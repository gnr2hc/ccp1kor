/////////////////////////////////////////////////////////////////////////////
// Name:        wx/dcps.h
// Purpose:     wxPostScriptDC base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// RCS-ID:      $Id: dcps.h 33948 2005-05-04 18:57:50Z JS $
// Licence:     wxWindows Licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_DCPS_H_BASE_
#define _WX_DCPS_H_BASE_

#include "wx/generic/dcpsg.h"

#endif

