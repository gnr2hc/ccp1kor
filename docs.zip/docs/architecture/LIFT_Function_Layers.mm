<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1399967622243" ID="ID_1596765644" MODIFIED="1418894049122">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      LIFT Functional Layers<br />
    </p>
  </body>
</html></richcontent>
<node CREATED="1416830390579" ID="ID_1412731015" MODIFIED="1421161499770" POSITION="left" TEXT="Layers">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Functional layer and device layer are shown
    </p>
  </body>
</html></richcontent>
<node CREATED="1417100012027" FOLDED="true" ID="ID_216646741" MODIFIED="1421935985693" TEXT="ECU Logical Layer (trial)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      All input/output possibilities are listed from ECU point of view
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1417516925380" ID="ID_786259973" MODIFIED="1418894598647" TEXT="control">
<node CREATED="1417514010000" ID="ID_1742219873" MODIFIED="1418894613025" TEXT="External components">
<node CREATED="1417100155551" FOLDED="true" ID="ID_985218384" MODIFIED="1418644291727" TEXT="peripheral sensors">
<node CREATED="1417515024505" FOLDED="true" ID="ID_1208602949" MODIFIED="1417521209693" TEXT="attributes">
<node CREATED="1417515081325" FOLDED="true" ID="ID_1842334312" MODIFIED="1417516825206" TEXT="type">
<node CREATED="1417515088837" ID="ID_799324742" MODIFIED="1417515093782" TEXT="upfront"/>
<node CREATED="1417515094679" ID="ID_500756527" MODIFIED="1417515101730" TEXT="side accel"/>
<node CREATED="1417515102284" ID="ID_779625304" MODIFIED="1417515107900" TEXT="side press"/>
<node CREATED="1417515114288" ID="ID_1812902553" MODIFIED="1417515118172" TEXT="pedestrian prot"/>
<node CREATED="1417515123734" ID="ID_1187924814" MODIFIED="1417515126823" TEXT="rear crash"/>
</node>
<node CREATED="1417515154208" ID="ID_631277300" MODIFIED="1417515159044" TEXT="customer name"/>
<node CREATED="1417515160846" ID="ID_1492339554" MODIFIED="1417516540037" TEXT="orientation (+- x, y, z)"/>
<node CREATED="1417516542962" FOLDED="true" ID="ID_1630882969" MODIFIED="1417521207853" TEXT="reality">
<node CREATED="1417516669087" ID="ID_717967075" MODIFIED="1417516670974" TEXT="real"/>
<node CREATED="1417516671372" ID="ID_724660595" MODIFIED="1417516674476" TEXT="simulation"/>
</node>
</node>
<node CREATED="1417515031050" FOLDED="true" ID="ID_1617515242" MODIFIED="1417521210698" TEXT="methods">
<node CREATED="1417515689195" ID="ID_509144453" MODIFIED="1417515695201" TEXT="get/set attributes"/>
<node CREATED="1417101679251" FOLDED="true" ID="ID_1380150736" MODIFIED="1417516703266" TEXT="configure">
<node CREATED="1417101868789" ID="ID_582297150" MODIFIED="1417101871401" TEXT="PD"/>
</node>
<node CREATED="1417101679251" FOLDED="true" ID="ID_1388354749" MODIFIED="1417516705419" STYLE="fork" TEXT="connect">
<node CREATED="1417101872667" ID="ID_228862915" MODIFIED="1417101879296" TEXT="I/O lines"/>
</node>
<node CREATED="1417103054230" FOLDED="true" ID="ID_847011754" MODIFIED="1417516982299" TEXT="stimulate">
<node CREATED="1417103203500" ID="ID_878377554" MODIFIED="1417103206528" TEXT="motion"/>
<node CREATED="1417516801486" ID="ID_1724502702" MODIFIED="1417516813725" TEXT="(pressure)"/>
<node CREATED="1417516772767" ID="ID_1963911903" MODIFIED="1417516776885" TEXT="injection"/>
</node>
<node CREATED="1417103402579" ID="ID_795088387" MODIFIED="1417103404224" TEXT="trace"/>
</node>
</node>
<node CREATED="1417100125011" FOLDED="true" ID="ID_1961760688" MODIFIED="1421931627804" TEXT="switches">
<node CREATED="1417515024505" FOLDED="true" ID="ID_1313384217" MODIFIED="1421931624598" TEXT="attributes">
<node CREATED="1417515081325" ID="ID_1604393115" MODIFIED="1418894649285" TEXT="type">
<node CREATED="1417517139964" ID="ID_575428848" MODIFIED="1417517145650" TEXT="hall"/>
<node CREATED="1417517146329" ID="ID_1093558301" MODIFIED="1418225326092" TEXT="resistive 1/2/3/..."/>
<node CREATED="1417517151640" ID="ID_576477840" MODIFIED="1417517155821" TEXT="mechanical"/>
<node CREATED="1417517156203" ID="ID_1369072275" MODIFIED="1417517214653" TEXT="external voltage"/>
<node CREATED="1417517216595" ID="ID_824570795" MODIFIED="1418207289425" TEXT="CAN"/>
</node>
<node CREATED="1417518030093" ID="ID_16130788" MODIFIED="1418894655972" TEXT="via type">
<node CREATED="1417517647290" FOLDED="true" ID="ID_889507016" MODIFIED="1421931292649" TEXT="position A">
<node CREATED="1417517678381" ID="ID_1864069345" MODIFIED="1417517681408" TEXT="min"/>
<node CREATED="1417517684052" ID="ID_1072590535" MODIFIED="1417517687219" TEXT="max"/>
<node CREATED="1417517687889" ID="ID_968844516" MODIFIED="1417517690595" TEXT="default"/>
<node CREATED="1417517820692" ID="ID_969189177" MODIFIED="1417517824031" TEXT="meaning"/>
</node>
<node CREATED="1417517701593" ID="ID_979161875" MODIFIED="1417517704869" TEXT="position B"/>
<node CREATED="1417517848109" ID="ID_1586588279" MODIFIED="1417517862836" TEXT="short to GND"/>
<node CREATED="1417517863483" ID="ID_1535348548" MODIFIED="1417517866931" TEXT="open line"/>
<node CREATED="1417517867235" ID="ID_1864152553" MODIFIED="1417517956094" TEXT="undefined"/>
</node>
<node CREATED="1417515154208" ID="ID_1966989666" MODIFIED="1417515159044" TEXT="customer name"/>
<node CREATED="1421931480431" ID="ID_376231522" MODIFIED="1421931485502" TEXT="configured"/>
<node CREATED="1417517308938" ID="ID_1424859668" MODIFIED="1418894672299" TEXT="location">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      pin/number, CAN/signalName, ECUsignal/address
    </p>
  </body>
</html></richcontent>
<node CREATED="1417521319384" ID="ID_29390221" MODIFIED="1418894675506" TEXT="area">
<node CREATED="1418225551295" ID="ID_1271106104" MODIFIED="1418225553198" TEXT="pin"/>
<node CREATED="1418225553611" ID="ID_1734494516" MODIFIED="1418225556263" TEXT="CAN"/>
</node>
<node CREATED="1417521323675" ID="ID_310468890" MODIFIED="1418894679513" TEXT="name">
<node CREATED="1418225583384" ID="ID_1182127124" MODIFIED="1418225586878" TEXT="pin number"/>
<node CREATED="1418225587354" ID="ID_280150058" MODIFIED="1418225592580" TEXT="CAN sginal name"/>
</node>
</node>
<node CREATED="1417520789401" ID="ID_529474460" MODIFIED="1421931490063" TEXT="value_unit">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      value (in ohm or ampere or ...) depending on type
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1418225653344" ID="ID_102529865" MODIFIED="1418225655762" TEXT="value"/>
<node CREATED="1418225656160" ID="ID_128322957" MODIFIED="1418225657766" TEXT="unit"/>
</node>
</node>
<node CREATED="1417515031050" FOLDED="true" ID="ID_1688491375" MODIFIED="1421931626229" TEXT="methods">
<node CREATED="1417515689195" FOLDED="true" ID="ID_157606530" MODIFIED="1418118278821" TEXT="get/set attributes">
<node CREATED="1417520837914" ID="ID_1842349883" MODIFIED="1417520848930" TEXT="internal"/>
</node>
<node CREATED="1417101679251" ID="ID_565882507" MODIFIED="1421931620247" TEXT="set configure state in ECU">
<node CREATED="1417101868789" ID="ID_446701555" MODIFIED="1417101871401" TEXT="PD"/>
</node>
<node CREATED="1417101679251" FOLDED="true" ID="ID_1027748300" MODIFIED="1418119794548" STYLE="fork" TEXT="connect on bench">
<node CREATED="1417101872667" ID="ID_752091088" MODIFIED="1417101879296" TEXT="I/O lines"/>
</node>
<node CREATED="1417103402579" FOLDED="true" ID="ID_242354047" MODIFIED="1418119804110" TEXT="configure for trace">
<node CREATED="1417521132016" ID="ID_407485057" MODIFIED="1417521148026" TEXT="I/O lines measurement"/>
<node CREATED="1417521173382" ID="ID_1415073045" MODIFIED="1417521188358" TEXT="CAN comm"/>
</node>
<node CREATED="1417101631842" FOLDED="true" ID="ID_194600035" MODIFIED="1418120518181" TEXT="set state">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      states can be: position A -&gt; meaning, position B -&gt; meaning, short to GND, open line, undefined
    </p>
  </body>
</html></richcontent>
<node CREATED="1417101905838" ID="ID_1004877851" MODIFIED="1417101914025" TEXT="I/O lines"/>
<node CREATED="1417520916186" ID="ID_1125536056" MODIFIED="1417520919801" TEXT="CAN comm"/>
</node>
<node CREATED="1417103447900" FOLDED="true" ID="ID_192382318" MODIFIED="1418120515904" TEXT="get state">
<node CREATED="1417520870890" ID="ID_29068659" MODIFIED="1417520874585" TEXT="internal"/>
</node>
</node>
</node>
<node CREATED="1417100169993" FOLDED="true" ID="ID_215456428" MODIFIED="1418644294982" TEXT="actuators">
<node CREATED="1417101679251" FOLDED="true" ID="ID_401795578" MODIFIED="1418225404568" TEXT="configure (present, not present, resistance)">
<node CREATED="1417101868789" ID="ID_708473351" MODIFIED="1417101871401" TEXT="PD"/>
<node CREATED="1417101872667" ID="ID_640366028" MODIFIED="1417101879296" TEXT="I/O lines"/>
</node>
<node CREATED="1417103431540" ID="ID_351031328" MODIFIED="1417103432697" TEXT="get"/>
<node CREATED="1417102192525" ID="ID_662561294" MODIFIED="1417102195161" TEXT="trace"/>
</node>
<node CREATED="1417100200829" ID="ID_404281300" MODIFIED="1417514057291" TEXT="analog output"/>
<node CREATED="1417101398614" ID="ID_701689652" MODIFIED="1417514130100" TEXT="power supply"/>
<node CREATED="1417514149920" ID="ID_470042616" MODIFIED="1417514152400" TEXT="disposal"/>
<node CREATED="1417100352396" ID="ID_1920768591" MODIFIED="1417514353973" TEXT="communication Rx"/>
<node CREATED="1417100518673" ID="ID_1564925739" MODIFIED="1417446953248" TEXT="(temperature)"/>
</node>
<node CREATED="1417514248201" FOLDED="true" ID="ID_1984581395" MODIFIED="1418894029793" TEXT="Internal components">
<node CREATED="1417514285663" ID="ID_1472804672" MODIFIED="1417514295584" TEXT="System Asics"/>
<node CREATED="1417100398285" FOLDED="true" ID="ID_1343009723" MODIFIED="1417513965348" TEXT="internal sensors">
<node CREATED="1417103054230" FOLDED="true" ID="ID_675813138" MODIFIED="1417513965348" TEXT="stimulate real">
<node CREATED="1417103203500" ID="ID_653419163" MODIFIED="1417103206528" TEXT="motion"/>
</node>
<node CREATED="1417103067071" FOLDED="true" ID="ID_1240687492" MODIFIED="1417513965348" TEXT="stimulate simulation">
<node CREATED="1417103209035" ID="ID_87232679" MODIFIED="1417103223753" TEXT="SPI"/>
</node>
<node CREATED="1417103402579" ID="ID_1406871120" MODIFIED="1417103404224" TEXT="trace"/>
</node>
<node CREATED="1417514409126" ID="ID_1865855319" MODIFIED="1417514413682" TEXT="communication Tx"/>
<node CREATED="1417100357204" ID="ID_1843444466" MODIFIED="1417100360440" TEXT="ECU signals"/>
</node>
</node>
<node CREATED="1417516936791" ID="ID_289355390" MODIFIED="1417516939630" TEXT="measurement"/>
<node CREATED="1417524858453" FOLDED="true" ID="ID_1930467581" MODIFIED="1418894029794" TEXT="project config">
<node CREATED="1418225844827" FOLDED="true" ID="ID_380677635" MODIFIED="1418723202601" TEXT="switches">
<node CREATED="1418226008925" ID="ID_1944737446" MODIFIED="1418226012653" TEXT="customerName"/>
<node CREATED="1418225865653" ID="ID_1001682732" MODIFIED="1418226708768" TEXT="type">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      see switch_types
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1418225870435" FOLDED="true" ID="ID_1335437905" MODIFIED="1418723202601" TEXT="location">
<node CREATED="1417521319384" FOLDED="true" ID="ID_1452948880" MODIFIED="1418723202601" TEXT="area">
<node CREATED="1418225551295" ID="ID_1271307708" MODIFIED="1418641219826" TEXT="pin">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Cannot really be used because mapping from TSG4/MLC pins to ECU pins is done by wiring harness.
    </p>
    <p>
      Access to individual switches is done by customer name.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1418225553611" ID="ID_1687436714" MODIFIED="1418225556263" TEXT="CAN"/>
</node>
<node CREATED="1417521323675" FOLDED="true" ID="ID_905510546" MODIFIED="1418723202601" TEXT="name">
<node CREATED="1418225583384" ID="ID_1314205511" MODIFIED="1418225586878" TEXT="pin number"/>
<node CREATED="1418225587354" ID="ID_1668671444" MODIFIED="1418225592580" TEXT="CAN sginal name"/>
</node>
</node>
</node>
<node CREATED="1418226047870" FOLDED="true" ID="ID_261830501" MODIFIED="1418644254449" TEXT="switch_types">
<node CREATED="1417517139964" ID="ID_1244553952" MODIFIED="1417517145650" TEXT="hall"/>
<node CREATED="1417517146329" FOLDED="true" ID="ID_135957763" MODIFIED="1418723202601" TEXT="resistive 1/2/3/...">
<node CREATED="1417517647290" FOLDED="true" ID="ID_32296483" MODIFIED="1418640551631" TEXT="position A">
<node CREATED="1417517678381" ID="ID_1835006793" MODIFIED="1417517681408" TEXT="min"/>
<node CREATED="1417517684052" ID="ID_385452623" MODIFIED="1417517687219" TEXT="max"/>
<node CREATED="1417517687889" ID="ID_871802215" MODIFIED="1417517690595" TEXT="default"/>
<node CREATED="1417517820692" ID="ID_785398749" MODIFIED="1417517824031" TEXT="meaning"/>
</node>
<node CREATED="1417517701593" ID="ID_224143201" MODIFIED="1417517704869" TEXT="position B"/>
<node CREATED="1417517848109" ID="ID_364072939" MODIFIED="1417517862836" TEXT="short to GND"/>
<node CREATED="1417517863483" ID="ID_808737784" MODIFIED="1417517866931" TEXT="open line"/>
<node CREATED="1417517867235" ID="ID_1241403147" MODIFIED="1417517956094" TEXT="undefined"/>
</node>
<node CREATED="1417517151640" ID="ID_722321467" MODIFIED="1417517155821" TEXT="mechanical"/>
<node CREATED="1417517156203" ID="ID_1999756144" MODIFIED="1417517214653" TEXT="external voltage"/>
<node CREATED="1417517216595" ID="ID_1177584921" MODIFIED="1418207289425" TEXT="CAN"/>
</node>
<node CREATED="1418644014398" FOLDED="true" ID="ID_1704909968" MODIFIED="1418723202601" TEXT="TSG4">
<node CREATED="1418644040738" FOLDED="true" ID="ID_1316554258" MODIFIED="1418644148721" TEXT="BELT_LOCKS (switches)">
<node CREATED="1418644061977" ID="ID_1378580160" MODIFIED="1418644072173" TEXT="name"/>
<node CREATED="1418644072848" ID="ID_445438595" MODIFIED="1418644074805" TEXT="unit"/>
<node CREATED="1418644075048" ID="ID_943965506" MODIFIED="1418644078564" TEXT="default"/>
<node CREATED="1418644078785" ID="ID_974805651" MODIFIED="1418644091244" TEXT="state A"/>
<node CREATED="1418644091607" ID="ID_308330164" MODIFIED="1418644093843" TEXT="state B"/>
<node CREATED="1418644139836" ID="ID_704500994" MODIFIED="1418644142968" TEXT="state short"/>
<node CREATED="1418644143579" ID="ID_1283331754" MODIFIED="1418644145944" TEXT="state open"/>
</node>
</node>
<node CREATED="1418644170594" FOLDED="true" ID="ID_8504951" MODIFIED="1418723202601" TEXT="MLC">
<node CREATED="1418644176290" FOLDED="true" ID="ID_272211367" MODIFIED="1418644215580" TEXT="SWITCHES">
<node CREATED="1418644201576" ID="ID_527488030" MODIFIED="1418644202708" TEXT="name"/>
<node CREATED="1418644203224" ID="ID_1691815975" MODIFIED="1418644204684" TEXT="open"/>
<node CREATED="1418644205168" ID="ID_1574203650" MODIFIED="1418644206876" TEXT="closed"/>
</node>
</node>
</node>
</node>
<node CREATED="1399967910509" ID="ID_1810452528" MODIFIED="1421930251198" TEXT="Functional Layer">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Functions in this layer are covered by several devices and are recommended to be used in test cases.
    </p>
    <p>
      The functionality of a functional layer is largely determined by the tools.
    </p>
  </body>
</html>
</richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1416993644456" FOLDED="true" ID="ID_557200679" MODIFIED="1421161510898" TEXT="current functional layers">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1399984551649" ID="ID_238113740" MODIFIED="1418894466883" TEXT="Diagnostic and Network">
<node CREATED="1399967736568" FOLDED="true" ID="ID_1755925919" MODIFIED="1417002769810" TEXT="LIFT_CD.pm">
<node CREATED="1399967736583" ID="ID_681184531" MODIFIED="1399967736583" TEXT="LIFT_CD_CAN.pm"/>
<node CREATED="1416242323921" ID="ID_1139980231" MODIFIED="1416242334485" TEXT="LIFT_CD_ODIS.pm"/>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_237230872" MODIFIED="1417002784810" TEXT="LIFT_PD.pm">
<node CREATED="1416242623589" FOLDED="true" ID="ID_1964844731" MODIFIED="1416849430455" TEXT="no device">
<icon BUILTIN="help"/>
<node CREATED="1399980288907" ID="ID_1243188837" MODIFIED="1399980288907" TEXT="PD.pm"/>
</node>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_1106712519" MODIFIED="1417002784810" TEXT="LIFT_can_access.pm">
<node CREATED="1399967736599" FOLDED="true" ID="ID_123518124" MODIFIED="1416907603179" TEXT="LIFT_vector_cantool.pm">
<node CREATED="1399967736599" ID="ID_1488607307" MODIFIED="1399967736599" TEXT="LIFT_vector_xcp.pm"/>
</node>
<node CREATED="1399967736599" ID="ID_285101478" MODIFIED="1399967736599" TEXT="LIFT_vector_canstress.pm"/>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_1207291060" MODIFIED="1417002784810" TEXT="LIFT_flexray_access.pm">
<node CREATED="1399967736599" FOLDED="true" ID="ID_805145717" MODIFIED="1416849430455" TEXT="LIFT_vector_cantool.pm">
<node CREATED="1399967736599" ID="ID_856202471" MODIFIED="1399967736599" TEXT="LIFT_vector_xcp.pm"/>
</node>
</node>
<node CREATED="1416245444409" FOLDED="true" ID="ID_1079662348" MODIFIED="1417002784810" TEXT="LIFT_LIN_access.pm">
<node CREATED="1399967736599" FOLDED="true" ID="ID_1241323639" MODIFIED="1416849430460" TEXT="LIFT_vector_cantool.pm">
<node CREATED="1399967736599" ID="ID_1815595468" MODIFIED="1399967736599" TEXT="LIFT_vector_xcp.pm"/>
</node>
</node>
<node CREATED="1399980288897" ID="ID_162230534" MODIFIED="1400054165272" TEXT="DCOM_SecurityAccess_KeyAlgo.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      check if used
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="help"/>
</node>
<node CREATED="1399980288897" ID="ID_440424997" MODIFIED="1416245514843" TEXT="DCOM_user_functions.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      calls STEPS functions !!!
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_cancel"/>
</node>
</node>
<node CREATED="1399988251160" ID="ID_1117066449" MODIFIED="1418894479742" TEXT="Measurement">
<node CREATED="1399967736583" FOLDED="true" ID="ID_1977838227" MODIFIED="1417002784810" TEXT="LIFT_TEMPERATURE.pm">
<node CREATED="1399967736583" ID="ID_278240217" MODIFIED="1399967736583" TEXT="LIFT_VOETSCH.pm"/>
<node CREATED="1416242603582" FOLDED="true" ID="ID_1289286162" MODIFIED="1416849430460" TEXT="no device">
<icon BUILTIN="help"/>
<node CREATED="1399980288902" ID="ID_528477853" MODIFIED="1399985692988" TEXT="DTM5080.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      only temperature measurement
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_1543029665" MODIFIED="1416243381756" TEXT="tsg4_rc.pm"/>
</node>
</node>
</node>
<node CREATED="1399984578744" ID="ID_1733751721" MODIFIED="1418894484263" TEXT="Stimulation">
<node CREATED="1399981248338" FOLDED="true" ID="ID_1910516394" MODIFIED="1417002784810" TEXT="FuncLib_TNT_DEVICE.pm">
<node CREATED="1399967736583" ID="ID_890414727" MODIFIED="1416242748697" TEXT="LIFT_PD.pm">
<icon BUILTIN="help"/>
</node>
<node CREATED="1399967736583" ID="ID_656091237" MODIFIED="1399967736583" TEXT="LIFT_MLC.pm"/>
<node CREATED="1399967736583" ID="ID_970119637" MODIFIED="1399967736583" TEXT="LIFT_TSG4.pm"/>
</node>
<node CREATED="1399967736583" ID="ID_422388119" MODIFIED="1418895756226" TEXT="LIFT_POWER.pm">
<node CREATED="1399967736583" ID="ID_114706868" MODIFIED="1399967736583" TEXT="LIFT_MLC.pm"/>
<node CREATED="1399967736583" ID="ID_1423558600" MODIFIED="1399967736583" TEXT="LIFT_TOE1.pm"/>
<node CREATED="1399967736583" ID="ID_1972923934" MODIFIED="1399967736583" TEXT="LIFT_TSG4.pm"/>
<node CREATED="1399967736583" ID="ID_1889047674" MODIFIED="1399967736583" TEXT="LIFT_IDEFIX.pm"/>
<node CREATED="1399967736583" ID="ID_1855545511" MODIFIED="1399967736583" TEXT="LIFT_IDXSPI.pm"/>
<node CREATED="1399967736583" ID="ID_1295684425" MODIFIED="1399967736583" TEXT="LIFT_GOS1.pm"/>
<node CREATED="1399967736583" ID="ID_201747671" MODIFIED="1399967736583" TEXT="LIFT_NIDAQ.pm"/>
</node>
</node>
</node>
<node CREATED="1416489579094" FOLDED="true" ID="ID_1977604837" MODIFIED="1421937814427" TEXT="new/modified functional layers">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1416489600991" ID="ID_552964238" MODIFIED="1421935824291" TEXT="LIFT_labcar (new)">
<node CREATED="1418727125955" ID="ID_1448028252" MODIFIED="1421933022230" TEXT="devices">
<node CREATED="1399967736583" ID="ID_1789167487" MODIFIED="1399967736583" TEXT="LIFT_MLC.pm"/>
<node CREATED="1399967736583" ID="ID_113499750" MODIFIED="1399967736583" TEXT="LIFT_TSG4.pm"/>
</node>
<node CREATED="1421935826332" ID="ID_1494711872" MODIFIED="1421935833278" TEXT="function">
<node CREATED="1421935837976" ID="ID_1554660113" MODIFIED="1421935842776" TEXT="power">
<node CREATED="1421933095646" ID="ID_412611787" MODIFIED="1421933095646" TEXT="LC_SetVoltage"/>
</node>
<node CREATED="1421935844798" ID="ID_226571237" MODIFIED="1421936334685" TEXT="line">
<node CREATED="1421933095642" ID="ID_87359879" MODIFIED="1421933095642" TEXT="LC_ConnectLine"/>
<node CREATED="1421933095643" ID="ID_1583830376" MODIFIED="1421933095643" TEXT="LC_DisconnectLine"/>
<node CREATED="1421933095643" ID="ID_1670934221" MODIFIED="1421933095643" TEXT="LC_ShortLines"/>
<node CREATED="1421933095645" ID="ID_1562158350" MODIFIED="1421933095645" TEXT="LC_UndoShortLines"/>
</node>
<node CREATED="1421936831633" ID="ID_579229892" MODIFIED="1421936834688" TEXT="lineRT">
<node CREATED="1421933095647" ID="ID_619764208" MODIFIED="1421933095647" TEXT="LC_LV124_microcut"/>
</node>
<node CREATED="1421935852721" ID="ID_1584146630" MODIFIED="1421935893388" TEXT="signal stimulation">
<node CREATED="1421935961551" ID="ID_148064281" MODIFIED="1421935977587" TEXT="LC_stimulate_PWM_signal"/>
</node>
</node>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_309190979" MODIFIED="1418727284542" TEXT="LIFT_POWER.pm (add get and stimulate, add second power supply) ">
<node CREATED="1399967736583" ID="ID_1124912842" MODIFIED="1399967736583" TEXT="LIFT_MLC.pm"/>
<node CREATED="1399967736583" ID="ID_1426431523" MODIFIED="1399967736583" TEXT="LIFT_TOE1.pm"/>
<node CREATED="1399967736583" ID="ID_15831856" MODIFIED="1399967736583" TEXT="LIFT_TSG4.pm"/>
<node CREATED="1399967736583" ID="ID_1715522683" MODIFIED="1399967736583" TEXT="LIFT_IDEFIX.pm"/>
<node CREATED="1399967736583" ID="ID_604321488" MODIFIED="1399967736583" TEXT="LIFT_IDXSPI.pm"/>
<node CREATED="1399967736583" ID="ID_326876067" MODIFIED="1399967736583" TEXT="LIFT_GOS1.pm"/>
<node CREATED="1399967736583" ID="ID_1563877195" MODIFIED="1399967736583" TEXT="LIFT_NIDAQ.pm"/>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_859755526" MODIFIED="1421935982058" TEXT="LIFT_TEMPERATURE.pm (add set and stimulate)">
<node CREATED="1421933001397" ID="ID_1914286249" MODIFIED="1421933003953" TEXT="devices">
<node CREATED="1399967736583" ID="ID_1373800650" MODIFIED="1399967736583" TEXT="LIFT_VOETSCH.pm"/>
<node CREATED="1416242603582" FOLDED="true" ID="ID_1297222486" MODIFIED="1421933177567" TEXT="DTM5080">
<node CREATED="1399980288902" ID="ID_1467501790" MODIFIED="1399985692988" TEXT="DTM5080.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      only temperature measurement
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_1916348916" MODIFIED="1416243381756" TEXT="tsg4_rc.pm"/>
</node>
</node>
<node CREATED="1421933012158" ID="ID_380356582" MODIFIED="1421933015066" TEXT="interface"/>
</node>
<node CREATED="1399967736583" FOLDED="true" ID="ID_1549476063" MODIFIED="1418723202601" TEXT="LIFT_can_access.pm (include APIs from CANoe and CANoe_Ctrl)">
<node CREATED="1417020413293" FOLDED="true" ID="ID_1607046239" MODIFIED="1417093179861" TEXT="modules used">
<node CREATED="1399967736599" FOLDED="true" ID="ID_1335429965" MODIFIED="1417020338183" TEXT="LIFT_vector_cantool.pm">
<node CREATED="1399967736599" ID="ID_1696504735" MODIFIED="1399967736599" TEXT="LIFT_vector_xcp.pm"/>
</node>
<node CREATED="1399967736599" ID="ID_615515866" MODIFIED="1399967736599" TEXT="LIFT_vector_canstress.pm"/>
</node>
<node CREATED="1417020422807" FOLDED="true" ID="ID_537961089" MODIFIED="1418723202601" TEXT="CANoe APIs used in test cases">
<node CREATED="1417020489859" ID="ID_188380829" MODIFIED="1417020607759" TEXT="CAN_set_EnvVar_value"/>
<node CREATED="1417020489864" ID="ID_1395691818" MODIFIED="1417021123734" TEXT="CAN_logging_start">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_trace_start
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_1725412123" MODIFIED="1417021130752" TEXT="CAN_logging_stop">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_trace_start
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_161950706" MODIFIED="1417021153484" TEXT="CAN_trace_can_get_dataref">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_trace_get_dataref
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_1714963380" MODIFIED="1417021161024" TEXT="CAN_log_store">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_trace_store
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_1961252592" MODIFIED="1417021236895" TEXT="CAN_get_Signal_value">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_read_can_signal
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_1909073966" MODIFIED="1417020489864" TEXT="CAN_get_EnvVar_value"/>
<node CREATED="1417020489864" ID="ID_1721485741" MODIFIED="1417021399357" TEXT="CAN_trace_store">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_trace_store and CA_trace_stop
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1417020489864" ID="ID_1482642307" MODIFIED="1417020489864" TEXT="CAN_start_measurement"/>
<node CREATED="1417020489864" ID="ID_448892060" MODIFIED="1417021518059" TEXT="CAN_send_request_wait_response">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      is an API of LIFT_CD_CAN
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_cancel"/>
</node>
<node CREATED="1417020489869" ID="ID_855339805" MODIFIED="1417021653067" TEXT="CAN_stop_measurement"/>
<node CREATED="1417020489869" ID="ID_1592200517" MODIFIED="1417021807025" TEXT="CAN_init">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CA_..._configure
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1417020895454" ID="ID_1906767468" MODIFIED="1417020930936" TEXT="separate start trace from start simulation"/>
<node CREATED="1417021870936" FOLDED="true" ID="ID_1894675696" MODIFIED="1417096404346" TEXT="CANoe_Ctrl APIs planned to be used">
<node CREATED="1417021940319" ID="ID_430767917" MODIFIED="1417021942491" TEXT="CANoeCtrl_init"/>
<node CREATED="1417021956784" ID="ID_713244582" MODIFIED="1417022044993" TEXT="CANoeCtrl_PutSignal (not existing)"/>
<node CREATED="1417021967040" ID="ID_292252981" MODIFIED="1417021967821" TEXT="CANoeCtrl_Exit"/>
</node>
</node>
<node CREATED="1416994059310" FOLDED="true" ID="ID_1223174517" MODIFIED="1421164398743" TEXT="LIFT_line_measurement_trace (new, not now)">
<node CREATED="1416502430489" ID="ID_583133435" MODIFIED="1416502432726" TEXT="LCT64"/>
<node CREATED="1416502442112" ID="ID_421844023" MODIFIED="1416994072026" TEXT="TRC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      combine MF and Tassler
    </p>
    <p>
      LIFT_TRC
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1416502521651" ID="ID_1913227898" MODIFIED="1416502526840" TEXT="logic analyzer"/>
<node CREATED="1416502452408" ID="ID_176427470" MODIFIED="1416502454196" TEXT="DSO"/>
<node CREATED="1416489913441" ID="ID_955304235" MODIFIED="1418726785561" TEXT="LIFT_TRC"/>
</node>
<node CREATED="1416489800427" ID="ID_1433223390" MODIFIED="1421930290282" TEXT="LIFT_motion (new, not now)">
<node CREATED="1399967736568" ID="ID_59880503" MODIFIED="1416489840706" TEXT="LIFT_ACUROT.pm"/>
<node CREATED="1399967736583" ID="ID_628555436" MODIFIED="1416489849370" TEXT="LIFT_RAT.pm"/>
</node>
<node CREATED="1416994820630" FOLDED="true" ID="ID_1219433742" MODIFIED="1421164401989" TEXT="LIFT_sensor_simulation (new)">
<icon BUILTIN="help"/>
<node CREATED="1416994842449" ID="ID_933236007" MODIFIED="1416994845664" TEXT="Quate"/>
<node CREATED="1416994849102" ID="ID_1805332313" MODIFIED="1416994851584" TEXT="Idefix"/>
</node>
<node CREATED="1416994059310" FOLDED="true" ID="ID_983540575" MODIFIED="1418725230485" TEXT="LIFT_line_measurement_once (new)">
<icon BUILTIN="help"/>
<node CREATED="1417096477555" ID="ID_7831014" MODIFIED="1417096479870" TEXT="DMM"/>
</node>
</node>
</node>
<node CREATED="1399967920641" FOLDED="true" ID="ID_967665557" MODIFIED="1421161508048" TEXT="Devices with (currently) no Functional Layer">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Functions in this layer correspond to one specific device and are not recommended to be used in test cases unless no proper functions exist in higher layers.
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1399975833260" FOLDED="true" ID="ID_1141069473" MODIFIED="1417002781250" TEXT="CAN / CANoe">
<node CREATED="1399967736568" ID="ID_487722205" MODIFIED="1416303559208" TEXT="LIFT_CANoe.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      functionality partly covered by LIFT_can_access, but some functions (e.g. environment variables) are not covered
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1416302367304" ID="ID_1211913854" MODIFIED="1416489180255" TEXT="LIFT_CANoeCtrl.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ported from Testprog, CAPL handling function are here
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399975745454" FOLDED="true" ID="ID_1680383504" MODIFIED="1417002781250" TEXT="Signal Capture">
<node CREATED="1399967736583" ID="ID_427445885" MODIFIED="1416489297931" TEXT="LIFT_DMM1.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Multimeter, currently only one device
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_1885455059" MODIFIED="1416489322843" TEXT="LIFT_DSO1.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      oscilloscope, currently only one device
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_1482786720" MODIFIED="1416489375499" TEXT="LIFT_TRC.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      transient recorder, name fits to functional layer, but only MF is currently supported, later Tassler will be implemented
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399975751534" FOLDED="true" ID="ID_1064383065" MODIFIED="1417002781250" TEXT="Logic Analyzer">
<node CREATED="1399967736583" ID="ID_320092293" MODIFIED="1416489436911" TEXT="LIFT_LCT.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      logic analyzer, specialized on fire times
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_518219440" MODIFIED="1416489447921" TEXT="LIFT_TRAVELLOGIC.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      logic analyzer
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399975757779" FOLDED="true" ID="ID_1569193667" MODIFIED="1417002781250" TEXT="SPI">
<node CREATED="1399967736583" ID="ID_1849052261" MODIFIED="1416489723617" TEXT="LIFT_IDXSPI.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      SPI monitor
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399975719922" FOLDED="true" ID="ID_957525796" MODIFIED="1417002781250" TEXT="Motion">
<node CREATED="1399967736568" ID="ID_711794284" MODIFIED="1416489752511" TEXT="LIFT_ACUROT.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ACUROT hardware
    </p>
    <p>
      a common motion function might be created if RAT has high level functions
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_454081508" MODIFIED="1416489791100" TEXT="LIFT_RAT.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      robot arm control
    </p>
    <p>
      no high level functions exist yet on device layer
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399975722997" FOLDED="true" ID="ID_1326989656" MODIFIED="1417002781250" TEXT="Sensors">
<node CREATED="1399967736583" ID="ID_1147709103" MODIFIED="1416489880400" TEXT="LIFT_IDEFIX.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      crash injection
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1399967736583" ID="ID_1898591141" MODIFIED="1416489891777" TEXT="LIFT_QuaTe.pm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      crash injection
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1399986975468" FOLDED="true" ID="ID_1681176485" MODIFIED="1417002781250" TEXT="others">
<node CREATED="1399967736568" ID="ID_966462956" MODIFIED="1399967736568" TEXT="LIFT_AFG1.pm"/>
<node CREATED="1399967736583" ID="ID_1504173208" MODIFIED="1399967736583" TEXT="LIFT_FETbox.pm"/>
<node CREATED="1399967736583" ID="ID_693693483" MODIFIED="1399988207765" TEXT="LIFT_MDSRESULT.pm"/>
<node CREATED="1399967736583" ID="ID_65672400" MODIFIED="1399984400599" TEXT="LIFT_PRITT.pm"/>
<node CREATED="1402457449946" ID="ID_1989764540" MODIFIED="1402457613700" TEXT="LIFT_sVTT_Curves.pm"/>
</node>
</node>
</node>
<node CREATED="1416830434168" ID="ID_1575758525" MODIFIED="1421935134201" POSITION="right" TEXT="ECU environment">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      All input/output possibilities are listed from testbench point of view
    </p>
  </body>
</html></richcontent>
<node CREATED="1416492348264" ID="ID_1154237141" MODIFIED="1418894117851" TEXT="outside ECU">
<node CREATED="1416492366049" ID="ID_1584468333" MODIFIED="1418894215695" TEXT="temperature">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      complete LIFT_temperature: temperature measure <b>and set and stimulate</b>
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_851136635" MODIFIED="1416907499576" TEXT="get"/>
<node CREATED="1416846859391" ID="ID_1701677029" MODIFIED="1421935242037" TEXT="set (target temperature)"/>
<node CREATED="1416906197583" ID="ID_1255921339" MODIFIED="1416906221513" TEXT="stimulate (set program)"/>
<node CREATED="1417093901635" ID="ID_899993659" MODIFIED="1417093906126" TEXT="(trace)"/>
<node CREATED="1417093925422" ID="ID_1366315144" MODIFIED="1421935242038" TEXT="wait for temp"/>
</node>
<node CREATED="1416492380418" ID="ID_197445490" MODIFIED="1418894217200" TEXT="motion">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      combine ACUROT and RAT
    </p>
    <p>
      LIFT_motion
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<node CREATED="1416847050357" ID="ID_1251103817" MODIFIED="1416847058282" TEXT="set rotation rate"/>
<node CREATED="1416846859391" ID="ID_321106299" MODIFIED="1416847121144" TEXT="set acceleration (static)"/>
<node CREATED="1416847088077" ID="ID_444606647" MODIFIED="1416847114357" TEXT="stimulate (complex motion)"/>
</node>
</node>
<node CREATED="1416492486765" ID="ID_238082971" MODIFIED="1418894192068" TEXT="power">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      extend LIFT_POWER:
    </p>
    <p>
      stimulate: define and run volage curves
    </p>
    <p>
      get: return last voltage value that was set (no measurment)
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_1319620350" MODIFIED="1416993905445" TEXT="get (no measurement)"/>
<node CREATED="1416846859391" ID="ID_952698192" MODIFIED="1416846933749" TEXT="set"/>
<node CREATED="1416847834400" ID="ID_810058505" MODIFIED="1416847836885" TEXT="switch"/>
<node CREATED="1416848287549" ID="ID_236725483" MODIFIED="1416993907988" TEXT="stimulate (voltage curve)"/>
</node>
<node CREATED="1416492029188" ID="ID_1069818438" MODIFIED="1418894264232" TEXT="I/O lines">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      line manipulations: read and set voltages/resistances, short/interrupt lines
    </p>
    <p>
      combine MLC and TSG4
    </p>
    <p>
      LIFT_labcar
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<node CREATED="1416492667115" ID="ID_1396089488" MODIFIED="1418894357731" TEXT="inputs">
<node CREATED="1416492623962" FOLDED="true" ID="ID_361206690" MODIFIED="1418894360833" TEXT="switches">
<node CREATED="1416847925774" ID="ID_293299946" MODIFIED="1416847928564" TEXT="set state"/>
<node CREATED="1416847962264" ID="ID_678440422" MODIFIED="1416847967242" TEXT="set resistance"/>
<node CREATED="1416848053692" ID="ID_988982781" MODIFIED="1416848056627" TEXT="set current"/>
<node CREATED="1416849068975" ID="ID_1908143144" MODIFIED="1416849074250" TEXT="see measurement"/>
</node>
<node CREATED="1416492617610" FOLDED="true" ID="ID_587486832" MODIFIED="1417095351176" TEXT="PAS">
<node CREATED="1416849068975" ID="ID_1249025524" MODIFIED="1416849074250" TEXT="see measurement"/>
<node CREATED="1417095186084" ID="ID_1385762346" MODIFIED="1417095193211" TEXT="set"/>
<node CREATED="1417095193785" ID="ID_591492885" MODIFIED="1417095319259" TEXT="stimulate (via PSI)"/>
</node>
</node>
<node CREATED="1416492680852" ID="ID_174534362" MODIFIED="1418894358556" TEXT="outputs">
<node CREATED="1416492636186" FOLDED="true" ID="ID_477773062" MODIFIED="1417095353816" TEXT="WL">
<node CREATED="1416849068975" ID="ID_341065324" MODIFIED="1416849074250" TEXT="see measurement"/>
</node>
<node CREATED="1416492524655" FOLDED="true" ID="ID_1480283777" MODIFIED="1417110361116" TEXT="squibs">
<node CREATED="1416849168619" ID="ID_1547821987" MODIFIED="1416849173944" TEXT="set current threshold"/>
<node CREATED="1416847962264" ID="ID_680733708" MODIFIED="1416847967242" TEXT="set resistance"/>
<node CREATED="1416849068975" ID="ID_544196598" MODIFIED="1416849074250" TEXT="see measurement"/>
</node>
<node CREATED="1416494316900" FOLDED="true" ID="ID_1792573353" MODIFIED="1416993146071" TEXT="crash output">
<node CREATED="1416849068975" ID="ID_672558159" MODIFIED="1416849074250" TEXT="see measurement"/>
</node>
</node>
<node CREATED="1416848601300" ID="ID_428024054" MODIFIED="1421930851578" TEXT="pin manipulation">
<node CREATED="1416848627105" ID="ID_1798694892" MODIFIED="1416848638335" TEXT="short"/>
<node CREATED="1416848620480" ID="ID_1791092775" MODIFIED="1416848671830" TEXT="disconnect"/>
<node CREATED="1416848936191" ID="ID_1251160597" MODIFIED="1416848941011" TEXT="microcut"/>
<node CREATED="1417094255040" ID="ID_298672744" MODIFIED="1417094339855" TEXT="set load"/>
</node>
<node CREATED="1416848160796" ID="ID_9687547" MODIFIED="1418894530153" TEXT="measurement">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      measurement device needs to be connected physically to particular lines
    </p>
  </body>
</html></richcontent>
<node CREATED="1416502119101" FOLDED="true" ID="ID_1038994485" MODIFIED="1417435737689" TEXT="one time">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      LIFT_line_measurement_once
    </p>
    <p>
      Only one device (DMM), so currently no priority for this functional layer
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<node CREATED="1416502400451" ID="ID_667305575" MODIFIED="1416502407111" TEXT="DMM"/>
</node>
<node CREATED="1416845274594" ID="ID_559592831" MODIFIED="1418894536642" TEXT="trace (threshold based time measurement)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      LIFT_line_measurement_trace
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<node CREATED="1416502430489" ID="ID_1535049291" MODIFIED="1416502432726" TEXT="LCT64"/>
<node CREATED="1416502442112" ID="ID_466055141" MODIFIED="1416994072026" TEXT="TRC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      combine MF and Tassler
    </p>
    <p>
      LIFT_TRC
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1416502521651" ID="ID_518263189" MODIFIED="1416502526840" TEXT="logic analyzer"/>
<node CREATED="1416502452408" ID="ID_443379805" MODIFIED="1416502454196" TEXT="DSO"/>
</node>
</node>
</node>
<node CREATED="1416492481429" FOLDED="true" ID="ID_1220228888" MODIFIED="1421932783330" TEXT="network">
<node CREATED="1416492748062" ID="ID_1737045710" MODIFIED="1418894282616" TEXT="ECU signals">
<node CREATED="1416499590989" FOLDED="true" ID="ID_1379100981" MODIFIED="1417094058690" TEXT="PD">
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_684912146" MODIFIED="1416907268919" TEXT="get (many APIs)"/>
<node CREATED="1416846859391" ID="ID_896665656" MODIFIED="1416907274659" TEXT="set (many APIs)"/>
<node CREATED="1416847230876" ID="ID_138635514" MODIFIED="1416847594390" TEXT="trace (fast diagnosis)"/>
<node CREATED="1416847565025" ID="ID_181890517" MODIFIED="1416907171167" STYLE="fork" TEXT="dump (EEPROM, flash, RAM)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1416499594606" FOLDED="true" ID="ID_1254220216" MODIFIED="1417094070410" TEXT="CD">
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_1034651328" MODIFIED="1416846929459" TEXT="get"/>
<node CREATED="1416846859391" ID="ID_1616729483" MODIFIED="1416907551597" TEXT="send request (get or set, project specific)"/>
</node>
</node>
<node CREATED="1416847474914" ID="ID_201155180" MODIFIED="1418894288033" TEXT="bus signals">
<node CREATED="1416499574430" ID="ID_773981442" MODIFIED="1421932776982" TEXT="CAN comm">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Current functional layer: LIFT_can_access.pm
    </p>
    <p>
      Required functions from LIFT_CANoe.pm and LIFT_CANoeCtrl.pm need to be included. Note: LIFT_CANoeCtrl.pm is currently not used by anybody, only LIFT_CREIS.pm intends to use it.
    </p>
    <p>
      Separate start trace from start rest bus simulation.
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="idea"/>
<icon BUILTIN="yes"/>
<node CREATED="1416846881271" ID="ID_918128961" MODIFIED="1416846929459" TEXT="get"/>
<node CREATED="1416846859391" ID="ID_1122170171" MODIFIED="1416846933749" TEXT="set"/>
<node CREATED="1416847230876" ID="ID_1864907073" MODIFIED="1416847233331" TEXT="trace"/>
<node CREATED="1416847244215" ID="ID_1044899854" MODIFIED="1416847253570" TEXT="stimulate (rest bus simulation)"/>
</node>
<node CREATED="1416492765767" FOLDED="true" ID="ID_1063308691" MODIFIED="1416994036684" TEXT="LIN">
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_331982329" MODIFIED="1416846929459" TEXT="get"/>
<node CREATED="1416846859391" ID="ID_1585141804" MODIFIED="1416846933749" TEXT="set"/>
<node CREATED="1416847230876" ID="ID_1601308042" MODIFIED="1416847233331" TEXT="trace"/>
<node CREATED="1416847244215" ID="ID_75009069" MODIFIED="1416847253570" TEXT="stimulate (rest bus simulation)"/>
</node>
<node CREATED="1416492751479" FOLDED="true" ID="ID_89139979" MODIFIED="1416994038229" TEXT="flexray">
<icon BUILTIN="idea"/>
<node CREATED="1416846881271" ID="ID_1690859092" MODIFIED="1416846929459" TEXT="get"/>
<node CREATED="1416846859391" ID="ID_1754308682" MODIFIED="1416846933749" TEXT="set"/>
<node CREATED="1416847230876" ID="ID_1912845718" MODIFIED="1416847233331" TEXT="trace"/>
<node CREATED="1416847244215" ID="ID_162369989" MODIFIED="1416847253570" TEXT="stimulate (rest bus simulation)"/>
</node>
</node>
</node>
<node CREATED="1416493282328" ID="ID_1343970327" MODIFIED="1418894314019" TEXT="SPI">
<node CREATED="1416493296858" ID="ID_1359825331" MODIFIED="1421932785843" TEXT="internal sensors (Quate, Idefix)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      is it reasonable to combine quate and idefix?
    </p>
    <p>
      LIFT_sensor_simulation
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="yes"/>
<node CREATED="1416993366449" ID="ID_672500034" MODIFIED="1416993367605" TEXT="get"/>
<node CREATED="1416993318205" ID="ID_854751842" MODIFIED="1416993319923" TEXT="set"/>
<node CREATED="1416993104398" ID="ID_388480836" MODIFIED="1416993126936" TEXT="stimulate (injection)"/>
<node CREATED="1416993271241" ID="ID_32572886" MODIFIED="1416993273630" TEXT="trace"/>
</node>
<node CREATED="1416493953588" ID="ID_715072778" MODIFIED="1417002495433" TEXT="generic (ManiToo)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ManiToo functionality should be split over several function layers.
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
<node CREATED="1416995625470" FOLDED="true" ID="ID_142196568" MODIFIED="1418656820749" POSITION="right" TEXT="used Symbols">
<node CREATED="1416995637193" ID="ID_753052490" MODIFIED="1416999221880" TEXT="existing functional layer">
<icon BUILTIN="idea"/>
</node>
<node CREATED="1416999226108" ID="ID_267430659" MODIFIED="1417002366434" TEXT="new functional layer or modificaton necessary">
<icon BUILTIN="yes"/>
</node>
<node CREATED="1417002377342" ID="ID_1546863307" MODIFIED="1417002426093" TEXT="special case: to be included in various functional layers">
<icon BUILTIN="messagebox_warning"/>
</node>
<node CREATED="1417002429141" ID="ID_699997203" MODIFIED="1417002437098" TEXT="comment exists">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1417106648771" ID="ID_403798871" MODIFIED="1417106708099" TEXT="question if module/layer shall exist">
<icon BUILTIN="help"/>
</node>
<node CREATED="1417106711558" ID="ID_1352827862" MODIFIED="1417106758464" TEXT="to be deleted or wrong">
<icon BUILTIN="button_cancel"/>
</node>
<node CREATED="1417106764819" ID="ID_275988141" MODIFIED="1417106784942" TEXT="already covered/working">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1417106597854" ID="ID_868352999" MODIFIED="1421937816126" POSITION="left" TEXT="Configuration of functions and devices">
<node CREATED="1417110179456" FOLDED="true" ID="ID_1036271052" MODIFIED="1418736478886" TEXT="requirements">
<node CREATED="1417110185864" FOLDED="true" ID="ID_846440245" MODIFIED="1417446730478" TEXT="which devices are present on my test bench">
<node CREATED="1417428115843" ID="ID_1410183653" MODIFIED="1417428137778" TEXT="defined in Device section of testbench config"/>
</node>
<node CREATED="1417110301934" FOLDED="true" ID="ID_1718230978" MODIFIED="1417446730478" TEXT="which project specific settings do I need for my devices and functions">
<node CREATED="1417428115843" ID="ID_821029774" MODIFIED="1417428137778" TEXT="defined in Device section of testbench config"/>
</node>
<node CREATED="1417110236240" FOLDED="true" ID="ID_352439531" MODIFIED="1417446730478" TEXT="which functions do I need for my test list">
<node CREATED="1417428198300" ID="ID_1472428758" MODIFIED="1417428225818" TEXT="defined in init campaign"/>
</node>
</node>
<node CREATED="1417110164141" ID="ID_1623232978" MODIFIED="1418895406015" TEXT="possibilities for config of functions">
<node CREATED="1417107968291" ID="ID_601950570" MODIFIED="1421937819846" TEXT="manually in init campaign">
<node CREATED="1417106808576" ID="ID_1828626632" MODIFIED="1421937826466" TEXT="configure each device separately (current situation)">
<node CREATED="1417110656589" ID="ID_1634164382" MODIFIED="1417110670176" TEXT="works currently">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417110671580" ID="ID_716828467" MODIFIED="1417110692239" TEXT="not compatible to functional layers">
<icon BUILTIN="smily_bad"/>
</node>
</node>
<node CREATED="1417106841630" ID="ID_1087663610" MODIFIED="1421937829866" TEXT="configure each sub-function of a functional layer">
<node CREATED="1417110435403" ID="ID_410881481" MODIFIED="1417110549257" TEXT="only needed functions will be configured">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417110463489" ID="ID_1421083048" MODIFIED="1417110597997" TEXT="many config calls required, possibly error prone">
<icon BUILTIN="smily_bad"/>
</node>
</node>
<node CREATED="1417107411998" ID="ID_162767464" MODIFIED="1421937831722" TEXT="configure each function layer">
<node CREATED="1417110030433" ID="ID_549498239" MODIFIED="1417110041540" TEXT="only few configuratons">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417110015668" ID="ID_1743411067" MODIFIED="1417110023591" TEXT="unnecessary functions may be configured">
<icon BUILTIN="smily_bad"/>
</node>
</node>
</node>
<node CREATED="1417109132860" ID="ID_1173512275" MODIFIED="1421937821187" TEXT="in test bench config">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      like Equip_main_init() in STEPS:
    </p>
  </body>
</html></richcontent>
<node CREATED="1417427494822" ID="ID_1405440272" MODIFIED="1421937832853" TEXT="as it is now">
<node CREATED="1417109359468" ID="ID_914958801" MODIFIED="1417109427771" TEXT="only one call in init campaign">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417109397022" ID="ID_1006473386" MODIFIED="1417109756353">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      unnecessary functions may be configured or
    </p>
    <p>
      several testbench configs necessary
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="smily_bad"/>
</node>
</node>
<node CREATED="1417427509805" ID="ID_1686585181" MODIFIED="1421937834098" TEXT="with several &quot;Functions&quot; sections">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Idea is to have several sections in the &quot;Functions&quot; part of testbench config, depending on the test type:
    </p>
    <p>
      'Functions' =&gt; {
    </p>
    <p>
      &#160;&#160;&#160;'standard' =&gt; ...
    </p>
    <p>
      &#160;&#160;&#160;'minimal' =&gt; ...
    </p>
    <p>
      &#160;&#160;&#160;'creis' =&gt; ...
    </p>
    <p>
      }
    </p>
    <p>
      The section name could be input parameter for Equip_main_init.
    </p>
  </body>
</html></richcontent>
<node CREATED="1417427979806" ID="ID_1739604504" MODIFIED="1417428010257" TEXT="easy configuration of several test types">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417428012075" ID="ID_244158674" MODIFIED="1417428031824" TEXT="testbench config becomes more complicated">
<icon BUILTIN="smily_bad"/>
</node>
</node>
</node>
<node CREATED="1417107983434" ID="ID_290078302" MODIFIED="1421937822178" TEXT="automatically by engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      let LIFT engine find out which functions are used in a test case by running the test case in offline mode
    </p>
    <p>
      then configure only those functions that are used in the test case
    </p>
  </body>
</html></richcontent>
<node CREATED="1417109502305" ID="ID_461936915" MODIFIED="1417109545087" TEXT="no manual configuration necessary">
<icon BUILTIN="ksmiletris"/>
</node>
<node CREATED="1417109547859" ID="ID_494962382" MODIFIED="1417109676371" TEXT="takes time">
<icon BUILTIN="smily_bad"/>
</node>
</node>
</node>
</node>
</node>
</map>
