use strict;
use Graphviz::DSL;

# open functional layer csv file
my $fileName = 'FunctionalLayerArchitecture.csv';
open( IN, '<', $fileName ) or die "cannot open input file $fileName : $!";
my @lines = <IN>;
close IN;

my %architecture;
my ( @devices, @functions, @apis, $graph, $graphName );

# loop over all lines of csv file
foreach my $line (@lines) {
    my @items = split( /;/, $line );

    # a line starting with 'FuncLib' is a header line containing the device names
    if ( $items[0] =~ /(FuncLib|Functional module)/i ) {
        @devices = ();
        splice( @items, 0, 4 );
        # extract device names until 'comment' or end
        foreach my $item (@items) {
            last if ( $item =~ /comment/i or $item eq '' );
            push( @devices, $item );
        }
        next;
    }

    # ignore empty lines
    next if $items[0] eq '';

    # get funcLib, function and api from the line
    my $funcLib  = $items[0];
    my $function = $items[1];
    my $api      = $items[2];

    # get deviceAPI for each device and sort everything into %architecture
    splice( @items, 0, 4 );
    foreach my $device (@devices) {
        my $deviceAPI = shift @items;
        $architecture{$funcLib}{$function}{$device}{$api} = $deviceAPI;
    }

}


# create output files from %architecture:
# loop over all funcLibs
foreach my $lfuncLib ( sort keys %architecture ) {
    # get a list of all functions in the funcLib
    @functions = ();
    foreach my $lfunction ( sort keys %{ $architecture{$lfuncLib} } ) {
        push( @functions, $lfunction );
    }

    # create a graph with all apis of all functions of a funcLib
    $graphName = $lfuncLib;
    $graph     = graph {
        name $graphName;
        edges arrowhead => 'onormal', color       => 'magenta4';
        global center   => 'true',    outputorder => 'nodefirst';

        subgraph {
            global label => 'Functional_Layer';
            foreach my $lfunction ( @functions ) {
                route( $lfuncLib, $lfunction );
                my @ldevices = sort keys %{ $architecture{$lfuncLib}{$lfunction} };
                foreach my $lapi ( sort keys %{ $architecture{$lfuncLib}{$lfunction}{ $ldevices[0] } } ) {
                    route( $lfunction, $lapi );
                }
            }
        };
    };
    $graph->save( path => $graphName, type => 'png', encoding => 'utf-8' );

    # loop over all functions
    foreach my $lfunction ( @functions ) {
        my @ldevices = sort keys %{ $architecture{$lfuncLib}{$lfunction} };

        # get a list of all apis of a function
        @apis = ();
        foreach my $lapi ( sort keys %{ $architecture{$lfuncLib}{$lfunction}{ $ldevices[0] } } ) {
            push( @apis, $lapi );
        }
        
        # loop over all devices of the function
        foreach my $ldevice ( sort keys %{ $architecture{$lfuncLib}{$lfunction} } ) {

            # create a graph for all apis of each function and each device
            $graphName = $lfuncLib . '_' . $lfunction . '_' . $ldevice;
            $graph     = graph {
                name $graphName;
                edges arrowhead => 'onormal', color       => 'magenta4';
                global center   => 'true',    outputorder => 'nodefirst';

                subgraph {
                    global label => 'Functional_Layer';
                    foreach my $lfunction (@functions) {
                        route( $lfuncLib, $lfunction );
                    }
                    foreach my $lapi (@apis) {
                        route( $lfunction, $lapi );
                    }
                };

                subgraph {
                    global label => 'Device_Layer';
                    subgraph {
                        global label => $ldevice;
                        foreach my $lapi ( sort keys %{ $architecture{$lfuncLib}{$lfunction}{$ldevice} } ) {
                            my $ldeviceAPI = $architecture{$lfuncLib}{$lfunction}{$ldevice}{$lapi};
                            route( $lapi, $ldeviceAPI );
                        }
                    };

                };

            };

            $graph->save( path => $graphName, type => 'png', encoding => 'utf-8' );

        }
    }
}

print "READY.\n";

