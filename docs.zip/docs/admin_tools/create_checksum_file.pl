# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: docs/admin_tools/create_checksum_file.pl $
#    $Revision: 1.3 $
#    $State: develop $
#******************************************************************************************************

use strict;
use warnings;
use Getopt::Long;
use Digest::MD5;
use File::Basename;
use File::Find;
use Pod::Usage;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.3 $;
$HEADER  = q$Header: docs/admin_tools/create_checksum_file.pl 1.3 2019/08/07 17:10:33CEST Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

=head1 NAME

create_checksum_file $Revision: 1.3 $

=head1 SYNOPSIS

create_checksum_file [Options]

 E.g. 
 create_checksum_file.pl --version 1.60
 create_checksum_file.pl -v 6.0 -c CREIS -p ../../../Engine/modules/TC_FunctionLib/CREIS_Framework -a ..\FuncLib_CREIS_Framework.pm -r "TurboLIFT_Engine >= 1.60"

 Options:
   --help|-?                          display tool documentation
   --version|-v <version-number>      define component version (mandatory argument!)
   --path|-p <path>                   define checksum file path
   --component|-c <component-name>    define component name
   --extensions|-x <extension>        define file-extensions for which checksums are calculated
   --excludeFolders|-f <folder-name>  define folders to be excluded from checksum calculation
   --additionalFiles|-a <file-name>   define additional files to be included for checksum calculation
   --requires|-r <r-component-info>   define a required component

=head1 OPTIONS

=over

=item --help|-?

Displays the tool documentation

=item --version|-v <version-number>

Defines the version-number of the component for which the checksum file is created.
The version-number may only contain one '.', e.g. 1.1 .
This Option has to be given by the user.

=item --path|-p <path>

Defines the path where the checksum file will be generated and where the files for which checksums are calculated will be searched.
Default value is: ../../../Engine.

=item --component|-c <component-name>

Defines the name of the component for which the checksum file will be generated.
Default value is: TurboLIFT_Engine.

=item --extensions|-x <extension>

Defines the file-extensions of the files for which checksums will be calculated.
This option can be given multiple times to specify more than one extension.
Default values are: pl pm dll.

=item --excludeFolders|-f <folder-name>

Defines sub-folders in the given path that will be excluded from the search for files for checksum calculation.
This option can be given multiple times to specify more than one exclude folder.
Default values are: Documentation test.

=item --additionalFiles|-a <file-name>

Defines optionally additional files that will be included for checksum calculation.
The file names must be given relative to <path>. 
This option can be given multiple times to specify more than one additional file.
There are no default values for this option.

=item --requires|-r <r-component-info>

Defines an optional required component for <component-name>.
<r-component-info> must be of the form: "<r-component-name> >= <r-version-number>",
e.g. "TurboLIFT_Engine >= 1.60".
There is no default value for this option.

=back

=head1 DESCRIPTION

This tool creates a TurboLIFT checksum file in <path> with the name 'LIFT_checksums.md5'.
It searches in <path> and all sub-folders (except in the sub-folders given by option --excludeFolders) for all files
with the extensions given by option --extensions and calculates the MD5 checksums of the files.
Additionally it calculates the MD5 checksums of the files given by option --additionalFiles.
The checksums and file names are written to the checksum file.
Finally the tool calculates the MD5 checksum of the checksum file itself and adds that checksum also to the checksum file.

=cut

#STEP set default values for options: path, component, exclude folders, extensions
my $givenPath      = '../../../Engine';
my $component      = 'TurboLIFT_Engine';
my @excludeFolders = qw(Documentation test);
my @extensions     = qw(pl pm dll);
my $help           = 0;
my ( $version, @excludeFoldersGiven, @extensionsGiven, @additionalFiles, $requires );

#STEP get given command line options
GetOptions( "help|?" => \$help, "version=s" => \$version, "path=s" => \$givenPath, "component=s" => \$component, "excludeFolders|f=s" => \@excludeFoldersGiven, "extensions|x=s" => \@extensionsGiven, "additionalFiles=s" => \@additionalFiles, "requires=s" => \$requires ) or pod2usage( -verbose => 0 );
pod2usage( -verbose => 2 ) if $help;

@excludeFolders = @excludeFoldersGiven if @excludeFoldersGiven > 0;
@extensions     = @extensionsGiven     if @extensionsGiven > 0;

#STEP throw error and exit if version is not given as argument
if ( not defined $version ) {
    pod2usage("Option '--version' or '-v' must be given.\n");
}

my $addFilesText = '';
$addFilesText = "and additional files '@additionalFiles'" if @additionalFiles > 0;
my $requiresText = '';
$requiresText = "and required component '$requires'" if defined $requires;
print "\nGenerating checksums for files with extensions '@extensions' in directory '$givenPath' excluding sub-directories '@excludeFolders' $addFilesText for component '$component' with version '$version' $requiresText...\n\n";

#STEP create header of checksum file
my $scriptName   = basename($0);
my $datestring   = localtime();
my $checksumList = "# MD5 checksums generated by $scriptName at $datestring\n";
$checksumList .= "Component: $component\n";
$checksumList .= "Version: $version\n";
$checksumList .= "Requires: $requires\n" if defined $requires;
$checksumList .= "\n";

#LOOP-START find all files in path
#CALL Wanted
find( \&Wanted, $givenPath );

#LOOP-END last file?

#LOOP-START loop over all given additional files
foreach my $additionalFile (@additionalFiles) {

    #CALL CalculateChecksum
    my $addFilepath = $givenPath . '/' . $additionalFile;
    CalculateChecksum( $addFilepath, $additionalFile );
}

#LOOP-END last file?

#STEP write contents to checksum file
my $filename = $givenPath . "/LIFT_checksums.md5";
print "Writing checksums to file '$filename'...\n";
open( my $outfh, '>', $filename ) or die "Can't open '$filename': $!";
print $outfh $checksumList;
close $outfh;

#STEP read checksum file and calculate the checksum for the checksum file
open( my $fh, '<', $filename ) or die "Can't open '$filename': $!";
binmode($fh);
my $checksumFileChecksum = uc( Digest::MD5->new->addfile($fh)->hexdigest );
close $fh;

#STEP append calculated checksum to the checksum file
print "Writing final checksum...\n";
open( $outfh, '>>', $filename ) or die "Can't open '$filename': $!";
print $outfh "\n$checksumFileChecksum";
close $outfh;

print "READY.\n";

#END end

sub Wanted {
    my $file = $_;
    my $path = $File::Find::name;

    #STEP return if file path contains one of the exclude folders
    if ( grep { $path =~ /\/$_\// } @excludeFolders ) {
        return;
    }

    #STEP get file extension
    my $extension;
    if ( $file =~ /\.(\w+)$/ ) {
        $extension = lc($1);
    }
    else {
        return;
    }

    #STEP return if file extension is not one of the given extensions
    if ( not grep { $extension eq $_ } @extensions ) {
        return;
    }

    #STEP get file path relative to given path
    my $pathRelEngine = substr( $path, length($givenPath) + 1 );
    $pathRelEngine =~ s|\/|\\|g;    # replace all / with \

    #CALL CalculateChecksum
    CalculateChecksum( $file, $pathRelEngine );

    #END return 1
    return 1;
}

sub CalculateChecksum {
    my $file          = shift;
    my $pathRelEngine = shift;

    #STEP check for forbidden MKS keywords
    CheckMKS_keywords($file);

    #STEP read file and calculate checksum
    open( my $fh, '<', $file ) or die "Can't open '$file': $!";
    binmode($fh);
    my $md5Checksum = uc( Digest::MD5->new->addfile($fh)->hexdigest );
    close $fh;

    #STEP add checksum and relative file path to checksum list
    #print ("$relativePath has MD5 checksum $md5Checksum\n");
    $checksumList .= "$md5Checksum *$pathRelEngine\n";

    #END return 1
    return 1;
}

sub CheckMKS_keywords{
    my $filepath = shift;

    return 1 if $filepath =~ /\.dll$/;

    my @keywords = qw(Source Revision State Header);

    open my $fh_in, $filepath or die "Could not open $filepath: $!";
    
    my @fileLines;
    my $fileChanged = 0;
    while( my $line = <$fh_in>)  {
        my $deleteLine = 0;
        foreach my $keyword ( @keywords ) {
            if( $line =~ /^\s*#.*\$$keyword:.+\$/ or $line =~ /^\s*(?:my|our)?\s*\$VERSION\s*=.*\$$keyword:.+\$/i or $line =~ /^\s*(?:my|our)?\s*\$HEADER\s*=.*\$$keyword:.+\$/i) {
                $deleteLine = 1;
                last;
            }
        }
        if( not $deleteLine ) {
            foreach my $keyword ( @keywords ) {
                if($line =~ /\$$keyword:.+\$/){
                    $line =~ s/\$$keyword:.+\$//g;
                    $fileChanged = 1;
                }
            }
            push(@fileLines, $line);
        }
        else{
            $fileChanged = 1;
        }
    }
    
    close $fh_in;    


    if( $fileChanged ) {
        print("ERROR: MKS keywords found in $filepath\n");
        $filepath .= '.new';
        open my $fh_out, '>', $filepath or die "Could not write $filepath: $!";
    
        foreach my $line ( @fileLines ) {
            print $fh_out $line;
        }
        close $fh_out;
    }

    return 1;
}

1;
