#!usr\bin\perl

use strict;
use warnings;
#use Getopt::Long;
use File::Path qw(make_path);
use File::Basename;

open(LOG,">engine_member_revisions.txt") or die "could not open file: $! ";

my $cmd='si viewproject -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj -R';
my @members = MKS_command($cmd);
foreach my $member (@members){
    print LOG "$member";
    my $archiveFound = $member =~ /^\s*(\S+)\s+archived\s+(\S+)/;
    my $file = $1;
    next if not $archiveFound;

    $cmd='si viewhistory --fields=revision,date,author,description -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj '.$file;
    my @history = MKS_command($cmd);
    
    my $historyFile = "history/$file"."_history.txt";
    my $historyDir = dirname($historyFile);
    make_path($historyDir) if not -d $historyDir;
    open(HIST,">$historyFile") or die "could not open file $historyFile: $! ";
    print HIST "@history\n";
    close(HIST);
}
close(LOG);
print "\n\n'engine_member_revisions.txt' has been written in the current directory.\n";
print "The MKS history for each member has been written in the directory 'history'.\n";
print "READY.\n";


###################
### subroutines ###
###################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    
    return @ret;

}