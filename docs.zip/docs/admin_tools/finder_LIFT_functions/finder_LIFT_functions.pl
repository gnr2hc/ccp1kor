=head1 NAME
finder_LIFT_functions.pl - create statistics about usage of TurboLIFT functions

=head1 SYNOPSIS

finder_LIFT_functions.pl

=head1 VERSION

$Revision: 1.2 $

=head1 DESCRIPTION

finder_LIFT_functions.pl searches all test case files and module files in the given folder (in $searchPath) and all sub-folders. 
For each test case and module file the script searches all function calls and tries to identify TurboLIFT functions.
The tool can also be limited to search only in test case files. To do this uncomment line 50 and comment line 48.
The TurboLIFT function calls are counted and a statistics file (LIFT_functions_overview.csv) is written 
which lists all TurboLIFT functions sorted by the number of calls.
Additionally a detailed statistics file (LIFT_functions.txt) is written that dumps all collected data:
Which function is called how many times in which test case file and which test case file is found in which path.

=cut

use strict;
use File::Find;
use Data::Dumper;
use POSIX qw/strftime/;

my $searchPath = 'C:\Users\phc2si\Documents\LIFT_all_projects';


my @perlKeywords = qw( if elsif my our for while foreach time until chop unless push when substr split shift uc pop sprintf hex join given open close pack close open pack keys scalar abs int lc floor print map return unshift length chomp system defined sqrt undef qw);
my ($result_href, $files_href);
my $hitcount = 0;

sub FindInFile {
	my $fileName = $File::Find::name;
	my $shortFileName;
	if( $fileName =~ /\/(\w+\.\w+)$/ ){
		$shortFileName = $1;
	}
	else{
		$shortFileName = 'unknown';
	}
	
    # with the following line activated the tool searches test case files and in module files
	return unless( $fileName =~ /\.pm$/ and ($fileName =~ /\/TCs\//i or $fileName =~ /\/modules\//i or $fileName =~ /\/config\//i) and $fileName !~ /RB_DCOM/i and $fileName !~ /playground/i and $fileName !~ /ProjectConst/i and $fileName !~ /mapping/i);
    # with the following line activated the tool searches only in test case files
	#return unless( $fileName =~ /\.pm$/ and $fileName =~ /\/TCs\//i and $fileName !~ /RB_DCOM/i and $fileName !~ /FuncLib_TNT/i and $fileName !~ /playground/i and $fileName !~ /\/config\//i and $fileName !~ /ProjectConst/i);

	if( defined $files_href->{$shortFileName} ){
		$files_href->{$shortFileName}{$fileName} = 2;
		return;
	}

	$files_href->{$shortFileName}{$fileName} = 1;
	
    print("searching in $fileName...\n");

	open( IN, '<', $fileName) or die "cannot open input file $fileName : $!";
	my @lines = <IN>;
	close IN;
	
	my $lineNr = 0;
	my $pod = 0;
	foreach my $line (@lines){
		$lineNr++;
		next if( $line =~ /^\s*#/ );
		next if( $line =~ /our\s+\$HEADER/ );
		next if( $line =~ /our\s+\$PURPOSE/ );
		if( $line =~ /^\s*=head/ ){
			$pod = 1;
		}
		if( $line =~ /^\s*=cut/ ){
			$pod = 0;
		}
		next if $pod;
		
		if( $line =~ /(\S+)\s*\(/ ){  # find all lines with xxxxx (
			my $function = $1;
			next if ( $function !~ /^\w+$/ );
			next if ( grep { $function =~ /^$_$/ } @perlKeywords );
			
			$result_href->{$function}{$shortFileName}{'hitcount'}++;
			$result_href->{$function}{'hitcount'}++;
			if( $function =~ /^([a-zA-Z0-9]+)_/ ){
				$result_href->{$function}{'prefix'} = $1;
			}
			else{
				$result_href->{$function}{'prefix'} = 'none';
			}
		}
		
	}
		
}

find(\&FindInFile, ($searchPath) );

my $testCaseCount = keys %{$files_href};

open( OUT, ">LIFT_functions_overview.csv"  ) or die $!;
print OUT strftime('%Y-%m-%d',localtime)."\n";
print OUT "test cases;$testCaseCount\n";
print OUT "name;hitcount;prefix\n";
foreach my $function (sort{$result_href->{$b}{'hitcount'} <=> $result_href->{$a}{'hitcount'}} keys %{$result_href}) {
	print OUT "$function;$result_href->{$function}{'hitcount'};$result_href->{$function}{'prefix'}\n";
}

close OUT;


$Data::Dumper::Indent = 1;
$Data::Dumper::Sortkeys = 1;

# dump data structures into a text file
open( VDUMP, ">LIFT_functions.txt"  ) or die $!;
print VDUMP Data::Dumper->Dump([$result_href, $files_href]);
close VDUMP;

my $runtime = time - $^T; print "This script took $runtime seconds\n";

print "READY.\n";
