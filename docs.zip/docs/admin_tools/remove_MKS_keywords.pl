use strict;
use warnings;
use File::Find;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.1 $;

my $workdir = 'C:\sandboxes\TurboLIFT_Bosch_Engine_development\PHC2SI\tools_TurboLIFT\Engine\funclib_generic';
my @keywords = qw(Source Revision State Author Date Header);
my $count = 0;

find( \&FindFiles, $workdir );

print "READY.\n";

sub FindFiles {
    my $fileName = $_;
    return if -d $fileName;
    return if $fileName =~ /\.(dll|exe)$/i;

    #return if $fileName ne 'LIFT_TOELLNER.pm';

    my $filepath = $File::Find::name;
    print "$filepath\n";

    open my $fh_in, $filepath or die "Could not open $filepath: $!";
    
    my @fileLines;
    while( my $line = <$fh_in>)  {
        my $deleteLine = 0;
        foreach my $keyword ( @keywords ) {
            if( $line =~ /^\s*#.*\$$keyword:.+\$/ or $line =~ /^\s*(?:my|our)?\s*\$VERSION\s*=.*\$$keyword:.+\$/i) {
                $deleteLine = 1;
                last;
            }
        }
        if( not $deleteLine ) {
            foreach my $keyword ( @keywords ) {
                $line =~ s/\$$keyword:.+\$//g;
            }
            push(@fileLines, $line);
        }
    }
    
    close $fh_in;    

    unlink $filepath or die "Could not delete $filepath: $!";

    open my $fh_out, '>', $filepath or die "Could not write $filepath: $!";

    foreach my $line ( @fileLines ) {
        print $fh_out $line;
    }
    close $fh_out;
    
}


1;
