#!usr\bin\perl

use strict;
use warnings;
use File::Spec;
use File::Basename;
use Getopt::Long;
use Win32::OLE;
use Win32::OLE::Const 'Microsoft Excel'; 

#no strict 'refs';

use constant MODULE_COLUMN  => 1;
use constant CHANGES_COLUMN  => 2;
use constant STATUS_COLUMN  => 3;

my $project_name = '';
my $filename = "";

if($ARGV[0] =~ /engine/i) {
    $project_name = 'G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj';
    $filename = "CP_Engine_status.xlsx";
} elsif($ARGV[0] =~ /dlls/i) {
    $project_name = 'G:\MKS\Projects\TurboLIFT\System\Engine\modules\DLLs\DLLs.pj';
    $filename = "CP_DLLs_status.xlsx";
} else {
    print "the commandline option shall be either 'Engine' or 'DLLs'";
    system('pause');
    exit(0);
}

# Get current directory using Cwd.pm
my $dir = dirname(__FILE__);
my $excelfile = $dir . "/$filename";
#$excelfile =~ s/\\/\\\\/ig;
$excelfile =~ s/\//\\/ig;

my $application = Win32::OLE->new("Excel.Application");


my $workbook    = $application->Workbooks->Add;
my $worksheet   = $workbook->Worksheets(1);

$workbook->SaveAs($excelfile);

$application->{'DisplayAlerts'} = "False";
$application->{'Visible'} = "True";

my ($change,@differences,@changes,$cmd,@revisions,$opt_rev);


#compare current working project to last checkpoint
GetOptions(
             "rev=s" => \$opt_rev,    # checkpoint to compare with
);

open(LOG,">CP_changes.txt") or die "could not open file: $! ";

if (defined $opt_rev){
	print LOG "comparing working project with checkpoint $opt_rev\n\n";
	$opt_rev=" -r ".$opt_rev;
}
else{
	$opt_rev='';
	print LOG "comparing working project with last checkpoint\n\n";
	
}
$cmd='si mods -P '. $project_name . $opt_rev .' -R';
@differences = MKS_command($cmd);

#system('pause');

#check if no modules are locked
$cmd='si rlog --noHeaderFormat --noTrailerFormat --format="{lockrecord}\n" --lockRecordFormat="{member} {revision} by {locker} on {hostname}" --rfilter=locked -P ' . $project_name . ' -R';
my @locked = MKS_command($cmd);
if ( scalar(@locked) > 0 )
{
    print LOG "!!! detected locked module(s):\n\n";
    print LOG " @locked \n----------------------------------------------------\n\n";
    $worksheet->Cells(1,MODULE_COLUMN)->{Value} = "@locked";    
}
  
my $rowindex = 4;

$worksheet->Cells($rowindex,MODULE_COLUMN)->{Value} = "Modules";
# Add some formatting
$worksheet->Cells($rowindex,MODULE_COLUMN)->Font->{Bold}       = "True";
$worksheet->Cells($rowindex,MODULE_COLUMN)->Font->{Size}       = 16;
$worksheet->Cells($rowindex,MODULE_COLUMN)->Font->{ColorIndex} =5;
$worksheet->Columns("A:C")->{ColumnWidth}  = 25;

$worksheet->Cells($rowindex,CHANGES_COLUMN)->{Value} = "Changes";
# Add some formatting
$worksheet->Cells($rowindex,CHANGES_COLUMN)->Font->{Bold}       = "True";
$worksheet->Cells($rowindex,CHANGES_COLUMN)->Font->{Size}       = 16;
$worksheet->Cells($rowindex,CHANGES_COLUMN)->Font->{ColorIndex} = 5;

$worksheet->Cells($rowindex,STATUS_COLUMN)->{Value} = "Status";
# Add some formatting
$worksheet->Cells($rowindex,STATUS_COLUMN)->Font->{Bold}       = "True";
$worksheet->Cells($rowindex,STATUS_COLUMN)->Font->{Size}       = 16;
$worksheet->Cells($rowindex,STATUS_COLUMN)->Font->{ColorIndex} = 5;

$rowindex++;
my $initRow = $rowindex;

print $excelfile;

foreach $change (@differences){
    print LOG "#".$change;

    #check for e.g. "Member revision changed: LIFT_exec_engine.pl from 2.6 to 2.11"
    if ($change =~ /^Member revision changed: (\S+) from (\S+)/){
        my $file = $1;
        my $oldrev = $2;

        # place the module name
        $worksheet->Cells($rowindex, MODULE_COLUMN)->{Value} = $file;
        $worksheet->Cells(1,MODULE_COLUMN)->Font->{Bold}       = "True";
        
        #get next version number (element n-1 from query)
        $cmd='si rlog --noHeaderFormat --noTrailerFormat --format="{revision}\n" --rfilter=range:'.$oldrev.'- -P ' . $project_name . ' '. $file;
        @revisions =  MKS_command($cmd);
        my $firstnewrev=$revisions[-2]; # this version contains the first change description
        chomp($firstnewrev); #cutt of newline

        #get accumulated revision descriptions from selected version till latest version
        $cmd='si viewhistory --fields=description --rfilter=range:'.$firstnewrev.'- -P ' . $project_name . ' '. $file;
        @changes=  MKS_command($cmd);
        shift(@changes);
        print LOG " @changes";
        
        # log the changes
        $worksheet->Cells($rowindex, CHANGES_COLUMN)->{Value} = " @changes";
        
        $rowindex++;
   
    }
}
close(LOG);

$worksheet->Range("A:C")->{HorizontalAlignment} = xlHAlignLeft;
$worksheet->Range("A:C")->{VerticalAlignment} = xlHAlignCenter;

$workbook->Save();
$workbook->Close();
$application->Close();
###################
### subroutines ###
###################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    
    return @ret;

}
=cut