use strict;
use warnings;
use Getopt::Long;
use File::Find;
use File::Checksum;
use File::Copy;
use File::Path qw( make_path );
use IO::Tee;
use POSIX;

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.2 $;
$HEADER  = q$Header: docs/admin_tools/updateDesignsInMKS.pl 1.2 2018/11/07 14:12:09CET Prosch Christian (CC-PS/EPS2) (PHC2SI) develop  $;

my $newdir = 'C:\Users\phc2si\Documents\TurboLIFT\Tools\FlowChart-Markup-Language';
my $olddir = 'C:\Users\phc2si\Documents\TurboLIFT\System\develop\docs\Engine_Function_Design';
my $mksProject = 'C:\Users\phc2si\Documents\TurboLIFT\System\develop\develop.pj';
my $ciComment = 'Updated for new checkpoint';

my $action;
GetOptions ('action' => \$action);

my $dateTime = strftime("%Y-%m-%d_%H-%M-%S", localtime);
open my $log, '>', "updateDesignsInMKS_$dateTime.log" or die "Can't write logfile: $!";
my $tee = new IO::Tee(\*STDOUT, $log);

print $tee "######## updateDesignsInMKS $VERSION started at $dateTime\n";
print $tee "MKS project: $mksProject\n";
print $tee "MKS sandbox folder: $olddir\n";
print $tee "New designs folder: $newdir\n";

if( $action ) {
    print $tee "Option -a (--action) selected: files will be copied and MKS actions will be done!\n\n";
}
else{
    print $tee "Option -a (--action) not selected: nothing will be changed on file system and in MKS.\n\n";
}

my $dir2Filehref;
our $folder;
sub FindFiles {
    my $fileName = $_;
    return if $fileName !~ /\.(svg|dot)$/i; # include only .svg and .dot files
    if ( -f $fileName ) {
        my $filepath = $File::Find::name;
        return if $filepath =~ m|/examples/|; # exclude example files from Flowchart markup tool
        $dir2Filehref->{$folder}{$fileName} = $filepath;
    }
}

#find all files present, and store in a hash dir => filefullpath
foreach $folder ( $newdir, $olddir ) {
    find( \&FindFiles, $folder );
}

#check if any new files are added in new directory
my @newfilesAdded = grep { !exists $dir2Filehref->{$olddir}{$_} } keys %{ $dir2Filehref->{$newdir} };
print $tee "######## Files to be added:\n";

# Add to MKS using si command
foreach my $fileName ( @newfilesAdded ) {
    my $destinationFile = CopyToSandbox( $fileName );
    MKS_command( 'si add --description="initial" -S '.$mksProject.' '.$destinationFile );
}

#check if any files to be deleted
my @filestodelete = grep { !exists $dir2Filehref->{$newdir}{$_} } keys %{ $dir2Filehref->{$olddir} };
print $tee "######## Files to be deleted:\n";

# Remove from MKS using si command
foreach my $fileName ( @filestodelete ) {
    my $deleteFile = $dir2Filehref->{$olddir}{$fileName};
    MKS_command( 'si drop --confirm --delete -S '.$mksProject.' '.$deleteFile );
}

#Check the remaining files if there is any update
my %hash;
@hash{@newfilesAdded} = ();
my @file2Check4update = grep { !exists $hash{$_} } ( keys %{ $dir2Filehref->{$newdir} } );
#my $updatedFilesArr;
print $tee "######## Files to be updated:\n";
foreach my $file (@file2Check4update) {
    my $newfilepath = $dir2Filehref->{$newdir}{$file};
    my $oldfilepath = $dir2Filehref->{$olddir}{$file};
    if ( Checksum( $newfilepath, 65537 ) == Checksum( $oldfilepath, 65537 ) ) {
        #print $tee "File $file didnt change since last checkpoint\n";
    }
    else {
        print $tee "    File $file changed\n";
        #push @$$updatedFilesArr, $file;
        # Checkin the updated MKS revision in MKS        
        my $destinationFile = CopyToSandbox( $file );
        MKS_command( 'si lock -S '.$mksProject.' '.$destinationFile );
        MKS_command( 'si ci --description="'.$ciComment.'" -S '.$mksProject.' '.$destinationFile );
    }
}

print $tee "READY.\n";
$tee->flush;






sub CopyToSandbox{
    my $fileName = shift;

    my $sourceFile = $dir2Filehref->{$newdir}{$fileName};
    my $subDirectory;
    if( $sourceFile =~ m|/(.+)/(.+)$| ) {
        $subDirectory = $1;
    }
    else{
        print $tee "    #### WARNING subdirectory not found\n";
        next;
    }

    my $destinationFolder = $olddir."/".$subDirectory;
    if( !-d $destinationFolder ) {
        print $tee "    Creating folder $destinationFolder ...\n";
        if( $action ) {
            make_path $destinationFolder or die "Failed to create path: $destinationFolder";
        }
    }

    my $destinationFile = $olddir."/".$subDirectory."/".$fileName;
    print $tee "    Copying $sourceFile to $destinationFile ...\n";
    if( $action ) {
        unlink $destinationFile;
        copy( $sourceFile, $destinationFile ) or die "Copy failed: $!";
    }
    
    return $destinationFile;
}


sub MKS_command{
    my $cmd = shift;
    my $ret;
    
    print $tee "    executing <$cmd>\n";
    $ret = `$cmd` if $action;
    
    return $ret;

}

1;
