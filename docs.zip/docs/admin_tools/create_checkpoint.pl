#
#  Copyright (c) 2014  RBEI
#                      India
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: docs/admin_tools/create_checkpoint.pl $
#    $Revision: 1.10 $
#    $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
#    $State: develop $
#    $Date: 2019/11/15 11:15:54CET $
#******************************************************************************************************

# create checkpoint
use Text::SimpleTable::AutoWidth;
use strict;
use warnings;
use HTML::Filter::Callbacks;
use File::Basename;
use Cwd 'abs_path';
use File::Spec;
use Readonly;
use Win32::Console::ANSI;
use Term::ANSIColor;

my $checkpointName = $ARGV[0];

# remove leading and trailing spaces
if ( defined $checkpointName ) {
    $checkpointName =~ s/^\s+//;
    $checkpointName =~ s/\s+$//;
}

my $FinalDocFolder = "";

Readonly my $thisfile_path     => abs_path( dirname(__FILE__) );
Readonly my $Engine_doc_path   => $thisfile_path . "/../../../Engine_SCM/Documentation/";
Readonly my $Engine_html_path  => $thisfile_path . "/../../../Engine_SCM/Documentation/html";
Readonly my $DestinationFolder => '\\\\bosch.com\dfsrb\DfsDE\STC\DIV\CC\PS_Websites\support_portal\testportal\common\LIFT\APIdocumentation/';
Readonly my $SystemSandbox     => $thisfile_path . "/../../../";
Readonly my $Project_name => 'G:\MKS\Projects\TurboLIFT\System\\';

print '    
Utility to create turboLIFT checkpoint $Revision: 1.10 $

';
#################################################################################
sub main() {

    # error if $checkpointName is not defined or empty
    unless ( defined $checkpointName && $checkpointName ne "" ) {
        help();
        
    } elsif ( $checkpointName =~ /help/i ) {
        help();
        
    } elsif ( $checkpointName =~ /getstatus-engine/i ) {
        my $sandbox_pj = $SystemSandbox . 'Engine_SCM/Engine_SCM.pj';
        my $MKSproject_pj = $Project_name . 'Engine_SCM\Engine_SCM.pj';
        get_status($sandbox_pj, $MKSproject_pj);
        
    } elsif ( $checkpointName =~ /getstatus-system/i ) {
        my $sandbox_pj = $SystemSandbox . 'System.pj';
        my $MKSproject_pj = $Project_name . 'System.pj';
        get_status($sandbox_pj, $MKSproject_pj);
        
    } elsif ( $checkpointName =~ /freeze/i ) {
        get_status();
    } elsif ( $checkpointName =~ /copytoolsdoc/i ) {
        # execute create_tools_docu.bat from TurboLIFT/Tools folder
        my $toolsDocFolder = "../../../../Tools/";
        $toolsDocFolder = abs_path("../../../../Tools/Documentation/");
        system("$toolsDocFolder/create_tools_docu.bat");
        
        # copy the tools documentation to checkpoint documentation folder
        my $checkpoint = $ARGV[1];

        my $FinalDocFolder = $DestinationFolder . "/$checkpoint/Tools";
        my $command = "robocopy \"$toolsDocFolder\" \"$FinalDocFolder\" /E /LOG:robocopy.log /TEE";        
        system($command);
    } else {

        # determine the final documentation folder
        $checkpointName =~ /(\w+)/i;
        my $extractedname = $1;

        unless ( defined $extractedname && $extractedname ne "" ) {
            help();
        } else {
            $FinalDocFolder = $DestinationFolder . $extractedname;
            process_documentation();
        }
    }
}

################################################################################

sub get_status {
    my $SystemSandboxpath = shift;
    my $Project_name = shift;
    

   open(LOG,">Checkpoint.LOG") or die "could not open file: $! ";
    
   # inform about the locked module
   my $cmd='si mods -P '. $Project_name . ' -R';
   my @differences = MKS_command($cmd);

    #check if no modules are locked
    $cmd='si rlog --noHeaderFormat --noTrailerFormat --format="{lockrecord}\n" --lockRecordFormat="{member} {revision} by {locker} on {hostname}" --rfilter=locked -P ' . $Project_name . ' -R';

    my @locked = MKS_command($cmd);
    if ( scalar(@locked) > 0 )
    {
        print LOG "!!! detected locked module(s):\n\n";
        print LOG " @locked \n----------------------------------------------------\n\n";
    }
    
    
       
   #inform about the files in branch
   $cmd = "si viewsandbox --fields=name,memberrev -R -S \"$SystemSandboxpath\"";
   my @allmembers = MKS_command($cmd);
   
   my $table = Text::SimpleTable::AutoWidth->new();
   $table->captions(['Responsible', 'Module', 'Details'] );

   my %Responsibles_Modules;
   

   foreach my $member (@allmembers) {
   		$member =~ /(.*?)\s*([\d\.]*)$/;
   		my $membername = $1;
   		my $member_revision = $2;
   		
   		# proceed next if .pj file
   		if($membername =~ /\.pj$/i) { next; }
   		
        # get all the revision & see the last revision if it is in branch
        $cmd = "si viewhistory --fields=revision,author,date $membername";
        my @allrevisions = MKS_command($cmd);
        
        # continue with next file, if there is only one revision
        if(scalar(@allrevisions) <= 2)  { next; }
        
        #find the first revision
        $allrevisions[1] =~ /^([^\s]+)/i;
        my $firstrevision = $1;
        
        $firstrevision =~ /^(\d+\.\d+)/i;
        my $majorrevision = $1;
        
        # if so, get the responsible name and print into log
        my @revisionDescs = ();
        my $isDeviation = 0;
        
        #find the responsible
        $allrevisions[1] =~ /\s+(.*?\)).*/i;
        my $Responsible = $1;
        
        if($allrevisions[1] !~ /^$member_revision\s/i) {
        	push(@revisionDescs, "CURRENT MEMBER REVISION : " . $member_revision);
        	push(@revisionDescs, "LATEST REVISION : " . $allrevisions[1]);
        	

        	$isDeviation = 1;
        	
        }
        
        # find all the branch revisions
        my @diffrevisions = ();
        foreach my $revision (@allrevisions) {
            if($revision =~ /^$majorrevision/i ) {
                push(@diffrevisions, $revision);
            }
        }
        
        if(scalar(@diffrevisions) >= 2) {
        	$isDeviation = 1;
        }
        
        if($isDeviation) {
        	$membername =~ /(System.*)/i;
           my $shortname = $1;
           $Responsibles_Modules{$Responsible}{$shortname} = join("\n",@revisionDescs)."\n".join("",@diffrevisions)."\n--------------------------------\n";
        }
   
   }
   
   # format the table
   foreach my $responsible(sort keys(%Responsibles_Modules)) {
   	   foreach my $module (keys %{$Responsibles_Modules{$responsible}}) {
   	   		$table->row( $responsible, $module, $Responsibles_Modules{$responsible}{$module} );
   	   }
   }
   
   print LOG $table->draw();
   
   close(LOG);

}

################################################################################
sub help {

    # print the help text
    print color 'bold green';
    print '
Usage:

> create_checkpoint.pl help
   
   to display help text
   
> create_checkpoint.pl getstatus-engine
   
   to get the status regarding all the files in TurboLIFT/System/Engine project.
   
   the status includes 
   
   i) lock status (if any files locked)
   
   ii) member revision update status (if there is a branch or 
   
       if member revision is not updated)
       
   This will create a test file with name "Checkpoint.LOG".
   
> create_checkpoint.pl getstatus-system
   
   to get the status regarding all the files in TurboLIFT/System project.
   
   the status includes 
   
   i) lock status (if any files locked)
   
   ii) member revision update status (if there is a branch or 
   
       if member revision is not updated)
       
   This will create a test file with name "Checkpoint.LOG".
   
> create_checkpoint.pl <checkpoint_name>

    to create documentation, perl-critic report, code-metrics report 
    
    of turboLIFT Engine and copy to K: drive (TurboLIFT support page folder)
    
    e.g., create_checkpoint.pl "Dentsu_Building (V 1.22) - 2.8 Baseline"
   
   
> create_checkpoint.pl copytoolsdoc <checkpointlabel>

    to create tools documentation and copy to K: drive (TurboLIFT support page folder)
    
    e.g., create_checkpoint.pl copytoolsdoc "IDS_Center"   

';

    print color 'reset';
}

################################################################################

sub process_documentation {
##create the Engine documentation
    system("call $Engine_doc_path/create_LIFT_perldoc_docu_quick.bat");

##create code metrics report
    system("call ./CreateLIFTMetrics.bat");

##create Perl critic report
    system("call perl PerlCritic/critichtml.pl");

    #     edit the index.html file to add the links of code metrics & Perl critic reports
    #
    #                 <div id="page_name">
    #                    <h1>TurboLIFT documentation</h1>
    #                  </div>
    #                  <div id="perl_version">
    #                    TurboLIFT documentation
    #                  </div>

    my $filter   = HTML::Filter::Callbacks->new;
    my $remove   = 0;
    my $pagename = 0;

    # callbacks for different tags
    $filter->add_callbacks(

        # callbacks for div tag
        'div' => {
            start => sub {
                my $tag = shift;

                #if tag contains id as "perl_version", remove text and tag
                my $attrval = $tag->attr("id");

                #                return unless ( defined $attrval );

                if ( $attrval eq "perl_version" ) {
                    $tag->remove_text_and_tag();
                    $remove = 1;
                }

                # handling for "page_name"
                if ( $attrval eq "page_name" ) {
                    $pagename = 1;
                }

            },

            end => sub {
                my $tag = shift;

                # remove the text and tag if $remove flag is set
                if ($remove) {
                    $tag->remove_text_and_tag();
                    $remove = 0;
                }

                # disable pagename indication flag
                if ($pagename) {
                    $pagename = 0;
                }

            },
        },

        # callbacks for h1 tag
        'h1' => {
            end => sub {
                my $tag = shift;

                # if h1 corresponds to id "page_name", the change the text accordingly to give code metrics & perl critic report
                if ($pagename) {

                    $tag->text(
                        $checkpointName . '<a href="critic_html/index.html" alt="Perl Critic status"><img hspace=3 border=0 src="./static/perl_critic_camel.png" alt="Perl Critic status" title="Perl Critic feedback"></img></a>
                <a href="LIFT_metrics.html" alt="Code metrics"><img hspace=3 border=0 src="./static/Metrics_Icon_30.png" alt="Code metrics" title="Code metrics"></img></a>
				<a href="Checkpoint_Testing/cover_db/coverage.html" alt="Code coverage of unit tests"><img hspace=3 border=0 src="./static/coverage.png" alt="Code coverage of unit tests" title="Code coverage of unit tests"></img></a>
				<a href="Checkpoint_Testing/TL_LRT/_main__result.html" alt="LIFT Release Test Results"><img hspace=3 border=0 src="./static/LRT.png" alt="LIFT Release Test Results" title="LIFT Release Test Results"></img></a> ');
                }

            },
        },
    );

    # read the index.html file
    open INDEXFILE, "<$Engine_html_path/index.html";
    my $htmlcontents = join '', <INDEXFILE>;
    close(INDEXFILE);

    # process the html contents using the filter
    my $new_html = $filter->process($htmlcontents);

    # write the new index file
    open NEWINDEXFILE, ">$Engine_html_path/index.html";
    print NEWINDEXFILE $new_html;
    close(NEWINDEXFILE);

    # copy the html documentation to a folder with checkpoint name in K: drive
    # use robocopy
    my $command = "robocopy \"$Engine_html_path\" \"$FinalDocFolder\" /E /LOG:robocopy.log /TEE";
    system($command);
}

################################################################################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    
    return @ret;

}

###############################################################################
main();
system("pause");
