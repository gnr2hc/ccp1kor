Please create a folder for each TurboLIFT module for which a design document exists (e.g. LIFT_PD).
Inside those folders please create one design document for each TurboLIFT function.