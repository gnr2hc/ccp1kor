<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1462808096734" ID="ID_1375560178" MODIFIED="1551359317582" TEXT="RTC TurboLIFT components">
<node CREATED="1462808142688" ID="ID_355517138" MODIFIED="1554892869827" POSITION="left" TEXT="MKS projects">
<node CREATED="1462808174547" ID="ID_276021145" MODIFIED="1554892869837" TEXT="TurboLIFT">
<node CREATED="1462809041988" FOLDED="true" ID="ID_1783355128" MODIFIED="1551357015661" TEXT="Playground">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1783355128" ENDARROW="Default" ENDINCLINATION="331;0;" ID="Arrow_ID_890192700" SOURCE="ID_665068612" STARTARROW="None" STARTINCLINATION="331;0;"/>
<node CREATED="1462810592465" ID="ID_1847908696" MODIFIED="1462810601174" TEXT="Tutorials"/>
</node>
<node CREATED="1462808744692" FOLDED="true" ID="ID_1839927653" MODIFIED="1551357015661" TEXT="Projects">
<node CREATED="1462808843597" ID="ID_842683181" MODIFIED="1462810077929" TEXT="AB12"/>
<node CREATED="1462808846165" ID="ID_1475773937" MODIFIED="1462810080433" TEXT="ACUROT"/>
<node CREATED="1462808851085" FOLDED="true" ID="ID_129117904" MODIFIED="1543041991050" TEXT="FoMoCo">
<node CREATED="1462808890106" ID="ID_140463984" MODIFIED="1462810173348" TEXT="AB12_Volvo">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="133;0;" ID="Arrow_ID_679313476" SOURCE="ID_472632083" STARTARROW="None" STARTINCLINATION="133;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="141;0;" ID="Arrow_ID_897101503" SOURCE="ID_1119333549" STARTARROW="None" STARTINCLINATION="141;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="259;0;" ID="Arrow_ID_1880450578" SOURCE="ID_665068612" STARTARROW="None" STARTINCLINATION="259;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="278;0;" ID="Arrow_ID_1952282624" SOURCE="ID_941305456" STARTARROW="None" STARTINCLINATION="278;0;"/>
</node>
<node CREATED="1462808898050" ID="ID_143725577" MODIFIED="1467730415580" TEXT="Ford_AB12_CD4_1_MCA">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="72;0;" ID="Arrow_ID_760957122" SOURCE="ID_472632083" STARTARROW="None" STARTINCLINATION="72;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="92;0;" ID="Arrow_ID_1801733790" SOURCE="ID_1119333549" STARTARROW="None" STARTINCLINATION="92;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="261;0;" ID="Arrow_ID_1837500005" SOURCE="ID_665068612" STARTARROW="None" STARTINCLINATION="261;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="260;0;" ID="Arrow_ID_859335224" SOURCE="ID_941305456" STARTARROW="None" STARTINCLINATION="260;0;"/>
</node>
<node CREATED="1462808925601" ID="ID_548838154" MODIFIED="1462808927277" TEXT="..."/>
</node>
<node CREATED="1462808929400" ID="ID_869954294" MODIFIED="1462808931269" TEXT="..."/>
<node CREATED="1462809790891" FOLDED="true" ID="ID_1090163250" MODIFIED="1543041991050" TEXT="CustLib">
<node CREATED="1462809807173" FOLDED="true" ID="ID_795282686" MODIFIED="1543041991050" TEXT="FoMoCo">
<node CREATED="1462809854852" ID="ID_472632083" MODIFIED="1464869618740" TEXT="TC_FunctionLib">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Function library TC_CustLib
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="133;0;" ID="Arrow_ID_679313476" STARTARROW="None" STARTINCLINATION="133;0;"/>
<arrowlink DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="72;0;" ID="Arrow_ID_760957122" STARTARROW="None" STARTINCLINATION="72;0;"/>
</node>
<node CREATED="1462809876344" ID="ID_1119333549" MODIFIED="1464869709017" TEXT="TCs_CustLib">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Customer specific test cases
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="141;0;" ID="Arrow_ID_897101503" STARTARROW="None" STARTINCLINATION="141;0;"/>
<arrowlink DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="92;0;" ID="Arrow_ID_1801733790" STARTARROW="None" STARTINCLINATION="92;0;"/>
</node>
</node>
</node>
</node>
<node CREATED="1462809015459" FOLDED="true" ID="ID_1342848762" MODIFIED="1551357015661" TEXT="System">
<node CREATED="1462809048874" FOLDED="true" ID="ID_1468341796" MODIFIED="1543041991050" TEXT="develop">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_1468341796" ENDARROW="Default" ENDINCLINATION="234;0;" ID="Arrow_ID_63685933" SOURCE="ID_1111187033" STARTARROW="None" STARTINCLINATION="234;0;"/>
<node CREATED="1462809180330" FOLDED="true" ID="ID_1149723894" MODIFIED="1543041991050" TEXT="ActivePerl">
<node CREATED="1462809218008" ID="ID_1966044932" MODIFIED="1462809223236" TEXT="ActivePerl512"/>
<node CREATED="1462809225895" ID="ID_251174717" MODIFIED="1462809235691" TEXT="Own_Perl_Packages"/>
</node>
<node CREATED="1462809252006" ID="ID_511428425" MODIFIED="1462810233446" TEXT="DLLs">
<arrowlink DESTINATION="ID_665068612" ENDARROW="Default" ENDINCLINATION="84;0;" ID="Arrow_ID_759036736" STARTARROW="None" STARTINCLINATION="84;0;"/>
</node>
<node CREATED="1462809281500" FOLDED="true" ID="ID_1298484072" MODIFIED="1543041991050" TEXT="iStarPlugins">
<node CREATED="1462809300819" ID="ID_1545570058" MODIFIED="1462809303415" TEXT="..."/>
</node>
<node CREATED="1462809314002" ID="ID_1712813013" MODIFIED="1462809319879" TEXT="SupportTools"/>
</node>
<node CREATED="1462808452996" ID="ID_665068612" MODIFIED="1467730420964" TEXT="Engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Shared into all Projects (usually as checkpoint)
    </p>
    <p>
      And each project has its own part of Engine files (Engine\modules\TC_FunctionLib\TC_Project)
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="259;0;" ID="Arrow_ID_1880450578" STARTARROW="None" STARTINCLINATION="259;0;"/>
<arrowlink DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="261;0;" ID="Arrow_ID_1837500005" STARTARROW="None" STARTINCLINATION="261;0;"/>
<arrowlink DESTINATION="ID_135449381" ENDARROW="Default" ENDINCLINATION="124;0;" ID="Arrow_ID_1327589287" STARTARROW="None" STARTINCLINATION="124;0;"/>
<arrowlink DESTINATION="ID_1783355128" ENDARROW="Default" ENDINCLINATION="331;0;" ID="Arrow_ID_890192700" STARTARROW="None" STARTINCLINATION="331;0;"/>
<arrowlink DESTINATION="ID_198086661" ENDARROW="Default" ENDINCLINATION="106;0;" ID="Arrow_ID_1098388648" STARTARROW="None" STARTINCLINATION="106;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_665068612" ENDARROW="Default" ENDINCLINATION="84;0;" ID="Arrow_ID_759036736" SOURCE="ID_511428425" STARTARROW="None" STARTINCLINATION="84;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_665068612" ENDARROW="Default" ENDINCLINATION="273;0;" ID="Arrow_ID_1824104741" SOURCE="ID_1830153346" STARTARROW="None" STARTINCLINATION="159;0;"/>
</node>
<node CREATED="1462809102870" FOLDED="true" ID="ID_1291576957" MODIFIED="1543041991060" TEXT="TCs">
<node CREATED="1462810113149" ID="ID_941305456" MODIFIED="1467730415579" TEXT="TCs_TNT">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Shared into all Projects (usually as checkpoint)
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_140463984" ENDARROW="Default" ENDINCLINATION="278;0;" ID="Arrow_ID_1952282624" STARTARROW="None" STARTINCLINATION="278;0;"/>
<arrowlink DESTINATION="ID_143725577" ENDARROW="Default" ENDINCLINATION="260;0;" ID="Arrow_ID_859335224" STARTARROW="None" STARTINCLINATION="260;0;"/>
</node>
</node>
<node CREATED="1462809107534" ID="ID_1883682577" MODIFIED="1462809116058" TEXT="TSG4_firmware"/>
</node>
<node CREATED="1462810457091" ID="ID_198086661" MODIFIED="1462810626735" TEXT="Template">
<linktarget COLOR="#b0b0b0" DESTINATION="ID_198086661" ENDARROW="Default" ENDINCLINATION="106;0;" ID="Arrow_ID_1098388648" SOURCE="ID_665068612" STARTARROW="None" STARTINCLINATION="106;0;"/>
</node>
<node CREATED="1462808331563" ID="ID_135449381" MODIFIED="1462810503930" TEXT="Tools">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      AB12flash
    </p>
    <p>
      AcuRoT_GUI
    </p>
    <p>
      AFG_GUI
    </p>
    <p>
      CANoeCTRL
    </p>
    <p>
      Coverage
    </p>
    <p>
      Create_SYC_conf
    </p>
    <p>
      CREIS_Utility
    </p>
    <p>
      Documentation
    </p>
    <p>
      DSO_GUI
    </p>
    <p>
      Engine
    </p>
    <p>
      FlashGordons
    </p>
    <p>
      FlowChart-Markup-Language
    </p>
    <p>
      GDCOM_Tool
    </p>
    <p>
      IDID
    </p>
    <p>
      LIFT_shell
    </p>
    <p>
      LPCM
    </p>
    <p>
      Mappingfile_Generators
    </p>
    <p>
      MLC_GUI
    </p>
    <p>
      ODIS
    </p>
    <p>
      par2testlist
    </p>
    <p>
      ParaGen
    </p>
    <p>
      PAS_fault_GUI
    </p>
    <p>
      PD_analyzer
    </p>
    <p>
      peace
    </p>
    <p>
      PPS_GUI
    </p>
    <p>
      QUATE_shell
    </p>
    <p>
      result2DOORS
    </p>
    <p>
      SAD2PLT
    </p>
    <p>
      SPI_GUI
    </p>
    <p>
      SPIexplorer
    </p>
    <p>
      sVTT
    </p>
    <p>
      TCpmGenerator
    </p>
    <p>
      Test_Report
    </p>
    <p>
      Toellner_GUI
    </p>
    <p>
      TSG4
    </p>
    <p>
      UNIVIEW_tools
    </p>
    <p>
      wakeonlan
    </p>
  </body>
</html></richcontent>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_135449381" ENDARROW="Default" ENDINCLINATION="124;0;" ID="Arrow_ID_1327589287" SOURCE="ID_665068612" STARTARROW="None" STARTINCLINATION="124;0;"/>
</node>
</node>
<node CREATED="1462809470521" ID="ID_1830153346" MODIFIED="1462809543985" TEXT="PSDiagSharedDLLs">
<arrowlink COLOR="#b0b0b0" DESTINATION="ID_665068612" ENDARROW="Default" ENDINCLINATION="273;0;" ID="Arrow_ID_1824104741" STARTARROW="None" STARTINCLINATION="159;0;"/>
</node>
<node CREATED="1462810252683" ID="ID_1111187033" MODIFIED="1462810347387" TEXT="testprog/CanoeCtrl">
<arrowlink COLOR="#b0b0b0" DESTINATION="ID_1468341796" ENDARROW="Default" ENDINCLINATION="234;0;" ID="Arrow_ID_63685933" STARTARROW="None" STARTINCLINATION="234;0;"/>
</node>
</node>
<node CREATED="1462810712438" ID="ID_1682570706" MODIFIED="1557141715446" POSITION="right" TEXT="RTC SCM components">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1557141717603" ID="ID_1085613143" MODIFIED="1557141726980" TEXT="rbh">
<node CREATED="1462810729599" ID="ID_1223920005" MODIFIED="1557141644936" TEXT="tools">
<node CREATED="1462810734567" ID="ID_592428531" MODIFIED="1557141645553" TEXT="TurboLIFT">
<node CREATED="1542646229119" ID="ID_1696270320" MODIFIED="1557141648018" TEXT="">
<icon BUILTIN="full-1"/>
<node CREATED="1462810810483" ID="ID_1753786288" MODIFIED="1557397661260" TEXT="Engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Required changes in engine for new structure:
    </p>
    <p>
      - Define $LIFT_engine_cust_path and $LIFT_engine_proj_path in main config file
    </p>
    <p>
      - Use $LIFT_engine_cust_path and $LIFT_engine_proj_path in LIFT_exec_engine to unshift @INC in function read_config
    </p>
    <p>
      - Change @INC path for loading the driver layer modules in many device layer modules
    </p>
    <p>
      - INCLUDES_Project.pm must be located in project part of the engine
    </p>
  </body>
</html></richcontent>
<icon BUILTIN="desktop_new"/>
<node CREATED="1465312890860" FOLDED="true" ID="ID_104558841" MODIFIED="1557397659421" TEXT="">
<node CREATED="1465373424513" ID="ID_832731439" MODIFIED="1465373430805" TEXT="Documentation"/>
<node CREATED="1465373431239" ID="ID_1501319520" MODIFIED="1465373434682" TEXT="htmldata"/>
<node CREATED="1465373434878" FOLDED="true" ID="ID_1863963750" MODIFIED="1557397656843" TEXT="modules">
<node CREATED="1465386772718" ID="ID_277063686" MODIFIED="1542710642725" TEXT="convenience layer"/>
<node CREATED="1465386787892" ID="ID_992433557" MODIFIED="1465386792881" TEXT="functional layer"/>
<node CREATED="1465386793580" FOLDED="true" ID="ID_355451655" MODIFIED="1551357001659" TEXT="device layer">
<node CREATED="1465386797268" ID="ID_1257028191" MODIFIED="1466607842810" TEXT="device1"/>
<node CREATED="1466607851095" ID="ID_1089215577" MODIFIED="1466607853783" TEXT="device 2"/>
<node CREATED="1466607854326" ID="ID_1709898665" MODIFIED="1466607856101" TEXT="..."/>
</node>
<node CREATED="1465386871488" ID="ID_536158768" MODIFIED="1466521668329" TEXT="common library"/>
</node>
<node CREATED="1465373438597" ID="ID_1710193010" MODIFIED="1465373443416" TEXT="run_once"/>
</node>
<node CREATED="1464876839610" ID="ID_1594768311" MODIFIED="1464876842670" TEXT="..."/>
</node>
<node CREATED="1542642801030" FOLDED="true" ID="ID_1011776148" MODIFIED="1557397664009" TEXT="Engine">
<node CREATED="1542642809280" FOLDED="true" ID="ID_1937565081" MODIFIED="1557397664009" TEXT="Daimler">
<node CREATED="1542642817900" ID="ID_1709609606" MODIFIED="1542642934687" TEXT="funclib_generic">
<icon BUILTIN="desktop_new"/>
</node>
<node CREATED="1542642904356" ID="ID_774139416" MODIFIED="1542642934687" TEXT="funclib_customer ">
<icon BUILTIN="desktop_new"/>
</node>
<node CREATED="1542642841430" FOLDED="true" ID="ID_1779180900" MODIFIED="1557397664009" TEXT="MRA">
<node CREATED="1542642912886" ID="ID_1916842260" MODIFIED="1542642943957" TEXT="funclib_project">
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node CREATED="1542642851551" FOLDED="true" ID="ID_11250648" MODIFIED="1557397664009" TEXT="MFA">
<node CREATED="1542642912886" ID="ID_69743814" MODIFIED="1542642943957" TEXT="funclib_project">
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
</node>
<node CREATED="1462810777625" ID="ID_695781765" MODIFIED="1464877622713" TEXT="Tools">
<icon BUILTIN="desktop_new"/>
</node>
<node CREATED="1465373443779" ID="ID_690363133" MODIFIED="1466609562454" TEXT="perl_unit_test">
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node CREATED="1542646260689" ID="ID_1000597648" MODIFIED="1557141646087" TEXT="">
<icon BUILTIN="full-2"/>
<node CREATED="1464875299159" ID="ID_198875927" MODIFIED="1557141794283" TEXT="TCs">
<icon BUILTIN="desktop_new"/>
<node CREATED="1542642249037" ID="ID_1370196805" MODIFIED="1542642262726" TEXT="ACEA"/>
<node CREATED="1542642268506" ID="ID_1996594731" MODIFIED="1542642275595" TEXT="ACEA_AB12"/>
<node CREATED="1542642278415" ID="ID_1385390223" MODIFIED="1542642283895" TEXT="BAT_AB12"/>
<node CREATED="1542642287155" ID="ID_437374126" MODIFIED="1542642289935" TEXT="COM"/>
<node CREATED="1542642292505" ID="ID_1818407275" MODIFIED="1542642294255" TEXT=".."/>
<node CREATED="1542642295165" ID="ID_1672482976" MODIFIED="1542642295985" TEXT=".."/>
<node CREATED="1542642296565" ID="ID_739852119" MODIFIED="1542642298585" TEXT="VDS"/>
</node>
<node CREATED="1542642462894" ID="ID_342118337" MODIFIED="1557141799306" TEXT="TCs.Daimler">
<node CREATED="1542642489755" ID="ID_69730532" MODIFIED="1542642563648" TEXT="TCs_Customer">
<icon BUILTIN="desktop_new"/>
</node>
<node CREATED="1542642551137" ID="ID_1601756003" MODIFIED="1557141803020" TEXT="MFA">
<node CREATED="1542642630827" ID="ID_1901137635" MODIFIED="1542642645417" TEXT="TCs_Project">
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node CREATED="1542642603310" ID="ID_1097821295" MODIFIED="1557141805390" TEXT="MRA">
<node CREATED="1542642616477" ID="ID_828317693" MODIFIED="1542642645417" TEXT="TCs_Project">
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
<node CREATED="1542640884213" ID="ID_526759434" MODIFIED="1542645256324" TEXT="TestArea">
<icon BUILTIN="desktop_new"/>
</node>
<node CREATED="1542645257894" ID="ID_960490186" MODIFIED="1557141811498" TEXT="TestArea">
<node CREATED="1542642155777" ID="ID_1004798415" MODIFIED="1557141842066" TEXT="CREIS">
<icon BUILTIN="desktop_new"/>
<node CREATED="1542642137697" ID="ID_1868029304" MODIFIED="1542642143447" TEXT="Engine"/>
<node CREATED="1542642144007" ID="ID_994030501" MODIFIED="1542642146757" TEXT="TCs"/>
<node CREATED="1542642147607" ID="ID_1728864781" MODIFIED="1542642151727" TEXT="Tools"/>
</node>
</node>
<node CREATED="1542645280520" ID="ID_806524623" MODIFIED="1557141812983" TEXT="TestArea">
<node CREATED="1542642169847" ID="ID_1432576553" MODIFIED="1557141840768" TEXT="EDR">
<icon BUILTIN="desktop_new"/>
<node CREATED="1542642137697" ID="ID_1450912007" MODIFIED="1542642143447" TEXT="Engine"/>
<node CREATED="1542642144007" ID="ID_111838700" MODIFIED="1542642146757" TEXT="TCs"/>
<node CREATED="1542642147607" ID="ID_161920237" MODIFIED="1542642151727" TEXT="Tools"/>
</node>
</node>
<node CREATED="1542641233463" ID="ID_282712595" MODIFIED="1557141834948" TEXT="TestArea">
<node CREATED="1557141818003" ID="ID_666414121" MODIFIED="1557141838169" TEXT="BAT">
<icon BUILTIN="desktop_new"/>
<node CREATED="1557141847098" ID="ID_866241927" MODIFIED="1557141852147" TEXT="Engine"/>
<node CREATED="1557141853087" ID="ID_921679150" MODIFIED="1557141858831" TEXT="TCs"/>
<node CREATED="1557141860253" ID="ID_1405947059" MODIFIED="1557141863917" TEXT="Tools ?"/>
</node>
</node>
<node CREATED="1557141866139" ID="ID_312006404" MODIFIED="1557141868296" TEXT=".."/>
</node>
<node CREATED="1542646434654" ID="ID_1284440398" MODIFIED="1557141869492" TEXT="">
<icon BUILTIN="full-3"/>
<node CREATED="1542640566175" ID="ID_635866159" MODIFIED="1557141872099" TEXT="Bosch">
<node CREATED="1542640619672" ID="ID_910363867" MODIFIED="1557141893447" TEXT="Engine_development">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465369514850" ID="ID_959705993" MODIFIED="1465369521605" TEXT="config"/>
<node CREATED="1465998727928" ID="ID_224666158" MODIFIED="1542644840038" TEXT="reports">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Reports folder must be put into .jazzignore. Otherwise it would show up as &quot;unresolved&quot; every time a test is run.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465369522008" ID="ID_254756347" MODIFIED="1465369528116" TEXT="TC_par"/>
<node CREATED="1465369528526" ID="ID_1704703673" MODIFIED="1465369539150" TEXT="Testlists"/>
</node>
<node CREATED="1542644766133" ID="ID_1727883221" MODIFIED="1557141896383" TEXT="Engine_development">
<node CREATED="1542640661512" ID="ID_750247009" MODIFIED="1542644876487" TEXT="System">
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node CREATED="1542644889877" ID="ID_286105728" MODIFIED="1557141897625" TEXT="Engine_development">
<node CREATED="1542644896647" ID="ID_741452273" MODIFIED="1557141899331" TEXT="System">
<node CREATED="1464875856063" ID="ID_1174216997" MODIFIED="1542644386041" TEXT="dlls_src">
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
<node CREATED="1542644889877" ID="ID_835611333" MODIFIED="1557141900909" TEXT="Engine_development">
<node CREATED="1542644896647" ID="ID_96303032" MODIFIED="1557141901686" TEXT="System">
<node CREATED="1464877759109" FOLDED="true" ID="ID_1103906860" MODIFIED="1542727339738" TEXT="Perl">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465373116547" ID="ID_1170120887" MODIFIED="1465373118247" TEXT="ActivePerl512"/>
<node CREATED="1465373118810" ID="ID_779164950" MODIFIED="1465373128167" TEXT="Own_Perl_Packages"/>
<node CREATED="1465373128682" ID="ID_362726673" MODIFIED="1465373139247" TEXT="SupportTools"/>
</node>
</node>
</node>
<node CREATED="1542644889877" ID="ID_1670880162" MODIFIED="1557141902989" TEXT="Engine_development">
<node CREATED="1542644896647" ID="ID_754981301" MODIFIED="1557141903643" TEXT="System">
<node CREATED="1542640708358" ID="ID_172481237" MODIFIED="1557141904547" TEXT="template_cfg">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465369514850" ID="ID_179976961" MODIFIED="1465369521605" TEXT="config"/>
<node CREATED="1465369522008" ID="ID_719410331" MODIFIED="1465369528116" TEXT="TC_par"/>
<node CREATED="1465369528526" ID="ID_1149959351" MODIFIED="1465369539150" TEXT="Testlists"/>
</node>
</node>
</node>
<node CREATED="1542640825044" ID="ID_640193379" MODIFIED="1557141907181" TEXT="TestCase_development">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465369514850" ID="ID_1363261660" MODIFIED="1465369521605" TEXT="config"/>
<node CREATED="1465998727928" ID="ID_1792809845" MODIFIED="1542644840038" TEXT="reports">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Reports folder must be put into .jazzignore. Otherwise it would show up as &quot;unresolved&quot; every time a test is run.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465369522008" ID="ID_872786494" MODIFIED="1465369528116" TEXT="TC_par"/>
<node CREATED="1465369528526" ID="ID_1355791310" MODIFIED="1465369539150" TEXT="Testlists"/>
</node>
</node>
<node CREATED="1462811012203" ID="ID_1867474171" MODIFIED="1557141916043" TEXT="Daimler">
<node CREATED="1462811045644" ID="ID_1048194942" MODIFIED="1557141918062" TEXT="MRA">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465369514850" ID="ID_1835481013" MODIFIED="1465369521605" TEXT="config"/>
<node CREATED="1465998727928" ID="ID_1752927780" MODIFIED="1542644840038" TEXT="reports">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Reports folder must be put into .jazzignore. Otherwise it would show up as &quot;unresolved&quot; every time a test is run.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465369522008" ID="ID_961805382" MODIFIED="1465369528116" TEXT="TC_par"/>
<node CREATED="1465369528526" ID="ID_441517888" MODIFIED="1465369539150" TEXT="Testlists"/>
</node>
<node CREATED="1462811045644" ID="ID_1467618946" MODIFIED="1557141922909" TEXT="MFA">
<icon BUILTIN="desktop_new"/>
<node CREATED="1465369514850" ID="ID_1356189985" MODIFIED="1465369521605" TEXT="config"/>
<node CREATED="1465998727928" ID="ID_45327660" MODIFIED="1469692666452" TEXT="reports">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Reports folder must be put into .jazzignore. Otherwise it would show up as &quot;unresolved&quot; every time a test is run.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465369522008" ID="ID_1537330075" MODIFIED="1465369528116" TEXT="TC_par"/>
<node CREATED="1465369528526" ID="ID_670895744" MODIFIED="1465369539150" TEXT="Testlists"/>
</node>
<node CREATED="1462811071310" ID="ID_1802126323" MODIFIED="1462811072962" TEXT="..."/>
</node>
<node CREATED="1542646824864" ID="ID_481614548" MODIFIED="1542646826784" TEXT=".."/>
</node>
</node>
</node>
</node>
</node>
<node CREATED="1464877986336" ID="ID_883917169" MODIFIED="1557398930794" POSITION="right" TEXT="RTC SCM streams">
<node COLOR="#338800" CREATED="1542634691787" ID="ID_1444759393" MODIFIED="1557142610745" TEXT="TurboLIFT_Bosch_Engine_development">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#3300ff" CREATED="1542635099318" ID="ID_983041470" MODIFIED="1557398901965" TEXT="tools.turboLIFT.Config.Bosch.Engine_dev">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      component for configuration, cfg, templates, batch, report folder, Testlist, TC_par
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635168715" ID="ID_202691582" MODIFIED="1557398901965" TEXT="tools.turboLIFT.Engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Documentation
    </p>
    <p>
      htmlData
    </p>
    <p>
      modules
    </p>
    <p>
      run_once
    </p>
    <p>
      *.pl eg LIFT_exec_engine.pl
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635383547" ID="ID_695546835" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Engine.funclib_generic">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FuncLib_TNT_*
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635393737" ID="ID_1780209847" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Tools">
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#3300ff" CREATED="1542635187624" ID="ID_1986279293" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Engine.perl_unit_test">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_345991748" MODIFIED="1557398901975" TEXT="tools.turboLIFT.TCs">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635789904" ID="ID_1898874734" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Bosch.Engine_dev.TCs_project">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
<node COLOR="#3300ff" CREATED="1542635099318" FOLDED="true" ID="ID_468089049" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Bosch.Engine_dev.System">
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635212144" ID="ID_466734648" MODIFIED="1557398901975" TEXT="tools.turboLIFT.ActivePerl">
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635219584" ID="ID_1719153142" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Bosch.TFrWk_development.dlls_src">
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635227244" ID="ID_1517150259" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Bosch.TFrWk_development.docs">
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635234914" ID="ID_1434249021" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Bosch.TFrWk_development.template_cfg">
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
<node COLOR="#009999" CREATED="1542634626161" ID="ID_194553563" MODIFIED="1557142595776" TEXT="TurboLIFT_Bosch_TestCase_development">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#009900" CREATED="1542635099318" ID="ID_1570660246" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Config.Bosch.TestCase_dev">
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635168715" ID="ID_1885824413" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Engine">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635383547" ID="ID_440446166" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Engine.funclib_generic">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635393737" ID="ID_748156402" MODIFIED="1557398901975" TEXT="tools.turboLIFT.Tools">
<font NAME="SansSerif" SIZE="13"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_441497425" MODIFIED="1557398901975" TEXT="tools.turboLIFT.TCs">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_10914124" MODIFIED="1557398901975" TEXT="tools.turboLIFT.TCs.TestArea">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_499632133" MODIFIED="1557398901975" TEXT="tools.turboLIFT.TCs.TestArea.CREIS">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_1281297614" MODIFIED="1557398901975" TEXT="tools.turboLIFT.TCs.TestArea.EDR">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_163005588" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.TestArea.BAT">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
</node>
<node COLOR="#009999" CREATED="1542635855731" ID="ID_372426389" MODIFIED="1557143514530" TEXT="TurboLIFT_Daimler_MFA">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Project stream. Engine.common and TCs.TCs_common are configured as baselines of an Engine release stream.
    </p>
    <p>
      If a project stream wants a new TurboLIFT checkpoint then
    </p>
    <p>
      - Baselines of Engine.common and TCs.TCs_common are replaced with newer baselines: User must accept changes (try, this looks like the best way)
    </p>
    <p>
      - Changes of the Release stream are flown to the Project stream: At the time of change the flow is created. User must accept the changes, but if changes have been done in the project then there is an error
    </p>
    <p>
      - A new project stream has to be created (big effort: create baselines of project specific components, user must create a new workspace for the new stream)
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#990099" CREATED="1542635896362" ID="ID_28259537" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Config.Daimler.MRA">
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#3300ff" CREATED="1542635168715" ID="ID_810657654" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Documentation
    </p>
    <p>
      htmlData
    </p>
    <p>
      modules
    </p>
    <p>
      run_once
    </p>
    <p>
      *.pl eg LIFT_exec_engine.pl
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635393737" ID="ID_86490426" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Tools">
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635383547" ID="ID_1264553138" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine.funclib_generic">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FuncLib_TNT_*
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542639893124" ID="ID_1192353447" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine.Daimler.funclib_customer">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542639946514" ID="ID_1094378508" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine.Daimler.MRA.funclib_project ">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_508477500" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#990099" CREATED="1542640008750" ID="ID_1937501586" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.Daimler.TCs_Customer">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542640018690" ID="ID_1874541272" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.Daimler.MRA.TCs_project">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_918805739" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.TestArea">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_618012639" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.TestArea.CREIS">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_235030251" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.TestArea.EDR">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542640018690" ID="ID_885792012" MODIFIED="1557398901985" TEXT="tools.turboLIFT.TCs.Daimler.TestArea.BAT">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
</node>
<node COLOR="#009999" CREATED="1542635881500" ID="ID_406597420" MODIFIED="1557143602551" TEXT="TurboLIFT_Daimler_MRA">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Project stream. Engine.common and TCs.TCs_common are configured as baselines of an Engine release stream.
    </p>
    <p>
      If a project stream wants a new TurboLIFT checkpoint then
    </p>
    <p>
      - Baselines of Engine.common and TCs.TCs_common are replaced with newer baselines: User must accept changes (try, this looks like the best way)
    </p>
    <p>
      - Changes of the Release stream are flown to the Project stream: At the time of change the flow is created. User must accept the changes, but if changes have been done in the project then there is an error
    </p>
    <p>
      - A new project stream has to be created (big effort: create baselines of project specific components, user must create a new workspace for the new stream)
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#990099" CREATED="1542635904822" ID="ID_408072724" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Config.Daimler.MFA">
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#3300ff" CREATED="1542635168715" ID="ID_1816855632" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Documentation
    </p>
    <p>
      htmlData
    </p>
    <p>
      modules
    </p>
    <p>
      run_once
    </p>
    <p>
      *.pl eg LIFT_exec_engine.pl
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#3300ff" CREATED="1542635393737" ID="ID_986385759" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Tools">
<font NAME="SansSerif" SIZE="15"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#3300ff" CREATED="1542635383547" ID="ID_695375328" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine.funclib_generic">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FuncLib_TNT_*
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542639893124" ID="ID_1107303252" MODIFIED="1557398901985" TEXT="tools.turboLIFT.Engine.Daimler.funclib_customer">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542639946514" ID="ID_608472706" MODIFIED="1557398901995" TEXT="tools.turboLIFT.Engine.Daimler.MFA.funclib_project ">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_1405461767" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#990099" CREATED="1542640008750" ID="ID_1088093732" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.Daimler.TCs_Customer">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542640018690" ID="ID_288088584" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.Daimler.MFA.TCs_project">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_935614469" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.TestArea">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_1578993933" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.TestArea.CREIS">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#009900" CREATED="1542635196174" ID="ID_653317508" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.TestArea.EDR">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
<node COLOR="#990099" CREATED="1542640018690" ID="ID_663497435" MODIFIED="1557398901995" TEXT="tools.turboLIFT.TCs.Daimler.TestArea.BAT">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="desktop_new"/>
</node>
</node>
</node>
</node>
<node CREATED="1542640130416" ID="ID_1092431442" MODIFIED="1542640197245" TEXT=".."/>
</node>
<node CREATED="1465370074968" FOLDED="true" ID="ID_484383352" MODIFIED="1551357015671" POSITION="left" TEXT="RTC SCM basics">
<node CREATED="1465372308639" ID="ID_582023190" MODIFIED="1465384545257" TEXT="A &quot;component&quot; is made of files and folders, starting in one common top folder">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1465372632309" ID="ID_1134235753" MODIFIED="1465372759407" TEXT="A component can have &quot;baselines&quot; (like a checkpoint in MKS)"/>
<node CREATED="1465372825725" ID="ID_802472737" MODIFIED="1465372861057" TEXT="The name of a component reflects its starting folder structure (dot notation)"/>
<node CREATED="1465372356961" ID="ID_607314407" MODIFIED="1465372766336" TEXT="A &quot;stream&quot; is made of streams and/or components"/>
<node CREATED="1465372696760" ID="ID_459570667" MODIFIED="1465372789568" TEXT="A stream can have &quot;snapshots&quot; (like a checkpoint in MKS)"/>
</node>
<node CREATED="1466605504905" FOLDED="true" ID="ID_42574544" MODIFIED="1551357015671" POSITION="left" TEXT="Ideas">
<node CREATED="1466605509691" ID="ID_1301955700" MODIFIED="1466605541246" TEXT="Put dll source code in Engine.common component"/>
<node CREATED="1466605656107" ID="ID_170448345" MODIFIED="1466607517118" TEXT="Think about modular engine components">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      High level module
    </p>
    <p>
      low level modules
    </p>
    <p>
      config file
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1464868407400" FOLDED="true" ID="ID_1624051932" MODIFIED="1551357015671" POSITION="left" TEXT="Questions about SCM">
<node CREATED="1464870270283" FOLDED="true" ID="ID_1125680405" MODIFIED="1551357015671" TEXT="open">
<node CREATED="1466594668690" ID="ID_145350215" MODIFIED="1466594711820" TEXT="How long will MKS be available (read-only) after we have switched to SCM?"/>
<node CREATED="1469688387193" ID="ID_1249342452" MODIFIED="1469688431324" TEXT="How is the team structure currently in ALM with testing team(s)?"/>
</node>
<node CREATED="1464870277771" FOLDED="true" ID="ID_1365905048" MODIFIED="1551357015671" TEXT="answered">
<node CREATED="1464870283114" ID="ID_1428732438" MODIFIED="1465287024078" TEXT="How do I create a workspace for a stream?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In Source Control Right click on stream-&gt; Create Workspace and Load UBK
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1464870483415" ID="ID_1588250940" MODIFIED="1469688933252" TEXT="How can I select where the components are checked out?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      By default the sandbox is created here:
    </p>
    <p>
      C:\Users\&lt;user&gt;\rtc_sandbox\&lt;stream&gt;_RWS_&lt;user&gt;
    </p>
    <p>
      But this can be configured in AEEE preferences.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465197040693" ID="ID_568242893" MODIFIED="1465287235893" TEXT="Why are folders not created according to dot notation when creating a stream workspace?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Folders are not created according to dot notation when creating the stream workspace using &quot;Load...&quot; instead of &quot;Load UBK&quot;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1464880633674" ID="ID_585491593" MODIFIED="1465287355562" TEXT="How can I create a non-private component / How can I create a stream?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      By having the proper role (Project Admin or Tool responsible?)
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1464870724185" ID="ID_288637711" MODIFIED="1543025831488" TEXT="How can I see the versions of a file that I have only checked in but not delivered?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In History tab activate &quot;Check-in History&quot;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1464880920918" ID="ID_1739655039" MODIFIED="1465369169742" TEXT="How can I delete a component or a stream?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Components or streams cannot be deleted. They can be renamed. Admins can move them to a special &quot;Deleted&quot; owner.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1465213699689" ID="ID_571391525" MODIFIED="1469689021224" TEXT="How to use the PSDiag dll in TurboLIFT (in MKS it is a shared project)?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Either add a PSDiag stream or component to TurboLIFT Engine stream. Then the dll will be located in tools\PSDiag\... However up to now the dll itself is not part of any SCM component. Only source code is in SCM.
    </p>
    <p>
      Or copy the dll into the Engine. Then the dll will be located inside the Engine.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1466690965421" ID="ID_194095067" MODIFIED="1469689050818" TEXT="What exactly is a flow and how is it used in other tools?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A flow is in short a relationship between streams or between workspaces and streams. The flow defines where changes are flowing to.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1466521811684" ID="ID_1397239458" MODIFIED="1467794390034" TEXT="How can I checkout a stream/component from within a batch file like done for MKS in _run_once.bat?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      See script examples (perl!) here: https://jazz.net/library/article/1031
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1466586947375" ID="ID_1566516252" MODIFIED="1468409605687" TEXT="How can I have the current version number of a file in the source code (like $Revision: 1.9 $ for MKS)?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      There is nothing like that in SCM
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1466669299885" ID="ID_1728048127" MODIFIED="1468409656577" TEXT="How can I permanently remove the &apos;Clean Workspace&apos; Precondition in the Eclipse client?">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Ask the ALM admin to remove the precondition for our projects
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1466609660521" ID="ID_391874256" MODIFIED="1469632310111" TEXT="Clarify which versions of files are visible in different streams">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Generally every component inside a stream has a defined baseline. This defines the visible versions of the files inside the components.
    </p>
    <p>
      Different streams can have different baselines of the same component. Thus in different streams the same file can have different visible versions.
    </p>
    <p>
      If certain new engine changes shall be visible in e.g. a project stream then the engine developer must define a flow from engine development to the project and deliver some or all change sets to the project. Only then those change sets (and thus also the corresponding file versions) are visible in the project.
    </p>
    <p>
      &#160;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1469688876037" FOLDED="true" ID="ID_1397965500" MODIFIED="1551357015671" POSITION="left" TEXT="Known issues/Open topics">
<node CREATED="1469688882244" ID="ID_1592773735" MODIFIED="1469689144930" TEXT="Re-write _run_once.bat to work with SCM"/>
<node CREATED="1469689176284" ID="ID_1257149857" MODIFIED="1469689304697" TEXT="Keyword replacement in the code (e.g. $Revision: 1.9 $) does not exist for SCM. Clarify what to do."/>
<node CREATED="1469690592395" ID="ID_514997398" MODIFIED="1469690621753" TEXT="Ask the ALM admin to remove the &apos;Clean Workspace&apos; Precondition for our projects"/>
<node CREATED="1469692033944" ID="ID_57553838" MODIFIED="1469692081821" TEXT="In which stream(s) is TCs_Common developed?"/>
<node CREATED="1469692430746" ID="ID_1584579699" MODIFIED="1469692442310" TEXT="Clarify access rights for engine development"/>
<node CREATED="1469707552662" ID="ID_985813907" MODIFIED="1469707608096" TEXT="When transferring to the productive server inlude all generated .jazzignore file from the Playground server"/>
</node>
<node CREATED="1469634131243" ID="ID_1075708545" MODIFIED="1554896149899" POSITION="right" TEXT="Use Cases">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1469634183171" ID="ID_572148435" MODIFIED="1554892896720" TEXT="Engine development">
<node CREATED="1554896168097" ID="ID_1561989203" MODIFIED="1554896193613" TEXT="Create RWS and load Sandbox"/>
<node CREATED="1469635122467" ID="ID_319957358" MODIFIED="1554895988619" TEXT="Get latest engine version on local PC ">
<node CREATED="1542719100066" ID="ID_1443594365" MODIFIED="1554896309293" TEXT="for first time user">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      go the Stream TurboLIFT_Bosch_Engine_development&#160;&#160;and do &quot;Create Workspace and load BBM&quot;. This creates a repository workspace in ALM and a sandbox on the PC: &quot;TurboLIFT_Bosch_Engine_development_RWS_&lt;userid&gt;&quot;.
    </p>
    <p>
      this will create a newer version of engine in the local PC.
    </p>
    <p>
      
    </p>
    <p>
      Adapt configs so that TurboLIFT works for your PC and tools.
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1542719229433" ID="ID_127470027" MODIFIED="1554896309301" TEXT="for existing users">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      go the repository workspace&#160;&#160;'TurboLIFT_Bosch_Engine_development_RWS_&lt;userid&gt;' and in the pending changes view -&gt; accept the incoming changes for the Engine component's.
    </p>
    <p>
      this will update a newer version of engine in the local PC.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1472565452106" ID="ID_1623348470" MODIFIED="1472565616067" TEXT="Check differences between a locally modified file and its repository version">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      The locally changed file appears in the &quot;Pending Changes&quot; tab under &quot;Unresolved&quot;.
    </p>
    <p>
      Just double click the file in &quot;Unresolved&quot; and the changes to the repository version will be displayed in the configured diff tool.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469635153245" ID="ID_508734182" MODIFIED="1542721291504" TEXT="Change engine code and checkin to your repository workspace">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Make changes on one or more files in &quot;TurboLIFT_Bosch_TestFramework_development_RWS_&lt;userid&gt;&quot;. The changes appear in AEEE in the &quot;Pending Changes&quot; tab as &quot;Unresolved&quot;.
    </p>
    <p>
      On the Unresolved changes do &quot;Check-in -&gt; New Change set&quot;. The changes are checked in to your repository workspace and are connected to one new Change set. The changes are not yet visible on the stream.
    </p>
    <p>
      The changes appear now in the &quot;Pending Changes&quot; tab as &quot;Outgoing&quot; and the Change set is marked as &lt;No Comment&gt;. You should change &lt;No Comment&gt; to a reasonable comment.
    </p>
    <p>
      You can do more changes in your sandbox. They appear in the &quot;Pending Changes&quot; tab again as &quot;Unresolved&quot;. On the Unresolved changes you can do either &quot;Check-in&quot; to your previosly created Change set (if you work for the same task) or &quot;Check-in -&gt; New Change set&quot; (if you work for another task). The changes are again checked in to your repository workspace and are connected to the chosen Change set.
    </p>
    <p>
      Change sets can be modified (change comment, move changes from one Change set to another, discard completely) as long as they are not yet delivered to the stream.
    </p>
    <p>
      Recommendation: Do Check-in early and often. Your changes are then safely stored on the ALM server. You can keep track of your changes, compare different Check-in versions for a file and revert back to an older version if necessary. But nothing of this is visible on the stream.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469635153245" ID="ID_136862449" MODIFIED="1542721286294" TEXT="Deliver changes from your repository workspace to the Engine development stream">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Whenever you think that your checked-in changes should be made visible to others (e.g. for review, for testing, for completion of a task or story) then you can deliver &quot;Outgoing&quot; Change sets to the Engine development stream.
    </p>
    <p>
      Before delivering any changes to the stream you should check if there are any &quot;Incoming&quot; changes that might affect your &quot;Outgoing&quot; changes. If there are any see the use case &quot;Merge my change set into someone elses changes&quot;.
    </p>
    <p>
      For the following let's assume that there are no &quot;Incoming&quot; changes that affect your &quot;Outgoing&quot; changes.
    </p>
    <p>
      In the &quot;Pending Changes&quot; tab select one or more &quot;Outgoing&quot; Change sets and do &quot;Related Artifacts -&gt; Associate Work Item&quot; and find a story or task that you want to link to the Change set(s).
    </p>
    <p>
      Then do &quot;Deliver&quot; on the Change set(s). The Change set(s) will be delivered to the stream that is connected to your repository workspace and other team members see your Change set(s) as &quot;Incoming&quot; in their sandboxes.
    </p>
    <p>
      Note: If a &quot;Clean workspace precondition&quot; error occurs then the precondition can be overridden. On the productive ALM server this precondition must be removed for TurboLIFT.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469705889998" ID="ID_1269269991" MODIFIED="1469706367617" TEXT="Accept changes from other team members in your repository workspace">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      When another team member has delivered Change sets to the stream then they will show up as &quot;Incoming&quot; in your repository workspace.
    </p>
    <p>
      You can choose at which point in time you want to have those Change sets in your repository workspace and sandbox.
    </p>
    <p>
      On the &quot;Incoming&quot; Change sets do &quot;Accept&quot;. The changes will be taken over to your repository workspace and to your sandbox.
    </p>
    <p>
      If you have modified files that have been changed by the &quot;Accept&quot; operation then you have a conflict, which you have to resolve. See use case &quot;Merge my change set into someone elses changes&quot;.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469636556987" ID="ID_1404298499" MODIFIED="1469708609665" TEXT="Merge someone elses changes into my change set">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Before delivering any changes to the stream you should check if there are any &quot;Incoming&quot; changes that might affect your &quot;Outgoing&quot; changes.
    </p>
    <p>
      If there are any then you have to merge someone elses changes into your change set.
    </p>
    <p>
      On the &quot;Incoming&quot; Change sets do &quot;Accept&quot;. The changes will be taken over to your repository workspace and to your sandbox as far as possible.
    </p>
    <p>
      A pop-up window will inform you about conflicts. Click &quot;Resolve Later&quot; because auto resolve is not reliable. The conflicting Change set appears as &quot;Unresolved&quot; with a little conflict symbol.
    </p>
    <p>
      On the conflicting Change set do &quot;Open in External Compare Tool&quot; (recommended, needs Beyond Compare to be configured in Preferences) or &quot;Open in Compare Editor&quot; to resolve the conflict manually in your local sandbox file.
    </p>
    <p>
      Then do &quot;Resolve as merged&quot; on the conflicting Change set. The conflicting Change set will vanish and your &quot;Outgoing&quot; change set that created the conflict will get &quot;(1 merged)&quot; added to the Change set comment.
    </p>
    <p>
      Now you can safely deliver this change set.
    </p>
    <p>
      Note: If you try to deliver a Change set that would create a conflict before accepting the conflicting Incoming Change set then you will get a delivery error.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469635552054" ID="ID_1202556370" MODIFIED="1469710172360" TEXT="Get an older version of the engine on local PC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>your repository workspace</b>&#160; on the component (e.g. tools.TurboLIFT.Engine.common) do &quot;Replace with -&gt; Baseline...&quot; and select the baseline that you want to go back to.
    </p>
    <p>
      The component will be brought to the selected baseline in your repository workspace and sandbox.
    </p>
    <p>
      As a consequence you will have all those Change sets as &quot;Incoming&quot; that are between the chosen baseline and the current state of the stream.
    </p>
    <p>
      Be aware that if you make changes from that state and try to deliver them to the stream, you will most likely create lots of conflicts. So do not do that!
    </p>
    <p>
      If you want to bring the component to the current state of the stream again, just accept all those &quot;Incoming&quot; change sets.
    </p>
    <p>
      Note: Whenever you do a &quot;Replace&quot; on a component then automatically a baseline named &quot;Backup before replace&quot; will be created. If the &quot;Replace&quot; is done in your repository workspace then this baseline is only visible there.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469636344024" ID="ID_800063765" MODIFIED="1470044018123" TEXT="Temporarily get an older version of a single file on local PC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      On the selected file do &quot;Team -&gt; Show History&quot; to display the file versions. To see the differences between any version and the file you have currently in your sandbox do on a particular version &quot;Compare with Local Version&quot;.
    </p>
    <p>
      If you have found the version that you want remember the Version ID and the Change set.
    </p>
    <p>
      
    </p>
    <p>
      File version method (load old version): Do &quot;Load&quot; on the remembered version. This will load the selected version of the file. If you have the file in more than one sandbox you will be asked for the path of the file.
    </p>
    <p>
      Since the file is now locally modified it will show up in &quot;Pending Changes&quot; tab as &quot;Unresolved&quot;.
    </p>
    <p>
      CAUTION: You should not check in this version of the file unless you really want to have this older version as latest version.
    </p>
    <p>
      CAUTION: It seems it cannot be easily seen which version of the file is loaded. One way is to do &quot;Compare with Local Version&quot; on versions until you find the version which is identical to the local file.
    </p>
    <p>
      If you want to go back to the latest file version do &quot;Undo&quot; on the &quot;Unresolved&quot; changes.
    </p>
    <p>
      
    </p>
    <p>
      Change set method (suspend Change sets): In the &quot;Team Artifacts&quot; view in <b>your repository workspace</b>&#160;&#160;on the component (e.g. tools.TurboLIFT.Engine.common) do &quot;Show -&gt; History&quot; to display all Change sets for the component.
    </p>
    <p>
      Select all Change sets from the latest until the remembered Change set and do &quot;Suspend&quot;. This will undo all changes of the selected Change sets in your sandbox. The selected Change sets will appear as &quot;Suspended&quot; (and &quot;Incoming&quot;).
    </p>
    <p>
      CAUTION: Other files will also be changed to earlier versions, depending on how many Change sets you have suspended.
    </p>
    <p>
      It may be helpful to get an older version of the engine before to reduce the number of Change sets to be suspended.
    </p>
    <p>
      If you want to go back to latest file versions do &quot;Resume&quot; on all suspended Change sets. In the pop-up window select &quot;Resume&quot;.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1470040346254" ID="ID_1358921264" MODIFIED="1470040580601" TEXT="Undo local changes on a file">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      If you have modified a file in your sandbox, but you want to have the latest version of your repository workspace again, then in the &quot;Pending Changes&quot; tab under &quot;Unresolved&quot; on the file do &quot;Undo&quot; to restore the latest version of your your repository workspace.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1470046091554" ID="ID_1053051503" MODIFIED="1470054478485" TEXT="Find all Change sets since the last baseline in your repository workspace">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>your repository workspace</b>&#160; on the component (e.g. tools.TurboLIFT.Engine.common) do &quot;Compare With -&gt; Current Baseline&quot;. All Change sets that were checked in since the baseline your workspace is based on are displayed.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469636602219" ID="ID_1735206892" MODIFIED="1470055097156" TEXT="Create a new baseline for Engine.common">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Before creating a baseline for a component make sure that you have accepted all incoming Change sets in your repository workspace which you want to have included in the baseline.
    </p>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>your repository workspace</b>&#160;&#160;on the component (e.g. tools.TurboLIFT.Engine.common) do &quot;New -&gt; Baseline...&quot;. Choose a name and optionally a description of the new baseline.
    </p>
    <p>
      In the &quot;Pending Changes&quot; tab the new baseline is shown as &quot;Outgoing&quot;. Deliver the new baseline to make it visible in the stream (no related story or task is required to deliver a baseline).
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469636663157" ID="ID_1986230459" MODIFIED="1472566786246" TEXT="Create a new Engine release (former checkpoint)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Make sure that all components in your Engine development stream have the intended baseline versions (and are not modified).
    </p>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>Tools area -&gt; Source Control (directly on the server)</b>&#160;on the stream (e.g. TurboLIFT__Engine_development) do &quot;New -&gt; Snapshot...&quot;. Choose a name and optionally a description of the new baseline.
    </p>
    <p>
      Make sure the &quot;Create new baselines&quot; option is <b>not</b>&#160;ticked.
    </p>
    <p>
      In the &quot;Pending Changes&quot; tab the new snapshot is shown as &quot;Incoming&quot; in your workspace. Accept the new snapshot to have it visible in the workspace.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469636421860" ID="ID_19588436" MODIFIED="1470045794093" TEXT="Create a branch version for a file (manually not possible)">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In SCM there is no need to create a branch version for a file manually. Parallel development on the same file is easily possible by using the personal Repoitory Workspace. Branches on files are created automatically if changes are merged into Change sets.
    </p>
    <p>
      If a longer parallel development is planned then consider creating a separate stream for the parallel development.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469696513396" ID="ID_355744937" MODIFIED="1469705883939" TEXT="Lock a file to indicate that you will be working on it (not recommended).">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      If you want to indicate to others that you will be working on a file then on that file you can do &quot;Team -&gt; Lock...&quot; and select the stream in which the lock shall be done. The file icon will get a little lock symbol.
    </p>
    <p>
      If a file has a lock then nobody else can deliver a Change set that includes this file.&#160;However a lock can be removed by anybody by doing &quot;Team -&gt; Unlock...&quot;.
    </p>
    <p>
      Recommendation: Do not use locks. They are not that helpful.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1542721038212" ID="ID_1157832706" MODIFIED="1542721049342" TEXT="Source Code review"/>
</node>
<node CREATED="1469634188652" ID="ID_584709995" MODIFIED="1554892945692" TEXT="Test development">
<node CREATED="1554896208103" ID="ID_970444875" MODIFIED="1554896210626" TEXT="Create RWS and load Sandbox "/>
<node CREATED="1542719488907" ID="ID_1970814714" MODIFIED="1542719940350" TEXT="Get latest engine version on local PC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <ol>
      <li>
        go to Stream &quot;TurboLIFT_Bosch_TestCase_development&quot;
      </li>
      <li>
        go to component &quot;tools.TurboLIFT.Engine&quot; and right click select &quot;Replace With&quot; =&gt;&#160;&#160;&quot;Component from Another Repository Workspace or Stream&quot;
      </li>
      <li>
        select the Stream &quot;TurboLIFT_Bosch_TestFramework_development&quot;, select Yes.
      </li>
      <li>
        Go to &quot;Pending Changes&quot;: and accept the incoming changes for the component &quot;tools.TurboLIFT.Engine&quot;.
      </li>
    </ol>
  </body>
</html></richcontent>
</node>
<node CREATED="1469688323638" ID="ID_1601938918" MODIFIED="1472570300534" TEXT="Create a new TurboLIFT project in SCM">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      You have to have the proper access rights to create/modify streams to be able to create a new TurboLIFT project.
    </p>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>Tools area -&gt; Source Control</b>&#160;do New -&gt; Stream...
    </p>
    <p>
      Give the name of the new stream (e.g. TurboLIFT__FoMoCo__Example_Project), set the owner of the new stream to &quot;Testing Framework&quot; (?) and add the following components:
    </p>
    <p>
      tools.TurboLIFT.Engine.common (release baseline)
    </p>
    <p>
      tools.TurboLIFT.Engine.FoMoCo.TC_CustLib
    </p>
    <p>
      tools.TurboLIFT.TCs.TCs_common (release baseline)
    </p>
    <p>
      tools.TurboLIFT.TCs.FoMoCo.TCs_CustLib
    </p>
    <p>
      Still in the new stream create the following new components:
    </p>
    <p>
      tools.TurboLIFT.Engine.FoMoCo.Example_Project
    </p>
    <p>
      tools.TurboLIFT.TCs.FoMoCo.Example_Project
    </p>
    <p>
      tools.TurboLIFT.Project.FoMoCo.Example_Project
    </p>
    <p>
      If the CustLib components do not yet exist, then they have to be created as well like the project specific components.
    </p>
    <p>
      Click &quot;Save&quot; and the new stream will be created.
    </p>
    <p>
      Go to the new stream and do &quot;Create Workspace and Load UBK&quot;. This creates a repository workspace in ALM and a sandbox on the PC: &quot;TurboLIFT__FoMoCo__Example_Project_RWS_&lt;userid&gt;&quot;.
    </p>
    <p>
      Go to stream &quot;TurboLIFT__Bosch__Template&quot; and do &quot;Create Workspace and Load UBK&quot;. This creates another repository workspace in ALM and another sandbox on the PC: &quot;TurboLIFT__Bosch__Template_RWS_&lt;userid&gt;&quot;.
    </p>
    <p>
      Copy all project specific files from the Template project to the new project and rename the config files from &quot;default&quot; to the new project name (in this example &quot;Example_Project&quot;).
    </p>
    <p>
      Do &quot;Check-in and Deliver...&quot; on all changed files.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469688440326" ID="ID_1413879351" MODIFIED="1472569519374" TEXT="&quot;Check out&quot; a TurboLIFT project in SCM">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>Tools area -&gt; Source Control </b>go to desired project stream and do &quot;Create Workspace and Load UBK&quot;. This creates a repository workspace in ALM and a sandbox on the PC: &quot;TurboLIFT__&lt;customer&gt;__&lt;project&gt;_RWS_&lt;userid&gt;&quot;.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469688339987" ID="ID_1530839200" MODIFIED="1472570103911" TEXT="Change project files or test cases and deliver to the project">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      This is done in exactly the same way as for engine development. See the use cases &quot;Change engine code and checkin to your repository workspace&quot; and &quot;Deliver changes from your repository workspace to the Engine development stream&quot;.
    </p>
    <p>
      <b>Important Note</b>: If you change files in the component &quot;tools.TurboLIFT.Engine.common&quot; or in &quot;tools.TurboLIFT.TCs.TCs_common&quot; then you may be able to check-in and deliver, but only to your project stream. Those changes will not flow to the Engine_Development stream and may be lost with the next engine update.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1469688803809" ID="ID_579218620" MODIFIED="1542719495247" TEXT="Upgrade the engine in the project to a newer baseline">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      You have to have the proper access rights to create/modify streams to be able to upgrade the TurboLIFT engine in a project.
    </p>
    <p>
      In the &quot;Team Artifacts&quot; view in <b>Tools area -&gt; Source Control </b>double click&#160;on the desired project stream. Select tools.TurboLIFT.Engine.common and&#160;click &quot;Replace with...&quot; -&gt; &quot;Component from snapshot&quot;, select the stream &quot;TurboLIFT__Engine_Development&quot; and select the desired snapshot. Click on &quot;Save&quot;.
    </p>
    <p>
      For component tools.TurboLIFT.Engine.common change sets will show up as &quot;Incoming&quot; in each repository workspace that is linked to the stream. Accept those change sets and the engine is upgraded also in the repository workspace.
    </p>
    <p>
      If engine files have been modified in the project stream then a conflict may occur and there may also be &quot;Outgoing&quot; change sets in tools.TurboLIFT.Engine.common. In that case accept only the incoming change sets and in the conflict dialog select the option &quot;Replace&quot; to get all files from the Engine_Development stream.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1542718973941" ID="ID_1129545963" MODIFIED="1554892950092" TEXT="Projects">
<node CREATED="1554896247937" ID="ID_553956803" MODIFIED="1554896252982" TEXT="Project1">
<node CREATED="1554896230033" ID="ID_403945988" MODIFIED="1554896231837" TEXT="Create RWS and load Sandbox "/>
<node CREATED="1542719492427" ID="ID_1979164937" MODIFIED="1542719946770" TEXT="Get latest engine version on local PC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <ol>
      <li>
        go to Stream &quot;TurboLIFT_Bosch_TestCase_development&quot;
      </li>
      <li>
        go to component &quot;tools.TurboLIFT.Engine&quot; and right click select &quot;Replace With&quot; =&gt;&#160;&#160;&quot;Component from Another Repository Workspace or Stream&quot;
      </li>
      <li>
        select the Stream &quot;TurboLIFT_Bosch_TestFramework_development&quot;, select Yes.
      </li>
      <li>
        Go to &quot;Pending Changes&quot;: and accept the incoming changes for the component &quot;tools.TurboLIFT.Engine&quot;.
      </li>
    </ol>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1554896247937" ID="ID_491799628" MODIFIED="1554896278819" TEXT="Project2">
<node CREATED="1554896230033" ID="ID_734442232" MODIFIED="1554896231837" TEXT="Create RWS and load Sandbox "/>
<node CREATED="1542719492427" ID="ID_1933195945" MODIFIED="1542719946770" TEXT="Get latest engine version on local PC">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <ol>
      <li>
        go to Stream &quot;TurboLIFT_Bosch_TestCase_development&quot;
      </li>
      <li>
        go to component &quot;tools.TurboLIFT.Engine&quot; and right click select &quot;Replace With&quot; =&gt;&#160;&#160;&quot;Component from Another Repository Workspace or Stream&quot;
      </li>
      <li>
        select the Stream &quot;TurboLIFT_Bosch_TestFramework_development&quot;, select Yes.
      </li>
      <li>
        Go to &quot;Pending Changes&quot;: and accept the incoming changes for the component &quot;tools.TurboLIFT.Engine&quot;.
      </li>
    </ol>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1542720459079" ID="ID_1434775327" MODIFIED="1554892952440" TEXT="Misc">
<node CREATED="1542720464189" ID="ID_590192096" MODIFIED="1542720748173" TEXT="Add Beyond Compare as compare tool">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      istar Preferences:
    </p>
    <p>
      Team -&gt;
    </p>
    <p>
      &#160;Jazz source control -&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;External Compare Tools -&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Select External compare tool to use as Beyond Comare.
    </p>
    <p>
      
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1554896750220" ID="ID_1471536766" MODIFIED="1554896753526" TEXT="Admin">
<node CREATED="1554896756166" ID="ID_1189578257" MODIFIED="1554896771191" TEXT="Creating a new component"/>
<node CREATED="1554896774963" ID="ID_1369396910" MODIFIED="1554896786451" TEXT="Naming the component"/>
<node CREATED="1554896797533" ID="ID_1282556302" MODIFIED="1554896837472" TEXT="Arrange components in a hierarchial order"/>
<node CREATED="1554896841711" ID="ID_1841926333" MODIFIED="1554896853091" TEXT="Creating a new Stream for a project"/>
<node CREATED="1554896854686" ID="ID_360765019" MODIFIED="1554896871128" TEXT="Updating a component baseline"/>
</node>
</node>
<node CREATED="1554896401256" ID="ID_1684751051" MODIFIED="1554896404580" POSITION="right" TEXT="FAQ">
<node CREATED="1554896410809" ID="ID_1568063263" MODIFIED="1554896428199" TEXT="How to know if files are checked into the RWS"/>
</node>
<node CREATED="1472571935106" ID="ID_859349078" MODIFIED="1554896099747" POSITION="right" TEXT="Migration sequence">
<node CREATED="1472572223660" ID="ID_686061790" MODIFIED="1554893009956" TEXT="Phase 1: On every checkpoint the SCM files will be copied to MKS">
<node CREATED="1472572143465" ID="ID_404394449" MODIFIED="1472572409505" TEXT="Migrate Tools project">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      To get experience with SCM without complicated component/stream structure
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1472572414049" ID="ID_283909140" MODIFIED="1472572505430" TEXT="Make structural changes to Engine.common in MKS to make it compatible with SCM"/>
<node CREATED="1472572347373" ID="ID_1643643560" MODIFIED="1472572360049" TEXT="Migrate Engine.common"/>
</node>
</node>
</node>
</map>
