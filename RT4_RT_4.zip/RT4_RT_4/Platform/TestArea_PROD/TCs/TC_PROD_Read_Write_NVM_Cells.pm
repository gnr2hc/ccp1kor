#### TEST CASE MODULE
package TC_PROD_Read_Write_NVM_Cells;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use INCLUDES_Project;    #necessary
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_CD_CAN;
use LIFT_can_access;

#include further modules here

##################################

our $PURPOSE = "to check the PD services to write to and read from NVM cells by block ID";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Read_Write_NVM_Cells

=head1 PURPOSE

to check the PD services to write to and read from NVM cells by block ID

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Set <Test_Condition>


I<B<Stimulation and Measurement>>

1. Send $tcpar_Prod_Diag_Request1 to write data <CellContentValue> to the NVM cells.

2. Immediately after the response for step 1 is received, send $tcpar_Prod_Diag_Request2 to read from these NVM cells.

3. Reset ECU and send $tcpar_Prod_Diag_Request2 to read from the same NVM cells.

4. Send $tcpar_Prod_Diag_Request3 to read ECU status

5. Read the fault recorder.


I<B<Evaluation>>

1. $tcpar_Prod_Diag_Response1 is received.

2. $tcpar_Prod_Diag_Response2 is received. The read bytes have the same value that was written in step 1.

3. $tcpar_Prod_Diag_Response2 is received - response is same as that obtained in step 2.

4. $tcpar_Prod_Diag_Response3 is received and Data Flash Status byte is: 0x00 (reserved)

5. No CRC fault is seen.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of TC
	SCALAR 'Test_Condition' => condition to be set before TC execution 
	SCALAR 'Prod_Diag_Request1' => Write_NVM_Cells
	SCALAR 'Prod_Diag_Response1' => PR_Write_NVM_Cells
	SCALAR 'Prod_Diag_Request2' => Read_NVM_Cells
	SCALAR 'Prod_Diag_Response2' => PR_Read_NVM_Cells
	SCALAR 'Prod_Diag_Request3' =  'ECU_Status'
	SCALAR 'Prod_Diag_Response3' =  'PR_ECU_Status'
	HASH 'RequestLabel' => each parameter of the request
	SCALAR 'CellContentValue' => value to be written/that was written


=head2 PARAMETER EXAMPLES

	purpose	= 'to check the PD services to write to and read from NVM cells by block ID - valid conditions, positive response'
	
	Test_Condition = 'none'
	Prod_Diag_Request1 = 'Write_NVM_Cells'
	Prod_Diag_Response1 = 'PR_Write_NVM_Cells'
	Prod_Diag_Request2 = 'Read_NVM_Cells'
	Prod_Diag_Response2 = 'PR_Read_NVM_Cells'
	Prod_Diag_Request3 =  'ECU_Status'
	Prod_Diag_Response3 =  'PR_ECU_Status'
	RequestLabel = %('NumberOfCells' => '00 01', 'NVMIndication' => '2', 'NVMBlockID' => 'NVMBlockIDMin', 'NVMSubBlockID' => 'NVMSubBlockIDMin', 'Offset' => '00 00')
	
	CellContentValue = '01'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Test_Condition;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_Prod_Diag_Request3;
my $tcpar_Prod_Diag_Response3;
my $tcpar_RequestLabel;
my $tcpar_CellContentValue;
my $tcpar_Service_Timeout;
my $tcpar_TransmitFrameTimeout;

################ global parameter declaration ###################
#add any global variables here
my (
	$WriteNVMCells_response_step1, $ReadNVMCells_response_step2, $ReadNVMCells_response_step3, $flt_mem_struct,             $numberOfCells,            $modified_request,          $NRCInfo,  $NVMcells_RequestLabel,
	$readNVMCells_response_begin,  $initCellContentValue,        $Trace_StoredfilePath,        $Writereqresp_hashref_step1, $Writecellresp_time_step1, $ReadReqresp_hashref_step2, $numCells, $ECUStatus_response,
);

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Test_Condition       = S_read_mandatory_testcase_parameter('Test_Condition');
	$tcpar_Prod_Diag_Request1   = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1  = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Request2   = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2  = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_Prod_Diag_Request3   = S_read_mandatory_testcase_parameter('Prod_Diag_Request3');
	$tcpar_Prod_Diag_Response3  = S_read_mandatory_testcase_parameter('Prod_Diag_Response3');
	$tcpar_RequestLabel         = S_read_mandatory_testcase_parameter( 'RequestLabel', 'byref' );
	$tcpar_CellContentValue     = S_read_mandatory_testcase_parameter('CellContentValue');
	$tcpar_Service_Timeout      = S_read_mandatory_testcase_parameter('Service_Timeout');
	$tcpar_TransmitFrameTimeout = S_read_mandatory_testcase_parameter('TransmitFrameTimeout');

	$NVMcells_RequestLabel = GEN_replaceAddressFromParameterFile( $tcpar_RequestLabel, 'NvM_Cfg' );
	$numberOfCells = $NVMcells_RequestLabel->{'NumberOfCells'};

	#construct byte 5 to 8 based (NVMBlockDetails in mapping file)
	$NVMcells_RequestLabel->{'NVMBlockDetails'} = $NVMcells_RequestLabel->{'NVMIndication'} . $NVMcells_RequestLabel->{'NVMBlockID'} . " " . $NVMcells_RequestLabel->{'NVMSubBlockID'} . $NVMcells_RequestLabel->{'Offset'};

	if ( $tcpar_Test_Condition =~ m/^NVMOperationNotSuccessful$/i ) {
		S_set_error( "This condition cannot be created", 0 );
		return 0;
	}

	$numCells = getNumOfCellshex($numberOfCells);

	if ( $tcpar_CellContentValue =~ m/^CellContent_NumberOfCellsMax$/i ) {
		my @cellContent;
		foreach my $index ( 1 .. $numCells ) {
			if ( $index > 255 ) { $index = 255; }
			push( @cellContent, uc( sprintf( "%02x", $index ) ) );
		}
		$NVMcells_RequestLabel->{'CellContentValue'} = join( ' ', @cellContent );
		$tcpar_CellContentValue = $tcpar_RequestLabel->{'CellContentValue'};
	}
	else {
		$NVMcells_RequestLabel->{'CellContentValue'} = $tcpar_CellContentValue;
	}

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Set condition $tcpar_Test_Condition", 'AUTO_NBR' );
	S_w2log( 4, "Condition $tcpar_Test_Condition is set as part of the test step itself", 'blue' );

	if ( $tcpar_Prod_Diag_Response1 eq 'PR_Write_NVM_Cells' ) {
		S_w2rep( "Read the Cell Content Value to write it back at the end of the test case", 'blue' );
		$readNVMCells_response_begin = DIAG_PD_request_general( "REQ_Read_NVM_Cells", "PR_Read_NVM_Cells", $NVMcells_RequestLabel );
		$initCellContentValue = getCellContentValue($readNVMCells_response_begin);
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Send request $tcpar_Prod_Diag_Request1 to write data CellContentValue to the NVM cells with condition '$tcpar_Test_Condition'", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", $NVMcells_RequestLabel, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition =~ m/^BlockLengthLess$/i or $tcpar_Test_Condition =~ m/^NumberOfCells_Zero$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", $NVMcells_RequestLabel, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition eq 'RAMBufferNotAvailable' ) {

		#difficult to create this condition. Try to send 22 20 00 (Read Generic Memory - DSM version from NVM) and immediately (after 10 ms) send Fast Diag request
		GDCOM_set_addressing_mode("CD");    #to send a CD request
		CD_CAN_send_request_wait_response( [ 0x22, 0x20, 0x00 ], undef, undef, undef, 0 );    #dont wait for response (22 20 00 reads from NVM)
		GDCOM_set_addressing_mode("PD");
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1", $NVMcells_RequestLabel );
	}
	elsif ( $tcpar_Test_Condition eq 'InvalidatedNVMID' ) {
		S_w2rep( "Do nothing as write NVM have no NRC24, just only check for read NVM", 'blue' );

	}
	else {
		S_teststep_2nd_level( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
		CA_simulation_stop();
		S_wait_ms(500);
		CA_simulation_start();

		GDCOM_CA_trace_start();
		$WriteNVMCells_response_step1 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1", $NVMcells_RequestLabel );
		$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(1);
		GDCOM_CA_trace_stop("$Trace_StoredfilePath");
		$Writereqresp_hashref_step1 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	}

	S_teststep( "Immediately after the response for step 1 is received, send $tcpar_Prod_Diag_Request2 to read from these NVM cells with condition '$tcpar_Test_Condition'", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", $NVMcells_RequestLabel, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition =~ m/^BlockLengthLess$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", $NVMcells_RequestLabel, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition eq 'RAMBufferNotAvailable' ) {

		#difficult to create this condition. Try to send 22 20 00 (Read Generic Memory - DSM version from NVM) and immediately (after 10 ms) send Fast Diag request
		GDCOM_set_addressing_mode("CD");    #to send a CD request
		CD_CAN_send_request_wait_response( [ 0x22, 0x20, 0x00 ], undef, undef, undef, 0 );    #dont wait for response (22 20 00 reads from NVM)
		GDCOM_set_addressing_mode("PD");
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2", $NVMcells_RequestLabel );

		#send again
		S_wait_ms( 1000, 'wait after previous step' );
		GDCOM_set_addressing_mode("CD");                                                      #to send a CD request
		CD_CAN_send_request_wait_response( [ 0x22, 0x20, 0x00 ] );                            #now wait for response
		GDCOM_set_addressing_mode("PD");
		DIAG_PD_request_general( "REQ_Read_NVM_Cells", "PR_Read_NVM_Cells", $NVMcells_RequestLabel );    #positive response is expected!
	}
	else {
		S_teststep_2nd_level( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
		CA_simulation_stop();
		S_wait_ms(500);
		CA_simulation_start();

		GDCOM_CA_trace_start();
		$ReadNVMCells_response_step2 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2", $NVMcells_RequestLabel );
		$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(1);
		GDCOM_CA_trace_stop("$Trace_StoredfilePath");
		$ReadReqresp_hashref_step2 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	}

	S_teststep( "Reset ECU and send request $tcpar_Prod_Diag_Request2 to read from the same NVM cells with condition '$tcpar_Test_Condition'", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU and login to ECU", 'AUTO_NBR' );
	GEN_Power_on_Reset();

	PD_ECUlogin();
	S_wait_ms( 500, 'waiting sometime after ECU login' );

	S_teststep_2nd_level( "Send the request '$tcpar_Prod_Diag_Request2' with condition '$tcpar_Test_Condition'", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", $NVMcells_RequestLabel, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition =~ m/^BlockLengthLess$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", $NVMcells_RequestLabel, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_Test_Condition eq 'RAMBufferNotAvailable' ) {

		#difficult to create this condition. Try to send 22 20 00 (Read Generic Memory - DSM version from NVM) and immediately (after 10 ms) send Fast Diag request

		GDCOM_set_addressing_mode("CD");    #to send a CD request
		CD_CAN_send_request_wait_response( [ 0x22, 0x20, 0x00 ], undef, undef, undef, 0 );    #dont wait for response (22 20 00 reads from NVM)
		GDCOM_set_addressing_mode("PD");
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2", $NVMcells_RequestLabel );
	}
	else {
		$ReadNVMCells_response_step3 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2", $NVMcells_RequestLabel );
	}

	S_teststep( "Send request '$tcpar_Prod_Diag_Request3'", 'AUTO_NBR' );
	$ECUStatus_response = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request3", "$tcpar_Prod_Diag_Response3" );

	S_teststep( "Check no fault should appear in memory after read and write NVM", 'AUTO_NBR' );

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 3000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep_2nd_level( "Read memory", 'AUTO_NBR' );
	S_wait_ms( 5000, 'wait for fault qualify if have' );
	$flt_mem_struct = PD_ReadFaultMemory();

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_Prod_Diag_Response1 eq 'PR_Write_NVM_Cells' ) {    #evaluate only if positive response is expected
		S_teststep( "Evaluation for Step 1: Response is received within $tcpar_Service_Timeout seconds", 'AUTO_NBR' );
		$Writecellresp_time_step1 = { "REQ_$tcpar_Prod_Diag_Request1" => "5000", };
		DIAG_EVAL_ResponseTime_from_dataref( $Writereqresp_hashref_step1, $Writecellresp_time_step1, $NVMcells_RequestLabel, undef, undef, '<' );
	}

	if ( $tcpar_Prod_Diag_Response2 eq 'PR_Read_NVM_Cells' ) {     #evaluate only if positive response is expected
		S_teststep( "Evaluation for Step 2a. response $tcpar_Prod_Diag_Response2 is received. The read bytes have the same value that was written in step 1.", 'AUTO_NBR' );
		evaluateCellContentValue( $ReadNVMCells_response_step2, $tcpar_CellContentValue );

		if ( $numCells > 7 ) {
			S_teststep_2nd_level( "Evaluation for Step 2b. For long responses, timing of the consecutive frames shall be less than $tcpar_TransmitFrameTimeout ms", 'AUTO_NBR' );
			DIAG_PD_EVAL_consecutiveFrameTiming( $ReadReqresp_hashref_step2, $tcpar_TransmitFrameTimeout, '<' );
		}

		S_teststep_2nd_level( "Evaluation for Step 3. response $tcpar_Prod_Diag_Response2 is received - response is same as that obtained in step 2.", 'AUTO_NBR' );
		evaluateCellContentValue( $ReadNVMCells_response_step3, $tcpar_CellContentValue );
	}

	S_teststep( "Evaluation for Step 4.  $tcpar_Prod_Diag_Response3 is received and Data Flash Status byte is: 0x00 (reserved)", 'AUTO_NBR' );
	evaluateDataFlashStatus( $ECUStatus_response, 0x00 );

	S_teststep( "Evaluation for Step 5. No new faults are qualified in the fault memory (like SDM, CRC faults) due to writing of NvM cells", 'AUTO_NBR' );
	PD_evaluate_faults( $flt_mem_struct, [] );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	if ( $tcpar_Prod_Diag_Response1 eq 'PR_Write_NVM_Cells' ) {
		S_teststep_2nd_level( "Write the Cell Content Value back into the cells", 'AUTO_NBR' );
		$NVMcells_RequestLabel->{'CellContentValue'} = $initCellContentValue;
		DIAG_PD_request_general( "REQ_Write_NVM_Cells", "PR_Write_NVM_Cells", $NVMcells_RequestLabel );
		GEN_Power_on_Reset();
	}

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;
}

sub getCellContentValue {
	my $response = shift;

	my @Bytes_response = split( / /, $response );
	my $numofCells = getNumOfCellshex($numberOfCells);

	my @CellContentValueBytes;

	#my $num = 1 + $numofCells;
	foreach my $index ( 1 .. $numofCells ) {
		push( @CellContentValueBytes, $Bytes_response[$index] );
	}
	return join( ' ', @CellContentValueBytes );

}

sub evaluateCellContentValue {
	my $response = shift;
	my $expected = shift;

	my $cellContentValue = getCellContentValue($response);

	EVAL_evaluate_string( "Evaluation of CellContentValue", $expected, $cellContentValue );

}

sub getNumOfCellshex {
	my $numOfCellsString = shift;

	return 1 if $main::opt_offline;

	my $numOfCells = GEN_byteString2hexaref($numOfCellsString);

	my $num = S_hex2dec( S_aref2hex($numOfCells) );
	S_w2log( '5', "number of cells: $num", 'brown' );
	return $num;

}

sub evaluateDataFlashStatus {
	my $response      = shift;
	my $expectedValue = shift;

	return 1 if $main::opt_offline;

	my $ECUStatusBytes = GEN_byteString2hexaref($response);
	EVAL_evaluate_value( "Expected Data Flash Status byte is $expectedValue", @$ECUStatusBytes[3], '==', $expectedValue );

}

1;
