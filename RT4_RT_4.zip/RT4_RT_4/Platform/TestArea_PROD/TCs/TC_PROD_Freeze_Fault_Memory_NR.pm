#### TEST CASE MODULE
package TC_PROD_Freeze_Fault_Memory_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_labcar;
##################################
our $PURPOSE = 'To check the supported NRC for the Freeze Fault Memory service';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_Freeze_Fault_Memory_NR;

=head1 PURPOSE
'To check the supported NRC for the Freeze Fault Memory  service'

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1

Set the "Test_Precondition"
 
[stimulation & measurement]

1. Set the <Test_Precondition> and send <Prod_Diag_Request1>  and check the response of the <Prod_Diag_Request1>

2. Create one External Fault and read the fault memory

3. Perform Reset and read the fault memory

[evaluation]

1. Verify the response of the <Prod_Diag_Response1> 

2. Fault should be present  in  the fault memory (for NRC22, fault will not be in fault memory)
 
3. Fault should be present  in  the fault memory
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'Test_PreCondition                       ' ->  '  Precondition before sending  the request  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '

=head2 PARAMETER EXAMPLES
	   

TC_PROD_Freeze_Fault_Memory_NR.NoSecurityAccessL1]   #ID: TS_PRD2564
Test_PreCondition = 'DIAG_PD_Login_Level1_IncorrectKey'
Prod_Diag_Response1='NR_Freeze_Fault_Memory_securityAccessDenied'
# From here on: applicable Lift Default Parameters
purpose			='To check the supported NRC for the Freeze Fault Memory  service'
Test_Precondition =' None'
Prod_Diag_Request1='Freeze_Fault_Memory'




=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_Test_Precondition,
	$defaultpar_Prod_Diag_Response1,
	$defaultpar_purpose,
	$defaultpar_Prod_Diag_Request1,

);
my $windiag_flt_mem_struct_afterfreeze;
my $windiag_flt_mem_struct_afterreset;
my $ReadMemory_Response_observed_afterfreeze;
my $ReadMemory_Response_observed_afterreset;
my $ReadMemory_EventID_Status_ref_afterfreeze;
my $ReadMemory_EventID_Status_ref_afterreset;

############# Parameters from const files ################

################ global parameter declaration ##################

sub TC_set_parameters {

	$defaultpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Test_Precondition   = S_read_optional_testcase_parameter('Test_Precondition');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	my $NRCInfo_ref;
	my $freeze_request_string;

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(5000);

	S_teststep( "Set the Test_Precondition '$defaultpar_Test_Precondition' and  send  REQUEST:'$defaultpar_Prod_Diag_Request1' and check the response of the  Prod_Diag_Request1 to Freeze the Memory.", 'AUTO_NBR' );
	if ( lc($defaultpar_Test_Precondition) =~ m/BlockLengthMore/i ) {
		$freeze_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", undef, +1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
		PD_ECUlogin();
		DIAG_PD_request( $freeze_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( lc($defaultpar_Test_Precondition) =~ m/BlockLengthLess/i ) {
		$freeze_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", undef, -1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
		PD_ECUlogin();
		DIAG_PD_request( "05", $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'}, undef, undef, undef, undef, 'NO' );
	}
	elsif ( lc($defaultpar_Test_Precondition) =~ m/FreezeRequestTwice/i ) {
		S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
		PD_ECUlogin();
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "PR_Freeze_Fault_Memory" );
		S_w2rep("Send request again");

		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	}
	elsif ( lc($defaultpar_Test_Precondition) =~ m/NoSecurityAccess/i ) {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	}
	else {
		S_set_error( "Wrong parameter: Test_Precondition", 109 );
	}

	S_teststep( "Step Create one External Fault 'rb_sqm_SquibResistanceOpenAB1FD_flt' and read the fault memory'", 'AUTO_NBR' );
	FM_createFault('rb_sqm_SquibResistanceOpenAB1FD_flt');
	S_wait_ms(10000);

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Send request 'REQ_Read_Fault_Memory__Primary' to read fault memory", 'AUTO_NBR' );
	$windiag_flt_mem_struct_afterfreeze        = PD_ReadFaultMemory();
	$ReadMemory_Response_observed_afterfreeze  = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Primary", "PR_Read_Fault_Memory__Primary" );
	$ReadMemory_EventID_Status_ref_afterfreeze = FM_PD_get_EventID_Status($ReadMemory_Response_observed_afterfreeze);

	S_teststep( "Perform Reset and then read fault memory.", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(5000);

	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR' );
	$windiag_flt_mem_struct_afterreset        = PD_ReadFaultMemory();
	$ReadMemory_Response_observed_afterreset  = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Primary", "PR_Read_Fault_Memory__Primary" );
	$ReadMemory_EventID_Status_ref_afterreset = FM_PD_get_EventID_Status($ReadMemory_Response_observed_afterreset);

	S_teststep( "Remove fault:'rb_sqm_SquibResistanceOpenAB1FD_flt' \n", 'AUTO_NBR' );
	FM_removeFault('rb_sqm_SquibResistanceOpenAB1FD_flt');

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( "Evaluation for Step 1.Verify the response of the  RESPONSE: '$defaultpar_Prod_Diag_Response1' ", 'blue' );
	S_w2rep('Evaluation for this step is done in stimulation and measurement');

	my $exp_eventID = sprintf( "%04x", PD_GetFaultID('rb_sqm_SquibResistanceOpenAB1FD_flt') );

	if ( $defaultpar_Test_Precondition =~ m/FreezeRequestTwice/i ) {
		S_w2rep( "Evaluation Step 2.Fault should not be present in the fault memory", 'blue' );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_afterfreeze, $exp_eventID, 'notpresent' );
	}
	else {
		S_w2rep( "Evaluation Step 2.Fault should be present in the fault memory", 'blue' );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_afterfreeze, $exp_eventID, '0bxxxx1111' );
	}

	S_w2rep( " Evaluation Step 3.Fault should be present in the fault memory'", 'blue' );
	FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_afterreset, $exp_eventID, '0bxxxx1111' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove Fault", 'AUTO_NBR' );
	FM_removeFault("rb_sqm_SquibResistanceOpenAB1FD_flt");
	S_wait_ms(8000);
	
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

1;
__END__
