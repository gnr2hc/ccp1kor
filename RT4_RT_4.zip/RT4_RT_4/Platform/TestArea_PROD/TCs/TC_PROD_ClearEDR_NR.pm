#### TEST CASE MODULE
package TC_PROD_ClearEDR_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_crash_simulation;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_labcar;

#include further modules here
################################# #

our $PURPOSE = "to test the negative response for clear EDR prodiag service";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ClearEDR_NR

=head1 PURPOSE

to test the negative response for clear EDR prodiag service

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Inject an airbag deployment crash and wait for 5 seconds

2. Create <condition>

3. Send <Prod_Diag_Request1> to clear the EDR and wait for 10 seconds

4. Send <Prod_Diag_Request2> with <DID_1>


I<B<Evaluation>>

3. Negative response <Prod_Diag_Response1> is received

4. Response <Prod_Diag_Response2> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Prod_Diag_Response1' => label from mapping file for clear EDR response
	SCALAR 'purpose' => purpose of this TC
	SCALAR 'condition' => condition to be created like BlockLengthMore, EDRStorageInProgress
	SCALAR 'Prod_Diag_Request1' => label from mapping file to clear the EDR
	SCALAR 'Prod_Diag_Request2' => label from mapping file to read the EDR
	SCALAR 'Prod_Diag_Response2' => label from mapping file for read EDR
	LIST 'DID_1' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to test the negative response for clear EDR prodiag service'
	condition = 'BlockLengthMore'
	Prod_Diag_Request1 = 'Clear_EDR'
	Prod_Diag_Request2 = 'Read_EDR'
	Prod_Diag_Response2 = 'PR_Read_EDR' 
	DID_1 = @('FD 00')
	Prod_Diag_Response1 = 'NR_Clear_EDR_incorrectMessageLengthOrInvalidFormat' 

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_condition;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_DID_1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Crashcode;
my $tcpar_ResultDB;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_condition           = S_read_mandatory_testcase_parameter('condition');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_DID_1               = S_read_mandatory_testcase_parameter('DID_1');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Crashcode           = S_read_optional_testcase_parameter('Crash_Code');
	$tcpar_ResultDB            = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB            = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Initialize and prepare for crash injection", 'AUTO_NBR' );
	S_teststep_2nd_level( "Get crash settings for crash $tcpar_Crashcode", 'AUTO_NBR' );
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	S_teststep_2nd_level( "Set environments for crash as per result DB", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my ( $requestLabel, $modified_request, $NRCInfo );
	$requestLabel->{'DID'} = $$tcpar_DID_1[0];

	S_teststep( "Inject '$tcpar_Crashcode' and wait for 5 seconds", 'AUTO_NBR' );
	S_teststep_2nd_level( "Trigger crash", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_wait_ms( 1000, "Wait after trigger crash (Not yet finish)" );

	S_teststep( "Create '$tcpar_condition'", 'AUTO_NBR' );
	S_w2rep("Send '$tcpar_Prod_Diag_Request1' to clear the EDR and wait for 10 seconds");
	if ( $tcpar_condition eq 'BlockLengthMore' ) {
		S_w2rep("Increase block length by 1");
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", undef, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);
		S_teststep_2nd_level( "Wait for 15s", 'AUTO_NBR' );
		S_wait_ms( 15000, "Wait after trigger crash" );

		S_teststep_2nd_level( "Send request '$modified_request'", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_condition eq 'BlockLengthLess' ) {
		S_w2rep("Reduce block length by 1");
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", undef, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);

		S_teststep_2nd_level( "Wait for 15s", 'AUTO_NBR' );
		S_wait_ms( 15000, "Wait after trigger crash" );

		S_teststep_2nd_level( "Send request '$modified_request'", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_condition eq 'EDRStorageInProgress' or $tcpar_condition eq 'CrashOutputStorageInProgress' ) {
		S_w2rep("Inject Crash and immediately send the clear request");
		S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );
	}
	elsif ( $tcpar_condition eq 'EDRErasureInProgress' ) {

		S_teststep_2nd_level( "Wait for 15s", 'AUTO_NBR' );
		S_wait_ms( 15000, "Wait after trigger crash" );

		S_teststep_2nd_level( "First send request 'REQ_Clear_EDR'", 'AUTO_NBR' );
		DIAG_PD_request_general( 'REQ_Clear_EDR', 'PR_Clear_EDR' );    #first clear is successful
		S_wait_ms( 200, "Wait after send first request" );

		S_teststep_2nd_level( "Second send request 'REQ_Clear_EDR'", 'AUTO_NBR' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );    #previous clear in progress
	}
	elsif ( $tcpar_condition eq 'CrashOutputErasureInProgress' ) {
		$PURPOSE = "Not possible to exclusively create this condition: CrashOutputErasureInProgress";
		S_set_error("Not possible to exclusively create this condition: CrashOutputErasureInProgress");
		return 0;
	}
	else {
		S_teststep_2nd_level( "Wait for 15s", 'AUTO_NBR' );
		S_wait_ms( 15000, "Wait after trigger crash" );

		S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );            #no special condition
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );
	}

	S_wait_ms( 10000, "wait after sending the clear request" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request2' with DID '$$tcpar_DID_1[0]'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", $tcpar_Prod_Diag_Response2, $requestLabel );

	S_teststep( "Clear EDR recoder", 'AUTO_NBR' );
	S_teststep_2nd_level( "Power down ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_2nd_level( "Power up ECU", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Erase EDR", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	return 1;
}

sub TC_evaluation {

	S_w2rep( "The evaluation already done in 'TC_stimulation_and_measurement'", 'blue' );

	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
