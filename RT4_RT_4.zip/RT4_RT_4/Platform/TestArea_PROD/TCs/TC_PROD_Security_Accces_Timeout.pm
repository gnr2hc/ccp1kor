#### TEST CASE MODULE
package TC_PROD_Security_Accces_Timeout;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use GENERIC_DCOM;
use INCLUDES_Project;    #necessary

#include further modules here

##################################

our $PURPOSE = "to check the security access timeout";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Security_Accces_Timeout

=head1 PURPOSE

to check the security access timeout

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Send Prod_Diag_Request1

2. Verify the response of the Prod_Diag_Request1

3. send the Prod_Diag_Request2 after waitTime Minutes

4. Verify the response of the Prod_Diag_Request2


I<B<Evaluation>>

2. Response Prod_Diag_Response1 should be received

4. Response Prod_Diag_Response2 should be received .


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of the TC
	SCALAR 'Prod_Diag_Request1' => request Clear_Fault_Memory
	SCALAR 'Prod_Diag_Request2' => request ECU_Status
	SCALAR 'Prod_Diag_Response1' => response for Clear_Fault_Memory request
	SCALAR 'Prod_Diag_Response2' => response for ECU_Status request
	SCALAR 'waitTime' => time to wait after 1st request


=head2 PARAMETER EXAMPLES

	purpose	 = 'If the security access of the Prodiag is granted and there is no Prodiag activity (new service received or fast diagnosis active) for 5 minutes the security access shall be cleared'
	Prod_Diag_Request1	= 'Clear_Fault_Memory'
	Prod_Diag_Request2	= 'ECU_Status'
	
	Prod_Diag_Response1	= 'PR_Clear_Fault_Memory'
	Prod_Diag_Response2	= 'PR_ECU_Status'
	waitTime = 4

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Response2;
my $tcpar_waitTime;

################ global parameter declaration ###################
#add any global variables here
my $PD_RequestLabel = { "Mode" => "00", };

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_waitTime            = S_read_mandatory_testcase_parameter('waitTime');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send request $tcpar_Prod_Diag_Request1");
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1", $PD_RequestLabel );

	S_teststep("Send request $tcpar_Prod_Diag_Request2 after $tcpar_waitTime seconds");
	S_teststep_2nd_level( "Wait for '$tcpar_waitTime*1000' second ", 'AUTO_NBR' );
	S_wait_ms( $tcpar_waitTime * 1000 );    #in ms

	S_teststep_2nd_level( "Send the request $tcpar_Prod_Diag_Request2", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2" );

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation is done in TC_stimulation_and_measurement", 'blue' );
	return 1;
}

sub TC_finalization {

	GDCOM_set_addressing_mode("physical");

	return 1;
}

1;
