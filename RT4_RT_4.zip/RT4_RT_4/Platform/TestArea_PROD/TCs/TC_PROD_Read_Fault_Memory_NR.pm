#### TEST CASE MODULE
package TC_PROD_Read_Fault_Memory_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
##################################

our $PURPOSE = 'To check the supported NRC for the Read Fault Memory $10 service';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_Read_Fault_Memory_NR;

=head1 PURPOSE

 ' NRC 13 should report when the block Length is more than 0x03 for Plant memory'
=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1

Set the "Test_Precondition"
 
[stimulation & measurement]

1. Send <Prod_Diag_Request1>  as soon as  <Test_Precondition> is set.

[evaluation]

1. Verify the response of the <Prod_Diag_Response1> should be received
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Test_Precondition                       ' ->  ' Pre Conditions before the read Memory service  is sent  '
    SCALAR 'subfunction                             ' ->  ' Subfuntion for read Service '
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_Read_Fault_Memory_NR.BlockLenghLess_Plant_NRC13]   #ID: TS_PROD2422
purpose = ' NRC 13 should report when the block Length is more than 0x03 for Plant memory'
# From here on: applicable Lift Default Parameters
Test_Precondition = BlockLenghLess
subfunction = ''
Prod_Diag_Request1 ='Read_Fault_Memory__Plant'
Prod_Diag_Response1='NR_Read_Fault_Memory_incorrectMessageLengthOrInvalidFormat'
# From here on: the connection to Doors

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Test_Precondition, $defaultpar_subfunction, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, );

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $ClearFaultmemory_Label, $NRCInfo_ref, $readmemory_request_string );

sub TC_set_parameters {

	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Test_Precondition   = S_read_mandatory_testcase_parameter('Test_Precondition');
	$defaultpar_subfunction         = S_read_optional_testcase_parameter('subfunction');
	$defaultpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Set test condition that is will not include in request", 'AUTO_NBR' );
	if ( lc($defaultpar_Test_Precondition) =~ m /Clear_Fault_Memory/i ) {
		$ClearFaultmemory_Label = { "Mode" => "00", };
		DIAG_PD_request_general( "REQ_Clear_Fault_Memory", "PR_Clear_Fault_Memory", $ClearFaultmemory_Label );
	}

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request1' as soon as '$defaultpar_Test_Precondition' condition is set.", 'AUTO_NBR' );
	my $readmemorylabel;
	if ( lc($defaultpar_Test_Precondition) =~ m /blocklengthmore/i ) {
		$readmemory_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", undef, +1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		DIAG_PD_request( $readmemory_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( lc($defaultpar_Test_Precondition) =~ m /blocklengthless/i ) {
		$readmemory_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", undef, -1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		DIAG_PD_request( $readmemory_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( lc($defaultpar_Test_Precondition) =~ m /invalidsubfunction/i ) {
		$readmemorylabel = { "subfunction" => "$defaultpar_subfunction" };
		DIAG_PD_request_general( "REQ_Read_Fault_Memory__InvalidSubFunction", "$defaultpar_Prod_Diag_Response1", $readmemorylabel );
	}
	else {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	}

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( 'All Evaluation is done in TC_stimulation_and_measurement', 'blue' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

1;
__END__
