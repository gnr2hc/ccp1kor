#### TEST CASE MODULE
package TC_PROD_ECU_Status_EDR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.48
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_crash_simulation;
use LIFT_PD;
use LIFT_labcar;
#include further modules here
use GENERIC_DCOM;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check the ECU Status byte for EDR";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ECU_Status_EDR

=head1 PURPOSE

to check the ECU Status byte for EDR

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Inject a crash of type <CrashType>

2. Send <Prod_Diag_Request1> to read the ECU status as soon as crash injection is initiated and wait for 5 seconds

3. Send <Prod_Diag_Request1> to read the ECU status

4. Send <Prod_Diag_Request2> to clear the EDR and then immediately send  <Prod_Diag_Request1> to read the ECU status

5. After 5 seconds, send <Prod_Diag_Request 1> to read the ECU status

6. Set <TestCondition> and send the <Prod_Diag_Request1>


I<B<Evaluation>>

2. <Prod_Diag_Response1> is received

EDR status byte (byte2) is: 

	<DataCollectorStatus>
	<PedproStatus>
	<CrashOutputStatus>
	FieldDataRecorderStatus = 0
	AnyCrashStoredStatus = 0

3. <Prod_Diag_Response1> is received for the ECU status request

EDR status byte is: 

	DataCollectorStatus = 0
	PedproStatus = 0
	CrashOutputStatus = 0
	FieldDataRecorderStatus = 0
	AnyCrashStoredStatus = 1

4. <Prod_Diag_Response2> is received for the clear EDR request. 

<Prod_Diag_Response1> is received for the ECU status request.

EDR status byte (byte2) is: 

	<DataCollectorStatus>
	<PedproStatus>
	<CrashOutputStatus>
	FieldDataRecorderStatus = 0
	AnyCrashStoredStatus = 1

5. <Prod_Diag_Response1> is received

EDR status byte is: 

	DataCollectorStatus = 0
	PedproStatus = 0
	CrashOutputStatus = 0
	FieldDataRecorderStatus = 0
	AnyCrashStoredStatus = 0

6. <Prod_Diag_Response3> is received 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CrashOutput' => yes or no. CrashOutput = 'yes' means crash output data would be written for this crash
	SCALAR 'DataCollectorStatus' => 1 or 0. 1 if normal record would be written for this crash
	SCALAR 'PedproStatus' => 1 or 0. 1 if pedpro (EPP) record would be written for this crash
	SCALAR 'CrashOutputStatus' => 1 or 0. 1 if crash output data would be written for this crash
	SCALAR 'purpose' => purpose of the test case
	SCALAR 'CrashType' => label of crash to be injected like 'FrontInflatableDeployment' (define file path in Mapping_EDR)
	SCALAR 'TestCondition' => condition to be created like BlockLengthMore
	SCALAR 'Prod_Diag_Request1' => label from mapping file for request to read the ECU status
	SCALAR 'Prod_Diag_Response1' => label from mapping file for ECU status response
	SCALAR 'Prod_Diag_Request2' => label from mapping file to clear the EDR
	SCALAR 'Prod_Diag_Response2' => label from mapping file for clear EDR positive response


=head2 PARAMETER EXAMPLES

	purpose	= 'to check the ECU Status byte for EDR'
	CrashType = 'FrontInflatableDeployment'
	TestCondition = 'none'
	Prod_Diag_Request1 =  'ECU_Status'
	Prod_Diag_Response1 =  'PR_ECU_Status'
	Prod_Diag_Request2 =  'Clear_EDR'
	Prod_Diag_Response2 =  'PR_Clear_EDR'
	CrashOutput = 'yes' #this crash should trigger storage to crash output data
	DataCollectorStatus = 1
	PedproStatus = 0
	CrashOutputStatus = 1

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_CrashType;
my $tcpar_TestCondition;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_Prod_Diag_Response3;
my $tcpar_CrashOutput;
my $tcpar_DataCollectorStatus;
my $tcpar_PedproStatus;
my $tcpar_CrashOutputStatus;
my $tcpar_Crashcode;
my $tcpar_ResultDB;
my $tcpar_T0;
################ global parameter declaration ###################
#add any global variables here
my ( $ECU_Status_Response_Duringcrash_string, $ECU_Status_Response_Aftercrash_string, $ECU_Status_Response_DuringErasure_string, $ECU_Status_Response_AfterErasure_string, );
my ( @ECU_Status_Response_Duringcrash_array,  @ECU_Status_Response_Aftercrash_array,  @ECU_Status_Response_DuringErasure_array,  @ECU_Status_Response_AfterErasure_array, );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_CrashType           = S_read_mandatory_testcase_parameter('CrashType');
	$tcpar_TestCondition       = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_Prod_Diag_Response3 = S_read_optional_testcase_parameter('Prod_Diag_Response3');
	$tcpar_CrashOutput         = S_read_optional_testcase_parameter('CrashOutput');
	$tcpar_DataCollectorStatus = S_read_optional_testcase_parameter('DataCollectorStatus');
	$tcpar_PedproStatus        = S_read_optional_testcase_parameter('PedproStatus');
	$tcpar_CrashOutputStatus   = S_read_optional_testcase_parameter('CrashOutputStatus');
	$tcpar_Crashcode           = S_read_optional_testcase_parameter('Crash_Code');
	$tcpar_ResultDB            = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB            = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	$tcpar_T0                  = S_read_optional_testcase_parameter('T0');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Initialize and prepare for crash injection", 'AUTO_NBR' );
	S_teststep_2nd_level( "Get crash settings for crash $tcpar_Crashcode", 'AUTO_NBR' );
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	S_teststep_2nd_level( "Set environments for crash as per result DB", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my ( $ecustatus_request_string, $NRCInfo_ref );

	S_teststep( "Trigger crash", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_wait_ms( ($tcpar_T0), "Wait after trigger crash (Not yet finish)" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to read the ECU status as soon as crash injection is initiated and wait for 15 seconds", 'AUTO_NBR', "request_in_crash_duration" );
	$ECU_Status_Response_Duringcrash_string = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );
	S_wait_ms( 15000, "wait after crash injection" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to read the ECU status", 'AUTO_NBR', "request_after_crash_duration" );
	$ECU_Status_Response_Aftercrash_string = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );

	S_teststep( "Send '$tcpar_Prod_Diag_Request2' to clear the EDR and then immediately send  '$tcpar_Prod_Diag_Request1' to read the ECU status", 'AUTO_NBR' );
	S_teststep_2nd_level( "Send request clear EDR: '$tcpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", $tcpar_Prod_Diag_Response2 );

	S_teststep_2nd_level( "Send request read ECU status: '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR', "request_in_clearEDR_duration" );
	$ECU_Status_Response_DuringErasure_string = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );

	S_teststep( "After 5 seconds, send '$tcpar_Prod_Diag_Request1' to read the ECU status", 'AUTO_NBR', "request_after_clearEDR_duration" );
	S_wait_ms( 5000, 'wait after erase request' );
	$ECU_Status_Response_AfterErasure_string = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );

	S_teststep( "Set condition '$tcpar_TestCondition' and send the '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	if ( $tcpar_TestCondition =~ m/BlockLengthMore/i ) {
		$ecustatus_request_string = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", undef, +1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response3);
		DIAG_PD_request( $ecustatus_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( $tcpar_TestCondition =~ m/BlockLengthLess/i ) {
		S_w2rep("Cannot create condition $tcpar_TestCondition as service request only have 1 byte");
	}
	elsif ( $tcpar_TestCondition =~ m/none/i ) {
		S_w2rep("No condition to be set for this test case");
	}

	S_teststep( "Clear EDR recoder", 'AUTO_NBR' );
	S_teststep_2nd_level( "Power down ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_2nd_level( "Power up ECU", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Erase EDR", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	return 1;
}

sub TC_evaluation {

	@ECU_Status_Response_Duringcrash_array = split( / /, $ECU_Status_Response_Duringcrash_string );
	foreach (@ECU_Status_Response_Duringcrash_array) { $_ = "0x$_"; }

	@ECU_Status_Response_Aftercrash_array = split( / /, $ECU_Status_Response_Aftercrash_string );
	foreach (@ECU_Status_Response_Aftercrash_array) { $_ = "0x$_"; }

	@ECU_Status_Response_DuringErasure_array = split( / /, $ECU_Status_Response_DuringErasure_string );
	foreach (@ECU_Status_Response_DuringErasure_array) { $_ = "0x$_"; }

	@ECU_Status_Response_AfterErasure_array = split( / /, $ECU_Status_Response_AfterErasure_string );
	foreach (@ECU_Status_Response_AfterErasure_array) { $_ = "0x$_"; }

	#offline mode handling
	if ($main::opt_offline) {
		@ECU_Status_Response_Duringcrash_array   = ( 0x49, 0x00, 0x00, 0x00 );
		@ECU_Status_Response_Aftercrash_array    = ( 0x49, 0x00, 0xFF, 0x00 );
		@ECU_Status_Response_DuringErasure_array = ( 0x49, 0x00, 0xFF, 0x00 );
		@ECU_Status_Response_AfterErasure_array  = ( 0x49, 0x00, 0x00, 0x00 );
	}

	S_teststep_expected( "The bit status should be: DataCollectorStatus = $tcpar_DataCollectorStatus, PedproStatus = $tcpar_PedproStatus, CrashOutputStatus = $tcpar_CrashOutputStatus, FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 1", "request_in_crash_duration" );
	S_teststep_detected( "The byte status '@ECU_Status_Response_Duringcrash_array[2]'", "request_in_crash_duration" );

	S_teststep( "Check: DataCollectorStatus = $tcpar_DataCollectorStatus in step 2", 'AUTO_NBR' );
	EVAL_evaluate_value( "DataCollectorStatus during crash", @ECU_Status_Response_Duringcrash_array[2], 'MASK', "0bxxxxxxx" . $tcpar_DataCollectorStatus );

	S_teststep( "Check: PedproStatus = $tcpar_PedproStatus", 'AUTO_NBR' );
	EVAL_evaluate_value( "PedproStatus during crash", @ECU_Status_Response_Duringcrash_array[2], 'MASK', "0bxxxxxx" . $tcpar_PedproStatus . "x" );

	S_teststep( "Check: CrashOutputStatus = $tcpar_CrashOutputStatus", 'AUTO_NBR' );
	EVAL_evaluate_value( "CrashOutputStatus during crash", @ECU_Status_Response_Duringcrash_array[2], 'MASK', "0bxxxxx" . $tcpar_CrashOutputStatus . "xx" );

	S_teststep( "Check: FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 0", 'AUTO_NBR' );
	EVAL_evaluate_value( "FieldDataRecorderStatus, AnyCrashStoredStatus during crash", @ECU_Status_Response_Duringcrash_array[2], 'MASK', "0b0xxx0xxx" );

	S_teststep_expected( "The bit status should be: DataCollectorStatus = 0, PedproStatus = 0, CrashOutputStatus = 0, FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 1", "request_after_crash_duration" );
	S_teststep_detected( "The byte status '@ECU_Status_Response_Aftercrash_array[2]'", "request_after_crash_duration" );

	S_teststep("Check: DataCollectorStatus = 0, PedproStatus = 0, CrashOutputStatus = 0, FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 1");
	EVAL_evaluate_value( "EDR status after crash", @ECU_Status_Response_Aftercrash_array[2], 'MASK', "0b1xxx0000" );

	S_teststep_expected( "The bit status should be: DataCollectorStatus = $tcpar_DataCollectorStatus, PedproStatus = $tcpar_PedproStatus, CrashOutputStatus = $tcpar_CrashOutputStatus, FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 1", "request_in_clearEDR_duration" );
	S_teststep_detected( "The byte status '@ECU_Status_Response_DuringErasure_array[2]'", "request_in_clearEDR_duration" );

	S_teststep( "Check: DataCollectorStatus = $tcpar_DataCollectorStatus in step 2", 'AUTO_NBR' );
	EVAL_evaluate_value( "DataCollectorStatus during clear", @ECU_Status_Response_DuringErasure_array[2], 'MASK', "0bxxxxxxx" . $tcpar_DataCollectorStatus );

	S_teststep( "Check: PedproStatus = $tcpar_PedproStatus", 'AUTO_NBR' );
	EVAL_evaluate_value( "PedproStatus during clear", @ECU_Status_Response_DuringErasure_array[2], 'MASK', "0bxxxxxx" . $tcpar_PedproStatus . "x" );

	S_teststep( "Check: CrashOutputStatus = $tcpar_CrashOutputStatus", 'AUTO_NBR' );
	EVAL_evaluate_value( "CrashOutputStatus during clear", @ECU_Status_Response_DuringErasure_array[2], 'MASK', "0bxxxxx" . $tcpar_CrashOutputStatus . "xx" );

	S_teststep( "Check: FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 1", 'AUTO_NBR' );
	EVAL_evaluate_value( "FieldDataRecorderStatus, AnyCrashStoredStatus during clear", @ECU_Status_Response_DuringErasure_array[2], 'MASK', "0b1xxx0xxx" );

	S_teststep_expected( "The bit status should be: DataCollectorStatus = 0, PedproStatus = 0, CrashOutputStatus = 0, FieldDataRecorderStatus = 0, AnyCrashStoredStatus = 0", "request_after_clearEDR_duration" );
	S_teststep_detected( "The byte status '@ECU_Status_Response_AfterErasure_array[2]'", "request_after_clearEDR_duration" );
	EVAL_evaluate_value( "EDR status after crash", @ECU_Status_Response_AfterErasure_array[2], 'MASK', "0b0xxx0000" );

	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
