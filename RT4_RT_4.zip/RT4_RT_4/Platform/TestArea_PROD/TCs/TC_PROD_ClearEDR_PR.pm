#### TEST CASE MODULE
package TC_PROD_ClearEDR_PR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_crash_simulation;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = "to test the clearing of EDR entries using prodiag services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ClearEDR_PR

=head1 PURPOSE

to test the clearing of EDR entries using prodiag services

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Clear the EDR using prodiag service


I<B<Stimulation and Measurement>>

1. Inject <crash> and wait for 5 seconds

2. Send <Prod_Diag_Request1> to clear the EDR and wait for 5 seconds

3. Send <Prod_Diag_Request2> with <DID_1> to read EDR

4. Inject <crash>, <count> times and wait for 5 seconds

5. Send <Prod_Diag_Request1> to clear the EDR and wait for 10 seconds

6. Send <Prod_Diag_Request2> with <DID_All> to read all entries

7. Send <Prod_Diag_Request1> to clear the EDR


I<B<Evaluation>>

2. Positive response <Prod_Diag_Response1> is received

3. Negative response <Prod_Diag_Response2> is received since the EDR is empty

5. Positive response <Prod_Diag_Response1> is received

6. Negative response <Prod_Diag_Response2> is received since all EDRs are empty

7. Positive response <Prod_Diag_Response1> is received (even though the EDRs are empty)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'crash' => label of crash to be injected like 'FrontInflatableDeployment' (define file path in Mapping_EDR)
	LIST 'DID_All' => list of all supported read EDR DIDs
	LIST 'DID_1' => DID to read first record
	SCALAR 'purpose' => purpose of this TC
	SCALAR 'count' => number of crashes to be injected (should be equal to the number of crash records supported in the project)
	SCALAR 'Prod_Diag_Request1' => label from mapping file to clear the EDR
	SCALAR 'Prod_Diag_Request2' => label from mapping file to read the EDR
	SCALAR 'Prod_Diag_Response1' => label from mapping file for clear EDR response
	SCALAR 'Prod_Diag_Response2' => label from mapping file for read EDR negative response NRC55


=head2 PARAMETER EXAMPLES

	purpose = 'to test the clearing of EDR entries using prodiag services'
	count = '2' #number of crash telegrams (in AB12 CA)
	Prod_Diag_Request1 = 'Clear_EDR'
	Prod_Diag_Request2 = 'Read_EDR'
	Prod_Diag_Response1 = 'PR_Clear_EDR'
	Prod_Diag_Response2 = 'NR_Read_EDR_crashRecorderEmpty' #NRC55
	crash = 'FrontInflatableDeployment'
	DID_All = @('FD 00','FD 01') #2 EDRs for AB12 CA
	DID_1 = @('00')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_count;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Response2;
my $tcpar_Crash_Code;
my $tcpar_DID_All;
my $tcpar_DID_1;
my $tcpar_ResultDB;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_count               = S_read_mandatory_testcase_parameter('count');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_DID_All             = S_read_mandatory_testcase_parameter('DID_All');
	$tcpar_DID_1               = S_read_mandatory_testcase_parameter('DID_1');
	$tcpar_Crash_Code          = S_read_optional_testcase_parameter('Crash_Code');
	$tcpar_ResultDB            = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB            = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Clear the EDR using prodiag service", 'AUTO_NBR' );
	DIAG_PD_request_general( 'REQ_Clear_EDR', 'PR_Clear_EDR' );

	S_teststep( "Initialize and prepare for crash injection", 'AUTO_NBR' );
	S_teststep_2nd_level( "Get crash settings for crash $tcpar_Crash_Code", 'AUTO_NBR' );
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crash_Code };
	my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crash_Code not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	S_teststep_2nd_level( "Set environments for crash as per result DB", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my $requestLabel;

	S_teststep( "Inject '$tcpar_Crash_Code' and wait for 15 seconds", 'AUTO_NBR' );
	S_teststep_2nd_level( "Trigger crash", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep_2nd_level( "Wait for 15s", 'AUTO_NBR' );
	S_wait_ms( 15000, "Wait after trigger crash" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to clear the EDR and wait for 10 seconds", 'AUTO_NBR' );
	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1' to clear EDR", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );

	S_teststep_2nd_level( "Wait 10s after clear EDR", 'AUTO_NBR' );
	S_wait_ms( 10000, "Wait after clearing the EDR" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request2' with DID '@$tcpar_DID_1' to read EDR", 'AUTO_NBR' );
	$requestLabel->{'DID'} = $$tcpar_DID_1[0];
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", $tcpar_Prod_Diag_Response2, $requestLabel );

	S_teststep("Inject '$tcpar_Crash_Code', '$tcpar_count' times and wait for 5 seconds");
	foreach ( 1 .. $tcpar_count ) {
		S_teststep_2nd_level( "Inject crash $_ times", 'AUTO_NBR' );
		CSI_TriggerCrash();
		S_wait_ms( 5000, "Wait after trigger crash" );
	}

	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to clear the EDR and wait for 10 seconds", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );
	S_wait_ms( 10000, "wait after clearing the EDR" );

	S_teststep( "Send '$tcpar_Prod_Diag_Request2' with DIDs '@$tcpar_DID_All' to read all entries", 'AUTO_NBR' );
	foreach (@$tcpar_DID_All) {
		S_teststep_2nd_level( "Read DID $_", 'AUTO_NBR' );
		$requestLabel->{'DID'} = $_;
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", $tcpar_Prod_Diag_Response2, $requestLabel );
	}
	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to clear the EDR", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response1 );

	return 1;
}

sub TC_evaluation {

	S_w2rep( "The evaluation already done in 'TC_stimulation_and_measurement'", 'blue' );

	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
