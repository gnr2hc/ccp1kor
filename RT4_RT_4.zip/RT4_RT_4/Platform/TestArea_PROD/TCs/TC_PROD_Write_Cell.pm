#### TEST CASE MODULE
package TC_PROD_Write_Cell;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
use Data::Dumper;
##################################

our $PURPOSE = "To check the Write Cell request and response values";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Write_Cell  $Revision: 1.1 $


=head1 PURPOSE

This service shall be able to write cells and response for  writing of the RAM/ROM  cells within 2msec'


=head1 TESTCASE DESCRIPTION 

[initialisation]
1.GEN_StandardPrepNoFault

2.Set the addressing mode to PD

3.DIAG_PD_Login_Level1
    
[stimulation & measurement]
 1. Send <Prod_Diag_Request2>   to read the RAM Cells before write service request 

2. Set the <Test_Condition>

3. Send <Prod_Diag_Request1>  and check the response of the <Prod_Diag_Request1>to write the  RAM section  

4. Send <Prod_Diag_Request2>  to read the RAM Cells
after write service request.

5. Check the RAM cell content in step 1 and step4


[evaluation]
1. Prod_Diag_Response1> should be received and the RAM cell content value be 'RAMcontent_BeforewriteService'

2. <Test_Conditions> should be active.

3. Verify the response of the <Prod_Diag_Response1> should be received with in <Max_WriteCell_Response_Time> ms.

4. Prod_Diag_Response2> should be receivednd the RAM cell content value be 'RAMcontent_AfterwriteService'

5. 'RAMcontent_BeforewriteService' and 'RAMcontent_AfterwriteService' should  be 'Writecell_status'

    
[finalisation]

1. <Test_Conditions> should be inactive.
2  Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			    -> 'purpose of the test case'
	SCALAR 'Prod_Diag_Request1'                     -> 'Request label for Write_Cell from  the Diagmapping File '
	SCALAR 'Prod_Diag_Response1'                    -> 'Response label for Write_Cell from  the Diagmapping File '
	SCALAR 'Prod_Diag_Request2'                     -> 'Request label for Read_Cell from  the Diagmapping File '
	SCALAR 'Prod_Diag_Response2'                    -> 'Response label for Read_Cell from  the Diagmapping File '
	SCALAR 'Start_Address'                           		-> 'Read Cell Start byte (RAM)/'
	SCALAR 'NumberOfCells'                     		-> Number of clees to be write in hex
	SCALAR 'Max_WriteCell_Response_Time'             ->  Maximum time to receiving the response for writecell Request from the ECU. '
	SCALAR 'Test_Condition'                           		-> 'Condition need to be set for the testcases '
	SCALAR 'Writecell_status'                           		-> 'Wriring status (Equal/notEqual)'

=head2 PARAMETER EXAMPLES
	   
	[TC_PROD_Write_Cell_RAM.18]   #ID: SRTP_PRD2499
CellContentValue=' 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24'
# From here on: applicable Lift Default Parameters
purpose			='This service shall be able to write the RAM Cells and response for  writing of the RAM  cells within 2msec'
Max_WriteCell_Response_Time = 2 # ms 
Prod_Diag_Request1		= 'Write_Cell'
StartAddress = '00 00 00 00'
NumberOfCells = '00 18'
Prod_Diag_Response1='PR_Write_Cell'
Prod_Diag_Request2='Read_Cell'
Prod_Diag_Response2='PR_Read_Cell'
Test_Condition= 'None'
Writecell_status ='NotEqual'



=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_purpose,
	$defaultpar_Prod_Diag_Request1,
	$defaultpar_Prod_Diag_Response1,
	$defaultpar_Prod_Diag_Request2,
	$defaultpar_Prod_Diag_Response2,
	$defaultpar_Start_Address,
	$defaultpar_NumberOfCells,
	$defaultpar_Max_WriteCell_Response_Time,
	$defaultpar_Test_Condition,
	$defaultpar_Writecell_status,
	$defaultpar_CellContentValue,
	$defaultpar_State1,
	$defaultpar_State2,
	$defaultpar_SignalValue,
	$defaultpar_Signal,
	$defaultpar_Message_Name,

);

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $Trace_StoredfilePath, $writereqresp_hashref_step3, $lamp_states_href1, $lamp_states_href2 );

my ( $writecellresp_time_withtol_step3, $Readcell_RequestLabel, $Writecell_RequestLabel, );

my ( $ReadResponse_observed_step1, $ReadResponse_observed_step4, );

my $testcondition_status;

sub TC_set_parameters {

	$defaultpar_purpose                     = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1          = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1         = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2          = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2         = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_Start_Address               = S_read_mandatory_testcase_parameter('StartAddress');
	$defaultpar_NumberOfCells               = S_read_mandatory_testcase_parameter('NumberOfCells');
	$defaultpar_CellContentValue            = S_read_mandatory_testcase_parameter('CellContentValue');
	$defaultpar_Max_WriteCell_Response_Time = S_read_mandatory_testcase_parameter('Max_WriteCell_Response_Time');
	$defaultpar_NumberOfCells               = S_read_mandatory_testcase_parameter('NumberOfCells');
	$defaultpar_Test_Condition              = S_read_optional_testcase_parameter('Test_Condition');
	$defaultpar_Writecell_status            = S_read_mandatory_testcase_parameter('Writecell_status');
	$defaultpar_State1                      = S_read_mandatory_testcase_parameter('State1');
	$defaultpar_State2                      = S_read_mandatory_testcase_parameter('State2');
	$defaultpar_SignalValue                 = S_read_optional_testcase_parameter('SignalValue');
	$defaultpar_Signal                      = S_read_optional_testcase_parameter('Signal');
	$defaultpar_Message_Name                = S_read_optional_testcase_parameter('Message_Name');

	return 1;

}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my $protocol = _get_communication_type();

	S_teststep( "Preparing the hash for the read cell", 'AUTO_NBR' );
	$Readcell_RequestLabel = {
		"NumberOfCells" => "$defaultpar_NumberOfCells",
		"StartAddress"  => "$defaultpar_Start_Address",
	};

	S_teststep( "Replace the 'RAMstartaddress' with the actual start Addressfrom the .sad File to read cell", 'AUTO_NBR' );
	$Readcell_RequestLabel = GEN_replaceAddressFromParameterFile($Readcell_RequestLabel);

	S_teststep( "Preparing the hash for the write cell", 'AUTO_NBR' );
	$Writecell_RequestLabel = {
		"StartAddress"     => "$defaultpar_Start_Address",
		"CellContentValue" => "$defaultpar_CellContentValue",
	};

	S_teststep( "Replace the 'RAMstartaddress' with the actual start Addressfrom the .sad File to write cell", 'AUTO_NBR' );
	$Writecell_RequestLabel = GEN_replaceAddressFromParameterFile($Writecell_RequestLabel);

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request2' to read the RAM Cells before write service request", 'AUTO_NBR' );
	S_w2rep( "$defaultpar_Prod_Diag_Response2 should be received and the RAM cell content value be 'RAMcontent_BeforewriteService'.\n", 'blue' );
	$ReadResponse_observed_step1 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2", $Readcell_RequestLabel );

	S_teststep_2nd_level( "Stop canoe to void appending data to the existing log file", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(1000);
	CA_simulation_start();

	S_teststep_2nd_level( "Start new logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep( "Set '$defaultpar_Test_Condition' condition", 'AUTO_NBR', 'set test condition' );
	$testcondition_status = _set_test_condition($defaultpar_Test_Condition);

	S_teststep( "Send request:'$defaultpar_Prod_Diag_Request1' and check the response of the '$defaultpar_Prod_Diag_Response1' to write the  RAM section \n", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $Writecell_RequestLabel );

	S_teststep( "Read Warning lamp status after valid request write cells", 'AUTO_NBR', 'check WL after write' );
	S_wait_ms( 5000, "wait for COM timeout fault de-qualify" );

	S_teststep_2nd_level( "Read WL state", 'AUTO_NBR' );
	$lamp_states_href1 = PD_ReadLampStates();

	S_teststep( "Store the request and reponse from the can log file", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(3);

	S_teststep_2nd_level( "Stop logging", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep( "Read the request and reponse from trace and put into the hash reference with '$protocol' protocol", 'AUTO_NBR' );
	$writereqresp_hashref_step3 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	my $dump_ref = Dumper $writereqresp_hashref_step3;
	S_w2rep( "Dump the data into LIFT report: $dump_ref", 'blue' );

	S_teststep( "Send request:'$defaultpar_Prod_Diag_Request2' to read the RAM Cells after write service request", 'AUTO_NBR', 'Check ram content before and after write' );
	S_w2rep( "response '$defaultpar_Prod_Diag_Response2' should be received the RAM cell content value be 'RAMcontent_AfterwriteService'.\n", 'blue' );
	$ReadResponse_observed_step4 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2", $Readcell_RequestLabel );

	S_teststep( "Reset ECU and read WI status after init", 'AUTO_NBR', 'check WL after reset' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	GEN_Power_on_Reset();

	S_teststep_2nd_level( "Start logging to timeout fault dequalify", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 5000, "wait for COM timeout fault de-qualify" );

	S_teststep_2nd_level( "Check memory in report", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep_2nd_level( "Read Warning lamp status after do the reset", 'AUTO_NBR' );
	$lamp_states_href2 = PD_ReadLampStates();

	return 1;

}

sub TC_evaluation {

	S_teststep_expected( "The test condition should be set successful with status 1 ", 'set test condition' );
	S_teststep_detected( "The status got is: $testcondition_status", 'set test condition' );
	EVAL_evaluate_value( "Test_Conditions status", $testcondition_status, '==', 1 );

	S_teststep( "Verify the response of the Prod_Diag_Response1 should be received with in Max_WriteCell_Response_Time (2) ms.\n", 'AUTO_NBR' );
	$writecellresp_time_withtol_step3 = { "REQ_$defaultpar_Prod_Diag_Request1" => "$defaultpar_Max_WriteCell_Response_Time%0", };
	DIAG_EVAL_ResponseTime_from_dataref( $writereqresp_hashref_step3, $writecellresp_time_withtol_step3, $Writecell_RequestLabel, undef, undef, '<=' );

	S_teststep_expected( "The warning lamp after write should be had state = '$defaultpar_State1'", 'check WL after write' );
	S_teststep_detected( "The warning lamp after write detected is=  $lamp_states_href1->{'System Warning Lamp'} ", 'check WL after write' );
	EVAL_evaluate_string( "Check the warning lamp after write", $defaultpar_State1, $lamp_states_href1->{'System Warning Lamp'}, '==' );
	S_teststep_expected( "'RAMcontent_AfterwriteService should be '$defaultpar_Writecell_status' with '$ReadResponse_observed_step1'", 'Check ram content before and after write' );
	if ( $defaultpar_Writecell_status eq 'Equal' ) {
		EVAL_evaluate_string( "Writecell_status", $ReadResponse_observed_step1, $ReadResponse_observed_step4, '==' );
	}
	elsif ( $defaultpar_Writecell_status eq 'NotEqual' ) {
		EVAL_evaluate_string( "Writecell_status", $ReadResponse_observed_step1, $ReadResponse_observed_step4, '!=' );
	}
	else {
		S_set_error( "SYNTAX: Writecell_status parameter should be 'Equal / NotEqual' but received is $defaultpar_Writecell_status", 109 );
	}
	S_teststep_detected( "The RAMcontent_AfterwriteService is: $ReadResponse_observed_step4", 'Check ram content before and after write' );

	S_teststep_expected( "The warning lamp after do the reset should be '$defaultpar_State2'", 'check WL after reset' );
	S_teststep_detected( "The warning lamp detected  after do the reset is: $lamp_states_href2->{'System Warning Lamp'} ", 'check WL after reset' );
	EVAL_evaluate_string( "Check the warning lamp after reset", $defaultpar_State2, $lamp_states_href2->{'System Warning Lamp'}, '==' );
	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 5000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;

}

sub _get_communication_type {

	my $LIFT_COM_Type = $LIFT_config::LIFT_Testbench->{'Devices'}{'PDLayer'}{'BusType'};

	return $LIFT_COM_Type;
}

sub _set_test_condition {

	my $condition = shift;
	my $status    = 0;
	if ( $condition eq 'SetVehicleSpeed' and defined $defaultpar_SignalValue and defined $defaultpar_Signal ) {
		$status = CA_write_can_signal( $defaultpar_Signal, $defaultpar_SignalValue, 'phys' );
		S_wait_ms( 2000, 'wait for write value' );
	}
	elsif ( $condition eq 'Normal' ) {
		S_w2rep( "Normal condition, so do nothing", 'blue' );
		$status = 1;
	}
	elsif ( $condition eq 'Vehiclespeedunknown' and defined $defaultpar_Message_Name ) {
		S_w2rep( "Set timeout for message '$defaultpar_Message_Name'", 'blue' );
		$status = COM_stopMessages( [$defaultpar_Message_Name], 'CAN' );    #CAN only, condititon will be removed when stop and start canoe.
	}
	else {
		S_set_error( "Condition '$condition' not support ", 22 );
	}
	return $status;
}

1;
__END__
