#### TEST CASE MODULE
package TC_PROD_Consecutive_Frames_From_Tester;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use INCLUDES_Project;    #necessary
use LIFT_general;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_CD_CAN;
use LIFT_PD;
use LIFT_can_access;

#include further modules here

##################################

our $PURPOSE = "to check the ECU behaviour with respect to interframe delay";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Consecutive_Frames_From_Tester

=head1 PURPOSE

to check the ECU behaviour with respect to interframe delay

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

SecurityAccess__Seed_Level1

Note: Select the request such that the length of the request is more than 8 bytes which has 4 consecutive frames


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request1> with time gap between each frame as <interFrameDelay>

2. Immediately after this, send <Prod_Diag_Request2>


I<B<Evaluation>>

1. Response <Prod_Diag_Response1> is received after all the consecutive frames are sent.

2. Response <Prod_Diag_Response2> is received.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of TC
	SCALAR 'Consecutive_Frames_Timeout' => max allowed time gap between consecutive frames
	SCALAR 'Prod_Diag_Request1' => request with multiple frames - Write_Cell
	SCALAR 'Prod_Diag_Response1' => response for Write_Cell
	SCALAR 'Prod_Diag_Request2' => request ECU_Status
	SCALAR 'Prod_Diag_Response2' => response for ECU_Status
	HASH 'RequestLabel' => labels corresponding to Write_Cell request
	SCALAR 'CellContentValue' => data bytes to be written with Write_Cell


=head2 PARAMETER EXAMPLES

	purpose	= 'The ECU shall be able to receive the consecutive frames from the tester every  3ms up to to <=250ms After timeout it should receive the new request'
	Consecutive_Frames_Timeout =250 #ms
	
	Prod_Diag_Request1 = 'Write_Cell'
	Prod_Diag_Response1 = 'PR_Write_Cell'
	
	Prod_Diag_Request2 = 'ECU_Status'
	Prod_Diag_Response2 = 'PR_ECU_Status'
	
	RequestLabel = %('NumberOfCells' => '00 20', 'StartAddress' => 'RAMstartaddress')
	
	CellContentValue='01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 25 26 27 28 29 30 31 32'
	Prod_Diag_Response1	= 'NoResponse''

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Consecutive_Frames_Timeout;
my $tcpar_interFrameDelay;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_RequestLabel;
my $tcpar_CellContentValue;

################ global parameter declaration ###################
#add any global variables here
my $response1_aref;
my $response2_aref;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                    = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Consecutive_Frames_Timeout = S_read_mandatory_testcase_parameter('Consecutive_Frames_Timeout');
	$tcpar_interFrameDelay            = S_read_mandatory_testcase_parameter('interFrameDelay');
	$tcpar_Prod_Diag_Request1         = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1        = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Request2         = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2        = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_RequestLabel               = S_read_mandatory_testcase_parameter( 'RequestLabel', 'byref' );
	$tcpar_CellContentValue           = S_read_mandatory_testcase_parameter('CellContentValue');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Get the RAM adressing from .sad file", 'AUTO_NBR' );
	$tcpar_RequestLabel = GEN_replaceAddressFromParameterFile($tcpar_RequestLabel);
	$tcpar_RequestLabel->{'CellContentValue'} = $tcpar_CellContentValue;

	S_teststep( "Get the information for '$tcpar_Prod_Diag_Request1' request", 'AUTO_NBR' );
	my $request1 = GDCOM_getRequestLabelValue( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_RequestLabel );
	my $checksum1     = DIAG_PD_calculateChecksum( $request1, 'VALID' );
	my $request1_aref = GEN_byteString2hexaref( $request1 . " $checksum1" );
	my $length1       = scalar @$request1_aref;
	unshift( @$request1_aref, $length1 );

	S_teststep( "Get the information for '$tcpar_Prod_Diag_Request2' request", 'AUTO_NBR' );
	my $request2      = GDCOM_getRequestLabelValue("REQ_$tcpar_Prod_Diag_Request2");
	my $checksum2     = DIAG_PD_calculateChecksum( $request2, 'VALID' );
	my $request2_aref = GEN_byteString2hexaref( $request2 . " $checksum2" );
	my $length2       = scalar @$request2_aref;
	unshift( @$request2_aref, $length2 );

	S_teststep( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();

	GDCOM_CA_trace_start();
	S_teststep( "Send $tcpar_Prod_Diag_Request1 with time gap between each frame as $tcpar_interFrameDelay", 'AUTO_NBR' );
	$response1_aref = CAN_send_request_wait_response( $request1_aref, undef, undef, $tcpar_Consecutive_Frames_Timeout, $tcpar_interFrameDelay );    #to save time

	S_teststep( "Immediately after this, send $tcpar_Prod_Diag_Request2", 'AUTO_NBR' );
	$response2_aref = CAN_send_request_wait_response($request2_aref);                                                                               #to save time

	my $trace_StoredfilePath = GEN_getTraceNameWithTeststep(1);
	GDCOM_CA_trace_stop("$trace_StoredfilePath");

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. $tcpar_Prod_Diag_Response1 is received after all the consecutive frames are sent.", 'AUTO_NBR' );
	return 1 if ($main::opt_offline);
	if ( $tcpar_Prod_Diag_Response1 eq 'PR_Write_Cell' ) {
		if ( defined @$response1_aref[0] ) {
			EVAL_evaluate_value( 'check if positive response is obtained', @$response1_aref[0], '==', 0x42 );    #check first byte of response
		}
		else {
			S_w2rep( "Response is not received for $tcpar_Prod_Diag_Request1", 'red' );
			S_set_verdict(VERDICT_FAIL);
		}
	}
	elsif ( $tcpar_Prod_Diag_Response1 eq 'NoResponse' ) {
		if ( defined @$response1_aref[0] ) {
			S_w2rep( "Response is received for $tcpar_Prod_Diag_Request1", 'red' );
			S_set_verdict(VERDICT_FAIL);
		}
		else {
			S_w2rep( "Response is not received for $tcpar_Prod_Diag_Request1 as expected", 'blue' );
			S_set_verdict(VERDICT_PASS);
		}
	}
	else {
		S_set_error( "response1: $tcpar_Prod_Diag_Response1 is not valid", 109 );
	}

	S_teststep( "Evaluation for Step 2. $tcpar_Prod_Diag_Response2 is received.", 'AUTO_NBR' );
	if ( defined @$response2_aref[0] ) {
		EVAL_evaluate_value( 'check if positive response is obtained', @$response2_aref[0], '==', 0x49 );    #check first byte of response
	}
	else {
		S_w2rep( "Response is not received for $tcpar_Prod_Diag_Request2", 'red' );
		S_set_verdict(VERDICT_FAIL);
	}
	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );

	S_teststep_2nd_level( "Reset and re-start canoe", 'AUTO_NBR' );
	GEN_Power_on_Reset();
	CA_simulation_start();

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
