#### TEST CASE MODULE
package TC_PROD_ProductionDiagnosisDuringSelfTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use INCLUDES_Project;    #necessary
use LIFT_general;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_can_access;

#include further modules here

##################################

our $PURPOSE = "To check that the Production Diagnosis doesnt deactivate any ECU self test";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ProductionDiagnosisDuringSelfTest

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1.PROD_Standard_Preparation



I<B<Stimulation and Measurement>>

1. Reset ECU and after init, check the ITM test status (Test Skipped and Test Finished status)

2. Send a request to perform Fast Diagnosis during startup.

3. Reset the ECU and check for fast diagnosis consecutive frames

4. After init, check the ITM test status


I<B<Evaluation>>

3. Fast diagnosis consecutive frames are sent by the ECU

4. The ITM test status (Test Skipped and Test Finished status) is same as in step 1 (no new test is deactivated)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC


=head2 PARAMETER EXAMPLES

	purpose = 'To check that the production Diagnosis doesnt deactivate any ECU self test'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_COM_Type;

################ global parameter declaration ###################
#add any global variables here
my $itm_TestStarted_step1;
my $itm_TestFinished_step1;
my $itm_TestFailed_step1;
my $itm_TestSkipped_step1;
my $itm_TestStarted_step4;
my $itm_TestFinished_step4;
my $itm_TestFailed_step4;
my $itm_TestSkipped_step4;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose  = S_read_optional_testcase_parameter('purpose');
	$tcpar_COM_Type = S_read_optional_testcase_parameter('COM_Type');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Reset ECU and after init, check the ITM test status (Test Skipped and Test Finished status)", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	GEN_Power_on_Reset();
	S_wait_ms( 2000, "wait for some more time after power on for itm status to be stable" );

	S_teststep_2nd_level( "Read PRD variable for ITM check", 'AUTO_NBR' );
	$itm_TestStarted_step1  = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestStarted_u64') );
	$itm_TestFinished_step1 = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestFinished_u64') );
	$itm_TestFailed_step1   = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestFailed_u64') );
	$itm_TestSkipped_step1  = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestSkipped_u64') );

	S_teststep( "Send a request to perform Fast Diagnosis during startup", 'AUTO_NBR' );
	my $ram_address_href = GEN_fetchAddressFromSADFile();
	my $RequestLabel;

	S_teststep_2nd_level( "Setting for fast diagnostic request: Start in next POC 01, 2 CAN IDs 02, read only one cell and start with RAM address", 'AUTO_NBR' );
	$RequestLabel->{'Options'}       = '24';                                     #StandardCAN 00, Start in next POC 01, 2 CAN IDs 02
	$RequestLabel->{'NumberOfCells'} = '01';
	$RequestLabel->{'RAM_Address'}   = $ram_address_href->{'RAMstartaddress'};
	DIAG_PD_request_general( "REQ_Fast_Diagnostics_" . $tcpar_COM_Type, "PR_Fast_Diagnostics_" . $tcpar_COM_Type . "_StartUp", $RequestLabel );

	S_teststep( "Reset the ECU and check for fast diagnosis consecutive frames", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	GEN_Power_on_Reset();
	S_wait_ms( 2000, "wait for some more time after power on for itm status to be stable" );

	S_teststep_2nd_level( "Check FastDiagnosis Communication", 'AUTO_NBR' );
	_checkFastDiagnosis_Communication();

	S_teststep( "Send one PRD service (ECU_Status) to stop fast diagnostic", 'AUTO_NBR' );
	DIAG_PD_request( "09", "49", 'quiet', 'valid request', 'NO_EVAL' );

	S_teststep( "After init, check the ITM test status", 'AUTO_NBR', 'check the ITM status' );
	$itm_TestStarted_step4  = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestStarted_u64') );
	$itm_TestFinished_step4 = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestFinished_u64') );
	$itm_TestFailed_step4   = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestFailed_u64') );
	$itm_TestSkipped_step4  = S_aref2hex( PD_ReadMemoryByName('rb_itm_TestSkipped_u64') );

	return 1;
}

sub TC_evaluation {

	S_teststep_expected(
		"The ITM status should be same with the original: 
		
	-  Started => $itm_TestStarted_step1
	
	-  Finished=> $itm_TestFinished_step1
	
	-  Failed  => $itm_TestFailed_step1
	
	-  Skipped => $itm_TestSkipped_step1 
	
	", 'check the ITM status'
	);
	S_teststep_detected(
		"The ITM after is:
		
	-  started => $itm_TestStarted_step4
	
	-  Finished=> $itm_TestFinished_step4
	
	-  Failed  => $itm_TestFailed_step4
	
	-  Skipped => $itm_TestSkipped_step4 
	
	", 'check the ITM status'
	);

	EVAL_evaluate_value( "Check for variable Started",  $itm_TestStarted_step4,  '==', $itm_TestStarted_step1 );
	EVAL_evaluate_value( "Check for variable Finished", $itm_TestFinished_step4, '==', $itm_TestFinished_step1 );
	EVAL_evaluate_value( "Check for variable Failed",   $itm_TestFailed_step4,   '==', $itm_TestFailed_step1 );
	EVAL_evaluate_value( "Check for variable Skipped",  $itm_TestSkipped_step4,  '==', $itm_TestSkipped_step1 );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _checkFastDiagnosis_Communication {

	S_teststep( "Avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();
	S_teststep( "Start new trace logging", 'AUTO_NBR' );
	CA_trace_start();
	S_wait_ms(1000);
	my $TracePath = GEN_printLink( CA_trace_store( GEN_generateUniqueTraceName() ) );
	S_teststep( "Stop new trace logging", 'AUTO_NBR' );
	CA_trace_stop();

	my $verdict = 'VERDICT_FAIL';
	unless ( open( FH, $TracePath ) ) {
		S_set_error("Could not open trace file for reading ");
		return;
	}

	while (<FH>) {
		if ( ( $_ =~ m/\d+\.\d+\s+CANFD\s+\d\s+Rx\s+(651|652|653|654|655)/ ) and ( $tcpar_COM_Type eq 'CANFD' ) or ( $_ =~ m/\d+\.\d+\s+\d+\s+(651|652|653|654|655)\s+Rx/ ) and ( $tcpar_COM_Type eq 'CAN' ) ) {
			S_w2rep("Fast diagnostic message found in log file, the frame is: $_ ");
			$verdict = 'VERDICT_PASS';
			last;
		}
	}
	unless ( close(FH) ) {
		S_set_error("Could not close trace file for reading ");
		return;
	}
	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_w2rep( "Fast diagnostic message was not found in log file", 'red' );
	}

	S_set_verdict($verdict);
	S_teststep( "Start again canoe to remove COM timeout fault", 'AUTO_NBR' );
	CA_trace_start();

	return 1;
}

1;
