#### TEST CASE MODULE
package TC_PROD_CustomerLogisticData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = "to check the customer logistic data in NvM";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_CustomerLogisticData

=head1 PURPOSE

to check the customer logistic data in NvM

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Read the customer logistic data in NvM using the variable: rb_prd_ProductionData_dfst.CustomData_au8( )

2. Write some new logistic data to NvM using NvM write service. (Write a 4 byte value starting at address rb_prd_ProductionData_dfst.CustomData_au8(0) )

3. Reset ECU and read the customer logistic data from NvM


I<B<Evaluation>>

1. All 4 bytes should contain the default value of 0x00

3. The value written in step 2 should be stored


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC


=head2 PARAMETER EXAMPLES

	purpose = 'To check the customer logistic data which is stored in NvM'
	
	 

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;

################ global parameter declaration ###################
#add any global variables here
my @read_LogisticData_step1;
my @read_LogisticData_step3;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose = S_read_mandatory_testcase_parameter('purpose');

	return 1;
}

sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Read the customer logistic data in NvM using the variable: rb_prd_ProductionData_dfst.CustomData_au8()", 'AUTO_NBR' );
	foreach my $byte ( 0 .. 3 ) {
		my $val_aref = PD_ReadMemoryByName("rb_prd_ProductionData_dfst.CustomData_au8($byte)");
		push( @read_LogisticData_step1, @$val_aref );
	}

	S_teststep( "Write some new logistic data to NvM using NvM write service. (Write a 4 byte value starting at address rb_prd_ProductionData_dfst.CustomData_au8(0) )", 'AUTO_NBR' );
	foreach my $byte ( 0 .. 3 ) {
		PD_WriteMemoryByName( "rb_prd_ProductionData_dfst.CustomData_au8($byte)", [$byte] );
	}

	S_teststep( "Reset ECU and read the customer logistic data from NvM", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Read some value to variable", 'AUTO_NBR' );
	foreach my $byte ( 0 .. 3 ) {
		my $val_aref = PD_ReadMemoryByName("rb_prd_ProductionData_dfst.CustomData_au8($byte)");
		push( @read_LogisticData_step3, @$val_aref );
	}

	S_teststep( "Write default value", 'AUTO_NBR' );
	foreach my $byte ( 0 .. 3 ) {
		PD_WriteMemoryByName( "rb_prd_ProductionData_dfst.CustomData_au8($byte)", [0] );
	}

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(2000);

	return 1;
}

sub TC_evaluation {

	S_teststep("Evaluation for Step 1. All 4 bytes should contain the default value of 0x00");
	GEN_EVAL_CompareNumArrays( \@read_LogisticData_step1, [ 0, 0, 0, 0 ], 'Equal' );

	S_teststep("Evaluation for Step 3. The value written in step 2 should be stored");
	GEN_EVAL_CompareNumArrays( \@read_LogisticData_step3, [ 0, 1, 2, 3 ], 'Equal' );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
