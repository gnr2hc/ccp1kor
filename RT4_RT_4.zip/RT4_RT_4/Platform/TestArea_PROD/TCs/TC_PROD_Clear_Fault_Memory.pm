#### TEST CASE MODULE
package TC_PROD_Clear_Fault_Memory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use LIFT_labcar;
##################################
our $PURPOSE = "To check the behaviour of Clear services in the production diagnostics with different types of faults and status.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_Clear_Fault_Memory;

=head1 PURPOSE
To check the behaviour of Clear services in the production diagnostics with different types of faults and status.

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1
 
[stimulation & measurement]

1. Create some faults with different states in fault memory (filtered, latched, stored).

2. Send the request to to read the fault Memory  (Plant, Primary, History, Bosch, Distrubance)

3. Set the <Test_Condition> and send <Prod_Diag_Request1>  to erase the fault recorder

4. After the <Prod_Diag_Response1>  is received send <Prod_Diag_Request2>  to read  the status  fault recorder.

5. Send the request to to read the fault Memory  (Plant, Primary, History, Bosch, Distrubance)

6. Send <Prod_Diag_Request2> to read  the ECU status 

7. Reset ECU and send <Prod_Diag_Request2> to read  the ECU status 

[evaluation]

2.All the created faults with Event ID and status are reported in the  corresponding read service

3. Response is <Prod_Diag_Response1> 
and For Mode 1: Response is received within 500  ms.

4. <Prod_Diag_Response2> is received
Bit 0 of Status byte 1 has value <FLM_Status_DuringErase>
Bit 1 of Status byte 1 has value <FLM_Status_LastEraseFailedInCurrentPOC>

5. Fault Erasure is done in 'Fault_Erasure_Memory_Section' locations.
All the Stored only faults are erased.
All the cyclically monitored  Active faults are erased  and qualified again.
All the Init faults  are erased and not qualified again in the same iginition cycle.

6. <Prod_Diag_Response2> is received
Bit 0 of Status byte 1 has value <FLM_Status_AfterErase>
Bit 1 of Status byte 1 has value <FLM_Status_LastEraseFailedInCurrentPOC>

7. <Prod_Diag_Response2> is received
Bit 0 of Status byte 1 has value 0 (erase not active)
Bit 1 of Status byte 1 has value 0 (no erase failure in current POC)
    
[finalisation]

-


=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose' ->  'purpose of the test case'
    SCALAR 'Test_Condition' ->  '   '
    SCALAR 'Fault_Erasure_Memory_Section' ->  '   '
    SCALAR 'Prod_Diag_Request1' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1 ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Request2' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Mode' ->  '   '
    SCALAR 'FLM_Status_DuringErase' ->  '   '
    SCALAR 'FLM_Status_AfterErase' ->  '   '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_Clear_Fault_Memory.Mode0]   #ID: SRTP_PRD1771
# From here on: applicable Lift Default Parameters
purpose			='To check the behaviour of Clear services in the production diagnostics with different types of faults and status.'
Test_Condition ='None'
Fault_Erasure_Memory_Section = @('Plant','Primary', 'History','Bosch','Disturbance')
ECUMode = 'NormalMode' #not in plant mode
Prod_Diag_Request1	=  'Clear_Fault_Memory'
Prod_Diag_Response1	=  'PR_Clear_Fault_Memory'
Prod_Diag_Request2	=  'ECU_Status'
Prod_Diag_Response2	=  'PR_ECU_Status'
Mode = '00'
FLM_Status_DuringErase = 1
FLM_Status_AfterErase = 0
FLM_Status_LastEraseFailedInCurrentPOC = 0

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_purpose,             $defaultpar_Test_Condition, $defaultpar_Fault_Erasure_Memory_Section, $defaultpar_Prod_Diag_Request1,    $defaultpar_Prod_Diag_Response1, $defaultpar_Prod_Diag_Request2,
	$defaultpar_Prod_Diag_Response2, $defaultpar_Mode,           $defaultpar_FLM_Status_DuringErase,       $defaultpar_FLM_Status_AfterErase, $defaultpar_ECUMode,             $defaultpar_FLM_Status_LastEraseFailedInCurrentPOC,
);

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $PD_RequestLabel, $PDresp_time_withtol, $Trace_StoredfilePath, $PDreqresp_hashref_step );

my (
	$PlantMemory_Response_observed_step2,
	$PrimaryMemory_Response_observed_step2,
	$HistoryMemory_Response_observed_step2,
	$BoschMemory_Response_observed_step2,
	$DistrubanceMemory_Response_observed_step2,

	# After Erasure
	$PlantMemory_Response_observed_Step5,
	$PrimaryMemory_Response_observed_Step5,
	$HistoryMemory_Response_observed_Step5,
	$BoschMemory_Response_observed_Step5,
	$DistrubanceMemory_Response_observed_Step5,
);

my (
	$PlantMemory_EventID_Status_ref_step2,
	$PrimaryMemory_EventID_Status_ref_step2,
	$HistoryMemory_EventID_Status_ref_step2,
	$BoschMemory_EventID_Status_ref_step2,
	$DistrubanceMemory_EventID_Status_ref_step2,

	# After Erasure
	$PlantMemory_EventID_Status_ref_Step5,
	$PrimaryMemory_EventID_Status_ref_Step5,
	$HistoryMemory_EventID_Status_ref_Step5,
	$BoschMemory_EventID_Status_ref_Step5,
	$DistrubanceMemory_EventID_Status_ref_Step5,
);

my ( $ECUStatus_Response_observed_step4_href, $ECUStatus_Response_observed_step6, $ECUStatus_Response_observed_step7 );
my @ECU_Status_resp_array;
my $modified_request;
my $NRCInfo;
my $searchField1;
my $searchField2;
my $faults;
my ( $SQfault, $SWfault, $storedFault, $latchedFault );
my $flt_mem_struct_afterErasure;

sub TC_set_parameters {

	$defaultpar_purpose                                = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Test_Condition                         = S_read_mandatory_testcase_parameter('Test_Condition');
	$defaultpar_ECUMode                                = S_read_mandatory_testcase_parameter('ECUMode');
	$defaultpar_Fault_Erasure_Memory_Section           = S_read_mandatory_testcase_parameter('Fault_Erasure_Memory_Section');
	$defaultpar_Prod_Diag_Request1                     = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1                    = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2                     = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2                    = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_Mode                                   = S_read_mandatory_testcase_parameter('Mode');
	$defaultpar_FLM_Status_DuringErase                 = S_read_mandatory_testcase_parameter('FLM_Status_DuringErase');
	$defaultpar_FLM_Status_AfterErase                  = S_read_mandatory_testcase_parameter('FLM_Status_AfterErase');
	$defaultpar_FLM_Status_LastEraseFailedInCurrentPOC = S_read_mandatory_testcase_parameter('FLM_Status_LastEraseFailedInCurrentPOC');

	if ( $defaultpar_Test_Condition eq 'EraseFailure' ) {
		S_set_error( "The condition $defaultpar_Test_Condition cannot be created. Not proceeding!!", 0 );
		return 0;
	}

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set ECU mode', 'AUTO_NBR' );
	if ( $defaultpar_ECUMode eq 'NormalMode' ) {
		S_w2rep("No action taken for normal mode");
	}
	else {
		GEN_setECUMode($defaultpar_ECUMode);
	}

	S_teststep( 'Set the addressing mode to PD ', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( 'Check fault memory before create condition', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#preparing the hash for the read cell
	$PD_RequestLabel = { "Mode" => "$defaultpar_Mode", };

	S_teststep( 'Create some faults with different states in fault memory (filtered, latched, stored).', 'AUTO_NBR' );
	S_teststep_2nd_level( "Fetch info squibs fault", 'AUTO_NBR' );
	$searchField1->{'DeviceType'} = 'Squib';
	$searchField1->{'Condition'}  = 'Openline';
	$faults                       = FM_fetchFaultName($searchField1);
	$SQfault                      = @$faults[0];
	$latchedFault                 = @$faults[1];
	$storedFault                  = @$faults[2];

	S_teststep_2nd_level( "Create squib fault: $SQfault", 'AUTO_NBR' );
	FM_createFault($SQfault);

	S_teststep_2nd_level( "Create stored fault: $storedFault", 'AUTO_NBR' );
	FM_createFault($storedFault);

	S_teststep_2nd_level( "wait for qualification time", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep_2nd_level( "Remove fault stored: $storedFault (make sure fault only stored)", 'AUTO_NBR' );
	FM_removeFault($storedFault);    #dequalify and reset

	S_teststep_2nd_level( "Wait for fault de-qualify", 'AUTO_NBR' );
	S_wait_ms(8000);

	S_teststep( 'Check fault memory appear in LIFT report as expected', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Create and Remove fault latched to make sure bit latched is kept", 'AUTO_NBR' );
	S_teststep_2nd_level( "Create latched fault: $latchedFault", 'AUTO_NBR' );
	FM_createFault($latchedFault);
	S_wait_ms(6000);

	FM_removeFault($latchedFault);    #only dequalify
	S_teststep_2nd_level( "Wait for fault de-qualify", 'AUTO_NBR' );
	S_wait_ms(6000);

	S_teststep( 'Check fault memory appear in LIFT report as expected', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Login after reset", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Set condition to '$defaultpar_ECUMode' mode", 'AUTO_NBR' );
	if ( $defaultpar_ECUMode eq 'NormalMode' ) {
		S_w2rep("No action taken for normal mode");
	}
	else {
		GEN_setECUMode($defaultpar_ECUMode);
	}

	S_teststep( 'Check fault memory appear in LIFT report as expected', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Send the request to to read the fault Memory in (Plant,Primary, History,Bosch,Distrubance)", 'AUTO_NBR' );
	S_teststep_2nd_level( "Read Plant memory", 'AUTO_NBR' );
	$PlantMemory_Response_observed_step2 = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Plant", "PR_Read_Fault_Memory__Plant" );
	$PlantMemory_EventID_Status_ref_step2 = FM_PD_get_EventID_Status($PlantMemory_Response_observed_step2);

	S_teststep_2nd_level( "Wait for reading memory", 'AUTO_NBR' );
	S_wait_ms(500);

	S_teststep_2nd_level( "Read Primary memory", 'AUTO_NBR' );
	$PrimaryMemory_Response_observed_step2 = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Primary", "PR_Read_Fault_Memory__Primary" );
	if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		$PrimaryMemory_EventID_Status_ref_step2 = FM_PD_get_EventID_Status($PrimaryMemory_Response_observed_step2);
	}

	S_teststep_2nd_level( "Wait for reading memory", 'AUTO_NBR' );
	S_wait_ms(500);

	S_teststep_2nd_level( "Read Bosch memory", 'AUTO_NBR' );
	$BoschMemory_EventID_Status_ref_step2 = PD_ReadFaultMemory(3);

	S_teststep_2nd_level( "Wait for reading memory", 'AUTO_NBR' );
	S_wait_ms(500);

	S_teststep_2nd_level( "Read Distrubance memory", 'AUTO_NBR' );

	#To be develop

	S_teststep_2nd_level( "Wait for reading memory", 'AUTO_NBR' );
	S_wait_ms(500);

	S_teststep( 'Check fault memory appear in LIFT report as expected', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Set the testCondition '$defaultpar_Test_Condition' and Send Prod_Diag_Request1::$defaultpar_Prod_Diag_Request1 to erase the fault recorder", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	if ( $defaultpar_Test_Condition eq 'BlockLengthMore' ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", $PD_RequestLabel, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $defaultpar_Test_Condition eq 'BlockLengthLess' ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", $PD_RequestLabel, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $defaultpar_Test_Condition eq 'NoSecurityAccessL1' ) {
		LC_ECU_Reset();
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $PD_RequestLabel );
		S_w2rep( 'Login after reset', 'blue' );
		PD_ECUlogin();
	}
	else {
		S_w2rep( "Send request with condition: $defaultpar_Test_Condition", 'blue' );
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $PD_RequestLabel );
	}

	S_teststep( "Immediately after the response $defaultpar_Prod_Diag_Response1  is received, send $defaultpar_Prod_Diag_Request2 to read  the status  fault recorder cyclically for 1 second", 'AUTO_NBR' );
	foreach my $count ( 1 .. 40 ) {
		S_w2rep("Read ECU status: loop $count");
		$ECUStatus_Response_observed_step4_href->{$count} = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );    # ECU Status
		S_wait_ms( 23, 'wait to send next cyclic request (cycle time of 25ms ==> 2ms response time + 23ms wait)' );
	}

	S_teststep( "Store trace", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(3);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");
	$PDreqresp_hashref_step = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	S_wait_ms( 10000, "wait after clear" );

	S_teststep( 'Send the request to to read the fault Memory (Plant,Primary, History,Bosch,Distrubance) after clear fault memory', 'AUTO_NBR' );
	S_teststep_2nd_level( "Read Plant memory", 'AUTO_NBR' );
	$PlantMemory_Response_observed_Step5 = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Plant", "PR_Read_Fault_Memory__Plant" );
	$PlantMemory_EventID_Status_ref_Step5 = FM_PD_get_EventID_Status($PlantMemory_Response_observed_Step5);

	S_teststep_2nd_level( "Read Primary memory", 'AUTO_NBR' );
	$PrimaryMemory_Response_observed_Step5 = DIAG_PD_request_general( "REQ_Read_Fault_Memory__Primary", "PR_Read_Fault_Memory__Primary" );
	if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		$PrimaryMemory_EventID_Status_ref_Step5 = FM_PD_get_EventID_Status($PrimaryMemory_Response_observed_Step5);
	}

	S_teststep_2nd_level( "Read Bosch memory", 'AUTO_NBR' );
	$BoschMemory_Response_observed_Step5 = PD_ReadFaultMemory(3);

	S_teststep_2nd_level( "Read Distrubance memory", 'AUTO_NBR' );

	#To be develop

	S_teststep( 'Check fault memory appear in LIFT report as expected', 'AUTO_NBR' );
	$flt_mem_struct_afterErasure = PD_ReadFaultMemory();

	S_teststep( "Send Prod_Diag_Request2 '$defaultpar_Prod_Diag_Request2'  to read ECU status", 'AUTO_NBR' );    # ECU Status
	$ECUStatus_Response_observed_step6 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );

	S_teststep( 'Reset ECU and send $defaultpar_Prod_Diag_Request2 to read  the ECU status', 'S_teststep' );     # ECU Status
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Send request '$defaultpar_Prod_Diag_Request2' to read ECU status", 'AUTO_NBR' );
	$ECUStatus_Response_observed_step7 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );

	S_teststep( "Remove fault that actived", 'AUTO_NBR' );
	FM_removeFault($SQfault);
	S_wait_ms(10000);

	S_teststep( "Set condition to '$defaultpar_ECUMode' mode", 'AUTO_NBR' );
	if ( $defaultpar_ECUMode eq 'NormalMode' ) {
		S_w2rep("No action taken for normal mode");
	}
	else {
		GEN_setECUMode('RemovePlantModes');    #remove all plant mode was setting
	}

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $exp_eventID_SQfault, $exp_eventID_latchedFault, $exp_eventID_storedFault );

	S_teststep( 'Evaluation for Step All the created faults Event ID and status should be reported in the  corresponding read service', 'AUTO_NBR' );
	S_teststep_2nd_level( "Check for Squib fault", 'AUTO_NBR' );
	$exp_eventID_SQfault = sprintf( "%04x", PD_GetFaultID($SQfault) );
	FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_step2,   $exp_eventID_SQfault, '0bxxxx1111' ) if ( grep { $_ eq 'Plant' } @$defaultpar_Fault_Erasure_Memory_Section );     #if Fault_Erasure_Memory_Section contains Plant memory
	FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_step2, $exp_eventID_SQfault, '0bxxxx1111' ) if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section );
	if ( grep { $_ eq 'Bosch' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		EVAL_evaluate_value( "Check latched fault status in Bosch fault memory", PD_get_fault_status( $BoschMemory_EventID_Status_ref_step2, $SQfault ), '==', '0x01' );
	}

	S_teststep_2nd_level( "Check for latched fault", 'AUTO_NBR' );
	$exp_eventID_latchedFault = sprintf( "%04x", PD_GetFaultID($latchedFault) );
	FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_step2,   $exp_eventID_latchedFault, '0bxxxx1110' ) if ( grep { $_ eq 'Plant' } @$defaultpar_Fault_Erasure_Memory_Section );
	FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_step2, $exp_eventID_latchedFault, '0bxxxx1110' ) if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section );
	if ( grep { $_ eq 'Bosch' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		EVAL_evaluate_value( "Check latched fault status in Bosch fault memory", PD_get_fault_status( $BoschMemory_EventID_Status_ref_step2, $latchedFault ), '==', '0x00' );
	}

	S_teststep_2nd_level( "Check for stored fault", 'AUTO_NBR' );
	$exp_eventID_storedFault = sprintf( "%04x", PD_GetFaultID($storedFault) );
	FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_step2,   $exp_eventID_storedFault, '0bxxxx1100' ) if ( grep { $_ eq 'Plant' } @$defaultpar_Fault_Erasure_Memory_Section );
	FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_step2, $exp_eventID_storedFault, '0bxxxx1100' ) if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section );
	if ( grep { $_ eq 'Bosch' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		EVAL_evaluate_value( "Check stored fault status in Bosch fault memory", PD_get_fault_status( $BoschMemory_EventID_Status_ref_step2, $storedFault ), '==', '0x00' );
	}

	S_teststep( "Evaluation for Step 3. Verify the response of the Prod_Diag_Response1: $defaultpar_Prod_Diag_Response1", 'AUTO_NBR' );
	S_w2rep( "This step is evaluated in stimulation and measurement itself", 'blue' );

	S_teststep( "Evaluation for Step 4. Verify the response of the Prod_Diag_Response2: $defaultpar_Prod_Diag_Response2", 'AUTO_NBR' );
	S_w2rep( "FLM Erasing Active bit should be set to '$defaultpar_FLM_Status_DuringErase'", 'blue' );
	return 1 if ($main::opt_offline);
	if ( $defaultpar_Mode eq '01' ) {    #for mode = plant memory clear
		S_w2rep( "For Mode 1:  Bit 0 has value $defaultpar_FLM_Status_DuringErase and then changes to  $defaultpar_FLM_Status_AfterErase within 500 ms", 'blue' );
		my $sample;
		foreach my $count ( 1 .. 40 ) {
			my $ECU_Status_resp = GEN_byteString2hexaref( $ECUStatus_Response_observed_step4_href->{$count} );
			if ( ( S_0x2dec( @$ECU_Status_resp[1] ) & 0x01 ) == 0x00 ) {
				$sample = $count;
				last;
			}
		}

		#evaluate erase time
		my $time = $sample * 25;         #sample count * 25 ms
		S_w2rep("Erase status bit is updated within: $time ms");
		EVAL_evaluate_value( "Clear should be completed with 500 ms", $time, '<=', 500 );

		#evaluate bits
		S_w2rep("Evaluation of FLM bits at $time ms");
		my $ECU_Status = GEN_byteString2hexaref( $ECUStatus_Response_observed_step4_href->{$sample} );
		EVAL_evaluate_value( "Bit 0: FLM Erasing Active bit",    @$ECU_Status[1], 'MASK', "0bxxxxxxx$defaultpar_FLM_Status_AfterErase" );
		EVAL_evaluate_value( "Bit 1: Last FLM Erase Failed Bit", @$ECU_Status[1], 'MASK', "0bxxxxxx$defaultpar_FLM_Status_LastEraseFailedInCurrentPOC" . "x" );

		if ( $sample > 1 ) {
			S_w2rep("Evaluation of FLM bits before $time ms");
			$ECU_Status = GEN_byteString2hexaref( $ECUStatus_Response_observed_step4_href->{ $sample - 1 } );
			EVAL_evaluate_value( "Bit 0: FLM Erasing Active bit",    @$ECU_Status[1], 'MASK', "0bxxxxxxx$defaultpar_FLM_Status_DuringErase" );
			EVAL_evaluate_value( "Bit 1: Last FLM Erase Failed Bit", @$ECU_Status[1], 'MASK', "0bxxxxxx$defaultpar_FLM_Status_LastEraseFailedInCurrentPOC" . "x" );
		}
	}
	else {
		S_w2rep( "Bit 0 of Status byte 1 has value $defaultpar_FLM_Status_DuringErase", 'blue' );
		S_w2rep("Evaluation of FLM bits at 500 ms");
		my $ECU_Status = GEN_byteString2hexaref( $ECUStatus_Response_observed_step4_href->{3} );    #take 03 rd sample
		EVAL_evaluate_value( "Bit 0: FLM Erasing Active bit",    @$ECU_Status[1], 'MASK', "0bxxxxxxx$defaultpar_FLM_Status_DuringErase" );
		EVAL_evaluate_value( "Bit 1: Last FLM Erase Failed Bit", @$ECU_Status[1], 'MASK', "0bxxxxxx$defaultpar_FLM_Status_LastEraseFailedInCurrentPOC" . "x" );
	}

	S_teststep( "Evaluation for Step 5. Fault Erasure should be done in @$defaultpar_Fault_Erasure_Memory_Section locations", 'AUTO_NBR' );
	S_w2rep( 'All the cyclically monitored active faults are erased and qualified again', 'blue' );
	S_w2rep( 'All the Stored only faults and latched faults are erased.',                 'blue' );
	EVAL_evaluate_value( 'cyclic faults are present in memory (status not 0)', PD_get_fault_status( $flt_mem_struct_afterErasure, $SQfault ), '!=', 0 );    #fault is present in memory (status not 0)

	if ( grep { $_ eq 'None' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		EVAL_evaluate_value( 'stored fault is present in memory (status not 0)',  PD_get_fault_status( $flt_mem_struct_afterErasure, $storedFault ),  '!=', 0 );    #fault is not present in memory (status 0)
		EVAL_evaluate_value( 'latched fault is present in memory (status not 0)', PD_get_fault_status( $flt_mem_struct_afterErasure, $latchedFault ), '!=', 0 );    #fault is not present in memory (status not 0)
	}
	else {
		EVAL_evaluate_value( 'stored fault is not present in memory (status 0)',  PD_get_fault_status( $flt_mem_struct_afterErasure, $storedFault ),  '==', 0 );    #fault is not present in memory (status 0)
		EVAL_evaluate_value( 'latched fault is not present in memory (status 0)', PD_get_fault_status( $flt_mem_struct_afterErasure, $latchedFault ), '==', 0 );    #fault is not present in memory (status not 0)
	}

	if ( grep { $_ eq 'Plant' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_Step5, $exp_eventID_SQfault,      '0bxxxx1111' );                                               #cyclic faults requalify                                             #cyclic faults requalify
		FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_Step5, $exp_eventID_storedFault,  'notpresent' );
		FM_PD_check_EventID_status( $PlantMemory_EventID_Status_ref_Step5, $exp_eventID_latchedFault, 'notpresent' );
	}
	if ( grep { $_ eq 'Primary' } @$defaultpar_Fault_Erasure_Memory_Section ) {
		FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_Step5, $exp_eventID_SQfault,      '0bxxxx1111' );                                             #cyclic faults requalify
		FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_Step5, $exp_eventID_storedFault,  'notpresent' );
		FM_PD_check_EventID_status( $PrimaryMemory_EventID_Status_ref_Step5, $exp_eventID_latchedFault, 'notpresent' );
	}

	S_teststep( ' Evaluation for Step 6. Verify the response of the Prod_Diag_Response2', 'AUTO_NBR' );
	S_w2rep( "FLM Erasing Active bit should be set to $defaultpar_FLM_Status_AfterErase",                     'blue' );
	S_w2rep( "FLM Last Erase Failed bit should be set to $defaultpar_FLM_Status_LastEraseFailedInCurrentPOC", 'blue' );
	@ECU_Status_resp_array = split( / /, $ECUStatus_Response_observed_step6 );
	EVAL_evaluate_value( "Bit 0: FLM Erasing Active bit",    $ECU_Status_resp_array[1], 'MASK', "0bxxxxxxx$defaultpar_FLM_Status_AfterErase" );
	EVAL_evaluate_value( "Bit 1: Last FLM Erase Failed Bit", $ECU_Status_resp_array[1], 'MASK', "0bxxxxxx$defaultpar_FLM_Status_LastEraseFailedInCurrentPOC" . "x" );

	S_w2rep( 'Evaluation for Step 7. Verify the response of the Prod_Diag_Response2', 'blue' );
	S_w2rep( "FLM Erasing Active bit should be 0",                                    'blue' );
	S_w2rep( "FLM Last Erase Failed bit should be 0",                                 'blue' );
	@ECU_Status_resp_array = split( / /, $ECUStatus_Response_observed_step7 );
	EVAL_evaluate_value( "Bit 0: FLM Erasing Active bit",    $ECU_Status_resp_array[1], 'MASK', "0bxxxxxxx0" );
	EVAL_evaluate_value( "Bit 1: Last FLM Erase Failed Bit", $ECU_Status_resp_array[1], 'MASK', "0bxxxxxx0x" );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 3000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

1;
__END__
