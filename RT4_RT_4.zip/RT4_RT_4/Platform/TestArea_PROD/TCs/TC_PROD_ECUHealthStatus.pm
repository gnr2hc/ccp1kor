#### TEST CASE MODULE
package TC_PROD_ECUHealthStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.91
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
##################################

our $PURPOSE = "To check the health status of ECU";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ECUHealthStatus

=head1 PURPOSE

"To check the health status of ECU"

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Read whitelist using Whitelist variable<Whitelist_Variable>

2. Create <Condition>

3. Create <Fault> not in Whitelist

4. Read Ecu Heath status variable <variable>


I<B<Evaluation>>

2. <Condition> created successfully.

4. <Variable_Value> value obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Variable_Value' => Value of health status variable at different conditions.
	SCALAR 'purpose' => Purpose of the test case.
	SCALAR 'Controller' => Controller type.
	SCALAR 'Condition' => Different test conditions such as Idle mode, Plantmode etc.
	SCALAR 'Whitelist_Variable' => Variable to read whitelist.
	SCALAR 'Variable' => Variable to read health status.
	SCALAR 'Fault' => Fault not present in fault list


=head2 PARAMETER EXAMPLES

	purpose = ''To check the health status of ECU'
	Controller = 'R1X'
	Condition ='Plant Mode'
	Whitelist_Variable='rb_sycg_HealthStatusWhiteList_nvmau16'
	Variable='rb_prhs_EcuHealthState_en'
	Variable_Value='0X01'
	Fault='OpenLine'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Controller;
my $tcpar_Condition;
my $tcpar_Whitelist_Variable;
my $tcpar_Variable;
my $tcpar_Variable_Value;
my $tcpar_Fault;
my $tcpar_plant_mode_aref;
################ global parameter declaration ###################
my $Health_Status;
my @plant_value_set = (
	0x000000,    #clear plant mode value
	0x000001,    #set plant mode 1 value
	0x000002,    #set plant mode 2 value
	0x000004,    #set plant mode 3 value
	0x000008,    #set plant mode 4 value
	0x000010,    #set plant mode 5 value
	0x000020,    #set plant mode 6 value
	0x000040,    #set plant mode 7 value
	0x000080,    #set plant mode 8 value
	0x000100,    #set plant mode 9 value
	0x000200,    #set plant mode 10 value
	0x000400,    #set plant mode 11 value
	0x000800,    #set plant mode 12 value
	0x001000,    #set plant mode 13 value
	0x002000,    #set plant mode 14 value
	0x004000,    #set plant mode 15 value
	0x008000,    #set plant mode 16 value
	0x010000,    #set plant mode 17 value
	0x020000,    #set plant mode 18 value
	0x040000     #set plant mode 19 value
);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Controller         = S_read_mandatory_testcase_parameter('Controller');
	$tcpar_Condition          = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Whitelist_Variable = S_read_mandatory_testcase_parameter('Whitelist_Variable');
	$tcpar_Variable           = S_read_mandatory_testcase_parameter('Variable');
	$tcpar_Variable_Value     = S_read_mandatory_testcase_parameter('Variable_Value');
	$tcpar_Fault              = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_Controller         = S_read_mandatory_testcase_parameter('Controller');
	$tcpar_plant_mode_aref    = S_read_mandatory_testcase_parameter( 'plant_mode', 'byref' );
	return 1;
}

sub TC_initialization {

	S_teststep( "PROD_Standard_Preparation", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "PROD_Login_Level1", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Read whitelist using Whitelist variable '$tcpar_Whitelist_Variable'", 'AUTO_NBR' );
	S_w2rep( "Not require", 'blue' );

	S_teststep( "Create '$tcpar_Condition'", 'AUTO_NBR', 'create_condition' );    #measurement 1
	if ( $tcpar_Condition eq "PlantMode" ) {
		_set_plant_mode($tcpar_plant_mode_aref);
		S_wait_ms(5000);
	}
	elsif ( $tcpar_Condition eq "NotinPlantMode" ) {
		LC_ECU_Reset();
		S_wait_ms(5000);
	}
	elsif ( $tcpar_Condition eq "IdleMode" ) {
		GEN_setECUMode('IdleMode');
		S_wait_ms(5000);
	}
	elsif ( $tcpar_Condition eq "InitMode" ) {
		LC_ECU_Off();
		S_wait_ms(8000);
		LC_ECU_On();
		S_wait_ms(600);
	}
	elsif ( $tcpar_Condition eq "DisableMode" ) {
		PD_WriteMemoryByName( 'rb_sycg_HealthStatusDisable_dfu8', ['0xDA'] );
		LC_ECU_Reset();
		my $ECU_Status = S_aref2hex( PD_ReadMemoryByName("rb_bswm_ActualSystemMode_au16(0)") );
		S_wait_ms(5000);
	}
	else {
		S_w2rep( "Unknown test condition", 'blue' );
	}

	S_teststep( "Create '$tcpar_Fault' that not in Whitelist", 'AUTO_NBR' );
	unless ( $tcpar_Fault eq "None" ) {
		FM_createFault($tcpar_Fault);
		S_wait_ms(8000);
		my $fault_HoA = PD_ReadFaultMemory();
	}
	else {
		S_w2rep("not required to create fault");
	}

	S_teststep( "Read Ecu Heath status variable '$tcpar_Variable' for '$tcpar_Controller' ", 'AUTO_NBR', 'read_ecu_heath' );    #measurement 2
	$Health_Status = S_aref2hex( PD_ReadMemoryByName("$tcpar_Variable") );

	if ( $tcpar_Condition eq "PlantMode" ) {
		_clear_plant_mode();
	}
	elsif ( $tcpar_Condition eq "IdleMode" ) {
		GEN_setECUMode('RemoveIdleMode');
	}
	elsif ( $tcpar_Condition eq "DisableMode" ) {
		PD_WriteMemoryByName( 'rb_sycg_HealthStatusDisable_dfu8', ['0x00'] );
		LC_ECU_Reset();
	}
	unless ( $tcpar_Fault eq "None" ) {
		FM_removeFault($tcpar_Fault);
		S_wait_ms(8000);
	}
	else {
		S_w2rep("not required to create fault");
	}
	PD_ReadFaultMemory();
	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "'$tcpar_Variable_Value' value obtained", 'read_ecu_heath' );    #evaluation 1
	S_teststep_detected( "$Health_Status", 'read_ecu_heath' );
	EVAL_evaluate_value( 'ECU_HEALTH_STATUS', $Health_Status, '==', $tcpar_Variable_Value );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Wait for ECU ready incase ECU reset condition", 'AUTO_NBR' );
	S_wait_ms(8000);

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _set_plant_mode {
	my $plan_mode       = shift;
	my $plantmode_value = 0;
	my ( $data_aref0, $data_aref1, $data_aref2, $detected_value );
	my $data_href;

	foreach (@$plan_mode) {

		$plantmode_value = ( $plantmode_value | $plant_value_set[$_] );

	}

	$plantmode_value = sprintf( '%#.06x', $plantmode_value );    #format to hex with 0x form
	S_w2rep("plant mode set is: '$plantmode_value'");

	my $plantmode_set = $plantmode_value;
	$plantmode_set =~ s/0x//;                                    #remove 0x
	$plantmode_set =~ s/(\w{2})/$1 /g;                           #inserts a space after every 2 characters
	$plantmode_set =~ s/\s+$//;                                  #remove whitespace at end

	my @plant_set = split( / /, $plantmode_set );

	#Set plan mode
	for ( my $index = 0 ; $index < scalar(@plant_set) ; $index++ ) {

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(' . $index . ')', [ '0x' . $plant_set[ -$index - 1 ] ] );
		S_wait_ms(2000);

	}

	#Do ECU reset
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub _clear_plant_mode {

	my ( $data_aref0, $data_aref1, $data_aref2, $detected_value );
	my $data_href;

	#clear plan mode
	for ( my $index = 0 ; $index < 3 ; $index++ ) {

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(' . $index . ')', [ $plant_value_set[0] ] );
		S_wait_ms(2000);

	}

	#Do ECU reset
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}
1;
