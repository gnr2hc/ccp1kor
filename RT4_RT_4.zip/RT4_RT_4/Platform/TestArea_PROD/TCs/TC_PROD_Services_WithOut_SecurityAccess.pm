#### TEST CASE MODULE
package TC_PROD_Services_WithOut_SecurityAccess;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use File::Basename;
use File::Spec;

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.23
#-------------------------------------------------------------------------

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_labcar;
use LIFT_PD;
use Data::Dumper;
##################################
our $PURPOSE = "Service is requested without security access should report NRC 33";

=head1 TESTCASE MODULE

TC_PROD_Services_WithOut_SecurityAccess_NRC33  $Revision: 1.1 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE
 
Service is requested without security access should report NRC 33

=head1 TESTCASE DESCRIPTION 

    [initialisation]

		1.GEN_StandardPrepNoFault

		2.RESET the ECU.

    [stimulation & measurement]
		1. Send the Login request of type <Login_Type> 

		2. Send the <Test_Precondition > request with  label <RequestLabel_Test_Precondition>

		3.Send <Prod_Diag_Request1> to the ECU and check response for  <Prod_Diag_Response1> with <RequestLabel>

		4. Send <Prod_Diag_Request1> to the ECU with no sec access, format Correct, checksum Incorrect
		and check the response for  <Prod_Diag_Request1>

    [evaluation]
		1.

		2.<Test_Precondition> should be completed.

		3.<Prod_Diag_Response1> should be obtained

		4.No Response should be obtained.

    [finalisation]

	No Faults 

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			    --> 'purpose of the test case'
	SCALAR 'Prod_Diag_Request1'                     -> 'Supported Production Daignostics Request Request label of the Diagmapping File'
	SCALAR 'Prod_Diag_Respons2'                    -> 'Neagative Response Security Access Denied label of the Diagmapping File'
	SCALAR 'RequestLabel'                   			    --> 'Hash parameter for the request  '
	SCALAR 'RequestLabel_Test_Precondition'       > 'Hash parameter for the  precondition request'
	SCALAR 'Login_Type'                    -> '      Security accesss type Login_Type or WrongSeedkey '

  	

=head2 PARAMETER EXAMPLES

[TC_PROD_Services_WithOut_SecurityAccess.NoPDLogin_Read_Cell]   #ID: TS_PRD2222
RequestLabel = %('NumberOfCells' => '00 01', 'StartAddress' => 'FE DF 44 68')
Prod_Diag_Request1		= 'Read_Cell'
Prod_Diag_Response1		= 'NR_Read_Cell_securityAccessDenied'
# From here on: applicable Lift Default Parameters
purpose		 		= 'Service is requested without security access should report NRC 33'
RequestLabel_Test_Precondition=''
Test_Precondition = ''
Login_Type = 'NoPDLogin'

=cut

##PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Test_Precondition, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Request_Label, $defaultpar_RequestLabel_Test_Precondition, $defaultpar_Login_Type, );

################ global parameter declaration ##################

sub TC_set_parameters {

	$defaultpar_purpose                        = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Login_Type                     = S_read_mandatory_testcase_parameter('Login_Type');
	$defaultpar_Prod_Diag_Request1             = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1            = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Request_Label                  = S_read_optional_testcase_parameter( 'RequestLabel', 'byref' );                      # All the Hash Label should be be passed with 'byref'
	$defaultpar_Test_Precondition              = S_read_optional_testcase_parameter('Test_Precondition');
	$defaultpar_RequestLabel_Test_Precondition = S_read_optional_testcase_parameter( 'RequestLabel_Test_Precondition', 'byref' );    # All the Hash Label should be be passed with 'byref'
	$defaultpar_RequestLabel_Test_Precondition = GEN_replaceAddressFromParameterFile($defaultpar_RequestLabel_Test_Precondition);
	$defaultpar_Request_Label                  = GEN_replaceAddressFromParameterFile($defaultpar_Request_Label);
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'Set the addressing mode to PD ', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( 'Reset the ECU ', 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	my ( $reqLabelValue, $checksumValue );

	if ( lc($defaultpar_Login_Type) =~ m /NoPDLogin/i ) {
		S_teststep( "Not Send the PD login \n", 'AUTO_NBR' );
	}
	elsif ( lc($defaultpar_Login_Type) =~ m /WrongSeedkey/i ) {
		S_set_error( "TCs for 'WrongSeedkey' will be test manuall as require smart card", 109 );
	}
	else {
		S_set_error( "Login_Type parameter is paased other than 'NoPDLogin' and 'WrongSeedkey' \n", 109 );
	}
	if ( defined($defaultpar_Test_Precondition) ) {
		S_teststep( "Send the '$defaultpar_Test_Precondition' request with  label 'RequestLabel_Test_Precondition' ", 'AUTO_NBR' );
		S_w2rep( " Evaluation Step2:  Precondition should receive the positive response", 'blue' );
		DIAG_PD_request_general( "REQ_" . $defaultpar_Test_Precondition, "PR_" . $defaultpar_Test_Precondition, $defaultpar_RequestLabel_Test_Precondition );
	}

	S_teststep( "Send Prod_Diag_Request to the ECU with $defaultpar_Prod_Diag_Request1, 'FORMAT: Correct , CHECKSUM: Correct ' and check response for Prod_Diag_Request1 \n", 'AUTO_NBR' );
	S_w2rep( " Evaluation of Step3:  NRC Security Access Denied should be reported\n", 'blue' );
	if($defaultpar_Prod_Diag_Request1=~ m/bosch/i){
		CA_simulation_stop();
		S_wait_ms( 500);
		CA_simulation_start();
		S_wait_ms( 1000);
		GDCOM_CA_trace_start();
		my $Readmemory_Response_observed= DIAG_PD_request( "10 03", "50 03", 'quiet', 'read bosch mem', 'NO_EVAL' );
		my $Trace_StoredfilePath = GEN_getTraceNameWithTeststep(2);
		GDCOM_CA_trace_stop("$Trace_StoredfilePath");
		_evaluate_response_read_mem_bosch();
	}
	else{
		DIAG_PD_request_general( "REQ_" . $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Request_Label );
	}

	S_teststep( "Send Prod_Diag_Request to the ECU with $defaultpar_Prod_Diag_Request1, FORMAT: InCorrect , CHECKSUM:Incorrect' and check response for Prod_Diag_Request1 \n", 'AUTO_NBR' );
	$reqLabelValue = GDCOM_getRequestLabelValue( "REQ_" . $defaultpar_Prod_Diag_Request1, $defaultpar_Request_Label );

	$checksumValue = DIAG_PD_calculateChecksum( $reqLabelValue, "INVALID" );
	$reqLabelValue = $reqLabelValue . " " . $checksumValue;
	S_w2rep( "Evaluation Step4: No Response should be obtained.\n", 'blue' );
	DIAG_PD_request( $reqLabelValue, "", "quiet", "No response for the request", undef, undef, undef, undef, 'No' );
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( "Evaluations is done in  the Diagnostics request Itself\n", "blue" );

	return 1;
}
#### TC FINALIZATION #####
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _evaluate_response_read_mem_bosch {

	my $read_mem_hashref = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	my $dump_ref = Dumper $read_mem_hashref;
	S_w2rep( "Data has ref: $dump_ref", 'bule' );
	my $request_str;

	foreach my $time_stamp ( sort { $a <=> $b } keys %{ $read_mem_hashref->{'Req_Resp'} } ) {
		$request_str = $read_mem_hashref->{'Req_Resp'}{$time_stamp}{'Request'};
		if ( $request_str =~ /03 10 03 16 FF FF FF FF/ )    #frame request will be fixed
		{
			my $response_arr_ref = $read_mem_hashref->{'Req_Resp'}{$time_stamp}{'Response'};
			my @first_frame_resp = split( / /, @$response_arr_ref[0] );
			S_w2rep( "The second frame in response is: @$response_arr_ref[1]", 'blue' );
			EVAL_evaluate_string( "Positive response",  $first_frame_resp[1].' '.$first_frame_resp[2], '50 03' );
			last;
		}

	}

	return 1;
}
1;

__END__
