#### TEST CASE MODULE
package TC_PROD_NotSupportedServices;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use INCLUDES_Project;
use LIFT_general;
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To test the behaviour of not supported Production Diagnostic service and after 2 ms only ECU should receive the new request";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_NotSupportedServices  $Revision: 1.1 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To check the not Supported behaviour of the Production Daignostics services 

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    1.Standard Preparation(Fault Free Setup)
    2.PD_Login

    [stimulation & measurement]
    1. Send Not Supported Services Prod_Diag_Request1 to the ECU

	2. Send Supported Services Prod_Diag_Request2 to the ECU within WaitTime_For_New_Request ms  from step 1

	3. Send Not Supported Service Prod_Diag_Request1 to the ECU and Wait For Timeout

	4. Send Supported Service Prod_Diag_Request2 to the ECU after the PD Timeout


    [evaluation]
    1. No response should be obtained.

	2. Prod_Diag_Response2 should be obtained

	3. No response should be obtained.

	4. Prod_Diag_Response2 should be obtained
    

    [finalisation]
     No Faults 

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose'                                --> 'purpose of the test case'
    SCALAR 'Prod_Diag_Request1'                     -> 'Not Supported Request'
    SCALAR 'Prod_Diag_Request2'                     -> 'Request label of the Diagmapping File (Supported Request)'
    SCALAR 'Prod_Diag_Response2'                    -> 'Response label of the Diagmapping File'
    SCALAR 'WaitTime_For_New_Request'               -> 'Response time of the supported services request'
    

=head2 PARAMETER EXAMPLES

    [TC_PROD_NotSupportedServices.Not_supported_Service_1]
    # From here on: applicable Lift Default Parameters
    purpose = 'To test the behaviour of not supported Production Diagnostic service and after 2 ms only ECU should receive the new request'
    Prod_Diag_Request1      = '03 0A A1 00'
    # From here on: applicable Lift Default Parameters
    Prod_Diag_Request2='PD_ECU_Status'
    Prod_Diag_Response2='PR_PD_ECU_Status'
    WaitTime_For_New_Request = 2 # ms
=cut

##PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Request2, $defaultpar_Prod_Diag_Response2, $defaultpar_WaitTime_For_New_Request, );

############# Parameters from const files ################

################ global parameter declaration ##################
my $ecu_response;
###############################################################
sub TC_set_parameters {

	$defaultpar_purpose                  = S_read_optional_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1       = S_read_optional_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Request2       = S_read_optional_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2      = S_read_optional_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_WaitTime_For_New_Request = S_read_optional_testcase_parameter('WaitTime_For_New_Request');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");
	
	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();
	
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Send Not Supported Services: $defaultpar_Prod_Diag_Request1 to the ECU in PD_Notimeout addressing mode", 'AUTO_NBR', 'No response for the not Supported services in PD_Notimeout' );
	S_teststep_2nd_level( "set addressing mode to: PD_Notimeout", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD_Notimeout");

	S_teststep_2nd_level( "Send request: '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ecu_response = GDCOM_request( $defaultpar_Prod_Diag_Request1, "", "quiet", "No response for the not Supported services" );
	S_teststep_expected( "No response receive", 'No response for the not Supported services in PD_Notimeout' );
	S_teststep_detected( "The response got from ECU is: '$ecu_response'", 'No response for the not Supported services in PD_Notimeout' );    #evaluation 3

	S_teststep( "Send Supported Services: $defaultpar_Prod_Diag_Request2 to the ECU with in 2 ms from step 1", 'AUTO_NBR', "Response get with valid request after 2ms request" );
	S_teststep_2nd_level( "set addressing mode to: PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");
	S_w2rep( "Timing was defined on project constant", 'blue' );

	S_teststep_2nd_level( "send request:'REQ_$defaultpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	$ecu_response = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );
	S_teststep_expected( "Positive response from ECU: $defaultpar_Prod_Diag_Response2", 'Response get with valid request after 2ms request' );
	S_teststep_detected( "The response got from ECU is: '$ecu_response'", 'Response get with valid request after 2ms request' );             #evaluation 3

	S_teststep( "Send Not Supported Services to the ECU and Wait For Timeout", 'AUTO_NBR', 'Response no get with invalid request after PD timeout' );
	$ecu_response = GDCOM_request( $defaultpar_Prod_Diag_Request1, "", "quiet", "No response for the not Supported services" );
	S_teststep_expected( "No response receive", 'Response no get with invalid request after PD timeout' );
	S_teststep_detected( "The response got from ECU is: '$ecu_response'", 'Response no get with invalid request after PD timeout' );         #evaluation 3

	S_teststep( "Send Supported Services to the ECU after the PD Timeout", 'AUTO_NBR', 'Response get with valid request after PD timeout' );
	$ecu_response = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );
	S_teststep_expected( "Positive response from ECU: $defaultpar_Prod_Diag_Response2", 'Response get with valid request after PD timeout' );
	S_teststep_detected( "The response got from ECU is: '$ecu_response'", 'Response get with valid request after PD timeout' );              #evaluation 3

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation is done in TC_stimulation_and_measurement", 'blue' );
	return 1;
}

sub TC_finalization {

	GDCOM_set_addressing_mode("physical");

	return 1;
}

1;

__END__
