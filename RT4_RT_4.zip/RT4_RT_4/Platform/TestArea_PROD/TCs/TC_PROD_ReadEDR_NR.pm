#### TEST CASE MODULE
package TC_PROD_ReadEDR_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.48
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;    #necessary
use GENERIC_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "to test the negative responses for read EDR prodiag services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ReadEDR_NR

=head1 PURPOSE

to test the negative responses for read EDR prodiag services

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Create <condition>

2. Send <Prod_Diag_Request> with <DID> to read EDR


I<B<Evaluation>>

2. <Prod_Diag_Response> is received


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'DID' => DID to read the EDR record
	SCALAR 'Prod_Diag_Response' => label from mapping file for read EDR negative response
	SCALAR 'purpose' => purpose of this TC
	SCALAR 'condition' => condition to be created like BlockLengthMore, EDRStorageInProgress, InvalidDID, NotSupportedDID
	SCALAR 'Prod_Diag_Request' => label from mapping file to read EDR


=head2 PARAMETER EXAMPLES

	purpose = 'to test the negative responses for read EDR prodiag services'
	condition = 'BlockLengthMore'
	Prod_Diag_Request = 'Read_EDR'
	DID = 'FD 00'
	Prod_Diag_Response = 'NR_Read_EDR_incorrectMessageLengthOrInvalidFormat' 

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_condition;
my $tcpar_Prod_Diag_Request;
my $tcpar_DID;
my $tcpar_Prod_Diag_Response;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_condition          = S_read_mandatory_testcase_parameter('condition');
	$tcpar_Prod_Diag_Request  = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_DID                = S_read_mandatory_testcase_parameter('DID');
	$tcpar_Prod_Diag_Response = S_read_mandatory_testcase_parameter('Prod_Diag_Response');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Create '$tcpar_condition' condition", 'AUTO_NBR' );
	my ( $requestLabel, $modified_request, $NRCInfo );
	$requestLabel->{'DID'} = $tcpar_DID;
	S_w2rep( "Condition will create in the request", 'blue' );

	S_teststep( "Send '$tcpar_Prod_Diag_Request' with DID '$tcpar_DID' to read EDR", 'AUTO_NBR' );
	if ( $tcpar_condition eq 'BlockLengthMore' ) {
		S_w2rep( "Increase block length by 1 as condition '$tcpar_condition'", 'blue' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_condition eq 'BlockLengthLess' ) {
		S_w2rep( "Reduce block length by 1 as condition '$tcpar_condition'", 'blue' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, -1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_condition eq 'EDRStorageInProgress' ) {
		S_w2rep( "Inject Crash and immediately send the read request", 'blue' );
		EDR_InjectCrash('FrontInflatableDeployment');
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );
	}
	elsif ( $tcpar_condition eq 'none' ) {
		S_w2rep( "no special condition require", 'blue' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep( 'All Evaluation is done in TC_stimulation_and_measurement', 'blue' );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
