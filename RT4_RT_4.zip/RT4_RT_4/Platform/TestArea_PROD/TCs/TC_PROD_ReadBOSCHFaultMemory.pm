#### TEST CASE MODULE
package TC_PROD_ReadBOSCHFaultMemory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_evaluation;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;
##################################

our $PURPOSE = "to check the service to read the BOSCH fault memory";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ReadBOSCHFaultMemory

=head1 PURPOSE

to check the service to read the BOSCH fault memory

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Note: The intention of this test is to check if the correct values are reported in the corresponding response bytes - not to check all possible properties in the Bosch Fault Memory - this should be covered in DEM module


I<B<Stimulation and Measurement>>

1. Create a squib openline fault and note these details immediately

ECU operating time

current power ON cycle

2. Send request <Prod_Diag_Request> to read the Bosch Fault Memory

3. Create a switch openline fault and note these details immediately

ECU operating time

current power ON cycle

4. Send request <Prod_Diag_Request> to read the Bosch Fault Memory

5. Reset the ECU (switch Off, wait for some time and then switch On)

6. Remove the squib openline fault and note these details immediately

ECU operating time

current power ON cycle

7. Send request <Prod_Diag_Request> to read the Bosch Fault Memory


I<B<Evaluation>>

2. <Prod_Diag_Response> is obtained. Squib openline fault created in step 1 is reported in response (Event ID) with these details:

byte 4 to 8 has non default data

Qualification time: operating time noted during fault creation

Dequalification time: 00 00 00 00 (default)

Qualification PowerOn cycle: value noted during fault creation

Dequalification PowerOn cycle: 00 00 00 00 (default)

Occurrence counter: 1

Event Status: corresponding fault status byte

4. <Prod_Diag_Response> is obtained. Squib openline fault  and switch openline fault is reported in response (Event ID) with these details:

byte 4 to 8 has non default data

Qualification time: time noted during fault creation

Dequalification time: 00 00 00 00 (default)

Qualification PowerOn cycle: value noted during fault creation

Dequalification PowerOn cycle: 00 00 00 00 (default)

Occurrence counter: 1

Event Status: corresponding fault status byte

7. <Prod_Diag_Response> is obtained. Squib and switch openline fault is reported in response (Event ID) with these details:

byte 4 to 8 has non default data

Qualification time: time noted during fault creation

Dequalification time: time noted during fault removal for squib fault and 00 00 00 00 for Switch fault

Qualification PowerOn cycle: value noted during fault creation

Dequalification PowerOn cycle:  power ON counter noted during fault removal for squib fault and 00 00 00 00 for Switch fault

Occurrence counter: 1

Event Status: corresponding fault status byte


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'Prod_Diag_Request' => request label from DIAG mapping file
	SCALAR 'Prod_Diag_Response' => response label from DIAG mapping file


=head2 PARAMETER EXAMPLES

	purpose = 'To test the Read BOSCH fault memory service'
	
	Prod_Diag_Request = 'Read_Fault_Memory__Bosch'
	Prod_Diag_Response = 'PR_Read_Fault_Memory__Bosch'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Prod_Diag_Request;
my $tcpar_Prod_Diag_Response;
my $tcpar_Switch_Fault;
my $tcpar_Squib_Fault;
################ global parameter declaration ###################
#add any global variables here
my $readMemory_Response_observed_step2;
my $readMemory_Response_observed_step4;
my $readMemory_Response_observed_step7;
my ( $opTime_step1, $poc_step1 );
my ( $opTime_step3, $poc_step3 );
my ( $opTime_step6, $poc_step6 );
my $sqFault_eventID;
my $swFault_eventID;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Prod_Diag_Request  = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_Prod_Diag_Response = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$tcpar_Switch_Fault       = S_read_mandatory_testcase_parameter('Switch_Fault');
	$tcpar_Squib_Fault        = S_read_mandatory_testcase_parameter('Squib_Fault');

	return 1;
}

sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep("Note: The intention of this test is to check if the correct values are reported in the corresponding response bytes - not to check all possible properties in the Bosch Fault Memory - this should be covered in DEM module");

	return 1;
}

sub TC_stimulation_and_measurement {

	my $Trace_StoredfilePath;
	my ( $reqresp_hashref_step2, $reqresp_hashref_step4, $reqresp_hashref_step7 );

	S_teststep( "Create a squib openline fault '$tcpar_Squib_Fault' and note these details immediately", 'AUTO_NBR' );
	FM_createFault($tcpar_Squib_Fault);
	$sqFault_eventID = sprintf( "%04X", PD_GetFaultID($tcpar_Squib_Fault) );

	S_teststep( "ECU operating time", 'AUTO_NBR' );
	my @time_1;
	push( @time_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(7)') } );
	push( @time_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(6)') } );
	push( @time_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(5)') } );
	push( @time_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(4)') } );
	$opTime_step1 = \@time_1;

	S_teststep( "current power ON cycle", 'AUTO_NBR' );
	my @poc_1;
	push( @poc_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(3)') } );
	push( @poc_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(2)') } );
	push( @poc_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(1)') } );
	push( @poc_1, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(0)') } );
	$poc_step1 = \@poc_1;

	S_wait_ms( 6000, 'wait for fault to qualify' );
	S_teststep( "Send request '$tcpar_Prod_Diag_Request' to read the Bosch Fault Memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Start can trace logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, undef, 'NO_EVAL' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep('2');

	S_teststep_2nd_level( "Stop trace logging", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get contain data byte", 'AUTO_NBR' );
	$reqresp_hashref_step2              = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	$readMemory_Response_observed_step2 = DIAG_PD_getResponseDataBytes($reqresp_hashref_step2);
	$readMemory_Response_observed_step2 = 'ff 50 03 19 19 04 ff ff 01 01 82 00 00 00 3d 20 00 04 10 7f 00 04 10 a0 00 00 06 a1 00 00 06 a2 01 00 ff ff ff ff ff ff 02 00 33 
00 00 00 3d 20 00 04 10 88 00 04 10 a5 00 00 06 a1 00 00 06 a2 03 00 ff ff ff ff ff ff 03 02 3e 00 00 00 3e 20 00 04 10 8a 00 00 00 
00 00 00 06 a1 00 00 00 00 01 01 ff ff ff ff ff ff ff 0c ff ff ff ff ff ff' if $main::opt_offline;
	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep("Create a switch openline fault '$tcpar_Switch_Fault' and note these details immediately");
	FM_createFault($tcpar_Switch_Fault);
	$swFault_eventID = sprintf( "%04X", PD_GetFaultID($tcpar_Switch_Fault) );

	S_teststep( "ECU operating time", 'AUTO_NBR' );
	my @time_3;
	push( @time_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(7)') } );
	push( @time_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(6)') } );
	push( @time_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(5)') } );
	push( @time_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(4)') } );
	$opTime_step3 = \@time_3;

	S_teststep( "current power ON cycle", 'AUTO_NBR' );
	my @poc_3;
	push( @poc_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(3)') } );
	push( @poc_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(2)') } );
	push( @poc_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(1)') } );
	push( @poc_3, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(0)') } );
	$poc_step3 = \@poc_3;

	S_teststep( "Send request '$tcpar_Prod_Diag_Request' to read the Bosch Fault Memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Start can trace logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_wait_ms( 6000, 'wait for fault to qualify' );
	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, undef, 'NO_EVAL' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep('4');

	S_teststep_2nd_level( "Stop trace logging", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get contain data byte", 'AUTO_NBR' );
	$reqresp_hashref_step4              = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	$readMemory_Response_observed_step4 = DIAG_PD_getResponseDataBytes($reqresp_hashref_step4);
	$readMemory_Response_observed_step4 = 'ff 50 03 19 19 04 ff ff 01 01 82 00 00 00 3d 20 00 04 10 7f 00 04 10 a0 00 00 06 a1 00 00 06 a2 01 00 ff ff ff ff ff ff 02 00 33 
00 00 00 3d 20 00 04 10 88 00 04 10 a5 00 00 06 a1 00 00 06 a2 03 00 ff ff ff ff ff ff 03 02 3e 00 00 00 3e 20 00 04 10 8a 00 00 00 
00 00 00 06 a1 00 00 00 00 01 01 ff ff ff ff ff ff ff 0c ff ff ff ff ff ff' if $main::opt_offline;
	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Reset the ECU (switch Off, wait for some time and then switch On)", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Login after reset", 'AUTO_NBR' );
	PD_ECUlogin();
	S_wait_ms( 500, 'wait after login' );

	S_teststep( "Remove the squib openline fault '$tcpar_Squib_Fault' and note these details immediately", 'AUTO_NBR' );
	FM_removeFault($tcpar_Squib_Fault);

	S_teststep( "ECU operating time", 'AUTO_NBR' );
	my @time_6;
	push( @time_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(7)') } );
	push( @time_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(6)') } );
	push( @time_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(5)') } );
	push( @time_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(4)') } );
	$opTime_step6 = \@time_6;

	S_teststep( "current power ON cycle", 'AUTO_NBR' );
	my @poc_6;
	push( @poc_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(3)') } );
	push( @poc_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(2)') } );
	push( @poc_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(1)') } );
	push( @poc_6, @{ PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st(0)') } );
	$poc_step6 = \@poc_6;

	S_teststep( "wait for fault de-qualify", 'AUTO_NBR' );
	S_wait_ms( 6000, 'wait for fault to dequalify' );

	S_teststep( "Send request '$tcpar_Prod_Diag_Request' to read the Bosch Fault Memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Start can trace logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep_2nd_level( "Send request $tcpar_Prod_Diag_Request", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, undef, 'NO_EVAL' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep('7');

	S_teststep_2nd_level( "Stop logging trace", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get contain data byte", 'AUTO_NBR' );
	$reqresp_hashref_step7              = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	$readMemory_Response_observed_step7 = DIAG_PD_getResponseDataBytes($reqresp_hashref_step7);
	$readMemory_Response_observed_step7 = 'ff 50 03 19 19 04 ff ff 01 01 82 00 00 00 3d 20 00 04 10 7f 00 04 10 a0 00 00 06 a1 00 00 06 a2 01 00 ff ff ff ff ff ff 02 00 33
00 00 00 3d 20 00 04 10 88 00 04 10 a5 00 00 06 a1 00 00 06 a2 03 00 ff ff ff ff ff ff 03 02 3e 00 00 00 3e 20 00 04 10 8a 00 00 00 
00 00 00 06 a1 00 00 00 00 01 01 ff ff ff ff ff ff ff 0c ff ff ff ff ff ff' if $main::opt_offline;
	S_wait_ms( 5000, 'wait for previous response' );

	S_teststep_2nd_level( "Read fault memory", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "remove the SW openline fault '$tcpar_Switch_Fault' created in step 3", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove fault '$tcpar_Switch_Fault'", 'AUTO_NBR' );
	FM_removeFault($tcpar_Switch_Fault);

	S_teststep_2nd_level( "wait for fault de-qualify", 'AUTO_NBR' );
	S_wait_ms( 6000, 'wait for fault to dequalify' );

	return 1;
}

sub TC_evaluation {

	my ( $readMemory_struct_SQ_step2, $readMemory_struct_SQ_step4, $readMemory_struct_SW_step4, $readMemory_struct_SQ_step7, $readMemory_struct_SW_step7 );

	S_teststep("Evaluation for Step 2. '$tcpar_Prod_Diag_Response' is obtained. Squib openline fault created in step 1 is reported in response (Event ID) with these details:");
	S_w2rep('response has been evaluated in stimulation and measurement section itself','blue');
	$readMemory_struct_SQ_step2 = FM_PD_getEventIDStruct( uc($readMemory_Response_observed_step2), $sqFault_eventID );

	S_teststep("byte 4 to 8 has non default data");
	EVAL_evaluate_value( 'SQ fault: Event Debug Data',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'EventDebugData'} ) ),     '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: ASIC Temperature',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'ASICTemperature'} ) ),    '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: General Status Flags', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'GeneralStatusFlags'} ) ), '!=', 0xFF );

	S_teststep("Qualification time: operating time noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'QualificationTime'} ) ), '==', S_aref2hex($opTime_step1), 10 );    #10% tolerance

	S_teststep("Dequalification time: 00 00 00 00 (default)");
	EVAL_evaluate_value( 'SQ fault: Dequalification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'DequalificationTime'} ) ), '==', 0 );

	S_teststep("Qualification PowerOn cycle: value noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'QualificationPOC'} ) ), '==', S_aref2hex($poc_step1), 10 );    #10% tolerance

	S_teststep("Dequalification PowerOn cycle: 00 00 00 00 (default)");
	EVAL_evaluate_value( 'SQ fault: Dequalification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step2->{'DequalificationPOC'} ) ), '==', 0 );

	S_teststep("Occurrence counter: 1");
	EVAL_evaluate_value( 'SQ fault: Occurrence counter', S_hex2dec( $readMemory_struct_SQ_step2->{'OccurrenceCounter'} ), '==', 1 );

	S_teststep("Event Status: corresponding fault status byte");
	EVAL_evaluate_value( 'SQ fault: fault status byte', S_hex2dec( $readMemory_struct_SQ_step2->{'StatusByte'} ), '==', 0x01 );                                                                     #qualified

	S_teststep("Evaluation for Step 4. '$tcpar_Prod_Diag_Response' is obtained. Squib openline fault  and switch openline fault is reported in response (Event ID) with these details:");
	S_w2rep('response has been evaluated in stimulation and measurement section itself','blue');
	$readMemory_struct_SQ_step4 = FM_PD_getEventIDStruct( uc $readMemory_Response_observed_step4, $sqFault_eventID );
	$readMemory_struct_SW_step4 = FM_PD_getEventIDStruct( uc $readMemory_Response_observed_step4, $swFault_eventID );

	S_teststep("byte 4 to 8 has non default data");

	#SQ
	EVAL_evaluate_value( 'SQ fault: Event Debug Data',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'EventDebugData'} ) ),     '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: ASIC Temperature',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'ASICTemperature'} ) ),    '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: General Status Flags', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'GeneralStatusFlags'} ) ), '!=', 0xFF );

	#SW
	EVAL_evaluate_value( 'SW fault: Event Debug Data',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'EventDebugData'} ) ),     '!=', 0xFFFF );
	EVAL_evaluate_value( 'SW fault: ASIC Temperature',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'ASICTemperature'} ) ),    '!=', 0xFFFF );
	EVAL_evaluate_value( 'SW fault: General Status Flags', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'GeneralStatusFlags'} ) ), '!=', 0xFF );

	S_teststep("Qualification time: time noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'QualificationTime'} ) ), '==', S_aref2hex($opTime_step1), 10 );    #qualified in step 1
	EVAL_evaluate_value( 'SW fault: Qualification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'QualificationTime'} ) ), '==', S_aref2hex($opTime_step3), 10 );    #qualified in step 3

	S_teststep("Dequalification time: 00 00 00 00 (default)");
	EVAL_evaluate_value( 'SQ fault: Dequalification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'DequalificationTime'} ) ), '==', 0 );
	EVAL_evaluate_value( 'SW fault: Dequalification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'DequalificationTime'} ) ), '==', 0 );

	S_teststep("Qualification PowerOn cycle: value noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'QualificationPOC'} ) ), '==', S_aref2hex($poc_step1), 10 );    #qualified in step 1
	EVAL_evaluate_value( 'SW fault: Qualification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'QualificationPOC'} ) ), '==', S_aref2hex($poc_step3), 10 );    #qualified in step 3

	S_teststep("Dequalification PowerOn cycle: 00 00 00 00 (default)");
	EVAL_evaluate_value( 'SQ fault: Dequalification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step4->{'DequalificationPOC'} ) ), '==', 0 );
	EVAL_evaluate_value( 'SW fault: Dequalification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step4->{'DequalificationPOC'} ) ), '==', 0 );

	S_teststep("Occurrence counter: 1");
	EVAL_evaluate_value( 'SQ fault: Occurrence counter', S_hex2dec( $readMemory_struct_SQ_step4->{'OccurrenceCounter'} ), '==', 1 );
	EVAL_evaluate_value( 'SW fault: Occurrence counter', S_hex2dec( $readMemory_struct_SW_step4->{'OccurrenceCounter'} ), '==', 1 );

	S_teststep("Event Status: corresponding fault status byte");
	EVAL_evaluate_value( 'SQ fault: fault status byte', S_hex2dec( $readMemory_struct_SQ_step4->{'StatusByte'} ), '==', 0x01 );                                                                     #qualified
	EVAL_evaluate_value( 'SW fault: fault status byte', S_hex2dec( $readMemory_struct_SW_step4->{'StatusByte'} ), '==', 0x01 );                                                                     #qualified

	S_teststep("Evaluation for Step 7. '$tcpar_Prod_Diag_Response' is obtained. Squib and switch openline fault is reported in response (Event ID) with these details:");
	S_w2rep('response has been evaluated in stimulation and measurement section itself','blue');
	$readMemory_struct_SQ_step7 = FM_PD_getEventIDStruct( uc $readMemory_Response_observed_step7, $sqFault_eventID );
	$readMemory_struct_SW_step7 = FM_PD_getEventIDStruct( uc $readMemory_Response_observed_step7, $swFault_eventID );

	S_teststep("byte 4 to 8 has non default data");

	#SQ
	EVAL_evaluate_value( 'SQ fault: Event Debug Data',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'EventDebugData'} ) ),     '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: ASIC Temperature',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'ASICTemperature'} ) ),    '!=', 0xFFFF );
	EVAL_evaluate_value( 'SQ fault: General Status Flags', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'GeneralStatusFlags'} ) ), '!=', 0xFF );

	#SW
	EVAL_evaluate_value( 'SW fault: Event Debug Data',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'EventDebugData'} ) ),     '!=', 0xFFFF );
	EVAL_evaluate_value( 'SW fault: ASIC Temperature',     S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'ASICTemperature'} ) ),    '!=', 0xFFFF );
	EVAL_evaluate_value( 'SW fault: General Status Flags', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'GeneralStatusFlags'} ) ), '!=', 0xFF );

	S_teststep("Qualification time: time noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'QualificationTime'} ) ), '==', S_aref2hex($opTime_step1), 10 );    #qualified in step 1
	EVAL_evaluate_value( 'SW fault: Qualification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'QualificationTime'} ) ), '==', S_aref2hex($opTime_step3), 10 );    #qualified in step 3

	S_teststep("Dequalification time: time noted during fault removal for squib fault and 00 00 00 00 for Switch fault");
	EVAL_evaluate_value( 'SQ fault: Dequalification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'DequalificationTime'} ) ), '==', S_aref2hex($opTime_step6), 10 );    #dequalified in step 6
	EVAL_evaluate_value( 'SW fault: Dequalification time', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'DequalificationTime'} ) ), '==', 0 );                                #not yet dequalified

	S_teststep("Qualification PowerOn cycle: value noted during fault creation");
	EVAL_evaluate_value( 'SQ fault: Qualification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'QualificationPOC'} ) ), '==', S_aref2hex($poc_step1), 10 );    #qualified in step 1
	EVAL_evaluate_value( 'SW fault: Qualification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'QualificationPOC'} ) ), '==', S_aref2hex($poc_step3), 10 );    #qualified in step 3

	S_teststep("Dequalification PowerOn cycle:  power ON counter noted during fault removal for squib fault and 00 00 00 00 for Switch fault");
	EVAL_evaluate_value( 'SQ fault: Dequalification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SQ_step7->{'DequalificationPOC'} ) ), '==', S_aref2hex($poc_step6), 10 );    #dequalified in step 6
	EVAL_evaluate_value( 'SW fault: Dequalification PowerOn cycle', S_aref2hex( GEN_byteString2hexaref( $readMemory_struct_SW_step7->{'DequalificationPOC'} ) ), '==', 0 );                             #not yet dequalified

	S_teststep("Occurrence counter: 1");
	EVAL_evaluate_value( 'SQ fault: Occurrence counter', S_hex2dec( $readMemory_struct_SQ_step7->{'OccurrenceCounter'} ), '==', 1 );
	EVAL_evaluate_value( 'SW fault: Occurrence counter', S_hex2dec( $readMemory_struct_SW_step7->{'OccurrenceCounter'} ), '==', 1 );

	S_teststep("Event Status: corresponding fault status byte");
	EVAL_evaluate_value( 'SQ fault: fault status byte', S_hex2dec( $readMemory_struct_SQ_step7->{'StatusByte'} ), '==', 0x00 );                                                                         #dequalified
	EVAL_evaluate_value( 'SW fault: fault status byte', S_hex2dec( $readMemory_struct_SW_step7->{'StatusByte'} ), '==', 0x01 );                                                                         #qualified

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start the canoe to logging trace", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;
}

1;
