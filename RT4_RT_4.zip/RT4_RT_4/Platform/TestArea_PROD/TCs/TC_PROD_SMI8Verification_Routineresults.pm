#### TEST CASE MODULE
package TC_PROD_SMI8Verification_Routineresults;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_labcar;

#include further modules here
##################################

our $PURPOSE = "To test the negative responses of the SMI8 verification service";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_SMI8Verification_Routineresults

=head1 PURPOSE

To test the negative responses of the SMI8 verification service

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request> to read the sensor data.
2. Create <TestCondition>.
3. Send <Prod_Diag_Request1>.


I<B<Evaluation>>

2. 
<Prod_Diag_Response> is received.
response is received within <ResponseTime> ms.
3.<Prod_Diag_Response1> is received.
response is received within <ResponseTime> ms.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_TestCondition;
my $tcpar_Prod_Diag_Request;
my $tcpar_Prod_Diag_Response;
my $tcpar_ControlType1;
my $tcpar_ControlType2;
my $tcpar_Prod_Diag_Response1;
my $tcpar_NumberOfSamples;
my $tcpar_SamplingDetails;

################ global parameter declaration ###################
#add any global variables here
my $requestLabel;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_TestCondition       = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_Prod_Diag_Request   = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_Prod_Diag_Response  = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_ControlType1        = S_read_mandatory_testcase_parameter('ControlTypes1');
	$tcpar_ControlType2        = S_read_mandatory_testcase_parameter('ControlTypes2');
	$tcpar_NumberOfSamples     = S_read_mandatory_testcase_parameter('NumberOfSamples');
	$tcpar_SamplingDetails     = S_read_mandatory_testcase_parameter('SamplingDetails');
	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my $modified_request;
	my $NRCInfo;
	$requestLabel->{'ControlType'}     = $tcpar_ControlType1;
	$requestLabel->{'NumberOfSamples'} = $tcpar_NumberOfSamples;
	$requestLabel->{'SamplingDetails'} = $tcpar_SamplingDetails;
	if ( $tcpar_TestCondition eq 'Requestroutineresultwithin200ms' ) {
		$requestLabel->{'NumberOfSamples'} = '08 00';	#using the large number of sample to make sure ECU take more time to collect data
	}

	S_teststep( "Send $tcpar_Prod_Diag_Request to read the sensor data.", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );

	S_teststep( "Create test condition '$tcpar_TestCondition' and send '$tcpar_Prod_Diag_Request'.", 'AUTO_NBR' );
	$requestLabel->{'ControlType'}     = $tcpar_ControlType2;    #Change to request result
	$requestLabel->{'NumberOfSamples'} = '';
	$requestLabel->{'SamplingDetails'} = '';

	if ( $tcpar_TestCondition eq 'Requestroutineresultwithin200ms' ) {
		S_wait_ms( 100, 'wait for routine start' );
		S_teststep_2nd_level( "Send request: REQ_$tcpar_Prod_Diag_Request without waiting finish of rountine", 'AUTO_NBR' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response1, $requestLabel );
	}
	elsif ( $tcpar_TestCondition eq 'Request_Sequence_Error' ) {
		S_teststep_2nd_level( "Reset ECU to remove the request start rountine before", 'AUTO_NBR' );
		LC_ECU_Reset();

		S_teststep_2nd_level( "Login to ECU", 'AUTO_NBR' );
		PD_ECUlogin();

		S_teststep_2nd_level( "Send request $tcpar_Prod_Diag_Request", 'AUTO_NBR' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response1, $requestLabel );
	}
	elsif ( $tcpar_TestCondition eq 'Wrong_routine_Control_type' ) {
		S_wait_ms( 5000, 'wait for finish routine' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response1, $requestLabel );
	}
	elsif ( $tcpar_TestCondition eq 'BlockLengthLess' ) {
		S_teststep_2nd_level( "Manipulation the request with condition 'BlockLengthLess' ", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, -1 );

		S_teststep_2nd_level( "Get NRC information", 'AUTO_NBR' );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);

		S_wait_ms( 5000, 'wait for finish routine' );
		S_teststep_2nd_level( "Send request: $modified_request", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $tcpar_TestCondition eq 'Blocklengthmore' ) {
		S_teststep_2nd_level( "Manipulation the request with condition 'Blocklengthmore' ", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, +1 );

		S_wait_ms( 5000, 'wait for finish routine' );
		S_teststep_2nd_level( "Get NRC information", 'AUTO_NBR' );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);

		S_teststep_2nd_level( "Send request: $modified_request", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	else {
		S_wait_ms( 5000, 'wait for finish routine' );
		DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response1, $requestLabel );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation is done in 'TC_stimulation_and_measurement'", 'blue' );

	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 1000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
