#### TEST CASE MODULE
package TC_PROD_Fast_Diagnosis_FD_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use GENERIC_DCOM;
use INCLUDES_Project;    #necessary
use LIFT_CD_CAN;
use LIFT_can_access;
use LIFT_PD;
use LIFT_DCOM;
##################################

our $PURPOSE = "To check the negative responses for Fast Diagnosis services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Fast_Diagnosis_NR

=head1 PURPOSE

To check the negative responses for Fast Diagnosis services

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Set <TestCondition>


I<B<Stimulation and Measurement>>

1. Send <Fast_Diag_Request>

2. Reset the ECU and check for consecutive fast diagnosis frames


I<B<Evaluation>>

1. <Fast_Diag_Response> is received. Consecutive fast diagnosis frames are not sent.

2. Consecutive fast diagnosis frames are not sent after reset


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of TC
	SCALAR 'Fast_Diag_Request' => request label
	SCALAR 'FD_Startup' => start up option selector
	SCALAR 'OutputMode' => StandardCAN or PrivateCAN
	SCALAR 'LimitNumberOfCANIDs' => 0001 to 0100
	SCALAR 'NumberOfCells' => 01 to 1C
	SCALAR 'Fast_Diag_Response' => Expected response label


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the negative responses for Fast Diagnosis services whne startup is disabled'
	Fast_Diag_Request = 'Fast_Diagnostics_CAN'
	#options
	FD_Startup = '00' #disabled
	OutputMode = '00'
	LimitNumberOfCANIDs = '0001'
	NumberOfCells = '01'
	Fast_Diag_Response = 'NR_Fast_Diagnostics_CAN_requestOutOfRange'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Fast_Diag_Request;
my $tcpar_FD_Startup;
my $tcpar_OutputMode;
my $tcpar_LimitNumberOfCANIDs;
my $tcpar_NumberOfCells;
my $tcpar_Fast_Diag_Response;
my $tcpar_TestCondition;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Fast_Diag_Request   = S_read_mandatory_testcase_parameter('Fast_Diag_Request');
	$tcpar_FD_Startup          = S_read_mandatory_testcase_parameter('FD_Startup');
	$tcpar_OutputMode          = S_read_mandatory_testcase_parameter('OutputMode');
	$tcpar_LimitNumberOfCANIDs = S_read_mandatory_testcase_parameter('LimitNumberOfCANIDs');
	$tcpar_NumberOfCells       = S_read_mandatory_testcase_parameter('NumberOfCells');
	$tcpar_Fast_Diag_Response  = S_read_mandatory_testcase_parameter('Fast_Diag_Response');
	$tcpar_TestCondition       = S_read_optional_testcase_parameter('TestCondition');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my $modified_request;
	my $NRCInfo;

	S_teststep("Startup: $tcpar_FD_Startup, Output mode: $tcpar_OutputMode, NumCANIds: $tcpar_LimitNumberOfCANIDs");

	S_teststep_2nd_level( "Prepare the byte request FD option", 'AUTO_NBR' );    #covert 2/4 bits to hex byte (8-bit) format
	$tcpar_FD_Startup          = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b000000' . $tcpar_FD_Startup ) ) );
	$tcpar_OutputMode          = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b000000' . $tcpar_OutputMode ) ) );
	$tcpar_LimitNumberOfCANIDs = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b0000' . $tcpar_LimitNumberOfCANIDs ) ) );

	my $FDoptions = ( ( $tcpar_LimitNumberOfCANIDs << 4 ) | ( $tcpar_FD_Startup << 2 ) | $tcpar_OutputMode );
	$FDoptions = sprintf( "%02X", $FDoptions );
	S_w2rep("FD options: $FDoptions");

	S_teststep_2nd_level( "Get the cells addressing", 'AUTO_NBR' );
	my $FDaddresses;
	if ( defined $tcpar_TestCondition and $tcpar_TestCondition eq 'InvalidAddress' ) {
		$FDaddresses = '00 07 FF FF';                                            #ROM address
	}
	else {
		$FDaddresses = generateFDAddresses($tcpar_NumberOfCells);
	}

	my $FD_requestLabel;
	$FD_requestLabel->{'Options'}       = $FDoptions;
	$FD_requestLabel->{'NumberOfCells'} = sprintf( "%02X", $tcpar_NumberOfCells );    #to hex
	$FD_requestLabel->{'RAM_Address'}   = $FDaddresses;

	S_teststep_2nd_level( "Send '$tcpar_Fast_Diag_Request' request", 'AUTO_NBR' );
	if ( defined $tcpar_TestCondition and $tcpar_TestCondition eq 'BlockLengthMore' ) {

		S_teststep_2nd_level( "Increase block length by 1", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Fast_Diag_Request", $FD_requestLabel, +1 );

		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Fast_Diag_Response);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( defined $tcpar_TestCondition and $tcpar_TestCondition eq 'BlockLengthLess' ) {

		S_teststep_2nd_level( "Reduce block length by 1", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Fast_Diag_Request", $FD_requestLabel, -1 );

		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Fast_Diag_Response);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( defined $tcpar_TestCondition and $tcpar_TestCondition eq 'InvalidNumberOfCells' ) {

		my $RequestDetails = DCOM_getReqestResponseFromMapping( "REQ_$tcpar_Fast_Diag_Request", $FD_requestLabel );
		GDCOM_request( $RequestDetails->{'Request'}, "", "quiet", "No response is expected" );    #checks that no response is received
	}
	elsif ( defined $tcpar_TestCondition and $tcpar_TestCondition eq 'RAMBufferNotAvailable' ) {
		S_set_error( "Condition cannot create \n", 22 );
		return 0;
	}
	else {
		DIAG_PD_request_general( "REQ_$tcpar_Fast_Diag_Request", $tcpar_Fast_Diag_Response, $FD_requestLabel );
	}

	S_teststep_2nd_level( "Check fast diagnostic working or not before reset", 'AUTO_NBR' );
	S_wait_ms( 2000, 'wait for 2 sec' );
	_checkFastDiagnosis_Communication_Inactive();

	S_teststep( "Reset the ECU and check for consecutive fast diagnosis frames", 'AUTO_NBR' );
	S_teststep_2nd_level( "Do the reset", 'AUTO_NBR' );
	GEN_Power_on_Reset();

	S_wait_ms( 2000, 'wait for 2 sec for more stable' );
	S_teststep_2nd_level( "Check fast diagnostic after reset", 'AUTO_NBR' );
	_checkFastDiagnosis_Communication_Inactive();

	return 1;
}

sub TC_evaluation {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub TC_finalization {

	return 1;
}

sub generateFDAddresses {

	my $NumberOfCells = shift;
	my $address_href  = GEN_fetchAddressFromSADFile();         #get addressing from sad file
	my $ram_address   = $address_href->{'RAMstartaddress'};    #take RAM address
	$ram_address =~ s/(\w+)\s(\w+)\s(\w+)\s(\w+)/$1 $2 $3/;    #remove the last byte
	my $last_byte = $4;
	my $addresses = "";

	#$NumberOfCells = S_hex2dec ( '0x'.$NumberOfCells );
	foreach my $num ( 1 .. $NumberOfCells ) {
		$num       = $num | hex($last_byte);
		$num       = sprintf( "%02X", $num );
		$addresses = $addresses . "$ram_address $num ";
	}

	S_w2rep("generated addresses: $addresses");
	return $addresses;

}

sub _checkFastDiagnosis_Communication_Inactive {

	S_teststep( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(1000);
	CA_simulation_start();

	S_teststep( "Start new trace logging", 'AUTO_NBR' );
	CA_trace_start();
	S_wait_ms(1000);
	my $TracePath = GEN_printLink( CA_trace_store( GEN_generateUniqueTraceName() ) );
	S_teststep( "Stop new trace logging", 'AUTO_NBR' );
	CA_trace_stop();

	my $verdict = 'VERDICT_PASS';
	unless ( open( FH, $TracePath ) ) {
		S_set_error("Could not open trace file for reading ");
		return;
	}

	while (<FH>) {
		if ( $_ =~ m/\d+\.\d+\s+\d+\s+(651|652|653|654|655)\s+Rx/ ) {
			S_w2rep( "Fast diagnostic message found in log file, the frame is: $_  \n", 'red' );
			$verdict = 'VERDICT_FAIL';
			last;
		}
	}

	unless ( close(FH) ) {
		S_set_error("Could not close trace file for reading ");
		return;
	}
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_w2rep( "Fast diagnostic message was not found in log file as expected \n", 'blue' );
	}

	S_teststep( "Set the verdict for function", 'AUTO_NBR' );
	S_set_verdict($verdict);

	S_teststep( "Start again canoe to remove COM timeout fault", 'AUTO_NBR' );
	CA_trace_start();

	return 1;
}

1;
