#### TEST CASE MODULE
package TC_FLT_FaultList_TNT;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------



#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use INCLUDES_Project;
use Data::Dumper;
use LIFT_CD;
use LIFT_TSG4;

##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_TNT_FaultList_TNT  

requires LIFT_PD, general, evaluation

default state is faultfree ECU powered ON

=head1 PURPOSE

FaultList Test - to test the fault properties for each fault (fault status, Quali times etc)

=head1 TESTCASE DESCRIPTION


=head2 SETTINGS

I<B<Usage:>> This script can be used if the Fault list TS has been generated with the DOORS uitlity from the template

I<B<Mapping_FAULT file:>> Before running this script, make sure the fault mapping file is available and upto date for the current software.


=head2 TEST STEPS

I<B<Initialisation>>

StandardPrepNoFault (ECU is fault free)

WL is OFF


I<B<Stimulation and Measurement>>

Common Steps for all faults!

Steps for each condition:

a. Create condition

b. Read fault memory using CD/PD (fault status, snapshot memory or other project specific fault properties)

c. Read WL status


Repeat the above steps for these conditions:

	NO_FAULT
	CREATE_FAULT_CONDITION
	RESET_AFTER_FAULT_CREATION
	CLEAR_AFTER_FAULT_QUALIFIED
	RESET_AFTER_FAULT_QUALIFIED
	REMOVE_FAULT_CONDITION
	RESET_AFTER_FAULT_REMOVAL
	CLEAR_AFTER_FAULT_REMOVAL

AB12: If fault is init/cyclic, perform measurement and evaluation both for init and cyclic handling


I<B<Evaluation>>

a. condition is created

b. Fault status/property is as expected for each condition

c. WL status is as expected for each condition


I<B<Finalisation>>

-

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose' --> Purpose of the test case
	SCALAR 'faultname' --> Bosch fault name	
	SCALAR 'tolerance' --> allowed jitter/tolerance for quali/dequali times (in %) (optional parameter - can be defined for each fault in fault mapping file)
	#OPTIONS
	SCALAR 'USE_WARNINGLAMP_MEASUREMENT' --> set to 'yes' if this test condition is to be checked (WL related steps will not be performed if this is 'no')

=head2 PARAMETER EXAMPLES

	[TC_TNT_FaultList_TNT.fault1]  
	purpose		 = 'check fault properties of faults'
	faultname	= @( '<Fetch {Bosch Fault Name}>')
	tolerance = '10' #%
	#optional steps
	USE_WARNINGLAMP_MEASUREMENT = 'yes'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#FAULT PROPERTIES
my ( $defaultpar_faultname, $defaultpar_tolerance );
my ( $projectpar_SYS_Voltage, $System_Test );
my (@projectpar_Accepted_Flts);
my @mandatoryFaults = ();

#OPTIONS
my ($defaultpar_USE_WARNINGLAMP_MEASUREMENT);

#global
my ($faultproperty, $qualiType, $dequaliType);
my ( %flt_mem_struct_PD_observed, %flt_mem_struct_CD_observed, %flt_status_PD_expected, %flt_status_CD_expected, );

my ( %measuredtime, %WLStatus_expected, %WLStatus_observed, %CustomerFaultProperties_expected, %CustomerFaultProperties_observed, );

my $ABGeneration;
my @Fault_Name;
my @faultEvalMode;
my @SupportedTestconditions = (
								'NO_FAULT',                       #before fault creation
								'CREATE_FAULT_CONDITION',         #create fault condition and measure Q time for cyclic faults
								'RESET_AFTER_FAULT_CREATION',     #after fault condition is created, reset ECU
								'CLEAR_AFTER_FAULT_QUALIFIED',    #clear the fault memory (optional condition)
								'RESET_AFTER_FAULT_QUALIFIED',    #after clear, reset ECU (optional condition)
								'REMOVE_FAULT_CONDITION',         #remove the fault condition and measure DQ time for cyclic faults
								'RESET_AFTER_FAULT_REMOVAL',      #reset ECU
								'CLEAR_AFTER_FAULT_REMOVAL'       #clear
);

my (
	 $fm_DTC,             $fm_Device,            $fm_Condition,           $fm_DeviceType, $fm_Faultpriority, $fm_FaultType,
	 $fm_WLproperty,      $fm_Qualificationtime, $fm_Dequalificationtime, $fm_Unlearn,    $fm_Tolerance,     $fm_AdditionalFaults,
	 $fm_cyclicqualitime, $fm_cyclicdequalitime, $fm_initqualitime,       $fm_initdequalitime
);

our $PURPOSE;

sub TC_set_parameters {

	$System_Test        = $LIFT_config::LIFT_SystemTest;
    $System_Test        = 0 unless( defined $System_Test );

	if ( $System_Test == 1 ) {
		undef(@projectpar_Accepted_Flts);
		@projectpar_Accepted_Flts = S_read_project_parameter('Accepted_Flts');
		$projectpar_SYS_Voltage   = S_read_project_parameter('System_Voltage');
	}

    $defaultpar_faultname                   = S_read_mandatory_testcase_parameter('faultname');
	$defaultpar_tolerance                   = S_read_optional_testcase_parameter('tolerance');
	$defaultpar_USE_WARNINGLAMP_MEASUREMENT = S_read_optional_testcase_parameter('USE_WARNINGLAMP_MEASUREMENT', undef, 'yes');
	
	@mandatoryFaults = ($defaultpar_faultname);

	#to print the purpose wrt fault
	$PURPOSE = "To test the fault properties for $defaultpar_faultname";

	$faultproperty = FM_fetchFaultInfo($defaultpar_faultname) || return;
	S_w2rep("Get Fault properties for $defaultpar_faultname\n");
	S_w2rep(Dumper $faultproperty);
	S_w2rep("\n");

	$fm_Condition = FM_fetchFaultInfo( $defaultpar_faultname, 'Condition' ) || return;
	$fm_Device    = FM_fetchFaultInfo( $defaultpar_faultname, 'Device' )    || return;

	unless ($fm_DeviceType = FM_fetchFaultInfo( $defaultpar_faultname, 'DeviceType' )) {
		unless( $fm_DeviceType = DEVICE_fetchDeviceType($fm_Device) ) {
            #   NOTE: DEVICE_fetchDeviceType throw an error if could not resolved -> therefore retorn 0
            S_w2rep( "No DeviceType determined (neither from Faultmapping nor from Device Mapping)" );
            return 0;
        }
	}

	$fm_AdditionalFaults = FM_fetchFaultInfo( $defaultpar_faultname, 'AdditionalFaults' );
	foreach ( @{$fm_AdditionalFaults} ) {
		next unless /\w+/;
		S_w2rep( " Adding 'AdditionalFaults' from FaultMapping: $_ " );
        push( @mandatoryFaults, $_ );
	}

	
	@faultEvalMode = ();
	
	$fm_FaultType = FM_fetchFaultInfo( $defaultpar_faultname, 'FaultType' ) || return;
	my $faultTypeExtn = FM_fetchExtendedFaultInfo_NOERROR( $defaultpar_faultname, 'FaultType' );
	
	if(defined $faultTypeExtn){	
		S_w2rep( "Found FaultType: '$faultTypeExtn' in Mapping_FAULT_extension. This will be used instead of '$fm_FaultType' from Mapping_FAULT" );
		$fm_FaultType = $faultTypeExtn;
	}
	
	if    ( $fm_FaultType eq 'init/cyclic' )   { @faultEvalMode = ( 'cyclic', 'init' );  }
	elsif ( $fm_FaultType =~ /^init$/i)       { @faultEvalMode = ( 'init' );            }
	else { 
		@faultEvalMode = ( $fm_FaultType ); #can be any type for project but will be handled like cyclic faultEvalMode        
	}

	S_w2rep("Get the expected data for $defaultpar_faultname under each test condition\n");
	foreach my $condition (@SupportedTestconditions) {    #get the expected data for each test condition
		S_w2rep("-------------- $condition -------( $defaultpar_faultname )--------------------\n");

		#create the HASHes for the expected behaviours(status/fault properties etc)
		# TODO: to be further analysed
		my $getstatus = flt_GetExpectedStatus($condition);

		unless ( defined $getstatus ) {
			S_set_error( "Not proceeding due to error in fault mapping file", 0 );
			$PURPOSE = "!! ERROR in fault mapping file for fault entry $defaultpar_faultname !!";
			return 0;
		}
	}
	
	$qualiType = flt_getQualiType();
	$dequaliType = flt_getDequaliType(); 
	#S_user_action('ok');
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault for $defaultpar_faultname\n", 'AUTO_NBR' );
	my $verdict = GEN_StandardPrepNoFault();
	if ( $System_Test == 1 ) {
		S_teststep_2nd_level( 'Set ECU voltage to required system voltage = $projectpar_SYS_Voltage V', 'AUTO_NBR' );
		LC_SetVoltage($projectpar_SYS_Voltage);    #Set ECU voltage to System voltage
		S_teststep_2nd_level( 'Wait for 5 sec to set the system to required voltage', 'AUTO_NBR' );
		S_wait_ms(5000);
		S_w2rep("Accepted faults @projectpar_Accepted_Flts are added to optional faults ");
		push( @{ $main::ProjectDefaults->{"TEMP_OPTIONAL_FAULTS"} }, @projectpar_Accepted_Flts );    # added accepted faults from projects parameters to optional faults
	}
	S_wait_ms( 5000, "Wait for some more time after start-up" );

	return 0 unless ( $verdict eq 'VERDICT_PASS' );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	my ( $condition, $evalMode, $FDtrace_name, $FD_start_delta );
	my ( $cyclicqualitime_lower_limit, $cyclicdequalitime_lower_limit, $cyclicqualitime_upper_limit, $cyclicdequalitime_upper_limit);
	my ( $initqualitime_lower_limit, $initdequalitime_lower_limit, $initqualitime_upper_limit, $initdequalitime_upper_limit);

	if ( grep { $_ ne "init" } @faultEvalMode ) { 

		$evalMode = 'cyclic'; #default for non init faults

		S_w2log( HTML, "<font size=5>" );    # print only to HTML test report
		S_w2rep( "----------------------------- Test fault in $evalMode mode -----------------------------", 'purple' );
		S_w2log( HTML, "<font size=3>" );    # print only to HTML test report

		#check for cyclic Q/DQ time attributes
		$fm_cyclicqualitime   = FM_fetchFaultInfo( $defaultpar_faultname, 'CyclicQualificationtime' );
		$fm_cyclicdequalitime = FM_fetchFaultInfo( $defaultpar_faultname, 'CyclicDequalificationtime' );

		unless ( defined $fm_cyclicqualitime and defined $fm_cyclicdequalitime ) {
			S_w2rep(
"'CyclicQualificationtime' and 'CyclicDequalificationtime' properties are not found in Mapping_FAULT file. Checking if old attributes 'Qualificationtime' and 'Dequalificationtime' are found..."
			);
			#check for old attributes
			$fm_cyclicqualitime   = FM_fetchFaultInfo( $defaultpar_faultname, 'Qualificationtime' );
			$fm_cyclicdequalitime = FM_fetchFaultInfo( $defaultpar_faultname, 'Dequalificationtime' );

			unless ( defined $fm_cyclicqualitime and defined $fm_cyclicdequalitime ) {
				S_set_error( "Not proceeding due to error in fault mapping file: Attributes for Qualification and Dequalification time are not found.", 0 );
				$PURPOSE = "!! ERROR in fault mapping file for fault entry $defaultpar_faultname !!";
				return 0;
			}
			
			if( $fm_cyclicqualitime =~ m/init/i  ) {
    			S_w2rep("Value for Qualification time is 'Init' ms. Read ITM Init time from ProjectConst");
    			$fm_cyclicqualitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
				
    			unless( defined $fm_cyclicqualitime ) {
        			S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
        			$PURPOSE = "!! Missing attribute ITM_Init_Time_ms in ProjectConst !!";
        			return 0;
                }
                
                S_w2rep("Found 'ITM_Init_Time_ms' = $fm_cyclicqualitime. This value will be used as expected quali time");
            }
            
            if( $fm_cyclicdequalitime =~ m/init/i  ) {
    			S_w2rep("Value for Dequalification time is 'Init' ms. Read ITM Init time from ProjectConst");
    			$fm_cyclicdequalitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
				
    			unless( defined $fm_cyclicdequalitime ) {
        			S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
        			$PURPOSE = "!! Missing attribute ITM_Init_Time_ms in ProjectConst !!";
        			return 0;
                }
                
                S_w2rep("Found 'ITM_Init_Time_ms' = $fm_cyclicdequalitime. This value will be used as expected dequali time");
            }
		}
		
		#handling if expected time is a range
		if ($fm_cyclicqualitime =~ m/(\d+)\s*\-\s*(\d+)/i){ #match something like '0-10' or '0 - 10'
			$cyclicqualitime_lower_limit = $1;
			$cyclicqualitime_upper_limit = $2;
		}
		else{
			$cyclicqualitime_upper_limit = convert2Val($fm_cyclicqualitime);
		}
		
		if ($fm_cyclicdequalitime =~ m/(\d+)\s*\-\s*(\d+)/i){ #match something like '0-10' or '0 - 10'
			$cyclicdequalitime_lower_limit = $1;
			$cyclicdequalitime_upper_limit = $2;
		}
		else{
			$cyclicdequalitime_upper_limit = convert2Val($fm_cyclicdequalitime);
		}

		#------------------------ NO_FAULT -------------------------#
		$condition = 'NO_FAULT';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {    #skip this condition if CD expected status has keyword 'SKIP'
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "No specific stimulation action needed", 'AUTO_NBR' );
			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CREATE_FAULT_CONDITION -------------------------#
		$condition = 'CREATE_FAULT_CONDITION';
		S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

		my $time_measurement = FM_fetchConstant( 'FAULTMEMORY', 'time_measurements' );

		S_w2rep("Create the fault condition\n");
		#specific handling for configuration/unexpected device fault
		if ( $fm_Condition =~ m/Configuration/i and ( $fm_DeviceType eq 'Squib' or $fm_DeviceType eq 'Switch' or $fm_DeviceType eq 'PAS' or $fm_DeviceType eq 'Lamp' ) ) {
			S_teststep_2nd_level( 'For Cyclic configuration fault, disconnect device, deconfigure and ' . 'then connect it back after reset to qualify the fault after init',
								  'AUTO_NBR' );

			S_teststep_2nd_level( "DEVICE_setDeviceState( $fm_Device, 'Openline' )", 'AUTO_NBR' );
			DEVICE_setDeviceState( $fm_Device, 'Openline' );

			S_teststep_2nd_level( "DEVICE_setDeviceConfiguration( $fm_Device, 'clear' )", 'AUTO_NBR' );
			DEVICE_setDeviceConfiguration( $fm_Device, 'clear' );

			S_teststep_2nd_level( "S_wait_ms( 10000, 'wait after reset' )", 'AUTO_NBR' );
			S_wait_ms( 10000, 'wait after reset' );

			#prepare for Q time measurement using PD Fast Diagnostics before qualifying the fault
			if ( $time_measurement eq 'PD' and $qualiType eq 'cyclic') {
				S_teststep_2nd_level( "FM_PD_measureTimePreparation", 'AUTO_NBR' );
				FM_PD_measureTimePreparation( $defaultpar_faultname, 'Qualification' );
				$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Cyclic ( $defaultpar_faultname );
				S_set_timer_zero('FD_start');
			}

			S_teststep_2nd_level( "DEVICE_resetDeviceState( $fm_Device, 'Openline' )", 'AUTO_NBR' );
			DEVICE_resetDeviceState( $fm_Device, 'Openline' );
			S_set_timer_zero('fault_trigger_start'); #fault creation start reference (to be used by FM_measureTime)
		}
		else {
			#prepare for Q time measurement using PD Fast Diagnostics before qualifying the fault
			if ( $time_measurement eq 'PD' and $qualiType eq 'cyclic' ) {
				S_teststep_2nd_level( "measureTimePreparation", 'AUTO_NBR' );
				FM_PD_measureTimePreparation( $defaultpar_faultname, 'Qualification' );
				$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Cyclic ( $defaultpar_faultname );
				S_set_timer_zero('FD_start');
			}

			#call Project, then CustLib, then TNT
			if ( defined &FuncLib_Project_FM::FM_createFault ) {
				S_teststep_2nd_level( "Calling FuncLib_Project_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_Project_FM::FM_createFault($defaultpar_faultname);
			}
			elsif ( defined &FuncLib_CustLib_FM::FM_createFault ) {
				S_teststep_2nd_level( "Calling FuncLib_CustLib_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_CustLib_FM::FM_createFault($defaultpar_faultname);
			}
			else {

				# S_teststep_2nd_level( "FuncLib_TNT_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_TNT_FM::FM_createFault($defaultpar_faultname);
			
			}
			S_set_timer_zero('fault_trigger_start'); #fault creation start reference (to be used by FM_measureTime)

		}
		
		$FD_start_delta = S_read_timer_ms ('FD_start') if ( $time_measurement eq 'PD' and $qualiType eq 'cyclic' ) ; #to measure the time taken for fast diag start

		S_teststep_2nd_level( "Measure Qualification Time", 'AUTO_NBR', $condition . $evalMode . "_quali_time" );
		if ( $time_measurement eq 'PD' and $qualiType eq 'cyclic' ) {
			my $waittime    = $cyclicqualitime_upper_limit + 6000; 
			S_wait_ms ( $waittime, "wait for qualification time");
			$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Cyclic ( $defaultpar_faultname, 'Qualification', $FDtrace_name, $FD_start_delta );
		}
		else{
			$measuredtime{$condition}{$evalMode} = FM_measureTime( $defaultpar_faultname, 'Qualification', 'fault_trigger_start', $cyclicqualitime_upper_limit );
		}	

		flt_readFaultProperties( $condition, $evalMode );
		
		#handling for faults which are expected to qualify only during init
		if ($qualiType eq 'init') {
			S_teststep_2nd_level( "For faults which are expected to qualify during init, send fast diagnosis request to start measurement in the next power on cycle\n", 'AUTO_NBR' );
			S_w2rep("Note: For init Q time evaluation, time will be measured only using PD Fast Diagnosis");
			$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);
		}
		
		

		#------------------------ RESET_AFTER_FAULT_CREATION -------------------------#
		$condition = 'RESET_AFTER_FAULT_CREATION';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			GEN_Power_on_Reset();
			
			if ($qualiType eq 'init') {
				S_teststep_2nd_level( "FM_measureTime for faults qualifying during init", 'AUTO_NBR', $condition . $evalMode . "_quali_time" );
				$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Qualification', $FDtrace_name );
			}
			
			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CLEAR_AFTER_FAULT_QUALIFIED -------------------------#
		$condition = 'CLEAR_AFTER_FAULT_QUALIFIED';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "Clear the fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();

			S_teststep_2nd_level( "S_wait_ms( 10000 )", 'AUTO_NBR' );
			S_wait_ms(10000);

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ RESET_AFTER_FAULT_QUALIFIED -------------------------#
		$condition = 'RESET_AFTER_FAULT_QUALIFIED';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			GEN_Power_on_Reset();

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ REMOVE_FAULT_CONDITION -------------------------#
		$condition = 'REMOVE_FAULT_CONDITION';
		S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

#		my $time_measurement = FM_fetchConstant( 'FAULTMEMORY', 'time_measurements' );

		#prepare for DQ time measurement using PD Fast Diagnostics before dequalifying the fault
		if ( $time_measurement eq 'PD' and $dequaliType eq 'cyclic' ) {
			S_teststep_2nd_level( "FM_PD_measureTimePreparation", 'AUTO_NBR' );
			FM_PD_measureTimePreparation( $defaultpar_faultname, 'Dequalification' );
			$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Cyclic ( $defaultpar_faultname );
			S_set_timer_zero('FD_start');
		}

		S_w2rep("Remove the fault condition\n");
		#specific handling for configuration/unexpected device fault
		if ( $fm_Condition =~ m/Configuration/i and ( $fm_DeviceType eq 'Squib' or $fm_DeviceType eq 'Switch' or $fm_DeviceType eq 'PAS' or $fm_DeviceType eq 'Lamp' ) ) {
			S_teststep_2nd_level( 'For Configuration fault, currently only disconnect the device to remove fault', 'AUTO_NBR' );
			S_teststep_2nd_level( "DEVICE_setDeviceState( $fm_Device, 'Openline' )",                               'AUTO_NBR' );
			DEVICE_setDeviceState( $fm_Device, 'Openline' );
			S_set_timer_zero('fault_trigger_start'); #fault removal start reference (to be used by FM_measureTime)
		}
		else {

			# call Project, then CustLib, then TNT
			if ( defined &FuncLib_Project_FM::FM_removeFault ) {
				S_teststep_2nd_level( "Calling FuncLib_Project_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_Project_FM::FM_removeFault($defaultpar_faultname);
			}
			elsif ( defined &FuncLib_CustLib_FM::FM_removeFault ) {
				S_teststep_2nd_level( "Calling FuncLib_CustLib_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_CustLib_FM::FM_removeFault($defaultpar_faultname);
			}
			else {

				# S_teststep_2nd_level( "FuncLib_TNT_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_TNT_FM::FM_removeFault($defaultpar_faultname);
			}
			S_set_timer_zero('fault_trigger_start'); #fault removal start reference (to be used by FM_measureTime)

		}
		$FD_start_delta = S_read_timer_ms ('FD_start') if ( $time_measurement eq 'PD' and $dequaliType eq 'cyclic' ) ; #to measure the time taken for fast diag start

		S_teststep_2nd_level( "Measure Dequalification Time", 'AUTO_NBR', $condition . $evalMode . "_dequali_time" );
		if ( $time_measurement eq 'PD' and $dequaliType eq 'cyclic' ) {
			my $waittime    = $cyclicdequalitime_upper_limit + 6000; 
			S_wait_ms ( $waittime, "wait for dequalification time");
			$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Cyclic ( $defaultpar_faultname, 'Dequalification', $FDtrace_name, $FD_start_delta );
		}
		else{
			$measuredtime{$condition}{$evalMode} = FM_measureTime( $defaultpar_faultname, 'Dequalification', 'fault_trigger_start', $cyclicdequalitime_upper_limit );
		}

		flt_readFaultProperties( $condition, $evalMode );
		
		#handling for faults which are expected to qualify only during init
		if ($dequaliType eq 'init') {
			S_teststep_2nd_level( "For faults which are expected to dequalify during init, send fast diagnosis request to start measurement in the next power on cycle\n", 'AUTO_NBR' );
			S_w2rep("Note: For init DQ time evaluation, time will be measured only using PD Fast Diagnosis");
			$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);
		}

		#------------------------ RESET_AFTER_FAULT_REMOVAL -------------------------#
		$condition = 'RESET_AFTER_FAULT_REMOVAL';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			GEN_Power_on_Reset();
			
			if ($dequaliType eq 'init') {
				S_teststep_2nd_level( "FM_measureTime for faults dequalifying during init", 'AUTO_NBR', $condition . $evalMode . "_dequali_time" );
				$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Dequalification', $FDtrace_name );
			}

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CLEAR_AFTER_FAULT_REMOVAL -------------------------#
		$condition = 'CLEAR_AFTER_FAULT_REMOVAL';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "Clear the fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();

			S_teststep_2nd_level( "S_wait_ms( 10000 )", 'AUTO_NBR' );
			S_wait_ms(10000);

			flt_readFaultProperties( $condition, $evalMode );
		}

	}
	
	#handle init faults
	if ( grep { $_ eq "init" } @faultEvalMode ) {

		$evalMode = 'init';

		S_w2log( HTML, "<font size=5>" );    # print only to HTML test report
		S_w2rep( "----------------------------- Test fault in $evalMode mode -----------------------------", 'purple' );
		S_w2log( HTML, "<font size=3>" );    # print only to HTML test report

		#check for init Q/DQ time attributes
		$fm_initqualitime   = FM_fetchFaultInfo( $defaultpar_faultname, 'InitQualificationtime' );
        unless( defined $fm_initqualitime ) {
            #check if old attributes are present (ONLY) for non cyclic faults
			unless ( $fm_FaultType =~ m/cyclic/i ){
				S_w2rep( "'InitQualificationtime' property is not found in Mapping_FAULT file. Checking if old attribute 'Qualificationtime' is found..." );
				$fm_initqualitime   = FM_fetchFaultInfo( $defaultpar_faultname, 'Qualificationtime' );
			}
		}
			
		#still not found or given as 'init'
		if( not defined $fm_initqualitime or $fm_initqualitime =~ m/init/i  ) {
			S_w2rep("Value for Qualification time is not found in Mapping_FAULT file. Default time is 'Init' ms. Read ITM Init time from ProjectConst");
			$fm_initqualitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
			
			unless( defined $fm_initqualitime ) {
				S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
				$PURPOSE = "!! Missing attribute ITM_Init_Time_ms in ProjectConst !!";
				return 0;
			}
			
			S_w2rep("Found 'ITM_Init_Time_ms' = $fm_initqualitime. This value will be used as expected init quali time");
		}

		S_w2rep("Expected init Quali time = $fm_initqualitime ms ");


		$fm_initdequalitime = FM_fetchFaultInfo( $defaultpar_faultname, 'InitDequalificationtime' );
        unless( defined $fm_initdequalitime ) { 
			
			#check if old attributes are present (ONLY) for non cyclic faults
			unless ( $fm_FaultType =~ m/cyclic/i ){ 
				S_w2rep( "'InitDequalificationtime' property is not found in Mapping_FAULT file. Checking if old attribute 'Dequalificationtime' is found..." );
				$fm_initdequalitime   = FM_fetchFaultInfo( $defaultpar_faultname, 'Dequalificationtime' );
			}
		}
            
		#still not found or given as 'init'
		if( not defined $fm_initdequalitime or $fm_initdequalitime =~ m/init/i ) {
			S_w2rep("Value for Dequalification time is not found in Mapping_FAULT file. Default time is 'Init' ms. Read ITM Init time from ProjectConst");
			$fm_initdequalitime = S_get_contents_of_hash( [ 'VEHICLE', 'ITM_Init_Time_ms' ] );
			
			unless( defined $fm_initdequalitime ) {
				S_set_error( "Not proceeding due to missing attribute 'VEHICLE'-> 'ITM_Init_Time_ms' in ProjectConst.", 0 );
				$PURPOSE = "!! Missing attribute ITM_Init_Time_ms in ProjectConst !!";
				return 0;
			}
			S_w2rep("Found 'ITM_Init_Time_ms' = $fm_initdequalitime. This value will be used as expected init dequali time");
		}

		S_w2rep("Expected init Dequali time = $fm_initdequalitime ms ");
		
		
		#handling if expected time is a range
		if ($fm_initqualitime =~ m/(\d+)\s*\-\s*(\d+)/i){ #match something like '0-10' or '0 - 10'
			$initqualitime_lower_limit = $1;
			$initqualitime_upper_limit = $2;
		}
		else{
			$initqualitime_upper_limit = convert2Val ($fm_initqualitime);
		}
		
		if ($fm_initdequalitime =~ m/(\d+)\s*\-\s*(\d+)/i){ #match something like '0-10' or '0 - 10'
			$initdequalitime_lower_limit = $1;
			$initdequalitime_upper_limit = $2;
		}
		else{
			$initdequalitime_upper_limit = convert2Val ($fm_initdequalitime);
		}


		#------------------------ NO_FAULT -------------------------#
		$condition = 'NO_FAULT';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {    #skip this condition if CD expected status has keyword 'SKIP'
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "No specific stimulation action needed", 'AUTO_NBR' );
			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CREATE_FAULT_CONDITION -------------------------#
		$condition = 'CREATE_FAULT_CONDITION';
		S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

		my $time_measurement = FM_fetchConstant( 'FAULTMEMORY', 'time_measurements' );
		my $Qinit_waitTime_ms = S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_READY' ] );
		$Qinit_waitTime_ms = $initqualitime_upper_limit + 5000 if ($initqualitime_upper_limit > $Qinit_waitTime_ms);

		S_w2rep("Create the fault condition\n");
		if ( $fm_Condition =~ m/Configuration/i and ( $fm_DeviceType eq 'Squib' or $fm_DeviceType eq 'Switch' or $fm_DeviceType eq 'PAS' or $fm_DeviceType eq 'Lamp' ) ) {
			S_teststep_2nd_level( 'For Cyclic configuration fault, disconnect device, deconfigure and ' . 'then connect it back after reset to qualify the fault after init',
								  'AUTO_NBR' );

			S_teststep_2nd_level( "DEVICE_setDeviceState( $fm_Device, 'Openline' )", 'AUTO_NBR' );
			DEVICE_setDeviceState( $fm_Device, 'Openline' );

			S_teststep_2nd_level( "DEVICE_setDeviceConfiguration( $fm_Device, 'clear' )", 'AUTO_NBR' );
			DEVICE_setDeviceConfiguration( $fm_Device, 'clear' );

			S_teststep_2nd_level( "S_wait_ms( 10000, 'wait after reset' )", 'AUTO_NBR' );
			S_wait_ms( 10000, 'wait after reset' );

			#prepare for Q time measurement using PD Fast Diagnostics before dequalifying the fault
			if ( $time_measurement eq 'PD' ) {
				S_teststep_2nd_level( "FM_PD_measureTimePreparation( $defaultpar_faultname, 'Qualification' )", 'AUTO_NBR' );
				FM_PD_measureTimePreparation( $defaultpar_faultname, 'Qualification' );
			}

			S_teststep_2nd_level( "DEVICE_resetDeviceState( $fm_Device, 'Openline' )", 'AUTO_NBR' );
			DEVICE_resetDeviceState( $fm_Device, 'Openline' );
			S_set_timer_zero('fault_trigger_start'); #fault creation start reference (to be used by FM_measureTime)
		}
		else {
			if ( $time_measurement eq 'PD' ) {
				S_teststep_2nd_level( "measureTimePreparation", 'AUTO_NBR' );
				FM_PD_measureTimePreparation( $defaultpar_faultname, 'Qualification' );
			}
			
			#specific handling for init/cyclic faults (which can qualify both during init and cyclically). Prepare for time measurement during init and create fault when ECU is OFF
			if ( $fm_FaultType eq 'init/cyclic' ) {
				S_teststep_2nd_level( "Under init fault evaluation mode, send fast diagnosis request to start measurement in the next power on cycle", 'AUTO_NBR' );
				S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
				$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);

				S_teststep_2nd_level( "For init/cyclic faults, create fault when ECU is Off and then switch On", 'AUTO_NBR' );
				LC_ECU_Off();
				S_wait_ms('TIMER_ECU_OFF');
			}

			#call Project, then CustLib, then TNT
			if ( defined &FuncLib_Project_FM::FM_createFault ) {
				S_teststep_2nd_level( "Calling FuncLib_Project_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_Project_FM::FM_createFault($defaultpar_faultname);
			}
			elsif ( defined &FuncLib_CustLib_FM::FM_createFault ) {
				S_teststep_2nd_level( "Calling FuncLib_CustLib_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_CustLib_FM::FM_createFault($defaultpar_faultname);
			}
			else {
				S_teststep_2nd_level( "FuncLib_TNT_FM::FM_createFault", 'AUTO_NBR' );
				FuncLib_TNT_FM::FM_createFault($defaultpar_faultname);
			}
			S_set_timer_zero('fault_trigger_start'); #fault creation start reference (to be used by FM_measureTime)

			if ( $fm_FaultType eq 'init/cyclic' ) {
				S_teststep_2nd_level( "Switch ECU On after creating fault", 'AUTO_NBR' );
				LC_ECU_On();
				S_wait_ms( $Qinit_waitTime_ms, "wait after power ON" );
			}
		}

		#stop fast diag which was started from power ON
		if ( $fm_FaultType eq 'init/cyclic' ) {
			S_teststep_2nd_level( "Measure qualification time for init/cyclic faults", 'AUTO_NBR', $condition . $evalMode . "_quali_time" );
			$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Qualification', $FDtrace_name );
		}
		else{
			S_wait_ms( $initqualitime_upper_limit, "wait after fault creation" );
		}

		flt_readFaultProperties( $condition, $evalMode );

		#handling for non init/cyclic faults (init only faults like CrossCoupling)
		if ( $fm_FaultType eq 'init' ) {
			S_teststep_2nd_level( "Under init fault evaluation mode, send fast diagnosis request to start measurement in the next power on cycle\n", 'AUTO_NBR' );
			S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
			$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);
		}

		#------------------------ RESET_AFTER_FAULT_CREATION -------------------------#
		$condition = 'RESET_AFTER_FAULT_CREATION';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms( $Qinit_waitTime_ms, "wait after power ON" );

			if ( $fm_FaultType eq 'init' ) {
				S_teststep_2nd_level( "FM_measureTime for init faults", 'AUTO_NBR', $condition . $evalMode . "_quali_time" );
				$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Qualification', $FDtrace_name );
			}

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CLEAR_AFTER_FAULT_QUALIFIED -------------------------#
		$condition = 'CLEAR_AFTER_FAULT_QUALIFIED';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "Clear the fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();

			S_teststep_2nd_level( "S_wait_ms( 10000 )", 'AUTO_NBR' );
			S_wait_ms(10000);

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ RESET_AFTER_FAULT_QUALIFIED -------------------------#
		$condition = 'RESET_AFTER_FAULT_QUALIFIED';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms( $Qinit_waitTime_ms, "wait after power ON" );

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ REMOVE_FAULT_CONDITION -------------------------#
		$condition = 'REMOVE_FAULT_CONDITION';
		S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

		my $time_measurement = FM_fetchConstant( 'FAULTMEMORY', 'time_measurements' );
		my $DQinit_waitTime_ms = S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_READY' ] );
		$DQinit_waitTime_ms = $initdequalitime_upper_limit + 5000 if ($initdequalitime_upper_limit > $DQinit_waitTime_ms);

		if ( $time_measurement eq 'PD' ) {
			S_teststep_2nd_level( "FM_PD_measureTimePreparation", 'AUTO_NBR' );
			FM_PD_measureTimePreparation( $defaultpar_faultname, 'Dequalification' );
		}

		S_w2rep("Remove the fault condition\n");
		if ( $fm_Condition =~ m/Configuration/i and ( $fm_DeviceType eq 'Squib' or $fm_DeviceType eq 'Switch' or $fm_DeviceType eq 'PAS' or $fm_DeviceType eq 'Lamp' ) ) {
			S_teststep_2nd_level( 'For Configuration fault, currently only disconnect the device to remove fault', 'AUTO_NBR' );
			S_teststep_2nd_level( "DEVICE_setDeviceState( $fm_Device, 'Openline' )",                               'AUTO_NBR' );
			DEVICE_setDeviceState( $fm_Device, 'Openline' );
			S_set_timer_zero('fault_trigger_start'); #fault removal start reference (to be used by FM_measureTime)
		}
		else {
			if ( $fm_FaultType eq 'init/cyclic' ) {
				S_teststep_2nd_level( "Under init fault evaluation mode, send fast diagnosis request to start measurement in the next power on cycle", 'AUTO_NBR' );
				S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
				$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);

				S_teststep_2nd_level( "For init/cyclic faults, remove fault when ECU is Off and then switch On", 'AUTO_NBR' );
				LC_ECU_Off();
				S_wait_ms('TIMER_ECU_OFF');
			}

			# call Project, then CustLib, then TNT
			if ( defined &FuncLib_Project_FM::FM_removeFault ) {
				S_teststep_2nd_level( "Calling FuncLib_Project_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_Project_FM::FM_removeFault($defaultpar_faultname);
			}
			elsif ( defined &FuncLib_CustLib_FM::FM_removeFault ) {
				S_teststep_2nd_level( "Calling FuncLib_CustLib_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_CustLib_FM::FM_removeFault($defaultpar_faultname);
			}
			else {
				S_teststep_2nd_level( "FuncLib_TNT_FM::FM_removeFault", 'AUTO_NBR' );
				FuncLib_TNT_FM::FM_removeFault($defaultpar_faultname);
			}
			S_set_timer_zero('fault_trigger_start'); #fault removal start reference (to be used by FM_measureTime)

			if ( $fm_FaultType eq 'init/cyclic' ) {
				S_teststep_2nd_level( "Switch ECU On after removing fault", 'AUTO_NBR' );
				LC_ECU_On();
				S_wait_ms( $DQinit_waitTime_ms, "wait after power ON" );
			}
		}

		if ( $fm_FaultType eq 'init/cyclic' ) {
			S_teststep_2nd_level( "Measure dequalification time for init/cyclic faults", 'AUTO_NBR', $condition . $evalMode . "_dequali_time" );
			$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Dequalification', $FDtrace_name );
		}
		else{
			S_wait_ms( $initdequalitime_upper_limit, "wait after fault removal" );
		}
		
		flt_readFaultProperties( $condition, $evalMode );

		if ( $fm_FaultType eq 'init' ) {
			S_teststep_2nd_level( "Under init fault evaluation mode, send fast diagnosis request to start measurement in the next power on cycle\n", 'AUTO_NBR' );
			S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
			$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($defaultpar_faultname);
			S_wait_ms (500);
		}

		#------------------------ RESET_AFTER_FAULT_REMOVAL -------------------------#
		$condition = 'RESET_AFTER_FAULT_REMOVAL';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "HARD SYSTEM RESET", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms( $DQinit_waitTime_ms, "wait after power ON" );

			if ( $fm_FaultType eq 'init' ) {
				S_teststep_2nd_level( "FM_measureTime for init faults", 'AUTO_NBR', $condition . $evalMode . "_dequali_time" );
				$measuredtime{$condition}{$evalMode} = FM_PD_measureEndQualiDequaliTime_Init( $defaultpar_faultname, 'Dequalification', $FDtrace_name );
			}

			flt_readFaultProperties( $condition, $evalMode );
		}

		#------------------------ CLEAR_AFTER_FAULT_REMOVAL -------------------------#
		$condition = 'CLEAR_AFTER_FAULT_REMOVAL';
		if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} ne 'SKIP' ) {
			S_teststep( "-------------- $condition ($evalMode) -----------------", 'AUTO_NBR' );

			S_teststep_2nd_level( "Clear the fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();

			S_teststep_2nd_level( "S_wait_ms( 10000 )", 'AUTO_NBR' );
			S_wait_ms(10000);

			flt_readFaultProperties( $condition, $evalMode );
		}

	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $expQtime, $expDQtime );

	foreach my $evalMode (@faultEvalMode) {

		if ( $evalMode eq 'init' ) {
			$expQtime  = $fm_initqualitime;
			$expDQtime = $fm_initdequalitime;
		}
		else {
			$evalMode = 'cyclic';
			$expQtime  = $fm_cyclicqualitime;
			$expDQtime = $fm_cyclicdequalitime;
		}

		S_w2log( HTML, "<font size=5>" );    # print only to HTML test report
		S_w2rep( "----------------------------- Test fault in $evalMode mode -----------------------------", 'purple' );
		S_w2log( HTML, "<font size=3>" );    # print only to HTML test report

		foreach my $condition (@SupportedTestconditions) {
			next if((($condition eq 'CREATE_FAULT_CONDITION') or ($condition eq 'REMOVE_FAULT_CONDITION')) and ($defaultpar_faultname =~/HighsidePowerstage/i or $defaultpar_faultname =~/LowsidePowerstage/i));
			next if (($condition eq 'CLEAR_AFTER_FAULT_QUALIFIED') and ($defaultpar_faultname =~/LowsidePowerstage/i));
			#for DOORS TR
			S_teststep_expected_NOHTML("------------ $condition ($evalMode) -------------");
			S_teststep_detected_NOHTML("------------ $condition ($evalMode) -------------");

			#skip this condition if expected status has keyword 'SKIP'
			next if ( defined $flt_status_CD_expected{$condition} and $flt_status_CD_expected{$condition} eq 'SKIP' );
			

			S_w2rep("-------------- $condition ----( $evalMode )--------------------\n");
			if ( defined $measuredtime{$condition}{$evalMode} ) {
				#Q/DQ times will be measured under RESET_AFTER_FAULT_CREATION for init faults and under CREATE_FAULT_CONDITION for cyclic or init/cyclic faults
				if ( ($condition eq 'CREATE_FAULT_CONDITION' and $qualiType eq 'cyclic') or ($condition eq 'RESET_AFTER_FAULT_CREATION' and $qualiType eq 'init') or ( $condition eq 'RESET_AFTER_FAULT_CREATION' and $fm_FaultType eq 'init' ) ) {
					my ( $verdict, $tol_low_limit, $tol_up_limit ) =
					  FM_evaluateQualiDequaliTime( $defaultpar_faultname, $measuredtime{$condition}{$evalMode}, "qualitime_$qualiType", $defaultpar_tolerance, $expQtime );
					S_teststep_expected( "Quali time: $tol_low_limit - $tol_up_limit ms (exact:$expQtime ms)", $condition . $evalMode . "_quali_time" );

					S_teststep_detected( "Quali time: " . $measuredtime{$condition}{$evalMode} . " ms", $condition . $evalMode . "_quali_time" ) if ( $verdict eq 'VERDICT_PASS' );
					S_teststep_detected( "MISMATCH: Quali time: " . $measuredtime{$condition}{$evalMode} . " ms", $condition . $evalMode . "_quali_time" )
					  if ( $verdict eq 'VERDICT_FAIL' );
				}
				elsif ( ($condition eq 'REMOVE_FAULT_CONDITION' and $dequaliType eq 'cyclic') or  ($condition eq 'RESET_AFTER_FAULT_REMOVAL' and $dequaliType eq 'init') or ( $condition eq 'RESET_AFTER_FAULT_REMOVAL' and $fm_FaultType eq 'init' ) ) {
					my ( $verdict, $tol_low_limit, $tol_up_limit ) =
					  FM_evaluateQualiDequaliTime( $defaultpar_faultname, $measuredtime{$condition}{$evalMode}, "dequalitime_$dequaliType", $defaultpar_tolerance, $expDQtime );
					S_teststep_expected( "Dequali time:  $tol_low_limit - $tol_up_limit ms (exact:$expDQtime ms) ", $condition . $evalMode . "_dequali_time" );

					S_teststep_detected( "Dequali time: " . $measuredtime{$condition}{$evalMode} . " ms", $condition . $evalMode . "_dequali_time" )
					  if ( $verdict eq 'VERDICT_PASS' );
					S_teststep_detected( "MISMATCH: Dequali time: " . $measuredtime{$condition}{$evalMode} . " ms", $condition . $evalMode . "_dequali_time" )
					  if ( $verdict eq 'VERDICT_FAIL' );
				}
			}
			
			
			
			#---------------- PD fault status evaluation ------------------
			
			#for bit2 (stored bit in PD status), move 7 characters to right from 0th char 0bxxxxx1xx
			my $storedbit = S_0x2dec( substr( $flt_status_CD_expected{$condition}, 6, 1 ) );
			#if fault should be stored
			if ( $storedbit == 1 ) {
				unless ( $defaultpar_faultname =~ m/CrossCoupl/i ) {    #execute for faults other than cross coupled fault
					S_w2rep("Evaluating fault memory using PD");
					S_teststep_expected( "PD faults: @mandatoryFaults ", $condition . $evalMode . "_read_RB_faults" );
					my $verdict = FM_evaluateFaults( $flt_mem_struct_PD_observed{$condition}{$evalMode}, [@mandatoryFaults] );    #confirm that no other faults are present

					S_teststep_detected( "PD faults: @{ $flt_mem_struct_PD_observed{$condition}{$evalMode}->{fault_text} } ", $condition . $evalMode . "_read_RB_faults" )
					  if ( $verdict eq 'VERDICT_PASS' );
					S_teststep_detected( "MISMATCH: PD faults: @{ $flt_mem_struct_PD_observed{$condition}{$evalMode}->{fault_text} } ", $condition . $evalMode . "_read_RB_faults" )
					  if ( $verdict eq 'VERDICT_FAIL' );
				}
			}
			else {
				S_w2rep("Evaluating fault memory using PD");
				S_teststep_expected( "PD faults: no faults", $condition . $evalMode . "_read_RB_faults" );
				my $verdict = FM_evaluateFaults( $flt_mem_struct_PD_observed{$condition}{$evalMode}, [] );                        #confirm that no faults are present

				S_teststep_detected( "PD faults: no faults", $condition . $evalMode . "_read_RB_faults" ) if ( $verdict eq 'VERDICT_PASS' );
				S_teststep_detected( "MISMATCH: PD faults: @{ $flt_mem_struct_PD_observed{$condition}{$evalMode}->{fault_text} } ", $condition . $evalMode . "_read_RB_faults" )
				  if ( $verdict eq 'VERDICT_FAIL' );

			}
			
			
			
			#---------------- CD fault status evaluation ------------------
			
			my $obs_flt_stat = CD_get_fault_status( $flt_mem_struct_CD_observed{$condition}{$evalMode}, $defaultpar_faultname );
			my $flt_stat_bin = sprintf( "0b%08b", hex($obs_flt_stat) );
			S_teststep_expected( "CD fault status: " . $flt_status_CD_expected{$condition}, $condition . $evalMode . "_read_CU_faults" );

			#FM_checkFaultStatus( $flt_mem_struct_CD_observed{$condition}, $defaultpar_faultname, $flt_status_CD_expected{$condition} );
			my $verdict = EVAL_evaluate_value( "CD fault status", $obs_flt_stat, '==', $flt_status_CD_expected{$condition} );

			S_teststep_detected( "CD fault status: " . $flt_stat_bin . " ($obs_flt_stat)",           $condition . $evalMode . "_read_CU_faults" ) if ( $verdict eq 'VERDICT_PASS' );
			S_teststep_detected( "MISMATCH: CD fault status: " . $flt_stat_bin . " ($obs_flt_stat)", $condition . $evalMode . "_read_CU_faults" ) if ( $verdict eq 'VERDICT_FAIL' );

			if ( $storedbit == 1 ) {

				#execute for faults other than cross coupled fault
				unless ( $defaultpar_faultname =~ m/CrossCoupl/i ) {

					#confirm that no other faults are present
					FM_evaluateFaults( $flt_mem_struct_CD_observed{$condition}{$evalMode}, [@mandatoryFaults] );
				}
			}
			
			
			
			#---------------- Cust fault properties evaluation ------------------

			if ( defined &FM_readCustomerFaultProperties ) {    #optional function (If project wants, they can define it in FuncLib_Project_FM or FuncLib_CustLib_FM
				S_teststep_expected( "Customer Fault Properties", $condition . $evalMode . "_read_CU_faults_prop" );
				FM_evaluateCustomerFaultProperties( $CustomerFaultProperties_expected{$condition}{$evalMode}, $CustomerFaultProperties_observed{$condition}{$evalMode} );
			}
			
			
			
			#---------------- Warning Lamp evaluation ------------------

			if ( $defaultpar_USE_WARNINGLAMP_MEASUREMENT eq 'yes' ) {

				unless ( defined $WLStatus_expected{$condition} ) {
					S_set_error("Missing expected WL status for condition $condition");
					next;
				}
				unless ( defined $WLStatus_observed{$condition} ) {
					S_set_error("Missing obtained WL status for condition $condition");
					next;
				}

				my $verdict;
				if ( $WLStatus_observed{$condition}{$evalMode} =~ m/^0x[0-9A-F]+$/i or $WLStatus_observed{$condition}{$evalMode} =~ m/^\d+$/ )
				{    #contains hex or decimal numbers, compare the values
					$verdict = EVAL_evaluate_value( "WL status", $WLStatus_observed{$condition}{$evalMode}, '==', $WLStatus_expected{$condition} );
				}
				else {    #if strings should be compared
					$verdict = EVAL_evaluate_string( "WL status", $WLStatus_expected{$condition}, $WLStatus_observed{$condition}{$evalMode} );
				}

				S_teststep_expected( "WL status: " . $WLStatus_expected{$condition} . "\n", $condition . $evalMode . "_read_WL_status" );

				S_teststep_detected( "WL status: " . $WLStatus_observed{$condition}{$evalMode} . "\n", $condition . $evalMode . "_read_WL_status" )
				  if ( $verdict eq 'VERDICT_PASS' );
				S_teststep_detected( "MISMATCH: WL status: " . $WLStatus_observed{$condition}{$evalMode} . "\n", $condition . $evalMode . "_read_WL_status" )
				  if ( $verdict eq 'VERDICT_FAIL' );
			}

		}
	}

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	if ( $defaultpar_faultname =~ m/Configuration|Unexpected/i ) {
		S_w2rep("For device configuration fault, re-configure and re-connect the device");
		if ( $fm_DeviceType eq 'Squib' or $fm_DeviceType eq 'Switch' or $fm_DeviceType eq 'PAS' or $fm_DeviceType eq 'Lamp' ) {
			DEVICE_setDeviceConfiguration( $fm_Device, 'set' );
			DEVICE_resetDeviceState( $fm_Device, 'Openline' );
			S_wait_ms(8000);
		}
	}
	GEN_Finalization();
	if ( $System_Test == 1 ) {
		my $len = scalar @projectpar_Accepted_Flts;
		#
        #  VERY DANGEROUS !!!  This block is manipulating the global settings 
        #      of $main::ProjectDefaults->{"TEMP_OPTIONAL_FAULTS"}     !!!!
        # 
        foreach ( 1 .. $len ) {
			pop( @{ $main::ProjectDefaults->{"TEMP_OPTIONAL_FAULTS"} } );       #    VERY DANGEROUS !!!  This block is manipulating the global settings
		}

		#my @temp = @{$main::ProjectDefaults->{"TEMP_OPTIONAL_FAULTS"}};
		S_w2rep("Accepted faults- @projectpar_Accepted_Flts are removed from optional faults");
	}

	return 1;
}

sub flt_GetExpectedStatus {
	my $condition = shift;

	#create the HASHes for the expected behaviours
	# (fault status, WL status, fault priority or other customer fault properties) based on the type of fault
	$flt_status_CD_expected{$condition} = FM_fetchExpectedFaultStatus( $defaultpar_faultname, $condition ) || return;

	#$flt_status_PD_expected{$condition} = FM_fetchExpectedFaultStatus ($defaultpar_faultname, $condition, $fm_FaultType ) || return;

	if ( $defaultpar_USE_WARNINGLAMP_MEASUREMENT eq 'yes' ) {
		$WLStatus_expected{$condition} = FM_fetchExpectedWLStatus( $defaultpar_faultname, $condition ) || return;
	}

	#optional function (If project wants, they can define it in FuncLib_Project_FM or FuncLib_CustLib_FM
	if ( defined &FM_fetchExpectedCustomerFaultProperties ) {

		#e.g. $CustomerFaultProperties_expected{'CREATE_FAULT_CONDITION'}{'Unlearn'}, $CustomerFaultProperties_expected{'CREATE_FAULT_CONDITION'}{'Priority'} etc..
		$CustomerFaultProperties_expected{$condition} = FM_fetchExpectedCustomerFaultProperties( $defaultpar_faultname, $condition ) || return;
	}

	return 1;

}

sub flt_readFaultProperties {
	my $condition = shift;
	my $evalMode  = shift;

	flt_readFaultMemories( $condition, $evalMode );
	flt_readCustomerFaultProperties( $condition, $evalMode );
	flt_readWarningLampStatus( $condition, $evalMode );

}

sub flt_readFaultMemories {
	my $condition = shift;
	my $evalMode  = shift;

	S_teststep_2nd_level( "Read the fault recorder PD", 'AUTO_NBR', $condition . $evalMode . "_read_RB_faults" );
	$flt_mem_struct_PD_observed{$condition}{$evalMode} = FM_PD_readFaultMemory();

	S_teststep_2nd_level( "Read the fault recorder CD", 'AUTO_NBR', $condition . $evalMode . "_read_CU_faults" );
	$flt_mem_struct_CD_observed{$condition}{$evalMode} = FM_CD_readFaultMemory(0x08);

	return 1;
}

sub flt_readCustomerFaultProperties {
	my $condition = shift;
	my $evalMode  = shift;

	if ( defined &FM_readCustomerFaultProperties ) {    #optional function (If project wants, they can define it in FuncLib_Project_FM or FuncLib_CustLib_FM
		S_teststep_2nd_level( "Read Customer Fault Properties", 'AUTO_NBR', $condition . $evalMode . "_read_CU_faults_prop" );
		$CustomerFaultProperties_observed{$condition}{$evalMode} = FM_readCustomerFaultProperties($defaultpar_faultname);
	}

	return 1;
}

sub flt_readWarningLampStatus {
	my $condition = shift;
	my $evalMode  = shift;

	if ( $defaultpar_USE_WARNINGLAMP_MEASUREMENT eq 'yes' ) {
		S_teststep_2nd_level( "Read the WL status\n", 'AUTO_NBR', $condition . $evalMode . "_read_WL_status" );
		$WLStatus_observed{$condition}{$evalMode} = GEN_readWLStatus();
	}

	return 1;
}

sub flt_getQualiType{
	
	my $filteredbit_createFault = S_0x2dec( substr( $flt_status_CD_expected{'CREATE_FAULT_CONDITION'}, 9, 1 ) );
	return 'cyclic' if( $filteredbit_createFault == 1);
	
	my $filteredbit_resetAfterFaultCreation = S_0x2dec( substr( $flt_status_CD_expected{'RESET_AFTER_FAULT_CREATION'}, 9, 1 ) );
	return 'init' if( $filteredbit_createFault == 0 and $filteredbit_resetAfterFaultCreation == 1);
	
	return 'noQuali';
	
}

sub flt_getDequaliType{
	
	my $filteredbit_removeFault = S_0x2dec( substr( $flt_status_CD_expected{'REMOVE_FAULT_CONDITION'}, 9, 1 ) );
	return 'cyclic' if( $filteredbit_removeFault == 0);
	
	my $filteredbit_resetAfterFaultRemoval = S_0x2dec( substr( $flt_status_CD_expected{'RESET_AFTER_FAULT_REMOVAL'}, 9, 1 ) );
	return 'init' if( $filteredbit_removeFault == 1 and $filteredbit_resetAfterFaultRemoval == 0);
	
	return 'noDequali';
}

sub convert2Val {
	my $text = shift;
	
	return 10000 if ($text eq 'permanent'); #only used for wait time
	
	return $text;
}

1;

__END__
