# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_FsCurrentCycle;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.5
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

#use LIFT_PD;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " if an internal failsafe fault is detected, a specified fault reaction is triggered for the current operation cycle ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_FsCurrentCycle 

=head1 PURPOSE

 if an internal failsafe fault is detected, a specified fault reaction is triggered for the current operation cycle

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat

    [initialisation]
    switch ECU on
    clear fault memory
    switch ECU off
    get temperature

    [stimulation & measurement]
    switch ECU on
    wait for ini end
	qualify failsafe fault
	- read warning indicator state
	- read ECU mode
	dequalify failsafe fault
	- read warning indicator state
	- read ECU mode
	reset ECU
	- read fault recorder
	- read warning indicator state
	- read ECU mode

    [evaluation]
	check that failsafe fault is in correct state
	check that warning indicator is in correct state
	check that ECU mode is correct

    [finalisation]
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_FR_FsCurrentCycle.FailsafeFault_PermanentLampOn]
    purpose                     = 'check that the system behaviour for FailsafeFault_PermanentLampOn for the current cycle correct is'
    Ubat                        = 12.4
    FailsafeFault               = 'rb_sft_ClockMonitoring_flt'
	WarningIndicatorState_step3 = 'On'
	ECUMode_step3               = 'IdleMode'
	WarningIndicatorState_step5 = 'On'
	ECUMode_step5               = 'IdleMode'
    FailsafeFaultState_step7    = 'dequalified'
    WarningIndicatorState_step7 = 'Off'
    ECUMode_step7               = 'NormalDriving'
    
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch, $fltmemPrimary );

my ( $tcpar_ubat, $tcpar_failsafeFault, $tcpar_failsafeFaultState_step7, $tcpar_warningIndicatorState_step7, $tcpar_ecuMode_step7 );
my ( $tcpar_warningIndicatorState_step3, $tcpar_ecuMode_step3, $tcpar_warningIndicatorState_step5, $tcpar_ecuMode_step5 );
my $time4FaultManipulation_ms = 3000;
my ( $ecuProperties_href_step3, $ecuProperties_href_step5, $ecuProperties_href_step7 );

# my ( $result, $BoschMemorySize, $minAutarkyTime_ms, $repetionTime_ms );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat                        = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_failsafeFault               = GEN_Read_mandatory_testcase_parameter('FailsafeFault');
	$tcpar_warningIndicatorState_step3 = GEN_Read_mandatory_testcase_parameter('WarningIndicatorState_step3');
	$tcpar_ecuMode_step3               = GEN_Read_mandatory_testcase_parameter('ECUMode_step3');
	$tcpar_warningIndicatorState_step5 = GEN_Read_mandatory_testcase_parameter('WarningIndicatorState_step5');
	$tcpar_ecuMode_step5               = GEN_Read_mandatory_testcase_parameter('ECUMode_step5');
	$tcpar_failsafeFaultState_step7    = GEN_Read_mandatory_testcase_parameter('FailsafeFaultState_step7');
	$tcpar_warningIndicatorState_step7 = GEN_Read_mandatory_testcase_parameter('WarningIndicatorState_step7');
	$tcpar_ecuMode_step7               = GEN_Read_mandatory_testcase_parameter('ECUMode_step7');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Qualify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "qualify" } );    #PD_ManipulateFaultMemory( $tcpar_failsafeFault, "qualify" );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep( "Read all information which is evaluated", 'AUTO_NBR' );
	S_teststep_2nd_level( "Read ECU mode and warning indicator state", 'AUTO_NBR', 'ECUMode_Lamp1' );
	$ecuProperties_href_step3 = PRD_Get_ECU_Properties( { Property_names => [ 'ECU_status', 'Lamp_status' ] } );

	S_teststep( "Dequalify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "dequalify" } );    #PD_ManipulateFaultMemory( $tcpar_failsafeFault, "dequalify" );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep( "Read all information which is evaluated", 'AUTO_NBR' );
	S_teststep_2nd_level( "Read ECU mode and warning indicator state", 'AUTO_NBR', 'ECUMode_Lamp2' );
	$ecuProperties_href_step5 = PRD_Get_ECU_Properties( { Property_names => [ 'ECU_status', 'Lamp_status' ] } );

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset(1);

	S_teststep( "Read all information which is evaluated", 'AUTO_NBR' );
	S_teststep_2nd_level( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemoryBosch' );
	$fltmemBosch = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "Read primary fault memory", 'AUTO_NBR', 'FaultMemoryPrimary' );
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep_2nd_level( "Read ECU mode and warning indicator state", 'AUTO_NBR', 'ECUMode_Lamp3' );
	$ecuProperties_href_step7 = PRD_Get_ECU_Properties( { Property_names => [ 'ECU_status', 'Lamp_status' ] } );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $expectedFaults, $detectedWarningIndicatorState, $detectedEcuMode );
	my ( $lampStatus1, $lampStatus2, $lampStatus3 );

	$detectedWarningIndicatorState = $ecuProperties_href_step3->{'Lamp_status'}->{'SystemWarningLamp'};
	S_teststep_expected( "Warning indicator state is '$tcpar_warningIndicatorState_step3'", 'ECUMode_Lamp1' );
	S_teststep_detected( "Warning indicator state is '$detectedWarningIndicatorState'", 'ECUMode_Lamp1' );
	if    ( $ecuProperties_href_step3->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $ecuProperties_href_step3->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                                                    { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "Warning indicator state", $tcpar_warningIndicatorState_step3, $lampStatus1 );

	$detectedEcuMode = $ecuProperties_href_step3->{'ECU_status'}->{'ECU_mode'};
	S_teststep_expected( "ECU mode is '$tcpar_ecuMode_step3'", 'ECUMode_Lamp1' );
	S_teststep_detected( "ECU mode is '$detectedEcuMode'", 'ECUMode_Lamp1' );
	EVAL_evaluate_string( "ECU Mode", $tcpar_ecuMode_step3, $detectedEcuMode );

	$detectedWarningIndicatorState = $ecuProperties_href_step5->{'Lamp_status'}->{'SystemWarningLamp'};
	S_teststep_expected( "Warning indicator state is '$tcpar_warningIndicatorState_step5'", 'ECUMode_Lamp2' );
	S_teststep_detected( "Warning indicator state is '$detectedWarningIndicatorState'", 'ECUMode_Lamp2' );
	if    ( $ecuProperties_href_step5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $ecuProperties_href_step5->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                                                    { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "Warning indicator state", $tcpar_warningIndicatorState_step5, $lampStatus2 );

	$detectedEcuMode = $ecuProperties_href_step5->{'ECU_status'}->{'ECU_mode'};
	S_teststep_expected( "ECU mode is '$tcpar_ecuMode_step5'", 'ECUMode_Lamp2' );
	S_teststep_detected( "ECU mode is '$detectedEcuMode'", 'ECUMode_Lamp2' );
	EVAL_evaluate_string( "ECU Mode", $tcpar_ecuMode_step5, $detectedEcuMode );

	if ( $tcpar_failsafeFaultState_step7 eq 'dequalified' ) {
		$expectedFaults->{$tcpar_failsafeFault} =
		  { 'DecodedStatus' => { 'TestFailed' => 0 } };
	}
	else {
		$expectedFaults->{$tcpar_failsafeFault} =
		  { 'DecodedStatus' => { 'TestFailed' => 1 } };
	}
	$fltmemBosch->evaluate_specific_faults( $expectedFaults, "FaultMemoryBosch" );

	$fltmemPrimary->evaluate_specific_faults( $expectedFaults, "FaultMemoryPrimary" );

	$detectedWarningIndicatorState = $ecuProperties_href_step7->{'Lamp_status'}->{'SystemWarningLamp'};
	S_teststep_expected( "Warning indicator state is '$tcpar_warningIndicatorState_step7'", 'ECUMode_Lamp3' );
	S_teststep_detected( "Warning indicator state is '$detectedWarningIndicatorState'", 'ECUMode_Lamp3' );
	if    ( $ecuProperties_href_step7->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus3 = 'Off'; }
	elsif ( $ecuProperties_href_step7->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus3 = 'On'; }
	else                                                                                    { $lampStatus3 = 'Error'; }
	EVAL_evaluate_string( "Warning indicator state", $tcpar_warningIndicatorState_step7, $lampStatus3 );

	$detectedEcuMode = $ecuProperties_href_step7->{'ECU_status'}->{'ECU_mode'};
	S_teststep_expected( "ECU mode is '$tcpar_ecuMode_step7'", 'ECUMode_Lamp3' );
	S_teststep_detected( "ECU mode is '$detectedEcuMode'", 'ECUMode_Lamp3' );
	EVAL_evaluate_string( "ECU Mode", $tcpar_ecuMode_step7, $detectedEcuMode );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	PRD_Clear_Fault_Memory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

