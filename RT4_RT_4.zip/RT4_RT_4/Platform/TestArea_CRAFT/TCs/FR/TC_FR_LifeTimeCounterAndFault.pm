# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_LifeTimeCounterAndFault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.5
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

#use LIFT_PD;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that life time counter is incremented and erased ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_LifeTimeCounterAndFault 

=head1 PURPOSE

 check that life time counter is incremented and erased

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat

    [initialisation]
    switch ECU on
    clear fault memory
    switch ECU off
    get temperature

    [stimulation & measurement]
	switch ECU on

	qualify failsafe fault
	dequalify failsafe fault
	check life time counter

	repeat step 2 - 4 for (FailsafeLimit -1) times

	check fault memory

	repeat step 2 -4 once more

	check fault memory
	erase fault memory
	check fault memory
	check life time counter

    [evaluation]
	life time counter is incremented correctly
	only failsafe fault is dequalified
	failsafe fault is dequalified, lifetime fault is qualified
	no faults stored
	life time counter = 0

    [finalisation]
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_FR_LifeTimeCounterAndFault.FailsafeFault_PermanentLampOn]
    purpose              = 'check that life time counter and life time fault are working correct for FailsafeFault_PermanentLampOn'
    Ubat                 = 12.4
	FailsafeFault        = 'rb_sft_ClockMonitoring_flt'
	FailsafeLimit        = 5
	LifeTimeFault        = 'rb_lfm_LifeTimeLamp_flt'
	LifeTimeCounterLabel = 'lfm_LifeTimeCounters_df(0)'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1,   $fltmemBosch2,   $fltmemBosch3,   $fltmemBosch4 );
my ( $fltmemPrimary1, $fltmemPrimary2, $fltmemPrimary3, $fltmemPrimary4 );

my ( $tcpar_ubat, $tcpar_failsafeFault, $tcpar_failsafeLimit, $tcpar_lifeTimeFault, $tcpar_lifeTimeCounterLabel );
my $time4FaultManipulation_ms = 3000;
my @lifeTimeCounter           = ();
my $lifeTimeCounterValue;
my ( $i, $value_aref, $type, $dec_value );

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat                 = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_failsafeFault        = GEN_Read_mandatory_testcase_parameter('FailsafeFault');
	$tcpar_failsafeLimit        = GEN_Read_mandatory_testcase_parameter('FailsafeLimit');
	$tcpar_lifeTimeFault        = GEN_Read_mandatory_testcase_parameter('LifeTimeFault');
	$tcpar_lifeTimeCounterLabel = GEN_Read_mandatory_testcase_parameter('LifeTimeCounterLabel');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Qualify and dequalify failsaft fault '$tcpar_failsafeFault' for '$tcpar_failsafeLimit-1' times", 'AUTO_NBR', 'lifeTimeCounter' );

	for ( $i = 1 ; $i < $tcpar_failsafeLimit ; $i++ ) {
		S_teststep_2nd_level( "Qualify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
		PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "qualify" } );
		S_wait_ms($time4FaultManipulation_ms);

		S_teststep_2nd_level( "Dequalify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
		PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "dequalify" } );
		S_wait_ms($time4FaultManipulation_ms);

		S_teststep_2nd_level( "Read life time counter '$tcpar_lifeTimeCounterLabel'", 'AUTO_NBR' );
		$value_aref = PRD_Read_Memory($tcpar_lifeTimeCounterLabel);
		$type       = 'U8';
		push( @lifeTimeCounter, S_aref2dec( $value_aref, $type ) );
	}
	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory1Bosch' );
	$fltmemBosch1 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory1Primary' );
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Qualify and dequalify failsaft fault '$tcpar_failsafeFault' one more time", 'AUTO_NBR' );

	S_teststep_2nd_level( "Qualify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "qualify" } );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep_2nd_level( "Dequalify failsafe fault '$tcpar_failsafeFault'", 'AUTO_NBR' );
	PRD_Manipulate_Fault_Memory( { 'fault_name' => $tcpar_failsafeFault, 'action' => "dequalify" } );
	S_wait_ms($time4FaultManipulation_ms);

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory2Bosch' );
	$fltmemBosch2 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory2Primary' );
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset(1);

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory3Bosch' );
	$fltmemBosch3 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory3Primary' );
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Erase fault memory", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemory4Bosch' );
	$fltmemBosch4 = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep( "Read primary fault memory", 'AUTO_NBR', 'FaultMemory4Primary' );
	$fltmemPrimary4 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_wait_ms(500);

	S_teststep( "Read life time counter '$tcpar_lifeTimeCounterLabel'", 'AUTO_NBR', 'lifeTimeCounterValue' );
	$value_aref           = PRD_Read_Memory($tcpar_lifeTimeCounterLabel);
	$type                 = 'U8';
	$lifeTimeCounterValue = S_aref2dec( $value_aref, $type );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	for ( $i = 1 ; $i < $tcpar_failsafeLimit ; $i++ ) {
		S_teststep_expected( "Life Time Counter = '$i'", 'lifeTimeCounter' );
		S_teststep_detected( "Life Time Counter = '@lifeTimeCounter[$i-1]'", 'lifeTimeCounter' );
		EVAL_evaluate_value( "Life Time Counter Evaluation", @lifeTimeCounter[ $i - 1 ], '==', $i );
	}
	my $expectedFaults;
	$expectedFaults->{$tcpar_failsafeFault} =
	  { 'DecodedStatus' => { 'TestFailed' => 0 } };

	$fltmemBosch1->evaluate_specific_faults( $expectedFaults, "FaultMemory1Bosch" );
	$fltmemPrimary1->evaluate_specific_faults( $expectedFaults, "FaultMemory1Primary" );

	$fltmemBosch2->evaluate_specific_faults( $expectedFaults, "FaultMemory2Bosch" );
	$fltmemPrimary2->evaluate_specific_faults( $expectedFaults, "FaultMemory2Primary" );

	$expectedFaults->{$tcpar_lifeTimeFault} =
	  { 'DecodedStatus' => { 'TestFailed' => 1 } };
	$fltmemBosch3->evaluate_specific_faults( $expectedFaults, "FaultMemory3Bosch" );
	$fltmemPrimary3->evaluate_specific_faults( $expectedFaults, "FaultMemory3Primary" );

	$fltmemBosch4->evaluate_faults( {}, "FaultMemory4Bosch" );
	$fltmemPrimary4->evaluate_faults( {}, "FaultMemory4Primary" );

	S_teststep_expected( "Life Time Counter = '0'", 'lifeTimeCounterValue' );
	S_teststep_detected( "Life Time Counter = '$lifeTimeCounterValue'", 'lifeTimeCounterValue' );
	EVAL_evaluate_value( "Life Time Counter Evaluation", $lifeTimeCounterValue, '==', 0 );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	PRD_Clear_Fault_Memory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

