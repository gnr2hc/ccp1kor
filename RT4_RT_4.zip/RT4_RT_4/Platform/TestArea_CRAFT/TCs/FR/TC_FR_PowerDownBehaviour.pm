# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_PowerDownBehaviour;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the fault recorder is functioning correct during power down / autarky / reset ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_PowerDownBehaviour 

=head1 PURPOSE

 test that the fault recorder is functioning correct during power down / autarky / reset

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    switch ECU on
    wait for ini end
    create disturbed fault
    create n stored faults
    dequalify 5 stored faults
    switch ECU off for autarky time
    switch ECU on
    read fault recorder
    switch ECU off

    [evaluation]
    check disturbance fault recorder
    check Bosch fault recorder
    check primary fault recorder
    send mail if not

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_FR_PowerDownBehaviour.Test]
    purpose = 'check that the fault information is stored correct during autarky'
    Ubat=12.4
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemDisturbed, $fltmemBosch );
my ( $disturbedFault, $qualifiedFaults_href, $dequalifiedFaults_href );
my ($tcpar_ubat);
my ( $result, $BoschMemorySize, $minAutarkyTime_ms, $repetionTime_ms );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');

	( $result, $BoschMemorySize )   = SYC_FLT_get_BoschMemorySize();
	( $result, $minAutarkyTime_ms ) = SYC_POWERSUPPLY_get_MinAutarkyTime();
	( $result, $repetionTime_ms )   = SYC_SQUIB_get_RepetitionTime();

	$repetionTime_ms =~ s/ms//g;           # remove leading 0x Edit by Lin Ying
	$repetionTime_ms =~ s/^\s+|\s+$//g;    # remove leading 0x Edit by Lin Ying

	if (   $tcpar_ubat eq 'U_BATT_OVERVOLTAGE'
		or $tcpar_ubat eq 'U_BATT_UNDERVOLTAGE' )
	{
		$BoschMemorySize = $BoschMemorySize - 1;
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	my @devices        = LC_Get_names('SQUIBS');
	my $disturbedSquib = shift @devices;
	push( @devices, LC_Get_names('PAS_LINES') );
	push( @devices, LC_Get_names('BELT_LOCKS') );

	S_teststep( 'switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Create different faults', 'AUTO_NBR' );

	S_teststep_2nd_level( 'create one disturbed fault', 'AUTO_NBR' );
	$disturbedFault = 'rb_sqm_SquibResistanceOpen' . $disturbedSquib . '_flt';
	LC_DisconnectLine($disturbedSquib);
	S_wait_ms($repetionTime_ms);
	LC_ConnectLine($disturbedSquib);
	S_wait_ms($repetionTime_ms);
	LC_DisconnectLine($disturbedSquib);
	S_wait_ms($repetionTime_ms);
	LC_ConnectLine($disturbedSquib);
	S_wait_ms($repetionTime_ms);

	S_teststep_2nd_level( 'Read disturbed fault memory', 'AUTO_NBR' );
	$fltmemDisturbed = LIFT_FaultMemory->read_fault_memory('Disturbance');
	S_teststep_2nd_level( 'Evaluate disturbed fault memory after power on', 'AUTO_NBR', 'FLT_disturbed' );

	S_teststep_2nd_level( "create '$BoschMemorySize' stored faults", 'AUTO_NBR' );
	$qualifiedFaults_href = createDefinedNbrOfFaults( $BoschMemorySize, \@devices );

	unless ( ref($qualifiedFaults_href) eq 'HASH' ) {
		S_set_error(" set verdict INCONC because there are not enough faults available\n");
		S_set_verdict(VERDICT_INCONC);
		return 0;

	}

	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( 'de-qualify 5 stored faults', 'AUTO_NBR' );
	$dequalifiedFaults_href = removeQualifiedFaults( \@devices, $qualifiedFaults_href );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms($minAutarkyTime_ms);

	S_teststep( 'Switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read all fault recorder', 'AUTO_NBR' );

	S_teststep_2nd_level( 'Read disturbed fault memory', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Disturbance');
	S_teststep_2nd_level( 'Evaluate disturbed fault memory after power on', 'AUTO_NBR' );

	S_teststep_2nd_level( 'Read Bosch fault memory', 'AUTO_NBR' );
	$fltmemBosch = LIFT_FaultMemory->read_fault_memory('Bosch');
	S_teststep_2nd_level( 'Evaluate Bosch fault memory', 'AUTO_NBR', 'FLT_Bosch' );

	S_teststep( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $expectedFaults_disturbance_afterQuali->{$disturbedFault} =
	  { 'DecodedStatus' => { 'TestDisturbed' => 1 }, };
	$fltmemDisturbed->evaluate_specific_faults( $expectedFaults_disturbance_afterQuali, "FLT_disturbed" );

	my $expectedFaults_bosch_afterQuali;
	foreach my $fault ( values %{$qualifiedFaults_href} ) {
		$expectedFaults_bosch_afterQuali->{$fault} =
		  { 'DecodedStatus' => { 'TestFailed' => 1 }, };
	}

	foreach my $fault ( values %{$dequalifiedFaults_href} ) {
		$expectedFaults_bosch_afterQuali->{$fault} =
		  { 'DecodedStatus' => { 'TestFailed' => 0 } };
	}

	$fltmemBosch->evaluate_specific_faults( $expectedFaults_bosch_afterQuali, "FLT_Bosch" );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	my @deviceList;

	# remove all faults
	if ( defined $qualifiedFaults_href ) {
		@deviceList = keys %{$qualifiedFaults_href};
	}
	else {
		@deviceList = LC_Get_names('SQUIBS');
		push( @deviceList, LC_Get_names('PAS_LINES') );
		push( @deviceList, LC_Get_names('BELT_LOCKS') );
	}

	foreach my $line (@deviceList) {
		LC_ConnectLine($line);
	}

	LC_ECU_On(13.5);
	S_wait_ms(20000);

	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

sub createDefinedNbrOfFaults {
	my $memorySize   = shift;
	my $devices_aref = shift;
	my $qualifiedFlt_href;
	my $fltCounter = 0;

	foreach my $line (@$devices_aref) {
		LC_DisconnectLine($line);
		$fltCounter++;
		$qualifiedFlt_href->{$line} = 'rb_sqm_SquibResistanceOpen' . $line . '_flt'
		  if ( is_squib($line) );
		$qualifiedFlt_href->{$line} = 'rb_psem_OpenLine' . $line . '_flt'
		  if ( is_pas($line) );
		$qualifiedFlt_href->{$line} = 'rb_swm_OpenLine' . $line . '_flt'
		  if ( is_switch($line) );
		last if ( $fltCounter == $memorySize );
	}

	return 0 if ( $fltCounter < $memorySize );
	return $qualifiedFlt_href;
}

sub removeQualifiedFaults {
	my $devices_aref      = shift;
	my $qualifiedFlt_href = shift;
	my $dequalifiedFlt_href;
	my $counter = 0;

	foreach my $line (@$devices_aref) {
		LC_ConnectLine($line);
		$counter++;
		$dequalifiedFlt_href->{$line} = 'rb_sqm_SquibResistanceOpen' . $line . '_flt'
		  if ( is_squib($line) );
		$dequalifiedFlt_href->{$line} = 'rb_psem_OpenLine' . $line . '_flt'
		  if ( is_pas($line) );
		$dequalifiedFlt_href->{$line} = 'rb_swm_OpenLine' . $line . '_flt'
		  if ( is_switch($line) );
		delete $qualifiedFlt_href->{$line};
		last if ( $counter == 5 );
	}

	return $dequalifiedFlt_href;

}

sub is_squib {
	my $device     = shift;
	my @squibNames = LC_Get_names('SQUIBS');
	my $squibs_href;

	@$squibs_href{@squibNames} = undef;

	return 1 if exists $squibs_href->{$device};

	return 0;
}

sub is_pas {
	my $device   = shift;
	my @pasNames = LC_Get_names('PAS_LINES');
	my $pases_href;

	@$pases_href{@pasNames} = undef;

	return 1 if exists $pases_href->{$device};

	return 0;
}

sub is_switch {
	my $device      = shift;
	my @switchNames = LC_Get_names('BELT_LOCKS');
	my $switches_href;

	@$switches_href{@switchNames} = undef;

	return 1 if exists $switches_href->{$device};

	return 0;
}

1;

__END__
