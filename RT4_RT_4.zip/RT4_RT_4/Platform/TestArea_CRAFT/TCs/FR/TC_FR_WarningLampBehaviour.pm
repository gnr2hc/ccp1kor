# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_WarningLampBehaviour;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that the warning indicator has the correct behaviour for different conditions ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_WarningLampBehaviour 

=head1 PURPOSE

 check that the warning indicator has the correct behaviour for different conditions

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Condition
    Behaviour

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    apply condition
    set Ubat
    wait for end of initialization
    read warning lamp status
    remove fault

    [evaluation]
    check if warning lamp status is correct
    send mail if not

    [finalisation]
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'Condition'   --> applied fault condition
    SCALAR 'Behaviour'   --> warning lamp behaviour
    
=head2 PARAMETER EXAMPLES

    [TC_FLT_Active.BLFD_Gnd]
    purpose = 'check that the warning lamp behaviour is correct for WLonStoredFault' 
	Ubat=13.2
	Condition='AB1FD'
	Behaviour='WLonStoredFault'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $lampMode, $lampStatus );

my ( $tcpar_ubat, $tcpar_condition, $tcpar_behaviour );
my ( $result, $lowVoltageDetectionLimit_V );
my @temperatures = ();

my ( $mapping_lampMode, $mapping_lampStatus );

# Indicator is on according to DEM indicator status (=7), Indicator is off (=8), Indicator is on during initialization phase (=2)
# values taken from CNS file
my $lampMode_DEM;

# Indicator is on (=1), Indicator is off (=0)
# values taken from CNS file
my $lampStatus_on;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat      = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_condition = GEN_Read_mandatory_testcase_parameter('Condition');
	$tcpar_behaviour = GEN_Read_mandatory_testcase_parameter('Behaviour');

	if ( $tcpar_condition eq 'VbatLow' ) {
		( $result, $lowVoltageDetectionLimit_V ) = SYC_POWERSUPPLY_get_LowVoltageDetectionLimit();
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;

}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	$mapping_lampMode   = PRD_Get_Symbol_Mapping( { 'enum_type' => 'rb_wimi_SysWIInidcatorMode_ten' } );
	$mapping_lampStatus = PRD_Get_Symbol_Mapping( { 'enum_type' => 'rb_wimi_SysWIStatus_ten' } );

	S_teststep( "Apply condition for behaviour '$tcpar_behaviour'.", 'AUTO_NBR' );
	if ( $tcpar_behaviour eq 'WLonStoredFault' ) {
		S_teststep_2nd_level( "Apply open to $tcpar_condition.", 'AUTO_NBR' );
		LC_DisconnectLine($tcpar_condition);

		# rb_wimi_SysWIOnDem_e + rb_wimi_SysWIStatusOn_e
		$lampMode_DEM  = $mapping_lampMode->{'rb_wimi_SysWIOnDem_e'}->{'value'};
		$lampStatus_on = $mapping_lampStatus->{'rb_wimi_SysWIStatusOn_e'}->{'value'};
		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);

		S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_READY');
	}
	elsif ( $tcpar_behaviour eq 'WLonLatchedFault' ) {
		S_teststep_2nd_level( "Remove monitoring for $tcpar_condition.", 'AUTO_NBR' );
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		PRD_Set_Device_Configuration( { $tcpar_condition => ['clear_Monitor'] }, { 'resetType' => 'HARD' } );

		#LC_ECU_Off();

		# rb_wimi_SysWIOnInitPhase_e + rb_wimi_SysWIStatusOn_e
		$lampMode_DEM  = $mapping_lampMode->{'rb_wimi_SysWIOnInitPhase_e'}->{'value'};
		$lampStatus_on = $mapping_lampStatus->{'rb_wimi_SysWIStatusOn_e'}->{'value'};
		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);

		S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_READY');
	}
	elsif ( $tcpar_behaviour eq 'WLonFilteredFault' ) {
		my $ubatlow_V;

		# adapt applied low battery voltage because of threshold
		$ubatlow_V = $lowVoltageDetectionLimit_V - 0.4;
		S_teststep_2nd_level( "Apply $tcpar_condition.", 'AUTO_NBR' );
		LC_ECU_On($ubatlow_V);
		S_wait_ms(15000);
		LC_ECU_Off();
		S_wait_ms(2000);

		# rb_wimi_SysWIOff_e + rb_wimi_SysWIStatusOff_e
		$lampMode_DEM  = $mapping_lampMode->{'rb_wimi_SysWIOff_e'}->{'value'};
		$lampStatus_on = $mapping_lampStatus->{'rb_wimi_SysWIStatusOff_e'}->{'value'};
		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);

		S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_READY');
	}
	else {
		S_teststep("Given lamp behaviour ($tcpar_behaviour) is not valid");
		S_set_verdict('VERDICT_INCONC');
		return 1;
	}

	S_teststep( 'Read warning lamp mode and status', 'AUTO_NBR' );

	$lampMode = PRD_Read_Memory( 'rb_wimi_SysWIHighestMode_en', { memoryContentsAsInteger => 1 } );
	S_teststep( 'Evaluate lamp mode', 'AUTO_NBR', 'LampMode' );

	$lampStatus = PRD_Read_Memory( 'rb_wimi_SysWIStatus_aen(0)', { memoryContentsAsInteger => 1 } );
	S_teststep( 'Evaluate lamp status', 'AUTO_NBR', 'LampStatus' );

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	# S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( "Expected lamp mode == $lampMode_DEM", 'LampMode' );
	S_teststep_detected( "Detected lamp mode == $lampMode", 'LampMode' );
	EVAL_evaluate_value( "lamp mode ", $lampMode, '==', $lampMode_DEM );

	S_teststep_expected( "Expected lamp status == $lampStatus_on", 'LampStatus' );
	S_teststep_detected( "Detected lamp status == $lampStatus", 'LampStatus' );
	EVAL_evaluate_value( "lamp status ", $lampStatus, '==', $lampStatus_on );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# remove condition
	S_teststep( "Remove condition for behaviour '$tcpar_behaviour'.", 'AUTO_NBR' );
	if ( $tcpar_behaviour eq 'WLonStoredFault' ) {
		LC_ConnectLine($tcpar_condition);
	}
	elsif ( $tcpar_behaviour eq 'WLonLatchedFault' ) {
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		PRD_Set_Device_Configuration( { $tcpar_condition => ['set_Monitor'] } );
		LC_ECU_Off();
	}
	elsif ( $tcpar_behaviour eq 'WLonFilteredFault' ) {
		## no action required
	}

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
