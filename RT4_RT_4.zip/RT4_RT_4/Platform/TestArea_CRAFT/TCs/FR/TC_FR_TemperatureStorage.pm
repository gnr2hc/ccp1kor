# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FR_TemperatureStorage;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Fault_Recording
#TS version in DOORS: 1.2
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_functional_layer;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the stored temperature in fault recorder is not changed when fault is qualified more then once ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FR_TemperatureStorage 

=head1 PURPOSE

 test that the stored temperature in fault recorder is not changed when fault is qualified more then once

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand
    Temperature

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
	1) set temperature
	2) switch ECU on
	3) qualify fault for given pin
	4) check fault recorder
	5) dequalify fault
	6) set next temperature
	7) qualify fault for given pin
	8) check fault recorder
	9) dequalify fault
	10) erase fault recorder
	11) qualify fault for given pin
	12) check fault recorder

    [evaluation]
	1) set temperature is reached
	2) -
	3) -
	4) expected fault and temperature are stored
	5) -
	6) set temperature is reached
	7) -
	8) expected fault and "old" temperature are stored
	9) -
	10) -
	11) -
	12) expected fault and "new" temperature is stored

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'Pin'		 --> pin name for open line fault
    LIST   'FLTmand'     --> list of mandatory faults (logical names)
    LIST   'Temperature' --> list of temperatures
    
    
=head2 PARAMETER EXAMPLES

    [TC_FR_TemperatureStorage.BT1FD]
	purpose = 'check that the temperature stored for a qualified fautlt is not changed when fault is qualified for a second time'
	Ubat=13.3
	Pin = 'BT1FD
	FLTmand = @('rb_sqm_SquibResistanceOpenBT1FD_flt')
	Temperature = @(25, 45)
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat,    $tcpar_pin );
my ( @tcpar_FLTmand, @tcpar_temperature );
my ( $faultMemTemp1, $faultMemTemp2, $faultMemTemp3 );
my ( $AsicTemp1,     $AsicTemp2, $AsicTemp3 );
my ( $fltmem1,       $fltmem2, $fltmem3 );
my @temperatures = ();
my ( $valid_flag, $return_value, $temp_set );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat        = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin         = GEN_Read_mandatory_testcase_parameter('Pin');
	@tcpar_FLTmand     = GEN_Read_mandatory_testcase_parameter('FLTmand');
	@tcpar_temperature = GEN_Read_mandatory_testcase_parameter('Temperature');

	( $valid_flag, $return_value ) = S_read_public_variable("TEMPcontrolled");
	$temp_set = FL_GetConfiguredDevice( 'Temperature', 'set' );

	if ( $valid_flag == 1 and $return_value == 1 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("Test is trying to set temperature, but temperature is controlled by IC!");
		S_teststep_detected("Rerun of TC with an IC without temp necessary!");
	}
	elsif ( $valid_flag == 0 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("State of temperature is not known!");
		S_teststep_detected("IC with public variable 'TEMPcontrolled' to be used!");
	}

	#	elsif ( $temp_set == undef ) {
	#		S_set_verdict("VERDICT_NONE");
	#		S_teststep_detected("No device for set temperature defined for this test bench!");
	#		S_teststep_detected("Rerun of TC with a test bench which can set temperature!");
	#		$valid_flag = 0;
	#	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	if ( $valid_flag == 1 and $return_value == 0 ) {

		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');

		PRD_Clear_Fault_Memory();
		S_wait_ms('TIMER_ECU_READY');
		LIFT_FaultMemory->read_fault_memory('Bosch');
		LIFT_FaultMemory->read_fault_memory('Primary');

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

	}

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	if ( $valid_flag == 1 and $return_value == 0 ) {

		#	1) set temperature
		S_teststep( "set temperature '$tcpar_temperature[0] �C' and wait till temperature is reached", 'AUTO_NBR' );
		TEMP_setTargetTemperature( $tcpar_temperature[0] );
		TEMP_waitForTemperature( 120, 2 );

		#	2) switch ECU on
		S_teststep( "switch ECU on", 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);
		S_wait_ms('TIMER_ECU_READY');

		#	3) qualify fault for given pin
		S_teststep( "qualify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_DisconnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		#	4) check fault recorder
		S_teststep( "check fault recorder", 'AUTO_NBR', 'fltmem1' );
		S_teststep_2nd_level( "read ASIC temperature", 'AUTO_NBR' );
		$AsicTemp1 = PRD_Read_Memory( 'rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32', { memoryContentsAsInteger => 1 } );
		$AsicTemp1 = $AsicTemp1 / 10;
		S_teststep_2nd_level( "read fault recorder", 'AUTO_NBR' );
		$fltmem1       = LIFT_FaultMemory->read_fault_memory('Bosch');
		$faultMemTemp1 = $fltmem1->get_fault_attribute(
			{
				'FaultName' => $tcpar_FLTmand[0],
				'Attribute' => 'ASIC_Temperature'
			}
		);

		#	5) dequalify fault
		S_teststep( "dequalify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		#	6) set next temperature
		S_teststep( "set temperature '$tcpar_temperature[1] �C' and wait till temperature is reached", 'AUTO_NBR' );

		TEMP_setTargetTemperature( $tcpar_temperature[1] );
		TEMP_waitForTemperature( 120, 2 );

		#	7) qualify fault for given pin
		S_teststep( "qualify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_DisconnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		#	8) check fault recorder
		S_teststep( "check fault recorder", 'AUTO_NBR', 'fltmem2' );
		S_teststep_2nd_level( "read ASIC temperature", 'AUTO_NBR' );
		$AsicTemp2 = PRD_Read_Memory( 'rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32', { memoryContentsAsInteger => 1 } );
		$AsicTemp2 = $AsicTemp2 / 10;
		S_teststep_2nd_level( "read fault recorder", 'AUTO_NBR' );
		$fltmem2       = LIFT_FaultMemory->read_fault_memory('Bosch');
		$faultMemTemp2 = $fltmem2->get_fault_attribute(
			{
				'FaultName' => $tcpar_FLTmand[0],
				'Attribute' => 'ASIC_Temperature'
			}
		);

		#	9) dequalify fault
		S_teststep( "dequalify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		#	10) erase fault recorder
		S_teststep( "erase fault recorder", 'AUTO_NBR' );
		PRD_Clear_Fault_Memory();
		S_wait_ms('TIMER_ECU_READY');

		#	11) qualify fault for given pin
		S_teststep( "qualify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_DisconnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		#	12) check fault recorder
		S_teststep( "check fault recorder", 'AUTO_NBR', 'fltmem3' );
		S_teststep_2nd_level( "read ASIC temperature", 'AUTO_NBR' );
		$AsicTemp3 = PRD_Read_Memory( 'rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32', { memoryContentsAsInteger => 1 } );
		$AsicTemp3 = $AsicTemp3 / 10;
		S_teststep_2nd_level( "read fault recorder", 'AUTO_NBR' );
		$fltmem3       = LIFT_FaultMemory->read_fault_memory('Bosch');
		$faultMemTemp3 = $fltmem3->get_fault_attribute(
			{
				'FaultName' => $tcpar_FLTmand[0],
				'Attribute' => 'ASIC_Temperature'
			}
		);

	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $expectedFaults;

	if ( $valid_flag == 1 and $return_value == 0 ) {

		#	4) expected fault and temperature are stored
		$expectedFaults->{ $tcpar_FLTmand[0] } =
		  { 'DecodedStatus' => { 'TestFailed' => 1 } };

		$fltmem1->evaluate_specific_faults( $expectedFaults, "fltmem1" );

		S_teststep_expected( "Temperature from ASIC = $AsicTemp1 �C", 'fltmem1' );
		S_teststep_detected( "Temperature stored in fault recorder = $faultMemTemp1 �C", 'fltmem1' );
		EVAL_evaluate_value( "fltmen1", $faultMemTemp1, '==', $AsicTemp1, 5, 'absolute' );

		#	8) expected fault and "old" temperature are stored
		$expectedFaults->{ $tcpar_FLTmand[0] } =
		  { 'DecodedStatus' => { 'TestFailed' => 1 } };

		$fltmem1->evaluate_specific_faults( $expectedFaults, "fltmem2" );

		S_teststep_expected( "Temperature from first fault recorder = $faultMemTemp1 �C", 'fltmem2' );
		S_teststep_detected( "Temperature from ASIC = $AsicTemp2 �C",                    'fltmem2' );
		S_teststep_detected( "Temperature stored in fault recorder = $faultMemTemp2 �C", 'fltmem2' );
		EVAL_evaluate_value( "fltmen2", $faultMemTemp1, '==', $faultMemTemp1, 2, 'absolute' );

		#	12) expected fault and "new" temperature is stored
		$expectedFaults->{ $tcpar_FLTmand[0] } =
		  { 'DecodedStatus' => { 'TestFailed' => 1 } };

		$fltmem3->evaluate_specific_faults( $expectedFaults, "fltmem3" );

		S_teststep_expected( "Temperature from ASIC = $AsicTemp3 �C", 'fltmem3' );
		S_teststep_detected( "Temperature stored in fault recorder = $faultMemTemp3 �C", 'fltmem3' );
		EVAL_evaluate_value( "fltmen3", $faultMemTemp3, '==', $AsicTemp3, 5, 'absolute' );

	}

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	if ( $valid_flag == 1 and $return_value == 0 ) {

		S_teststep( "set room temperature", 'AUTO_NBR' );
		TEMP_setTargetTemperature(25);

		S_teststep( "dequalify open line fault for pin '$tcpar_pin' ", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

		S_teststep( "erase fault recorder", 'AUTO_NBR' );
		PRD_Clear_Fault_Memory();
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( "switch ECU off", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}

	return 1;
}

1;
