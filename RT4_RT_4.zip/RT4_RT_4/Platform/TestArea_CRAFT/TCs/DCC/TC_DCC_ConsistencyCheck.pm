# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_DCC_ConsistencyCheck;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Data_Configuration_Concept
#TS version in DOORS: 2.6
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "verify that consistency check for the different data/parameter is working and stores a fault if any inconsistancy is recognised";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DCC_ConsistencyCheck

=head1 PURPOSE

verify that consistency check for the different data/parameter is working and stores a fault if any inconsistancy is recognised

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on
2. program SW or DataFlash
3. switch ECU off
4. switch ECU on
5. read fault recorder
6. switch ECU off

I<B<Evaluation>>

1. -
2. - 
3. -
4. -
5. check fault recorder for FLTmand
6. -

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose'		=> short description of test case 
	SCALAR 'FLTmand'		=> expected fault
	SCALAR 'FLTopt'			=> optional fault
	SCALAR 'ProgrammedFile'	=> file which is programmed
	SCALAR 'Type'			=> SW or Data Flash update 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose= 'check fault qualification for SWUpdate_incompatible'

	# input parameter (used for stimulation and measurement)
	ProgrammedFile = 'AB1200_B4_0043_BB000000_Cat2.hex'
	Type = 'SWUpdate'

	# output parameter (used for evaluation)
	FLTmand = @('rb_utsv_SwVersionWrong_flt')
	FLTopt  = @('rb_edr_DataAreaNotInitialized_flt')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_type;
my $tcpar_programmedFile;
my $tcpar_FLTmand;
my $tpcar_FLTopt;
################ global parameter declaration ###################
#add any global variables here
my $action;
my $fltmem1;
my @temperatures;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose        = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_type           = S_read_mandatory_testcase_parameter('Type');
	$tcpar_programmedFile = S_read_mandatory_testcase_parameter('ProgrammedFile');
	$tcpar_FLTmand        = S_read_mandatory_testcase_parameter('FLTmand');
	$tpcar_FLTopt         = S_read_mandatory_testcase_parameter('FLTopt');

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory_NOERROR();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();

	S_teststep( "Wait for ini end", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	#   test for SW update
	if ( $tcpar_type eq 'SWUpdate' ) {
		S_teststep( "Program other SW and data block", 'AUTO_NBR' );
		$action = S_user_action( "Necessary action" . "\nConnect programming device to ECU.\n" . "Program other SW and data block then required ('$tcpar_programmedFile').\n\n" . "Confirm with yes if programming is finished.\n" . "Confirm with no if you want to cancel this test.", 'YesNo' );

		if ( $action eq 'no' ) {
			S_set_verdict("VERDICT_NONE");
			S_teststep_detected("Test is canceled by user input");
		}
		elsif ( $action eq 'yes' ) {
			S_teststep( "Reset ECU", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep( "Program SW", 'AUTO_NBR' );
			S_user_action( "Necessary action" . "\nConnect programming device to ECU.\n" . "Program required SW '$tcpar_programmedFile'.\n\n" . "Confirm programming is finished.\n", 'Ok' );

			S_teststep( "Reset ECU", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep( "Read and evaluate fault recorder.", 'AUTO_NBR', 'read_fault_recorder' );
			$fltmem1 = LIFT_FaultMemory->read_fault_memory('Primary');
		}
	}

	#   test for Data Block update
	elsif ( $tcpar_type eq 'DataBlock' ) {
		S_teststep( "Program data block", 'AUTO_NBR' );
		$action = S_user_action( "Necessary action" . "\nConnect programming device to ECU.\n" . "Program required data block '$tcpar_programmedFile'.\n\n" . "Confirm with yes if programming is finished.\n" . "Confirm with no if you want to cancel this test.", 'YesNo' );

		if ( $action eq 'no' ) {
			S_set_verdict("VERDICT_NONE");
			S_teststep_detected("Test is canceled by user input");
		}
		elsif ( $action eq 'yes' ) {
			S_teststep( "Erase fault recorder", 'AUTO_NBR' );
			PRD_Clear_Fault_Memory_NOERROR();

			S_teststep( "Reset ECU", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep( "Read and evaluate fault recorder.", 'AUTO_NBR', 'read_fault_recorder' );
			$fltmem1 = LIFT_FaultMemory->read_fault_memory('Primary');

		}
	}

	#   choosen function is not supported
	else {
		S_teststep( "The test of this type '$tcpar_type' is not supported from the test case.", 'AUTO_NBR', 'wrongFunction' );
		S_set_verdict("VERDICT_INCONC");
	}

	return 1;
}

sub TC_evaluation {

	if ( $action eq 'yes' ) {
		S_teststep_expected( 'Expected faults:', 'read_fault_recorder' );
		foreach my $fault (@$tcpar_FLTmand) {
			S_teststep_expected($fault);
		}
		my $expected_faults_href1 = { 'mandatory' => $tcpar_FLTmand, 'optional' => $tpcar_FLTopt, };
		$fltmem1->evaluate_faults( $expected_faults_href1, 'read_fault_recorder' );
	}

	return 1;
}

sub TC_finalization {

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	return 1;
}

1;
