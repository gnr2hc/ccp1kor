# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FLT_FaultWithShunt;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the ECU stores a fault if the specified shunt in short2gnd/short2bat is used and that the ECU stores no fault if the shunt is higher than specified";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 test that a fault is detected in cyclical mode and stored in fault memory

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	shunt
	Ubat
	FLTmandGnd
	FLTmandBat
	FLTmand (opt)
	FLTopt (opt)

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
	1. switch ECU on
	2. apply short2gnd with specified shunt
	3. wait for fault qualification time
	4. read fault recorder
	5. evaluate fault recorder
	6. remove fault
	7. erase fault recorder
	8. switch ECU off
	
	9. switch ECU on
	10. apply short2gnd with shunt higher than specified
	11. wait for fault qualification time
	12. read fault recorder
	13. evaluate fault recorder
	14. remove fault
	15. erase fault recorder
	16. switch ECU off
	
	17. switch ECU on
	18. apply short2bat with specified shunt
	19. wait for fault qualification time
	20. read fault recorder
	21. evaluate fault recorder
	22. remove fault
	23. erase fault recorder
	24. switch ECU off
	
	25. switch ECU on
	26. apply short2bat with shunt higher than specified
	27. wait for fault qualification time
	28. read fault recorder
	29. evaluate fault recorder
	30. remove fault
	31. erase fault recorder
	32. switch ECU off

    [evaluation]
	5. check that expected fault is stored

	13. check that no fault is present

	21. check that expected fault is stored

	29. check that no fault is present

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

	SCALAR 'pin'		 --> ECU pin
	SCALAR 'shunt'		 --> used shunt in kOhm 
	SCALAR 'Ubat'        --> battery voltage value
	LIST FLTmandGnd		 --> list of mandatory faults for short to Gnd (logical names)
	LIST FLTmandBat		 --> list of mandatory faults for short to Bat (logical names)
(	
	LIST FLTmand (opt)	 --> list of mandatory faults for short to Gnd (logical names)
	LIST FLTopt (opt)	 --> list of optional faults for short to Gnd (logical names)
)
    
=head2 PARAMETER EXAMPLES

[TC_FLT_FaultWithShunt.BT1FD]
purpose='$check test pulses for BT1FD'
shunt=5 #kOhm 
Ubat=9.9
FLTmandGnd=@('rb_sqm_TerminalShort2GndBT1FD_flt')
FLTmandBat=@('rb_sqm_TerminalShort2BatBT1FD_flt')
FLTmand = @()
FLTopt = @()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $result, $tcpar_ubat, $tcpar_pin, $tcpar_shunt_short2bat, $tcpar_shunt_short2gnd, $tcpar_FLTmandGnd, $tcpar_FLToptGnd, $tcpar_FLTmandBat, $tcpar_FLToptBat );
my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $fltmemBosch3, $fltmemPrimary3, $fltmemBosch4, $fltmemPrimary4, $fltmemBosch5, $fltmemPrimary5, $fltmemBosch6, $fltmemPrimary6, $fltmemBosch7, $fltmemPrimary7, $fltmemBosch8, $fltmemPrimary8, $expectedFaults_href );
my ( $shunt_below_short2gnd, $shunt_above_short2gnd, $shunt_below_short2bat, $shunt_above_short2bat, $shunt );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_pin = S_read_mandatory_testcase_parameter('Pin');

	$tcpar_FLTmandGnd = S_read_mandatory_testcase_parameter( 'FLTmandGnd', 'byref' );
	$tcpar_FLToptGnd = S_read_optional_testcase_parameter( 'FLToptGnd', 'byref' );
	$tcpar_FLTmandBat = S_read_mandatory_testcase_parameter( 'FLTmandBat', 'byref' );
	$tcpar_FLToptBat = S_read_optional_testcase_parameter( 'FLToptBat', 'byref' );

	$tcpar_shunt_short2gnd = 5;       # value in kOhm
	$shunt_below_short2gnd = 3000;    # value in  Ohm
	$shunt_above_short2gnd = 7000;    # value in  Ohm

	( $result, $tcpar_shunt_short2bat ) = SYC_SQUIB_get_ResistanceShort2Bat();
	return 0 unless $result;
	if ( $tcpar_shunt_short2bat == 5 ) {
		$shunt_below_short2bat = 3000;    # value in Ohm
		$shunt_above_short2bat = 7000;    # value in Ohm
		$tcpar_ubat            = 12;
	}
	elsif ( $tcpar_shunt_short2bat == 20 ) {
		$shunt_below_short2bat = 12000;    # value in Ohm
		$shunt_above_short2bat = 25000;    # value in Ohm
		$tcpar_ubat            = 14;
	}
	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

###############################################################################
	S_teststep( "Short '$tcpar_pin-' to GND with shunt less then specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_below_short2gnd );
	S_teststep_2nd_level( "Short '$tcpar_pin-' to GND with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "-", 'B-' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd-' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short '$tcpar_pin-' to GND with shunt higher then specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_above_short2gnd );
	S_teststep_2nd_level( "Short '$tcpar_pin-' to GND with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "-", 'B-' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd-_noFault' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short '$tcpar_pin-' to BAT with shunt less then specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_below_short2bat );
	S_teststep_2nd_level( "Short '$tcpar_pin-' to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "-", 'B+' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch3   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat-' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short '$tcpar_pin-' to BAT with shunt higher than specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_above_short2bat );
	S_teststep_2nd_level( "Short '$tcpar_pin-' to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "-", 'B+' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch4   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary4 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat-_noFault' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short $tcpar_pin+ to GND with shunt less than specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_below_short2gnd );
	S_teststep_2nd_level( "Short $tcpar_pin+ to GND with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "+", 'B-' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch5   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary5 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd+' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short $tcpar_pin+ to GND with shunt higher than specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_above_short2gnd );
	S_teststep_2nd_level( "Short $tcpar_pin+ to GND with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "+", 'B-' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch6   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary6 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd+_noFault' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short $tcpar_pin+ to BAT with shunt less than specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_below_short2bat );
	S_teststep_2nd_level( "Short $tcpar_pin+ to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "+", 'B+' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch7   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary7 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat+' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

###############################################################################
	S_teststep( "Short $tcpar_pin+ to BAT with shunt higher than specified shunt", 'AUTO_NBR' );
	S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	$shunt = sprintf( "%05d", $shunt_above_short2bat );
	S_teststep_2nd_level( "Short $tcpar_pin+ to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin . "+", 'B+' ], $shunt );

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmemBosch8   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary8 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat+_noFault' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Clear_Fault_Memory();

	S_teststep_2nd_level( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandGnd-)', 'FLTmandGnd-' );
	foreach my $fault (@$tcpar_FLTmandGnd) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmandGnd,
		'disjunction' => [],
		'optional'    => $tcpar_FLToptGnd,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'FLTmandGnd-' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'FLTmandGnd-' );

###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandGnd-_noFault)', 'FLTmandGnd-_noFault' );
	S_teststep_expected('NoFault');
	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => [],
	};
	$fltmemBosch2->evaluate_faults( $expectedFaults_href, 'FLTmandGnd-_noFault' );
	$fltmemPrimary2->evaluate_faults( $expectedFaults_href, 'FLTmandGnd-_noFault' );

###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandBat-)', 'FLTmandBat-' );
	foreach my $fault (@$tcpar_FLTmandBat) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmandBat,
		'disjunction' => [],
		'optional'    => $tcpar_FLToptBat,
	};
	$fltmemBosch3->evaluate_faults( $expectedFaults_href, 'FLTmandBat-' );
	$fltmemPrimary3->evaluate_faults( $expectedFaults_href, 'FLTmandBat-' );

###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandBat-_noFault)', 'FLTmandBat-_noFault' );
	S_teststep_expected('NoFault');
	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => [],
	};
	$fltmemBosch4->evaluate_faults( $expectedFaults_href, 'FLTmandBat-_noFault' );
	$fltmemPrimary4->evaluate_faults( $expectedFaults_href, 'FLTmandBat-_noFault' );

###############################################################################
	S_teststep_expected( 'Expected faults(FLTmandGnd+):', 'FLTmandGnd+' );
	foreach my $fault (@$tcpar_FLTmandGnd) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmandGnd,
		'disjunction' => [],
		'optional'    => $tcpar_FLToptGnd,
	};
	$fltmemBosch5->evaluate_faults( $expectedFaults_href, 'FLTmandGnd+' );
	$fltmemPrimary5->evaluate_faults( $expectedFaults_href, 'FLTmandGnd+' );

###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandGnd+_noFault)', 'FLTmandGnd+_noFault' );
	S_teststep_expected('NoFault');
	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => [],
	};
	$fltmemBosch6->evaluate_faults( $expectedFaults_href, 'FLTmandGnd+_noFault' );
	$fltmemPrimary6->evaluate_faults( $expectedFaults_href, 'FLTmandGnd+_noFault' );

###############################################################################
	S_teststep_expected( 'Expected faults(FLTmandBat+):', 'FLTmandBat+' );
	foreach my $fault (@$tcpar_FLTmandBat) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmandBat,
		'disjunction' => [],
		'optional'    => $tcpar_FLToptBat,
	};
	$fltmemBosch7->evaluate_faults( $expectedFaults_href, 'FLTmandBat+' );
	$fltmemPrimary7->evaluate_faults( $expectedFaults_href, 'FLTmandBat+' );

###############################################################################
	S_teststep_expected( 'Expected faults: (FLTmandBat+_noFault)', 'FLTmandBat+_noFault' );
	S_teststep_expected('NoFault');
	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => [],
	};
	$fltmemBosch8->evaluate_faults( $expectedFaults_href, 'FLTmandBat+_noFault' );
	$fltmemPrimary8->evaluate_faults( $expectedFaults_href, 'FLTmandBat+_noFault' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
