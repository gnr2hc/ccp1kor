# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_WI_HWLamp_FaultHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Warning_Indicators
#TS version in DOORS: 5.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

#use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " the ECU detects faults at optical / acoustical indicator pin depending on the used HW driver and the state of the optical / acoustical indicator ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_WI_HWLamp_FaultHandling 

=head1 PURPOSE

 the ECU detects faults at optical / acoustical indicator pin depending on the used HW driver and the state of the optical / acoustical indicator

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin1
    Pin2
    Condition
    FLTmand
    FLTopt

    [initialisation]
    get temperature
    
    [stimulation & measurement]
    switch ECU on
    wait for ini end
    apply fault <pin2> to <pin1>
    wait until fault is qualified
    read and evaluate RB fault recorder
    undo applied fault
    switch ECU off
    wait for ECU off
    switch ECU on
    wait for ini end
    clear RB fault recorder
    switch ECU off
    wait for ECU off
    switch ECU on
    wait for ini end
    read and evaluate RB fault recorder
    
    [evaluation]
    evaluate first read of RB fault recorder
    evaluate second read of RB fault recorder

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin1'          		 --> ECU pin
    SCALAR 'pin2'                --> applied fault
    SCALAR 'condition'           --> warning indicator condition (on / off)
    LIST   'FLTmand'             --> mandatory faults
    LIST   'FLTopt'              --> optional faults
    
=head2 PARAMETER EXAMPLES

    [TC_WI_HWLamp_FaultHandling.AWL]
    purpose='Checking_FaultHandling_WalaOn' 
    Ubat=15.3
	Pin1='AWL'
	Pin2='short2gnd'
	Condition='WalaOff'
	FLTmand=@('rb_aod_AOutSysWarningIndicatorShort2Gnd_flt')
	FLTopt=@()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_Ubat, $tcpar_Pin2, $tcpar_Pin1, $tcpar_Condition, $tcpar_FLTmand, $tcpar_FLTopt );
my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $expectedFaults_href );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat      = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Pin1      = S_read_mandatory_testcase_parameter('Pin1');
	$tcpar_Pin2      = S_read_mandatory_testcase_parameter('Pin2');
	$tcpar_Condition = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_FLTmand   = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt    = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# set battery voltage
	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	if ( $tcpar_Condition eq "WalaOn" ) {
		S_teststep( "Disconnect AB1FD line. ", 'AUTO_NBR' );
		LC_DisconnectLine('AB1FD');

		S_teststep( 'Wait until fault is detected.', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	}

	if ( $tcpar_Pin2 eq "short2ubat" ) {
		S_teststep( "Short '$tcpar_Pin1 +' line to UBat.", 'AUTO_NBR' );
		LC_ShortLines( [ $tcpar_Pin1 . '+', 'B+' ] );
	}
	elsif ( $tcpar_Pin2 eq "short2gnd" ) {
		S_teststep( "Short '$tcpar_Pin1 +' line to GND.", 'AUTO_NBR' );
		LC_ShortLines( [ $tcpar_Pin1 . '+', 'B-' ] );
	}
	elsif ( $tcpar_Pin2 eq "open" ) {
		S_teststep( "Disconnect '$tcpar_Pin1' line.", 'AUTO_NBR' );
		LC_DisconnectLine($tcpar_Pin1);
	}
	else {
		# nothing to do...
	}
	S_teststep( "Wait until fault is qualified.", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep( "Read and eval RB fault memory.", 'AUTO_NBR', "fault_1" );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');

	if ( $tcpar_Condition eq "WalaOn" ) {
		S_teststep( "Connect AB1FD line.", 'AUTO_NBR' );
		LC_ConnectLine('AB1FD');
	}
	if ( $tcpar_Pin2 eq "short2ubat" ) {
		S_teststep( "Undo short line to UBat.", 'AUTO_NBR' );
		LC_UndoShortLines();
	}
	elsif ( $tcpar_Pin2 eq "short2gnd" ) {
		S_teststep( "Undo short line to GND.", 'AUTO_NBR' );
		LC_UndoShortLines();
	}
	elsif ( $tcpar_Pin2 eq "open" ) {
		S_teststep( "Connect '$tcpar_Pin1' line.", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_Pin1);
	}
	else {
		# nothing to do...
	}

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( 'Wait until ECU is off.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Clear RB fault memory.', 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();

	S_teststep( 'Wait until ECU is ready.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( 'Wait until ECU is off.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read and eval RB fault memory.", 'AUTO_NBR', "fault_2" );
	$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	# read fault memory and compare against mandatory and optional faults
	S_teststep_expected( 'Expected faults:', 'fault_1' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'fault_1' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'fault_1' );

	# read fault memory and compare against mandatory and optional faults
	S_teststep_expected( 'Expected faults:', 'fault_2' );

	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => [],
	};

	$fltmemBosch2->evaluate_faults( $expectedFaults_href, 'fault_2' );
	$fltmemPrimary2->evaluate_faults( $expectedFaults_href, 'fault_2' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# switch ECU off
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;

__END__
