# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_WI_FieldBusMessage_PowerOn;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Warning_Indicators (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 5.11 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use LIFT_NET_access;

##################################

our $PURPOSE = "Check that the warning indicator message is correct and that the warning indicator message shows the correct state after initialization";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_WI_FieldBusMessage_PowerOn

=head1 PURPOSE

<Check that the warning indicator message is correct and that the warning indicator message shows the correct state after initialization>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Apply test case state

2. Set bus simulation for recording 

3. Switch ECU on

4. Wait for IniEnd

5. Read fault recorder

6. Check warning indicator message

7. Switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. -

4. -

5. fault according fault state 

6. warning indicator message is like specified 

7. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Ubat' => 
	SCALAR 'Pin' => 
	SCALAR 'Condition' => 
	SCALAR 'InitialOnTime_s' => 
	SCALAR 'OffAfterInit_s' => 
	LIST 'FLTmand' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='Check CANWL (field bus message) signal during power on with <Test Heading Tail>' 
	
	# input parameter (used for stimulation and measurement)
	Ubat=<Random 9 to 16 step 0.1>
	Pin='CANWL'
	Condition='WalaOff'
	InitialOnTime_s = 5 #sec
	OffAfterInit_s = 0 #sec
	Can_signal='AB_VB_deaktiviert'
	
	# output parameter (used for evaluation)
	FLTmand=@()
	Expected_value_on_CAN=0

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat;
my $tcpar_Condition;
my $tcpar_can_signal;
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my $tcpar_ExpectedValue_on_CAN;

################ global parameter declaration ###################
#add any global variables here
my @temperatures = ();
my ($detectedValue_on_CAN);
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );
###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat                 = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Condition            = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_FLTmand              = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt               = S_read_optional_testcase_parameter( 'FLTopt', 'byref' );
	$tcpar_can_signal           = S_read_mandatory_testcase_parameter('Can_Signal');
	$tcpar_ExpectedValue_on_CAN = S_read_mandatory_testcase_parameter('Expected_value_on_CAN');

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {
	my $unit;
	S_teststep( "Start CAN trace", 'AUTO_NBR' );
	NET_trace_start();

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');

	S_teststep( "Wait for IniEnd", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	if ( $tcpar_Condition eq "WalaOn" ) {
		S_teststep( 'Disconnect AB1FD line.', 'AUTO_NBR' );
		LC_DisconnectLine('AB1FD');

		S_teststep( 'Wait until fault is detected.', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	}

	S_teststep( "Check warning indicator message during ECU off and ECU initialisation", 'AUTO_NBR', 'Check_warning_indicator_init' );

	#my $trStore_filepath = NET_trace_store ();   #measurement 1

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'read_fault_recorder' );    #measurement 2
	                                                                           # read fault memory
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Check warning indicator message", 'AUTO_NBR', 'Check_warning_indicator_fault' );    #measurement 3
	( $detectedValue_on_CAN, $unit ) = NET_read_signal($tcpar_can_signal);                           # read CAN signal 'phys' value

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "warning indicator message should be ON for certain period when ECU is switched ON. It should be OFF during ECU initialisation", 'Check_warning_indicator_init' );    #evaluation 1
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL---Manual validation is required", 'Check_warning_indicator_init' );

	S_teststep_expected( 'Expected faults:', 'read_fault_recorder' );                                                                                                                          #evaluation 2
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'read_fault_recorder' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'read_fault_recorder' );

	S_teststep_expected( "warning indicator message should have value $tcpar_ExpectedValue_on_CAN", 'Check_warning_indicator_fault' );    #evaluation 3
	S_teststep_detected( "Detected value :$detectedValue_on_CAN", 'Check_warning_indicator_fault' );
	EVAL_evaluate_value( "Warning lamp status on CAN", $detectedValue_on_CAN, "==", $tcpar_ExpectedValue_on_CAN );

	return 1;
}

sub TC_finalization {

	if ( $tcpar_Condition eq "WalaOn" ) {
		LC_ConnectLine('AB1FD');
		S_wait_ms(6000);
	}

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;
