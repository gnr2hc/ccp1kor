# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_WI_HWIndicatorSignal_PowerOff;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Warning_Indicators (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 5.11 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_SYC_INTERFACE;

#include further modules here
use Readonly;

Readonly my $SWITCH_STATE_CHANGE_TIME_MS => 6000;

##################################

our $PURPOSE = "check the behaviour of optical / acoustical indicator is correct and that the optical / acoustical indicator shows the correct state during power down/off";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_WI_HWIndicatorSignal_PowerOff

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Apply state

2. Set transient recorder

3. Switch ECU off

4. Measure optical / acoustical indicator signal

5. Check optical / acoustical indicator behaviour and state

6. Switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. -

4. -

5. optical / acoustical indicator behaviour is like specified behaviour and state is correct

7. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Ubat' => 
	SCALAR 'Pin' => 
	SCALAR 'Condition' => 
	SCALAR 'InitialOnTime_s' => 
	SCALAR 'OffAfterInit_s' => 
	LIST 'FLTmand' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check PADL (optical / acoustical indicator) signal during power off with <Test Heading Tail>' 
	
	# input parameter (used for stimulation and measurement)
	Ubat=<Random 9 to 16 step 0.1>
	
	Pin='PADL' # to be defined in Ref Type 4 Project constant
	Condition='PositionA'
	InitialOnTime_s = 5 #sec
	OffAfterInit_s = 0 #sec
	RelatedSwitches = @('PADS1', 'PADS2')
	
	
	# output parameter (used for evaluation)
	FLTmand=@()
	# PADI Indicator Off

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat;
my $tcpar_Pin;
my $tcpar_Condition;
my $tcpar_RelatedSwitches;

################ global parameter declaration ###################
#add any global variables here

my @temperatures = ();
###############################################################

sub TC_set_parameters {

	$tcpar_purpose         = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Pin             = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_Condition       = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_RelatedSwitches = S_read_mandatory_testcase_parameter( 'RelatedSwitches', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	# set TRC and scanner and measure
	S_teststep( 'Set transient recorder and scanner', 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'negative' } );
	LC_SetTRCscanner( [$tcpar_Pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 125 * 1000, 'MemorySize' => 1024 * 1024, 'TriggerDelay' => -1 } );

	foreach my $switch (@$tcpar_RelatedSwitches) {
		my ( $result, $state_value, $state_unit ) = SYC_SWITCH_get_state( $switch, $tcpar_Condition );
		LC_SetResistance( $switch, $state_value ) if ( $state_unit eq 'R' );
		LC_SetCurrent( $switch, $state_value ) if ( $state_unit eq 'I' );
	}

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);

	S_teststep( 'Wait for Init End.', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Set transient recorder.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	S_wait_ms(2000);

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_DisconnectLine('ALL_SUPPLY+');

	S_teststep( 'Measure Signal.', 'AUTO_NBR' );
	S_wait_ms(15000);
	S_teststep( 'Stop transient recorder.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStop();
	LC_ECU_Off();
	S_teststep( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'check_optical_acoustical' );
	my $TRC_Trace_storename = S_get_TC_number() . "_TRC_Trace_" . $tcpar_Pin . "_PowerOff" . time() . ".txt.unv";

	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $TRC_Trace_storename, 30000 );
	S_w2rep( '<A HREF="./' . $TRC_Trace_storename . '" TYPE="text/unv">' . "Click to view TRC trace $TRC_Trace_storename" . '</A><br>' );    #measurement1

	LC_ECU_On($tcpar_Ubat);
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_evaluation {

	#evaluate measured signal
	S_teststep_expected( "optical_acoustical indicator is either on or off during power down, and off at power off, optical_acoustical indicator is not blinking.", 'check_optical_acoustical' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL --> manual Evaluation of transient recorder Trace needed", 'check_optical_acoustical' );    #evaluation1

	return 1;
}

sub TC_finalization {

	LC_ECU_Off();
	LC_ResetTRCscanner();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;
