# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_WI_HWLampSignal_PowerOn;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Warning_Indicators
#TS version in DOORS: 5.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

#use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " switch ECU on and measure with transient recorder the warning lamp and check during initialization the behaviour of warning lamp is correct and that the warning lamp shows the correct state after initialization ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_WI_HWLampSignal_PowerOn 

=head1 PURPOSE

 switch ECU on and measure with transient recorder the warning lamp and check during initialization the behaviour of warning lamp is correct and that the warning lamp shows the correct state after initialization

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    Condition
    InitialOnTime_s
    OffAfterInit_s
    FLTmand
    FLTopt

    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set transient recorder and scanner
    apply fault if required
    start TRC measurement
    switch ECU on
    wait for end of measurement
    read fault recorder
    
    [evaluation]
    evaluate measured signal manually
    evaluate fault recorder

    [finalisation]
    switch ECU off
    reset transient recorder and scanner
    
=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> ECU pin
    SCALAR 'Condition'           --> condition of warning lamp (on or off)
    SCALAR 'InitialOnTime_s'   	 --> duration of initialization phase
    SCALAR 'OffAfterInit_s'	   	 --> duration of lamp off after initialization phase
    SCALAR 'Type'                --> 
    LIST   'FLTmand'             --> mandatory faults
    LIST   'FLTopt'              --> optional faults
    
=head2 PARAMETER EXAMPLES

    [TC_WI_HWLampSignal_PowerOn.AWL_WalaOff]   #ID: TS_TCR_761
    purpose='check AWL (HW indicator) signal during power on with WalaOff' 
    Ubat=14.5
    Pin='AWL'
    Condition='WalaOff'
    InitialOnTime_s = 5 #sec
    OffAfterInit_s = 0 #sec
    FLTmand=@()
        
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_Ubat, $tcpar_Pin, $tcpar_Condition, $tcpar_FLTmand, $tcpar_FLTopt );
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );
my @temperatures = ();
my $TRC_Trace_storename;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat      = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Pin       = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_Condition = S_read_mandatory_testcase_parameter('Condition');

	$tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt',  'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# set TRC and scanner and measure
	S_teststep( 'Set transient recorder and scanner', 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );
	LC_SetTRCscanner( [$tcpar_Pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 125 * 1000, 'MemorySize' => 1024 * 1024, 'TriggerDelay' => -1 } );

	if ( $tcpar_Condition eq "WalaOn" ) {
		S_teststep( 'Disconnect AB1FD line.', 'AUTO_NBR' );
		LC_DisconnectLine('AB1FD');

		S_teststep( 'Wait until fault is detected.', 'AUTO_NBR' );
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	}

	S_teststep( 'Set transient recorder.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	S_wait_ms(2000);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_teststep( 'Measure Signal.', 'AUTO_NBR' );
	S_wait_ms(15000);
	S_teststep( 'Stop transient recorder.', 'AUTO_NBR' );
	LC_MeasureTraceAnalogStop();

	S_teststep( 'Plot values of recording for Offline evaluation.', 'AUTO_NBR', 'lamp_1' );
	$TRC_Trace_storename = S_get_TC_number() . '_TRC_Trace_AWL_PowerOn_' . time() . ".txt.unv";

	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $TRC_Trace_storename, 30000 );
	S_w2rep( '<A HREF="./' . $TRC_Trace_storename . '" TYPE="text/unv">' . "Click to view TRC trace $TRC_Trace_storename" . '</A><br>' );

	S_teststep( "Read and eval RB fault memory.", 'AUTO_NBR', "fault_1" );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	#	evaluate measured signal
	S_teststep_expected( "'$tcpar_Pin' behaviour is like specified behaviour and state is according to fault state.", 'lamp_1' );
	S_set_verdict('VERDICT_FAIL');
	S_teststep_detected( "FAIL --> manual Evaluation of transient recorder trace needed", 'lamp_1' );

	# 	read fault memory and compare against mandatory and optional faults
	S_teststep_expected( 'Expected faults:', 'fault_1' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'fault_1' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'fault_1' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_Off();
	LC_ConnectLine('AB1FD') if ( $tcpar_Condition eq "WalaOn" );
	LC_ResetTRCscanner();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat V");

	return 1;
}

1;

__END__
