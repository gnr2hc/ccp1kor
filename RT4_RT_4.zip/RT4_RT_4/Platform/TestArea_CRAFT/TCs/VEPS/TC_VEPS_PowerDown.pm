# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_PowerDown;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_FaultMemory;
use LIFT_evaluation;
use File::Basename;
##################################

our $PURPOSE = "test that the ECU is able to store relevant data into NVM and that no fault is qualified";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

 TC_VEPS_PowerDown 

=head1 PURPOSE

 test that the ECU is able to store relevant data into NVM and that no fault is qualified

=head1 TESTCASE DESCRIPTION

 tbd
 
 [parameter used]

    Testcase Parameter:

    HImin
    HImax
    LOmin
    LOmax
    VminLO
    VmaxLO
    VminHI
    VmaxHI
    MAXtime
    FLTmand (optional)
    FLTopt  (optional)

 [initialisation]
    switch ECU on 
    erase fault recorder
    read fault recorder
    switch ECU off

 [stimulation & measurement]
	1. switch ECU on
	2. read power on counter and power on time
	3. apply given voltage / time profile
	4. switch ECU off
	5. switch ECU on
	6. read fault recorder
	7. read power on counter and power on time
	8. switch ECU off

 [evaluation]
	1. -
	2. store values
	3. -
	4. -
	5. -
	6. no fault
	7. compare values with stored values
	8. -

 [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'VoltageProfile' --> name of voltage profile file
    SCALAR 'Mode'           --> ECU mode in which the test case is done
    LIST   'FLTmand'        --> list of mandatory faults (logical names)
    LIST   'FLTopt'         --> list of optional faults (logical names) - optional parameter

=head2 PARAMETER EXAMPLES

	[TC_VEPS_PowerDown.Condition1_NormalMode]
	purpose        = '$checking power down and autarky behaviour for  Condition1' 
	VoltageProfile = '.\config\Curves\PowerDown_Condition1_NormalMode.sat'
	Mode           = 'NormalMode'
	FLTmand        = @()
	FLTopt         = @() # optional parameter

 NOTE: values below 4.2 V will be set to 4.2 V (internal clipping due to OP-amp)
 
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $duration, $tcpar_ECUMode, $tcpar_CurveFile, $tcpar_FLTmand_aref, $tcpar_FLTopt_aref );
my ( $fltmem1,  $filename,      $fltmem2,         $fltmem3,            $fltmem4 );
my ( $POC1,     $POT1,          $POC2,            $POT2 );
my @temperatures = ();

my ( $expected_faults_href, $generatedCurve );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ECUMode      = S_read_mandatory_testcase_parameter("Mode");
	$tcpar_CurveFile    = S_read_mandatory_testcase_parameter('VoltageProfile');
	$tcpar_FLTmand_aref = S_read_mandatory_testcase_parameter('FLTmand');
	$tcpar_FLTopt_aref  = S_read_optional_testcase_parameter('FLTopt');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	TEMP_get_temperature();

	$filename = $tcpar_CurveFile;

	LC_PowerPlotCurve($filename);

	S_teststep( "load voltage curve to configured power supply.", 'AUTO_NBR' );
	($duration) = LC_PowerConfigCurve($filename);

	S_teststep( "switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	S_teststep( "clear fault memory", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "read fault recorder", 'AUTO_NBR' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Plant');

	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR' );
	LIFT_FaultMemory->read_fault_memory('Disturbance');

	S_teststep( "switch ECU off", 'AUTO_NBR' );
	LC_SetVoltage(0);
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# my $transiSettings_href = GetTRCSettings( $duration * 1000 );

	# LC_SetTRCscanner( ['Sense1'], { 'SignalMode' => 'differential', 'VoltageRange' => 50 } );
	# LC_ConfigureTRCchannels($transiSettings_href);

	# LC_MeasureTraceAnalogStart();
	# S_wait_ms(1000);

	S_teststep( "switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "read labels", 'AUTO_NBR' );
	S_teststep_2nd_level( "read power on counter", 'AUTO_NBR' );
	$POC1 = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', { memoryContentsAsInteger => 1 } );

	S_teststep_2nd_level( "read power on time", 'AUTO_NBR' );
	$POT1 = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_st.PoOnTime_u32', { memoryContentsAsInteger => 1 } );

	# LC_MeasureTraceAnalogSendSWTrigger();
	# S_wait_ms(100);

	S_teststep( "start voltage profile", 'AUTO_NBR' );
	S_set_timer_zero();
	LC_PowerStartCurve();
	S_wait_ms( $duration * 1000 );
	S_wait_ms(500);

	S_teststep( "switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "read fault recorder", 'AUTO_NBR', 'read_fault' );
	S_teststep_2nd_level( "read primary fault recorder", 'AUTO_NBR', 'read_fault_primary' );
	$fltmem1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( "read Bosch fault recorder", 'AUTO_NBR', 'read_fault_bosch' );
	$fltmem2 = LIFT_FaultMemory->read_fault_memory('Bosch');
	S_teststep_2nd_level( "read plant fault recorder", 'AUTO_NBR', 'read_fault_plant' );
	$fltmem3 = LIFT_FaultMemory->read_fault_memory('Plant');
	S_teststep_2nd_level( "read disturbed fault recorder", 'AUTO_NBR', 'read_fault_disturb' );
	$fltmem4 = LIFT_FaultMemory->read_fault_memory('Disturbance');

	S_teststep( "read labels", 'AUTO_NBR' );
	S_teststep_2nd_level( "read power on counter", 'AUTO_NBR', 'PowerOnCounter' );
	$POC2 = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', { memoryContentsAsInteger => 1 } );

	S_teststep_2nd_level( "read power on time", 'AUTO_NBR', 'PowerOnTime' );
	$POT2 = PRD_Read_Memory( 'rb_tim_EcuOnTimeDataEe_st.PoOnTime_u32', { memoryContentsAsInteger => 1 } );

	# S_wait_until_timer_ms( GetTRCRecordingTime( $transiSettings_href->{MemorySize}, $transiSettings_href->{SamplingFrequency} ) );
	# LC_MeasureTraceAnalogStop();

	# my $TRC_Trace_storename = S_get_TC_number() . "_TRC_Trace_" . S_get_TC_parameter_name() . ".txt.unv";
	# LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $TRC_Trace_storename, 30000 );
	# S_w2rep( '<A HREF="./' . $TRC_Trace_storename . '" TYPE="text/unv">' . "Click to view TRC trace $TRC_Trace_storename" . '</A><br>' );    #measurement1

	S_teststep( "get ambient temperature", 'AUTO_NBR' );
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
	$expected_faults_href = {
		'mandatory' => $tcpar_FLTmand_aref,
		'optional'  => $tcpar_FLTopt_aref,
	};

	my $eval_primary = $fltmem1->evaluate_faults( $expected_faults_href, 'read_fault_primary' );
	my $eval_bosch   = $fltmem2->evaluate_faults( $expected_faults_href, 'read_fault_bosch' );

	my @boschFaults;
	if ( $fltmem2->get_number_of_faults() ) {
		foreach my $fault_entry_obj ( values %{ $fltmem2->FaultEntriesHash } ) {
			push @boschFaults, $fault_entry_obj->FaultName;
		}
	}
	my $eval_primary2bosch = $fltmem1->evaluate_faults( { 'mandatory' => \@boschFaults, }, 'read_fault_primary' );

	my @primaryFaults;
	if ( $fltmem1->get_number_of_faults() ) {
		foreach my $fault_entry_obj ( values %{ $fltmem1->FaultEntriesHash } ) {
			push @primaryFaults, $fault_entry_obj->FaultName;
		}
	}
	my $eval_bosch2primary = $fltmem2->evaluate_faults( { 'mandatory' => \@primaryFaults, }, 'read_fault_bosch' );

	unless ($eval_primary eq VERDICT_PASS
		and $eval_bosch eq VERDICT_PASS
		and $eval_bosch2primary eq VERDICT_PASS
		and $eval_primary2bosch eq VERDICT_PASS )
	{
		S_teststep_detected("content of primary and bosch fault memory is different");
	}

	S_teststep_expected( "Power On Counter: value 2 >= value 1", 'PowerOnCounter' );
	S_teststep_detected( "Power On Counter: value 1 = $POC1", 'PowerOnCounter' );
	S_teststep_detected( "Power On Counter: value 2 = $POC2", 'PowerOnCounter' );
	EVAL_evaluate_value( 'Power On Counter', $POC2, '>=', $POC1 );

	S_teststep_expected( "Power On Time: value 2 > value 1", 'PowerOnTime' );
	S_teststep_detected( "Power On Time: value 1 = $POT1", 'PowerOnTime' );
	S_teststep_detected( "Power On Time: value 2 = $POT2", 'PowerOnTime' );
	EVAL_evaluate_value( 'Power On Time', $POT2, '>', $POT1 );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	push( @temperatures, TEMP_get_temperature() );

	# LC_ResetTRCscanner();

	S_w2rep( "\nlogged temperatures in celsius: " . join( ' -> ', @temperatures ) . "\n", 'blue' );
	return 1;
}

sub GetTRCSettings {
	my @args = @_;

	my $minRecordingTime_ms = shift @args;
	my $recordingTime_ms;
	my $memorySize_B;
	my $lastValidMemorySize_B;
	my $lastValidSamplingFrequency_Hz;
	my @possibleMemorySizes_kB = ( 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048 );
	my @possibleSamplingFrequencies_kHz = ( 10, 5, 2, 1, 0.5, 0.2, 0.1 );

	S_w2log( 3, "\$minRecordingTime_ms: $minRecordingTime_ms \n" );

	foreach my $samplingFrequency_kHz ( sort { $b <=> $a } @possibleSamplingFrequencies_kHz ) {
		my $samplingFrequency_Hz = $samplingFrequency_kHz * 1000;
		foreach my $memorySize_kB ( sort { $b <=> $a } @possibleMemorySizes_kB ) {
			$memorySize_B          = $memorySize_kB * 1024;
			$recordingTime_ms      = GetTRCRecordingTime( $memorySize_B, $samplingFrequency_Hz );
			$lastValidMemorySize_B = $memorySize_B if $minRecordingTime_ms < $recordingTime_ms;
		}
		$lastValidSamplingFrequency_Hz = $samplingFrequency_Hz;
		last if $lastValidMemorySize_B;
	}

	my $settings_href = {
		'SamplingFrequency' => $lastValidSamplingFrequency_Hz,
		'MemorySize'        => $lastValidMemorySize_B,
		'TriggerDelay'      => 0
	};

	return $settings_href;
}

sub GetTRCRecordingTime {
	my @args = @_;

	my $memorySize_B         = shift @args;
	my $samplingFrequency_Hz = shift @args;
	my $recordingTime_s;
	my $recordingTime_ms;

	$recordingTime_s = $memorySize_B * ( 1 / $samplingFrequency_Hz );
	$recordingTime_ms = $recordingTime_s * 1000;

	return $recordingTime_ms;
}

1;

__END__
