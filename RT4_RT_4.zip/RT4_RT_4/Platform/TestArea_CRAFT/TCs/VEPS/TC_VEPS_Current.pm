# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_Current;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

#use FuncLib_SYC_INTERFACE;
#################################

our $PURPOSE = " measure the ECU current consumption ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_Current

=head1 PURPOSE

measure the ECU current consumption

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on

2. set ECU in required mode

3. measure current consumption

4. set ECU in normal mode

5. switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. check measured current

4. -

5. - 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose'           => short test case description
	SCALAR 'ECUMode'           => mode of ECU
	SCALAR 'Ubat_V'            => used battery voltage
	SCALAR 'Temp'              => used temperature
	SCALAR 'MeasStartTime_ms'  => start time of measurement after power on
	SCALAR 'MeasDuration_ms'   => duration of measurement
	SCALAR 'I_uA'              => expected current consumption in �A


=head2 PARAMETER EXAMPLES

	[TC_VEPS_Current.Initialization_8_V]
	purpose          = 'check current consumption in Initialization' 
	ECUMode          = 'Initialization'
	Ubat_V           = 8 # V
	I_mA             = 115 # mA
	Temp             = 25 # �C
	MeasStartTime_ms = 2 #ms (start of measurement)
	MeasDuration_ms  = 4000 #ms (duration of measurement)
	
	[TC_VEPS_Current.SleepMode_Measurement1_2ASIC_CAN]
	purpose          = 'check current consumption in SleepMode' 
	ECUMode          = 'SleepMode'
	Ubat_V           = 20 #V
	I_uA             = 121 #�A
	Temp             = 85 #�C +/-5�C
	MeasStartTime_ms = 4000 #ms (start of measurement)
	MeasDuration_ms  = 2000 #s (duration of measurement)
	

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my ( $tcpar_ECUMode, $tcpar_Ubat_V, $tcpar_Temp );
my ( $tcpar_I_uA, $tcpar_I_mA );
my ( $tcpar_MeasStartTime_ms, $tcpar_MeasDuration_ms );

################ global parameter declaration ###################
my $unv_file_name;
my $toleranceCurrent = 5;    # %
my $action;
my ( $valid_flag, $return_value, $precondition_valid );
my @supplyLines = ( 'UBAT1_I', 'UBAT2_I', 'UBAT3_I', 'UBAT4_I' );
my @temperatures = ();

sub TC_set_parameters {

	$tcpar_purpose          = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ECUMode          = S_read_mandatory_testcase_parameter('ECUMode');
	$tcpar_Ubat_V           = S_read_mandatory_testcase_parameter('Ubat_V');
	$tcpar_Temp             = S_read_mandatory_testcase_parameter('Temp');
	$tcpar_MeasStartTime_ms = S_read_mandatory_testcase_parameter('MeasStartTime_ms');
	$tcpar_MeasDuration_ms  = S_read_mandatory_testcase_parameter('MeasDuration_ms');

	if ( $tcpar_ECUMode eq 'Initialization' ) {
		$tcpar_I_mA         = S_read_mandatory_testcase_parameter('I_mA');
		$precondition_valid = 1;
	}
	elsif ( $tcpar_ECUMode eq 'SleepMode' ) {
		$tcpar_I_uA         = S_read_mandatory_testcase_parameter('I_uA');
		$precondition_valid = 1;
	}
	else {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("given ECU Mode is not supported");
		S_teststep_detected("ECUMode has to be 'Initialization' or 'SleepMode'");
		$precondition_valid = 0;
	}

	( $valid_flag, $return_value ) = S_read_public_variable("TEMPcontrolled");

	if ( $valid_flag == 1 and $return_value == 1 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("Test is trying to set temperature, but temperature is controlled by IC!");
		S_teststep_detected("Rerun of TC with an IC without temp necessary!");
		$precondition_valid = 0;
	}
	elsif ( $valid_flag == 0 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("State of temperature is not known!");
		S_teststep_detected("IC with public variable 'TEMPcontrolled' to be used!");
		$precondition_valid = 0;
	}
	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	if ($precondition_valid) {

		TEMP_get_temperature();

		my $TCRuntime = S_get_TC_time();
		TEMP_setTargetTemperature($tcpar_Temp);
		S_w2rep( "* set temperature '$tcpar_Temp �C' * \n", 'green' );
		TEMP_waitForTemperature( 120, 5 );
		$TCRuntime = S_get_TC_time() - $TCRuntime;
		if ( $TCRuntime > 600 ) {
			S_w2rep( " * waiting for ECU acclimatisation (20min) * \n", 'green' );
			S_wait_ms( 20 * 60 * 1000 );
		}
		else {
			S_w2rep( " * waiting for ECU acclimatisation not necessary * \n",           'green' );
			S_w2rep( " * duration for heating / cooling took only $TCRuntime sec * \n", 'green' );
		}

		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');

		PRD_Clear_Fault_Memory();
		S_wait_ms('TIMER_ECU_READY');

		LIFT_FaultMemory->read_fault_memory('Bosch');
		LIFT_FaultMemory->read_fault_memory('Primary');

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		push( @temperatures, TEMP_get_temperature() );
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	if ($precondition_valid) {
		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_Ubat_V);

		S_teststep( "Set ECU in required mode.", 'AUTO_NBR' );
		if ( $tcpar_ECUMode eq 'SleepMode' ) {
			S_teststep_2nd_level( "Active sleep mode.", 'AUTO_NBR' );
			$action = S_user_action( "WARNING" . "\nPlease set ECU sleep mode.\n\n" . "Current measurement will be started after a reset.\n" . "Confirm with yes if sleep mode is activated.\n" . "Confirm with no if you want to cancel this test.", 'YesNo' );

			if ( $action eq 'no' ) {
				S_set_verdict("VERDICT_NONE");
				S_teststep_detected("Test is canceled by user input");
				return 1;
			}
			elsif ( $action eq 'yes' ) {
				S_teststep_2nd_level( "ECU is switched off", 'AUTO_NBR' );
				LC_ECU_Off();
				S_wait_ms('TIMER_ECU_READY');
			}
		}
		elsif ( $tcpar_ECUMode eq 'Initialization' ) {
			$action = 'yes';
			S_teststep_2nd_level( "Prepare ECU for current measurement during initialization", 'AUTO_NBR' );
			S_teststep_2nd_level( "ECU is switched off",                                       'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_READY');
		}
		else {
			$action = 'no';
			S_teststep_2nd_level( "This ECU mode is not support from the test case.", 'AUTO_NBR' );
			S_set_verdict("VERDICT_INCONC");
			return 1;
		}

		S_teststep( "Measure current consumption", 'AUTO_NBR', 'measure_current_consumption' );

		if ( $tcpar_ECUMode eq 'Initialization' ) {
			S_teststep_2nd_level( "Set scanner and transient recorder.", 'AUTO_NBR' );
			LC_SetTRCscanner( ['Sense1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'positive' } );
			LC_SetTRCscanner( \@supplyLines, { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
			LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 128 * 1024, 'TriggerDelay' => 0 } );

			S_teststep_2nd_level( "Start transient recorder measurement.", 'AUTO_NBR' );
			LC_MeasureTraceAnalogStart();
			LC_ECU_On($tcpar_Ubat_V);

			S_teststep_2nd_level( "Wait for measurement finished", 'AUTO_NBR' );
			S_wait_ms(7000);
			LC_MeasureTraceAnalogStop();

			S_teststep_2nd_level( "Evaluate current consumption", 'AUTO_NBR' );
			$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
			LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
			S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );
		}
		elsif ( $tcpar_ECUMode eq 'SleepMode' ) {
			S_user_action( "USER ACTION" . "\nPerform current measurement manually with DMM.\n\n" . "Note down measured current value and enter it in DOORS test report.\n", 'Ok' );
		}
		S_teststep( "Set ECU in normal mode", 'AUTO_NBR' );
		if ( $tcpar_ECUMode eq 'SleepMode' ) {
			S_teststep_2nd_level( "Deactive sleep mode.", 'AUTO_NBR' );
			S_user_action( "WARNING" . "\nPlease set ECU in normal mode.\n\n" . "Confirm with Ok when sleep mode is deactivated.\n", 'Ok' );

		}
		elsif ( $tcpar_ECUMode eq 'Initialization' ) {
			S_teststep_2nd_level( "No additional steps needed", 'AUTO_NBR' );
		}

		S_teststep( "Switch ECU off", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_READY');
	}
	return 1;
}

sub TC_evaluation {

	my $data_HoH;
	my $measured_I_mA;
	my $measured_I_uA;
	my ( $squareamplitude, $avg_current_A );

	if ( $precondition_valid == 1 and $action eq 'yes' ) {

		if ( $tcpar_ECUMode eq 'Initialization' ) {
			$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );

			foreach my $channel (@supplyLines) {
				my @values = EVAL_get_values_over_time( $data_HoH, $channel );

				foreach my $datapoint (@values) { $squareamplitude += ( $datapoint * $datapoint ); }
				$squareamplitude /= scalar(@values);
				$avg_current_A = sqrt($squareamplitude);
				S_w2log( 3, "Average current of '$channel': $avg_current_A A." );
				$measured_I_mA += 1000 * $avg_current_A if $avg_current_A > 0.005;
			}

			$measured_I_mA = sprintf( "%.2f", $measured_I_mA );

			S_teststep_expected( "current = $tcpar_I_mA mA", 'measure_current_consumption' );
			S_teststep_detected( "current = $measured_I_mA mA", 'measure_current_consumption' );
			EVAL_evaluate_value( "current", $measured_I_mA, '==', $tcpar_I_mA, $toleranceCurrent, 'relative' );
		}
		elsif ( $tcpar_ECUMode eq 'SleepMode' ) {

			#			$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
			#
			#			foreach my $channel (@supplyLines) {
			#				my @values = EVAL_get_values_over_time( $data_HoH, $channel );
			#				foreach my $datapoint (@values) { $squareamplitude += ( $datapoint * $datapoint ); }
			#
			#				$squareamplitude /= scalar(@values);
			#				$avg_current_A = sqrt($squareamplitude);
			#				S_w2log( 3, "Average current of '$channel': $avg_current_A A." );
			#				$measured_I_uA += 1000 * 1000 * $avg_current_A if $avg_current_A > 0.005;
			#			}
			#
			#			$measured_I_uA = sprintf( "%.2f", $measured_I_uA );
			#
			#			S_teststep_expected( "current = $tcpar_I_uA �A", 'measure_current_consumption' );
			#			S_teststep_detected( "current = $measured_I_uA �A", 'measure_current_consumption' );
			#			EVAL_evaluate_value( "current", $measured_I_uA, '==', $tcpar_I_uA, $toleranceCurrent, 'relative' );

			S_teststep_expected( "current <= $tcpar_I_uA �A",, 'measure_current_consumption' );
			S_set_verdict('VERDICT_FAIL');
			S_teststep_detected( "FAIL --> enter manually measured value of current measurement and perform evaluation",, 'measure_current_consumption' );

		}

	}
	return 1;
}

sub TC_finalization {

	if ($precondition_valid) {
		LC_ResetTRCscanner();

		# switch ECU off
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep_detected("TEMP: $temperatures[0]");
		S_teststep_detected("UBat: $tcpar_Ubat_V V");
	}
	return 1;
}

1;
