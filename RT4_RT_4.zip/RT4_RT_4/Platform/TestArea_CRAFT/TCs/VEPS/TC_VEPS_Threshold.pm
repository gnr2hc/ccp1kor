# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_Threshold;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check battery voltage threshold";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_Threshold

=head1 PURPOSE

check battery voltage threshold

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. get temperature


I<B<Stimulation and Measurement>>

1. switch ECU on
2. decrease / increase battery till fault is present
3. measure battery voltage
4. read fault memory
5. increase / decrease battery till fault is not present
6. measure battery voltage
7. read fault memory
8. switch ECU off


I<B<Evaluation>>

1. -
2. - 
3. measured value should be in tolerance 
4. expected fault present
5. -
6. measured value should be in tolerance
7. no fault present
8. -

I<B<Finalisation>>

Reset/Remove the test condition created in test case
Switch ECU off

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => description of test case
	SCALAR 'Speed_mV_s' => change rate of battery voltage [mV/s]
	SCALAR 'FaultQualificationTime_ms' => wait time in ms until the fault has to be qualified
	LIST 'FLTmand' => mandatory fault
	LIST 'FLTopt' =>  optional fault


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check battery voltage threshold for  <Test Heading Head>'
	
	# input parameter (used for stimulation and measurement)
	Speed_mV_s                 = 50
	FaultQualificationTime_ms  = 5000
	
	# output parameter (used for evaluation)
	FLTmand = @( )
	FLTopt = @()

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat_V;
my $tcpar_Speed_mV_s;
my $tcpar_Threshold_V;
my $tcpar_FaultQualificationTime_ms;
my $tcpar_FLTopt;
my $tcpar_FLTmand;

################ global parameter declaration ###################
#add any global variables here
my @temperatures = ();
my ( $fltmem1, $fltmem2 );
my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $expectedFaults_href );

my $voltage_level;
my $voltage_read_faultqualify;
my $voltage_read_defaultqualify;
my $needed_steps;
my $result;

my $tolerance4VbatLow_V  = 0.8;
my $tolerance4VbatHigh_V = 1.2;
my $tolerance_V          = 1.0;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                   = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Speed_mV_s                = S_read_mandatory_testcase_parameter('Speed_mV_s');
	$tcpar_FaultQualificationTime_ms = S_read_mandatory_testcase_parameter('FaultQualificationTime_ms');

	#	$tcpar_Threshold_V =  GEN_Read_mandatory_testcase_parameter( 'Threshold' );
	$tcpar_FLTopt  = S_read_mandatory_testcase_parameter( 'FLTopt',  'byref' );
	$tcpar_FLTmand = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );

	S_w2rep(" voltage_level : '$voltage_level' \n");

	#	$tcpar_Threshold_V =~ s/,/./g;

	( $result, $tcpar_Threshold_V ) = SYC_POWERSUPPLY_get_LowVoltageDetectionLimit() if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
	$tcpar_Ubat_V = $tcpar_Threshold_V + 1 if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
	( $result, $tcpar_Threshold_V ) = SYC_POWERSUPPLY_get_HighVoltageDetectionLimit() if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );
	$tcpar_Ubat_V = $tcpar_Threshold_V - 1 if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );
	unless ( defined $tcpar_Ubat_V ) {
		S_set_error( "tcpar_FLTmand[0] is not 'rb_pom_VbatLow_flt' or 'rb_pom_VbatHigh_flt' as needed. \n", 110 );
		return 0;
	}

	$tolerance_V = $tolerance4VbatLow_V  if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
	$tolerance_V = $tolerance4VbatHigh_V if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

sub TC_stimulation_and_measurement {

	LC_SetDVMscanner('Sense1');

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Decrease battery till fault is present", 'AUTO_NBR' ) if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
	S_teststep( "Increase battery till fault is present", 'AUTO_NBR' ) if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );

	#    $needed_steps = 2 / ( $tcpar_Speed_mV_s / 1000 );
	$needed_steps = 4 / ( $tcpar_Speed_mV_s / 1000 );
	$needed_steps = int( $needed_steps + 1.5 );

	S_w2rep(" max needed steps : '$needed_steps' \n");

	for ( my $i = 1 ; $i < $needed_steps ; $i++ ) {
		$voltage_level = $tcpar_Ubat_V - $i * $tcpar_Speed_mV_s / 1000 if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
		$voltage_level = $tcpar_Ubat_V + $i * $tcpar_Speed_mV_s / 1000 if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );
		LC_SetVoltage($voltage_level);
		S_wait_ms( $tcpar_FaultQualificationTime_ms * 1.1 );
		$fltmem1 = LIFT_FaultMemory->read_fault_memory('Bosch');
		$fltmem2 = LIFT_FaultMemory->read_fault_memory('Primary');
		if ( $fltmem1->check_fault_presence( $$tcpar_FLTmand[0] ) eq 'present' and $fltmem2->check_fault_presence( $$tcpar_FLTmand[0] ) eq 'present' ) {
			S_w2rep(" -->  fault is qualified \n");
			last;
		}

	}

	S_teststep( "Measure battery voltage", 'AUTO_NBR', 'measure_battery_voltage_faultQualified' );
	$voltage_read_faultqualify = LC_MeasureOnceGetVoltage();

	S_teststep( "Read and evaluate RB fault memory", 'AUTO_NBR', 'fault_qualified' );
	$fltmemBosch1   = $fltmem1;
	$fltmemPrimary1 = $fltmem2;

	S_teststep( "Decrease battery till fault is absent", 'AUTO_NBR' ) if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );
	S_teststep( "Increase battery till fault is absent", 'AUTO_NBR' ) if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );

	$tcpar_Ubat_V = $voltage_level;

	$needed_steps = abs( $tcpar_Ubat_V - ( $tcpar_Threshold_V - 1 ) ) if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );
	$needed_steps = abs( $tcpar_Ubat_V - ( $tcpar_Threshold_V + 1 ) ) if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
	$needed_steps = $needed_steps / ( $tcpar_Speed_mV_s / 1000 );
	$needed_steps = int( $needed_steps + 1.5 );

	S_w2rep(" max needed steps : '$needed_steps' \n");

	for ( my $i = 1 ; $i < $needed_steps ; $i++ ) {
		$voltage_level = $tcpar_Ubat_V + $i * $tcpar_Speed_mV_s / 1000 if ( $$tcpar_FLTmand[0] =~ /VbatLow/ );
		$voltage_level = $tcpar_Ubat_V - $i * $tcpar_Speed_mV_s / 1000 if ( $$tcpar_FLTmand[0] =~ /VbatHigh/ );

		LC_SetVoltage($voltage_level);
		S_wait_ms('500');
		PRD_Clear_Fault_Memory();
		S_wait_ms( $tcpar_FaultQualificationTime_ms * 1.1 );
		$fltmem1 = LIFT_FaultMemory->read_fault_memory('Bosch');
		$fltmem2 = LIFT_FaultMemory->read_fault_memory('Primary');
		if ( $fltmem1->check_fault_presence( $$tcpar_FLTmand[0] ) eq 'not_present' and $fltmem2->check_fault_presence( $$tcpar_FLTmand[0] ) eq 'not_present' ) {
			S_w2rep(" -->  fault is qualified \n");
			last;
		}

	}

	S_teststep( "Measure battery voltage", 'AUTO_NBR', 'measure_battery_voltage_faultDequalified' );
	$voltage_read_defaultqualify = LC_MeasureOnceGetVoltage();

	S_teststep( "Read and evaluate RB fault memory", 'AUTO_NBR', 'fault_dequalified' );
	$fltmemBosch2   = $fltmem1;
	$fltmemPrimary2 = $fltmem2;

	return 1;
}

sub TC_evaluation {

	my $voltage_threshold_max = $tcpar_Threshold_V + $tolerance_V;
	my $voltage_threshold_min = $tcpar_Threshold_V - $tolerance_V;

	$voltage_read_faultqualify   = sprintf( "%.2f", $voltage_read_faultqualify );
	$voltage_read_defaultqualify = sprintf( "%.2f", $voltage_read_defaultqualify );

	S_teststep_expected( "'$voltage_threshold_min V <= measured value <= '$voltage_threshold_max V'", 'measure_battery_voltage_faultQualified' );    #evaluation 1
	S_teststep_detected( "Measured valuev = '$voltage_read_faultqualify V'", 'measure_battery_voltage_faultQualified' );
	EVAL_evaluate_interval( "voltage_lowORHigh", $voltage_threshold_min, $voltage_threshold_max, $voltage_read_faultqualify );

	S_teststep_expected( "'$voltage_threshold_min V <= measured value <= '$voltage_threshold_max V'", 'measure_battery_voltage_faultDequalified' );    #evaluation 1
	S_teststep_detected( "Measured value = '$voltage_read_defaultqualify V'", 'measure_battery_voltage_faultDequalified' );
	EVAL_evaluate_interval( "normal", $voltage_threshold_min, $voltage_threshold_max, $voltage_read_defaultqualify );

	S_teststep_expected( 'Expected faults:', 'fault_qualified' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'fault_qualified' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'fault_qualified' );

	S_teststep_expected( 'Expected faults:', 'fault_dequalified' );

	$expectedFaults_href = {
		'mandatory'   => [],
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch2->evaluate_faults( $expectedFaults_href, 'fault_dequalified' );
	$fltmemPrimary2->evaluate_faults( $expectedFaults_href, 'fault_dequalified' );

	return 1;
}

sub TC_finalization {

	LC_ResetDVMscanner();
	LC_ECU_Off();

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );

	return 1;
}

1;

