# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_ReverseVoltage;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------
#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;

#include further modules here

##################################

our $PURPOSE = " test that the ECU is robust against a battery supply with wrong polarity ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_ReverseVoltage

=head1 PURPOSE

test that the ECU is robust against a battery supply with wrong polarity

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on with reverse polarity

2. wait for given time

3. start communication

4. switch ECU off

5. switch ECU on with correct polarity

6. read fault recorder

7. switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. no communication 

4. -

5. -

6. no fault

7. -


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Ubat' => battery voltage 
	SCALAR 'Duration' => duration for wrong polarity in min
	SCALAR 'T' =>  temperature
	LIST 'FLTmand' =>  mandatory (expected) faults


=head2 PARAMETER EXAMPLES

    [TC_VEPS_ReverseVoltage.condition1]
    purpose='$checking reverse voltage Condition1' 
    Ubat=13.5 # V
    Duration=1 # min
    T=25 # �C
    FLTmand=@()

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_FLTmand;
my $tcpar_Ubat;
my $tcpar_Duration_min;
my $tcpar_T;
my ($fltmem1);
my ( $ecuProperties_href, $ECUMode );
my $voltage_read;
my $current_read;
my @temperatures;
my $action;
my ($result);
my ( $valid_flag,    $return_value );
my ( $sycpar_Ubat_V, $sycpar_duration_min, $sycpar_temperature_C );
my ( $fltmemBosch,   $fltmemPrimary );
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_FLTmand      = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_Ubat         = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Duration_min = S_read_mandatory_testcase_parameter('Duration');
	$tcpar_T            = S_read_mandatory_testcase_parameter('T');

	# if one of the parameters requires SYC data
	if ( $tcpar_Ubat eq 'SYC' or $tcpar_Duration_min eq 'SYC' or $tcpar_T eq 'SYC' ) {
		( $result, $sycpar_Ubat_V, $sycpar_duration_min, $sycpar_temperature_C ) = SYC_POWERSUPPLY_get_ReverseVoltageTestConditions();

		$tcpar_Ubat         = $sycpar_Ubat_V        if $tcpar_Ubat eq 'SYC';
		$tcpar_Duration_min = $sycpar_duration_min  if $tcpar_Duration_min eq 'SYC';
		$tcpar_T            = $sycpar_temperature_C if $tcpar_T eq 'SYC';
	}

	( $valid_flag, $return_value ) = S_read_public_variable("TEMPcontrolled");

	if ( $valid_flag == 1 and $return_value == 1 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("Test is trying to set temperature, but temperature is controlled by IC!");
		S_teststep_detected("Rerun of TC with an IC without temp necessary!");
	}
	elsif ( $valid_flag == 0 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("State of temperature is not known!");
		S_teststep_detected("IC with public variable 'TEMPcontrolled' to be used!");
	}

	return 1;
}

sub TC_initialization {
	if ( $valid_flag == 1 and $return_value == 0 ) {

		if ( $tcpar_T != -1000 ) {

			# VT_connect();
			TEMP_get_temperature();

			#VT_setCompressor('on');
			my $TCRuntime = S_get_TC_time();
			TEMP_setTargetTemperature($tcpar_T);
			S_w2rep( " * set temperature $tcpar_T �C * \n", 'green' );
			TEMP_waitForTemperature( 120, 2 );
			$TCRuntime = S_get_TC_time() - $TCRuntime;
			if ( $TCRuntime > 600 ) {
				S_w2rep( " * waiting for ECU acclimatisation (20 min) \n", 'green' );
				S_wait_ms( 20 * 60 * 1000 );
			}
			else {
				S_w2rep( " * waiting for ECU acclimatisation not necessary * \n",         'green' );
				S_w2rep( " * duration for heating/cooling took only $TCRuntime sec * \n", 'green' );
			}
		}

		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');
		PRD_Clear_Fault_Memory();
		S_wait_ms('TIMER_ECU_READY');

		PRD_Clear_Fault_Memory();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		push( @temperatures, TEMP_get_temperature() );
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $valid_flag == 1 and $return_value == 0 ) {
		S_teststep( "Switch ECU on with reverse polarity.", 'AUTO_NBR' );

		S_teststep( "Polarity of battery voltage is changed manually.", 'NO_AUTO_NBR' );
		$action = S_user_action(
			"WARNING"
			  . "\nPlease change polarity of battery voltage connection.\n\n"
			  . "Please remove any gnd connection to ECU base plate.\n"
			  . "Please disconnect all additional devices which can be damaged by reversed battery voltage\n\n"
			  . "Confirm with yes if battery voltage connection is reversed.\n"
			  . "Confirm with no if you want to cancel this test.",
			'YesNo'
		);

		if ( $action eq 'no' ) {
			S_set_verdict("VERDICT_NONE");
			S_teststep_detected("Test is canceled by user input");
		}
		elsif ( $action eq 'yes' ) {

			LC_SetVoltage($tcpar_Ubat);

			#TSG4_lowlevel_command("ubat_UF(1,'reverse')");
			LC_PowerConnect();

			S_teststep( "Measure current reverse polarity.", 'AUTO_NBR', 'current_measurement' );
			LC_SetDVMscanner('UBAT1::current');
			$current_read = LC_MeasureOnceGetVoltage();
			LC_ResetDVMscanner();
			S_wait_ms(100);

			S_teststep( "Measure battery voltage and check for reverse polarity.", 'AUTO_NBR', 'battery_voltage' );
			LC_SetDVMscanner('UBAT1');
			$voltage_read = LC_MeasureOnceGetVoltage();

			S_teststep( "Wait for '$tcpar_Duration_min' min.", 'AUTO_NBR' );
			S_wait_ms( $tcpar_Duration_min * 60 * 1000 );

			S_teststep( "Check communication.", 'AUTO_NBR', 'start_communication' );    #measurement 1
			my $success = PRD_ECU_Login_NOERROR();
			if ( defined $success ) {
				$ECUMode = 'NormalDriving';
			}
			else {
				$ECUMode = 'ECUoff';
			}

			#$ecuProperties_href = PRD_Get_ECU_Properties_NOERROR( { 'Property_names' => ['ECU_status'] } );
			#$ECUMode            = $ecuProperties_href->{'ECU_status'}->{'ECU_mode'};

			S_teststep( "Switch ECU off.", 'AUTO_NBR' );
			LC_PowerDisconnect();

			S_teststep( "Wait for 'TIMER_ECU_OFF'.", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep( "Switch ECU on with correct polarity.",             'AUTO_NBR' );
			S_teststep( "Polarity of battery voltage is changed manually.", 'NO_AUTO_NBR' );
			S_user_action( "Please change battery voltage connection back to normal.\n\n" . "Confirm if connection is normal again." );

			#TSG4_lowlevel_command("ubat_UF(1,'normal')");
			LC_ECU_On($tcpar_Ubat);

			S_teststep( "Wait for 'TIMER_ECU_READY'.", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_READY');

			S_teststep( "Read and evaluate fault recorder.", 'AUTO_NBR', 'read_fault_recorder' );    #measurement 2
			S_teststep_2nd_level( "Read Bosch fault memory", 'AUTO_NBR', 'FaultMemoryBosch' );
			$fltmemBosch = LIFT_FaultMemory->read_fault_memory('Bosch');
			S_teststep_2nd_level( "Read primary fault memory", 'AUTO_NBR', 'FaultMemoryPrimary' );
			$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');

			LC_MeasureOnceGetVoltage();
		}
	}

	return 1;
}

sub TC_evaluation {

	if ( $valid_flag == 1 and $return_value == 0 and $action eq 'yes' ) {
		my $voltage_threshold_max = -$tcpar_Ubat + 0.5;
		my $voltage_threshold_min = -$tcpar_Ubat - 0.5;

		$voltage_read = sprintf( "%.2f", $voltage_read );
		S_teststep_expected( "'$voltage_threshold_min V' <= measured value <= '$voltage_threshold_max V'", 'battery_voltage' );
		S_teststep_detected( "Measured value = '$voltage_read V'", 'battery_voltage' );
		EVAL_evaluate_interval( "reverted battery voltage", $voltage_threshold_min, $voltage_threshold_max, $voltage_read );

##########
		my $current_threshold_max = -0.001;
		my $current_threshold_min = -0.100;
		$current_read = sprintf( "%.3f", $current_read );
		S_teststep_expected( "'$current_threshold_min A' <= measured value <= '$current_threshold_max A'", 'current_measurement' );
		S_teststep_detected( "Measured value = '$current_read A'", 'current_measurement' );
		EVAL_evaluate_interval( "reverted current", $current_threshold_min, $current_threshold_max, $current_read );

##########
		S_teststep_expected( 'No response', 'start_communication' );
		if ( $ECUMode ne 'NormalDriving' ) {
			S_teststep_detected( 'No response', 'start_communication' );
			S_set_verdict(VERDICT_PASS);
		}
		else {
			S_teststep_detected( 'Response received', 'start_communication' );
			S_set_verdict(VERDICT_FAIL);
		}

##########
		S_teststep_expected( 'Expected faults:', 'read_fault_recorder' );
		$fltmemBosch->evaluate_faults( {}, "FaultMemoryBosch" );
		$fltmemPrimary->evaluate_faults( {}, "FaultMemoryPrimary" );

	}

	return 1;
}

sub TC_finalization {

	if ( $valid_flag == 1 and $return_value == 0 and $action eq 'yes' ) {
		LC_ResetDVMscanner();
		LC_ECU_Off();
		S_teststep_detected("TEMP: $temperatures[0]");
		S_teststep_detected("UBat: $tcpar_Ubat V");
	}

	return 1;
}

1;
