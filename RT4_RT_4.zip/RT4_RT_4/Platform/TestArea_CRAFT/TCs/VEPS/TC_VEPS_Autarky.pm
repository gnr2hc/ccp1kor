# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_Autarky;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "test that the required functionality is working in autarky";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_Autarky

=head1 PURPOSE

test that the required functionality is working in autarky

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on
2. wait for ini end
3. switch ECU off
4. test functionality and evaluate functionality
5. switch ECU on


I<B<Evaluation>>

1. -
2. - 
3. -
4. check communication, deployment
5. -

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose'   => short description of test case 
	SCALAR 'Ubat'      => used battery voltage
	SCALAR 'function'  => tested functionality 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check function Communication in autarky'
	
	# input parameter (used for stimulation and measurement)
	Ubat=13.5
	function='Communication'
	# output parameter (used for evaluation)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat_V;
my $tcpar_function;
my $tcpar_pin_acl;
my $tcpar_source_acl;
################ global parameter declaration ###################
#add any global variables here
my ( $result, $minAutarkyTime_ms );
my $autarkyTime_ms;
my $deploy_flag;
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;
my ( $unv_file_name, $samplingFrequency_Hz, $memorySize_B, $recordingTime_ms, @squibList4Scanner );
my @temperatures;
###############################################################

sub TC_set_parameters {

	( $result, $minAutarkyTime_ms ) = SYC_POWERSUPPLY_get_MinAutarkyTime();
	return 0 unless $result;

	$tcpar_purpose    = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat_V     = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_function   = S_read_mandatory_testcase_parameter('function');
	$tcpar_pin_acl    = S_read_optional_testcase_parameter('PinACL');
	$tcpar_source_acl = S_read_optional_testcase_parameter('SourceACL');

	$samplingFrequency_Hz = 20 * 1000;

	$memorySize_B = GetTRCMemorySize( $minAutarkyTime_ms + 500, $samplingFrequency_Hz );
	$recordingTime_ms = GetTRCRecordingTime( $memorySize_B, $samplingFrequency_Hz );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	if ( $tcpar_function eq 'ElectronicFiring' ) {
		$unv_file_name = 'TC_FL_FiringPulse_Autarky_AllSquibs.txt.unv';

		my $device_data_href = PRD_Get_Device_Configuration();

		S_w2log( 1, "select a subset of squibs for evaluation (every 4th (0,4,8,12) squib of each ASIC)" );
		foreach my $squib ( keys %{ $device_data_href->{'squibs'} } ) {

			# my $squibConfig = $device_data_href->{'squibs'}{$squib}{'Configured'};
			# S_w2log( 1, "squib '$squib' is checked: '$squibConfig' " );
			next unless ( $device_data_href->{'squibs'}{$squib}{'Configured'} );

			my $deviceIndex = $device_data_href->{'squibs'}{$squib}{'Index'};

			# S_w2log( 1, "squib '$squib' with index '$deviceIndex' " );
			my $loopConfigSetting_aref = PRD_Read_Memory( "rb_sqm_SQMLoopConfigSettings_st.SQMLoopConfig_au16($deviceIndex)", { NbrOfBytes => 2 } );

			my $flicASIC    = sprintf( "%d", $$loopConfigSetting_aref[0] >> 4 );
			my $asicChannel = sprintf( "%d", $$loopConfigSetting_aref[0] & 0xF );

			# S_w2log( 1, "Flic ASIC: '$flicASIC' and ASIC Channel: '$asicChannel' ..." );

			if ( $asicChannel % 4 == 0 ) {
				push( @squibList4Scanner, $squib );
			}
		}

	}

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);

	S_teststep( "Wait for ini end", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	#   check communication function
	if ( $tcpar_function eq 'Communication' ) {
		S_teststep( "Switch ECU off", 'AUTO_NBR' );
		LC_DisconnectLine('ALL_SUPPLY+');

		S_teststep( "Test functionality during autarky", 'AUTO_NBR' );
		S_teststep_2nd_level( "Check communication during autarky", 'AUTO_NBR', 'checkCommunication' );

		my $ECUMode;
		my $time_ms;
		my $ecuProperties_href;

		S_set_timer_zero("AutarkyTimer");

		for ( my $i = 0 ; $i < 1200 ; $i++ ) {
			$ecuProperties_href = PRD_Get_ECU_Properties_NOERROR( { 'Property_names' => ['ECU_status'] } );
			$ECUMode            = $ecuProperties_href->{'ECU_status'}->{'ECU_mode'};
			$time_ms            = S_read_timer_ms("AutarkyTimer");
			$autarkyTime_ms     = $time_ms;
			if ( $ECUMode ne 'NormalDriving' ) {
				$autarkyTime_ms = $time_ms;
				last;
			}
			last if $time_ms > 60000;
		}
		S_teststep( "Switch ECU on", 'AUTO_NBR' );
		LC_ConnectLine('ALL_SUPPLY+');
		S_wait_ms('TIMER_ECU_READY');
	}

	#   check deployment function
	elsif ( $tcpar_function eq 'Deployment' ) {
		S_teststep_2nd_level( "Check deployment during autarky", 'AUTO_NBR', 'checkDeploy' );
		S_teststep_2nd_level( "The test of deployment during autarky is at the moment not supported from the test case.", 'AUTO_NBR' );
		S_set_verdict("VERDICT_NONE");

	}

	#   check electronic firing function
	elsif ( $tcpar_function eq 'ElectronicFiring' ) {

		S_teststep( "Test functionality during autarky", 'AUTO_NBR' );
		S_teststep_2nd_level( "Check electronic firing during autarky", 'AUTO_NBR' );
		S_teststep_2nd_level( "Activate plant mode 7",                  'AUTO_NBR' );
		PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );
		S_wait_ms(100);

		S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
		LC_ECU_On($tcpar_Ubat_V);
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep_2nd_level( "Set scanner and transient recorder.", 'AUTO_NBR' );
		foreach my $squib (@squibList4Scanner) {
			LC_SetTRCscanner( [ $squib . "::current" ], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
		}
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => $samplingFrequency_Hz,
				'MemorySize'        => $memorySize_B,
				'TriggerDelay'      => 0
			}
		);

		if ( defined $tcpar_pin_acl ) {
			S_teststep_2nd_level( "Send Disposal PWM on PIN '$tcpar_pin_acl'.", 'AUTO_NBR' );
			LC_ConnectLine($tcpar_pin_acl);
			LC_SendPWMDisposalStart($tcpar_pin_acl)
			  unless $tcpar_source_acl eq 'external';
		}

		S_teststep_2nd_level( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );
		S_wait_ms(100);
		PRD_Electronic_Firing_Enable();

		S_teststep_2nd_level( "Wait 2s to make sure preparation is finished.", 'AUTO_NBR' );
		S_wait_ms(2000);

		S_teststep_2nd_level( "Start transient recorder measurement.", 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();
		S_set_timer_zero('MeasureTraceAnalogSendSWTrigger');
		S_wait_ms(100);

		S_teststep_2nd_level( "Switch ECU off and wait autarky time before electronic firing.", 'AUTO_NBR' );
		LC_DisconnectLine('ALL_SUPPLY+');
		S_wait_ms($minAutarkyTime_ms);

		S_teststep_2nd_level( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
		PRD_Electronic_Firing_Fire_NOERROR();

		S_teststep_2nd_level( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
		S_wait_until_timer_ms( $recordingTime_ms, 'MeasureTraceAnalogSendSWTrigger' );

		LC_ECU_Off();    #also disconnects 'ALL_SUPPLY-' and sets the internal status

		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
		S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

		S_teststep_2nd_level( "Check number of detected firing pulses.", 'AUTO_NBR', 'firing_pulse_nbr' );

		S_teststep_2nd_level( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_Ubat_V);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep_2nd_level( 'Deactivate plant mode 7.', 'AUTO_NBR' );
		PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
		S_wait_ms(100);
	}

	#   choosen function is not supported
	else {
		S_teststep( "The test of this functionaliy '$tcpar_function' during autarky is not supported from the test case.", 'AUTO_NBR', 'wrongFunction' );
		S_set_verdict("VERDICT_INCONC");
	}

	S_teststep_2nd_level( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_function eq 'Communication' ) {
		S_teststep_expected( "Expected min autarky time for communication = $minAutarkyTime_ms ms", 'checkCommunication' );
		S_teststep_detected( "Detected autarky time for communication = $autarkyTime_ms ms", 'checkCommunication' );
		EVAL_evaluate_value( "autarky time", $autarkyTime_ms, '>', $minAutarkyTime_ms );
	}
	elsif ( $tcpar_function eq 'Deployment' ) {
		S_teststep_detected( "The test of deployment during autarky is at the moment not supported from the test case.", 'checkDeploy' );
		S_teststep_detected( "Check this functionality during your crash injection.",                                    'checkDeploy' );
		S_set_verdict("VERDICT_NONE");
	}
	elsif ( $tcpar_function eq 'ElectronicFiring' ) {
		$deploy_flag = 0;
		my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
		foreach my $squib (@squibList4Scanner) {
			my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $squib . "::CURRENT", 0.5, 0.01, 'rising' );
			$deploy_flag++ if ( $NumOfPulses > 0 );
		}

		S_teststep_expected( "fired squibs > 0", 'firing_pulse_nbr' );
		S_teststep_detected( "$deploy_flag squibs were fired", 'firing_pulse_nbr' );
		EVAL_evaluate_value( "electronic firing", $deploy_flag, '>', 0 );
	}
	else {
		S_teststep_detected( "The test of this functionaliy '$tcpar_function' during autarky is not supported from the test case.", 'wrongFunction' );
		S_set_verdict("VERDICT_INCONC");
	}

	return 1;
}

sub TC_finalization {

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

sub GetTRCMemorySize {
	my @args = @_;

	my $TRC_minRecordingTime_ms  = shift @args;
	my $TRC_samplingFrequency_Hz = shift @args;
	my $TRC_recordingTime_ms;
	my $TRC_memorySize_B;
	my @TRC_possibleMemorySizes_kB = ( 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192 );

	foreach my $TRC_memorySize_kB (@TRC_possibleMemorySizes_kB) {
		$TRC_memorySize_B = $TRC_memorySize_kB * 1024;
		$TRC_recordingTime_ms = GetTRCRecordingTime( $TRC_memorySize_B, $TRC_samplingFrequency_Hz );
		last if $TRC_minRecordingTime_ms < $TRC_recordingTime_ms;
	}

	return $TRC_memorySize_B;
}

sub GetTRCRecordingTime {
	my @args = @_;

	my $TRC_memorySize_B         = shift @args;
	my $TRC_samplingFrequency_Hz = shift @args;
	my $TRC_recordingTime_s;
	my $TRC_recordingTime_ms;

	$TRC_recordingTime_s = $TRC_memorySize_B * ( 1 / $TRC_samplingFrequency_Hz );
	$TRC_recordingTime_ms = $TRC_recordingTime_s * 1000;

	return $TRC_recordingTime_ms;
}

1;
