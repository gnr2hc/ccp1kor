# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_PowerSupplyLines;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "test that the power supply lines are functioning as expected";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_PowerSupplyLines

=head1 PURPOSE

test that the power supply lines are functioning as expected

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

one battery line:
1. switch ECU on
2. read fault recorder
3. disconnect one supply line
4. read fault recorder
5. connect supply line
6. read fault recorder
7. erase fault recorder
8. switch ECU off

two battery lines:
1. switch ECU on
2. read fault recorder
3. disconnect one supply line
4. read fault recorder
5. connect supply line
6. read fault recorder
7. disconnect second supply line
8. read fault recorder
9. connect supply line
10. read fault recorder
11. erase fault recorder
12. switch ECU off


I<B<Evaluation>>

one battery line:
1. -
2. no fault 
3. - 
4. no communication after autarky time
5. -
6. no fault
7. -
8. -

two battery lines:
1. -
2. no fault 
3. - 
4. FLTmand present
5. -
6. FLTmand stored
7. -
8. FLTmand present
9. -
10. FLTmand stored
11. - 
12. - 

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Ubat' => 
	SCALAR 'numberSupplyLines' => 
	LIST 'FLTmand' => 
	LIST 'FLTopt' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check battery voltage threshold for  <Test Heading Head>'
	
	# input parameter (used for stimulation and measurement)
	Ubat=13.5
	numberSupplyLines =1
	
	# output parameter (used for evaluation)
	FLTmand = @( )
	FLTopt = @()

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat_V;
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my ( $fltmemBosch1, $fltmemPrimary1, $fltmemBosch2, $fltmemPrimary2, $fltmemBosch3, $fltmemPrimary3, $expectedFaults_href );
################ global parameter declaration ###################
#add any global variables here
my ( $result, $numberOfSupplyLines, $minAutarkyTime_ms, @names, $PdStatus1, $PdStatus2 );
my @temperatures;

###############################################################

sub TC_set_parameters {

	( $result, $numberOfSupplyLines ) = SYC_POWERSUPPLY_get_NumberOfSupplyLines();
	( $result, $minAutarkyTime_ms )   = SYC_POWERSUPPLY_get_MinAutarkyTime();
	@names = LC_Get_names('POWER_SUPPLY_LINES');

	$tcpar_purpose = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat_V  = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmand = S_read_mandatory_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_mandatory_testcase_parameter( 'FLTopt', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault recorder", 'AUTO_NBR' );
	$fltmemBosch1   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary1 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( "Evaluate fault recorder", 'AUTO_NBR', 'evalFaultMemStart' );

	if ( $numberOfSupplyLines == 1 ) {
		S_teststep( "Disconnect supply line", 'AUTO_NBR' );
		LC_DisconnectLine( @names[0] );

		S_teststep_2nd_level( "Wait 10 * $minAutarkyTime_ms ms", 'AUTO_NBR' );
		S_wait_ms( 10 * $minAutarkyTime_ms );

		S_teststep( "Read ECU details", 'AUTO_NBR' );
		$PdStatus1 = PRD_ECU_Login_NOERROR();

		#$PdStatus1 = PRD_Get_ECU_Properties_NOERROR( { 'Property_names' => ['ECU_details'] } );
		S_teststep_2nd_level( "Evaluate production diagnosis status", 'AUTO_NBR', 'evalPdStatus1' );
	}
	elsif ( $numberOfSupplyLines == 2 ) {
		S_teststep( "Disconnect supply line one", 'AUTO_NBR' );
		LC_DisconnectLine( @names[0] );
		S_teststep_2nd_level( "Wait 3 * $minAutarkyTime_ms ms", 'AUTO_NBR' );
		S_wait_ms( 3 * $minAutarkyTime_ms );

		S_teststep( "Read ECU details", 'AUTO_NBR' );
		$PdStatus1 = PRD_Get_ECU_Properties_NOERROR( { 'Property_names' => ['ECU_details'] } );
		S_teststep_2nd_level( "Evaluate production diagnosis status", 'AUTO_NBR', 'evalPdStatus1' );

		S_teststep( "Connect supply line one", 'AUTO_NBR' );
		LC_ConnectLine( @names[0] );
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( "Read fault recorder", 'AUTO_NBR' );
		$fltmemBosch2   = LIFT_FaultMemory->read_fault_memory('Bosch');
		$fltmemPrimary2 = LIFT_FaultMemory->read_fault_memory('Primary');
		S_teststep_2nd_level( "Evaluate fault recorder", 'AUTO_NBR', 'evalFaultMem2' );

		S_teststep( "Disconnect supply line two", 'AUTO_NBR' );
		LC_DisconnectLine( @names[1] );
		S_teststep_2nd_level( "Wait 3 * $minAutarkyTime_ms ms", 'AUTO_NBR' );
		S_wait_ms( 3 * $minAutarkyTime_ms );

		S_teststep( "Read ECU details", 'AUTO_NBR' );
		$PdStatus2 = PRD_Get_ECU_Properties_NOERROR( { 'Property_names' => ['ECU_details'] } );
		S_teststep_2nd_level( "Evaluate production diagnosis status", 'AUTO_NBR', 'evalPdStatus2' );
	}
	else {
		S_teststep( "This amount of supply lines is not supported from the test case.", 'AUTO_NBR', 'wrongNumber' );
		S_set_verdict("VERDICT_INCONC");
	}

	S_teststep( "Connect all supply lines", 'AUTO_NBR' );
	foreach my $line (@names) {
		LC_ConnectLine($line);
	}
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Readt fault recorder", 'AUTO_NBR' );
	$fltmemBosch3   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary3 = LIFT_FaultMemory->read_fault_memory('Primary');
	S_teststep_2nd_level( "Evaluate fault recorder", 'AUTO_NBR', 'evalFaultMemEnd' );

	S_teststep( "Erase fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();

	return 1;
}

sub TC_evaluation {

	# evaluation of fault recorder start
	S_teststep_expected( 'Expected faults:', 'evalFaultMemStart' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch1->evaluate_faults( $expectedFaults_href, 'evalFaultMemStart' );
	$fltmemPrimary1->evaluate_faults( $expectedFaults_href, 'evalFaultMemStart' );

	# evaluation of fault recorder(s)
	if ( $numberOfSupplyLines == 1 ) {
		if ( defined $PdStatus1 ) {
			S_teststep_detected( 'ECU communication possible => not expected behaviour', 'evalPdStatus1' );
			S_set_verdict("VERDICT_FAIL");
		}
		else {
			S_teststep_detected( 'no ECU communication possible => expected behaviour', 'evalPdStatus1' );
			S_set_verdict("VERDICT_PASS");
		}
	}
	elsif ( $numberOfSupplyLines == 2 ) {
		if ( defined $PdStatus1 ) {
			S_teststep_detected( 'ECU communication possible => expected behaviour', 'evalPdStatus1' );
			S_set_verdict("VERDICT_PASS");
		}
		else {
			S_teststep_detected( 'no ECU communication possible => expected behaviour', 'evalPdStatus1' );
			S_set_verdict("VERDICT_FAIL");
		}

		S_teststep_expected( 'Expected faults:', 'evalFaultMem2' );
		foreach my $fault (@$tcpar_FLTmand) {
			S_teststep_expected($fault);
		}
		$expectedFaults_href = {
			'mandatory'   => $tcpar_FLTmand,
			'disjunction' => [],
			'optional'    => $tcpar_FLTopt,
		};

		$fltmemBosch2->evaluate_faults( $expectedFaults_href, 'evalFaultMem2' );
		$fltmemPrimary2->evaluate_faults( $expectedFaults_href, 'evalFaultMem2' );

		if ( defined $PdStatus2 ) {
			S_teststep_detected( 'ECU communication possible => expected behaviour', 'evalPdStatus2' );
			S_set_verdict("VERDICT_PASS");
		}
		else {
			S_teststep_detected( 'no ECU communication possible => expected behaviour', 'evalPdStatus2' );
			S_set_verdict("VERDICT_FAIL");
		}
	}
	else {
		S_teststep_detected( "This amount of supply lines is not supported from the test case.", 'wrongNumber' );
		S_set_verdict("VERDICT_INCONC");
	}

	# evaluation of fault recorder end
	S_teststep_expected( 'Expected faults:', 'evalFaultMemEnd' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}
	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch3->evaluate_faults( $expectedFaults_href, 'evalFaultMemEnd' );
	$fltmemPrimary3->evaluate_faults( $expectedFaults_href, 'evalFaultMemEnd' );

	return 1;
}

sub TC_finalization {

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");
	return 1;
}

1;
