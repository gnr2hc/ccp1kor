# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_VEPS_GroundMicrocutWOShort;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "test that the ECU stores a fault if a microcut in gnd line is influencing the ECU behaviour";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_VEPS_GroundMicrocutWOShort 

=head1 PURPOSE

 test that the ECU stores a fault if a microcut in gnd line is influencing the ECU behaviour

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

	Ubat
	Duration
	FLTmand
	FLTopt

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
	1. switch ECU on
	2. wait for end of initialization
	3. apply 10 microcuts with 5s waiting time between
	4. read fault recorder
	5. evaluate fault recorder
	6. reset ECU
	7. erase fault recorder
	8. switch ECU off
	
    [evaluation]
	5. check that expected fault is stored

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

	SCALAR 'Ubat'        --> battery voltage value
	SCALAR 'Duration'	 --> used duration of microcut in �s
	LIST FLTmand		 --> list of mandatory faults
	LIST FLTopt			 --> list of optional  faults
    
=head2 PARAMETER EXAMPLES

[TC_VEPS_GroundMicrocutWOShort.5_�s]
  purpose='check ground microcut for 5 �s'  
  Ubat=13.5 
  Duration=5 #�s
  FLTmand=@()
  FLTopt=@()
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_duration, $line, $fltmem, $count, $tcpar_FLTmand, $tcpar_FLTopt );
my ( $fltmemBosch, $fltmemPrimary, $expectedFaults_href );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat     = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_duration = S_read_mandatory_testcase_parameter('Duration');

	$tcpar_FLTmand = S_read_optional_testcase_parameter( 'FLTmand', 'byref' );
	$tcpar_FLTopt  = S_read_optional_testcase_parameter( 'FLTopt',  'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Apply 10 microcuts for '$tcpar_duration' �s", 'AUTO_NBR' );
	$line = S_get_contents_of_hash( [ 'TSG4', 'POWER_SUPPLY_LINES', 'PSL1_Name' ] ) . '-';
	S_w2rep("Name : $line");
	$count = 0;
	while ( $count < 10 ) {
		LC_LV124_microcut( $line, $tcpar_duration );
		S_wait_ms(5000);
		$count++;
	}

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'FLTeval' );
	$fltmemBosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmemPrimary = LIFT_FaultMemory->read_fault_memory('Primary');
	PRD_Read_Memory('rb_pomp_TestSteps_aen(0)');
	PRD_Read_Memory('rb_pomp_TestSteps_aen(1)');
	PRD_Read_Memory('rb_pom_PomFaultCounters_st.BatteryEsrFaultCounter_u8');
	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Erase fault recorder", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
###############################################################################
	S_teststep_expected( 'Expected faults:', 'FLTeval' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	$expectedFaults_href = {
		'mandatory'   => $tcpar_FLTmand,
		'disjunction' => [],
		'optional'    => $tcpar_FLTopt,
	};

	$fltmemBosch->evaluate_faults( $expectedFaults_href, 'FLTeval' );
	$fltmemPrimary->evaluate_faults( $expectedFaults_href, 'FLTeval' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# print temperature and battery voltage
	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
