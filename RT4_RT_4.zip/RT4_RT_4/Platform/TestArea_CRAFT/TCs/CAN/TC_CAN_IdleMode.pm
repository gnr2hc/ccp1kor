# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CAN_IdleMode;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_CAN
#TS version in DOORS: 5.6
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " set ECU in idle mode and check that CAN communication is possible during idle mode and after leaving idle mode ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CAN_IdleMode 

=head1 PURPOSE

 set ECU in idle mode and check that CAN communication is possible during idle mode and after leaving idle mode

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
    switch ECU on
    wait for ini end
    read fault recorder
    set ECU in idle mode
    read fault recorder / read label
    set ECU in normal mode
    read fault recorder
    erase fault recorder
    switch ECU off

    [evaluation]
    check fault recorder 
    check fault recorder during idle mode
    check fault recorder
    send mail if not

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    
=head2 PARAMETER EXAMPLES

    [TC_FR_PowerDownBehaviour.Test]
    purpose = 'check that the fault information is stored correct during autarky'
    Ubat=12.4
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmemBosch1,     $fltmemBosch2,     $fltmemBosch3 );
my ( $actSysMode1_aref, $actSysMode2_aref, $actSysMode3_aref );
my $actSysModeLabel = 'rb_bswm_ActualSystemMode_au16(0)';
my $IdleModeLabel1  = 'rb_bswm_IdleModeData_dfst(0)';
my $IdleModeLabel2  = 'rb_bswm_IdleModeData_dfst(1)';
my $IdleModeLabel3  = 'rb_bswm_IdleModeData_dfst(2)';
my $IdleModeLabel4  = 'rb_bswm_IdleModeData_dfst(3)';
my $valueNormalMode = 0x05;
my $valueIdleMode   = 0x04;
my ( $tcpar_ubat, $tcpar_FLTmand );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmand = GEN_Read_optional_testcase_parameter( 'FLTmand', 'byref' );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'switch ECU on', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	PD_ECUlogin();
	$fltmemBosch1 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep( 'Evaluate Bosch fault memory', 'AUTO_NBR', 'FLT_read_1' );

	S_teststep( 'Read actual system mode', 'AUTO_NBR' );
	$actSysMode1_aref = PD_ReadMemoryByName($actSysModeLabel);

	S_teststep( 'set ECU in idle mode', 'AUTO_NBR' );
	PD_WriteMemoryByName( $IdleModeLabel1, [0xFF] );
	PD_WriteMemoryByName( $IdleModeLabel2, [0xFF] );
	PD_WriteMemoryByName( $IdleModeLabel3, [0x5A] );
	PD_WriteMemoryByName( $IdleModeLabel4, [0x5A] );

	S_teststep( 'reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	PD_ECUlogin();
	$fltmemBosch2 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep( 'Evaluate Bosch fault memory', 'AUTO_NBR', 'FLT_read_2' );

	S_teststep( 'Read actual system mode', 'AUTO_NBR' );
	$actSysMode2_aref = PD_ReadMemoryByName($actSysModeLabel);

	S_teststep( 'set ECU in normal mode', 'AUTO_NBR' );
	PD_WriteMemoryByName( $IdleModeLabel1, [0xFF] );
	PD_WriteMemoryByName( $IdleModeLabel2, [0xFF] );
	PD_WriteMemoryByName( $IdleModeLabel3, [0xFF] );
	PD_WriteMemoryByName( $IdleModeLabel4, [0xFF] );

	S_teststep( 'reset ECU', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	PD_ECUlogin();
	$fltmemBosch3 = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
	S_teststep( 'Evaluate Bosch fault memory', 'AUTO_NBR', 'FLT_read_3' );

	S_teststep( 'Read actual system mode', 'AUTO_NBR' );
	$actSysMode3_aref = PD_ReadMemoryByName($actSysModeLabel);

	S_teststep( 'switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my $dec_value;

	S_teststep_expected( 'Expected faults:', 'FLT_read_1' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FLT_read_1' );
	foreach my $fault ( @{ $fltmemBosch1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmemBosch1, $tcpar_FLTmand );

	$dec_value = S_aref2dec( $actSysMode1_aref, 'U16' );
	EVAL_evaluate_value( "ActualSystemMode", $dec_value, '==', $valueNormalMode );

	S_teststep_expected( 'Expected faults:', 'FLT_read_2' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FLT_read_2' );
	foreach my $fault ( @{ $fltmemBosch2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmemBosch2, $tcpar_FLTmand );

	$dec_value = S_aref2dec( $actSysMode2_aref, 'U16' );
	EVAL_evaluate_value( "ActualSystemMode", $dec_value, '==', $valueIdleMode );

	S_teststep_expected( 'Expected faults:', 'FLT_read_3' );
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'FLT_read_3' );
	foreach my $fault ( @{ $fltmemBosch3->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmemBosch3, $tcpar_FLTmand );

	$dec_value = S_aref2dec( $actSysMode3_aref, 'U16' );
	EVAL_evaluate_value( "ActualSystemMode", $dec_value, '==', $valueNormalMode );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	PD_ECUlogin();
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
