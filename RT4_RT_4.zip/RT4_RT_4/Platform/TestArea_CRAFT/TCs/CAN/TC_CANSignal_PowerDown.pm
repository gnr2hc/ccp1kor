# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CANSignal_PowerDown;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_CAN
#TS version in DOORS: 5.6
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_can_access;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;

#include further modules here
##################################

our $PURPOSE = "measure when CAN messages stop after power off (with or without communication)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CANSignal_PowerDown

=head1 PURPOSE

measure when CAN messages stop after power off (with or without communication)

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on

2. read fault recorder

3. set transient recorder

4. set communication (continue or stop)

5. switch ECU off

6. measure signal

7. evaluate signal


I<B<Evaluation>>

1. -

2. no fault 

3. - 

4. -

5. -

6. -

7. signal is in given limits


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'communication' => 
	SCALAR 'Ubat' => 
	SCALAR 'purpose' => 
	SCALAR 'CANLevel' => 


=head2 PARAMETER EXAMPLES

	# description of test case
	purpose='check <Test Heading Head> signal during <Test Heading Tail>' 
	
	
	# input parameter (used for stimulation and measurement)
	
	# output parameter (used for evaluation)
	# CAN bus is in recessive mode
	CANLevel=200 #mV
	communication='yes'
	Ubat=0 #V

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_CANLevel;
my $tcpar_communication;
my $tcpar_Ubat;
my $tcpar_pin;
my $unv_file_name;
my @temperatures;
my $i;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {
	$tcpar_Ubat          = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_CANLevel      = GEN_Read_mandatory_testcase_parameter('CANLevel');
	$tcpar_communication = GEN_Read_mandatory_testcase_parameter('communication');
	$tcpar_pin           = GEN_Read_mandatory_testcase_parameter('Pin');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 7, 'SlopeType' => 'negative' } );
	LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );

	#	LC_SetTRCscanner( ['CANFR1'], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 64 * 1024, 'TriggerDelay' => -5 } );

	S_teststep( "Switch ECU on.", 'AUTO_NBR' );
	LC_ECU_On();

	S_teststep( "Wait 5000ms.", 'AUTO_NBR' );
	S_wait_ms(5000);

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( "Wait 2000ms.", 'AUTO_NBR' );
	S_wait_ms(2000);

	S_teststep( "Stop CAN bus simulation", 'AUTO_NBR' );
	CA_simulation_stop_NOERROR();

	if ( $tcpar_Ubat > 0 ) {
		S_teststep( "Set Ubat = 'U_BATT_UNDERVOLTAGE'.", 'AUTO_NBR' );
		LC_SetVoltage('U_BATT_UNDERVOLTAGE');
		LC_MeasureTraceAnalogSendSWTrigger();
	}
	else {
		S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
		LC_DisconnectLine('ALL_SUPPLY+');
	}

	if ( $tcpar_communication eq 'yes' ) {
		S_teststep( "Read 5 times a label", 'AUTO_NBR' );
		for ( $i = 0 ; $i < 5 ; $i++ ) {

			#PD_ReadMemoryByName('rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16');
			PRD_Read_Memory_NOERROR('rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16');
			S_wait_ms(50);
		}
	}

	S_teststep( "Wait until transient recorder measurement is finished (10s).", 'AUTO_NBR' );
	S_wait_ms(10000);

	LC_ECU_Off();

	S_teststep( "Start CAN bus simulation", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep( "Store measurement data for later evaluation", 'AUTO_NBR' );
	$unv_file_name = S_get_TC_number() . '_TRC_Trace_CAN_Signal_PowerDown.txt.unv';
	LC_MeasureTraceAnalogPlotValues( $main::REPORT_PATH . "\\" . $unv_file_name );
	S_w2rep( '<A HREF="./' . $unv_file_name . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate measured signal.", 'AUTO_NBR', 'evaluate_signal' );
	return 1;
}
#### EVALUATE TC #####
sub TC_evaluation {

	S_set_verdict(VERDICT_FAIL);

	S_teststep_expected( "signal is in given limits", 'evaluate_signal' );    #evaluation 2
	S_teststep_detected( "<<add detected result here>>", 'evaluate_signal' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	if ( $tcpar_Ubat > 0 ) {
		LC_SetVoltage('U_BATT_DEFAULT');
	}
	else {
		LC_ConnectLine('ALL_SUPPLY+');
	}
	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );

	return 1;
}
1;

__END__
	
	
