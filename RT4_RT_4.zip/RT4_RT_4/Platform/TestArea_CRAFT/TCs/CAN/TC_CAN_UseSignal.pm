# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CAN_UseSignal;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_CAN
#TS version in DOORS: 5.6
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use LIFT_can_access;

##################################

our $PURPOSE = "check that the signals on CAN bus are used as long as valid values are received";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CAN_UseSignal

=head1 PURPOSE

check that the signals on CAN bus are used as long as valid values are received

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_UbatStart_V, $tcpar_UbatStop_V, $tcpar_UbatStep_V, $tcpar_Label, $tcpar_CanSignal );
my ( $tcpar_CanValueList_aref, $tcpar_LabelValueList_aref );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my ( $setValue, $expectedValue );
my ($tracefilename);
my ($data_HoH);

###############################################################

sub TC_set_parameters {

	$tcpar_UbatStart_V         = S_read_mandatory_testcase_parameter('UbatStart');
	$tcpar_UbatStop_V          = S_read_mandatory_testcase_parameter('UbatStop');
	$tcpar_UbatStep_V          = S_read_mandatory_testcase_parameter('UbatStep');
	$tcpar_Label               = S_read_mandatory_testcase_parameter('Label');
	$tcpar_CanSignal           = S_read_mandatory_testcase_parameter('CANSignal');
	$tcpar_CanValueList_aref   = S_read_mandatory_testcase_parameter( 'CANValueList', 'byref' );
	$tcpar_LabelValueList_aref = S_read_mandatory_testcase_parameter( 'LabelValueList', 'byref' );

	return 1;
}

sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	my $type = 0;

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set battery voltage to Ubat = $tcpar_UbatStart_V V", 'AUTO_NBR' );
	LC_SetVoltage($tcpar_UbatStart_V);

	for ( my $ubat = $tcpar_UbatStart_V - $tcpar_UbatStep_V ; $ubat > $tcpar_UbatStop_V ; $ubat = $ubat - $tcpar_UbatStep_V ) {
		S_teststep( "Get values for this loop", 'AUTO_NBR' );
		$setValue      = shift(@$tcpar_CanValueList_aref);
		$expectedValue = shift(@$tcpar_LabelValueList_aref);

		push( @$tcpar_CanValueList_aref,   $setValue );
		push( @$tcpar_LabelValueList_aref, $expectedValue );
		$type++;

		S_teststep_2nd_level( "Set CAN message '$tcpar_CanSignal' to value $setValue", 'AUTO_NBR' );
		CA_write_can_signal( $tcpar_CanSignal, $setValue );

		S_teststep_2nd_level( "Start fast diagnosis for label '$tcpar_Label'", 'AUTO_NBR' );
		$tracefilename = $main::REPORT_PATH . "/Loop_$type";
		PD_StartFastDiagName( $tracefilename, [$tcpar_Label], [ uc( PD_get_type_from_name($tcpar_Label) ) ] );

		S_wait_ms(1000);

		S_teststep_2nd_level( "Set battery voltage to Ubat = $ubat V", 'AUTO_NBR' );
		LC_SetVoltage($ubat);

		S_wait_ms(1000);

		S_teststep_2nd_level( "Stop fast diagnosis and get trace", 'AUTO_NBR' );
		PD_StopFastDiag();

		$data_HoH = PD_get_FDtrace($tracefilename);
		PD_plot_FDtrace( $data_HoH, $tracefilename );
		S_add_pic2html( $tracefilename . ".png", '', $tracefilename . ".unv", 'TYPE="text/unv"' );

		S_teststep_2nd_level( "Compare expected and measured value for CAN value '$setValue", 'AUTO_NBR' );
		S_teststep_expected(" Value == $expectedValue ");
		EVAL_evaluate_value_over_time( $data_HoH, $tcpar_Label, '==', $expectedValue );
	}

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation is done", 'AUTO_NBR' );

	return 1;
}

sub TC_finalization {

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	LC_ECU_Off();

	S_teststep_detected(" TEMP : $temperatures[0] ");

	return 1;
}

1;
