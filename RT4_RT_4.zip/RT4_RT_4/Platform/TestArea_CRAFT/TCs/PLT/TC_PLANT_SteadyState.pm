# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_SteadyState;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Vehicle_ECU_Power_Supply
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;

#use FuncLib_SYC_INTERFACE;
#################################

our $PURPOSE = " check that the ECU fulfills all requirements for steady state ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_SteadyState

=head1 PURPOSE

check that the ECU fulfills all requirements for steady state

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. switch ECU on

2. measure current consumption

3. evaluate current consumption

4. switch ECU off


I<B<Evaluation>>

1. -

2. - 

3. check measured current

4. -

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose'            => short test case description
	SCALAR 'Ubat_V'             => used battery voltage
	SCALAR 'PermanentCurrent_A' => expected current consumption in A


=head2 PARAMETER EXAMPLES

	# description of test case
    purpose='check Steady State Behaviour' 
	
	# input parameter (used for stimulation and measurement)
    Ubat_V=13.5 # V
	
	# output parameter (used for evaluation)
    PermanentCurrent_A=3.2 # A

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_PermanentCurrent_A;
my $tcpar_Ubat_V;

################ global parameter declaration ###################
my $unv_file_name;
my $toleranceCurrent = 5;    # %
my @temperatures     = ();

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_PermanentCurrent_A = S_read_mandatory_testcase_parameter('PermanentCurrent_A');
	$tcpar_Ubat_V             = S_read_mandatory_testcase_parameter('Ubat');
	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);

	S_teststep( "Wait for ini end", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Prepare measurement of current consumption", 'AUTO_NBR' );

	S_teststep_2nd_level( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBSense'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_SetTRCscanner( ['UBAT1_I'], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 128 * 1024, 'TriggerDelay' => 0 } );

	S_teststep_2nd_level( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	S_wait_ms(200);
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep_2nd_level( "Wait for measurement finished", 'AUTO_NBR' );
	S_wait_ms(7000);
	LC_MeasureTraceAnalogStop();

	S_teststep_2nd_level( "Evaluate current consumption", 'AUTO_NBR', 'measure_current_consumption' );
	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

sub TC_evaluation {

	# evaluation of current consumption
	my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
	my ( $VALUES_AREF, $TIMES_AREF ) = EVAL_get_values_and_times_over_time( $data_HoH, "UBAT1_I" );

	my $squareamplitude;
	my $avg_current_A;
	my $measured_I_A;

	foreach my $datapoint (@$VALUES_AREF) { $squareamplitude += ( $datapoint * $datapoint ); }

	$squareamplitude /= scalar(@$VALUES_AREF);
	$avg_current_A = sqrt($squareamplitude);
	$measured_I_A = sprintf( "%.2f", $avg_current_A );

	S_teststep_expected( "current = $tcpar_PermanentCurrent_A A", 'measure_current_consumption' );
	S_teststep_detected( "current = $measured_I_A A", 'measure_current_consumption' );
	EVAL_evaluate_value( "current", $measured_I_A, '<', $tcpar_PermanentCurrent_A, $toleranceCurrent, 'relative' );

	return 1;
}

sub TC_finalization {

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");
	return 1;
}

1;
