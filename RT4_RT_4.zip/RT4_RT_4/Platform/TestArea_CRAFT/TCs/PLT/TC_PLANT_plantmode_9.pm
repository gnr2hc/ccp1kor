# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_plantmode_9;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check plant mode 9: AIO and AIN test mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_9

=head1 PURPOSE

check plant mode 9: AIO and AIN test mode

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>

    AIN1_5_9  will be set to 100 Ohm
    AIN2_6_10 will be set to Hall low (3 mA)
    AIN3_7_11 will be set to 400 Ohm
    AIN4_8_12 will be set to Hall high (14mA)

I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


	[TC_PLANT_plantmode_9.RefType3]
	purpose     = 'AIxTestMode RefType3'
	AIN1_5_9    = @( 'BLRP',  'SPSFD', 'BLRD' )
	AIN2_6_10   = @( 'PADS1', 'OPSFP', 'BLFP' )
	AIN3_7_11   = @( 'BLRC',  'BLFD' )
	AIN4_8_12   = @( 'PADS2', 'BLR2D' )
	
	[TC_PLANT_plantmode_9.DevBoard]
	purpose     = 'AIxTestMode DevBoard'
	AIN1_5_9    = @( 'BLRP', 'BLFP', 'SPSFD' )
	AIN2_6_10   = @( 'PADS1', 'OPSFP', 'BLFD' )
	AIN3_7_11   = @( 'BLRC', 'BLR2D' )
	AIN4_8_12   = @( 'PADS2', 'BLRD' )


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_AIN1_5_9,          $tcpar_AIN2_6_10,        $tcpar_AIN3_7_11,       $tcpar_AIN4_8_12 );
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ( $tcpar_Ubat_V,            $tcpar_COName );

################ global parameter declaration ###################
#add any global variables here
my @deviceNames;
my @temperatures;
my ( $unv_file_name1, $unv_file_name2 );
my $plantmode9_set  = 0b00000001;
my $plantmode_clear = 0b00000000;
my ( $data_aref1, $data_aref2 );
my ( $data_href1, $data_href2 );
my ( $fltmem1,    $fltmem2 );
my ( $data_HoH,   $aout, $foundFreq_Hz );
my $freq_mode_inactive;
my $freq_mode_active = 20;

###############################################################

sub TC_set_parameters {

	$tcpar_AIN1_5_9          = S_read_mandatory_testcase_parameter('AIN1_5_9');
	$tcpar_AIN2_6_10         = S_read_mandatory_testcase_parameter('AIN2_6_10');
	$tcpar_AIN3_7_11         = S_read_mandatory_testcase_parameter('AIN3_7_11');
	$tcpar_AIN4_8_12         = S_read_mandatory_testcase_parameter('AIN4_8_12');
	$tcpar_COName            = S_read_optional_testcase_parameter('CrashOutputName');
	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_FLTmandPMInactive = S_read_mandatory_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_mandatory_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	if ( defined $tcpar_COName ) {
		$freq_mode_inactive = S_read_mandatory_testcase_parameter('CrashOutputFrequency');
	}

	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'", 114 ) unless ( defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'} );
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'",    114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'} );
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'",  114 ) unless ( defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'} );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( defined $tcpar_COName ) {
		S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
		LC_SetTRCscanner( $tcpar_COName, { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 20 * 1000,
				'MemorySize'        => 64 * 1024,
				'TriggerDelay'      => 0
			}
		);
	}

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(1)');
	$data_href1 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_teststep( "Set all AIN to plant mode equipment", 'AUTO_NBR' );
	foreach my $ain (@$tcpar_AIN1_5_9) {
		LC_SetResistance( $ain, 100 );
	}
	foreach my $ain (@$tcpar_AIN2_6_10) {
		LC_SetCurrent( $ain, 3 );
	}
	foreach my $ain (@$tcpar_AIN3_7_11) {
		LC_SetResistance( $ain, 400 );
	}
	foreach my $ain (@$tcpar_AIN4_8_12) {
		LC_SetCurrent( $ain, 14 );
	}

	if ( defined $tcpar_COName ) {
		S_teststep( "Start transient recorder measurement.", 'AUTO_NBR', 'signal_mode_inactive' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_teststep_2nd_level( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
		S_wait_ms(5000);
		LC_MeasureTraceAnalogStop();
		$unv_file_name1 = 'TC_PlantMode_9_AIN_AOUT_Test_not_active.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name1 );
		S_w2rep( '<A HREF="./' . "$unv_file_name1" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name1" . '</A><br>' );
	}

	S_teststep( "Check if faults qualified due to plant mode setting", 'AUTO_NBR', 'checkFaultPMInactive' );
	S_wait_ms(500);
	$fltmem1 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode9_set] );

	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );
	$data_aref2 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(1)');
	$data_href2 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	if ( defined $tcpar_COName ) {
		S_teststep( "Send AIO test pattern", 'AUTO_NBR' );
		PRD_Activate_AIO_Test_Pattern();

		S_teststep( "Start transient recorder measurement.", 'AUTO_NBR', 'signal_mode_active' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_teststep_2nd_level( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
		S_wait_ms(5000);
		LC_MeasureTraceAnalogStop();
		$unv_file_name2 = 'TC_PlantMode_9_AIN_AOUT_Test_active.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name2 );
		S_w2rep( '<A HREF="./' . "$unv_file_name2" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name2" . '</A><br>' );
	}

	S_teststep( "Check if no faults qualify due to plant mode settings", 'AUTO_NBR', 'checkFaultPMActive' );
	$fltmem2 = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2 );

	# plant mode not active
	S_teststep_expected( "Plant mode 9 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 9 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 9 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off", 'mode_inactive' );
	S_teststep_detected( "WL is $detectedWarningIndicatorState", 'mode_inactive' );
	if    ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                                      { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	if ( defined $tcpar_COName ) {
		$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name1 );
		foreach my $aout ($tcpar_COName) {
			$foundFreq_Hz = EVAL_calc_signal_frequence( $data_HoH, 'CRO1', 0, 3000000, 5 );
			$foundFreq_Hz = sprintf( "%.2f", 1000 * 1000 * $foundFreq_Hz );
			S_teststep_expected( "Expected signal frequency: $freq_mode_inactive Hz", 'signal_mode_inactive' );
			S_teststep_detected( "Detected signal frequency: $foundFreq_Hz Hz", 'signal_mode_inactive' );
			EVAL_evaluate_value( "Signal frequency", $foundFreq_Hz, '==', $freq_mode_inactive, 2, 'relative' );
		}
	}

	S_teststep_expected( 'Expected faults:', 'checkFaultPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}
	my $expected_faults_href1 = { 'mandatory' => $tcpar_FLTmandPMInactive, };
	$fltmem1->evaluate_faults( $expected_faults_href1, "checkFaultPMInactive" );

	# plant mode active
	S_teststep_expected( "Plant mode 9 == $plantmode9_set", 'mode_active' );
	S_teststep_detected( "Plant mode 9 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 9 active", $$data_aref2[0], '==', $plantmode9_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                                      { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	if ( defined $tcpar_COName ) {
		$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name2 );
		foreach my $aout ($tcpar_COName) {
			$foundFreq_Hz = EVAL_calc_signal_frequence( $data_HoH, 'CRO1', 0, 3000000, 5 );
			$foundFreq_Hz = sprintf( "%.2f", 1000 * 1000 * $foundFreq_Hz );
			S_teststep_expected( "Expected signal frequency: $freq_mode_active Hz", 'signal_mode_active' );
			S_teststep_detected( "Detected signal frequency: $foundFreq_Hz Hz", 'signal_mode_active' );
			EVAL_evaluate_value( "Signal frequency", $foundFreq_Hz, '==', $freq_mode_active, 2, 'relative' );
		}
	}

	S_teststep_expected( 'Expected faults:', 'checkFaultPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}
	my $expected_faults_href2 = {};
	$fltmem2->evaluate_faults( $expected_faults_href2, "checkFaultPMActive" );
	return 1;
}

sub TC_finalization {

	S_teststep( "Set devices to default state", 'AUTO_NBR' );
	@deviceNames = LC_Get_names('BELT_LOCKS');
	foreach my $device (@deviceNames) {
		LC_SetLogicalState( $device, 'DEFAULT' );
	}

	if ( defined $tcpar_COName ) {
		S_teststep( "Reset TRC scanner", 'AUTO_NBR' );
		LC_ResetTRCscanner();
	}

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
