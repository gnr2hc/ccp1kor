# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_plantmode_7_EMCCapTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;

#use PD;

use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "test plant mode 7: EMC capacitor test for squibs (semi-automated)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_7_EMCCapTest

=head1 PURPOSE

test plant mode 7: EMC capacitor test for squibs (semi-automated)

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ( $tcpar_Ubat_V, $result, $tcpar_Pin );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;
my $timePrepare_ms  = 2500;
my $data_aref;
my ( $data_aref1, $data_aref2 );
my ( $data_href1, $data_href2 );
my ( $fltmem1,    $fltmem2 );

###############################################################

sub TC_set_parameters {
	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_Pin               = S_read_mandatory_testcase_parameter('Pin');
	$tcpar_FLTmandPMInactive = S_read_mandatory_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_mandatory_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href1 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_teststep( "Connect 100nF capacitor between pin '$tcpar_Pin' and gnd", 'AUTO_NBR' );
	S_user_action("Connect 100nF capacitor between pin '$tcpar_Pin' and gnd.\nConfirm popup when capacitor is connected");
	S_wait_ms(500);

	S_teststep( "Check that no fault is qualified", 'AUTO_NBR', 'checkFaultPMInactive' );
	$fltmem1 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Reset ECU and erase fault recorder", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );

	S_teststep( "Do reset", 'AUTO_NBR' );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );

	$data_aref2 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href2 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	S_wait_ms(500);

	S_teststep( "Check that fault according to plant mode is qualified", 'AUTO_NBR', 'checkFaultPMActive' );
	$fltmem2 = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Disconnect 100nF capacitor between pin '$tcpar_Pin' and gnd", 'AUTO_NBR' );
	S_user_action("Disconnect 100nF capacitor between pin '$tcpar_Pin' and gnd.\nConfirm popup when capacitor is disconnected");

	return 1;
}

sub TC_evaluation {
	my ( $lampStatus1, $lampStatus2 );

	S_teststep_expected( "Plant mode 7 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 7 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 7 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'Lamp_status'}->{'SystemWarningLamp'}", 'mode_inactive' );
	if    ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                                      { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMInactive' );
	foreach my $fault (@$tcpar_FLTmandPMInactive) {
		S_teststep_expected($fault);
	}

	my $expected_faults_href1 = {

		'mandatory' => $tcpar_FLTmandPMInactive,
		'optional'  => $tcpar_FLToptPMInactive,
	};
	$fltmem1->evaluate_faults( $expected_faults_href1, "checkFaultPMInactive" );

	S_teststep_expected( "Plant mode 7 == $plantmode7_set", 'mode_active' );
	S_teststep_detected( "Plant mode 7 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 7 active", $$data_aref2[0], '==', $plantmode7_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                                      { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}

	my $expected_faults_href2 = {

		'mandatory' => $tcpar_FLTmandPMActive,
		'optional'  => $tcpar_FLToptPMActive,
	};
	$fltmem2->evaluate_faults( $expected_faults_href2, "checkFaultPMActive" );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	$data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	PRD_Clear_Fault_Memory();
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
