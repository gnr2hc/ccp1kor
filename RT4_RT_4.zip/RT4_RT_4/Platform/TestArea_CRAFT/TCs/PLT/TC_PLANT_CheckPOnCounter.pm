# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_CheckPOnCounter;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;

#use LIFT_functional_layer;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that the power on counter in NvM is incremented after 1.5sec after power on when at least on plant mode is active ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_CheckPOnCounter 

=head1 PURPOSE

 check that the power on counter in NvM is incremented after 1.5sec after power on when at least on plant mode is active

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    LabelPoCRAM
    LabelPoCNVM

    [initialisation]
    get temperature
    switch ECU on with U_BATT_DEFAULT
    clear fault memory

    [stimulation & measurement]
	 1. switch ECU on - plant mode inactive
	 2. start fast diagnosis in next power on cycle
	 3. reset ECU
	 4. wait for end of initialization
	 5. stop fast diagnosis
	 6. evaluate fast diagnosis trace
	 7. activate one plant mode
	 8. reset ECU
	 9. start fast diagnosis in next power on cycle
	10. reset ECU
	11. wait for end of initialization
	12. stop fast diagnosis
	13. evaluate fast diagnosis trace
	14. deactivate plant mode

    [evaluation]
	 1. -
	 2. -
	 3. -
	 4. -
	 5. -
	 6. check time when power on counter is updated
	 7. -
	 8. -
	 9. -
	10. -
	11. -
	12. -
	13. check time when power on counter is updated
	14. -

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'LabelPoCRAM' --> label which contains power on counter in RAM
    SCALAR 'LabelPoCNVM  --> label which contains power on counter in NVM
    
=head2 PARAMETER EXAMPLES

    [TC_PLANT_CheckPOnCounter.ECU]
	purpose = 'check power on counter update with ECU'
	Ubat=13.5
	LabelPoCRAM = 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32'
	LabelPoCNVM = 'rb_tim_EcuOnTimeDataEe_dfst.POnCounter_u32'
	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ######################
my ( $tcpar_Ubat_V, $tcpar_labelPoC_RAM, $tcpar_labelPoC_NVM );
################ Parameters from syc ############################

################ global parameter declaration ###################
my $plantmode5_set  = 0b00010000;
my $plantmode_clear = 0b00000000;

my ( $data_aref1,    $data_aref2 );
my ( $data_href1,    $data_href2 );
my ( $fdData1_href,  $fdData2_href );
my ( $valuePoC1_PMI, $valuePoC2_PMI, $valuePoC3_PMI, $valuePoC4_PMI );
my ( $valuePoC1_PMA, $valuePoC2_PMA, $valuePoC3_PMA, $valuePoC4_PMA );

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat_V       = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_labelPoC_RAM = GEN_Read_mandatory_testcase_parameter('LabelPoCRAM');
	$tcpar_labelPoC_NVM = GEN_Read_mandatory_testcase_parameter('LabelPoCNVM');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	my ( $data1_path, $data2_path );
	my $fastDiagConfig_href = {
		labels            => [$tcpar_labelPoC_RAM],
		is_next_POC       => 1,
		number_of_BUS_Ids => 1,
	};

	# 1. switch ECU on - no plant mode active
	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	# PRD_Write_Memory( $tcpar_labelPoC_RAM, 5 );
	# PRD_Write_Memory( $tcpar_labelPoC_NVM, 5 );

	S_teststep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
	$data_aref1 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href1 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	# 3. reset ECU and 4. wait for end of init phase
	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms(1800);

	S_teststep( "Read power on counter 1.8s after power on", 'AUTO_NBR', 'value1PMInactive' );
	$valuePoC1_PMI = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC1_PMI'\n", 'green' );

	S_teststep( "Read power on counter after 10s", 'AUTO_NBR' );
	S_wait_ms(10000);
	$valuePoC2_PMI = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC2_PMI'\n", 'green' );

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms(1800);

	S_teststep( "Read power on counter 1.8s after power on", 'AUTO_NBR', 'value2PMInactive' );
	$valuePoC3_PMI = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC3_PMI'\n", 'green' );

	S_teststep( "Read power on counter after 10s", 'AUTO_NBR' );
	S_wait_ms(10000);
	$valuePoC4_PMI = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC4_PMI'\n", 'green' );

	# 7. activate one plant mode
	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode5_set] );

	# 8. reset ECU
	S_teststep( "Do SW reset", 'AUTO_NBR' );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Write_Memory( $tcpar_labelPoC_RAM, 0 );
	PRD_Write_Memory( $tcpar_labelPoC_NVM, 0 );

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );
	$data_aref2 = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	$data_href2 = PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

	# 10. reset ECU and 11. wait for end of initialization
	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms(1800);

	S_teststep( "Read power on counter 1.8s after power on", 'AUTO_NBR', 'value1PMActive' );
	$valuePoC1_PMA = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC1_PMA'\n", 'green' );

	S_teststep( "Read power on counter after 10s", 'AUTO_NBR' );
	S_wait_ms(10000);
	$valuePoC2_PMA = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC2_PMA'\n", 'green' );

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms(1800);

	S_teststep( "Read power on counter 1.8s after power on", 'AUTO_NBR', 'value2PMActive' );
	$valuePoC3_PMA = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC3_PMA'\n", 'green' );

	S_teststep( "Read power on counter after 10s", 'AUTO_NBR' );
	S_wait_ms(10000);
	$valuePoC4_PMA = PRD_Read_Memory( $tcpar_labelPoC_NVM, { memoryContentsAsInteger => 1 } );
	S_w2rep( " power on counter NVM: '$valuePoC4_PMA'\n", 'green' );

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $lampStatus1, $lampStatus2 );

	S_teststep_expected( "Plant mode 5 == 0", 'mode_inactive' );
	S_teststep_detected( "Plant mode 5 is $$data_aref1[0]", 'mode_inactive' );
	EVAL_evaluate_value( "Plant mode 5 inactive", $$data_aref1[0], '==', 0 );

	S_teststep_expected( "WL == Off", 'mode_inactive' );
	S_teststep_detected( "WL is $data_href1->{'Lamp_status'}->{'SystemWarningLamp'}", 'mode_inactive' );
	if    ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus1 = 'Off'; }
	elsif ( $data_href1->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus1 = 'On'; }
	else                                                                      { $lampStatus1 = 'Error'; }
	EVAL_evaluate_string( "WL inactive", 'Off', $lampStatus1 );

	S_teststep_detected( "Power on counter after 1.8s: $valuePoC1_PMI", 'value1PMInactive' );
	S_teststep_detected( "Power on counter after 10s : $valuePoC2_PMI", 'value1PMInactive' );
	EVAL_evaluate_value( "Power on counter ", $valuePoC2_PMI, '==', $valuePoC1_PMI );

	S_teststep_detected( "Power on counter after 1.8s: $valuePoC3_PMI", 'value2PMInactive' );
	S_teststep_detected( "Power on counter after 10s : $valuePoC4_PMI", 'value2PMInactive' );
	EVAL_evaluate_value( "Power on counter ", $valuePoC4_PMI, '==', $valuePoC3_PMI );

	S_teststep_expected("Power on counter is updated after ECU reset.");
	EVAL_evaluate_value( "Power on counter update", $valuePoC3_PMI, '==', $valuePoC1_PMI + 1 );

	#	S_teststep_expected( 'diagnosis service status: no response', 'requestPMInactive' );
	#	$status1 = $response_href1->{'Status'};
	#	S_teststep_detected( "diagnosis service status: $status1", 'responsePMInactive' );
	#	EVAL_evaluate_value( "diagnosis service status", $status1, '>=', 0 );
	#
	#	S_teststep_expected( 'diagnosis service: NRC 0x22', 'responsePMInactive' );
	#	$content1 = '0x' . sprintf( "%X", $response_href1->{'CompletePdMsg'}->[3] );
	#	S_teststep_detected( "diagnosis service: $content1", 'responsePMInactive' );
	#	EVAL_evaluate_string( 'diagnosis service', '0x22', $content1 );

	S_teststep_expected( "Plant mode 5 == $plantmode5_set", 'mode_active' );
	S_teststep_detected( "Plant mode 5 is $$data_aref2[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 5 active", $$data_aref2[0], '==', $plantmode5_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_href2->{'Lamp_status'}->{'SystemWarningLamp'}" . "\n", 'mode_active' );
	if    ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*off/i ) { $lampStatus2 = 'Off'; }
	elsif ( $data_href2->{'Lamp_status'}->{'SystemWarningLamp'} =~ /.*on/i )  { $lampStatus2 = 'On'; }
	else                                                                      { $lampStatus2 = 'Error'; }
	EVAL_evaluate_string( "WL active", 'On', $lampStatus2 );

	S_teststep_detected( "Power on counter after 1.8s: $valuePoC1_PMA", 'value1PMActive' );
	S_teststep_detected( "Power on counter after 10s : $valuePoC2_PMA", 'value1PMActive' );
	EVAL_evaluate_value( "Power on counter ", $valuePoC2_PMA, '==', $valuePoC1_PMA );

	S_teststep_detected( "Power on counter after 1.8s: $valuePoC3_PMA", 'value2PMActive' );
	S_teststep_detected( "Power on counter after 10s : $valuePoC4_PMA", 'value2PMActive' );
	EVAL_evaluate_value( "Power on counter ", $valuePoC4_PMA, '==', $valuePoC3_PMA );

	S_teststep_expected("Power on counter is updated after ECU reset.");
	EVAL_evaluate_value( "Power on counter update", $valuePoC3_PMA, '==', $valuePoC1_PMA + 1 );

	return 1;
}
#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	my $data_aref;

	# 14. deactivate plant mode
	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PRD_ECU_Reset();
	S_wait_ms('TIMER_ECU_READY');

	$data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	PRD_Clear_Fault_Memory();
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
