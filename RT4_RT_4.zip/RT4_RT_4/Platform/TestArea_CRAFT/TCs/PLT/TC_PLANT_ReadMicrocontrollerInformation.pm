# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PLANT_ReadMicrocontrollerInformation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;

#use LIFT_functional_layer;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " check that it is possible to read information from microcontroller ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_ReadMicrocontrollerInformation 

=head1 PURPOSE

 check that it is possible to read information from microcontroller

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Bytes

    [initialisation]
    get temperature
    switch ECU on with U_BATT_DEFAULT
    clear fault memory

    [stimulation & measurement]
	1. switch ECU on
	2. read memory by address
	3. check response
	4. switch ECU off

    [evaluation]
	1. -
	2. -
	3. response contains �C information 
	4. -

    [finalisation]
    switch ECU on
    clear fault memory
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        --> battery voltage value
    SCALAR 'Bytes'		 --> amount of bytes
    SCALAR 'Address'	 --> start address for reading
    
=head2 PARAMETER EXAMPLES

	[TC_PLANT_ReadMicrocontrollerInformation.part_01]   #ID: TS_PLT_582
	purpose	= 'check reading of microcontroller information part_01'
	Ubat    = 13.5
	Bytes   = 256
	Address = '0xFFCD0000'

	
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#PARAMETERS
################ Parameters from .par file ######################
my ( $tcpar_Ubat_V, $tcpar_bytes, $tcpar_address );
################ Parameters from syc ############################

################ global parameter declaration ###################
my $plantmode5_set  = 0b00010000;
my $plantmode_clear = 0b00000000;

my ( $data_aref,      $data_aref2 );
my ( $data_href1,     $data_href2 );
my ( $response_href1, $response_href2 );

my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_Ubat_V  = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_bytes   = GEN_Read_mandatory_testcase_parameter('Bytes');
	$tcpar_address = GEN_Read_mandatory_testcase_parameter('Address');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# 1. switch ECU on
	S_teststep( "Switch ECU on with Ubat = $tcpar_Ubat_V V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');

	# 2. read memory by address
	S_teststep( "Read memory with start address '$tcpar_address' for $tcpar_bytes bytes", 'AUTO_NBR' );
	$data_aref = PRD_Read_Memory( $tcpar_address, { NbrOfBytes => $tcpar_bytes } );

	# 3. check response
	S_teststep( "Check response of read memory", 'AUTO_NBR', 'response' );

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	my $readStatus;

	S_teststep_expected( "Status: memory reading is possible", 'response' );
	if ( $data_aref == undef ) {
		$readStatus = 'memory reading not possible';
	}
	else {
		$readStatus = 'memory reading possible';
	}
	S_teststep_detected( "Status: $readStatus", 'response' );
	EVAL_evaluate_string( "Status", $readStatus, 'memory reading possible' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	# PRD_Clear_Fault_Memory();
	# switch ECU off
	S_teststep( "switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_Ubat_V V");

	return 1;
}

1;
