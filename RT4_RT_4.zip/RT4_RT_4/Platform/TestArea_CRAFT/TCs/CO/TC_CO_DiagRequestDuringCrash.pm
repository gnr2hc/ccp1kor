# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CO_DiagRequestDuringCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TR_Feature_Crash_Output
#TS version in DOORS: 5.13
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
use LIFT_crash_simulation;
use LIFT_can_access;
##################################

our $PURPOSE = "test that a diagnosis request for all crash output signals is ignored during a real crash and has no influence to the required crash output signals for this crash";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CO_DiagRequestDuringCrash

=head1 PURPOSE

test that a diagnosis request for all crash output signals is ignored during a real crash and has no influence to the required crash output signals for this crash

=head1 TESTCASE DESCRIPTION

This script is based on AB12_TR_Feature_Crash_Output

I<B<Initialisation>>

    switch ECU on
    clear fault recorder
    activate plant mode
    read fault recorder
    switch ECU off

I<B<Stimulation and Measurement>>

    set scanner and transient recorder
    switch ECU on
    send diagnosis request
    measure signal
    plot signal
    evaluate signal

I<B<Evaluation>>

    evaluate measured signal for frequency

I<B<Finalisation>>

    reset scanner
    deactivate plant mode
    reset ECU
    erase fault recorder
    switch ECU off


=head1 PARAMETER DESCRIPTION

    Ubat
    SignalType
    Pin
    SignalOnRequest
    SignalOnRequestTolerance
    CreisInputFile
    CrashName
    CrashNumber

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        				--> battery voltage value
    SCALAR 'SignalType'  				--> analog signal or bus signal (e.g. CAN)
    SCALAR 'Pin'         				--> ECU pin
    SCALAR 'SignalOnRequest'			--> frequency of requested signal
    SCALAR 'SignalOnRequestTolerance'	--> tolerance of requested signal
    SCALAR 'CreisInputFile'				--> name and path of result MDB
    SCALAR 'CrashName'					--> name of crash
    SCALAR 'CrashNumber'				--> number of crash


=head2 PARAMETER EXAMPLES

	[TC_CO_DiagRequestDuringCrash.CRO1]
	purpose='Checking_diag_request_during_crash_CRO1' 
	Ubat=9.8
	SignalType = 'analog'
	Pin = CRO1
	CreisInputFile = 'C:\TurboLIFT\AB12\CREIS\RT4_M3_13\SCI\SCI_M03_11_RT4_04B020_20190301.mdb'
	CrashName = 'C910353;1'
	CrashNumber = 40
	SignalOnRequest = 20 # Hz
	SignalOnRequestTolerance = 10 # %

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_ubat, $tcpar_pin, $tcpar_signalType );
my ( $tcpar_signalOnRequest, $tcpar_signalOnRequestTolerance );
my ( $tcpar_creisInputFile, $tcpar_crashName, $tcpar_crashNumber );
################ global parameter declaration ###################
#add any global variables here
#my @temperatures;
my ($unv_file_name);

# my $plantmode9_set  = 0b00000001;
# my $plantmode_clear = 0b00000000;

#my ( $data_aref1, $data_aref2 );
#my ( $data_href1, $data_href2 );
#my ( $fltmem1,    $fltmem2 );
my ( $data_HoH, $measuredSignal, $PDsuccess );
my $crashData_href;

#my $freq_mode_inactive;
#my $freq_mode_active = 20;

###############################################################

sub TC_set_parameters {

	$tcpar_ubat       = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_signalType = S_read_mandatory_testcase_parameter('SignalType');
	$tcpar_pin        = S_read_mandatory_testcase_parameter('Pin') if ( defined $tcpar_signalType );

	$tcpar_signalOnRequest          = S_read_mandatory_testcase_parameter('SignalOnRequest');
	$tcpar_signalOnRequestTolerance = S_read_mandatory_testcase_parameter('SignalOnRequestTolerance');

	$tcpar_creisInputFile = S_read_mandatory_testcase_parameter('CreisInputFile');
	$tcpar_crashNumber    = S_read_mandatory_testcase_parameter('CrashNumber');
	undef $tcpar_crashName;
	$tcpar_crashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_crashNumber );

	return 1;
}

sub TC_initialization {

	if ( defined $tcpar_crashNumber ) {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHINDEX"     => $tcpar_crashNumber,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_creisInputFile,
			}
		);

	}
	else {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHNAME"      => $tcpar_crashName,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_creisInputFile,
			}
		);

	}

	CSI_LoadAllData2Simulator($crashData_href);

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	# S_teststep( "Set plantmode", 'AUTO_NBR' );
	# PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode9_set] );

	CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'strict' );

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	#	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_signalType eq 'analog' ) {

		S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
		LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 20 * 1000,
				'MemorySize'        => 32 * 1024,
				'TriggerDelay'      => 0
			}
		);

		S_teststep( "Switch ECU on with Ubat = $tcpar_ubat V", 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( "Inject crash", 'AUTO_NBR' );
		CSI_TriggerCrash();

		S_teststep( "Wait 500 ms", 'AUTO_NBR' );
		S_wait_ms(500);

		S_teststep( "Read algo active flag", 'AUTO_NBR' );
		my $algoStatus = PRD_Read_Memory( 'rb_fcl_StatusFirCtrl_u8', { memoryContentsAsInteger => 1 } );
		S_w2log( 1, "Algo Status = $algoStatus\n", 'cyan' );

		# S_teststep( "Send AIO test pattern", 'AUTO_NBR', 'PDsuccess' );
		# $PDsuccess = PRD_Activate_AIO_Test_Pattern();

		S_teststep( "Request AIO test pattern", 'AUTO_NBR' );
		S_user_action( "Request AIO test pattern", "Send customer diagnosis request for AIO test pattern ($2F)" );

		S_teststep( "Measure signal", 'AUTO_NBR' );
		S_teststep_2nd_level( "Start TRC measurement", 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_teststep_2nd_level( "Wait until TRC measurement is finished.", 'AUTO_NBR' );
		S_wait_ms(2500);
		LC_MeasureTraceAnalogStop();
		$unv_file_name = $main::TC_REPORT_NAME . '_Signal.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
		S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

		S_teststep( "Evaluate signal", 'AUTO_NBR', 'evaluate_signal' );

		# S_user_action("check fire counter");

	}
	else {
	}

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_signalType eq 'analog' ) {

		S_teststep_expected( "Diagnosis request is not successful", 'PDsuccess' );
		S_teststep_detected( "Diagnosis request is $PDsuccess", 'PDsuccess' );
		EVAL_evaluate_value( "Diagnosis request", $PDsuccess, '!=', 1 );

		$data_HoH       = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
		$measuredSignal = EVAL_calc_signal_frequence( $data_HoH, $tcpar_pin, 0, undef, 5 );
		$measuredSignal = sprintf( "%.2f", 1000 * 1000 * $measuredSignal );
		S_teststep_expected( "Expected signal frequency: != $tcpar_signalOnRequest Hz", 'evaluate_signal' );
		S_teststep_detected( "Detected signal frequency: $measuredSignal Hz", 'evaluate_signal' );
		EVAL_evaluate_value( "Signal frequency", $measuredSignal, '!=', $tcpar_signalOnRequest, $tcpar_signalOnRequestTolerance, 'relative' );

	}
	else {

	}

	return 1;
}

sub TC_finalization {

	CSI_PrepareEnvironment( $crashData_href, 'after_crash' );
	CSI_PostCrashActions($crashData_href);

	S_teststep( "Reset TRC scanner", 'AUTO_NBR' );
	LC_ResetTRCscanner();

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	# S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	# PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	# PRD_ECU_Reset();
	# S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	#	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
