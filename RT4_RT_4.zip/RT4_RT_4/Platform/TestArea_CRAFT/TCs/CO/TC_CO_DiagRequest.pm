# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CO_DiagRequest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TR_Feature_Crash_Output
#TS version in DOORS: 5.13
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use FuncLib_TNT_GEN;
use LIFT_FaultMemory;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "switch ECU on and test that all crash output signals (analog or via communication bus) are send when a diagnosis request is send";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CO_DiagRequest

=head1 PURPOSE

switch ECU on and test that all crash output signals (analog or via communication bus) are send when a diagnosis request is send

=head1 TESTCASE DESCRIPTION

This script is based on AB12_TR_Feature_Crash_Output

I<B<Initialisation>>

    switch ECU on
    clear fault recorder
    activate plant mode
    read fault recorder
    switch ECU off

I<B<Stimulation and Measurement>>

    set scanner and transient recorder
    switch ECU on
    send diagnosis request
    measure signal
    plot signal
    evaluate signal

I<B<Evaluation>>

    evaluate measured signal for frequency

I<B<Finalisation>>

    reset scanner
    deactivate plant mode
    reset ECU
    erase fault recorder
    switch ECU off


=head1 PARAMETER DESCRIPTION

    Ubat
    SignalType
    Pin
    SignalAlive
    SignalAliveTolerance
    SignalOnRequest
    SignalOnRequestTolerance

=head2 PARAMETER NAMES

    SCALAR 'Ubat'        				--> battery voltage value
    SCALAR 'SignalType'  				--> analog signal or bus signal (e.g. CAN)
    SCALAR 'Pin'         				--> ECU pin
    SCALAR 'SignalAlive'				--> frequency of alive signal
    SCALAR 'SignalAliveTolerance'		--> tolerance of alive signal
    SCALAR 'SignalOnRequest'			--> frequency of requested signal
    SCALAR 'SignalOnRequestTolerance'	--> tolerance of requested signal


=head2 PARAMETER EXAMPLES

    [TC_CO_DiagRequest.CRO1]   #ID: TS_CRO_510
    purpose='Checking_diag_request_CRO1' 
    Ubat=12.3 
    SignalType = 'analog'
    Pin = 'CRO1'
	SignalAlive = 10 # Hz
	SignalAliveTolerance = 5 # %
	SignalOnRequest = 20 # Hz
	SignalOnRequestTolerance = 10 # %    

=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_ubat, $tcpar_pin, $tcpar_signalType );
my ( $tcpar_signalAlive,     $tcpar_signalAliveTolerance );
my ( $tcpar_signalOnRequest, $tcpar_signalOnRequestTolerance );

################ global parameter declaration ###################
#add any global variables here
my @temperatures;
my ( $unv_file_name1, $unv_file_name2 );

# my $plantmode9_set  = 0b00000001;
# my $plantmode_clear = 0b00000000;

#my ( $data_aref1, $data_aref2 );
#my ( $data_href1, $data_href2 );
#my ( $fltmem1,    $fltmem2 );
my ( $data_HoH, $measuredAliveSignal, $measuredTestSignal );

#my $freq_mode_inactive;
#my $freq_mode_active = 20;

###############################################################

sub TC_set_parameters {

	$tcpar_ubat       = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_signalType = S_read_mandatory_testcase_parameter('SignalType');
	$tcpar_pin        = S_read_mandatory_testcase_parameter('Pin') if ( defined $tcpar_signalType );

	$tcpar_signalAlive              = S_read_mandatory_testcase_parameter('SignalAlive');
	$tcpar_signalAliveTolerance     = S_read_mandatory_testcase_parameter('SignalAliveTolerance');
	$tcpar_signalOnRequest          = S_read_mandatory_testcase_parameter('SignalOnRequest');
	$tcpar_signalOnRequestTolerance = S_read_mandatory_testcase_parameter('SignalOnRequestTolerance');

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard Prep No fault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');

	# S_teststep( "Set plantmode", 'AUTO_NBR' );
	# PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode9_set] );

	PRD_Read_Fault_Memory('PRIMARY');
	PRD_Read_Fault_Memory('BOSCH');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_signalType eq 'analog' ) {

		S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
		LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 20 * 1000,
				'MemorySize'        => 64 * 1024,
				'TriggerDelay'      => 0
			}
		);

		S_teststep( "Switch ECU on with Ubat = $tcpar_ubat V", 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( "Measure alive signal", 'AUTO_NBR' );
		S_teststep_2nd_level( "Start TRC measurement", 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_teststep_2nd_level( "Wait until TRC is finished", 'AUTO_NBR' );
		S_wait_ms(5000);
		LC_MeasureTraceAnalogStop();
		$unv_file_name1 = $main::TC_REPORT_NAME . '_Alive_Signal.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name1 );
		S_w2rep( '<A HREF="./' . "$unv_file_name1" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name1" . '</A><br>' );

		S_teststep( "Evaluate alive signal", 'AUTO_NBR', 'alive_signal' );

		# S_teststep( "Send AIO test pattern", 'AUTO_NBR' );
		# PRD_Activate_AIO_Test_Pattern();

		S_teststep( "Request AIO test pattern", 'AUTO_NBR' );
		S_user_action( "Request AIO test pattern", "Send customer diagnosis request for AIO test pattern ($2F)" );

		S_teststep( "Measure test signal", 'AUTO_NBR' );
		S_teststep_2nd_level( "Start TRC measurement", 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_teststep_2nd_level( "Wait until TRC measurement is finished.", 'AUTO_NBR' );
		S_wait_ms(5000);
		LC_MeasureTraceAnalogStop();
		$unv_file_name2 = $main::TC_REPORT_NAME . '_Test_Signal.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name2 );
		S_w2rep( '<A HREF="./' . "$unv_file_name2" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name2" . '</A><br>' );

		S_teststep( "Evaluate test signal", 'AUTO_NBR', 'test_signal' );

	}
	else {
	}

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_signalType eq 'analog' ) {

		$data_HoH            = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name1 );
		$measuredAliveSignal = EVAL_calc_signal_frequence( $data_HoH, $tcpar_pin, 0, undef, 5 );
		$measuredAliveSignal = sprintf( "%.2f", 1000 * 1000 * $measuredAliveSignal );
		S_teststep_expected( "Expected alive signal frequency: $tcpar_signalAlive Hz", 'alive_signal' );
		S_teststep_detected( "Detected alive signal frequency: $measuredAliveSignal Hz", 'alive_signal' );
		EVAL_evaluate_value( "Alive Signal Frequency", $measuredAliveSignal, '==', $tcpar_signalAlive, $tcpar_signalAliveTolerance, 'relative' );

		$data_HoH           = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name2 );
		$measuredTestSignal = EVAL_calc_signal_frequence( $data_HoH, $tcpar_pin, 0, undef, 5 );
		$measuredTestSignal = sprintf( "%.2f", 1000 * 1000 * $measuredTestSignal );
		S_teststep_expected( "Expected signal frequency: $tcpar_signalOnRequest Hz", 'test_signal' );
		S_teststep_detected( "Detected signal frequency: $measuredTestSignal Hz", 'test_signal' );
		EVAL_evaluate_value( "Signal frequency", $measuredTestSignal, '==', $tcpar_signalOnRequest, $tcpar_signalOnRequestTolerance, 'relative' );

	}
	else {

	}

	return 1;
}

sub TC_finalization {

	S_teststep( "Reset TRC scanner", 'AUTO_NBR' );
	LC_ResetTRCscanner();

	S_teststep( "Switch ECU on", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	# S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	# PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$plantmode_clear] );
	# PRD_ECU_Reset();
	# S_wait_ms('TIMER_ECU_READY');

	my $data_aref = PRD_Read_Memory('rb_sycg_ActivePlantModes_au8(1)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
