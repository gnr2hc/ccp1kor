# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_SensorReboot;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " record the PSI communication and check that sensor reboot is performed ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_SensorReboot 

=head1 PURPOSE

 record the PSI communication and check that sensor reboot is performed

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand

    
    [initialisation]
    get temperature

    
    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
    apply fault
    wait for end of measurement
    

    [evaluation]
    evaluate measured signal for
    - sensor reboot
    send mail if not


    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'       --> battery voltage value
    SCALAR 'pin'        --> ECU pin
    LIST   'FLTmand'    --> mandatory faults
    
=head2 PARAMETER EXAMPLES

	[TC_FL_TestPulse.BT1FD]
	purpose='checking sensor reboot for UFSD' 
	Ubat=10.6
	Pin = 'UFSD'
	FLTmand = @('rb_psem_OpenLineUFSD_flt')
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, @tcpar_FLTmand, $fltmem, @tcpar_FLTopt, $unv_file_name );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = GEN_Read_optional_testcase_parameter('Pin');
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );

	LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 500 * 1000, 'MemorySize' => 2048 * 1024, 'TriggerDelay' => 0 } );

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep( "Wait 1 sec", 'AUTO_NBR' );
	S_wait_ms(1000);

	S_teststep( "Disconnect line: $tcpar_pin ", 'AUTO_NBR' );
	LC_DisconnectLine($tcpar_pin);

	S_teststep( "Wait 2.5 sec", 'AUTO_NBR' );
	S_wait_ms(2500);

	S_teststep( "Connect line: $tcpar_pin ", 'AUTO_NBR' );
	LC_ConnectLine($tcpar_pin);

	S_teststep( "Wait 1 sec", 'AUTO_NBR' );
	S_wait_ms(1000);

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'fault' );
	$fltmem = PD_GetExtendedFaultInformation();

	LC_MeasureTraceAnalogStop();
	S_wait_ms(100);

	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate measured signal for sensor reboot", 'AUTO_NBR', 'sensor_reboot' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $duration_ms, $timestamp_ms );

	#	evaluate measured signal
	my $data_href = LC_MeasureTraceAnalogGetValues( ["$tcpar_pin"], 0.02 );

	my ( $numOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_href, $tcpar_pin, 3.5, 0.1, 'falling' );

	#    my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
	#    my ( $numOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin, 3.5, 0.1, 'falling' );

	# calculation and evaluation of pulse duration
	#    foreach my $pulseNumber ( 0 .. ( $numOfPulses - 1 ) ) {
	#        if ( $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'} > $duration ) {
	#            $duration  = $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'};
	#            $timestamp = $pulses->{"pulse$pulseNumber"}{'start'};
	#        }
	#        my $start = $pulses->{"pulse$pulseNumber"}{'start'};
	#        my $end = $pulses->{"pulse$pulseNumber"}{'end'};
	#        S_w2log(3, "Detected pulse $pulseNumber Start: $start End: $end ");
	#    }

	$duration_ms  = $pulses->{'pulse0'}{'end'} - $pulses->{'pulse0'}{'start'};
	$timestamp_ms = $pulses->{'pulse0'}{'start'};

	$duration_ms  = sprintf( "%.2f", $duration_ms );
	$timestamp_ms = sprintf( "%.2f", $timestamp_ms );
	S_teststep_expected( "reboot (max duration) = 50 ms", 'sensor_reboot' );
	S_teststep_detected( "reboot (max duration) = '$duration_ms ms' (@ $timestamp_ms ms)", 'sensor_reboot' );
	EVAL_evaluate_value( "reboot duration", $duration_ms, '==', 50, 2, 'absolute' );

	# compare fault memory against mandatory and optional faults
	S_teststep_expected( 'Expected faults:', 'fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'fault' );
	foreach my $fault ( @{ $fltmem->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
__END__
