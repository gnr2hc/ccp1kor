# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_NoSensorReboot;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.10
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;

use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
use LIFT_crash_simulation;
use LIFT_can_access;
##################################

our $PURPOSE = " record the PSI communication and check that no sensor reboot is performed ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_NoSensorReboot 

=head1 PURPOSE

 record the PSI communication and check that sensor reboot is performed

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    FLTmand

    
    [initialisation]
    
    [stimulation & measurement]
    set scanner
    set transient recorder
    set Ubat
    switch ECU on
    inject crash
    apply fault
    wait for end of measurement
    

    [evaluation]
    evaluate measured signal for
    - no sensor reboot
    send mail if not


    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'        --> battery voltage value
    SCALAR 'pin'         --> ECU pin
    SCALAR 'MDSDB'       --> name of used MDS database file
    SCALAR 'CrashName'   --> name of injected crash (has to be a deployment crash)
    SCALAR 'CrashNumber' --> number of injected crash
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_NoSensorReboot.UFSD]   #ID: TS_PSI_943
    purpose='checking no sensor reboot for UFSD' 
    Ubat=12.3 
    Pin = 'UFSD'
    MDSDB = 'C:\TurboLIFT\AB12\config\Tools\CREIS\Systemtests_M0245_AB12_PlatformM0245_SCI_037838_forM245offDLLnew_20160426.mdb'
    CrashNumber = '1'
    CrashName = 'PT_fire_from_all_sensors'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $fltmem_Bosch, $fltmem_Primary, $unv_file_name, $tcpar_MDSDB, $tcpar_CrashName, $crashData_href, $tcpar_CrashNumber );

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin  = S_read_optional_testcase_parameter('Pin');

	$tcpar_MDSDB       = S_read_mandatory_testcase_parameter('MDSDB');
	$tcpar_CrashNumber = S_read_mandatory_testcase_parameter('CrashNumber');
	undef $tcpar_CrashName;
	$tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# 1. read next crash from MDS-Result-File (read environment states + velocities)
	if ( defined $tcpar_CrashNumber ) {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHINDEX"     => $tcpar_CrashNumber,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_MDSDB,
			}
		);

	}
	else {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHNAME"      => $tcpar_CrashName,
				"STATEVARIATION" => 1,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_MDSDB,
			}
		);

	}

	CSI_LoadAllData2Simulator($crashData_href);

	#	CA_simulation_start();
	# switch ECU on
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PRD_Clear_EDR();
	S_wait_ms('TIMER_ECU_READY');
	PRD_Clear_Fault_Memory();
	S_wait_ms('TIMER_ECU_READY');
	CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'relaxed' );

	#PD_GetExtendedFaultInformation();
	LIFT_FaultMemory->read_fault_memory('Bosch');
	LIFT_FaultMemory->read_fault_memory('Primary');

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Prepare crash.", 'AUTO_NBR' );

	# prepare crash

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );

	LC_SetTRCscanner( [$tcpar_pin], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );

	#    LC_ConfigureTRCchannels( { 'SamplingFrequency' => 200 * 1000, 'MemorySize' => 512 * 1024, 'TriggerDelay' => 0 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 500 * 1000, 'MemorySize' => 512 * 1024, 'TriggerDelay' => 0 }, { 'SlopeType' => 'negative' } );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	#	S_user_action("start diag");

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	#        S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	#        LC_MeasureTraceAnalogSendSWTrigger();
	#
	#        S_teststep( "Wait 200 sec", 'AUTO_NBR' );
	#        S_wait_ms(200);

	# only used for evaluation
	my $FDtrace = $main::REPORT_PATH . "/" . S_get_TC_number() . "NoSensorReboot.txt";

	#	PD_StartFastDiagName( $FDtrace, ['rb_fcl_StatusFirCtrl_u8'], ['U8'], [], 4 );
	# PD_StartFastDiagName( $FDtrace, ['rb_fcl_StatusFirCtrl_u8'], ['U8'], [], 1 );
	my $fastDiagConfig_href = {
		labels             => ['rb_fcl_StatusFirCtrl_u8'],
		number_of_BUS_Ids  => 1,
		is_next_POC        => 0,
		csv_data_file_path => $FDtrace,
	};
	my $csv_data_file_path = PRD_Start_Fast_Diagnosis($fastDiagConfig_href);

	S_teststep( "Inject crash", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep( "Wait 100 ms", 'AUTO_NBR' );
	S_wait_ms(100);

	S_teststep( "Disconnect line: $tcpar_pin ", 'AUTO_NBR' );
	LC_DisconnectLine($tcpar_pin);

	S_teststep( "Wait 250 ms", 'AUTO_NBR' );
	S_wait_ms(250);

	S_teststep( "Connect line: $tcpar_pin ", 'AUTO_NBR' );
	LC_ConnectLine($tcpar_pin);

	S_teststep( "Wait 2 sec", 'AUTO_NBR' );
	S_wait_ms(2000);

	#    S_user_action("stop diag");

	# only used for evaluation
	# PD_StopFastDiag();
	PRD_Stop_Fast_Diagnosis();

	# my $FD_data = PD_get_FDtrace($FDtrace);
	# my $fdData_href  = PRD_Get_Fast_Diagnosis_Data({'data_path' =>  $csv_data_file_path});
	# PD_plot_FDtrace( $FD_data, $FDtrace );
	# S_create_graph ( $fdData_href, 'FD-Trace-Algo-Active' );

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'fault' );

	# $fltmem = PD_GetExtendedFaultInformation();
	$fltmem_Bosch   = LIFT_FaultMemory->read_fault_memory('Bosch');
	$fltmem_Primary = LIFT_FaultMemory->read_fault_memory('Primary');

	LC_MeasureTraceAnalogStop();
	S_wait_ms(100);

	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogStop();
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate measured signal for sensor reboot", 'AUTO_NBR', 'sensor_reboot' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $duration_ms, $timestamp_ms );

	#	evaluate measured signal
	my $data_href = LC_MeasureTraceAnalogGetValues( ["$tcpar_pin"], 0.02 );

	my ( $numOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_href, $tcpar_pin, 3.5, 0.1, 'falling' );

	#    my $data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name );
	#    my ( $numOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin, 3.5, 0.1, 'falling' );

	# calculation and evaluation of pulse duration
	#    foreach my $pulseNumber ( 0 .. ( $numOfPulses - 1 ) ) {
	#        if ( $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'} > $duration ) {
	#            $duration  = $pulses->{"pulse$pulseNumber"}{'end'} - $pulses->{"pulse$pulseNumber"}{'start'};
	#            $timestamp = $pulses->{"pulse$pulseNumber"}{'start'};
	#        }
	#        my $start = $pulses->{"pulse$pulseNumber"}{'start'};
	#        my $end = $pulses->{"pulse$pulseNumber"}{'end'};
	#        S_w2log(3, "Detected pulse $pulseNumber Start: $start End: $end ");
	#    }

	$duration_ms  = $pulses->{'pulse0'}{'end'} - $pulses->{'pulse0'}{'start'};
	$timestamp_ms = $pulses->{'pulse0'}{'start'};

	$duration_ms  = sprintf( "%.2f", $duration_ms );
	$timestamp_ms = sprintf( "%.2f", $timestamp_ms );
	S_teststep_expected( "no sensor reboot is expected  (pulses) = 0", 'sensor_reboot' );
	S_teststep_detected( "no sensor reboot is performed (pulses) = '$numOfPulses' ", 'sensor_reboot' );
	EVAL_evaluate_value( "no sensor reboot", $numOfPulses, '==', 0 );

	# compare fault memory against mandatory and optional faults
	#    S_teststep_expected( 'Expected faults:', 'fault' );
	#    foreach my $fault (@tcpar_FLTmand) {
	#        S_teststep_expected($fault);
	#    }
	#
	#    S_teststep_detected( 'Detected faults:', 'fault' );
	#    foreach my $fault ( @{ $fltmem->{fault_text} } ) {
	#        S_teststep_detected($fault);
	#    }
	#    PD_evaluate_faults( $fltmem, \@tcpar_FLTmand, \@tcpar_FLTopt );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	CSI_PrepareEnvironment( $crashData_href, 'after_crash' );
	CSI_PostCrashActions($crashData_href);

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;
__END__
