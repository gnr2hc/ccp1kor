# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_PSI_VerifyStoredData;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Peripheral_Sensor_Interface
#TS version in DOORS: 5.11
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = " test that all stored data for each sensor is correct ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PSI_VerifyStoredData 

=head1 PURPOSE

 test that all stored data for each sensor is correct 
 
=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin
    Label
    Data1
    Data2
    Data3
    Data4
    Data5
    Data6
    Data7
	FLTmand
        
    [initialisation]
    get temperature

    [stimulation & measurement]
    set Ubat
	ECU on
    wait for end of initialization
    read label to get start address
    read 16 cells from start address
    read fault memory
	ECU off
    
    [evaluation]
    check if stored data is correct
    check if fault memory matches given faults

    [finalisation]
    get temperature
    print temperatures
    
=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'         --> battery voltage value
    SCALAR 'pin'		  --> PAS which is verifed
    SCALAR 'label'		  --> label containing start address
    SCALAR 'data1'		  --> checked data
    SCALAR 'data2'		  --> checked data
    SCALAR 'data3'		  --> checked data
    SCALAR 'data4'		  --> checked data
    SCALAR 'data5'		  --> checked data
    SCALAR 'data6'		  --> checked data
    SCALAR 'data7'		  --> checked data
    LIST   'FLTmand'      --> list of mandatory faults (logical names)
    
=head2 PARAMETER EXAMPLES

    [TC_PSI_VerifyStoredData.UFSD]
    purpose		 ='Checking_stored_data_for_UFSD'
    Ubat		 = 10.8
    Pin			 = 'UFSD'
    Label		 = 'rb_pssm_InternalData_st.ChannelMiscData_apv(0)' 
    Data1 = '0x04' # protocol revision
	Data2 = '0x02' # number of data blocks
	Data3 = '0x00' # number of data blocks
	Data4 = '0x01' # manufacturer
	Data5 = '0x00' # manufacturer
	Data6 = '0x06' # sensor generation / sensor bus mode
	Data7 = '0x01' # sensor type
    FLTmand		 = ()
		
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $fltmem1, $value_aref );

my ( $tcpar_ubat, $tcpar_pin, $tcpar_label, @tcpar_FLTmand, );
my @temperatures = ();
my (
	$tcpar_data1,  $tcpar_data2,  $tcpar_data3,  $tcpar_data4,  $tcpar_data5,  $tcpar_data6,  $tcpar_data7,  $tcpar_data8,  $tcpar_data9,  $tcpar_data10, $tcpar_data11, $tcpar_data12, $tcpar_data13, $tcpar_data14, $tcpar_data15, $tcpar_data16,
	$tcpar_data17, $tcpar_data18, $tcpar_data19, $tcpar_data20, $tcpar_data21, $tcpar_data22, $tcpar_data23, $tcpar_data24, $tcpar_data25, $tcpar_data26, $tcpar_data27, $tcpar_data28, $tcpar_data29, $tcpar_data30, $tcpar_data31, $tcpar_data32,
);

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat    = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin     = GEN_Read_mandatory_testcase_parameter('Pin');
	$tcpar_data1   = GEN_Read_mandatory_testcase_parameter('Data1');
	$tcpar_data2   = GEN_Read_mandatory_testcase_parameter('Data2');
	$tcpar_data3   = GEN_Read_mandatory_testcase_parameter('Data3');
	$tcpar_data4   = GEN_Read_mandatory_testcase_parameter('Data4');
	$tcpar_data5   = GEN_Read_mandatory_testcase_parameter('Data5');
	$tcpar_data6   = GEN_Read_mandatory_testcase_parameter('Data6');
	$tcpar_data7   = GEN_Read_mandatory_testcase_parameter('Data7');
	$tcpar_data8   = GEN_Read_optional_testcase_parameter('Data8');
	$tcpar_data9   = GEN_Read_optional_testcase_parameter('Data9');
	$tcpar_data10  = GEN_Read_optional_testcase_parameter('Data10');
	$tcpar_data11  = GEN_Read_optional_testcase_parameter('Data11');
	$tcpar_data12  = GEN_Read_optional_testcase_parameter('Data12');
	$tcpar_data13  = GEN_Read_optional_testcase_parameter('Data13');
	$tcpar_data14  = GEN_Read_optional_testcase_parameter('Data14');
	$tcpar_data15  = GEN_Read_optional_testcase_parameter('Data15');
	$tcpar_data16  = GEN_Read_optional_testcase_parameter('Data16');
	$tcpar_data17  = GEN_Read_optional_testcase_parameter('Data17');
	$tcpar_data18  = GEN_Read_optional_testcase_parameter('Data18');
	$tcpar_data19  = GEN_Read_optional_testcase_parameter('Data19');
	$tcpar_data20  = GEN_Read_optional_testcase_parameter('Data20');
	$tcpar_data21  = GEN_Read_optional_testcase_parameter('Data21');
	$tcpar_data22  = GEN_Read_optional_testcase_parameter('Data22');
	$tcpar_data23  = GEN_Read_optional_testcase_parameter('Data23');
	$tcpar_data24  = GEN_Read_optional_testcase_parameter('Data24');
	$tcpar_data25  = GEN_Read_optional_testcase_parameter('Data25');
	$tcpar_data26  = GEN_Read_optional_testcase_parameter('Data26');
	$tcpar_data27  = GEN_Read_optional_testcase_parameter('Data27');
	$tcpar_data28  = GEN_Read_optional_testcase_parameter('Data28');
	$tcpar_data29  = GEN_Read_optional_testcase_parameter('Data29');
	$tcpar_data30  = GEN_Read_optional_testcase_parameter('Data30');
	$tcpar_data31  = GEN_Read_optional_testcase_parameter('Data31');
	$tcpar_data32  = GEN_Read_optional_testcase_parameter('Data32');
	@tcpar_FLTmand = GEN_Read_optional_testcase_parameter('FLTmand');

	my $device_index = PD_get_device_index($tcpar_pin);
	$tcpar_label = "rb_pssm_InternalData_st.ChannelMiscData_apv($device_index)";

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read label for start address", 'AUTO_NBR' );

	#PD_ECUlogin();
	S_wait_ms(500);

	#my $label_aref   = PD_ReadMemoryByName($tcpar_label);

	my $labelAddress = PD_GetAddressByName($tcpar_label);
	my $label_aref = PD_ReadMemoryByAddress( $labelAddress, 4 );

	my $startAddress = S_aref2hex($label_aref);
	S_w2rep("Start Address: $startAddress");

	S_teststep( "Read 16 cells from start address", 'AUTO_NBR' );
	$value_aref = PD_ReadMemoryByAddress( $startAddress, 16 );

	S_teststep( "Evaluate the data elements", 'AUTO_NBR', 'Data' );

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );

	#PD_ECUlogin();
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'Fault' );

	S_teststep( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my @value = reverse @$value_aref;
	my $detected_values;
	$detected_values->{'Data1'} = sprintf '%#.2x', ( $value[0] >> 4 ) & 0x0F;
	$detected_values->{'Data2'} = sprintf '%#.2x', $value[0] & 0x0F;
	$detected_values->{'Data3'} = sprintf '%#.2x', ( $value[1] >> 4 ) & 0x0F;
	$detected_values->{'Data4'} = sprintf '%#.2x', $value[1] & 0x0F;
	$detected_values->{'Data5'} = sprintf '%#.2x', ( $value[2] >> 4 ) & 0x0F;
	$detected_values->{'Data6'} = sprintf '%#.2x', $value[2] & 0x0F;
	$detected_values->{'Data7'} = sprintf '%#.2x', ( $value[3] >> 4 ) & 0x0F;
	$detected_values->{'Data8'} = sprintf '%#.2x', $value[3] & 0x0F;
	$detected_values->{'Data9'} = sprintf '%#.2x', ( $value[4] >> 4 ) & 0x0F;
	$detected_values->{'Data10'} = sprintf '%#.2x', $value[4] & 0x0F;
	$detected_values->{'Data11'} = sprintf '%#.2x', ( $value[5] >> 4 ) & 0x0F;
	$detected_values->{'Data12'} = sprintf '%#.2x', $value[5] & 0x0F;
	$detected_values->{'Data13'} = sprintf '%#.2x', ( $value[6] >> 4 ) & 0x0F;
	$detected_values->{'Data14'} = sprintf '%#.2x', $value[6] & 0x0F;
	$detected_values->{'Data15'} = sprintf '%#.2x', ( $value[7] >> 4 ) & 0x0F;
	$detected_values->{'Data16'} = sprintf '%#.2x', $value[7] & 0x0F;
	$detected_values->{'Data17'} = sprintf '%#.2x', ( $value[8] >> 4 ) & 0x0F;
	$detected_values->{'Data18'} = sprintf '%#.2x', $value[8] & 0x0F;
	$detected_values->{'Data19'} = sprintf '%#.2x', ( $value[9] >> 4 ) & 0x0F;
	$detected_values->{'Data20'} = sprintf '%#.2x', $value[9] & 0x0F;
	$detected_values->{'Data21'} = sprintf '%#.2x', ( $value[10] >> 4 ) & 0x0F;
	$detected_values->{'Data22'} = sprintf '%#.2x', $value[10] & 0x0F;
	$detected_values->{'Data23'} = sprintf '%#.2x', ( $value[11] >> 4 ) & 0x0F;
	$detected_values->{'Data24'} = sprintf '%#.2x', $value[11] & 0x0F;
	$detected_values->{'Data25'} = sprintf '%#.2x', ( $value[12] >> 4 ) & 0x0F;
	$detected_values->{'Data26'} = sprintf '%#.2x', $value[12] & 0x0F;
	$detected_values->{'Data27'} = sprintf '%#.2x', ( $value[13] >> 4 ) & 0x0F;
	$detected_values->{'Data28'} = sprintf '%#.2x', $value[13] & 0x0F;
	$detected_values->{'Data29'} = sprintf '%#.2x', ( $value[14] >> 4 ) & 0x0F;
	$detected_values->{'Data30'} = sprintf '%#.2x', $value[14] & 0x0F;
	$detected_values->{'Data31'} = sprintf '%#.2x', ( $value[15] >> 4 ) & 0x0F;
	$detected_values->{'Data32'} = sprintf '%#.2x', $value[15] & 0x0F;

	S_teststep_expected( 'Expected data:', 'Data' );
	S_teststep_detected( 'Detected data:', 'Data' );

	S_teststep_expected("Data1: $tcpar_data1");
	S_teststep_detected("Data1: $detected_values->{'Data1'}");
	EVAL_evaluate_value( 'Data1', $detected_values->{'Data1'}, '==', $tcpar_data1 );

	S_teststep_expected("Data2: $tcpar_data2");
	S_teststep_detected("Data2: $detected_values->{'Data2'}");
	EVAL_evaluate_value( 'Data2', $detected_values->{'Data2'}, '==', $tcpar_data2 );

	S_teststep_expected("Data3: $tcpar_data3");
	S_teststep_detected("Data3: $detected_values->{'Data3'}");
	EVAL_evaluate_value( 'Data3', $detected_values->{'Data3'}, '==', $tcpar_data3 );

	S_teststep_expected("Data4: $tcpar_data4");
	S_teststep_detected("Data4: $detected_values->{'Data4'}");
	EVAL_evaluate_value( 'Data4', $detected_values->{'Data4'}, '==', $tcpar_data4 );

	S_teststep_expected("Data5: $tcpar_data5");
	S_teststep_detected("Data5: $detected_values->{'Data5'}");
	EVAL_evaluate_value( 'Data5', $detected_values->{'Data5'}, '==', $tcpar_data5 );

	S_teststep_expected("Data6: $tcpar_data6");
	S_teststep_detected("Data6: $detected_values->{'Data6'}");
	EVAL_evaluate_value( 'Data6', $detected_values->{'Data6'}, '==', $tcpar_data6 );

	S_teststep_expected("Data7: $tcpar_data7");
	S_teststep_detected("Data7: $detected_values->{'Data7'}");
	EVAL_evaluate_value( 'Data7', $detected_values->{'Data7'}, '==', $tcpar_data7 );

	S_teststep_expected("Data8: $tcpar_data8")                if defined $tcpar_data8;
	S_teststep_detected("Data8: $detected_values->{'Data8'}") if defined $tcpar_data8;
	EVAL_evaluate_value( 'Data8', $detected_values->{'Data8'}, '==', $tcpar_data8 ) if defined $tcpar_data8;

	S_teststep_expected("Data9: $tcpar_data9")                if defined $tcpar_data9;
	S_teststep_detected("Data9: $detected_values->{'Data9'}") if defined $tcpar_data9;
	EVAL_evaluate_value( 'Data9', $detected_values->{'Data9'}, '==', $tcpar_data9 ) if defined $tcpar_data9;

	S_teststep_expected("Data10: $tcpar_data10")                if defined $tcpar_data10;
	S_teststep_detected("Data10: $detected_values->{'Data10'}") if defined $tcpar_data10;
	EVAL_evaluate_value( 'Data10', $detected_values->{'Data10'}, '==', $tcpar_data10 ) if defined $tcpar_data10;

	S_teststep_expected("Data11: $tcpar_data11")                if defined $tcpar_data11;
	S_teststep_detected("Data11: $detected_values->{'Data11'}") if defined $tcpar_data11;
	EVAL_evaluate_value( 'Data11', $detected_values->{'Data11'}, '==', $tcpar_data11 ) if defined $tcpar_data11;

	S_teststep_expected("Data12: $tcpar_data12")                if defined $tcpar_data12;
	S_teststep_detected("Data12: $detected_values->{'Data12'}") if defined $tcpar_data12;
	EVAL_evaluate_value( 'Data12', $detected_values->{'Data12'}, '==', $tcpar_data12 ) if defined $tcpar_data12;

	S_teststep_expected("Data13: $tcpar_data13")                if defined $tcpar_data13;
	S_teststep_detected("Data13: $detected_values->{'Data13'}") if defined $tcpar_data13;
	EVAL_evaluate_value( 'Data13', $detected_values->{'Data13'}, '==', $tcpar_data13 ) if defined $tcpar_data13;

	S_teststep_expected("Data14: $tcpar_data14")                if defined $tcpar_data14;
	S_teststep_detected("Data14: $detected_values->{'Data14'}") if defined $tcpar_data14;
	EVAL_evaluate_value( 'Data14', $detected_values->{'Data14'}, '==', $tcpar_data14 ) if defined $tcpar_data14;

	S_teststep_expected("Data15: $tcpar_data15")                if defined $tcpar_data15;
	S_teststep_detected("Data15: $detected_values->{'Data15'}") if defined $tcpar_data15;
	EVAL_evaluate_value( 'Data15', $detected_values->{'Data15'}, '==', $tcpar_data15 ) if defined $tcpar_data15;

	S_teststep_expected("Data16: $tcpar_data16")                if defined $tcpar_data16;
	S_teststep_detected("Data16: $detected_values->{'Data16'}") if defined $tcpar_data16;
	EVAL_evaluate_value( 'Data16', $detected_values->{'Data16'}, '==', $tcpar_data16 ) if defined $tcpar_data16;

	S_teststep_expected("Data17: $tcpar_data17")                if defined $tcpar_data17;
	S_teststep_detected("Data17: $detected_values->{'Data17'}") if defined $tcpar_data17;
	EVAL_evaluate_value( 'Data17', $detected_values->{'Data17'}, '==', $tcpar_data17 ) if defined $tcpar_data17;

	S_teststep_expected("Data18: $tcpar_data18")                if defined $tcpar_data18;
	S_teststep_detected("Data18: $detected_values->{'Data18'}") if defined $tcpar_data18;
	EVAL_evaluate_value( 'Data18', $detected_values->{'Data18'}, '==', $tcpar_data18 ) if defined $tcpar_data18;

	S_teststep_expected("Data19: $tcpar_data19")                if defined $tcpar_data19;
	S_teststep_detected("Data19: $detected_values->{'Data19'}") if defined $tcpar_data19;
	EVAL_evaluate_value( 'Data19', $detected_values->{'Data19'}, '==', $tcpar_data19 ) if defined $tcpar_data19;

	S_teststep_expected("Data20: $tcpar_data20")                if defined $tcpar_data20;
	S_teststep_detected("Data20: $detected_values->{'Data20'}") if defined $tcpar_data20;
	EVAL_evaluate_value( 'Data20', $detected_values->{'Data20'}, '==', $tcpar_data20 ) if defined $tcpar_data20;

	S_teststep_expected("Data21: $tcpar_data21")                if defined $tcpar_data21;
	S_teststep_detected("Data21: $detected_values->{'Data21'}") if defined $tcpar_data21;
	EVAL_evaluate_value( 'Data21', $detected_values->{'Data21'}, '==', $tcpar_data21 ) if defined $tcpar_data21;

	S_teststep_expected("Data22: $tcpar_data22")                if defined $tcpar_data22;
	S_teststep_detected("Data22: $detected_values->{'Data22'}") if defined $tcpar_data22;
	EVAL_evaluate_value( 'Data22', $detected_values->{'Data22'}, '==', $tcpar_data22 ) if defined $tcpar_data22;

	S_teststep_expected("Data23: $tcpar_data23")                if defined $tcpar_data23;
	S_teststep_detected("Data23: $detected_values->{'Data23'}") if defined $tcpar_data23;
	EVAL_evaluate_value( 'Data23', $detected_values->{'Data23'}, '==', $tcpar_data23 ) if defined $tcpar_data23;

	S_teststep_expected("Data24: $tcpar_data24")                if defined $tcpar_data24;
	S_teststep_detected("Data24: $detected_values->{'Data24'}") if defined $tcpar_data24;
	EVAL_evaluate_value( 'Data24', $detected_values->{'Data24'}, '==', $tcpar_data24 ) if defined $tcpar_data24;

	S_teststep_expected("Data25: $tcpar_data25")                if defined $tcpar_data25;
	S_teststep_detected("Data25: $detected_values->{'Data25'}") if defined $tcpar_data25;
	EVAL_evaluate_value( 'Data25', $detected_values->{'Data25'}, '==', $tcpar_data25 ) if defined $tcpar_data25;

	S_teststep_expected("Data26: $tcpar_data26")                if defined $tcpar_data26;
	S_teststep_detected("Data26: $detected_values->{'Data26'}") if defined $tcpar_data26;
	EVAL_evaluate_value( 'Data26', $detected_values->{'Data26'}, '==', $tcpar_data26 ) if defined $tcpar_data26;

	S_teststep_expected("Data27: $tcpar_data27")                if defined $tcpar_data27;
	S_teststep_detected("Data27: $detected_values->{'Data27'}") if defined $tcpar_data27;
	EVAL_evaluate_value( 'Data27', $detected_values->{'Data27'}, '==', $tcpar_data27 ) if defined $tcpar_data27;

	S_teststep_expected("Data28: $tcpar_data28")                if defined $tcpar_data28;
	S_teststep_detected("Data28: $detected_values->{'Data28'}") if defined $tcpar_data28;
	EVAL_evaluate_value( 'Data28', $detected_values->{'Data28'}, '==', $tcpar_data28 ) if defined $tcpar_data28;

	S_teststep_expected("Data29: $tcpar_data29")                if defined $tcpar_data29;
	S_teststep_detected("Data29: $detected_values->{'Data29'}") if defined $tcpar_data29;
	EVAL_evaluate_value( 'Data29', $detected_values->{'Data29'}, '==', $tcpar_data29 ) if defined $tcpar_data29;

	S_teststep_expected("Data30: $tcpar_data30")                if defined $tcpar_data30;
	S_teststep_detected("Data30: $detected_values->{'Data30'}") if defined $tcpar_data30;
	EVAL_evaluate_value( 'Data30', $detected_values->{'Data30'}, '==', $tcpar_data30 ) if defined $tcpar_data30;

	S_teststep_expected("Data31: $tcpar_data31")                if defined $tcpar_data31;
	S_teststep_detected("Data31: $detected_values->{'Data31'}") if defined $tcpar_data31;
	EVAL_evaluate_value( 'Data31', $detected_values->{'Data31'}, '==', $tcpar_data31 ) if defined $tcpar_data31;

	S_teststep_expected("Data32: $tcpar_data32")                if defined $tcpar_data32;
	S_teststep_detected("Data32: $detected_values->{'Data32'}") if defined $tcpar_data32;
	EVAL_evaluate_value( 'Data32', $detected_values->{'Data32'}, '==', $tcpar_data32 ) if defined $tcpar_data32;

	S_teststep_expected( 'Expected faults:', 'Fault' );
	foreach my $fault (@tcpar_FLTmand) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults:', 'Fault' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, \@tcpar_FLTmand );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
