# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_FiringPulseHighResistance;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " record the firing pulses on each squib with a high resistance and check that all parameters are correct ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 record the firing pulses on each squib with a high resistance and check that all parameters are correct

=head1 TESTCASE DESCRIPTION

[parameter used]

    [initialisation]
    get temperature
    

    [stimulation & measurement]
    set scanner and transient recorder
    switch ECU on
    wait 10 sec
    set squib <pin> to <resistance> ohm
    send disposal PWM signal on PIN <pin_acl> if ACL is used
    prepare electronic firing using RB PD
    start transient recorder measurement
    trigger electronic firing using RB PD
    wait until transient recorder measurement is finished
    set squib <pin> to default
    switch ECU off
    evaluate squib firing for <pin> ...
    
    [evaluation]
    evaluate squib firing for <pin>
    - check number of detected firing pulses
    - check current of first detected firing pulse
    - check duration of first detected firing pulse
    send mail if not

    [finalisation]
    stop sending of disposal PWM signal if ACL is used
    reset scanner

=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> firing loop name
    SCALAR 'resistance_ohm'      --> resistance value [ohm]
    SCALAR 'firingMode'		 	 --> firing mode of squib		  - taken from SYC interface
    SCALAR 'min_currrent_A'		 --> minimum firing current [A]	  - taken from SYC interface
    SCALAR 'min_duration_ms'	 --> minimum firing duration [ms] - taken from SYC interface
    SCALAR 'nbr_byte_of_sqmm'    --> squib number of ASIC         - taken from SYC interface
    SCALAR 'pin_acl'			 --> ACL Pin
    SCALAR 'source_acl'			 --> Source of ACL signal
    LIST   'readLabels'	 		 --> check fire counter label
    
=head2 PARAMETER EXAMPLES

	[TC_FL_FiringPulse.AB1FD]
	purpose    = '$check firing pulses for AB1FD with electronic firing' 
	UBat       = 12.7
	Pin        = AB1FD
	Resistance = 6.8
	PinACL     = ACL
	SourceACL  = external
	ReadLabels = @('rb_sqmf_Firecounter_au16(4)')
		
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my (
	$tcpar_ubat,                 $tcpar_pin,     $tcpar_resistance_ohm, $tcpar_nbr_byte_of_sqmm, $tcpar_firingMode,   $tcpar_min_current_A, $tcpar_min_duration_ms, $tcpar_min_duration_backup_ms,
	$tcpar_min_current_backup_A, $unv_file_name, $calc_array_idx,       $asic_connection,        $asic_connectionCBR, $asic_connectionIGH,  $asic_connectionIGL
);
my ($result);
my @temperatures = ();
my ( $valid_flag, $return_value, $precondition_valid, $tcpar_pin_acl, $tcpar_source_acl, $diagSimType );
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat           = GEN_Read_mandatory_testcase_parameter('UBat');
	$tcpar_pin            = GEN_Read_mandatory_testcase_parameter('Pin');
	$tcpar_resistance_ohm = GEN_Read_mandatory_testcase_parameter('Resistance');
	$tcpar_pin_acl        = GEN_Read_optional_testcase_parameter('PinACL');
	$tcpar_source_acl     = GEN_Read_optional_testcase_parameter('SourceACL');

	( $result, $tcpar_firingMode ) = SYC_SQUIB_get_firing_mode($tcpar_pin);
	return 0 unless $result;

	( $result, $tcpar_min_duration_ms, $tcpar_min_duration_backup_ms ) = SYC_SQUIB_get_firing_pulse_min_duration($tcpar_pin);
	return 0 unless $result;

	( $result, $tcpar_min_current_A, $tcpar_min_current_backup_A ) = SYC_SQUIB_get_firing_pulse_min_current($tcpar_pin);
	return 0 unless $result;

	( $result, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL ) = SYC_SQUIB_get_ASIC_connection($tcpar_pin);
	return 0 unless $result;

	( $valid_flag, $return_value ) = S_read_public_variable("TEMPcontrolled");

	if ( $valid_flag == 1 and $return_value == 1 and TEMP_getTargetTemperature() > 75 ) {
		S_w2rep("Test should only run at HT - currenlty at HT");
		$precondition_valid = 1;
	}
	elsif ( $valid_flag == 1 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("Test should only run with IC for HT [IC_AB12_TEMP.HT]");
		S_teststep_detected("But Temp is not under control if IC [IC_AB12_TEMP.DEFAULT]") if $return_value == 0;

		$precondition_valid = 0;
	}
	elsif ( $valid_flag == 0 ) {
		S_set_verdict("VERDICT_NONE");
		S_teststep_detected("State of temperature is not known!");
		S_teststep_detected("IC with public variable 'TEMPcontrolled' to be used!");

		$precondition_valid = 0;
	}

	if ( PD_GetAddressByName_NOERROR_NOHTML("rb_sqmm_ResistanceValue_au16(0)(0)") ne '0x1' ) {
		$diagSimType = 3;
	}
	else {
		$diagSimType = 2;
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {
	if ($precondition_valid) {

		# switch ECU on
		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');

		#PD_ECUlogin();
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		PD_GetExtendedFaultInformation();

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	}
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	if ($precondition_valid) {
		S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
		LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 }, { 'TriggerVoltage' => 6, 'SlopeType' => 'negative' } );
		LC_SetTRCscanner( [ $tcpar_pin . '::current' ], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
		LC_ConfigureTRCchannels(
			{
				'SamplingFrequency' => 20 * 1000,
				'MemorySize'        => 8 * 1024,
				'TriggerDelay'      => 0
			}
		);

		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( 'Activate plant mode 7.', 'AUTO_NBR' );

		#PD_ECUlogin();
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );
		S_wait_ms(100);

		S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);

		S_teststep( "Wait 10s.", 'AUTO_NBR' );
		S_wait_ms(10000);

		# set resistance function is defined at the end of this test case, labcar functions is not used
		S_teststep( "Set squib '$tcpar_pin' to $tcpar_resistance_ohm ohm.", 'AUTO_NBR' );
		SetResistance( $tcpar_pin, $tcpar_resistance_ohm, $tcpar_nbr_byte_of_sqmm );

		if ( defined $tcpar_pin_acl ) {
			S_teststep( "Send Disposal PWM on PIN '$tcpar_pin_acl'.", 'AUTO_NBR' );
			LC_ConnectLine($tcpar_pin_acl);
			LC_SendPWMDisposalStart($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
		}

		S_teststep( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );

		#PD_ECUlogin();
		S_wait_ms(100);
		PD_Prepare_electronic_firing();

		S_wait_ms(2000);

		S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
		LC_MeasureTraceAnalogStart();
		LC_MeasureTraceAnalogSendSWTrigger();

		S_wait_ms(200);

		S_teststep( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
		PD_Trigger_electronic_firing();

		S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
		S_wait_ms(200);

		$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
		LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
		S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

		S_teststep( "Set squib '$tcpar_pin' to default.", 'AUTO_NBR' );
		LC_SetResistance( $tcpar_pin, 'DEFAULT' );

		S_teststep( "Switch ECU off.", 'AUTO_NBR' );
		LC_ECU_Off();

		S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
		LC_ECU_On($tcpar_ubat);
		S_wait_ms('TIMER_ECU_READY');

		S_teststep( 'Deactivate plant mode 7.', 'AUTO_NBR' );

		#PD_ECUlogin();
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
		S_wait_ms(100);

		S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		S_teststep( "Evaluate squib firing for $tcpar_pin...", 'AUTO_NBR' );
		S_teststep_2nd_level( "Check number of detected firing pulses.",        'AUTO_NBR', 'firing_pulse_nbr' );
		S_teststep_2nd_level( "Check current of first detected firing pulse.",  'AUTO_NBR', 'current' );
		S_teststep_2nd_level( "Check duration of first detected firing pulse.", 'AUTO_NBR', 'duration' );
	}
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
	if ($precondition_valid) {

		# evaluate measured signal
		my $data_HoH = EVAL_importUNV("$main::REPORT_PATH/$unv_file_name");

		my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin . '::CURRENT', 0.5, 0.01, 'rising' );
		my $squareamplitude;
		my @datapoints;
		my $current_A;
		my $pulse_duration_ms;

		S_teststep_expected( "Nbr. of Firing pulses == 1", 'firing_pulse_nbr' );
		S_teststep_detected( "Nbr. of Firing pulses == $NumOfPulses", 'firing_pulse_nbr' );
		EVAL_evaluate_value( "Nbr. of Firing pulses", $NumOfPulses, '==', 1 );

		@datapoints = @{ $pulses->{"pulse0"}{'values'} };
		foreach my $datapoint (@datapoints) {
			$squareamplitude += ( $datapoint * $datapoint );
		}
		$squareamplitude /= scalar(@datapoints);
		$current_A = sqrt($squareamplitude);
		$current_A = sprintf( "%.3f", $current_A );
		S_teststep_expected( "I(pulse) >= '$tcpar_min_current_A' A in firing mode '$tcpar_firingMode'", 'current' );
		S_teststep_detected( "I(pulse) == '$current_A' A", 'current' );
		EVAL_evaluate_value( "I(pulse)", $current_A, '>=', $tcpar_min_current_A );

		$pulse_duration_ms =
		  $pulses->{"pulse0"}{'end'} - $pulses->{"pulse0"}{'start'};
		$pulse_duration_ms = $pulse_duration_ms / 1000;               # fix for wrong time base
		$pulse_duration_ms = sprintf( "%.2f", $pulse_duration_ms );
		S_teststep_expected( "t(pulse duration) >= '$tcpar_min_duration_ms' ms in firing mode '$tcpar_firingMode'", 'duration' );
		S_teststep_detected( "t(pulse duration) == '$pulse_duration_ms' ms", 'duration' );
		EVAL_evaluate_value( "t(pulse duration)", $pulse_duration_ms, '>=', $tcpar_min_duration_ms );
	}
	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {
	if ($precondition_valid) {
		if ( defined $tcpar_pin_acl ) {
			LC_DisconnectLine($tcpar_pin_acl);
			LC_SendPWMDisposalStop($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
		}
		LC_ResetTRCscanner();
	}
	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

sub SetResistance {
	my $pin       = shift;
	my $threshold = shift;
	my $nbr       = shift;

	my $dec_value_1 = sprintf( "%.1f", GetECUInternalResistance() );
	S_w2log( 3, "Initial internal Resistance for $pin: $dec_value_1" );

	S_w2log( 3, "Set Resistance of $pin to a value in the middle of internal and target value." );
	LC_SetResistance( $tcpar_pin, $dec_value_1 + ( ( $threshold - $dec_value_1 ) / 2 ) );
	S_wait_ms(500);

	my $dec_value_2 = sprintf( "%.1f", GetECUInternalResistance() );
	S_w2log( 3, "Internal Resistance for $pin: $dec_value_2" );
	my $threshold_diff = $dec_value_1 + ( ( $threshold - $dec_value_1 ) / 2 ) - $dec_value_2;
	S_w2log( 3, "Calculated threshold between internal resistance and TSG4 resistance: $threshold_diff" );

	LC_SetResistance( $tcpar_pin, $threshold + $threshold_diff );
	S_wait_ms(500);

	$dec_value_2 = sprintf( "%.1f", GetECUInternalResistance() );
	S_w2log( 3, "Internal Resistance for $pin: $dec_value_2" );

	return;
}

sub GetECUInternalResistance {
	my ( $label, $type, $calcResistance_Ohm );

	if ( $diagSimType == 3 ) {
		my $nbr1 = $asic_connectionCBR - 1;
		my $nbr2 = $asic_connectionIGH - 1;

		$label = "rb_sqmm_ResistanceValue_au16($nbr1)($nbr2)";
	}
	else {
		$label = "rb_sqmm_ResistanceValue_au16($calc_array_idx)";
	}

	my $filename = "$main::REPORT_PATH/" . S_get_TC_number() . "_TC_FL_Range_" . S_get_TC_parameter_name();
	$type = PD_get_type_from_name($label);

	PD_StartFastDiagName( $filename, [$label], [$type] );

	S_wait_ms(1000);

	PD_StopFastDiag();

	my $fd_data = PD_get_FDtrace($filename);
	PD_plot_FDtrace( $fd_data, $filename );

	my @values = EVAL_get_values_over_time( $fd_data, $label );

	my $sum;
	foreach (@values) { $sum += $_; }
	my $mean = $sum / @values;

	$calcResistance_Ohm = $mean / 100;

	S_w2log( 3, "Internal Resistance: $calcResistance_Ohm" );

	return $calcResistance_Ohm;
}

1;

__END__
