# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_FiringPulseWithFault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " record the firing pulses on each squib and check that all parameters are correct when a fault on the squib is active";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 record the firing pulses on each squib and check that all parameters are correct

=head1 TESTCASE DESCRIPTION

[parameter used]

    [initialisation]
    get temperature

    [stimulation & measurement]
    set scanner and transient recorder
    short <pin1> with <pin2>
    switch ECU on
    wait 10 sec
    send disposal PWM signal on PIN <pin_acl> if ACL is used
    prepare electronic firing using RB PD
    start transient recorder measurement
    trigger electronic firing using RB PD
    wait until transient recorder measurement is finished
    undo short
    evaluate squib firing for <pin1> ...
    switch ECU off

    [evaluation]
    evaluate squib firing for <pin1>
    - check number of detected firing pulses
    - check current of first detected firing pulse
    - check duration of first detected firing pulse
    send mail if not

    [finalisation]
    stop sending of disposal PWM signal if ACL is used
    reset scanner


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		--> battery voltage value
    SCALAR 'pin1'               --> ECU Pin1
    SCALAR 'pin2'               --> ECU Pin2
    SCALAR 'firingMode'		 	--> firing mode of squib
    SCALAR 'pin_acl'			 --> ACL Pin
    SCALAR 'source_acl'			 --> Source of ACL signal
    LIST   'readLabels'	 		--> check fire counter label
    
=head2 PARAMETER EXAMPLES

	[TC_FL_FiringPulse.AB1FD]
	purpose='$check fing pulses for AB1FD with electronic firing' 
	UBat       =12.7
	Pin1       = 'AB1FD-'
	Pin2       = 'AB2FD+'
	FiringMode ='mode VI'
	PinACL     = ACL
	SourceACL  = external
	ReadLabels = @('rb_sqmf_Firecounter_au16(4)')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin, $tcpar_pin1, $tcpar_pin2, $tcpar_readLabels, $unv_file_name );
my ( $tcpar_pin_acl, $tcpar_source_acl );
my @temperatures    = ();
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat       = GEN_Read_mandatory_testcase_parameter('UBat');
	$tcpar_pin1       = GEN_Read_mandatory_testcase_parameter('Pin1');
	$tcpar_pin2       = GEN_Read_mandatory_testcase_parameter('Pin2');
	$tcpar_readLabels = GEN_Read_optional_testcase_parameter( 'ReadLabels', 'byref' );
	$tcpar_pin_acl    = GEN_Read_optional_testcase_parameter('PinACL');
	$tcpar_source_acl = GEN_Read_optional_testcase_parameter('SourceACL');

	$tcpar_pin = $tcpar_pin1;
	chop $tcpar_pin;

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on and start diagnosis
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( [ $tcpar_pin . '::current' ], { 'SignalMode' => 'differential', 'VoltageRange' => 10 } );
	LC_ConfigureTRCchannels(
		{
			'SamplingFrequency' => 20 * 1000,
			'MemorySize'        => 64 * 1024,
			'TriggerDelay'      => 0
		}
	);

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Activate plant mode 7.', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );
	S_wait_ms(100);

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep( "Short $tcpar_pin1 with $tcpar_pin2.", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin1, $tcpar_pin2 ] );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	if ( defined $tcpar_pin_acl ) {
		S_teststep( "Send Disposal PWM on PIN '$tcpar_pin_acl'.", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_pin_acl);
		LC_SendPWMDisposalStart($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
	}

	S_teststep( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );

	#PD_ECUlogin();
	S_wait_ms(100);
	PD_Prepare_electronic_firing();

	S_wait_ms(2000);

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();
	LC_MeasureTraceAnalogSendSWTrigger();

	S_wait_ms(200);

	S_teststep( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
	PD_Trigger_electronic_firing();

	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms(5000);
	LC_ECU_Off();

	S_teststep( "Undo short.", 'AUTO_NBR' );
	LC_UndoShortLines();

	$unv_file_name = $main::TC_REPORT_NAME . '.txt.unv';
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name );
	S_w2rep( '<A HREF="./' . "$unv_file_name" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name" . '</A><br>' );

	S_teststep( "Evaluate squib firing for $tcpar_pin...", 'AUTO_NBR' );
	S_teststep_2nd_level( "Check number of detected firing pulses.", 'AUTO_NBR', 'firing_pulse_nbr' );

	S_teststep( "Switch ECU off.", 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( 'Deactivate plant mode 7.', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	S_wait_ms(100);

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	# evaluate measured signal
	my $data_HoH = EVAL_importUNV("$main::REPORT_PATH/$unv_file_name");

	my ( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin . '::CURRENT', 0.5, 0.01, 'rising' );
	my $squareamplitude;
	my @datapoints;
	my $current_A;
	my $pulse_duration_ms;

	S_teststep_expected( "Nbr. of Firing pulses == 1", 'firing_pulse_nbr' );
	S_teststep_detected( "Nbr. of Firing pulses == $NumOfPulses", 'firing_pulse_nbr' );
	EVAL_evaluate_value( "Nbr. of Firing pulses", $NumOfPulses, '==', 1 );

	@datapoints = @{ $pulses->{"pulse0"}{'values'} };
	foreach my $datapoint (@datapoints) {
		$squareamplitude += ( $datapoint * $datapoint );
	}
	$squareamplitude /= scalar(@datapoints);
	$current_A = sqrt($squareamplitude);
	$current_A = sprintf( "%.3f", $current_A );
	S_teststep_detected("I(pulse) == '$current_A' A");

	$pulse_duration_ms =
	  $pulses->{"pulse0"}{'end'} - $pulses->{"pulse0"}{'start'};
	$pulse_duration_ms = $pulse_duration_ms / 1000;               # fix for wrong time base
	$pulse_duration_ms = sprintf( "%.2f", $pulse_duration_ms );
	S_teststep_detected("t(pulse duration) == '$pulse_duration_ms' ms");

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {
	if ( defined $tcpar_pin_acl ) {
		LC_DisconnectLine($tcpar_pin_acl);
		LC_SendPWMDisposalStop($tcpar_pin_acl) unless $tcpar_source_acl eq 'external';
	}
	LC_ResetTRCscanner();

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
