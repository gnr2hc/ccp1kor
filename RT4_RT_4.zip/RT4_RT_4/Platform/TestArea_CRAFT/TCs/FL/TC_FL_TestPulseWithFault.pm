# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_TestPulseWithFault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that no test pulses are present when a fault is present (short2bat) ";

# our $PURPOSE = " test that no test pulses are present when a fault is present (short2gnd, short2bat, cross coupling) ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FL_TestPulseWithFault 

=head1 PURPOSE

 test that no test pulses are present when a fault is present (short2bat)

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:

    Ubat
    Pin

    [initialisation]
    get temperature
    

    [stimulation & measurement]
	1. set transient recorder
	2. switch ECU on
	3. apply short2gnd
	4. read fault recorder
	5. measure signal
	6. evaluate signal
	7. remove short2gnd
	
	8. set transient recorder
	9. switch ECU on
	10. apply short2bat
	11. read fault recorder
	12. measure signal
	13. evaluate signal
	14. remove short2bat
	
	15. set transient recorder
	16. apply cross coupling
	17. switch ECU on
	18. read fault recorder
	19. measure signal
	20. evaluate signal
	21. remove cross coupling
    

    [evaluation]
	6. check if no test pulses are present
	13. check if no test pulses are present
	20. check if no test pulses are present

    [finalisation]
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

    SCALAR 'ubat'          		 --> battery voltage value
    SCALAR 'pin'           		 --> ECU pin
    
=head2 PARAMETER EXAMPLES

	[TC_FL_TestPulseWithFault.BT1FD]
	purpose='$check test pulses for BT1FD' 
	Ubat=10.6
	Pin = 'BT1FD'
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my ( $tcpar_ubat, $tcpar_pin1, $tcpar_pin2, $unv_file_name_short2bat, $unv_file_name_short2batAIE );
my @temperatures = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin1 = GEN_Read_mandatory_testcase_parameter('Pin1');
	$tcpar_pin2 = GEN_Read_mandatory_testcase_parameter('Pin2');

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# switch ECU on
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	#PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	push( @temperatures, TEMP_get_temperature() );

	return 1;
}
### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Set scanner and transient recorder.", 'AUTO_NBR' );
	LC_SetTRCscanner( ['UBAT1'], { 'SignalMode' => 'differential', 'VoltageRange' => 20 } );
	LC_SetTRCscanner( [ "$tcpar_pin1" . '::current' ], { 'SignalMode' => 'differential', 'VoltageRange' => 5 } );
	LC_ConfigureTRCchannels( { 'SamplingFrequency' => 20 * 1000, 'MemorySize' => 256 * 1024, 'TriggerDelay' => 0 } );

	#	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	#    TRC_StartMeasurement();
	#
	#	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	#	LC_ECU_On();
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);
	#
	#	S_teststep("Short '$tcpar_pin1' to 'B-'" , 'AUTO_NBR' );
	#	TSG4_ShortLines( [$tcpar_pin1."-", 'B-'] );
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);
	#
	#	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	#	PD_ECUlogin();
	#	PD_GetExtendedFaultInformation();
	#
	#	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	#	TRC_SendSWTrigger();
	#
	#	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	#	S_wait_ms(15000);
	#
	#	S_teststep( "Check if no test pulses are present.", 'AUTO_NBR' , 'short2gnd' );
	#
	#	$unv_file_name_short2gnd = 'TC_FL_TestPulseWithFault_'.$tcpar_pin1.'_short2gnd.txt.unv';
	#	TRC_plot_values("$main::REPORT_PATH/".$unv_file_name_short2gnd);
	#    S_w2rep('<A HREF="./'."$unv_file_name_short2gnd".'" TYPE="text/unv">'."Click to view TRC trace $unv_file_name_short2gnd".'</A><br>');
	#
	#	S_teststep("Remove the short." , 'AUTO_NBR' );
	#	TSG4_UndoShortLines( );
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);
	#
	#	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	#	PD_ECUlogin();
	#	PD_GetExtendedFaultInformation();
	#
	#
	#	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	#	LC_ECU_Off();
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( "Short '$tcpar_pin1' to 'B+'", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin1 . "-", 'B+' ] );

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_GetExtendedFaultInformation();

	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms(15000);
	LC_MeasureTraceAnalogStop();

	S_teststep( "Check if no test pulses are present.", 'AUTO_NBR', 'short2bat' );

	$unv_file_name_short2bat = 'TC_FL_TestPulseWithFault_' . $tcpar_pin1 . '_short2bat.txt.unv';
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name_short2bat );
	S_w2rep( '<A HREF="./' . "$unv_file_name_short2bat" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name_short2bat" . '</A><br>' );

	S_teststep( "Remove the short.", 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_GetExtendedFaultInformation();

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

####################

	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogStart();

	S_teststep( "Short '$tcpar_pin1' to 'B+'", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_pin1 . "-", 'B+' ] );

	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_GetExtendedFaultInformation();

	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	LC_MeasureTraceAnalogSendSWTrigger();

	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	S_wait_ms(15000);
	LC_MeasureTraceAnalogStop

	  S_teststep( "Check if no test pulses are present.", 'AUTO_NBR', 'short2batAIE' );

	$unv_file_name_short2batAIE = 'TC_FL_TestPulseWithFault_' . $tcpar_pin1 . '_short2batAIE.txt.unv';
	LC_MeasureTraceAnalogPlotValues( "$main::REPORT_PATH/" . $unv_file_name_short2batAIE );
	S_w2rep( '<A HREF="./' . "$unv_file_name_short2batAIE" . '" TYPE="text/unv">' . "Click to view TRC trace $unv_file_name_short2batAIE" . '</A><br>' );

	S_teststep( "Remove the short.", 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( 'Read fault recorder', 'AUTO_NBR' );

	#PD_ECUlogin();
	PD_GetExtendedFaultInformation();

	S_teststep( 'Switch ECU off.', 'AUTO_NBR' );
	LC_ECU_Off();

	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	S_wait_ms(10000);

####################

	#	S_teststep( "Start transient recorder measurement.", 'AUTO_NBR' );
	#    TRC_StartMeasurement();
	#
	#	S_teststep("Short '$tcpar_pin1' to '$tcpar_pin2'" , 'AUTO_NBR' );
	#	TSG4_ShortLines( [$tcpar_pin1."-", $tcpar_pin2."+",] );
	#
	#	S_teststep( "Wait 5s.", 'AUTO_NBR' );
	#	S_wait_ms(5000);
	#
	#	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	#	LC_ECU_On();
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);
	#
	#	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	#	PD_ECUlogin();
	#	PD_GetExtendedFaultInformation();
	#
	#	S_teststep( "Send SW Trigger to transient recorder.", 'AUTO_NBR' );
	#	TRC_SendSWTrigger();
	#
	#	S_teststep( "Wait until transient recorder measurement is finished.", 'AUTO_NBR' );
	#	S_wait_ms(15000);
	#
	#	S_teststep( "Check if no test pulses are present.", 'AUTO_NBR' , 'crosscoupling' );
	#
	#	$unv_file_name_crosscoupling = 'TC_FL_TestPulseWithFault_'.$tcpar_pin1.'_crosscoupling.txt.unv';
	#	TRC_plot_values("$main::REPORT_PATH/".$unv_file_name_crosscoupling);
	#    S_w2rep('<A HREF="./'."$unv_file_name_crosscoupling".'" TYPE="text/unv">'."Click to view TRC trace $unv_file_name_crosscoupling".'</A><br>');
	#
	#	S_teststep("Remove the short." , 'AUTO_NBR' );
	#	TSG4_UndoShortLines( );
	#
	#	S_teststep( "Wait 10s.", 'AUTO_NBR' );
	#	S_wait_ms(10000);
	#
	#	S_teststep( 'Read fault recorder', 'AUTO_NBR' );
	#	PD_ECUlogin();
	#	PD_GetExtendedFaultInformation();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
	my ( $NumOfPulses, $pulses, $data_HoH );

	# evaluate measured signal
	#    $data_HoH = EVAL_importUNV("$main::REPORT_PATH/".$unv_file_name_short2gnd);
	#    ($NumOfPulses) = EVAL_get_signal_pulses( $data_HoH , $tcpar_pin1.'::CURRENT', 0.05, 0.01, 'rising');
	#	S_teststep_expected( "Detected testpulses: '0'.", 'short2gnd' );
	#	S_teststep_detected( "Detected testpulses: '$NumOfPulses'.", 'short2gnd' );
	#	EVAL_evaluate_value( "Testpulses for '$tcpar_pin1' during 'short2gnd'", $NumOfPulses, '==', 0 );

	$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name_short2bat );
	( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin1 . '::CURRENT', 0.05, 0.01, 'rising' );
	S_teststep_expected( "Detected testpulses: '0'.", 'short2bat' );
	S_teststep_detected( "Detected testpulses: '$NumOfPulses'.", 'short2bat' );
	EVAL_evaluate_value( "Testpulses for '$tcpar_pin1' during 'short2bat'", $NumOfPulses, '==', 0 );

##########

	$data_HoH = EVAL_importUNV( "$main::REPORT_PATH/" . $unv_file_name_short2batAIE );
	( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_pin1 . '::CURRENT', 0.05, 0.01, 'rising' );
	S_teststep_expected( "Detected testpulses: '0'.", 'short2batAIE' );
	S_teststep_detected( "Detected testpulses: '$NumOfPulses'.", 'short2batAIE' );
	EVAL_evaluate_value( "Testpulses for '$tcpar_pin1' during 'short2batAIE'", $NumOfPulses, '==', 0 );

##########

	#    $data_HoH = EVAL_importUNV("$main::REPORT_PATH/".$unv_file_name_crosscoupling);
	#    ($NumOfPulses, $pulses) = EVAL_get_signal_pulses( $data_HoH , $tcpar_pin1.'::CURRENT', 0.05, 0.01, 'rising');
	#    S_teststep_expected( "Detected testpulses: '0'.", 'crosscoupling' );
	#	S_teststep_detected( "Detected testpulses: '$NumOfPulses'.", 'crosscoupling' );
	#	EVAL_evaluate_value( "Testpulses for '$tcpar_pin1' during 'crosscoupling'", $NumOfPulses, '==', 0 );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_ResetTRCscanner();

	# switch ECU off
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep_detected("TEMP: $temperatures[0]");
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

1;

__END__
