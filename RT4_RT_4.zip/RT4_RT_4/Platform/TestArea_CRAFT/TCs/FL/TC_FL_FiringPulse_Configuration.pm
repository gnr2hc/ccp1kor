# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_FiringPulse_Configuration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### INCLUDE ENGINE MODULES ####
use LIFT_general;    # this is always required
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_FaultMemory;
use LIFT_QuaTe;
use LIFT_crash_simulation;
use LIFT_can_access;

#use FuncLib_CREIS_Framework;
use LIFT_labcar;
##################################

our $PURPOSE = "test that a not configured but connected squib is not firing when a crash is detected";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FL_FiringPulse_Configuration  

=head1 PURPOSE

    test that a not configured but connected squib is not firing when a crash is detected

=head1 TESTCASE DESCRIPTION

=head1 PARAMETER

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES

    [TC_FL_FiringPulse_Configuration.BT1FD]
    purpose        = 'check not configured but connected squib is not firing in case of crash for BT1FD'
    Ubat           = 15.4
    Pin1           = 'BT1FD'
    FLTmand        = 'rb_sqm_UnexpectedBT1FD_flt'
    CreisInputFile = 'C:\TurboLIFT\AB12\config\Tools\CREIS\M031003\SCI\SCI_M03_10_3_RT4_04B009_20180907.mdb'
    CrashName      = 'PT_Ramp_CA_BT;1'
    CrashNumber    = 6
    State          = '1'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $tcpar_CrashName, $tcpar_State, $tcpar_CrashNumber, $tcpar_CreisInputFile, $tcpar_Ubat, $tcpar_FLTmand, $tcpar_Pin, $ignoreMissingEnvironments );
my ( $crashData_href, $fltmemAfterInjectionConfigured, $fltmemBeforeInjectionConfigured, $fltmemAfterInjectionDeconfigured, $fltmemBeforeInjectionDeconfigured );
my ( $plotfilenameConfig, $plotfilenameDeconfig );

#### TC PARAMETERS #####
sub TC_set_parameters {

	$tcpar_CreisInputFile = S_read_mandatory_testcase_parameter('CreisInputFile');

	$tcpar_CrashNumber = S_read_optional_testcase_parameter('CrashNumber');
	undef $tcpar_CrashName;
	$tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

	$tcpar_State = S_read_optional_testcase_parameter( 'State', 'byref', 1 );

	$tcpar_Ubat = S_read_optional_testcase_parameter( 'Ubat', 'byref', 'U_BATT_DEFAULT' );

	$tcpar_Pin = S_read_mandatory_testcase_parameter('Pin1');

	$tcpar_FLTmand = S_read_mandatory_testcase_parameter('FLTmand');

	if ( $tcpar_Ubat !~ /([0-9]+)/ ) {
		$tcpar_Ubat = S_get_contents_of_hash( [ 'VEHICLE', $tcpar_Ubat ] );
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	# read next crash from MDS-Result-File (read environment states + velocities)
	if ( defined $tcpar_CrashNumber ) {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				"CRASHINDEX"     => $tcpar_CrashNumber,
				"STATEVARIATION" => $tcpar_State,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_CreisInputFile,
			}
		);
	}
	else {
		$crashData_href = CSI_GetCrashDataFromMDS(
			{
				'CRASHNAME'      => $tcpar_CrashName,
				"STATEVARIATION" => $tcpar_State,
				"MDSTYPE"        => "MDSNG",
				"RESULTDB"       => $tcpar_CreisInputFile,
			}
		);
	}

	# prepare crash
	CSI_LoadAllData2Simulator($crashData_href);
	CA_simulation_start();

	# power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	# 2. set environment states + velocities
	#$ignoreMissingEnvironments = S_get_exec_option('CREIS_IgnoreMissingEnvironments') if S_check_exec_option('CREIS_IgnoreMissingEnvironments');
	CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'strict' );    #unless $ignoreMissingEnvironments;
	                                                                        #CSI_PrepareEnvironment( $crashData_href, 'before_crash', 'relaxed' ) if $ignoreMissingEnvironments;

	S_wait_ms(500);
	CSI_PrepareEnvironment( $crashData_href, 'before_crash_same_cycle', 'strict' );
	S_wait_ms(500);

	LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.8 );

	#    CREIS_PrepareMeasurementsAndReporting($crashData_href);

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_Fault_Memory();
	S_wait_ms(200);
	PRD_Clear_EDR();
	S_wait_ms(500);

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	# start all measurement before ECU is switched on, so that network trace contains the full ECU cycle
	LC_MeasureTraceDigitalStart();

	#    CREIS_StartAllMeasurements();

	S_teststep( "'$tcpar_Pin' is configured, crash is injected and deployment is expected", 'AUTO_NBR' );

	S_teststep_2nd_level( "Switch ECU on with '$tcpar_Ubat V' and wait until ECU is ready.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Read fault memory before crash", 'AUTO_NBR', 'FMBeforeConfigured' );
	$fltmemBeforeInjectionConfigured = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "Start to inject the crash.", 'AUTO_NBR', 'CrashConfigured' );
	CSI_TriggerCrash();

	# wait for the crash duration
	S_wait_ms( $crashData_href->{METADATA}{CRASHDURATION_MS} );

	#    CREIS_WaitUntillRecordingIsFinished();

	$fltmemAfterInjectionConfigured = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "Reset environments which need reset.", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

	S_teststep_2nd_level( "Call project specific post crash actions...", 'AUTO_NBR' );
	CSI_PostCrashActions($crashData_href);

	S_teststep_2nd_level( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_set_timer_zero("ECU_OFF");

	LC_MeasureTraceDigitalStop();

	#$plotfilenameConfig = $main::TC_REPORT_NAME . '_squib_configured.txt.unv';
	$plotfilenameConfig = S_get_TC_number() . '_Squib_' . $tcpar_Pin . '_configured.txt.unv';
	LC_MeasureTraceDigitalPlotValues( "$main::REPORT_PATH/" . $plotfilenameConfig );
	S_w2rep( '<A HREF="./' . "$plotfilenameConfig" . '" TYPE="text/unv">' . "Click to view TRC trace $plotfilenameConfig" . '</A><br>' );

	#    CREIS_StopAllMeasurements();

#####

	S_teststep( "'$tcpar_Pin' is deconfigured, crash is injected and no deployment is expected", 'AUTO_NBR' );

	S_teststep_2nd_level( "Switch ECU on with '$tcpar_Ubat V' and wait until ECU is ready.", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat);
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Deconfigure squib '$tcpar_Pin' ", 'AUTO_NBR' );
	PRD_Set_Device_Configuration( { $tcpar_Pin => 'clear_Configure' } );

	S_teststep_2nd_level( "Clear EDR and Fault Memory", 'AUTO_NBR' );
	PRD_Clear_Fault_Memory();
	S_wait_ms(200);
	PRD_Clear_EDR_NOERROR();
	S_wait_ms(200);
	PRD_Clear_Fault_Memory();
	S_wait_ms(200);

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	LC_MeasureTraceDigitalStart();

	#    CREIS_StartAllMeasurements();

	S_teststep_2nd_level( "Read fault memory before crash", 'AUTO_NBR', 'FMBeforeDeconfigured' );
	$fltmemBeforeInjectionDeconfigured = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "Start to inject the crash.", 'AUTO_NBR', 'CrashDeconfigured' );
	CSI_TriggerCrash();

	# wait for the crash duration
	S_wait_ms( $crashData_href->{METADATA}{CRASHDURATION_MS} );

	#    CREIS_WaitUntillRecordingIsFinished();

	$fltmemAfterInjectionDeconfigured = LIFT_FaultMemory->read_fault_memory('Bosch');

	S_teststep_2nd_level( "Reset environments which need reset.", 'AUTO_NBR' );
	CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

	S_teststep_2nd_level( "Call project specific post crash actions...", 'AUTO_NBR' );
	CSI_PostCrashActions($crashData_href);

	S_teststep_2nd_level( "Configure squib '$tcpar_Pin' ", 'AUTO_NBR' );
	PRD_Set_Device_Configuration( { $tcpar_Pin => 'set_Configure' } );

	S_teststep_2nd_level( "Switch ECU off", 'AUTO_NBR' );
	LC_ECU_Off();
	S_set_timer_zero("ECU_OFF");

	LC_MeasureTraceDigitalStop();

	#$plotfilenameDeconfig = $main::TC_REPORT_NAME . '_squib_deconfigured.txt.unv';
	$plotfilenameDeconfig = S_get_TC_number() . '_Squib_' . $tcpar_Pin . '_deconfigured.txt.unv';

	LC_MeasureTraceDigitalPlotValues( "$main::REPORT_PATH/" . $plotfilenameDeconfig );
	S_w2rep( '<A HREF="./' . "$plotfilenameDeconfig" . '" TYPE="text/unv">' . "Click to view TRC trace $plotfilenameDeconfig" . '</A><br>' );

	#    CREIS_StopAllMeasurements();

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	my ( $verdict, $NumOfPulses, $pulses, $data_HoH );

	S_teststep( "Evaluation for configured $tcpar_Pin", 'NO_AUTO_NBR' );
	$verdict = $fltmemBeforeInjectionConfigured->evaluate_faults( {}, 'FMBeforeConfigured' );

	$data_HoH = EVAL_importUNV("$main::REPORT_PATH/$plotfilenameConfig");
	if ( EVAL_get_signal_availability( $data_HoH, $tcpar_Pin ) eq 'present' ) {
		( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_Pin );
	}
	else {
		$NumOfPulses = 0;
		$pulses      = undef;
	}

	S_teststep_expected( "$tcpar_Pin is deployed", 'CrashConfigured' );
	S_teststep_detected( "$tcpar_Pin has $NumOfPulses firing pulse", 'CrashConfigured' );
	EVAL_evaluate_value( "Nbr. of firing pulses", $NumOfPulses, '==', 1 );

	S_teststep( "Evaluation for deconfigured $tcpar_Pin", 'NO_AUTO_NBR' );
	my $expectedFaults = { $tcpar_FLTmand => { 'DecodedStatus' => { 'TestFailed' => 1, }, } };
	$verdict = $fltmemBeforeInjectionDeconfigured->evaluate_specific_faults( $expectedFaults, 'FMBeforeDeconfigured' );

	$data_HoH = EVAL_importUNV("$main::REPORT_PATH/$plotfilenameDeconfig");
	if ( EVAL_get_signal_availability( $data_HoH, $tcpar_Pin ) eq 'present' ) {
		( $NumOfPulses, $pulses ) = EVAL_get_signal_pulses( $data_HoH, $tcpar_Pin );
	}
	else {
		$NumOfPulses = 0;
		$pulses      = undef;
	}

	S_teststep_expected( "$tcpar_Pin is not deployed", 'CrashDeconfigured' );
	S_teststep_detected( "$tcpar_Pin has $NumOfPulses firing pulse", 'CrashDeconfigured' );
	EVAL_evaluate_value( "Nbr. of firing pulses", $NumOfPulses, '==', 0 );

	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	LC_ECU_On();

	S_wait_ms('TIMER_ECU_READY');

	PRD_Clear_EDR( { timeout_ms => 15000 } );

	S_wait_ms(2000);

	PRD_Clear_Fault_Memory();

	return 1;
}

1;

__END__

