# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_CREIS_StandardTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#### INCLUDE ENGINE MODULES ####
use LIFT_general;    # this is always required
use LIFT_evaluation;
use LIFT_ProdDiag;
use LIFT_QuaTe;
use LIFT_crash_simulation;
use LIFT_can_access;
use FuncLib_CREIS_Framework;
use FuncLib_TNT_CREIS_Framework;
use LIFT_labcar;
##################################

our $PURPOSE = "Standard Crash Injection test ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#-> update documentation that somebody else can use the test without asking you
#-> delete parameter section if no paramteres are used
#-> note that POD documentation needs entirely empty lines before and after keywords (e.g. =head1, =cut ...)

=head1 TESTCASE MODULE

TC_CREIS_StandardTest

=head1 PURPOSE

=head1 TESTCASE DESCRIPTION

=head1 PARAMETER

=head2 PARAMETER NAMES

=head2 PARAMETER EXAMPLES


=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#-> define variables here which sall be used across subroutines
#-> test case parameters shall start with tcpar_
my ( $tcpar_CrashName, $tcpar_State, $tcpar_CrashNumber, $tcpar_CreisInputFile, $tcpar_Ubat, $tcpar_ignoreAllErrors, $tcpar_FLT_mand, $tcpar_FLT_opt );
my ( $crashData_href, $fltmemAfterInjection, $errorHandlingPrepEnv, $failedHandlingEnvCheck, $errorHandlingEnvCheck, $skipEnvironmentCombination );

sub TC_set_parameters {

    $tcpar_CreisInputFile = S_read_mandatory_testcase_parameter('CreisInputFile');

    $tcpar_CrashNumber = S_read_optional_testcase_parameter('CrashNumber');

    undef $tcpar_CrashName;
    $tcpar_CrashName = S_read_mandatory_testcase_parameter('CrashName') unless ( defined $tcpar_CrashNumber );

    $tcpar_State = S_read_optional_testcase_parameter( 'State', 'byref', 1 );

    $tcpar_Ubat = S_read_optional_testcase_parameter( 'Ubat', 'byref', 'U_BATT_DEFAULT' );

    my $ignoreFailedEnvironmentChecks  = S_check_exec_option('CREIS_IgnoreFailedEnvironmentChecks')  ? S_get_exec_option('CREIS_IgnoreFailedEnvironmentChecks')  : 0;
    my $ignoreMissingEnvironmentChecks = S_check_exec_option('CREIS_IgnoreMissingEnvironmentChecks') ? S_get_exec_option('CREIS_IgnoreMissingEnvironmentChecks') : 1;
    $failedHandlingEnvCheck = $ignoreFailedEnvironmentChecks  ? 'relaxed' : 'strict';
    $errorHandlingEnvCheck  = $ignoreMissingEnvironmentChecks ? 'relaxed' : 'strict';

    my $ignoreMissingEnvironments = S_get_exec_option('CREIS_IgnoreMissingEnvironments') if S_check_exec_option('CREIS_IgnoreMissingEnvironments');
    $errorHandlingPrepEnv = $ignoreMissingEnvironments ? 'relaxed' : 'strict';

    return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

    # 1. read next crash from MDS-Result-File (read environment states + velocities)
    $crashData_href = CSI_GetCrashDataFromMDS(
        {
            "CRASHINDEX"     => $tcpar_CrashNumber,
            'CRASHNAME'      => $tcpar_CrashName,
            "STATEVARIATION" => $tcpar_State,
            "MDSTYPE"        => "MDSNG",
            "RESULTDB"       => $tcpar_CreisInputFile,
        }
    );

    $skipEnvironmentCombination = CREIS_CheckEnvironmentCombinationSkip($crashData_href);
    
    return 1 if $skipEnvironmentCombination;
    
    # prepare crash
    CSI_LoadAllData2Simulator($crashData_href);
    CA_simulation_start();

    # power ON the ECU
    LC_ECU_On();
    CREIS_WaitEcuReady();

    # 2. set environment states + velocities
    CSI_PrepareEnvironment( $crashData_href, 'before_crash', $errorHandlingPrepEnv );

    CREIS_Clear_EDR();
    
    unless (PRD_Clear_Fault_Memory_NOERROR( )){
        S_wait_ms(5000);
        PRD_Clear_Fault_Memory( );
    }

    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    LC_ECU_On();
    CREIS_WaitEcuReady();

    unless (CSI_VerifyEnvironment( $crashData_href, 'before_crash', $failedHandlingEnvCheck, $errorHandlingEnvCheck )){
        CREIS_StoreFaultMemory('AfterVerifyEnvironment');
    }
    
    CREIS_PrepareMeasurementsAndReporting($crashData_href);

    unless (PRD_Clear_Fault_Memory_NOERROR( )){
        S_wait_ms(5000);
        PRD_Clear_Fault_Memory( );
    }

    S_wait_ms(2000);

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    return 1 if $skipEnvironmentCombination;
    
    # start all measurement before ECU is switched on, so that network trace contains the full ECU cycle
    CREIS_StartAllMeasurements();

    # power ON the ECU
    S_teststep( "Switch ECU on", 'AUTO_NBR' );
    LC_ECU_On($tcpar_Ubat);
    S_set_timer_zero ( "ECU_On" );
    CREIS_LogTestCaseEvent("ECU_On");

    # wait for ECU ready
    S_teststep( "Wait until ECU is ready.", 'AUTO_NBR' );
    CREIS_WaitEcuReady();

    CSI_PrepareEnvironment( $crashData_href, 'before_crash_same_cycle', $errorHandlingPrepEnv );
    CREIS_StoreFaultMemory('BeforeCrash');
    CREIS_DumpNVMData('BeforeCrash');
    CREIS_ReadPdLabels('BeforeCrash');
    CREIS_ReadEcuMode('BeforeCrash');
    CREIS_ReadSquibResistance( );
    CSI_VerifyEnvironment( $crashData_href, 'before_crash_same_cycle', $failedHandlingEnvCheck, $errorHandlingEnvCheck );
    
    S_teststep( "Wait until ECU is in steady state (15s after ECU on).", 'AUTO_NBR' );
    S_wait_until_timer_ms ( 15000 , "ECU_On" );

    CREIS_RuntimeBeforeCrash();
    CREIS_StartFastDiagTrace();

    # Inject the crash
    S_teststep( "Start to inject the crash.", 'AUTO_NBR' );
    CREIS_LogTestCaseEvent("Inject_Crash");
    CSI_TriggerCrash();

    # wait for the crash duration
    CREIS_WaitUntillRecordingIsFinished();

    CREIS_StopFastDiagTrace();
    CREIS_RuntimeAfterCrash();
    CREIS_ReadFireCounter();
    CREIS_ReadPdLabels('AfterCrash');
    CREIS_ReadEcuMode('AfterCrash');
    
    $fltmemAfterInjection = CREIS_StoreFaultMemory('AfterCrash');
    CREIS_ReadPD_EDR();
    S_wait_ms(2000);
    CREIS_DumpNVMData('AfterCrash');

    S_teststep( "Reset environments which need reset.", 'AUTO_NBR' );
    CSI_PrepareEnvironment( $crashData_href, 'after_crash', 'relaxed' );

    S_teststep( "Call project specific post crash actions...", 'AUTO_NBR' );
    CSI_PostCrashActions($crashData_href);

    S_teststep( "Switch ECU off", 'AUTO_NBR' );
    LC_ECU_Off();
    S_set_timer_zero("ECU_OFF");

    CREIS_StopAllMeasurements();

    return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {
    return 1 if $skipEnvironmentCombination;
    
    CREIS_EvaluateMeasurements($crashData_href);
    CREIS_EvaluateExtendedRuntime();
    CREIS_EvaluateFaultMemory($crashData_href);
    CREIS_StoreFastDiagTrace();

    return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

    CREIS_FinishReporting($crashData_href, $skipEnvironmentCombination);
    
    return 1 if $skipEnvironmentCombination;
    
    S_wait_until_timer_ms( S_get_contents_of_hash( [ 'TIMER', 'TIMER_ECU_OFF' ] ), "ECU_OFF" );

    return 1;
}

1;

__END__

