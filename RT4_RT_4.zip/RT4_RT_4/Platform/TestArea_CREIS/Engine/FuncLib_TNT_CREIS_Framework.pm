# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_TNT_CREIS_Framework;

use strict;
use warnings;
use LIFT_general;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use LIFT_ProdDiag;
use FuncLib_CREIS_HelperFunctions;
use Import::Into;

use Exporter;

BEGIN {
    our @ISA    = qw(Exporter);
    our @EXPORT = qw(
      CREIS_Clear_EDR
      CREIS_EvaluateFaultEntry
      CREIS_EvaluateNetSignal
      CREIS_EvaluatePWMSignal
      CREIS_EvaluateSlope
      CREIS_EvaluateSquibFiring
      CREIS_StartSpecificMeasurements
      CREIS_StopSpecificMeasurements
    );
}

=head1 NAME

FuncLib_TNT_CREIS_Framework

=head1 SYNOPSIS

    Should not be accessed directly.
    Access to the functions happens from FuncLib_CREIS_Framework which is called by TCs. 

=head1 DESCRIPTION

This module provides generic functions for CREIS measurement and evaluation.
All functions in this module can be overwritten by functions with the same name in FuncLib_CustLib_CREIS_Framework and/or FuncLib_Project_CREIS_Framework
if they are exported in one of those modules.

=cut

=head2 import
    
There is no builtin import function. It is just an ordinary method (subroutine) defined (or inherited) by modules that wish to export names to another module.
The use function calls the import method for the package used. See also use, perlmod, and Exporter. When using this builtin import Exporter's import method is
no longer called, but Exporter has a special method, 'export_to_level' which is used in situations where you can't directly call Exporter's import method.

http://perldoc.perl.org/Exporter.html

=cut

sub import {
    my @args   = @_;
    my $caller = caller;

    FuncLib_TNT_CREIS_Framework->export_to_level( 1, @args );

    # optional CustLib module (will only be imported if *.pm file exists)
    eval { require FuncLib_CustLib_CREIS_Framework; 1; };

    if ( $@ =~ /Can't locate FuncLib_CustLib_CREIS_Framework.pm in \@INC.*/ ) {
        S_w2log( 3, "FuncLib_CREIS_Framework: no 'FuncLib_CustLib_CREIS_Framework' found. This is OK if there are no CustLib specific functions in CREIS Framework." );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_CustLib_CREIS_Framework' : $@", 112 );
    }
    else {
        'FuncLib_CustLib_CREIS_Framework'->import::into($caller);
    }

    # optional Project module (will only be imported if *.pm file exists)
    eval { require FuncLib_Project_CREIS_Framework; 1; };

    if ( $@ =~ /Can't locate FuncLib_Project_CREIS_Framework.pm in \@INC.*/ ) {
        S_w2log( 3, "FuncLib_CREIS_Framework: no 'FuncLib_Project_CREIS_Framework' found. This is OK if there are no project specific functions in CREIS Framework." );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_Project_CREIS_Framework' : $@", 112 );
    }
    else {
        'FuncLib_Project_CREIS_Framework'->import::into($caller);
    }

    return 1;
}

=head2 CREIS_Clear_EDR

=cut

sub CREIS_Clear_EDR {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_Clear_EDR( )', @args );

    PRD_Clear_EDR( { timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER' } );

    return 1;
}

=head2 CREIS_EvaluateSquibFiring

=cut

sub CREIS_EvaluateSquibFiring {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateSquibFiring($deviceName, $crashData_href, $callType , $settings_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;
    my $callType       = shift @args;
    my $settings_href  = shift @args;
    my ( $pulses_href, $numOfPulses, $firingTimes_href, $actualFiringTime_ms, $firing_state_href, $detectedFiringDuration_ms );
    my ( $measureBy, @succeededPulses );

    $actualFiringTime_ms       = "-";
    $detectedFiringDuration_ms = "-";

    $measureBy = $settings_href->{MeasureBy};
    my $deviceNameALIAS = $settings_href->{'ALIAS'};

    # handle all different combinations here (LCT, TRC)(SimDev, AdditionalEvaluations)
    if ( $measureBy eq "trace_digital" ) {
        $firingTimes_href = LC_MeasureTraceDigitalGetValues( [$deviceNameALIAS] );

        if ( EVAL_get_signal_availability( $firingTimes_href, $deviceNameALIAS ) eq 'present' ) {
            ( $numOfPulses, $pulses_href ) = EVAL_get_signal_pulses( $firingTimes_href, $deviceNameALIAS );
        }
        else {
            $numOfPulses = 0;
            $pulses_href = undef;
        }
    }
    elsif ( $measureBy eq "trace_analog" ) {
        my $firingCurrentThreshold_A = $settings_href->{'FiringCurrentThreshold_A'};

        $firingTimes_href = LC_MeasureTraceAnalogGetValues( [$deviceNameALIAS], 0.01 );

        ( $numOfPulses, $pulses_href ) = EVAL_get_signal_pulses( $firingTimes_href, $deviceNameALIAS, $firingCurrentThreshold_A );
    }
    else {
        S_set_error("Measure by '$measureBy' currently not supported for device '$deviceName'.");
        return 0;
    }

    # check and delete peaks
    foreach my $pulse ( 0 .. $numOfPulses - 1 ) {
        my $pulse_start_ms = $pulses_href->{ 'pulse' . $pulse }{'start'};
        my $pulse_end_ms   = $pulses_href->{ 'pulse' . $pulse }{'end'};
        my $duration_ms    = $pulse_end_ms - $pulse_start_ms;
        S_w2log( 4, "Pulse$pulse: start '$pulse_start_ms ms', end '$pulse_end_ms ms', duration '$duration_ms ms' " );
        if ( $duration_ms > 0.010 ) {
            push( @succeededPulses, $pulse );
        }
        else {
            S_set_warning("Pulse($pulse) is a peak (with duration_ms: '$duration_ms') and has been removed from CREIS evaluation.\n");
        }
    }

    $actualFiringTime_ms = $pulses_href->{ 'pulse' . $succeededPulses[0] }{'start'} if scalar(@succeededPulses);
    $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms );

    # add FireCounterData (from measurement hash)
    my $filenames_href = FLC_getFilename('FireCounter');
    $firing_state_href->{FireCounter_HighLevel_ms} = $filenames_href->{$deviceName}{value_high_level_ms} if exists $filenames_href->{$deviceName} and defined $filenames_href->{$deviceName}{value_high_level_ms};
    $firing_state_href->{FireCounter_LowLevel_ms}  = $filenames_href->{$deviceName}{value_low_level_ms}  if exists $filenames_href->{$deviceName} and defined $filenames_href->{$deviceName}{value_low_level_ms};

    $filenames_href = FLC_getFilename('SquibResistance');
    $firing_state_href->{SquibResistance_ohm} = $filenames_href->{$deviceName}{value_ohm} if exists $filenames_href->{$deviceName} and defined $filenames_href->{$deviceName}{value_ohm};

    # add calculated Duration (from measurement hash)
    $detectedFiringDuration_ms = $pulses_href->{ 'pulse' . $succeededPulses[0] }{'end'} - $pulses_href->{ 'pulse' . $succeededPulses[0] }{'start'} if scalar(@succeededPulses);
    $detectedFiringDuration_ms = sprintf( "%.3f", $detectedFiringDuration_ms ) unless $detectedFiringDuration_ms eq "-";
    $firing_state_href->{DetectedFiringDuration_ms} = $detectedFiringDuration_ms;

    FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

    return 1;
}

=head2 CREIS_EvaluateSlope

only for 'trace_analog'

=cut

sub CREIS_EvaluateSlope {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateSlope($deviceName, $crashData_href, $callType , $settings_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;
    my $callType       = shift @args;
    my $settings_href  = shift @args;
    my ( $pulses_href, $numOfPulses, $firingTimes_href, $actualFiringTime_ms, $firing_state_href );
    my ( $measureBy, @succeededPulses );

    $actualFiringTime_ms = "-";

    $measureBy = $settings_href->{MeasureBy};

    unless ( $measureBy eq "trace_analog" ) {
        S_set_error("Measure by '$measureBy' currently not supported for device '$deviceName'.");
        return 0;
    }

    my $slopeThreshold_V = $settings_href->{'SlopeThreshold_V'};
    my $slopeType        = $settings_href->{'SlopeType'};
    my $operator;
    my $deviceNameALIAS = $settings_href->{'ALIAS'};

    if ( lc $slopeType eq 'rising' or lc $slopeType eq 'positive' ) {
        $operator = ">";
    }
    elsif ( lc $slopeType eq 'falling' or lc $slopeType eq 'negative' ) {
        $operator = "<";
    }
    else {
        S_set_error("\$slopeType '$slopeType' not in specified range (rising|positive|falling|negative).");
        return 0;
    }

    $firingTimes_href = LC_MeasureTraceAnalogGetValues( [$deviceNameALIAS], 0.01 );

    $actualFiringTime_ms = EVAL_get_time_when( $firingTimes_href, $deviceNameALIAS, $operator, $slopeThreshold_V );

    $actualFiringTime_ms = "-" if ( $actualFiringTime_ms < 0 );

    $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms );

    FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

    return 1;
}

=head2 CREIS_EvaluateNetSignal

=cut

sub CREIS_EvaluateNetSignal {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateNetSignal($deviceName, $crashData_href, $callType , $settings_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;
    my $callType       = shift @args;
    my $settings_href  = shift @args;
    my ( $actualFiringTime_ms, $firing_state_href, $simDevOverwritten );

    # handle all different combinations here (LCT, TRC)(SimDev, AdditionalEvaluations)
    my $isDeployed          = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'};
    my $netSignalTimeZero_s = FLC_getNetSignalTimeZero();

    my $netSignal_href = FLC_getNetSignal_dataref( $settings_href->{'Signal'}, $settings_href->{'MeasureBy'} );

    if ( defined $netSignalTimeZero_s ) {
        if ( defined $netSignal_href ) {
            my $signal_time_s = EVAL_get_time_when( $netSignal_href, $settings_href->{'Signal'}, $settings_href->{'Operator'}, $settings_href->{'Value'}, $netSignalTimeZero_s );

            $actualFiringTime_ms = ( $signal_time_s - $netSignalTimeZero_s ) * 1000 unless $signal_time_s == -1;

            # handling for HigherPrioSimDevs option
            if ( $signal_time_s == -1 and ( $isDeployed == $FIRE_SIMDEVICE or $isDeployed == $CANFIRE_SIMDEVICE ) and ref( $settings_href->{'HigherPrioSimDevs'} ) eq "ARRAY" ) {
                my $minTmsOfActualSimDev     = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'};
                my $isDeployedOfActualSimDev = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'};

                # loop over all higherPrioSimDevs
                foreach my $higherPrioSimDev ( @{ $settings_href->{'HigherPrioSimDevs'} } ) {
                    my $simDevSettings_href = FLC_getSimDeviceSettings($higherPrioSimDev);

                    $signal_time_s = EVAL_get_time_when( $netSignal_href, $settings_href->{'Signal'}, $simDevSettings_href->{'Operator'}, $simDevSettings_href->{'Value'}, $netSignalTimeZero_s );

                    my $alternativeFiringTime_ms;

                    $alternativeFiringTime_ms = ( $signal_time_s - $netSignalTimeZero_s ) * 1000 unless $signal_time_s == -1;

                    $actualFiringTime_ms = $alternativeFiringTime_ms if ( ( $alternativeFiringTime_ms < $actualFiringTime_ms and $alternativeFiringTime_ms > 0 ) or not defined $actualFiringTime_ms and defined $alternativeFiringTime_ms );

                    # overwrite if earlier deployment of higherPrio simDev
                    if ( $actualFiringTime_ms < $minTmsOfActualSimDev ) {
                        S_w2log( 3, "No deployment of SimDev '$deviceName' will not be evaluated as it is overwritten by deployment of '$higherPrioSimDev'." );
                        $simDevOverwritten = 1;
                        last;
                    }
                }
            }
            elsif ( ref( $settings_href->{'CombinedSimDevs'} ) eq "ARRAY" ) {
                my $minTmsOfActualSimDev     = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'};
                my $maxTmsOfActualSimDev     = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MAXT'};
                my $isDeployedOfActualSimDev = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'};

                # loop over all CombinedSimDevs
                foreach my $combinedSimDev ( @{ $settings_href->{'CombinedSimDevs'} } ) {

                    # do not continue if actual SimDev is valid deployment
                    last if ( $actualFiringTime_ms >= $minTmsOfActualSimDev and $actualFiringTime_ms <= $maxTmsOfActualSimDev ) and ( $isDeployed == $FIRE_SIMDEVICE or $isDeployed == $CANFIRE_SIMDEVICE );

                    # alternativ simDev is not considered as it is the same as actual simDev
                    next if ( $deviceName eq $combinedSimDev );

                    # get deployment of alternative SimDev:
                    my $isDeployedOfAlternative = $crashData_href->{'EXPECTEDRESULT'}->{$combinedSimDev}{'ISDEPLOYED'};
                    my $minTmsOfAlternative     = $crashData_href->{'EXPECTEDRESULT'}->{$combinedSimDev}{'MINT'};
                    my $maxTmsOfAlternative     = $crashData_href->{'EXPECTEDRESULT'}->{$combinedSimDev}{'MAXT'};

                    # alternative SimDev is not considered if no deployment
                    next if ( $isDeployedOfAlternative == $NOFIRE_SIMDEVICE );

                    # overwrite the actual SimDev if it has no deployment as there is an alternativ SimDev with deployment
                    if ( $isDeployedOfActualSimDev == $NOFIRE_SIMDEVICE ) {
                        S_w2log( 3, "No deployment of SimDev '$deviceName' will not be evaluated as it is overwritten by deployment of '$combinedSimDev'." );
                        $simDevOverwritten = 1;
                        last;
                    }

                    next if $minTmsOfAlternative > $minTmsOfActualSimDev;

                    # overwrite if mandatory deployment of alternativ simDev
                    if ( $isDeployedOfAlternative == $FIRE_SIMDEVICE ) {
                        S_w2log( 3, "SimDev '$deviceName' will not be evaluated as it is overwritten by earlier deployment of '$combinedSimDev'." );
                        $simDevOverwritten = 1;
                        last;
                    }

                    # overwrite if optional deployment of alternativ simDev is valid
                    elsif ( $actualFiringTime_ms >= $minTmsOfAlternative and $actualFiringTime_ms <= $maxTmsOfAlternative ) {
                        S_w2log( 3, "SimDev '$deviceName' will not be evaluated as it is overwritten by earlier optional deployment of '$combinedSimDev'." );
                        $simDevOverwritten = 1;
                        last;
                    }
                }
            }
        }

        $actualFiringTime_ms = "-" unless defined $actualFiringTime_ms;
        $actualFiringTime_ms = "-" if ( $actualFiringTime_ms < 0 );

        $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms ) unless $simDevOverwritten;
        $firing_state_href = FLC_evaluateFiringStateNoEvaluation( $crashData_href, $deviceName, $actualFiringTime_ms, "COMB" ) if $simDevOverwritten;
    }
    else {
        $firing_state_href = FLC_evaluateFiringStateError( $crashData_href, $deviceName, "missing Trigger" );
    }

    FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

    return 1;
}

=head2 CREIS_EvaluateFaultEntry

=cut

sub CREIS_EvaluateFaultEntry {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateFaultEntry($deviceName, $crashData_href, $callType , $settings_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;
    my $callType       = shift @args;
    my $settings_href  = shift @args;
    my ( $pulses_href, $numOfPulses, $firingTimes_href, $actualFiringTime_ms, $firing_state_href );
    my ( $measureBy, @succeededPulses, $faultPresence_href, $faultPresence );

    $actualFiringTime_ms = "-";

    my $minTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'};
    my $maxTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MAXT'};
    my $isDeployed = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'};

    # read Bosch fault memory and get arrays for fault text and event debug data
    my $filenames_href  = FLC_getFilename('fault_memory');
    my $faultMemory_obj = $filenames_href->{'AfterCrash'}{object};

    # get Settings from CREIS Mapping
    my $disjFaultsList_aref    = $settings_href->{'FaultsList'};
    my $expectedEventDebugData = $settings_href->{'DebugData'};

    # handle CombinedSimDevs
    my $simDevOverwritten;
    if ( exists $settings_href->{'CombinedSimDevs'} ) {

        # loop over all CombinedSimDevs
        foreach my $combinedSimDev ( @{ $settings_href->{'CombinedSimDevs'} } ) {

            # do not continue if actual SimDev is valid deployment
            last if ( $isDeployed == $FIRE_SIMDEVICE );

            # alternativ simDev is not considered as it is the same as actual simDev
            next if ( $deviceName eq $combinedSimDev );

            # get deployment of alternative SimDev:
            my $isDeployedOfAlternative = $crashData_href->{'EXPECTEDRESULT'}->{$combinedSimDev}{'ISDEPLOYED'};

            # alternative SimDev is not considered if no deployment
            next if ( $isDeployedOfAlternative == $NOFIRE_SIMDEVICE );

            # overwrite if mandatory deployment of alternativ simDev
            if ( $isDeployedOfAlternative == $FIRE_SIMDEVICE ) {
                S_w2log( 3, "SimDev '$deviceName' will not be evaluated as it is overwritten by deployment of '$combinedSimDev'." );
                $firing_state_href = FLC_evaluateFiringStateNoEvaluation( $crashData_href, $deviceName, '-', "COMB" );
                FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

                return 1;
            }
        }
    }

    if ( defined $expectedEventDebugData and $isDeployed == $NOFIRE_SIMDEVICE ) {
        $expectedEventDebugData =~ tr/1/0/;
    }

    push( @{$disjFaultsList_aref}, $settings_href->{'FaultName'} ) if ( defined $settings_href->{'FaultName'} );

    # go through fault texts and check if expected fault is there
    my $detectedFault;
    my $debugDataValid;

    S_w2log( 3, "Check FaultPesence of following faults: @$disjFaultsList_aref\n" );
    my $nbr_of_faults = @$disjFaultsList_aref;

    if ( $nbr_of_faults == 1 ) {
        S_w2log( 3, "\$nbr_of_faults: $nbr_of_faults 'check_fault_presence' with scalar.\n" );
        $faultPresence = $faultMemory_obj->check_fault_presence( $$disjFaultsList_aref[0] );

        $detectedFault = $$disjFaultsList_aref[0] if $faultPresence eq 'present';
        FLC_addSimDeviceDependentFault($detectedFault) if $faultPresence eq 'present';
    }
    else {
        S_w2log( 3, "\$nbr_of_faults: $nbr_of_faults 'check_fault_presence' with aref'.\n" );
        $faultPresence_href = $faultMemory_obj->check_fault_presence($disjFaultsList_aref);

        foreach my $fault ( keys %{$faultPresence_href} ) {

            if ( defined $detectedFault and $faultPresence_href->{$fault} eq 'present' ) {
                S_set_warning("More than one of the expected disjunctive faults detected. Sim Device will be set as 'Early Deployment'.");
                $detectedFault = "MultiDisjunctiveDetected";
                last;
            }

            $detectedFault = $fault if $faultPresence_href->{$fault} eq 'present';
            FLC_addSimDeviceDependentFault($detectedFault) if $faultPresence_href->{$fault} eq 'present';
            S_w2log( 3, "FaulPresence: \$fault: $fault $faultPresence_href->{$fault}" );
        }
    }

    S_w2log( 3, "\$detectedFault:'$detectedFault'" );

    if ( defined $detectedFault and $detectedFault ne 'MultiDisjunctiveDetected' and defined $expectedEventDebugData ) {

        my $debugData = $faultMemory_obj->get_fault_attribute( { 'FaultName' => $detectedFault, 'Attribute' => 'EventDebugData' } );

        $debugDataValid = 1 if EVAL_evaluate_value_NOVERDICT_NOHTML( $deviceName, $debugData, 'MASK', $expectedEventDebugData ) eq "VERDICT_PASS";    # check value with a bitmask (1..32 bits) (ignore x)
    }
    else {
        $debugDataValid = 1;
    }

    S_w2log( 3, "\$debugDataValid:'$debugDataValid'" );

    if ( defined $detectedFault and $detectedFault eq 'MultiDisjunctiveDetected' ) {
        $actualFiringTime_ms = $minTime_ms / 2;
    }
    elsif ( defined $detectedFault and $debugDataValid ) {
        $actualFiringTime_ms = $minTime_ms + ( ( $maxTime_ms - $minTime_ms ) / 2 );
        $actualFiringTime_ms = '-' if ( defined $expectedEventDebugData and $isDeployed == $NOFIRE_SIMDEVICE );
    }
    elsif ( defined $detectedFault ) {
        $actualFiringTime_ms = $maxTime_ms + 100;
    }
    else {
        $actualFiringTime_ms = '-';
    }

    $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms );

    FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

    return 1;
}

=head2 CREIS_EvaluatePWMSignal

only for 'trace_analog'

=cut

sub CREIS_EvaluatePWMSignal {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluatePWMSignal($deviceName, $crashData_href, $callType , $settings_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;
    my $callType       = shift @args;
    my $settings_href  = shift @args;
    my ( $pulses_href, $numOfPulses, $data_href, $definitionPWM_href, $actualFiringTime_ms, $firing_state_href );
    my ( $measureBy, @succeededPulses );

    $actualFiringTime_ms = "-";

    $measureBy = $settings_href->{MeasureBy};

    unless ( $measureBy eq "trace_analog" ) {
        S_set_error("Measure by '$measureBy' currently not supported for device '$deviceName'.");
        return 0;
    }

    unless (defined $settings_href->{t_min_high_ms}
        and defined $settings_href->{t_max_high_ms}
        and defined $settings_href->{t_min_low_ms}
        and defined $settings_href->{t_max_low_ms}
        and defined $settings_href->{starting_level} )
    {
        S_set_error("Invalid Evaluation Settings for \$simDev '$deviceName'. Check your 'CREIS_ProjectConst'. \n For CREIS_EvaluatePWMSignal 't_min_low_ms', 't_max_low_ms','t_min_high_ms', 't_max_high_ms' and 'starting_level' need to be defined!");
        return 0;
    }

    $definitionPWM_href->{t_min_high_ms}  = $settings_href->{t_min_high_ms};
    $definitionPWM_href->{t_max_high_ms}  = $settings_href->{t_max_high_ms};
    $definitionPWM_href->{t_min_low_ms}   = $settings_href->{t_min_low_ms};
    $definitionPWM_href->{t_max_low_ms}   = $settings_href->{t_max_low_ms};
    $definitionPWM_href->{starting_level} = $settings_href->{starting_level};

    my $deviceNameALIAS = $settings_href->{'ALIAS'};

    $data_href = LC_MeasureTraceAnalogGetValues( [$deviceNameALIAS], 0.01 );

    my ( $deployment_detected, $time_state_active_ms, $time_state_inactive_ms ) = GetTimePWM_Signal( $data_href, $deviceNameALIAS, $definitionPWM_href, 4 );

    $actualFiringTime_ms = $time_state_active_ms if $deployment_detected;

    $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms );

    FLC_logSimDev( $deviceName, $firing_state_href ) if $callType eq "SimDev";

    return 1;
}

sub GetTimePWM_Signal {

    # TODO detailed parameter check for signal_details_HoH and $threshold

    my @args = @_;
    my (
        $time_state_active_s, $time_state_inactive_s, @times_state_inactive_s, @times_state_active_s,    $THRESHOLD,         $MEASURE_DATA_HREF,        $SIGNAL_LABEL,   $SIGNAL_DETAILS_HREF, $THRESHOLD_HREF,
        $TIME_LOG_START,      $TIME_LOG_END,          $total_iterations,       $count_total_iterations,  $updated_data_href, @time_stamps,              $nbr_pwm_labels, $used_signal,         $counter_high,
        $time_stamp_next_s,   $first_cycle_flag,      $current_level,          $previous_time_stamp_low, $count_iterations,  $previous_time_stamp_high, $valid,          $counter_low,
    );

    if ( ref $args[3] eq "HASH" ) {
        S_checkFunctionArguments( 'GetTimePWM_Signal ( $MEASURE_DATA_HREF, $SIGNAL_LABEL, $SIGNAL_DETAILS_HREF, $THRESHOLD_HREF [, $TIME_LOG_START, $TIME_LOG_END])', @args );

        $MEASURE_DATA_HREF   = shift;
        $SIGNAL_LABEL        = shift;
        $SIGNAL_DETAILS_HREF = shift;
        $THRESHOLD_HREF      = shift;
        $TIME_LOG_START      = shift;
        $TIME_LOG_END        = shift;
    }
    else {
        S_checkFunctionArguments( 'GetTimePWM_Signal($MEASURE_DATA_HREF,$SIGNAL_LABEL,$SIGNAL_DETAILS_HREF,$THRESHOLD[,$TIME_LOG_START,$TIME_LOG_END])', @args );

        $MEASURE_DATA_HREF   = shift;
        $SIGNAL_LABEL        = shift;
        $SIGNAL_DETAILS_HREF = shift;
        $THRESHOLD_HREF      = shift;
        $TIME_LOG_START      = shift;
        $TIME_LOG_END        = shift;

        $THRESHOLD = $THRESHOLD_HREF;
    }

    return -2 if $main::opt_offline;

    $used_signal = $SIGNAL_LABEL;

    $MEASURE_DATA_HREF = Analyse_PWM_signal( $MEASURE_DATA_HREF, $used_signal, $THRESHOLD_HREF );
    @time_stamps = sort { $a <=> $b } keys %$MEASURE_DATA_HREF;

    if ( defined $SIGNAL_DETAILS_HREF->{Iterations} ) {
        $counter_high     = $SIGNAL_DETAILS_HREF->{Iterations};
        $counter_low      = $SIGNAL_DETAILS_HREF->{Iterations};
        $count_iterations = 1;
    }
    else {
        $counter_high     = 0;
        $counter_low      = 0;
        $count_iterations = 0;
    }

    foreach my $time_stamp (@time_stamps) {
        undef $first_cycle_flag;
        if ( defined $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_low" } ) {
            $previous_time_stamp_low = $time_stamp;
            $current_level           = "low";
            my $value = $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_low" };
            S_w2rep("time_stamp: $time_stamp, low: $value");
        }
        elsif ( defined $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_high" } ) {
            $previous_time_stamp_high = $time_stamp;
            $current_level            = "high";
            my $value = $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_high" };
            S_w2rep("time_stamp: $time_stamp, high: $value");
        }
        else {
            next;
        }

        next
          if ( defined $TIME_LOG_START ) && ( $time_stamp < $TIME_LOG_START );
        last if ( defined $TIME_LOG_END ) && ( $time_stamp > $TIME_LOG_END );

        if (   defined $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_" . $current_level }
            && LIFT_evaluation::compare_two_values( $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_" . $current_level }, ">", $SIGNAL_DETAILS_HREF->{ "t_min_" . $current_level . "_ms" } )
            && LIFT_evaluation::compare_two_values( $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_" . $current_level }, "<", $SIGNAL_DETAILS_HREF->{ "t_max_" . $current_level . "_ms" } ) )
        {
            S_w2rep("conditions fullfilled");

            # store the time of the first occurence
            unless ( defined $time_state_active_s ) {
                S_w2rep("for the first time");
                $time_state_active_s = $time_stamp;
                $first_cycle_flag    = 1;
            }

            unless ( defined $first_cycle_flag ) {
                $counter_high-- if $current_level eq "high";
                $counter_low--  if $current_level eq "low";
            }

            $time_stamp_next_s = $time_stamp + $MEASURE_DATA_HREF->{$time_stamp}{ $used_signal . "_t_" . $current_level };
        }
        else {
            if ( defined $time_state_active_s ) {
                $time_state_inactive_s = $time_stamp;
            }
        }

        if (   $first_cycle_flag
            && defined $SIGNAL_DETAILS_HREF->{"starting_level"}
            && $SIGNAL_DETAILS_HREF->{"starting_level"} eq $current_level )
        {
            $counter_high-- if $current_level eq "high";
            $counter_low--  if $current_level eq "low";
        }
        elsif ($first_cycle_flag
            && $current_level eq "high"
            && defined $SIGNAL_DETAILS_HREF->{"starting_level"}
            && $SIGNAL_DETAILS_HREF->{"starting_level"} eq 'low' )
        {
            if ( $MEASURE_DATA_HREF->{$previous_time_stamp_low}{ $used_signal . "_t_low" } > ( $SIGNAL_DETAILS_HREF->{"t_min_low_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_low_ms"} ) / 2 ) {
                $time_state_active_s = $time_state_active_s - ( $SIGNAL_DETAILS_HREF->{"t_min_low_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_low_ms"} ) / 2;
                $counter_low--;
                $counter_high--;
            }
            else {
                undef $time_state_active_s;
            }
        }
        elsif ($first_cycle_flag
            && $current_level eq "low"
            && defined $SIGNAL_DETAILS_HREF->{"starting_level"}
            && $SIGNAL_DETAILS_HREF->{"starting_level"} eq 'high' )
        {
            if ( $MEASURE_DATA_HREF->{$previous_time_stamp_high}{ $used_signal . "_t_high" } > ( $SIGNAL_DETAILS_HREF->{"t_min_high_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_high_ms"} ) / 2 ) {
                $time_state_active_s = $time_state_active_s - ( $SIGNAL_DETAILS_HREF->{"t_min_high_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_high_ms"} ) / 2;
                $counter_low--;
                $counter_high--;
            }
            else {
                undef $time_state_active_s;
            }
        }
        elsif ($first_cycle_flag) {

        }

        if (   defined $time_state_inactive_s
            && $counter_high == 1
            && $counter_low == 0 )
        {
            if (   defined $MEASURE_DATA_HREF->{$time_state_inactive_s}{ $used_signal . "_t_high" }
                && defined $MEASURE_DATA_HREF->{$time_state_inactive_s}{ $used_signal . "_t_high" } > ( $SIGNAL_DETAILS_HREF->{"t_min_high_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_high_ms"} ) / 2 )
            {
                $time_state_inactive_s = $time_state_inactive_s + ( $SIGNAL_DETAILS_HREF->{"t_min_high_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_high_ms"} ) / 2;
                $valid = 1;
                last;
            }
            else {
                $valid = 0;
                last;
            }
        }
        elsif (defined $time_state_inactive_s
            && $counter_high == 0
            && $counter_low == 1 )
        {
            if (   defined $MEASURE_DATA_HREF->{$time_state_inactive_s}{ $used_signal . "_t_low" }
                && defined $MEASURE_DATA_HREF->{$time_state_inactive_s}{ $used_signal . "_t_low" } > ( $SIGNAL_DETAILS_HREF->{"t_min_low_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_low_ms"} ) / 2 )
            {
                $time_state_inactive_s = $time_state_inactive_s + ( $SIGNAL_DETAILS_HREF->{"t_min_low_ms"} + $SIGNAL_DETAILS_HREF->{"t_max_low_ms"} ) / 2;
                $valid = 1;
                last;
            }
            else {
                $valid = 0;
                last;
            }
        }
        elsif (
            defined $time_state_inactive_s
            && (   $counter_high > 0
                || $counter_low > 0 )
          )
        {
            $valid = 0;
            last;
        }
        elsif ( defined $time_state_inactive_s ) {
            $valid = 1;
            last;
        }
        elsif ($count_iterations
            && $counter_high == 0
            && $counter_low == 0 )
        {
            $time_state_inactive_s = $time_stamp_next_s;
            $valid                 = 1;
            last;
        }
    }

    $valid = 1 if ( not defined $valid and defined $time_state_active_s );
    $valid = 0 unless defined $valid;

    S_w2rep("valid '$valid'");
    S_w2rep("time_state_active_s: '$time_state_active_s s'");
    S_w2rep("time_state_inactive_s: '$time_state_inactive_s s'");

    return ( $valid, $time_state_active_s, $time_state_inactive_s );
}

sub Analyse_PWM_signal {
    my @args = @_;
    my ( $values_aref, $times_aref, $toggle, $i, $lastEdge, $diff, $threshold, $measure_data_href, $signal_label, $threshold_href, $ref_values_aref, $ref_times_aref, $reference_threshold, %updated_data_href, $MINtime_stamp, $MAXtime_stamp, @time_stamps, $TIME_LOG_START, $TIME_LOG_END );

    if ( ref $args[2] eq "HASH" ) {
        return -1
          unless S_checkFunctionArguments( 'Analyse_PWM_signal ( $measure_data_href, $signal_label, $threshold_href [, $TIME_LOG_START, $TIME_LOG_END] )', @args );

        $measure_data_href = shift;
        $signal_label      = shift;
        $threshold_href    = shift;
        $TIME_LOG_START    = shift;
        $TIME_LOG_END      = shift;

        unless (defined $threshold_href->{Reference_Signal}
            and defined $threshold_href->{Reference_Threshold} )
        {
            S_set_error( "Analyse_PWM_signal: '\$threshold_href' does not contain 'Reference_Signal' and 'Reference_Threshold'. \n", 114 );
            return -1;
        }

        $reference_threshold = $threshold_href->{Reference_Threshold};
    }
    else {
        return -1
          unless S_checkFunctionArguments( 'Analyse_PWM_signal ( $measure_data_href, $signal_label, $threshold [, $TIME_LOG_START, $TIME_LOG_END] )', @args );
        $measure_data_href = shift;
        $signal_label      = shift;
        $threshold         = shift;
        $TIME_LOG_START    = shift;
        $TIME_LOG_END      = shift;
    }

    # check if $used_signal exists in data hash

    @time_stamps   = sort { $a <=> $b } keys %$measure_data_href;
    $MINtime_stamp = $time_stamps[0];
    $MAXtime_stamp = $time_stamps[-1];
    if ( defined $TIME_LOG_START && $TIME_LOG_START > $MAXtime_stamp ) {
        S_set_error( "TIME_LOG_START $TIME_LOG_START out of range: time( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return -1;
    }
    if ( defined $TIME_LOG_END && $TIME_LOG_END < $MINtime_stamp ) {
        S_set_error( "TIME_LOG_END $TIME_LOG_END out of range: time( $MINtime_stamp , $MAXtime_stamp )", 114 );
        return -1;
    }

    ( $values_aref, $times_aref ) = EVAL_get_values_and_times_over_time( $measure_data_href, $signal_label );

    unless ( defined $values_aref && defined $times_aref ) {
        S_set_error( "signal $signal_label not found in given data reference", 114 );
        return -1;
    }

    $i = 0;

    if ( defined $threshold ) {
        if ( $$values_aref[0] <= $threshold ) {

            # next edge will be rising
            $toggle = 1;

            #ignore start with low level
            $i++ while ( $i < $#$times_aref && $$values_aref[$i] <= $threshold );
        }
        else {

            #next edge will be falling
            $toggle = -1;

            #ignore start with high level
            $i++ while ( $i < $#$times_aref && $$values_aref[$i] > $threshold );
        }

        while ( $i < $#$times_aref ) {
            $lastEdge = $$times_aref[$i];
            $i++ while (
                $i < $#$times_aref
                && (   ( $toggle == 1 && ( $$values_aref[$i] > $threshold ) )
                    || ( $toggle == -1 && ( $$values_aref[$i] <= $threshold ) ) )
            );
            if ( $i < $#$times_aref ) {
                $diff = $$times_aref[$i] - $lastEdge;

                $updated_data_href{$lastEdge}{ $signal_label . "_t_high" } = $diff
                  if $toggle == 1;
                $updated_data_href{$lastEdge}{ $signal_label . "_t_low" } = $diff
                  if $toggle == -1;

                $toggle = $toggle * -1;
            }
        }
    }
    else {
        ( $ref_values_aref, $ref_times_aref ) = EVAL_get_values_and_times_over_time( $measure_data_href, $threshold_href->{Reference_Signal} );

        $i++ while ( abs( $$ref_values_aref[$i] ) < 6 );

        if ( $$values_aref[$i] <= $reference_threshold * $$ref_values_aref[$i] ) {

            # next edge will be rising
            $toggle = 1;

            #ignore start with low level
            $i++ while ( $i < $#$times_aref
                && $$values_aref[$i] <= $reference_threshold * $$ref_values_aref[$i] );
        }
        else {

            #next edge will be falling
            $toggle = -1;

            #ignore start with high level
            $i++ while ( $i < $#$times_aref
                && $$values_aref[$i] > $reference_threshold * $$ref_values_aref[$i] );
        }

        while ( $i < $#$times_aref ) {
            $lastEdge = $$times_aref[$i];
            $i++ while (
                $i < $#$times_aref
                && (
                    ( $toggle == 1 && ( $$values_aref[$i] > $reference_threshold * $$ref_values_aref[$i] ) )
                    || ( $toggle == -1
                        && ( $$values_aref[$i] <= $reference_threshold * $$ref_values_aref[$i] ) )
                )
            );
            if ( $i < $#$times_aref ) {
                $diff = $$times_aref[$i] - $lastEdge;

                $updated_data_href{$lastEdge}{ $signal_label . "_t_high" } = $diff
                  if $toggle == 1;
                $updated_data_href{$lastEdge}{ $signal_label . "_t_low" } = $diff
                  if $toggle == -1;

                $toggle = $toggle * -1;
            }
        }
    }

    return \%updated_data_href;
}

=head2 CREIS_StartSpecificMeasurements

=cut

sub CREIS_StartSpecificMeasurements {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StartSpecificMeasurements()', @args );

    S_w2log( 3, "CREIS_StartSpecificMeasurements: TNT function called" );

    #    #start QuaTe monitor (SPI/PSI)
    #    LIFT_QuaTe::QuaTe_SetSPIMonitorMode('InternalSensors', ENABLE, 0, 1, ['SMB470']);
    #    LIFT_QuaTe::QuaTe_SetPSIMonitorMode('PSImonitorQ1', ENABLE, 1, ['UFSD','PASFD','PASFP','PPSFD','PPSFP']);

    return 1;
}

=head2 CREIS_StopSpecificMeasurements

=cut

sub CREIS_StopSpecificMeasurements {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StopSpecificMeasurements()', @args );

    S_w2log( 3, "CREIS_StopSpecificMeasurements: TNT function called" );

    #    #stop QuaTe monitor (SPI/PSI), save dump
    #    LIFT_QuaTe::QuaTe_SetSPIMonitorMode('InternalSensors', DISABLE, 0, 1, ['SMB470']);
    #    my $filename = FuncLib_CREIS_Framework::CREIS_GetResultsFolder().S_get_TC_number() . "_SPI_Trace.csv";
    #    LIFT_QuaTe::QuaTe_SaveSPIMonitorData_NOERROR('InternalSensors', $filename);

    #    LIFT_QuaTe::QuaTe_SetPSIMonitorMode('PSImonitorQ1', DISABLE, 1, ['UFSD','PASFD','PASFP','PPSFD','PPSFP']);
    #    $filename = FuncLib_CREIS_Framework::CREIS_GetResultsFolder( ).S_get_TC_number() . "_PSI_Q1_Trace.csv";
    #    LIFT_QuaTe::QuaTe_SavePSIMonitorData_NOERROR('PSImonitorQ1', $filename);

    return 1;
}
1;
__END__

