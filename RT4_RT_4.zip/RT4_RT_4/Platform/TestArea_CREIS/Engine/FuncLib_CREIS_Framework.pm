# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_CREIS_Framework;

use strict;
use warnings;

BEGIN 
{
	use LIFT_general;
    S_add_paths2INC(['./CREIS_Framework']);
}

use LIFT_labcar;
use LIFT_FaultMemory;
use LIFT_ProdDiag;
use LIFT_can_access;
use LIFT_evaluation;
use FuncLib_CREIS_HelperFunctions;
use FuncLib_CREIS_LoggerFunctions;
use FuncLib_CREIS_xlsxReporting;
use FuncLib_TNT_CREIS_Framework;
require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  CREIS_CheckEnvironmentCombinationSkip
  CREIS_CreateXLSXSummary
  CREIS_EvaluateExtendedRuntime
  CREIS_EvaluateFaultMemory
  CREIS_EvaluateMeasurements
  CREIS_EvaluateRuntime
  CREIS_FinishReporting
  CREIS_GetResultsFolder
  CREIS_LogTestCaseEvent
  CREIS_PrepareMeasurementsAndReporting
  CREIS_ReadEcuMode
  CREIS_ReadFireCounter
  CREIS_ReadPD_EDR
  CREIS_ReadPdLabels
  CREIS_ReadSquibResistance
  CREIS_DumpNVMData
  CREIS_RuntimeAfterCrash
  CREIS_RuntimeBeforeCrash
  CREIS_StartAllMeasurements
  CREIS_StartFastDiagTrace
  CREIS_StopAllMeasurements
  CREIS_StopFastDiagTrace
  CREIS_StoreFastDiagTrace
  CREIS_StoreFaultMemory
  CREIS_WaitEcuReady
  CREIS_WaitUntillRecordingIsFinished
);

=head1 NAME

FuncLib_CREIS_Framework

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 CREIS Mapping

=head2 SimDevices

=head3 SimDevice: Ignored

    A simDevice will be ignored for all evaluations if the "ignored" parameter is set.
    It will not set "verdict_fail" or "verdict_inconc" but in the CREIS excel reporting it will still be highlighted
    and the given reason will be directly documented.

    Parameter: 'Ignored'
        required
        if given, this SimDevice will not be evaluated
        Values: any text as reason for ignore
        this reason will be displayed in the report section
        comment or delte this parameter if simDevice should be evaluated again

    Code:
        'ignored_simDevice' => {
            'Ignored'   =>  'reason for ignore',
        },

=head3 SimDevice: Squib

    Devices are automatically deteced as squib if they are defined as squib in TSG4 mapping.
    None of the given parameters is needed for evaluation of squibs.

=head4 Parameter: 'MeasureBy'
        optional
        will force usage of given device
        Values: "trace_digital" or  "trace_analog"
        if not given the best possible device is selected automaticly (depending on testbench setup)
        it will use a default sampling frequency of 0,2 MHz if 'trace_analog' is given or selected automaticly
           this may be overwriten by analog signals if they have a sampling frequency defined which is >0,2 MHz

=head4 Parameter: 'FiringCurrentThreshold_A'
        optional
        will overwrite setting given in general settings for this device
        Values: direct value in A

=head4 Parameter: 'Current'
        optional
        will overwrite default setting for squibs (default: '1')
        Values: '0' - no current measurement OR '1' - current measurement

=head4 Parameter: 'SignalMode'
        optional
        will overwrite default setting for squibs (default: 'differential')
        Values: see documentation of LIFT_TRC module

=head4 Parameter: 'VoltageRange'
        optional
        will overwrite default setting for squibs (default: '5')
        Values: see documentation of LIFT_TRC module

=head4 Parameter: 'Evaluation'
        optional
        will overwrite the default function for evaluation of squib firing
        the given function has to be defined in 'FuncLib_Project_CREIS_Framework' or in 'FuncLib_CustLib_CREIS_Framework' if need for whole customer group
        if default function is overwriten it is possible to define other parameters in this section and use them in the new function and settings
        in 'firing_current_A' and 'firing_duration_ms' may be ignored (dependend on the individual function)

=head4 Parameter: 'backup_mode'
        optional
        will use backup mode values for evaluation of squib firing
        Values: '0' - no backup mode OR '1' - backup mode

=head4 Parameter: 'firing_current_A'
        optional
        expected firing current in A used for squib evaluation (only possible with Transi)
        if not given value will be fetched from SYC
        Values: direct value in A

=head4 Parameter: 'firing_duration_ms'
        optional
        expected firing duration in ms used for squib evaluation
        if not given value will be fetched from SYC
        Values: direct value in ms

=head4 Parameter: 'maxPulses'
        optional
        allowed firing pulses
        may be 2 if project uses disposal functionality
        Values: 1..N

=head4 Code:
        "squib" => {
            'MeasureBy'                 => "trace_digital",             # "trace_digital" or "trace_analog"
            'FiringCurrentThreshold_A'  => 1.2,                         # direct value in A
            'Current'                   => 1,                           # '0' - no current measurement OR '1' - current measurement
            'SignalMode'                => 'differential'               # possible values see documentation of LIFT_TRC module
            'VoltageRange'              => 5,                           # possible values see documentation of LIFT_TRC module
            'Evaluation'                => 'CREIS_EvaluateSquibFiring',
            'backup_mode'               => ...,                         # '0' - no backup mode OR '1' - backup mode
            'firing_current_A'          => '1.4',                       # direct value in A
            'firing_duration_ms'        => '0.7',                       # direct value in ms
            'maxPulses'                 => '1',                         # 1..N
        }

=head3 SimDevice: Analog Signal

    All devices that are not identified as  squibs (see above) and are set to 'MeasureBy' => 'trace_analog',

=head4 Parameter: 'MeasureBy'
        required
        Values: "trace_analog"

=head4 Parameter: 'Current'
        optional
        will overwrite default setting for Analog Signals (default: '0')
        Values: '0' - no current measurement OR '1' - current measurement

=head4 Parameter: 'SignalMode'
        optional
        will overwrite default setting for Analog Signals (default: 'differential')
        Values: see documentation of LIFT_TRC module

=head4 Parameter: 'VoltageRange'
        optional
        will overwrite default setting for Analog Signals (default: '20')
        Values: see documentation of LIFT_TRC module

=head4 Parameter: 'SamplingFrequency_Hz'
        required
        will set the 'SamplingFrequency_Hz' of TransientRecorder
        biggest value will be used, if more than one analog signal uses samplingFrequency
        Values: see documentation of LIFT_TRC module

=head4 Parameter: 'Evaluation'
        optional
        will overwrite the default function for evaluation of Analog Signals
        the given function has to be defined in 'FuncLib_Project_CREIS_Framework' or in 'FuncLib_CustLib_CREIS_Framework' if need for whole customer group
        if default function is overwriten it is possible to define other parameters in this section and use them in the new function and settings
        in 'firing_current_A' and 'firing_duration_ms' may be ignored (dependend on the individual function)

=head4 Code:
        "analog_signal" => {
            'MeasureBy'     => 'trace_analog',              # "trace_analog"
            'Current'       => 0,                           # '0' - no current measurement OR '1' - current measurement
            'SignalMode'    => 'differential'               # Values: see documentation of LIFT_TRC module
            'VoltageRange'  => 5,                           # Values: see documentation of LIFT_TRC module
            'SamplingFrequency_Hz => 200 * 1000,                      # Values: see documentation of LIFT_TRC module
            'Evaluation'    => 'CREIS_EvaluatePWMPattern',
            # Todo Parameter of evaluation function
        }

=head3 SimDevice: Network Signal
    all devices that are set to 'MeasureBy' => 'CAN' or 'FLXR' or 'LIN'

=head4 Parameter: 'MeasureBy'
        required
        Values: 'CAN' or 'FLXR' or 'LIN'

=head4 Parameter: 'Evaluation'
        optional
        will overwrite the default function for evaluation of Network Signals
        the given function has to be defined in 'FuncLib_Project_CREIS_Framework' or in 'FuncLib_CustLib_CREIS_Framework' if needed for whole customer group
        if default function is overwriten it is possible to define other parameters in this section and use them in the new function and settings
        in 'firing_current_A' and 'firing_duration_ms' may be ignored (dependend on the individual function)

=head4 Code:
        "network_signal" => {
            'MeasureBy'     => "CAN",                       # 'CAN', 'FLXR' or 'LIN'
            'Evaluation'    => 'CREIS_EvaluateNetSignal',
            # Todo Parameter of evaluation function (signal, values, duration ...)
            'Signal'		=> "" #used CAN signal
            'Operator'		=> "" # as in EVAL_time_when();
            'Value'			=> "" # value as per CAN signal range.
        }

=cut

my $lastRESULTDB   = undef;
my $lasttcParaName = undef;
my $iterationCount = 1;

# Globals for
our $CREIS_RELEASE_LABEL     = "CREIS_V2_0";
our $MINIMUM_REQUIRED_ENGINE = "2.32";

#
#
# Definition of all functions in LIFT_crash_simulation
#
#

=head1 Function Group 'base'

=head2 CREIS_CheckEnvironmentCombinationSkip

	CREIS_CheckEnvironmentCombinationSkip($crashData_href);

=cut

sub CREIS_CheckEnvironmentCombinationSkip {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_CheckEnvironmentCombinationSkip( $crashData_href )', @args );

    my $settingsInvalidEnvironmentCombinations_href = FLC_getInvalidEnvironmentCombinations( );
    my $crashData_href = shift @args;

    unless ( defined $settingsInvalidEnvironmentCombinations_href ) {
        S_set_warning("CREIS_CheckEnvironmentCombinationSkip: section not defined.");
        return 0;
    }

    unless ( ref $settingsInvalidEnvironmentCombinations_href eq "HASH" ) {
        S_set_warning("CREIS_CheckEnvironmentCombinationSkip: provided content for InvalidEnvironmentCombinations is not a hash reference.");
        return [];
    }

    foreach my $rule ( keys %{ $settingsInvalidEnvironmentCombinations_href } ) {
        my $calculationExpressionText = $settingsInvalidEnvironmentCombinations_href->{$rule};
        my @expressionVariables       = sort( $calculationExpressionText =~ /(\#\w*\|?\d?)/g );
        my $calculationExpression     = $calculationExpressionText;

        # loop over all #n in $calculationExpression
        foreach my $expressionVariable (@expressionVariables) {
            if ( $expressionVariable =~ /\#(\w*)\|?(\d?)/ ) {

                # get variable number: 0 for #0, 1 for #1, etc.
                my $exprVar          = $1;
                my $alternativeValue = $2;

                my $value;

                if ( exists $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$exprVar} ) {
                    $value = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$exprVar}{Value};
                }
                elsif ( exists $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$exprVar} ) {
                    $value = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$exprVar}{Value};
                }

                if ( $alternativeValue eq '' ) {
                    unless ( defined $value ) {
                        next;
                    }
                    $calculationExpression =~ s/\#$exprVar/$value/;
                }
                else {
                    $value = $value // $alternativeValue;
                    $calculationExpression =~ s/\#$exprVar\|$alternativeValue/$value/;
                }
            }
        }
        my $result = eval($calculationExpression);
        if ($result) {
            S_w2rep( "Execution of this Crash and State will be skipped as given Environments combination is invalid (fullfilled rule: $rule)\n", 'blue' );
            return $rule;
        }
    }

    return 0;
}

=head2 CREIS_StartFastDiagTrace

    CREIS_StartFastDiagTrace();

=cut

sub CREIS_StartFastDiagTrace {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StartFastDiagTrace( )', @args );
    my ( $filenames_href, $filename, $nbrOfCanIDs, @fd_variables, @types );

    ### extended runtime measurement
    $filename       = FLC_getFilename('fd_trace');
    $filenames_href = FLC_getFilename('FastDiagTrace');
    $nbrOfCanIDs    = FLC_getFilename('pdNbrOfCanIDs');

    if ( $filename and $filenames_href ) {
        my @labels = values %$filenames_href;
        PRD_Start_Fast_Diagnosis(
            {
                labels             => \@labels,
                number_of_BUS_Ids  => $nbrOfCanIDs,
                csv_data_file_path => $filename,
            }
        );
    }

    return 1;

}

=head2 CREIS_StopFastDiagTrace

    CREIS_StopFastDiagTrace();

=cut

sub CREIS_StopFastDiagTrace {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StopFastDiagTrace( )', @args );
    my ( $filenames_href, $filename );

    $filename       = FLC_getFilename('fd_trace');
    $filenames_href = FLC_getFilename('FastDiagTrace');
    if ( $filename and $filenames_href ) {
        S_teststep( 'Stop fast diagnose trace and store data for later evaluation.', 'AUTO_NBR' );
        PRD_Stop_Fast_Diagnosis();
    }
    return 1;

}

=head2 CREIS_StoreFastDiagTrace

    CREIS_StoreFastDiagTrace();

=cut

sub CREIS_StoreFastDiagTrace {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StoreFastDiagTrace( )', @args );
    my ( $filenames_href, $filename, $filename_can_access, @fd_variables, @types );

    $filename       = FLC_getFilename('fd_trace');
    $filenames_href = FLC_getFilename('FastDiagTrace');
    if ( $filename and $filenames_href ) {
        my $fdData_href = LIFT_ProdDiag::PRD_Get_Fast_Diagnosis_Data( { data_path => $filename } );
        EVAL_dump2UNV( $fdData_href, $filename . ".txt.unv");
    }
    return 1;

}

=head2 CREIS_RuntimeBeforeCrash

	CREIS_RuntimeBeforeCrash();

=cut

sub CREIS_RuntimeBeforeCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_RuntimeBeforeCrash( )', @args );
    my ( $max_runtime_before_crash, $min_runtime_before_crash, $pendcnt_before_crash, $filenames_href, $filename, $nbrOfCanIDs, @fd_variables, @types );

    ### standard runtime measurement
    $filenames_href = FLC_getFilename('Runtime');
    if ($filenames_href) {
        S_teststep( 'Runtime before crash', 'AUTO_NBR' );
        if ( $filenames_href->{"delete"} ) {
            S_teststep_2nd_level( 'Reset the runtime variables to remove init phase from measurements.', 'AUTO_NBR' );

            S_teststep_2nd_level( $filenames_href->{"MaximumTime"}, 'NO_AUTO_NBR' ) if defined $filenames_href->{"MaximumTime"};
            PRD_Write_Memory( $filenames_href->{"MaximumTime"}, [ 0, 0, 0, 0 ] ) if defined $filenames_href->{"MaximumTime"};

            S_teststep_2nd_level( $filenames_href->{"MinimumTime"}, 'NO_AUTO_NBR' ) if defined $filenames_href->{"MinimumTime"};
            PRD_Write_Memory( $filenames_href->{"MinimumTime"}, [ '0xFF', '0xFF', '0xFF', '0xFF' ] ) if defined $filenames_href->{"MinimumTime"};

            S_teststep_2nd_level( $filenames_href->{"PendingCounter"}, 'NO_AUTO_NBR' ) if defined $filenames_href->{"PendingCounter"};
            PRD_Write_Memory( $filenames_href->{"PendingCounter"}, [ 0, ] ) if defined $filenames_href->{"PendingCounter"};
        }

        my $tableObject = S_TableCreate( [ 'Name', 'PdVariable', 'Value', 'Unit' ] );

        S_teststep_2nd_level( 'Read internal SW runtime values.', 'AUTO_NBR' );
        $max_runtime_before_crash = PRD_Read_Memory( $filenames_href->{"MaximumTime"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"MaximumTime"};
        PRD_Read_Memory( $filenames_href->{"MaximumTime"}, { memoryContentsAsInteger => 1 } );
        S_TableAddRow( $tableObject, [ "MaximumTime", $filenames_href->{'MaximumTime'}, $max_runtime_before_crash, 'val_us' ] ) if defined $filenames_href->{"MaximumTime"};

        $min_runtime_before_crash = PRD_Read_Memory( $filenames_href->{"MinimumTime"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"MinimumTime"};
        S_TableAddRow( $tableObject, [ "MinimumTime", $filenames_href->{'MinimumTime'}, $min_runtime_before_crash, 'val_us' ] ) if defined $filenames_href->{"MinimumTime"};

        $pendcnt_before_crash = PRD_Read_Memory( $filenames_href->{"PendingCounter"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"PendingCounter"};
        S_TableAddRow( $tableObject, [ "PendingCounter", $filenames_href->{'PendingCounter'}, $pendcnt_before_crash, 'val' ] ) if defined $filenames_href->{"PendingCounter"};

        S_TablePrint( CONSOLE | TEXT | HTML | 3, $tableObject, "Runtime_BeforeCrash", [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

    }

    ### extended runtime measurement
    $filename       = FLC_getFilename('fd_trace');
    $filenames_href = FLC_getFilename('ExtendedRuntime');
    $nbrOfCanIDs    = FLC_getFilename('pdNbrOfCanIDs');

    if ( $filename and $filenames_href ) {
        my @labels = values %$filenames_href;
        PRD_Start_Fast_Diagnosis(
            {
                labels             => \@labels,
                number_of_BUS_Ids  => $nbrOfCanIDs,
                csv_data_file_path => $filename,
            }
        );
    }

    return 1;

}

=head2 CREIS_RuntimeAfterCrash

	CREIS_RuntimeAfterCrash();

=cut

sub CREIS_RuntimeAfterCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_RuntimeAfterCrash( )', @args );
    my ( $max_runtime_after_crash, $min_runtime_after_crash, $pendcnt_after_crash, $filenames_href, $filename, @fd_variables, @types );

    ### extended runtime measurement
    $filename       = FLC_getFilename('fd_trace');
    $filenames_href = FLC_getFilename('ExtendedRuntime');
    if ( $filename and $filenames_href ) {
        S_teststep( 'Stop fast diagnose trace and store data for later evaluation.', 'AUTO_NBR', 'ExtendedRuntime' );
        PRD_Stop_Fast_Diagnosis();
    }

    ### standard runtime measurement
    $filenames_href = FLC_getFilename('Runtime');
    if ($filenames_href) {
        S_teststep( 'Runtime after crash', 'AUTO_NBR' );

        my $tableObject = S_TableCreate( [ 'Name', 'PdVariable', 'Value', 'Unit' ] );

        S_teststep_2nd_level( 'Read internal SW runtime values.', 'AUTO_NBR' );
        $max_runtime_after_crash = PRD_Read_Memory( $filenames_href->{"MaximumTime"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"MaximumTime"};
        S_TableAddRow( $tableObject, [ "MaximumTime", $filenames_href->{'MaximumTime'}, $max_runtime_after_crash, 'val_us' ] ) if defined $filenames_href->{"MaximumTime"};

        $min_runtime_after_crash = PRD_Read_Memory( $filenames_href->{"MinimumTime"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"MinimumTime"};
        S_TableAddRow( $tableObject, [ "MinimumTime", $filenames_href->{'MinimumTime'}, $min_runtime_after_crash, 'val_us' ] ) if defined $filenames_href->{"MinimumTime"};

        $pendcnt_after_crash = PRD_Read_Memory( $filenames_href->{"PendingCounter"}, { memoryContentsAsInteger => 1 } ) if defined $filenames_href->{"PendingCounter"};
        S_TableAddRow( $tableObject, [ "PendingCounter", $filenames_href->{'PendingCounter'}, $pendcnt_after_crash, 'val' ] ) if defined $filenames_href->{"PendingCounter"};

        S_TablePrint( CONSOLE | TEXT | HTML | 3, $tableObject, "Runtime_AfterCrash", [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

    }

    if ($main::opt_offline) {
        FLC_LOG_RuntimeValues( "MAX", "MIN", "PND" );
        return 1;
    }

    FLC_LOG_RuntimeValues( $max_runtime_after_crash, $min_runtime_after_crash, $pendcnt_after_crash );

    return 1;

}

=head2 CREIS_GetResultsFolder

    CREIS_GetResultsFolder( );

Will return the path of the results folder, which will be archived at the end of the test.
This can be used to add files to this folder which are not recorded by CREIS Framework itself.

=cut

sub CREIS_GetResultsFolder {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_GetResultsFolder( )', @args );

    my $filename;

    return 0 unless $filename = FLC_getFilename('folder');

    return $filename;
}

=head2 CREIS_EvaluateExtendedRuntime

    CREIS_EvaluateExtendedRuntime( );

=cut

sub CREIS_EvaluateExtendedRuntime {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateExtendedRuntime( )', @args );

    my $filename       = FLC_getFilename('fd_trace');
    my $filenames_href = FLC_getFilename('ExtendedRuntime');
    return 0 unless ( $filename and $filenames_href );

    S_teststep_detected( "Extended Runtime ", "ExtendedRuntime" );
    my $fdData_href = LIFT_ProdDiag::PRD_Get_Fast_Diagnosis_Data( { data_path => $filename } );
    EVAL_dump2UNV( $fdData_href, $filename . ".txt.unv");
    
    my $avgAlgoActiveRuntime = "-";
    my $taskDropRate_2ms     = "-";
    my $taskDropRate_5ms     = "-";
    my $taskDropRate_10ms    = "-";

    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_CurrentRuntime_u32"} ) {
        $avgAlgoActiveRuntime = FLC_getAvgAlgoActiveRuntime($fdData_href);
        S_teststep_detected("avgAlgoActiveRuntime: $avgAlgoActiveRuntime us");
    }

    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_2mscounter_u8"} ) {
        $taskDropRate_2ms = FLC_getTaskDropRate( $fdData_href, 'rb_bg_2mscounter_u8', 2, 0, 255 );
        S_teststep_detected("taskDropRate_2ms: $taskDropRate_2ms %");
    }

    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_5mscounter_u8"} ) {
        $taskDropRate_5ms = FLC_getTaskDropRate( $fdData_href, 'rb_bg_5mscounter_u8', 5, 0, 255 );
        S_teststep_detected("taskDropRate_5ms: $taskDropRate_5ms %");
    }

    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_10mscounter_u8"} ) {
        $taskDropRate_10ms = FLC_getTaskDropRate( $fdData_href, 'rb_bg_10mscounter_u8', 10, 0, 255 );
        S_teststep_detected("taskDropRate_10ms $taskDropRate_10ms %");
    }

    FLC_LOG_ExtendedRuntimeValues( $avgAlgoActiveRuntime, $taskDropRate_2ms, $taskDropRate_5ms, $taskDropRate_10ms );

    return 1;

}

=head2 CREIS_EvaluateFaultMemory

    CREIS_EvaluateFaultMemory( $crashData_href );
    
    

=cut

sub CREIS_EvaluateFaultMemory {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateFaultMemory( $crashData_href )', @args );

    my $crashData_href = shift @args;

    my $expectedFaultsBeforeCrash_href = FLC_evaluateRbFaultsBeforeCrash($crashData_href);
    FLC_evaluateRbFaultsAfterCrash($crashData_href, $expectedFaultsBeforeCrash_href);

    return 1;

}

=head2 CREIS_EvaluateMeasurements

    CREIS_EvaluateMeasurements( $crashData_href );

=cut

sub CREIS_EvaluateMeasurements {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_EvaluateMeasurements( $crashData_href )', @args );

    my $crashData_href = shift @args;

    FLC_prepareCrashData4MultiEvaluationSimDevices($crashData_href);

    foreach my $simDev ( sort keys %{ $crashData_href->{'EXPECTEDRESULT'} } ) {

        # evaluate and document the simDevice if it can be ignored
        next if FLC_evaluateSimDeviceIgnored( $simDev, $crashData_href );

        # evaluate and document the simDevice with the specific function (has to be defined in Prj, Cust or TNT - Lib)
        my $simDevSettings_href = FLC_getSimDeviceSettings($simDev);
        CallEvaluationSpecificFunction( $simDevSettings_href->{'Evaluation'}, $simDev, $crashData_href, 'SimDev', $simDevSettings_href );
        FLC_check4LogSimDev($simDev);
    }

    FLC_LOG_CreateSimDevHTMLTable();

    return 1;

}

=head2 CREIS_FinishReporting

    CREIS_FinishReporting( $crashData_href, $skipInvalidEnvironmentCombination );

=cut

sub CREIS_FinishReporting {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_FinishReporting( $crashData_href,[$skipInvalidEnvironmentCombination] )', @args );

    my $crashData_href = shift @args;
    my $skipInvalidEnvironmentCombination = shift @args;
    my @csmPerCrashKeywordList;

    my $crashIteration = FLC_LOG_CompleteCrash($crashData_href, $skipInvalidEnvironmentCombination);

    return 1 if $skipInvalidEnvironmentCombination;

    push @csmPerCrashKeywordList, "CrashNumber::" . $crashData_href->{'METADATA'}{'CRASHINDEX'};
    push @csmPerCrashKeywordList, "CrashName::" . $crashData_href->{'METADATA'}{'CRASHNAME'};
    push @csmPerCrashKeywordList, "State::" . $crashData_href->{'METADATA'}{'STATEVARIATION'};
    push @csmPerCrashKeywordList, "Iteration::" . $crashIteration;


    FLC_createCSMcontainer_NOERROR( \@csmPerCrashKeywordList );

    FLC_XLSX_createReport();

    my $iterations = 0;    # do not skip per default
    $iterations = S_get_exec_option('CREIS_Iterations') if S_check_exec_option('CREIS_Iterations') and not $main::opt_offline;
    $iterations = 1 if $main::opt_offline;

    if ( $crashIteration < $iterations ) {
        S_w2rep( "Combination of of crash and state will be injected again, as 'CREIS_Iterations' is set to '$iterations',\nbut currently only '$crashIteration' iterations have been performed\n", 'blue' ) unless $main::opt_offline;
        S_w2rep( "Execution of this Iteration will be skipped as only one iteration will be done in offline mode.\n", 'blue' ) if $main::opt_offline;

        S_repeat_testcase ( 1 );
    }

    return 1;
}

=head2 CREIS_CreateXLSXSummary

    CREIS_CreateXLSXSummary( );

=cut

sub CREIS_CreateXLSXSummary {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_CreateXLSXSummary( )', @args );

    FLC_XLSX_createReport() if ( defined $lastRESULTDB );

    return 1;
}

=head2 CREIS_ReadEcuMode

    CREIS_ReadPdLabels( $point );

Will read the ECU mode and store it for display in the report...

$point has to be given as 'BeforeCrash'|'AfterCrash'

=cut

sub CREIS_ReadEcuMode {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_ReadEcuMode( $point )', @args );

    my $point = shift @args;

    unless ( $point eq "BeforeCrash" or $point eq "AfterCrash" ) {
        S_set_error("Given \$point '$point' is not in allowed range ('BeforeCrash'|'AfterCrash')");
        return 0;
    }

    S_teststep( "Read ECU mode '$point'", 'AUTO_NBR' );

    my $ecuProperties_href = PRD_Get_ECU_Properties(  {
        'Property_names' => ['ECU_status', 'Lamp_status']
    } );

    my $lampTableObject = S_TableCreate( [ 'Lamp', 'Value'] );

    foreach my $lamp (sort keys %{$ecuProperties_href->{Lamp_status}}){
        
        S_TableAddRow( $lampTableObject, [ $lamp, $ecuProperties_href->{Lamp_status}{$lamp} ] );
    }

    S_TablePrint( CONSOLE | TEXT | HTML | 3, $lampTableObject, "Lamps_$point", [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

   
    my $tableObject = S_TableCreate( [ 'Name', 'Value'] );
    my $ecuMode = $ecuProperties_href->{ECU_status}{ECU_mode};

    foreach my $statusEntry (sort keys %{$ecuProperties_href->{ECU_status}}){
        
        S_TableAddRow( $tableObject, [ $statusEntry, $ecuProperties_href->{ECU_status}{$statusEntry} ] );
    }

    S_TablePrint( CONSOLE | TEXT | HTML | 3, $tableObject, "ECU_status_$point", [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

    FLC_LOG_EcuMode( $point, $ecuMode );

    return 1;
}

=head2 CREIS_ReadPdLabels

    CREIS_ReadPdLabels( $point );

Will read all configured pdLabels (generic labels and optional labels defined in CREIS Mapping) and store them for display in the report...

$point has to be given as 'BeforeCrash'|'AfterCrash'

=cut

sub CREIS_ReadPdLabels {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_ReadPdLabels( $point )', @args );

    my $point = shift @args;

    unless ( $point eq "BeforeCrash" or $point eq "AfterCrash" ) {
        S_set_error("Given \$point '$point' is not in allowed range ('BeforeCrash'|'AfterCrash')");
        return 0;
    }

    my $filenames_href = FLC_getFilename('PdLabels');

    return unless $filenames_href;
    return unless defined $filenames_href->{$point};

    S_teststep( "Read PdLabels '$point'", 'AUTO_NBR' );

    my $tableObject = S_TableCreate( [ 'Name', 'PdVariable', 'Value', 'Unit' ] );

    foreach my $name ( sort keys %{ $filenames_href->{$point} } ) {
        my $label  = $filenames_href->{$point}{$name}{PdVariable};
        my $mode   = $filenames_href->{$point}{$name}{Mode};
        my $unit   = $filenames_href->{$point}{$name}{Unit};
        my $factor = $filenames_href->{$point}{$name}{Factor};
        my $value;

        my $decValue = PRD_Read_Memory( $label, { memoryContentsAsInteger => 1 } );
        return '---' unless defined $decValue;

        if ( $mode eq "dec" and defined $factor ) {
            $value = $decValue * $factor;
            $unit  = $mode . "_" . $unit;
        }
        elsif ( $mode eq "bin" ) {
            $value = "0b" . S_dec2bin($decValue);
            $unit  = $mode;
        }
        elsif ( $mode eq "hex" ) {
            $value = S_dec2hex($decValue);
            $unit  = $mode;
        }
        else {
            $value = $decValue;
            $unit  = $mode;
        }

        FLC_LOG_PdLabelValues( $name, $point, $value, "NONE" );
        S_TableAddRow( $tableObject, [ $name, $label, $value, $unit ] );
    }

    S_TablePrint( CONSOLE | TEXT | HTML | 3, $tableObject, "PdLabels_$point", [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

    return 1;
}

=head2 CREIS_StoreFaultMemory

    $faultmem_href = CREIS_StoreFaultMemory( $point );

will call "LIFT_FaultMemory -> read_fault_memory('Bosch');" and store the data in the CREIS - Framework and returns the $faultMemory_obj.

data will only be stored inside CREIS - Framework if $point is given as 'BeforeCrash'|'AfterCrash'

=cut

sub CREIS_StoreFaultMemory {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StoreFaultMemory( $point )', @args );

    my $point          = shift @args;
    my $filenames_href = FLC_getFilename('fault_memory');

    S_teststep( "Read RB FCM (BOSCH_FLT_MEM) '$point'", 'AUTO_NBR' );
    S_w2log( 1, "RB FCM (BOSCH_FLT_MEM) '$point'\n", undef, "BOSCH_FLT_MEM_$point" );

    # create a fault memory object of type 'Bosch' and reads the faults from ECU
    my $faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Bosch');

    return $faultMemory_obj unless $point eq "BeforeCrash" or $point eq "AfterCrash";

    $faultMemory_obj->write_to_file( $filenames_href->{$point}{filename} );
    $filenames_href->{$point}{object} = $faultMemory_obj;

    return $faultMemory_obj;
}

=head2 CREIS_DumpNVMData

    CREIS_DumpNVMData( $point );

Will dump all NVM section to the test results but only if corresponding ExecutionOption (CREIS_StoreNVM) was set.

    $point has to be 'BeforeCrash'|'AfterCrash'
    
    Execution Option 'CREIS_StoreNVM'
        1 .. AfterCrash
        2 .. BeforeCrash
        3 .. Both

=cut

sub CREIS_DumpNVMData {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_DumpNVMData( $point )', @args );

    my $point = shift @args;

    unless ( $point eq "BeforeCrash" or $point eq "AfterCrash" ) {
        S_set_error("Given parameter \$point '$point' is not allowed ('BeforeCrash'|'AfterCrash').");
        return 0;
    }

    # setup NVM dump
    my $storeNVM = 0;
    $storeNVM = S_get_exec_option('CREIS_StoreNVM') if S_check_exec_option('CREIS_StoreNVM');
    my $storeNvm4Edr = FLC_getFilename('nvmDumpNeeded4EDR');

    if (   $point eq "BeforeCrash" & ( $storeNVM == 2 or $storeNVM == 3 )
        or $point eq "AfterCrash" & ( $storeNVM == 1 or $storeNVM == 3 or $storeNvm4Edr ) )
    {
        my $options_href;
        $options_href->{file_name} = FLC_getFilename( 'nvmDump' . $point );

        PRD_Dump_Memory_To_File_NOERROR( 'NVM', $options_href );
    }

    return 1;
}

=head2 CREIS_ReadFireCounter

    CREIS_ReadFireCounter( );

Will read the FireCounter for all squibs (will be used for plausi checks during evaluation)

=cut

sub CREIS_ReadFireCounter {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_ReadFireCounter( )', @args );

    my $filenames_href = FLC_getFilename('FireCounter');

    return 0 unless $filenames_href;
    return 0 if $main::opt_offline;

    foreach my $squib ( keys %$filenames_href ) {
        my $label            = $filenames_href->{$squib}{label};
        my $fireCounter_aref = PRD_Read_Memory_NOERROR($label);

        unless ( defined $fireCounter_aref ) {
            S_w2log( 3, "Reading FireCounter not successfull for squib '$squib'." );
            next;
        }

        if ( @$fireCounter_aref < 2 ) {
            S_w2log( 3, "Reading FireCounter not successfull for squib '$squib'." );
            next;
        }

        my $value_high_level_ms = $$fireCounter_aref[0] * 0.025;
        my $value_low_level_ms  = $$fireCounter_aref[1] * 0.025;

        $filenames_href->{$squib}{value_high_level_ms} = $value_high_level_ms;
        $filenames_href->{$squib}{value_low_level_ms}  = $value_low_level_ms;

    }

    return 1;
}

=head2 CREIS_ReadSquibResistance

    CREIS_ReadSquibResistance( );

Will read the CREIS_SquibResistance for all squibs (will be used for plausi checks during evaluation)

=cut

sub CREIS_ReadSquibResistance {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_ReadSquibResistance( )', @args );

    my $filenames_href = FLC_getFilename('SquibResistance');

    return 0 unless $filenames_href;

    foreach my $squib ( keys %$filenames_href ) {
        my $label            = $filenames_href->{$squib}{label};
        my $squibResistance_dec = PRD_Read_Memory_NOERROR($label, { memoryContentsAsInteger => 1 });

        my $value_ohm = $squibResistance_dec/100;

        $filenames_href->{$squib}{value_ohm} = $value_ohm;

    }

    return 1;
}

=head2 CREIS_ReadPD_EDR

    CREIS_ReadPD_EDR( );

Will read the EDR as configured by CREIS_PrepareMeasurements_and_Reporting.

=cut

sub CREIS_ReadPD_EDR {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_ReadPD_EDR( )', @args );

    my $edrReader_href    = FLC_getFilename('edrReader');
    my $pepEdrReader_href = FLC_getFilename('pepEdrReader');

    return 0 unless ( $edrReader_href or $pepEdrReader_href );

    my ( $ecuStatus, $anyEdrStored, $anyEdrFailed, $failedStatus, $storedStatus );

    S_teststep( 'Wait until storing of EDR is finished or maximum 60s.', 'AUTO_NBR' );
    $ecuStatus = FLC_waitForEdrStatus($edrReader_href);

    if ($edrReader_href) {
        my ( $mandRecCnt, $recCnt, $edrCnt );

        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $edrReader_href->{EdrId} } ) {
            my $thisEdrFailed = 0;
            my $thisEdrStored = 0;
            next if $edrNbr !~ /([0-9]+)/;

            ( $failedStatus, $storedStatus ) = FLC_ReadAndCheckMandatoryDataRecCompltStatus( $edrReader_href, $edrNbr );

            if ($failedStatus) {
                $thisEdrFailed = 1;
                $anyEdrFailed  = 1;
            }

            if ($storedStatus) {
                $mandRecCnt++;
                $thisEdrStored = 1;
                $anyEdrStored  = 1;
            }

            ( $failedStatus, $storedStatus ) = FLC_ReadAndCheckRecordCompleteStatus( $edrReader_href, $edrNbr );

            if ($failedStatus) {
                $thisEdrFailed = 1;
                $anyEdrFailed  = 1;
            }

            if ($storedStatus) {
                $recCnt++;
                $thisEdrStored = 1;
                $anyEdrStored  = 1;
            }

            $storedStatus = FLC_ReadCrashRecorder( $edrReader_href, $edrNbr, $thisEdrFailed, $thisEdrStored );
            $edrCnt++ if $storedStatus;
        }

        FLC_CheckNbrOfStoredEDR( $edrCnt, $mandRecCnt, $recCnt ) if exists $edrReader_href->{EdrCount};
    }

    if ($pepEdrReader_href) {
        my ( $recCnt, $edrCnt );
        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $pepEdrReader_href->{EdrId} } ) {
            my $thisEdrFailed = 0;
            my $thisEdrStored = 0;
            next if $edrNbr !~ /([0-9]+)/;

            ( $failedStatus, $storedStatus ) = FLC_ReadAndCheckPepRecordCompleteStatus( $pepEdrReader_href, $edrNbr );

            if ($failedStatus) {
                $thisEdrFailed = 1;
                $anyEdrFailed  = 1;
            }

            if ($storedStatus) {
                $recCnt++;
                $thisEdrStored = 1;
                $anyEdrStored  = 1;
            }

            $storedStatus = FLC_ReadPepCrashRecorder( $pepEdrReader_href, $edrNbr, $thisEdrFailed, $thisEdrStored );
            $edrCnt++ if $storedStatus;

        }

        FLC_CheckNbrOfStoredPepEDR( $edrCnt, $recCnt ) if exists $pepEdrReader_href->{EdrCount};
    }

    $failedStatus = FLC_CheckEdrStatus( $ecuStatus, $anyEdrStored );
    if ($failedStatus) {
        $anyEdrFailed = 1;
    }
    if ($anyEdrFailed) {
        FLC_EnableNvmReadAfterCrash();
    }

    return 1;
}

=head2 CREIS_LogTestCaseEvent

    CREIS_LogTestCaseEvent( $eventName );

Will add a node to the xml wiht $eventName as node name and TcTime as attribute.
This info can be used for offline testing.

=cut

sub CREIS_LogTestCaseEvent {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_LogTestCaseEvent( $eventName )', @args );

    my $eventName = shift @args;

    my $eventNameClean = FLC_LOG_TcEvent($eventName);

    S_w2log(3, "CREIS_LogTestCaseEvent: event logged as '$eventNameClean'");

    return 1;
}

=head2 CREIS_PrepareMeasurementsAndReporting

    CREIS_PrepareMeasurementsAndReporting( $crashData_href );

Will do all the preparation of measurements which is needed for the CREIS.

- check that for all SimDevices from $CrashData a methode to measure and evaluate is clear 
- prepare Transi - Channels and Scanner settings if available  (this is only done for the first crash or when MDB is changed)  

$crashData_href - crash data as returned from CSI_GetCrashDataFromMDS()
                
For official system test CREIS it is not allowed to mix different MDS RESULT files, therefore this function will throw an error 
if MDS result files are mixed.

=cut

sub CREIS_PrepareMeasurementsAndReporting {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_PrepareMeasurementsAndReporting( $crashData_href )', @args );

    my $crashData_href = shift @args;

    # do all initial preparations which are only done once per testlist
    $lastRESULTDB = FLC_initialPreparations($crashData_href) unless ( defined $lastRESULTDB );

    # check that always the same MDSRESULT file is being used.
    unless ( $crashData_href->{'METADATA'}{'RESULTDB'} eq $lastRESULTDB ) {
        S_set_error( "Different RESULTDBs used in the same testlist. This is not allowed for System Test CREIS.", 109 );
        return 0;
    }

    # prepare a folder for the measurements and the names for the files
    FLC_prepareMeasurementFiles($crashData_href);

    #dynamically configure Trans settings, depending on the crash settings
    FLC_configureTransientRecorder($crashData_href);

    return 1;
}

=head2 CREIS_StartAllMeasurements

    CREIS_StartAllMeasurements( );

Will start all measurements. CREIS_PrepareMeasurements_and_Reporting has to be called before.

=cut

sub CREIS_StartAllMeasurements {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StartAllMeasurements( )', @args );

    S_teststep( "Start all required measurements.", 'AUTO_NBR' );

    if ( FLC_getFilename('trace_digital') ) {
        S_teststep_2nd_level( "Prepare and start trace digital (will wait for trigger).", 'AUTO_NBR' );
        LC_MeasureTraceDigitalStart();
    }

    if ( FLC_getFilename('trace_analog') ) {
        S_teststep_2nd_level( "Prepare and start trace analog (will wait for trigger).", 'AUTO_NBR' );
        LC_MeasureTraceAnalogStart();
    }

    if ( FLC_getFilename('can_access') ) {
        S_teststep_2nd_level( "Start can trace.", 'AUTO_NBR' );
        CA_trace_start();
    }
    
    my $specificMeasurement = S_check_exec_option('CREIS_SpecificMeasurement') ? S_get_exec_option('CREIS_SpecificMeasurement') : 0;
    CREIS_StartSpecificMeasurements() if $specificMeasurement;

    return 1;
}

=head2 CREIS_StopAllMeasurements

    CREIS_StopAllMeasurements( );

Will stop all measurements and store the measurement files. CREIS_PrepareMeasurements_and_Reporting and CREIS_StartAllMeasurements has to be called before.

=cut

sub CREIS_StopAllMeasurements {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CREIS_StopAllMeasurements( )', @args );

    my $filename;

    if ( $filename = FLC_getFilename('trace_digital') ) {
        S_teststep_2nd_level( "Stop trace digital and store the plot file.", 'AUTO_NBR' );
        LC_MeasureTraceDigitalStop();
        LC_MeasureTraceDigitalPlotValues_NOERROR($filename);
    }

    if ( $filename = FLC_getFilename('trace_analog') ) {
        S_teststep_2nd_level( "Stop trace analog and store the plot file.", 'AUTO_NBR' );
        LC_MeasureTraceAnalogPlotValues_NOERROR($filename);
    }

    if ( $filename = FLC_getFilename('can_access') ) {
        S_teststep_2nd_level( "Stop and store can trace.", 'AUTO_NBR' );
        CA_trace_stop();
        CA_trace_store($filename);
        CA_simulation_start();
    }
    
    my $specificMeasurement = S_check_exec_option('CREIS_SpecificMeasurement') ? S_get_exec_option('CREIS_SpecificMeasurement') : 0;
    CREIS_StopSpecificMeasurements() if $specificMeasurement;

    return 1;
}

=head2 CREIS_WaitEcuReady

    CREIS_WaitEcuReady( );

Will wait untill the ECU is ready...

Functionality is switched depending on Execution Option "CREIS_EcuReadyOptimisation"
0 = it will just wait till "TIMER_ECU_READY" is over.
1 = it will use PD to read "rb_itm_EndOfItmTimestamp_u32" untill it becomes > 0.
    it will wait for "TIMER_PD_READY" untill it starts to communicate with the ECU 

=cut

sub CREIS_WaitEcuReady {
    my $ecuReadyOptimisation = 0;
    $ecuReadyOptimisation = S_get_exec_option('CREIS_EcuReadyOptimisation') if S_check_exec_option('CREIS_EcuReadyOptimisation');

    if ($ecuReadyOptimisation) {

        return if ($main::opt_offline);

        my ( $stat, $value_aref, $dec_value, $start, $timeout );
        $start     = S_get_TC_time_NOHTML();
        $dec_value = 0;
        $timeout   = S_get_contents_of_hash_NOHTML( [ 'TIMER', 'TIMER_ECU_READY' ] ) / 1000;

        # try to get timeout time from Project Defaults
        my $timerPdReady_ms = S_get_contents_of_hash_NOERROR( [ 'TIMER', 'TIMER_PD_READY' ] );

        unless ( defined $timerPdReady_ms ) {
            $timerPdReady_ms = 1500;
        }

        S_wait_ms($timerPdReady_ms);

        # add comparison with ECU_OFF timer here...
        while ( $dec_value < 1 and S_get_TC_time_NOHTML() - $start < $timeout ) {
            $dec_value = PRD_Read_Memory( 'rb_itm_EndOfItmTimestamp_u32', { memoryContentsAsInteger => 1 } );
            next unless $dec_value;
            S_w2log( 5, "CREIS_WaitItmFinished: rb_itm_EndOfItmTimestamp_u32 = '$dec_value'." );
        }

        my $total_time = S_get_TC_time_NOHTML() - $start;
        $total_time = sprintf( "%.2f", $total_time );
        S_w2log( 3, "CREIS_WaitItmFinished: returned after $total_time s of max TIMER_ECU_READY $timeout s." );
    }
    else {
        S_wait_ms('TIMER_ECU_READY');
    }

    return;
}

=head2 CREIS_WaitUntillRecordingFinished

    CREIS_WaitUntillRecordingFinished( );

Will wait untill the configured TRC recording is finished.
If no TRC is used it will wait for crash duration + DisposalTime_ms (from Defaults -> CRASH_MEASUREMENT_AND_EVALUATION )

=cut

sub CREIS_WaitUntillRecordingIsFinished {

    my $recordingTime_ms = FLC_getRecordingTime();

    S_teststep( "Wait for '$recordingTime_ms ms' untill crash and corresponding recordings are finished.", 'AUTO_NBR' );
    S_wait_ms($recordingTime_ms);

    return 1;
}

=head2 CallEvaluationSpecificFunction

    CallEvaluationSpecificFunction( $element, $simDev, $crashData_href, $callType, $simDevSettings_href );
    
Checks if a function exists with the name $element. These functions can be defined in 
FuncLib_TNT_CREIS_Framework, FuncLib_Custlib_CREIS_Framework or FuncLib_Project_CREIS_Framework
and are imported into this module.

If such a function exists it is called with $simDev, $crashData_href, $callType and $settings_href as arguments.

Returns 1 if the function execution was successful, 0 otherwise.

=cut

sub CallEvaluationSpecificFunction {
    my $element        = shift;
    my $simDev         = shift;
    my $crashData_href = shift;
    my $callType       = shift;
    my $settings_href  = shift;

    my $evaluationFunction = $element;

    return 0 if not exists &$evaluationFunction;

    {
        no strict 'refs';
        my $success = &$evaluationFunction( $simDev, $crashData_href, $callType, $settings_href );
        return 0 if not $success;
    }

    return 1;
}

END {
    # create the Excel fault table if perl is ending
    S_w2log(1, "FuncLib_CREIS_Framework: Trying to create the XLSM Report, when closing PERL.");
    FLC_XLSX_createReport() if ( defined $lastRESULTDB );
}

1;
__END__
