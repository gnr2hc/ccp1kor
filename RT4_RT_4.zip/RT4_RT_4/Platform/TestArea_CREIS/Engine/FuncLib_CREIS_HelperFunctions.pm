# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_CREIS_HelperFunctions;

use strict;
use warnings;
use LIFT_general;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_ProdDiag;
use LIFT_CSM;
use LIFT_MDSRESULT;
use LIFT_MKS;
use LIFT_can_access;
use LIFT_LIN_Access;
use LIFT_flexray_access;
use LIFT_functional_layer;
use LIFT_crash_simulation;
use FuncLib_SYC_INTERFACE;
use FuncLib_CREIS_LoggerFunctions;
use Clone 'clone';
use XML::LibXML;
use File::Basename;
use File::Path qw(make_path remove_tree);
use Path::Class;

use Exporter;
our @ISA    = qw(Exporter);
our @EXPORT = qw(
  FLC_addSimDeviceDependentFault
  FLC_check4LogSimDev
  FLC_closeXMLCrashNode
  FLC_configureTransientRecorder
  FLC_createCSMcontainer
  FLC_createXMLCrashNode
  FLC_evaluateFiringState
  FLC_evaluateFiringStateError
  FLC_evaluateFiringStateNoEvaluation
  FLC_evaluateRbFaultsAfterCrash
  FLC_evaluateRbFaultsBeforeCrash
  FLC_evaluateSimDeviceIgnored
  FLC_getAvgAlgoActiveRuntime
  FLC_getFilename
  FLC_getInvalidEnvironmentCombinations
  FLC_getNetSignal_dataref
  FLC_getNetSignalTimeZero
  FLC_getRecordingTime
  FLC_getSimDeviceSettings
  FLC_getTaskDropRate
  FLC_initialPreparations
  FLC_logSimDev
  FLC_prepareCrashData4MultiEvaluationSimDevices
  FLC_prepareMeasurementFiles
  FLC_waitForEdrStatus
  FLC_CheckEdrStatus
  FLC_CheckNbrOfStoredEDR
  FLC_CheckNbrOfStoredPepEDR
  FLC_ReadAndCheckRecordCompleteStatus
  FLC_ReadAndCheckPepRecordCompleteStatus
  FLC_ReadAndCheckMandatoryDataRecCompltStatus
  FLC_EnableNvmReadAfterCrash
  FLC_ReadCrashRecorder
  FLC_ReadPepCrashRecorder

);

=head1 NAME

FuncLib_CREIS_HelperFunctions

=head1 SYNOPSIS

    use FuncLib_CREIS_Framework;
    
  CREIS_PrepareMeasurements_and_Reporting
  CREIS_StartAllMeasurements
  CREIS_StopAllMeasurements
  CREIS_EvaluateMeasurements
  CREIS_FinishReporting
    
=head1 DESCRIPTION

This module provides common functions for measurement and evaluation of the official CREIS (used by system test).
It does not contain crash injection related functions (for this additional "LIFT_crash_simulation" is used in TCs)   

Additional this module imports functions for CREIS measurement and evaluation settings from FuncLib_TNT_CREIS_Framework 
and optionally from FuncLib_CustLib_CREIS_Framework and FuncLib_Project_CREIS_Framework
and exports all functions to the caller (TC).

For the documentation of the generic functions see the link below:

=for html
<a href='TC_FunctionLib/TC_TNT/FuncLib_TNT_CREIS_Framework.html'FuncLib_TNT_CREIS_Framework documentation</a>

=cut

my $settingsSimDevices_href                     = {};
my $generalSettings_href                        = {};
my $settingsAdditionalMeasurements_href         = {};
my $settingsFastDiagTrace_href                  = {};
my $settingsAdditionalPdLabels_href             = {};
my $settingsFaults_href                         = {};
my $settingsInvalidEnvironmentCombinations_href = {};
my $emptyFireState_href                         = {
    "MinT_ms"                   => "-",
    "ActualFiringTime_ms"       => "-",
    "MaxT_ms"                   => "-",
    "Text"                      => "-",
    "Firing_Status"             => "-",
    "DetectedFiringDuration_ms" => "-",
    "FireCounter_LowLevel_ms"   => "-",
    "FireCounter_HighLevel_ms"  => "-",
    "SquibResistance_ohm"       => "-",
};
my $emptyDurationEval_href = { "actual_duration" => "-" };
my $emptyValueEval_href    = { "actual_value"    => "-" };

my $usedMeasureDevices = {};

our $summaryXMLFile;
my $oCREISSummaryDoc;
my $rootElement;
my $actualSettingsNode;
my $actualCrashNode;
my $csmGlobalKeywordList_aref;
my $lasttcParaName = 'FIRST';

sub CheckAlgoIDs {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CheckAlgoIDs( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my @requiredAlgoIds = ( 'ProjIdHB_u8', 'ProjIdLB_u8', 'ParaId_u8', 'ParaTransferID1_u8', 'ParaTransferID2_u8', 'ParaTransferID3_u8', 'ParaTransferID4_u8' );

    S_w2log( 3, "Compare AlgoIDs from MDSRESULT DB with AlgoIDs from ECU...", undef, "CREIS_AlgoIDCheck" );

    # get AlgoIds from crashData
    my $algoIDs_MDSRESULT_href = $crashData_href->{'METADATA'}{'ALGOIDS'};

    # check if there are any AlgoIDs defined in crash data
    unless ( defined $algoIDs_MDSRESULT_href ) {
        S_set_error( "No AlgoIDs found in given crash data. MDSRESULT DB should be updated!", 120 );
        return 0;
    }

    my $algoIds_href = CheckRequiredAlgoIDs( $algoIDs_MDSRESULT_href, \@requiredAlgoIds );
    my $optionalAlgoIds_href = CheckOptionalAlgoIDs( $algoIDs_MDSRESULT_href, \@requiredAlgoIds );

    @{$algoIds_href}{ keys %{$optionalAlgoIds_href} } = values %{$optionalAlgoIds_href};

    return $algoIds_href;
}

sub CheckOptionalAlgoIDs {
    my $algoIDs_MDSRESULT_href = shift;
    my $requiredAlgoIds        = shift;

    my ( @notInSADoptionalAlgoIds, @notmatchedoptionalAlgoIds, $collectedAlgoIds_href );

    foreach my $algoID ( sort keys %$algoIDs_MDSRESULT_href ) {
        next if ( grep { /$algoID/ } @$requiredAlgoIds );
        my $algoIdValue_PD;

        my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_acc_AlgoIds_st." . $algoID } );
        if ($mapping_info) {
            $algoIdValue_PD = PRD_Read_Memory( "rb_acc_AlgoIds_st." . $algoID, { memoryContentsAsInteger => 1 } );

        }
        else {
            push( @notInSADoptionalAlgoIds, $algoID );
            $algoIdValue_PD = '---';
        }

        my $logText = "rb_acc_AlgoIds_st.$algoID: ";
        $logText .= $algoIdValue_PD if $algoIdValue_PD eq '---';
        $logText .= sprintf( "0x%02X", $algoIdValue_PD ) unless $algoIdValue_PD eq '---';
        $logText .= " MDSRESULT         $algoID: ";
        $logText .= $algoIDs_MDSRESULT_href->{$algoID} if $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $logText .= sprintf( "0x%02X", $algoIDs_MDSRESULT_href->{$algoID} ) unless $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        S_w2log( 3, $logText );

        $collectedAlgoIds_href->{$algoID}{"value_MDS"} = '---' if $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_MDS"} = sprintf( "0x%02X", $algoIDs_MDSRESULT_href->{$algoID} ) unless $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_ECU"} = $algoIdValue_PD if $algoIdValue_PD eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_ECU"} = sprintf( "0x%02X", $algoIdValue_PD ) unless $algoIdValue_PD eq '---';
        $collectedAlgoIds_href->{$algoID}{"isRequired"} = 0;

        if ( $algoIdValue_PD eq '---' ) {
            S_w2log( 3, "Not tested for '$algoID'!\n", 'blue' );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "NOT TESTED";
        }
        elsif ( $algoIdValue_PD == $algoIDs_MDSRESULT_href->{$algoID} ) {
            S_w2log( 3, "Match for optional '$algoID'!\n" );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "PASS";
        }
        else {
            S_w2log( 3, "Missmatch for optional'$algoID'!\n" );
            push( @notmatchedoptionalAlgoIds, $algoID );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "FAIL";
        }
    }

    return $collectedAlgoIds_href if ($main::opt_offline);    # return 1 in offline

    # Throw an warning if there are entries in the list of optional AlgoIDs not available in SAD
    if ( @notInSADoptionalAlgoIds > 0 ) {
        my $notInSADAlgoIdsString = join( "\n", @notInSADoptionalAlgoIds );
        S_set_warning("The following optional AlgoIds are not defined in SAD file:\n$notInSADAlgoIdsString\n\n");
    }

    # Throw an warning if there are entries in the list unmatched optional AlgoIDs
    if ( @notmatchedoptionalAlgoIds > 0 ) {
        my $notmatchedAlgoIdsString = join( "\n", @notmatchedoptionalAlgoIds );
        S_set_warning("The following optional AlgoIds did not match (ECU != MDSRESULT):\n$notmatchedAlgoIdsString\n\n");
    }

    return $collectedAlgoIds_href;
}

sub CheckRequiredAlgoIDs {
    my $algoIDs_MDSRESULT_href = shift;
    my $requiredAlgoIds        = shift;

    my ( @notFoundrequiredAlgoIds, @notInSADrequiredAlgoIds, @notmatchedrequiredAlgoIds, $collectedAlgoIds_href );

    foreach my $algoID (@$requiredAlgoIds) {
        unless ( exists $algoIDs_MDSRESULT_href->{$algoID} ) {
            push( @notFoundrequiredAlgoIds, $algoID );
            $algoIDs_MDSRESULT_href->{$algoID} = "---";
        }
        my $algoIdValue_PD;

        my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_acc_AlgoIds_st." . $algoID } );
        if ($mapping_info) {
            $algoIdValue_PD = PRD_Read_Memory( "rb_acc_AlgoIds_st." . $algoID, { memoryContentsAsInteger => 1 } );
        }
        else {
            push( @notInSADrequiredAlgoIds, $algoID );
            $algoIdValue_PD = '---';
        }

        my $logText = "rb_acc_AlgoIds_st.$algoID: ";
        $logText .= $algoIdValue_PD if $algoIdValue_PD eq '---';
        $logText .= sprintf( "0x%02X", $algoIdValue_PD ) unless $algoIdValue_PD eq '---';
        $logText .= " MDSRESULT         $algoID: ";
        $logText .= $algoIDs_MDSRESULT_href->{$algoID} if $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $logText .= sprintf( "0x%02X", $algoIDs_MDSRESULT_href->{$algoID} ) unless $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $logText .= "\n";
        S_w2log( 3, $logText );

        $collectedAlgoIds_href->{$algoID}{"value_MDS"} = '---' if $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_MDS"} = sprintf( "0x%02X", $algoIDs_MDSRESULT_href->{$algoID} ) unless $algoIDs_MDSRESULT_href->{$algoID} eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_ECU"} = '---' if $algoIdValue_PD eq '---';
        $collectedAlgoIds_href->{$algoID}{"value_ECU"} = sprintf( "0x%02X", $algoIdValue_PD ) unless $algoIdValue_PD eq '---';
        $collectedAlgoIds_href->{$algoID}{"isRequired"} = 1;

        if ( $algoIdValue_PD eq '---' ) {
            S_w2log( 3, "Not tested for '$algoID'!\n", 'blue' );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "NOT TESTED";
        }
        elsif ( $algoIdValue_PD == $algoIDs_MDSRESULT_href->{$algoID} ) {
            S_w2log( 3, "Match for '$algoID'!\n" );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "PASS";
        }
        else {
            S_w2log( 3, "Missmatch for '$algoID'!\n" );
            push( @notmatchedrequiredAlgoIds, $algoID );
            $collectedAlgoIds_href->{$algoID}{"VERDICT"} = "FAIL";
        }
    }

    return $collectedAlgoIds_href if ($main::opt_offline);    # return 1 in offline

    # Throw an error if there are entries in the list not found required AlgoIDs
    if ( @notFoundrequiredAlgoIds > 0 ) {
        my $notFoundRequiredAlgoIdsString = join( "\n", @notFoundrequiredAlgoIds );
        S_set_error( "The following required AlgoIds were not found in CREIS input file (*.mdb):\n$notFoundRequiredAlgoIdsString\n\n", 120 );
    }

    # Throw an error if there are entries in the list of required AlgoIDs not available in SAD
    if ( @notInSADrequiredAlgoIds > 0 ) {
        my $notInSADAlgoIdsString = join( "\n", @notInSADrequiredAlgoIds );
        S_set_error( "The following required AlgoIds are not defined in SAD file:\n$notInSADAlgoIdsString\n\n", 120 );
    }

    # Throw an error if there are entries in the list unmatched required AlgoIDs
    if ( @notmatchedrequiredAlgoIds > 0 ) {
        my $notmatchedAlgoIdsString = join( "\n", @notmatchedrequiredAlgoIds );
        S_set_error( "The following required AlgoIds did not match (ECU != MDSRESULT):\n$notmatchedAlgoIdsString\n\n", 120 );
    }

    return $collectedAlgoIds_href;
}

sub CheckSquibConfiguration {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CheckSquibConfiguration( $device_data_href )', @args );

    my $device_data_href = shift @args;
    my ( @validSquibs, @squibsWithoutMDB, @squibsNotProgrammed, @squibsWithoutSwLabel, @ignoredSquibs, @squibInvalidConfiguration );

    # parse all squibs that are available in SW
    foreach my $squib ( keys %{ $device_data_href->{'squibs'} } ) {

        if ( $device_data_href->{squibs}{$squib}{Configured} ) {

            if ( $settingsSimDevices_href->{$squib}{Ignored} ) {
                push( @ignoredSquibs, $squib );
                next;
            }
            elsif ( not exists $settingsSimDevices_href->{$squib}{'Type'} ) {
                push( @squibsWithoutMDB, $squib );
                next;
            }
            elsif ( $settingsSimDevices_href->{$squib}{'Type'} eq "Squib" ) {
                push( @validSquibs, $squib );
                next;
            }
            else {
                push( @squibInvalidConfiguration, $squib );
                next;
            }

        }
        else {
            if ( not exists $settingsSimDevices_href->{$squib} or $settingsSimDevices_href->{$squib}{Ignored} ) {
                next;
            }
            elsif ( $settingsSimDevices_href->{$squib}{'Type'} eq "Squib" ) {
                push( @squibsNotProgrammed, $squib );
                next;
            }
        }
    }

    # ensure that all valid squibs are also available in SW
    foreach my $squib ( keys %{$settingsSimDevices_href} ) {
        next if $settingsSimDevices_href->{$squib}{'Type'} ne "Squib";
        push( @squibsWithoutSwLabel, $squib ) unless exists $device_data_href->{squibs}{$squib};
    }

    # Throw an error if there are entries in the list @squibsWithoutMDB
    if ( @squibsWithoutMDB > 0 ) {
        my $squibsWithoutMDBString = join( "\n", @squibsWithoutMDB );
        S_set_error( "The following squibs are configured but not available in MDS (and therefore will not be tested):\n$squibsWithoutMDBString\n\n", 120 );
    }

    # Throw an error if there are entries in the list @squibsNotProgrammed
    if ( @squibsNotProgrammed > 0 and not $main::opt_offline ) {
        my $squibsNotProgrammedString = join( "\n", @squibsNotProgrammed );
        S_set_error( "The following squibs are in MDS but currently not configured in SW:\n$squibsNotProgrammedString\n\n", 120 );
    }

    # Throw an error if there are entries in the list @squibsWithoutSwLabel
    if ( @squibsWithoutSwLabel > 0 ) {
        my $squibsWithoutSwLabelString = join( "\n", @squibsWithoutSwLabel );
        S_set_error( "The following squibs are not available in SW at all:\n$squibsWithoutSwLabelString\n\n", 120 );
    }

    # Throw an error if there are entries in the list @ignoredSquibs
    if ( @ignoredSquibs > 0 ) {
        my $ignoredSquibsString = join( "\n", @ignoredSquibs );
        S_set_error( "The following squibs are in MDS but set to ignored in CREIS Mapping File:\n$ignoredSquibsString\n\n", 120 );
    }

    # Throw an error if there are entries in the list @ignoredSquibs
    if ( @squibInvalidConfiguration > 0 ) {
        my $squibInvalidConfigurationString = join( "\n", @squibInvalidConfiguration );
        S_set_error( "The following squibs are in MDS but not configured as squibs in CREIS Mapping File:\n$squibInvalidConfigurationString\n\n", 120 );
    }

    return \@validSquibs;
}

=head2 FLC_check4LogSimDev

    FLC_check4LogSimDev( $deviceName );

=cut

sub FLC_check4LogSimDev {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_check4LogSimDev( $deviceName )', @args );

    my $deviceName = shift @args;

    # flag 'FLC_logSimDev' available -> everything okay
    if ( exists $settingsSimDevices_href->{$deviceName}{"FLC_logSimDev"} ) {
        delete $settingsSimDevices_href->{$deviceName}{"FLC_logSimDev"};
        return 1;
    }

    my $evaluationFunction = $settingsSimDevices_href->{$deviceName}{'Evaluation'};

    my $fireState_href = clone($emptyFireState_href);
    $fireState_href->{Text}          = "ERROR in evaluation";
    $fireState_href->{Firing_Status} = "INCONC";

    S_set_error("Implementation of '$evaluationFunction' did not call 'FLC_logSimDev', but this is necessary!");
    FLC_logSimDev( $deviceName, $fireState_href );

    return 0;
}

sub FLC_CheckEdrStatus {
    my $ecuStatus    = shift;
    my $anyEdrStored = shift;

    my $name         = "ECU Status - Byte 2";
    my $verdict      = "NA";
    my $failedStatus = 0;
    my $comment;

    if ( not defined $ecuStatus ) {
        $failedStatus = 1;
        $ecuStatus    = "-";
        $verdict      = "FAIL";
    }
    elsif ( $ecuStatus & 1 ) {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "bit0=1: edr 'data collector' still active (storing/erasing)";
    }
    elsif ( $ecuStatus & 2 ) {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "bit1=1: edr 'pedpro' active (not Idle and not disabled)";
    }
    elsif ( $ecuStatus & 128 and not $anyEdrStored ) {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "bit4=1: any crash stored (only data collector & pedpro), but none of the Edr has header entries";
    }
    elsif ( not ($ecuStatus & 128) and $anyEdrStored ) {
        $verdict = "FAIL";
        $comment = "bit7=0: no crash stored (only data collector & pedpro), but some of the Edr has header entries";
    }
    else {
        $verdict = "PASS";
    }
    my $ecuStatus_text = S_dec2hex_NOERROR( $ecuStatus );
    FLC_LOG_EDRValues( $name, $ecuStatus_text, $verdict, $comment );

    return $failedStatus;
}

sub FLC_getTaskDropRate {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_getTaskDropRate ( $dataRef_href , $signal_label, $task_ms, $startValue, $maxValue )', @args );

    my $dataRef_href = shift @args;
    my $signal_label = shift @args;
    my $task_ms      = shift @args;
    my $startValue   = shift @args;
    my $maxValue     = shift @args;

    S_w2log( 3, " FCL_getTaskDropRate : started for \$signal_label '$signal_label' and \$task_ms '$task_ms' [\$startValue $startValue, \$maxValue $maxValue ].  \n" );

    # get all phases where Algo is active
    my ( $statusFirCtrl, $lastStatus, @phaseStartTimes, @phaseEndTimes, $nbrPhases, $detected_phases_text );
    my $algoActivePhaseStarted = 0;

    $lastStatus = 0;
    $nbrPhases  = 0;

    foreach my $time_stamp ( sort { $a <=> $b } keys %$dataRef_href ) {
        next unless defined $dataRef_href->{$time_stamp}{'rb_fcl_StatusFirCtrl_u8'};

        $lastStatus = $statusFirCtrl if defined $statusFirCtrl;

        $statusFirCtrl = $dataRef_href->{$time_stamp}{"rb_fcl_StatusFirCtrl_u8"};

        if ( $algoActivePhaseStarted == 0 ) {

            # no phase changed...
            next if $statusFirCtrl <= $lastStatus;

            # phase start
            $algoActivePhaseStarted = 1;
            push @phaseStartTimes, $time_stamp;
            $nbrPhases++;
            $detected_phases_text .= "PhaseNbr: '$nbrPhases' start '$time_stamp' ";
        }
        elsif ( $algoActivePhaseStarted == 1 ) {
            next if $statusFirCtrl >= $lastStatus;

            # phase end
            $algoActivePhaseStarted = 0;
            push @phaseEndTimes, $time_stamp;
            $detected_phases_text .= "end '$time_stamp', ";
        }
    }

    S_w2log( 5, "FCL_getTaskDropRate : $detected_phases_text" );

    my ( $total_time_ms, $counter_difference, $detected_counter_delta_sum, $counter_sum, $first_counter_value, $nbr_of_counter_reset, $actual_counter_value, $actual_time_stamp, $previous_time_stamp, $previous_counter_value, $phase4text );

    for my $phase ( 0 .. $nbrPhases - 1 ) {
        $previous_time_stamp    = 0;
        $actual_time_stamp      = 0;
        $previous_counter_value = undef;
        $first_counter_value    = undef;
        $nbr_of_counter_reset   = 0;
        $phase4text             = $phase + 1;

        # calculate total recording time from RT counter
        foreach my $time_stamp ( sort { $a <=> $b } keys %$dataRef_href ) {
            next unless defined $dataRef_href->{$time_stamp}{"rb_rt_500uscounter_u8"};
            next if ( $time_stamp < $phaseStartTimes[$phase] );
            last if ( defined $phaseEndTimes[$phase] ) && ( $time_stamp > $phaseEndTimes[$phase] );

            $actual_counter_value = $dataRef_href->{$time_stamp}{"rb_rt_500uscounter_u8"};

            unless ( defined $previous_counter_value ) {
                $previous_counter_value = $actual_counter_value;
                next;
            }

            $counter_difference = $actual_counter_value - $previous_counter_value;
            $counter_difference += ( $maxValue - $startValue + 1 ) if $counter_difference < 0;
            $counter_sum += $counter_difference;

            $previous_counter_value = $actual_counter_value;
        }

        S_w2log( 5, " FCL_getTaskDropRate : \$counter_sum = '$counter_sum' after phase '$phase' \n" );

        $previous_counter_value = undef;

        # count resets of $signal_label, first and last time stamp
        foreach my $time_stamp ( sort { $a <=> $b } keys %$dataRef_href ) {
            next unless defined $dataRef_href->{$time_stamp}{$signal_label};
            next if ( $time_stamp < $phaseStartTimes[$phase] );
            last if ( defined $phaseEndTimes[$phase] ) && ( $time_stamp > $phaseEndTimes[$phase] );

            $actual_counter_value = $dataRef_href->{$time_stamp}{$signal_label};

            $first_counter_value = $actual_counter_value unless ( defined $first_counter_value );

            $nbr_of_counter_reset++ if ( defined $previous_counter_value && $actual_counter_value < $previous_counter_value );

            $previous_counter_value = $actual_counter_value;

        }

        my $last_counter_value = $previous_counter_value;

        my $detected_counter_delta = $last_counter_value - $first_counter_value + $nbr_of_counter_reset * ( $maxValue - $startValue + 1 );
        $detected_counter_delta_sum += $detected_counter_delta;

        S_w2log( 5, " FCL_getTaskDropRate : \$first_counter_value = '$first_counter_value' in phase '$phase'\n" );
        S_w2log( 5, " FCL_getTaskDropRate : \$last_counter_value = '$last_counter_value' in phase '$phase'\n" );
        S_w2log( 5, " FCL_getTaskDropRate : \$nbr_of_counter_reset = '$nbr_of_counter_reset' in phase '$phase'\n" );
        S_w2log( 5, " FCL_getTaskDropRate : \$detected_counter_delta = '$detected_counter_delta' in phase '$phase'\n" );
    }

    $total_time_ms = $counter_sum / 2;
    S_w2log( 5, " FCL_getTaskDropRate : \$total_time_ms = '$total_time_ms ms' \n" );

    my $expected_counter_delta = $total_time_ms / $task_ms;

    # expected_counter_delta == 0 means no correct input data
    if ( $expected_counter_delta < 10 ) {
        S_w2log( 3, " FCL_getTaskDropRate : calculation of TaskDropRate not possible \n" );
        return "N.A.";
    }

    S_w2log( 5, " FCL_getTaskDropRate : \$expected_counter_delta = '$expected_counter_delta' \n" );
    S_w2log( 5, " FCL_getTaskDropRate : \$detected_counter_delta = '$detected_counter_delta_sum' \n" );

    my $taskDropRate;
    my $taskDropRate_percent;

    if ( $detected_counter_delta_sum < $expected_counter_delta ) {
        $taskDropRate = 1 - ( $detected_counter_delta_sum / $expected_counter_delta );
    }
    else {
        $taskDropRate = 0;
    }

    $taskDropRate_percent = sprintf( "%01d", $taskDropRate * 100 );
    S_w2log( 3, " FCL_getTaskDropRate : detected \$taskDropRate = '$taskDropRate_percent %' \n" );

    return $taskDropRate_percent;
}

=head2 FLC_addSimDeviceDependentFault

    FLC_addSimDeviceDependentFault($faultName);

=cut

sub FLC_addSimDeviceDependentFault {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_addSimDeviceDependentFault($faultName);', @args );

    my $faultName = shift @args;

    push( @{ $usedMeasureDevices->{'fault_memory'}{"SimDeviceDependentFaults"} }, $faultName );

    return 1;
}

sub FLC_getAvgAlgoActiveRuntime {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_getAvgAlgoActiveRuntime ( $dataRef_href )', @args );

    my $dataRef_href = shift @args;

    my ( $avgRuntime, $currentRuntime, $statusFirCtrl, $lastStatus, $sumRuntime, $nbr );

    $avgRuntime = "N.A.";

    foreach my $time_stamp ( sort { $a <=> $b } keys %$dataRef_href ) {
        next unless defined $dataRef_href->{$time_stamp}{"rb_fcl_StatusFirCtrl_u8"};
        next unless defined $dataRef_href->{$time_stamp}{"rb_rt_CurrentRuntime_u32"};

        $currentRuntime = $dataRef_href->{$time_stamp}{"rb_rt_CurrentRuntime_u32"};
        $statusFirCtrl  = $dataRef_href->{$time_stamp}{"rb_fcl_StatusFirCtrl_u8"};

        if ( $statusFirCtrl == 0 or $statusFirCtrl < $lastStatus ) {
            $lastStatus = 0 if $statusFirCtrl == 0;
            next;
        }
        $nbr++;
        $sumRuntime += $currentRuntime;
        $lastStatus = $statusFirCtrl;
    }

    $avgRuntime = $sumRuntime / $nbr if $nbr > 0;
    $avgRuntime = sprintf( "%01d", $avgRuntime );

    S_w2log( 3, " FCL_getAvgAlgoActiveRuntime : detected \$avgRuntime = '$avgRuntime' \n" );

    return $avgRuntime;
}

=head2 FLC_createCSMcontainer

    FLC_createCSMcontainer( );

=cut

sub FLC_createCSMcontainer {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_createCSMcontainer ( $csmPerCrashKeywordList_aref )', @args );

    my $csmPerCrashKeywordList_aref = shift @args;

    # TODO new handling keywords
    return 1 if ($main::opt_offline);    # return 1 in offline
    my ( @keywordList, $filename, $filenames_href, $folder );

    push @keywordList, @$csmGlobalKeywordList_aref;
    push @keywordList, @$csmPerCrashKeywordList_aref;

    my @alreadyArchivedFiles;

    $filename = basename( FLC_getFilename('zip_file'), ".zip" );
    my $container_id = CSM_create_container($filename);

    # $usedMeasureDevices->{'trace_digital'} = $filename_common . "_trace_digital.txt.unv" if exists $usedMeasureDevices->{'trace_digital'};
    $filename = FLC_getFilename('trace_digital');
    if ( $filename and -e $filename ) {
        CSM_add_userfile( $container_id, $filename, 'trace_digital' );
        push( @alreadyArchivedFiles, basename($filename) );
    }

    # $usedMeasureDevices->{'trace_analog'}  = $filename_common . "_trace_analog.txt.unv"  if exists $usedMeasureDevices->{'trace_analog'};
    $filename = FLC_getFilename('trace_analog');
    if ( $filename and -e $filename ) {
        CSM_add_userfile( $container_id, $filename, 'trace_analog' );
        push( @alreadyArchivedFiles, basename($filename) );
    }

    # $usedMeasureDevices->{'can_access'}    = $filename_common . "_NET_Trace.asc"         if exists $usedMeasureDevices->{'can_access'};
    $filename = FLC_getFilename('can_access');
    if ( $filename and -e $filename ) {
        CSM_add_userfile( $container_id, $filename, 'can_access' );
        push( @alreadyArchivedFiles, basename($filename) );
    }

    # $usedMeasureDevices->{'nvmDump'}       = $filename_common . "_NVM_Dump.txt"          if exists $usedMeasureDevices->{'nvmDump'};
    $filename = FLC_getFilename('nvmDumpBeforeCrash');
    if ( $filename and -e $filename ) {
        CSM_add_userfile( $container_id, $filename, 'nvmDumpBeforeCrash' ) if -e $filename;
        push( @alreadyArchivedFiles, basename($filename) );
    }

    $filename = FLC_getFilename('nvmDumpAfterCrash');
    if ( $filename and -e $filename ) {
        CSM_add_userfile( $container_id, $filename, 'nvmDumpAfterCrash' ) if -e $filename;
        push( @alreadyArchivedFiles, basename($filename) );
    }

    # $usedMeasureDevices->{'fd_trace'}      = $filename_common . "_FD_files"              if exists $usedMeasureDevices->{'fd_trace'};
    $folder = FLC_getFilename('fd_trace');
    if ( $folder and -d $folder ) {
        if ( -e $folder . ".txt.unv" ) {
            CSM_add_userfile( $container_id, $folder . ".txt.unv", 'fd_trace' );
            push( @alreadyArchivedFiles, basename( $folder . ".txt.unv" ) );
        }

        my $zip_handle = S_open_zip( $folder . ".zip" );

        my $dir = dir($folder);
        foreach my $element ( $dir->children() ) {
            S_w2log( 3, "Try to zip $element" );
            S_add_to_zip( $zip_handle, $element->stringify );
        }

        S_close_zip($zip_handle);

        CSM_add_userfile( $container_id, $folder . ".zip" );
        push( @alreadyArchivedFiles, basename( $folder . ".zip" ) );
        remove_tree($folder);

    }

    if ( $filenames_href = FLC_getFilename('edrReader') ) {
        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $filenames_href->{EdrId} } ) {
            next if $edrNbr !~ /([0-9]+)/;

            if ( exists $filenames_href->{EdrId}{$edrNbr}{filename} and -e $filenames_href->{EdrId}{$edrNbr}{filename} ) {
                CSM_add_userfile( $container_id, $filenames_href->{EdrId}{$edrNbr}{filename}, "edrReader" );
                push( @alreadyArchivedFiles, basename( $filenames_href->{EdrId}{$edrNbr}{filename} ) );
            }

            if ( exists $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} and -e $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} ) {
                CSM_add_userfile( $container_id, $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete}, "edrReader" );
                push( @alreadyArchivedFiles, basename( $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} ) );
            }
        }
    }

    if ( $filenames_href = FLC_getFilename('pepEdrReader') ) {
        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $filenames_href->{EdrId} } ) {
            next if $edrNbr !~ /([0-9]+)/;

            if ( exists $filenames_href->{EdrId}{$edrNbr}{filename} and -e $filenames_href->{EdrId}{$edrNbr}{filename} ) {
                CSM_add_userfile( $container_id, $filenames_href->{EdrId}{$edrNbr}{filename}, "pepEdrReader" );
                push( @alreadyArchivedFiles, basename( $filenames_href->{EdrId}{$edrNbr}{filename} ) );
            }

            if ( exists $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} and -e $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} ) {
                CSM_add_userfile( $container_id, $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete}, "pepEdrReader" );
                push( @alreadyArchivedFiles, basename( $filenames_href->{EdrId}{$edrNbr}{filenameIncomplete} ) );
            }
        }
    }

    # Zip all remaining files and folder
    $folder = FLC_getFilename('folder');
    my $dir = dir($folder);
    foreach my $element ( $dir->children() ) {
        my $fileName = basename($element);
        S_w2log( 3, "File: '$fileName'" );
        unless ( grep { $_ =~ /$fileName/ } @alreadyArchivedFiles ) {
            CSM_add_userfile( $container_id, $element->stringify );
        }
    }

    # remove the folder which was used to collect the files...
    remove_tree($folder);

    # add keywords to the container
    CSM_add_keywords( $container_id, \@keywordList );

    # pack container
    S_w2log( 4, "FLC_createCSMcontainer Packing CSM container" );
    CSM_pack_container($container_id);

    S_w2log( 4, "FLC_createCSMcontainer Archive CSM container '$container_id'\n" );
    CSM_archive_container( $container_id, 'NoLocalData' );    # KeepLocalData or NoLocalData

    return 1;
}

=head2 FLC_evaluateRbFaultsAfterCrash

    FLC_evaluateRbFaultsAfterCrash($crashData_href, $expectedFaultsBeforeCrash_href);

=cut

sub FLC_evaluateRbFaultsAfterCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateRbFaultsAfterCrash($crashData_href, $expectedFaultsBeforeCrash_href);', @args );

    my ( @faultNamesAfterCrash, @unexpectedFaults, @missingFaults );
    my $crashData_href                 = shift @args;
    my $expectedFaultsBeforeCrash_href = shift @args;
    my $filenames_href                 = FLC_getFilename('fault_memory');
    my $faultMemory_obj                = $filenames_href->{AfterCrash}{object};

    if ( not defined $faultMemory_obj ) {
        FLC_LOG_Faults( 'Error', 'DetectedAfterCrash', 1 );
        return;
    }

    my $mandatoryBeforeCrash_href     = $expectedFaultsBeforeCrash_href->{mandatory};
    my $optionalBeforeCrash_href      = $expectedFaultsBeforeCrash_href->{optional};
    my $genericFaultsAfterCrash_href  = GetGenericFaultsAdditionalAfterCrash($crashData_href);
    my $crashDependentFaults_href     = GetCrashDependentFaults($crashData_href);
    my $simDeviceDependentFaults_href = GetSimDeviceDependentFaults($crashData_href);
    my $genericFaultsAfterCrashFilled_href;

    if ( $faultMemory_obj->get_number_of_faults() ) {
        foreach my $fault_entry_obj ( values %{ $faultMemory_obj->FaultEntriesHash } ) {
            my $faultName = $fault_entry_obj->FaultName;

            FLC_LOG_Faults( $faultName, 'DetectedAfterCrash', 1 );

            push( @faultNamesAfterCrash, $faultName );

            if ( exists $mandatoryBeforeCrash_href->{$faultName} ) {
                next;
            }

            if ( exists $optionalBeforeCrash_href->{$faultName} ) {
                next;
            }

            if ( exists $simDeviceDependentFaults_href->{$faultName} ) {
                $simDeviceDependentFaults_href->{$faultName}{Detected} = 1;
                next;
            }

            if ( my $perFault_href = FaultIsGenericAfterCrash( $faultName, $faultMemory_obj, $genericFaultsAfterCrash_href ) ) {
                $genericFaultsAfterCrashFilled_href->{$faultName} = $perFault_href;
                FLC_LOG_Faults( $faultName, 'GenericAfterCrash', 1 );
                FLC_LOG_Faults( $faultName, 'Comment',           $genericFaultsAfterCrashFilled_href->{$faultName}{Comment} );
                delete $genericFaultsAfterCrashFilled_href->{$faultName}{Comment};
                next;
            }

            if ( exists $crashDependentFaults_href->{$faultName} ) {
                FLC_LOG_Faults( $faultName, 'CrashDependent', 1 );
                FLC_LOG_Faults( $faultName, 'Comment',        "Fault accepted by user." );
                next;
            }

            FLC_LOG_Faults( $faultName, 'UnexpectedAfterCrash', 1 );
            push( @unexpectedFaults, $faultName );
        }
    }
    else {
        FLC_LOG_Faults( 'NoFault', 'DetectedAfterCrash', 1 );
    }

    foreach my $faultName ( keys %$simDeviceDependentFaults_href ) {
        FLC_LOG_Faults( $faultName, 'SimDeviceDependent', 1 );
        FLC_LOG_Faults( $faultName, 'Comment',            "Fault expected due to SimDevice" );
        next if delete $simDeviceDependentFaults_href->{$faultName}{Detected};
        FLC_LOG_Faults( $faultName, 'MissingAfterCrash', 1 );
        push( @missingFaults, $faultName );
    }

    my $expected_faults_href;
    $expected_faults_href->{mandatory} = $mandatoryBeforeCrash_href;
    @{ $expected_faults_href->{mandatory} }{ keys %$simDeviceDependentFaults_href }      = values %$simDeviceDependentFaults_href;
    @{ $expected_faults_href->{mandatory} }{ keys %$genericFaultsAfterCrashFilled_href } = values %$genericFaultsAfterCrashFilled_href;

    $expected_faults_href->{optional} = $optionalBeforeCrash_href;
    @{ $expected_faults_href->{optional} }{ keys %$crashDependentFaults_href } = values %$crashDependentFaults_href;

    EvaluateFaults_NOVERDICT( $faultMemory_obj, $expected_faults_href );

    return 1;

}

=head2 FLC_evaluateRbFaultsBeforeCrash

    FLC_evaluateRbFaultsBeforeCrash($crashData_href);

=cut

sub FLC_evaluateRbFaultsBeforeCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateRbFaultsBeforeCrash( $crashData_href )', @args );

    my $crashData_href = shift @args;

    my ( @faultNamesBeforeCrash, @unexpectedFaults, @missingFaults );
    my $filenames_href  = FLC_getFilename('fault_memory');
    my $faultMemory_obj = $filenames_href->{BeforeCrash}{object};

    if ( not defined $faultMemory_obj ) {
        FLC_LOG_Faults( 'Error', 'DetectedBeforeCrash', 1 );
        return;
    }

    my $environmentDependentFaults_href = GetEnvironmentDependentFaults($crashData_href);
    my $genericFaultsBeforeCrash_href   = GetGenericFaultsBeforeCrash($crashData_href);

    if ( $faultMemory_obj->get_number_of_faults() ) {
        foreach my $fault_entry_obj ( values %{ $faultMemory_obj->FaultEntriesHash } ) {
            my $faultName = $fault_entry_obj->FaultName;

            FLC_LOG_Faults( $faultName, 'DetectedBeforeCrash', 1 );

            push( @faultNamesBeforeCrash, $faultName );

            if ( exists $environmentDependentFaults_href->{$faultName} ) {
                $environmentDependentFaults_href->{$faultName}{Detected} = 1;
                next;
            }

            if ( exists $genericFaultsBeforeCrash_href->{$faultName} ) {
                FLC_LOG_Faults( $faultName, 'GenericBeforeCrash', 1 );
                FLC_LOG_Faults( $faultName, 'Comment',            "Fault accepted by user." );
                next;
            }

            FLC_LOG_Faults( $faultName, 'UnexpectedBeforeCrash', 1 );
            push( @unexpectedFaults, $faultName );
        }
    }
    else {
        FLC_LOG_Faults( 'NoFault', 'DetectedBeforeCrash', 1 );
    }

    foreach my $faultName ( keys %$environmentDependentFaults_href ) {
        FLC_LOG_Faults( $faultName, 'EnvironmentDependent', 1 );
        FLC_LOG_Faults( $faultName, 'Comment', $environmentDependentFaults_href->{$faultName}{Comment} );
        delete $environmentDependentFaults_href->{$faultName}{Comment};
        next if delete $environmentDependentFaults_href->{$faultName}{Detected};
        FLC_LOG_Faults( $faultName, 'MissingBeforeCrash', 1 );
        push( @missingFaults, $faultName );
    }

    my $expected_faults_href = {
        'mandatory' => $environmentDependentFaults_href,
        'optional'  => $genericFaultsBeforeCrash_href,
    };

    EvaluateFaults_NOVERDICT( $faultMemory_obj, $expected_faults_href );

    return $expected_faults_href;

}

=head2 FLC_evaluateSimDeviceIgnored

    $success = FLC_evaluateSimDeviceIgnored( $deviceName, $crashData_href );

Will check if for the given simDevice $deviceName the ignored flag is set.
If the ignored flag is set, it will fill the reporting with dummy values where necessary and return 1.
Directly returns 0 if the ignored flag is not set.

=cut

sub FLC_evaluateSimDeviceIgnored {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateSimDeviceIgnored( $deviceName, $crashData_href )', @args );

    my $deviceName     = shift @args;
    my $crashData_href = shift @args;

    return 0 unless ( $settingsSimDevices_href->{$deviceName}{'Ignored'} );

    my $fireState_href = clone($emptyFireState_href);

    $fireState_href->{MinT_ms}       = $crashData_href->{'EXPECTEDRESULT'}{$deviceName}{MINT};
    $fireState_href->{MaxT_ms}       = $crashData_href->{'EXPECTEDRESULT'}{$deviceName}{MAXT};
    $fireState_href->{IsDeployed}    = $crashData_href->{'EXPECTEDRESULT'}{$deviceName}{ISDEPLOYED};
    $fireState_href->{Text}          = $settingsSimDevices_href->{$deviceName}{'Ignored'};
    $fireState_href->{Firing_Status} = "Ignored";

    FLC_logSimDev( $deviceName, $fireState_href );

    return 1;

}

=head2 FLC_getNetSignal_dataref

    $netSignal_href = FLC_getNetSignal_dataref( $signal_label , $busType );

Returns the Signal Dataref of Signal $signal_label for the actual crash.

=cut

sub FLC_getNetSignal_dataref {
    my @args = @_;
    return unless S_checkFunctionArguments( 'FLC_getNetSignal_dataref( $signal_label, $busType )', @args );

    my $signal_label = shift @args;
    my $busType      = shift @args;
    my $signal_href;

    return $usedMeasureDevices->{'NetSignalsHrefs'}{$busType}{$signal_label} if exists $usedMeasureDevices->{'NetSignalsHrefs'}{$busType}{$signal_label};

    $signal_href = CA_trace_get_dataref_NOERROR( FLC_getFilename('can_access'),  [$signal_label] ) if $busType eq 'CAN';
    $signal_href = LIN_trace_get_dataref_NOERROR( FLC_getFilename('can_access'), [$signal_label] ) if $busType eq 'LIN';
    $signal_href = FR_trace_get_dataref_NOERROR( FLC_getFilename('can_access'),  [$signal_label] ) if $busType eq 'FLXR';

    $usedMeasureDevices->{'NetSignalsHrefs'}{$busType}{$signal_label} = $signal_href;

    return $signal_href;

}

=head2 FLC_getNetSignalTimeZero

    $netSignalTimeZero_s = FLC_getNetSignalTimeZero( );

Returns the netSignalTimeZero_s for the actual crash. If it is not known yet, it will calculate and store it.

=cut

sub FLC_getNetSignalTimeZero {
    my @args = @_;
    return unless S_checkFunctionArguments( 'FLC_getNetSignalTimeZero( )', @args );

    if ( defined $usedMeasureDevices->{'NetSignalTimeZero_s'} ) {

        # return with undef if trigger was already searched but not detected
        return if $usedMeasureDevices->{'NetSignalTimeZero_s'} == -1;

        # return the detected time
        return $usedMeasureDevices->{'NetSignalTimeZero_s'};
    }

    my $eventTrigger_href = CA_trace_get_dataref( FLC_getFilename('can_access'), ['EventTrigger'] );
    my @times = sort { $a <=> $b } keys %$eventTrigger_href;

    if ( scalar @times > 1 ) {
        S_set_error("More then one trigger detected during Crash Injection (check the event trigger connection of TSG4)!\n");
        $usedMeasureDevices->{'NetSignalTimeZero_s'} = -1;
        return;
    }

    if ( scalar @times == 0 ) {
        S_set_error("No trigger detected during Crash Injection (check TSG4 setup, actual firmware for RackController used? TSG4 Com channel mapped in CANoe?)!\n");
        $usedMeasureDevices->{'NetSignalTimeZero_s'} = -1;
        return;
    }

    $usedMeasureDevices->{'NetSignalTimeZero_s'} = $times[0];

    S_w2log( 3, "NetSignalTimeZero_s: $usedMeasureDevices->{'NetSignalTimeZero_s'} seconds \n" );

    return $usedMeasureDevices->{'NetSignalTimeZero_s'};

}

sub FLC_EnableNvmReadAfterCrash {
    $usedMeasureDevices->{'nvmDumpNeeded4EDR'} = 1;

    return;
}

sub FLC_CheckNbrOfStoredPepEDR {
    my $edrCnt = shift // 0;
    my $recCnt = shift // 0;

    my $name    = "Nbr. of stored PEP EDR";
    my $verdict = "PASS";
    my $comment;

    if ( defined $recCnt and $recCnt != $edrCnt ) {
        $verdict = "FAIL";
        $comment .= "There are '$edrCnt' edr read from ECU, but '$recCnt' are defined in RecordCompleteStatus \n";
    }

    FLC_LOG_EDRValues( $name, $edrCnt, $verdict, $comment );

    return;
}

sub FLC_CheckNbrOfStoredEDR {
    my $edrCnt     = shift // 0;
    my $mandRecCnt = shift // 0;
    my $recCnt     = shift // 0;

    my $name    = "Nbr. of stored EDR";
    my $verdict = "PASS";
    my $comment;

    if ( defined $mandRecCnt and $mandRecCnt != $edrCnt ) {
        $verdict = "FAIL";
        $comment .= "There are '$edrCnt' edr read from ECU, but '$mandRecCnt' are defined in MandatoryDataRecCompltStatus \n";
    }

    if ( defined $recCnt and $recCnt != $edrCnt ) {
        $verdict = "FAIL";
        $comment .= "There are '$edrCnt' edr read from ECU, but '$recCnt' are defined in RecordCompleteStatus \n";
    }

    FLC_LOG_EDRValues( $name, $edrCnt, $verdict, $comment );

    return;
}

sub FLC_ReadPepCrashRecorder {
    my $pepEdrReader_href = shift;
    my $edrNbr            = shift;
    my $thisEdrFailed     = shift;
    my $thisEdrStored     = shift;

    # do not read EDR ...
    return   if not exists $pepEdrReader_href->{EdrId}{$edrNbr}{filename};    # if reading is disabled by exec option
    return 1 if $thisEdrFailed;                                               # if recordcompletestatus is failed (reading fails anyhow in this case)
    return 0 unless $thisEdrStored;                                           # if no edr stored (as it wastes 10s of execution time)

    my ($response_aref);
    S_teststep_2nd_level( "Read Crash Recorder $edrNbr", 'AUTO_NBR' );

    my $options_href->{date_time_in_file_name} = 0;
    $options_href->{dump_filename} = $pepEdrReader_href->{EdrId}{$edrNbr}{filename};

    my $response_href = PRD_Read_EDR_NOERROR( $edrNbr + 0x10, $options_href );

    unless ($response_href) {
        S_wait_ms(5000);
        $response_href = PRD_Read_EDR( $edrNbr + 0x10, $options_href );
        S_wait_ms(10000) unless $response_href;
    }

    S_wait_ms(2000);

    return 1 if $response_href->{Id} == 71;

    return 0;
}

sub FLC_ReadCrashRecorder {
    my $edrReader_href = shift;
    my $edrNbr         = shift;
    my $thisEdrFailed  = shift;
    my $thisEdrStored  = shift;

    # do not read EDR ...
    return   if not exists $edrReader_href->{EdrId}{$edrNbr}{filename};    # if reading is disabled by exec option
    return 1 if $thisEdrFailed;                                            # if recordcompletestatus is failed (reading fails anyhow in this case)
    return 0 unless $thisEdrStored;                                        # if no edr stored (as it wastes 10s of execution time)

    my ($response_aref);
    S_teststep_2nd_level( "Read Crash Recorder $edrNbr", 'AUTO_NBR' );

    my $options_href->{date_time_in_file_name} = 0;
    $options_href->{dump_filename} = $edrReader_href->{EdrId}{$edrNbr}{filename};

    my $response_href = PRD_Read_EDR_NOERROR( $edrNbr, $options_href );

    unless ($response_href) {
        S_wait_ms(5000);
        $response_href = PRD_Read_EDR( $edrNbr, $options_href );
        S_wait_ms(10000) unless $response_href;
    }

    S_wait_ms(2000);

    return 1 if $response_href->{Id} == 71;

    return 0;
}

sub FLC_ReadAndCheckPepRecordCompleteStatus {
    my $pepEdrReader_href = shift;
    my $edrNbr            = shift;

    return if ( not exists $pepEdrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus} or not defined $pepEdrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} );

    my $name         = "RecordCompleteStatusPEP$edrNbr";
    my $verdict      = "NA";
    my $failedStatus = 0;
    my $storedStatus = 0;

    my ( $response_aref, $comment );

    S_teststep_2nd_level( 'Read RecordCompleteStatus', 'AUTO_NBR' );
    $response_aref = PRD_Read_Memory_NOERROR( $pepEdrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} );
    my $value = S_dec2hex_NOERROR( $$response_aref[0] );
    S_w2log( 3, "$pepEdrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable}: $value" );

    if ( not defined $value ) {
        $value        = "-";
        $failedStatus = 1;
        $verdict      = "FAIL";
    }
    elsif ( $value eq "0x5A" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0x55" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0xA5" ) {
        $storedStatus = 1;
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Record is not completely stored.";
    }
    elsif ( $value eq "0x0" ) {
        $verdict = "PASS";
    }
    else {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Unexpected value detected.";
    }

    FLC_LOG_EDRValues( $name, $value, $verdict, $comment );

    return ( $failedStatus, $storedStatus );

}

sub FLC_ReadAndCheckRecordCompleteStatus {
    my $edrReader_href = shift;
    my $edrNbr         = shift;

    return if ( not exists $edrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus} or not defined $edrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} );

    my $name         = "RecordCompleteStatus$edrNbr";
    my $verdict      = "NA";
    my $failedStatus = 0;
    my $storedStatus = 0;

    my ( $response_aref, $comment );

    S_teststep_2nd_level( 'Read RecordCompleteStatus', 'AUTO_NBR' );
    $response_aref = PRD_Read_Memory_NOERROR( $edrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} );
    my $value = S_dec2hex_NOERROR( $$response_aref[0] );
    S_w2log( 3, "$edrReader_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable}: $value" );

    if ( not defined $value ) {
        $value        = "-";
        $failedStatus = 1;
        $verdict      = "FAIL";
    }
    elsif ( $value eq "0x5A" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0x55" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0xA5" ) {
        $storedStatus = 1;
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Record (all crash data) is not completely stored.";
    }
    elsif ( $value eq "0x0" ) {
        $verdict = "PASS";
    }
    else {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Unexpected value detected.";
    }

    FLC_LOG_EDRValues( $name, $value, $verdict, $comment );

    return ( $failedStatus, $storedStatus );

}

sub FLC_ReadAndCheckMandatoryDataRecCompltStatus {
    my $edrReader_href = shift;
    my $edrNbr         = shift;

    return if ( not exists $edrReader_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus} or not defined $edrReader_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable} );

    my $name         = "MandatoryDataRecCompltStatus$edrNbr";
    my $verdict      = "NA";
    my $failedStatus = 0;
    my $storedStatus = 0;

    my ( $response_aref, $comment );

    S_teststep_2nd_level( 'Read MandatoryDataRecCompltStatus', 'AUTO_NBR' );
    $response_aref = PRD_Read_Memory_NOERROR( $edrReader_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable} );
    my $value = S_dec2hex_NOERROR( $$response_aref[0] );
    S_w2log( 3, "$edrReader_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable}: $value" );

    if ( not defined $value ) {
        $value        = "-";
        $failedStatus = 1;
        $verdict      = "FAIL";
    }
    elsif ( $value eq "0x5A" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0x55" ) {
        $storedStatus = 1;
        $verdict      = "PASS";
    }
    elsif ( $value eq "0xA5" ) {
        $storedStatus = 1;
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Mandatory section of data is not completely stored.";
    }
    elsif ( $value eq "0x0" ) {
        $verdict = "PASS";
    }
    else {
        $failedStatus = 1;
        $verdict      = "FAIL";
        $comment      = "Unexpected value detected.";
    }

    FLC_LOG_EDRValues( $name, $value, $verdict, $comment );

    return ( $failedStatus, $storedStatus );

}

sub FLC_waitForEdrStatus {
    my ( $ecuProperties_href, $ecuStatus );
    S_set_timer_zero('EDR');

    for my $attempts ( 0 .. 10 ) {

        S_wait_until_timer_ms( $attempts * 1000, 'EDR' ) if $attempts;

        $ecuProperties_href = PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_status'] } );

        last unless ( $ecuProperties_href->{ECU_status}{EDR_status} & 1 or $ecuProperties_href->{ECU_status}{EDR_status} & 2 );
    }

    for my $attempts ( 3 .. 12 ) {

        last unless ( $ecuProperties_href->{ECU_status}{EDR_status} & 1 or $ecuProperties_href->{ECU_status}{EDR_status} & 2 );

        S_wait_until_timer_ms( $attempts * 5000, 'EDR' ) if $attempts;

        $ecuProperties_href = PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_status'] } );

    }

    S_teststep_2nd_level( 'Read ECU Status Byte 2', 'AUTO_NBR' );
    my $ecuStatus_text = S_dec2hex_NOERROR( $ecuProperties_href->{ECU_status}{EDR_status} );
    S_w2log( 3, "ECUStatus (Byte 2): $ecuStatus" );

    return $ecuProperties_href->{ECU_status}{EDR_status};
}

=head2 EvaluateFaults

    EvaluateFaults($faultMemory_obj,$expected_faults_href);

=cut

sub EvaluateFaults {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'EvaluateFaults($faultMemory_obj,$expected_faults_href)', @args );

    my $faultMemory_obj      = shift @args;
    my $expected_faults_href = shift @args;
    $faultMemory_obj->evaluate_faults($expected_faults_href);

    return 1;
}

=head2 FaultIsGenericAfterCrash

    FaultIsGenericAfterCrash( $faultName, $faultMemory_obj, $genericFaultsAfterCrash_href );

=cut

sub FaultIsGenericAfterCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FaultIsGenericAfterCrash( $faultName, $faultMemory_obj, $genericFaultsAfterCrash_href )', @args );

    my $faultName                    = shift @args;
    my $faultMemory_obj              = shift @args;
    my $genericFaultsAfterCrash_href = shift @args;

    foreach my $fault ( keys %$genericFaultsAfterCrash_href ) {
        if ( $faultName =~ m/$genericFaultsAfterCrash_href->{$fault}{FaultName}/ ) {
            my $comment = $genericFaultsAfterCrash_href->{$fault}{Comment};
            if ( defined $genericFaultsAfterCrash_href->{$fault}{EventDebugData} ) {
                my $debugData = $faultMemory_obj->get_fault_attribute( { 'FaultName' => $faultName, 'Attribute' => 'EventDebugData' } );
                my $debugDataBin = sprintf( '%#016b', $debugData );

                # my $debugDataBin2 = sprintf ('%016b',  $debugData);
                if ( EVAL_evaluate_value_NOVERDICT_NOHTML( $faultName, $debugData, 'MASK', $genericFaultsAfterCrash_href->{$fault}{EventDebugData} ) eq "VERDICT_PASS" ) {
                    S_w2log( 3, "Adding '$faultName' to expected GenericFaultsAfterCrash - as it matches '$genericFaultsAfterCrash_href->{$fault}{FaultName}' and detected DebugData '$debugDataBin' matches '$genericFaultsAfterCrash_href->{$fault}{EventDebugData}'." );
                    return { FaultName => $faultName, EventDebugData => $debugData, Comment => $comment };
                }
            }
            else {
                S_w2log( 3, "Adding '$faultName' to expected GenericFaultsAfterCrash - as it matches '$genericFaultsAfterCrash_href->{$fault}{FaultName}'." );
                return { FaultName => $faultName, Comment => $comment };
            }
        }
    }

    return 0;
}

=head2 GetCrashDependentFaults

    $crashDependentFaults_href       = GetCrashDependentFaults($crashData_href);

Returns a list of faults the can be present after crash was injected but only for a particular crash.
Faults can be provided in CREIS_Mapping, section 'CRASH_MEASUREMENT_AND_EVALUATION' => 'Faults' => 'AdditionalAfterCrash' => 'CrashDependent'

=cut

sub GetCrashDependentFaults {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetCrashDependentFaults( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my $crashDependentFaults_href;
    my $crashName = $crashData_href->{METADATA}{CRASHNAME};

    unless ( defined $settingsFaults_href->{AdditionalAfterCrash}{CrashDependent} ) {
        S_set_warning("GetCrashDependentFaults: section for CrashDependent faults not filled.");
        return {};
    }

    unless ( exists $settingsFaults_href->{AdditionalAfterCrash}{CrashDependent}{$crashName} ) {
        S_set_warning("GetCrashDependentFaults: no CrashDependent faults defined for crash '$crashName'.");
        return {};
    }

    unless ( ref $settingsFaults_href->{AdditionalAfterCrash}{CrashDependent}{$crashName} eq "ARRAY" ) {
        S_set_warning("GetCrashDependentFaults: provided content for crash '$crashName' is not an array reference.");
        return {};
    }

    foreach my $faultName ( @{ $settingsFaults_href->{AdditionalAfterCrash}{CrashDependent}{$crashName} } ) {
        $crashDependentFaults_href->{$faultName}{FaultName} = $faultName;
    }

    return $crashDependentFaults_href;
}

=head2 GetEnvironmentDependentFaults

    $environmentDependentFaults_href = GetEnvironmentDependentFaults( $crashData_href );

Returns a href of faults the are expected to be present in the fault memory as per Environment settings of the crash.

=cut

sub GetEnvironmentDependentFaults {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetEnvironmentDependentFaults( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my $environmentDependentFaults_href;

    return [] unless defined $settingsFaults_href->{BeforeCrash}{EnvironmentDependent};

    unless ( defined $settingsFaults_href->{BeforeCrash}{EnvironmentDependent} ) {
        S_set_warning("GetEnvironmentDependentFaults: section for EnvironmentDependent faults not filled.");
        return [];
    }

    unless ( ref $settingsFaults_href->{BeforeCrash}{EnvironmentDependent} eq "HASH" ) {
        S_set_warning("GetEnvironmentDependentFaults: provided content for EnvironmentDependent faults is not a hash reference.");
        return [];
    }

    foreach my $faultName ( keys %{ $settingsFaults_href->{BeforeCrash}{EnvironmentDependent} } ) {
        my $calculationExpressionText = $settingsFaults_href->{BeforeCrash}{EnvironmentDependent}{$faultName};
        my @expressionVariables       = sort( $calculationExpressionText =~ /(\#\w*\|?\d?)/g );
        my $calculationExpression     = $calculationExpressionText;

        # loop over all #n in $calculationExpression
        foreach my $expressionVariable (@expressionVariables) {
            if ( $expressionVariable =~ /\#(\w*)\|?(\d?)/ ) {

                # get variable number: 0 for #0, 1 for #1, etc.
                my $exprVar          = $1;
                my $alternativeValue = $2;

                my $value = FuncLib_TNT_crash_simulation::GetStateOfEnvVariable( $crashData_href, $exprVar );

                if ( $alternativeValue eq '' ) {
                    unless ( defined $value ) {
                        next;
                    }
                    $calculationExpression =~ s/\#$exprVar/$value/;
                }
                else {
                    $value = $value // $alternativeValue;
                    $calculationExpression =~ s/\#$exprVar\|$alternativeValue/$value/;
                }
            }
        }
        my $result = eval($calculationExpression);
        if ($result) {
            S_w2log( 3, "Adding '$faultName' to expected EnvironmentDependentFaults - \$calculationExpression: $calculationExpressionText - filled \$calculationExpression: $calculationExpression - \$result: $result." );
            $environmentDependentFaults_href->{$faultName}{FaultName} = $faultName;
            $environmentDependentFaults_href->{$faultName}{Comment}   = "Fault expected due to environment settings: " . $calculationExpressionText;
        }
        else {
            S_w2log( 3, "'$faultName' will not be added to expected EnvironmentDependentFaults - \$calculationExpression: $calculationExpressionText - filled \$calculationExpression: $calculationExpression." );
        }
    }

    return $environmentDependentFaults_href;
}

=head2 FLC_getFilename

    $filename = FLC_getFilename( $measureDevice );

Returns the SimDevice settings for a particular sim device.

=cut

sub FLC_getFilename {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_getFilename( $measureDevice )', @args );

    my $measureDevice = shift @args;

    return 0 unless exists $usedMeasureDevices->{$measureDevice};

    return $usedMeasureDevices->{$measureDevice};

}

=head2 GetGenericFaultsAdditionalAfterCrash

    $genericFaultsAfterCrash_aref  = GetGenericFaultsAdditionalAfterCrash( $crashData_href );

Returns a list of faults the can be present in the fault memory (optional) after crash was injected.
Faults can be provided in CREIS_Mapping, section 'CRASH_MEASUREMENT_AND_EVALUATION' => 'Faults' => 'AdditionalAfterCrash' => 'Generic'
                                     
=cut

sub GetGenericFaultsAdditionalAfterCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetGenericFaultsAdditionalAfterCrash( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my $genericFaults_href;

    unless ( defined $settingsFaults_href->{AdditionalAfterCrash}{Generic} ) {
        S_set_warning("GetGenericFaultsAdditionalAfterCrash: No Generic faults defined for 'AdditionalAfterCrash'.");
        return [];
    }

    unless ( ref $settingsFaults_href->{AdditionalAfterCrash}{Generic} eq "HASH" ) {
        S_set_warning("GetGenericFaultsAdditionalAfterCrash: provided content is not an array reference.");
        return [];
    }

    $genericFaults_href = $settingsFaults_href->{AdditionalAfterCrash}{Generic};

    return $genericFaults_href;
}

=head2 GetGenericFaultsBeforeCrash

    $genericFaultsBeforeCrash_aref = GetGenericFaultsBeforeCrash( $crashData_href );

Returns a list of faults the can be present in the fault memory (optional) already before crash is injected.
Faults can be provided in CREIS_Mapping, section 'CRASH_MEASUREMENT_AND_EVALUATION' => 'Faults' => 'BeforeCrash' => 'Generic'
                                     
=cut

sub GetGenericFaultsBeforeCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetGenericFaultsBeforeCrash( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my $genericFaults_href;

    unless ( defined $settingsFaults_href->{BeforeCrash}{Generic} ) {
        S_set_warning("GetGenericFaultsBeforeCrash: No Generic faults defined for 'BeforeCrash'.");
        foreach my $faultName ( @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } ) {
            $genericFaults_href->{$faultName}{FaultName} = $faultName;
        }
        return $genericFaults_href;
    }

    unless ( ref $settingsFaults_href->{BeforeCrash}{Generic} eq "ARRAY" ) {
        S_set_warning("GetGenericFaultsBeforeCrash: provided content is not an array reference.");
        foreach my $faultName ( @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } ) {
            $genericFaults_href->{$faultName}{FaultName} = $faultName;
        }
        return $genericFaults_href;
    }

    foreach my $faultName ( @{ $settingsFaults_href->{BeforeCrash}{Generic} } ) {
        $genericFaults_href->{$faultName}{FaultName} = $faultName;
    }

    #STEP get expected optional faults from project defaults
    if ( exists $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} ) {
        S_w2log( 5, " Add project defined optional faults '" . @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } . "'\n" );
        foreach my $faultName ( @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } ) {
            $genericFaults_href->{$faultName}{FaultName} = $faultName;
        }
    }

    return $genericFaults_href;
}

=head2 FLC_getInvalidEnvironmentCombinations

    $settingsInvalidEnvironmentCombinations_href = FLC_getInvalidEnvironmentCombinations( );

Returns the CREIS mapping for InvalidEnvironmentCombinations.

=cut

sub FLC_getInvalidEnvironmentCombinations {

    return $settingsInvalidEnvironmentCombinations_href;

}

=head2 FLC_getRecordingTime

    $recordingTime_ms = FLC_getRecordingTime( );

Returns the stored $recordingTime_ms (which was prepared during 'FLC_configureTransientRecorder').

=cut

sub FLC_getRecordingTime {

    return $generalSettings_href->{'RecordingTime_ms'};

}

=head2 GetSimDeviceDependentFaults

    $crashDependentFaults_href       = GetSimDeviceDependentFaults($crashData_href);

=cut

sub GetSimDeviceDependentFaults {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetSimDeviceDependentFaults( $crashData_href )', @args );

    my $crashData_href = shift @args;
    my $simDeviceDependentFaults_href;

    foreach my $faultName ( @{ $usedMeasureDevices->{'fault_memory'}{"SimDeviceDependentFaults"} } ) {
        $simDeviceDependentFaults_href->{$faultName}{FaultName} = $faultName;
    }

    return $simDeviceDependentFaults_href;
}

=head2 FLC_getSimDeviceSettings

    $simDevSettings_href = FLC_getSimDeviceSettings( $deviceName );

Returns the SimDevice settings for a particular sim device.

=cut

sub FLC_getSimDeviceSettings {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_getSimDeviceSettings( $deviceName )', @args );

    my $deviceName = shift @args;

    return 0 unless ( $settingsSimDevices_href->{$deviceName} );

    return clone( $settingsSimDevices_href->{$deviceName} );

}

=head2 FLC_configureTransientRecorder

    FLC_configureTransientRecorder( $crashData_href );

=cut

sub FLC_configureTransientRecorder {
    my @args = @_;

    my $crashData_href = shift @args;

    # transi should record crash duration + disposal time
    my $crashDuration_ms = $crashData_href->{'METADATA'}{'CRASHDURATION_MS'};
    my $disposalTime_ms  = $generalSettings_href->{'DisposalTime_ms'};
    my $triggerDelay     = $generalSettings_href->{'TriggerDelay'};

    if ( $disposalTime_ms =~ /([0-9]+)/ ) {
        $disposalTime_ms = $1;
    }
    else {
        S_set_error( "Given 'DisposalTime_ms' from 'CRASH_MEASUREMENT_AND_EVALUATION -> General_Settings' is not a number. ", 120 );
    }

    my $minRecordingTime_ms = $crashDuration_ms + $disposalTime_ms;

    # store the calculated RecordingTime_ms for use in other functions
    # will be overwriten if "measure_trace_analog" is used by any of the simDevs
    $generalSettings_href->{'RecordingTime_ms'} = $minRecordingTime_ms;

    return 0 unless exists $usedMeasureDevices->{'trace_analog'};

    my $samplingFrequency_Hz = $generalSettings_href->{'SamplingFrequency_Hz'};
    if ( $samplingFrequency_Hz =~ /([0-9]+)/ ) {
        $samplingFrequency_Hz = $1;
    }

    my $memorySize_B = GetTRCMemorySize( $minRecordingTime_ms, $samplingFrequency_Hz );
    my $recordingTime_ms = GetTRCRecordingTime( $memorySize_B, $samplingFrequency_Hz );

    # store the calculated RecordingTime_ms for use in other functions
    $generalSettings_href->{'RecordingTime_ms'} = $recordingTime_ms;
    LC_MeasureTraceAnalogStop();
    LC_ConfigureTRCchannels( { 'SamplingFrequency' => $samplingFrequency_Hz, 'MemorySize' => $memorySize_B, 'TriggerDelay' => 0 } );

    return 1;

}

sub GetTRCMemorySize {
    my @args = @_;

    my $minRecordingTime_ms  = shift @args;
    my $samplingFrequency_Hz = shift @args;
    my $recordingTime_ms;
    my $memorySize_B;
    my @possibleMemorySizes_kB = ( 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192 );

    foreach my $memorySize_kB (@possibleMemorySizes_kB) {
        $memorySize_B = $memorySize_kB * 1024;
        $recordingTime_ms = GetTRCRecordingTime( $memorySize_B, $samplingFrequency_Hz );
        last if $minRecordingTime_ms < $recordingTime_ms;
    }

    return $memorySize_B;
}

sub GetTRCRecordingTime {
    my @args = @_;

    my $memorySize_B         = shift @args;
    my $samplingFrequency_Hz = shift @args;
    my $recordingTime_s;
    my $recordingTime_ms;

    $recordingTime_s = $memorySize_B * ( 1 / $samplingFrequency_Hz );
    $recordingTime_ms = $recordingTime_s * 1000;

    return $recordingTime_ms;
}

=head2 FLC_evaluateFiringState

    $firing_state_href = FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms, [$minTime_ms, $maxTime_ms, $isDeployed] );

=cut

sub FLC_evaluateFiringState {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateFiringState( $crashData_href, $deviceName, $actualFiringTime_ms, [$minTime_ms, $maxTime_ms, $isDeployed] )', @args );

    my $crashData_href      = shift @args;
    my $deviceName          = shift @args;
    my $actualFiringTime_ms = shift @args;
    my $minTime_ms          = shift @args;
    my $maxTime_ms          = shift @args;
    my $isDeployed          = shift @args;

    $minTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'}       unless defined $minTime_ms;
    $maxTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MAXT'}       unless defined $maxTime_ms;
    $isDeployed = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'} unless defined $isDeployed;

    $actualFiringTime_ms = sprintf( "%.3f", $actualFiringTime_ms ) unless $actualFiringTime_ms eq "-";

    my $firing_status     = 'VALID';
    my $text              = '-';
    my $firing_state_href = clone($emptyFireState_href);

    S_w2rep("$deviceName - Deployment optional (partial deployment). If it deploys, deployment time will be checked against min and max.\n") if $isDeployed == $CANFIRE_SIMDEVICE;
    S_w2rep("$deviceName - Deployment expected.\n")                                                                                          if $isDeployed == $FIRE_SIMDEVICE;
    S_w2rep("$deviceName - minTime_ms: $minTime_ms ms, maxTime_ms: $maxTime_ms ms, detected time: $actualFiringTime_ms ms\n")                if ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );
    S_w2rep("$deviceName - No deployment expected. Detected time: $actualFiringTime_ms ms\n") unless ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );

    if ( ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE ) && $actualFiringTime_ms ne "-" ) {

        # validate with min and max time (include firing delay)
        if ( $actualFiringTime_ms < $minTime_ms ) {
            S_w2rep( "Early deployment in '$deviceName'.", 'red' );
            my $deviation = $actualFiringTime_ms - $minTime_ms;
            $deviation = sprintf( "%.5f", $deviation );
            $text = "x# | " . $deviation . ' ms';
            S_set_verdict(VERDICT_FAIL);
            $firing_status = "Early Deployment";
        }
        elsif ( $actualFiringTime_ms > $maxTime_ms ) {
            S_w2rep( "Late deployment '$deviceName'.", 'red' );
            my $deviation = $actualFiringTime_ms - $maxTime_ms;
            $deviation = sprintf( "%.5f", $deviation );
            $text = "x# | " . $deviation . ' ms';
            S_set_verdict(VERDICT_FAIL);
            $firing_status = "Late Deployment";
        }
        else {
            $text = "x";
        }
    }

    # check for unexpected deployment
    elsif ( $isDeployed == $NOFIRE_SIMDEVICE && $actualFiringTime_ms ne "-" ) {
        S_w2rep( "Unexpected deployment in $deviceName", 'red' );
        $text = "x# | " . $actualFiringTime_ms . ' ms';
        S_set_verdict(VERDICT_FAIL);
        $firing_status = "Wrong Deployment";
    }

    # check for no deployment
    elsif ( $isDeployed == $FIRE_SIMDEVICE && $actualFiringTime_ms eq "-" ) {
        S_w2rep( "No deployment in $deviceName", 'red' );
        $text          = "-#";
        $firing_status = "No Deployment";
        S_set_verdict(VERDICT_FAIL);
    }

    S_set_verdict(VERDICT_PASS) if ( $firing_status eq 'VALID' );

    $firing_state_href->{"MinT_ms"}             = $minTime_ms;
    $firing_state_href->{"MaxT_ms"}             = $maxTime_ms;
    $firing_state_href->{"ActualFiringTime_ms"} = $actualFiringTime_ms;
    $firing_state_href->{"Text"}                = $text;
    $firing_state_href->{"Firing_Status"}       = $firing_status;
    $firing_state_href->{"IsDeployed"}          = $isDeployed;
    return $firing_state_href;
}

=head2 FLC_evaluateFiringStateError

    $firing_state_href = FLC_evaluateFiringStateError( $crashData_href, $deviceName, $errorText );

=cut

sub FLC_evaluateFiringStateError {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateFiringStateError( $crashData_href, $deviceName, $errorText, [$minTime_ms, $maxTime_ms, $isDeployed] )', @args );

    my $crashData_href = shift @args;
    my $deviceName     = shift @args;
    my $errorText      = shift @args;
    my $minTime_ms     = shift @args;
    my $maxTime_ms     = shift @args;
    my $isDeployed     = shift @args;

    $minTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'}       unless defined $minTime_ms;
    $maxTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MAXT'}       unless defined $maxTime_ms;
    $isDeployed = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'} unless defined $isDeployed;

    my $firing_state_href = clone($emptyFireState_href);

    S_w2rep("$deviceName - Deployment optional (partial deployment). If it deploys, deployment time will be checked against min and max.\n") if $isDeployed == $CANFIRE_SIMDEVICE;
    S_w2rep("$deviceName - Deployment expected.\n")                                                                                          if $isDeployed == $FIRE_SIMDEVICE;
    S_w2rep("$deviceName - minTime_ms: $minTime_ms ms, maxTime_ms: $maxTime_ms ms\n")                                                        if ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );
    S_w2rep("$deviceName - No deployment expected.\n") unless ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );

    $firing_state_href->{"MinT_ms"}             = $minTime_ms;
    $firing_state_href->{"MaxT_ms"}             = $maxTime_ms;
    $firing_state_href->{"ActualFiringTime_ms"} = '-';
    $firing_state_href->{"Text"}                = $errorText;
    $firing_state_href->{"Firing_Status"}       = 'INCONC';
    $firing_state_href->{"IsDeployed"}          = $isDeployed;
    return $firing_state_href;
}

=head2 FLC_evaluateFiringStateNoEvaluation

    $firing_state_href = FLC_evaluateFiringStateNoEvaluation( $crashData_href, $deviceName, $errorText );

=cut

sub FLC_evaluateFiringStateNoEvaluation {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_evaluateFiringStateNoEvaluation( $crashData_href, $deviceName, $actualFiringTime_ms, $text, [$minTime_ms, $maxTime_ms, $isDeployed] )', @args );

    my $crashData_href      = shift @args;
    my $deviceName          = shift @args;
    my $actualFiringTime_ms = shift @args;
    my $text                = shift @args;
    my $minTime_ms          = shift @args;
    my $maxTime_ms          = shift @args;
    my $isDeployed          = shift @args;

    $minTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MINT'}       unless defined $minTime_ms;
    $maxTime_ms = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'MAXT'}       unless defined $maxTime_ms;
    $isDeployed = $crashData_href->{'EXPECTEDRESULT'}->{$deviceName}{'ISDEPLOYED'} unless defined $isDeployed;

    my $firing_state_href = clone($emptyFireState_href);

    S_w2rep("$deviceName - Deployment optional (partial deployment). If it deploys, deployment time will be checked against min and max.\n") if $isDeployed == $CANFIRE_SIMDEVICE;
    S_w2rep("$deviceName - Deployment expected.\n")                                                                                          if $isDeployed == $FIRE_SIMDEVICE;
    S_w2rep("$deviceName - minTime_ms: $minTime_ms ms, maxTime_ms: $maxTime_ms ms\n")                                                        if ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );
    S_w2rep("$deviceName - No deployment expected.\n") unless ( $isDeployed == $FIRE_SIMDEVICE || $isDeployed == $CANFIRE_SIMDEVICE );

    $firing_state_href->{"MinT_ms"}             = $minTime_ms;
    $firing_state_href->{"MaxT_ms"}             = $maxTime_ms;
    $firing_state_href->{"ActualFiringTime_ms"} = $actualFiringTime_ms;
    $firing_state_href->{"Text"}                = $text;
    $firing_state_href->{"Firing_Status"}       = 'VALID';
    $firing_state_href->{"IsDeployed"}          = $isDeployed;
    return $firing_state_href;
}

sub FLC_prepareMeasurementFiles {
    my @args = @_;

    my $crashData_href = shift @args;

    my $crashName      = $crashData_href->{'METADATA'}{'CRASHNAME'};
    my $stateVariation = $crashData_href->{'METADATA'}{'STATEVARIATION'};

    my $crashNameClean = FLC_LOG_CleanStrings($crashName);

    my $foldername_common = $main::REPORT_PATH . '\\';

    my ( $mainTCNumber, $iterationNumber ) = split( '_', S_get_TC_number() );

    $iterationNumber = "0000" unless defined $iterationNumber;

    $foldername_common .= sprintf( "%04d", $mainTCNumber ) . "_" . sprintf( "%04d", $iterationNumber ) . "_" . $crashNameClean . "_" . $stateVariation;

    $usedMeasureDevices->{'zip_file'} = $foldername_common . ".zip";

    $foldername_common .= '\\';

    unless ( -d $foldername_common ) {
        S_w2log( 4, " CREIS_PrepareMeasurements: create path '$foldername_common'\n" );
        mkdir($foldername_common);
    }

    $usedMeasureDevices->{'folder'} = $foldername_common;

    # prepare file - names for all measurement - types
    my $filename_common = $foldername_common . sprintf( "%04d", $mainTCNumber ) . "_" . sprintf( "%04d", $iterationNumber ) . "_" . $crashNameClean . "_" . $stateVariation;
    $usedMeasureDevices->{'can_access'}    = $filename_common . "_NET_Trace.asc"         if exists $usedMeasureDevices->{'can_access'};
    $usedMeasureDevices->{'trace_digital'} = $filename_common . "_trace_digital.txt.unv" if exists $usedMeasureDevices->{'trace_digital'};
    $usedMeasureDevices->{'trace_analog'}  = $filename_common . "_trace_analog.txt.unv"  if exists $usedMeasureDevices->{'trace_analog'};
    $usedMeasureDevices->{'fd_trace'}      = $filename_common . "_FD_files"              if exists $usedMeasureDevices->{'fd_trace'};
    $usedMeasureDevices->{'nvmDumpBeforeCrash'} = $filename_common . "_NVM_DumpBeforeCrash.txt";
    $usedMeasureDevices->{'nvmDumpAfterCrash'}  = $filename_common . "_NVM_DumpAfterCrash.txt";
    $usedMeasureDevices->{'nvmDumpNeeded4EDR'}  = 0;

    my $filename_edr = $foldername_common . sprintf( "%04d", $mainTCNumber ) . "_" . sprintf( "%04d", $iterationNumber ) . '_@' . $crashName . '@_' . $stateVariation;
    if ( exists $usedMeasureDevices->{edrReader} ) {
        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $usedMeasureDevices->{edrReader}{EdrId} } ) {

            next if $edrNbr !~ /([0-9]+)/;

            my $edrNbr_text = sprintf( "%02d", $edrNbr );
            $usedMeasureDevices->{edrReader}{EdrId}{$edrNbr}{filename} = $filename_edr . "_EDR_Dump_" . $edrNbr_text . ".txt" if exists $usedMeasureDevices->{edrReader}{EdrId}{$edrNbr}{filename};
            $usedMeasureDevices->{edrReader}{EdrId}{$edrNbr}{filenameIncomplete} = $filename_edr . "_EDR_Dump_INCOMPLETE" . $edrNbr_text . ".txt";
        }

    }

    if ( exists $usedMeasureDevices->{pepEdrReader} ) {
        foreach my $edrNbr ( sort { $a <=> $b } keys %{ $usedMeasureDevices->{pepEdrReader}{EdrId} } ) {

            next if $edrNbr !~ /([0-9]+)/;

            my $edrNbr_text = sprintf( "%02d", $edrNbr );
            $usedMeasureDevices->{pepEdrReader}{EdrId}{$edrNbr}{filename} = $filename_edr . "_PEP_EDR_Dump_" . $edrNbr_text . ".txt" if exists $usedMeasureDevices->{pepEdrReader}{EdrId}{$edrNbr}{filename};
            $usedMeasureDevices->{pepEdrReader}{EdrId}{$edrNbr}{filenameIncomplete} = $filename_edr . "_PEP_EDR_Dump_INCOMPLETE" . $edrNbr_text . ".txt";
        }
    }
    foreach my $squib ( keys %{ $usedMeasureDevices->{FireCounter} } ) {
        $usedMeasureDevices->{FireCounter}{$squib}{value_high_level_ms} = undef;
        $usedMeasureDevices->{FireCounter}{$squib}{value_low_level_ms}  = undef;
    }

    foreach my $squib ( keys %{ $usedMeasureDevices->{SquibResistance} } ) {
        $usedMeasureDevices->{SquibResistance}{$squib}{value_ohm} = undef;
    }

    $usedMeasureDevices->{'fault_memory'}{"BeforeCrash"}{filename}    = $filename_common . "_BoschFaultMemoryBeforeCrash.xml";
    $usedMeasureDevices->{'fault_memory'}{"BeforeCrash"}{object}      = {};
    $usedMeasureDevices->{'fault_memory'}{"AfterCrash"}{filename}     = $filename_common . "_BoschFaultMemoryAfterCrash.xml";
    $usedMeasureDevices->{'fault_memory'}{"AfterCrash"}{object}       = {};
    $usedMeasureDevices->{'fault_memory'}{"SimDeviceDependentFaults"} = [];

    $usedMeasureDevices->{'NetSignalTimeZero_s'} = undef;
    $usedMeasureDevices->{'NetSignalsHrefs'}     = {};

    return 1;
}

sub FLC_initialPreparations {
    my @args = @_;

    my $crashData_href = shift @args;

    $settingsSimDevices_href                     = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'SimDevices' ] ) );
    $settingsAdditionalMeasurements_href         = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'AdditionalMeasurements' ] ) );
    $generalSettings_href                        = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'General_Settings' ] ) );
    $settingsFastDiagTrace_href                  = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'FastDiagTrace' ] ) );
    $settingsAdditionalPdLabels_href             = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'AdditionalPdLabels' ] ) );
    $settingsFaults_href                         = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'Faults' ] ) );
    $settingsInvalidEnvironmentCombinations_href = clone( S_get_contents_of_hash_NOERROR_NOHTML( [ 'CRASH_MEASUREMENT_AND_EVALUATION', 'InvalidEnvironmentCombinations' ] ) );

    # check that CRASH_MEASUREMENT_AND_EVALUATION -> SimDevices is defined
    unless ( defined $settingsSimDevices_href ) {
        S_set_error( "Section 'CRASH_MEASUREMENT_AND_EVALUATION -> SimDevices' is not defined in project constants.", 120 );
    }

    # check that CRASH_MEASUREMENT_AND_EVALUATION -> General_Settings is defined
    unless ( defined $generalSettings_href ) {
        S_set_error( "Section 'CRASH_MEASUREMENT_AND_EVALUATION -> General_Settings' is not defined in project constants.", 120 );
    }

    # check that SamplingFrequency is defined
    unless ( defined $generalSettings_href->{'SamplingFrequency_Hz'} ) {
        S_set_error( "'SamplingFrequency_Hz' is not defined in section 'CRASH_MEASUREMENT_AND_EVALUATION -> General_Settings' project constants.", 120 );
    }

    # check Algo IDs
    my $algoIds_href;
    my $ignoreAlgoIDCheck = S_check_exec_option('CREIS_IgnoreAlgoIDCheck') ? S_get_exec_option('CREIS_IgnoreAlgoIDCheck') : 0;
    $algoIds_href = $ignoreAlgoIDCheck ? CheckAlgoIDs_NOERROR($crashData_href) : CheckAlgoIDs($crashData_href);

    # setup all SimDevices (all settings that will not change for the whole testlist)
    my $ignoreUnmatchedSimDev = S_check_exec_option('CREIS_IgnoreUnmatchedSimDev') ? S_get_exec_option('CREIS_IgnoreUnmatchedSimDev') : 0;
    $ignoreUnmatchedSimDev ? PrepareSimDevices_NOERROR($crashData_href) : PrepareSimDevices($crashData_href);

    # check squib configuration and prepare fire counter reader
    my $device_data_href        = PRD_Get_Device_Configuration_NOERROR();
    my $ignoreSquibConfigErrors = S_check_exec_option('CREIS_IgnoreSquibConfigErrors') ? S_get_exec_option('CREIS_IgnoreSquibConfigErrors') : 0;
    my $validSquibs_aref        = $ignoreSquibConfigErrors ? CheckSquibConfiguration_NOERROR($device_data_href) : CheckSquibConfiguration($device_data_href);
    $ignoreSquibConfigErrors ? PrepareFireCounterReader_NOERROR($validSquibs_aref) : PrepareFireCounterReader($validSquibs_aref);

    # setup all AdditionalMeasurements (all settings that will not change for the whole testlist)
    PrepareAdditionalMeasurements_NOERROR($crashData_href);

    # setup read EDR
    my $edrCompletenessCheck = S_check_exec_option('CREIS_EdrCompletenessCheck') ? S_get_exec_option('CREIS_EdrCompletenessCheck') : 1;
    my $storeEDR             = S_check_exec_option('CREIS_StoreEDR')             ? S_get_exec_option('CREIS_StoreEDR')             : 0;
    PrepareEDRReader( $edrCompletenessCheck, $storeEDR );

    # setup CAN trace
    my $storeNetTraces = S_check_exec_option('CREIS_StoreNetTraces') ? S_get_exec_option('CREIS_StoreNetTraces') : 0;
    $usedMeasureDevices->{can_access} = 1 if $storeNetTraces;

    # setup runtime measurement and extended if needed
    my $ignoreRuntimeErrors = S_check_exec_option('CREIS_IgnoreRuntimeErrors') ? S_get_exec_option('CREIS_IgnoreRuntimeErrors') : 0;
    $ignoreRuntimeErrors ? PrepareRuntimeMeasurement_NOERROR() : PrepareRuntimeMeasurement();

    my $extendedRuntime = S_check_exec_option('CREIS_ExtendedRuntime') ? S_get_exec_option('CREIS_ExtendedRuntime') : 0;
    if ($extendedRuntime) {
        my $ignoreExtendedRuntimeErrors = S_check_exec_option('CREIS_IgnoreExtendedRuntimeErrors') ? S_get_exec_option('CREIS_IgnoreExtendedRuntimeErrors') : 0;
        $ignoreExtendedRuntimeErrors ? PrepareExtendedRuntimeMeasurement_NOERROR() : PrepareExtendedRuntimeMeasurement();
    }

    # setup Fast Diag Trace
    my $fastDiagTrace = S_check_exec_option('CREIS_FastDiagTrace') ? S_get_exec_option('CREIS_FastDiagTrace') : 0;
    PrepareFastDiagTrace($fastDiagTrace) if $fastDiagTrace;

    # setup Memory Reader
    my $pdLabelsBeforeCrash       = S_check_exec_option('CREIS_PdLabelsBeforeCrash')       ? S_get_exec_option('CREIS_PdLabelsBeforeCrash')       : 0;
    my $pdLabelsAfterCrash        = S_check_exec_option('CREIS_PdLabelsAfterCrash')        ? S_get_exec_option('CREIS_PdLabelsAfterCrash')        : 0;
    my $ignorePdLabelReaderErrors = S_check_exec_option('CREIS_IgnorePdLabelReaderErrors') ? S_get_exec_option('CREIS_IgnorePdLabelReaderErrors') : 0;
    $ignorePdLabelReaderErrors ? PreparePdLabelReader_NOERROR( $pdLabelsBeforeCrash, $pdLabelsAfterCrash ) : PreparePdLabelReader( $pdLabelsBeforeCrash, $pdLabelsAfterCrash );

    my $rbFaultEvaluation = S_check_exec_option('CREIS_EvaluateRbFaults') ? S_get_exec_option('CREIS_EvaluateRbFaults') : 0;

    my $componentIntegrityCreisFw;
    my $actionOnMismatch = 'error';
    my $ignoreComponentIntegrityCheckErrors = S_check_exec_option('CREIS_IgnoreComponentIntegrityCheckErrors') ? S_get_exec_option('CREIS_IgnoreComponentIntegrityCheckErrors') : 0;
    $componentIntegrityCreisFw = S_check_LIFT_component_integrity( { component => "CREIS_Framework", action_on_mismatch => 'log' } );

    if ( not $ignoreComponentIntegrityCheckErrors and not $componentIntegrityCreisFw ) {
        my $errorText = "The check of CREIS_Framework integrity was not successfull (for more information check warnings in IC test report).\n";
        $errorText .= "Please make sure your TurboLIFT engine is checked out from version control and not locally modified.\n";
        $errorText .= "Crash injection will be chanceled (This can be controlled by ExecOption 'CREIS_IgnoreComponentIntegrityCheckErrors', but is only allowed during Engine developement.)\n";
        S_set_error( $errorText, 120 );
    }

    PrepareCsmContainer();

    #create and fill summaryXML file
    $csmGlobalKeywordList_aref = FLC_LOG_InitSummaryXMLFile($crashData_href);
    FLC_LOG_AlgoIds($algoIds_href);
    FLC_LOG_CreateSettingsNode();
    FLC_LOG_ReleaseIntegrityStatus($componentIntegrityCreisFw);
    FLC_LOG_ChannelAssignmentOverview();
    FLC_LOG_StaticEnvironments($crashData_href);
    FLC_LOG_DynamicEnvSettings($crashData_href);
    FLC_LOG_SimDeviceSettings( $crashData_href, $settingsSimDevices_href );
    FLC_LOG_RbFaultEvaluationSettings($rbFaultEvaluation);
    FLC_LOG_PdLabelReaderSettings( FLC_getFilename('PdLabels') );
    FLC_LOG_RuntimeSettings( FLC_getFilename('Runtime') );
    FLC_LOG_ExtendedRuntimeSettings( FLC_getFilename('ExtendedRuntime') ) if $extendedRuntime;
    FLC_LOG_EDRSettings( FLC_getFilename('edrReader') );
    FLC_LOG_CloseSettingsNode();

    return $crashData_href->{'METADATA'}{'RESULTDB'};
}

=head2 FLC_logSimDev

    FLC_logSimDev ($deviceName, $firing_state_href,);
    
Logs all SimDev relevant settings to XML for later generation of XLS reporting.

$firing_state_href can be used from calling FLC_evaluateFiringState before.

If directly used, it should look as follows:  
    $firing_state_href = {
        "MinT_ms"               => ...,
        "MaxT_ms"               => ...,
        "ActualFiringTime_ms"   => ...,
        "Text"                  => ...,
        "Firing_Status"         => ...,
    };
=cut

sub FLC_logSimDev {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_logSimDev ($deviceName, $firing_state_href )', @args );

    my $deviceName        = shift @args;
    my $firing_state_href = shift @args;
    my @missingKeys;

    # check that device is defined in SimDev section of settings mapping
    unless ( exists $settingsSimDevices_href->{$deviceName} ) {
        S_set_error("'FLC_logSimDev' called for a device which is not defined as SimDev. Check your implementation of ");
    }

    # store that function was called for this device
    $settingsSimDevices_href->{$deviceName}{"FLC_logSimDev"} = 1;

    foreach my $mandatoryKey (qw( MinT_ms MaxT_ms ActualFiringTime_ms Text Firing_Status IsDeployed FireCounter_HighLevel_ms FireCounter_LowLevel_ms SquibResistance_ohm DetectedFiringDuration_ms )) {
        push( @missingKeys, $mandatoryKey ) unless exists $firing_state_href->{$mandatoryKey};
    }

    if ( @missingKeys > 0 ) {
        my $missingKeysString = join( "\n", @missingKeys );
        S_set_error( "The following mandatory keys in \$firing_state_href are not defined (make sure that you called the function correctly):\n$missingKeysString\n\n", 120 );
    }

    FLC_LOG_SimDevice( $deviceName, $firing_state_href );

    return 1;
}

sub PrepareFireCounterReader {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PrepareFireCounterReader( $validSquibs_aref )', @args );

    my $validSquibs_aref = shift @args;

    # prepare memory reader for FireCounter
    foreach my $squib (@$validSquibs_aref) {
        my $deviceIndex = PRD_Get_Device_Property($squib);

        unless ( defined $deviceIndex ) {
            S_w2log( 3, "Reading Index not successfull for squib '$squib'. Squib is not known to SW. Reading the FireCounter will not be possible." );
            next;
        }

        # Read sdlSwitch from switchConfiguration
        my @possibleSymbols = ( "rb_sqm_SQMLoopConfigSettings_st.SQMLoopConfig_au16($deviceIndex)", "rb_sqm_SQMLoopConfigSettings_cst.SQMLoopConfig_au16($deviceIndex)" );
        my $loopConfigSetting_aref;

        foreach my $symbol (@possibleSymbols) {
            if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => $symbol } ) ) {
                $loopConfigSetting_aref = PRD_Read_Memory($symbol);
                last;
            }
        }

        unless ($loopConfigSetting_aref) {
            S_w2log( 3, "Reading SQMLoopConfigSettings not successfull for squib '$squib'. Reading the FireCounter will not be possible." );
            next;
        }

        my $flicASIC    = sprintf( "%d", $$loopConfigSetting_aref[0] >> 4 );
        my $asicChannel = sprintf( "%d", $$loopConfigSetting_aref[0] & 0xF );

        # check symbol for Firecounter
        if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_sqmf_Firecounter_au16($flicASIC)($asicChannel)" } ) ) {
            S_w2log( 3, "Firecounter label for $squib: rb_sqmf_Firecounter_au16($flicASIC)($asicChannel)" );
            $usedMeasureDevices->{FireCounter}{$squib}{label} = "rb_sqmf_Firecounter_au16($flicASIC)($asicChannel)";
        }
        else {
            S_w2log( 3, "rb_sqmf_Firecounter_au16($flicASIC)($asicChannel) not defined in SAD. Reading the FireCounter for squib '$squib' will not be possible." );
        }

        # check symbol for SquibResistance
        if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_sqmm_ResistanceValue_au16($flicASIC)($asicChannel)" } ) ) {
            S_w2log( 3, "SquibResistance label for $squib: rb_sqmm_ResistanceValue_au16($flicASIC)($asicChannel)" );
            $usedMeasureDevices->{SquibResistance}{$squib}{label} = "rb_sqmm_ResistanceValue_au16($flicASIC)($asicChannel)";
        }
        else {
            S_w2log( 3, "rb_sqmm_ResistanceValue_au16($flicASIC)($asicChannel) not defined in SAD. Reading the SquibResistance for squib '$squib' will not be possible." );
            next;
        }
    }

    return;
}

sub PrepareEDRReader {
    my $performEdrCompletenessCheck = shift;
    my $storeEdr                    = shift;

    return 0 unless ( $performEdrCompletenessCheck or $storeEdr );

    # get the value from 'CRASH_MEASUREMENT_AND_EVALUATION -> General_Settings'
    my $numberOfEventsToBeStored    = $generalSettings_href->{'EDRnumberOfEvents'};
    my $numberOfEventsToBeStoredPEP = $generalSettings_href->{'EDRnumberOfEventsPEP'};
    my ( $result, $stat );

    if ( $numberOfEventsToBeStored eq 'SAD' ) {

        # use content of SAD file to get maximum number of EDR events to be stored
        $numberOfEventsToBeStored = 0;

        for ( my $edrNbr = 0 ; $edrNbr < 15 ; $edrNbr++ ) {
            my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($edrNbr)" } );
            last unless ($mapping_info);
            $numberOfEventsToBeStored = $edrNbr + 1;
        }

    }
    elsif ( $numberOfEventsToBeStored =~ /([0-9]+)/ ) {

        $numberOfEventsToBeStored = $1;

    }
    else {

        S_set_error( "Content of 'EDRnumberOfEvents' is not in the expected format ('SAD' or integer).", 20 );
        return 0;

    }

    if ( $numberOfEventsToBeStoredPEP eq 'SAD' ) {

        # use content of SAD file to get maximum number of EDR events to be stored
        $numberOfEventsToBeStoredPEP = 0;

        for ( my $edrNbr = 0 ; $edrNbr < 15 ; $edrNbr++ ) {
            my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_pcdc_HeaderPublic_st.RecordCompleteStatus_aen($edrNbr)" } );
            last unless ($mapping_info);
            $numberOfEventsToBeStoredPEP = $edrNbr + 1;
        }

    }
    elsif ( $numberOfEventsToBeStoredPEP =~ /([0-9]+)/ ) {

        $numberOfEventsToBeStoredPEP = $1;

    }
    else {

        S_set_error( "Content of 'EDRnumberOfEventsPEP' is not in the expected format ('SAD' or integer).", 20 );
        return 0;

    }

    for ( my $edrNbr = 0 ; $edrNbr < $numberOfEventsToBeStored ; $edrNbr++ ) {
        if ($storeEdr) {
            $usedMeasureDevices->{'edrReader'}{EdrId}{$edrNbr}{filename} = 1;
        }

        if ($performEdrCompletenessCheck) {
            $usedMeasureDevices->{'edrReader'}{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus} = {};
            $usedMeasureDevices->{'edrReader'}{EdrId}{$edrNbr}{RecordCompleteStatus}         = {};

            my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($edrNbr)" } );
            if ($mapping_info) {
                $usedMeasureDevices->{'edrReader'}{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable} = "rb_dcc_HeaderPublic_st.MandatoryDataRecCompltStatus_aen($edrNbr)";
            }

            $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_dcc_HeaderPublic_st.RecordCompleteStatus_aen($edrNbr)" } );
            if ($mapping_info) {
                $usedMeasureDevices->{'edrReader'}{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} = "rb_dcc_HeaderPublic_st.RecordCompleteStatus_aen($edrNbr)";
            }
        }
    }

    for ( my $edrNbr = 0 ; $edrNbr < $numberOfEventsToBeStoredPEP ; $edrNbr++ ) {
        if ($storeEdr) {
            $usedMeasureDevices->{'pepEdrReader'}{EdrId}{$edrNbr}{filename} = 1;
        }

        if ($performEdrCompletenessCheck) {
            $usedMeasureDevices->{'pepEdrReader'}{EdrId}{$edrNbr}{RecordCompleteStatus} = {};

            my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_pcdc_HeaderPublic_st.RecordCompleteStatus_aen($edrNbr)" } );
            if ($mapping_info) {
                $usedMeasureDevices->{'pepEdrReader'}{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} = "rb_pcdc_HeaderPublic_st.RecordCompleteStatus_aen($edrNbr)";
            }
        }
    }

    if ( $performEdrCompletenessCheck or $storeEdr ) {
        $usedMeasureDevices->{'edrReader'}{EdrStatus} = 1;
    }

    if ($storeEdr) {
        $usedMeasureDevices->{'edrReader'}{EdrCount} = 1;
    }

    if ( $storeEdr and $numberOfEventsToBeStoredPEP > 0 ) {
        $usedMeasureDevices->{'pepEdrReader'}{EdrCount} = 1;
    }

    return 1;

}

sub PrepareFastDiagTrace {
    my $fastDiagConfigSection = shift;

    # Get NbrOfCanIDs from CREIS Mapping and drop an Error if < 4
    my $nbrOfCanIDs = $settingsFastDiagTrace_href->{NbrOfCanIDs};

    if ( not defined $nbrOfCanIDs or $nbrOfCanIDs < 1 or $nbrOfCanIDs > 4 ) {
        S_set_warning("'NbrOfCANIDs' not defined or in wrong range (1..4) in 'CRASH_MEASUREMENT_AND_EVALUATION -> FastDiagTrace'. Default Value 4 will be used.");
        $nbrOfCanIDs = 4;
    }

    $usedMeasureDevices->{'pdNbrOfCanIDs'} = $nbrOfCanIDs;

    if ( $usedMeasureDevices->{'fd_trace'} ) {
        S_set_warning("FastDiag is already used by another Execution Option (ExtendedRuntime). FastDiagTrace will not be created.");
        return 0;
    }

    unless ( defined $settingsFastDiagTrace_href->{Configurations}{$fastDiagConfigSection} ) {
        S_set_warning("Section defined in ExecOption 'CREIS_FastDiagTrace' is not available in 'CRASH_MEASUREMENT_AND_EVALUATION -> FastDiagTrace'.");
        return 0;
    }

    foreach my $label ( keys %{ $settingsFastDiagTrace_href->{Configurations}{$fastDiagConfigSection} } ) {
        my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => $label } );
        unless ($mapping_info) {
            S_set_warning("Label '$label' is not defined in *.cns / *.sad and will be excluded from FastDiagMeasurement.");
            next;
        }

        my $dataType = $settingsFastDiagTrace_href->{Configurations}{$fastDiagConfigSection}{$label};

        $usedMeasureDevices->{'fd_trace'} = 1;
        $usedMeasureDevices->{'FastDiagTrace'}{$label} = $label;
        $usedMeasureDevices->{'FastDiagTrace'}{$label} .= ';' . $dataType if defined $dataType;
    }

    return 1;

}

sub PrepareExtendedRuntimeMeasurement {

    # Get NbrOfCanIDs from CREIS Mapping and drop an Error if < 4
    my $nbrOfCanIDs = $settingsFastDiagTrace_href->{NbrOfCanIDs};

    if ( not defined $nbrOfCanIDs or $nbrOfCanIDs < 1 or $nbrOfCanIDs > 4 ) {
        S_set_warning("'NbrOfCANIDs' not defined or in wrong range (1..4) in 'CRASH_MEASUREMENT_AND_EVALUATION -> FastDiagTrace'. Default Value 4 will be used.");
        $nbrOfCanIDs = 4;
    }

    #    if ( $nbrOfCanIDs < 4 ) {
    #        S_set_error("given 'NbrOfCANIDs' in 'CRASH_MEASUREMENT_AND_EVALUATION -> FastDiagTrace' is < 4. This will reduce the reliability of the results.");
    #    }

    $usedMeasureDevices->{'pdNbrOfCanIDs'} = $nbrOfCanIDs;

    # "rb_rt_500uscounter_u8", "rb_bg_2mscounter_u8", "rb_bg_5mscounter_u8", "rb_bg_10mscounter_u8", 'rb_fcl_StatusFirCtrl_u8', "rb_rt_CurrentRuntime_u32"
    my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_fcl_StatusFirCtrl_u8" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_fcl_StatusFirCtrl_u8' is not defined in *.cns / *.sad. Extended Runtime Measurement will not be possible.");
        return 0;
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_CurrentRuntime_u32" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_rt_CurrentRuntime_u32' is not defined in *.cns / *.sad. Calculation of average runtime will not be possible.");
    }
    else {
        $usedMeasureDevices->{'fd_trace'}                                    = 1;
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_fcl_StatusFirCtrl_u8"}  = "rb_fcl_StatusFirCtrl_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_rt_CurrentRuntime_u32"} = "rb_rt_CurrentRuntime_u32";
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_500uscounter_u8" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_rt_500uscounter_u8' is not defined in *.cns / *.sad. Calculations of task drop rates will not be possible.");
        return 0;
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_bg_2mscounter_u8" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_bg_2mscounter_u8' is not defined in *.cns / *.sad. Calculations of 2ms backround task drop rate will not be possible.");
    }
    else {
        $usedMeasureDevices->{'fd_trace'}                                   = 1;
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_fcl_StatusFirCtrl_u8"} = "rb_fcl_StatusFirCtrl_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_rt_500uscounter_u8"}   = "rb_rt_500uscounter_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_bg_2mscounter_u8"}     = "rb_bg_2mscounter_u8";
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_bg_5mscounter_u8" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_bg_5mscounter_u8' is not defined in *.cns / *.sad. Calculations of 5ms backround task drop rate will not be possible.");
    }
    else {
        $usedMeasureDevices->{'fd_trace'}                                   = 1;
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_fcl_StatusFirCtrl_u8"} = "rb_fcl_StatusFirCtrl_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_rt_500uscounter_u8"}   = "rb_rt_500uscounter_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_bg_5mscounter_u8"}     = "rb_bg_5mscounter_u8";
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_bg_10mscounter_u8" } );
    unless ($mapping_info) {
        S_set_error("Label 'rb_bg_10mscounter_u8' is not defined in *.cns / *.sad. Calculations of 10ms backround task drop rate will not be possible.");
    }
    else {
        $usedMeasureDevices->{'fd_trace'}                                   = 1;
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_fcl_StatusFirCtrl_u8"} = "rb_fcl_StatusFirCtrl_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_rt_500uscounter_u8"}   = "rb_rt_500uscounter_u8";
        $usedMeasureDevices->{'ExtendedRuntime'}{"rb_bg_10mscounter_u8"}    = "rb_bg_10mscounter_u8";
    }

    return 1;

}

sub PrepareCsmContainer {

    CSM_init( { 'StorageArea_Path' => $main::REPORT_PATH . '\\' } );

    return 1;

}

sub PreparePdLabelReader {
    my $pdLabelsBeforeCrash = shift;
    my $pdLabelsAfterCrash  = shift;

    $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"} = {};
    $usedMeasureDevices->{'PdLabels'}{"AfterCrash"}  = {};

    #

    my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_tim_EcuOnTimeDataEe_st.POnCounter_u32" } );
    if ($mapping_info) {
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Counter"}{"Mode"}       = "dec";
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Counter"}{"PdVariable"} = "rb_tim_EcuOnTimeDataEe_st.POnCounter_u32";
    }

    # c
    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_tim_EcuOnTimeDataEe_st.PoOnTime_u32" } );
    if ($mapping_info) {
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Time"}{"Mode"}       = "dec";
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Time"}{"PdVariable"} = "rb_tim_EcuOnTimeDataEe_st.PoOnTime_u32";
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Time"}{"Factor"}     = 1;
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Power On Time"}{"Unit"}       = "s";
    }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "Fee_LLSectorOrder_st(0).SecChngCnt_u32" } );
    if ($mapping_info) {
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Nvm Reorg Counter"}{"Mode"}       = "dec";
        $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{"Nvm Reorg Counter"}{"PdVariable"} = "Fee_LLSectorOrder_st(0).SecChngCnt_u32";
    }

    if ( $pdLabelsBeforeCrash and defined $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash} ) {
        foreach my $name ( keys %{ $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash} } ) {
            my $label  = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash}{$name}{PdLabel};
            my $mode   = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash}{$name}{Mode};
            my $factor = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash}{$name}{Factor};
            my $unit   = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash}{$name}{Unit};

            # ensure that label is defined in *.sad
            $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => $label } );
            unless ($mapping_info) {
                S_set_warning("Label '$label' is not defined in *.cns / *.sad and will be excluded from PdLabelReader.");
                next;
            }

            # ensure that configuration is correct
            $mode = "hex" unless ( defined $mode or $mode eq "hex" or $mode eq "bin" or $mode eq "dec" );

            unless ( defined $factor and defined $unit ) {
                undef $factor;
                undef $unit;
            }

            $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{$name}{PdVariable} = $label;
            $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{$name}{Mode}       = $mode;
            $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{$name}{Factor}     = $factor if defined $factor;
            $usedMeasureDevices->{'PdLabels'}{"BeforeCrash"}{$name}{Unit}       = $unit if defined $unit;
        }
    }
    elsif ( $pdLabelsBeforeCrash and not defined $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsBeforeCrash} ) {
        S_set_warning("Section defined in ExecOption 'CREIS_PdLabelsBeforeCrash' is not available in 'CRASH_MEASUREMENT_AND_EVALUATION -> AdditionalPdLabels'.");
    }
    else {
        S_w2log( 3, "Execution option 'CREIS_PdLabelsBeforeCrash' not defined. No additional PD Labels before crash will be read." );
    }

    if ( $pdLabelsAfterCrash and defined $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash} ) {
        foreach my $name ( keys %{ $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash} } ) {
            my $label  = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash}{$name}{PdLabel};
            my $mode   = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash}{$name}{Mode};
            my $factor = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash}{$name}{Factor};
            my $unit   = $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash}{$name}{Unit};

            # ensure that label is defined in *.sad
            my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => $label } );
            unless ($mapping_info) {
                S_set_warning("Label '$label' is not defined in *.cns / *.sad and will be excluded from PdLabelReader.");
                next;
            }

            # ensure that configuration is correct
            $mode = "hex" unless ( defined $mode or $mode eq "hex" or $mode eq "bin" or $mode eq "dec" );

            unless ( defined $factor and defined $unit ) {
                undef $factor;
                undef $unit;
            }

            $usedMeasureDevices->{'PdLabels'}{"AfterCrash"}{$name}{PdVariable} = $label;
            $usedMeasureDevices->{'PdLabels'}{"AfterCrash"}{$name}{Mode}       = $mode;
            $usedMeasureDevices->{'PdLabels'}{"AfterCrash"}{$name}{Factor}     = $factor if defined $factor;
            $usedMeasureDevices->{'PdLabels'}{"AfterCrash"}{$name}{Unit}       = $unit if defined $unit;
        }
    }
    elsif ( $pdLabelsAfterCrash and not defined $settingsAdditionalPdLabels_href->{Configurations}{$pdLabelsAfterCrash} ) {
        S_set_warning("Section defined in ExecOption 'CREIS_PdLabelsAfterCrash' is not available in 'CRASH_MEASUREMENT_AND_EVALUATION -> AdditionalPdLabels'.");
    }
    else {
        S_w2log( 3, "Execution option 'CREIS_PdLabelsAfterCrash' not defined. No additional PD Labels after crash will be read." );
    }

    return 1;

}

sub PrepareRuntimeMeasurement {

    # check Type of SW:
    my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_RunTimeSteady_st.MaximumTime_u32" } );
    if ($mapping_info) {

        # new style
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_RunTimeSteady_st.MaximumTime_u32" } );
        $usedMeasureDevices->{'Runtime'}{"MaximumTime"} = "rb_rt_RunTimeSteady_st.MaximumTime_u32" if $mapping_info;
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_RunTimeSteady_st.MinimumTime_u32" } );
        $usedMeasureDevices->{'Runtime'}{"MinimumTime"} = "rb_rt_RunTimeSteady_st.MinimumTime_u32" if $mapping_info;
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_IntPendingCntMaxSteady_u8" } );
        $usedMeasureDevices->{'Runtime'}{"PendingCounter"} = "rb_rt_IntPendingCntMaxSteady_u8" if $mapping_info;
        $usedMeasureDevices->{'Runtime'}{"delete"} = 0 if exists $usedMeasureDevices->{'Runtime'};
    }
    else {

        # old style
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_RunTime_st.MaximumTime_u32" } );
        $usedMeasureDevices->{'Runtime'}{"MaximumTime"} = "rb_rt_RunTime_st.MaximumTime_u32" if $mapping_info;
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_RunTime_st.MinimumTime_u32" } );
        $usedMeasureDevices->{'Runtime'}{"MinimumTime"} = "rb_rt_RunTime_st.MinimumTime_u32" if $mapping_info;
        $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_rt_IntPendingCounterMax_u8" } );
        $usedMeasureDevices->{'Runtime'}{"PendingCounter"} = "rb_rt_IntPendingCounterMax_u8" if $mapping_info;
        $usedMeasureDevices->{'Runtime'}{"delete"} = 1 if exists $usedMeasureDevices->{'Runtime'};
    }

    S_set_warning("Required runtime labels are not defined in *.cns. Runtime will not be documented.") unless exists $usedMeasureDevices->{'Runtime'};

    return 1;

}

sub PrepareAdditionalMeasurements {

    my @faultymappedAdditionalMeasurement;
    my $status = 1;

    foreach my $additionalMeasurement ( keys %{$settingsAdditionalMeasurements_href} ) {

        # prepare the simDevice if it is analog measurement
        next if PrepareAdditionalMeasurementAsAnalog($additionalMeasurement);

        # if none of the preparations was successfull add the device to faulty mapped device list
        push( @faultymappedAdditionalMeasurement, $additionalMeasurement );

    }

    # Throw an error if there are entries in the list of faulty mapped signals
    if ( @faultymappedAdditionalMeasurement > 0 ) {
        my $faultymappedAdditionalMeasurementString = join( "\n", @faultymappedAdditionalMeasurement );
        S_set_warning( "The following AdditionalMeasurements from CREIS measurement mapping have an invalid configuration(\$Defaults->{'CRASH_MEASUREMENT_AND_EVALUATION'}) :\n$faultymappedAdditionalMeasurementString\n\n", 120 );
        $status = 0;
    }

    return $status;
}

sub PrepareAdditionalMeasurementAsAnalog {
    my @args = @_;

    my $additionalMeasurement = shift @args;

    my $measureBy = $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'MeasureBy'};

    # only analog measurements are allowed for this
    return 0 unless $measureBy eq 'trace_analog';

    unless ( defined FL_GetConfiguredDevice( 'labcar', 'measure_trace_analog' ) ) {
        return 0;
    }

    # get settings directly from project constants
    my $current              = $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'Current'};
    my $signalMode           = $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'SignalMode'};
    my $voltageRange         = $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'VoltageRange'};
    my $samplingFrequency_Hz = $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'SamplingFrequency_Hz'};

    # use default setting if project constants don't contain settings
    $current      = 0              unless ( defined $current );
    $signalMode   = 'differential' unless ( defined $signalMode );
    $voltageRange = '20'           unless ( defined $voltageRange );

    unless ( defined $samplingFrequency_Hz ) {
        S_set_warning("'SamplingFrequency_Hz' is not given for AdditionalMeasurement '$additionalMeasurement', but it is required for AdditionalMeasurement type 'Analog'");
        return 0;
    }

    # overwrite current global sampling frequency if the given on is bigger
    $generalSettings_href->{'SamplingFrequency_Hz'} = $samplingFrequency_Hz if $generalSettings_href->{'SamplingFrequency_Hz'} < $samplingFrequency_Hz;

    my $usedAdditionalMeasurement         = $additionalMeasurement;
    my $usedAdditionalMeasurement4scanner = $usedAdditionalMeasurement;
    $usedAdditionalMeasurement4scanner .= "::current" if $current;

    my $scannerAlreadySet;

    if ( exists $usedMeasureDevices->{$measureBy}{$usedAdditionalMeasurement} ) {
        S_set_warning("Channel '$usedAdditionalMeasurement' is already used by a SimDev and will not be configured.\n");

        $scannerAlreadySet = 1;
    }
    else {

        # store the used measure device in the list
        $usedMeasureDevices->{$measureBy}{$usedAdditionalMeasurement} = $usedAdditionalMeasurement;
        $scannerAlreadySet = 0;
    }

    LC_SetTRCscanner( [$usedAdditionalMeasurement4scanner], { 'SignalMode' => $signalMode, 'VoltageRange' => $voltageRange, } ) unless ($scannerAlreadySet);

    # store the used values to the crash data, to make it available to all functions
    $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'Current'}      = $current;
    $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'SignalMode'}   = $signalMode;
    $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'VoltageRange'} = $voltageRange;
    $settingsAdditionalMeasurements_href->{$additionalMeasurement}{'ALIAS'}        = $usedAdditionalMeasurement4scanner;

    return 1;
}

sub PrepareSimDevices {
    my @args = @_;

    my $crashData_href = shift @args;

    # check if there are any Expected Results
    unless ( keys %{ $crashData_href->{'EXPECTEDRESULT'} } ) {
        S_set_error( "No Expected Results found in given crash data", 120 );
        return 0;
    }

    # check for Multi Evaluation SimDevices
    foreach my $simDev ( keys %{ $crashData_href->{'EXPECTEDRESULT'} } ) {

        # skip SimDev if ignored
        next if PrepareSimDeviceIgnored( $crashData_href, $simDev );

        PrepareMultiEvaluationSimDevice( $crashData_href, $simDev );
    }

    my @faultymappedSimDevices;
    my $status = 1;

    foreach my $simDev ( keys %{ $crashData_href->{'EXPECTEDRESULT'} } ) {

        # prepare the simDevice if it can be ignored
        next if PrepareSimDeviceIgnored( $crashData_href, $simDev );

        # prepare the simDevice if it is a squib
        next if PrepareSimDeviceAsSquib( $crashData_href, $simDev );

        # prepare the simDevice if it is analog measurement
        next if PrepareSimDeviceAsAnalog( $crashData_href, $simDev );

        # prepare the simDevice if it is CAN, FLXR or LIN measurement
        next if PrepareSimDeviceAsNetwork( $crashData_href, $simDev );

        # prepare the simDevice if it is fault memory evaluation
        next if PrepareSimDeviceAsFaultMemory( $crashData_href, $simDev );

        # if none of the preparations was successfull add the device to faulty mapped device list
        push( @faultymappedSimDevices, $simDev );

        # set ignored flag for this SimDevice and store the reason if not given already
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings." unless defined $settingsSimDevices_href->{$simDev}{'Ignored'};
    }

    # Throw an error if there are entries in the list of faulty mapped signals
    if ( @faultymappedSimDevices > 0 ) {
        my $faultymappedSimDevicesString = join( "\n", @faultymappedSimDevices );
        S_set_error( "The following SimDevices from the crash database have an invalid configuration in CREIS measurement mapping(\$Defaults->{'CRASH_MEASUREMENT_AND_EVALUATION'}) :\n$faultymappedSimDevicesString\n\n", 120 );
        $status = 0;
    }

    return $status;
}

sub FLC_prepareCrashData4MultiEvaluationSimDevices {
    my @args = @_;

    my $crashData_href = shift @args;

    # get list of simDevices from crashData
    my @simDevices = sort keys %{ $crashData_href->{'EXPECTEDRESULT'} };

    foreach my $simDev (@simDevices) {

        # don't do anything if there are no keys
        next unless exists $settingsSimDevices_href->{$simDev}{MultiEvaluation};

        # copy settings and expected results foreach section
        foreach my $mappingKey ( @{ $settingsSimDevices_href->{$simDev}{MultiEvaluation} } ) {
            $crashData_href->{'EXPECTEDRESULT'}{$mappingKey} = $crashData_href->{'EXPECTEDRESULT'}{$simDev};
        }

        delete $crashData_href->{'EXPECTEDRESULT'}{$simDev};
    }

    return 1;
}

sub PrepareMultiEvaluationSimDevice {
    my @args = @_;

    my $crashData_href = shift @args;
    my $simDev         = shift @args;

    # don't do anything if there are no keys
    return 0 unless keys %{ $settingsSimDevices_href->{$simDev} };

    # all keys have to be hashrefs
    foreach my $mappingKey ( keys %{ $settingsSimDevices_href->{$simDev} } ) {
        return 0 unless ref $settingsSimDevices_href->{$simDev}{$mappingKey} eq "HASH";
    }

    my @mappingKeys = keys %{ $settingsSimDevices_href->{$simDev} };

    # copy settings and expected results foreach section
    foreach my $mappingKey (@mappingKeys) {
        $settingsSimDevices_href->{ $simDev . " - " . $mappingKey } = $settingsSimDevices_href->{$simDev}{$mappingKey};
        $settingsSimDevices_href->{ $simDev . " - " . $mappingKey }{"ALIAS"} = $simDev unless defined $settingsSimDevices_href->{ $simDev . " - " . $mappingKey }{"ALIAS"};
        push( @{ $settingsSimDevices_href->{$simDev}{MultiEvaluation} }, $simDev . " - " . $mappingKey );
        delete $settingsSimDevices_href->{$simDev}{$mappingKey};
        $crashData_href->{'EXPECTEDRESULT'}{ $simDev . " - " . $mappingKey } = $crashData_href->{'EXPECTEDRESULT'}{$simDev};
    }

    delete $crashData_href->{'EXPECTEDRESULT'}{$simDev};

    return 1;
}

sub PrepareSimDeviceIgnored {
    my @args = @_;

    my $crashData_href = shift @args;
    my $simDev         = shift @args;

    return 1 if $settingsSimDevices_href->{$simDev}{'Ignored'};

    return 0;
}

sub PrepareSimDeviceAsNetwork {
    my @args = @_;

    my $crashData_href    = shift @args;
    my $simDev            = shift @args;
    my @can_accessDevices = ( 'CAN', 'FLXR', 'LIN' );
    my $measureBy         = $settingsSimDevices_href->{$simDev}{'MeasureBy'};

    # only network related measurements
    return 0 unless ( grep { /$measureBy/i } @can_accessDevices );

    # store the used measure device in the list
    $usedMeasureDevices->{can_access} = 1;

    # prepare evaluation section (make sure that all parameters are available for the default evaluation)
    $settingsSimDevices_href->{$simDev}{'Evaluation'} = "CREIS_EvaluateNetSignal" unless defined $settingsSimDevices_href->{$simDev}{'Evaluation'};

    return 1 unless $settingsSimDevices_href->{$simDev}{'Evaluation'} eq "CREIS_EvaluateNetSignal";

    unless (defined $settingsSimDevices_href->{$simDev}{'Signal'}
        and defined $settingsSimDevices_href->{$simDev}{'Value'}
        and defined $settingsSimDevices_href->{$simDev}{'Operator'} )
    {
        S_set_error("Invalid Evaluation Settings for \$simDev '$simDev'. Check your 'CREIS_ProjectConst'. \n For the default network signal evaluation 'Signal', 'Operator' and 'Value' need to be defined!");
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings.";
    }

    # check that only on out of HigherPrioSimDevs and CombinedSimDevs is used
    if ( ref( $settingsSimDevices_href->{$simDev}{'HigherPrioSimDevs'} ) eq "ARRAY" and ref( $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} ) eq "ARRAY" ) {
        S_set_error("'CombinedSimDevs' and 'HigherPrioSimDevs'. Evaluation not possible.");
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings.";

        return 0;
    }

    # check if HigherPrioSimDevs are configured correctly
    if ( ref( $settingsSimDevices_href->{$simDev}{'HigherPrioSimDevs'} ) eq "ARRAY" ) {
        foreach my $higherPrioSimDev ( @{ $settingsSimDevices_href->{$simDev}{'HigherPrioSimDevs'} } ) {

            # check for unplausible config
            unless ($settingsSimDevices_href->{$simDev}{MeasureBy} eq $settingsSimDevices_href->{$higherPrioSimDev}{MeasureBy}
                and $settingsSimDevices_href->{$simDev}{Signal} eq $settingsSimDevices_href->{$higherPrioSimDev}{Signal} )
            {
                S_set_error("Defined higher prio SimDev '$higherPrioSimDev' is not having the same settings as evaluated SimDev '$simDev'. Evaluation not possible.");
                $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings.";

                return 0;
            }
        }
    }

    # check if CombinedSimDevs are configured correctly
    if ( ref( $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} ) eq "ARRAY" ) {
        foreach my $combinedSimDev ( @{ $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} } ) {

            # check for unplausible config
            unless ($settingsSimDevices_href->{$simDev}{MeasureBy} eq $settingsSimDevices_href->{$combinedSimDev}{MeasureBy}
                and $settingsSimDevices_href->{$simDev}{Signal} eq $settingsSimDevices_href->{$combinedSimDev}{Signal}
                and $settingsSimDevices_href->{$simDev}{Operator} eq $settingsSimDevices_href->{$combinedSimDev}{Operator}
                and $settingsSimDevices_href->{$simDev}{Value} eq $settingsSimDevices_href->{$combinedSimDev}{Value} )
            {
                S_set_error("Defined CombinedSimDev '$combinedSimDev' is not having the same settings as evaluated SimDev '$simDev'. Evaluation not possible.");
                $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings.";

                return 0;
            }
        }
    }

    $settingsSimDevices_href->{$simDev}{'Type'} = $measureBy;

    return 1;
}

sub PrepareSimDeviceAsFaultMemory {
    my @args = @_;

    my $crashData_href = shift @args;
    my $simDev         = shift @args;

    my $measureBy = $settingsSimDevices_href->{$simDev}{'MeasureBy'};

    return 0 unless $measureBy eq 'fault_memory';

    #check that one of the disjunctive parameters (FaultName, FaultsList) is given
    unless ( exists $settingsSimDevices_href->{$simDev}{'FaultName'} or  exists $settingsSimDevices_href->{$simDev}{'FaultsList'} ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'FaultName' or parameter 'FaultsList' has to be given but is not.", 109 );
            
             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultName' or parameter 'FaultsList' has to be given";
             return 0;          
    }

    #check that parameter 'FaultName' is a string
    if ( exists $settingsSimDevices_href->{$simDev}{'FaultName'} ) {
        unless ( defined $settingsSimDevices_href->{$simDev}{'FaultName'} ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'FaultName' is given but undefined.", 109 );
            
             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultName' is given but undefined";
             return 0;    
        }
        
        if ( ref( $settingsSimDevices_href->{$simDev}{'FaultName'} ) eq 'ARRAY' or ref( $settingsSimDevices_href->{$simDev}{'FaultName'} ) eq 'HASH' ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'FaultName' has to be a string, but given argument ($settingsSimDevices_href->{$simDev}{'FaultName'}) is a reference.", 109 );

             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultName' has to be a string";
             return 0;    
        }
    }

    #check that parameter 'FaultsList' is a ARRAY reference
    if ( exists $settingsSimDevices_href->{$simDev}{'FaultsList'} ) {
        unless ( defined $settingsSimDevices_href->{$simDev}{'FaultsList'} ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'FaultsList' is given but undefined.", 109 );
            
             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultsList' is given but undefined";
             return 0;   
        }
        
        if ( ref( $settingsSimDevices_href->{$simDev}{'FaultsList'} ) ne 'ARRAY' ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'FaultsList' has to be a ARRAY reference, but given argument ($settingsSimDevices_href->{$simDev}{'FaultsList'}) is not an ARRAY reference.", 109 );

             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultsList' has to be a ARRAY reference";
             return 0;  
        }
    }

    # check if CombinedSimDevs are configured correctly
    if ( exists $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} ) {
        unless ( defined $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'CombinedSimDevs' is given but undefined.", 109 );
            
             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'CombinedSimDevs' is given but undefined";
             return 0;   
        }
        
        if ( ref( $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} ) ne 'ARRAY' ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'CombinedSimDevs' has to be a ARRAY reference, but given argument ($settingsSimDevices_href->{$simDev}{'CombinedSimDevs'}) is not an ARRAY reference.", 109 );

             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'CombinedSimDevs' has to be a ARRAY reference";
             return 0;  
        }
        
        foreach my $combinedSimDev ( @{ $settingsSimDevices_href->{$simDev}{'CombinedSimDevs'} } ) {

            # check for unplausible config
            unless ($settingsSimDevices_href->{$simDev}{MeasureBy} eq $settingsSimDevices_href->{$combinedSimDev}{MeasureBy}
                and exists $settingsSimDevices_href->{$simDev}{FaultName}
                and exists $settingsSimDevices_href->{$combinedSimDev}{FaultName}
                and $settingsSimDevices_href->{$simDev}{FaultName} eq $settingsSimDevices_href->{$combinedSimDev}{FaultName})
            {
                S_set_error("Defined CombinedSimDev '$combinedSimDev' is not having the same settings as evaluated SimDev '$simDev'. Evaluation not possible.");
                $settingsSimDevices_href->{$simDev}{'Ignored'} = "Invalid eval settings.";

                return 0;
            }
        }
    }

    # check if DebugData is configured correctly
    if ( exists $settingsSimDevices_href->{$simDev}{'DebugData'} ) {
        unless ( defined $settingsSimDevices_href->{$simDev}{'DebugData'} ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'DebugData' is given but undefined.", 109 );
            
             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'DebugData' is given but undefined";
             return 0;   
        }
        
       if ( ref( $settingsSimDevices_href->{$simDev}{'DebugData'} ) eq 'ARRAY' or ref( $settingsSimDevices_href->{$simDev}{'DebugData'} ) eq 'HASH' ) {
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'DebugData' has to be a string, but given argument ($settingsSimDevices_href->{$simDev}{'DebugData'}) is a reference.", 109 );

             $settingsSimDevices_href->{$simDev}{'Ignored'} = "wrong configuration in CREIS Mapping - parameter 'FaultName' has to be a string";
             return 0;    
        }
        
        unless ($settingsSimDevices_href->{$simDev}{'DebugData'} =~ /^0b[0|x|1]{16}$/){
            S_set_error( "PrepareSimDeviceAsFaultMemory (SimDev: '$simDev'): wrong configuration in CREIS Mapping - parameter 'DebugData' has to follow given pattern (0b................ with . = 0|1|x exactly 16times), but given '$settingsSimDevices_href->{$simDev}{'DebugData'}' does not fullfill the pattern.", 109 );

             $settingsSimDevices_href->{$simDev}{'Ignored'} = " wrong configuration in CREIS Mapping - parameter 'DebugData' has to follow given pattern";
             return 0;              
        }
    }

    $settingsSimDevices_href->{$simDev}{'Type'} = "FaultMemory";

    return 1;
}

sub PrepareSimDeviceAsAnalog {
    my @args = @_;

    my $crashData_href = shift @args;
    my $simDev         = shift @args;

    my $measureBy = $settingsSimDevices_href->{$simDev}{'MeasureBy'};

    # only analog measurements are allowed for this
    return 0 unless $measureBy eq 'trace_analog';

    unless ( defined FL_GetConfiguredDevice( 'labcar', 'measure_trace_analog' ) ) {
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "Configured measure device not available at setup!";
        return 0;
    }

    # get settings directly from project constants
    my $current              = $settingsSimDevices_href->{$simDev}{'Current'};
    my $signalMode           = $settingsSimDevices_href->{$simDev}{'SignalMode'};
    my $voltageRange         = $settingsSimDevices_href->{$simDev}{'VoltageRange'};
    my $samplingFrequency_Hz = $settingsSimDevices_href->{$simDev}{'SamplingFrequency_Hz'};

    # use default setting if project constants don't contain settings
    $current      = 0              unless ( defined $current );
    $signalMode   = 'differential' unless ( defined $signalMode );
    $voltageRange = '20'           unless ( defined $voltageRange );

    unless ( defined $samplingFrequency_Hz ) {
        S_set_error("'SamplingFrequency_Hz' is not given for SimDevice '$simDev', but it is required for SimDevice type 'Analog'");
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "'SamplingFrequency_Hz' is not given.";
        return 0;
    }

    # overwrite current global sampling frequency if the given on is bigger
    $generalSettings_href->{'SamplingFrequency_Hz'} = $samplingFrequency_Hz if $generalSettings_href->{'SamplingFrequency_Hz'} < $samplingFrequency_Hz;

    my $usedSimDev = $simDev;
    $usedSimDev = $settingsSimDevices_href->{$simDev}{'ALIAS'} if defined $settingsSimDevices_href->{$simDev}{'ALIAS'};
    my $usedSimDev4scanner = $usedSimDev;
    $usedSimDev4scanner .= "::current" if $current;

    my $scannerAlreadySet;

    if ( exists $usedMeasureDevices->{$measureBy}{$usedSimDev} ) {
        my @differentSetting;
        push( @differentSetting, "Current" )      unless $current == $settingsSimDevices_href->{ $usedMeasureDevices->{$measureBy}{$usedSimDev} }{'Current'};
        push( @differentSetting, "SignalMode" )   unless $signalMode eq $settingsSimDevices_href->{ $usedMeasureDevices->{$measureBy}{$usedSimDev} }{'SignalMode'};
        push( @differentSetting, "VoltageRange" ) unless $voltageRange eq $settingsSimDevices_href->{ $usedMeasureDevices->{$measureBy}{$usedSimDev} }{'VoltageRange'};

        if ( @differentSetting > 0 ) {
            my $differentSettingString = join( "\n", @differentSetting );
            S_set_error("Channel '$usedSimDev' is used for more than one SimDevice, but following settings are different :\n$differentSettingString\n\n");

            $settingsSimDevices_href->{$simDev}{'Ignored'} = "Configured channel '$usedSimDev' is used by another SimDevice '$usedMeasureDevices->{$measureBy}{$usedSimDev}' with differet Settings!";

            return 0;
        }
        $scannerAlreadySet = 1;
    }
    else {

        # store the used measure device in the list
        $usedMeasureDevices->{$measureBy}{$usedSimDev} = $simDev;
        $scannerAlreadySet = 0;
    }

    LC_SetTRCscanner( [$usedSimDev4scanner], { 'SignalMode' => $signalMode, 'VoltageRange' => $voltageRange, } ) unless ($scannerAlreadySet);

    # store the used values to the crash data, to make it available to all functions
    $settingsSimDevices_href->{$simDev}{'Type'}         = "Analog";
    $settingsSimDevices_href->{$simDev}{'Current'}      = $current;
    $settingsSimDevices_href->{$simDev}{'SignalMode'}   = $signalMode;
    $settingsSimDevices_href->{$simDev}{'VoltageRange'} = $voltageRange;
    $settingsSimDevices_href->{$simDev}{'ALIAS'}        = $usedSimDev4scanner;

    return 1;
}

sub PrepareSimDeviceAsSquib {
    my @args = @_;

    my $crashData_href = shift @args;
    my $simDev         = shift @args;

    my $usedSimDev = $settingsSimDevices_href->{$simDev}{'ALIAS'} // $simDev;

    # return if measureBy is given and analog or digital
    my $measureBy = $settingsSimDevices_href->{$simDev}{'MeasureBy'};
    return 0 if ( defined $measureBy and not $measureBy eq 'trace_analog' and not $measureBy eq 'trace_digital' );

    # return if device is not a squib
    return 0 unless ( grep { /$usedSimDev/i } LC_Get_names('SQUIBS') );

    # use 'trace_digital' if not given by project constants
    $measureBy = 'trace_digital' unless defined $measureBy;

    # check if 'trace_digital' is configured in testbench and try to use 'trace_analog' if not
    if ( $measureBy eq 'trace_digital' and not FL_GetConfiguredDevice( 'labcar', 'measure_trace_digital' ) eq 'LCT' ) {
        $measureBy = undef;
        $measureBy = 'trace_analog' if defined FL_GetConfiguredDevice( 'labcar', 'measure_trace_analog' );
    }

    # check if 'trace_analog' is configured in testbench and try to use 'trace_digital' if not
    if ( $measureBy eq 'trace_analog' and not defined FL_GetConfiguredDevice( 'labcar', 'measure_trace_analog' ) ) {
        $measureBy = undef;
        $measureBy = 'trace_digital' if FL_GetConfiguredDevice( 'labcar', 'measure_trace_digital' ) eq 'LCT';
    }

    # error if no possibilty was found to record the squib
    unless ( defined $measureBy ) {
        S_set_error("No possibility found to record SimDev '$simDev' (SimDevType: 'Squib').");
        $settingsSimDevices_href->{$simDev}{'Ignored'} = "No possibility found to record SimDev '$simDev' (SimDevType: 'Squib').";
        return 0;
    }

    # update the settings of the simDev
    $settingsSimDevices_href->{$simDev}{'MeasureBy'} = $measureBy;

    # store the used measure device in the list
    $usedMeasureDevices->{$measureBy}{$simDev} = $simDev;

    # prepare evaluation section (make sure that all parameters are available for the default evaluation)
    $settingsSimDevices_href->{$simDev}{'Evaluation'} = "CREIS_EvaluateSquibFiring" unless defined $settingsSimDevices_href->{$simDev}{'Evaluation'};

    my ( $fireCurrentThreshold_A, $firingCurrentThresholdSource ) = GetFireCurrentThreshold($simDev);
    $settingsSimDevices_href->{$simDev}{'FiringCurrentThreshold_A'}     = $fireCurrentThreshold_A;
    $settingsSimDevices_href->{$simDev}{'FiringCurrentThresholdSource'} = $firingCurrentThresholdSource;

    # if LCT is used as active measurement device delete all config items which are not needed and return with success
    if ( $measureBy eq 'trace_digital' and FL_GetConfiguredDevice( 'labcar', 'measure_trace_digital' ) eq 'LCT' ) {
        delete $settingsSimDevices_href->{$simDev}{'Current'};
        delete $settingsSimDevices_href->{$simDev}{'SignalMode'};
        delete $settingsSimDevices_href->{$simDev}{'VoltageRange'};

        $settingsSimDevices_href->{$simDev}{'Type'}  = "Squib";
        $settingsSimDevices_href->{$simDev}{'ALIAS'} = $usedSimDev;
        LC_MeasureTraceDigitalConfigureThresholds( [$usedSimDev], $fireCurrentThreshold_A );

        return 1;
    }

    # get settings directly from project constants
    my $current              = $settingsSimDevices_href->{$simDev}{'Current'};
    my $signalMode           = $settingsSimDevices_href->{$simDev}{'SignalMode'};
    my $voltageRange         = $settingsSimDevices_href->{$simDev}{'VoltageRange'};
    my $samplingFrequency_Hz = $settingsSimDevices_href->{$simDev}{'SamplingFrequency_Hz'};

    # use default setting if project constants don't contain settings
    $current              = 1                                               unless ( defined $current );
    $signalMode           = 'differential'                                  unless ( defined $signalMode );
    $voltageRange         = '5'                                             unless ( defined $voltageRange );
    $samplingFrequency_Hz = $generalSettings_href->{'SamplingFrequency_Hz'} unless ( defined $samplingFrequency_Hz );

    # overwrite current global sampling frequency if the given frequency is bigger
    $generalSettings_href->{'SamplingFrequency_Hz'} = $samplingFrequency_Hz if $generalSettings_href->{'SamplingFrequency_Hz'} < $samplingFrequency_Hz;

    my $usedSimDev4scanner = $usedSimDev;
    $usedSimDev4scanner .= "::current" if $current;

    LC_SetTRCscanner( [$usedSimDev4scanner], { 'SignalMode' => $signalMode, 'VoltageRange' => $voltageRange, } );

    # store the used values to the settings, to make it available to all functions
    $settingsSimDevices_href->{$simDev}{'Current'}      = $current;
    $settingsSimDevices_href->{$simDev}{'SignalMode'}   = $signalMode;
    $settingsSimDevices_href->{$simDev}{'VoltageRange'} = $voltageRange;
    $settingsSimDevices_href->{$simDev}{'ALIAS'}        = $usedSimDev4scanner;
    $settingsSimDevices_href->{$simDev}{'Type'}         = "Squib";

    return 1;
}

sub GetFireCurrentThreshold {
    my @args = @_;

    my $simDev = shift @args;
    my $fireCurrentThreshold_A;
    my $firingCurrentThresholdSource;

    if ( defined $settingsSimDevices_href->{$simDev}{'FiringCurrentThreshold_A'} ) {
        $fireCurrentThreshold_A       = $settingsSimDevices_href->{$simDev}{'FiringCurrentThreshold_A'};
        $firingCurrentThresholdSource = 'SimDevSettings';
    }
    elsif ( defined $generalSettings_href->{'FiringCurrentThreshold_A'} and $generalSettings_href->{'FiringCurrentThreshold_A'} eq "SYC" ) {

        my ( $result, $min_current_A, $min_current_backup_A ) = SYC_SQUIB_get_firing_pulse_min_current($simDev);
        my $fireCurrentThresholdTolerance_A = $generalSettings_href->{'FiringCurrentThresholdTolerance_A'};

        if ( not $min_current_A =~ /^([0-9]+(\.[0-9]+)?|\.[0-9]+)$/ or $min_current_A < 1 or $min_current_A > 20 ) {
            $min_current_A = undef;
        }

        if ( not $fireCurrentThresholdTolerance_A =~ /^([0-9]+(\.[0-9]+)?|\.[0-9]+)$/ ) {
            $fireCurrentThresholdTolerance_A = undef;
        }

        if ( $fireCurrentThresholdTolerance_A < 0 and $fireCurrentThresholdTolerance_A > 1 ) {
            $fireCurrentThresholdTolerance_A = undef;
        }

        if ( defined $min_current_A and defined $fireCurrentThresholdTolerance_A ) {
            $fireCurrentThreshold_A       = $min_current_A - $fireCurrentThresholdTolerance_A;
            $firingCurrentThresholdSource = 'SYC';
        }
    }
    elsif ( defined $generalSettings_href->{'FiringCurrentThreshold_A'} ) {
        $fireCurrentThreshold_A       = $generalSettings_href->{'FiringCurrentThreshold_A'};
        $firingCurrentThresholdSource = 'GeneralSettings';
    }

    unless ( $fireCurrentThreshold_A =~ /^([0-9]+(\.[0-9]+)?|\.[0-9]+)$/ ) {
        S_set_warning("Calculated or given \$fireCurrentThreshold_A '$fireCurrentThreshold_A' from source '$firingCurrentThresholdSource' is not in the expected format. \n Default values will be used.");
        $fireCurrentThreshold_A       = 0.5;
        $firingCurrentThresholdSource = 'default';
    }

    if ( $fireCurrentThreshold_A < 0.5 or $fireCurrentThreshold_A > 20 ) {
        S_set_warning("Calculated or given \$fireCurrentThreshold_A '$fireCurrentThreshold_A' from source '$firingCurrentThresholdSource' is not inside the allowed range ( 0.5 A <= x <= 20 A ). \n Default values ( 0.5 A ) will be used.");
        $fireCurrentThreshold_A       = 0.5;
        $firingCurrentThresholdSource = 'default';
    }

    return ( $fireCurrentThreshold_A, $firingCurrentThresholdSource );
}

1;
__END__
