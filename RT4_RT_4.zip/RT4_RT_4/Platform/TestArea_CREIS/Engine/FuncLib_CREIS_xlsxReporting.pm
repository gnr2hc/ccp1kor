# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_CREIS_xlsxReporting;

use strict;
use warnings;
use LIFT_general;
use LIFT_MDSRESULT;
use Clone 'clone';
use XML::LibXML;
use Excel::Writer::XLSX;
use Excel::Writer::XLSX::Utility;
use Font::TTFMetrics;
use File::Basename;

use Exporter;
our @ISA    = qw(Exporter);
our @EXPORT = qw(
  FLC_XLSX_createReport
);

my $moduleName     = __PACKAGE__;
my $calibri        = Font::TTFMetrics->new('c:\windows\fonts\calibri.ttf');
my $lasttcParaName = 'FIRST';
my $timesCreated   = 0;

# formats
my (
    $format_earlyDeployment4DS, $format_lateDeployment4DS, $format_wrongDeployment4DS, $format_noDeployment4DS, $format_Ignored4DS, $format_Inconc4DS,      $format_Multi,           $format_pass,              $format_fail,    $format_pass_w_com,
    $format1,                   $format_earlyDeployment,   $format_url,                $format_wrapped,         $format_RowFaulty,  $format_lateDeployment, $format_wrongDeployment, $format_noDeployment,      $format_Ignored, $format_Inconc,
    $format1_rot30,             $format1_rot90,            $format_Border2,            $format_text_pass,       $format_text_fail,  $format_dynEnvPass,     $format_dynEnvFail,      $format1_rot90_bottomLeft, $format_text,
);

sub FLC_XLSX_createReport {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_XLSX_createReport( [$localSummaryXMLFile, $localXLSXsummary] )', @args );

    my $localSummaryXMLFile = shift @args;
    my $localXLSXsummary    = shift @args;

    my $summaryXMLFile = $FuncLib_CREIS_LoggerFunctions::summaryXMLFile;
    $summaryXMLFile = $localSummaryXMLFile if ( defined $localSummaryXMLFile );

    my $callingFunction = ( caller(1) )[3];
    my $force_creation  = 0;
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        S_w2log( 3, "$2...\n" );    # print the name or the PRD_ function
        if ( $2 eq "END" ) {
            my $projectPath = File::Spec->rel2abs( dirname( dirname( dirname( dirname(__FILE__) ) ) ) );
            my $cmd         = $projectPath . "\\Platform\\TestArea_CREIS\\Tools\\CreateXLSXreport.pl -x " . $summaryXMLFile;
            
            unless ( defined( my $pid = open( SAVE_CHILD_COMMAND, "$cmd |" ) ) ) {
                S_set_error( "executing fork : $!", 5 );
                return;
            }
            return 1;
        }
    }

    # parse the summary XML file and get the reference of Document root element
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # load the existing XML file
    my $oCREISSummaryDoc = $parser->load_xml( location => $summaryXMLFile );

    # get the reference to root element
    my $rootElement = $oCREISSummaryDoc->documentElement;

    my $xpc = XML::LibXML::XPathContext->new($rootElement);

    unless ( defined $localXLSXsummary ) {
        my $mdb_file;

        for my $ecuIdentification ( $xpc->findnodes("//ECU_Identification") ) {
            $mdb_file = $ecuIdentification->getAttribute("MDSResult");
        }

        $mdb_file = basename( $mdb_file, ".mdb" );

        $localXLSXsummary = dirname($summaryXMLFile) . '//__CREIS_' . $mdb_file . '.xlsm';
    }

    my $tc_number              = S_get_TC_number();
    my $xlsxReportUpdateOption = 1;                   # DEFAULT: update for every new crash / state
    $xlsxReportUpdateOption = S_get_exec_option('CREIS_xlsxReportUpdateOption') if S_check_exec_option('CREIS_xlsxReportUpdateOption') and not $main::opt_offline;
    $xlsxReportUpdateOption = 0 if $main::opt_offline;    # do not update the report during offline mode

    # do not create the file, if option == 0 and tc_number is number
    if ( $xlsxReportUpdateOption == 0 and $tc_number =~ /(\d+)/ and not $force_creation ) {
        S_w2log( 3, "CREIS XLSX summary will not be updated. This is switched off by ExecOption 'CREIS_xlsxReportUpdateOption => 0' or during offline mode.\n" );
        return 1;
    }

    my $tcParaName = S_get_TC_parameter_name();

    if ( not defined $tc_number or $tc_number eq "___" ) {
        $tc_number  = 0;
        $tcParaName = "FORCE";
    }

    # do not create the file, if $xlsxReportUpdateOption > 1 and TC > $xlsxReportUpdateOption and file already exists
    if ( $xlsxReportUpdateOption > 1 and $tc_number > $xlsxReportUpdateOption and -e $localXLSXsummary ) {
        S_w2log( 3, "CREIS XLSX summary will not be updated. It will only be updated for the first $xlsxReportUpdateOption iterations or if you delete the file from the report folder." );
        return 1;
    }

    # do not create the file, if $xlsxReportUpdateOption == 1 and only consecutive iteration of the same parameter set and file already exists
    if ( $xlsxReportUpdateOption == 1 and $tcParaName eq $lasttcParaName and -e $localXLSXsummary ) {
        S_w2log( 3, "CREIS XLSX summary will not be updated. It will only be updated for the first occurence of a new crash or state or if you delete the file from the report folder." );
        return 1;
    }

    # do not create the file, if it already was created for more than 300 times to avoid the bug
    # https://github.com/jmcnamara/excel-writer-xlsx/issues/175
    if ( $timesCreated > 299 and not $tcParaName eq "FORCE" ) {
        S_w2log( 3, "CREIS XLSX summary will no longer be updated. Only 300 updates per testlist possible. EC will still create the report." );
        return 1;
    }

    $lasttcParaName = $tcParaName;

    my $workbook = Excel::Writer::XLSX->new($localXLSXsummary);

    if ( $tcParaName eq "FORCE" and not defined $workbook ) {
        S_user_action("Please close the *.xlsm");
        $workbook = Excel::Writer::XLSX->new($localXLSXsummary);
    }
    return 0 unless defined $workbook;

    $timesCreated++;

    $workbook->set_optimization();
    my (
        $actual_RowDeploymentSummary, $actual_RowProjectData,        $actual_RowAlgoIdCheck, $resultAlgoIdCheck,      $actual_RowChannelAssignmentOverview, $actual_RowStaticEnvStates,    $actual_RowDeploymentReport, $crashLinks_href,
        $headerDeploymentReport_href, $headerDeploymentSummary_href, $edrCompletenessResult, $overallCrashIterations, $actual_RowReleaseIntegrityReport,    $resultReleaseIntegrityReport, $faultsOverview_href
    );

    $workbook->add_vba_project( dirname(__FILE__) . '\vbaProject.bin' );

    my $worksheet_prjData                   = $workbook->add_worksheet("ProjectData");
    my $worksheet_AlgoIdCheck               = $workbook->add_worksheet("AlgoIdCheck");
    my $worksheet_ChannelAssignmentOverview = $workbook->add_worksheet("ChannelAssignmentOverview");
    my $worksheet_StaticEnvStates           = $workbook->add_worksheet("StaticEnvStates");
    my $worksheet_FaultsOverview            = $workbook->add_worksheet("FaultsOverview");
    my $worksheet_DeploymentReport          = $workbook->add_worksheet("DeploymentReport");
    my $worksheet_DeploymentSummary         = $workbook->add_worksheet("DeploymentSummary");

    $format1                   = $workbook->add_format( bold       => 1 );
    $format_earlyDeployment    = $workbook->add_format( bg_color   => 'cyan', border => 2 );
    $format_lateDeployment     = $workbook->add_format( bg_color   => 'yellow', border => 2 );
    $format_wrongDeployment    = $workbook->add_format( bg_color   => '#FF99CC', border => 2 );
    $format_noDeployment       = $workbook->add_format( bg_color   => 'red', border => 2 );
    $format_Ignored            = $workbook->add_format( bg_color   => '#C5D5F5', border => 2 );                                                   # light blue
    $format_Inconc             = $workbook->add_format( bg_color   => '#CC99FF', border => 2 );                                                   # violett
    $format_Border2            = $workbook->add_format( border     => 2 );
    $format_earlyDeployment4DS = $workbook->add_format( bg_color   => 'cyan' );
    $format_lateDeployment4DS  = $workbook->add_format( bg_color   => 'yellow' );
    $format_wrongDeployment4DS = $workbook->add_format( bg_color   => '#FF99CC' );
    $format_noDeployment4DS    = $workbook->add_format( bg_color   => 'red' );
    $format_Ignored4DS         = $workbook->add_format( bg_color   => '#C5D5F5' );                                                                # light blue
    $format_Inconc4DS          = $workbook->add_format( bg_color   => '#CC99FF' );                                                                # violett
    $format_Multi              = $workbook->add_format( bg_color   => '#FFCC99', );
    $format1_rot30             = $workbook->add_format( bold       => 1, rotation => 30 );
    $format1_rot90             = $workbook->add_format( bold       => 1, rotation => 90, align => 'top', valign => 'left', align => 'bottom' );
    $format1_rot90_bottomLeft  = $workbook->add_format( bold       => 1, rotation => 90, align => 'top', valign => 'left', align => 'bottom' );
    $format_url                = $workbook->add_format( color      => 'blue', underline => 1 );
    $format_wrapped            = $workbook->add_format( text_wrap  => 1 );
    $format_RowFaulty          = $workbook->add_format( bg_color   => '#C0C0C0' );
    $format_pass               = $workbook->add_format( bg_color   => '#00B050' );
    $format_fail               = $workbook->add_format( bg_color   => 'red' );
    $format_pass_w_com         = $workbook->add_format( bg_color   => 'yellow' );
    $format_text_pass          = $workbook->add_format( color      => '#00B050' );
    $format_text_fail          = $workbook->add_format( color      => 'red' );
    $format_dynEnvPass         = $workbook->add_format( color      => '#006100', bg_color => '#C6EFCE' );
    $format_dynEnvFail         = $workbook->add_format( color      => '#9C0006', bg_color => '#FFC7CE' );
    $format_text               = $workbook->add_format( num_format => '@' );

    AutofitStartStoringStringWidths($worksheet_prjData);
    AutofitStartStoringStringWidths($worksheet_AlgoIdCheck);
    AutofitStartStoringStringWidths($worksheet_ChannelAssignmentOverview);
    AutofitStartStoringStringWidths($worksheet_StaticEnvStates);

    # fill 'General Part' of ProjectData
    $actual_RowProjectData = WsProjectData_GeneralPart( $workbook, $worksheet_prjData, 1, $xpc );

    # add ReleaseIntegrity result to Project Data
    $actual_RowProjectData = WsProjectData_ReleaseIntegrityCheck( $workbook, $worksheet_prjData, $actual_RowProjectData, $xpc );

    # fill AlgoIdCheck
    ( $actual_RowAlgoIdCheck, $resultAlgoIdCheck ) = WsAlgoIdCheck( $workbook, $worksheet_AlgoIdCheck, 1, $xpc );

    # fill ChannelAssignmentOverview
    $actual_RowChannelAssignmentOverview = WsChannelAssignmentOverview( $workbook, $worksheet_ChannelAssignmentOverview, 1, $xpc );

    # fill StaticEnvStates
    $actual_RowStaticEnvStates = WsStaticEnvStates( $workbook, $worksheet_StaticEnvStates, 1, $xpc );

    # fill 'Header' of DeploymentReport
    $headerDeploymentReport_href = WsDeploymentReport_getHeaderStructure($xpc);
    $actual_RowDeploymentReport = WsDeploymentReport_Header( $workbook, $worksheet_DeploymentReport, 0, $headerDeploymentReport_href );
    my $formulaStartDeploymentReport = $actual_RowDeploymentReport;
    AutofitStartStoringStringWidths($worksheet_DeploymentReport);

    # fill all Crashes in DeploymentReport
    ( $actual_RowDeploymentReport, $crashLinks_href, $edrCompletenessResult, $faultsOverview_href ) = WsDeploymentReport_Crashes( $workbook, $worksheet_DeploymentReport, $actual_RowDeploymentReport, $xpc, $headerDeploymentReport_href, $faultsOverview_href );
    my $formulaEndDeploymentReport = $actual_RowDeploymentReport - 1;
    $overallCrashIterations = $formulaEndDeploymentReport - $formulaStartDeploymentReport + 1;

    # finalize the DeploymentReport worksheet
    WsDeploymentReport_Finalize( $workbook, $worksheet_DeploymentReport, $formulaStartDeploymentReport, $actual_RowDeploymentReport, $headerDeploymentReport_href );

    # fill worksheet $worksheet_FaultsOverview ...
    my $rbFaultEvaluation = WsFaultsOverview( $xpc, $workbook, $worksheet_FaultsOverview, $faultsOverview_href, $headerDeploymentReport_href, $formulaStartDeploymentReport, $formulaEndDeploymentReport );

    # add Runtime Measurement Results to Project Data
    $actual_RowProjectData = WsProjectData_RuntimeMeasurement( $workbook, $worksheet_prjData, $actual_RowProjectData, $headerDeploymentReport_href, $formulaStartDeploymentReport, $formulaEndDeploymentReport );

    # add AlgoIdCheck result to Project Data
    $actual_RowProjectData = WsProjectData_AlgoIdCheck( $workbook, $worksheet_prjData, $actual_RowProjectData, $resultAlgoIdCheck );

    # add EDR completeness result to Project Data
    $actual_RowProjectData = WsProjectData_EdrCompletness( $workbook, $worksheet_prjData, $actual_RowProjectData, $headerDeploymentReport_href, $edrCompletenessResult, $overallCrashIterations );
    $actual_RowProjectData = WsProjectData_EdrReader( $workbook, $worksheet_prjData, $actual_RowProjectData, $xpc );

    # add Faults Overview Result to Project Data
    $actual_RowProjectData = WsProjectData_FaultsOverview( $workbook, $worksheet_prjData, $actual_RowProjectData, $rbFaultEvaluation );

    # fill 'Header' of DeploymentSummary
    ( $actual_RowDeploymentSummary, $headerDeploymentSummary_href ) = WsDeploymentSummary_Header( $workbook, $worksheet_DeploymentSummary, 0, $xpc );
    my $formulaStartDeploymentSummary = $actual_RowDeploymentSummary;
    AutofitStartStoringStringWidths($worksheet_DeploymentSummary);

    # fill all Crashes in DeploymentSummary
    $actual_RowDeploymentSummary = WsDeploymentSummary_Crashes( $workbook, $worksheet_DeploymentSummary, $actual_RowDeploymentSummary, $xpc, $headerDeploymentSummary_href, $crashLinks_href );
    my $formulaEndDeploymentSummary = $actual_RowDeploymentSummary;

    # add SystemTestEvaluation template to Project Data
    $actual_RowProjectData = WsProjectData_SystemTestEvaluation( $workbook, $worksheet_prjData, $actual_RowProjectData );

    # add DeploymentBehaviourCheck template to Project Data
    $actual_RowProjectData = WsProjectData_DeploymentBehaviourCheck( $workbook, $worksheet_prjData, $actual_RowProjectData );

    AutofitColumns($worksheet_prjData);

    #    AutofitColumns($worksheet_ReleaseIntegrityReport);
    AutofitColumns($worksheet_AlgoIdCheck);
    AutofitColumns($worksheet_ChannelAssignmentOverview);
    AutofitColumns($worksheet_StaticEnvStates);
    AutofitColumns($worksheet_DeploymentSummary);
    AutofitColumns($worksheet_FaultsOverview);

    $workbook->close();

    return 1;
}

# parse the settings node and create the excel header structure

sub WsDeploymentReport_getHeaderStructure {
    my $xpc = shift;
    my ( $header_href, $column );

    for my $settingsNode ( $xpc->findnodes("//Settings") ) {
        $column = 9;

        $header_href->{'dynEnv'}{'first'} = $column;
        for my $dynamicEnvState ( $settingsNode->findnodes("DynamicEnvironment") ) {
            $header_href->{'dynEnv'}{ $dynamicEnvState->getAttribute('name') }{'Value'} = $column++;
            $header_href->{'dynEnv'}{ $dynamicEnvState->getAttribute('name') }{'Set'}   = $column++;
            $header_href->{'dynEnv'}{ $dynamicEnvState->getAttribute('name') }{'Check'} = $column++;
        }

        $header_href->{'simDev'}{'first'} = $column;
        for my $simDev ( $settingsNode->findnodes("SimDevice") ) {
            my $simDeviceName = $simDev->getAttribute('Name');
            $header_href->{'simDev'}{$simDeviceName}{'MinT_ms'}             = $column++;
            $header_href->{'simDev'}{$simDeviceName}{'ActualFiringTime_ms'} = $column++;
            $header_href->{'simDev'}{$simDeviceName}{'MaxT_ms'}             = $column++;
            $header_href->{'simDev'}{$simDeviceName}{'Text'}                = $column++;
        }

        $header_href->{'runtime'}{'first'} = $column;
        for my $runtime ( $settingsNode->findnodes("Runtime") ) {
            $header_href->{'runtime'}{ $runtime->getAttribute('Name') }{'column'}     = $column++;
            $header_href->{'runtime'}{ $runtime->getAttribute('Name') }{'pdVariable'} = $runtime->getAttribute('pdVariable');
            $header_href->{'runtime'}{ $runtime->getAttribute('Name') }{'unit'}       = $runtime->getAttribute('unit');
        }

        for my $runtime ( $settingsNode->findnodes("ExtendedRuntime") ) {
            $header_href->{'extRuntime'}{ $runtime->getAttribute('Name') }{'column'}     = $column++;
            $header_href->{'extRuntime'}{ $runtime->getAttribute('Name') }{'pdVariable'} = $runtime->getAttribute('pdVariable');
            $header_href->{'extRuntime'}{ $runtime->getAttribute('Name') }{'unit'}       = $runtime->getAttribute('unit');
        }

        for my $edr ( $settingsNode->findnodes("EDR") ) {
            $header_href->{'edr'}{first} = $column unless defined $header_href->{'edr'}{first};
            $header_href->{'edr'}{ $edr->getAttribute('Name') }{'column'}     = $column++;
            $header_href->{'edr'}{ $edr->getAttribute('Name') }{'pdVariable'} = $edr->getAttribute('pdVariable');
        }

        for my $pdLabelBeforeCrash ( $settingsNode->findnodes("PdLabelBeforeCrash") ) {
            $header_href->{'pdLabelBeforeCrash'}{first} = $column unless defined $header_href->{'pdLabelBeforeCrash'}{first};
            $header_href->{'pdLabelBeforeCrash'}{ $pdLabelBeforeCrash->getAttribute('Name') }{'column'}     = $column++;
            $header_href->{'pdLabelBeforeCrash'}{ $pdLabelBeforeCrash->getAttribute('Name') }{'pdVariable'} = $pdLabelBeforeCrash->getAttribute('pdVariable');
            $header_href->{'pdLabelBeforeCrash'}{ $pdLabelBeforeCrash->getAttribute('Name') }{'unit'}       = $pdLabelBeforeCrash->getAttribute('unit');
            $header_href->{'pdLabelBeforeCrash'}{ $pdLabelBeforeCrash->getAttribute('Name') }{'mode'}       = $pdLabelBeforeCrash->getAttribute('mode');
            $header_href->{'pdLabelBeforeCrash'}{ $pdLabelBeforeCrash->getAttribute('Name') }{'factor'}     = $pdLabelBeforeCrash->getAttribute('factor');
        }

        for my $pdLabelAfterCrash ( $settingsNode->findnodes("PdLabelAfterCrash") ) {
            $header_href->{'pdLabelAfterCrash'}{first} = $column unless defined $header_href->{'pdLabelAfterCrash'}{first};
            $header_href->{'pdLabelAfterCrash'}{ $pdLabelAfterCrash->getAttribute('Name') }{'column'}     = $column++;
            $header_href->{'pdLabelAfterCrash'}{ $pdLabelAfterCrash->getAttribute('Name') }{'pdVariable'} = $pdLabelAfterCrash->getAttribute('pdVariable');
            $header_href->{'pdLabelAfterCrash'}{ $pdLabelAfterCrash->getAttribute('Name') }{'unit'}       = $pdLabelAfterCrash->getAttribute('unit');
            $header_href->{'pdLabelAfterCrash'}{ $pdLabelAfterCrash->getAttribute('Name') }{'mode'}       = $pdLabelAfterCrash->getAttribute('mode');
            $header_href->{'pdLabelAfterCrash'}{ $pdLabelAfterCrash->getAttribute('Name') }{'factor'}     = $pdLabelAfterCrash->getAttribute('factor');
        }

        $header_href->{'faults'}{first}                         = $column;
        $header_href->{'faults'}{'before_ecu_mode'}{'column'}   = $column++;
        $header_href->{'faults'}{'before_detected'}{'column'}   = $column++;
        $header_href->{'faults'}{'before_unexpected'}{'column'} = $column++;
        $header_href->{'faults'}{'before_missing'}{'column'}    = $column++;
        $header_href->{'faults'}{'after_ecu_mode'}{'column'}    = $column++;
        $header_href->{'faults'}{'after_detected'}{'column'}    = $column++;
        $header_href->{'faults'}{'after_additional'}{'column'}  = $column++;
        $header_href->{'faults'}{'after_unexpected'}{'column'}  = $column++;
        $header_href->{'faults'}{'after_missing'}{'column'}     = $column++;
        $header_href->{'comment'}                               = $column++;
    }

    return $header_href;
}

sub WsDeploymentReport_Header {
    my $workbook    = shift;
    my $worksheet   = shift;
    my $row         = shift;
    my $header_href = shift;

    $worksheet->set_column( 0, 4, 5 );

    # row 0
    $worksheet->write( $row, 0, 'Legend', $format1 );

    $worksheet->write( $row, $header_href->{'dynEnv'}{'first'}, "DYNAMIC ENV", $format1 );
    delete $header_href->{'dynEnv'}{'first'};
    $worksheet->write( $row, $header_href->{'simDev'}{'first'}, "SIMDEVICE", $format1 );
    delete $header_href->{'simDev'}{'first'};
    $worksheet->write( $row, $header_href->{'runtime'}{'first'}, "RUNTIME", $format1 );
    delete $header_href->{'runtime'}{'first'};
    if ( exists $header_href->{'edr'}{'first'} ) {
        $worksheet->write( $row, $header_href->{'edr'}{'first'}, "EDR", $format1 );
        delete $header_href->{'edr'}{'first'};
    }
    if ( exists $header_href->{'pdLabelBeforeCrash'}{'first'} ) {
        $worksheet->write( $row, $header_href->{'pdLabelBeforeCrash'}{'first'}, "PD_LABELS BEFORE CRASH", $format1 );
        delete $header_href->{'pdLabelBeforeCrash'}{'first'};
    }
    if ( exists $header_href->{'pdLabelAfterCrash'}{'first'} ) {
        $worksheet->write( $row, $header_href->{'pdLabelAfterCrash'}{'first'}, "PD_LABELS AFTER CRASH", $format1 );
        delete $header_href->{'pdLabelAfterCrash'}{'first'};
    }
    $worksheet->write( $row++, $header_href->{'faults'}{'first'}, "RB_FAULTS", $format1 );
    delete $header_href->{'faults'}{'first'};

    # row 1
    $worksheet->merge_range( $row, 0, $row, 6, 'Late Deployment ... x# | t.tt ms', $format_lateDeployment );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 2
    $worksheet->merge_range( $row, 0, $row, 6, 'Early Deployment ... x# | t.tt ms', $format_earlyDeployment );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 3
    $worksheet->merge_range( $row, 0, $row, 6, 'Wrong Deployment ... x# | t.tt ms', $format_wrongDeployment );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 4
    $worksheet->merge_range( $row, 0, $row, 6, 'No Deployment ... -#', $format_noDeployment );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 5
    $worksheet->merge_range( $row, 0, $row, 6, 'Inconc ... reason', $format_Inconc );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 6
    $worksheet->merge_range( $row, 0, $row, 6, 'Ignored ... reason', $format_Ignored );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 7
    $worksheet->merge_range( $row, 0, $row, 6, 'Optional Deployment ... [ MinT_ms | MeasT_ms | MaxT_ms ]', $format_Border2 );
    $worksheet->set_row( $row++, undef, undef, 0, 1 );

    # row 8
    $worksheet->write( $row, 0, "      " . "TestListNumber",        $format1_rot90_bottomLeft );
    $worksheet->write( $row, 1, "      " . "TestCase Module",       $format1_rot90_bottomLeft );
    $worksheet->write( $row, 2, "      " . "Crash-Id",              $format1_rot90_bottomLeft );
    $worksheet->write( $row, 3, "      " . "Crash Name",            $format1_rot90_bottomLeft );
    $worksheet->write( $row, 4, "      " . "State",                 $format1_rot90_bottomLeft );
    $worksheet->write( $row, 5, "      " . "Iteration",             $format1_rot90_bottomLeft );
    $worksheet->write( $row, 6, "      " . "Assignment Comment",    $format1_rot90_bottomLeft );
    $worksheet->write( $row, 7, "      " . "LINK test results",     $format1_rot90_bottomLeft );
    $worksheet->write( $row, 8, "      " . "LINK measurement data", $format1_rot90_bottomLeft );

    foreach my $dynamicEnvState ( keys %{ $header_href->{'dynEnv'} } ) {
        $worksheet->write( $row, $header_href->{'dynEnv'}{$dynamicEnvState}{'Value'}, $dynamicEnvState, $format1_rot90 );
    }

    foreach my $simDev ( keys %{ $header_href->{'simDev'} } ) {
        $worksheet->write( $row, $header_href->{'simDev'}{$simDev}{'MinT_ms'}, $simDev, $format1_rot30 );
    }

    foreach my $runtime ( keys %{ $header_href->{'runtime'} } ) {
        $worksheet->write( $row, $header_href->{'runtime'}{$runtime}{'column'}, $runtime, $format1_rot90 );
    }
    foreach my $extRuntime ( keys %{ $header_href->{'extRuntime'} } ) {
        $worksheet->write( $row, $header_href->{'extRuntime'}{$extRuntime}{'column'}, $extRuntime, $format1_rot90 );
    }

    foreach my $edr ( keys %{ $header_href->{'edr'} } ) {
        $worksheet->write( $row, $header_href->{'edr'}{$edr}{'column'}, $edr, $format1_rot90 );
    }

    foreach my $pdLabelBeforeCrash ( keys %{ $header_href->{'pdLabelBeforeCrash'} } ) {
        $worksheet->write( $row, $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'column'}, $pdLabelBeforeCrash, $format1_rot90 );
    }

    foreach my $pdLabelAfterCrash ( keys %{ $header_href->{'pdLabelAfterCrash'} } ) {
        $worksheet->write( $row, $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'column'}, $pdLabelAfterCrash, $format1_rot90 );
    }

    $worksheet->write( $row, $header_href->{'faults'}{'before_ecu_mode'}{'column'}, 'before crash', $format1_rot90 );
    $worksheet->merge_range( $row, $header_href->{'faults'}{'before_ecu_mode'}{'column'}, $row, $header_href->{'faults'}{'before_missing'}{'column'}, 'before crash', $format1_rot90 );
    $worksheet->write( $row, $header_href->{'faults'}{'after_ecu_mode'}{'column'}, 'after crash', $format1_rot90 );
    $worksheet->merge_range( $row, $header_href->{'faults'}{'after_ecu_mode'}{'column'}, $row, $header_href->{'faults'}{'after_missing'}{'column'}, 'after crash', $format1_rot90 );

    # row 9
    $worksheet->merge_range( $row, 0, $row + 1, 0, "      " . "TestList-Number",       $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 1, $row + 1, 1, "      " . "TestCase-Module",       $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 2, $row + 1, 2, "      " . "Crash-Id",              $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 3, $row + 1, 3, "      " . "Crash Name",            $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 4, $row + 1, 4, "      " . "State",                 $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 5, $row + 1, 5, "      " . "Iteration",             $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 6, $row + 1, 6, "      " . "Assignment Comment",    $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 7, $row + 1, 7, "      " . "LINK test results",     $format1_rot90_bottomLeft );
    $worksheet->merge_range( $row, 8, $row + 1, 8, "      " . "LINK measurement data", $format1_rot90_bottomLeft );

    foreach my $dynamicEnvState ( keys %{ $header_href->{'dynEnv'} } ) {
        $worksheet->write( $row + 1, $header_href->{'dynEnv'}{$dynamicEnvState}{'Value'}, "Value", $format1_rot90 );
        $worksheet->write( $row + 1, $header_href->{'dynEnv'}{$dynamicEnvState}{'Set'},   "Set",   $format1_rot90 );
        $worksheet->write( $row + 1, $header_href->{'dynEnv'}{$dynamicEnvState}{'Check'}, "Check", $format1_rot90 );
    }

    foreach my $simDev ( keys %{ $header_href->{'simDev'} } ) {
        $worksheet->write( $row + 1, $header_href->{'simDev'}{$simDev}{'MinT_ms'},             'MinT_ms',   $format1_rot90 );
        $worksheet->write( $row + 1, $header_href->{'simDev'}{$simDev}{'ActualFiringTime_ms'}, 'MeasT_ms',  $format1_rot90 );
        $worksheet->write( $row + 1, $header_href->{'simDev'}{$simDev}{'MaxT_ms'},             'MaxT_ms',   $format1_rot90 );
        $worksheet->write( $row + 1, $header_href->{'simDev'}{$simDev}{'Text'},                'Deviation', $format1_rot90 );
    }

    foreach my $runtime ( keys %{ $header_href->{'runtime'} } ) {
        $worksheet->write( $row + 1, $header_href->{'runtime'}{$runtime}{'column'}, $header_href->{'runtime'}{$runtime}{'unit'}, $format1_rot90 );
        $worksheet->write_comment( $row + 1, $header_href->{'runtime'}{$runtime}{'column'}, $header_href->{'runtime'}{$runtime}{'pdVariable'}, width => 350, height => 24 );
    }

    foreach my $extRuntime ( keys %{ $header_href->{'extRuntime'} } ) {
        $worksheet->write( $row + 1, $header_href->{'extRuntime'}{$extRuntime}{'column'}, $header_href->{'extRuntime'}{$extRuntime}{'unit'}, $format1_rot90 );
        $worksheet->write_comment( $row + 1, $header_href->{'extRuntime'}{$extRuntime}{'column'}, $header_href->{'extRuntime'}{$extRuntime}{'pdVariable'}, width => 350, height => 24 );
    }

    foreach my $edr ( keys %{ $header_href->{'edr'} } ) {
        $worksheet->write( $row + 1, $header_href->{'edr'}{$edr}{'column'}, "", $format1_rot90 );
        $worksheet->write_comment( $row + 1, $header_href->{'edr'}{$edr}{'column'}, $header_href->{'edr'}{$edr}{'pdVariable'}, width => 350, height => 24 ) if defined $header_href->{'edr'}{$edr}{'pdVariable'};
    }

    foreach my $pdLabelBeforeCrash ( keys %{ $header_href->{'pdLabelBeforeCrash'} } ) {
        my $unit = $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'unit'};
        my $mode = $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'mode'};

        my $text = $mode;
        $text .= "_" . $unit if defined $unit;

        $worksheet->write( $row + 1, $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'column'}, $text, $format1_rot90 );
        $worksheet->write_comment( $row + 1, $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'column'}, $header_href->{'pdLabelBeforeCrash'}{$pdLabelBeforeCrash}{'pdVariable'}, width => 350, height => 24 );
    }

    foreach my $pdLabelAfterCrash ( keys %{ $header_href->{'pdLabelAfterCrash'} } ) {
        my $unit = $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'unit'};
        my $mode = $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'mode'};

        my $text = $mode;
        $text .= "_" . $unit if defined $unit;

        $worksheet->write( $row + 1, $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'column'}, $text, $format1_rot90 );
        $worksheet->write_comment( $row + 1, $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'column'}, $header_href->{'pdLabelAfterCrash'}{$pdLabelAfterCrash}{'pdVariable'}, width => 350, height => 24 );
    }

    $worksheet->write( $row + 1, $header_href->{'faults'}{'before_ecu_mode'}{'column'},   "ECU Mode",   $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'before_detected'}{'column'},   "detected",   $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'before_unexpected'}{'column'}, "unexpected", $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'before_missing'}{'column'},    "missing",    $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'after_ecu_mode'}{'column'},    "ECU Mode",   $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'after_detected'}{'column'},    "detected",   $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'after_additional'}{'column'},  "additional", $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'after_unexpected'}{'column'},  "unexpected", $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'faults'}{'after_missing'}{'column'},     "missing",    $format1_rot90 );
    $worksheet->write( $row + 1, $header_href->{'comment'},                               "Comments",   $format1_rot90 );

    # merge between row 8 + 9
    # It is possible, but kludgey, to workaround this by writing the row data first and then merging the cells later.
    foreach my $edr ( keys %{ $header_href->{'edr'} } ) {
        $worksheet->merge_range( $row, $header_href->{'edr'}{$edr}{'column'}, $row + 1, $header_href->{'edr'}{$edr}{'column'}, $edr, $format1_rot90 );
    }
    $row++;
    $row++;

    return $row;
}

sub WsDeploymentReport_perCrashDynEnvs {
    my $worksheet   = shift;
    my $row         = shift;
    my $crash       = shift;
    my $header_href = shift;

    my $localDynEnvHeader_href = clone $header_href->{'dynEnv'};

    # check all dynamicEnvStates from xml
    for my $collectedDynamicEnvStates ( $crash->findnodes("CollectedDynamicEnvironements") ) {
        for my $dynamicEnvState ( $collectedDynamicEnvStates->findnodes("DynamicEnvironment") ) {
            my $dynEnvFormat = undef;
            my @setTexts     = split( /\|/, $dynamicEnvState->getAttribute('joinedSetText') );
            my @checkTexts   = split( /\|/, $dynamicEnvState->getAttribute('joinedCheckText') );
            my @verdicts     = split( /\|/, $dynamicEnvState->getAttribute('joinedVerdict') );

            my @richTextParameters;
            for my $i ( 0 .. $#setTexts ) {

                # add the the rich text list to write it formated
                push( @richTextParameters, $setTexts[$i] );
                push( @richTextParameters, "\n" );

                # write any part to ensure biggest is used for column width
                $worksheet->write( $row, $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') }{'Set'}, $setTexts[$i] );
            }
            pop @richTextParameters;    # remove the last /n as it is not needed
            $worksheet->write_rich_string( $row, $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') }{'Set'}, @richTextParameters, $format_wrapped );

            @richTextParameters = ();
            for my $i ( 0 .. $#checkTexts ) {
                if ( defined $verdicts[$i] and $verdicts[$i] eq "VERDICT_PASS" ) {
                    push( @richTextParameters, $format_text_pass );
                    $dynEnvFormat = $format_dynEnvPass unless defined $dynEnvFormat;
                }
                elsif ( defined $verdicts[$i] and $verdicts[$i] eq "VERDICT_FAIL" ) {
                    push( @richTextParameters, $format_text_fail );
                    $dynEnvFormat = $format_dynEnvFail;
                }

                push( @richTextParameters, $checkTexts[$i] );
                push( @richTextParameters, "\n" );

                # write any part to ensure biggest is used for column width
                $worksheet->write( $row, $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') }{'Check'}, $checkTexts[$i] );
            }
            pop @richTextParameters;    # remove the last /n as it is not needed
            $worksheet->write_rich_string( $row, $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') }{'Check'}, @richTextParameters, $format_wrapped );

            # write the value in color for check result
            $worksheet->write( $row, $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') }{'Value'}, $dynamicEnvState->getAttribute('value'), $dynEnvFormat );
            delete $localDynEnvHeader_href->{ $dynamicEnvState->getAttribute('name') };
        }
    }

    # enter all missing dynamicEnvStates
    foreach my $dynEnvColumn ( keys %$localDynEnvHeader_href ) {
        $worksheet->write( $row, $localDynEnvHeader_href->{$dynEnvColumn}{'Value'}, "-", $format_Inconc );
        $worksheet->write_comment( $row, $localDynEnvHeader_href->{$dynEnvColumn}{'Value'}, "Error during evaluation" );
    }

    return 1;
}

sub WsDeploymentReport_perCrashSimDevs {
    my $worksheet   = shift;
    my $row         = shift;
    my $crash       = shift;
    my $header_href = shift;

    my $localSimDevHeader_href = clone $header_href->{'simDev'};

    # check all simDevices from xml
    for my $simDev ( $crash->findnodes("SimDevice") ) {
        my $simDeviceName = $simDev->getAttribute('Name');

        my $isDeployed = $simDev->getAttribute('IsDeployed');

        if ( $isDeployed == $CANFIRE_SIMDEVICE ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'MinT_ms'},             '[ ' . $simDev->getAttribute('MinT_ms') );
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'ActualFiringTime_ms'}, $simDev->getAttribute('ActualFiringTime_ms') );
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'MaxT_ms'},             $simDev->getAttribute('MaxT_ms') . ' ]', );
        }
        else {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'MinT_ms'},             $simDev->getAttribute('MinT_ms') );
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'ActualFiringTime_ms'}, $simDev->getAttribute('ActualFiringTime_ms') );
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'MaxT_ms'},             $simDev->getAttribute('MaxT_ms') );
        }

        if ( $simDev->getAttribute('FiringStatus') eq "Late Deployment" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text'), $format_lateDeployment );
            $worksheet->set_row( $row, undef, $format_RowFaulty );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "Early Deployment" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text'), $format_earlyDeployment );
            $worksheet->set_row( $row, undef, $format_RowFaulty );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "Wrong Deployment" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text'), $format_wrongDeployment );
            $worksheet->set_row( $row, undef, $format_RowFaulty );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "No Deployment" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text'), $format_noDeployment );
            $worksheet->set_row( $row, undef, $format_RowFaulty );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "Ignored" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, "Ignored", $format_Ignored );
            $worksheet->write_comment( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text') );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "INCONC" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, "INCONC", $format_Inconc );
            $worksheet->write_comment( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text') );
            $worksheet->set_row( $row, undef, $format_RowFaulty );
        }
        elsif ( $simDev->getAttribute('FiringStatus') eq "VALID" ) {
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text') );
        }
        else {

            #unplausible firing Status maybe error has to go here...
            $worksheet->write( $row, $localSimDevHeader_href->{$simDeviceName}{'Text'}, $simDev->getAttribute('Text') );
        }
        delete $localSimDevHeader_href->{$simDeviceName};
    }

    # enter all missing simDevices
    foreach my $simDevColumn ( keys %$localSimDevHeader_href ) {
        $worksheet->write( $row, $localSimDevHeader_href->{$simDevColumn}{'MinT_ms'},             "-" );
        $worksheet->write( $row, $localSimDevHeader_href->{$simDevColumn}{'ActualFiringTime_ms'}, "-" );
        $worksheet->write( $row, $localSimDevHeader_href->{$simDevColumn}{'MaxT_ms'},             "-" );
        $worksheet->write( $row, $localSimDevHeader_href->{$simDevColumn}{'Text'},                "INCONC", $format_Inconc );
        $worksheet->write_comment( $row, $localSimDevHeader_href->{$simDevColumn}, "Error during evaluation" );
        $worksheet->set_row( $row, undef, $format_RowFaulty );
    }

    return 1;
}

sub WsDeploymentReport_perCrashRuntime {
    my $worksheet   = shift;
    my $row         = shift;
    my $crash       = shift;
    my $header_href = shift;

    my $localRuntimeHeader_href    = clone $header_href->{'runtime'};
    my $localExtRuntimeHeader_href = clone $header_href->{'extRuntime'};

    # check all runtime labels from xml
    for my $runtimeNode ( $crash->findnodes("Runtime") ) {
        $worksheet->write( $row, $localRuntimeHeader_href->{ $runtimeNode->getAttribute('Name') }{'column'}, $runtimeNode->getAttribute('Value') );
        delete $localRuntimeHeader_href->{ $runtimeNode->getAttribute('Name') };
    }

    # check all extended runtime labels from xml
    for my $extendedRuntimeNode ( $crash->findnodes("ExtendedRuntime") ) {
        $worksheet->write( $row, $localExtRuntimeHeader_href->{ $extendedRuntimeNode->getAttribute('Name') }{'column'}, $extendedRuntimeNode->getAttribute('Value') );
        delete $localExtRuntimeHeader_href->{ $extendedRuntimeNode->getAttribute('Name') };
    }

    # enter all missing runtime Labels
    foreach my $runtimeColumn ( keys %$localRuntimeHeader_href ) {
        $worksheet->write( $row, $localRuntimeHeader_href->{$runtimeColumn}{'column'}, "INCONC", $format_Inconc );
        $worksheet->write_comment( $row, $localRuntimeHeader_href->{$runtimeColumn}{'column'}, "Error during evaluation", width => 250, height => 24 );
    }

    # enter all missing extended runtime labels
    foreach my $extendedRuntimeColumn ( keys %$localExtRuntimeHeader_href ) {
        $worksheet->write( $row, $localExtRuntimeHeader_href->{$extendedRuntimeColumn}{'column'}, "INCONC", $format_Inconc );
        $worksheet->write_comment( $row, $localExtRuntimeHeader_href->{$extendedRuntimeColumn}{'column'}, "Error during evaluation", width => 250, height => 24 );
    }

    return 1;
}

sub WsDeploymentReport_perCrashPdLabelBeforeCrash {
    my $worksheet   = shift;
    my $row         = shift;
    my $crash       = shift;
    my $header_href = shift;

    my $localPdLabelBeforeCrashHeader_href = clone $header_href->{'pdLabelBeforeCrash'};

    # check all extended runtime labels from xml
    for my $pdLabelBeforeCrashNode ( $crash->findnodes("PdLabelValuesBeforeCrash") ) {
        $worksheet->write( $row, $localPdLabelBeforeCrashHeader_href->{ $pdLabelBeforeCrashNode->getAttribute('Name') }{'column'}, $pdLabelBeforeCrashNode->getAttribute('Value') );

        delete $localPdLabelBeforeCrashHeader_href->{ $pdLabelBeforeCrashNode->getAttribute('Name') };
    }

    # enter all missing extended runtime labels
    foreach my $pdLabelBeforeCrashColumn ( keys %$localPdLabelBeforeCrashHeader_href ) {
        $worksheet->write( $row, $localPdLabelBeforeCrashHeader_href->{$pdLabelBeforeCrashColumn}{'column'}, "---" );
    }

    return 1;
}

sub WsDeploymentReport_perCrashPdLabelAfterCrash {
    my $worksheet   = shift;
    my $row         = shift;
    my $crash       = shift;
    my $header_href = shift;

    my $localPdLabelAfterCrashHeader_href = clone $header_href->{'pdLabelAfterCrash'};

    # check all extended runtime labels from xml
    for my $pdLabelAfterCrashNode ( $crash->findnodes("PdLabelValuesAfterCrash") ) {
        $worksheet->write( $row, $localPdLabelAfterCrashHeader_href->{ $pdLabelAfterCrashNode->getAttribute('Name') }{'column'}, $pdLabelAfterCrashNode->getAttribute('Value') );

        delete $localPdLabelAfterCrashHeader_href->{ $pdLabelAfterCrashNode->getAttribute('Name') };
    }

    # enter all missing extended runtime labels
    foreach my $pdLabelAfterCrashColumn ( keys %$localPdLabelAfterCrashHeader_href ) {
        $worksheet->write( $row, $localPdLabelAfterCrashHeader_href->{$pdLabelAfterCrashColumn}{'column'}, "---" );
    }

    return 1;
}

sub WsDeploymentReport_perCrashEdr {
    my $worksheet             = shift;
    my $row                   = shift;
    my $crash                 = shift;
    my $header_href           = shift;
    my $edrCompletenessResult = shift;

    my $localEdrHeader_href        = clone $header_href->{'edr'};
    my $localEdrCompletenessResult = 1;

    # check all extended runtime labels from xml
    for my $edrNode ( $crash->findnodes("EDR") ) {
        if ( $edrNode->getAttribute('Verdict') eq "FAIL" ) {
            $localEdrCompletenessResult = 0;
            $worksheet->write( $row, $localEdrHeader_href->{ $edrNode->getAttribute('Name') }{'column'}, $edrNode->getAttribute('Value'), $format_noDeployment );
            $worksheet->write_comment( $row, $localEdrHeader_href->{ $edrNode->getAttribute('Name') }{'column'}, $edrNode->getAttribute('Comment'), width => 250, height => 24 );
        }
        else {
            $worksheet->write( $row, $localEdrHeader_href->{ $edrNode->getAttribute('Name') }{'column'}, $edrNode->getAttribute('Value') );
        }

        delete $localEdrHeader_href->{ $edrNode->getAttribute('Name') };
    }

    $edrCompletenessResult++ unless $localEdrCompletenessResult;

    # enter all missing extended runtime labels
    foreach my $edrColumn ( keys %$localEdrHeader_href ) {
        $worksheet->write( $row, $localEdrHeader_href->{$edrColumn}{'column'}, "INCONC", $format_Inconc );
        $worksheet->write_comment( $row, $localEdrHeader_href->{$edrColumn}{'column'}, "Error during evaluation", width => 250, height => 24 );
    }

    return $edrCompletenessResult;
}

sub WsDeploymentReport_perCrashFaults {
    my $worksheet           = shift;
    my $row                 = shift;
    my $crash               = shift;
    my $header_href         = shift;
    my $faultsOverview_href = shift;

    # collect fault texts for initial faults and additional faults
    my ( $commentHeight, $commentText, @faultsBefore, @faultsAfter, @missingBefore, @missingAfter, @unexpectedBefore, @unexpectedAfter, @additionalAfter, $ecuModeBeforeCrash, $ecuModeAfterCrash, );
    $commentHeight = 56;

    $ecuModeBeforeCrash = 'NA';
    $ecuModeAfterCrash  = 'NA';

    foreach my $ecuModeNode ( $crash->findnodes("EcuModeBeforeCrash") ) {
        $ecuModeBeforeCrash = $ecuModeNode->getAttribute("Value");
    }

    foreach my $ecuModeNode ( $crash->findnodes("EcuModeAfterCrash") ) {
        $ecuModeAfterCrash = $ecuModeNode->getAttribute("Value");
    }

    foreach my $rbFaultNode ( $crash->findnodes("RBFault") ) {
        my $name                   = $rbFaultNode->getAttribute("Name");
        my $aDetectedBeforeCrash   = $rbFaultNode->getAttribute("DetectedBeforeCrash");
        my $aEnvironmentDependent  = $rbFaultNode->getAttribute("EnvironmentDependent");
        my $aGenericBeforeCrash    = $rbFaultNode->getAttribute("GenericBeforeCrash");
        my $aUnexpectedBeforeCrash = $rbFaultNode->getAttribute("UnexpectedBeforeCrash");
        my $aMissingBeforeCrash    = $rbFaultNode->getAttribute("MissingBeforeCrash");
        my $aDetectedAfterCrash    = $rbFaultNode->getAttribute("DetectedAfterCrash");
        my $aSimDeviceDependent    = $rbFaultNode->getAttribute("SimDeviceDependent");
        my $aCrashDependent        = $rbFaultNode->getAttribute("CrashDependent");
        my $aGenericAfterCrash     = $rbFaultNode->getAttribute("GenericAfterCrash");
        my $aUnexpectedAfterCrash  = $rbFaultNode->getAttribute("UnexpectedAfterCrash");
        my $aMissingAfterCrash     = $rbFaultNode->getAttribute("MissingAfterCrash");
        my $aComment               = $rbFaultNode->getAttribute("Comment");

        unless ( exists $faultsOverview_href->{$name} ) {
            $faultsOverview_href->{$name} = {
                EnvironmentDependent => 0,
                GenericBeforeCrash   => 0,
                CrashDependent       => 0,
                GenericAfterCrash    => 0,
                SimDeviceDependent   => 0,
                Comment              => '---',
                Result               => 'not set',
            };
        }

        unless ( $faultsOverview_href->{$name}{Result} eq "problem" ) {
            if ( $name eq "NoFault" ) {
                $faultsOverview_href->{$name}{Result} = "expected";
            }
            elsif ( $name eq "Error" ) {
                $faultsOverview_href->{$name}{Result} = "problem";
            }
            elsif ( $aUnexpectedBeforeCrash or $aMissingBeforeCrash or $aUnexpectedAfterCrash or $aMissingAfterCrash ) {
                $faultsOverview_href->{$name}{Result} = "problem";
            }
            elsif ( $aDetectedBeforeCrash and $aEnvironmentDependent ) {
                $faultsOverview_href->{$name}{Result} = "expected";
                $faultsOverview_href->{$name}{Comment} = $aComment if defined $aComment;
            }
            elsif ( $aDetectedAfterCrash and $aSimDeviceDependent ) {
                $faultsOverview_href->{$name}{Result} = "expected";
                $faultsOverview_href->{$name}{Comment} = $aComment if defined $aComment;
            }
            elsif ( $aDetectedBeforeCrash and $aGenericBeforeCrash ) {
                $faultsOverview_href->{$name}{Result} = "accepted" unless $faultsOverview_href->{$name}{Result} eq "expected";
                $faultsOverview_href->{$name}{Comment} = $aComment if defined $aComment and not $faultsOverview_href->{$name}{Result} eq "expected";
            }
            elsif ( $aDetectedAfterCrash and ( $aGenericAfterCrash or $aCrashDependent ) ) {
                $faultsOverview_href->{$name}{Result} = "accepted" unless $faultsOverview_href->{$name}{Result} eq "expected";
                $faultsOverview_href->{$name}{Comment} = $aComment if defined $aComment and not $faultsOverview_href->{$name}{Result} eq "expected";
            }
        }

        $faultsOverview_href->{$name}{EnvironmentDependent} = 1 if ( not $faultsOverview_href->{$name}{EnvironmentDependent} and $aEnvironmentDependent );
        $faultsOverview_href->{$name}{GenericBeforeCrash}   = 1 if ( not $faultsOverview_href->{$name}{GenericBeforeCrash}   and $aGenericBeforeCrash );
        $faultsOverview_href->{$name}{CrashDependent}       = 1 if ( not $faultsOverview_href->{$name}{CrashDependent}       and $aCrashDependent );
        $faultsOverview_href->{$name}{GenericAfterCrash}    = 1 if ( not $faultsOverview_href->{$name}{GenericAfterCrash}    and $aGenericAfterCrash );
        $faultsOverview_href->{$name}{SimDeviceDependent}   = 1 if ( not $faultsOverview_href->{$name}{SimDeviceDependent}   and $aSimDeviceDependent );

        if ($aDetectedBeforeCrash) {
            push @faultsBefore, $name;
            $commentHeight += 14;
        }
        if ($aMissingBeforeCrash) {
            push @missingBefore, $name;
        }
        if ($aUnexpectedBeforeCrash) {
            push @unexpectedBefore, $name;
        }
        if ($aDetectedAfterCrash) {
            push @faultsAfter, $name;
        }
        if ($aMissingAfterCrash) {
            push @missingAfter, $name;
        }
        if ($aUnexpectedAfterCrash) {
            push @unexpectedAfter, $name;
        }
        if ( $aDetectedAfterCrash and not $aDetectedBeforeCrash ) {
            push @additionalAfter, $name;
            $commentHeight += 14;
        }
    }

    my $faultsBeforeCommentText    = join( ",\n", @faultsBefore );
    my $additionalAfterCommentText = join( ",\n", @additionalAfter );
    $additionalAfterCommentText = "---\n" unless $additionalAfterCommentText;

    $commentText = "Initial faults before crash injection:\n" . $faultsBeforeCommentText . "\n\nAdditional faults after crash injection:\n" . $additionalAfterCommentText . "\n";

    my $faultsBeforeText     = join( ", ", @faultsBefore );
    my $missingBeforeText    = join( ", ", @missingBefore );
    my $unexpectedBeforeText = join( ", ", @unexpectedBefore );
    my $faultsAfterText      = join( ", ", @faultsAfter );
    my $missingAfterText     = join( ", ", @missingAfter );
    my $unexpectedAfterText  = join( ", ", @unexpectedAfter );
    my $additionalAfterText  = join( ", ", @additionalAfter );

    $missingBeforeText    = "---" unless $missingBeforeText;
    $unexpectedBeforeText = "---" unless $unexpectedBeforeText;
    $missingAfterText     = "---" unless $missingAfterText;
    $unexpectedAfterText  = "---" unless $unexpectedAfterText;
    $additionalAfterText  = "---" unless $additionalAfterText;

    $worksheet->write_string( $row, $header_href->{'faults'}{'before_ecu_mode'}{'column'}, $ecuModeBeforeCrash );
    $worksheet->write_string( $row, $header_href->{'faults'}{'before_detected'}{'column'}, $faultsBeforeText );
    $worksheet->write_comment( $row, $header_href->{'faults'}{'before_detected'}{'column'}, $commentText, width => 250, height => $commentHeight );
    $worksheet->write_string( $row, $header_href->{'faults'}{'before_unexpected'}{'column'}, $unexpectedBeforeText, $format_noDeployment ) if @unexpectedBefore;
    $worksheet->write_string( $row, $header_href->{'faults'}{'before_unexpected'}{'column'}, $unexpectedBeforeText ) unless @unexpectedBefore;
    $worksheet->write_string( $row, $header_href->{'faults'}{'before_missing'}{'column'}, $missingBeforeText, $format_noDeployment ) if @missingBefore;
    $worksheet->write_string( $row, $header_href->{'faults'}{'before_missing'}{'column'}, $missingBeforeText ) unless @missingBefore;
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_ecu_mode'}{'column'}, $ecuModeAfterCrash );
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_detected'}{'column'}, $faultsAfterText );
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_additional'}{'column'}, $additionalAfterText );
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_unexpected'}{'column'}, $unexpectedAfterText, $format_noDeployment ) if @unexpectedAfter;
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_unexpected'}{'column'}, $unexpectedAfterText, ) unless @unexpectedAfter;
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_missing'}{'column'}, $missingAfterText, $format_noDeployment ) if @missingAfter;
    $worksheet->write_string( $row, $header_href->{'faults'}{'after_missing'}{'column'}, $missingAfterText, ) unless @missingAfter;

    return $faultsOverview_href;
}

sub WsDeploymentReport_Crashes {
    my $workbook            = shift;
    my $worksheet           = shift;
    my $row                 = shift;
    my $xpc                 = shift;
    my $header_href         = shift;
    my $faultsOverview_href = shift;

    my $crashLinks_href;
    my $edrCompletenessResult = 0;
    my $initialRow            = $row;

    for my $crash ( $xpc->findnodes("//Crash") ) {

        $worksheet->set_row( $row, 15 );

        my $text = $crash->getAttribute('id') . " Crash: " . $crash->getAttribute('name') . " State: " . $crash->getAttribute('envstate') . " Iteration: " . $crash->getAttribute('iteration');

        my $testListNbr = $crash->getAttribute('tcNumber');
        $testListNbr .= "_" . $crash->getAttribute('tcRepetition') if $crash->getAttribute('tcRepetition');

        $worksheet->write( $row, 0, $testListNbr . " ", $format_text );
        $worksheet->write( $row, 1, $crash->getAttribute('tcModule') );
        $worksheet->write( $row, 2, $crash->getAttribute('id') );
        $worksheet->write( $row, 3, $crash->getAttribute('name') );
        $worksheet->write( $row, 4, $crash->getAttribute('envstate') );
        $worksheet->write( $row, 5, $crash->getAttribute('iteration') );
        $worksheet->write( $row, 6, $crash->getAttribute('channel_assignment') );

        $worksheet->write( $row, 7, "HTML" );
        $worksheet->write_url( $row, 7, $crash->getAttribute('hreftestcase'), $format_url, "HTML" );

        $worksheet->write( $row, 8, "Folder" );
        $worksheet->write_url( $row, 8, $crash->getAttribute('folder'), $format_url, "Folder" );

        unless ( exists $crashLinks_href->{ $crash->getAttribute('tcNumber') } ) {
            my $linkText = 'internal:DeploymentReport!';
            $linkText .= xl_rowcol_to_cell( $row, 0 );
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'link'}              = $linkText;
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'CrashName'}         = $crash->getAttribute('name');
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'AssignmentComment'} = $crash->getAttribute('channel_assignment');
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'Comment'}           = $crash->getAttribute('comment');
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'EnvState'}          = $crash->getAttribute('envstate');
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'CrashId'}           = $crash->getAttribute('id');
            $crashLinks_href->{ $crash->getAttribute('tcNumber') }{'TcModule'}          = $crash->getAttribute('tcModule');
        }

        WsDeploymentReport_perCrashDynEnvs( $worksheet, $row, $crash, $header_href );
        WsDeploymentReport_perCrashSimDevs( $worksheet, $row, $crash, $header_href );
        WsDeploymentReport_perCrashRuntime( $worksheet, $row, $crash, $header_href );
        $edrCompletenessResult = WsDeploymentReport_perCrashEdr( $worksheet, $row, $crash, $header_href, $edrCompletenessResult );
        WsDeploymentReport_perCrashPdLabelBeforeCrash( $worksheet, $row, $crash, $header_href );
        WsDeploymentReport_perCrashPdLabelAfterCrash( $worksheet, $row, $crash, $header_href );
        $faultsOverview_href = WsDeploymentReport_perCrashFaults( $worksheet, $row, $crash, $header_href, $faultsOverview_href );

        # add space to column after the last column
        $worksheet->write_string( $row, $header_href->{'comment'}, " " );
        $worksheet->write( $row, $header_href->{'comment'}, $crash->getAttribute('comment') ) if $crash->getAttribute('comment');

        $row++;
    }

    return ( $row, $crashLinks_href, $edrCompletenessResult, $faultsOverview_href );
}

sub WsDeploymentReport_Finalize {
    my $workbook    = shift;
    my $worksheet   = shift;
    my $initialRow  = shift;
    my $actualRow   = shift;
    my $header_href = shift;

    my $last_column = $header_href->{'faults'}{'after_missing'}{'column'};
    $worksheet->set_column( $last_column + 1, $last_column + 1, 35 );

    $worksheet->autofilter( $initialRow - 1, 0, $actualRow, $last_column );    # apply autofilter for full report
    $worksheet->freeze_panes( $initialRow, 6 );                                # Freeze first 10 rows and first column

    AutofitColumns($worksheet);

    # Grouping for all necessary elements
    foreach my $dynamicEnvState ( keys %{ $header_href->{'dynEnv'} } ) {
        AutofitAndGroupColumn( $worksheet, $header_href->{'dynEnv'}{$dynamicEnvState}{'Set'} );
        AutofitAndGroupColumn( $worksheet, $header_href->{'dynEnv'}{$dynamicEnvState}{'Check'} );
    }

    foreach my $simDev ( keys %{ $header_href->{'simDev'} } ) {
        AutofitAndGroupColumn( $worksheet, $header_href->{'simDev'}{$simDev}{'ActualFiringTime_ms'} );
        AutofitAndGroupColumn( $worksheet, $header_href->{'simDev'}{$simDev}{'MaxT_ms'} );
    }

    return 1;
}

sub WsDeploymentSummary_Header {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $column = 0;

    $worksheet->set_column( 0, 3, 5 );

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'Legend', $format1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'Late Deployment', $format_lateDeployment4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'Early Deployment', $format_earlyDeployment4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;
    $worksheet->merge_range( $row, $column, $row, $column + 4, 'Wrong Deployment', $format_wrongDeployment4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'No Deployment', $format_noDeployment4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'Different deviations', $format_Multi );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, 'INCONC', $format_Inconc4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;

    $worksheet->merge_range( $row, $column, $row, $column + 4, "Ignored", $format_Ignored4DS );
    $worksheet->set_row( $row, undef, undef, 0, 1 );
    $row++;
    $worksheet->set_row( $row, undef, undef, 0, 1 );

    # parse the first crash and create the excel header structure
    my ($header_href);

    $worksheet->write( $row, $column++, "      " . "TestList-Number",    $format1_rot90 );
    $worksheet->write( $row, $column++, "      " . "TestCase-Module",    $format1_rot90 );
    $worksheet->write( $row, $column++, "      " . "Crash-Id",           $format1_rot90 );
    $worksheet->write( $row, $column++, "      " . "Crash Name",         $format1_rot90 );
    $worksheet->write( $row, $column++, "      " . "State",              $format1_rot90 );
    $worksheet->write( $row, $column++, "      " . "Assignment Comment", $format1_rot90 );

    for my $settingsNode ( $xpc->findnodes("//Settings") ) {
        for my $simDev ( $settingsNode->findnodes("SimDevice") ) {
            my $simDeviceName = $simDev->getAttribute('Name');
            my $ignored       = $simDev->getAttribute('Ignored');
            $worksheet->write( $row, $column, "      " . $simDeviceName, $format1_rot90 );
            $worksheet->write_comment( $row, $column, "Ignored: $ignored", width => 250, height => 28 ) if defined $ignored;
            $worksheet->set_column( $column, $column, 3 );
            $header_href->{'SimDevs'}{$simDeviceName} = $column;
            $column++;
        }
    }

    $header_href->{'MaxEarly'} = $column;
    $worksheet->write( $row, $column++, "      " . "Max. Early", $format1_rot90 );
    $header_href->{'MaxLate'} = $column;
    $worksheet->write( $row, $column++, "      " . "Max. Late", $format1_rot90 );
    $header_href->{'FailPercent'} = $column;
    $worksheet->write( $row, $column++, "      " . "Nbr Fail / Total", $format1_rot90 );
    $header_href->{'Result'} = $column;
    $worksheet->write( $row, $column++, "      " . "Result", $format1_rot90 );
    $header_href->{'Comment'} = $column;
    $worksheet->write( $row++, $column++, "      " . "Comment", $format1_rot90 );

    return ( $row, $header_href );
}

sub WsDeploymentSummary_perCrashOverview {
    my $testListNbr = shift;
    my $xpc         = shift;
    my $header_href = shift;

    my $perCrashOverview_href;
    $perCrashOverview_href->{'IterationValidCount'}         = 0;
    $perCrashOverview_href->{'IterationStatusInvalidCount'} = 0;
    $perCrashOverview_href->{'Max_Early_ms'}                = 0;
    $perCrashOverview_href->{'Max_Late_ms'}                 = 0;

    foreach my $crashIteration ( $xpc->findnodes("//Crash[\@tcNumber='$testListNbr']") ) {
        my $iteration              = $crashIteration->getAttribute('iteration');
        my $iteration_valid        = 0;
        my $iteration_status_valid = 1;

        $perCrashOverview_href->{'MaxIteration'} = $iteration;

        my $localHeader_href = clone $header_href->{'SimDevs'};

        for my $simDev ( $crashIteration->findnodes("SimDevice") ) {
            my $simDeviceName = $simDev->getAttribute('Name');
            $iteration_valid = 1;
            delete $localHeader_href->{$simDeviceName};

            $perCrashOverview_href->{$simDeviceName}{'MinT_ms'}    = $simDev->getAttribute('MinT_ms')    unless defined $perCrashOverview_href->{$simDeviceName}{'MinT_ms'};
            $perCrashOverview_href->{$simDeviceName}{'MaxT_ms'}    = $simDev->getAttribute('MaxT_ms')    unless defined $perCrashOverview_href->{$simDeviceName}{'MaxT_ms'};
            $perCrashOverview_href->{$simDeviceName}{'IsDeployed'} = $simDev->getAttribute('IsDeployed') unless defined $perCrashOverview_href->{$simDeviceName}{'IsDeployed'};
            $perCrashOverview_href->{$simDeviceName}{'Iterations'}{$iteration}{'ActualFiringTime_ms'} = $simDev->getAttribute('ActualFiringTime_ms');
            $perCrashOverview_href->{$simDeviceName}{'Iterations'}{$iteration}{'Text'}                = $simDev->getAttribute('Text');
            $perCrashOverview_href->{$simDeviceName}{'Iterations'}{$iteration}{'FiringStatus'}        = $simDev->getAttribute('FiringStatus');

            if ( $simDev->getAttribute('FiringStatus') eq 'Early Deployment' ) {
                my $max_early_ms = $simDev->getAttribute('MinT_ms') - $simDev->getAttribute('ActualFiringTime_ms');
                $perCrashOverview_href->{'Max_Early_ms'} = $max_early_ms if $max_early_ms > $perCrashOverview_href->{'Max_Early_ms'};
                $iteration_status_valid = 0;
            }
            elsif ( $simDev->getAttribute('FiringStatus') eq 'Late Deployment' ) {
                my $max_late_ms = $simDev->getAttribute('ActualFiringTime_ms') - $simDev->getAttribute('MaxT_ms');
                $perCrashOverview_href->{'Max_Late_ms'} = $max_late_ms if $max_late_ms > $perCrashOverview_href->{'Max_Late_ms'};
                $iteration_status_valid = 0;
            }
            elsif ( $simDev->getAttribute('FiringStatus') eq 'Wrong Deployment' or $simDev->getAttribute('FiringStatus') eq 'No Deployment' ) {
                $iteration_status_valid = 0;
            }
            elsif ( $simDev->getAttribute('FiringStatus') eq 'INCONC' ) {
                $iteration_status_valid = 0;
            }
        }

        next unless $iteration_valid;

        foreach my $missingSimDev ( keys %$localHeader_href ) {
            $iteration_status_valid                                                                   = 0;
            $perCrashOverview_href->{$missingSimDev}{'Iterations'}{$iteration}{'FiringStatus'}        = 'INCONC';
            $perCrashOverview_href->{$missingSimDev}{'Iterations'}{$iteration}{'ActualFiringTime_ms'} = "Error during evaluation";
            $perCrashOverview_href->{$missingSimDev}{'Iterations'}{$iteration}{'Text'}                = "NA";
        }
        $perCrashOverview_href->{'IterationValidCount'}++;
        $perCrashOverview_href->{'IterationStatusInvalidCount'}++ unless $iteration_status_valid;
    }

    return $perCrashOverview_href;
}

sub WsDeploymentSummary_Crashes {
    my $workbook        = shift;
    my $worksheet       = shift;
    my $row             = shift;
    my $xpc             = shift;
    my $header_href     = shift;
    my $crashLinks_href = shift;

    my $firstAutoFilterRow = $row - 1;

    foreach my $testListNbr ( sort { $a <=> $b } keys %{$crashLinks_href} ) {
        my $crashId              = $crashLinks_href->{$testListNbr}{'CrashId'};
        my $stateVariationNumber = $crashLinks_href->{$testListNbr}{'EnvState'};
        my $name                 = $crashLinks_href->{$testListNbr}{'CrashName'};
        my $tcModule             = $crashLinks_href->{$testListNbr}{'TcModule'};
        my $text                 = $crashId . " Crash: " . $name . " State: " . $stateVariationNumber;

        $worksheet->write( $row, 0, $testListNbr . " ", $format_text );
        $worksheet->write( $row, 1, $tcModule );
        $worksheet->write( $row, 2, $crashId );
        $worksheet->write( $row, 3, $name );
        $worksheet->write_url( $row, 3, $crashLinks_href->{$testListNbr}{'link'}, $format_url, $name );
        $worksheet->write( $row, 4, $stateVariationNumber );
        $worksheet->write( $row, 5, $crashLinks_href->{$testListNbr}{'AssignmentComment'} );

        my $perCrashOverview_href = WsDeploymentSummary_perCrashOverview( $testListNbr, $xpc, $header_href );

        # analyse all data foreach simDevice
        foreach my $simDev ( keys %{ $header_href->{'SimDevs'} } ) {
            my ( $commentText, $status, $commentHeight );

            $status        = undef;
            $commentHeight = 48;
            $commentText .= "MinT_ms: " . $perCrashOverview_href->{$simDev}{'MinT_ms'} . "ms MaxT_ms: " . $perCrashOverview_href->{$simDev}{'MaxT_ms'} . "ms\n";

            if ( $perCrashOverview_href->{$simDev}{'IsDeployed'} == $CANFIRE_SIMDEVICE ) {
                $commentText .= "PARTIAL DEPLOYMENT\n";
            }

            $commentText .= "\n";

            foreach my $iteration ( 1 .. $perCrashOverview_href->{'MaxIteration'} ) {
                my ( $firing_time, $firingStatus );

                $text         = $perCrashOverview_href->{$simDev}{'Iterations'}{$iteration}{'Text'};
                $firing_time  = $perCrashOverview_href->{$simDev}{'Iterations'}{$iteration}{'ActualFiringTime_ms'};
                $firingStatus = $perCrashOverview_href->{$simDev}{'Iterations'}{$iteration}{'FiringStatus'};

                if ( $firingStatus eq "Ignored" ) {
                    $status = "Ignored";
                    last;
                }
                elsif ( not defined $firingStatus or $firingStatus eq "INCONC" ) {
                    $status = $firingStatus unless ( defined $status );
                    $commentText .= "$iteration: INCONC\n";
                    $commentHeight += 14;
                }
                else {
                    $commentText .= "$iteration: $text | $firing_time\n";

                    if ( not defined $status or $status eq "VALID" or $status eq "INCONC" ) {
                        $status = $firingStatus;
                    }
                    else {
                        $status = "MULTI" if $firingStatus ne "VALID" and not $status eq $firingStatus;
                    }

                    $commentHeight += 14;
                }
            }

            if ( $status eq "Late Deployment" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_lateDeployment4DS );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
            elsif ( $status eq "Early Deployment" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_earlyDeployment4DS );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
            elsif ( $status eq "Wrong Deployment" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_wrongDeployment4DS );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
            elsif ( $status eq "No Deployment" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_noDeployment4DS );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
            elsif ( $status eq "INCONC" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_Inconc4DS );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
            elsif ( $status eq "Ignored" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_Ignored4DS );
            }
            elsif ( $status eq "MULTI" ) {
                $worksheet->write( $row, $header_href->{'SimDevs'}{$simDev}, "", $format_Multi );
                $worksheet->write_comment( $row, $header_href->{'SimDevs'}{$simDev}, $commentText, width => 250, height => $commentHeight );
            }
        }

        $worksheet->write( $row, $header_href->{'MaxEarly'}, $perCrashOverview_href->{'Max_Early_ms'} );
        $worksheet->write( $row, $header_href->{'MaxLate'},  $perCrashOverview_href->{'Max_Late_ms'} );

        my $textFailPercent = $perCrashOverview_href->{'IterationStatusInvalidCount'} . " / " . $perCrashOverview_href->{'IterationValidCount'};
        $worksheet->write( $row, $header_href->{'FailPercent'}, $textFailPercent );

        my $textResult;
        $textResult = "PASS"          if ( $perCrashOverview_href->{'IterationStatusInvalidCount'} == 0 and $perCrashOverview_href->{'IterationValidCount'} > 0 );
        $textResult = "not evaluated" if ( $perCrashOverview_href->{'IterationStatusInvalidCount'} > 0  and $perCrashOverview_href->{'IterationValidCount'} > 0 );
        $textResult = "NA"            if ( $perCrashOverview_href->{'IterationValidCount'} == 0 );

        $worksheet->write( $row, $header_href->{'Result'},  $textResult );
        $worksheet->write( $row, $header_href->{'Comment'}, $crashLinks_href->{$crashId}{$stateVariationNumber}{'Comment'} );
        $worksheet->set_row( $row, undef, $format_RowFaulty ) if ( $perCrashOverview_href->{'IterationValidCount'} == 0 );

        $row++;
    }

    $worksheet->data_validation(
        $firstAutoFilterRow + 1,
        $header_href->{'Result'},
        $row - 1,
        $header_href->{'Result'},
        {
            validate => 'list',
            value    => [ 'PASS', 'PASS w.Com.', 'FAIL', 'not evaluated', 'NA' ],
        }
    );
    $worksheet->conditional_formatting(
        $firstAutoFilterRow + 1,
        $header_href->{'Result'},
        $row - 1,
        $header_href->{'Result'},
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'PASS w.Com.',
            format   => $format_pass_w_com,
        }
    );
    $worksheet->conditional_formatting(
        $firstAutoFilterRow + 1,
        $header_href->{'Result'},
        $row - 1,
        $header_href->{'Result'},
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'PASS',
            format   => $format_pass,
        }
    );
    $worksheet->conditional_formatting(
        $firstAutoFilterRow + 1,
        $header_href->{'Result'},
        $row - 1,
        $header_href->{'Result'},
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'FAIL',
            format   => $format_fail,
        }
    );

    $worksheet->autofilter( $firstAutoFilterRow, 0, $row, $header_href->{'Comment'} );    # apply autofilter for full report
    $worksheet->freeze_panes( $firstAutoFilterRow + 1, 5 );                               # Freeze first 2 rows and first column

    return $row;
}

sub WsStaticEnvStates {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $format_headline          = $workbook->add_format( bold => 1, size => 14, );
    my $format1_leftHeader       = $workbook->add_format( top  => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format1_centerHeader     = $workbook->add_format( top  => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_rightHeader       = $workbook->add_format( top  => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_leftContent       = $workbook->add_format( top  => 1, left => 2, right => 1, bottom => 1, valign => 'top' );
    my $format_centerContent     = $workbook->add_format( top  => 1, left => 1, right => 1, bottom => 1, valign => 'top', text_wrap => 1 );
    my $format_centerContentPass = $workbook->add_format( top  => 1, left => 1, right => 1, bottom => 1, valign => 'top', text_wrap => 1, color => '#006100', bg_color => '#C6EFCE' );
    my $format_centerContentFail = $workbook->add_format( top  => 1, left => 1, right => 1, bottom => 1, valign => 'top', text_wrap => 1, color => '#9C0006', bg_color => '#FFC7CE' );
    my $format_rightContent      = $workbook->add_format( top  => 1, left => 1, right => 2, bottom => 1, valign => 'top', text_wrap => 1 );
    my $format_bottom = $workbook->add_format( top => 2 );
    my $format_Link = $workbook->add_format( color => 'blue', underline => 1 );
    my $column = 1;

    $worksheet->write( $row, $column++, "Static Environment State", $format1_leftHeader );
    $worksheet->write( $row, $column, "value", $format1_centerHeader );
    $worksheet->write_comment( $row, $column++, "Value from input file (*.mdb) or if environment uses source mechanism the value as given by the source (f.e. from crash itself)", width => 350, height => 24 );
    $worksheet->write( $row, $column++, "performed action", $format1_centerHeader );
    $worksheet->write( $row, $column++, "performed checks", $format_rightHeader );

    # write link to the documentation only in first row of the table
    $worksheet->write_url( $row, $column, 'https://inside-docupedia.bosch.com/confluence/display/aeos/StaticEnvStates+-+sheet', $format_Link );
    $worksheet->write( $row++, $column, "?", $format_Link );

    for my $settingsNode ( $xpc->findnodes("//Settings") ) {
        for my $staticEnvState ( $settingsNode->findnodes("StaticEnvironment") ) {
            my $format4value = undef;
            $worksheet->write( $row, 1, $staticEnvState->getAttribute('name'), $format_leftContent );

            my @setTexts   = split( /\|/, $staticEnvState->getAttribute('joinedSetText') );
            my @checkTexts = split( /\|/, $staticEnvState->getAttribute('joinedCheckText') );
            my @verdicts   = split( /\|/, $staticEnvState->getAttribute('joinedVerdict') );

            my @richTextParameters;
            for my $i ( 0 .. $#setTexts ) {

                # add the the rich text list to write it formated
                push( @richTextParameters, $setTexts[$i] );
                push( @richTextParameters, "\n" );

                # write any part to ensure biggest is used for column width
                $worksheet->write( $row, 3, $setTexts[$i], $format_centerContent );
            }
            pop @richTextParameters;    # remove the last /n as it is not needed
            $worksheet->write_rich_string( $row, 3, @richTextParameters, $format_centerContent );

            @richTextParameters = ();
            for my $i ( 0 .. $#checkTexts ) {
                if ( defined $verdicts[$i] and $verdicts[$i] eq "VERDICT_PASS" ) {
                    push( @richTextParameters, $format_text_pass );
                    $format4value = $format_centerContentPass unless defined $format4value;
                }
                elsif ( defined $verdicts[$i] and $verdicts[$i] eq "VERDICT_FAIL" ) {
                    push( @richTextParameters, $format_text_fail );
                    $format4value = $format_centerContentFail;
                }

                push( @richTextParameters, $checkTexts[$i] );
                push( @richTextParameters, "\n" );

                # write any part to ensure biggest is used for column width
                $worksheet->write( $row, 4, $checkTexts[$i], $format_rightContent );
            }

            $format4value = $format_centerContent unless defined $format4value;

            pop @richTextParameters;    # remove the last /n as it is not needed
            $worksheet->write_rich_string( $row, 4, @richTextParameters, $format_rightContent );

            $worksheet->write( $row++, 2, $staticEnvState->getAttribute('value'), $format4value );
        }
    }

    $column = 1;
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row++, $column++, undef, $format_bottom );

    return 1;
}

sub WsChannelAssignmentOverview {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $format_headline      = $workbook->add_format( bold => 1, size => 14, );
    my $format1_leftHeader   = $workbook->add_format( top  => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format1_centerHeader = $workbook->add_format( top  => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_rightHeader   = $workbook->add_format( top  => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_leftContent   = $workbook->add_format( top  => 1, left => 2, right => 1, bottom => 1, );
    my $format_centerContent = $workbook->add_format( top  => 1, left => 1, right => 1, bottom => 1, );
    my $format_rightContent  = $workbook->add_format( top  => 1, left => 1, right => 2, bottom => 1, );
    my $format_bottom = $workbook->add_format( top => 2 );
    my $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    my $column = 1;

    for my $settings ( $xpc->findnodes("//Settings") ) {

        $worksheet->write( $row, $column, 'CRASH_SENSORS', $format_headline );

        # write link to the documentation only in first row of the table
        $worksheet->write_url( $row, $column + 1, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ChannelAssignmentOverview+-+sheet#ChannelAssignmentOverview-sheet-CRASH_SENSORS', $tempFormat );
        $worksheet->write( $row++, $column + 1, "?", $tempFormat );
        $row++;
        $worksheet->write( $row,   $column++, 'MDS channel',              $format1_leftHeader );
        $worksheet->write( $row,   $column++, 'Device name',              $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'QuaTe index',              $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'Device index',             $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'Channel index',            $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'Channel name',             $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'ROM file',                 $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'Quate device description', $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'Firmware',                 $format1_centerHeader );
        $worksheet->write( $row,   $column++, 'ChipSelect',               $format1_centerHeader );
        $worksheet->write( $row++, $column++, 'Port',                     $format_rightHeader );

        for my $crashSensorChannel ( $settings->findnodes("CRASH_SENSOR") ) {
            $column = 1;
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('MDS_channel'),            $format_leftContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('DeviceName'),             $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('QuaTeIndex'),             $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('DeviceIndex'),            $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('ChannelIndex'),           $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('ChannelName'),            $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('RomFile'),                $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('QuateDeviceDescription'), $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('Firmware'),               $format_centerContent );
            $worksheet->write( $row,   $column++, $crashSensorChannel->getAttribute('ChipSelect'),             $format_centerContent );
            $worksheet->write( $row++, $column++, $crashSensorChannel->getAttribute('Port'),                   $format_rightContent );

        }

        $column = 1;
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row++, $column++, undef, $format_bottom );

        # 'NETWORK_DYNAMIC', [ 'MDS channel', 'Frame/PDU', 'Signal' ]
        $column = 1;
        $worksheet->write( $row, $column, 'NETWORK_DYNAMIC', $format_headline );

        # write link to the documentation only in first row of the table
        $worksheet->write_url( $row, $column + 1, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ChannelAssignmentOverview+-+sheet#ChannelAssignmentOverview-sheet-NETWORK_DYNAMIC', $tempFormat );
        $worksheet->write( $row++, $column + 1, "?", $tempFormat );
        $row++;
        $worksheet->write( $row,   $column++, 'MDS channel', $format1_leftHeader );
        $worksheet->write( $row,   $column++, 'Frame/PDU',   $format1_centerHeader );
        $worksheet->write( $row++, $column++, 'Signal',      $format_rightHeader );

        for my $netDynamicChannel ( $settings->findnodes("NETWORK_DYNAMIC") ) {
            $column = 1;
            $worksheet->write( $row,   $column++, $netDynamicChannel->getAttribute('MDS_channel'), $format_leftContent );
            $worksheet->write( $row,   $column++, $netDynamicChannel->getAttribute('Frame'),       $format_centerContent );
            $worksheet->write( $row++, $column++, $netDynamicChannel->getAttribute('Signal'),      $format_rightContent );

        }

        $column = 1;
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row,   $column++, undef, $format_bottom );
        $worksheet->write( $row++, $column++, undef, $format_bottom );
    }

    return ($row);
}

sub WsAlgoIdCheck {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $tempFormat;
    my $format_leftHeader   = $workbook->add_format( top => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_centerHeader = $workbook->add_format( top => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_rightHeader  = $workbook->add_format( top => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_bottom       = $workbook->add_format( top => 2 );
    my $result              = "NA";
    my $collectedAlgoIds_href;

    for my $collectedAlgoIDs ( $xpc->findnodes("//CollectedAlgoIDs") ) {
        for my $algoID ( $collectedAlgoIDs->findnodes("AlgoID") ) {

            my $type = 'optional';
            $type = 'mandatory' if $algoID->getAttribute('isRequired') == 1;
            my $name = $algoID->getAttribute('name');
            $collectedAlgoIds_href->{$type}{$name}{VERDICT}   = $algoID->getAttribute('VERDICT');
            $collectedAlgoIds_href->{$type}{$name}{value_MDS} = $algoID->getAttribute('value_MDS');
            $collectedAlgoIds_href->{$type}{$name}{value_ECU} = $algoID->getAttribute('value_ECU');
        }
    }

    my $column = 1;

    $worksheet->write( $row, $column++, "Mandatory AlgoID", $format_leftHeader );
    $worksheet->write( $row, $column++, "MDS",              $format_centerHeader );
    $worksheet->write( $row, $column++, "ECU",              $format_centerHeader );
    $worksheet->write( $row, $column++, "VERDICT",          $format_rightHeader );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, $column, 'https://inside-docupedia.bosch.com/confluence/display/aeos/AlgoIdCheck+-+sheet#AlgoIdCheck-sheet-MandatoryAlgo-Ids', $tempFormat );
    $worksheet->write( $row++, $column, "?", $tempFormat );

    foreach my $mandatoryAlgoId ( sort keys %{ $collectedAlgoIds_href->{mandatory} } ) {
        my ($verdictColor);

        $verdictColor = "green" if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "PASS";
        $verdictColor = "red"   if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "FAIL";
        $verdictColor = "blue"  if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "NOT TESTED";

        $column = 1;

        $tempFormat = $workbook->add_format(
            top    => 1,
            left   => 2,
            right  => 1,
            bottom => 1,
        );
        $worksheet->write( $row, $column++, $mandatoryAlgoId, $tempFormat );
        $tempFormat = $workbook->add_format(
            top    => 1,
            left   => 1,
            right  => 1,
            bottom => 1,
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{value_MDS}, $tempFormat );
        $tempFormat = $workbook->add_format(
            top    => 1,
            left   => 1,
            right  => 1,
            bottom => 1,
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{value_ECU}, $tempFormat );
        $tempFormat = $workbook->add_format(
            top    => 1,
            left   => 1,
            right  => 2,
            bottom => 1,
            color  => $verdictColor,
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT}, $tempFormat );

        $result = "PASS" if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "PASS" and $result eq "NA";
        $result = "NOT COMPLETED" if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "NOT TESTED" and ( $result eq "NA" or $result eq "PASS" );
        $result = "FAIL" if $collectedAlgoIds_href->{mandatory}{$mandatoryAlgoId}{VERDICT} eq "FAIL";

        $row++;
    }

    $column = 1;
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row++, $column++, undef, $format_bottom );

    $column = 1;
    $worksheet->write( $row, $column++, "Optional AlgoID", $format_leftHeader );
    $worksheet->write( $row, $column++, "MDS",             $format_centerHeader );
    $worksheet->write( $row, $column++, "ECU",             $format_centerHeader );
    $worksheet->write( $row, $column++, "VERDICT",         $format_rightHeader );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, $column, 'https://inside-docupedia.bosch.com/confluence/display/aeos/AlgoIdCheck+-+sheet#AlgoIdCheck-sheet-OptionalAlgo-Ids', $tempFormat );
    $worksheet->write( $row++, $column, "?", $tempFormat );

    foreach my $optionalAlgoId ( sort keys %{ $collectedAlgoIds_href->{optional} } ) {
        my ( $color, $verdictColor );

        $color = '#D9D9D9';

        $verdictColor = "green" if $collectedAlgoIds_href->{optional}{$optionalAlgoId}{VERDICT} eq "PASS";
        $verdictColor = "red"   if $collectedAlgoIds_href->{optional}{$optionalAlgoId}{VERDICT} eq "FAIL";
        $verdictColor = "blue"  if $collectedAlgoIds_href->{optional}{$optionalAlgoId}{VERDICT} eq "NOT TESTED";

        $column     = 1;
        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 2,
            right    => 1,
            bottom   => 1,
            bg_color => $color
        );
        $worksheet->write( $row, $column++, $optionalAlgoId, $tempFormat );
        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 1,
            right    => 1,
            bottom   => 1,
            bg_color => $color
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{optional}{$optionalAlgoId}{value_MDS}, $tempFormat );
        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 1,
            right    => 1,
            bottom   => 1,
            bg_color => $color
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{optional}{$optionalAlgoId}{value_ECU}, $tempFormat );
        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 1,
            right    => 2,
            bottom   => 1,
            bg_color => $color,
            color    => $verdictColor,
        );
        $worksheet->write( $row, $column++, $collectedAlgoIds_href->{optional}{$optionalAlgoId}{VERDICT}, $tempFormat );

        $row++;
    }

    $column = 1;
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row,   $column++, undef, $format_bottom );
    $worksheet->write( $row++, $column++, undef, $format_bottom );

    return ( $row, $result );
}

sub WsProjectData_GeneralPart {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $tempFormat;
    my $formatHeadline = $workbook->add_format( bold => 1, border => 2, size => 20 );

    my $header_left_href = {
        1 => {
            "xmlName" => "ProjectDescription",
            "Text"    => "Project Description:",
        },
        2 => {
            "xmlName" => "ECU_fingerprint",
            "Text"    => "HW-Fingerprint:",
        },
        3 => {
            "xmlName" => "TT_No",
            "Text"    => "TT-Number:",
        },
        4 => {
            "xmlName" => "HW_ver",
            "Text"    => "HW-Version:",
        },
        5 => {
            "xmlName" => "HW_serNo",
            "Text"    => "HW-Serial-Number:",
        },
        6 => {
            "xmlName" => "ECU_SW_VERSION",
            "Text"    => "SW-Version:",
        },
        7 => {
            "xmlName" => "ECU_AlgoParameter_ID",
            "Text"    => "Algo-Parameter-ID:",
        },
        8 => {},
        9 => {
            "xmlName" => "MDSResult",
            "Text"    => "CREIS input file:",
        },
    };
    my $header_right_href = {
        1 => {
            "xmlName" => "start_date",
            "Text"    => "Start Date:",
        },
        2 => {
            "xmlName" => "start_time",
            "Text"    => "Start Time:",
        },
        3 => {
            "xmlName" => "hostname",
            "Text"    => "Hostname:",
        },
        4 => {
            "xmlName" => "username",
            "Text"    => "Username:",
        },
        5 => {},
        6 => {
            "xmlName" => "LIFT_version",
            "Text"    => "LIFT Version:",
        },
        7 => {
            "xmlName" => "LIFT_exec_engine",
            "Text"    => "LIFT Exec Engine:",
        },
        8 => {
            "xmlName" => "configuration",
            "Text"    => "LIFT Configuration:",
        },
        9 => {
            "xmlName" => "testlist",
            "Text"    => "LIFT Testlist:",
        },
    };

    $worksheet->merge_range( $row, 1, $row, 5, "Deployment time test", $formatHeadline );

    $row++;

    $tempFormat = $workbook->add_format( bottom => 2, );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row,   2, undef, $tempFormat );
    $worksheet->write( $row,   4, undef, $tempFormat );
    $worksheet->write( $row++, 5, undef, $tempFormat );

    for my $ecuIdentification ( $xpc->findnodes("//ECU_Identification") ) {
        foreach my $line ( sort { $a <=> $b } keys %$header_left_href ) {

            my $text;
            my $content;

            $text = $header_left_href->{$line}{Text} if exists $header_left_href->{$line}{Text};
            $content = $ecuIdentification->getAttribute( $header_left_href->{$line}{xmlName} ) if exists $header_left_href->{$line}{xmlName};

            $tempFormat = $workbook->add_format(
                top      => 1,
                left     => 2,
                right    => 1,
                bottom   => 1,
                bold     => 1,
                bg_color => '#C0C0C0'
            );
            $worksheet->write( $row, 1, $text, $tempFormat );

            $tempFormat = $workbook->add_format(
                top    => 1,
                left   => 1,
                right  => 2,
                bottom => 1,
            );
            $worksheet->write( $row, 2, $content, $tempFormat );

            # write link to the documentation only in first row of the table
            if ( $line == 1 ) {
                $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
                $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-GeneralInformation', $tempFormat );
                $worksheet->write( $row, 3, "?", $tempFormat );
            }

            $text    = "";
            $content = "";

            $text = $header_right_href->{$line}{Text} if exists $header_right_href->{$line}{Text};
            $content = $ecuIdentification->getAttribute( $header_right_href->{$line}{xmlName} ) if exists $header_right_href->{$line}{xmlName};

            $tempFormat = $workbook->add_format(
                top      => 1,
                left     => 2,
                right    => 1,
                bottom   => 1,
                bold     => 1,
                bg_color => '#C0C0C0'
            );
            $worksheet->write( $row, 4, $text, $tempFormat );

            $tempFormat = $workbook->add_format(
                top    => 1,
                left   => 1,
                right  => 2,
                bottom => 1,
            );
            $worksheet->write( $row++, 5, $content, $tempFormat );
        }
    }

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );
    $worksheet->write( $row, 4, undef, $tempFormat );
    $worksheet->write( $row, 5, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_RuntimeMeasurement {
    my $workbook                     = shift;
    my $worksheet                    = shift;
    my $row                          = shift;
    my $header_href                  = shift;
    my $formulaStartDeploymentReport = shift;
    my $formulaEndDeploymentReport   = shift;

    my $format_left = $workbook->add_format( top => 1, left => 2, right => 1, bottom => 1, bold => 1, bg_color => '#C0C0C0' );
    my $format_right = $workbook->add_format( top => 1, left => 1, right => 2, bottom => 1, align => 'left' );

    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 2,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );

    $worksheet->merge_range( $row, 1, $row, 2, "Runtime measurement results:", $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-Runtimesummary', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );
    $row++;

    foreach my $runtime ( sort keys %{ $header_href->{'runtime'} } ) {
        $worksheet->write( $row, 1, "MAX(" . $runtime . ")", $format_left );
        my $formula = "=MAX(DeploymentReport!" . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'runtime'}{$runtime}{'column'} ) . ":" . xl_rowcol_to_cell( $formulaEndDeploymentReport, $header_href->{'runtime'}{$runtime}{'column'} ) . ")";
        $formula = "-" if $header_href->{'runtime'}{$runtime}{'pdVariable'} eq 'NA';
        $worksheet->write( $row++, 2, $formula, $format_right );
    }

    foreach my $extRuntime ( sort keys %{ $header_href->{'extRuntime'} } ) {
        next if $extRuntime eq "PdGapRate";
        $worksheet->write( $row, 1, "MAX(" . $extRuntime . ")", $format_left );
        my $formula = "=MAX(DeploymentReport!" . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'extRuntime'}{$extRuntime}{'column'} ) . ":" . xl_rowcol_to_cell( $formulaEndDeploymentReport, $header_href->{'extRuntime'}{$extRuntime}{'column'} ) . ")";
        $formula = "-" if $header_href->{'extRuntime'}{$extRuntime}{'pdVariable'} eq 'NA';
        $worksheet->write( $row++, 2, $formula, $format_right );
    }

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsFaultsOverview {
    my $xpc                          = shift;
    my $workbook                     = shift;
    my $worksheet                    = shift;
    my $faultsOverview_href          = shift;
    my $header_href                  = shift;
    my $formulaStartDeploymentReport = shift;
    my $formulaEndDeploymentReport   = shift;

    # get Settings for RbFaultEvaluation
    my $rbFaultEvaluation = 0;

    for my $settingsNode ( $xpc->findnodes("//Settings") ) {
        for my $rbFaultEvaluationNode ( $settingsNode->findnodes("RbFaultEvaluation") ) {
            $rbFaultEvaluation = $rbFaultEvaluationNode->getAttribute('EvaluateRbFaults');
        }
    }
    my $row = 1;
    my ( $start_row, $last_row );

    my $format_Header                   = $workbook->add_format( valign => 'vcenter', align    => 'center', top => 2, left => 2, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_beforeCrash_leftHeader   = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );
    my $format_beforeCrash_centerHeader = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );
    my $format_beforeCrash_rightHeader  = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#DDD9C4', text_wrap => 1 );
    my $format_afterCrash_leftHeader    = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 2, right => 1, bottom => 2, bold => 1, bg_color => '#DCE6F1', text_wrap => 1 );
    my $format_afterCrash_centerHeader  = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 1, bottom => 2, bold => 1, bg_color => '#DCE6F1', text_wrap => 1 );
    my $format_afterCrash_rightHeader   = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 1, right => 2, bottom => 2, bold => 1, bg_color => '#DCE6F1', text_wrap => 1 );
    my $format_Header2                  = $workbook->add_format( align  => 'center',  rotation => 90,       top => 2, left => 2, right => 2, bottom => 2, bold => 1, bg_color => '#C0C0C0' );
    my $format_Content       = $workbook->add_format( top => 1, left => 2, right => 2, bottom => 1, );
    my $format_leftContent   = $workbook->add_format( top => 1, left => 2, right => 1, bottom => 1, );
    my $format_centerContent = $workbook->add_format( top => 1, left => 1, right => 1, bottom => 1, );
    my $format_rightContent  = $workbook->add_format( top => 1, left => 1, right => 2, bottom => 1, );
    my $format_bottom        = $workbook->add_format( top => 2 );
    my $format_greenHighlight = $workbook->add_format( bg_color => '#EBF1DE' );
    my $format_whiteText      = $workbook->add_format( color    => 'white' );

    $worksheet->write( $row, 2, "Before" );
    $worksheet->write( $row, 3, "Before" );
    $worksheet->write( $row, 4, "Before" );
    $worksheet->merge_range( $row, 2, $row, 4, "Before", $format_Header );

    $worksheet->write( $row, 5, "After" );
    $worksheet->write( $row, 6, "After" );
    $worksheet->write( $row, 7, "After" );
    $worksheet->merge_range( $row, 5, $row, 8, "After", $format_Header );

    $worksheet->write( $row, 9,  "Expectation" );
    $worksheet->write( $row, 10, "Expectation" );
    $worksheet->write( $row, 11, "Expectation" );
    $worksheet->write( $row, 12, "Expectation" );
    $worksheet->write( $row, 13, "Expectation" );
    $worksheet->merge_range( $row, 9, $row, 13, "Expectation", $format_Header );
    $row++;

    $worksheet->write( $row,   1,  "RB Faults",                                      $format_Header2 );
    $worksheet->write( $row,   2,  "Detected",                                       $format_beforeCrash_leftHeader );
    $worksheet->write( $row,   3,  "Unexpected",                                     $format_beforeCrash_centerHeader );
    $worksheet->write( $row,   4,  "Missing",                                        $format_beforeCrash_rightHeader );
    $worksheet->write( $row,   5,  "Detected",                                       $format_afterCrash_leftHeader );
    $worksheet->write( $row,   6,  "Additional",                                     $format_afterCrash_centerHeader );
    $worksheet->write( $row,   7,  "Unexpected",                                     $format_afterCrash_centerHeader );
    $worksheet->write( $row,   8,  "Missing",                                        $format_afterCrash_rightHeader );
    $worksheet->write( $row,   9,  "GenericBeforeCrash\n(optional before crash)",    $format_beforeCrash_leftHeader );
    $worksheet->write( $row,   10, "EnvironmentDependent\n(mandatory before crash)", $format_beforeCrash_rightHeader );
    $worksheet->write( $row,   11, "GenericAfterCrash\n(optional after crash)",      $format_afterCrash_leftHeader );
    $worksheet->write( $row,   12, "SimDeviceDependent\n(mandatory after crash)",    $format_afterCrash_centerHeader );
    $worksheet->write( $row,   13, "CrashDependent\n(optional after crash)",         $format_afterCrash_rightHeader );
    $worksheet->write( $row,   14, "Result",                                         $format_Header2 );
    $worksheet->write( $row++, 15, "Comment",                                        $format_Header2 );
    $start_row = $row;

    AutofitStartStoringStringWidths($worksheet);

    foreach my $fault ( sort keys %$faultsOverview_href ) {
        $last_row = $row;
        $worksheet->write( $row, 1, $fault, $format_Content );
        my $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'before_detected'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'before_detected'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 2, $formula, $format_leftContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'before_unexpected'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'before_unexpected'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 3, $formula, $format_centerContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'before_missing'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'before_missing'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 4, $formula, $format_rightContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'after_detected'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'after_detected'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 5, $formula, $format_leftContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'after_additional'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'after_additional'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 6, $formula, $format_centerContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'after_unexpected'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'after_unexpected'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 7, $formula, $format_centerContent );
        $formula =
            "=COUNTIF(DeploymentReport!"
          . xl_rowcol_to_cell( $formulaStartDeploymentReport, $header_href->{'faults'}{'after_missing'}{'column'} ) . ":"
          . xl_rowcol_to_cell( $formulaEndDeploymentReport,   $header_href->{'faults'}{'after_missing'}{'column'} )
          . ",\"*\"&"
          . xl_rowcol_to_cell( $row, 1 )
          . "&\"*\")";
        $worksheet->write( $row, 8, $formula, $format_rightContent );

        $formula = "=FALSE()";
        $formula = "=TRUE()" if $faultsOverview_href->{$fault}{GenericBeforeCrash};
        $worksheet->write( $row, 9, $formula, $format_leftContent );
        $formula = "=FALSE()";
        $formula = "=TRUE()" if $faultsOverview_href->{$fault}{EnvironmentDependent};
        $worksheet->write( $row, 10, $formula, $format_rightContent );
        $formula = "=FALSE()";
        $formula = "=TRUE()" if $faultsOverview_href->{$fault}{GenericAfterCrash};
        $worksheet->write( $row, 11, $formula, $format_leftContent );
        $formula = "=FALSE()";
        $formula = "=TRUE()" if $faultsOverview_href->{$fault}{SimDeviceDependent};
        $worksheet->write( $row, 12, $formula, $format_centerContent );
        $formula = "=FALSE()";
        $formula = "=TRUE()" if $faultsOverview_href->{$fault}{CrashDependent};
        $worksheet->write( $row, 13, $formula, $format_rightContent );

        $worksheet->write( $row, 14, $faultsOverview_href->{$fault}{Result}, $format_Content ) if $rbFaultEvaluation;
        $worksheet->write( $row, 14, 'not set', $format_Content ) unless $rbFaultEvaluation;

        $worksheet->write( $row++, 15, $faultsOverview_href->{$fault}{Comment}, $format_Content );
    }

    $worksheet->conditional_formatting(
        $start_row,
        2,
        $last_row,
        8,
        {
            type     => 'cell',
            criteria => '==',
            value    => 0,
            format   => $format_whiteText,
        }
    );

    $worksheet->conditional_formatting(
        $start_row,
        3,
        $last_row,
        4,
        {
            type     => 'cell',
            criteria => '>',
            value    => 0,
            format   => $format_dynEnvFail,
        }
    );

    $worksheet->conditional_formatting(
        $start_row,
        7,
        $last_row,
        8,
        {
            type     => 'cell',
            criteria => '>',
            value    => 0,
            format   => $format_dynEnvFail,
        }
    );

    $worksheet->conditional_formatting(
        $start_row,
        9,
        $last_row,
        13,
        {
            type     => 'formula',
            criteria => 'J4',
            format   => $format_greenHighlight,
        }
    );

    $worksheet->data_validation(
        $start_row,
        14,
        $last_row,
        14,
        {
            validate => 'list',
            value    => [ 'problem', 'accepted', 'expected', 'not set' ],
        }
    );

    $worksheet->conditional_formatting(
        $start_row,
        14,
        $last_row,
        14,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'accepted',
            format   => $format_dynEnvPass,
        }
    );
    $worksheet->conditional_formatting(
        $start_row,
        14,
        $last_row,
        14,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'expected',
            format   => $format_dynEnvPass
        }
    );
    $worksheet->conditional_formatting(
        $start_row,
        14,
        $last_row,
        14,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'problem',
            format   => $format_dynEnvFail,
        }
    );

    $worksheet->write( $row,   1,  undef, $format_bottom );
    $worksheet->write( $row,   2,  undef, $format_bottom );
    $worksheet->write( $row,   3,  undef, $format_bottom );
    $worksheet->write( $row,   4,  undef, $format_bottom );
    $worksheet->write( $row,   5,  undef, $format_bottom );
    $worksheet->write( $row,   6,  undef, $format_bottom );
    $worksheet->write( $row,   7,  undef, $format_bottom );
    $worksheet->write( $row,   8,  undef, $format_bottom );
    $worksheet->write( $row,   9,  undef, $format_bottom );
    $worksheet->write( $row,   10, undef, $format_bottom );
    $worksheet->write( $row,   11, undef, $format_bottom );
    $worksheet->write( $row,   12, undef, $format_bottom );
    $worksheet->write( $row,   13, undef, $format_bottom );
    $worksheet->write( $row,   14, undef, $format_bottom );
    $worksheet->write( $row++, 15, undef, $format_bottom );

    $worksheet->autofilter( $start_row - 1, 1, $last_row, 15 );

    return $rbFaultEvaluation;
}

sub WsProjectData_AlgoIdCheck {
    my $workbook           = shift;
    my $worksheet          = shift;
    my $row                = shift;
    my $result_AlgoIDCheck = shift;

    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Result of AlgoID check:", $tempFormat );

    my $verdictColor = undef;
    $verdictColor = "#00B050" if $result_AlgoIDCheck eq "PASS";
    $verdictColor = "red"     if $result_AlgoIDCheck eq "FAIL";

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 1,
        right    => 2,
        bottom   => 1,
        bg_color => $verdictColor
    );
    $worksheet->write( $row, 2, $result_AlgoIDCheck, $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ResultofAlgoIdcheck', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );
    $row++;

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write_string( $row++, 2, "ParameterTransferIDs are identical between ECU and MDS-simulation.\nNo separate ParameterTransferTest necessary", $tempFormat ) if $result_AlgoIDCheck eq "PASS";
    $worksheet->write_string( $row++, 2, "ParameterTransferIDs are not identical between ECU and MDS-simulation.\nSeparate ParameterTransferTest necessary", $tempFormat ) if $result_AlgoIDCheck eq "FAIL" or $result_AlgoIDCheck eq "NOT COMPLETED";

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_ReleaseIntegrityCheck {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my ( $componentIntegrity, $creisFwVersion );

    my $result_ReleaseIntegrityCheck = "NA";

    for my $releaseStatus ( $xpc->findnodes("//ReleaseStatus") ) {
        $componentIntegrity = $releaseStatus->getAttribute("ComponentIntegrity");
        $creisFwVersion     = $releaseStatus->getAttribute("Version");
    }

    $result_ReleaseIntegrityCheck = "FAIL" if defined $componentIntegrity;
    $result_ReleaseIntegrityCheck = "PASS" if $componentIntegrity;

    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "CREIS_Framework Release:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write_string( $row, 2, $creisFwVersion, $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ReleaseIntegrityCheck', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );
    $row++;

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Result of Release Integrity check:", $tempFormat );

    my $verdictColor = undef;
    $verdictColor = "#00B050" if $result_ReleaseIntegrityCheck eq "PASS";
    $verdictColor = "red"     if $result_ReleaseIntegrityCheck eq "FAIL";

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 1,
        right    => 2,
        bottom   => 1,
        bg_color => $verdictColor
    );
    $worksheet->write( $row++, 2, $result_ReleaseIntegrityCheck, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write( $row++, 2, "Release Integrity check passed - The used Engine and corresponding files of CREIS release are integer.", $tempFormat ) if $result_ReleaseIntegrityCheck eq "PASS";
    $worksheet->write( $row++, 2, "Release Integrity check failed - The used Engine and corresponding files of CREIS release are not integer.", $tempFormat )
      if $result_ReleaseIntegrityCheck eq "FAIL"
      or $result_ReleaseIntegrityCheck eq "NA";

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_FaultsOverview {
    my $workbook          = shift;
    my $worksheet         = shift;
    my $row               = shift;
    my $rbFaultEvaluation = shift;

    return $row unless $rbFaultEvaluation;

    # Result of Deployment behaviour check
    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );

    $worksheet->write( $row, 1, "Result of Fault evaluation:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
    );

    $worksheet->data_validation(
        $row, 2,
        {
            validate => 'list',
            value    => [ 'PASS', 'FAIL', 'NOT SET' ],
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'PASS',
            format   => $format_pass,
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'FAIL',
            format   => $format_fail,
        }
    );

    my $formula = "=IF(COUNTIF(FaultsOverview!O:O,\"problem\"),\"FAIL\",IF(COUNTIF(FaultsOverview!O:O,\"not set\"),\"NOT SET\",\"PASS\"))";
    $worksheet->write_formula( $row, 2, $formula, $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ResultofFaultevaluation', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );
    $row++;

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $formula = "=IF(" . xl_rowcol_to_cell( $row - 1, 2 ) . "=\"NOT SET\",\"Check sheet 'FaultsOverview' and fill result accordingly\",\"Check sheet 'FaultsOverview' for details.\")";
    $worksheet->write_formula( $row++, 2, $formula, $tempFormat );

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_SystemTestEvaluation {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;

    # Result of Deployment behaviour check
    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );

    $worksheet->write( $row, 1, "Result of System Test evaluation:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
    );

    $worksheet->data_validation(
        $row, 2,
        {
            validate => 'list',
            value    => [ 'CHECKED OK', 'CHECKED NOK', 'NOT CHECKED' ],
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'CHECKED OK',
            format   => $format_pass,
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'CHECKED NOK',
            format   => $format_fail,
        }
    );

    $worksheet->write_comment( $row, 1, "" );
    $worksheet->write( $row, 2, "NOT CHECKED", $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ResultofSystemTestevaluation', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );

    # Add a button tied to a macro in the VBA project.
    $worksheet->insert_button(
        $row++,
        4,
        {
            macro   => 'Fill_SysTest',
            caption => 'Fill System Tester',
            width   => 100,
            height  => 30
        }
    );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "System Tester:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
    );

    $workbook->define_name( 'SysTestName', xl_range_formula( "ProjectData", $row, $row, 2, 2 ) );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Date:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
        align  => 'left',
    );
    $workbook->define_name( 'SysTestDate', xl_range_formula( "ProjectData", $row, $row, 2, 2 ) );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_DeploymentBehaviourCheck {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;

    # Result of Deployment behaviour check
    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );

    $worksheet->write( $row, 1, "Result of Deployment behaviour check:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
    );

    $worksheet->data_validation(
        $row, 2,
        {
            validate => 'list',
            value    => [ 'PASS', 'PASS w.Com.', 'FAIL', 'not evaluated' ],
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'PASS w.Com.',
            format   => $format_pass_w_com,
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'PASS',
            format   => $format_pass,
        }
    );
    $worksheet->conditional_formatting(
        $row, 2,
        {
            type     => 'text',
            criteria => 'containing',
            value    => 'FAIL',
            format   => $format_fail,
        }
    );

    # Add a button tied to a macro in the VBA project.
    $worksheet->write( $row, 2, "not evaluated", $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ResultofDeploymentbehaviourcheck', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );

    $worksheet->insert_button(
        $row++,
        4,
        {
            macro   => 'Fill_Appl',
            caption => 'Fill Application Engineer',
            width   => 100,
            height  => 30
        }
    );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Application Engineer:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
    );
    $workbook->define_name( 'ApplName', xl_range_formula( "ProjectData", $row, $row, 2, 2 ) );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Date:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top    => 1,
        left   => 1,
        right  => 2,
        bottom => 1,
        align  => 'left',
    );
    $workbook->define_name( 'ApplDate', xl_range_formula( "ProjectData", $row, $row, 2, 2 ) );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write( $row++, 2, "", $tempFormat );

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

sub WsProjectData_EdrReader {
    my $workbook  = shift;
    my $worksheet = shift;
    my $row       = shift;
    my $xpc       = shift;

    my $edrDefect219169Workaround;

    for my $settingsNode ( $xpc->findnodes("//Settings") ) {
        for my $edr ( $settingsNode->findnodes("EDR") ) {
            next unless $edr->getAttribute('Name') eq 'Defect_219169_workaround';
            $edrDefect219169Workaround = 1;
        }
    }

    if ($edrDefect219169Workaround) {
        my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
        $worksheet->write( $row,   1, undef, $tempFormat );
        $worksheet->write( $row++, 2, undef, $tempFormat );

        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 2,
            right    => 1,
            bottom   => 1,
            bold     => 1,
            bg_color => '#C0C0C0'
        );
        $worksheet->write( $row, 1, "Defect_219169_workaround:", $tempFormat );

        my $verdictColor = "red";

        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 1,
            right    => 2,
            bottom   => 1,
            bg_color => $verdictColor,
        );
        $worksheet->write( $row, 2, "used", $tempFormat );

        # write link to the documentation only in first row of the table
        $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
        $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-Defect_219169_workaround', $tempFormat );
        $worksheet->write( $row, 3, "?", $tempFormat );
        $row++;

        $tempFormat = $workbook->add_format(
            top      => 1,
            left     => 2,
            right    => 1,
            bottom   => 1,
            bold     => 1,
            valign   => 'top',
            bg_color => '#C0C0C0'
        );
        $worksheet->write( $row, 1, "Comment:", $tempFormat );

        $tempFormat = $workbook->add_format(
            top       => 1,
            left      => 1,
            right     => 2,
            bottom    => 1,
            text_wrap => 1,
        );
        $worksheet->write_string( $row++, 2, "Defect_219169_workaround is used. All read EDR records are potentially affected of missing data.", $tempFormat );

        $tempFormat = $workbook->add_format( top => 2, );
        $worksheet->write( $row, 1, undef, $tempFormat );
        $worksheet->write( $row, 2, undef, $tempFormat );
    }

    return ($row);
}

sub WsProjectData_EdrCompletness {
    my $workbook               = shift;
    my $worksheet              = shift;
    my $row                    = shift;
    my $header_href            = shift;
    my $edrCompletenesResult   = shift;
    my $overallCrashIterations = shift;

    my $result = "NOT TESTED";

    if ( %{ $header_href->{'edr'} } ) {
        $result = "PASS";
        $result = "FAIL" if $edrCompletenesResult;
    }

    my $tempFormat = $workbook->add_format( bottom => 2, top => 2 );
    $worksheet->write( $row,   1, undef, $tempFormat );
    $worksheet->write( $row++, 2, undef, $tempFormat );

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Result of EDR completeness check:", $tempFormat );

    my $verdictColor = undef;
    $verdictColor = "#00B050" if $result eq "PASS";
    $verdictColor = "red"     if $result eq "FAIL";
    $verdictColor = "#C0C0C0" if $result eq "NOT TESTED";
    my $color = undef;
    $color = "blue" if $result eq "NOT TESTED";

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 1,
        right    => 2,
        bottom   => 1,
        bg_color => $verdictColor,
        color    => $color,
    );
    $worksheet->write( $row, 2, $result, $tempFormat );

    # write link to the documentation only in first row of the table
    $tempFormat = $workbook->add_format( color => 'blue', underline => 1 );
    $worksheet->write_url( $row, 3, 'https://inside-docupedia.bosch.com/confluence/display/aeos/ProjectData+-+sheet#ProjectData-sheet-ResultofEDRcompletenesscheck', $tempFormat );
    $worksheet->write( $row, 3, "?", $tempFormat );
    $row++;

    $tempFormat = $workbook->add_format(
        top      => 1,
        left     => 2,
        right    => 1,
        bottom   => 1,
        bold     => 1,
        valign   => 'top',
        bg_color => '#C0C0C0'
    );
    $worksheet->write( $row, 1, "Comment:", $tempFormat );

    $tempFormat = $workbook->add_format(
        top       => 1,
        left      => 1,
        right     => 2,
        bottom    => 1,
        text_wrap => 1,
    );
    $worksheet->write_string( $row++, 2, "EDR completeness check passed.",                                                                                                                                                         $tempFormat ) if $result eq "PASS";
    $worksheet->write_string( $row++, 2, "EDR completeness check failed for '$edrCompletenesResult / $overallCrashIterations' crash iterations.\nSystemTester has to check details in sheet 'DeploymentReport' and raise defect.", $tempFormat ) if $result eq "FAIL";
    $worksheet->write_string( $row++, 2, "EDR completeness check was not performed.",                                                                                                                                              $tempFormat ) if $result eq "NOT TESTED";

    $tempFormat = $workbook->add_format( top => 2, );
    $worksheet->write( $row, 1, undef, $tempFormat );
    $worksheet->write( $row, 2, undef, $tempFormat );

    return ($row);
}

###############################################################################
#
# Functions used for Autofit.
#
###############################################################################

sub AutofitStartStoringStringWidths {

    my $worksheet = shift;

    $worksheet->add_write_handler( qr/\w/, \&StoreStringWidths );

    return 1;
}

###############################################################################
#
# Adjust the column widths to fit the longest string in the column.
#
sub AutofitColumns {

    my $worksheet = shift;
    my $col       = 0;

    for my $width ( @{ $worksheet->{__col_widths} } ) {

        $worksheet->set_column( $col, $col, $width ) if $width;
        $col++;
    }

    return 1;
}

sub AutofitAndGroupColumn {

    my $worksheet = shift;
    my $col       = shift;

    $worksheet->set_column( $col, $col, $worksheet->{__col_widths}->[$col], undef, 1, 1 );

    return 1;
}

###############################################################################
#
# The following function is a callback that was added via add_write_handler()
# above. It modifies the write() function so that it stores the maximum
# unwrapped width of a string in a column.
#
sub StoreStringWidths {
    my @args      = @_;
    my $worksheet = shift @args;
    my $col       = $args[1];
    my $token     = $args[2];

    # Ignore some tokens that we aren't interested in.
    return if not defined $token;       # Ignore undefs.
    return if $token eq '';             # Ignore blank cells.
    return if ref $token eq 'ARRAY';    # Ignore array refs.
    return if $token =~ /^=/;           # Ignore formula

    # Ignore numbers
    return if $token =~ /^([+-]?)(?=\d|\.\d)\d*(\.\d*)?([Ee]([+-]?\d+))?$/;

    # Ignore various internal and external hyperlinks. In a real scenario
    # you may wish to track the length of the optional strings used with
    # urls.
    return if $token =~ m{^[fh]tt?ps?://};
    return if $token =~ m{^mailto:};
    return if $token =~ m{^(?:in|ex)ternal:};

    # We store the string width as data in the worksheet_appl object. We use
    # a double underscore key name to avoid conflicts with future names.
    #
    my $old_width    = $worksheet->{__col_widths}->[$col];
    my $string_width = StringWidth($token);

    if ( not defined $old_width or $string_width > $old_width ) {

        # You may wish to set a minimum column width as follows.
        $string_width = 3 if $string_width < 3;

        $worksheet->{__col_widths}->[$col] = $string_width;
    }

    # Return control to write();
    return;
}

###############################################################################
#
# This function uses an external module to get a more accurate width for a
# string.
sub StringWidth {
    my @args = @_;

    my $font_size    = 11;
    my $dpi          = 96;
    my $units_per_em = $calibri->get_units_per_em();
    my $font_width   = $calibri->string_width( $args[0] );

    # Convert to pixels as per TTFMetrics docs.
    my $pixel_width = 6 + $font_width * $font_size * $dpi / ( 72 * $units_per_em );

    # Add extra pixels for border around text.
    $pixel_width += 15;

    # Convert to cell width (for Arial) and for cell widths > 1.
    my $cell_width = ( $pixel_width - 5 ) / 7;

    return $cell_width;

}

1;

__END__
