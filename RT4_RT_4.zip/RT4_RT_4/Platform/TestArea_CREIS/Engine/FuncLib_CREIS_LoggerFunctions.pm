# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

package FuncLib_CREIS_LoggerFunctions;

use strict;
use warnings;
use LIFT_crash_simulation;
use LIFT_general;
use LIFT_MDSRESULT;
use XML::LibXML;
use File::Basename;
use File::Path qw(make_path remove_tree);
use Path::Class;

use Exporter;
our @ISA    = qw(Exporter);
our @EXPORT = qw(
  FLC_LOG_AlgoIds
  FLC_LOG_ChannelAssignmentOverview
  FLC_LOG_CleanStrings
  FLC_LOG_CloseSettingsNode
  FLC_LOG_CompleteCrash
  FLC_LOG_CreateSettingsNode
  FLC_LOG_CreateSimDevHTMLTable
  FLC_LOG_DynamicEnvSettings
  FLC_LOG_EcuMode
  FLC_LOG_EDRSettings
  FLC_LOG_EDRValues
  FLC_LOG_ExtendedRuntimeSettings
  FLC_LOG_ExtendedRuntimeValues
  FLC_LOG_Faults
  FLC_LOG_InitSummaryXMLFile
  FLC_LOG_PdLabelReaderSettings
  FLC_LOG_PdLabelValues
  FLC_LOG_RbFaultEvaluationSettings
  FLC_LOG_ReleaseIntegrityStatus
  FLC_LOG_RuntimeSettings
  FLC_LOG_RuntimeValues
  FLC_LOG_SimDevice
  FLC_LOG_SimDeviceSettings
  FLC_LOG_StaticEnvironments
  FLC_LOG_TcEvent
);

=head1 NAME

FuncLib_CREIS_LoggerFunctions

=head1 SYNOPSIS
    
=head1 DESCRIPTION

=cut

our $summaryXMLFile;
my $oCREISSummaryDoc;
my $rootElement;
my $actualSettingsNode;
my $actualCrashNode;
my $perCrashSimDevices_href;
my $perCrashTcEvents_href;
my $perCrashEdrValues_href;
my $perCrashExtendedRuntime_href;
my $perCrashRuntime_href;
my $perCrashFaults_href;
my $perCrashpdLabels_href;
my $perCrashEcuMode_href;
my $moduleName = __PACKAGE__;

=head CleanStrings

    Function Name    :: CleanStrings
    Description      :: This function replaces german umlauts and cleans all other special signs.

=cut

sub FLC_LOG_CleanStrings {
    my $string = shift;

    $string =~ s/�/ae/g;
    $string =~ s/�/oe/g;
    $string =~ s/�/ue/g;
    $string =~ s/�/Ae/g;
    $string =~ s/�/Oe/g;
    $string =~ s/�/Ue/g;
    $string =~ s/�/ss/g;
    $string =~ s/\W/\_/g;
    $string =~ s/_+/_/g;

    return $string;
}

sub FLC_LOG_AlgoIds {
    my $algoIds_href = shift;

    my $collectedAlgoIdsNode = $oCREISSummaryDoc->createElement("CollectedAlgoIDs");

    foreach my $algoId ( keys %{$algoIds_href} ) {
        next unless $algoIds_href->{$algoId}{isRequired};
        my $algoIDNode = $oCREISSummaryDoc->createElement("AlgoID");
        $algoIDNode->setAttribute( "name",       $algoId );
        $algoIDNode->setAttribute( "value_MDS",  $algoIds_href->{$algoId}{value_MDS} );
        $algoIDNode->setAttribute( "value_ECU",  $algoIds_href->{$algoId}{value_ECU} );
        $algoIDNode->setAttribute( "isRequired", $algoIds_href->{$algoId}{isRequired} );
        $algoIDNode->setAttribute( "VERDICT",    $algoIds_href->{$algoId}{VERDICT} );
        $collectedAlgoIdsNode->appendChild($algoIDNode);
    }
    foreach my $algoId ( keys %{$algoIds_href} ) {
        next if $algoIds_href->{$algoId}{isRequired};
        my $algoIDNode = $oCREISSummaryDoc->createElement("AlgoID");
        $algoIDNode->setAttribute( "name",       $algoId );
        $algoIDNode->setAttribute( "value_MDS",  $algoIds_href->{$algoId}{value_MDS} );
        $algoIDNode->setAttribute( "value_ECU",  $algoIds_href->{$algoId}{value_ECU} );
        $algoIDNode->setAttribute( "isRequired", $algoIds_href->{$algoId}{isRequired} );
        $algoIDNode->setAttribute( "VERDICT",    $algoIds_href->{$algoId}{VERDICT} );
        $collectedAlgoIdsNode->appendChild($algoIDNode);
    }
    $rootElement->appendChild($collectedAlgoIdsNode);

}

sub FLC_LOG_ChannelAssignmentOverview {
    my $channelAssignment_href = CSI_GetChannelAssignmentOverview();

    return 1 unless defined $channelAssignment_href;

    my $sortableChannelAssignment_href;

    foreach my $channel ( sort keys %{ $channelAssignment_href->{'CRASH_SENSORS'} } ) {
        my $quate_index   = sprintf( "%03d", $channelAssignment_href->{'CRASH_SENSORS'}{$channel}{'Quate index'} );
        my $device_index  = sprintf( "%03d", $channelAssignment_href->{'CRASH_SENSORS'}{$channel}{'Device index'} );
        my $channel_index = sprintf( "%03d", $channelAssignment_href->{'CRASH_SENSORS'}{$channel}{'Channel index'} );
        $sortableChannelAssignment_href->{ $quate_index . "_" . $device_index . "_" . $channel_index } = $channelAssignment_href->{'CRASH_SENSORS'}{$channel};
        $sortableChannelAssignment_href->{ $quate_index . "_" . $device_index . "_" . $channel_index }{'MDS channel'} = $channel;
    }

    foreach my $channel ( sort keys %{$sortableChannelAssignment_href} ) {

        my $mds_channel = $sortableChannelAssignment_href->{$channel}{'MDS channel'};
        utf8::upgrade($mds_channel);

        my $device_name = $sortableChannelAssignment_href->{$channel}{'Device name'};
        utf8::upgrade($device_name);

        my $quate_index = $sortableChannelAssignment_href->{$channel}{'Quate index'};
        utf8::upgrade($quate_index);

        my $device_index = $sortableChannelAssignment_href->{$channel}{'Device index'};
        utf8::upgrade($device_index);

        my $channel_index = $sortableChannelAssignment_href->{$channel}{'Channel index'};
        utf8::upgrade($channel_index);

        my $channel_name = $sortableChannelAssignment_href->{$channel}{'Channel name'};
        utf8::upgrade($channel_name);

        my $romFile = $sortableChannelAssignment_href->{$channel}{'ROM file'};
        utf8::upgrade($romFile);

        my $deviceDescription = $sortableChannelAssignment_href->{$channel}{'Quate device description'};
        utf8::upgrade($deviceDescription);

        my $firmware = $sortableChannelAssignment_href->{$channel}{'Firmware'};
        utf8::upgrade($firmware);

        my $chipSelect = "---";
        $chipSelect = $sortableChannelAssignment_href->{$channel}{'Quate chip select'} if defined $sortableChannelAssignment_href->{$channel}{'Quate chip select'};
        utf8::upgrade($chipSelect);

        my $port = "---";
        $port = $sortableChannelAssignment_href->{$channel}{'Quate port'} if defined $sortableChannelAssignment_href->{$channel}{'Quate port'};
        utf8::upgrade($port);

        my $channelNode = $oCREISSummaryDoc->createElement('CRASH_SENSOR');
        $channelNode->setAttribute( "MDS_channel",            $mds_channel );
        $channelNode->setAttribute( "DeviceName",             $device_name );
        $channelNode->setAttribute( "QuaTeIndex",             $quate_index );
        $channelNode->setAttribute( "DeviceIndex",            $device_index );
        $channelNode->setAttribute( "ChannelIndex",           $channel_index );
        $channelNode->setAttribute( "ChannelName",            $channel_name );
        $channelNode->setAttribute( "RomFile",                $romFile );
        $channelNode->setAttribute( "QuateDeviceDescription", $deviceDescription );
        $channelNode->setAttribute( "Firmware",               $firmware );
        $channelNode->setAttribute( "ChipSelect",             $chipSelect );
        $channelNode->setAttribute( "Port",                   $port );
        $actualSettingsNode->appendChild($channelNode);
    }

    foreach my $channel ( sort keys %{ $channelAssignment_href->{'NETWORK_DYNAMIC'} } ) {

        my $channelNode = $oCREISSummaryDoc->createElement('NETWORK_DYNAMIC');

        # 'MDS channel', 'Frame/PDU', 'Signal'
        $channelNode->setAttribute( "MDS_channel", $channel );
        $channelNode->setAttribute( "Frame",       $channelAssignment_href->{'NETWORK_DYNAMIC'}{$channel}{'Frame/PDU'} );
        $channelNode->setAttribute( "Signal",      $channelAssignment_href->{'NETWORK_DYNAMIC'}{$channel}{'Signal'} );

        $actualSettingsNode->appendChild($channelNode);
    }

    return 1;
}

sub FLC_LOG_CloseSettingsNode {

    # error if crashNode is not defined
    return 0 unless ( defined $actualSettingsNode );

    $rootElement->appendChild($actualSettingsNode);

    open( my $fhSummaryXMLFile, ">", $summaryXMLFile ) or S_set_error( "unable to write to XML file '$summaryXMLFile' ", 21 );
    binmode $fhSummaryXMLFile;    # drop all PerlIO layers possibly created by a use open pragma
    print $fhSummaryXMLFile $oCREISSummaryDoc->toString(1);
    close($fhSummaryXMLFile);

    $oCREISSummaryDoc = undef;
    $rootElement      = undef;

    return 1;
}

sub FLC_LOG_CreateSettingsNode {

    $actualSettingsNode = $oCREISSummaryDoc->createElement("Settings");

    return 1;
}

sub FLC_LOG_DynamicEnvSettings {
    my @args = @_;

    my $crashData_href = shift @args;

    my $dynamicEnvironments_href = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'};

    foreach my $dynamicEnv ( sort keys %$dynamicEnvironments_href ) {

        my $dynamicEnvNode = $oCREISSummaryDoc->createElement("DynamicEnvironment");
        $dynamicEnvNode->setAttribute( "name", $dynamicEnv );

        $actualSettingsNode->appendChild($dynamicEnvNode);
    }

    return 1;
}

sub FLC_LOG_EcuMode {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_LOG_EcuMode( $phase, $value )', @args );

    my $phase = shift @args;
    my $value = shift @args;

    $perCrashEcuMode_href->{$phase} = $value;

    return 1;
}

sub FLC_LOG_EDRSettings {

    my $filenames_href = shift;

    return 0 unless $filenames_href;

    my $edrSettingsNode;

    if ( exists $filenames_href->{EdrCount} ) {
        $edrSettingsNode = $oCREISSummaryDoc->createElement("EDR");
        $edrSettingsNode->setAttribute( "Name", "Nbr. of stored EDR" );
        $actualSettingsNode->appendChild($edrSettingsNode);

        my $edrDefect219169Workaround = S_check_exec_option('Defect_219169_workaround') ? S_get_exec_option('Defect_219169_workaround') : 0;
        if ($edrDefect219169Workaround) {
            $edrSettingsNode = $oCREISSummaryDoc->createElement("EDR");
            $edrSettingsNode->setAttribute( "Name", "Defect_219169_workaround" );
            $actualSettingsNode->appendChild($edrSettingsNode);
        }
    }

    if ( exists $filenames_href->{EdrStatus} ) {
        $edrSettingsNode = $oCREISSummaryDoc->createElement("EDR");
        $edrSettingsNode->setAttribute( "Name", "ECU Status - Byte 2" );
        $actualSettingsNode->appendChild($edrSettingsNode);
    }

    foreach my $edrNbr ( sort { $a <=> $b } keys %{ $filenames_href->{EdrId} } ) {

        next if $edrNbr !~ /([0-9]+)/;
        if ( exists $filenames_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus} ) {
            $edrSettingsNode = $oCREISSummaryDoc->createElement("EDR");
            $edrSettingsNode->setAttribute( "Name",       "MandatoryDataRecCompltStatus$edrNbr" );
            $edrSettingsNode->setAttribute( "pdVariable", $filenames_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable} ) if exists $filenames_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable};
            $edrSettingsNode->setAttribute( "pdVariable", "NA" ) unless exists $filenames_href->{EdrId}{$edrNbr}{MandatoryDataRecCompltStatus}{pdVariable};
            $actualSettingsNode->appendChild($edrSettingsNode);
        }

        if ( exists $filenames_href->{EdrId}{$edrNbr}{RecordCompleteStatus} ) {
            $edrSettingsNode = $oCREISSummaryDoc->createElement("EDR");
            $edrSettingsNode->setAttribute( "Name",       "RecordCompleteStatus$edrNbr" );
            $edrSettingsNode->setAttribute( "pdVariable", $filenames_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable} ) if exists $filenames_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable};
            $edrSettingsNode->setAttribute( "pdVariable", "NA" ) unless exists $filenames_href->{EdrId}{$edrNbr}{RecordCompleteStatus}{pdVariable};
            $actualSettingsNode->appendChild($edrSettingsNode);
        }
    }

    return 1;
}

sub FLC_LOG_EDRValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_LOG_EDRValues( $name, $value, $verdict, [$comment] )', @args );

    my $name    = shift @args;
    my $value   = shift @args;
    my $verdict = shift @args;
    my $comment = shift @args;

    $perCrashEdrValues_href->{$name}{Value}    = $value;
    $perCrashEdrValues_href->{$name}{Verdict}  = $verdict;
    $perCrashEdrValues_href->{$name}{Comment}  = $comment if ( defined $comment );
    $perCrashEdrValues_href->{$name}{TcTime_s} = S_get_TC_time();

    return 1;
}

sub FLC_LOG_ExtendedRuntimeSettings {

    my $filenames_href = shift;

    my $extendedRuntimeNode = $oCREISSummaryDoc->createElement("ExtendedRuntime");

    # attach all attributes
    $extendedRuntimeNode->setAttribute( "Name", "AverageTime" );
    $extendedRuntimeNode->setAttribute( "unit", "Val_us" );
    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_CurrentRuntime_u32"} ) {
        $extendedRuntimeNode->setAttribute( "pdVariable", "rb_fcl_StatusFirCtrl_u8, rb_rt_CurrentRuntime_u32" );
    }
    else {
        $extendedRuntimeNode->setAttribute( "pdVariable", "NA" );
    }

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($extendedRuntimeNode);

    $extendedRuntimeNode = $oCREISSummaryDoc->createElement("ExtendedRuntime");

    # attach all attributes
    $extendedRuntimeNode->setAttribute( "Name", "TaskDrop_BG2ms" );
    $extendedRuntimeNode->setAttribute( "unit", "Val_percent" );
    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_2mscounter_u8"} ) {
        $extendedRuntimeNode->setAttribute( "pdVariable", "rb_fcl_StatusFirCtrl_u8, rb_rt_500uscounter_u8, rb_bg_2mscounter_u8" );
    }
    else {
        $extendedRuntimeNode->setAttribute( "pdVariable", "NA" );
    }

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($extendedRuntimeNode);

    $extendedRuntimeNode = $oCREISSummaryDoc->createElement("ExtendedRuntime");

    # attach all attributes
    $extendedRuntimeNode->setAttribute( "Name", "TaskDrop_BG5ms" );
    $extendedRuntimeNode->setAttribute( "unit", "Val_percent" );
    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_5mscounter_u8"} ) {
        $extendedRuntimeNode->setAttribute( "pdVariable", "rb_fcl_StatusFirCtrl_u8, rb_rt_500uscounter_u8, rb_bg_5mscounter_u8" );
    }
    else {
        $extendedRuntimeNode->setAttribute( "pdVariable", "NA" );
    }

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($extendedRuntimeNode);

    $extendedRuntimeNode = $oCREISSummaryDoc->createElement("ExtendedRuntime");

    # attach all attributes
    $extendedRuntimeNode->setAttribute( "Name", "TaskDrop_BG10ms" );
    $extendedRuntimeNode->setAttribute( "unit", "Val_percent" );
    if ( exists $filenames_href->{"rb_fcl_StatusFirCtrl_u8"} and exists $filenames_href->{"rb_rt_500uscounter_u8"} and exists $filenames_href->{"rb_bg_10mscounter_u8"} ) {
        $extendedRuntimeNode->setAttribute( "pdVariable", "rb_fcl_StatusFirCtrl_u8, rb_rt_500uscounter_u8, rb_bg_10mscounter_u8" );
    }
    else {
        $extendedRuntimeNode->setAttribute( "pdVariable", "NA" );
    }

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($extendedRuntimeNode);

    return 1;
}

sub FLC_LOG_ExtendedRuntimeValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_LOG_ExtendedRuntimeValues( $avgAlgoActiveRuntime, $taskDropRate_2ms, $taskDropRate_5ms, $taskDropRate_10ms )', @args );

    my $avgAlgoActiveRuntime = shift @args;
    my $taskDropRate_2ms     = shift @args;
    my $taskDropRate_5ms     = shift @args;
    my $taskDropRate_10ms    = shift @args;

    $perCrashExtendedRuntime_href->{AverageTime}     = '-';
    $perCrashExtendedRuntime_href->{AverageTime}     = $avgAlgoActiveRuntime if ( defined $avgAlgoActiveRuntime );
    $perCrashExtendedRuntime_href->{TaskDrop_BG2ms}  = '-';
    $perCrashExtendedRuntime_href->{TaskDrop_BG2ms}  = $taskDropRate_2ms if ( defined $taskDropRate_2ms );
    $perCrashExtendedRuntime_href->{TaskDrop_BG5ms}  = '-';
    $perCrashExtendedRuntime_href->{TaskDrop_BG5ms}  = $taskDropRate_5ms if ( defined $taskDropRate_5ms );
    $perCrashExtendedRuntime_href->{TaskDrop_BG10ms} = '-';
    $perCrashExtendedRuntime_href->{TaskDrop_BG10ms} = $taskDropRate_10ms if ( defined $taskDropRate_10ms );

    return 1;
}

sub FLC_LOG_Faults {
    my ( %faultTexts, @afterCrashFaultTexts, @beforeCrashFaultTexts );
    my $faultName       = shift;
    my $attribute       = shift;
    my $value           = shift;
    my @validAttributes = qw(
      DetectedBeforeCrash EnvironmentDependent GenericBeforeCrash UnexpectedBeforeCrash MissingBeforeCrash
      DetectedAfterCrash SimDeviceDependent CrashDependent GenericAfterCrash UnexpectedAfterCrash MissingAfterCrash
      Comment
    );

    unless ( $attribute ~~ @validAttributes ) {
        S_set_error("FLC_LOG_Faults: Given attribute $attribute not supported.");
        return;
    }

    unless ( $value == 0 or $value == 1 or $attribute eq "Comment" ) {
        S_set_error("FLC_LOG_Faults: Given value $value not supported.");
        return;
    }

    unless ( exists $perCrashFaults_href->{$faultName} ) {
        @{ $perCrashFaults_href->{$faultName} }{@validAttributes} = (0) x @validAttributes;
    }

    $perCrashFaults_href->{$faultName}{$attribute} = $value;

    return 1;
}

sub FLC_LOG_InitSummaryXMLFile {
    my @args = @_;

    my $crashData_href = shift @args;
    my @csmGlobalKeywordList;

    $summaryXMLFile = $main::REPORT_PATH . "\\CREISTest_summary.xml";

    $oCREISSummaryDoc = XML::LibXML::Document->new( '1.0', 'utf-8' );

    # create the root element
    $rootElement = $oCREISSummaryDoc->createElement("CREIS_summary");

    # set the document root element
    $oCREISSummaryDoc->setDocumentElement($rootElement);

    my $ecuIdentificationNode = $oCREISSummaryDoc->createElement("ECU_Identification");

    my $project_info = S_get_project_info();

    foreach my $keyProjectInfo ( keys %$project_info ) {
        my $cleandedKeyProjectInfo = $keyProjectInfo;
        $cleandedKeyProjectInfo =~ s/\s/_/g;
        $ecuIdentificationNode->setAttribute( $cleandedKeyProjectInfo, $project_info->{$keyProjectInfo} );
        push @csmGlobalKeywordList, $cleandedKeyProjectInfo . "::" . $project_info->{$keyProjectInfo};
    }

    my $mdsResult = basename( $crashData_href->{'METADATA'}{'RESULTDB'} );

    $ecuIdentificationNode->setAttribute( "MDSResult", $mdsResult );
    push @csmGlobalKeywordList, "CreisInputFile::" . $mdsResult;
    $rootElement->appendChild($ecuIdentificationNode);

    return \@csmGlobalKeywordList;
}

sub FLC_LOG_PdLabelReaderSettings {
    my $filenames_href = shift;

    return 0 unless $filenames_href;

    foreach my $name ( sort keys %{ $filenames_href->{BeforeCrash} } ) {
        my $label  = $filenames_href->{BeforeCrash}{$name}{PdVariable};
        my $mode   = $filenames_href->{BeforeCrash}{$name}{Mode};
        my $factor = $filenames_href->{BeforeCrash}{$name}{Factor};
        my $unit   = $filenames_href->{BeforeCrash}{$name}{Unit};

        my $pdLabelReaderSettingsNode = $oCREISSummaryDoc->createElement("PdLabelBeforeCrash");
        $pdLabelReaderSettingsNode->setAttribute( "Name",       $name );
        $pdLabelReaderSettingsNode->setAttribute( "pdVariable", $label );
        $pdLabelReaderSettingsNode->setAttribute( "mode",       $mode );
        $pdLabelReaderSettingsNode->setAttribute( "factor",     $factor ) if defined $factor;
        $pdLabelReaderSettingsNode->setAttribute( "unit",       $unit ) if defined $unit;
        $actualSettingsNode->appendChild($pdLabelReaderSettingsNode);
    }
    foreach my $name ( sort keys %{ $filenames_href->{AfterCrash} } ) {
        my $label  = $filenames_href->{AfterCrash}{$name}{PdVariable};
        my $mode   = $filenames_href->{AfterCrash}{$name}{Mode};
        my $factor = $filenames_href->{AfterCrash}{$name}{Factor};
        my $unit   = $filenames_href->{AfterCrash}{$name}{Unit};

        my $pdLabelReaderSettingsNode = $oCREISSummaryDoc->createElement("PdLabelAfterCrash");
        $pdLabelReaderSettingsNode->setAttribute( "Name",       $name );
        $pdLabelReaderSettingsNode->setAttribute( "pdVariable", $label );
        $pdLabelReaderSettingsNode->setAttribute( "mode",       $mode );
        $pdLabelReaderSettingsNode->setAttribute( "factor",     $factor ) if defined $factor;
        $pdLabelReaderSettingsNode->setAttribute( "unit",       $unit ) if defined $unit;
        $actualSettingsNode->appendChild($pdLabelReaderSettingsNode);
    }

    return 1;
}

sub FLC_LOG_RbFaultEvaluationSettings {
    my @args = @_;

    my $rbFaultEvaluationSetting = shift @args;

    my $rbFaultEvaluation = 0;
    $rbFaultEvaluation = 1 if $rbFaultEvaluationSetting;

    my $rbFaultEvaluationSettingsNode = $oCREISSummaryDoc->createElement("RbFaultEvaluation");
    $rbFaultEvaluationSettingsNode->setAttribute( "EvaluateRbFaults", $rbFaultEvaluation );
    $actualSettingsNode->appendChild($rbFaultEvaluationSettingsNode);

    return 1;
}

sub FLC_LOG_ReleaseIntegrityStatus {
    my @args = @_;

    my $componentIntegrityCreisFw = shift @args;

    my $checksumResultsAll_href = main::Get_checksumResultsAll();

    my $versionCreisFw = $checksumResultsAll_href->{Components}{"CREIS_Framework"}{Version};

    my $componentIntegrityNode = $oCREISSummaryDoc->createElement("ReleaseStatus");
    $componentIntegrityNode->setAttribute( "ComponentIntegrity", $componentIntegrityCreisFw );
    $componentIntegrityNode->setAttribute( "Version",            $versionCreisFw );
    $actualSettingsNode->appendChild($componentIntegrityNode);

    return 1;
}

sub FLC_LOG_RuntimeSettings {
    my $filenames_href = shift;
    return 0 unless $filenames_href;

    my $runtimeNode = $oCREISSummaryDoc->createElement("Runtime");

    # attach all attributes
    $runtimeNode->setAttribute( "Name",       "MaximumTime" );
    $runtimeNode->setAttribute( "pdVariable", $filenames_href->{"MaximumTime"} ) if exists $filenames_href->{"MaximumTime"};
    $runtimeNode->setAttribute( "pdVariable", "NA" ) unless exists $filenames_href->{"MaximumTime"};
    $runtimeNode->setAttribute( "unit",       "Val_us" );

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($runtimeNode);

    $runtimeNode = $oCREISSummaryDoc->createElement("Runtime");

    # attach all attributes
    $runtimeNode->setAttribute( "Name",       "MinimumTime" );
    $runtimeNode->setAttribute( "pdVariable", $filenames_href->{"MinimumTime"} ) if exists $filenames_href->{"MinimumTime"};
    $runtimeNode->setAttribute( "pdVariable", "NA" ) unless exists $filenames_href->{"MinimumTime"};
    $runtimeNode->setAttribute( "unit",       "Val_us" );

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($runtimeNode);

    $runtimeNode = $oCREISSummaryDoc->createElement("Runtime");

    # attach all attributes
    $runtimeNode->setAttribute( "Name",       "PendingCounter" );
    $runtimeNode->setAttribute( "pdVariable", $filenames_href->{"PendingCounter"} ) if exists $filenames_href->{"PendingCounter"};
    $runtimeNode->setAttribute( "pdVariable", "NA" ) unless exists $filenames_href->{"PendingCounter"};
    $runtimeNode->setAttribute( "unit",       "Val" );

    # append the SimDevNode to the crash
    $actualSettingsNode->appendChild($runtimeNode);

    return 1;
}

sub FLC_LOG_RuntimeValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_LOG_RuntimeValues( $max_runtime, $min_runtime, $pendcnt )', @args );

    my $max_runtime = shift @args;
    my $min_runtime = shift @args;
    my $pendcnt     = shift @args;

    $perCrashRuntime_href->{MaximumTime} = '-';
    $perCrashRuntime_href->{MaximumTime} = $max_runtime if ( defined $max_runtime );

    $perCrashRuntime_href->{MinimumTime} = '-';
    $perCrashRuntime_href->{MinimumTime} = $min_runtime if ( defined $min_runtime );

    $perCrashRuntime_href->{PendingCounter} = '-';
    $perCrashRuntime_href->{PendingCounter} = $pendcnt if ( defined $pendcnt );

    return 1;
}

=head2 FLC_LOG_CreateSimDevHTMLTable

    FLC_LOG_CreateSimDevHTMLTable( );

=cut

sub FLC_LOG_CreateSimDevHTMLTable {
    my @table = ();
    my $simDevData_href;

    foreach my $simDev ( sort keys %{$perCrashSimDevices_href} ) {

        my $firing_status_color;

        if ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "Late Deployment" ) {
            $firing_status_color = 'yellow';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "Early Deployment" ) {
            $firing_status_color = 'cyan';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "Wrong Deployment" ) {
            $firing_status_color = '#FF99CC';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "No Deployment" ) {
            $firing_status_color = 'red';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "Ignored" ) {
            $firing_status_color = '#C5D5F5';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "VALID" ) {
            $firing_status_color = 'green';
        }
        elsif ( $perCrashSimDevices_href->{$simDev}{'Firing_Status'} eq "INCONC" ) {
            $firing_status_color = '#CC99FF';
        }
        else {
            $firing_status_color = '#CC99FF';
        }

        my $text_MinT_ms = $perCrashSimDevices_href->{$simDev}{'MinT_ms'};
        my $text_MaxT_ms = $perCrashSimDevices_href->{$simDev}{'MaxT_ms'};

        if ( $perCrashSimDevices_href->{$simDev}{"IsDeployed"} == $CANFIRE_SIMDEVICE ) {
            $text_MinT_ms = "[" . $text_MinT_ms . "]";
            $text_MaxT_ms = "[" . $text_MaxT_ms . "]";
        }

        # store the html Data for the simDev
        my $text4table =
            '<TR><TD>'
          . $simDev
          . '</TD><TD>'
          . $text_MinT_ms
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'ActualFiringTime_ms'}
          . '</TD><TD>'
          . $text_MaxT_ms
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'Text'}
          . "</TD><TD style='background:$firing_status_color'>"
          . $perCrashSimDevices_href->{$simDev}{'Firing_Status'}
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'DetectedFiringDuration_ms'}
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'FireCounter_HighLevel_ms'}
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'FireCounter_LowLevel_ms'}
          . '</TD><TD>'
          . $perCrashSimDevices_href->{$simDev}{'SquibResistance_ohm'}
          . '</TD></TR>';

        push( @table, $text4table );
    }

    S_w2log( 1, "Result table\n", undef, "Result table" );
    push(
        @TC_HTML_TEXT,
        join(
            '',
            '<div class="w2rep ',
            $moduleName,
            '"><TABLE class="tablesorter">',
            '<TR><TH>SimDevices</TH>
            <TH> MinT<br>(in ms)</TH>
            <TH> Actual<br>FiringTime<br>(in ms)</TH>
            <TH> MaxT<br>(in ms)</TH>
            <TH> Status Text</TH>
            <TH> Status</TH>
            <TH> Detected<br>Firing Duration<br>(in ms)</TH>
            <TH> FireCounter<br>High Level<br>(in ms)</TH>
            <TH> FireCounter<br>Low Level<br>(in ms)</TH>
            <TH> SquibResistance<br>(in Ohm)</TH></TR>',
            @table, '</TABLE></div>', "\n"
        )
    );

    return 1;
}

sub FLC_LOG_SimDevice {
    my @args = @_;

    my $deviceName        = shift @args;
    my $firing_state_href = shift @args;

    $perCrashSimDevices_href->{$deviceName} = $firing_state_href;

    return 1;
}

sub FLC_LOG_SimDeviceSettings {
    my @args = @_;

    my $crashData_href          = shift @args;
    my $settingsSimDevices_href = shift @args;
    my @simDevices              = keys %{ $crashData_href->{'EXPECTEDRESULT'} };

    foreach my $simDev ( sort @simDevices ) {
        my $simdevNode = $oCREISSummaryDoc->createElement("SimDevice");

        # attach all attributes
        $simdevNode->setAttribute( "Name", $simDev );
        foreach my $setting ( sort keys %{ $settingsSimDevices_href->{$simDev} } ) {
            if ( ref $settingsSimDevices_href->{$simDev}{$setting} eq "ARRAY" ) {
                my $text = join( ', ', @{ $settingsSimDevices_href->{$simDev}{$setting} } );
                $simdevNode->setAttribute( $setting, $text );
            }
            else {
                $simdevNode->setAttribute( $setting, $settingsSimDevices_href->{$simDev}{$setting} );
            }
        }

        # append the SimDevNode to the crash
        $actualSettingsNode->appendChild($simdevNode);
    }

    return 1;
}

sub FLC_LOG_StaticEnvironments {
    my @args = @_;

    my $crashData_href = shift @args;

    my $staticEnvironments_href = $crashData_href->{'ENVIRONMENT'}{'STATIC'};

    foreach my $staticEnv ( sort keys %$staticEnvironments_href ) {
        my $joinedSetTexts   = join( "|", @{ $staticEnvironments_href->{$staticEnv}{SetText} } );
        my $joinedCheckTexts = join( "|", @{ $staticEnvironments_href->{$staticEnv}{CheckText} } );
        my $joinedVerdicts   = join( "|", @{ $staticEnvironments_href->{$staticEnv}{Verdict} } );

        my $staticEnvNode = $oCREISSummaryDoc->createElement("StaticEnvironment");
        $staticEnvNode->setAttribute( "name",            $staticEnv );
        $staticEnvNode->setAttribute( "value",           $staticEnvironments_href->{$staticEnv}{Value} );
        $staticEnvNode->setAttribute( "joinedSetText",   $joinedSetTexts );
        $staticEnvNode->setAttribute( "joinedCheckText", $joinedCheckTexts );
        $staticEnvNode->setAttribute( "joinedVerdict",   $joinedVerdicts );
        $actualSettingsNode->appendChild($staticEnvNode);
    }

    return 1;
}

sub FLC_LOG_TcEvent {
    my $tcEvent = shift;

    my $tcEvent_clean = FLC_LOG_CleanStrings($tcEvent);

    $perCrashTcEvents_href->{$tcEvent_clean}{TcTime_s} = S_get_TC_time();

    return $tcEvent_clean;
}

sub FLC_LOG_PdLabelValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FLC_LOG_PdLabelValues( $name, $phase, $value, $verdict, [$comment] )', @args );

    my $name    = shift @args;
    my $phase   = shift @args;
    my $value   = shift @args;
    my $verdict = shift @args;
    my $comment = shift @args;

    $perCrashpdLabels_href->{$phase}{$name}{Verdict}  = $verdict;
    $perCrashpdLabels_href->{$phase}{$name}{Value}    = $value;
    $perCrashpdLabels_href->{$phase}{$name}{Comment}  = $comment if ( defined $comment );
    $perCrashpdLabels_href->{$phase}{$name}{TcTime_s} = S_get_TC_time();

    return 1;
}

sub FLC_LOG_CompleteCrash {
    my @args = @_;

    my $crashData_href                    = shift @args;
    my $skipInvalidEnvironmentCombination = shift @args;

    # parse the summary XML file and get the reference of Document root element
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # load the existing XML file
    $oCREISSummaryDoc = $parser->load_xml( location => $summaryXMLFile );

    # get the reference to root element
    $rootElement = $oCREISSummaryDoc->documentElement;

    #Create the output $CrashSettingsHash
    my $crashId                 = $crashData_href->{'METADATA'}{'CRASHINDEX'};
    my $crashname               = $crashData_href->{'METADATA'}{'CRASHNAME'};
    my $stateVariationNumber    = $crashData_href->{'METADATA'}{'STATEVARIATION'};
    my $crashDuration_ms        = $crashData_href->{'METADATA'}{'CRASHDURATION_MS'};
    my $channel_assignment_aref = $crashData_href->{'METADATA'}{'CRASH_ASSIGNMENT_COMMENT'};
    my $channel_assignment      = $$channel_assignment_aref[0];

    # try to avoid unicode bug:
    utf8::upgrade($crashname);
    utf8::upgrade($channel_assignment);

    my $attachmentFolder = S_get_TC_number() . "_" . FLC_LOG_CleanStrings($crashname) . "_" . $stateVariationNumber . ".zip";

    my @parts        = split( /\_/, S_get_TC_number );
    my $tcNumber     = $parts[0];
    my $tcRepetition = $parts[1];
    my $iteration    = $tcRepetition + 1;

    my @parts = split( /\./, $main::CURRENT_TC );
    my $tcModule = $parts[0];

    $actualCrashNode = $oCREISSummaryDoc->createElement("Crash");
    $actualCrashNode->setAttribute( "id",                 $crashId );
    $actualCrashNode->setAttribute( "name",               $crashname );
    $actualCrashNode->setAttribute( "envstate",           $stateVariationNumber );
    $actualCrashNode->setAttribute( "iteration",          $iteration );
    $actualCrashNode->setAttribute( "tcNumber",           $tcNumber );
    $actualCrashNode->setAttribute( "tcRepetition",       $tcRepetition );
    $actualCrashNode->setAttribute( "tcModule",           $tcModule );
    $actualCrashNode->setAttribute( "hreftestcase",       $main::TC_REPORT_NAME );
    $actualCrashNode->setAttribute( "folder",             $attachmentFolder );
    $actualCrashNode->setAttribute( "crashduration_ms",   $crashDuration_ms );
    $actualCrashNode->setAttribute( "channel_assignment", $channel_assignment );
    $actualCrashNode->setAttribute( "comment",            " " );
    $actualCrashNode->setAttribute( "comment",            "Invalid combination of environments [section: " . $skipInvalidEnvironmentCombination . "]." ) if $skipInvalidEnvironmentCombination;

    # get all dynamicEnvironments and add them to XML
    my $dynamicEnvironments_href = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'};

    if ( defined $dynamicEnvironments_href ) {
        my $collectedDynamicEnvNode = $oCREISSummaryDoc->createElement("CollectedDynamicEnvironements");

        foreach my $dynamicEnv ( sort keys %$dynamicEnvironments_href ) {
            my $joinedSetTexts   = join( "|", @{ $dynamicEnvironments_href->{$dynamicEnv}{SetText} } );
            my $joinedCheckTexts = join( "|", @{ $dynamicEnvironments_href->{$dynamicEnv}{CheckText} } );
            my $joinedVerdicts   = join( "|", @{ $dynamicEnvironments_href->{$dynamicEnv}{Verdict} } );

            my $dynamicEnvNode = $oCREISSummaryDoc->createElement("DynamicEnvironment");
            $dynamicEnvNode->setAttribute( "name",            $dynamicEnv );
            $dynamicEnvNode->setAttribute( "value",           $dynamicEnvironments_href->{$dynamicEnv}{Value} );
            $dynamicEnvNode->setAttribute( "joinedSetText",   $joinedSetTexts );
            $dynamicEnvNode->setAttribute( "joinedCheckText", $joinedCheckTexts );
            $dynamicEnvNode->setAttribute( "joinedVerdict",   $joinedVerdicts );
            $collectedDynamicEnvNode->appendChild($dynamicEnvNode);
        }

        $actualCrashNode->appendChild($collectedDynamicEnvNode);
    }

    # add all testcase events to XML
    foreach my $event ( keys %{$perCrashTcEvents_href} ) {
        my $genericTcEventNode = $oCREISSummaryDoc->createElement($event);
        $genericTcEventNode->setAttribute( "TcTime_s", $perCrashTcEvents_href->{$event}{TcTime_s} );
        $actualCrashNode->appendChild($genericTcEventNode);
    }

    # add all SimDevices to XML
    foreach my $simDevice ( keys %{$perCrashSimDevices_href} ) {
        my $simdevNode = $oCREISSummaryDoc->createElement("SimDevice");

        $simdevNode->setAttribute( "Name",                      $simDevice );
        $simdevNode->setAttribute( "MinT_ms",                   $perCrashSimDevices_href->{$simDevice}{MinT_ms} );
        $simdevNode->setAttribute( "ActualFiringTime_ms",       $perCrashSimDevices_href->{$simDevice}{ActualFiringTime_ms} );
        $simdevNode->setAttribute( "MaxT_ms",                   $perCrashSimDevices_href->{$simDevice}{MaxT_ms} );
        $simdevNode->setAttribute( "FiringStatus",              $perCrashSimDevices_href->{$simDevice}{Firing_Status} );
        $simdevNode->setAttribute( "Text",                      $perCrashSimDevices_href->{$simDevice}{Text} );
        $simdevNode->setAttribute( "IsDeployed",                $perCrashSimDevices_href->{$simDevice}{IsDeployed} );
        $simdevNode->setAttribute( "FireCounter_HighLevel_ms",  $perCrashSimDevices_href->{$simDevice}{FireCounter_HighLevel_ms} );
        $simdevNode->setAttribute( "FireCounter_LowLevel_ms",   $perCrashSimDevices_href->{$simDevice}{FireCounter_LowLevel_ms} );
        $simdevNode->setAttribute( "DetectedFiringDuration_ms", $perCrashSimDevices_href->{$simDevice}{DetectedFiringDuration_ms} );

        $actualCrashNode->appendChild($simdevNode);
    }

    # add Runtime measurements to XML
    foreach my $runtime ( keys %{$perCrashRuntime_href} ) {
        my $runtimeNode = $oCREISSummaryDoc->createElement("Runtime");
        $runtimeNode->setAttribute( "Name",  $runtime );
        $runtimeNode->setAttribute( "Value", $perCrashRuntime_href->{$runtime} );
        $actualCrashNode->appendChild($runtimeNode);
    }

    # add extendedRuntime measurements to XML
    foreach my $extendedRuntime ( keys %{$perCrashExtendedRuntime_href} ) {
        my $extendedRuntimeNode = $oCREISSummaryDoc->createElement("ExtendedRuntime");
        $extendedRuntimeNode->setAttribute( "Name",  $extendedRuntime );
        $extendedRuntimeNode->setAttribute( "Value", $perCrashExtendedRuntime_href->{$extendedRuntime} );
        $actualCrashNode->appendChild($extendedRuntimeNode);
    }

    foreach my $edrElement ( keys %{$perCrashEdrValues_href} ) {
        my $edrValuesNode = $oCREISSummaryDoc->createElement("EDR");

        $edrValuesNode->setAttribute( "Name",     $edrElement );
        $edrValuesNode->setAttribute( "Value",    $perCrashEdrValues_href->{$edrElement}{Value} );
        $edrValuesNode->setAttribute( "Verdict",  $perCrashEdrValues_href->{$edrElement}{Verdict} );
        $edrValuesNode->setAttribute( "Comment",  $perCrashEdrValues_href->{$edrElement}{Comment} ) if ( defined $perCrashEdrValues_href->{$edrElement}{Comment} );
        $edrValuesNode->setAttribute( "TcTime_s", $perCrashEdrValues_href->{$edrElement}{TcTime_s} );

        $actualCrashNode->appendChild($edrValuesNode);
    }

    foreach my $fault ( keys %{$perCrashFaults_href} ) {

        # prepare new SimDeviceNode for XML
        my $faultNode = $oCREISSummaryDoc->createElement("RBFault");

        # attach all attributes
        $faultNode->setAttribute( "Name", $fault );
        foreach my $attribute ( sort keys %{ $perCrashFaults_href->{$fault} } ) {
            $faultNode->setAttribute( $attribute, $perCrashFaults_href->{$fault}{$attribute} );
        }

        # append the SimDevNode to the crash
        $actualCrashNode->appendChild($faultNode);
    }

    # $perCrashpdLabels_href->{$phase}{$name}{TcTime_s} = S_get_TC_time();
    foreach my $label ( keys %{ $perCrashpdLabels_href->{BeforeCrash} } ) {
        my $pdLabelValuesNode = $oCREISSummaryDoc->createElement("PdLabelValuesBeforeCrash");
        $pdLabelValuesNode->setAttribute( "Name",     $label );
        $pdLabelValuesNode->setAttribute( "Verdict",  $perCrashpdLabels_href->{BeforeCrash}{$label}{Verdict} );
        $pdLabelValuesNode->setAttribute( "Value",    $perCrashpdLabels_href->{BeforeCrash}{$label}{Value} );
        $pdLabelValuesNode->setAttribute( "Comment",  $perCrashpdLabels_href->{BeforeCrash}{$label}{Comment} ) if ( defined $perCrashpdLabels_href->{BeforeCrash}{$label}{Comment} );
        $pdLabelValuesNode->setAttribute( "TcTime_s", $perCrashpdLabels_href->{BeforeCrash}{$label}{TcTime_s} );
        $actualCrashNode->appendChild($pdLabelValuesNode);
    }
    foreach my $label ( keys %{ $perCrashpdLabels_href->{AfterCrash} } ) {
        my $pdLabelValuesNode = $oCREISSummaryDoc->createElement("PdLabelValuesAfterCrash");
        $pdLabelValuesNode->setAttribute( "Name",     $label );
        $pdLabelValuesNode->setAttribute( "Verdict",  $perCrashpdLabels_href->{AfterCrash}{$label}{Verdict} );
        $pdLabelValuesNode->setAttribute( "Value",    $perCrashpdLabels_href->{AfterCrash}{$label}{Value} );
        $pdLabelValuesNode->setAttribute( "Comment",  $perCrashpdLabels_href->{AfterCrash}{$label}{Comment} ) if ( defined $perCrashpdLabels_href->{AfterCrash}{$label}{Comment} );
        $pdLabelValuesNode->setAttribute( "TcTime_s", $perCrashpdLabels_href->{AfterCrash}{$label}{TcTime_s} );
        $actualCrashNode->appendChild($pdLabelValuesNode);
    }

    if ( exists $perCrashEcuMode_href->{BeforeCrash} ) {
        my $ecuModeNode = $oCREISSummaryDoc->createElement("EcuModeBeforeCrash");
        $ecuModeNode->setAttribute( "Value", $perCrashEcuMode_href->{BeforeCrash} );
        $actualCrashNode->appendChild($ecuModeNode);
    }

    if ( exists $perCrashEcuMode_href->{AfterCrash} ) {
        my $ecuModeNode = $oCREISSummaryDoc->createElement("EcuModeAfterCrash");
        $ecuModeNode->setAttribute( "Value", $perCrashEcuMode_href->{AfterCrash} );
        $actualCrashNode->appendChild($ecuModeNode);
    }

    $rootElement->appendChild($actualCrashNode);

    open( my $fhSummaryXMLFile, ">", $summaryXMLFile ) or S_set_error( "unable to write to XML file '$summaryXMLFile' ", 21 );
    binmode $fhSummaryXMLFile;    # drop all PerlIO layers possibly created by a use open pragma
    print $fhSummaryXMLFile $oCREISSummaryDoc->toString(1);
    close($fhSummaryXMLFile);

    $oCREISSummaryDoc        = undef;
    $rootElement             = undef;
    $perCrashSimDevices_href = undef;
    $perCrashTcEvents_href   = undef;
    $perCrashEdrValues_href  = undef;
    $perCrashEcuMode_href    = undef;
    $perCrashRuntime_href    = undef;
    $perCrashFaults_href     = undef;
    $perCrashpdLabels_href   = undef;

    return $iteration;
}

1;
__END__
