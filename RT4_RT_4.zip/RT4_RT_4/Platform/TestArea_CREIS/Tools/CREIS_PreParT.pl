#!usr\bin\perl.exe -w
# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

use strict;
use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use Getopt::Long;
use warnings;
use File::Basename;
use Win32::Console::ANSI;
use Win32::Shortcut;
use Term::ANSIColor;
use Pod::Usage;

=head1 NAME

CREIS_PreParT.pl

=head1 SYNOPSIS

CREIS_PreParT.pl [Options]


 E.g. 
 
    GUI Mode:
        CREIS_PreParT.pl
        
    HELP Mode:
        CREIS_PreParT.pl -?
        
    extendedMode:
        CREIS_PreParT.pl ^
           -m C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\CREIS\M03_18_RT4\SCI_04B034\SCI_M03_17_RT4_04B034_20191202.mdb ^
           -s C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\config\CREIS_PreParT_SettingFiles\default.cfg
        
    simpleMode:
        CREIS_PreParT.pl ^
           -m C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\CREIS\M03_18_RT4\SCI_04B034\SCI_M03_18_RT4_04B034_20191202.mdb ^
           -c C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\CREIS\config\Mappings\AB12_RefType4_ProjectConst_CREIS.pm ^
           -t TC_CREIS_StandardTest ^
        
    extendedMode with own test list name:
        CREIS_PreParT.pl ^
           -m C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\CREIS\M03_18_RT4\SCI_04B034\SCI_M03_17_RT4_04B034_20191202.mdb ^
           -s C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\config\CREIS_PreParT_SettingFiles\default.cfg
           -l TestList4Fun
	
 Options:
   --help|-?                          display tool documentation
   --mdbFilePath|-m  <path>           define path to *.mdb file
   --settingsFilePath|-s <path>       define settings file path
   --creisMappingFilePath|-c <path>   define CREIS mapping file path
   --testCaseName|-t <testcase-name>  define test case name
   --testListName|-l <testlist-name>  define the name of the generated testlist

=head1 OPTIONS

=over

=item --help|-?

Displays the tool documentation

=item --mdbFilePath|-m  <path>

Defines the path to *.mdb file.
If this option or help option is not given, the tool will start in GUI mode for manual usage.

=item --settingsFilePath|-s <path>

Defines the path to the Settings File (*.cfg).
If defined, the tool is switched to 'extendedMode', else the tool is in 'simpleMode'.

=item --creisMappingFilePath|-c <path>

Defines the CREIS mapping file path, that will be used by the tool if 'simpleMode' is used (no settings file provided).
In 'extendedMode' this option is ignored.

=item --testCaseName|-t <testcase-name>

Defines the testcase-name that will be used by the tool if 'simpleMode' is used (no settings file provided).
Value has to consist of word characters (alphanumeric or _) only and file ending (*.pm) should not be provided.
In 'extendedMode' this option is ignored.

=item --testListName|-l <testlist-name>

Defines the name of the generated testlist. 
Value has to consist of word characters (alphanumeric or _) only and file ending (*.txt) should not be provided.
If this option is not given, the testlist will be named as combination of the folders where *.mdb is provided.

=back

=head1 DESCRIPTION

This tool is used to create TurboLIFT parameter file and test list and checks the CREIS Mapping file for consistency.
It has different modes that can be switched by providing arguments.

=head2 GUI - Mode
 
If no argument is given, the tool is started in GUI mode. For details see https://inside-docupedia.bosch.com/confluence/display/aeos/CREIS_PreParT+Tool

=head2 simpleMode
 
If option '--mdbFilePath|-m  <path>' is provided together with option '--testCaseName|-t <testcase-name>' and option '--creisMappingFilePath|-c <path>'.

In this mode the tool will create parameters and test list for the given test case and check the consistency for the provided CREIS mapping file.
A batch file template will be generated to the TODO - File (not ready to run).

=head2 extendedMode
 
If option '--mdbFilePath|-m  <path>' is provided together with option '--settingsFilePath|-s <path>'.

In this mode the tool will create parameters and test list for the test case that is provided in the given settings file
and check the consistency for the CREIS mapping file that is provided in the given settings file.

A ready to run batch file code snipet will be generated to the TODO - File.

=cut

my $projectPath      = File::Spec->rel2abs( dirname( dirname( dirname( dirname(__FILE__) ) ) ) );
my $sccmBasedProject = 0;
if ( -e $projectPath . "\\Custlib" ) {
    $projectPath      = $projectPath . "\\Custlib";
    $sccmBasedProject = 1;
}
my $configPath = $projectPath . "\\config";
my $addpath;

BEGIN {
    use Config;
    use File::Spec;
    use File::Basename;

    # find the LIFT engine path (LIFT_engine_path = ./../)
    my $LIFT_exec_path = File::Spec->rel2abs( dirname( dirname( dirname( dirname(__FILE__) ) ) ) ) . "/Engine";

    unshift @INC, "$LIFT_exec_path/modules/";
    unshift @INC, "$LIFT_exec_path/modules/Common_library/";

    # add directories to search path for perl modules
    $addpath = "$LIFT_exec_path/modules/Device_layer/MDSRESULT";
    my $perl56 = $addpath . "/Perl56";    #perl 5.6(32-bit) DLL directory
    my $win32  = $addpath . "/Win32";     #perl 5.12, 32-bit DLL directory
    my $win64  = $addpath . "/Win64";     #perl 5.12, 64-bit DLL directory

    if ( $] =~ m/5.006/i ) {              #if Perl version is 5.6
        unshift @INC, ( $addpath, $perl56 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Perl56"
        $ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load MDSResult.dll from "Win32"
    }
    elsif ( $] =~ m/5.012/i ) {                 #if Perl version is 5.12
        if ( $Config{'archname'} =~ m/x64/i ) {    #check the bitness of perl (32-bit or 64-bit)
            unshift @INC, ( $addpath, $win64 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win64"
            $ENV{PATH} = $win64 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win64"
        }
        else {
            unshift @INC, ( $addpath, $win32 );    #Include MDSResult.pm from Root directory, Load MDSResult.dll from "Win32"
            $ENV{PATH} = $win32 . ";$ENV{PATH}";   #Load MDSResult.dll from "Win32"
        }
    }
}

use MDSResult;

#create a LOG file
open( LOG, ">CREIS_PreParT_LOG.txt" ) || die("could not open CREIS_PreParT_log.txt\n");
print LOG "##########################################################################\n";
print LOG "###            CREIS Pre(pare)Par(ameter)T(estlist) GUI LOG            ###\n";
print LOG "##########################################################################\n";

# global variables for settings from settings file
my $configFilePath;
my $creisMappingFilePath;
my $execOptionFilePath;
my $usedExecOption;
my $usedInitCampaign;
my $testCaseName;
my $typeFolderName;

my $tempConfigFilePath;
my $tempCreisMappingFilePath;
my $tempExecOptionFilePath;
my $tempUsedExecOption;
my $tempUsedInitCampaign;
my $tempTestCaseName = "TC_CREIS_StandardTest";
my $tempTypeFolderName;

# global variables for settings from ini file
my $lastSettingsFile;
my $settingFilesDirectory;
my $lastSettingsFileDisplay;
my $lastSettingsFileFullPath;
my $mdbDirectory;
my $availableSettingsFiles_aref;

# global variables
my $mdbFilePath;
my $mdbFileDisplay      = "Select *.mdb File!";
my $testListName        = "TL_CREIS_VARIANT_TYPE";
my $knownTestCases_aref = [ "TC_CREIS_StandardTest", "TC_CREIS_MultiCrashes", "TC_CREIS_FreezeEnv" ];
my $engineCall          = '.\Engine\LIFT_exec_engine.pl';
$engineCall = '..\Engine\LIFT_exec_engine.pl' if $sccmBasedProject;
my $todoFileText;
my $todo_file_name = File::Spec->rel2abs("CREIS_PreParT_ToDo.txt");
my $status         = "Welcome!";
my $creisMappingContent;
my $creisMappingTemplate;
my $creisMappingEnvPrototypes;
my $remainingSections_href;
my $forceNewMapping;
my $prefix;
my ( $main, $top2, $givenMdbPath, $givenSettingsFilePath, $givenCreisMappingFilePath, $givenTestCaseName, $givenTestListName, $cmdLineMode, $help );

# set above defined global variables
CreateShortcut();
ReadInitFile();
ReadSettingsFile();
ScanAvailableSettingsFiles();

#Create Main window
$main = MainWindow->new( "-background" => "#888888" );

#Size of main window display
$main->resizable( 0, 0 );
$main->geometry("700x195");

$main->title("CREIS Pre(pare)Par(ameter)T(estlist) GUI");

#Declare that there is a menu
my $mbar = $main->Menu();
$main->configure( -menu => $mbar );

## File Menu ##
my $file = $mbar->cascade( -label => "File", -underline => 0, -tearoff => 0 );
$file->command( -label => "Exit", -underline => 1, -command => sub { exit } );

## Help Menu ##
my $helpMenu = $mbar->cascade( -label => "Help", -underline => 0, -tearoff => 0 );
$helpMenu->command( -label => "ReadMe", -underline => 0, -command => sub { OpenURL('https://inside-docupedia.bosch.com/confluence/display/aeos/CREIS_PreParT+Tool'); } );

# --- settings display
my $frame_projectPath = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_projectPath->Label(
    -text       => 'Project - Path:',
    -width      => '21',
    -background => "#888888",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_projectPath->Label(
    -width        => '80',
    -font         => '{Segoe UI} 10.5 ',
    -textvariable => \$projectPath,
    -background   => "#888888",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

my $frame_activeSettings = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_activeSettings->Label(
    -text       => 'Active Settings:',
    -width      => '21',
    -font       => '{Segoe UI} 10.5 ',
    -background => "#888888",
)->pack( -side => "left", -padx => '05', -pady => '03' );

my $om_activeSettings = $frame_activeSettings->Optionmenu(
    -width    => '70',
    -options  => $availableSettingsFiles_aref,
    -variable => \$lastSettingsFile,
    -command  => sub {
        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
        $lastSettingsFileDisplay = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );
        ReadSettingsFile();
    }
)->pack( -side => 'left', -padx => '05', -pady => '03' );

$frame_activeSettings->Button(
    -text       => "Edit...",
    -width      => '8',
    -background => "SkyBlue",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { ShowSettingsWindow() }
)->pack( -side => "right", -padx => '05', -pady => '03' );

# --- mdb File path ---
my $frame_mdbFilePath = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_mdbFilePath->Button(
    -text       => "Select *.mdb File",
    -width      => '18',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { GetMdbFileName() }
)->pack( -side => "left", -padx => '05', -pady => '03' );
$frame_mdbFilePath->Entry(
    -width        => '90',
    -textvariable => \$mdbFileDisplay,
    -background   => "grey",
    -state        => 'disabled',
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- test list name ---
my $frame_TestListName = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_TestListName->Label(
    -text       => 'Test List Name',
    -width      => '21',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_TestListName->Entry(
    -width        => '90',
    -textvariable => \$testListName,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- Generate Paramters ---
my $frame_generate_params_button = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );

# --- Generate Validation Testlist ---
my $button_GenerateFiles = $frame_generate_params_button->Button(
    -text       => "Generate Test List and Par File",
    -width      => '27',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        $status = "Generating...";
        _MDS_Start();
        GenerateParFile_and_TestList();
        CheckCREIS_Mapping();
        _MDS_Close();
    },
    -state => 'disabled',
)->pack( -side => "left", -padx => '05', -pady => '03' );

my $button_UpdateCreisMapping = $frame_generate_params_button->Button(
    -text       => "Save updated CREIS Mapping",
    -width      => '27',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { StoreUpdatedCreisMapping() },
    -state      => 'disabled',
)->pack( -side => "left", -padx => '05', -pady => '03' );

# --- Execute ---
my $button_CloseAndShowTodo = $frame_generate_params_button->Button(
    -text       => "Close and show TODO",
    -width      => '27',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { CloseAndShowToDo(); },
    -state      => 'disabled',
)->pack( -side => "right", -padx => '05', -pady => '03' );

# --- status bar ---
my $frame_statusBar = $main->Frame( "-background" => "black" )->pack( -pady => '1', -padx => '1', -anchor => 'nw' );
my $statusBarLabel = $frame_statusBar->Label(
    -textvariable => \$status,
    -width        => '100',
    -background   => "grey",
    -foreground   => "black",
    -font         => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '1', -pady => '1' );

### top level window 2
$top2 = $main->Toplevel( -background => "#888888" );
$top2->withdraw();

#Size of top2 window display
$top2->resizable( 0, 0 );
$top2->geometry("330x80");
$top2->title("CREIS PreParT Generate Templates GUI");

# --- Prefix ---
my $frame_top2_prefix = $top2->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_top2_prefix->Label(
    -text       => 'Prefix',
    -width      => '15',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_top2_prefix->Entry(
    -width        => '50',
    -textvariable => \$prefix,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- Save Settings Button ---
my $frame_top2_buttons = $top2->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'center' );
$frame_top2_buttons->Button(
    -text       => "Generate...",
    -width      => '18',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        CreateAllTemplates();
        $top2->withdraw();
    },
)->pack( -side => "top", -padx => '05', -pady => '03' );

### top level window
my $top = $main->Toplevel( -background => "#888888" );
$top->withdraw();

#Size of top window display
$top->resizable( 0, 0 );
$top->geometry("660x320");
$top->title("CREIS PreParT Settings GUI");

my $frame_settingFile = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );

$frame_settingFile->Button(
    -text       => "Select settings File",
    -width      => '18',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { GetSettingsFileName() }
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_settingFile->Entry(
    -width        => '80',
    -textvariable => \$lastSettingsFileDisplay,
    -background   => "grey",
    -state        => "disabled",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

my $frame_file_path_project_config = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );

$frame_file_path_project_config->Button(
    -text       => "Select project CFG",
    -width      => '18',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { GetConfigFileName() }
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_file_path_project_config->Entry(
    -width        => '80',
    -textvariable => \$tempConfigFilePath,
    -background   => "grey",
    -state        => "disabled",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

my $frame_file_path_creis_mapping = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_file_path_creis_mapping->Button(
    -text       => "Select Creis Mapping",
    -width      => '18',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { GetCreisMappingFile() }
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_file_path_creis_mapping->Entry(
    -width        => '80',
    -textvariable => \$tempCreisMappingFilePath,
    -background   => "grey",
    -state        => "disabled",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

my $frame_file_path_ExecOptions = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );

$frame_file_path_ExecOptions->Button(
    -text       => "Select Exec Options File",
    -width      => '18',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub { GetExecOptionsFile() }
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_file_path_ExecOptions->Entry(
    -width        => '80',
    -textvariable => \$tempExecOptionFilePath,
    -background   => "grey",
    -state        => "disabled",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- used Exec Option ---
my $frame_usedExecOption = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_usedExecOption->Label(
    -text       => 'Used Exec Option',
    -width      => '21',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_usedExecOption->Entry(
    -width        => '80',
    -textvariable => \$tempUsedExecOption,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- used Init Campaign ---
my $frame_InitCampaign = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_InitCampaign->Label(
    -text       => 'Init Campaign',
    -width      => '21',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_InitCampaign->Entry(
    -width        => '80',
    -textvariable => \$tempUsedInitCampaign,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- Test Case Name ---
my $frame_TestCaseName = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_TestCaseName->Label(
    -text       => 'Test Case Name',
    -width      => '21',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_TestCaseName->Optionmenu(
    -width    => '40',
    -variable => \$tempTestCaseName,
    -options  => $knownTestCases_aref,
)->pack( -side => 'right', -padx => '05', -pady => '03' );

$frame_TestCaseName->Entry(
    -width        => '40',
    -textvariable => \$tempTestCaseName,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- Test Case Name ---
my $frame_RegExp = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
$frame_RegExp->Label(
    -text       => 'Type / Folder Name',
    -width      => '21',
    -background => "DodgerBlue1",
    -foreground => "white",
    -font       => '{Segoe UI} 10.5 '
)->pack( -side => "left", -padx => '05', -pady => '03' );

$frame_RegExp->Entry(
    -width        => '80',
    -textvariable => \$tempTypeFolderName,
    -background   => "white",
)->pack( -side => 'right', -padx => '05', -pady => '03' );

# --- Save Settings Button ---
my $frame_save_settings_buttons = $top->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '03', -anchor => 'nw' );
my $button_Chancel = $frame_save_settings_buttons->Button(
    -text       => "Cancel",
    -width      => '18',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        CancelSettingsFileEdit();
        $top->withdraw();
    },
)->pack( -side => "left", -padx => '05', -pady => '03' );
my $button_CreateTemplates = $frame_save_settings_buttons->Button(
    -text       => "Create ALL Templates",
    -width      => '18',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        $top2->deiconify();
        $top2->raise();
    },
)->pack( -side => "left", -padx => '05', -pady => '03' );
my $button_SaveAs = $frame_save_settings_buttons->Button(
    -text       => "Save As... and Close",
    -width      => '18',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        SaveSettingsFileAs();
        $top->withdraw();
    },
)->pack( -side => "left", -padx => '05', -pady => '03' );
my $button_Save = $frame_save_settings_buttons->Button(
    -text       => "Save and Close",
    -width      => '18',
    -background => "Navy",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 10 ',
    -command    => sub {
        SaveSettingsFile();
        $top->withdraw();
    },
)->pack( -side => "left", -padx => '05', -pady => '03' );

#STEP get given command line options
GetOptions( "help|?" => \$help, "mdbFilePath=s" => \$givenMdbPath, "settingsFilePath=s" => \$givenSettingsFilePath, "creisMappingFilePath=s" => \$givenCreisMappingFilePath, "testListName|l=s" => \$givenTestListName, "testCaseName|t=s" => \$givenTestCaseName );

if ($help) {
    pod2usage( -verbose => 2 );
}
elsif ($givenMdbPath) {
    $cmdLineMode = 1;
    CmdLineMode();
}
else {
    MainLoop;
}

print LOG "\n##########################################################################\n";
print LOG "END OF LOGFILE\n\n\n";

close(LOG);

#################################################################################################
################################ MDS related Sub functions ######################################
#################################################################################################
sub _MDS_CheckStatus {
    my $status       = shift;
    my $functionText = shift;

    if ( $status < 0 ) {
        my $errortext = mdsresult_GetErrorString($status);

        $main->messageBox(
            '-icon'    => "error",                     #qw/error info question warning/
            '-type'    => "OK",                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Couldnot $functionText!"
        );

        ExitOnError("ERROR :: $functionText Failed :: Error Description :: $errortext \n");
    }

    return 1;
}

sub _MDS_Close {
    my $functionText = "Unload MDSResult DLL";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my $exit_status = mdsresult_CloseResult();
    _MDS_CheckStatus( $exit_status, $functionText );

    return 1;
}

sub _MDS_GetCrashEntityIterations {
    my $functionText = "Fetch all Crash Entity details from database";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my ( $GetCrashEntityIterations_status, $CrashEntityIDs, $CrashEntityNames, $State_Number ) = mdsresult_GetCrashEntityIterations();
    _MDS_CheckStatus( $GetCrashEntityIterations_status, $functionText );

    return ( $CrashEntityIDs, $CrashEntityNames, $State_Number );
}

sub _MDS_GetEnvironmentDetails {
    my $functionText = "Fetch all Constant Environment Parameters from database";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my ( $GetConstantEnvParams_status, $EnvName_Const, $EnvVals ) = mdsresult_GetConstantEnvParams();
    _MDS_CheckStatus( $GetConstantEnvParams_status, $functionText );

    $functionText = "Fetch all Dynamic Environment Parameters from database";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my ( $GetDynamicEnvParams_status, $EnvName_Dynamic ) = mdsresult_GetDynamicEnvParams();
    _MDS_CheckStatus( $GetDynamicEnvParams_status, $functionText );

    my %allEnv;

    @allEnv{@$EnvName_Dynamic} = 1;
    @allEnv{@$EnvName_Const}   = 1;

    return \%allEnv;
}

sub _MDS_GetSensorDetails {
    my $functionText = "Fetch Sensor Details from database";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my ( $GetSensorDetails_status, $ModuleName, $SensorName, $SensorDirection, $SensorType ) = mdsresult_GetSensorDetails();
    _MDS_CheckStatus( $GetSensorDetails_status, $functionText );

    return ( $ModuleName, $SensorName, $SensorDirection, $SensorType );
}

sub _MDS_GetSimDeviceDetails {
    my $functionText = "Fetch SimDevice Details from database";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my ( $GetSimDevices_status, $SimDevices_aref ) = mdsresult_GetSimDevices();
    _MDS_CheckStatus( $GetSimDevices_status, $functionText );

    return ($SimDevices_aref);
}

sub _MDS_Start {
    $statusBarLabel->update;

    my $MDB_file_processed = $mdbFilePath;
    $MDB_file_processed =~ s/\//\\/g;

    my $functionText = "Start mdsresult";
    print LOG "CREIS_proj_constants :: $functionText\n";
    my $status = mdsresult_Start();
    _MDS_CheckStatus( $status, $functionText );

    $functionText = "Enable Debug Infos";
    print LOG "CREIS_proj_constants :: $functionText\n";
    $status = mdsresult_SetFlagPrintDbgInfosEnabled( 1, dirname(__FILE__) );
    _MDS_CheckStatus( $status, $functionText );

    $functionText = "Initialise mdsresult";
    print LOG "CREIS_proj_constants :: $functionText\n";
    $status = mdsresult_InitResult($MDB_file_processed);
    _MDS_CheckStatus( $status, $functionText );

    return 1;
}

sub GetParaFileText {
    my $CrashEntityIDs     = shift;
    my $CrashEntityNames   = shift;
    my $State_Number       = shift;
    my $testCaseName_local = shift;

    my $paraFile_text;
    $paraFile_text .= "## This file is generated using CREIS_PreParT Tool ##\n";
    $paraFile_text .= "## This file is generated from *.mdb: $mdbFileDisplay ##\n";

    for my $crash ( 0 .. $#$State_Number ) {
        for my $state ( 1 .. $$State_Number[$crash] ) {
            my $crashID        = $$CrashEntityIDs[$crash];
            my $crashName      = $$CrashEntityNames[$crash];
            my $crashNameClean = cleanStrings($crashName);

            my $testlist_line = $testCaseName . "." . $crashID . "_" . $crashNameClean . "_State_" . $state;
            $testlist_line = $testCaseName_local . "." . $crashID . "_" . $crashNameClean . "_State_" . $state if defined $testCaseName_local;

            $paraFile_text .= "[$testlist_line]\n";
            $paraFile_text .= "Ubat               = 'U_BATT_DEFAULT'\n";
            $paraFile_text .= "CreisInputFile     = '$mdbFilePath'\n";
            $paraFile_text .= "CrashNumber        = $crashID\n";
            $paraFile_text .= "CrashName          = '$crashName'\n";
            $paraFile_text .= "State              = $state\n";
            $paraFile_text .= "\n";
        }
    }

    return $paraFile_text;
}

sub GetTestListText {
    my $CrashEntityIDs   = shift;
    my $CrashEntityNames = shift;
    my $State_Number     = shift;

    my $testlist_text;
    $testlist_text .= "## This file is generated using CREIS_PreParT Tool ##\n";
    $testlist_text .= "## This file is generated from *.mdb: $mdbFileDisplay ##\n";
    $testlist_text .= "# TestList structure : TC_name.CrashEntityIDs_CrashEntityNames_State_State_Number\n\n";

    if ( $testCaseName eq 'TC_CREIS_MultiCrashes' or $testCaseName eq 'TC_CREIS_FreezeEnv' ) {
        for my $crash ( 0 .. $#$State_Number ) {
            for my $state ( 1 .. $$State_Number[$crash] ) {
                my $crashID        = $$CrashEntityIDs[$crash];
                my $crashName      = $$CrashEntityNames[$crash];
                my $crashNameClean = cleanStrings($crashName);

                my $testlist_line = "TC_CREIS_StandardTest." . $crashID . "_" . $crashNameClean . "_State_" . $state;

                $testlist_text .= $testlist_line . "\n";
            }
        }
        $testlist_text .= "\n";
    }

    for my $crash ( 0 .. $#$State_Number ) {
        for my $state ( 1 .. $$State_Number[$crash] ) {
            my $crashID        = $$CrashEntityIDs[$crash];
            my $crashName      = $$CrashEntityNames[$crash];
            my $crashNameClean = cleanStrings($crashName);

            my $testlist_line = $testCaseName . "." . $crashID . "_" . $crashNameClean . "_State_" . $state;

            $testlist_text .= $testlist_line . "\n";
        }
    }

    return $testlist_text;
}

sub CreateFile {
    my $filePath = shift;
    my $text     = shift;

    open( FILE, ">$filePath" ) || ExitOnError("ERROR :: cannot create / overwrite $filePath file \n");
    print FILE $text;
    close(FILE);

    return 1;
}

sub CreateShortcut {
    my $LINK = Win32::Shortcut->new();
    $LINK->Path(__FILE__);
    $LINK->Description("CREIS_Pre(pare)Par(ameter and)T(estlist) GUI");
    $LINK->WorkingDirectory( dirname(__FILE__) );
    $LINK->IconLocation('%SystemRoot%\System32\shell32.dll');
    $LINK->IconNumber(320);
    $LINK->Save( $projectPath . "\\_CREIS_PreParT.pl.lnk" );
    $LINK->Close();

    return 1;
}

sub CmdLineMode {

    $todo_file_name = File::Spec->rel2abs( dirname($givenMdbPath) . "/CREIS_PreParT_ToDo.txt" );

    ExitOnError("Given mdb @ mdbPath '$givenMdbPath' is not a *.mdb File.") unless $givenMdbPath =~ m/\.mdb$/;
    ExitOnError("Given mdb @ mdbPath '$givenMdbPath' does not exist.") unless -e $givenMdbPath;

    $mdbFilePath = $givenMdbPath;
    if ( $givenSettingsFilePath or ( $givenCreisMappingFilePath and $givenTestCaseName ) ) {

        if ($givenSettingsFilePath) {
            ExitOnError("Given SettingsFile @ givenSettingsFilePath '$givenSettingsFilePath' is not a *.cfg File.") unless $givenSettingsFilePath =~ m/\.cfg$/;
            ExitOnError("Given SettingsFile @ givenSettingsFilePath '$givenSettingsFilePath' does not exist.") unless -e $givenSettingsFilePath;
            $lastSettingsFileFullPath = $givenSettingsFilePath;
            ReadSettingsFile();
        }
        else {
            ExitOnError("Given CREIS mapping @ givenCreisMappingFilePath '$givenCreisMappingFilePath' is not a *.pm File.") unless $givenCreisMappingFilePath =~ m/\.pm$/;
            ExitOnError("Given CREIS mapping @ givenCreisMappingFilePath '$givenCreisMappingFilePath' does not exist.") unless -e $givenCreisMappingFilePath;
            $creisMappingFilePath = $givenCreisMappingFilePath;

            ExitOnError("Given TestCaseName '$givenTestCaseName' is not a valid name for a TurboLIFT test case.") unless $givenTestCaseName =~ m/^\w+$/;
            $testCaseName = $givenTestCaseName;
        }

        if ($givenTestListName) {
            ExitOnError("Given TestListName '$givenTestListName' is not a valid name for a TurboLIFT test list.") unless $givenTestListName =~ m/^\w+$/;
            $testListName = $givenTestListName;
        }
        else {
            my $type    = ( basename( dirname($mdbFilePath) ) );
            my $variant = ( basename( dirname( dirname($mdbFilePath) ) ) );
            $type         = cleanStrings($type);
            $variant      = cleanStrings($variant);
            $testListName = "TL_CREIS_" . $variant . "_" . $type;
        }

        _MDS_Start();
        GenerateParFile_and_TestList();
        CheckCREIS_Mapping();
        _MDS_Close();

        print LOG "\$todo_file_name :: $todo_file_name \n";
        CreateFile( $todo_file_name, $todoFileText );
    }

    return 1;
}

sub CreateAllTemplates {

    my $template_href = {
        TS_Application_SCI => {
            USED_EXEC_OPTION => "DEFAULT_10Iter",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "Appl",
        },
        TS_Algo_01_SCI => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "SCI",
        },
        TS_Algo_02_MultipleEvents => {
            USED_EXEC_OPTION => "DEFAULT_1Iter",
            TEST_CASE_NAME   => "TC_CREIS_MultiCrashes",
            TYPE_FOLDER_NAME => "Multi",
        },
        TS_Algo_03_DCI => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "DCI",
        },
        TS_Algo_04_SCON => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "SCON",
        },
        TS_Algo_05_EnhancedSCON => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "SCON",
        },
        TS_Algo_06_CRI => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "CRI",
        },
        TS_Algo_07_RuntimeSCI => {
            USED_EXEC_OPTION => "Runtime",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "Runtime",
        },
        TS_Algo_08_ESO => {
            USED_EXEC_OPTION => "ESO_AWD",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "ESO",
        },
        TS_Algo_09_AWD => {
            USED_EXEC_OPTION => "ESO_AWD",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "AWD",
        },
        TS_Algo_10_LocMonMain => {
            USED_EXEC_OPTION => "ESO_AWD",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "LocMon",
        },
        TS_Algo_11_LocMonPTS => {
            USED_EXEC_OPTION => "ESO_AWD",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "LocMon",
        },
        TS_Algo_13_FreezeEnv => {
            USED_EXEC_OPTION => "DEFAULT_1Iter",
            TEST_CASE_NAME   => "TC_CREIS_FreezeEnv",
            TYPE_FOLDER_NAME => "Freeze",
        },
        TS_Algo_14_Overload => {
            USED_EXEC_OPTION => "DEFAULT",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "Overload",
        },
        TS_Algo_15_OutputSignals => {
            USED_EXEC_OPTION => "ESO_AWD",
            TEST_CASE_NAME   => "TC_CREIS_StandardTest",
            TYPE_FOLDER_NAME => "OutputSignals",
        },
    };

    my $origSettingsFile = $lastSettingsFile;
    SaveSettingsFile();

    $tempExecOptionFilePath = ".\\Platform\\TestArea_CREIS\\configs\\ExecOptionsCREIS.pm"  if $tempExecOptionFilePath eq "" and not $sccmBasedProject;
    $tempExecOptionFilePath = "..\\Platform\\TestArea_CREIS\\configs\\ExecOptionsCREIS.pm" if $tempExecOptionFilePath eq "" and $sccmBasedProject;

    foreach my $settingsSubset ( keys %{$template_href} ) {
        $lastSettingsFile         = $prefix . $settingsSubset . ".cfg";
        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
        $lastSettingsFileDisplay  = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );

        $tempUsedExecOption = $template_href->{$settingsSubset}{USED_EXEC_OPTION};
        $tempTestCaseName   = $template_href->{$settingsSubset}{TEST_CASE_NAME};
        $tempTypeFolderName = $template_href->{$settingsSubset}{TYPE_FOLDER_NAME};

        SaveSettingsFile();
    }

    $lastSettingsFile         = $origSettingsFile;
    $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
    $lastSettingsFileDisplay  = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );

    ReadSettingsFile();

    ScanAvailableSettingsFiles();

    return 1;
}

sub Add2TodoFile {
    my $line = shift;

    $button_CloseAndShowTodo->configure( -state => 'normal' ) unless defined $todoFileText;

    $todoFileText .= $line;
    print LOG $line;

    return 1;
}

sub ExitOnError {
    my $text = shift;

    print LOG $text;
    close(LOG);
    exit;
}

sub GenerateParFile_and_TestList {
    $status = "Reading $mdbFileDisplay file...";
    $statusBarLabel->update;

    my $filePath = dirname($mdbFilePath);
    my $relativFilePath = ".\\" . File::Spec->abs2rel( $filePath, $projectPath );
    my ( $CrashEntityIDs, $CrashEntityNames, $State_Number ) = _MDS_GetCrashEntityIterations();

    $status = "Create test list and parameter file...";
    $statusBarLabel->update;

    CreateFile( $filePath . "\\" . $testListName . '.txt', GetTestListText( $CrashEntityIDs, $CrashEntityNames, $State_Number ) );
    CreateFile( $filePath . "\\" . $testCaseName . '.par', GetParaFileText( $CrashEntityIDs, $CrashEntityNames, $State_Number ) );
    CreateFile( $filePath . "\\" . 'TC_CREIS_StandardTest.par', GetParaFileText( $CrashEntityIDs, $CrashEntityNames, $State_Number, "TC_CREIS_StandardTest" ) ) if ( $testCaseName eq 'TC_CREIS_MultiCrashes' or $testCaseName eq 'TC_CREIS_FreezeEnv' );

    Add2TodoFile("rem ############################################################\n");
    Add2TodoFile("rem ###  $testListName  ###\n");
    Add2TodoFile("rem ############################################################\n");
    Add2TodoFile( "call " . $engineCall . " ^\n" );
    Add2TodoFile( "    -testlist " . $relativFilePath . "\\" . $testListName . ".txt ^\n" );
    Add2TodoFile( "    -tc_para " . $relativFilePath . "\\ ^\n" );
    Add2TodoFile( "    -conf " . $configFilePath . " ^\n" );
    Add2TodoFile( "    -IC " . $usedInitCampaign . " ^\n" );
    Add2TodoFile( "    -exec_options_file " . $execOptionFilePath . " ^\n" );
    Add2TodoFile( "    -use_exec_options \"" . $usedExecOption . "\" ^\n" );
    Add2TodoFile("    -minimalsnapshot ^\n\n\n");

    $status = "Done!";
    $statusBarLabel->update;
    return 1;
}

# SYNOPSIS
#   openurl <url>
# DESCRIPTION
#   Opens the specified URL in the system's default browser.
# COMPATIBILITY
#   OSX, Windows (including MSYS, Git Bash, and Cygwin), as well as Freedesktop-compliant
#   OSs, which includes many Linux distros (e.g., Ubuntu), PC-BSD, OpenSolaris...
sub OpenURL {
    my $url = shift;
    if ( -e 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe' ) {

        # workaround with 'CMD' because just calling 'start' causes MKS error 'wrong OS' (there is a start.exe in MKS subfolder)
        system( 'CMD /C start "C:\Program Files (x86)\Mozilla Firefox\firefox.exe" ' . "$url" );    # open in Firefox Win7
    }
    elsif ( -e 'C:\Program Files\Mozilla Firefox\firefox.exe' ) {
        system( 'start "C:\Program Files\Mozilla Firefox\firefox.exe" ' . "$url" );                 # open in Firefox
    }

    return 1;
}

sub ShowSettingsWindow {

    $top->deiconify();
    $top->raise();

    return 1;
}

sub SaveSettingsFile {

    # update global settings if changes are saved by user
    $configFilePath       = $tempConfigFilePath;
    $creisMappingFilePath = $tempCreisMappingFilePath;
    $execOptionFilePath   = $tempExecOptionFilePath;
    $usedExecOption       = $tempUsedExecOption;
    $usedInitCampaign     = $tempUsedInitCampaign;
    $testCaseName         = $tempTestCaseName;
    $typeFolderName       = $tempTypeFolderName;

    $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
    $lastSettingsFileDisplay = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );

    #clear read-only flag
    chmod 0755, $lastSettingsFileFullPath;

    #update file content
    open( CFG, ">$lastSettingsFileFullPath" ) || ExitOnError("ERROR :: could not open \$lastSettingsFileFullPath : '$lastSettingsFileFullPath' \n");
    print CFG '$CFG_FILE_PATH = \'' . $configFilePath . "\';\n";
    print CFG '$CREIS_MAPPING_FILE_PATH = \'' . $creisMappingFilePath . "\';\n";
    print CFG '$EXEC_OPTION_FILE_PATH = \'' . $execOptionFilePath . "\';\n";
    print CFG '$USED_EXEC_OPTION = \'' . $usedExecOption . "\';\n";
    print CFG '$USED_INIT_CAMPAIGN = \'' . $usedInitCampaign . "\';\n";
    print CFG '$TEST_CASE_NAME = \'' . $testCaseName . "\';\n";
    print CFG '$TYPE_FOLDER_NAME = \'' . $typeFolderName . "\';\n";

    close(CFG);

    $status = "Settings File saved: $lastSettingsFileDisplay";

    return 1;
}

sub StoreUpdatedCreisMapping {

    my $fileTypes = [ [ "CREIS Mapping file", '.pm' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetSaveAsFilePathAndDirectory( $fileTypes, "Select CREIS Mapping file", $configPath, "Mapping_CREIS_*.pm", "pm" );
    if ($thisFilePath) {
        open( PROJCONST, ">$thisFilePath" ) || ExitOnError("ERROR :: could not overwrite CREIS mapping : '$thisFilePath' \n");
        print PROJCONST "## This file is generated using CREIS Configuration Generator Tool ##\n";
        print PROJCONST "## This file is generated from *.mdb: $mdbFileDisplay ##\n\n";
        print PROJCONST "package LIFT_PROJECT;\n\n";
        $Data::Dumper::Terse = 1;
        $Data::Dumper::Useqq = 1;

        print PROJCONST '$Defaults -> {\'MDSRESULT\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter( $creisMappingContent->{MDSRESULT} );    #sort the hash keys in alphabetical order
        print PROJCONST Dumper( $creisMappingContent->{MDSRESULT} );
        print PROJCONST "\;\n\n";

        print PROJCONST '$Defaults -> {\'CRASH_SIMULATION\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter( $creisMappingContent->{CRASH_SIMULATION} );    #sort the hash keys in alphabetical order
        print PROJCONST Dumper( $creisMappingContent->{CRASH_SIMULATION} );
        print PROJCONST "\;\n\n";

        print PROJCONST '$Defaults -> {\'CRASH_MEASUREMENT_AND_EVALUATION\'} = ';
        $Data::Dumper::Sortkeys = \&hash_sorter( $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION} );    #sort the hash keys in alphabetical order
        print PROJCONST Dumper( $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION} );
        print PROJCONST "\;\n\n";

        foreach my $mappingSectionKey ( keys %{$remainingSections_href} ) {
            print PROJCONST '$Defaults -> {\'' . $mappingSectionKey . '\'} = ';
            $Data::Dumper::Sortkeys = \&hash_sorter( $remainingSections_href->{$mappingSectionKey} );           #sort the hash keys in alphabetical order
            print PROJCONST Dumper( $remainingSections_href->{$mappingSectionKey} );
            print PROJCONST "\;\n\n";
        }

        print PROJCONST "1\;";

        close(PROJCONST);
    }

    return 1;
}

sub SaveSettingsFileAs {

    my $fileTypes = [ [ "CREIS_PreParT Settings file", '.cfg' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetSaveAsFilePathAndDirectory( $fileTypes, "Select CREIS_PreParT Settings file", $settingFilesDirectory, "cfg" );
    if ($thisFilePath) {
        $lastSettingsFile         = basename($thisFilePath);
        $settingFilesDirectory    = dirname($thisFilePath);
        $lastSettingsFileFullPath = $thisFilePath;
        $lastSettingsFileDisplay  = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );
        SaveInitFile();
        SaveSettingsFile();
        ScanAvailableSettingsFiles();
    }

    return 1;

}

sub CancelSettingsFileEdit {

    # update temporary settings if changes are chanceled by user
    $tempConfigFilePath       = $configFilePath;
    $tempCreisMappingFilePath = $creisMappingFilePath;
    $tempExecOptionFilePath   = $execOptionFilePath;
    $tempUsedExecOption       = $usedExecOption;
    $tempUsedInitCampaign     = $usedInitCampaign;
    $tempTestCaseName         = $testCaseName;
    $tempTypeFolderName       = $typeFolderName;

    return 1;
}

sub CheckCREIS_Mapping {

    $forceNewMapping = 0;
    $button_UpdateCreisMapping->configure( -state => 'disabled' );

    CheckCREIS_Mapping__ReadTemplate();
    CheckCREIS_Mapping__ReadMapping();
    CheckCREIS_Mapping__MdsResults();
    CheckCREIS_Mapping__SensorDetails();
    CheckCREIS_Mapping__Environments();
    CheckCREIS_Mapping__SimDevices();
    CheckCREIS_Mapping__GeneralSettings();
    CheckCREIS_Mapping__Faults();
    CheckCREIS_Mapping__FastDiag();
    CheckCREIS_Mapping__AdditionalPdLabels();
    CheckCREIS_Mapping__AdditionalMeasurements();

    if ($forceNewMapping) {
        $button_UpdateCreisMapping->configure( -state => 'normal' );
    }
}

sub CheckCREIS_Mapping__AdditionalMeasurements {
    unless ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'AdditionalMeasurements'} ) {
        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'AdditionalMeasurements'} = {};
        Add2TodoFile("TODO :: AdditionalMeasurements - Mapping updated with settings template for 'AdditionalMeasurements'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__AdditionalPdLabels {
    foreach my $additionalPdLabelsReaderSettingsKey ( sort keys %{ $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{AdditionalPdLabels} } ) {
        next if ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'AdditionalPdLabels'}{$additionalPdLabelsReaderSettingsKey} );

        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'AdditionalPdLabels'}{$additionalPdLabelsReaderSettingsKey} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{$additionalPdLabelsReaderSettingsKey};
        Add2TodoFile("TODO :: AdditionalPdLabels - Mapping updated with settings template for 'AdditionalPdLabels'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__FastDiag {
    foreach my $fastDiagSettingsKey ( sort keys %{ $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{FastDiagTrace} } ) {
        next if ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'FastDiagTrace'}{$fastDiagSettingsKey} );

        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'FastDiagTrace'}{$fastDiagSettingsKey} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{$fastDiagSettingsKey};
        Add2TodoFile("TODO :: FastDiagTrace - Mapping updated with settings template for 'FastDiagTrace'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__Faults {
    foreach my $faultEvaluationSettingsKey ( sort keys %{ $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{Faults} } ) {
        next if ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'Faults'}{$faultEvaluationSettingsKey} );

        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'Faults'}{$faultEvaluationSettingsKey} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{$faultEvaluationSettingsKey};
        Add2TodoFile("TODO :: Faults - Mapping updated with settings template for 'Faults'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }

    if ( ref( $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'Faults'}{'AdditionalAfterCrash'}{'Generic'} ) eq 'ARRAY' ) {
        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'Faults'}{'AdditionalAfterCrash'}{'Generic'} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{AdditionalAfterCrash}{Generic};
        Add2TodoFile("TODO :: Faults - Mapping section updated: 'AdditionalAfterCrash - Generic'. Check content and adapt if needed!!!\n");
        Add2TodoFile( "                                        : " . 'https://inside-docupedia.bosch.com/confluence/display/aeos/Faults#Faults-new(CREIS_V6_x)' . "\n" );
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__GeneralSettings {

    foreach my $generalSettingsKey ( sort keys %{ $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{General_Settings} } ) {
        next if ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{$generalSettingsKey} );

        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{$generalSettingsKey} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{General_Settings}{$generalSettingsKey};
        Add2TodoFile("TODO :: General_Settings - Mapping updated with General_Setting '$generalSettingsKey'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }

    if ( $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{'EDRnumberOfEventsPEP'} eq 'SYC' ) {
        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{'EDRnumberOfEventsPEP'} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{General_Settings}{'EDRnumberOfEventsPEP'};
        Add2TodoFile("TODO :: General_Settings - Mapping updated with General_Setting 'EDRnumberOfEventsPEP'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }

    if ( $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{'EDRnumberOfEvents'} eq 'SYC' ) {
        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'General_Settings'}{'EDRnumberOfEvents'} = $creisMappingTemplate->{CRASH_MEASUREMENT_AND_EVALUATION}{General_Settings}{'EDRnumberOfEvents'};
        Add2TodoFile("TODO :: General_Settings - Mapping updated with General_Setting 'EDRnumberOfEvents'. Check content and use updated Mapping!!!\n");
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__SimDevices {
    my $SimDevices_aref = _MDS_GetSimDeviceDetails();

    foreach my $Output_Device ( sort @$SimDevices_aref ) {
        next if ( exists $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'SimDevices'}{$Output_Device} );

        $creisMappingContent->{CRASH_MEASUREMENT_AND_EVALUATION}{'SimDevices'}{$Output_Device} = "<<TODO>>";
        Add2TodoFile("TODO :: Fill mapping for SimDevices '$Output_Device'. \n");
        $forceNewMapping = 1;
    }
}

sub CheckCREIS_Mapping__Environments {

    my $allEnv_href = _MDS_GetEnvironmentDetails();

    if ( exists $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{'RESET'} ) {
        delete $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{'RESET'};
        Add2Todo("TODO :: ENVIRONMENT - Section 'RESET' is obsolete and has been removed!!!\n");
        $forceNewMapping = 1;
    }

    if ( exists $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{'SENSORS'} ) {
        delete $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{'SENSORS'};
        Add2Todo("TODO :: ENVIRONMENT - Section 'SENSORS' is obsolete and has been removed!!!\n");
        $forceNewMapping = 1;
    }

    foreach my $envName ( sort keys %{ $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'} } ) {
        next unless exists $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory};
        next unless $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory};
        next if exists $allEnv_href->{$envName};
        Add2TodoFile("TODO :: ENVIRONMENT - Mandatory Environment '$envName' not selected as 'CREIS relevant'. Given MDB should not be used without clarification! \n");
    }

    foreach my $envName ( sort keys %$allEnv_href ) {

        next if ( exists $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName} );

        # environments defined in TODO template mapping will be directly copied from template
        if ( exists $creisMappingEnvPrototypes->{TODO}{$envName} ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName} = $creisMappingEnvPrototypes->{TODO}{$envName};

            Add2TodoFile("TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'.\n");
            $forceNewMapping = 1;
        }

        # environments defined in DONE template mapping will be directly copied from template
        elsif ( exists $creisMappingEnvPrototypes->{DONE}{$envName} ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName} = $creisMappingEnvPrototypes->{DONE}{$envName};

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # elements ending with ErrStart or ErrEnd or OverloadStart or OverloadEnd can be ignored
        elsif ( $envName =~ /(ErrStart|ErrEnd|OverloadStart|OverloadEnd|Source)$/ ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}   = "Parameter";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory} = 1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Text}      = "Parameter for other environments.";

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'Env...'
        elsif ( $envName =~ /^ Env (\w+) $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}             = "NetSignal";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}           = 1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{NetworkType}         = "<<TODO>>";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SignalName}          = "<<TODO>>";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Force4eachIteration} = 1;

            if ( $envName =~ /^ Env (\w+) Valid $/ix ) {
                $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SignalMapping_Mdb2Net} = {
                    0 => "<<TODO: NET value for signal invalid>>",
                    1 => "<<TODO: NET value for signal valid>>"
                };
            }
            else {
                $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SignalMapping_Mdb2Net} = {};
            }
            Add2TodoFile("TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n");
            $forceNewMapping = 1;
        }

        # check for 'Switch_..._State'
        elsif ( $envName =~ /^ Switch_ (\w+) _State $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}                     = "SwitchState";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Source4SwitchValue}          = 'SYC';
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchState';

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'Switch_..._Diagnosable'
        elsif ( $envName =~ /^ Switch_ (\w+) _Diagnosable $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}                     = "Parameter";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Text}                        = "Diagnosable attribute of a switch is a variant configuration and should not be changed during testing.";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchDiagnosable';

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'Switch_..._Configured'
        elsif ( $envName =~ /^ Switch_ (\w+) _Configured $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}                     = "SwitchConfiguration";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}                   = 1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SwitchName}                  = $1;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Verify}{EnvVerificationType} = 'SwitchConfiguration';

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'Ps...ErrBehaviour'
        elsif ( $envName =~ /^ Ps (\w+) ErrBehaviour $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}    = "ExternalSensorError";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}  = 0;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SensorName} = $1;

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'Ps...Configured'
        elsif ( $envName =~ /^ Ps (\w+) Configured $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}    = "ExternalSensorConfiguration";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory}  = 0;
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{SensorName} = $1;

            Add2TodoFile("TODO :: ENVIRONMENT - Mapping updated with Environment '$envName'. Use updated Mapping!!!\n");
            $forceNewMapping = 1;
        }

        # check for 'CsEcu...OverloadBhvr'
        elsif ( $envName =~ /^ CsEcu (\w+) OverloadBhvr $/ix ) {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}   = "<<TODO>>";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory} = 0;

            Add2TodoFile("TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n");
            $forceNewMapping = 1;
        }
        else {
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{EnvType}   = "<<TODO>>";
            $creisMappingContent->{CRASH_SIMULATION}{'ENVIRONMENT'}{$envName}{Mandatory} = 0;

            Add2TodoFile("TODO :: ENVIRONMENT - Fill mapping for Environment '$envName'. \n");
            $forceNewMapping = 1;
        }
    }
}

sub CheckCREIS_Mapping__SensorDetails {

    my ( $ModuleName, $SensorName, $SensorDirection, $SensorType ) = _MDS_GetSensorDetails();

    for my $ndx ( 0 .. $#$SensorDirection ) {

        my $Input_keys   = qq/$$ModuleName[$ndx]: $$SensorName[$ndx]: $$SensorDirection[$ndx]: $$SensorType[$ndx]/;
        my $Input_values = qq/<<TODO: $$ModuleName[$ndx]_$$SensorName[$ndx] >>/;

        next if ( exists $creisMappingContent->{CRASH_SIMULATION}{'STIMULATION'}{'CRASH_SENSORS'}{$Input_keys} );
        next if ( exists $creisMappingContent->{CRASH_SIMULATION}{'STIMULATION'}{'NETWORK_DYNAMIC'}{$Input_keys} );

        if ( $$SensorDirection[$ndx] eq "Bus" ) {
            $creisMappingContent->{CRASH_SIMULATION}{'STIMULATION'}{'NETWORK_DYNAMIC'}{$Input_keys} = $Input_values;
            Add2TodoFile("TODO :: NETWORK_DYNAMIC - Fill mapping for NETWORK_DYNAMIC '$Input_keys' \n");
        }
        else {
            $creisMappingContent->{CRASH_SIMULATION}{'STIMULATION'}{'CRASH_SENSORS'}{$Input_keys} = $Input_values;
            Add2TodoFile("TODO :: CRASH_SENSOR - Fill mapping for CRASH_SENSOR '$Input_keys' \n");
        }

        $forceNewMapping = 1;

    }
}

sub CheckCREIS_Mapping__MdsResults {

    unless ( defined $creisMappingContent->{MDSRESULT}{"RESULTS"}{"DEFAULT"} ) {
        print LOG "ERROR :: CREIS_Mapping: Missing key { MDSRESULT }{ RESULTS }{ DEFAULT }.  A new CREIS Mapping file should be created! \n";
        $forceNewMapping = 1;
    }

    $creisMappingContent->{MDSRESULT}{"RESULTS"}{"DEFAULT"}{"PATH"}    = $mdbFilePath;
    $creisMappingContent->{MDSRESULT}{"RESULTS"}{"DEFAULT"}{"MDSTYPE"} = "MDSNG";

    return 1;
}

sub CheckCREIS_Mapping__ReadTemplate {
    no warnings;
    require '.\Mapping_CREIS_Template.pm';

    $creisMappingTemplate      = $CREIS_MAPPING_TEMPLATE::Defaults;
    $creisMappingEnvPrototypes = $CREIS_MAPPING_TEMPLATE::EnvPrototypes;
}

sub CheckCREIS_Mapping__ReadMapping {
    my (@missingSections);
    my $creisMappingFilePath_absolut = $projectPath . $creisMappingFilePath;
    my @sectionList                  = qw(CRASH_SIMULATION CRASH_MEASUREMENT_AND_EVALUATION MDSRESULT);

    if ( $creisMappingFilePath ne "" and -e $creisMappingFilePath_absolut ) {
        eval( require $creisMappingFilePath_absolut );

        if ($@) {
            print LOG "ERROR :: CREIS_Mapping: Selected CREIS mapping could not be loaded. A new CREIS Mapping file should be created! \n";
            print LOG "               error text: $@ \n";
        }
    }

    foreach my $mappingSectionKey ( keys %{$LIFT_PROJECT::Defaults} ) {
        next if $mappingSectionKey eq 'CRASH_SIMULATION';
        next if $mappingSectionKey eq 'CRASH_MEASUREMENT_AND_EVALUATION';
        next if $mappingSectionKey eq 'MDSRESULT';
        $remainingSections_href->{$mappingSectionKey} = $LIFT_PROJECT::Defaults->{$mappingSectionKey};
    }

    foreach my $sectionKey (@sectionList) {
        next if ( $creisMappingContent->{$sectionKey} = $LIFT_PROJECT::Defaults->{$sectionKey} );
        push @missingSections, $sectionKey;
        print LOG "ERROR :: CREIS_Mapping: Missing section Defaults->{'$sectionKey'}. A new CREIS Mapping file should be created! \n";
        $forceNewMapping = 1;
    }

    return 1;
}

sub CloseAndShowToDo {
    print LOG "\$todo_file_name :: $todo_file_name \n";
    close(LOG);
    CreateFile( $todo_file_name, $todoFileText );
    system("explorer.exe \"$todo_file_name\"");

    exit;

    return 1;
}

sub SaveInitFile {

    open( INI, ">CREIS_PReParT.ini" ) || ExitOnError("ERROR :: could not open CREIS_PReParT.ini \n");
    print INI '$MDB_DIRECTORY = \'' . $mdbDirectory . "\';\n";
    print INI '$LAST_SETTINGS_FILE = \'' . $lastSettingsFile . "\';\n";
    print INI '$SETTINGS_FILES_DIRECTORY = \'' . $settingFilesDirectory . "\';\n";

    close(INI);
    return 1;
}

sub ReadSettingsFile {
    $tempTypeFolderName = "";
    $typeFolderName     = "";

    if ( -e $lastSettingsFileFullPath ) {
        { package Config; do $lastSettingsFileFullPath };
        $tempConfigFilePath       = $Config::CFG_FILE_PATH;
        $tempCreisMappingFilePath = $Config::CREIS_MAPPING_FILE_PATH;
        $tempExecOptionFilePath   = $Config::EXEC_OPTION_FILE_PATH;
        $tempUsedExecOption       = $Config::USED_EXEC_OPTION;
        $tempUsedInitCampaign     = $Config::USED_INIT_CAMPAIGN;
        $tempTestCaseName         = $Config::TEST_CASE_NAME;
        $tempTypeFolderName       = $Config::TYPE_FOLDER_NAME;

        $configFilePath       = $Config::CFG_FILE_PATH;
        $creisMappingFilePath = $Config::CREIS_MAPPING_FILE_PATH;
        $execOptionFilePath   = $Config::EXEC_OPTION_FILE_PATH;
        $usedExecOption       = $Config::USED_EXEC_OPTION;
        $usedInitCampaign     = $Config::USED_INIT_CAMPAIGN;
        $testCaseName         = $Config::TEST_CASE_NAME;
        $typeFolderName       = $Config::TYPE_FOLDER_NAME;
    }
    else {
        SaveSettingsFile();
    }

    return 1;
}

sub ReadInitFile {

    if ( -e "CREIS_PReParT.ini" ) {
        { package Init; do "CREIS_PReParT.ini" };
        $mdbDirectory          = $Init::MDB_DIRECTORY;
        $lastSettingsFile      = $Init::LAST_SETTINGS_FILE;
        $settingFilesDirectory = $Init::SETTINGS_FILES_DIRECTORY;

        $mdbDirectory          = $Init::MDB_DIRECTORY;
        $lastSettingsFile      = $Init::LAST_SETTINGS_FILE;
        $settingFilesDirectory = $Init::SETTINGS_FILES_DIRECTORY;

        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
        $lastSettingsFileDisplay = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );
    }
    else {
        $mdbDirectory = $projectPath;

        $lastSettingsFile         = "default.cfg";
        $settingFilesDirectory    = $configPath . "\\CREIS_PreParT_SettingFiles";
        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
        $lastSettingsFileDisplay  = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );

        unless ( -e $settingFilesDirectory or mkdir $settingFilesDirectory ) {
            ExitOnError("ERROR :: Unable to create $settingFilesDirectory \n");
        }

        SaveInitFile();
    }

    return 1;
}

sub GetFilePathAndDirectory {
    my $filetypes_aref   = shift;
    my $fileOpenTitle    = shift;
    my $initialDirectory = shift;
    my $initialFile      = shift;

    if ( not defined $initialDirectory ) {
        $initialDirectory = '.';
    }

    if ( not defined $fileOpenTitle ) {
        $fileOpenTitle = "Open File";
    }

    my $thisFilePath = $main->getOpenFile(
        -filetypes   => $filetypes_aref,
        -title       => $fileOpenTitle,
        -initialdir  => $initialDirectory,
        -initialfile => $initialFile,
    );

    my $thisDirectory;
    if ($thisFilePath) {
        my $path = dirname($thisFilePath);
        $thisDirectory = $path . "/";
    }
    else {
        return;
    }

    return ( $thisFilePath, $thisDirectory );
}

sub GetSaveAsFilePathAndDirectory {
    my $filetypes_aref   = shift;
    my $fileOpenTitle    = shift;
    my $initialDirectory = shift;
    my $defaultExtension = shift;

    if ( not defined $initialDirectory ) {
        $initialDirectory = '.';
    }

    if ( not defined $fileOpenTitle ) {
        $fileOpenTitle = "Open File";
    }

    my $thisFilePath = $main->getSaveFile(
        -filetypes        => $filetypes_aref,
        -title            => $fileOpenTitle,
        -initialdir       => $initialDirectory,
        -defaultextension => $defaultExtension,
    );

    my $thisDirectory;
    if ($thisFilePath) {
        my $path = dirname($thisFilePath);
        $thisDirectory = $path . "/";
    }
    else {
        return;
    }

    return ( $thisFilePath, $thisDirectory );
}

sub GetConfigFileName {

    my $fileTypes = [ [ "CFG file", '.pm' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetFilePathAndDirectory( $fileTypes, "Select project CFG file", $configPath, "*CFG.pm" );
    if ($thisFilePath) {
        $tempConfigFilePath = ".\\" . File::Spec->abs2rel( $thisFilePath, $projectPath );
    }

    $top->raise();

    return 1;
}

sub GetCreisMappingFile {

    my $fileTypes = [ [ "CREIS Mapping file", '.pm' ], [ "All files", '.*' ] ];
    my $creisMappingConfigPath = $configPath;
    $creisMappingConfigPath = $configPath . "\\Mappings" if -e $configPath . "\\Mappings";
    my ( $thisFilePath, $thisDirectory ) = GetFilePathAndDirectory( $fileTypes, "Select CREIS Mapping file", $creisMappingConfigPath, "Mapping_CREIS_*.pm" );
    if ($thisFilePath) {
        $tempCreisMappingFilePath = ".\\" . File::Spec->abs2rel( $thisFilePath, $projectPath );
    }

    $top->raise();

    return 1;
}

sub GetExecOptionsFile {

    my $fileTypes = [ [ "Exec Options file", '.pm' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetFilePathAndDirectory( $fileTypes, "Select Exec Options file", $configPath, "ExecOptionsCREIS*.pm" );
    if ($thisFilePath) {
        $tempExecOptionFilePath = ".\\" . File::Spec->abs2rel( $thisFilePath, $projectPath );
    }

    $top->raise();

    return 1;
}

sub GetSettingsFileName {

    my $fileTypes = [ [ "CREIS_PreParT Settings file", '.cfg' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetFilePathAndDirectory( $fileTypes, "Select CREIS_PreParT Settings file", $settingFilesDirectory, "*.cfg" );
    if ($thisFilePath) {
        $lastSettingsFile      = basename($thisFilePath);
        $settingFilesDirectory = dirname($thisFilePath);

        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $lastSettingsFile;
        $lastSettingsFileDisplay = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );
        ReadSettingsFile();
        SaveInitFile();
        $status = "New Settings File: $lastSettingsFileDisplay";
        $statusBarLabel->update;

        ScanAvailableSettingsFiles();
    }

    $top->raise();

    return 1;
}

sub GetMatchingSettingsFile {

    my $defaultSettingsFile;

    $lastSettingsFile = undef;

    foreach my $settingsFile ( sort @$availableSettingsFiles_aref ) {
        $lastSettingsFileFullPath = $settingFilesDirectory . "\\" . $settingsFile;
        $lastSettingsFileDisplay = ".\\" . File::Spec->abs2rel( $lastSettingsFileFullPath, $projectPath );
        ReadSettingsFile();
        my $type = ( basename( dirname($mdbFilePath) ) );

        # default RegExp detected --> not to be used for matching
        if ( $typeFolderName eq "" ) {
            $defaultSettingsFile = $settingsFile unless defined $defaultSettingsFile;
            next;
        }

        if ( $type =~ /.*$typeFolderName.*/ ) {
            $lastSettingsFile = $settingsFile;
            last;
        }
    }

    unless ( defined $lastSettingsFile ) {
        $lastSettingsFile = $defaultSettingsFile;
    }

    return 1;
}

sub ScanAvailableSettingsFiles {

    opendir( DIR, $settingFilesDirectory );
    my @files = grep( /\.cfg$/, readdir(DIR) );
    closedir(DIR);

    $availableSettingsFiles_aref = \@files;
    $om_activeSettings->configure( -options => $availableSettingsFiles_aref ) if defined $om_activeSettings;
}

sub GetMdbFileName {

    my $fileTypes = [ [ "MDS DataBase", '.mdb' ], [ "All files", '.*' ] ];
    my ( $thisFilePath, $thisDirectory ) = GetFilePathAndDirectory( $fileTypes, "Choose a .mdb file(*.mdb)", $mdbDirectory, "*.mdb" );

    # first check if the .mdb file is selected else throw a message asking for the .mdb file
    if ( $thisFilePath =~ /\.mdb$/ ) {
        $mdbFilePath  = $thisFilePath;
        $mdbDirectory = dirname( dirname( dirname($mdbFilePath) ) );

        SaveInitFile();

        print LOG "mdb File Chosen :: $mdbFilePath \n";
        my $mdbBaseName = basename($mdbFilePath);
        my $type        = ( basename( dirname($mdbFilePath) ) );
        my $variant     = ( basename( dirname( dirname($mdbFilePath) ) ) );
        my $mainFolder  = ( basename( dirname( dirname( dirname($mdbFilePath) ) ) ) );
        $mdbFileDisplay = ".\\$mainFolder\\$variant\\$type\\$mdbBaseName";
        $type           = cleanStrings($type);
        $variant        = cleanStrings($variant);
        $testListName   = "TL_CREIS_" . $variant . "_" . $type;
        $todo_file_name = File::Spec->rel2abs( dirname($mdbFilePath) . "/CREIS_PreParT_ToDo.txt" );
        $button_GenerateFiles->configure( -state => 'normal' );
        $status = "MDB-File selected: $mdbBaseName";
        $statusBarLabel->update;

        GetMatchingSettingsFile();
    }
    else {
        $main->messageBox(
            '-icon'    => "error",               #qw/error info question warning/
            '-type'    => "OK",                  #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-message' => "!Select .mdb file!"
        );
        $button_GenerateFiles->configure( -state => 'disabled' );
    }

    return 1;
}

sub cleanStrings {
    my $string = shift;

    $string =~ s/�/ae/g;
    $string =~ s/�/oe/g;
    $string =~ s/�/ue/g;
    $string =~ s/�/Ae/g;
    $string =~ s/�/Oe/g;
    $string =~ s/�/Ue/g;
    $string =~ s/�/ss/g;
    $string =~ s/\W/\_/g;
    $string =~ s/_+/_/g;

    return $string;
}

sub hash_sorter {
    my ($hash) = @_;
    return ( sort keys %$hash );
}

__END__
