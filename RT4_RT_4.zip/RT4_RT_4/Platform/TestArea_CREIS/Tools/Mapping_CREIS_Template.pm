package CREIS_MAPPING_TEMPLATE;

$Defaults = {
    MDSRESULT => {
        RESULTS => {
            DEFAULT => {
                MDSTYPE => "MDSNG",
                PATH    => "DUMMY_DEFAULT.mdb"
            },
        },
    },
    CRASH_SIMULATION => {
        ENVIRONMENT => {},
        STIMULATION => {
            CRASH_SENSORS => {},
        },
    },
    CRASH_MEASUREMENT_AND_EVALUATION => {
        General_Settings => {
            "DisposalTime_ms"                   => 300,
            "EDRnumberOfEvents"                 => "SAD",
            "EDRnumberOfEventsPEP"              => "SAD",
            "FiringCurrentThresholdTolerance_A" => "0.2",
            "FiringCurrentThreshold_A"          => "0.5",
            "SamplingFrequency_Hz"              => 20 * 1000,
        },
        SimDevices             => {},
        AdditionalMeasurements => {},
        Faults                 => {
            "BeforeCrash" => {
                "Generic"              => [],
                "EnvironmentDependent" => {     # "mandatory" faults before crash
                    rb_swm_OpenLineBLFD_flt    => '#Switch_BLFD_Configured|1 == 1 and #Switch_BLFD_State == 3',
                    rb_swm_UndefinedBLFD_flt   => '#Switch_BLFD_State == 2',
                    rb_swm_UnexpectedBLFD_flt  => '#Switch_BLFD_Configured|1 == 0 and not #Switch_BLFD_State == 3',
                    rb_swm_OpenLineBLFP_flt    => '#Switch_BLFP_Configured|1 == 1 and #Switch_BLFP_State == 3',
                    rb_swm_UndefinedBLFP_flt   => '#Switch_BLFP_State == 2',
                    rb_swm_UnexpectedBLFP_flt  => '#Switch_BLFP_Configured|1 == 0 and not #Switch_BLFP_State == 3',
                    rb_swm_OpenLineBLRC_flt    => '#Switch_BLRC_Configured|1 == 1 and #Switch_BLRC_State == 3',
                    rb_swm_UndefinedBLRC_flt   => '#Switch_BLRC_State == 2',
                    rb_swm_UnexpectedBLRC_flt  => '#Switch_BLRC_Configured|1 == 0 and not #Switch_BLRC_State == 3',
                    rb_swm_OpenLineBLRD_flt    => '#Switch_BLRD_Configured|1 == 1 and #Switch_BLRD_State == 3',
                    rb_swm_UndefinedBLRD_flt   => '#Switch_BLRD_State == 2',
                    rb_swm_UnexpectedBLRD_flt  => '#Switch_BLRD_Configured|1 == 0 and not #Switch_BLRD_State == 3',
                    rb_swm_OpenLineBLRP_flt    => '#Switch_BLRP_Configured|1 == 1 and #Switch_BLRP_State == 3',
                    rb_swm_UndefinedBLRP_flt   => '#Switch_BLRP_State == 2',
                    rb_swm_UnexpectedBLRP_flt  => '#Switch_BLRP_Configured|1 == 0 and not #Switch_BLRP_State == 3',
                    rb_swm_OpenLineOPSFP_flt   => '#Switch_OPSFP_Configured|1 == 1 and #Switch_OPSFP_State == 3',
                    rb_swm_UndefinedOPSFP_flt  => '#Switch_OPSFP_State == 2',
                    rb_swm_UnexpectedOPSFP_flt => '#Switch_OPSFP_Configured|1 == 0 and not #Switch_OPSFP_State == 3',
                    rb_swm_OpenLinePADS1_flt   => '#Switch_PADS_Configured|1 == 1 and #Switch_PADS_State == 3',
                    rb_swm_UndefinedPADS1_flt  => '#Switch_PADS_State == 2',
                    rb_swm_UnexpectedPADS1_flt => '#Switch_PADS_Configured|1 == 0 and not #Switch_PADS_State == 3',
                    rb_swm_OpenLineSPSFD_flt   => '#Switch_SPSFD_Configured|1 == 1 and #Switch_SPSFD_State == 3',
                    rb_swm_UndefinedSPSFD_flt  => '#Switch_SPSFD_State == 2',
                    rb_swm_UnexpectedSPSFD_flt => '#Switch_SPSFD_Configured|1 == 0 and not #Switch_SPSFD_State == 3',
                },
            },
            "AdditionalAfterCrash" => {
                "Generic" => {
                    "EventManagerFault" => {
                        "FaultName" => "rb_evm_.*CrashDetected_flt"
                    },
                    "CsemMonTempFaults_Clipping" => {
                        "EventDebugData" => "0b0000000100000000",
                        "FaultName"      => "rb_csem_MonTemp.*_flt"
                    },
                },
                "CrashDependent" => {},
            },
        },
        FastDiagTrace => {
            "NbrOfCanIDs"    => 4,
            "Configurations" => {
                "AlgoActive" => {
                    "rb_fcl_StatusFirCtrl_u8" => "U8",
                },
            },
        },
        AdditionalPdLabels => {
            "Configurations" => {
                "PomAdcData" => {
                    "VBat1" => {
                        "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vbat1_u16",
                        "Mode"    => "dec",
                        "Factor"  => 0.01,
                        "Unit"    => "V",
                    },
                    "Ver" => {
                        "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Ver_u16",
                        "Mode"    => "dec",
                        "Factor"  => 0.01,
                        "Unit"    => "V",
                    },
                    "Temperature_ASIC1" => {
                        "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Temperature_s32",
                        "Mode"    => "dec",
                        "Factor"  => 0.1,
                        "Unit"    => "C",
                    },
                    "Temperature_ASIC2" => {
                        "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(1).Temperature_s32",
                        "Mode"    => "dec",
                        "Factor"  => 0.1,
                        "Unit"    => "C",
                    },
                    "Vup" => {
                        "PdLabel" => "rb_pomv_PomAdcData_st.AdcValuesConverted_ast(0).Vup_u16",
                        "Mode"    => "dec",
                        "Factor"  => 0.01,
                        "Unit"    => "V",
                    },
                },
            },
        },
    },
};

$EnvPrototypes = {
    TODO => {
        "EnvAmbientTemp" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "degC",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (degCelsius) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvAmbientTemp_Source",
            "SourceMapping"        => {
                0 => "TEMPERATURE_degCelsius",
                1 => "EnvAmbientTemp"
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_AmbientTemp_s8",
                "Factor_LsbPdLabel2Mdb"     => 1,
                "Tolerance"                 => 1,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvAmbientTempValid",
            },
        },
        "EnvAmbientTempValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvAmbientTemp'",
            },
        },
        "EnvEgoVelocity" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "km/h",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (km/h) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvEgoVelocity_Source",
            "SourceMapping"        => {
                0 => "VELOCITY_X_kmh",
                1 => "VELOCITY_kmh",
                2 => "EnvEgoVelocity",
                3 => undef
            },
            "ResetValue" => 0,
            "Verify"     => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_EgoVelocity_u16",
                "Factor_LsbPdLabel2Mdb"     => 0.125,
                "Tolerance"                 => 0.125,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvEgoVelocityValid",
            },
        },
        "EnvEgoVelocityValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvEgoVelocity'",
            },
        },
        "EnvVehicleSpeed" => {
            "EnvType"              => "NetSignal",
            "EnvUnit_Mdb"          => "km/h",
            "Force4eachIteration"  => 1,
            "Mandatory"            => 1,
            "NetworkType"          => "<<TODO: CAN|FR|LIN>>",
            "SignalFactor_Mdb2Net" => "<<TODO: conversion factor between MDB (km/h) to NET signal>>",
            "SignalUnit_Net"       => "<<TODO: unit of NET signal>>",
            "SignalName"           => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "SourceEnvironment"    => "EnvVelocity_Source",
            "SourceMapping"        => {
                0 => "VELOCITY_kmh",
                1 => "EnvVehicleSpeed",
                2 => undef
            },
            "ResetValue" => 0,
            "Verify"     => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_EgoVelocity_u16",
                "Factor_LsbPdLabel2Mdb"     => 0.125,
                "Tolerance"                 => 0.125,
                "SignalMapping_Mdb2PdLabel" => {
                    INVALID => 65534,
                },
                "ValidityEnvironment" => "EnvVehicleSpeedValid",
            },
        },
        "EnvVehicleSpeedValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvVehicleSpeed'",
            },
        },
        "EnvVehicleDrivingDir" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "CAN",
            "SignalName"            => "VSD_VehicleDrivingDirection",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for forward>>",
                1 => "<<TODO: NET value for backward>>",
            },
            "Verify" => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_cia_DrivingDirection_u8",
                "SignalMapping_Mdb2PdLabel" => {
                    0       => 0,
                    1       => 1,
                    INVALID => 3,
                },
                "ValidityEnvironment" => "EnvVehicleDrivingDirValid",
            },
        },
        "EnvVehicleDrivingDirValid" => {
            "EnvType"               => "NetSignal",
            "Force4eachIteration"   => 1,
            "Mandatory"             => 1,
            "NetworkType"           => "<<TODO: CAN|FR|LIN>>",
            "SignalMapping_Mdb2Net" => {
                0 => "<<TODO: NET value for signal invalid>>",
                1 => "<<TODO: NET value for signal valid>>",
            },
            "SignalName" => "<<TODO: name of NET signal as in CAN|FR|LIN mapping>>",
            "Verify"     => {
                "EnvVerificationType" => "Parameter",
                "Text"                => "Verified with verification of 'EnvVehicleDrivingDir'",
            },
        },
        "Switch_OCS_Configured" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS configuration. Check CREIS Wiki>>",
        },
        "Switch_OCS_State" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS States. Check CREIS Wiki>>",
        },
        "Switch_OCS_Diagnosable" => {
            "EnvType" => "<<TODO: Find a EnvironmentType for implementing OCS Diagnosable. Check CREIS Wiki>>",
        },
    },
    DONE => {
        "Config_RightHandDriver" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 1,
            "SpecialBitName" => "IsRightHandDriver",
            "Verify"         => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_siam_DriverConfigSign_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => -1,
                },
            },
        },
        "FCLConfSystem_DriverRight" => {
            "EnvType"        => "SpecialBehaviourBit",
            "Mandatory"      => 1,
            "SpecialBitName" => "IsRightHandDriver",
            "Verify"         => {
                "EnvVerificationType"       => "PdLabel",
                "PdLabel"                   => "rb_siam_DriverConfigSign_s8",
                "SignalMapping_Mdb2PdLabel" => {
                    0 => 1,
                    1 => -1,
                },
            },
        },
    },
};
