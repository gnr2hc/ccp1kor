#!usr\bin\perl.exe -w
# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

use strict;
use Tk;
use Tk::Table;
use Tk::DirTree;
use Data::Dumper;
use warnings;
use File::Basename;
use Data::Dumper;
use Win32::Console::ANSI;
use Term::ANSIColor;

my $addpath;

BEGIN {
    use Config;
    use File::Spec;
    use File::Basename;

    my $LIFT_exec_path = File::Spec->rel2abs( dirname( dirname( dirname( dirname(__FILE__) ) ) ) ) . "/Engine";
    unshift @INC, "$LIFT_exec_path/modules/";
    unshift @INC, "$LIFT_exec_path/modules/Common_library/";
    unshift @INC, "$LIFT_exec_path/modules/Device_layer/MDSRESULT";

    my $LIFT_TestAreaEnginePath = File::Spec->rel2abs( dirname( dirname(__FILE__) ) ) . "/Engine";
    unshift @INC, "$LIFT_TestAreaEnginePath";

}

use strict;
use warnings;
use Cwd;
use FuncLib_CREIS_xlsxReporting;
use Pod::Usage;
use Getopt::Long;

=head1 NAME

CreateXLSXreport.pl

=head1 SYNOPSIS

CreateXLSXreport.pl [Options]


 E.g. 
 
    GUI Mode:
        CreateXLSXreport.pl
        
    HELP Mode:
        CreateXLSXreport.pl -?
        
    CMD-line Mode:
        CreateXLSXreport.pl ^
           -x C:\sandboxes\TurboLIFT_Bosch_Engine_development\SDW2BUE\tools_TurboLIFT\Custlib\CREIS\M03_18_RT4\SCI_04B034\SCI_M03_17_RT4_04B034_20191202.xml
	
 Options:
   --help|-?                          display tool documentation
   --xmlFilePath|-x  <path>           define path to *.xml file

=head1 OPTIONS

=over

=item --help|-?

Displays the tool documentation

=item --xmlFilePath|-m  <path>

Defines the path to *.mdb file.
If this option or help option is not given, the tool will start in GUI mode for manual usage.

=back

=head1 DESCRIPTION

This tool is used to create the CREIS XLSX report from an existing *.XML file (which was created during CREIS run).
It can be used to create the XLSX reporting during a running crash injection to see the status of the tests.
Or it can be used to create the XLSX reporting in case it was not reported or lost.
Same tool will be called during EC to create the XLSX reporting from an test run.

=cut

my ($help, $givenXmlPath );

#STEP get given command line options
GetOptions( "help|?" => \$help, "xmlFilePath=s" => \$givenXmlPath );

if ($help) {
    pod2usage( -verbose => 2 );
}
elsif ($givenXmlPath) {
    # nothing to do here.
}
else {
    my $mw = tkinit();

    $givenXmlPath = $mw->getOpenFile(
        "-filetypes" => [ [ "Creis Summary XML", '.xml' ], [ "All files", '.*' ] ],
        "-title" => "Choose a  CREIS Summary XML file (*.xml)",
    );
}

FLC_XLSX_createReport($givenXmlPath);
