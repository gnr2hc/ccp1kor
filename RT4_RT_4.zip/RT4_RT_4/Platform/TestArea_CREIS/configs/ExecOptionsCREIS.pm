package LIFT_EXEC_OPTIONS;

$EXEC_OPTIONS = {
    'DEFAULT' => {
        CREIS_EcuReadyOptimisation => 1,

        CREIS_Iterations => 3,

        CREIS_xlsxReportUpdateOption => 0,

        CREIS_EdrCompletenessCheck => 1,
        CREIS_ExtendedRuntime      => 0,
        CREIS_EvaluateRbFaults     => 1,
        
        CREIS_PdLabelsBeforeCrash  => undef,
        CREIS_PdLabelsAfterCrash   => undef,
        CREIS_FastDiagTrace  => undef,
        CREIS_StoreEDR       => 1,
        CREIS_StoreNVM       => 0,
        CREIS_StoreNetTraces => 1,

        CREIS_IgnoreAlgoIDCheck              => 0,
        CREIS_IgnoreRuntimeErrors            => 0,
        CREIS_IgnoreMissingEnvironments      => 0,
        CREIS_IgnoreFailedEnvironmentChecks  => 0,
        CREIS_IgnoreMissingEnvironmentChecks => 1,
        CREIS_IgnoreExtendedRuntimeErrors    => 0,
    },
    'Runtime' => {
        CREIS_EcuReadyOptimisation => 1,

        CREIS_Iterations => 10,

        CREIS_xlsxReportUpdateOption => 0,

        CREIS_EdrCompletenessCheck => 1,
        CREIS_ExtendedRuntime      => 1,
        CREIS_EvaluateRbFaults     => 1,
        
        CREIS_PdLabelsBeforeCrash  => undef,
        CREIS_PdLabelsAfterCrash   => undef,
        CREIS_FastDiagTrace  => undef,
        CREIS_StoreEDR       => 0,
        CREIS_StoreNVM       => 0,
        CREIS_StoreNetTraces => 0,

        CREIS_IgnoreAlgoIDCheck              => 0,
        CREIS_IgnoreRuntimeErrors            => 0,
        CREIS_IgnoreMissingEnvironments      => 0,
        CREIS_IgnoreFailedEnvironmentChecks  => 0,
        CREIS_IgnoreMissingEnvironmentChecks => 1,
        CREIS_IgnoreExtendedRuntimeErrors    => 0,
    },
    'ESO_AWD' => {
        CREIS_EcuReadyOptimisation => 1,

        CREIS_Iterations => 3,

        CREIS_xlsxReportUpdateOption => 0,

        CREIS_EdrCompletenessCheck => 1,
        CREIS_ExtendedRuntime      => 0,
        CREIS_EvaluateRbFaults     => 1,
        
        CREIS_PdLabelsBeforeCrash  => undef,
        CREIS_PdLabelsAfterCrash   => undef,
        CREIS_FastDiagTrace  => undef,
        CREIS_StoreEDR       => 0,
        CREIS_StoreNVM       => 0,
        CREIS_StoreNetTraces => 0,

        CREIS_IgnoreAlgoIDCheck              => 0,
        CREIS_IgnoreRuntimeErrors            => 0,
        CREIS_IgnoreMissingEnvironments      => 0,
        CREIS_IgnoreFailedEnvironmentChecks  => 0,
        CREIS_IgnoreMissingEnvironmentChecks => 1,
        CREIS_IgnoreExtendedRuntimeErrors    => 0,
        CREIS_IgnoreSquibConfigErrors        => 1,
    },
    'DEFAULT_1Iter' => {
        CREIS_EcuReadyOptimisation => 1,

        CREIS_Iterations => 1,

        CREIS_xlsxReportUpdateOption => 0,

        CREIS_EdrCompletenessCheck => 1,
        CREIS_ExtendedRuntime      => 0,
        CREIS_EvaluateRbFaults     => 1,
        
        CREIS_PdLabelsBeforeCrash  => undef,
        CREIS_PdLabelsAfterCrash   => undef,
        CREIS_FastDiagTrace  => undef,
        CREIS_StoreEDR       => 1,
        CREIS_StoreNVM       => 0,
        CREIS_StoreNetTraces => 0,

        CREIS_IgnoreAlgoIDCheck              => 0,
        CREIS_IgnoreRuntimeErrors            => 0,
        CREIS_IgnoreMissingEnvironments      => 0,
        CREIS_IgnoreFailedEnvironmentChecks  => 0,
        CREIS_IgnoreMissingEnvironmentChecks => 1,
        CREIS_IgnoreExtendedRuntimeErrors    => 0,
    },
     'DEFAULT_10Iter' => {
        CREIS_EcuReadyOptimisation => 1,

        CREIS_Iterations => 10,

        CREIS_xlsxReportUpdateOption => 0,

        CREIS_EdrCompletenessCheck => 1,
        CREIS_ExtendedRuntime      => 0,
        CREIS_EvaluateRbFaults     => 1,
        
        CREIS_PdLabelsBeforeCrash  => undef,
        CREIS_PdLabelsAfterCrash   => undef,
        CREIS_FastDiagTrace  => undef,
        CREIS_StoreEDR       => 1,
        CREIS_StoreNVM       => 0,
        CREIS_StoreNetTraces => 1,

        CREIS_IgnoreAlgoIDCheck              => 0,
        CREIS_IgnoreRuntimeErrors            => 0,
        CREIS_IgnoreMissingEnvironments      => 0,
        CREIS_IgnoreFailedEnvironmentChecks  => 0,
        CREIS_IgnoreMissingEnvironmentChecks => 1,
        CREIS_IgnoreExtendedRuntimeErrors    => 0,
    },
};

1;
