#### TEST CASE MODULE
package TC_AOD_WhenNotMonitored;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_labcar;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_PD;
use FuncLib_SYC_INTERFACE;    #as CA do not include this in INCLUDES_Project
use feature qw(switch);
##################################

our $PURPOSE = "To verify the enableing and disabling monitoring of Aout port";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_WhenNotMonitored

=head1 PURPOSE

To verify the enableing and disabling monitoring of Aout port

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create fault condition <FaultCondition> for <LoadName>

2. Wait for <QualiTime>.

3. Check <LoadName> status.

4. Read Fault memory.

5. Remove monitoring bit of <LoadName>

6. Read Fault memory.


I<B<Evaluation>>

1.

2.

3. Status of <LoadName> is OFF

4. <Fault> should be present, which is created at step 1

5. Moitoring bit should be removed

6. Fault should not be present, which is created in step 1


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'Fault' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 
	SCALAR 'FaultCondition' => 
	SCALAR 'QualiTime' => 
	SCALAR 'DequaliTime' => 
	HASH 'Aout_LC_device_map' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the fault will not be present when Aout is not monitored'
	Aoutname = '<Test Heading 2>'
	FaultCondition = '<Test Heading 3>'
	QualiTime = '1000'
	DequaliTime = '1000'
	Aout_LC_device_map = %('AOutSysWarningIndicator' => 'AWL', 'AOutPassAirbagOnIndicator' => 'PADL', 'AOutPassAirbagOffIndicator' => 'PAEL', 'AOutCrashOutput1' => 'CRO1', 'AOutCrashOutput2' => 'CRO2','AOutCrashOutput3' => 'CRO3') #mapping between .sad device and name in mapping labcar (MLC or TSG4)
	LoadName = 'NONE'
	Fault = 'NONE'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_FaultCondition;
my $tcpar_QualiTime;
my $tcpar_DequaliTime;
my $tcpar_Aout_LC_device_map;
my $tcpar_LoadName;
my $tcpar_Fault;
my $tcpar_DriverState;
my $tcpar_CRO_Off_value;
my $tcpar_FLTopt_aref;

################ global parameter declaration ###################
#add any global variables here
my $labcar_device;
my $lamp_states_href;
my $lamp_states_init_href;
my $CRO_status;
my ( $Real_init,       $Monitored_init,   $Prog_init );
my ( $Real_deconf,     $Monitored_deconf, $Prog_deconf );
my ( $faultMemory_obj, $faultMemory_obj1, $expectedFaults_Quali_href, $expectedFaults_DeQuali_href );
my @optFaults_Quali   = ();
my @optFaults_DeQuali = ();
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose            = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname           = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_FaultCondition     = S_read_mandatory_testcase_parameter('FaultCondition');
	$tcpar_QualiTime          = S_read_mandatory_testcase_parameter('QualiTime');
	$tcpar_DequaliTime        = S_read_mandatory_testcase_parameter('DequaliTime');
	$tcpar_Aout_LC_device_map = S_read_mandatory_testcase_parameter('Aout_LC_device_map');
	$tcpar_LoadName           = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_Fault              = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_DriverState        = S_read_optional_testcase_parameter('DriverState');
	$tcpar_CRO_Off_value      = S_read_optional_testcase_parameter('CRO_Off_value');
	$tcpar_FLTopt_aref        = S_read_optional_testcase_parameter('FLTopt');

	$labcar_device   = $tcpar_Aout_LC_device_map->{$tcpar_LoadName};
	@optFaults_Quali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );
	@optFaults_DeQuali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );

	return 1;
}

sub TC_initialization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	unless ( $tcpar_DriverState eq 'NONE' ) {
		_setAODstate( $tcpar_LoadName, $tcpar_DriverState );
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Create fault condition '$tcpar_FaultCondition' for '$tcpar_LoadName'", 'AUTO_NBR' );
	_createFaultCondition($tcpar_FaultCondition);

	S_teststep( "Wait for '$tcpar_QualiTime'.", 'AUTO_NBR' );
	S_wait_ms($tcpar_QualiTime);

	S_teststep( "Check '$tcpar_LoadName' status.", 'AUTO_NBR', 'check_loadname_status' );    #measurement 1
	if ( $tcpar_LoadName =~ /AOutCrashOutput/ ) {
		unless ( defined &FuncLib_Project_DEVICE::DEVICE_getCROStatus ){
			S_w2rep( "Device '$tcpar_LoadName' is controlled by PWM, cannot read ON or OFF", 'blue' );
		}
		else{
			$CRO_status = FuncLib_Project_DEVICE::DEVICE_getCROStatus();
		}
	}
	else {
		$lamp_states_href = PD_ReadLampStates();
	}

	S_teststep( "Read Fault memory.", 'AUTO_NBR', 'read_fault_memory_A' );                   #measurement 2
	$faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	S_teststep( "Remove monitoring bit of '$tcpar_LoadName'", 'AUTO_NBR', 'remove_monitoring_bit' );    #measurement 3

	S_teststep_2nd_level( "Read and store monitoring and configuration bit before remove", 'AUTO_NBR' );
	( $Real_init, $Monitored_init, $Prog_init ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms( 2000, "avoid PD error" );

	S_teststep_2nd_level( "Remove configuration bit before remove monitoring bit to avoid IDLE mode", 'AUTO_NBR' );
	PD_Device_configuration( 'clear', [$tcpar_LoadName] );
	S_wait_ms( 2000, "avoid PD error" );

	S_teststep_2nd_level( "Remove monitoring bit", 'AUTO_NBR' );
	PD_Device_configuration( 'clear_Mon', [$tcpar_LoadName] );
	S_wait_ms( 2000, "avoid PD error" );

	S_teststep_2nd_level( "Read monitoring bit afer de-monitoring", 'AUTO_NBR' );
	( $Real_deconf, $Monitored_deconf, $Prog_deconf ) = PD_get_device_config($tcpar_LoadName);

	S_teststep( "Read Fault memory.", 'AUTO_NBR', 'read_fault_memory_B' );    #measurement 4
	$faultMemory_obj1 = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	$expectedFaults_Quali_href->{'mandatory'}->{$tcpar_Fault}   = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };
	$expectedFaults_DeQuali_href->{'mandatory'}->{$tcpar_Fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };

	$expectedFaults_Quali_href->{'optional'}   = \@optFaults_Quali;
	$expectedFaults_DeQuali_href->{'optional'} = \@optFaults_DeQuali;

	if ( $tcpar_LoadName =~ /AOutCrashOutput/ ) {    #for Crash Output in CA, control by PWM -> Lamp Off time is very small, cannot be dectected
		unless(defined $CRO_status){
			S_w2rep( "Device '$tcpar_LoadName' is controlled by PWM, will not evaluate ON or OFF", 'blue' );
		}
		else{
			S_teststep_expected( "Status of '$tcpar_LoadName' is ON", 'check_loadname_status' );    #evaluation 1
			S_teststep_detected( "Detected state of '$tcpar_LoadName' is $lamp_states_href->{$tcpar_LoadName}", 'check_loadname_status' );
			EVAL_evaluate_value( "State of '$tcpar_LoadName'", $CRO_status, '==', $tcpar_CRO_Off_value );
		}

	}
	else {
		S_teststep_expected( "Status of '$tcpar_LoadName' is not ON (as there is also Faulty state)", 'check_loadname_status' );    #evaluation 1
		S_teststep_detected( "Detected state of '$tcpar_LoadName' is $lamp_states_href->{$tcpar_LoadName}", 'check_loadname_status' );
		unless ( $tcpar_LoadName =~ /AOutSysWarningIndicator/ ) {
			EVAL_evaluate_string( "State of '$tcpar_LoadName'", 'On', $lamp_states_href->{$tcpar_LoadName}, '!=' );    #Lamp should not be ON as there is also one state for Faulty
		}
		else {
			EVAL_evaluate_string( "State of '$tcpar_LoadName'", 'On', $lamp_states_href->{'System Warning Lamp'}, '!=' );    #Lamp should not be ON as there is also one state for Faulty
		}

	}

	my $entry_obj_aref = $faultMemory_obj->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
	my @faultNamesInMemory_Quali = ();
	foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
		push( @faultNamesInMemory_Quali, $fault_entry_obj->FaultName );
	}

	S_teststep_expected( "'$tcpar_Fault' should be present, which is created at step 1", 'read_fault_memory_A' );            #evaluation 2

	S_teststep_detected( "Detected fault qualify in memory:", 'read_fault_memory_A' );
	foreach my $fault (@faultNamesInMemory_Quali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj->evaluate_faults(
		$expectedFaults_Quali_href,                                                                                          # expected faults
		'read_fault_memory_A'                                                                                                # eval keyword
	);

	S_teststep_expected( "Monitoring bit should be removed", 'remove_monitoring_bit' );                                      #evaluation 3
	S_teststep_detected( "Detected monitoring bit state is '$Monitored_deconf'", 'remove_monitoring_bit' );
	EVAL_evaluate_value( "Monitoring bit status $tcpar_LoadName", $Monitored_deconf, '==', 0 );

	my $entry_obj1_aref = $faultMemory_obj1->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 } } );
	my @faultNamesInMemory_DeQuali = ();
	foreach my $fault_entry_obj ( @{$entry_obj1_aref} ) {
		push( @faultNamesInMemory_DeQuali, $fault_entry_obj->FaultName );
	}
	S_teststep_expected( "Fault should be dequalified, which is created in step 1", 'read_fault_memory_B' );                 #evaluation 4
	S_teststep_detected( "Detected fault qualify in memory", 'read_fault_memory_B' );
	foreach my $fault (@faultNamesInMemory_DeQuali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj1->evaluate_faults(
		$expectedFaults_DeQuali_href,                                                                                        # expected faults
		'read_fault_memory_B'                                                                                                # eval keyword
	);

	return 1;
}

sub TC_finalization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Reconfig and monitor deveice'.", 'AUTO_NBR' );

	S_teststep_2nd_level( "Set monitoring bit", 'AUTO_NBR' );
	PD_Device_configuration( 'set_Mon', [$tcpar_LoadName] );
	S_wait_ms( 2000, "avoid PD error" );

	if ( $Prog_init == 1 ) {
		S_teststep_2nd_level( "Re-configure device", 'AUTO_NBR' );
		PD_Device_configuration( 'set', [$tcpar_LoadName] );
		S_wait_ms( 2000, "avoid PD error" );
	}

	S_teststep( "Remove '$tcpar_FaultCondition'.", 'AUTO_NBR' );
	_removeFaultCondition($tcpar_FaultCondition);
	S_wait_ms($tcpar_DequaliTime);

	S_teststep( "Read and clear fault memory", 'AUTO_NBR' );
	my $faultMemory_afterConf_obj = LIFT_FaultMemory->read_fault_memory('Primary');
	$faultMemory_afterConf_obj->clear_in_ECU();

	S_teststep( "Reset AOD state", 'AUTO_NBR' );
	_resetAODstate( $tcpar_LoadName, $tcpar_DriverState );

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Check fault free setup", 'AUTO_NBR' );
	my $faultMemory_reset_obj = LIFT_FaultMemory->read_fault_memory('Primary');
	$faultMemory_reset_obj->evaluate_faults( {} );

	return 1;
}

sub _createFaultCondition {

	my $faultcondtion = shift;
	if ( $faultcondtion =~ 'Short2Gnd' ) {

		LC_ShortLines( [ $labcar_device . '+', 'B-' ] );
	}
	elsif ( $faultcondtion =~ 'Short2Bat' ) {

		LC_ShortLines( [ $labcar_device . '+', 'B+' ] );
	}
	else {

		S_set_error("Fault condition $faultcondtion is not supported, only support for 'Short2Gnd', 'Short2Bat'");
	}
	return 1;
}

sub _removeFaultCondition {

	my $faultcondtion = shift;
	if ( $faultcondtion =~ /Short2/ ) {

		LC_UndoShortLines();
	}
	else {

		S_set_error("Fault condition $faultcondtion is not supported, only support for 'Short2Gnd', 'Short2Bat'");
	}
	return 1;
}

sub _setAODstate {

	my $device = shift;
	my $state  = shift;

	unless ( defined &FuncLib_Project_DEVICE::DEVICE_setAODState ) {

		given ($device) {
			when ('AOutSysWarningIndicator') {
				if ( $state =~ 'DriverSwitchedOn' ) {

					S_teststep( "Create fault to set SysWL ON ", 'AUTO_NBR' );
					LC_DisconnectLine('AB1FD');
					S_wait_ms(8000);
					push( @optFaults_Quali,   'rb_sqm_SquibResistanceOpenAB1FD_flt' );
					push( @optFaults_DeQuali, 'rb_sqm_SquibResistanceOpenAB1FD_flt' );

					S_teststep( "Read fault memory", 'AUTO_NBR' );
					PD_ReadFaultMemory();
				}
				elsif ( $state =~ 'DriverSwitchedOff' ) {

					S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
				}
				else {

					S_set_error("State $state currently is not supported in this test script ");
				}
			}
			when (/AOutPassAirbag/) {

				_setPADI_PAEL_state( $device, $state );
			}
			when (/AOutCrashOutput/) {

				S_w2rep( "Device '$device' is control by PWM, cannot control ON or OFF", 'blue' );
			}
			default {
				S_set_error("Device $device currently is not supportted in test script");
			}
		}
	}
	else {
		FuncLib_Project_DEVICE::DEVICE_setAODState( $device, $state );
	}

	unless ( $device =~ /AOutCrashOutput/ ) {

		my $lamp_states_href;
		S_teststep( "Read and evaluate lamp state", 'AUTO_NBR' );
		$lamp_states_href = PD_ReadLampStates();

		$device = 'System Warning Lamp' if ( $device =~ 'AOutSysWarningIndicator' );

		if ( $state =~ 'DriverSwitchedOn' ) {

			S_teststep_expected("Lamp $device should be ON");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );
		}
		else {

			S_teststep_expected("Lamp $device should be OFF");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );
		}
	}
	else {

		S_w2rep( "Do not evaluate state On or Off of $device", 'blue' );
	}
	return 1;
}

sub _resetAODstate {

	my $device = shift;
	my $state  = shift;
	my $lamp_states_href;
	given ($device) {
		when ('AOutSysWarningIndicator') {
			if ( $state =~ 'DriverSwitchedOn' ) {

				S_teststep( "Remove fault to set SysWL ON ", 'AUTO_NBR' );
				LC_ConnectLine('AB1FD');
				S_wait_ms(2000);
				PD_ClearFaultMemory();
			}
			elsif ( $state =~ 'DriverSwitchedOff' ) {

				S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
				S_teststep_2nd_level( "Read and evaluate lamp state", 'AUTO_NBR' );
				$lamp_states_href = PD_ReadLampStates();
				EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{'System Warning Lamp'} );
			}
			else {

				S_set_error("State $state currently is not supported in this test script ");
			}
		}
		when (/AOutPassAirbag/) {

			_setPADI_PAEL_state( 'AOutPassAirbagOffIndicator', 'DriverSwitchedOff' );
		}
		when (/AOutCrashOutput/) {

			S_w2rep( "Device '$device' is control by PWM, cannot control ON or OFF", 'blue' );
		}
		default {
			S_set_error("Device $device currently is not supportted in test script");
		}
	}

	return 1;
}

sub _setPADI_PAEL_state {

	my $devicename = shift;
	my $state      = shift;

	my ( $result_OPSFP_A, $state_OPSFP_A_value, $state_OPSFP_A_unit ) = SYC_SWITCH_get_state( 'OPSFP', 'PositionA' );
	my ( $result_OPSFP_B, $state_OPSFP_B_value, $state_OPSFP_B_unit ) = SYC_SWITCH_get_state( 'OPSFP', 'PositionB' );

	my ( $result_PADS1_A, $state_PADS1_A_value, $state_PADS1_A_unit ) = SYC_SWITCH_get_state( 'PADS1', 'PositionA' );
	my ( $result_PADS1_B, $state_PADS1_B_value, $state_PADS1_B_unit ) = SYC_SWITCH_get_state( 'PADS1', 'PositionB' );

	my ( $result_PADS2_A, $state_PADS2_A_value, $state_PADS2_A_unit ) = SYC_SWITCH_get_state( 'PADS2', 'PositionA' );
	my ( $result_PADS2_B, $state_PADS2_B_value, $state_PADS2_B_unit ) = SYC_SWITCH_get_state( 'PADS2', 'PositionB' );

	if (
		( ( $devicename =~ 'AOutPassAirbagOffIndicator' ) and ( $state =~ 'DriverSwitchedOn' ) )
		or (    ( $devicename =~ 'AOutPassAirbagOnIndicator' )
			and ( $state =~ 'DriverSwitchedOff' ) )
	  )
	{

		S_teststep( "Set OPSFP to occupied (PosB) and set PADS1, PADS2 to airbag off (PosA)", 'AUTO_NBR' );
		_setSwitchState( 'OPSFP', $state_OPSFP_B_value, $state_OPSFP_B_unit );
		_setSwitchState( 'PADS1', $state_PADS1_A_value, $state_PADS1_A_unit );
		_setSwitchState( 'PADS2', $state_PADS2_A_value, $state_PADS2_B_unit );
	}
	else {

		S_teststep( "Set OPSFP to occupied (PosB) and set PADS1, PADS2 to airbag on (PosB)", 'AUTO_NBR' );
		_setSwitchState( 'OPSFP', $state_OPSFP_B_value, $state_OPSFP_B_unit );
		_setSwitchState( 'PADS1', $state_PADS1_B_value, $state_PADS1_B_unit );
		_setSwitchState( 'PADS2', $state_PADS2_B_value, $state_PADS2_A_unit );
	}
	S_wait_ms(1000);

	return 1;
}

sub _setSwitchState {

	my $switch      = shift;
	my $state_value = shift;
	my $switch_unit = shift;

	if ( $switch_unit =~ 'I' ) {

		LC_SetCurrent( $switch, $state_value );
	}
	elsif ( $switch_unit =~ 'R' ) {

		LC_SetResistance( $switch, $state_value );
	}
	else {

		S_set_error("Device type unit '$switch_unit' is not supported");
	}
	return 1;
}
1;

1;
