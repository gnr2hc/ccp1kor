#### TEST CASE MODULE
package TC_AOD_Monitoring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_labcar;
use FuncLib_SYC_INTERFACE; #as CA do not include this in INCLUDES_Project
##################################

our $PURPOSE = "To verify the enableing and disabling monitoring of Aout port";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_Monitoring

=head1 PURPOSE

To verify the enableing and disabling monitoring of Aout port

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault

<LoadName> should be configured.


I<B<Stimulation and Measurement>>

1. Verify configuration and monitoring flag of <LoadName>.

2. Deconfigure <LoadName> and reset ECU.

3. Verify deconfiguration of <LoadName>.

4. Verify monitoring flag of <LoadName>.

5. Disable monitoring of <LoadName> and reset the ECU.

6. Verify monitoring flag of <LoadName>.

7. Enable monitoring of <LoadName> and reset the ECU.

8. Verify monitoring flag of <LoadName>.

9. Reconfigure <LoadName> and reset ECU.

10. Verify configuration and monitoring flag of <LoadName>.


I<B<Evaluation>>

1. Configuration and monitoring flag of <LoadName> should be same as in SYC.

2.

3. <LoadName> is deconfigured.

4. Monitoring status of <LoadName> is remain enabled.

5.

6. Monitoring status of <LoadName> is disabled.

7.

8. Monitoring status of <LoadName> is remain enabled.

9. 

10. Configuration and monitoring flag of <LoadName> should be same as in SYC.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the enableing and disabling monitoring of Aout port'
	Aoutname = '<Test Heading 2>'
	LoadName = 'AWL'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_LoadName;
my $tcpar_Aout_SYC_device_map;

################ global parameter declaration ###################
#add any global variables here
my ( $present_init,        $monitor_init,        $config_init );
my ( $present_afer_deconf, $monitor_afer_deconf, $config_afer_deconf );
my ( $present_afer_demon,  $monitor_afer_demon,  $config_afer_demon );
my ( $present_afer_remon,  $monitor_afer_remon,  $config_afer_remon );
my ( $present_afer_reconf, $monitor_afer_reconf, $config_afer_reconf );
my ( $result,              $configured,          $monitored );
my $conf_mon_states_map = { 'yes' => 1, 'no' => 0, 'N/A' => 0 };
my $SYC_scip_device;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose  = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_LoadName = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_Aout_SYC_device_map = S_read_mandatory_testcase_parameter('Aout_SYC_device_map');
	
	$SYC_scip_device = $tcpar_Aout_SYC_device_map->{$tcpar_LoadName};

	return 1;
}

sub TC_initialization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Verify configuration and monitoring flag of '$tcpar_LoadName' compare with SYC.", 'AUTO_NBR', 'verify_configuration_and_monitor' );
	( $present_init, $monitor_init, $config_init ) =  PD_get_device_config($tcpar_LoadName);
	S_teststep_2nd_level( "Verify configuration of '$tcpar_LoadName' compare with SYC" , 'AUTO_NBR' , 'verify_configuration' );
	( $result, $configured ) =  SYC_AnalogueOutput_get_Configured($SYC_scip_device);
	S_teststep_expected( "Follow SYC, config bit of '$tcpar_LoadName' is '$configured'.", 'verify_configuration' );
	S_teststep_detected( "Config bit status '$tcpar_LoadName' in SW is '$config_init'.", 'verify_configuration' );
	EVAL_evaluate_value( "Config bit status $tcpar_LoadName", $config_init, '==', $conf_mon_states_map->{$configured} );

	S_teststep_2nd_level( "Verify monitoring flag of '$tcpar_LoadName' compare with SYC" , 'AUTO_NBR' , 'verify_monitor' );
	( $result, $monitored ) = SYC_AnalogueOutput_get_Monitored($SYC_scip_device);
	S_teststep_expected( "Follow SYC, monitor bit of '$tcpar_LoadName' is '$monitored'.", 'verify_monitor' );
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' in SW is '$monitor_init'.", 'verify_monitor' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_init, '==', $conf_mon_states_map->{$monitored} );

	return 1;
}

sub TC_stimulation_and_measurement {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	if (( $monitor_init == 0 ) and ( $config_init == 1 )) #ECU will be in IDLE mode if config bit is set but monitor bit is not set
	{
		S_set_error( "Config bit and monitor bit is inconsistent, this will cause ECU in IDLE mode", 114 );
        return;
    }   
    
    S_teststep( "Verify configuration and monitoring flag of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_configuration_and_A' );    #measurement 1
	S_w2rep( "'$tcpar_LoadName' config bit is '$config_init', monitor bit is '$monitor_init' in SW, evaluation had been done in Initialization. \n", 'blue' );

	S_teststep( "Deconfigure '$tcpar_LoadName' and reset ECU.", 'AUTO_NBR' );
	PD_Device_configuration( 'clear', [$tcpar_LoadName] );
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep( "Verify deconfiguration of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_deconfiguration_of' );     #measurement 2
	( $present_afer_deconf, $monitor_afer_deconf, $config_afer_deconf ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep_expected( "'$tcpar_LoadName' is deconfigured.", 'verify_deconfiguration_of' );                 #evaluation 2
	S_teststep_detected( "Config bit status '$tcpar_LoadName' after de-configure is '$config_afer_deconf'.", 'verify_deconfiguration_of' );
	EVAL_evaluate_value( "Config bit status $tcpar_LoadName", $config_afer_deconf, '==', $conf_mon_states_map->{'no'} );

	S_teststep( "Verify monitoring flag of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_monitoring_flag_A' );      #measurement 3

	S_teststep_expected( "Monitoring status of '$tcpar_LoadName' is remain enabled.", 'verify_monitoring_flag_A' );                  #evaluation 3
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' after de-configure is '$monitor_afer_deconf'", 'verify_monitoring_flag_A' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_afer_deconf, '==', $conf_mon_states_map->{'yes'} );

	S_teststep( "Disable monitoring of '$tcpar_LoadName' and reset the ECU.", 'AUTO_NBR' );
	PD_Device_configuration( 'clear_Mon', [$tcpar_LoadName] );
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep( "Verify monitoring flag of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_monitoring_flag_B' );    #measurement 4
	( $present_afer_demon, $monitor_afer_demon, $config_afer_demon ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep_expected( "Monitoring status of '$tcpar_LoadName' is disabled.", 'verify_monitoring_flag_B' );                #evaluation 4
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' after disable monitor bit is '$monitor_afer_demon'", 'verify_monitoring_flag_B' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_afer_demon, '==', $conf_mon_states_map->{'no'} );

	S_teststep( "Enable monitoring of '$tcpar_LoadName' and reset the ECU.", 'AUTO_NBR' );
	PD_Device_configuration( 'set_Mon', [$tcpar_LoadName] );
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep( "Verify monitoring flag of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_monitoring_flag_C' );    #measurement 5
	( $present_afer_remon, $monitor_afer_remon, $config_afer_remon ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms(2000); #wait for 2s to avoid PD error

	S_teststep_expected( "Monitoring status of '$tcpar_LoadName' is enabled.", 'verify_monitoring_flag_C' );                #evaluation 5
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' after enable monitor bit is '$monitor_afer_remon'", 'verify_monitoring_flag_C' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_afer_remon, '==', $conf_mon_states_map->{'yes'} );

	S_teststep( "Reconfigure '$tcpar_LoadName' and reset ECU.", 'AUTO_NBR' );
	if ( $config_init == 1 ) {
		PD_Device_configuration( 'set', [$tcpar_LoadName] );
		S_wait_ms(2000); #wait for 2s to avoid PD error
	}
	else {
		S_w2rep( "'$tcpar_LoadName' is not configured as init configuration status is '$config_init' " );
	}

	S_teststep( "Verify configuration and monitoring flag of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_configuration_monitor_B' );    #measurement 6
	( $present_afer_reconf, $monitor_afer_reconf, $config_afer_reconf ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms(2000); #wait for 2s to avoid PD error
	
	S_teststep_2nd_level( "Verify configuration of '$tcpar_LoadName' compare with init state" , 'AUTO_NBR' , 'verify_configuration_B' );
	S_teststep_expected( "Config bit of '$tcpar_LoadName' in init state is '$config_init'.", 'verify_configuration_B' );
	S_teststep_detected( "Config bit status '$tcpar_LoadName' in SW is '$config_afer_reconf'.", 'verify_configuration_B' );
	EVAL_evaluate_value( "Config bit status $tcpar_LoadName", $config_afer_reconf, '==', $config_init );

	S_teststep_2nd_level( "Verify monitoring flag of '$tcpar_LoadName' compare with init state" , 'AUTO_NBR' , 'verify_monitor_B' );
	S_teststep_expected( "Monitor bit of '$tcpar_LoadName' in init state is '$monitor_init'.", 'verify_monitor_B' );
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' in SW is '$monitor_afer_reconf'.", 'verify_monitor_B' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_afer_reconf, '==', $monitor_init );


	return 1;
}

sub TC_evaluation {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_w2rep( "All evaluation had been done in stimulation and measurement \n", 'blue' );

	return 1;
}

sub TC_finalization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

1;
