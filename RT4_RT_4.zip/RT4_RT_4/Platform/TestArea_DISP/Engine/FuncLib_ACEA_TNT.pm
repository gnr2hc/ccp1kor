package FuncLib_ACEA_TNT;

######################################################

=head1 NAME

FuncLib_ACEA_TNT

Provide LIFT ACEA functions - generic functions

=cut

######################################################

use strict;
use LIFT_numerics ;
use LIFT_general;
use LIFT_MLC;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_CANoe;
use LIFT_POWER;
use LIFT_labcar;
use LIFT_PRITT;
use LIFT_can_access;
use LIFT_LIN_Access;
use LIFT_flexray_access;
use GENERIC_DCOM;
use INCLUDES_Project;




my $Counter_State=50;
my $Condition_Global;
my $Squib_Global;

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(ACEA_ReadDismantlerInfo 
                 ACEA_WriteDismantlerInfo
                 ACEA_ExecuteDisposalProgramLoader
                 ACEA_FireSquib
                 ACEA_Get_SecurityAccess
                 ACEA_Read_DiploymentLoopTable
                 ACEA_Read_ECUAddressInfo
                 ACEA_Read_HWDeploymentMethod
                 ACEA_Read_NumberOfPCUs
                 ACEA_Read_VIN
                 ACEA_RequestRoutineResults
                 ACEA_RequestSeed
                 ACEA_CalculateKey
                 ACEA_SendKey
                 ACEA_SetACLConnection
                 ACEA_Send_TesterPresent_Cyclically
                 ACEA_Stop_TesterPresent
                 ACEA_ProjectSpecificSettings
                 ACEA_SetTestCondition
                 ACEA_ResetTestCondition
                 ACEA_SetECUMode
                 ACEA_ResetECUMode
                 ACEA_ReadDisableLineStatus
                 ACEA_EvaluateDisableLineStatus
                 ACEA_EvaluateDLTForGivenLoopId
                 ACEA_ExtractRespDataToBeEvaluated
                 ACEA_ReadDecryptionKeyInRAM
                 ACEA_ReadWLStatus
                 ACEA_ReadAlgoStatus
                 ACEA_EvaluateWLStatus
                 ACEA_EvaluateAlgoStatus
                 ACEA_ReadDPLStatusNVM
                 ACEA_ReadFirstDeploymentTimeStamp
                 ACEA_ReadPowerOnTimer
                 ACEA_ReadDecryptedCommandsInRAM
                 ACEA_EvaluateDecryptedCommandsInRAM
                 ACEA_GetWrongKey
                 ACEA_ReadSDLstatus
                 ACEA_EvaluateSDLstatus
                 ACEA_RequestRoutineResults_SPL
                 ACEA_FaultCounter
                 ACEA_ReadEncryptedCommandsInROM
                 ACEA_FireCounter                 
                 ACEA_FireCondition
				 
);



=head1 SYNOPSIS

	use LIFT_general;
	use LIFT_MLC;
	use LIFT_PD;
	use LIFT_CD;
	use LIFT_evaluation;
	use LIFT_CANoe;
	use LIFT_POWER;
	use GENERIC_DCOM;
	use INCLUDES_Project;
    
=head1 DESCRIPTION

Generic functions for ACEA

=cut

=head2 ACEA_Read_HWDeploymentMethod
      
	$Diag_response = ACEA_Read_HWDeploymentMethod ($Eval_Switch);

I<B<Description:>>  Read the HW deployment method.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut    

sub ACEA_Read_HWDeploymentMethod {

	GEN_print_caller();
	my $Eval_Switch = shift;
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadPCUHWDPLMethod", "PR_ReadDatabyID_ReadPCUHWDPLMethod", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.

}# end of ACEA_Read_HWDeploymentMethod

=head2 ACEA_Read_NumberOfPCUs
      
	$Diag_response = ACEA_Read_NumberOfPCUs ($Eval_Switch);

I<B<Description:>>  Reads the number of PCUs in a vehicle.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut  

sub ACEA_Read_NumberOfPCUs {

	GEN_print_caller();
	my $Eval_Switch = shift;
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadNumberOfPCU", "PR_ReadDatabyID_ReadNumberOfPCU", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.
}# end of ACEA_Read_NumberOfPCUs

=head2 ACEA_Read_ECUAddressInfo
      
	$Diag_response = ACEA_Read_ECUAddressInfo ($Eval_Switch);

I<B<Description:>>  Reads the address information of PCUs in vehicle.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut  

sub ACEA_Read_ECUAddressInfo {

	GEN_print_caller();
	my $Eval_Switch = shift;
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadAddressInfoOfPCU", "PR_ReadDatabyID_ReadAddressInfoOfPCU", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.
}# end of ACEA_Read_ECUAddressInfo

=head2 ACEA_ReadDismantlerInfo
      
	$Diag_response = ACEA_ReadDismantlerInfo ($Eval_Switch);

I<B<Description:>>  Reads the dismantler information.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_ReadDismantlerInfo{

	GEN_print_caller();

 	my $Eval_Switch = shift;

	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadDismantlerInfo", "PR_ReadDatabyID_ReadDismantlerInfo", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.

}# end of ACEA_ReadDismantlerInfo

=head2 ACEA_WriteDismantlerInfo
      
	$Diag_response = ACEA_WriteDismantlerInfo ($DismantlerInfo, $Response, $Eval_Switch);

I<B<Description:>>  writes the dismantler information.

$DismantlerInfo = hash reference to data to be written

$Response = expected response string

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_WriteDismantlerInfo{

	GEN_print_caller();

	my %DismantlerInfo;
    $DismantlerInfo{'DismantlerInfo'} = shift;
	my $Response = shift; 
 	my $Eval_Switch = shift; 
 	return 1 if $main::opt_offline;
	my $DiagResponse;
	unless( defined $DismantlerInfo{'DismantlerInfo'})
	{
		S_w2rep(" -->  Missing mandatory parameter DismantlerInfo to be written.\n");
		return undef;
	}
	$Eval_Switch="";
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	if(defined $Response) {
		$DiagResponse = GDCOM_request_general ("REQ_WriteDatabyID_WriteDismantlerInfo", $Response, \%DismantlerInfo);
	}
	else {
		$DiagResponse = GDCOM_request_general ("REQ_WriteDatabyID_WriteDismantlerInfo", "PR_WriteDatabyID_WriteDismantlerInfo",\%DismantlerInfo);
	}

	return $DiagResponse;#Returning the response string.
}# end of ACEA_WriteDismantlerInfo

=head2 ACEA_Read_DiploymentLoopTable
      
	$Diag_response = ACEA_Read_DiploymentLoopTable ($Eval_Switch);

I<B<Description:>>  Reads the Diployment Loop Table.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_Read_DiploymentLoopTable {

	GEN_print_caller();

	my $Eval_Switch = shift;
	
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadDeploymentLoopTable", "PR_ReadDatabyID_ReadDeploymentLoopTable", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.

}# end of ACEA_Read_DiploymentLoopTable

=head2 ACEA_Get_SecurityAccess
      
	$Diag_response = ACEA_Get_SecurityAccess ($Eval_Switch);

I<B<Description:>>  Obtain security access

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

=cut

sub ACEA_Get_SecurityAccess {

	GEN_print_caller();

	#Invoking function to request the seed.
	my $Response = ACEA_RequestSeed();
	my @Response = split(' ', $Response);
	my $Seed = $Response[2].' '.$Response[3];
	#Calculates key for the given seed 
	my $Key = ACEA_CalculateKey($Seed);
	
	#Invoking function to send seed.
	ACEA_SendKey($Key);

	return 1;
}# end of ACEA_Get_SecurityAccess

=head2 ACEA_RequestSeed
      
	$Diag_response = ACEA_RequestSeed ($Eval_Switch);

I<B<Description:>>  Requests seed

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_RequestSeed {

	GEN_print_caller();

	my $Eval_Switch = shift;
	
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_SecurityAccess_CD_RequestSeed", "PR_SecurityAccess_CD_RequestSeed", undef, $Eval_Switch);
	return $DiagResponse;
}# end of ACEA_RequestSeed

=head2 ACEA_CalculateKey
      
	ACEA_CalculateKey ($Seed);

I<B<Description:>>  Calculates key for a given seed seed

I<B<Return:>> 1 Key

I<B<Verdict:>> none

=cut

sub ACEA_CalculateKey {

	GEN_print_caller();
	my $Seed = shift; S_w2rep("Seed = $Seed");
	my @Seed = split(' ', $Seed);
	my (@Key, $TempSeed);
	my $i;
	foreach $TempSeed (@Seed){
		$TempSeed = '0x'.$TempSeed;
		$Key[$i] = ~(hex($TempSeed)) & 0xFF;
		$Key[$i] = S_aref2hex([$Key[$i]]);
		$Key[$i] =~ s/0x//;
		$i++;
	}
	my $j = '';
	my $TempKey;
	$TempKey = join(' ',@Key);
	return $TempKey;
}# end of ACEA_CalculateKey

=head2 ACEA_SendKey
      
	$Diag_response = ACEA_SendKey ($Eval_Switch);

I<B<Description:>>  Sends key

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_SendKey {

	GEN_print_caller();

	my %Key;
	$Key{'Key'} = shift;
	S_w2rep("Key $Key{'Key'}");
	my $Eval_Switch = shift;   
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_SecurityAccess_CD_SendKey", "PR_SecurityAccess_CD_SendKey", \%Key, $Eval_Switch);
	return 1;
}# end of ACEA_SendKey

=head2 ACEA_Read_VIN
      
	$Diag_response = ACEA_Read_VIN ($Eval_Switch);

I<B<Description:>>  Reads VIN

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_Read_VIN {

	GEN_print_caller();

	my $Eval_Switch = shift;
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returing the response.
	my $DiagResponse = GDCOM_request_general ("REQ_ReadDatabyID_ReadVIN", "PR_ReadDatabyID_ReadVIN", undef, $Eval_Switch);
	return $DiagResponse;#Returning the response string.
}# end of ACEA_Read_NumberOfPCUs

=head2 ACEA_RequestRoutineResults
      
	$Diag_response = ACEA_RequestRoutineResults ($LoopID,$Condition,$routineStatusRecord,$Eval_Switch);

I<B<Description:>>  Requests Routine Results
$LoopID = Loop ID of squib fired
$Condition = Test condition
$routineStatusRecord = Routine status record for OEM. This value can be obtained from SYC of the project.
$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_RequestRoutineResults {

	GEN_print_caller();

	my %LoopId;
	my ($Condition,$Eval_Switch,$DiagResponse,$routineStatusRecord);
	$LoopId{'LoopId'}= shift;
	$Condition= shift;
	$routineStatusRecord= shift;
	$Eval_Switch = shift;
	$LoopId{'LoopResults'}= $routineStatusRecord.' '.$LoopId{'LoopId'};
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returning the response.
	if($Condition eq "NotSupportedSquib")
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_ReqRoutineResult_DeployLoopRoutineID", "NR_requestOutOfRange",\%LoopId);
	}
	else
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_ReqRoutineResult_DeployLoopRoutineID", "PR_RoutineControl_ReqRoutineResult_DeployLoopRoutineID",\%LoopId, $Eval_Switch);
	}
	return $DiagResponse;#Returning the response string.
}# end of ACEA_RequestRoutineResults

=head2 ACEA_ExecuteDisposalProgramLoader
      
	$Diag_response = ACEA_ExecuteDisposalProgramLoader ($RoutineControlOption, $routineStatusRecord, $Eval_Switch);

I<B<Description:>>  Executes Disposal Program Loader

$RoutineControlOption = Routine Control Option(either 00 or 01)

$routineStatusRecord = Routine status record for OEM. This value can be obtained from SYC of the project.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut

sub ACEA_ExecuteDisposalProgramLoader {

	GEN_print_caller();
	my %RoutineControlOption;
	my $routineStatusRecord;
	$RoutineControlOption{'RoutineControlOption'} = shift;
	$routineStatusRecord = shift;
	my $Eval_Switch = shift; 
	$RoutineControlOption{'RoutineControlResponse'} = $routineStatusRecord.' '.$RoutineControlOption{'RoutineControlOption'};
	my $DiagResponse = GDCOM_request_general ("REQ_RoutineControl_StartRoutine_ExecuteDisposalProgramLoader", "PR_RoutineControl_StartRoutine_ExecuteDisposalProgramLoader",\%RoutineControlOption, $Eval_Switch);
	return $DiagResponse;#Returning the response string.
}# end of ACEA_ExecuteDisposalProgramLoader

=head2 ACEA_FireSquib
      
	$Diag_response = ACEA_FireSquib ($LoopId,$Condition,$Eval_Switch);

I<B<Description:>>  Executes Disposal Program Loader

$LoopId = Loop id of the squib to be fired

$Condition = Test Condition

$routineStatusRecord = Routine status record for OEM. This value can be obtained from SYC of the project.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general
=cut
sub ACEA_FireSquib {

	GEN_print_caller();
	my %LoopId;
	my ($routineStatusRecord,$Condition,$Eval_Switch,$DiagResponse);
	$LoopId{'LoopId'}= shift;
	$Condition= shift;
	$routineStatusRecord=shift;
	$Eval_Switch = shift;
	$LoopId{'LoopId_Response'}= $routineStatusRecord.' '.$LoopId{'LoopId'};
	#Sending Diag request to read HW Deployment method, evaluating  the response if opted and returning the response.
	GEN_printComment("Condition is $Condition");
	if($Condition eq "NotSupportedSquib")
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "NR_requestOutOfRange",\%LoopId);
	}
	else
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_StartRoutine_DeployLoopRoutineID", "PR_RoutineControl_StartRoutine_DeployLoopRoutineID",\%LoopId, $Eval_Switch);
	}
	return $DiagResponse;#Returning the response string.
}# end of ACEA_FireSquib

=head2 ACEA_SetACLConnection
      
	ACEA_SetACLConnection ($ACLConnection);

I<B<Description:>>  Executes Disposal Program Loader

$ACLConnection = 'Connect' or 'Disconnect'

I<B<Return:>> none

I<B<Verdict:>> none

I<B<Note:>> 
For AB10
Define a freely usable switch in MLC as FS_ACL. 
$Defaults -> {'MLC'}= {
						'FREELY_USABLE_SWICHES' =>
						{
							'FSn_Name' => 'FS_ACL',
							'FS_ACL_STATE_CA' => 'ACL_CONNECT',
							'FS_ACL_STATE_NC' => 'ACL_DISCONNECT',
						},
					};									
Connect ACL PWM signal generator to terminal A of defined freely usable switch in MLC.
Connect ECU port which is configured for ACL to terminal C of defined freely usable switch in MLC.

For AB12
Define project constant in a below manner.Based on Harness mapping.   
            'WARNING_LAMPS' =>
            {
              'WL_1_3_Name'   => 'DISP',
            }
If MLC is used, then script will assume that ACL is provided externally and it is continous.              
=cut

sub ACEA_SetACLConnection{

	GEN_print_caller();
    my $ACLConnection = shift;
    return 1 if $main::opt_offline;
    my $Generation=PD_GetABGeneration();
    if($Generation==12)
    {
		if($ACLConnection eq 'Connect')
		{
		   LC_SendPWMDisposalStart('DISP',1);
		}
		elsif($ACLConnection eq 'Disconnect')
		{
			LC_SendPWMDisposalStop('DISP',1);
		}	   
    }
    else
    {
	    if($ACLConnection eq 'Connect'){
		   MLC_SetLogicalState( 'FS_ACL', 'ACL_CONNECT');
	    }
	    elsif($ACLConnection eq 'Disconnect'){
		  MLC_SetLogicalState( 'FS_ACL', 'ACL_DISCONNECT');
	   }
    }   
	S_wait_ms(3000);
	return 1;
}

=head2 ACEA_Send_TesterPresent_Cyclically

	ACEA_Send_TesterPresent_Cyclically();
	
I<B<Description:>>  Send tester present service cyclically with response suppressed

I<B<Return:>> none

I<B<Verdict:>> none

=cut    

sub ACEA_Send_TesterPresent_Cyclically {
	GEN_print_caller();
	my $msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'CAN_TesterPresent_Req'};
	my $msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
	my $cycle  = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'CAN_TesterPresent_Time'};
	my $TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);	

	return $TP_handle;
}# end of ACEA_FireSquib

=head2 ACEA_Stop_TesterPresent

I<B<Description:>>  Stops cyclical tester present service 

I<B<Return:>> none

I<B<Verdict:>> none

=cut    

sub ACEA_Stop_TesterPresent {
	GEN_print_caller();

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}# end of ACEA_FireSquib

=head2 ACEA_SetECUMode

	($IdleMode_var, $Value) = ACEA_SetECUMode($SystemMode);
	
$SystemMode = 'Idle'  or 'PermIdle'
	
I<B<Description:>>  Sets ECU mode

I<B<Return:>> 
$IdleMode_var = variable manipulated to create idle mode condition
$Value = valid value of the $IdleMode_var

I<B<Verdict:>> none

=cut    

sub ACEA_SetECUMode {
	GEN_print_caller();
	my $SystemMode = shift;
	return 1 if $main::opt_offline;
	my $ab_Gen=PD_GetABGeneration();	

   	if(($SystemMode eq 'Idle')&& ($ab_Gen<12))
   	{
		my $IdleMode_var = 'S_PDMASICDevice_XXE.A_ASICDeviceList_U8X(1)';
		my $value = S_aref2hex(PD_ReadMemoryByName($IdleMode_var));
		PD_WriteMemoryByName($IdleMode_var, ['0x00'] );
		PD_CalculateChecksum(@{$main::ProjectDefaults->{'CRC_AREA'}{'ALL'}});
		S_wait_ms(500);			
		PD_ECUreset();
		S_wait_ms( 'TIMER_ECU_READY' );
		S_w2rep("ECU is set to $SystemMode", 'blue');
		return ($IdleMode_var, $value);
	}
	elsif(($SystemMode eq 'Idle')&& ($ab_Gen==12))
	{
		my $IdleMode_var = 'rb_bswm_ActiveStateIdle_u16';
		PD_WriteMemoryByName($IdleMode_var, ['0xAA','0x55'] );
		PD_ECUreset();
		PD_ECUlogin();
		S_wait_ms( 'TIMER_ECU_READY' );
		my $idlemode_Value=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
		if($idlemode_Value ne '0x0004')
		{
			S_w2rep("ECU is not set to $SystemMode", 'red');
			return 0;
		}
	}
	elsif(($SystemMode eq 'PermIdle')&& ($ab_Gen==12))
	{
		my $aref_Idle;
		$aref_Idle->[0]='FF';
		$aref_Idle->[1]='FF';
		$aref_Idle->[2]='5A';
		$aref_Idle->[3]='5A';
		PD_WriteNVMSection("bswm_IdleModeData",$aref_Idle);
		S_wait_ms(5000);
		PD_ECUreset();
		PD_ECUlogin();
		my $idlemode_Value=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
		if($idlemode_Value ne '0x0004')
		{
			S_w2rep("ECU is not set to $SystemMode", 'red');
			return 0;
		}
	}
	S_w2rep("ECU is set to $SystemMode mode", 'blue');
    return 1;
}# end of ACEA_SetECUMode

=head2 ACEA_ResetECUMode

	ACEA_ResetECUMode($tcpar_SystemMode, $IdleMode_var, $Value);
	
$SystemMode = 'Idle' or 'PermIdle'
	
$IdleMode_var = variable manipulated to create idle mode condition used in ACEA_SetECUMode. Not required for AB12 projects.

$Value = valid value of the $IdleMode_var used in ACEA_SetECUMode. Not required for AB12 projects.

I<B<Description:>>  Resets ECU mode

I<B<Return:>> none

I<B<Verdict:>> none

=cut


sub ACEA_ResetECUMode {
	GEN_print_caller();

	my $SystemMode = shift;
	my $IdleMode_var = shift;
	my $Value = shift;
	return 1 if $main::opt_offline;
	my $ab_Gen = PD_GetABGeneration();
	if(($SystemMode eq 'Idle')&& ($ab_Gen<12))
	{
		PD_WriteMemoryByName($IdleMode_var, [$Value] );
		PD_CalculateChecksum(@{$main::ProjectDefaults->{'CRC_AREA'}{'ALL'}});
		S_wait_ms(500);
		PD_ECUreset();
		S_wait_ms( 'TIMER_ECU_READY' );
		S_w2rep("ECU is reset from $SystemMode", 'blue');
	}
	elsif(($SystemMode eq 'Idle')&& ($ab_Gen==12))
	{
		PD_ECUreset();
		S_wait_ms( 'TIMER_ECU_READY' );
		my $idlemode_Value=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
		if($idlemode_Value ne '0x0005')
		{
			S_w2rep("ECU is not reset from $SystemMode mode", 'red');
			return 0;
		}
	}
	elsif(($SystemMode eq 'PermIdle')&& ($ab_Gen==12))
	{
		my $aref_Idle;
		$aref_Idle->[0]='FF';
		$aref_Idle->[1]='FF';
		$aref_Idle->[2]='FF';
		$aref_Idle->[3]='FF';
		PD_WriteNVMSection("bswm_IdleModeData",$aref_Idle);
		S_wait_ms(5000);
		PD_ECUreset();
		PD_ECUlogin();
		my $idlemode_Value=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
		if($idlemode_Value ne '0x0005')
		{
			S_w2rep("ECU is not reset from $SystemMode mode", 'red');
			return 0;
		}
	}
	
	S_w2rep("ECU is reset from $SystemMode mode", 'blue');

	return 1;
}# end of ACEA_ResetECUMode


=head2 ACEA_SetTestCondition

	ACEA_SetTestCondition($devicename, $TestCondition);
	
$devicename = device name for which test condition to set
	
$TestCondition = test conditions
	valid TestConditions:
	CfgFlt : squib configuration fault
	S2GFlt : squib short to GND fault
	S2BFlt : squib short to Vbat fault
	ShortFlt : squib short fault
	OpenFlt : squib open fault
	CCFlt : squib cross coupling fault
	NoCfgSqOpen : squib configuration fault and squib open fault
	
I<B<Description:>>  Sets TestCondition

I<B<Return:>> none

I<B<Verdict:>> none

=cut    

sub ACEA_SetTestCondition {
	GEN_print_caller();

	my $devicename = shift;
	my $TestCondition = shift;
	my $SearchHashRef;
	my $verdict;
	my $matchedfaults_aref;
	$SearchHashRef->{'Device'} = $devicename;
	
	if($TestCondition eq 'CfgFlt'){
		$SearchHashRef->{'Condition'} = 'Configuration';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'S2GFlt'){
		$SearchHashRef->{'Condition'} = 'Short2Gnd';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'S2BFlt'){
		$SearchHashRef->{'Condition'} = 'Short2Bat';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'ShortFlt'){
		$SearchHashRef->{'Condition'} = 'ShortResistance';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'OpenFlt'){
		$SearchHashRef->{'Condition'} = 'Openline';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'CCFlt'){
		$SearchHashRef->{'Condition'} = 'CrossCouple';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		PD_ECUreset("Hard_reset");
		S_wait_ms( 'TIMER_ECU_READY' );
		#PD_ECUlogin();
	}
	elsif($TestCondition eq 'NoCfgSqOpen'){
		$SearchHashRef->{'Condition'} = 'Configuration';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		$SearchHashRef->{'Condition'} = 'Openline';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
		GEN_Power_on_Reset();
		PD_ECUlogin();
		PD_ClearFaultMemory();
		S_wait_ms(5000);
		PD_ReadFaultMemory();
	}
	elsif($TestCondition eq 'HighsidePowerstage'){
		$SearchHashRef->{'Condition'} = 'HighsidePowerstage';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		}
		elsif($TestCondition eq 'LowsidePowerstage'){
		$SearchHashRef->{'Condition'} = 'LowsidePowerstage';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_createFault(@$matchedfaults_aref[0]);
		}
	S_w2rep("fault $TestCondition is created for $devicename ", 'blue');

	return 1;
}# end of ACEA_SetTestCondition

=head2 ACEA_ResetTestCondition

	ACEA_ResetTestCondition($devicename, $TestCondition);
	
$devicename = device name for which test condition to set
	
$TestCondition = test conditions
	valid TestConditions:
	CfgFlt : squib configuration fault
	S2GFlt : squib short to GND fault
	S2BFlt : squib short to Vbat fault
	ShortFlt : squib short fault
	OpenFlt : squib open fault
	CCFlt : squib cross coupling fault
	NoCfgSqOpen : squib configuration fault and squib open fault
	
I<B<Description:>>  Resets TestCondition

I<B<Return:>> none

I<B<Verdict:>> none

=cut    


sub ACEA_ResetTestCondition {
	GEN_print_caller();

	my $devicename = shift;
	my $TestCondition = shift;
	my $SearchHashRef;
	my $verdict;
	my $matchedfaults_aref;
	 
	$SearchHashRef->{'Device'} = $devicename;
	
if($TestCondition eq 'CfgFlt'){
		$SearchHashRef->{'Condition'} = 'Configuration';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'S2GFlt'){
		$SearchHashRef->{'Condition'} = 'Short2Gnd';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'S2BFlt'){
		$SearchHashRef->{'Condition'} = 'Short2Bat';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'ShortFlt'){
		$SearchHashRef->{'Condition'} = 'ShortResistance';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'OpenFlt'){
		$SearchHashRef->{'Condition'} = 'Openline';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'CCFlt'){
		$SearchHashRef->{'Condition'} = 'CrossCouple';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		PD_ECUreset();
		S_wait_ms( 'TIMER_ECU_READY' );
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'NoCfgSqOpen'){
		$SearchHashRef->{'Condition'} = 'Configuration';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		$SearchHashRef->{'Condition'} = 'Openline';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms(5000);
	}
	elsif($TestCondition eq 'HighsidePowerstage'){
		$SearchHashRef->{'Condition'} = 'HighsidePowerstage';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		LC_ShortLines( [$devicename.'-', 'UF+' ] );
		S_wait_ms(5000);
		LC_UndoShortLines();
		S_wait_ms(1000);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms( 'TIMER_ECU_READY' );
		S_wait_ms(5000);
		LC_ECU_Reset();
		PD_ClearFaultMemory();
		S_wait_ms(2000);
		}
		elsif($TestCondition eq 'LowsidePowerstage'){
		$SearchHashRef->{'Condition'} = 'LowsidePowerstage';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
	    LC_ShortLines( [$devicename.'-', 'UF+' ],100 );
		S_wait_ms(5000);
		LC_UndoShortLines();
		S_wait_ms(1000);
		FM_removeFault(@$matchedfaults_aref[0]);
		S_wait_ms( 'TIMER_ECU_READY' );
		S_wait_ms(5000);
		LC_ECU_Reset();
		PD_ClearFaultMemory();
		S_wait_ms(2000);
		}
		
S_w2rep("fault $TestCondition is removed for $devicename ", 'blue');
	return 1;
}# end of ACEA_ResetTestCondition

=head2 ACEA_ReadDisableLineStatus

	ACEA_ReadDisableLineStatus();
	
I<B<Description:>>  Reads Disable Line Status

I<B<Return:>> $DisLnStatus = disable line status

I<B<Verdict:>> none

=cut    

sub ACEA_ReadDisableLineStatus {

	GEN_print_caller();
	my $Generation=PD_GetABGeneration();
	my $DisLnStatus;

	if($Generation==12)
	{
		if(PD_GetAddressByName_NOERROR_NOHTML('T_AifSconStateFlags_t_U8X(0)') ne '0x1')
		{
			$DisLnStatus = S_aref2hex(PD_ReadMemoryByName('T_AifSconStateFlags_t_U8X(0)'));
	
		}	
		else
		{
			$DisLnStatus = S_aref2hex(PD_ReadMemoryByName('T_AifSconStateFlags_t_U8X'));
		}
	}
	
	else
	{
		$DisLnStatus = S_aref2hex(PD_ReadMemoryByName('V_SCMDisableLineStatus_U8R')); #V_SCMDisableLineStatus_U8R
	}

	return $DisLnStatus;

}

=head2 ACEA_EvaluateDisableLineStatus

	ACEA_EvaluateDisableLineStatus();
	
$Exp_DisLnStatus = expected disable line status

$DisLnStatus = obtained disable line status
	
I<B<Description:>>  Evaluate Disable Line Status

I<B<Return:>> 
PASS - if $Exp_DisLnStatus mathse with $DisLnStatus
FAIl - if $Exp_DisLnStatus mismathse with $DisLnStatus

I<B<Verdict:>> none

=cut    

sub ACEA_EvaluateDisableLineStatus {
	GEN_print_caller();
	my $Exp_DisLnStatus = shift;
	my $DisLnStatus = shift;
	return 1 if $main::opt_offline;
	my $Generation=PD_GetABGeneration();
	if($Generation==12)
	{
		if($Exp_DisLnStatus eq 'DISABLED'){
			EVAL_evaluate_value("Disable line status, Expected = DISABLED", $DisLnStatus, 'MASK', '0b0011111x');
		}
		elsif($Exp_DisLnStatus eq 'ENABLED'){
	
			EVAL_evaluate_value("Disable line status, Expected = ENABLED", $DisLnStatus, 'MASK', '0bx0010000');
		}
		elsif($Exp_DisLnStatus eq 'ENABLED_EXCEPT_DISAHP'){
			EVAL_evaluate_value("Disable line status, Expected = ENABLED_EXCEPT_DISAHP", $DisLnStatus, 'MASK', '0bx0110000');
		}
		else
		{
			S_set_error("Wrong parameter $Exp_DisLnStatus",109);
	    }
	}
	else
	{
		if($Exp_DisLnStatus eq 'DISABLED'){
			EVAL_evaluate_value("Disable line status, Expected = DISABLED", $DisLnStatus, '==', '0x001E');
		}
		elsif($Exp_DisLnStatus eq 'ENABLED'){
			EVAL_evaluate_value("Disable line status, Expected = ENABLED", $DisLnStatus, '==', '0x0000');
		}
		elsif($Exp_DisLnStatus eq 'ENABLED_EXCEPT_DISAHP'){
			EVAL_evaluate_value("Disable line status, Expected = ENABLED_EXCEPT_DISAHP", $DisLnStatus, '==', '0x0010');
		}
		else{
			S_set_error("Wrong parameter $Exp_DisLnStatus",109);
		}
	}
	return 1;
}
			 
=head2 ACEA_ReadDPLStatusNVM

	ACEA_ReadDPLStatusNVM();
	
I<B<Description:>> reads DPL Status in EEPROM

I<B<Return:>> 1 DPL Status in EEPROM

I<B<Verdict:>> none

=cut 

sub ACEA_ReadDPLStatusNVM {
	my $Generation=PD_GetABGeneration();
	my $DPLStatusEEPROM;
	GEN_print_caller();
	if($Generation==12)
	{
		$DPLStatusEEPROM= NUM_ListOfBytes2Integer(PD_ReadMemoryByName('rb_dmim_ICMCfgTable_st.DeployedLoopStatus_u64'), 'U64'); 
	}
	else
	{
		$DPLStatusEEPROM = NUM_ListOfBytes2Integer(PD_ReadMemoryByName('S_ADFDeployed_XXE.V_ADFDeployedLoops_U64X'), 'U64');
	}

	return "$DPLStatusEEPROM";
}# end of ACEA_ReadDPLStatusNVM

=head2 ACEA_ReadAlgoStatus

	ACEA_ReadAlgoStatus();
	
I<B<Description:>> Reads Algo Status

I<B<Return:>> 1 Algo Status

I<B<Verdict:>> none

=cut 

sub ACEA_ReadAlgoStatus{

	GEN_print_caller();
	my $Generation=PD_GetABGeneration();
	my $AlgoStatus;
	
	if($Generation==12)
	{
		$AlgoStatus = S_aref2hex(PD_ReadMemoryByName('rb_bswm_AlgoState_au32(0)'));
	
	}
	else
	{
	
		$AlgoStatus = S_aref2hex(PD_ReadMemoryByName('V_SSMActSysMode_U32R'));
	}

	return $AlgoStatus;
}

=head2 ACEA_ReadWLStatus

	ACEA_ReadWLStatus();
	
I<B<Description:>> Reads WL Status

I<B<Return:>> 1 WL Status

I<B<Verdict:>> none

=cut 

sub ACEA_ReadWLStatus {

	GEN_print_caller();
	my $WLStatus;
	my $COM_Type;
	my $WL_Signal;
	my $Generation=PD_GetABGeneration();
	$COM_Type=$LIFT_PROJECT::Defaults->{"DISPOSAL"}{'WL_Status_Read_Method'};
	$WL_Signal=$LIFT_PROJECT::Defaults->{"DISPOSAL"}{'WL_Signal_Name'};
	if($Generation==12)
	{
		if($COM_Type eq "CAN")
		{
			$WLStatus = CA_read_can_signal($WL_Signal,'hex');
		}
		elsif($COM_Type eq "LIN")
		{
			$WLStatus = LIN_read_LIN_signal($WL_Signal,'hex');
		}
		elsif($COM_Type eq "FlexRay")
		{
			$WLStatus = FR_read_flxr_signal($WL_Signal,'hex');
		}
		elsif($COM_Type eq "PD")
		{
			$WLStatus = S_aref2hex(PD_ReadMemoryByName($WL_Signal));
		}
		else
		{
			$WLStatus = S_aref2hex(PD_ReadMemoryByName('rb_wimi_SysWIStatus_aen(0)'));  # seems to be old..
		}
		
	}
	else
	{
		$WLStatus = S_aref2hex(PD_ReadMemoryByName('A_LampLogicalStatus_SER(0)'));
	}

	return $WLStatus;

}# end of ACEA_ReadWLStatus

=head2 ACEA_EvaluateWLStatus

	ACEA_EvaluateWLStatus(($Obt_WLStatus, $Exp_WLStatus);

I<B<Description:>> Reads Algo Status
$Obt_WLStatus = obtained WL status
$Exp_WLStatus = expected WL status

I<B<Return:>> 1 

I<B<Verdict:>> none

=cut 

sub ACEA_EvaluateWLStatus{
	GEN_print_caller();

	my $Obt_WLStatus = shift;
	my $Exp_WLStatus = shift;
	return 1 if $main::opt_offline;
	if($Exp_WLStatus eq 'ON'){
		EVAL_evaluate_value("expected WL status is ON", $Obt_WLStatus, '==', '0x01');
	}
	elsif($Exp_WLStatus eq 'OFF'){
		EVAL_evaluate_value("expected WL status is OFF", $Obt_WLStatus, '==', '0x00');
	}

	return 1;

}#end of ACEA_EvaluateWLStatus

=head2 ACEA_EvaluateAlgoStatus

	ACEA_EvaluateAlgoStatus($Obt_AlgoStatus, $Exp_AlgoStatus);
	
I<B<Description:>> Reads WL Status
$Obt_AlgoStatus = obtained algo status
$Exp_AlgoStatus = expected algo status

I<B<Return:>> 1 

I<B<Verdict:>> none

=cut 

sub ACEA_EvaluateAlgoStatus {
	GEN_print_caller();
	my $Obt_AlgoStatus = shift;
	my $Exp_AlgoStatus = shift;
	return 1 if $main::opt_offline;
	#$Obt_AlgoStatus = hex($Obt_AlgoStatus) & 512;
	if($Exp_AlgoStatus eq 'ENABLED'){
		EVAL_evaluate_value("expected algo status is ENABLED", $Obt_AlgoStatus, '==', '0x00');
	}
	elsif($Exp_AlgoStatus eq 'DISABLED'){
		EVAL_evaluate_value("expected algo status is DISABLED", $Obt_AlgoStatus, '==', '0x01');
	}

	return 1;
}# end of ACEA_EvaluateAlgoStatus

=head2 ACEA_ReadDecryptionKeyInRAM

	ACEA_ReadDecryptionKeyInRAM();
	
I<B<Description:>> Reads Decryption Key In RAM

I<B<Return:>> 1 Decryption Key In RAM

I<B<Verdict:>> none

=cut 

sub ACEA_ReadDecryptionKeyInRAM {

	GEN_print_caller();
	my $DecryptionKeyInRAM;
	my $Generation=PD_GetABGeneration();

	if($Generation==10)
	{
		$DecryptionKeyInRAM = S_aref2hex(PD_ReadMemoryByName('V_DPLDecryptionKey_U16R'));

    }

	else
	{
		$DecryptionKeyInRAM = S_aref2hex(PD_ReadMemoryByName('rb_dmim_DecryptionKey_u16'));

	
	}

	return $DecryptionKeyInRAM;

}

=head2 ACEA_ReadFirstDeploymentTimeStamp

	ACEA_ReadFirstDeploymentTimeStamp();
	
I<B<Description:>> Reads First Deployment Time Stamp

I<B<Return:>> 1 First Deployment Time Stamp

I<B<Verdict:>> none

=cut 

sub ACEA_ReadFirstDeploymentTimeStamp {
	GEN_print_caller();

	my $FirstDeploymentTimeStamp = S_aref2hex(PD_ReadMemoryByName('S_ADFDeployed_XXE.V_ADFFirstDeployment_U32X'));

	return $FirstDeploymentTimeStamp;
}# end of ACEA_ReadFirstDeploymentTimeStamp

=head2 ACEA_FaultCounter

	ACEA_FaultCounter($FaultID);
		
I<B<Description:>> Reads Fault counter value
$FaultID = Fault ID
I<B<Return:>> 1 Fault Counter

I<B<Verdict:>> none

=cut 

sub ACEA_FaultCounter {

	GEN_print_caller();
	my $FaultID=shift;
	my $Faultcntr;
	my $Generation=PD_GetABGeneration();
	if($Generation==12)
	{
		$Faultcntr=S_aref2dec(PD_ReadMemoryByName('Dem_AllEventsState($FaultID).debounceLevel'));
	}
	else
	{

	}
	return $Faultcntr;
}

=head2 ACEA_ReadPowerOnTimer

	ACEA_ReadPowerOnTimer();
	
I<B<Description:>> Reads Power On Timer

I<B<Return:>> 1 Power On Timer

I<B<Verdict:>> none

=cut 

sub ACEA_ReadPowerOnTimer {

	GEN_print_caller();
	my $PowerOnTimer;
	my $temp;
	my $PonTimer;
	my @arr;
	my $i;
	my $Generation=PD_GetABGeneration();
	if($Generation==12)
	{
		for($i=4;$i<=7;$i++)
		{
			$PonTimer=PD_ReadMemoryByName('rb_tim_EcuOnTimeDataEe_st($i)');
			$temp= S_aref2hex($PonTimer);
			push (@arr, $temp);
		}
		$PowerOnTimer= S_aref2hex(@arr);
	}
	else
	{
		$PowerOnTimer  = S_aref2hex(PD_ReadMemoryByName('V_PoOnTime_U32R'));
	}
	return $PowerOnTimer ;
}#end of ACEA_ReadPowerOnTimer

=head2 ACEA_ReadDecryptedCommandsInRAM

	ACEA_ReadDecryptedCommandsInRAM();
	
I<B<Description:>> Reads Decrypted Commands In RAM

I<B<Return:>> 1 Decrypted Commands In RAM

I<B<Verdict:>> none

=cut 

sub ACEA_ReadDecryptedCommandsInRAM {

	GEN_print_caller();
	my $ACL_Status=shift;
	my $Generation=PD_GetABGeneration();
	my @DecryptedcommandsInRAM;
	if($Generation==10)
	{
		for(my $i = 0; $i < 5; $i++)
		{
			for(my $j = 0; $j < 4; $j++)
			{
				$DecryptedcommandsInRAM[$i][$j] = S_aref2hex(PD_ReadMemoryByName('A_DPLCriticalSPICmds_XSR'.'('.$i.')'.'.'.'V_DispCmd'.($j+1).'_U16X'));
			}
		}
	}
	else
	{
		if($ACL_Status eq'Yes')
		{
			$DecryptedcommandsInRAM[0]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(0)'));
			$DecryptedcommandsInRAM[1]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(1)'));
			$DecryptedcommandsInRAM[2]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(2)'));
			$DecryptedcommandsInRAM[3]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(3)'));
			$DecryptedcommandsInRAM[4]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(4)'));
		}
		else
		{
			$DecryptedcommandsInRAM[0]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(0)'));
			$DecryptedcommandsInRAM[1]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(1)'));
			$DecryptedcommandsInRAM[2]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(2)'));
			$DecryptedcommandsInRAM[3]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(3)'));
			$DecryptedcommandsInRAM[4]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_DecryptedCommand_au32(4)'));
			
		}
	}
	GEN_printTestStep("Decrypted commands array is @DecryptedcommandsInRAM");
	return \@DecryptedcommandsInRAM;
}

=head2 ACEA_EvaluateDecryptedCommandsInRAM

	ACEA_EvaluateDecryptedCommandsInRAM($ExpectedResult);
	
$DisposalcommandsInRAM_ref = reference to response array
	
$ExpectedResult = 'ZERO' or 'NONZERO'
	
I<B<Description:>> Evaluates Decrypted Commands In RAM

I<B<Return:>> 1 Decrypted Commands In RAM

I<B<Verdict:>> none

=cut 

sub ACEA_EvaluateDecryptedCommandsInRAM {
	GEN_print_caller();

	my $DisposalcommandsInRAM_ref = shift;
	my $ExpectedResult = shift;
	return 1 if $main::opt_offline;
	my $Generation=PD_GetABGeneration();
	if($Generation==10)
	{
	if($ExpectedResult eq 'ZERO'){
		for(my $i = 0; $i < 5; $i++){
			for(my $j = 0; $j < 4; $j++){
			EVAL_evaluate_value("", ${$DisposalcommandsInRAM_ref}[$i][$j], '==', 0);
			}
		}
	}
	elsif($ExpectedResult eq 'NONZERO'){
		for(my $i = 0; $i < 5; $i++){
			for(my $j = 0; $j < 4; $j++){
			EVAL_evaluate_value("", ${$DisposalcommandsInRAM_ref}[$i][$j], '!=', 0);
			}
		}
	}
	}
	else
	{
	if($ExpectedResult eq 'ZERO'){
		my @temp=@$DisposalcommandsInRAM_ref;

		for(my $i = 0; $i < scalar(@temp); $i++){
				
			EVAL_evaluate_value("", $temp[$i], '==', 0);
		}

	}
	elsif($ExpectedResult eq 'NONZERO'){

		my @temp=@$DisposalcommandsInRAM_ref;

		for(my $i = 0; $i < scalar(@temp); $i++){
				
			EVAL_evaluate_value("", $temp[$i], '!=', 0);

		}
	}
	}
	return 1;
}#end of ACEA_EvaluateDecryptedCommandsInRAM

=head2 ACEA_ExtractRespDataToBeEvaluated

	ACEA_ExtractRespDataToBeEvaluated($Response, $Position);
	
$Response = response string to be manipulated

$Position = charecter position until which string needs to be removed
	
I<B<Description:>> extracts the part of the response string to be evaluated

I<B<Return:>> 1 response string after manipulation

I<B<Verdict:>> none

=cut 

sub ACEA_ExtractRespDataToBeEvaluated {
	GEN_print_caller();

	my $Response = shift;
	my $Position = shift;
	return 1 if $main::opt_offline;
	my $ExtractedResponse = substr($Response, $Position, length($Response));

	return $ExtractedResponse;
}#end of ACEA_ExtractRespDataToBeEvaluated

=head2 ACEA_EvaluateDLTForGivenLoopId

	ACEA_EvaluateDLTForGivenLoopId($Response, $Exp_LoopStatus, $LoopId);
	
$Response = response string to be evaluated

$Exp_LoopStatus = expected loop status

$LoopId = loop id for which loop status needs to be evaluated
	
I<B<Description:>> evaluates loop status for given loop id in give response

I<B<Return:>> 
PASS : if $Exp_LoopStatus matches with loop status in $response for given loop id
FAIL : if $Exp_LoopStatus mismatches with loop status in $response for given loop id

I<B<Verdict:>> none

=cut 

sub ACEA_EvaluateDLTForGivenLoopId {
	GEN_print_caller();

	my $Response = shift;
	my $Exp_LoopStatus = shift;
	my $LoopId = shift;
	my $testCondition = shift;
	return 1 if $main::opt_offline;
	my $LoopStatus = undef;
	my @TempResponse = split(/ /, $Response);
	for(my $i = 0; $i < scalar(@TempResponse); $i = $i + 2){
		S_w2rep("$TempResponse[$i] = $TempResponse[$i+1]");
		if($TempResponse[$i] eq $LoopId){
			$LoopStatus = $TempResponse[$i + 1];
			last;
		}
	}

	if(not defined ($LoopStatus))
	{
		if($testCondition =~ m/^CfgFlt$/i)
		{
			GEN_printComment("For configuration fault : Loop ID is not present in the Deployment Loop Table");
			S_set_verdict('VERDICT_PASS');
		}
		elsif($testCondition =~ m/^NoCfgSqOpen$/i)
		{
			GEN_printComment("For only monitored squib : Loop ID is not present in the Deployment Loop Table");
			S_set_verdict('VERDICT_PASS');
		}
		elsif($testCondition =~ m/^NotSupportedSquib$/i)
		{
			GEN_printComment("For not supported squib : Loop ID is not present in the Deployment Loop Table");
			S_set_verdict('VERDICT_PASS');
		}
		else
		{
			GEN_printComment("Expected Loop ID is not present in the Deployment Loop Table");
			S_set_verdict('VERDICT_FAIL');
		}
	}
	else
	{
		EVAL_evaluate_string( "Loop status in the deployment loop table", $Exp_LoopStatus, $LoopStatus);
	}
return 1;
}#end of ACEA_EvaluateDLTForGivenLoopId
	 
=head2 ACEA_ProjectSpecificSettings

	ACEA_ProjectSpecificSettings();
	
I<B<Description:>> Project specific function to make ECU fault free - is a dummy function

I<B<Return:>> none

I<B<Verdict:>> none

=cut    

sub ACEA_ProjectSpecificSettings {

	GEN_print_caller();

	S_w2rep("No project specific settings required", 'blue');
return 1;
}


=head2 ACEA_GetWrongKey

	ACEA_GetWrongKey($Key);
	
I<B<Description:>> This function returns the wrong key to get the security access for disposal.

I<B<Return:>> Returns wrong key string.

I<B<Verdict:>> none

=cut    


sub ACEA_GetWrongKey {

	GEN_print_caller();
	my $Key = shift;
	#Split key in to an array
	my @temp_Key = split(' ', $Key);
	#Adding one to the key bytes to make it wrong key
	$temp_Key[0] = $temp_Key[0] + 1;
	$temp_Key[1] = $temp_Key[1] + 1;
	#creating Wrong key from array to string
	my $wrong_Key = join(" ",@temp_Key);
	#returning the wrong key string
	return $wrong_Key;

} #ACEA_GetWrongKey


=head2 ACEA_ReadSDLstatus

	ACEA_ReadSDLstatus();
	
I<B<Description:>> This function returns the SDL switch status

I<B<Return:>> Returns SDL switch status.

I<B<Verdict:>> none

=cut 


sub ACEA_ReadSDLstatus {
	GEN_print_caller();
	my $SDLstatus;
	$SDLstatus=S_aref2hex(PD_ReadMemoryByName('rb_swm_SwitchInfo_ast(0).PositionFiltered_en'));
	return $SDLstatus;
}


=head2 ACEA_EvaluateSDLstatus

	ACEA_EvaluateSDLstatus($SDLstatus,$SDLbehaviour);
	$SDLstatus --> Status of SDL switch observed
	$SDLbehaviour --> Expected behaviur of SDL switch
	
I<B<Description:>> This function evaluate SDL switch status. 

I<B<Verdict:>> none

=cut 


sub	ACEA_EvaluateSDLstatus {
	GEN_print_caller();
	my $SDLstatus=shift;
	my $SDLbehaviour=shift;
	return 1 if $main::opt_offline;
	my $Temp;
	if($SDLbehaviour eq'MONITORED')
	{
		$Temp=0x01;
		EVAL_evaluate_value("SDLSwitchbehaviour",$Temp,'==',$SDLstatus);
	}
	elsif($SDLbehaviour eq'NOTMONITORED')
	{
		$Temp=0x00;
		EVAL_evaluate_value("SDLSwitchbehaviour",$Temp,'==',$SDLstatus);
	}
return 1;
}


=head2 ACEA_RequestRoutineResults_SPL
      
	$Diag_response = ACEA_RequestRoutineResults_SPL ($controlByte,$routineStatusRecord,$Response,[$Eval_Switch]);

I<B<Description:>>  Requests SPL Routine Results

$controlByte = Routine Control Option(either 00 or 01)

$routineStatusRecord = Routine status record for OEM. This value can be obtained from SYC of the project.

$Eval_Switch = Switch to skip evaluation

I<B<Return:>> 1 Diag response string obtained

I<B<Verdict:>> 
No verdict is set if evaluation is skipped
PASS : if response obtained matches with positive response as in diag mapping file
FAIL : if response obtained mismatches with positive response as in diag mapping file  

Note : 
internally calls GDCOM_request_general

=cut


sub ACEA_RequestRoutineResults_SPL {

	GEN_print_caller();
	my $controlByte = shift;
	my $routineStatusRecord = shift;
	my $Response =shift;
	my $Eval_Switch=shift;
	my %RoutineControlOption;
	my $DiagResponse;
	$RoutineControlOption{'RoutineControlResult'} =$routineStatusRecord.' '.$controlByte;
	unless(defined($Response))
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_ReqRoutineResult_ExecuteDisposalProgramLoader", "PR_RoutineControl_ReqRoutineResult_ExecuteDisposalProgramLoader",\%RoutineControlOption, $Eval_Switch);
	}
	else
	{
		$DiagResponse = GDCOM_request_general ("REQ_RoutineControl_ReqRoutineResult_ExecuteDisposalProgramLoader", "$Response",\%RoutineControlOption, $Eval_Switch);
	}
	return $DiagResponse;

}


=head2 ACEA_ReadEncryptedCommandsInROM

	ACEA_ReadEncryptedCommandsInROM();
	
I<B<Description:>> Reads Encrypted Commands In ROM

I<B<Return:>> 1 Encrypted Commands In ROM

I<B<Verdict:>> none

=cut 


sub ACEA_ReadEncryptedCommandsInROM {

	GEN_print_caller();
	my $ACL_Level=shift;
	my @EncryptedcommandsInROM;

		if($ACL_Level eq'Yes')
		{

			$EncryptedcommandsInROM[0]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(0)'));
			$EncryptedcommandsInROM[1]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(1)'));
			$EncryptedcommandsInROM[2]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(2)'));
			$EncryptedcommandsInROM[3]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(3)'));
			$EncryptedcommandsInROM[4]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(4)'));
		}
		else
		{
			$EncryptedcommandsInROM[0]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(0)'));
			$EncryptedcommandsInROM[1]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(1)'));
			$EncryptedcommandsInROM[2]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(2)'));
			$EncryptedcommandsInROM[3]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(3)'));
			$EncryptedcommandsInROM[4]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(4)'));
			$EncryptedcommandsInROM[5]= S_aref2hex(PD_ReadMemoryByName('rb_dmdm_EncryptedCommand_au32(5)'));
		}

	GEN_printTestStep("@EncryptedcommandsInROM");
	return \@EncryptedcommandsInROM;
}

=head2 ACEA_FireCounter

	ACEA_FireCounter($Condition,$Squib_Name);
	
I<B<Description:>> Reads Firecounter variables and checks for unique counter

$Condition=Test condition

$SquibName=Name of the squib to be fired

I<B<Return:>> 1 

I<B<Verdict:>> none

=cut 


sub ACEA_FireCounter
{
	GEN_print_caller();
	my $Condition= shift;
	my $Squib_Name=shift;
	return 1 if $main::opt_offline;
	my ($count, $count1, $count2, $count3);
	my $temp;
	my @Counter_val;
	$temp=0;

 	my $diagSymType;
	S_wait_ms(2000);
	if (PD_GetAddressByName_NOERROR_NOHTML("rb_sqmf_Firecounter_au16(0)(0)") ne '0x1')
	{
		$diagSymType = 3;
		S_w2log(1, "diagSym Type is $diagSymType");
	}
	else 
	{
		$diagSymType = 2;
		S_w2log(1, "diagSym Type is $diagSymType");
	}

	if($diagSymType eq 2)
	{
		for($count=0;$count<32;$count++)
		{
			$Counter_val[$count]=S_aref2hex(PD_ReadMemoryByName("rb_sqmf_Firecounter_au16($count)"));
		}
	}
	else
	{
		for($count1=0;$count1<2;$count1++)
		{
			for($count2=0;$count2<16;$count2++) 
			{
				$Counter_val[$count3]=S_aref2hex(PD_ReadMemoryByName("rb_sqmf_Firecounter_au16($count1)($count2)"));
				$count3=$count3+1;
			}
		}
	}


	for($count=0;$count<32;$count++)
	{
		if($Counter_val[$count] ne '0x0000')
		{
			if($Counter_State != $count)
			{
				$Counter_State = $count;
				$temp=1;
				last;
			}
			else
			{
				GEN_printComment("Same Counter:Already fired squib");
			}
		}
	}
	
	if($temp==1)
	{
		GEN_printComment("Unique Fire Counter obtained with Non zero value at index $Counter_State");
	}
	elsif($temp==0 &&(($Condition eq "NotSupportedSquib")||($Condition eq "NoCfgSqOpen")||($Condition eq "OpenFlt")||($Condition eq "CfgFlt")))
	{
		GEN_printComment("All Counters are Zero is as Expected");
		S_set_verdict ( 'VERDICT_PASS');
		return 1;
	}
	elsif($temp==0 && (($Condition_Global ne $Condition)&&($Squib_Global eq $Squib_Name)))
	{
		GEN_printComment("Same Counter is obtained because same squib is fired");
		S_set_verdict ( 'VERDICT_PASS');
		return 1;
	}
	else
	{
		GEN_printComment("Unique Fire Counter is not obtained with Non zero value");
		S_set_verdict ( 'VERDICT_FAIL');
		return 0;
	}
	$Condition_Global=$Condition;
	$Squib_Global=$Squib_Name;
}


=head2 ACEA_FireCondition

	ACEA_FireCondition();

I<B<Description:>> This function is used to perform any customer specific precondition before firing.

Example:
ACEA_FireCondition();

I<B<Return:>> None
=cut 

sub ACEA_FireCondition {
	GEN_print_caller();
	S_w2rep("Please add customer specific function, if available,'blue' ");
}

1;