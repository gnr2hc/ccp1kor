#### TEST CASE MODULE
package TC_DIS_FaultHandling_AB12;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_NET_access;
use INCLUDES_Project;
use GENERIC_DCOM;

#necessary
#include further modules here

##################################

our $PURPOSE = "To test fault handling during ACEA deployment procedure";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_FaultHandling

=head1 PURPOSE

To test fault handling during ACEA deployment procedure

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

 	1. Standard Preparation
	2. No ACL connected
	3. Tester present diag service is transmitted cyclically to keep diagnostics active


I<B<Stimulation and Measurement>>
	
	2. Read fault memory before entering to disposal session
		
		- Execute steps 3 to 12 for all supported squibs
		- skip DPL activation i.e. step 3 to 6 if ECU reset is not performed
	3. Initiate Safety System Diagnostic Session
	4. Read fault memory after disposal session is entered
	5. Obtain security access to download and activateDPL 
	6. Execute SPL
	7. Connect ACL PWM signal, if ACL check is done by the SW for ACEA deployment 
	8. Perform ACEA deployement
	   
	9. Perform ECU reset if required
	10,11.	Read fault memory after each squib deployment

	12. Perform ECU reset if required after all squibs deployed	
	13 & 14. Read fault memory after all squibs are deployed


I<B<Evaluation>>


	2. Evaluate fault memory data read before entering to disposal session
		
		- Execute steps 3 to 12 for all supported squibs
		- skip DPL activation i.e. step 3 to 6 if ECU reset is not performed
	3. Evaluate positive response for diag service "Initiate Safety System Diagnostic Session"
	4. Read fault memory after disposal session is entered
	5. Evaluate positive response for diag service "Obtain security access to download and activateDPL" 
	6. Evaluate positive response for diag service "Execute SPL""
	7.  
	8. Evaluate positive response for diag service "Perform ACEA deployement"
	9. 
	10,11. Evaluate fault memory data read after each squib deployment

	13. 
	14&15. Evaluate fault memory data read after all squibs are deployed


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test
	SCALAR 'Fault1_ExpName' => name of the fault 1
	SCALAR 'Fault2_ExpName' => name of the fault 2
	SCALAR 'Fault1_ExpStatus_DisposalSessionEntry' => expected fault status of fault 1 after disposal session entry
	SCALAR 'Fault2_ExpStatus_DisposalSessionEntry' =>  expected fault status of fault 2 after disposal session entry
	SCALAR 'Fault1_ExpStatus_FirstFiring' => expected fault status of fault 1 after first squib firing
	SCALAR 'Fault2_ExpStatus_FirstFiring' => expected fault status of fault 2 after first squib firing
	SCALAR 'Fault1_ExpStatus_AllSquibsFired' => expected fault status of fault 1 before all squib are fired
	SCALAR 'Fault2_ExpStatus_AllSquibsFired' => expected fault status of fault 2 before all squib are fired
	SCALAR 'TestCondition' => condition for the test
	SCALAR 'ACLSupported' => Is ACl supported by SW under test
	SCALAR 'PowerOnTimer_var' => variable to read power on timer
	SCALAR 'FirstDeploymentTimeStamp_var' => variable to read First Deployment Time Stamp
	SCALAR 'Squib_LoopIds' => list of squibs and loop ids supported by SW


=head2 PARAMETER EXAMPLES

	TestCondition = '<Test Heading 2>'
	ACLSupported = 'yes' #'Yes' or 'No'
	PowerOnTimer_var = 'V_PoOnTime_U32R'
	FirstDeploymentTimeStamp_var = 'S_ADFDeployed_XXE.V_ADFFirstDeployment_U32X'
	
	Squib_LoopIds = <Fetch {Proj1_SWExpectedValue}>
	purpose  = 'To test fault handling during ISO disposal deployment procedure only when InProgress fault is configured, and when no reset is performed troughout the test'
	Fault1_ExpName = 'rb_dmim_DeploymentIsInProgress_flt'
	Fault2_ExpName = 'rb_dmim_DeploymentComplete_flt'
	Fault1_ExpStatus_DisposalSessionEntry = '0x00'
	Fault2_ExpStatus_DisposalSessionEntry = '0x00'
	Fault1_ExpStatus_FirstFiring = '0x1F'
	Fault2_ExpStatus_FirstFiring = '0x00'
	Fault1_ExpStatus_AllSquibsFired = '0x26'
	Fault2_ExpStatus_AllSquibsFired = '0x00'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_TestCondition;
my $tcpar_ACLSupported;
my $tcpar_Squib_LoopIds;
my $tcpar_purpose;
my $tcpar_Fault1_ExpName;
my $tcpar_Fault2_ExpName;
my $tcpar_Fault1_ExpStatus_DisposalSessionEntry;
my $tcpar_Fault2_ExpStatus_DisposalSessionEntry;
my $tcpar_Fault1_ExpStatus_FirstFiring;
my $tcpar_Fault2_ExpStatus_FirstFiring;
my $tcpar_Fault1_ExpStatus_AllSquibsFired;
my $tcpar_Fault2_ExpStatus_AllSquibsFired;

################ global parameter declaration ###################
my $ExecuteSPL_With_Conversion = '01';
my ( $DeploymentTimeStamp_AftrDeployment, $FirstDeploymentTimeStamp_2, $PowerOnTimer, $routineStatusRecord, $Faultmemorystate, @FaultMemoryStatusaftrDisposal, @FaultMemoryStatusAftrFiring, $FaultMemoryStatusAftrAllFiring, $NumberOfIterations, @SquibNames, @LoopIds, $verdict );
my $TP_handle;
my @DLT_ID;
my $count;
my $i = 0;

###############################################################

sub TC_set_parameters {

	$tcpar_TestCondition                         = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_ACLSupported                          = S_read_mandatory_testcase_parameter('ACLSupported');
	$tcpar_Squib_LoopIds                         = S_read_mandatory_testcase_parameter('Squib_LoopIds');
	$tcpar_purpose                               = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Fault1_ExpName                        = S_read_optional_testcase_parameter('Fault1_ExpName');
	$tcpar_Fault2_ExpName                        = S_read_optional_testcase_parameter('Fault2_ExpName');
	$tcpar_Fault1_ExpStatus_DisposalSessionEntry = S_read_mandatory_testcase_parameter('Fault1_ExpStatus_DisposalSessionEntry');
	$tcpar_Fault2_ExpStatus_DisposalSessionEntry = S_read_mandatory_testcase_parameter('Fault2_ExpStatus_DisposalSessionEntry');
	$tcpar_Fault1_ExpStatus_FirstFiring          = S_read_mandatory_testcase_parameter('Fault1_ExpStatus_FirstFiring');
	$tcpar_Fault2_ExpStatus_FirstFiring          = S_read_mandatory_testcase_parameter('Fault2_ExpStatus_FirstFiring');
	$tcpar_Fault1_ExpStatus_AllSquibsFired       = S_read_mandatory_testcase_parameter('Fault1_ExpStatus_AllSquibsFired');
	$tcpar_Fault2_ExpStatus_AllSquibsFired       = S_read_mandatory_testcase_parameter('Fault2_ExpStatus_AllSquibsFired');

	my $ProjConst_notSupported_Squibs = $LIFT_PROJECT::Defaults->{'notSupported_Squibs'};

	my @Squib_LoopIds = split( /\\n/, $tcpar_Squib_LoopIds );
	my @Temp_Squib_LoopIds;
	S_w2rep("Temp=@Squib_LoopIds");
	S_w2rep("$Squib_LoopIds[0]");
	my $size = scalar(@Squib_LoopIds);
	my $i    = 0;
	foreach (@Squib_LoopIds) {
		( $SquibNames[$i], $LoopIds[$i] ) = split( ' ', $_ );
		++$i;
	}

	$routineStatusRecord = S_get_label( 'RoutineStatusRecord', ['DISPOSAL'] )
	  if S_check_label( 'RoutineStatusRecord', ['DISPOSAL'] );

	return 1;
}

sub TC_initialization {

	S_w2rep("Set the preconditions for this test case");
	S_w2rep("Squib names are @SquibNames \n");
	S_w2rep("Loop IDs are @LoopIds \n");

	S_teststep( "NET_simulation_start\n", 'NO_AUTO_NBR' );
	NET_simulation_start();    # starts RBS &  switch - off logging fast

	S_teststep( "NET_trace_start\n", 'NO_AUTO_NBR' );
	NET_trace_start();         # switch - on logging the trace

	S_teststep( "GEN_StandardPrepNoFault\n", 'NO_AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_w2rep("NoACLConnected");
	my $status = ACEA_SetACLConnection('Disconnect');

	S_teststep( "GDCOM_set_addressing_mode( 'disposal' )\n", 'NO_AUTO_NBR' );
	GDCOM_set_addressing_mode("disposal");

	S_teststep( "ACEA_Send_TesterPresent_Cyclically\n", 'NO_AUTO_NBR' );
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Read fault memory before entering to disposal session ", 'AUTO_NBR', 'STEP_2' );

	$Faultmemorystate = FM_PD_readFaultMemory();

	my $Squib = '';

	my $SquibIndex                         = 0;
	my $Deployment_Loop_structure_Complete = ACEA_Read_DiploymentLoopTable();
	my $Deployment_Loop_structure_Extract  = ACEA_ExtractRespDataToBeEvaluated( $Deployment_Loop_structure_Complete, 18 );
	my @DLT_Squib                          = split( ' ', $Deployment_Loop_structure_Extract );

	for ( $count = 0 ; $count < scalar(@DLT_Squib) ; $count = $count + 2 ) {
		$DLT_ID[$i] = $DLT_Squib[$count];
		$i = $i + 1;
	}

	foreach $Squib (@SquibNames) {
		if ( ( $tcpar_TestCondition eq 'ResetAfterEachSquibFiring' ) || ( $SquibIndex == 0 ) )    #To skip DPL activation if ECU reset is not performed
		{
			S_teststep( "$Squib-> Initiate Safety System Diagnostic Session", 'AUTO_NBR', $Squib . "STEP_3" );
			GDCOM_StartSession('DisposalSession');

			S_teststep( "$Squib-> Read fault memory after disposal session is entered", 'AUTO_NBR', $Squib . "STEP_4" );
			$FaultMemoryStatusaftrDisposal[$SquibIndex] = FM_PD_readFaultMemory();

			S_teststep( "$Squib-> Obtain security access to download and activateDPL", 'AUTO_NBR', $Squib . "STEP_5" );
			ACEA_Get_SecurityAccess();

			S_teststep( "$Squib-> Execute SPL", 'AUTO_NBR', $Squib . "STEP_6" );
			ACEA_ExecuteDisposalProgramLoader( $ExecuteSPL_With_Conversion, $routineStatusRecord );

		}

		#if($SquibIndex == 0)
		#{
		if ( $tcpar_ACLSupported eq 'Yes' ) {
			S_teststep( "$Squib-> Connect ACL PWM signal, if ACL check is done by the SW for ACEA deployment ", 'AUTO_NBR', $Squib . "STEP_7" );
			ACEA_SetACLConnection('Connect');    #Check is ACL check is done by the SW for ACEA deployment
			S_wait_ms(3000);
		}

		#}

		S_teststep( "$Squib->Perform ACEA deployement", 'AUTO_NBR', $Squib . "STEP_8" );

		my $LoopId = $LoopIds[$SquibIndex];
		$LoopId =~ s/0x//;

		#$tcpar_Squib_LoopIds=~ s/0x//;
		for ( $count = 0 ; $count < scalar(@DLT_ID) ; $count++ ) {

			my $Temp_LoopID = uc($LoopId);

			if ( $DLT_ID[$count] eq $Temp_LoopID ) {
				S_wait_ms(3000);
				ACEA_FireSquib( $Temp_LoopID, undef, $routineStatusRecord );

				S_wait_ms(100);
				last;
			}
		}

		if ( $tcpar_TestCondition eq 'ResetAfterEachSquibFiring' ) {
			S_teststep( "$Squib-> Perform ECU reset", 'AUTO_NBR', $Squib . "STEP_9" );
			GEN_Power_on_Reset();
		}

		S_teststep( "$Squib-> Read fault memory after each squib deployment", 'AUTO_NBR', $Squib . "STEP_1011" );
		$FaultMemoryStatusAftrFiring[$SquibIndex] = FM_PD_readFaultMemory();
		$SquibIndex++;
	}

	if ( $tcpar_TestCondition eq 'ResetAfterAllSquibFiring' ) {
		S_teststep( "$Squib-> Perform ECU reset if required after all squibs deployed", 'AUTO_NBR', $Squib . "STEP_12" );
		GEN_Power_on_Reset();
	}

	S_teststep( "$Squib-> Read fault memory after all squibs are deployed", 'AUTO_NBR', $Squib . "STEP_1314" );
	$FaultMemoryStatusAftrAllFiring = FM_PD_readFaultMemory();

	S_teststep( "Stop and Store Network trace\n", 'NO_AUTO_NBR' );

	# NET_trace_stop();               #  switch - off logging (only) but not the measurement
	# CA_trace_stop();
	my $can_trace_file = NET_trace_store();    # storing the trace
	                                           # my $can_trace_file = CA_trace_store();# storing the trace
	S_w2rep(" NET trace stored : can_trace_file\n");

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluate fault memory data read before entering to disposal session ");
	$verdict = PD_evaluate_faults( $Faultmemorystate, [] );
	S_teststep_expected( " fault memory data read before entering to disposal session is empty \n ", 'STEP_2' );
	if ( $verdict eq 'VERDICT_PASS' ) {
		S_teststep_detected( "fault memory data read before entering to disposal session is:" . $Faultmemorystate . "\n", 'STEP_2' );
	}

	if ( $verdict eq 'VERDICT_FAIL' ) {
		S_teststep_detected( "MISMATCH: fault memory data read before entering to disposal session is:" . $Faultmemorystate . "\n", 'STEP_2' );
	}

	my $Squib;

	my $SquibIndex = 0;

	foreach $Squib (@SquibNames) {
		if ( ( $tcpar_TestCondition eq 'ResetAfterEachSquibFiring' ) || ( $SquibIndex == 0 ) ) {
			S_w2rep("Evaluation $Squib-> Evaluate positive response for diag service Initiate Safety System Diagnostic Session-Evaluation is done at Measurement and setup");
			S_teststep_expected( "Evaluate positive response for diag service Initiate Safety System Diagnostic Session-Evaluation is done at Measurement and setup(Refer the traces or html report)\n", $Squib . "STEP_3" );
			S_teststep_detected( "Evaluate positive response for diag service Initiate Safety System Diagnostic Session-Evaluation is done at Measurement and setup(Refer the traces or html report)\n", $Squib . "STEP_3" );

			S_w2rep("Evaluation for $Squib-> Read fault memory after disposal session is entered");
			if ( $SquibIndex == 0 ) {

				$verdict = PD_evaluate_faults( $FaultMemoryStatusaftrDisposal[$SquibIndex], [] );
				S_teststep_expected( " Read fault memory after disposal session is Empty \n ", $Squib . "STEP_4" );
				if ( $verdict eq 'VERDICT_PASS' ) {
					S_teststep_detected( "Read fault memory after disposal session is:" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
				}

				if ( $verdict eq 'VERDICT_FAIL' ) {
					S_teststep_detected( "MISMATCH: Read fault memory after disposal session is:" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
				}
			}
			else {
				if ( $tcpar_Fault1_ExpStatus_DisposalSessionEntry ne '0x00' ) {

					$verdict = EVAL_check_fault_status( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_DisposalSessionEntry );
					S_teststep_expected( " status byte for $tcpar_Fault1_ExpName should have  $tcpar_Fault1_ExpStatus_DisposalSessionEntry \n ", $Squib . "STEP_4" );
					if ( $verdict eq 'VERDICT_PASS' ) {
						S_teststep_detected( "status byte for $tcpar_Fault1_ExpName matches $tcpar_Fault1_ExpStatus_DisposalSessionEntry" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
					}

					if ( $verdict eq 'VERDICT_FAIL' ) {
						S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault1_ExpName not matches $tcpar_Fault1_ExpStatus_DisposalSessionEntry" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
					}
				}

				else {
					$verdict = EVAL_evaluate_value( "Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault1_ExpName ), '==', 0 );
					my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault1_ExpName );
					S_teststep_expected( " Occurence counter for $tcpar_Fault1_ExpName should be zero \n ", $Squib . "STEP_4" );
					if ( $verdict eq 'VERDICT_PASS' ) {
						S_teststep_detected( "Occurence counter for $tcpar_Fault1_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_4" );
					}

					if ( $verdict eq 'VERDICT_FAIL' ) {
						S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault1_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_4" );
					}
				}

				if ( $tcpar_Fault2_ExpStatus_DisposalSessionEntry ne '0x00' ) {
					$verdict = EVAL_check_fault_status( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_DisposalSessionEntry );
					S_teststep_expected( " status byte for $tcpar_Fault2_ExpName should have  $tcpar_Fault2_ExpStatus_DisposalSessionEntry \n ", $Squib . "STEP_4" );
					if ( $verdict eq 'VERDICT_PASS' ) {
						S_teststep_detected( "status byte for $tcpar_Fault2_ExpName matches $tcpar_Fault2_ExpStatus_DisposalSessionEntry" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
					}

					if ( $verdict eq 'VERDICT_FAIL' ) {
						S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault2_ExpName not matches $tcpar_Fault2_ExpStatus_DisposalSessionEntry" . $FaultMemoryStatusaftrDisposal[$SquibIndex] . "\n", $Squib . "STEP_4" );
					}
				}

				else {
					$verdict = EVAL_evaluate_value( "Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault2_ExpName ), '==', 0 );
					my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusaftrDisposal[$SquibIndex], $tcpar_Fault1_ExpName );
					S_teststep_expected( " Occurence counter for $tcpar_Fault2_ExpName should be zero \n ", $Squib . "STEP_4" );
					if ( $verdict eq 'VERDICT_PASS' ) {
						S_teststep_detected( "Occurence counter for $tcpar_Fault2_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_4" );
					}

					if ( $verdict eq 'VERDICT_FAIL' ) {
						S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault2_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_4" );
					}
				}

			}

			S_teststep_expected( "Evaluation for $Squib->  Security access Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_5" );
			S_teststep_detected( "Evaluation for $Squib->  Security access Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_5" );

			S_teststep_expected( "Evaluation for $Squib->  SPL Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_6" );
			S_teststep_detected( "Evaluation for $Squib->  SPL Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_6" );

		}

		if ( $tcpar_ACLSupported eq 'Yes' ) {
			S_teststep_expected( "Evaluation for $Squib->  ACL-No Evaluation \n", $Squib . "STEP_7" );
			S_teststep_detected( "Evaluation for $Squib->  ACL-No Evaluation \n", $Squib . "STEP_7" );
		}

		S_teststep_expected( "Evaluation for $Squib->  ACEA Deployment Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_8" );
		S_teststep_detected( "Evaluation for $Squib->  ACEA Deployment Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_8" );

		if ( $tcpar_TestCondition eq 'ResetAfterEachSquibFiring' ) {
			S_teststep_expected( "Evaluation for $Squib->  ECU REset Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_9" );
			S_teststep_detected( "Evaluation for $Squib->  ECU Reset Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_9" );
		}

		S_w2rep("Evaluation for $Squib-> Evaluate fault memory data read after each squib deployment");

		if ( $SquibIndex != ( scalar(@SquibNames) - 1 ) ) {
			if ( $tcpar_Fault1_ExpStatus_FirstFiring ne '0x00' ) {
				EVAL_check_fault_status( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_FirstFiring );
				S_teststep_expected( " status byte for $tcpar_Fault1_ExpName should have  $tcpar_Fault1_ExpStatus_FirstFiring \n ", $Squib . "STEP_1011" );
				if ( $verdict eq 'VERDICT_PASS' ) {
					S_teststep_detected( "status byte for $tcpar_Fault1_ExpName matches $tcpar_Fault1_ExpStatus_FirstFiring" . $FaultMemoryStatusAftrFiring[$SquibIndex] . "\n", $Squib . "STEP_1011" );
				}

				if ( $verdict eq 'VERDICT_FAIL' ) {
					S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault1_ExpName not matches $tcpar_Fault1_ExpStatus_FirstFiring" . $FaultMemoryStatusAftrFiring[$SquibIndex] . "\n", $Squib . "STEP_1011" );
				}
			}
			elsif ( $tcpar_Fault1_ExpStatus_FirstFiring eq '0x00' ) {
				EVAL_evaluate_value( "Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault1_ExpName ), '==', 0 );
				my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault1_ExpName );
				S_teststep_expected( " Occurence counter for $tcpar_Fault1_ExpName should be zero \n ", $Squib . "STEP_1011" );
				if ( $verdict eq 'VERDICT_PASS' ) {
					S_teststep_detected( "Occurence counter for $tcpar_Fault1_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1011" );
				}

				if ( $verdict eq 'VERDICT_FAIL' ) {
					S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault1_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1011" );
				}
			}

			if ( $tcpar_Fault2_ExpStatus_FirstFiring ne '0x00' ) {
				EVAL_check_fault_status( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_FirstFiring );
				S_teststep_expected( " status byte for $tcpar_Fault2_ExpName should have  $tcpar_Fault2_ExpStatus_FirstFiring \n ", $Squib . "STEP_1011" );
				if ( $verdict eq 'VERDICT_PASS' ) {
					S_teststep_detected( "status byte for $tcpar_Fault2_ExpName matches $tcpar_Fault2_ExpStatus_FirstFiring" . $FaultMemoryStatusAftrFiring[$SquibIndex] . "\n", $Squib . "STEP_1011" );
				}

				if ( $verdict eq 'VERDICT_FAIL' ) {
					S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault2_ExpName not matches $tcpar_Fault2_ExpStatus_FirstFiring" . $FaultMemoryStatusAftrFiring[$SquibIndex] . "\n", $Squib . "STEP_1011" );
				}
			}
			elsif ( $tcpar_Fault2_ExpStatus_FirstFiring eq '0x00' ) {
				EVAL_evaluate_value( "Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault2_ExpName ), '==', 0 );
				my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusAftrFiring[$SquibIndex], $tcpar_Fault2_ExpName );
				S_teststep_expected( " Occurence counter for $tcpar_Fault2_ExpName should be zero \n ", $Squib . "STEP_1011" );
				if ( $verdict eq 'VERDICT_PASS' ) {
					S_teststep_detected( "Occurence counter for $tcpar_Fault2_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1011" );
				}

				if ( $verdict eq 'VERDICT_FAIL' ) {
					S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault2_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1011" );
				}
			}
		}

		$SquibIndex++;
	}

	if ( $tcpar_TestCondition eq 'ResetAfterAllSquibFiring' ) {
		S_teststep_expected( "Evaluation for $Squib->  ECU Reset Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_12" );
		S_teststep_detected( "Evaluation for $Squib->  ECU Reset Evaluation is done at Stimulation and setup(Refer the traces or html report)\n", $Squib . "STEP_12" );
	}

	S_w2rep("Evaluation for $Squib->. Evaluate fault memory data read after all squibs are deployed");

	if ( $tcpar_Fault1_ExpStatus_AllSquibsFired ne '0x00' ) {
		EVAL_check_fault_status( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault1_ExpName, $tcpar_Fault1_ExpStatus_AllSquibsFired );
		S_teststep_expected( " status byte for $tcpar_Fault1_ExpName should have  $tcpar_Fault1_ExpStatus_AllSquibsFired \n ", $Squib . "STEP_1314" );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "status byte for $tcpar_Fault1_ExpName matches $tcpar_Fault1_ExpStatus_AllSquibsFired" . $FaultMemoryStatusAftrAllFiring . "\n", $Squib . "STEP_1314" );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault1_ExpName not matches $tcpar_Fault1_ExpStatus_AllSquibsFired" . $FaultMemoryStatusAftrAllFiring . "\n", $Squib . "STEP_1314" );
		}
	}
	else {
		$verdict = EVAL_evaluate_value( "Fault $tcpar_Fault1_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault1_ExpName ), '==', 0 );
		my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault1_ExpName );
		S_teststep_expected( " Occurence counter for $tcpar_Fault1_ExpName should be zero \n ", $Squib . "STEP_1314" );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Occurence counter for $tcpar_Fault1_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1314" );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault1_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1314" );
		}
	}

	if ( $tcpar_Fault2_ExpStatus_AllSquibsFired ne '0x00' ) {
		EVAL_check_fault_status( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault2_ExpName, $tcpar_Fault2_ExpStatus_AllSquibsFired );
		S_teststep_expected( " status byte for $tcpar_Fault2_ExpName should have  $tcpar_Fault1_ExpStatus_AllSquibsFired \n ", $Squib . "STEP_1314" );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "status byte for $tcpar_Fault2_ExpName matches $tcpar_Fault2_ExpStatus_AllSquibsFired" . $FaultMemoryStatusAftrAllFiring . "\n", $Squib . "STEP_1314" );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( "MISMATCH: status byte for $tcpar_Fault2_ExpName not matches $tcpar_Fault2_ExpStatus_AllSquibsFired" . $FaultMemoryStatusAftrAllFiring . "\n", $Squib . "STEP_1314" );
		}
	}
	else {
		$verdict = EVAL_evaluate_value( "Fault $tcpar_Fault2_ExpName is not present in fault memory", PD_count_fault( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault2_ExpName ), '==', 0 );
		my $detected_OccurenceCounter = PD_count_fault( $FaultMemoryStatusAftrAllFiring, $tcpar_Fault2_ExpName );
		S_teststep_expected( " Occurence counter for $tcpar_Fault2_ExpName should be zero \n ", $Squib . "STEP_1314" );
		if ( $verdict eq 'VERDICT_PASS' ) {
			S_teststep_detected( "Occurence counter for $tcpar_Fault2_ExpName" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1314" );
		}

		if ( $verdict eq 'VERDICT_FAIL' ) {
			S_teststep_detected( " MISMATCH: Occurence counter for $tcpar_Fault2_ExpName is" . $detected_OccurenceCounter . "\n", $Squib . "STEP_1314" );
		}
	}

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);

	S_w2rep("Reset Addressing Mode");
	GDCOM_set_addressing_mode("physical");

	GEN_Power_on_Reset();
	GEN_AutoECUFlash();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
