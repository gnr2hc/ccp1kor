#### TEST CASE MODULE
package TC_DIS_IdleModeStrategy;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_PD;
use LIFT_labcar;

##################################

our $PURPOSE = "To check that Bit 2 of loop status is set in IDLE mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_Bit2OfLoopStatus

=head1 PURPOSE

To check that Bit 2 of loop status is set in IDLE mode

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation
2. Send Tester Present continously

I<B<Stimulation and Measurement>>

1. Create Idle Mode

2. Read loop status of all deployable squibs rb_dmim_DeploymentLoopStatusTable_au8(0)




I<B<Evaluation>>

1.

2. Bit 2 of all the loop status should be set.




I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Test_Condition' => Test condition
	SCALAR 'REQ_ReadStatus' => Vaiable name to read deployment loop status


=head2 PARAMETER EXAMPLES

	purpose  = 'To check that Bit 2 of loop status is set in IDLE mode'
	Test_Condition =  'Idle Mode'
	REQ_ReadStatus = 'rb_dmim_DeploymentLoopStatusTable_au8(0)'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Test_Condition;
my $tcpar_Session;

################ global parameter declaration ###################
my $Squib_Loop_Status;
my @Squib_Loop_Array;
my ( $TP_handle, $Loop_Status, $Squib_Loop_Structure, $routineStatusRecord );

###############################################################

sub TC_set_parameters {

	$tcpar_Session        = S_read_mandatory_testcase_parameter('Session');
	$tcpar_purpose        = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Test_Condition = S_read_mandatory_testcase_parameter('Test_Condition');

	$routineStatusRecord = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};

	return 1;
}

sub TC_initialization {

	S_w2rep("Start of Precondition");

	S_w2rep("Step1:Standard Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");

	S_w2rep("Send Tester Present Cyclically");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Enter '$tcpar_Session'", 'AUTO_NBR', 'STEP_1' );
	S_wait_ms(10000);    #To make sure ECU is not in initialization phase
	GDCOM_StartSession('DisposalSession');

	S_teststep( "Enable Disposal_Security", 'AUTO_NBR', 'STEP_2' );
	ACEA_Get_SecurityAccess();

	S_teststep( "Execute Disposal Program Loader", 'AUTO_NBR', 'STEP_3' );
	ACEA_ExecuteDisposalProgramLoader( '01', $routineStatusRecord );

	S_teststep( "reate '$tcpar_Test_Condition'", 'AUTO_NBR', 'STEP_4' );
	ACEA_SetECUMode($tcpar_Test_Condition);

	S_teststep( "Read loop status of all deployable squibs ", 'AUTO_NBR', 'STEP_5' );
	$Loop_Status = ACEA_Read_DiploymentLoopTable();
	$Squib_Loop_Structure = ACEA_ExtractRespDataToBeEvaluated( $Loop_Status, 18 );
	S_w2rep("$Squib_Loop_Structure");
	@Squib_Loop_Array = split( ' ', $Squib_Loop_Structure );
	S_w2rep("@Squib_Loop_Array");
	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Evaluate for Disposal session done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );
	S_teststep_detected( "Evaluate for Disposal session done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_1' );

	S_teststep_expected( "Evaluate for Security access done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_2' );
	S_teststep_detected( "Evaluate for Security access done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_2' );

	S_teststep_expected( "Evaluate for Disposal Program Loader done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_3' );
	S_teststep_detected( "Evaluate for Disposal Program Loader done at stimulation and measurement(Refer the traces or html report)\n", 'STEP_2' );

	S_teststep_expected( "No Evaluation\n", 'STEP_4' );
	S_teststep_detected( "No Evaluation\n", 'STEP_4' );

	S_teststep_expected( "Evaluation for loop status of all deployable squibs Refer the html report\n", 'STEP_5' );
	S_teststep_detected( "Evaluation for loop status of all deployable squibs Refer the html report\n", 'STEP_5' );
	for ( my $count = 1 ; $count < scalar(@Squib_Loop_Array) ; $count = $count + 2 ) {
		S_w2rep("Loop ID of the Squib is $Squib_Loop_Array[$count-1]\n ");
		S_w2rep("Loop Status is  $Squib_Loop_Array[$count]\n");
		if ( $Squib_Loop_Array[$count] eq '04' ) {
			S_set_verdict('VERDICT_PASS');
		}
		else {
			S_set_verdict('VERDICT_FAIL');
		}
	}
	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	S_wait_ms(2000);

	ACEA_ResetECUMode("Idle");
	GEN_Power_on_Reset();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
