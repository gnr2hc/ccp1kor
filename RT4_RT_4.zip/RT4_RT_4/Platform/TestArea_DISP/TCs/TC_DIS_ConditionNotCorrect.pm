#### TEST CASE MODULE
package TC_DIS_ConditionNotCorrect;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;

##################################

our $PURPOSE = "Checking NRC22 for Supported Diagnostic Services for ACEA";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_ConditionNotCorrect

=head1 PURPOSE

Checking NRC22 for Supported Diagnostic Services for ACEA

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set the <address_mode>

2. Create <Test_Condition>

3. Send <Request>

Note : Dependent services to be sent before <Request>


I<B<Evaluation>>

1. 

2.

3. Expected <Response>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'address_mode' => Addressing mode to be set
	SCALAR 'Test_Condition' => Condition to be set
	SCALAR 'Pre_Diag_Services' => Pre Diagnostic services to be sent, if any


=head2 PARAMETER EXAMPLES

	purpose  = 'Checking NRC22 for Supported Diagnostic Services for ACEA '
	
	address_mode = 'Disposal'
	Test_Condition = 'Normal'
	Pre_Diag_Services = 'None'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_address_mode;
my $tcpar_Test_Condition;
my $tcpar_RoutineControlOption;
my $tcpar_Service;
my $tcpar_Request;

################ global parameter declaration ###################
my $TP_handle;
my $NRCInfo;
my %Temp;
my $Modified_Request;
my $routineStatusRecord;
my $detected_response;
my $Expected_response;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_address_mode         = S_read_mandatory_testcase_parameter('address_mode');
	$tcpar_Test_Condition       = S_read_mandatory_testcase_parameter('Test_Condition');
	$tcpar_Service              = S_read_mandatory_testcase_parameter('Service');
	$tcpar_RoutineControlOption = S_read_optional_testcase_parameter('RoutineControlOption');
	$tcpar_Request              = S_read_mandatory_testcase_parameter('Request');
	$routineStatusRecord        = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set Addressing Mode '$tcpar_address_mode'", 'AUTO_NBR', 'Addressing_Mode' );
	GDCOM_set_addressing_mode($tcpar_address_mode);

	S_teststep( "Create a Test condition '$tcpar_Test_Condition'", 'AUTO_NBR', 'Test_condition' );
	if ( $tcpar_Test_Condition eq "StartUpMode" ) {
		GEN_Power_on_Reset('NO_WAIT');
		S_wait_ms(200);

	}
	elsif ( $tcpar_Test_Condition eq "IdleMode" ) {
		ACEA_SetECUMode("Idle");

	}
	elsif ( $tcpar_Test_Condition eq "ElectronicFiringMode" ) {
		GEN_setECUMode("PlantMode7_ElectronicFiringMode");

	}
	elsif ( $tcpar_Test_Condition eq "WDFault" ) {
		GDCOM_StartSession('DisposalSession');
		ACEA_Get_SecurityAccess();
		PD_WriteMemoryByName( "rb_wdm_Wd2ResponseRT_u32.1", [0x01] );

	}
	elsif ( $tcpar_Test_Condition eq "SafetyPathsEnabled" ) {
		GDCOM_StartSession('DisposalSession');
		ACEA_Get_SecurityAccess();
		ACEA_ExecuteDisposalProgramLoader( '01', $routineStatusRecord );

	}

	S_teststep( "Send Request'$tcpar_Request'", 'AUTO_NBR', 'NRC_Read' );

	$NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, 'NR_conditionsNotCorrect' );
	$Expected_response = $NRCInfo->{'Response'};
	if ( defined($tcpar_RoutineControlOption) ) {
		$Temp{'RoutineControlOption'} = $tcpar_RoutineControlOption;
	}
	$Modified_Request = GDCOM_getRequestLabelValue( "REQ_$tcpar_Request", \%Temp );
	$detected_response = GDCOM_request( $Modified_Request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );

	return 1;
}

sub TC_evaluation {

	S_teststep_detected( " No Evaluation ", 'Addressing_Mode' );
	S_teststep_expected( " No Evaluation ", 'Addressing_Mode' );

	S_teststep_detected( " No Evaluation ", 'Test_condition' );
	S_teststep_expected( " No Evaluation ", 'Test_condition' );

	S_teststep_detected( "Detected Negative response is : $detected_response Evaluation done in Stimulation and Measurement Refer the traces or html report\n ", 'NRC_Read' );
	S_teststep_expected( "Expected Negative response is : $Expected_response ", 'NRC_Read' );

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	if ( $tcpar_Test_Condition eq "IdleMode" ) {
		ACEA_ResetECUMode("Idle");
	}
	elsif ( $tcpar_Test_Condition eq "ElectronicFiringMode" ) {
		GEN_setECUMode("RemovePlantModes");
	}
	elsif ( $tcpar_Test_Condition eq "WDFault" ) {
		PD_ClearFaultMemory();
		GEN_Power_on_Reset();
	}

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
