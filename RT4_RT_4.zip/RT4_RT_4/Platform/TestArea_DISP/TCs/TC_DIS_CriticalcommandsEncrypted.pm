#### TEST CASE MODULE
package TC_DIS_CriticalcommandsEncrypted;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_Disp_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------
#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_CD_CAN;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_labcar;

##################################

our $PURPOSE = "To check Critical commands are stored in an encrypted format in ROM";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CriticalcommandsEncrypted

=head1 PURPOSE

To check Critical commands are stored in an encrypted format in ROM

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1.  Read encrypted ROM data using <ROM_Variable>

2. Read RAM data using <RAM_Variable>

3. Enter <Session>

4. Enable Security

5. Enable Saftey path

6. Read decrypted RAM data using <RAM_Variable>

7. Compare <ROM_Variable_Value> value with observed RAM value

8. Compare  observed RAM value with <Original_Storedvalue> 


I<B<Evaluation>>

1. <ROM_Variable_Value> obtained

2. <RAM_Default_Value> obtained

3. <Session> Entered

4. Security Granted

5. Saftey path enabled

6. <RAM_Variable_Value> obtained

7. <ROM_Variable_Value> and observed RAM value should not match

8. Observed RAM value and <Original_Storedvalue> should match


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => To check Critical commands are stored in an encrypted format in ROM
	SCALAR 'Session' => Disposal session
	SCALAR 'ROM_Variable' => ROM variable used to save disposal commands
	SCALAR 'RAM_Default_Value' => Default value of RAM variable
	SCALAR 'ROM_Variable_Value' => value of ROM variable
	SCALAR 'RAM_Variable' => RAM variable used to save disposal commands
	SCALAR 'Original_Storedvalue' => Decrypted expected commands
	SCALAR 'RAM_Variable_Value' => value of RAM variable
	
=head2 PARAMETER EXAMPLES

	purpose  = 'To check Critical commands are stored in an encrypted format in ROM'
	Session = 'DisposalSession'
	ROM_Variable='rb_dmdm_EncryptedCommand_au32'
	RAM_Default_Value=0000
	ROM_Variable_Value=(0xAF52AAF2,0xAF120BA6,0xAF13EA4E,0xAF18A10A,0xAF06BF16,0xAF07FE42,0xAE12AB12)
	RAM_Variable='rb_dmdm_DecryptedCommand_au32'
	RAM_Variable_Value=	(0x44001E0,0x401415C,0x40A0A18,0x4141404,0x4155550,0x05000000)	
	Original_Storedvalue=(0x44001E0,0x401415C,0x40A0A18,0x4141404,0x4155550,0x05000000)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session;
my $tcpar_ROM_Variable;
my $tcpar_RAM_Default_Value;
my $tcpar_ROM_Variable_Value_ACL;
my $tcpar_ROM_Variable_Value_WithoutACL;
my $tcpar_RAM_Variable_Value_ACL;
my $tcpar_RAM_Variable_Value_WithoutACL;
my $tcpar_Original_Storedvalue_ACL;
my $tcpar_Original_Storedvalue_WithoutACL;
my $tcpar_ACL;
my $tcpar_RAM_Variable;

################ global parameter declaration ###################
#add any global variables here
my $ExecuteSPL_With_Conversion = '01';
my ( $Default_ROM_Data, $Default_RAM_Data, $Decrypted_RAM_Data, $TP_handle, $routineStatusRecord );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                         = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Session                         = S_read_mandatory_testcase_parameter('Session');
	$tcpar_ROM_Variable                    = S_read_mandatory_testcase_parameter('ROM_Variable');
	$tcpar_RAM_Default_Value               = S_read_mandatory_testcase_parameter('RAM_Default_Value');
	$tcpar_ROM_Variable_Value_ACL          = S_read_mandatory_testcase_parameter('ROM_Variable_Value_ACL');
	$tcpar_ROM_Variable_Value_WithoutACL   = S_read_mandatory_testcase_parameter('ROM_Variable_Value_WithoutACL');
	$tcpar_RAM_Variable_Value_ACL          = S_read_mandatory_testcase_parameter('RAM_Variable_Value_ACL');
	$tcpar_RAM_Variable_Value_WithoutACL   = S_read_mandatory_testcase_parameter('RAM_Variable_Value_WithoutACL');
	$tcpar_Original_Storedvalue_ACL        = S_read_mandatory_testcase_parameter('Original_Storedvalue_ACL');
	$tcpar_Original_Storedvalue_WithoutACL = S_read_mandatory_testcase_parameter('Original_Storedvalue_WithoutACL');
	$tcpar_RAM_Variable                    = S_read_mandatory_testcase_parameter('RAM_Variable');
	$tcpar_ACL                             = S_read_mandatory_testcase_parameter('ACL');

	$routineStatusRecord = $LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};

	return 1;
}

sub TC_initialization {

	CA_trace_start();
	S_w2rep("Standard Preparation");
	GEN_StandardPrepNoFault();

	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");

	S_w2rep("SendTesterPresentCyclically");
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();
	return 1;

}

sub TC_stimulation_and_measurement {

	S_teststep( "Read encrypted ROM data using '$tcpar_ROM_Variable'", 'AUTO_NBR', 'STEP_1' );
	$Default_ROM_Data = ACEA_ReadEncryptedCommandsInROM($tcpar_ACL);
	S_w2rep("DefaultROM=@$Default_ROM_Data");

	S_teststep( "Read RAM data using '$tcpar_RAM_Variable'", 'AUTO_NBR', 'STEP_2' );
	$Default_RAM_Data = ACEA_ReadDecryptedCommandsInRAM($tcpar_ACL);
	S_w2rep("DefaultRAM=@$Default_RAM_Data");

	S_teststep( "Enter '$tcpar_Session'", 'AUTO_NBR', 'STEP_3' );
	GDCOM_StartSession($tcpar_Session);

	S_teststep( "Enable security.", 'AUTO_NBR', 'STEP_4' );
	ACEA_Get_SecurityAccess();

	S_teststep( "Enable Saftey path", 'AUTO_NBR', 'STEP_5' );
	ACEA_ExecuteDisposalProgramLoader( $ExecuteSPL_With_Conversion, $routineStatusRecord );

	S_teststep( "Read decrypted RAM data using '$tcpar_RAM_Variable'", 'AUTO_NBR', 'STEP_6' );
	$Decrypted_RAM_Data = ACEA_ReadDecryptedCommandsInRAM($tcpar_ACL);

	S_teststep( "Compare ROM_Variable_Value value with obsevred RAM value ", 'AUTO_NBR', 'STEP_7' );

	S_teststep( "Compare  obsevred RAM value with Original_Storedvalue ", 'AUTO_NBR', 'STEP_8' );

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation for encrypted ROM");

	if ( $tcpar_ACL eq 'Yes' ) {
		my $Expected_Default_ROM_Data = $tcpar_ROM_Variable_Value_ACL;
		S_teststep_detected( " Detected Default ROM Data is :$Default_ROM_Data ", 'STEP_1' );
		S_teststep_expected( " Expected Default ROM Data is :$Expected_Default_ROM_Data ", 'STEP_1' );
		GEN_EVAL_CompareNumArrays( $Default_ROM_Data, $Expected_Default_ROM_Data, 'Equal' );
	}
	else {
		my $Expected_Default_ROM_Data = $tcpar_ROM_Variable_Value_WithoutACL;
		S_teststep_detected( " Detected Default ROM Data is :$Default_ROM_Data ", 'STEP_1' );
		S_teststep_expected( " Expected Default ROM Data is :$Expected_Default_ROM_Data ", 'STEP_1' );
		GEN_EVAL_CompareNumArrays( $Default_ROM_Data, $Expected_Default_ROM_Data, 'Equal' );
	}

	S_teststep_detected( " Detected Default Encrypted RAM data is :@$Default_RAM_Data[0] ", 'STEP_2' );
	S_teststep_expected( " Expected Default Encrypted RAM data is :$tcpar_RAM_Default_Value ", 'STEP_2' );
	S_w2rep("Evaluation for RAM Data ");
	EVAL_evaluate_value( "Default commands in RAM", @$Default_RAM_Data[0], '==', $tcpar_RAM_Default_Value );

	S_teststep_detected( " Disposal Session of ECU-Evaluation done at stimulation and measurement ", 'STEP_3' );
	S_teststep_expected( " Disposal Session of ECU-Evaluation done at stimulation and measurement ", 'STEP_3' );

	S_teststep_detected( " Security 'Access of ECU-Evaluation done at stimulation and measurement ", 'STEP_4' );
	S_teststep_expected( " Security 'Access of ECU-Evaluation done at stimulation and measurement ", 'STEP_4' );

	S_teststep_detected( " Safety Path of ECU-Evaluation done at stimulation and measurement ", 'STEP_5' );
	S_teststep_expected( " Safety Path of ECU-Evaluation done at stimulation and measurement ", 'STEP_5' );

	S_teststep_detected( " Encrypted RAM data of ECU-Evaluation done at stimulation and measurement ", 'STEP_6' );
	S_teststep_expected( " Encrypted RAM data of ECU-Evaluation done at stimulation and measurement ", 'STEP_6' );

	S_w2rep("Evaluation for ROM_Variable_Value and Observed RAM value should not match");
	if ( $tcpar_ACL eq 'Yes' ) {
		my $Expected_RAM_Variable_Value_ACL = $tcpar_RAM_Variable_Value_ACL;
		S_teststep_detected( " Detected Encrypted RAM data is $Default_ROM_Data ", 'STEP_7' );
		S_teststep_expected( " Expected Encrypted RAM data is $Expected_RAM_Variable_Value_ACL ", 'STEP_7' );
		GEN_EVAL_CompareNumArrays( $Default_ROM_Data, $Expected_RAM_Variable_Value_ACL, 'NotEqual' );
	}
	else {
		my $Expected_RAM_Variable_Value_WithoutACL = $tcpar_RAM_Variable_Value_WithoutACL;
		S_teststep_detected( " Detected Encrypted RAM data is $Default_ROM_Data ", 'STEP_7' );
		S_teststep_expected( " Expected Encrypted RAM data is $Expected_RAM_Variable_Value_WithoutACL ", 'STEP_7' );
		GEN_EVAL_CompareNumArrays( $Default_ROM_Data, $Expected_RAM_Variable_Value_WithoutACL, 'NotEqual' );
	}

	S_w2rep("Evaluation Oberved RAM value and Original_Storedvalue should match");
	if ( $tcpar_ACL eq 'Yes' ) {
		my $Expected_Original_Storedvalue_ACL = $tcpar_Original_Storedvalue_ACL;
		S_teststep_detected( " Detected Encrypted RAM data is $Decrypted_RAM_Data ", 'STEP_8' );
		S_teststep_expected( " Expected Encrypted RAM data is $Expected_Original_Storedvalue_ACL ", 'STEP_8' );
		GEN_EVAL_CompareNumArrays( $Decrypted_RAM_Data, $Expected_Original_Storedvalue_ACL, 'Equal' );
	}
	else {
		my $Expected_Original_Storedvalue_WithoutACL = $tcpar_Original_Storedvalue_WithoutACL;
		S_teststep_detected( " Detected Encrypted RAM data is $Decrypted_RAM_Data ", 'STEP_8' );
		S_teststep_expected( " Expected Encrypted RAM data is $Expected_Original_Storedvalue_WithoutACL ", 'STEP_8' );
		GEN_EVAL_CompareNumArrays( $Decrypted_RAM_Data, $Expected_Original_Storedvalue_WithoutACL, 'Equal' );
	}
	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	S_wait_ms(2000);
	GEN_Power_on_Reset();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

1;
