#### TEST CASE MODULE
package TC_DEM_CustFaultMemoryExtendedDataRecord;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: DEM/TC_DEM_CustFaultMemoryExtendedDataRecord.pm 1.1 2020/02/07 10:03:15ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DEM_DignosticEventManager
#TS version in DOORS: 3.87
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use FuncLib_CustLib_DIAG;
use LIFT_CD;
use LIFT_labcar;



#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_CustFaultMemoryExtendedDataRecord

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create Fault  for <Device> of <DeviceType> with <Condition> and Qualify the same

2. Read the Fault Memory with <ReportDTCExtendedDataRecordByDTCNumber> with DTC of Fault created 


I<B<Evaluation>>

1. <FaultName>is created with <Condition> and fault is qualified

2. Evaluate the positive response <OccurrenceCounterValue> shall have value Occurrence Counter  equal to <Conditon> 

#Refer SRS_DEM_416

#OccurrenceCounterValueis 8th Byte of Response obtai


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Device' => 
	SCALAR 'purpose' => 
	SCALAR 'DeviceType' => 
	SCALAR 'Condition' => 
	SCALAR 'OccurrenceCounterValue' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To test the fault properties for fault stored in the customer fault memory by reading the extended Data record.'
	
	
	DeviceType	= '<Test Heading 2>'
	Condition 	= '<Test Heading 3>'
	
	
	
	OccurrenceCounterValue= '<Test Heading 3>'
	Device 		= 'AB1FD'	#Open Line fault is created for the device.

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;;
my $tcpar_DeviceType;
my $tcpar_Condition;
my $tcpar_OccurrenceCounterValue;
my $tcpar_Device;

################ global parameter declaration ###################
#add any global variables here
my $faultname;
my @ResponseArray;		# Holds the array coverted from response obtained in 19 06 DTC    


###############################################################

sub TC_set_parameters {

	$tcpar_purpose 					=  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_DeviceType 				=  GEN_Read_mandatory_testcase_parameter( 'DeviceType' );
	$tcpar_Condition 				=  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_OccurrenceCounterValue 	=  GEN_Read_mandatory_testcase_parameter( 'OccurrenceCounterValue' );
	$tcpar_Device 					=  GEN_Read_mandatory_testcase_parameter( 'Device' );

	return 1;
}

sub TC_initialization {

    S_w2rep( '1. StandardPrepNoFault', 'green' );
    GEN_StandardPrepNoFault ();

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1. Create Fault  for '$tcpar_Device' of '$tcpar_DeviceType' with '$tcpar_Condition' times Qualify the same fault");
	
	if ($tcpar_DeviceType eq "Squib") {
		$faultname = "rb_sqm_SquibResistanceOpen". '' ."$tcpar_Device"."_flt";
	}
	elsif ($tcpar_DeviceType eq "Switch") {
		$faultname = "rb_swm_OpenLine". '' ."$tcpar_Device"."_flt";
	}
	elsif ($tcpar_DeviceType eq "AOD") {
		$faultname = "rb_aod_". '' ."$tcpar_Device"."Short2Gnd_flt";
		#rb_aod_AOutSysWarningIndicatorShort2Gnd_flt
	}
	else {
		GEN_printTestStep ("Wrong device ");
	}
	
	
	GEN_printTestStep("fault name to be $faultname");
	
my $FalutCreateloop = $tcpar_Condition;
	while ($FalutCreateloop > 0) 
	{
		FM_createFault($faultname);
		S_wait_ms('5000');
		PD_ReadFaultMemory();

  		$FalutCreateloop -= 1;
 		FM_removeFault($faultname);
 		S_wait_ms('5000');
 		PD_ReadFaultMemory();
  	
	}

	
#	S_user_action("Creat AB1FD Open Line fault $tcpar_Condition number of times");
#	S_user_action("Remove Fault");
	

	GEN_printTestStep("Step 2. Read the Fault Memory with 'tcpar_ReportDTCExtendedDataRecordByDTCNumber' with Status as FF for DTC of Fault created ");
	
	my $fault_DTC = CD_get_FaultDTC ($faultname);
	$fault_DTC =~ s/..\K(?=.)/ /sg;
	
	my $tcpar_request = "19 06 "."$fault_DTC"." FF";	
	
	my $response;
	my $response = GDCOM_request  ( $tcpar_request, $response, 'relax') ;
	@ResponseArray = split(/ /, $response);
	
	GEN_printTestStep("Step 3. Reset the ECU");
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	GEN_printTestStep("Step 4. Read the Fault Memory with 'tcpar_ReportDTCExtendedDataRecordByDTCNumber' with Status as FF for DTC of Fault created ");
	my $fault_DTC = CD_get_FaultDTC ($faultname);
	$fault_DTC =~ s/..\K(?=.)/ /sg;
	
	my $tcpar_request = "19 06 "."$fault_DTC"." FF";	
	
	my $response;
	my $response = GDCOM_request( $tcpar_request, $response, 'relax') ;
	@ResponseArray = split(/ /, $response);
	
	return 1;
}

sub TC_evaluation {
	if($tcpar_Condition > 255)
{
	$tcpar_Condition -= 1;
}
	GEN_printTestStep("Evaluation for Step 1. '$tcpar_FaultName'is created with '$tcpar_Condition' and fault is qualified");
    GEN_printTestStep("Evaluation for Step 2. Evaluate the positive response extended information shall have value Occurrence Counter  equal to '$tcpar_Condition' ");
	 EVAL_evaluate_value ("Occurance Counter for $faultname", hex($ResponseArray[7]), '==', $tcpar_Condition);
	GEN_printTestStep("Evaluation for Step 4. Evaluate the positive response extended information shall have value Occurrence Counter  equal to '$tcpar_Condition' ");
	EVAL_evaluate_value ("Occurance Counter for $faultname", hex($ResponseArray[7]), '==', $tcpar_Condition);
	return 1;
}

sub TC_finalization {
	# Erase Fault memory
    #PD_ClearFaultMemory();
   # S_wait_ms(10000);
    
    S_w2rep( "Bring the ECU back to normal mode", 'blue' );
    GEN_Finalization();
    
	return 1;
}


1;
