#### TEST CASE MODULE
package TC_DEM_BoschFaultMemoryTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: DEM/TC_DEM_BoschFaultMemoryTest.pm 1.1 2020/02/07 10:03:15ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DEM_DignosticEventManager
#TS version in DOORS: 3.87
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use Data::Dumper;

#include further modules here

##################################

our $PURPOSE = "To test the Fault properties store correctly for Bosch fault Memory.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DEM_BoschFaultMemoryTest

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create Fault  for <Device> of <DeviceType> with <Condition> and Qualify the same

2. Read the Fault Memory with <MemoryType>

3. Dequalifiy the <FaultName> 

4. Read the Fualt memory with  <MemoryType>

5. Erase the fault 

6. Read the Fualt memory with  <MemoryType>


I<B<Evaluation>>

1. <FaultName>is created with <Condition> and fault is qualified

2. Evaluate the data of Fault in the Fault memory with DataTable 

# Ref  SRS_DEM_145, SRS_PRD_292

3. <FaultName> is not dequalified 

4. Evaluate the data of Fault in the Fault  memory with DataTable 

# Ref  SRS_DEM_145, SRS_PRD_292

5. Fault is erased from fault memory

6. Fault details are not observed.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'DeviceType' => 
	SCALAR 'Condition' => 
	SCALAR 'MemoryType' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To test the fault properties for FAULT stored in the memory '
	
	
	DeviceType	= '<Test Heading 2>'
	Condition 	= '<Test Heading 3>'
	MemoryType 	= '03'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DeviceType;
my $tcpar_Condition;
my $tcpar_MemoryType;
my $tcpar_Device;

################ global parameter declaration ###################
#add any global variables here
my $faultname; 				#Holds the fault name
my $fault_Created; 			#
my $fault_RemovededFlt;		#
my $fault_ClearedFlt;		#


my $fltnum_Created                            ;  
my $fault_text_Created                        ;  
my $DTC_Created                               ;                    
my $GeneralState_Created                      ;  
my $EventDebug_HB_Created                     ;  
my $EventDebug_LB_Created                     ;
my $OccuranceCounter_Created                  ;  
my $QualificationTime_Created                 ;  
my $DequalificationTime_Created               ;  
my $Qualification_poweron_cycle_Created       ;  
my $Dequalification_poweron_cycle_Created     ; 

my $fltnum_Removed							;
my $fault_text_Removed                   	;
my $DTC_Removed                          	;
my $GeneralState_Removed					;
my $GeneralState_text_Removed				;
my $EventDebug_HB_Removed                   ;
my $EventDebug_LB_Removed                   ;
my $OccuranceCounter_Removed             	;
my $QualificationTime_Removed            	;
my $DequalificationTime_Removed          	;
my $Qualification_poweron_cycle_Removed  	;
my $Dequalification_poweron_cycle_Removed	;

my $fltnum_Clear							;
my $fault_text_Clear                   		;
my $DTC_Clear                          		;
my $GeneralState_Clear						;
my $GeneralState_text_Clear					;
my $EventDebug_HB_Clear                   	;
my $EventDebug_LB_Clear                     ;
my $OccuranceCounter_Clear             		;
my $QualificationTime_Clear            		;
my $DequalificationTime_Clear          		;
my $Qualification_poweron_cycle_Clear  		;
my $Dequalification_poweron_cycle_Clear		;




###############################################################

sub TC_set_parameters {

	$tcpar_purpose 		=  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_DeviceType 	=  GEN_Read_mandatory_testcase_parameter( 'DeviceType' );
	$tcpar_Condition 	=  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_MemoryType 	=  GEN_Read_mandatory_testcase_parameter( 'MemoryType' );
	$tcpar_Device		=  GEN_Read_mandatory_testcase_parameter( 'Device' );
	return 1;
}

sub TC_initialization {

    S_w2rep( '1. StandardPrepNoFault', 'blue' );
    GEN_StandardPrepNoFault ();
    
	return 1;
}

sub TC_stimulation_and_measurement {


	if ($tcpar_DeviceType eq "Squib")	
	{
		$faultname = "rb_sqm_SquibResistanceOpen". '' ."$tcpar_Device"."_flt";
	}
	elsif ($tcpar_DeviceType eq "Switch")	
	{
		$faultname = "rb_swm_OpenLine". '' ."$tcpar_Device"."_flt";
	}
	elsif ($tcpar_DeviceType eq "AOD")		
	{
		$faultname = "rb_aod_". '' ."$tcpar_Device"."Short2Gnd_flt";
		#rb_aod_AOutSysWarningIndicatorShort2Gnd_flt
	}
	else {
		GEN_printTestStep ("Wrong device ");
		exit(0);

	}
	
	#sleep(50);
	
	my $FalutCreateloop = $tcpar_Condition;

	while ($FalutCreateloop > 0) 
	{
		FM_createFault($faultname);
		#FM_createFault("rb_sqm_SquibResistanceOpenAB1FD_flt");
		S_wait_ms('5000');
		PD_ReadFaultMemory();
		
  		$FalutCreateloop -= 1;
 		FM_removeFault($faultname);
 		S_wait_ms('5000');
 		PD_ReadFaultMemory();
  	
	}

   # S_user_action("Creat AB1FD Open Line fault $tcpar_Condition number of times");
       
	# Fault is created. ..... 

	GEN_printTestStep("Step 2. Read the Fault Memory with '$tcpar_MemoryType'");
	$fault_Created = PD_ReadFaultMemory($tcpar_MemoryType);
	
	$fltnum_Created                            = PD_GetFaultAttribute ($fault_Created,    $faultname,    'fltnum'                        );  
    $fault_text_Created                        = PD_GetFaultAttribute ($fault_Created,    $faultname,    'fault_text'                    );  
    $DTC_Created                               = PD_GetFaultAttribute ($fault_Created,    $faultname,   'DTC'                           );  

    $GeneralState_Created                      = PD_GetFaultAttribute ($fault_Created,    $faultname,    'GeneralState'                  );  
    $EventDebug_HB_Created                        = PD_GetFaultAttribute ($fault_Created,    $faultname,    'EventDebug_HB'                    );
	$EventDebug_LB_Created                           = PD_GetFaultAttribute ($fault_Created,    $faultname,    'EventDebug_LB'                    );
    $OccuranceCounter_Created                  = PD_GetFaultAttribute ($fault_Created,    $faultname,   'OccuranceCounter'              );  
    $QualificationTime_Created                 = PD_GetFaultAttribute ($fault_Created,    $faultname,    'QualificationTime'             );  
    $DequalificationTime_Created               = PD_GetFaultAttribute ($fault_Created,    $faultname,    'DequalificationTime'           );  
    $Qualification_poweron_cycle_Created       = PD_GetFaultAttribute ($fault_Created,    $faultname,    'Qualification_poweron_cycle'   );  
    $Dequalification_poweron_cycle_Created     = PD_GetFaultAttribute ($fault_Created,    $faultname,    'Dequalification_poweron_cycle' );  


	GEN_printTestStep("The following are the values updated after the fault is qualified for the fault : $fault_text_Created \n ");
	
	GEN_printTestStep("After Creating  the fault, the value of fltnum                       : $fltnum_Created                               \n  ");
	GEN_printTestStep("After Creating the fault, the value of fault_text                   	: $fault_text_Created                           \n  ");
	GEN_printTestStep("After Creating the fault, the value of DTC                          	: $DTC_Created                                  \n  ");
                           
	GEN_printTestStep("After Creating the fault, the value of GeneralState_text             : $GeneralState_Created                    	  	\n  ");
	GEN_printTestStep("After Creating the fault, the value of EventDebug Highbyte                    : $EventDebug_HB_Created                           \n  ");
	GEN_printTestStep("After Creating the fault, the value of EventDebug LowByte                   : $EventDebug_LB_Created                           \n  ");
	GEN_printTestStep("After Creating the fault, the value of OccuranceCounter              : $OccuranceCounter_Created                     \n  ");
	GEN_printTestStep("After Creating the fault, the value of QualificationTime             : $QualificationTime_Created                    \n  ");
	GEN_printTestStep("After Creating the fault, the value of DequalificationTime           : $DequalificationTime_Created                  \n  ");
	GEN_printTestStep("After Creating the fault, the value of Qualification_poweron_cycle   : $Qualification_poweron_cycle_Created          \n  ");
	GEN_printTestStep("After Creating the fault, the value of Dequalification_poweron_cycle : $Dequalification_poweron_cycle_Created        \n  ");



=cu
	while ($tcpar_Condition > 0) 
    {
    	FM_createFault($faultname);
        FM_createFault("rb_sqm_SquibResistanceOpenAB1FD_flt");
        $tcpar_Condition -= 1;
        FM_removeFault($faultname);
        FM_removeFault("rb_sqm_SquibResistanceOpenAB1FD_flt");
	}
=cut

	#GEN_printTestStep("Step 3. Dequalifiy the '$faultname' ");
	#FM_removeFault($faultname);
	#S_user_action("Remove Fault");
	#sleep(50);
	$fault_RemovededFlt = PD_ReadFaultMemory($tcpar_MemoryType);
	
	
    $fltnum_Removed                             = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'fltnum'                          );  
    $fault_text_Removed                         = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'fault_text'                      );  
    $DTC_Removed                               	= PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'DTC'                             );  
    
    $GeneralState_Removed                		= PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'GeneralState'                    );  
    $EventDebug_HB_Removed                         = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'EventDebug_HB'                      );  
	$EventDebug_LB_Removed                        = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'EventDebug_LB'                      );
    $OccuranceCounter_Removed                   = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'OccuranceCounter'                );    
    $QualificationTime_Removed                  = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'QualificationTime'				);  
    $DequalificationTime_Removed                = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'DequalificationTime' 			);  
    $Qualification_poweron_cycle_Removed        = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,    'Qualification_poweron_cycle' 	);  
    $Dequalification_poweron_cycle_Removed      = PD_GetFaultAttribute ($fault_RemovededFlt,    $faultname,   'Dequalification_poweron_cycle'  	);  
	
	
	GEN_printTestStep("The following are the values updated after the fault is de-qualified for the fault : $fault_text_Removed \n ");
	
	GEN_printTestStep("After Clearing the fault, the value of fltnum                       	: $fltnum_Removed                               \n  ");
	GEN_printTestStep("After Clearing the fault, the value of fault_text                   	: $fault_text_Removed                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of DTC                          	: $DTC_Removed                                  \n  ");

	GEN_printTestStep("After Clearing the fault, the value of GeneralState_text             : $GeneralState_Removed                    	  	\n  ");
	GEN_printTestStep("After Clearing the fault, the value of EventDebug High Byte                   : $EventDebug_HB_Removed                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of EventDebug Low Byte                   : $EventDebug_LB_Removed                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of OccuranceCounter              : $OccuranceCounter_Removed                     \n  ");
	GEN_printTestStep("After Clearing the fault, the value of QualificationTime             : $QualificationTime_Removed                    \n  ");
	GEN_printTestStep("After Clearing the fault, the value of DequalificationTime           : $DequalificationTime_Removed                  \n  ");
	GEN_printTestStep("After Clearing the fault, the value of Qualification_poweron_cycle   : $Qualification_poweron_cycle_Removed          \n  ");
	GEN_printTestStep("After Clearing the fault, the value of Dequalification_poweron_cycle : $Dequalification_poweron_cycle_Removed        \n  ");
	

	GEN_printTestStep("Step 4. Read the Fualt memory with  '$tcpar_MemoryType'");
	#$fault_DQLI = PD_ReadFaultMemory($tcpar_MemoryType);

	GEN_printTestStep("Step 5. Erase the fault ");
	PD_ClearFaultMemory(0);
	
	GEN_printTestStep("Step 6. Read the Fualt memory with  '$tcpar_MemoryType'");
	$fault_ClearedFlt = PD_ReadFaultMemory($tcpar_MemoryType);
	
    $fltnum_Clear                             	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,   'fltnum'                            );  
    $fault_text_Clear                         	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'fault_text'                        );  
    $DTC_Clear                               	= PD_GetFaultAttribute ($fault_ClearedFlt,   $faultname,    'DTC'                               );  
    
    $GeneralState_Clear                			= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,   'GeneralState'                      );  
    $EventDebug_HB_Clear                         	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'EventDebug_HB'                        );  
	$EventDebug_LB_Clear                         = PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'EventDebug_LB'                        ); 
    $OccuranceCounter_Clear                   	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'OccuranceCounter'                  );    
    $QualificationTime_Clear                  	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'QualificationTime'					);  
    $DequalificationTime_Clear                	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,    'DequalificationTime' 				);  
    $Qualification_poweron_cycle_Clear        	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,   'Qualification_poweron_cycle' 		);  
    $Dequalification_poweron_cycle_Clear      	= PD_GetFaultAttribute ($fault_ClearedFlt,    $faultname,   'Dequalification_poweron_cycle'  	);  

	
	GEN_printTestStep("The following are the values updated after the fault is cleared for the fault: $fault_text_Clear \n ");
	
	GEN_printTestStep("After Clearing the fault, the value of fltnum                       	: $fltnum_Clear                               \n  ");
	GEN_printTestStep("After Clearing the fault, the value of fault_text                   	: $fault_text_Clear                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of DTC                          	: $DTC_Clear                                  \n  ");

	GEN_printTestStep("After Clearing the fault, the value of GeneralState_text             : $GeneralState_Clear                    	  \n  ");
	GEN_printTestStep("After Clearing the fault, the value of EventDebug High Byte                    : $EventDebug_HB_Clear                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of EventDebug Low Byte                    : $EventDebug_HB_Clear                           \n  ");
	GEN_printTestStep("After Clearing the fault, the value of OccuranceCounter              : $OccuranceCounter_Clear                     \n  ");
	GEN_printTestStep("After Clearing the fault, the value of QualificationTime             : $QualificationTime_Clear                    \n  ");
	GEN_printTestStep("After Clearing the fault, the value of DequalificationTime           : $DequalificationTime_Clear                  \n  ");
	GEN_printTestStep("After Clearing the fault, the value of Qualification_poweron_cycle   : $Qualification_poweron_cycle_Clear          \n  ");
	GEN_printTestStep("After Clearing the fault, the value of Dequalification_poweron_cycle : $Dequalification_poweron_cycle_Clear        \n  ");
	
	return 1;
}

sub TC_evaluation {
		if($tcpar_Condition > 255)
		{
				$tcpar_Condition -= 1;
		}
	#GEN_printTestStep("Evaluation for Step 1. '$faultname'is created with '$tcpar_Condition' and fault is qualified");

	#GEN_printTestStep("Evaluation for Step 2. Evaluate the data of Fault in the Fault memory with DataTable ");
	#GEN_printTestStep("# Ref  SRS_DEM_145, SRS_PRD_292");
	
	EVAL_evaluate_value ("General State for $faultname", 					$GeneralState_Created,						'==', 	$GeneralState_Created,);
	
	EVAL_evaluate_value ("Event Debug Data High byte for $faultname", 				$EventDebug_HB_Created,						'==', '0');
	EVAL_evaluate_value ("Event Debug Data Low byte for $faultname", 				$EventDebug_LB_Created,						'==', 	'0');
	EVAL_evaluate_value ("Occurrence Counter for $faultname", 				$OccuranceCounter_Created,					'==', $tcpar_Condition);
	EVAL_evaluate_value ("Qualification time for $faultname", 				$QualificationTime_Created,					'==', 	$QualificationTime_Created);
	EVAL_evaluate_value ("De-Qualification time for $faultname", 			$DequalificationTime_Created,				'==', 	$DequalificationTime_Created);
	EVAL_evaluate_value ("Qualification Power On cycle for $faultname", 	$Qualification_poweron_cycle_Created,		'==', 	$Qualification_poweron_cycle_Created);
	EVAL_evaluate_value ("De-Qualification Power On cycle for  $faultname", $Dequalification_poweron_cycle_Created,		'==', 	$Dequalification_poweron_cycle_Created);

	#GEN_printTestStep("Evaluation for Step 3. '$faultname'  not dequalified ");
	EVAL_evaluate_value ("General State for $faultname", 					$GeneralState_Removed,						'==', 	$GeneralState_Removed);
	EVAL_evaluate_value ("Event Debug Data High byte for $faultname", 				$EventDebug_HB_Removed,						'==', 	'0');
	EVAL_evaluate_value ("Event Debug Data Low byte for $faultname", 				$EventDebug_LB_Removed,						'==', 	'0');
	EVAL_evaluate_value ("Occurrence Counter for $faultname", 				$OccuranceCounter_Removed,					'==', 	$tcpar_Condition);
	EVAL_evaluate_value ("Qualification time for $faultname", 				$QualificationTime_Removed,					'==', 	$QualificationTime_Removed);
	EVAL_evaluate_value ("De-Qualification time for $faultname", 			$DequalificationTime_Removed,				'==', 	$DequalificationTime_Removed);
	EVAL_evaluate_value ("Qualification Power On cycle for $faultname", 	$Qualification_poweron_cycle_Removed,		'==', 	$Qualification_poweron_cycle_Removed);
	EVAL_evaluate_value ("De-Qualification Power On cycle for  $faultname", $Dequalification_poweron_cycle_Removed,		'==', 	$Dequalification_poweron_cycle_Removed);

	#GEN_printTestStep("Evaluation for Step 4. Evaluate the data of Fault in the Fault  memory with DataTable ");
	#GEN_printTestStep("# Ref  SRS_DEM_145, SRS_PRD_292");
	EVAL_evaluate_value ("General State for $faultname", 					$GeneralState_Clear,						'==', 	'0');
	EVAL_evaluate_value ("Event Debug Data High byte for $faultname", 				$EventDebug_HB_Clear,							'==', 	'0');
	EVAL_evaluate_value ("Event Debug Data Low byte for $faultname", 				$EventDebug_LB_Clear,							'==', 	'0');
	EVAL_evaluate_value ("Occurrence Counter for $faultname", 				$OccuranceCounter_Clear,					'==', 	'0');
	EVAL_evaluate_value ("Qualification time for $faultname", 				$QualificationTime_Clear,					'==', 	'0');
	EVAL_evaluate_value ("De-Qualification time for $faultname", 			$DequalificationTime_Clear,					'==', 	'0');
	EVAL_evaluate_value ("Qualification Power On cycle for $faultname", 	$Qualification_poweron_cycle_Clear,			'==', 	'0');
	EVAL_evaluate_value ("De-Qualification Power On cycle for  $faultname", $Dequalification_poweron_cycle_Clear,		'==', 	'0');
	

	return 1;
}

sub TC_finalization {

	return 1;
}


1;
