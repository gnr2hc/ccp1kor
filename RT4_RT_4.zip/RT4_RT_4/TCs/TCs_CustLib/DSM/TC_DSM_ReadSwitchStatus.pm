#### TEST CASE MODULE
package TC_DSM_ReadSwitchStatus;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_ReadSwitchStatus.pm 1.2 2019/08/20 13:21:25ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_DSM_CustomerDiagnostics> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <4.125> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;

##################################

our $PURPOSE =  'To Measure the Switch Status during different condition';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReadSwitchStatus

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>	

2. Set <Switch_Behaviour>

3. Enter <Session>

4. Create Condition <Condition> 	

5. Send <Request> 


I<B<Evaluation>>

1. 

2. 

3.Positive Response is obtained

4.

5.<Response> is obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Condition' => 
	SCALAR 'Purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	SCALAR 'Switch_Behaviour' =>
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To Measure the Switch Status during different condition'
	
	
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR, 
	

	Response = 
	Condition = 
	

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_Condition;
my $tcpar_Switch_Behaviour;
my $tcpar_Switch;

################ global parameter declaration ###################
#add any global variables here
my $mode;
my $session;
my $service;
my $service1;
my $Req1;
my @Req1;
my $Req;
my @Req;
my $val;
my $val2;
my $SwitchFlag = 0;


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose' , 'byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode', 'byref' );
	$tcpar_Switch =  S_read_mandatory_testcase_parameter( 'Switch','byvalue' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol', 'byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session', 'byref' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request', 'byvalue' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response', 'byvalue' );
	$tcpar_Switch_Behaviour = S_read_mandatory_testcase_parameter( 'Switch_Behaviour', 'byvalue' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition','byvalue' );
	

	return 1;
}

sub TC_initialization {

	if($tcpar_Switch_Behaviour =~ m/MeasuredValue/i){
			S_w2rep("Not implemented for CA",'blue');
			S_set_verdict ( 'VERDICT_NONE' );
			$SwitchFlag = 1;
			return 1; 
		}
		else{
			S_w2rep("Switch is evaluated for default value",'blue');
		}

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
	GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {


	S_teststep("Set '@$tcpar_Addressing_Mode' for '$tcpar_Protocol'	", 'AUTO_NBR');
	foreach $mode (@$tcpar_Addressing_Mode){
		GDCOM_set_addressing_mode($mode);
		S_w2rep("*** ECU is in $mode  ***",'Orange');


		S_teststep("Set '$tcpar_Switch_Behaviour' ", 'AUTO_NBR');
		if($tcpar_Switch_Behaviour =~ m/MeasuredValue/i){
			S_w2rep("Not implemented for CA",'blue');
			S_set_verdict ( 'VERDICT_NONE' );
			$SwitchFlag = 1;
			return 1; 
		}
		else{
			S_w2rep("Switch is evaluated for default value",'blue');
		}


		
		foreach $session(@$tcpar_Session){
		S_teststep("Enter '$session'", 'AUTO_NBR');			#measurement 1	
			$service1 = GDCOM_request_general('REQ_DiagnosticSessionControl_'.$session,'PR_DiagnosticSessionControl_'.$session);
			
			@Req = split(/ /,$service1);
			$val2 = $Req[1];
			S_w2rep("Switch is in session @Req with its 2nd byte value : $val2",'green');
	
			S_w2rep("** evaluation for $mode with $session **",'Purple');
			S_teststep_expected("Positive response shall be obtained. ");			#evaluation 4
			if($session eq 'DefaultSession'){
				S_teststep_detected("Switch status is in $session");
				EVAL_evaluate_value("Evaluating positive response for Session",'0x'.$val2,'==','01') unless $main::opt_offline;	
			 }
			 elsif($session eq 'ExtendedSession'){
				S_teststep_detected("switch status is in $session");
				EVAL_evaluate_value("Evaluating positive response for Session",'0x'.$val2,'==','03') unless $main::opt_offline;	
			 }
	
			S_teststep("Create '$tcpar_Condition'	", 'AUTO_NBR');
			_Condition_Create($tcpar_Condition, $tcpar_Switch);	
			
	
			S_teststep("Send '$tcpar_Request' ", 'AUTO_NBR');			
			$service = GDCOM_request_general('REQ_'.$tcpar_Request,'PR_'.$tcpar_Request,'Data','optional strict');
			
			@Req1 = split(/ /,$service);
			$val = $Req1[-1];
	
			S_w2rep("Switch status response @Req1 with value $val",'green');
	

			S_w2rep("** evaluation for $mode with $session **",'Purple');
			S_teststep_expected("Positive response with '$tcpar_Response' is obtained. ");			#evaluation 4
			S_teststep_detected("Switch status value : $val");
			EVAL_evaluate_value("Evaluating response for switch status value",'0x'.$val,'==','0x'.$tcpar_Response) unless $main::opt_offline;	
		   
		   
			_resetCondition($tcpar_Condition, $tcpar_Switch);
			S_wait_ms('TIMER_SIX_SEC');

		}
	
	}
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation handled in stimulation part"); 

	return 1;
}

sub TC_finalization {
	
	GDCOM_stop_CyclicTesterPresent();
	S_wait_ms('TIMER_DIAGNOSIS');
	
	return 1;
}


sub _Condition_Create {
	
	my $Condition = shift;
	my $Switch1 = shift;
	my $DeviceMapping = S_get_contents_of_hash(['Mapping_DEVICE']);
	my $SwitchType = $DeviceMapping->{$Switch1}{'type'}; 
	
	if ($Condition eq 'NotConfNotPresent'){
		LC_DisconnectLine($Switch1);
		S_wait_ms('TIMER_SIX_SEC');	
		PD_Device_configuration( 'clear',  [$Switch1]);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
		LC_ECU_Reset();
		PD_ClearFaultMemory();	
	}
	elsif($Condition eq 'UnexpectedDevice'){
		PD_Device_configuration( 'clear',  [$Switch1]);
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
		LC_ECU_Reset();
	}
	elsif($Condition eq 'CrossCoupling'){
		if($SwitchType eq 'hall'){
			if($Switch1 eq 'BLFP'){
				LC_ShortLines( [$Switch1.'+', 'BLFD+'] );
			}
			else{
				LC_ShortLines( [$Switch1.'+', 'BLFP+'] );
			}
		}
		elsif($SwitchType eq 'resistive'){
			LC_ShortLines( [$Switch1.'+', 'PADS1+'] );
		}
		else{
			S_w2rep("Mechanical switch type is not implemented",'blue')
		}
		S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
		LC_ECU_Reset();
	}
	else{
	
		  # FM_createFault($faultname);
		DEVICE_setDeviceState($Switch1,$Condition);
	}
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	PD_ReadFaultMemory();
}

sub _resetCondition {
	
	my $Condition = shift;
	my $Switch1 = shift;
	
	if ($Condition eq 'NotConfNotPresent'){
        LC_ConnectLine($Switch1);
		S_wait_ms('TIMER_SIX_SEC');	
		PD_Device_configuration( 'set',  [$Switch1]);	  
	}
	elsif($Condition eq 'UnexpectedDevice'){
		PD_Device_configuration( 'set',  [$Switch1]);
	}
	elsif($Condition eq 'CrossCoupling'){
		LC_UndoShortLines( );
	}
	else{
		DEVICE_resetDeviceState($Switch1, $Condition);
	}
	S_wait_ms('TIMER_SIX_SEC');	
	LC_ECU_Reset( ); 
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_SIX_SEC');
	PD_ReadFaultMemory();
}

1;