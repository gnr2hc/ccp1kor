## TEST CASE MODULE
package TC_DSM_SingleDID;

## DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_SingleDID.pm 1.2 2019/08/20 13:21:24ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

# ----------------------- TEST SPECIFICATION ------------------------------
# This script is based on TS: TS_DSM_CustomerDiagnostics (e.g. TS_SWM_SwitchMgt)
# TS version in DOORS: 4.125(e.g. 3.30)
# -------------------------------------------------------------------------

## INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
# include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
################################

our $PURPOSE = "'To check format when single DID is sent as request '";

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SingleDID

=head1 PURPOSE

'To check format when single DID is sent as request '

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>

2. Enter Session <Session>

3. Send <Request> with  <DIDType>   

 


I<B<Evaluation>>

1. 

2. 

3. Positive response with <DIDType> and with the valid response bytes of the DID sent. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Session' => 
	SCALAR 'purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Request' => 
	SCALAR 'DIDType' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check format when single DID is sent as request ' 
	
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR
	
	DIDType = 'ReadDiagnosticSession'
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR

=cut



# PARAMETERS
############## Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Request;
my $tcpar_DIDType;
my $tcpar_Session;

############## global parameter declaration ###################
# add any global variables here
my $mode;
my $session;
my $response;

#############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' ,'byvalue');
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode','byref' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_DIDType =  S_read_mandatory_testcase_parameter( 'DIDType' ,'byvalue');
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byvalue' );

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {
	foreach $mode (@$tcpar_Addressing_Mode){
		# S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'", 'AUTO_NBR');
		S_teststep("Set '$mode' for '$tcpar_Protocol'", 'AUTO_NBR');
			GDCOM_set_addressing_mode($mode);
			
		S_teststep("Enter Session '$tcpar_Session'", 'AUTO_NBR');
			DIAG_StartSession($tcpar_Session);
			
		S_teststep("Send '$tcpar_Request' with  '$tcpar_DIDType'   ", 'AUTO_NBR');			#measurement 1
			$response = GDCOM_request_general ('REQ_'.$tcpar_Request, 'PR_'.$tcpar_Request);
			$session = substr($response,9,11);
		
		S_teststep_expected("Positive response with '$tcpar_DIDType' and with the valid response bytes of the DID sent. ");			#evaluation 1
		S_teststep_detected("Detected response with '$tcpar_DIDType': $session ");
			if($tcpar_Session =~ m/Default/i){
				EVAL_evaluate_string( "Positive response with DefaultSession: $session " , '01' , $session );
			}else{
				EVAL_evaluate_string( "Positive response with ExtendedSession: $session " , '03' , $session );
			}	
	}
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation handled in stimulation part");

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}


1;
