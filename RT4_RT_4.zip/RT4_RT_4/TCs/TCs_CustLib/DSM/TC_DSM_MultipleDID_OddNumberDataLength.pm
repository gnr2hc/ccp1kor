#### TEST CASE MODULE
package TC_DSM_MultipleDID_OddNumberDataLength;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM/TC_DSM_MultipleDID_OddNumberDataLength.pm 1.3 2019/08/29 18:20:03ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_CustomerDiagnostics (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 4.125 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "To check multiple DID's for ReadData byIdentifier with Odd number bytes requested, excluding the service ID ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_MultipleDID_OddNumberDataLength

=head1 PURPOSE

'To check multiple DID's for ReadData byIdentifier with Odd number bytes requested, excluding the service ID '

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>

2. Enter Session <Session>

3. Set Condition <Condition>

4. Send request <Request> with  <DIDType>  

#Multiple DID's are Supported subfunction/DID of  ReadDatabyID which are fetched from Mapping file


I<B<Evaluation>>

1. 

2. positive response with Session <Session> is entered

3.

4. Response <Response> is obtained . 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	LIST 'DIDType' => 
	SCALAR 'Condition' => 
	SCALAR 'Response' => 
	SCALAR 'DIDLimit' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check multiple DID's for ReadData byIdentifier with Odd number bytes requested, excluding the service ID '
	
	
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR
	
	DIDType = @('ReadGenericMemory', 'ReadDiagnosticSession', 'ReadEOLConfiguration ', 'ReadVIN', 'ReadVoltage')
	
	
	Condition = 'OddLength'
	
	Response = 'tbd' #IncorrectMessageLengthOrInvalidFormat
	
	DIDLimit = 'TBD' #Total Number of DID's shall be depend on the how many DIDs are supported in Addressing mode.
	
	#Note: Parse the Condition and if precondition is applicable then respective test case shall executed 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_DIDType;
my $tcpar_Condition;
my $tcpar_Response;
my $tcpar_DIDLimit;

################ global parameter declaration ###################
#add any global variables here
my $ReadGenericMemory_req ;
my $ReadDiagnosticSession_req;
my $ReadEOLConfiguration_req ;
my $ReadVIN ;
my $ReadVoltage ;
my @DIDType;
my $response ;
my $response1 ;
my $index ;
my $request_multipleDID ;
my $ReqDetail;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose', 'byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode', 'byvalue' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol', 'byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session', 'byvalue' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request', 'byvalue' );
	$tcpar_DIDType =  S_read_mandatory_testcase_parameter( 'DIDType', 'byref' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition', 'byvalue' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response', 'byvalue' );
	$tcpar_DIDLimit =  S_read_mandatory_testcase_parameter( 'DIDLimit', 'byvalue' );

	foreach (@$tcpar_DIDType){
		$ReqDetail = GDCOM_getRequestInfofromMapping($_)->{'Requests'}{'REQ_'.$_}{'Request'};
		S_w2rep("--> $ReqDetail");
		$ReqDetail =~ s/^22 //;
		push @DIDType , $ReqDetail ;
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'", 'AUTO_NBR');
		GDCOM_set_addressing_mode($tcpar_Addressing_Mode);
		
	S_teststep("Enter Session '$tcpar_Session'", 'AUTO_NBR', 'enter_session_session');			#measurement 1
		$response = GDCOM_request_general ('REQ_DiagnosticSessionControl_'.$tcpar_Session, 'PR_DiagnosticSessionControl_'.$tcpar_Session);
		
	S_teststep("Send request '$tcpar_Request' with  '@$tcpar_DIDType'  ", 'AUTO_NBR', 'send_request_request');			#measurement 2
		$request_multipleDID = $tcpar_Request ;
		foreach $index (0..4){
			$request_multipleDID = $request_multipleDID.' '.$DIDType[$index];
		}
		
		foreach(0..2){															#reuest to create condition ODDlengthDID => '22 xx xx xx xx xx xx xx xx xx'		
			chop($request_multipleDID);
		}
		
		S_w2rep("##################################################################################################################",'purple');
		S_w2rep("Sending Request: '$request_multipleDID' in Addressing mode:'$tcpar_Addressing_Mode' and Session: '$tcpar_Session' ",'purple');
		$response1 = GDCOM_request($request_multipleDID,"7F $tcpar_Request $tcpar_Response",'relax',"Sending multipleDID Request: '$request_multipleDID'");

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("positive response with Session '$tcpar_Session' is entered", 'enter_session_session');			#evaluation 1
	S_teststep_detected("Detected Response: $response");
	
	S_w2rep("Evaluating after sending request: $request_multipleDID ",'purple');
	S_teststep_expected("Response '$tcpar_Response' is obtained . ", 'send_request_request');			#evaluation 2
	S_teststep_detected("Detected response: '$response1'", 'send_request_request');
		EVAL_evaluate_string( "Negative response should be observed after sending oddlenth of DIDs: 'NRC$tcpar_Response' " , "7F $tcpar_Request $tcpar_Response" , $response1 );
		
	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}


1;
