#### TEST CASE MODULE
package TC_DSM_MultipleDID_InCorrectNoOfDID;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM/TC_DSM_MultipleDID_InCorrectNoOfDID.pm 1.3 2019/08/29 18:19:55ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_CustomerDiagnostics(e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 4.125 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "To check multiple DID's for ReadData byIdentifier with Same DID and Differenr DID's in Functional request";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_MultipleDID_InCorrectNoOfDID

=head1 PURPOSE

'To check multiple DID's for ReadData byIdentifier with Same DID and Differenr DID's in Functional request'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>

2. Enter Session <Session>

3. Set Condition <Condition>

4. Send request <Request> with  <DIDType>  with nummber of DID's varies from <NoOfDID_MinRange> - 1

5. Send request <Request> with  <DIDType>  with nummber of DID's varies from <NoOfDID_MaxRange>  + 1

#Multiple DID's are Supported subfunction/DID of  ReadDatabyID which are fetched from Mapping file


I<B<Evaluation>>

1. 

2. positive response with Session <Session> is entered

3.

4. Negative response <Response> is obtained . 

5. Response <Response> is obtained 

Note: In Functional Addressing mode, No response is obtained.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	LIST 'DIDType' => 
	SCALAR 'Condition' => 
	SCALAR 'Response' => 
	SCALAR 'DIDLimit' => 
	SCALAR 'NoOfDID_MinRange' => 
	SCALAR 'NoOfDID_MaxRange' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check multiple DID's for ReadData byIdentifier with Same DID and Differenr DID's in Functional request' 
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR
	DIDType = @('ReadGenericMemory', 'ReadDiagnosticSession', 'ReadEOLConfiguration ', 'ReadVIN', 'ReadVoltage')
	# With respect to NoOfDID mentioned the DID's will be sent 
	Condition = 'DifferentDID'
	Response = 'tbd' #To be defined
	DIDLimit = 'TBD' #Total Number of DID's shall be depend on the how many DIDs are supported in Physical Addressing mode.
	NoOfDID_MinRange = 'tbd'  #To be defined
	NoOfDID_MaxRange = 'tbd'  #To be defined
	#Note: Parse the Condition and if precondition is applicable then respective test case shall executed 
	 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_DIDType;
my $tcpar_Condition;
my $tcpar_Response;
my $tcpar_DIDLimit;
my $tcpar_NoOfDID_MinRange;
my $tcpar_NoOfDID_MaxRange;

################ global parameter declaration ###################
#add any global variables here

my $ReadGenericMemory_req ;
my $ReadDiagnosticSession_req;
my $ReadEOLConfiguration_req ;
my $ReadVIN ;
my $ReadVoltage ;
my $request_multipleDID;
my $NoOfDID;
my $index;
my $value;
my $response;
my $response1;
my $response2;
my @Response_array;
my @DIDType;
my $ReqDetail;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose','byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode','byvalue' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byvalue' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_DIDType =  S_read_mandatory_testcase_parameter( 'DIDType','byref' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition','byvalue' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response','byvalue' );
	$tcpar_DIDLimit =  S_read_mandatory_testcase_parameter( 'DIDLimit','byvalue' );
	$tcpar_NoOfDID_MinRange =  S_read_optional_testcase_parameter( 'NoOfDID_MinRange','byvalue' );
	$tcpar_NoOfDID_MaxRange =  S_read_optional_testcase_parameter( 'NoOfDID_MaxRange','byvalue' );
	
	@Response_array = split(/\//,$tcpar_Response);
	S_w2rep("Response = $Response_array[0]");
	if($Response_array[0] =~m/NR_InvalidLength/i ){
		$tcpar_Response = '13';
	}
	
	
	foreach (@$tcpar_DIDType){
		$ReqDetail = GDCOM_getRequestInfofromMapping($_)->{'Requests'}{'REQ_'.$_}{'Request'};
		S_w2rep("--> $ReqDetail");
		$ReqDetail =~ s/^22 //;
		push @DIDType , $ReqDetail ;
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'", 'AUTO_NBR');
		GDCOM_set_addressing_mode($tcpar_Addressing_Mode);
		
	S_teststep("Enter Session '$tcpar_Session'", 'AUTO_NBR', 'enter_session_session');			#measurement 1
		$response = GDCOM_request_general ('REQ_DiagnosticSessionControl_'.$tcpar_Session, 'PR_DiagnosticSessionControl_'.$tcpar_Session);

	S_teststep("Send request '$tcpar_Request' with  '@$tcpar_DIDType'  with nummber of DID's varies from '$tcpar_NoOfDID_MinRange' - 1", 'AUTO_NBR', 'send_request_request_A');			#measurement 2
		S_w2rep("##################################################################################################################",'purple');
		S_w2rep("Sending Request: '$tcpar_Request' in Addressing mode:'$tcpar_Addressing_Mode' and Session: '$tcpar_Session' ",'purple');
		$response1 = GDCOM_request($tcpar_Request,"7F $tcpar_Request $tcpar_Response" ,'relax',"Sending multipleDID Request: '$request_multipleDID'");
		
	S_teststep("Send request '$tcpar_Request' with  '@$tcpar_DIDType'  with nummber of DID's varies from '$tcpar_NoOfDID_MaxRange'  + 1", 'AUTO_NBR', 'send_request_request_B');			#measurement 3
		$request_multipleDID = $tcpar_Request ;
		foreach $index (0..4){
			if($tcpar_Condition =~ m/DifferantDID/i){
				$request_multipleDID = $request_multipleDID.' '.$DIDType[$index];
			}else{
				$request_multipleDID = $request_multipleDID.' '.$DIDType[0];
			}
		}
		$request_multipleDID = $request_multipleDID. ' ' .'00';
		
		S_w2rep("##################################################################################################################",'purple');
		S_w2rep("Sending Request: '$request_multipleDID' in Addressing mode:'$tcpar_Addressing_Mode' and Session: '$tcpar_Session' ",'purple');
		$response2 = GDCOM_request($request_multipleDID,"7F $tcpar_Request $tcpar_Response",'optional relax',"Sending multipleDID Request: '$request_multipleDID'");
	

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("positive response with Session '$tcpar_Session' is entered", 'enter_session_session');			#evaluation 1
	S_teststep_detected("Detected Response: $response");
	
	S_w2rep("##################################################################################################################",'purple');
	S_w2rep("Evaluating response after sending request with nummber of DID's varies from '$tcpar_NoOfDID_MinRange' - 1 ",'purple');	
	S_teststep_expected("Negative response '$tcpar_Response' is obtained . ", 'send_request_request_A');			#evaluation 2
	S_teststep_detected("Detected Response: $response1", 'send_request_request_A');
		EVAL_evaluate_string( "Negative response should be observed:$response1 " , "7F $tcpar_Request $tcpar_Response" , $response1 );
	
	S_w2rep("##################################################################################################################",'purple');
	S_w2rep("Evaluating response after sending request with nummber of DID's varies from '$tcpar_NoOfDID_MaxRange'  + 1 ",'purple');		
	S_teststep_expected("Response '$tcpar_Response' is obtained ", 'send_request_request_B');			#evaluation 3
	S_teststep_detected("Detected Response: $response1", 'send_request_request_B');
		if($tcpar_Addressing_Mode =~ m/physical/i){
			EVAL_evaluate_string( "Negative response should be observed:$response2 " , "7F $tcpar_Request $tcpar_Response" , $response2 );
		}else{
			EVAL_evaluate_string( "No response should be obtained :$response2 " , "" , $response2 );
		}

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}


1;
