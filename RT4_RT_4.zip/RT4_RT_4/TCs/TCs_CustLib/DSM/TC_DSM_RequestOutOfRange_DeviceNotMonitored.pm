#### TEST CASE MODULE
package TC_DSM_RequestOutOfRange_DeviceNotMonitored;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_RequestOutOfRange_DeviceNotMonitored.pm 1.2 2019/08/20 13:21:24ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_DSM_CustomerDiagnostics> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <4.125> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD2ProdDiag;
use LIFT_labcar;
use LIFT_PD;
##################################

our $PURPOSE = "When device is not monitered and request is sent then Configured value shall be returned";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_RequestOutOfRange_DeviceNotMonitored

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. set <Addressing _Mode> in <Protocol_Type>

2. Send Request to enter <Session>

3. Create <Condition> for <Device>

4. Send <SendService> 


I<B<Evaluation>>

1.

2..Session  is entered 

3. Condition created 

4. <RESP_Send_Service> is obtained.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Device' => 
	SCALAR 'purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	SCALAR 'Condition' => 
	SCALAR 'RESP_Send_Service' => 
	SCALAR 'SendService' => 


=head2 PARAMETER EXAMPLES

	purpose = 'When device is not monitered and request is sent then Configured value shall be returned '
	
	
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	
	Condition 		= 'Set Device Is Not Monitered '
	
	RESP_Send_Service  = 'ConfiguredValue' # The To be lined to SPS/SPR
	
	SendService = 'Test Heading'
	Device = 'AB1FD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Condition;
my $tcpar_RESP_Send_Service;
my $tcpar_SendService;
my $tcpar_Device;

################ global parameter declaration ###################
#add any global variables here

my $mode;
my $Session;
my $response;
my $response1;
my $pos_response;
my $session_resp;
my $value;
my ($Real,$Monitored,$Prog);
my $Squib;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose', 'byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode', 'byref' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol', 'byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session', 'byref' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition', 'byvalue' );
	$tcpar_RESP_Send_Service =  S_read_mandatory_testcase_parameter( 'RESP_Send_Service', 'byvalue' );
	$tcpar_SendService =  S_read_mandatory_testcase_parameter( 'SendService', 'byvalue' );
	$tcpar_Device =  S_read_mandatory_testcase_parameter( 'Device' );

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	
	return 1;
}

sub TC_stimulation_and_measurement {

	foreach $mode (@$tcpar_Addressing_Mode){
		S_teststep("set '$mode' in '$tcpar_Protocol'", 'AUTO_NBR');
			GDCOM_set_addressing_mode($mode);
		foreach $Session (@$tcpar_Session){	
			S_teststep("Send Request to enter '$Session'", 'AUTO_NBR');			#measurement 1
				$response = GDCOM_request_general ('REQ_DiagnosticSessionControl_'.$Session, 'PR_DiagnosticSessionControl_'.$Session);
				
				$session_resp  = substr($response,0,5);
				S_w2rep("********* Evaluating for $mode Addressing mode and $Session *********",'purple');
				S_teststep_expected("Session is entered ");			#evaluation 1
				S_teststep_detected("Entered to $Session : $response");
				$pos_response = S_get_contents_of_hash(['Mapping_DIAG','Requests_Responses','DiagnosticSessionControl_'.$Session,'POS_Responses','PR_DiagnosticSessionControl_'.$Session,'Response']);
				EVAL_evaluate_string( "Positive response observed after entering into $Session: $pos_response " , $pos_response , $session_resp );
				
			S_teststep("Create '$tcpar_Condition' for '$tcpar_Device'", 'AUTO_NBR');			#measurement 2
				PD_Device_configuration( 'clear', [$tcpar_Device] );
				S_wait_ms('TIMER_SIX_SEC');
				PD_Device_configuration( 'clear_Mon', [$tcpar_Device] );
				S_wait_ms('TIMER_SIX_SEC');
				LC_ECU_Reset();
				($Real,$Monitored,$Prog) = PD_get_device_config( $tcpar_Device );
				S_w2rep(" Present bit $Squib : $Real , Monitored bit $Squib : $Monitored , Configure bit $Squib : $Prog",'green'); 
				
				S_teststep_expected("Condition created ");			#evaluation 2
				S_teststep_detected("Detected monitor bit: $Monitored");
				EVAL_evaluate_value("Detected monitor bit is :'$Monitored' ",$Monitored,'==',0); 
					
				
			S_teststep("Send '$tcpar_SendService' ", 'AUTO_NBR');			#measurement 3
				$response1 = GDCOM_request_general ('REQ_'.$tcpar_SendService, 'PR_'.$tcpar_SendService);
				
					$value  = substr($response1,9,2);

					S_teststep_expected("'$tcpar_RESP_Send_Service' is obtained.");			#evaluation 3
					S_teststep_detected("Detected configured value: $value");
					EVAL_evaluate_value("Evaluating response for configured value",'0x'.$value,'==','0x'.$tcpar_RESP_Send_Service) unless $main::opt_offline;	
				
			
		}
	}
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation handled in stimulation part");
	
	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();
	
	PD_Device_configuration( 'set_Mon', [$tcpar_Device] );
	S_wait_ms('TIMER_SIX_SEC');
	PD_Device_configuration( 'set', [$tcpar_Device] );
	S_wait_ms('TIMER_SIX_SEC');
	LC_ECU_Reset();
	($Real,$Monitored,$Prog) = PD_get_device_config( $tcpar_Device );
	S_w2rep(" Present bit $Squib : $Real , Monitored bit $Squib : $Monitored , Configure bit $Squib : $Prog",'green'); 
	
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_SIX_SEC');
	PD_ReadFaultMemory();
	
	return 1;
}


1;