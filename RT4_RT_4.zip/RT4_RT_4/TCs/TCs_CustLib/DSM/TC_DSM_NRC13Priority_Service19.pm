#### TEST CASE MODULE
package TC_DSM_NRC13Priority_Service19 ;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM/TC_DSM_NRC13Priority_Service19.pm 1.3 2019/08/20 13:21:24ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_DSM_CustomerDiagnostics> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <4.125> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here

use GENERIC_DCOM;
use LIFT_CD;
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_general;
##################################

our $PURPOSE = 'To check the NRC13 InvalidLength over other NRCs for service 19';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC13PriorityService19 

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>	

2. Enter <Session>	

3. Create <Condition>

4. Send <Request> 


I<B<Evaluation>>

1. 

2. 

3.

4.<Response_Type> is obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Condition' => 
	SCALAR 'Purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	SCALAR 'Response_Type' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check the NRC13 InvalidLength over other NRCs for service 19 '
	
	
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR, 
	Response_Type = 'InvalidLength'	#NRC13
	Condition = 'InvalidDTCMaskRecord' 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_CondReq;
my $tcpar_Request;
my $tcpar_Response_Type;
my $tcpar_Condition;

################ global parameter declaration ###################
#add any global variables here

my $session;
my $Response;
my $Response1;
my $var_str;
my @string;
my $num;
my $ReqResp;
my $CondiResp;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose','byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode','byvalue' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byref' );
	$tcpar_CondReq = S_read_optional_testcase_parameter( 'CondReq','byvalue' );
	$tcpar_Request = S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_Response_Type =  S_read_mandatory_testcase_parameter( 'Response_Type','byvalue' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' ,'byvalue');

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'	", 'AUTO_NBR');
			GDCOM_set_addressing_mode($tcpar_Addressing_Mode);
			S_w2rep ("ECU is in $tcpar_Addressing_Mode\n");

			S_teststep("Enter '@$tcpar_Session'	", 'AUTO_NBR');
				foreach  $session (@$tcpar_Session){
					DIAG_StartSession($session);
					S_w2rep("ECU is in $_ $session Session");

					S_teststep("Create '$tcpar_Condition'", 'AUTO_NBR');
					
					
					if($tcpar_Condition =~ m/DTCSnapshotRecordNumber/i){
						
						$var_str = $tcpar_Request;
						@string = split(/_/,$var_str);
						$num = $string[0];
						
						my $Req_Service = _getServiceID($num);
						my $Service = $Req_Service.' '.'04 00 01 65 02';
						
						$CondiResp = "7F $Req_Service 31";
						
						$Response1 = GDCOM_request( $Service , $CondiResp, 'strict', 'NRC31');
						S_w2rep("Response => $Response1","Green");
						
						
					}
					elsif($tcpar_Condition =~ m/DTCExtendedDataRecordNumber/i){		
						
						$var_str = $tcpar_Request;
						@string = split(/_/,$var_str);
						$num = $string[0];
						
						my $Req_Service = _getServiceID($num);
						my $Service = $Req_Service.' '.'06 00 01 65 10';
						$CondiResp = "7F $Req_Service 31";
						
						$Response1 = GDCOM_request( $Service , $CondiResp, 'strict', 'NRC31');
						S_w2rep("Response => $Response1","Green");
						
					}
						
					unless($tcpar_Condition =~ m/InvalidDTCMaskRecord/i ){
						S_teststep_expected("'$CondiResp shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$CondiResp' shall be obtained" ,$CondiResp,$Response1); 	
					}
						
						
						S_teststep("Send '$tcpar_Request' ", 'AUTO_NBR');			#measurement 1
						
						$var_str = $tcpar_Request;
						@string = split(/_/,$var_str);
						$num = $string[0];
						
						my $Req_Service = _getServiceID($num);
						my $Service = $Req_Service.' '.'04 00 01 65 02 11 11 11';
						$ReqResp= "7F $Req_Service 13";
						
						$Response = GDCOM_request($Service , $ReqResp , 'strict', 'NRC13');
					
						S_teststep_expected("'$tcpar_Response_Type shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response");
						EVAL_evaluate_string( "'$tcpar_Response_Type' shall be obtained" ,$ReqResp,$Response); 
	    
				}
	
	return 1;
}

sub TC_evaluation {
     
	 S_w2rep("Evaluation is done above in stimulation_and_measurement"); 
	
	return 1;
}

sub TC_finalization {
    
	GDCOM_stop_CyclicTesterPresent();
	S_wait_ms (5000); 
	PD_ClearFaultMemory();
	S_wait_ms(2000);
    PD_ReadFaultMemory();
	LC_ECU_Reset(); 
	
	return 1;
}


sub _getServiceID {

	my $SID = shift;
	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $SID ] );
	S_w2rep("Service : $services");
	
	return $services;
}

1;