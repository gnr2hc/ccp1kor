#### TEST CASE MODULE
package TC_DSM_NRCPriority;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_NRCPriority.pm 1.2 2019/08/20 13:21:25ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_DSM_CustomerDiagnostics> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <4.125> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here

use LIFT_CD;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;

##################################

our $PURPOSE = "'To check the NRC priority over other NRCs for Service 10'";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRCPriority

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol_Type>

2. Send request to enter  <Session>

3. Send the service <SID> with <Condition> 




I<B<Evaluation>>

2. Session entry is sucessfull.

3. a. For physical addressing mode <Response_Type1> is obtained

   b. For functional addressing mode <Response_Type2> is obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Condition' => 
	SCALAR 'Response_Type1' => 
	SCALAR 'Response_Type2' => 
	SCALAR 'purpose' => 
	SCALAR 'SID' => 
	SCALAR 'Session' => 
	SCALAR 'Protocol_Type' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check the NRC priority over other NRCs for Service 10'
	SID  = 'DiagnosticSessionControl'
	Session = '<Fetch {Session}>'  
	Protocol_Type =  '<Fetch {Protocol}>'
	Condition = @('SubFunction_NotSupported', 'Invalid_Length')
	
	Response_Type1 	= 'NRC_12'
	Response_Type2		= 'No_Response'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SID;
my $tcpar_Addressing_Mode;
my $tcpar_Session;
my $tcpar_Protocol_Type;
my $tcpar_Condition;
my $tcpar_Request;
my $tcpar_Response_Type1;
my $tcpar_Response_Type2;

################ global parameter declaration ###################
#add any global variables here

my $session;
my $mode;
my $response_phys;
my $data;
my $Service;
my $Response1;
my $Response2;
my $data1;
my $var_str;
my $string;
my @string;
my $Req_Serv;
my $num;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose','byvalue' );
	$tcpar_SID =  S_read_mandatory_testcase_parameter( 'SID','byvalue' );
	$tcpar_Addressing_Mode = S_read_mandatory_testcase_parameter( 'Addressing_Mode','byref' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byref' );
	$tcpar_Protocol_Type =  S_read_mandatory_testcase_parameter( 'Protocol_Type','byvalue' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition','byvalue' );
	$tcpar_Request = S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_Response_Type1 =  S_read_optional_testcase_parameter( 'Response_Type1','byvalue' );
	$tcpar_Response_Type2 =  S_read_mandatory_testcase_parameter( 'Response_Type2','byvalue' );

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	
	return 1;
}

sub TC_stimulation_and_measurement {
			
		S_teststep("Set '@$tcpar_Addressing_Mode' for '$tcpar_Protocol_Type'	", 'AUTO_NBR');
		foreach $mode (@$tcpar_Addressing_Mode){
			GDCOM_set_addressing_mode($mode);
			S_w2rep("*****  Evaluation for $mode Addressing mode *****",'purple');
		
			S_teststep("Send request to enter  '@$tcpar_Session'", 'AUTO_NBR');			#measurement 1
			foreach $session (@$tcpar_Session) {
				DIAG_StartSession($session);
				S_w2rep("*** ECU is in $session  ***");	
					
				S_teststep("Send the service '$tcpar_SID' in '$tcpar_Protocol_Type'with '$tcpar_Condition' in ", 'AUTO_NBR');			#measurement 2
				if($tcpar_SID  =~ 'DiagnosticSessionControl'){
					if($tcpar_Condition =~ m/SubFunction_NotSupported/i ){
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'22';
						$response_phys = "7F $data 12";
						
						S_w2rep("*** SID IS $tcpar_SID ***",'Pink');
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');

						if(($tcpar_Response_Type2 eq 'No_Response') && ($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
							
							S_w2rep("***** Evaluation for $mode Addressing mode with $session  *****",'purple');
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						
						}
					}
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){
						
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,2);
						
						$Service = $Req_Serv.' '.'23 45';
						$response_phys = "7F $data 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');
						if(($tcpar_Response_Type2 =~ 'No_Response') && ($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for  $mode Addressing mode with $session  *****",'purple');
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
					
					}
					
					
				}
				
				
				elsif($tcpar_SID  =~ 'ECUReset'){
				
					if($tcpar_Condition =~ m/SubFunction_NotSupported/i ){
						
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'08';
						$response_phys = "7F $Req_Serv 12";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
						
						S_w2rep("*** SID IS $tcpar_SID ***",'Pink');
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');
						if(($tcpar_Response_Type2 =~ 'No_Response') && ($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
				
					}
						
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){
						
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,2);
						
						$Service = $Req_Serv.' '.'11 22 33 44';
						$response_phys = "7F $data 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with $session  *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
					}
							
						
				}
				
				elsif($tcpar_SID  =~ 'ClearDTCInformation'){
			
					if($tcpar_Condition =~ m/Invalid_Length/i ){
						
						my $Req_Serv = _getServiceID($tcpar_Request);
												
						$response_phys = "7F $Req_Serv 13";
						
						S_w2rep("*** SID IS $tcpar_SID ***",'Pink');
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							$Response1 = GDCOM_request($Req_Serv,$response_phys, 'optional strict','NRC13');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
							
					}		
					
					elsif($tcpar_Condition =~ m/GODTC_NotSupported/i ){
						
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'34 43 34';
						$response_phys = "7F $data 31";
						
						S_w2rep("*** SID IS $tcpar_SID ***",'Pink');
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC31');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
					
					}
				
				}
				
				elsif($tcpar_SID  =~ 'ReadDTCInformation'){
			
					if($tcpar_Condition =~ m/SubFunction_NotSupported/i ){
						
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'03 AF';
						$response_phys = "7F $Req_Serv 12";
						
						S_w2rep("*** SID IS $tcpar_SID ***",'Pink');
						S_w2rep("** Condition is $tcpar_Condition **",'Orange');
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
								S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
								S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
								$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
								
								S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
								S_teststep_detected("Obtained response is $Response1");
								EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1);
						}
					
					}
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){
						
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,5);
						$data1 = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'AF 32';
						$response_phys = "7F $data1 13";
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with $session  *****",'purple');
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						
					}
				
				}
				
				elsif($tcpar_SID  =~ 'ReadDataByIdentifier'){
			
					if($tcpar_Condition =~ m/Invalid_Length/i ){
						
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						my $data = substr($Req_Serv,0,2);
						
						$Service = $Req_Serv.' '.'01';
						$response_phys = "7F $data 13";
						
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1)
				
					}
						
					elsif($tcpar_Condition =~ m/GODTC_NotSupported/i ){
						
						$var_str = $tcpar_Request;
						@string = split(/_/,$var_str);
						$num = $string[0];
						
						my $Req_Serv = _getServiceID($num);
						
						$Service = $Req_Serv.' '.'14 53';
						$response_phys = "7F $Req_Serv 31";
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC31');
						
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
					}
						
				}		
				
				elsif($tcpar_SID  =~ 'SecurityAccess'){
			
					if($tcpar_Condition =~ m/serviceNotSupportedInActiveSession/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$response_phys = "7F $Req_Serv 7F";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							$Response1 = GDCOM_request($Req_Serv,$response_phys, 'optional strict','NRC7F');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
							
					}
						
					elsif($tcpar_Condition =~ m/SubFunction_NotSupported/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						$data = $Req_Serv.' '.'06';
						
						$response_phys = "7F $Req_Serv 12";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							$Response1 = GDCOM_request($data,$response_phys, 'optional strict','NRC12');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 	
						}
							
					}
						
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){							
								
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$response_phys = "7F $Req_Serv 13";
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with $session  *****",'purple');
						$Response1 = GDCOM_request($Req_Serv,$response_phys, 'optional strict','NRC13');
						
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
				
					}	
				
				}
				
				elsif($tcpar_SID  =~ 'CommunicationControl'){
			
					if($tcpar_Condition =~ m/serviceNotSupportedInActiveSession/i ){							
							
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,5);
						$data1 = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'01';
						
						$response_phys = "7F $data1 7F";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC7F');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
							
					}
						
					elsif($tcpar_Condition =~ m/SubFunction_NotSupported/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'87 01';
			
						$response_phys = "7F $Req_Serv 12";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
							
					}	
				
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'00 01 03';
			
						$response_phys = "7F $Req_Serv 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						
					}
				
				}
				
				elsif($tcpar_SID  =~ 'WriteDataByIdentifier'){
			
					if($tcpar_Condition =~ m/serviceNotSupportedInActiveSession/i ){							
							
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,8);
						$data1 = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'01 02 03';
			
						$response_phys = "7F $data1 7F";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC7F');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
						}
						
					}	
						
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){							
							
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$data = substr($Req_Serv,0,8);
						$data1 = substr($Req_Serv,0,2);
						
						$Service = $data.' '.'01 02 03 04';
			
						$response_phys = "7F $data1 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("***** Evaluation for  $mode Addressing mode with  $session  *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
							
					}	
						
						
				}
				
				elsif($tcpar_SID  =~ 'TesterPresent'){
			
					if($tcpar_Condition =~ m/SubFunction_NotSupported/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'76';
			
						$response_phys = "7F $Req_Serv 12";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
							
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1);
					
						}
							
					}
						
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						
						$Service = $Req_Serv.' '.'00 32';
			
						$response_phys = "7F $Req_Serv 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 		
				
					}
				
				}

				elsif($tcpar_SID  =~ 'ControlDTCSetting'){
			
					if($tcpar_Condition =~ m/serviceNotSupportedInActiveSession/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						$Service = $Req_Serv.' '.'01';
						
						$response_phys = "7F $Req_Serv 7F";
						
						if(($tcpar_Response_Type2 =~ 'No_Response') &&($mode eq 'functional')){
							S_w2rep("**As ECU is in functional mode,it will not give any response.Hence, No evaluation is required for Functional address **");
						}
						else{
						
							S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
							$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC7F');
						
							S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
							S_teststep_detected("Obtained response is $Response1");
							EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 	
						}
						
					}
						
					elsif($tcpar_Condition =~ m/SubFunction_NotSupported/i ){							
							
						my $Req_Serv = _getServiceID($tcpar_Request);
						$Service = $Req_Serv.' '.'06';
						
						$response_phys = "7F $Req_Serv 12";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC12');
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
							
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
							
					}	
						
					elsif($tcpar_Condition =~ m/Invalid_Length/i ){							
							
						my $Req_Serv = _getServiceRequest($tcpar_Request);
						$Service = $Req_Serv.' '.'12 34';
						$data= substr($Req_Serv,0,2);
						
						$response_phys = "7F $data 13";
						
						$Response1 = GDCOM_request($Service,$response_phys, 'optional strict','NRC13');
						
						S_w2rep("***** Evaluation for   $mode Addressing mode with  $session  *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type1 shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type1' shall be obtained" ,$response_phys,$Response1); 
							
					}
						
				}
			
			}	
					
		}		
						
				
	return 1;
}

sub TC_evaluation {
    
    S_w2rep("Evaluation is done above in stimulation_and_measurement"); 	
	
	return 1;
}

sub TC_finalization {

    GDCOM_stop_CyclicTesterPresent();
	S_wait_ms (5000); 
	PD_ClearFaultMemory();
	S_wait_ms(2000);
    PD_ReadFaultMemory();
    LC_ECU_Reset();	
	
	return 1;
}

sub _getServiceRequest {

	my $SID = shift;
	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG','Requests_Responses',$tcpar_Request,'Requests','REQ_'.$tcpar_Request,'Request'] );
	return $services;
	
}

sub _getServiceID {

	my $SID = shift;
	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $SID ] );
	S_w2rep("Service : $services");
	
	return $services;
}


1;