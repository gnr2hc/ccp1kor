#### TEST CASE MODULE
package TC_DSM_SquibResiRead;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_SquibResiRead.pm 1.2 2019/08/26 16:08:46ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;

##################################

our $PURPOSE = 'To Test the behaviour of system Squib is not faulty and default valus is configured';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_SquibResiRead

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>	

2. Enter <Session>

3. Create <Condition>	

4. Send <Request> 

#Note: Refer to SPR_DSM_CustomerDiagnostic and ID : SPS_DSM_214, to cross check is default or measured values are applicable.  Example if value is 0x013D

#0000 0001 0011 1101

#bit 0 - SquibOpen			1	Measured

#bit 1 - SquibShort			0	Default

#bit 2 - ShortBat				1	Measured

#bit 3 - ShortGnd				1	Measured

#bit 4 - SqrefTooLow			1	Measured

#bit 5 - SqrefTooHigh			1	Measured

#bit 6 - Invalid				0	Default

#bit 7 - SquibConfiguration		0	Default

#bit 8 - CrossCoupling			1	Measured

#bit 9 - NotConfNotPresent		0	Default

#bit 10 to 15 - Reserved			0	Default

#Refer to SPR_DSM_CustomerDiagnostic and ID : SPS_DSM_113 for values of Default and Measured. 


I<B<Evaluation>>

1. 	

2. 

3. Condition is created

4. <Response> is obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Condition' => 
	SCALAR 'Squib_Behaviour' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR
	Response = 'Positive Response 62 followed by   with YY 1...YYn  Bytes is obtained' 
					#Shall  conform with the Squib Resistance with system
	#Note: Squib Resistance response Length is configurable and to be in lined to SPS/SPR
	Purpose = 'To Test the behaviour of system Squib is not faulty and default valus is configured'
	
	
	Condition 		= 'Normal'		# To be inlined with SPS/SPR
	Squib_Behaviour 	= 'DefaultValue'		# To be lined to SPS/SPR
	
	#Note: Squib Resistance response Length is configurable and to be lined to SPS/SPR

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_Purpose;
my $tcpar_Condition;
my $tcpar_Squib;
my $tcpar_Squib_Behaviour;


################ global parameter declaration ###################
#add any global variables here

my $mode;
my $session;
my $CondiResp;
my $service;
my $service1;
my $response1;
my $response2;
my $Req1;
my @Req1;
my $Req;
my @Req;
my $val;
my $val2;
my $SquibFlag = 0;
my $Squib;
my $Condition;
my $flt_mem;
my $optional_flt = ['rb_ccc_ConfiguredAndSysConfMismatch_flt','rb_ccc_IncompatibleConfiguration_flt'];
my $ReqRes;


###############################################################

sub TC_set_parameters {

	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode','byref' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byref' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response','byvalue' );
	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose','byvalue' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition','byvalue' );
	$tcpar_Squib_Behaviour =  S_read_mandatory_testcase_parameter( 'Squib_Behaviour','byvalue' );
	$tcpar_Squib =  S_read_mandatory_testcase_parameter( 'Squib','byvalue' );

	return 1;
}

sub TC_initialization {

	if($tcpar_Squib_Behaviour =~ m/MeasuredValue/i){
			S_w2rep("Not implemented for CA",'blue');
			S_set_verdict ( 'VERDICT_NONE' );
			$SquibFlag = 1;
			return 1; 
		}
		else{
			S_w2rep("Squib is evaluated for default value",'blue');
		}

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {


	S_teststep("Set '@$tcpar_Addressing_Mode' for '$tcpar_Protocol'	", 'AUTO_NBR');
	foreach $mode (@$tcpar_Addressing_Mode){
		GDCOM_set_addressing_mode($mode);
		S_w2rep("*** ECU is in $mode  ***",'Green');
		
		S_teststep("Set $tcpar_Squib_Behaviour", 'AUTO_NBR');
		if($tcpar_Squib_Behaviour =~ m/MeasuredValue/i){
			S_w2rep("Not implemented for CA",'blue');
			S_set_verdict ( 'VERDICT_NONE' );
			$SquibFlag = 1;
			return 1; 
		}
		else{
			S_w2rep("Squib is evaluated for default value",'blue');
		}

		S_teststep("Enter '@$tcpar_Session'", 'AUTO_NBR');
		foreach $session(@$tcpar_Session){
			
			$service1 = GDCOM_request_general('REQ_DiagnosticSessionControl_'.$session,'PR_DiagnosticSessionControl_'.$session);
			
			@Req = split(/ /,$service1);
			$val2 = $Req[1];
			S_w2rep("Squib is in session @Req with its 2nd byte value : $val2",'green');
			
			
			S_w2rep("** evaluation for $mode with $session **",'Purple');
			S_teststep_expected("Positive response shall be obtained. ");			#evaluation 4
			if($session eq 'DefaultSession'){
				S_teststep_detected("Squib resistance is in $session");
				EVAL_evaluate_value("Evaluating positive response for Session",'0x'.$val2,'==','01') unless $main::opt_offline;	
			 }
			 elsif($session eq 'ExtendedSession'){
				S_teststep_detected("squib resistance is in $session");
				EVAL_evaluate_value("Evaluating positive response for Session",'0x'.$val2,'==','03') unless $main::opt_offline;	
			 }	

			S_teststep("Create '$tcpar_Condition' ", 'AUTO_NBR');			#measurement 1
			
			#creating different conditions and clearing respective squibs and clearing fault memory 
			_Condition_Create($tcpar_Condition, $tcpar_Squib);

			S_teststep("Read Fault Recorder.", 'AUTO_NBR');			#measurement 1
				$flt_mem = PD_ReadFaultMemory( );
						
				S_w2rep("***** Step 4 : Evaluation for $session with $mode Addressing Mode *****",'purple');
				S_teststep_expected("Condition created on '$tcpar_Squib' ");			#evaluation 1
					if($tcpar_Condition =~ m/NoFault|NotConfNotPresent/i){
							my $VERDICT = PD_evaluate_faults( $flt_mem, [], $optional_flt);
							if ($VERDICT =~ /PASS/i){
								S_teststep_detected("Required condition $tcpar_Condition is created");
							}
							else{
								S_teststep_detected("Condition $tcpar_Condition is not created");
								}
							}
							else{
								my $cond = _conditionName($tcpar_Condition);
								PD_check_fault_status($flt_mem, 'rb_sqm_'."$cond"."$tcpar_Squib".'_flt' ,'0bxxxx1xx1');
								S_teststep_detected("Required condition $tcpar_Condition is created");
							}
			

			S_teststep("Send '$tcpar_Request' ", 'AUTO_NBR');			#measurement 2
			$service = GDCOM_request_general('REQ_'.$tcpar_Request,'PR_'.$tcpar_Request);
			
				@Req1 = split(/ /,$service);
				S_w2rep("squib status is @Req1",'Blue');
				$val =  $Req1[3].$Req1[4];
				
					
					#evaluation
					S_w2rep("** evaluation for $mode with $session **",'Purple');
					S_teststep_expected("Positive response with '$tcpar_Response' is obtained. ");			#evaluation 4
					S_teststep_detected("squib resistance is:$val");
					EVAL_evaluate_value("Evaluating response for squib resistance",'0x'.$val,'==','0x'.$tcpar_Response,10) unless $main::opt_offline;	
				
				S_teststep("Removing the created condition '$tcpar_Condition' ", 'NO_AUTO_NBR');	
				#setting respective squibs and clearing and reading fault memory
				_resetCondition($tcpar_Condition, $tcpar_Squib);	

		}

	}	

	

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");  

	return 1;
}

sub TC_finalization {
	
	GDCOM_stop_CyclicTesterPresent();
	S_wait_ms('TIMER_DIAGNOSIS');
	
	return 1;
}


sub _Condition_Create {
	
	my $Condition = shift;
	my $Squib = shift;
	my $DeviceMapping = S_get_contents_of_hash(['Mapping_DEVICE']);
	my $SquibType = $DeviceMapping->{$Squib}{'type'}; 
	
	if ($Condition eq 'NoFault'){
		LC_SetResistance($Squib, '2.2');
	}
	elsif ($Condition eq 'Configuration'){
		PD_Device_configuration( 'clear',  [$Squib]);
		S_wait_ms(5000);
		LC_ECU_Reset();
		my ($Real,$Monitored,$Prog) = PD_get_device_config( $Squib );
		S_w2rep(" Present bit $Squib : $Real , Monitored bit $Squib : $Monitored , Configure bit $Squib : $Prog",'green');
	}
	elsif ($Condition eq 'NotConfNotPresent'){
		LC_DisconnectLine($Squib);
        S_wait_ms(2000);
        #Clear the configuration bit for the device
        PD_Device_configuration( 'clear',  [$Squib]);
        S_wait_ms(5000);
		LC_ECU_Reset();
		my ($Real,$Monitored,$Prog) = PD_get_device_config( $Squib );
		S_w2rep(" Present bit $Squib : $Real , Monitored bit $Squib : $Monitored , Configure bit $Squib : $Prog",'green');
        #Clear Fault memory
        PD_ClearFaultMemory();	
	}
	else{
	
		DEVICE_setDeviceState($Squib, $Condition);
	}
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
	
}

sub _resetCondition {
	
	my $Condition = shift;
	my $Squib_Name = shift;
	if($Condition eq 'Configuration'){
		PD_Device_configuration( 'set',  [$Squib_Name]);
		S_wait_ms(5000);
		LC_ECU_Reset();
	}
	elsif ($Condition eq 'NotConfNotPresent'){
		PD_Device_configuration( 'set', [$Squib_Name]);	
        S_wait_ms(5000);
		LC_ConnectLine($Squib_Name);
		S_wait_ms(5000);
		LC_ECU_Reset();  
	}
	else{
		DEVICE_resetDeviceState($Squib_Name, $Condition) unless ($Condition =~ m/NoFault/i);
	}
	S_wait_ms('TIMER_SIX_SEC');	
	LC_ECU_Reset( ); 
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_SIX_SEC');
	PD_ReadFaultMemory();
}

sub _conditionName {
	
	my $condition = shift;
	my $content;
	if($condition eq 'NoFault'){
		$content = 'No Fault';
	}
	elsif($condition eq 'OpenLine'){
		$content = 'SquibResistanceOpen';
	}
	elsif($condition eq 'SquibResistanceShort'){
		$content = 'SquibResistanceShort';
	}
	elsif($condition eq 'Short2Bat'){
		$content = 'TerminalShort2Bat';
	}
	elsif($condition eq 'Short2Gnd'){
		$content = 'TerminalShort2Gnd';
	}
	elsif($condition eq 'resistanceTooLow'){
		$content = 'SquibResistanceShort';
	}
	elsif($condition eq 'resistanceTooHigh'){
		$content = 'SquibResistanceOpen';
	}
	elsif($condition eq 'Configuration'){
		$content = 'Unexpected';
	}
	elsif($condition eq 'NotConfNotPresent'){
		$content = 'NotConfNotPresent';
	}
	else{
		S_set_error("Invalid condition \n");
	}
	
	return $content;
}

1;