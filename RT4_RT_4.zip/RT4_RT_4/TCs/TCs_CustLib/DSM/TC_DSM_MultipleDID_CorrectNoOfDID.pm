#### TEST CASE MODULE
package TC_DSM_MultipleDID_CorrectNoOfDID;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: DSM/TC_DSM_MultipleDID_CorrectNoOfDID.pm 1.3 2019/08/29 18:19:19ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_CustomerDiagnostics (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 4.125 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "To check multiple DID's for ReadData byIdentifier with Same and Differenr DID's in physical request";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_MultipleDID_CorrectNoOfDID

=head1 PURPOSE

'To check multiple DID's for ReadData byIdentifier with Same and Differenr DID's in physical request'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>

2. Enter Session <Session>

3. Set <Condition>

4. Set <DIDLimit> according to Addressing mode

5. Send <Request> with  <DIDType>  with nummber of DID's varies from <NoOfDID>  

#Multiple DID's are Supported subfunction/DID of  ReadDatabyID which are fetched from Mapping file

 


I<B<Evaluation>>

1. 

2. 

3.

4.

5. Positive response is obtained with the valid response bytes of the multiple DID sent. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'Addressing_Mode' => 
	LIST 'Protocol' => 
	LIST 'Session' => 
	LIST 'Request' => 
	LIST 'DIDType' => 
	SCALAR 'Condition' => 
	SCALAR 'DIDLimit' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check multiple DID's for ReadData byIdentifier with Same and Differenr DID's in physical request' 
	Addressing_Mode 	= @'<Fetch {Addressing Mode}>' 	#To be lined to SPS/SPR
	Protocol 		= @'<Fetch {Protocol}>' 		#To be lined to SPS/SPR
	Session 			= @'<Fetch {Session}>' 		#To be lined to SPS/SPR
	Request 			= @'<Fetch {Service description}>'	#To be lined to SPS/SPR
	DIDType = @('ReadGenericMemory', 'ReadDiagnosticSession', 'ReadEOLConfiguration ', 'ReadVIN', 'ReadVoltage')
	# With respect to NoOfDID mentioned the DID's will be sent 
	Condition = 'DifferantDID'
	DIDLimit = 'TBD' #Total Number of DID's shall be depend on the how many DIDs are supported in Physical Addressing mode.
	#Note: Parse the Condition and if precondition is applicable then respective test case shall executed 
	 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_DIDType;
my $tcpar_Condition;
my $tcpar_DIDLimit;
my $tcpar_NoOfDID;

################ global parameter declaration ###################
#add any global variables here

my $ReadGenericMemory_req ;
my $ReadDiagnosticSession_req;
my $ReadEOLConfiguration_req ;
my $ReadVIN ;
my $ReadVoltage ;
my $request_multipleDID;
my $NoOfDID;
my $index;
my $value;
my $response;
my @DIDType;
my $ReqDetail;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose','byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode','byvalue' );
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byvalue' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_DIDType =  S_read_mandatory_testcase_parameter( 'DIDType','byref' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition','byvalue' );
	$tcpar_DIDLimit =  S_read_mandatory_testcase_parameter( 'DIDLimit','byvalue' );
	$tcpar_NoOfDID =  S_read_mandatory_testcase_parameter( 'NoOfDID','byref' );
	
	#$ReadGenericMemory_req 		= S_get_contents_of_hash(['Mapping_DIAG','DIAG_SERVICES','ReadDataByIdentifier','Supported_SubFuns','ReadWriteGenData']);
	#$ReadDiagnosticSession_req 	= S_get_contents_of_hash(['Mapping_DIAG','DIAG_SERVICES','ReadDataByIdentifier','Supported_SubFuns','ActDiagSession']);
	#$ReadEOLConfiguration_req  	= S_get_contents_of_hash(['Mapping_DIAG','DIAG_SERVICES','ReadDataByIdentifier','Supported_SubFuns','ReadWriteEOL']);
	#$ReadVIN 					= S_get_contents_of_hash(['Mapping_DIAG','DIAG_SERVICES','ReadDataByIdentifier','Supported_SubFuns','ReadVIN']);
	#$ReadVoltage 				= S_get_contents_of_hash(['Mapping_DIAG','DIAG_SERVICES','ReadDataByIdentifier','Supported_SubFuns','ReadBatteryVoltage']);
	#@DIDType = ($ReadGenericMemory_req, $ReadDiagnosticSession_req, $ReadEOLConfiguration_req, $ReadVIN, $ReadVoltage );
	#S_w2rep("DIDs = @DIDType");
	
	foreach (@$tcpar_DIDType){
		$ReqDetail = GDCOM_getRequestInfofromMapping($_)->{'Requests'}{'REQ_'.$_}{'Request'};
		S_w2rep("--> $ReqDetail");
		$ReqDetail =~ s/^22 //;
		push @DIDType , $ReqDetail ;
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
    GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'", 'AUTO_NBR');
		GDCOM_set_addressing_mode($tcpar_Addressing_Mode);
		
	S_teststep("Enter Session '$tcpar_Session'", 'AUTO_NBR');
		DIAG_StartSession($tcpar_Session);

	S_teststep("Send '$tcpar_Request' with  '@$tcpar_DIDType'  with nummber of DID's varies from '@$tcpar_NoOfDID'  ", 'AUTO_NBR');			#measurement 1
	$request_multipleDID = $tcpar_Request ;
	foreach $NoOfDID (@$tcpar_NoOfDID){
		foreach $index (0..($NoOfDID - 1)){
			if($tcpar_Condition =~ m/DifferantDID/i){
				$request_multipleDID = $request_multipleDID.' '.$DIDType[$index];
			}else{
				$request_multipleDID = $request_multipleDID.' '.$DIDType[0];
			}
		}
		S_w2rep("##################################################################################################################",'purple');
		S_w2rep("Sending Request: '$request_multipleDID' in Addressing mode:'$tcpar_Addressing_Mode' and Session: '$tcpar_Session' ",'purple');
		$response = GDCOM_request($request_multipleDID,'62','relax',"Sending multipleDID Request: '$request_multipleDID'");
		
		S_teststep_expected("Positive response is obtained with the valid response bytes of the multiple DID sent. ");			#evaluation 1
		S_teststep_detected("Detected response:'$response' ");
		$value  = substr($response,0,2);
		EVAL_evaluate_string( "Positive response should obtained,Detected response is :$response " , '62' , $value );
		$request_multipleDID = $tcpar_Request ;
	}	

	return 1;
}

sub TC_evaluation {
	
	S_w2rep("Evaluation handled in stimulation part");

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}


1;