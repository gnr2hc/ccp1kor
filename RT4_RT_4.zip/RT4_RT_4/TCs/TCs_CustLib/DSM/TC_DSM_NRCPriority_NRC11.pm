#### TEST CASE MODULE
package TC_DSM_NRCPriority_NRC11;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: DSM/TC_DSM_NRCPriority_NRC11.pm 1.2 2019/08/20 13:21:26ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_DSM_CustomerDiagnostics> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <4.125> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = "<'To check the NRC11 Service not Supported over other NRCs'>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRCPriority_NRC11

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set <Addressing_Mode> for <Protocol>	

2. Enter <Session>

3. Create Condition <Condition1> 	

4.  Create <Condition2>

5. Send <Request> 


I<B<Evaluation>>

1. 

2. 

3. Condition 1 is created 

4. Condition 2 is created 

5.<Response_Type> is obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Condition2' => 
	SCALAR 'Purpose' => 
	LIST 'Addressing_Mode' => 
	SCALAR 'Protocol' => 
	SCALAR 'Session' => 
	SCALAR 'Request' => 
	SCALAR 'Condition1' => 
	SCALAR 'Response_Type' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check the NRC11 Service not Supported over other NRCs'
	
	Addressing_Mode = @('Physical','Functional')
	    
	Protocol = '<Fetch {Protocol}>' 
	
	Session = '<Fetch {Session}>' 
	
	Request = '23 60 00'   #ServiceNotSupported
	
	Condition1 = '23'  #SIDNotSupported
	
	Response_Type 	= 'ServiceNotSupported'		#NRC11 
	
	#Note: if the respective test case is applicable only be executed and remaining test case shall be not to be tested 
	Condition2 ='ServiceNotSupportedInActiveSession'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Addressing_Mode;
my $tcpar_Protocol;
my $tcpar_Session;
my $tcpar_Request;
my $tcpar_Condition1;
my $tcpar_CondReq;
my $tcpar_Response_Type;
my $tcpar_Condition2;

################ global parameter declaration ###################
#add any global variables here

my $Response;
my $Response1;
my $data;
my $data1;
my $CondiResp;
my $Service;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  S_read_mandatory_testcase_parameter( 'Purpose','byvalue' );
	$tcpar_Addressing_Mode =  S_read_mandatory_testcase_parameter( 'Addressing_Mode' ,'byvalue');
	$tcpar_Protocol =  S_read_mandatory_testcase_parameter( 'Protocol','byvalue' );
	$tcpar_Session =  S_read_mandatory_testcase_parameter( 'Session','byvalue' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request','byvalue' );
	$tcpar_Condition1 =  S_read_mandatory_testcase_parameter( 'Condition1','byvalue' );
	$tcpar_CondReq = S_read_mandatory_testcase_parameter('CondReq','byvalue');
	$tcpar_Response_Type =  S_read_mandatory_testcase_parameter( 'Response_Type','byvalue' );
	$tcpar_Condition2 =  S_read_mandatory_testcase_parameter( 'Condition2','byvalue' );

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	GDCOM_init();
	GDCOM_start_CyclicTesterPresent();	
	return 1;
}

sub TC_stimulation_and_measurement {

		S_teststep("Set '$tcpar_Addressing_Mode' for '$tcpar_Protocol'	", 'AUTO_NBR');
			GDCOM_set_addressing_mode($tcpar_Addressing_Mode);	
			S_w2rep("*****  Evaluation for $tcpar_Addressing_Mode  *****",'purple');

			S_teststep("Enter '$tcpar_Session'", 'AUTO_NBR');
					DIAG_StartSession($tcpar_Session);
					S_w2rep("ECU is in $tcpar_Session");

				S_teststep("Create Condition '$tcpar_Condition1' ", 'AUTO_NBR');			#measurement 1
					
					my $Req_Service = _getServiceID($tcpar_Condition1);
					$data = $Req_Service + 1;
					S_w2rep("--> $data");
					
					$CondiResp = "7F $data 11";
					$Response = GDCOM_request( $data , $CondiResp, 'strict', 'NRC11');
					
					S_w2rep("***** Evaluation for $tcpar_Session with $tcpar_Addressing_Mode  *****",'purple');
					S_teststep_expected("'$CondiResp shall be obtained.");			#evaluation 1
					S_teststep_detected("Obtained response is $Response");
					EVAL_evaluate_string( "'$CondiResp' shall be obtained" ,$CondiResp,$Response); 
					
					
					S_teststep("Create '$tcpar_Condition2'", 'AUTO_NBR');			#measurement 3
			
					if($tcpar_Condition2 =~ m/SecurityAccessDenied/i){
				
					
						my $Req_Service = _getServiceRequest($tcpar_CondReq);
						
						$data = substr($Req_Service,0,8);
						$data1 = substr($Req_Service,0,2);
						
						my $Service = $data.' '.'AD 55 FF 07';
						
						$CondiResp = "7F $data1 33";
						
						$Response = GDCOM_request( $Service , $CondiResp, 'strict', 'NRC33');
						S_w2rep("Response => $Response","Green");
						
						
				
					}
			
					elsif($tcpar_Condition2 =~ m/Invalid_Length/i){
					
						$Req_Service = _getServiceRequest($tcpar_CondReq);
						$data = substr($Req_Service,0,5);
						$data1 = substr($Req_Service,0,2);
						
						
						$CondiResp = "7F $data1 13";
						
						$Response = GDCOM_request( $data , $CondiResp, 'strict', 'NRC13');
						S_w2rep("Response => $Response1","Green");
										
					
					}	
				
					elsif($tcpar_Condition2 =~ m/SubFunction_NotSupported/i){
						
						my $Req_Service = _getServiceID($tcpar_CondReq);
						my $Service = $Req_Service.' '.'08 AF';
						
						$CondiResp = "7F $Req_Service 12";
						
						$Response = GDCOM_request( $Service , $CondiResp, 'strict', 'NRC12');
						S_w2rep("Response => $Response","Green");
											
					
					}

		
					elsif($tcpar_Condition2 =~ m/SequenceError/i){
					

						my $Req_Service = _getServiceRequest($tcpar_CondReq);
						$data = substr($Req_Service,0,5);
						$data1 = substr($Req_Service,0,2);
						
						my $Service = $data.' '.'34 56 78 89';
						
						$CondiResp = "7F $data1 24";
						
						$Response = GDCOM_request( $Service , $CondiResp, 'strict', 'NRC24');
						S_w2rep("Response => $Response","Green");
						
					
					}
					
						S_teststep_expected("'$CondiResp shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response");
						EVAL_evaluate_string( "'$CondiResp' shall be obtained" , $CondiResp, $Response); 	
					
						S_teststep("Send '$tcpar_Request' ", 'AUTO_NBR');			#measurement 1
						
						my $Req_Service = _getServiceID($tcpar_Request);
						$data = $Req_Service + 1;
						
						$CondiResp = "7F $data 11";
						$Response1 = GDCOM_request( $data , $CondiResp, 'strict', 'NRC11');
						
						S_w2rep("***** Evaluation for $tcpar_Session with $tcpar_Addressing_Mode *****",'purple');
						S_teststep_expected("'$tcpar_Response_Type shall be obtained.");			#evaluation 1
						S_teststep_detected("Obtained response is $Response1");
						EVAL_evaluate_string( "'$tcpar_Response_Type' shall be obtained" ,$CondiResp,$Response1); 	
					
		
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement"); 
	return 1;
}

sub TC_finalization {
	
	GDCOM_stop_CyclicTesterPresent();
	S_wait_ms (5000); 
	PD_ClearFaultMemory();
	S_wait_ms(2000);
	PD_ReadFaultMemory();
	LC_ECU_Reset();
		
	return 1;
}

	sub _getServiceRequest {

	my $SID = shift;
	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG','Requests_Responses',$tcpar_CondReq,'Requests','REQ_'.$tcpar_CondReq,'Request'] );
	
	return $services;
}

sub _getServiceID {

	my $SID = shift;
	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES', $SID ] );
	S_w2rep("Service : $services");
	
	return $services; 
}	

1;