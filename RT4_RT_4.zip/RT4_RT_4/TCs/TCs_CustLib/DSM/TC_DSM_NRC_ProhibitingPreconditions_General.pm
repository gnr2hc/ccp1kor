#### TEST CASE MODULE
package TC_DSM_NRC_ProhibitingPreconditions_General;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: DSM/TC_DSM_NRC_ProhibitingPreconditions_General.pm 1.1 2020/06/15 17:22:26ICT Biswas Abhishek (RBEI/ESA-PP2) (ABW5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_NegativeResponseCodes
#TS version in DOORS: 0.1
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
##################################

our $PURPOSE = "To verify the NRC for services which are dependent on certain preconditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_NRC_ProhibitingPreconditions

=head1 PURPOSE

To verify the NRC for services which are dependent on certain preconditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter session supported by the service. Get security access if required

2. Create <Precondition>

3. Send request

4. Remove <Precondition>

5. Enter session supported by the service. Get security access if required

6. Send request which depends on <Precondition>

Repeat for all requests supported by a service


I<B<Evaluation>>

1. -

2. -

3. <Response> is received for the requests whose precondition is fulfilled.
Positive response is received for requests which do not depend on the precondition

4. -

5. -

6. <Response1> is received for the requests whose precondition is not fulfilled.
Positive response is received for requests which do not depend on the precondition


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'Precondition' => 
	SCALAR 'Response' => 
	SCALAR 'Response1' =>


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the NRC for services which are dependent on IdleMode Precondition'
	Precondition = 'IdleMode'
	Response = 'NR_conditionsNotCorrect'
	Response1 = 'PositiveResponse'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Precondition;
my $tcpar_Response;
my $tcpar_Response1;
my $tcpar_Service;
my $tcpar_SpeedSignalName;
my $tcpar_SpeedSignalValue;
my ( %tcpar_CommunicationType, %tcpar_Key, %tcpar_Data, %tcpar_IOControlState, %tcpar_RoutineControlOption );

################ global parameter declaration ###################
#add any global variables here
my %DataValue;
my %PreconditionParameters;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose      = GEN_Read_mandatory_testcase_parameter('Purpose');
	$tcpar_Precondition = GEN_Read_mandatory_testcase_parameter('Precondition');
	$tcpar_Service      = GEN_Read_mandatory_testcase_parameter('Service');
	$tcpar_Response     = GEN_Read_mandatory_testcase_parameter('Response');
	$tcpar_Response1     = GEN_Read_mandatory_testcase_parameter('Response1');

	$PreconditionParameters{'SpeedSignalName'}   = GEN_Read_optional_testcase_parameter('SpeedSignalName');
	$PreconditionParameters{'SpeedSignalValue'}  = GEN_Read_optional_testcase_parameter('SpeedSignalValue');
	$PreconditionParameters{'InternalFaultName'} = GEN_Read_optional_testcase_parameter('InternalFaultName');

	#handle required bytes in request
	$DataValue{'StatusMask'}                  = GEN_Read_optional_testcase_parameter('StatusMask');
	$DataValue{'DTC'}                         = GEN_Read_optional_testcase_parameter('DTC');
	$DataValue{'DTCSnapshotRecordNumber'}     = GEN_Read_optional_testcase_parameter('DTCSnapshotRecordNumber');
	$DataValue{'DTCExtendedDataRecordNumber'} = GEN_Read_optional_testcase_parameter('DTCExtendedDataRecordNumber');

	%tcpar_CommunicationType    = GEN_Read_optional_testcase_parameter('CommunicationType');
	%tcpar_Key                  = GEN_Read_optional_testcase_parameter('Key');
	%tcpar_Data                 = GEN_Read_optional_testcase_parameter('Data');
	%tcpar_IOControlState       = GEN_Read_optional_testcase_parameter('IOControlState');
	%tcpar_RoutineControlOption = GEN_Read_optional_testcase_parameter('RoutineControlOption');

	return 1;
}

sub TC_initialization {

	S_teststep( "\nStandardPrepNoFault\n", 'NO_AUTO_NBR' );

	#	GEN_StandardPrepNoFault();

	DIAG_ECUReset_NOVERDICT();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
	PD_ReadFaultMemory_NOERROR();

	GDCOM_start_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');
	S_wait_ms (100);

	return 1;
}

sub TC_stimulation_and_measurement {

	#    S_teststep("Repeat for all requests within a service", 'AUTO_NBR');

	my $SID = $tcpar_Service;
	$tcpar_Service = _getServiceLabel($tcpar_Service);
	my $SubFuncInfo = GDCOM_getSupportedSubFunsfromMapping($tcpar_Service);

	my $count = 0; #to check if any request was executed
	foreach my $subFunc ( sort { hex( $SubFuncInfo->{$a} ) <=> hex( $SubFuncInfo->{$b} ) } keys %$SubFuncInfo ) {

		my $requestLabel = $tcpar_Service . "_" . $subFunc;
		S_w2rep( "************* $requestLabel *************", 'orange' );

		unless ( _getProtocolForRequest($requestLabel) eq 'UDS' ) {
			S_w2rep("Sub Function ($requestLabel) is not supported on UDS protocol. Go to next sub function..");
			next;
		}

		_fillRequestInputParameters( $SID, S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] ) );

		my $prohibitingPreconditionsForRequest = _getProhibitingPreconditionsForRequest($requestLabel);

		if ( grep { $_ =~ m/\Q$tcpar_Precondition\E/i } @$prohibitingPreconditionsForRequest ) {
			
			if ( $SID eq '2E' ) {    #for 2E service, write the same value as read by 22 service
				my $DID = S_get_contents_of_hash( [ 'Mapping_DIAG', 'DIAG_SERVICES', $tcpar_Service, 'Supported_SubFuns', $subFunc ] );
				my $readdata = GDCOM_request_NOVERDICT ( "22 $DID", "62 $DID", 'relax' );
				$readdata = substr( $readdata, 9 );    #remove 62 DIDHB DIDLB
				$DataValue{'Data'} = $readdata if (defined $readdata);
			}

			my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
			S_teststep( "Enter session: @$sessionsForRequest[0]", 'AUTO_NBR' );
			GDCOM_set_addressing_mode('disposal') if ( @$sessionsForRequest[0] =~ m/safety|disposal/i );
			DIAG_StartSession( @$sessionsForRequest[0] );
			S_wait_ms( 5000, 'wait after session entry' ) if ( @$sessionsForRequest[0] =~ m/prog|boot/i );

			my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

			if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' ) {    #in case security access is required
				S_teststep( "Get required security access: @$securityLevelsForRequest", 'AUTO_NBR' );
				DIAG_getSecurityAccess( @$securityLevelsForRequest[0] ) if ( defined &DIAG_getSecurityAccess );
			}

			GDCOM_GetAccessToRequest($requestLabel);                                                         #handle any dependent services through request in Mapping_DIAG (if required)

			my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $requestLabel, \%DataValue );

			S_teststep( "Create condition: $tcpar_Precondition", 'AUTO_NBR' );
			DIAG_setProhibitingPrecondition( $tcpar_Precondition, \%PreconditionParameters ) if ( defined &DIAG_setProhibitingPrecondition );    #TODO: function to be developed (Story 62110)

			S_teststep( "Send request $requestLabel: $requestBytes", 'AUTO_NBR', $subFunc . "send_request_$tcpar_Precondition" );

			my $response;
			if($tcpar_Response =~ m/PositiveResponse/i) { 
				$response = GDCOM_request_general( "REQ_" . $requestLabel, "PR_" . $requestLabel, \%DataValue );
				S_teststep_expected( $tcpar_Response, $subFunc . "send_request_$tcpar_Precondition" ); 
				S_teststep_detected( $response, $subFunc . "send_request_$tcpar_Precondition" );
			}
			else { #NRC expected
				$response = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response, \%DataValue );
				my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response );
				S_teststep_expected( $NRCInfo->{'Response'}, $subFunc . "send_request_$tcpar_Precondition" ); 
				S_teststep_detected( $response, $subFunc . "send_request_$tcpar_Precondition" );
			}			
                                                     

			DIAG_removeProhibitingPrecondition( $tcpar_Precondition, \%PreconditionParameters );
			S_wait_ms(4000);
			my $sessionsForRequest = _getSupportedSessionsForRequest($requestLabel);
			S_teststep( "Enter session: @$sessionsForRequest[0]", 'AUTO_NBR' );
			GDCOM_set_addressing_mode('disposal') if ( @$sessionsForRequest[0] =~ m/safety|disposal/i );
			DIAG_StartSession( @$sessionsForRequest[0] );
			S_wait_ms( 5000, 'wait after session entry' ) if ( @$sessionsForRequest[0] =~ m/prog|boot/i );

			my $securityLevelsForRequest = _getSecurityLevelsForRequest($requestLabel);

			if ( @$securityLevelsForRequest[0] !~ m/None/i and @$securityLevelsForRequest[0] ne '---' ) {    #in case security access is required
				S_teststep( "Get required security access: @$securityLevelsForRequest", 'AUTO_NBR', $subFunc . "send_request_$tcpar_Precondition" . "afterSA" );
				DIAG_getSecurityAccess( @$securityLevelsForRequest[0] ) if ( defined &DIAG_getSecurityAccess );
			}

			GDCOM_GetAccessToRequest($requestLabel);                                                         #handle any dependent services through request in Mapping_DIAG (if required)

			my $requestBytes = GDCOM_getRequestLabelValue( "REQ_" . $requestLabel, \%DataValue );
            S_teststep( "Send request $requestLabel: $requestBytes", 'AUTO_NBR', $subFunc . "send_request_$tcpar_Precondition" . "after" );

			my $response1;
			if($tcpar_Response1 =~ m/PositiveResponse/i) { 
				$response1 = GDCOM_request_general( "REQ_" . $requestLabel, "PR_" . $requestLabel, \%DataValue );
				S_teststep_expected( $tcpar_Response1, $subFunc . "send_request_$tcpar_Precondition" . "after" ); 
				S_teststep_detected( $response1, $subFunc . "send_request_$tcpar_Precondition" . "after" );
			}
			else { #NRC expected
				$response1 = GDCOM_request_general( "REQ_" . $requestLabel, $tcpar_Response1, \%DataValue );
				my $NRCInfo = GDCOM_getNRCfromMapping( $tcpar_Service, $tcpar_Response1 );
				S_teststep_expected( $NRCInfo->{'Response1'}, $subFunc . "send_request_$tcpar_Precondition". "after" ); 
				S_teststep_detected( $response1, $subFunc . "send_request_$tcpar_Precondition" . "after" );
				
			}
			   
			S_wait_ms(4000);
			$count++;
			
			S_teststep( "\n", 'NO_AUTO_NBR' );    #newline for steps in TR
		}
		else {
			S_w2rep( "Request '$requestLabel' doesn't depend on $tcpar_Precondition precondition" );
#			S_teststep( "Request '$requestLabel' doesn't depend on $tcpar_Precondition precondition", 'AUTO_NBR', $subFunc );
#			S_teststep_expected( "No evaluation", $subFunc );
#			S_teststep_detected( "'$requestLabel' doesn't depend on $tcpar_Precondition precondition", $subFunc );

			#            #positive response expected
			#            my $response = GDCOM_request_general( "REQ_" . $requestLabel, "PR_" . $requestLabel, \%DataValue );
			#
			#            my $ReqRespInfo = DCOM_getReqestResponseFromMapping( $requestLabel, \%DataValue );
			#            S_teststep_expected( $ReqRespInfo->{'Response'}, $subFunc . "send_request_$tcpar_Precondition" );                                 #evaluation 2
			#            S_teststep_detected( $response, $subFunc . "send_request_$tcpar_Precondition" ); #no response expected
		}

	}
	
	if($count == 0){ #for TR printout
		S_teststep( "No requests for service $SID depend on $tcpar_Precondition precondition\n", 'AUTO_NBR', 'NO_REQ' );
		S_teststep_expected( "No evaluation", 'NO_REQ' );
		S_teststep_detected( "No requests for service $SID depend on $tcpar_Precondition precondition\n", 'NO_REQ' );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _getServiceLabel {
	my $SID = shift;

	my $services = S_get_contents_of_hash( [ 'Mapping_DIAG', 'PRJ_SUPPORTED_SERVICES' ] );

	foreach my $serv ( keys %$services ) {
		return $serv if ( $services->{$serv} eq $SID );
	}
}

sub _getSecurityLevelsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_securitylevels'};
}

sub _getProhibitingPreconditionsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'preconditions_prohibiting_execution'};
}

sub _getProtocolForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'protocol'};
}

sub _getSupportedAddrModesForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_addressingmodes'};
}

sub _getSupportedSessionsForRequest {
	my $reqLabel = shift;

	return GDCOM_getRequestInfofromMapping($reqLabel)->{'allowed_in_sessions'};
}

sub _fillRequestInputParameters {
	my $SID     = shift;
	my $subFunc = shift;

	if ( $SID eq '27' ) {
		$DataValue{'Key'} = $tcpar_Key{$subFunc};
	}
	elsif ( $SID eq '28' ) {
		$DataValue{'CommunicationType'} = $tcpar_CommunicationType{$subFunc};
	}
	elsif ( $SID eq '2E' ) {
		$DataValue{'Data'} = $tcpar_Data{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '2F' ) {
		$DataValue{'IOControlState'} = $tcpar_IOControlState{$subFunc};
	}
	elsif ( $SID eq '31' ) {
		$DataValue{'RoutineControlOption'} = $tcpar_RoutineControlOption{$subFunc};
	}

}

1;
