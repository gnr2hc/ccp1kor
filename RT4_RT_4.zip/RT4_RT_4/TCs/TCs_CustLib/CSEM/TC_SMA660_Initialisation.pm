#### TEST CASE MODULE
package TC_SMA660_Initialisation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: CSEM/TC_SMA660_Initialisation.pm 1.1 2020/05/22 00:48:50ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_labcar;
use LIFT_spi_access;
use LIFT_PD;
use LIFT_evaluation;
#include further modules here

##################################

our $PURPOSE = "Over all Purpose is to verify the Sensor Initialisation command sequence ";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SMA660_Initialisation 

=head1 PURPOSE

<Over all Purpose is to verify the Sensor Initialisation command sequence>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault 


I<B<Stimulation and Measurement>>

1. Capture SPI data of SMA660 <Sensor> CaptureSPIData_SMA660_Initialisation

2. verify SPI trace data. Also verify the sensor Initilisation command sequence. 


I<B<Evaluation>>

1.

2.

2a. Expected<Current_Command>

2b. Expected<MOSI_Data_Value> of <Current_Command>

2c. Expected<MISO_Data_Value> of <Current_Command>

2d. Expected<PrecedingCommand> 

2e. Expected<SucceedingCommand> 

2f. Expected<Wait_Time>

Note: Wait_Time Should be observed only for Specified commands whenever it is metioned in the requirements. 

2g. Expected<GS_Flag_Value>

Note: GS_Flag_Value Should be observed only for Specified commands whenever it is metioned in the requirements.    

2h. Expected<CRC_Value>

2i. Expected<TIME_SR>

 Note: Expected value Should be observed only for Specified commands whenever it is metioned in the requirements. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Current_Command' => 
	HASH 'MOSI_Data_Value' => 
	HASH 'MISO_Data_Value' => 
	SCALAR 'PrecedingCommand' => 
	LIST 'SucceedingCommand' => 
	SCALAR 'Wait_Time' => 
	SCALAR 'GS_Flag_Value' => 
	SCALAR 'CRC_Value' => 
	SCALAR 'TIME_SR' => 
	SCALAR 'purpose' => 
	SCALAR 'Sensor' => 


=head2 PARAMETER EXAMPLES

	purpose = 'Over all Purpose is to verify the Sensor Initialisation command sequence'
	Sensor =  '<Test Heading 1>'             
	Current_Command = 'PROT_SEL'
	
	MOSI_Data_Value = %('Instruction' => '0xFF00FF00')
	
	MISO_Data_Value = %('PROT_SEL_RESP' => '0xFFFFFFFF')
	
	PrecedingCommand = 'None'
	
	SucceedingCommand =  @('PROG_MODE')
	
	Wait_Time = 'NA'
	
	GS_Flag_Value = 'NA'
	
	CRC_Value = 'NA'
	
	TIME_SR  = 'NA'
	
	# Response of the Sensor is Ignored 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Sensor;
my $tcpar_Current_Command;
my $tcpar_MOSI_Data_Value;
my $tcpar_MISO_Data_Value;
my $tcpar_PrecedingCommand;
my $tcpar_SucceedingCommand;
my $tcpar_Wait_Time;
my $tcpar_GS_Flag_Value;
my $tcpar_CRC_Value;
my $tcpar_TIME_SR;
my $tcpar_Time_Eval;
my ( $tcpar_USE_SPI_RECORD, $tcpar_SPI_Node, $SPI_tracefile_name, $tcpar_Leading_SPI_frames, $tcpar_Following_SPI_frames, $SPI_data );

################ global parameter declaration ###################
#add any global variables here
my $meas_label;
my @tcpar_expectedCommands_aref;
my $thisVerdict;
#my $time;
my $timestamp ;  
my $MINtime_stamp ;
my $MAXtime_stamp ;
my $detectedSequence_aref;
my %time_href;
my $tcpar_expectedCommands_aref;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Sensor =  GEN_Read_mandatory_testcase_parameter( 'Sensor' );
	$tcpar_Current_Command =  GEN_Read_mandatory_testcase_parameter( 'Current_Command' );
	$tcpar_MOSI_Data_Value =  GEN_Read_mandatory_testcase_parameter( 'MOSI_Data_Value','byref' );
	$tcpar_MISO_Data_Value =  GEN_Read_mandatory_testcase_parameter( 'MISO_Data_Value','byref' );
	$tcpar_PrecedingCommand =  GEN_Read_mandatory_testcase_parameter( 'PrecedingCommand' );
	$tcpar_SucceedingCommand =  GEN_Read_mandatory_testcase_parameter( 'SucceedingCommand' );
	$tcpar_Wait_Time =  GEN_Read_mandatory_testcase_parameter( 'Wait_Time' );
	$tcpar_GS_Flag_Value =  GEN_Read_mandatory_testcase_parameter( 'GS_Flag_Value' );
	$tcpar_CRC_Value =  GEN_Read_mandatory_testcase_parameter( 'CRC_Value' );
	$tcpar_TIME_SR =  GEN_Read_mandatory_testcase_parameter( 'TIME_SR' );
	$tcpar_SPI_Node = S_read_mandatory_testcase_parameter('SPI_Node');
	$meas_label= S_read_mandatory_testcase_parameter('measurement_label');
	@tcpar_expectedCommands_aref = S_read_mandatory_testcase_parameter( '_Expected_Commands', 'byref');
	$tcpar_Time_Eval = GEN_Read_mandatory_testcase_parameter('Time_Eval');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault ", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms(8000);
	PD_ReadFaultMemory();
	S_wait_ms(4000);
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms(6000);
	return 1;
}

sub TC_stimulation_and_measurement {
	S_teststep("Capture SPI data of SMA660 '$tcpar_Sensor' CaptureSPIData_SMA660_Initialisation", 'AUTO_NBR');
		if ( $tcpar_USE_SPI_RECORD ne 'no' ) {
				LC_ECU_On();
		
			S_teststep( "Start SPI recording", 'AUTO_NBR' );
			return unless SPI_trace_start( [$tcpar_SPI_Node] );
			}
			S_wait_ms(2000);
			S_teststep( "Stop SPI Trace", 'AUTO_NBR' );
			SPI_trace_stop();
			S_w2rep( "Trace stopped with captured data " );
			S_teststep( "Store SPI Trace", 'AUTO_NBR' );
			my $SPI_tracefile_name = $main::REPORT_PATH . "/" . "SMA" . "_SPI_trace.mbt";
			S_teststep( "Store SPI Trace", 'AUTO_NBR' );
			SPI_trace_store($SPI_tracefile_name);
            SPI_trace_load_file(
				'MeasurementLabel' => $meas_label,
				'FileName'         => $SPI_tracefile_name,
				);
				foreach my $SPI_node ($tcpar_SPI_Node) {
            my $measurement_temp_href = SPI_trace_get_dataref(
					'MeasurementLabel' => $meas_label,
					'SPI_Node'         => $SPI_node,
				);
            }
            if ( defined @tcpar_expectedCommands_aref ){
            my $measdata_href = SPI_trace_get_dataref('MeasurementLabel' => $meas_label,
                                              'SPI_Node' => $tcpar_SPI_Node,
                                              'StartTime_ms' => 0 ,
                                              'EndTime_ms' => 4000);
			
            my ($thisVerdict,$detectedSequence_aref,$cmd_details_href) = SPI_EVAL_check_command_sequence(
                                                        'MeasurementData_href' => $measdata_href,
													    'CommandList' => @tcpar_expectedCommands_aref,
														'GetCmdDetails' => 1, );
	        use Data::Dumper;
            my $key_val =  Dumper( $cmd_details_href );
		    S_w2rep("command details---->$key_val\n");
			if($tcpar_Time_Eval eq 'Yes')
			{
			foreach my $timestamp (keys %$measdata_href){
				foreach my $cmd (@$tcpar_expectedCommands_aref){
					if(defined $measdata_href->{$timestamp}->{$tcpar_SPI_Node.'::'.$cmd}){
						$time_href{$cmd} = $timestamp;
						}
				}
			}
			S_w2rep(Dumper(\%time_href));
			my $time_href = Dumper(\%time_href);
			my @value = values %time_href;
			my $timestamp1 = $value[0];
			my $timestamp2 = $value[1];
			S_w2rep("timestamp1 value:$timestamp1");
			S_w2rep("timestamp2 value:$timestamp2");
			my $timedifference = ($timestamp2 - $timestamp1);
			S_w2rep("The time difference is $timedifference");
			}
		    my @MOSI_Data_Value = keys %$tcpar_MOSI_Data_Value;   
	        my @MISO_Data_Value = keys %$tcpar_MISO_Data_Value;   
	        my $MOSI_expected_Data_value = $tcpar_MOSI_Data_Value->{$MOSI_Data_Value[0]};
	        my $MISO_expected_Data_value = $tcpar_MISO_Data_Value->{$MISO_Data_Value[0]};
	        S_w2rep("Expected MOSI command value:$MOSI_expected_Data_value and Expected MISO command value:$MISO_expected_Data_value");
	        my $MOSI_detected_Data_value = $cmd_details_href->{$tcpar_Current_Command}->{$MOSI_Data_Value[0]};
            my $MISO_detected_Data_value = $cmd_details_href->{$tcpar_Current_Command}->{$MISO_Data_Value[0]};
	        S_w2rep("Detected MOSI command value:$MOSI_detected_Data_value and Detected MISO command value:$MISO_detected_Data_value");
            EVAL_evaluate_value("Expected MOSI value of $tcpar_Current_Command command should match with the Detected MOSI value",hex($MOSI_expected_Data_value), '==',hex($MOSI_detected_Data_value));
            EVAL_evaluate_value("Expected MISO value of $tcpar_Current_Command command should match with the Detected MISO value",hex($MISO_expected_Data_value),'==',hex($MISO_detected_Data_value));
			}		
else {
	S_set_error("Command details are not provided hence not proceeding further\n",110);
}	
return 1;
}

sub TC_evaluation {

	S_teststep_expected("Evaluation is done in stimulation and measurement");			#evaluation 2
	

	return 1;
}

sub TC_finalization {
    S_teststep( "Set 'power-OFF'", 'AUTO_NBR' );
    LC_ECU_Off();

	return 1;
}


1;
