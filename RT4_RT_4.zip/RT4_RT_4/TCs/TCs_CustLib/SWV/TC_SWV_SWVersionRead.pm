#### TEST CASE MODULE
package TC_SWV_SWVersionRead;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWV/TC_SWV_SWVersionRead.pm 1.1 2020/01/17 13:08:05ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWV_SoftwareVersion> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <0.26> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWV_SWVersionRead

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read the SW version string using SW labels <SWversionString_ROM_var> and <SWversionString_NVM_var>.


I<B<Evaluation>>

1. Values read from <SWversionString_ROM_var> and <SWversionString_NVM_var> should match with expected values  <SWversionString_Expval>.

Verify the following components of SW version string individually.

- Customer ID

- Project ID

- HW sample

- Continous ID

- BB number


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'SWversionString_ROM_var' => 
	LIST 'SWversionString_NVM_var' => 
	SCALAR 'SWversion_Expval' => 
	SCALAR 'Note: Expected values <SWversion_Expval> are different for different checkpoints. Refer the latest SPR.' => 
	SCALAR 'The data(expected values) can also be found in SCIP [Path: ab12_development -->pv_models -->Variantmodels -->Softwarevariantmodels].' => 
	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	purpose = ' To verify SW version string stored inside the executable part of the software in ROM and NVM'
	SWversionString_ROM_var = @('rb_swv_SwVersionRomCfg_cst.CustomerId0_u8', 'rb_swv_SwVersionRomCfg_cst.CustomerId1_u8', 'rb_swv_SwVersionRomCfg_cst.ProjectId_u8', 'rb_swv_SwVersionRomCfg_cst.HwSamplePhase_u8', 'rb_swv_SwVersionRomCfg_cst.HwSampleNumber_u8', 'rb_swv_SwVersionRomCfg_cst.ContinuousId_u16', 'rb_swv_SwVersionRomCfg_cst.BbNumber0_u8', 'rb_swv_SwVersionRomCfg_cst.BbNumber1_u8', 'rb_swv_SwVersionRomCfg_cst.BbNumber2_u8')
	SWversionString_NVM_var = @('rb_swv_SwVersionNvmCfg_dfst.CustomerId0_u8', 'rb_swv_SwVersionNvmCfg_dfst.CustomerId1_u8', 'rb_swv_SwVersionNvmCfg_dfst.ProjectId_u8', 'rb_swv_SwVersionNvmCfg_dfst.HwSamplePhase_u8', 'rb_swv_SwVersionNvmCfg_dfst.HwSampleNumber_u8', 'rb_swv_SwVersionNvmCfg_dfst.ContinuousId_u16', 'rb_swv_SwVersionNvmCfg_dfst.BbNumber0_u8', 'rb_swv_SwVersionNvmCfg_dfst.BbNumber1_u8', 'rb_swv_SwVersionNvmCfg_dfst.BbNumber2_u8')
	SWversion_Expval = "TBD" #Fetch the expected values from latest SPR
	
	Note: Expected values <SWversion_Expval> are different for different checkpoints. Refer the latest SPR.
	The data(expected values) can also be found in SCIP [Path: ab12_development -->pv_models -->Variantmodels -->Softwarevariantmodels].

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SWversionString_ROM_var;
my $tcpar_SWversionString_NVM_var;
my @tcpar_SWversion_Expval;
#my $tcpar_Note: Expected values <SWversion_Expval> are different for different checkpoints. Refer the latest SPR.;
#my $tcpar_The data(expected values) can also be found in SCIP [Path: ab12_development -->pv_models -->Variantmodels -->Softwarevariantmodels].;

################ global parameter declaration ###################
#add any global variables here
my $read_value1;
my $read_value2;
my @array1;
my @array2;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SWversionString_ROM_var =  GEN_Read_mandatory_testcase_parameter( 'SWversionString_ROM_var','byref' );
	$tcpar_SWversionString_NVM_var =  GEN_Read_mandatory_testcase_parameter( 'SWversionString_NVM_var' ,'byref');
	@tcpar_SWversion_Expval =  GEN_Read_mandatory_testcase_parameter( 'SWversion_Expval');
	#$tcpar_Note: Expected values <SWversion_Expval> are different for different checkpoints. Refer the latest SPR. =  GEN_Read_mandatory_testcase_parameter( 'Note: Expected values <SWversion_Expval> are different for different checkpoints. Refer the latest SPR.' );
	#$tcpar_The data(expected values) can also be found in SCIP [Path: ab12_development -->pv_models -->Variantmodels -->Softwarevariantmodels]. =  GEN_Read_mandatory_testcase_parameter( 'The data(expected values) can also be found in SCIP [Path: ab12_development -->pv_models -->Variantmodels -->Softwarevariantmodels].' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Read the SW version string using SW labels '@$tcpar_SWversionString_ROM_var' and '@$tcpar_SWversionString_NVM_var'.", 'AUTO_NBR', 'read_the_sw');			#measurement 1
	
	S_w2rep("*** ROM VARIABLES  ***","Purple");  
	foreach my $rom_var (@$tcpar_SWversionString_ROM_var){
		$read_value1 = S_aref2hex(PD_ReadMemoryByName($rom_var));
		S_w2rep("*** Detected variable - $read_value1  ***");
		push @array1 , $read_value1;	
	}
	
	S_w2rep("*** NVM VARIABLES  ***","Purple");
	foreach my $nvm_var (@$tcpar_SWversionString_NVM_var){
		$read_value2 = S_aref2hex(PD_ReadMemoryByName($nvm_var));
		S_w2rep("*** Detected variable - $read_value2  ***");
		push @array2 , $read_value2;	
	}
	

	return 1;
}

sub TC_evaluation {
	

	S_w2rep("*** Customer ID - ROM ***","Orange");  
	for(my $i=0;$i<2;$i++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_ROM_var value is:$read_value1");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_ROM_var:",$array1[$i],'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	
	S_w2rep("*** Customer ID - NVM ***","Orange");  
	for(my $j=0;$j<2;$j++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_NVM_var value  is:$read_value2");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_NVM_var:",$array2[$j],'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	}
	
	
	
	 S_w2rep("*** for Project ID  ***","Orange");  
	 for(my $i=2;$i<3;$i++){
	 S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
	 S_teststep_detected("Detected @$tcpar_SWversionString_ROM_var value is:$read_value1");
	 EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_ROM_var:",$array1[$i],'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	
	for(my $j=2;$j<3;$j++){
	 S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
	 S_teststep_detected("Detected @$tcpar_SWversionString_NVM_var value  is:$read_value2");
	 EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_NVM_var:",$array2[$j],'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	 }
	
	
	

	S_w2rep("*** for HW sample  ***","Orange");  
	for(my $i=3;$i<5;$i++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_ROM_var value  is:$read_value1");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_ROM_var:",$array1[$i],'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	
	for(my $j=3;$j<5;$j++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_NVM_var value  is:$read_value2");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_NVM_var:",$array2[$j],'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	}
	
	

	S_w2rep("*** for Continous ID ***","Orange"); 
	for(my $i=5;$i<6;$i++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_ROM_var value is:$read_value1");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_ROM_var:",$array1[$i],'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	
	for(my $j=5;$j<6;$j++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_NVM_var value  is:$read_value2");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_NVM_var:",$array2[$j],'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	}


	S_w2rep("*** for BB number ***","Orange"); 
	for(my $i=6;$i<9;$i++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_ROM_var value  is:$read_value1");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_ROM_var:",$array1[$i],'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	
	for(my $j=6;$j<9;$j++){
		S_teststep_expected("Package ID and Layout ID Values read from '@$tcpar_SWversionString_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.");			#evaluation 1
		S_teststep_detected("Detected @$tcpar_SWversionString_NVM_var value  is:$read_value2");
		EVAL_evaluate_value("Evaluating response for @$tcpar_SWversionString_NVM_var:",$array2[$j],'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	}

	return 1;
}

sub TC_finalization {

	S_wait_ms(1000);
	return 1;
}


1;