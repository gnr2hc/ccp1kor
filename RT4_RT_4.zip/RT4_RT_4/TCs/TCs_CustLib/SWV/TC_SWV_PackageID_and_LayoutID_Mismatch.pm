#### TEST CASE MODULE
package TC_SWV_PackageID_and_LayoutID_Mismatch;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWV/TC_SWV_PackageID_and_LayoutID_Mismatch.pm 1.1 2020/01/17 13:08:05ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWV_SoftwareVersion> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <0.26> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_labcar;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWV_PackageID_and_LayoutID_Mismatch

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>


I<B<Stimulation and Measurement>>

1.Read the value of <variable>

2.Manipulate the contents of Package ID and Layout ID  using SW labels  <NVM_Var>.

3.Hard Reset.

4.Read the fault Recorder

5.Read the value of <variable>

6.Read the value of<Sys_mode>

7.Check the status of warning lamp and warning lamp status variable

8.Clear the fault memory

9.Hard Reset

10.Read the fault Recorder

11.Read the value of <variable>


I<B<Evaluation>>

1.Value of <variable> should be 1.

4.<Fault>should qualify

5.Value of <variable> should be 0.

6.value of<Sys_mode> should be equal to 4.

7Warning lamp should glow and value of<WI_Status> should be 1

8.No <Fault> in memory

10.<Fault> is qualified

11.Value of <variable> should be 0.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'NVM_Var' => 
	SCALAR 'purpose' => 
	SCALAR 'variable' => 
	SCALAR 'Fault' => 
	SCALAR 'Sys_mode' => 
	SCALAR 'WI_Status' => 


=head2 PARAMETER EXAMPLES

	purpose = ' To verify that the mismatch between  SW Package ID and Layout ID  stored in NVM and ROM creates a fault'
	
	variable ='rb_swv_SwCheckResult_bo'
	
	Fault ='SwVersionWrong'
	
	Sys_mode ='rb_bswm_ActualSystemMode_au16(0)'
	
	WI_Status  ='rb_wimi_SysWIStatus_aen(0)'
	NVM_Var ='rb_swv_DataPackageOverwriteableNvmCfg_dfst.Package_u32'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_variable;
my $tcpar_Fault;
my $tcpar_Sys_mode;
my $tcpar_WI_Status;
my $tcpar_NVM_Var;
my $tcpar_WI_Status;
my $tcpar_LoadName;
my $tcpar_DriverState;
my $tcpar_FLTopt_aref  ;


################ global parameter declaration ###################
#add any global variables here
my $value;
my $read_value1;
my $read_value2;
my $read_value3;
my $read_value4;
my $optional_flt = ['rb_sqm_SquibResistanceOpenAB2FD_flt','rb_utsv_SwVersionWrong_flt'];
my $write;
my @original_value;
my $lamp_states_href;
my $device;
my $state;
my @optFaults_Quali;
my @optFaults_DeQuali;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_variable =  GEN_Read_mandatory_testcase_parameter( 'variable' );
	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_FLTopt_aref        = S_read_optional_testcase_parameter('FLTopt');
	$tcpar_Sys_mode =  GEN_Read_mandatory_testcase_parameter( 'Sys_mode' );
	$tcpar_WI_Status =  GEN_Read_mandatory_testcase_parameter( 'WI_Status' );
	$tcpar_NVM_Var =  GEN_Read_mandatory_testcase_parameter( 'NVM_Var' );
	$tcpar_LoadName = GEN_Read_mandatory_testcase_parameter( 'LoadName' );
    $tcpar_DriverState = GEN_Read_mandatory_testcase_parameter( 'DriverState' );

	@optFaults_Quali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );
	@optFaults_DeQuali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
    
	$value = S_aref2hex(PD_ReadMemoryByName($tcpar_NVM_Var));
	S_w2rep("$value","Blue");
	
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Read the value of '$tcpar_variable'", 'AUTO_NBR', 'read_the_value_A');			#measurement 1
	$read_value1 = S_aref2hex(PD_ReadMemoryByName($tcpar_variable));
	S_w2rep("*** Detected variable - $read_value1  ***");
	
	S_teststep_expected("Value of '$tcpar_variable' should be 1.", 'read_the_value_A');			#evaluation 1
	S_teststep_detected("Detected $tcpar_variable value is:$read_value1");
	EVAL_evaluate_value("Evaluating response :",$read_value1,'==',1,10) unless $main::opt_offline;	
	
	

	S_teststep("Manipulate the contents of Package ID and Layout ID  using SW labels  '$tcpar_NVM_Var'.", 'AUTO_NBR');
	
	my $read_value2 = S_aref2hex(PD_ReadMemoryByName($tcpar_NVM_Var));
	S_w2rep("*** Detected variable before increment - $read_value2  ***","Green");
	$read_value2++;
	S_w2rep("*** Detected variable - $read_value2  ***","Green");
	
	PD_WriteMemoryByName($tcpar_NVM_Var,$read_value2);
	S_wait_ms(1000);
	
	
	
	S_teststep("Hard Reset.", 'AUTO_NBR');
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );
	
	
	
	S_teststep("Read the fault Recorder", 'AUTO_NBR', 'read_the_fault_A');			#measurement 2
		
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_'."$tcpar_Fault".'_flt' ,'0bxxxx1xx1');
	S_teststep_detected("Fault Qualified : $detected_fault ");
	S_wait_ms(5000);	
	


	S_teststep("Read the value of '$tcpar_variable'", 'AUTO_NBR', 'read_the_value_B');			#measurement 3
	$read_value1 = S_aref2hex(PD_ReadMemoryByName($tcpar_variable));
	S_w2rep("*** Detected variable - $read_value1  ***");
	
	S_teststep_expected("Value of '$tcpar_variable' should be 0.", 'read_the_value_B');			#evaluation 3
	S_teststep_detected("Detected $tcpar_variable value is:$read_value1");
	EVAL_evaluate_value("Evaluating response: ",$read_value1,'==',0) unless $main::opt_offline;	



	S_teststep("Read the value of'$tcpar_Sys_mode'", 'AUTO_NBR', 'read_the_value_C');			#measurement 4
	$read_value3 = S_aref2hex(PD_ReadMemoryByName($tcpar_Sys_mode));
	S_w2rep("*** Detected variable - $read_value3  ***");
	
	S_teststep_expected("value of'$tcpar_Sys_mode' should be equal to 4.", 'read_the_value_C');			#evaluation 4
	S_teststep_detected("Detected $tcpar_Sys_mode value is:$read_value3");
	EVAL_evaluate_value("Evaluating response :",$read_value3,'==',4) unless $main::opt_offline;	
	
	

	S_teststep("Check the status of warning lamp and warning lamp status variable", 'AUTO_NBR', 'check_the_status');			#measurement 5
	
	#check WL status
	_setAODstate( $tcpar_LoadName, $tcpar_DriverState );
	
	$read_value4 = S_aref2hex(PD_ReadMemoryByName($tcpar_WI_Status));
	S_w2rep("*** Detected variable - $read_value4  ***");
	
	#check status variable of Warning Lamp
	S_teststep_expected("Warning lamp should glow and value of'$tcpar_WI_Status' should be 1", 'check_the_status');			#evaluation 5
	S_teststep_detected("Detected $tcpar_WI_Status value is:$read_value4");
	EVAL_evaluate_value("Evaluating response :",$read_value4,'==',1) unless $main::opt_offline;	
	
	



	S_teststep("Clear the fault memory", 'AUTO_NBR', 'clear_the_fault');			#measurement 6
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep_expected("Fault should not be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	if ($VERDICT =~ /PASS/i){
		S_teststep_detected("Fault should not be Qualified  ");	 	
	}	
	else{		
		 my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_SwVersionWrong_flt' ,'0bxxxxxxx1');
		 S_teststep_detected("Fault should not be Qualified : $detected_fault ");	
	}
	
	
	
	S_teststep("Hard Reset", 'AUTO_NBR');
	PD_ECUreset( ); 
	S_wait_ms('TIMER_ECU_READY');




	S_teststep("Read the fault Recorder", 'AUTO_NBR', 'read_the_fault_B');			#measurement 7
		
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_'."$tcpar_Fault".'_flt' ,'0bxxxx1xx1');
	S_teststep_detected("Fault Qualified : $detected_fault ");
	S_wait_ms(5000);	
		
	PD_ClearFaultMemory();	
					
	
	S_teststep("Read the value of '$tcpar_variable'", 'AUTO_NBR', 'read_the_value_D');			#measurement 8
	$read_value1 = S_aref2hex(PD_ReadMemoryByName($tcpar_variable));
	S_w2rep("*** Detected variable - $read_value1  ***");
	
	S_teststep_expected("Value of '$tcpar_variable' should be 0.", 'read_the_value_D');			#evaluation 8
	S_teststep_detected("Detected $tcpar_variable value is:$read_value1");
	EVAL_evaluate_value("Evaluating response :",$read_value1,'==',0) unless $main::opt_offline;	
	
	
			

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");  


	return 1;
}

sub TC_finalization {
	
	
	_resetAODstate( $tcpar_LoadName, $tcpar_DriverState );
	
	my $write=PD_WriteMemoryByName($tcpar_NVM_Var, ['0x'.'00','23','03','00']);
	S_wait_ms(1000);
	
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );
	
	PD_ReadFaultMemory(); 

	return 1;
}

sub _setAODstate {

	my $device = shift;
	my $state  = shift;

	my $lamp_states_href;
	

	if ( $state =~ 'DriverSwitchedOn' ) {

		S_teststep( "Create fault to set SysWL ON ", 'AUTO_NBR' );
		LC_DisconnectLine('AB2FD');
		S_wait_ms(2000);
		push( @optFaults_Quali,   'rb_sqm_SquibResistanceOpenAB2FD_flt' );
		push( @optFaults_DeQuali, 'rb_sqm_SquibResistanceOpenAB2FD_flt' );
	}
	elsif ( $state =~ 'DriverSwitchedOff' ) {

		S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
	}
	else {

		S_set_error("State $state currently is not supported in this test script ");
	}
		
	
	
	S_teststep( "Read and evaluate lamp state", 'AUTO_NBR' );
	$lamp_states_href = PD_ReadLampStates();
	unless ( $device =~ /AOutCrashOutput/ ) {
		if ( $state =~ 'DriverSwitchedOn' ) {

			S_teststep_expected("Lamp $device should be ON");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );
		}
		else {

			S_teststep_expected("Lamp $device should be OFF");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );
		}
	}
	else {

		S_teststep_expected("Lamp $device should be ON");
		S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
		EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );
	}
	return 1;
}

 sub _resetAODstate {
	
	my $device = shift;
	my $state  = shift;
	my $lamp_states_href;
	
	if ( $state =~ 'DriverSwitchedOn' ) {

		S_teststep( "Remove fault to set SysWL ON ", 'AUTO_NBR' );
		LC_ConnectLine('AB2FD');
		S_wait_ms(2000);
		PD_ClearFaultMemory();
	}
	elsif ( $state =~ 'DriverSwitchedOff' ) {

		S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
		S_teststep_2nd_level( "Read and evaluate lamp state", 'AUTO_NBR' );
		$lamp_states_href = PD_ReadLampStates();
		EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );
	}
	else {

		S_set_error("State $state currently is not supported in this test script ");
	}
		
		
	
	return 1;
}


1;