#### TEST CASE MODULE
package TC_SWV_SWVersionFailure;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWV/TC_SWV_SWVersionFailure.pm 1.1 2020/01/17 13:08:05ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWV_SoftwareVersion> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <0.26> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_DCOM;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWV_SWVersionFailure

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Manipulate contents of the SW version string in NVM using SW labels <SWversionString_NVM_var> or do not flash NVM data..

Power on Reset.

2. Read fault memory.

3. Clear fault memory.

4. Power on Reset.

5. Read fault memory.


I<B<Evaluation>>

1. 

2. Fault 'rb_utsv_SwVersionWrong_flt' should be qualified.

3. Fault 'rb_utsv_SwVersionWrong_flt' should not be present in fault memory.

4.

5. Fault 'rb_utsv_SwVersionWrong_flt' should be qualified.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'SWversionString_NVM_var' => 
	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	purpose = ' To verify that the SW version check failure.'
	SWversionString_NVM_var = @('rb_swv_SwVersionNvmCfg_dfst.CustomerId0_u8', 'rb_swv_SwVersionNvmCfg_dfst.CustomerId1_u8')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SWversionString_NVM_var;

################ global parameter declaration ###################
#add any global variables here
my (%flt_mem_struct);
my $SW_Var;
my $read_var;
my @manipulated_hex_value;
my @original_val;
my $value;
my $re_value=0;
my  $optional_flt = ['rb_sqm_SquibResistanceOpenAB2FD_flt','rb_utsv_SwVersionWrong_flt'];

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SWversionString_NVM_var =  GEN_Read_mandatory_testcase_parameter( 'SWversionString_NVM_var' ,'byref');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	foreach $SW_Var (@$tcpar_SWversionString_NVM_var){
		$value = S_aref2hex(PD_ReadMemoryByName($SW_Var));
		push @original_val , $value;
	}
	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Manipulate contents of the SW version string in NVM using SW labels '$tcpar_SWversionString_NVM_var' or do not flash NVM data..", 'AUTO_NBR');
	foreach $SW_Var (@$tcpar_SWversionString_NVM_var){
		$SW_Var =~ m/_(u\d+)$/i;
		S_w2rep("*** $SW_Var ***","Orange");
		my $read_value = S_aref2hex(PD_ReadMemoryByName($SW_Var));
		S_w2rep("*** Detected variable -$read_value  ***","Orange");
		$re_value = $read_value++;
		S_w2rep("*** Detected variable -$read_value  ***","Green");
		push @manipulated_hex_value , $read_value;

		S_w2rep("*** Detected variable - @manipulated_hex_value  ***","Blue");

	}
	
	my $cnt = 0;	
	foreach $SW_Var (@$tcpar_SWversionString_NVM_var){
		PD_WriteMemoryByName($SW_Var, [$manipulated_hex_value[$cnt++]] );
		S_wait_ms(1000);
	
	}
	
	
	
	S_teststep("Power on Reset.", 'AUTO_NBR');
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );


	
	S_teststep("Read fault memory.", 'AUTO_NBR', 'read_fault_memory_A');			#measurement 1
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_SwVersionWrong_flt' ,'0bxxxx1xx1');
	S_teststep_detected("Fault Qualified : $detected_fault ");
	S_wait_ms(5000);

	
	
	S_teststep("Clear fault memory.", 'AUTO_NBR', 'clear_fault_memory');			#measurement 2
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep_expected("Fault should not be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	if ($VERDICT =~ /PASS/i){
		S_teststep_detected("Fault should not be Qualified  ");	 	
	}	
	else{		
		 my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_SwVersionWrong_flt' ,'0bxxxxxxx1');
		 S_teststep_detected("Fault should not be Qualified : $detected_fault ");	
	}
	


	S_teststep("Power on Reset.", 'AUTO_NBR');
	PD_ECUreset( ); 
	S_wait_ms('TIMER_SIX_SEC');
		

		

	S_teststep("Read fault memory.", 'AUTO_NBR', 'read_fault_memory_B');			#measurement 3
	
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_SwVersionWrong_flt' ,'0bxxxx1xx1');
	S_teststep_detected("Fault Qualified : $detected_fault ");
	S_wait_ms(5000);
	PD_ClearFaultMemory();	

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");  
	

	return 1;
}

sub TC_finalization {

	my $cnt = 0;
	foreach $SW_Var (@$tcpar_SWversionString_NVM_var){
		PD_WriteMemoryByName($SW_Var, [$original_val[$cnt++]] );
		S_wait_ms(1000);
	}
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );
	
	PD_ReadFaultMemory(); 

	return 1;
}


1;