#### TEST CASE MODULE
package TC_SWV_PackageID_and_LayoutID_Read;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWV/TC_SWV_PackageID_and_LayoutID_Read.pm 1.1 2020/01/17 13:08:05ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWV_SoftwareVersion> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <0.26> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWV_PackageID_and_LayoutID_Read

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read the Package ID and Layout ID  using SW labels 

<SWversion_ROM_var> and <SWversion_NVM_var>.


I<B<Evaluation>>

1. Package ID and Layout ID Values read from <SWversion_ROM_var> and <SWversion_NVM_var> should match with expected values  <SWversion_Expval>.

Verify the following components of SW individually for ROM and NVM.

-Package ID 

-Layout ID


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'SWversion_ROM_var' => 
	LIST 'SWversion_NVM_var' => 
	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	purpose = ' To verify that the SW Package ID and Layout ID  stored in NVM and ROM'
	SWversion_ROM_var  =  @('rb_swv_DataPackageProtectedRomCfg_cst.LayoutID_u32','rb_swv_DataPackageProtectedRomCfg_cst.PackageID_u32','rb_swv_DataPackageOverwriteableRomCfg_cst.LayoutID_u32','rb_swv_DataPackageOverwriteableRomCfg_cst.Package_u32')
	
	SWversion_NVM_var  = @('rb_swv_DataPackageProtectedNvmCfg_dfst.LayoutID_u32','rb_swv_DataPackageProtectedNvmCfg_dfst.PackageID_u32','rb_swv_DataPackageOverwriteableNvmCfg_dfst.LayoutID_u32','rb_swv_DataPackageOverwriteableNvmCfg_dfst.Package_u32')
	
	 #both NVM and ROM value should be equal

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_SWversion_ROM_var;
my @tcpar_SWversion_NVM_var;
my @tcpar_SWversion_Expval;

################ global parameter declaration ###################
#add any global variables here
my $ROM_value ;
my $ROM_hex_value;
my $NVM_value;
my $NVM_hex_value;
my $ROM_hex;
my $NVM_hex;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	@tcpar_SWversion_ROM_var =  GEN_Read_mandatory_testcase_parameter( 'SWversion_ROM_var');
	@tcpar_SWversion_NVM_var =  GEN_Read_mandatory_testcase_parameter( 'SWversion_NVM_var');
	@tcpar_SWversion_Expval =  GEN_Read_mandatory_testcase_parameter( 'SWversion_Expval');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Read the Package ID and Layout ID of @tcpar_SWversion_ROM_var  and  @tcpar_SWversion_NVM_var using SW labels ", 'AUTO_NBR', 'read_the_package');			#measurement 1
	foreach  $ROM_value (@tcpar_SWversion_ROM_var ){
		$ROM_hex_value = S_aref2hex(PD_ReadMemoryByName($ROM_value));
		S_w2rep("*** Detected ROM VALUE - $ROM_hex_value  ***","Orange");

	}
	
	foreach $NVM_value(@tcpar_SWversion_NVM_var){
		$NVM_hex_value = S_aref2hex(PD_ReadMemoryByName($NVM_value));
		S_w2rep("*** Detected NVM VALUE - $NVM_hex_value  ***","Orange");
	
	}

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Package ID and Layout ID Values read from '@tcpar_SWversion_ROM_var' should match with expected values  '@tcpar_SWversion_Expval'.", 'read_the_package');			#evaluation 1
	S_teststep_detected("Detected @tcpar_SWversion_ROM_var value is:$ROM_hex_value");
	for(my $i=0;$i<4;$i++)
	{
		EVAL_evaluate_value("Evaluating response for @tcpar_SWversion_ROM_var:",$ROM_hex_value,'==','0x'.$tcpar_SWversion_Expval[$i]) unless $main::opt_offline;	
	}
	for(my $j=0;$j<4;$j++){
		S_teststep_expected("Package ID and Layout ID Values read from '@tcpar_SWversion_NVM_var' should match with expected values  '@tcpar_SWversion_Expval'.", 'read_the_package');			#evaluation 1
		S_teststep_detected("Detected @tcpar_SWversion_NVM_var value is:$NVM_hex_value");
		EVAL_evaluate_value("Evaluating response for @tcpar_SWversion_NVM_var",$NVM_hex_value,'==','0x'.$tcpar_SWversion_Expval[$j]) unless $main::opt_offline;	
	}


	return 1;
}

sub TC_finalization {
		
	S_wait_ms(1000);	
	return 1;
}


1;