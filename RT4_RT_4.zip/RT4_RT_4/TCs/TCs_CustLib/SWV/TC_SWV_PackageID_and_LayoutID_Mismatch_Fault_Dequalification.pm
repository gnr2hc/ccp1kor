#### TEST CASE MODULE
package TC_SWV_PackageID_and_LayoutID_Mismatch_Fault_Dequalification;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: SWV/TC_SWV_PackageID_and_LayoutID_Mismatch_Fault_Dequalification.pm 1.2 2020/01/21 12:13:34ICT Revathi Kaliyamoorthy (RBEI/ESA-PP3) (RKI8COB) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_general;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_can_access;
##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWV_PackageID_and_LayoutID_Mismatch_Fault_Dequalification

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>


I<B<Stimulation and Measurement>>

1.Manipulate the contents of Package ID and Layout ID of NVM to create mismach between ROM and NVM.

<Package_ID_Protected_Var>

<Layout_ID_Protected_Var>

<Package_ID_Overwriteable_Var>

<Layout_ID_Overwriteable_Var>

2.Hard Reset

3.Read the value of <variable>

4.Read the fault Recorder

5.Manipulate the contents of Package ID and Layout ID to <Package_ID_Protected_Var>

<Layout_ID_Protected_Var>

<Package_ID_Overwriteable_Var>

<Layout_ID_Overwriteable_Var>

their original values.

6.Hard Reset

7.Read the fault Recorder

8.Read the value of <variable>

9.Check the status of warning lamp and value of Warning lamp status variable<WI_Status>


I<B<Evaluation>>

3.Value of <variable> should be 0.

4.<Fault> should be qualified.

7.<Fault> should be De-qualified

8.Value of <variable> should be 1.

9.Warning lamp should not glow and value of warrning status variable<WI_Status> should be equal to 0.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'variable' => 
	SCALAR 'Fault' => 
	SCALAR 'Package_ID_Protected_Var' => 
	SCALAR 'Layout_ID_Protected_Var' => 
	SCALAR 'Package_ID_Overwriteable_Var' => 
	SCALAR 'Layout_ID_Overwriteable_Var' => 
	SCALAR 'WI_Status' => 


=head2 PARAMETER EXAMPLES

	purpose = ' To verify that removing mismatch between  SW Package ID and Layout ID  stored in NVM and ROM de-qualifies  fault'
	
	
	variable ='rb_swv_SwCheckResult_bo'
	
	Fault ='SwVersionWrong'
	
	
	Package_ID_Protected_Var ='rb_swv_DataPackageProtectedNvmCfg_dfst.PackageID_u32'
	
	Layout_ID_Protected_Var  ='rb_swv_DataPackageProtectedNvmCfg_dfst.LayoutID_u32'
	
	Package_ID_Overwriteable_Var ='rb_swv_DataPackageOverwriteableNvmCfg_dfst.Package_u32'
	
	Layout_ID_Overwriteable_Var ='rb_swv_DataPackageOverwriteableNvmCfg_dfst.LayoutID_u32'
	
	WI_Status ='rb_wimi_SysWIStatus_aen(0)'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_variable;
my $tcpar_Fault;
my $tcpar_FLTopt_aref ;
my $tcpar_Package_ID_Protected_Var;
my $tcpar_Layout_ID_Protected_Var;
my $tcpar_Package_ID_Overwriteable_Var;
my $tcpar_Layout_ID_Overwriteable_Var;
my $tcpar_WI_Status;
my $tcpar_LoadName;
my $tcpar_DriverState;



################ global parameter declaration ###################
#add any global variables here
my $optional_flt = ['rb_sqm_SquibResistanceOpenAB2FD_flt','rb_utsv_SwVersionWrong_flt'];
my $value1;
my $value2;
my $value3;
my $value4;
my @array2;
my $lamp_states_href;
my $device;
my $state;
my @optFaults_Quali;
my @optFaults_DeQuali;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_variable =  GEN_Read_mandatory_testcase_parameter( 'variable' );
	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_FLTopt_aref        = S_read_optional_testcase_parameter('FLTopt');
	$tcpar_Package_ID_Protected_Var =  GEN_Read_mandatory_testcase_parameter( 'Package_ID_Protected_Var' );
	$tcpar_Layout_ID_Protected_Var =  GEN_Read_mandatory_testcase_parameter( 'Layout_ID_Protected_Var' );
	$tcpar_Package_ID_Overwriteable_Var =  GEN_Read_mandatory_testcase_parameter( 'Package_ID_Overwriteable_Var' );
	$tcpar_Layout_ID_Overwriteable_Var =  GEN_Read_mandatory_testcase_parameter( 'Layout_ID_Overwriteable_Var' );
	$tcpar_WI_Status =  GEN_Read_mandatory_testcase_parameter( 'WI_Status' );
	$tcpar_LoadName = GEN_Read_mandatory_testcase_parameter( 'LoadName' );
    $tcpar_DriverState = GEN_Read_mandatory_testcase_parameter( 'DriverState' );
	

	@optFaults_Quali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );
	@optFaults_DeQuali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	
	$value1 = S_aref2hex(PD_ReadMemoryByName($tcpar_Package_ID_Protected_Var));
	
    $value2 = S_aref2hex(PD_ReadMemoryByName($tcpar_Layout_ID_Protected_Var));
	
	$value3 = S_aref2hex(PD_ReadMemoryByName($tcpar_Package_ID_Overwriteable_Var));

	$value4 = S_aref2hex(PD_ReadMemoryByName($tcpar_Layout_ID_Overwriteable_Var));
	
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Manipulate the contents of Package ID and Layout ID of NVM to create mismach between ROM and NVM.", 'AUTO_NBR');
	
	S_teststep("'$tcpar_Package_ID_Protected_Var'", 'AUTO_NBR');
	
	
	my $read_value1 = S_aref2hex(PD_ReadMemoryByName($tcpar_Package_ID_Protected_Var));
	$read_value1++;
	
	PD_WriteMemoryByName($tcpar_Package_ID_Protected_Var,$read_value1);
	S_wait_ms(1000);
	
	

	S_teststep("'$tcpar_Layout_ID_Protected_Var'", 'AUTO_NBR');
	my $read_value2 = S_aref2hex(PD_ReadMemoryByName($tcpar_Layout_ID_Protected_Var));
	$read_value2++;
	
	PD_WriteMemoryByName($tcpar_Layout_ID_Protected_Var,$read_value2);
	S_wait_ms(1000);
	 
	
	

	S_teststep("'$tcpar_Package_ID_Overwriteable_Var'", 'AUTO_NBR');
	my $read_value3 = S_aref2hex(PD_ReadMemoryByName($tcpar_Package_ID_Overwriteable_Var));
	$read_value3++;

	
	PD_WriteMemoryByName($tcpar_Package_ID_Overwriteable_Var,$read_value3);
	S_wait_ms(1000);
	

	S_teststep("'$tcpar_Layout_ID_Overwriteable_Var'", 'AUTO_NBR');
	my $read_value4 = S_aref2hex(PD_ReadMemoryByName($tcpar_Layout_ID_Overwriteable_Var));
	$read_value4++;

	
	PD_WriteMemoryByName($tcpar_Layout_ID_Overwriteable_Var,$read_value3);
	S_wait_ms(1000);
	

	S_teststep("Hard Reset", 'AUTO_NBR');
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );

	S_teststep("Read the value of '$tcpar_variable'", 'AUTO_NBR');			#measurement 1
	my $read_value5 = S_aref2hex(PD_ReadMemoryByName($tcpar_variable));
	S_w2rep("*** Detected variable - $read_value5  ***");
	
	S_teststep_expected("Value of '$tcpar_variable' should be 0.");			#evaluation 3
	S_teststep_detected("Detected $tcpar_variable value is:$read_value5");
	EVAL_evaluate_value("Evaluating response: ",$read_value5,'==',0) unless $main::opt_offline;	


	S_teststep("Read the fault Recorder", 'AUTO_NBR');			#measurement 2
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_'."$tcpar_Fault".'_flt' ,'0bxxxx1xx1');
	S_teststep_detected("Fault Qualified : $detected_fault ");
	S_wait_ms(5000);	
	

	S_teststep("Manipulate the contents of Package ID and Layout ID to '$tcpar_Package_ID_Protected_Var'", 'AUTO_NBR');
	
	PD_WriteMemoryByName($tcpar_Package_ID_Protected_Var, ['0x'.'00','23','03','00']);
	S_wait_ms(1000);
	
	
	
	S_teststep("'$tcpar_Layout_ID_Protected_Var'", 'AUTO_NBR');


	PD_WriteMemoryByName($tcpar_Layout_ID_Protected_Var, ['0x'.'00','23','03','00']);
	S_wait_ms(1000);
	
	
	

	S_teststep("'$tcpar_Package_ID_Overwriteable_Var'", 'AUTO_NBR');
	
	PD_WriteMemoryByName($tcpar_Package_ID_Overwriteable_Var, ['0x'.'00','23','03','00']);

	S_wait_ms(1000);
	

	S_teststep("'$tcpar_Layout_ID_Overwriteable_Var'", 'AUTO_NBR');
	
	PD_WriteMemoryByName($tcpar_Layout_ID_Overwriteable_Var, ['0x'.'00','23','03','00']);

	S_wait_ms(1000);
	
	

	S_teststep("their original values.", 'AUTO_NBR');

	S_teststep("Hard Reset", 'AUTO_NBR');
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );
	

	
	S_teststep("Check the status of warning lamp and value of Warning lamp status variable'$tcpar_WI_Status'", 'AUTO_NBR', 'check_the_status');			#measurement 5
	
	CA_trace_start();
	
	_setAODstate( $tcpar_LoadName, $tcpar_DriverState );
	
	
	my $read_value6 = S_aref2hex(PD_ReadMemoryByName($tcpar_WI_Status));
	S_w2rep("*** Detected variable - $read_value6  ***");
	
	#check value of Warning Lamp
	S_teststep_expected("Warning lamp should NOT glow and value of'$tcpar_WI_Status' should be 0");			#evaluation 5
	S_teststep_detected("Detected $tcpar_WI_Status value is:$read_value6");
	EVAL_evaluate_value("Evaluating response :",$read_value6,'==',0) unless $main::opt_offline;	
	

	S_teststep("Read the fault Recorder", 'AUTO_NBR');			#measurement 3
	
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep_expected("Fault should not be qualified");
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should not be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	if ($VERDICT =~ /PASS/i){
		S_teststep_detected("Fault should not be Qualified  ");	 	
	}	
	else{		
		 my $detected_fault = PD_check_fault_status($flt_mem_struct, 'rb_utsv_SwVersionWrong_flt' ,'0bxxxxxxx1');
		 S_teststep_detected("Fault should not be Qualified : $detected_fault ");	
	}
	
	
	

	S_teststep("Read the value of '$tcpar_variable'", 'AUTO_NBR');			#measurement 4
	my $read_value5 = S_aref2hex(PD_ReadMemoryByName($tcpar_variable));
	S_w2rep("*** Detected variable - $read_value5  ***");
	
	S_teststep_expected("Value of '$tcpar_variable' should be 1.");			#evaluation 3
	S_teststep_detected("Detected $tcpar_variable value is:$read_value5");
	EVAL_evaluate_value("Evaluating response: ",$read_value5,'==',1) unless $main::opt_offline;	

	
	
	

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");  
	


	return 1;
}

sub TC_finalization {

	_resetAODstate( $tcpar_LoadName, $tcpar_DriverState );

	PD_ClearFaultMemory();
	
	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );
	
	PD_ReadFaultMemory(); 


	return 1;
}

sub _setAODstate {

	my $device = shift;
	my $state  = shift;

	my $lamp_states_href;
	

	if ( $state =~ 'DriverSwitchedOn' ) {

		S_teststep( "Create fault to set SysWL ON ", 'AUTO_NBR' );
		LC_DisconnectLine('AB2FD');
		S_wait_ms(2000);
		push( @optFaults_Quali,   'rb_sqm_SquibResistanceOpenAB2FD_flt' );
		push( @optFaults_DeQuali, 'rb_sqm_SquibResistanceOpenAB2FD_flt' );
	}
	elsif ( $state =~ 'DriverSwitchedOff' ) {

		S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
	}
	else {

		S_set_error("State $state currently is not supported in this test script ");
	}
		
	S_user_action('check');
	
	S_teststep( "Read and evaluate lamp state", 'AUTO_NBR' );
	$lamp_states_href = PD_ReadLampStates();
	 unless ( $device =~ /AOutCrashOutput/ ) {
		if ( $state =~ 'DriverSwitchedOff' ) {

			S_teststep_expected("Lamp $device should be OFF");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );

			
		}
		else {

			S_teststep_expected("Lamp $device should be ON");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );

		}
	}
	else {

		S_teststep_expected("Lamp $device should be OFF");
		S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
		EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );
	}
	return 1;
}

 sub _resetAODstate {
	
	my $device = shift;
	my $state  = shift;
	my $lamp_states_href;
	
	if ( $state =~ 'DriverSwitchedOff' ) {

		S_teststep( "Remove fault to set SysWL OFF ", 'AUTO_NBR' );
		LC_ConnectLine('AB2FD');
		S_wait_ms(2000);
		PD_ClearFaultMemory();
	}
	elsif ( $state =~ 'DriverSwitchedOn' ) {

		S_teststep( "WL should be ON as expected fault free setup, nothing to be done", 'AUTO_NBR' );
		S_teststep_2nd_level( "Read and evaluate lamp state", 'AUTO_NBR' );
		$lamp_states_href = PD_ReadLampStates();
		EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );
	}
	else {

		S_set_error("State $state currently is not supported in this test script ");
	}
		
		
	
	return 1;
}



1;