#### TEST CASE MODULE
package TC_AOD_PlantMode2_WLShortToGndFault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: AOD/TC_AOD_PlantMode2_WLShortToGndFault.pm 1.2 2019/08/02 13:59:24ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_evaluation;
use LIFT_FaultMemory;
use LIFT_labcar;
##################################

our $PURPOSE = "To verify the behaviour of Short To Ground of Warning lamp when the system is in plant mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_PlantMode2_WLShortToGndFault

=head1 PURPOSE

To verify the behaviour of Short To Ground of Warning lamp when the system is in plant mode

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter in the Plant mode 2

2. Create ShortToGnd condition on Warning lamp. 

3. Check Fault recorder

Note: The above functionality will work only if the Warning lamp is connected to LowSideDriver


I<B<Evaluation>>

1. 

2. 

3. <Fault> is created


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Fault' => 
	SCALAR 'Purpose' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the behaviour of Short To Ground of Warning lamp when the system is in plant mode '
	Fault = 'NONE'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Fault;
my $tcpar_Warning_lamp;

################ global parameter declaration ###################
#add any global variables here
my $plantmode2_set  = 0b00000010;
my $plantmode_clear = 0b00000000;
my $faultMemory_obj;
my $expectedFaults_href;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose      = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Fault        = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_Warning_lamp = S_read_mandatory_testcase_parameter('Warning_lamp');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Enter in the Plant mode 2", 'AUTO_NBR' );

	S_teststep_2nd_level( "Write 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)'-> $plantmode2_set", 'AUTO_NBR' );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode2_set] );

	S_teststep_2nd_level( "Do SW reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active_A' );
	my $plantmode_value_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	S_teststep_expected( "Plant mode 2 == $plantmode2_set", 'mode_active_A' );
	S_teststep_detected( "Plant mode 2 is $$plantmode_value_aref[0]", 'mode_active_A' );
	EVAL_evaluate_value( "Plant mode 2 active", $$plantmode_value_aref[0], '==', $plantmode2_set );

	S_teststep_2nd_level( "Check if WL is ON as plant mode is actived", 'AUTO_NBR', 'mode_active_B' );
	my $lamp_state_href = PD_ReadLampStates();
	S_teststep_expected( "WL == On" . "\n", 'mode_active_B' );
	S_teststep_detected( "WL is $lamp_state_href->{'System Warning Lamp'}" . "\n", 'mode_active_B' );
	EVAL_evaluate_string( "WL active", 'On', $lamp_state_href->{'System Warning Lamp'} );

	S_teststep( "Create ShortToGnd condition on $tcpar_Warning_lamp ", 'AUTO_NBR' );
	LC_ShortLines( [ $tcpar_Warning_lamp . '+', 'B-' ] );
	S_wait_ms( 6000, "wait until fault is qualified" );

	S_teststep( "Check Fault recorder", 'AUTO_NBR', 'check_fault_recorder' );    #measurement 1
	$faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	my $entry_obj_aref = $faultMemory_obj->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
	my @faultNamesInMemory_Quali = ();
	foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
		push( @faultNamesInMemory_Quali, $fault_entry_obj->FaultName );
	}
	my $faultPresence = $faultMemory_obj->check_fault_presence('rb_aod_AOutSysWarningIndicatorShort2Gnd_flt');

	S_teststep_detected( "Detected fault qualify in memory:", 'check_fault_recorder' );
	foreach my $fault (@faultNamesInMemory_Quali) {
		S_teststep_detected("$fault is in the fault recorder");
	}

	if ( $tcpar_Fault =~ 'NONE' ) {

		$expectedFaults_href = {};
		S_teststep_expected( "ShortToGnd fault of $tcpar_Warning_lamp should not be presented", 'check_fault_recorder' );    #evaluation 1
		EVAL_evaluate_string( "ShortToGnd fault of $tcpar_Warning_lamp present in fault memory", 'not_present', $faultPresence );
	}
	else {

		$expectedFaults_href->{$tcpar_Fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };
		S_teststep_expected( "'$tcpar_Fault' is created", 'check_fault_recorder' );                                          #evaluation 1
		$faultMemory_obj->evaluate_specific_faults(
			$expectedFaults_href,                                                                                            # expected faults
			'check_fault_recorder'                                                                                           # eval keyword
		);
	}

	return 1;
}

sub TC_finalization {

	S_teststep( "Undo ShortToGnd condition on $tcpar_Warning_lamp ", 'AUTO_NBR' );
	LC_UndoShortLines();

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Write 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)' -> $plantmode_clear", 'AUTO_NBR' );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );

	S_teststep_2nd_level( "Reset ECU and wait for ECU ready", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep_2nd_level( "Read rb_sycg_ActivePlantModes_au8(0) to check whether plantmode is deactived", 'AUTO_NBR' );
	my $plantmode_data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$plantmode_data_aref[0], '==', $plantmode_clear );

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

1;
