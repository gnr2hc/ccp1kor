#### TEST CASE MODULE
package TC_AOD_Status_In_Init;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: AOD/TC_AOD_Status_In_Init.pm 1.3 2020/04/10 18:55:33ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
##################################

our $PURPOSE = "To verify the status of AOD in Init phase";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_Status_In_Init

=head1 PURPOSE

To verify the status of AOD in Init phase

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. State of <Aoutname> in init phase.


I<B<Evaluation>>

1. State is set to <Status>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'Status' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the status of AOD in Init pahse'
	Aoutname = '<Test Heading 2>'
	LoadName = 'NONE'
	Status = 'Off'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_LoadName;
my $tcpar_Status;

################ global parameter declaration ###################
#add any global variables here
my $lamp_states_href;
my $CRO_status;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose  = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_LoadName = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_Status   = S_read_mandatory_testcase_parameter('Status');

	return 1;
}

sub TC_initialization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Turn off ECU and turn on again to check in init phase", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms("TIMER_ECU_OFF");
	LC_ECU_On();
	S_wait_ms(200);

	S_teststep( "State of '$tcpar_Aoutname' in init phase.", 'AUTO_NBR', 'state_of_aoutname' );    #measurement 1
	if ( $tcpar_LoadName =~ /AOutCrashOutput/ ) {
		unless ( defined &FuncLib_Project_DEVICE::DEVICE_getCROStatus ) {
			S_w2rep( "Device '$tcpar_LoadName' is controlled by PWM, cannot read ON or OFF", 'blue' );
		}
		else {
			$CRO_status = FuncLib_Project_DEVICE::DEVICE_getCROStatus();
		}
	}
	else {
		$lamp_states_href = PD_ReadLampStates();
	}

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	unless ( $tcpar_LoadName =~ /AOutCrashOutput/ ) {

		S_teststep_expected( "State is set to '$tcpar_Status'", 'state_of_aoutname' );    #evaluation 1
		S_teststep_detected( "Detected state of '$tcpar_LoadName' is $lamp_states_href->{$tcpar_LoadName}", 'state_of_aoutname' );
		unless ( $tcpar_LoadName =~ /AOutSysWarningIndicator/ ) {
			EVAL_evaluate_string( "State of '$tcpar_LoadName'", $tcpar_Status, $lamp_states_href->{$tcpar_LoadName} );
		}
		else {
			EVAL_evaluate_string( "State of '$tcpar_LoadName'", $tcpar_Status, $lamp_states_href->{'System Warning Lamp'} );
		}
	}
	else {
		unless ( defined &FuncLib_Project_DEVICE::DEVICE_getCROStatus ) {
			S_w2rep( "Device '$tcpar_LoadName' is controlled by PWM, cannot read ON or OFF", 'blue' );
		}
		else {
			EVAL_evaluate_string( "State of '$tcpar_LoadName'", $tcpar_Status, $CRO_status );
		}
	}

	return 1;
}

sub TC_finalization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

1;
