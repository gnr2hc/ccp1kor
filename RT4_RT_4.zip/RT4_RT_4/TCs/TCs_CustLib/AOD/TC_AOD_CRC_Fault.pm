#### TEST CASE MODULE
package TC_AOD_CRC_Fault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: AOD/TC_AOD_CRC_Fault.pm 1.2 2019/07/22 15:24:12ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_labcar;
use LIFT_FaultMemory;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_spi_access;
##################################

our $PURPOSE = "To verify when the CRC fault is present then none of the short circuit fault will be qualified";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_CRC_Fault

=head1 PURPOSE

To verify when the CRC fault is present then none of the short circuit fault will be qualified

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create the CRC fault for <Messages>

2. Create Short Circut fault on <LoadName>  of <DriverType>

3. Check Fault recorder


I<B<Evaluation>>

1. 

2. 

3. No Fault is created


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'DriverType' => 
	SCALAR 'Messages' => 
	SCALAR 'Node' => 
	SCALAR 'Purpose' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify when the CRC fault is present then none of the short circuit fault will be qualified'
	LoadName = 'NONE'
	DriverType = 'NONE'
	Messages = 'AIO1_Status'
	Node = 'CG904_M'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_LoadName;
my $tcpar_DriverType;
my $tcpar_Messages;
my $tcpar_Node;
my $tcpar_FaultCondition;
my $tcpar_Aout_LC_device_map;
################ global parameter declaration ###################
#add any global variables here
my $labcar_device;
my $faultMemory_obj;
my $expectedFaults_href = {};
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose            = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_LoadName           = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_DriverType         = S_read_mandatory_testcase_parameter('DriverType');
	$tcpar_Messages           = S_read_mandatory_testcase_parameter('Messages');
	$tcpar_Node               = S_read_mandatory_testcase_parameter('Node');
	$tcpar_FaultCondition     = S_read_mandatory_testcase_parameter('FaultCondition');
	$tcpar_Aout_LC_device_map = S_read_mandatory_testcase_parameter('Aout_LC_device_map');

	$labcar_device = $tcpar_Aout_LC_device_map->{$tcpar_LoadName};

	return 1;
}

sub TC_initialization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Create the CRC fault for '$tcpar_Messages'", 'AUTO_NBR' );
	S_teststep_2nd_level( "Load invalid CRC value", 'AUTO_NBR' );
	SPI_load_signal_manipulation(
				'Node'        => $tcpar_Node,
				'Command'     => $tcpar_Messages,
				'Signal'      => 'CRC',
				'SignalValue' => 0,
			);

	S_teststep_2nd_level( "Start SPI manipulate", 'AUTO_NBR' );
	SPI_start_manipulation();
	S_wait_ms(2000);

	S_teststep( "Create Short Circut $tcpar_FaultCondition on '$tcpar_LoadName'  of '$tcpar_DriverType'", 'AUTO_NBR' );
	_createFaultCondition($tcpar_FaultCondition);
	S_wait_ms(8000);

	S_teststep( "Check Fault recorder", 'AUTO_NBR', 'check_fault_recorder' );    #measurement 1
	$faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	my $entry_obj_aref = $faultMemory_obj->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
	my @faultNamesInMemory_Quali = ();
	foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
		push( @faultNamesInMemory_Quali, $fault_entry_obj->FaultName );
	}
	S_teststep_expected( "No Fault is created", 'check_fault_recorder' );    #evaluation 1
	S_teststep_detected( "Detected fault qualify in memory:", 'check_fault_recorder' );
	foreach my $fault (@faultNamesInMemory_Quali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj->evaluate_faults(
		$expectedFaults_href,                                                # expected faults
		'check_fault_recorder'                                               # eval keyword
	);

	return 1;
}

sub TC_finalization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}
	S_teststep( "Remove Short Circut Condition", 'AUTO_NBR' );
	_removeFaultCondition($tcpar_FaultCondition);
	S_wait_ms(8000);

	S_teststep( "Stop SPI Manipulate", 'AUTO_NBR' );
	SPI_stop_manipulation();
	S_wait_ms(2000);

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

sub _createFaultCondition {

	my $faultcondition = shift;
	if ( $faultcondition =~ 'ShortToGND' ) {

		S_w2rep( "Short line $labcar_device+ and B-", 'blue' );
		LC_ShortLines( [ $labcar_device . '+', 'B-' ] );
	}
	elsif ( $faultcondition =~ 'ShortToVbat' ) {

		S_w2rep( "Short line $labcar_device+ and B+", 'blue' );
		LC_ShortLines( [ $labcar_device . '+', 'B+' ] );
	}
	else {

		S_set_error("Fault condition $faultcondition is not supported, only support for 'ShortToGND', 'ShortToVbat'");
	}
	return 1;
}

sub _removeFaultCondition {

	my $faultcondition = shift;
	if ( $faultcondition =~ 'ShortToGND' ) {

		S_w2rep( "Undo short line $labcar_device+ and B-", 'blue' );
		LC_UndoShortLines();
	}
	elsif ( $faultcondition =~ 'ShortToVbat' ) {

		S_w2rep( "Undo short line $labcar_device+ and B+", 'blue' );
		LC_UndoShortLines();
	}
	else {

		S_set_error("Fault condition $faultcondition is not supported, only support for 'ShortToGND', 'ShortToVbat'");
	}

	return 1;
}
1;
