#### TEST CASE MODULE
package TC_AOD_Configuration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER =
q$Header: AOD/TC_AOD_Configuration.pm 1.1 2019/07/23 17:20:24ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
#include further modules here
use LIFT_PD;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_labcar;
use FuncLib_SYC_INTERFACE; #as CA do not include this in INCLUDES_Project
##################################

our $PURPOSE =  "To verify the enabling and disabling of configuration of AO ports";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_Configuration

=head1 PURPOSE

To verify the enabling and disabling of configuration of AO ports

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault

<LoadName> should be configured.


I<B<Stimulation and Measurement>>

1. Verify configuration of <LoadName> connected to <Aoutname>

2. Read fault memory.

3. Deconfigure <LoadName> and reset the ECU.

4. Verify deconfiguration of <LoadName>.

5. Read fault memory.

6. Configure <LoadName> and reset the ECU.

7. Verify configuration of <LoadName>.

8. Read fault memory.

Note: The HW design limitation and as per requirement SRS_AOD_359, 

Due to an internal pull-up resistor, system ASIC LIN interface has several limitations which affect the following fault detection:

Open line fault detection

Unexpected device fault detection (device not configured but equipped)

The above faults cannot be detectable. 

Ref Req: AB12_SYDS_AO_185

                AB12_DEV_7


I<B<Evaluation>>

1. <LoadName> is configured.

2. Fault memory is empty.

3. 

4. <LoadName> is deconfigured.

5. Unexpected fault <Fault> is qualified.

6. 

7. <LoadName> should be configured.

8. <Fault> is dequalified.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'Fault' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' =>


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the enabling and disabling of configuration of AO ports'
	Aoutname = '<Test Heading 2>'
	LoadName = 'AOutSysWarningIndicator'
	Fault = 'rb_wim_UnexpectedSysWIFault_flt'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_LoadName;
my $tcpar_Fault;
my $tcpar_Aout_SYC_device_map;
################ global parameter declaration ###################
#add any global variables here
my ( $present_init,        $monitor_init,        $config_init );
my ( $present_afer_deconf, $monitor_afer_deconf, $config_afer_deconf );
my ( $present_afer_reconf, $monitor_afer_reconf, $config_afer_reconf );
my ( $result,              $configured );
my $conf_states_map = { 'yes' => 1, 'no' => 0, 'N/A' => 0 };
my $SYC_scip_device;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose  = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_LoadName = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_Fault    = S_read_optional_testcase_parameter('Fault');
	$tcpar_Aout_SYC_device_map = S_read_mandatory_testcase_parameter('Aout_SYC_device_map');
	
	$SYC_scip_device = $tcpar_Aout_SYC_device_map->{$tcpar_LoadName};

	return 1;
}

sub TC_initialization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Check configuration of '$tcpar_LoadName' compare with SYC.", 'AUTO_NBR', 'verify_configuration' );
	( $result, $configured ) = SYC_AnalogueOutput_get_Configured($SYC_scip_device);
	( $present_init, $monitor_init, $config_init ) = PD_get_device_config($tcpar_LoadName);

	S_teststep_expected( "Follow SYC, configuration of '$tcpar_LoadName' is '$configured'.", 'verify_configuration' );
	S_teststep_detected( "Config bit status '$tcpar_LoadName' in SW is '$config_init'.", 'verify_configuration' );
	EVAL_evaluate_value( "Config bit status $tcpar_LoadName", $config_init, '==', $conf_states_map->{$configured} );

	return 1;
}

sub TC_stimulation_and_measurement {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	unless ( $config_init == 1 ) {
		S_teststep( "Verify configuration of '$tcpar_LoadName' connected to '$tcpar_Aoutname'", 'AUTO_NBR', 'verify_configuration_of_A' );    #measurement 1
		S_w2rep( "$tcpar_LoadName is not configured in SW, no testing will be performed. \n", 'blue' );
	}
	else {
		S_teststep( "Verify configuration of '$tcpar_LoadName' connected to '$tcpar_Aoutname'", 'AUTO_NBR', 'verify_configuration_of_A' );    #measurement 1
		S_w2rep( "$tcpar_LoadName is configured in SW, evaluation had been done in Initialization. \n", 'blue' );

		S_teststep( "Read fault memory.", 'AUTO_NBR', 'read_fault_memory_A' );    #measurement 2
		my $faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');
		my $entry_obj_aref  = $faultMemory_obj->get_faults_with_properties(
			{ 'DecodedStatus' => { 'ConfirmedDTC' => 1 } } );
		my @faultNamesInMemory = ();
		foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
			push( @faultNamesInMemory, $fault_entry_obj->FaultName );
		}
		my $expectedFaults_Init_href = {};

		S_teststep_expected( "Fault memory is empty.", 'read_fault_memory_A' );    #evaluation 2
		S_teststep_detected( "Detected fault in memory:", 'read_fault_memory_A' );
		foreach my $fault (@faultNamesInMemory) {
			S_teststep_detected("$fault is in the fault recorder");
		}
		$faultMemory_obj->evaluate_faults(
			$expectedFaults_Init_href,    # expected faults
			'read_fault_memory_A'         # eval keyword
		);
		S_wait_ms(2000); #wait for 2s to avoid PD error

		S_teststep( "Deconfigure '$tcpar_LoadName' and reset the ECU.", 'AUTO_NBR' );
		PD_Device_configuration( 'clear', [$tcpar_LoadName] );
		S_wait_ms(2000); #wait for 2s to avoid PD error

		S_teststep( "Verify deconfiguration of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_deconfiguration_of' );    #measurement 3
		( $present_afer_deconf, $monitor_afer_deconf, $config_afer_deconf ) = PD_get_device_config($tcpar_LoadName);

		S_teststep_expected( "'$tcpar_LoadName' is deconfigured.", 'verify_deconfiguration_of' );                #evaluation 3
		S_teststep_detected( "Configuration status of $tcpar_LoadName is '$config_afer_deconf'", 'verify_deconfiguration_of' );
		EVAL_evaluate_value( "Configuration status of $tcpar_LoadName", $config_afer_deconf, '==', $conf_states_map->{'no'} );

		S_teststep( "Read fault memory.", 'AUTO_NBR', 'read_fault_memory_B' );                                               #measurement 4
		my $faultMemory_obj1 = LIFT_FaultMemory->read_fault_memory('Primary');
		my $entry_obj1_aref  = $faultMemory_obj1->get_faults_with_properties(
			{ 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
		my @faultNamesInMemory_after_deconf = ();
		foreach my $fault_entry_obj ( @{$entry_obj1_aref} ) {
			push( @faultNamesInMemory_after_deconf,
				$fault_entry_obj->FaultName );
		}
		my $expectedFaults_After_deconf_href = {};
		if (defined $tcpar_Fault) {
			$expectedFaults_After_deconf_href = {
				'mandatory' => {
					$tcpar_Fault => {
						'DecodedStatus' => {
							'ConfirmedDTC' => 1,
							'TestFailed'   => 1,
						},
					},
				},
			};
		}

		S_teststep_expected( "Unexpected fault '$tcpar_Fault' is qualified.", 'read_fault_memory_B' );    #evaluation 4
		S_teststep_detected( "Detected fault qualify in memory:", 'read_fault_memory_B' );
		foreach my $fault (@faultNamesInMemory_after_deconf) {
			S_teststep_detected("$fault is in the fault recorder");
		}
		$faultMemory_obj1->evaluate_faults(
			$expectedFaults_After_deconf_href,    # expected faults
			'read_fault_memory_B'                 # eval keyword
		);
		S_wait_ms(2000); #wait for 2s to avoid PD error

		S_teststep( "Configure '$tcpar_LoadName' and reset the ECU.", 'AUTO_NBR' );
		PD_Device_configuration( 'set', [$tcpar_LoadName] );
		S_wait_ms(2000); #wait for 2s to avoid PD error

		S_teststep( "Verify configuration of '$tcpar_LoadName'.", 'AUTO_NBR', 'verify_configuration_of_B' );    #measurement 5
		( $present_afer_reconf, $monitor_afer_reconf, $config_afer_reconf ) = PD_get_device_config($tcpar_LoadName);

		S_teststep_expected( "'$tcpar_LoadName' should be configured.", 'verify_configuration_of_B' );                #evaluation 5
		S_teststep_detected( "Configuration status of $tcpar_LoadName is '$config_afer_reconf'", 'verify_configuration_of_B'
		);
		EVAL_evaluate_value( "Configuration status of $tcpar_LoadName", $config_afer_reconf, '==', $conf_states_map->{'yes'} );

		S_teststep( "Read fault memory.", 'AUTO_NBR', 'read_fault_memory_C' );                                               #measurement 6
		my $faultMemory_obj2 = LIFT_FaultMemory->read_fault_memory('Primary');
		my $entry_obj2_aref  = $faultMemory_obj2->get_faults_with_properties(
			{ 'DecodedStatus' => { 'ConfirmedDTC' => 1 } } );
		my @faultNamesInMemory_after_reconf = ();
		foreach my $fault_entry_obj ( @{$entry_obj2_aref} ) {
			push( @faultNamesInMemory_after_reconf,
				$fault_entry_obj->FaultName );
		}
		my $expectedFaults_After_reconf_href = {};
		if (defined $tcpar_Fault) {
			$expectedFaults_After_reconf_href = {
				'mandatory' => {
					$tcpar_Fault => {
						'DecodedStatus' => {
							'ConfirmedDTC' => 1,
							'TestFailed'   => 0,
						},
					},
				},
			};
		}
		S_teststep_expected( "'$tcpar_Fault' is dequalified.", 'read_fault_memory_C' );    #evaluation 6
		S_teststep_detected( "Below fault are in fault memory:", 'read_fault_memory_C' );
		foreach my $fault (@faultNamesInMemory_after_reconf) {
			S_teststep_detected("$fault is in the fault recorder");
		}
		$faultMemory_obj2->evaluate_faults(
			$expectedFaults_After_reconf_href,    # expected faults
			'read_fault_memory_C'                 # eval keyword
		);
		S_wait_ms(2000); #wait for 2s to avoid PD error

	}

	return 1;
}

sub TC_evaluation {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_w2rep( "All evaluation had been done in stimulation and measurement \n", 'blue' );

	return 1;
}

sub TC_finalization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

1;
