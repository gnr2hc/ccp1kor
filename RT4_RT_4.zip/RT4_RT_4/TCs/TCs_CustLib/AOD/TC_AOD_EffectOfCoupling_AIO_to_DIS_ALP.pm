#### TEST CASE MODULE
package TC_AOD_EffectOfCoupling_AIO_to_DIS_ALP;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: AOD/TC_AOD_EffectOfCoupling_AIO_to_DIS_ALP.pm 1.1 2019/08/02 14:43:49ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_spi_access;
use LIFT_FaultMemory;

#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_EffectOfCoupling_AIO_to_DIS_ALP

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Observe the <WL> connected <AIO>

2. Create condition to disable the DIS_ALP

ex : WD fault

Note : Creating this WD fault, should not effect the WL state.

3. Observe the <WL> connected <AIO>


I<B<Evaluation>>

1. Lamp status should be <Initial_WL_State>

2.

3. Lamp status should be <WL_State>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'WL' => 
	SCALAR 'Purpose' => 
	SCALAR 'AIO' => 
	SCALAR 'Initial_WL_State' => 
	SCALAR 'WL_State' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the effect of coupling of ASIC AIO1 and/or AIO2 to DIS_ALP' 
	
	AIO = '<Test Heading 2>'
	Initial_WL_State = 'OFF'
	WL_State = 'ON'
	WL = 'AWL'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_AIO;
my $tcpar_Initial_WL_State;
my $tcpar_WD_Fault;
my $tcpar_WL_State;
my $tcpar_WL;

################ global parameter declaration ###################
#add any global variables here
my $lamp_states_href;
my $lamp_states_init_href;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose          = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_AIO              = S_read_mandatory_testcase_parameter('AIO');
	$tcpar_Initial_WL_State = S_read_mandatory_testcase_parameter('Initial_WL_State');
	$tcpar_WD_Fault         = S_read_mandatory_testcase_parameter('WD_Fault');
	$tcpar_WL_State         = S_read_mandatory_testcase_parameter('WL_State');
	$tcpar_WL               = S_read_mandatory_testcase_parameter('WL');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Observe the '$tcpar_WL' connected '$tcpar_AIO'", 'AUTO_NBR', 'observe_the_wl_A' );    #measurement 1
	$lamp_states_init_href = PD_ReadLampStates();

	S_teststep( "Create $tcpar_WD_Fault condition to disable the DIS_ALP", 'AUTO_NBR' );
	my $device         = FM_fetchExtendedFaultInfo( $tcpar_WD_Fault, 'Device' );
	my $SpiSignal      = FM_fetchExtendedFaultInfo( $tcpar_WD_Fault, 'SpiSignal' );
	my $SpiCommand     = FM_fetchExtendedFaultInfo( $tcpar_WD_Fault, 'SpiCommand' );
	my $SpiSignalError = FM_fetchExtendedFaultInfo( $tcpar_WD_Fault, 'SpiSignalError' );

	S_w2rep("Load SPI Signal Error ($SpiSignalError) on signal $device :: $SpiCommand :: $SpiSignal \n");
	SPI_load_signal_manipulation(
		'Node'        => $device,
		'Command'     => $SpiCommand,
		'Signal'      => $SpiSignal,
		'SignalValue' => $SpiSignalError,
	);

	S_teststep_2nd_level( "Start SPI manipulation on required signal(s)", 'AUTO_NBR' );
	SPI_start_manipulation();
	S_wait_ms(2000);

	S_teststep_2nd_level( "Read and evaluate for fault $tcpar_WD_Fault", 'AUTO_NBR', 'read_fault_recorder_A' );
	my $faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	my $entry_obj_aref = $faultMemory_obj->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
	my @faultNamesInMemory_Quali = ();
	foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
		push( @faultNamesInMemory_Quali, $fault_entry_obj->FaultName );
	}
	my $expectedFaults_Quali_href->{'mandatory'}->{$tcpar_WD_Fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };

	S_teststep_expected( "'$tcpar_WD_Fault' should be qualified.", 'read_fault_recorder_A' );
	S_teststep_detected( "Detected fault qualify in memory:", 'read_fault_recorder_A' );
	foreach my $fault (@faultNamesInMemory_Quali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj->evaluate_faults(
		$expectedFaults_Quali_href,    # expected faults
		'read_fault_recorder_A'        # eval keyword
	);

	S_teststep( "Observe the '$tcpar_WL' connected '$tcpar_AIO'", 'AUTO_NBR', 'observe_the_wl_B' );    #measurement 2
	$lamp_states_href = PD_ReadLampStates();

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Lamp status should be '$tcpar_Initial_WL_State'", 'observe_the_wl_A' );      #evaluation 1
	S_teststep_detected( "Detected Initial state of '$tcpar_WL' is $lamp_states_init_href->{$tcpar_WL}", 'observe_the_wl_A' );
	EVAL_evaluate_string( "State of '$tcpar_WL'", $tcpar_Initial_WL_State, $lamp_states_init_href->{$tcpar_WL} );

	S_teststep_expected( "Lamp status should be '$tcpar_WL_State'", 'observe_the_wl_B' );              #evaluation 2
	S_teststep_detected( "Detected Initial state of '$tcpar_WL' is $lamp_states_href->{$tcpar_WL}", 'observe_the_wl_B' );
	EVAL_evaluate_string( "State of '$tcpar_WL'", $tcpar_WL_State, $lamp_states_href->{$tcpar_WL} );

	return 1;
}

sub TC_finalization {

	S_teststep( "Remove fault", 'AUTO_NBR' );
	S_teststep_2nd_level( "Stop SPI manipulation", 'AUTO_NBR' );
	SPI_stop_manipulation();
	S_wait_ms(2000);

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

1;
