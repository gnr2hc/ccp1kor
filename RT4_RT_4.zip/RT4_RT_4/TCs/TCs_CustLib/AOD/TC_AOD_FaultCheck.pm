#### TEST CASE MODULE
package TC_AOD_FaultCheck;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: AOD/TC_AOD_FaultCheck.pm 1.6 2020/04/10 18:54:51ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_labcar;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_crash_simulation;
use FuncLib_SYC_INTERFACE;    #as CA do not include this in INCLUDES_Project
use feature qw(switch);
##################################

our $PURPOSE = "To verify the Aout fault handling under different test conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_FaultCheck

=head1 PURPOSE
                 
To verify the Aout fault handling under different test conditions'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create test condition <TestCondition>.

2. Create <FaultCondition>. 

3. Wait for <QualiTime>.

4. Read fault recorder.

5. Remove <FaultCondition>.

6. Wait for <DequaliTime>.

7. Read fault recorder.

Note : <FaultCondition> is optional test.


I<B<Evaluation>>

1. 

2. 

3.

4. <Fault> should be qualified.

5. 

6.

7. <Fault> should be dequalified.

Note : 

the following factors need to be considered during evaluation the fault recorder data in steps 3 and 6.

1. No shortage fault detection possible when <TestCondition> is 'VZPLOW'.

2. For <DriverType> is 'HIGHSIDE'

	Short2Bat can be detected if <AoutState> is 'AoutDriverSwitchedOff'

	Short2Gnd can be detected if <AoutState> is 'AoutDriverSwitchedOn'

	open line condition cannot be distinguished from Normal condition. Therefore open line faults cannot be detected.

3. For <DriverType> is 'LOWSIDE'

	Short2Bat can be detected if <AoutState> is 'AoutDriverSwitchedOn'

	Short2Gnd can be detected if <AoutState> is 'AoutDriverSwitchedOff'

	open line condition cannot be distinguished from Short2Ground condition.

Note : The load behavior and PWM generation depends on type of load. for ex : Crash output or inverted lamps. Hence behavior need to be updated.

SRTP will be updated for B-sample and once the system configuration id fixed.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'DriverType' => 
	SCALAR 'Fault' => 
	SCALAR 'QualiTime' => 
	SCALAR 'DequaliTime' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 
	SCALAR 'TestCondition' => 
	SCALAR 'DriverState' => 
	SCALAR 'FaultCondition' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the Aout fault handling uder different test conditions'
	Aoutname = '<Test Heading 2>'
	TestCondition = 'NORMAL'
	DriverState = '<Test Heading 3>'
	FaultCondition = '<Test Heading 4>'
	LoadName = 'TBD'
	DriverType = 'TBD'
	Fault = 'TBD'
	QualiTime = 'TBD'
	DequaliTime = 'TBD'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_TestCondition;
my $tcpar_DriverState;
my $tcpar_FaultCondition;
my $tcpar_LoadName;
my $tcpar_DriverType;
my $tcpar_Fault;
my $tcpar_QualiTime;
my $tcpar_DequaliTime;
my $tcpar_Crashcode;
my $tcpar_ResultDB;
my $tcpar_Aout_LC_device_map;
my $tcpar_FLTopt_aref;
my $tcpar_Fault_qualify;

################ global parameter declaration ###################
#add any global variables here
my ( $faultMemory_obj, $faultMemory_obj1 );
my $expectedFaults_Quali_href   = {};
my $expectedFaults_DeQuali_href = {};
my @optFaults_Quali             = ();
my @optFaults_DeQuali           = ();
my $labcar_device;
my $crashSettings;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose            = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname           = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_TestCondition      = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_DriverState        = S_read_optional_testcase_parameter('DriverState');
	$tcpar_FaultCondition     = S_read_mandatory_testcase_parameter('FaultCondition');
	$tcpar_LoadName           = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_FLTopt_aref        = S_read_optional_testcase_parameter('FLTopt');
	$tcpar_DriverType         = S_read_optional_testcase_parameter('DriverType');
	$tcpar_Fault              = S_read_optional_testcase_parameter('Fault');
	$tcpar_Fault_qualify      = S_read_mandatory_testcase_parameter('Fault_qualify');
	$tcpar_QualiTime          = S_read_mandatory_testcase_parameter('QualiTime');
	$tcpar_DequaliTime        = S_read_mandatory_testcase_parameter('DequaliTime');
	$tcpar_Crashcode          = S_read_optional_testcase_parameter('Crashcode');
	$tcpar_ResultDB           = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB           = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	$tcpar_Aout_LC_device_map = S_read_mandatory_testcase_parameter('Aout_LC_device_map');

	$labcar_device   = $tcpar_Aout_LC_device_map->{$tcpar_LoadName};
	@optFaults_Quali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );
	@optFaults_DeQuali = @$tcpar_FLTopt_aref
	  if ( defined $tcpar_FLTopt_aref );

	return 1;
}

sub TC_initialization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	if ( defined $tcpar_Crashcode ) {
		S_teststep( "Initialize and prepare for crash injection", 'AUTO_NBR' );
		S_teststep_2nd_level( "Get crash settings for crash $tcpar_Crashcode", 'AUTO_NBR' );
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
		$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		S_teststep_2nd_level( "Set environments for crash as per result DB", 'AUTO_NBR' );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	}
	_setAODstate( $tcpar_LoadName, $tcpar_DriverState );

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	unless ( $tcpar_TestCondition =~ 'AUTARKY' ) {
		S_teststep( "Create test condition '$tcpar_TestCondition'.", 'AUTO_NBR', 'create_test_condition' );    #measurement 1
		_createTestCondition($tcpar_TestCondition);

		S_teststep( "Create '$tcpar_FaultCondition'. ", 'AUTO_NBR', 'create_faultcondition' );                 #measurement 2
		_createFaultCondition($tcpar_FaultCondition);

		S_teststep( "Wait for '$tcpar_QualiTime'.", 'AUTO_NBR', 'wait_for_qualitime' );                        #measurement 3
		S_wait_ms($tcpar_QualiTime);
	}
	else {

		#for AUTARKY condition, Autarky time is not enough for fault qualified
		#-> create fault, wait little bit time and cut power off
		S_teststep( "Create '$tcpar_FaultCondition'. ", 'AUTO_NBR', 'create_faultcondition' );                 #measurement 2
		_createFaultCondition($tcpar_FaultCondition);
		S_wait_ms( $tcpar_QualiTime - 50, "wait little bit for fault qualified before cut off power" );

		S_teststep( "Create test condition '$tcpar_TestCondition'.", 'AUTO_NBR', 'create_test_condition' );    #measurement 1
		_createTestCondition($tcpar_TestCondition);
	}

	S_teststep( "Read fault recorder.", 'AUTO_NBR', 'read_fault_recorder_A' );                                 #measurement 4
	$faultMemory_obj = LIFT_FaultMemory->read_fault_memory('Primary');

	if ( $tcpar_TestCondition =~ 'AUTARKY' ) {
		S_teststep( "For test condition 'AUTARKY', wait for ECU off, remove fault turn on ECU, creat fault again and repeat test for remove fault in AUTARKY", 'AUTO_NBR' );
		S_teststep_2nd_level( "wait for ECU off", 'AUTO_NBR' );
		S_wait_ms("TIMER_ECU_OFF");

		S_teststep_2nd_level( "Remove '$tcpar_FaultCondition'.", 'AUTO_NBR' );
		_removeFaultCondition($tcpar_FaultCondition);

		S_teststep_2nd_level( "Remove condition '$tcpar_TestCondition'", 'AUTO_NBR' );
		_removeTestCondition($tcpar_TestCondition);

		S_teststep_2nd_level( "Create '$tcpar_FaultCondition' and wait for Fault qualified", 'AUTO_NBR' );
		_createFaultCondition($tcpar_FaultCondition);
		S_wait_ms(5000);

		S_teststep( "Remove '$tcpar_FaultCondition'.", 'AUTO_NBR' );
		_removeFaultCondition($tcpar_FaultCondition);
		S_wait_ms( $tcpar_DequaliTime - 50, "wait little bit for fault de-qualified before cut off power" );

		S_teststep_2nd_level( "Create condition '$tcpar_TestCondition' again and continue test remove fault", 'AUTO_NBR' );
		_createTestCondition($tcpar_TestCondition);
	}
	else {
		S_teststep( "Remove '$tcpar_FaultCondition'.", 'AUTO_NBR' );
		_removeFaultCondition($tcpar_FaultCondition);

		S_teststep( "Wait for '$tcpar_DequaliTime'.", 'AUTO_NBR' );
		S_wait_ms($tcpar_DequaliTime);
	}

	S_teststep( "Read fault recorder.", 'AUTO_NBR', 'read_fault_recorder_B' );    #measurement 5
	$faultMemory_obj1 = LIFT_FaultMemory->read_fault_memory('Primary');

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	my $check_fault = 0;

	unless ( $tcpar_Fault =~ 'NONE' ) {

		if ( $tcpar_Fault_qualify =~ /yes/ ) {
			$expectedFaults_Quali_href->{'mandatory'}->{$tcpar_Fault}   = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 }, };
			$expectedFaults_DeQuali_href->{'mandatory'}->{$tcpar_Fault} = { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 }, };
			$check_fault                                                = 1;
		}
		else {

			$expectedFaults_Quali_href   = {};
			$expectedFaults_DeQuali_href = {};
		}
	}
	else {
		$expectedFaults_Quali_href   = {};
		$expectedFaults_DeQuali_href = {};
	}

	$expectedFaults_Quali_href->{'optional'}   = \@optFaults_Quali;
	$expectedFaults_DeQuali_href->{'optional'} = \@optFaults_DeQuali;

	my $entry_obj_aref = $faultMemory_obj->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 1 } } );
	my @faultNamesInMemory_Quali = ();
	foreach my $fault_entry_obj ( @{$entry_obj_aref} ) {
		push( @faultNamesInMemory_Quali, $fault_entry_obj->FaultName );
	}
	if ( $check_fault == 1 ) {

		S_teststep_expected( "'$tcpar_Fault' should be qualified.", 'read_fault_recorder_A' );    #evaluation 4
	}
	else {

		S_teststep_expected( "'$tcpar_Fault' should not be stored as AOD state is '$tcpar_DriverState' and fault condition is '$tcpar_FaultCondition'", 'read_fault_recorder_A' );    #evaluation 4
	}
	S_teststep_detected( "Detected fault qualify in memory:", 'read_fault_recorder_A' );
	foreach my $fault (@faultNamesInMemory_Quali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj->evaluate_faults(
		$expectedFaults_Quali_href,                                                                                                                                                   # expected faults
		'read_fault_recorder_A'                                                                                                                                                       # eval keyword
	);

	my $entry_obj1_aref = $faultMemory_obj1->get_faults_with_properties( { 'DecodedStatus' => { 'ConfirmedDTC' => 1, 'TestFailed' => 0 } } );
	my @faultNamesInMemory_DeQuali = ();
	foreach my $fault_entry_obj ( @{$entry_obj1_aref} ) {
		push( @faultNamesInMemory_DeQuali, $fault_entry_obj->FaultName );
	}

	if ( defined $expectedFaults_DeQuali_href ) {

		S_teststep_expected( "'$tcpar_Fault' should be dequalified.", 'read_fault_recorder_B' );                                                                                      #evaluation 5
	}
	else {

		S_teststep_expected( "'$tcpar_Fault' should not be stored as AOD state is '$tcpar_DriverState' and fault condition is '$tcpar_FaultCondition'", 'read_fault_recorder_B' );    #evaluation 5
	}

	S_teststep_detected( "Detected fault qualify in memory", 'read_fault_recorder_B' );
	foreach my $fault (@faultNamesInMemory_DeQuali) {
		S_teststep_detected("$fault is in the fault recorder");
	}
	$faultMemory_obj1->evaluate_faults(
		$expectedFaults_DeQuali_href,                                                                                                                                                 # expected faults
		'read_fault_recorder_B'                                                                                                                                                       # eval keyword
	);

	return 1;
}

sub TC_finalization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Remove condition '$tcpar_TestCondition'", 'AUTO_NBR' );
	_removeTestCondition($tcpar_TestCondition);

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset AOD state", 'AUTO_NBR' );
	_resetAODstate( $tcpar_LoadName, $tcpar_DriverState );

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Check fault free setup", 'AUTO_NBR' );
	my $faultMemory_reset_obj = LIFT_FaultMemory->read_fault_memory('Primary');
	$faultMemory_reset_obj->evaluate_faults( {} );

	return 1;
}

sub _createTestCondition {

	my $condtion = shift;

	given ($condtion) {

		when ('NORMAL') {

			S_w2rep( "Condition NORMAL, nothing to set", 'blue' );
		}
		when ('IDLEMODE') {

			my $IdleMode_var = 'rb_bswm_ActiveStateIdle_u16';
			S_teststep_2nd_level( "Writing $IdleMode_var => [0x55 0xAA]", 'AUTO_NBR' );
			PD_WriteMemoryByName( $IdleMode_var, [ '0xAA', '0x55' ] );
			PD_ECUreset('Soft_reset');
			S_wait_ms(8000);

			S_teststep_2nd_level( "Read rb_bswm_ActualSystemMode_au16(0)", 'AUTO_NBR' );
			my $idlemode_Value = S_aref2hex( PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)') );

			EVAL_evaluate_value( "ECU is in idle mode", $idlemode_Value, '==', 0x0004 );
		}
		when ('AUTARKY') {

			LC_ECU_Off();
		}
		when ('VBATLOW') {

			S_teststep_2nd_level( "Set ECU supplier voltage to 'U_BATT_UNDERVOLTAGE')", 'AUTO_NBR' );
			LC_SetVoltage('U_BATT_UNDERVOLTAGE');
		}
		when ('VBATHIGH') {

			S_teststep_2nd_level( "Set ECU supplier voltage to '20' V)", 'AUTO_NBR' );
			LC_SetVoltage('U_BATT_OVERVOLTAGE');
		}
		when (/CRASH/) {

			S_teststep_2nd_level( "Inject '$tcpar_Crashcode'", 'AUTO_NBR' );
			CSI_TriggerCrash();
			if ( $condtion =~ 'AFTERCRASH' ) {
				S_teststep_2nd_level( "Wait for crash finish", 'AUTO_NBR' );
				S_wait_ms(15000);
			}
			push( @optFaults_Quali,   ( 'rb_evm_FrontCrashDetected_flt', 'rb_evm_CrashDetected_flt' ) );
			push( @optFaults_DeQuali, ( 'rb_evm_FrontCrashDetected_flt', 'rb_evm_CrashDetected_flt' ) );
		}
		default {

			S_set_error("Test condition $condtion is not match or currently not support, only support for below: 'NORMAL', 'DURINGCRASH', 'AFTERCRASH', 'IDLEMODE', 'AUTARKY', 'VBATLOW', 'VBATHIGH'");
		}
	}

	S_teststep( "Read lamp state after creating condition", 'AUTO_NBR' );
	my $lamp_states_href = PD_ReadLampStates();
	S_w2rep( "Lamp $tcpar_LoadName is '$lamp_states_href->{$tcpar_LoadName}'", 'blue' );

	return 1;
}

sub _removeTestCondition {

	my $condtion = shift;

	given ($condtion) {
		when ('NORMAL') {

			S_w2rep( "Condition NORMAL, nothing to set", 'blue' );
		}
		when ('IDLEMODE') {

			S_teststep_2nd_level( "Reset ECU and wait ECU ready", 'AUTO_NBR' );
			PD_ECUreset();
			S_wait_ms('TIMER_ECU_READY');

			S_teststep_2nd_level( "Read rb_bswm_ActualSystemMode_au16(0)", 'AUTO_NBR' );
			my $idlemode_Value = S_aref2hex( PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)') );

			EVAL_evaluate_value( "ECU is not in idle mode", $idlemode_Value, '==', 0x0005 );
		}
		when ('AUTARKY') {

			S_teststep_2nd_level( "Power ON ECU and wait for ECU Ready", 'AUTO_NBR' );
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();

			if ( $tcpar_LoadName =~ /AOutPassAirbag|AOutSysWarningIndicator/ ) {
				S_teststep_2nd_level( "Clear fault memory as PADI and WL will be On during prove-out", 'AUTO_NBR' );
				PD_ClearFaultMemory();
				S_wait_ms(5000);
			}

		}
		when ('VBATLOW') {

			S_teststep_2nd_level( "Set ECU supplier voltage to 'U_BATT_DEFAULT')", 'AUTO_NBR' );
			LC_SetVoltage('U_BATT_DEFAULT');
		}
		when ('VBATHIGH') {

			S_teststep_2nd_level( "Set ECU supplier voltage to 'U_BATT_DEFAULT')", 'AUTO_NBR' );
			LC_SetVoltage('U_BATT_DEFAULT');
		}
		when (/CRASH/) {

			if ( $condtion =~ 'DURINGCRASH' ) {
				S_teststep_2nd_level( "Wait for crash finish", 'AUTO_NBR' );
				S_wait_ms(15000);
			}
			S_teststep_2nd_level( "Power down ECU", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep_2nd_level( "Power up ECU", 'AUTO_NBR' );
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_READY');

			S_teststep_2nd_level( "Erase EDR", 'AUTO_NBR' );
			PD_ClearCrashRecorder();
			S_wait_ms(2000);
		}
		default {
			S_set_error("Test condition $condtion is not match or currently not support, only support for below: 'NORMAL', 'DURINGCRASH', 'AFTERCRASH', 'IDLEMODE', 'AUTARKY', 'VBATLOW', 'VBATHIGH'");
		}
	}

	return 1;
}

sub _createFaultCondition {

	my $faultcondtion = shift;
	if ( $faultcondtion =~ 'ShortToGND' ) {

		S_w2rep( "Short line $labcar_device+ and B-", 'blue' );
		LC_ShortLines( [ $labcar_device . '+', 'B-' ] );
	}
	elsif ( $faultcondtion =~ 'ShortToVbat' ) {

		S_w2rep( "Short line $labcar_device+ and B+", 'blue' );
		LC_ShortLines( [ $labcar_device . '+', 'B+' ] );
	}
	elsif ( $faultcondtion =~ 'OpenLine' ) {

		S_w2rep( "Disconnect line $labcar_device", 'blue' );
		LC_DisconnectLine($labcar_device);
	}
	else {

		S_set_error("Fault condition $faultcondtion is not supported, only support for 'ShortToGND', 'ShortToVbat', 'OpenLine'");
	}
	S_wait_ms(1000);
	return 1;
}

sub _removeFaultCondition {

	my $faultcondtion = shift;
	if ( $faultcondtion =~ 'ShortToGND' ) {

		S_w2rep( "Undo short line $labcar_device+ and B-", 'blue' );
		LC_UndoShortLines();
	}
	elsif ( $faultcondtion =~ 'ShortToVbat' ) {

		S_w2rep( "Undo short line $labcar_device+ and B+", 'blue' );
		LC_UndoShortLines();
	}
	elsif ( $faultcondtion =~ 'OpenLine' ) {

		S_w2rep( "Re-connect line $labcar_device", 'blue' );
		LC_ConnectLine($labcar_device);
	}
	else {

		S_set_error("Fault condition $faultcondtion is not supported, only support for 'ShortToGND', 'ShortToVbat', 'OpenLine'");
	}

	return 1;
}

sub _setAODstate {

	my $device = shift;
	my $state  = shift;

	unless ( defined &FuncLib_Project_DEVICE::DEVICE_setAODState ) {

		given ($device) {
			when ('AOutSysWarningIndicator') {
				if ( $state =~ 'DriverSwitchedOn' ) {

					S_teststep( "Create fault to set SysWL ON ", 'AUTO_NBR' );
					LC_DisconnectLine('AB1FD');
					S_wait_ms(8000);
					push( @optFaults_Quali,   'rb_sqm_SquibResistanceOpenAB1FD_flt' );
					push( @optFaults_DeQuali, 'rb_sqm_SquibResistanceOpenAB1FD_flt' );

					S_teststep( "Read fault memory", 'AUTO_NBR' );
					PD_ReadFaultMemory();
				}
				elsif ( $state =~ 'DriverSwitchedOff' ) {

					S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
				}
				else {

					S_set_error("State $state currently is not supported in this test script ");
				}
			}
			when (/AOutPassAirbag/) {

				_setPADI_PAEL_state( $device, $state );
			}
			when (/AOutCrashOutput/) {

				S_w2rep( "Device '$device' is control by PWM, cannot control ON or OFF", 'blue' );
			}
			default {
				S_set_error("Device $device currently is not supportted in test script");
			}
		}
	}
	else {
		FuncLib_Project_DEVICE::DEVICE_setAODState( $device, $state );
	}

	unless ( $device =~ /AOutCrashOutput/ ) {

		my $lamp_states_href;
		S_teststep( "Read and evaluate lamp state", 'AUTO_NBR' );
		$lamp_states_href = PD_ReadLampStates();

		$device = 'System Warning Lamp' if ( $device =~ 'AOutSysWarningIndicator' );

		if ( $state =~ 'DriverSwitchedOn' ) {

			S_teststep_expected("Lamp $device should be ON");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'On', $lamp_states_href->{$device} );
		}
		else {

			S_teststep_expected("Lamp $device should be OFF");
			S_teststep_detected("Lamp $device is '$lamp_states_href->{$device}'");
			EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{$device} );
		}
	}
	else {

		S_w2rep( "Do not evaluate state On or Off of $device", 'blue' );
	}
	return 1;
}

sub _resetAODstate {

	my $device = shift;
	my $state  = shift;
	my $lamp_states_href;
	given ($device) {
		when ('AOutSysWarningIndicator') {
			if ( $state =~ 'DriverSwitchedOn' ) {

				S_teststep( "Remove fault to set SysWL ON ", 'AUTO_NBR' );
				LC_ConnectLine('AB1FD');
				S_wait_ms(2000);
				PD_ClearFaultMemory();
			}
			elsif ( $state =~ 'DriverSwitchedOff' ) {

				S_teststep( "WL should be OFF as expected fault free setup, nothing to be done", 'AUTO_NBR' );
				S_teststep_2nd_level( "Read and evaluate lamp state", 'AUTO_NBR' );
				$lamp_states_href = PD_ReadLampStates();
				EVAL_evaluate_string( "State of '$device'", 'Off', $lamp_states_href->{'System Warning Lamp'} );
			}
			else {

				S_set_error("State $state currently is not supported in this test script ");
			}
		}
		when (/AOutPassAirbag/) {

			_setPADI_PAEL_state( 'AOutPassAirbagOffIndicator', 'DriverSwitchedOff' );
		}
		when (/AOutCrashOutput/) {

			S_w2rep( "Device '$device' is control by PWM, cannot control ON or OFF", 'blue' );
		}
		default {
			S_set_error("Device $device currently is not supportted in test script");
		}
	}

	return 1;
}

sub _setPADI_PAEL_state {

	my $devicename = shift;
	my $state      = shift;

	my ( $result_OPSFP_A, $state_OPSFP_A_value, $state_OPSFP_A_unit ) = SYC_SWITCH_get_state( 'OPSFP', 'PositionA' );
	my ( $result_OPSFP_B, $state_OPSFP_B_value, $state_OPSFP_B_unit ) = SYC_SWITCH_get_state( 'OPSFP', 'PositionB' );

	my ( $result_PADS1_A, $state_PADS1_A_value, $state_PADS1_A_unit ) = SYC_SWITCH_get_state( 'PADS1', 'PositionA' );
	my ( $result_PADS1_B, $state_PADS1_B_value, $state_PADS1_B_unit ) = SYC_SWITCH_get_state( 'PADS1', 'PositionB' );

	my ( $result_PADS2_A, $state_PADS2_A_value, $state_PADS2_A_unit ) = SYC_SWITCH_get_state( 'PADS2', 'PositionA' );
	my ( $result_PADS2_B, $state_PADS2_B_value, $state_PADS2_B_unit ) = SYC_SWITCH_get_state( 'PADS2', 'PositionB' );

	if (
		( ( $devicename =~ 'AOutPassAirbagOffIndicator' ) and ( $state =~ 'DriverSwitchedOn' ) )
		or (    ( $devicename =~ 'AOutPassAirbagOnIndicator' )
			and ( $state =~ 'DriverSwitchedOff' ) )
	  )
	{

		S_teststep( "Set OPSFP to occupied (PosB) and set PADS1, PADS2 to airbag off (PosA)", 'AUTO_NBR' );
		_setSwitchState( 'OPSFP', $state_OPSFP_B_value, $state_OPSFP_B_unit );
		_setSwitchState( 'PADS1', $state_PADS1_A_value, $state_PADS1_A_unit );
		_setSwitchState( 'PADS2', $state_PADS2_A_value, $state_PADS2_B_unit );
	}
	else {

		S_teststep( "Set OPSFP to occupied (PosB) and set PADS1, PADS2 to airbag on (PosB)", 'AUTO_NBR' );
		_setSwitchState( 'OPSFP', $state_OPSFP_B_value, $state_OPSFP_B_unit );
		_setSwitchState( 'PADS1', $state_PADS1_B_value, $state_PADS1_B_unit );
		_setSwitchState( 'PADS2', $state_PADS2_B_value, $state_PADS2_A_unit );
	}
	S_wait_ms(1000);

	return 1;
}

sub _setSwitchState {

	my $switch      = shift;
	my $state_value = shift;
	my $switch_unit = shift;

	if ( $switch_unit =~ 'I' ) {

		LC_SetCurrent( $switch, $state_value );
	}
	elsif ( $switch_unit =~ 'R' ) {

		LC_SetResistance( $switch, $state_value );
	}
	else {

		S_set_error("Device type unit '$switch_unit' is not supported");
	}
	return 1;
}

1;
