#### TEST CASE MODULE
package TC_AOD_LoadPresence;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER =
q$Header: AOD/TC_AOD_LoadPresence.pm 1.2 2019/05/28 13:36:08ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_AOD_AnalogOutputDriver
#TS version in DOORS: 3.84
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_labcar;
use FuncLib_SYC_INTERFACE;    #as CA do not include this in INCLUDES_Project
##################################

our $PURPOSE = "To verify the indication of load presence at Aout";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_AOD_LoadPresence

=head1 PURPOSE

To verify the indication of load presence at Aout

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault

Variable: LoadPresence Check  rb_syco_AOutPresence_ab8(0)

Limitations:

For HighSide drivers it is not possible to detect an open line. The presence bit is not set.

For the system ASIC LIN interface it is not possible to detect an open line. The presence bit is always set. 


I<B<Stimulation and Measurement>>

1. Monitor presence (real) bit for the load <LoadName> connected to port <AoutName>.

2. Create <Condition>.

3. Monitor presence (real) bit for the load <LoadName>.


I<B<Evaluation>>

1. Presence bit should be set.

2. 

3. Presence bit should be set in case of monitored and load connected.

Check below table for present bit set:

 

monitor bit	load connected	present bit	   

no	no	no	   

no	yes	no	   

yes	no	no	   

yes	yes	yes	 

Note :LoadDisconnected cannot be distinguished from the normal condition for high side drivers. this needs to be taken care during scripting and testing.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'DriverType' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 
	SCALAR 'Condition' => 
	HASH 'Aout_SYC_device_map' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the indication of load presence at Aout'
	Aoutname = '<Test Heading 2>'
	Condition = 'LoadNotMonitored'
	Aout_SYC_device_map = %('AOutSysWarningIndicator' => 'System_Warning_Indicator', 'AOutPassAirbagOnIndicator' => 'Passenger_Airbag_On_Indicator', 'AOutPassAirbagOffIndicator' => 'Passenger_Airbag_Off_Indicator', 'AOutCrashOutput1' => 'CrashOutput1', 'AOutCrashOutput2' => 'CrashOutput2','AOutCrashOutput3' => 'CrashOutput3') #mapping between .sad device and name in SYC export from SCIP
	LoadName = 'TBD'
	DriverType = 'TBD'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_Condition;
my $tcpar_Aout_SYC_device_map;
my $tcpar_LoadName;
my $tcpar_Aout_LC_device_map;

################ global parameter declaration ###################
#add any global variables here
my ( $present_init, $monitor_init, $config_init );
my ( $present,      $monitor,      $config );
my ( $result,       $configured,   $monitored );
my $conf_mon_states_map = { 'yes' => 1, 'no' => 0, 'N/A' => 0 };
my $SYC_scip_device;
my $labcar_device;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose   = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname  = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_Condition = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Aout_SYC_device_map = S_read_mandatory_testcase_parameter('Aout_SYC_device_map');
	$tcpar_Aout_LC_device_map = S_read_mandatory_testcase_parameter('Aout_LC_device_map');
	$tcpar_LoadName   = S_read_mandatory_testcase_parameter('LoadName');

	$SYC_scip_device = $tcpar_Aout_SYC_device_map->{$tcpar_LoadName};
	$labcar_device = $tcpar_Aout_LC_device_map->{$tcpar_LoadName};

	return 1;
}

sub TC_initialization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Verify configuration and monitoring flag of '$tcpar_LoadName' compare with SYC.", 'AUTO_NBR', 'verify_configuration_and_monitor' );
	( $present_init, $monitor_init, $config_init ) = PD_get_device_config($tcpar_LoadName);
	S_wait_ms(2000);    #wait for 2s to avoid PD error
	S_teststep_2nd_level( "Verify configuration of '$tcpar_LoadName' compare with SYC", 'AUTO_NBR', 'verify_configuration' );
	( $result, $configured ) = SYC_AnalogueOutput_get_Configured($SYC_scip_device);
	S_teststep_expected( "Follow SYC, config bit of '$tcpar_LoadName' is '$conf_mon_states_map->{$configured}'.", 'verify_configuration' );
	S_teststep_detected( "Config bit status '$tcpar_LoadName' in SW is '$config_init'.", 'verify_configuration' );
	EVAL_evaluate_value( "Config bit status $tcpar_LoadName", $config_init, '==', $conf_mon_states_map->{$configured} );

	S_teststep_2nd_level( "Verify monitoring flag of '$tcpar_LoadName' compare with SYC", 'AUTO_NBR', 'verify_monitor' );
	( $result, $monitored ) = SYC_AnalogueOutput_get_Monitored($SYC_scip_device);
	S_teststep_expected( "Follow SYC, monitor bit of '$tcpar_LoadName' is '$conf_mon_states_map->{$monitored}'.", 'verify_monitor' );
	S_teststep_detected( "Monitor bit status '$tcpar_LoadName' in SW is '$monitor_init'.", 'verify_monitor' );
	EVAL_evaluate_value( "Monitor bit status $tcpar_LoadName", $monitor_init, '==', $conf_mon_states_map->{$monitored} );

	return 1;
}

sub TC_stimulation_and_measurement {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	if ( $monitor_init == 1 ) {
		S_teststep( "Monitor presence (real) bit for the load '$tcpar_LoadName' connected to port '$tcpar_Aoutname'.", 'AUTO_NBR', 'monitor_presence_real_A' );    #measurement 1
		S_w2rep( "$tcpar_LoadName present bit state had already gotten in the initilization \n", 'blue' );
		S_teststep_expected( "Presence bit should be set.", 'monitor_presence_real_A' );    #evaluation 1
		S_teststep_detected( "Presence bit  detected is '$present_init'", 'monitor_presence_real_A' );
		EVAL_evaluate_value( "Presence bit status $tcpar_LoadName", $present_init, '==', $conf_mon_states_map->{'yes'} );

		S_teststep( "Create condition '$tcpar_Condition'.", 'AUTO_NBR' );
		_create_Condition($tcpar_Condition);

		S_teststep( "Monitor presence (real) bit for the load '$tcpar_LoadName'.", 'AUTO_NBR', 'monitor_presence_real_B' );    #measurement 2
		( $present, $monitor, $config ) = PD_get_device_config($tcpar_LoadName);
		_evaluate_presence_bit( $tcpar_Condition, $present );

	}
	else {

		#Evaluate presence bit follow the monitor bit, if monitor bit is 0, presence bit should also be 0
		S_teststep_expected( "Presence bit of '$tcpar_LoadName' is '$monitor_init'.", 'verify_monitor' );
		S_teststep_detected( "Presence bit status '$tcpar_LoadName' in SW is '$present_init'.", 'verify_monitor' );
		EVAL_evaluate_value( "Presence bit status $tcpar_LoadName", $present_init, '==', $conf_mon_states_map->{$monitored} );

	}

	return 1;
}

sub TC_evaluation {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_w2rep( "All evaluation had been done in stimulation and measurement \n", 'blue' );

	return 1;
}

sub TC_finalization {

	if($tcpar_LoadName eq 'NONE'){
        S_teststep("No LoadName are applicable for this test case in project", 'NO_AUTO_NBR');
        return 1;
    }

	S_teststep( "Remove condition '$tcpar_Condition'", 'AUTO_NBR' );
	_remove_Condition($tcpar_Condition);

	S_teststep( "Clear Fault Memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep( "Reset the ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	return 1;
}

sub _create_Condition {

	my $condition = shift;

	if ( $condition =~ 'LoadNotMonitored' ) {
		
		PD_Device_configuration( 'clear', [$tcpar_LoadName] );
		S_wait_ms(2000);

		PD_Device_configuration( 'clear_Mon', [$tcpar_LoadName] );
		S_wait_ms(2000);
	}
	elsif ( $condition =~ 'LoadDisconnected' ) {

		LC_DisconnectLine($labcar_device);
	}
	elsif ( $condition =~ 'LoadConnected' ) {

		LC_ConnectLine($labcar_device);
	}
	else {

		S_set_error( "Condition $condition is not supported", 114 );
	}

	return 1;
}

sub _remove_Condition {

	my $condition = shift;

	if ( $condition =~ 'LoadNotMonitored' ) {

		PD_Device_configuration( 'set_Mon', [$tcpar_LoadName] );
		S_wait_ms(2000);
		
		if ($config_init == 1) {
		
			PD_Device_configuration( 'set', [$tcpar_LoadName] );
			S_wait_ms(2000);
		}
	}
	elsif ( $condition =~ 'LoadDisconnected' ) {
		if ( $present_init == 1 ) {

			LC_ConnectLine($labcar_device);
		}
		else {

			S_w2rep( "$tcpar_LoadName is not connectted in initilization state, not connect device \n", 'blue' );
		}

	}
	elsif ( $condition =~ 'LoadConnected' ) {
		if ( $present_init == 1 ) {

			S_w2rep( "$tcpar_LoadName is connected in initilization state, no change is performed \n", 'blue' );
		}
		else {

			LC_DisconnectLine($labcar_device);
		}

	}
	else {

		S_set_error( "Condition $condition is not supported", 114 );
	}

	return 1;
}

sub _evaluate_presence_bit {

	my $condition     = shift;
	my $present_state = shift;

	my $expected_presence_bit;

	if ( $condition =~ 'LoadNotMonitored' ) {

		$expected_presence_bit = 'no';
	}
	elsif ( $condition =~ 'LoadDisconnected' ) {

		$expected_presence_bit = 'no';
	}
	elsif ( $condition =~ 'LoadConnected' ) {

		$expected_presence_bit = 'yes';
	}
	else {

		S_set_error( "Condition $condition is not supported", 114 );
	}
	S_teststep_expected( "Presence bit with conditon '$condition' is '$expected_presence_bit'", 'monitor_presence_real_B' );    #evaluation 2
	S_teststep_detected( "Presence bit detected is '$present_state'", 'monitor_presence_real_B' );
	EVAL_evaluate_value( "Presence bit status $tcpar_LoadName", $present_state, '==', $conf_mon_states_map->{$expected_presence_bit} );
	
	return 1;
}

1;
