#### TEST CASE MODULE
package TC_ASIC_AOD_In_Init;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: AOD/TC_ASIC_AOD_In_Init.pm 1.1 2019/05/28 14:06:12ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
##################################

our $PURPOSE = "To verify the status of AOD in Init phase";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_ASIC_AOD_In_Init

=head1 PURPOSE

To verify the status of AOD in Init phase

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Test setup : 

Preconditions : 

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. State of <Aoutname> in init phase.


I<B<Evaluation>>

1. State is set to <Status>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'LoadName' => 
	SCALAR 'Status' => 
	SCALAR 'Purpose' => 
	SCALAR 'Aoutname' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To verify the status of AOD in Init pahse'
	Aoutname = '<Test Heading 2>'
	LoadName = 'NONE'
	Status = 'Off'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_Aoutname;
my $tcpar_LoadName;
my $tcpar_Status;

################ global parameter declaration ###################
#add any global variables here
my $lamp_states_href;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose  = S_read_mandatory_testcase_parameter('Purpose');
	$tcpar_Aoutname = S_read_mandatory_testcase_parameter('Aoutname');
	$tcpar_LoadName = S_read_mandatory_testcase_parameter('LoadName');
	$tcpar_Status   = S_read_mandatory_testcase_parameter('Status');

	return 1;
}

sub TC_initialization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep( "Turn off ECU and turn on again to check in init phase", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms("TIMER_ECU_OFF");
	LC_ECU_On();
	S_wait_ms(200);

	S_teststep( "State of '$tcpar_Aoutname' in init phase.", 'AUTO_NBR', 'state_of_aoutname' );    #measurement 1
	$lamp_states_href = PD_ReadLampStates();

	return 1;
}

sub TC_evaluation {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}

	S_teststep_expected( "State is set to '$tcpar_Status'", 'state_of_aoutname' );    #evaluation 1
	S_teststep_detected( "Detected state of '$tcpar_LoadName' is $lamp_states_href->{$tcpar_LoadName}", 'state_of_aoutname' );
	EVAL_evaluate_string( "State of '$tcpar_LoadName'", $tcpar_Status, $lamp_states_href->{$tcpar_LoadName} );

	return 1;
}

sub TC_finalization {

	if ( $tcpar_LoadName eq 'NONE' ) {
		S_teststep( "No LoadName are applicable for this test case in project", 'NO_AUTO_NBR' );
		return 1;
	}
	S_wait_ms('TIMER_ECU_READY');

	return 1;
}

1;
