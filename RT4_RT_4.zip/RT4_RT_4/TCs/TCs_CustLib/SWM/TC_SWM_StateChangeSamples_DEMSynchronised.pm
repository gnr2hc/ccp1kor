#### TEST CASE MODULE
package TC_SWM_StateChangeSamples_DEMSynchronised;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: SWM/TC_SWM_StateChangeSamples_DEMSynchronised.pm 1.4 2020/06/17 17:04:08ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWM_SwitchMgt> 
#TS version in DOORS: <> (e.g. 3.143)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use FuncLib_TNT_SYC_INTERFACE;
use LIFT_labcar;
use LIFT_evaluation;
use FuncLib_TNT_DEVICE;
##################################

our $PURPOSE = "To check if the switch state change is synchronised with DEM";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_StateChangeSamples_DEMSynchronised

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the <switch> to positionB

2. Create a cyclic fault on <switch> and wait for fault qualification time

3. Remove the switch fault and wait for fault de-qualification time

Note: Monitor the switch state and status (validity) continuously through Fast Diagnostics for step 2 and 3. Read the values 30 ms (one switch cycle) before and 30 ms after qualification


I<B<Evaluation>>

2. 

during fault qualification, switch position changes from positionB to default only when the fault gets qualified in the fault memory

during fault qualification, switch status (validity) changes from valid to fault only when the fault gets qualified in the fault memory

3.

during fault dequalification, switch position changes from default to positionB only when the fault gets dequalified in the fault memory

during fault dequalification, switch status (validity) changes from fault to valid only when the fault gets dequalified in the fault memory


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'switch' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To check if theswitch state change is synchronised with DEM'
	
	switch = '<Test Heading>'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_switch;


################ global parameter declaration ###################
#add any global variables here

my ($DQTime,$QTime,$switchName,$switchtype,$SW_state_var,$SW_status_var,$SW_FaultStatus_var,$SDL_switches,$FaultID,$deviceProperties,$FDdata_2,$FDdata_3);
my ($FDtrace1,$FDtrace2,$waitime,$Status_valid,$Status_fault,$Status_position,$SDL_Switch,$VERDICT,$fetch_SDL_Name);
my $fault = 'OpenLine';
my 	($Real,$Monitored_ID,$Prog);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose','byvalue' );
	$tcpar_switch =  S_read_mandatory_testcase_parameter( 'switch','byvalue' );

	$switchName =DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_switch) ;
	
	unless(defined $switchName and $switchName ne '' and $switchName ne 'NONE'){	
		
			S_w2rep ("switch having label $tcpar_switch is  not present in the project");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
		
	}
	
	else{
	
		($Real,$Monitored_ID,$Prog) = PD_get_device_config($switchName);
		S_w2rep("presence bit :$Real",'Purple');
	
		if($Real eq '0'){                        #checking presence bit 
			S_w2rep("switch $switchName is not present in the system.");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
			
		}
		
		
		$switchtype = DEVICE_fetchSwitchType($switchName);
		
		if($switchtype =~ m/mech/i ){    #checking for mechanical switch
	
			S_w2rep ("test case is not required for  mechanical switch");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);

		}
		
		$SDL_Switch = S_get_contents_of_hash(['Mapping_DEVICE','SDL_switch']);   
		$fetch_SDL_Name = $SDL_Switch ->[0];

		if($fetch_SDL_Name eq $switchName){                  #Checking for SDL switch
	
			S_w2rep("Test case in not executed for SDL switch :$fetch_SDL_Name ",'purple');
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
		}
		
		
		$deviceProperties = DEVICE_fetchDeviceInfo($switchName);
		$SW_state_var  = $deviceProperties->{'State_PD'};
		$SW_status_var = $deviceProperties->{'Status_PD'};
		
		$FaultID = PD_GetFaultID( "rb_swm_".$fault.$switchName. "_flt" );
		$SW_FaultStatus_var = "Dem_AllEventsStatusByte($FaultID)";
		
		
		$Status_valid = S_get_contents_of_hash(['Mapping_DEVICE','DataValueTable_SwitchStates_PD','STATUS_VALID']);
		$Status_fault = S_get_contents_of_hash(['Mapping_DEVICE','DataValueTable_SwitchStates_PD','STATUS_FAULT']);
		$Status_position = S_get_contents_of_hash(['Mapping_DEVICE','DataValueTable_SwitchStates_PD','STATE_POSITIONB']);
		
		
		
	}
	
	
	
	
	return 1;

}

sub TC_initialization {

	
	return 1 if ($VERDICT);
		
		S_teststep("StandardPrepNoFault", 'AUTO_NBR');
		GEN_StandardPrepNoFault();
	
	
	return 1;
}

sub TC_stimulation_and_measurement {

	
	return 1 if ($VERDICT);

		S_teststep("Set the '$tcpar_switch' to positionB", 'AUTO_NBR');
	
		DEVICE_setDeviceState( $switchName, 'PositionB' );
	
		S_wait_ms('TIMER_SIX_SEC');
	
		
		S_teststep("Create a cyclic fault on '$tcpar_switch' and wait for fault qualification time", 'AUTO_NBR');
		
	
		PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step2.txt", [ $SW_state_var, $SW_status_var, $SW_FaultStatus_var ], [ "U8", "U8", "U8" ] );
		S_wait_ms( '2000', 'wait after Fast Diag start' );
		DEVICE_setDeviceState( $switchName, 'Openline' );

		S_wait_ms('TIMER_SIX_SEC'); 
		PD_StopFastDiag();
		
		#plot the trace
		$FDdata_2 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step2.txt" );
		PD_plot_FDtrace( $FDdata_2, $main::REPORT_PATH . "/FDtrace_$switchName"."Step2.txt" );
		S_add_pic2html( "./FDtrace_$switchName"."Step2.png", '', "./FDtrace_$switchName"."Step2.txt.unv", 'TYPE="text/unv"' );
		EVAL_dump2file($FDdata_2);
	
		
		
		S_teststep("Remove the switch fault and wait for fault de-qualification time", 'AUTO_NBR');
	
		PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt", [ $SW_state_var, $SW_status_var, $SW_FaultStatus_var ], [ "U8", "U8", "U8" ] );
		S_wait_ms( '2000', 'wait after Fast Diag start' );
		DEVICE_resetDeviceState( $switchName, 'Openline' );
		
		S_wait_ms( 'TIMER_SIX_SEC', 'wait for fault dequali time' );
		PD_StopFastDiag();

		#plot the trace
		$FDdata_3 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt" );
		PD_plot_FDtrace( $FDdata_3, $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt" );
		S_add_pic2html( "./FDtrace_$switchName"."Step3.png", '', "./FDtrace_$switchName"."Step3.txt.unv", 'TYPE="text/unv"' );
		EVAL_dump2file($FDdata_3);
	
		S_teststep("Note: Monitor the switch state and status (validity) continuously through Fast Diagnostics for step 2 and 3. Read the values 30 ms (one switch cycle) before and 30 ms after qualification", 'AUTO_NBR');
		

	
	return 1;


}

sub TC_evaluation {

	
	return 1 if ($VERDICT);

		S_w2rep("Evaluation for Step 2. "); #0bxxxxxxx1
		$QTime = EVAL_get_time_when( $FDdata_2, $SW_FaultStatus_var, 'MASK','0bxxxxxxx1' );    #time when filtered bit (bit0) is set
		S_teststep_expected("during fault qualification, switch position changes from positionB to default only when the fault gets qualified in the fault memory");
		
			
				GEN_printComment("Detected switch type for $switchName: $switchtype");
				EVAL_evaluate_value_around_time( $FDdata_2, ( $QTime - 30 ), $SW_state_var, "==", $Status_position );    #before qualification, state positionB
				EVAL_evaluate_value_around_time( $FDdata_2, ( $QTime + 30 ), $SW_state_var, "==", $Status_position );    #after qualification, state position is default - keep last condition
			
			
		S_teststep_expected("during fault qualification, switch status (validity) changes from valid to fault only when the fault gets qualified in the fault memory");
		
			
				GEN_printComment("Detected switch type for $switchName: $switchtype");
				EVAL_evaluate_value_around_time( $FDdata_2, ( $QTime - 30 ), $SW_status_var, "==", $Status_valid );    #before qualification, status 'valid'
				EVAL_evaluate_value_around_time( $FDdata_2, ( $QTime + 30 ), $SW_status_var, "==", $Status_fault );    #after qualification, status 'fault'
			
		
			S_w2rep("Evaluation for Step 3.");#0bxxxxxxx0
			$DQTime = EVAL_get_time_when( $FDdata_3, $SW_FaultStatus_var, 'MASK', '0bxxxxxxx0' );    #time when the fault counter reaches the dequali threshold
		
		S_teststep_expected("during fault dequalification, switch position changes from default to positionB only when the fault gets dequalified in the fault memory");
		
			
				GEN_printComment("Detected switch type for $switchName: $switchtype");
				EVAL_evaluate_value_around_time( $FDdata_3, ( $DQTime - 30 ), $SW_state_var, "==", $Status_position );    #before dequalification, state position is default - keep last condition
				EVAL_evaluate_value_around_time( $FDdata_3, ( $DQTime + 30 ), $SW_state_var, "==", $Status_position );    #after dequalification, state positionB
			
			
		S_teststep_expected("during fault dequalification, switch status (validity) changes from fault to valid only when the fault gets dequalified in the fault memory");
		
				GEN_printComment("Detected switch type for $switchName: $switchtype");
				EVAL_evaluate_value_around_time( $FDdata_3, ( $DQTime - 30 ), $SW_status_var, "==", $Status_fault );    #before dequalification, status 'fault'
				EVAL_evaluate_value_around_time( $FDdata_3, ( $DQTime + 30 ), $SW_status_var, "==", $Status_valid );    #after dequalification, status 'valid'
			
	
	
	return 1;
}

sub TC_finalization {

		return 1 if ($VERDICT);

		PD_ClearFaultMemory();
	
	
	return 1;

}




1;