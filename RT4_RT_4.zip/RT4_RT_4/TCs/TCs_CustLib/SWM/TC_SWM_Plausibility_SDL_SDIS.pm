#### TEST CASE MODULE
package TC_SWM_Plausibility_SDL_SDIS;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SWM_Plausibility_SDL_SDIS.pm 1.1 2019/07/15 11:57:43ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.114
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_spi_access;
#include further modules here

##################################

our $PURPOSE = "To test the SDIS_S connectivity between all System-ASICs";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_Plausibility_SDL_SDIS

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. ECU is powered on and system is fault free.

2. Read the fault recorder.

3. Set the <switch> to <position>.

4. Change the <signal> in SPI instruction <command>  to <value> during initialisation of ECU.

5. Power off the ECU and Power on the ecu.

6. Read the fault recorder.


I<B<Evaluation>>

1. 

2. No <fault> is qualified.

3.

4.

5. ECU is powered off and then the ECU is powered on.

6. <fault> shall be qualified.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'value' => 
	SCALAR 'purpose' => 
	SCALAR 'switch' => 
	SCALAR 'position' => 
	SCALAR 'command' => 
	SCALAR 'signal' => 
	SCALAR 'fault' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To test the SDIS_S connectivity between all System-ASICs'
	
	switch = '<Test Heading 1>'
	position = '<Test Heading 2>'
	
	#DISABLE_STATUS Bit0 corresponds to SIDS_S value
	
	command = 'DISABLE_STATUS'
	signal = 'SDIS_S'
	fault ='NONE'
	value = 0

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_switch;
my $tcpar_position;
my $tcpar_command;
my $tcpar_signal;
my %tcpar_fault;
my $tcpar_value;

################ global parameter declaration ###################
#add any global variables here
my $faultsAfterStimulation;
my $Detected_fault;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_switch =  GEN_Read_mandatory_testcase_parameter( 'switch' );
	$tcpar_position =  GEN_Read_mandatory_testcase_parameter( 'position' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	$tcpar_signal =  GEN_Read_mandatory_testcase_parameter( 'signal' );
	%tcpar_fault =  GEN_Read_mandatory_testcase_parameter( 'fault' );
	$tcpar_value =  GEN_Read_mandatory_testcase_parameter( 'value' );
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("ECU is powered on and system is fault free.", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep("Read the fault recorder.", 'AUTO_NBR');			#measurement 1
	
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]);
	
	S_teststep("Set the '$tcpar_switch' to '$tcpar_position'.", 'AUTO_NBR');
	
	DEVICE_setDeviceState($tcpar_switch,$tcpar_position);
	
	S_wait_ms(10000);
	
	S_teststep("Change the '$tcpar_signal' in SPI instruction '$tcpar_command'  to '$tcpar_value' during initialisation of ECU.", 'AUTO_NBR');
		
	SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal,
				'SignalValue' => $tcpar_value,
				);
	
	S_w2rep("Start the Manipulation");
	SPI_start_manipulation();
		
	S_teststep("Power off the ECU and Power on the ecu.", 'AUTO_NBR');			#measurement 2
	DIAG_ECUReset();
	
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Read the fault recorder.", 'AUTO_NBR', 'read_the_fault_B');			#measurement 3
	$faultsAfterStimulation = PD_ReadFaultMemory();
	return 1;
}

sub TC_evaluation {
		 
		foreach my $fault( keys %tcpar_fault){
			PD_check_fault_exists($faultsAfterStimulation, $fault);
			S_teststep_expected("'$fault' shall be qualified.", 'read_the_fault_B');			#evaluation 3
			$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation, $fault, 'fault_text' );
			S_teststep_detected("Detected Fault in the system:$Detected_fault", 'read_the_fault_B');
			
			my $fault_index  = PD_get_fault_index( $faultsAfterStimulation, $fault );
			# check Fault State
			my $FLT_state_expected = $tcpar_fault{$fault};
			my $FLT_state_detected = $faultsAfterStimulation->{'state'}->[$fault_index];
			
			#my $FLT_state_detected_8bits = substr((S_dec2bin(S_hex2dec($FLT_state_detected))), -8);				
			S_teststep_2nd_level( "Evaluate Fault State for $fault", 'AUTO_NBR');
			S_teststep_expected( "$FLT_state_expected"); 
			S_teststep_detected( "$FLT_state_detected" );
			EVAL_evaluate_value( "key_fault_name", $FLT_state_detected, 'MASK', $FLT_state_expected );
		}
		unless( scalar(keys %tcpar_fault)){
			my $faultsVerdict = PD_evaluate_faults( $faultsAfterStimulation,[]); 
			S_teststep_expected("No fault should qualify in the system.", 'read_the_fault_B');			#evaluation 3
			if($faultsVerdict eq 'VERDICT_PASS'){ 
				S_teststep_detected("No fault Qualified in the system", 'read_the_fault_B');
			}
			else{
				S_set_error("Unexpected Fault Qualified in the sensor");
				return 0;
			}
	 }

	return 1;
}

sub TC_finalization {
	SPI_stop_manipulation();
	PD_ClearFaultMemory();
    S_wait_ms('TIMER_ECU_READY');
	return 1;
}


1;
