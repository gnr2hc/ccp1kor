#### TEST CASE MODULE
package TC_SWM_MonitoringBasedOnFlags_CRC_NotOK;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SWM_MonitoringBasedOnFlags_CRC_NotOK.pm 1.1 2019/07/15 11:57:43ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS:TS_SWM_SwitchMgt
#TS version in DOORS: 3.114
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_spi_access;
#include further modules here

##################################

our $PURPOSE = "To test switch monitoring when CRC is not OK";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_MonitoringBasedOnFlags_CRC_NotOK

=head1 PURPOSE

To test switch monitoring when CRC is not OK

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. power up the ECU and check for fault free system.

2. Create <condition> for <NoOfTimes> during init time on <command_START>and <command_Read> commands using Manitoo.

3. Capture the SPI trace for verification

4. Read the Fault Recorder

Note: 

Create a condition such that CRC is NOT OK for all START_BIST and Read_BIST commands.

 System will Wait untill max number of retries for fault qualification

Here max number equals three times.


I<B<Evaluation>>

1. System should be fault free.

2.

3. 

4. <Mand_FLT> is qualified in the fault recorder.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Mand_FLT' => 
	SCALAR 'NoOfTimes' => 
	SCALAR 'Purpose' => 
	SCALAR 'condition' => 
	SCALAR 'command_START' => 
	SCALAR 'command_READ' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To test switch monitoring when CRC is not OK'
	
	condition = '<Test Heading 1>'
	command_START = 'AINO_START_BIST'
	command_READ ='AINO_Read_BIST'
	Mand_FLT= 'No_flt'
	NoOfTimes = '<Test Heading 2>'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_condition;
my $tcpar_command;
my %tcpar_Mand_FLT;
my $tcpar_NoOfTimes;

################ global parameter declaration ###################
#add any global variables here
my $faultsAfterStimulation;
my $Detected_fault;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_condition =  GEN_Read_mandatory_testcase_parameter( 'condition' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	%tcpar_Mand_FLT =  GEN_Read_mandatory_testcase_parameter( 'Mand_FLT' );
	$tcpar_NoOfTimes =  GEN_Read_mandatory_testcase_parameter( 'NoOfTimes' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("power up the ECU and check for fault free system.", 'AUTO_NBR', 'power_up_the');			#measurement 1
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]);
	
	S_teststep("Create '$tcpar_condition' for '$tcpar_NoOfTimes' during init time for the '$tcpar_command'and commands using Manitoo.", 'AUTO_NBR');
	
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	
	SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_condition,
				'FrameCycles' => $tcpar_NoOfTimes,
				'SignalValue' => 0,
			);
	
	S_w2rep("Start the Manipulation");
	SPI_start_manipulation();
	
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	S_wait_ms(5000);
	
	S_teststep("Read the Fault Recorder", 'AUTO_NBR', 'read_the_fault');			#measurement 2
	$faultsAfterStimulation = PD_ReadFaultMemory();
	

	return 1;
}

sub TC_evaluation {

	foreach my $fault( keys %tcpar_Mand_FLT){
			PD_check_fault_exists($faultsAfterStimulation, $fault);
			S_teststep_expected("'$fault' shall be qualified.", 'read_the_fault');			#evaluation 3
			$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation, $fault, 'fault_text' );
			S_teststep_detected("Detected Fault in the system:$Detected_fault", 'read_the_fault');
		}
	 return 1;
}

sub TC_finalization {
	SPI_stop_manipulation();
	PD_ClearFaultMemory();
    S_wait_ms(5000);
	return 1;
}


1;
