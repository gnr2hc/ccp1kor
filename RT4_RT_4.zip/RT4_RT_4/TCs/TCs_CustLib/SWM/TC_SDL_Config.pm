#### TEST CASE MODULE
package TC_SDL_Config;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SDL_Config.pm 1.1 2019/05/29 16:08:50ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) ready_for_review EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR)(2019/07/24 19:24:15ICT) $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####


use LIFT_general;
use INCLUDES_Project; 
use FuncLib_TNT_DEVICE;
use FuncLib_TNT_FM;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TSG4;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_ProdDiag;
require LIFT_PD2ProdDiag;import LIFT_PD2ProdDiag; #necessary
#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDL_Config

=head1 PURPOSE

To check when SDIS_S special disable line is not configured, then the SDL monitoring "test" shall be reported as finished to the ITM.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Start with fault free ECU.

2. Deconfigure PADS Switch <switch>.

3.Turn ECU off and turn on.

4.Measure the time when <Var1> is reported to <Var2> in <t1>and <Var3> in <t2>.


I<B<Evaluation>>

4. Compare <t1> and <t2>. The time difference (<t2>-<t1>) should be below <time_diff>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'switch' => 
	SCALAR 'Var1' => 
	SCALAR 'Var2' => 
	SCALAR 'Var3' => 
	SCALAR 't1' => 
	SCALAR 't2' => 
	SCALAR 'time_diff' => 


=head2 PARAMETER EXAMPLES

	Purpose ='To check when SDIS_S special disable line is not configured, then the SDL monitoring "test" shall be reported as finished to the ITM.'
	
	switch = '<Test Heading 1>'
	Var1='rb_itm_StartCyclicSwmSconMon_e'
	Var2= 'rb_itm_TestStarted_u64'
	Var3= 'rb_itm_TestFinished_u64'
	t1 = 'the time of the SDL-Monitoring start in ms'
	t2 = 'time when SDL-Monitoring gets reported as finished to ITM in ms.'
	
	time_diff = '10' #ms

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_switch;
my $tcpar_Var1;
my $tcpar_Var2;
my $tcpar_Var3;
my $tcpar_t1;
my $tcpar_t2;
my $tcpar_time_diff;

################ global parameter declaration ###################
#add any global variables here
my $Time1;
my $Time2;
my $FDdata;
my $Time_difference;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_switch =  GEN_Read_mandatory_testcase_parameter( 'switch' );
	$tcpar_Var1 =  GEN_Read_mandatory_testcase_parameter( 'Var1' );
	$tcpar_Var2 =  GEN_Read_mandatory_testcase_parameter( 'Var2' );
	$tcpar_Var3 =  GEN_Read_mandatory_testcase_parameter( 'Var3' );
	$tcpar_t1 =  GEN_Read_mandatory_testcase_parameter( 't1' );
	$tcpar_t2 =  GEN_Read_mandatory_testcase_parameter( 't2' );
	$tcpar_time_diff =  GEN_Read_mandatory_testcase_parameter( 'time_diff' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();


    return 1;

}

sub TC_stimulation_and_measurement {

	S_teststep("Start with fault free ECU.", 'AUTO_NBR');
		PD_ClearFaultMemory();
		S_wait_ms('2000');

	S_teststep("Deconfigure PADS Switch '$tcpar_switch'.", 'AUTO_NBR');
		PD_Device_configuration( 'clear', [$tcpar_switch.'1']);
		S_wait_ms('TIMER_SIX_SEC');
		PD_Device_configuration( 'clear', [$tcpar_switch.'2']);
	
	S_teststep("Turn ECU off and turn on.", 'AUTO_NBR');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Measure the time when '$tcpar_Var1' is reported to '$tcpar_Var2' in '$tcpar_t1'and '$tcpar_Var3' in '$tcpar_t2'.", 'AUTO_NBR');			#measurement 1
		PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$tcpar_switch".".txt", [ $tcpar_Var2, $tcpar_Var3], [ "U8", "U8"] );
		S_wait_ms( '2000', 'wait after Fast Diag start' );
		PD_StopFastDiag();
		
		$FDdata = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$tcpar_switch".".txt" );
		PD_plot_FDtrace( $FDdata, $main::REPORT_PATH . "/FDtrace_$tcpar_switch".".txt" );
		S_add_pic2html( "./FDtrace_$tcpar_switch".".png", '', "./FDtrace_$tcpar_switch".".txt.unv", 'TYPE="text/unv"' );
		EVAL_dump2file($FDdata);
    
	return 1;
}

sub TC_evaluation {

    S_teststep_expected("Compare '$tcpar_t1' and '$tcpar_t2'. The time difference ('$tcpar_t2'-'$tcpar_t1') should be below '$tcpar_time_diff'.");			#evaluation 1
	#S_teststep_detected("");
		$Time1 = EVAL_get_time_when( $FDdata, $tcpar_Var2, 'MASK','0bxxxxxxx1' );
		
		$Time2 = EVAL_get_time_when( $FDdata, $tcpar_Var3, 'MASK','0bxxxxxxx1' );
		
		$Time_difference = $Time2 - $Time1 ;
		
		if($Time_difference < $tcpar_time_diff){
			S_set_verdict( 'VERDICT_PASS');
		}else{
			S_set_verdict( 'VERDICT_FAIL');
		}
	    
	return 1;
}

sub TC_finalization {
	PD_ClearFaultMemory();
	PD_Device_configuration( 'set', [$tcpar_switch.'1']);
	S_wait_ms('TIMER_SIX_SEC');
	PD_Device_configuration( 'set', [$tcpar_switch.'2']);
	return 1;
}


1;
