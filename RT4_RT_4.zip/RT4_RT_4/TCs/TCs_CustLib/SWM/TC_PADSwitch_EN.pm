#### TEST CASE MODULE
package TC_PADSwitch_EN;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_PADSwitch_EN.pm 1.1 2019/05/29 16:08:49ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) ready_for_review EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR)(2019/07/24 19:24:12ICT) $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_DCOM;
use FuncLib_TNT_SYC_INTERFACE;
##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PADSwitch_EN

=head1 PURPOSE

To check if SDL monitoring "test" is finished, if the configured number of measurement samples, which are necessary for a state change, are executed and the SDIS_S-State is equal to the PADS-Switch SW-Position.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Turn off the ECU.

2. Set the PADS-Switch to <position>.

3.Turn ECU on.

4.Record the SDL-Monitoring, PADS-Switch Position-Counter , the end of the initalization using <Var1>, <Var2>, <Var3> <Var4> and the disable line status of the <SDIS_S>  using fast diagnosis.

5. Check if the initialization <Var3> is not completed before the configured number of measurements <measurements> are executed for the <switch> after the start of the SDL-Monitoring <Var1>, and also check if the SDIS_S <SDIS_S> in <bit> changes the state from <disabled> to <enabled> before the end of ITM.


I<B<Evaluation>>

5. The time at which <Var4> in <Var3> is set to <itm_set> is <timestamp_itm>.

The time at which <Var2> reaches value <measurements> is <timestamp_counter>.

The time at which <Var1> reaches value <sdl_set> is <timestamp_sdl>.

The time at which <SDIS_S> is set to <SDIS_clear> is <timestamp_SDIS>.

<timestamp_counter> is greater than <timestamp_sdl>.

<timestamp_itm> is greater than <timestamp_counter> and <timestamp_SDIS>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'position' => 
	SCALAR 'switch' => 
	SCALAR 'Var1' => 
	SCALAR 'Var2' => 
	SCALAR 'Var3' => 
	SCALAR 'Var4' => 
	SCALAR 'measurements' => 
	SCALAR 'SDIS_S' => 
	SCALAR 'bit' => 
	SCALAR 'SDIS_clear' => 
	SCALAR 'disabled' => 
	SCALAR 'enabled' => 
	SCALAR 'itm_set' => 
	SCALAR 'sdl_set' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check if SDL monitoring "test" is finished, if the configured number of measurement samples, which are necessary for a state change, are executed and the SDIS_S-State is equal to the PADS-Switch SW-Position.'
	
	position = '<Test Heading 1>'
	switch = '<Test Heading 2>'
	Var1 = 'rb_swma_SdlMonitoringActive_bo'#'rb_itm_StartCyclicSwmSconMon_e'
	Var2='rb_swm_SwitchInfo_ast'
	#PADS.PositionCounter_s8'
	Var3 = 'rb_itm_TestFinished_u64'
	Var4 = 'rb_itm_StartCyclicSwmSconMon_e'
	measurements = '5' #default in CA
	SDIS_S ='rb_scdl_ReturnValue_u8'
	bit = '0'
	SDIS_clear = '0'
	disabled = '1'
	enabled = '0'
	itm_set = '1'
	sdl_set = '1'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_position;
my $tcpar_switch;
my $tcpar_Var1;
my $tcpar_Var2;
my $tcpar_Var3;
my $tcpar_Var4;
my $tcpar_measurements;
my $tcpar_SDIS_S;
my $tcpar_bit;
my $tcpar_SDIS_clear;
my $tcpar_disabled;
my $tcpar_enabled;
my $tcpar_itm_set;
my $tcpar_sdl_set;

################ global parameter declaration ###################
#add any global variables here
my $FDdata1;
my $FDdata2;
my $FDdata3;
my $FDdata4;
my ($data_aref,$data_aref1,$data_aref2,$data_aref3);
my $sdl_monitor;	
my $pos_counter;	
my $status;		
my $status_SDIS_S;
my $itm_status;
my $sw_state1;
my $sw_state2;
###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_position =  GEN_Read_mandatory_testcase_parameter( 'position' );
	$tcpar_switch =  GEN_Read_mandatory_testcase_parameter( 'switch' );
	$tcpar_Var1 =  GEN_Read_mandatory_testcase_parameter( 'Var1' );
	$tcpar_Var2 =  GEN_Read_mandatory_testcase_parameter( 'Var2' );
	$tcpar_Var3 =  GEN_Read_mandatory_testcase_parameter( 'Var3' );
	$tcpar_Var4 =  GEN_Read_mandatory_testcase_parameter( 'Var4' );
	$tcpar_measurements =  GEN_Read_mandatory_testcase_parameter( 'measurements' );
	$tcpar_SDIS_S =  GEN_Read_mandatory_testcase_parameter( 'SDIS_S' );
	$tcpar_bit =  GEN_Read_mandatory_testcase_parameter( 'bit' );
	$tcpar_SDIS_clear =  GEN_Read_mandatory_testcase_parameter( 'SDIS_clear' );
	$tcpar_disabled =  GEN_Read_mandatory_testcase_parameter( 'disabled' );
	$tcpar_enabled =  GEN_Read_mandatory_testcase_parameter( 'enabled' );
	$tcpar_itm_set =  GEN_Read_mandatory_testcase_parameter( 'itm_set' );
	$tcpar_sdl_set =  GEN_Read_mandatory_testcase_parameter( 'sdl_set' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Turn off the ECU.", 'AUTO_NBR');
		if($tcpar_switch =~ /PADS/){
			$sw_state1 = DEVICE_readSwitchState_PD('PADS1');
			$sw_state2 = DEVICE_readSwitchState_PD('PADS2');
		
			LC_ECU_Off();
			S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
			
			S_teststep("Set the PADS-Switch to '$tcpar_position'.", 'AUTO_NBR');
			my ($result, $state_value, $state_unit) 	= SYC_SWITCH_get_state( 'PADS1', $tcpar_position );
			my ($result1, $state_value1, $state_unit1) 	= SYC_SWITCH_get_state( 'PADS2', $tcpar_position );
			
			if($state_unit =~ /I/){
				LC_SetCurrent('PADS1', $state_value);
			}elsif($state_unit =~ /R/){
				LC_SetResistance('PADS1', $state_value);
			}
			
			if($state_unit1 =~ /I/){
				LC_SetCurrent('PADS2', $state_value1);
			}elsif($state_unit1 =~ /R/){
				LC_SetResistance('PADS2', $state_value1);
			}
				
			S_wait_ms('SWITCH_STATE_CHANGE_TIME');
		}
		S_teststep("Turn ECU on.", 'AUTO_NBR');
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Record the SDL-Monitoring, PADS-Switch Position-Counter , the end of the initalization using '$tcpar_Var1', '$tcpar_Var2', '$tcpar_Var3' and the disable line status of the SDIS_S  using fast diagnosis.", 'AUTO_NBR');
		$data_aref = PD_ReadMemoryByName($tcpar_Var1);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD1.txt" , [$tcpar_Var1] , ['U64'] );
		PD_StopFastDiag();
		
		$data_aref1 = PD_ReadMemoryByName($tcpar_Var2);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD2.txt" , [$tcpar_Var2] , ['U64'] );
		PD_StopFastDiag();
		
		$data_aref2 = PD_ReadMemoryByName($tcpar_Var3);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD3.txt" , [$tcpar_Var3] , ['U64'] );
		PD_StopFastDiag();
		
		$data_aref3 = PD_ReadMemoryByName($tcpar_SDIS_S);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD4.txt" , [$tcpar_SDIS_S] , ['U64'] );
		PD_StopFastDiag();
		
		#plot FDtrace
		#############################################################################################
		$FDdata1 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD1.txt" );
		PD_plot_FDtrace( $FDdata1, $main::REPORT_PATH . "/AB12FD1.txt" );
		S_add_pic2html( "./AB12FD1.png", '', "./AB12FD1.txt.unv", 'TYPE="text/unv"' );
		
		
		$FDdata2 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD2.txt" );
		PD_plot_FDtrace( $FDdata2, $main::REPORT_PATH . "/AB12FD2.txt" );
		S_add_pic2html( "./AB12FD2.png", '', "./AB12FD2.txt.unv", 'TYPE="text/unv"' );
		
		$FDdata3 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD3.txt" );
		PD_plot_FDtrace( $FDdata3, $main::REPORT_PATH . "/AB12FD3.txt" );
		S_add_pic2html( "./AB12FD3.png", '', "./AB12FD3.txt.unv", 'TYPE="text/unv"' );
		
		$FDdata4 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD4.txt" );
		PD_plot_FDtrace( $FDdata4, $main::REPORT_PATH . "/AB12FD4.txt" );
		S_add_pic2html( "./AB12FD4.png", '', "./AB12FD4.txt.unv", 'TYPE="text/unv"' );
		#############################################################################################
		
		#changing array ref to hex
		$sdl_monitor	= S_aref2hex($data_aref);
		$pos_counter 	= S_aref2hex($data_aref1);
		$status 		= S_aref2hex($data_aref2);
		$status_SDIS_S  = S_aref2hex($data_aref3);
		
		#converting hex to dec
		$sdl_monitor  	= hex($sdl_monitor);
		$pos_counter 	= hex($pos_counter);
		$status_SDIS_S  = hex($status_SDIS_S);
		
		
		S_w2rep("Status : $status ","Purple");
		
		#Get_bit_val function use to capture the bit status(0 or 1) from the input hex value
		
		$itm_status = &Get_bit_val($status,26); 		#26 is the bit index position for 'rb_itm_StartCyclicSwm_e' in 'rb_itm_TestFinished_u64'
	
		S_w2rep("ITM Status: $itm_status ","Purple");
		
		return 1;
}

sub TC_evaluation {

	S_teststep_expected("Check if the initialization '$tcpar_Var2' is not completed before the configured number of measurements are executed for the PADS-Switch after the start of the SDL-Monitoring '$tcpar_Var1', and also check if the SDIS_S changes the state from disabled to enabled before the end of ITM.");			#evaluation 1
	S_teststep_detected("Detected value for ITM status is $itm_status");
		EVAL_evaluate_value("itm status is '$itm_status' captured using '$tcpar_Var3'", $itm_status, "==", $tcpar_itm_set )unless $main::opt_offline;

	return 1;
}

sub TC_finalization {
	PD_ClearFaultMemory();
	return 1;
}

############# local subroutine ##################################

sub Get_bit_val{
	my $hex_val 			= shift;
	my $bit_index_position 	= shift;
	$hex_val =~ s/^0x//;	
	my $position;
	my $index;
	my $Decimal;
	my $nibble;
	
	my @array = split(//,$hex_val);
	if(($bit_index_position % 4) == 0){
		$position = int($bit_index_position / 4);
	}else{
		$position = int($bit_index_position / 4) + 1;
	}
	$index = 16 - $position;
	
	$Decimal = hex($array[$index]);
	$nibble = sprintf("%04b",$Decimal);
	my @bitval = split(//,$nibble);
	$bit_index_position = $bit_index_position + 1;

	my $rem = $bit_index_position % 4;
	if($rem == 0){
		return $bitval[0];
	}elsif($rem == 3){
		return $bitval[1];
	}elsif($rem == 2){
		return $bitval[2];
	}elsif($rem == 1){
		return $bitval[3];
	}

}

1;
