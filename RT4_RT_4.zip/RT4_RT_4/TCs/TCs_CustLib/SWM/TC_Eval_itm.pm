#### TEST CASE MODULE
package TC_Eval_itm;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_Eval_itm.pm 1.1 2019/06/01 12:43:53ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) ready_for_review EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR)(2019/07/24 19:24:07ICT) $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_DCOM;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_Eval_itm

=head1 PURPOSE

To check the cyclic switch evaluation of all switches during initialization

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Start with fault free ECU.

2. Reset the ECU and capture the itm status using <Var1> and <Var2> in PS diag.

3.Capture the switch position counter and switch status using <Var3>  <Var4> and <Var5> in fast diagnosis.


I<B<Evaluation>>

2.The itm <Var5> with <var5_offset> and <var5_byte> in <Var1> and <Var2> gets set to started <started> and  finished <finished> in the ITM.

The time <timestamp_itm> when the cyclic switch evaluation <Var5> with <var5_offset> and <var5_byte> in <Var2> gets set to finished <finished> in the ITM is checked.

3. The status of the <switch> changed from <status_value_init>  to <status_value_limit>  at the time <timestamp_status>.

  The position counter reaches the limit  <counter_limit> at <time_stamp_counter>.

 Compare <timestamp_status> and <time_stamp_counter>. The time difference  should be <time_diff>.

 Compare <timestamp_itm> and <timestamp_status>. The time difference should be <time_diff_itm>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR '_FastDiagVar2' => 
	SCALAR '_FastDiagVar3' => 
	LIST '_FD_GetTime_T3' => 
	LIST '_FD_GetTime_T4' => 
	SCALAR 'Purpose' => 
	SCALAR 'switch' => 
	SCALAR 'Var1' => 
	SCALAR 'Var2' => 
	SCALAR 'Var3' => 
	SCALAR 'Var4' => 
	SCALAR 'Var5' => 
	SCALAR 'status_value_init' => 
	SCALAR 'status_value_final' => 
	SCALAR 'counter_limit' => 
	SCALAR 'var5_offset' => 
	SCALAR 'var5_byte' => 
	SCALAR 'started' => 
	SCALAR 'finished' => 
	SCALAR 'time_diff' => 
	SCALAR 'time_diff_itm' => 
	SCALAR 'USE_FDIAG_RECORD' => 
	SCALAR '_FastDiagVar0' => 
	SCALAR '_FastDiagVar1' => 
	LIST '_FD_GetTime_T1' => 
	LIST '_FD_GetTime_T2' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To check the cyclic switch evaluation of all switches during initialization'.
	switch = '<Test Heading 1>'
	Var1 = 'rb_itm_TestStarted_u64'
	Var2 = 'rb_itm_TestFinished_u64'
	Var3 = 'rb_swm_SwitchInfo_ast' #for position counter
	#<switch>.PositionCounter_s8' 
	Var4 = 'rb_swm_SwitchInfo_ast' # for status filtered
	#<switch>.StatusFiltered_en'
	 Var5 ='rb_itm_StartCyclicSwm_e' 
	status_value_init = '0'
	status_value_final = '1'
	counter_limit = '5'
	var5_offset = '-3'
	var5_byte ='1'
	started = '0bxx1x'
	finished = '0bxx1x'
	time_diff = '0'
	time_diff_itm= '10' #status of the switch changes latest at the time when itm is set to finished in itm.
	 USE_FDIAG_RECORD        = 'yes'
	_FastDiagVar0           = 'rb_itm_TestStarted_u64'
	_FastDiagVar1           = 'rb_itm_TestFinished_u64'
	 _FD_GetTime_T1          = @('T0', 'rb_itm_TestStarted_u64',  '==', '0x019E727E4007023E')
	   _FD_GetTime_T2          = @('T1', 'rb_itm_TestFinished_u64',  '==', '0x019E727E4007023E')
	 _FastDiagVar2           = 'rb_swm_SwitchInfo_ast(0).PositionCounter_s8'
	 _FastDiagVar3 		= 'rb_swm_SwitchInfo_ast(0).StatusFiltered_en' 
	
	 _FD_GetTime_T3          = @('T2', 'rb_swm_SwitchInfo_ast(0).PositionCounter_s8',  '==', '5')
	
	 _FD_GetTime_T4          = @('T3', 'rb_swm_SwitchInfo_ast(0).StatusFiltered_en',  '==', '1') 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_switch;
my $tcpar_Var1;
my $tcpar_Var2;
my $tcpar_Var3;
my $tcpar_Var4;
my $tcpar_Var5;
my $tcpar_status_value_init;
my $tcpar_status_value_final;
my $tcpar_counter_limit;
my $tcpar_var5_offset;
my $tcpar_var5_byte;
my $tcpar_started;
my $tcpar_finished;
my $tcpar_time_diff;
my $tcpar_time_diff_itm;
my $tcpar_USE_FDIAG_RECORD;
my $tcpar__FastDiagVar0;
my $tcpar__FastDiagVar1;
my $tcpar__FD_GetTime_T1;
my $tcpar__FD_GetTime_T2;
my $tcpar__FastDiagVar2;
my $tcpar__FastDiagVar3;
my $tcpar__FD_GetTime_T3;
my $tcpar__FD_GetTime_T4;

################ global parameter declaration ###################
#add any global variables here
my $FDdata1;
my $FDdata2;
my $FDdata3;
my $FDdata4;
my $data_aref;
my $data_aref1;
my $data_aref2;
my $data_aref3;
my $status1;
my $status2;
my $itm_status1;
my $itm_status2;
my $pos_counter;
my $sw_status1;

###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_switch =  GEN_Read_mandatory_testcase_parameter( 'switch' );
	$tcpar_Var1 =  GEN_Read_mandatory_testcase_parameter( 'Var1' );
	$tcpar_Var2 =  GEN_Read_mandatory_testcase_parameter( 'Var2' );
	$tcpar_Var3 =  GEN_Read_mandatory_testcase_parameter( 'Var3' );
	$tcpar_Var4 =  GEN_Read_mandatory_testcase_parameter( 'Var4' );
	$tcpar_Var5 =  GEN_Read_mandatory_testcase_parameter( 'Var5' );
	$tcpar_status_value_init =  GEN_Read_mandatory_testcase_parameter( 'status_value_init' );
	$tcpar_status_value_final =  GEN_Read_mandatory_testcase_parameter( 'status_value_final' );
	$tcpar_counter_limit =  GEN_Read_mandatory_testcase_parameter( 'counter_limit' );
	$tcpar_var5_offset =  GEN_Read_mandatory_testcase_parameter( 'var5_offset' );
	$tcpar_var5_byte =  GEN_Read_mandatory_testcase_parameter( 'var5_byte' );
	$tcpar_started =  GEN_Read_mandatory_testcase_parameter( 'started' );
	$tcpar_finished =  GEN_Read_mandatory_testcase_parameter( 'finished' );
	$tcpar_time_diff =  GEN_Read_mandatory_testcase_parameter( 'time_diff' );
	$tcpar_time_diff_itm =  GEN_Read_mandatory_testcase_parameter( 'time_diff_itm' );
	$tcpar_USE_FDIAG_RECORD =  GEN_Read_mandatory_testcase_parameter( 'USE_FDIAG_RECORD' );
	$tcpar__FastDiagVar0 =  GEN_Read_mandatory_testcase_parameter( '_FastDiagVar0' );
	$tcpar__FastDiagVar1 =  GEN_Read_mandatory_testcase_parameter( '_FastDiagVar1' );
	$tcpar__FD_GetTime_T1 =  GEN_Read_mandatory_testcase_parameter( '_FD_GetTime_T1' );
	$tcpar__FD_GetTime_T2 =  GEN_Read_mandatory_testcase_parameter( '_FD_GetTime_T2' );
	$tcpar__FastDiagVar2 =  GEN_Read_mandatory_testcase_parameter( '_FastDiagVar2' );
	$tcpar__FastDiagVar3 =  GEN_Read_mandatory_testcase_parameter( '_FastDiagVar3' );
	$tcpar__FD_GetTime_T3 =  GEN_Read_mandatory_testcase_parameter( '_FD_GetTime_T3' );
	$tcpar__FD_GetTime_T4 =  GEN_Read_mandatory_testcase_parameter( '_FD_GetTime_T4' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Start with fault free ECU.", 'AUTO_NBR');
		PD_ClearFaultMemory();
		S_wait_ms('2000');
		
	S_teststep("Reset the ECU and capture the itm status using '$tcpar_Var1' and '$tcpar_Var2' in PS diag.", 'AUTO_NBR');			#measurement 1
		LC_ECU_Reset();
		
		$data_aref = PD_ReadMemoryByName($tcpar_Var1);
		$data_aref1 = PD_ReadMemoryByName($tcpar_Var2);
		
		$status1 = S_aref2hex($data_aref);
		$status2 = S_aref2hex($data_aref1);
		S_w2rep("ITM Status 1 : $data_aref = $status1 ","Purple");
		S_w2rep("ITM Status 2 : $data_aref1 = $status2 ","Purple");

		
		#Get_bit_val function use to capture the bit status(0 or 1) from the input hex value
		
		$itm_status1 = &Get_bit_val($status1,26); 		#26 is the bit index position for 'rb_itm_StartCyclicSwm_e' in 'rb_itm_TestStarted_u64'
		$itm_status2 = &Get_bit_val($status2,26); 		#26 is the bit index position for 'rb_itm_StartCyclicSwm_e' in 'rb_itm_TestFinished_u64'
		
		S_w2rep("ITM Status 1 : $data_aref = $itm_status1 ","Purple");
		S_w2rep("ITM Status 2 : $data_aref1 = $itm_status2 ","Purple");
						
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD1.txt" , [$tcpar_Var1] , ['U64'] );
		PD_StopFastDiag();
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD2.txt" , [$tcpar_Var2] , ['U64'] );
		PD_StopFastDiag();
		
		$FDdata1 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD1.txt" );
		PD_plot_FDtrace( $FDdata1, $main::REPORT_PATH . "/AB12FD1.txt" );
		S_add_pic2html( "./AB12FD1.png", '', "./AB12FD1.txt.unv", 'TYPE="text/unv"' );
		
		
		$FDdata2 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD2.txt" );
		PD_plot_FDtrace( $FDdata2, $main::REPORT_PATH . "/AB12FD2.txt" );
		S_add_pic2html( "./AB12FD2.png", '', "./AB12FD2.txt.unv", 'TYPE="text/unv"' );
		
		PD_ReadFaultMemory();

	S_teststep("Capture the switch position counter and switch status using '$tcpar_Var3'  '$tcpar_Var4' in fast diagnosis.", 'AUTO_NBR');			#measurement 2
		$data_aref2 = PD_ReadMemoryByName($tcpar__FastDiagVar2);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD3.txt" , [$tcpar__FastDiagVar2] , ['U32'] );
		PD_StopFastDiag();
		
		$data_aref3 = PD_ReadMemoryByName($tcpar__FastDiagVar3);
		PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD4.txt" , [$tcpar__FastDiagVar3] , ['U32'] );
		PD_StopFastDiag();
		
		$pos_counter = S_aref2hex($data_aref2);
		$sw_status1  = S_aref2hex($data_aref3);
		
		$pos_counter = hex($pos_counter);
		$sw_status1  = hex($sw_status1);
		
		S_w2rep("pos counter : $data_aref2 = $pos_counter ","Purple");
		S_w2rep("sw Status 1 : $data_aref3 = $sw_status1 ","Purple");
		
		$FDdata3 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD3.txt" );
		PD_plot_FDtrace( $FDdata3, $main::REPORT_PATH . "/AB12FD3.txt" );
		S_add_pic2html( "./AB12FD3.png", '', "./AB12FD3.txt.unv", 'TYPE="text/unv"' );
		
		
		$FDdata4 = PD_get_FDtrace( $main::REPORT_PATH . "/AB12FD4.txt" );
		PD_plot_FDtrace( $FDdata4, $main::REPORT_PATH . "/AB12FD4.txt" );
		S_add_pic2html( "./AB12FD4.png", '', "./AB12FD4.txt.unv", 'TYPE="text/unv"' );
		
		PD_ReadFaultMemory();

	return 1;
}

sub TC_evaluation {
   
	S_teststep_expected("The itm '$tcpar_Var5' should pass during init.");			#evaluation 1
	S_teststep_detected("Detected value for $tcpar_Var1 is :$itm_status1  and for $tcpar_Var2 is :$itm_status2");
		EVAL_evaluate_value("itm status is '$itm_status1' captured using '$tcpar_Var1'", $itm_status1, "==", $tcpar_var5_byte )unless $main::opt_offline; 
		EVAL_evaluate_value("itm status is '$itm_status2' captured using '$tcpar_Var2'", $itm_status2, "==", $tcpar_var5_byte )unless $main::opt_offline; 
	
	
	S_teststep_expected("The status of the '$tcpar_switch' changed at the time when the position counter reaches the limit or latest at the time when the cyclic switch evaluation gets set to finished in the ITM.");			#evaluation 2
	S_teststep_detected("Detected status of the '$tcpar_switch' is $sw_status1");
		EVAL_evaluate_value("Status of the '$tcpar_switch' ", $sw_status1, "==", $tcpar_status_value_final )unless $main::opt_offline;
	
	return 1;
}

sub TC_finalization {
	PD_ClearFaultMemory();
	return 1;
}

############# local subroutine ##################################

sub Get_bit_val{
	my $hex_val 			= shift;
	my $bit_index_position 	= shift;
	$hex_val =~ s/^0x//;	
	my $position;
	my $index;
	my $Decimal;
	my $nibble;
	
	my @array = split(//,$hex_val);
	if(($bit_index_position % 4) == 0){
		$position = int($bit_index_position / 4);
	}else{
		$position = int($bit_index_position / 4) + 1;
	}
	$index = 16 - $position;
	
	$Decimal = hex($array[$index]);
	$nibble = sprintf("%04b",$Decimal);
	my @bitval = split(//,$nibble);
	$bit_index_position = $bit_index_position + 1;

	my $rem = $bit_index_position % 4;
	if($rem == 0){
		return $bitval[0];
	}elsif($rem == 3){
		return $bitval[1];
	}elsif($rem == 2){
		return $bitval[2];
	}elsif($rem == 1){
		return $bitval[3];
	}

}

1;
