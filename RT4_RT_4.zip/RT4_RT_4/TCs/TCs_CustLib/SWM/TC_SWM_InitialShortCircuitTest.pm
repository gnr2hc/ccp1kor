#### TEST CASE MODULE
package TC_SWM_InitialShortCircuitTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: SWM/TC_SWM_InitialShortCircuitTest.pm 1.2 2020/05/22 18:53:53ICT Purushotham Reddy Chinnasani (RBEI/ESA-PP2) (UCP5KOR) develop  $;
#TS version - This script is based on TS_SWM_SwitchMgt v3.27

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to test the behaviour of switches for initial short circuits";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_InitialShortCircuitTest

=head1 PURPOSE

to test the behaviour of switches for initial short circuits

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. StandardPrepNoFault

2. Set the switch to positionB state


I<B<Stimulation and Measurement>>

1. Switch Off the ECU and create a short to Vbat on the switch and then switch ON the ECU

2. Read the fault recorder, WL status, switch position and status

3. Remove the short and wait for dequalification time

4. Read the fault recorder, WL status, switch position and status

5. Reset the ECU

6. Read the switch position and status

7. Switch Off the ECU and create a short to Gnd on the switch and then switch ON the ECU

8. Read the fault recorder, WL status, switch position and status

9. Remove the short and wait for dequalification time

10. Read the fault recorder, WL status, switch position and status


I<B<Evaluation>>

2. 

Short2Bat fault is qualified in the fault recorder

WL is ON

default position is reported

status is 'fault'

4. 

Short2Bat fault is dequalified in the fault recorder

WL is ON

default position is reported

status is 'fault'

6. 

state is positionB

status is 'valid'

8. 

Short2Gnd fault is qualified in the fault recorder

WL is ON

default position is reported

status is 'fault'

10. 

Short2Gnd fault is dequalified in the fault recorder

WL is ON

default position is reported

status is 'fault'


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'Device' => the switch device (SW1, SW2..)
	SCALAR 'Switchstate_val_default' => value of switch position when the switch is faulty (default position)


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the behaviour in case of initial switch short circuits'
	
	Device = 'SW1'
	Switchstate_val_fault  = '1' #default value

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_Switchstate_val_default;

################ global parameter declaration ###################
#add any global variables here
my $switchName;
my $Switch_positionA;
my $Switch_positionB;
my $SW_state_var;
my $SW_status_var;
my $flt_mem_step2;
my $WL_status_step2;
my $sw_position_step2;
my $sw_status_step2;
my $flt_mem_step5;
my $WL_status_step5;
my $sw_position_step5;
my $sw_status_step5;
my $sw_position_step7;
my $sw_status_step7;
my $flt_mem_step9;
my $WL_status_step9;
my $sw_position_step9;
my $sw_status_step9;
my $flt_mem_step11;
my $WL_status_step11;
my $sw_position_step11;
my $sw_status_step11;
my $Switchstate_value_default;  

###############################################################

sub TC_set_parameters {

	$tcpar_purpose               = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_Device                = GEN_Read_mandatory_testcase_parameter('Device');
	$tcpar_Switchstate_val_default = GEN_Read_mandatory_testcase_parameter('Switchstate_val_default');

	$switchName       = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_Device);

	
	unless(defined $switchName){
		$switchName = 'NONE';
	}
	
	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();
	
	$Switch_positionA = DEVICE_fetchSwitchState( $switchName, 'positionA' );
	$Switch_positionB = DEVICE_fetchSwitchState( $switchName, 'positionB' );

	my $deviceProperties = DEVICE_fetchDeviceInfo($switchName);
	$Switchstate_value_default = $deviceProperties->{$tcpar_Switchstate_val_default};
	$SW_state_var  = $deviceProperties->{'State_PD'};
	$SW_status_var = $deviceProperties->{'Status_PD'};

	return 1;
}

sub TC_initialization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	S_w2rep("Step 1. StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	S_w2rep("Step 2. Set the switch to positionA state");
	DEVICE_setDeviceState( $switchName, $Switch_positionA );

	return 1;
}

sub TC_stimulation_and_measurement {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	S_w2rep("Step 1. Switch Off the ECU and create a short to Vbat on the switch and then switch ON the ECU");
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	DEVICE_setDeviceState( $switchName, 'Short2Bat' );
	LC_ECU_On();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after power on' );

	S_w2rep("Step 2. Read the fault recorder, WL status, switch position and status");
	$flt_mem_step2     = FM_PD_readFaultMemory();
	$WL_status_step2   = GEN_readWLStatus();
	$sw_position_step2 = DEVICE_readSwitchState_PD($switchName);
	$sw_status_step2   = DEVICE_readSwitchStatus_PD($switchName);

	S_w2rep("Step 3. Remove the short and wait for dequalification time");
	DEVICE_resetDeviceState( $switchName, 'Short2Bat' );
	S_wait_ms( 6000, 'wait after fault removal' );

	S_w2rep("Step 4. Read the fault recorder, WL status, switch position and status");
	$flt_mem_step5     = FM_PD_readFaultMemory();
	$WL_status_step5   = GEN_readWLStatus();
	$sw_position_step5 = DEVICE_readSwitchState_PD($switchName);
	$sw_status_step5   = DEVICE_readSwitchStatus_PD($switchName);

	S_w2rep("Step 5. Reset the ECU");
	PD_ClearFaultMemory( );
	S_wait_ms( 6000, 'wait after fault removal' );
	GEN_Power_on_Reset();
	PD_ECUlogin();

	S_w2rep("Step 6. Read the switch position and status");
	$sw_position_step7 = DEVICE_readSwitchState_PD($switchName);
	$sw_status_step7   = DEVICE_readSwitchStatus_PD($switchName);
	
	if(($switchName eq 'PADS2') || ($switchName =~ /^OPS/))
	{
	 S_w2rep("Step 7:Short to Gnd is not applicable  for Mechanical and Resistive OPS Switches",'blue');
	}
	else{

	S_w2rep("Step 7. Switch Off the ECU and create a short to Gnd on the switch and then switch ON the ECU");
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	DEVICE_setDeviceState( $switchName, 'Short2Gnd' );
	LC_ECU_On();
	S_wait_ms( 'TIMER_ECU_READY', 'wait after power on' );

	S_w2rep("Step 8. Read the fault recorder, WL status, switch position and status");
	$flt_mem_step9     = FM_PD_readFaultMemory();
	$WL_status_step9   = GEN_readWLStatus();
	$sw_position_step9 = DEVICE_readSwitchState_PD($switchName);
	$sw_status_step9   = DEVICE_readSwitchStatus_PD($switchName);

	S_w2rep("Step 9. Remove the short and wait for dequalification time");
	DEVICE_resetDeviceState( $switchName, 'Short2Gnd' );
	S_wait_ms( 6000, 'wait after fault removal' );

	S_w2rep("Step 10. Read the fault recorder, WL status, switch position and status");
	$flt_mem_step11     = FM_PD_readFaultMemory();
	$WL_status_step11   = GEN_readWLStatus();
	$sw_position_step11 = DEVICE_readSwitchState_PD($switchName);
	$sw_status_step11   = DEVICE_readSwitchStatus_PD($switchName);
	}
	return 1;
}

sub TC_evaluation {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	my $status_ref1;
	my $status_ref2;
	my $statusFault_val     = DEVICE_fetchExpectedSwitchState_PD('STATUS_FAULT');
	my $statusValid_val     = DEVICE_fetchExpectedSwitchState_PD('STATUS_VALID');
	my $state_positionA_val = DEVICE_fetchExpectedSwitchState_PD('STATE_POSITIONA');

	S_w2rep("Evaluation for Step 2. ");
	S_w2rep("Short2Bat fault is qualified in the fault recorder");
	$status_ref1->{'Short2Bat'} = '0bxxxxx111';
	FM_checkDeviceFaults( $flt_mem_step2, $switchName, $status_ref1 );

	S_w2rep("WL is ON");
	EVAL_evaluate_string( "WL status", 'Lamp SysWI is ON', $WL_status_step2 );

	S_w2rep("default position is reported");
	EVAL_evaluate_value( "SW position", $sw_position_step2, '==', $Switchstate_value_default );

	S_w2rep("status is 'fault'");
	EVAL_evaluate_value( "SW status", $sw_status_step2, '==', $statusFault_val );

	S_w2rep("Evaluation for Step 4. ");
	S_w2rep("Short2Bat fault is dequalified in the fault recorder");
	$status_ref1->{'Short2Bat'} = '0bxxxxx110';
	FM_checkDeviceFaults( $flt_mem_step5, $switchName, $status_ref1 );

	S_w2rep("WL is ON");
	EVAL_evaluate_string( "WL status", 'Lamp SysWI is ON', $WL_status_step5 );

	S_w2rep("default position is reported");
	EVAL_evaluate_value( "SW position", $sw_position_step5, '==', $Switchstate_value_default );

	S_w2rep("status is 'fault'");
	EVAL_evaluate_value( "SW status", $sw_status_step5, '==', $statusFault_val );

	S_w2rep("Evaluation for Step 6. ");
	S_w2rep("state is positionA");
	EVAL_evaluate_value( "SW position", $sw_position_step7, '==', $state_positionA_val );

	S_w2rep("status is 'valid'");
	EVAL_evaluate_value( "SW status", $sw_status_step7, '==', $statusValid_val );
	
	if(($switchName eq 'PADS2') || ($switchName =~ /^OPS/))
	{
	 S_w2rep("Step 8:Short to Gnd is not applicable for Mechanical and Resistive OPS Switches",'blue');
	}
	else{

	S_w2rep("Evaluation for Step 8. ");
	S_w2rep("Short2Gnd fault is qualified in the fault recorder");
	$status_ref2->{'Short2Gnd'} = '0bxxxxx111';
	FM_checkDeviceFaults( $flt_mem_step9, $switchName, $status_ref2 );

	S_w2rep("WL is ON");
	EVAL_evaluate_string( "WL status", 'Lamp SysWI is ON', $WL_status_step9 );

	S_w2rep("default position is reported");
	EVAL_evaluate_value( "SW position", $sw_position_step9, '==', $Switchstate_value_default );

	S_w2rep("status is 'fault'");
	EVAL_evaluate_value( "SW status", $sw_status_step9, '==', $statusFault_val );

	S_w2rep("Evaluation for Step 10. ");
	S_w2rep("Short2Gnd fault is dequalified in the fault recorder");
	$status_ref2->{'Short2Gnd'} = '0bxxxxx110';
	FM_checkDeviceFaults( $flt_mem_step11, $switchName, $status_ref2 );

	S_w2rep("WL is ON");
	EVAL_evaluate_string( "WL status", 'Lamp SysWI is ON', $WL_status_step11 );

	S_w2rep("default position is reported");
	EVAL_evaluate_value( "SW position", $sw_position_step11, '==', $Switchstate_value_default );

	S_w2rep("status is 'fault'");
	EVAL_evaluate_value( "SW status", $sw_status_step11, '==', $statusFault_val );
    }
	return 1;
}

sub TC_finalization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	return 1;
}

sub CheckValidDevice {

	if ( $switchName eq 'NONE' ) {
		S_w2rep( "Valid switch is not configured for this AIN Stop further execution\n", 'orange' );
		$PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $tcpar_Device";
		return 1;
	}
}

1;
