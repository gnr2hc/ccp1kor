#### TEST CASE MODULE
package TC_SWM_StateChangeSamples;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: SWM/TC_SWM_StateChangeSamples.pm 1.6 2020/06/17 17:29:22ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWM_SwitchMgt> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <3.142> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use FuncLib_TNT_SYC_INTERFACE;
use FuncLib_TNT_DEVICE;
##################################

our $PURPOSE = "To test Switch state change based on number of samples";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_StateChangeSamples

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the switch to <state1>

2. Configure <Number_Of_Samples_var> to <Number_Of_Samples>

3. In Fast diagnosis, Read the switch state continuously and change the switch state to <state2>, maintain this state only for (<Number_Of_Samples> - 1)*<Switch_Cycle_Time> 

i.e. Change to <state1> state after (<Number_Of_Samples> - 1 )*<Switch_Cycle_Time>

4  In Fast diagnosis, Read the switch state continuously and change the switch state to <state2>, maintain this state for more than <Number_Of_Samples>*<Switch_Cycle_Time>


I<B<Evaluation>>

3. Switch state remains as <State_val_state1>

4. Switch state remains as <State_val_state1> for <Number_Of_Samples - 1> *<Switch_Cycle_Time> and after that it changes to <State_val_state2> within <Number_Of_Samples> *<Switch_Cycle_Time>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Number_Of_Samples_var' => 
	SCALAR 'purpose' => 
	SCALAR 'Device' => 
	SCALAR 'state1' => 
	SCALAR 'state2' => 
	SCALAR 'Number_Of_Samples' => 
	SCALAR 'Switch_Cycle_Time' => 
	SCALAR 'State_val_state1' => 
	SCALAR 'State_val_state2' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test Switch state change based on number of samples: Valid state'
	
	Device = '<Test Heading>'
	state1 = 'POSITIONB'
	state2 = 'POSITIONA'
	
	Number_Of_Samples = '5'
	Switch_Cycle_Time = '30'
	
	
	State_val_state1 = 'STATE_POSITIONB'
	State_val_state2 = 'STATE_POSITIONA'
	
	#Note: the above parameters are declared in SWM constants file
	Number_Of_Samples_var = 'rb_swm_Types_cast(4).changeCntrLimit_u8'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_state1;
my $tcpar_state2;
my $tcpar_Number_Of_Samples;
my $tcpar_Switch_Cycle_Time;
my $tcpar_State_val_state1;
my $tcpar_State_val_state2;
my $tcpar_Number_Of_Samples_var;

################ global parameter declaration ###################
#add any global variables here
my ($FDtrace1,$FDtrace2,$FDdata1,$FDdata2 ,$switchtype ,$state1,$state2,$state1_val,$VERDICT,$state2_val,$SW_state_var,$No_of_sample_count,$device);
my ($Real,$Monitored_ID,$Prog);
my $fault = 'OpenLine';

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_state1 =  GEN_Read_mandatory_testcase_parameter( 'state1' );
	$tcpar_state2 =  GEN_Read_mandatory_testcase_parameter( 'state2' );
	$tcpar_Number_Of_Samples =  GEN_Read_mandatory_testcase_parameter( 'Number_Of_Samples' );
	$tcpar_Switch_Cycle_Time =  GEN_Read_mandatory_testcase_parameter( 'Switch_Cycle_Time' );
	$tcpar_State_val_state1 =  GEN_Read_mandatory_testcase_parameter( 'State_val_state1' );
	$tcpar_State_val_state2 =  GEN_Read_mandatory_testcase_parameter( 'State_val_state2' );
	$tcpar_Number_Of_Samples_var =  GEN_Read_mandatory_testcase_parameter( 'Number_Of_Samples_var' );

	$No_of_sample_count = S_aref2hex(PD_ReadMemoryByName($tcpar_Number_Of_Samples_var));
	$No_of_sample_count	= S_aref2dec([$No_of_sample_count],U16);							

	S_w2rep("Sample Count : $No_of_sample_count",'Orange');
	
	$device = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_Device);
	S_w2rep("fetched device : $device",'Orange');
	
	unless(defined $device and $device ne '' and $device ne 'NONE'){	
		
			S_w2rep ("switch having label $tcpar_Device is  not present in the project");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
		
	}
	else{
	
		$switchtype = DEVICE_fetchSwitchType($device);
		
		if($switchtype =~ m/mech/i ){    #checking for mechanical switch
		
			S_w2rep ("test case is not required for  mechanical switch: $device");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
	
		}
		
		($Real,$Monitored_ID,$Prog) = PD_get_device_config($device);
		S_w2rep("presence bit :$Real",'Purple');
	
		if($Real eq '0'){                        #checking presence bit 
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
		}
	
	}	
	

	return 1;
}

sub TC_initialization {
	
	return 1 if ($VERDICT);

		S_teststep("StandardPrepNoFault", 'AUTO_NBR');
		GEN_StandardPrepNoFault();
	

	return 1;
}

sub TC_stimulation_and_measurement {
	
	return 1 if ($VERDICT);
		
		S_teststep("Set the switch to '$tcpar_state1'", 'AUTO_NBR');
	
		$state1_val = DEVICE_fetchExpectedSwitchState_PD($tcpar_State_val_state1);  
		$state2_val = DEVICE_fetchExpectedSwitchState_PD($tcpar_State_val_state2);  
		S_w2rep("state1 = $state1_val, state2 = $state2_val");
		
		SetState($tcpar_state1);
		S_wait_ms('TIMER_SIX_SEC');
		
		S_teststep("Configure '$tcpar_Number_Of_Samples_var' to '$tcpar_Number_Of_Samples'", 'AUTO_NBR');
		
		$tcpar_Number_Of_Samples = $No_of_sample_count;
		S_w2rep("No. of samples :'$tcpar_Number_Of_Samples'");
		
		S_teststep("In Fast diagnosis, Read the switch state continuously and change the switch state to '$tcpar_state2', maintain this state only for ('$tcpar_Number_Of_Samples' - 1)*'$tcpar_Switch_Cycle_Time' ", 'AUTO_NBR');			#measurement 1
		
		S_teststep("i.e. Change to '$tcpar_state1' state after ('$tcpar_Number_Of_Samples' - 1 )*'$tcpar_Switch_Cycle_Time'", 'AUTO_NBR');
		
		$SW_state_var = ReadFastDiagVariable($tcpar_state2);
		$FDtrace1 = "FDtrace1".time();    
		PD_StartFastDiagName($main::REPORT_PATH."/$FDtrace1.txt",[$SW_state_var],["U8"]);
		
		if($tcpar_state2 =~ m/Openline/i){
			DEVICE_setDeviceState ($device, $tcpar_state2);
		}else{
			SetState ($tcpar_state2);
		}
		my $waittime1 = ($tcpar_Number_Of_Samples - 1) * $tcpar_Switch_Cycle_Time ;
		S_wait_ms($waittime1);  #wait for 1 less than no of samples
		
		SetState ($tcpar_state1);
		my $waittime2 = (($tcpar_Number_Of_Samples + 1) * $tcpar_Switch_Cycle_Time) + 100 ;
		S_wait_ms($waittime2);  #wait for more than no of samples     
		PD_StopFastDiag();
		
		$FDdata1 = PD_get_FDtrace($main::REPORT_PATH."/$FDtrace1.txt");
		PD_plot_FDtrace($FDdata1,$main::REPORT_PATH."/$FDtrace1.txt");
		S_add_pic2html ( "./$FDtrace1.png",'', "./$FDtrace1.txt.unv",'TYPE="text/unv"');
		EVAL_dump2file($FDdata1);
		
		S_wait_ms('TIMER_SIX_SEC');
		
		###
		S_teststep_expected("Switch state remains as '$tcpar_State_val_state1'");			#evaluation 1
		S_teststep_detected("Detected switch state is : $SW_state_var");
		EVAL_evaluate_value_around_time ($FDdata1 , (($tcpar_Number_Of_Samples*$tcpar_Switch_Cycle_Time ) -30) , $SW_state_var , "==", $state1_val ); 
		
		
		S_teststep("In Fast diagnosis, Read the switch state continuously and change the switch state to '$tcpar_state2', maintain this state for more than '$tcpar_Number_Of_Samples'*'$tcpar_Switch_Cycle_Time'", 'AUTO_NBR');			#measurement 2
		
		$FDtrace2 = "FDtrace2".time();    
		PD_StartFastDiagName($main::REPORT_PATH."/$FDtrace2.txt",[$SW_state_var],["U8"]);
		
		if($tcpar_state2 =~ m/Openline/i){
			
			DEVICE_setDeviceState ($device, $tcpar_state2);
		}else{
			SetState ($tcpar_state2);
		}
		my $waittime3 = (($tcpar_Number_Of_Samples + 1) * $tcpar_Switch_Cycle_Time) + 100 ;
		S_wait_ms($waittime3);  #wait for more than no of samples        
		PD_StopFastDiag();
		
		$FDdata2 = PD_get_FDtrace($main::REPORT_PATH."/$FDtrace2.txt");
		PD_plot_FDtrace($FDdata2,$main::REPORT_PATH."/$FDtrace2.txt");
		S_add_pic2html ( "./$FDtrace2.png",'', "./$FDtrace2.txt.unv",'TYPE="text/unv"');
		EVAL_dump2file($FDdata2);
		
		
		S_teststep_expected("Switch state remains as '$tcpar_State_val_state1' for '$tcpar_Number_Of_Samples - 1' *'$tcpar_Switch_Cycle_Time' and after that it changes to '$tcpar_State_val_state2' within '$tcpar_Number_Of_Samples' *'$tcpar_Switch_Cycle_Time'");			#evaluation 2
		S_teststep_detected("Detected switch state is :$SW_state_var");
		
		if($tcpar_state2 =~ m/Openline/i){
			EVAL_evaluate_value_around_time ($FDdata2 ,(($tcpar_Number_Of_Samples)*$tcpar_Switch_Cycle_Time*2), $SW_state_var , "==", $state2_val );   
		}
		else{
			EVAL_evaluate_value_around_time ($FDdata2 , (($tcpar_Number_Of_Samples-1)*$tcpar_Switch_Cycle_Time ) , $SW_state_var , "==", $state1_val );
			EVAL_evaluate_value_around_time ($FDdata2 ,(($tcpar_Number_Of_Samples)*$tcpar_Switch_Cycle_Time*2), $SW_state_var , "==", $state2_val );   
		}		

	
	return 1;
}

sub TC_evaluation {

	return 1 if ($VERDICT);
	
	S_w2rep("Evaluation handled in simulation part");
	

	return 1;
}

sub TC_finalization {

	return 1 if ($VERDICT);

		my $state;
		if($tcpar_state2 =~ m/Openline/i){
			FM_removeFault('rb_swm_'.$fault.$device.'_flt');
			S_wait_ms('TIMER_SIX_SEC');
		}else{
			SetState ($tcpar_state1);
		}
		LC_ECU_Reset();
	
		GEN_Finalization ();

	
	return 1;
}

sub SetState{
	
	my $defaultpar_state = shift;
	my ($result, $state_value, $state_unit);
   	S_w2rep("STATE = $defaultpar_state , SWITCHNAME = $device");
	if($defaultpar_state =~ m/PositionA/i){ 
		($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $device, 'PositionA' );
	}else{
		($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $device, 'PositionB' );	
	}
	
	if($state_unit =~ /I/){
		LC_SetCurrent($device, $state_value);
	}elsif($state_unit =~ /R/){
		LC_SetResistance($device, $state_value);
	}
	
	S_w2rep("result = $result, state val = $state_value, state unit = $state_unit");
		
}

sub ReadFastDiagVariable{
	my $defaultpar_state = shift;
	
	
	if($defaultpar_state =~ m/position/i or $defaultpar_state =~ m/Switch/i){
		my $deviceProperties = DEVICE_fetchDeviceInfo($device);  
    	$SW_state_var = $deviceProperties->{'State_PD'};
		return $SW_state_var;
	}
	else{ #state is a fault
		my $deviceProperties = DEVICE_fetchDeviceInfo($device);  
    	$SW_state_var = $deviceProperties->{'Status_PD'};
	    return $SW_state_var;
	}
}




1;