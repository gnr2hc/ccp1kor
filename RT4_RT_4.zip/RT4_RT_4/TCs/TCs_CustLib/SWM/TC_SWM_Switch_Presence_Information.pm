#### TEST CASE MODULE
package TC_SWM_Switch_Presence_Information;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: SWM/TC_SWM_Switch_Presence_Information.pm 1.3 2020/05/22 18:57:06ICT Purushotham Reddy Chinnasani (RBEI/ESA-PP2) (UCP5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.100
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "check if the SWM shall clear the presence information in case of open line fault";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_Switch_Presence_Information

=head1 PURPOSE

check if the SWM shall clear the presence information in case of open line fault.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the switch to positionB state

2. Read <Switch_Presence> information.

3. Create an Open line fault on switch

4. Read <Switch_Presence> information.

5. Remove the open line fault condition on the switch 

6. Set switch to positionA state

7. Read <Switch_Presence> information.

8. Create an Undefined fault on switch

9. Read <Switch_Presence> information.

10. Create a Short to Ground fault on switch 

11. Read <Switch_Presence> information.


I<B<Evaluation>>

2. <Switch_Presence> = <Switch_Present_val>

4. <Switch_Presence> = <Switch_NotPresent_val>

7.  <Switch_Presence> = <Switch_Present_val>

8. <Switch_Presence> = <Switch_Present_val>

11. <Switch_Presence> = <Switch_Present_val>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case.
	LIST 'Switch_Presence' => Variable to check switch presence bit
	SCALAR 'Switch_Present_val' => Value if switch presence bit is set
	SCALAR 'Switch_NotPresent_val' => Value if switch presence bit is not set


=head2 PARAMETER EXAMPLESs

	purpose	= 'To test Switch presence information'
	
	Switch_Presence = @('rb_sycs_SwitchPresence_ab8(0)','rb_sycs_SwitchPresence_ab8(1)') #bit oriented(each bit represents a switch device )
	Switch_Present_val = '1' 
	Switch_NotPresent_val  = '0' 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_Switch_Presence;
my $tcpar_Switch_Present_val;
my $tcpar_Switch_NotPresent_val;
my $tcpar_Device;

################ global parameter declaration ###################
my ($switchName,$switchType,$Switch_positionB,$Switch_positionA,$Switch_Observed_Value,$Switch_Observed_Bit_Value,$Temp_Bit_Position,$Switch_Presence_Info);
my (%SearchHash,%Response_Val);
my @Bit_Array;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	@tcpar_Switch_Presence =  GEN_Read_mandatory_testcase_parameter( 'Switch_Presence' );
	$tcpar_Switch_Present_val =  GEN_Read_mandatory_testcase_parameter( 'Switch_Present_val' );
	$tcpar_Switch_NotPresent_val =  GEN_Read_mandatory_testcase_parameter( 'Switch_NotPresent_val' );
	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$switchName = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_Device);
	S_w2rep("Switch Name: $switchName");
	unless ( defined $switchName )
	{
		$switchName = 'NONE';
	}
	return 1 if CheckValidDevice();
	$switchType = DEVICE_fetchSwitchType ($switchName);
	S_w2rep("Switch Type: $switchType");
	if($switchType eq 'mech')
	{
		S_set_verdict('VERDICT_NONE');
	}
    $Switch_positionA =  DEVICE_fetchSwitchState($switchName,'positionA');
    S_w2rep("Switch PositionA: $Switch_positionA");
    $Switch_positionB =  DEVICE_fetchSwitchState($switchName,'positionB');
    S_w2rep("Switch PositionB: $Switch_positionB");

	return 1;
}

sub TC_initialization {

	return 1 if CheckValidDevice();
	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	return 1;
}

sub TC_stimulation_and_measurement {

	return 1 if CheckValidDevice();
	S_teststep("Set the switch to positionB state", 'AUTO_NBR');
	DEVICE_setDeviceState($switchName,$Switch_positionB);
	S_wait_ms(5000);
	S_teststep("Read Switch_Presence information using '@tcpar_Switch_Presence' .", 'AUTO_NBR', 'read_switch_presence_A');
	$Response_Val{'Nofault'}=PresenceStatus();
	S_teststep("Create an Open line fault on switch", 'AUTO_NBR');
	FM_createFault("rb_swm_OpenLine"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();

	S_teststep("Read '@tcpar_Switch_Presence' information.", 'AUTO_NBR', 'read_switch_presence_B');
	$Response_Val{'Openline'}=PresenceStatus();

	S_teststep("Remove the open line fault condition on the switch ", 'AUTO_NBR');
	FM_removeFault("rb_swm_OpenLine"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();
	S_teststep("Set switch to positionA state", 'AUTO_NBR');
	DEVICE_setDeviceState($switchName,$Switch_positionA);
	S_wait_ms(10000);
	S_teststep("Read '@tcpar_Switch_Presence' information.", 'AUTO_NBR', 'read_switch_presence_C');
	$Response_Val{'PositionA'}=PresenceStatus();

	S_teststep("Create an Undefined fault on switch", 'AUTO_NBR', 'create_an_undefined');
	FM_createFault("rb_swm_Undefined"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();
	S_teststep("Read '@tcpar_Switch_Presence' information.", 'AUTO_NBR');
    $Response_Val{'Undefined'}=PresenceStatus();
    FM_removeFault("rb_swm_Undefined"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();    
	S_teststep("Create a Short to Ground fault on switch ", 'AUTO_NBR');
	FM_createFault("rb_swm_ShortLine"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();
	S_teststep("Read '@tcpar_Switch_Presence' information.", 'AUTO_NBR', 'read_switch_presence_D');
	$Response_Val{'Short2Gnd'}=PresenceStatus();
	FM_removeFault("rb_swm_ShortLine"."$switchName"."_"."flt");
	S_wait_ms(10000);
	PD_ReadFaultMemory();
	return 1;
}

sub TC_evaluation {

	return 1 if CheckValidDevice();
	S_teststep_expected("$tcpar_Switch_Present_val", 'read_switch_presence_A');#evaluation 1
	S_teststep_detected("$Response_Val{'Nofault'}", 'read_switch_presence_A');
	EVAL_evaluate_value('Switch Presence',$Response_Val{'Nofault'},'==',$tcpar_Switch_Present_val);

	S_teststep_expected("$tcpar_Switch_NotPresent_val", 'read_switch_presence_B');#evaluation 2
	S_teststep_detected("$Response_Val{'Openline'}", 'read_switch_presence_B');
    EVAL_evaluate_value('Switch Presence',$Response_Val{'Openline'},'==',$tcpar_Switch_NotPresent_val);
	S_teststep_expected("$tcpar_Switch_Present_val", 'read_switch_presence_C');#evaluation 3
	S_teststep_detected("$Response_Val{'PositionA'}", 'read_switch_presence_C');
    EVAL_evaluate_value('Switch Presence',$Response_Val{'PositionA'},'==',$tcpar_Switch_Present_val);
	S_teststep_expected("$tcpar_Switch_Present_val", 'create_an_undefined');#evaluation 4
	S_teststep_detected("$Response_Val{'Undefined'}", 'create_an_undefined');
	EVAL_evaluate_value('Switch Presence',$Response_Val{'Undefined'},'==',$tcpar_Switch_Present_val);
	S_teststep_expected("$tcpar_Switch_Present_val", 'read_switch_presence_D');#evaluation 5
	S_teststep_detected("$Response_Val{'Short2Gnd'}", 'read_switch_presence_D');
	EVAL_evaluate_value('Switch Presence',$Response_Val{'Short2Gnd'},'==',$tcpar_Switch_Present_val);

	return 1;
}

sub TC_finalization {

	return 1 if CheckValidDevice();
	return 1;
}

sub CheckValidDevice{

	if ($switchName eq 'NONE')
	{
	    S_w2rep("Valid switch is not configured for this AIN Stop further execution\n",'orange');
	    $PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $tcpar_Device";
	    return 1;
    } 
}
sub PresenceStatus
{
    $SearchHash{'PADS1'}=0;
    $SearchHash{'PADS2'}=1;
    $SearchHash{'BLFD'}=2;
    $SearchHash{'BLFP'}=3;
	$SearchHash{'BLFC'}=4;
    $SearchHash{'BLRD'}=5;
    $SearchHash{'BLRP'}=6;
    $SearchHash{'BLRC'}=7;
    $SearchHash{'BLR2D'}=8;
    $SearchHash{'BLR2P'}=9;
	$SearchHash{'BLR2C'}=10;
    $SearchHash{'SPSFD'}=11;
	$SearchHash{'SPSFP'}=12;
    $SearchHash{'OPSFP'}=13;
	$SearchHash{'OPSRD'}=14;
	$SearchHash{'OPSRP'}=15;
	$SearchHash{'OPSRC'}=16;
	$SearchHash{'BLR3D'}=17;
	$SearchHash{'BLR3P'}=18;
	$SearchHash{'BLR3C'}=19;
    $Temp_Bit_Position=$SearchHash{$switchName};
	
    my @Names= keys %SearchHash;
    for(my $i=0;$i<scalar(@Names);$i++)
    {	
    	if($Names[$i] eq $switchName)
    	{
		    if($SearchHash{$switchName}>15)
    		{
    			$Switch_Observed_Value=S_aref2dec(PD_ReadMemoryByName($tcpar_Switch_Presence[2]),U8);
    			$Temp_Bit_Position=$SearchHash{$switchName}-16;
     		}
    		elsif($SearchHash{$switchName}>7 and $SearchHash{$switchName}<16)
			# if($SearchHash{$switchName}>7)
    		{
    			$Switch_Observed_Value=S_aref2dec(PD_ReadMemoryByName($tcpar_Switch_Presence[1]),U8);
    			$Temp_Bit_Position=$SearchHash{$switchName}-8;
     		}
    		else
    		{
    			$Switch_Observed_Value=S_aref2dec(PD_ReadMemoryByName($tcpar_Switch_Presence[0]),U8);
    			S_w2rep("else block");
    		}
    		$Switch_Observed_Bit_Value=S_dec2bin($Switch_Observed_Value);
    		@Bit_Array=split(//,$Switch_Observed_Bit_Value);
    		$Switch_Presence_Info=$Bit_Array[31-$Temp_Bit_Position];
    	}
    	#else
    	#{
    	#	S_set_error("Switch Name is not valid");
    	#}
    }
return $Switch_Presence_Info;
}
1;
