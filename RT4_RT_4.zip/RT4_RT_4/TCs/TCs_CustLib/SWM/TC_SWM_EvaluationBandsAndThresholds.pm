#### TEST CASE MODULE
package TC_SWM_EvaluationBandsAndThresholds;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER = q$Header: SWM/TC_SWM_EvaluationBandsAndThresholds.pm 1.5 2020/06/17 17:22:36ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS_SWM_SwitchMgt> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <3.146> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use GENERIC_DCOM;
use FuncLib_TNT_DEVICE;
use LIFT_labcar;
use LIFT_PD2ProdDiag;
use LIFT_evaluation;
use LIFT_PD;
use FuncLib_TNT_SYC_INTERFACE;

##################################

our $PURPOSE = "To check if the SWM qualifies the fault when the switch measurement falls out of valid band.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_EvaluationBandsAndThresholds

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Create <condition>


I<B<Stimulation and Measurement>>

1. For switch with type is 'resistive',set the resistance to a value in <Band1>.

For switch with type is 'hall',set the resistance to a value in <Band2> and wait for <Qualitime>

2.Send <Request> to read physical measurement value (in mA/ohm) for the switch through CD 

3. Read the Fault Recorder

4. Set the switch current/resistance to a <Default_value> and wait for <Dequalitime > time

5. .Send <Request> to read physical measurement value (in mA/ohm) for the switch through CD  

6. Read the Fault Recorder

Note1:Openline and Short2bat faults are NA for mechanical switches

Note: CA supports only 4 DID's for the switches BLFD,BLFP,BLR2D and SPSFD.Refer latest SPR_DSM_ConfigTable for supported DIDs


I<B<Evaluation>>

2. <Response> shall be received as <Response_Faulty>

3. <FLT_mand_FaultQualified> shall be qualified.

5. If type is 'hall', <Response> shall be received with 10% tolerance else <Response> shall be received as FB

6. <FLT_mand_FaultDequalified> shall be dequalified.

#Note:In step5, for resistive switches the response is expected as FB as the valid resistance value exceeds the 2bytes and hence  DSM reports the resistance as out of range(FB)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Device' => 
	SCALAR 'condition' => 
	SCALAR 'fault' => 
	SCALAR 'faulttype' => 
	SCALAR 'Qualitime' => 
	SCALAR 'Dequalitime' => 
	HASH 'FLT_mand_FaultQualified' => 
	HASH 'FLT_mand_FaultDequalified' => 
	SCALAR 'Band1' => 
	SCALAR 'Band2' => 
	SCALAR 'Request' => 
	SCALAR 'Response' => 
	SCALAR 'Response_Faulty' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test switch evaluation bands - Openline fault'
	#SETTINGS
	Device = '<Test Heading>'
	condition = 'none' #nothing required
	
	#FAULTS
	fault = 'Openline'
	faulttype = 'cyclic'
	Qualitime = '6000' #ms
	Dequalitime = '6000' #ms
	FLT_mand_FaultQualified = %('Openline' => '0bxxxxx111')
	FLT_mand_FaultDequalified = %('Openline' => '0bxxxxx110')
	
	#THRESHOLDS/BANDS
	Band1 = 'AboveHighBand' 
	Band2 = 'BelowLowBand'
	
	#CD Request
	Request = 'REQ_ReadDataByIdentifier_ReadSwitchMes'
	#ReadDataByIdentifier is service 22. Refer 'SPR_DSM_ConfigTable' for supported DID's
	
	#CD Response 
	Response = 'PR_ReadDataByIdentifier_ReadSwitchMes'
	#Positive response is 62 <DID> <switch_resistance>
	Response_Faulty = 'FD'
	#For the response values when the switch is faulty refer to SPS_DSM_119 in latest SPR_DSM_CustomerDiagnostics

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_condition;
my $tcpar_fault;
my $tcpar_faulttype;
my $tcpar_Qualitime;
my $tcpar_Dequalitime;
my $tcpar_FLT_mand_FaultQualified;
my $tcpar_FLT_mand_FaultDequalified;
my $tcpar_Band1;
my $tcpar_Band2;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_Response_Faulty;

################ global parameter declaration ###################
#add any global variables here
my ($type,$tcpar_Default_value,$BelowLow, $AboveHigh, $band1, $band2, $read_the_physical_A, $read_the_physical_B, $read_the_fault_A, $read_the_fault_B, $Value1, $Value2);
my $fault1 = 'OpenLine';
my $fault2 = 'ShortLine';
my ($result, $state_value, $state_unit,$Device_Name,$VERDICT,%fault_dequalified,%fault_qualified,$Real,$Monitored_ID,$Prog);
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_condition =  GEN_Read_mandatory_testcase_parameter( 'condition' );
	$tcpar_fault =  GEN_Read_mandatory_testcase_parameter( 'fault' );
	$tcpar_faulttype =  GEN_Read_mandatory_testcase_parameter( 'faulttype' );
	$tcpar_Qualitime =  GEN_Read_mandatory_testcase_parameter( 'Qualitime' );
	$tcpar_Dequalitime =  GEN_Read_mandatory_testcase_parameter( 'Dequalitime' );
	$tcpar_FLT_mand_FaultQualified =  GEN_Read_mandatory_testcase_parameter( 'FLT_mand_FaultQualified' ,'byref' );
	$tcpar_FLT_mand_FaultDequalified =  GEN_Read_mandatory_testcase_parameter( 'FLT_mand_FaultDequalified' ,'byref');
	$tcpar_Band1 =  GEN_Read_mandatory_testcase_parameter( 'Band1' );
	$tcpar_Band2 =  GEN_Read_mandatory_testcase_parameter( 'Band2' );
	$tcpar_Request =  GEN_Read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Response =  GEN_Read_mandatory_testcase_parameter( 'Response' );
	$tcpar_Response_Faulty =  GEN_Read_mandatory_testcase_parameter( 'Response_Faulty' );

	$Device_Name = DEVICE_fetchDeviceNamebyDeviceNumber ($tcpar_Device);
	
	
	unless(defined $Device_Name and $Device_Name ne '' and $Device_Name ne 'NONE'){	
		
			S_w2rep ("switch having label $tcpar_Device is  not present in the project");
			$VERDICT = S_set_verdict(VERDICT_NONE);
			return 1 if ($VERDICT);
		
	}
		
	if($Device_Name =~ m/BLFD|BLFP|BLR2D|SPSFD/i){
	
			$type = DEVICE_fetchSwitchType ($Device_Name); #Getting infor about type of the switch
			
			($Real,$Monitored_ID,$Prog) = PD_get_device_config($Device_Name);
				S_w2rep("presence bit :$Real",'Purple');
			
			if($Real eq '0'){                        #checking presence bit 
				$VERDICT = S_set_verdict(VERDICT_NONE);
				return 1 if ($VERDICT);
			}
			          
			$BelowLow  	= ((DEVICE_fetchDeviceThreshold( $Device_Name, 'Min' )) +(DEVICE_fetchDeviceThreshold( $Device_Name, 'Low' ))) /2 ;
			$AboveHigh  = ((DEVICE_fetchDeviceThreshold( $Device_Name, 'Max' )) +(DEVICE_fetchDeviceThreshold( $Device_Name, 'High' ))) /2;
			
			if($tcpar_Band1 =~ m/AboveHighBand/i){
				$band1 = $AboveHigh;
				$band2 = $BelowLow;
			}
			else{
				$band1 = $BelowLow;
				$band2 = $AboveHigh;
			}
			S_w2rep("Band1 is $band1 and band2 is $band2 \n",'green');
			
	}
	else{

		S_w2rep("CA doesn't support DID's for $Device_Name switch , hence cannot be implemented for this definition \n");
		$VERDICT =S_set_verdict(VERDICT_NONE);
		return 1 if ($VERDICT);
		
		
	}

		
	return 1;


}

sub TC_initialization {

	return 1 if ($VERDICT);

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	
	return 1;

}

sub TC_stimulation_and_measurement {

	return 1 if ($VERDICT);

		S_teststep("For switch with type is 'resistive',set the resistance to a value in '$tcpar_Band1'.", 'AUTO_NBR');
	
		S_teststep("For switch with type is 'hall',set the resistance to a value in '$tcpar_Band2' and wait for '$tcpar_Qualitime'", 'AUTO_NBR');
			
			if ($type eq 'resistive'){
					LC_SetResistance( $Device_Name, $band1);
					S_w2rep("resistance set as $band1 for Device $Device_Name \n",'green');
				}
				if ( $type eq 'hall'){
					LC_SetCurrent( $Device_Name,$band2);
					S_w2rep("Current is set as $band2 for device $Device_Name \n",'green');
				}
			S_wait_ms($tcpar_Qualitime,"Wait time for fault Qualification");
		
		S_teststep("Send '$tcpar_Request' to read physical measurement value (in mA/ohm) for the switch through CD ", 'AUTO_NBR', 'send_request_to_A');			#measurement 1
			
			$read_the_physical_A = GDCOM_request_general ( $tcpar_Request.$Device_Name, $tcpar_Response.$Device_Name);
			$Value1 = substr($read_the_physical_A,9,11);
			S_w2rep("Obtained Value after Qualified Fault is $Value1 \n",'green');
		
		S_teststep("Read the Fault Recorder", 'AUTO_NBR', 'read_the_fault_A');			#measurement 2
			
			$read_the_fault_A = PD_ReadFaultMemory();
			
		S_teststep("Set the switch current/resistance to a '$tcpar_Default_value' and wait for '$tcpar_Dequalitime ' time", 'AUTO_NBR');
	
			($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $Device_Name, 'PositionA' );
			if($state_unit =~ /I/){
				LC_SetCurrent($Device_Name, $state_value);
				S_w2rep("Current is set as $state_value for device $Device_Name \n",'green');
			}
			elsif($state_unit =~ /R/){
				LC_SetResistance($Device_Name, $state_value);
				S_w2rep("resistance set as $state_value for Device $Device_Name \n",'green');
			}
			S_wait_ms($tcpar_Dequalitime,"Wait time for fault De-Qualification");
		
		S_teststep("Send '$tcpar_Request' to read physical measurement value (in mA/ohm) for the switch through CD  ", 'AUTO_NBR', 'send_request_to_B');			#measurement 3
			$read_the_physical_B = GDCOM_request_general ( 'REQ_ReadDataByIdentifier_ReadSwitchMes'.$Device_Name, 'PR_ReadDataByIdentifier_ReadSwitchMes'.$Device_Name);
			$Value2 = substr($read_the_physical_B,9,11);
			S_w2rep("Obtained Value after DeQualified Fault is $Value2 \n",'green');
		
		S_teststep("Read the Fault Recorder", 'AUTO_NBR', 'read_the_fault_B');			#measurement 4
			$read_the_fault_B = PD_ReadFaultMemory();
		
		S_teststep("Note1:Openline and Short2bat faults are NA for mechanical switches", 'AUTO_NBR');
		S_teststep("Note: CA supports only 4 DID's for the switches BLFD,BLFP,BLR2D and SPSFD.Refer latest SPR_DSM_ConfigTable for supported DIDs", 'AUTO_NBR');
	
	
	
	return 1;
}

sub TC_evaluation {


	return 1 if ($VERDICT);
	
		S_teststep_expected("'$tcpar_Response' shall be received as '$tcpar_Response_Faulty'", 'send_request_to_A');			#evaluation 1
		S_teststep_detected("Obtained response Value is $Value1", 'send_request_to_A');
		EVAL_evaluate_value ( "Checking for Detected Value with 10%" , hex($Value1), '==', hex($tcpar_Response_Faulty));
			
			
		S_teststep_expected("'$tcpar_FLT_mand_FaultQualified' shall be qualified.", 'read_the_fault_A');			#evaluation 2
		S_teststep_detected("Fault is $read_the_fault_A", 'read_the_fault_A');
			%fault_qualified = %$tcpar_FLT_mand_FaultQualified;
			if($tcpar_fault eq 'Openline'){
				PD_evaluate_faults($read_the_fault_A,["rb_swm_".$fault1.$Device_Name."_flt"]);
				PD_check_fault_status($read_the_fault_A,"rb_swm_".$fault1.$Device_Name."_flt",$fault_qualified{$tcpar_fault});
			}
			if($tcpar_fault eq 'Short2Gnd' ){
				PD_evaluate_faults($read_the_fault_A,["rb_swm_".$fault2.$Device_Name."_flt"]);
				PD_check_fault_status($read_the_fault_A,"rb_swm_".$fault2.$Device_Name."_flt",$fault_qualified{$tcpar_fault});	
			}
			
		S_teststep_expected("If type is 'hall', '$tcpar_Response' shall be received with 10% tolerance else '$tcpar_Response' shall be received as FB", 'send_request_to_B');			#evaluation 3
		S_teststep_detected("Obtained response Value is $Value2", 'send_request_to_B');
		if ($type eq 'resistive') {
				EVAL_evaluate_value ( "Checking for Detected Value with 10%" ,hex($Value2), '==' , hex('FB'));
			}
			else{
				EVAL_evaluate_value ( "Checking for Detected Value with 10%" , hex($Value2)/10, '==', $state_value,10 );
			}
				
		S_teststep_expected("'$tcpar_FLT_mand_FaultDequalified' shall be dequalified.", 'read_the_fault_B');			#evaluation 4
		S_teststep_detected("Detected Falut is $read_the_fault_B \n");
			%fault_dequalified = %$tcpar_FLT_mand_FaultDequalified;
			if($tcpar_fault eq 'Openline'){
				PD_evaluate_faults($read_the_fault_B,["rb_swm_".$fault1.$Device_Name."_flt"]);
				PD_check_fault_status($read_the_fault_B,"rb_swm_".$fault1.$Device_Name."_flt",$fault_dequalified{$tcpar_fault});
			}
			if($tcpar_fault eq 'Short2Gnd'){
				PD_evaluate_faults($read_the_fault_B,["rb_swm_".$fault2.$Device_Name."_flt"]);
				PD_check_fault_status($read_the_fault_B,"rb_swm_".$fault2.$Device_Name."_flt",$fault_dequalified{$tcpar_fault});
			}	
		S_teststep_expected("#Note:In step5, for resistive switches the response is expected as FB as the valid resistance value exceeds the 2bytes and hence  DSM reports the resistance as out of range(FB)");
	
	

	return 1;
}

sub TC_finalization {

		return 1 if ($VERDICT);

		PD_ClearFaultMemory();
		
		LC_ECU_Reset();
		S_wait_ms(2000);
	
	
	
	return 1;
}


1;