#### TEST CASE MODULE
package TC_SWM_Short2Bat_VzlBit_Set;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SWM_Short2Bat_VzlBit_Set.pm 1.1 2019/07/15 11:57:43ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.121
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_spi_access;
#include further modules here

##################################

our $PURPOSE = "To check the qualification of Short2Bat fault when vzl bit is set.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_Short2Bat_VzlBit_Set

=head1 PURPOSE

To check the qualification of Short2Bat fault when vzl bit is set.

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read the Fault recorder.

1.Create a <condition> on a <device>

2. Read the fault recorder.

3.Remove the <condition> 

4. Reset the ECU 

5. Manipulate the SPI signal for <command> <signal> bit <set> 

6. Read the fault recorder


I<B<Evaluation>>

1.

2. <Fault> must be qualified.

3.

4.

5.

6.<Fault> must be qualified.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Device' => 
	SCALAR 'condition' => 
	SCALAR 'cycle_time' => 
	SCALAR 'command' => 
	SCALAR 'signal' => 
	SCALAR 'set' => 
	HASH 'Fault' => 
	SCALAR 'Number_Of_Samples' => 
	SCALAR 'Switch_Cycle_Time' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To check the behaviour of Short2Bat fault when vzl bit is set'
	
	Device = '<Test Heading 2>'
	condition = 'Short2Bat'
	
	cycle_time= ' No_of_samples x SwitchCycleTime' 
	
	#in ms.
	#No_of_samples is configurable by projects.    
	command = 'POM_STATUS'
	signal = 'vzl'
	set = '1'
	Fault = %('rb_swm_Short2BatPADS1_flt' => '0bxxxxxxxx')
	Number_Of_Samples = '5'
	Switch_Cycle_Time = '30' 
	#Note: the above parameters are declared in SWM constants file, Refer SRS ID:166 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_condition;
my $tcpar_cycle_time;
my $tcpar_command;
my $tcpar_signal;
my $tcpar_set;
my %tcpar_Fault;
my $tcpar_Number_Of_Samples;
my $tcpar_Switch_Cycle_Time;
my $tcpar_Node;

################ global parameter declaration ###################
#add any global variables here

my $faultsAfterStimulation_A;
my $faultsAfterStimulation_B;
my $Detected_fault;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_condition =  GEN_Read_mandatory_testcase_parameter( 'condition' );
	$tcpar_cycle_time =  GEN_Read_mandatory_testcase_parameter( 'cycle_time' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	$tcpar_signal =  GEN_Read_mandatory_testcase_parameter( 'signal' );
	$tcpar_set =  GEN_Read_mandatory_testcase_parameter( 'set' );
	$tcpar_Node =  GEN_Read_mandatory_testcase_parameter( 'Node' );
	%tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_Number_Of_Samples =  GEN_Read_mandatory_testcase_parameter( 'Number_Of_Samples' );
	$tcpar_Switch_Cycle_Time =  GEN_Read_mandatory_testcase_parameter( 'Switch_Cycle_Time' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Create a '$tcpar_condition' on a '$tcpar_Device'", 'AUTO_NBR', 'create_a_condition');			#measurement 1
	DEVICE_setDeviceState($tcpar_Device,$tcpar_condition);
	S_wait_ms(5000,"Wait time for fault Qualification");
	
	S_teststep("Read the fault recorder.", 'AUTO_NBR');			#measurement 2
	$faultsAfterStimulation_A = PD_ReadFaultMemory();
	
	S_teststep("Remove the '$tcpar_condition' ", 'AUTO_NBR');
	DEVICE_resetDeviceState($tcpar_Device,$tcpar_condition);
	S_wait_ms(5000,"Wait time for fault de-qualification");
	
	S_teststep("Manipulate the SPI signal for '$tcpar_command' '$tcpar_signal' bit '$tcpar_set' ", 'AUTO_NBR');
		
	SPI_load_signal_manipulation(
				'Node'        => $tcpar_Node,
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal,
				'SignalValue' => $tcpar_set,
			);
	
	S_w2rep("Start the Manipulation");
	
	SPI_start_manipulation();
		
	S_wait_ms(1000,"Wait time for manipulation");
	
	S_teststep("Read the fault recorder", 'AUTO_NBR');			#measurement 3
	$faultsAfterStimulation_B = PD_ReadFaultMemory();
	return 1;
}

sub TC_evaluation {
	foreach my $fault( keys %tcpar_Fault){
			if(PD_check_fault_exists($faultsAfterStimulation_A, $fault)){
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation_A, $fault, 'fault_text' );
				S_teststep_detected("Detected Fault in the system:$Detected_fault");
				my $fault_index  = PD_get_fault_index( $faultsAfterStimulation_A, $fault );
				# check Fault State
				my $FLT_state_expected = $tcpar_Fault{$fault};
				my $FLT_state_detected = $faultsAfterStimulation_A->{'state'}->[$fault_index];
				
				#my $FLT_state_detected_8bits = substr((S_dec2bin(S_hex2dec($FLT_state_detected))), -8);				
				S_teststep_2nd_level( "Evaluate Fault State for $fault", 'AUTO_NBR');
				S_teststep_expected( "$FLT_state_expected"); 
				S_teststep_detected( "$FLT_state_detected" );
				EVAL_evaluate_value( "key_fault_name", $FLT_state_detected, '==', $FLT_state_expected );
			}
			else{
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				S_teststep_detected("$fault didn't qualify in the system");
			} 
			if(PD_check_fault_exists($faultsAfterStimulation_B, $fault)){
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation_B, $fault, 'fault_text' );
				S_teststep_detected("Detected Fault in the system:$Detected_fault");
				my $fault_index  = PD_get_fault_index( $faultsAfterStimulation_B, $fault );
				# check Fault State
				my $FLT_state_expected = $tcpar_Fault{$fault};
				my $FLT_state_detected = $faultsAfterStimulation_B->{'state'}->[$fault_index];
				
				#my $FLT_state_detected_8bits = substr((S_dec2bin(S_hex2dec($FLT_state_detected))), -8);				
				S_teststep_2nd_level( "Evaluate Fault State for $fault", 'AUTO_NBR');
				S_teststep_expected( "$FLT_state_expected"); 
				S_teststep_detected( "$FLT_state_detected" );
				EVAL_evaluate_value( "key_fault_name", $FLT_state_detected, '==', $FLT_state_expected );
			}
			else{
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				S_teststep_detected("$fault didn't qualify in the system");
			} 
			
		}
	
	return 1;
}

sub TC_finalization {
	SPI_stop_manipulation();
	PD_ClearFaultMemory();
	return 1;
}


1;
