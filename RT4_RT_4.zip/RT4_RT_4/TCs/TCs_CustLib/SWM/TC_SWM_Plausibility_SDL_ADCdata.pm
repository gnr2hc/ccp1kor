#### TEST CASE MODULE
package TC_SWM_Plausibility_SDL_ADCdata;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SWM_Plausibility_SDL_ADCdata.pm 1.1 2019/07/15 11:57:43ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS:TS_SWM_SwitchMgt
#TS version in DOORS: 3.121
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_spi_access;
#include further modules here

##################################

our $PURPOSE = "'To test the SW/HW plausibility for SDL switches'";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_Plausibility_SDL_ADCdata

=head1 PURPOSE

'To test the SW/HW plausibility for SDL switches'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power_on_reset. 

2. Read the fault recorder.

3. Change the <signal> to <value> in the SPI instruction <command>  and also valid CRC so that the position in the software and the hardware differs using the SPI manipulation tool.

4. Reset the ECU.

5. Read the fault recorder.


I<B<Evaluation>>

1.

2.Fault 'SdlHwSwPlausibility' should not be qualified

3.

5. Fault 'SdlHwSwPlausibility' should be qualified


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'ManiToo_tcpar' => 
	SCALAR '_FastDiagVar0' => 
	SCALAR 'WaitTime_ms' => 
	HASH '_FLT_state' => 
	LIST '_EvalVar0' => 
	SCALAR 'purpose' => 
	SCALAR 'Switch' => 
	SCALAR 'command' => 
	SCALAR 'signal' => 
	SCALAR 'ManipuStartTime_ms' => 
	SCALAR 'DiagStartTime_ms' => 
	SCALAR 'USE_FDIAG_RECORD' => 
	SCALAR 'USE_FLT_EVAL' => 
	SCALAR 'USE_VAR_EVAL' => 
	SCALAR 'USE_FDIAG_EVAL' => 
	SCALAR 'USE_SPI_EVAL' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the SW/HW plausibility for SDL switches'
	Switch = '<Test Heading>'
	command = 'AINO_READ_AUTO' 
	signal = 'adc_result'
	ManipuStartTime_ms		= -1
	DiagStartTime_ms		= 7000
	USE_FDIAG_RECORD		= 'yes'
	USE_FLT_EVAL			= 'yes'
	USE_VAR_EVAL			= 'no'
	USE_FDIAG_EVAL		= 'no'
	USE_SPI_EVAL			= 'no'
	#AINO_READ_AUTO Bit0 to bit 9 corresponds to adc result. Value from 0-1024.
	
	
	# ------------------ TC_initialization ---------------------------------
	ManiToo_tcpar			= 'Invalid_SDL_ADC_DATA'
	
	# -------------------TC_stimulation_and_measurement --------
	_FastDiagVar0			= 'SDL_HW_SW_SCON_U8'
	WaitTime_ms			= 500
	
	# ------------------ TC_evaluation ----------------------------------
	_FLT_state		   	= %(''rb_swm_SdlHwSwPlausibility_flt'  => '0bxxxxxxxx')
	_EvalVar0			= @('SDL_HW_SW_SCON_U8, '>', '0') 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Switch;
my $tcpar_command;
my $tcpar_signal;
my $tcpar_value;
my %tcpar_Fault;

################ global parameter declaration ###################
#add any global variables here
my $faultsAfterStimulation;
my $Detected_fault;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	$tcpar_signal =  GEN_Read_mandatory_testcase_parameter( 'signal' );
	%tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_value =  GEN_Read_mandatory_testcase_parameter( 'value' );


	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Power_off_reset. ", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Power_on_reset. ", 'AUTO_NBR');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Read the fault recorder.", 'AUTO_NBR', 'read_the_fault_A');			#measurement 1
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation,[]);
	return 0 unless($faultsVerdict eq 'VERDICT_PASS');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Change the '$tcpar_signal' to '$tcpar_value' in the SPI instruction '$tcpar_command' using the SPI manipulation tool.", 'AUTO_NBR');
	SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal,
				'SignalValue' => $tcpar_value,
			);
	
	S_w2rep("Start the Manipulation");
	
	SPI_start_manipulation();
	
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	S_teststep("Read the fault recorder.", 'AUTO_NBR');			#measurement 2
	$faultsAfterStimulation = PD_ReadFaultMemory();
	return 1;
}

sub TC_evaluation {

	foreach my $fault( keys %tcpar_Fault){
			if(PD_check_fault_exists($faultsAfterStimulation, $fault)){;
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation, $fault, 'fault_text' );
				S_teststep_detected("Detected Fault in the system:$Detected_fault");
				my $fault_index  = PD_get_fault_index( $faultsAfterStimulation, $fault );
				# check Fault State
				my $FLT_state_expected = $tcpar_Fault{$fault};
				my $FLT_state_detected = $faultsAfterStimulation->{'state'}->[$fault_index];
				
				#my $FLT_state_detected_8bits = substr((S_dec2bin(S_hex2dec($FLT_state_detected))), -8);				
				S_teststep_2nd_level( "Evaluate Fault State for $fault", 'AUTO_NBR');
				S_teststep_expected( "$FLT_state_expected"); 
				S_teststep_detected( "$FLT_state_detected" );
				EVAL_evaluate_value( "key_fault_name", $FLT_state_detected, '==', $FLT_state_expected );
			}
		}
	return 1;
}

sub TC_finalization {
	SPI_stop_manipulation();
	PD_ClearFaultMemory();
	return 1;
}


1;
