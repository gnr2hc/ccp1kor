#### TEST CASE MODULE
package TC_SWM_ECOandDisposalMode;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: SWM/TC_SWM_ECOandDisposalMode.pm 1.3 2019/07/24 19:30:23ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS:TS_SWM_SwitchMgt
#TS version in DOORS: 3.96
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use LIFT_labcar;
use LIFT_evaluation;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_can_access; 
use FuncLib_ACEA_TNT;
use FuncLib_TNT_SYC_INTERFACE;
##################################

our $PURPOSE = "To check if the cyclic switch measurement stops during ECO or Disposal Mode.";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_ECOandDisposalMode

=head1 PURPOSE

To check if the cyclic switch measurement stops during ECO or Disposal Mode.


=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Set the switch state to Position A.


I<B<Stimulation and Measurement>>

1. Enter  <mode> and read the fault recorder.

2. Create <fault> and wait for Qualification time and  Read fault recorder  

3. Change the switch position B of  switch <Device>. Read the  switch position, status and extended status.

4. Exit  <mode> and  Read the fault recorder 

5. Remove the faults and read the fault recorder.Read the  switch position, status and extended status.


I<B<Evaluation>>

1. 

2. <fault> is not qualified.

3. <fault> is not qualified and  

Switch position is <state_mand_FaultQualified>, 

status is <Status_val_FaultQualified>and

extstatus is <ExtStatus_val_FaultQualified>

4. <fault> will be in  qualified state.

6.<fault> is dequalified.

Switch position changes to<state_mand_FaultDequalified>

status changes to<Status_val_FaultDequalified>and 

extstatus changes to<ExtStatus_val_FaultDequalified>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => To check if the cyclic switch measurement stops during ECO or Disposal Mode.
	SCALAR 'Device' => switch label 
	SCALAR 'fault' => Fault created on the switch
	SCALAR 'mode' => Disposal/ECO
	SCALAR 'State_val_FaultQualified' => position of the switch in the disposal mode and when fault is qualified on that particular switch
	SCALAR 'Status_val_FaultQualified' => status of the switch in the disposal mode and when fault is qualified on that particular switch
	SCALAR 'ExtStatus_val_FaultQualified' => Extstatus of the switch in the disposal mode and when fault is qualified on that particular switch
	SCALAR 'State_val_FaultDeQualified_' => position of the switch in the normal mode and when fault is dequalified on that particular switch
	SCALAR 'Status_val_FaultDequalified' => status of the switch in the normal mode and when fault is dequalified on that particular switch
	SCALAR 'ExtStatus_val_FaultDequalified' => Extstatus of the switch in the normal mode and when fault is dequalified on that particular switch


=head2 PARAMETER EXAMPLES

	purpose	= 'To test switch fault behaviour in ECO and Disposal mode condition'
	
	#SETTINGS
	Device = 'BL1' #Belt lock 1
	fault =  'Short2GND'
	mode = 'Disposal mode'
	
	State_val_FaultQualified='STATE_POSITIONA'
	Status_val_FaultQualified = 'STATUS_FAULT'
	ExtStatus_val_FaultQualified = 'EXTSTATUS_FAULT'
	#configurable
	#last valid or default, refer SPR.
	
	
	State_val_FaultDeQualified_='STATE_POSITIONB'
	Status_val_FaultDequalified = 'STATUS_VALID'
	ExtStatus_val_FaultDequalified = 'EXTSTATUS_VALID'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_fault;
my $tcpar_mode;
my $TestHW;
my $tcpar_State_val_FaultQualified;
my $tcpar_Status_val_FaultQualified;
my $tcpar_ExtStatus_val_FaultQualified;
my $tcpar_State_val_FaultDequalified;
my $tcpar_Status_val_FaultDequalified;
my $tcpar_ExtStatus_val_FaultDequalified;

################ global parameter declaration ###################
my ($switchType,
    $Switch_positionA,
    $Switch_positionB);
my %faultsInFaultMemory;
my %observedstate_PD;
my %observedstatus_PD;
my %observedextstatus_PD;
my $expectedstate_PD;
my $expectedstatus_PD;
my $expectedextstatus_PD;
my ($msg_aref,$msg_ID,$cycle,$TP_handle);
my $ExecuteSPL_With_Conversion='01';
my $routineStatusRecord;
my $defaultpar_fault;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose', 'byvalue' );
	$tcpar_Device =  S_read_mandatory_testcase_parameter( 'Device', 'byvalue' );
	$tcpar_fault =  S_read_mandatory_testcase_parameter( 'fault', 'byvalue' );
	$tcpar_mode =  S_read_mandatory_testcase_parameter( 'mode', 'byvalue' );
	$tcpar_State_val_FaultQualified =  S_read_mandatory_testcase_parameter( 'State_val_FaultQualified', 'byvalue' );
	$tcpar_Status_val_FaultQualified =  S_read_mandatory_testcase_parameter( 'Status_val_FaultQualified', 'byvalue' );
	$tcpar_ExtStatus_val_FaultQualified =  S_read_mandatory_testcase_parameter( 'ExtStatus_val_FaultQualified', 'byvalue' );
	$tcpar_State_val_FaultDequalified =  S_read_mandatory_testcase_parameter( 'State_val_FaultDequalified', 'byvalue' );
	$tcpar_Status_val_FaultDequalified =  S_read_mandatory_testcase_parameter( 'Status_val_FaultDequalified', 'byvalue' );
	$tcpar_ExtStatus_val_FaultDequalified =  S_read_mandatory_testcase_parameter( 'ExtStatus_val_FaultDequalified', 'byvalue' );
	
	# $tcpar_Device = $tcpar_Device; 
    
    unless ( defined $tcpar_Device ) {
		# $tcpar_Device = 'NONE';			
		S_set_error("Switch is not present");
		return 1;
	}
    
    #If no device is assigned then skip execution. Verdict will be 'NONE'
    return 1 if CheckValidDevice();
    
    $switchType = DEVICE_fetchSwitchType ($tcpar_Device);
	return 1;
}

sub TC_initialization {
	
		S_teststep("StandardPrepNoFault", 'AUTO_NBR');
		GDCOM_init();
		GEN_StandardPrepNoFault();
		CD_init();
		
		S_teststep("Set the switch state to Position A.", 'AUTO_NBR');
		my ($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionA' );
		if($state_unit =~ /I/){
			LC_SetCurrent($tcpar_Device, $state_value);
		}elsif($state_unit =~ /R/){
			LC_SetResistance($tcpar_Device, $state_value);
		}
		S_wait_ms('SWITCH_STATE_CHANGE_TIME');
		
	return 1;
}

sub TC_stimulation_and_measurement {
	
	S_teststep("Enter  '$tcpar_mode' and read the fault recorder.", 'AUTO_NBR');
		if($tcpar_mode eq 'ECO')
		{
			S_set_error("ECO mode not yet implemented in AB12,hence TC is aborted");
			S_set_verdict ( 'VERDICT_FAIL' );
			return 1;
		}
		elsif($tcpar_mode eq 'Disposal')
		{
			CA_trace_start();
			S_w2rep("Set the preconditions for this test case",'blue');
			$msg_aref = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{"CAN_TesterPresent_Req"};
			$msg_ID = $LIFT_PROJECT::Defaults->{"CUSTOMER_DIAGNOSIS"}{'RequestID_disposal'};
			$cycle  = 4500;
			$routineStatusRecord =$LIFT_PROJECT::Defaults->{"DISPOSAL"}{'RoutineStatusRecord'};
			
			GDCOM_set_addressing_mode("disposal");
			S_w2rep("SendTesterPresentCyclically",'blue');
			$TP_handle = GDCOM_start_CyclicTesterPresent($msg_aref,$msg_ID,$cycle);
			S_wait_ms('TIMER_TWO_SEC');
			GDCOM_StartSession('DisposalSession');  
			S_w2rep("Enable Disposal_Security");
			ACEA_Get_SecurityAccess();
			ACEA_ExecuteDisposalProgramLoader($ExecuteSPL_With_Conversion,$routineStatusRecord,1);
			S_wait_ms('TIMER_TWO_SEC');
		
		}
		else{
			S_set_error("mode is not defined for the test case");
			S_set_verdict ( 'VERDICT_FAIL' );			
			return 1;
		}
	
	S_teststep("Create '$tcpar_fault' and wait for Qualification time,", 'AUTO_NBR', 'create_fault_and_check_faultrecorder');#measurement 1

		$defaultpar_fault = "rb_swm_$tcpar_fault"."$tcpar_Device"."_flt";
		if($tcpar_fault =~ m/ShortLine/i){
			LC_ShortLines( [$tcpar_Device.'+', $tcpar_Device.'-'] );
		}elsif($tcpar_fault =~ m/Undefined/i and $tcpar_Device =~ m/OPS/i){	
			S_set_error("Undefined band is not present for OPS switch,,Hence TC is aborted");
			S_set_verdict ( 'VERDICT_FAIL' );
			return 1;
		}else{
			FM_createFault($defaultpar_fault);
		}
		S_wait_ms( 'TIMER_ECU_FAULT_QUALIFICATION' );
		$faultsInFaultMemory{'create_fault_and_check_faultrecorder'} = PD_ReadFaultMemory();
		
	
	S_teststep("Change the switch position B of  switch '$tcpar_Device'. Read the  switch position, status and extended status.", 'AUTO_NBR', 'change_the_switch_position');#measurement 2
	
		my ($result1, $state_value1, $state_unit1) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionB' );
		if($state_unit1 =~ /I/){
			LC_SetCurrent($tcpar_Device, $state_value1);
		}elsif($state_unit1 =~ /R/){
			LC_SetResistance($tcpar_Device, $state_value1);
		}	
		
		S_wait_ms('TIMER_TWO_SEC');
		$observedstate_PD{'change_the_switch_position'} = DEVICE_readSwitchState_PD($tcpar_Device);
		$observedstatus_PD{'change_the_switch_position'} =  DEVICE_readSwitchStatus_PD($tcpar_Device);
		$observedextstatus_PD{'change_the_switch_position'} =  DEVICE_readSwitchExtendedStatus_PD($tcpar_Device);
	
	S_teststep("Exit  '$tcpar_mode' and  Read the fault recorder ", 'AUTO_NBR', 'exit_mode');#measurement 3
		LC_ECU_Reset();
		$faultsInFaultMemory{'exit_mode'}= PD_ReadFaultMemory();
	
	S_teststep("Remove the faults and read the fault recorder.Read the  switch position, status and extended status.", 'AUTO_NBR','check_faultrecorder');#measurement 4
		if($tcpar_fault =~ m/ShortLine/i){
			LC_UndoShortLines();
		}else{
			FM_removeFault($defaultpar_fault);
		}
		S_wait_ms( 'TIMER_ECU_FAULT_QUALIFICATION' );
		LC_ECU_Reset();
		$faultsInFaultMemory{'check_faultrecorder'} = PD_ReadFaultMemory();
	
		$observedstate_PD{'check_switch_status'} = DEVICE_readSwitchState_PD($tcpar_Device);
		$observedstatus_PD{'check_switch_status'} =  DEVICE_readSwitchStatus_PD($tcpar_Device);
		$observedextstatus_PD{'check_switch_status'} =  DEVICE_readSwitchExtendedStatus_PD($tcpar_Device);

	return 1;
}

sub TC_evaluation {
	
		S_w2rep("##########################################################################################################################################################",'purple');
		S_teststep_expected("$tcpar_fault is not qualified: $tcpar_mode", 'create_fault_and_check_faultrecorder');#evaluation 1
		if(PD_evaluate_faults( $faultsInFaultMemory{'create_fault_and_check_faultrecorder'},[] ))
		{
			S_teststep_detected("$tcpar_fault is not qualified after entering mode: $tcpar_mode",'create_fault_and_check_faultrecorder');
		}
		else
		{
			S_teststep_detected("$tcpar_fault is qualified after entering mode: $tcpar_mode",'create_fault_and_check_faultrecorder'); 
		}
		S_w2rep("##########################################################################################################################################################",'purple');
		#----------------------------------------------------------------------------------------------------------------------
		
		$expectedstate_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_State_val_FaultQualified);
		S_teststep_expected("Position of $tcpar_Device is '$expectedstate_PD' ");#evaluation 2
		S_teststep_detected("Position of $tcpar_Device is '$expectedstate_PD' = $observedstate_PD{'change_the_switch_position'}");
		EVAL_evaluate_value ( "Switch state for $tcpar_Device",$observedstate_PD{'change_the_switch_position'}, '==',$expectedstate_PD);
		
		$expectedstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_Status_val_FaultQualified);
		S_teststep_expected("status of $tcpar_Device is $expectedstatus_PD");
		S_teststep_detected("status of $tcpar_Device is $expectedstatus_PD = $observedstatus_PD{'change_the_switch_position'}");
		EVAL_evaluate_value ( "Switch status for $tcpar_Device",$observedstatus_PD{'change_the_switch_position'} ,'==',$expectedstatus_PD);
	
		$expectedextstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_ExtStatus_val_FaultQualified);
		S_teststep_expected("extstatus of $tcpar_Device is $expectedextstatus_PD");
		S_teststep_detected("extstatus of $tcpar_Device is $expectedextstatus_PD = $observedextstatus_PD{'change_the_switch_position'}");
		EVAL_evaluate_value ( "Switch Extended status for $tcpar_Device",$observedextstatus_PD{'change_the_switch_position'} ,'==',$expectedextstatus_PD,);
	
		#----------------------------------------------------------------------------------------------------------------------
		S_w2rep("##########################################################################################################################################################",'purple');
		S_teststep_expected("'$tcpar_fault' will be in  qualified state after mode $tcpar_mode exit", 'exit_mode');#evaluation 3
		if (PD_check_fault_exists($faultsInFaultMemory{'exit_mode'}, $defaultpar_fault))
		{
			PD_check_fault_status( $faultsInFaultMemory{'exit_mode'}, $defaultpar_fault, '0bxxxxxxx1' );
			S_teststep_detected("$tcpar_fault is qualified after mode $tcpar_mode exit ",'exit_mode');
		}
		else
		{
			S_teststep_detected("$tcpar_fault is not qualified after mode $tcpar_mode exit ", 'exit_mode');
		}
		S_w2rep("##########################################################################################################################################################",'purple');
		#----------------------------------------------------------------------------------------------------------------------
		S_teststep_expected("'$tcpar_fault' is dequalified.");#evaluation 4
		if(PD_check_fault_exists($faultsInFaultMemory{'check_faultrecorder'}, $defaultpar_fault))
		{
			PD_check_fault_status( $faultsInFaultMemory{'check_faultrecorder'}, $defaultpar_fault, '0bxxxxxxx0');
			S_teststep_detected("$tcpar_fault is dequalified");
		}
		else
		{
			S_teststep_detected("$tcpar_fault is still qualified");
		}
		S_w2rep("##########################################################################################################################################################",'purple');
		#----------------------------------------------------------------------------------------------------------------------
	
		$expectedstate_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_State_val_FaultDequalified);
		S_teststep_expected("Position of $tcpar_Device changes to $expectedstate_PD  ");#evaluation 5
		S_teststep_detected("Position of $tcpar_Device is $expectedstate_PD = $observedstate_PD{'check_switch_status'}");
		EVAL_evaluate_value ( "Switch state for $tcpar_Device",$observedstate_PD{'check_switch_status'},'==', $expectedstate_PD);
	
		$expectedstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_Status_val_FaultDequalified);
		S_teststep_expected("status of $tcpar_Device changes to $expectedstatus_PD");
		S_teststep_detected("status of $tcpar_Device is $expectedstatus_PD = $observedstatus_PD{'check_switch_status'}");
		EVAL_evaluate_value ( "Switch status for $tcpar_Device",$observedstatus_PD{'check_switch_status'},'==',$expectedstatus_PD);
	
		$expectedextstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($tcpar_ExtStatus_val_FaultDequalified);
		S_teststep_expected("extstatus of $tcpar_Device changes to $expectedextstatus_PD");
		S_teststep_detected("extstatus of $tcpar_Device is $expectedextstatus_PD = $observedextstatus_PD{'check_switch_status'}");
		EVAL_evaluate_value ( "Switch Extended status for $tcpar_Device",$observedextstatus_PD{'check_switch_status'},'==',$expectedextstatus_PD);
		S_w2rep("##########################################################################################################################################################",'purple');

	return 1;
}

sub TC_finalization {
	if($tcpar_mode eq 'ECO')
	{
		S_set_error("ECO mode not yet implemented in AB12",'blue');
		S_set_verdict ( 'VERDICT_FAIL' );
		return 1;
	}
	elsif($tcpar_mode eq 'Disposal')
	{
		GDCOM_stop_CyclicTesterPresent($TP_handle);
		S_wait_ms('TIMER_TWO_SEC');
		PD_ClearFaultMemory();
	}
	else{
		S_set_error("ECU mode is not defined. Specify either ECO or Disposal mode.\n");
	}
	return 1;
}

############# local subroutines ##############


sub CheckValidDevice{

	if ($tcpar_Device eq 'NONE') 
	{  
	    S_set_error("Valid switch is not configured for this AIN Stop further execution\n");
	    $PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $tcpar_Device";
	    return 1;
    }
    else{
    if($switchType eq 'simple')
	{
    	if($tcpar_fault=~ m/OpenLine/ or $tcpar_fault=~ m/Undefined/ or $tcpar_fault=~ m/Short2GND]/){ #these faults are not possible for simple/mechanical switch
    		S_w2rep("$tcpar_fault fault is not possible for simple switch - $tcpar_Device. Stop further execution\n",'orange');
	    	$PURPOSE = "TESTCASE NOT EXECUTED: $tcpar_fault fault is not possible for simple switch - $tcpar_Device";
	    	return 1;
    		}
    	
		}
    }
}

1;
