### TEST CASE MODULE
package TC_SWM_MonitoringBasedOnFlags;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SWM/TC_SWM_MonitoringBasedOnFlags.pm 1.1 2019/07/15 11:57:42ICT Verma Nupur (RBEI/ESA-PP3) (ENU5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.166
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
use LIFT_evaluation;
use LIFT_PD;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_spi_access;
#include further modules here

##################################

our $PURPOSE = "To check that measurement and evaluation are skipped in case AMU is blocked";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_MonitoringBasedOnFlags

=head1 PURPOSE

To check that measurement and evaluation are skipped in case AMU is blocked

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set <switch> to <state>

2. Monitor the switch state, status and ASIC Fault Flags using Fast diagnosis for the below steps

3. Manipulate the <signal> of the <command> to the <value>

4. Change switch state, then create a switch fault

5. Read the Fault Recorder

6. Remove the switch fault

Note: ASIC fault flag can be Read using the SW labels corresponding to the AIN rb_swma_AsicChannelData_ast(AinNr).FaultFlags_u8


I<B<Evaluation>>

3. After the fault flag is set due to SPI Manipulation, switch state remains frozen as <state> and status is 'valid' for <FreezeTime>. It then changes to <switchPositionDuringFault> and status is 'fault' 

4. state remains as <switchPositionDuringFault> and status remains as 'fault' 

5. Switch fault <Fault> is qualified in the Fault Recorder

6. After the fault flag is reset, switch position and status is updated to the current valid values (<state> and 'valid')


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'state' => 
	SCALAR 'purpose' => 
	SCALAR 'switch' => 
	HASH 'Fault' => 
	SCALAR 'condition' => 
	SCALAR 'switchPositionDuringFault' => 
	SCALAR 'FreezeTime' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test switch monitoring when gs bit is set due to watchdog fault'
	
	switch = '<Test Heading>'
	Fault =%()
	condition = 'WatchdogFault_gsBitSet'
	switchPositionDuringFault = 'LastValid' #configurable by project
	FreezeTime = ' FreezeCounterLimit x SwitchCycleTime' #in ms.
	
	#Note: For the visibility of the filtered switch state i.e visible filtered state = freeze time + filter time(ms)
	state = 'positionA'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_switch;
my %tcpar_Fault;
my $tcpar_condition;
my $tcpar_switchPositionDuringFault;
my $tcpar_FreezeTime;
my $tcpar_state1;
my $tcpar_state2;
my $tcpar_command;
my $tcpar_signal;
my $tcpar_value;
################ global parameter declaration ###################
#add any global variables here
my $Detected_fault;
my $faultsAfterStimulation;
my $switchName;
my $StateAfterfault;
my $StateBeforefault;
my $expectedstateBeforefault;
my $expectedstateAfterfault;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_switch =  GEN_Read_mandatory_testcase_parameter( 'switch' );
	%tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_state1 =  GEN_Read_mandatory_testcase_parameter( 'state1' );
	$tcpar_state2 =  GEN_Read_mandatory_testcase_parameter( 'state2' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	$tcpar_signal =  GEN_Read_mandatory_testcase_parameter( 'signal' );
	$tcpar_value =  GEN_Read_mandatory_testcase_parameter( 'value' );
	
	#$switchName = DEVICE_fetchDeviceNamebyDeviceNumber ($tcpar_switch); 
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set '$tcpar_switch' to '$tcpar_state1'", 'AUTO_NBR');
	DEVICE_setDeviceState($tcpar_switch,$tcpar_state1);
	
	S_wait_ms(10000);

	S_teststep("Monitor the switch state, status and ASIC Fault Flags using Fast diagnosis for the below steps", 'AUTO_NBR');
	$StateBeforefault = DEVICE_readSwitchState_PD($tcpar_switch);
	S_w2rep("State of the switch before fault is $StateBeforefault");
	
	S_teststep("Manipulate the '$tcpar_signal' of the '$tcpar_command' to the '$tcpar_value'", 'AUTO_NBR', 'manipulate_the_signal');			#measurement 1
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	
	SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal,
				'SignalValue' => $tcpar_value,
				);
	
	S_w2rep("Start the Manipulation");
	
	SPI_start_manipulation();
	S_wait_ms(500);
	
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	S_wait_ms(1000,"Wait Time for SPI manipulation");
	S_teststep("Set '$tcpar_switch' to '$tcpar_state2'", 'AUTO_NBR');
	DEVICE_setDeviceState($tcpar_switch,$tcpar_state2);
	S_wait_ms(7000);
	
	S_teststep("Read the Fault Recorder", 'AUTO_NBR', 'read_the_fault');			#measurement 3
	$faultsAfterStimulation = PD_ReadFaultMemory();
	
	S_teststep("Read the switch state", 'AUTO_NBR');
	$StateAfterfault = DEVICE_readSwitchState_PD($tcpar_switch);
	S_w2rep("State of the switch after fault is $StateAfterfault");
	
	S_teststep("Remove the switch fault", 'AUTO_NBR', 'remove_the_switch');			#measurement 4
	SPI_stop_manipulation();
	
	return 1;
}

sub TC_evaluation {
	if($tcpar_state1 eq "positionA"){
		$expectedstateBeforefault = $expectedstateAfterfault = '0x00';
	}
	else{
		$expectedstateBeforefault = $expectedstateAfterfault = '0x01';
	}
	
	S_teststep_expected("Expected Switch State before fault : $tcpar_state1");			#evaluation 1
	EVAL_evaluate_value("State of the switch", $StateBeforefault, '==', $expectedstateBeforefault);
	S_teststep_detected("Detected switch state before :$StateBeforefault");
	
	foreach my $fault( keys %tcpar_Fault){
			if(PD_check_fault_exists($faultsAfterStimulation, $fault)){
				S_teststep_expected("'$fault' shall be qualified.");			#evaluation 3
				$Detected_fault = PD_GetFaultAttribute( $faultsAfterStimulation, $fault, 'fault_text' );
				S_teststep_detected("Detected Fault in the system:$Detected_fault");
			}
		}
	S_teststep_expected("Expected Switch State after fault : $tcpar_state1");			#evaluation 1
	EVAL_evaluate_value("State of the switch", $StateAfterfault, '==', $expectedstateAfterfault);
	S_teststep_detected("Detected switch state after fault:$StateAfterfault");
	
	return 1;
}

sub TC_finalization {
	
	PD_ClearFaultMemory();
    S_wait_ms(5000);
	return 1;
}


1;
