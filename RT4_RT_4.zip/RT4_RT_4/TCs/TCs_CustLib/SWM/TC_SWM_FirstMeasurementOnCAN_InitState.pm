#### TEST CASE MODULE
package TC_SWM_FirstMeasurementOnCAN_InitState;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: SWM/TC_SWM_FirstMeasurementOnCAN_InitState.pm 1.3 2019/07/24 19:30:45ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;  
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_can_access;
use FuncLib_TNT_SYC_INTERFACE;
##################################

our $PURPOSE = "To check if the switch signals are properly transmitted on CAN bus";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_FirstMeasurementOnCAN_InitState

=head1 PURPOSE

To check if the switch signals are properly transmitted on CAN bus

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the switch to positionB state

2. Power_on_reset 

3. Immediately after power ON Read the switch signal value on CAN bus.

4. Switch Off the ECU and set the switch to positionA

5. Power ON and immdiately Read the switch signal value on CAN bus.

6. Switch Off the ECU and create any fault on the switch

7. Power ON and immdiately Read the switch signal value on CAN bus.

8. Switch Off the ECU and remove the configuration bit

9. Power ON and immdiately Read the switch signal value on CAN bus.

10. Switch Off the ECU and remove the monitoring bit

11. Power ON and immdiately Read the switch signal value on CAN bus.

Finalization:

Set the monitoring and configuration bits


I<B<Evaluation>>

3. 

Initially, Switch state is <State_val_init>

State changes to <State_val_valid_belted> within ~ <time> from power ON

5. 

Initially, Switch state is <State_val_init>

State changes to <State_val_valid_unbelted> within ~<time> from power ON

7. 

Initially, Switch state is <State_val_init>

State changes to <State_val_valid_fault> within ~ <time> from power ON

9. 

Initially, Switch state is <State_val_init>

State changes to <State_val_notConfigured> within ~ <time> from power ON

11. 

Initially, Switch state is <State_val_init>

State changes to <State_val_notConfigured> within ~ <time> from power ON


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'CAN_Signal' => 
	SCALAR 'purpose' => 
	SCALAR 'State_val_init' => 
	SCALAR 'State_val_valid_belted' => 
	SCALAR 'State_val_valid_unbelted' => 
	SCALAR 'State_val_fault' => 
	SCALAR 'State_val_notConfigured' => 
	SCALAR 'Switch_Name' => 
	SCALAR 'time' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To check if the switch signals are properly transmitted on CAN bus'
	
	
	State_val_init = 1
	State_val_valid_belted = 3
	State_val_valid_unbelted = 2
	State_val_fault = 1
	State_val_notConfigured = 0
	Switch_Name='<Test Heading 2>'
	time = '350' #ms
	CAN_Signal='Airbag01_BeltLockFrontDriver'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_State_val_init;
my $tcpar_State_val_valid_belted;
my $tcpar_State_val_valid_unbelted;
my $tcpar_State_val_fault;
my $tcpar_State_val_notConfigured;
my $tcpar_Switch_Name;
my $tcpar_time;
my $tcpar_CAN_Signal;

################ global parameter declaration ###################
#add any global variables here
my $signal_val;
my $signal_val1;
my $signal_val2;
my $signal_val3 = undef;
my $signal_val4;
my ($unit, $unit1 ,$unit2 ,$unit3 ,$unit4);
my $Init_sw_state;

my $signal_val_time =0;
my $signal_val1_time=0;
my $signal_val2_time=0;
my $signal_val3_time=0;
my $signal_val4_time=0;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose','byvalue' );
	$tcpar_State_val_init =  S_read_mandatory_testcase_parameter( 'State_val_init','byvalue'  );
	$tcpar_State_val_valid_belted =  S_read_mandatory_testcase_parameter( 'State_val_valid_belted','byvalue' );
	$tcpar_State_val_valid_unbelted =  S_read_mandatory_testcase_parameter( 'State_val_valid_unbelted' ,'byvalue');
	$tcpar_State_val_fault =  S_read_mandatory_testcase_parameter( 'State_val_fault','byvalue' );
	$tcpar_State_val_notConfigured =  S_read_mandatory_testcase_parameter( 'State_val_notConfigured','byvalue' );
	$tcpar_Switch_Name =  S_read_mandatory_testcase_parameter( 'Switch_Name','byvalue' );
	$tcpar_time =  S_read_mandatory_testcase_parameter( 'time','byvalue' );
	$tcpar_CAN_Signal =  S_read_mandatory_testcase_parameter( 'CAN_Signal' ,'byvalue');

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	PD_InitDiagnosis();
	
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set the switch to positionB state", 'AUTO_NBR');
		my ($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $tcpar_Switch_Name, 'PositionB' );			## Fetching the switch state value( PositionB ) and switch type from SYC
		if($state_unit =~ /I/){
			LC_SetCurrent($tcpar_Switch_Name, $state_value);
		}elsif($state_unit =~ /R/){
			LC_SetResistance($tcpar_Switch_Name, $state_value);
		}
		S_wait_ms( 'SWITCH_STATE_CHANGE_TIME', 'wait after state change' );
		
		$Init_sw_state = DEVICE_readSwitchState_PD($tcpar_Switch_Name);
		
	S_teststep("Power_on_reset ", 'AUTO_NBR');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
		LC_ECU_On();

	S_teststep("Immediately after power ON Read the switch signal value on CAN bus.", 'AUTO_NBR');
		do{
			S_wait_ms(5);
			($signal_val,$unit) = CA_read_can_signal($tcpar_CAN_Signal,'phys');
			$signal_val_time = $signal_val_time + 5;
		}while($signal_val != $tcpar_State_val_valid_belted);
	
	S_teststep("Switch Off the ECU and set the switch to positionA", 'AUTO_NBR');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
		my ($result1, $state_value1, $state_unit1) = SYC_SWITCH_get_state( $tcpar_Switch_Name, 'PositionA' );		## Fetching the switch state value( PositionA ) and switch type from SYC
		if($state_unit1 =~ /I/){
			LC_SetCurrent($tcpar_Switch_Name, $state_value1);
		}elsif($state_unit1 =~ /R/){
			LC_SetResistance($tcpar_Switch_Name, $state_value1);
		}
		S_wait_ms( '2000', 'wait after state change' );

	S_teststep("Power ON and immdiately Read the switch signal value on CAN bus.", 'AUTO_NBR');
		LC_ECU_On();
		do{
			S_wait_ms(5);
			($signal_val1,$unit1) = CA_read_can_signal($tcpar_CAN_Signal,'phys');
			$signal_val1_time = $signal_val1_time + 5;
		}while($signal_val1 != $tcpar_State_val_valid_unbelted);
		
	S_teststep("Switch Off the ECU and create any fault on the switch", 'AUTO_NBR');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
		FM_createFault('rb_swm_Short2Bat'.$tcpar_Switch_Name.'_flt'); 											   ## Creating Short2bat fault
		S_w2rep('TIMER_ECU_FAULT_QUALIFICATION');
		
		
	S_teststep("Power ON and immdiately Read the switch signal value on CAN bus.", 'AUTO_NBR');
		LC_ECU_On();
		do{
			S_wait_ms(5);
			($signal_val2,$unit2) = CA_read_can_signal($tcpar_CAN_Signal,'phys');
			$signal_val2_time = $signal_val2_time + 5;
		}while($signal_val2 != $tcpar_State_val_fault);
		S_w2rep(" CAN Signal value : $signal_val2",'Green');
		S_wait_ms('TIMER_ECU_READY');
		PD_ReadFaultMemory();
	
	S_teststep("Remove the configuration bit and switch Off the ECU", 'AUTO_NBR');
		PD_Device_configuration( 'clear', [$tcpar_Switch_Name]);												  ## Removing the Configure bit	
		S_wait_ms('TIMER_SIX_SEC');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
		
	S_teststep("Power ON and immdiately Read the switch signal value on CAN bus.", 'AUTO_NBR');
		LC_ECU_On();
		do{
			S_wait_ms(5);
			($signal_val3,$unit3) = CA_read_can_signal($tcpar_CAN_Signal,'phys');
			$signal_val3_time = $signal_val3_time + 5;
		}while($signal_val3 != $tcpar_State_val_notConfigured);
		S_w2rep(" CAN Signal value : $signal_val3",'Green');
		S_wait_ms('TIMER_ECU_READY');
		
	S_teststep("Remove the monitoring bit and switch Off the ECU", 'AUTO_NBR');
		PD_Device_configuration( 'clear_Mon', [$tcpar_Switch_Name]);											  ## Removing the Monitor bit
		S_wait_ms('TIMER_SIX_SEC');
		LC_ECU_Off();
		S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	
	S_teststep("Power ON and immdiately Read the switch signal value on CAN bus.", 'AUTO_NBR');
		LC_ECU_On();
		do{
			S_wait_ms(5);
			($signal_val4,$unit4) = CA_read_can_signal($tcpar_CAN_Signal,'phys');
			$signal_val4_time = $signal_val4_time + 5;
		}while($signal_val4 != $tcpar_State_val_notConfigured);
		S_wait_ms('TIMER_ECU_READY');
		S_w2rep(" CAN Signal value : $signal_val4",'Green');
		
	S_teststep("Finalization: Set the monitoring and configuration bits", 'AUTO_NBR');
		PD_Device_configuration( 'set_Mon', [$tcpar_Switch_Name] );												## Setting the Configure bit	
		S_wait_ms('TIMER_SIX_SEC');
		PD_Device_configuration( 'set', [$tcpar_Switch_Name] );													 ## Setting the Monitor bit
		S_wait_ms('TIMER_SIX_SEC');
	
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Initially, Switch state is '$tcpar_State_val_init'");
	S_teststep_detected("Detected Switch state is '$Init_sw_state'");
	EVAL_evaluate_value("Switch state is '$tcpar_State_val_init'", $Init_sw_state, "==", $tcpar_State_val_init ); 

	S_teststep_expected("State changes to '$tcpar_State_val_valid_belted' within ~ '$tcpar_time' from power ON");
	S_teststep_detected("State changes to '$signal_val' within '$signal_val_time'");
	EVAL_evaluate_value("State changed within '$signal_val_time'", $signal_val_time, "<=", $tcpar_time ); 
	EVAL_evaluate_value("Switch changes to '$tcpar_State_val_valid_belted'", $signal_val, "==", $tcpar_State_val_valid_belted ); 

	S_teststep_expected("State changes to '$tcpar_State_val_valid_unbelted' within ~'$tcpar_time' from power ON");
	S_teststep_detected("State changes to '$signal_val1' within '$signal_val1_time'");
	EVAL_evaluate_value("State changed within '$signal_val1_time'", $signal_val1_time, "<=", $tcpar_time );
	EVAL_evaluate_value("Switch changes to '$tcpar_State_val_valid_unbelted'", $signal_val1, "==", $tcpar_State_val_valid_unbelted );

	S_teststep_expected("State changes to '$tcpar_State_val_fault' within ~ '$tcpar_time' from power ON");
	S_teststep_detected("State changes to '$signal_val2' within '$signal_val2_time'");
	EVAL_evaluate_value("State changed within '$signal_val2_time'", $signal_val2_time, "<=", $tcpar_time );
	EVAL_evaluate_value("Switch changes to '$tcpar_State_val_fault'", $signal_val2, "==", $tcpar_State_val_fault );

	S_teststep_expected("State changes to '$tcpar_State_val_notConfigured' within ~ '$tcpar_time' from power ON");
	S_teststep_detected("State changes to '$signal_val3' within '$signal_val3_time'");
	EVAL_evaluate_value("State changed within '$signal_val3_time'", $signal_val3_time, "<=", $tcpar_time );
	EVAL_evaluate_value("Switch changes to '$tcpar_State_val_notConfigured'", $signal_val3, "==", $tcpar_State_val_notConfigured );

	S_teststep_expected("State changes to '$tcpar_State_val_notConfigured' within ~ '$tcpar_time' from power ON");
	S_teststep_detected("State changes to '$signal_val4'");
	EVAL_evaluate_value("State changed within '$signal_val4_time'", $signal_val4_time, "<=", $tcpar_time );
	EVAL_evaluate_value("Switch changes to '$tcpar_State_val_notConfigured'", $signal_val4, "==", $tcpar_State_val_notConfigured );

	return 1;
}

sub TC_finalization {

		FM_removeFault('rb_swm_Short2Bat'.$tcpar_Switch_Name.'_flt');							## Removing the qualified fault
		S_wait_ms('TIMER_SIX_SEC');
		LC_ECU_Reset();
		PD_ClearFaultMemory();
		PD_ReadFaultMemory();
		
	return 1;
}


1;
