#### TEST CASE MODULE
package TC_SWM_CrossCouplingTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: SWM/TC_SWM_CrossCouplingTest.pm 1.3 2020/05/22 18:44:43ICT Purushotham Reddy Chinnasani (RBEI/ESA-PP2) (UCP5KOR) develop  $;
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_PD;
use LIFT_evaluation;
use INCLUDES_Project;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_CrossCouplingTest  $Revision: 1.3 $

requires LIFT_PD, general, evaluation and Project_SWM_Functions

default state is faultfree ECU powered ON

=head1 PURPOSE

To test Switch monitoring during Init - Cross coupling test

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPrepNoFault
	Set switch1 and switch2 to positionB

    [stimulation & measurement]
    Repeat the below sequence of steps for all Test Conditions
    1. Set the Test Condition
    2. Read the fault recorder
    3. Read switch state and status
    
    Test Conditions:
    CrossCoupledBeforeReset - create a crosscouple between the two switches - don't reset the ECU
    CrossCoupledAfterReset - 
    FaultQualifiedandPositionChange - When switch fault is qualified, change the switch state/position
    RemoveCrossCoupleCreateOpenline - remove the crosscouple and create an openline condition on both switches
    RemoveOpenline - remove the openline fault and reset

    [evaluation]
    Repeat the below sequence of steps for all Test Conditions
    2. Evaluate the expected faults
    3. Evaluate the Switch state and status

    [finalisation]
    Clear Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose'                   			--> Purpose of the test case
   #SETTINGS
    SCALAR 'Device1'                   			--> Switch input/AIN to which the switch1 is connected - <TestHeading1>
    SCALAR 'Device2'                   			--> Switch input/AIN to which the switch2 is connected - <TestHeading2>
   #FAULTS 
    HASH   'FLT_mand_CrossCoupledBeforeReset'   --> expected faults with status - under 'CrossCoupledBeforeReset' condition
    HASH   'FLT_mand_CrossCoupledAfterReset'   	--> expected faults with status - under 'CrossCoupledAfterReset' condition
    HASH   'FLT_mand_RemoveOpenline' 			--> expected faults with status - under 'RemoveOpenline' condition  
   #STATE and STATUS
   #CrossCoupledBeforeReset
    SCALAR 'State_val_CrossCoupledBeforeReset'         --> switch state under 'CrossCoupledBeforeReset' condition
    SCALAR 'Status_val_CrossCoupledBeforeReset'        --> switch state status(validity) under 'CrossCoupledBeforeReset' condition
   #CrossCoupledAfterReset
    SCALAR 'State_val_CrossCoupledAfterReset'  --> switch state under 'CrossCoupledAfterReset' condition
    SCALAR 'Status_val_CrossCoupledAfterReset' --> switch state status under 'CrossCoupledAfterReset' condition
   #RemoveOpenline
    SCALAR 'State_val_RemoveOpenline'  --> switch state under 'RemoveOpenline' condition
    SCALAR 'Status_val_RemoveOpenline' --> switch state status under 'RemoveOpenline' condition
    

=head2 PARAMETER EXAMPLES

    [TC_SWM_CrossCouplingTest.SwitchInput1_SwitchInput2]   #ID: SRTP_SWM_1978
    # From here on: applicable Lift Default Parameters
    purpose = 'To test OpenLine fault when switch is monitored and configured'
    Device1 = 'SwitchInput1'
    Device2 = 'SwitchInput2'
    USE_FAULTQUALIFIEDandPOSITIONCHANGE = 'yes'
    FLT_mand_CrossCoupledBeforeReset = %('swm_CrossCoupling_FAULT' => '0bxx000000')
    FLT_mand_CrossCoupledAfterReset = %('swm_CrossCoupling_FAULT' => '0bxx011111')
    FLT_mand_RemoveOpenline = %('swm_CrossCoupling_FAULT' => '0bxx001110')
    State_val_CrossCoupledBeforeReset = 'swm_SWITCHSTATE_VAL_POSITIONA'
    Status_val_CrossCoupledBeforeReset = 'swm_STATUS_VALID'
    State_val_CrossCoupledAfterReset = 'swm_SWITCHSTATE_VAL_POSITIONB'
    Status_val_CrossCoupledAfterReset = 'swm_STATUS_FAULT'
    State_val_RemoveOpenline = 'swm_SWITCHSTATE_VAL_POSITIONA'
    Status_val_RemoveOpenline = 'swm_STATUS_VALID'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
   
my ($defaultpar_purpose);
#SETTINGS
my ($defaultpar_Device1,
	$defaultpar_Device2);
#FAULTS
my (%defaultpar_FLT_mand);
my $tcpar_FLTopt1_Short2Gnd;
my $tcpar_FLTopt2_Undefined;
my $tcpar_FLTmand_CrossCouple;
#STATE and STATUS
my (%defaultpar_Read_val);

#From ProjConst
my ($switch1Name,
    $switch1Type,
    $Switch1_positionA,
    $Switch1_positionB);
my ($switch2Name,
	$switch2Type,
    $Switch2_positionA,
    $Switch2_positionB);

#global 
our $PURPOSE;
my (%flt_mem_struct);
my (%SwitchState_val,
    %SwitchStatus_val);
my $SwitchStateChangeTime;
    
my @Testcondition = ('CrossCoupledBeforeReset',
                     'CrossCoupledAfterReset',
                     'FaultQualifiedandPositionchange',
                     'RemoveCrossCoupleCreateOpenline',
                     'RemoveOpenline');
                     


sub TC_set_parameters {
    
    $defaultpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
    $defaultpar_Device1 =  GEN_Read_mandatory_testcase_parameter( 'Device1' );  
    $defaultpar_Device2 =  GEN_Read_mandatory_testcase_parameter( 'Device2' );
	
	$tcpar_FLTopt1_Short2Gnd = S_read_mandatory_testcase_parameter('FLTopt1_Short2Gnd');
	$tcpar_FLTopt2_Undefined = S_read_mandatory_testcase_parameter('FLTopt2_Undefined');
	$tcpar_FLTmand_CrossCouple = S_read_mandatory_testcase_parameter('FLTmand_CrossCouple');
	
    $defaultpar_FLT_mand{'CrossCoupledBeforeReset'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_CrossCoupledBeforeReset','byref' );
    $defaultpar_FLT_mand{'CrossCoupledAfterReset'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_CrossCoupledAfterReset','byref');
    $defaultpar_FLT_mand{'FaultQualifiedandPositionchange'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_CrossCoupledAfterReset','byref');
    $defaultpar_FLT_mand{'RemoveCrossCoupleCreateOpenline'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_CrossCoupledAfterReset','byref');
    $defaultpar_FLT_mand{'RemoveOpenline'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_RemoveOpenline','byref');
    
    # $defaultpar_Read_val{'state'}{'CrossCoupledBeforeReset'} = GEN_Read_mandatory_testcase_parameter( 'State_val_CrossCoupledBeforeReset' );
    # $defaultpar_Read_val{'status'}{'CrossCoupledBeforeReset'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_CrossCoupledBeforeReset' );
    $defaultpar_Read_val{'state'}{'CrossCoupledAfterReset'} = GEN_Read_mandatory_testcase_parameter( 'State_val_CrossCoupledAfterReset' );
    $defaultpar_Read_val{'status'}{'CrossCoupledAfterReset'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_CrossCoupledAfterReset' );
    $defaultpar_Read_val{'state'}{'RemoveOpenline'} = GEN_Read_mandatory_testcase_parameter( 'State_val_RemoveOpenline' );
    $defaultpar_Read_val{'status'}{'RemoveOpenline'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_RemoveOpenline' );   
    
    $defaultpar_Read_val{'state'}{'FaultQualifiedandPositionchange'} = $defaultpar_Read_val{'state'}{'CrossCoupledAfterReset'}; #no change in state
    $defaultpar_Read_val{'status'}{'FaultQualifiedandPositionchange'} = $defaultpar_Read_val{'status'}{'CrossCoupledAfterReset'}; #no change in state    
    $defaultpar_Read_val{'state'}{'RemoveCrossCoupleCreateOpenline'} = $defaultpar_Read_val{'state'}{'CrossCoupledAfterReset'}; #no change in state 
    $defaultpar_Read_val{'status'}{'RemoveCrossCoupleCreateOpenline'} = $defaultpar_Read_val{'status'}{'CrossCoupledAfterReset'}; #no change in state
	
 
	
	
  
    
    # check if used ProjectDefaults constants are defined 
    $SwitchStateChangeTime = 1000;
    
    # $switch1Name = $defaultpar_Device1;
	$switch1Name = DEVICE_fetchDeviceNamebyDeviceNumber($defaultpar_Device1); 
    $switch1Type = DEVICE_fetchSwitchType ($switch1Name);
    $Switch1_positionA =  DEVICE_fetchSwitchState($switch1Name,'positionA');   
    $Switch1_positionB =  DEVICE_fetchSwitchState($switch1Name,'positionB');
    
    # $switch2Name = $defaultpar_Device2;  
	$switch2Name = DEVICE_fetchDeviceNamebyDeviceNumber($defaultpar_Device2);
    $switch2Type = DEVICE_fetchSwitchType ($switch2Name);
    $Switch2_positionA =  DEVICE_fetchSwitchState($switch1Name,'positionA');   
    $Switch2_positionB =  DEVICE_fetchSwitchState($switch1Name,'positionB');
    
    #to print the purpose wrt device being tested
    $PURPOSE = "To test Switch monitoring during Init - Cross coupling test for $switch1Name ( $switch1Type switch ) and $switch2Name ( $switch2Type switch )";
    
    #If no device is assigned then skip execution. Verdict will be 'NONE'
    return 1 if CheckValidDevice();
    
     
return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {
    
    #before proceeding check if a valid device is configured for both
	return 1 if CheckValidDevice();
    
    S_w2rep('StandardPrepNoFault', 'blue'); 
    GEN_StandardPrepNoFault();
    
    S_w2rep("Set switch1 to $Switch1_positionB and switch2 to $Switch2_positionB", 'blue'); 
    DEVICE_setDeviceState( $switch1Name, $Switch1_positionB );
    DEVICE_setDeviceState( $switch2Name, $Switch2_positionB );
    S_wait_ms( 2000 );
        
  return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    #before proceeding check if a valid device is configured for both
	return 1 if CheckValidDevice();
    
    my $teststep = 1;
    foreach my $condition (@Testcondition){
        S_w2rep("$condition", 'orange');
        S_w2rep("Step$teststep", 'blue');$teststep++;
        DEVICE_setSwitchCCTestCondition($switch1Name,$switch2Name,$condition);
                
        S_w2rep("Step$teststep: Read the fault recorder", 'blue');$teststep++;
        $flt_mem_struct{$condition} = FM_PD_readFaultMemory();
    
        S_w2rep("Step$teststep: Read switch state and status", 'blue');$teststep++;
        Readswitchstate ($switch1Name, $condition);
        Readswitchstate ($switch2Name, $condition);
        Readswitchstatus ($switch1Name, $condition);
        Readswitchstatus ($switch2Name, $condition);    
    }
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
    #before proceeding check if a valid device is configured for both
	return 1 if CheckValidDevice();

    	my $faultopt1     = $tcpar_FLTopt1_Short2Gnd . $switch1Name . '_flt';
		my $faultopt2     = $tcpar_FLTopt1_Short2Gnd . $switch2Name . '_flt';
		my $faultopt3     = $tcpar_FLTopt2_Undefined . $switch1Name . '_flt';
		my $faultopt4     = $tcpar_FLTopt2_Undefined . $switch2Name . '_flt';
		my @tcpar_FLTopt  = ( $faultopt1, $faultopt2, $faultopt3, $faultopt4 );

	
		my $faultname_CC1 = $tcpar_FLTmand_CrossCouple. $switch1Name . '_flt';
		my $faultname_CC2 = $tcpar_FLTmand_CrossCouple. $switch2Name . '_flt';
		my @tcpar_FLTmand = ( $faultname_CC1, $faultname_CC2 );
		
	    my $teststep = 2;
		
		foreach my $condition (@Testcondition){
        S_w2rep("$condition", 'orange');
        S_w2rep("Step$teststep: evaluate expected faults of step $teststep", 'blue'); $teststep++;
        FM_checkDeviceFaults_local ($flt_mem_struct{$condition}, $switch1Name, $defaultpar_FLT_mand{$condition}); 
        FM_checkDeviceFaults_local ($flt_mem_struct{$condition}, $switch2Name, $defaultpar_FLT_mand{$condition});  
		if($condition eq 'CrossCoupledBeforeReset')
		{
		 FM_evaluateFaults( $flt_mem_struct{$condition},[], \@tcpar_FLTopt );    #confirm that no other faults are present
		 }else{
		 
		 FM_evaluateFaults( $flt_mem_struct{$condition}, \@tcpar_FLTmand, \@tcpar_FLTopt );    #confirm that no other faults are present
        }
		if($condition ne 'CrossCoupledBeforeReset')   #check the state and status only if condiiton is not equal to 'CrossCoupledBeforeReset' as the state and status can't be expected
		{
         S_w2rep("Step$teststep: evaluate State and status of step $teststep", 'blue'); $teststep++;
	     Evaluateswitchstate ($switch1Name, $condition); 
	     Evaluateswitchstate ($switch2Name, $condition); 
	     Evaluateswitchstatus ($switch1Name, $condition); 	    
	     Evaluateswitchstatus ($switch2Name, $condition); 
        }		 
	                 
        $teststep++;
    }
	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
    
    #before proceeding check if a valid device is configured for both
	return 1 if CheckValidDevice();
    
    DEVICE_setDeviceState( $switch1Name, $Switch1_positionA );
    DEVICE_setDeviceState( $switch2Name, $Switch2_positionA );
    GEN_Finalization  ();
    
	return 1;
}

###################local subs#################

sub CheckValidDevice{
	if (($switch1Name eq 'NONE') || ($switch2Name eq 'NONE')){
	    S_w2rep("Valid switch is not configured for one of the AINs Stop further execution\n", 'orange');
	    $PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for any/both of these: $switch1Name or $switch2Name";
	    return 1;
    }
}


sub Readswitchstate{
    my $device = shift;
    my $condition = shift;
    
    $SwitchState_val{$device}{$condition}{'PD'} =  DEVICE_readSwitchState_PD($device);
    #$SwitchState_val{$device}{$condition}{'CD'} =  SWM_ReadSwitchState_CD($device);
    #$SwitchState_val{$device}{$condition}{'CAN'} =  SWM_ReadSwitchState_CAN($device);
    #$SwitchState_val{$device}{$condition}{'FR'} =  SWM_ReadSwitchState_FR($device);     
}

sub Readswitchstatus{
    my $device = shift;
    my $condition = shift;
    
    $SwitchStatus_val{$device}{$condition}{'PD'} =  DEVICE_readSwitchStatus_PD($device);
    #$SwitchStatus_val{$device}{$condition}{'CD'} =  SWM_ReadSwitchStatus_CD($device);
    #$SwitchStatus_val{$device}{$condition}{'CAN'} =  SWM_ReadSwitchStatus_CAN($device);
    #$SwitchStatus_val{$device}{$condition}{'FR'} =  SWM_ReadSwitchStatus_FR($device);     
}


sub Evaluateswitchstate{
    my $device = shift;
    my $condition = shift;
    
	my $deviceProperties = DEVICE_fetchDeviceInfo($device);
    my $expectedstate_PD = $deviceProperties->{$defaultpar_Read_val{'state'}{$condition}};
    # my $expectedstate_PD = DEVICE_fetchExpectedSwitchState_PD ($defaultpar_Read_val{'state'}{$condition});
    my $observedstate_PD = $SwitchState_val{$device}{$condition}{'PD'};
    S_w2rep("Switch_State:\n Expected:$expectedstate_PD\n Observed:$observedstate_PD");
    EVAL_evaluate_value ( "SW State", $expectedstate_PD, '==', $observedstate_PD  );
    
    #SWM_EvaluateSwitchState_PD($defaultpar_Read_val{'state'}{$condition},$SwitchState_val{$device}{$condition}{'PD'});
    #SWM_EvaluateSwitchState_CD($defaultpar_Read_val{'state'}{$condition},$SwitchState_val{$device}{$condition}{'CD'});
    #SWM_EvaluateSwitchState_CAN($defaultpar_Read_val{'state'}{$condition},$SwitchState_val{$device}{$condition}{'CAN'});
    #SWM_EvaluateSwitchState_FR($defaultpar_Read_val{'state'}{$condition},$SwitchState_val{$device}{$condition}{'FR'});   
}

sub Evaluateswitchstatus{
    my $device = shift;
    my $condition = shift;
    
    my $expectedstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($defaultpar_Read_val{'status'}{$condition});
    my $observedstatus_PD = $SwitchStatus_val{$device}{$condition}{'PD'};
    S_w2rep("Switch_Status:\n Expected:$expectedstatus_PD\n Observed:$observedstatus_PD");
    EVAL_evaluate_value ( "SW State", $expectedstatus_PD, '==', $observedstatus_PD  );
    
    #SWM_EvaluateSwitchStatus_PD($defaultpar_Read_val{'status'}{$condition},$SwitchStatus_val{$device}{$condition}{'PD'});
    #SWM_EvaluateSwitchStatus_CD($defaultpar_Read_val{'status'}{$condition},$SwitchStatus_val{$device}{$condition}{'CD'});
    #SWM_EvaluateSwitchStatus_CAN($defaultpar_Read_val{'status'}{$condition},$SwitchStatus_val{$device}{$condition}{'CAN'});
    #SWM_EvaluateSwitchStatus_FR($defaultpar_Read_val{'status'}{$condition},$SwitchStatus_val{$device}{$condition}{'FR'});    
}

sub FM_checkDeviceFaults_local {
	my $flt_mem_struct = shift;
	my $devicename     = shift;
	my $check_FLT_mand = shift;

	my $faultname;
	my $faultstatus;
	# my @expectedfaults;

	foreach my $key ( keys %$check_FLT_mand ) {    #perform the check for each fault

		my %SearchHash;
		$SearchHash{'Device'} = $devicename if ( $key !~ m/HighVoltage|LowVoltage|IdleMode/i );
		$SearchHash{'Condition'} = $key;

		my $faults = FM_fetchFaultName( \%SearchHash );
		$faultname = @$faults[0];
		

		$faultstatus = $check_FLT_mand->{$key};
		if ( defined $faultname ) {
			FM_checkFaultStatus( $flt_mem_struct, $faultname, $faultstatus );    #check the status for each fault
			# push( @expectedfaults, $faultname );
		}
	}
	#PD_clearfaultrecorder
	#FM_evaluateFaults( $flt_mem_struct, [], \@expectedfaults );                  #to check that no other faults are present

	return 1;
}



1;


__END__