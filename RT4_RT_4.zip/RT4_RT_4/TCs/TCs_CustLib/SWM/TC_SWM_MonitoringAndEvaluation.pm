#### TEST CASE MODULE
package TC_SWM_MonitoringAndEvaluation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: SWM/TC_SWM_MonitoringAndEvaluation.pm 1.4 2020/05/22 18:55:53ICT Purushotham Reddy Chinnasani (RBEI/ESA-PP2) (UCP5KOR) develop  $;
################################## 

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.28
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general; 
use LIFT_PD;
use LIFT_evaluation;
use INCLUDES_Project;
use FuncLib_ACEA_TNT;


##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_MonitoringAndEvaluation  $Revision: 1.4 $

requires LIFT_PD, general, evaluation and Project_SWM_Functions

default state is faultfree ECU powered ON

=head1 PURPOSE

To test Switch monitoring and evaluation requirements

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPrepNoFault
    Set switch to <MonitoringBitStatus> and <ConfigurationBitStatus>
    Set supply voltage
    Set mode

    [stimulation & measurement]
    Repeat the below sequence of steps for all Test Conditions
    1. Set the Test Condition
    2. Read the fault recorder
    3. Read switch state and status
    
    Test Conditions:
    NofaultpositionA
    NofaultpositionB
    FaultQualified - 
    FaultQualifiedandPositionChange - When switch fault is qualified, change the switch state/position
    FaultDequalified
    ThresholdCheckQualify - Switch evaluation thresholds out of valid measurement bands
    ThresholdCheckDequalify

    [evaluation]
    Repeat the below sequence of steps for all Test Conditions
    2. Evaluate the expected faults
    3. Evaluate the Switch state and status

    [finalisation]
    Clear Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'purpose'                   --> Purpose of the test case
   #SETTINGS
    SCALAR 'Device'                    --> Switch input/AIN to which the device is connected - <TestHeading>
    SCALAR 'MonitoringBitStatus'       --> Monitoring bit status. Is the device monitored? -  "set_Mon", "clear_Mon" to enable/disable monitoring
    SCALAR 'ConfigurationBitStatus'    --> Configuration bit status. Is the device configured? - may be "set", "clear" to configure/unconfigue
    SCALAR 'supply'                    --> Voltage supply to which the device is connected - VBat/Vup/VAS
    SCALAR 'voltage'                   --> supply Voltage to be set - in volts
    SCALAR 'mode'                      --> system mode - Normal/Idlemode
   #OPTIONS
    SCALAR 'USE_FaultQualifiedandPositionChange' --> set to 'yes' if this test condition is to be checked: FaultQualifiedandPositionChange
   #FAULTS 
    SCALAR 'fault'                     --> fault to be qualified - OpenLine/Short2Bat/Short2GND/Undefined/Configuration
    SCALAR 'faulttype'                 --> type of the fault to be qualified - 'init' or 'cyclic' or 'init/cyclic' (both)
    SCALAR 'Qualitime'                 --> Time to qualify a switch fault - in ms
    SCALAR 'Dequalitime'               --> Time to dequalify a switch fault - in ms
    HASH   'FLT_mand_Nofault'          --> expected faults with status - under 'Nofault' condition
    HASH   'FLT_mand_FaultQualified'   --> expected faults with status - under 'FaultQualified' condition
    HASH   'FLT_mand_FaultDequalified' --> expected faults with status - under 'FaultDequalified' condition
    
   #STATE and STATUS
   #Nofault
    SCALAR 'State_val_NofaultpositionA'         --> switch state under 'Nofault' condition - positionA
	SCALAR 'State_val_NofaultpositionB'         --> switch state under 'Nofault' condition - positionB
    SCALAR 'Status_val_Nofault'        --> switch state status(validity) under 'Nofault' condition
   #FaultQualified
    SCALAR 'State_val_FaultQualified'  --> switch state under 'FaultQualified' condition
    SCALAR 'Status_val_FaultQualified' --> switch state status under 'FaultQualified' condition
   #FaultDequalified
    SCALAR 'State_val_FaultDequalified'  --> switch state under 'FaultDequalified' condition
    SCALAR 'Status_val_FaultDequalified' --> switch state status under 'FaultDequalified' condition

	
=head2 PARAMETER EXAMPLES
	   
	[TC_SWM_MonitoringAndEvaluation.MonitoredandConfigured_OpenLineSwitchInput1]   #ID: SRTP_SWM_1978
	# From here on: applicable Lift Default Parameters
	purpose	= 'To test OpenLine fault when switch is monitored and configured'
	Device = 'SwitchInput1'
	MonitoringBitStatus = 'set_Mon'
	ConfigurationBitStatus = 'set'
	supply = 'Vup'
	voltage = '13' #volts
	mode = 'normal'
	USE_FaultQualifiedandPositionChange = 'no'
	fault = 'OpenLine'
	faulttype = 'cyclic'
	Qualitime = '6000' #ms
	Dequalitime = '6000' #ms
	FLT_mand_Nofault =  %('swm_OpenLine_FAULT' => '0bxx000000')
	FLT_mand_FaultQualified = %('swm_OpenLine_FAULT' => '0bxxxxx111')
	FLT_mand_FaultDequalified = %('swm_OpenLine_FAULT' => '0bxxxxx110')
	State_val_NofaultpositionA = 'swm_SWITCHSTATE_VAL_POSITIONA'
	State_val_NofaultpositionB = 'swm_SWITCHSTATE_VAL_POSITIONB'
	Status_val_Nofault = 'swm_STATUS_VALID'
	State_val_FaultQualified = 'swm_SWITCHSTATE_VAL_POSITIONA'
	Status_val_FaultQualified = 'swm_STATUS_FAULT'
	State_val_FaultDequalified = 'swm_SWITCHSTATE_VAL_POSITIONA'
	Status_val_FaultDequalified = 'swm_STATUS_VALID'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
   
my ($defaultpar_purpose);
#SETTINGS
my ($defaultpar_Device,
    $defaultpar_MonitoringBitStatus,
    $defaultpar_ConfigurationBitStatus,
    $defaultpar_supply,
    $defaultpar_voltage,
    $defaultpar_mode);
#OPTIONS
my ($defaultpar_USE_FAULTQUALIFIEDandPOSITIONCHANGE);
#FAULTS
my (%defaultpar_FLT_mand);
#STATE and STATUS
my (%defaultpar_Read_val);

#From ProjConst
my ($switchName,
    $switchType,
    $Switch_positionA,
    $Switch_positionB);

#global 
our $PURPOSE;
my (%flt_mem_struct);
my (%SwitchState_val,
    %SwitchStatus_val,
    %SwitchExtendedStatus_val);
my $SwitchStateChangeTime;  
my $defaultpar_switchFault;  
my ($deviceName);
my @Testcondition = ('NofaultpositionA',
					 'NofaultpositionB',
                     'FaultQualified',
                     'FaultQualifiedandPositionChange',
                     'FaultDequalified');
                     

sub TC_set_parameters {
    $defaultpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
    $defaultpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );  
    $defaultpar_MonitoringBitStatus =  GEN_Read_mandatory_testcase_parameter( 'MonitoringBitStatus' );
	$defaultpar_ConfigurationBitStatus =  GEN_Read_mandatory_testcase_parameter( 'ConfigurationBitStatus' );     
    $defaultpar_supply =  GEN_Read_mandatory_testcase_parameter( 'supply' );  
    $defaultpar_voltage =  GEN_Read_mandatory_testcase_parameter( 'voltage' );   
    $defaultpar_mode =  GEN_Read_mandatory_testcase_parameter( 'mode' );     
    $defaultpar_USE_FAULTQUALIFIEDandPOSITIONCHANGE =  GEN_Read_mandatory_testcase_parameter( 'USE_FAULTQUALIFIEDandPOSITIONCHANGE' );  
    
    $defaultpar_switchFault =  GEN_Read_mandatory_testcase_parameter( 'fault' ); 

    $defaultpar_FLT_mand{'NofaultpositionA'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_Nofault' ,'byref' );
    $defaultpar_FLT_mand{'NofaultpositionB'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_Nofault' , 'byref');
    $defaultpar_FLT_mand{'FaultQualified'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_FaultQualified', 'byref');
    $defaultpar_FLT_mand{'FaultQualifiedandPositionChange'} = GEN_Read_optional_testcase_parameter( 'FLT_mand_FaultQualifiedandPositionChange', 'byref'); #optional since this is not applicable for some faults/conditions
    $defaultpar_FLT_mand{'FaultDequalified'} = GEN_Read_mandatory_testcase_parameter( 'FLT_mand_FaultDequalified', 'byref');
    
    $defaultpar_Read_val{'state'}{'NofaultpositionA'} = GEN_Read_mandatory_testcase_parameter( 'State_val_NofaultpositionA' );
    $defaultpar_Read_val{'state'}{'NofaultpositionB'} = GEN_Read_mandatory_testcase_parameter( 'State_val_NofaultpositionB' );
    $defaultpar_Read_val{'status'}{'NofaultpositionA'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_Nofault' );
    $defaultpar_Read_val{'Extstatus'}{'NofaultpositionA'} = GEN_Read_mandatory_testcase_parameter( 'ExtStatus_val_Nofault' );
    $defaultpar_Read_val{'status'}{'NofaultpositionB'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_Nofault' );
    $defaultpar_Read_val{'Extstatus'}{'NofaultpositionB'} = GEN_Read_mandatory_testcase_parameter( 'ExtStatus_val_Nofault' );
    $defaultpar_Read_val{'state'}{'FaultQualified'} = GEN_Read_mandatory_testcase_parameter( 'State_val_FaultQualified' );
    $defaultpar_Read_val{'status'}{'FaultQualified'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_FaultQualified' );
    $defaultpar_Read_val{'Extstatus'}{'FaultQualified'} = GEN_Read_mandatory_testcase_parameter( 'ExtStatus_val_FaultQualified' );
    $defaultpar_Read_val{'state'}{'FaultDequalified'} = GEN_Read_mandatory_testcase_parameter( 'State_val_FaultDequalified' );
    $defaultpar_Read_val{'status'}{'FaultDequalified'} = GEN_Read_mandatory_testcase_parameter( 'Status_val_FaultDequalified' );
    $defaultpar_Read_val{'Extstatus'}{'FaultDequalified'} = GEN_Read_mandatory_testcase_parameter( 'ExtStatus_val_FaultDequalified' );        
    $defaultpar_Read_val{'state'}{'FaultQualifiedandPositionChange'} = GEN_Read_optional_testcase_parameter( 'State_val_FaultQualifiedandPositionChange'); #optional since this is not applicable for some faults/conditions
    $defaultpar_Read_val{'status'}{'FaultQualifiedandPositionChange'} = GEN_Read_optional_testcase_parameter( 'Status_val_FaultQualifiedandPositionChange'); #optional since this is not applicable for some faults/conditions
    $defaultpar_Read_val{'Extstatus'}{'FaultQualifiedandPositionChange'} = GEN_Read_optional_testcase_parameter( 'ExtStatus_val_FaultQualifiedandPositionChange'); #optional since this is not applicable for some faults/conditions
    
    # check if used ProjectDefaults constants are defined and read them
    $SwitchStateChangeTime = 1000;
    $switchName =  DEVICE_fetchDeviceNamebyDeviceNumber ($defaultpar_Device); 
	# $switchName = $defaultpar_Device; 
    
    unless ( defined $switchName ) {
		$switchName = 'NONE';
	}
    
    #If no device is assigned then skip execution. Verdict will be 'NONE'
    return 1 if CheckValidDevice();
    
    $switchType = DEVICE_fetchSwitchType ($switchName);
    
    $Switch_positionA =  DEVICE_fetchSwitchState($switchName,'positionA');   
    $Switch_positionB =  DEVICE_fetchSwitchState($switchName,'positionB');
    
    #to print the purpose wrt device being tested
    $PURPOSE = "Switch Monitoring and evaluation for $switchName - $switchType switch";
    
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {
    
    #before proceeding check if a valid device is configured for this switch input/AIN
    return 1 if CheckValidDevice();
      
    S_w2rep('StandardPrepNoFault', 'blue'); 
    GEN_StandardPrepNoFault();
	

	if($defaultpar_ConfigurationBitStatus eq "clear")
	{
		DEVICE_setDeviceConfiguration ($switchName, $defaultpar_ConfigurationBitStatus);
	}
	S_w2rep("testing:Configuring bit cleared");
	S_wait_ms(2000);
		if($defaultpar_MonitoringBitStatus eq "clear_Mon")
	{
	    #DEVICE_setDeviceConfiguration ($switchName, $defaultpar_ConfigurationBitStatus);
		DEVICE_setDeviceConfiguration ($switchName, $defaultpar_MonitoringBitStatus);
		
	}
	S_wait_ms(2000);
	S_w2rep("testing:monitering bit clered");
	PD_ClearFaultMemory();
	S_wait_ms(2000);
	PD_ReadFaultMemory();
# S_user_action('PSdiag');
	 if($defaultpar_supply eq 'VBat'){
    	S_w2rep('Set supply voltage to $defaultpar_voltage', 'blue');
        POW_voltage($defaultpar_voltage); 
    }
	my $ab_Gen=PD_GetABGeneration();	
	if($defaultpar_mode ne 'normal'){
		#ACEA_SetECUMode("Idle");
		my $IdleMode_var = 'rb_bswm_IdleModeData_dfst.PermIdleMode_u16';
		PD_WriteMemoryByName($IdleMode_var, ['0x5A','0x5A'] );
		PD_ECUreset();
		PD_ECUlogin();
		S_wait_ms( 'TIMER_ECU_READY' );
		my $idlemode_Value=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
		if($idlemode_Value ne '0x0004')
		{
			S_w2rep("ECU is not set to Idle", 'red');
			return 0;
		}
	}
    
  	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
    
    #before proceeding check if a valid device is configured
    return 1 if CheckValidDevice();
	S_w2rep("Set switch to MonitoringBitStatus and ConfigurationBitStatus", 'blue');
	
      
    
    my $teststep = 1; #stimulation_and_measurement starts with step1
    foreach my $condition (@Testcondition){
    	#If this option is 'no', dont do anything
        if($condition eq 'FaultQualifiedandPositionChange' and $defaultpar_USE_FAULTQUALIFIEDandPOSITIONCHANGE ne 'yes'){;}  #dont do anything!  
        else{
            S_w2rep("$condition", 'orange');
            S_w2rep("Step$teststep", 'blue');$teststep++;
			
            DEVICE_setSwitchTestCondition($switchName, $defaultpar_switchFault, $condition);
            S_wait_ms( '2000', 'wait after state change' );
			
            S_w2rep("Step$teststep: Read the fault recorder", 'blue');$teststep++;
            $flt_mem_struct{$condition} = FM_PD_readFaultMemory (); 
			S_wait_ms(5000);
    
            S_w2rep("Step$teststep: Read switch state, status and Extended status", 'blue');$teststep++;
            Readswitchstate ($switchName, $condition);
            Readswitchstatus ($switchName, $condition);  
            ReadswitchExtendedstatus ($switchName, $condition); 
        }
    }
  	return 1;
}


#### EVALUATE TC #####
sub TC_evaluation {
    
    #before proceeding check if a valid device is configured
    return 1 if CheckValidDevice();
    
    my $teststep = 2; #evaluation starts with step2
    foreach my $condition (@Testcondition){
        if($condition eq 'FaultQualifiedandPositionChange' and $defaultpar_USE_FAULTQUALIFIEDandPOSITIONCHANGE ne 'yes'){
		}  #dont do anything!
        else{
            S_w2rep("$condition", 'orange');
            S_w2rep("Step$teststep: evaluate expected faults of step $teststep", 'blue'); $teststep++;
            FM_checkDeviceFaults ($flt_mem_struct{$condition},$switchName, $defaultpar_FLT_mand{$condition});       
    
            S_w2rep("Step$teststep: evaluate State, status and Extended status of step $teststep", 'blue'); $teststep++;
            Evaluateswitchstate ($switchName, $condition); 
            Evaluateswitchstatus ($switchName, $condition); 
            EvaluateswitchExtendedstatus ($switchName, $condition); 
                                
            $teststep++;
        }
    }
	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
    
    #before proceeding check if a valid device is configured
    return 1 if CheckValidDevice();
	
	#bring back ECU to normal mode
	if($defaultpar_mode ne 'normal'){
		my $IdleMode_var = 'rb_bswm_IdleModeData_dfst.PermIdleMode_u16';
		PD_WriteMemoryByName($IdleMode_var, ['0xFF','0xFF'] );
		PD_ECUreset();
		S_wait_ms( 'TIMER_ECU_READY' );
		}	
    PD_ECUlogin();
    S_wait_ms(2000);
	if($defaultpar_ConfigurationBitStatus eq "clear")
	{	
		DEVICE_setDeviceConfiguration ($switchName, "set");
	}
	S_wait_ms(5000);
	if($defaultpar_MonitoringBitStatus eq "clear_Mon")
	{
		DEVICE_setDeviceConfiguration ($switchName, "set_Mon");
	}
	S_wait_ms(3000);

	DEVICE_setDeviceState( $switchName, $Switch_positionA );
    GEN_Finalization  ();
    
	return 1;
}

###################local subs#################

sub CheckValidDevice{

	if ($switchName eq 'NONE') {  
	    S_w2rep("Valid switch is not configured for this AIN Stop further execution\n",'orange');
	    $PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $defaultpar_Device";
	    return 1;
    }
    elsif($switchType eq 'simple'){
    	if($defaultpar_switchFault=~ m/OpenLine/ or $defaultpar_switchFault=~ m/Undefined/ or $defaultpar_switchFault=~ m/Short2GND]/){ #these faults are not possible for simple/mechanical switch
    		S_w2rep("$defaultpar_switchFault fault is not possible for simple switch - $switchName. Stop further execution\n",'orange');
	    	$PURPOSE = "TESTCASE NOT EXECUTED: $defaultpar_switchFault fault is not possible for simple switch - $switchName";
	    	return 1;
    	}
    }
}

sub Readswitchstate{
    my $device = shift;
    my $condition = shift;
    
    $SwitchState_val{$device}{$condition}{'PD'} =  DEVICE_readSwitchState_PD($device);
#	 !!sample!!  
#    $SwitchState_val{$device}{$condition}{'CD'} =  DEVICE_readSwitchState_CD($device);
#    $SwitchState_val{$device}{$condition}{'CAN'} =  DEVICE_readSwitchState_CAN($device);
#    $SwitchState_val{$device}{$condition}{'FR'} =  DEVICE_readSwitchState_FR($device);     
}

sub Readswitchstatus{
    my $device = shift;
    my $condition = shift;
    
    $SwitchStatus_val{$device}{$condition}{'PD'} =  DEVICE_readSwitchStatus_PD($device);
#    $SwitchStatus_val{$device}{$condition}{'CD'} =  DEVICE_readSwitchStatus_CD($device);
#    $SwitchStatus_val{$device}{$condition}{'CAN'} =  DEVICE_readSwitchStatus_CAN($device);
#    $SwitchStatus_val{$device}{$condition}{'FR'} =  DEVICE_readSwitchStatus_FR($device);     
}

sub ReadswitchExtendedstatus{
    my $device = shift;
    my $condition = shift;
    
    $SwitchExtendedStatus_val{$device}{$condition}{'PD'} =  DEVICE_readSwitchExtendedStatus_PD($device);
#    $SwitchExtendedStatus_val{$device}{$condition}{'CD'} =  DEVICE_readSwitchExtendedStatus_CD($device);
#    $SwitchExtendedStatus_val{$device}{$condition}{'CAN'} =  DEVICE_readSwitchExtendedStatus_CAN($device);
#    $SwitchExtendedStatus_val{$device}{$condition}{'FR'} =  DEVICE_readSwitchExtendedStatus_FR($device);     
}


sub Evaluateswitchstate{
    my $device = shift;
    my $condition = shift;
	my $deviceProperties = DEVICE_fetchDeviceInfo($device);
	# my $var = $defaultpar_Read_val{'state'}{$condition};
    my $expectedstate_PD = $deviceProperties->{$defaultpar_Read_val{'state'}{$condition}};
    # my $expectedstate_PD = DEVICE_fetchExpectedSwitchState_PD ($defaultpar_Read_val{'state'}{$condition});
    my $observedstate_PD = $SwitchState_val{$device}{$condition}{'PD'};
    S_w2rep("Switch_State:\n Expected:$expectedstate_PD\n Observed:$observedstate_PD");
    EVAL_evaluate_value ( "SW State", $expectedstate_PD, '==', $observedstate_PD  );

#	!!sample!!    
#    my $expectedstate_CD = DEVICE_fetchExpectedSwitchState_CD ($defaultpar_Read_val{'state'}{$condition});
#    my $observedstate_CD = $SwitchState_val{$device}{$condition}{'CD'};
#    S_w2rep("Switch_State:\n Expected:$expectedstate_CD\n Observed:$observedstate_CD");
#    EVAL_evaluate_value ( "SW State", $expectedstate_CD, '==', $observedstate_CD  );
  
}

sub Evaluateswitchstatus{
    my $device = shift;
    my $condition = shift;
    
    my $expectedstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($defaultpar_Read_val{'status'}{$condition});
    my $observedstatus_PD = $SwitchStatus_val{$device}{$condition}{'PD'};
    S_w2rep("Switch_Status:\n Expected:$expectedstatus_PD\n Observed:$observedstatus_PD");
    EVAL_evaluate_value ( "SW Status", $expectedstatus_PD, '==', $observedstatus_PD  );

}

sub EvaluateswitchExtendedstatus{
    my $device = shift;
    my $condition = shift;
    
    my $expectedstatus_PD = DEVICE_fetchExpectedSwitchState_PD ($defaultpar_Read_val{'Extstatus'}{$condition});
    my $observedstatus_PD = $SwitchExtendedStatus_val{$device}{$condition}{'PD'};
    S_w2rep("Switch Extended Status:\n Expected:$expectedstatus_PD\n Observed:$observedstatus_PD");
    EVAL_evaluate_value ( "SW Extended Status", $expectedstatus_PD, '==', $observedstatus_PD  );

}


1;


__END__