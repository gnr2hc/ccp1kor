#### TEST CASE MODULE
package TC_PLANT_plantmode_9;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: SWM/TC_PLANT_plantmode_9.pm 1.2 2019/07/11 16:13:45ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) ready_for_review  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_can_access;
use FuncLib_TNT_SYC_INTERFACE;
use LIFT_ProdDiag;
##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PLANT_plantmode_9

=head1 PURPOSE

To test the fault qualification of switch faults in plant mode9

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter into Plant mode 9 by updating <variable> to <value> and reset the ECU.

2. Read the Fault Recorder

3. Set the <switch> <configuration>  in plant mode 9 ,clear the fault memory and read the Fault Recorder.

4. Exit the Plantmode9 and set the switch configuration to default,clear the fault memory and read the Fault Recorder.


I<B<Evaluation>>

2.Switch faults will get qualified as per the requirement  specified.

3. No switch related  <fault> are qualified


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'variable' => 
	SCALAR 'value' => 
	SCALAR 'switch' => 
	SCALAR 'configuration' => 
	SCALAR 'fault' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the fault qualification of switch faults in plant mode9'
	
	variable= 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)'
	value= '01'
	switch = '<Test Heading 1>'
	configuration = '<Test Heading 2>'
	fault = 'None'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_variable;
my $tcpar_value;
my $tcpar_switch;
my $tcpar_configuration;
my $tcpar_fault;

################ global parameter declaration ###################
#add any global variables here
my $Fault_Recorder;
my $Fault_Recorder1;
my $switchtype;
my $fault = 'ShortLine';
my ($result, $state_value, $state_unit);
my $value;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose', 'byvalue' );
	$tcpar_variable =  S_read_mandatory_testcase_parameter( 'variable', 'byvalue'  );
	$tcpar_value =  S_read_mandatory_testcase_parameter( 'value', 'byvalue'  );
	$tcpar_switch =  S_read_mandatory_testcase_parameter( 'switch', 'byvalue'  );
	$tcpar_configuration =  S_read_mandatory_testcase_parameter( 'configuration', 'byvalue'  );
	$tcpar_fault =  S_read_mandatory_testcase_parameter( 'fault', 'byvalue'  );
	
	if($tcpar_switch =~ m/SW/i){
		S_set_error("$tcpar_switch is not a valid Device");
		S_set_verdict('VERDICT_FAIL');
		return 1;
	}else{
		S_w2rep("$tcpar_switch is a valid Device");
	}
	
	$switchtype = DEVICE_fetchSwitchType ($tcpar_switch);
	
	if($switchtype =~ m/mech/i){
		S_set_error("Script is not automated for mechanical switches");
		S_set_verdict('VERDICT_FAIL');
		return 1;
	}else{
		S_w2rep("Script is not automated for $switchtype switches");
	}
	
	
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Enter into Plant mode 9 by updating '$tcpar_variable' to '$tcpar_value' and reset the ECU.", 'AUTO_NBR');
		PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [$tcpar_value] );
		S_wait_ms('TIMER_SIX_SEC');
		LC_ECU_Reset();
		
	S_teststep("Read the Fault Recorder", 'AUTO_NBR');			#measurement 1
		$Fault_Recorder = PD_ReadFaultMemory();
	
	S_teststep("Set the '$tcpar_switch' '$tcpar_configuration'  in plant mode 9 ,clear the fault memory and read the Fault Recorder.", 'AUTO_NBR');			#measurement 2
		$tcpar_configuration =~ /(\d+)(\w+)/;
		$value = $1;
		
		if($2 =~ m/Ohm/i){
			LC_SetResistance( $tcpar_switch, $value);
		}elsif($2 =~ m/mA/i){
			LC_SetCurrent( $tcpar_switch, $value);
		}
		S_wait_ms('TIMER_TWO_SEC');
		
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_SIX_SEC');
		
		$Fault_Recorder1 = PD_ReadFaultMemory();
		S_wait_ms('TIMER_SIX_SEC');
	
	S_teststep("Exit the Plantmode9 and set the switch configuration to default,clear the fault memory and read the Fault Recorder.", 'AUTO_NBR');
		PRD_Write_Memory( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [00] );
		S_wait_ms('TIMER_SIX_SEC');
		LC_ECU_Reset();
		
		if($tcpar_switch =~ m/SPS/i){
			$fault = 'OpenLine';
			($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $tcpar_switch, 'PositionB' );
		}else{
			($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $tcpar_switch, 'PositionA' );
		}
		S_w2rep("SYC ret values : $result, $state_value, $state_unit","Green");
		if($state_unit =~ /I/){
			LC_SetCurrent($tcpar_switch, $state_value);
		}elsif($state_unit =~ /R/){
			LC_SetResistance($tcpar_switch, $state_value);
		}
		
		S_wait_ms('TIMER_TWO_SEC');
				
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Switch faults will get qualified as per the requirement specified.");			#evaluation 1
		if(PD_check_fault_status($Fault_Recorder,'rb_swm_'.$fault.$tcpar_switch.'_flt','0bxxxxxxx1')){
			S_teststep_detected("Detected 'rb_swm_'.$fault.$tcpar_switch.'_flt' fault is Qualified for $tcpar_switch");
		}else{
			S_teststep_detected("Detected 'rb_swm_'.$fault.$tcpar_switch.'_flt' fault is De-Qualified for $tcpar_switch");
		}
	
	S_w2rep("###############################################################################################################################",'purple');	
	
	S_teststep_expected("No switch related '$tcpar_fault' are qualified");			#evaluation 2
		if(PD_check_fault_status($Fault_Recorder1,'rb_swm_'.$fault.$tcpar_switch.'_flt','0bxxxxxxx0')){
			S_teststep_detected("Detected 'rb_swm_'.$fault.$tcpar_switch.'_flt' fault is De-Qualified for $tcpar_switch");
		}else{
			S_teststep_detected("Detected 'rb_swm_'.$fault.$tcpar_switch.'_flt' fault is Qualified for $tcpar_switch");
		}
	
	
	return 1;
}

sub TC_finalization {
	PD_ClearFaultMemory();
	return 1;
}


1;
