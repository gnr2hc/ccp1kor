#### TEST CASE MODULE
package TC_SWM_FaultHandling;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER = q$Header: SWM/TC_SWM_FaultHandling.pm 1.4 2020/05/22 19:18:18ICT Purushotham Reddy Chinnasani (RBEI/ESA-PP2) (UCP5KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: 3.112 (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_labcar;
use LIFT_PD;
use LIFT_TSG4;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_ProdDiag;
require LIFT_PD2ProdDiag;import LIFT_PD2ProdDiag;
use FuncLib_TNT_SYC_INTERFACE;
##################################

our $PURPOSE = "To test the qualification of logical/physical switch fault";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_FaultHandling

=head1 PURPOSE

To test the qualification of logical/physical switch fault

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set the state of <Device> to positionA.

2.Create any <phy_faults> and any  <log_faults> on the switch at the same time.

3. Read the fault recorder, switch state and status.

4. Change the switch state to position B

5. Read the fault recorder, switch state and status.

6. Remove the faults and reset the ECU.   

7. Read the fault recorder, switch state and status

#Note:phy_fault= physical faults on the switch like S2G,S2B,Undefined,Crosscoupling,Undefined.

#log_fault=logical faults on the switch likeConfiguration(unexpected device)fault.#Consider all 3 types of switches SW1=hall, SW2=resistive,SW3=simple


I<B<Evaluation>>

3. <Faults> will be qualified in the fault recorder.

State will be <state_val_fault> and status  <status_val_fault>

5. <Faults> will be qualified, 

State will remain latched i.e. <state_val_fault> and status is <status_val_fault>

7.<Faults> will be de-qualified in the fault recorder.

State will be  <state_val_nofault> and status to <status_val_nofault>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Device' => 
	SCALAR 'state_val_fault' => 
	SCALAR 'state_val_nofault' => 
	SCALAR 'status_val_fault' => 
	SCALAR 'status_val_nofault' => 
	SCALAR 'phy_faults' => 
	SCALAR 'log_faults' => 
	HASH 'Faults' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the qualification of logical/physical switch fault '
	
	Device = '<Test Heading>'
	
	state_val_fault='STATE_POSITIONA'
	state_val_nofault='STATE_POSITIONB'
	status_val_fault='STATUS_FAULT'
	status_val_nofault='STATUS_VALID'
	
	phy_faults ='ShortLine'
	log_faults ='Configuration'
	Faults=%('ShortLine' => '0bxxxxx111','Configuration' => '0bxxxxx111')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_state_val_fault;
my $tcpar_state_val_nofault;
my $tcpar_status_val_fault;
my $tcpar_status_val_nofault;
my $tcpar_phy_faults;
my $tcpar_log_faults;
my $tcpar_Faults;

################ global parameter declaration ###################
#add any global variables here
S_w2rep("Switch Name: $tcpar_Device");
my ($fault_recorder,$fault_recorder1,$fault_recorder2); 
my ($sw_position,$sw_position1,$sw_position2); 
my ($sw_status,$sw_status1,$sw_status2); 

my (	
		$sw_position_dev1,	
		$sw_status_dev1,		
		$sw_position_dev2,	
		$sw_status_dev2		
	);

my (	
		$sw_position1_dev1, 	
		$sw_status1_dev1, 	
		$sw_position1_dev2, 	
		$sw_status1_dev2 	
	);
	
my (	
		$sw_position2_dev1,		
		$sw_status2_dev1,	
		$sw_position2_dev2,
		$sw_status2_dev2
	
	);  	
	
my $flt;
my @FaultName;
my @FaultName1;
my @FaultNames_for_two_devices;
my @FaultNames_for_two_devices_1;
my $switch_device;

#checking only last bit value 
my $flt_quali ='0bxxxxxxx1';
my $flt_dequali ='0bxxxxxxx0';

my @Devices;
my @switches;
my $No_of_switch;
my $no_of_phy_flt;
my $valid_switch_flag = 0;
###############################################################

sub TC_set_parameters {
	
	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose', 'byvalue' );
	$tcpar_Device =  S_read_mandatory_testcase_parameter( 'Device','byvalue' );
	$tcpar_state_val_fault =  S_read_mandatory_testcase_parameter( 'state_val_fault','byvalue' );
	$tcpar_state_val_nofault =  S_read_mandatory_testcase_parameter( 'state_val_nofault', 'byvalue' );
	$tcpar_status_val_fault =  S_read_mandatory_testcase_parameter( 'status_val_fault','byvalue' );
	$tcpar_status_val_nofault =  S_read_mandatory_testcase_parameter( 'status_val_nofault', 'byvalue' );
	$tcpar_phy_faults =  S_read_mandatory_testcase_parameter( 'phy_faults','byref');
	$tcpar_log_faults =  S_read_mandatory_testcase_parameter( 'log_faults', 'byvalue' );
	$tcpar_Faults =  S_read_mandatory_testcase_parameter( 'Faults', 'byref' );		
	# $tcpar_Device=DEVICE_fetchDeviceNamebyDeviceNumber ($switch_device); 
	my @switches = split(/_/,$tcpar_Device);
	foreach (@switches)
	{
	 
	my $temp =DEVICE_fetchDeviceNamebyDeviceNumber($_);
	push @Devices,$temp;
	
	
	}

	$No_of_switch = @Devices;
	foreach (@Devices){
		if($_ =~ m/PADS2/i){
			S_w2rep("No Fault can be created for the PADS2 switch");
			$valid_switch_flag = 1;
			return 1;
		}
	}
	$no_of_phy_flt = scalar @$tcpar_phy_faults;
	if((@$tcpar_phy_faults[0] =~ /Short2Bat|ShortLine/i) and (@$tcpar_phy_faults[1] =~ /CrossCoupling/i) ){				#short2bat and crosscoupling fault can not be created on a same switch at a time
		shift @$tcpar_phy_faults ;
		S_w2rep(" fault array =====> @$tcpar_phy_faults");
	}
	
	return 1;
}

sub TC_initialization {
	unless($valid_switch_flag == 0){
		S_w2rep("No Fault can be created for the PADS2 switch");
		return 1;
	}
	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	return 1;
}

sub TC_stimulation_and_measurement {
	
	unless($valid_switch_flag == 0){
		S_w2rep("No Fault can be created for the PADS2 switch");
		return 1;
	}
	
	S_teststep("Set the state of '$tcpar_Device' to positionA.", 'AUTO_NBR');
		if($No_of_switch == 2){
			my ($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $Devices[0], 'PositionA' );
			if($state_unit =~ /I/){
				LC_SetCurrent($Devices[0], $state_value);
			}elsif($state_unit =~ /R/){
				LC_SetResistance($Devices[0], $state_value);
			}
			
			my ($result1, $state_value1, $state_unit1) = SYC_SWITCH_get_state( $Devices[1], 'PositionA' );
			if($state_unit1 =~ /I/){
				LC_SetCurrent($Devices[1], $state_value1);
			}elsif($state_unit1 =~ /R/){
				LC_SetResistance($Devices[1], $state_value1);
			}
						
		}else{
			$tcpar_Device = $Devices[0]; # If there is only one device assigning the Device to tcpar_Device
			my ($result, $state_value, $state_unit) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionA' );
			if($state_unit =~ /I/){
				LC_SetCurrent($tcpar_Device, $state_value);
			}elsif($state_unit =~ /R/){
				LC_SetResistance($tcpar_Device, $state_value);
			}
		}
		S_wait_ms( 'SWITCH_STATE_CHANGE_TIME', 'wait after state change' );

	if($tcpar_log_faults =~ m/None/i){
		S_teststep("Create '@$tcpar_phy_faults' on the switch.", 'AUTO_NBR');
	}else{
		S_teststep("Create '@$tcpar_phy_faults' and '$tcpar_log_faults' on the switch at the same time.", 'AUTO_NBR');
	}	
		foreach $flt (@$tcpar_phy_faults){
			chomp($flt);
			if($No_of_switch == 2){
				if($flt =~ /CrossCoupling/i){
					push @FaultNames_for_two_devices, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;
					push @FaultNames_for_two_devices, "rb_swm_".$flt."$Devices[1]"."_"."flt" ;
					S_w2rep("Creating $flt fault : @FaultNames_for_two_devices","Purple");
					LC_ShortLines( [$Devices[0] . '+', $Devices[1] . '+' ]);
					PD_ECUreset();
					
				}else{
					# Only one short at same time is possible(cannot create short2bat fault for two switches)
					if($flt =~ m/Short2Bat|ShortLine/i){	
						push @FaultNames_for_two_devices, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;
						S_w2rep("Creating $flt fault : @FaultNames_for_two_devices","Purple");
						FM_createFault("rb_swm_".$flt."$Devices[0]"."_"."flt");
					}else{	
						push @FaultNames_for_two_devices, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;					
						push @FaultNames_for_two_devices, "rb_swm_".$flt."$Devices[1]"."_"."flt" ;					
						S_w2rep("Creating $flt fault : @FaultNames_for_two_devices","Purple");                     				
						FM_createFault("rb_swm_".$flt."$Devices[0]"."_"."flt");     					
						FM_createFault("rb_swm_".$flt."$Devices[1]"."_"."flt");     					
					}
				}
				S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
			}
			else{
				push @FaultName, "rb_swm_".$flt."$tcpar_Device"."_"."flt" ;
				S_w2rep("Creating $flt fault : @FaultName","Purple");
				FM_createFault("rb_swm_".$flt."$tcpar_Device"."_"."flt"); 
				S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
			}
		}
		
		if($tcpar_log_faults =~ /Configuration/i){
			push @FaultName, "rb_swm_Unexpected"."$tcpar_Device"."_"."flt" ;
			S_w2rep("Creating $tcpar_log_faults log fault : @FaultName","Purple");
			FM_createFault("rb_swm_Unexpected"."$tcpar_Device"."_"."flt");
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');
		}else{
			S_w2rep("Log fault is not present for this current Test Case","Purple");
		}
		
	S_teststep("Read the fault recorder, switch state and status after creating faults.", 'AUTO_NBR');			#measurement 1		###
		$fault_recorder = PD_ReadFaultMemory();
		S_wait_ms('TIMER_SIX_SEC'); 
		
		if($No_of_switch == 2){
			$sw_position_dev1	= DEVICE_readSwitchState_PD($Devices[0]);
			$sw_status_dev1		= DEVICE_readSwitchStatus_PD($Devices[0]);
			
			$sw_position_dev2	= DEVICE_readSwitchState_PD($Devices[1]);
			$sw_status_dev2		= DEVICE_readSwitchStatus_PD($Devices[1]);
		}else{
			$sw_position 	= DEVICE_readSwitchState_PD($tcpar_Device);
			$sw_status		= DEVICE_readSwitchStatus_PD($tcpar_Device);
		}
		
	S_teststep("Change the $tcpar_Device switch state to position B", 'AUTO_NBR');
		if($No_of_switch == 2){
			my ($result2, $state_value2, $state_unit2) = SYC_SWITCH_get_state( $Devices[0], 'PositionB' );
			if($state_unit2 =~ /I/){
				LC_SetCurrent($Devices[0], $state_value2);
			}elsif($state_unit2 =~ /R/){
				LC_SetResistance($Devices[0], $state_value2);
			}
			
			my ($result3, $state_value3, $state_unit3) = SYC_SWITCH_get_state( $Devices[1], 'PositionB' );
			if($state_unit3 =~ /I/){
				LC_SetCurrent($Devices[1], $state_value3);
			}elsif($state_unit3 =~ /R/){
				LC_SetResistance($Devices[1], $state_value3);
			}
		}else{
			my ($result1, $state_value1, $state_unit1) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionB' );
			if($state_unit1 =~ /I/){
				LC_SetCurrent($tcpar_Device, $state_value1);
			}elsif($state_unit1 =~ /R/){
				LC_SetResistance($tcpar_Device, $state_value1);
			}
		}
		S_wait_ms( 'SWITCH_STATE_CHANGE_TIME', 'wait after state change' );
		
		if((@$tcpar_phy_faults[0] =~ m/Undefined|ShortLine/i) and ($No_of_switch != 2)){							
			## Change the switch position to position A for Undefined/ShortLine fault, because state of the switch is getting changed after setting the band for Undefined/Shortline
			my ($result_undef_shortline, $state_value_undef_shortline, $state_unit_undef_shortline) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionA' );
			if($state_unit_undef_shortline =~ /I/){
				LC_SetCurrent($tcpar_Device, $state_value_undef_shortline);
			}elsif($state_unit_undef_shortline =~ /R/){
				LC_SetResistance($tcpar_Device, $state_value_undef_shortline);
			}
			S_wait_ms( 'SWITCH_STATE_CHANGE_TIME', 'wait after state change' );
		}else{
			S_w2rep("Log fault is not present for this current Test Case","Purple");
		}
		
	S_teststep("Read the fault recorder, switch state and status after changing $tcpar_Device to position B .", 'AUTO_NBR');			#measurement 2
		$fault_recorder1 = PD_ReadFaultMemory();
		S_wait_ms('TIMER_SIX_SEC');
		
		if($No_of_switch == 2){
			$sw_position1_dev1 	 = DEVICE_readSwitchState_PD($Devices[0]);
			$sw_status1_dev1 	 = DEVICE_readSwitchStatus_PD($Devices[0]);
			
			$sw_position1_dev2 	 = DEVICE_readSwitchState_PD($Devices[1]);
			$sw_status1_dev2 	 = DEVICE_readSwitchStatus_PD($Devices[1]);
		}else{
			$sw_position1 	 = DEVICE_readSwitchState_PD($tcpar_Device);
			$sw_status1 	 = DEVICE_readSwitchStatus_PD($tcpar_Device);
		}
		
	S_teststep("Remove the faults and reset the ECU.", 'AUTO_NBR');
		foreach $flt (@$tcpar_phy_faults){
			if($No_of_switch == 2){
				if($flt =~ /CrossCoupling/i){
					push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;
					push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[1]"."_"."flt" ;
					S_w2rep("Removing $flt fault : @FaultNames_for_two_devices_1","Purple");
					LC_UndoShortLines();
					S_wait_ms('TIMER_SIX_SEC');
					LC_ECU_Reset();
					
				}else{
					if($flt =~ m/Short2Bat|ShortLine/i ){									#only one short2bat/ShortLine can be created (Removing the short2bat/ShortLine fault which is created above ) 
						push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;
						S_w2rep("Removing $flt fault : @FaultNames_for_two_devices_1","Purple");
						FM_removeFault("rb_swm_".$flt."$Devices[0]"."_"."flt");	
					}elsif($flt =~ m/Undefined/i){																		# FM_createFault API seting a switch state to position A to create undefine fault,	
						push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;					
						push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[1]"."_"."flt" ;					
						S_w2rep("Removing $flt fault : @FaultNames_for_two_devices_1","Purple");    
						my ($res , $state_val, $unit) = SYC_SWITCH_get_state( $Devices[0], 'PositionB' );			 	#Therefore setting switch state to position B to remove the undefine fault
						if($unit =~ /I/){
							LC_SetCurrent( $Devices[0], $state_val);
						}elsif($unit =~ /R/){
							LC_SetResistance( $Devices[0], $state_val);
						}
						S_wait_ms( 'SWITCH_STATE_CHANGE_TIME');
						
						my ($res1 , $state_val1, $unit1) = SYC_SWITCH_get_state( $Devices[1], 'PositionB' );			 
						if($unit1 =~ /I/){
							LC_SetCurrent( $Devices[1], $state_val1);
						}elsif($unit1 =~ /R/){
							LC_SetResistance( $Devices[1], $state_val1);
						}
						S_wait_ms( 'SWITCH_STATE_CHANGE_TIME');
						
					}else{
						push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[0]"."_"."flt" ;					
						push @FaultNames_for_two_devices_1, "rb_swm_".$flt."$Devices[1]"."_"."flt" ;					
						S_w2rep("Removing $flt fault : @FaultNames_for_two_devices_1","Purple");             			
						FM_removeFault("rb_swm_".$flt."$Devices[0]"."_"."flt");      					
						FM_removeFault("rb_swm_".$flt."$Devices[1]"."_"."flt");      					
					}
					S_wait_ms('TIMER_SIX_SEC');                                             			
				}
				
			}
			else{
				push @FaultName1 ,"rb_swm_".$flt."$tcpar_Device"."_"."flt";
				S_w2rep("Removing $flt fault : @FaultName1","Purple");
				if($flt =~ /Undefined|ShortLine/i){																								#undefinedandShort2Bat # FM_createFault API seting a switch state to position A to create undefine fault,
					my ($result_undef1, $state_value_undef1, $state_unit_undef1) = SYC_SWITCH_get_state( $tcpar_Device, 'PositionB' );			#Therefore setting switch state to position B to remove the undefine fault 
					if($state_unit_undef1 =~ /I/){
					 LC_SetCurrent( $tcpar_Device, $state_value_undef1);
					}elsif($state_unit_undef1 =~ /R/){
					 LC_SetResistance( $tcpar_Device, $state_value_undef1);
					}
				}else{
					FM_removeFault("rb_swm_".$flt."$tcpar_Device"."_"."flt");
				}
				S_wait_ms('TIMER_SIX_SEC');
			}
		
		}
		if($tcpar_log_faults =~ /Configuration/i){
			push @FaultName1 ,"rb_swm_Unexpected"."$tcpar_Device"."_"."flt";
			S_w2rep("Removing $tcpar_log_faults Log fault : @FaultName1","Purple");    
			FM_removeFault("rb_swm_Unexpected"."$tcpar_Device"."_"."flt");
			S_wait_ms('TIMER_SIX_SEC');
		}
		LC_ECU_Reset();
		
	S_teststep("Read the fault recorder, switch state and status after removing the faults and reseting the ECU", 'AUTO_NBR');			#measurement 3
		$fault_recorder2 = PD_ReadFaultMemory();
		S_wait_ms('TIMER_SIX_SEC');
		
		if($No_of_switch == 2){
			$sw_position2_dev1	 = DEVICE_readSwitchState_PD($Devices[0]);
			$sw_status2_dev1	 = DEVICE_readSwitchStatus_PD($Devices[0]);
			
			$sw_position2_dev2	 = DEVICE_readSwitchState_PD($Devices[1]);
			$sw_status2_dev2	 = DEVICE_readSwitchStatus_PD($Devices[1]);
		}else{
			$sw_position2	 = DEVICE_readSwitchState_PD($tcpar_Device);
			$sw_status2		 = DEVICE_readSwitchStatus_PD($tcpar_Device);
		}
	

	return 1;
}

sub TC_evaluation {

	unless($valid_switch_flag == 0){
		S_w2rep("No Fault can be created for the PADS2 switch");
		return 1;
	}
	
	my $key;
	my $verdict;
	my ($size,$size1);
	
	my $status_fault    = DEVICE_fetchExpectedSwitchState_PD($tcpar_status_val_fault);								
	my $status_valid    = DEVICE_fetchExpectedSwitchState_PD($tcpar_status_val_nofault);                			
	my $state_positionA = DEVICE_fetchExpectedSwitchState_PD($tcpar_state_val_fault);                   			
	my $state_positionB = DEVICE_fetchExpectedSwitchState_PD($tcpar_state_val_nofault);                 			
	
		S_w2rep("###############################################################################################################");	
		S_w2rep("########################################  After Creating the faults   #########################################");	
		S_w2rep("###############################################################################################################");		
		if($No_of_switch == 2){
			S_teststep_expected("'@FaultNames_for_two_devices' will be qualified in the fault recorder after creating faults.");			#evaluation 1
			
			$size = @FaultNames_for_two_devices;																						
			$verdict = evaluate_faults($size,$fault_recorder,$flt_quali,\@FaultNames_for_two_devices);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected qualified faults are @FaultNames_for_two_devices");
			}else{
				S_teststep_detected("@FaultNames_for_two_devices faults are not qualified");
			}
		}else{
			S_teststep_expected("'@FaultName' will be qualified in the fault recorder after creating faults.");			#evaluation 1
			
			$size = @FaultName;	
			$verdict = evaluate_faults($size,$fault_recorder,$flt_quali,\@FaultName);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected qualified faults are @FaultName");
			}else{
				S_teststep_detected("@FaultName faults are not qualified");
			}
		}
		
		S_w2rep("###############################################################################################################");	
		
	S_teststep_expected("State will be '$tcpar_state_val_fault' and status  '$tcpar_status_val_fault' after creating faults");
	
		if($No_of_switch == 2){
			S_teststep_detected("Detected states for $Devices[0] switch = '$sw_position_dev1' and for $Devices[1] switch ='$sw_position_dev2' and
								Detected status for $Devices[0] switch = '$sw_status_dev1' and $Devices[1] switch = '$sw_status_dev2' resp.");
			
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position_dev1, '==', $state_positionA );   	
			                                                                                                                                   		
			EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status_dev1, '==', $status_fault );      
			                                                                                                                                   	
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position_dev2, '==', $state_positionA );   		
			
			EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status_dev2, '==', $status_fault );
			
		}else{
			S_teststep_detected("Detected state and status are for $tcpar_Device switch is $sw_position and $sw_status resp.");
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position, '==', $state_positionA );
			
			EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status, '==', $status_fault );
		}	

		S_w2rep("###############################################################################################################");	
		S_w2rep("#######################  After Changing $tcpar_Device to position B   #########################################");	
		S_w2rep("###############################################################################################################");	
		if($No_of_switch == 2){
			S_teststep_expected("'@FaultNames_for_two_devices' will be qualified after changing the $tcpar_Device to position B");			#evaluation 2
			
			$verdict = evaluate_faults($size,$fault_recorder1,$flt_quali,\@FaultNames_for_two_devices);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected qualified faults are @FaultNames_for_two_devices");
			}else{
				S_teststep_detected("@FaultNames_for_two_devices faults are not qualified");
			}
		}else{
			S_teststep_expected("'@FaultName' will be qualified after changing the $tcpar_Device to position B ");			#evaluation 2
			
			$verdict = evaluate_faults($size,$fault_recorder1,$flt_quali,\@FaultName);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected qualified faults are @FaultName");
			}else{
				S_teststep_detected("@FaultName faults are not qualified");
			}	
		}
		
	S_teststep_expected("State will remain latched i.e. '$tcpar_state_val_fault' and status is '$tcpar_status_val_fault' after changin $tcpar_Device to position B");

		if($No_of_switch == 2){
			S_teststep_detected("Detected states for $Devices[0] switch = '$sw_position1_dev1' and for $Devices[1] switch ='$sw_position1_dev2' and
								Detected status for $Devices[0] switch = '$sw_status1_dev1' and $Devices[1] switch = '$sw_status1_dev2' resp.");
								
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position1_dev1, '==', $state_positionA );  	
			                                                                                                                                      
			EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status1_dev1, '==', $status_fault );    
			                                                                                                                                      
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position1_dev2, '==', $state_positionA ); 	
			
			EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status1_dev2, '==', $status_fault );
		
		}else{
			S_teststep_detected("Detected state and status are for $tcpar_Device switch is $sw_position1 and $sw_status1 resp.");
			
			EVAL_evaluate_value( "state will be '$tcpar_state_val_fault'", $sw_position1, '==', $state_positionA );
			if(((@$tcpar_phy_faults[0] =~ m/Undefined|ShortLine/i) and (($no_of_phy_flt == 1) or (@$tcpar_phy_faults[1] =~ m/ShortLine/i)))){													#undefined/shortline fault will get dequalified 
				EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status1, '==', $status_valid );
			}else{
				EVAL_evaluate_value( "status will be '$tcpar_status_val_fault'", $sw_status1, '==', $status_fault );
			}
		}
		
	
		S_w2rep("###############################################################################################################");	
		S_w2rep("########################################  After removing the faults   #########################################");	
		S_w2rep("###############################################################################################################");	
		if($No_of_switch == 2){
			S_teststep_expected("'@FaultNames_for_two_devices_1' will be de-qualified in the fault recorder after removing the faults.");			#evaluation 3
			
			$size1 = @FaultNames_for_two_devices_1;	
			$verdict = evaluate_faults($size1,$fault_recorder2,$flt_dequali,\@FaultNames_for_two_devices_1);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected dequalified faults are @FaultNames_for_two_devices");
			}else{
				S_teststep_detected("@FaultNames_for_two_devices faults are qualified");
			}
			
		}else{
			S_teststep_expected("'@FaultName1' will be de-qualified in the fault recorder after removing the faults.");			#evaluation 3
			
			$size1 = @FaultName1;	
			$verdict = evaluate_faults($size1,$fault_recorder2,$flt_dequali,\@FaultName1);
			if($verdict =~ m/PASS/i){
				S_teststep_detected("Detected dequalified faults are @FaultName1");
			}else{
				S_teststep_detected("@FaultName1 faults are qualified");
			}
		}
		
	S_teststep_expected("State will be '$tcpar_state_val_nofault' and status to '$tcpar_status_val_nofault' after removing the faults.");
	
		if($No_of_switch == 2){
			S_teststep_detected("Detected states for $Devices[0] switch = '$sw_position2_dev1' and for $Devices[1] switch = '$sw_position2_dev2' and 
								Detected status for $Devices[0] switch = '$sw_status2_dev1' and for $Devices[1] switch ='$sw_status2_dev2' resp.");
			
			EVAL_evaluate_value( "state will be '$tcpar_state_val_nofault'", $sw_position2_dev1, '==', $state_positionB );
			                                                                                                                                       
			EVAL_evaluate_value( "status will be '$tcpar_status_val_nofault'", $sw_status2_dev1, '==', $status_valid );        
			                                                                                                                                     	
			EVAL_evaluate_value( "state will be '$tcpar_state_val_nofault'", $sw_position2_dev2, '==', $state_positionB ); 	
			
			EVAL_evaluate_value( "status will be '$tcpar_status_val_nofault'", $sw_status2_dev2, '==', $status_valid );
			
		
		}else{
			S_teststep_detected("Detected state and status for $tcpar_Device are $sw_position2 and $sw_status2 resp.");
			
			EVAL_evaluate_value( "state will be '$tcpar_state_val_nofault'", $sw_position2, '==', $state_positionB );
			
			EVAL_evaluate_value( "status will be '$tcpar_status_val_nofault'", $sw_status2, '==', $status_valid );
		}
		
	return 1;
}

sub TC_finalization {
	unless($valid_switch_flag == 0){
		S_w2rep("No Fault can be created for the PADS2 switch");
		return 1;
	}
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_SIX_SEC');
	PD_ReadFaultMemory();
	LC_ECU_Reset();

	return 1;

}

##############local Sub ####################################################
# evaluate_faults($size,$Falut_recorder,$flt_state,$FaultName);
#		Size 			= count value for faults to evalute
#		Falut_recorder
#		flt_state		= quali/dequali (eg. '0bxxxxxxx1'/'0bxxxxxxx0')
#		FaultName 		= Array ref of fault list that need to be evaluate
#
############################################################################
sub evaluate_faults {

	my $size = shift;
	my $fault_recorder = shift;
	my $flt_state = shift;
	my $FaultName = shift;
	my $verdict;
	if($flt_state =~ m/0bxxxxxxx1/i){
		$verdict = PD_evaluate_faults($fault_recorder,[@$FaultName]);
	}else{
		$verdict = 'PASS';
	}
	if($size == 1){
	
		PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_state);
	
	}elsif($size == 2){
		if((@$FaultName[0] =~ m/OpenLine/i) or ((@$FaultName[0] =~ m/Undefined|ShortLine/i) and ($no_of_phy_flt != 1))){
			PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_dequali);
			
		}else{
			PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_state);
		}
		PD_check_fault_status($fault_recorder,@$FaultName[1],$flt_state);
		
	}elsif($size == 3){
		if(@$FaultName[0] =~ m/OpenLine|Undefined/i ){
			PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_dequali);
		}else{
			PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_state);
		}
		PD_check_fault_status($fault_recorder,@$FaultName[1],$flt_state);
		PD_check_fault_status($fault_recorder,@$FaultName[2],$flt_state);
		
	}elsif($size == 4){
		S_w2rep("Inside evaluate faults Function size $size");
		PD_check_fault_status($fault_recorder,@$FaultName[0],$flt_state);
		PD_check_fault_status($fault_recorder,@$FaultName[1],$flt_state);
		PD_check_fault_status($fault_recorder,@$FaultName[2],$flt_state);
		PD_check_fault_status($fault_recorder,@$FaultName[3],$flt_state);
	}
	
	return $verdict;

}

1;
