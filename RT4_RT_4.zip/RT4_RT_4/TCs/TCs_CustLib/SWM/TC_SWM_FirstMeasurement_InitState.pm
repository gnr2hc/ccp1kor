#### TEST CASE MODULE
package TC_SWM_FirstMeasurement_InitState;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: SWM/TC_SWM_FirstMeasurement_InitState.pm 1.1 2019/08/22 19:04:43ICT EXTERNAL J M Rangwardhan (Brigosha, RBEI/ESA-PW5) (JAW1KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SWM_SwitchMgt
#TS version in DOORS: 3.28
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check the switch state and status during init and time taken for the first measurement";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_FirstMeasurement_InitState

=head1 PURPOSE

to check the switch state and status during init and time taken for the first measurement

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Note: To read the switch states immediately after power ON, use 'Fast Diagnostics after start-up' feature.


I<B<Stimulation and Measurement>>

1. Set the switch to positionA state

2. Power_on_reset 

3. Immediately after power ON read the switch state, status and extended status

4. Switch Off the ECU and set the switch to positionB

5. Power ON and immdiately Read the switch state, status and extended status

6. Switch Off the ECU and create a fault on the switch

7. Power ON and immdiately Read the switch state, status and extended status

8. Switch Off the ECU and remove the configuration bit

9. Power ON and immdiately Read the switch state, status and extended status

10. Switch Off the ECU and remove the monitoring bit

11. Power ON and immdiately Read the switch state, status and extended status

Finalization:

Set the monitoring and configuration bits


I<B<Evaluation>>

3. Initially, Switch state is <State_val_init>

Status is Init

Extended Status is Init

State changes to positionA, Status changes to Valid, Extended Status changes to Valid within 2850 ms from power ON

5. Initially, Switch state is  <State_val_init>

Status is  Init

Extended Status is Init

State changes to positionB, Status changes to Valid, Extended Status changes to Valid within 2850 ms from power ON

7. 	Initially, Switch state is <State_val_init>

Status is Init

Extended Status is Init

State changes to <State_val_fault>, Status changes to Fault, Extended Status changes to Fault within 2850 ms from power ON

9. Initially, Switch state is <State_val_init>

Status is Init

Extended Status is NotConfInit

State changes to <State_val_fault>, Status changes to Fault, Extended Status changes to NotConfFault within 2850 ms from power ON

11. Initially, Switch state is <State_val_init>

Status is Init

Extended Status is NotMonitored

State changes to <State_val_init>, Status changes to Init,  within 2850 ms from power ON. (Extended Status remains as NotMonitored)

Note: If switch is an SDL switch, state change may not happen within 2850 ms.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'Device' => the switch device (SW1, SW2..)
	SCALAR 'State_val_init' => switch state/position value corresponding to init status
	SCALAR 'State_val_fault' => switch state/position value corresponding to fault status


=head2 PARAMETER EXAMPLES

	purpose	= 'To test the init state before first measurement'
	Device = 'SW1'
	State_val_init = 'STATE_POSITIONB'
	State_val_fault = 'STATE_POSITIONB'

=cut

#positionFiltered_en
#0 = PositionA, 1 = PositionB

#statusFiltered_en
#0 = Valid, 1= fault, 2 = init

#extStatusFiltered_en
#0 = Valid
#1 = Fault
#2 = NotPresent
#3 = Init
#4 = NotConfValid
#5 = NotConfFault
#6 = NotConfNotPresent
#7 = NotConfInit
#8 = NotMonitored

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_State_val_init;
my $tcpar_State_val_fault;

################ global parameter declaration ###################
#add any global variables here
my $switchName;
my $Switch_positionA;
my $Switch_positionB;
my $SW_state_var;
my $SW_status_var;
my $SW_extstatus_var;
my $FDdata_3;
my $FDdata_4;
my $FDdata_5;
my $FDdata_7;
my $FDdata_9;
my $FDdata_11;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose         = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_Device          = GEN_Read_mandatory_testcase_parameter('Device');
	$tcpar_State_val_init  = GEN_Read_mandatory_testcase_parameter('State_val_init');
	$tcpar_State_val_fault = GEN_Read_mandatory_testcase_parameter('State_val_fault');

	$switchName = $tcpar_Device;

	unless ( defined $switchName ) {
		$switchName = 'NONE';
	}

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	$Switch_positionA = DEVICE_fetchSwitchState( $switchName, 'positionA' );
	$Switch_positionB = DEVICE_fetchSwitchState( $switchName, 'positionB' );

	my $deviceProperties = DEVICE_fetchDeviceInfo($switchName);
	$SW_state_var     = $deviceProperties->{'State_PD'};
	$SW_status_var    = $deviceProperties->{'Status_PD'};
	$SW_extstatus_var = $deviceProperties->{'ExtStatus_PD'};

	return 1;
}

sub TC_initialization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	S_w2rep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	PD_ECUlogin();    #to start Fast Diagnosis immediately
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep("Note: To read the switch states immediately after power ON, use 'Fast Diagnostics after start-up' feature.");

	return 1;
}

sub TC_stimulation_and_measurement {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	S_w2rep("Step 1. Set the switch to positionA state");
	DEVICE_setDeviceState( $switchName, $Switch_positionA );
	S_wait_ms( '2000', 'wait after state change' );

	S_w2rep("Step 2. Power_on_reset ");

	#FD with startup enabled
	GEN_printComment("Enable Fast Diagnosis at start up");
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt", [ $SW_state_var, $SW_status_var, $SW_extstatus_var ], [ "U8", "U8", "U8" ], undef, undef, 1 );
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	LC_ECU_On();
	S_wait_ms(5000, 'wait after power on' );
	
	S_w2rep("Step 3. Immediately after power ON read the switch state, status and extended status");
	PD_StopFastDiag();

	#plot the trace
	$FDdata_3 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt" );
	PD_plot_FDtrace( $FDdata_3, $main::REPORT_PATH . "/FDtrace_$switchName"."Step3.txt" );
	S_add_pic2html( "./FDtrace_$switchName"."Step3.png", '', "./FDtrace_$switchName"."Step3.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_3);

	S_w2rep("Step 4. Switch Off the ECU and set the switch to positionB");

	#FD with startup enabled
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step5.txt", [ $SW_state_var, $SW_status_var, $SW_extstatus_var ], [ "U8", "U8", "U8" ], undef, undef, 1  );
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	DEVICE_setDeviceState( $switchName, $Switch_positionB );

	S_w2rep("Step 5. Power ON and immdiately Read the switch state, status and extended status");
	LC_ECU_On();
	S_wait_ms( 5000, 'wait after power on' );
	PD_StopFastDiag();

	#plot the trace
	$FDdata_5 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step5.txt" );
	PD_plot_FDtrace( $FDdata_5, $main::REPORT_PATH . "/FDtrace_$switchName"."Step5.txt" );
	S_add_pic2html( "./FDtrace_$switchName"."Step5.png", '', "./FDtrace_$switchName"."Step5.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_5);

	S_w2rep("Step 6. Switch Off the ECU and create a fault on the switch");
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step7.txt", [ $SW_state_var, $SW_status_var, $SW_extstatus_var ], [ "U8", "U8", "U8" ], undef, undef, 1  );
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	DEVICE_setDeviceState( $switchName, 'Short2Bat' );

	S_w2rep("Step 7. Power ON and immdiately Read the switch state, status and extended status");
	LC_ECU_On();
	S_wait_ms( 5000, 'wait after power on' );
	PD_StopFastDiag();

	#plot the trace
	$FDdata_7 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step7.txt" );
	PD_plot_FDtrace( $FDdata_7, $main::REPORT_PATH . "/FDtrace_$switchName"."Step7.txt" );
	S_add_pic2html( "./FDtrace_$switchName"."Step7.png", '', "./FDtrace_$switchName"."Step7.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_7);

	#!!!!!!!!!!!!!! Device Configuration (SYC)is not yet implemented in AB12 CA !!!!!!!!!!!!!!!!!
	#comment out all below steps till its implemented

	S_w2rep("Step 8. Switch Off the ECU and remove the configuration bit");
	PD_Device_configuration( 'clear', [$switchName]);
	S_wait_ms(5000);
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step9.txt", [ $SW_state_var, $SW_status_var, $SW_extstatus_var ], [ "U8", "U8", "U8" ], undef, undef, 1  );
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );
	
	#GEN_Power_on_Reset(5000);

	S_w2rep("Step 9. Power ON and immdiately Read the switch state, status and extended status");
	LC_ECU_On();
	S_wait_ms( 5000, 'wait after power on' );
	PD_StopFastDiag();
	
	
	#plot the trace
	$FDdata_9 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step9.txt" );
	PD_plot_FDtrace( $FDdata_9, $main::REPORT_PATH . "/FDtrace_$switchName"."Step9.txt" );
	S_add_pic2html( "./FDtrace_$switchName"."Step9.png", '', "./FDtrace_$switchName"."Step9.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_9);

	S_w2rep("Step 10. Switch Off the ECU and remove the monitoring bit");
	PD_ECUlogin();
	PD_Device_configuration( 'clear_Mon', [$switchName]);
	S_wait_ms(5000);
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_$switchName"."Step11.txt", [ $SW_state_var, $SW_status_var, $SW_extstatus_var ], [ "U8", "U8", "U8" ], undef, undef, 1  );
	#GEN_Power_on_Reset(5000);
	LC_ECU_Off();
	S_wait_ms( 'TIMER_ECU_OFF', 'wait till ECU switch off completely' );

	S_w2rep("Step 11. Power ON and immdiately Read the switch state, status and extended status");
	LC_ECU_On();
	S_wait_ms( 5000, 'wait after power on' );
	PD_StopFastDiag();

	#plot the trace
	$FDdata_11 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_$switchName"."Step11.txt" );
	PD_plot_FDtrace( $FDdata_11, $main::REPORT_PATH . "/FDtrace_$switchName"."Step11.txt" );
	S_add_pic2html( "./FDtrace_$switchName"."Step11.png", '', "./FDtrace_$switchName"."Step11.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_11);

	return 1;
}

sub TC_evaluation {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	#Note: timing for below evaluation is taken as 0 ms from Pon and 2850 ms from Pon in the Fast Diagnosis trace.
	#But this value needs to checked and adjusted/calibrated with a real setup during execution and time for communication start/FD trace start needs to be taken into account.

	S_w2rep("Evaluation for Step 3. Initially, Switch state is '$tcpar_State_val_init'");
	S_w2rep("Status is Init");
	S_w2rep("Extended Status is Init");
	EVAL_evaluate_value_around_time( $FDdata_3, 0, $SW_state_var,     "==", $tcpar_State_val_init );
	EVAL_evaluate_value_around_time( $FDdata_3, 0, $SW_status_var,    "==", 0 );                       #init
	EVAL_evaluate_value_around_time( $FDdata_3, 0, $SW_extstatus_var, "==", 4 );                       #init

	S_w2rep("State changes to positionA, Status changes to Valid, Extended Status changes to Valid within 2850 ms from power ON");
	EVAL_evaluate_value_around_time( $FDdata_3, 50, $SW_state_var,     "==", 0 );                      #positionA
	EVAL_evaluate_value_around_time( $FDdata_3, 2850, $SW_status_var,    "==", 1 );                      #valid
	EVAL_evaluate_value_around_time( $FDdata_3, 2850, $SW_extstatus_var, "==", 5 );                      #valid

	S_w2rep("Evaluation for Step 5. Initially, Switch state is  '$tcpar_State_val_init'");
	S_w2rep("Status is  Init");
	S_w2rep("Extended Status is Init");
	EVAL_evaluate_value_around_time( $FDdata_5, 0, $SW_state_var,     "==", $tcpar_State_val_init );
	EVAL_evaluate_value_around_time( $FDdata_5, 0, $SW_status_var,    "==", 0 );                       #init
	EVAL_evaluate_value_around_time( $FDdata_5, 0, $SW_extstatus_var, "==", 4 );                       #init

	S_w2rep("State changes to positionB, Status changes to Valid, Extended Status changes to Valid within 2850 ms from power ON");
	EVAL_evaluate_value_around_time( $FDdata_5, 50, $SW_state_var,     "==", 1 );                      #positionB
	EVAL_evaluate_value_around_time( $FDdata_5, 2850, $SW_status_var,    "==", 1 );                      #valid
	EVAL_evaluate_value_around_time( $FDdata_5, 2850, $SW_extstatus_var, "==", 5 );                      #valid

	S_w2rep("Evaluation for Step 7. Initially, Switch state is '$tcpar_State_val_init'");
	S_w2rep("Status is Init");
	S_w2rep("Extended Status is Init");
	EVAL_evaluate_value_around_time( $FDdata_7, 0, $SW_state_var,     "==", $tcpar_State_val_init );
	EVAL_evaluate_value_around_time( $FDdata_7, 0, $SW_status_var,    "==", 0 );                       #init
	EVAL_evaluate_value_around_time( $FDdata_7, 0, $SW_extstatus_var, "==", 4 );                       #init

	S_w2rep("State changes to '$tcpar_State_val_fault', Status changes to Fault, Extended Status changes to Fault within 2850 ms from power ON");
	EVAL_evaluate_value_around_time( $FDdata_7, 50, $SW_state_var,     "==", $tcpar_State_val_fault );    #fault
	EVAL_evaluate_value_around_time( $FDdata_7, 2850, $SW_status_var,    "==", 2 );                         #fault
	EVAL_evaluate_value_around_time( $FDdata_7, 2850, $SW_extstatus_var, "==", 6 );                         #fault

	#!!!!!!!!!!!!!! Device Configuration (SYC)is not yet implemented in AB12 CA !!!!!!!!!!!!!!!!!
	#comment out all below steps till its implemented

	S_w2rep("Evaluation for Step 9. Initially, Switch state is '$tcpar_State_val_init'");
	S_w2rep("Status is Init");
	S_w2rep("Extended Status is NotConfInit");
	EVAL_evaluate_value_around_time( $FDdata_9, 0, $SW_state_var,     "==", $tcpar_State_val_init );
	EVAL_evaluate_value_around_time( $FDdata_9, 0, $SW_status_var,    "==", 0 );                          #init
	EVAL_evaluate_value_around_time( $FDdata_9, 0, $SW_extstatus_var, "==", 0 );                          #NotConfInit

	S_w2rep("State changes to '$tcpar_State_val_fault', Status changes to Fault, Extended Status changes to NotConfFault within 2850 ms from power ON");
	EVAL_evaluate_value_around_time( $FDdata_9, 50, $SW_state_var,     "==", $tcpar_State_val_fault );    #fault
	EVAL_evaluate_value_around_time( $FDdata_9, 2850, $SW_status_var,    "==", 2 );                         #fault
	EVAL_evaluate_value_around_time( $FDdata_9, 2850, $SW_extstatus_var, "==", 2 );                         #NotConfFault

	S_w2rep("Evaluation for Step 11. Initially, Switch state is '$tcpar_State_val_init'");
	S_w2rep("Status is Init");
	S_w2rep("Extended Status is NotMonitored");
	EVAL_evaluate_value_around_time( $FDdata_11, 0, $SW_state_var,     "==", $tcpar_State_val_init );
	EVAL_evaluate_value_around_time( $FDdata_11, 0, $SW_status_var,    "==", 0 );                          #init
	EVAL_evaluate_value_around_time( $FDdata_11, 0, $SW_extstatus_var, "==", 8 );                          #NotMonitored

	S_w2rep("State changes to '$tcpar_State_val_fault', Status changes to Fault,  within 2850 ms from power ON. (Extended Status remains as NotMonitored)");
	EVAL_evaluate_value_around_time( $FDdata_11, 50, $SW_state_var,     "==", $tcpar_State_val_fault );    #fault
	EVAL_evaluate_value_around_time( $FDdata_11, 2850, $SW_status_var,    "==", 0 );                         #fault
	EVAL_evaluate_value_around_time( $FDdata_11, 2850, $SW_extstatus_var, "==", 8 );                         #NotMonitored

	S_w2rep("Note: If switch is an SDL switch, state change may not happen within 2850 ms.");

	return 1;
}

sub TC_finalization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	return 1 if CheckValidDevice();

	S_w2rep("Finalization: Remove switch fault, Set the monitoring and configuration bits");
	DEVICE_resetDeviceState( $switchName, 'Short2Bat' );
	PD_ECUlogin();
	
	PD_Device_configuration( 'set_Mon', [$switchName] );
	S_wait_ms(5000);
	PD_Device_configuration( 'set',     [$switchName] );
	S_wait_ms(5000);

	return 1;
}

sub CheckValidDevice {

	if ( $switchName eq 'NONE' ) {
		S_w2rep( "Valid switch is not configured for this AIN Stop further execution\n", 'orange' );
		$PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $tcpar_Device";
		return 1;
	}
}

1;
