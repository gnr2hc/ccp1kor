#### TEST CASE MODULE
package TC_SWM_SwitchMeasurementAndEvaluation_DuringCrash;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: SWM/TC_SWM_SwitchMeasurementAndEvaluation_DuringCrash.pm 1.1 2019/08/26 12:27:07ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;
#TS version - This script is based on TS_SWM_SwitchMgt v3.27

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use LIFT_evaluation;
use LIFT_PD2ProdDiag;
use LIFT_ProdDiag;
##################################

our $PURPOSE = "to check the switch measurement and evaluation during a crash (algo/FCL active)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SWM_SwitchMeasurementAndEvaluation_DuringCrash

=head1 PURPOSE

to check the switch measurement and evaluation during a crash (algo/FCL active)

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Monitor these labels continuously using Fast Diagnosis:

	switch position
	switch status
	algo switch state
	switch fault counter
	crash algorithm state (active/inactive)
	FCL state

Note: Choose a crash such that the algo/FCL remains active for a long duration so that measurements can be done properly.


I<B<Stimulation and Measurement>>

1. Set the switch to positionB state

2. Monitor the required labels (mentioned in Test Preparation) using Fast Diagnosis and then create a crash

3. As soon as the algo or FCL gets active, change the switch state to positionA

4. Monitor the required labels using Fast Diagnosis and then Create a crash

5. As soon as algo or FCL gets active, change the switch state to Faulty (create a fault on switch)

6. Monitor the required labels using Fast Diagnosis and then Create a crash

7. As soon as algo or FCL gets active, change the switch state to positionB (remove fault that was created in step 5)


I<B<Evaluation>>

3. Switch position and algo switch state changes to positionA only after the crash (algo/FCL becomes inactive). i.e. it remains frozen for the duration on the crash

5.  

Switch position and algo switch state changes to <Switchstate_val_fault> only after the crash. 

Switch status changes from valid to fault only after the crash. 

For the SDL switch, the switch fault counter starts incrementing only after the algo/FCL becomes inactive. For all other switches, the fault counter starts incrementing immediately after the fault is created (even when algo is active). 

7. Switch position and algo switch state changes to positionB only after the crash


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'Device' => the switch device (SW1, SW2..)
	SCALAR 'Switchstate_val_fault' => value of switch state when the switch is faulty


=head2 PARAMETER EXAMPLES

	purpose	= 'To test switch measurement and evaluation during a crash'
	
	Device = 'SW1'
	Switchstate_val_fault  = '1' #default or last valid value

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Device;
my $tcpar_Switchstate_val_fault;

################ global parameter declaration ###################
#add any global variables here
my $switchName;
my $Switch_positionA;
my $Switch_positionB;
my $SW_state_var;
my $SW_status_var;
my $SW_AlgoState_var;
my $CrashAlgoState_var;
my $FCLState_var;
my $FDdata_2_3;
my $FDdata_4_5;
my $FDdata_6_7;
my $crashFile;
my $SW_FaultCounter_var;
my $SDL_switches;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose               = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_Device                = GEN_Read_mandatory_testcase_parameter('Device');
	$tcpar_Switchstate_val_fault = GEN_Read_mandatory_testcase_parameter('Switchstate_val_fault');

	#$switchName       = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_Device);
	$switchName       = $tcpar_Device;
	
	unless(defined $switchName){
		$switchName = 'NONE';
	}
	
	#before proceeding check if a valid device is configured for this switch input/AIN
	# return 1 if CheckValidDevice();
	
	$Switch_positionA = DEVICE_fetchSwitchState( $switchName, 'positionA' );
	$Switch_positionB = DEVICE_fetchSwitchState( $switchName, 'positionB' );

	#get all software labels to be read using Fast Diagnosis
	my $deviceProperties = DEVICE_fetchDeviceInfo($switchName);
	$SW_state_var  = $deviceProperties->{'State_PD'};
	$SW_status_var = $deviceProperties->{'Status_PD'};

	#TBD - get these software labels for AB12!!
	#$SW_AlgoState_var = $deviceProperties->{'AlgoState_PD'};
	#$CrashAlgoState_var = '';
	#$FCLState_var = '';
	#$crashFile = ''; #get required crash file (with long algo/FCL reset time)

	#details for Short2Bat fault (AB10) - till AB12 details are available (update during TR task!)
	my ( $flt_cnt_loc, $ISO_state_byte, $bitnr, $ISO_state_mask0, $ISO_state_mask1 ) = PD_getISOdata( "rb_swm_ShortLine$switchName" . "_flt" );
	$SW_FaultCounter_var = "A_FLMFltMemCounter_U8R($flt_cnt_loc)";

	#get SDL switch details
	$SDL_switches = $main::ProjectDefaults->{'Mapping_DEVICE'}{'SDL_switch'};

	return 1;
}

sub TC_initialization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	# return 1 if CheckValidDevice();

	GEN_printTestStep("Step 1. StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	PD_ECUlogin();    #to start Fast Diagnosis immediately
	S_wait_ms('TIMER_ECU_READY');

	GEN_printTestStep("Monitor these labels continuously using Fast Diagnosis: switch position, switch status, algo switch state, switch fault counter, crash algorithm state (active/inactive), FCL state");
	GEN_printComment("This is done in stimulation and measurement");

	return 1;
}

sub TC_stimulation_and_measurement {

	#before proceeding check if a valid device is configured for this switch input/AIN
	# return 1 if CheckValidDevice();

	GEN_printTestStep("Step 1. Set the switch to positionB state");
	DEVICE_setDeviceState( $switchName, $Switch_positionB );

	GEN_printComment("Step 2. Monitor the required labels (mentioned in Test Preparation) using Fast Diagnosis and then create a crash - for step 2,3");
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_Step2_3.txt", [ $SW_state_var, $SW_status_var, $SW_AlgoState_var, $CrashAlgoState_var, $FCLState_var, $SW_FaultCounter_var ], [ "U8", "U8", "U8", "U16", "U16", "U8" ] );
	S_wait_ms( '2000', 'wait after Fast Diag start' );
	EDR_InjectCrash($crashFile);

	GEN_printTestStep("Step 3. As soon as the algo or FCL gets active, change the switch state to positionA");
	DEVICE_setDeviceState( $switchName, $Switch_positionA );
	S_wait_ms( '2000', 'wait after state change' );

	PD_StopFastDiag();
	$FDdata_2_3 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_Step2_3.txt" );
	PD_plot_FDtrace( $FDdata_2_3, $main::REPORT_PATH . "/FDtrace_Step2_3.txt" );
	S_add_pic2html( "./FDtrace_Step2_3.png", '', "./FDtrace_Step2_3.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_2_3);

	GEN_printComment("Step 4. Monitor the required labels using Fast Diagnosis and then create a crash - for step 4,5");
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_Step4_5.txt", [ $SW_state_var, $SW_status_var, $SW_AlgoState_var, $CrashAlgoState_var, $FCLState_var, $SW_FaultCounter_var ], [ "U8", "U8", "U8", "U16", "U16", "U8" ] );
	S_wait_ms( '2000', 'wait after Fast Diag start' );
	EDR_InjectCrash($crashFile);

	GEN_printTestStep("Step 5. As soon as algo or FCL gets active, change the switch state to Faulty (create a fault on switch)");
	DEVICE_setDeviceState( $switchName, 'Short2Gnd' );
	S_wait_ms( '2000', 'wait after state change' );

	PD_StopFastDiag();
	$FDdata_4_5 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_Step4_5.txt" );
	PD_plot_FDtrace( $FDdata_4_5, $main::REPORT_PATH . "/FDtrace_Step4_5.txt" );
	S_add_pic2html( "./FDtrace_Step4_5.png", '', "./FDtrace_Step4_5.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_4_5);

	GEN_printComment("Step 6. Monitor the required labels using Fast Diagnosis and then create a crash - for step 6,7");
	PD_StartFastDiagName( $main::REPORT_PATH . "/FDtrace_Step6_7.txt", [ $SW_state_var, $SW_status_var, $SW_AlgoState_var, $CrashAlgoState_var, $FCLState_var, $SW_FaultCounter_var ], [ "U8", "U8", "U8", "U16", "U16", "U8" ] );
	S_wait_ms( '2000', 'wait after Fast Diag start' );
	EDR_InjectCrash($crashFile);

	GEN_printTestStep("Step 7. As soon as algo or FCL gets active, change the switch state to positionB (remove fault that was created in step 5)");
	DEVICE_resetDeviceState( $switchName, 'Short2Gnd' );
	DEVICE_setDeviceState( $switchName, $Switch_positionB );
	S_wait_ms( '2000', 'wait after state change' );

	PD_StopFastDiag();
	$FDdata_6_7 = PD_get_FDtrace( $main::REPORT_PATH . "/FDtrace_Step6_7.txt" );
	PD_plot_FDtrace( $FDdata_6_7, $main::REPORT_PATH . "/FDtrace_Step6_7.txt" );
	S_add_pic2html( "./FDtrace_Step6_7.png", '', "./FDtrace_Step6_7.txt.unv", 'TYPE="text/unv"' );
	EVAL_dump2file($FDdata_6_7);

	return 1;
}

sub TC_evaluation {

	#before proceeding check if a valid device is configured for this switch input/AIN
	# return 1 if CheckValidDevice();

	my $statepositionA_val = DEVICE_fetchExpectedSwitchState_PD('STATE_POSITIONA');
	my $statepositionB_val = DEVICE_fetchExpectedSwitchState_PD('STATE_POSITIONB');
	my $statusValid_val    = DEVICE_fetchExpectedSwitchState_PD('STATUS_VALID');
	my $statusFault_val    = DEVICE_fetchExpectedSwitchState_PD('STATUS_FAULT');

	GEN_printTestStep("Evaluation for Step 3. Switch position and algo switch state changes to positionA only after the crash (algo/FCL becomes inactive). i.e. it remains frozen for the duration on the crash");
	my $algoActiveTime = EVAL_get_time_when( $FDdata_2_3, $CrashAlgoState_var, '==', 1 );
	my $algoResetTime  = EVAL_get_time_when( $FDdata_2_3, $CrashAlgoState_var, '==', 0 );
	GEN_printComment("Check the switch state");
	EVAL_evaluate_value_around_time( $FDdata_2_3, $algoActiveTime, $SW_state_var, "==", $statepositionB_val );    #algo active
	EVAL_evaluate_value_around_time( $FDdata_2_3, $algoResetTime,  $SW_state_var, "==", $statepositionB_val );    #algo still active
	EVAL_evaluate_value_around_time( $FDdata_2_3, ( $algoResetTime + 100 ), $SW_state_var, "==", $statepositionA_val );    #100 ms after algo become inactive

	#	GEN_printComment("Check the algo switch state"); #to be included later
	#	EVAL_evaluate_value_around_time( $FDdata_2_3, $algoActiveTime, $SW_AlgoState_var, "==", $statepositionB_val );         #algo active
	#	EVAL_evaluate_value_around_time( $FDdata_2_3, $algoResetTime,  $SW_AlgoState_var, "==", $statepositionB_val );         #algo still active
	#	EVAL_evaluate_value_around_time( $FDdata_2_3, ( $algoResetTime + 100 ), $SW_AlgoState_var, "==", $statepositionA_val );    #100 ms after algo become inactive

	GEN_printTestStep("Evaluation for Step 5a. Switch position and algo switch state changes to '$tcpar_Switchstate_val_fault' only after the crash. ");
	$algoActiveTime = EVAL_get_time_when( $FDdata_4_5, $CrashAlgoState_var, '==', 1 );
	$algoResetTime  = EVAL_get_time_when( $FDdata_4_5, $CrashAlgoState_var, '==', 0 );
	GEN_printComment("Check the switch state");
	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoActiveTime, $SW_state_var, "==", $statepositionA_val );             #algo active
	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoResetTime,  $SW_state_var, "==", $statepositionA_val );             #algo still active
	EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoResetTime + 100 ), $SW_state_var, "==", $tcpar_Switchstate_val_fault );    #100 ms after algo become inactive

	#	GEN_printComment("Check the algo switch state"); #to be included later
	#	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoActiveTime, $SW_AlgoState_var, "==", $statepositionA_val );                  #algo active
	#	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoResetTime,  $SW_AlgoState_var, "==", $statepositionA_val );                  #algo still active
	#	EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoResetTime + 100 ), $SW_AlgoState_var, "==", $tcpar_Switchstate_val_fault );    #100 ms after algo become inactive

	GEN_printTestStep("Evaluation for Step 5b. Switch status changes from valid to fault only after the crash. ");
	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoActiveTime, $SW_status_var, "==", $statusValid_val );                        #algo active
	EVAL_evaluate_value_around_time( $FDdata_4_5, $algoResetTime,  $SW_status_var, "==", $statusValid_val );                        #algo still active
	EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoResetTime + 100 ), $SW_status_var, "==", $statusFault_val );               #100 ms after algo become inactive

	GEN_printTestStep(
"Evaluation for Step 5c. For the SDL switch, the switch fault counter starts incrementing only after the algo/FCL becomes inactive. For all other switches, the fault counter starts incrementing immediately after the fault is created (even when algo is active). "
	);
	GEN_printComment("Check the fault counter");
	if ( grep { $_ eq $switchName } @$SDL_switches ) {                                                                              #check if SDL switch
		GEN_printComment("Detected switch type for $switchName: SDL switch");
		EVAL_evaluate_value_around_time( $FDdata_4_5, $algoActiveTime, $SW_FaultCounter_var, "==", 0 );                             #algo active
		EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoActiveTime + 200 ), $SW_FaultCounter_var, ">", 0 );                    #algo active for 200 ms
		EVAL_evaluate_value_around_time( $FDdata_4_5, $algoResetTime, $SW_FaultCounter_var, ">", 0 );                               #algo still active
		EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoResetTime + 200 ), $SW_FaultCounter_var, ">", 0 );                     #200 ms after algo become inactive
	}
	else {
		GEN_printComment("Detected switch type for $switchName: normal switch");
		EVAL_evaluate_value_around_time( $FDdata_4_5, $algoActiveTime, $SW_FaultCounter_var, "==", 0 );                             #algo active
		EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoActiveTime + 200 ), $SW_FaultCounter_var, "==", 0 );                   #algo active for 200 ms
		EVAL_evaluate_value_around_time( $FDdata_4_5, $algoResetTime, $SW_FaultCounter_var, "==", 0 );                              #algo still active
		EVAL_evaluate_value_around_time( $FDdata_4_5, ( $algoResetTime + 200 ), $SW_FaultCounter_var, ">", 0 );                     #200 ms after algo become inactive
	}

	GEN_printTestStep("Evaluation for Step 7. Switch position and algo switch state changes to positionB only after the crash");
	$algoActiveTime = EVAL_get_time_when( $FDdata_6_7, $CrashAlgoState_var, '==', 1 );
	$algoResetTime  = EVAL_get_time_when( $FDdata_6_7, $CrashAlgoState_var, '==', 0 );
	GEN_printComment("Check the switch state");
	EVAL_evaluate_value_around_time( $FDdata_6_7, $algoActiveTime, $SW_state_var, "==", $tcpar_Switchstate_val_fault );             #algo active
	EVAL_evaluate_value_around_time( $FDdata_6_7, $algoResetTime,  $SW_state_var, "==", $tcpar_Switchstate_val_fault );             #algo still active
	EVAL_evaluate_value_around_time( $FDdata_6_7, ( $algoResetTime + 100 ), $SW_state_var, "==", $statepositionB_val );             #100 ms after algo become inactive

	#	GEN_printComment("Check the algo switch state"); #to be included later
	#	EVAL_evaluate_value_around_time( $FDdata_6_7, $algoActiveTime, $SW_AlgoState_var, "==", $tcpar_Switchstate_val_fault );             #algo active
	#	EVAL_evaluate_value_around_time( $FDdata_6_7, $algoResetTime,  $SW_AlgoState_var, "==", $tcpar_Switchstate_val_fault );             #algo still active
	#	EVAL_evaluate_value_around_time( $FDdata_6_7, ( $algoResetTime + 100 ), $SW_AlgoState_var, "==", $statepositionB_val );             #100 ms after algo become inactive

	return 1;
}

sub TC_finalization {

	#before proceeding check if a valid device is configured for this switch input/AIN
	# return 1 if CheckValidDevice();

	return 1;
}

sub CheckValidDevice {

	if ( $switchName eq 'NONE' ) {
		S_w2rep( "Valid switch is not configured for this AIN Stop further execution\n", 'orange' );
		$PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for $tcpar_Device";
		return 1;
	}
}

1;
