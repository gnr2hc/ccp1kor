#### TEST CASE MODULE
package TC_COM_RxDLCError;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_RxDLCError.pm 1.1 2020/04/30 14:30:55ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<To create a DLC Error for Rx signals and checking the fault status under different voltage conditions and different ECU modes";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_RxDLCError

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <VoltageCondition_V> 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Wait till ECU intialization period completes

7. Create DLC error<faultname> for the mesage <MessageName>.  

8. Measure Qualifiation time after fault qualificaiton

9. Read the fault recorder by PD after Fault Qualification

10 . Read the fault recorder by CD after Fault Qualification

11. Read the warning lamp status after fault qualificaiton

12. Start sending CAN message with valid DLC value 

13. Measure Dequalifiation time after fault dequalificaiton

14. Read the fault recorder by PD after Fault DeQualification

15. Read the fault recorder by CD after Fault DeQualification

16. Read the warning lamp status after fault dequalificaiton


I<B<Evaluation>>

1.

2.

3.

4.

5.

6.

7.

8. Measured Qualification Time should have Qualification time of the fault with  <Tolerance>

9. Fault <faultname>   has status<FaultQualistatus>

10. Fault <faultname>   has status<FaultQualistatus> 

11. Warning lamp <SysWL_SigLabel> has status <WL_Faultquali>

12.

13. Measured Dequalification Time should have Dequalification time of the fault with  <Tolerance>

14. Fault <faultname>   has status <FaultDeQualistatus> 

15. Fault <faultname>   has status <FaultDeQualistatus>

16. Warning lamp has status <WL_FaultDequali>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'WL_Faultquali' => 
	SCALAR 'WL_FaultDequali' => 
	SCALAR 'Faulthandling' => 
	SCALAR 'faultname' => 
	SCALAR 'FaultQualistatus' => 
	SCALAR 'FaultDeQualistatus' => 
	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'VoltageCondition_V' => 
	SCALAR 'MessageName' => 
	SCALAR 'SysWL_SigLabel' => 
	SCALAR 'Tolerance' => 
	SCALAR 'InvalidDLCValue' => 
	SCALAR 'ValidDLCValue' => 
	SCALAR 'EnvVarName' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	
	purpose = 'Check fault qualification for Time Out of the Rx message'
	#  parameters
	
	ECU_Mode = '<Test Heading 1>'
	VoltageCondition_V = '<Test Heading 2>' # Volt
	MessageName = '<Fetch {Object Heading} {(.*)}>'
	SysWL_SigLabel = 'TBD'
	Tolerance = '10'
	InvalidDLCValue= 'TBD' 
	ValidDLCValue= 'TBD'
	EnvVarName = 'TBD'
	
	# Example
	#SysWL_SigLabel = 'SRS_AirbagFaultSt'
	#Tolerance = '10'
	#InvalidDLCValue= '3' 
	#ValidDLCValue= '8'
	#EnvVarName = 'EnvBCS_2Dlc_'
	#WL_Faultquali = '1'
	#WL_FaultDequali = '0'
	#Faulthandling = 'TBD'
	#faultname = 'rb_cfh_ABSCommunication_flt'
	#FaultQualistatus = '0x2F'
	#FaultDeQualistatus = '0x2E'
	WL_Faultquali = 'TBD'
	WL_FaultDequali = 'TBD'
	Faulthandling = 'TBD'
	faultname = 'TBD'
	FaultQualistatus = 'TBD'
	FaultDeQualistatus = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_faultname;
my $tcpar_ECU_Mode;
my $tcpar_VoltageCondition_V;
my $tcpar_MessageName;
my $tcpar_WL_Signal;
my $tcpar_Tolerance;
my $tcpar_InvalidDLCValue;
my $tcpar_ValidDLCValue;
my $tcpar_QualiTime;
my $tcpar_DequaliTime;
my $tcpar_WL_Faultquali;
my $tcpar_WL_FaultDequali;
my $tcpar_Faulthandling;
my $tcpar_SysWL_SigLabel;
my $tcpar_FaultQualistatus;
my $tcpar_FaultDeQualistatus;
my $tcpar_CDFaultQualistatus;
my $tcpar_CDFaultDeQualistatus;
my $tcpar_qualiType;
my $tcpar_Protocol;
################ global parameter declaration ###################
my $faultproperty;
my @tcpar_Mandatory_Flts;
my @tcpar_Optional_Flts;
my $FDtrace_name;
my $FD_start_delta;
my $time_measurement;
my $measuredtime_qualificationTime;
my $measuredtime_dequalificationTime;
my $Quali_Time;
my $De_Quali_Time;
my $detected_CD_status;
my $detected_PD_status;
my $sysWLAtFltQuali;
my $sysWLAtFltDequali;
my $unit;
my %flt_mem_struct_pd_qualification;
my %flt_mem_struct_cd_qualification;
my %flt_mem_struct_pd_dequalification;
my %flt_mem_struct_cd_dequalification;
my $CAN_Mapping;
my $DLCEnVarName;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_faultname =  S_read_mandatory_testcase_parameter( 'faultname' );
	$tcpar_ECU_Mode =  S_read_mandatory_testcase_parameter( 'ECU_Mode' );
	$tcpar_VoltageCondition_V =  S_read_mandatory_testcase_parameter( 'VoltageCondition_V' );
	$tcpar_MessageName =  S_read_mandatory_testcase_parameter( 'MessageName' );
	$tcpar_Tolerance =  S_read_mandatory_testcase_parameter( 'Tolerance' );
	$tcpar_InvalidDLCValue =  S_read_mandatory_testcase_parameter( 'InvalidDLCValue' );
	$tcpar_ValidDLCValue =  S_read_mandatory_testcase_parameter( 'ValidDLCValue' );
	$tcpar_WL_Faultquali =  S_read_mandatory_testcase_parameter( 'WL_Faultquali' );
	$tcpar_WL_FaultDequali =  S_read_mandatory_testcase_parameter( 'WL_FaultDequali' );
	$tcpar_Faulthandling =  S_read_mandatory_testcase_parameter( 'Faulthandling' );
	$tcpar_SysWL_SigLabel = S_read_mandatory_testcase_parameter( 'SysWL_SigLabel' );
	$tcpar_FaultQualistatus = S_read_mandatory_testcase_parameter( 'FaultQualistatus' );
	$tcpar_FaultDeQualistatus = S_read_mandatory_testcase_parameter( 'FaultDeQualistatus' );
	$tcpar_CDFaultQualistatus =  S_read_mandatory_testcase_parameter( 'CDFaultQualistatus' );
	$tcpar_CDFaultDeQualistatus =  S_read_mandatory_testcase_parameter( 'CDFaultDeQualistatus' );	
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_qualiType = S_read_mandatory_testcase_parameter( 'qualiType' );
	@tcpar_Mandatory_Flts = S_read_mandatory_testcase_parameter( 'Mandatory_Flts' );
	@tcpar_Optional_Flts = S_read_mandatory_testcase_parameter( 'Optional_Flts' );
	$tcpar_Tolerance = S_read_optional_testcase_parameter('Tolerance');
	
	 unless( defined $tcpar_ECU_Mode ) {
  		S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  		$tcpar_ECU_Mode = 'NormalMode';
    };	
	
    unless( $tcpar_Faulthandling =~ /yes|no/i ) {
        S_set_error( "Unexpected setting for parameter 'FaultHandling'; use YES or NO "); return 0;
    }
    $tcpar_Faulthandling = 'YES' if $tcpar_Faulthandling =~ /yes/i;
	

	if(($tcpar_VoltageCondition_V >='6.5') and ($tcpar_VoltageCondition_V <= '20'))
	{
		S_w2rep("Set Voltage $tcpar_VoltageCondition_V within range(between 6.5 and 20 volts)\n"); 		
	}
	else
	{
		S_set_error( "Voltage out of range, set proper voltage "); 
		return 0;
	}


	
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);
	
	# Fetching of Fault Quali and dequli times from the Fault mapping file
	$faultproperty = FM_fetchFaultInfo($tcpar_faultname);
	$time_measurement = FM_fetchConstant( 'FAULTMEMORY', 'time_measurements' );
	
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
	$Quali_Time  = $faultproperty->{'CyclicQualificationtime'};
	$De_Quali_Time  = $faultproperty->{'CyclicDequalificationtime'};
	
	my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$DLCEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_DLC'};
	
	return 1;
}

sub TC_stimulation_and_measurement {
################################################################## SET THE DIFFERENT ECU MODE ################################################################

	S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('IdleMode');
	}
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
	
############################################################### SET THE DIFFERENT POWER SUPLLY MODE ###############################################################

	S_teststep("Set the ECU Supply Voltage at '$tcpar_VoltageCondition_V'", 'AUTO_NBR');
        
    LC_SetVoltage( $tcpar_VoltageCondition_V);
############################################################# Reset the ECU ############################################################################################	
	S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
	LC_ECU_Off();
	
	S_teststep("Wait till ECU goes to Off State", 'AUTO_NBR');
	S_wait_ms('TIMER_ECU_OFF');
	
	S_teststep("Switch ON the ECU.", 'AUTO_NBR');
	LC_ECU_On($tcpar_VoltageCondition_V);
	
	S_teststep("Wait till ECU intialization period completes", 'AUTO_NBR');
	S_wait_ms('TIMER_ECU_READY');
	
########################################################## CREATE the fault/Measure the Time/Record the DTC & WL ############################################################	

	S_teststep("Create DLC error  for the mesage '$tcpar_MessageName' ", 'AUTO_NBR');
	FM_PD_measureTimePreparation( $tcpar_faultname, 'Qualification' );
	$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Cyclic ( $tcpar_faultname );
	S_set_timer_zero('FD_start'); #fault creation start reference (to be used by FM_measureTime)	
	#COM_CreateDLCErrors([$tcpar_MessageName], 'can' );
	CA_set_EnvVar_value ( $DLCEnVarName, $tcpar_InvalidDLCValue);
	S_w2rep("Measure the qualification time",'blue');	
	S_wait_ms($Quali_Time);
	S_teststep("Measure Qualifiation time after fault qualificaiton ", 'AUTO_NBR', 'QualificationTime_after_fault_qualification');
	$FD_start_delta = S_read_timer_ms ('FD_start') if ( $time_measurement eq 'PD' and $tcpar_qualiType eq 'cyclic' ) ; #to measure the time taken for fast diag start
	$measuredtime_qualificationTime = FM_PD_measureEndQualiDequaliTime_Cyclic ( $tcpar_faultname, 'Qualification', $FDtrace_name, $FD_start_delta );
		
	S_teststep("Read the fault recorder by PD after Fault Qualification ", 'AUTO_NBR', 'PD_status_after_fault_qualification'); 		 										# Read the DTC after fault qualification
	$flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'} = PD_ReadFaultMemory();

	S_teststep("Read the fault recorder by CD after Fault Qualification ", 'AUTO_NBR', 'CD_status_after_fault_qualification'); 
	$flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'} = CD_read_DTC('02','08');  
	
	S_teststep("Read the warning lamp status after fault qualificaiton ", 'AUTO_NBR', 'WL_status_after_fault_qualification');
	S_w2rep("  System warning lamp value received from CAN after fault qualification : $sysWLAtFltQuali \n");		#Read the warning Lamp status after fault qualification
	($sysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );	
	
	FM_PD_measureTimePreparation( $tcpar_faultname, 'Dequalification' );
	$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Cyclic ( $tcpar_faultname );
	S_set_timer_zero('FD_start'); #fault creation start reference (to be used by FM_measureTime)
	
	
	S_teststep("Start sending CAN message with valid DLC value '$tcpar_MessageName'", 'AUTO_NBR');							# Remove the fault
	#COM_RemoveDLCErrors( [$tcpar_MessageName], 'can' );
	CA_set_EnvVar_value ( $DLCEnVarName, $tcpar_ValidDLCValue);										
	
	S_w2rep("Measure the Dequalification time",'blue');	# Measure the fault Dequalification time
	S_wait_ms($De_Quali_Time);
	S_teststep("Measure Dequalifiation time after fault dequalificaiton ", 'AUTO_NBR', 'DequalificationTime_after_fault_qualification');
	$FD_start_delta = S_read_timer_ms ('FD_start') if ( $time_measurement eq 'PD' and $tcpar_qualiType eq 'cyclic' ) ; #to measure the time taken for fast diag start
	$measuredtime_dequalificationTime = FM_PD_measureEndQualiDequaliTime_Cyclic ( $tcpar_faultname, 'Dequalification', $FDtrace_name, $FD_start_delta );
	
	S_teststep("Read the fault recorder by PD after Fault DeQualification ", 'AUTO_NBR', 'PD_status_after_fault_dequalification'); 												# Read the DTC after fault Dequalification
	$flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read the fault recorder by CD after Fault DeQualification ", 'AUTO_NBR', 'CD_status_after_fault_dequalification');
	$flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'} = CD_read_DTC('02','08'); 
	
	S_teststep("Read the warning lamp status after fault dequalificaiton ", 'AUTO_NBR', 'WL_status_after_fault_dequalification');
	S_w2rep("  System warning lamp value received from CAN after fault dequalification  : $sysWLAtFltDequali \n");	#Read the warning Lamp status after fault Dequalification
	($sysWLAtFltDequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );  

	return 1;
}

sub TC_evaluation {

	if($tcpar_Faulthandling eq 'YES')
		{
			S_teststep_detected("Detected Qualification time: $measuredtime_qualificationTime ", 'QualificationTime_after_fault_qualification');
			S_teststep_expected("Expected Qualification time: $Quali_Time ", 'QualificationTime_after_fault_qualification');
			FM_evaluateQualiDequaliTime( $tcpar_faultname, $measuredtime_qualificationTime, 'qualitime', $tcpar_Tolerance,$Quali_Time );
			
			$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname );        
			S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_status_after_fault_qualification');
			S_teststep_expected("Fault Status read by PD: $tcpar_FaultQualistatus ", 'PD_status_after_fault_qualification');
			PD_check_fault_status($flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_FaultQualistatus);			# Evalute the DTC Status after fault qualification
					
			$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname );        
			S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_status_after_fault_qualification');
			S_teststep_expected("Fault Status read by CD: $tcpar_CDFaultQualistatus ", 'CD_status_after_fault_qualification');
			CD_check_fault_status($flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_CDFaultQualistatus);
			
			S_teststep_detected("Detected Warning lamp status after qualification : $sysWLAtFltQuali  ", 'WL_status_after_fault_qualification');
			S_teststep_expected("Expected Warning lamp status after qualification: $tcpar_WL_Faultquali ", 'WL_status_after_fault_qualification');
			EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $sysWLAtFltQuali, '==', $tcpar_WL_Faultquali );	 	        # Evalute the Warning Lamp
			
			S_teststep_detected("Detected DeQualification time: $measuredtime_dequalificationTime ", 'DequalificationTime_after_fault_qualification');
			S_teststep_expected("Expected DeQualification time: $De_Quali_Time", 'DequalificationTime_after_fault_qualification');
			FM_evaluateQualiDequaliTime( $tcpar_faultname, $measuredtime_dequalificationTime, 'dequalitime', $tcpar_Tolerance,$De_Quali_Time );
					
			$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
			S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_status_after_fault_dequalification');
			S_teststep_expected("Fault Status read by PD: $tcpar_FaultDeQualistatus ", 'PD_status_after_fault_dequalification');				# Evalute the DTC Status after fault Dequalification
			PD_check_fault_status($flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_FaultDeQualistatus);
					
			$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
			S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_status_after_fault_dequalification');
			S_teststep_expected("Fault Status read by CD: $tcpar_CDFaultDeQualistatus ", 'CD_status_after_fault_dequalification');
			CD_check_fault_status($flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_CDFaultDeQualistatus);
			
			S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDequali  ", 'WL_status_after_fault_dequalification');
			S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali ", 'WL_status_after_fault_dequalification');
			EVAL_evaluate_value( "System warning lamp status after fault dequalificaiton : ", $sysWLAtFltDequali, '==', $tcpar_WL_FaultDequali );	# Evalute the warning lamp status
		}
		else
		{		
							
			my $CD_flt_mem_struct = CD_read_DTC('02','08'); 
			CD_evaluate_faults( $CD_flt_mem_struct, @tcpar_Mandatory_Flts,@tcpar_Optional_Flts ); 
			
			my $PD_flt_mem_struct = PD_ReadFaultMemory();
			PD_evaluate_faults( $PD_flt_mem_struct, @tcpar_Mandatory_Flts,@tcpar_Optional_Flts ); 	
		
		}	

	return 1;
}

sub TC_finalization {

	
	S_w2rep("TC FINALIZATION\n");
	
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms (5000);
	}
	
	if($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms (5000);
	}	 
		
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
