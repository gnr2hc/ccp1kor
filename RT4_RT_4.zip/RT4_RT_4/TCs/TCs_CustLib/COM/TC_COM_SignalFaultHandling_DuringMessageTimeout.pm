#### TEST CASE MODULE
package TC_COM_SignalFaultHandling_DuringMessageTimeout;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_SignalFaultHandling_DuringMessageTimeout.pm 1.1 2020/04/30 14:30:55ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "Signal fault handling during message timeout fault";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_SignalFaultHandling_DuringMessageTimeout

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Create a <Signal_Fault>  and wait for SignalQualification_Time

2.Read fault recorder after signal fault qualification through PD

3.Read fault recorder after signal fault qualification through PD

4. Verify Warning lamp satus after signal fault qualification

5. Create a <Message_TimeoutFault> and wait for TimeoutQualification_Time

6. Read Fault Recorder through PD after timeout fault qualification

7. Read Fault Recorder through CD after timeout fault qualification

8. Verify the status of signal fault through PD after timeout fault qualification

9. Verify the status of signal fault through CD after timeout fault qualification

10. Verify Warning lamp satus after timeout fault qualification

11. Remove '<Message_TimeoutFault> and wait for TimeoutDequalification_Time

12. Read Fault Recorder through PD after timeout fault dequalification

13. Read Fault Recorder through CD after timeout fault dequalification

14. Verify the status of signal fault through PD after timeout fault dequalification.

15. Verify the status of signal fault through CD after timeout fault dequalification

16. Verify Warning lamp satus after timeout fault dequalification

17. Remove a <Signal_Faul>'  and wait for SignalDequalification_Time

18. Read fault recorder after signal fault dequalification through PD

19. Read fault recorder after signal fault dequalification through CD

20. Verify Warning lamp satus after signal fault dequalification


I<B<Evaluation>>

1.

2. <Signal_Fault > should have   <Signal_Fault_QualiStatus>

3. <Signal_Fault > should have   <Signal_Fault_QualiStatus>

4. Warning lamp <SysWL_SigLabel> should have status <WL_Faultquali> 

5.

6. <Message_TimeoutFault > should have   <Timeout_Fault_QualiStatus>

7. <Message_TimeoutFault > should have   <Timeout_Fault_QualiStatus>

8. <Signal_Fault> should have<Signal_Fault_QualiStatus>

9. <Signal_Fault> should have<Signal_Fault_QualiStatus>

10. Warning lamp <SysWL_SigLabel> should have status <WL_Faultquali>

11.

12.<Message_TimeoutFault > should have   <Timeout_Fault_DeQualiStatus>

13. <Message_TimeoutFault > should have   <Timeout_Fault_DeQualiStatus>

14. <Signal_Fault> should have<Signal_Fault_QualiStatus>

15. <Signal_Fault> should have<Signal_Fault_QualiStatus>

16. Warning lamp <SysWL_SigLabel> should have status <WL_Faultquali>

17.

18. <Signal_Fault> is in <Signal_Fault_DeQualiStatus>

19. <Signal_Fault> is in <Signal_Fault_DeQualiStatus>

20.Warning lamp <SysWL_SigLabel> should have status <WL_FaultDequali>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Message_TimeoutFault' => 
	SCALAR 'Signal_Fault' => 
	SCALAR 'Timeout_Fault_QualiStatus' => 
	SCALAR 'Signal_Fault_QualiStatus' => 
	SCALAR 'Timeout_Fault_DeQualiStatus' => 
	SCALAR 'Signal_Fault_DeQualiStatus' => 
	SCALAR 'WL_Faultquali' => 
	SCALAR 'WL_FaultDequali' => 
	SCALAR 'Message' => 
	SCALAR 'physicalValueValid' => 
	SCALAR 'signal' => 
	SCALAR 'physicalValue' => 


=head2 PARAMETER EXAMPLES

	purpose='signal fault is not handling during message fault and handling normally when message fault is not there'
	Message_TimeoutFault ='TBD'
	Signal_Fault='TBD'
	Timeout_Fault_QualiStatus='TBD'
	Signal_Fault_QualiStatus='TBD'
	Timeout_Fault_DeQualiStatus='TBD'
	Signal_Fault_DeQualiStatus='TBD'
	WL_Faultquali = 'TBD'
	WL_FaultDequali = 'TBD'
	Message = 'TBD'
	physicalValueValid = 'TBD'
	signal = 'TBD'
	physicalValue = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Message_TimeoutFault;
my $tcpar_Signal_Fault;
my $tcpar_SignalQualification_Time;
my $tcpar_TimeoutDeQualification_Time;
my $tcpar_TimeoutQualification_Time;
my $tcpar_Timeout_Fault_QualiStatus;
my $tcpar_Signal_Fault_QualiStatus;
my $tcpar_Timeout_Fault_DeQualiStatus;
my $tcpar_Signal_Fault_DeQualiStatus;

my $tcpar_Timeout_Fault_CDQualiStatus;
my $tcpar_Signal_Fault_CDQualiStatus;
my $tcpar_Timeout_Fault_CDDeQualiStatus;
my $tcpar_Signal_Fault_CDDeQualiStatus;

my $tcpar_WL_Faultquali;
my $tcpar_WL_FaultDequali;
my $tcpar_Message;
my $tcpar_signal;
my $tcpar_physicalValueValid;
my $tcpar_Protocol;
my $tcpar_physicalValue;
my $tcpar_SysWL_SigLabel;
my $tcpar_Protocol;
################ global parameter declaration ###################
my %flt_mem_struct_pd_signal_qualificaiton;
my %flt_mem_struct_cd_signal_qualificaiton;
my %flt_mem_struct_pd_timeout_qualification;
my %flt_mem_struct_cd_timeout_qualification;
my %flt_mem_struct_signal_pd_faultstatus_after_timeoutfltqualification;
my %flt_mem_struct_signal_cd_faultstatus_after_timeoutfltqualification;
my %flt_mem_struct_pd_timeout_dequalification;
my %flt_mem_struct_cd_timeout_dequalification;
my %flt_mem_struct_signal_pd_faultstatus_after_timeoutfltdequalification;
my %flt_mem_struct_signal_cd_faultstatus_after_timeoutfltdequalification;
my %flt_mem_struct_pd_signal_dequalification;
my %flt_mem_struct_cd_signal_dequalification;
my $sysWLAtFltQuali;
my $unit;
my $sysWLAtFltDequali;
my $SignalsysWLAtFltQuali;
my $TimeoutsysWLAtFltQuali;
my $SignalQualification_Time;
my $SignalDequalification_Time;
my $TimeoutQualification_Time;
my $TimeoutDequalification_Time;
my $faultproperty;
my $detected_CD_status;
my $detected_PD_status;
my $SignalsysWLAtFltdequali;
my $TimeoutsysWLAtFltdequali;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Message_TimeoutFault =  S_read_mandatory_testcase_parameter( 'Message_TimeoutFault' );
	$tcpar_Signal_Fault =  S_read_mandatory_testcase_parameter( 'Signal_Fault' );	
	$tcpar_Timeout_Fault_QualiStatus =  S_read_mandatory_testcase_parameter( 'Timeout_Fault_QualiStatus' );
	$tcpar_Signal_Fault_QualiStatus =  S_read_mandatory_testcase_parameter( 'Signal_Fault_QualiStatus' );
	$tcpar_Timeout_Fault_DeQualiStatus =  S_read_mandatory_testcase_parameter( 'Timeout_Fault_DeQualiStatus' );
	$tcpar_Signal_Fault_DeQualiStatus =  S_read_mandatory_testcase_parameter( 'Signal_Fault_DeQualiStatus' );
	
	$tcpar_Timeout_Fault_CDQualiStatus =  S_read_mandatory_testcase_parameter( 'Timeout_Fault_CDQualiStatus' );
	$tcpar_Signal_Fault_CDQualiStatus =  S_read_mandatory_testcase_parameter( 'Signal_Fault_CDQualiStatus' );
	$tcpar_Timeout_Fault_CDDeQualiStatus =  S_read_mandatory_testcase_parameter( 'Timeout_Fault_CDDeQualiStatus' );
	$tcpar_Signal_Fault_CDDeQualiStatus =  S_read_mandatory_testcase_parameter( 'Signal_Fault_CDDeQualiStatus' );
	
	$tcpar_WL_Faultquali =  S_read_mandatory_testcase_parameter( 'WL_Faultquali' );
	$tcpar_WL_FaultDequali =  S_read_mandatory_testcase_parameter( 'WL_FaultDequali' );
	$tcpar_Message =  S_read_mandatory_testcase_parameter( 'Message' );
	$tcpar_signal =  S_read_mandatory_testcase_parameter( 'Signal' );
	$tcpar_physicalValueValid = S_read_mandatory_testcase_parameter('physicalValueValid');
	$tcpar_physicalValue = S_read_mandatory_testcase_parameter('physicalValue');
	$tcpar_SysWL_SigLabel = S_read_mandatory_testcase_parameter('SysWL_SigLabel');
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);
	
	# Fetching of Fault Quali and dequli times from the Fault mapping file
	$faultproperty = FM_fetchFaultInfo($tcpar_Signal_Fault);
		
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
	$SignalQualification_Time  = $faultproperty->{'CyclicQualificationtime'};
	$SignalDequalification_Time  = $faultproperty->{'CyclicDequalificationtime'};
	
	$faultproperty = FM_fetchFaultInfo($tcpar_Message_TimeoutFault);
		
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
	$TimeoutQualification_Time  = $faultproperty->{'CyclicQualificationtime'};
	$TimeoutDequalification_Time  = $faultproperty->{'CyclicDequalificationtime'};
	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Create a '$tcpar_Signal_Fault'  and wait for '$SignalQualification_Time'", 'AUTO_NBR');
	COM_setSignalState ($tcpar_signal, $tcpar_physicalValue, $tcpar_Protocol);
	S_wait_ms($SignalQualification_Time);
	
	S_teststep("Read fault recorder after signal fault qualification through PD", 'AUTO_NBR', 'PD_Signal_Fault_status_after_qualification');			#measurement 1
	$flt_mem_struct_pd_signal_qualificaiton{'SignalFaultStatus_afterQualification'} = PD_ReadFaultMemory();
	
	S_teststep("Read fault recorder after signal fault qualification through CD", 'AUTO_NBR', 'CD_Signal_Fault_status_after_qualification');
	$flt_mem_struct_cd_signal_qualificaiton{'SignalFaultStatus_afterQualification'} = CD_read_DTC('02','08');
	
	S_teststep("Verify Warning lamp satus after signal fault qualification", 'AUTO_NBR', 'WL_Signal_Fault_status_after_qualification');
	S_w2rep("  System warning lamp value received from CAN after Signal fault qualification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($SignalsysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );
	
	S_teststep("Create a '$tcpar_Message_TimeoutFault' and wait for '$TimeoutQualification_Time'", 'AUTO_NBR');	
	COM_stopMessages( [$tcpar_Message], $tcpar_Protocol );
	S_wait_ms($TimeoutQualification_Time);
	
	S_teststep("Read Fault Recorder through PD after timeout fault qualification", 'AUTO_NBR', 'PD_Timeout_Fault_status_after_qualification');			#measurement 2
	$flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'} = PD_ReadFaultMemory();
	
	S_teststep("Read Fault Recorder through CD after timeout fault qualification", 'AUTO_NBR', 'CD_Timeout_Fault_status_after_qualification');
	$flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'} = CD_read_DTC('02','08');
	
	S_teststep("Verify the status of signal fault through PD after timeout fault qualification", 'AUTO_NBR', 'PD_Signal_Fault_status_after_TimeoutFltqualification');			#measurement 2
	$flt_mem_struct_signal_pd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'} = PD_ReadFaultMemory();
	
	S_teststep("Verify the status of signal fault through CD after timeout fault qualification", 'AUTO_NBR', 'CD_Signal_Fault_status_after_TimeoutFltqualification');
	$flt_mem_struct_signal_cd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'} = CD_read_DTC('02','08');
	
	S_teststep("Verify Warning lamp satus after timeout fault qualification", 'AUTO_NBR', 'WL_Timeout_Fault_status_after_qualification');
	S_w2rep("  System warning lamp value received from CAN after Timeout fault qualification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($TimeoutsysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );
	
	S_teststep("Remove '$tcpar_Message_TimeoutFault' and wait for '$TimeoutDequalification_Time'", 'AUTO_NBR');
	COM_startMessages( [$tcpar_Message], $tcpar_Protocol );
	S_wait_ms($TimeoutDequalification_Time);
	
	S_teststep("Read Fault Recorder through PD after timeout fault dequalification", 'AUTO_NBR', 'PD_Timeout_Fault_status_after_dequalification');			#measurement 2
	$flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'} = PD_ReadFaultMemory();
	
	S_teststep("Read Fault Recorder through CD after timeout fault dequalification", 'AUTO_NBR', 'CD_Timeout_Fault_status_after_dequalification');
	$flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'} = CD_read_DTC('02','08');
	
	S_teststep("Verify the status of signal fault through PD after timeout fault dequalification", 'AUTO_NBR', 'PD_Signal_Fault_status_after_TimeoutFltdequalification');			#measurement 2
	$flt_mem_struct_signal_pd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'} = PD_ReadFaultMemory();
	
	S_teststep("Verify the status of signal fault through CD after timeout fault dequalification", 'AUTO_NBR', 'CD_Signal_Fault_status_after_TimeoutFltdequalification');
	$flt_mem_struct_signal_cd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'} = CD_read_DTC('02','08');
	
	S_teststep("Verify Warning lamp satus after timeout fault dequalification", 'AUTO_NBR', 'WL_Timeout_Fault_status_after_dequalification');
	S_w2rep("  System warning lamp value received from CAN after Timeout fault Dequalification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($TimeoutsysWLAtFltdequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );
	
	S_teststep("Remove a '$tcpar_Signal_Fault'  and wait for '$SignalDequalification_Time'", 'AUTO_NBR');
	COM_setSignalState ($tcpar_signal, $tcpar_physicalValueValid, $tcpar_Protocol);
	S_wait_ms($SignalDequalification_Time);
	
	S_teststep("Read fault recorder after signal fault dequalification through PD", 'AUTO_NBR', 'PD_signal_Fault_status_after_dequalification');			#measurement 1
	$flt_mem_struct_pd_signal_dequalification{'SignalFaultStatus_afterDequalification'} = PD_ReadFaultMemory();
	
	S_teststep("Read fault recorder after signal fault dequalification through CD", 'AUTO_NBR', 'CD_signal_Fault_status_after_dequalification');
	$flt_mem_struct_cd_signal_dequalification{'SignalFaultStatus_afterDequalification'} = CD_read_DTC('02','08');
				
	S_teststep("Verify Warning lamp satus after signal fault dequalification", 'AUTO_NBR', 'WL_signal_Fault_status_after_dequalification');
	S_w2rep("  System warning lamp value received from CAN after Signal fault dequalification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($SignalsysWLAtFltdequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );	

	return 1;
}

sub TC_evaluation {

	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_signal_qualificaiton{'SignalFaultStatus_afterQualification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Signal_Fault_status_after_qualification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Signal_Fault_QualiStatus ", 'PD_Signal_Fault_status_after_qualification');
	PD_check_fault_status($flt_mem_struct_pd_signal_qualificaiton{'SignalFaultStatus_afterQualification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_QualiStatus);			# Evalute the DTC Status after fault qualification
			
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_signal_qualificaiton{'SignalFaultStatus_afterQualification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Signal_Fault_status_after_qualification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Signal_Fault_CDQualiStatus ", 'CD_Signal_Fault_status_after_qualification');
	CD_check_fault_status($flt_mem_struct_cd_signal_qualificaiton{'SignalFaultStatus_afterQualification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_CDQualiStatus);
	
	S_teststep_detected("Detected Warning lamp status after qualification : $SignalsysWLAtFltQuali  ", 'WL_Signal_Fault_status_after_qualification');
	S_teststep_expected("Expected Warning lamp status after qualification: $tcpar_WL_Faultquali ", 'WL_Signal_Fault_status_after_qualification');
	EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $SignalsysWLAtFltQuali, '==', $tcpar_WL_Faultquali );	
		
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $tcpar_Message_TimeoutFault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status (Faultname: $tcpar_Message_TimeoutFault)", 'PD_Timeout_Fault_status_after_qualification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Timeout_Fault_QualiStatus ", 'PD_Timeout_Fault_status_after_qualification');
	PD_check_fault_status($flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $tcpar_Message_TimeoutFault, $tcpar_Timeout_Fault_QualiStatus);			# Evalute the DTC Status after fault qualification
			
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $tcpar_Message_TimeoutFault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status (Faultname: $tcpar_Message_TimeoutFault)", 'CD_Timeout_Fault_status_after_qualification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Timeout_Fault_CDQualiStatus ", 'CD_Timeout_Fault_status_after_qualification');
	CD_check_fault_status($flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $tcpar_Message_TimeoutFault, $tcpar_Timeout_Fault_CDQualiStatus);
			
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_signal_pd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Signal_Fault_status_after_TimeoutFltqualification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Signal_Fault_QualiStatus ", 'PD_Signal_Fault_status_after_TimeoutFltqualification');
	PD_check_fault_status($flt_mem_struct_signal_pd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_QualiStatus);			# Evalute the DTC Status after fault qualification
			
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_signal_cd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Signal_Fault_status_after_TimeoutFltqualification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Signal_Fault_QualiStatus ", 'CD_Signal_Fault_status_after_TimeoutFltqualification');
	CD_check_fault_status($flt_mem_struct_signal_cd_faultstatus_after_timeoutfltqualification{'Signal_Fault_status_after_TimeoutFltqualification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_QualiStatus);
		
	S_teststep_detected("Detected Warning lamp status after timeout fault qualification : $TimeoutsysWLAtFltQuali  ", 'WL_Timeout_Fault_status_after_qualification');
	S_teststep_expected("Expected Warning lamp status after timeout fault qualification: $tcpar_WL_Faultquali ", 'WL_Timeout_Fault_status_after_qualification');
	EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $TimeoutsysWLAtFltQuali, '==', $tcpar_WL_Faultquali );
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $tcpar_Message_TimeoutFault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Timeout_Fault_status_after_dequalification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Timeout_Fault_DeQualiStatus ", 'PD_Timeout_Fault_status_after_dequalification');
	PD_check_fault_status($flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $tcpar_Message_TimeoutFault, $tcpar_Timeout_Fault_DeQualiStatus);			# Evalute the DTC Status after fault qualification
				
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $tcpar_Message_TimeoutFault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Timeout_Fault_status_after_dequalification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Timeout_Fault_CDDeQualiStatus ", 'CD_Timeout_Fault_status_after_dequalification');
	CD_check_fault_status($flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $tcpar_Message_TimeoutFault, $tcpar_Timeout_Fault_CDDeQualiStatus);
	
	S_teststep_detected("Detected Warning lamp status after timeout fault dequalification : $TimeoutsysWLAtFltdequali  ", 'WL_Timeout_Fault_status_after_dequalification');
	S_teststep_expected("Expected Warning lamp status after timeout fault dequalification: $tcpar_WL_FaultDequali ", 'WL_Timeout_Fault_status_after_dequalification');
	EVAL_evaluate_value( "System warning lamp status after timeout fault dequalification : ", $TimeoutsysWLAtFltdequali, '==', $tcpar_WL_Faultquali );
	
	#verifying PD and CD status after timeout fault dequali
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_signal_pd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Signal_Fault_status_after_TimeoutFltdequalification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Signal_Fault_QualiStatus ", 'PD_Signal_Fault_status_after_TimeoutFltdequalification');
	PD_check_fault_status($flt_mem_struct_signal_pd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_QualiStatus);			# Evalute the DTC Status after fault qualification
				
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_signal_cd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Signal_Fault_status_after_TimeoutFltdequalification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Signal_Fault_QualiStatus ", 'CD_Signal_Fault_status_after_TimeoutFltdequalification');
	CD_check_fault_status($flt_mem_struct_signal_cd_faultstatus_after_timeoutfltdequalification{'Signal_Fault_status_after_TimeoutFltdequalification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_QualiStatus);
		
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_signal_dequalification{'SignalFaultStatus_afterDequalification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_signal_Fault_status_after_dequalification');
	S_teststep_expected("Fault Status read by PD: $tcpar_Signal_Fault_DeQualiStatus ", 'PD_signal_Fault_status_after_dequalification');
	PD_check_fault_status($flt_mem_struct_pd_signal_dequalification{'SignalFaultStatus_afterDequalification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_DeQualiStatus);			# Evalute the DTC Status after fault qualification
				
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_signal_dequalification{'SignalFaultStatus_afterDequalification'}, $tcpar_Signal_Fault );        
	S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_signal_Fault_status_after_dequalification');
	S_teststep_expected("Fault Status read by CD: $tcpar_Signal_Fault_CDDeQualiStatus ", 'CD_signal_Fault_status_after_dequalification');
	CD_check_fault_status($flt_mem_struct_cd_signal_dequalification{'SignalFaultStatus_afterDequalification'}, $tcpar_Signal_Fault, $tcpar_Signal_Fault_CDDeQualiStatus);
	
	S_teststep_detected("Detected Warning lamp status after signal fault dequalification : $SignalsysWLAtFltdequali  ", 'WL_signal_Fault_status_after_dequalification');
	S_teststep_expected("Expected Warning lamp status after signal fault dequalification: $tcpar_WL_FaultDequali ", 'WL_signal_Fault_status_after_dequalification');
	EVAL_evaluate_value( "System warning lamp status after signal fault dequalification : ", $SignalsysWLAtFltdequali, '==', $tcpar_WL_FaultDequali );
	
	return 1;
}

sub TC_finalization {

	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
