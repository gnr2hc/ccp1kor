#### TEST CASE MODULE
package TC_COM_Shutdown_measurement;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_Shutdown_measurement.pm 1.1 2020/04/30 14:30:55ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<To measure the Autarchy time under different voltage conditions and different ECU modes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_Shutdown_measurement

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <Low_Volt>

 

3. Switch OFF the ECU.

4. Measure the time at which CAN transmission stops after ECU is powered OFF.

5.  Set the ECU Supply Voltage at <Normal_Volt>

 

6. Switch OFF the ECU.

7. Measure the time at which CAN transmission stops after ECU is powered OFF.

8.  Set the ECU Supply Voltage at <High_Volt>

 

9. Switch OFF the ECU.

10. Measure the time at which CAN transmission stops after ECU is powered OFF.

11.  Set the ECU Supply Voltage at <Over_Volt>

 

12. Switch OFF the ECU.

13. Measure the time at which CAN transmission stops after ECU is powered OFF.


I<B<Evaluation>>

1.

2.

3.

4. Measured time is <AutarchyTime_ms>.

5.

6.

7. Measured time is <AutarchyTime_ms>.

8.

9.

10. Measured time is <AutarchyTime_ms>.

11.

12.

13. Measured time is <AutarchyTime_ms>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'AutarchyTime_ms' => 
	SCALAR 'EnvVar_name' => 
	SCALAR 'Low_Volt' => 
	SCALAR 'Normal_Volt' => 
	SCALAR 'High_Volt' => 
	SCALAR 'Over_Volt' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	
	purpose = 'To measure the time at which CAN transmission stops after ECU is powered off'
	
	ECU_Mode = '<Test Heading 1>'
	AutarchyTime_ms = 'TBD' #ms
	EnvVar_name = 'Env_Dummy'
	Low_Volt = '8'#Volt
	Normal_Volt = '13'#Volt
	High_Volt = '18'#Volt
	Over_Volt = '20'#Volt

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_Mode;
my $tcpar_AutarchyTime_ms;
my @Initial_powon_time;
my @First_err_msg_rec_time;
my $TracePath;
my $tcpar_EnvVar_name;
my @Testcondition = ('8','13','20.5');

################ global parameter declaration ###################
#add any global variables here
my %MeasuredShutdownTime;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ECU_Mode =  GEN_Read_optional_testcase_parameter( 'ECU_Mode' );
	$tcpar_AutarchyTime_ms =  GEN_Read_mandatory_testcase_parameter( 'AutarkyTime_ms' );
	$tcpar_EnvVar_name =  GEN_Read_mandatory_testcase_parameter( 'EnvVar_name' );
	
	 unless( defined $tcpar_ECU_Mode ) {
  		S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  		$tcpar_ECU_Mode = 'NormalMode';
    };

	return 1;
}

sub TC_initialization {

    S_teststep("Standard_Preparation", 'NO_AUTO_NBR'); 
    CA_trace_start();	
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('IdleMode');
	}
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
		
	foreach my $condition (@Testcondition)
	{
		
		S_teststep("Set the ECU Supply Voltage at '$condition' volts", 'AUTO_NBR');
		LC_ECU_On($condition);
		S_wait_ms(10000);
		CA_trace_start();
		S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
		CA_set_EnvVar_value ($tcpar_EnvVar_name, 1 );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
		
		S_teststep("Measure the time at which CAN transmission stops after ECU is powered OFF.", 'AUTO_NBR',$condition);			#measurement 1
		$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 

		CA_trace_stop();
		
		open(FH,$TracePath) or die "Cant open $!";
		while(<FH>)
		{
			
			if($_ =~m/$tcpar_EnvVar_name/)
			{
				@Initial_powon_time = split(/\s+/,$_);
				S_w2rep("Power off timeline $_ ");
				S_w2rep("Power off timeline value $Initial_powon_time[1] ");
									
				while(<FH>)
				{
					if($_ =~/(\d+\.\d+)\s\d+\s(.*)\s+Rx/)		#	
					{											#	
						my $value = $2;							#
						$value=~s/^\s+//;						#
						$value=~s/\s+$//;						#
						S_w2rep("Detected ID's = $value ");		#
							
					}
					
					
					if($_ =~/ErrorFrame/) #ErrorFrame	ECC
					{
						S_w2rep("Trace shutdown delay time $_ ");
						@First_err_msg_rec_time = split(/\s+/,$_);
							S_w2rep("first error frame detected time  =  $First_err_msg_rec_time[1] ");
						last;
					}
				}
			}		
		}
		close(FH);
		
		$MeasuredShutdownTime{$condition} = (($First_err_msg_rec_time[1] - $Initial_powon_time[1])*1000);
		S_w2rep("Shut Down time is  $MeasuredShutdownTime{$condition} miliseconds");
	}
	return 1;
}

sub TC_evaluation {

	foreach my $condition (@Testcondition)
	{

		S_teststep_detected("Detected Autarchy time is : $MeasuredShutdownTime{$condition} ", $condition);
		S_teststep_expected("Expected Autarchy time is : $tcpar_AutarchyTime_ms ", $condition);	
		EVAL_evaluate_value ("Measured shutdown time  for the voltage condition $condition  is" , $MeasuredShutdownTime{$condition}, '>=',$tcpar_AutarchyTime_ms ); #evaluation 1
	}
	return 1;
}

sub TC_finalization {

	S_w2rep("TC FINALIZATION\n");

	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms (5000);
	}
	
	if($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms (5000);
	}
	
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
