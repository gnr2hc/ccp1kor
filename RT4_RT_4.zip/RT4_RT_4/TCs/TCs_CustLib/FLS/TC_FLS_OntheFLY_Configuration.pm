#### TEST CASE MODULE
package TC_FLS_OntheFLY_Configuration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_OntheFLY_Configuration.pm 1.1 2019/06/14 13:45:28ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use FuncLib_TNT_FM;

##################################

our $PURPOSE = "To check the behaviour of On the Fly Configuration of Squibs";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_OntheFLY_Configuration

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Power On the ECU and check for Fault free system <FLTmand>.

2. Read the Squib <Squib> configuration.

3. Set configuration bit of Squib <Squib> to <value>.

4. Reset the ECU.

5. Read the fault recorder


I<B<Evaluation>>

1. System is fault free.

2. The <Squib>configuration is equal to<configured>.

5. Fault <Fault> is present in the fault recorder in qualified state.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Squib' => 
	HASH 'FLTmand' => 
	SCALAR 'Fault' => 
	SCALAR 'value' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'to check the behaviour of On the Fly Configuration of Squib'
	
	Squib = '<Test Heading 1>'
	FLTmand = %() #no fault
	Fault = 'rb_sqm_Unexpected'
	value = 'clear'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Squib;
my $tcpar_FLTmand;
my $tcpar_Fault;
my $tcpar_value;
my $tcpar_configured;

################ global parameter declaration ###################
#add any global variables here
my $Status_FaultQualified;
my $Const_sqm_DEVICE1_NAME;
my $Squib_configured;
my $valid;
my $flt_mem_struct;
my $verdict;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose    = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Squib      = S_read_mandatory_testcase_parameter('Squib');
	$tcpar_FLTmand    = S_read_mandatory_testcase_parameter('FLTmand');
	$tcpar_Fault      = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_value      = S_read_mandatory_testcase_parameter('value');
	$tcpar_configured = S_read_mandatory_testcase_parameter('configured');

	$Const_sqm_DEVICE1_NAME = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_Squib);
	$Status_FaultQualified  = '0bxxxxx1x1';

	unless ( defined $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE1_NAME ne '' and $Const_sqm_DEVICE1_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;
		return 1;
	}
	return 1;
}

sub TC_initialization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {

		#before proceeding check if a valid device is configured for both
		$valid = CheckValidDevice();
		if ( $valid == 0 ) {
			S_set_error("Valid squib is not configured for one of the squib lines.\n");
			return 1;
		}
		S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
		GEN_StandardPrepNoFault();
	}
	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "Power On the ECU and check for Fault free system '$tcpar_FLTmand'.", 'AUTO_NBR', 'power_on_the' );    #measurement 1
		my $faultsBeforeStimulation = PD_ReadFaultMemory();
		my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );

		S_teststep( "Read the Squib $tcpar_Squib configuration.", 'AUTO_NBR' );
		( my $Real1, my $Monitored_ID1, $Squib_configured ) = PD_get_device_config($Const_sqm_DEVICE1_NAME);
		S_w2rep( "Squib_configured $Squib_configured", 'AUTO_NBR' );

		S_teststep( "Set configuration bit of Squib $tcpar_Squib to $tcpar_value.", 'AUTO_NBR' );
		if ( $Squib_configured != $tcpar_configured ) {
			S_set_error("Valid squib is not configured for one of the squib lines.\n");
			return 1;
		}
		else {
			my $config = PD_Device_configuration( $tcpar_value, [$Const_sqm_DEVICE1_NAME] );
			PD_ECUlogin();
			S_teststep( "Reset the ECU.", 'AUTO_NBR' );
			PD_ECUreset();
			S_wait_ms(6000);
		}

		S_teststep( "Read the fault recorder", 'AUTO_NBR', 'read_the_fault' );    #measurement 2
		$flt_mem_struct = PD_ReadFaultMemory();
	}
	return 1;
}

sub TC_evaluation {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		my $ConditionToCreate = $tcpar_Fault . $Const_sqm_DEVICE1_NAME . '_flt';
		my $fault_status = PD_get_fault_status( $flt_mem_struct, $ConditionToCreate );
		S_w2rep( "config '$fault_status'", 'AUTO_NBR' );
		FM_checkFaultStatus( $flt_mem_struct, $ConditionToCreate, $Status_FaultQualified );
	}
	return 1;
}

sub TC_finalization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		PD_Device_configuration( 'set', [$Const_sqm_DEVICE1_NAME] );
		S_wait_ms(6000);
		PD_ECUreset();
		S_wait_ms(6000);

		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $FLT_final = PD_ReadFaultMemory();

		S_wait_ms('TIMER_ECU_READY');

		my $faultsVerdict_final = FM_evaluateFaults( $FLT_final, [] );
	}
	return 1;
}

sub CheckValidDevice {

	my $check_mapping = 1;

	unless ( defined $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE1_NAME ne '' and $Const_sqm_DEVICE1_NAME ne 'NONE' ) {
		$check_mapping = 0;
	}

	return $check_mapping;    #valid device name is present

}

1;
