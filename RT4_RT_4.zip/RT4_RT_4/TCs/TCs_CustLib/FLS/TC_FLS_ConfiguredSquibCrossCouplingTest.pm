#### TEST CASE MODULE
package TC_FLS_ConfiguredSquibCrossCouplingTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_ConfiguredSquibCrossCouplingTest.pm 1.1 2019/06/14 13:45:27ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.94
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use FuncLib_SYC_INTERFACE;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_TSG4;
##################################

our $PURPOSE = "to check cross coupling of squibs";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_ConfiguredSquibCrossCouplingTest

=head1 PURPOSE

to check cross coupling of squibs

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create a short between high side terminal of one squib to the low side terminal of other squib for <Pins>(cross couple)

2. Read fault recorder

3. Reset ECU and read the fault recorder after init.


I<B<Evaluation>>

2. Cross coupling fault <Fault> is not qualified for <Pins> crosscoupled and no other faults are qualified

3. Squib cross coupling fault <Fault> is qualified for <Pins> crosscoupled and no other faults are qualified


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Pins' => 
	SCALAR 'purpose' => 
	SCALAR 'Fault' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'to check cross coupling of squibs'
	
	Fault = 'rb_sqm_Crosscoupling'
	Pins = @('<Test Heading 1>+','<Test Heading 2>-')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Fault;
my @tcpar_Pins;

################ global parameter declaration ###################
#add any global variables here
my %squib_name;
my %squib_pin;
my @short_pin;
my %squib_fault;
my @fault_arr;
my %faut_struct;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_Fault   = GEN_Read_mandatory_testcase_parameter('Fault');
	@tcpar_Pins    = GEN_Read_mandatory_testcase_parameter('Pins');

	foreach my $squib_nbr (@tcpar_Pins) {
		my $temp = $squib_nbr;
		$squib_nbr =~ s/SQ(\d+)(.)/SQ$1/;
		my $squib_index = $2;
		$squib_name{$temp}  = DEVICE_fetchDeviceNamebyDeviceNumber($squib_nbr);
		$squib_fault{$temp} = $tcpar_Fault . $squib_name{$temp} . '_flt';
		$squib_pin{$temp}   = $squib_name{$temp} . $squib_index;
	}

	@short_pin = values %squib_pin;
	@fault_arr = values %squib_fault;

	S_w2rep("Squib pin: @short_pin");
	S_w2rep("Fault: @fault_arr");

	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	if ( $TestHW eq 'MLC' ) {
		S_set_error("Cannot testing this TCD on MLC device");
		return 0;
	}

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Create a short between high side terminal of one squib to the low side terminal of other squib for '@short_pin'(cross couple)", 'AUTO_NBR' );
	LC_ShortLines( \@short_pin );

	S_teststep( "Read fault recorder", 'AUTO_NBR', 'read_fault_recorder' );    #measurement 1
	$faut_struct{'before_reset'} = FM_PD_readFaultMemory();
	FM_evaluateFaults( $faut_struct{'before_reset'}, [] );

	S_teststep( "Reset ECU and read the fault recorder after init.", 'AUTO_NBR', 'reset_ecu_and' );    #measurement 2
	LC_ECU_Reset();
	$faut_struct{'after_reset'} = FM_PD_readFaultMemory();
	FM_evaluateFaults( $faut_struct{'after_reset'}, \@fault_arr );

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Cross coupling fault '@fault_arr' is not qualified for '@short_pin' crosscoupled and no other faults are qualified", 'read_fault_recorder' );    #evaluation 1
	S_teststep_detected( "Done in TC_stimulation_and_measurement", 'read_fault_recorder' );

	S_teststep_expected( "Squib cross coupling fault '$tcpar_Fault' is qualified for '@short_pin' crosscoupled and no other faults are qualified", 'reset_ecu_and' );      #evaluation 2
	S_teststep_detected( "Done in TC_stimulation_and_measurement", 'reset_ecu_and' );
	return 1;
}

sub TC_finalization {
	LC_UndoShortLines();
	LC_ECU_Reset();

	PD_ClearFaultMemory();
	$faut_struct{'empty_expect'} = FM_PD_readFaultMemory();
	FM_evaluateFaults( $faut_struct{'empty_expect'}, [] );

	return 1;
}

1;
