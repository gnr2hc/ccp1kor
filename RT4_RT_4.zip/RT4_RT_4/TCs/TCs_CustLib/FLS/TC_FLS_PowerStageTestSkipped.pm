#### TEST CASE MODULE
package TC_FLS_PowerStageTestSkipped;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: FLS/TC_FLS_PowerStageTestSkipped.pm 1.3 2019/12/09 13:51:50ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

# ----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_general;
use LIFT_labcar;
use LIFT_spi_access;
use LIFT_TSG4;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_spi_access;
use FuncLib_TNT_GEN;
use Data::Dumper;
$Data::Dumper::Sortkeys = 1;    #Sort the keys in the output
use LIFT_manitoo;

##################################

our $PURPOSE = "to check the power stage test under abnormal conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_PowerStageTest

=head1 PURPOSE

<to check the power stage test under normal conditions>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Create <condition>


I<B<Stimulation and Measurement>>

1. Check the ITM test status for test.

2. Read the fault recorder

3. Create <condition>.

4. Reset the ECU and Monitor_SPI during initialization

5. Check the sequence of SPI commands

6.  Check the ITM test status for test.

7. Read the fault recorder.


I<B<Evaluation>>

1. <PD_ITMTestStarted>, <PD_ITMTestFinished>, <PD_ITMTestSkipped>, <PD_ITMTestFailed> with value  

<ITM_TestStarted>

<ITM_TestFinished>

<ITM_TestFailed>

<ITM_TestSkipped> in the bit  <itm_TestBit_SVR_OFFtest> and <itm_TestBit_SquibPstHSTest>

2. No fault is qualified

5. The expected sequence of commands are sent.

6. <PD_ITMTestStarted>, <PD_ITMTestFinished>, <PD_ITMTestSkipped>, <PD_ITMTestFailed> with value  

<ITM_TestStarted_init>

<ITM_TestFinished_init>

<ITM_TestFailed_init>

<ITM_TestSkipped_init>

  in the bit  <itm_TestBit_SVR_OFFtest> and <itm_TestBit_SquibPstHSTest>

7. No fault is qualified


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'trace_capture' => 
	LIST '_SPI_EvalSignal1_T1' => 
	SCALAR 'purpose' => 
	SCALAR 'condition' => 
	SCALAR 'squib' => 
	SCALAR 'PD_ITMTestStarted' => 
	SCALAR 'PD_ITMTestFinished' => 
	SCALAR 'PD_ITMTestSkipped' => 
	SCALAR 'PD_ITMTestFailed' => 
	SCALAR 'itm_TestBit_SVR_OFFtest' => 
	SCALAR 'SVR_offset' => 
	SCALAR 'SVR_byte' => 
	SCALAR 'SVR_mask' => 
	SCALAR 'itm_TestBit_SquibPstHSTest' => 
	SCALAR 'HSPST_offset' => 
	SCALAR 'HSPST_byte' => 
	SCALAR 'HSPST_mask' => 
	SCALAR 'itm_TestStarted' => 
	SCALAR 'itm_TestFinished' => 
	SCALAR 'itm_TestFailed' => 
	SCALAR 'itm_TestSkipped' => 
	SCALAR 'itm_TestStarted_init' => 
	SCALAR 'itm_TestFinished_init' => 
	SCALAR 'itm_TestFailed_init' => 
	SCALAR 'itm_TestSkipped_init' => 
	SCALAR 'USE_SPI_RECORD' => 
	LIST '_SPI_Node' => 
	SCALAR 'USE_SPI_EVAL' => 
	LIST '_SPI_GetTime_T1' => 
	LIST '_SPI_GetTime_T2' => 
	LIST '_SPI_EvalTime0_T1' => 
	LIST '_SPI_EvalSignal0_T1' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check the High side power stage test under normal conditions'
	condition = 'normal' #normal condition
	squib = '<Test Heading 1>'
	#manual testing
	#mode_mask = '0bxxxxxxx0xxxx0011' #HS PST mode
	#SDIS_mask = '0bxxxxxxxxxxxx0000' #SDIS are enabled
	#VEL_bit = '0bxxxxxxxxxxxxxxx1' #VEL bit is low
	#d5_DIS_AHP_mask = '0bxxxxxxxxxx0xxxxx' #enabled
	#d6_DIS_ALP_mask = '0bxxxxxxxxx1xxxxxx' #disabled
	#ul_mask  = '0bxxxxxxx00xxxxxxx' #HS and LS locked
	#run_mask = '0bxxxxx0xxxxxxxxxx' #no test running
	#tso_mask = '0bxxxx1xxxxxxxxxxx' #PST mode active
	#EOP_MISOmask = '0bxxxxxxxxxxxxxx01' #EOP1 is done
	#diag_result_mask = '0bxxxx0xxxxxxx0001' #PST OK
	#ITM Variables
	PD_ITMTestStarted = 'rb_itm_TestStarted_u64'
	PD_ITMTestFinished = 'rb_itm_TestFinished_u64'
	PD_ITMTestSkipped = 'rb_itm_TestSkipped_u64'
	PD_ITMTestFailed = 'rb_itm_TestFailed_u64'
	#ITM test status
	itm_TestBit_SVR_OFFtest = '42' 
	SVR_offset = '6'
	SVR_byte ='1'
	SVR_mask = '0bx1xx'
	itm_TestBit_SquibPstHSTest = '12'
	HSPST_offset = '-4'
	HSPST_byte ='1'
	HSPST_mask = '0bxxx1'
	#rb_itm_SquibPstHSTest_e
	itm_TestStarted = 1
	itm_TestFinished = 1
	itm_TestFailed = 0
	itm_TestSkipped = 0
	itm_TestStarted_init = 1
	itm_TestFinished_init = 1
	itm_TestFailed_init = 0
	itm_TestSkipped_init = 0
	USE_SPI_RECORD 		= 'yes'
	_SPI_Node			= @('CG904_M', 'CG904_S')
	USE_SPI_EVAL            = 'yes'
	_SPI_GetTime_T1  = @('T0', 'CG904 M::FLM_START_DIAG::MISO::d5', '==', '0x0') 
	_SPI_GetTime_T2  = @('T1', 'CG904_M::EOP::MISO::EOP1', '==', '0x1')  
	 _SPI_EvalTime0_T1       = @('T2', '>=', 1990, '<=', 2070)  
	_SPI_EvalSignal0_T1    = @('I_T1T2', 'CG904_M::FLM_START_DIAG::MOSI::mode', '==', '0x3',  'CG904_S::FLM_START_DIAG::MOSI::mode', '==', '0x3', 'CG904_M::POM_STATUS::MISO::vel', '==', '0x0',  'CG904_M::FLM_READ_VH::MISO::adc_data', '>=', '0x187', 'CG904_M::FLM_STATUS::MISO::d0', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d1', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d2', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d3', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d4', '>=', '0x1','CG904_M::FLM_STATUS::MISO::d5', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d6', '>=', '0x1','>=',1)
	#conf_mask = '0bxxxxxxxx0000xxxx'
	
	trace_capture = '1'
	
	_SPI_EvalSignal1_T1    = @('I_T1T2', 'CG904_M::FLM_START_DIAG::MOSI::conf', '==', '0x0','==',1)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_condition;
my $tcpar_squib;
my $tcpar_PD_ITMTestStarted;
my $tcpar_PD_ITMTestFinished;
my $tcpar_PD_ITMTestSkipped;
my $tcpar_PD_ITMTestFailed;
my $tcpar_itm_TestBit_SVR_OFFtest;
my $tcpar_SVR_offset;
my $tcpar_SVR_byte;
my $tcpar_SVR_mask1;
my $tcpar_SVR_mask0;

my $tcpar_itm_TestBit_SquibPstTest;
my $tcpar_PST_offset;
my $tcpar_PST_byte;
my $tcpar_PST_mask1;
my $tcpar_PST_mask0;
my $tcpar_path;

my $tcpar_itm_TestStarted;
my $tcpar_itm_TestFinished;
my $tcpar_itm_TestFailed;
my $tcpar_itm_TestSkipped;
my $tcpar_itm_TestStarted_init;
my $tcpar_itm_TestFinished_init;
my $tcpar_itm_TestFailed_init;
my $tcpar_itm_TestSkipped_init;

################ global parameter declaration ###################
#add any global variables here
my $Const_sqm_DEVICE_NAME;
my $check_mapping;
my $check_conf;
my $itmstarted;
my $itmfinished;
my $itmskipped;
my $itmfailed;
my $itmstarted_PST;
my $itmfinished_PST;
my $itmskipped_HSPST;
my $itmfailed_PST;
my $itmstarted_final;
my $itmfinished_final;
my $itmskipped_final;
my $itmfailed_final;
my $itmstarted_PST_final;
my $itmfinished_PST_final;
my $itmskipped_PST_final;
my $itmfailed_PST_final;
my $faultsafterStimulation;
my $faultsBeforeStimulation;
my $verdict;
my $tcpar_PST_mask2;
my $tcpar_SVR_mask2;
my $tcpar_Fault;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose                  = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_condition                = S_read_mandatory_testcase_parameter('condition');
	$tcpar_squib                    = S_read_mandatory_testcase_parameter('squib');
	$tcpar_PD_ITMTestStarted        = S_read_mandatory_testcase_parameter('PD_ITMTestStarted');
	$tcpar_PD_ITMTestFinished       = S_read_mandatory_testcase_parameter('PD_ITMTestFinished');
	$tcpar_PD_ITMTestSkipped        = S_read_mandatory_testcase_parameter('PD_ITMTestSkipped');
	$tcpar_PD_ITMTestFailed         = S_read_mandatory_testcase_parameter('PD_ITMTestFailed');
	$tcpar_itm_TestBit_SVR_OFFtest  = S_read_mandatory_testcase_parameter('itm_TestBit_SVR_OFFtest');
	$tcpar_SVR_offset               = S_read_mandatory_testcase_parameter('SVR_offset');
	$tcpar_SVR_byte                 = S_read_mandatory_testcase_parameter('SVR_byte');
	$tcpar_SVR_mask1                = S_read_mandatory_testcase_parameter('SVR_mask1');
	$tcpar_SVR_mask0                = S_read_mandatory_testcase_parameter('SVR_mask0');
	$tcpar_SVR_mask2                = S_read_optional_testcase_parameter('SVR_mask2');
	$tcpar_itm_TestBit_SquibPstTest = S_read_mandatory_testcase_parameter('itm_TestBit_SquibPstTest');
	$tcpar_PST_offset               = S_read_mandatory_testcase_parameter('PST_offset');
	$tcpar_PST_byte                 = S_read_mandatory_testcase_parameter('PST_byte');
	$tcpar_PST_mask1                = S_read_mandatory_testcase_parameter('PST_mask1');
	$tcpar_PST_mask0                = S_read_mandatory_testcase_parameter('PST_mask0');
	$tcpar_PST_mask2                = S_read_optional_testcase_parameter('PST_mask2');
	$tcpar_Fault                    = S_read_optional_testcase_parameter('Fault');
	$tcpar_itm_TestStarted          = S_read_mandatory_testcase_parameter('itm_TestStarted');
	$tcpar_itm_TestFinished         = S_read_mandatory_testcase_parameter('itm_TestFinished');
	$tcpar_itm_TestFailed           = S_read_mandatory_testcase_parameter('itm_TestFailed');
	$tcpar_itm_TestSkipped          = S_read_mandatory_testcase_parameter('itm_TestSkipped');
	$tcpar_itm_TestStarted_init     = S_read_mandatory_testcase_parameter('itm_TestStarted_init');
	$tcpar_itm_TestFinished_init    = S_read_mandatory_testcase_parameter('itm_TestFinished_init');
	$tcpar_itm_TestFailed_init      = S_read_mandatory_testcase_parameter('itm_TestFailed_init');
	$tcpar_itm_TestSkipped_init     = S_read_mandatory_testcase_parameter('itm_TestSkipped_init');

	$Const_sqm_DEVICE_NAME = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_squib);

	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;
	}

	return 1;
}

sub TC_initialization {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_w2rep( 'StandardPrepNoFault', 'blue' );
		GEN_StandardPrepNoFault();
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {

		S_teststep( "Check the ITM test status for test before create fault", 'AUTO_NBR' );    #measurement 1
		$itmstarted = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );
		$itmskipped  = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		$itmstarted_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_HSPST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		S_teststep( "Read the fault recorder before create fault", 'AUTO_NBR', 'read_the_fault_A' );    #measurement 2
		$faultsBeforeStimulation = FM_PD_readFaultMemory();

		S_teststep( "Create '$tcpar_condition' for $Const_sqm_DEVICE_NAME", 'AUTO_NBR' );
		if ( $tcpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) {

			my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
			if ( $TestHW eq 'MLC' ) {
				S_set_error("Cannot set highside on MLC device");
				return 0;
			}
			else {
				TSG4_ConnectSquibToOpAmp( $Const_sqm_DEVICE_NAME . "+", 3 );
			}
		}
		elsif ( $tcpar_condition eq 'FaultySVR' ) {
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => 'FLM_READ_SVR',
				'Signal'      => '| adc_data: 0x',
				'SignalValue' => '0xFF',
			);
			SPI_start_manipulation();
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_READY');
			S_wait_ms(2000);
		}
		else {
			my $conditionstatus = DEVICE_setSquibTestCondition( $Const_sqm_DEVICE_NAME, $tcpar_condition );

			unless ( defined $conditionstatus and $conditionstatus == 1 ) {
				S_w2rep( "Condition is not created successfully! Not proceeding", 'red' );
				$PURPOSE = "Condition is not created successfully";
				return 0;
			}
		}

		LC_ECU_Reset();

		S_w2rep( "Check fault exist in LIFT report \n", 'red' );
		$faultsafterStimulation = FM_PD_readFaultMemory();

		#		S_teststep( "Check the ITM test status for test after fault creation", 'AUTO_NBR' );    #measurement 4
		$itmstarted_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		$itmstarted_PST_final  = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );
		$itmfinished_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

	}
	return 1;
}

sub TC_evaluation {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		my $bin_value;

		S_w2log( HTML, "<font size=5>" );    # print only to HTML test report
		S_w2rep( "----------------------------- Check SVR bit init -----------------------------", 'purple' );
		S_w2log( HTML, "<font size=3>" );    # print only to HTML test report

		my $itmstarted_byte = S_hex2dec( substr( $itmstarted, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		$bin_value = S_dec2bin($itmstarted_byte);
		S_teststep_expected("the SVR test started bit: $tcpar_SVR_mask1");    #evaluation 1
		S_teststep_detected("the SVR test started bit: 0b$bin_value");
		EVAL_evaluate_value( "read the SVR test started bit", $itmstarted_byte, 'MASK', $tcpar_SVR_mask1 );

		my $itmfinished_byte = S_hex2dec( substr( $itmfinished, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		$bin_value = S_dec2bin($itmfinished_byte);
		S_teststep_expected("the SVR test finished bit: $tcpar_SVR_mask1");    #evaluation 1
		S_teststep_detected("the SVR test finished bit: 0b$bin_value");
		EVAL_evaluate_value( "read the SVR test finished bit", $itmfinished_byte, 'MASK', $tcpar_SVR_mask1 );

		my $itmskipped_byte = S_hex2dec( substr( $itmskipped, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		$bin_value = S_dec2bin($itmskipped_byte);
		S_teststep_expected("The SVR test skipped bit: $tcpar_SVR_mask0");     #evaluation 1
		S_teststep_detected("The SVR test skipped bit: 0b$bin_value");
		EVAL_evaluate_value( "read the SVR test skipped bit", $itmskipped_byte, 'MASK', $tcpar_SVR_mask0 );

		my $itmfailed_byte = S_hex2dec( substr( $itmfailed, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		$bin_value = S_dec2bin($itmfailed_byte);
		S_teststep_expected("the SVR test failed bit: $tcpar_SVR_mask0");      #evaluation 1
		S_teststep_detected("the SVR test failed bit: 0b$bin_value");
		EVAL_evaluate_value( "read the SVR test failed bit", $itmfailed_byte, 'MASK', $tcpar_SVR_mask0 );

		S_w2log( HTML, "<font size=5>" );                                      # print only to HTML test report
		S_w2rep( "----------------------------- Check PST test bit init -----------------------------", 'purple' );
		S_w2log( HTML, "<font size=3>" );                                      # print only to HTML test report

		my $itmstarted_byte_PST = S_hex2dec( substr( $itmstarted_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		$bin_value = S_dec2bin($itmstarted_byte_PST);
		S_teststep_expected("the HSPST test started bit: $tcpar_PST_mask1");    #evaluation 1
		S_teststep_detected("the HSPST test started bit: 0b$bin_value");
		EVAL_evaluate_value( "read the HSPST test started bit", $itmstarted_byte_PST, 'MASK', $tcpar_PST_mask1 );

		my $itmfinished_byte_PST = S_hex2dec( substr( $itmfinished_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		$bin_value = S_dec2bin($itmfinished_byte_PST);
		S_teststep_expected("the HSPST test finished bit: $tcpar_PST_mask1");    #evaluation 1
		S_teststep_detected("the HSPST test finished bit: 0b$bin_value");
		EVAL_evaluate_value( "read the HSPST test finished bit", $itmfinished_byte_PST, 'MASK', $tcpar_PST_mask1 );

		my $itmskipped_byte_HSPST = S_hex2dec( substr( $itmskipped_HSPST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		$bin_value = S_dec2bin($itmskipped_byte_HSPST);
		S_teststep_expected("the HSPST test skipped bit: $tcpar_PST_mask0");     #evaluation 1
		S_teststep_detected("the HSPST test skipped bit: 0b$bin_value");
		EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_HSPST, 'MASK', $tcpar_PST_mask0 );

		my $itmfailed_byte_PST = S_hex2dec( substr( $itmfailed_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		$bin_value = S_dec2bin($itmfailed_byte_PST);
		S_teststep_expected("the HSPST test failed bit: $tcpar_PST_mask0");      #evaluation 1
		S_teststep_detected("the HSPST test failed bit: 0b$bin_value");
		EVAL_evaluate_value( "read the HSPST test failed bit", $itmfailed_byte_PST, 'MASK', $tcpar_PST_mask0 );

		unless ( $tcpar_condition eq 'SquibNotMonitored' ) {

			S_w2log( HTML, "<font size=5>" );                                    # print only to HTML test report
			S_w2rep( "----------------------------- Check SVR bit after create condtion -----------------------------", 'purple' );
			S_w2log( HTML, "<font size=3>" );                                    # print only to HTML test report

			my $itmstarted_byte_final = S_hex2dec( substr( $itmstarted_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmstarted_byte_final);
			S_teststep_expected("the SVR test started bit: $tcpar_SVR_mask1");    #evaluation 1
			S_teststep_detected("the SVR test started bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test started bit", $itmstarted_byte_final, 'MASK', $tcpar_SVR_mask1 );

			my $itmfinished_byte_final = S_hex2dec( substr( $itmfinished_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmfinished_byte_final);
			S_teststep_expected("the SVR test finished bit: $tcpar_SVR_mask1");    #evaluation 1
			S_teststep_detected("the SVR test finished bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test finished bit", $itmfinished_byte_final, 'MASK', $tcpar_SVR_mask1 );

			my $itmskipped_byte_final = S_hex2dec( substr( $itmskipped_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmskipped_byte_final);
			S_teststep_expected("the SVR test skipped bit: $tcpar_SVR_mask0");     #evaluation 1
			S_teststep_detected("the SVR test skipped bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test skipped bit", $itmskipped_byte_final, 'MASK', $tcpar_SVR_mask0 );

			my $itmfailed_byte_final = S_hex2dec( substr( $itmfailed_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmfailed_byte_final);
			S_teststep_expected("the SVR test failed bit: $tcpar_SVR_mask0");      #evaluation 1
			S_teststep_detected("the SVR test failed bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test failed bit", $itmfailed_byte_final, 'MASK', $tcpar_SVR_mask0 );

			S_w2log( HTML, "<font size=5>" );                                      # print only to HTML test report
			S_w2rep( "----------------------------- Check PST test bit after create condtion -----------------------------", 'purple' );
			S_w2log( HTML, "<font size=3>" );                                      # print only to HTML test report

			my $itmstarted_byte_PST_final = S_hex2dec( substr( $itmstarted_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmstarted_byte_PST_final);
			S_teststep_expected("the HSPST test started bit: $tcpar_PST_mask1");    #evaluation 1
			S_teststep_detected("the HSPST test started bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test started bit", $itmstarted_byte_PST_final, 'MASK', $tcpar_PST_mask1 );

			my $itmfinished_byte_PST_final = S_hex2dec( substr( $itmfinished_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmfinished_byte_PST_final);
			S_teststep_expected("the HSPST test finished bit: $tcpar_PST_mask1");    #evaluation 1
			S_teststep_detected("the HSPST test finished bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test finished bit", $itmfinished_byte_PST_final, 'MASK', $tcpar_PST_mask1 );

			if ( defined $tcpar_Fault and ( $tcpar_Fault =~ /PST/ ) ) {
				S_w2rep( "add more step evaluate fault for powerstate fault \n", 'green' );
				$tcpar_Fault = 'rb_sqm_HighsidePowerstage' . $Const_sqm_DEVICE_NAME . '_flt';
				FM_evaluateFaults( $faultsafterStimulation, [$tcpar_Fault] );

				my $itmskipped_byte_PST_final = S_hex2dec( substr( $itmskipped_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
				$bin_value = S_dec2bin($itmskipped_byte_PST_final);
				S_teststep_expected("the HSPST test skipped bit: $tcpar_PST_mask0");    #evaluation 1
				S_teststep_detected("the HSPST test skipped bit: 0b$bin_value");
				EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_PST_final, 'MASK', $tcpar_PST_mask0 );
			}
			else {
				my $itmskipped_byte_PST_final = S_hex2dec( substr( $itmskipped_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
				$bin_value = S_dec2bin($itmskipped_byte_PST_final);
				S_teststep_expected("the HSPST test skipped bit: $tcpar_PST_mask1");    #evaluation 1
				S_teststep_detected("the HSPST test skipped bit: 0b$bin_value");
				if ( defined $tcpar_PST_mask2 ) {
					EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_PST_final, 'MASK', $tcpar_PST_mask2 );
				}
				else {
					EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_PST_final, 'MASK', $tcpar_PST_mask1 );
				}
				if ( defined $tcpar_Fault and ( $tcpar_Fault =~ /rb_svr/ ) ) {
					S_w2rep( "add more step evaluate fault for SVR fault \n", 'green' );
					FM_evaluateFaults( $faultsafterStimulation, [$tcpar_Fault] );
				}
			}
			my $itmfailed_byte_PST_final = S_hex2dec( substr( $itmfailed_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmfailed_byte_PST_final);
			S_teststep_expected("the HSPST test failed bit: $tcpar_PST_mask0");    #evaluation 1
			S_teststep_detected("the HSPST test failed bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test failed bit", $itmfailed_byte_PST_final, 'MASK', $tcpar_PST_mask0 );

		}
		else {

			S_w2log( HTML, "<font size=5>" );                                      # print only to HTML test report
			S_w2rep( "----------------------------- Check SVR bit after create condtion -----------------------------", 'purple' );
			S_w2log( HTML, "<font size=3>" );                                      # print only to HTML test report

			S_w2rep( "For condition not monitoring, not bit was set \n", 'green' );
			my $itmstarted_byte_final = S_hex2dec( substr( $itmstarted_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmstarted_byte_final);
			S_teststep_expected("the SVR test started bit: $tcpar_SVR_mask2");     #evaluation 1
			S_teststep_detected("the SVR test started bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test started bit", $itmstarted_byte_final, 'MASK', $tcpar_SVR_mask2 );

			my $itmfinished_byte_final = S_hex2dec( substr( $itmfinished_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmfinished_byte_final);
			S_teststep_expected("the SVR test finished bit: $tcpar_SVR_mask2");    #evaluation 1
			S_teststep_detected("the SVR test finished bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test finished bit", $itmfinished_byte_final, 'MASK', $tcpar_SVR_mask2 );

			my $itmskipped_byte_final = S_hex2dec( substr( $itmskipped_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmskipped_byte_final);
			S_teststep_expected("the SVR test skipped bit: $tcpar_SVR_mask2");     #evaluation 1
			S_teststep_detected("the SVR test skipped bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test skipped bit", $itmskipped_byte_final, 'MASK', $tcpar_SVR_mask2 );

			my $itmfailed_byte_final = S_hex2dec( substr( $itmfailed_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
			$bin_value = S_dec2bin($itmfailed_byte_final);
			S_teststep_expected("the SVR test failed bit: $tcpar_SVR_mask2");      #evaluation 1
			S_teststep_detected("the SVR test failed bit: 0b$bin_value");
			EVAL_evaluate_value( "read the SVR test failed bit", $itmfailed_byte_final, 'MASK', $tcpar_SVR_mask2 );

			S_w2log( HTML, "<font size=5>" );                                      # print only to HTML test report
			S_w2rep( "----------------------------- Check PST test bit after create condtion -----------------------------", 'purple' );
			S_w2log( HTML, "<font size=3>" );                                      # print only to HTML test report
			my $itmstarted_byte_PST_final = S_hex2dec( substr( $itmstarted_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmstarted_byte_PST_final);
			S_teststep_expected("the HSPST test started bit: $tcpar_PST_mask2");    #evaluation 1
			S_teststep_detected("the HSPST test started bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test started bit", $itmstarted_byte_PST_final, 'MASK', $tcpar_PST_mask2 );

			my $itmfinished_byte_PST_final = S_hex2dec( substr( $itmfinished_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmfinished_byte_PST_final);
			S_teststep_expected("the HSPST test finished bit: $tcpar_PST_mask2");    #evaluation 1
			S_teststep_detected("the HSPST test finished bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test finished bit", $itmfinished_byte_PST_final, 'MASK', $tcpar_PST_mask2 );

			my $itmskipped_byte_PST_final = S_hex2dec( substr( $itmskipped_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmskipped_byte_PST_final);
			S_teststep_expected("the HSPST test skipped bit: $tcpar_PST_mask2");     #evaluation 1
			S_teststep_detected("the HSPST test skipped bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_PST_final, 'MASK', $tcpar_PST_mask2 );

			my $itmfailed_byte_PST_final = S_hex2dec( substr( $itmfailed_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
			$bin_value = S_dec2bin($itmfailed_byte_PST_final);
			S_teststep_expected("the HSPST test failed bit: $tcpar_PST_mask2");      #evaluation 1
			S_teststep_detected("the HSPST test failed bit: 0b$bin_value");
			EVAL_evaluate_value( "read the HSPST test failed bit", $itmfailed_byte_PST_final, 'MASK', $tcpar_PST_mask2 );
		}

	}
	return 1;
}

sub TC_finalization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		if ( $tcpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) {
			my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
			if ( $TestHW eq 'MLC' ) {
				S_set_error("Cannot set highside on MLC device");
				return 0;
			}
			else {
				LC_ShortLines( [ $Const_sqm_DEVICE_NAME . '-', 'B+' ] );
				S_wait_ms(5000);
				LC_UndoShortLines();
				S_wait_ms(1000);
				TSG4_DisconnectSquibFromOpAmp($Const_sqm_DEVICE_NAME);
				LC_ECU_Reset();    # cross coupling is an Init fault
			}
		}
		elsif ( $tcpar_condition eq 'FaultySVR' ) {
			SPI_stop_manipulation();
			LC_ECU_Reset();
		}
		else {

			DEVICE_resetSquibTestCondition( $Const_sqm_DEVICE_NAME, $tcpar_condition );
			S_wait_ms(3000);
		}
		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms(5000);

		my $FLT_final = FM_PD_readFaultMemory();
		FM_evaluateFaults( $FLT_final, [] );
	}
	return 1;
}

sub CheckValidDevice {

	my $mapping = 1;

	# my $configured = 1;

	unless (defined $Const_sqm_DEVICE_NAME
		and $Const_sqm_DEVICE_NAME ne ''
		and $Const_sqm_DEVICE_NAME ne 'NONE' )
	{
		$mapping = 0;
	}

	return ($mapping);    #valid device name is present
}

1;
