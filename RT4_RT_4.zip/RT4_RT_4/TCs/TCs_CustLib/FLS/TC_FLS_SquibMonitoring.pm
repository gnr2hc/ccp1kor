#### TEST CASE MODULE
package TC_FLS_SquibMonitoring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_SquibMonitoring.pm 1.1 2019/06/14 13:45:29ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;
##################################

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use FuncLib_SYC_INTERFACE;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_spi_access;
use LIFT_labcar;
use LIFT_TSG4;
##################################
our $PURPOSE = "Checks the Squib Monitoring related requirements";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_SquibMonitoring  $Revision: 1.1 $


=head1 PURPOSE

to check the squib monitoring requirements

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

StandardPrepNoFault

I<B<Stimulation and Measurement>>

1. Create condition

2. Create fault on squib

3. Wait for qualitime and read the fault recorder

4. Remove fault on squib

5. Wait for dequalitime and read the fault recorder


I<B<Evaluation>>

3. expected faults: as per parameter FLTmand_createFault

5. expected faults: as per parameter FLTmand_removeFault


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'--> 'purpose of the test case'
	SCALAR 'squib'--> 'squib under test'
	SCALAR 'condition'--> 'condition to be created for the test case. For e.g. Normal condition, not monitored, not configured, abnormal voltage, PST fault, Short to Bat/Gnd on squib, ER voltage below threshold'
	SCALAR 'fault'--> 'fault to be created on the squib' 
	SCALAR 'qualitime'--> 'squib fault qualification time'
	SCALAR 'dequalitime'--> 'squib fault dequalification time'
	HASH 'FLTmand_createFault'--> 'mandatory/expected faults with status when fault is created in step2'
	HASH 'FLTmand_removeFault'--> 'mandatory/expected faults with status when fault condition is removed in step4'


=head2 PARAMETER EXAMPLES
  
	[TC_FLS_SquibMonitoring.NormalCondition_HighSideShort2BatSquibLine1]   #ID: SRTP_FLS_408
	# From here on: applicable Lift Default Parameters
	purpose	= 'to check the squib monitoring requirements under normal condition - HighSide Short2Bat fault'
	squib = 'AB1FD'
	condition = 'normal' #normal condition
	fault = 'Short2Bat_highSide'
	qualitime = '6000' #ms
	dequalitime = '6000' #ms
	FLTmand_createFault = %('fls_Short2Bat_FAULT' => '0bxxxxx111')
	FLTmand_removeFault = %('fls_Short2Bat_FAULT' => '0bxxxxx110')

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_purpose,             $defaultpar_squib,          $Const_sqm_DEVICE_NAME,      $defaultpar_condition,  $defaultpar_fault,      $defaultpar_qualitime, $defaultpar_dequalitime, $defaultpar_FLTmand_createFault,
	$defaultpar_FLTmand_removeFault, @defaultpar_FLToptPMActive, $defaultpar_FLTmandPMActive, $tcpar_shunt_short2bat, $tcpar_shunt_short2gnd, $tcpar_ubat,           $tcpar_FLTmandGnd,       $tcpar_FLToptGnd,
	$tcpar_FLTmandBat,               $tcpar_FLToptBat,           $tcpar_command,              $tcpar_signal,          $tcpar_value,           $tcpar_opt_fault
);
my $plantmode2_set  = 0b00000010;
my $plantmode_clear = 0b00000000;
my ( $data_aref1, $data_aref2 );
my ( $fltmem1, $fltmem2, $fltmem3, $fltmem4, $fltmem5, $fltmem6, $fltmem7, $fltmem8 );
############# Parameters from const files ################
my $verdict;
################ global parameter declaration ##################
my (%flt_mem_struct_observed);
my $result;
my $factor_below;
my $factor_above;
my $fltname_Bat;
my $fltname_Gnd;
my $shunt;
my $Status_FaultQualified;
my $Status_FaultStored;
my $Status_NoFault;
my $valid_mapping;
my $valid_squib;
my ( $FLTmand_createFault, $FLTmand_removeFault );

sub TC_set_parameters {

	$defaultpar_purpose             = GEN_Read_mandatory_testcase_parameter('purpose');
	$defaultpar_squib               = GEN_Read_optional_testcase_parameter('squib');
	$defaultpar_condition           = GEN_Read_mandatory_testcase_parameter('condition');
	$defaultpar_fault               = GEN_Read_mandatory_testcase_parameter('fault');
	$defaultpar_qualitime           = GEN_Read_mandatory_testcase_parameter('qualitime');
	$defaultpar_dequalitime         = GEN_Read_mandatory_testcase_parameter('dequalitime');
	$defaultpar_FLTmand_createFault = GEN_Read_optional_testcase_parameter( 'FLTmand_createFault', 'byref' );
	$defaultpar_FLTmand_removeFault = GEN_Read_optional_testcase_parameter( 'FLTmand_removeFault', 'byref' );
	@defaultpar_FLToptPMActive      = GEN_Read_optional_testcase_parameter('FLToptPMActive');
	$defaultpar_FLTmandPMActive     = GEN_Read_optional_testcase_parameter('FLTmandPMActive');
	$tcpar_ubat                     = 13.5;
	$tcpar_shunt_short2gnd          = 5;
	$tcpar_FLTmandGnd               = GEN_Read_optional_testcase_parameter('FLTmandGnd');
	$tcpar_FLToptGnd                = GEN_Read_optional_testcase_parameter( 'FLToptGnd', 'byref' );
	$tcpar_FLTmandBat               = GEN_Read_optional_testcase_parameter('FLTmandBat');
	$tcpar_FLToptBat                = GEN_Read_optional_testcase_parameter( 'FLToptBat', 'byref' );
	$tcpar_command                  = GEN_Read_optional_testcase_parameter('command');
	$tcpar_signal                   = GEN_Read_optional_testcase_parameter('signal');
	$tcpar_value                    = GEN_Read_optional_testcase_parameter('value');
	$tcpar_opt_fault                = GEN_Read_optional_testcase_parameter('opt_fault');

	( $result, $tcpar_shunt_short2bat ) = SYC_SQUIB_get_ResistanceShort2Bat();
	return 0 unless $result;

	$factor_below          = 1000 * 0.8;
	$factor_above          = 1000 * 1.2;
	$Status_FaultQualified = '0bxxxx1xx1';     #stored and filtered
	$Status_FaultStored    = '0bxxxxx1xx0';    #stored and not filtered
	$Status_NoFault        = '0b000000000';    #no fault qualified

	unless ( $defaultpar_condition eq 'Plantmode2' ) {

		#for printout:
		my ( $key, $value );
		while ( ( $key, $value ) = each %$defaultpar_FLTmand_createFault ) { $FLTmand_createFault .= " $key => $value ,"; }
		while ( ( $key, $value ) = each %$defaultpar_FLTmand_removeFault ) { $FLTmand_removeFault .= " $key => $value ,"; }
	}

	# check if used constants are defined and read them
	$Const_sqm_DEVICE_NAME = DEVICE_fetchDeviceNamebyDeviceNumber($defaultpar_squib);
	#If no device is assigned then skip this section.

	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;
		return 1;
	}
	else {
		( $valid_mapping, $valid_squib ) = CheckValidDevice();

		if ( $valid_mapping == 0 or $valid_squib == 0 ) {
			S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
			S_set_verdict(VERDICT_NONE);
			$verdict = VERDICT_NONE;
			return 1;
		}
	}

	$fltname_Bat = $tcpar_FLTmandBat . $Const_sqm_DEVICE_NAME . '_flt';
	$fltname_Gnd = $tcpar_FLTmandGnd . $Const_sqm_DEVICE_NAME . '_flt';

	#to print the purpose
	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_w2rep( 'StandardPrepNoFault', 'blue' );
		GEN_StandardPrepNoFault();
	}

	return 1;

}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "Step 1: Create condition $defaultpar_condition condition for $Const_sqm_DEVICE_NAME", 'AUTO_NBR' );
		if ( $defaultpar_condition eq 'notMonitored' ) {
			my $config = PD_Device_configuration( 'clear', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(5000);

			#Clear the monitoring bit
			PD_Device_configuration( 'clear_Mon', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(6000);
		}
		elsif ( $defaultpar_condition eq 'Plantmode2' ) {

			S_w2rep( "Check if plantmode is not yet activated", 'AUTO_NBR', 'mode_inactive' );
			$data_aref1 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
			EVAL_evaluate_value( "Plant mode 2 inactive", $$data_aref1[0], '==', 0 );
			PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode2_set] );

			PD_ECUreset();
			S_wait_ms('TIMER_ECU_READY');

			PD_ClearFaultMemory();
			$data_aref2 = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
			my $plan_check = EVAL_evaluate_value( "Plant mode 2 active", $$data_aref2[0], '==', $plantmode2_set );
			if ( $plan_check eq VERDICT_PASS ) {
				S_w2rep( "Plant mode 2 is set successful", 'AUTO_NBR' );
			}
			else {
				S_w2rep( "Failed to set Plant mode 2 ", 'AUTO_NBR' );
				return 0;
			}
		}

		elsif ( $defaultpar_condition eq 'CrossCouple' ) {
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			my $faultstatus = DEVICE_setDeviceState( $Const_sqm_DEVICE_NAME, $defaultpar_condition );

			unless ( defined $faultstatus and $faultstatus == 1 ) {
				S_w2rep( "Cross coupling fault for: $Const_sqm_DEVICE_NAME is is not created successfully! Not proceeding", 'red' );
				return 0;
			}
			LC_ECU_Reset();
			PD_ReadFaultMemory();

		}
		elsif ( $defaultpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) {

			my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
			if ( $TestHW eq 'MLC' ) {
				S_set_error("Cannot set highside on MLC device");
				return 0;
			}
			else {
				TSG4_ConnectSquibToOpAmp( $Const_sqm_DEVICE_NAME . "+", 3 );
				my $powerstagefault  = 'rb_sqm_HighsidePowerstage' . $Const_sqm_DEVICE_NAME . '_flt';
				my $fault_mem_struct = FM_PD_readFaultMemory();
				FM_evaluateFaults( $fault_mem_struct, [$powerstagefault] );

			}
		}

		else {
			my $conditionstatus = DEVICE_setSquibTestCondition( $Const_sqm_DEVICE_NAME, $defaultpar_condition );

			unless ( defined $conditionstatus and $conditionstatus == 1 ) {
				S_w2rep( "Condition: $defaultpar_condition on $Const_sqm_DEVICE_NAME is not created successfully! Not proceeding", 'red' );
				return 0;
			}
		}

		S_teststep( "Step 2: Create fault: $defaultpar_fault on squib: $Const_sqm_DEVICE_NAME", 'AUTO_NBR' );
		if ( $defaultpar_fault eq 'LowOhmicShort2Gnd' ) {

			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			S_teststep( "Short '$Const_sqm_DEVICE_NAME-' to GND with $shunt Ohm shunt", 'AUTO_NBR' );
			$shunt = sprintf( "%04d", $tcpar_shunt_short2gnd * $factor_below );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "-", 'B-' ], $shunt );

			S_teststep( "Wait for qualification time", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			$fltmem1 = PD_GetExtendedFaultInformation();
			S_teststep( "Evaluate fault in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem1, [$fltname_Gnd] );

			S_teststep( "Remove fault condition", 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( "Wait for dequalification time", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( "Clear fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();
			S_wait_ms(5000);

			S_teststep( "Check fault remove to memory", 'AUTO_NBR' );
			$fltmem1 = PD_GetExtendedFaultInformation();
			FM_evaluateFaults( $fltmem1, [] );

			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');
			###############################################################################

			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			S_teststep( "Short '$Const_sqm_DEVICE_NAME-' to GND with shunt higher then specified shunt", 'AUTO_NBR' );
			$shunt = sprintf( "%04d", $tcpar_shunt_short2gnd * $factor_above );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "-", 'B-' ], $shunt );

			S_teststep( "Wait for qualification time", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			$fltmem2 = PD_GetExtendedFaultInformation();
			S_teststep( "Evaluate fault in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem2, [], [] );

			S_teststep( "Remove fault condition", 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( "Wait for dequalification time", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( "Clear fault memory", 'AUTO_NBR' );
			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem2 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem2, [], [] );

			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

		}
		elsif ( $defaultpar_fault eq 'LowOhmicShort2Bat' ) {
			###############################################################################
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			S_teststep( "Short '$Const_sqm_DEVICE_NAME-' to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
			$shunt = sprintf( "%04d", $tcpar_shunt_short2bat * $factor_below );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "-", 'B+' ], $shunt );

			S_teststep( "Wait for qualification time", 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem3 = PD_GetExtendedFaultInformation();
			S_teststep( "Evaluate fault in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem3, [$fltname_Bat] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem3 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem3, [] );

			S_w2rep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			###############################################################################

			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			S_teststep( "Short '$Const_sqm_DEVICE_NAME-' to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
			$shunt = sprintf( "%04d", $tcpar_shunt_short2bat * $factor_above );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "-", 'B+' ], $shunt );

			S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem4 = PD_GetExtendedFaultInformation();
			S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat-_noFault' );
			FM_evaluateFaults( $fltmem4, [], [] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem4 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem4, [] );

			S_w2rep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

		}
		elsif ( $defaultpar_fault eq 'HighOhmicShort2Gnd' ) {
			###############################################################################
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to GND with shunt less than specified shunt", 'AUTO_NBR' );
			S_w2rep( 'Switch ECU on.', 'AUTO_NBR' );
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			$shunt = sprintf( "%04d", $tcpar_shunt_short2gnd * $factor_below );
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to GND with $shunt Ohm shunt", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "+", 'B-' ], $shunt );

			S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem5 = PD_GetExtendedFaultInformation();
			S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd+' );
			FM_evaluateFaults( $fltmem5, [$fltname_Gnd] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem5 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem5, [] );

			S_teststep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

###############################################################################
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to GND with shunt higher than specified shunt", 'AUTO_NBR' );
			S_w2rep( 'Switch ECU on.', 'AUTO_NBR' );
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			$shunt = sprintf( "%04d", $tcpar_shunt_short2gnd * $factor_above );
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to GND with $shunt Ohm shunt", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "+", 'B-' ], $shunt );

			S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem6 = PD_GetExtendedFaultInformation();
			S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandGnd+_noFault' );
			FM_evaluateFaults( $fltmem6, [], [] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem6 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem6, [] );

			S_teststep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

		}
		elsif ( $defaultpar_fault eq 'HighOhmicShort2Bat' ) {
			###############################################################################
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to BAT with shunt less than specified shunt", 'AUTO_NBR' );
			S_w2rep( 'Switch ECU on.', 'AUTO_NBR' );
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			$shunt = sprintf( "%04d", $tcpar_shunt_short2bat * $factor_below );
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "+", 'B+' ], $shunt );

			S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem7 = PD_GetExtendedFaultInformation();
			S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat+' );
			FM_evaluateFaults( $fltmem7, [$fltname_Bat] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem7 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem7, [] );

			S_w2rep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to BAT with shunt higher than specified shunt", 'AUTO_NBR' );
			S_w2rep( 'Switch ECU on.', 'AUTO_NBR' );
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();
			PD_GetExtendedFaultInformation();

			$shunt = sprintf( "%04d", $tcpar_shunt_short2bat * $factor_above );
			S_teststep( "Short $Const_sqm_DEVICE_NAME+ to BAT with $shunt Ohm shunt", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . "+", 'B+' ], $shunt );

			S_teststep( 'Wait for fault qualification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			S_teststep( 'Read fault recorder', 'AUTO_NBR' );
			$fltmem8 = PD_GetExtendedFaultInformation();
			S_teststep( 'Evaluate fault recorder', 'AUTO_NBR', 'FLTmandBat+_noFault' );
			FM_evaluateFaults( $fltmem8, [], [] );

			S_teststep( 'Remove fault', 'AUTO_NBR' );
			LC_UndoShortLines();

			S_teststep( 'Wait for fault dequalification time', 'AUTO_NBR' );
			S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

			PD_ClearFaultMemory();
			S_wait_ms(5000);

			$fltmem8 = PD_GetExtendedFaultInformation();
			S_teststep( "Check fault empty in memory", 'AUTO_NBR' );
			FM_evaluateFaults( $fltmem8, [] );

			S_w2rep( 'Switch ECU off', 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

		}
		elsif ( $defaultpar_fault eq 'VHxFault' ) {

			SPI_load_signal_manipulation(
				'Node'        => 'CG904_M',
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal,
				'SignalValue' => $tcpar_value,
				'Duration_ms' => '6000',
			);

			S_teststep( "Manipulate the SPI response for the SPI command 'FlmReadVhX' such that adc_data bit is set to value 390 ", 'AUTO_NBR' );
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			my $faultsBeforeStimulation = PD_ReadFaultMemory();
			my $faultsVerdict_before = FM_evaluateFaults( $faultsBeforeStimulation, [] );
			return unless ($faultsVerdict_before);

			SPI_start_manipulation();
			S_wait_ms(6000);

			my $faultsafterStimulation = PD_ReadFaultMemory();
			FM_checkFaultStatus( $faultsafterStimulation, $defaultpar_FLTmand_createFault, $Status_FaultQualified );

			my $faultsVerdict_after = FM_evaluateFaults( $faultsafterStimulation, [$defaultpar_FLTmand_createFault] );
			return unless ($faultsVerdict_after);

			S_teststep( "Stop Manipulation", 'AUTO_NBR' );    # including check of Manipulation counter
			SPI_stop_manipulation();
			S_wait_ms($defaultpar_dequalitime);

			my $faultsafterStimulation_dequali = PD_ReadFaultMemory();
			FM_checkFaultStatus( $faultsafterStimulation_dequali, $defaultpar_FLTmand_createFault, $Status_FaultStored );
			my $faultsVerdict_final = FM_evaluateFaults( $faultsafterStimulation_dequali, [$defaultpar_FLTmand_createFault] );
			return unless ($faultsVerdict_final);

		}
		elsif ( $defaultpar_fault eq 'HighsidePowerstage' ) {
			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');
			PD_ECUlogin();

			TSG4_ConnectSquibToOpAmp( $Const_sqm_DEVICE_NAME . "+", 3 );
			PD_ECUreset();    # cross coupling is an Init fault
			S_wait_ms(6000);

			S_teststep( "Step 3: Wait for qualitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_qualitime);
			$flt_mem_struct_observed{'step3'} = FM_PD_readFaultMemory();

			S_teststep( "Step 4: Remove fault on squib", 'AUTO_NBR' );
			S_w2rep( "remove high side fault", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . '-', 'B+' ] );
			S_wait_ms(5000);
			LC_UndoShortLines();
			S_wait_ms(1000);
			TSG4_DisconnectSquibFromOpAmp($Const_sqm_DEVICE_NAME);

			PD_ECUreset();    # cross coupling is an Init fault
			S_wait_ms(6000);

			S_teststep( "Step 5: Wait for dequalitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_dequalitime);
			$flt_mem_struct_observed{'step5'} = FM_PD_readFaultMemory();

			FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, [], \@defaultpar_FLToptPMActive );
			FM_evaluateFaults( $flt_mem_struct_observed{'step5'}, [], \@defaultpar_FLToptPMActive );

		}
		elsif ( ( $defaultpar_fault eq 'Short2Bat_lowSide' ) and ( $defaultpar_condition eq 'CrossCouple' ) ) {

			S_w2rep( "2 short happen in TSG4, need to handle separately. => add pin to create $defaultpar_fault fault \n", 'AUTO_NBR' );
			my ( $PMFault1, $PMFault2 );

			$PMFault1 = 'rb_sqm_Crosscoupling' . $Const_sqm_DEVICE_NAME . '_flt';
			$PMFault2 = 'rb_sqm_TerminalShort2Bat' . $Const_sqm_DEVICE_NAME . '_flt';
			S_teststep( "Create $defaultpar_fault fault ", 'AUTO_NBR' );
			TSG4_add_pins_to_short( ['B+'] );

			S_teststep( "Step 3: Wait for qualitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_qualitime);
			$flt_mem_struct_observed{'step3'} = FM_PD_readFaultMemory();

			S_teststep( "Step 4: Remove fault $defaultpar_fault on squib", 'AUTO_NBR' );
			TSG4_remove_pins_from_short( ['B+'] );

			S_teststep( "Step 5: Wait for dequalitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_dequalitime);
			$flt_mem_struct_observed{'step5'} = FM_PD_readFaultMemory();

			FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault1, '0bxxxxx111' );
			FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault2, '0bxxx00000' );

			S_teststep( "Evaluation for Step 5: $defaultpar_fault for $Const_sqm_DEVICE_NAME fault not appear, crosscoupling fault still there appear", 'AUTO_NBR' );
			FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault1, '0bxxxxx111' );
			FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault2, '0bxxx00000' );
		}
		else {

			LC_ECU_On($tcpar_ubat);
			S_wait_ms('TIMER_ECU_READY');

			S_w2rep( "Create fault: $defaultpar_fault ", 'AUTO_NBR' );
			my $faultstatus = DEVICE_setDeviceState( $Const_sqm_DEVICE_NAME, $defaultpar_fault );

			unless ( defined $faultstatus and $faultstatus == 1 ) {
				S_w2rep( "fault is is not created successfully! Not proceeding", 'red' );
				return 0;
			}
			if ( ( $defaultpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) or ( $defaultpar_condition eq 'CrossCouple' ) or ( $defaultpar_condition eq 'Plantmode2' ) ) {
				S_w2rep( "Do not need reset", 'blue' );
			}
			else {
				LC_ECU_Reset();
				S_wait_ms(2000);
			}
			S_teststep( "Step 3: Wait for qualitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_qualitime);
			$flt_mem_struct_observed{'step3'} = FM_PD_readFaultMemory();

			S_teststep( "Step 4: Remove fault on squib", 'AUTO_NBR' );
			DEVICE_resetDeviceState( $Const_sqm_DEVICE_NAME, $defaultpar_fault );

			if ( ( $defaultpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) or ( $defaultpar_condition eq 'CrossCouple' ) or ( $defaultpar_condition eq 'Plantmode2' ) ) {
				S_w2rep( "Do not need reset", 'blue' );
			}
			else {
				LC_ECU_Reset();
				S_wait_ms(2000);
			}
			S_teststep( "Step 5: Wait for dequalitime and read the fault recorder", 'AUTO_NBR' );
			S_wait_ms($defaultpar_dequalitime);
			$flt_mem_struct_observed{'step5'} = FM_PD_readFaultMemory();

			if ( $defaultpar_condition eq 'notMonitored' ) {
				my $mandFault     = $defaultpar_fault . $Const_sqm_DEVICE_NAME . '_flt';
				my $optionalFault = $tcpar_opt_fault . $Const_sqm_DEVICE_NAME . '_flt';

				FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $mandFault,     $Status_NoFault );        #eval faultname, status
				FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $optionalFault, $Status_FaultStored );    #eval faultname, status

				FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, [], [$optionalFault] );

				FM_checkFaultStatus( $flt_mem_struct_observed{'step5'}, $mandFault,     $Status_NoFault );        #eval faultname, status
				FM_checkFaultStatus( $flt_mem_struct_observed{'step5'}, $optionalFault, $Status_FaultStored );    #eval faultname, status

				FM_evaluateFaults( $flt_mem_struct_observed{'step5'}, [], [$optionalFault] );
			}
			elsif ( $defaultpar_condition eq 'CrossCouple' and $defaultpar_fault eq 'resistanceTooHigh' ) {
				my $PMFault = 'rb_sqm_SquibResistanceOpen' . $Const_sqm_DEVICE_NAME . '_flt';
				FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault, '0bxxx00000' );
				FM_checkFaultStatus( $flt_mem_struct_observed{'step5'}, $PMFault, '0bxxx00000' );
			}
			elsif ( $defaultpar_condition eq 'Plantmode2' or $defaultpar_fault eq 'CrossCouple' ) {

				if ( $defaultpar_FLTmandPMActive ne 'NONE' ) {
					my $PMFault = $defaultpar_FLTmandPMActive . $Const_sqm_DEVICE_NAME . '_flt';
					FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $PMFault, $defaultpar_FLTmand_createFault );    #eval faultname, status
					FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, [$PMFault], \@defaultpar_FLToptPMActive );

					FM_checkFaultStatus( $flt_mem_struct_observed{'step5'}, $PMFault, $defaultpar_FLTmand_removeFault );    #eval faultname, status
					FM_evaluateFaults( $flt_mem_struct_observed{'step5'}, [$PMFault], \@defaultpar_FLToptPMActive );
				}
				else {
					FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, [], \@defaultpar_FLToptPMActive );
					FM_evaluateFaults( $flt_mem_struct_observed{'step5'}, [], \@defaultpar_FLToptPMActive );
				}

			}
			else {

				S_teststep( "Evaluation for Step 3: expected faults: $FLTmand_createFault ", 'AUTO_NBR' );
				FM_checkDeviceFaults( $flt_mem_struct_observed{'step3'}, $Const_sqm_DEVICE_NAME, $defaultpar_FLTmand_createFault );

				S_teststep( "Evaluation for Step 5: expected faults: $FLTmand_removeFault", 'AUTO_NBR' );
				FM_checkDeviceFaults( $flt_mem_struct_observed{'step5'}, $Const_sqm_DEVICE_NAME, $defaultpar_FLTmand_removeFault );

			}
		}
	}
	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( "Evaluation is done in stimulation and measurement", 'blue' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		S_w2rep( "Step END: reset test condition", 'blue' );

		if ( $defaultpar_condition eq 'notMonitored' ) {
			my $config = PD_Device_configuration( 'set_Mon', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(5000);

			#set the monitoring bit
			PD_Device_configuration( 'set', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(6000);
		}

		elsif ( $defaultpar_condition eq 'CrossCouple' ) {
			LC_UndoShortLines();
			PD_ECUreset();
			S_wait_ms('TIMER_ECU_READY');
		}
		elsif ( $defaultpar_condition eq 'Plantmode2' ) {
			S_w2rep( "Deactivate plantmode", 'AUTO_NBR' );

			PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
			PD_ECUreset();
			S_wait_ms('TIMER_ECU_READY');
			PD_ClearFaultMemory();
			S_wait_ms('TIMER_ECU_READY');
			my $plantmodeinactive = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
			EVAL_evaluate_value( "Plant mode 2 inactive", $$plantmodeinactive[0], '==', $plantmode_clear );
		}
		elsif ( $defaultpar_condition eq 'ActivatePowerStage_DisAHPdisabled' and $defaultpar_fault eq 'resistanceTooHigh' ) {
			S_w2rep( "remove high side fault", 'AUTO_NBR' );
			LC_ShortLines( [ $Const_sqm_DEVICE_NAME . '-', 'B+' ] );
			S_wait_ms(5000);
			LC_UndoShortLines();
			S_wait_ms(1000);
			TSG4_DisconnectSquibFromOpAmp($Const_sqm_DEVICE_NAME);
		}
		elsif ( $defaultpar_condition eq 'ActivatePowerStage_DisAHPdisabled' ) {
			S_w2rep( "remove high side fault", 'AUTO_NBR' );
			TSG4_DisconnectSquibFromOpAmp($Const_sqm_DEVICE_NAME);
		}

		else {
			DEVICE_resetSquibTestCondition( $Const_sqm_DEVICE_NAME, $defaultpar_condition );
		}

		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $FLT_final = PD_ReadFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $faultsVerdict_final = FM_evaluateFaults( $FLT_final, [] );

		GEN_Finalization();
	}
	return 1;

}

sub CheckValidDevice {

	my $mapping    = 1;
	my $configured = 1;
	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {

		$mapping = 0;
	}

	( my $Real, my $Monitored_ID, my $Prog ) = PD_get_device_config($Const_sqm_DEVICE_NAME);

	if ( $Prog == 0 ) {
		$configured = 0;
	}

	return ( $mapping, $configured );    #valid device name is present
}

1;

