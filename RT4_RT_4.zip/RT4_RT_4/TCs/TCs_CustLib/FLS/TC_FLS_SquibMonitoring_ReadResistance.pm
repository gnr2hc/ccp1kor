#### TEST CASE MODULE
package TC_FLS_SquibMonitoring_ReadResistance;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_SquibMonitoring_ReadResistance.pm 1.1 2019/06/14 13:45:29ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use FuncLib_TNT_GEN;
use INCLUDES_Project;    #necessary
use FuncLib_TNT_SYC_INTERFACE;
use LIFT_PD;
use LIFT_labcar;

##################################

our $PURPOSE = "To check for squib monitoring condition when squib is not monitored/Short2bat/Short2gnd";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_SquibMonitoring_ReadResistance

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <condition>

2. Read the squib <squib> resistance.

3. Create <fault> on <squib>

4. Wait for <qualitime> and read the fault recorder.

5. Remove <fault> on <squib>

6. Wait for <dequalitime> and read the fault recorder.


I<B<Evaluation>>

2. The squib <squib> resistance is <value>.

4. expected faults: <FLTmand_createFault>

6. expected faults: <FLTmand_removeFault>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'squib' => 
	SCALAR 'condition' => 
	SCALAR 'fault' => 
	SCALAR 'qualitime' => 
	SCALAR 'dequalitime' => 
	HASH 'FLTmand_createFault' => 
	HASH 'FLTmand_removeFault' => 
	SCALAR 'value' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'to check the squib monitoring requirements when short to Gnd is present on the squib - resistance too low, shortline fault'
	
	squib = '<Test Heading>'
	condition = 'Short2Gnd' 
	fault = 'resistanceTooLow'
	qualitime = '6000' #ms
	dequalitime = '6000' #ms
	
	FLTmand_createFault = %('Short2Gnd' => '0bxxxxx111', 'ShortResistance' => '0bxxx00000')
	FLTmand_removeFault = %('Short2Gnd' => '0bxxxxx111', 'ShortResistance' => '0bxxx00000')
	value = '0'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_squib;
my $tcpar_condition;
my $tcpar_fault;
my $tcpar_qualitime;
my $tcpar_dequalitime;
my $tcpar_FLTmand_createFault;
my $tcpar_FLTmand_removeFault;

my $tcpar_fault_name;

################ global parameter declaration ###################
#add any global variables here
my $Const_sqm_DEVICE_NAME;
my (%flt_mem_struct_observed);
my $Status_FaultQualified;
my $Status_FaultStored;
my $Status_NoFault;
my $mapping;
my $conf;
my ( $valid_mapping, $valid_squib );
my $verdict;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_squib               = GEN_Read_mandatory_testcase_parameter('squib');
	$tcpar_condition           = GEN_Read_mandatory_testcase_parameter('condition');
	$tcpar_fault               = GEN_Read_mandatory_testcase_parameter('fault');
	$tcpar_fault_name          = GEN_Read_optional_testcase_parameter('fault_name');
	$tcpar_qualitime           = GEN_Read_mandatory_testcase_parameter('qualitime');
	$tcpar_dequalitime         = GEN_Read_mandatory_testcase_parameter('dequalitime');
	$tcpar_FLTmand_createFault = GEN_Read_optional_testcase_parameter( 'FLTmand_createFault', 'byref' );
	$tcpar_FLTmand_removeFault = GEN_Read_optional_testcase_parameter( 'FLTmand_removeFault', 'byref' );

	$Const_sqm_DEVICE_NAME = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_squib);

	$Status_FaultQualified = '0bxxxx1xx1';     #stored and filtered
	$Status_FaultStored    = '0bxxxxx1xx0';    #stored and not filtered
	$Status_NoFault        = '0b000000000';    #no fault qualified

	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;
		return 1;
	}
	else {
		( $valid_mapping, $valid_squib ) = CheckValidDevice();

		if ( $valid_mapping == 0 or $valid_squib == 0 ) {
			S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
			S_set_verdict(VERDICT_NONE);
			$verdict = VERDICT_NONE;
			return 1;
		}
	}
	return 1;
}

sub TC_initialization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_w2rep( 'StandardPrepNoFault', 'blue' );
		GEN_StandardPrepNoFault();
	}

	return 1;

}

sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "Create '$tcpar_condition' condition for $Const_sqm_DEVICE_NAME", 'AUTO_NBR' );

		if ( $tcpar_condition eq 'notMonitored' ) {
			PD_ECUlogin();
			PD_Device_configuration( 'clear', [$Const_sqm_DEVICE_NAME] );
			S_wait_ms(5000);

			#Clear the monitoring bit
			PD_Device_configuration( 'clear_Mon', [$Const_sqm_DEVICE_NAME] );
			S_wait_ms(6000);
		}
		else {

			my $conditionstatus = DEVICE_setDeviceState( $Const_sqm_DEVICE_NAME, $tcpar_condition );
			unless ( defined $conditionstatus and $conditionstatus == 1 ) {
				S_w2rep( "Condition is not created successfully! Not proceeding", 'red' );
				$PURPOSE = "Condition is not created successfully";
				return 0;
			}
		}

		S_wait_ms(6000);
		S_teststep( "Read the squib '$Const_sqm_DEVICE_NAME' resistance.", 'AUTO_NBR', 'read_the_squib' );    #measurement 1
		my $resistance = tc_ReadResistance();

		if ( ( $resistance == 0 ) ) {

			S_teststep_expected( "The resistance expected is: 0", 'read_the_squib' );                         #evaluation 1
			S_teststep_detected( "The detected resistance is: $resistance", 'read_the_squib' );
			S_set_verdict(VERDICT_PASS);
		}
		else {
			S_teststep_expected( "The resistance expected is: 0", 'read_the_squib' );                         #evaluation 1
			S_teststep_detected( "The detected resistance is: $resistance", 'read_the_squib' );
			S_set_verdict(VERDICT_FAIL);
		}

		S_teststep( "Create '$tcpar_fault' on '$Const_sqm_DEVICE_NAME'", 'AUTO_NBR' );
		my $faultstatus = DEVICE_setDeviceState( $Const_sqm_DEVICE_NAME, $tcpar_fault );

		unless ( defined $faultstatus and $faultstatus == 1 ) {
			S_w2rep( "fault is is not created successfully! Not proceeding", 'red' );
			$PURPOSE = "Squib fault is not created successfully";
			return 0;
		}
		S_teststep( "Wait for '$tcpar_qualitime' and read the fault recorder.", 'AUTO_NBR', 'wait_for_qualitime' );    #measurement 2
		S_wait_ms($tcpar_qualitime);
		$flt_mem_struct_observed{'step4'} = FM_PD_readFaultMemory();

		S_teststep( "Remove '$tcpar_fault' on '$Const_sqm_DEVICE_NAME'", 'AUTO_NBR' );
		DEVICE_resetDeviceState( $Const_sqm_DEVICE_NAME, $tcpar_fault );

		S_teststep( "Wait for '$tcpar_dequalitime' and read the fault recorder.", 'AUTO_NBR', 'wait_for_dequalitime' );    #measurement 3
		S_wait_ms($tcpar_dequalitime);
		$flt_mem_struct_observed{'step6'} = FM_PD_readFaultMemory();

		if ( $tcpar_condition eq 'notMonitored' ) {
			my $mandFault     = $tcpar_fault_name . $Const_sqm_DEVICE_NAME . '_flt';
			my $optionalFault = 'rb_sqm_Unexpected' . $Const_sqm_DEVICE_NAME . '_flt';

			FM_checkFaultStatus( $flt_mem_struct_observed{'step4'}, $mandFault,     $Status_NoFault );                     #eval faultname, status
			FM_checkFaultStatus( $flt_mem_struct_observed{'step4'}, $optionalFault, $Status_FaultStored );                 #eval faultname, status

			FM_evaluateFaults( $flt_mem_struct_observed{'step4'}, [], [$optionalFault] );

			FM_checkFaultStatus( $flt_mem_struct_observed{'step6'}, $mandFault,     $Status_NoFault );                     #eval faultname, status
			FM_checkFaultStatus( $flt_mem_struct_observed{'step6'}, $optionalFault, $Status_FaultStored );                 #eval faultname, status

			FM_evaluateFaults( $flt_mem_struct_observed{'step6'}, [], [$optionalFault] );
		}
		else {
			S_w2rep( "Evaluation for Step 4: expected faults: as per parameter FLTmand_createFault", 'blue' );
			FM_checkDeviceFaults( $flt_mem_struct_observed{'step4'}, $Const_sqm_DEVICE_NAME, $tcpar_FLTmand_createFault );

			S_w2rep( "Evaluation for Step 6: expected faults: as per parameter FLTmand_removeFault", 'blue' );
			FM_checkDeviceFaults( $flt_mem_struct_observed{'step6'}, $Const_sqm_DEVICE_NAME, $tcpar_FLTmand_removeFault );

		}
	}
	return 1;

}

sub TC_evaluation {

	S_w2rep( "Evaluation is done in stimulation and measurement", 'blue' );

	return 1;
}

sub TC_finalization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		S_w2rep( "Step END: reset test condition", 'blue' );

		if ( $tcpar_condition eq 'notMonitored' ) {
			PD_Device_configuration( 'set_Mon', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(5000);

			#Clear the monitoring bit
			PD_Device_configuration( 'set', [$Const_sqm_DEVICE_NAME] );
			PD_ECUlogin();
			S_wait_ms(6000);
		}
		else {
			DEVICE_resetDeviceState( $Const_sqm_DEVICE_NAME, $tcpar_condition );
		}

		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $FLT_final = PD_ReadFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $faultsVerdict_final = FM_evaluateFaults( $FLT_final, [] );

		GEN_Finalization();
	}
	return 1;
}

sub CheckValidDevice {
	my $check_mapping = 1;
	my $check_conf    = 1;

	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {
		S_w2rep( "Valid squib is not configured for one of the squib lines. Skip execution of this section\n", 'orange' );
		$PURPOSE       = "TESTCASE NOT EXECUTED: No device is configured for: $Const_sqm_DEVICE_NAME";
		$check_mapping = 0;
	}

	( my $Real, my $Monitored_ID, my $Prog ) = PD_get_device_config($Const_sqm_DEVICE_NAME);

	if ( ( $Prog == 0 ) ) {
		S_w2rep( "The squib is not configured ", 'AUTO_NBR' );
		$check_conf = 0;
	}

	return ( $check_mapping, $check_conf );    #valid device name is present
}

sub tc_ReadResistance {
	my $res;
	( my $result, my $calc_array_idx, my $asic_connection, my $asic_connectionCBR, my $asic_connectionIGH, my $asic_connectionIGL ) = SYC_SQUIB_get_ASIC_connection($Const_sqm_DEVICE_NAME);
	$asic_connectionCBR = $asic_connectionCBR - 1;
	$asic_connectionIGH = $asic_connectionIGH - 1;
	$res                = S_aref2hex( PD_ReadMemoryByName("rb_sqmm_ResistanceValue_au16($asic_connectionCBR)($asic_connectionIGH)") );
	$res                = ( S_hex2dec($res) ) / 100;
	S_w2rep("The resistance value of $Const_sqm_DEVICE_NAME is $res ohms");

	return ($res);

}

1;
