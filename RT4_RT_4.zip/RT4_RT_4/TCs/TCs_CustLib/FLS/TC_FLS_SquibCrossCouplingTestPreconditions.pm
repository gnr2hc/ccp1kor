#### TEST CASE MODULE
package TC_FLS_SquibCrossCouplingTestPreconditions;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_SquibCrossCouplingTestPreconditions.pm 1.1 2019/06/14 13:45:29ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;
##################################

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_labcar;
use LIFT_TSG4;
use LIFT_PD;
##################################
our $PURPOSE = "to check the preconditions for CC test";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_SquibCrossCouplingTestPreconditions  $Revision: 1.1 $


=head1 PURPOSE

to check the preconditions for CC test

=head1 TESTCASE DESCRIPTION 

I<B<Initialisation>>

StandardPrepNoFault

I<B<Stimulation and Measurement>>

1. Create condition1

2. Create a short between high side terminal of squib1 and high side terminal of squib2 (cross coupled)

3. Read fault recorder

4. Reset ECU and read the fault recorder after init

5. Create condition2

6. Reset ECU and read the fault recorder after init


I<B<Evaluation>>

3. Cross coupling fault is not qualified for squib1 and squib2. Fault created in step 1 is qualified

4. Squib cross coupling fault is qualified only for squib2. Fault created in step 1 remains qualified

6. Squib cross coupling fault is not qualified for squib1 and squib2. Fault created in step 1 and step 5 remains qualified


I<B<Finalisation>>

Reset/Remove the test conditions created in test case


=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'--> 'purpose of the test case'
	SCALAR 'squib1'--> 'for e.g. SquibLine1 which may correspond to AB1FD'
	SCALAR 'squib2'--> 'for e.g. SquibLine2 which may correspond to AB1FP' 
	SCALAR 'condition1'--> 'Condition to be set on squib1. For example: Short2Bat, Short2Gnd or Deconfigured'
	SCALAR 'condition2'--> 'Condition to be set on squib2 or to set the ER voltage below threshold. For example: Short2Bat, Deconfigured for squib2 and ER voltage below threshold for the ECU'


=head2 PARAMETER EXAMPLES

	[TC_FLS_SquibCrossCouplingTestPreconditions.AB1FD_AB1FP_ConfigS2B]   #ID: SRTP_FLS_3830
	# From here on: applicable Lift Default Parameters
	purpose	= 'to check the preconditions for CC test'
	squib1 = 'SquibLine1'
	squib2 = 'SquibLine2'
	condition1 = 'squib1_NotConfigured'
	condition2 = 'squib2_Short2Bat'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_CCfault, $defaultpar_purpose, $defaultpar_squib1_name, $defaultpar_squib2_name, $tcpar_condition1, $tcpar_fault1, $tcpar_Optional_Fault );

############# Parameters from const files ################
my $Status_FaultQualified;

################ global parameter declaration ##################

my (%flt_mem_struct_observed);
my $SquibFaultQualiTime;
my $status;
my $fltmem1;
my $status;

sub TC_set_parameters {

	$defaultpar_purpose     = GEN_Read_mandatory_testcase_parameter('purpose');
	$defaultpar_squib1_name = GEN_Read_mandatory_testcase_parameter('squib1');
	$defaultpar_squib2_name = GEN_Read_mandatory_testcase_parameter('squib2');
	$tcpar_condition1       = GEN_Read_mandatory_testcase_parameter('condition1');
	$tcpar_fault1           = GEN_Read_mandatory_testcase_parameter('fault1');
	$tcpar_CCfault          = GEN_Read_mandatory_testcase_parameter('CCfault');
	$tcpar_Optional_Fault   = GEN_Read_optional_testcase_parameter('Optional_Fault');

	# check if used constants are defined and read them
	$Status_FaultQualified = '0bxxxx1xx1';    #stored and filtered
	$SquibFaultQualiTime   = 6000;

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	return 1 if ( CheckValidDevice() == 0 );

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	return 1 if ( CheckValidDevice() == 0 );

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;

}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	return 1 if ( CheckValidDevice() == 0 );

	S_teststep( "Step 1:Create condition1: $tcpar_condition1", 'AUTO_NBR' );
	if ( $tcpar_condition1 eq 'notMonitored' ) {
		S_w2rep( "Clear configuration bit to avoid ECU go to idle mode \n", 'blue' );
		my $status = DEVICE_setSquibTestCondition( $defaultpar_squib1_name, 'notConfigured' );
		S_wait_ms(2000);
		unless ( defined $status and $status == 1 ) {
			S_w2rep( "condition is not created successfully! Not proceeding", 'red' );
			$PURPOSE = "condition is not created successfully";
			return 0;
		}
	}
	my $status = DEVICE_setSquibTestCondition( $defaultpar_squib1_name, $tcpar_condition1 );

	S_wait_ms($SquibFaultQualiTime);

	unless ( defined $status and $status == 1 ) {
		S_w2rep( "condition is not created successfully! Not proceeding", 'red' );
		$PURPOSE = "condition is not created successfully";
		return 0;
	}

	S_teststep( "Step 2:Create a short between high side terminal of $defaultpar_squib1_name and high side terminal of $defaultpar_squib2_name (cross coupled)", 'AUTO_NBR' );
	if ( $tcpar_condition1 eq 'notMonitored' ) {
		DEVICE_shortLines( "$defaultpar_squib1_name" . '+', "$defaultpar_squib2_name" . '+' );
	}
	elsif ( $tcpar_condition1 eq 'Short2Gnd' or $tcpar_condition1 eq 'Short2Bat' ) {

		my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
		if ( $TestHW eq 'MLC' ) {
			S_set_error("Cannot set 2 shortlines on MLC device");
			return 0;
		}
		TSG4_add_pins_to_short( [ "$defaultpar_squib2_name" . '+' ] );
	}
	else {
		S_set_error( "Invalid fault mem structure", 109 );
	}

	S_wait_ms($SquibFaultQualiTime);

	S_teststep( "Step 3: Read fault recorder", 'AUTO_NBR' );
	$flt_mem_struct_observed{'step3'} = FM_PD_readFaultMemory();

	S_teststep( "Step 4: Reset ECU and read the fault recorder after init", 'AUTO_NBR' );
	GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step4'} = FM_PD_readFaultMemory();

	S_teststep( "Step 5:Remove the short between the squib terminals and read the fault recorder (note: reset not required)", 'AUTO_NBR' );
	LC_UndoShortLines();
	$flt_mem_struct_observed{'step5'} = FM_PD_readFaultMemory();

	S_w2rep( "Remove all fault in memory \n", 'blue' );
	DEVICE_resetSquibTestCondition( $defaultpar_squib1_name, $tcpar_condition1 );
	if ( $tcpar_condition1 eq 'notMonitored' ) {
		S_wait_ms(2000);
		DEVICE_resetSquibTestCondition( $defaultpar_squib1_name, 'notConfigured' );
	}

	GEN_Power_on_Reset();
	PD_ClearFaultMemory();
	S_wait_ms(5000);
	
	$fltmem1 = PD_GetExtendedFaultInformation();
	FM_evaluateFaults( $fltmem1, [] );    #check for remove all fault in memory

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	return 1 if ( CheckValidDevice() == 0 );

	#create hash crosscoupling fault.
	my %fault_cross;
	$fault_cross{$defaultpar_squib1_name} = $tcpar_CCfault . $defaultpar_squib1_name . '_flt';
	$fault_cross{$defaultpar_squib2_name} = $tcpar_CCfault . $defaultpar_squib2_name . '_flt';

	S_teststep( "Evaluation for Step 3: Cross coupling fault is not qualified for $defaultpar_squib1_name and $defaultpar_squib2_name. Fault created in step 1 is qualified", 'AUTO_NBR' );
	if ( $tcpar_fault1 eq 'NONE' ) {
		S_w2rep( "No fault should be appear in memory \n", 'blue' );
		FM_evaluateFaults( $flt_mem_struct_observed{'step3'},[],[$tcpar_Optional_Fault] );    #confirm that no other faults are present
	}
	else {
		FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $tcpar_fault1, $Status_FaultQualified );    #check fault status
		FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, [$tcpar_fault1], [$tcpar_Optional_Fault] );   #confirm that no other faults are present
	}

	S_teststep( "Evaluation for Step 4: Squib cross coupling fault is qualified only for $defaultpar_squib2_name. Fault created in step 1 remains qualified", 'AUTO_NBR' );
	unless ( $tcpar_fault1 eq 'NONE' ) {
		S_w2rep( "No crosscoupling fault for 2 squib \n", 'blue' );
		FM_evaluateFaults( $flt_mem_struct_observed{'step4'}, [$tcpar_fault1], [$tcpar_Optional_Fault] );    #confirm that no other faults are present
		S_teststep( "Evaluation for Step 5: Cross coupling faults for $defaultpar_squib2_name remain qualified.", 'AUTO_NBR' );
		FM_evaluateFaults( $flt_mem_struct_observed{'step5'}, [$tcpar_fault1], [$tcpar_Optional_Fault] );    #confirm that no other faults are present
	}
	else {
		S_w2rep( "Check crosscoupling for squib 2: $defaultpar_squib2_name \n", 'blue' );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step4'}, $fault_cross{$defaultpar_squib2_name}, $Status_FaultQualified );
		FM_evaluateFaults( $flt_mem_struct_observed{'step4'}, [ $fault_cross{$defaultpar_squib2_name} ], [$tcpar_Optional_Fault] );    #confirm that no other faults are present

		S_teststep( "Evaluation for Step 5: Cross coupling faults for $defaultpar_squib2_name remain qualified.", 'AUTO_NBR' );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step5'}, $fault_cross{$defaultpar_squib2_name}, $Status_FaultQualified );       #check fault status
	}
	return 1;

}

#-- set system to original state --##
sub TC_finalization {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	return 1 if ( CheckValidDevice() == 0 );
	GEN_Finalization();

	return 1;

}

sub CheckValidDevice {
	unless ( defined $defaultpar_squib1_name and $defaultpar_squib1_name ne '' and $defaultpar_squib1_name ne 'NONE' ) {
		S_w2rep( "Valid squib is not configured for one of the squib lines. Skip execution of this section\n", 'orange' );
		$PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for: $defaultpar_squib1_name";
		return 0;
	}
	unless ( defined $defaultpar_squib2_name and $defaultpar_squib2_name ne '' and $defaultpar_squib2_name ne 'NONE' ) {
		S_w2rep( "Valid squib is not configured for one of the squib lines. Skip execution of this section\n", 'orange' );
		$PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for: $defaultpar_squib2_name";
		return 0;
	}
	return 1;    #valid device name is present
}

1;
__END__
