#### TEST CASE MODULE
package TC_FLS_PowerStageTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: FLS/TC_FLS_PowerStageTest.pm 1.1 2019/06/14 13:45:28ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

# ----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_general;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_spi_access;
use FuncLib_TNT_GEN;
use Data::Dumper;
$Data::Dumper::Sortkeys = 1;    #Sort the keys in the output
use LIFT_manitoo;

##################################

our $PURPOSE = "to check the power stage test under normal conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_PowerStageTest

=head1 PURPOSE

<to check the power stage test under normal conditions>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Create <condition>


I<B<Stimulation and Measurement>>

1. Check the ITM test status for test.

2. Read the fault recorder

3. Create <condition>.

4. Reset the ECU and Monitor_SPI during initialization

5. Check the sequence of SPI commands

6.  Check the ITM test status for test.

7. Read the fault recorder.


I<B<Evaluation>>

1. <PD_ITMTestStarted>, <PD_ITMTestFinished>, <PD_ITMTestSkipped>, <PD_ITMTestFailed> with value  

<ITM_TestStarted>

<ITM_TestFinished>

<ITM_TestFailed>

<ITM_TestSkipped> in the bit  <itm_TestBit_SVR_OFFtest> and <itm_TestBit_SquibPstHSTest>

2. No fault is qualified

5. The expected sequence of commands are sent.

6. <PD_ITMTestStarted>, <PD_ITMTestFinished>, <PD_ITMTestSkipped>, <PD_ITMTestFailed> with value  

<ITM_TestStarted_init>

<ITM_TestFinished_init>

<ITM_TestFailed_init>

<ITM_TestSkipped_init>

  in the bit  <itm_TestBit_SVR_OFFtest> and <itm_TestBit_SquibPstHSTest>

7. No fault is qualified


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'trace_capture' => 
	LIST '_SPI_EvalSignal1_T1' => 
	SCALAR 'purpose' => 
	SCALAR 'condition' => 
	SCALAR 'squib' => 
	SCALAR 'PD_ITMTestStarted' => 
	SCALAR 'PD_ITMTestFinished' => 
	SCALAR 'PD_ITMTestSkipped' => 
	SCALAR 'PD_ITMTestFailed' => 
	SCALAR 'itm_TestBit_SVR_OFFtest' => 
	SCALAR 'SVR_offset' => 
	SCALAR 'SVR_byte' => 
	SCALAR 'SVR_mask' => 
	SCALAR 'itm_TestBit_SquibPstHSTest' => 
	SCALAR 'HSPST_offset' => 
	SCALAR 'HSPST_byte' => 
	SCALAR 'HSPST_mask' => 
	SCALAR 'itm_TestStarted' => 
	SCALAR 'itm_TestFinished' => 
	SCALAR 'itm_TestFailed' => 
	SCALAR 'itm_TestSkipped' => 
	SCALAR 'itm_TestStarted_init' => 
	SCALAR 'itm_TestFinished_init' => 
	SCALAR 'itm_TestFailed_init' => 
	SCALAR 'itm_TestSkipped_init' => 
	SCALAR 'USE_SPI_RECORD' => 
	LIST '_SPI_Node' => 
	SCALAR 'USE_SPI_EVAL' => 
	LIST '_SPI_GetTime_T1' => 
	LIST '_SPI_GetTime_T2' => 
	LIST '_SPI_EvalTime0_T1' => 
	LIST '_SPI_EvalSignal0_T1' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check the High side power stage test under normal conditions'
	condition = 'normal' #normal condition
	squib = '<Test Heading 1>'
	#manual testing
	#mode_mask = '0bxxxxxxx0xxxx0011' #HS PST mode
	#SDIS_mask = '0bxxxxxxxxxxxx0000' #SDIS are enabled
	#VEL_bit = '0bxxxxxxxxxxxxxxx1' #VEL bit is low
	#d5_DIS_AHP_mask = '0bxxxxxxxxxx0xxxxx' #enabled
	#d6_DIS_ALP_mask = '0bxxxxxxxxx1xxxxxx' #disabled
	#ul_mask  = '0bxxxxxxx00xxxxxxx' #HS and LS locked
	#run_mask = '0bxxxxx0xxxxxxxxxx' #no test running
	#tso_mask = '0bxxxx1xxxxxxxxxxx' #PST mode active
	#EOP_MISOmask = '0bxxxxxxxxxxxxxx01' #EOP1 is done
	#diag_result_mask = '0bxxxx0xxxxxxx0001' #PST OK
	#ITM Variables
	PD_ITMTestStarted = 'rb_itm_TestStarted_u64'
	PD_ITMTestFinished = 'rb_itm_TestFinished_u64'
	PD_ITMTestSkipped = 'rb_itm_TestSkipped_u64'
	PD_ITMTestFailed = 'rb_itm_TestFailed_u64'
	#ITM test status
	itm_TestBit_SVR_OFFtest = '42' 
	SVR_offset = '6'
	SVR_byte ='1'
	SVR_mask = '0bx1xx'
	itm_TestBit_SquibPstHSTest = '12'
	HSPST_offset = '-4'
	HSPST_byte ='1'
	HSPST_mask = '0bxxx1'
	#rb_itm_SquibPstHSTest_e
	itm_TestStarted = 1
	itm_TestFinished = 1
	itm_TestFailed = 0
	itm_TestSkipped = 0
	itm_TestStarted_init = 1
	itm_TestFinished_init = 1
	itm_TestFailed_init = 0
	itm_TestSkipped_init = 0
	USE_SPI_RECORD 		= 'yes'
	_SPI_Node			= @('CG904_M', 'CG904_S')
	USE_SPI_EVAL            = 'yes'
	_SPI_GetTime_T1  = @('T0', 'CG904 M::FLM_START_DIAG::MISO::d5', '==', '0x0') 
	_SPI_GetTime_T2  = @('T1', 'CG904_M::EOP::MISO::EOP1', '==', '0x1')  
	 _SPI_EvalTime0_T1       = @('T2', '>=', 1990, '<=', 2070)  
	_SPI_EvalSignal0_T1    = @('I_T1T2', 'CG904_M::FLM_START_DIAG::MOSI::mode', '==', '0x3',  'CG904_S::FLM_START_DIAG::MOSI::mode', '==', '0x3', 'CG904_M::POM_STATUS::MISO::vel', '==', '0x0',  'CG904_M::FLM_READ_VH::MISO::adc_data', '>=', '0x187', 'CG904_M::FLM_STATUS::MISO::d0', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d1', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d2', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d3', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d4', '>=', '0x1','CG904_M::FLM_STATUS::MISO::d5', '>=', '0x0','CG904_M::FLM_STATUS::MISO::d6', '>=', '0x1','>=',1)
	#conf_mask = '0bxxxxxxxx0000xxxx'
	
	trace_capture = '1'
	
	_SPI_EvalSignal1_T1    = @('I_T1T2', 'CG904_M::FLM_START_DIAG::MOSI::conf', '==', '0x0','==',1)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_condition;
my $tcpar_squib;
my $tcpar_PD_ITMTestStarted;
my $tcpar_PD_ITMTestFinished;
my $tcpar_PD_ITMTestSkipped;
my $tcpar_PD_ITMTestFailed;
my $tcpar_itm_TestBit_SVR_OFFtest;
my $tcpar_SVR_offset;
my $tcpar_SVR_byte;
my $tcpar_SVR_mask1;
my $tcpar_SVR_mask0;

my $tcpar_itm_TestBit_SquibPstTest;
my $tcpar_PST_offset;
my $tcpar_PST_byte;
my $tcpar_PST_mask1;
my $tcpar_PST_mask0;
my $tcpar_path;

my $tcpar_itm_TestStarted;
my $tcpar_itm_TestFinished;
my $tcpar_itm_TestFailed;
my $tcpar_itm_TestSkipped;
my $tcpar_itm_TestStarted_init;
my $tcpar_itm_TestFinished_init;
my $tcpar_itm_TestFailed_init;
my $tcpar_itm_TestSkipped_init;
my $tcpar_USE_SPI_RECORD;
my @tcpar_SPI_Node;
my $tcpar_USE_SPI_EVAL;
my $tcpar__SPI_GetTime_T1;
my $tcpar__SPI_GetTime_T2;
my $tcpar__SPI_EvalSignal0_T1;
my $tcpar__SPI_EvalSignal1_T1;
my $tcpar_trace_capture;

################ global parameter declaration ###################
#add any global variables here
my $Const_sqm_DEVICE_NAME;
my $check_mapping;
my $check_conf;
my $SPI_data;
my $tcpar_SPI_GetTime_href;
my $tcpar_Trace_EvalTime_href;
my $tcpar_SPI_EvalSignal_href;
my $meas_label = 'MY_SPI_Measurement';
my $itmstarted;
my $itmfinished;
my $itmskipped;
my $itmfailed;
my $itmstarted_PST;
my $itmfinished_PST;
my $itmskipped_HSPST;
my $itmfailed_PST;
my $itmstarted_final;
my $itmfinished_final;
my $itmskipped_final;
my $itmfailed_final;
my $itmstarted_PST_final;
my $itmfinished_PST_final;
my $itmskipped_PST_final;
my $itmfailed_PST_final;
my $faultsafterStimulation;
my $faultsBeforeStimulation;
my $verdict;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose                  = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_condition                = S_read_mandatory_testcase_parameter('condition');
	$tcpar_squib                    = S_read_mandatory_testcase_parameter('squib');
	$tcpar_PD_ITMTestStarted        = S_read_mandatory_testcase_parameter('PD_ITMTestStarted');
	$tcpar_PD_ITMTestFinished       = S_read_mandatory_testcase_parameter('PD_ITMTestFinished');
	$tcpar_PD_ITMTestSkipped        = S_read_mandatory_testcase_parameter('PD_ITMTestSkipped');
	$tcpar_PD_ITMTestFailed         = S_read_mandatory_testcase_parameter('PD_ITMTestFailed');
	$tcpar_itm_TestBit_SVR_OFFtest  = S_read_mandatory_testcase_parameter('itm_TestBit_SVR_OFFtest');
	$tcpar_SVR_offset               = S_read_mandatory_testcase_parameter('SVR_offset');
	$tcpar_SVR_byte                 = S_read_mandatory_testcase_parameter('SVR_byte');
	$tcpar_SVR_mask1                = S_read_mandatory_testcase_parameter('SVR_mask1');
	$tcpar_SVR_mask0                = S_read_mandatory_testcase_parameter('SVR_mask0');
	$tcpar_itm_TestBit_SquibPstTest = S_read_mandatory_testcase_parameter('itm_TestBit_SquibPstTest');
	$tcpar_PST_offset               = S_read_mandatory_testcase_parameter('PST_offset');
	$tcpar_PST_byte                 = S_read_mandatory_testcase_parameter('PST_byte');
	$tcpar_PST_mask1                = S_read_mandatory_testcase_parameter('PST_mask1');
	$tcpar_PST_mask0                = S_read_mandatory_testcase_parameter('PST_mask0');
	$tcpar_trace_capture            = S_read_mandatory_testcase_parameter('trace_capture');
	$tcpar_itm_TestStarted          = S_read_mandatory_testcase_parameter('itm_TestStarted');
	$tcpar_itm_TestFinished         = S_read_mandatory_testcase_parameter('itm_TestFinished');
	$tcpar_itm_TestFailed           = S_read_mandatory_testcase_parameter('itm_TestFailed');
	$tcpar_itm_TestSkipped          = S_read_mandatory_testcase_parameter('itm_TestSkipped');
	$tcpar_itm_TestStarted_init     = S_read_mandatory_testcase_parameter('itm_TestStarted_init');
	$tcpar_itm_TestFinished_init    = S_read_mandatory_testcase_parameter('itm_TestFinished_init');
	$tcpar_itm_TestFailed_init      = S_read_mandatory_testcase_parameter('itm_TestFailed_init');
	$tcpar_itm_TestSkipped_init     = S_read_mandatory_testcase_parameter('itm_TestSkipped_init');
	$tcpar_USE_SPI_EVAL             = S_read_mandatory_testcase_parameter('USE_SPI_EVAL');
	$tcpar__SPI_GetTime_T1          = S_read_mandatory_testcase_parameter('_SPI_GetTime_T1');
	$tcpar__SPI_GetTime_T2          = S_read_mandatory_testcase_parameter('_SPI_GetTime_T2');
	$tcpar_path                     = S_read_mandatory_testcase_parameter('path');
	$tcpar__SPI_EvalSignal0_T1      = S_read_mandatory_testcase_parameter('_SPI_EvalSignal0_T1');

	# $tcpar__SPI_EvalSignal1_T1   = GEN_Read_optional_testcase_parameter('_SPI_EvalSignal1_T1');

	$Const_sqm_DEVICE_NAME = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_squib);

	unless ( defined $Const_sqm_DEVICE_NAME and $Const_sqm_DEVICE_NAME ne '' and $Const_sqm_DEVICE_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;
		return 1;
	}
	$tcpar_USE_SPI_RECORD = S_read_optional_testcase_parameter( 'USE_SPI_RECORD', 'byvalue', 'no' );

	if ( $tcpar_USE_SPI_RECORD eq 'yes' ) {
		@tcpar_SPI_Node = S_read_mandatory_testcase_parameter( '_SPI_Node', 'byvalue' );

		# ------------------------------------------------------------------------
		$tcpar_USE_SPI_EVAL = S_read_optional_testcase_parameter( 'USE_SPI_EVAL', 'byvalue', 'no' );

		if ( $tcpar_USE_SPI_EVAL eq 'yes' ) {
			( $tcpar_SPI_GetTime_href, $tcpar_Trace_EvalTime_href, $tcpar_SPI_EvalSignal_href ) = GEN_get_trace_eval_params('SPI');

			# my $data = Dumper($tcpar_SPI_GetTime_href);

			# my $data1 = Dumper($tcpar_SPI_EvalSignal_href);

			# S_w2log(5, "Data dump for : \n $data \n");
			# S_w2log(5, "Data dump for : \n $data1 \n");

		}

		return 1;
	}
}

sub TC_initialization {

	#If no device is assigned then skip this section. Verdict will be 'NONE'
	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_w2rep( 'StandardPrepNoFault', 'blue' );
		GEN_StandardPrepNoFault();
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "Check the ITM test status for test.", 'AUTO_NBR' );    #measurement 1
		$itmstarted = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		$itmstarted_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_HSPST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_PST = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		S_teststep( "Read the fault recorder", 'AUTO_NBR', 'read_the_fault_A' );    #measurement 2
		$faultsBeforeStimulation = PD_ReadFaultMemory();

		S_teststep( "Create '$tcpar_condition'.", 'AUTO_NBR' );
		my $conditionstatus = DEVICE_setSquibTestCondition( $Const_sqm_DEVICE_NAME, $tcpar_condition );

		unless ( defined $conditionstatus and $conditionstatus == 1 ) {
			S_w2rep( "Condition is not created successfully! Not proceeding", 'red' );
			$PURPOSE = "Condition is not created successfully";
			return 0;
		}

		S_teststep( "Reset the ECU and Monitor_SPI during initialization", 'AUTO_NBR' );
		if ( $tcpar_trace_capture == 1 ) {

			S_teststep( "Reset the ECU and Monitor_SPI during initialization", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			LC_ECU_On();
			S_wait_ms(25);

			S_teststep( "Start SPI Trace", 'AUTO_NBR' );
			SPI_trace_start( [@tcpar_SPI_Node] );
			S_wait_ms(4000);

			S_teststep( "Stop SPI Trace", 'AUTO_NBR' );
			SPI_trace_stop();

			S_teststep( "Store SPI Trace", 'AUTO_NBR' );
			my $SPI_tracefile_name = $main::REPORT_PATH . "/" . "PST" . "_SPI_trace.mbt";

			S_teststep( "Store SPI Trace", 'AUTO_NBR' );
			SPI_trace_store($SPI_tracefile_name);

			SPI_trace_load_file(
				'MeasurementLabel' => $meas_label,
				'FileName'         => $SPI_tracefile_name,
			);

			foreach my $SPI_node (@tcpar_SPI_Node) {

				my $measurement_temp_href = SPI_trace_get_dataref(
					'MeasurementLabel' => $meas_label,
					'SPI_Node'         => $SPI_node,
				);

				my $data = Dumper($measurement_temp_href);

				S_w2log( 5, "Data dump for $SPI_node : \n $data \n" );

				@{$SPI_data}{ keys %$measurement_temp_href } = values %$measurement_temp_href;

			}
		}

		else {

			LC_ECU_Off();
			S_teststep( "Reset the ECU and Monitor_SPI during initialization", 'AUTO_NBR' );
			SPI_trace_start();    # when in lift testbenches, trace capture is SPIMaid, user action is pops up.
			LC_ECU_On();
			S_teststep( "Stop SPI Trace", 'AUTO_NBR' );
			SPI_trace_stop();     # when in lift testbenches, trace capture is SPIMaid, user action is pops up.
			S_teststep( "Store SPI Trace", 'AUTO_NBR' );

			my $SPI_tracefile_name = $tcpar_path;
			SPI_trace_load_file(
				'MeasurementLabel' => $meas_label,
				'FileName'         => $SPI_tracefile_name,
			);

			foreach my $SPI_node (@tcpar_SPI_Node) {
				my $measurement_temp_href = SPI_trace_get_dataref(
					'MeasurementLabel' => $meas_label,
					'SPI_Node'         => $SPI_node,
				);

				# my $data = Dumper(%$measurement_temp_href);
				# my $num  = keys(%$measurement_temp_href);
				# S_w2log( 5, "Data dump for $SPI_node : \n $data \n" );
				# S_w2log( 5, "number of keys for $SPI_node : \n $num \n" );

				@{$SPI_data}{ keys %$measurement_temp_href } = values %$measurement_temp_href;

			}
		}

		S_teststep( "Check the sequence of SPI commands", 'AUTO_NBR', 'check_the_sequence' );    #measurement 3
		S_w2rep( "Offline evaluation of the trace captured with SPIMaid", 'red' );

		S_teststep( "Check the ITM test status for test.", 'AUTO_NBR' );                         #measurement 4
		$itmstarted_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );

		$itmfinished_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		$itmstarted_PST_final  = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestStarted) );
		$itmfinished_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFinished) );

		$itmskipped_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestSkipped) );

		$itmfailed_PST_final = S_aref2hex( PD_ReadMemoryByName($tcpar_PD_ITMTestFailed) );

		S_teststep( "Read the fault recorder.", 'AUTO_NBR', 'read_the_fault_B' );    #measurement 5
		$faultsafterStimulation = PD_ReadFaultMemory();
	}
	return 1;
}

sub TC_evaluation {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {

		S_teststep_expected("'$tcpar_PD_ITMTestStarted', '$tcpar_PD_ITMTestFinished', '$tcpar_PD_ITMTestSkipped', '$tcpar_PD_ITMTestFailed' with value");    #evaluation 1
		S_teststep_detected("ITM Test status is checked");
		my $itmstarted_byte = S_hex2dec( substr( $itmstarted, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test started bit", $itmstarted_byte, 'MASK', $tcpar_SVR_mask1 );

		my $itmfinished_byte = S_hex2dec( substr( $itmfinished, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test finished bit", $itmfinished_byte, 'MASK', $tcpar_SVR_mask1 );

		my $itmskipped_byte = S_hex2dec( substr( $itmskipped, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test skipped bit", $itmskipped_byte, 'MASK', $tcpar_SVR_mask0 );

		my $itmfailed_byte = S_hex2dec( substr( $itmfailed, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test failed bit", $itmfailed_byte, 'MASK', $tcpar_SVR_mask0 );

		my $itmstarted_byte_PST = S_hex2dec( substr( $itmstarted_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test started bit", $itmstarted_byte_PST, 'MASK', $tcpar_PST_mask1 );

		my $itmfinished_byte_PST = S_hex2dec( substr( $itmfinished_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test finished bit", $itmfinished_byte_PST, 'MASK', $tcpar_PST_mask1 );

		my $itmskipped_byte_HSPST = S_hex2dec( substr( $itmskipped_HSPST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_HSPST, 'MASK', $tcpar_PST_mask0 );

		my $itmfailed_byte_PST = S_hex2dec( substr( $itmfailed_PST, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test failed bit", $itmfailed_byte_PST, 'MASK', $tcpar_PST_mask0 );

		S_teststep_expected("No fault is qualified");                                                              #evaluation 2
		S_teststep_detected("detected faults ::");

		my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );

		my ( $verdict2, $sequence_time_value_href );

		if ( defined $tcpar_SPI_GetTime_href ) {
			( $verdict2, $sequence_time_value_href ) = GEN_EVAL_trace_sequence( $SPI_data, $tcpar_SPI_GetTime_href );
		}

		if ( $verdict2 eq 'PASS' ) {

			if ( defined $tcpar_SPI_EvalSignal_href ) {
				my $verdictSignals = GEN_EVAL_trace_signals( $SPI_data, $sequence_time_value_href, $tcpar_SPI_EvalSignal_href )
				  if ( defined $tcpar_SPI_EvalSignal_href );
			}
		}

		S_teststep_expected("'$tcpar_PD_ITMTestStarted', '$tcpar_PD_ITMTestFinished', '$tcpar_PD_ITMTestSkipped', '$tcpar_PD_ITMTestFailed' with value  ");    #evaluation 4
		S_teststep_detected("ITM Test status is checked");

		my $itmstarted_byte_final = S_hex2dec( substr( $itmstarted_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test started bit", $itmstarted_byte_final, 'MASK', $tcpar_SVR_mask1 );

		my $itmfinished_byte_final = S_hex2dec( substr( $itmfinished_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test finished bit", $itmfinished_byte_final, 'MASK', $tcpar_SVR_mask1 );

		my $itmskipped_byte_final = S_hex2dec( substr( $itmskipped_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test skipped bit", $itmskipped_byte_final, 'MASK', $tcpar_SVR_mask0 );

		my $itmfailed_byte_final = S_hex2dec( substr( $itmfailed_final, $tcpar_SVR_offset, $tcpar_SVR_byte ) );
		EVAL_evaluate_value( "read the SVR test failed bit", $itmfailed_byte_final, 'MASK', $tcpar_SVR_mask0 );

		my $itmstarted_byte_PST_final = S_hex2dec( substr( $itmstarted_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test started bit", $itmstarted_byte_PST_final, 'MASK', $tcpar_PST_mask1 );

		my $itmfinished_byte_PST_final = S_hex2dec( substr( $itmfinished_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test finished bit", $itmfinished_byte_PST_final, 'MASK', $tcpar_PST_mask1 );

		my $itmskipped_byte_PST_final = S_hex2dec( substr( $itmskipped_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test skipped bit", $itmskipped_byte_PST_final, 'MASK', $tcpar_PST_mask0 );

		my $itmfailed_byte_PST_final = S_hex2dec( substr( $itmfailed_PST_final, $tcpar_PST_offset, $tcpar_PST_byte ) );
		EVAL_evaluate_value( "read the HSPST test failed bit", $itmfailed_byte_PST_final, 'MASK', $tcpar_PST_mask0 );

		S_teststep_expected("No fault is qualified");    #evaluation 5
		S_teststep_detected("detected faults::");

		my $faultsVerdict_after = PD_evaluate_faults( $faultsafterStimulation, [] );
	}
	return 1;
}

sub TC_finalization {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {

		DEVICE_resetSquibTestCondition( $Const_sqm_DEVICE_NAME, $tcpar_condition );
		S_wait_ms(3000);

		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();

		my $FLT_final = PD_ReadFaultMemory();

		my $faultsVerdict_final = FM_evaluateFaults( $FLT_final, [] );
	}
	return 1;
}

sub CheckValidDevice {

	my $mapping = 1;

	# my $configured = 1;

	unless (defined $Const_sqm_DEVICE_NAME
		and $Const_sqm_DEVICE_NAME ne ''
		and $Const_sqm_DEVICE_NAME ne 'NONE' )
	{

		$mapping = 0;
	}

	return ($mapping);    #valid device name is present
}

1;
