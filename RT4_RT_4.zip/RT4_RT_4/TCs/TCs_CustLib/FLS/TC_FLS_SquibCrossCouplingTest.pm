#### TEST CASE MODULE
package TC_FLS_SquibCrossCouplingTest;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: FLS/TC_FLS_SquibCrossCouplingTest.pm 1.4 2020/05/26 15:53:09ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_FLS_FireloopManagement
#TS version in DOORS: 3.90
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use LIFT_PD;
use FuncLib_TNT_SYC_INTERFACE;
use LIFT_evaluation;
use LIFT_labcar;

#include further modules here

##################################

our $PURPOSE = "to check fire loop for shorts between squibs (highside/lowside)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_FLS_SquibCrossCouplingTest

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create a short between high side terminal of <squib1> and low side terminal of <squib2> (cross couple)

2. Read fault recorder

3. Read the squib resistance of <squib1> and <squib2> using PD variable <variable>.

4. Reset ECU and read the fault recorder after init

5. Read the squib resistance of <squib1> and <squib2> using PD variable <variable>.

6. Remove the short between the squib terminals and read the fault recorder (note: reset not required)

7. Read the squib resistance of <squib1> and <squib2> using PD variable <variable>.

8. Reset ECU and read the fault recorder after init.

9. Read the squib resistance of <squib1> and <squib2> using PD variable <variable>.


I<B<Evaluation>>

2. Cross coupling fault <FLTmand> is not qualified for <squib1> and <squib2>.

3. The squib resistance of <squib1> is <res1> and <squib2> is <res2>.

4. Squib cross coupling fault <FLTmand> is qualified for <squib1> and <squib2>

5.  The squib resistance of <squib1> is <res3> and <squib2> is <res4>. The resistance values are different compared resistance values measured in step3.

6. Cross coupling faults remain qualified

7. The squib resistance of <squib1> is <res5> and <squib2> is <res6>. The resistance values are equal to resistance values measured in step3.

8. Cross coupling faults are dequalified. 

9. The squib resistance of <squib1> is <res7> and <squib2> is <res8>. The resistance values are different compared resistance values measured in step7.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'squib1' => 
	SCALAR 'squib2' => 
	SCALAR 'FLTmand' => 
	SCALAR 'FLTopt1_Short2Gnd' => 
	SCALAR 'FLTopt2_Short2Bat' => 
	SCALAR 'FLTopt3_Short' =>
	SCALAR 'variable' => 


=head2 PARAMETER EXAMPLES

	purpose	= 'to check fire loop for shorts between squibs (highside/lowside)'
	
	squib1 = '<Test Heading 1>'
	squib2 = '<Test Heading 2>'
	
	FLTmand= 'rb_sqm_Crosscoupling' 
	FLTopt1_Short2Gnd = 'rb_sqm_TerminalShort2Gnd'
	FLTopt2_Short2Bat = 'rb_sqm_TerminalShort2Bat'
	FLTopt3_Short = 'rb_sqm_SquibResistanceShort'
	variable = 'rb_sqmm_ResistanceValue_au16'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_squib1;
my $tcpar_squib2;
my $tcpar_FLTmand;
my $tcpar_FLTopt1_Short2Gnd;
my $tcpar_FLTopt2_Short2Bat;
my $tcpar_FLTopt3_Short;
my $tcpar_wait_time;

################ global parameter declaration ###################
#add any global variables here
my (
	$defaultpar_squib1, $defaultpar_squib2, $SquibFaultQualiTime, $Status_FaultQualified, $Status_FaultStored, $Const_sqm_DEVICE1_NAME, $Const_sqm_DEVICE2_NAME, $resistance1, $resistance2,
	$resistance3,       $resistance4,       $resistance5,         $resistance6,           $resistance7,        $resistance8,            $SQ1_configured,         $SQ2_configured
);
my (%flt_mem_struct_observed);
my $valid_mapping;
my $valid_squib;
my $verdict;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose           = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_squib1            = S_read_mandatory_testcase_parameter('squib1');
	$tcpar_squib2            = S_read_mandatory_testcase_parameter('squib2');
	$tcpar_FLTmand           = S_read_mandatory_testcase_parameter('FLTmand');
	$tcpar_FLTopt1_Short2Gnd = S_read_mandatory_testcase_parameter('FLTopt1_Short2Gnd');
	$tcpar_FLTopt2_Short2Bat = S_read_mandatory_testcase_parameter('FLTopt2_Short2Bat');
	$tcpar_FLTopt3_Short     = S_read_mandatory_testcase_parameter('FLTopt3_Short');
	$tcpar_wait_time         = S_read_mandatory_testcase_parameter('wait_time');
	$SquibFaultQualiTime     = 6000;
	$Status_FaultQualified   = '0bxxxxx1x1';                                               #stored and filtered
	$Status_FaultStored      = '0bxxxxx1x0';                                               #stored and not filtered
	$Const_sqm_DEVICE1_NAME  = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_squib1);
	$Const_sqm_DEVICE2_NAME  = DEVICE_fetchDeviceNamebyDeviceNumber($tcpar_squib2);

	unless ( defined $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE1_NAME ne '' and $Const_sqm_DEVICE1_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;

		return 1;
	}

	unless ( defined $Const_sqm_DEVICE2_NAME and $Const_sqm_DEVICE2_NAME ne '' and $Const_sqm_DEVICE2_NAME ne 'NONE' ) {
		S_w2rep( 'Squib not configure in project => Verdict set to NONE', 'blue' );
		S_set_verdict(VERDICT_NONE);
		$verdict = VERDICT_NONE;

		return 1;
	}
	return 1;
}

sub TC_initialization {

	#before proceeding check if a valid device is configured for both
	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
		GEN_StandardPrepNoFault();
		my $FLT_initial = PD_ReadFaultMemory();
		my $faultsVerdict_initial = FM_evaluateFaults( $FLT_initial, [] );

	}
	return 1;
}

sub TC_stimulation_and_measurement {

	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_teststep( "Create a short between high side terminal of '$Const_sqm_DEVICE1_NAME' and low side terminal of '$Const_sqm_DEVICE2_NAME' (cross couple)", 'AUTO_NBR' );
		my $status = DEVICE_shortLines( "$Const_sqm_DEVICE1_NAME" . '+', "$Const_sqm_DEVICE2_NAME" . '-' );
		unless ( defined $status and $status == 1 ) {
			S_w2rep( "Cross couple is not created successfully! Not proceeding", 'red' );
			$PURPOSE = "Cross couple is not created successfully";
			return 0;
		}
		S_wait_ms($SquibFaultQualiTime);

		S_teststep( "Read fault recorder", 'AUTO_NBR', 'read_fault_recorder' );    #measurement 1
		$flt_mem_struct_observed{'step2'} = PD_ReadFaultMemory();

		S_teststep( "Reset ECU and read the fault recorder after init", 'AUTO_NBR', 'reset_ecu_and_A' );    #measurement 3
		LC_ECU_Reset();
		$flt_mem_struct_observed{'step3'} = PD_ReadFaultMemory();

		#		S_teststep( "Read the squib resistance of '$Const_sqm_DEVICE1_NAME' and '$Const_sqm_DEVICE2_NAME' ", 'AUTO_NBR', 'read_the_squib_A' );    #measurement 4
		#		( $resistance1, $resistance2 ) = tc_ReadResistance();

		S_wait_ms($tcpar_wait_time);

		#		S_teststep( "Read the squib resistance of '$Const_sqm_DEVICE1_NAME' and '$Const_sqm_DEVICE2_NAME'", 'AUTO_NBR', 'read_the_squib_B' );     #measurement 2
		#		( $resistance3, $resistance4 ) = tc_ReadResistance();

		S_teststep( "Remove the short between the squib terminals and read the fault recorder (note: reset not required)", 'AUTO_NBR', 'remove_the_short' );    #measurement 5
		DEVICE_undoShortLines();
		S_wait_ms($SquibFaultQualiTime);
		$flt_mem_struct_observed{'step7'} = PD_ReadFaultMemory();

		#		S_teststep( "Read the squib resistance of '$Const_sqm_DEVICE1_NAME' and '$Const_sqm_DEVICE2_NAME' ", 'AUTO_NBR', 'read_the_squib_C' );                                      #measurement 6
		#		( $resistance5, $resistance6 ) = tc_ReadResistance();

		S_teststep( "Reset ECU and read the fault recorder after init.", 'AUTO_NBR', 'reset_ecu_and_B' );                                                       #measurement 7
		LC_ECU_Reset();
		$flt_mem_struct_observed{'step9'} = PD_ReadFaultMemory();

		#		S_teststep( "Read the squib resistance of '$tcpar_squib1' and '$tcpar_squib2'", 'AUTO_NBR', 'read_the_squib_D' );                                       #measurement 8
		#		( $resistance7, $resistance8 ) = tc_ReadResistance();
	}
	return 1;
}

sub TC_evaluation {
	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		my $faultname_CC1 = $tcpar_FLTmand . $Const_sqm_DEVICE1_NAME . '_flt';
		my $faultname_CC2 = $tcpar_FLTmand . $Const_sqm_DEVICE2_NAME . '_flt';
		my @tcpar_FLTmand = ( $faultname_CC1, $faultname_CC2 );
		my $faultopt1     = $tcpar_FLTopt1_Short2Gnd . $Const_sqm_DEVICE1_NAME . '_flt';
		my $faultopt2     = $tcpar_FLTopt1_Short2Gnd . $Const_sqm_DEVICE2_NAME . '_flt';
		my $faultopt3     = $tcpar_FLTopt2_Short2Bat . $Const_sqm_DEVICE1_NAME . '_flt';
		my $faultopt4     = $tcpar_FLTopt2_Short2Bat . $Const_sqm_DEVICE2_NAME . '_flt';
		my $faultopt5     = $tcpar_FLTopt3_Short     . $Const_sqm_DEVICE1_NAME . '_flt';
		my $faultopt6     = $tcpar_FLTopt3_Short     . $Const_sqm_DEVICE2_NAME . '_flt';
		my @tcpar_FLTopt  = ( $faultopt1, $faultopt2, $faultopt3, $faultopt4,$faultopt5,$faultopt6);

		S_teststep( "Evaluation for Step 2: Cross coupling fault is not qualified for $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE2_NAME",'AUTO_NBR');
		FM_checkFaultStatus( $flt_mem_struct_observed{'step2'}, $faultname_CC1, 0x00 );    #eval faultname, status
		FM_checkFaultStatus( $flt_mem_struct_observed{'step2'}, $faultname_CC2, 0x00 );    #eval DTC, status
		FM_evaluateFaults( $flt_mem_struct_observed{'step2'}, [], \@tcpar_FLTopt );        #This fault was created during steady state

		S_teststep( "Evaluation for Step 3: Squib cross coupling fault is qualified for $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE2_NAME",'AUTO_NBR' );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $faultname_CC1, $Status_FaultQualified );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step3'}, $faultname_CC2, $Status_FaultQualified );
		FM_evaluateFaults( $flt_mem_struct_observed{'step3'}, \@tcpar_FLTmand, \@tcpar_FLTopt );    #confirm that no other faults are present

	  #	if (    ( $resistance3 == $resistance1 )
	  #		and ( $resistance4 == $resistance2 )
	  #	  )    #due to steady state short2bat or short2gnd fault created during step 1 for any one of the squibs, the squib measurement result is zero for that squib. After ECUReset when CC fault is detected, the squib measurement result is latched to zero (last POC measuremnt result for that squib.
	  #	{
	  #		S_set_verdict(VERDICT_PASS);
	  #	}
	  #	else {
	  #		S_set_verdict(VERDICT_FAIL);
	  #	}

		S_teststep( "Evaluation for Step 7: Cross coupling faults remain qualified",'AUTO_NBR');
		FM_checkFaultStatus( $flt_mem_struct_observed{'step7'}, $faultname_CC1, $Status_FaultQualified );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step7'}, $faultname_CC2, $Status_FaultQualified );
		FM_evaluateFaults( $flt_mem_struct_observed{'step7'}, \@tcpar_FLTmand, \@tcpar_FLTopt );    #confirm that no other faults are present
		                                                                                            #S_w2rep( "Evaluation for Step 8 : The resistance values are same compared to resistance values measured in step5.", 'blue' );
		                                                                                            #if ( ( $resistance5 == $resistance3 ) and ( $resistance6 == $resistance4 ) ) {
		                                                                                            #S_set_verdict(VERDICT_PASS);
		                                                                                            #	}
		                                                                                            #	else {
		                                                                                            #		S_set_verdict(VERDICT_FAIL);
		                                                                                            #	}

		S_teststep( "Evaluation for Step 9: Cross coupling faults are dequalified.",'AUTO_NBR');
		FM_checkFaultStatus( $flt_mem_struct_observed{'step9'}, $faultname_CC1, $Status_FaultStored );
		FM_checkFaultStatus( $flt_mem_struct_observed{'step9'}, $faultname_CC2, $Status_FaultStored );
		FM_evaluateFaults( $flt_mem_struct_observed{'step9'}, \@tcpar_FLTmand, \@tcpar_FLTopt );    #confirm that no other faults are present

		#	S_w2rep( "Evaluation for Step 10 : The resistance values are different compared to resistance values measured in step7.", 'blue' );
		#	if ( ( $resistance7 != $resistance5 ) and ( $resistance8 != $resistance6 ) ) {
		#		S_set_verdict(VERDICT_PASS);
		#	}
		#	else {
		#		S_set_verdict(VERDICT_FAIL);
		#	}

	}
	return 1;
}

sub TC_finalization {
	if ( $verdict eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
		S_w2rep( 'Erase fault recorder', 'AUTO_NBR' );
		PD_ClearFaultMemory();
		S_wait_ms('TIMER_ECU_READY');

		my $FLT_final = PD_ReadFaultMemory();

		S_wait_ms('TIMER_ECU_READY');

		my $faultsVerdict_final = FM_evaluateFaults( $FLT_final, [] );
	}
	return 1;
}

sub CheckValidDevice {

	my $mapping    = 1;
	my $configured = 1;

	unless ( defined $Const_sqm_DEVICE1_NAME and $Const_sqm_DEVICE1_NAME ne '' and $Const_sqm_DEVICE1_NAME ne 'NONE' ) {

		$mapping = 0;
	}
	unless ( defined $Const_sqm_DEVICE2_NAME and $Const_sqm_DEVICE2_NAME ne '' and $Const_sqm_DEVICE2_NAME ne 'NONE' ) {

		$mapping = 0;
	}

	( my $Real1, my $Monitored_ID1, my $Prog1 ) = PD_get_device_config($Const_sqm_DEVICE1_NAME);
	( my $Real2, my $Monitored_ID2, my $Prog2 ) = PD_get_device_config($Const_sqm_DEVICE2_NAME);

	if ( ( $Prog1 == 0 ) or ( $Prog2 == 0 ) ) {
		$configured = 0;
	}

	return ( $mapping, $configured );                                                               #valid device name is present
}

sub tc_ReadResistance {
	my ( $res1, $res2 );
	( my $result1, my $calc_array_idx1, my $asic_connection1, my $asic_connectionCBR1, my $asic_connectionIGH1, my $asic_connectionIGL1 ) = SYC_SQUIB_get_ASIC_connection($Const_sqm_DEVICE1_NAME);
	$asic_connectionCBR1 = $asic_connectionCBR1 - 1;
	$asic_connectionIGH1 = $asic_connectionIGH1 - 1;
	$res1                = S_aref2hex( PD_ReadMemoryByName("rb_sqmm_ResistanceValue_au16($asic_connectionCBR1)($asic_connectionIGH1)") );
	$res1                = ( S_hex2dec($res1) ) / 100;
	S_w2rep("The resistance value of $Const_sqm_DEVICE1_NAME is $res1 ohms");
	( my $result2, my $calc_array_idx2, my $asic_connection2, my $asic_connectionCBR2, my $asic_connectionIGH2, my $asic_connectionIGL2 ) = SYC_SQUIB_get_ASIC_connection($Const_sqm_DEVICE2_NAME);
	$asic_connectionCBR2 = $asic_connectionCBR2 - 1;
	$asic_connectionIGH2 = $asic_connectionIGH2 - 1;
	$res2                = S_aref2hex( PD_ReadMemoryByName("rb_sqmm_ResistanceValue_au16($asic_connectionCBR2)($asic_connectionIGH2)") );
	$res2                = ( S_hex2dec($res2) ) / 100;

	S_w2rep("The resistance value of $Const_sqm_DEVICE2_NAME is $res2 ohms");
	return ( $res1, $res2 );
}
1;
