#### TEST CASE MODULE
package TC_LFM_Lifetimecounter_Aging;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: LFM/TC_LFM_Lifetimecounter_Aging.pm 1.1 2020/01/24 18:15:11ICT EXTERNAL Divya Jayeshkumar Soni (Brigosha, RBEI/ESA-PW5) (DIO4KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_spi_access;
use LIFT_spi_instruction_set;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_LFM_Lifetimecounter_Aging

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1.Start with a fault free ECU. 

2.Qualify an <internal fail safe fault> and read PFM.

3. Read the NVM block of <LifeTime counter>.

4. Dequalify the <internal fail safe fault> and Reset the ECU with <condition> and read NVM block of <life time counter>.


I<B<Evaluation>>

2. ECU will be in <mode2>.

3. Lifetime counter will be  1.

4.There will be no change in the value of lifetime counter. Life time counter will hold the same value from previous POC.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => 
	SCALAR 'condition' => 
	SCALAR 'condition' => 
	SCALAR 'LifeTime_counter' => 
	SCALAR 'mode1' => 
	SCALAR 'mode2' => 
	SCALAR 'Read_PFM' => 
	SCALAR 'Internal_fail_safe_fault' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To test Aging shall have no influence on the values of the lifetime counters.' 
	
	
	condition ='<Test Heading 2>'
	condition = Number of resets 
	LifeTime_counter = 'lfm_LifeTimeCounters'
	
	
	mode1 = 'Idle'
	mode2 = 'Normal driving'
	Read_PFM ='<Test Heading 1>'
	Internal_fail_safe_fault = 'rb_wdm_WDFaultMasterWD1_flt'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_condition;
my $tcpar_LifeTime_counter;
my $tcpar_mode1;
my $tcpar_mode2;
my $tcpar_Read_PFM;
my $tcpar_Internal_fail_safe_fault;
my @tcpar_expected;
my $tcpar_Node;
my $tcpar_command;
my $tcpar_USE_SPI_SIGNALS;
my $tcpar_signal;

################ global parameter declaration ###################
#add any global variables here
my $resp_aref;
my $spi_load_signal        = {};
my $erase;
my $erase1;
my @resp_aref;
my $optional_flt = ['rb_sqm_SquibResistanceOpenAB2FD_flt','rb_pom_VerOpenLine_flt','rb_pom_ESRhigh_flt','rb_lfm_LifeTimeLamp_flt'];
my $mandatory_flt = ['rb_wdm_WDFaultMasterWD1_flt'];
my $USE_SPI_SIGNALS;
my $detected_fault ;

my @optFaults_Quali;
my @optFaults_DeQuali;
my $i;


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_condition =  GEN_Read_mandatory_testcase_parameter( 'condition' );
	$tcpar_LifeTime_counter =  GEN_Read_mandatory_testcase_parameter( 'LifeTime_counter' );
	$tcpar_mode1 =  GEN_Read_mandatory_testcase_parameter( 'mode1' );
	$tcpar_mode2 =  GEN_Read_mandatory_testcase_parameter( 'mode2' );
	$tcpar_Read_PFM =  GEN_Read_mandatory_testcase_parameter( 'Read_PFM' );
	$tcpar_Internal_fail_safe_fault =  GEN_Read_mandatory_testcase_parameter( 'Internal_fail_safe_fault' );
	@tcpar_expected =  GEN_Read_mandatory_testcase_parameter( 'expected' );
	$tcpar_Node =  GEN_Read_mandatory_testcase_parameter( 'Node' );
	$tcpar_command =  GEN_Read_mandatory_testcase_parameter( 'command' );
	$tcpar_USE_SPI_SIGNALS = GEN_Read_mandatory_testcase_parameter( 'USE_SPI_SIGNALS' );
	$tcpar_signal = GEN_Read_optional_testcase_parameter( 'signal' );


	return 1;
}

sub TC_initialization {

	
	LC_ECU_On();
    S_wait_ms(1000);

    PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Start with a fault free ECU. ", 'AUTO_NBR');
	
	my $flt_mem_struct = PD_ReadFaultMemory(1);

    S_teststep_2nd_level( "PD_ClearFaultMemory", 'NO_AUTO_NBR' );
    PD_ClearFaultMemory();
    S_wait_ms(2000);
    my  $flt_mem_struct = PD_ReadFaultMemory(1);

	S_wait_ms(1000);
	
	
	
	

	S_teststep("Qualify an '$tcpar_Internal_fail_safe_fault' and read PFM.", 'AUTO_NBR');			#measurement 1
	
	LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	
    if ( $tcpar_USE_SPI_SIGNALS eq 'yes' ) {
	

		SPI_load_signal_manipulation(
				'Node'        => $tcpar_Node,
				'Command'     => $tcpar_command,
				'Signal'      => $tcpar_signal, 
				'SignalValue' => '1',
		);
	
		
	
	}
	
	SPI_start_manipulation();
	 S_wait_ms(2000);
	 		
	S_teststep( "Power ON ECU", 'AUTO_NBR' );
    LC_ECU_On();
	S_wait_ms(2000);
	
	
	#EVENT1
	

	if($tcpar_condition eq '1'){
		
	
		for($i = 0; $i<2; $i++){
		
			PD_ECUreset( );
			S_wait_ms('3000');
			
		
			
		}
	
	}
	

	elsif($tcpar_condition eq '25'){
		
		for($i = 0; $i<25; $i++){
		
			PD_ECUreset( );
			S_wait_ms('4000');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '127'){
	
		for($i = 0; $i<127; $i++){
		
			PD_ECUreset( );
			S_wait_ms('5000');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '128'){
	
		for($i = 0; $i<128; $i++){
		
			PD_ECUreset( );
			S_wait_ms('5000');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '129'){
	
		for($i = 0; $i<129; $i++){
		
			PD_ECUreset( );
			S_wait_ms('5000');
			
		}
	
	
	}
	
	
	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct,$mandatory_flt, $optional_flt);
	
	my $detected_fault = PD_check_fault_status($flt_mem_struct, $tcpar_Internal_fail_safe_fault ,'0bxxxxx110');
	
	
	S_teststep_detected("Fault Qualified : $detected_fault ");
	

	S_teststep("Read the NVM block of '$tcpar_LifeTime_counter'.", 'AUTO_NBR');			#measurement 2
		
	
	$resp_aref = PD_ReadNVMSection($tcpar_LifeTime_counter); 
	

	
	S_teststep_expected("'$tcpar_LifeTime_counter' will be 1.");			#evaluation 2
	S_teststep_detected("Detected $tcpar_LifeTime_counter value is: @$resp_aref");
	EVAL_evaluate_value("Evaluating response :",@$resp_aref[1],'==',$tcpar_expected[0]) unless $main::opt_offline;	
	

	S_teststep("Dequalify the '$tcpar_Internal_fail_safe_fault' and Reset the ECU with '$tcpar_condition' and read NVM block of '$tcpar_LifeTime_counter'.", 'AUTO_NBR');			#measurement 3


   #dequalify the fault
	PD_ClearFaultMemory();

	my $flt_mem_struct = PD_ReadFaultMemory(); 
	S_teststep_expected("Fault should be DE - qualified");
	my $VERDICT = PD_evaluate_faults( $flt_mem_struct, [], $optional_flt);
	
	my $detected_fault = PD_check_fault_status($flt_mem_struct, $tcpar_Internal_fail_safe_fault ,'0bxxxxxxx0');
	
	
	S_teststep_detected("Fault should be DE- Qualified : $detected_fault ");
	
	if($tcpar_condition eq '1'){
	
		for($i = 0; $i<1; $i++){
		
			PD_ECUreset( );
			S_wait_ms('TIMER_ECU_READY');
			
		}
	
	}
	
	elsif($tcpar_condition eq '25'){
		
		for($i = 0; $i<25; $i++){
		
			PD_ECUreset( );
			S_wait_ms('TIMER_ECU_READY');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '127'){
	
		for($i = 0; $i<127; $i++){
		
			PD_ECUreset( );
			S_wait_ms('TIMER_ECU_READY');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '128'){
	
		for($i = 0; $i<128; $i++){
		
			PD_ECUreset( );
			S_wait_ms('TIMER_ECU_READY');
			
		}
	
	
	}
	
	elsif($tcpar_condition eq '129'){
	
		for($i = 0; $i<129; $i++){
		
			PD_ECUreset( );
			S_wait_ms('TIMER_ECU_READY');
			
		}
	
	
	}
		

	SPI_stop_manipulation();
	
	
	$resp_aref = PD_ReadNVMSection($tcpar_LifeTime_counter); #will give [74,00,00,00,6F,40,4A,00]
	
	
	S_teststep_expected("There will be no change in the value of lifetime counter. $tcpar_LifeTime_counter will hold the same value from previous POC.");			#evaluation 2
	S_teststep_detected("Detected $tcpar_LifeTime_counter value is: @$resp_aref");
	EVAL_evaluate_value("Evaluating response :",@$resp_aref[1],'==',$tcpar_expected[0]) unless $main::opt_offline;	
	
	
	

	return 1;
}

sub TC_evaluation {


	S_w2rep("evaluation is done in Stimulation and Measurement Function");

	

	return 1;
}

sub TC_finalization {

	

	PD_ECUreset();
	S_wait_ms( 'TIMER_ECU_READY' );

	PD_ClearFaultMemory();

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;