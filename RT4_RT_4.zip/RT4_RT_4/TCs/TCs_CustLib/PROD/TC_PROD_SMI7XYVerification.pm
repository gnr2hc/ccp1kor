#### TEST CASE MODULE
package TC_PROD_SMI7XYVerification;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: PROD/TC_PROD_SMI7XYVerification.pm 1.6 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.48
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = "check the SMI7 verification services - positive and negative response handling";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_SMI7XYVerification

=head1 PURPOSE

check the SMI7 verification services - positive and negative response handling

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. PROD_Standard_Preparation

2. PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Create <TestCondition>

2. Send <Prod_Diag_Request> to read the sensor data.


I<B<Evaluation>>

2. 

<Prod_Diag_Response> is received

response is received within <ResponseTime> ms


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'TestCondition' => condition to be created for this test
	SCALAR 'Prod_Diag_Request' => request label from DIAG mapping file
	SCALAR 'Prod_Diag_Response' => response label from DIAG mapping file
	SCALAR 'NumberOfSamples' => num of samples to be taken for calculation (byte 6 of request)
	SCALAR 'ResponseTime' => max time within which response should be received
	SCALAR 'SamplingDetails' => type of processing to be done (byte2 to 5 of request)

=head2 PARAMETER EXAMPLES

	purpose = 'To test the SMI7XY Verification services - positive response'
	
	TestCondition = 'none' #no special condition
	Prod_Diag_Request = 'SMI7XY_Verification'
	Prod_Diag_Response = 'PR_SMI7XY_Verification'
	NumberOfSamples = '00 01'
	ResponseTime =21 #ms 
	SamplingDetails = '00 00 00 00'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_TestCondition;
my $tcpar_Prod_Diag_Request;
my $tcpar_Prod_Diag_Response;
my $tcpar_NumberOfSamples;
my $tcpar_ResponseTime;
my $tcpar_SamplingDetails;
my $defaultpar_Signal;
my $defaultpar_State;
my $defaultpar_State2;
my $tcpar_Group_Byte_Unused;
################ global parameter declaration ###################
#add any global variables here
my $Trace_StoredfilePath;
my $PDreqresp_hashref;
my $requestLabel;
my @response_array;
my ( $lamp_state_beforereset_href, $lamp_state_afterreset_href );
###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_TestCondition      = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_Prod_Diag_Request  = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_Prod_Diag_Response = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$tcpar_NumberOfSamples    = S_read_mandatory_testcase_parameter('NumberOfSamples');
	$tcpar_ResponseTime       = S_read_mandatory_testcase_parameter('ResponseTime');
	$tcpar_SamplingDetails    = S_read_mandatory_testcase_parameter('SamplingDetails');
	$defaultpar_Signal        = S_read_optional_testcase_parameter('Signal');
	$defaultpar_State         = S_read_optional_testcase_parameter('State');
	$defaultpar_State2        = S_read_optional_testcase_parameter('State2');
	$tcpar_Group_Byte_Unused  = S_read_optional_testcase_parameter('Group_Byte_Unused');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	my $modified_request;
	my $nrcInfo;
	$requestLabel->{'NumberOfSamples'} = $tcpar_NumberOfSamples;
	$requestLabel->{'SamplingDetails'} = $tcpar_SamplingDetails;

	S_teststep( "Create '$tcpar_TestCondition' condition", 'AUTO_NBR' );
	if ( $tcpar_TestCondition eq 'none' ) {
		S_w2rep("TestCondition is $tcpar_TestCondition: No special condition to be set for this test case", 'blue');
	}
	elsif ( $tcpar_TestCondition eq 'ESPSensor_AccCh2LfChannelDefective' ) {
		S_set_error( "This condition ($tcpar_TestCondition) cannot be created currently!", 0 );    #warning!
		return 0;
	}
	elsif ( $tcpar_TestCondition eq 'RolloverAndPitchSensor_SensorModuleDefective' ) {
		S_set_error( "This condition ($tcpar_TestCondition) cannot be created currently!", 0 );    #warning!
		return 0;
	}
	elsif ( $tcpar_TestCondition eq 'BlockLengthMore' ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, +1 );
		$nrcInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response);
	}
	elsif ( $tcpar_TestCondition eq 'BlockLengthLess' ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request", $requestLabel, -1 );
		$nrcInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response);
	}
	elsif ( $tcpar_TestCondition =~ /VehSpeed_/ ) {
		$tcpar_TestCondition =~ s/(\w+)\_(\d+\.\d+)/$2/g;
		$tcpar_TestCondition = $1;    #take value from condition
		CA_write_can_signal( $defaultpar_Signal, $2, 'phys' );
	}

	S_teststep( "Send '$tcpar_Prod_Diag_Request' to read the sensor data.", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	if ( $tcpar_TestCondition eq 'BlockLengthMore' ) {
		DIAG_PD_request( $modified_request, $nrcInfo->{'Response'}, $nrcInfo->{'Mode'}, $nrcInfo->{'Desc'} );
	}
	elsif ( $tcpar_TestCondition eq 'BlockLengthLess' ) {
		DIAG_PD_request( $modified_request, $nrcInfo->{'Response'}, $nrcInfo->{'Mode'}, $nrcInfo->{'Desc'} );
	}
	elsif ( ( $tcpar_TestCondition eq 'none' ) or ( $tcpar_TestCondition =~ /VehSpeed/ ) ) {
		my $response_string = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );
		@response_array = split( / /, $response_string );
		foreach (@response_array) { $_ = "0x$_"; }
	}

	S_teststep( "Stored and take data struct from trace", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(2);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");
	$PDreqresp_hashref = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );

	S_teststep( "Start canoe to remove timeout CAN", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 3000, 'wait for COM timeout dequalify' );

	if ( defined $defaultpar_State and defined $defaultpar_State2 ) {
		S_teststep( "Read WL before do the reset", 'AUTO_NBR', 'check WL before reset' );
		$lamp_state_beforereset_href = PD_ReadLampStates();

		S_teststep( "Reset ECU", 'AUTO_NBR' );
		LC_ECU_Reset();
		S_wait_ms(5000);

		S_teststep( "Read WL after do the reset", 'AUTO_NBR', 'check WL after reset' );
		$lamp_state_afterreset_href = PD_ReadLampStates();
	}

	return 1;
}

sub TC_evaluation {

	#offline mode handling
	if ($main::opt_offline) {
		foreach my $index ( 0 .. 414 ) {
			$response_array[$index] = 0x00;
		}
	}

	S_teststep( "Check response is received within '$tcpar_ResponseTime' ms", 'NO_AUTO_NBR' );
	if ( $tcpar_Prod_Diag_Response !~ m/^NR_/ ) {
		my $respTime = { "REQ_$tcpar_Prod_Diag_Request" => "$tcpar_ResponseTime%0", };
		DIAG_EVAL_ResponseTime_from_dataref( $PDreqresp_hashref, $respTime, $requestLabel, undef, undef, '<=' );
	}
	else {
		S_w2rep("Timing will be verified only for positive responses", 'blue');

	}

	S_teststep( "Check: Unused (not configured) sensor bytes in the response are reported as 0", 'NO_AUTO_NBR' );
	S_w2rep("Second SMI sensor is not supported in Core Assets, so corresponding response bytes should be 0", 'blue');
	if ( $tcpar_Prod_Diag_Response !~ m/^NR_/ ) {
		S_w2rep("Check second SMI700/705/740 sensor data, check rqmt:https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-659-0003ea7f?doors.view=00000006", 'blue');
		foreach (@$tcpar_Group_Byte_Unused) {
			$_ =~ /(\d+)(..)(\d+)/;
			foreach ( $1 .. $3 ) {
				EVAL_evaluate_value( "Second SMI sensor for byte: $_", $response_array[ $_ - 1 ], '==', 0x00 );
			}
		}
	}
	else {
		S_w2rep("Unused bytes will be verified only for positive responses", 'blue');
	}

	if ( defined $defaultpar_State and defined $defaultpar_State2 ) {

		S_teststep_expected( "The state WL should be in state '$defaultpar_State'", 'check WL before reset' );
		S_teststep_detected( "Detected WL state is: '$lamp_state_beforereset_href->{'System Warning Lamp'}'", 'check WL before reset' );
		EVAL_evaluate_string( "Check WL before reset", $defaultpar_State, uc $lamp_state_beforereset_href->{'System Warning Lamp'} );

		S_teststep_expected( "The state WL should be in state '$defaultpar_State2'", 'check WL after reset' );
		S_teststep_detected( "Detected WL state is: '$lamp_state_afterreset_href->{'System Warning Lamp'}'", 'check WL after reset' );
		EVAL_evaluate_string( "Check WL before reset", $defaultpar_State2, uc $lamp_state_afterreset_href->{'System Warning Lamp'} );
	}
	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 1000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
