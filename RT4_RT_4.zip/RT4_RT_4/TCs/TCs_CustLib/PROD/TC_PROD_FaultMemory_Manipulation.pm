#### TEST CASE MODULE
package TC_PROD_FaultMemory_Manipulation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_FaultMemory_Manipulation.pm 1.4 2020/04/28 13:46:36ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = 'To check the Fault manupulation request and response and is behaviour';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_FaultMemory_Manipulation

=head1 PURPOSE

To check the Fault manupulation request and response and is behaviour

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request> with Request type 0x01 to qualify a  fault of type <FaultType>

2. Disconnect a squib and read the fault memory after 6 seconds (External fault)

3. Reset the ECU and read the fault memory after init (External fault)

4. Send <Prod_Diag_Request> with Request type 0x00 to dequalify the fault created in step 1


I<B<Evaluation>>

1. <Prod_Diag_Response> is received and this fault is qualified in the fault memory

2. Squib Openline fault is not qualified in the fault memory (since Test Mode is active)

3. Squib Openline fault is qualified in the fault memory (since Test Mode is not active in new power on cycle)

4. <Prod_Diag_Response> is received and this fault is dequalified in the fault memory


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Fault_Name' => 
	SCALAR 'purpose' => 
	SCALAR 'FaultType' => 
	SCALAR 'Prod_Diag_Request' => 
	SCALAR 'Prod_Diag_Response' => 
	SCALAR 'Request_Type_Fault_Creation' => 
	SCALAR 'Request_Type_Fault_Removal' => 


=head2 PARAMETER EXAMPLES

	purpose ='to check the fault memory manipulation request and response and is behaviour'
	
	FaultType = '<Test Heading>'
	
	Prod_Diag_Request  = 'Fault_Memory_Manipulation'
	Prod_Diag_Response = 'PR_Fault_Memory_Manipulation'
	
	Request_Type_Fault_Creation = '01'
	Request_Type_Fault_Removal = '00'
	Fault_Name='rb_sqm_LowsidePowerstageAB1FD_flt'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_FaultType, $defaultpar_Squib_Name, $defaultpar_purpose, $defaultpar_Prod_Diag_Request, $defaultpar_Prod_Diag_Response, $defaultpar_Request_Type_Fault_Creation, $defaultpar_Request_Type_Fault_Removal, $defaultpar_Fault_Name, );

################ global parameter declaration ##################

my ( $flt_mem_struc_qualify, $flt_mem_struc_dequalify, $flt_mem_struc_aft_disconnectline, $flt_mem_struc_aft_reset, $PD_RequestLabel, );

my $fault_ID;
my $Event_ID_withspaces_string;

sub TC_set_parameters {

	$defaultpar_purpose                     = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request           = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$defaultpar_Prod_Diag_Response          = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$defaultpar_Request_Type_Fault_Creation = S_read_mandatory_testcase_parameter('Request_Type_Fault_Creation');
	$defaultpar_Request_Type_Fault_Removal  = S_read_mandatory_testcase_parameter('Request_Type_Fault_Removal');
	$defaultpar_Fault_Name                  = S_read_mandatory_testcase_parameter('Fault_Name');
	$defaultpar_FaultType                   = S_read_mandatory_testcase_parameter('FaultType');
	$defaultpar_Squib_Name                  = S_read_mandatory_testcase_parameter('Squib_Name');

	#Get fault ID
	$fault_ID                   = PD_GetFaultID($defaultpar_Fault_Name);
	$fault_ID                   = sprintf( "%04X", $fault_ID );            # 2 bytes in request
	$Event_ID_withspaces_string = $fault_ID;
	$Event_ID_withspaces_string =~ s/(\w{2})(\w{2})/$1 $2/g;               #insert space into 2 byte ID

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Send '$defaultpar_Prod_Diag_Request' to Qualify the fault in the memory.", 'AUTO_NBR' );
	$PD_RequestLabel = {
		"EventID"      => "$Event_ID_withspaces_string",
		"Request_Type" => "$defaultpar_Request_Type_Fault_Creation",
	};

	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request", "$defaultpar_Prod_Diag_Response", $PD_RequestLabel );

	S_teststep( "Read fault memory after send request qualify fault", 'AUTO_NBR' );
	$flt_mem_struc_qualify = PD_ReadFaultMemory();

	S_teststep( "Disconnect a squib and read the fault memory after 6 seconds (External fault)", 'AUTO_NBR' );
	LC_DisconnectLine($defaultpar_Squib_Name);
	S_wait_ms( 6000, 'wait for 6 second to fault qualify' );

	S_teststep( "Read fault memory after deconnect squib $defaultpar_Squib_Name line ", 'AUTO_NBR' );
	$flt_mem_struc_aft_disconnectline = PD_ReadFaultMemory();

	S_teststep( "Do the reset", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms( 10000, 'wait for 10 second to fault qualify' );

	S_teststep( "Read fault memory after reset.", 'AUTO_NBR' );
	$flt_mem_struc_aft_reset = PD_ReadFaultMemory();

	S_teststep( "Send '$defaultpar_Prod_Diag_Request' to Dequalify the fault in the memory", 'AUTO_NBR' );
	$PD_RequestLabel = {
		"EventID"      => "$Event_ID_withspaces_string",
		"Request_Type" => "$defaultpar_Request_Type_Fault_Removal",
	};

	S_teststep_2nd_level( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Send the request: '$defaultpar_Prod_Diag_Request'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request", "$defaultpar_Prod_Diag_Response", $PD_RequestLabel );

	S_teststep( "Read fault memory after send request dequalify fault", 'AUTO_NBR' );
	$flt_mem_struc_dequalify = PD_ReadFaultMemory();

	return 1;

}

sub TC_evaluation {

	my $expect_qualified_state   = '0bxxxx1xx1';
	my $expect_dequalified_state = '0bxxxx1xx0';
	my $squib_openline_flt       = 'rb_sqm_SquibResistanceOpen' . $defaultpar_Squib_Name . '_flt';

	S_teststep( "Evaluation for Step :1. Verify the response of the '$defaultpar_Prod_Diag_Response' faults '$defaultpar_Fault_Name' qualified in the fault memory", 'AUTO_NBR' );
	PD_check_fault_status( $flt_mem_struc_qualify, $defaultpar_Fault_Name, $expect_qualified_state );

	S_teststep( "Evaluation for Step :2. Squib Openline fault is not qualified in the fault memory (since Test Mode is active)", 'AUTO_NBR' );
	PD_check_fault_status( $flt_mem_struc_aft_disconnectline, $squib_openline_flt, 0x00 );

	S_teststep( "Evaluation for Step :3.Squib Openline fault is qualified in the fault memory (since Test Mode is not active in new power on cycle)", 'AUTO_NBR' );
	PD_check_fault_status( $flt_mem_struc_aft_reset, $squib_openline_flt, $expect_qualified_state );

	S_teststep( "$defaultpar_Prod_Diag_Response is received and this fault is dequalified in the fault memory", 'AUTO_NBR' );
	PD_check_fault_status( $flt_mem_struc_dequalify, $defaultpar_Fault_Name, $expect_dequalified_state );
	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Re-connect the squib $defaultpar_Squib_Name", 'AUTO_NBR' );
	LC_ConnectLine($defaultpar_Squib_Name);

	S_teststep_2nd_level( "Do the reset", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	return 1;

}

1;
__END__
