#### TEST CASE MODULE
package TC_PROD_AccessingPDInInit;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_AccessingPDInInit.pm 1.3 2020/04/28 13:46:35ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_can_access;
use LIFT_labcar;
##################################

our $PURPOSE = "To verify that PD will be activated once Init1 is finished(~300ms)";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_AccessingPDInInit

=head1 PURPOSE

To verify that PD will be activated once Init1 is finished(~300ms)

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation


I<B<Stimulation and Measurement>>

1.Create <Test_Condition>.

2. Send <Prod_Diag_Request3>.

3. Send <Prod_Diag_Request1> along with 256 bytes of valid signature and verify the response of the <Prod_Diag_Request1>. 

4. Send <Prod_Diag_Request1> along with invalid signature and verify the response of <Prod_Diag_Request1>.

5. Send <Prod_Diag_Request3>.

6. Send <Prod_Diag_Request1> along with 256 bytes of valid signature and verify the response of the <Prod_Diag_Request1>. 

7.Verify the 4th byte in the response.

8. Verify the 5th byte in the response.

Bit 7 is Endianess indicator and protocol version from 0 to 6th bit.

9. Check the 6th byte in the security key response.

10.Send <Prod_Diag_Request2> and verify the response.

11.Send <Prod_Diag_Request4>.

12.Send <Prod_Diag_Request5>.

13.Send <Prod_Diag_Request6>.

14.Send <Prod_Diag_Request7>.

15. Send <Prod_Diag_Request8>.

16.Send <Prod_Diag_Request9>.


I<B<Evaluation>>

2. <Prod_Diag_Response3> is obtained.

3. <Prod_Diag_Response1> is obtained within 100ms. 

4.NRC $35 is obtained.

5. <Prod_Diag_Response3> is obtained.

6. <Prod_Diag_Response1> is obtained.

7.security key response must have the value 0x0C.

8.'Bit 7' should indicate the endianess(see ID SRS_PROD_1298).

  - 'Bit 6-0' should indicate the protocol version number(see ID SRS_PROD_1302).

9.6th byte in the security key response is number of bytes of the output file name of the SW. ie( 0x0B)

10. <Prod_Diag_Response2> is obtained.

11.<Prod_Diag_Response4> is obtained.

12.<Prod_Diag_Response5> is obtained.

13.<Prod_Diag_Response6> is obtained.

14.<Prod_Diag_Response7> is obtained.

15.No response observed.

16.No response observed.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $defaultpar_purpose;
my $defaultpar_Test_Condition;
my $defaultpar_Prod_Diag_Request1;
my $defaultpar_Prod_Diag_Response1;
################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Test_Condition      = S_read_mandatory_testcase_parameter('Test_Condition');
	$defaultpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');

	return 1;
}

sub TC_initialization {

	S_teststep( "PROD_Standard_Preparation", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Create '$defaultpar_Test_Condition'.", 'AUTO_NBR' );
	_create_condition($defaultpar_Test_Condition);

	S_teststep( "Reset ECU", 'AUTO_NBR', 'ecu_reset' );    #measurement 1
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();

	S_teststep( "Wait for 300ms", 'AUTO_NBR' );            #measurement 1
	S_wait_ms(300);

	if ( $defaultpar_Test_Condition =~ /Disposal/ ) {
		S_wait_ms(20000);
		GDCOM_set_addressing_mode('disposal');
		GDCOM_request( '10 04', '50 04', 'relax' );
		GDCOM_set_addressing_mode("PD");
	}

	S_teststep( "Logging to ECU after 300ms from ECU on", 'AUTO_NBR' );    #measurement 1
	PD_ECUlogin();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Immediately send the valid request ", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );

	S_teststep( "Wait for ECU ready completely", 'AUTO_NBR' );             #measurement 15
	S_wait_ms(3000);
	_remove_condition($defaultpar_Test_Condition);

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation is done in TC_stimulation_and_measurement", 'blue' );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _create_condition {

	my $condition = shift;
	if ( $condition =~ /Init/ ) {
		S_w2rep( "Condition not require action", 'blue' );
	}
	elsif ( $condition =~ /Idle/ ) {
		GEN_setECUMode('IdleMode');
	}
	elsif ( $condition =~ /Disposal/ ) {
		S_w2rep( "this Disposal Condition have to create in steady state, after ECU reset", 'blue' );
	}
	else {
		S_set_error("condition not support yet");
		return;
	}

	return 1;
}

sub _remove_condition {

	my $condition = shift;
	if ( $condition =~ /Init/ ) {
		S_w2rep( "Condition not require action", 'blue' );
	}
	elsif ( $condition =~ /Idle/ ) {
		GEN_setECUMode('RemoveIdleMode');
	}
	elsif ( $condition =~ /Disposal/ ) {
		S_w2rep( "this Disposal Condition have to create in steady state, after ECU reset", 'blue' );
		GDCOM_set_addressing_mode("physical");
		S_wait_ms(5000);    #wait for timeout => default session
	}
	else {
		S_set_error("condition not support yet");
		return;
	}
	return 1;
}
1;
