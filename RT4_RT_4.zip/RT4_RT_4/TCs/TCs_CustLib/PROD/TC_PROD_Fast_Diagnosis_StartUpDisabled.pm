#### TEST CASE MODULE
package TC_PROD_Fast_Diagnosis_StartUpDisabled;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_Fast_Diagnosis_StartUpDisabled.pm 1.4 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_can_access;
use LIFT_PD;
##################################

our $PURPOSE = "To the test the Fast Diagnosis services - response frames under start up disabled condition";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Fast_Diagnosis_StartUpDisabled

=head1 PURPOSE

To the test the Fast Diagnosis services - response frames under start up disabled condition

=head1 TESTCASE DESCRIPTION

This script is based on TS_PROD_ProductionDiagnosis v3.30

I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Set <TestCondition>


I<B<Stimulation and Measurement>>

1. Send <Fast_Diag_Request>

2. Send <Prod_Diag_Request> on incorrect ProDiag Rx ID

3. Send <Prod_Diag_Request> on correct ProDiag Rx ID


I<B<Evaluation>>

1. 

No positive response frame is received

The consecutive fast diagnosis response frames are received every <FD_Response_time> ms +/- 2ms (tolerance)

The realtime counter in each response frame is incremented by 4

The Frame Identifier is incremented in case the frames are sent on different CAN IDs

If a response frame is never used, it shall not be sent

If a response frame is used sometimes, it shall always be sent

Check the captured data values for each address/cell (compare with the previously read cell values)

Check if the unused bytes and unused frames have default value 0xFF for each byte

2. Fast Diagnosis consecutive frames are not stopped.

3. Fast Diagnosis consecutive frames are stopped.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of this TC
	SCALAR 'TestCondition' => Set the test condition on the PROD diag request in step 3
	SCALAR 'FD_Response_time' => time between consecutive response frames
	SCALAR 'Fast_Diag_Request' => label of FD request
	SCALAR 'FD_monitoringDuration' => duration to monitor the consecutive response frames in step 1 (in ms)
	SCALAR 'Prod_Diag_Request' => label of other PROD request to be sent in step 2, 3
	SCALAR 'FD_Startup' => start up option selector
	SCALAR 'OutputMode' => StandardCAN or PrivateCAN
	SCALAR 'LimitNumberOfCANIDs' => 0001 to 0100
	SCALAR 'NumberOfCells' => 01 to 1C
	SCALAR 'SecondaryPrivateCANSupported' => 'Yes' or 'No'


=head2 PARAMETER EXAMPLES

	purpose	= 'To test Fast Diagnosis services'
	TestCondition = 'none' #normal condition
	FD_Response_time = 2  #ms
	Fast_Diag_Request = 'Fast_Diagnostics_CAN'
	FD_monitoringDuration = '1000' #ms
	Prod_Diag_Request =  'ECU_Status'
	SecondaryPrivateCANSupported = 'No'
	
	#options
	FD_Startup = '00' #disabled
	OutputMode = '<Test Heading 1>'
	LimitNumberOfCANIDs = '<Test Heading 2>'
	NumberOfCells = '<Test Heading 3>'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_TestCondition;
my $tcpar_FD_Response_time;
my $tcpar_Fast_Diag_Request;
my $tcpar_Prod_Diag_Request;
my $tcpar_FD_Startup;
my $tcpar_OutputMode;
my $tcpar_LimitNumberOfCANIDs;
my $tcpar_NumberOfCells;
my $tcpar_FD_monitoringDuration;

################ global parameter declaration ###################
#add any global variables here
my ( $Trace_StoredfilePath, $usedCANIDs, $CANchannel, $OutputMode, $unusedBytes, $requiredFrames, $reqIDs, $respIDs, $FD_requestLabel );
my $FDreqresp_hashref_step;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose               = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_TestCondition         = S_read_mandatory_testcase_parameter('TestCondition');
	$tcpar_FD_Response_time      = S_read_mandatory_testcase_parameter('FD_Response_time');
	$tcpar_Fast_Diag_Request     = S_read_mandatory_testcase_parameter('Fast_Diag_Request');
	$tcpar_FD_monitoringDuration = S_read_optional_testcase_parameter('FD_monitoringDuration');
	$tcpar_Prod_Diag_Request     = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_FD_Startup            = S_read_mandatory_testcase_parameter('FD_Startup');
	$tcpar_OutputMode            = S_read_mandatory_testcase_parameter('OutputMode');
	$tcpar_LimitNumberOfCANIDs   = S_read_mandatory_testcase_parameter('LimitNumberOfCANIDs');
	$tcpar_NumberOfCells         = S_read_mandatory_testcase_parameter('NumberOfCells');

	unless ( defined $tcpar_FD_monitoringDuration ) {
		$tcpar_FD_monitoringDuration = 500;
	}

	if ( $tcpar_OutputMode eq 'StandardCAN' ) {
		$OutputMode = '00';
		$CANchannel = 1;
	}
	elsif ( $tcpar_OutputMode eq 'PrivateCAN' ) {
		$OutputMode = '10';
		$CANchannel = 2;
	}

	$tcpar_LimitNumberOfCANIDs =~ m/(.*)CANID/i;
	$tcpar_LimitNumberOfCANIDs = $1;
	( $usedCANIDs, $requiredFrames, $unusedBytes ) = DIAG_PD_calculateFastDiagnosis_ResponseDetails( $tcpar_NumberOfCells, $tcpar_LimitNumberOfCANIDs );

	$tcpar_LimitNumberOfCANIDs = sprintf( "%04b", $tcpar_LimitNumberOfCANIDs );

	$reqIDs  = DIAG_PD_fetchProDiag_RequestID();
	$respIDs = DIAG_PD_fetchFastDiagnosis_ResponseIDs();

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Prepare fast diagnostic option: Startup - $tcpar_FD_Startup - Output mode: $OutputMode, NumCANIds: $tcpar_LimitNumberOfCANIDs", 'AUTO_NBR' );
	$tcpar_FD_Startup          = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b000000' . $tcpar_FD_Startup ) ) );          #covert 2/4 bits to hex byte (8-bit) format
	$OutputMode                = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b000000' . $OutputMode ) ) );
	$tcpar_LimitNumberOfCANIDs = S_hex2dec( sprintf( "%02x", S_0x2dec( '0b0000' . $tcpar_LimitNumberOfCANIDs ) ) );

	my $FDoptions = ( ( $tcpar_LimitNumberOfCANIDs << 4 ) | ( $tcpar_FD_Startup << 2 ) | $OutputMode );
	$FDoptions = sprintf( "%02X", $FDoptions );
	S_w2rep("FD options: $FDoptions");

	S_teststep_2nd_level( "Get the correct cells addressing from sad file", 'AUTO_NBR' );
	my $FDaddresses = generateFDAddresses($tcpar_NumberOfCells);

	$FD_requestLabel->{'Options'}       = $FDoptions;
	$FD_requestLabel->{'NumberOfCells'} = sprintf( "%02X", $tcpar_NumberOfCells );                                    #to hex
	$FD_requestLabel->{'RAM_Address'}   = $FDaddresses;

	S_teststep_2nd_level( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();

	S_teststep_2nd_level( "Start new trace record", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_teststep( "Send request '$tcpar_Fast_Diag_Request'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Fast_Diag_Request", "PR_$tcpar_Fast_Diag_Request", $FD_requestLabel, 'NO_EVAL' );    #no evaluation here - no positive response is checked in evaluation

	S_teststep_2nd_level( "wait for $tcpar_FD_monitoringDuration ms to get the trace data", 'AUTO_NBR' );
	S_wait_ms( $tcpar_FD_monitoringDuration, 'monitor fast diagnostic frames for some time' );

	S_teststep_2nd_level( "Stop the trace record and get the data", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep('1a');
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");
	$FDreqresp_hashref_step = DIAG_PD_Trace_get_ReqResp( $Trace_StoredfilePath, $reqIDs, $respIDs, $CANchannel );

	S_teststep( "Check the fast diagnostic was sent on the trace", 'AUTO_NBR' );
	_checkFastDiagnosis_Communication('ACTIVE');

	S_teststep( " Send request '$tcpar_Prod_Diag_Request' on incorrect ProDiag Rx ID", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to Invalid", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("Invalid");

	S_teststep_2nd_level( "send the request 09 - read ECU status", 'AUTO_NBR' );
	DIAG_PD_request( "09", "49", 'quiet', 'invalid request', 'NO_EVAL', '500' );
	S_wait_ms( 500, 'wait for 1 sec' );

	S_teststep( "Check the fast diagnostic was sent on the trace after send one service with invalid ID", 'AUTO_NBR' );
	_checkFastDiagnosis_Communication('ACTIVE');

	S_teststep( "Send request '$tcpar_Prod_Diag_Request' on correct ProDiag Rx ID with '$tcpar_TestCondition' condition", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep_2nd_level( "Send the request with '$tcpar_TestCondition' condition", 'AUTO_NBR' );
	if ( $tcpar_TestCondition eq 'BlockLengthMore' ) {
		DIAG_PD_request( "09 02", "49", 'quiet', 'valid request', 'NO_EVAL' );
	}
	elsif ( $tcpar_TestCondition eq 'NotSupportedRequest' ) {
		DIAG_PD_request( "99", "49", 'quiet', 'valid request', 'NO_EVAL' );
	}
	else {
		S_w2rep("Require using function DIAG_PD_request as conflict issue sometimes will not get the response when fast diagnostic are working");
		DIAG_PD_request( "09", "49", 'quiet', 'valid request', 'NO_EVAL' );
	}

	S_wait_ms( 200, 'wait for 200 ms and check Fast Diag communication' );
	_checkFastDiagnosis_Communication('INACTIVE');

	return 1;
}

sub TC_evaluation {

	if ($main::opt_offline) {    #temp responses for offline mode
		$FDreqresp_hashref_step->{'Response'} = {
			'0.459169' => '04 00 00 00 00 FF FF FF',
			'0.461171' => '08 FF 00 00 00 FF FF FF',
			'0.463175' => '0C 00 00 00 00 FF FF FF',
			'0.465161' => '10 FF 00 00 00 FF FF FF',
			'0.467161' => '14 00 00 00 00 FF FF FF',
			'0.469173' => '18 FF 00 00 00 FF FF FF',
			'0.471167' => '1C 00 00 00 00 FF FF FF',
			'0.473173' => '20 FF 00 00 00 FF FF FF',
			'0.475159' => '24 00 00 00 00 FF FF FF',
			'0.477165' => '28 00 00 00 00 FF FF FF',
			'0.479165' => '2C 00 00 00 00 FF FF FF',
			'0.481169' => '30 00 00 00 00 FF FF FF',
			'0.483175' => '34 00 00 00 00 FF FF FF',
			'0.485167' => '38 00 00 00 00 FF FF FF',
			'0.487169' => '3C 00 00 00 00 FF FF FF',
			'0.489171' => '00 00 00 00 00 FF FF FF',
		};
	}

	S_teststep( "Check no positive response frame is received", 'AUTO_NBR' );
	my @frames;
	foreach my $time ( sort { $a <=> $b } keys %{ $FDreqresp_hashref_step->{'Response'} } ) {
		push( @frames, $FDreqresp_hashref_step->{'Response'}{$time} );
	}
	my $firstFrame = GEN_byteString2hexaref( $frames[0] );
	EVAL_evaluate_value( "No positive response frame (02 D0 D2) - byte0", ( @{$firstFrame}[0] ), '!=', 0x02 );
	EVAL_evaluate_value( "No positive response frame (02 D0 D2) - byte1", ( @{$firstFrame}[1] ), '!=', 0xD0 );
	EVAL_evaluate_value( "No positive response frame (02 D0 D2) - byte2", ( @{$firstFrame}[2] ), '!=', 0xD2 );

	S_teststep( "Check the Frame Identifier is incremented in case the frames are sent on different CAN IDs", 'AUTO_NBR' );
	DIAG_PD_checkFastDiagnosis_FrameIdentifier( $FDreqresp_hashref_step, $usedCANIDs );

	S_teststep( "The realtime counter in each response frame is incremented by 4", 'AUTO_NBR' );
	DIAG_PD_checkFastDiagnosis_RealTimeCounter( $FDreqresp_hashref_step, $usedCANIDs );

	S_teststep( "The consecutive fast diagnosis response frames are received every '$tcpar_FD_Response_time' ms +/- 2ms (tolerance)", 'AUTO_NBR' );
	my $maxResponseTime = $tcpar_FD_Response_time + 2.2;    #allowed time + 2 ms tolerance + load due to CAN bus
	DIAG_PD_checkFastDiagnosis_FrameTiming( $FDreqresp_hashref_step, $maxResponseTime, $usedCANIDs );

	S_teststep( "Check for the captured data for each address(cell)", 'AUTO_NBR' );
	S_w2rep( "As value of cell in RAM will changed time to time so the content of data will not be checked.", 'red' );

	S_teststep( "Check for the unused frames in data set - all bytes should have value 0xFF", 'AUTO_NBR' );
	DIAG_PD_checkFastDiagnosis_UnusedFrames($FDreqresp_hashref_step);

	S_teststep( "Check for the unused bytes in data set - all bytes should have value 0xFF", 'AUTO_NBR' );
	DIAG_PD_checkFastDiagnosis_UnusedBytes($FDreqresp_hashref_step);

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 3000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub generateFDAddresses {

	my $NumberOfCells = shift;

	S_w2rep("Get start address from sad file");
	my $address_href = GEN_fetchAddressFromSADFile();         #get addressing from sad file
	my $ram_address  = $address_href->{'RAMstartaddress'};    #take RAM address
	$ram_address =~ s/(\w+)\s(\w+)\s(\w+)\s(\w+)/$1 $2 $3/;   #remove the last byte
	my $last_byte = $4;
	my $addresses = "";

	S_w2rep("Create valid RAM address chain and the read the initial content of RAM cells");
	foreach my $num ( 1 .. $NumberOfCells ) {
		my $decNum = $num;
		$num       = $num | hex($last_byte);
		$num       = sprintf( "%02X", $num );
		$addresses = $addresses . "$ram_address $num ";

		#read the value initially (to compare with the capured FD data)
		my $RequestLabel;
		$RequestLabel->{'NumberOfCells'} = "00 01";
		$RequestLabel->{'StartAddress'}  = "$ram_address $num";
	}

	S_w2rep("Generated addresses: $addresses");

	return $addresses;
}

#Function support for CAN only
sub _checkFastDiagnosis_Communication {

	my $expect_fastdiag_communication = shift;
	my $verdict;

	#set default verdict
	if ( $expect_fastdiag_communication eq 'INACTIVE' ) {
		$verdict = 'VERDICT_PASS';
	}
	elsif ( $expect_fastdiag_communication eq 'ACTIVE' ) {
		$verdict = 'VERDICT_FAIL';
	}
	else {
		S_set_error( "Parameter not correct", 109 );
		return 0;
	}

	S_teststep( "Stop the canoe to avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(1000);
	CA_simulation_start();

	S_teststep( "Start new trace logging", 'AUTO_NBR' );
	CA_trace_start();
	S_wait_ms(1000);
	my $TracePath = GEN_printLink( CA_trace_store( GEN_generateUniqueTraceName() ) );

	S_teststep( "Stop new trace logging", 'AUTO_NBR' );
	CA_trace_stop();

	unless ( open( FH, $TracePath ) ) {
		S_set_error("Could not open trace file for reading ");
		return;
	}

	while (<FH>) {
		if ( $_ =~ m/\d+\.\d+\s+\d+\s+(651|652|653|654|655)\s+Rx/ ) {

			S_w2rep( "Fast diagnostic frame found in log file, the frame is: $_  \n", 'blue' );
			if ( $expect_fastdiag_communication eq 'INACTIVE' ) {
				$verdict = 'VERDICT_FAIL';
			}
			elsif ( $expect_fastdiag_communication eq 'ACTIVE' ) {
				$verdict = 'VERDICT_PASS';
			}
			else {
				S_set_error( "Parameter not correct", 109 );
				return 0;
			}
			last;
		}
	}
	
	unless ( close(FH) ) {
		S_set_error("Could not close trace file for reading ");
		return;
	}

	S_teststep( "Set the verdict for the evaluation", 'AUTO_NBR' );
	S_set_verdict($verdict);

	S_teststep( "Start again canoe to remove COM timeout fault", 'AUTO_NBR' );
	CA_trace_start();

	return 1;
}

1;
