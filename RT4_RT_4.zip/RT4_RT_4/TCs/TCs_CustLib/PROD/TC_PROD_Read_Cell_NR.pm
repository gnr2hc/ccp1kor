#### TEST CASE MODULE
package TC_PROD_Read_Cell_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_Read_Cell_NR.pm 1.4 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-----------------------------------------------------------------------------------------------------------------------------------------------

##################################

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_can_access;
use Data::Dumper;
##################################

our $PURPOSE = "To check the Read Cell Negative Request Response values";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Read_Cell_NR  $Revision: 1.4 $


=head1 PURPOSE

To check the supported NRC for the Read Cell service


=head1 TESTCASE DESCRIPTION 

[initialisation]
1.GEN_StandardPrepNoFault

2.DIAG_PD_Login_Level1
    
[stimulation & measurement]
 1. Send <Prod_Diag_Request1> to read the cell value of RAM/ ROM section  


[evaluation]
1. Verify the response of the Prod_Diag_Response1 and response should be received   .
 and it should be received with in Max_ReadCell_Response_Time  (2 )ms.
    
[finalisation]
Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			          -> 'purpose of the test case'
	SCALAR 'Prod_Diag_Request1'                     -> 'Request label for Read_Cell from  the Diagmapping File '
	SCALAR 'Prod_Diag_Response1'                   -> 'Response label for Read_Cell from  the Diagmapping File '
	SCALAR 'Start_Addres'                     		       -> 'Read Cell Start byte (RAM)/(ROM)'
	SCALAR 'Max_ReadCell_Response_Time'         ->  Maximum time to receiving the response  for Readcell Request from the ECU. '
	SCALAR 'Block_Length'           		        ->  Block Length in  the first byte of request. '

=head2 PARAMETER EXAMPLES
	   
	[TC_PROD_Read_Cell_NR.RAM_00_01]   #ID: SRTP_PRD1517
# From here on: applicable Lift Default Parameters
purpose			='When the  Specific ROM Address is Invalid(Secondry Controller) It should report NRC 31'
Prod_Diag_Response1='NR_Read_Cell_RequestOutOfRange'
Test_Condition =  'InvalidAddress_ROM_SecondryController'
RequestLabel = %('NumberOfCells' => '00 01', 'StartAddress' => 'FE DF 44 68')
Prod_Diag_Request1		= 'Read_Cell'
Prod_Diag_Response1		= 'PR_Read_Cell'
Block_Length  ='00FF'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Max_ReadCell_Response_Time, $defaultpar_RequestLabel, $defaultpar_Test_Condition, $defaultpar_Memory_Location, );
my ( $Trace_StoredfilePath, $Readreqresp_hashref_step1, $Readcellresp_time_withtol_step1 );
my ( $modified_request, $NRCInfo );

sub TC_set_parameters {

	$defaultpar_purpose                    = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1         = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1        = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Max_ReadCell_Response_Time = S_read_mandatory_testcase_parameter('Max_ReadCell_Response_Time');
	$defaultpar_RequestLabel               = S_read_mandatory_testcase_parameter( 'RequestLabel', 'byref' );
	$defaultpar_Test_Condition             = S_read_optional_testcase_parameter( 'Test_Condition', );
	$defaultpar_Memory_Location            = S_read_mandatory_testcase_parameter('Memory_Location');
	
	if ( $defaultpar_Test_Condition =~ m/^ReadFailure_DataFlash$/i ) {
		S_set_error( "This condition cannot be created. Not proceeding with this test case!", 0 );
		return 0;
	}
	
	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();
}

sub TC_stimulation_and_measurement {

	S_teststep( "Replace the 'RAMstartaddress' with the actual start Addressfrom the .sad File", 'AUTO_NBR' );
	$defaultpar_RequestLabel = GEN_replaceAddressFromParameterFile($defaultpar_RequestLabel);

	S_teststep( "Send $defaultpar_Prod_Diag_Request1  to read the RAM / ROM cells", 'AUTO_NBR' );
	S_teststep_2nd_level( "Avoid appending data to the existing log", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();

	S_teststep_2nd_level( "Start logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	if ( $defaultpar_Test_Condition eq 'BlockLengthMore' ) {

		S_teststep_2nd_level( "Manipulation the request with condition 'BlockLengthMore' ", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", $defaultpar_RequestLabel, +1 );

		S_teststep_2nd_level( "Get NRC information", 'AUTO_NBR' );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);

		S_teststep_2nd_level( "Send request: $modified_request", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	elsif ( $defaultpar_Test_Condition eq 'BlockLengthLess' ) {

		S_teststep_2nd_level( "Manipulation the request with condition 'BlockLengthLess' ", 'AUTO_NBR' );
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request1", $defaultpar_RequestLabel, -1 );

		S_teststep_2nd_level( "Get NRC information", 'AUTO_NBR' );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response1);

		S_teststep_2nd_level( "Send request: $modified_request", 'AUTO_NBR' );
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}
	else {

		S_teststep_2nd_level( "Send request: REQ_$defaultpar_Prod_Diag_Request1 without pre-condition", 'AUTO_NBR' );
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel );
	}

	S_teststep( "Store the request and reponse from the can log file", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(1);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	my $protocol = _get_communication_type();
	S_teststep( "Read the request and reponse from trace and put into the hash reference with '$protocol' protocol", 'AUTO_NBR' );
	$Readreqresp_hashref_step1 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	my $dump_ref = Dumper $Readreqresp_hashref_step1;
	S_w2rep( "Dump the data into LIFT report: $dump_ref", 'blue' );

	return 1;

}
#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Verify the response of the $defaultpar_Prod_Diag_Response1 and it should be received with in $defaultpar_Max_ReadCell_Response_Time ms.", 'AUTO_NBR' );

	if ( $defaultpar_Memory_Location eq 'DataFlash' ) {
		S_w2rep( "Response timing is not applicable for reading from Data Flash. So this is not evaluated", 'red' );
	}
	else {
		S_teststep_2nd_level( "Set expected response time with tolerance", 'AUTO_NBR' );
		if ( ( $defaultpar_Test_Condition eq 'BlockLengthMore' ) or ( $defaultpar_Test_Condition eq 'BlockLengthLess' ) ) {
			$Readcellresp_time_withtol_step1 = { "$modified_request" => "$defaultpar_Max_ReadCell_Response_Time%0", };
		}
		else {
			$Readcellresp_time_withtol_step1 = {
				"REQ_$defaultpar_Prod_Diag_Request1" => "$defaultpar_Max_ReadCell_Response_Time%1",    #1 % Tolerance
			};
		}
		
		S_teststep_2nd_level( "Do the timing evaluation", 'AUTO_NBR' );
		DIAG_EVAL_ResponseTime_from_dataref( $Readreqresp_hashref_step1, $Readcellresp_time_withtol_step1, $defaultpar_RequestLabel, undef, undef, '<=' );
	}

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 3000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _get_communication_type {

	my $LIFT_COM_Type = $LIFT_config::LIFT_Testbench->{'Devices'}{'PDLayer'}{'BusType'};

	return $LIFT_COM_Type;
}

1;
__END__
