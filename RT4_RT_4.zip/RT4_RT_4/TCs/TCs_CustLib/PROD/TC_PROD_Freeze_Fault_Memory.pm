#### TEST CASE MODULE
package TC_PROD_Freeze_Fault_Memory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_Freeze_Fault_Memory.pm 1.4 2020/04/28 13:46:36ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use LIFT_labcar;
##################################

our $PURPOSE = "To check the Freeze Fault memory services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_Freeze_Fault_Memory;

=head1 PURPOSE

To check the Freeze Fault memory services

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault
 
[stimulation & measurement]

1. Create the Faults of type <Faults_Before_FreezeRequest>.

2. Send <Prod_Diag_Request1> to read fault memory and check the response of the <Prod_Diag_Request1>.

3. Send <Prod_Diag_Request2> and check the response of the <Prod_Diag_Request2>

4. Create the Faults of type <Faults_After_FreezeRequest>.

5. Send <Prod_Diag_Request1> to read fault memory and check the response of the <Prod_Diag_Request1>.

6. Check the  faults Name and their status before and after the Freeze frame requests

7. Reset the ECU and wait for ECU Initlisation to complete

8. Send <Prod_Diag_Request1> to read fault memory and check the response of the <Prod_Diag_Request1>

[evaluation]

1.- 

2. Verify the response of the <Prod_Diag_Response1> and note down faults present in  the fault memoy - "Faults_Before_FreezeRequest"

3 Verify the response of the <Prod_Diag_Response2>  

4. <Faults_After_FreezeRequest>.
 Faults created should 'Not' be present in the fault memory

5 Verify the response of the <Prod_Diag_Response1> and note down faults present in  the fault memoy - "Faults_After_FreezeRequest"

6. "Faults_After_FreezeRequest" and "Faults_After_FreezeRequest" should be same .

7.

8.Verify the response of the <Prod_Diag_Response1> 
and all the faults created in Step4 should be present
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Faults_Before_FreezeRequest             ' ->  ' Faults should  be created  Before the FreezeRequest  '
    SCALAR 'Faults_After_FreezeRequest              ' ->  '  Faults should  be created  After the FreezeRequest  '
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service Read_Fault_Memory from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service Read_Fault_Memory from the Diagmapping File  '
    SCALAR 'Prod_Diag_Request2                      ' ->  ' Request label for the PD service Freeze_Fault_Memory from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service Freeze_Fault_Memory from the Diagmapping File  '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_Freeze_Fault_Memory.Request_Responses]   #ID: TS_PRD2549
# From here on: applicable Lift Default Parameters
purpose			='To check the Freeze Fault Frame services'
Faults_Before_FreezeRequest = %("Internal_Faults"  => "1","Init_Faults"  => "1","External_Faults"  => "1")
Faults_After_FreezeRequest = %("Internal_Faults"  => "1","Init_Faults"  => "1","External_Faults"  => "1")
Prod_Diag_Request1 = 'Read_Fault_Memory__Primary'
Prod_Diag_Response1 = 'PR_Read_Fault_Memory_Primary'
Prod_Diag_Request2 = 'Freeze_Fault_Memory'
Prod_Diag_Response2 = 'PR_Freeze_Fault_Memory'
# From here on: the connection to Doors



=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Faults_Before_FreezeRequest, $defaultpar_Faults_After_FreezeRequest, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Prod_Diag_Request2, $defaultpar_Prod_Diag_Response2, );

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $PrimaryMemory_Response_observed_step2, $PrimaryMemory_Response_observed_step5, $PrimaryMemory_Response_observed_step8, );

my ( $flt_mem_struct_beforefreeze, $flt_mem_struct_afterfreeze, $flt_mem_struct_afterreset, );
my ( @Fault_before_freeze_arr, @Fault_after_freeze_arr );
my $defaultpar_Internal_Fault;
my $defaultpar_Init_Fault;
my $defaultpar_External_Fault;

sub TC_set_parameters {
	$defaultpar_purpose                     = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Faults_Before_FreezeRequest = S_read_mandatory_testcase_parameter( 'Faults_Before_FreezeRequest', 'byref' );
	$defaultpar_Faults_After_FreezeRequest  = S_read_mandatory_testcase_parameter( 'Faults_After_FreezeRequest', 'byref' );
	$defaultpar_Prod_Diag_Request1          = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1         = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2          = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2         = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_Internal_Fault              = S_read_mandatory_testcase_parameter('Internal_Faults');
	$defaultpar_Init_Fault                  = S_read_mandatory_testcase_parameter('Init_Fault');
	$defaultpar_External_Fault              = S_read_mandatory_testcase_parameter('External_Fault');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( 'Check fault memory before create condition', 'AUTO_NBR' );
	PD_ReadFaultMemory();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Create the Faults with type defined'", 'AUTO_NBR' );
	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'Internal_Faults'} ) && ( $defaultpar_Faults_Before_FreezeRequest->{'Internal_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create Internal_Faults '@$defaultpar_Internal_Fault[0]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_Internal_Fault[0] );
		push @Fault_before_freeze_arr, @$defaultpar_Internal_Fault[0];
	}

	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'Init_Faults'} ) && ( $defaultpar_Faults_Before_FreezeRequest->{'Init_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create Init_Faults crosscoupling:'@$defaultpar_Init_Fault[0]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_Init_Fault[0] );
		push @Fault_before_freeze_arr, @$defaultpar_Init_Fault[0];
	}

	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'External_Faults'} ) && ( $defaultpar_Faults_Before_FreezeRequest->{'External_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create External_Faults:'@$defaultpar_External_Fault[0]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_External_Fault[0] );
		push @Fault_before_freeze_arr, @$defaultpar_External_Fault[0];
	}

	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Wait for all fault qualify if has", 'AUTO_NBR' );
	S_wait_ms(6000);

	S_teststep( "Read memory check in report before create faults and not yet freeze fault memory", 'AUTO_NBR' );
	$flt_mem_struct_beforefreeze = PD_ReadFaultMemory();

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request1' to read fault memory and check the response of the request '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 2.Verify the response of the response'   $defaultpar_Prod_Diag_Response1'  and note down faults present in  the fault memoy -  ' Faults_Before_FreezeRequest ' ", 'blue' );
	$PrimaryMemory_Response_observed_step2 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request2' and check the response $defaultpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step  3 Verify the response of the  RESPONSE::'   $defaultpar_Prod_Diag_Response2'", 'blue' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );

	S_teststep( "Create the Faults of type ' Faults_After_FreezeRequest'", 'AUTO_NBR' );
	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'Internal_Faults'} ) && ( $defaultpar_Faults_After_FreezeRequest->{'Internal_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create Internal_Faults '@$defaultpar_Internal_Fault[1]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_Internal_Fault[1] );
		push @Fault_after_freeze_arr, @$defaultpar_Internal_Fault[1];
	}

	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'Init_Faults'} ) && ( $defaultpar_Faults_After_FreezeRequest->{'Init_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create Init_Faults crosscoupling:'@$defaultpar_Init_Fault[1]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_Init_Fault[1] );
		push @Fault_after_freeze_arr, @$defaultpar_Init_Fault[1];
	}

	if ( defined( $defaultpar_Faults_Before_FreezeRequest->{'External_Faults'} ) && ( $defaultpar_Faults_After_FreezeRequest->{'External_Faults'} ) == 1 ) {
		S_teststep_2nd_level( "Create external Faults crosscoupling:'@$defaultpar_External_Fault[1]'", 'AUTO_NBR' );
		FM_createFault( @$defaultpar_External_Fault[1] );
		push @Fault_after_freeze_arr, @$defaultpar_External_Fault[1];
	}

	S_teststep( "Wait for all fault qualify if has", 'AUTO_NBR' );
	S_wait_ms(6000);

	S_teststep( "Check memory in LIFT report after freeze memory", 'AUTO_NBR' );
	$flt_mem_struct_afterfreeze = PD_ReadFaultMemory();

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request1' to read fault memory and check the response '$defaultpar_Prod_Diag_Request1'.", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 5 Verify the response of the RESPONSE '$defaultpar_Prod_Diag_Response1' and note down faults present in  the fault memory -'Faults_After_FreezeRequest'", 'blue' );
	S_teststep_2nd_level( "Login after reset", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Send request: '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$PrimaryMemory_Response_observed_step5 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );

	S_teststep( "Step 6. Check the  faults Name and their status before and after the Freeze frame requests", 'AUTO_NBR' );
	S_w2rep("The faults are noted and evaluated and in evaluation section");

	S_teststep( "Step 7. Reset the ECU and wait for ECU Initlisation to complete", 'AUTO_NBR' );
	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep( "Wait for all fault qualify if has", 'AUTO_NBR' );
	S_wait_ms(6000);
	S_teststep( "Step 8. Send REQUEST '$defaultpar_Prod_Diag_Request1' to read fault memory and check the response '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$PrimaryMemory_Response_observed_step8 = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );

	S_teststep( "Check memory in LIFT report after freeze memory", 'AUTO_NBR' );
	$flt_mem_struct_afterreset = PD_ReadFaultMemory();

	S_teststep( "Remove all fault was created: @Fault_before_freeze_arr ,@Fault_after_freeze_arr \n", 'AUTO_NBR' );
	foreach ( @Fault_before_freeze_arr, @Fault_after_freeze_arr ) {
		S_teststep_2nd_level( "Remove fault: '$_' \n", 'AUTO_NBR' );
		FM_removeFault($_);
	}

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Evaluation: Fault created before freeze fault memory should be in memory", 'AUTO_NBR' );
	FM_evaluateFaults( $flt_mem_struct_beforefreeze, [@Fault_before_freeze_arr] );

	S_teststep( "Evaluation: Fault created after freeze fault memory should not be in memory, the old fault still there", 'AUTO_NBR' );
	FM_evaluateFaults( $flt_mem_struct_afterfreeze, [@Fault_before_freeze_arr] );

	S_teststep( "Evaluation for Step 6.'Faults_Before_FreezeRequest' and 'Faults_After_FreezeRequest ' should be same .", 'AUTO_NBR' );
	EVAL_evaluate_string( "Read Memory Response ", $PrimaryMemory_Response_observed_step2, $PrimaryMemory_Response_observed_step5 );

	S_teststep( "Evaluation: All Faults created before and after freeze should be in memory", 'AUTO_NBR' );
	FM_evaluateFaults( $flt_mem_struct_afterreset, [ @Fault_before_freeze_arr, @Fault_after_freeze_arr ] );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	return 1;

}

1;
__END__
