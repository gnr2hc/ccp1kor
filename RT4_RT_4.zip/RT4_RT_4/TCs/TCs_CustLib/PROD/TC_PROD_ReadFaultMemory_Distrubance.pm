#### TEST CASE MODULE
package TC_PROD_ReadFaultMemory_Distrubance;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_ReadFaultMemory_Distrubance.pm 1.4 2020/04/28 13:46:37ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_labcar;
use LIFT_can_access;
use Data::Dumper;    # simple procedural interface4.
##################################
our $PURPOSE = "To test the Disturbance Read Fault memory service request and response";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_ReadFaultMemory_Distrubance;

=head1 PURPOSE

To test the Disturbance Read Fault memory  service request and response

=head1 TESTCASE DESCRIPTION 

[initialisation]

Standard_Preparation
 
[stimulation & measurement]

1. Create faults  in the list Qualify,  <Fault_List> with corresponding Fault status

 2. Send <Prod_Diag_Request1> to read the Event ID and status  for  the Distrubance memory  when the fault si in active state

3. Create faults  in the list  Dequalify,  <Fault_List>

4. Send <Prod_Diag_Request1> to read the Event ID and status  for  the Distrubance memory  when the faults is in inactive state

5. Send <Prod_Diag_Request2>to erase Fault recorder 

6. Send <Prod_Diag_Request1> to read the Event IDand status for the Distrubance memory when the faults is not present.

[evaluation]

1. Faults in <Fault_List> are qualified.

2.a. Response<Prod_Diag_Response1> should be received.
2.b Response should contain  <EventID_List_Qualify> Event ID and status.

3. Faults in <Fault_List> are dequalified

4.a. Response<Prod_Diag_Response1> should be received 
4.b Response should contain  <EventID_List_Dequalify> Event ID and status.


5.Response<Prod_Diag_Response2> should be received .

6.a. Response<Prod_Diag_Response1> should be received..
6.b Response should contain  <EventID_List_Erase> Event ID and status.
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'Fault_List                              ' ->  ' List if Fault should be qualified   '
    SCALAR 'EventID_List_Fault_Qualify              ' ->  ' Fault Name and EventID after the Fault Qualification '
    SCALAR 'EventID_List_Fault_Dequalify            ' ->  ' Fault Name and EventID after the Fault Dequalification  '
    SCALAR 'EventID_List_Fault_Erase                ' ->  ' Fault Name and EventID after the Fault Erasal  '
    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service  from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Request2                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service from the Diagmapping File  '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_ReadFaultMemory_Distrubance.External]   #ID: TS_PROD2626
Fault_List = %('Fault_Name' => 'Fault_status')
EventID_List_Fault_Qualify = %('Event_ID' => 'Event_status')
EventID_List_Fault_Dequalify = %('Event_ID' => 'Event_status')
EventID_List_Fault_Erase= %('Event_ID' => 'Event_status')
# From here on: applicable Lift Default Parameters
purpose = 'To test the Distrubance Read Fault memory  service request and response'
Prod_Diag_Request1 = 'Read_Fault_Memory__Distrubance'
Prod_Diag_Response1='PR_Read_Fault_Memory__Distrubance'
Prod_Diag_Request2 = 'Clear_Fault_Memory'
Prod_Diag_Response2='PR_Clear_Fault_Memory'
# From here on: the connection to Doors

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_Fault_List, $defaultpar_purpose, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Prod_Diag_Request2, $defaultpar_Prod_Diag_Response2, $defaultpar_faulttype, );

################ global parameter declaration ##################

my ( $Trace_StoredfilePath, $exp_eventID );

my $faultname;
my $ClearMemory_RequestLabel;

my ( $ReadMemory_Response_observed_faultqualify, $ReadMemory_Response_observed_faultdequalify, $ReadMemory_Response_observed_faulterase );
my ( $ReadMemory_EventID_Status_ref_faultqualify, $ReadMemory_EventID_Status_ref_faultdequalify );

sub TC_set_parameters {

	$defaultpar_Fault_List          = S_read_mandatory_testcase_parameter('Fault_List');
	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_faulttype           = S_read_mandatory_testcase_parameter('faulttype');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;

}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Create faults  in the list Qualify, 'Fault_List' with corresponding Fault status", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 1. Faults in 'Fault_List' are qualified.", 'blue' );
	if ( $defaultpar_faulttype eq 'CAN' ) {
		S_teststep_2nd_level( "Create CAN fault", 'AUTO_NBR' );
		CA_simulation_stop();
	}
	else {
		foreach (@$defaultpar_Fault_List) {
			S_teststep_2nd_level( "Create fault '$_'", 'AUTO_NBR' );
			FM_createFault($_);
		}
	}

	S_teststep_2nd_level( "Wait for qualify fault", 'AUTO_NBR' );
	S_wait_ms(6000);

	S_teststep_2nd_level( "Read fault memory after create fault and waiting", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Send REQUEST: '$defaultpar_Prod_Diag_Request1' to read the Event ID and status for the Distrubance memory when the fault is in active state", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	$ReadMemory_Response_observed_faultqualify = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	$ReadMemory_Response_observed_faultqualify  = '50 04 0F 03 00 12 01 00 15 00 02 00 21 01 00 00 00 02 00 33 01 00 00 00 20 22' if ($main::opt_offline);
	$ReadMemory_EventID_Status_ref_faultqualify = _get_EventID_Status($ReadMemory_Response_observed_faultqualify);
	$Trace_StoredfilePath                       = GEN_getTraceNameWithTeststep(2);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep( "Remove (dequalify) the faults created in step 1", 'AUTO_NBR' );
	if ( $defaultpar_faulttype eq 'CAN' ) {
		S_teststep_2nd_level( "Already started canoe => fault already dequalied", 'AUTO_NBR' );

	}
	else {
		foreach (@$defaultpar_Fault_List) {
			S_teststep_2nd_level( "Remove fault '$_'", 'AUTO_NBR' );
			FM_removeFault($_);
		}
	}

	S_teststep_2nd_level( "Wait for de-qualify fault", 'AUTO_NBR' );
	S_wait_ms( 6000, "wait for dequali time" );

	S_teststep_2nd_level( "Read fault memory after create fault and waiting", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Send REQUEST: '$defaultpar_Prod_Diag_Request1' to read the Event ID and status for the Distrubance memory when the faults is in inactive state", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	$ReadMemory_Response_observed_faultdequalify = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	$ReadMemory_Response_observed_faultdequalify  = '50 04 0F 03 00 12 01 00 15 00 02 00 21 01 00 00 00 02 00 33 01 00 00 00 20 22' if ($main::opt_offline);
	$ReadMemory_EventID_Status_ref_faultdequalify = _get_EventID_Status($ReadMemory_Response_observed_faultdequalify);
	$Trace_StoredfilePath                         = GEN_getTraceNameWithTeststep(4);

	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep( "Send REQUEST:'$defaultpar_Prod_Diag_Request2 'to erase Fault recorder ", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 5.Response RESPONSE:'$defaultpar_Prod_Diag_Response2' ", 'blue' );
	$ClearMemory_RequestLabel = {
		"Mode" => "00",    #Mode0
	};

	GDCOM_CA_trace_start();
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2", $ClearMemory_RequestLabel );

	S_teststep_2nd_level( "Wait to 5 sec to Erase the Distrubance Fault memory", 'AUTO_NBR' );
	S_wait_ms(5000);

	S_teststep( "Send  REQUEST:'$defaultpar_Prod_Diag_Request1' to read the Event IDand status for the Distrubance memory when the faults is not present.", 'AUTO_NBR' );
	$ReadMemory_Response_observed_faulterase = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	my @response_array = split( / /, $ReadMemory_Response_observed_faulterase );
	if ( scalar @response_array < 6 and scalar @response_array > 0 ) {
		S_w2rep( "Response just contain positive response and no event ID found", 'blue' );
		S_set_verdict(VERDICT_PASS);

	}
	else {
		S_w2rep( "Fault still there in memory", 'blue' );
		S_set_verdict(VERDICT_FAIL);
	}

	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(6);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( "Evaluation for Step 2.a. Response RESPONSE::'   $defaultpar_Prod_Diag_Response1'  should be received.", 'blue' );
	S_w2rep( "Evaluation for Step  2.b Response should contain   ' EventID_List_Qualify'   Event ID and status.",     'blue' );

	foreach $faultname (@$defaultpar_Fault_List) {
		$exp_eventID = PD_GetFaultID($faultname);
		$exp_eventID = sprintf( "%04x", $exp_eventID );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_faultqualify, $exp_eventID, '0x01' );

	}

	S_w2rep( "Evaluation for Step 4.a. Response RESPONSE:'$defaultpar_Prod_Diag_Response1' should be received ", 'blue' );
	S_w2rep( "Evaluation for Step 4.b Response should contain' EventID_List_Dequalify' Event ID and status.",    'blue' );
	foreach $faultname (@$defaultpar_Fault_List) {
		$exp_eventID = PD_GetFaultID($faultname);
		$exp_eventID = sprintf( "%04x", $exp_eventID );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_faultdequalify, $exp_eventID, '0x01' );
	}

	S_w2rep( " Evaluation for Step  6.a. Response RESPONSE:'$defaultpar_Prod_Diag_Response1' should be received", 'blue' );
	S_w2rep( " Evaluation for Step  6.b Response should contain 'EventID_List_Erase' Event ID and status.",       'blue' );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start the canoe to logging trace", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;

}

sub _get_EventID_Status {

	my $faultmemory_resp = shift;
	my $C_Event_Length   = 6;       # $vent ID : 2 Bytes , Status 1 Byte
	my $C_Status_Length  = 1;       # $vent ID : 2 Bytes , Status 1 Byte

	my ( $EventID, $EventIDstate, @PD_Resp_Array, @EventID_arr, @states);
	my $PD_Faultmemory_struct;

	unless ($faultmemory_resp) {
		S_set_error( "Too Less Parameters ! Syntax : _get_EventID_Status( $faultmemory_resp ) ", 110 );
		return 0;
	}

	@PD_Resp_Array = split( / /, $faultmemory_resp );

	my $resp = shift(@PD_Resp_Array);                                                                      # drop pos/neg response
	if ( $resp eq '50' ) {
		$PD_Faultmemory_struct->{"response"} = 'PR';
		shift(@PD_Resp_Array);                                                                             # drop subfunc
		shift(@PD_Resp_Array);                                                                             # drop max event ID
		shift(@PD_Resp_Array);                                                                             # drop current ID
		pop(@PD_Resp_Array);                                                                               # removes the checksum

		my $Len = ( scalar @PD_Resp_Array );
		while (@PD_Resp_Array) {
			@EventID_arr  = splice( @PD_Resp_Array, 0, ( $C_Event_Length + $C_Status_Length ) );
			$EventID      = $EventID_arr[0] . $EventID_arr[1];
			$EventIDstate = $EventID_arr[2];
			push( @{ $PD_Faultmemory_struct->{"EventID"} }, $EventID );
			push( @{ $PD_Faultmemory_struct->{"state"} },   "0x" . $EventIDstate );
		}
		GEN_printComment( "Number of Event ID Present in Fault Memory :: " . scalar( @{ $PD_Faultmemory_struct->{"EventID"} } ) . " EventID\n" );
		@states = @{ $PD_Faultmemory_struct->{'state'} };
		return ($PD_Faultmemory_struct);
	}
}
1;
__END__
