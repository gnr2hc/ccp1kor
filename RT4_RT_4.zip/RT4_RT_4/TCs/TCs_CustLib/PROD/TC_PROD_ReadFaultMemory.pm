#### TEST CASE MODULE
package TC_PROD_ReadFaultMemory;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.6 $;
our $HEADER  = q$Header: PROD/TC_PROD_ReadFaultMemory.pm 1.6 2020/04/29 17:01:21ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

our $PURPOSE = 'To test the Plant, Primary Read Fault memory service request and response';

=head1 TESTCASE MODULE

package TC_PROD_ReadFaultMemory;

=head1 PURPOSE

 'To test the Plant, Primary Read Fault memory service request and response'
 
=head1 TESTCASE DESCRIPTION 

[initialisation]

Standard_Preparation
 
[stimulation & measurement]

1. Create faults  in the list Qualify,  <Fault_List> with corresponding Fault status

 2. Send <Prod_Diag_Request1> to read the Event ID and status  for  the plant memory  when the fault si in active state

3. Create faults  in the list  Dequalify,  <Fault_List>

4. Send <Prod_Diag_Request1> to read the Event ID and status  for  the plant memory  when the faults is in inactive state

5. Send <Prod_Diag_Request2>to erase Fault recorder 

6. Send <Prod_Diag_Request1> to read the Event IDand status for the plant memory when the faults is not present.

[evaluation]

1. Faults in <Fault_List> are qualified.

2.a. Response<Prod_Diag_Response1> should be received within <ReadPlant_Memory_RespTime> ms .
2.b Response should contain  <EventID_List_Qualify> Event ID and status.

3. Faults in <Fault_List> are dequalified

4.a. Response<Prod_Diag_Response1> should be received within <ReadPlant_Memory_RespTime> ms .
4.b Response should contain  <EventID_List_Dequalify> Event ID and status.


5.Response<Prod_Diag_Response2>
should be received .

6.a. Response<Prod_Diag_Response1> should be received within <ReadPlant_Memory_RespTime> ms .
6.b Response should contain  <EventID_List_Erase> Event ID and status.
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'Fault_List                              ' ->  ' List if Fault should be qualified   '
    SCALAR 'EventID_List_Fault_Qualify              ' ->  ' Fault Name and EventID after the Fault Qualification '
    SCALAR 'EventID_List_Fault_Dequalify            ' ->  ' Fault Name and EventID after the Fault Dequalification  '
    SCALAR 'EventID_List_Fault_Erase                ' ->  ' Fault Name and EventID after the Fault Erasal  '
    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Request2                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'ReadPlant_Memory_RespTime               ' ->  '   '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_ReadFaultMemory_Plant.External]   #ID: TS_PROD1986
Fault_List = %('Fault_Name' => 'Fault_status')
EventID_List_Fault_Qualify = %('Event_ID' => 'Event_status')
EventID_List_Fault_Dequalify = %('Event_ID' => 'Event_status')
EventID_List_Fault_Erase= %('Event_ID' => 'Event_status')
# From here on: applicable Lift Default Parameters
purpose = 'To test the Plant Read Fault memory  service request and response'
Prod_Diag_Request1 = 'Read_Fault_Memory__Plant'
Prod_Diag_Response1='PR_Read_Fault_Memory__Plant'
Prod_Diag_Request2 = 'Clear_Fault_Memory'
Prod_Diag_Response2='PR_Clear_Fault_Memory'
ReadPlant_Memory_RespTime= 700 
# From here on: the connection to Doors

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_Fault_List, $defaultpar_faulttype, $defaultpar_purpose, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Prod_Diag_Request2, $defaultpar_Prod_Diag_Response2, $defaultpar_ReadPlant_Memory_RespTime, );

################ global parameter declaration ##################
my ( $PDresp_time_withtol, $Trace_StoredfilePath, );
my $ClearMemory_RequestLabel;

my ( $ReadMemory_Response_observed_faultqualify, $ReadMemory_Response_observed_faultdequalify, $ReadMemory_Response_observed_faulterase );
my ( $ReadMemory_EventID_Status_ref_faultqualify, $ReadMemory_EventID_Status_ref_faultdequalify );
my ( $PDreqresp_hashref_faultqualify, $PDreqresp_hashref_faultdequalify, $PDreqresp_hashref_faulterase );
my $fltmemstruct_step1;

sub TC_set_parameters {
	$defaultpar_faulttype                 = S_read_mandatory_testcase_parameter('faulttype');
	$defaultpar_purpose                   = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1        = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1       = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2        = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2       = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_ReadPlant_Memory_RespTime = S_read_optional_testcase_parameter('ReadPlant_Memory_RespTime');
	$defaultpar_Fault_List                = S_read_mandatory_testcase_parameter('Fault_List');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Create some faults of type $defaultpar_faulttype", 'AUTO_NBR' );
	if ( $defaultpar_faulttype eq 'CAN' ) {
		S_teststep_2nd_level( "Create CAN fault", 'AUTO_NBR' );
		CA_simulation_stop();
	}
	else {
		foreach (@$defaultpar_Fault_List) {
			S_teststep_2nd_level( "Create fault '$_'", 'AUTO_NBR' );
			FM_createFault($_);
		}
	}

	S_teststep_2nd_level( "Wait for qualify fault", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep( "Read fault memory after create fault and waiting", 'AUTO_NBR' );
	$fltmemstruct_step1 = PD_ReadFaultMemory();

	S_teststep( "Start the canoe to logging trace", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request1' to read the Event ID and status for faults in the fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Start the trace", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep_2nd_level( "Send request '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ReadMemory_Response_observed_faultqualify  = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	$ReadMemory_EventID_Status_ref_faultqualify = FM_PD_get_EventID_Status($ReadMemory_Response_observed_faultqualify);
	$Trace_StoredfilePath                       = GEN_getTraceNameWithTeststep(2);

	S_teststep_2nd_level( "Stop the trace", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get list request, response from trace", 'AUTO_NBR' );
	$PDreqresp_hashref_faultqualify = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );

	S_teststep( "Remove (dequalify) the faults created in step 1", 'AUTO_NBR' );
	if ( $defaultpar_faulttype eq 'CAN' ) {
		S_teststep_2nd_level( "Already started canoe => fault already dequalify", 'AUTO_NBR' );

	}
	else {
		foreach (@$defaultpar_Fault_List) {
			S_teststep_2nd_level( "Remove fault '$_'", 'AUTO_NBR' );
			FM_removeFault($_);
		}
	}

	S_teststep_2nd_level( "Wait for de-qualify fault", 'AUTO_NBR' );
	S_wait_ms( 6000, "wait for dequali time" );

	S_teststep( "Send REQUEST: '$defaultpar_Prod_Diag_Request1' to read the Event ID and status for faults in the fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Start the trace", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep_2nd_level( "Send request '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ReadMemory_Response_observed_faultdequalify  = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	$ReadMemory_EventID_Status_ref_faultdequalify = FM_PD_get_EventID_Status($ReadMemory_Response_observed_faultdequalify);
	$Trace_StoredfilePath                         = GEN_getTraceNameWithTeststep(4);

	S_teststep_2nd_level( "Stop the trace", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get list request, response from trace", 'AUTO_NBR' );
	$PDreqresp_hashref_faultdequalify = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );

	S_teststep_2nd_level( "Read fault memory after remove fault and waiting", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "StepSend REQUEST '$defaultpar_Prod_Diag_Request2' to erase Fault recorder", 'AUTO_NBR' );
	$ClearMemory_RequestLabel = {
		"Mode" => "00",    #Mode0 (clear all memories)
	};

	S_teststep_2nd_level( "Start the trace", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep_2nd_level( "Send request '$defaultpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2", $ClearMemory_RequestLabel );

	S_teststep_2nd_level( "Wait to 12 sec after Erase the Fault memory", 'AUTO_NBR' );
	S_wait_ms(12000);

	S_teststep_2nd_level( "Read fault memory after erase fault and waiting", 'AUTO_NBR' );
	PD_ReadFaultMemory();

	S_teststep( "Send REQUEST: '$defaultpar_Prod_Diag_Request1' to read the Event ID and status for faults in the fault memory", 'AUTO_NBR' );
	S_teststep_2nd_level( "Send request '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ReadMemory_Response_observed_faulterase = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	my @response_array = split( / /, $ReadMemory_Response_observed_faulterase );
	if ( scalar @response_array < 4 and scalar @response_array > 0 ) {
		S_w2rep( "Response just contain positive response and no event ID", 'blue' );
		S_set_verdict(VERDICT_PASS);

	}
	else {
		S_w2rep( "Fault still there in memory", 'blue' );
		S_set_verdict(VERDICT_FAIL);
	}

	S_teststep_2nd_level( "Stop the trace", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(6);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	S_teststep_2nd_level( "Get list request, response from trace", 'AUTO_NBR' );
	$PDreqresp_hashref_faulterase = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	$PDresp_time_withtol = { "REQ_$defaultpar_Prod_Diag_Request1" => "$defaultpar_ReadPlant_Memory_RespTime%0", };
	if ( $defaultpar_Prod_Diag_Request1 =~ m/Plant/i ) {    #evaluate time only for Read_Fault_Memory__Plant
		S_w2rep( "Evaluation for Step 2a. Response RESPONSE: '$defaultpar_Prod_Diag_Response1'  should be received within  '$defaultpar_ReadPlant_Memory_RespTime'  ms .", 'blue' );
		DIAG_EVAL_ResponseTime_from_dataref( $PDreqresp_hashref_faultqualify, $PDresp_time_withtol, undef, undef, undef, '<=' );
	}
	S_w2rep( " Evaluation for Step 2b Response should contain all Event IDs of the created faults with qualified status", 'blue' );
	if ( $defaultpar_faulttype eq 'CAN' ) {
		S_w2rep( "Check status for CAN fault", 'blue' );
		my $exp_eventID = sprintf( "%04x", PD_GetFaultID( @$defaultpar_Fault_List[0] ) );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_faultqualify, $exp_eventID, '0bxxxx1110' );
	}
	else {
		foreach (@$defaultpar_Fault_List) {
			S_w2rep( "Check status for '$_' fault", 'blue' );
			my $exp_eventID = sprintf( "%04x", PD_GetFaultID($_) );
			FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_faultqualify, $exp_eventID, '0bxxxx1111' );
		}
	}

	if ( $defaultpar_Prod_Diag_Request1 =~ m/Plant/i ) {    #evaluate time only for Read_Fault_Memory__Plant
		S_w2rep( "Evaluation for Step 4a. Response RESPONSE::'   $defaultpar_Prod_Diag_Response1'  should be received within  '$defaultpar_ReadPlant_Memory_RespTime'  ms .", 'blue' );
		DIAG_EVAL_ResponseTime_from_dataref( $PDreqresp_hashref_faultdequalify, $PDresp_time_withtol, undef, undef, undef, '<=' );
	}
	S_w2rep( " Evaluation for Step 4b Response should contain the Event IDs of faults created in step 1 with dequalified status", 'blue' );

	foreach (@$defaultpar_Fault_List) {
		S_w2rep( "Check status for '$_' fault", 'blue' );
		my $exp_eventID = sprintf( "%04x", PD_GetFaultID($_) );
		FM_PD_check_EventID_status( $ReadMemory_EventID_Status_ref_faultdequalify, $exp_eventID, '0bxxxx1110' );
	}

	if ( $defaultpar_Prod_Diag_Request1 =~ m/Plant/i ) {    #evaluate time only for Read_Fault_Memory__Plant
		S_w2rep( "Evaluation for Step 6a. Response RESPONSE:'$defaultpar_Prod_Diag_Response1'  should be received within '$defaultpar_ReadPlant_Memory_RespTime'  ms .", 'blue' );
		DIAG_EVAL_ResponseTime_from_dataref( $PDreqresp_hashref_faulterase, $PDresp_time_withtol, undef, undef, undef, '<=' );
	}

	S_w2rep( " Evaluation for Step  6b Response should not contain the event IDs of faults created in step 1", 'blue' );
	S_w2rep( " Evaluation already done in TC_stimulation_and_measurement",                                     'blue' );

	return 1;
}

#### TC FINALIZATION #####
#--set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start the canoe to logging trace", 'AUTO_NBR' );
	CA_simulation_start();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;

}

1;
__END__
