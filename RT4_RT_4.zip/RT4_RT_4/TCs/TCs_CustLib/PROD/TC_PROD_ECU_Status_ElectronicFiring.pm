#### TEST CASE MODULE
package TC_PROD_ECU_Status_ElectronicFiring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_ECU_Status_ElectronicFiring.pm 1.4 2020/04/28 13:46:36ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------
#### INCLUDE MODULES ####
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_labcar;
use INCLUDES_Project;    #necessary

#include further modules here
##################################

our $PURPOSE = "To check Electronic Firing Status byte in the response for ECU Status service";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ECU_Status_ElectronicFiring

=head1 PURPOSE

To check Electronic Firing Status byte in the  response for ECU Status service

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request> 

2. Enter Electronic Firing Mode (by setting the production mode bit and then send $tcpar_Prod_Diag_Request1 

3. Trigger the safety path activation by sending $tcpar_Prod_Diag_Request2 and immediately send $tcpar_Prod_Diag_Request1

4. After safety path activation, send $tcpar_Prod_Diag_Request1

5. Perform Electronic Firing for loops by sending $tcpar_Prod_Diag_Request3 and then send $tcpar_Prod_Diag_Request1

6. Exit Electronic Firing Mode (by re-setting the production mode bit) and then send $tcpar_Prod_Diag_Request1 


I<B<Evaluation>>

1.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x00 (not in "Electronic Firing Mode")

2.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x01 (Safety path activation not started)

3.  $tcpar_Prod_Diag_Response2 is received. 

$tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x02 (Safety path activation started)

4.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x03 (Safety path activation completed)

5.  $tcpar_Prod_Diag_Response3 is received. 

$tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x03 (Safety path activation completed)

6.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x00 (not in "Electronic Firing Mode")


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of the test case
	SCALAR 'key' => key to enable safety path
	SCALAR 'Prod_Diag_Request1' => ECU_Status
	SCALAR 'Prod_Diag_Response1' => PR_ECU_Status
	SCALAR 'Prod_Diag_Request2' => Enable_Safety_Path
	SCALAR 'Prod_Diag_Response2' => PR_Enable_Safety_Path
	SCALAR 'Prod_Diag_Request3' => Fire_All_Devices
	SCALAR 'Prod_Diag_Response3' => PR_Fire_All_Devices


=head2 PARAMETER EXAMPLES

	purpose	= 'To check Electronic Firing Status byte in the  response for ECU Status service'
	
	key = 'AB12'
	Prod_Diag_Request1 =  'ECU_Status'
	Prod_Diag_Response1 =  'PR_ECU_Status'
	
	Prod_Diag_Request2 =  'Enable_Safety_Path'
	Prod_Diag_Response2 =  'PR_Enable_Safety_Path'
	
	Prod_Diag_Request3 =  'Fire_All_Devices'
	Prod_Diag_Response3 =  'PR_Fire_All_Devices'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_Prod_Diag_Request3;
my $tcpar_Prod_Diag_Response3;
my $tcpar_Key;

################ global parameter declaration ###################
#add any global variables here
my ( $FireAllDevices_response_step6, $ECUStatus_response_step7, $ECUStatus_response_step1, $ECUStatus_response_step2, $ECUStatus_response_step3, $ECUStatus_response_step4, $ECUStatus_response_step5, $ECUStatus_response_step6, $EnableSafetyPath_RequestLabel, $EnableSafetyPath_response_step4 );

###############################################################

sub TC_set_parameters {
	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Key                 = S_read_mandatory_testcase_parameter('Key');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Request2  = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2 = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_Prod_Diag_Request3  = S_read_mandatory_testcase_parameter('Prod_Diag_Request3');
	$tcpar_Prod_Diag_Response3 = S_read_mandatory_testcase_parameter('Prod_Diag_Response3');

	$EnableSafetyPath_RequestLabel = { "Key" => "$tcpar_Key", };

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Send $tcpar_Prod_Diag_Request1 ", 'AUTO_NBR' );
	$ECUStatus_response_step1 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	S_teststep( "Enter Electronic Firing Mode (by setting the production mode bit and then send $tcpar_Prod_Diag_Request1 ", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set ECU to plant mode 7", 'AUTO_NBR' );
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0x40] );
	LC_ECU_Off();
	S_wait_ms(8000);
	LC_ECU_On();

	S_teststep_2nd_level( "Wait 500ms after ECU On (Not yet ready state but PD can working)", 'AUTO_NBR' );
	S_wait_ms(500);

	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ECUStatus_response_step2 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	S_teststep( "Enter Electronic Firing Mode (by setting the production mode bit) and then send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	S_teststep_2nd_level( "Wait 10s after ECU On to get ECU ready", 'AUTO_NBR' );
	S_wait_ms(10000);

	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ECUStatus_response_step3 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	S_teststep( "Trigger the safety path activation by sending $tcpar_Prod_Diag_Request2 and immediately send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	S_teststep_2nd_level( "Trigger safety path by sending '$tcpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	$EnableSafetyPath_response_step4 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2", $EnableSafetyPath_RequestLabel );

	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ECUStatus_response_step4 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );
	S_wait_ms( 1000, "wait for safety path activation" );

	S_teststep( "After safety path activation, send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	$ECUStatus_response_step5 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	S_teststep( "Perform Electronic Firing for loops by sending $tcpar_Prod_Diag_Request3 and then send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request3'", 'AUTO_NBR' );
	$FireAllDevices_response_step6 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request3", "$tcpar_Prod_Diag_Response3" );

	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ECUStatus_response_step6 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	S_teststep( "Exit Electronic Firing Mode (by re-setting the production mode bit) and then send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	S_teststep_2nd_level( "Remove plant mode", 'AUTO_NBR' );
	GEN_setECUMode('RemovePlantModes');

	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();
	S_wait_ms( 5000, 'wait for ECU ready completely' );
	S_teststep_2nd_level( "Send request '$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	$ECUStatus_response_step7 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1" );

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation for Step 1.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x00 (not in 'Electronic Firing Mode')", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step1, 0x00 );

	S_w2rep( "Evaluation for Step 2.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x00 (system not yet initialization)", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step2, 0x00 );

	S_w2rep( "Evaluation for Step 3.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x01 (Safety path activation not started)", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step3, 0x01 );

	S_w2rep( "Evaluation for Step 4.  $tcpar_Prod_Diag_Response2 is received. ", 'blue' );
	S_w2log( 4, "Evaluation for this step is done in stimulation and measurement step 3", 'orange' );

	S_w2rep( "Evaluation for Step 4. is received and Electronic Firing Status byte is: 0x02 (Safety path activation started)", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step4, 0x02 );

	S_w2rep( "Evaluation for Step 5.  $tcpar_Prod_Diag_Response3 is received. ", 'blue' );
	S_w2log( 4, "Evaluation for this step is done in stimulation and measurement step 5", 'orange' );

	S_w2rep( "Evaluation for Step 5 $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x03 (Safety path activation completed)", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step5, 0x03 );

	S_w2rep( "Evaluation for Step 6.  $tcpar_Prod_Diag_Response1 Electronic Firing Status byte is: 0x03 (Safety path activation completed)", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step6, 0x03 );

	S_w2rep( "Evaluation for Step 7.  $tcpar_Prod_Diag_Response1 is received and Electronic Firing Status byte is: 0x00 (not in 'Electronic Firing Mode')", 'blue' );
	evaluateElectronicFiringStatus( $ECUStatus_response_step7, 0x00 );
	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub evaluateElectronicFiringStatus {
	my $response      = shift;
	my $expectedValue = shift;

	return 1 if $main::opt_offline;

	my $ECUStatusBytes_response = GEN_byteString2hexaref($response);
	EVAL_evaluate_value( "Expected Firing Status is $expectedValue", @$ECUStatusBytes_response[4], '==', $expectedValue );
	return 1;
}

1;
