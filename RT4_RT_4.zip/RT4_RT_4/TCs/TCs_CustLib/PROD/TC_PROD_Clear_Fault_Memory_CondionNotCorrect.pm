#### TEST CASE MODULE
package TC_PROD_Clear_Fault_Memory_CondionNotCorrect;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_Clear_Fault_Memory_CondionNotCorrect.pm 1.4 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_PD;
use LIFT_can_access;
use LIFT_labcar;
use Data::Dumper;    # simple procedural interface4.

##################################
our $PURPOSE = 'To check the behaviour of Clear services when the clear services are already running.';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_Clear_Fault_Memory_CondionNotCorrect;

=head1 PURPOSE

'To check the behaviour of Clear services when the clear services are already running.'

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1
 
[stimulation & measurement]

1. Create the faults of type Fault_Type and set the Pre Condition

2. Send <Prod_Diag_Request1>  and check  the response of the <Prod_Diag_Request1>to erase the fault memory .  

3.  Send <Prod_Diag_Request2>  as soon as  response <Prod_Diag_Response1>  is received

[evaluation]

1. <Pre_Condition_Status> should be active.

2. Verify the response of the <Prod_Diag_Response1> should be received .

3. Verify the response of the <Prod_Diag_Response2> should be received .
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Fault_Type                            ' ->  '  Type of Fault Fault(Internal / External)'
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Request2                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'Pre_Condition_Status                    ' ->  '  Precondition  Status before sending  the clear Services  '
    SCALAR 'Pre_Condition                           ' ->  '   Precondition to be set before sending  the clear Services '
	SCALAR 'Mode                                       ' ->  '   Mode of   the clear Services '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_Clear_Fault_Memory_CondionNotCorrect.FLMActive_External]   #ID: SRTP_PRD1757
Fault_NoOfFaults_Condition_Status= % ('NoOf_Faults' => '1' , 'Fault_Status' => 'Active', 'Faultcondition' => 'OpenLine' )
# From here on: applicable Lift Default Parameters
purpose			='To check the behaviour of Clear services when the clear services are already running.'
Prod_Diag_Request1		=  'Clear_Fault_Memory'
Prod_Diag_Response1		=  'PR_Clear_Fault_Memory'
Prod_Diag_Request2		=  'Clear_Fault_Memory'
Prod_Diag_Response2		= 'NR_Clear_Fault_Memory_conditionsNotCorrect'
Pre_Condition_Status =''
Pre_Condition=''
Mode = 00
Fault_Type = 'External'



=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_purpose,              $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Prod_Diag_Request2, $defaultpar_Prod_Diag_Response2,
	$defaultpar_Pre_Condition_Status, $defaultpar_Pre_Condition,      $defaultpar_Mode,                $default_Fault_Type,            $default_Fault_Name,
);

############# Parameters from const files ################

################ global parameter declaration ##################
my ( $PD_RequestLabel, $faultsafterclear, $faultsafterStimulation );

sub TC_set_parameters {

	$defaultpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1   = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1  = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Prod_Diag_Request2   = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2  = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_Pre_Condition        = S_read_optional_testcase_parameter('Pre_Condition');
	$defaultpar_Pre_Condition_Status = S_read_optional_testcase_parameter('Pre_Condition_Status');
	$defaultpar_Mode                 = S_read_mandatory_testcase_parameter('Mode');
	$default_Fault_Type              = S_read_mandatory_testcase_parameter('Fault_Type');
	$default_Fault_Name              = S_read_mandatory_testcase_parameter('Fault_Name');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "preparing the hash for the read cell", 'AUTO_NBR' );
	$PD_RequestLabel = { "Mode" => "$defaultpar_Mode", };

	S_teststep( "Create the faults of type $default_Fault_Type and set the Pre Condition", 'AUTO_NBR' );
	S_teststep_2nd_level( "Create the faults of type $default_Fault_Type", 'AUTO_NBR' );
	if ( $default_Fault_Type eq "External" ) {
		FM_createFault($default_Fault_Name);
		S_wait_ms(6000);
	}
	elsif ( $default_Fault_Type eq "Internal" ) {
		PD_ManipulateFaultMemory( $default_Fault_Name, "qualify" );
		S_wait_ms(2000);
		S_teststep_2nd_level( "Login to ECU", 'AUTO_NBR' );
		PD_ECUlogin();
	}
	else {
		S_set_error( "Invalid paramter : Fault_type :  It should be 'Internal' or 'External'  but received  $default_Fault_Type", 110 );
		return 0;
	}

	S_teststep_2nd_level( "Check fault create suscessfull", 'AUTO_NBR' );
	$faultsafterStimulation = FM_PD_readFaultMemory();
	FM_evaluateFaults( $faultsafterStimulation, [$default_Fault_Name] );

	S_teststep_2nd_level( "set the Pre Condition '$defaultpar_Pre_Condition'", 'AUTO_NBR' );
	if ( $defaultpar_Pre_Condition eq 'Freeze_Fault_Memory' ) {
		DIAG_PD_request_general( "REQ_$defaultpar_Pre_Condition", "$defaultpar_Pre_Condition_Status" );
	}
	else {
		S_w2rep( "Precondition not require", 'blue' );
	}

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request1' and check the response of the  response '$defaultpar_Prod_Diag_Response1' to erase the fault memory .", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $PD_RequestLabel );

	S_teststep( "Send request '$defaultpar_Prod_Diag_Request2' as soon as after response '$defaultpar_Prod_Diag_Response1' and expect response '$defaultpar_Prod_Diag_Response2' is obtained", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2", $PD_RequestLabel );

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_w2rep( 'All Evaluation is done in TC_stimulation_and_measurement', 'blue' );

	return 1;

}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	if ( $default_Fault_Type eq "External" ) {
		FM_removeFault($default_Fault_Name);
		S_wait_ms(6000);
	}
	else {
		PD_ManipulateFaultMemory( $default_Fault_Name, "dequalify" );
		S_wait_ms(2000);
	}

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms(5000);

	S_teststep_2nd_level( "Check fault clear suscessfull", 'AUTO_NBR' );
	$faultsafterclear = FM_PD_readFaultMemory();
	FM_evaluateFaults( $faultsafterclear, [] );

	return 1;
}

1;
__END__
