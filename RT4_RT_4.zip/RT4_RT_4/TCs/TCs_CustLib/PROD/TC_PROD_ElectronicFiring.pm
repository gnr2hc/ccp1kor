#### TEST CASE MODULE
package TC_PROD_ElectronicFiring;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_ElectronicFiring.pm 1.4 2020/04/28 13:46:36ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use GENERIC_DCOM;
use INCLUDES_Project;    #necessary
use LIFT_labcar;

#include further modules here

##################################

our $PURPOSE = "To check the services for Electronic Firing under different conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ElectronicFiring

=head1 PURPOSE

To check the services for Electronic Firing under different conditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Set $tcpar_Test_Condition


I<B<Stimulation and Measurement>>

1. Configure all squibs

2. Set the status of the electronic firing Production mode bit to <status>

3. Send Prod_Diag_Request1 to enable safety path

4. Send Prod_Diag_Request2 to fire all devices

5. Deconfigure some squibs and reset the ECU

6. Send Prod_Diag_Request2 to fire all devices

7. Send Prod_Diag_Request1 to enable safety path

8. Send Prod_Diag_Request2 to fire all devices


I<B<Evaluation>>

3. Prod_Diag_Response1 is received

4. Prod_Diag_Response2 is received

	Check the below details in case of positive response:
	OverallStatusByte is 0x01
	Power stage status byte is <PowerStageStatusByte>
	Bits corresponding to each fired loop in ASIC status byte is set to 1
	Firing counter data for each fired loop contains non-default data. 

6. Prod_Diag_Response3 is received

7. Prod_Diag_Response1 is received

8. Prod_Diag_Response2 is received

	Check the below details in case of positive response:
	OverallStatusByte is 0x00
	Power stage status byte is <PowerStageStatusByte>
	Bits corresponding to each fired loop in ASIC status byte is set to 1
	Firing counter data for each fired loop contains non-default data. 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => purpose of TC
	SCALAR 'PowerStageStatusByte' => state of all powerstages (bitwise)
	SCALAR 'status' => state of Electronic Firing Production mode (set/notset)
	SCALAR 'Test_Condition' => condition to be set before test case
	SCALAR 'Prod_Diag_Request1' => Enable_Safety_Path
	SCALAR 'Prod_Diag_Response1' => PR_Enable_Safety_Path
	SCALAR 'Prod_Diag_Request2' => Fire_All_Devices
	SCALAR 'Prod_Diag_Response2' => PR_Fire_All_Devices


=head2 PARAMETER EXAMPLES

	purpose	= 'To check the services for Electronic Firing under different conditions'
	
	PowerStageStatusByte = '00 00' #all powerstages enabled
	status = 'set'
	Test_Condition = 'none'
	Prod_Diag_Request1 =  'Enable_Safety_Path'
	Prod_Diag_Response1 =  'PR_Enable_Safety_Path'
	
	Prod_Diag_Request2 =  'Fire_All_Devices'
	Prod_Diag_Response2 =  'PR_Fire_All_Devices'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_PowerStageStatusByte;
my $tcpar_status;
my $tcpar_Test_Condition;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_Prod_Diag_Request2;
my $tcpar_Prod_Diag_Response2;
my $tcpar_Prod_Diag_Response3;
my $tcpar_Key;

################ global parameter declaration ###################
#add any global variables here
my ( $FireAllDevices_response_step4, $FireAllDevices_response_step6, $FireAllDevices_response_step8, $EnableSafetyPath_RequestLabel, $modified_request, $NRCInfo, );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose              = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_PowerStageStatusByte = S_read_mandatory_testcase_parameter('PowerStageStatusByte');
	$tcpar_status               = S_read_mandatory_testcase_parameter('status');
	$tcpar_Test_Condition       = S_read_mandatory_testcase_parameter('Test_Condition');
	$tcpar_Key                  = S_read_mandatory_testcase_parameter('Key');
	$tcpar_Prod_Diag_Request1   = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1  = S_read_optional_testcase_parameter('Prod_Diag_Response1');
	$tcpar_Prod_Diag_Request2   = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$tcpar_Prod_Diag_Response2  = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$tcpar_Prod_Diag_Response3  = S_read_mandatory_testcase_parameter('Prod_Diag_Response3');

	$EnableSafetyPath_RequestLabel = { "Key" => "$tcpar_Key", };

	return 1;
}

sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Set condition: $tcpar_Test_Condition", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		S_w2log( '1', "Block Length more is set in each test step", 'brown' );
	}
	elsif ( $tcpar_Test_Condition =~ m/^BlockLengthLess$/i ) {
		S_w2log( '1', "Block Length less is set in each test step", 'brown' );
	}
	elsif ( $tcpar_Test_Condition =~ m/^SafetyPathNotEnabled$/i ) {
		S_w2log( '1', "SafetyPathNotEnabled is set in test step", 'brown' );
	}

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Configure all squibs", 'AUTO_NBR' );
	S_w2log( '1', "Default system should configuration all squib.", 'blue' );

	S_teststep( "Set the status of the electronic firing Production mode bit to $tcpar_status", 'AUTO_NBR' );
	if ( $tcpar_status =~ m/^set$/i ) {
		GEN_setECUMode('PlantMode7_ElectronicFiringMode');
	}
	elsif ( $tcpar_status =~ m/^notset$/i ) {
		GEN_setECUMode('RemovePlantModes');
	}
	else {
		S_set_error( "Invalid status for electronic firing bit - $tcpar_status", 109 );
		return 0;
	}
	S_wait_ms(2000);

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Send request $tcpar_Prod_Diag_Request1 to enable safety path with condition '$tcpar_Test_Condition'", 'AUTO_NBR' );
	_enableSafety($tcpar_Test_Condition);

	S_teststep( "Send request $tcpar_Prod_Diag_Request2 to fire all devices", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", undef, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}

	else {
		S_wait_ms( 200, 'wait after previous step' );
		$FireAllDevices_response_step4 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2" );
	}

	S_teststep( "Deconfigure some squibs and reset the ECU", 'AUTO_NBR' );
	S_teststep_2nd_level( "Deconfigure AB1FD and AB1FP squibs", 'AUTO_NBR' );
	PD_Device_configuration( 'clear', [ 'AB1FP', 'AB1FD' ] );

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(5000);

	S_teststep( "Set the status of Electronic firing Production mode", 'AUTO_NBR' );
	if ( $tcpar_status =~ m/^set$/i ) {
		GEN_setECUMode('PlantMode7_ElectronicFiringMode');
	}
	elsif ( $tcpar_status =~ m/^notset$/i ) {
		GEN_setECUMode('RemovePlantModes');
	}
	else {
		S_set_error( "Invalid status for electronic firing bit - $tcpar_status", 109 );
		return 0;
	}

	S_wait_ms( 2000, "wait for mode to be set" );
	S_teststep_2nd_level( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	S_teststep( "Send request $tcpar_Prod_Diag_Request2 to fire all devices", 'AUTO_NBR' );
	$FireAllDevices_response_step6 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response3" );

	S_teststep( "Send request $tcpar_Prod_Diag_Request1 to enable safety path", 'AUTO_NBR' );
	_enableSafety($tcpar_Test_Condition);

	S_teststep( "Send request $tcpar_Prod_Diag_Request2 to fire all devices", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition =~ m/^BlockLengthMore$/i ) {
		$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request2", undef, +1 );
		$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response2);
		DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
	}

	else {
		S_wait_ms( 200, 'wait after previous step' );
		$FireAllDevices_response_step8 = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request2", "$tcpar_Prod_Diag_Response2" );
	}

	S_teststep( "Remove all plant mode", 'AUTO_NBR' );
	GEN_setECUMode('RemovePlantModes');

	S_teststep( "Re-configure some squibs and reset the ECU", 'AUTO_NBR' );
	S_teststep_2nd_level( "Re-configure AB1FD and AB1FP squibs", 'AUTO_NBR' );
	PD_Device_configuration( 'set', [ 'AB1FP', 'AB1FD' ] );

	S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(5000);

	return 1;
}

sub TC_evaluation {

	S_w2rep( "Evaluation for Step 3. response $tcpar_Prod_Diag_Response1 is received", 'blue' );
	S_w2log( 1, "Evaluation for this step is done in stimulation and measurement step 3", 'orange' );

	if ( defined $FireAllDevices_response_step4 and $tcpar_Prod_Diag_Response2 eq 'PR_Fire_All_Devices' ) {    #evaluate only if positive response is expected!
		S_w2rep( "Evaluation for Step 4. response $tcpar_Prod_Diag_Response2 is received", 'blue' );
		S_w2rep( "OverallStatusByte is 0x01",                                              'blue' );
		evaluateOverallStatusByte( $FireAllDevices_response_step4, 0x01 );

		S_w2rep( "Power stage status byte is $tcpar_PowerStageStatusByte", 'blue' );
		evaluatePowerStageStatusByte( $FireAllDevices_response_step4, $tcpar_PowerStageStatusByte );

		S_w2rep( "Bits corresponding to each fired loop in ASIC status byte is set to 1", 'blue' );
		S_w2rep( "Firing counter data for each fired loop contains non-default data. ",   'blue' );
		displayLoopStatus($FireAllDevices_response_step4);
	}

	if ( defined $FireAllDevices_response_step8 and $tcpar_Prod_Diag_Response2 eq 'PR_Fire_All_Devices' ) {    #evaluate only if positive response is expected!
		S_w2rep( "Evaluation for Step 6. response $tcpar_Prod_Diag_Response2 is received", 'blue' );
		S_w2rep( "OverallStatusByte is 0x00",                                              'blue' );
		evaluateOverallStatusByte( $FireAllDevices_response_step8, 0x00 );

		S_w2rep( "Power stage status byte is $tcpar_PowerStageStatusByte", 'blue' );
		evaluatePowerStageStatusByte( $FireAllDevices_response_step8, $tcpar_PowerStageStatusByte );

		S_w2rep( "Bits corresponding to each fired loop in ASIC status byte is set to 1", 'blue' );
		S_w2rep( "Firing counter data for each fired loop contains non-default data. ",   'blue' );
		displayLoopStatus($FireAllDevices_response_step8);
	}

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

sub _enableSafety {
	my $condition = shift;

	if ( $condition =~ m/^SafetyPathNotEnabled$/i ) {
		S_w2log( '1', "This request is not sent due to condition SafetyPathNotEnabled", 'brown' );
	}
	else {
		if ( $condition =~ m/^BlockLengthMore$/i ) {
			$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", $EnableSafetyPath_RequestLabel, +1 );
			$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);
			DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
		}
		elsif ( $condition =~ m/^BlockLengthLess$/i ) {
			$modified_request = GDCOM_requestlength_manipulation( "REQ_$tcpar_Prod_Diag_Request1", $EnableSafetyPath_RequestLabel, -1 );
			$NRCInfo = GDCOM_PD_getNRCfromMapping($tcpar_Prod_Diag_Response1);
			DIAG_PD_request( $modified_request, $NRCInfo->{'Response'}, $NRCInfo->{'Mode'}, $NRCInfo->{'Desc'} );
		}
		else {
			DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$tcpar_Prod_Diag_Response1", $EnableSafetyPath_RequestLabel );
		}
	}

	return 1;
}

sub evaluateOverallStatusByte {
	my $response      = shift;
	my $expectedValue = shift;

	return 1 if $main::opt_offline;

	my $Bytes_response = GEN_byteString2hexaref($response);

	if ( @$Bytes_response[0] != 0x7F ) {
		my $OverallStatusByte = @$Bytes_response[1];    #byte0: 59, byte1: overall status byte
		EVAL_evaluate_value( "Expected Overall Status Byte is $expectedValue", $OverallStatusByte, '==', $expectedValue );
	}
	else {
		S_set_error( 'Negative response obtained!', 102 );
	}
	return 1;
}

sub evaluatePowerStageStatusByte {
	my $response      = shift;
	my $expectedValue = shift;

	return 1 if $main::opt_offline;

	my $Bytes_response = GEN_byteString2hexaref($response);
	my @PowerstageStatusBytes_expected = split( / /, $expectedValue );

	if ( @$Bytes_response[0] != 0x7F ) {
		foreach (@PowerstageStatusBytes_expected) { $_ = "0x$_"; }

		my @PowerstageStatusBytes = @$Bytes_response[ 2, 3 ];
		GEN_EVAL_CompareNumArrays( \@PowerstageStatusBytes, \@PowerstageStatusBytes_expected, 'Equal' );
	}
	else {
		S_w2log( '1', 'Negative response obtained!', 'orange' );
	}
	return 1;
}

sub displayLoopStatus {
	my $response = shift;

	my $ASICStatusbyte;
	my @ASICStatus;
	my $ASICStatusbit;
	my @Counter;
	my $LoopFiringCounter;
	my @status;

	$response = "59 01 00 0F FF FF FF FF FF FF 01 01 02 02 03 03 04 04 05 05 06 06 07 07 08 08 09 09" if $main::opt_offline;

	my $Bytes_response = GEN_byteString2hexaref($response);
	my @bytesarray     = @$Bytes_response;

	if ( $bytesarray[0] != 0x7F ) {
		my @ASICStatusBytes = @bytesarray[ 4, 5, 6, 7, 8, 9 ];
		my @FiringCounterBytes = splice @bytesarray, 10, 105;

		my $bytecount     = 0;
		my $printhead2rep = '<div class="w2rep"><TABLE class="tablesorter"><TR><TH>System ASIC</TH><TH>Loop</TH><TH>ASIC Status bit</TH><TH>Firing Counter Value</TH></TR>';

		push( @status, $printhead2rep );

		foreach my $ASICnum ( 1 .. 3 ) {
			if ( $ASICnum == 1 ) {
				@ASICStatus = @ASICStatusBytes[ 0, 1 ];
			}
			elsif ( $ASICnum == 2 ) {
				@ASICStatus = @ASICStatusBytes[ 2, 3 ];
			}
			elsif ( $ASICnum == 3 ) {
				@ASICStatus = @ASICStatusBytes[ 4, 5 ];
			}
			$ASICStatusbyte = S_aref2hex( \@ASICStatus );

			foreach my $loopnum ( 1 .. 16 ) {
				$ASICStatusbit = ( S_hex2dec($ASICStatusbyte) >> ( $loopnum - 1 ) ) & 0x0001;
				@Counter = @FiringCounterBytes[ $bytecount, $bytecount + 1 ];
				$LoopFiringCounter = S_aref2hex( \@Counter ) if defined $Counter[0];

				$bytecount = $bytecount + 2;

				my $print2rep = '<TR><TD>' . $ASICnum . '</TD><TD>' . $loopnum . '</TD><TD>' . $ASICStatusbit . '</TD><TD>' . $LoopFiringCounter . '</TD></TR>';
				push( @status, $print2rep );

			}
		}

		my $printtableend = '</TABLE></div>';
		push( @status, $printtableend );
		S_w2rep( join( '', @status ) );
	}
	else {
		S_w2log( '1', 'Negative response obtained!', 'orange' );
	}
	return 1;
}

1;
