#### TEST CASE MODULE
package TC_PROD_Reset_Request_Response;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_Reset_Request_Response.pm 1.3 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_CD_CAN;
use LIFT_PD;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
our $PURPOSE = 'To check therequest and response for  the reset services ';

=head1 TESTCASE MODULE

package TC_PROD_Reset_Request_Response;


=head1 PURPOSE


'To check therequest and response for  the reset services '



=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1
 
[stimulation & measurement]

1. Read the <Power_On_Counter_Variable>

2. Send <Prod_Diag_Request1> to make the Reset.

3. send <Prod_Diag_Request2> to read the ECU Status after positive response <Prod_Diag_Response1>  but before reset.

4. Read the <Power_On_Counter_Variable>

5. Perform  <Test_Condition> to remove the security access

6. Send <Prod_Diag_Request1> to make the reset.

[evaluation]

1. Let the Power on Counter value  be 'PowerON_Countervalue_Init'

2. Verify the response of the <Prod_Diag_Response1> should be received within <Response_time> ms .

3a. For Positive Reset Response
 Verify the response of the <Prod_Diag_Response2> should NOT be received.

3b. For Negative Reset Response
 Verify the response of the <Prod_Diag_Response2> should be received.

4.  Power on Counter value   should  have 'PowerON_Countervalue_Init'+ PowerON_Countervalue_Increment' 

5.  -

6.Verify the response of the <Prod_Diag_Response3> should  be received .
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Power_On_Counter_Variable               ' ->  ' Power ON Counter variable   '
    SCALAR 'RequestLabel                            ' ->  ' Hash parameter for the PD Request  '
    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service "Reset" from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service "Reset" from the Diagmapping File  '
    SCALAR 'Response_time                           ' ->  ' Response time  for the PD service  "Reset" '
    SCALAR 'Prod_Diag_Request2                      ' ->  ' Request label for the PD service ECU_Status from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response2                     ' ->  ' Response label for the PD service ECU_Status from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response3                     ' ->  ' Response label for the PD service "ECU_Status" from the Diagmapping File  '
    SCALAR 'PowerON_Countervalue_Increment          ' ->  '   Power ON Counter value after reset  '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_Reset_Request_Response.Hard_Reset]   #ID: SRTP_PRD2654
# From here on: applicable Lift Default Parameters
purpose ='To check therequest and response for  the reset services '
Power_On_Counter_Variable = 'TBD'
RequestLabel = %('ResetType' = '0l')
Prod_Diag_Request1 ='Reset'
Prod_Diag_Response1='PR_Reset'
Response_time = 200 # ms 
Prod_Diag_Request2 ='ECU_Status'
Prod_Diag_Response2='PR_ECU_Status' 
Prod_Diag_Response3='NR_Reset_securityAccessDenied'
 PowerON_Countervalue_Increment= 1
# From here on: the connection to Doors



=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_purpose,       $defaultpar_Power_On_Counter_Variable, $defaultpar_RequestLabel,        $defaultpar_Prod_Diag_Request1,  $defaultpar_Prod_Diag_Response1,
	$defaultpar_Response_time, $defaultpar_Prod_Diag_Request2,        $defaultpar_Prod_Diag_Response2, $defaultpar_Prod_Diag_Response3, $defaultpar_PowerON_Countervalue_Increment,
);

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $PDresp_time_withtol, $Trace_StoredfilePath, $PDreqresp_hashref_step );

#Global paramter for  the testcases
my $Power_Oncounter_Init_dec;
my $Power_Oncounter_AfterReset_dec;
my $ECU_Status_Response_string;
my $ECU_Status_Response_Array;
my $response1_aref;
my $response2_aref;

sub TC_set_parameters {

	$defaultpar_purpose                        = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Power_On_Counter_Variable      = S_read_mandatory_testcase_parameter('Power_On_Counter_Variable');
	$defaultpar_RequestLabel                   = S_read_mandatory_testcase_parameter( 'RequestLabel', 'byref' );
	$defaultpar_Prod_Diag_Request1             = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1            = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Response_time                  = S_read_mandatory_testcase_parameter('Response_time');
	$defaultpar_Prod_Diag_Request2             = S_read_mandatory_testcase_parameter('Prod_Diag_Request2');
	$defaultpar_Prod_Diag_Response2            = S_read_mandatory_testcase_parameter('Prod_Diag_Response2');
	$defaultpar_Prod_Diag_Response3            = S_read_mandatory_testcase_parameter('Prod_Diag_Response3');
	$defaultpar_PowerON_Countervalue_Increment = S_read_mandatory_testcase_parameter('PowerON_Countervalue_Increment');

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Read the Power_On_Counter_Variable before reset", 'AUTO_NBR' );
	$Power_Oncounter_Init_dec = GEN_readPowerONCounter();

	S_teststep( "Prepare for the request '$defaultpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	my $request1 = GDCOM_getRequestLabelValue( "REQ_$defaultpar_Prod_Diag_Request1", $defaultpar_RequestLabel );
	my $checksum1     = DIAG_PD_calculateChecksum( $request1, 'VALID' );
	my $request1_aref = GEN_byteString2hexaref( $request1 . " $checksum1" );
	my $length1       = scalar @$request1_aref;
	unshift( @$request1_aref, $length1 );

	S_teststep( "Prepare for the request '$defaultpar_Prod_Diag_Request2'", 'AUTO_NBR' );
	my $request2      = GDCOM_getRequestLabelValue("REQ_$defaultpar_Prod_Diag_Request2");
	my $checksum2     = DIAG_PD_calculateChecksum( $request2, 'VALID' );
	my $request2_aref = GEN_byteString2hexaref( $request2 . " $checksum2" );
	my $length2       = scalar @$request2_aref;
	unshift( @$request2_aref, $length2 );

	S_teststep( "Start logging trace", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();
	GDCOM_CA_trace_start();

	S_teststep( "Send the request: '$defaultpar_Prod_Diag_Request1' ", 'AUTO_NBR' );
	if ( $defaultpar_Prod_Diag_Response1 eq 'PR_Reset' ) {
		$response1_aref = CAN_send_request_wait_response($request1_aref);    #to save time
	}
	else {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel );
	}

	S_teststep( "Store trace and stop logging", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(2);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");
	$PDreqresp_hashref_step = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	
	S_teststep( "Send '$defaultpar_Prod_Diag_Request2' to read the ECU Status after positive response $defaultpar_Prod_Diag_Response1 but before reset.", 'AUTO_NBR' );
	if ( $defaultpar_Prod_Diag_Response1 eq 'PR_Reset' ) {
		$response2_aref = CAN_send_request_wait_response($request2_aref);    #to save time/send immediately after above request
	}
	else {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request2", "$defaultpar_Prod_Diag_Response2" );
	}

	S_teststep( 'Read the Power_On_Counter_Variable after reset', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');
	$Power_Oncounter_AfterReset_dec = GEN_readPowerONCounter();

	return 1;

}

sub TC_evaluation {

	$PDresp_time_withtol = { "REQ_$defaultpar_Prod_Diag_Request1" => "$defaultpar_Response_time%0", };

	S_teststep( "Evaluation for Step : 2. Verify the response of the '$defaultpar_Prod_Diag_Response1' should be received within '$defaultpar_Response_time' ms.", 'AUTO_NBR' );
	DIAG_EVAL_ResponseTime_from_dataref( $PDreqresp_hashref_step, $PDresp_time_withtol, $defaultpar_RequestLabel, undef, undef, '<=' );

	S_teststep( "Evaluation for Step 2. $defaultpar_Prod_Diag_Response1 is received", 'AUTO_NBR' );
	return 1 if ($main::opt_offline);
	if ( $defaultpar_Prod_Diag_Response1 eq 'PR_Reset' ) {
		if ( defined @$response1_aref[0] ) {
			EVAL_evaluate_value( ' check if positive response is obtained ', @$response1_aref[0], '==', 0x52 );                            #check first byte of response
		}
		else {
			S_set_error( "Response is not received for $defaultpar_Prod_Diag_Request1", 102 );
			S_set_verdict(VERDICT_FAIL);
		}

		S_teststep( "Evaluation for Step 3a. For Positive Reset Response, Verify the response of the '$defaultpar_Prod_Diag_Response2' should NOT be received.", 'AUTO_NBR' );
		if ( defined @$response2_aref[0] ) {
			S_set_error( "Response is received for $defaultpar_Prod_Diag_Request2", 102 );
			S_set_verdict(VERDICT_FAIL);
		}
		else {
			S_w2rep( "response is not received as expected", 'blue' );
			S_set_verdict(VERDICT_PASS);
		}
	}
	else {
		S_w2rep("Evaluation for this step is done in stimulation and measurement");
	}

	S_teststep( "Evaluation for Step : 4. Power on Counter value should have '$Power_Oncounter_Init_dec' + ''$defaultpar_PowerON_Countervalue_Increment'", 'AUTO_NBR' );
	my $expval = $Power_Oncounter_Init_dec + $defaultpar_PowerON_Countervalue_Increment;
	EVAL_evaluate_value( "Power on Counter value", $Power_Oncounter_AfterReset_dec, '==', $expval );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 1000, ' wait for fault de-qualify ' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

1;
__END__
