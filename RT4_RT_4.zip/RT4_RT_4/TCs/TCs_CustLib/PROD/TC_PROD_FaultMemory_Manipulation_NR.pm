#### TEST CASE MODULE
package TC_PROD_FaultMemory_Manipulation_NR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_FaultMemory_Manipulation_NR.pm 1.3 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_PD;
use LIFT_labcar;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
our $PURPOSE = 'To check the Fault manupulation request and response and is behaviour';

=head1 TESTCASE MODULE

TC_PROD_FaultMemory_Manipulation_NR

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request> with <Request_Type_Fault_Creation> to qualify the fault in the memory

2. Send <Prod_Diag_Request> with <Request_Type_Fault_Removal> to dequalify the fault in the memory


I<B<Evaluation>>

1. Response <Prod_Diag_Response> is received and fault is not qualified in the fault memory

2. Response <Prod_Diag_Response> is received and fault is not present in the fault memory


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Test_Condition' => 
	SCALAR 'Prod_Diag_Response' => 
	SCALAR 'purpose' => 
	SCALAR 'Prod_Diag_Request' => 
	SCALAR 'Event_ID' => 
	SCALAR 'Request_Type_Fault_Creation' => 
	SCALAR 'Request_Type_Fault_Removal' => 


=head2 PARAMETER EXAMPLES

	purpose ='To check the Fault manipulation Negative Responses'
	
	Prod_Diag_Request = 'Fault_Memory_Manipulation'
	
	Event_ID = '00 01'
	Request_Type_Fault_Creation = '01'
	Request_Type_Fault_Removal = '00'
	Test_Condition = 'BlockLengthMore'
	Prod_Diag_Response = 'NR_Fault_Memory_Manipulation_incorrectMessageLengthOrInvalidFormat'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_Event_ID, $defaultpar_purpose, $defaultpar_Prod_Diag_Request, $defaultpar_Prod_Diag_Response, $defaultpar_Request_Type_Fault_Creation, $defaultpar_Request_Type_Fault_Removal, $defaultpar_Test_Condition, );

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $PD_RequestLabel, $Trace_StoredfilePath, );

sub TC_set_parameters {

	$defaultpar_Event_ID                    = S_read_mandatory_testcase_parameter('Event_ID');
	$defaultpar_purpose                     = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request           = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$defaultpar_Prod_Diag_Response          = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$defaultpar_Request_Type_Fault_Creation = S_read_mandatory_testcase_parameter('Request_Type_Fault_Creation');
	$defaultpar_Request_Type_Fault_Removal  = S_read_mandatory_testcase_parameter('Request_Type_Fault_Removal');
	$defaultpar_Test_Condition              = S_read_mandatory_testcase_parameter('Test_Condition');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	#preparing the hash for the Fault Mamipulation cell
	my $faultqualification_request_string;
	my $faultdequalification_request_string;
	my $NRCInfo_ref;

	S_teststep( "Send '$defaultpar_Prod_Diag_Request' to Qualify the fault in the memory.", 'AUTO_NBR' );
	$PD_RequestLabel = {
		"EventID"      => "$defaultpar_Event_ID",
		"Request_Type" => "$defaultpar_Request_Type_Fault_Creation",
	};
	if ( lc($defaultpar_Test_Condition) =~ m /BlockLengthMore/i ) {
		$faultqualification_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request", $PD_RequestLabel, +1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response);
		DIAG_PD_request( $faultqualification_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( lc($defaultpar_Test_Condition) =~ m /BlockLengthLess/i ) {
		$faultqualification_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request", $PD_RequestLabel, -1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response);
		DIAG_PD_request( $faultqualification_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	else {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request", "$defaultpar_Prod_Diag_Response", $PD_RequestLabel );
	}

	S_teststep( "Send to Dequalify the fault in the memory", 'AUTO_NBR' );
	$PD_RequestLabel = {
		"EventID"      => "$defaultpar_Event_ID",
		"Request_Type" => "$defaultpar_Request_Type_Fault_Removal",
	};
	if ( $defaultpar_Test_Condition =~ m /BlockLengthMore/i ) {
		$faultdequalification_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request", $PD_RequestLabel, +1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response);
		DIAG_PD_request( $faultdequalification_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	elsif ( $defaultpar_Test_Condition =~ m /BlockLengthLess/i ) {
		$faultdequalification_request_string = GDCOM_requestlength_manipulation( "REQ_$defaultpar_Prod_Diag_Request", $PD_RequestLabel, -1 );
		$NRCInfo_ref = GDCOM_PD_getNRCfromMapping($defaultpar_Prod_Diag_Response);
		DIAG_PD_request( $faultdequalification_request_string, $NRCInfo_ref->{'Response'}, $NRCInfo_ref->{'Mode'}, $NRCInfo_ref->{'Desc'} );
	}
	else {
		DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request", "$defaultpar_Prod_Diag_Response", $PD_RequestLabel );
	}

	return 1;

}

sub TC_evaluation {

	S_w2rep( 'All evaluation for this step is done in stimulation and measurement', 'blue' );

	return 1;
}

sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Do the reset", 'AUTO_NBR' );
	LC_ECU_Reset();

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	return 1;

}

1;
__END__
