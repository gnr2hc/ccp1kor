#### TEST CASE MODULE
package TC_PROD_Read_Cell;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: PROD/TC_PROD_Read_Cell.pm 1.4 2020/04/28 13:46:37ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_can_access;
use Data::Dumper;
##################################

our $PURPOSE = "To check the Read Cell request and response values";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_Read_Cell  $Revision: 1.4 $


=head1 PURPOSE

This service shall be able to read RAM,ROM Cells and response for  Reading of the RAM/ROM  cells within 2msec'


=head1 TESTCASE DESCRIPTION 

[initialisation]
1.GEN_StandardPrepNoFault

2.DIAG_PD_Login_Level1
    
[stimulation & measurement]
 1. Send <Prod_Diag_Request1> to read the cell value of <Test Heading 1> section  


[evaluation]
1. Verify the response of the Prod_Diag_Response1 and response should be received within Max_ReadCell_Response_Time(2ms)  .

    
[finalisation]
Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			    -> 'purpose of the test case'
	SCALAR 'Prod_Diag_Request1'                     -> 'Request label for Read_Cell from  the Diagmapping File '
	SCALAR 'Prod_Diag_Response1'                    -> 'Response label for Read_Cell from  the Diagmapping File '
	SCALAR 'Start_Addres'                     		-> 'Read Cell Start byte (RAM)/(ROM)'
	SCALAR 'Max_ReadCell_Response_Time'             ->  Maximum time to receiving the response  for Readcell Request from the ECU. '
	SCALAR 'Block_Length'           		        ->  Block Length in  the first byte of response. '

=head2 PARAMETER EXAMPLES
	   
	[TC_PROD_Read_Cell.RAM_00_01]   #ID: SRTP_PRD1517
# From here on: applicable Lift Default Parameters
purpose			='This service shall be able to read RAM,ROM Cells and response for  Reading of the RAM/ROM  cells within 2msec'
Max_ReadCell_Response_Time = 2 # ms 
RequestLabel = %('NumberOfCells' => '00 01', 'StartAddress' => 'FE DF 44 68')
Prod_Diag_Request1		= 'Read_Cell'
Prod_Diag_Response1		= 'PR_Read_Cell'
Memory_Location = 'RAM'
Block_Length  ='00FF'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_purpose, $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_Max_ReadCell_Response_Time, $defaultpar_RequestLabel, $defaultpar_Memory_Location, );

############# Parameters from const files ################

################ global parameter declaration ##################

my ( $Readreqresp_hashref_step1, $Trace_StoredfilePath, $Readcellresp_time_withtol_step1, );

my @ReadCell_response_Arr;
my $Exp_responselength;
my $Rec_responselength;
my $ReadCell_response;

sub TC_set_parameters {

	$defaultpar_purpose                    = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Prod_Diag_Request1         = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1        = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_Max_ReadCell_Response_Time = S_read_mandatory_testcase_parameter('Max_ReadCell_Response_Time');
	$defaultpar_RequestLabel               = S_read_mandatory_testcase_parameter( 'RequestLabel', 'byref' );
	$defaultpar_Memory_Location            = S_read_mandatory_testcase_parameter('Memory_Location');

	return 1;

}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Replace the 'RAMstartaddress' with the actual start Addressfrom the .sad File", 'AUTO_NBR' );
	$defaultpar_RequestLabel = GEN_replaceAddressFromParameterFile($defaultpar_RequestLabel);

	S_teststep( "Send $defaultpar_Prod_Diag_Request1 and Verify the response $defaultpar_Prod_Diag_Response1 ", 'AUTO_NBR', 'Send_the_request' );
	S_teststep_2nd_level( "Avoid appending data to the existing log file", 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms(500);
	CA_simulation_start();

	S_teststep_2nd_level( "Start logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	
	#Get expect response length
	$Exp_responselength = $defaultpar_RequestLabel->{'NumberOfCells'};
	$Exp_responselength =~ s / //g;
	$Exp_responselength = S_0x2dec("0x$Exp_responselength");    # Decimal
	$Exp_responselength = $Exp_responselength + 2;

	S_teststep_2nd_level( "Send request: REQ_$defaultpar_Prod_Diag_Request1", 'AUTO_NBR' );
	if ( $Exp_responselength > 255 ) {
		S_w2log( 5, "Note : For  Reading the cells more than 253 cannot be done with the current DLL. This has to be verified manually", 'red' );
		$ReadCell_response = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel, 'NO_EVAL' );
	}
	else {
		$ReadCell_response = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel );
	}

	S_teststep( "Store the request and reponse from the can log file", 'AUTO_NBR' );
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(1);

	S_teststep_2nd_level( "Stop logging", 'AUTO_NBR' );
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	my $protocol = _get_communication_type();
	S_teststep( "Read the request and reponse from trace and put into the hash reference with '$protocol' protocol", 'AUTO_NBR' );
	$Readreqresp_hashref_step1 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	my $dump_ref = Dumper $Readreqresp_hashref_step1;
	S_w2rep( Dumper $Readreqresp_hashref_step1);

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Verify the response of the $defaultpar_Prod_Diag_Response1 and it should be received with in $defaultpar_Max_ReadCell_Response_Time ms.", 'AUTO_NBR' );
	if ( $defaultpar_Memory_Location eq 'DataFlash' ) {
		S_w2rep( "Response timing is not applicable for reading from Data Flash. So this is not evaluated", 'red' );
	}
	else {
		$Readcellresp_time_withtol_step1 = {
			"REQ_$defaultpar_Prod_Diag_Request1" => "$defaultpar_Max_ReadCell_Response_Time%0",    # 0 % Tolerance
		};

		S_teststep_2nd_level( "Do the timing evaluation", 'AUTO_NBR' );
		DIAG_EVAL_ResponseTime_from_dataref( $Readreqresp_hashref_step1, $Readcellresp_time_withtol_step1, $defaultpar_RequestLabel, undef, undef, '<' );
	}

	@ReadCell_response_Arr = split( / /, $ReadCell_response );
	$Rec_responselength = scalar @ReadCell_response_Arr;

	if ( $Exp_responselength > 255 ) {
		S_w2log( 5, "Note : For  Reading the cells more than 253 cannot be done with the current DLL. This has to be verified manually", 'red' );
	}
	else {
		S_teststep_expected( "Expected Response Length = $Exp_responselength", 'Send_the_request' );    #evaluation 1
		S_teststep_detected( "Received Response Length = $Rec_responselength", 'Send_the_request' );
		EVAL_evaluate_value( "Response Length", $Rec_responselength, '==', $Exp_responselength );
	}

	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 1000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

sub _get_communication_type {

	my $LIFT_COM_Type = $LIFT_config::LIFT_Testbench->{'Devices'}{'PDLayer'}{'BusType'};

	return $LIFT_COM_Type;
}

1;
__END__
