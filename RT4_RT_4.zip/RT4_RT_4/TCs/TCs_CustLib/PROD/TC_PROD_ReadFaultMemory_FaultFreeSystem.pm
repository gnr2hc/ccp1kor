#### TEST CASE MODULE
package TC_PROD_ReadFaultMemory_FaultFreeSystem;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_ReadFaultMemory_FaultFreeSystem.pm 1.3 2020/04/28 14:19:39ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use Data::Dumper;    # simple procedural interface4.
##################################

our $PURPOSE = 'To test the response of  Read Fault Recorder for fault free system';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

package TC_PROD_ReadFaultMemory_FaultFreeSystem;

=head1 PURPOSE

 'To test the response of  Read Fault  Recorder for fault free system'

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault.

Perform ECU Reset 

Erase the fault recorder using "Clear_Fault_Memory" with Mode 0

DIAG_PD_Login_Level1
 
[stimulation & measurement]

1.Read the Fault Recorder

2. Send <Prod_Diag_Request1> to read the Event ID and status for the <Test_Heading>  memory  .

[evaluation]

1. No faullts should be present in the fault recorder.

2. Verify the response of the <Prod_Diag_Response1> should be received for  the memoty location <Test_Heading>  and No faults should be reported in the service resposne.
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_ReadFaultMemory_FaultFreeSystem.Plant]   #ID: SRTP_PRD2597
Prod_Diag_Request1 = 'Read_Fault_Memory__Plant'
Prod_Diag_Response1='PR_Read_Fault_Memory__Plant'
# From here on: applicable Lift Default Parameters
purpose = 'To test the response of  Read Fault  Recorder for fault free system'
# From here on: the connection to Doors

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
my ( $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_purpose, $defaultpar_Test_Condition );
my ( $Readmemory_Response_observed,  $Trace_StoredfilePath, );
my ( $request,                       $memorysection );
my $clear_label_ref;

#PARAMETERS
################ Parameters from .par file ###################
sub TC_set_parameters {
	$defaultpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Test_Condition      = S_read_mandatory_testcase_parameter('Test_Condition');

	( $request, $memorysection ) = split( "__", $defaultpar_Prod_Diag_Request1 );

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Create test condition '$defaultpar_Test_Condition'", 'AUTO_NBR' );
	if ( $defaultpar_Test_Condition eq 'Idle' ) {
		S_w2rep( "Set ECU to idle mode", 'blue' );
		GEN_setECUMode('IdleMode');
	}
	elsif ( $defaultpar_Test_Condition eq 'Normal' ) {
		S_w2rep( "Condition is normal, no setting require", 'blue' );
	}
	else {
		S_w2rep( "Condition '$defaultpar_Test_Condition' is not yet support", 'red' );
		return 0;
	}

	S_teststep( 'Erase the fault recorder using "Clear_Fault_Memory" with Mode 0', 'AUTO_NBR' );
	CA_simulation_stop();
	S_wait_ms( 500, 'wait for canoe stop' );
	CA_simulation_start();
	S_wait_ms( 1000, 'wait for CAN timeout de-qualify' );

	my $clear_label_ref = { "Mode" => "00", };
	DIAG_PD_request_general( "REQ_Clear_Fault_Memory", "PR_Clear_Fault_Memory", $clear_label_ref );
	S_wait_ms( 5000, 'wait till fault memory is cleared' );

	# Read the Fault recorder is done in  the simulation step only
	GDCOM_CA_trace_start();
	S_teststep( "Send Prod_Diag_Request1 to read the Event ID and status for the $memorysection  memory .", 'blue' );
	if ( $memorysection eq 'Bosch' ) {
		S_w2rep( "For '$memorysection' memory, the data lenght is 0xFF, so not require the response", 'blue' );
		$Readmemory_Response_observed = DIAG_PD_request( "10 03", "50 03", 'quiet', 'read bosch mem', 'NO_EVAL' );
	}
	else {
		$Readmemory_Response_observed = DIAG_PD_request_general( "REQ_$defaultpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1" );
	}
	$Trace_StoredfilePath = GEN_getTraceNameWithTeststep(2);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath");

	return 1;

}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Evaluation for Step :2. Verify the response of the 'Prod_Diag_Response1' should be received for  the memory location  $defaultpar_Prod_Diag_Request1 and No faults should be reported in the service response.", 'AUTO_NBR' );
	_evaluate_response_read_mem( $Readmemory_Response_observed, $memorysection );

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	if ( $defaultpar_Test_Condition eq 'Idle' ) {
		S_teststep_2nd_level( "Set ECU to normal mdoe", 'AUTO_NBR' );
		GEN_setECUMode('RemoveIdleMode');
	}

	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Re-start Canoe", 'AUTO_NBR' );
	CA_simulation_start();

	S_wait_ms( 5000, 'wait for CAN timeout de-qualify' );
	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

sub _evaluate_response_read_mem {

	my $readmemory_response        = shift;
	my $mem_type                   = shift;
	my @readmemory_response_arr    = split( / /, $readmemory_response );
	my $readmemory_response_length = scalar @readmemory_response_arr;

	return 1 if $main::opt_offline;
	if ( $mem_type eq 'Plant' or $mem_type eq 'Primary' )

	{
		S_w2rep( "For '$mem_type' memory, the response require for fault free system is 3", 'blue' );
		EVAL_evaluate_value( "Check the data lenght for $mem_type memory", $readmemory_response_length, '==', 3 );
	}
	elsif ( $mem_type eq 'Distrubance' ) {
		S_w2rep( "For '$mem_type' memory, the response require for fault free system is 5", 'blue' );
		EVAL_evaluate_value( "Check the data lenght for $mem_type memory", $readmemory_response_length, '==', 5 );
	}
	elsif ( $mem_type eq 'Bosch' ) {
		S_w2rep( "For '$mem_type' memory, the byte 7th set to 0xFF to show that no fault in memory", 'blue' );
		_evaluate_response_read_mem_bosch();
	}
	else {
		S_w2rep( "$mem_type memory is not correct", 'red' );
		return 0;
	}

	return 1;
}

sub _evaluate_response_read_mem_bosch {

	my $read_mem_hashref = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	my $dump_ref = Dumper $read_mem_hashref;
	S_w2rep( "Data has ref: $dump_ref", 'bule' );
	my $request_str;

	foreach my $time_stamp ( sort { $a <=> $b } keys %{ $read_mem_hashref->{'Req_Resp'} } ) {
		$request_str = $read_mem_hashref->{'Req_Resp'}{$time_stamp}{'Request'};
		if ( $request_str =~ /03 10 03 16 FF FF FF FF/ )    #frame request will be fixed
		{
			my $response_arr_ref = $read_mem_hashref->{'Req_Resp'}{$time_stamp}{'Response'};
			my @second_frame_resp = split( / /, @$response_arr_ref[1] );
			S_w2rep( "The second frame in response is: @$response_arr_ref[1]", 'blue' );
			EVAL_evaluate_value( "The first byte of second frame should be 0xFF to show no fault in bosch memory", '0x' . $second_frame_resp[0], '==', '0xFF' );
			last;
		}

	}

	return 1;
}
1;
__END__
