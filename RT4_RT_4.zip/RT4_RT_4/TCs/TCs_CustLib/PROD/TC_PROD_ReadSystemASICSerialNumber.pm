#### TEST CASE MODULE
package TC_PROD_ReadSystemASICSerialNumber;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_ReadSystemASICSerialNumber.pm 1.3 2020/04/28 13:46:37ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary
use GENERIC_DCOM;
use LIFT_evaluation;
use LIFT_PD;

#include further modules here

##################################

our $PURPOSE = "To Read System ASIC Serial Number during different conditions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_ReadSystemASICSerialNumber

=head1 PURPOSE

To Read System ASIC Serial Number during different conditions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

PROD_Standard_Preparation

PROD_Login_Level1

Set <Test_Condition>


I<B<Stimulation and Measurement>>

1.Set the ECU to any plant mode.

2. Send <Prod_Diag_Request> to read system ASIC Serial Number. 


I<B<Evaluation>>

2.<Prod_Diag_Response> is received Within <Response_time>. Block length is 14H.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Test_Condition' => 
	SCALAR 'Prod_Diag_Response' => 
	SCALAR 'purpose' => 
	SCALAR 'Prod_Diag_Request' => 
	SCALAR 'Response_time' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To Read System ASIC Serial Number during different conditions' 
	
	Prod_Diag_Request = 'Read_System_ASIC_Serial_number' #$17H
	Response_time = '300' #ms
	Test_Condition = '<Test Heading>'
	Prod_Diag_Response =  'NR_conditionsNotCorrect'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Prod_Diag_Request;
my $tcpar_Response_time;
my $tcpar_Test_Condition;
my $tcpar_Prod_Diag_Response;

################ global parameter declaration ###################
#add any global variables here
my $response_str;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose            = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Prod_Diag_Request  = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_Response_time      = S_read_mandatory_testcase_parameter('Response_time');
	$tcpar_Test_Condition     = S_read_mandatory_testcase_parameter('Test_Condition');
	$tcpar_Prod_Diag_Response = S_read_mandatory_testcase_parameter('Prod_Diag_Response');

	return 1;
}

sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( 'Set the addressing mode to PD', 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Set '$tcpar_Test_Condition'", 'AUTO_NBR' );
	if ( $tcpar_Test_Condition ne 'PlantModeNotActive' ) {
		S_teststep( "Active any plant mode (plant mode 12) in condition not 'PlantModeNotActive'", 'AUTO_NBR' );
		GEN_setECUMode('PlantMode12_OnlyPlantDemActive');

	}
	else {
		S_teststep( "Condition will be set in request", 'AUTO_NBR' );
	}

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set the ECU to any plant mode.", 'AUTO_NBR' );
	S_w2rep( "=> done in TC_initialization", 'blue' );
	S_teststep( "Send '$tcpar_Prod_Diag_Request' to read system ASIC Serial Number. ", 'AUTO_NBR', 'send_prod_diag' );    #measurement 1
	if ( $tcpar_Test_Condition =~ m/BlockLengthMore/i ) {
		$response_str = DIAG_PD_request( '17 00', '7F 17 13 AD', 'VALID' );                                               #send one more 1 byte
	}
	else {
		$response_str = DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", "$tcpar_Prod_Diag_Response" );
	}

	S_teststep( "Remove plant mode", 'AUTO_NBR' );
	GEN_setECUMode('RemovePlantModes');

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "'$tcpar_Prod_Diag_Response' is received Within '$tcpar_Response_time'. Block length is 14H.", 'send_prod_diag' );    #evaluation 1
	S_teststep_detected( "Response get is: $response_str", 'send_prod_diag' );
	$response_str = '57 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00' if $main::opt_offline;
	my @response_arr = split( / /, $response_str );
	if ( $tcpar_Test_Condition eq 'ValidRequest' ) {
		S_teststep( "Check for data lenght of response, the lenght should be 20 (add 1 as checksum)", 'AUTO_NBR' );
		EVAL_evaluate_value( "Check data lenght of response", scalar @response_arr, '==', 20 );

		S_teststep( "Contain data for not populated asic should be set to 0", 'AUTO_NBR' );
		EVAL_evaluate_string( "Data for asic 3 should be 0", "00 00 00 00 00 00", "@response_arr[ 13 .. 18 ]" );
	}
	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	return 1;
}

1;
