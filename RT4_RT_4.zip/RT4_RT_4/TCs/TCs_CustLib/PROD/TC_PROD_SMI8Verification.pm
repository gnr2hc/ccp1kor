#### TEST CASE MODULE
package TC_PROD_SMI8Verification;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: PROD/TC_PROD_SMI8Verification.pm 1.3 2020/04/28 13:46:38ICT Dinh The Bao (RBVH/EPS24) (DBI1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis (https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-0004fe2b?doors.view=00000001)
#TS version in DOORS: 4.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_can_access;
##################################

our $PURPOSE = "To test the SMI8 Verification services - positive response";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_PROD_SMI8Verification

=head1 PURPOSE

To test the SMI8 Verification services - positive response

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. PROD_Standard_Preparation

2. PROD_Login_Level1


I<B<Stimulation and Measurement>>

1. Send <Prod_Diag_Request> to read the sensor data.

2. Read warning lamp status.

3. Reset ECU and read warning lamp status after init.

4. Repeat step2. Send <Prod_Diag_Request> to read the sensor data.

5.Send <Prod_Diag_Request1> to read the sensor. 

6.Verify SMA module serial numbers.

7.Verify SMI8/SMA7 processed data.

8.Verify SMI8_1 data block identifier.

9.Verify SMI8 module and ASIC serial number values.

10.Verify SMI8 temperature sensor values.

11. Verify SMI8_2 data block identifier.

12. Verify SMI8_2 numbers(Module serial number and ASIC serial number).

13. Verify SMI8_2 temperature sensor 01 and SMI8_2 temperature sensor 02 values.

14. Verify QuadI data block identifier.

15. Verify QuadI Roll data,Quadl Yaw,Quadl Yaw redundant and QuadI Pitch.

16. Verify Acceleration data block identifier.

17. Verify Sensor ID AccX high g,Sensor ID AccY high g,Sensor ID AccYrd high g,Sensor ID AccX mid g,Sensor ID AccX low g,Sensor ID AccZ low g,Sensor ID AccYrd low g,Sensor ID AccZrd low g.

18. Verify Rate data block identifier.

19. Verify Sensor Id Rate X,Sensor Id Rate Y,Sensor Id Rate Y,Sensor Id Rate Z and Sensor Id Rate Z redundant.


I<B<Evaluation>>

1. 

<Prod_Diag_Response> is received.

response is received within <ResponseTime> ms.

Unused (not configured) sensor bytes in the response are reported as 0.

2. Warning lamp should be in <State> for valid request.

3. Warning lamp should be in <State2>.

4.

<Prod_Diag_Response> is received.

response is received within <ResponseTime> ms.

Unused (not configured) sensor bytes in the response are reported as 0.

5.<Prod_Diag_Response1> is received.

6.SMA module serial numbers are obtained.

7.In core assets all bits/bytes will be returned with zero. If the customer project implements the support of the customer specific handling this has to be tested in the customer project.

8.SMI8 data block identifier should be equal to 44.

9.SMI8 module and ASIC serial number are obtained.

10.SMI8 temperature sensor data are obtained.

11.SMI8_2 data block identifier should be equal to 55.

12. Module serial number and ASIC serial number are observed.

13.SMI8_2 temperature sensor 01 and SMI8_2 temperature sensor 02 values are observed.

14. QuadI data block identifier should be 66.

15. QuadI Roll data,Quadl Yaw,Quadl Yaw redundant and QuadI Pitch are obtained.

16. Acceleration data block identifier will be equal to 77.

17. Sensor ID AccX high g,Sensor ID AccY high g,Sensor ID AccYrd high g,Sensor ID AccX mid g,Sensor ID AccX low g,Sensor ID AccZ low g,Sensor ID AccYrd low g,Sensor ID AccZrd low g are obtained.

18. Rate data block identifier will be equal to 88.

19. Sensor Id Rate X,Sensor Id Rate Y,Sensor Id Rate Y,Sensor Id Rate Z and Sensor Id Rate Z redundant values are obtained.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'SamplingDetails' => 
	SCALAR 'purpose' => 
	SCALAR 'Prod_Diag_Request' => 
	SCALAR 'Prod_Diag_Response' => 
	SCALAR 'NumberOfSamples' => 
	SCALAR 'ResponseTime' => 
	SCALAR 'State' => 
	SCALAR 'State2' => 
	SCALAR 'Prod_Diag_Request1' => 
	SCALAR 'Prod_Diag_Response1' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To test the SMI8 Verification services - positive response'
	
	Prod_Diag_Request = 'SMI8_Verification' #($0EH,01H)
	Prod_Diag_Response = 'PR_SMI8_Verification' #($4EH)
	NumberOfSamples = '00 02'
	ResponseTime = 2 #s
	State='ON'
	State2='OFF'
	Prod_Diag_Request1 = 'Routine request' #($0EH,03H)
	Prod_Diag_Response1 = 'PR_Routine request'
	#Note:Precondition to test this feature is you should have SMI8 sensors in hardware.
	SamplingDetails = '00 00 00 01'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Prod_Diag_Request;
my $tcpar_Prod_Diag_Response;
my $tcpar_NumberOfSamples;
my $tcpar_ResponseTime;
my $tcpar_State;
my $tcpar_State2;
my $tcpar_Prod_Diag_Request1;
my $tcpar_Prod_Diag_Response1;
my $tcpar_ControlTypes1;
my $tcpar_ControlTypes2;
my $tcpar_SamplingDetails;
my $tcpar_Signal;
my $tcpar_TestCondition;
################ global parameter declaration ###################
#add any global variables here
my $requestLabel;
my $lamp_state_beforereset_href;
my $Trace_StoredfilePath1;
my $Trace_StoredfilePath2;
my $lamp_state_afterreset_href;
my $response_observer;
my $response_observer_trace1;
my $response_observer_trace2;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Prod_Diag_Request   = S_read_mandatory_testcase_parameter('Prod_Diag_Request');
	$tcpar_Prod_Diag_Response  = S_read_mandatory_testcase_parameter('Prod_Diag_Response');
	$tcpar_NumberOfSamples     = S_read_mandatory_testcase_parameter('NumberOfSamples');
	$tcpar_ResponseTime        = S_read_mandatory_testcase_parameter('ResponseTime');
	$tcpar_State               = S_read_mandatory_testcase_parameter('State');
	$tcpar_State2              = S_read_mandatory_testcase_parameter('State2');
	$tcpar_Prod_Diag_Request1  = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$tcpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$tcpar_ControlTypes1       = S_read_mandatory_testcase_parameter('ControlTypes1');
	$tcpar_ControlTypes2       = S_read_mandatory_testcase_parameter('ControlTypes2');
	$tcpar_SamplingDetails     = S_read_mandatory_testcase_parameter('SamplingDetails');
	$tcpar_Signal              = S_read_optional_testcase_parameter('Signal');
	$tcpar_TestCondition       = S_read_optional_testcase_parameter('TestCondition');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Set the addressing mode to PD", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");

	S_teststep( "Login to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

sub TC_stimulation_and_measurement {

	$requestLabel->{'NumberOfSamples'} = $tcpar_NumberOfSamples;
	$requestLabel->{'SamplingDetails'} = $tcpar_SamplingDetails;

	S_teststep( "Set precondition if existence", 'AUTO_NBR' );
	if ( defined $tcpar_Signal and defined $tcpar_TestCondition ) {
		$tcpar_TestCondition =~ s/(\w+)\_(\d+\.\d+)/$2/g;
		$tcpar_TestCondition = $1;    #take value from condition
		CA_write_can_signal( $tcpar_Signal, $tcpar_TestCondition, 'phys' );
		S_wait_ms(1000);
	}

	S_teststep( "Send '$tcpar_Prod_Diag_Request' to read the sensor data.", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	$requestLabel->{'ControlType'} = $tcpar_ControlTypes1;
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );

	S_teststep( "Read warning lamp status.", 'AUTO_NBR', 'check WL before reset' );    #measurement 1
	$lamp_state_beforereset_href = PD_ReadLampStates();

	S_teststep( "Reset ECU and read warning lamp status after init.", 'AUTO_NBR', 'reset_ecu_and' );    #measurement 2
	S_teststep( "Reset ECU", 'AUTO_NBR' );
	LC_ECU_Reset();
	S_wait_ms(5000);

	S_teststep( "Read WL after reset ECU", 'AUTO_NBR', 'check WL after reset' );
	$lamp_state_afterreset_href = PD_ReadLampStates();

	S_teststep( "Repeat step2. Send '$tcpar_Prod_Diag_Request' to read the sensor data.", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request", $tcpar_Prod_Diag_Response, $requestLabel );

	$Trace_StoredfilePath1 = GEN_getTraceNameWithTeststep(1);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath1");
	$response_observer_trace1 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );

	S_teststep( "Start logging", 'AUTO_NBR' );
	GDCOM_CA_trace_start();

	S_teststep( "Send '$tcpar_Prod_Diag_Request1' to read the sensor. ", 'AUTO_NBR', 'send_prod_diag' );    #measurement 3
	$requestLabel->{'ControlType'}     = $tcpar_ControlTypes2;
	$requestLabel->{'NumberOfSamples'} = '';
	$requestLabel->{'SamplingDetails'} = '';

	S_teststep_2nd_level( "Wait 5s for routine finish", 'AUTO_NBR' );
	S_wait_ms(5000);

	S_teststep_2nd_level( "Send $tcpar_Prod_Diag_Request1", 'AUTO_NBR' );
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", $tcpar_Prod_Diag_Response, $requestLabel );

	S_teststep_2nd_level( "Store the request and reponse from the can log file", 'AUTO_NBR' );
	$Trace_StoredfilePath2 = GEN_getTraceNameWithTeststep(2);
	GDCOM_CA_trace_stop("$Trace_StoredfilePath2");

	S_teststep_2nd_level( "Get byte request from trace", 'AUTO_NBR' );
	$response_observer_trace2 = GDCOM_CA_Trace_get_ReqResp( 'PD', undef, undef, 'raw' );
	$response_observer = DIAG_PD_getResponseDataBytes($response_observer_trace2);
	$response_observer =
'b6 4e 03 75 38 e9 e9 2a a3 75 38 e9 e9 2a a3 00 00 00 00 00 00 00 00 00 00 44 33 e1 ca 46 c2 f7 73 39 07 e0 8e 35 00 00 00 00 01 12 a8 80 ff ff e8 90 f4 48 f4 48 00 00 00 00 01 12 a8 80 ff ff e8 90 f4 48 f4 48 55 43 e8 0a 4e f9 0c 69 39 07 f0 bc 41 00 00 00 00 01 12 a8 80 ff ff e8 90 f4 48 f4 48 00 00 00 00 01 12 a8 80 ff ff e8 90 f4 48 f4 48 66 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 77 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0000 00 00 00 00 00'
	  if ($main::opt_offline);

	S_teststep( "Verify SMA module serial numbers.", 'AUTO_NBR', 'verify_sma_module' );    #measurement 4
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8/SMA7 processed data.", 'AUTO_NBR', 'verify_smi8sma7_processed' );    #measurement 5
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8_1 data block identifier.", 'AUTO_NBR', 'verify_smi8_1' );            #measurement 6
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8 module and ASIC serial number values.", 'AUTO_NBR', 'verify_smi8_module' );    #measurement 7
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8 temperature sensor values.", 'AUTO_NBR', 'verify_smi8_temperature' );          #measurement 8
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8_2 data block identifier.", 'AUTO_NBR', 'verify_smi8_2_A' );                    #measurement 9
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8_2 numbers(Module serial number and ASIC serial number).", 'AUTO_NBR', 'verify_smi8_2_B' );    #measurement 10
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify SMI8_2 temperature sensor 01 and SMI8_2 temperature sensor 02 values.", 'AUTO_NBR', 'verify_smi8_2_C' );    #measurement 11
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify QuadI data block identifier.", 'AUTO_NBR', 'verify_quadi_data' );                                           #measurement 12
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify QuadI Roll data,Quadl Yaw,Quadl Yaw redundant and QuadI Pitch.", 'AUTO_NBR', 'verify_quadi_roll' );         #measurement 13
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify Acceleration data block identifier.", 'AUTO_NBR', 'verify_acceleration_data' );                             #measurement 14
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify Sensor ID AccX high g,Sensor ID AccY high g,Sensor ID AccYrd high g,Sensor ID AccX mid g,Sensor ID AccX low g,Sensor ID AccZ low g,Sensor ID AccYrd low g,Sensor ID AccZrd low g.", 'AUTO_NBR', 'verify_sensor_id_A' );    #measurement 15
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify Rate data block identifier.", 'AUTO_NBR', 'verify_rate_data' );                                                                                                                                                            #measurement 16
	S_w2rep( "Will implement in TC_evaluation", 'blue' );
	S_teststep( "Verify Sensor Id Rate X,Sensor Id Rate Y,Sensor Id Rate Y,Sensor Id Rate Z and Sensor Id Rate Z redundant.", 'AUTO_NBR', 'verify_sensor_id_B' );                                                                                  #measurement 17
	S_w2rep( "Will implement in TC_evaluation", 'blue' );

	return 1;
}

sub TC_evaluation {

	$tcpar_ResponseTime = $tcpar_ResponseTime * 1000;                                                                                                                                                                                              #convert to ms
	my $routine_control = {
		"REQ_$tcpar_Prod_Diag_Request" => "$tcpar_ResponseTime%0",                                                                                                                                                                                 #0 % Tolerance
	};
	S_teststep_expected("response is received within '$tcpar_ResponseTime' ms.");
	S_teststep_detected("Evaluation in DIAG_EVAL_ResponseTime_from_dataref");

	S_w2rep( "Check timing of request result", 'blue' );
	$requestLabel->{'ControlType'} = $tcpar_ControlTypes2;
	DIAG_EVAL_ResponseTime_from_dataref( $response_observer_trace2, $routine_control, $requestLabel, undef, undef, '<=' );

	S_w2rep( "Check timing of request read data", 'blue' );
	$requestLabel->{'NumberOfSamples'} = $tcpar_NumberOfSamples;
	$requestLabel->{'SamplingDetails'} = $tcpar_SamplingDetails;
	$requestLabel->{'ControlType'}     = $tcpar_ControlTypes1;
	DIAG_EVAL_ResponseTime_from_dataref( $response_observer_trace1, $routine_control, $requestLabel, undef, undef, '<=' );

	S_teststep_expected("Unused (not configured) sensor bytes in the response are reported as 0.");
	S_w2rep( "The byte order from 182 should be set to 0", 'blue' );
	my @response_observer = split / /, $response_observer;
	foreach my $index ( 182 .. ( scalar @response_observer ) ) {
		EVAL_evaluate_value( "Second SMI sensor for byte: $index", '0x' . $response_observer[ $index - 1 ], '==', 0x00 );
	}
	S_teststep_detected("Done in EVAL_evaluate_value");

	S_teststep_expected( "Warning lamp should be in '$tcpar_State' for valid request.", 'check WL before reset' );                                                                                                                                 #evaluation 1
	S_teststep_detected( "Detected WL state is: '$lamp_state_beforereset_href->{'System Warning Lamp'}'", 'check WL before reset' );
	EVAL_evaluate_string( "Check WL before reset", uc $tcpar_State, uc $lamp_state_beforereset_href->{'System Warning Lamp'} );

	S_teststep_expected( "The state WL should be in state '$tcpar_State2'", 'check WL after reset' );
	S_teststep_detected( "Detected WL state is: '$lamp_state_afterreset_href->{'System Warning Lamp'}'", 'check WL after reset' );
	EVAL_evaluate_string( "Check WL before reset", uc $tcpar_State2, uc $lamp_state_afterreset_href->{'System Warning Lamp'} );

	S_teststep_expected( "SMA module serial numbers are obtained.", 'verify_sma_module' );                                                                                                                                                         #evaluation 4
	S_teststep_detected( "NA", 'verify_sma_module' );
	S_set_error( 'Serial number not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "In core assets all bits/bytes will be returned with zero. If the customer project implements the support of the customer specific handling this has to be tested in the customer project.", 'verify_smi8sma7_processed' );    #evaluation 5
	S_teststep_detected( "byte content is @response_observer[21..24]", 'verify_smi8sma7_processed' );
	foreach my $index ( 22 .. 25 ) {
		EVAL_evaluate_value( "Second SMI sensor for byte: $index", '0x' . $response_observer[ $index - 1 ], '==', 0x00 );
	}

	S_teststep_expected( "SMI8 data block identifier should be equal to 0x44.", 'verify_smi8_1' );                                                                                                                                                      #evaluation 6
	S_teststep_detected( "byte content is order 26: $response_observer[25]", 'verify_smi8_1' );
	EVAL_evaluate_value( "SMI8 data block ID", '0x' . $response_observer[25], '==', 0x44 );

	S_teststep_expected( "SMI8 module and ASIC serial number are obtained.", 'verify_smi8_module' );                                                                                                                                                    #evaluation 7
	S_teststep_detected( "NA", 'verify_smi8_module' );
	S_set_error( 'Serial number not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "SMI8 temperature sensor data are obtained.", 'verify_smi8_temperature' );                                                                                                                                                     #evaluation 8
	S_teststep_detected( "NA", 'verify_smi8_temperature' );
	S_set_error( 'SMI8 temperature sensor data not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "SMI8_2 data block identifier should be equal to 0x55.", 'verify_smi8_2_A' );                                                                                                                                                  #evaluation 9
	S_teststep_detected( "byte content is order 71: $response_observer[70]", 'verify_smi8_2_A' );
	EVAL_evaluate_value( "SMI8_2 data block identifier", '0x' . $response_observer[70], '==', 0x55 );

	S_teststep_expected( "Module serial number and ASIC serial number are observed.", 'verify_smi8_2_B' );                                                                                                                                              #evaluation 10
	S_teststep_detected( "NA", 'verify_smi8_2_B' );
	S_set_error( 'Serial number not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "SMI8_2 temperature sensor 01 and SMI8_2 temperature sensor 02 values are observed.", 'verify_smi8_2_C' );                                                                                                                     #evaluation 11
	S_teststep_detected( "NA", 'verify_smi8_2_C' );
	S_set_error( 'MI8_2 temperature sensor 01 and SMI8_2 temperature sensor 02 values not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "QuadI data block identifier should be 0x66.", 'verify_quadi_data' );                                                                                                                                                          #evaluation 12
	S_teststep_detected( "byte content is order 116: $response_observer[115]", 'verify_quadi_data' );
	EVAL_evaluate_value( "QuadI data block identifier", '0x' . $response_observer[115], '==', 0x66 );

	S_teststep_expected( "QuadI Roll data,Quadl Yaw,Quadl Yaw redundant and QuadI Pitch are obtained.", 'verify_quadi_roll' );                                                                                                                          #evaluation 13
	S_teststep_detected( "NA", 'verify_quadi_roll' );
	S_set_error( 'QuadI Roll data,Quadl Yaw,Quadl Yaw redundant and QuadI Pitch not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "Acceleration data block identifier will be equal to 0x77.", 'verify_acceleration_data' );                                                                                                                                     #evaluation 14
	S_teststep_detected( "byte content is order 181: $response_observer[180]", 'verify_acceleration_data' );
	EVAL_evaluate_value( "Acceleration data block identifier", '0x' . $response_observer[180], '==', 0x77 );

	S_teststep_expected( "Sensor ID AccX high g,Sensor ID AccY high g,Sensor ID AccYrd high g,Sensor ID AccX mid g,Sensor ID AccX low g,Sensor ID AccZ low g,Sensor ID AccYrd low g,Sensor ID AccZrd low g are obtained.", 'verify_sensor_id_A' );      #evaluation 15
	S_teststep_detected( "NA", 'verify_sensor_id_A' );
	S_set_error( 'Sensor ID AccX high g,Sensor ID AccY high g,Sensor ID AccYrd high g,Sensor ID AccX mid g,Sensor ID AccX low g,Sensor ID AccZ low g,Sensor ID AccYrd low g,Sensor ID AccZrd low g not yet define as a clear parameter in TS', 0 );

	S_teststep_expected( "Rate data block identifier will be equal to 88.", 'verify_rate_data' );                                                                                                                                                       #evaluation 16
	S_teststep_detected( "byte content is order 374: $response_observer[373]", 'verify_rate_data' );
	EVAL_evaluate_value( "QuadI data block identifier", '0x' . $response_observer[373], '==', 0x88 ) unless ($main::opt_offline);

	S_teststep_expected( "Sensor Id Rate X,Sensor Id Rate Y,Sensor Id Rate Y,Sensor Id Rate Z and Sensor Id Rate Z redundant values are obtained.", 'verify_sensor_id_B' );                                                                             #evaluation 17
	S_teststep_detected( "NA", 'verify_sensor_id_B' );
	S_set_error( 'Sensor Id Rate X,Sensor Id Rate Y,Sensor Id Rate Y,Sensor Id Rate Z and Sensor Id Rate Z redundant not yet define as a clear parameter in TS', 0 );

	return 1;
}

sub TC_finalization {
	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Start can trace again to avoid time out fault", 'AUTO_NBR' );
	GDCOM_CA_trace_start();
	S_wait_ms( 1000, 'wait for fault de-qualify' );

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;
}

1;
