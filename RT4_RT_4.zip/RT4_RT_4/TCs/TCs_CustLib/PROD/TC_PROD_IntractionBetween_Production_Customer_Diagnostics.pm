#### TEST CASE MODULE
package TC_PROD_IntractionBetween_Production_Customer_Diagnostics;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: PROD/TC_PROD_IntractionBetween_Production_Customer_Diagnostics.pm 1.5 2020/05/23 11:43:21ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;
##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_PROD_ProductionDiagnosis
#TS version in DOORS: 3.43
#-------------------------------------------------------------------------
#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general;
use LIFT_evaluation;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_DCOM;
use LIFT_can_access;
use LIFT_CD_CAN;
use Data::Dumper;    # simple procedural interface4.
use LIFT_PD;
use LIFT_CD;
##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
our $PURPOSE = 'To Check  the intraction between  the production and customer Diagnostics';

=head1 TESTCASE MODULE

package TC_PROD_IntractionBetween_Production_Customer_Diagnostics;

=head1 PURPOSE

 'To Check  the intraction between  the production and customer Diagnostics'

=head1 TESTCASE DESCRIPTION 

[initialisation]

GEN_StandardPrepNoFault

DIAG_PD_Login_Level1
 
[stimulation & measurement]

1.Send the customer Diagnostics Request <Cust_Diag_Request1> periodicially at every 2  sec

2. Send <Prod_Diag_Request1>

3.Send the customer Diagnostics Request ' <Cust_Diag_Request2>

4. Send <Prod_Diag_Request1>

[evaluation]


1. Check the <Cust_Diag_Response1> 'should be received.

2. <Prod_Diag_Response1> should be received  .

3. Check the <Cust_Diag_Response2> 'should be received.

4. <Prod_Diag_Response1> should be received  .
    
[finalisation]

1. Fault free Setup

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES


    SCALAR 'Prod_Diag_Request1                      ' ->  ' Request label for the PD service from the Diagmapping File  '
    SCALAR 'Prod_Diag_Response1                     ' ->  ' Response label for the PD service from the Diagmapping File  '
    SCALAR 'purpose                                 ' ->  ' purpose of the test case  '
    SCALAR 'Cust_Diag_Request1                      ' ->  '  Request label for the CD service from the Diagmapping File  '
    SCALAR 'Cust_Diag_Response1                     ' ->  '   Response label for the CD service from the Diagmapping File '
    SCALAR 'Cust_Diag_Request2                      ' ->  '    Request label for the CD service from the Diagmapping File'
    SCALAR 'Cust_Diag_Response2                     ' ->  '    Response label for the CD service from the Diagmapping File'
    SCALAR 'RequestLabel                            ' ->  '     label parameters  for the PD service from the Diagmapping File'

=head2 PARAMETER EXAMPLES
	   
[TC_PROD_IntractionBetween_Production_Customer_Diagnostics.ECU_Status]   #ID: TS_PRD2201
Prod_Diag_Request1 ='ECU_Status'
Prod_Diag_Response1='PR_ECU_Status'
# From here on: applicable Lift Default Parameters
purpose = 'To Check  the intraction between  the production and customer Diagnostics'
Cust_Diag_Request1 ='CD_Tester_Present_With_Res'
Cust_Diag_Response1 ='PR_CD_Tester_Present_With_Resp'
Cust_Diag_Request2  = 'CD_Default_Session'
Cust_Diag_Response2  = 'PR_CD_Default_Session'
RequestLabel = ''
# From here on: the connection to Doors



=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ( $defaultpar_Prod_Diag_Request1, $defaultpar_Prod_Diag_Response1, $defaultpar_purpose, $defaultpar_Cust_Diag_Request1, $defaultpar_Cust_Diag_Response1, $defaultpar_Cust_Diag_Request2, $defaultpar_Cust_Diag_Response2, $defaultpar_RequestLabel, );
my $tcpar_Prod_Diag_Request1;
my ( $req_ID, $respID );
my $MSG_handle;
############# Parameters from const files ################

sub TC_set_parameters {
	$tcpar_Prod_Diag_Request1       = S_read_mandatory_testcase_parameter('Prod_Diag_Request1');
	$defaultpar_Prod_Diag_Response1 = S_read_mandatory_testcase_parameter('Prod_Diag_Response1');
	$defaultpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$defaultpar_Cust_Diag_Request1  = S_read_mandatory_testcase_parameter('Cust_Diag_Request1');
	$defaultpar_Cust_Diag_Response1 = S_read_mandatory_testcase_parameter('Cust_Diag_Response1');
	$defaultpar_Cust_Diag_Request2  = S_read_mandatory_testcase_parameter('Cust_Diag_Request2');
	$defaultpar_Cust_Diag_Response2 = S_read_mandatory_testcase_parameter('Cust_Diag_Response2');
	$defaultpar_RequestLabel        = S_read_optional_testcase_parameter( 'RequestLabel', 'byref' );

	return 1;
}

#### INITIALIZE TC ####'
sub TC_initialization {

	S_teststep( 'StandardPrepNoFault', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Send the customer Diagnostics Request 'Cust_Diag_Request1' periodicially at every 2  sec", 'AUTO_NBR' );
	( $req_ID, $respID ) = GDCOM_set_addressing_mode("physical");

	S_teststep( "Evaluation for Step 1. RESPONSE: '$defaultpar_Cust_Diag_Response1' should be received.", 'AUTO_NBR' );
	$MSG_handle = CD_send_message( [ 0x02, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 ], $req_ID, 2000 );    #sends TP on physical ID for every 2secs

	S_teststep( "Send REQUEST: '$tcpar_Prod_Diag_Request1 '", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 2.RESPONSE: '$defaultpar_Prod_Diag_Response1' should be received .", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("PD");
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel );

	if ( $tcpar_Prod_Diag_Request1 =~ /Reset/ ) {
		S_wait_ms(10000);
	}

	S_teststep( "Send the customer Diagnostics Request '10 01' Cust_Diag_Request2' ", 'AUTO_NBR' );
	S_w2rep( "Evaluation for Step 3. Check the 'Cust_Diag_Response2' 'should be received.", 'blue' );
	GDCOM_set_addressing_mode("physical");
	GDCOM_request( '10 01', '50 01', 'relax', 'Response for the Diagnostics session ' );

	S_teststep( "Send REQUEST:'$tcpar_Prod_Diag_Request1'", 'AUTO_NBR' );
	S_w2rep( " Evaluation for Step  4.RESPONSE:'$defaultpar_Prod_Diag_Response1' should be received .", 'blue' );
	S_teststep( "Logging to ECU", 'AUTO_NBR' );
	PD_ECUlogin();
	GDCOM_set_addressing_mode("PD");
	DIAG_PD_request_general( "REQ_$tcpar_Prod_Diag_Request1", "$defaultpar_Prod_Diag_Response1", $defaultpar_RequestLabel );

	S_w2rep( "Stop the tester present Service", 'blue' );
	CD_stop_message($MSG_handle);
	if ( $tcpar_Prod_Diag_Request1 =~ /Reset/ ) {
		S_wait_ms(10000);
	}

	S_wait_ms( 2000, 'wait for before clear fault memory' );

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	S_teststep( "Bring the ECU back to normal mode", 'AUTO_NBR' );
	S_teststep_2nd_level( "Set addressing mode to physical address", 'AUTO_NBR' );
	GDCOM_set_addressing_mode("physical");

	S_teststep_2nd_level( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();

	return 1;

}

1;
__END__
