#### TEST CASE MODULE
package TC_SYC_PeripheralSensorConfiguration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_PeripheralSensorConfiguration.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_evaluation;
use LIFT_PD;

##################################

our $PURPOSE = "To verify sensor configuration status and channel head position";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_PeripheralSensorConfiguration

=head1 PURPOSE

To verify sensor configuration status and channel head position

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read Sensor configuration information using <Sensor_Configuration_Variable> for each <Sensor>

2. Read channel head position of each <Sensor> using <Sensor_Head_Variable>


I<B<Evaluation>>

1. <Sensor_Configuration_Value> obtained for each <Sensor>

2. <Sensor_Head_Value> obtained for each <Sensor>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Sensor_Configuration_Value' => 
	SCALAR 'Sensor_Head_Value' => 
	SCALAR 'purpose' => 
	SCALAR 'Sensor' => 
	SCALAR 'Sensor_Configuration_Variable' => 
	SCALAR 'Sensor_Head_Variable' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To verify sensor configuration status and channel head position.
	Sensor ='UFSD'
	Sensor_Configuration_Variable ='rb_sycp_SysConfPsNvmCfgData_st.ChannelConfigured_ab8'
	Sensor_Head_Variable ='rb_sycp_SysConfPsRomCfgData_cst.ChannelRomCfgData_ast'
	Sensor_Configuration_Value ='0bxxxxxxx1'
	Sensor_Head_Value ='01'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Sensor;
my $tcpar_Sensor_Configuration_Variable;
my $tcpar_Sensor_Head_Variable;
my $tcpar_Sensor_Configuration_Value;
my $tcpar_Sensor_Head_Value;

################ global parameter declaration ###################
my (@Sensor_Conf_Val,@Sensor_Head_Val);
my $i;
my $j;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_optional_testcase_parameter( 'purpose' );
	$tcpar_Sensor =  GEN_Read_mandatory_testcase_parameter( 'Sensor' );
	$tcpar_Sensor_Configuration_Variable =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Configuration_Variable' );
	$tcpar_Sensor_Head_Variable =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Head_Variable' );
	$tcpar_Sensor_Configuration_Value =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Configuration_Value' );
	$tcpar_Sensor_Head_Value =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Head_Value' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	use Switch;
	GEN_printTestStep("Step 1. Read Sensor configuration information using '$tcpar_Sensor_Configuration_Variable' for each '$tcpar_Sensor'");
		
	for($i=0;$i<2;$i++)
	{
		$Sensor_Conf_Val[$i]= S_aref2hex(PD_ReadMemoryByName("$tcpar_Sensor_Configuration_Variable($i)"));
		
	}	
	
	GEN_printTestStep("Step 2. Read channel head position of each '$tcpar_Sensor' using '$tcpar_Sensor_Head_Variable'");

	for($j=0; $j<12;$j++)
	{
		$Sensor_Head_Val[$j]=S_aref2hex(PD_ReadMemoryByName("$tcpar_Sensor_Head_Variable($j).OrientationInverted_bo"));
		
	}
	switch($tcpar_Sensor)
	{
		case "UFSD"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[0]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[0],'==',$tcpar_Sensor_Head_Value);
		}
		case "UFSP"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[1]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[1],'==',$tcpar_Sensor_Head_Value);
		}
		case "PASFD"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[2]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[2],'==',$tcpar_Sensor_Head_Value);
		}
		case "PASFP"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[3]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[3],'==',$tcpar_Sensor_Head_Value);
		}
		case "PASMD"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[4]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[4],'==',$tcpar_Sensor_Head_Value);
		}
		case "PASMP"	
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[5]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[5],'==',$tcpar_Sensor_Head_Value);
		}
		case "PPSFD"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[6]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[6],'==',$tcpar_Sensor_Head_Value);
		}
		case "PPSFP"	
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[0]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[7]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[0],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[7],'==',$tcpar_Sensor_Head_Value);
		}
		case "PCSD"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[1]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[8]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[1],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[8],'==',$tcpar_Sensor_Head_Value);
		}
		case "PCSP"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[1]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[9]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[1],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[9],'==',$tcpar_Sensor_Head_Value);
		}	
		case "PCSC"
		{
			GEN_printComment("Sensor configuration Value obtained is $Sensor_Conf_Val[1]\n");
			GEN_printComment("Sensor Head Value obtained for Sensor '$tcpar_Sensor' is $Sensor_Head_Val[10]\n");
			EVAL_evaluate_value("Sensor Configuration Value for '$tcpar_Sensor'", $Sensor_Conf_Val[1],'MASK',$tcpar_Sensor_Configuration_Value);
			EVAL_evaluate_value("Sensor Head Value for '$tcpar_Sensor'",$Sensor_Head_Val[11],'==',$tcpar_Sensor_Head_Value);
		}	
	}	
	return 1;
}

sub TC_evaluation {


	GEN_printTestStep("Evaluation for Step 1. '$tcpar_Sensor_Configuration_Value' obtained for each '$tcpar_Sensor-Evaluation done at Stimulation and measurement.'");

	GEN_printTestStep("Evaluation for Step 2. '$tcpar_Sensor_Head_Value' obtained for each '$tcpar_Sensor'-Evaluation done at Stimulation and measurement.");
	
	return 1;
}

sub TC_finalization {
	GEN_Finalization();
	return 1;
}


1;
