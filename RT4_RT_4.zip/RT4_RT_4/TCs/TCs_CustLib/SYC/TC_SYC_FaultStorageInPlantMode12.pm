#### TEST CASE MODULE
package TC_SYC_FaultStorageInPlantMode12;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_FaultStorageInPlantMode12.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_PD;
use Switch;

##################################

our $PURPOSE = "To Verify that newly created faults are stored only to Bosch fault memory when plant mode 12 is active";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_FaultStorageInPlantMode12

=head1 PURPOSE

To Verify that newly created faults are stored only to Bosch fault memory when plant mode 12 is active

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Create <Fault>

2. Read <Fault_Recorder>

3. Create <Condition>

4. Create <Fault2>

5. Read <Fault_Recorder>

6. Remove <Condition>

7. Create <Fault3>

8. Read <Fault_Recorder>


I<B<Evaluation>>

2. <Fault> is present in <Fault_recorder2>

5. <Fault2> is present in <Fault_recorder> along with <Fault4>

8. <Fault3> is present in <Fault_Recorder2> 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => Purpose of the test case
	LIST 'Fault_Recorder' => Type of Fault recorder
	SCALAR 'Fault' => Event created
	SCALAR 'Condition' => Condition to be set
	SCALAR 'Fault2' => Event 2 created
	SCALAR 'Fault3' => Event 3 created
	SCALAR 'Fault4' => Event 4 created
	LIST 'Fault_recorder2' => Type of Fault recorder


=head2 PARAMETER EXAMPLES

	Fault= 'Squib_Openline'
	Condition= '<Test Heading>'
	Fault2= 'Switch_Short2Bat'
	Fault3= 'Squib_Short'
	Fault4= 'None'
	Fault_recorder2= @('Primary','Bosch')
	Purpose= 'To Verify that newly created faults are stored only to Bosch fault memory when plant mode 12 is active'
	
	Fault_Recorder= @('Bosch')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Fault;
my $tcpar_Condition;
my $tcpar_Fault2;
my $tcpar_Fault3;
my $tcpar_Fault4;
my @tcpar_Fault_recorder2;
my $tcpar_purpose;
my @tcpar_Fault_Recorder;

################ global parameter declaration ###################
my $fault_Recorder1_Primary;
my $fault_Recorder1_Bosch;
my $fault_Recorder2_Primary;
my $fault_Recorder2_Bosch;
my $fault_Recorder3_Primary;
my $fault_Recorder3_Bosch;
my $Occurance;
###############################################################

sub TC_set_parameters {

	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_Condition =  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Fault2 =  GEN_Read_mandatory_testcase_parameter( 'Fault2' );
	$tcpar_Fault3 =  GEN_Read_mandatory_testcase_parameter( 'Fault3' );
	$tcpar_Fault4 =  GEN_Read_mandatory_testcase_parameter( 'Fault4' );
	@tcpar_Fault_recorder2 =  GEN_Read_mandatory_testcase_parameter( 'Fault_recorder2' );
	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	@tcpar_Fault_Recorder =  GEN_Read_mandatory_testcase_parameter( 'Fault_Recorder' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {


	GEN_printTestStep("Step 1. Create '$tcpar_Fault'");
	FM_createFault($tcpar_Fault);
	S_wait_ms(4000);
	GEN_printTestStep("Step 2. Read '@tcpar_Fault_Recorder'");
	$fault_Recorder1_Primary=PD_ReadFaultMemory(1);
	$fault_Recorder1_Bosch=PD_ReadFaultMemory(3);

	GEN_printTestStep("Step 3. Create '$tcpar_Condition'");
	switch($tcpar_Condition)
	{
		case "Plantmode12"
		{
			PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)",[0x10]);
			GEN_Power_on_Reset();
		}
		case "WrongPlantMode"
		{
			PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)",[0x04]);
			GEN_Power_on_Reset();
		}
		case "NotinPlantmode"
		{
			PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)",[00]);
			PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)",[00]);
			PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(2)",[00]);
			GEN_Power_on_Reset();
		}
	}		

	GEN_printTestStep("Step 4. Create '$tcpar_Fault2'");
	FM_createFault($tcpar_Fault2);
	S_wait_ms(4000);
	GEN_printTestStep("Step 5. Read '@tcpar_Fault_Recorder'");
	$fault_Recorder2_Primary=PD_ReadFaultMemory(1);
	$fault_Recorder2_Bosch=PD_ReadFaultMemory(3);

	GEN_printTestStep("Step 6. Remove '$tcpar_Condition'");
	PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)",[00]);
	PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)",[00]);
	PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(2)",[00]);
	GEN_Power_on_Reset();

	GEN_printTestStep("Step 7. Create '$tcpar_Fault3'");
	FM_createFault($tcpar_Fault3);
	S_wait_ms(4000);
	GEN_printTestStep("Step 8. Read '@tcpar_Fault_Recorder'");
	$fault_Recorder3_Primary=PD_ReadFaultMemory(1);
	$fault_Recorder3_Bosch=PD_ReadFaultMemory(3);

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 2. '$tcpar_Fault' is present in '@tcpar_Fault_recorder2'");
	PD_check_fault_exists( $fault_Recorder1_Primary, $tcpar_Fault );
	PD_check_fault_exists( $fault_Recorder1_Bosch, $tcpar_Fault );

	GEN_printTestStep("Evaluation for Step 5. '$tcpar_Fault2' is present in '@tcpar_Fault_Recorder' along with '$tcpar_Fault4'");
	switch($tcpar_Condition)
	{
		case "Plantmode12"
		{
			PD_check_fault_exists( $fault_Recorder2_Primary, $tcpar_Fault );
			$Occurance=PD_count_fault($fault_Recorder2_Primary,$tcpar_Fault2);
			if($Occurance<1)
			{
				GEN_printComment(" Fault $tcpar_Fault2 doesn't exist in Primary fault memory\n" );
				S_set_verdict('VERDICT_PASS');
			}
			else
			{
				GEN_printComment(" Fault $tcpar_Fault2  exist in Primary fault memory\n" );
				S_set_verdict('VERDICT_FAIL');
			}	
			PD_check_fault_exists( $fault_Recorder2_Bosch, $tcpar_Fault2 );
		}
		else
		{
			PD_check_fault_exists( $fault_Recorder2_Primary, $tcpar_Fault2 );
			PD_check_fault_exists( $fault_Recorder2_Bosch, $tcpar_Fault2 );
		}
	}		

	GEN_printTestStep("Evaluation for Step 8. '$tcpar_Fault3' is present in '@tcpar_Fault_recorder2' ");
	PD_check_fault_exists( $fault_Recorder3_Primary, $tcpar_Fault3 );
	PD_check_fault_exists( $fault_Recorder3_Bosch, $tcpar_Fault3 );

	return 1;
}

sub TC_finalization {

	FM_removeFault($tcpar_Fault);
	FM_removeFault($tcpar_Fault2);
	FM_removeFault($tcpar_Fault3);
	return 1;
}


1;
