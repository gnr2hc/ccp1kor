#### TEST CASE MODULE
package TC_SYC_ExternalDeviceConfiguration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.8 $; 
our $HEADER = q$Header: SYC/TC_SYC_ExternalDeviceConfiguration.pm 1.8 2020/06/23 16:42:49ICT Reddivari Devendra Kumar (RBEI/ESA-PP) (dvn2kor) develop  $;  
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general; 
use LIFT_evaluation; 
use LIFT_PD;
use FuncLib_TNT_GEN;
use FuncLib_ACEA_TNT;
use INCLUDES_Project;
use LIFT_labcar;

##################################
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.31
#-------------------------------------------------------------------------
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_ExternalDeviceConfiguration  $Revision: 1.8 $


=head1 PURPOSE

to check requirements related to monitoring, configuration and presence bits

=head1 TESTCASE DESCRIPTION 

[initialisation]
StandardPrepNoFault
Set the ECU mode
    
[stimulation & measurement]
1. Set the status of device:
a) Set the monitoring bit to MonitoringBitStatus using PD
b) Set the configuration bit to ConfigurationBitStatus using PD
c) Connect/disconnect the external device according to DevicePresenceStatus

2. Read the configuration status of device
a) Monitoring bit
b) Configuration bit
c) Device Presence bit

3. Read the fault recorder

4. Reset the ECU and read the fault recorder after initialization

5. Read the configuration status of the device:
a) Monitoring bit
b) Configuration bit
c) Device Presence bit

6. Configure, enable monitoring and connect device

7. Reset the ECU and read the fault recorder after initialization

8. Read the configuration status of device
a) Monitoring bit
b) Configuration bit
c) Device Presence bit


[evaluation]
2. Status of these bits:
a) MonitoringBitValue
b) ConfigurationBitValue
c) PresenceBitValue

3. expected faults are FLTmand_BeforeReset

4. expected faults are FLTmand_AfterReset

5. Status of these bits are same as set in step 2:
a) MonitoringBitValue
b) ConfigurationBitValue
c) PresenceBitValue

7. expected faults are FLTmand_NormalStatus

8. 
These bits corresponding to the device are set in normal mode
Presence bit is not set in Idle mode. Other bits are set

    
[finalisation]
 -

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			   --> 'purpose of the test case'
	SCALAR 'mode'                   			   --> 'ECU mode to be set for this TC e.g. NormalMode'
	SCALAR 'device'                 	   		   --> 'device under test'
	SCALAR 'MonitoringBitStatus'                   --> 'e.g. set_Mon or clear_Mon' 
	SCALAR 'ConfigurationBitStatus' 			   --> 'e.g. set or clear'
	SCALAR 'DevicePresenceStatus' 				   --> 'e.g. present of notPresent'
	SCALAR 'MonitoringBitValue'                    --> '0 or 1' 
	SCALAR 'ConfigurationBitValue' 			 	   --> '0 or 1'
	SCALAR 'PresenceBitValue' 			   		   --> '0 or 1'
	HASH 'FLTmand_BeforeReset ' 				   --> 'step 3 mandatory/expected faults with status'
	HASH 'FLTmand_AfterReset' 					   --> 'step 4 mandatory/expected faults with status'
	HASH 'FLTmand_NormalStatus' 				   --> 'step 7 mandatory/expected faults with status'


=head2 PARAMETER EXAMPLES
	   
	[TC_SYC_ExternalDeviceConfiguration.NormalMode_Monitored_NotConfigured_PresentSwitch10]   #ID: SRTP_SYC_4532
	# From here on: applicable Lift Default Parameters
	purpose = 'to check the status of the monitoring, configuration and presence bits, when the device is monitored, not configured, but physically present'
	mode = 'NormalMode'
	device = 'Switch10'
	MonitoringBitStatus = '1'
	ConfigurationBitStatus = '0'
	DevicePresenceStatus = '1'
	FLTmand_BeforeReset = %(' ') #no faults
	FLTmand_AfterReset = %('UnexpectedDevice_FAULT' => '0bxxxxx111') #filtered, latched and stored
	FLTmand_NormalStatus = %('UnexpectedDevice_FAULT' => '0bxxxxx100')  #only stored

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my (
	$defaultpar_mode,
	$defaultpar_device,
    $defaultpar_MonitoringBitStatus,
    $defaultpar_ConfigurationBitStatus,
    $defaultpar_DevicePresenceStatus,
    $defaultpar_MonitoringBitValue,
    $defaultpar_ConfigurationBitValue,
    $defaultpar_PresenceBitValue,
    $defaultpar_FLTmand_BeforeReset,
    $defaultpar_FLTmand_AfterReset,
    $defaultpar_FLTmand_NormalStatus,
    $defaultpar_CheckFLT_ConfigDataInconsistent,
    @tcpar_FLTmand, 
    $tcpar_FLT_state_href,
    $tcpar_DTC_exp_href,
	);

############# Parameters from mapping files ################  
my ($deviceName,$SwitchType);
	

################ global parameter declaration ################## 	
my (%flt_mem_struct_observed,
    $Real,$Monitored_ID,$Prog,
	$PresenceBit_observed_step1a,
	$Monitored_observed_step1a,
	$Configured_observed_step1a,
	$PresenceBit_observed_step1b,
	$Monitored_observed_step1b,
	$Configured_observed_step1b,
	$PresenceBit_observed_step2,
	$Monitored_observed_step2,
	$Configured_observed_step2,
	$PresenceBit_observed_step5,
	$Monitored_observed_step5,
	$Prog_observed_step5,
	$PresenceBit_observed_step8,
	$Monitored_observed_step8,
	$Prog_observed_step8);
our $PURPOSE;	
my $VERDICT;


sub TC_set_parameters {
    
    $defaultpar_mode =  S_read_mandatory_testcase_parameter ( 'mode' );
    $defaultpar_device =  S_read_mandatory_testcase_parameter ( 'device' );  
    $defaultpar_MonitoringBitStatus =  S_read_mandatory_testcase_parameter ( 'MonitoringBitStatus' );  
    $defaultpar_ConfigurationBitStatus =  S_read_mandatory_testcase_parameter ( 'ConfigurationBitStatus' ); 
    $defaultpar_DevicePresenceStatus =  S_read_mandatory_testcase_parameter ( 'DevicePresenceStatus' );
    $defaultpar_MonitoringBitValue =  S_read_mandatory_testcase_parameter ( 'MonitoringBitValue' );  
    $defaultpar_ConfigurationBitValue =  S_read_mandatory_testcase_parameter ( 'ConfigurationBitValue' ); 
    $defaultpar_PresenceBitValue =  S_read_mandatory_testcase_parameter ( 'PresenceBitValue' );    
    $defaultpar_FLTmand_BeforeReset = S_read_mandatory_testcase_parameter ( 'FLTmand_BeforeReset' ,'byref' );
    $defaultpar_FLTmand_AfterReset = S_read_mandatory_testcase_parameter ( 'FLTmand_AfterReset' ,'byref' );
    $defaultpar_FLTmand_NormalStatus = S_read_mandatory_testcase_parameter ( 'FLTmand_NormalStatus' ,'byref' );
    $defaultpar_CheckFLT_ConfigDataInconsistent = S_read_mandatory_testcase_parameter ( 'CheckFLT_ConfigDataInconsistent' ,'byref' );
	
    
    $tcpar_FLT_state_href = ();
    @tcpar_FLTmand        = ();
    
     if ( $defaultpar_CheckFLT_ConfigDataInconsistent eq 'yes' ) {
     	
        $tcpar_FLT_state_href = S_read_testcase_parameter( 'FLTmand_BeforeReset', 'byref' ); #FLTmand_BeforeReset or FLTmand_AfterReset fault will be the same for NotMonitored, Configured use cases.
        
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href;

        $tcpar_DTC_exp_href = S_read_testcase_parameter( '_DTC_EXP', 'byref' );
    }
    
    # check if used constants are defined and read them
    $deviceName = DEVICE_fetchDeviceNamebyDeviceNumber ($defaultpar_device);
if ($defaultpar_device =~ m/BL/i)
	{
	$SwitchType = DEVICE_fetchSwitchType($deviceName);
	}
    #to print the purpose
    $PURPOSE = "to check device configuration for external device: $defaultpar_device - $deviceName";  
    unless(defined $deviceName and $deviceName ne '' and $deviceName ne 'NONE' ){
	S_w2rep("$deviceName is not present in the project");
	S_set_verdict(VERDICT_NONE);
	
	$VERDICT = VERDICT_NONE;
	return 1;
	}
 ($Real,$Monitored_ID,$Prog) = PD_get_device_config($deviceName);
 $PURPOSE = "to check device presence bit for external device: $defaultpar_device - $deviceName";
	if($Real eq '0'){
	S_set_verdict(VERDICT_NONE);
	$VERDICT = VERDICT_NONE;
	return 1;
	}
	return 1;
	}

#### INITIALIZE TC #####
sub TC_initialization {
	
	if ( $VERDICT eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	} 
	else{
	S_teststep('StandardPrepNoFault', 'blue'); 
    GEN_StandardPrepNoFault ();
    
    S_teststep("Set ECU mode to $defaultpar_mode", 'blue');    
    if ($defaultpar_mode !~ m/normal/i){
    	ACEA_SetECUMode($defaultpar_mode);
    }
    else{
    	S_teststep("No action needed for normal mode!",'cyan');   
    }
  }  
	return 1;
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
if ( $VERDICT eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
else {    
	S_teststep("Step 1: Set the status of device = '$deviceName'",'AUTO_NBR');
	S_teststep_2nd_level("Step 1a:Set the configuration bit to ConfigurationBitStatus = '$defaultpar_ConfigurationBitStatus' using PD", 'AUTO_NBR');
	
	DEVICE_setDeviceConfiguration ($deviceName,$defaultpar_ConfigurationBitStatus);
	S_wait_ms(1500);
	
	($PresenceBit_observed_step1a,$Monitored_observed_step1a,$Configured_observed_step1a) = PD_get_device_config($deviceName );
    S_w2rep(" Presence Bit = $PresenceBit_observed_step1a, Monitored Bit = $Monitored_observed_step1a,  Configured Bit = $Configured_observed_step1a",'cyan');
     	
	S_teststep_2nd_level("Step 1b: Set the monitoring bit to MonitoringBitStatus = '$defaultpar_MonitoringBitStatus' using PD", 'AUTO_NBR');
	DEVICE_setDeviceConfiguration ($deviceName,$defaultpar_MonitoringBitStatus,'yes','no');
	S_wait_ms(1500);
	
	($PresenceBit_observed_step1b,$Monitored_observed_step1b,$Configured_observed_step1b) = PD_get_device_config($deviceName );  #return ( $real, $monitored, $configured );
    S_w2rep(" Presence Bit = $PresenceBit_observed_step1b, Monitored Bit = $Monitored_observed_step1b,  Configured Bit = $Configured_observed_step1b",'cyan');
	
	if($defaultpar_DevicePresenceStatus ne 'Present')
	{
		S_teststep_2nd_level("Step 1c: Disconnecting the external device according to DevicePresenceStatus = '$defaultpar_DevicePresenceStatus'", 'AUTO_NBR');
		DEVICE_setDeviceConfiguration ($deviceName,$defaultpar_DevicePresenceStatus,'yes','no');
		S_wait_ms(1500);
    } 

    S_teststep("Step 2: Reading (before reset) the configuration status of device = '$deviceName'", 'AUTO_NBR', 'ReadConfigurationStatus_Step2'); #measurement 1
    ($PresenceBit_observed_step2,$Monitored_observed_step2,$Configured_observed_step2) = PD_get_device_config($deviceName );
    S_w2rep("Presence Bit =$PresenceBit_observed_step2, Monitored Bit = $Monitored_observed_step2, Configured Bit =$Configured_observed_step2",'cyan');  
    
    S_teststep("Step 3: Read the fault recorder",'AUTO_NBR', 'ReadConfigurationStatus_Step3');  #measurement 2
    $flt_mem_struct_observed{'step3'} = PD_ReadFaultMemory (); 
    
    S_teststep("Step 4: Reset the ECU and read the fault recorder after initialization",'AUTO_NBR', 'ReadConfigurationStatus_Step4'); #measurement 3
    GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step4'} = PD_ReadFaultMemory (); 
    
    S_teststep("Step 5: Reading (After reset) the configuration status of the device = $deviceName",'AUTO_NBR', 'ReadConfigurationStatus_Step5');  #measurement 4
    ($PresenceBit_observed_step5,$Monitored_observed_step5,$Prog_observed_step5) = PD_get_device_config($deviceName );
    S_w2rep("Monitored Bit = $Monitored_observed_step5,Presence Bit = $PresenceBit_observed_step5,Configured Bit = $Prog_observed_step5",'cyan'); 
    
	S_teststep("Step 6: Configure, enable monitoring and connect device = $deviceName", 'cyan');
	DEVICE_setDeviceConfiguration ($deviceName,'set_Mon','yes','no');
	S_wait_ms(1500);
	DEVICE_setDeviceConfiguration ($deviceName,'set','yes','no');
	S_wait_ms(1500);	
	if($defaultpar_DevicePresenceStatus ne 'Present')
	{
			DEVICE_setDeviceConfiguration ($deviceName,'Present','yes','no');
			S_wait_ms(1500);
			PD_ClearFaultMemory();
	}
	
	S_teststep("Step 7: Reset the ECU and read the fault recorder after initialization",'AUTO_NBR', 'ReadConfigurationStatus_Step7'); #measurement 5
    GEN_Power_on_Reset();

	$flt_mem_struct_observed{'step7'} = PD_ReadFaultMemory (); 
    S_wait_ms(1500);
    
    S_teststep("Step 8: Read the configuration status of the device",'AUTO_NBR', 'ReadConfigurationStatus_Step8');  #measurement 6
    ($PresenceBit_observed_step8,$Monitored_observed_step8,$Prog_observed_step8) = PD_get_device_config($deviceName );
    S_w2rep("Monitored Bit = $Monitored_observed_step8,Presence Bit = $PresenceBit_observed_step8,Configured Bit = $Prog_observed_step8",'cyan'); 
   } 
  	return 1;
  	
}


#### EVALUATE TC #####
sub TC_evaluation {
    if ( $VERDICT eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
	else {
    S_teststep_expected("Step 2: Reported configuration bits status of Device -> $deviceName is :", 'ReadConfigurationStatus_Step2');  #evaluation 1
    if($defaultpar_DevicePresenceStatus ne 'Present')
	{
      EVAL_evaluate_value ( "Presence Bit of $deviceName: " , $PresenceBit_observed_step5, '==', $defaultpar_PresenceBitValue);
	}
    EVAL_evaluate_value ( "Monitoring Bit of $deviceName: " , $Monitored_observed_step2, '==', $defaultpar_MonitoringBitValue);
    EVAL_evaluate_value ( "Configuration Bit of $deviceName: " , $Configured_observed_step2, '==', $defaultpar_ConfigurationBitValue);
    
    S_teststep_expected("Step 3: expected faults: as per parameter FLTmand_BeforeReset", 'ReadConfigurationStatus_Step3');  #evaluation 2
    PD_ReadFaultMemory();
    
    if ( $defaultpar_CheckFLT_ConfigDataInconsistent eq 'yes' ) {    # Check for mandatory faults
		
		PD_evaluate_faults( $flt_mem_struct_observed{'step3'}, \@tcpar_FLTmand );
		
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step3'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step3'}, $fault_name, $fault_state , 'state' );
            }
            else {
                S_set_warning( "Missing Fault State for Fault '$fault_name'" );
            }
            
            my $dtc_expected = $tcpar_DTC_exp_href->{$fault_name};
            if( defined $dtc_expected ) {
                my $fault_index = PD_get_fault_index( $flt_mem_struct_observed{'step3'}, $fault_name );
                my $dtc_detected = $flt_mem_struct_observed{'step3'}->{'DTC'}->[$fault_index];
                EVAL_evaluate_string( 'DTC', $dtc_expected, $dtc_detected );
            }
            else {
                S_set_warning( "Missing DTC for Fault '$fault_name'" ); next;
            }           
        }
    }
	elsif($SwitchType =~ m/mech/i)
	{ 
	
	$tcpar_FLT_state_href = S_read_testcase_parameter( 'FLTmand_NormalStatus', 'byref' ); #FLTmand_BeforeReset or FLTmand_AfterReset fault will be the same for NotMonitored, Configured use cases.
        
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href;
       
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step3'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step3'}, $fault_name, $fault_state , 'state' );
            }
            else {
                S_set_error("Missing Fault State for Fault '$fault_name'", 110);
            }
		}
		S_w2rep("Unexpected and openline faults are not applicable for mech switch");
		}	
	
	else 
	{
		FM_checkDeviceFaults ($flt_mem_struct_observed{'step3'}, $deviceName, $defaultpar_FLTmand_BeforeReset);
	}
     
    
    S_teststep_expected("Step 4: expected faults: as per parameter FLTmand_AfterReset", 'ReadConfigurationStatus_Step4'); #evaluation 3
    PD_ReadFaultMemory();  
    
    if ( $defaultpar_CheckFLT_ConfigDataInconsistent eq 'yes' ) {    # Check for mandatory faults
		
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step4'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step4'}, $fault_name, $fault_state , 'state' );
            }
            else {
            	S_set_error("Missing Fault State for Fault '$fault_name'", 110);
            }
            
            my $dtc_expected = $tcpar_DTC_exp_href->{$fault_name};
            if( defined $dtc_expected ) {
                my $fault_index = PD_get_fault_index( $flt_mem_struct_observed{'step4'}, $fault_name );
                my $dtc_detected = $flt_mem_struct_observed{'step4'}->{'DTC'}->[$fault_index];
                EVAL_evaluate_string( 'DTC', $dtc_expected, $dtc_detected );
            }
            else {
            	S_set_error("Missing DTC for Fault '$fault_name'", 110);next;
            }           
        }
    }	
	elsif($SwitchType =~ m/mech/i)
	{ 
	$tcpar_FLT_state_href = S_read_testcase_parameter( 'FLTmand_NormalStatus', 'byref' ); #FLTmand_BeforeReset or FLTmand_AfterReset fault will be the same for NotMonitored, Configured use cases.
        
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href;
        
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step4'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step4'}, $fault_name, $fault_state , 'state' );
            }
            else {
                S_set_error("Missing Fault State for Fault '$fault_name'", 110);
            }
            }
			S_w2rep("Unexpected and openline faults are not applicable for mech switch");
	}
    else
    {
    	FM_checkDeviceFaults ($flt_mem_struct_observed{'step4'}, $deviceName, $defaultpar_FLTmand_AfterReset);
     }
    
    S_teststep_expected("Step 5: Reported configuration bits status of Device -> $deviceName is : ", 'ReadConfigurationStatus_Step5'); #evaluation 4
    PD_ReadFaultMemory();
	if($defaultpar_DevicePresenceStatus ne 'Present')
	{
      EVAL_evaluate_value ( "Presence Bit of $deviceName: " , $PresenceBit_observed_step5, '==', $defaultpar_PresenceBitValue);
	}
  
	
    EVAL_evaluate_value ( "Monitoring Bit of $deviceName: " , $Monitored_observed_step5, '==', $defaultpar_MonitoringBitValue);
    EVAL_evaluate_value ( "Configuration Bit of $deviceName: " , $Prog_observed_step5, '==', $defaultpar_ConfigurationBitValue); 
    
    S_teststep_expected("Step 7: expected faults: as per parameter FLTmand_NormalStatus", 'ReadConfigurationStatus_Step7');  #evaluation 5
    if ( $defaultpar_CheckFLT_ConfigDataInconsistent eq 'yes' ){    # Check for mandatory faults?
		
		$tcpar_FLT_state_href = S_read_testcase_parameter( 'FLTmand_NormalStatus', 'byref' ); #FLTmand_BeforeReset or FLTmand_AfterReset fault will be the same for NotMonitored, Configured use cases.
        
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href;
        
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step7'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step7'}, $fault_name, $fault_state , 'state' );
            }
            else {
                S_set_error("Missing Fault State for Fault '$fault_name'", 110);
            }
            
            my $dtc_expected = $tcpar_DTC_exp_href->{$fault_name};
            if( defined $dtc_expected ) {
                my $fault_index = PD_get_fault_index( $flt_mem_struct_observed{'step7'}, $fault_name );
                my $dtc_detected = $flt_mem_struct_observed{'step7'}->{'DTC'}->[$fault_index];
                EVAL_evaluate_string( 'DTC', $dtc_expected, $dtc_detected );
            }
            else {
                S_set_error("Missing DTC for Fault '$fault_name'", 110);next;
            }           
        }
    }
	elsif($SwitchType =~ m/mech/i)
	{ 
		$tcpar_FLT_state_href = S_read_testcase_parameter( 'FLTmand_NormalStatus', 'byref' ); #FLTmand_BeforeReset or FLTmand_AfterReset fault will be the same for NotMonitored, Configured use cases.
        
        @tcpar_FLTmand = keys %$tcpar_FLT_state_href;
        
        foreach my $fault_name ( keys %$tcpar_FLT_state_href ) {
            next unless PD_count_fault( $flt_mem_struct_observed{'step7'}, $fault_name );

            my $fault_state = $tcpar_FLT_state_href->{$fault_name};            
            if( defined $fault_state ) {
                PD_check_fault_status( $flt_mem_struct_observed{'step7'}, $fault_name, $fault_state , 'state' );
            }
            else {
                S_set_error("Missing Fault State for Fault '$fault_name'", 110);
            }
            }
	S_w2rep("Unexpected and openline faults are not applicable for mech switch");
	}
    else{
    	 FM_checkDeviceFaults ($flt_mem_struct_observed{'step7'}, $deviceName, $defaultpar_FLTmand_NormalStatus);
	}
      if($defaultpar_mode eq 'NormalMode'){
    	S_teststep_expected("Step 8: configuration status of $deviceName in normal mode", 'ReadConfigurationStatus_Step8'); #evaluation 6
    	if($defaultpar_DevicePresenceStatus ne 'Present')
		{
    	 EVAL_evaluate_value ( "Presence Bit of $deviceName: " , $PresenceBit_observed_step8, '==', 1);
		}
    }
    else{
    	
    	if ($defaultpar_device =~ m/WL/i){ # as per the requirement SRS_AOD_44 behavior of WL is different from other device.
    		S_teststep_expected("Step 8: configuration status of $deviceName in Idle mode.", 'ReadConfigurationStatus_Step8'); #evaluation 6
    		EVAL_evaluate_value ( "Presence Bit of $deviceName: " , $PresenceBit_observed_step8, '==', 1 );	
    		
    	}
    	else {
    		S_teststep_expected("Step 8: configuration status of $deviceName in Idle mode.", 'ReadConfigurationStatus_Step8'); #evaluation 6
    		EVAL_evaluate_value ( "Presence Bit of $deviceName: " , $PresenceBit_observed_step8, '==', 0 );
    	}
    	
    }    
    
    EVAL_evaluate_value ( "Monitoring Bit of $deviceName: " , $Monitored_observed_step8, '==', 1);
    EVAL_evaluate_value ( "Configuration Bit of $deviceName: " , $Prog_observed_step8, '==', 1);  
           
  	}
	return 1;
  	
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
	
	if ( $VERDICT eq VERDICT_NONE ) {
		S_set_verdict(VERDICT_NONE);
	}
else {
    S_w2rep("Bring the ECU back to normal mode", 'blue'); 
    
	if ($defaultpar_mode !~ m/normal/i)
	{
		ACEA_ResetECUMode($defaultpar_mode);
    }
    
    # Erase Fault memory
    PD_ClearFaultMemory();
    S_wait_ms(2000);
    
    # Read fault memory after clearing fault memory
    PD_ReadFaultMemory();
    S_wait_ms(2000);
	}
return 1;
}
1;


__END__
