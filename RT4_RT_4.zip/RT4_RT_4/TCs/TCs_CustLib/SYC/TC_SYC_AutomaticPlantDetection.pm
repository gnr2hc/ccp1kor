#### TEST CASE MODULE
package TC_SYC_AutomaticPlantDetection;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_AutomaticPlantDetection.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;

##################################

our $PURPOSE = "To check automatic plant mode detection, if PD is initalized or not initilized with in 500ms'";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_AutomaticPlantDetection

=head1 PURPOSE

To check automatic plant mode detection, if PD is initalized or not initilized with in 500ms'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Activate Plant mode 13 using <Plant_mode_var>

2. Reset ECU

3. Activate production diagnostics in <time>

4. Verify active plant modes 


I<B<Evaluation>>

4. <Plant_Modes> are active


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'time' => Time at which PD is initialized 
	LIST 'Plant_Modes' => Different plant modes
	SCALAR 'purpose' => Purpose of test case
	SCALAR 'Plant_mode_var' => Variable used to set plant mode


=head2 PARAMETER EXAMPLES

	purpose = 'To check automatic plant mode detection, if PD is initalized or not initilized with in 550ms'
	Plant_mode_var = 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8'
	time = 500 #ms
	Plant_Modes =(Plantmode7,Plantmode8,Plantmode9)

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Plant_mode_var;
my $tcpar_time;
my @tcpar_Plant_Modes;


################ global parameter declaration ###################
my $SearchHashRef;
my $matchedfaults_aref;
my $flt_mem_struct;
my $Return_Val;
my $Key;
my $a;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_Plant_mode_var =  GEN_Read_mandatory_testcase_parameter( 'Plant_mode_var' );
	$tcpar_time =  GEN_Read_mandatory_testcase_parameter( 'time' );
	@tcpar_Plant_Modes =  GEN_Read_mandatory_testcase_parameter( 'Plant_Modes' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	$Key = { "Key" => "AB 12", };
	GEN_printTestStep("Step 1. Activate Plant mode 13 using '$tcpar_Plant_mode_var'");
	PD_ECUlogin();
	PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x10]);
	GEN_Power_on_Reset();
	$a=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(1)"));
	GEN_printTestStep("Value of Plant mode variable is $a\n");
	GEN_printTestStep("Step 2. Reset ECU");
	GEN_Power_on_Reset(['NO_WAIT']);
	GEN_printTestStep("Step 3. Activate production diagnostics in '$tcpar_time'");
	if($tcpar_time<=500)
	{
		S_wait_ms(150); #Wait for PD initialization during ITM
		PD_ECUlogin();
	}
	else
	{	
		S_wait_ms($tcpar_time);
		PD_ECUlogin();
	}
	GEN_printTestStep("Step 4. Verify  active plant modes");

	S_wait_ms(4000);
	if($tcpar_time>500)
	{
		$flt_mem_struct= PD_ReadFaultMemory(1);
		$SearchHashRef->{'Condition'} = 'Configuration';
		$matchedfaults_aref = FM_fetchFaultName($SearchHashRef);
		$Return_Val=PD_evaluate_faults($flt_mem_struct,$matchedfaults_aref);
	}
	else
	{
		
		#PD_Prepare_electronic_firing();
		$Return_Val=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(1)"));
		# GDCOM_set_addressing_mode("PD");
		# $Return_Val=DIAG_PD_request_general("REQ_Enable_Safety_Path","PR_Enable_Safety_Path",$Key);
	}	

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 4. '@tcpar_Plant_Modes' are active");
	EVAL_evaluate_value("Evaluation for Step 4.",$a, '==', $Return_Val);

	return 1;
}

sub TC_finalization {
	PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[00]);
	GEN_Power_on_Reset();
	
	return 1;
}


1;
