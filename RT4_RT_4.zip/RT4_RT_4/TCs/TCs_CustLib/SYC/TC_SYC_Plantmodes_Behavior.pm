#### TEST CASE MODULE
package TC_SYC_Plantmodes_Behavior;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
use Switch;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_Plantmodes_Behavior.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To verify WL is ON when plant mode is active";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_Plantmodes_Behavior

=head1 PURPOSE

To verify WL is ON when plant mode is active

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Activate <Plant_mode> using <Plant_mode_var>

Test step 2 is not applicable for plant mode 4 ,17

2. Reset ECU

3. Read <Plant_mode_var> using production diagnostics

4. Read Warning lamp status using <WIM_var>

Test step 5-6 is applicable only for plant mode 4

5. Create any fault

6. Read Fault memory through CD or PD

7. Deactivate <Plant Mode> using <Plant_mode_var>

8. Reset ECU

9. Read <Plant_mode_var> using production diagnostics

10. Read Warning lamp status using <WIM_var>

Test step 11 is applicable only for plant mode 4

11. Read Fault memory through CD or PD


I<B<Evaluation>>

3.  <Plant_mode> is activated

4. <WIM_var> should have<WIM_var_onvalue> hence warning lamp is ON

. For plant mode 2 WI status will be 03

6. Fault is not present in Fault memory

9. <Plant Mode> is Deactivated

10. <WIM_var> should have<WIM_var_offvalue> hence warning lamp is OFF

11. Fault is present in Fault memory

 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES
	
		SCALAR 'Plant_mode' =>Different plant modes
		SCALAR 'Plant_mode_var' =>Variable to set plant mode
		SCALAR 'Purpose' => Purpose of test case
		SCALAR 'WIM_var' => Warning Lamp variable
		SCALAR 'WIM_var_onvalue' => Value of WI variable when WI is ON
		SCALAR 'WIM_var_offvalue' => Value of WI variable when WI is OFF

=head2 PARAMETER EXAMPLES

		Plant_mode = 'Plant mode 1'
		Plant_mode_var = 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8'
		Purpose = 'To verify WL is ON when plant mode is active'
		WIM_var = 'rb_wimi_SysWIStatus_aen(0)'
		WIM_var_onvalue = 01
		WIM_var_offvalue = 00
		
=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Plant_mode;
my $tcpar_Plant_mode_var;
my $tcpar_Purpose;
my $tcpar_WIM_var;
my $tcpar_WIM_var_onvalue;
my $tcpar_WIM_var_offvalue;

################ global parameter declaration ###################
my %Plant_Mode_Val;
my $WL_Status;
my %Fault_Memory_Ref;
my $WL_Status_Off;
my $Fault_Memory_Ref_Off;
my $Temp;

###############################################################

sub TC_set_parameters {

	$tcpar_Plant_mode=GEN_Read_mandatory_testcase_parameter( 'Plant_mode' );
	$tcpar_Plant_mode_var=GEN_Read_mandatory_testcase_parameter( 'Plant_mode_var' );
	$tcpar_Purpose=GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_WIM_var=GEN_Read_mandatory_testcase_parameter( 'WIM_var' );
	$tcpar_WIM_var_onvalue=GEN_Read_mandatory_testcase_parameter( 'WIM_var_onvalue' );
	$tcpar_WIM_var_offvalue=GEN_Read_mandatory_testcase_parameter( 'WIM_var_offvalue' );

	return 1;
}

sub TC_initialization {

	S_w2rep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_w2rep("Step 1. Activate '$tcpar_Plant_mode' using '$tcpar_Plant_mode_var'");
	PD_ECUlogin();
	switch($tcpar_Plant_mode)
	{
		case "Plantmode1"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x01]);
		}
		case "Plantmode2"	
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x02]);
		}
		case "Plantmode3"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x04]);
		}
		case "Plantmode4"
		{
			PD_FreezeFaultMemory();
		}
		case "Plantmode5"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x10]);
		}
		case "Plantmode6"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x20]);
		}
		case "Plantmode7"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x40]);
		}
		case "Plantmode8"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[0x80]);
		}
		case "Plantmode9"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x01]);
		}
		case "Plantmode10"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x02]);
		}
		case "Plantmode11"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x04]);
		}
		case "Plantmode12"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x08]);
		}
		case "Plantmode13"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x10]);
		}
		case "Plantmode14"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x20]);
		}
		case "Plantmode15"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x40]);
		}
		case "Plantmode16"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[0x80]);
		}
		case "Plantmode17"
		{
			PD_WriteMemoryByName("$tcpar_Plant_mode_var(2)",[0x01]);
		}	
	}	
	

	S_w2rep("Test step 2 is not applicable for plant mode 4 ,17");
	
	S_w2rep("Step 2. Reset ECU");
	if($tcpar_Plant_mode ne 'Plantmode4')
	{
		GEN_Power_on_Reset();
	}	

	S_w2rep("Step 3. Read '$tcpar_Plant_mode_var' using production diagnostics");
	
	$Plant_Mode_Val{0}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(0)"));
	$Plant_Mode_Val{1}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(1)"));
	$Plant_Mode_Val{2}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(2)"));
	
	

	S_w2rep("Step 4. Read Warning lamp status using '$tcpar_WIM_var'");
	$WL_Status=S_aref2hex(PD_ReadMemoryByName("$tcpar_WIM_var"));

	S_w2rep("Test step 5-6 is applicable only for plant mode 4");
	if($tcpar_Plant_mode eq 'Plantmode4')
	{
		
		S_w2rep("Step 5. Create any fault");
		
		FM_createFault("rb_sqm_SquibResistanceOpenAB1FD_flt");

		S_w2rep("Step 6. Read Fault memory through CD or PD");
		
		$Fault_Memory_Ref{'plant'}=PD_ReadFaultMemory(1);
	}	

	S_w2rep("Step 7. Deactivate '$tcpar_Plant_mode' using '$tcpar_Plant_mode_var'");
	
	PD_WriteMemoryByName("$tcpar_Plant_mode_var(0)",[00]);
	PD_WriteMemoryByName("$tcpar_Plant_mode_var(1)",[00]);
	PD_WriteMemoryByName("$tcpar_Plant_mode_var(2)",[00]);

	S_w2rep("Step 8. Reset ECU");
	
	GEN_Power_on_Reset();

	S_w2rep("Step 9. Read '$tcpar_Plant_mode_var' using production diagnostics");
	
	$Plant_Mode_Val{3}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(0)"));
	$Plant_Mode_Val{4}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(1)"));
	$Plant_Mode_Val{5}=S_aref2hex(PD_ReadMemoryByName("$tcpar_Plant_mode_var(2)"));
	
	
	PD_ClearFaultMemory();
	S_w2rep("Step 10. Read Warning lamp status using '$tcpar_WIM_var'");
	
	$WL_Status_Off=S_aref2hex(PD_ReadMemoryByName("$tcpar_WIM_var"));
	
	S_w2rep("Test step 11 is applicable only for plant mode 4");
	if($tcpar_Plant_mode eq 'Plantmode4')
	{
	S_w2rep("Step 11. Read Fault memory through CD or PD");
	$Fault_Memory_Ref{'noplant'}=PD_ReadFaultMemory(1);
	}
	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation for Step 3.  '$tcpar_Plant_mode' is activated-Done at Stimulation and Measurement");

	S_w2rep("Evaluation for Step 4. '$tcpar_WIM_var' should have'$tcpar_WIM_var_onvalue' hence warning lamp is ON");
	EVAL_evaluate_value("WI Status When Plant mode is Active",$WL_Status,'==',$tcpar_WIM_var_onvalue);

	
	if($tcpar_Plant_mode eq 'Plantmode4')
	{
		S_w2rep("Evaluation for Step 6. Fault is not present in Fault memory");	
		PD_evaluate_faults( $Fault_Memory_Ref{'plant'}, [] );
	}	

	S_w2rep("Evaluation for Step 9. '$tcpar_Plant_mode' is Deactivated-Done at Stimulation and Measurement");
	
	S_w2rep("Evaluation for Step 10. '$tcpar_WIM_var' should have'$tcpar_WIM_var_offvalue' hence warning lamp is OFF");
	EVAL_evaluate_value("WI Status When Plant mode is Active",$WL_Status_Off,'==',$tcpar_WIM_var_offvalue);
	if($tcpar_Plant_mode eq 'Plantmode4')
	{
		S_w2rep("Evaluation for Step 11. Fault is present in Fault memory");
	
		$Temp=PD_count_fault( $Fault_Memory_Ref{'noplant'}, "rb_sqm_SquibResistanceOpenAB1FD_flt" );
		if($Temp>0)
		{
			S_set_verdict("VERDICT_PASS");
		}
		else
		{
			S_set_verdict("VERDICT_FAIL");
		}	
	}
	return 1;
}

sub TC_finalization {
if($tcpar_Plant_mode eq 'Plantmode4')
	{
	FM_removeFault("rb_sqm_SquibResistanceOpenAB1FD_flt");
	}
	return 1;
}


1;
