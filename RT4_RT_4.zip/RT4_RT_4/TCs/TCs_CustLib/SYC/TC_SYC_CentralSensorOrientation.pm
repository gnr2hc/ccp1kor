#### TEST CASE MODULE
package TC_SYC_CentralSensorOrientation;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_CentralSensorOrientation.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration 
#TS version in DOORS: 3.41 
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_evaluation;
use LIFT_PD;

##################################

our $PURPOSE = "To verify central sensor orientation status";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_CentralSensorOrientation

=head1 PURPOSE

To verify central sensor orientation status

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read central sensor orientation using <Sensor_Orientation_Variable> for each <Central_Sensor>


I<B<Evaluation>>

1. <Sensor_Orientation_value> obtained for each sensor


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Sensor_Orientation_value' => Value of Sensor orientation
	SCALAR 'purpose' => Purpose of test case
	SCALAR 'Central_Sensor' => Name of central sensor
	SCALAR 'Sensor_Orientation_Variable' => Variable to read sensor orientation


=head2 PARAMETER EXAMPLES

	purpose = 'To verify central sensor orientation status'
	Central_Sensor ='SMA 660'
	Sensor_Orientation_Variable ='rb_sycc_SysConfCsemDataEe_st.sensorHeading_aen'
	Sensor_Orientation_value ='0A'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Central_Sensor;
my $tcpar_Sensor_Orientation_Variable;
my $tcpar_Sensor_Orientation_value;

################ global parameter declaration ###################
my @Sensor_Orientation_Array;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_optional_testcase_parameter( 'purpose' );
	$tcpar_Central_Sensor =  GEN_Read_mandatory_testcase_parameter( 'Central_Sensor' );
	$tcpar_Sensor_Orientation_Variable =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Orientation_Variable' );
	$tcpar_Sensor_Orientation_value =  GEN_Read_mandatory_testcase_parameter( 'Sensor_Orientation_value' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

use Switch;
	GEN_printTestStep("Step 1. Read central sensor orientation using '$tcpar_Sensor_Orientation_Variable' for each '$tcpar_Central_Sensor'");

	
	for(my $i=0; $i<6;$i++)
	{
		$Sensor_Orientation_Array[$i]=S_aref2hex(PD_ReadMemoryByName("$tcpar_Sensor_Orientation_Variable($i)"));
	}
	switch($tcpar_Central_Sensor)
	{
		case "SMA660high1" 
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[0]\n");
			EVAL_evaluate_value("Sensor Orientation for SMA660 high 1", $Sensor_Orientation_Array[0],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMA660high2"	
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[1]\n");
			EVAL_evaluate_value("Sensor Orientation for SMA660 high 2", $Sensor_Orientation_Array[1],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI700low"
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[2]\n");
			EVAL_evaluate_value("Sensor Orientation for SMI700 low", $Sensor_Orientation_Array[2],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI700high"
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[3]\n");
			EVAL_evaluate_value("Sensor Orientation for SMI700 high", $Sensor_Orientation_Array[3],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI710low"	
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[4]\n");
			EVAL_evaluate_value("Sensor Orientation for SMI710 low", $Sensor_Orientation_Array[4],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI710high"	
		{
			GEN_printComment("Sensor Orientation value obtained is $Sensor_Orientation_Array[5]\n");
			EVAL_evaluate_value("Sensor Orientation for SMI710 high", $Sensor_Orientation_Array[5],'==',$tcpar_Sensor_Orientation_value);
		}
	}		
	return 1;
}

sub TC_evaluation {



	GEN_printTestStep("Evaluation for Step 1. '$tcpar_Sensor_Orientation_value' obtained for sensor");
	switch($tcpar_Central_Sensor)
	{
		case "SMA660high1" 
		{
			EVAL_evaluate_value("Sensor Orientation for SMA660 high 1", $Sensor_Orientation_Array[0],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMA660high2"	
		{
			EVAL_evaluate_value("Sensor Orientation for SMA660 high 2", $Sensor_Orientation_Array[1],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI700low"
		{
			EVAL_evaluate_value("Sensor Orientation for SMI700 low", $Sensor_Orientation_Array[2],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI700high"
		{
			EVAL_evaluate_value("Sensor Orientation for SMI700 high", $Sensor_Orientation_Array[3],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI710low"	
		{
			EVAL_evaluate_value("Sensor Orientation for SMI710 low", $Sensor_Orientation_Array[4],'==',$tcpar_Sensor_Orientation_value);
		}
		case "SMI710high"	
		{
			EVAL_evaluate_value("Sensor Orientation for SMI710 high", $Sensor_Orientation_Array[5],'==',$tcpar_Sensor_Orientation_value);
		}
	}		

	return 1;
}

sub TC_finalization {

	GEN_Finalization();
	return 1;
}


1;
