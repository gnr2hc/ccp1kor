#### TEST CASE MODULE
package TC_SYC_ASICConfiguration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.1 $; 
our $HEADER = q$Header: SYC/TC_SYC_ASICConfiguration.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;  
################################## 

#### HERE SELECTION OF AUTOTEST MODULES ####

use LIFT_general; 
use LIFT_PD;
use LIFT_evaluation; 
use FuncLib_TNT_GEN;
use INCLUDES_Project;
do "INCLUDES_Project.pm";

##################################

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_ASICConfiguration  $Revision: 1.1 $


=head1 PURPOSE

to check requirements related to monitoring and presence bits for ASICs

=head1 TESTCASE DESCRIPTION 

[initialisation]
StandardPrepNoFault
Set the ECU mode
    
[stimulation & measurement]
1. Set the status of device:
a) Set the configuration bit to ConfigurationBitStatus using PD
b) Connect/disconnect the ASIC according to DevicePresenceStatus (Not possible for the master ASIC)

2. Reset the ECU and read the fault recorder after initialization

3. Read the configuration status of the device:
a) Configuration bit
b) Device Presence bit

4. Configure and connect device

5. Reset the ECU and read the fault recorder after initialization

6. Read the configuration status of device
a) Configuration bit
b) Device Presence bit

7. Read the ASIC IDs using the variables below:
a) ASIC_DeviceID_var
a) ASIC_RevisionID_var
a) ASIC_MaskID_var

8. Write an invalid ASIC Device ID value for the corresponding ASIC and read the fault recorder

9. Reset the ECU and read the fault recorder after initialization

10. Write the valid ASIC Device ID value for the corresponding ASIC and read the fault recorder after reset


[evaluation]
2. expected faults are FLTmand_AfterReset

3. Status of these bits are:
a) ConfigurationBitValue
b) PresenceBitValue

5. expected faults are FLTmand_NormalStatus

6. 
These bits corresponding to the device are set in normal/production mode
Presence bit is not set in Idle mode. Configuration bit is set

7. 
Non default values are stored for these IDs in normal/production mode
default value (0) is stored in Idle mode

8. expected faults are FLTmand_ASICidMismatch_BeforeReset

9. expected faults are FLTmand_ASICidMismatch_AfterReset

10. expected faults are FLTmand_validASICid_AfterReset

    
[finalisation]
 -

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

	SCALAR 'purpose'                   			   --> 'purpose of the test case'
	SCALAR 'mode'                   			   --> 'ECU mode to be set for this TC e.g. NormalMode'
	SCALAR 'device'                 	   		   --> 'device under test'
	SCALAR 'ConfigurationBitStatus' 			   --> 'e.g. set or clear'
	SCALAR 'DevicePresenceStatus' 				   --> 'e.g. present of notPresent'
	SCALAR 'ConfigurationBitValue' 			 	   --> '0 or 1'
	SCALAR 'PresenceBitValue' 			   		   --> '0 or 1'
	HASH 'FLTmand_AfterReset' 					   --> 'step 2 mandatory/expected faults with status'
	HASH 'FLTmand_NormalStatus' 				   --> 'step 5 mandatory/expected faults with status'
	HASH 'FLTmand_ASICidMismatch_BeforeReset' 	   --> 'step 8 mandatory/expected faults with status'
	HASH 'FLTmand_ASICidMismatch_AfterReset' 	   --> 'step 9 mandatory/expected faults with status'
	HASH 'FLTmand_validASICid_AfterReset' 	   	   --> 'step 10 mandatory/expected faults with status'
	SCALAR 'ASIC_DeviceID_var' 			   		   --> 'variable to read the ASIC device ID'
	SCALAR 'ASIC_RevisionID_var' 			   	   --> 'variable to read the ASIC revision ID'
	SCALAR 'ASIC_MaskID_var' 			   	   	   --> 'variable to read the ASIC mask ID'


=head2 PARAMETER EXAMPLES
	   

	[TC_SYC_ASICConfiguration.NormalMode_NotConfigured_PresentMasterSystemASIC]   #ID: SRTP_SYC_5134
	# From here on: applicable Lift Default Parameters
	purpose = 'to check the status of the ASIC configuration and presence bits, when the device is not configured and physically present'
	mode = 'NormalMode'
	device = MasterSystemASIC
	ConfigurationBitStatus = 'clear'
	DevicePresenceStatus = 'Present'
	ConfigurationBitValue = '0'
	PresenceBitValue = '1'
	FLTmand_AfterReset = %(' ') #no fault in normal mode
	FLTmand_NormalStatus = %(' ')
	FLTmand_ASICidMismatch_BeforeReset = %(' ')
	FLTmand_ASICidMismatch_AfterReset = %('rb_syc_AsicIdMismatch_flt' => '0bxxxxx111')
	FLTmand_validASICid_AfterReset = %('rb_syc_AsicIdMismatch_flt' => '0bxxxxx100') 
	ASIC_DeviceID_var = 'rb_syca_AsicDeviceId_au16' #array with index corresponding to each ASIC
	ASIC_RevisionID_var = 'rb_syca_AsicRevisionId_au16'
	ASIC_MaskID_var = 'rb_syca_AsicMaskId_au8'

=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION END<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my ($defaultpar_purpose,
	$defaultpar_mode,
	$defaultpar_device,
    $defaultpar_ConfigurationBitStatus,
    $defaultpar_DevicePresenceStatus,
    $defaultpar_ConfigurationBitValue,
    $defaultpar_PresenceBitValue,   
    $defaultpar_FLTmand_AfterReset,
    $defaultpar_FLTmand_NormalStatus,
    $defaultpar_FLTmand_ASICidMismatch_BeforeReset,
    $defaultpar_FLTmand_ASICidMismatch_AfterReset,
    $defaultpar_FLTmand_validASICid_AfterReset,
    $defaultpar_ASIC_DeviceID_var,
	$defaultpar_ASIC_RevisionID_var,
	$defaultpar_ASIC_MaskID_var);

############# Parameters from mapping files ################  
my ($deviceName);
	

################ global parameter declaration ################## 	
my (%flt_mem_struct_observed,
	$Real_observed_step3,
	$MonitoredID_observed_step3,
	$Prog_observed_step3,
	$Real_observed_step6,
	$MonitoredID_observed_step6,
	$Prog_observed_step6,
	$ASIC_DeviceID_observed_aref,
	$ASIC_RevisionID_observed_aref,
	$ASIC_MaskID_observed_aref);
our $PURPOSE;	

sub TC_set_parameters {
    
    $defaultpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
    $defaultpar_mode =  GEN_Read_mandatory_testcase_parameter( 'mode' );
    $defaultpar_device =  GEN_Read_mandatory_testcase_parameter( 'device' );  
    $defaultpar_ConfigurationBitStatus =  GEN_Read_mandatory_testcase_parameter( 'ConfigurationBitStatus' ); 
    $defaultpar_DevicePresenceStatus =  GEN_Read_mandatory_testcase_parameter( 'DevicePresenceStatus' );
    $defaultpar_ConfigurationBitValue =  GEN_Read_mandatory_testcase_parameter( 'ConfigurationBitValue' ); 
    $defaultpar_PresenceBitValue =  GEN_Read_mandatory_testcase_parameter( 'PresenceBitValue' );    
    $defaultpar_FLTmand_AfterReset = GEN_Read_mandatory_testcase_parameter( 'FLTmand_AfterReset' ,'byref' );
    $defaultpar_FLTmand_NormalStatus = GEN_Read_mandatory_testcase_parameter( 'FLTmand_NormalStatus' ,'byref' );
    $defaultpar_FLTmand_ASICidMismatch_BeforeReset = GEN_Read_mandatory_testcase_parameter( 'FLTmand_ASICidMismatch_BeforeReset' ,'byref' );
    $defaultpar_FLTmand_ASICidMismatch_AfterReset = GEN_Read_mandatory_testcase_parameter( 'FLTmand_ASICidMismatch_AfterReset' ,'byref' );
    $defaultpar_FLTmand_validASICid_AfterReset = GEN_Read_mandatory_testcase_parameter( 'FLTmand_validASICid_AfterReset' ,'byref' );
    $defaultpar_ASIC_DeviceID_var =  GEN_Read_mandatory_testcase_parameter( 'ASIC_DeviceID_var' ); 
    $defaultpar_ASIC_RevisionID_var =  GEN_Read_mandatory_testcase_parameter( 'ASIC_RevisionID_var' );
    $defaultpar_ASIC_MaskID_var =  GEN_Read_mandatory_testcase_parameter( 'ASIC_MaskID_var' ); 
    
    # check if used constants are defined and read them
    $deviceName = $main::ProjectDefaults->{'ASICS'}{$defaultpar_device}; 
           
    #to print the purpose
    $PURPOSE = "to check requirements related to monitoring and presence bits for ASIC: $defaultpar_device - $deviceName";   
    
    #If no device is assigned then skip this section. Verdict will be 'NONE'
    return 1 if (CheckValidDevice() == 0); #stops execution here
    
    return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {
	
	#If no device is assigned then skip this section. Verdict will be 'NONE'
    return 1 if (CheckValidDevice() == 0);
	
    S_w2rep('StandardPrepNoFault', 'blue'); 
    GEN_StandardPrepNoFault ();
     
    S_w2rep("Set ECU mode to $defaultpar_mode", 'blue');    
    if ($defaultpar_mode !~ m/normal/i){
    	return GEN_setECUMode ($defaultpar_mode) ;
    }
    else{
    	S_w2rep("No action needed for normal mode!");   
    	return 1;
    }
	
}


### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {
	
	#If no device is assigned then skip this section. Verdict will be 'NONE'
    return 1 if (CheckValidDevice() == 0);
      				        
    S_w2rep("Step 1: Set the status of device",'blue');
	S_w2rep("Step 1a: Set the configuration bit to ConfigurationBitStatus using PD", 'blue');
	my $confstatus = DEVICE_setDeviceConfiguration ($deviceName,$defaultpar_ConfigurationBitStatus);
	S_w2rep("Step 1b: Connect/disconnect the external device according to DevicePresenceStatus", 'blue');
	my $connectstatus = DEVICE_setDeviceConfiguration ($deviceName,$defaultpar_DevicePresenceStatus);
       
    unless($confstatus != 0 and $connectstatus != 0){
    	S_w2rep("Configuration is not done successfully", 'blue');
    	return 0;
    }
    
    S_w2rep("Step 2: Reset the ECU and read the fault recorder after initialization", 'blue');
    GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step2'} = FM_PD_readFaultMemory (); 
       
    S_w2rep("Step 3: Read the configuration status of device", 'blue');
    ($Real_observed_step3,$MonitoredID_observed_step3,$Prog_observed_step3) = PD_get_device_config($deviceName );
    
	S_w2rep("Step 4: Configure and connect device", 'blue');
	DEVICE_setDeviceConfiguration ($deviceName,'set');
	DEVICE_setDeviceConfiguration ($deviceName,'Present');
	
	S_w2rep("Step 5: Reset the ECU and read the fault recorder after initialization", 'blue');
    GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step5'} = FM_PD_readFaultMemory (); 
	
	S_w2rep("Step 6: Read the configuration status of device", 'blue');
    ($Real_observed_step6,$MonitoredID_observed_step6,$Prog_observed_step6) = PD_get_device_config($deviceName );
    
    S_w2rep("Step 7: Read the ASIC IDs", 'blue');
    $ASIC_DeviceID_observed_aref = PD_ReadMemoryByName($defaultpar_ASIC_DeviceID_var);
    $ASIC_RevisionID_observed_aref = PD_ReadMemoryByName($defaultpar_ASIC_RevisionID_var);
    $ASIC_MaskID_observed_aref = PD_ReadMemoryByName($defaultpar_ASIC_MaskID_var);
    
    S_w2rep("Step 8: Write an invalid ASIC Device ID value for the corresponding ASIC and read the fault recorder", 'blue');
    PD_WriteMemoryByName( $defaultpar_ASIC_DeviceID_var, [0xFF, 0xFF]); #16 bit ID
    PD_WriteMemoryByName( $defaultpar_ASIC_RevisionID_var, [0xFF, 0xFF]); #16 bit ID
    PD_WriteMemoryByName( $defaultpar_ASIC_MaskID_var, [0xFF]); #8 bit ID
    S_wait_ms(4000);
    $flt_mem_struct_observed{'step8'} = FM_PD_readFaultMemory (); 
	
	S_w2rep("Step 9: Reset the ECU and read the fault recorder after initialization", 'blue');
    GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step9'} = FM_PD_readFaultMemory (); 
    
    S_w2rep("Step 10: Write the valid ASIC Device ID value for the corresponding ASIC and read the fault recorder after reset", 'blue'); 
    PD_WriteMemoryByName( $defaultpar_ASIC_DeviceID_var, $ASIC_DeviceID_observed_aref);
    PD_WriteMemoryByName( $defaultpar_ASIC_RevisionID_var, $ASIC_RevisionID_observed_aref);
    PD_WriteMemoryByName( $defaultpar_ASIC_MaskID_var, $ASIC_MaskID_observed_aref);
    GEN_Power_on_Reset();
	$flt_mem_struct_observed{'step10'} = FM_PD_readFaultMemory (); 
    
  	return 1;
  	
}


#### EVALUATE TC #####
sub TC_evaluation {
	
	#If no device is assigned then skip this section. Verdict will be 'NONE'
    return 1 if (CheckValidDevice() == 0);
    
    S_w2rep("Evaluation for Step 2: expected faults: as per parameter FLTmand_AfterReset", 'blue');
    FM_checkDeviceFaults ($flt_mem_struct_observed{'step2'}, $deviceName, $defaultpar_FLTmand_AfterReset); 
    
    S_w2rep("Evaluation for Step 3: ASIC configuration status", 'blue');
    EVAL_evaluate_value ( "Presence Bit" , $Real_observed_step3, '==', $defaultpar_PresenceBitValue);
    EVAL_evaluate_value ( "Configuration Bit" , $Prog_observed_step3, '==', $defaultpar_ConfigurationBitValue); 
    
    S_w2rep("Evaluation for Step 5: expected faults: as per parameter FLTmand_NormalStatus", 'blue');
    FM_checkDeviceFaults ($flt_mem_struct_observed{'step5'}, $deviceName, $defaultpar_FLTmand_NormalStatus);    
    
    
    if($defaultpar_mode eq 'IdleMode'){
    	S_w2rep("Evaluation for Step 6: Presence bit is not set in Idle mode. Configuration bit is set", 'blue');
    	EVAL_evaluate_value ( "Presence Bit" , $Real_observed_step6, '==', 0); #not set in Idle mode
    	EVAL_evaluate_value ( "Configuration Bit" , $Prog_observed_step6, '==', 1); 
    }
    else{
    	S_w2rep("Evaluation for Step 6: These bits corresponding to the device are set in normal/production mode", 'blue');
    	EVAL_evaluate_value ( "Presence Bit" , $Real_observed_step6, '==', 1);
    	EVAL_evaluate_value ( "Configuration Bit" , $Prog_observed_step6, '==', 1); 
    }
    
    if($defaultpar_mode eq 'IdleMode'){
    	S_w2rep("Evaluation for Step 7: default value (0) is stored in Idle mode", 'blue');
    	EVAL_evaluate_value ( "ASIC DeviceID" , S_aref2hex($ASIC_DeviceID_observed_aref), '==', 0); 
    	EVAL_evaluate_value ( "ASIC RevisionID" , S_aref2hex($ASIC_RevisionID_observed_aref), '==', 0); 
    	EVAL_evaluate_value ( "ASIC MaskID" , S_aref2hex($ASIC_MaskID_observed_aref), '==', 0);
    }
    else{
    	S_w2rep("Evaluation for Step 7: Non default values are stored for these IDs in normal/production mode", 'blue');
    	EVAL_evaluate_value ( "ASIC DeviceID" , S_aref2hex($ASIC_DeviceID_observed_aref), '!=', 0);
    	EVAL_evaluate_value ( "ASIC RevisionID" , S_aref2hex($ASIC_RevisionID_observed_aref), '!=', 0);
    	EVAL_evaluate_value ( "ASIC MaskID" , S_aref2hex($ASIC_MaskID_observed_aref), '!=', 0);
    } 
    
    S_w2rep("Evaluation for Step 8: expected faults: as per parameter FLTmand_ASICidMismatch_BeforeReset", 'blue');
    FM_checkDeviceFaults ($flt_mem_struct_observed{'step8'}, $deviceName, $defaultpar_FLTmand_ASICidMismatch_BeforeReset);    
    
    S_w2rep("Evaluation for Step 9: expected faults: as per parameter FLTmand_ASICidMismatch_AfterReset", 'blue');
    FM_checkDeviceFaults ($flt_mem_struct_observed{'step9'}, $deviceName, $defaultpar_FLTmand_ASICidMismatch_AfterReset); 
    
    S_w2rep("Evaluation for Step 10: expected faults: as per parameter FLTmand_validASICid_AfterReset", 'blue');
    FM_checkDeviceFaults ($flt_mem_struct_observed{'step10'}, $deviceName, $defaultpar_FLTmand_validASICid_AfterReset);   
           
  	return 1;
  	
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {
	
	#If no device is assigned then skip this section. Verdict will be 'NONE'
    return 1 if (CheckValidDevice() == 0);

    S_w2rep("Bring the ECU back to normal mode", 'blue'); 
    GEN_setECUMode ("remove".$defaultpar_mode) if ($defaultpar_mode !~ m/normal/i);
    
    GEN_Finalization();
    
	return 1;
	
}

sub CheckValidDevice{
	unless (defined $deviceName and $deviceName ne '' and $deviceName ne 'NONE'){
		S_w2rep("Valid device is not configured for this line. Stop further execution\n", 'orange');
	    $PURPOSE = "TESTCASE NOT EXECUTED: No device is configured for this line: $defaultpar_device";
	    return 0;
	}
	return 1;
}

1;


__END__