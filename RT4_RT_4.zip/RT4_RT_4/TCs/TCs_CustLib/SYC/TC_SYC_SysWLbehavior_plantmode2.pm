#### TEST CASE MODULE
package TC_SYC_SysWLbehavior_plantmode2;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SYC/TC_SYC_SysWLbehavior_plantmode2.pm 1.1 2020/03/04 10:42:13ICT Anurag G N (RBEI/ESA-PP3) (UAG6KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_SYC_SystemConfiguration
#TS version in DOORS: 3.41
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To check all analog output devices are deconfigured in plant mode 2 except SysWL";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SYC_SysWLbehavior_plantmode2

=head1 PURPOSE

To check all analog output devices are deconfigured in plant mode 2 except SysWL

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Enter into <plant_mode>

2. Read Fault recorder using PD or CD

3. Read Warning lamp status

4. Exit <plant_mode>



I<B<Evaluation>>

1. <plant_mode> is activated

2. Unexpected faults for all peripheral devices except SysWL is qualified

3.Warning lamp should be in <status>

4. <plant_mode> is deactivated



I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Purpose' => Purpose of the test case
	SCALAR 'plant_mode' => Plant mode
	SCALAR 'status' => status of warning lamp.


=head2 PARAMETER EXAMPLES

	Purpose = 'To check all analog output devices are deconfigured in plant mode 2 except SysWL'
	plant_mode= 'Plant mode 2'
	status ='ON'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_plant_mode;
my $tcpar_status;

################ global parameter declaration ###################
my $Fault_Status_Plant;
my $Fault_Status_Normal;
my $WL_Status;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_plant_mode =  GEN_Read_mandatory_testcase_parameter( 'plant_mode' );
	$tcpar_status =  GEN_Read_mandatory_testcase_parameter( 'status' );

	return 1;
}

sub TC_initialization {

	GEN_printTestStep("StandardPrepNoFault");
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1. Enter into '$tcpar_plant_mode'");
	PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)",[0x02]);
	GEN_Power_on_Reset();

	GEN_printTestStep("Step 2. Read Fault recorder using PD or CD");
	$Fault_Status_Plant=PD_ReadFaultMemory(1);

	GEN_printTestStep("Step 3. Read Warning lamp status");
	$WL_Status=ACEA_ReadWLStatus();

	GEN_printTestStep("Step 4. Exit '$tcpar_plant_mode'");
	PD_WriteMemoryByName("rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)",[00]);
	GEN_Power_on_Reset();


	return 1;
}

sub TC_evaluation {

	my $Temp;
	GEN_printTestStep("Evaluation for Step 1. '$tcpar_plant_mode' is activated-Evaluation done at Stimulation and measurement");

	GEN_printTestStep("Evaluation for Step 2. Unexpected faults for all peripheral devices except SysWL is qualified");
	PD_count_fault($Fault_Status_Plant,"rb_wim_UnexpectedSysWIFault_flt");
	if($Temp<1)
	{
		S_set_verdict('VERDICT_PASS');
	}	

	GEN_printTestStep("Evaluation for Step 3.Warning lamp should be in '$tcpar_status'");
	EVAL_evaluate_value("Warning Lamp status",$WL_Status,'==',01);

	GEN_printTestStep("Evaluation for Step 4. '$tcpar_plant_mode' is deactivated-Evaluation done at Stimulation and measurement");


	return 1;
}

sub TC_finalization {

	return 1;
}


1;
