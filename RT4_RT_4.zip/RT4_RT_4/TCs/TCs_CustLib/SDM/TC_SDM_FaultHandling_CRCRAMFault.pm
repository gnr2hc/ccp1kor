#### TEST CASE MODULE
package TC_SDM_FaultHandling_CRCRAMFault;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SDM/TC_SDM_FaultHandling_CRCRAMFault.pm 1.1 2020/02/24 13:06:46ICT Kharabe Vishal (RBEI/ESA-PP3) (KHV3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_PD;
use LIFT_CD;
require LIFT_PD2ProdDiag; import LIFT_PD2ProdDiag;
use LIFT_evaluation;
use LIFT_PD2ProdDiag;
use LIFT_ProdDiag_AB12;
use LIFT_ProdDiag;
use Data::Dumper;
use LIFT_MLC;
use LIFT_CANoe;
use LIFT_POWER;
use GENERIC_DCOM;
use LIFT_FaultMemory;
##################################

our $PURPOSE = "Test case for SDM Fault Handling For CRCRAM Fault";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDM_FaultHandling_CRCRAMFault

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Perform this test only if the data section <SDM_DataSection> is required to be loaded by SDM.

i.e. the value of <SDM_SectionSelector_var> & (<SDM_SectionSelector_var> >> <SDM_SectionSelector_bitposition>)  & 1 = 1 .


I<B<Stimulation and Measurement>>

1. Corrupt a location in target data set in memory locaton <Memory_Location>  for the data section <SDM_DataSection>. 

Do not calculate CRC Checksum for data section <SDM_DataSection>

2. Read Fault Memory

3. Read <SDM_SectionStatus_var>.

Note: Idle mode should be blocked before creating CRC RAM fault. Else Controller will reset automatically and fault condition will be eliminated. Hence Idle mode condition can't be verified.


I<B<Evaluation>>

1. 

2. If <Memory_Location> = RAM,Fault CRCRAMFault  shall be Qualified .

If <Memory_Location> = ROM,no Fault  shall be Qualified .

3. 

If <Memory_Location> = RAM,<SDM_SectionStatus_var> = <SDM_SectionStatus_valFault>

If <Memory_Location> = ROM,<SDM_SectionStatus_var> = <SDM_SectionStatus_valNoFault>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Memory_Location' => 
	SCALAR 'SDM_SectionSelector_bitposition' => 
	SCALAR 'SDM_TargetDataSet_address' => 
	SCALAR 'Purpose' => 
	SCALAR 'SDM_DataSection' => 
	SCALAR 'SDM_SectionSelector_var' => 
	SCALAR 'SDM_SectionStatus_var' => 
	SCALAR 'SDM_SectionStatus_valFault' => 
	SCALAR 'SDM_SectionStatus_valNoFault' => 


=head2 PARAMETER EXAMPLES

	Purpose = 'To test SDM fault handling - CRC RAM fault'
	SDM_DataSection = '<Test Heading 1>'
	SDM_SectionSelector_var = 'rb_sdm_DataSectionSelector_st.rb_sdm_DataSectionSelector_au8'
	SDM_SectionStatus_var = 'rb_sdm_SectionStatus_aen'
	SDM_SectionStatus_valFault = '6'
	SDM_SectionStatus_valNoFault = '3'
	Memory_Location = RAM
	
	SDM_SectionSelector_bitposition = 'rb_sdm_DataSectionSelector_st.rb_sdm_DataSectionSelector_au8'
	
	#Block Address and Block Size to Read Target RAM data set
	SDM_TargetDataSet_address = '' #rb_sdm_DataSectionSelector_st

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Purpose;
my $tcpar_SDM_DataSection;
my $tcpar_SDM_SectionSelector_var;
my $tcpar_SDM_SectionStatus_var;
my $tcpar_SDM_SectionStatus_valFault;
my $tcpar_SDM_SectionStatus_valNoFault;
my $tcpar_Memory_Location;
my $tcpar_SDM_SectionSelector_bitposition;
my $tcpar_SDM_TargetDataSet_address;
my $tcpar_CRCRAM_Fault;
my $tcpar_FaultStatus_Quali;
my $SectionData_aref;
my $flt_mem_struct_cd_B;
my $SectionStatusVar_aref;
my @SectionData_aref;
my $SectionData_MemBit;
my $ECUMode;
my $faultMemObject;
my $SectionSelector_Val;
my $tcpar_SDM_SectionSelector_bitposition;
my $SDMSection_LoadingValid;
my $random_number;
################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Purpose =  GEN_Read_mandatory_testcase_parameter( 'Purpose' );
	$tcpar_SDM_DataSection =  GEN_Read_mandatory_testcase_parameter( 'SDM_DataSection' );
	$tcpar_SDM_SectionSelector_var =  GEN_Read_mandatory_testcase_parameter( 'SDM_SectionSelector_var' );
	$tcpar_SDM_SectionStatus_var =  GEN_Read_mandatory_testcase_parameter( 'SDM_SectionStatus_var' );
	$tcpar_SDM_SectionStatus_valFault =  GEN_Read_mandatory_testcase_parameter( 'SDM_SectionStatus_valFault' );
	$tcpar_SDM_SectionStatus_valNoFault =  GEN_Read_mandatory_testcase_parameter( 'SDM_SectionStatus_valNoFault' );
	$tcpar_Memory_Location =  GEN_Read_mandatory_testcase_parameter( 'Memory_Location' );
	$tcpar_SDM_SectionSelector_bitposition =  GEN_Read_mandatory_testcase_parameter( 'SDM_SectionSelector_bitposition' );
	$tcpar_SDM_TargetDataSet_address =  GEN_Read_mandatory_testcase_parameter( 'SDM_TargetDataSet_address' );
	$tcpar_CRCRAM_Fault                   = GEN_Read_mandatory_testcase_parameter('CRCRAM_Fault');
    
	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();
	
	S_teststep("Note: Idle mode should be blocked before creating CRC RAM fault. Else Controller will reset automatically and fault condition will be eliminated. Hence Idle mode condition can't be verified.", 'AUTO_NBR');
	
	#Write 5A5A to rb_bswm_IdleModeData_st.PermIdleMode_u16 to set ECU in IDLE mode
	PRD_Write_Memory('rb_bswm_IdleModeData_dfst.PermIdleMode_u16',[0x5A, 0x5A]);
	PRD_Write_Memory('rb_bswm_IdleModeData_dfst.BlockIdleMode_u16',[0x0C, 0xB1]);
	
	S_wait_ms(15000);
	    # hard reset with 10sec. waiting
         
    PRD_ECU_Reset({'resetType' => 'HARD'});
	S_wait_ms(10000);
	
	#Check if ECU Mode is set to Idle 
	my $ECU_mode = 'not set';
	my $IDLEModeMemory = PRD_Read_Memory( 'rb_bswm_IdleModeData_st.PermIdleMode_u16', {memoryContentsAsInteger => 1});
	
	
	S_teststep_2nd_level( "Read PRD_Get_ECU_Properties", 'AUTO_NBR' );
	my $ecuProperties_after_Flash_href = PRD_Get_ECU_Properties();
	foreach my $EcuProp_key ( keys %{$ecuProperties_after_Flash_href} ) {
		foreach my $EcuSubProp_key (
			keys %{ $ecuProperties_after_Flash_href->{$EcuProp_key} } )
		{
			my $EcuSubProp_value =
			    $ecuProperties_after_Flash_href->{$EcuProp_key}{$EcuSubProp_key};
				if ( $EcuSubProp_key eq 'ECU_mode' ) {
				$ECU_mode = $EcuSubProp_value;
			}
		}
	}

 	
	S_teststep_expected("ECU mode shall be IDLE DRIVING");
	S_teststep_detected("ECU mode : $ECU_mode");

	S_teststep("Perform this test only if the data section '$tcpar_SDM_DataSection' is required to be loaded by SDM.", 'AUTO_NBR');
	S_teststep_2nd_level("i.e. the value of '$tcpar_SDM_SectionSelector_var' & ('$tcpar_SDM_SectionSelector_var' >> '$tcpar_SDM_SectionSelector_bitposition')  & 1 = 1 .", 'AUTO_NBR');
	$SectionSelector_Val = PRD_Read_Memory( $tcpar_SDM_SectionSelector_var, {memoryContentsAsInteger => 1});
	
	return 1;
}

sub TC_stimulation_and_measurement {
	
	#DataSection loading is allowed by SDM is checked
	if (($SectionSelector_Val & ($SectionSelector_Val >> $tcpar_SDM_SectionSelector_bitposition)) & 1 )
	{S_w2rep ("Precondtion is satisfied");
		$SDMSection_LoadingValid = 'True';
		 }
    else
    { S_w2rep ("Precondtion is not satisfied and hence Test will not be executed");
    	 S_w2rep ("i.e. the value of '$tcpar_SDM_SectionSelector_var' & ('$tcpar_SDM_SectionSelector_var' >> '$tcpar_SDM_SectionSelector_bitposition')  & 1 is not equal to 1");
    	 S_w2rep ("Value of '$tcpar_SDM_SectionSelector_var' = '$SectionSelector_Val'");
    	 S_w2rep ("Value of Section Selector Bit position = '$tcpar_SDM_SectionSelector_bitposition'");
    	$SDMSection_LoadingValid = 'False';
    }
    
    if($SDMSection_LoadingValid eq 'True')                 #Block is executed only if The precondition is Satisfied
    {
	S_teststep("Corrupt a location in target data set in memory locaton '$tcpar_Memory_Location'  for the data section '$tcpar_SDM_DataSection'. ", 'AUTO_NBR');
			
	S_teststep_2nd_level ("Read memory from target data set before and after Modfying data", 'AUTO_NBR' );
	$SectionData_aref = PRD_Read_Memory( $tcpar_SDM_TargetDataSet_address, {memoryContentsAsInteger => 1});
	S_w2rep("Data in Target Data set address before Modification: '$SectionData_aref'");
	
	#Generating a Random Number and writing it to target data set address
	do
	{
    $random_number = int(rand(10));
	}while($random_number == $SectionData_aref);
	
	if ($random_number < 10) { $random_number = "0$random_number"; }
	my $SectionDataByteToWrite = $random_number;
		
	S_w2rep("Byte to write: '$SectionDataByteToWrite' to Memory : '$tcpar_SDM_TargetDataSet_address'");

	PRD_Write_Memory($tcpar_SDM_TargetDataSet_address,$SectionDataByteToWrite);
	S_wait_ms(10000);
	
	$SectionData_aref = PRD_Read_Memory( $tcpar_SDM_TargetDataSet_address, {memoryContentsAsInteger => 1});
	S_w2rep("Data in Target Data set address after Modification: '$SectionData_aref'");
	
	S_teststep("Do not calculate CRC Checksum for data section '$tcpar_SDM_DataSection'", 'AUTO_NBR');
	
	S_wait_ms(5000);
	
	# Read Fault and Data section Status Memory after writing data
	#S_teststep("Read Fault Memory", 'AUTO_NBR', 'read_fault_memory');		
	#$flt_mem_struct_cd_B  = PRD_Read_Fault_Memory('PRIMARY');
		        
	$faultMemObject = LIFT_FaultMemory -> read_fault_memory('Primary'); #measurement 1Read Primary Fault Memory	
	S_teststep("Read Data Section Status Memory : '$tcpar_SDM_SectionStatus_var'.", 'AUTO_NBR');
	$SectionStatusVar_aref  = PRD_Read_Memory( $tcpar_SDM_SectionStatus_var, {memoryContentsAsInteger => 1});
    } #Block is executed only if The precondition is Satisfied
    
	return 1;
}

sub TC_evaluation {
		
		 if($SDMSection_LoadingValid eq 'True')                 #Block is executed only if The precondition is Satisfied
    {
		
		 if ($tcpar_Memory_Location eq 'RAM'){
			S_teststep("Check if CRCRAM fault is qualified", 'AUTO_NBR','read_Primary_after_quali');
	    
	    	my $expectedFaults = {
	        $tcpar_CRCRAM_Fault => {
	                'DecodedStatus' => { 'TestFailed' => 1,}, #Check if CRCRAM fault is in qualified state
	            					}
	    						};
	    	my $verdict = $faultMemObject -> evaluate_specific_faults($expectedFaults,'read_Primary_after_quali'); # eval keyword
		     }
		
	 		 
		 else{
			 my $entry_obj_aref = $faultMemObject -> get_faults_with_properties(
             {'DecodedStatus' => {'TestFailed' => 1}});
    		my $numberOfQualifiedFaults = @{$entry_obj_aref};
    		my @faultNamesInQualifedState = ();
    		foreach my $fault_entry_obj(@{$entry_obj_aref})
    		{
        		push(   @faultNamesInQualifedState,
                $fault_entry_obj -> FaultName);
   			}
    		S_w2rep("Following faults are qualified: @faultNamesInQualifedState"); #Print all faults is in qualified state
    
			my $verdict = $faultMemObject -> evaluate_faults({});
			
		}
	 

	 if ($tcpar_Memory_Location eq 'RAM'){
	S_teststep_expected("If '$tcpar_Memory_Location' = RAM,'$tcpar_SDM_SectionStatus_var' = '$tcpar_SDM_SectionStatus_valFault'");
	S_teststep_detected("Detected Value : '$SectionStatusVar_aref'");
	EVAL_evaluate_value ( $tcpar_SDM_TargetDataSet_address , $SectionStatusVar_aref, '==', $tcpar_SDM_SectionStatus_valFault);
	}
	else{
	S_teststep_expected("If '$tcpar_Memory_Location' = ROM,'$tcpar_SDM_SectionStatus_var' = '$tcpar_SDM_SectionStatus_valNoFault'");
	S_teststep_detected("Detected Value : $SectionStatusVar_aref'");
	EVAL_evaluate_value ( $tcpar_SDM_TargetDataSet_address , $SectionStatusVar_aref, '==', $tcpar_SDM_SectionStatus_valNoFault);
	}
	
    }
    
    else
    {S_w2rep("Data Section Loading Check PreConditon is not satisfied");}
	return 1;
}

sub TC_finalization {
    S_w2rep("TC FINALIZATION\n");
    PD_ClearFaultMemory();
	S_wait_ms(2000);
	#Write FFFF to rb_bswm_IdleModeData_st.PermIdleMode_u16 to set ECU in Normal mode
	PRD_Write_Memory('rb_bswm_IdleModeData_dfst.PermIdleMode_u16',[0xFF,0xFF]);
	PRD_Write_Memory('rb_bswm_IdleModeData_dfst.BlockIdleMode_u16',[0xFF, 0xFF]);
	
	S_wait_ms(5000);
	         
    PRD_ECU_Reset({'resetType' => 'HARD'});
	S_wait_ms(10000);
	
	#Check if ECU Mode is set to back to Normal driving 
	my $ECU_mode = 'not set';
	S_teststep( "Read PRD_Get_ECU_Properties", 'AUTO_NBR' );
	my $ecuProperties_after_Flash_href = PRD_Get_ECU_Properties();
	foreach my $EcuProp_key ( keys %{$ecuProperties_after_Flash_href} ) {
		foreach my $EcuSubProp_key (
			keys %{ $ecuProperties_after_Flash_href->{$EcuProp_key} } )
		{
			my $EcuSubProp_value =
			  $ecuProperties_after_Flash_href->{$EcuProp_key}{$EcuSubProp_key};
			#S_w2rep( " $EcuProp_key -> $EcuSubProp_key = $EcuSubProp_value \n",'blue' );
			if ( $EcuSubProp_key eq 'ECU_mode' ) {
				$ECU_mode = $EcuSubProp_value;
			}
		}
	}

	S_teststep_expected("ECU mode shall be NORMAL DRIVING before reset");
	S_teststep_detected("ECU mode : $ECU_mode");
	return 1;
}


1;
