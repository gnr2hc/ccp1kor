#### TEST CASE MODULE
package TC_SDM_CloseRAM;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: SDM/TC_SDM_CloseRAM.pm 1.1 2020/02/24 13:06:45ICT Kharabe Vishal (RBEI/ESA-PP3) (KHV3KOR) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_FaultMemory;
use LIFT_evaluation;
use LIFT_PD;
require LIFT_PD2ProdDiag;
import LIFT_PD2ProdDiag;
use LIFT_ProdDiag;
use LIFT_equipment;
##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_SDM_CloseRAM

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Change <Condition> using on fly configuration

2.  Verify that CRC is calculated and <Fault> is not created

3. Verify section status

4. Verify Data written to NV


I<B<Evaluation>>

1.<Condition> created

2. CRC is calculated and <Fault> not qualified

3. Section status is <Value>

4.If writing NV is permitted then it should write to NV else not


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Condition' => 
	SCALAR 'Fault' => 
	SCALAR 'Value' => 


=head2 PARAMETER EXAMPLES

	purpose =''To test Close RAM functionalites'
	Condition='Squib configuration'
	Fault='CRCRAM'
	Value= 03

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Condition;
my $tcpar_Fault;
my $tcpar_Value;
my $SectionStatusVar_aref;
my $tcpar_SDM_SectionStatus_var='rb_sdm_SectionStatus_aen(24)';
my $tcpar_CRCRAM_Fault = 'rb_sdm_CRCRAM_flt';
my $faultMemObject;
my $ConditionCreated;
my $ConditionCreatedResult;
my $CRCAfterDeConfig;
my $CRC_MemLocation_Address = 'rb_sycf_SysConfSquib_dfst.crc_u32';
my $CRCBeforeDeConfig;
my $NV_Deconfig_DetectedData;
my @faultNamesInQualifedState;
my $DeviceConfig_NVData = 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8(0)';
my $NV_Device_DeconfigBit = 0;
my $ConfigChange_Device = 'AB1FD';
my $DeviceConfigBit = 1;
my $DeviceConfig_NVUpdated;
################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Condition =  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_Value =  GEN_Read_mandatory_testcase_parameter( 'Value' );

	return 1;
}

sub TC_initialization {
	S_w2rep("Setting the Device Condition to Configure and Monitored Before starting the Test");
	PRD_Set_Device_Configuration({$ConfigChange_Device => ['set_Configure', 'set_Monitor'] });
	
	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	#GEN_StandardPrepNoFault();
			            
    S_wait_ms(2000);     
    PRD_ECU_Reset({'resetType' => 'HARD'});
	S_wait_ms(10000);
	return 1;
}

sub TC_stimulation_and_measurement {
	S_w2rep("Reading the CRC memory location for Squib Configuration before Deconfiguring");
	$CRCBeforeDeConfig = PRD_Read_Memory($CRC_MemLocation_Address,{memoryContentsAsInteger => 1});   #Read CRC before Deconfig

	S_teststep("Change '$tcpar_Condition' using on fly configuration", 'AUTO_NBR', 'change_condition_using');			#measurement 1
	$ConditionCreated = PRD_Set_Device_Configuration({$ConfigChange_Device => ['clear_Configure','clear_Monitor'] });
			 
	S_teststep("Verify that CRC is calculated and '$tcpar_Fault' is not created", 'AUTO_NBR', 'verify_that_crc');		#measurement 2
	
	S_w2rep("Reading the CRC memory location for Squib Configuration after Deconfiguring");
	$CRCAfterDeConfig = PRD_Read_Memory($CRC_MemLocation_Address,{memoryContentsAsInteger => 1});   #Read CRC after doconfig
	
	S_teststep("Verify that '$tcpar_Fault' is not created", 'AUTO_NBR', 'crcram_fault');
	my $entry_obj_aref;
	$faultMemObject = LIFT_FaultMemory -> read_fault_memory('Primary'); #measurement 3 Read Primary Fault Memory
	

	  $entry_obj_aref = $faultMemObject -> get_faults_with_properties( {'FaultName' => $tcpar_CRCRAM_Fault,
                              'DecodedStatus' => {'TestFailed' => 1 }
	   });
	   
	     
    my $numberOfQualifiedFaults = @{$entry_obj_aref};
    @faultNamesInQualifedState = ();
    foreach my $fault_entry_obj(@{$entry_obj_aref})
    {
        push(   @faultNamesInQualifedState,
                $fault_entry_obj -> FaultName);
    }
   
                              	


    S_teststep("Verify section status", 'AUTO_NBR', 'verify_section_status');			#measurement 4
	$SectionStatusVar_aref  = PRD_Read_Memory( $tcpar_SDM_SectionStatus_var, {memoryContentsAsInteger => 1});
	
	
	S_teststep("Verify Data written to NV", 'AUTO_NBR', 'verify_data_written');			#measurement 5
	$NV_Deconfig_DetectedData = PRD_Read_Memory($DeviceConfig_NVData,{memoryContentsAsInteger => 1}); 
		
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("'$tcpar_Condition' should be created successfully", 'change_condition_using');			#evaluation 1
	
	S_teststep_detected("'$tcpar_Condition' Condition creation status: '$ConditionCreated' ", 'change_condition_using');
	if ($ConditionCreated == 1)
	{$ConditionCreatedResult  = 'Success'}
	else
	{$ConditionCreatedResult  = 'Fail'}
	
	EVAL_evaluate_string ( "Result for Condition created ", 'Success', $ConditionCreatedResult);

	S_teststep_expected("Verify CRC is calculated ", 'verify_that_crc');			#evaluation 2
	S_teststep_detected("'$CRCAfterDeConfig'", 'verify_that_crc');
	EVAL_evaluate_value ( "CRC after Device Config Change" , $CRCAfterDeConfig,'!=',$CRCBeforeDeConfig);
	
	#CRC Fault not qualified
	my $CRCRAMFault_Detected;
	if (@faultNamesInQualifedState eq $tcpar_CRCRAM_Fault)
	{	S_w2rep("CRCRAM fault is qualified");
		$CRCRAMFault_Detected = 'True';
	}
	else
	{	S_w2rep("CRCRAM fault is not qualified");
		$CRCRAMFault_Detected = 'False';
	}
	S_teststep_expected("CRCRAM fault should not be qualified ", 'crcram_fault');			#evaluation 3
	S_teststep_detected("CRCRAMFault_Detected:'$CRCRAMFault_Detected' ", 'crcram_fault');
	EVAL_evaluate_string ( "CRCRAM fault qualification status",'False',$CRCRAMFault_Detected);
	
	S_teststep_expected("Section status is '$tcpar_Value'", 'verify_section_status');			#evaluation 4
	S_teststep_detected("$SectionStatusVar_aref", 'verify_section_status');
	EVAL_evaluate_value ( "Section Status after device Config Change", $SectionStatusVar_aref, '==', $tcpar_Value);

	S_teststep_expected("If writing NV is permitted then it should write to NV else not", 'verify_data_written');			#evaluation 5
	S_teststep_detected("Checking deconfigured bit for '$tcpar_Condition' in NV", 'verify_data_written');
	if($NV_Deconfig_DetectedData & (1>>$DeviceConfigBit))
	{S_w2rep ("'$ConfigChange_Device' is Still Configured"); 
		$DeviceConfig_NVUpdated = 'False';
	}
    else
    { S_w2rep ("'$ConfigChange_Device' is successfully Deconfigured");
    	$DeviceConfig_NVUpdated = 'True';
    	 }
	EVAL_evaluate_string ("NV data written in '$DeviceConfig_NVData' after device Config Change" , 'True',$DeviceConfig_NVUpdated);

	return 1;
}

sub TC_finalization {
	S_w2rep("Setting the Device Condition to Configure and Monitored before shutting down the test");
	PRD_Set_Device_Configuration({$ConfigChange_Device => ['set_Configure', 'set_Monitor'] });
	return 1;
}


1;
