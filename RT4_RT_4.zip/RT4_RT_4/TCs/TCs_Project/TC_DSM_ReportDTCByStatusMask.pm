#### TEST CASE MODULE
package TC_DSM_ReportDTCByStatusMask;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: Include/TCpmGenerator/Create_TCpm.pl 1.1 2015/01/21 16:00:45MEZ Geisler Martin (CC-PS/EPS2) (gem1si) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DSM_ReadDTCInformation
#TS version in DOORS: 4.9
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use GENERIC_DCOM;
use LIFT_CD;
use LIFT_evaluation;
##################################

our $PURPOSE = "to check that service 19 02 reports the correct DTCs that match a particular status mask";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DSM_ReportDTCByStatusMask

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault

Set <AddressingMode>, Enter <Session>


I<B<Stimulation and Measurement>>

1. Create <Faults_Qualify> and wait for qualification time

2. Send <ReportDTCByStatusMask> with <StatusMask>

3. Remove <Faults_Dequalify> and wait for dequalification time

4. Send <ReportDTCByStatusMask> with <StatusMask>

5. Reset ECU twice

6. Send <ReportDTCByStatusMask> with <StatusMask>

7. Clear fault memory and wait for qualification time

8. Send <ReportDTCByStatusMask> with <StatusMask>

9. Remove all remaining faults created in step 1 (if not removed in step 3)


I<B<Evaluation>>

2. Positive response with <DTCStatusAvailabilityMask> and <DTC_Status_AfterQualify>

4. Positive response with <DTCStatusAvailabilityMask> and <DTC_Status_AfterDequalify>

6. Positive response with <DTCStatusAvailabilityMask> and <DTC_Status_AfterReset>

8. Positive response with <DTCStatusAvailabilityMask> and <DTC_Status_AfterClear>

In any of the above steps, if 'DTC_Status_AfterXYZ' parameter is empty, the response format is positive response bytes followed <DTCStatusAvailabilityMask>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	LIST 'Faults_Qualify' => 
	LIST 'Faults_Dequalify' => 
	HASH 'DTC_Status_AfterQualify' => 
	HASH 'DTC_Status_AfterDequalify' => 
	HASH 'DTC_Status_AfterReset' => 
	HASH 'DTC_Status_AfterClear' => 
	SCALAR 'purpose' => 
	SCALAR 'AddressingMode' => 
	SCALAR 'Session' => 
	SCALAR 'RdNbrOfDTCByStatusMask' => 
	SCALAR 'StatusMask' => 
	SCALAR 'DTCStatusAvailabilityMask' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that service 19 02 reports the correct DTCs that match a particular status mask' 
	# input parameters
	AddressingMode = 'physical'
	Session = 'DefaultSession'
	RdNbrOfDTCByStatusMask = 'ReadDTCInformation_ReportDtcsByStatusMask'
	StatusMask = '<Test Heading 2>'
	#output parameters
	DTCStatusAvailabilityMask = '39'
	#any 5 cyclic faults
	Faults_Qualify = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	
	Faults_Dequalify = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	
	DTC_Status_AfterQualify = '09'
	
	DTC_Status_AfterDequalify = 'NotReported'
	
	DTC_Status_AfterReset = 'NotReported'
	
	DTC_Status_AfterClear = 'NotReported'
=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_AddressingMode;
my $tcpar_Session;
my $tcpar_RdNbrOfDTCByStatusMask;
my $tcpar_StatusMask;
my $tcpar_DTCStatusAvailabilityMask;
my @tcpar_Faults_Qualify;
my @tcpar_Faults_Dequalify;
my $tcpar_DTC_Status_AfterQualify;
my $tcpar_DTC_Status_AfterDequalify;
my $tcpar_DTC_Status_AfterReset;
my $tcpar_DTC_Status_AfterClear;

################ global parameter declaration ###################
#add any global variables here

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                   = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_AddressingMode            = GEN_Read_mandatory_testcase_parameter('AddressingMode');
	$tcpar_Session                   = GEN_Read_mandatory_testcase_parameter('Session');
	$tcpar_RdNbrOfDTCByStatusMask    = GEN_Read_mandatory_testcase_parameter('RdNbrOfDTCByStatusMask');
	$tcpar_StatusMask                = GEN_Read_mandatory_testcase_parameter('StatusMask');
	$tcpar_DTCStatusAvailabilityMask = GEN_Read_mandatory_testcase_parameter('DTCStatusAvailabilityMask');
	@tcpar_Faults_Qualify            = GEN_Read_mandatory_testcase_parameter('Faults_Qualify');
	@tcpar_Faults_Dequalify          = GEN_Read_mandatory_testcase_parameter('Faults_Dequalify');
	$tcpar_DTC_Status_AfterQualify   = GEN_Read_mandatory_testcase_parameter('DTC_Status_AfterQualify');
	$tcpar_DTC_Status_AfterDequalify = GEN_Read_mandatory_testcase_parameter('DTC_Status_AfterDequalify');
	$tcpar_DTC_Status_AfterReset     = GEN_Read_mandatory_testcase_parameter('DTC_Status_AfterReset');
	$tcpar_DTC_Status_AfterClear     = GEN_Read_mandatory_testcase_parameter('DTC_Status_AfterClear');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	S_teststep( "Set '$tcpar_AddressingMode', Enter '$tcpar_Session'", 'AUTO_NBR' );
	GDCOM_set_addressing_mode($tcpar_AddressingMode);
	DIAG_StartSession($tcpar_Session);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Create 'Faults_Qualify' and wait for qualification time", 'AUTO_NBR' );
	foreach (@tcpar_Faults_Qualify) {
		FM_createFault($_);
	}
	S_wait_ms( 10000, 'wait for qualification time' );

	S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with '$tcpar_StatusMask'", 'AUTO_NBR', 'send_reportdtcbystatusmask_with_A' );    #measurement 1
	my $response_afterqualify = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );
	if ( $tcpar_DTC_Status_AfterQualify eq 'NotReported' ) {
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask", 'send_reportdtcbystatusmask_with_A' );       #evaluation 1
		S_teststep_detected( "Response = $response_afterqualify", 'send_reportdtcbystatusmask_with_A' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterQualify", $response_afterqualify, 2, $tcpar_DTCStatusAvailabilityMask );
	}
	else {
		$response_afterqualify = &_responseWithoutDTCName($response_afterqualify);
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask $tcpar_DTC_Status_AfterQualify", 'send_reportdtcbystatusmask_with_A' );    #evaluation 1
		S_teststep_detected( "Response = $response_afterqualify", 'send_reportdtcbystatusmask_with_A' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterQualify", $response_afterqualify, 2, $tcpar_DTCStatusAvailabilityMask );
		GDCOM_evaluate_response_bytes( "DTCStatus_AfterQualify",                 $response_afterqualify, 3, $tcpar_DTC_Status_AfterQualify );
	}

	S_teststep( "Remove 'Faults_Dequalify' and wait for dequalification time", 'AUTO_NBR' );
	foreach (@tcpar_Faults_Dequalify) {
		FM_removeFault($_);
	}
	S_wait_ms( 10000, 'wait for dequalification time' );

	S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with '$tcpar_StatusMask'", 'AUTO_NBR', 'send_reportdtcbystatusmask_with_B' );                                #measurement 2
	my $response_afterdequalify = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );
	if ( $tcpar_DTC_Status_AfterDequalify eq 'NotReported' ) {
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask", 'send_reportdtcbystatusmask_with_B' );                                   #evaluation 2
		S_teststep_detected( "Response = $response_afterdequalify", 'send_reportdtcbystatusmask_with_B' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterDequalify", $response_afterdequalify, 2, $tcpar_DTCStatusAvailabilityMask );

	}
	else {
		$response_afterqualify = &_responseWithoutDTCName($response_afterqualify);
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask $tcpar_DTC_Status_AfterDequalify", 'send_reportdtcbystatusmask_with_B' );    #evaluation 2
		S_teststep_detected( "Response = $response_afterdequalify", 'send_reportdtcbystatusmask_with_B' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterDequalify", $response_afterdequalify, 2, $tcpar_DTCStatusAvailabilityMask );
		GDCOM_evaluate_response_bytes( "DTCStatus_AfterDequalify",                 $response_afterdequalify, 3, $tcpar_DTC_Status_AfterDequalify );
	}

	S_teststep( "Reset ECU twice", 'AUTO_NBR' );
	GEN_Power_on_Reset();
	GEN_Power_on_Reset();

	S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with '$tcpar_StatusMask'", 'AUTO_NBR', 'send_reportdtcbystatusmask_with_C' );                                  #measurement 3
	my $response_afterreset = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );
	if ( $tcpar_DTC_Status_AfterReset eq 'NotReported' ) {
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask", 'send_reportdtcbystatusmask_with_C' );                                     #evaluation 3
		S_teststep_detected( "Response = $response_afterreset", 'send_reportdtcbystatusmask_with_C' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterReset", $response_afterreset, 2, $tcpar_DTCStatusAvailabilityMask );
	}
	else {
		$response_afterqualify = &_responseWithoutDTCName($response_afterqualify);
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask $tcpar_DTC_Status_AfterReset", 'send_reportdtcbystatusmask_with_C' );        #evaluation 3
		S_teststep_detected( "Response = $response_afterreset", 'send_reportdtcbystatusmask_with_C' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterReset", $response_afterreset, 2, $tcpar_DTCStatusAvailabilityMask );
		GDCOM_evaluate_response_bytes( "DTCStatus_AfterReset",                 $response_afterreset, 3, $tcpar_DTC_Status_AfterReset );
	}

	S_teststep( "Clear fault memory and wait for qualification time", 'AUTO_NBR' );
	CD_clear_DTC();
	S_wait_ms( 10000, 'wait for qualification time' );

	S_teststep( "Send '$tcpar_RdNbrOfDTCByStatusMask' with '$tcpar_StatusMask'", 'AUTO_NBR', 'send_reportdtcbystatusmask_with_D' );                                  #measurement 4
	my $response_afterclear = GDCOM_request_general( "REQ_" . $tcpar_RdNbrOfDTCByStatusMask, "PR_" . $tcpar_RdNbrOfDTCByStatusMask, { 'StatusMask' => $tcpar_StatusMask } );
	if ( $tcpar_DTC_Status_AfterClear eq 'NotReported' ) {
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask", 'send_reportdtcbystatusmask_with_D' );                                     #evaluation 3
		S_teststep_detected( "Response = $response_afterclear", 'send_reportdtcbystatusmask_with_D' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterReset", $response_afterreset, 2, $tcpar_DTCStatusAvailabilityMask );
	}
	else {
		$response_afterqualify = &_responseWithoutDTCName($response_afterqualify);
		S_teststep_expected( "Positive response: 59 02 $tcpar_DTCStatusAvailabilityMask $tcpar_DTC_Status_AfterClear", 'send_reportdtcbystatusmask_with_D' );        #evaluation 3
		S_teststep_detected( "Response = $response_afterclear", 'send_reportdtcbystatusmask_with_D' );
		GDCOM_evaluate_response_bytes( "DTCStatusAvailabilityMask_AfterReset", $response_afterreset, 2, $tcpar_DTCStatusAvailabilityMask );
		GDCOM_evaluate_response_bytes( "DTCStatus_AfterClear",                 $response_afterclear, 3, $tcpar_DTC_Status_AfterClear );
	}

	S_teststep( "Remove all remaining faults created in step 1 (if not removed in step 3)", 'AUTO_NBR' );
	foreach my $fault (@tcpar_Faults_Qualify) {
		next if ( grep { $_ eq $fault } @tcpar_Faults_Dequalify );
		FM_removeFault($fault);
	}
	S_wait_ms( 10000, 'wait for dequalification time' );

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();
	GDCOM_set_addressing_mode('physical');

	return 1;
}

sub _responseWithoutDTCName {
	my $response = shift;

	my @response = split / /, $response;
	splice( @response, 3, 3 );
	$response = join ' ', @response;

	return $response;
}

1;
