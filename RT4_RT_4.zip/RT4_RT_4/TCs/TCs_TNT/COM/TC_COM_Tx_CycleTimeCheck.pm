#### TEST CASE MODULE
package TC_COM_Tx_CycleTimeCheck;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.6 $;
our $HEADER = q$Header: COM/TC_COM_Tx_CycleTimeCheck.pm 1.6 2017/07/30 00:16:40ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "<To measure the cycle time of Tx message  under different voltage conditions and different ECU modes>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_Tx_CycleTimeCheck_HighBusLoad

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

#Note : Increase Bus load up to 70% (High) before executing test cases


I<B<Stimulation and Measurement>>

1. Set ECU Mode <ECU_Mode>

2.  Set the ECU Supply Voltage at <Low_Volt>

 

3. Switch OFF the ECU.

4. Wait till ECU goes to Off State

5. Switch ON the ECU.

6. Wait till ECU intialization period completes

7. Record PDU <MsgName> on <Protocol>

8. Check the CycleTime. Calculate the average cycle time over <No_Of_Samples> samples of the message <MsgName>

9.  Set the ECU Supply Voltage at <Normal_Volt>

 

10. Switch OFF the ECU.

11. Wait till ECU goes to Off State

12. Switch ON the ECU.

13. Wait till ECU intialization period completes

14. Record PDU <MsgName> on <Protocol>

15. Check the CycleTime. Calculate the average cycle time over <No_Of_Samples> samples of the message <MsgName>

16.  Set the ECU Supply Voltage at <High_Volt>

 

17. Switch OFF the ECU.

18. Wait till ECU goes to Off State

19. Switch ON the ECU.

20. Wait till ECU intialization period completes

21. Record PDU <MsgName> on <Protocol>

22. Check the CycleTime. Calculate the average cycle time over <No_Of_Samples> samples of the message <MsgName>

23.  Set the ECU Supply Voltage at <Over_Volt>

 

24. Switch OFF the ECU.

25. Wait till ECU goes to Off State

26. Switch ON the ECU.

27. Wait till ECU intialization period completes

28. Record PDU <MsgName> on <Protocol>

29. Check the CycleTime. Calculate the average cycle time over <No_Of_Samples> samples of the message <MsgName>


I<B<Evaluation>>

1.

2.

3.

4.

5

6

7

8. Average calculated time must match with that in K Matrix. with a tolerance of <ToleranceAverage> %, min and max time is also matching with <ToleranceMinMax>%

9.

10.

11.

12

13.

14.

15. Average calculated time must match with that in K Matrix. with a tolerance of <ToleranceAverage> %, min and max time is also matching with <ToleranceMinMax>%

16.

17.

18.

19

20.

21.

22. Average calculated time must match with that in K Matrix. with a tolerance of <ToleranceAverage> %, min and max time is also matching with <ToleranceMinMax>%

23.

24.

25.

26.

27.

28.

29. Average calculated time must match with that in K Matrix. with a tolerance of <ToleranceAverage> %, min and max time is also matching with <ToleranceMinMax>%

Note : Error frames should not be observed during normal operation


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'ECU_Mode' => 
	SCALAR 'Low_Volt' => 
	SCALAR 'Normal_Volt' => 
	SCALAR 'High_Volt' => 
	SCALAR 'Over_Volt' => 
	SCALAR 'MsgName' => 
	SCALAR 'Protocol' => 
	SCALAR 'No_Of_Samples' => 
	HASH 'ToleranceAverage' => 
	HASH 'ToleranceMinMax' => 


=head2 PARAMETER EXAMPLES

	# ---------- Stimulation ------------
	purpose  = 'Measuring the cycle time of the message is within allowed jitter time'
	ECU_Mode = '<Test Heading 1>'
	Low_Volt = '8'#Volt
	Normal_Volt = '13'#Volt
	High_Volt = '18'#Volt
	Over_Volt = '20'#Volt
	MsgName= '<Fetch {Object Heading} {(.*)}>'
	Protocol = 'can'
	No_Of_Samples = '100'
	ToleranceAverage = '1' #%
	ToleranceMinMax = '10' #%
	 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_Mode;
my $TP_handle;
my @Testcondition = ('8','13','18');

# Test case parameters
my ($tcpar_MsgName,$tcpar_Protocol,$tcpar_NoOfSamples, $tcpar_ToleranceAverage, $tcpar_ToleranceMinMax);

# Variables used inside the script
my ($MaxCycleTime, $MinCycleTime, $Average_Time, $CycleTime, $TracePath, $MyMsgInfo);

################ global parameter declaration ###################
my %MyData;


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_ECU_Mode =  GEN_Read_optional_testcase_parameter( 'ECU_Mode' );
	
	GEN_printTestStep("Set test parameters"); 
	$tcpar_MsgName = GEN_Read_mandatory_testcase_parameter( 'MsgName' );
	$tcpar_Protocol = GEN_Read_mandatory_testcase_parameter( 'Protocol' );
	
	unless( defined $tcpar_ECU_Mode ) {
  	S_w2rep(" -->  Missing optional parameter 'ECU_Mode'. Assuming it as 'NormalMode' \n");
  	$tcpar_ECU_Mode = 'NormalMode';
    };	

	$tcpar_ToleranceAverage = GEN_Read_optional_testcase_parameter( 'ToleranceAverage' ); 
	unless( defined $tcpar_ToleranceAverage ) 
	{
		S_w2rep(" -->  Missing Optional parameter 'ToleranceAverage' , Setting it to value 10%.\n");
		$tcpar_ToleranceAverage = 10;
	};
	
	$tcpar_ToleranceMinMax = GEN_Read_optional_testcase_parameter( 'ToleranceMinMax' ); 
	unless( defined $tcpar_ToleranceMinMax ) 
	{
		S_w2rep(" -->  Missing Optional parameter 'ToleranceMinMax' , Setting it to value 10%.\n");
		$tcpar_ToleranceMinMax = 10;
	};
	
	$tcpar_NoOfSamples = GEN_Read_optional_testcase_parameter('No_Of_Samples');
	unless( defined $tcpar_NoOfSamples ) 
	{
		S_w2rep(" -->  Missing Optional parameter 'No_Of_Samples' , Setting it to value 10.\n");
		$tcpar_NoOfSamples = 100;
	 };

	# Cycle Time
 	$MyMsgInfo = CA_get_can_message_info($tcpar_MsgName); 
	$CycleTime = $MyMsgInfo->{'CYCLE'};
	unless(defined $CycleTime)
	{  	$CycleTime = -1; }

	return 1;
}

sub TC_initialization {
	
	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');  
	CA_trace_start();
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set ECU Mode '$tcpar_ECU_Mode'", 'AUTO_NBR');
	
	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('PlantMode10_SuppressComFaults');
	}
	elsif($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('IdleMode');
	}
	else
	{
		S_w2rep(" No specific handling is required for Normal modes \n");
	}
		
	foreach my $condition (@Testcondition)
	{
		S_teststep("Set the ECU Supply Voltage at '$condition'", 'AUTO_NBR');
		LC_SetVoltage($condition);
		
		S_teststep("Switch OFF the ECU.", 'AUTO_NBR');
		LC_ECU_Off();
		
		S_teststep("Wait till ECU goes to Off State", 'AUTO_NBR');
		S_wait_ms('TIMER_ECU_OFF');
		
		S_teststep("Switch ON the ECU.", 'AUTO_NBR');
		LC_ECU_On($condition);
		
		S_teststep("Wait till ECU intialization period completes", 'AUTO_NBR');
		S_wait_ms('TIMER_ECU_READY');
		
		S_teststep("Record PDU '$tcpar_MsgName' on '$tcpar_Protocol'", 'AUTO_NBR');

		CA_trace_start();
		
		if($CycleTime!=-1)
		{
			S_wait_ms($tcpar_NoOfSamples*$CycleTime);	
		}
		else
		{
			S_wait_ms(5000);	
		}

		S_teststep("Check the CycleTime. Calculate the average cycle time over '$tcpar_NoOfSamples' samples of the message '$tcpar_MsgName'", 'AUTO_NBR',$condition);			#measurement 1
		
		#CA_trace_stop();
		$TracePath = GEN_printLink(CA_trace_store(GEN_generateUniqueTraceName())); 
		if($CycleTime != -1)
		{
			$MyData{$condition} = CA_trace_get_dataref($TracePath,[$tcpar_MsgName]);

            my $current_testcase_name;
            $current_testcase_name =$main::CURRENT_TC;
            $current_testcase_name=~ s/\./-/g; 
            S_dump2pmFile ("VariableToDump" => $MyData{$condition},
                         "VariableName" => "CanTraceData",
                         "PackageName" => "$current_testcase_name\_$condition",
                         "StoragePath" => "$main::REPORT_PATH/");

		}
		else
		{
			S_set_error("The PDU is not defined in Mapping File and Hence Cannot be tested");
		}
	}
	return 1;
}

sub TC_evaluation {

		
	
	foreach my $condition (@Testcondition)
	{
		if($CycleTime != -1 )
		{
			# Get signal's cycle time from the trace 
			($MinCycleTime, $MaxCycleTime, $Average_Time) = EVAL_get_signal_cycletime($MyData{$condition},$tcpar_MsgName); 
			
			S_teststep_detected("Average Cycle Time for the voltage condition $condition is : $Average_Time", $condition);
		    S_teststep_expected("Average Cycle Time for the voltage condition $condition is $CycleTime ", $condition);
		
			# Evaluate values 
			EVAL_evaluate_value ( "Average Cycle Time for the voltage condition $condition is ", $Average_Time, '==',  ($CycleTime/1000) , $tcpar_ToleranceAverage  ); 
			EVAL_evaluate_value ( "Maximum Cycle Time for the voltage condition $condition is ", $MaxCycleTime, '==',  ($CycleTime/1000) , $tcpar_ToleranceMinMax  ); 
			EVAL_evaluate_value ( "Minimum Cycle Time for the voltage condition $condition is ", $MinCycleTime, '==',  ($CycleTime/1000) , $tcpar_ToleranceMinMax  ); 
		}
		else
		{
			S_set_error("Mapping File doesnot contain Cycle Time. OR Message is not supported in Protocol/Project hence evaluation is not done");
			S_set_verdict(VERDICT_NONE);
		}
	}
	return 1;
}

sub TC_finalization {

	S_w2rep("TC FINALIZATION\n");

	if($tcpar_ECU_Mode eq 'Productionmode')
	{
		GEN_setECUMode('RemovePlantModes');
		S_wait_ms (5000);
	}
	
	if($tcpar_ECU_Mode eq 'Idlemode')
	{
		GEN_setECUMode('RemoveIdleMode');
		S_wait_ms (5000);
	}
	
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
