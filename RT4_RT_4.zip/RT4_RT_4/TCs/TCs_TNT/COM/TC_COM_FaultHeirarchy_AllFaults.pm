#### TEST CASE MODULE
package TC_COM_FaultHeirarchy_AllFaults;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: COM/TC_COM_FaultHeirarchy_AllFaults.pm 1.1 2017/08/02 16:47:05ICT Satish N (RBEI/ESM6) (stn3kor) ready_for_review  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.23
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "Check the correct priorisation of three different faults";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_COM_FaultHeirarchy_AllFaults

=head1 PURPOSE

<Check the correct priorisation of three different faults>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1.Create <FaultConditionsInitialSequence> on <MessageName> 

2.Read Fault recorder through PD

3.Read Fault recorder through CD

4.Read Warning lamp after fault qualification

5.Remove <FaultConditionsFinalSequence>

6.Read Fault recorder through PD

7.Read Fault recorder through CD

8.Read Warning lamp after fault qualification


I<B<Evaluation>>

1.

2.The Fault <faultname>  should have <FaultStatesInitial> 

3.The Fault <faultname>  should have <FaultStatesInitial>

4. Warning lamp <SysWL_SigLabel> should have the status <SysWLQualiStatus>

5.

6.The Fault <faultname>  should have <FaultStatesFinal > 

7.The Fault <faultname>  should have <FaultStatesFinal >

8. Warning lamp <SysWL_SigLabel> should have the status <SysWLDequaliStatus>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'MessageName' => 
	LIST 'FaultConditionsInitialSequence' => 
	LIST 'FaultConditionsFinalSequence' => 
	LIST 'faultname' => 
	LIST 'FaultStatesInitial' => 
	LIST 'FaultStatesFinal' => 
	SCALAR 'SysWL_SigLabel' => 
	SCALAR 'SysWLQualiStatus' => 
	SCALAR 'SysWLDequaliStatus' => 


=head2 PARAMETER EXAMPLES

	purpose		 = 'To test CRC and BZ and Timeout Fault Heirarchy'
	
	MessageName ='<Test Heading>'
	FaultConditionsInitialSequence =@('AliveCounterError','CRCError','TimeOutError')
	
	FaultConditionsFinalSequence=@('TimeOutError','AliveCounterError','CRCError')
	
	faultname = @ ('TBD', 'TBD', 'TBD')
	
	FaultStatesInitial =@('Qualified','Qualified','Qualified')
	
	FaultStatesFinal =@('Dequalified','Dequalified','Dequalified')
	
	SysWL_SigLabel ='TBD'
	
	SysWLQualiStatus = 'TBD'
	
	SysWLDequaliStatus = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_MessageNameName;
my @tcpar_FaultConditionsInitialSequence;
my @tcpar_FaultConditionsFinalSequence;
my @tcpar_faultname;
my @tcpar_FaultStatesInitial;
my @tcpar_FaultStatesFinal;
my @tcpar_FaultStatesInitialonCD;
my @tcpar_FaultStatesFinalonCD;
my $tcpar_SysWL_SigLabel;
my $tcpar_SysWLQualiStatus;
my $tcpar_SysWLDequaliStatus;
my $tcpar_MessageName;
my $tcpar_Protocol;


################ global parameter declaration ###################
my %flt_mem_struct_pd_BZ_qualification;
my %flt_mem_struct_cd_BZ_qualification;

my %flt_mem_struct_pd_CRC_qualification;
my %flt_mem_struct_cd_CRC_qualification;

my %flt_mem_struct_pd_timeout_qualification;
my %flt_mem_struct_cd_timeout_qualification;

my %flt_mem_struct_pd_timeout_dequalification;
my %flt_mem_struct_cd_timeout_dequalification;

my %flt_mem_struct_pd_CRC_dequalification;
my %flt_mem_struct_cd_CRC_dequalification;

my %flt_mem_struct_pd_BZ_dequalification;
my %flt_mem_struct_cd_BZ_dequalification;

my $SysWLAtFltQuali;
my $SysWLAtFltdequali;
my $detected_CD_status;
my $detected_PD_status;
my $tcpar_maxWaitTime ;
my $faultproperty;
my $InvalidCRCValue;
my $ValidCRCValue;
my $InvalidBZValue;
my $ValidBZValue;
my $CRCEnVarName;
my $BZEnVarName;
my $Timeoutfault;
my $CRCfault;
my $BZfault;
my $Timeoutfaultstateinitial;
my $CRCfaultstateinitial;
my $BZfaultstateinitial;
my $Timeoutfaultstatfinal;
my $CRCfaultstatefinal;
my $BZfaultstatefinal;
my $TimeoutfaultstateinitialonCD;
my $CRCfaultstateinitialonCD;
my $BZfaultstateinitialonCD;
my $TimeoutfaultstatfinalonCD;
my $CRCfaultstatefinalonCD;
my $BZfaultstatefinalonCD;
my $unit;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_MessageName =  GEN_Read_mandatory_testcase_parameter( 'MessageName' );
	$tcpar_Protocol =  GEN_Read_mandatory_testcase_parameter( 'Protocol' );
	@tcpar_FaultConditionsInitialSequence =  GEN_Read_mandatory_testcase_parameter( 'FaultConditionsInitialSequence' );
	@tcpar_FaultConditionsFinalSequence =  GEN_Read_mandatory_testcase_parameter( 'FaultConditionsFinalSequence' );
	@tcpar_faultname =  GEN_Read_mandatory_testcase_parameter( 'faultname' );
	@tcpar_FaultStatesInitial =  GEN_Read_mandatory_testcase_parameter( 'FaultStatesInitial' );
	@tcpar_FaultStatesFinal =  GEN_Read_mandatory_testcase_parameter( 'FaultStatesFinal' );
	@tcpar_FaultStatesInitialonCD =  GEN_Read_mandatory_testcase_parameter( 'FaultStatesInitialonCD' );
	@tcpar_FaultStatesFinalonCD =  GEN_Read_mandatory_testcase_parameter( 'FaultStatesFinalonCD' );	
	$tcpar_SysWL_SigLabel =  GEN_Read_mandatory_testcase_parameter( 'SysWL_SigLabel' );
	$tcpar_SysWLQualiStatus =  GEN_Read_mandatory_testcase_parameter( 'SysWLQualiStatus' );
	$tcpar_SysWLDequaliStatus =  GEN_Read_mandatory_testcase_parameter( 'SysWLDequaliStatus' );
	#von hier aus ist es ein versuch
	$InvalidBZValue = GEN_Read_mandatory_testcase_parameter( 'InvalidBZValue' );
	$InvalidCRCValue = GEN_Read_mandatory_testcase_parameter( 'InvalidCRCValue' );
	$ValidBZValue = GEN_Read_mandatory_testcase_parameter( 'ValidBZValue' );
	$ValidCRCValue = GEN_Read_mandatory_testcase_parameter( 'ValidCRCValue');
	$tcpar_maxWaitTime = GEN_Read_mandatory_testcase_parameter( 'maxWaitTime' );

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    #GEN_StandardPrepNoFault();
    S_wait_ms(5000);	
	
	my $CAN_Mapping = S_get_contents_of_hash( ['Mapping_CAN'] );	
	$CRCEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDCRC'};		
	$BZEnVarName = $CAN_Mapping->{'CAN_MESSAGES'}{$tcpar_MessageName}{'CANOE_VALIDBZ'};

	$Timeoutfault = @tcpar_faultname [0];
	$CRCfault = @tcpar_faultname [1];
	$BZfault = @tcpar_faultname [2];
	$Timeoutfaultstateinitial = @tcpar_FaultStatesInitial [2];
	$CRCfaultstateinitial = @tcpar_FaultStatesInitial [1];
	$BZfaultstateinitial = @tcpar_FaultStatesInitial [0];
	
	$Timeoutfaultstatfinal = @tcpar_FaultStatesFinal [0];
	$CRCfaultstatefinal = @tcpar_FaultStatesFinal [2];
	$BZfaultstatefinal = @tcpar_FaultStatesFinal [1];
	
	$TimeoutfaultstateinitialonCD = @tcpar_FaultStatesInitialonCD [2];
	$CRCfaultstateinitialonCD = @tcpar_FaultStatesInitialonCD [1];
	$BZfaultstateinitialonCD = @tcpar_FaultStatesInitialonCD [0];
	
	$TimeoutfaultstatfinalonCD = @tcpar_FaultStatesFinalonCD [0];
	$CRCfaultstatefinalonCD = @tcpar_FaultStatesFinalonCD [2];
	$BZfaultstatefinalonCD = @tcpar_FaultStatesFinalonCD [1];	
	
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Create '@tcpar_FaultConditionsInitialSequence' on '$tcpar_MessageName' ", 'AUTO_NBR');
	foreach my $FaultCondition (@tcpar_FaultConditionsInitialSequence)
	{
		if($FaultCondition eq 'AliveCounterError')
		{
			#CA_set_invalidBZ($tcpar_MessageName,$tcpar_Method,$tcpar_NbOfCycles);
			CA_set_EnvVar_value ( $BZEnVarName, $InvalidBZValue);
		}
		elsif($FaultCondition eq 'CRCError')
		{
			#CA_set_invalidCRC($tcpar_MessageName,$tcpar_Method);
			CA_set_EnvVar_value ( $CRCEnVarName, $InvalidCRCValue);
		}
		elsif($FaultCondition eq 'TimeOutError')
		{
			COM_stopMessages( [$tcpar_MessageName], $tcpar_Protocol );
		}
		S_wait_ms($tcpar_maxWaitTime);
	}
		
	S_teststep("Read Fault recorder through PD for $BZfault", 'AUTO_NBR', 'read_fault_recorder_PD_Qual_BZ');			#measurement 3

	$flt_mem_struct_pd_BZ_qualification{'BZFaultStatus_afterQualification'} = PD_ReadFaultMemory();
	
	S_teststep("Read Fault recorder through CD for $BZfault", 'AUTO_NBR', 'read_fault_recorder_CD_Qual_BZ');			#measurement 6

	$flt_mem_struct_cd_BZ_qualification{'BZFaultStatus_afterQualification'} = CD_read_DTC('02','08');	

	S_teststep("Read Fault recorder through PD for $CRCfault", 'AUTO_NBR', 'read_fault_recorder_PD_Qual_CRC');			#measurement 2

	$flt_mem_struct_pd_CRC_qualification{'CRCFaultStatus_afterQualification'} = PD_ReadFaultMemory();	

	S_teststep("Read Fault recorder through CD for $CRCfault", 'AUTO_NBR', 'read_fault_recorder_CD_Qual_CRC');			#measurement 5

	$flt_mem_struct_cd_CRC_qualification{'CRCFaultStatus_afterQualification'} = CD_read_DTC('02','08');	
	
	S_teststep("Read Fault recorder through PD for $Timeoutfault", 'AUTO_NBR', 'read_fault_recorder_PD_Qual_Timeout');			#measurement 1

	$flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'} = PD_ReadFaultMemory();
	
	S_teststep("Read Fault recorder through CD for $Timeoutfault", 'AUTO_NBR', 'read_fault_recorder_CD_Qual_Timeout');			#measurement 4

	$flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'} = CD_read_DTC('02','08');	
	
	S_teststep("Read Warning lamp after fault qualification", 'AUTO_NBR', 'read_warning_lamp_A');			#measurement 7

	($SysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );
	
	S_teststep("Remove '@tcpar_FaultConditionsFinalSequence'", 'AUTO_NBR');
	
	foreach my $FaultCondition (@tcpar_FaultConditionsFinalSequence)
	{
		if($FaultCondition eq 'TimeOutError')
		{
			COM_startMessages( [$tcpar_MessageName], $tcpar_Protocol );
		}
		elsif($FaultCondition eq 'CRCError')
		{
			#CA_set_invalidCRC($tcpar_MessageName,$tcpar_Method);
			CA_set_EnvVar_value ( $CRCEnVarName, $ValidCRCValue);
		}
		elsif($FaultCondition eq 'AliveCounterError')
		{
			#CA_set_validBZ($tcpar_MessageName);
			CA_set_EnvVar_value ( $BZEnVarName, $ValidBZValue);
		}
		S_wait_ms($tcpar_maxWaitTime);
	}

	S_teststep("Read Fault recorder through PD for $Timeoutfault", 'AUTO_NBR', 'read_fault_recorder_PD_Dequal_Timeout');			#measurement 8

	$flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'} = PD_ReadFaultMemory();

	S_teststep("Read Fault recorder through CD for $Timeoutfault", 'AUTO_NBR', 'read_fault_recorder_CD_Dequal_Timeout');			#measurement 11

	$flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'} = CD_read_DTC('02','08');	

	S_teststep("Read Fault recorder through PD for $BZfault", 'AUTO_NBR', 'read_fault_recorder_PD_Dequal_BZ');			#measurement 10

	$flt_mem_struct_pd_BZ_dequalification{'BZFaultStatus_afterDequalification'} = PD_ReadFaultMemory();

	S_teststep("Read Fault recorder through CD for $BZfault", 'AUTO_NBR', 'read_fault_recorder_CD_Dequal_BZ');			#measurement 13

	$flt_mem_struct_cd_BZ_dequalification{'BZFaultStatus_afterDequalification'} = CD_read_DTC('02','08');
	
	S_teststep("Read Fault recorder through PD for $CRCfault", 'AUTO_NBR', 'read_fault_recorder_PD_Dequal_CRC');			#measurement 9

	$flt_mem_struct_pd_CRC_dequalification{'CRCFaultStatus_afterDequalification'} = PD_ReadFaultMemory();
	
	S_teststep("Read Fault recorder through CD for $CRCfault", 'AUTO_NBR', 'read_fault_recorder_CD_Dequal_CRC');			#measurement 12

	$flt_mem_struct_cd_CRC_dequalification{'CRCFaultStatus_afterDequalification'} = CD_read_DTC('02','08');	
	
	
	
	S_teststep("Read Warning lamp after fault dequalification", 'AUTO_NBR', 'read_warning_lamp_B');			#measurement 14

	($SysWLAtFltdequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' );
	
	return 1;
}

sub TC_evaluation {

	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_BZ_qualification{'BZFaultStatus_afterQualification'}, $BZfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Qual_BZ');
	S_teststep_expected("The Fault '$BZfault'  should have '$BZfaultstateinitial' ", 'read_fault_recorder_PD_Qual_BZ');			#evaluation 3
	PD_check_fault_status($flt_mem_struct_pd_BZ_qualification{'BZFaultStatus_afterQualification'}, $BZfault, $BZfaultstateinitial);

	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_BZ_qualification{'BZFaultStatus_afterQualification'}, $BZfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Qual_BZ');
	S_teststep_expected("The Fault '$BZfault'  should have '$BZfaultstateinitialonCD'", 'read_fault_recorder_CD_Qual_BZ');			#evaluation 6
	CD_check_fault_status($flt_mem_struct_cd_BZ_qualification{'BZFaultStatus_afterQualification'}, $BZfault, $BZfaultstateinitialonCD);
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_CRC_qualification{'CRCFaultStatus_afterQualification'}, $CRCfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Qual_CRC');
	S_teststep_expected("The Fault '$CRCfault'  should have '$CRCfaultstateinitial' ", 'read_fault_recorder_PD_Qual_CRC');			#evaluation 2
	PD_check_fault_status($flt_mem_struct_pd_CRC_qualification{'CRCFaultStatus_afterQualification'}, $CRCfault, $CRCfaultstateinitial);

	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_CRC_qualification{'CRCFaultStatus_afterQualification'}, $CRCfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Qual_CRC');
	S_teststep_expected("The Fault '$CRCfault'  should have '$CRCfaultstateinitialonCD'", 'read_fault_recorder_CD_Qual_CRC');			#evaluation 5
	CD_check_fault_status($flt_mem_struct_cd_CRC_qualification{'CRCFaultStatus_afterQualification'}, $CRCfault, $CRCfaultstateinitialonCD);	

	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $Timeoutfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Qual_Timeout');
	S_teststep_expected("The Fault '$Timeoutfault'  should have '$Timeoutfaultstateinitial' ", 'read_fault_recorder_PD_Qual_Timeout');			#evaluation 1
	PD_check_fault_status($flt_mem_struct_pd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $Timeoutfault, $Timeoutfaultstateinitial);
	
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $Timeoutfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Qual_Timeout');
	S_teststep_expected("The Fault '$Timeoutfault'  should have '$TimeoutfaultstateinitialonCD'", 'read_fault_recorder_CD_Qual_Timeout');			#evaluation 4
	CD_check_fault_status($flt_mem_struct_cd_timeout_qualification{'TimeoutFaultStatus_afterQualification'}, $Timeoutfault, $TimeoutfaultstateinitialonCD);

	S_teststep_detected("<<add detected result here>>", 'read_warning_lamp_A');
	S_teststep_expected("Warning lamp '$tcpar_SysWL_SigLabel' should have the status '$tcpar_SysWLQualiStatus'", 'read_warning_lamp_A');			#evaluation 7
	EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $SysWLAtFltQuali, '==', $tcpar_SysWLQualiStatus );
	
	#Dequalified faults
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $Timeoutfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Dequal_Timeout');
	S_teststep_expected("The Fault '$Timeoutfault'  should have '$Timeoutfaultstatfinal ' ", 'read_fault_recorder_PD_Dequal_Timeout');			#evaluation 8
	PD_check_fault_status($flt_mem_struct_pd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $Timeoutfault, $Timeoutfaultstatfinal);
	
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $Timeoutfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Dequal_Timeout');
	S_teststep_expected("The Fault '$Timeoutfault'  should have '$TimeoutfaultstatfinalonCD '", 'read_fault_recorder_CD_Dequal_Timeout');			#evaluation 11
	CD_check_fault_status($flt_mem_struct_cd_timeout_dequalification{'TimeoutFaultStatus_afterDequalification'}, $Timeoutfault, $TimeoutfaultstatfinalonCD);
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_BZ_dequalification{'BZFaultStatus_afterDequalification'}, $BZfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Dequal_BZ');
	S_teststep_expected("The Fault '$BZfault'  should have '$BZfaultstatefinal ' ", 'read_fault_recorder_PD_Dequal_BZ');			#evaluation 10
	PD_check_fault_status($flt_mem_struct_pd_BZ_dequalification{'BZFaultStatus_afterDequalification'}, $BZfault, $BZfaultstatefinal);
		
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_BZ_dequalification{'BZFaultStatus_afterDequalification'}, $BZfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Dequal_BZ');
	S_teststep_expected("The Fault '$BZfault'  should have '$BZfaultstatefinalonCD '", 'read_fault_recorder_CD_Dequal_BZ');			#evaluation 13
	CD_check_fault_status($flt_mem_struct_cd_BZ_dequalification{'BZFaultStatus_afterDequalification'}, $BZfault, $BZfaultstatefinalonCD);	
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_CRC_dequalification{'CRCFaultStatus_afterDequalification'}, $CRCfault );
	S_teststep_detected("Detected Fault status is $detected_PD_status", 'read_fault_recorder_PD_Dequal_CRC');
	S_teststep_expected("The Fault '$CRCfault'  should have '$CRCfaultstatefinal ' ", 'read_fault_recorder_PD_Dequal_CRC');			#evaluation 9
	PD_check_fault_status($flt_mem_struct_pd_CRC_dequalification{'CRCFaultStatus_afterDequalification'}, $CRCfault, $CRCfaultstatefinal);
	
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_CRC_dequalification{'CRCFaultStatus_afterDequalification'}, $CRCfault );
	S_teststep_detected("Detected Fault status is $detected_CD_status", 'read_fault_recorder_CD_Dequal_CRC');
	S_teststep_expected("The Fault '$CRCfault'  should have '$CRCfaultstatefinalonCD '", 'read_fault_recorder_CD_Dequal_CRC');			#evaluation 12
	CD_check_fault_status($flt_mem_struct_cd_CRC_dequalification{'CRCFaultStatus_afterDequalification'}, $CRCfault, $CRCfaultstatefinalonCD);
	
	S_teststep_detected("<<add detected result here>>", 'read_warning_lamp_B');
	S_teststep_expected("Warning lamp '$tcpar_SysWL_SigLabel' should have the status '$tcpar_SysWLDequaliStatus'", 'read_warning_lamp_B');			#evaluation 14
	EVAL_evaluate_value( "System warning lamp status after BZ fault dequalification : ", $SysWLAtFltdequali, '==', $tcpar_SysWLDequaliStatus );
	
	return 1;
}

sub TC_finalization {

	PD_ClearFaultMemory();
	#LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}


1;
