#### TEST CASE MODULE
package  TC_COM_FaultHandling_StartupDelay;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER = q$Header: COM/TC_COM_FaultHandling_StartupDelay.pm 1.3 2017/07/30 00:16:55ICT Satish N (RBEI/ESM6) (stn3kor) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_COM_Application
#TS version in DOORS: 4.22
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_can_access;
use LIFT_labcar;
use GENERIC_DCOM;
use LIFT_PD;
use LIFT_CD;
use LIFT_evaluation;

##################################

our $PURPOSE = "To check that COM fault handling during and after  start-up delay";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

 TC_COM_FaultHandling_StartupDelay

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Switch OFF ECU and wait till ECU goes to off state.

2. Create a <COM Fault> , Switch ON ECU, and wait for init qualitime 

3. Measure init qualification time after fault <COM Fault> qualification

4.  Read fault recorder through PD after fault <COM Fault> qualification

5. Read fault recorder through CD after fault <COM Fault> qualification

6. Read the Warning lamp status after fault <COM Fault> qualification

7. Switch OFF ECU and wait till ECU goes to off state.

8.  Remove <COM Fault>,Switch ON ECU and wait for init dequalitime 

9. Measure init dequalification time after fault <COM Fault> dequalification

10.  Read fault recorder through PD after fault <COM Fault> dequalification

11. Read fault recorder through CD after fault <COM Fault> dequalification

12. Read the Warning lamp status after fault <COM Fault> dequalification


I<B<Evaluation>>

1.

2.

3. Measured Init Qualification Time should have Init Qualification time of the fault with  <Tolerance>

4. Fault should have  status <FaultQualistatus> after reading the fault recorder.

5.Fault should have  status <FaultQualistatus> after reading the fault recorder

6. Warning lamp <SysWL_SigLabel> should have status <WL_Faultquali>

7.

8.

9. Measured Init Dequalification Time should have Init Dequalification time of the fault with  <Tolerance>

10. Fault should have  status <FaultDeQualistatus> after reading the fault recorder.

11.Fault should have  status <FaultDeQualistatus> after reading the fault recorder

12. Warning lamp <SysWL_SigLabel> should have status <WL_FaultDequali>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'faultname' => 
	SCALAR 'FaultQualistatus' => 
	SCALAR 'WL_Faultquali' => 
	SCALAR 'WL_FaultDequali' => 
	SCALAR 'FaultDeQualistatus' => 
	HASH 'Tolerance' => 
	SCALAR 'MessageName' => 
	SCALAR 'NbOfCycles' => 
	SCALAR 'purpose' => 
	SCALAR 'COM_Fault' => 
	SCALAR 'Protocol' => 
	SCALAR 'Method' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check that COM fault handling during and after  start-up delay'
	
	COM_Fault= '<Test Heading 1>'
	Protocol = 'can'
	Method = 'Constant'
	faultname = 'TBD'
	FaultQualistatus = 'TBD'
	WL_Faultquali = 'TBD'
	WL_FaultDequali = 'TBD'
	FaultDeQualistatus = 'TBD'
	Tolerance = '10%'
	MessageName  = 'TBD'
	NbOfCycles = 'TBD'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Message;
my $tcpar_ECU_OFF_Time;
my $tcpar_faultname;
my $tcpar_FaultQualistatus;
my $tcpar_WL_Faultquali;
my $tcpar_WL_FaultDequali;
my $tcpar_FaultDeQualistatus;
my $tcpar_CDFaultDeQualistatus;
my $tcpar_SysWL_SigLabel;
my $tcpar_COM_Fault;
my $tcpar_NbOfCycles;
my $tcpar_MessageName;
my $tcpar_Protocol;
my $tcpar_Method;
my $tcpar_signal;
my $tcpar_physicalValue;
my $tcpar_physicalValueValid;

################ global parameter declaration ###################
#add any global variables here
my $faultproperty;
my %flt_mem_struct_pd_qualification;
my %flt_mem_struct_cd_qualification;
my %flt_mem_struct_pd_dequalification;
my %flt_mem_struct_cd_dequalification;
my $sysWLAtFltQuali;
my $sysWLAtFltDequali;
my $unit;
my $FDtrace_name;
my $measuredtime_quali_time;
my $measuredtime_dequali_time;
my $tcpar_Tolerance;
my $fm_initqualitime;
my $fm_initdequalitime;
my $fm_FaultType;
our $PURPOSE;
my $detected_PD_status;
my $detected_CD_status;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Message =  S_read_mandatory_testcase_parameter( 'Message' );
	$tcpar_ECU_OFF_Time =  S_read_mandatory_testcase_parameter( 'ECU_OFF_Time' );
	$tcpar_FaultQualistatus =  S_read_mandatory_testcase_parameter( 'FaultQualistatus' );
	$tcpar_WL_Faultquali =  S_read_mandatory_testcase_parameter( 'WL_Faultquali' );
	$tcpar_WL_FaultDequali =  S_read_mandatory_testcase_parameter( 'WL_FaultDequali' );
	$tcpar_FaultDeQualistatus =  S_read_mandatory_testcase_parameter( 'FaultDeQualistatus' );
	$tcpar_CDFaultDeQualistatus =  S_read_mandatory_testcase_parameter( 'CDFaultDeQualistatus' );
	$tcpar_SysWL_SigLabel = S_read_mandatory_testcase_parameter( 'SysWL_SigLabel' );
	$tcpar_Tolerance = S_read_mandatory_testcase_parameter( 'Tolerance' );	
	$tcpar_COM_Fault =  S_read_mandatory_testcase_parameter( 'COM_Fault' );
	$tcpar_faultname =  S_read_mandatory_testcase_parameter( 'faultname' );	
	$tcpar_Method = S_read_optional_testcase_parameter( 'Method' ); 
	unless( defined $tcpar_Method ) 
	{
			S_w2rep(" -->  Missing optional parameter 'Method', By default script uses 'Constant' as the method. \n");
			$tcpar_Method = 'Constant';
			
	};
	$tcpar_NbOfCycles = S_read_mandatory_testcase_parameter('NbOfCycles');	
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	$tcpar_MessageName = S_read_mandatory_testcase_parameter('MessageName');
	$tcpar_signal = S_read_mandatory_testcase_parameter('signal');	
	$tcpar_physicalValue = S_read_mandatory_testcase_parameter('physicalValue');
	$tcpar_physicalValueValid = S_read_mandatory_testcase_parameter('physicalValueValid');

	return 1;
}

sub TC_initialization {

	S_teststep("Standard_Preparation", 'NO_AUTO_NBR');          
    GEN_StandardPrepNoFault();
    S_wait_ms(5000);	
	
	$faultproperty = FM_fetchFaultInfo($tcpar_faultname);
	S_w2rep("Get Fault properties for $tcpar_faultname\n");	
	
	unless ( keys(%$faultproperty) )
	{                                                     #check if keys are read successfully from mapping file
		S_set_error( "Details are not read successfully from fault mapping file", 10 );    #Error!
		return undef;
	}
			
		$fm_initqualitime   = FM_fetchFaultInfo( $tcpar_faultname, 'InitQualificationtime' );        
		S_w2rep("Expected init Quali time = $fm_initqualitime ms ");


		$fm_initdequalitime = FM_fetchFaultInfo( $tcpar_faultname, 'InitDequalificationtime' );        
		S_w2rep("Expected init Dequali time = $fm_initdequalitime ms ");		


	return 1;
}

sub TC_stimulation_and_measurement {	

	FM_PD_measureTimePreparation( $tcpar_faultname, 'Qualification' );	
	S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
	$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($tcpar_faultname);	
	S_teststep("Switch OFF ECU and wait till ECU goes to off state", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	
	S_teststep("Create a COM Fault'$tcpar_COM_Fault', Switch ON ECU, ,and wait for '$fm_initqualitime'", 'AUTO_NBR');
	
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_stopMessages( [$tcpar_MessageName], 'can' );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValue, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{
		CA_set_invalidCRC($tcpar_MessageName,$tcpar_Method);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		CA_set_invalidBZ($tcpar_MessageName,$tcpar_Method,$tcpar_NbOfCycles);
	}	
	
	S_set_timer_zero('fault_trigger_start'); #fault creation start reference (to be used by FM_measureTime)	
	LC_ECU_On();
	S_teststep("Measure qualification time after fault qualification", 'AUTO_NBR', 'QualificationTime_after_fault_qualification');
	S_wait_ms($fm_initqualitime);
	$measuredtime_quali_time = FM_PD_measureEndQualiDequaliTime_Init( $tcpar_faultname, 'Qualification', $FDtrace_name );

	S_teststep("Read fault recorder through PD after fault qualification", 'AUTO_NBR', 'PD_Fault_status_after_qualification');			#measurement 1
	$flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read fault recorder through CD after fault qualification", 'AUTO_NBR', 'CD_Fault_status_after_qualification');
	$flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'} = CD_read_DTC('02','08');

	S_teststep("Read the Warning lamp status after fault qualification", 'AUTO_NBR', 'WL_Status_after_qualification');
	S_w2rep("  System warning lamp value received from CAN after fault Qualification  : $sysWLAtFltQuali \n");	#Read the warning Lamp status after fault Dequalification
	($sysWLAtFltQuali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' ); 				
	FM_PD_measureTimePreparation( $tcpar_faultname, 'Dequalification' );
	
	S_w2rep("Note: For init fault evaluation, time will be measured only using PD Fast Diagnosis");
	$FDtrace_name = FM_PD_measureStartQualiDequaliTime_Init($tcpar_faultname);
	S_teststep("Switch OFF ECU and wait for '$tcpar_ECU_OFF_Time'", 'AUTO_NBR');
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_teststep("Remove COM Fault'$tcpar_COM_Fault',Switch ON ECU and wait for '$fm_initdequalitime' ", 'AUTO_NBR');
	
	if($tcpar_COM_Fault eq 'Timeout')
	{
		COM_startMessages( [$tcpar_MessageName], 'can' );
	}
	elsif($tcpar_COM_Fault eq 'InvalidSignal')
	{
		COM_setSignalState ($tcpar_signal, $tcpar_physicalValueValid, $tcpar_Protocol);
	}
	elsif($tcpar_COM_Fault eq 'CRC')
	{
		CA_set_validCRC($tcpar_MessageName);
	}
	elsif($tcpar_COM_Fault eq 'AliveCntr')
	{
		CA_set_validBZ($tcpar_MessageName);
	}	
	
	S_set_timer_zero('fault_trigger_start'); #fault removal start reference (to be used by FM_measureTime)	
	LC_ECU_On();
	S_teststep("Measure qualification time after fault qualification", 'AUTO_NBR', 'DequalificationTime_after_fault_dequalification');
	S_wait_ms($fm_initdequalitime);
	$measuredtime_dequali_time = FM_PD_measureEndQualiDequaliTime_Init( $tcpar_faultname, 'Dequalification', $FDtrace_name );
	
	S_teststep("Read fault recorder through PD after fault dequalification", 'AUTO_NBR', 'PD_Fault_status_after_dequalification');			#measurement 2
	$flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'} = PD_ReadFaultMemory();
	S_wait_ms (2000);
	S_teststep("Read fault recorder through CD after fault dequalification", 'AUTO_NBR', 'CD_Fault_status_after_dequalification');
	$flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'} = CD_read_DTC('02','08');
	
	S_teststep("Read the Warning lamp status after fault dequalification", 'AUTO_NBR', 'WL_Status_after_dequalification');
	S_w2rep("  System warning lamp value received from CAN after fault dequalification  : $sysWLAtFltDequali \n");	#Read the warning Lamp status after fault Dequalification
	($sysWLAtFltDequali,$unit) = CA_read_can_signal($tcpar_SysWL_SigLabel, 'hex' ); 
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Expected Qualificaiton time is  '$fm_initqualitime' ", 'QualificationTime_after_fault_qualification');			
	S_teststep_detected("Detected Qualificaiton time is  '$measuredtime_quali_time' ", 'QualificationTime_after_fault_qualification');
	FM_evaluateQualiDequaliTime( $tcpar_faultname, $measuredtime_quali_time, 'qualitime', $tcpar_Tolerance,$fm_initqualitime );

	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname ); 
	S_teststep_expected("Fault '$tcpar_faultname'  should have status'$tcpar_FaultQualistatus' ", 'PD_Fault_status_after_qualification');			#evaluation 1
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Fault_status_after_qualification');
	PD_check_fault_status($flt_mem_struct_pd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_FaultQualistatus);
	
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname );        
    S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Fault_status_after_qualification');
	S_teststep_expected("Fault Status read by CD: $tcpar_FaultQualistatus ", 'CD_Fault_status_after_qualification');
	CD_check_fault_status($flt_mem_struct_cd_qualification{'FaultStatus_afterQualification'}, $tcpar_faultname, $tcpar_FaultQualistatus);	
	
	S_teststep_detected("Detected Warning lamp status after qualification : $sysWLAtFltQuali  ",'WL_Status_after_qualification'); #evaluation 2
	S_teststep_expected("Expected Warning lamp status after qualification: $tcpar_WL_Faultquali ",'WL_Status_after_qualification');
	EVAL_evaluate_value( "System warning lamp status after fault qualification : ", $sysWLAtFltQuali, '==', $tcpar_WL_Faultquali );	  # Evalute the Warning Lamp
	
	S_teststep_expected("Expected Dequalificaiton time is  '$fm_initdequalitime' ", 'DequalificationTime_after_fault_dequalification');			
	S_teststep_detected("Detected Dequalificaiton time is  '$measuredtime_dequali_time' ", 'DequalificationTime_after_fault_dequalification');
	FM_evaluateQualiDequaliTime( $tcpar_faultname, $measuredtime_dequali_time, 'dequalitime', $tcpar_Tolerance,$fm_initdequalitime );
	
	$detected_PD_status = PD_get_fault_status( $flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname ); 
	S_teststep_expected("Fault '$tcpar_faultname'  should have status'$tcpar_FaultDeQualistatus' ", 'PD_Fault_status_after_dequalification');			#evaluation 1
	S_teststep_detected("Fault Status read by PD: $detected_PD_status ", 'PD_Fault_status_after_dequalification');
	PD_check_fault_status($flt_mem_struct_pd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_FaultDeQualistatus);
	
	$detected_CD_status = CD_get_fault_status( $flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname );        
    S_teststep_detected("Fault Status read by CD: $detected_CD_status ", 'CD_Fault_status_after_dequalification');
	S_teststep_expected("Fault Status read by CD: $tcpar_CDFaultDeQualistatus ", 'CD_Fault_status_after_dequalification');
	CD_check_fault_status($flt_mem_struct_cd_dequalification{'FaultStatus_afterDeQualification'}, $tcpar_faultname, $tcpar_CDFaultDeQualistatus);

	S_teststep_detected("Detected Warning lamp status after dequalification : $sysWLAtFltDequali ",'WL_Status_after_dequalification'); #evaluation 4
	S_teststep_expected("Expected Warning lamp status after dequalification: $tcpar_WL_FaultDequali ",'WL_Status_after_dequalification');
	EVAL_evaluate_value( "System warning lamp status after fault dequalification : ", $sysWLAtFltDequali, '==', $tcpar_WL_FaultDequali );	        # Evalute the Warning Lamp
	
	

	return 1;
}

sub TC_finalization {

	S_w2rep("TC FINALIZATION\n");			
	PD_ClearFaultMemory();
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}




1;
