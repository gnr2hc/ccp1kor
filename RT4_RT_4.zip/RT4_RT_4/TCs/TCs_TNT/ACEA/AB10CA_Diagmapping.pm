package LIFT_ACEA_DIAG_MAPPING;
$Mapping = {
"DID_FixedDataValue" =>
    {
#       "F1DF_ECUProgrInfor"                               => "",
    }, 
#---------------------------------------------------------------- 

"PRJ_SUPPORTED_SERVICES" => {
		"StartSession" => "10",
		"ECUReset" => "11",
		"SecurityAccess" => "27",
		"ReadDatabyID" => "22",
		"WriteDatabyID" => "2E",
		"StartRoutineControlService" => "31 01",
		"RequestRoutineResults" => "31 03",
		"TesterPresent" => "3E",
		 },
#---------------------------------------------------------------- 

"NR_ServiceNotSupported" => {
                                "Response" => "7F",
                                "Mode" => "strict",
                                "Desc" => "Service not supported"
                              },

#---------------------------------------------------------------- 

"DIAG_SERVICES" => { 
#----------------------------------------------------------------- 
		"StartSession" => {  
		"Service_ID" => "10" , 
 			"Supported_SubFuns" => { 
            "DefaultSession"                  => "01" ,
			"DisposalSession"                  => "04" ,
			 },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 10 13" , "Mode" =>  "strict" , "Desc" =>  "StartSession: incorrectMessageLengthOrInvalidFormat" , "AddrModes" => ["Physical","Functional"]},
              "NR_subFunctionNotSupported"      => { "Response" =>  "7F 10 12" , "Mode" =>  "strict" , "Desc" =>  "StartSession: subFunctionNotSupported" , "AddrModes" => ["Physical"]},
              "NR_subFunctionNotSupportedInActiveSession"      => { "Response" =>  "7F 10 7E" , "Mode" =>  "strict" , "Desc" =>  "StartSession: subFunctionNotSupportedInActiveSession" , "AddrModes" => ["Physical","Functional"]},
              "NR_conditionsNotCorrect"      => { "Response" =>  "7F 2E 22" , "Mode" =>  "strict" , "Desc" =>  "StartSession: conditionsNotCorrect" ,"AddrModes" => ["Physical","Functional"]},
			 },  
		 },   
#----------------------------------------------------------------
		"ECUReset" => {  
		"Service_ID" => "11" , 
 			"Supported_SubFuns" => { 
 			 			  "HardReset"                    => "01",
						  "HardResetsupressPOSResp"     => "81", 
								   },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 11 13" , "Mode" =>  "strict" , "Desc" =>  "ECUReset: incorrectMessageLengthOrInvalidFormat" ,"AddrModes" => ["Physical","Functional"]},
              "NR_serviceNotSupportedInActiveSession"      => { "Response" =>  "7F 11 7F" , "Mode" =>  "strict" , "Desc" =>  "ECUReset: serviceNotSupportedInActiveSession" ,},
              "NR_subFunctionNotSupported"      => { "Response" =>  "7F 11 12" , "Mode" =>  "strict" , "Desc" =>  "ECUReset: subFunctionNotSupported" ,"AddrModes" => ["Physical","Functional"]},
			 },  
		 },  
#----------------------------------------------------------------- 
		"SecurityAccess" => {  
		"Service_ID" => "27" , 
 			"Supported_SubFuns" => {
			        "RequestSeed"  => "5F",
					"SendKey"      => "60",
								   },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 27 13" , "Mode" =>  "strict" , "Desc" =>  "SecurityAccess: incorrectMessageLengthOrInvalidFormat", "AddrModes" => ["Physical","Functional"]},
              "NR_invalidKey"      => { "Response" =>  "7F 27 35" , "Mode" =>  "strict" , "Desc" =>  "SecurityAccess: invalidKey" , "AddrModes" => ["Physical","Functional"]},
              "NR_serviceNotSupportedInActiveSession"      => { "Response" =>  "7F 27 7F" , "Mode" =>  "strict" , "Desc" =>  "SecurityAccess: serviceNotSupportedInActiveSession", "AddrModes" => ["Physical","Functional"]},
              "NR_subFunctionNotSupported"      => { "Response" =>  "7F 27 12" , "Mode" =>  "strict" , "Desc" =>  "SecurityAccess: subFunctionNotSupported" , "AddrModes" => ["Physical","Functional"]},
              "NR_RequestSequenceError"      => { "Response" =>  "7F 27 24" , "Mode" =>  "strict" , "Desc" =>  "SecurityAccess: RequestSequenceError" , "AddrModes" => ["Physical","Functional"]},                        
			 },  
		 }, 
#----------------------------------------------------------------- 
		"ReadDatabyID" => {  
		"Service_ID" => "22" , 
 			"Supported_SubFuns" => { 
  			        "ReadVIN " => "F1 90",
  			        "ReadNumberOfPCU" => "FA 00",
  			        "ReadPCUHWDPLMethod " => "FA 01",					
  			        "ReadAddressInfoOfPCU" => "FA 02",
  			        "ReadDeploymentLoopTable " => "FA 06",					
					"ReadDismantlerInfo" => "FA 07",
								   },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 2E 13" , "Mode" =>  "strict" , "Desc" =>  "ReadDatabyID: incorrectMessageLengthOrInvalidFormat" ,"AddrModes" => ["Physical","Functional"]},
              "NR_requestOutOfRange"      => { "Response" =>  "7F 2E 31" , "Mode" =>  "strict" , "Desc" =>  "ReadDatabyID: requestOutOfRange" ,"AddrModes" => ["Physical","Functional"]},
			 },  
		 }, 		 
#----------------------------------------------------------------- 
		"WriteDatabyID" => {  
		"Service_ID" => "2E" , 
 			"Supported_SubFuns" => { 
  			        "WriteDismantlerInfo" => "FA 07",
								   },  
			"NEG_Responses" => { 
              "NR_conditionsNotCorrect"      => { "Response" =>  "7F 2E 22" , "Mode" =>  "strict" , "Desc" =>  "WriteDatabyID: conditionsNotCorrect" ,"AddrModes" => ["Physical","Functional"]},
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 2E 13" , "Mode" =>  "strict" , "Desc" =>  "WriteDatabyID: incorrectMessageLengthOrInvalidFormat" ,"AddrModes" => ["Physical","Functional"]},
              "NR_requestOutOfRange"      => { "Response" =>  "7F 2E 31" , "Mode" =>  "strict" , "Desc" =>  "WriteDatabyID: requestOutOfRange" ,"AddrModes" => ["Physical","Functional"]},
			 },  
		 },  
#-----------------------------------------------------------------
		"StartRoutineControlService" => {  
		"Service_ID" => "31 01" , 
 			"Supported_SubFuns" => {
  			        "ExecuteDisposalProgramLoader" => "E2 00 01",
					"DeployLoopRoutineID" => "E2 01 00",
			},  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 31 13" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: incorrectMessageLengthOrInvalidFormat" , "AddrModes" => ["Physical","Functional"]},
              "NR_requestOutOfRange"      => { "Response" =>  "7F 31 31" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: requestOutOfRange" , "AddrModes" => ["Physical","Functional"]},
              "NR_serviceNotSupportedInActiveSession"      => { "Response" =>  "7F 31 7F" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: serviceNotSupportedInActiveSession" , "AddrModes" => ["Physical","Functional"]},
              "NR_securityAccessDenied"      => { "Response" =>  "7F 31 33" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: securityAccessDenied" , "AddrModes" => ["Physical","Functional"]},
              "NR_RequestSequenceError"      => { "Response" =>  "7F 27 24" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: RequestSequenceError" , "AddrModes" => ["Physical","Functional"]},
			},  
		 },  
#-----------------------------------------------------------------
		"RequestRoutineResults" => {  
		"Service_ID" => "31 03" , 
 			"Supported_SubFuns" => {
  			        "ExecuteDisposalProgramLoader" => "E2 00",
					"DeployLoopRoutineID" => "E2 01 00",
			 },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 31 13" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: incorrectMessageLengthOrInvalidFormat" , "AddrModes" => ["Physical","Functional"]},
              "NR_requestOutOfRange"      => { "Response" =>  "7F 31 31" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: requestOutOfRange" , "AddrModes" => ["Physical","Functional"]},
              "NR_serviceNotSupportedInActiveSession"      => { "Response" =>  "7F 31 7F" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: serviceNotSupportedInActiveSession" , "AddrModes" => ["Physical","Functional"]},
              "NR_securityAccessDenied"      => { "Response" =>  "7F 31 33" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: securityAccessDenied" , "AddrModes" => ["Physical","Functional"]},
              "NR_RequestSequenceError"      => { "Response" =>  "7F 27 24" , "Mode" =>  "strict" , "Desc" =>  "RoutineControl: RequestSequenceError" , "AddrModes" => ["Physical","Functional"]},
			 },  
		 }, 		 
#----------------------------------------------------------------- 
		"TesterPresent" => {  
		"Service_ID" => "3E" , 
 			"Supported_SubFuns" => { 
					"TesterPresentPosResp"                 => "00" ,
					"TesterPresentsupressPosResp" => "80" , 
			 },  
			"NEG_Responses" => { 
              "NR_incorrectMessageLengthOrInvalidFormat"      => { "Response" =>  "7F 3E 13" , "Mode" =>  "strict" , "Desc" =>  "TesterPresent: incorrectMessageLengthOrInvalidFormat" ,"AddrModes" => ["Physical","Functional"]},
              "NR_subFunctionNotSupported"      => { "Response" =>  "7F 3E 12" , "Mode" =>  "strict" , "Desc" =>  "TesterPresent: subFunctionNotSupported" ,"AddrModes" => ["Physical","Functional"]},
			 },  
		 }, 
#----------------------------------------------------------------- 
 }, #end of DIAG_SERVICES 
 
  
 "Requests_Responses" => { 
 #----------------------------------------------------------------------------------- 
	"StartSession_DisposalSession" => {  
		"Requests" => { 
            "REQ_StartSession_DisposalSession" => { "Request" => "10 04"},
				 },  
		"POS_Responses" => { 
            "PR_StartSession_DisposalSession"    => { "Response" =>  "50 04 00 32 01 F4" , "Mode" =>  "strict" , "Desc" =>  "Start Session: StartSession_DefaultSession" , "DataLength" => "" , "DoorsIDs" => [ "" ]},
				 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
		 },		 
 #----------------------------------------------------------------------------------- 
	"StartSession_DefaultSession" => {  
		"Requests" => { 
            "REQ_StartSession_DefaultSession" => { "Request" => "10 01"},
				 },  
		"POS_Responses" => { 
            "PR_StartSession_DefaultSession"    => { "Response" =>  "50 01 00 32 01 F4" , "Mode" =>  "strict" , "Desc" =>  "Start Session: StartSession_DefaultSession" , "DataLength" => "" , "DoorsIDs" => [ "" ]},
				 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 				 
		 },  
#----------------------------------------------------------------------------------- 
	"StartSession_DefaultSessionSupressPOSResp" => {  
		"Requests" => { 
            "REQ_StartSession_DefaultSessionSupressPOSResp" => { "Request" => "10 81"},
				 },  
		"POS_Responses" => { 
            "PR_StartSession_DefaultSessionSupressPOSResp"    => { "Response" =>  undef , "Mode" =>  "quiet" , "Desc" =>  "Start Session: StartSession_DefaultSession_supressPOSResp" , "DataLength" => "" , "DoorsIDs" => [ "" ]},
				 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 				 
		 }, 
 #------------------------------------------------------------------- 
	"ECUReset_HardReset" => {  
                "Requests" => { 
            "REQ_ECUReset_HardReset"       =>  { 'Request' => "11 01" },
                 },  
                "POS_Responses" => { 
              "PR_ECUReset_HardReset"      => { "Response" =>  "51 01" , "Mode" =>  "strict" , "Desc" =>  "PR: ECU Reset Hard Reset" , "DoorsIDs" => [ "" ]},
                 }, 
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  
#------------------------------------------------------------------- 
	"ECUReset_HardResetSupressPOSResp" => {  
                "Requests" => { 
                        "REQ_ECUReset_HardResetSupressPOSResp"       =>  { 'Request' => "11 81" },
                 },  
                "POS_Responses" => { 
                    "PR_ECUReset_HardResetSupressPOSResp"      => { "Response" =>  undef , "Mode" =>  "quiet" , "Desc" =>  "PR: ECU Reset Hard Reset suppress positive response" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  
#------------------------------------------------------------------- 
	"SecurityAccess_RequestSeed" => {  
                "Requests" => { 
					"REQ_SecurityAccess_RequestSeed"       =>  { 'Request' => "27 5F" },
                 },  
                "POS_Responses" => { 
                    "PR_SecurityAccess_RequestSeed"      => { "Response" =>  "67 5F" , "Mode" =>  "relax" , "Desc" =>  "PR: Security Access - Request Seed" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         }, 
#------------------------------------------------------------------- 
	"SecurityAccess_SendKey" => {  
                "Requests" => { 
					"REQ_SecurityAccess_SendKey"     => { 'Request' => "27 60 Key" },
                 },  
                "POS_Responses" => { 
                    "PR_SecurityAccess_SendKey"      => { "Response" =>  "67 60" , "Mode" =>  "strict" , "Desc" =>  "PR: Security Access - Send Seed" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadVIN" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadVIN"       =>  { 'Request' => "22 F1 90" } ,
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadVIN"      => { "Response" =>  "62 F1 90 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D 2D" , "Mode" =>  "strict" , "Desc" =>  "PR: Read Data by ID - Read VIN" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadNumberOfPCU" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadNumberOfPCU"       =>  { 'Request' => "22 FA 00" },
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadNumberOfPCU"      => { "Response" =>  "62 FA 00 01" , "Mode" =>  "strict" , "Desc" =>  "PR: Read Data by ID - Read Number Of PCU" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         }, 		 
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadPCUHWDPLMethod" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadPCUHWDPLMethod"        =>  { 'Request' => "22 FA 01" },
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadPCUHWDPLMethod"      => { "Response" =>  "62 FA 01 01 50 43 55 20 56 57 32 36 58" , "Mode" =>  "strict" , "Desc" =>  "PR: Read Data by ID - Read PCU HW DPL Method" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         }, 
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadAddressInfoOfPCU" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadAddressInfoOfPCU"       =>  { 'Request' => "22 FA 02"},
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadAddressInfoOfPCU"      => { "Response" =>  "62 FA 02 01 00 00 07 F1 00 00 07 F9" , "Mode" =>  "strict" , "Desc" =>  "PR: Read Data by ID - SRead Address Info Of PCU" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadDeploymentLoopTable" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadDeploymentLoopTable"       =>  { 'Request' => "22 FA 06"},
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadDeploymentLoopTable"      => { "Response" =>  "62 FA 06" , "Mode" =>  "relax" , "Desc" =>  "PR: Read Data by ID - Read Deployment Loop Table" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },  		 
#------------------------------------------------------------------- 
	"ReadDatabyID_ReadDismantlerInfo" => {  
                "Requests" => { 
					"REQ_ReadDatabyID_ReadDismantlerInfo"       =>  { 'Request' => "22 FA 07"},
                 },  
                "POS_Responses" => { 
                    "PR_ReadDatabyID_ReadDismantlerInfo"      => { "Response" =>  "62 FA 07" , "Mode" =>  "relax" , "Desc" =>  "PR: Read Data by ID - Read Dismantler Info" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },
#------------------------------------------------------------------- 
	"WriteDatabyID_WriteDismantlerInfo" => {  
                "Requests" => { 
					"REQ_WriteDatabyID_WriteDismantlerInfo"       =>  { 'Request' => "2E FA 07 DismantlerInfo"},
                 },  
                "POS_Responses" => { 
                    "PR_WriteDatabyID_WriteDismantlerInfo"      => { "Response" =>  "6E FA 07" , "Mode" =>  "strict" , "Desc" =>  "PR: Write Data by ID - Write Dismantler Infon" ,},
                 },  
                "NEG_Responses" => { 
                    "NR_WriteDatabyID_WriteDismantlerInfo_conditionsNotCorrect"      => { "Response" =>  "7F 2E 22" , "Mode" =>  "strict" , "Desc" =>  "NR: Write Data by ID - Write Dismantler Infon" ,},
                 },  				 
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },		 
#------------------------------------------------------------------- 
	"StartRoutineControlService_ExecuteDisposalProgramLoader" => {  
                "Requests" => { 
					"REQ_RoutineControl_StartRoutine_ExecuteDisposalProgramLoader"       =>  { 'Request' => "31 01 E2 00 RoutineControlOption"},
                 },  
                "POS_Responses" => { 
                    "PR_RoutineControl_StartRoutine_ExecuteDisposalProgramLoader"      => { "Response" =>  "71 01 E2 00 00 RoutineControlOption" , "Mode" =>  "strict" , "Desc" =>  "PR: Start Routine Control Service - Execute Disposal Program Loader" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },	
#------------------------------------------------------------------- 
	"StartRoutineControlService_DeployLoopRoutineID" => {  
                "Requests" => { 
					"REQ_RoutineControl_StartRoutine_DeployLoopRoutineID"       =>  { 'Request' => "31 01 E2 01 LoopId"} ,
                 },  
                "POS_Responses" => { 
                    "PR_RoutineControl_StartRoutine_DeployLoopRoutineID"      => { "Response" =>  "71 01 E2 01 00 LoopId" , "Mode" =>  "relax" , "Desc" =>  "PR: Start Routine Control Service - Deploy Loop Routine ID" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },	
#------------------------------------------------------------------- 
	"RequestRoutineResults_ExecuteDisposalProgramLoader" => {  
                "Requests" => { 
					"REQ_RequestRoutineResults_ExecuteDisposalProgramLoader"       =>  { 'Request' => "31 03 E2 00"},
                 },  
                "POS_Responses" => { 
                    "PR_RequestRoutineResults_ExecuteDisposalProgramLoader"      => { "Response" =>  "71 03 E2 00 01" , "Mode" =>  "strict" , "Desc" =>  "PR: Request Routine Results - Execute Disposal Program Loader" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },			 
#------------------------------------------------------------------- 
	"RequestRoutineResults_DeployLoopRoutineID" => {  
                "Requests" => { 
					"REQ_RoutineControl_ReqRoutineResult_DeployLoopRoutineID"       =>  { 'Request' => "31 03 E2 01 LoopId"},
                 },  
                "POS_Responses" => { 
                    "PR_RoutineControl_ReqRoutineResult_DeployLoopRoutineID"      => { "Response" =>  "71 03 E2 01 00 LoopId" , "Mode" =>  "relax" , "Desc" =>  "PR: Request Routine Results - Deploy Loop Routine ID" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },		
#------------------------------------------------------------------- 
	"TesterPresent_TesterPresentPosResp" => {  
                "Requests" => { 
					"REQ_TesterPresent_TesterPresentPosResp"       =>  { 'Request' => "3E 00" },
                 },  
                "POS_Responses" => { 
                    "PR_TesterPresent_TesterPresentPosResp"      => { "Response" =>  "7E 00" , "Mode" =>  "Strict" , "Desc" =>  "PR: Tester Present - Positive Response" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },			 
#------------------------------------------------------------------- 
	"TesterPresent_TesterPresentSupressPosResp" => {  
                "Requests" => { 
					"REQ_TesterPresent_TesterPresentSupressPosResp"       =>  { 'Request' => "3E 80" },
                 },  
                "POS_Responses" => { 
                    "PR_TesterPresent_TesterPresentSupressPosResp"      => { "Response" =>  undef , "Mode" =>  "quiet" , "Desc" =>  "PR: Tester Present - Supress Positive Response" ,},
                 },  
		"allowed_in_sessions" => [  "DefaultSession" , "safetySystemDiagnosticSession"] ,    				 
         },


		 
  }, #end of Request_Responses  
 
}; # end of ACEA DIAG mapping
1;