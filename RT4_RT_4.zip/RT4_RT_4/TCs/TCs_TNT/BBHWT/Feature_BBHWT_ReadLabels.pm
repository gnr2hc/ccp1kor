#### TEST CASE MODULE
package Feature_BBHWT_ReadLabels;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: BBHWT/Feature_BBHWT_ReadLabels.pm 1.2 2018/01/19 00:14:25ICT Okrusch Thomas (CC-PS/EPS2) (OUT2SI) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use INCLUDES_Project;
use LIFT_evaluation;
use LIFT_DCOM;
use LIFT_TSG4; #necessary
#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

Feature_BBHWT_ReadLabels

=head1 PURPOSE

Feature_BBHWT_ReadLabels

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Nothing done here


I<B<Stimulation and Measurement>>

1.If its Type1 Read squib values 

2.If its Type2 Read Switch values


I<B<Evaluation>>

Nothing done here

I<B<Finalisation>>

Nothing done here


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'Label' => 
	SCALAR 'Type' => 
	SCALAR 'Device' => 
	SCALAR 'Value' => 
	SCALAR 'UpperLimit' => 
	SCALAR 'LowerLimit' => 


=head2 PARAMETER EXAMPLES

	#TurboLift_Parameters
	Type=1
	Device= AB1FD
	Value =13.6
	UpperLimit =0 
	LowerLimit =0

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_Type;
my $tcpar_Label;
my $tcpar_Device;
my $tcpar_Value;
my $tcpar_UpperLimit;
my $tcpar_LowerLimit;
my $DeviceWaitTime = 2000;
################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_Label =  GEN_Read_optional_testcase_parameter( 'Label' );
    $tcpar_Device =  GEN_Read_mandatory_testcase_parameter( 'Device' );
	$tcpar_Type =  GEN_Read_optional_testcase_parameter( 'Type' );
	$tcpar_Value =  GEN_Read_optional_testcase_parameter( 'Value' );
	$tcpar_UpperLimit =  GEN_Read_optional_testcase_parameter( 'UpperLimit' );
	$tcpar_LowerLimit =  GEN_Read_optional_testcase_parameter( 'LowerLimit' );

	return 1;
}

sub TC_initialization {
    S_wait_ms('TIMER_ECU_READY');
	return 1;
}

sub TC_stimulation_and_measurement {

    my @SQ_val;
    
    if ($tcpar_Type == 1){
	GEN_printTestStep("Step 1.If its Type1 Read squib values ");
   
    push (@SQ_val, @{PD_ReadMemoryByName ($tcpar_Label)}); 
    if($main::opt_offline){
            @SQ_val = (0,0);
    }
    #temp fix
    my $temp = $SQ_val[1];
    $SQ_val[1] = $SQ_val[0];
    $SQ_val[0] = $temp;
    my $detected_value = S_aref2dec ( \@SQ_val, U16 );
    
    EVAL_evaluate_interval ( "Evaluate squib resistance" ,$tcpar_LowerLimit , $tcpar_UpperLimit , $detected_value  );
    }
    elsif ($tcpar_Type == 2){    
        GEN_printTestStep("Step 2.If its Type2 Read Switch values");
        DEVICE_setDeviceCurrent ($tcpar_Device,$tcpar_Value);
        S_wait_ms( $DeviceWaitTime,"Wait after SwitchValue is set" ); 
        push (@SQ_val, @{PD_ReadMemoryByName ($tcpar_Label)}); 
        if($main::opt_offline){
            @SQ_val = (0,0);
        }
        #temp fix
        my $temp = $SQ_val[1];
        $SQ_val[1] = $SQ_val[0];
        $SQ_val[0] = $temp;
        my $detected_value = S_aref2dec ( \@SQ_val, U16 );
        
        EVAL_evaluate_interval ( "Evaluate Switch resistance" ,$tcpar_LowerLimit , $tcpar_UpperLimit , $detected_value  );
    }
    else{
   # TSG4_CloseHW();
    }
	return 1;
}

sub TC_evaluation {
    S_set_verdict(VERDICT_PASS);
	return 1;
}

sub TC_finalization {

	return 1;
}


1;
