#### TEST CASE MODULE
package TC_DIS_WrongISODisposalKey;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_Disp_Disposal
#TS version in DOORS: 3.93
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use GENERIC_DCOM;
use LIFT_can_access;
use LIFT_evaluation;
use LIFT_labcar;

##################################

our $PURPOSE = "To check critical commands are not downloaded to RAM area, when decryption key is not correct";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_WrongISODisposalKey

=head1 PURPOSE

To check critical commands are not downloaded to RAM area, when decryption key is not correct'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation
2. Send Tester Present Cyclically


I<B<Stimulation and Measurement>>

1. Enter Disposal Session

2. Request for seed 

3. Send Invalid decryption key to get ISO disposal security access

4. Enable Saftey Path

5. Check Critical commands stored in RAM.


I<B<Evaluation>>

1. Disposal Session Entered

2. Seed Obtained

3. Expected Resp_Key

4. SPL Executed

5. Critical commands should not be stored in RAM


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Session' => Session to be entered
	SCALAR 'Resp_Key' => Response of the security access



=head2 PARAMETER EXAMPLES

	purpose  = 'To check critical commands are not downloaded to RAM area, when decryption key is not correct'
	
	Session = 'DisposalSession'
	Resp_Key = 'NR_invalidKey'


=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session;
my $tcpar_Resp_Key;

################ global parameter declaration ###################
#add any global variables here
my $TP_handle;
my %ExecuteSPL_With_Conversion;
my ( $Decrypted_RAM_Data, $Resp_Seed, $Key, %Wrong_Key, $Resp_Key );
my $key1;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose  = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Session  = S_read_mandatory_testcase_parameter('Session');
	$tcpar_Resp_Key = S_read_mandatory_testcase_parameter('Resp_Key');

	return 1;
}

sub TC_initialization {

	S_w2rep("Start of Precondition");
	
	S_w2rep("Standard Preparation");
	GEN_StandardPrepNoFault();
	
	S_w2rep("Set addressing mode");
	GDCOM_set_addressing_mode("disposal");
	
	S_w2rep("Send Tester Present Cyclically");	
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Enter '$tcpar_Session'",'AUTO_NBR','STEP_1');
	S_wait_ms(10000); #To make sure ECU is not in initialization phase
	GDCOM_StartSession($tcpar_Session);
	
	S_teststep("Request for seed",'AUTO_NBR','STEP_2');
	$Resp_Seed = ACEA_RequestSeed();
	my @Response = split( ' ', $Resp_Seed );
	my $Seed = $Response[2] . ' ' . $Response[3];
	
	S_teststep("Send Invalid decryption key to get ISO disposal security access.",'AUTO_NBR','STEP_3');
	$Key = ACEA_CalculateKey($Seed);
	GEN_printTestStep("Key= $Key");
	$Key='FE 57';	
	$Wrong_Key{'Key'} =$Key;
	GDCOM_request_general ("REQ_SecurityAccess_CD_SendKey", "NR_invalidKey", \%Wrong_Key,"");
	
	S_teststep("Enable Saftey Path",'AUTO_NBR','STEP_4');
	$ExecuteSPL_With_Conversion{'RoutineControlOption'} = 01;
	GDCOM_request_general ("REQ_RoutineControl_StartRoutine_ExecuteDisposalProgramLoader", "NR_securityAccessDenied",\%ExecuteSPL_With_Conversion,"");
	
	S_teststep("Check Critical commands stored in RAM.",'AUTO_NBR','STEP_5');
	$Decrypted_RAM_Data = ACEA_ReadDecryptedCommandsInRAM();

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("Evaluation for Request and Response is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_1');
	S_teststep_detected("Evaluation for Request and Response is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_1');

	S_teststep_expected("Evaluation for Seed is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_2');
	S_teststep_detected("Evaluation for Seed is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_2');

	S_teststep_expected("Evaluation for Key - '$tcpar_Resp_Key' is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_3');
	S_teststep_detected("Evaluation for Key - '$tcpar_Resp_Key' is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_3');

	S_teststep_expected("Evaluation for SPL Execution is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_4');
	S_teststep_detected("Evaluation for SPL Execution is done at Stimulation and Measurement Refer the html report or traces \n",'STEP_4');
	
	ACEA_EvaluateDecryptedCommandsInRAM( $Decrypted_RAM_Data, 'ZERO' );
	S_teststep_expected("Critical commands stored in RAM should be Zero \n",'STEP_5');
	S_teststep_detected("Detected Critical commands stored in RAM is : $Decrypted_RAM_Data\n",'STEP_5');

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
