#### TEST CASE MODULE
package TC_DIS_ACLType;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_labcar;

##################################

our $PURPOSE = "Verification of ACL type";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_ACLType

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation

2. Send tester present continously


I<B<Stimulation and Measurement>>

1. Send <Request> to read deployment loop table


I<B<Evaluation>>

1. ACL type should be reported as  <ACLType_Value> in 4th byte of <Response>.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Request' => 
	SCALAR 'Response' => 
	SCALAR 'ACLType_Value' => 


=head2 PARAMETER EXAMPLES

	purpose  = 'Verification of ACL type'
	Request ='REQ_ReadDatabyID_ReadDeploymentLoopTable'
	Response='PR_ReadDatabyID_ReadDeploymentLoopTable'
	ACLType_Value=<Fetch {V_DevBoard_IntegrationPath}>

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Request;
my $tcpar_Response;
my $tcpar_ACLType_Value;


################ global parameter declaration ###################
#add any global variables here
my $TP_handle;
my $Resp_ReadDLT;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response' );
	$tcpar_ACLType_Value =  S_read_mandatory_testcase_parameter( 'ACLType_Value' );

	return 1;
}

sub TC_initialization {	
	
	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	
	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");
	
	S_w2rep("Enter into safety system diagnostic session\n");
	GDCOM_StartSession('DisposalSession');
	
	S_w2rep("Send tester present continously");	
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Send '$tcpar_Request' to read deployment loop table", 'AUTO_NBR', 'send_request_to');			#measurement 1
	$Resp_ReadDLT = ACEA_Read_DiploymentLoopTable();

	return 1;
}

sub TC_evaluation {

	my @Obtained_Response = split( / /, "$Resp_ReadDLT" );
	S_teststep_expected("ACL type should be reported as  '$tcpar_ACLType_Value' in 4th byte of '$tcpar_Response'.", 'send_request_to');			#evaluation 1
	S_teststep_detected("Detected Value is $Obtained_Response[3]", 'send_request_to');
	if ($Obtained_Response[3] eq $tcpar_ACLType_Value )
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}

	return 1;
}

sub TC_finalization {

	ACEA_Stop_TesterPresent($TP_handle);
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
