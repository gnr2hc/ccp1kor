#### TEST CASE MODULE
package TC_DIS_FaultsSteppingDown;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_Disp_Disposal
#TS version in DOORS: 3.82
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_labcar;
##################################

our $PURPOSE = "check the fault handing during the same power on cycle";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_FaultsSteppingDown

=head1 PURPOSE

check the fault handing during the same power on cycle

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation


I<B<Stimulation and Measurement>>

1. Read RAM_Variable Dem_AllEventsState(Fault_Number).debounceLevel  

2. Reset ECU

3.Read RAM_Variable Dem_AllEventsState(Fault_Number).debounceLevel 


I<B<Evaluation>>

1.  <Fault> should be in <value>

2.

3. <Fault> should be step down from 0 to <Value>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Fault_Number' => Fault number	
	SCALAR 'Fault' => Fault name	
	SCALAR 'Fault_Value' => Value of ram variable


=head2 PARAMETER EXAMPLES

	purpose='check the fault handing during the same power on cycle.'
	Fault_Number='88'
	Fault='rb_dmim_DeploymentInProgress_flt'
	Fault_Value='-32768'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Fault_Number;
my $tcpar_Fault;
my $tcpar_Fault_Value;

################ global parameter declaration ###################
my ( $Faultmemorystate, $Fault_Value, $Fault_Value_Init, $Fault_Value_AfterInit,$verdict );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose      = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Fault_Number = S_read_mandatory_testcase_parameter('Fault_Number');
	$tcpar_Fault        = S_read_mandatory_testcase_parameter('Fault');
	$tcpar_Fault_Value  = S_read_mandatory_testcase_parameter('Fault_Value');

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Read RAM_Variable Dem_AllEventsState(Fault_Number)debounceLevel ",'AUTO_NBR','STEP_1');
	$Fault_Value = S_aref2dec( PD_ReadMemoryByName("Dem_AllEventsState($tcpar_Fault_Number).debounceLevel"),U8 );
	
	S_teststep("Reset ECU",'AUTO_NBR','STEP_2');
	GEN_Power_on_Reset ('NO_WAIT');
	S_wait_ms(1500,"Wait till Communication is Established");
	S_teststep("Read RAM_Variable Dem_AllEventsState(Fault_Number)debounceLevel ",'AUTO_NBR','STEP_3');
	$Fault_Value_Init = S_aref2dec( PD_ReadMemoryByName("Dem_AllEventsState($tcpar_Fault_Number).debounceLevel"),U8 );
	S_wait_ms(5000,"Wait till Fault is step down");#Wait time for Fault to step down
	$Fault_Value_AfterInit = S_aref2dec( PD_ReadMemoryByName("Dem_AllEventsState($tcpar_Fault_Number).debounceLevel"),U8 );

	return 1;
}

sub TC_evaluation {


	S_w2rep("Evaluation for Default Dem_AllEventsState(Fault_Number)debounceLevel");
	$verdict = EVAL_evaluate_value( "Default Fault Value", $Fault_Value, '==', $tcpar_Fault_Value );
	S_teststep_expected(" Default Fault Value is $tcpar_Fault_Value \n ", 'STEP_1');
	if($verdict eq 'VERDICT_PASS' )
	{
		S_teststep_detected( "Default Fault Value is $Fault_Value\n" ,'STEP_1');
	}

	if($verdict eq 'VERDICT_FAIL' )
	{
		S_teststep_detected( "MISMATCH: Default Fault Value is $Fault_Value\n" ,'STEP_1');
	}
	
	
	S_w2rep("Reset ECU");
	S_teststep_expected("No Evaluation \n",'STEP_2');
	S_teststep_detected("No Evaluation \n",'STEP_2');
	
	S_w2rep("Evaluation for RAM_Variable Dem_AllEventsState(Fault_Number)debounceLevel during and after init");
	$verdict = EVAL_evaluate_value( "Fault value during init", $Fault_Value_Init,      '<=', 0 );
	S_teststep_expected(" Fault value during init is 0 \n ", 'STEP_3');
	if($verdict eq 'VERDICT_PASS' )
	{
		S_teststep_detected( "Fault value during init is $Fault_Value_Init\n" ,'STEP_3');
	}

	if($verdict eq 'VERDICT_FAIL' )
	{
		S_teststep_detected( "MISMATCH: Fault value during init is $Fault_Value_Init\n" ,'STEP_3');
	}
	
	
	$verdict = EVAL_evaluate_value( "Fault value after init",  $Fault_Value_AfterInit, '==', $tcpar_Fault_Value );
	S_teststep_expected(" Fault value after init is $tcpar_Fault_Value \n ", 'STEP_3');
	if($verdict eq 'VERDICT_PASS' )
	{
		S_teststep_detected( "Fault value after init is $Fault_Value_AfterInit\n" ,'STEP_3');
	}

	if($verdict eq 'VERDICT_FAIL' )
	{
		S_teststep_detected( "MISMATCH: Fault value after init is $Fault_Value_AfterInit\n" ,'STEP_3');
	}

	return 1;
}

sub TC_finalization {

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

1;
