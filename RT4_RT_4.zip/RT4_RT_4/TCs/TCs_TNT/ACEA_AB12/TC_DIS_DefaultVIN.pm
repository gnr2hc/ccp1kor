#### TEST CASE MODULE
package TC_DIS_DefaultVIN;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_DISP_Disposal
#TS version in DOORS: 3.104
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; 
use GENERIC_DCOM ;
use LIFT_labcar;

##################################

our $PURPOSE = "Verify that default VIN will be reported if VIN information is not available";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DIS_DefaultVIN

=head1 PURPOSE

Verify that default VIN will be reported if VIN information is not available

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

1. Standard_Preparation

2. Send tester present continously

3. Set <Condition>


I<B<Stimulation and Measurement>>

1. Enter Diagnostic session

2. Read VIN using <Request>

1. Send <Request_LoopTable> to read deployment loop table


I<B<Evaluation>>

2. <Response> obtained

3. <Response_LoopTable> obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Test case purpose to be provide
	SCALAR 'Request' => Request to be set
	SCALAR 'Condition' => Condtion to be set
	SCALAR 'Response' => Response to be set
	SCALAR 'Request_LoopTable' => Request of loop table to be set
	SCALAR 'Response_LoopTable' =>  Response of loop table to be set


=head2 PARAMETER EXAMPLES

	purpose  = 'Verify that default VIN will be reported if VIN information is not available'
	Request='REQ_ReadDatabyID_ReadVIN'
	Condition='NormalVIN'
	Response='PR_ReadDatabyID_ReadVIN'
	Request_LoopTable='REQ_ReadDatabyID_ReadDeploymentLoopTable'
	Response_LoopTable='PR_ReadDatabyID_ReadDeploymentLoopTable'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Request;
my $tcpar_Condition;
my $tcpar_Response;
my $tcpar_Request_LoopTable;
my $tcpar_Response_LoopTable;
my @tcpar_VIN_Bytes = 0;
my $tcpar_Protocol;
my $tcpar_VINmessage;

################ global parameter declaration ###################
#add any global variables here
my $TP_handle;
my $Resp_ReadVIN;
my $Resp_ReadDLT;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  S_read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Request =  S_read_mandatory_testcase_parameter( 'Request' );
	$tcpar_Condition =  S_read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Response =  S_read_mandatory_testcase_parameter( 'Response' );
	$tcpar_Request_LoopTable =  S_read_mandatory_testcase_parameter( 'Request_LoopTable' );
	$tcpar_Response_LoopTable =  S_read_mandatory_testcase_parameter( 'Response_LoopTable' );
	$tcpar_VINmessage = S_read_mandatory_testcase_parameter( 'VINmessage' );
	$tcpar_Protocol = S_read_mandatory_testcase_parameter( 'Protocol' );
	@tcpar_VIN_Bytes =  S_read_mandatory_testcase_parameter( 'VIN_Bytes' );

	return 1;
}

sub TC_initialization {

	S_w2rep("Standard_Preparation");
	GEN_StandardPrepNoFault();
	
	S_w2rep("Set Addressing Mode");
	GDCOM_set_addressing_mode("disposal");
	
	S_w2rep("Send tester present continously");	
	$TP_handle = ACEA_Send_TesterPresent_Cyclically();	

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Enter Diagnostic Session", 'AUTO_NBR');			
	GDCOM_StartSession('DisposalSession');
	
	S_teststep("Set '$tcpar_Condition'", 'AUTO_NBR');
	if($tcpar_Condition = 'DefaultVIN')
	{
		COM_stopMessages( [$tcpar_VINmessage], $tcpar_Protocol );
		S_wait_ms('TIMER_ECU_READY');
	}
	
	S_teststep("Read VIN using '$tcpar_Request'", 'AUTO_NBR', 'read_vin_using');			#measurement 1
	$Resp_ReadVIN = ACEA_Read_VIN();

	S_teststep("Send '$tcpar_Request_LoopTable' to read deployment loop table", 'AUTO_NBR', 'send_request_looptable');			#measurement 2
	$Resp_ReadDLT = ACEA_Read_DiploymentLoopTable();
	
	return 1;
}

sub TC_evaluation {

	my @Obtained_Response = split( / /, "$Resp_ReadVIN" );
	if (@Obtained_Response eq @tcpar_VIN_Bytes)
	{
		S_set_verdict('VERDICT_PASS');
	}
	else
	{
		S_set_verdict('VERDICT_FAIL'); 
	}	
	S_teststep_expected("'@tcpar_VIN_Bytes' obtained", 'read_vin_using');			#evaluation 1
	S_teststep_detected("Detected Response is @Obtained_Response ", 'read_vin_using');

	S_teststep_expected(" $tcpar_Response_LoopTable Postive Response should obtained",'send_request_looptable'); #evaluation 2
	S_teststep_detected(" Detected Response is $Resp_ReadDLT ",'send_request_looptable');

	return 1;
}

sub TC_finalization {
	ACEA_Stop_TesterPresent($TP_handle);
	
	if($tcpar_Condition = 'DefaultVIN')
	{
		COM_startMessages( [$tcpar_VINmessage], $tcpar_Protocol );
		S_wait_ms('TIMER_ECU_READY');
	}
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}


1;
