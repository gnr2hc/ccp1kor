# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

#### TEST CASE MODULE
package TC_FL_Range;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Firing_Loops
#TS version in DOORS: 6.4
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_TEMPERATURE;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = " test that the ECU is able to measure the squib resistance in the requested range and that a fault is stored if the resistance value is outside the given range";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

RB_voltage_file 

=head1 PURPOSE

 test that the ECU is able to measure the squib resistance in the requested range and that a fault is stored if the resistance value is outside the given range

=head1 TESTCASE DESCRIPTION

[parameter used]

    Testcase Parameter:
    Pin
	ThresholdLow 
	ThresholdHigh
	Ubat
	FLTmandLow
	FLTmandHigh

    [initialisation]
    get temperature
    UZ on with U_batt_default
    clear fault memory

    [stimulation & measurement]
	1. switch ECU on
	
	2. apply value below lower threshold
	3. erase fault recorder
	4. wait for qualification
	5. read fault recorder
	6. evaluate fault recorder
	
	7. apply value above lower threshold
	8. erase fault recorder
	9. wait for qualification
	10. read fault recorder
	11. evaluate fault recorder
	
	12. apply value below higher threshold
	13. erase fault recorder
	14. wait for qualification
	15. read fault recorder
	16. evaluate fault recorder
	
	17. apply value above higher threshold
	18. erase fault recorder
	19. wait for qualification
	20. read fault recorder
	21. evaluate fault recorder

    [evaluation]

	6. check that expected fault is stored
	
	11. check that no fault is present
	
	16. check that no fault is present 
	
	21. check that expected fault is stored

    [finalisation]
    remove fault
    switch ECU off


=head1 PARAMETER

=head2 PARAMETER NAMES

	SCALAR 'Pin'		 --> ECU pin
	SCALAR 'Ubat'        --> battery voltage value
	LIST FLTmandLow		 --> list of mandatory faults for Squib Resistance short (logical names)
	LIST FLTmandHigh	 --> list of mandatory faults for Squib Resistance open  (logical names)
    
=head2 PARAMETER EXAMPLES

[TC_FL_Range.BT1FD] 
purpose='$check test pulses for BT1FD' 
Ubat=14.5
Pin='BT1FD'
FLTmandLow=@('rb_sqm_SquibResistanceShortBT1FD_flt')
FLTmandHigh=@('rb_sqm_SquibResistanceOpenBT1FD_flt')
    
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

my (
	$tcpar_ubat,                  $tcpar_pin,                   $tcpar_FLTmandLow,         $tcpar_FLTmandHigh,        $result,                       $tcpar_Threshold,             $fltmem1,                    $fltmem2,
	$fltmem3,                     $fltmem4,                     $calc_array_idx,           $asic_connection,          $asic_connectionCBR,           $asic_connectionIGH,          $asic_connectionIGL,         $diagSimType,
	$tcpar_ResistanceDefault_Ohm, $cableInherentResistance_Ohm, $tcpar_ResistanceLowerThd, $tcpar_ResistanceUpperThd, $tcpar_ResistanceHighLowerThd, $tcpar_ResistanceLowUpperThd, $tcpar_ResistanceOkLowerThd, $tcpar_ResistanceOkUpperThd,
);
my $offsetResistanceThreshold = 0.2;
my $offsetResistanceRange     = 0.3;
my @temperatures              = ();

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
sub TC_set_parameters {

	$tcpar_ubat        = GEN_Read_mandatory_testcase_parameter('Ubat');
	$tcpar_pin         = GEN_Read_mandatory_testcase_parameter('Pin');
	$tcpar_FLTmandLow  = GEN_Read_optional_testcase_parameter( 'FLTmandLow', 'byref' );
	$tcpar_FLTmandHigh = GEN_Read_optional_testcase_parameter( 'FLTmandHigh', 'byref' );

	( $result, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL ) = SYC_SQUIB_get_ASIC_connection($tcpar_pin);
	return 0 unless $result;

	( $result, $tcpar_ResistanceLowerThd ) = SYC_SQUIB_get_ResistanceLowerThd_NOERROR($tcpar_pin);
	my $result_threshold += $result;
	( $result, $tcpar_ResistanceUpperThd ) = SYC_SQUIB_get_ResistanceUpperThd_NOERROR($tcpar_pin);
	$result_threshold += $result;

	( $result, $tcpar_ResistanceLowUpperThd ) = SYC_SQUIB_get_ResistanceLowUpperThd_NOERROR($tcpar_pin);
	my $result_range += $result;
	( $result, $tcpar_ResistanceOkLowerThd ) = SYC_SQUIB_get_ResistanceOkLowerThd_NOERROR($tcpar_pin);
	$result_range += $result;
	( $result, $tcpar_ResistanceOkUpperThd ) = SYC_SQUIB_get_ResistanceOkUpperThd_NOERROR($tcpar_pin);
	$result_range += $result;
	( $result, $tcpar_ResistanceHighLowerThd ) = SYC_SQUIB_get_ResistanceHighLowerThd_NOERROR($tcpar_pin);
	$result_range += $result;

	if ( $result_threshold == 2 ) {
		$tcpar_ResistanceDefault_Ohm  = ( $tcpar_ResistanceLowerThd + $tcpar_ResistanceUpperThd ) / 2;
		$tcpar_ResistanceHighLowerThd = $tcpar_ResistanceUpperThd + $offsetResistanceThreshold;
		$tcpar_ResistanceOkUpperThd   = $tcpar_ResistanceUpperThd - $offsetResistanceThreshold;
		$tcpar_ResistanceOkLowerThd   = $tcpar_ResistanceLowerThd + $offsetResistanceThreshold;
		$tcpar_ResistanceLowUpperThd  = $tcpar_ResistanceLowerThd - $offsetResistanceThreshold;
	}
	elsif ( $result_range == 4 ) {
		$tcpar_ResistanceHighLowerThd = $tcpar_ResistanceHighLowerThd + $offsetResistanceRange;
		$tcpar_ResistanceOkUpperThd   = $tcpar_ResistanceOkUpperThd - $offsetResistanceRange;
		$tcpar_ResistanceOkLowerThd   = $tcpar_ResistanceOkLowerThd + $offsetResistanceRange;
		$tcpar_ResistanceLowUpperThd  = $tcpar_ResistanceLowUpperThd - $offsetResistanceRange;
		$tcpar_ResistanceDefault_Ohm  = ( $tcpar_ResistanceOkUpperThd + $tcpar_ResistanceOkLowerThd ) / 2;
	}
	else {
		S_set_error("Either 'ResistanceLowerThd', 'ResistanceUpperThd' or 'ResistanceLowUpperThd', 'ResistanceOkLowerThd', 'ResistanceOkUpperThd', 'ResistanceHighLowerThd' have to be defined in SYC.");
		return 0;
	}

	$tcpar_FLTmandLow  = [ "rb_sqm_SquibResistanceShort" . $tcpar_pin . "_flt" ] unless defined $tcpar_FLTmandLow;
	$tcpar_FLTmandHigh = [ "rb_sqm_SquibResistanceOpen" . $tcpar_pin . "_flt" ]  unless defined $tcpar_FLTmandHigh;

	if ( PD_GetAddressByName_NOERROR_NOHTML("rb_sqmm_ResistanceValue_au16(0)(0)") ne '0x1' ) {
		$diagSimType = 3;
	}
	else {
		$diagSimType = 2;
	}

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {

	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ECUlogin();
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	push( @temperatures, TEMP_get_temperature() );
	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

############################################################################### Expected Fault
	S_teststep( 'Switch ECU on.', 'AUTO_NBR' );
	LC_ECU_On($tcpar_ubat);

	S_teststep( 'Wait for end of initialization', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Set Resistance of '$tcpar_pin' to $tcpar_ResistanceDefault_Ohm Ohm (corrected)", 'AUTO_NBR' );
	$cableInherentResistance_Ohm = GetCableInherentResistance();
	S_teststep( "Calculate the inherent resistance of the harness for squib '$tcpar_pin' and evaluate the range", 'AUTO_NBR', 'cabelInherentResistance' );

	return unless defined $cableInherentResistance_Ohm;

	PD_GetExtendedFaultInformation();

	S_teststep( 'Apply value below lower threshold', 'AUTO_NBR' );
	S_teststep_2nd_level( "Set Resistance of '$tcpar_pin' to '$tcpar_ResistanceLowUpperThd' Ohm (corrected)", 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceLowUpperThd - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem1 = PD_GetExtendedFaultInformation();
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'BelowLow' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceDefault_Ohm - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	PD_GetExtendedFaultInformation();
	PD_ClearFaultMemory();
	S_wait_ms(500);
	PD_ClearFaultMemory();

############################################################################### No fault Expected
	S_teststep( 'Apply value above lower threshold', 'AUTO_NBR' );
	S_teststep_2nd_level( "Set Resistance of '$tcpar_pin' to '$tcpar_ResistanceOkLowerThd' Ohm (corrected)", 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceOkLowerThd - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem2 = PD_GetExtendedFaultInformation();
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'AboveLow' );

	S_wait_ms(500);
	PD_ClearFaultMemory();

############################################################################### No fault Expected

	S_teststep( 'Apply value below higher threshold', 'AUTO_NBR' );
	S_teststep_2nd_level( "Set Resistance of '$tcpar_pin' to '$tcpar_ResistanceOkUpperThd' Ohm (corrected)", 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceOkUpperThd - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem3 = PD_GetExtendedFaultInformation();
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'BelowHigh' );

	S_wait_ms(500);
	PD_ClearFaultMemory();

############################################################################### Expected Fault

	S_teststep( 'Apply value above higher threshold', 'AUTO_NBR' );
	S_teststep_2nd_level( "Set Resistance of '$tcpar_pin' to '$tcpar_ResistanceHighLowerThd' Ohm (corrected)", 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceHighLowerThd - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault qualification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Read fault recorder', 'AUTO_NBR' );
	$fltmem4 = PD_GetExtendedFaultInformation();
	S_teststep_2nd_level( 'Evaluate fault recorder', 'AUTO_NBR', 'AboveHigh' );

	S_teststep_2nd_level( 'Remove fault', 'AUTO_NBR' );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceDefault_Ohm - $cableInherentResistance_Ohm );
	S_wait_ms(500);
	GetECUInternalResistance();

	S_teststep_2nd_level( 'Wait for fault dequalification time', 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_FAULT_QUALIFICATION');

	S_teststep_2nd_level( 'Erase fault recorder', 'AUTO_NBR' );
	PD_GetExtendedFaultInformation();
	PD_ClearFaultMemory();
	S_wait_ms(500);
	PD_ClearFaultMemory();

	S_teststep( 'Switch ECU off', 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}
#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep_expected( 'inherent resistance: 0.2 Ohm < x < 0.8 Ohm', 'cabelInherentResistance' );
	S_teststep_detected( "inherent resistance: $cableInherentResistance_Ohm", 'cabelInherentResistance' );
	EVAL_evaluate_interval( "cabelInherentResistance", 0.2, 0.8, $cableInherentResistance_Ohm );

	S_teststep_expected( 'Expected faults: (BelowLow)', 'BelowLow' );
	foreach my $fault ( @{$tcpar_FLTmandLow} ) {
		S_teststep_expected($fault);
	}

	S_teststep_detected( 'Detected faults: (BelowLow)', 'BelowLow' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem1, $tcpar_FLTmandLow );

	S_teststep_expected( 'Expected faults: (AboveLow)', 'AboveLow' );
	S_teststep_detected( 'Detected faults: (AboveLow)', 'AboveLow' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem2, [], [] );

	S_teststep_expected( 'Expected faults: (BelowHigh)', 'BelowHigh' );
	S_teststep_detected( 'Detected faults: (BelowHigh)', 'BelowHigh' );
	foreach my $fault ( @{ $fltmem3->{fault_text} } ) {
		S_teststep_detected($fault);
	}

	PD_evaluate_faults( $fltmem3, [], [] );

	S_teststep_expected( 'Expected faults: (AboveHigh)', 'AboveHigh' );
	foreach my $fault ( @{$tcpar_FLTmandHigh} ) {
		S_teststep_expected($fault);
	}
	S_teststep_detected( 'Detected faults: (AboveHigh)', 'AboveHigh' );
	foreach my $fault ( @{ $fltmem4->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem4, $tcpar_FLTmandHigh );

	return 1;
}

#### TC FINALIZATION #####
#-- set system in original state --##
sub TC_finalization {

	LC_SetResistance( $tcpar_pin, 'DEFAULT' );

	S_teststep_detected( "TEMP: " . join( ' -> ', @temperatures ) );
	S_teststep_detected("UBat: $tcpar_ubat V");

	return 1;
}

sub GetCableInherentResistance {

	S_w2log( 3, "Set Resistance of $tcpar_pin to $tcpar_ResistanceDefault_Ohm Ohm." );
	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceDefault_Ohm );
	S_wait_ms(500);

	my $resistanceECUinternal_before = GetECUInternalResistance();
	my $cableInherentResistance = sprintf( "%.1f", $resistanceECUinternal_before - $tcpar_ResistanceDefault_Ohm );
	S_w2log( 3, "Calculated inherent resistance of the harness cable: $cableInherentResistance" );

	LC_SetResistance( $tcpar_pin, $tcpar_ResistanceDefault_Ohm - $cableInherentResistance );
	S_wait_ms(500);

	my $resistanceECUinternal_after;

	for ( 1 .. 10 ) {
		$resistanceECUinternal_after = GetECUInternalResistance();
		last if ( abs( $resistanceECUinternal_before - $resistanceECUinternal_after - $cableInherentResistance ) < 0.2 );
		S_wait_ms(500);
	}

	return 0 if $main::opt_offline;

	# check that internal SW value is updated when changing TSG4 resistance
	if ( abs( $resistanceECUinternal_before - $resistanceECUinternal_after - $cableInherentResistance ) > 0.2 ) {
		my $nbr1 = $asic_connectionCBR - 1;
		my $nbr2 = $asic_connectionIGH - 1;
		S_set_error("Resistance changes for squib '$tcpar_pin' are not visible in corresponding PD variable 'rb_sqmm_ResistanceValue_au16($nbr1)($nbr2)'.") if ( $diagSimType == 3 );
		S_set_error("Resistance changes for squib '$tcpar_pin' are not visible in corresponding PD variable 'rb_sqmm_ResistanceValue_au16($calc_array_idx)'.") unless ( $diagSimType == 3 );

		return;
	}

	return $cableInherentResistance;
}

sub GetECUInternalResistance {
	my ( $label, $type, $calcResistance_Ohm );

	if ( $diagSimType == 3 ) {
		my $nbr1 = $asic_connectionCBR - 1;
		my $nbr2 = $asic_connectionIGH - 1;

		$label = "rb_sqmm_ResistanceValue_au16($nbr1)($nbr2)";
	}
	else {
		$label = "rb_sqmm_ResistanceValue_au16($calc_array_idx)";
	}

	my $filename = "$main::REPORT_PATH/" . S_get_TC_number() . "_TC_FL_Range_" . S_get_TC_parameter_name();
	$type = PD_get_type_from_name($label);

	PD_StartFastDiagName( $filename, [$label], [$type] );

	S_wait_ms(1000);

	PD_StopFastDiag();

	my $fd_data = PD_get_FDtrace($filename);
	PD_plot_FDtrace( $fd_data, $filename );

	my @values = EVAL_get_values_over_time( $fd_data, $label );

	my $sum;
	foreach (@values) { $sum += $_; }
	my $mean = $sum / @values;

	$calcResistance_Ohm = $mean / 100;

	S_w2log( 3, "Internal Resistance: $calcResistance_Ohm" );

	return $calcResistance_Ohm;
}

1;

__END__
	
	
