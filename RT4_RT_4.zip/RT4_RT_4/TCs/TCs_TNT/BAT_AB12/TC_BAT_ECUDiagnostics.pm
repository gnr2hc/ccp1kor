#### TEST CASE MODULE
package TC_BAT_ECUDiagnostics;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER =
q$Header: BAT_AB12/TC_BAT_ECUDiagnostics.pm 1.4 2018/10/10 14:21:19ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 0.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_CD;
use LIFT_labcar;
use LIFT_evaluation;
use GENERIC_DCOM;
use LIFT_PD;
use FuncLib_TNT_GEN;
##################################

our $PURPOSE = "To check the basic customer diagnostic functionality";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_ECUDiagnostics

=head1 PURPOSE

to check the basic customer diagnostic functionality

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Read the fault memory using Customer Diagnostics (19 02 08)

2. De-configure a <Squib> (say AB1FD) and wait for <Quali_time_ms>.

3. Read the fault memory using Customer Diagnostics (19 02 08)

4. Re-configure the <Squib>, wait for <DeQuali_time_ms>

5. Clear the Fault memory using Customer Diagnostics by sending <Request_clearDTC> (14 FF FF FF)

6. Reset the ECU using Customer Diagnostics (11 01) 

7. After initialization, read the fault memory using Customer Diagnostics (19 02 08)


I<B<Evaluation>>

1. No DTCs are reported in the response (fault memory is empty)

2.

3. <Fault_name> is reported in response with the fault status byte as <Quali_status>.

4.

5. Clear happens successfully (Positive response is obtained)

6.

7. No DTCs are reported in the response (fault memory is empty)


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Squib' => 
	SCALAR 'Quali_time_ms' => 
	SCALAR 'Fault_name' => 
	SCALAR 'Quali_status' => 
	SCALAR 'DeQuali_time_ms' => 
	SCALAR 'Request_clearDTC' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check the basic customer diagnostic functionality'
	
	Squib = AB1FD
	Quali_time_ms = 2000
	Fault_name = 'rb_sqm_SquibResistanceOpenAB1FD_flt'
	Quali_status = '0xAF'
	DeQuali_time_ms = 2000
	Request_clearDTC = 'ClearDTCInformation_ClearDTCAll'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Squib;
my $tcpar_Quali_time_ms;
my $tcpar_Fault_name;
my $tcpar_Quali_status;
my $tcpar_DeQuali_time_ms;
my $tcpar_Request_clearDTC;

################ global parameter declaration ###################
#add any global variables here
my ( $DTC_struct1, $DTC_struct2, $DTC_struct3 );
my $response_aref;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose 			= S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Squib   			= S_read_mandatory_testcase_parameter('Squib');
	$tcpar_Quali_time_ms 	= S_read_mandatory_testcase_parameter('Quali_time_ms');
	$tcpar_Fault_name       = S_read_mandatory_testcase_parameter('Fault_name');
	$tcpar_Quali_status 	= S_read_mandatory_testcase_parameter('Quali_status');
	$tcpar_DeQuali_time_ms 	= S_read_mandatory_testcase_parameter('DeQuali_time_ms');
	$tcpar_Request_clearDTC = S_read_mandatory_testcase_parameter('Request_clearDTC');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Read the fault memory using Customer Diagnostics (19 02 08)", 'AUTO_NBR', 'read_the_fault_A' );    #measurement 1
	$DTC_struct1 = CD_read_DTC( '02', '08' );
	my $DTC1 = ( $DTC_struct1->{"DTC"} );
	my @detected_DTC1;
	foreach (@$DTC1) {
		push( @detected_DTC1, $_ );
	}
	S_teststep_expected( "No DTCs are reported in the response (fault memory is empty)", 'read_the_fault_A' );                #evaluation 1
	S_teststep_detected( "Detected DTC: '@detected_DTC1'", 'read_the_fault_A' );
	CD_evaluate_faults( $DTC_struct1, [] );

	S_teststep( "De-configure a '$tcpar_Squib' and wait for '$tcpar_Quali_time_ms'.", 'AUTO_NBR' );
	PD_Device_configuration( "clear", [$tcpar_Squib]);
	S_wait_ms(8000);

	S_teststep( "Read the fault memory using Customer Diagnostics (19 02 08)", 'AUTO_NBR', 'read_the_fault_B' );    #measurement 2
	$DTC_struct2 = CD_read_DTC( '02', '08' );
	my $status = CD_get_fault_status( $DTC_struct2, $tcpar_Fault_name );
	S_teststep_expected( "'$tcpar_Fault_name' is reported in response with the fault status byte as '$tcpar_Quali_status'", 'read_the_fault_B' );                                       #evaluation 2
	S_teststep_detected( "Detected $tcpar_Fault_name with fault state is '$status'", 'read_the_fault_B' );
	EVAL_evaluate_value( "Fault Status", $status, '==', $tcpar_Quali_status );

	S_teststep( "Re-configure the '$tcpar_Squib', wait for '$tcpar_DeQuali_time_ms'", 'AUTO_NBR' );
	PD_Device_configuration( "set", [$tcpar_Squib]  );
	S_wait_ms(8000);

	S_teststep( "Clear the Fault memory using Customer Diagnostics by sending '$tcpar_Request_clearDTC' (14 FF FF FF)", 'AUTO_NBR', 'clear_the_fault' );    #measurement 3
	$response_aref = GDCOM_request( '14 FF FF FF', '54', 'relax' );
	S_teststep_expected( "Clear happens successfully (Positive response is obtained)", 'clear_the_fault' );    #evaluation 3
	S_teststep_detected( "Detected response is: '$response_aref'", 'clear_the_fault' );

	S_teststep( "Reset the ECU using Customer Diagnostics (11 01) ", 'AUTO_NBR' );
	GDCOM_request( '10 03', '50 03', 'relax' );
	GDCOM_request( '11 01', '51 01', 'relax' );
	S_wait_ms ('TIMER_ECU_READY', 'wait after reset');

	S_teststep( "After initialization, read the fault memory using Customer Diagnostics (19 02 08)", 'AUTO_NBR', 'after_initialization_read' );    #measurement 4
	$DTC_struct3 = CD_read_DTC( '02', '08' );
	my $DTC3 = ( $DTC_struct3->{"DTC"} );
	my @detected_DTC3;
	foreach (@$DTC3) {
		push( @detected_DTC3, $_ );
	}
	S_teststep_expected( "No DTCs are reported in the response (fault memory is empty)", 'after_initialization_read' );    #evaluation 4
	S_teststep_detected( "Detected DTC: '@detected_DTC3'", 'after_initialization_read' );
	CD_evaluate_faults( $DTC_struct3, [] );

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	return 1;
}

1;
