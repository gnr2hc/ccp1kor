# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: BAT_AB12/TC_BAT_plantmode_7.pm $
#    $Revision: 1.2 $
#    $Author: Phan Khanh Duy (RBVH/EPS24) (PDA1HC) $
#    $State: develop $
#    $Date: 2018/10/10 14:21:18ICT $
#******************************************************************************************************

#### TEST CASE MODULE
package TC_BAT_plantmode_7;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_plantmode_7.pm 1.2 2018/10/10 14:21:18ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_Feature_Plant
#TS version in DOORS: 1.x
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use File::Basename;
use File::Copy;
use FuncLib_TNT_GEN;
use PD;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "check plant mode 7: electronic firing mode";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_plantmode_7

=head1 PURPOSE

check plant mode 7: electronic firing mode

=head1 TESTCASE DESCRIPTION

This script is based on 

I<B<Initialisation>>

PROD_Standard_Preparation


Set <TestCondition>


I<B<Stimulation and Measurement>>



I<B<Evaluation>>






I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################
my ( $tcpar_FLTmandPMInactive, $tcpar_FLToptPMInactive, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );
my ( $tcpar_Ubat_V,            $tcpar_PinACL,           $tcpar_SourceACL );
my ( $result,                  $master_asic_type_aref,  $slave1_asic_type_aref, $slave2_asic_type_aref );

################ global parameter declaration ###################
#add any global variables here
my $plantmode7_set  = 0b01000000;
my $plantmode_clear = 0b00000000;
my $timePrepare_ms  = 2500;
my $data_aref;
my ( $data_plant_aref, $data_plant_href );
my ( $fltmem );
my ( $squibsMasterAsic,   $squibsSlave1Asic, $squibsSlave2Asic );
my ( $deploy_flag_mode );
my ( $diagsymType );

###############################################################

sub TC_set_parameters {
	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_PinACL            = S_read_optional_testcase_parameter('PinACL');
	$tcpar_SourceACL         = S_read_optional_testcase_parameter('SourceACL');
	$tcpar_FLTmandPMInactive = S_read_mandatory_testcase_parameter('FLTmandPMInactive');
	$tcpar_FLToptPMInactive  = S_read_optional_testcase_parameter('FLToptPMInactive');
	$tcpar_FLTmandPMActive   = S_read_mandatory_testcase_parameter('FLTmandPMActive');
	$tcpar_FLToptPMActive    = S_read_optional_testcase_parameter('FLToptPMActive');

	( $result, $master_asic_type_aref ) = SYC_SYSTEMASIC_get_MasterAsicType();
	if    ( $master_asic_type_aref eq 'CG904' ) { $squibsMasterAsic = 16; }
	elsif ( $master_asic_type_aref eq 'CG903' ) { $squibsMasterAsic = 12; }
	elsif ( $master_asic_type_aref eq 'CG902' ) { $squibsMasterAsic = 8; }
	elsif ( $master_asic_type_aref eq 'CG912' ) { $squibsMasterAsic = 4; }
	else {
		$squibsMasterAsic = 0;
		S_w2rep( "Unknown type of Master System ASIC '$master_asic_type_aref' specified in SYC.\n", 'blue' );
		S_set_verdict("VERDICT_INCONC");
	}
	( $result, $slave1_asic_type_aref ) = SYC_SYSTEMASIC_get_Slave1AsicType();
	if    ( $slave1_asic_type_aref eq 'CG904' ) { $squibsSlave1Asic = 16; }
	elsif ( $slave1_asic_type_aref eq 'CG903' ) { $squibsSlave1Asic = 12; }
	elsif ( $slave1_asic_type_aref eq 'CG902' ) { $squibsSlave1Asic = 8; }
	elsif ( $slave1_asic_type_aref eq 'CG912' ) { $squibsSlave1Asic = 4; }
	else                                        { $squibsSlave1Asic = 0; }
	( $result, $slave2_asic_type_aref ) = SYC_SYSTEMASIC_get_Slave2AsicType();
	if    ( $slave2_asic_type_aref eq 'CG904' ) { $squibsSlave2Asic = 16; }
	elsif ( $slave2_asic_type_aref eq 'CG903' ) { $squibsSlave2Asic = 12; }
	elsif ( $slave2_asic_type_aref eq 'CG902' ) { $squibsSlave2Asic = 8; }
	elsif ( $slave2_asic_type_aref eq 'CG912' ) { $squibsSlave2Asic = 4; }
	else                                        { $squibsSlave2Asic = 0; }

	$diagsymType = 0;
	if ( PD_GetAddressByName_NOERROR_NOHTML("rb_sqmm_ResistanceValue_au16(0)(0)") ne '0x1' ) {
		$diagsymType = 3;
	}
	else {
		$diagsymType = 2;
	}

	return 1;
}

sub TC_initialization {

	S_teststep( "Initialize ECU", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "PD Clear FaultMemory\n", 'blue' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "Power OFF the ECU\n", 'blue' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_w2rep( "Switch ECU on with Ubat = $tcpar_Ubat_V V\n", 'blue' );
	LC_ECU_On($tcpar_Ubat_V);
	S_wait_ms('TIMER_ECU_READY');
	
	S_w2rep( "PD Get Extended Fault Information\n", 'blue' );
	PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set plantmode", 'AUTO_NBR' );
	PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode7_set] );

	S_teststep( "Do reset", 'AUTO_NBR' );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Check if plantmode is activated", 'AUTO_NBR', 'mode_active' );
	$data_plant_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	$data_plant_href = PD_ReadLampStates();

	S_teststep("Connect ACL", 'AUTO_NBR' );
	if ( defined $tcpar_PinACL ) {
		S_teststep( "Send Disposal PWM on PIN '$tcpar_PinACL'.", 'AUTO_NBR' );
		LC_ConnectLine($tcpar_PinACL);
		LC_SendPWMDisposalStart($tcpar_PinACL) unless $tcpar_SourceACL eq 'external';
	}
	else
	{
		S_w2rep("ACL should be connected (manually) with ACL box (https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/ACL-Simulator)");
	}

	S_teststep( "Prepare electronic firing using RB PD.", 'AUTO_NBR' );
	S_wait_ms(100);
	PD_Prepare_electronic_firing();
	S_wait_ms($timePrepare_ms);

	S_teststep( "Trigger electronic firing using RB PD.", 'AUTO_NBR' );
	PD_Trigger_electronic_firing();
	S_teststep( "Check if deployment happened", 'AUTO_NBR', 'mode7_active' );

	$deploy_flag_mode = 0;
	if ( $diagsymType == 2 ) {
		foreach my $SQnr ( 0 .. ( $squibsMasterAsic + $squibsSlave1Asic + $squibsSlave2Asic - 1 ) ) {
			$data_aref = PD_ReadMemoryByName("rb_sqmf_Firecounter_au16($SQnr)");
			$deploy_flag_mode++ if ( $$data_aref[0] > 0 or $$data_aref[1] > 0 );
		}
	}
	else {
		foreach my $SQnr ( 0 .. ( $squibsMasterAsic - 1 ) ) {
			$data_aref = PD_ReadMemoryByName("rb_sqmf_Firecounter_au16(0)($SQnr)");
			$deploy_flag_mode++ if ( $$data_aref[0] > 0 or $$data_aref[1] > 0 );
		}
		if ( $squibsSlave1Asic > 0 ) {
			foreach my $SQnr ( 0 .. ( $squibsSlave1Asic - 1 ) ) {
				$data_aref = PD_ReadMemoryByName("rb_sqmf_Firecounter_au16(1)($SQnr)");
				$deploy_flag_mode++ if ( $$data_aref[0] > 0 or $$data_aref[1] > 0 );
			}
		}
		if ( $squibsSlave2Asic > 0 ) {
			foreach my $SQnr ( 0 .. ( $squibsSlave2Asic - 1 ) ) {
				$data_aref = PD_ReadMemoryByName("rb_sqmf_Firecounter_au16(2)($SQnr)");
				$deploy_flag_mode++ if ( $$data_aref[0] > 0 or $$data_aref[1] > 0 );
			}
		}
	}

	S_teststep( "Check that fault according to deployment is qualified", 'AUTO_NBR', 'checkFaultPMActive' );
	$fltmem = PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Plant mode 7 == $plantmode7_set", 'mode_active' );
	S_teststep_detected( "Plant mode 7 is $$data_plant_aref[0]", 'mode_active' );
	EVAL_evaluate_value( "Plant mode 7 active", $$data_plant_aref[0], '==', $plantmode7_set );

	S_teststep_expected( "WL == On" . "\n", 'mode_active' );
	S_teststep_detected( "WL is $data_plant_href->{'System Warning Lamp'}" . "\n", 'mode_active' );
	EVAL_evaluate_string( "WL active", 'On', $data_plant_href->{'System Warning Lamp'} );

	S_teststep_expected( "Deployed squibs > 0" . "\n", 'mode7_active' );
	S_teststep_detected( "Deployed squibs = $deploy_flag_mode" . "\n", 'mode7_active' );
	EVAL_evaluate_value( "Deployed squibs", $deploy_flag_mode, '>', 0 );

	S_teststep_expected( 'Expected faults:', 'checkFaultPMActive' );
	foreach my $fault (@$tcpar_FLTmandPMActive) {
		S_teststep_expected($fault);
	}
	S_teststep_detected( 'Detected faults:', 'checkFaultPMActive' );
	foreach my $fault ( @{ $fltmem->{fault_text} } ) {
		S_teststep_detected($fault);
	}
	PD_evaluate_faults( $fltmem, $tcpar_FLTmandPMActive, $tcpar_FLToptPMActive );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deactivate plantmode", 'AUTO_NBR' );

	#    PD_ECUlogin();
	PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [$plantmode_clear] );
	PD_ECUreset();
	S_wait_ms('TIMER_ECU_READY');

	$data_aref = PD_ReadMemoryByName('rb_sycg_ActivePlantModes_au8(0)');
	EVAL_evaluate_value( "Plant mode inactive", $$data_aref[0], '==', $plantmode_clear );
	LC_ECU_Off();

	return 1;
}

1;
