#### TEST CASE MODULE
package TC_BAT_itm_states;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.8 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_itm_states.pm 1.8 2018/07/19 16:02:34ICT ver6cob develop  $;


#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

##################################

our $PURPOSE = "check init test manager states and timing";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_itm_states $Revision: 1.8 $

=head1 PURPOSE

check init test manager states and timing

=head1 TESTCASE DESCRIPTION

	if 'plant_modes_active'
		HW reset
		set plantmodes 1,3,5,6,10,12,14,13, (2,11) in panel mode
		disconnect all external devices (will not work on PeriBox)
	
	HW reset
	wait TIMER_ECU_READY
	read ITM started, finished, failed, skipped and time

	if 'plant_modes_active' skip evaluation of ITM skipped
	evaluate ITM values:
		skipped and failed = 0
		started = finished = all configured tests (calculated from rb_itm_TestMax_e)

sets Jenkins to YELLOW if failed

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

    SCALAR 'plant_modes_active'     --> decide if plantmode will be activated before ITM check

=head2 PARAMETER EXAMPLES

	[TC_BAT_itm_states.plant]
	purpose  = 'check ITM in plant mode'
	plant_modes_active   = 1 

	[TC_BAT_itm_states.normal]
	purpose  = 'check ITM in normal mode'
	plant_modes_active   = 0 

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_plant_modes_active ;
################ global parameter declaration ###################
#add any global variables here
my ($started,$skipped,$failed,$finished,$time,$expected_states,@DEVICEnames);


###############################################################

sub TC_set_parameters {
	$tcpar_plant_modes_active = S_read_testcase_parameter( 'plant_modes_active' );
	unless( defined $tcpar_plant_modes_active){
		$tcpar_plant_modes_active = 0;
		S_w2rep("parameter '$tcpar_plant_modes_active' not given, taking default 0.\n",'blue');
	}

	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'", 114 ) unless (defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'});
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'});
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'});

	#U_BATT_DEFAULT
	#TIMER_ECU_READY
	#TIMER_ECU_OFF

    return 1;
}

sub TC_initialization {

	if ($tcpar_plant_modes_active){
		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');
		PD_ECUlogin();
		S_w2rep("set plantmodes 1,3,5,6,10,12,14,13, (2,11) in panel mode\n");

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00110101] );
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [0b00111010] );

	    S_teststep( "disconnect all squibs, belt locks, warning lamps and PAS lines and do HW reset", 'AUTO_NBR' );
	    LC_ECU_Off();
	    S_wait_ms('TIMER_ECU_OFF');
	    @DEVICEnames = LC_Get_names('SQUIBS');
	    push( @DEVICEnames, LC_Get_names('BELT_LOCKS') );
	    push( @DEVICEnames, LC_Get_names('PAS_LINES') );
	    push( @DEVICEnames, LC_Get_names('WARNING_LAMPS') );
	    foreach my $device (@DEVICEnames) {
	        LC_DisconnectLine($device);
	    }

	}

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

    return 1;
}

sub TC_stimulation_and_measurement {
	my $data_aref;
	
	S_teststep( "Read the ITM test status", 'AUTO_NBR' );
	S_teststep_2nd_level("Test Started", 'AUTO_NBR', 'test_started');
    $data_aref = PD_ReadMemoryByName("rb_itm_TestStarted_u64");
    $started = S_aref2hex($data_aref);
	
	S_teststep_2nd_level("Test Finished", 'AUTO_NBR', 'test_finished');
    $data_aref = PD_ReadMemoryByName("rb_itm_TestFinished_u64");
    $finished = S_aref2hex($data_aref);
	
	S_teststep_2nd_level("Test Failed", 'AUTO_NBR', 'test_failed');
    $data_aref = PD_ReadMemoryByName("rb_itm_TestFailed_u64");
    $failed = S_aref2hex($data_aref);
	
	S_teststep_2nd_level("Test Skipped", 'AUTO_NBR', 'test_skipped');
    $data_aref = PD_ReadMemoryByName("rb_itm_TestSkipped_u64");
    $skipped = S_aref2hex($data_aref);
	
	S_teststep_2nd_level("End Of Itm Timestamp", 'AUTO_NBR', 'EndOfItmTimestamp');
    $data_aref = PD_ReadMemoryByName("rb_itm_EndOfItmTimestamp_u32");
    $time = S_aref2dec($data_aref, 'U32');

	my $bitcount = Get_ITMmax_from_CNS();

	S_w2rep("started: $started, finished: $finished, failed : $failed, skipped : $skipped, time = $time us, bits = $bitcount\n");

	$expected_states = Get_string_from_bitcount($bitcount);
    PD_ReadFaultMemory();

    return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Started = $finished", 'test_started' );
	S_teststep_detected( "Started = $started", 'test_started' );
	EVAL_evaluate_string ('started=finished',  $finished, $started);
	
	S_teststep_expected( "Finished = $expected_states", 'test_finished' );
	S_teststep_detected( "Finished = $finished", 'test_finished' );
	EVAL_evaluate_string ('all tests finished', $expected_states, $finished);
	
	S_teststep_expected( "Failed = 0x0000000000000000", 'test_failed' );
	S_teststep_detected( "Failed = $failed", 'test_failed' );
	EVAL_evaluate_string ('0 failed',   '0x0000000000000000', $failed);

	if ($tcpar_plant_modes_active){
		S_teststep_expected( "Skipped tests are not checked in plantmode", 'test_skipped' );
		S_teststep_detected( "Skipped = $skipped", 'test_skipped' );
	}
	else{
		EVAL_evaluate_string ('0 skipped',  '0x0000000000000000', $skipped);
		S_teststep_expected( "Skipped = 0x0000000000000000", 'test_skipped' );
		S_teststep_detected( "Skipped = $skipped", 'test_skipped' );
	}

	S_w2rep("empty fault memory is precondition for timing check",'blue');
	my $flt_aref = PD_ReadFaultMemory(1);

	my $timeout_us = 4000000;
	if ($tcpar_plant_modes_active){
		S_w2rep("timeout for ITM in plant mode is 10 s\n",'blue');
		$timeout_us = 10000000;
	}
	else{
		S_w2rep("timeout for ITM in normal mode is 4 s\n",'blue');
	}
	
	S_teststep_expected( "ITM time < $timeout_us us", 'EndOfItmTimestamp' );
	S_teststep_detected( "ITM time = $time us", 'EndOfItmTimestamp' );
	EVAL_evaluate_value ( "time not exceeded", $time, '<', $timeout_us );

	S_w2rep("LIFT_SET_JENKINS_STATUS_YELLOW since ITM states or timing are not behaving correctly",'blue') if (S_get_current_verdict ( ) eq VERDICT_FAIL);

    return 1;
}

sub TC_finalization {

	if ($tcpar_plant_modes_active){
		S_w2rep("clear plantmodes\n");

		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0] );
		PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [0] );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
	    S_teststep( "re-connect all devices", 'AUTO_NBR' );
	    foreach my $device (@DEVICEnames) {
	        LC_ConnectLine($device);
	    }
		LC_ECU_On('U_BATT_DEFAULT');
		S_wait_ms('TIMER_ECU_READY');
	}

    return 1;
}

sub Get_string_from_bitcount {
	my $bitcount = shift;

	#convert number of ones to U64 value
	my $nibbles = int($bitcount/4);
	my $bits = $bitcount%4;
	my $num = 2**($bits)-1;

	#S_w2rep("bitcount $bitcount, nibbles $nibbles, bits $bits, num $num\n");
	my $values = join ('',$num,('F') x $nibbles);
	my $text = sprintf("0x%016s",$values);

	S_w2rep(" $bitcount ones converted to $text\n");

    return $text;
}

sub Get_ITMmax_from_CNS {
	my $max = 0;

	my $sadFile    = $LIFT_config::SAD_file;
    my $cnsFile = $sadFile;
    $cnsFile =~ s/\.sad$/.cns/i;
    $cnsFile =~ s/\//\\/g;
    unless ( open( CNS, "<$cnsFile" ) )
    {
        S_set_error( "Cannot open CNS file $cnsFile: $!.\nHint: The CNS file must be in the same folder and have the same name (except extension) as the SAD file.", 5 );
        return 0;
    }
    my @lines = <CNS>;
    close(CNS);

    foreach my $line (@lines) {
		if ( $line =~ /^enum;rb_itm_InitialTest_ten;rb_itm_TestMax_e;(\d+);(.*)\s*$/ ) {
			$max = $1;
			last;
        }
    }

	S_w2rep("scanning CNS: rb_itm_TestMax_e is $max\n");

    return $max;
}



1;
