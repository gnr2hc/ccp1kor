#### TEST CASE MODULE
package TC_BAT_idlemode;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_idlemode.pm 1.3 2018/07/19 16:02:34ICT ver6cob develop  $;


#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;

use constant IDLEMODE_VALUE => 4;
##################################

our $PURPOSE = "check for no idle mode";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_idlemode $Revision: 1.3 $

=head1 PURPOSE

check for no idle mode

=head1 TESTCASE DESCRIPTION

read rb_bswm_ActualSystemMode_au16(0) and chek if it is not 4 (idle mode), 

set fail depending if fail_on_idle is true (1), default is false

sets Jenkins to RED if failed

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    SCALAR 'fail_on_idle'     --> decide if verdict will be set on idlemode, default is 0

=head2 PARAMETER EXAMPLES

    [TC_BAT_idlemode.fail_on_idle]
    purpose      = 'fail if idle mode detected'
    fail_on_idle = 1

    [TC_BAT_idlemode.no_verdict]
    purpose      = 'read idle mode state, but no verdict change'
    fail_on_idle = 0

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_fail_on_idle;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_fail_on_idle = S_read_testcase_parameter( 'fail_on_idle' );
	unless( defined $tcpar_fail_on_idle){
		$tcpar_fail_on_idle = 0;
		S_w2rep("parameter 'fail_on_idle' not given, taking default 0.\n",'blue');
	}

	S_set_error( "'U_BATT_DEFAULT' not found in Project Defaults 'VEHICLE'", 114 ) unless (defined $main::ProjectDefaults->{'VEHICLE'}{'U_BATT_DEFAULT'});
	S_set_error( "'TIMER_ECU_OFF' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_OFF'});
	S_set_error( "'TIMER_ECU_READY' not found in Project Defaults 'TIMER'", 114 ) unless (defined $main::ProjectDefaults->{'TIMER'}{'TIMER_ECU_READY'});

    return 1;
}

sub TC_initialization {

    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On('U_BATT_DEFAULT');
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();
    S_w2rep("set verdict PASS to have a test result\n");
    S_set_verdict( VERDICT_PASS );
    return 1;
}

sub TC_stimulation_and_measurement {

	# check for 'no idlemode
	S_teststep( "Read rb_bswm_ActualSystemMode_au16(0) to check for no idle mode", 'AUTO_NBR', 'read_sys_mode' );
	# rb_bswm_ActualSystemMode_au16[0] = 0x04 -> idle mode
	my $data_aref = PD_ReadMemoryByName( 'rb_bswm_ActualSystemMode_au16(0)' );
	my $value = S_aref2dec($data_aref, 'U16');
	
	S_teststep_expected( "ActualSystemMode is not equal to 4", 'read_sys_mode' );
	S_teststep_detected( "ActualSystemMode is $value", 'read_sys_mode' );

	S_w2rep("system is in idlemode ($value)",'red') if (hex($value) == IDLEMODE_VALUE);

	if ($tcpar_fail_on_idle){
		EVAL_evaluate_value ( "NO IdleMode", $value, '!=', '0x04' );
		S_w2rep("LIFT_SET_JENKINS_STATUS_RED since ECU is in idle mode",'blue') if (hex($value) == IDLEMODE_VALUE);
	}

	PD_ECUlogin();
	my $fltmem = PD_GetExtendedFaultInformation();
	
	S_teststep( "Reset ECU", 'AUTO_NBR' );
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');
    PD_ECUlogin();

	S_teststep( "Read rb_bswm_ActualSystemMode_au16(0) after reset to check for no idle mode", 'AUTO_NBR', 'read_sys_mode_reset' );
	$data_aref = PD_ReadMemoryByName( 'rb_bswm_ActualSystemMode_au16(0)' );
	$value = S_aref2dec($data_aref, 'U16');
	
	S_teststep_expected( "ActualSystemMode is not equal to 4", 'read_sys_mode_reset' );
	S_teststep_detected( "ActualSystemMode is $value", 'read_sys_mode_reset' );
	S_w2rep("system is in idlemode ($value)",'red') if (hex($value) == IDLEMODE_VALUE);

	if ($tcpar_fail_on_idle){
		EVAL_evaluate_value ( "NO IdleMode", $value, '!=', IDLEMODE_VALUE );
		S_w2rep("LIFT_SET_JENKINS_STATUS_RED since ECU is in idle mode",'blue') if (hex($value) == IDLEMODE_VALUE);
	}

	$fltmem = PD_GetExtendedFaultInformation();

    return 1;
}

sub TC_evaluation {

    return 1;
}

sub TC_finalization {

    return 1;
}

1;
