#### TEST CASE MODULE
package TC_BAT_DeviceConfiguration;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.7 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_DeviceConfiguration.pm 1.7 2018/10/10 14:27:48ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 0.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_PD;
use LIFT_labcar;
use LIFT_evaluation;
use FuncLib_SYC_INTERFACE;
##################################

our $PURPOSE = "to check that all supported peripheral devices and ASICs are monitored, configured and detected";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_DeviceConfiguration

=head1 PURPOSE

to check that all supported peripheral devices and ASICs are monitored, configured and detected

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Previous test case TC_SAT_ECUProgramming has completed and passed.


I<B<Stimulation and Measurement>>

1. Read the SquibConfiguration using PS Diag

2. Read the SwitchConfiguration using PS Diag

3. Read the SensorConfiguration using PS Diag

4. Read the LampConfiguration using PS Diag

5. Read the ASICConfiguration using PS Diag


I<B<Evaluation>>

1 - 6. All supported devices and ASICs are configured and detected.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that all supported peripheral devices and ASICs are configured and detected'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Aout_SYC_device_map;

################ global parameter declaration ###################
#add any global variables here
my $conf_mon_states_map = { 'yes' => 1, 'no' => 0, 'N/A' => 0 };
my $device_data_href;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Aout_SYC_device_map = S_read_mandatory_testcase_parameter('Aout_SYC_device_map');

	return 1;
}

sub TC_initialization {

	S_teststep( "Initialize ECU", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "PD Clear FaultMemory\n", 'blue' );
	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "Power OFF the ECU\n", 'blue' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	S_w2rep( "Power ON the ECU\n", 'blue' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2rep( "PD Get Extended Fault Information\n", 'blue' );
	PD_GetExtendedFaultInformation();
	
	return 1;
}

sub TC_stimulation_and_measurement {

	$device_data_href = PD_DumpDeviceConfiguration();

	S_teststep( "Read the SquibConfiguration using Prodiag", 'AUTO_NBR', 'squib' );    #measurement 1
	eval_conf_mon_real_bit('squib');

	S_teststep( "Read the SwitchConfiguration using Prodiag", 'AUTO_NBR', 'switches' );
	eval_conf_mon_real_bit('switches');

	S_teststep( "Read the SensorConfiguration using Prodiag", 'AUTO_NBR', 'pases' );
	eval_conf_mon_real_bit('pases');

	S_teststep( "Read the LampConfiguration using Prodiag", 'AUTO_NBR', 'lamps' );
	eval_conf_mon_real_bit('lamps');

#	S_teststep( "Read the ASICConfiguration using Prodiag", 'AUTO_NBR', 'asic' );
#	eval_conf_mon_real_bit('asic');

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {

	return 1;
}

sub eval_conf_mon_real_bit {
	my $device_type = shift;

	my ( @device_names, @conf_exp, @conf_act, @mon_exp, @mon_act,, @presence_exp, @presence_act, @overall_verdict );

	my $syc_conf_function_map = {
		'squib'    => 'SYC_SQUIB_get_Configured',
		'switches' => 'SYC_SWITCH_get_Configured',
		'pases'    => 'SYC_SENSOR_get_Configured',
		'lamps'    => 'SYC_AnalogueOutput_get_Configured',
	};
	
	my $syc_mon_function_map = {
		'squib'    => 'SYC_SQUIB_get_Monitored',
		'switches' => 'SYC_SWITCH_get_Monitored',
		'pases'    => 'SYC_SENSOR_get_Monitored',
		'lamps'    => 'SYC_AnalogueOutput_get_Monitored',
	};

	foreach my $device ( sort keys %{$device_data_href->{$device_type}{'Prog'}} ) {
		next if ( $device =~ m/variable|name|bits/i );
		push( @device_names, $device );
		my $overall_verdict = "<span style='background:green'>PASS</span>";
		
		my $SYC_scip_device = $device;
		$SYC_scip_device = uc($SYC_scip_device) if ($device_type eq 'pases');
		$SYC_scip_device = $tcpar_Aout_SYC_device_map->{$device} if (defined $tcpar_Aout_SYC_device_map->{$device});

		no strict 'refs';

		#configuration bit
		S_w2log (5, "Config bit status for $device");
		my ( $result, $configured ) = &{ $syc_conf_function_map->{$device_type} }($SYC_scip_device);
		my $verdict_conf = EVAL_evaluate_value( "Config bit status $device", $device_data_href->{$device_type}{'Prog'}{$device}, '==', $conf_mon_states_map->{$configured} );
		push( @conf_exp, $conf_mon_states_map->{$configured} );
		push( @conf_act, $device_data_href->{$device_type}{'Prog'}{$device} );

		#presence bit / real bit (based on config bit status)
		S_w2log (5, "Presence bit status for $device");
		my $verdict_presence = EVAL_evaluate_value( "Presence bit status $device", $device_data_href->{$device_type}{'Real'}{$device}, '==', $conf_mon_states_map->{$configured} );
		push( @presence_exp, $conf_mon_states_map->{$configured} );
		push( @presence_act, $device_data_href->{$device_type}{'Real'}{$device} );

		#monitoring bit
		S_w2log (5, "Monitor bit status for $device");	
		my ( $result, $monitored ) = &{ $syc_mon_function_map->{$device_type} }($SYC_scip_device);
		my $verdict_mon = EVAL_evaluate_value( "Monitor bit status $device", $device_data_href->{$device_type}{'Mon'}{$device}, '==', $conf_mon_states_map->{$monitored} );
		push( @mon_exp, $conf_mon_states_map->{$monitored} );
		push( @mon_act, $device_data_href->{$device_type}{'Mon'}{$device} );

		$overall_verdict = "<span style='background:red'>FAIL</span>" if ( $verdict_conf ne 'VERDICT_PASS' or $verdict_mon ne 'VERDICT_PASS' or $verdict_presence ne 'VERDICT_PASS' );
		push( @overall_verdict, $overall_verdict );

	}
	
	S_teststep_expected( "All supported $device_type are configured and detected", $device_type ); 
	if ( grep( /FAIL/, @overall_verdict ) ) {
		S_teststep_detected( "Mismatch in device configuration check for $device_type", $device_type );
	}
	else{
		S_teststep_detected( "Device configuration check successful for $device_type", $device_type );
	}
	

	#print table
	S_w2rep( "Device Type: $device_type\n", "blue" );
	my $tableObject = S_TableCreate(
		[ 'Device',       'Config bit exp', 'Config bit observed', 'Monitoring bit exp', 'Monitoring bit observed', 'Presence bit exp', 'Presence bit observed', 'Verdict' ],
		[ \@device_names, \@conf_exp,       \@conf_act,            \@mon_exp,            \@mon_act,                 \@presence_exp,     \@presence_act,          \@overall_verdict ],
		'column-wise'
	);
	S_TablePrint( CONSOLE | TEXT | HTML | 2, $tableObject, "DeviceConfig_$device_type" );

}

1;
