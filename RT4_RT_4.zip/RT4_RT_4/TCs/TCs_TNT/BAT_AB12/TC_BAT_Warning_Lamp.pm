#### TEST CASE MODULE
package TC_BAT_Warning_Lamp;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_Warning_Lamp.pm 1.2 2018/09/17 13:57:46ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 0.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_PD;
use LIFT_labcar;
##################################

our $PURPOSE = "check fault of SysWarning Lamp is stored with correct status";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_Warning_Lamp

=head1 PURPOSE

check fault of SysWarning Lamp is stored with correct status

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set Ubat to <Ubat_V> V

2. Wait for end of initialization

3. Deconfigure SysWarning lamp.

4. Wait for fault qualification

5. Read fault memory afterwards

6. Configure SysWarning lamp again.

7. Wait for fault dequalification

8. Read fault memory afterwards

9. Reset ECU.

10. Wait for fault dequalification

11. Read fault memory afterwards


I<B<Evaluation>>

1. 

2. 

3. 

4. 

5. <FLTmand> and <FLTopt> is observed with <Status_Qualify>

6.

7.

8. <FLTmand> and <FLTopt> is observed with <Status_DeQualify>

9.

10. 

11. <FLTmand> and <FLTopt> is observed with <Status_AfterReset>


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	LIST 'FLTmand' => 
	LIST 'FLTopt' => 
	SCALAR 'Status_Qualify' => 
	SCALAR 'Status_DeQualify' => 
	SCALAR 'Status_AfterReset' => 


=head2 PARAMETER EXAMPLES

	purpose  = 'check fault of SysWarning Lamp is stored with correct status'
	FLTmand  = @('rb_aod_AOutSysWarningIndicatorShort2Gnd_flt')
	FLTopt   = @()
	Status_Qualify = '0bxxxx1x11'
	Status_DeQualify = '0bxxxx1x10'
	Status_AfterReset = '0bxxxx1x00'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Ubat_V;
my $tcpar_SysWL_Name;
my $tcpar_FLTmand;
my $tcpar_FLTopt;
my $tcpar_Status_Qualify;
my $tcpar_Status_DeQualify;
my $tcpar_Status_AfterReset;

################ global parameter declaration ###################
#add any global variables here
my ( $fltmem1, $fltmem2, $fltmem3 );

###############################################################

sub TC_set_parameters {

	$tcpar_purpose           = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Ubat_V            = S_read_mandatory_testcase_parameter('Ubat');
	$tcpar_SysWL_Name        = S_read_mandatory_testcase_parameter('SysWL_Name');
	$tcpar_FLTmand           = S_read_mandatory_testcase_parameter('FLTmand');
	$tcpar_FLTopt            = S_read_optional_testcase_parameter('FLTopt');
	$tcpar_Status_Qualify    = S_read_mandatory_testcase_parameter('Status_Qualify');
	$tcpar_Status_DeQualify  = S_read_mandatory_testcase_parameter('Status_DeQualify');
	$tcpar_Status_AfterReset = S_read_mandatory_testcase_parameter('Status_AfterReset');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	LC_ECU_On('U_BATT_DEFAULT');
	S_wait_ms('TIMER_ECU_READY');

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');

	PD_GetExtendedFaultInformation();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Set Ubat to '$tcpar_Ubat_V' V", 'AUTO_NBR' );
	LC_ECU_On($tcpar_Ubat_V);

	S_teststep( "Wait for end of initialization", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Deconfigure SysWarning lamp.", 'AUTO_NBR' );
	PD_Device_configuration( "clear", [$tcpar_SysWL_Name] );

	S_teststep( "Wait for fault qualification", 'AUTO_NBR' );
	S_wait_ms( 10000, 'wait for fault qualification' );

	S_teststep( "Read fault memory afterwards", 'AUTO_NBR', 'read_fault_memory_A' );    #measurement 1
	$fltmem1 = PD_GetExtendedFaultInformation();

	S_teststep( "Configure SysWarning lamp again.", 'AUTO_NBR' );
	PD_Device_configuration( "set", [$tcpar_SysWL_Name]  );

	S_teststep( "Wait for fault dequalification", 'AUTO_NBR' );
	S_wait_ms( 10000, 'wait for fault dequalification' );

	S_teststep( "Read fault memory afterwards", 'AUTO_NBR', 'read_fault_memory_B' );    #measurement 2
	$fltmem2 = PD_GetExtendedFaultInformation();

	S_teststep( "Reset ECU.", 'AUTO_NBR' );
	PD_ECUreset();

	S_teststep( "Wait for fault dequalification", 'AUTO_NBR' );
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Read fault memory afterwards", 'AUTO_NBR', 'read_fault_memory_C' );    #measurement 3
	$fltmem3 = PD_GetExtendedFaultInformation();

	return 1;
}

sub TC_evaluation {

	S_teststep_expected( "Expected faults:", 'read_fault_memory_A' );    #evaluation 1
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected("$fault with status $tcpar_Status_Qualify");
	}
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_A' );
	foreach my $fault ( @{ $fltmem1->{fault_text} } ) {
		my $status = PD_get_fault_status( $fltmem1, $fault );
		S_teststep_detected("$fault is present with status $status");
	}
	foreach my $fault ( @$tcpar_FLTmand ) {
		PD_check_fault_status( $fltmem1, $fault, $tcpar_Status_Qualify );
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem1, $tcpar_FLTmand, $tcpar_FLTopt );


	S_teststep_expected( "Expected faults:", 'read_fault_memory_B' );    #evaluation 2
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected("$fault with status $tcpar_Status_DeQualify");
	}
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_B' );
	foreach my $fault ( @{ $fltmem2->{fault_text} } ) {
		my $status = PD_get_fault_status( $fltmem2, $fault );
		S_teststep_detected("$fault is present with status $status");
	}
	foreach my $fault ( @$tcpar_FLTmand ) {
		PD_check_fault_status( $fltmem2, $fault, $tcpar_Status_DeQualify );
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem2, $tcpar_FLTmand, $tcpar_FLTopt );


	S_teststep_expected( "Expected faults:", 'read_fault_memory_C' );    #evaluation 3
	foreach my $fault (@$tcpar_FLTmand) {
		S_teststep_expected("$fault with status $tcpar_Status_AfterReset");
	}
	S_teststep_expected("\n");

	S_teststep_detected( 'Detected faults:', 'read_fault_memory_C' );
	foreach my $fault ( @{ $fltmem3->{fault_text} } ) {
		my $status = PD_get_fault_status( $fltmem3, $fault );
		S_teststep_detected("$fault is present with status $status");
	}
	foreach my $fault ( @$tcpar_FLTmand ) {
		PD_check_fault_status( $fltmem3, $fault, $tcpar_Status_AfterReset );
	}
	S_teststep_detected("\n");
	PD_evaluate_faults( $fltmem3, $tcpar_FLTmand, $tcpar_FLTopt );

	return 1;
}

sub TC_finalization {

	S_teststep( "Set battery voltage to default value", 'AUTO_NBR' );
	LC_ECU_On();

	PD_ClearFaultMemory();
	S_wait_ms('TIMER_ECU_READY');
	LC_ECU_Off();

	return 1;
}

1;
