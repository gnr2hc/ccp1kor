#### TEST CASE MODULE
package TC_BAT_SW_version;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_SW_version.pm 1.2 2018/07/19 16:02:34ICT ver6cob develop  $;


#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_evaluation;

##################################

our $PURPOSE = "check for SW version and SAD naming";


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_SW_version $Revision: 1.2 $

=head1 PURPOSE

check for SW version and SAD naming

=head1 TESTCASE DESCRIPTION

compare string returned from PD login with ROMCODE and Filename taken from SAD file.

=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES



=head2 PARAMETER EXAMPLES


=cut

#PARAMETERS
################ Parameters from .par file ###################

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

    return 1;
}

sub TC_initialization {

    return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Check SW version", 'AUTO_NBR' );
	S_teststep_2nd_level( "Compare string returned from PD login with ROMCODE taken from SAD file", 'AUTO_NBR', 'sw_version_romcode' );
	S_teststep_2nd_level( "Compare string returned from PD login with filename taken from SAD file", 'AUTO_NBR', 'sw_version_sadfile' );
	my $info_href = S_get_project_info();
	my $ecu_SW = $info_href->{'ECU_SW_VERSION'};

	my ($sad_SW,$rom_Code);

	my $sadfile    = $LIFT_config::SAD_file;
    unless ( open( SAD, "<$sadfile" ) )
    {
        S_set_error( "Cannot open SAD file $sadfile: $!.", 5 );
        return 0;
    }
    my @lines = <SAD>;
    close(SAD);

    foreach my $line (@lines) {
	    if ( $line =~ /^\s*ROMCODE\s*\:\s*(\w+)/ ){
            $rom_Code = $1;
        }
	    if ( $line =~ /^\s*Filename\s*\:\s*(\w+)/ ){
            $sad_SW = $1;
        }
		if ( $line =~ /^END OF HEADER/ ) {
			last;
        }
    }

	$sad_SW =~ s/\.sad$//i; # cut off extension
	#store sad vaules to report:
	S_w2rep("SW version $ecu_SW from ECU\n", 'blue');
	S_w2rep("SW version $rom_Code from ROMCODE\n", 'blue');
	S_w2rep("SW version $sad_SW from SAD filename\n", 'blue');
	
	S_teststep_expected( "SW version from ROMCODE = $ecu_SW", 'sw_version_romcode' );
	S_teststep_detected( "SW version from ROMCODE = $rom_Code", 'sw_version_romcode' );
	EVAL_evaluate_string ( 'compare ECU SW with ROMCODE' , $ecu_SW , $rom_Code  );
	
	S_teststep_expected( "SW version in SAD filename = $ecu_SW", 'sw_version_sadfile' );
	S_teststep_detected( "SW version in SAD filename = $sad_SW", 'sw_version_sadfile' );
	EVAL_evaluate_string ( 'compare ECU SW with SAD filename' , $ecu_SW , $sad_SW   );


    return 1;
}

sub TC_evaluation {


    return 1;
}

sub TC_finalization {

    return 1;
}

1;
