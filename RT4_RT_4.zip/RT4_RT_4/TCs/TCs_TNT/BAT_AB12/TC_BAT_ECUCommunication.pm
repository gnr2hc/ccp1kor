#### TEST CASE MODULE
package TC_BAT_ECUCommunication;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: BAT_AB12/TC_BAT_ECUCommunication.pm 1.5 2018/10/09 15:39:56ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: AB12_TS_BaselineAcceptanceTest
#TS version in DOORS: 0.8
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;

#include further modules here
use LIFT_PD;
use LIFT_FaultMemory;
use LIFT_labcar;
use LIFT_evaluation;
use LIFT_NET_access;
##################################

our $PURPOSE = "to check that the ECU communication works properly and timeout faults are handled";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_BAT_ECUCommunication

=head1 PURPOSE

to check that the ECU communication works properly and timeout faults are handled

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Observe the ECUTxCOMmessages using CANoe

2. Check the CANoe trace for error frames

3. Stop all ECURxCOMmessages (rest bus simulation)

4. Read the fault recorder after some time

5. Send all ECURxCOMmessages (rest bus simulation)

6. Reset the ECU and read the fault recorder after initialization


I<B<Evaluation>>

1. All ECU transmit messages are sent on the bus

2. No error frames are observed

4. COM Timeout faults are qualified in the fault recorder

6. COM Timeout faults are dequalified in the fault recorder


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 


=head2 PARAMETER EXAMPLES

	purpose = 'to check that the ECU communication works properly and timeout faults are handled'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ECU_TxMsgs_aref;
my $tcpar_FLTmand_aref;
my $tcpar_FLTopt_aref;

################ global parameter declaration ###################
#add any global variables here
my $nbr_error_fames_detected = 0;
my $trace_data_href;
my ( $faultMemory_obj1, $faultMemory_obj2, $expectedFaults_Quali, $expectedFaults_DeQuali );

###############################################################

sub TC_set_parameters {

    $tcpar_purpose         = S_read_mandatory_testcase_parameter('purpose');
    $tcpar_ECU_TxMsgs_aref = S_read_mandatory_testcase_parameter('ECU_TxMsgs');
    $tcpar_FLTmand_aref    = S_read_mandatory_testcase_parameter('FLTmand');
    $tcpar_FLTopt_aref     = S_read_optional_testcase_parameter('FLTopt');

    return 1;
}

sub TC_initialization {

    S_teststep( "Initialize rest bus simulation", 'AUTO_NBR' );
    #Stop and start CANoe to clear trace (make sure not get Error frame from another test at the beginning of trace)
    NET_simulation_stop();
    NET_simulation_start();

	S_teststep( "Initialize ECU", 'AUTO_NBR' );
    LC_ECU_On('U_BATT_DEFAULT'); 
    S_wait_ms('TIMER_ECU_READY');

    S_w2rep( "PD Clear FaultMemory\n", 'blue' );
    PD_ClearFaultMemory();

    S_w2rep( "Power OFF the ECU\n", 'blue' );
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');

    S_w2rep( "Power ON the ECU\n", 'blue' );
    LC_ECU_On();
    S_wait_ms('TIMER_ECU_READY');

    S_w2rep( "PD Get Extended Fault Information\n", 'blue' );
    PD_GetExtendedFaultInformation();

    S_w2rep( "Stop Network Trace (but RBS shall be still running) \n", 'blue' );
    NET_trace_stop();

    return 1;
}

sub TC_stimulation_and_measurement {

    S_teststep( "Measure the Network Communication", 'AUTO_NBR', 'observe_the_network_communication' );    #measurement 1

    S_teststep_2nd_level( "Start Network Trace / Logging", 'AUTO_NBR' );
    NET_trace_start();

    my $network_measure_time_ms = 5000;
    S_teststep_2nd_level( "Wait for $network_measure_time_ms ms ", 'AUTO_NBR' );
    S_wait_ms( $network_measure_time_ms, "trace capture for $network_measure_time_ms ms" );

    S_teststep_2nd_level( "Stop and Store Network Trace", 'AUTO_NBR' );
    NET_trace_stop();
    my $CANoe_trace_file = NET_trace_store();

    S_w2rep( "Stored Trace File : $CANoe_trace_file \n", 'blue' );
    $trace_data_href = NET_trace_get_dataref( $CANoe_trace_file, { 'MESSAGES' => $tcpar_ECU_TxMsgs_aref } );

    S_teststep( "Check Network Communication for error frames in the CANoe trace '$CANoe_trace_file'", 'AUTO_NBR' );
    $nbr_error_fames_detected = _countErrorFrames_inTraceFile($CANoe_trace_file);

    S_teststep( "Stop all ECURxCOMmessages (rest bus simulation)", 'AUTO_NBR' );
    NET_simulation_stop();
    S_wait_ms( 10000, 'wait after stopping CANoe RBS' );

    S_teststep( "Read the fault recorder after some time", 'AUTO_NBR', 'read_the_fault_with_absent_RX_msgs' );    #measurement 3
    $faultMemory_obj1 = LIFT_FaultMemory -> read_fault_memory('Primary');

    S_teststep( "Send all ECU Rx COMmessages (rest bus simulation)", 'AUTO_NBR' );
    NET_simulation_start();
    S_wait_ms( 10000, 'wait after re-starting CANoe RBS' );

    S_teststep( "Reset the ECU", 'AUTO_NBR', 'reset_ECU' );
    PD_ECUreset();
    S_wait_ms('TIMER_ECU_READY');

    S_teststep( "Read the fault recorder after new initialization", 'AUTO_NBR', 'read_the_fault_with_sent_RX_msgs_again' );    #measurement 4
    $faultMemory_obj2 = LIFT_FaultMemory -> read_fault_memory('Primary');

    return 1;
}

sub TC_evaluation {

    S_teststep_expected( "All ECU transmit messages are sent on the bus", 'observe_the_network_communication' );               #evaluation 1
    foreach my $msg (@$tcpar_ECU_TxMsgs_aref) {
        S_teststep_expected("Message '$msg' must be present in network trace");
    }

    S_teststep_detected( "Detected:", 'observe_the_network_communication' );
    foreach my $msg (@$tcpar_ECU_TxMsgs_aref) {
        my $availability_status = EVAL_get_signal_availability( $trace_data_href, $msg );
        S_teststep_detected(" Message '$msg' is $availability_status in trace");
        S_set_verdict(VERDICT_FAIL) if ( $availability_status eq 'absent' );
        S_set_verdict(VERDICT_PASS) if ( $availability_status eq 'present' );
    }

    S_teststep_expected( "No error frames shall be observed", 'observe_the_network_communication' );    #evaluation 2
    if ($nbr_error_fames_detected) {
        S_teststep_detected( "Error frames are observed", 'observe_the_network_communication' );
        S_set_verdict(VERDICT_FAIL);
    }
    else {
        S_teststep_detected( "No error frames are observed", 'observe_the_network_communication' );
        S_set_verdict(VERDICT_PASS);
    }

    S_teststep_expected( "COM Timeout faults are qualified in the fault recorder", 'read_the_fault_with_absent_RX_msgs' );    #evaluation 3
    foreach my $fault (@$tcpar_FLTmand_aref) {
        S_teststep_expected("$fault is qualified in the fault recorder");
    }
    S_w2rep("\n");
	my $entry_obj1_aref = $faultMemory_obj1 -> get_faults_with_properties({'DecodedStatus' => {'TestFailed' => 1}});
	my @faultNamesInQualifedState = ();
	foreach my $fault_entry_obj1(@{$entry_obj1_aref})
	{
		push(   @faultNamesInQualifedState, $fault_entry_obj1 -> FaultName);
	}
	
	S_teststep_detected( "Below faults are qualified in the fault recorder", 'read_the_fault_with_absent_RX_msgs' );
	foreach my $fault (@faultNamesInQualifedState) {
        S_teststep_detected( "$fault is qualified in the fault recorder" );
    }
	S_w2rep("\n");
    foreach my $fault (@$tcpar_FLTmand_aref) {
        $expectedFaults_Quali -> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1, 'TestFailed' => 1},};
    }
    $expectedFaults_Quali -> {'optional'} = $tcpar_FLTopt_aref;
    
    S_teststep_detected( 'Evaluate fault memory with absent Rx Msgs' );
    my $verdict = $faultMemory_obj1 -> evaluate_faults($expectedFaults_Quali, # expected faults
                                        'read_the_fault_with_absent_RX_msgs'); # eval keyword

    S_teststep_expected( "COM Timeout faults are dequalified in the fault recorder", 'read_the_fault_with_sent_RX_msgs_again' );    #evaluation 4
    foreach my $fault (@$tcpar_FLTmand_aref) {
        S_teststep_expected("$fault is dequalified in the fault recorde");
    }
    S_w2rep("\n");
    my $entry_obj2_aref = $faultMemory_obj2 -> get_faults_with_properties({'DecodedStatus' => {'ConfirmedDTC' => 1, 'TestFailed' => 0}});
	my @faultNamesInDeQualifedState = ();
	foreach my $fault_entry_obj2(@{$entry_obj2_aref})
	{
		push(   @faultNamesInDeQualifedState, $fault_entry_obj2 -> FaultName );
	}
	
	S_teststep_detected( "Below faults are dequalified in the fault recorder", 'read_the_fault_with_sent_RX_msgs_again' );
	foreach my $fault (@faultNamesInDeQualifedState) {
        S_teststep_detected("$fault is dequalified in the fault recorder");
    }
    S_w2rep("\n");
    foreach my $fault (@$tcpar_FLTmand_aref) {
        $expectedFaults_DeQuali -> {'mandatory'} -> {$fault} = {'DecodedStatus' => {'ConfirmedDTC' => 1, 'TestFailed' => 0},};
    }
    $expectedFaults_DeQuali -> {'optional'} = $tcpar_FLTopt_aref;
    
    S_teststep_detected( 'Evaluate fault memory with sent Rx Msgs again' );
    $verdict = $faultMemory_obj2 -> evaluate_faults($expectedFaults_DeQuali, # expected faults
                                        'read_the_fault_with_sent_RX_msgs_again'); # eval keyword

    return 1;
}

sub TC_finalization {

    S_w2rep( "PD Clear FaultMemory\n", 'blue' );
    PD_ClearFaultMemory();

    return 1;
}

sub _countErrorFrames_inTraceFile {
    my $network_trace_file  = shift;
    my $nbr_of_error_frames = 0;

    S_w2log( 3, " _countErrorFrames_inTraceFile: Opening Trace File for reading\n" );
    unless ( open( FH, $network_trace_file ) ) {
        S_set_error("Could not open trace '$network_trace_file' file for reading ");
        return;
    }

    while (<FH>) { $nbr_of_error_frames++ if /ErrorFrame/ }
    unless ( close(FH) ) {
        S_set_error("Could not close trace '$network_trace_file' file for reading ");
        return;
    }

    S_w2log( 3, " _countErrorFrames_inTraceFile: Found '$nbr_of_error_frames' error messages\n" );

    return $nbr_of_error_frames;
}

1;
