#### TEST CASE MODULE
package TC_EDR_DiagnosticInterfaceReadEDR_ConditionsNotCorrect;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: AKLV/TC_EDR_DiagnosticInterfaceReadEDR_ConditionsNotCorrect.pm 1.1 2020/03/17 09:03:37ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

##################################

our $PURPOSE = "To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_DiagnosticInterfaceReadEDR

=head1 PURPOSE

'To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <crashcode>.

2.Wait <CrashTimeZero_ms> 

3.Create <Condition> and send <Diag_service> Read <EDR_EntryType>

4. Wait <wait_ms>

5. Power down ECU


I<B<Evaluation>>

1. -

2.

3. <Response> is obtained

4. -

5. -

Note: applies for the $22 services with DID's $FA13 to $FA18 and $1013 to $1018 (which are used for reading EDR data) and not for the other AK-LV 37 DID


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Condition' => 
	SCALAR 'EDR_EntryType' => 
	SCALAR 'crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'wait_ms' => 
	SCALAR 'ResultDB' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress'
	
	Condition = <Test Heading 1>
	EDR_EntryType = <Test Heading 2>
	
	# ---------- Stimulation ------------ 
	crashcode = 'Single_EDR_Front_Inflatable;5'
	CrashTimeZero_ms='11.76' #ms
	
	wait_ms = 10000 #ms
	ResultDB='EDR'
	
	# ---------- Evaluation ------------ 
	Response = 'NR_conditionsNotCorrect'  #Conditions not correct
	
	
	#NRC $22 - ConditionsNotCorrect.( NRC shall be configurable)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Condition;
my $tcpar_EDR_EntryType;
my $tcpar_Crashcode;
my $tcpar_wait_ms;
my $tcpar_Response;
my $tcpar_ResultDB;
my $tcpar_CrashTimeZero_ms;
my $tcpar_NbrOfRecordsExpected;
my $tcpar_Read_EDR_Generic_label;
my $tcpar_Read_EDR_OEM_label;
my $tcpar_Read_EDR_Supplier_label;
################ global parameter declaration ###################
#add any global variables here
my $crashSettings;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                 = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Condition               = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_EDR_EntryType           = S_read_mandatory_testcase_parameter('EDR_EntryType');
	$tcpar_Crashcode               = S_read_mandatory_testcase_parameter('crashcode');
	$tcpar_wait_ms                 = S_read_mandatory_testcase_parameter('wait_ms');
	$tcpar_Response                = S_read_mandatory_testcase_parameter('Response');
	$tcpar_ResultDB                = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	$tcpar_CrashTimeZero_ms        = S_read_mandatory_testcase_parameter('CrashTimeZero_ms');
	$tcpar_NbrOfRecordsExpected    = S_read_mandatory_testcase_parameter('NbrOfRecordsExpected');
	$tcpar_Read_EDR_Generic_label  = S_read_mandatory_testcase_parameter('Read_EDR_Generic_label');
	$tcpar_Read_EDR_OEM_label      = S_read_mandatory_testcase_parameter('Read_EDR_OEM_label');
	$tcpar_Read_EDR_Supplier_label = S_read_mandatory_testcase_parameter('Read_EDR_Supplier_label');

	return 1;
}

sub TC_initialization {

	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_w2rep("Get crash settings for crash $tcpar_Crashcode");
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $tcpar_Crashcode };
	$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $tcpar_Crashcode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $tcpar_Crashcode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Power on ECU" );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	S_w2log( 1, "Clear crash recorder" );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	S_w2log( 1, "Clear fault memory" );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_w2log( 1, "Read and evaluate fault memory before stimulation" );
	my $faultsBeforeStimulation = PD_ReadFaultMemory();

	#Fault memory must be empty
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#

	# Prepare crash
	S_teststep( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#--------------------------------------------------------------
	# CRASH INJECTION
	#

	S_teststep( "Inject '$tcpar_Crashcode'.", 'AUTO_NBR' );
	CSI_TriggerCrash();

	S_teststep( "Wait '$tcpar_CrashTimeZero_ms' ms", 'AUTO_NBR' );
	S_wait_ms($tcpar_CrashTimeZero_ms);

	S_teststep( "Create '$tcpar_Condition' and Read '$tcpar_EDR_EntryType'", 'AUTO_NBR', 'create_condition_and' );    #measurement 1
	S_teststep_2nd_level( "Create condition $tcpar_Condition", 'AUTO_NBR' );
	_create_Condition($tcpar_Condition);

	foreach my $recordNbr ( 1 .. $tcpar_NbrOfRecordsExpected ) {
		S_teststep_2nd_level( "Read '$tcpar_EDR_EntryType' section $recordNbr ", 'AUTO_NBR', 'read_edr_' . $recordNbr );
		my $readEDR_response_aref = _read_EDR_record( $recordNbr, $tcpar_EDR_EntryType, $tcpar_Response, 'EVAL_SWITCH' );
		my @obtained_response;
		foreach my $i ( @{$readEDR_response_aref} ) {
			push( @obtained_response, $i );
		}
		S_teststep_expected( "Expect $tcpar_Response", 'read_edr_' . $recordNbr );                                    #evaluation 1
		S_teststep_detected( "Detected response is @obtained_response in decimal format", 'read_edr_' . $recordNbr );
	}

	S_teststep( "Wait '$tcpar_wait_ms' ms", 'AUTO_NBR' );
	S_wait_ms($tcpar_wait_ms);

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
	PD_ECUlogin();
	S_wait_ms(2000);

	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

sub _create_Condition {
	my $condition = shift;

	if ( $condition =~ m/AlgorithmIsActive|CrashStorageIsInProgress/i ) {
		S_wait_ms( 50, 'wait after crash trigger' );
	}
	elsif ( $condition =~ /CrashRecorderErasureInProgress/ ) {
		S_wait_ms( 15000, 'wait for EDR finish record' );

		S_teststep_2nd_level( "Read Crash Recorder to ensure there is already EDR recored", 'AUTO_NBR' );
		PD_ReadCrashRecorder(0x00);
		S_wait_ms(2000);

		S_teststep_2nd_level( "Clear Crash Recorder", 'AUTO_NBR' );
		PD_ClearCrashRecorder_NOERROR(1000);
	}
	elsif ( $condition =~ /CrashRecorderUnlockingInProgress/ ) {
		S_teststep_2nd_level( "Call 'EDR_CD_UnlockEDR' to unlock locked EDR", 'AUTO_NBR' );
		EDR_CD_UnlockEDR();    #This is dummy function since this feature is not present in coreassets
	}
	else {
		S_set_error("Currently, condition $condition is not supported, only support for AlgorithmIsActive|CrashStorageIsInProgress|CrashRecorderErasureInProgress|CrashRecorderUnlockingInProgress");
	}

	return 1;
}

sub _read_EDR_record {

	my $EDRentry_nbr       = shift;
	my $EDRentry_type      = shift;
	my $expectedResponse   = shift;
	my $evaluationRequired = shift;

	my $requestLabel;
	$requestLabel = $tcpar_Read_EDR_Generic_label . '0' . $EDRentry_nbr if ( $EDRentry_type eq 'Generic' );

	$requestLabel = $tcpar_Read_EDR_OEM_label . '0' . $EDRentry_nbr if ( $EDRentry_type eq 'OEM' );

	$requestLabel = $tcpar_Read_EDR_Supplier_label . '0' . $EDRentry_nbr if ( $EDRentry_type eq 'Supplier' );

	S_w2log( 3, "\n Sending Diag request to read EDR Entry $EDRentry_nbr \n" );

	unless ( defined $expectedResponse ) {
		$expectedResponse = "PR_$requestLabel";
	}
	my $noEvalSwitch;
	$noEvalSwitch = 'NO_EVAL_SWITCH' unless ( defined $evaluationRequired );

	# Send the diagnosis request via GDCOM
	my $response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	unless ($response) {
		S_wait_ms(2000);
		S_w2log( 2, "Try to read service again after short wait time" );
		$response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	}

	# In case of offline run, no response will be recieved
	return [] if $main::opt_offline;

	# Convert the received diagnosis response (string with hex values, each byte separated by space!) to array of bytes
	my @responseBytes = split( / /, $response );

	# Convert the array of hex bytes to an array of decimal bytes
	my @response_dec;
	foreach my $byte (@responseBytes) {
		push( @response_dec, hex($byte) );
	}

	# return dereferenced array of decimal bytes

	return \@response_dec;
}
1;
