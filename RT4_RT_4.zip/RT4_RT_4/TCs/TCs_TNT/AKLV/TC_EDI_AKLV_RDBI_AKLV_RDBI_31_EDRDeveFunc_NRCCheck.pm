#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_AKLV_RDBI_31_EDRDeveFunc_NRCCheck;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER = q$Header: AKLV/TC_EDI_AKLV_RDBI_AKLV_RDBI_31_EDRDeveFunc_NRCCheck.pm 1.2 2014/07/07 16:24:26ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project; 

##################################

our $PURPOSE = "To test supported NRC for Crash Recorder Routine Control services";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_CD_AKLVRoutineControl_NRCCheck

=head1 PURPOSE

To test supported NRC for Crash Recorder Routine Control services

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation

Set <Test_Condition>


I<B<Stimulation and Measurement>>

1. Send Request to enter session [enterSession::<Session_to_be_entered>]

2. Send start routine control request  [routinecontrol :: <Sub_Function_Start><RID><SelectedFunction>, <EDR_EntryToProcess>]

3. Send  Stop routine control request   [routinecontrol :: <Sub_Function_Stop><RID><SelectedFunction>, <EDR_EntryToProcess>]

4. Send  routine result request  [routinecontrol :: <Sub_Function_Result><RID>]  


I<B<Evaluation>>

1. Session is entered

2. <Response_Type_Start> is obtained 

3. <Response_Type_Stop> is obtained 

4. <Response_Type_Result> is obtained 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	SCALAR 'Session_to_be_entered' => Session to be entered
	SCALAR 'Test_Condition' => NONE, RequestSequenceError  , RequestLengthMore, RequestLengthLess
	LIST 'Sub_Function_Start' => 01
	LIST 'Sub_Function_Stop' => 02
	LIST 'Sub_Function_Result' => 03 
	LIST 'RID' => E2 10
	LIST 'SelectedFunction' => Selected function either signature or CRC
	LIST 'EDR_EntryToProcess' => EDR Entry 
	SCALAR 'Response_Type_Start' => Expected Response Type for start routine
	SCALAR 'Response_Type_Stop' => Expected Response Type for stop routine
	SCALAR 'Response_Type_Result' => Expected Response Type for routine result
	


=head2 PARAMETER EXAMPLES

	purpose = 'To check  NRC for Crash Recorder Routine Control services'
	Session_to_be_entered ='DefaultSession' 
	Test_Condition = 'NONE'
	Sub_Function_Start = @('01')
	Sub_Function_Stop = @('02')
	Sub_Function_Result = @('03')
	RID = @('E2 10')
	SelectedFunction = @('01','02')
	EDR_EntryToProcess = @('01', '02','03','04','05','06','F0','81', '82','83','84','85','86','F1')	
	Response_Type_Start = 'NR_requestOutOfRange'
	Response_Type_Stop = 'NR_requestOutOfRange'
	Response_Type_Result = 'NR_requestOutOfRange'
	Session_to_be_entered ='ProgrammingSession' 

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session_to_be_entered;
my $tcpar_Test_Condition;
my @tcpar_Sub_Function_Start;
my @tcpar_Sub_Function_Stop;
my @tcpar_Sub_Function_Result;
my @tcpar_RID;
my @tcpar_SelectedFunction;
my @tcpar_EDR_EntryToProcess;
my $tcpar_Response_Type_Start;
my $tcpar_Response_Type_Stop;
my $tcpar_Response_Type_Result;


################ global parameter declaration ###################
#add any global variables here
my $NRCInfo_Start;
my $NRCInfo_Stop;
my $NRCInfo_Result;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Session_to_be_entered =  GEN_Read_mandatory_testcase_parameter( 'Session_to_be_entered' );
	$tcpar_Test_Condition =  GEN_Read_mandatory_testcase_parameter( 'Test_Condition' );
	@tcpar_Sub_Function_Start =  GEN_Read_mandatory_testcase_parameter( 'Sub_Function_Start' );
	@tcpar_Sub_Function_Stop =  GEN_Read_mandatory_testcase_parameter( 'Sub_Function_Stop' );
	@tcpar_Sub_Function_Result =  GEN_Read_mandatory_testcase_parameter( 'Sub_Function_Result' );
	@tcpar_RID =  GEN_Read_mandatory_testcase_parameter( 'RID' );
	@tcpar_SelectedFunction =  GEN_Read_mandatory_testcase_parameter( 'SelectedFunction' );
	@tcpar_EDR_EntryToProcess =  GEN_Read_mandatory_testcase_parameter( 'EDR_EntryToProcess' );
	$tcpar_Response_Type_Start =  GEN_Read_mandatory_testcase_parameter( 'Response_Type_Start' );
	$tcpar_Response_Type_Stop =  GEN_Read_mandatory_testcase_parameter( 'Response_Type_Stop' );
	$tcpar_Response_Type_Result =  GEN_Read_mandatory_testcase_parameter( 'Response_Type_Result' );
	

	return 1;
}

sub TC_initialization {
	
	GEN_printTestStep("Standard_Preparation");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();
	

	GEN_printTestStep("Set $tcpar_Test_Condition");
	GEN_printComment ( "This is done in stimulation and measurement section" );

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1. Send Request to enter session [enterSession::$tcpar_Session_to_be_entered]");
	GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	
	
	$NRCInfo_Start = GDCOM_getNRCfromMapping('RoutineControl',$tcpar_Response_Type_Start); 
	$NRCInfo_Stop = GDCOM_getNRCfromMapping('RoutineControl',$tcpar_Response_Type_Stop);
	$NRCInfo_Result = GDCOM_getNRCfromMapping('RoutineControl',$tcpar_Response_Type_Result);
	
	if ( $tcpar_Test_Condition eq 'NONE' )
	{
		foreach my $RID(@tcpar_RID)
		{
			foreach my $SelFunc(@tcpar_SelectedFunction)
			{
				foreach my $EDR_EntryToProcess(@tcpar_EDR_EntryToProcess)
				{
					foreach my $Sub_Function_Start(@tcpar_Sub_Function_Start)					
					{
						my $RequestLabel_StartRoutine = "31 $Sub_Function_Start $RID $SelFunc $EDR_EntryToProcess";
						GEN_printTestStep("Step 2. Send start routine control request Sub_Function_Start : $Sub_Function_Start, RID :  $RID, SelFunc : $SelFunc, EDR_EntryToProcess : $EDR_EntryToProcess ");
						GDCOM_request($RequestLabel_StartRoutine,$NRCInfo_Start->{'Response'}, 'strict') ;																
					}
					foreach my $Sub_Function_Stop(@tcpar_Sub_Function_Stop)
					{
						my $RequestLabel_StopRoutine = "31 $Sub_Function_Stop $RID $SelFunc $EDR_EntryToProcess";
						GEN_printTestStep("Step 3. Send  Stop routine control request Sub_Function_Stop : $Sub_Function_Stop, RID :  $RID, SelFunc : $SelFunc, EDR_EntryToProcess : $EDR_EntryToProcess  ");
						GDCOM_request($RequestLabel_StopRoutine,$NRCInfo_Stop->{'Response'}, 'strict') ;						
					}	
					foreach my $Sub_Function_Result(@tcpar_Sub_Function_Result)
					{
						my $RequestLabel_ResultRoutine = "31 $Sub_Function_Result $RID";
						GEN_printTestStep("Step 4. Send  routine result request Sub_Function_Result : $Sub_Function_Result, RID :  $RID");
						GDCOM_request($RequestLabel_ResultRoutine,$NRCInfo_Result->{'Response'}, 'strict') ;						
					}									
				}				
			}			
						
		}
	}
	elsif ( $tcpar_Test_Condition eq 'RequestSequenceError' )
	{
		foreach my $RID(@tcpar_RID)
		{
			foreach my $SelFunc(@tcpar_SelectedFunction)
			{
				foreach my $EDR_EntryToProcess(@tcpar_EDR_EntryToProcess)
				{
					foreach my $Sub_Function_Stop(@tcpar_Sub_Function_Stop)
					{
						my $RequestLabel_StopRoutine = "31 $Sub_Function_Stop $RID $SelFunc $EDR_EntryToProcess";
						GEN_printTestStep("Step 3. Send  Stop routine control request Sub_Function_Stop : $Sub_Function_Stop, RID :  $RID, SelFunc : $SelFunc, EDR_EntryToProcess : $EDR_EntryToProcess  ");
						GDCOM_request($RequestLabel_StopRoutine,$NRCInfo_Stop->{'Response'}, 'strict') ;						
					}	
					foreach my $Sub_Function_Result(@tcpar_Sub_Function_Result)
					{
						my $RequestLabel_ResultRoutine = "31 $Sub_Function_Result $RID";
						GEN_printTestStep("Step 4. Send  routine result request Sub_Function_Result : $Sub_Function_Result, RID :  $RID");
						GDCOM_request($RequestLabel_ResultRoutine,$NRCInfo_Result->{'Response'}, 'strict') ;						
					}									
				}				
			}			
						
		}
	}
	
	
	else
	{
		S_set_error( "Test Condition is Incorrect. Not proceeding!", 0 );
		return 0;
	}
	

	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 2. $tcpar_Response_Type_Start is obtained ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 3. $tcpar_Response_Type_Stop is obtained ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 4. $tcpar_Response_Type_Result is obtained ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	return 1;
}

sub TC_finalization {
	if ($tcpar_Session_to_be_entered eq 'ProgrammingSession')
	{
			GDCOM_stop_CyclicTesterPresent();
			GEN_Power_on_Reset();
			S_wait_ms ( '5000' );
			GEN_printComment("Enter Extended Diag Session ");
			GDCOM_StartSession ( 'ExtendedSession' , 'CheckActiveSession');
	}
	else
	{
		GDCOM_stop_CyclicTesterPresent();
	}

	return 1;
}


1;
