#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_RequestSequenceError;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_RequestSequenceError.pm 1.4 2019/11/19 18:21:56ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_crash_simulation;
use LIFT_labcar;

##################################

our $PURPOSE = "To check  for NRC_24 for generic EDR entries";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_AKLV_RDBI_AKLV_RDBI_RequestSequenceError

=head1 PURPOSE

To check  for NRC_24 for generic EDR entries

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send Request to enter session [enterSession::<Session_to_be_entered>]

2. Create <Condition>

3. Get the Security  access  [getSecurity ::<Security_Key>]

4. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are  <EDR_Entries> 

5. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>,<EDR_EntryToProcess>]

6. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during CompletedSuccessfully condition

7. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are  <EDR_Entries> 

8. Inject Any Deployment Crash [FrontInflatableDeployment]

9. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are  <EDR_Entries>

10. Inject Any Five Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, FrontInflatableDeployment, SideDriverInflatableDeployment]

11. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>]

12. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are  <EDR_Entries> during the start routine is running


I<B<Evaluation>>

1. Session is entered

2. --

3. --

4. NR_requestSequenceError  is obtained  for each request

5. Positive Response is obtained

6. Positive Response is obtained

7. <Response_Type> is obtained for each request

8. --

9. NR_requestSequenceError  is obtained  for each request

10. --

11. Positive Response is obtained

12. NR_requestSequenceError  is obtained  for each request


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => To check  for NRC_24 for generic EDR entries
	SCALAR 'Session_to_be_entered' =>  DefaultSession
	SCALAR 'Condition' => NoOperation
	SCALAR 'Security_Key' => NONE
	LIST 'EDR_Entries' => @('01', '02', '03', '04', '05', '06')
	LIST 'EDR_EntryToProcess' => @('01', '02', '03', '04', '05', '06')
	SCALAR 'Response_Type' => 'NR_requestSequenceError'
	LIST 'SelectedFunction' => @('NoOperation')


=head2 PARAMETER EXAMPLES

	purpose = 'To check  for NRC_24 for generic EDR entries'
	
	Session_to_be_entered ='<Test Heading 1>'
	Condition =  '<Test Heading 2>'
	Security_Key = 'NONE'
	EDR_Entries = @('01', '02', '03', '04', '05', '06')
	EDR_EntryToProcess = @('01', '02', '03', '04', '05', '06')
	Response_Type = 'NR_requestSequenceError'
	SelectedFunction = @('NoOperation')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Session_to_be_entered;
my $tcpar_Condition;
my $tcpar_Security_Key;
my $tcpar_EDR_Entries;
my $tcpar_EDR_EntryToProcess;
my $tcpar_Response_Type;
my $tcpar_SelectedFunction;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
my $CrashInjectionStatus;
my $EDRresp;
my $EDRDiagResp;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose               = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Session_to_be_entered = S_read_mandatory_testcase_parameter('Session_to_be_entered');
	$tcpar_Condition             = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Security_Key          = S_read_mandatory_testcase_parameter('Security_Key');
	$tcpar_EDR_Entries           = S_read_mandatory_testcase_parameter( 'EDR_Entries', 'byref' );
	$tcpar_EDR_EntryToProcess    = S_read_mandatory_testcase_parameter( 'EDR_EntryToProcess', 'byref' );
	$tcpar_Response_Type         = S_read_mandatory_testcase_parameter('Response_Type');
	$tcpar_SelectedFunction      = S_read_mandatory_testcase_parameter( 'SelectedFunction', 'byref' );
	$tcpar_CrashScenarioList     = S_read_mandatory_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB              = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB              = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparation", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	PD_ClearCrashRecorder();
	GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Step 1. Send Request to enter session [enterSession::'$tcpar_Session_to_be_entered']", 'AUTO_NBR' );
	GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );

	S_teststep( "Step 2. Create '$tcpar_Condition'", 'AUTO_NBR' );

	if ( $tcpar_Condition eq 'CrashEntry' ) {
		S_teststep( "Injecting a Crash", 'AUTO_NBR' );

		_injectCrash( @$tcpar_CrashScenarioList[0] );

	}

	S_teststep( "Step 3. Get the Security  access  [getSecurity ::'$tcpar_Security_Key']", 'AUTO_NBR' );

	if ( $tcpar_Security_Key eq 'NONE' ) {
		GEN_printComment( 'SA is Not Required', 'blue' );
	}
	else {
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}

	S_teststep( "Step 4. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ]", 'AUTO_NBR' );

	foreach $EDRresp (@$tcpar_EDR_Entries) {
		$EDRDiagResp = DIAG_readEDREntry($EDRresp);

		EVAL_evaluate_value( "Checking NRC 24 is obtained", @$EDRDiagResp[2], '==', '0x24' );
	}

	S_teststep( "Step 5. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,]", 'AUTO_NBR' );

	S_teststep( "Step 6. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during CompletedSuccessfully condition", 'AUTO_NBR' );

	if ( @$tcpar_SelectedFunction[0] eq 'CalculateSignature' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
			my $Signroutineresult_sucess = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$Signroutineresult_sucess[6], '==', '0x80' );

			S_teststep( "Signature calculated Sucessfully", 'AUTO_NBR' );
		}
	}

	elsif ( @$tcpar_SelectedFunction[0] eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {

			my $CRCroutineresult_sucess = DIAG_calculateCRC_CompletedSuccessfully($EDR_EntryToProcess_CRC);

			EVAL_evaluate_value( "Checking Result", @$CRCroutineresult_sucess[6], '==', '0x80' );

			S_teststep( "CRC calculated Sucessfully", 'AUTO_NBR' );

		}
	}

	elsif ( scalar(@$tcpar_SelectedFunction) == 2 && @$tcpar_SelectedFunction[0] eq 'CalculateSignature' && @$tcpar_SelectedFunction[1] eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
			my $Signroutineresult_sucess = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Signature Result", @$Signroutineresult_sucess[6], '==', '0x80' );
		}

		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {

			my $CRCroutineresult_sucess = DIAG_calculateCRC_CompletedSuccessfully($EDR_EntryToProcess_CRC);

			EVAL_evaluate_value( "Checking CRC Result", @$CRCroutineresult_sucess[6], '==', '0x80' );

		}
		S_teststep( "CRC and Signature Completed Sucessfully", 'AUTO_NBR' );
	}

	S_teststep( "Step 7. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are  ", 'AUTO_NBR' );

	foreach $EDRresp (@$tcpar_EDR_Entries) {
		$EDRDiagResp = DIAG_readEDREntry($EDRresp);

		EVAL_evaluate_value( "EDR response is obtained", @$EDRDiagResp[2], '!=', '0x24' );
	}

	S_teststep( "Step 8. Inject Any Deployment Crash [FrontInflatableDeployment]", 'AUTO_NBR' );

	_injectCrash( @$tcpar_CrashScenarioList[0] );

	S_teststep( "Step 9. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] where DID are ", 'AUTO_NBR' );

	foreach $EDRresp (@$tcpar_EDR_Entries) {
		$EDRDiagResp = DIAG_readEDREntry($EDRresp);

		EVAL_evaluate_value( "Checking NRC 24 is obtained", @$EDRDiagResp[2], '==', '0x24' );
	}

	S_teststep( "Step 10. Inject Any Five Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, FrontInflatableDeployment, SideDriverInflatableDeployment]", 'AUTO_NBR' );
	my $crashCount = 0;
	foreach (@$tcpar_CrashScenarioList) {
		#Check number of Crash Injection in case of wrong parameter update.
		unless ( $crashCount >= 5 ) {
			_injectCrash($_);
			$crashCount = $crashCount + 1;
		}
		else {
			S_set_error("Reach maximun number of crash required: 5 ");
		}
	}

	S_teststep( "Step 11. Send  start routine control request ", 'AUTO_NBR' );

	if ( @$tcpar_SelectedFunction[0] eq 'CalculateSignature' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
			my $Signroutineresult_sucess = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'Running' );

			EVAL_evaluate_value( "Checking Result", @$Signroutineresult_sucess[6], '==', '0x01' );

			S_teststep( "Signature calculation Running", 'AUTO_NBR' );
		}
	}

	elsif ( @$tcpar_SelectedFunction[0] eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {

			my $CRCroutineresult_sucess = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, 'Running' );

			EVAL_evaluate_value( "Checking Result", @$CRCroutineresult_sucess[6], '==', '0x01' );

			S_teststep( "CRC calculation Running", 'AUTO_NBR' );

		}
	}

	elsif ( scalar(@$tcpar_SelectedFunction) == 2 && @$tcpar_SelectedFunction[0] eq 'CalculateSignature' && @$tcpar_SelectedFunction[1] eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
			my $Signroutineresult_sucess = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'Running' );

			EVAL_evaluate_value( "Checking Signature Result", @$Signroutineresult_sucess[6], '==', '0x01' );
		}

		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {

			my $CRCroutineresult_sucess = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, 'Running' );

			EVAL_evaluate_value( "Checking CRC Result", @$CRCroutineresult_sucess[6], '==', '0x01' );

		}
		S_teststep( "CRC and Signature calculation Running", 'AUTO_NBR' );
	}

	S_teststep( "Step 12. Send array of requests  to read EDR entries   [ ReadDataByIdentifier :: DID ] ", 'AUTO_NBR' );

	foreach my $EDRresp (@$tcpar_EDR_Entries) {
		my $EDRDiagResp = DIAG_readEDREntry($EDRresp);

		EVAL_evaluate_value( "Checking NRC 24 is obtained", @$EDRDiagResp[2], '==', '0x24' );
	}

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. Session is entered", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 2. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 3. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 4. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 5. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 6. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 7. '$tcpar_Response_Type' is obtained for each request", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 8. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 9. NR_requestSequenceError  is obtained  for each request", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 10. is done at Test measurement and setup", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 11. Positive Response is obtained", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 12. NR_requestSequenceError  is obtained  for each request", 'AUTO_NBR' );

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

sub _injectCrash() {

	my $crashCode = shift;

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_teststep_2nd_level( "Get crash settings for crash $crashCode", 'AUTO_NBR' );
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
	my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#--------------------------------------------------------------
	# CRASH INJECTION
	#

	S_teststep_2nd_level( "Inject crash '$crashCode'", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
	S_wait_ms(10000);
}

1;
