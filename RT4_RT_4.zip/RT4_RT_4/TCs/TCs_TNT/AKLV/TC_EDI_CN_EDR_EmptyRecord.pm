#### TEST CASE MODULE
package TC_EDI_CN_EDR_EmptyRecord;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: AKLV/TC_EDI_CN_EDR_EmptyRecord.pm 1.2 2020/03/20 13:35:49ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
##################################

our $PURPOSE = "To check response bytes have value FF when EDR entry is empty";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_CN_EDR_EmptyRecord

=head1 PURPOSE

To check response bytes have value FF when EDR entry is empty

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <CrashCodeList> Crashes

2. send request <Read_ChinaEDR> and check obtained response

3. Clear all stored EDR

4. send request <Read_ChinaEDR> and check obtained response


I<B<Evaluation>>

1. --

2. Positive response is obtained with <NbrOfDataByte> EDR bytes

data having value different from FF

3. 

4. Positive response is obtained and all <NbrOfDataByte> EDR data bytes received as response having value FF.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'NumberOfCrashes' => 
	SCALAR 'NbrOfDataByte' => 
	LIST 'CrashCodeList' => 
	SCALAR 'ResultDB' => 
	SCALAR 'Read_ChinaEDR' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check response bytes have value FF when EDR entry is empty'
	
	NumberOfCrashes = <Test Heading 1>
	NbrOfDataByte = 772
	
	CrashCodeList = @('Single_EDR_Front_Inflatable;5', 'Single_EDR_SideRight_Inflatable;5', 'Single_EDR_Rear_NonInflatable;5')
	ResultDB = 'EDR'
	Read_ChinaEDR = 'ReadDataByIdentifier_CnEDRdata'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_NumberOfCrashes;
my $tcpar_NbrOfDataByte;
my $tcpar_CrashCodeList;
my $tcpar_ResultDB;
my $tcpar_Read_ChinaEDR;

################ global parameter declaration ###################
#add any global variables here
my $crashLabel;
my $crashcount;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose         = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_NumberOfCrashes = S_read_mandatory_testcase_parameter('NumberOfCrashes');
	$tcpar_NbrOfDataByte   = S_read_mandatory_testcase_parameter('NbrOfDataByte');
	$tcpar_CrashCodeList   = S_read_mandatory_testcase_parameter('CrashCodeList');
	$tcpar_ResultDB        = S_read_optional_testcase_parameter( 'ResultDB', "byref", 'DEFAULT' );
	$tcpar_Read_ChinaEDR   = S_read_mandatory_testcase_parameter('Read_ChinaEDR');

	return 1;
}

sub TC_initialization {

	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Inject Crashes", 'AUTO_NBR' );
	$crashcount = 0;
	foreach my $crashCode ( @{$tcpar_CrashCodeList} ) {
		S_w2rep("Prepare and inject $crashCode");
		$crashLabel .= "_" if ( defined $crashLabel );
		$crashLabel .= $crashCode;
		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2rep("Get crash settings for crash $crashCode");
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);

		unless ( defined $crashSettings ) {
			S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_teststep( "Set environment for crash", 'AUTO_NBR' );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		CSI_TriggerCrash();

		S_teststep( "Wait for 15 seconds", 'AUTO_NBR' );
		S_wait_ms(15000);
		$crashcount++;
		if ( $crashcount eq $tcpar_NumberOfCrashes ) {
			last;
		}
	}

	S_teststep( "send request '$tcpar_Read_ChinaEDR' and check obtained response", 'AUTO_NBR', 'send_request_read_A' );    #measurement 1
	foreach my $recordNbr ( 1 .. $tcpar_NumberOfCrashes ) {

		S_teststep_2nd_level( "send request read ChinaEDR section $recordNbr ", 'AUTO_NBR', 'read_edr_' . $recordNbr );
		my $readEDR_response_aref = _read_EDR_record( $recordNbr, undef, 'EVAL_SWITCH' );

		S_teststep_2nd_level( "Evaluate for number of data bytes", 'AUTO_NBR', 'edr_length_' . $recordNbr );
		my $detected_length = scalar(@$readEDR_response_aref) - 3;
		S_teststep_expected( "Positive response shall be obtained followed by $tcpar_NbrOfDataByte EDR data bytes", 'edr_length_' . $recordNbr );    #evaluation 1
		S_teststep_detected( "Detected $detected_length data byte", 'edr_length_' . $recordNbr );
		EVAL_evaluate_value( "Data length of EDR data", $detected_length, '==', $tcpar_NbrOfDataByte );

		S_teststep_2nd_level( "Evaluate for data response do not having all 'FF' value", 'AUTO_NBR', 'edr_value_' . $recordNbr );
		my $count = 0;
		foreach (@$readEDR_response_aref) {
			if ( $_ eq 'FF' ) {
				$count++;
			}
		}
		S_teststep_expected( "Not all data response having same  value 'FF'", 'edr_value_' . $recordNbr );                                           #evaluation 1
		S_teststep_detected( "Detected '$count' byte of data equal to 'FF'", 'edr_value_' . $recordNbr );
		EVAL_evaluate_value( "Value of EDR data", $count, '<', $tcpar_NbrOfDataByte );
	}

	S_teststep( "Clear all stored EDR", 'AUTO_NBR' );
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(10000);
	S_teststep( "send request '$tcpar_Read_ChinaEDR' and check obtained response", 'AUTO_NBR', 'send_request_read_B' );                              #measurement 2
	foreach my $recordNbr ( 1 .. $tcpar_NumberOfCrashes ) {

		S_teststep_2nd_level( "send request read ChinaEDR section $recordNbr ", 'AUTO_NBR', 'read_edr_empty_' . $recordNbr );
		my $readEDR_response_aref = _read_EDR_record( $recordNbr, undef, 'EVAL_SWITCH' );

		S_teststep_2nd_level( "Evaluate for number of data bytes", 'AUTO_NBR', 'edr_length_empty_' . $recordNbr );
		my $detected_length = scalar(@$readEDR_response_aref) - 3;
		S_teststep_expected( "Positive response shall be obtained followed by $tcpar_NbrOfDataByte EDR data bytes", 'edr_length_empty_' . $recordNbr );    #evaluation 2
		S_teststep_detected( "Detected $detected_length data byte", 'edr_length_empty_' . $recordNbr );
		EVAL_evaluate_value( "Data length of EDR data", $detected_length, '==', $tcpar_NbrOfDataByte );

		S_teststep_2nd_level( "Evaluate for data response having all 'FF' value", 'AUTO_NBR', 'edr_value_empty_' . $recordNbr );
		my $count = 0;
		foreach (@$readEDR_response_aref) {
			if ( $_ eq 'FF' ) {
				$count++;
			}
		}
		S_teststep_expected( "All data response having same  value 'FF'", 'edr_value_empty_' . $recordNbr );                                               #evaluation 2
		S_teststep_detected( "Detected '$count' byte of data equal to 'FF'", 'edr_value_empty_' . $recordNbr );
		EVAL_evaluate_value( "Value of EDR data", $count, '==', $tcpar_NbrOfDataByte );
	}

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
	PD_ECUlogin();
	S_wait_ms(2000);

	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

sub _read_EDR_record {

	my $edrEntry_nbr       = shift;
	my $expectedResponse   = shift;
	my $evaluationRequired = shift;

	my $requestLabel;
	$requestLabel = $tcpar_Read_ChinaEDR . '0' . $edrEntry_nbr;

	S_w2log( 3, "\n Sending Diag request to read EDR Entry $edrEntry_nbr \n" );

	unless ( defined $expectedResponse ) {
		$expectedResponse = "PR_$requestLabel";
	}
	my $noEvalSwitch;
	$noEvalSwitch = 'NO_EVAL_SWITCH' unless ( defined $evaluationRequired );

	# Send the diagnosis request via GDCOM
	my $response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	unless ($response) {
		S_wait_ms(2000);
		S_w2log( 2, "Try to read service again after short wait time" );
		$response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	}

	# In case of offline run, no response will be recieved
	return [] if $main::opt_offline;

	# Convert the received diagnosis response (string with hex values, each byte separated by space!) to array of bytes
	my @responseBytes = split( / /, $response );

	return \@responseBytes;
}

1;
