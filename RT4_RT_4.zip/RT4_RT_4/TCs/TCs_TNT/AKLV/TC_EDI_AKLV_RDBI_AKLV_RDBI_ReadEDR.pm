#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_AKLV_RDBI_ReadEDR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER =  q$Header: AKLV/TC_EDI_AKLV_RDBI_AKLV_RDBI_ReadEDR.pm 1.5 2019/11/19 18:22:23ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use INCLUDES_Project;
use LIFT_CD;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use FuncLib_CustLib_DIAG;
##################################

our $PURPOSE = "To check Reading of different EDR entries";
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_AKLV_RDBI_ReadEDR

=head1 PURPOSE

"To check Reading of different EDR entries"

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1.Send Request to enter session [enterSession::<Session_to_be_entered1>] 

2.Inject 6 crashes

3.Iterate step 3 and step 4 for each values of <EDR_EntryToProcess> 

4.Send start routine control request [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>,<EDR_EntryToProcess>] 

5.Get the Security access [getSecurity ::<Security_Key>]

6.Send array of requests to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>


I<B<Evaluation>>

1.Send Request to enter session [enterSession::<Session_to_be_entered1>] 

2.Inject 6 crashes

3.Iterate step 3 and step 4 for each values of <EDR_EntryToProcess> 

4.Send start routine control request [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>,<EDR_EntryToProcess>] 

5.Get the Security access [getSecurity ::<Security_Key>]

6.Send array of requests to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>

Note: Number of EDR entries shall be configurable by project. If theEDR entry is not supported NRC shall be returned


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 'To check Reading of different EDR entries'
	SCALAR 'SelectedFunction' => CalculateSignature
	SCALAR 'Security_Key' => 'Level3_23'
	SCALAR 'Session_to_be_entered1' => 'ExtendedSession'
	LIST 'EDR_EntryToProcess' => @('01','02','03','04','05','06','81', '82', '83', '84', '85', '86')
	LIST 'EDR_Entries' => @('01','02','03','04','05','06','81', '82', '83', '84', '85', '86')


=head2 PARAMETER EXAMPLES

	purpose = 'To check Reading of different EDR entries'
	
	SelectedFunction = <Test Heading>
	
	Security_Key = 'Level3_23'
	
	Session_to_be_entered1 = 'ExtendedSession'
	
	EDR_EntryToProcess = @('01','02','03','04','05','06','81', '82', '83', '84', '85', '86')
	
	EDR_Entries = @('01','02','03','04','05','06','81', '82', '83', '84', '85', '86')

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SelectedFunction;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered1;
my @tcpar_EDR_EntryToProcess;
my @tcpar_EDR_Entries;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
my $count=0;
my @EDRHeaderValue;
my @crashes;
my $crashStatus;



###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_SelectedFunction =  GEN_Read_mandatory_testcase_parameter( 'SelectedFunction' );
	$tcpar_Security_Key =  GEN_Read_mandatory_testcase_parameter( 'Security_Key' );
	$tcpar_Session_to_be_entered1 =  GEN_Read_mandatory_testcase_parameter( 'Session_to_be_entered1' );
	@tcpar_EDR_EntryToProcess =  GEN_Read_mandatory_testcase_parameter( 'EDR_EntryToProcess' );
	@tcpar_EDR_Entries =  GEN_Read_mandatory_testcase_parameter( 'EDR_Entries' );
	$tcpar_CrashScenarioList        = S_read_mandatory_testcase_parameter('CrashScenarioList', 'byref');
	$tcpar_ResultDB                 = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                 = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	return 1;
}

sub TC_initialization {

	GEN_printTestStep("Standard_Preparaion");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	GEN_printTestStep("Step 1.Send Request to enter session ");
	
	GDCOM_StartSession ($tcpar_Session_to_be_entered1,'CheckActiveSession');

	GEN_printTestStep("Step 2.Inject 6 crashes");
	
	##########Crash Injection Started##########
	foreach my $crashCode (@$tcpar_CrashScenarioList) {

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_teststep_2nd_level( "Get crash settings for crash $crashCode", 'AUTO_NBR' );
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		#--------------------------------------------------------------
		# CRASH PREPARATION
		#
		S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# CRASH INJECTION
		#

		S_teststep_2nd_level( "Inject crash '$crashCode'", 'AUTO_NBR' );
		CSI_TriggerCrash();
		S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
		S_wait_ms(10000);
	}
	
	##########Crash Injection Completed##########

	#GEN_printTestStep("Step 3.Iterate step 3 and step 4 for each values of '$tcpar_EDR_EntryToProcess' ");

	GEN_printTestStep("Step 4.Send start routine control request ");

	##########Calculating Signature or CRC##########
	
	if($tcpar_SelectedFunction eq 'CalculateSignature') #Calculating Signature
	
	{
		foreach my $EDR_EntryToProcess_Sign(@tcpar_EDR_EntryToProcess)
		{
			my $signRoutineResult_Success = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_Sign);
			
			EVAL_evaluate_value("Checking Result",@$signRoutineResult_Success[6],'==','0x80');
			
			GEN_printTestStep("Signature calculated Sucessfully");
		}
	}

	elsif($tcpar_SelectedFunction eq 'CalculateCRC') #Calculating CRC
	{
				foreach my $EDR_EntryToProcess_CRC(@tcpar_EDR_EntryToProcess)
				{
					
				my $CRCroutineResult_Success = DIAG_calculateCRC_CompletedSuccessfully($EDR_EntryToProcess_CRC);
			
				EVAL_evaluate_value("Checking Result",@$CRCroutineResult_Success[6],'==','0x80');
			
				GEN_printTestStep("CRC calculated Sucessfully");
				
				}
	}
	
	##########Signature or CRC calculation completed##########
	
		######Security Access Requesting##########
	
	GEN_printTestStep("Step 5.Get the Security access [getSecurity ::'$tcpar_Security_Key']");
	
	GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	
		##########Security Access Obtained##########
		
	##########Reading EDR Entries Both Generic & OEM##########	
	
	GEN_printTestStep("Step 6.Send array of requests to read EDR entries");
	
	foreach my $EDRResponse(@tcpar_EDR_Entries)
		{
			my $EDRDiagResponse=DIAG_readEDREntry($EDRResponse); #To Read EDR response
			
			my $EDRHeadResp=EDR_CD_readHeader($EDRDiagResponse); #To find Header information
			
			@EDRHeaderValue[$count]=@$EDRHeadResp[1]; #second byte of header information is saved to one array
			
			$count=$count+1;	
		}
		
		my $totalcount= $count; #Total array elements
		
		################Evaluvating Crash storage Criteria###############
		  	
		if(@EDRHeaderValue[$totalcount]==06 && @EDRHeaderValue[$totalcount-1]==05 && @EDRHeaderValue[$totalcount-2]==04 && @EDRHeaderValue[$totalcount-3]==03 && @EDRHeaderValue[$totalcount-4]==02 && @EDRHeaderValue[$totalcount-5]==01)
		{
			GEN_printTestStep("Crashes are stored in decenting order ");
		}
		
		###################Crash Storage Criteria Evaluvated###############				
	
	return 1;
}

sub TC_evaluation {

	GEN_printTestStep("Evaluation for Step 1 is completed at Test Stimulation");
	
	GEN_printTestStep("Crash Injected Sucessfully");

	GEN_printTestStep("Evaluation for Step 4 is completed at Test Stimulation");

	GEN_printTestStep("Evaluation for Step 5 is completed at Test Stimulation");

	GEN_printTestStep("Evaluation for Step 6 is completed at Test Stimulation");

	return 1;
}

sub TC_finalization {
	
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}


1;
