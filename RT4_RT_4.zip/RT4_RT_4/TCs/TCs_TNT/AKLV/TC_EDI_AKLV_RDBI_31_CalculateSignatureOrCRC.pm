#### TEST CASE MODULE

#EDR Diagnostics

package TC_EDI_AKLV_RDBI_31_CalculateSignatureOrCRC;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;
###-------------------------------
our $VERSION = q$Revision: 1.3 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_31_CalculateSignatureOrCRC.pm 1.3 2019/11/19 18:21:47ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;
##################################

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_PD;
use LIFT_CD;
use LIFT_labcar;
use LIFT_crash_simulation;
use GENERIC_DCOM;
use INCLUDES_Project;

##################################

our $PURPOSE = "To check for supported subfunctions associated with calculation of signature for each EDR Entry";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_31_CalculateSignatureOrCRC $Revision: 1.3 $

=head1 PURPOSE

To check for supported subfunctions associated with calculation of signature for each EDR Entry

=head1 TESTCASE DESCRIPTION

I<B<Initialisation>>

Standard Preparation


I<B<Stimulation and Measurement>>

1.Send Request to enter session [enterSession::Default]

2.Inject <Number_of_crashes> crashes 

3. Iterate step 5 and step 5 for each values of <EDR_EntryToProcess> 

4.Send start routine control request [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>]

5.Send routine result request [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition>

I<B<Evaluation>>

1. Session is entered

2. --

3. --

4. Positive response is Obtained with StartRoutineStateOfOperation As Running

5. Positive response is obtained with <RoutineResultStateOfOperation>

I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER

=head2 PARAMETER NAMES

	Scalar 'purpose' => Purpose of test case
	Scalar 'SelectedFunction' => Selected Function
	Scalar 'Condition' => Condition
	List 'EDR_EntryToProcess' => EDR_EntryToProcess
	Scalar 'Number_of_crashes' => Number of crashes to be injected
	Scalar 'RoutineResultStateOfOperation' => State of operation of Request Routine Results

=head2 PARAMETER EXAMPLES

purpose = 'To check for supported subfunctions associated with calculation of CRC for each EDR entry'
SelectedFunction = 'CalculateCRC'
EDR_EntryToProcess = @('01', '02', '03', '04', '05', '06')
Condition = 'Idle'
Number_of_crashes = 6
RoutineResultStateOfOperation ='0x00'
=cut

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DOCUMENTATION <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SelectedFunction;
my $tcpar_Condition;
my $tcpar_EDR_EntryToProcess;
my $tcpar_Number_of_crashes;
my $tcpar_RoutineResultStateOfOperation;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;
################ global parameter declaration ###################
#add any global variables here

my $CrashInjectionStatus;
my $RequestInfo;
my %SignRoutine_Reponse;
my %CRCRoutine_Reponse;
my $crashSettings;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose                       = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_SelectedFunction              = S_read_mandatory_testcase_parameter('SelectedFunction');
	$tcpar_Condition                     = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_EDR_EntryToProcess            = S_read_mandatory_testcase_parameter( 'EDR_EntryToProcess', 'byref' );
	$tcpar_Number_of_crashes             = S_read_mandatory_testcase_parameter('Number_of_crashes');
	$tcpar_RoutineResultStateOfOperation = S_read_mandatory_testcase_parameter('RoutineResultStateOfOperation');
	$tcpar_CrashScenarioList             = S_read_optional_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB                      = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                      = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

#### INITIALIZE TC #####
sub TC_initialization {
	S_teststep( "Standard_Preparation", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Step 1.Send Request to enter session [enterSession::Default]", 'AUTO_NBR' );
	GDCOM_StartSession( 'DefaultSession', 'CheckActiveSession' );

	S_teststep( "Step 2.Inject  $tcpar_Number_of_crashes crashes ", 'AUTO_NBR' );
	S_teststep_2nd_level( "Clear crash recorder before crash injection", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	if ( $tcpar_Number_of_crashes == 0 ) {
		S_w2rep( "No Crashes are injected  ", 'blue' );
	}
	elsif ( $tcpar_Number_of_crashes == 6 ) {
		S_w2rep( "Injecting Six Crashes  ", 'blue' );
		foreach (@$tcpar_CrashScenarioList) {

			#--------------------------------------------------------------
			# PREPARE CRASH AND INITIALIZE EQUIPMENT
			#
			S_w2rep("Get crash settings for crash $_");
			my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $_ };
			$crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
			unless ( defined $crashSettings ) {
				S_set_error("Crash $_ not available in result DB $tcpar_ResultDB. Test case aborted.");
				return;
			}

			my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
			my $resultDB_Path = $resultDBDetails->{'PATH'};
			S_w2log( 1, "Crashcode: $_, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

			S_w2log( 1, "Set environments for crash as per result DB" );
			CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
			S_wait_ms(2000);

			#--------------------------------------------------------------
			# CRASH PREPARATION
			#
			S_teststep( "Prepare crash", 'AUTO_NBR' );
			LC_ECU_Off();
			S_wait_ms('TIMER_ECU_OFF');

			# Prepare crash
			CSI_LoadCrashSensorData2Simulator($crashSettings);

			# Power ON the ECU
			LC_ECU_On();
			S_wait_ms('TIMER_ECU_READY');

			#--------------------------------------------------------------
			# CRASH INJECTION
			#

			S_teststep( "Inject crash '$_'", 'AUTO_NBR' );
			CSI_TriggerCrash();
			S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
			S_wait_ms(10000);
		}
		#--------------------------------------------------------------
		# CRASH INJECTIONS SECTION IS COMPLETED
		#
				
	}   				
	else				 {
		S_set_error( "No Of Crashes is Invalid!", 114 );
		return 0;
	}
	S_teststep( "Step 3. Iterate step 4 and step 5 for each value of EDR Entry and in all supported sessions [DefaultSession, Extended Session,EOL Session,Development Session] ", 'AUTO_NBR' );
	if ( $tcpar_SelectedFunction eq 'CalculateSignature' ) {
		$RequestInfo = GDCOM_getRequestInfofromMapping( "RoutineControl_EDRCalculateSignature_StartRoutine", 'AUTO_NBR' );
		foreach my $session ( @{ $RequestInfo->{'allowed_in_sessions'} } ) {
			S_w2rep( "Performing Signature in : $session ", 'AUTO_NBR' );
			GDCOM_StartSession( $session, 'CheckActiveSession' );
			foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
				S_teststep( "Step 4.Send  start routine control request  for Signature of EDR Entry : $EDR_EntryToProcess_Sign",    'AUTO_NBR' );
				S_teststep( "Step 5.Send  routine result request for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition", 'AUTO_NBR' );
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
				my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperation", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperation );

			}
		}
	}
	elsif ( $tcpar_SelectedFunction eq 'CalculateCRC' ) {
		$RequestInfo = GDCOM_getRequestInfofromMapping( "RoutineControl_EDRCalculateSignature_StartRoutine", 'AUTO_NBR' );
		foreach my $session ( @{ $RequestInfo->{'allowed_in_sessions'} } ) {
			S_w2rep( "Performing CRC in  : $session ", 'AUTO_NBR' );
			GDCOM_StartSession( $session, 'CheckActiveSession' );
			foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {
				S_teststep( "Step 4.Send  start routine control request  for CRC of EDR Entry : $EDR_EntryToProcess_CRC",          'AUTO_NBR' );
				S_teststep( "Step 5.Send  routine result request for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition", 'AUTO_NBR' );
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
				my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperation", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperation );
			}
		}
	}
	else {
		S_set_error( "Selected Function is Invalid!", 114 );
		return 0;
	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. Session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 2.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 3.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 4. Positive response is  obtained with StartRoutineStateOfOperation As Running", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 5. Positive response  is  obtained with $tcpar_RoutineResultStateOfOperation", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	return 1;
}

#### TC FINALIZATION #####
sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

1;

__END__
