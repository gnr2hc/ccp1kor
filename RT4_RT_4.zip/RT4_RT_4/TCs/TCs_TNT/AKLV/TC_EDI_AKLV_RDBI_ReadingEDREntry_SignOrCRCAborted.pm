#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingEDREntry_SignOrCRCAborted;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingEDREntry_SignOrCRCAborted.pm 1.4 2019/11/19 18:22:53ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_evaluation;
use LIFT_crash_simulation;
use LIFT_labcar;

##################################

our $PURPOSE = "To test the reading generic and OEM specific EDR entries by aborting either signature or CRC";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingEDREntry_SignOrCRCAborted

=head1 PURPOSE

To test the reading generic and OEM specific EDR entries by aborting either signature or CRC

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send Request to enter session [enterSession::<Session_to_be_entered1>] 

2. Inject a Six Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, RearNonInflatableDeployment, RolloverInflatableDeployment, FrontInflatableDeployment]

3. Iterate step 4 to step 7 for each values of <EDR_EntryToProcess> 

4. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction1>, <EDR_EntryToProcess>] 

5. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition1>

6. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction2>, <EDR_EntryToProcess>] 

7. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition2>

8. Send Request to enter session [enterSession::<Session_to_be_entered2>] 

9. Get the Security  access  [getSecurity ::<Security_Key>]

10. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>


I<B<Evaluation>>

1. Session is entered

2. Crashs are injected Successfully 

3. -- 

4. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

5. Positive response is obtained for each request with <RoutineResultStateOfOperarion_Sign> 

6. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

7. Positive response is obtained for each request with <RoutineResultStateOfOperarion_CRC>

8. Session is entered

9. 

10. Responses_Array is   obtained  
	Responses_Array =@('EDRentryWithoutCRC_06','EDRentryWithoutCRC_06','EDRentryWithoutCRC_04,'EDRentryWithoutCRC_03','EDRentryWithoutCRC_02','EDRentryWithoutCRC_01')


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	LIST 'EDR_EntryToProcess' => EDR Entry to calculate signature or CRC
	SCALAR 'Security_Key' => NONE, Level3_23
	SCALAR 'Session_to_be_entered1' => Session to be entered
	SCALAR 'Session_to_be_entered2' => Session to be entered
	LIST 'EDR_Entries' => Generic EDR Entries or OEM Specific EDR entries
	SCALAR 'SelectedFunction1' => Selected function either signature or CRC
	SCALAR 'Condition1' => Condition to calculate signature or CRC
	SCALAR 'SelectedFunction2' => Selected function either signature or CRC
	SCALAR 'Condition2' => Condition to calculate signature or CRC
	SCALAR 'RoutineResultStateOfOperarion_Sign' => Status of the Routine Result for Signature 
	SCALAR 'RoutineResultStateOfOperarion_CRC' => Status of the Routine Result for CRC


=head2 PARAMETER EXAMPLES

	purpose = 'To check  for reading different generic EDR entries by aborting either signature or CRC'	
	EDR_EntryToProcess = @('01', '02','03','04','05','06')
	Security_Key = 'NONE'
	Session_to_be_entered1 ='ExtendedSession'
	Session_to_be_entered2 = 'ExtendedSession'
	EDR_Entries = @('01', '02','03','04','05','06')	
	SelectedFunction1 = 'CalculateSignature'
	Condition1 = 'CompletedSuccessfully'	
	SelectedFunction2 = 'CalculateCRC'
	Condition2  = 'AbortedByClient'	
	RoutineResultStateOfOperarion_Sign = '0x80'
	RoutineResultStateOfOperarion_CRC = '0x81'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_EDR_EntryToProcess;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered1;
my $tcpar_Session_to_be_entered2;
my $tcpar_EDR_Entries;
my $tcpar_SelectedFunction1;
my $tcpar_Condition1;
my $tcpar_SelectedFunction2;
my $tcpar_Condition2;
my %Responses_Hash;
my $tcpar_RoutineResultStateOfOperarion_Sign;
my $tcpar_RoutineResultStateOfOperarion_CRC;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
#add any global variables here

my %EDR_Reponse;
my %SignRoutine_Reponse;
my %CRCRoutine_Reponse;
my $CrashInjectionStatus;
my $requestLabel;
my %EDR_SignatureEDIDData;
my %EDR_CRCEDIDData;
my %EDR_EventCounterEDIDData;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                            = GEN_Read_mandatory_testcase_parameter('purpose');
	$tcpar_EDR_EntryToProcess                 = GEN_Read_mandatory_testcase_parameter( 'EDR_EntryToProcess', 'byref' );
	$tcpar_Security_Key                       = GEN_Read_mandatory_testcase_parameter('Security_Key');
	$tcpar_Session_to_be_entered1             = GEN_Read_mandatory_testcase_parameter('Session_to_be_entered1');
	$tcpar_Session_to_be_entered2             = GEN_Read_mandatory_testcase_parameter('Session_to_be_entered2');
	$tcpar_EDR_Entries                        = GEN_Read_mandatory_testcase_parameter( 'EDR_Entries', 'byref' );
	$tcpar_SelectedFunction1                  = GEN_Read_mandatory_testcase_parameter('SelectedFunction1');
	$tcpar_Condition1                         = GEN_Read_mandatory_testcase_parameter('Condition1');
	$tcpar_SelectedFunction2                  = GEN_Read_mandatory_testcase_parameter('SelectedFunction2');
	$tcpar_Condition2                         = GEN_Read_mandatory_testcase_parameter('Condition2');
	$tcpar_RoutineResultStateOfOperarion_Sign = GEN_Read_mandatory_testcase_parameter('RoutineResultStateOfOperarion_Sign');
	$tcpar_RoutineResultStateOfOperarion_CRC  = GEN_Read_mandatory_testcase_parameter('RoutineResultStateOfOperarion_CRC');
	$tcpar_CrashScenarioList                  = S_read_mandatory_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB                           = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                           = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparaion", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Step 1.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered1] ", 'AUTO_NBR' );
	GDCOM_StartSession( $tcpar_Session_to_be_entered1, 'CheckActiveSession' );

	############### Injecting Crash ###################
	S_teststep( "Step 2. Inject a Six Deployment Crashes [FrontInflatableDeployment, SideDriverInflatableDeployment, SidePassengerInflatableDeployment, RearNonInflatableDeployment, RolloverInflatableDeployment, FrontInflatableDeployment]", 'AUTO_NBR' );
	S_teststep_2nd_level( "Clear crash recorder before crash injection", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	foreach (@$tcpar_CrashScenarioList) {

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_w2rep("Get crash settings for crash $_");
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $_ };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $_ not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $_, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		#--------------------------------------------------------------
		# CRASH PREPARATION
		#
		S_teststep( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# CRASH INJECTION
		#

		S_teststep( "Inject crash '$_'", 'AUTO_NBR' );
		CSI_TriggerCrash();
		S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
		S_wait_ms(10000);

		#--------------------------------------------------------------
		# CRASH INJECTIONS SECTION IS COMPLETED
		#
	}
	S_teststep( "Step 3.Iterate step 4 to step 7 for each values of EDR Entry ", 'AUTO_NBR' );
	if ( $tcpar_SelectedFunction1 eq 'CalculateSignature' ) {
		foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
			S_teststep( "Step 4.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign",                    'AUTO_NBR' );
			S_teststep( "Step 5.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition1 ", 'AUTO_NBR' );
			$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition1 );
			my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
			EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion_Sign ) if ( defined @$SignatureResponse[6] );
		}
	}
	else {
		S_set_error( " Selected Function is Invalid!", 0 );
	}

	if ( $tcpar_SelectedFunction2 eq 'CalculateCRC' ) {
		foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {
			S_teststep( "Step 6.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC",                    'AUTO_NBR' );
			S_teststep( "Step 7.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition2 ", 'AUTO_NBR' );
			$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition2 );
			my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
			EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion_CRC ) if ( defined @$CRCResponse[6] );
		}
	}
	else {
		S_set_error( " Selected Function is Invalid!", 0 );
	}

	S_teststep( "Step 8.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered2] ", 'AUTO_NBR' );
	if ( $tcpar_Session_to_be_entered2 eq 'DevelopmentSession' ) {
		GDCOM_StartSession( 'ExtendedSession',             'CheckActiveSession' );
		GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
	}
	else {
		GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
	}

	S_teststep( "Step 9.Get the Security  access  [getSecurity ::$tcpar_Security_Key]", 'AUTO_NBR' );
	if ( $tcpar_Security_Key eq 'NONE' ) {
		S_w2rep( 'SA is Not Required', 'blue' );
	}
	else {
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}

	############### Reading the EDR Entry   ###################

	foreach my $EDREntries (@$tcpar_EDR_Entries) {
		$requestLabel = 'ReadDatabyID_FA13_GenericEDREntry' if ( $EDREntries == 01 );
		$requestLabel = 'ReadDatabyID_FA14_GenericEDREntry' if ( $EDREntries == 02 );
		$requestLabel = 'ReadDatabyID_FA15_GenericEDREntry' if ( $EDREntries == 03 );
		$requestLabel = 'ReadDatabyID_FA16_GenericEDREntry' if ( $EDREntries == 04 );
		$requestLabel = 'ReadDatabyID_FA17_GenericEDREntry' if ( $EDREntries == 05 );
		$requestLabel = 'ReadDatabyID_FA18_GenericEDREntry' if ( $EDREntries == 06 );
		$requestLabel = 'ReadDatabyID_1013_OEMEDREntry'     if ( $EDREntries == 81 );
		$requestLabel = 'ReadDatabyID_1014_OEMEDREntry'     if ( $EDREntries == 82 );
		$requestLabel = 'ReadDatabyID_1015_OEMEDREntry'     if ( $EDREntries == 83 );
		$requestLabel = 'ReadDatabyID_1016_OEMEDREntry'     if ( $EDREntries == 84 );
		$requestLabel = 'ReadDatabyID_1017_OEMEDREntry'     if ( $EDREntries == 85 );
		$requestLabel = 'ReadDatabyID_1018_OEMEDREntry'     if ( $EDREntries == 86 );

		S_teststep( "Step 10. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );

		if ( ( $tcpar_SelectedFunction1 eq 'CalculateSignature' ) and ( $tcpar_Condition1 eq 'CompletedSuccessfully' ) and ( $tcpar_SelectedFunction2 eq 'CalculateCRC' ) and ( $tcpar_Condition2 eq 'AbortedByClient' ) ) {
			$Responses_Hash{$EDREntries} = DIAG_readEDREntry($EDREntries);

			if ( $EDREntries == 01 or $EDREntries == 02 or $EDREntries == 03 or $EDREntries == 04 or $EDREntries == 05 or $EDREntries == 06 ) {

				############### Checking the CRC & Sign ###################
				$EDR_SignatureEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1023 );
				my @SignatureEDIDData = @{ $EDR_SignatureEDIDData{$EDREntries} };
				S_w2rep( " Signature EDID Data is : @SignatureEDIDData ", 'blue' );
				unless ( scalar(@SignatureEDIDData) ) {
					S_set_error( "Signature is Not Reported in the reposne", 114 );
				}

				$EDR_CRCEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1022 );
				my @CRCEDIDData = @{ $EDR_CRCEDIDData{$EDREntries} };
				S_w2rep( " CRC  EDID Data is : @CRCEDIDData ", 'blue' );
				if ( scalar(@CRCEDIDData) ) {
					S_set_error( "CRC is Reported in the  Generic EDR reposne", 114 );
				}
				else {
					S_w2rep( " CRC is not Reported in the Generic EDR Response", 'blue' );
				}

				############### Checking the CRC & Sign is completed ###################

				############### Checking the EventCounter   ###################
				$EDR_EventCounterEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1021 );
				my @EventCounterEDIDData = @{ $EDR_EventCounterEDIDData{$EDREntries} };

				if ( $EDREntries == 01 ) {
					my @EventCounter_06 = ( '00', '06' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_06, 'Equal' );
				}
				elsif ( $EDREntries == 02 ) {
					my @EventCounter_05 = ( '00', '05' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_05, 'Equal' );
				}
				elsif ( $EDREntries == 03 ) {
					my @EventCounter_04 = ( '00', '04' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_04, 'Equal' );
				}
				elsif ( $EDREntries == 04 ) {
					my @EventCounter_03 = ( '00', '03' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_03, 'Equal' );
				}
				elsif ( $EDREntries == 05 ) {
					my @EventCounter_02 = ( '00', '02' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_02, 'Equal' );
				}
				elsif ( $EDREntries == 06 ) {
					my @EventCounter_01 = ( '00', '01' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_01, 'Equal' );
				}
				else {
					S_set_error( " EDREntries is Invalid!", 0 );
				}
				############### Checking the EventCounter  is completed ###################

			}
			else {
				############### Checking the CRC & Sign ###################
				$EDR_SignatureEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1023, 'OEM' );
				my @SignatureEDIDData = @{ $EDR_SignatureEDIDData{$EDREntries} };
				S_w2rep( " Signature EDID Data is : @SignatureEDIDData ", 'blue' );
				unless ( scalar(@SignatureEDIDData) ) {
					S_set_error( "Signature is Not Reported in the reposne", 114 );
				}

				$EDR_CRCEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1022, 'OEM' );
				my @CRCEDIDData = @{ $EDR_CRCEDIDData{$EDREntries} };
				S_w2rep( " CRC  EDID Data is : @CRCEDIDData ", 'blue' );
				if ( scalar(@CRCEDIDData) ) {
					S_set_error( "CRC is Reported in the OEM EDR reposne", 114 );
				}
				else {
					S_w2rep( " CRC is not Reported in theOEM EDR Response", 'blue' );
				}
				############### Checking the CRC & Sign is completed ###################

				############### Checking the EventCounter ###################
				$EDR_EventCounterEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1021, 'OEM' );
				my @EventCounterEDIDData = @{ $EDR_EventCounterEDIDData{$EDREntries} };

				if ( $EDREntries == 81 ) {
					my @EventCounter_06 = ( '00', '06' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_06, 'Equal' );
				}
				elsif ( $EDREntries == 82 ) {
					my @EventCounter_05 = ( '00', '05' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_05, 'Equal' );
				}
				elsif ( $EDREntries == 83 ) {
					my @EventCounter_04 = ( '00', '04' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_04, 'Equal' );
				}
				elsif ( $EDREntries == 84 ) {
					my @EventCounter_03 = ( '00', '03' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_03, 'Equal' );
				}
				elsif ( $EDREntries == 85 ) {
					my @EventCounter_02 = ( '00', '02' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_02, 'Equal' );
				}
				elsif ( $EDREntries == 86 ) {
					my @EventCounter_01 = ( '00', '01' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_01, 'Equal' );
				}
				else {
					S_set_error( " EDREntries is Invalid!", 0 );
				}
				############### Checking the EventCounter  is completed ###################

			}

		}
		elsif ( ( $tcpar_SelectedFunction1 eq 'CalculateSignature' ) and ( $tcpar_Condition1 eq 'CompletedSuccessfully' ) and ( $tcpar_SelectedFunction2 eq 'CalculateCRC' ) and ( $tcpar_Condition2 eq 'AbortedByDetectedFailure' ) ) {
			GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' );
		}
		elsif ( ( $tcpar_SelectedFunction1 eq 'CalculateSignature' ) and ( $tcpar_Condition1 eq 'AbortedByClient' ) and ( $tcpar_SelectedFunction2 eq 'CalculateCRC' ) and ( $tcpar_Condition2 eq 'CompletedSuccessfully' ) ) {
			$Responses_Hash{$EDREntries} = DIAG_readEDREntry($EDREntries);

			if ( $EDREntries == 01 or $EDREntries == 02 or $EDREntries == 03 or $EDREntries == 04 or $EDREntries == 05 or $EDREntries == 06 ) {
				############### Checking the CRC & Sign   ###################
				$EDR_CRCEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1022 );
				my @CRCEDIDData = @{ $EDR_CRCEDIDData{$EDREntries} };
				S_w2rep( " CRC  EDID Data is : @CRCEDIDData ", 'blue' );
				unless ( scalar(@CRCEDIDData) ) {
					S_set_error( "CRC is Not Reported in the reposne", 114 );
				}

				$EDR_SignatureEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1023 );
				my @SignatureEDIDData = @{ $EDR_SignatureEDIDData{$EDREntries} };
				S_w2rep( " Signature EDID Data is : @SignatureEDIDData ", 'blue' );
				if ( scalar(@SignatureEDIDData) ) {
					S_set_error( "Signature  is Reported in the Generic  EDR reposne", 114 );
				}
				else {
					S_w2rep( " Signature is not Reported in the Generic EDR Response", 'blue' );
				}

				############### Checking the CRC & Sign is completed ###################

				############### Checking the EventCounter   ###################
				$EDR_EventCounterEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1021 );
				my @EventCounterEDIDData = @{ $EDR_EventCounterEDIDData{$EDREntries} };

				if ( $EDREntries == 01 ) {
					my @EventCounter_06 = ( '00', '06' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_06, 'Equal' );
				}
				elsif ( $EDREntries == 02 ) {
					my @EventCounter_05 = ( '00', '05' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_05, 'Equal' );
				}
				elsif ( $EDREntries == 03 ) {
					my @EventCounter_04 = ( '00', '04' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_04, 'Equal' );
				}
				elsif ( $EDREntries == 04 ) {
					my @EventCounter_03 = ( '00', '03' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_03, 'Equal' );
				}
				elsif ( $EDREntries == 05 ) {
					my @EventCounter_02 = ( '00', '02' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_02, 'Equal' );
				}
				elsif ( $EDREntries == 06 ) {
					my @EventCounter_01 = ( '00', '01' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_01, 'Equal' );
				}
				else {
					S_set_error( " EDREntries is Invalid!", 0 );
				}
				############### Checking the EventCounter  is completed ###################

			}
			else {
				############## Checking the CRC & Sign is completed ###################
				$EDR_CRCEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1022, 'OEM' );
				my @CRCEDIDData = @{ $EDR_CRCEDIDData{$EDREntries} };
				S_w2rep( " CRC  EDID Data is : @CRCEDIDData ", 'blue' );
				unless ( scalar(@CRCEDIDData) ) {
					S_set_error( "CRC is Not Reported in the reposne", 114 );
				}

				$EDR_SignatureEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1023, 'OEM' );
				my @SignatureEDIDData = @{ $EDR_SignatureEDIDData{$EDREntries} };
				S_w2rep( " Signature EDID Data is : @SignatureEDIDData ", 'blue' );
				if ( scalar(@SignatureEDIDData) ) {
					S_set_error( "Signature  is Reported in the OEM EDR reposne", 114 );
				}
				else {
					S_w2rep( " Signature is not Reported in the OEM EDR Response", 'blue' );
				}
				############### Checking the CRC & Sign is completed ###################

				############### Checking the EventCounter ###################
				$EDR_EventCounterEDIDData{$EDREntries} = EDR_CD_getEDIDdata( $Responses_Hash{$EDREntries}, 1021, 'OEM' );
				my @EventCounterEDIDData = @{ $EDR_EventCounterEDIDData{$EDREntries} };

				if ( $EDREntries == 81 ) {
					my @EventCounter_06 = ( '00', '06' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_06, 'Equal' );
				}
				elsif ( $EDREntries == 82 ) {
					my @EventCounter_05 = ( '00', '05' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_05, 'Equal' );
				}
				elsif ( $EDREntries == 83 ) {
					my @EventCounter_04 = ( '00', '04' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_04, 'Equal' );
				}
				elsif ( $EDREntries == 84 ) {
					my @EventCounter_03 = ( '00', '03' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_03, 'Equal' );
				}
				elsif ( $EDREntries == 85 ) {
					my @EventCounter_02 = ( '00', '02' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_02, 'Equal' );
				}
				elsif ( $EDREntries == 86 ) {
					my @EventCounter_01 = ( '00', '01' );
					S_w2rep( " Checking the Event Counter Of EDR Entry : $EDREntries ", 'blue' );
					GEN_EVAL_CompareNumArrays( \@EventCounterEDIDData, \@EventCounter_01, 'Equal' );
				}
				else {
					S_set_error( " EDREntries is Invalid!", 0 );
				}
				############### Checking the EventCounter  is completed ###################

			}
		}
		elsif ( ( $tcpar_SelectedFunction1 eq 'CalculateSignature' ) and ( $tcpar_Condition1 eq 'AbortedByDetectedFailure' ) and ( $tcpar_SelectedFunction2 eq 'CalculateCRC' ) and ( $tcpar_Condition2 eq 'CompletedSuccessfully' ) ) {
			GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' );
		}
		else {
			S_set_error( "Conditions are invalid", 114 );

		}
	}

	############### Reading the EDR Entry is Completed ###################
	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. Session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 2. Crashs are injected Successfully ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 3. - ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 4. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 5. Positive response is obtained for each request with $tcpar_RoutineResultStateOfOperarion_Sign ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 6. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 7. Positive response is obtained for each request with $tcpar_RoutineResultStateOfOperarion_CRC", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 8. Session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 9. ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 10. Responses_Array is   obtained  ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

1;
