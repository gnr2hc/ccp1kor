#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_NRC_Preconditions_NotFulfilled;

#### DONT MODifY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.5 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_NRC_Preconditions_NotFulfilled.pm 1.5 2019/11/19 18:22:34ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_CD;
use INCLUDES_Project;
use LIFT_PD;
use GENERIC_DCOM;
use LIFT_evaluation;
use FuncLib_CustLib_DIAG;
use LIFT_crash_simulation;
use LIFT_labcar;

##################################

our $PURPOSE = "To Test for response when one of the preconditions is not fulfilled";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_NRC_Preconditions_NotFulfilled

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparaion


I<B<Stimulation and Measurement>>

1.Send Request to enter session [enterSession::Development]

2.Send  start routine control request  <Routine_Control> 

3. Read EDR Entry <SelectedFunction>


I<B<Evaluation>>

1.

2. 

3. Reading EDR is successful if <Routine_Control> supported by the project.else it should return NRC


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 'To Test for response when one of the preconditions is not fulfilled'
	SCALAR 'Condition' => 'CRCandSignature'
	LIST 'SelectedFunction' => @('01','02','03','04','82')
	SCALAR 'StopRoutineResponse_Type' => StopRoutineResponse_Type


=head2 PARAMETER EXAMPLES

	purpose = 'To Test for response when one of the preconditions is not fulfilled'
	
	Condition ='<Test Heading>'
	SelectedFunction = @('01','02','03','04','82')
	StopRoutineResponse_Type = 'NR_requestOutOfRange'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Condition;
my $tcpar_SelectedFunction;
my $tcpar_StopRoutineResponse_Type;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
my @EDR_Entries;
my $Security_Key = 'Level3_21';
my %EDRData;
my $EDRResponse;
my $EDR_EntryToProcess_Sign;
my $EDR_EntryToProcess_CRC;
my $finalResponse;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                  = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_Condition                = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_SelectedFunction         = S_read_mandatory_testcase_parameter('SelectedFunction');
	$tcpar_StopRoutineResponse_Type = S_read_mandatory_testcase_parameter('StopRoutineResponse_Type');
	$tcpar_CrashScenarioList        = S_read_mandatory_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB                 = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                 = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparaion", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Step 1.Send Request to enter session [enterSession::Development]", 'AUTO_NBR' );
	GDCOM_StartSession( 'ExtendedSession', 'CheckActiveSession' );
	S_teststep( "Injecting Six Crashes to read EDR entry", 'AUTO_NBR' );
	@EDR_Entries = ( 01, 02, 03, 04, 05, 06, 81, 82, 83, 84, 85, 86 );
	S_teststep_2nd_level( "Clear crash recorder before crash injection", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	foreach my $crashCode (@$tcpar_CrashScenarioList) {

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_teststep_2nd_level( "Get crash settings for crash $crashCode", 'AUTO_NBR' );
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		#--------------------------------------------------------------
		# CRASH PREPARATION
		#
		S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# CRASH INJECTION
		#

		S_teststep_2nd_level( "Inject crash '$crashCode'", 'AUTO_NBR' );
		CSI_TriggerCrash();
		S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
		S_wait_ms(10000);
	}
	##################CRASH Injection Completed###############################################

	S_teststep( "Step 2.Send  start routine control request", 'AUTO_NBR' );

	S_teststep( "Step 3. Read EDR Entry ", 'AUTO_NBR' );

	if ( $tcpar_Condition eq 'Signatureonly' ) {
		S_teststep("Performing Signature Calculation");

		foreach $EDR_EntryToProcess_Sign (@EDR_Entries) {
			my $signRoutineResult_Success = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$signRoutineResult_Success[6], '==', '0x80' );

			S_teststep( "Reading EDR entry for Signature calculated Sucessfully", 'AUTO_NBR' );

			S_teststep( "Security access Approval", 'AUTO_NBR' );

			GDCOM_SecurityAccess_Unlock($Security_Key);

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

			}

			my $signRoutineResult_AbortedByClient = DIAG_calculateSignature_AbortedByClient($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$signRoutineResult_AbortedByClient[6], '==', '0x81' );

			S_teststep( "Reading EDR entry for Signature calculated Aborted by Client", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

			}

			my $signRoutineResult_AbortedByFailure = DIAG_calculateSignature_AbortedByDetectedFailure($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$signRoutineResult_AbortedByFailure[6], '==', '0x82' );

			S_teststep( "Reading EDR entry for Signature calculated Aborted by Failure", 'AUTO_NBR' );

			foreach my $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is received as NRC 24", @$finalResponse[2], '==', '0x24' );

			}

			my $signRoutineResult_Running = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'Running' );

			EVAL_evaluate_value( "Checking Result", @$signRoutineResult_Running[6], '==', '0x01' );

			S_teststep( "Reading EDR entry for Signature calculated While Running Routine", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is received as NRC 24", @$finalResponse[2], '==', '0x24' );

			}

		}
	}

	elsif ( $tcpar_Condition eq 'CRConly' ) {
		S_teststep( "Perfoming CRC calculation", 'AUTO_NBR' );

		foreach $EDR_EntryToProcess_CRC (@EDR_Entries) {
			my $CRCRoutineResult_Success = DIAG_calculateCRC_CompletedSuccessfully($$EDR_EntryToProcess_CRC);

			EVAL_evaluate_value( "Checking Result", @$CRCRoutineResult_Success[6], '==', '0x80' );

			S_teststep( "Reading EDR entry for CRC calculated Sucessfully", 'AUTO_NBR' );

			S_teststep( "Security access Approval", 'AUTO_NBR' );

			GDCOM_SecurityAccess_Unlock($Security_Key);

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

			}

			my $CRCRoutineResult_AbortedByClient = DIAG_calculateCRC_AbortedByClient($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$CRCRoutineResult_AbortedByClient[6], '==', '0x81' );

			S_teststep( "Reading EDR entry for Signature calculated Aborted by Client", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

			}

			my $CRCRoutineResult_AbortedByFailure = DIAG_calculateCRC_AbortedByDetectedFailure($EDR_EntryToProcess_Sign);

			EVAL_evaluate_value( "Checking Result", @$CRCRoutineResult_AbortedByFailure[6], '==', '0x82' );

			S_teststep( "Reading EDR entry for Signature calculated Aborted by Failure", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is received as NRC 24", @$finalResponse[2], '==', '0x24' );

			}

			my $CRCRoutineResult_Running = DIAG_calculateCRC( $EDR_EntryToProcess_Sign, 'Running' );

			EVAL_evaluate_value( "Checking Result", @$CRCRoutineResult_Running[6], '==', '0x01' );

			S_teststep( "Reading EDR entry for Signature calculated While Running Routine", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries) {

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is received as NRC 24", @$finalResponse[2], '==', '0x24' );
			}

		}

	}

	elsif ( $tcpar_Condition eq 'CRCandSignature' ) {
		S_teststep( "Perfoming CRC and Signature calculation", 'AUTO_NBR' );

		foreach $EDR_EntryToProcess_CRC (@EDR_Entries) {
			S_teststep( "Reading EDR without CRC or Signature calculation ", 'AUTO_NBR' );

			foreach $EDRResponse (@EDR_Entries)    #No data condition
			{

				$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

				$finalResponse = $EDRData{$EDRResponse};

				EVAL_evaluate_value( "Checking EDR entry is invalid", @$finalResponse[2], '==', '0x24' );

			}
			my $CRCRoutineResult_Success = DIAG_calculateCRC_CompletedSuccessfully($EDR_EntryToProcess_CRC);

			my $signRoutineResult_Success = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_CRC);

			my $signRoutineResult_AbortedByClient = DIAG_calculateSignature_AbortedByClient($EDR_EntryToProcess_CRC);

			my $CRCRoutineResult_AbortedByClient = DIAG_calculateCRC_AbortedByClient($EDR_EntryToProcess_CRC);

			my $CRCRoutineResult_AbortedByFailure = DIAG_calculateCRC_AbortedByDetectedFailure($EDR_EntryToProcess_CRC);

			my $signRoutineResult_AbortedByFailure = DIAG_calculateSignature_AbortedByDetectedFailure($EDR_EntryToProcess_CRC);

			my $CRCRoutineResult_Running = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, 'Running' );

			my $signRoutineResult_Running = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'Running' );

			if ( @$CRCRoutineResult_Success[6] == '0x80' && @$signRoutineResult_Success[6] == '0x80' )    #CRC and Signature Completed Sucessfully
			{
				S_teststep( "Reading EDR entry for Signature & CRC calculated Sucessfully", 'AUTO_NBR' );

				S_teststep( "Security access Approval", 'AUTO_NBR' );

				GDCOM_SecurityAccess_Unlock($Security_Key);

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Success[6] == '0x80' && @$signRoutineResult_Running[6] == '0x01' )    #CRC completed Sucessfully and Signature is running
			{
				S_teststep( "Reading EDR entry for Signature is Running & CRC calculated Sucessfully", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					my $finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Running[6] == '0x01' )    #CRC is Running and Signature is 'dont care'
			{
				S_teststep( "Reading EDR entry for  CRC calculation Running", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					my $finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}
			}
			elsif ( @$CRCRoutineResult_Success[6] == '0x80' && @$signRoutineResult_AbortedByClient[6] == '0x81' )    #CRC completed Sucessfully and Signature aborted by client
			{
				S_teststep( "Reading EDR entry for  CRC calculation Sucessfully and Signature aborted by client", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_AbortedByClient[6] == '0x81' && @$signRoutineResult_Running[6] == '0x01' )    #CRC aborted by client and Signature Running
			{
				S_teststep( "Reading EDR entry for  CRC calculation Aborted by Client and Signature Calculation is Running", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_AbortedByClient[6] == '0x81' && @$signRoutineResult_Success[6] == '0x80' )    #CRC aborted by client and Signature Completed Sucessfully
			{
				S_teststep( "Reading EDR entry for  CRC calculation Aborted by Client and Signature Calculation is Successful", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}
			}

			elsif ( @$CRCRoutineResult_AbortedByClient[6] == '0x81' && @$signRoutineResult_AbortedByClient[6] == '0x81' )    #CRC and Signature aborted by Client
			{
				S_teststep( "Reading EDR entry for  CRC calculation Aborted by Client and Signature Calculation Aborted by Client", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}
			}

			elsif ( @$CRCRoutineResult_AbortedByFailure[6] == '0x82' )    #CRC aborted by failure
			{
				S_teststep( "Reading EDR entry for  CRC calculation Aborted by Failure", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}

			}

		}

	}

	elsif ( $tcpar_Condition eq 'CRCorSignature' ) {
		S_teststep( "Performing CRC or Signature Calculation", 'AUTO_NBR' );

		foreach $EDR_EntryToProcess_CRC (@EDR_Entries) {
			my $CRCRoutineResult_Success = DIAG_calculateCRC_CompletedSuccessfully($$EDR_EntryToProcess_CRC);

			my $signRoutineResult_Success = DIAG_calculateSignature_CompletedSuccessfully($EDR_EntryToProcess_CRC);

			my $signRoutineResult_AbortedByClient = DIAG_calculateSignature_AbortedByClient($EDR_EntryToProcess_CRC);

			my $CRCRoutineResult_AbortedByClient = DIAG_calculateCRC_AbortedByClient($EDR_EntryToProcess_CRC);

			my $CRCRoutineResult_AbortedByFailure = DIAG_calculateCRC_AbortedByDetectedFailure($EDR_EntryToProcess_Sign);

			my $signRoutineResult_AbortedByFailure = DIAG_calculateSignature_AbortedByDetectedFailure($EDR_EntryToProcess_Sign);

			my $CRCRoutineResult_Running = DIAG_calculateCRC( $EDR_EntryToProcess_Sign, 'Running' );

			my $signRoutineResult_Running = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'Running' );

			if ( @$CRCRoutineResult_Running[6] == '0x01' )    #CRC Running Signature dont care
			{
				S_teststep( "Reading EDR entry with CRC calculation Running", 'AUTO_NBR' );

				S_teststep( "Security access Approval", 'AUTO_NBR' );

				GDCOM_SecurityAccess_Unlock($Security_Key);

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					my $finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Success[6] == '0x80' || @$signRoutineResult_Running[6] == '0x01' )    #CRC Completed and Signature running
			{
				S_teststep( "Reading EDR entry with CRC calculation is sucess and Signature calculation is Running", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Success[6] == '0x80' || @$signRoutineResult_Success[6] == '0x80' )    #Signature and CRC Completed
			{
				S_teststep( "Reading EDR entry with CRC calculation and Signature calculation are Success", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Success[6] == '0x80' || @$signRoutineResult_AbortedByClient[6] == '0x81' )    #CRC completed Signature aborted by client
			{
				S_teststep( "Reading EDR entry with CRC calculation is sucess and Signature calculation is aborted by client", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_AbortedByFailure[6] == '0x82' )    #CRC aborted by failure and signature dont care
			{
				S_teststep( "Reading EDR entry with CRC calculation is aborted due to Failure", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is NRC 24", @$finalResponse[2], '==', '0x24' );

				}

			}

			elsif ( @$CRCRoutineResult_Success[6] == '0x80' )    #CRC is completed and signature is no data
			{
				S_teststep( "Reading EDR entry with CRC calculation is Completed and Signature is No data", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}
			}

			elsif ( @$signRoutineResult_Success[6] == '0x80' )    #CRC is no data and Signature is Completed Sucessfully
			{
				S_teststep( "Reading EDR entry with CRC is No Data and Signature calculation is Completed", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

			elsif ( @$signRoutineResult_AbortedByClient[6] == '0x81' )    #CRC is no data and signature is aborted by client
			{
				S_teststep( "Reading EDR entry with CRC is No Data and Signature calculation is aborted by client", 'AUTO_NBR' );

				foreach $EDRResponse (@EDR_Entries) {

					$EDRData{$EDRResponse} = DIAG_readEDREntry($EDRResponse);

					$finalResponse = $EDRData{$EDRResponse};

					EVAL_evaluate_value( "Checking EDR entry is valid", @$finalResponse[2], '!=', '0x24' );

				}

			}

		}

	}

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1 is completed in Test Stimulation and Measurement", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 2 is completed in Test Stimulation and Measurement", 'AUTO_NBR' );

	S_teststep( "Evaluation for Step 3 is completed in Test Stimulation and Measurement", 'AUTO_NBR' );

	return 1;
}

sub TC_finalization {

	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

1;
