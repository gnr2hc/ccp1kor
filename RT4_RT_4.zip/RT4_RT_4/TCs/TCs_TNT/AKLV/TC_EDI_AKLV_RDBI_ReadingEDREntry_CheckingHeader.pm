#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingEDREntry_CheckingHeader;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingEDREntry_CheckingHeader.pm 1.2 2014/07/07 16:28:46ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_evaluation;    

##################################

our $PURPOSE = "To test the reading generic, OEM specific and Supplier Specific EDR entries and checking Header  with crash injecting using EDR Developement functions";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingEDREntry_CheckingHeader

=head1 PURPOSE

To test the reading generic, OEM specific and Supplier Specific EDR entries and checking Header  with crash injecting using EDR Developement functions

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Inject crashes in the <EDR_Event_Array> sequencially using EDR development functions routine control

2. Send Request to enter session [enterSession:: ExtendedSession] 

3. Iterate step 4 and step 5 for each values of <EDR_EntryToProcess> 

4. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>] 

5. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition> 

6. Send Request to enter session [enterSession::<Session_to_be_entered>] 

7. Get the Security  access  [getSecurity ::<Security_Key>]

8. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries> And Read The Total Event Counter in all EDR Entries

9. Read Fault recorder through windiag. [readFaultMemory :: PD]

10. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]

11. Perform Step12 for  <Number_of_crashes_Injected> times and then continue with step 13.

12. Inject Valid Deployment Event Using EDR development functions routine control

13. Send Request to enter session [enterSession:: ExtendedSession] 

14. Iterate step 15 and step 16 for each values of <EDR_EntryToProcess> 

15. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>] 

16. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition> 

17. Send Request to enter session [enterSession::<Session_to_be_entered>] 

18. Get the Security  access  [getSecurity ::<Security_Key>]

19. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries> And Read The Header in all EDR Entries

20. Send Request to enter session [enterSession::Development]  

21. Get the Security  access  [getSecurity ::EDRDevelopmentFunctionsMiniAlgoKey]

22. Send  start routine control request  [routinecontrol ::  startRoutine,EDRDevelopmentFunctions,ResetCompleteEDR]  

23. Send  routine control result  request  [routinecontrol :: requestRoutineResults,EDRDevelopmentFunctions,ResetCompleteEDR]  

24. Reset ECU

25. Send Request to enter session [enterSession:: ExtendedSession] 

26. Iterate step 27 and step 28 for each values of <EDR_EntryToProcess> 

27. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>] 

28. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC]  during  CompletedSuccessfully Condition

29. Send Request to enter session [enterSession::<Session_to_be_entered>] 

30. Get the Security  access  [getSecurity ::<Security_Key>]

31. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries> 

32. Read Fault recorder through windiag. [readFaultMemory :: PD]

33. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]


I<B<Evaluation>>

1. Crash is injected Successfully  

2. Session is entered

3. --

4. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

5. Positive response is obtained for each request with <RoutineResultStateOfOperarion>

6. Session is entered

7. --

8. Responses_Array is obtained and Total Event Counter should be 06

9. Fault recorder contains  'FltEdrDataAreaFull' if 5 Deployment Crashes are injected

10. Response contains DTC corresponding to  'FltEdrDataAreaFull' if 5 Deployment Crashes are injected

11. --

12. Crash is injected Successfully  

13. Session is entered

14. --

15. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

16. Positive response is obtained for each request with <RoutineResultStateOfOperarion>

17. Session is entered

18. --

19. Responses_Array is obtained and Header for EDR Entry 1 to EDR Entry 6 is <Exp_Header_01>,  <Exp_Header_02>,  <Exp_Header_03>,  <Exp_Header_04>,  <Exp_Header_05> and <Exp_Header_06>

20. Session is entered

21. --

22. Positive response is obtained

23. Routine is successful 

24. --

25. Session is entered

26. --

27. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

28. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'CompletedSuccessfully '

29. Session is entered

30. --

31. Positive Response is obtained  for all EDR Entries  with empty Header as <Empty_Header_Bytes>

32. Fault recorder does NOT contain any 'FltEdrDataAreaFull' 

33. Response does NOT contains DTC corresponding to  'FltEdrDataAreaFull'


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	LIST 'SelectedFunction' => Selected function either signature or CRC
	LIST 'EDR_EntryToProcess' => EDR Entry to calculate signature or CRC
	SCALAR 'Condition' => Condition to calculate signature or CRC
	SCALAR 'Security_Key' => NONE, Level3_23
	SCALAR 'Session_to_be_entered' => Session to be entered
	LIST 'Empty_Header_Bytes' => @('00','00')
	LIST 'EDR_Entries' => Generic EDR Entries or OEM Specific or Supplier Specific EDR entries to read
	SCALAR 'Number_of_crashes_Injected' => Number of crashes to be Injected
	LIST 'EDR_Event_Array' => Crashes to be injected
	SCALAR 'RoutineResultStateOfOperarion' => Status of the Routine Result
	LIST 'Exp_Header_01' => Expected Header
	LIST 'Exp_Header_02' =>  Expected Header
	LIST 'Exp_Header_03' =>  Expected Header 
	LIST 'Exp_Header_04' =>  Expected Header
	LIST 'Exp_Header_05' =>  Expected Header
	LIST 'Exp_Header_06' =>  Expected Header


=head2 PARAMETER EXAMPLES

	purpose = 'To check  for Reading Generic EDREntry and Checking the header and crash is injected using EDR Developement functions'
	
	SelectedFunction = @('CalculateSignature','CalculateCRC')
	EDR_EntryToProcess = @('01', '02','03','04','05','06')
	Condition = 'CompletedSuccessfully'
	Security_Key = 'NONE'
	Session_to_be_entered = 'ExtendedSession'
	Empty_Header_Bytes =@('0x00','0x00')
	EDR_Entries = @('01', '02','03','04','05','06')	
	Number_of_crashes_Injected = '<Test Heading 2>'
	EDR_Event_Array =@('ValidDeploymentEvent','InvalidDeploymentEvent','InvalidDeploymentEvent','ValidDeploymentEvent','InvalidDeploymentEvent',''InvalidDeploymentEvent')
	RoutineResultStateOfOperarion ='0x80'	
	Exp_Header_01 = @( '0x80', '0x06' )
	Exp_Header_02 = @( '0x80', '0x06' )
	Exp_Header_03 = @( '0x00', '0x06' ) 
	Exp_Header_04 = @( '0x80', '0x06' )
	Exp_Header_05 = @( '0x80', '0x06' )
	Exp_Header_06 = @( '0x00', '0x06' )
	
	# Responses_Array =@('GenericInvalidDeploymentEntry','GenericInvalidDeploymentEntry','GenericValidDeploymentEntry','GenericInvalidDeploymentEntry','GenericInvalidDeploymentEntry','GenericValidDeploymentEntry')

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_SelectedFunction;
my @tcpar_EDR_EntryToProcess;
my $tcpar_Condition;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered;
my @tcpar_Empty_Header_Bytes;
my @tcpar_EDR_Entries;
my $tcpar_Number_of_crashes_Injected;
my @tcpar_EDR_Event_Array;
my $tcpar_RoutineResultStateOfOperarion;
my @tcpar_Exp_Header_01;
my @tcpar_Exp_Header_02;
my @tcpar_Exp_Header_03;
my @tcpar_Exp_Header_04;
my @tcpar_Exp_Header_05;
my @tcpar_Exp_Header_06;

################ global parameter declaration ###################
#add any global variables here
my $CrashCount;
my %Responses_Hash;
my %EDR_Response_Hash;
my %EDR_HeaderBytes;
my %EDR_EmptyHeaderBytes;

my %Responses_Hash_AfterCrashes;
my %EDR_Response_Hash_AfterCrashes; 
my %EDR_HeaderBytes_AfterCrashes;

my %SignRoutine_Reponse;
my %CRCRoutine_Reponse;
my %EDR_EmptyReponse;
my $requestLabel;
my $CrashRead;
my $flt_mem_struct_PD_AfterCrash;
my $flt_mem_struct_CD_AfterCrash;
my $flt_mem_struct_PD_AfterResetCompleteEDR;
my $flt_mem_struct_CD_AfterResetCompleteEDR;

###############################################################

sub TC_set_parameters
{

	$tcpar_purpose                       = GEN_Read_mandatory_testcase_parameter('purpose');
	@tcpar_SelectedFunction              = GEN_Read_mandatory_testcase_parameter('SelectedFunction');
	@tcpar_EDR_EntryToProcess            = GEN_Read_mandatory_testcase_parameter('EDR_EntryToProcess');
	$tcpar_Condition                     = GEN_Read_mandatory_testcase_parameter('Condition');
	$tcpar_Security_Key                  = GEN_Read_mandatory_testcase_parameter('Security_Key');
	$tcpar_Session_to_be_entered         = GEN_Read_mandatory_testcase_parameter('Session_to_be_entered');
	@tcpar_Empty_Header_Bytes            = GEN_Read_mandatory_testcase_parameter('Empty_Header_Bytes');
	@tcpar_EDR_Entries                   = GEN_Read_mandatory_testcase_parameter('EDR_Entries');
	$tcpar_Number_of_crashes_Injected    = GEN_Read_mandatory_testcase_parameter('Number_of_crashes_Injected');
	@tcpar_EDR_Event_Array               = GEN_Read_mandatory_testcase_parameter('EDR_Event_Array');
	$tcpar_RoutineResultStateOfOperarion = GEN_Read_mandatory_testcase_parameter('RoutineResultStateOfOperarion');
	@tcpar_Exp_Header_01                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_01');
	@tcpar_Exp_Header_02                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_02');
	@tcpar_Exp_Header_03                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_03');
	@tcpar_Exp_Header_04                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_04');
	@tcpar_Exp_Header_05                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_05');
	@tcpar_Exp_Header_06                 = GEN_Read_mandatory_testcase_parameter('Exp_Header_06');

	return 1;
}

sub TC_initialization
{

	GEN_printTestStep("Standard_Preparaion");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement
{

	GEN_printTestStep("Step 1. Inject crashes in the [@tcpar_EDR_Event_Array] sequencially using EDR development functions routine control");
	############### Injecting Crash ###################
	foreach my $EDREventArray(@tcpar_EDR_Event_Array)
	{
		if ( $EDREventArray eq 'ValidDeploymentEvent' )
		{
			GDCOM_StartSession( 'ExtendedSession',    'CheckActiveSession' );
			GDCOM_StartSession( 'DevelopmentSession', 'CheckActiveSession' );
			GDCOM_SecurityAccess_Unlock('Level3_21');
			DIAG_performEDRDevelopmentFunctions('02');
		}
		elsif ( $EDREventArray eq 'InvalidDeploymentEvent' )
		{
			GDCOM_StartSession( 'ExtendedSession',    'CheckActiveSession' );
			GDCOM_StartSession( 'DevelopmentSession', 'CheckActiveSession' );
			GDCOM_SecurityAccess_Unlock('Level3_21');
			DIAG_performEDRDevelopmentFunctions('04');
		}
		else
		{
			S_set_error( "EDR Dev Function Crash Type : $EDREventArray is Invalid !", 0 );
			return 0;
		}
	}
	############### Crash Injections Section is Completed  ###################
	$CrashCount = scalar(@tcpar_EDR_Event_Array);    #Checking the No Of Crashes

	GEN_printTestStep("Step 2. Send Request to enter session [enterSession:: ExtendedSession] ");
	GDCOM_StartSession( 'ExtendedSession','CheckActiveSession' );

	GEN_printTestStep("Step 3. Iterate step 4 and step 5 for each values of [@tcpar_EDR_EntryToProcess] ");
	foreach my $SelFuncCrcOrSign (@tcpar_SelectedFunction)
	{
		if ( $SelFuncCrcOrSign eq 'CalculateSignature' )
		{
			foreach my $EDR_EntryToProcess_Sign (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 4.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign");
				GEN_printTestStep("Step 5.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ");
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
				my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$SignatureResponse[6] );
			}
		}
		elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' )
		{
			foreach my $EDR_EntryToProcess_CRC (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 4.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC");
				GEN_printTestStep("Step 5.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ");
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
				my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$CRCResponse[6] );
			}
		}
		else
		{
			GEN_printComment( 'Not Required To Calculate CRC or SIGN', 'blue' );
		}
	}

	GEN_printTestStep("Step 6. Send Request to enter session [enterSession::'$tcpar_Session_to_be_entered'] ");
	if ( $tcpar_Session_to_be_entered eq 'DevelopmentSession' )
	{
		GDCOM_StartSession( 'ExtendedSession','CheckActiveSession' );
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}
	else
	{
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}

	GEN_printTestStep("Step 7.  Get the Security  access  [getSecurity ::'$tcpar_Security_Key']");
	############### Getting SA ###################
	if ( $tcpar_Security_Key eq 'NONE' )
	{
		GEN_printComment( 'SA is Not Required', 'blue' );
	}
	else
	{
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}

	GEN_printTestStep("Step 8. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array [@tcpar_EDR_Entries] And Read The Total Event Counter in all EDR Entries");
	foreach my $EDREntries(@tcpar_EDR_Entries)
	{
		GEN_printTestStep("Step 8. Send request  to read EDR entry : $EDREntries");	
			if ( $EDREntries == 01 or $EDREntries == 81 or $EDREntries == 11 )
			{
				$CrashRead = 01;
			}
			elsif ( $EDREntries == 02 or $EDREntries == 82 or $EDREntries == 12  )
			{
				$CrashRead = 02;
			}
			elsif ( $EDREntries == 03 or $EDREntries == 83 or $EDREntries == 13  )
			{
				$CrashRead = 03;
			}
			elsif ( $EDREntries == 04 or $EDREntries == 84 or $EDREntries == 14  )
			{
				$CrashRead = 04;
			}
			elsif ( $EDREntries == 05 or $EDREntries == 85  or $EDREntries == 15 )
			{
				$CrashRead = 05;
			}
			elsif ( $EDREntries == 06 or $EDREntries == 86 or $EDREntries == 16  )
			{
				$CrashRead = 06;
			}
			else
			{
				S_set_error( "EDR Entry is Invalid!", 0 );
				return 0;
			}
		$Responses_Hash{$CrashRead}  = DIAG_readEDREntry($EDREntries);
		$EDR_Response_Hash{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash{$CrashRead} );		
		$EDR_HeaderBytes{$CrashRead} = EDR_CD_readHeader( $Responses_Hash{$CrashRead} );
						
	}

	GEN_printTestStep("Step 9. Read Fault recorder through windiag. [readFaultMemory :: PD]");
	$flt_mem_struct_PD_AfterCrash = FM_PD_readFaultMemory();

	GEN_printTestStep("Step 10. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]");
	$flt_mem_struct_CD_AfterCrash = FM_CD_readFaultMemory(0xFF);

	GEN_printTestStep("Step 11. Perform Step12 for  [$tcpar_Number_of_crashes_Injected] times and then continue with step 13.");
	for( $CrashCount = 1 ; $CrashCount <= $tcpar_Number_of_crashes_Injected ; $CrashCount++ )
	{
		GEN_printTestStep("Step 12. Inject Valid Deployment Event Using EDR development functions routine control  and Count is : $CrashCount");
		GDCOM_StartSession( 'ExtendedSession',    'CheckActiveSession' );
		GDCOM_StartSession( 'DevelopmentSession', 'CheckActiveSession' );
		GDCOM_SecurityAccess_Unlock('Level3_21');
		DIAG_performEDRDevelopmentFunctions('02');			
	}

	GEN_printTestStep("Step 13. Send Request to enter session [enterSession:: ExtendedSession] ");
	GDCOM_StartSession( 'ExtendedSession','CheckActiveSession' );

	GEN_printTestStep("Step 14. Iterate step 15 and step 16 for each values of [@tcpar_EDR_EntryToProcess] ");
	foreach my $SelFuncCrcOrSign (@tcpar_SelectedFunction)
	{
		if ( $SelFuncCrcOrSign eq 'CalculateSignature' )
		{
			foreach my $EDR_EntryToProcess_Sign (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 15.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign");
				GEN_printTestStep("Step 16.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ");
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
				my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$SignatureResponse[6] );
			}
		}
		elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' )
		{
			foreach my $EDR_EntryToProcess_CRC (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 15.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC");
				GEN_printTestStep("Step 16.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ");
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
				my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$CRCResponse[6] );
			}
		}
		else
		{
			GEN_printComment( 'Not Required To Calculate CRC or SIGN', 'blue' );
		}
	}
	

	GEN_printTestStep("Step 17. Send Request to enter session [enterSession::'$tcpar_Session_to_be_entered'] ");
	if ( $tcpar_Session_to_be_entered eq 'DevelopmentSession' )
	{
		GDCOM_StartSession( 'ExtendedSession','CheckActiveSession' );
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}
	else
	{
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}

	GEN_printTestStep("Step 18.  Get the Security  access  [getSecurity ::'$tcpar_Security_Key']");
	############### Getting SA ###################
	if ( $tcpar_Security_Key eq 'NONE' )
	{
		GEN_printComment( 'SA is Not Required', 'blue' );
	}
	else
	{
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}	

	GEN_printTestStep("Step 19. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array [@tcpar_EDR_Entries] And Read The Header in all EDR Entries");
	foreach my $EDREntries(@tcpar_EDR_Entries)
	{
		GEN_printTestStep("Step 19. Send request  to read EDR entry : $EDREntries");	
			if ( $EDREntries == 01 or $EDREntries == 81 or $EDREntries == 11 )
			{
				$CrashRead = 01;
			}
			elsif ( $EDREntries == 02 or $EDREntries == 82 or $EDREntries == 12  )
			{
				$CrashRead = 02;
			}
			elsif ( $EDREntries == 03 or $EDREntries == 83 or $EDREntries == 13  )
			{
				$CrashRead = 03;
			}
			elsif ( $EDREntries == 04 or $EDREntries == 84 or $EDREntries == 14  )
			{
				$CrashRead = 04;
			}
			elsif ( $EDREntries == 05 or $EDREntries == 85  or $EDREntries == 15 )
			{
				$CrashRead = 05;
			}
			elsif ( $EDREntries == 06 or $EDREntries == 86 or $EDREntries == 16  )
			{
				$CrashRead = 06;
			}
			else
			{
				S_set_error( "EDR Entry is Invalid!", 0 );
				return 0;
			}
		$Responses_Hash_AfterCrashes{$CrashRead}  = DIAG_readEDREntry($EDREntries);
		$EDR_Response_Hash_AfterCrashes{$CrashRead} = DIAG_getEDRDataFromResponse($Responses_Hash_AfterCrashes{$CrashRead} );		
		$EDR_HeaderBytes_AfterCrashes{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_AfterCrashes{$CrashRead} );
						
	}

	GEN_printTestStep("Step 20. Send Request to enter session [enterSession::Development]  ");
	GDCOM_StartSession( 'ExtendedSession',    'CheckActiveSession' );
	GDCOM_StartSession( 'DevelopmentSession', 'CheckActiveSession' );

	GEN_printTestStep("Step 21. Get the Security  access  [getSecurity ::EDRDevelopmentFunctionsMiniAlgoKey]");
	GDCOM_SecurityAccess_Unlock('Level3_21');

	GEN_printTestStep("Step 22. Send  start routine control request  [routinecontrol ::  startRoutine,EDRDevelopmentFunctions,ResetCompleteEDR]  ");
	GEN_printTestStep("Step 23. Send  routine control result  request  [routinecontrol :: requestRoutineResults,EDRDevelopmentFunctions,ResetCompleteEDR]  ");
	DIAG_performEDRDevelopmentFunctions('82');

	GEN_printTestStep("Step 24. Reset ECU");
	GEN_Power_on_Reset();
	S_wait_ms('5000',"Waiting 5000ms time after Power on RESET");
	
	GEN_printTestStep("Step 25. Send Request to enter session [enterSession:: ExtendedSession] ");
	GDCOM_StartSession( 'ExtendedSession', 'CheckActiveSession' );

	GEN_printTestStep("Step 26. Iterate step 27 and step 28 for each values of [@tcpar_EDR_EntryToProcess] ");
	foreach my $SelFuncCrcOrSign (@tcpar_SelectedFunction)
	{
		if ( $SelFuncCrcOrSign eq 'CalculateSignature' )
		{
			foreach my $EDR_EntryToProcess_Sign (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 27.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign");
				GEN_printTestStep("Step 28.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ");
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
				my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$SignatureResponse[6] );
			}
		}
		elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' )
		{
			foreach my $EDR_EntryToProcess_CRC (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 27.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC");
				GEN_printTestStep("Step 28.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ");
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
				my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$CRCResponse[6] );
			}
		}
		else
		{
			GEN_printComment( 'Not Required To Calculate CRC or SIGN', 'blue' );
		}
	}
	

	GEN_printTestStep("Step 29. Send Request to enter session [enterSession::'$tcpar_Session_to_be_entered'] ");
	if ( $tcpar_Session_to_be_entered eq 'DevelopmentSession' )
	{
		GDCOM_StartSession( 'ExtendedSession','CheckActiveSession' );
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}
	else
	{
		GDCOM_StartSession( $tcpar_Session_to_be_entered, 'CheckActiveSession' );
	}

	GEN_printTestStep("Step 30. Get the Security  access  [getSecurity ::'$tcpar_Security_Key']");
	############### Getting SA ###################
	if ( $tcpar_Security_Key eq 'NONE' )
	{
		GEN_printComment( 'SA is Not Required', 'blue' );
	}
	else
	{
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}	

	GEN_printTestStep("Step 31. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array '@tcpar_EDR_Entries' ");
	foreach my $EmptyEDREntries (@tcpar_EDR_Entries)
	{
		GEN_printTestStep("Step 31. Send request  to read EDR entry : $EmptyEDREntries ");
		$EDR_EmptyReponse{$EmptyEDREntries}     = DIAG_readEDREntry($EmptyEDREntries);
		$EDR_EmptyHeaderBytes{$EmptyEDREntries} = EDR_CD_readHeader( $EDR_EmptyReponse{$EmptyEDREntries} );
		GEN_EVAL_CompareNumArrays( $EDR_EmptyHeaderBytes{$EmptyEDREntries}, \@tcpar_Empty_Header_Bytes, 'Equal' );

	}

	GEN_printTestStep("Step 32. Read Fault recorder through windiag. [readFaultMemory :: PD]");
	$flt_mem_struct_PD_AfterResetCompleteEDR = FM_PD_readFaultMemory();

	GEN_printTestStep("Step 33. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]");
	$flt_mem_struct_CD_AfterResetCompleteEDR = FM_CD_readFaultMemory(0x89);

	return 1;
}

sub TC_evaluation
{

	GEN_printTestStep("Evaluation for Step 1. Crash is injected Successfully  ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 2. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 3. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 4. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 5.Positive response is obtained for each request with '$tcpar_RoutineResultStateOfOperarion'");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 6.Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 7. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 8. Responses_Array is obtained and Total Event Counter should be 06");
	my @exp_Header_Intial_01 = ( '0x80', '0x06' );
	my @exp_Header_Intial_02 = ( '0x80', '0x06' );
	my @exp_Header_Intial_03 = ( '0x00', '0x06' );
	my @exp_Header_Intial_04 = ( '0x80', '0x06' );
	my @exp_Header_Intial_05 = ( '0x80', '0x06' );
	my @exp_Header_Intial_06 = ( '0x00', '0x06' );	
	GEN_printComment( "\n Checking The Header Of Responses_Hash{01}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{01}, \@exp_Header_Intial_01, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash{02}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{02}, \@exp_Header_Intial_02, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash{03}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{03}, \@exp_Header_Intial_03, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash{04}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{04}, \@exp_Header_Intial_04, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash{05}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{05}, \@exp_Header_Intial_05, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash{06}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{06}, \@exp_Header_Intial_06, 'Equal' );

	GEN_printTestStep("Evaluation for Step 9. Fault recorder contains  'FltEdrDataAreaFull' if 5 Deployment Crashes are injected");
	FM_checkFaultStatus( $flt_mem_struct_PD_AfterCrash, 'FltEdrDataAreaFull', 0x1F );
	
	GEN_printTestStep("Evaluation for Step 10.Response contains DTC corresponding to  'FltEdrDataAreaFull' if 5 Deployment Crashes are injected");
	FM_checkFaultStatus( $flt_mem_struct_CD_AfterCrash, 'FltEdrDataAreaFull', 0x89 );

	GEN_printTestStep("Evaluation for Step 11. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 12. Crash is injected Successfully  ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 13. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 14. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 15. Positive response is obtained for each request with StartRoutineStateOfOperarion as Running");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 16. Positive response is obtained for each request with [$tcpar_RoutineResultStateOfOperarion]");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 17. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 18. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 19. Responses_Array is obtained and Header for EDR Entry 1 to EDR Entry 6 is [@tcpar_Exp_Header_01],  [@tcpar_Exp_Header_02],  [@tcpar_Exp_Header_03],  [@tcpar_Exp_Header_04],  [@tcpar_Exp_Header_05] and [@tcpar_Exp_Header_06]");
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{01}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{01}, \@tcpar_Exp_Header_01, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{02}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{02}, \@tcpar_Exp_Header_02, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{03}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{03}, \@tcpar_Exp_Header_03, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{04}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{04}, \@tcpar_Exp_Header_04, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{05}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{05}, \@tcpar_Exp_Header_05, 'Equal' );
	GEN_printComment( "\n Checking The Header Of Responses_Hash_AfterCrashes{06}   ! \n", "blue" );
	GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes_AfterCrashes{06}, \@tcpar_Exp_Header_06, 'Equal' );
	
	#Comparing The Arrays EDR_Reponse_Hash and  EDR_Response_Hash_AfterCrashes #	
	for( $CrashCount = 1 ; $CrashCount <= 6 ; $CrashCount++ )
	{
		GEN_printComment( "\n Comparing The Arrays %EDR_Response_Hash[$CrashCount] and  EDR_Response_Hash_AfterCrashes[$CrashCount]! \n" );
		GEN_EVAL_CompareNumArrays( $EDR_Response_Hash{$CrashCount}, $EDR_Response_Hash_AfterCrashes{$CrashCount}, 'Equal' );					
	}

	GEN_printTestStep("Evaluation for Step 20. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 21. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 22. Positive response is obtained");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");
	
	GEN_printTestStep("Evaluation for Step 23. Routine is successful ");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 24. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 25. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 26. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 27. Positive response is obtained for each request with StartRoutineStateOfOperarion as Running");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 28. Positive response is obtained for each request with StartRoutineStateOfOperarion as CompletedSuccessfully");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 29. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 30. --");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 31.  Positive Response is obtained  for all EDR Entries  with empty Header as [@tcpar_Empty_Header_Bytes]");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 32. Fault recorder does NOT contain any [FltEdrDataAreaFull] ");
	FM_checkFaultStatus( $flt_mem_struct_PD_AfterResetCompleteEDR, 'FltEdrDataAreaFull', 0x00 );

	GEN_printTestStep("Evaluation for Step 33. Response does NOT contains DTC corresponding to [FltEdrDataAreaFull]");
	FM_checkFaultStatus( $flt_mem_struct_CD_AfterResetCompleteEDR, 'FltEdrDataAreaFull', 0x00 );

	return 1;
}

sub TC_finalization
{
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}

1;
