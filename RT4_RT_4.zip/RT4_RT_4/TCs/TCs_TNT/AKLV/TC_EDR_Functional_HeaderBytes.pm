#### TEST CASE MODULE
package TC_EDR_Functional_HeaderBytes;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: AKLV/TC_EDR_Functional_HeaderBytes.pm 1.4 2019/11/19 18:23:12ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;
##################################

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### HERE SELECTION OF AUTOTEST MODULES ####
use LIFT_general;
use LIFT_evaluation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_crash_simulation;
use INCLUDES_Project;
##################################
our $PURPOSE = 'To validate Header bytes reported in the EDR service';

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_Functional_HeaderBytes  $Revision: 1.4 $

requires MLC,PD,CANoe,POWER and evaluation (setup already done in IC)

default state is faultfree ECU powered ON

=head1 PURPOSE

To validate Header bytes reported in the EDR service

=head1 TESTCASE DESCRIPTION 

    [initialisation]
    StandardPreparation

    [stimulation & measurement]
    1. Inject any Inflatable Crash.
	2. Read header bytes in EDR1 through CD.
	3. Inject any NonInflatable Crash and at the time of storage, switch Off the ECU. i.e create such a condition complete crash should not be stored
	4. Read header bytes in EDR2 through CD.
	5. Reset ECU and inject any Inflatable Crash.
	6. Read header bytes in EDR3 through CD.
	7. Inject any Inflatable Crash.
	8. Read header bytes in EDR4 through CD.
	9. Inject any Inflatable Crash.
	10. Read header bytes in EDR5 through CD.
	11. Inject 10 NoDeployment Crashes.
	12. Read header bytes in EDR6 through CD.	
	

    [evaluation]
    1.
	2. 00 01
	3.
	4. 80 02
	5.
	6. 00 03
	7.
	8. 00 04
	9.
	10. 00 05
	11.
	12. 00 0F

    [finalisation]
    Clear Crash Telegram and Fault memory
    ECU off

=head1 PARAMETER DESCRIPTION

=head2 PARAMETER NAMES

    purpose                  --> Purpose of the test case
  	

=head2 PARAMETER EXAMPLES

    [TC_EDR_Functional_HeaderBytes.HeaderBytes]
	# From here on: applicable Lift Default Parameters
	purpose = 'To validate Header bytes reported in the EDR service'

=cut

################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_ResultDB;
my $tcpar_Inflatable_Crash;
my $tcpar_NonInflatable_Crash;
my $tcpar_NoDeployment_Crash;
################ global parameter declaration ###################
my ( $EDR1_CD_response_aref, $EDR2_CD_response_aref, $EDR3_CD_response_aref, $EDR4_CD_response_aref, $EDR5_CD_response_aref, $EDR6_CD_response_aref );
my ( $EDR1_Header_aref,      $EDR2_Header_aref,      $EDR3_Header_aref,      $EDR4_Header_aref,      $EDR5_Header_aref,      $EDR6_Header_aref );
my $NumberOfCrashTelegrams;
my $CrashInjectionStatus;

sub TC_set_parameters {

	$tcpar_purpose             = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ResultDB            = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_Inflatable_Crash    = S_read_mandatory_testcase_parameter( 'Inflatable_Crash', 'byref' );
	$tcpar_NonInflatable_Crash = S_read_mandatory_testcase_parameter( 'NonInflatable_Crash', 'byref' );
	$tcpar_NoDeployment_Crash  = S_read_mandatory_testcase_parameter( 'NoDeployment_Crash', 'byref' );
	
	#read other TC specific constants/parameters from other files	
    $NumberOfCrashTelegrams = EDR_fetchNumberOfCrashTelegrams ();

	return 1;

}

#### INITIALIZE TC #####
sub TC_initialization {

	S_teststep( 'StandardPreparation', 'AUTO_NBR' );
	GEN_StandardPrepNoFault();

	return 1;
}

### STIMULATION AND MEASUREMENT ###
sub TC_stimulation_and_measurement {

	S_teststep( "Clear crash recorder before crash injection", 'AUTO_NBR' );
	PD_ClearCrashRecorder();
	S_wait_ms(2000);

	S_teststep( "Step1:  Inject any Inflatable Crash", 'AUTO_NBR' );
	_injectCrash( @$tcpar_Inflatable_Crash[0] );

	S_teststep( "Step2:  Read header bytes in EDR1 through CD", 'AUTO_NBR' );
	$EDR1_CD_response_aref = EDR_CD_ReadEDR(1);
	if ($EDR1_CD_response_aref) {    #if aref is not empty
		$EDR1_Header_aref = EDR_CD_readHeader($EDR1_CD_response_aref);
	}

	S_teststep( "Step3: Inject any NonInflatable Crash and at the time of storage, switch Off the ECU. i.e create such a condition complete crash should not be stored", 'AUTO_NBR' );
	_injectCrash( @$tcpar_NonInflatable_Crash[0], 'yes', 50 );
	S_wait_ms('TIMER_ECU_OFF');
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	S_teststep( "Step4:  Read header bytes in EDR2 through CD", 'AUTO_NBR' );
	$EDR2_CD_response_aref = EDR_CD_ReadEDR(2);
	if ($EDR2_CD_response_aref) {
		$EDR2_Header_aref = EDR_CD_readHeader($EDR2_CD_response_aref);
	}

	if ( $NumberOfCrashTelegrams > 2 ) {
		S_teststep( "Step5:  Reset ECU and inject any Inflatable Crash", 'AUTO_NBR' );
		GEN_Power_on_Reset();
		_injectCrash(@$tcpar_Inflatable_Crash[1]);

		S_teststep( "Step6:  Read header bytes in EDR3 through CD", 'AUTO_NBR' );
		$EDR3_CD_response_aref = EDR_CD_ReadEDR(3);
		if ($EDR3_CD_response_aref) {
			$EDR3_Header_aref = EDR_CD_readHeader($EDR3_CD_response_aref);
		}
	}

	if ( $NumberOfCrashTelegrams > 3 ) {
		S_teststep( "Step7:  Inject any Inflatable Crash", 'AUTO_NBR' );
		_injectCrash(@$tcpar_Inflatable_Crash[2]);

		S_teststep( "Step8:  Read header bytes in EDR4 through CD", 'AUTO_NBR' );
		$EDR4_CD_response_aref = EDR_CD_ReadEDR(4);
		if ($EDR4_CD_response_aref) {
			$EDR4_Header_aref = EDR_CD_readHeader($EDR4_CD_response_aref);
		}
	}

	if ( $NumberOfCrashTelegrams > 4 ) {
		S_teststep( "Step9:  Inject any Inflatable Crash", 'AUTO_NBR' );
		_injectCrash(@$tcpar_Inflatable_Crash[3]);

		S_teststep( "Step10:  Read header bytes in EDR5 through CD", 'AUTO_NBR' );
		$EDR5_CD_response_aref = EDR_CD_ReadEDR(5);
		if ($EDR5_CD_response_aref) {
			$EDR5_Header_aref = EDR_CD_readHeader($EDR5_CD_response_aref);
		}
	}

	if ( $NumberOfCrashTelegrams > 5 ) {
		S_teststep( "Step11:  Inject 10 NoDeployment Crashes", 'AUTO_NBR' );
		foreach ( 1 .. 10 ) {
			_injectCrash(@$tcpar_NoDeployment_Crash[0]);
		}

		S_teststep( "Step12:  Read header bytes in EDR6 through CD", 'AUTO_NBR' );
		$EDR6_CD_response_aref = EDR_CD_ReadEDR(6);
		if ($EDR6_CD_response_aref) {
			$EDR6_Header_aref = EDR_CD_readHeader($EDR6_CD_response_aref);
		}
	}

	return 1;
}

#### EVALUATE TC #####
sub TC_evaluation {

	S_teststep( "Step2: Header bytes: 00 01", 'AUTO_NBR' );
	if ($EDR1_Header_aref) {    #check if array ref is not empty
		GEN_EVAL_CompareNumArrays( $EDR1_Header_aref, [ 0x00, 0x01 ], 'Equal' );
	}

	S_teststep( "Step4: Header bytes: 80 02", 'AUTO_NBR' );
	if ($EDR2_Header_aref) {
		GEN_EVAL_CompareNumArrays( $EDR2_Header_aref, [ 0x80, 0x02 ], 'Equal' );
	}

	if ( $NumberOfCrashTelegrams > 2 ) {
		S_teststep( "Step6: Header bytes: 00 03", 'AUTO_NBR' );
		if ($EDR3_Header_aref) {
			GEN_EVAL_CompareNumArrays( $EDR3_Header_aref, [ 0x00, 0x03 ], 'Equal' );

		}
	}

	if ( $NumberOfCrashTelegrams > 3 ) {
		S_teststep( "Step8: Header bytes: 00 04", 'AUTO_NBR' );
		if ($EDR4_Header_aref) {
			GEN_EVAL_CompareNumArrays( $EDR4_Header_aref, [ 0x00, 0x04 ], 'Equal' );
		}
	}

	if ( $NumberOfCrashTelegrams > 4 ) {
		S_teststep( "Step10: Header bytes: 00 05", 'AUTO_NBR' );
		if ($EDR5_Header_aref) {
			GEN_EVAL_CompareNumArrays( $EDR5_Header_aref, [ 0x00, 0x05 ], 'Equal' );
		}
	}

	if ( $NumberOfCrashTelegrams > 5 ) {
		S_teststep( "Step12: Header bytes: 00 06", 'AUTO_NBR' );
		if ($EDR6_Header_aref) {
			GEN_EVAL_CompareNumArrays( $EDR6_Header_aref, [ 0x00, 0x0F ], 'Equal' );
		}
	}

	return 1;
}

#### TC FINALIZATION #####
#-- set system to original state --##
sub TC_finalization {

	GEN_Finalization();

	return 1;
}

sub _injectCrash() {

	my $crashCode       = shift;
	my $cutoff_flag     = shift;    #Cut power off before inject crash
	my $cutoff_waittime = shift;    #wait time from cut off point to crash injection

	unless ( defined $cutoff_flag ) {
		$cutoff_flag = 'no';
	}
	else {
		unless ( defined $cutoff_waittime ) {
			$cutoff_waittime = 50;    #50 ms
		}
	}

	#--------------------------------------------------------------
	# PREPARE CRASH AND INITIALIZE EQUIPMENT
	#
	S_teststep_2nd_level( "Get crash settings for crash $crashCode", 'AUTO_NBR' );
	my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
	my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
	unless ( defined $crashSettings ) {
		S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
		return;
	}

	my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
	my $resultDB_Path = $resultDBDetails->{'PATH'};
	S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

	S_w2log( 1, "Set environments for crash as per result DB" );
	CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
	S_wait_ms(2000);

	#--------------------------------------------------------------
	# CRASH PREPARATION
	#
	S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');

	# Prepare crash
	CSI_LoadCrashSensorData2Simulator($crashSettings);

	# Power ON the ECU
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');

	#--------------------------------------------------------------
	# CRASH INJECTION
	#
	if ( $cutoff_flag eq 'yes' ) {
		S_teststep_2nd_level( "Power Off ECU", 'AUTO_NBR' );
		LC_ECU_Off();
		S_teststep_2nd_level( "Wait for $cutoff_waittime ms", 'AUTO_NBR' );
		S_wait_ms($cutoff_waittime);
	}
	S_teststep_2nd_level( "Inject crash '$crashCode'", 'AUTO_NBR' );
	CSI_TriggerCrash();
	S_teststep( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
	S_wait_ms(10000);
}

1;

__END__
