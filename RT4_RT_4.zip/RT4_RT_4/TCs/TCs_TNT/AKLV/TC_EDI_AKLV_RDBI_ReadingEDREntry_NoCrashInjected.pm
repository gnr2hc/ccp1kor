#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingEDREntry_NoCrashInjected;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.2 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingEDREntry_NoCrashInjected.pm 1.2 2014/07/07 16:29:40ICT DVR5KOR develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use INCLUDES_Project;
use LIFT_evaluation;    

##################################

our $PURPOSE = "To test the reading generic and OEM specific EDR entries when crash recorder is empty by calculating signature And CRC";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingEDREntry_NoCrashInjected

=head1 PURPOSE

To test the reading generic and OEM specific EDR entries when crash recorder is empty by calculating signature And CRC

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send Request to enter session [enterSession::<Session_to_be_entered1>] 

2. Iterate step 3 and step 4 for each values of <EDR_EntryToProcesss> 

3. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>,<EDR_EntryToProcesss>] 

4. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC]  during <Condition> 

5. Send Request to enter session [enterSession::<Session_to_be_entered2>] 

6. Get the Security  access  [getSecurity ::<Security_Key>]

7. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>


I<B<Evaluation>>

1. Session is entered

2.

3. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

4. Positive response is obtained for each request with <RoutineResultStateOfOperarion>

5. Session is entered

6.

7.  <Response_Type> is obtained with <Response_Array > with empty Header 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	LIST 'SelectedFunction' => Selected function either signature or CRC
	LIST 'EDR_EntryToProcess' => EDR Entry to calculate signature or CRC
	SCALAR 'Condition' => Condition to calculate signature or CRC
	SCALAR 'Security_Key' => NONE, Level3_23
	SCALAR 'Session_to_be_entered1' => Session to be entered
	SCALAR 'Session_to_be_entered2' => Session to be entered
	LIST 'Empty_Header_Bytes ' => @('00','00')
	LIST 'EDR_Entries' => Generic EDR Entries or OEM Specific EDR entries
	SCALAR 'RoutineResultStateOfOperarion' => Status of the Routine Result
	SCALAR 'Response_Type' => Expected Response Type
	


=head2 PARAMETER EXAMPLES

	purpose = 'To check  for different EDR entries by calculating signature and CRC when no crash is injected'
	
	SelectedFunction = @('CalculateSignature','CalculateCRC')
	EDR_EntryToProcess = @('01', '02','03','04','05','06')
	Condition ='<Test Heading Head>'
	Security_Key = 'NONE'
	Session_to_be_entered1 ='ExtendedSession'
	Session_to_be_entered2 = 'ExtendedSession'
	Empty_Header_Bytes  =@('00','00')
	EDR_Entries = @('01', '02','03','04','05','06')
	RoutineResultStateOfOperarion ='CompletedSuccessfully'
	Response_Type = 'PositiveResponseWithEmptyHeader'
	

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my @tcpar_SelectedFunction;
my @tcpar_EDR_EntryToProcess;
my $tcpar_Condition;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered1;
my $tcpar_Session_to_be_entered2;
my @tcpar_Empty_Header_Bytes;
my @tcpar_EDR_Entries;
my $tcpar_RoutineResultStateOfOperarion;
my $tcpar_Response_Type;
my @tcpar_Response_Array;

################ global parameter declaration ###################
#add any global variables here
my %EDR_Response_NRC;
my %EDR_Reponse;
my %EDR_EmptyHeaderBytes;
my $requestLabel;
my %EDR_Response_NRC;
my %SignRoutine_Reponse;
my %CRCRoutine_Reponse;

###############################################################

sub TC_set_parameters
{

	$tcpar_purpose                       = GEN_Read_mandatory_testcase_parameter('purpose');
	@tcpar_SelectedFunction              = GEN_Read_mandatory_testcase_parameter('SelectedFunction');
	@tcpar_EDR_EntryToProcess            = GEN_Read_mandatory_testcase_parameter('EDR_EntryToProcess');
	$tcpar_Condition                     = GEN_Read_mandatory_testcase_parameter('Condition');
	$tcpar_Security_Key                  = GEN_Read_mandatory_testcase_parameter('Security_Key');
	$tcpar_Session_to_be_entered1        = GEN_Read_mandatory_testcase_parameter('Session_to_be_entered1');
	$tcpar_Session_to_be_entered2        = GEN_Read_mandatory_testcase_parameter('Session_to_be_entered2');
	@tcpar_Empty_Header_Bytes            = GEN_Read_mandatory_testcase_parameter('Empty_Header_Bytes');
	@tcpar_EDR_Entries                   = GEN_Read_mandatory_testcase_parameter('EDR_Entries');
	$tcpar_RoutineResultStateOfOperarion = GEN_Read_mandatory_testcase_parameter('RoutineResultStateOfOperarion');
	$tcpar_Response_Type                 = GEN_Read_mandatory_testcase_parameter('Response_Type');

	return 1;
}

sub TC_initialization
{

	GEN_printTestStep("Standard_Preparaion");
	PD_ClearCrashRecorder();
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();
	return 1;
}

sub TC_stimulation_and_measurement
{

	GEN_printTestStep("Step 1.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered1] ");
	GDCOM_StartSession( $tcpar_Session_to_be_entered1, 'CheckActiveSession' );

	GEN_printTestStep("Step 2.Iterate step 3 and step 4 for each values of [@tcpar_EDR_EntryToProcess]");
	foreach my $SelFuncCrcOrSign (@tcpar_SelectedFunction)
	{
		if ( $SelFuncCrcOrSign eq 'CalculateSignature' )
		{
			foreach my $EDR_EntryToProcess_Sign (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 3.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign");
				GEN_printTestStep("Step 4.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ");
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
			}
		}
		elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' )
		{
			foreach my $EDR_EntryToProcess_CRC (@tcpar_EDR_EntryToProcess)
			{
				GEN_printTestStep("Step 3.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC");
				GEN_printTestStep("Step 4.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ");
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
			}

		}
		else
		{
			GEN_printComment( 'Not Required To Calculate CRC or SIGN', 'blue' );
		}

	}

	GEN_printTestStep("Step 5..Send Request to enter session [enterSession::$tcpar_Session_to_be_entered2] ");
	GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );

	GEN_printTestStep("Step 6. Get the Security  access  [getSecurity ::$tcpar_Security_Key]");
	if ( $tcpar_Security_Key eq 'NONE' )
	{
		GEN_printComment( 'SA is Not Required', 'blue' );
	}
	else
	{
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}

	GEN_printTestStep("Step 7. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array [@tcpar_EDR_Entries]");

	if ( $tcpar_Response_Type eq 'PositiveResponseWithEmptyHeader' )
	{
		foreach my $EDREntries (@tcpar_EDR_Entries)
		{
			GEN_printTestStep("Step 7. Send request  to read EDR entry : $EDREntries");
			$EDR_Reponse{$EDREntries}          = DIAG_readEDREntry($EDREntries);
			$EDR_EmptyHeaderBytes{$EDREntries} = EDR_CD_readHeader( $EDR_Reponse{$EDREntries} );
		}

	}
	elsif ( $tcpar_Response_Type eq 'NR_requestSequenceError' )
	{
		foreach my $EDREntries (@tcpar_EDR_Entries)
		{
			GEN_printTestStep("Step 7. Send request  to read EDR entry : $EDREntries");
			my $EDRentry = $EDREntries;
			$requestLabel = 'ReadDatabyID_FA13_GenericEDREntry' if ( $EDRentry == 01 );
			$requestLabel = 'ReadDatabyID_FA14_GenericEDREntry' if ( $EDRentry == 02 );
			$requestLabel = 'ReadDatabyID_FA15_GenericEDREntry' if ( $EDRentry == 03 );
			$requestLabel = 'ReadDatabyID_FA16_GenericEDREntry' if ( $EDRentry == 04 );
			$requestLabel = 'ReadDatabyID_FA17_GenericEDREntry' if ( $EDRentry == 05 );
			$requestLabel = 'ReadDatabyID_FA18_GenericEDREntry' if ( $EDRentry == 06 );

			$requestLabel = 'ReadDatabyID_1013_OEMEDREntry' if ( $EDRentry == 81 );
			$requestLabel = 'ReadDatabyID_1014_OEMEDREntry' if ( $EDRentry == 82 );
			$requestLabel = 'ReadDatabyID_1015_OEMEDREntry' if ( $EDRentry == 83 );
			$requestLabel = 'ReadDatabyID_1016_OEMEDREntry' if ( $EDRentry == 84 );
			$requestLabel = 'ReadDatabyID_1017_OEMEDREntry' if ( $EDRentry == 85 );
			$requestLabel = 'ReadDatabyID_1018_OEMEDREntry' if ( $EDRentry == 86 );
			$EDR_Response_NRC{$EDREntries} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' );
		}
	}
	else
	{
		S_set_error( "Response Type is in correct", 102 );
	}

	return 1;
}

sub TC_evaluation
{

	GEN_printTestStep("Evaluation for Step 1. Session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 2.");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 3.Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 4.Positive response is obtained for each request with $tcpar_RoutineResultStateOfOperarion");

	foreach my $EDR_EntryToProcess_Sign (@tcpar_EDR_EntryToProcess)
	{
		my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
		EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion );
	}

	foreach my $EDR_EntryToProcess_CRC (@tcpar_EDR_EntryToProcess)
	{
		my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
		EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion );
	}

	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 5.session is entered");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 6.");
	GEN_printComment("This Step is Evaluated in Stimulation And Measurement Only  ");

	GEN_printTestStep("Evaluation for Step 7.   $tcpar_Response_Type is obtained  for all EDR Entries  with empty Header as @tcpar_Empty_Header_Bytes ");
	foreach my $EDREntries (@tcpar_EDR_Entries)
	{
		if ( $EDR_EmptyHeaderBytes{$EDREntries} )    #check if array ref is not empty
		{
			GEN_EVAL_CompareNumArrays( $EDR_EmptyHeaderBytes{$EDREntries}, \@tcpar_Empty_Header_Bytes, 'Equal' );
		}
	}

	return 1;
}

sub TC_finalization
{
	GDCOM_stop_CyclicTesterPresent();

	return 1;
}

1;
