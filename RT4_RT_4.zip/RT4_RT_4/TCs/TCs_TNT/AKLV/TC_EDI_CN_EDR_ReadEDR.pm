#### TEST CASE MODULE
package TC_EDI_CN_EDR_ReadEDR;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER  = q$Header: AKLV/TC_EDI_CN_EDR_ReadEDR.pm 1.1 2020/03/20 10:36:09ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project;    #necessary

#include further modules here
use LIFT_crash_simulation;
use LIFT_labcar;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_MDSRESULT;
use GENERIC_DCOM;
use LIFT_can_access;
use FuncLib_EDR_Framework;
use FuncLib_SYC_INTERFACE;

use Data::Dumper;

##################################

our $PURPOSE = "To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDR_DiagnosticInterfaceReadEDR

=head1 PURPOSE

'To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress'

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Inject <CrashCodeList>.

2. send request <Read_ChinaEDR> and check obtained response

I<B<Evaluation>>

1. --

2. <Expected_response> is obtained and NRC (SID is Wrong) is not obtained


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Condition' => 
	SCALAR 'EDR_EntryType' => 
	SCALAR 'crashcode' => 
	SCALAR 'CrashTimeZero_ms' => 
	SCALAR 'wait_ms' => 
	SCALAR 'ResultDB' => 
	SCALAR 'Response' => 


=head2 PARAMETER EXAMPLES

	purpose = 'To check  supported NRC for Crash Recorder EDR when algo is active and crash storage is in progress'
	
	Condition = <Test Heading 1>
	EDR_EntryType = <Test Heading 2>
	
	# ---------- Stimulation ------------ 
	crashcode = 'Single_EDR_Front_Inflatable;5'
	CrashTimeZero_ms='11.76' #ms
	
	wait_ms = 10000 #ms
	ResultDB='EDR'
	
	# ---------- Evaluation ------------ 
	Response = 'NR_conditionsNotCorrect'  #Conditions not correct
	
	
	#NRC $22 - ConditionsNotCorrect.( NRC shall be configurable)

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_CrashCodeList;
my $tcpar_EvalType;
my $tcpar_Expected_response;
my $tcpar_ResultDB;
my $tcpar_EDID;
my $tcpar_NbrOfDataByte;
my $tcpar_IgnitionCycle_LowByte;
my $tcpar_IgnitionCycle_HighByte;
my $tcpar_Read_ChinaEDR;
my $tcpar_Factor;
my $tcpar_Offset;
################ global parameter declaration ###################
#add any global variables here
my $pre_check;
my $edrNumberOfEventsToBeStored = 3;    # for CN EDR
my @ignitionCycle;
my $crashLabel;
###############################################################

sub TC_set_parameters {

	$tcpar_purpose       = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_ResultDB      = S_read_mandatory_testcase_parameter('ResultDB');
	$tcpar_CrashCodeList = S_read_mandatory_testcase_parameter( 'CrashCodeList', 'byref' );
	$tcpar_EvalType      = S_read_mandatory_testcase_parameter('EvalType');

	$pre_check = 0;

	if ( $tcpar_EvalType =~ m/Diag_response/i ) {
		$tcpar_Expected_response = S_read_mandatory_testcase_parameter('Expected_response');
	}
	elsif ( $tcpar_EvalType =~ m/DataLength/i ) {
		$tcpar_NbrOfDataByte = S_read_mandatory_testcase_parameter('NbrOfDataByte');
	}
	elsif ( $tcpar_EvalType =~ m/StorageOrder/i ) {
		$tcpar_IgnitionCycle_LowByte  = S_read_mandatory_testcase_parameter('Variable_IgnitionCycle_LowByte');
		$tcpar_IgnitionCycle_HighByte = S_read_mandatory_testcase_parameter('Variable_IgnitionCycle_HighByte');
		$tcpar_EDID                   = S_read_mandatory_testcase_parameter('EDID');
		$tcpar_Factor                 = S_read_mandatory_testcase_parameter('Factor');
		$tcpar_Offset                 = S_read_mandatory_testcase_parameter('Offset');
	}
	else {
		S_set_error( "EvalType $tcpar_EvalType is not supported, check again parameter", 110 );
		$pre_check = 1;
		return 0;
	}

	$tcpar_ResultDB      = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB      = 'DEFAULT' unless ( defined $tcpar_ResultDB );
	$tcpar_Read_ChinaEDR = S_read_mandatory_testcase_parameter('Read_ChinaEDR');

	return 1;
}

sub TC_initialization {

	if ($pre_check) {

		S_set_error( "parameter EvalType get error, Stop execution", 110 );
		return 0;
	}
	S_teststep( "Test setup preparation", 'AUTO_NBR' );

	#--------------------------------------------------------------
	# INITIALIZE RECORD AND CRASH HANDLER
	#
	S_teststep( "Power up ECU", 'AUTO_NBR' );
	LC_ECU_On();
	S_wait_ms('TIMER_ECU_READY');
	S_w2log( 1, "Initialize CD and start CAN trace" );
	GDCOM_init();    # To fetch info for CD from mapping_diag
	CA_trace_start();

	S_teststep( "Clear crash recorder", 'AUTO_NBR' );
	PD_ClearCrashRecorder();

	S_wait_ms(2000);
	S_teststep( "Clear fault memory", 'AUTO_NBR' );
	PD_ClearFaultMemory();
	S_wait_ms(2000);

	S_teststep( "Read fault memory before stimulation", 'AUTO_NBR' );
	my $faultsBeforeStimulation = PD_ReadFaultMemory();
	my $faultsVerdict = PD_evaluate_faults( $faultsBeforeStimulation, [] );
	return 0 unless ( $faultsVerdict eq 'VERDICT_PASS' );

	return 1;
}

sub TC_stimulation_and_measurement {

	foreach my $crashCode ( @{$tcpar_CrashCodeList} ) {
		S_w2rep("Prepare and inject $crashCode");
		$crashLabel .= "_" if ( defined $crashLabel );
		$crashLabel .= $crashCode;
		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2rep("Get crash settings for crash $crashCode");
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $crashCode };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $crashCode not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		S_w2log( 1, "Crashcode: $crashCode, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_teststep( "Set environment for crash", 'AUTO_NBR' );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# READ IGNITION CYCLE to evaluate incase of StorageOrder need to check
		#
		if ( $tcpar_EvalType =~ m/StorageOrder/i ) {

			my $ignitionCycle;
			S_teststep_2nd_level( "Read '$tcpar_IgnitionCycle_LowByte','$tcpar_IgnitionCycle_HighByte' to get current power on cycle", 'AUTO_NBR' );
			my $ignitionCycleBeforeCrash1 = S_aref2hex( PD_ReadMemoryByName($tcpar_IgnitionCycle_LowByte) );
			return unless ($ignitionCycleBeforeCrash1);
			my $ignitionCycleBeforeCrash2 = S_aref2hex( PD_ReadMemoryByName($tcpar_IgnitionCycle_HighByte) );
			return unless ($ignitionCycleBeforeCrash2);

			$ignitionCycle = $ignitionCycleBeforeCrash2 . $ignitionCycleBeforeCrash1;
			$ignitionCycle =~ m/0x(.*)0x(.*)/;    #concatenated and removed 0x
			$ignitionCycle = '0x' . $1 . $2;
			$ignitionCycle = S_0x2dec($ignitionCycle);
			S_w2rep("Ignition cycle for crash $crashCode =  $ignitionCycle ");
			push( @ignitionCycle, $ignitionCycle );
		}
		CSI_TriggerCrash();

		S_teststep( "Wait for 15 seconds", 'AUTO_NBR' );
		S_wait_ms(15000);
	}

	S_teststep( "send request $tcpar_Read_ChinaEDR and check obtained response", 'AUTO_NBR', 'create_condition_and' );    #measurement 1

	foreach my $recordNbr ( 1 .. 3 ) {

		my $response = undef;
		if ( ( defined $tcpar_Expected_response ) and ( $tcpar_Expected_response != m/PR_response/i ) ) {
			$response = $tcpar_Expected_response;
		}

		S_teststep_2nd_level( "send request read ChinaEDR section $recordNbr ", 'AUTO_NBR', 'read_edr_' . $recordNbr );
		my $readEDR_response_aref = _read_EDR_record( $recordNbr, $response, 'EVAL_SWITCH' );
		my @obtained_response;
		foreach my $i ( @{$readEDR_response_aref} ) {
			push( @obtained_response, $i );
		}
		if ( $tcpar_EvalType =~ m/Diag_response/i ) {
			S_teststep_expected( "Expected $tcpar_Expected_response", 'read_edr_' . $recordNbr );    #evaluation 1
			if ( $obtained_response[0] eq '7F' ) {
				S_teststep_detected( "Detected Negative response", 'read_edr_' . $recordNbr );
			}
			else {
				S_teststep_detected( "Detected Possitive response", 'read_edr_' . $recordNbr );
			}
		}
		elsif ( $tcpar_EvalType =~ m/DataLength/i ) {
			my $detected_length = scalar(@obtained_response) - 3;
			S_teststep_expected( "Positive response shall be obtained followed by $tcpar_NbrOfDataByte EDR data bytes", 'read_edr_' . $recordNbr );    #evaluation 1
			S_teststep_detected( "Detected $detected_length data byte", 'read_edr_' . $recordNbr );
			EVAL_evaluate_value( "Data length of EDR data", $detected_length, '==', $tcpar_NbrOfDataByte );
		}
		elsif ( $tcpar_EvalType =~ m/StorageOrder/i ) {
			my $expectedIgnitionCycle;
			$expectedIgnitionCycle = $ignitionCycle[ $edrNumberOfEventsToBeStored - $recordNbr ];

			my $recordStructure_href  = FuncLib_TNT_EDR::EDR_ReadCHINAEDR_Record_structure_info_from_mapping();
			my $parsing_EDID          = FuncLib_TNT_EDR::EDR_parseEDIDs( $readEDR_response_aref, $recordStructure_href );
			my $edidData_aref         = $parsing_EDID->{$tcpar_EDID};
			my $detectedIgnitionCycle = _decode_EDID_data( $edidData_aref, $tcpar_Factor, );
			S_teststep_expected("Positive response shall be obtained and response has data from  most recent crash injected");                         #evaluation 1
			S_teststep_expected( "Ignition Cycle is '$expectedIgnitionCycle'", 'read_edr_' . $recordNbr );
			S_teststep_detected( "Ignition Cycle in record $recordNbr is '$detectedIgnitionCycle'", 'read_edr_' . $recordNbr );
			EVAL_evaluate_value( "Data length of EDR data", $detectedIgnitionCycle, '==', $expectedIgnitionCycle );
		}
		else {

		}
	}

	S_teststep( "Wait 10000 ms", 'AUTO_NBR' );
	S_wait_ms(10000);

	return 1;
}

sub TC_evaluation {

	S_w2rep("Evaluation is done above in stimulation_and_measurement");

	return 1;
}

sub TC_finalization {
	PD_ECUlogin();
	S_wait_ms(2000);

	# Erase EDR
	PD_ClearCrashRecorder_NOERROR();
	S_wait_ms(2000);

	# Erase Fault memory
	PD_ClearFaultMemory();
	S_wait_ms(10000);

	# Read fault memory after clearing and erasing EDR
	PD_ReadFaultMemory();

	LC_ECU_Off();
	S_wait_ms('TIMER_ECU_OFF');
	return 1;
}

sub _read_EDR_record {

	my $edrEntry_nbr       = shift;
	my $expectedResponse   = shift;
	my $evaluationRequired = shift;

	my $requestLabel;
	$requestLabel = $tcpar_Read_ChinaEDR . '0' . $edrEntry_nbr;

	S_w2log( 3, "\n Sending Diag request to read EDR Entry $edrEntry_nbr \n" );

	unless ( defined $expectedResponse ) {
		$expectedResponse = "PR_$requestLabel";
	}
	my $noEvalSwitch;
	$noEvalSwitch = 'NO_EVAL_SWITCH' unless ( defined $evaluationRequired );

	# Send the diagnosis request via GDCOM
	my $response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	unless ($response) {
		S_wait_ms(2000);
		S_w2log( 2, "Try to read service again after short wait time" );
		$response = GDCOM_request_general( "REQ_$requestLabel", $expectedResponse, undef, $noEvalSwitch );
	}

	# In case of offline run, no response will be recieved
	return [] if $main::opt_offline;

	# Convert the received diagnosis response (string with hex values, each byte separated by space!) to array of bytes
	my @responseBytes = split( / /, $response );

	return \@responseBytes;
}

sub _decode_EDID_data {

	my $edidData_aref = shift;
	my $factor        = shift;
	my $offset        = shift;
	my $sampleHEX;
	foreach my $rawValue (@$edidData_aref) {
		$sampleHEX .= $rawValue;
	}
	my $sampleValue = ( hex($sampleHEX) * $factor ) + $offset;
	return $sampleValue;
}
1;
