#### TEST CASE MODULE
package TC_EDI_AKLV_RDBI_ReadingEDREntry_CrashInjected;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.4 $;
our $HEADER  = q$Header: AKLV/TC_EDI_AKLV_RDBI_ReadingEDREntry_CrashInjected.pm 1.4 2019/11/19 18:22:44ICT Phan Khanh Duy (RBVH/EPS24) (PDA1HC) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: TS_EDR_DiagnosticInterface
#TS version in DOORS: 0.3
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use LIFT_PD;
use LIFT_CD;
use GENERIC_DCOM;
use LIFT_general;
use INCLUDES_Project;
use LIFT_evaluation;
use LIFT_crash_simulation;
use LIFT_labcar;

##################################

our $PURPOSE = "To test the reading generic and OEM specific EDR entries in chronological order by calculating signature And CRC with crash injecting using Sensor Simulator";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_EDI_AKLV_RDBI_ReadingEDREntry_CrashInjected

=head1 PURPOSE

To test the reading generic and OEM specific EDR entries in chronological order by calculating signature And CRC with crash injecting using Sensor Simulator

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

Standard_Preparation


I<B<Stimulation and Measurement>>

1. Send Request to enter session [enterSession::<Session_to_be_entered1>] 

2. Perform step 3 to step 9<Number_of_crashes_Injected> times and then continue with step 10.

3. Inject a Deployment  Crash

4. Iterate step 5 and step 6 for each values of <EDR_EntryToProcess> 

5. Send  start routine control request  [routinecontrol :: startRoutine,CalculateSignatureOrCRC,<SelectedFunction>, <EDR_EntryToProcess>] 

6. Send  routine result request  [routinecontrol :: requestRoutineResults,CalculateSignatureOrCRC] during <Condition> 

7. Send Request to enter session [enterSession::<Session_to_be_entered2>] 

8. Get the Security  access  [getSecurity ::<Security_Key>]

9. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>

10. read Fault recorder through windiag. [readFaultMemory :: PD]

11. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]

12. Send Request to enter session [enterSession::Development]  

13. Get the Security  access  [getSecurity ::EDRDevelopmentFunctionsMiniAlgoKey]

14. Send  start routine control request  [routinecontrol :: startRoutine,EDRDevelopmentFunctions,ResetCompleteEDR]  

15. Send  routine control result  request  [routinecontrol :: requestRoutineResults,EDRDevelopmentFunctions,ResetCompleteEDR]  

16. Send Request to enter session [enterSession::<Session_to_be_entered2>] 

17. Get the Security  access  [getSecurity ::<Security_Key>]

18. Send array of requests  to read EDR entries [ ReadDataByIdentifier :: DID ] where DID Array <EDR_Entries>

19. read Fault recorder through windiag. [readFaultMemory :: PD]

20. Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]


I<B<Evaluation>>

1. Session is entered

2.

3. Crash is injected Successfully 

4.

5. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'

6. Positive response is obtained for each request with <RoutineResultStateOfOperarion>

7.

8.

9. Arrray of Positive responses from "Responses_Array_0" to "Responses_Array_(Number_of_crashes_Injected-1)" are  obtained
		Responses_Array_0 =@('EDRentry01','EmptyEntry','EmptyEntry','EmptyEntry','EmptyEntry','EmptyEntry')
		Responses_Array_1 =@('EDRentry02','EDRentry01','EmptyEntry','EmptyEntry','EmptyEntry','EmptyEntry')
		Responses_Array_2 =@('EDRentry03','EDRentry02','EDRentry01','EmptyEntry','EmptyEntry','EmptyEntry')
		Responses_Array_3 =@('EDRentry04,'EDRentry03','EDRentry02','EDRentry01','EmptyEntry','EmptyEntry')
		Responses_Array_4 =@('EDRentry05','EDRentry04,'EDRentry03','EDRentry02','EDRentry01','EmptyEntry')
		Responses_Array_5 =@('EDRentry06','EDRentry05','EDRentry04,'EDRentry03','EDRentry02','EDRentry01')
	
10. Fault recorder contains  'FltEdrDataAreaFull' if 5  crashes are  injected

11. Response contains DTC corresponding to  'FltEdrDataAreaFull' if deployemnt crash is injected

12. session is entered

13.

14. Positive response is obtained

15. Routine is successful 

16. session is entered

17.

18. Positive Response is obtained  for all EDR Entries  with empty Header as <Empty_Header_Bytes>

19. Fault recorder does NOT contain any 'FltEdrDataAreaFull' 

20. Response does NOT contains DTC corresponding to  'FltEdrDataAreaFull' 

Format of each of the EDRentry01:EDREntryData #1 to EDREntryData #n


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => Purpose of the test case
	LIST 'SelectedFunction' => Selected function either signature or CRC
	LIST 'EDR_EntryToProcess' => EDR Entry to calculate signature or CRC
	SCALAR 'Condition' => Condition to calculate signature or CRC
	SCALAR 'Security_Key' => NONE, Level3_23
	SCALAR 'Session_to_be_entered1' => Session to be entered
	SCALAR 'Session_to_be_entered2' => Session to be entered
	LIST 'Empty_Header_Bytes' => @('00','00')
	LIST 'EDR_Entries' => Generic EDR Entries or OEM Specific EDR entries
	SCALAR 'Number_of_crashes_Injected' => Number of crashes to be injected
	SCALAR 'RoutineResultStateOfOperarion' => Status of the Routine Result



=head2 PARAMETER EXAMPLES

	purpose = 'To check  for different EDR entries by calculating signature And CRC'	
	SelectedFunction = @('CalculateSignature','CalculateCRC')
	EDR_EntryToProcess = @('01', '02','03','04','05','06')
	Condition ='<Test Heading Head>'
	Security_Key = 'NONE'
	Session_to_be_entered1 ='ExtendedSession'
	Session_to_be_entered2 = 'ExtendedSession'
	Empty_Header_Bytes =@('00','00')
	EDR_Entries = @('01', '02','03','04','05','06')
	Number_of_crashes_Injected =06
	RoutineResultStateOfOperarion ='0x80'

=cut

#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_SelectedFunction;
my $tcpar_EDR_EntryToProcess;
my $tcpar_Condition;
my $tcpar_Security_Key;
my $tcpar_Session_to_be_entered1;
my $tcpar_Session_to_be_entered2;
my $tcpar_Empty_Header_Bytes;
my $tcpar_EDR_Entries;
my $tcpar_Number_of_crashes_Injected;
my $tcpar_RoutineResultStateOfOperarion;
my $tcpar_CrashScenarioList;
my $tcpar_ResultDB;

################ global parameter declaration ###################
#add any global variables here
my $CrashInjectionStatus;
my ( %EDR_Reponse_Hash_0, %EDR_Reponse_Hash_1, %EDR_Reponse_Hash_2, %EDR_Reponse_Hash_3, %EDR_Reponse_Hash_4, %EDR_Reponse_Hash_5 );
my ( %Responses_Hash_0,   %Responses_Hash_1,   %Responses_Hash_2,   %Responses_Hash_3,   %Responses_Hash_4,   %Responses_Hash_5 );
my %EDR_EmptyReponse;
my %EDR_EmptyHeaderBytes;
my %EDR_HeaderBytes;
my %SignRoutine_Reponse;
my %CRCRoutine_Reponse;
my $requestLabel;
my $CrashCount;
my $CrashRead;
my @Header_Bytes = ( '0x00', '0x06' );
my $flt_mem_struct_PD_AfterCrash;
my $flt_mem_struct_CD_AfterCrash;
my $flt_mem_struct_PD_AfterResetCompleteEDR;
my $flt_mem_struct_CD_AfterResetCompleteEDR;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose                       = S_read_mandatory_testcase_parameter('purpose');
	$tcpar_SelectedFunction              = S_read_mandatory_testcase_parameter( 'SelectedFunction', 'byref' );
	$tcpar_EDR_EntryToProcess            = S_read_mandatory_testcase_parameter( 'EDR_EntryToProcess', 'byref' );
	$tcpar_Condition                     = S_read_mandatory_testcase_parameter('Condition');
	$tcpar_Security_Key                  = S_read_mandatory_testcase_parameter('Security_Key');
	$tcpar_Session_to_be_entered1        = S_read_mandatory_testcase_parameter('Session_to_be_entered1');
	$tcpar_Session_to_be_entered2        = S_read_mandatory_testcase_parameter('Session_to_be_entered2');
	$tcpar_Empty_Header_Bytes            = S_read_mandatory_testcase_parameter( 'Empty_Header_Bytes', 'byref' );
	$tcpar_EDR_Entries                   = S_read_mandatory_testcase_parameter( 'EDR_Entries', 'byref' );
	$tcpar_Number_of_crashes_Injected    = S_read_mandatory_testcase_parameter('Number_of_crashes_Injected');
	$tcpar_RoutineResultStateOfOperarion = S_read_mandatory_testcase_parameter('RoutineResultStateOfOperarion');
	$tcpar_CrashScenarioList             = S_read_mandatory_testcase_parameter( 'CrashScenarioList', 'byref' );
	$tcpar_ResultDB                      = S_read_optional_testcase_parameter('ResultDB');
	$tcpar_ResultDB                      = 'DEFAULT' unless ( defined $tcpar_ResultDB );

	return 1;
}

sub TC_initialization {

	S_teststep( "Standard_Preparaion", 'AUTO_NBR' );
	GEN_StandardPrepNoFault();
	GDCOM_start_CyclicTesterPresent();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep( "Step 1.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered1] ", 'AUTO_NBR' );
	GDCOM_StartSession( $tcpar_Session_to_be_entered1, 'CheckActiveSession' );

	S_teststep( "Step 2.Perform step 3 to step 9 for [$tcpar_Number_of_crashes_Injected] times and then continue with step 10.", 'AUTO_NBR' );
	$CrashCount = 0;
	S_teststep_2nd_level("Clear crash recorder before crash injection", 'AUTO_NBR');
	PD_ClearCrashRecorder();
	S_wait_ms(2000);
	foreach (@$tcpar_CrashScenarioList) {

		S_teststep( "Step 3. Inject a Deployment  Crash", 'AUTO_NBR' );

		#--------------------------------------------------------------
		# PREPARE CRASH AND INITIALIZE EQUIPMENT
		#
		S_teststep_2nd_level("Get crash settings for crash $_", 'AUTO_NBR' );
		my $crashDetails_href = { "RESULTDB" => $tcpar_ResultDB, 'CRASHNAME' => $_ };
		my $crashSettings = CSI_GetCrashDataFromMDS($crashDetails_href);
		unless ( defined $crashSettings ) {
			S_set_error("Crash $_ not available in result DB $tcpar_ResultDB. Test case aborted.");
			return;
		}

		my $resultDBDetails = S_get_contents_of_hash( [ 'MDSRESULT', 'RESULTS', "$tcpar_ResultDB" ] );
		my $resultDB_Path = $resultDBDetails->{'PATH'};
		S_w2log( 1, "Crashcode: $_, ResultDB: $tcpar_ResultDB (path: $resultDB_Path)" );

		S_w2log( 1, "Set environments for crash as per result DB" );
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(2000);

		#--------------------------------------------------------------
		# CRASH PREPARATION
		#
		S_teststep_2nd_level( "Prepare crash", 'AUTO_NBR' );
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');

		# Prepare crash
		CSI_LoadCrashSensorData2Simulator($crashSettings);

		# Power ON the ECU
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');

		#--------------------------------------------------------------
		# CRASH INJECTION
		#

		S_teststep_2nd_level( "Inject crash '$_'", 'AUTO_NBR' );
		CSI_TriggerCrash();
		$CrashCount = $CrashCount + 1;
		S_teststep_2nd_level( "Wait 10s for crash happen and EDR record complete", 'AUTO_NBR' );
		S_wait_ms(10000);

		if ( $CrashCount > $tcpar_Number_of_crashes_Injected ) {
			S_set_error( "Total No Of Crashes to be injected is more than $tcpar_Number_of_crashes_Injected!", 0 );
			return 0;
		}

		############### Crash Injections Section is Completed  ###################

		############### Performing the CRC and Signature ###################
		S_teststep( "Step 4.Iterate step 5 and step 6 for each values of EDR Entry to Process ", 'AUTO_NBR' );

		############### Performing the CRC and Signature For All EDR Entries ###################
		if ( $tcpar_Condition eq 'CompletedSuccessfully' or $tcpar_Condition eq 'Idle' or $tcpar_Condition eq 'Running' or $tcpar_Condition eq 'AbortedByClientAfterCompletedSuccessfully' or $tcpar_Condition eq 'AbortedByDetectedFailureAfterCompletedSuccessfully' ) {
			foreach my $SelFuncCrcOrSign (@$tcpar_SelectedFunction) {
				if ( $SelFuncCrcOrSign eq 'CalculateSignature' ) {
					foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
						S_teststep( "Step 5.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign",                   'AUTO_NBR' );
						S_teststep( "Step 6.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ", 'AUTO_NBR' );
						$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
						my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
						EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$SignatureResponse[6] );
					}
				}
				elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' ) {
					foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {
						S_teststep( "Step 5.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC",                   'AUTO_NBR' );
						S_teststep( "Step 6.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ", 'AUTO_NBR' );
						$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
						my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
						EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$CRCResponse[6] );
					}
				}
				else {
					S_w2rep( 'Not Required To Calculate CRC or SIGN', 'blue' );
				}
			}
		}
		elsif ( $tcpar_Condition eq 'AbortedByClient' or $tcpar_Condition eq 'AbortedByDetectedFailure' ) {
			foreach my $SelFuncCrcOrSign (@$tcpar_SelectedFunction) {
				if ( $SelFuncCrcOrSign eq 'CalculateSignature' ) {
					foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
						my $TempEntry = $EDR_EntryToProcess_Sign;
						$TempEntry = $EDR_EntryToProcess_Sign - 80 if ( $EDR_EntryToProcess_Sign > 80 );    #convert the range from 1 to 6 for OEM entries

						if ( $TempEntry <= $CrashCount )                                                    #if crash is stored in EDR entry
						{
							S_teststep( "Step 5.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign",                   'AUTO_NBR' );
							S_teststep( "Step 6.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ", 'AUTO_NBR' );
							$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, $tcpar_Condition );
							my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
							EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$SignatureResponse[6] );
						}
						else {
							S_teststep( "Step 5.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign",                   'AUTO_NBR' );
							S_teststep( "Step 6.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during $tcpar_Condition ", 'AUTO_NBR' );
							$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'CompletedSuccessfully' );
							my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
							EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', '0x80' ) if ( defined @$SignatureResponse[6] );
						}
					}
				}
				elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' ) {
					foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {
						my $TempEntry = $EDR_EntryToProcess_CRC;
						$TempEntry = $EDR_EntryToProcess_CRC - 80 if ( $EDR_EntryToProcess_CRC > 80 );    #convert the range from 1 to 6 for OEM entries

						if ( $TempEntry <= $CrashCount )                                                  #if crash is stored in EDR entry
						{
							S_teststep( "Step 5.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC",                   'AUTO_NBR' );
							S_teststep( "Step 6.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ", 'AUTO_NBR' );
							$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, $tcpar_Condition );
							my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
							EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', $tcpar_RoutineResultStateOfOperarion ) if ( defined @$CRCResponse[6] );

						}
						else {
							S_teststep( "Step 5.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC",                   'AUTO_NBR' );
							S_teststep( "Step 6.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during $tcpar_Condition ", 'AUTO_NBR' );
							$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, 'CompletedSuccessfully' );
							my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
							EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', '0x80' ) if ( defined @$CRCResponse[6] );
						}

					}
				}
				else {
					S_w2rep( 'Not Required To Calculate CRC or SIGN', 'blue' );
				}
			}

		}
		else {
			S_set_error( "$tcpar_Condition is Invalid!", 0 );
		}

		############### Performing the CRC and Signature section is completed ###################

		S_teststep( "Step 7.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered2] ", 'AUTO_NBR' );
		if ( $tcpar_Session_to_be_entered2 eq 'DevelopmentSession' ) {
			GDCOM_StartSession( 'ExtendedSession',             'CheckActiveSession' );
			GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
		}
		else {
			GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
		}

		############### Getting SA ###################
		S_teststep( "Step 8.Get the Security  access  [getSecurity ::$tcpar_Security_Key]", 'AUTO_NBR' );
		if ( $tcpar_Security_Key eq 'NONE' ) {
			S_w2rep( 'SA is Not Required', 'blue' );
		}
		else {
			GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
		}
		############### SA section is completed ###################

		############### Reading the EDR Entry ###################

		foreach my $EDREntries (@$tcpar_EDR_Entries) {
			$requestLabel = 'ReadDatabyID_FA13_GenericEDREntry' if ( $EDREntries == 01 );
			$requestLabel = 'ReadDatabyID_FA14_GenericEDREntry' if ( $EDREntries == 02 );
			$requestLabel = 'ReadDatabyID_FA15_GenericEDREntry' if ( $EDREntries == 03 );
			$requestLabel = 'ReadDatabyID_FA16_GenericEDREntry' if ( $EDREntries == 04 );
			$requestLabel = 'ReadDatabyID_FA17_GenericEDREntry' if ( $EDREntries == 05 );
			$requestLabel = 'ReadDatabyID_FA18_GenericEDREntry' if ( $EDREntries == 06 );
			$requestLabel = 'ReadDatabyID_1013_OEMEDREntry'     if ( $EDREntries == 81 );
			$requestLabel = 'ReadDatabyID_1014_OEMEDREntry'     if ( $EDREntries == 82 );
			$requestLabel = 'ReadDatabyID_1015_OEMEDREntry'     if ( $EDREntries == 83 );
			$requestLabel = 'ReadDatabyID_1016_OEMEDREntry'     if ( $EDREntries == 84 );
			$requestLabel = 'ReadDatabyID_1017_OEMEDREntry'     if ( $EDREntries == 85 );
			$requestLabel = 'ReadDatabyID_1018_OEMEDREntry'     if ( $EDREntries == 86 );

			if ( $EDREntries == 01 or $EDREntries == 81 ) {
				$CrashRead = 01;
			}
			elsif ( $EDREntries == 02 or $EDREntries == 82 ) {
				$CrashRead = 02;
			}
			elsif ( $EDREntries == 03 or $EDREntries == 83 ) {
				$CrashRead = 03;
			}
			elsif ( $EDREntries == 04 or $EDREntries == 84 ) {
				$CrashRead = 04;
			}
			elsif ( $EDREntries == 05 or $EDREntries == 85 ) {
				$CrashRead = 05;
			}
			elsif ( $EDREntries == 06 or $EDREntries == 86 ) {
				$CrashRead = 06;
			}
			else {
				S_set_error( "EDR Entry is Invalid!", 0 );
			}

			if ( $tcpar_Condition eq 'CompletedSuccessfully' or $tcpar_Condition eq 'Idle' or $tcpar_Condition eq 'Running' or $tcpar_Condition eq 'AbortedByClientAfterCompletedSuccessfully' ) {
				my $TempEntry = $EDREntries;
				$TempEntry = $EDREntries - 80 if ( $EDREntries > 80 );    #convert the range from 1 to 6 for OEM entries

				if ( $TempEntry <= $CrashCount )                          #if crash is stored in EDR entry
				{
					S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
					$Responses_Hash_0{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 1 );
					$Responses_Hash_1{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 2 );
					$Responses_Hash_2{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 3 );
					$Responses_Hash_3{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 4 );
					$Responses_Hash_4{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 5 );
					$Responses_Hash_5{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 6 );

					$EDR_Reponse_Hash_0{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_0{$CrashRead} ) if ( $CrashCount == 1 );
					$EDR_Reponse_Hash_1{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_1{$CrashRead} ) if ( $CrashCount == 2 );
					$EDR_Reponse_Hash_2{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_2{$CrashRead} ) if ( $CrashCount == 3 );
					$EDR_Reponse_Hash_3{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_3{$CrashRead} ) if ( $CrashCount == 4 );
					$EDR_Reponse_Hash_4{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_4{$CrashRead} ) if ( $CrashCount == 5 );
					$EDR_Reponse_Hash_5{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_5{$CrashRead} ) if ( $CrashCount == 6 );
				}
				else {
					if ( $CrashCount == 1 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_0{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_0{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_0{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_0{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_0{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 2 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_1{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_1{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_1{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_1{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_1{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}

					if ( $CrashCount == 3 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_2{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_2{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_2{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_2{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_2{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 4 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_3{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_3{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_3{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_3{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_3{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 5 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_4{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_4{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_4{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_4{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_4{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 6 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_5{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_5{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_5{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_0{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_5{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
				}
			}
			elsif ( $tcpar_Condition eq 'AbortedByClient' ) {
				my $TempEntry = $EDREntries;
				$TempEntry = $EDREntries - 80 if ( $EDREntries > 80 );    #convert the range from 1 to 6 for OEM entries

				if ( $TempEntry <= $CrashCount )                          #if crash is stored in EDR entry
				{
					S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
					$Responses_Hash_0{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 1 );
					$Responses_Hash_1{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 2 );
					$Responses_Hash_2{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 3 );
					$Responses_Hash_3{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 4 );
					$Responses_Hash_4{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 5 );
					$Responses_Hash_5{$CrashRead} = DIAG_readEDREntry($EDREntries) if ( $CrashCount == 6 );

					$EDR_Reponse_Hash_0{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_0{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 1 );
					$EDR_Reponse_Hash_1{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_1{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 2 );
					$EDR_Reponse_Hash_2{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_2{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 3 );
					$EDR_Reponse_Hash_3{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_3{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 4 );
					$EDR_Reponse_Hash_4{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_4{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 5 );
					$EDR_Reponse_Hash_5{$CrashRead} = DIAG_getEDRDataFromResponse( $Responses_Hash_5{$CrashRead}, 'DontRemoveCRCAndSignature' ) if ( $CrashCount == 6 );
				}
				else {
					if ( $CrashCount == 1 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_0{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_0{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_0{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_0{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_0{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 2 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_1{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_1{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_1{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_1{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_1{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 3 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_2{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_2{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_2{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_2{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_2{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 4 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_3{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_3{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_3{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_3{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_3{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 5 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_4{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_4{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_4{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_4{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_4{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
					if ( $CrashCount == 6 ) {
						S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
						$Responses_Hash_5{$CrashRead}   = DIAG_readEDREntry($EDREntries);
						$EDR_Reponse_Hash_5{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_5{$CrashRead} );
						S_w2rep( "\n Checking The Array $EDR_Reponse_Hash_0{$CrashRead} is emplty or not ! \n", "blue" );
						GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_5{$CrashRead}, $tcpar_Empty_Header_Bytes, 'Equal' );
					}
				}
			}
			elsif ( $tcpar_Condition eq 'AbortedByDetectedFailure' or $tcpar_Condition eq 'AbortedByDetectedFailureAfterCompletedSuccessfully' ) {
				S_teststep( "Step 9. Send request  to read EDR entry : $EDREntries", 'AUTO_NBR' );
				$Responses_Hash_0{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 1 );
				$Responses_Hash_1{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 2 );
				$Responses_Hash_2{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 3 );
				$Responses_Hash_3{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 4 );
				$Responses_Hash_4{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 5 );
				$Responses_Hash_5{$CrashRead} = GDCOM_request_general( "REQ_$requestLabel", "NR_requestSequenceError", undef, 'NO_EVAL_SWITCH' ) if ( $CrashCount == 6 );
			}
			else {
				S_set_error( "$tcpar_Condition is Invalid!", 0 );
			}

		}
		############### Reading the EDR Entry is Completed ###################

	}
	############### End Of For Loop Of Crash_Count ###################

	S_teststep( "Step 10. read Fault recorder through windiag. [readFaultMemory :: PD]", 'AUTO_NBR' );
	$flt_mem_struct_PD_AfterCrash = FM_PD_readFaultMemory();

	S_teststep( "Step 11.Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]", 'AUTO_NBR' );
	$flt_mem_struct_CD_AfterCrash = FM_CD_readFaultMemory(0x89);

	S_teststep( "Step 12.Send Request to enter session [enterSession::Development]  ", 'AUTO_NBR' );
	GDCOM_StartSession( 'ExtendedSession',    'CheckActiveSession' );
	GDCOM_StartSession( 'DevelopmentSession', 'CheckActiveSession' );

	S_teststep( "Step 13.Get the Security  access  [getSecurity ::EDRDevelopmentFunctionsMiniAlgoKey]", 'AUTO_NBR' );
	GDCOM_SecurityAccess_Unlock('Level3_21');

	S_teststep( "Step 14.Send  start routine control request  [routinecontrol :: startRoutine,EDRDevelopmentFunctions,ResetCompleteEDR]  ",            'AUTO_NBR' );
	S_teststep( "Step 15.Send  routine control result  request  [routinecontrol :: requestRoutineResults,EDRDevelopmentFunctions,ResetCompleteEDR]  ", 'AUTO_NBR' );
	DIAG_performEDRDevelopmentFunctions('82');

	############### Performing the CRC and Signature ###################
	S_teststep( "Step 16.Iterate step 17 and step 18 for each values of EDR Entries", 'AUTO_NBR' );
	foreach my $SelFuncCrcOrSign (@$tcpar_SelectedFunction) {
		if ( $SelFuncCrcOrSign eq 'CalculateSignature' ) {
			foreach my $EDR_EntryToProcess_Sign (@$tcpar_EDR_EntryToProcess) {
				S_teststep( "Step 17.Send  start routine control request  to Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign",                                  'AUTO_NBR' );
				S_teststep( "Step 18.Send  routine result request  of Calculate Signature for EDR Entry : $EDR_EntryToProcess_Sign during CompletedSuccessfully condition ", 'AUTO_NBR' );
				$SignRoutine_Reponse{$EDR_EntryToProcess_Sign} = DIAG_calculateSignature( $EDR_EntryToProcess_Sign, 'CompletedSuccessfully' );
				my $SignatureResponse = $SignRoutine_Reponse{$EDR_EntryToProcess_Sign};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$SignatureResponse[6], '==', '0x80' ) if ( defined @$SignatureResponse[6] );
			}
		}
		elsif ( $SelFuncCrcOrSign eq 'CalculateCRC' ) {
			foreach my $EDR_EntryToProcess_CRC (@$tcpar_EDR_EntryToProcess) {
				S_teststep( "Step 17.Send  start routine control request  to Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC",                                  'AUTO_NBR' );
				S_teststep( "Step 18.Send  routine result request  of Calculate CRC for EDR Entry : $EDR_EntryToProcess_CRC during CompletedSuccessfully condition ", 'AUTO_NBR' );
				$CRCRoutine_Reponse{$EDR_EntryToProcess_CRC} = DIAG_calculateCRC( $EDR_EntryToProcess_CRC, 'CompletedSuccessfully' );
				my $CRCResponse = $CRCRoutine_Reponse{$EDR_EntryToProcess_CRC};
				EVAL_evaluate_value( "Comparing the RoutineResultStateOfOperarion", @$CRCResponse[6], '==', '0x80' ) if ( defined @$CRCResponse[6] );
			}
		}
		else {
			S_w2rep( 'Not Required To Calculate CRC or SIGN', 'blue' );
		}
	}
	############### Performing the CRC and Signature is Completed ###################

	S_teststep( "Step 19.Send Request to enter session [enterSession::$tcpar_Session_to_be_entered2] ", 'AUTO_NBR' );
	if ( $tcpar_Session_to_be_entered2 eq 'DevelopmentSession' ) {
		GDCOM_StartSession( 'ExtendedSession',             'CheckActiveSession' );
		GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
	}
	else {
		GDCOM_StartSession( $tcpar_Session_to_be_entered2, 'CheckActiveSession' );
	}

	############### Getting SA ###################
	S_teststep( "Step 20.Get the Security  access  [getSecurity ::$tcpar_Security_Key]", 'AUTO_NBR' );
	if ( $tcpar_Security_Key eq 'NONE' ) {
		S_w2rep( 'SA is Not Required', 'blue' );
	}
	else {
		GDCOM_SecurityAccess_Unlock($tcpar_Security_Key);
	}
	############### SA section is completed ###################

	foreach my $EmptyEDREntries (@$tcpar_EDR_Entries) {
		S_teststep( "Step 21. Send request  to read EDR entry : $EmptyEDREntries ", 'AUTO_NBR' );
		$EDR_EmptyReponse{$EmptyEDREntries}     = DIAG_readEDREntry($EmptyEDREntries);
		$EDR_EmptyHeaderBytes{$EmptyEDREntries} = EDR_CD_readHeader( $EDR_EmptyReponse{$EmptyEDREntries} );
		S_wait_ms('1000');
		S_w2rep( "Waiting Some Time", 'blue' );
	}

	S_teststep( "Step 22.read Fault recorder through windiag. [readFaultMemory :: PD]", 'AUTO_NBR' );
	$flt_mem_struct_PD_AfterResetCompleteEDR = FM_PD_readFaultMemory();

	S_teststep( "Step 23.Send request to read faults. [readDTCInfo::ReportDTCByStatusMask]", 'AUTO_NBR' );
	$flt_mem_struct_CD_AfterResetCompleteEDR = FM_CD_readFaultMemory(0x89);

	return 1;
}

sub TC_evaluation {

	S_teststep( "Evaluation for Step 1. Session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 2.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 3.Crash is injected Successfully ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 4.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 5. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 6.Positive response is obtained for each request with $tcpar_RoutineResultStateOfOperarion", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 7.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 8.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 9.Comparing the EDR Entries in Chronological order ", 'AUTO_NBR' );

	############### Comparing the EDR Data in Chronological Order ###################
	if ( $tcpar_Condition eq 'CompletedSuccessfully' or $tcpar_Condition eq 'Idle' or $tcpar_Condition eq 'Running' or $tcpar_Condition eq 'AbortedByClientAfterCompletedSuccessfully' or $tcpar_Condition eq 'AbortedByClient' ) {
		for ( $CrashCount = 2 ; $CrashCount <= $tcpar_Number_of_crashes_Injected ; $CrashCount++ ) {
			for ( $CrashRead = 2 ; $CrashRead <= $CrashCount ; $CrashRead++ ) {
				if ( ( $CrashCount == 2 ) ) {
					my $CrashRead_Temp = $CrashRead - 1;
					S_w2rep( "\n Comparing The Arrays EDR_Reponse_Hash_1[$CrashRead] and  EDR_Reponse_Hash_0[$CrashRead_Temp] ! \n", "blue" );
					GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_1{$CrashRead}, $EDR_Reponse_Hash_0{ $CrashRead - 1 }, 'Equal' );
				}
				if ( ( $CrashCount == 3 ) ) {
					my $CrashRead_Temp = $CrashRead - 1;
					S_w2rep( "\n Comparing The Arrays EDR_Reponse_Hash_2[$CrashRead] and  EDR_Reponse_Hash_1[$CrashRead_Temp] ! \n", "blue" );
					GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_2{$CrashRead}, $EDR_Reponse_Hash_1{ $CrashRead - 1 }, 'Equal' );
				}
				if ( ( $CrashCount == 4 ) ) {
					my $CrashRead_Temp = $CrashRead - 1;
					S_w2rep( "\n Comparing The Arrays EDR_Reponse_Hash_3[$CrashRead] and  EDR_Reponse_Hash_2[$CrashRead_Temp] ! \n", "blue" );
					GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_3{$CrashRead}, $EDR_Reponse_Hash_2{ $CrashRead - 1 }, 'Equal' );
				}
				if ( ( $CrashCount == 5 ) ) {
					my $CrashRead_Temp = $CrashRead - 1;
					S_w2rep( "\n Comparing The Arrays EDR_Reponse_Hash_4[$CrashRead] and  EDR_Reponse_Hash_3[$CrashRead_Temp] ! \n", "blue" );
					GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_4{$CrashRead}, $EDR_Reponse_Hash_3{ $CrashRead - 1 }, 'Equal' );
				}
				if ( ( $CrashCount == 6 ) ) {
					my $CrashRead_Temp = $CrashRead - 1;
					S_w2rep( "\n Comparing The Arrays EDR_Reponse_Hash_5[$CrashRead] and  EDR_Reponse_Hash_4[$CrashRead_Temp] ! \n", "blue" );
					GEN_EVAL_CompareNumArrays( $EDR_Reponse_Hash_5{$CrashRead}, $EDR_Reponse_Hash_4{ $CrashRead - 1 }, 'Equal' );
				}
			}
		}
	}
	elsif ( $tcpar_Condition eq 'AbortedByDetectedFailure' or $tcpar_Condition eq 'AbortedByDetectedFailureAfterCompletedSuccessfully' ) {
		S_w2rep( "\n No Comparision is required, Becuase the All the Reponses are NRCs! \n", "brown" );
	}
	else {
		S_set_error( "$tcpar_Condition is Invalid!", 0 );
	}
	############### Comparing the EDR Data Is Completed ###################

	############### Verifying the Header Of All Six Crashes ###################
	if ( $tcpar_Condition eq 'CompletedSuccessfully' or $tcpar_Condition eq 'Idle' or $tcpar_Condition eq 'Running' or $tcpar_Condition eq 'AbortedByClientAfterCompletedSuccessfully' or $tcpar_Condition eq 'AbortedByClient' ) {
		for ( $CrashRead = 1 ; $CrashRead <= $tcpar_Number_of_crashes_Injected ; $CrashRead++ ) {
			$EDR_HeaderBytes{$CrashRead} = EDR_CD_readHeader( $Responses_Hash_5{$CrashRead} );

			S_w2rep( "\n Verifying the Header Bytes of EDR_Reponse_Hash_5[$CrashRead]! \n", "blue" );

			GEN_EVAL_CompareNumArrays( $EDR_HeaderBytes{$CrashRead}, \@Header_Bytes, 'Equal' );
		}

	}
	###############  Verifying Header  Is Completed ###################

	S_teststep( "Evaluation for Step 10.Fault recorder contains  'FltEdrDataAreaFull' if 5  crashes are  injected",                    'AUTO_NBR' );
	S_teststep( "Evaluation for Step 11.Response contains DTC corresponding to  'FltEdrDataAreaFull' if deployemnt crash is injected", 'AUTO_NBR' );
	FM_checkFaultStatus( $flt_mem_struct_PD_AfterCrash, 'FltEdrDataAreaFull', 0x1F );
	FM_checkFaultStatus( $flt_mem_struct_CD_AfterCrash, 'FltEdrDataAreaFull', 0x89 );

	S_teststep( "Evaluation for Step 12.session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 13.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 14.Positive response is obtained", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 15.Routine is successful ", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 16.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 17. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'Running'", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 18. Positive response is obtained for each request with StartRoutineStateOfOperarion as 'CompletedSuccessfully'", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 19.session is entered", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 20.", 'AUTO_NBR' );
	S_w2rep( "This Step is Evaluated in Stimulation And Measurement Only  ", 'blue' );

	S_teststep( "Evaluation for Step 21.  Positive Response is obtained  for all EDR Entries  with empty Header", 'AUTO_NBR' );
	foreach my $EDREntries (@$tcpar_EDR_Entries) {
		if ( $EDR_EmptyHeaderBytes{$EDREntries} )    #check if array ref is not empty
		{
			GEN_EVAL_CompareNumArrays( $EDR_EmptyHeaderBytes{$EDREntries}, $tcpar_Empty_Header_Bytes, 'Equal' );
		}
	}

	S_teststep( "Evaluation for Step 22.Fault recorder does NOT contain any 'FltEdrDataAreaFull' ", 'AUTO_NBR' );
	FM_checkFaultStatus( $flt_mem_struct_PD_AfterResetCompleteEDR, 'FltEdrDataAreaFull', 0x00 );

	S_teststep( "Evaluation for Step 23.Response does NOT contains DTC corresponding to  'FltEdrDataAreaFull' ", 'AUTO_NBR' );
	FM_checkFaultStatus( $flt_mem_struct_CD_AfterResetCompleteEDR, 'FltEdrDataAreaFull', 0x00 );
	return 1;
}

sub TC_finalization {
	GDCOM_stop_CyclicTesterPresent();
	return 1;
}

1;
