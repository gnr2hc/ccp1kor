package LIFT_Testbenches;

use File::Basename;
use Cwd 'abs_path';
my $PRJCFG_path = abs_path( dirname($main::opt_conf) );    #   absolute path like C:\working_somewhere\...\lift_project_config\

#our $Testbench;
$Testbench = {

	'HC-C-0001G' => {                                      # LIFT PC host name  / MLC1123 with RefType4 + MANITOO
		### ----------- Device Configuration Section -----------
		'Devices' => {

			'PDLayer' => {                                 # example values given here
				'BusType'             => 'CANFD',          # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 0,                # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 9497,             # Vector hardware serial number
			},
			'LabCar' => {                                  ####   'Labcar'  means MLC   (for historical reasons)
				'Hostname'          => 'HC-C-0001G',
				'Test_Bench_Number' => "MLC1123",                       # number of test bench (Laborplatz)
				'Description'       => "MLC with RefType4 + MANITOO",
				'CANchannel'        => 2,                               # CAN channel used to communicate with MLC
				'CANHWSerialNo'     => 9497,                            # Serial number of Vector CAN hardware
			},
			'CD' => {
				'Hostname'      => 'HC-C-0001G',
				'CANHWSerialNo' => 9497,
				'CANchannel'    => 1,
			},
			'Manitoo' => {
				'Connection_Type'    => 'COM15',
				'FET_HW_Type'        => 'FET_3_Ports',                  # FET_3_Ports , FET_6_Ports, FET_15_Ports
				'FET_PortsSelection' => 1                               # If only one port on/off  -> 1 or 2 or 3...
			},

			'CANoe' => {
				'Hostname' => 'HC-C-0001G',

				# 'Log_File' => 'D:\AB12\config\Tools\CANoe\AB12_Bussimulation_InteractionLayer\LogFiles\CANOE.asc',
				# 'Online_Config' =>'D:\AB12\config\Tools\CANoe\AB12_Bussimulation_InteractionLayer\AB12_CoreAssets_ISS-IDF_IL_Layer_CANoe9.cfg',
				'Online_Config' => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_Bussimulation_CANFD.cfg",
				'Log_File'      => 'C:\temp\CANOE.asc',
			},
		},

		## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {

			### ----------- TESTBENCH TYPE : DEFAULT -----------
			'Labcar' => {
				'power_Ubat' => 'MLC',    # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX, IXS, GOS1, PRITT, NONE
				'line'       => 'MLC',
			},

			'ProdDiag' => {               ### when use of new LIFT_ProdDIag
				'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			'CD' => 'CAN',

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',
			},

			### ----------- TESTBENCH TYPE : SPI_Manipulation -----------
			'SPI_Manipulation' => {

				'SPI_Access' => {
					'trace'      => 'Manitoo',    #Device used to take trace
					'manipulate' => 'Manitoo'
				},

				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},

				'ProdDiag' => {                   ### when use of new LIFT_ProdDIag
					'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CD'     => 'CAN',                # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices
				'Labcar' => {
					'power_Ubat' => 'MLC',        # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX, IXS, GOS1, PRITT, NONE
					'line'       => 'MLC',
					'disposal'   => 'MLC',
				},

			},

		},    ## end of ~~~ Function Configuration Section ~~~
	},    ## end of :     'HC-C-0001G' => {                                      # LIFT PC host name  / MLC with RefType4 + MANITOO

	### ----------- LIFT control host -----------
	'BMH1073363' => {    #   test tower for normal execution and test development  / never jenkins usage
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'BMH1073363',
				'Test_Bench_Number' => "TS 020 (TestSetup 020)",    # test bench number / name
				'Description'       => "AB12 CA SW RBT RT4",        # test bench description
				'CANHWSerialNo'     => 29845,                       # VN1640A
				'CANchannel'        => 2,                           # used CAN channel for TSG4 control
			},

			'PDLayer' => {                                          # example values given here,
				'BusType'             => 'CANFD',                   # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 0,                         # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 29845,                     # Vector hardware serial number
			},

			'Manitoo' => {
				'Connection_Type'    => 'COM6',
				'FET_HW_Type'        => 'FET_3_Ports',
				'FET_PortsSelection' => 1,
			},

			'CD' => {
				'Hostname'      => 'BMH1073363',
				'CANHWSerialNo' => 29845,

				#               'AB12'          => 1,
				'CANchannel' => 1,
			},

			'CANoe' => {
				'Hostname'      => 'BMH1073363',
				'Online_Config' => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_Bussimulation_CANFD.cfg",
				'Log_File'      => 'C:\temp\CANOE.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### ----------- Default Functions -----------
			'Labcar' => {
				'line'       => 'TSG4',
				'extended'   => 'TSG4',
				'disposal'   => 'TSG4',
				'power_Ubat' => 'TSG4',
				'power_UF'   => 'TSG4',

				#               'measure_connector'     => 'TSG4',
				#               'measure_trace_digital' => 'LCT',
				#               'measure_trace_analog'  => 'TRC',
				#               'measure_once'          => 'DMM1',
			},

			'ProdDiag' => {
				'generation' => 'AB12',
				'basic'      => 'PDLayer',
			},

			'CD' => 'CAN',    # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',
			},

			'PSI5_Access' => {
				'simulate' => 'Manitoo',    #Device used to simulate
			},

			## end of ~~~ Default Functions ~~~

			### ----------- Test Type Section (examples) -----------
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'SI-Z0OUS' => {    # LIFT PC host name  -  MANITOO TESTBENCH AB12.1 RT4  () in Dz office )
		### ----------- Device Configuration Section -----------
		'Devices' => {

			'PDLayer' => {    # example values given here
				'BusType'             => 'CAN',    # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 1,        # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 16030,    # Vector hardware serial number
			},

			'Manitoo' => {
				'Connection_Type'    => 'COM5',
				'FET_HW_Type'        => 'FET_3_Ports',
				'FET_PortsSelection' => 1,
				'Description'        => "only for Manitoo testing ",    # only for logging purpose
			},
			'PeriBox' => {
				'Description'       => "Peribox Manitoo RefType4 Testbench",
				'Test_Bench_Number' => 'SI-Z0OUS',                             # number of test bench (Laborplatz)
			},
			'PD' => {
				'Hostname'      => 'SI-Z0OUS',
				'CANHWSerialNo' => '957',                                      # VN8912A  device
				'CANchannel'    => 3,                                          # to be checked with PsDiag
			},
			'CD'    => { 'CANchannel' => 2, },
			'GPIB'  => { 'Hostname'   => 'SI-Z0OUS', },
			'CANoe' => {              # to be checked
				'Hostname'      => 'SI-Z0OUS',
				'Online_Config' => 'D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\AB12_Bussimulation_InteractionLayer\\AB12_CoreAssets_IL_Layer_CANoe9.cfg',
				'Log_File'      => 'D:\\MKS\\TurboLIFT\\temp\\CANOE.asc',
				'ILUsed'        => 'Yes',                                                                                                                        # Option : 'Yes' if Interaction layer used , otherwise 'No'
			},

			# not used yet / is defined in Mapping_LA_Acute
			#			'LA_AcuteTravelLogic' => {
			#				# used as default for SPI_logicanalyzer_store
			#				'LA_viewer_template' => dirname($main::opt_conf) . '\Tools\LA_AcuteTravelLogic\AB12_ManiToo_LIFT_Interface_Template.law' ,
			#			},
			# 			'Renesas_Flash_Tool' => {
			# 				'ECU_type' => 'D3A',             #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
			# 												 #  RenesasR1xTypeB = "R1L"
			# 												 #  RenesasR1x10623 = "R1L"
			# 												 #  RenesasR1xTypeC = "R1L1MB"
			# 												 #  RenesasR1x10643 = "R1L1MB"
			# 												 #  RenesasP1xD3    = "D3"
			# 												 #  RenesasP1xD4    = "D4"
			# 			   #  user can also use their own configuration by giving it as ECU type string in this format 'rwsProj;needsCleanHex;extendCodeFlash'
			# 			   #  e.g.: geely;1;1 where geely has to be a folder below config/Tools/Renesas with same structure like R1L1MB_ecuFlash
			# 				'FlashTool_Sl_Num' => '2CS029571',   #  written on flashtool
			# 			},
			# 			'SPIMaid' => {
			# 				'ProjectPath' => "D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\SPIMaid\\AB1200_BD_0105_conf_1_5DR.prj",
			# 			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {

			'Labcar' => {    # see documentaton of LIFT_labcar for possible devices
				'line'       => 'PeriBox_NoPower',    # possible devices: TSG4, MLC, PeriBox
				                                      #'extended' =>              'TSG4',       # device only TSG4
				                                      #'disposal' =>              'TSG4',       # possible devices: TSG4, MLC (with ACL box),
				                                      # PeriBox (with ACL box)
				'power_Ubat' => 'Manitoo',            # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				                                      # IXS, GOS1, PRITT, Manitoo, NONE
				                                      #'power_UF' =>              'TOELLNER',  # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				                                      # IXS, GOS1, PRITT, NONE
				                                      #'measure_connector' =>     'TSG4',      # possible devices: TSG4, wired
				                                      #'measure_trace_digital' => 'LCT',       # possible devices: TRC, LCT
				                                      #'measure_trace_analog' =>  'TRC',       # device only TRC
				                                      #'measure_once' =>          'DMM1',      # possible devices: DMM1, later possibly more
			},
			'PSI5_Access' => {
				'simulate' => 'Manitoo',              #Device used to simulate
			},
			'SPI_Access' => {
				'trace'      => 'Manitoo',            # function groups: trace, manipulate
				'manipulate' => 'Manitoo',            #Manitoo

				# 				'logicanalyzer' => 'LA_AcuteTravelLogic',         # currently not connected / but available ( ask Willi Petkof to connect )
			},
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'basic'     => 'CANoe',               # function groups: read, write, trace, simulation
				'stimulate' => 'CANoe',               # function groups: Stimulate signals , call CAPL
			},

			'PD' => 'PD',
			'CD' => 'CAN',                            #either 'CAN' (for CD via CANoe module) or 'ODIS' (for CD via ODIS tool)

		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'BMH1009211' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Hostname'          => 'BMH1009211',
				'Serial_Number'     => 'svt_18',       # LabCar serial number
				'Test_Bench_Number' => 'lab1',         # number of test bench (Laborplatz)
				'Description'       => "Sv Team",
				'CANchannel'        => 2,
				'CANdevice'         => 0,              # 1=CANcard, 0=CANcase
				'CANHWSerialNo'     => '041594',       # cancase serial number
			},
			'PD' => {
				'Hostname'      => 'BMH1009211',
				'CANchannel'    => 1,
				'CANdevice'     => 0,                  # 1=CANcard, 0=CANcase
				'CANHWSerialNo' => '041594',           # cancase serial number
				'AB12'          => 1,
			},
			'GPIB' => { 'Hostname' => 'BMH1009211', },
			'TOE1' => { 'connect'  => 'GPIB:8', },
			'IDX'  => { 'config'   => 'default.cfg', },
			'DSO1' => {
				'connect' => 'IP:10.47.105.52',        #LCRY0304M15306
			},
			'QT1'   => { 'controller' => 0, },
			'CANoe' => {
				'Hostname'      => 'BMH1009211',
				'Online_Config' => 'CAN_config_AB12.cfg',
				'Log_File'      => 'C:\\MKS\\Turbolift\\AB12\\config\\Tools\\CANoe\\CAN_TEST.asc',
			},
		},    ## End of ~~~ Device Configuration Section ~~~
		## ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'BMH1009213' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Hostname'          => 'bmh1009213',
				'Serial_Number'     => 'svt_18',       # LabCar serial number
				'Test_Bench_Number' => 'Muthu',        # number of test bench (Laborplatz)
				'Description'       => "Sv Team",
				'CANchannel'        => 2,
				'CANdevice'         => 0,              # 1=CANcard, 0=CANcase
				'CANHWSerialNo'     => '068278',       # cancase serial number
			},
			'PeriBox' => {
				'Hostname'          => 'bmh1009213',
				'Serial_Number'     => 'svt_18',       # LabCar serial number
				'Test_Bench_Number' => 'lab1',         # number of test bench (Laborplatz)
				'Description'       => "Sv Team",
				'CANchannel'        => 1,
				'CANdevice'         => 0,              # 1=CANcard, 0=CANcase
				'CANHWSerialNo'     => '068278',       # cancase serial number
			},
			'PD' => {
				'Hostname'      => 'bmh1009213',
				'CANchannel'    => 1,
				'CANdevice'     => 0,                  # 1=CANcard, 0=CANcase
				'CANHWSerialNo' => '068278',           # cancase serial number
				'AB12'          => 1,
			},
			'GPIB' => { 'Hostname' => 'bmh1009213', },
			'TOE1' => { 'connect'  => 'GPIB:8', },
			'IDX'  => { 'config'   => 'default.cfg', },
			'DSO1' => {
				'connect' => 'IP:10.47.105.52',        #LCRY0304M15306
			},
			'QT1'   => { 'controller' => 0, },
			'CANoe' => {
				'Hostname'      => 'bmh1009213',
				'Online_Config' => 'CAN_config_AB12.cfg',
				'Log_File'      => '\\\\bmh1009213\\c$\\MKS\\LIFT\\AB12\\config\\Tools\\CANoe\\CAN_TEST.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'KOR303582' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Hostname'          => 'KOR303582',
				'Serial_Number'     => 'svt_18',      # LabCar serial number
				'Test_Bench_Number' => 'lab1',        # number of test bench (Laborplatz)
				'Description'       => "Sv Team",
				'CANchannel'        => 2,
				'CANdevice'         => 0,             # 1=CANcard, 0=CANcase
				'CANHWSerialNo'     => '028258',      # cancase serial number
			},
			'PD' => {
				'Hostname'      => 'KOR303582',
				'CANchannel'    => 1,
				'CANdevice'     => 0,                 # 1=CANcard, 0=CANcase
				'CANHWSerialNo' => '028258',          # cancase serial number
				'AB12'          => 0,
			},
			'GPIB' => { 'Hostname' => 'KOR303582', },
			'TOE1' => { 'connect'  => 'GPIB:8', },
			'IDX'  => { 'config'   => 'default.cfg', },
			'DSO1' => {
				'connect' => 'IP:10.47.105.52',       #LCRY0304M15306
			},
			'QT1'   => { 'controller' => 0, },
			'CANoe' => {
				'Hostname'      => 'KOR303582',
				'Online_Config' => 'C:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\CAN_config_AB12.cfg',
				'Log_File'      => 'CAN_TEST.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	#         _           ___              _        _    ____  _ ____    ____ _____ _  _
	#     ___(_)     ____/ _ \  ___  _   _| |_     / \  | __ )/ |___ \  |  _ \_   _| || |
	#    / __| |____|_  / | | |/ _ \| | | | __|   / _ \ |  _ \| | __) | | |_) || | | || |_
	#    \__ \ |_____/ /| |_| | (_) | |_| | |_   / ___ \| |_) | |/ __/  |  _ < | | |__   _|
	#    |___/_|    /___|\___/ \___/ \__,_|\__| /_/   \_\____/|_|_____| |_| \_\|_|    |_|
	#
	'SI-Z0OUT' => {    # LIFT PC host name  -   JENKINS BasicTest Setup AB12.1 Igor / Thomas
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'PDLayer' => {    # example values given here
				'BusType'             => 'CANFD',    # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 0,          # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 24926,      # Vector hardware serial number
			},
			'CD' => {
				'Hostname'      => 'Z0OUT',
				'CANchannel'    => 1,
				'CANHWSerialNo' => '24926',          # '001446',
			},
			'CANoe' => {

				#  old: 'Online_Config' => 'C:\TurboLIFT\Projects\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation.cfg',
				# CANoe_simulation must be copied there from JENKINS scripts
				#
				# JENKINS_WORK_PATH +--+
				#                      +- test_automation -+
				#                      |                   +--lift_project_config ==> this is $PRJCFG_path
				#                      |
				#                      +- CANoe_simulation...   ==> here is CANoe config in project stream sandbox
				#                                                   to come to here jump 2 folder up and then down to CANoe....cfg
				#
				'Online_Config' => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => $PRJCFG_path . '\..\..\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'Hostname'      => 'SI-Z0OUT',

				# 'Keep_Application_After_Test' => 1 ,
			},
			'Renesas_Flash_Tool' => {
				'ECU_type'          => 'D3A',                              #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
				'FlashTool_Sl_Num'  => '2LS036928A',                       #  written on flashtool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
			},
		},
		### ----------- Function Configuration Section -----------
		'Functions' => {

			#
			# BEGIN standard config for BASIC_TEST
			#
			'BASIC_TEST' => {
				'Labcar' => {                                              # see documentaton of LIFT_labcar for possible devices
					'line'       => 'PeriBox_NoPower',                     # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'PRITT',                               # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
				'CAN_Access' => { 'basic' => 'CANoe', },
				'ProdDiag'   => {         ### when use of new LIFT_ProdDIag
					'generation' => 'AB12',                                # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                             # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
			},

			#
			# END standard config for BASIC_TEST
			#
			#
			# BEGIN standard config for BAT_REGRESSION_TEST
			#
			'BAT_REGRESSION_TEST' => {
				'Labcar' => {                                              # see documentaton of LIFT_labcar for possible devices
					'line'       => 'PeriBox_NoPower',                     # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'PRITT',                               # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX, Manitoo
				},

				'CAN_Access' => { 'basic' => 'CANoe', },

				#
				#				'NET_Access' => {
				#					'basic' =>  'CANoe', # function groups: read, write, trace, simulation
				#					# 'stimulate' => 'CANoeCtrl',
				#				},
				#
				#				'NET_Access' => {
				#					'basic' =>  'CANoe', # function groups: read, write, trace, simulation
				#					# 'stimulate' => 'CANoeCtrl',
				#				},

				'CD' => 'CAN',

				'ProdDiag' => {    ### when use of new LIFT_ProdDIag
					'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
			},

			#
			# END standard config for BAT_REGRESSION_TEST
			#

			#
			# BEGIN sub section 'FLASH_ONLY'
			#
			'FLASH_ONLY' => {
				'Labcar' => {                     # see documentaton of LIFT_labcar for possible devices
					'line'       => 'PeriBox_NoPower',    # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'PRITT',              # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
			},

			#
			# END sub section 'FLASH_ONLY'
			#

		},
	},

	'SI-Z0K52' => {                                       # LIFT PC host name  -  Willi Petkof PC
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'Manitoo' => {

				#                'Connection_Type' => 'COM11',
				'Connection_Type'    => 'COM15',
				'FET_HW_Type'        => 'FET_3_Ports',
				'FET_PortsSelection' => 1,
				'Description'        => "only for Manitoo testing ",    # only for logging purpose
			},
			'PeriBox' => {
				'Description'       => "Willi's PC",
				'Test_Bench_Number' => 'my desk',                       # number of test bench (Laborplatz)
			},
			'PD' => {
				'Hostname'      => 'SI-Z0K52',
				'CANHWSerialNo' => '957',                               # cancase serial number
				'CANchannel'    => 1,
			},
			'CD'      => { 'CANchannel' => 1, },
			'PDLayer' => {              # example values given here
				'BusType'             => 'FlexRay',                     # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 1,                             # Vector hardware channel number
				'Hw_Serial_Nbr'       => 957,                           # Vector hardware serial number
			},
			'GPIB'  => { 'Hostname' => 'SI-Z0K52', },
			'CANoe' => {
				'Hostname'      => 'SI-Z0K52',
				'Online_Config' => 'D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\CHASSIS_1.cfg',
				'Log_File'      => 'D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\Trace\\CANOE.asc',

				#				'Online_Config' => 'D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\AB12_Bussimulation_InteractionLayer\\AB12_CoreAssets_IL_Layer_CANoe9_1234.cfg',
				#				'Log_File'      => 'D:\\MKS\\TurboLIFT\\temp\\CANOE.asc',
				'ILUsed' => 'Yes',                                      # Option : 'Yes' if Interaction layer used , otherwise 'No'
			},
			'SPIMaid' => { 'ProjectPath' => "D:\\MKS\\TurboLIFT\\AB12\\config\\Tools\\SPIMaid\\AB1200_BD_0105_conf_1_5DR.prj", },
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			'Labcar' => { 'power_Ubat' => 'Manitoo' },

			# 'PSI5_Access' => {
			#    'simulate' => 'Manitoo',    #Device used to simulate
			#},
			'SPI_Access' => {
				'trace'         => 'Manitoo',               # function groups: trace, manipulate
				'manipulate'    => 'Manitoo',               #Manitoo
				'logicanalyzer' => 'LA_AcuteTravelLogic',
			},
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'basic'     => 'CANoe',                     # function groups: read, write, trace, simulation
				'stimulate' => 'CANoe',                     # function groups: Stimulate signals , call CAPL
			},
			'FlexRay_Access' => {
				'basic' => ['CANoe'],                       # function groups: read, write, trace
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},

			#	'CD' => 'CANoeFR',                 #either 'CAN' (for CD via CANoe module) or 'ODIS' (for CD via ODIS tool)
			'ProdDiag' => {
				'generation' => 'AB12',                     # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',                  # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'BMH318992' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Description'       => "SMA660 test bench",
				'Test_Bench_Number' => 'IN_CA_2',             # number of test bench (Laborplatz)
				'Hostname'          => 'BMH318992',
				'Serial_Number'     => 'SVT_MLC_13',          # LabCar serial number
				'CANHWSerialNo'     => '64964',               # cancase serial number
				'CANdevice'         => 0,                     # 1=CANcard, 0=CANcase
				'CANchannel'        => 2,
			},
			'PD' => {
				'Hostname'      => 'BMH318992',
				'CANHWSerialNo' => '64964',                   # cancase serial number
				'CANdevice'     => 0,                         # 1=CANcard, 0=CANcase
				'CANchannel'    => 1,
				'AB12'          => 1,
			},
			'GPIB'  => { 'Hostname' => 'BMH318992', },
			'TOE1'  => { 'connect'  => 'GPIB:8', },
			'DSO1'  => { 'connect'  => 'GPIB:1', },
			'QuaTe' => {
				'Controllers' => 1,                           # number of controllers connected
			},
			'IDX'   => { 'config' => 'default.cfg', },
			'CANoe' => {
				'Hostname'      => 'BMH318992',
				'Online_Config' => 'C:\\MKS\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANoe_AB12.cfg',
				'Log_File'      => 'C:\\MKS\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANOE_log.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'BMH318979' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Description'       => "CA Test Setup 1",
				'Test_Bench_Number' => 'IN_CA_1',           # number of test bench (Laborplatz)
				'Hostname'          => 'BMH318979',
				'Serial_Number'     => 'SVT_MLC_13',        # LabCar serial number
				'CANHWSerialNo'     => '64964',             # cancase serial number
				'CANdevice'         => 0,                   # 1=CANcard, 0=CANcase
				'CANchannel'        => 2,
			},
			'PD' => {
				'Hostname'      => 'BMH318979',
				'CANHWSerialNo' => '64964',                 # cancase serial number
				'CANdevice'     => 0,                       # 1=CANcard, 0=CANcase
				'CANchannel'    => 1,
				'AB12'          => 1,
			},
			'GPIB'  => { 'Hostname' => 'BMH318979', },
			'TOE1'  => { 'connect'  => 'GPIB:8', },
			'DSO1'  => { 'connect'  => 'GPIB:1', },
			'QuaTe' => {
				'Controllers' => 1,                         # number of controllers connected
			},
			'IDX'   => { 'config' => 'default.cfg', },
			'CANoe' => {
				'Hostname'      => 'BMH318979',
				'Online_Config' => 'C:\\MKS\\Projects\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANoe_AB12.cfg',
				'Log_File'      => 'C:\\MKS\\Projects\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANOE_log.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'KOR303581' => {    # LIFT PC host name        ---   // STILL ALIVE ??
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'LabCar' => {
				'Description'       => "CA Test Setup 5",
				'Test_Bench_Number' => 'IN_CA_5',           # number of test bench (Laborplatz)
				'Hostname'          => 'KOR303581',
				'Serial_Number'     => 'SVT_MLC_13',        # LabCar serial number
				'CANHWSerialNo'     => '27342',             # cancase serial number
				'CANdevice'         => 0,                   # 1=CANcard, 0=CANcase
				'CANchannel'        => 2,
			},
			'PD' => {
				'Hostname'      => 'KOR303581',
				'CANHWSerialNo' => '27342',                 # cancase serial number
				'CANdevice'     => 0,                       # 1=CANcard, 0=CANcase
				'CANchannel'    => 1,
				'AB12'          => 1,
			},
			'GPIB'  => { 'Hostname' => 'KOR303581', },
			'TOE1'  => { 'connect'  => 'GPIB:8', },
			'DSO1'  => { 'connect'  => 'GPIB:1', },
			'QuaTe' => {
				'Controllers' => 1,                         # number of controllers connected
			},
			'IDX'   => { 'config' => 'default.cfg', },
			'CANoe' => {
				'Hostname'      => 'KOR303581',
				'Online_Config' => 'C:\\MKS\\Projects\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANoe_AB12.cfg',
				'Log_File'      => 'C:\\MKS\\Projects\\TurboLIFT\\Projects\\AB12\\config\\Tools\\CANoe\\CANOE_log.asc',
			},
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### --- Function Area : Power, select device the power functions will be mapped to (LabCar,TOE1 or IDX)
			'POWER' => { 'device' => 'LabCar', },
			### --- Function Area : Peripherie, select device where ECU is connected to (PeriBox or LabCar)
			'PERIPHERIE' => { 'device' => 'LabCar', },
			### --- Function Area : CAN_Access
			'CAN_Access' => {
				'read'  => ['CANoe'],
				'write' => ['CANoe'],
				'trace' => ['CANoe'],
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'SI-Z0SFB' => {    # LIFT PC host name  - System Test TSG4 (No 01 - Boba Fett)
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'SI-Z0SFB',
				'Test_Bench_Number' => "TSG4 (No 01 - Boba Fett)",    # test bench number / name
				'Description'       => "AB12 CA CRAFT",               # test bench description
				'CANHWSerialNo'     => 3679,                          # VN1640A
				'CANchannel'        => 1,                             # used CAN channel for TSG4 control
			},
			'TOE1' => {
				'GPIB_device' => 0,
				'connect'     => "GPIB:8",
			},
			'TRC' => {

				#  'IP'   => "10.40.5.18:666",
				'IP'   => "10.40.5.18:10010",
				'Type' => 'MFTRC',                                    # Type can be 'MFTRC' or 'LTT'
			},

			#'DTM5080' => {
			#	'connect' => "COM1",
			#},
			'GPIB' => { 'Hostname' => 'SI-Z0SFB', },
			'PD'   => {
				'Hostname'      => 'SI-Z0SFB',
				'AB12'          => 1,
				'CANHWSerialNo' => 30595,                             #    VN1610
				'CANchannel'    => 1,

				#'CANHWSerialNo' => 58682,        #    CANcaseXL
				#'CANchannel'    => 1,
			},
			'CANoe' => {
				'Hostname' => 'SI-Z0SFB',

				#'Online_Config' => 'C:\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\AB12_Bussimulation_InteractionLayer\\AB12_CoreAssets_IL_Layer_CANoe9.cfg',
				#'Online_Config' => 'C:\\TurboLIFT\\AB12\\config\\Tools\\CANoe_simulation\\AB12_Bussimulation\\AB12_CoreAssets_Bussimulation.cfg',
				'Online_Config' => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation_saved\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => 'D:\\temp\\CANOE.asc',

				#'Log_File'      => 'C:\\temp\\CANOE.asc',
				'ILUsed' => 'Yes',
			},
			'VOETSCH' => {
				'compressor_bit' => 2,
				'connect'        => "COM1",
			},
			'DMM1' => {
				'resistance_mode' => 2,          #       2: two wire, 4: four wire measurement
				'connect'         => "GPIB:9",
			},

			#            'QuaTe' => {
			#                'Controllers' => 2,              # 2         # number of controllers for PSI tests
			#                                                 #'Controllers' => 3, 		# number of controllers for CREIS tests
			#            },
		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### ----------- Default Functions -----------
			'Labcar' => {
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TOE1',
				'power_UF'              => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'TRC',
				'measure_trace_analog'  => 'TRC',
				'measure_once'          => 'DMM1',
			},

			#'PD' => 'PD',    # only device PD is currently possible

			'ProdDiag' => {
				'generation' => 'AB12',
				'basic'      => 'PDLayer',
			},

			'CAN_Access' => {
				'basic' => 'CANoe',

				#'stimulate' => 'CANoe',
			},
			'SensorEmulator' => 'QuaTe',

			#            'Crash_simulation' => {
			#                'crash_database' => 'MDSRESULT',
			#                'crash_sensors'  => 'QuaTe',
			#                'trigger'        => 'QuaTe',
			#            },

			'Temperature' => {

				#'get' => 'NONE',
				'get' => 'VOETSCH',
				'set' => 'VOETSCH',
			},
			## end of ~~~ Default Functions ~~~

			### ----------- Test Type Section (examples) -----------
			'CREIS' => {    # test type for doing a complete crash injecton test
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TOE1',
					'power_UF'              => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'TRC',
					'measure_trace_analog'  => 'TRC',
					'measure_once'          => 'DMM1',
				},

				#'PD' => 'PD',    # only device PD is currently possible

				'ProdDiag' => {
					'generation' => 'AB12',
					'basic'      => 'PDLayer',
				},
				'CAN_Access' => {
					'basic' => 'CANoe',

					#'stimulate' => 'CANoe',
				},

				#                'Crash_simulation' => {
				#                    'crash_database' => 'MDSRESULT',
				#                    'crash_sensors'  => 'QuaTe',
				#                    'trigger'        => 'QuaTe',
				#                },
			},
			## end of ~~~ Test Type Section ~~~
			'BASIC' => {    # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TOE1',
					'power_UF'   => 'TSG4',
				},
				'CAN_Access' => {
					'basic' => 'CANoe',

					#'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {

					#'crash_sensors' => 'QuaTe',
					#'crash_database' => 'MDSRESULT',
					#'trigger'        => 'QuaTe',
				},
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'SI-Z0WHT' => {    #  LIFT PC host name  - System Test TSG4 (No 08 - IG-88)
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'SI-Z0WHT',
				'Test_Bench_Number' => "TSG4 (No 08 - IG-88)",    # test bench number / name
				'Description'       => "AB12 CA CRAFT",           # test bench description
				'CANHWSerialNo'     => 3682,                      # VN1640A
				'CANchannel'        => 1,                         # used CAN channel for TSG4 control
			},

			'TOE1' => {
				'GPIB_device' => 0,
				'connect'     => "GPIB:8",
			},

			'TRC' => {
				'IP'   => "10.40.5.18:10010",
				'Type' => 'MFTRC',                                # Type can be 'MFTRC' or 'LTT'
			},

			#           'DTM5080' => {
			#               'connect' => "COM1",
			#           },

			'GPIB' => { 'Hostname' => 'SI-Z0WHT', },
			'PD'   => {
				'Hostname'      => 'SI-Z0WHT',
				'AB12'          => 1,
				'CANHWSerialNo' => 30591,                         #    VN1640
				'CANchannel'    => 1,

				#               'CANHWSerialNo' => 57518,        #    CANcaseXL
				#               'CANchannel'    => 1,
			},
			'CD' => {
				'Hostname'      => 'SI-Z0WHT',
				'AB12'          => 1,
				'CANHWSerialNo' => 30591,                         #    VN1640
				'CANchannel'    => 1,

				#               'CANHWSerialNo' => 57518,        #    CANcaseXL
				#               'CANchannel'    => 1,
			},
			'CANoe' => {
				'Hostname' => 'SI-Z0WHT',

				#				'Online_Config' => 'C:\\TurboLIFT\\AB12\\config\\Tools\\CANoe\\AB12_Bussimulation_InteractionLayer\\AB12_CoreAssets_IL_Layer_CANoe9.cfg', # old version
				#				'Online_Config' => 'C:\\TurboLIFT\\AB12\\config\\Tools\\CANoe_simulation\\AB12_Bussimulation\\AB12_CoreAssets_Bussimulation.cfg',
				'Online_Config' => 'C:\\TurboLIFT\\AB12\\config\\Tools\\CANoe_simulation\\AB12_Bussimulation\\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => 'C:\\temp\\CANOE.asc',
				'ILUsed'        => 'Yes',
			},

			#           'VOETSCH' => {
			#               'compressor_bit' => 2,
			#               'connect'        => "COM1",
			#           },

			'DMM1' => {
				'resistance_mode' => 2,          #       2: two wire, 4: four wire measurement
				'connect'         => "GPIB:9",
			},

			'Manitoo' => {
				'Description'     => "Manitoo",     # only for logging purpose
				'Connection_Type' => 'COM5',
				'ManitooPAS'      => 'connected',
			},

		},    ## end of ~~~ Device Configuration Section ~~~
		### ----------- Function Configuration Section -----------
		'Functions' => {
			### ----------- Default Functions -----------
			'Labcar' => {
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TOE1',
				'power_UF'              => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'TRC',
				'measure_trace_analog'  => 'TRC',
				'measure_once'          => 'DMM1',
			},

			#  			'PD' => 'PD',    # only device PD is currently possible
			'ProdDiag' => {
				'generation' => 'AB12',
				'basic'      => 'PDLayer',
			},

			'CAN_Access' => {
				'basic' => 'CANoe',

				# 'stimulate' => 'CANoe',
			},

			'PSI5_Access' => {
				'simulate' => 'Manitoo',    # ManitooPAS or QuaTe
			},

			'Temperature' => {
				'get' => 'NONE',

				#				'get' => 'VOETSCH',
				#				'set' => 'VOETSCH',
			},

			## end of ~~~ Default Functions ~~~

			'BASIC' => {                    # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TOE1',
					'power_UF'   => 'TSG4',
				},
				'CAN_Access' => {
					'basic' => 'CANoe',

					#                   'stimulate' => 'CANoe',
				},
				'PSI5_Access' => {
					'simulate' => 'Manitoo',    # ManitooPAS or QuaTe
				},

			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},

	### ----------- LIFT control host -----------
	'SI-Z0QQE' => {    # LIFT PC host name  - System Test TSG4 (No 02 - Mara Jade)
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => "SI-Z0QQE",
				'Test_Bench_Number' => "TSG4 (No 02 - Mara Jade)",    # test bench number / name
				'Description'       => "AB12 CA CREIS",               # test bench description
				'CANHWSerialNo'     => 416,                           # VN8912
				'CANchannel'        => 3,                             # used CAN channel
			},
			'PD' => {
				'Hostname'      => "SI-Z0QQE",
				'AB12'          => 1,
				'CANHWSerialNo' => 3686,                              # VN1640A
				'CANchannel'    => 4,

				#'CANHWSerialNo' => 416,                               # VN8912
				#'CANchannel'    => 8,
			},
			'PDLayer' => {                                            # example values given here
				'BusType'             => 'CAN',                       # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 3,                           # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 3686,                        # Vector hardware serial number
				                                                      #'Channel_Nbr_0-based' => 7,                           # Vector hardware channel number (0-based)
				                                                      #'Hw_Serial_Nbr'       => 416,                         # Vector hardware serial number
			},
			'CANoe' => {
				'Hostname'      => 'SI-Z0QQE',
				'Log_File'      => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\LogFiles\CANOE.asc',
				'Online_Config' => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation.cfg',

				#                'Online_Config' => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'ILUsed' => 'Yes',
			},
			'GPIB' => { 'Hostname' => "SI-Z0QQE", },

			#'TOE1' => {
			#	'GPIB_device' => 0,
			#	'connect'     => "GPIB:8",
			#},
			#'DMM1' => {
			#	'resistance_mode' => 2,          # 2: two wire, 4: four wire measurement
			#	'connect'         => "GPIB:9",
			#},
			#'TRC' => {
			#   'IP'   => "10.40.5.18:666",
			#   'Type' => 'MFTRC',               # Type can be 'MFTRC' or 'LTT'
			#},
			#'VOETSCH' => {
			#	'compressor_bit' => 2,
			#	'connect'        => "COM1",
			#},
			#'DTM5080' => {
			#	'connect' => "COM1",
			#},
			'QuaTe' => {
				'Controllers' => 3,    # number of controllers connected
			},
		},    ## end of ~~~ Device Configuration Section ~~~

		### ----------- Function Configuration Section -----------
		'Functions' => {
			### ----------- Default Functions -----------
			'Labcar' => {
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'power_UF'              => 'TSG4',
				'measure_connector'     => 'wired',
				'measure_trace_digital' => 'LCT',

				# 'measure_trace_analog' => 'LCT',
				#'measure_once' => 'DMM1',
			},

			#'PD' => 'PD',    # only device PD is currently possible
			'ProdDiag' => {
				'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',
			},

			'SensorEmulator' => 'QuaTe',

			'Crash_simulation' => {
				'crash_database'  => 'MDSRESULT',
				'crash_sensors'   => 'QuaTe',
				'trigger'         => 'QuaTe',
				'network_dynamic' => 'can_access',
			},

			'Temperature' => {
				'get' => 'NONE',

				# 'set' => 'VOETSCH',
			},

			## end of ~~~ Default Functions ~~~

			### ----------- Test Type Section (examples) -----------
			'CREIS' => {    # test type for doing a complete crash injecton test
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'power_UF'              => 'TSG4',
					'measure_connector'     => 'wired',
					'measure_trace_digital' => 'LCT',

					# 'measure_trace_analog' => 'LCT',
					#'measure_once' => 'DMM1',
				},

				#'PD'         => 'PD',    # only device PD is currently possible
				'ProdDiag' => {
					'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {
					'crash_database'  => 'MDSRESULT',
					'crash_sensors'   => 'QuaTe',
					'trigger'         => 'QuaTe',
					'network_dynamic' => 'can_access',
				},
			},
			'BASIC' => {    # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TSG4',
				},
				'CAN_Access'       => { 'basic'         => 'CANoe', },
				'Crash_simulation' => { 'crash_sensors' => 'QuaTe', },
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},    ## end of ~~ SI-Z0QQE ~~

	### ----------- LIFT control host -----------
	'SI-Z0TXL' => {    # LIFT PC host name  - System Test TSG4 (No 0x - YT-1300)
		### ----------- Device Configuration Section -----------
		'Devices' => {
			'TSG4' => {
				'Hostname'          => "SI-Z0TXL",
				'Test_Bench_Number' => "TSG4 (No 0x - YT-1300)",    # test bench number / name
				'Description'       => "AB12 CA CREIS",             # test bench description
				'CANHWSerialNo'     => 417,                         # VN8912
				'CANchannel'        => 3,                           # used CAN channel
			},
			'PD' => {
				'Hostname'      => "SI-Z0TXL",
				'CANchannel'    => 4,
				'CANHWSerialNo' => 2897,                            # VN1640A
				'AB12'          => 1,
			},
			'PDLayer' => {
				'BusType'             => 'CAN',
				'Channel_Nbr_0-based' => 3,
				'Hw_Serial_Nbr'       => 2897,
			},
			'CANoe' => {
				'Hostname' => 'SI-Z0TXL',

				#'Online_Config' => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation.cfg',
				'Online_Config' => 'C:\TurboLIFT\AB12\config\Tools\CANoe_simulation\AB12_Bussimulation\AB12_CoreAssets_Bussimulation_CANFD.cfg',
				'Log_File'      => 'D:\\temp\\CANOE.asc',
				'ILUsed'        => 'Yes',
			},
			'GPIB' => { 'Hostname' => "SI-Z0TXL", },

			#'TOE1' => {
			# 	'GPIB_device' => 0,
			# 	'connect'     => "GPIB:8",
			# },
			'DMM1' => {
				'resistance_mode' => 2,           # 2: two wire, 4: four wire measurement
				'connect'         => "GPIB:22",
			},

			'TRC' => {
				'IP'   => "10.40.5.18:10010",
				'Type' => 'MFTRC',                # Type can be 'MFTRC' or 'LTT'
			},

			#'VOETSCH' => {
			#	'compressor_bit' => 2,
			#	'connect'        => "COM1",
			#},
			#'DTM5080' => {
			#	'connect' => "COM1",
			#},
			'QuaTe' => {
				'Controllers' => 2,               # number of controllers connected
			},
		},    ## end of ~~~ Device Configuration Section ~~~

		### ----------- Function Configuration Section -----------
		'Functions' => {
			### ----------- Default Functions -----------
			'Labcar' => {
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'power_UF'              => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',
				'measure_trace_analog'  => 'TRC',
				'measure_once'          => 'DMM1',
			},

			#			'PD' => 'PD',    # only device PD is currently possible

			'ProdDiag' => {
				'generation' => 'AB12',
				'basic'      => 'PDLayer',
			},

			'CAN_Access' => {
				'basic'     => 'CANoe',
				'stimulate' => 'CANoe',
			},

			'SensorEmulator' => 'QuaTe',

			'Crash_simulation' => {
				'crash_database'  => 'MDSRESULT',
				'crash_sensors'   => 'QuaTe',
				'trigger'         => 'QuaTe',
				'network_dynamic' => 'can_access',
			},

			'Temperature' => {
				'get' => 'NONE',

				# 'set' => 'VOETSCH',
			},

			## end of ~~~ Default Functions ~~~

			### ----------- Test Type Section (examples) -----------
			'CREIS' => {    # test type for doing a complete crash injecton test
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'power_UF'              => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
					'measure_trace_analog'  => 'TRC',
					'measure_once'          => 'DMM1',
				},

				#				'PD'         => 'PD',    # only device PD is currently possible

				'ProdDiag' => {
					'generation' => 'AB12',
					'basic'      => 'PDLayer',
				},

				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {
					'crash_database'  => 'MDSRESULT',
					'crash_sensors'   => 'QuaTe',
					'trigger'         => 'QuaTe',
					'network_dynamic' => 'can_access',
				},
			},
			'BASIC' => {    # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TSG4',

					#				'power_UF'              => 'TSG4',
				},
				'CAN_Access' => {
					'basic' => 'CANoe',

					#					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {

					#					'crash_database' => 'MDSRESULT',
					'crash_sensors' => 'QuaTe',

					#					'trigger'        => 'QuaTe',
				},
			},
		},    ## end of ~~~ Function Configuration Section ~~~
	},    ## end of ~~ SI-Z0TXL ~~

	### ----------- LIFT control host -----------
	'SI-Z0UYN' => {    # LIFT PC host name  -  Core Asset EDR setup   (good example for TSG4+LCT with crash setup)
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'SI-Z0UYN',
				'Test_Bench_Number' => 43,                       #     only for logging purpose
				'Description'       => "Core Asset EDR setup",
				'CANHWSerialNo'     => 2890,                     # 573, 2890            # 2890 -> VN1640
				'CANchannel'        => 3,                        # 2890 -> 3  ,        # VN1640 CH4        slot 2 on VN89xx Box, because FR channel does not count
				'POWER'             => {
					'Ubat' => "internal",                        #  POWER Devices:: LabCar,TOE1 or IDX
					'UF'   => "internal",                        #  POWER Devices:: LabCar,TOE1 or IDX
				},
			},

			'PD' => {

				#				'Hostname'      => 'SI-Z0UYN',
				#				'CANHWSerialNo' => 2890,  #573,
				'AB12' => 1,

				#				'CANchannel'    => 4, #9,
			},

			'PDLayer' => {    # example values given here
				'BusType'             => 'CAN',    # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 0,        # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 573,      # Vector hardware serial number                573 ->   VN89xx Box
			},

			# 'PDLayer' => {    # example values given here
			# 'BusType'             => 'CAN',    # bus type, possible values are 'CAN', 'FlexRay'
			# 'Channel_Nbr_0-based' => 3,        # Vector hardware channel number (0-based)
			# 'Hw_Serial_Nbr'       => 2890,     # Vector hardware serial number
			# },
			'CD' => {
				'Hostname'      => 'SI-Z0UYN',
				'CANHWSerialNo' => 2890,

				# 'AB12'          => 1,
				'CANchannel' => 2,    # f�r 573
			},
			'QuaTe' => {
				'Controllers' => 2,    #RT4, RT3.2: 2 - RT3: 3             #   number of controllers connected
			},
			'CANoe' => {
				'Hostname'      => 'SI-Z0UYN',
				'Log_File'      => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/LogFiles/CANOE.asc",
				'Online_Config' => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_Bussimulation_CANFD.cfg",
				'ILUsed'        => 'Yes',
			},

			'Manitoo' => {
				'Description'     => "SPI manipulation Tool",    # only for logging purpose
				'Connection_Type' => 'COM6',                     # com port detected when connected to TestPC
			},
		},
		'Functions' => {
			'Labcar' => {                                        # see documentaton of LIFT_labcar for possible devices
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',
			},

			'ProdDiag' => {
				'generation' => 'AB12',                          # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',                       # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			#			'PD' => 'PD',

			'CD' => 'CAN',                                       # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'CAN_Access' => {
				'basic' => 'CANoe',                              # function groups: read, write, trace, simulation
				                                                 # 'stimulate' => 'CANoe',
			},

			#			'NET_Access' => {
			#            	'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
			#            	'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
			#        	},
			### --- Function Area : Crash_simulation, function groups for crash database access, download to simulators and triggering the simulated crash
			'Crash_simulation' => {
				'crash_database' => 'MDSRESULT',                 # possible devices: MDSRESULT
				'crash_sensors'  => 'QuaTe',                     # possible devices: QuaTe, IDEFIX
				'trigger'        => 'QuaTe',                     # possible devices: QuaTe, IDEFIX, can_access
			},

			'BASIC' => {                                         # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TSG4',
				},
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',             # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',                 # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',                 # possible devices: QuaTe, IDEFIX, can_access
				},
			},
			'CREIS' => {                                         # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				'ProdDiag' => {
					'generation' => 'AB12',                      # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                   # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CD'         => 'CAN',
				'CAN_Access' => {
					'basic' => 'CANoe',

					# 'stimulate' => 'CANoe',
				},

				#				'NET_Access' => {
				#	            	'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
				#	            	'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
				#        		},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			},
			'SPI_Manipulation' => {
				### --- Function Area : SPI_Access, select device used for trace / manipulate
				'SPI_Access' => {                       # currently no alternative configuration possible
					                                    # function groups: trace, manipulate
					'manipulate' => 'Manitoo',          # possible devices only Manitoo
					'trace'      => 'Manitoo',          # possible devices Manitoo or SPIMaid (manual start/stop only)
				},
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				'ProdDiag' => {
					'generation' => 'AB12',       # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',    # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CD'         => 'CAN',
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			}
		},
	},    ## end of ~~ SI-Z0UYN ~~

	### ----------- LIFT control host -----------
	'BIEZ00HL' => {    # LIFT PC host name  -  Core Asset EDR setup   (good example for TSG4+LCT with crash setup)
		'Devices' => {
			'TSG4' => {
				'Hostname'          => 'BIEZ00HL',
				'Test_Bench_Number' => 20,                                #     only for logging purpose
				'Description'       => "Core Asset EDR setup L2B-R1.4",
				'CANHWSerialNo'     => 3685,                              # 573, 2890            # 2890 -> VN1640
				'CANchannel'        => 2,                                 # 2890 -> 3  ,        # VN1640 CH4        slot 2 on VN89xx Box, because FR channel does not count
				'POWER'             => {
					'Ubat' => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
					'UF'   => "internal",                                 #  POWER Devices:: LabCar,TOE1 or IDX
				},
			},

			'PD' => {

				#				'Hostname'      => 'BIEZ00HL',
				#				'CANHWSerialNo' => 2890,  #573,
				'AB12' => 1,

				#				'CANchannel'    => 4, #9,
			},

			'PDLayer' => {    # example values given here
				'BusType'             => 'CANFD',    # bus type, possible values are 'CAN', 'FlexRay'
				'Channel_Nbr_0-based' => 3,        # Vector hardware channel number (0-based)
				'Hw_Serial_Nbr'       => 3685,     # Vector hardware serial number                573 ->   VN89xx Box
			},

			# 'PDLayer' => {    # example values given here
			# 'BusType'             => 'CAN',    # bus type, possible values are 'CAN', 'FlexRay'
			# 'Channel_Nbr_0-based' => 3,        # Vector hardware channel number (0-based)
			# 'Hw_Serial_Nbr'       => 2890,     # Vector hardware serial number
			# },
			'CD' => {
				'Hostname'      => 'BIEZ00HL',
				'CANHWSerialNo' => 3685,

				# 'AB12'          => 1,
				'CANchannel' => 3,    # f�r 573
			},
			'QuaTe' => {
				'Controllers' => 2,    #RT4, RT3.2: 2 - RT3: 3             #   number of controllers connected
			},
			'CANoe' => {
				'Hostname'      => 'BIEZ00HL',
				'Log_File'      => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/LogFiles/CANOE.asc",
				'Online_Config' => $PRJCFG_path . "/Tools/CANoe_simulation/AB12_Bussimulation/AB12_CoreAssets_Bussimulation_CANFD_318.cfg",
				'ILUsed'        => 'Yes',
			},
			'Renesas_Flash_Tool' => {
				'ECU_type'          => 'D3A',                              #  ECU_type can be R1L, R1L1MB, D4 or D3 or D3A
				'FlashTool_Sl_Num'  => '7CS106857C',                       #  written on tool
				'Project_Workspace' => $PRJCFG_path . '\Tools\Renesas',    # Renesas project workspace
			},
		},
		'Functions' => {
			'Labcar' => {                                                  # see documentaton of LIFT_labcar for possible devices
				'line'                  => 'TSG4',
				'extended'              => 'TSG4',
				'disposal'              => 'TSG4',
				'power_Ubat'            => 'TSG4',
				'measure_connector'     => 'TSG4',
				'measure_trace_digital' => 'LCT',
			},

			'ProdDiag' => {
				'generation' => 'AB12',                                    # Airbag generation, possible values: currently 'AB12' only
				'basic'      => 'PDLayer',                                 # Device for function group 'basic' (all functions): device currently only 'PDLayer'
			},

			#			'PD' => 'PD',

			'CD' => 'CAN',                                                 # was formerly 'Diagnosis', see documentaton of LIFT_CD for possible devices

			'CAN_Access' => {
				'basic' => 'CANoe',                                        # function groups: read, write, trace, simulation
				                                                           # 'stimulate' => 'CANoe',
			},

			#			'NET_Access' => {
			#            	'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
			#            	'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
			#        	},
			### --- Function Area : Crash_simulation, function groups for crash database access, download to simulators and triggering the simulated crash
			'Crash_simulation' => {
				'crash_database' => 'MDSRESULT',                           # possible devices: MDSRESULT
				'crash_sensors'  => 'QuaTe',                               # possible devices: QuaTe, IDEFIX
				'trigger'        => 'QuaTe',                               # possible devices: QuaTe, IDEFIX, can_access
			},

			'BASIC' => {                                                   # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'       => 'TSG4',
					'extended'   => 'TSG4',
					'disposal'   => 'TSG4',
					'power_Ubat' => 'TSG4',
				},
				'CAN_Access' => {
					'basic'     => 'CANoe',
					'stimulate' => 'CANoe',
				},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',                       # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',                           # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',                           # possible devices: QuaTe, IDEFIX, can_access
				},
			},
			'FLASH_ONLY' => {
				'Labcar' => {                                              # see documentaton of LIFT_labcar for possible devices
					'line'       => 'TSG4',                                # possible devices: TSG4, MLC, PeriBox
					'power_Ubat' => 'TSG4',                                # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX,
				},
			},
			'CREIS' => {                                                   # test type for switching ON and OFF ECU
				'Labcar' => {
					'line'                  => 'TSG4',
					'extended'              => 'TSG4',
					'disposal'              => 'TSG4',
					'power_Ubat'            => 'TSG4',
					'measure_connector'     => 'TSG4',
					'measure_trace_digital' => 'LCT',
				},

				#				'PD' => 'PD',
				'ProdDiag' => {
					'generation' => 'AB12',                                # Airbag generation, possible values: currently 'AB12' only
					'basic'      => 'PDLayer',                             # Device for function group 'basic' (all functions): device currently only 'PDLayer'
				},
				'CD'         => 'CAN',
				'CAN_Access' => {
					'basic' => 'CANoe',

					# 'stimulate' => 'CANoe',
				},

				#				'NET_Access' => {
				#	            	'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
				#	            	'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL
				#        		},
				'Crash_simulation' => {
					'crash_database' => 'MDSRESULT',    # possible devices: MDSRESULT
					'crash_sensors'  => 'QuaTe',        # possible devices: QuaTe, IDEFIX
					'trigger'        => 'QuaTe',        # possible devices: QuaTe, IDEFIX, can_access
				},
			},
		},
	},    ## end of ~~ BIEZ00HL ~~
};
