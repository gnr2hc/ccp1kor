package LIFT_config;

### Project Specific Config for LIFT_exec_engine

use Sys::Hostname;
use File::Basename;
use File::Spec;

our ( $left_logo, $right_logo, $LIFT_ProjectDescription, $LIFT_host, $LIFT_exec_path, $LIFT_PRJCFG_path );
our ( $SAD_file, $LIFT_TC_path, $LIFT_TC_DOCS_path, $LIFT_PARA_path, $LIFT_LOG_path, $LIFT_RES_path, $SYC_export_pm_file, $SYC_variant_name );
our ( $LIFT_TC_INIT_path, $LIFT_TC_INIT_CAMPAIGN, $LIFT_Simulator );

$LIFT_ProjectDescription = "AB12.1 Core Asset - RT4 B0";

$LIFT_host             = hostname();                              ### LIFT host
$LIFT_exec_path        = dirname($0);                             ### LIFT exec path = path from called LIFT_exec_engine
$LIFT_PRJCFG_path      = dirname(__FILE__);                       ### Project Configuration PATH = from called Project Configuration
$LIFT_LOG_path         = "$LIFT_PRJCFG_path/../reports/";         ### LOGS PATH
$LIFT_LOG_path         = File::Spec->rel2abs("$LIFT_LOG_path");
$LIFT_RES_path         = "$LIFT_PRJCFG_path/../reports/";         ### RESULTS PATH
$LIFT_RES_path         = File::Spec->rel2abs("$LIFT_RES_path");
$LIFT_PARA_path        = "$LIFT_PRJCFG_path/../TC_par/";          ### TESTCASE PARAMETERS
$LIFT_TC_path          = "$LIFT_PRJCFG_path/../TCs/";             ### TESTCASE MODULES
$LIFT_TC_DOCS_path     = "$LIFT_TC_path/Documentation/html/";     ### TESTCASE DOCUMENTATION
$left_logo             = '.\htmldata\images\logo_left.png';       ### TODO : to be set correctly
$right_logo            = '.\htmldata\images\logo_right.png';      ### TODO : to be set correctly
$LIFT_TC_INIT_path     = "$LIFT_PRJCFG_path";
$LIFT_TC_INIT_CAMPAIGN = "IC_AB12_CA.DEFAULT";                    ### Init campaign to be executed / can be even set via cmd line option -IC xxxx

# $LIFT_TC_END_path        = "$LIFT_PRJCFG_path/IC";                  ### End campaign path
# $LIFT_TC_END_CAMPAIGN    = "EC_CI";                                 ### End campaign to be executed

### replace path with SAD file for ECU SW
$SAD_file = $LIFT_PRJCFG_path . "/SW/AB1210_B0_0018_BB031802_Cat2/AB1210_B0_0018_BB031802_Cat2.sad";

### used pv SYC export
# RT4 - A0 Muster
# our $SYC_export_pm_file = './config/SysTestExport_AB12_RefType4_SYC.pm';
# RT4 - M03.17
$SYC_export_pm_file = './config/SysTestExport_AB12_RefType4_SYC_M03_18.pm';
$SYC_variant_name   = "AB12_RefType4_SYC_General_Rev_1_36";
#### PROJECT Defaults
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_Main.pm";     # contains package LIFT_PROJECT
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_TSG4.pm";     # use Device mapping file
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_QuaTe.pm";    # contains package LIFT_PROJECT
require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_ProjectConst_CREIS.pm";    # CREIS defaults AB12_ProjectConst_SPI
require "$LIFT_PRJCFG_path/Mappings/AB12_ProjectConst_SPI.pm";
$LIFT_ProjectDefaults = $LIFT_PROJECT::Defaults;                             # initial assignment of  $LIFT_ProjectDefaults

### Testbench configuration
require "$LIFT_PRJCFG_path/LIFT_Testbenches.pm";
$LIFT_Testbench = $LIFT_Testbenches::Testbench->{$LIFT_host};

unless ( $LIFT_Simulator = $LIFT_Testbench->{'Devices'}{'LabCar'}{'Serial_Number'} ) {
	$LIFT_Simulator = 'None_LIFT_LC';
}

if ( -f "$LIFT_PRJCFG_path/Mappings/AB12_PD_Diagmapping.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/AB12_PD_Diagmapping.pm";
	$LIFT_DiagMapping = $LIFT_DIAG_MAPPING::Mapping;
}
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_PSI5_settings_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_PSI5_settings_RefType4.pm";
}

if ( -f "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_CAN_mapping.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/AB12_RefType4_CAN_mapping.pm";
	$LIFT_CanMapping = $LIFT_PROJECT::Defaults->{'Mapping_CAN'};
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_DIAG.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_DIAG.pm";
	$LIFT_DiagMapping = $LIFT_DIAG_MAPPING::Mapping;
}

## handling for including ProjConst for Manitoo might be extended with oontrol of different Mappings via ENV vars
if ( -f "$LIFT_PRJCFG_path/Mappings/AB12_ProjectConst_ManiToo_SMA760_SMA720.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/AB12_ProjectConst_ManiToo_SMA760_SMA720.pm";
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_SPI_network_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_SPI_network_RefType4.pm";
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_Fault.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_Fault.pm";
	$LIFT_FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_Fault'};
}
####temp added################################################################
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_FAULT_extension.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_FAULT_extension.pm";
	$LIFT_FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_Fault'};
}
##############################################################################



### EDR mapping
# This file is generated by SCIP -> it must be replaced for every SW checkpoint!
our $EDR_variant_name = 'EdrRefType4';
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_Core_Asset_AB12_RefTyp4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_Core_Asset_AB12_RefTyp4.pm";
	unless ( defined $ENV{'REGULATION'} ) {
		#StorageOrder will be set in Mapping_EDR_Core_Asset_AB12_RefTyp4, #CHINA = MostRecentFirst ; NHTSA = PhysicalOrder before run the test
	}
	else {
		#StorageOrder will be set .bat, please use format: SET REGULATION=NHTSA or SET REGULATION=CHINA
		if ( $ENV{'REGULATION'} eq 'CHINA' ) {
			$LIFT_PROJECT::Defaults->{'Mapping_EDR'}->{'StorageOrder'} = 'MostRecentFirst';    #avoid separated mapping EDR between CHINA and NHTSA
		}
		elsif ( $ENV{'REGULATION'} eq 'NHTSA' ) {
			$LIFT_PROJECT::Defaults->{'Mapping_EDR'}->{'StorageOrder'} = 'PhysicalOrder';      #avoid separated mapping EDR between CHINA and NHTSA
		}
	}
}

# Mapping contains variant specific settings to be done by the user
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_UserSettings_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_EDR_UserSettings_RefType4.pm";
}

if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_LA_AcuteTravelLogic_RefType4.pm" ) {               # it's currently setting of R1L DevBoard
	require "$LIFT_PRJCFG_path/Mappings/Mapping_LA_AcuteTravelLogic_RefType4.pm";
}

### Device mapping  // must be first configured (T.Okrusch Apr, 1st 2019)
if ( -f "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm" ) {
	require "$LIFT_PRJCFG_path/Mappings/Mapping_DEVICE_RefType4.pm";
	$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'};
}

# probably not required
#     require "$LIFT_PRJCFG_path/Mappings/Mapping_SAD.pm";
#     $LIFT_SADMapping = $LIFT_PROJECT::Defaults->{'Mapping_SAD'};          # Never used (?)

1;
