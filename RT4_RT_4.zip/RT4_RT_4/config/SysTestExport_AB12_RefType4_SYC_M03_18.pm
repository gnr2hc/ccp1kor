# --------------------------------------------------------------------------
#
#  Copyright (c) 2017 Robert Bosch GmbH, Germany
#  All rights reserved.
#
# --------------------------------------------------------------------------
#                AB12_SystemTest_SYC.pm
#
# Description:
#  Export of all parameter settings of the AB12 SYC model
#  that are needed by system test.
#
#  $Source: config/SysTestExport_AB12_RefType4_SYC_M03_18.pm $
#  $Revision: 1.1 $
#  $Author: Nguyen Van Truc (RBVH/EPS24) (GNR2HC) $
#
# --------------------------------------------------------------------------
package SystemTest_SYC_Export;

$SYC_Export = {
VariantModelInformation => "AB12_RefType4_SYC_General_Rev_1_36",

# --------------------------------------------------------------------------
# Actuators
# --------------------------------------------------------------------------
Actuators => {
GeneralData =>
{
RepetitionTime_ms => 200,TestCurrent_mA => 40,ResistanceShort2Bat_kOhm => 5
},
DeviceData =>
{
BT1FD => {asicNo => 1, loopNo => 10, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT1FP => {asicNo => 1, loopNo => 12, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
SA1FD => {asicNo => 2, loopNo => 14, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
SA1FP => {asicNo => 1, loopNo => 8, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
AB1FD => {asicNo => 2, loopNo => 1, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
AB2FD => {asicNo => 2, loopNo => 2, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
AB1FP => {asicNo => 2, loopNo => 3, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
AB2FP => {asicNo => 2, loopNo => 4, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
IC1FD => {asicNo => 2, loopNo => 15, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
IC1FP => {asicNo => 1, loopNo => 5, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
ALLFP => {asicNo => 1, loopNo => 1, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.65, ResistanceLow_UpperThreshold_Ohm => 1.45},
ALLFD => {asicNo => 1, loopNo => 2, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.65, ResistanceLow_UpperThreshold_Ohm => 1.45},
AB3FP => {asicNo => 2, loopNo => 5, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode V", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
KA1FP => {asicNo => 2, loopNo => 8, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode V", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
KA1FD => {asicNo => 2, loopNo => 7, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode V", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
ASC1FD => {asicNo => 2, loopNo => 6, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode V", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT2FD => {asicNo => 1, loopNo => 13, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode VI", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT2FP => {asicNo => 1, loopNo => 15, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode VI", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT1RD => {asicNo => 1, loopNo => 16, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode VI", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT1RP => {asicNo => 2, loopNo => 13, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
HOODD => {asicNo => 1, loopNo => 14, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode VI", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
HOODP => {asicNo => 2, loopNo => 16, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BATD => {asicNo => 1, loopNo => 4, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.65, ResistanceLow_UpperThreshold_Ohm => 1.45},
SA1RD => {asicNo => 2, loopNo => 12, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT1RC => {asicNo => 1, loopNo => 7, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT2RD => {asicNo => 1, loopNo => 6, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT2RP => {asicNo => 1, loopNo => 9, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
BT2RC => {asicNo => 1, loopNo => 11, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode III", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
SA1RP => {asicNo => 2, loopNo => 11, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
PPAB1 => {asicNo => 1, loopNo => 3, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode II", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.65, ResistanceLow_UpperThreshold_Ohm => 1.45},
IC1RD => {asicNo => 2, loopNo => 9, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2},
IC1RP => {asicNo => 2, loopNo => 10, configured => "true", onlyMonitored => "false", crossCoupling => "true", firingMode => "mode I", ActuatorType => "Squib", ResistanceHigh_LowerThreshold_Ohm => 4.85, ResistanceOk_UpperThreshold_Ohm => 4.4, ResistanceOk_LowerThreshold_Ohm => 1.4, ResistanceLow_UpperThreshold_Ohm => 1.2}
},
},
# --------------------------------------------------------------------------
# Analogue Outputs
# --------------------------------------------------------------------------
AnalogueOutputs => {
DeviceData =>
{
System_Warning_Indicator => {configured => "true", onlyMonitored => "false"},
CrashOutput1 => {configured => "true", onlyMonitored => "false"},
CrashOutput2 => {configured => "true", onlyMonitored => "false"},
Passenger_Airbag_On_Indicator => {configured => "true", onlyMonitored => "false"},
Passenger_Airbag_Off_Indicator => {configured => "true", onlyMonitored => "false"}
},
},
# --------------------------------------------------------------------------
# ASICs
# --------------------------------------------------------------------------
ASICs => {
DeviceData =>
{
MasterAsicType => "CG904",
Slave1AsicType => "CG904",
Slave2AsicType => "N/A"
},
},
# --------------------------------------------------------------------------
# Communication Interfaces
# --------------------------------------------------------------------------
Communication_Interfaces => {
Can =>
{
150
},
FlexRay =>
{
"N/A"
},
Lin =>
{
300
},
},
# --------------------------------------------------------------------------
# EDR
# --------------------------------------------------------------------------
EDR => {
GeneralData =>
{
EDR_ALLOW_ONLINE_DIAG => "false",
EDR_ME_HANDLING => "Drop",
NumberOfEventsToBeStored => 3,
NumberOfParallelEvents => 3,
ThresholdValueForInternalError      => 1,
EDR_SECTION_CRC                     => "false",
EDR_SPECIAL_EVENT_SET => "Rollover",
NumberOfEventsToBeStoredPEP => "N/A",
NumberOfParallelEventsPEP => "N/A",
ThresholdValueForInternalErrorPEP => "N/A",
EDR_TRIGGER_THRESHOLD_SPEED => 8,
EDR_TRIGGER_THRESHOLD_TIME => 150,
Type => "NHTSA",
DevicesLeadingToLockingOfRecord     => ["BT1FD","BT1FP","SA1FD","SA1FP","AB1FD","AB2FD","AB1FP","AB2FP","IC1FD","IC1FP","ALLFP","ALLFD","AB3FP","KA1FP","KA1FD","ASC1FD","BT2FD","BT2FP","BT1RD","BT1RP","HOODD","HOODP","BATD","SA1RD","BT1RC","BT2RD","BT2RP","BT2RC","SA1RP","PPAB1","IC1RD","IC1RP"],

},
},
# --------------------------------------------------------------------------
# FaultRecording
# --------------------------------------------------------------------------
FaultRecording => {
GeneralData =>
{
BoschMemorySize => 25,
DemDisturbanceMemorySize => 15,
DemMaxNumberEventEntryPrimary => 25
},
},
# --------------------------------------------------------------------------
# PowerSupply
# --------------------------------------------------------------------------
PowerSupply => {
GeneralData =>
{
HighVoltageDetectionLimit_V         => 19.2,
LowVoltageDetectionLimit_V          => 8.75,
MinAutarkyTime_ms                   => 400,
NumberOfSupplyLines                 => 2,
ReverseVoltageTest_voltage_V        => -16,
ReverseVoltageTest_duration_s       => 3600,
ReverseVoltageTest_temperature_C    => 50,

},
},
# --------------------------------------------------------------------------
# Sensors
# --------------------------------------------------------------------------
Sensors => {
DeviceData =>
{
UFSD => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
UFSP => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PASFD => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PASFP => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PASMD => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PASMP => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PPSFD => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PPSFP => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PCSC => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PTSD => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PTSP => {
"ch1" => {configured => "true", onlyMonitored => "false"}
},
PASRC => {
"ch1" => {configured => "false", onlyMonitored => "true"}
}
},
},
# --------------------------------------------------------------------------
# Switches
# --------------------------------------------------------------------------
Switches => {
GeneralData =>
{
RepetitionTime_ms => 30,
},
DeviceData =>
{
BLFD => {asicNo => 1, loopNo => 1, configured => "true", onlyMonitored => "false", SwitchType => "Hall Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "current measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 3.9, PositionA_High => 6.9, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 11.0, PositionB_High => 19.4, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 3.217, UndefinedValue_Low => 7.8, UndefinedValue_High => 9.908, Short2GndValue => 21.072, ConstantCurrent => "N/A", MaxMeasurementLimit => 30, MeasurementRepetition => 5},
BLFP => {asicNo => 1, loopNo => 7, configured => "true", onlyMonitored => "false", SwitchType => "Hall Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "current measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 3.9, PositionA_High => 6.9, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 11.0, PositionB_High => 19.4, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 3.217, UndefinedValue_Low => 7.8, UndefinedValue_High => 9.908, Short2GndValue => 21.072, ConstantCurrent => "N/A", MaxMeasurementLimit => 30, MeasurementRepetition => 5},
BLRD => {asicNo => 2, loopNo => 7, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLRC => {asicNo => 2, loopNo => 9, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLRP => {asicNo => 2, loopNo => 8, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR2D => {asicNo => 2, loopNo => 1, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR2P => {asicNo => 2, loopNo => 10, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
SPSFD => {asicNo => 1, loopNo => 8, configured => "true", onlyMonitored => "false", SwitchType => "Hall Switch", InitialCondition => "Position B", FaultReaction => "keep last condition", MeasurementMode => "current measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 11.0, PositionA_High => 19.4, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 3.9, PositionB_High => 6.9, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 3.217, UndefinedValue_Low => 7.8, UndefinedValue_High => 9.908, Short2GndValue => 21.072, ConstantCurrent => "N/A", MaxMeasurementLimit => 30, MeasurementRepetition => 5},
OPSFP => {asicNo => 1, loopNo => 4, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "false", PositionA_Type => "Range", PositionA_Low => 0, PositionA_High => 340, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 502, PositionB_High => 740, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 1003.893, UndefinedValue_Low => "NA", UndefinedValue_High => "NA", Short2GndValue => "NA", ConstantCurrent => 7, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
PADS1 => {asicNo => 1, loopNo => 5, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
SPSFP => {asicNo => 1, loopNo => 3, configured => "true", onlyMonitored => "false", SwitchType => "Hall Switch", InitialCondition => "Position B", FaultReaction => "keep last condition", MeasurementMode => "current measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 11.0, PositionA_High => 19.4, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 3.9, PositionB_High => 6.9, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 3.217, UndefinedValue_Low => 7.8, UndefinedValue_High => 9.908, Short2GndValue => 21.072, ConstantCurrent => "N/A", MaxMeasurementLimit => 30, MeasurementRepetition => 5},
BLFC => {asicNo => 1, loopNo => 2, configured => "true", onlyMonitored => "false", SwitchType => "Hall Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "current measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 3.9, PositionA_High => 6.9, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 11.0, PositionB_High => 19.4, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 3.217, UndefinedValue_Low => 7.8, UndefinedValue_High => 9.908, Short2GndValue => 21.072, ConstantCurrent => "N/A", MaxMeasurementLimit => 30, MeasurementRepetition => 5},
PADS2 => {asicNo => 1, loopNo => 6, configured => "true", onlyMonitored => "false", SwitchType => "Mechanical Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "false", PositionA_Type => "Threshold", PositionA_Low => "N/A", PositionA_High => "N/A", PositionA_ThresholdValue_Ohm => 350, PositionB_Type => "Threshold", PositionB_Low => "N/A", PositionB_High => "N/A", PositionB_ThresholdValue_Ohm => 350, Threshold_A_Below_B => "true", OpenLineValue => "NA", UndefinedValue_Low => "NA", UndefinedValue_High => "NA", Short2GndValue => "NA", ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR2C => {asicNo => 1, loopNo => 10, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR3D => {asicNo => 2, loopNo => 3, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR3P => {asicNo => 2, loopNo => 4, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
BLR3C => {asicNo => 2, loopNo => 5, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "true", PositionA_Type => "Range", PositionA_Low => 80, PositionA_High => 120, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 360, PositionB_High => 440, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 564.83, UndefinedValue_Low => 162.943, UndefinedValue_High => 276.824, Short2GndValue => 53.666, ConstantCurrent => 10, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
OPSRD => {asicNo => 2, loopNo => 2, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "false", PositionA_Type => "Range", PositionA_Low => 0, PositionA_High => 340, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 502, PositionB_High => 740, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 1003.893, UndefinedValue_Low => "NA", UndefinedValue_High => "NA", Short2GndValue => "NA", ConstantCurrent => 7, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
OPSRP => {asicNo => 2, loopNo => 6, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "false", PositionA_Type => "Range", PositionA_Low => 0, PositionA_High => 340, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 502, PositionB_High => 740, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 1003.893, UndefinedValue_Low => "NA", UndefinedValue_High => "NA", Short2GndValue => "NA", ConstantCurrent => 7, MaxMeasurementLimit => 1250, MeasurementRepetition => 5},
OPSRC => {asicNo => 1, loopNo => 9, configured => "true", onlyMonitored => "false", SwitchType => "Resistive Switch", InitialCondition => "Position A", FaultReaction => "keep last condition", MeasurementMode => "voltage measurement", crossCoupling => "false", PositionA_Type => "Range", PositionA_Low => 0, PositionA_High => 340, PositionA_ThresholdValue_Ohm => "N/A", PositionB_Type => "Range", PositionB_Low => 502, PositionB_High => 740, PositionB_ThresholdValue_Ohm => "N/A", Threshold_A_Below_B => "N/A", OpenLineValue => 1003.893, UndefinedValue_Low => "NA", UndefinedValue_High => "NA", Short2GndValue => "NA", ConstantCurrent => 7, MaxMeasurementLimit => 1250, MeasurementRepetition => 5}
},
},
# --------------------------------------------------------------------------
};