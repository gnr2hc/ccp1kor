package LIFT_PROJECT;

# Mapping describing the SPI network
# Used for: SPI trace decoding, SPI manipulation
# TODO:  - add all SPI Nodes available in the network (ASICs, internal sensors)
# 	-> information on configured devices can be found in SYC chapters:
			# 5.2 (System Asics)
			# 5.3 (Internal Airbag Sensors)
			
use File::Basename;  # needed for dirname

our @ISA = qw(Exporter);

our @EXPORT = qw(
  $Defaults
);

$Defaults -> {'Mapping_SPI'} = {

	'Cobra_M' => {
		#'Offset' => '0',
		'CS_Polarity' => 'true',
		'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/CG90x_Cobra.spi',
		'CS_Enabled' => 'true',
		'CS_Pin' => '0',
		'MSB_LSB' => 'MSB',
		'DeviceType' => 'CG90x_Cobra',
		'Frame_Length_Bit' => '32',
		'CLK_Mode' => 'true',
		'SPI' => '1'
	},
 
	'Cobra_S' => {
		#'Offset' => '0',
		'CS_Polarity' => 'true',
		'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/CG90x_Cobra.spi',
		'CS_Enabled' => 'true',
		'CS_Pin' => '1',
		'MSB_LSB' => 'MSB',
		'DeviceType' => 'CG90x_Cobra',
		'Frame_Length_Bit' => '32',
		'CLK_Mode' => 'true',
		'SPI' => '1'
	},

	  # 'SMA760' => {
		# 'Offset' => '0',
		 # 'CS_Polarity' => 'true',
		 # 'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/SMA7xx.spi',
 		 # 'CS_Enabled' => 'true',
		 # 'CS_Pin' => '2',
		 # 'MSB_LSB' => 'MSB',
		 # 'DeviceType' => 'SMA760',
		 # 'Frame_Length_Bit' => '32',
		 # 'CLK_Mode' => 'true',
		 # 'SPI' => '1'
	 # },
 
	# 'SMA720' => {
		# 'Offset' => '0',
		# 'CS_Polarity' => 'true',
		# 'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/SMA7xx.spi',
 		# 'CS_Enabled' => 'true',
		# 'CS_Pin' => '4',
		# 'MSB_LSB' => 'MSB',
		# 'DeviceType' => 'SMA660',
		# 'Frame_Length_Bit' => '32',
		# 'CLK_Mode' => 'true',
		# 'SPI' => '1'
	# },
 

	# 'SMI7xx' => {
		#'Offset' => '0',
		# 'CS_Polarity' => 'true',
#		'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/SMx8xx_conf_1.spi',
		# 'DecodingFile' => dirname($main::opt_conf) . '/Tools/SPI_decoder_files/SMI7xx_conf_3.spi',
		# 'CS_Enabled' => 'true',
		# 'CS_Pin' => '3',
		# 'MSB_LSB' => 'MSB',
#		'DeviceType' => 'SMx8xx_conf_1',
		# 'DeviceType' => 'SMI7xx_conf_3',
		# 'Frame_Length_Bit' => '32',
		# 'CLK_Mode' => 'true',
		# 'SPI' => '1',
		# 'SMI7_Modules' => {
			#'YawSensor' => 0,
			#'YawPlausiSensor' => 1,
			#'PitchSensor' => 2,
			#'RollSensor' => 3,
		# },
	# },
 
};


$Defaults->{'SPILC_FunctionMapping'} = {
    squibs => {
        ls_short2gnd => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 8 },    #  even extension with MASK or BIT_INDEX can happen
        },
        hs_short2gnd => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 10 },    #  even extension with MASK or BIT_INDEX can happen
        },
        ls_short2bat => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 9 },     #  even extension with MASK or BIT_INDEX can happen
        },

        hs_short2bat => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 11 },    #  even extension with MASK or BIT_INDEX can happen
        },

        sqref_too_low => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 2 },     #  even extension with MASK or BIT_INDEX can happen
        },

        sqref_too_high => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 3 },     #  even extension with MASK or BIT_INDEX can happen
        },

        hs_volt_too_high => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 4 },     #  even extension with MASK or BIT_INDEX can happen
        },

        ls_volt_too_high => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 5 },     #  even extension with MASK or BIT_INDEX can happen
        },

        res_value_too_high => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 6 },     #  even extension with MASK or BIT_INDEX can happen
        },

        volt_ls_gt_hs => {
            1 => { 'CMD' => 'FLM_READ_RES_CH<ASIC_CHANNEL>', 'SIG' => 'flt', 'VAL' => 7 },     #  even extension with MASK or BIT_INDEX can happen
        },
        res_value_raw => {
            1 => { 'SIG' => 'res_value', 'VAL' => '<Resistor_value_raw>' },                    #  even extension with MASK or BIT_INDEX can happen
        },

        #        res_value_ohms => {                                                        #  calculation method to be investigated / later
        #            1 => { 'SIG' => 'res_value', 'VALUE_PHYS' => '<Resistor_value_ohms' },    #  even extension with MASK or BIT_INDEX can happen
        #        },

        validity_flag => {
            1 => { 'SIG' => 'vd', 'VAL' => '<Validity_flag>' },    #  even extension with MASK or BIT_INDEX can happen
        },
    },

    pases => {
        ls_short2gnd => {
            1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sg<ASIC_CHANNEL>', 'VAL' => 1 },
        },
        hs_short2gnd => {
            1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sg<ASIC_CHANNEL>', 'VAL' => 1 },
        },
        ls_short2bat => {
            1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sb<ASIC_CHANNEL>', 'VAL' => 1 },
        },
        hs_short2bat => {
            1 => { 'CMD' => 'PSI_READ_SC', 'SIG' => 'sb<ASIC_CHANNEL>', 'VAL' => 1 },
        },
        
    }
};
1;