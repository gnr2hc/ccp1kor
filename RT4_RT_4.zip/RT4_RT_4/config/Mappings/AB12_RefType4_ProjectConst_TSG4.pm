package LIFT_PROJECT;

#$VERSION = q$Revision: 1.4 $;
#$HEADER = q$Header: config/Mappings/AB12_RefType4_ProjectConst_TSG4.pm 1.4 2020/04/12 10:06:56ICT Nguyen Van Truc (RBVH/EPS24) (GNR2HC) develop  $;

$Defaults->{'TRANSI'} = {
	'General' => {

		# Parameter for Warning Indicator measurement
		'SamplingFrequency' => 125 * 1000,     # in Hz , 250 KHz
		'MemorySize'        => 1024 * 1024,    # in bytes, 128 KB
		'TriggerDelay'      => -1,             # from -99% to 200%

		# Parameter for Switch Test Pulse measurement
		#        'SamplingFrequency' => 20 * 1000  , # in Hz , 250 KHz
		#        'MemorySize'        =>  128 * 1024 , # in bytes, 128 KB
		#        'TriggerDelay'      =>  -5 ,        # from -99% to 200%
		# Parameter for Firing Pulse measurement
		#        'SamplingFrequency' => 200 * 1000  , # in Hz , 200 KHz = 5�s
		#        'MemorySize'        =>  16 * 1024 , # in bytes, 2048 KB    => Measuring time = 0,8sec
		#        'TriggerDelay'      =>  -5 ,        # from -99% to 200%
	},
	'EXTERNAL_TRIGGER' => {
		'SlopeType' => 'negative',    # MF: 'positive' or 'negative', LTT: Only 'positive' successfully tested
	},
};

$Defaults->{'TSG4'} =

########################################################################################################################
  # here you define the TSG4 configuration
  # section => {device name => label}
########################################################################################################################

  {
	'General' => {

		# CAN settings will be overwritten from testbench config settings
		'MaxVoltage' => 20,
	},
	'SQUIBS' => {    # to be renamed
		'SQ1_Name'     => 'IC1RD',
		'SQ1_Default'  => '2.2',
		'SQ2_Name'     => 'IC1RP',
		'SQ2_Default'  => '2.2',
		'SQ3_Name'     => 'AB3FP',
		'SQ3_Default'  => '2.2',
		'SQ4_Name'     => 'ASC1FD',
		'SQ4_Default'  => '2.2',
		'SQ5_Name'     => 'PPAB1',
		'SQ5_Default'  => '2.2',
		'SQ6_Name'     => 'BATD',
		'SQ6_Default'  => '2.2',
		'SQ7_Name'     => 'AB1FP',
		'SQ7_Default'  => '2.2',
		'SQ8_Name'     => 'AB1FD',
		'SQ8_Default'  => '2.2',
		'SQ9_Name'     => 'ALLFP',
		'SQ9_Default'  => '2.2',
		'SQ10_Name'    => 'ALLFD',
		'SQ10_Default' => '2.2',
		'SQ11_Name'    => 'KA1FD',
		'SQ11_Default' => '2.2',
		'SQ12_Name'    => 'KA1FP',
		'SQ12_Default' => '2.2',
		'SQ13_Name'    => 'AB2FD',
		'SQ13_Default' => '2.2',
		'SQ14_Name'    => 'BT1FD',
		'SQ14_Default' => '2.2',
		'SQ15_Name'    => 'IC1FD',
		'SQ15_Default' => '2.2',
		'SQ16_Name'    => 'BT2FD',
		'SQ16_Default' => '2.2',
		'SQ17_Name'    => 'HOODD',
		'SQ17_Default' => '2.2',
		'SQ18_Name'    => 'IC1FP',
		'SQ18_Default' => '2.2',
		'SQ19_Name'    => 'BT2FP',
		'SQ19_Default' => '2.2',
		'SQ20_Name'    => 'BT2RC',
		'SQ20_Default' => '2.2',
		'SQ21_Name'    => 'SA1RD',
		'SQ21_Default' => '2.2',
		'SQ22_Name'    => 'SA1RP',
		'SQ22_Default' => '2.2',
		'SQ23_Name'    => 'SA1FD',
		'SQ23_Default' => '2.2',
		'SQ24_Name'    => 'BT1RD',
		'SQ24_Default' => '2.2',
		'SQ25_Name'    => 'BT1RP',
		'SQ25_Default' => '2.2',
		'SQ26_Name'    => 'BT1RC',
		'SQ26_Default' => '2.2',
		'SQ27_Name'    => 'BT2RD',
		'SQ27_Default' => '2.2',
		'SQ28_Name'    => 'BT2RP',
		'SQ28_Default' => '2.2',
		'SQ29_Name'    => 'AB2FP',
		'SQ29_Default' => '2.2',
		'SQ30_Name'    => 'BT1FP',
		'SQ30_Default' => '2.2',
		'SQ31_Name'    => 'HOODP',
		'SQ31_Default' => '2.2',
		'SQ32_Name'    => 'SA1FP',
		'SQ32_Default' => '2.2',

		#                        'SQ33_Name' => 'GndOffset',
		#                        'SQ33_Default' => '0.1',
	},

	'POWER_SUPPLY_LINES' => {
		'PSL1_Name'    => 'Vign',
		'PSL1_Default' => 'Ubat',
		'PSL2_Name'    => 'Vbat',
		'PSL2_Default' => 'Ubat',
	},

	'BELT_LOCKS' => {

		'BL5_Name'       => 'OPSRC',    # ResistiveOPS
		'BL5_Unit'       => 'R',
		'BL5_Default'    => '205',      # Pos A
		'BL5_state_PosA' => '205',      # Pos A
		'BL5_state_PosB' => '575',      # Pos B

		'BL6_Name'       => 'BLR2C',    # ResistiveBeltLock
		'BL6_Unit'       => 'R',
		'BL6_Default'    => '100',      # Pos A
		'BL6_state_PosA' => '100',      # Pos A
		'BL6_state_PosB' => '400',      # Pos B

		'BL7_Name'       => 'PADS1',    # ResistiveSwitchPADS1
		'BL7_Unit'       => 'R',
		'BL7_Default'    => '100',      # Pos A
	    'BL7_state_PosA' => '100',      # Pos A
		'BL7_state_PosB' => '400',      # Pos B

		'BL8_Name'       => 'PADS2',    # MechanicalPADS2
		'BL8_Unit'       => 'R',
		'BL8_Default'    => '500',      # Pos B
		'BL8_state_PosA' => '20',       # Pos A
		'BL8_state_PosB' => '500',      # Pos B

		'BL9_Name'       => 'BLR2D',    # ResistiveBeltLock
		'BL9_Unit'       => 'R',
		'BL9_Default'    => '100',
		'BL9_state_PosA' => '100',
		'BL9_state_PosB' => '400',

		'BL10_Name'       => 'BLR2P',    # ResistiveBeltLock
		'BL10_Unit'       => 'R',
		'BL10_Default'    => '100',
		'BL10_state_PosA' => '100',
		'BL10_state_PosB' => '400',

		'BL11_Name'       => 'BLRD',     # ResistiveBeltLock
		'BL11_Unit'       => 'R',
		'BL11_Default'    => '100',
		'BL11_state_PosA' => '100',
		'BL11_state_PosB' => '400',

		'BL12_Name'       => 'BLRC',     # ResistiveBeltLock
		'BL12_Unit'       => 'R',
		'BL12_Default'    => '100',
		'BL12_state_PosA' => '100',
		'BL12_state_PosB' => '400',

		'BL13_Name'       => 'BLRP',     # ResistiveBeltLock
		'BL13_Unit'       => 'R',
		'BL13_Default'    => '100',
		'BL13_state_PosA' => '100',
		'BL13_state_PosB' => '400',

		'BL14_Name'       => 'OPSRD',    # ResistiveOPS
		'BL14_Unit'       => 'R',
		'BL14_Default'    => '205',
		'BL14_state_PosA' => '205',
		'BL14_state_PosB' => '575',

		'BL15_Name'       => 'OPSRP',    # ResistiveOPS
		'BL15_Unit'       => 'R',
		'BL15_Default'    => '205',
		'BL15_state_PosA' => '205',
		'BL15_state_PosB' => '575',

		'BL16_Name'       => 'BLFD',     # HallBeltLock
		'BL16_Unit'       => 'I',
		'BL16_Default'    => '5',        # Pos A
		'BL16_state_PosA' => '5',        # Pos A
		'BL16_state_PosB' => '15',       # Pos B

		'BL17_Name'       => 'BLFC',     # HallBeltLock
		'BL17_Unit'       => 'I',
		'BL17_Default'    => '5',
		'BL17_state_PosA' => '5',
		'BL17_state_PosB' => '15',

		'BL18_Name'       => 'BLFP',     # HallBeltLock
		'BL18_Unit'       => 'I',
		'BL18_Default'    => '5',
		'BL18_state_PosA' => '5',
		'BL18_state_PosB' => '15',

		'BL25_Name'       => 'SPSFD',    # HallSeatPos
		'BL25_Unit'       => 'I',
		'BL25_Default'    => '5',        # Pos B
		'BL25_state_PosA' => '15',       # Pos A
		'BL25_state_PosB' => '5',        # Pos B

		'BL26_Name'       => 'SPSFP',    # HallSeatPos
		'BL26_Unit'       => 'I',
		'BL26_Default'    => '5',
		'BL26_state_PosA' => '15',
		'BL26_state_PosB' => '5',

		'BL27_Name'       => 'OPSFP',    # ResistiveOPS
		'BL27_Unit'       => 'R',
		'BL27_Default'    => '205',
		'BL27_state_PosA' => '205',
		'BL27_state_PosB' => '575',

		'BL28_Name'       => 'BLR3D',    # ResistiveBeltLock
		'BL28_Unit'       => 'R',
		'BL28_Default'    => '100',
		'BL28_state_PosA' => '100',
		'BL28_state_PosB' => '400',

		'BL29_Name'       => 'BLR3C',    # ResistiveBeltLock
		'BL29_Unit'       => 'R',
		'BL29_Default'    => '100',
		'BL29_state_PosA' => '100',
		'BL29_state_PosB' => '400',

		'BL30_Name'       => 'BLR3P',    # ResistiveBeltLock
		'BL30_Unit'       => 'R',
		'BL30_Default'    => '100',
		'BL30_state_PosA' => '100',
		'BL30_state_PosB' => '400',
	},
	'PAS_LINES' => {
		'PAS_1_1_Name'  => 'PASFD',
		'PAS_1_2_Name'  => 'PASMD',
		'PAS_2_1_Name'  => 'PASFP',
		'PAS_2_2_Name'  => 'PASMP',
		'PAS_3_1_Name'  => 'PPSFD',
		'PAS_4_1_Name'  => 'PPSFP',
		'PAS_19_1_Name' => 'UFSD',
		'PAS_20_1_Name' => 'UFSP',
		'PAS_21_1_Name' => 'PTSD',
		'PAS_22_1_Name' => 'PTSP',
		'PAS_23_1_Name' => 'PCSC',
		'PAS_24_1_Name' => 'PASRC',
	},

	'WARNING_LAMPS' => {
		'WL_1_1_Name'    => 'CRO1',
		 'WL_1_2_Name'    => 'CRO2',
		 'WL_1_3_Name'    => 'DISP',#ACL
		#'WL_1_3_Default' => 'not_connected',
		'WL_1_4_Name'    => 'AWL',
		'WL_1_5_Name'    => 'PADL',
		'WL_1_6_Name'    => 'PAEL',
	},

	'CAN_FR' => {
		'CF1_Name' => 'CAN1',
		'CF2_Name' => 'CAN2',
	},
	'K_LIN' => {
		'KL6_Name' => 'LIN',
	},

	'DVM_SCANNER' => {
		'DVM1_Name' => 'DVM1',
	},
	'TRC_SCANNER' => {
		'TRC1_Name' => 'TRC1',
		'TRC2_Name' => 'TRC2',
		'TRC3_Name' => 'TRC3',
		'TRC4_Name' => 'TRC4',
	},
	'TRC_MERGER' => {
		'MERGER' => 'used',    # blue connector on scanner rack (connect X-scan1 and X-scan2 for TRC)
	},
	'EMPTY' => {},
  },

  1;
