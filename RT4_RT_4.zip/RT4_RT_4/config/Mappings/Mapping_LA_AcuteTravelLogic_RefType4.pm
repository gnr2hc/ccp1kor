###################  Configuration for LA_AcuteTravelLogic  ##################

package LIFT_PROJECT;

# The content below are just example values and should be replaced by project specific data.

# configuration for LA_AcuteTravelLogic

$Defaults->{'LA_AcuteTravelLogic'} = {

    # Only the used channels, including the trigger channel need to be listed
    # GND Pin not to be listed, but GND connection to any of the 4 GND pins has to exist in HW setup
    # Names can be chosen, assigned integer numbers have to be zero-based
    # Maximum number of available channels depends on selected 'hwMode'
    'pinNames' => {    # [REQUIRED] list of pin names
        '21_MOSI1'        => 0,
        '22_MISO1_ASIC'   => 1,
        'MISO1_CPU'       => 2,
        '14_SCK1'         => 3,
        '24_CONTROL_MUX'  => 4,
        '20_CS0_COBRA_M'  => 5,
        '19_CS1_COBRA_S'  => 6,
        '18_CS2_SMA660_M' => 7,
        '17_CS3_SMI7xx'   => 8,
        '16_CS4_SMA660_P' => 9,
    },
    'triggerPinName' => '24_CONTROL_MUX',          # [REQUIRED, if triggerEdge not equal to 'dontcare' otherwise OPTIONAL]

    'triggerEdge'    => 'rising',             # [REQUIRED]
                                              # text: 'falling'|'rising'|'low'|'high'|'change'|'dontcare'
                                              # (dontcare = immediate trigger)

    'hwMode'         => 'HW_200M_32CH_TR',    # [OPTIONAL]
                                              # (default: 'HW_200M_32CH_TR' = 200 MHz, transitional mode, 32 ch)

                                              #POSSIBLE MODES
                                              #'HW_4G_36CH'
                                              #'HW_4G_18CH'
                                              #'HW_4G_9CH'
                                              #'HW_4G_4CH'
                                              #'HW_2G_36CH'
                                              #'HW_1600M_4CH'
                                              #'HW_800M_9CH'
                                              #'HW_400M_18CH'
                                              #'HW_200M_36CH'
                                              #'HW_200M_18CH'
                                              #'HW_200M_12CH'
                                              #'HW_200M_9CH'
                                              #'HW_200M_6CH'
                                              #'HW_200M_4CH'
                                              #'HW_200M_2CH'
                                              #'HW_200M_1CH'
                                              #'HW_200M_32CH_TR'
                                              #'HW_200M_8CH_TR'

    'fileNameTemplate' => 'C:/Sandbox/Template/config/Tools/LA_AcuteTravelLogic/AB12_CA_Template.law',
    'postTriggerSize_pct' => '<int>', # [OPTIONAL] default: 90%
    'numSamples_perCh' => '<int>',   # [OPTIONAL] <int> default: max. available memory
};

1;
