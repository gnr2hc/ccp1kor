package LIFT_PROJECT;

$Defaults->{'Mapping_FAULT_extension'} = {

	#--------------------------- POM -------------------------------

	'rb_pom_PowerPlausiSystemAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::c3',
		'SpiSignalError' => 0,
	},

	'rb_pom_PowerPlausiSystemAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_STATUS::c4',
		'SpiSignalError' => 0,
	},

	'rb_pom_InadvertentReset_flt' => {                   #TODO: fault not qualified
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError'   => 380,
		'SpiSignal_1'      => 'CG904_S::POM_READ_AUTO_VER::ver',
		'SpiSignalError_1' => 380,
	},

	'rb_pom_VerVignCoupling_flt' => {                    #TODO: fault not qualified
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError'   => 250,
		'SpiSignal_1'      => 'CG904_S::POM_READ_AUTO_VER::ver',
		'SpiSignalError_1' => 250,
#		'SpiSignal_2'      => 'Cobra_M::POM_READ_AUTO_VBAT_MON2::vbat_mon2',
#		'SpiSignalError_2' => 250,
	},

	'rb_pom_VerOpenLine_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 0,
		'FaultType'		 => 'init_NoClearNoReset',
	},

	'rb_pom_VerLow_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 500,
		'FaultType'		 => 'cyclic_SPI',
	},

	'rb_pom_VerHigh_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_VER::ver',
		'SpiSignalError' => 800,
		'FaultType'		 => 'cyclic_SPI',
	},

	'rb_pom_ESRhigh_flt' => {
		'DeviceType'       => 'SPI',
		'Condition'        => 'SPI_Manipulation',
		'SpiSignal'        => 'CG904_M::POM_READ_BIST::et0_et1_et2',
		'SpiSignalError'   => '0b1xxxxxx11xxxxxxx',
		'SpiSignal_1'      => 'CG904_S::POM_READ_BIST::et0_et1_et2',
		'SpiSignalError_1' => '0b1xxxxxx11xxxxxxx',
		'FaultType'		   => 'init_NoClearNoReset',
	},

	'rb_pom_ErCapacityOutOfRange_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_BIST::delta_ver',
		'SpiSignalError' => 5,
		'FaultType'		 => 'init_NoClearNoReset',
	},

	'rb_pom_ErCapacitorMissing_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_CYCL_CAP::res',    #cyclic fault
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10000', #in ms
		'FaultType'					=>'cyclic_SPI',                 
	},

#	'rb_pom_ErCapacitorMissing_flt' => {
#		'DeviceType'     => 'SPI',
#		'Condition'      => 'SPI_Manipulation',
#		'SpiSignal'      => 'Cobra_M::POM_READ_BIST::vel', 	 #init fault
#		'SpiSignalError' => 0,
#	},

	'rb_pom_Autarky_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_CYCL_CAP::aky',    #case 1
		'SpiSignalError' => 1,
	},

#	'rb_pom_Autarky_flt' => {
#		'DeviceType'     => 'SPI',
#		'Condition'      => 'SPI_Manipulation',
#		'SpiSignal'      => 'Cobra_M::POM_STATUS::vin', 	 #case 2
#		'SpiSignalError' => 1,
#	},

	'rb_pom_VerTestLevelChargeUp_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::vet',
		'SpiSignalError' => 0,
	},

	'rb_pom_VerFinalLevelChargeUp_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::vel',
		'SpiSignalError' => 1,
	},

	'rb_pom_OverTemperatureSystemAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::ot',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_OverTemperatureSystemAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_STATUS::ot',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_VST50VltgSystemAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::v50',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_VST50VltgSystemAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_STATUS::v50',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_VltgsNokSystemAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_STATUS::nok',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_VltgsNokSystemAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_STATUS::nok',
		'SpiSignalError' => 1,
		'CyclicDequalificationtime'=>'0-10', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_HighTemperatureAsic1_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::POM_READ_AUTO_TEMPERATURE::temperature',
		'SpiSignalError' => 0,
		'CyclicDequalificationtime'=>'0-100', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},

	'rb_pom_HighTemperatureAsic2_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::POM_READ_AUTO_TEMPERATURE::temperature',
		'SpiSignalError' => 0,
		#'CyclicDequalificationtime'=>'0-100', #in ms
		'FaultType'					=>'cyclic_SPI', 
	},
	
	
	#--------------------------- WDM -------------------------------
	
	'rb_wdm_InitTestFail_flt' => { #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::o1',
		'SpiSignalError' => 0,
	   
	},
	
	'rb_wdm_DisAlpRemainsDisabled_flt' => { #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::DISABLE_STATUS::ALP',
		'SpiSignalError' => 1,
	},
	
	'rb_wdm_WrongInitValWdStatus_flt' => { #TODO: check
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::cr',
		'SpiSignalError' => 0,
	},
	
	'rb_wdm_Wd2WrongCheckword_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD2_TRIGGER::wd2_checkword',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI_SingleQuali',
	},
	
	'rb_wdm_Wd3WrongCheckword_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD3_TRIGGER::wd3_checkword',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI_SingleQuali',
	},
	
	'rb_wdm_WDFaultMasterWD1_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::u1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI',
	},
	
	'rb_wdm_WDFaultMasterWD2_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::u2',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI',
	},
	
	'rb_wdm_WDFaultMasterWD3_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::r3',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI',
	},
	
	'rb_wdm_WDFaultSlave1_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_S::WD_STATUS::o1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'cyclic_SPI',
	},
	
	'rb_wdm_WDFltCntOverflow_flt' => { 
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::WD_STATUS::faultcnt',
		'SpiSignalError' => 3,
	},

	#--------------------------- SMA760-SMA720 -------------------------------

	'rb_csem_InitGroup1SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_CONFIG_1::CRC',
		'SpiSignalError' => 7,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup1SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_CONFIG_1::CRC',
		'SpiSignalError' => 7,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup2SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_MONITOR_II_DATA::FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup2SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_MONITOR_II_DATA::FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup3SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_TEST_MODE::CH1_BITE_off',
		'SpiSignalError' => 3,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup3SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_TEST_MODE::CH1_BITE_off',
		'SpiSignalError' => 3,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup4SmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_BITE_CH1::Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup4SmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_BITE_CH1::Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_CyclRTMonSmaMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_SENSOR_DATA_CH1::SID',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI_SingleQuali',
	},
	
	'rb_csem_CyclRTMonSmaPlausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA720::RD_CAPTURED_DATA_CH2::SID',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI_SingleQuali',
	},
#------------------------------------------------------------------#
#----------SMA660------------------------------------------------------------#
'rb_csem_InitGroup1Sma660Main_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_M::RD_MODE::PRO',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup1Sma660Plausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_P::RD_MODE::PRO',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup2Sma660Main_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_M::RD_MONITOR_II_DATA::-FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup2Sma660Plausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_P::RD_MONITOR_II_DATA::-FOC_BUSY_CH1',
		'SpiSignalError' => 1,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup3Sma660Main_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_M::RD_TEST_MODE::-CH1_BITE_off',
		'SpiSignalError' => 3,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup3Sma660Plausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_P::RD_TEST_MODE::-CH1_BITE_off',
		'SpiSignalError' => 3,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup4Sma660Main_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_M::RD_BITE_CH1::-Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_InitGroup4Sma660Plausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_P::RD_BITE_CH1::-Positive BITE OTP CH1',
		'SpiSignalError' => 255,
		'FaultType'		 => 'init_permanent',
	},
	
	'rb_csem_CyclRTMonSma660Main_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_M::RD_CAP_SENSOR_DATA_CH2::-SID',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI_permanent',
	},
	
	'rb_csem_CyclRTMonSma660Plausi_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA660_P::RD_SENSOR_DATA_CH1::SID',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI_permanent',
	},
#---------------------Algo------------------------------------------------------
'rb_simc_SignalMonCtrlMain_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMA760::RD_SENSOR_DATA_CH1::Data_CH1',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI',
},
'rb_simp_SignalMonPesPasFD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA13::psi_data',
		'SpiSignalError' => 31,
		'FaultType'		 => 'cyclic_SPI',
},
'rb_simp_SignalMonPesUfsD_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::PSI_READ_DATA2::psi_data',
		'SpiSignalError' => 20,
		'FaultType'		 => 'cyclic_SPI_SingleQuali',
},
#---------------------------------------------------------------------------------------------
#---------------------------------SMI8-----------------------------------------------------------
'rb_csem_MonPermInitInertialSensor2_flt' => {
        'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'SMI8xx::PitchRateLfChl::CRC',
		'SpiSignalError' => 7,
		'FaultType'		 => 'init_permanent',
},
#------------------------------------------------------SWM----------------------------------------#
'rb_swm_SdlHwSwPlausibility_flt' => {
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::DISABLE_STATUS::SIDS',
		'SpiSignalError' => 0,
		'FaultType'		 => 'cyclic_SPI',
},		
'rb_sqm_AmuShortTestGnd_flt' => {	
		'DeviceType'     => 'SPI',
		'Condition'      => 'SPI_Manipulation',
		'SpiSignal'      => 'CG904_M::FLM_READ_SHORT::short',
		'SpiSignalError' => 65535,
		'FaultType'		 => 'init',
},
#---------------------------------------------------PSEM----------------------------------------------#
'rb_psem_InternalCommUFSD_flt' => {
			'DeviceType' =>  'SPI',
			'Condition' =>  'SPI_Manipulation',
			'SpiSignal' =>  'CG904_M::PSI_READ_DATA_CH1_TS2::S',
			'SpiSignalError' => 0,
			'SpiSignal_1'      => 'CG904_M::PSI_READ_DATA_CH1_TS2::gs',
			'SpiSignalError_1' => 1,
			'FaultType'		   => 'cyclic_SPI_permanent',
},
};

1;
