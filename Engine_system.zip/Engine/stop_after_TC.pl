#!usr\bin\perl

use strict;
use warnings;
my $Registry;
use Win32::TieRegistry ( TiedRef=>\$Registry);

$Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\"}={"LIFT\\"=>{"\\STOPafterTC" => 1}};
print"\n\n *** test run will be stopped after current test case has finished ***\n\n\n\n";
sleep(3);
