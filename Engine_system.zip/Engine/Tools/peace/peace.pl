#!perl -w

#****************************************************************************************************
#                                                                           						*
# Copyright (c) 2013 RBEI	                             											*
#               All rights reserved                                         						*
#                                                                           						*
#****************************************************************************************************
# $Revision : 1.0 $        																			*
#                     																				*
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd; 
use Tk::LabFrame;

 # Create a Zip file
use Archive::Zip qw( :ERROR_CODES :CONSTANTS );

my %parData;
my %parDataMultipleFile;
my %parDataFile;
my %parDetails;
my $multipleFileFlag;
my ($directory,$tcTime,$reportsPath,$snapshotPath,$tempPath,$relPath,$allReportsPath,$reportfile,$multipleFilesFlag);
my ($start_date, $start_time,$username,$executionMin,$executionSec);
my (@error_messages,@warning_messages);
my %excelFile;
my %globalVerdicts;
my $passCount;
my $failCount;
my $inconcCount;
my $noneCount; 
my $notfoundCount;

sub Create_About_Window(){
	my $mw = MainWindow->new("-background" => "#888888");
	$mw->minsize(100,25);
	$mw->title("Help");

	#Making a text area
	my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

	$txt->delete('1.0','end');
		$txt->insert('end','
#	
#
#	DESCRIPTION:                               
#	This tool will generate an SPR from an exported SPS           
#
#	FOLLOW THESE STEPS:
#	1. Export SPS to excel sheet: SPS->File->Export->Microsoft Office->Excel..
#	2. Select this file or folder(containing one or more exported excel sheets) and the project sandbox path and click Start                             
#  
#	REMARKS:                                    
#	1. Perl Version 5.12 32 bit(installed using Peacy package) is required
#	2. Perl TK is to be installed                
#                                       
	'
	);

}
my ($main,$end_frame,$path_frame_xls,$path_frame_dir,$path_frame_sandbox,$path_frame_template,$entry, $input_excel_File_Name, $Excelsheets_Path);
my ($Designation_path,$ExcelFile_Name_Path,$SandboxFile_Path,@File_Select_Arr,$status);
$multipleFilesFlag = 0;

# Default Designation Path
$Designation_path='C:';
my  $TK_ERROR_INDICATION_FLAG_i=0;
my $project_name ="";
$main = MainWindow->new("-background" => "DodgerBlue1");

# Size to the TK window 
$main->minsize(450,100);

$main->title("PEACE");
# Get the current path 
my $pwd = cwd();
#print "$pwd","\n";
my @path_structure;
@path_structure =split(/\//,$pwd); 
# Remove the last Folder 
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path=join("\\",@path_structure);
print "File_With_Path =$File_With_Path","\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder
  

#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#The Main Buttons
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);


## File Menu ##
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );
 
#******************************************************************************************** 
$help -> command(-label =>"ReadMe",  -command=>sub {Create_About_Window()});

$main->Label(
    -text=>'peace',
    -font=>'{Segoe UI Light} 34',
    -background => 'DodgerBlue1',
    -foreground => 'orange',
    -height=>'000')->pack(-side=>'top',-pady=>'000');




 my $labeled_frame1   = $main->Frame(-borderwidth => 2, 
                                 -relief => 'groove',
                                 -background => "DodgerBlue1",
                                 )->pack(-side => "top",-padx=>'150',-anchor=>'nw');


#my $shot = $main->Photo(-file => "$File_With_Path\\logo\\AUDI.gif");
#$main->Label(-image => $shot)->pack(-side => 'top');
 $main->Label(
            -text=>'Parameter Element Accuracy Check Executor',
            -font=>'{Segoe UI} 11 ',
            -background => "DodgerBlue1",
            -foreground => "orange",
             )->pack(-side=>'top',-pady=>'02');

$path_frame_xls = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'1',-padx=>'05', -anchor=>'nw' );
$path_frame_dir = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'1',-padx=>'05', -anchor=>'nw' );
$path_frame_sandbox = $main->Frame("-background" => "DodgerBlue1")->pack(-pady=>'1',-padx=>'05', -anchor=>'nw' );

$path_frame_xls->Label(
        -text=>'Load File',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI Light} 11 ')->pack(-side=>'left');
         
        
$status= ' Not Started';
$entry = $path_frame_xls->Entry(
        -width=>'50',
        -textvariable=>\$ExcelFile_Name_Path,
        -background => "grey",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'0');

                $path_frame_xls->Button(
                        -text=>"BROWSE",
                        -width=>'9',
                        -height=>'1.5',
                        #-relief => 'groove',
                        -background => "orange",
                        -foreground  => "DodgerBlue1",
                         -font=>'{Segoe UI} 8.5',
                        -command=>sub
                        {
                            $ExcelFile_Name_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
											["xls xlsx files", ['.xlsx', '.xls'] ],
                                       ],
                                       -title=>"Choose the xls file ",
                            
                            #my $FSref = $main->FileSelect();
                            #$FSref->configure(-verify => ['-d']);
                            #$ExcelFile_Name_Path = $FSref->Show;                          
                        	);
                        
                        
                
                            if($ExcelFile_Name_Path)
                            {
                               @File_Select_Arr=split(/\[/, $ExcelFile_Name_Path);
                               $input_excel_File_Name=$File_Select_Arr[-1];
                               print "Excel File Name =$input_excel_File_Name";
                               $Designation_path = dirname($ExcelFile_Name_Path); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side => "right",-padx=>'05',-pady=>'03');

$path_frame_dir->Label(
        -text=>'Folder   ',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI Light} 11 ')->pack(-side=>'left');
         
        
$status= ' Not Started';
$entry = $path_frame_dir->Entry(
        -width=>'50',
        -textvariable=>\$Excelsheets_Path,
        -background => "grey",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'0');

                $path_frame_dir->Button(
                        -text=>"BROWSE",
                        -width=>'9',
                        -height=>'1.5',
                        #-relief => 'groove',
                        -background => "orange",
                        -foreground  => "DodgerBlue1",
                         -font=>'{Segoe UI} 8.5',
                        -command=>sub
                        {
                            $Excelsheets_Path = $main->chooseDirectory;
                            -title=>"Choose the directory which contains the exported SPSs",
                            
                           # $Excelsheets_Path = $main->getOpenFile(
                            #            -filetypes=>[
                            #                ["xls xlsx files", ['.xlsx', '.xls'] ],
							#				["xls xlsx files", ['.xlsx', '.xls'] ],
                             #          ],
                             #          -title=>"Choose the xls file ",
                            
                            #my $FSref = $main->FileSelect();
                            #$FSref->configure(-verify => ['-d']);
                            #$ExcelFile_Name_Path = $FSref->Show;                          
                        	#);
                                                                            
                        }
        )->pack(-side => "right",-padx=>'05',-pady=>'03');
        
$path_frame_sandbox->Label(
        -text=>'Sandbox',
        -background => "DodgerBlue1",
         -foreground => "white",
        -font=>'{Segoe UI Light} 11 ')->pack(-side=>'left');           
        
$entry = $path_frame_sandbox->Entry(
        -width=>'50',
        -textvariable=>\$SandboxFile_Path,
        -background => "grey",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'1');

               $path_frame_sandbox->Button(
                        -text=>"BROWSE",
                        -width=>'9',
                        -height=>'1.5',
                        #-relief => 'groove',
                        -background => "orange",
                        -foreground  => "DodgerBlue1",
                         -font=>'{Segoe UI} 8.5',
                        -command=>sub
                        {
                           #$SandboxFile_Path = $main->chooseDirectory;
                           #-title=>"Choose the sandbox directory",
                            $SandboxFile_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["sandbox directory", ['.pj'] ],
                                            ["sandbox directory", ['.pj'] ],
                                       ],
                                        -title=>"Choose the sandbox directory",
                        				);
                
                            if($SandboxFile_Path)
                            {
                               #@File_Select_Arr=split(/\[/, $SandboxFile_Path);
                               #$input_excel_File_Name=$File_Select_Arr[-1];
                               #print "Excel File Name =$input_excel_File_Name";
                               $SandboxFile_Path = dirname($SandboxFile_Path); 
                               print "Sandbox path =$SandboxFile_Path";
                               #$Designation_path=$Designation_path."/";                            
                            }
                                                    
                        }
        )->pack(-side => "top",-padx=>'06');    


$end_frame = $main->Frame("-background" => "DodgerBlue1")->pack(-ipadx=>'10', -padx=>'2');
$end_frame->Button(
        -text=>'EXIT',
        -width=>'9',
        -height=>'1.5',
        -font=>'{Segoe UI} 10 ',
         -background => "orange",
         -foreground => "DodgerBlue1",
         #-relief => 'groove',
        -command=>[$main=>'destroy']
        )->pack(-pady=> 10, -padx=> 10, -side=>'right');


$end_frame->Button(
        -text=>'START',
        -width=>'9',
        -height=>'1.5',
        -font=>'{Segoe UI} 10 ',
		-background => "orange",
        -foreground => "DodgerBlue1",
        #-relief => 'groove',
        -command=>sub {Generate_File()}
        )->pack(-pady=> 10, -padx=> 10,  -side=>'right');   
        
 # create label in window 'main'
 $main -> Label(
        -textvariable => \$status, #reference to display the status
         -font=>'{Segoe UI Light} 11',
        -background  => "DodgerBlue1",
        -foreground  => "gray90",
        )-> pack( "-pady" => 6,-side=>'top' );
        
MainLoop;

 
  
sub Generate_File(){
	
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time());
	my $date = sprintf("%04d%02d%02d", $year+1900, $mon+1, $mday );
	my $time = sprintf("%02d%02d%02d", $hour, $min, $sec);
	$tcTime = "$date"."_$time";
	($start_date, $start_time) = S_formated_timestamp();
	$username = getlogin || getpwuid($<) ;
	print "$username\n";

    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI   
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    		
		if(defined $Excelsheets_Path){
			find(\&check_eachfile, $Excelsheets_Path);
			
			my ($secEnd,$minEnd,$hourEnd,$mdayEnd,$monEnd,$yearEnd,$wdayEnd,$ydayEnd,$isdstEnd) = localtime(time());		
			$executionMin = $minEnd - $min;
			if ($secEnd> $sec){
				$executionSec = $secEnd - $sec if ($secEnd> $sec);				
			}
			else{
				$executionSec = ($secEnd+60) - $sec if ($secEnd< $sec);
				$executionMin = $executionMin - 1;
			}

			htmlMultipleFiles () if ($multipleFilesFlag == 1);			
		}
		else{
			if(!$input_excel_File_Name){
		       	$status= "Select the excel file !!"; 
				$main->update();
				die("excel file $input_excel_File_Name is not found!\n");
		    }
			process_excelfile($input_excel_File_Name);
		}
			
		$status = "Completed! \nHave a look at error log file for Errors and Warnings";		
		$main->update();
		print "\n\nCompleted! \nHave a look at error log file for Errors and Warnings\n";
		
		undef $Excelsheets_Path;
		undef $ExcelFile_Name_Path;
		undef $input_excel_File_Name;
		undef %excelFile; #clear old data
		undef %globalVerdicts;
		$multipleFilesFlag = 0;
}



sub check_eachfile{
	my $Filename = $_;
	my $filepath = $File::Find::name;
	
	if($Filename =~ m/\.xls/i){ #if the file is an SPS/SPR excel file
		if($Filename =~ m/SPS|SPR/i){
			$multipleFilesFlag = 1;
			process_excelfile($filepath);	
			sleep(2);
		}
		else{
			print "\n\n!!!! $Filename is not processed. Only excel files whose file name contains SPS or SPR are handeled !!!! \n";
		}
					
	}
		  
}


sub process_excelfile{
	
	#>>>>>>>>>>>>>>>>>>>> Re initialize all global variables for each new file to be processed<<<<<<<<<<<<<<<<<<<
	undef %parData;
	undef %parDataFile;
	undef %parDetails;	
	undef @error_messages;
	undef @warning_messages;	
	$passCount = 0;
	$failCount= 0;
	$inconcCount= 0;
	$noneCount= 0; 
	$notfoundCount= 0;
	#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> End <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	
	my ($verdict,$verdictColor,$pathcolor);	
	my $input_excel_File_Name = shift; #name of file
	#my $filepath = $File::Find::name;
	
			#SheetName of the Exported Decoder sheet
		my %input_data_Sheet = (
								'in_Data1'=>"Tabelle1",
								'in_Data2'=>"sheet1",
								);									
	
		
		my $excel;
		my $input_WorkBook;
		my $input_WorkSheet;
		my @datavaluelines;

		# Open the xls using the WIN OLE package  
		use Win32::OLE qw(in with);
		use Win32::OLE::Const 'Microsoft Excel';
		$Win32::OLE::Warn = 3;

		# get already active Excel application or open new
		$excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');  
		#$excel->{DisplayAlerts}=0;
		#$excel->{Visible} =0;

		# open Excel file which comtain  the decoder information 
		$input_WorkBook = $excel->Workbooks->Open("$input_excel_File_Name");
		# select workSheet number 1 (you can also select a workSheet by name)
		
		$input_WorkSheet = $input_WorkBook->Worksheets(1);
		
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
		my $LastRow_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
		SearchDirection=>xlPrevious,
		SearchOrder=>xlByRows})->{Row};
		print "\nLast Row of input file =",$LastRow_input_data,"\n";
		
		my $LastColoumn_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
		SearchDirection=>xlPrevious,
		SearchOrder=>xlByColumns})->{Column};
		print "\nLast Coloumn of input file =",$LastColoumn_input_data,"\n";
					
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^       
		$status = "Conversion in progress!!!";
		$main->update();

		print "$input_excel_File_Name\n";		
		my($file, $dir, $ext) = fileparse($input_excel_File_Name);
		my $excelfile = $file;
		$file =~ s/\.xlsx$//;
		$file =~ s/\.xls$//;
		$relPath = "reports_$file"."_$tcTime";
		
		my ($volume, $directory, $filename) = File::Spec->splitpath(__FILE__);
		if(defined $Excelsheets_Path){ #multiple file handling
			$allReportsPath = File::Spec->rel2abs("$directory/reports_$tcTime");	
			$reportsPath = $allReportsPath."/reports_$file"."_$tcTime";	
			mkdir($allReportsPath, 0700);
		}
		else{
			$reportsPath = File::Spec->rel2abs("$directory/reports_$file"."_$tcTime");
		}
		$snapshotPath = "$reportsPath/_snapshot_/";
		$tempPath = "$reportsPath/_snapshot_/temp";
		print "$reportsPath\n";		
				 
		mkdir($reportsPath, 0700); 
		mkdir($snapshotPath, 0700); 
		mkdir($tempPath, 0700); 
		
		copy("$input_excel_File_Name","$snapshotPath\\$excelfile"); #copy SPS to snapshot folder
		copy("$filename","$snapshotPath\\$filename"); #copy peace.pl to snapshot folder (for future analysis)
				
				
		#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
		my $Header_Filter_Row =1;
		my $column =1;
		my $column_Read;
		my $xls_Type_column;
		my $xls_NameAtSW_column;
		my $xls_Description_column;
		my $xls_SWDefautRange_column;
		my $xls_ID_column;
		my $xls_source_column;
		
		foreach $column(1..$LastColoumn_input_data){
			$column_Read=""; # clear the old data 
			# Read the bit byte cell value from xls File 
			$column_Read =$input_WorkSheet->Cells($Header_Filter_Row,$column)->{'Value'};
			
			if($column_Read =~ m/^Type$/i){
				$xls_Type_column = $column;
			}
			elsif($column_Read =~ m/Name @ SW/i){
				$xls_NameAtSW_column = $column;
			}
			elsif($column_Read =~ m/Software Parameter Specification|Description/i){
				$xls_Description_column = $column;
			}
			elsif($column_Read =~ m/SW Defaut\/Range/i){
				$xls_SWDefautRange_column = $column;
			}
			elsif($column_Read =~ m/^ID$/i){
				$xls_ID_column = $column;
			}
			elsif($column_Read =~ m/^Source$/i){
				$xls_source_column = $column;
			}
		}	
		#++++++++++++++++++++++++++++++++++++++++++++++++++++++

		# check if all expected columns are present in excel sheet
		unless (defined $xls_Type_column){
			push(@error_messages,  "'Type' column is missing. Please make sure the headings of each column are exported from the SPS\n");
		}
		unless (defined $xls_NameAtSW_column){
			push(@error_messages,  "'Name @ SW' column is missing. Please make sure the headings of each column are exported from the SPS\n");
		}
		unless (defined $xls_Description_column){
			push(@error_messages,  "'Software Parameter Specification ...' or 'Description' column is missing. Please make sure the headings of each column are exported from the SPS\n");
		}
		unless (defined $xls_SWDefautRange_column){
			push(@error_messages,  "'SW Defaut/Range' column is missing. Please make sure the headings of each column are exported from the SPS\n");
		}
		unless (defined $xls_ID_column){
			push(@error_messages,  "'ID' column is missing. Please make sure the headings of each column are exported from the SPS\n");
		}
		unless (defined $xls_source_column){
			push(@error_messages,  "'Source' column is missing. Please make sure the headings of each column are exported from the SPS and thsi column is available\n");
		}		
		#++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		
		#++++++++++++++++++++++++++++create the SPS HASH+++++++++++++++++++++++++++++++++++++++				
		my ($xls_Type_read,
			$xls_NameAtSW_read, 
			$xls_Description_read,
			$xls_SWDefautRange_read,
			$xls_ID_read,	
			$xls_source_read,				
			$paraFileName,
			$paraFileName_File2,
		);
						
		foreach my $row (1..$LastRow_input_data){ #parse all rows of excel sheet

			$xls_ID_read =$input_WorkSheet->Cells($row,$xls_ID_column)->{'Value'} if defined $xls_ID_column;
			$xls_Type_read  =$input_WorkSheet->Cells($row,$xls_Type_column)->{'Value'} if defined $xls_Type_column;
																													
			if (defined $xls_Type_read and $xls_Type_read =~ m/Heading/i){ #if heading is found
				#undef $paraFileName;   
				$xls_Description_read =$input_WorkSheet->Cells($row,$xls_Description_column)->{'Value'} if defined $xls_Description_column;
				
				if(defined $xls_Description_read){
					
					if($xls_Description_read =~ m/(.*?)\.p\s*\/\s*(.*?)\.p/i){ #File: sem_sensormgtpar.p / sem_sensormgteeprom.p
						$paraFileName = $1.'.p';
						$paraFileName_File2 = $2.'.p';
						$multipleFileFlag = 1;
					}
					elsif($xls_Description_read =~ m/(.*?)\.p\s*(.*?)\.p/i){ #File: sem_sensormgtpar.p sem_sensormgteeprom.p
						$paraFileName = $1.'.p';
						$paraFileName_File2 = $2.'.p';
						$multipleFileFlag = 1;
					}
					elsif($xls_Description_read =~ m/(.*?)\.p\s*/i){
						$paraFileName = $1.'.p';
						$multipleFileFlag = 0;
					}
					elsif($xls_Description_read =~ m/(.*?)\.h\s*/i){
						$paraFileName = $1.'.h';
						$multipleFileFlag = 0;
					}
					elsif($xls_Description_read =~ m/(.*?)\.c\s*/i){
						$paraFileName = $1.'.c';
						$multipleFileFlag = 0;
					}
					elsif($xls_Description_read =~ m/File\s*:\s*(.*?)$/i){ #any other file (other than .p .h or .c)
						$paraFileName = $1;
						$multipleFileFlag = 0;
					}
					
					chomp($paraFileName);
					$paraFileName =~ s/File\s*:\s*//; #remove additional words
					$paraFileName =~ s/File\s*//; #even if semicolon is missing!!!
					$paraFileName =~ s/ //; #remove spaces
					print "$paraFileName\n";
				}
				#if(defined $xls_Description_read and ($xls_Description_read =~ m/(.*?)\.p\s*/i or $xls_Description_read =~ m/(.*?)\.h\s*/i or $xls_Description_read =~ m/(.*?)\.c\s*/i)){ #.p or .h or .c files
				#	$paraFileName = $xls_Description_read ;
				#	
				#}
			}			
			elsif(defined $xls_Type_read and $xls_Type_read =~ m/Parameter|Constant|Definition/i){ #if Parameter|Constant|Definition is found
				if(defined $paraFileName){
					$xls_NameAtSW_read =$input_WorkSheet->Cells($row,$xls_NameAtSW_column)->{'Value'} if defined $xls_NameAtSW_column;
					$xls_SWDefautRange_read =$input_WorkSheet->Cells($row,$xls_SWDefautRange_column)->{'Value'} if defined $xls_SWDefautRange_column;
					$xls_source_read =$input_WorkSheet->Cells($row,$xls_source_column)->{'Value'} if defined $xls_source_column;

					if(defined $xls_NameAtSW_read){
						chomp($xls_NameAtSW_read);
						chomp($xls_SWDefautRange_read);
						$parData{$paraFileName}{$xls_NameAtSW_read}{'expected'} = $xls_SWDefautRange_read;
						unless(defined $xls_SWDefautRange_read){
							$parData{$paraFileName}{$xls_NameAtSW_read}{'expected'} = 'not defined';
						}
						$parData{$paraFileName}{$xls_NameAtSW_read}{'ID'} = $xls_ID_read;
						$parData{$paraFileName}{$xls_NameAtSW_read}{'source'} = $xls_source_read;
						$parDataFile{$paraFileName}{'secondFile'} = $paraFileName_File2 if ($multipleFileFlag == 1);
					}
					
					unless (defined $xls_NameAtSW_read){
						push(@error_messages,  "'Name @ SW' is not defined for ID $xls_ID_read\n");
					}
					unless (defined $xls_SWDefautRange_read){
						push(@error_messages,  "'SW Defaut/Range' is not defined for ID $xls_ID_read\n");
					}
					unless (defined $xls_source_read){
						push(@error_messages,  "'Source' is not defined for ID $xls_ID_read\n");
					}
				}
								
			}
		}
		
		$input_WorkBook->Close(); 
		
		$reportfile = "$reportsPath\\$file"."_report.html";
				
		#+++++++++++++++++++++++++create the html report and result.txt file++++++++++++++++++++++++++	
		open (HTMLFILE,">$reportsPath\\$file"."_report.html") || die("$reportsPath\\$file"."_report.html could not be created!\n");  
		open (IMPORTFILE,">$reportsPath\\$file"."_importfile.txt") || die("$reportsPath\\$file"."_importfile.txt could not be created!\n");  
		print IMPORTFILE "#### SPR IMPORT RESULT FILE ####\n";		
		print IMPORTFILE "CPG_START;.$relPath;LabCar;$start_date;$start_time\n\n";
		print IMPORTFILE "#TC_VD;name;VERDICT;date;time;exetime;tcnum;purpose1;purpose2;purpose3;TS path;ID;expected;observed\n";
		
		$excelFile{$file}{'path'} = "$reportsPath\\$file"."_report.html";
		$excelFile{$file}{'logPath'} = "$reportsPath\\$file"."_errorLog.txt";
		
		
		#$directory = 'D:\MKS\vo1000'; #the starting directory		
			
		find(\&check_file, $SandboxFile_Path);
		
		#+++++++++++++++++++++++++for evaluation summary section++++++++++++++++++++++++++	
		#>>>>>>>>>>>>>> handle not found files <<<<<<<<<<<<<<<<<<<
		foreach my $paraFile (sort keys %parData){
			chomp($paraFile);		
			#>>>>>>>>>>>>>> check if file is found in sandbox dir<<<<<<<<<<<<<<<<<<<
			unless(defined $parDataFile{$paraFile}{'path'}){	
				$parDataFile{$paraFile}{'path'} = "file not found in directory $SandboxFile_Path !!";				
			    my $names = $parData{$paraFile};
				foreach my $par (sort keys %$names){
					chomp($par);
			    	$parData{$paraFile}{$par}{'observedString'} = 'not found';
			    	$parData{$paraFile}{$par}{'observedValue'} = '-';
			    	$parData{$paraFile}{$par}{'verdict'} = 'NOT_FOUND';
			    	$parData{$paraFile}{$par}{'verdictColor'} = 'blue';
			    	$notfoundCount++;
		    	}
			}
		}
		my $totalVerdictCount = $passCount+$failCount+$inconcCount+$notfoundCount;
		my $passPercentage = sprintf("%.1f",$passCount/$totalVerdictCount*100) if ($totalVerdictCount > 0);
		my $failPercentage = sprintf("%.1f",$failCount/$totalVerdictCount*100) if ($totalVerdictCount > 0);
		my $inconcPercentage = sprintf("%.1f",$inconcCount/$totalVerdictCount*100) if ($totalVerdictCount > 0);
		my $notfoundPercentage = sprintf("%.1f",$notfoundCount/$totalVerdictCount*100) if ($totalVerdictCount > 0);
		my $allPercentage = sprintf("%.1f",$totalVerdictCount/$totalVerdictCount*100) if ($totalVerdictCount > 0);
	
		my $errorLogPath = "$reportsPath/".$file."_errorLog.txt";
		my $logFileName = $file."_errorLog.txt";

		my $html_report_info= <<EOHTML;
		<TABLE><TR>
			<BR>&nbsp;<BR>
		</TR></TABLE> 
		<div id="content"><a name="Top" id="Top"></a>		
		<TABLE width="100%"><TR>
		    <div style="font-family:Arial; color:black; font-size:22; font-weight:bold; text-align:center">Software Parameter Report</div>
		    <div style="font-family:Arial; color:grey; font-size:18; font-weight:bold; text-align:center">Test of the Software Parameter Specification</div>
		</TR></TABLE>
		</div>

		<HR>
		<TABLE align = "left"><TR>
		    <TH><div style="font-family:Arial; color:black; font-size:18; font-weight:normal; text-align:left">Summary</div></TH>
		</TR></TABLE>
		<TABLE align = "right"><TR>
			<TH><div style="font-family:Arial; color:black; font-size:18; font-weight:normal; text-align:right">Evaluation</div></TH>
		</TR></TABLE>
		
	<TABLE><TR>
		<div style="font-family:Arial; color:white; font-size:14; font-weight:normal">&nbsp;</div>
		<div style="font-family:Arial; color:white; font-size:14; font-weight:normal">&nbsp;</div>
	</TR></TABLE>
			
		
		<!-- CSS goes in the document HEAD or added to your external stylesheet -->
<style type="text/css">
table.gridtable {
	font-family: segoe UI,verdana,arial,sans-serif;
	font-size:11.5px;
	color:#333333;
	border-width: 2px;
	border-color: #666666;
	border-collapse: collapse;
}
table.gridtable th {
	border-width: 2px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #D4E5F7; #light blue
}
table.gridtable td {
	border-width: 2px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #ffffff;
}
</style>
<!-- Table goes in the document BODY -->
<table class="gridtable"; align = "left">	
		<TR ALIGN="LEFT">
            <TH>Generated from</TH>
            <TD><A HREF="file:///$snapshotPath$excelfile" TYPE="text/pm">$excelfile</A></TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Sandbox directory</TH>
            <TD>$SandboxFile_Path</TH>
        </TR>        
        <TR ALIGN="LEFT">
            <TH>Date/Time</TH>
            <TD>$start_date $start_time</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Generated by</TH>
            <TD>$username</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Error Log</TH>
            <TD><A HREF="file:///$errorLogPath" TYPE="text/pm">$logFileName</A></TH>
        </TR>
     </TABLE>
       
<table class="gridtable"; align = "right">	
		<TR ALIGN="LEFT">
            <TH>VERDICT</TH>
            <TH>Number of tests</TH>
        </TR>
		<TR ALIGN="LEFT">
            <TH>PASS</TH>
            <TD><span style="color:green">$passCount ($passPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>FAIL</TH>
            <TD><span style="color:red">$failCount ($failPercentage%)</span></TD>
        </TR>        
        <TR ALIGN="LEFT">
            <TH>INCONC</TH>
            <TD><span style="color:purple">$inconcCount ($inconcPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>NOT_FOUND</TH>
            <TD><span style="color:blue">$notfoundCount ($notfoundPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>TOTAL</TH>
            <TD><span style="color:black">$totalVerdictCount ($allPercentage%)</span></TD>
        </TR>
	</TABLE>
	        
	<TABLE><TR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
	</TR></TABLE> 
		
	<TABLE><TR>
		<div style="font-family:Arial; color:white; font-size:18; font-weight:bold">&nbsp;</div>		
		<div style="font-family:Arial; color:black; font-size:22; font-weight:bold; text-align:left">ParameterList</div>
	</TR></TABLE>

EOHTML
		
		print HTMLFILE $html_report_info;			
	
		foreach my $paraFile (sort keys %parData){
			chomp($paraFile);		
			print"\n$paraFile";	
			print IMPORTFILE "\n#$paraFile\n";	 
			my $pathcolor = 'black';	
			if($parDataFile{$paraFile}{'path'} =~ m/file not found/i){
		    	$pathcolor = 'red';
			}  		
			my $filetext1 = <<EOHTML;	    
		<TABLE><TR>
		    <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
		    <div style="font-family:segoe UI; color:grey; font-size:18; font-weight:normal; text-align:left">$paraFile ($parDataFile{$paraFile}{'revision'} $parDataFile{$paraFile}{'state'})</div>
		    <div style="font-family:segoe UI; color:$pathcolor; font-size:14; font-weight:lighter; text-align:left">$parDataFile{$paraFile}{'path'}</div>
		    <div style="font-family:segoe UI; font-size:14; font-weight:lighter; text-align:left"><A HREF="file:///$snapshotPath$paraFile" TYPE="text/pm">./$relPath/_snapshot_/$paraFile</A></div>
		    <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
		</TR></TABLE>
EOHTML

		    my $filetext2 = <<EOHTML;
<!-- Table goes in the document BODY -->
<table class="gridtable">
			
		<TR ALIGN="LEFT" bgcolor = grey; border:1px solid green;>
            <TH WIDTH="3%">ID</TH>
            <TH WIDTH="12%">File</TH>
            <TH WIDTH="10%">SW label (Name @ SW)</TH>
            <TH WIDTH="3%">Source</TH>
            <TH WIDTH="25%">Expected (SW Default/Range)</TH>
            <TH WIDTH="25%">Observed String</TH>
            <TH WIDTH="15%">Observed Value</TH>
            <TH WIDTH="5%">Verdict</TH>
        </TR>        
EOHTML
			print HTMLFILE $filetext1;
			print HTMLFILE $filetext2 if (defined $parData{$paraFile});

			my $names = $parData{$paraFile};
			foreach my $par (sort keys %$names){
				chomp($par);
				my $IDnum = $parData{$paraFile}{$par}{'ID'};
				$IDnum =~ s/\D*//; #remove all no digits from ID	
				$parData{$paraFile}{$par}{'expected'} =~ tr{\n}{ }; #replace all newlines with space
				$parData{$paraFile}{$par}{'observedString'} =~ tr{\n}{ }; #replace all newlines with space
				$parData{$paraFile}{$par}{'observedString'} =~ tr{;}{ }; #replace ; with space
				$parData{$paraFile}{$par}{'observedString'} =~ s/\s+/ /g; #replace multiple spaces with single space
				$parData{$paraFile}{$par}{'observedValue'} =~ tr{\n}{ }; #replace all newlines with space
				$parData{$paraFile}{$par}{'fileName'} =~ tr{\n}{ }; #replace all newlines with space 
				my $htmlPar = $par;
				$htmlPar =~ tr{<}{\(}; #replace < with ( since it is not processed by html properly)
				$htmlPar =~ tr{>}{\)}; #replace > with ) since it is not processed by html properly)	
				my $verdict = $parData{$paraFile}{$par}{'verdict'};
				$verdict = 'FAIL' if ($verdict eq 'NOT_FOUND');	#convert to FAIL in import file							
				print IMPORTFILE "TC_VD;$par;VERDICT_$verdict;$start_date;$start_time; ; ; ; ; ; ;$IDnum;\tExpected:$parData{$paraFile}{$par}{'expected'}\t;\tFile: $parData{$paraFile}{$par}{'fileName'}\tObserved String: $parData{$paraFile}{$par}{'observedString'}\tObserved Value: $parData{$paraFile}{$par}{'observedValue'}\t\n";
				my $parinfo= <<EOHTML;
		<TR ALIGN="LEFT" bgcolor = silver>
            <TD WIDTH="3%">$parData{$paraFile}{$par}{'ID'}</TD>
            <TD WIDTH="12%">$parData{$paraFile}{$par}{'fileName'}</TD>
            <TD WIDTH="10%">$htmlPar</TD>
            <TD WIDTH="3%">$parData{$paraFile}{$par}{'source'}</TD>
            <TD WIDTH="25%">$parData{$paraFile}{$par}{'expected'}</TD>
            <TD WIDTH="25%">$parData{$paraFile}{$par}{'observedString'}</TD>
            <TD WIDTH="15%">$parData{$paraFile}{$par}{'observedValue'}</TD>
            <TD WIDTH="5%"><span style="color:$parData{$paraFile}{$par}{'verdictColor'}">$parData{$paraFile}{$par}{'verdict'}</span></TD>
		</TR>							
EOHTML
					
			print HTMLFILE $parinfo;			
			}						
		}		
		my $endtable = <<EOHTML;					
			</TABLE>
			<TABLE><TR>
				<BR>&nbsp;<BR>
			</TR></TABLE>
			<HR>
	        
	        <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
	        <div style="font-family:Segoe UI; color:grey; font-size:18; font-weight:normal; text-align:left">Remarks:</div>
	        <div style="font-family:Segoe UI; color:black; font-size:14; font-weight:normal; text-align:left">NOT_FOUND - The parameter mentioned in the SPS is not found in the corresponding parameter file (or) the file is not found in the sandbox directory. </div>
	        <div style="font-family:Segoe UI; color:black; font-size:14; font-weight:normal; text-align:left">INCONC - Verdict of the test case is inconclusive. Manual verificaion is required. </div>	        
	        <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
EOHTML
		print HTMLFILE $endtable;

		close IMPORTFILE;	
		close HTMLFILE;	
		
		$excelFile{$file}{'PASS'} = $passCount;
		$excelFile{$file}{'FAIL'} = $failCount;
		$excelFile{$file}{'INCONC'} = $inconcCount;
		$excelFile{$file}{'NOT_FOUND'} = $notfoundCount;
		$excelFile{$file}{'TOTAL'} = $totalVerdictCount;
		
		$globalVerdicts{'totalPass'} += $passCount;
		$globalVerdicts{'totalFail'} += $failCount;
		$globalVerdicts{'totalInconc'} += $inconcCount;
		$globalVerdicts{'totalNotFound'}  += $notfoundCount;
		$globalVerdicts{'totalAll'}  += $totalVerdictCount;
			
		#++++++++++++++++++++++++++++log files+++++++++++++++++++++++++++++++++++++++	
		open (ERRORLOG,">$reportsPath/$file"."_errorLog.txt") || die("$file"."_errorLog.txt could not be created!\n");  
		my $errorcount = 0;
		print ERRORLOG "!!!!!!!!!!!!!!!!!!!!!!!!ERRORS!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
		if(defined $error_messages[0]){
			foreach my $error (@error_messages){
				$errorcount++;
				print ERRORLOG "$errorcount. $error";
			}
		}
		else{
			print ERRORLOG "No Errors! :-)";
		}
		
		my $warningcount = 0;
		print ERRORLOG "\n\n!!!!!!!!!!!!!!!!!!!!!!!!WARNINGS!!!!!!!!!!!!!!!!!!!!!!\n\n";
		if(defined $warning_messages[0]){
			foreach my $warning (@warning_messages){
				$warningcount++;
				print ERRORLOG "$warningcount. $warning";
			}
		}
		else{
			print ERRORLOG "No Warnings! :-)";
		}	
				  
		##################  Save File is completed ###############################     
		
		close ERRORLOG;
   
	    if($multipleFilesFlag != 1){
	    	#++++++++++++++++++++++++++++ Open Report on Completion +++++++++++++++++++++++++++++++++	
		    $status= "Completed! \nHave a look at error log file for Errors and Warnings";
		    print "\n\nCompleted! \nHave a look at error log file for Errors and Warnings\n";
		    $main->update(); # sub 
		    
		    if (-e 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'){
		    	# workaround with 'CMD' because just calling 'start' causes MKS error 'wrong OS' (there is a start.exe in MKS subfolder)
		        system('CMD /C start "C:\Program Files (x86)\Mozilla Firefox\firefox.exe" file:///'."$reportfile"); # open in Firefox Win7 
		    }
		    elsif (-e 'C:\Program Files\Mozilla Firefox\firefox.exe'){
		        system('start "C:\Program Files\Mozilla Firefox\firefox.exe" file:///'."$reportfile"); # open in Firefox
		    }
		    else{
		        print(" could not open Firefox to display report\n"); 
		    } 
	    }
	     

    #---------------to create a zip archive------------------
#    print "Backing up ".$reportsPath."\n";
#    my $zip = Archive::Zip->new();
     
    #add files in report path
#    opendir (DIR, $reportsPath) or die $!;     
#    while (my $eachfile = readdir(DIR)) {         
    	# Use -f to look for a file
#    	next unless (-f $reportsPath."\\".$eachfile);
#		$zip->addFile($reportsPath."\\".$eachfile, $eachfile);
#        print "Added $eachfile to zip\n";
#	}
#    closedir(DIR);
    
    #add files in snapshots path
#    opendir (DIR, $snapshotPath) or die $!;     
#    while (my $eachfile = readdir(DIR)) {         
    	# Use -f to look for a file
#    	next unless (-f $snapshotPath."\\".$eachfile);
#		$zip->addFile($snapshotPath."\\".$eachfile, "_snapshot_\\".$eachfile);
#        print "Added $eachfile to zip\n";
#	}
#    closedir(DIR);
    
#    unless ( $zip->writeToFileNamed("$relPath.zip") == AZ_OK ) {
#		die 'write error';
#	}
#	print "Successfully backed up to ". "$relPath.zip";
		
		

}


sub check_file{
	my $File = $_; #name of file
	my $filepath = $File::Find::name; #absolute path of file
	
	foreach my $paraFile (sort keys %parData){
		chomp($paraFile);	
		my $secondFile = $parDataFile{$paraFile}{'secondFile'} if defined $parDataFile{$paraFile}{'secondFile'};	
	    if(($File eq $paraFile) or (defined $secondFile and $File eq $secondFile)){	#if current file matches the expected file    	
	    	$parDataFile{$paraFile}{'path'} = $filepath;  
	    	$parDataFile{$secondFile}{'path'} = $filepath if ($File eq $secondFile);  
	    	print"\n$paraFile found ($filepath)\n";  				    	
	    	copy("$filepath","$snapshotPath\\$File"); #copy const file from sandbox to reports/snapshot folder	    	    	 	
	    	removeComments ($File); #remove C comments
	    	
			my $names = $parData{$paraFile};
			foreach my $par (sort keys %$names){								
				chomp($par);		
		    	$parData{$File}{$par}{'observedString'} = processFile($File,$par); #if ($File eq $paraFile);
		    	evaluateParameters($File,$par) if ($File eq $paraFile);	#evaluate only for main file, handle second file internally
		    	setVerdicts ($File,$par) if ($File eq $paraFile);	#evaluate only for main file, handle second file internally	 	   		 	
	    	}	    
    	}
    	#unlink "temp_$paraFile" or warn "Could not delete temporary file temp_$paraFile!";
	}
}

sub removeComments{
	
	my $foundFile = shift;
	
	open (CONSTFILE,"$snapshotPath\\$foundFile")|| die("$snapshotPath\\$file could not be opened!\n");
	open (TEMPWRITE,">$tempPath\\temp_$foundFile") || die("$tempPath\\temp_$foundFile could not be opened \n!");  
	    	
	my $commentedText = '';
	my $commentStarted = 0;
    while (my $line_ConstFile = <CONSTFILE>) {	
       #get the MKS revision
       if($line_ConstFile =~ m/\$Revision\s*\:(.*?)\$/i){
       		$parDataFile{$foundFile}{'revision'} = $1;
       		$parDataFile{$foundFile}{'revision'} =~ tr{\n*}{}; #remove newlines
       		$parDataFile{$foundFile}{'revision'} =~ s/ +/ /; #remove spaces
       }
       #get the state of file
       elsif($line_ConstFile =~ m/\$State\s*\:(.*?)\$/i){
       		$parDataFile{$foundFile}{'state'} = $1;
       }
       		   			   
	   if($line_ConstFile =~ m/^(.*?)\/\*(.*?)\*\/(.*?)$/){ # ... /* ... */ ... remove comments in each line (single line comments)
	   		$line_ConstFile = $1.$3;
	   		print TEMPWRITE "$line_ConstFile\n" if ($line_ConstFile =~ m/\S/);
	   }
	   elsif ($line_ConstFile =~ m/\/\*/ or $commentStarted == 1){ #remove multiple line comments
	   		$commentStarted = 1;
	   		$commentedText = $commentedText.$line_ConstFile;	
	   		if($line_ConstFile =~ m/\*\/\s*$/ and $commentStarted == 1){
	   			$commentStarted = 0;
	   			$commentedText = ''; #empty comment
	   		}
	   }
	   else{
	   		print TEMPWRITE $line_ConstFile if ($line_ConstFile =~ m/\S/); #print to temp file only if line contains a non-whitespace char
	   }						
	}
	
	close TEMPWRITE;
	close CONSTFILE;
}

sub processFile{ #process every valid parameter found in the file
	
	my $foundFile = shift;
	my $par = shift;
	
	print "expected par $par\n";
	
	my @multipleLines;
	
	open (TEMPREAD,"$tempPath\\temp_$foundFile") || die("$tempPath\\temp_$foundFile could not be opened \n!");  
    	my ($enumDef,$arrayDef,$macroDef,$maskDef,$structDef);
    	my $enumStarted= 0;
    	my $arrayStarted =0; 
    	my $macroStarted =0; 
    	my $maskStarted =0;
    	my $structStarted =0;
    	my $array;  
    	my $observedLine; 	
    	while (my $line = <TEMPREAD>){
    		chomp($line);
    		    		  		
    		#>>>>>>>>>>>>>> process enums <<<<<<<<<<<<<<<<<<<
    		#store all enums temporarily
    		#typedef enum
			#{
			#   E_TimeOutThdGroup1,
			#   E_TimeOutThdGroup3,
			#   E_MaxToutQualiGroup
			# }te_ToutQualiGroup;
			
    		if($line =~ m/typedef enum/i or $enumStarted == 1){ #start of enum
    			$enumDef = $enumDef.$line;
    			$enumStarted = 1;
    			if($line =~ m/(.*?)te\_(.*?)\;/){ #end of enum
    				my $enum = "te_".$2;
    				$parDetails{$foundFile}{$enum} = $enumDef; #store all found enums temporarily in a hash   				
		   			$enumStarted = 0;
		   			undef $enumDef;			   			
		   		}				   		
    		}
    		
    		#>>>>>>>>>>>>>> process arrays <<<<<<<<<<<<<<<<<<<
    		#extern ts_FLMBoschFaultEntry   A_BoschFltMem_XSE[C_FltMemEepromSize_U8X];
    		#const ts_FLMBoschFaultEntry  A_BoschFltMem_XSE[C_FltMemEepromSize_U8X] = {
        		#{0xFFFFFFFFu,0xFFFFu,0xFFu,0xFFu,0xFFFFFFFFu},
        		#{0xFFFFFFFFu,0xFFFFu,0xFFu,0xFFu,0xFFFFFFFFu},
			if($par =~ m/^A\_/){ #if line has an array parameter name, push the stored array value
				if($line =~ m/(.*?)\s*\Q$par\E(.*?)/ or $arrayStarted == 1){ #start of array #\s*\=	
	    			$arrayDef = $arrayDef.$line;  
	    			$arrayStarted = 1;			  			   			
	    			if($arrayStarted == 1 and $line =~ m/(.*?)\s*\;/){  #end of array #\}					
			   			$arrayStarted = 0;
			   			push (@multipleLines,$arrayDef); 
			   			undef $arrayDef;
			   			undef $array;		   						   			
			   		}
				}
			}
			
			
			#>>>>>>>>>>>>>> process structs <<<<<<<<<<<<<<<<<<<
    		#const ts_AIDConfigTbl S_AIDCfgTbl_SXE = 
			#{
			#    {
			#	    0
			#    },
			elsif($par =~ m/^S\_/){ #if line has an array parameter name, push the stored array value
				if($line =~ m/(.*?)\s*\Q$par\E(.*?)/ or $structStarted == 1){ #start of array \s*\=   			
	    			$structDef = $structDef.$line;  
	    			$structStarted = 1;			  			   			
	    			if($structStarted == 1 and $line =~ m/(.*?)\s*\;/){  #end of array \}				
			   			$structStarted = 0;
			   			push (@multipleLines,$structDef); 
			   			undef $structDef;
			   			undef $structDef;		   						   			
			   		}
				}
			}
			
			#>>>>>>>>>>>>>> process macros (Z_) <<<<<<<<<<<<<<<<<<<
    		# #define Z_SystemAsicMacro Z_InitMacro1(SystemAsic1),\
            #               			Z_InitMacro1(SystemAsic2)
			elsif($par =~ m/^Z\_/){ #if line has a macro parameter name, push the stored macro value
				if($line =~  m/^(.*?)define\s*\Q$par\E\s*(.*?)\s*$/ or $macroStarted == 1){ #start of macro   			
	    			$macroDef = $macroDef.$line;  
	    			$macroStarted = 1;			  			   			
	    			if($macroStarted == 1 and $line !~ m/(.*?)\,\s*\\/){  #end of macro - line should not have ,\					
			   			$macroStarted = 0;
			   			push (@multipleLines,$macroDef); 
			   			undef $macroDef;   						   			
			   		}
				}
			}
			
			
			#>>>>>>>>>>>>>> process masks (M_) <<<<<<<<<<<<<<<<<<<
    		# #define M_StoreCrashTriggers_U32X      (U32)(M_AirbagDeploymentCrash_U32X | M_OtherDeploymentCrash_U32X |\
            #                                 				M_NoDeploymentCrash_U32X )
			elsif($par =~ m/^M\_/){ #if line has a macro parameter name, push the stored macro value
				if($line =~  m/^(.*?)define\s*\Q$par\E\s*(.*?)\s*$/ or $maskStarted == 1){ #start of macro   			
	    			$maskDef = $maskDef.$line;  
	    			$maskStarted = 1;			  			   			
	    			if($maskStarted == 1 and $line !~ m/(.*?)\|\s*\\/){  #end of mask - line should not have |\					
			   			$maskStarted = 0;
			   			push (@multipleLines,$maskDef); 
			   			undef $maskDef;   						   			
			   		}
				}
			}
			    		
    		#>>>>>>>>>>>>>> process all parameters <<<<<<<<<<<<<<<<<<<
    		#const U8 V_IniAirbagBulbStatus_U8C = 0;
    		#const U8 A_DefOCSSerialNoMessage_U8C[8] = {0,0,0,0,0,0,0,0};
    		#define Z_GetPIBCntCopy()
    		# #undef Z_CAPToutFault
    		# #define C_QualiTimeOutThdGroup1_U8X      (U8)25u
    		#extern ts_FLMBoschFaultEntry   A_BoschFltMem_XSE[C_FltMemEepromSize_U8X];
    		#const ts_FLMBoschFaultEntry  A_BoschFltMem_XSE[C_FltMemEepromSize_U8X] = {
        		#{0xFFFFFFFFu,0xFFFFu,0xFFu,0xFFu,0xFFFFFFFFu},
        		#{0xFFFFFFFFu,0xFFFFu,0xFFu,0xFFu,0xFFFFFFFFu},
    		
			elsif($line =~ m/\Q$par\E/i){ #if parameter is found in line
				print "$line\n";
				#>>>>>>>>>>>>>> process constants <<<<<<<<<<<<<<<<
				if($par =~ m/^C\_|^M\_|^Z\_/){ #if the parameter is a constant (C_...) or bit mask (M_) or macro (Z_), only use if line has a #define					
					if($line =~ m/^(.*?)define\s*\Q$par\E\s*(.*?)\s*$/){
						print "$line\n";	
						push(@multipleLines,$line);	 #used to check if constant is found more than once
					}							
				}
				#>>>>>>>>>>>>>> process enums <<<<<<<<<<<<<<<<<<
				elsif($par =~ m/te\_/i){ #if line has an enum parameter name, push the stored enum value
					push (@multipleLines,$parDetails{$foundFile}{$par}); #used to check if constant is found more than once
				}								
				#>>>>>>>>>>>>>> all other parameters <<<<<<<<<<<<<<<
				else{	
					push(@multipleLines,$line);	
				}																	
			}
			
			#>>>>>>>>>>>>>> handling for multiple occurences <<<<<<<<<<<<<<<<<<<
			
			my $lineCount= 1;
			if(scalar @multipleLines > 1){
				$observedLine = "Multiple Occurences found:\n";	
				$parData{$foundFile}{$par}{'verdict'} = 'FAIL'; #FAIL the test if multiple occurances are found
				foreach my $eachline(@multipleLines){
					#chomp($eachline);
					$observedLine = "$observedLine\n $lineCount. $eachline\n\r"; #print all found occurances in report
					$lineCount++;
				}				
			}
			else{
				$observedLine = $multipleLines[0];
			}
											
			#$parData{$foundFile}{$par}{'observedString'} = 				
		}
		return $observedLine;
		close TEMPREAD;
		undef @multipleLines;
}


sub evaluateParameters{ #evaluate every valid parameter found in the file
	
	my $foundFile = shift;
	my $par = shift;	
	my $constValue;
	my $secondFile;
	
	my $filename1 = "$foundFile($parDataFile{$foundFile}{'revision'})";
	my $filename2;
	$parData{$foundFile}{$par}{'fileName'} = $filename1;
	#>>>>>>>>>>>>>> check if parameter is found in file <<<<<<<<<<<<<<<<<<<
	unless(defined $parData{$foundFile}{$par}{'observedString'}){ #if parameter is not found in file		
		if(defined $parDataFile{$foundFile}{'secondFile'} and ($foundFile ne $parDataFile{$foundFile}{'secondFile'})){ #check if found in second file (if available)!!
			$secondFile = $parDataFile{$foundFile}{'secondFile'};
			$filename2 = "$secondFile($parDataFile{$secondFile}{'revision'})";
			$parData{$foundFile}{$par}{'observedString'} = $parData{$secondFile}{$par}{'observedString'};
			$parData{$foundFile}{$par}{'fileName'} = $filename2;
			undef $parData{$secondFile}; #remove 2nd file from hash
		}		
		unless(defined $parData{$foundFile}{$par}{'observedString'}){
			$parData{$foundFile}{$par}{'fileName'} = $filename1."\n$filename2" if (defined $secondFile);
			$parData{$foundFile}{$par}{'observedString'} = 'not found';	
			#$parData{$secondFile}{$par}{'observedString'} = 'not found' if (defined $secondFile);	
			$parData{$foundFile}{$par}{'observedValue'} = '-';
			$parData{$foundFile}{$par}{'verdict'} = 'NOT_FOUND';
			#$parData{$secondFile}{$par}{'verdict'} = 'NOT_FOUND' if (defined $secondFile);	
			#$parData{$foundFile}{$par}{'verdictColor'} = 'blue';
			#$notfoundCount++;
			return; #dont proceed
		}
	}

	#>>>>>>>>>>>>>> extract paramerter value from #define statement <<<<<<<<<<<<<<<<<<<
	if($parData{$foundFile}{$par}{'observedString'} =~ m/^(.*?)define\s*\Q$par\E\s*(.*?)\s*$/){ #define C_QualiTimeOutThdGroup1_U8X      (U8)25u
		$parData{$foundFile}{$par}{'observedValue'} = $2;
		#1st check if the observed matches with expected
		if((defined $parData{$foundFile}{$par}{'observedValue'} and ($parData{$foundFile}{$par}{'observedValue'} eq $parData{$foundFile}{$par}{'expected'})) or ($parData{$foundFile}{$par}{'observedString'} eq $parData{$foundFile}{$par}{'expected'})){
			$parData{$foundFile}{$par}{'verdict'} = 'PASS';
			return;
		}
		#extract only the value and remove all brackets
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(\s*\(U(.*?)\)\s*(.*?)\)$/){ #((U8)8) - remove ((U8) )
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(\s*\(S(.*?)\)\s*(.*?)\)$/){ #((S8)8) - remove ((S8) )
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(U(.*?)\)\s*\((.*?)\)$/){ #(U8)(25u) - remove all brackets
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(S(.*?)\)\s*\((.*?)\)$/){ #(S8)(25) - remove all brackets
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(U(.*?)\)\s*(.*?)$/){ #(U8)25u - remove (S8)
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\(S(.*?)\)\s*(.*?)$/){ #(S8)25 - remove (S8)
			$parData{$foundFile}{$par}{'observedValue'} = $2;
		}
		elsif($parData{$foundFile}{$par}{'observedValue'} =~ m/^\((.*?)\)$/){ #(8u) - remove ( )
			$parData{$foundFile}{$par}{'observedValue'} = $1;
		}
				
		if($parData{$foundFile}{$par}{'expected'} =~ m/^([0-9u]+)$|^-([0-9]+)$|^0x([0-9A-Fu]+)$|^\s*([0-9A-Fux]+)\s*-\s*([0-9A-Fux]+)\s*$/i and $parData{$foundFile}{$par}{'observedValue'} =~ m/^([0-9u]+)$|^-([0-9]+)$|^0x([0-9A-Fu]+)$|^\s*([0-9A-Fux]+)\s*-\s*([0-9A-Fux]+)\s*$/i){ #if it contains only digits or negative numbers or hex value or range e.g. 0-5
			#>>>>>>>>>>>>>> handling for constants <<<<<<<<<<<<<<<<<<<
			if($par =~ m/^C\_|^M\_|^Z\_/){	#handle constants, bit masks and macros			
				my $observed = $parData{$foundFile}{$par}{'observedValue'};
				my $expected = $parData{$foundFile}{$par}{'expected'};
				if($observed =~ m/^\s*(.*?)u\s*$/i){
					$observed = $1;
					$parData{$foundFile}{$par}{'observedValue'} = $1;
				}
				
				#range check for constants
				$expected =~ tr/ //ds; #1st remove all spaces
				$observed =~ tr/ //ds; #1st remove all spaces
				if($expected =~ m/^(.+?)-(.+?)$/i){ #if it is a range e.g. 0-5
					my $lowerLimit = $1;
					my $upperLimit = $2;
					$lowerLimit = hex($lowerLimit) if($lowerLimit =~ m/0x/i);
					$upperLimit = hex($upperLimit) if($upperLimit =~ m/0x/i);
					my $observed_hex = $observed;
					my $observed_hex = hex($observed) if($observed =~ m/0x/i);					
					if($observed_hex >= $lowerLimit and $observed_hex<= $upperLimit){
						$parData{$foundFile}{$par}{'verdict'} = 'PASS';
					}
					else{
						$parData{$foundFile}{$par}{'verdict'} = 'FAIL';
						push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to FAIL: Observed ($observed_hex) is not within range ($lowerLimit - $upperLimit)\n");
					}
				}
				else{ #normal
					if($expected =~ m/^\s*(.*?)u\s*$/i){
						$expected = $1;
					}
					my $observed_hex =$observed;
					my $expected_hex =$expected;
					$observed_hex = hex($observed) if ($observed =~ m/0x/i);
					$expected_hex = hex($expected) if ($expected =~ m/0x/i);					
					if($observed_hex == $expected_hex){ #for numeric entries
						$parData{$foundFile}{$par}{'verdict'} = 'PASS';
					}
					elsif($observed eq $expected){ #for strings
						$parData{$foundFile}{$par}{'verdict'} = 'PASS';
					}
					elsif($parData{$foundFile}{$par}{'expected'} eq 'not defined'){ #if expected value is not defined
						$parData{$foundFile}{$par}{'verdict'} = 'INCONC' ;
						push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: Expected value is not defined in SPS\n");
					}
					else{
						$parData{$foundFile}{$par}{'verdict'} = 'FAIL';
						push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to FAIL: Observed ($observed_hex) is different from expected data ($expected_hex)\n");
					}
				}				
			}	
		}
		elsif(defined $parData{$foundFile}{$par}{'observedValue'} and $parData{$foundFile}{$par}{'observedValue'} eq $parData{$foundFile}{$par}{'expected'}){
			$parData{$foundFile}{$par}{'verdict'} = 'PASS';
		}
		else{ #we can't evaluate
			$parData{$foundFile}{$par}{'verdict'} = 'INCONC';
			unless(defined $parData{$foundFile}{$par}{'observedValue'}){
				$parData{$foundFile}{$par}{'observedValue'} = '-';	#dummy value for printing to report			
			}
			unless($parData{$foundFile}{$par}{'observedValue'} !~ m/^\s*$/){
				$parData{$foundFile}{$par}{'observedValue'} = '-';	#dummy value for printing to report			
			}
			if($parData{$foundFile}{$par}{'expected'} eq 'not defined'){ #if expected value is not defined
				$parData{$foundFile}{$par}{'verdict'} = 'INCONC' ;
				push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: Expected value is not defined in SPS\n");
			}
			else{
				push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: expected value contains data other than numbers\n");
			}			
		}
	}
	#>>>>>>>>>>>>>> extract paramerter value from enum <<<<<<<<<<<<<<<<<<<
	elsif($parData{$foundFile}{$par}{'observedString'} =~ m/^(.*?)typedef enum\s*\{\s*(.*?)\s*\}/){ #typedef enum{....}
		$parData{$foundFile}{$par}{'observedValue'} = $2;
		$parData{$foundFile}{$par}{'observedValue'} =~ tr/ //ds; #1st remove all spaces
		$parData{$foundFile}{$par}{'observedValue'} =~ tr/,/ /; #replace ',' with space in observed string
		
		if($parData{$foundFile}{$par}{'expected'} =~ m/E_/i){
			$parData{$foundFile}{$par}{'expected'} =~ tr/\n//ds; #1st remove all newlines from expected string
			$parData{$foundFile}{$par}{'expected'} =~ tr/ //ds; #then remove all spaces from expected string
			$parData{$foundFile}{$par}{'expected'} =~ tr/,/ /; #replace ',' with space in expected string
		}
		
		if($parData{$foundFile}{$par}{'observedValue'} eq $parData{$foundFile}{$par}{'expected'}){
			$parData{$foundFile}{$par}{'verdict'} = 'PASS';
		}
		elsif($parData{$foundFile}{$par}{'expected'} eq 'not defined'){ #if expected value is not defined
			$parData{$foundFile}{$par}{'verdict'} = 'INCONC' ;
			push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: Expected value is not defined in SPS\n");
		}
		else{
			$parData{$foundFile}{$par}{'verdict'} = 'FAIL';
			push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to FAIL: Observed is different from expected data\n");
		}
	}
	#>>>>>>>>>>>>>> all other cases <<<<<<<<<<<<<<<<<<<
	else{
		if((defined $parData{$foundFile}{$par}{'observedValue'} and $parData{$foundFile}{$par}{'observedValue'} eq $parData{$foundFile}{$par}{'expected'}) or ($parData{$foundFile}{$par}{'observedString'} eq $parData{$foundFile}{$par}{'expected'})){
			$parData{$foundFile}{$par}{'verdict'} = 'PASS';
		}
		elsif($parData{$foundFile}{$par}{'expected'} eq 'not defined'){ #if expected value is not defined
			$parData{$foundFile}{$par}{'verdict'} = 'INCONC' ;
			push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: Expected value is not defined in SPS\n");
		}
		else{
			$parData{$foundFile}{$par}{'verdict'} = 'INCONC';
			push(@warning_messages,  "$parData{$foundFile}{$par}{'ID'} ($par) is set to INCONC: Observed is different from expected data\n");
		}
	}
	
	unless(defined $parData{$foundFile}{$par}{'observedValue'}){
		$parData{$foundFile}{$par}{'observedValue'} = '-';	#dummy value for printing to report			
	}

									
}


sub setVerdicts{
	
	my $foundFile = shift;
	my $par = shift;
	
	#>>>>>>>>>>>>>> Set the Verdict color and count <<<<<<<<<<<<<<<<<<<
	if($parData{$foundFile}{$par}{'verdict'} eq 'PASS'){
		$parData{$foundFile}{$par}{'verdictColor'} = 'green';
		$passCount++;
	}
	elsif($parData{$foundFile}{$par}{'verdict'} eq 'FAIL'){
		$parData{$foundFile}{$par}{'verdictColor'} = 'red';
		$failCount++;
	}
	elsif($parData{$foundFile}{$par}{'verdict'} eq 'INCONC'){
		$parData{$foundFile}{$par}{'verdictColor'} = 'purple';
		$inconcCount++;
	}
	elsif($parData{$foundFile}{$par}{'verdict'} eq 'NOT_FOUND'){
		$parData{$foundFile}{$par}{'verdictColor'} = 'blue';
		$notfoundCount++;
	}
	else{ #if no verdict has been set, set it to NONE (i.e. no evaluation was done)
		$parData{$foundFile}{$par}{'verdict'} = 'NONE';
		$parData{$foundFile}{$par}{'verdictColor'} = 'blue';
		$noneCount++;
	}
}


sub htmlMultipleFiles{
		
	my $totalVerdictCount = $passCount+$failCount+$inconcCount+$notfoundCount;
	
	
	my $passPercentage = sprintf("%.1f",$globalVerdicts{'totalPass'}/$globalVerdicts{'totalAll'}*100) if ($globalVerdicts{'totalAll'} > 0);
	my $failPercentage = sprintf("%.1f",$globalVerdicts{'totalFail'}/$globalVerdicts{'totalAll'}*100) if ($globalVerdicts{'totalAll'} > 0);
	my $inconcPercentage = sprintf("%.1f",$globalVerdicts{'totalInconc'}/$globalVerdicts{'totalAll'}*100) if ($globalVerdicts{'totalAll'} > 0);
	my $notfoundPercentage = sprintf("%.1f",$globalVerdicts{'totalNotFound'}/$globalVerdicts{'totalAll'}*100) if ($globalVerdicts{'totalAll'} > 0);
	my $allPercentage = sprintf("%.1f",$globalVerdicts{'totalAll'}/$globalVerdicts{'totalAll'}*100) if ($globalVerdicts{'totalAll'} > 0);
	
	open (SUMMARYHTMLFILE,">$allReportsPath"."/Summary_report_$tcTime.html") || die("$allReportsPath"."/Summary_report_$tcTime.html could not be created!\n");  
	
	my $html_report_info= <<EOHTML;
		<TABLE><TR>
			<BR>&nbsp;<BR>
		</TR></TABLE> 
		<div id="content"><a name="Top" id="Top"></a>		
		<TABLE width="100%"><TR>
		    <div style="font-family:Arial; color:black; font-size:22; font-weight:bold; text-align:center">Summary</div>
		    <div style="font-family:Arial; color:grey; font-size:18; font-weight:bold; text-align:center">Summary of the Software Parameter Specification tests</div>
		</TR></TABLE>
		</div>

		<HR>
		<TABLE align = "left"><TR>
		    <TH><div style="font-family:Arial; color:black; font-size:18; font-weight:normal; text-align:left">Summary</div></TH>
		</TR></TABLE>
		<TABLE align = "right"><TR>
			<TH><div style="font-family:Arial; color:black; font-size:18; font-weight:normal; text-align:right">Evaluation</div></TH>
		</TR></TABLE>
		
	<TABLE><TR>
		<div style="font-family:Arial; color:white; font-size:14; font-weight:normal">&nbsp;</div>
		<div style="font-family:Arial; color:white; font-size:14; font-weight:normal">&nbsp;</div>
	</TR></TABLE>
			
		
		<!-- CSS goes in the document HEAD or added to your external stylesheet -->
<style type="text/css">
table.gridtable {
	font-family: segoe UI,verdana,arial,sans-serif;
	font-size:11.5px;
	color:#333333;
	border-width: 2px;
	border-color: #666666;
	border-collapse: collapse;
}
table.gridtable th {
	border-width: 2px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #D4E5F7; #light blue
}
table.gridtable td {
	border-width: 2px;
	padding: 8px;
	border-style: solid;
	border-color: #666666;
	background-color: #ffffff;
}
</style>
<!-- Table goes in the document BODY -->
<table class="gridtable"; align = "left">	
		<TR ALIGN="LEFT">
            <TH>SPS Directory</TH>
            <TD>$Excelsheets_Path</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Sandbox directory</TH>
            <TD>$SandboxFile_Path</TH>
        </TR>        
        <TR ALIGN="LEFT">
            <TH>Date/Time</TH>
            <TD>$start_date $start_time</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Execution Duration</TH>
            <TD>$executionMin min $executionSec sec</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Generated by</TH>
            <TD>$username</TH>
        </TR>
        <TR ALIGN="LEFT">
            <TH>Reports folder</TH>
            <TD><A HREF="file:///$allReportsPath" TYPE="text/pm">./reports_$tcTime/</A></TH>
        </TR>
     </TABLE>
       
<table class="gridtable"; align = "right">	
		<TR ALIGN="LEFT">
            <TH>VERDICT</TH>
            <TH>Number of tests</TH>
        </TR>
		<TR ALIGN="LEFT">
            <TH>PASS</TH>
            <TD><span style="color:green">$globalVerdicts{'totalPass'} ($passPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>FAIL</TH>
            <TD><span style="color:red">$globalVerdicts{'totalFail'} ($failPercentage%)</span></TD>
        </TR>        
        <TR ALIGN="LEFT">
            <TH>INCONC</TH>
            <TD><span style="color:purple">$globalVerdicts{'totalInconc'} ($inconcPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>NOT_FOUND</TH>
            <TD><span style="color:blue">$globalVerdicts{'totalNotFound'} ($notfoundPercentage%)</span></TD>
        </TR>
        <TR ALIGN="LEFT">
            <TH>TOTAL</TH>
            <TD><span style="color:black">$globalVerdicts{'totalAll'} ($allPercentage%)</span></TD>
        </TR>
	</TABLE>
	        
	<TABLE><TR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
		<BR>&nbsp;<BR>
	</TR></TABLE> 
		
	<TABLE><TR>
		<div style="font-family:Arial; color:white; font-size:18; font-weight:bold">&nbsp;</div>
		<div style="font-family:Arial; color:white; font-size:18; font-weight:bold">&nbsp;</div>		
		<div style="font-family:Arial; color:black; font-size:22; font-weight:bold; text-align:left">ExecutionList</div>
		<div style="font-family:Arial; color:white; font-size:18; font-weight:bold">&nbsp;</div>
	</TR></TABLE>

EOHTML
		
		print SUMMARYHTMLFILE $html_report_info;			
			
			my $filetext = <<EOHTML;	    	
		
<!-- Table goes in the document BODY -->
<table class="gridtable">
			
		<TR ALIGN="LEFT" bgcolor = grey; border:1px solid green;>
            <TH WIDTH="5%">S.No</TH>
            <TH WIDTH="25%">File</TH>
            <TH WIDTH="7%">PASS</TH>
            <TH WIDTH="7%">FAIL</TH>
            <TH WIDTH="7%">INCONC</TH>
            <TH WIDTH="7%">NOT_FOUND</TH>
            <TH WIDTH="7%">TOTAL</TH>
            <TH WIDTH="15%">Error Log</TH>
        </TR>        
EOHTML
			print SUMMARYHTMLFILE $filetext;

			my $Sno=0;
			foreach my $file (sort keys %excelFile){
				$Sno++;	
				chomp($file);					
				my $fileinfo= <<EOHTML;
		<TR ALIGN="LEFT" bgcolor = silver>
            <TD WIDTH="5%">$Sno</TD>
            <TD WIDTH="25%"><A HREF="file:///$excelFile{$file}{'path'}" TYPE="text/pm">$file</A></TD>
            <TD WIDTH="7%"><span style="color:green">$excelFile{$file}{'PASS'}</span></TD>
            <TD WIDTH="7%"><span style="color:red">$excelFile{$file}{'FAIL'}</span></TD>
            <TD WIDTH="7%"><span style="color:purple">$excelFile{$file}{'INCONC'}</span></TD>
            <TD WIDTH="7%"><span style="color:blue">$excelFile{$file}{'NOT_FOUND'}</span></TD>
            <TD WIDTH="7%"><span style="color:black">$excelFile{$file}{'TOTAL'}</span></TD>
            <TD WIDTH="15%"><A HREF="file:///$excelFile{$file}{'logPath'}" TYPE="text/pm">error log</A></TD>
		</TR>							
EOHTML
				
				print SUMMARYHTMLFILE $fileinfo;			
			}	
										
		my $endtable = <<EOHTML;					
			</TABLE>
			<TABLE><TR>
				<BR>&nbsp;<BR>
			</TR></TABLE>
			<HR>
	        
	        <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
	        <div style="font-family:Segoe UI; color:grey; font-size:18; font-weight:normal; text-align:left">Remarks:</div>
	        <div style="font-family:Segoe UI; color:black; font-size:14; font-weight:normal; text-align:left">NOT_FOUND - The parameter mentioned in the SPS is not found in the corresponding parameter file (or) the file is not found in the sandbox directory. </div>
	        <div style="font-family:Segoe UI; color:black; font-size:14; font-weight:normal; text-align:left">INCONC - Verdict of the test case is inconclusive. Manual verificaion is required. </div>	        
	        <div style="font-family:Arial; color:white; font-size:18; font-weight:bold; text-align:left">&nbsp;</div>
EOHTML
		print SUMMARYHTMLFILE $endtable;

		close IMPORTFILE;	
		close SUMMARYHTMLFILE;	
		
		
		if (-e 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe'){
	    	# workaround with 'CMD' because just calling 'start' causes MKS error 'wrong OS' (there is a start.exe in MKS subfolder)
	        system('CMD /C start "C:\Program Files (x86)\Mozilla Firefox\firefox.exe" file:///'.$allReportsPath."/Summary_report_$tcTime.html"); # open in Firefox Win7 
	    }
	    elsif (-e 'C:\Program Files\Mozilla Firefox\firefox.exe'){
	        system('start "C:\Program Files\Mozilla Firefox\firefox.exe" file:///'.$allReportsPath."/Summary_report_$tcTime.html"); # open in Firefox
	    }
	    else{
	        print(" could not open Firefox to display report\n"); 
	    }

}


sub S_formated_timestamp {
  my $mytime = shift;
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst);
  
  if (defined $mytime) {
     ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($mytime);
  }
  else {
     ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time());
  }
    
  return ( sprintf("%02d.%02d.%04d", $mday, $mon+1, $year+1900 ), sprintf("%02d:%02d:%02d", $hour, $min, $sec) );
  
}


__END__
