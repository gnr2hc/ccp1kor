#ifndef Y_sem_smr_sensormanagerH
#define Y_sem_smr_sensormanagerH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "spi_spi_spidriver.h" 
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define Z_BETWEEN(x, min, max) ( ((x) >= (min)) AND_THEN ((x) <= (max)) )
#define Z_ExtractSensorData(x) (((S16)((x) << 6u)) >> 6u)
#define C_MaxValidSensorValue_S16X 480   
#define C_MinValidSensorValue_S16X -480  
#define M_FltSemAddSensorChannel_U8X    0x01u   
#define M_FltSemInvalidPasType_U8X      0x02u   
#define M_FltSemInvalidCsType_U8X       0x04u   
#define M_FltSemPasIfLineMapping_U8X    0x08u   
#define M_FltSemOutOfPasSpecificRam_U8X 0x10u   
typedef enum
{
   E_SEMBGExecutionPart1,
   E_SEMBGExecutionPart2,
   E_SEMBGExecutionPart3
} te_SEMBGExecutionPart;
typedef enum
{
   E_SMRSensorOK,
   E_SMRSensorSwitchedOff,
   E_SMRSensorInitializing1,
   E_SMRSensorInitializing2,
   E_SMRSensorInitializing3,
   E_SMRSensorInitializingDone,
   E_SMRSensorInitializingError,
   E_SMRSensorError,
   E_SMRSensorErrorAndOff,
   E_SMRSensorDead,
   E_SMRNoSensorConfigured,
   E_SMRSensorOptionTest,
   E_SMRSensorMonitoringOff
} te_SensorStateList;
typedef enum
{
   E_SMRInit,
   E_SMRIdleMode,
   E_SMRConfiguringCS,
   E_SMRConfiguringPES,
   E_SMRConfiguringCust,
   E_SMRStartRtReading,
   E_SMRStartUp,
   E_SMRSteadyState
} te_SensorMgrStateList;
typedef void (*tp_SensorSpecificFunction) (U16, U8, U8);
void SMR_Init( void );
void SMR_ReadSensorsFIQ( void );
void SMR_Background2ms( void );
void SMR_Background10msInitAndCS( void );
void SMR_Background10msPES(te_SEMBGExecutionPart e_bgexecpart_xxr );
void SMR_Background100ms( void );
void SMR_BeginSensorInitialisation( void );
void SMR_EnableDataPassing( void );
void SMR_SetDCInitPulseMaskFIQ( void );
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void SMR_CheckSignalPlausibility(S16 v_sensordata_s16r, S16 * p_counter_s16r, S16 v_signalThreshold_s16r, te_Boolean e_dataValid_xxr );
void SMR_ChkSignalPlausiSteps(S16 v_sensordata_s16r, S16 * p_counter_s16r, U16 v_signalThreshold_u16r, U8 v_Step_u8r, te_Boolean e_dataValid_xxr );
void SMR_AddSensorChannel(U16 v_spicommand_u16r, te_SpiDeviceList e_spidevice_xxr, U8 v_sensor_u8r, U8 v_channel_u8r, tp_SensorSpecificFunction p_realtimeeval_xfr );
void SMR_DisableChannelEvaluation(te_SpiDeviceList e_SPIDevice_xxr, U8 v_channel_u8r );
void SMR_SensorCfgError(U8 v_faultDetails_u8r );
void SMR_NoOperationFIQ(U16 v_RawData_u16r, U8 v_SensorIndex_u8r, U8 v_ChannelIndex_u8r );
#endif
#endif
