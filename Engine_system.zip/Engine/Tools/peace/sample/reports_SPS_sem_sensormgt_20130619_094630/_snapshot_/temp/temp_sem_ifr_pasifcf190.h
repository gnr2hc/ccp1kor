#ifndef Y_sem_ifr_pasifcf190H
#define Y_sem_ifr_pasifcf190H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define Y_Feature_sem_ifr_Initial4MHzEClkMonTest
#define C_FirstCf190AsicPos_U8X ((U8)(E_MaxSystemAsics + E_MaxCg974Asics))
#define C_Cf190MaxPasSamples_U8X             ((U8)8)
#define C_Cf190NumberOfPasLines_U8X          ((U8)2)
#define C_Cf190MaxSupportedCF190_U8X         0x4u
#define M_Cf190Lines_U16X                     0x0003u
#define C_Cf190ReadDIA1_U16X                  0x6100u
#define C_Cf190ReadPasCommand_U16X            0x8000u
#define C_Cf190SelectPasCommand_U16X          0xC200u
#define C_Cf190ReadSupply_U16X                0x1000u
#define C_Cf190SwitchSupply_U16X              0x1300u  
#define C_Cf190ProgSID_U16X                   0x7600u  
#define C_Cf190ReadSID_U16X                   0x7500u  
#define C_Cf190ProgPsiMode_U16X               0x5800u  
#define C_Cf190ReadPsiMode_U16X               0x5000u  
#define C_Cf190ProgSyncMode_U16X              0x7300u 
#define C_Cf190ReadSyncMode_U16X              0x7000u 
#define C_Cf190SyncMode_U8X                   0x00u
#define C_Cf190SetSyncMask_U16X               0xF700u 
#define C_Cf190ReadSyncMask_U16X              0xF400u 
#define C_Cf190SetSyncTime_U16X               0x2800u
#define C_Cf190ReadSyncTime_U16X              0x3000u
#define C_Cf190ProgTSyncLine1_U16X            0x0100u
#define C_Cf190ProgTSyncLine2_U16X            0x0200u
#define C_Cf190SyncTime_U8X                   0x1Fu
#define C_Cf190SyncGen_U16X                   0xF800u 
#define C_Cf190ProgConfig_U16X               0x6E00u  
#define C_Cf190ReadConfig_U16X               0x6D00u  
#define C_Cf190ConfigModeNoDC_U8X              0x05u      
#define C_Cf190ConfigModeDC_U8X                0x07u      
#define C_Cf190Shift2DataRegPos_U8X           4u   
#define C_Cf190Shift2LinePos_U8X              6u   
#define M_Cf190EopAndSIDBits_U8X                (U8)0x3C
#define M_ProgPESLineFault_U8X                  (U8)0x01
#define M_ProgPSISyncModeFault_U8X              (U8)0x02
#define M_ProgSIDFault_U8X                      (U8)0x04
#define M_ProgConfigFault_U8X                   (U8)0x08
typedef struct
   {
   tp_SensorSpecificFunction P_PasSpecificFIQFp_XFX;
   U16                       V_ReadCommand_U16X;
   U8                        V_SensorIndex_U8X;
   U8                        V_ChannelIndex_U8X;
   } ts_PasifCf190SetupData;
typedef enum
{
   E_IFRSetEclkTestExecutionState,
   E_IFRInitStaticData,
   E_IFRInitSMR,
   E_IFRCalculatePASLineSettings,
   E_IFRProgramPASLines,
   E_IFRInitSID,
   E_IFRInitSyncMode,
   E_IFRInitSpecialParameters,
   E_IFRInitEopAndFaultHandling,
   E_IFRInitCheckNextCf190,
   E_IFRInitFinished
}te_IFRInitStates;
typedef enum
{
   E_CF190PASLineReg1,
   E_CF190PASLineReg2,
   E_CF190PASLineReg3,
   E_CF190PASLineReg4,
   E_MaxCF190PASLineRegs
}te_CF190PASLineRegs;
void IFR_Initial4MHzEClkMonTest( void );
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
te_Complete IFR_Init( void );
void IFR_MakeLineMeasurement( void );
void IFR_MakeLineSwitching( void );
void IFR_DisableSensorsOnAsic(te_Cf190AsicList e_cf190Asic_xxr );
te_Boolean IFR_IsLineConnectedToCf190(te_PasLineList e_line_xxr );
te_AsicList IFR_GetFirstCf190InAsicList( void );
#endif
#endif
