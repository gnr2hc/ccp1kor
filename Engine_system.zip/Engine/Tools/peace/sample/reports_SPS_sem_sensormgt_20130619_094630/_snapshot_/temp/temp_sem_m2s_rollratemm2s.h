#ifndef Y_sem_m2s_rollratemm2sH
#define Y_sem_m2s_rollratemm2sH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
          /* debug information activated */
#undef Y_SMG100DbgInfo                 
   /* control error test cases activated */
#undef Y_SMG100ErrorTestCases          
#define C_MM2SResetDelay_U8X                   10u    
#define C_MM2SRawOffsetDelay_U16X              500u   
#define C_MM2SOffsetThreshold_U16X            0x32u   
#define C_MM2SOffsetDelayFirst_U16X            500u   
#define C_MM2SOffsetDelayRetry_U16X            200u   
#define C_MM2SDelayAfterReset_U16X           150u     
#define C_MM2SDelayAfterFOC_U16X             300u     
#define C_MM2SBiteDelay_U16X                  60u     
#define C_MM2SBiteOffDelay_U16X               70u     
#define C_MM2SBiteMaxThreshold_S16X           460u    
#define C_MM2SEOPDelay_U16X                   100u    
#define C_MM2SSPIReadSensorData_U16X          0x8000u  
#define C_MM2SSPISoftReset_U16X               0x4a00u  
#define C_MM2SReadSensorConfig_U16X           0x7500u  
#define C_MM2SSPIReadDeviceID_U16X            0x0100u  
#define C_MM2SSPIReadMonitorData1_U16X        0x3b00u  
#define C_MM2SSPIReadMonitorData2_U16X        0x3d00u  
#define C_MM2SSPIReadMonitorData3_U16X        0x3e00u  
#define C_MM2SSPIWrEOP_U16X                   0x0d00u  
#define C_MM2SSPIDemandBitePos_U16X           0x3801u  
#define C_MM2SSPIDemandBiteNeg_U16X           0x3802u  
#define C_MM2SSPIDemandBiteOFF_U16X           0x3800u  
#define C_MM2SSPIReadPartId1_U16X             0x5E00u  
#define C_MM2SSPIReadPartId2_U16X             0x5d00u  
#define C_MM2SSPIReadPartId3_U16X             0x5B00u  
#define C_MM2SSPIReadPartId4_U16X             0x5800u  
#define C_MM2SSPIReadPartId5_U16X             0x5700u  
#define C_MM2SSPIReadPartId6_U16X             0x5400u  
#define C_MM2SSPIOffsetCancellationON_U16X    0x7901u  
#define C_MM2SSPIOffsetCancellationOFF_U16X   0x7900u  
#define C_MM2SSPIReadOffsetCancellation_U16X  0x7A00u  
#define C_MM2SSPIEOPCommand_U16X              0x0D00u  
#define C_MM2SResetResponse_U16X              0xFFFF   
#define C_MM2SDeviceID_U8X                    0x97u   
#define C_MM2SDeviceIDRsp_U16X                0x3097u 
#define C_MM2SPartIdLengt_U8X                 0x06u   
#define M_MM2SSPIOffsetCancellationFast_U8X     0x03u    
#define M_MM2SSPIOffsetStatusAfterEOP_U16X      0x1002u  
#define M_MM2SSPIOffsetCancellationOff_U8X      0x00u    
#define M_MM2SSPIMoni1ADCrat_U8X                0x04u    
#define M_MM2SCsStatusInfoNRO_U8X            0x01u 
#define M_MM2SCsStatusInfoTST_U8X            0x02u 
#define M_MM2SCsStatusInfoMonitorData12_U8X  0x04u 
#define M_MM2SCsStatusInfoADCratFlt_U8X      0x08u 
#define M_MM2SCsStatusInfoIntrnFlt_U8X       0x10u 
#define M_MM2SSWResetFailed_U8X         0x01u
#define M_MM2SWrongDeviceID_U8X         0x02u
#define M_MM2SWrongSensorConfig_U8X     0x04u
#define M_MM2SMonitoringDataFault_U8X   0x08u
#define M_MM2SWrongSensorType_U8X       0x10u
#ifdef Y_SMG100ErrorTestCases
#define M_MM2SDbgCtrlA1_U16X         0x0001u 
#define M_MM2SDbgCtrlA2_U16X         0x0002u 
#define M_MM2SDbgCtrlA3_U16X         0x0004u 
#define M_MM2SDbgCtrlA4_U16X         0x0008u 
#define M_MM2SDbgCtrlA5_U16X         0x0010u 
#define M_MM2SDbgCtrlA6_U16X         0x0020u 
#define M_MM2SDbgCtrlB1_U16X         0x0040u 
#define M_MM2SDbgCtrlB2_U16X         0x0080u 
#define M_MM2SDbgCtrlB3_U16X         0x0100u 
#define M_MM2SDbgCtrlB4_U16X         0x0200u 
#define M_MM2SDbgCtrlB5_U16X         0x0400u 
#define M_MM2SDbgCtrlB6_U16X         0x0800u 
#define M_MM2SDbgCtrlC1_U16X         0x2000u 
#define M_MM2SDbgCtrlD1_U16X         0x4000u 
#define M_MM2SDbgCtrlE1_U16X         0x8000u 
#define M_MM2SDbgCtrlE2_U16X         0x0001u 
#define M_MM2SDbgCtrlF1_U16X         0x0002u 
#define M_MM2SDbgCtrlB61_U16X        0x0004u 
#define M_MM2SDbgCtrlG1_U16X         0x0008u 
#define M_MM2SDbgCtrlG2_U16X         0x0010u 
#define M_MM2SDbgCtrlB51_U16X        0x0040u 
#define M_MM2SDbgCtrlB62_U16X        0x0080u 
#define M_MM2SDbgCtrlG1dequal_U16X   0x0400u 
#endif
#define M_MM2SRepB1_U8X              0x01u 
#define M_MM2SRepB2_U8X              0x02u 
#define M_MM2SRepB3_U8X              0x04u 
#define M_MM2SRepB4_U8X              0x08u 
#define M_OfdgBitsExlNRO_U8X 0xdcu           
#define C_MM2SALLBitsSet_U8X                   0xFFu    
typedef enum          
{                             
  E_MM2SNotConfigured         ,
  E_MM2SSensorDisabled        ,
  E_MM2SInitPart1             ,
  E_MM2SInitPart2             ,
  E_MM2SSteadyState1          ,
  E_MM2SSteadyState2          ,
  E_MM2SSteadyState3          
} te_MM2SStatus;              
typedef enum
{                                 
  E_MM2SStartupTest               ,
  E_MM2SStartupTestPart2          ,
  E_MM2SReadConfig                ,
  E_MM2SReadMonitoringData        ,
  E_MM2SInitResetTestDelay        ,
  E_MM2SInitResetTestEval         ,
  E_MM2SInitReadPartID            ,
  E_MM2SInitRawOffsetDelay        ,
  E_MM2SInitRawOffsetMeasurement  ,
  E_MM2SInitFastOffsetStart       ,
  E_MM2SInitFastOffsetDelay       ,
  E_MM2SInitFastOffsetEval        
} te_MM2SInitPart1;               
typedef enum
{                                 
  E_MM2SInitBite1Start            ,
  E_MM2SInitBite1Delay            ,
  E_MM2SInitBiteSwitch            ,
  E_MM2SInitBite2Delay            ,
  E_MM2SInitBiteEval              ,
  E_MM2SInitBiteSendOff           ,
  E_MM2SInitBiteCheckOff          ,
  E_MM2SInitProgramSensor         ,
  E_MM2SInitCompleteInit          
} te_MM2SInitPart2;               
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 M2S_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void M2S_BackgroundMonitoring10ms( void );
void M2S_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
#endif
#endif
