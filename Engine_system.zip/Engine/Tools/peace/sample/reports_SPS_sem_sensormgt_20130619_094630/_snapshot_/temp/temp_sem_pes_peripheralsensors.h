#ifndef Y_sem_pes_peripheralsensorsH
#define Y_sem_pes_peripheralsensorsH
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "pdm_syssettingspar.p" 
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PESInitLineCheckAttempts_U8X          4u
#define C_PESInvalidData_S16X                   0x7FFF
#define C_PESExpSPIBits_U8X                     0u
#define C_OptionTestCommFltThd_U8X              3u
#define C_ERThresholdVsyncLow_U16X              ((U16)1300u)   
#define C_PSIManchesterErrorMsg_S16X            0x01FC
#define C_PSIParityErrorMsg_S16X                0x01F8
#define C_PSISyncPulseVoltageTooLowMsg_S16X     0x01F6
#define C_PSISensorDefectiveMsg_S16X            0x01F4
#define C_PSIBufferEmptyMsg_S16X                0x01F0
#define C_PSISensorBusyMsg_S16X                 0x01E8
#define C_PSISensorOkMsg_S16X                   0x01E7
#define C_PSISensorUnlockedMsg_S16X             0x01E6
#define C_PSIOnlyBit1LockedMsg_S16X             0x01E5
#define C_PSIBidiCommCodeErrorMsg_S16X          0x01E2
#define C_PSIBidiCommCodeOkMsg_S16X             0x01E1
#define C_PSIMaxStatusDatum_S16X                -481
#define C_PSIMinStatusDatum_S16X                -496
#define C_PSIMaxIdentCode_S16X                  -497
#define C_PSIMinIdentCode_S16X                  -512
#define C_PSIStatusDataOffset_S16X              496
#define C_PSIIdentCodeOffset_S16X               512
#define C_PESSafetyIDReadCommandLocation_U8X    2u
#define M_PESSafetyID_U8X                       0x1Cu 
#define M_PESSPIStatusBitsAndSID_U8X            0x7Cu 
#define M_PESSyncPulseVoltageTooLow_U8X                 0x01u  
#define M_PESVerLow_U8X                                 0x80u  
#define M_PESExternalCommBufferEmpty_U8X                0x01u 
#define M_PESExternalCommParityError_U8X                0x02u 
#define M_PESExternalCommManchesterError_U8X            0x04u 
#define M_PESExternalCommUnexpectedDataError_U8X        0x08u 
#define M_PESExternalCommInitTimeOut_U8X                0x10u 
#define M_PESInitFaultTimeout_U8X       0x01u 
#define M_PESInitFaultTransmission_U8X  0x02u 
#define M_PESInitFaultType_U8X          0x04u 
#define M_PESInitFaultSubtype_U8X       0x08u 
#define M_PESInitFaultProject_U8X       0x10u 
#define M_PESInitFaultSpecific_U8X      0x20u 
#define M_PESPlausiAlgoFront_U8X 	0x04u	
#define M_PESPlausiAlgoRear_U8X 	0x08u	
#define M_PESPlausiAlgo_U8X 		0x10u	
#define M_PESPlausiCSABS_U8X 		0x20u	
#define M_PESDefectError_U8X                            0x80u
#define M_PESFltInfoRcvd_U8X                            0x40u
typedef enum
{
   E_PesBgState1,
   E_PesBgState2,
   E_PesBgState3
} te_PesBgStates;
typedef void (*tp_PesSpecificBgFunction) (U8, te_PesBgStates);
typedef struct
{
  U16 F_MeasuredStatus_U16X      ;    
  U16 F_ExpectedStatus_U16X      ;    
  U16 F_RequestedStatus_U16X     ;    
  U16 F_UsedPESLines_U16X        ;  
} ts_PesLineData;
typedef struct
{
  U32 F_DataValid_U32X           ;    
typedef struct
{
  void* A_SensorSpecificData_XPX [E_MaxPeripheralSensors] ;    
  U32 A_StatusMsgRvdINTW_U32X [E_MaxPeripheralSensors] ;    
  S16 A_PlausiCounter_S16X [E_MaxPeripheralSensors] ;    
  U8 A_PESRTDefectFltINTW_U8X [E_MaxPeripheralSensors] ;    
  U8 A_PESRTExtCommFltINTW_U8X [E_MaxPeripheralSensors] ;    
  U8 A_PESRTIntCommFltINTW_U8X [E_MaxPeripheralSensors] ;    
  U16 A_PESInitOneTimeout_U16X [E_MaxPeripheralSensors] ;    
  U16 A_PESInitTimeout_U16X [E_MaxPeripheralSensors] ;    
  U8 A_MessageIndexINTW_U8X [E_MaxPeripheralSensors] ;    
  U8 A_ExpSPIBits_U8X [E_MaxPeripheralSensors] ;    
  U8 V_CheckedSPIBits_U8X        ;    
  U8 A_NumberOfSamples_U8X [E_MaxPeripheralSensors] ;    
  U8 A_RebootCounter_U8X [E_MaxPeripheralSensors] ;    
  U8 A_OptionTestCounter_U8X [E_MaxPeripheralSensors] ;    
  te_SensorStateList A_SensorStateINTW_XEX [E_MaxPeripheralSensors] ;    
  te_SpiDeviceList A_SPIDevice_XEX [E_MaxPeripheralSensors] ;    
  tp_PesSpecificBgFunction A_PESSpecificBgFP_XFX [E_MaxPeripheralSensors] ;    
  U8 A_OptnTestComFltCntINTW_U8X [E_MaxPeripheralSensors] ;    
  U32 F_OptionTestFailedINTW_U32X ;  
} ts_PesInternalData;
 typedef enum
 {                         
  E_PasIfShortToBatCheck,      
  E_PasIfCrossCouplingTest,    
  E_PasIfWaitForERTest,        
  E_PasIfEvalERCondition,      
  E_PasStartup,                
  E_PasStartupCompleted        
 } te_PASIFInitialisationStateList;  
typedef enum
{
   E_PesNoChange,
   E_PesPowerOn,
   E_PesPowerOff
} te_PesDesiredPowerState;
typedef enum
{
   E_PesInitSissi,
   E_PesInitSaphir,
   E_PesInitCf190,
   E_PesInitCG974,
   E_PesInitFinish,
   E_PesInitDone
} te_PesInit2State;
void PES_PowerPeripheralSensors(te_Boolean e_powerOn_xxr );
void PES_DisablePeripheralSensor(te_PeripheralSensorList e_sensor_xxr );
te_PASTypeList PES_GetPasTypeALL(te_PeripheralSensorList e_sensor_xxr );
te_SensorStateList PES_ReadPESStatusALL(te_PeripheralSensorList e_sensor_xxr );
const void* PES_AccessPesInitData(te_PeripheralSensorList e_sensor_xxr );
void PES_ReportSignalPlausiFault(te_PeripheralSensorList e_sensor_xxr, U8 v_detailedFaultInfo_u8r );
#define Z_IsPESDataValid(x) ( (te_Boolean) Z_BitIsSet(S_PesSensorDataINTW_XXR.F_DataValid_U32X, Z_GetBitMask(x) ))
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void PES_ClearSensorDataOutputFIQ( void );
void PES_Init1( void );
te_Boolean PES_Init2( void );
void PES_BackGroundMonitoring10ms(te_SEMBGExecutionPart e_bgexecpart_xxr );
void PES_SetPeripheralSensorState(U8 v_sensor_u8r, te_SensorStateList e_state_xxr );
void* PES_AllocateSensorSpecificRam(U16 v_bytes_u16r );
void PES_CheckRTDefectFaults(U8 v_sensor_u8r );
void PES_CheckRTInternalCommFaults(U8 v_sensor_u8r );
void PES_CheckRTExternalCommFaults(U8 v_sensor_u8r );
void PES_SetInitialState(U8 v_sensor_u8r );
void PES_CallSensorSpecificInit(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pesFirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pesSecondSampleFIQFp_xfr );
void PES_HandleVSyncLowMsgFIQ(U8 v_sensor_u8r );
void PES_HandleExtCommMsgFIQ(U8 v_sensor_u8r );
te_Boolean PES_IsPermanentFltPresent(U8 v_sensor_u8r );
#endif
#endif
