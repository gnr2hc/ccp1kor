#ifndef Y_sem_pp2_pps2H
#define Y_sem_pp2_pps2H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PPS2INIT1Timeout_U16X             98u      
#define C_PPS2StartupTimeout_U16X           500u     
#define C_PPS3INIT1Timeout_U16X             225u     
#define C_PPS3StartupTimeout_U16X           615u     
#define C_PPS2SerialNumberLength_U8X        6u     
#define C_PPS2StatusMessageLength_U8X       16u    
#define C_PPS2PesIfSettings_U8X             0x0Bu     
#define C_PPS2MinValidSensorValue_S16X      -102
#define C_PPS2MaxValidSensorValue_S16X      307
#define C_PPS2FirstPageComplete_U32X        0x0000FFFFu   
#define C_PPS2StatusMessagesComplete_U32X   0xFFFFFFFFu   
#define C_PPS2IndexSecondPage_U8X           16u           
#define C_PPS2AbsPressureIDMask_U16X        0x0018u     
#define C_PPS2AbsPressureValueMask_U16X     0x0007u     
#define C_PPS2AbsPressureID1_U16X           0x0000u     
#define C_PPS2AbsPressureID2_U16X           0x0008u     
#define C_PPS2AbsPressureID3_U16X           0x0010u     
#define C_PPS2AbsPressureID4_U16X           0x0018u     
#define C_PPS2ShiftAbsPressPart1_U8X        0x09u
#define C_PPS2ShiftAbsPressPart2_U8X        0x06u
#define C_PPS2ShiftAbsPressPart3_U8X        0x03u
#define C_PPS2ShiftAbsPressPart4_U8X        0x00u
#define C_PPS2SignalPlausiThreshold_U16X     16u     
#define C_PPS2RelPressureReceived_U8X       0x01u
#define C_PPS2AbsPressureReceived_U8X       0x02u
#define C_PPS2BothPressureReceived_U8X      0x03u
#define C_PPS2MaxMissingAbsMessages_U8X     20u
#define C_PPS2SdProtocolA_U8X               0x42u       
#define C_PPS2SdProtocolB_U8X               0x00u       
#define C_PPS2ManuBoschBIT_U8X              0x10u
#define C_PPS2ManuVdoBIT_U8X                0x20u
#define C_PPS2ManuAutolivBIT_U8X            0x40u
#define C_PPS2ManuTemicBIT_U8X              0x80u
#define C_PPS2ManuBoschASCII_U8X            0x42u
#define C_PPS2ManuAutolivASCII_U8X          0x41u
#define C_PPS2ManuTemicASCII_U8X            0x43u
#define C_PPS2ManuTrwASCII_U8X              0x54u
#define C_PPS2SdSensorTypeA_U8X             0x00u
#define C_PPS2SdSensorTypeB_U8X             0x08u
#define C_PPS2AbsDefaultValue_U16X              0xFFFFu   
#define C_PPS2AbsMinimumThresh_U16X             0x0006u   
#define C_PPS2AbsMaximumThresh_U16X             0x0D47u   
#define C_PPS2AbsDeltaThresh_U16X               0x01AEu   
#define M_PPS2MinimumAbsPressureFlt_U8X         0x01u
#define M_PPS2MaximumAbsPressureFlt_U8X         0x02u
#define M_PPS2DeltaAbsPressureFlt_U8X           0x04u
#define C_AbsPressFailMaxReboot_U8X             3u        
#define M_PPS2NoRelativePressureRcvd_U8X        0x01u   
#define M_PPS2NoAbsIDRcvd_U8X                   0x02u   
#define M_PPS2ReadyUnlocked_U8X                 0x04u   
#define M_PPS2SensorDefectMsg_U8X               0x20u   
typedef enum
{
   E_NoPPS2Configured,
   E_PPS2AbsMinMaxUpdated,
   E_PPS2NoAbsMinMaxUpdate
} te_PPS2MinMaxUpdate;
typedef enum
{
   E_NoAbsPress,
   E_FirstPartReceived,
   E_SecondPartReceived,
   E_ThirdPartReceived
} te_PPS2AbsPressureState;
typedef struct
   {
   #if defined ab10andromeda
   U32 B_ProtocolA_U8X     : 8;   
   U32 B_ProtocolB_U4X     : 4;   
   U32 B_ManufacturerA_U4X : 4;   
   U32 B_ManufacturerB_U4X : 4;   
   U32 B_TypeA_U4X         : 4;   
   U32 B_TypeB_U4X         : 4;   
   U32 B_TransCRCMode_U4X :  4;   
   #elif defined ab10nec
   U32 B_ProtocolA_U8X     : 8;   
   U32 B_ManufacturerA_U4X : 4;   
   U32 B_ProtocolB_U4X     : 4;   
   U32 B_TypeA_U4X         : 4;   
   U32 B_ManufacturerB_U4X : 4;   
   U32 B_TransCRCMode_U4X :  4;   
   U32 B_TypeB_U4X         : 4;   
   #else
      #error unsupported uC type!
   #endif
   } ts_Pps2StatusPart1;
typedef struct
   {
   #if defined ab10andromeda
   U32 B_PSI_U4X          :  4;   
   U32 B_HousingCodeA_U4X :  4;   
   U32 B_HousingCodeB_U4X :  4;   
   U32 B_SeriesCodeA_U4X  :  4;   
   U32 B_SeriesCodeB_U8X  :  8;   
   U32 B_ProdDateUp_U8X   :  8;   
   #elif defined ab10nec
   U32 B_HousingCodeA_U4X :  4;   
   U32 B_PSI_U4X          :  4;   
   U32 B_SeriesCodeA_U4X  :  4;   
   U32 B_HousingCodeB_U4X :  4;   
   U32 B_SeriesCodeB_U8X  :  8;   
   U32 B_ProdDateUp_U8X   :  8;   
   #else
      #error unsupported uC type!
   #endif
   } ts_Pps2StatusPart2;
typedef struct
   {
   ts_Pps2StatusPart1 S_Part1_XXX;   
   ts_Pps2StatusPart2 S_Part2_XXX;   
   U8 V_ProdDateLow_U8X;             
   U8 V_LotLineNo_U8X;               
   U8 A_SerialNumber_U8X[C_PPS2SerialNumberLength_U8X]; 
   } ts_Pps2StatusCode;
typedef struct
   {
   U8                      A_SensorStatusCodeINTW_U8X[C_PPS2StatusMessageLength_U8X]; 
   U16                     V_AbsolutePressureINTW_U16X;                               
   U16                     V_TempAbsolutePressureINTW_U16X;                           
   te_PPS2AbsPressureState E_AbsPressureRcvd_XXX;                                     
   U8                      V_PressureReceiveFlagsINTW_U8X;                             
   U8                      V_MissingAbsCounter_U8X;                                    
   U8                      V_Dummy_U8X;                                               
   S16                     V_FirstSampleValueINTW_S16X;                               
   U16                     V_Dummy_U16X;                                              
   } ts_Pps2SpecificData;
#define C_PPS2SpecificRamSize_U16X sizeof(ts_Pps2SpecificData)
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void PP2_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pps2FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pps2SecondSampleFIQFp_xfr );
void PP2_EvaluateSingleSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PP2_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PP2_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PP2_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
void PP2_BackGroundMonitoring100ms( void );
#endif
#endif
