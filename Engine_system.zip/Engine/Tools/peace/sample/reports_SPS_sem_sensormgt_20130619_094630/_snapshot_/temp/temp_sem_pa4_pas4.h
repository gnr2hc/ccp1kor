#ifndef Y_sem_pa4_pas4H
#define Y_sem_pa4_pas4H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PAS4INIT1Timeout_U16X             176u         
#define C_PAS4StartupTimeout_U16X           525u     
#define C_PAS4StatusMessageLength_U8X         8u     
#define C_PAS4SerialNumberLength_U8X          4u     
#define C_PAS4PasIfSettings_U8X            0x07u     
#define C_PAS4SignalPlausiThreshold_U16X     60u     
#define C_Pas4StatusMessagesComplete_U32X  0x0000FFFFu   
#define C_PAS4StatusDataProtocol_U8X            0x30u    
#define C_PAS4StatusDataManufact_U8X            0x01u    
#define C_PAS4StatusDataCG968_U8X               0x01u    
#define C_PAS4StatusDataCG969_U8X               0x02u    
#define C_PAS4StatusData50g_U8X                 0x01u 
#define C_PAS4StatusData100g_U8X                0x00u
#define C_PAS4StatusData200g_U8X                0x02u
#define C_PAS4StatusData200gPSB5_U8X            0x03u
#define C_PAS4StatusDataXsensitiv_U8X           0x00u
#define C_PAS4StatusDataYsensitiv_U8X           0x01u
#define C_PAS4StatusDataZsensitiv_U8X           0x10u
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Protocol_U8X     : 8;  
   U32 B_Manufacturer_U3X : 3;  
   U32 B_Type_U5X         : 5;  
   U32 B_Range_U4X        : 4;  
   U32 B_SensingAxis_U4X  : 4;  
   U32 B_CustomerCode_U8X : 8;  
   #elif defined ab10nec
   U32 B_Protocol_U8X     : 8;  
   U32 B_Type_U5X         : 5;  
   U32 B_Manufacturer_U3X : 3;  
   U32 B_SensingAxis_U4X  : 4;  
   U32 B_Range_U4X        : 4;  
   U32 B_CustomerCode_U8X : 8;  
   #else 
      #error unsupported uC type!
   #endif
   } ts_Pas4StatusPart1;
typedef struct
   {
   ts_Pas4StatusPart1 S_DecodedMsg_XXX;
   U8 A_SerialNumber_U8X[C_PAS4SerialNumberLength_U8X];  
   } ts_Pas4StatusCode;
typedef struct
   {
   U8  A_SensorStatusCodeINTW_U8X[C_PAS4StatusMessageLength_U8X]; 
   S16 V_FirstSampleValueINTW_S16X;                               
   U16 V_Dummy_U16X;                                              
   } ts_Pas4SpecificData;
#define C_PAS4SpecificRamSize_U16X sizeof(ts_Pas4SpecificData)
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void PA4_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pas4FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pas4SecondSampleFIQFp_xfr );
void PA4_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PA4_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PA4_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
#endif
#endif
