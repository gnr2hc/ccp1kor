#ifndef Y_sem_s20_smb200H
#define Y_sem_s20_smb200H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_SMB200SPIReadChannel1_U16X            0x8000u  
#define C_SMB200SPIReadChannel2_U16X            0xC000u  
#define C_SMB200SPIReadDeviceID_U16X            0x0000u  
#define C_SMB200SPIReadRevisionID_U16X          0x0600u  
#define C_SMB200SPIReadMonitorData_U16X         0x0E00u  
#define C_SMB200SPIOffsetCancellationON_U16X    0x7805u  
#define C_SMB200SPIOffsetCancellationOFF_U16X   0x7800u  
#define C_SMB200SPIReadOffsetCancellation_U16X  0x7A00u  
#define C_SMB200SPIDemandBite1_U16X             0x3809u  
#define C_SMB200SPIDemandBite2_U16X             0x3806u  
#define C_SMB200SPIDemandBiteOFF_U16X           0x3800u  
#define C_SMB200SPIEOPCommand_U16X              0x0C00u  
#define M_SMB200AllSpiBits_U8X 0xFCu
#define M_SMB200MonitorFaultBits_U16X       0x000Fu  
#define M_SMB200FinalSensorStatus_U16X      0x100Au  
#define M_SMB200OffsetCancellationFast_U8X  0x0Fu    
#define M_SMB200OffsetCancellationOff_U8X   0x00u    
#define C_SMB200DeviceID_U8X                    0x35u   
#define C_SMB200AverageRawOffsetExp_U8X           4u    
#define C_SMB200AverageTestExp_U8X                6u    
#define C_SMB200OffsetDelay_U16X                500u    
#define C_SMB200OffsetTreshold_U16X             0x0C8u  
#define C_SMB200BiteDelay_U16X                  100u    
#define C_SMB200BiteOffDelay_U16X                36u    
#define C_SMB200BiteMinThresholdChannel1_S16X   250     
#define C_SMB200BiteMaxThresholdChannel1_S16X   470     
#define C_SMB200BiteMinThresholdChannel2_S16X   110     
#define C_SMB200BiteMaxThresholdChannel2_S16X   450     
typedef enum
{
  E_SMB200NotConfigured,                     
  E_SMB200SensorDisabled,                    
  E_SMB200InitCalcRawOffset,                 
  E_SMB200InitEvalRawOffset,                 
  E_SMB200InitStartFastOffsetCancellation,   
  E_SMB200InitWaitForOffsetCancellation,     
  E_SMB200InitEvalOffsetCancellation,        
  E_SMB200InitStartBite1,                    
  E_SMB200InitWaitForBite1,                  
  E_SMB200InitSwitchBite2,                   
  E_SMB200InitWaitForBite2,                  
  E_SMB200InitEvalBite,                      
  E_SMB200InitCheckTestModeOff,              
  E_SMB200InitEvaluateErrorsAndEOP,          
  E_SMB200SteadyState1,                      
  E_SMB200SteadyState2,                      
  E_SMB200SteadyState3                       
} te_SMB200Status;
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
U8 S20_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
void S20_BackgroundMonitoring10ms( void );
#endif
#endif
