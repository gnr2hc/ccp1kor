#ifndef Y_sem_pa5_pas5H
#define Y_sem_pa5_pas5H
#include "utl_options.p"
#include "utl_tb_typesbase.h"
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
#define C_PAS5INIT1Timeout_U16X                98u  
#define C_PAS5StartupTimeout_U16X             305u  
#define C_PAS5DCINIT1Timeout_U16X               258u
#define C_PAS5DCStartupTimeout_U16X             405u
#define C_PAS5StatusMessageLength_U8X          16u  
#define C_PAS5SerialNumberLength_U8X            6u  
#define C_PAS5PasIfSettings_U8X              0x03u  
#define C_PAS5RPasIfSettings_U8X             0x09u  
#define C_PAS5SignalPlausiThreshold_U16X       60u  
#define C_PAS5FirstPageComplete_U32X        0x0000FFFFu   
#define C_Pas5StatusMessagesComplete_U32X   0xFFFFFFFFu   
#define C_PAS5IndexSecondPage_U8X           16u           
#define C_PAS5SdProtocolCSampleA_U8X        0x42u 
#define C_PAS5SdProtocolCSampleB_U8X        0x00u 
#define C_PAS5ManuBoschBIT_U8X              0x10u
#define C_PAS5ManuVdoBIT_U8X                0x20u
#define C_PAS5ManuAutolivBIT_U8X            0x40u
#define C_PAS5ManuTemicBIT_U8X              0x80u
#define C_PAS5ManuBoschASCII_U8X            0x42u
#define C_PAS5ManuAutolivASCII_U8X          0x41u
#define C_PAS5ManuTemicASCII_U8X            0x43u
#define C_PAS5ManuTrwASCII_U8X              0x54u
#define C_PAS5SensorTypePas5xy_U8X          0x00u               
#define C_PAS5SensorType_U8X                0x01u
#define C_PAS5Range120g_U8X                  0x08u    
#define C_PAS5Range240g_U8X                  0x09u    
#define C_PAS5Range480g_U8X                  0x0Au    
#define M_PAS5ReadyUnlocked_U8X               0x10u
#define M_PAS5ReadyOnlyBit1Locked_U8X         0x10u
#define M_PAS5DaisyChainProgrammingError_U8X  0x20u
typedef struct
   {
   #if defined ab10andromeda
   U32 B_ProtocolA_U8X     : 8;   
   U32 B_ProtocolB_U4X     : 4;   
   U32 B_ManufacturerA_U4X : 4;   
   U32 B_ManufacturerB_U4X : 4;   
   U32 B_ModeOrType_U4X    : 4;   
   U32 B_Type_U4X          : 4;   
   U32 B_SensingAxis_U4X   : 4;   
   #elif defined ab10nec
   U32 B_ProtocolA_U8X     : 8;   
   U32 B_ManufacturerA_U4X : 4;   
   U32 B_ProtocolB_U4X     : 4;   
   U32 B_ModeOrType_U4X    : 4;   
   U32 B_ManufacturerB_U4X : 4;   
   U32 B_SensingAxis_U4X   : 4;   
   U32 B_Type_U4X          : 4;   
   #else
      #error unsupported uC type!
   #endif
   } ts_Pas5StatusPart1;
typedef struct
   {
   #if defined ab10andromeda
   U32 B_Range_U4X         :  4;   
   U32 B_Filter_U1X        :  1;   
   U32 B_SMBDir_U1X        :  1;   
   U32 B_SGBCodeA_U2X      :  2;   
   U32 B_SGBCodeB_U4X      :  4;   
   U32 B_CustomerCodeA_U4X :  4;   
   U32 B_CustomerCodeB_U8X :  8;   
   U32                     :  2;   
   U32 B_DateUpper_U6X     :  6;   
   #elif defined ab10nec
   U32 B_SGBCodeA_U2X      :  2;   
   U32 B_SMBDir_U1X        :  1;   
   U32 B_Filter_U1X        :  1;   
   U32 B_Range_U4X         :  4;   
   U32 B_CustomerCodeA_U4X :  4;   
   U32 B_SGBCodeB_U4X      :  4;   
   U32 B_CustomerCodeB_U8X :  8;   
   U32 B_DateUpper_U6X     :  6;   
   U32                     :  2;   
   #else
      #error unsupported uC type!
   #endif
   } ts_Pas5StatusPart2;
typedef struct
   {
   ts_Pas5StatusPart1 S_Part1_XXX;   
   ts_Pas5StatusPart2 S_Part2_XXX;   
   U8 V_DateLower_U8X;               
   U8 V_LotLineNo_U8X;               
   U8 A_SerialNumber_U8X[C_PAS5SerialNumberLength_U8X]; 
   } ts_Pas5StatusCode;
typedef struct
   {
   U8      A_SensorStatusCodeINTW_U8X[C_PAS5StatusMessageLength_U8X]; 
   S16     V_FirstSampleValueINTW_S16X;                               
   U16     V_Dummy_U16X;                                              
   } ts_Pas5SpecificData;
#define C_PAS5SpecificRamSize_U16X      sizeof(ts_Pas5SpecificData)
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
void PA5_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pas5FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pas5SecondSampleFIQFp_xfr );
void PA5_EvaluateSingleSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PA5_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PA5_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
void PA5_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
#endif
#endif
