/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_m2s_rollratemm2s.h */
#ifndef Y_sem_m2s_rollratemm2sH
#define Y_sem_m2s_rollratemm2sH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2010 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_m2s_rollratemm2s Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_m2s_rollratemm2s.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific Module for MM2S (SMG100) series angular-rate sensor.
 * The MM2S is the successor of the MM2R used in AB9.
 * 
 * This module contains the sensor specific initialisation and background
 * monitoring tasks.
 * 
 * The framework of the module is extended to implement optionally CRQ149 or
 * CRQ168 according (System_CRQ_149_NRO_Flag_handling_SMG100,
 * System_CRQ_168_SMG100_Fault_Handling) by using a dedicated real-time
 * evaluation function M2S_EvaluateSensorDataFIQ().
 * This function improves the NRO handling regarding special driving maneuver
 * on gravel. This improvement was introduced initially for Hyundai Hy1000
 * (CRQ149) and was taken over for this module.
 * Changed behaviour: one inactive NRO flag in the timeframe of 30 ms leads to
 * a FltStepDown.
 * (Target is to reach a increased robustness of fault filtering for the SMG100
 * and SMG102.)
 * 
 * !!! This function shall not be used by module revisions which do not support
 * CRQ149 or CRQ168. In case that CRQ149 or CRQ168 is not required this
 * functionality is taken over by the standard function of
 * CS_EvaluateSensorDataFIQ() in <sem_cs_centralsensors.c> and no overloading
 * takes place.
 * 
 * For simplicity to have the same AMEOS model regarding module
 * <sem_m2s_rollratemm2s.c> the function frame continues to exist by having an
 * empty body.
 *
 *
 *  Reference to Documentation:  sem_m2s_rollratemm2s_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_m2s_rollratemm2s Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_m2s_rollratemm2s.h  $ */
/*  Revision 1.1 2019/09/05 11:16:42CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:56MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.8 2012/06/18 20:01:06IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor)  */
/*  new plausi handling added */
/*  --- Added comments ---  bhs6kor [2012/06/18 14:38:44Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/27 11:33:33Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/29 09:16:25Z] */
/*  State changed: reviewed -> release by bhs6kor */
/*   */
/*  --- Added comments ---  FKS2SI [2013/04/03 08:18:29Z] */
/*  fix:Ptedt00132223 "Sensor monitoring update for SMG074, SMG076, SMG10x and SMB225" */
/*  Revision 5.7 2011/05/13 12:29:00MESZ HKU2SI  */
/*  create_code executed */
/*  --- Added comments ---  HKU2SI [2011/05/13 10:29:50Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/05/13 10:30:21Z] */
/*  delta review done by EPS3-Frueh */
/*  --- Added comments ---  HKU2SI [2011/07/18 13:14:08Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.6 2011/05/13 12:19:47CEST HKU2SI  */
/*  review finding, disable algo rollover for internal monitoring fault */
/*  Revision 5.5 2011/04/18 17:30:18CEST HKU2SI  */
/*  comment for fault reaction and fault description reworked */
/*  Revision 5.4 2011/02/25 10:03:16CET HKU2SI  */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:07Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:07Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.3 2011/01/04 14:31:58CET bhs6kor  */
/*  updated after review */
/*  --- Added comments ---  bhs6kor [2011/01/06 09:21:17Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2011/02/18 08:41:45Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:36:41Z] */
/*  REVIEWED AND BASELINED */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:36:42Z] */
/*  State changed: reviewed -> release by rdd3kor */
/*  Revision 5.2 2010/12/09 18:06:57IST HKU2SI  */
/*  Solution of CRQ168 copied from side branch 1.6.1.31. */
/*  Source adapted to new ASI interface and adaptation to AMEOS model. */
/*  --- Added comments ---  HKU2SI [2010/12/10 11:04:13Z] */
/*  1.6.1.31 refers to sem_m2s_rollratemm2s.c */
/*  regarding header file solution of CRQ168 from 1.7.1.19 was taken over */
/*  --- Added comments ---  HKU2SI [2010/12/10 11:04:39Z] */
/*  CRQ_168 */
/*  --- Added comments ---  HKU2SI [2010/12/10 14:11:10Z] */
/*  State changed: develop -> tested by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/12/10 14:11:16Z] */
/*  State changed: tested -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/12/10 14:11:55Z] */
/*  delta review done by EPS3-Jonkmann */
/*  delta review is based on 1.7.1.19 */
/*  --- Added comments ---  HKU2SI [2010/12/10 14:27:14Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/12/10 15:33:43Z] */
/*  fix:Ptedt00056177 */
/*  --- Added comments ---  HKU2SI [2010/12/13 09:22:55Z] */
/*  fix:Ptedt00055235 */
/*  explanation: CRQ_167 waiting time increased to 150ms */
/*  CRQ168: second improvement to handle NRO ADCRAT_ERR in regard to vibration */
/*  Revision 1.7.1.19 2010/12/06 12:16:34CET HKU2SI  */
/*  ADCRAT_OFS replaced by ADCRAT_ERR to detect vibration */
/*  --- Added comments ---  jnr1si [2010/12/07 09:01:45Z] */
/*  delta review by Jonkmann, no findings */
/*  --- Added comments ---  jnr1si [2010/12/07 09:01:45Z] */
/*  State changed: develop -> reviewed by jnr1si */
/*  Revision 1.7.1.18 2010/09/30 11:58:19CEST HKU2SI  */
/*  review findings incorporated */
/*  --- Added comments ---  HKU2SI [2010/10/01 13:08:18Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/10/01 13:08:23Z] */
/*  State changed: reviewed -> tested by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2010/10/19 08:50:47Z] */
/*  fix:Ptedt00055073 AsicRollOverInternalMonitoring during misuse tests */
/*  fix:Ptedt00054969 50ms ->150ms startup delay time */
/*  fix:Ptedt00055187 50ms ->150ms startup delay time */
/*   */
/*  --- Added comments ---  HKU2SI [2010/11/02 14:46:39Z] */
/*  ADCRAT_OFS instead of ADCRAT_ERR is used to evaluate vibration */
/*  --- Added comments ---  HKU2SI [2010/11/02 14:46:39Z] */
/*  State changed: tested -> bug by HKU2SI */
/*  Revision 1.7.1.17 2010/09/24 14:05:10CEST HKU2SI  */
/*  expected safetyID taken over from sem_sensormgtpar.p */
/*  --- Added comments ---  HKU2SI [2010/09/28 13:33:03Z] */
/*  State changed: develop -> tested by HKU2SI */
/*  Revision 1.7.1.16 2010/09/22 13:47:59CEST HKU2SI  */
/*  rework and new test cases for test SW */
/*  Revision 1.7.1.15 2010/09/21 15:50:58CEST HKU2SI  */
/*  test cases for test SW reworked */
/*  Revision 1.7.1.14 2010/09/09 16:43:41CEST HKU2SI  */
/*  adaptations after RTRT */
/*  Revision 1.7.1.13 2010/08/26 07:45:35CEST HKU2SI  */
/*  create_code executed */
/*  Revision 1.7.1.12 2010/08/25 18:06:09CEST HKU2SI  */
/*  temporary check-in review findings incorporated */
/*  Revision 1.7.1.11 2010/08/25 10:40:58CEST HKU2SI  */
/*  CRQ168 implemented (update create_code regarding old Ameos model corrected) */
/*  Revision 1.7.1.9 2010/02/26 11:09:43CET HKU2SI  */
/*  review findings incorporated Ptedt00046854 */
/*  --- Added comments ---  HKU2SI [2010/02/26 17:24:20Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 1.7.1.8 2010/02/26 09:26:11CET HKU2SI  */
/*  review finding incorporated (new test case) Ptedt00046854 */
/*  Revision 1.7.1.7 2010/02/25 11:53:37CET HKU2SI  */
/*  review findings incorprated */
/*  Revision 1.7.1.6 2010/02/18 08:14:45CET HKU2SI  */
/*  error test cases added to check error handling for special test mode */
/*  Revision 1.7.1.5 2010/02/15 09:09:16CET HKU2SI  */
/*  debug info disabled */
/*  Revision 1.7.1.4 2010/02/11 10:39:03CET HKU2SI  */
/*  temporary check-in for Hyundai new NRO behaviour */
/*  - change to main state machine and 2 sub state machines */
/*  Revision 1.7.1.3 2010/01/29 14:48:26CET HKU2SI  */
/*  temporary version for Hyundai which passed tests from Frank Boehm 29.1.10 11.00 a.m. */
/*  Revision 1.7 2008/10/28 15:45:49CET hku2si  */
/*  revision 1.6.1.2 shifted to main branch to release module */
/*  --- Added comments ---  hku2si [2008/10/28 14:50:25Z] */
/*  MM2S QB2 was done on 27.10.08. Current status: no additional parameter  */
/*  changes. */
/*  --- Added comments ---  hku2si [2008/10/28 14:50:25Z] */
/*  State changed: develop -> release by hku2si */
/*   */
/*  --- Added comments ---  hku2si [2008/10/29 15:17:43Z] */
/*  Member revision set by hku2si */
/*  --- Added comments ---  hku2si [2008/11/21 10:26:23Z] */
/*  Member revision set by hku2si on variant NI_X61G */
/*  Revision 1.6.1.2 2008/09/02 14:45:49CEST fru1si  */
/*  Changed threshold constants for BITE. Modification requested by project team. */
/*  --- Added comments ---  fru1si [2008/09/02 12:46:23Z] */
/*  State changed: develop -> tested by fru1si */
/*  Revision 1.6.1.1 2008/03/03 15:50:12CET fru1si  */
/*  Duplicate revision */
/*  Revision 1.5.1.3 2008/02/29 17:40:10CET hku2si  */
/*  review findings incorporated */
/*  Revision 1.5.1.2 2008/02/25 17:03:28CET hku2si  */
/*  mask corrected M_MM2SMoniIIResponseBits_U8R */
/*  Revision 1.5.1.1 2008/02/22 13:06:47CET hku2si  */
/*  adaptation for BSS C2-Sample */
/*  - SPI commands odd parity */
/*  Revision 1.5 2008/02/06 16:39:59CET hku2si  */
/*  review finding incorporated */
/*  Revision 1.4 2008/01/17 16:48:35CET hku2si  */
/*  only typo removed */
/*  Revision 1.3 2007/09/17 11:13:02CEST hku2si  */
/*  - review findings incorporated and beautification */
/*  Revision 1.2 2007/08/17 15:24:45CEST hku2si  */
/*  beautification */
/*  Revision 1.1 2007/08/16 08:46:23CEST hku2si  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/ab10_base/ab10lib_hwd/sem_sensormgt/sem_sensormgt.pj */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_m2s_rollratemm2s_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_m2s_rollratemm2s_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_m2s_rollratemm2s)  Definitions*/
/* EasyCASE - */
/* #define Y_SMG100DbgInfo */          /* debug information activated */
#undef Y_SMG100DbgInfo                 /* debug information deactivated */
/* EasyCASE - */
/* #define Y_SMG100ErrorTestCases */   /* control error test cases activated */
#undef Y_SMG100ErrorTestCases          /* control error test cases deactivated */
/* EasyCASE ( 918
   sensor specific thresholds / constants */
#define C_MM2SAverageExp_U8X                     6u   /* number of realtime measurements used for an averaged signal,
specified in 2^x fashion (6 => 64 samples) */
/* EasyCASE - */
#define C_MM2SResetDelay_U8X                   10u    /* delay between activation of reset and it is effective (us) */
/* EasyCASE - */
#define C_MM2SRawOffsetDelay_U16X              500u   /* delay till raw offset can be sampled (delay since reset, ms) */
#define C_MM2SOffsetThreshold_U16X            0x32u   /* threshold for offset cancellation check (+-25deg/s) */
#define C_MM2SOffsetDelayFirst_U16X            500u   /* delay till fast offset cancellation can be evaluated (ms) */
#define C_MM2SOffsetDelayRetry_U16X            200u   /* delay for fast offset in case of a retry (ms) */
/* EasyCASE - */
#define C_MM2SDelayAfterReset_U16X           150u     /* delay after sensor reset in ms */
#define C_MM2SDelayAfterFOC_U16X             300u     /* delay after FOC to allow sending of next SPI command */
#define C_MM2SBiteDelay_U16X                  60u     /* delay till Bite can be evaluated (ms) */
#define C_MM2SBiteOffDelay_U16X               70u     /* delay between BITE-off command and real end of BITE (ms) */
#define C_MM2SBiteMinThreshold_S16X           100u    /* minimum threshold for the BITE Test
* minimum neg range -100
* minimum pos range  100
* done by comparison of absolute value   */
#define C_MM2SBiteMaxThreshold_S16X           460u    /* maximum threshold for the BITE Test */
/* EasyCASE - */
#define C_MM2SEOPDelay_U16X                   100u    /* delay between EOP and the final evaluation (ms) */
/* EasyCASE - */
#define C_MM2STimeToIntrlMoniFlt_U16X         334    /* time based on 30ms counter until internal monitoring fault 
occurs due to vibration fault, 334 * 30ms = 10020  */
/* EasyCASE ) */
/* EasyCASE ( 914
   SPI Commands for MM2S */
/* SPI responses */
/* EasyCASE - */
#define C_MM2SSPIReadSensorData_U16X          0x8000u  /* Read sensor channel */


#define C_MM2SSPISoftReset_U16X               0x4a00u  /* performs a reset of the sensor */
#define C_MM2SReadSensorConfig_U16X           0x7500u  /* (changed for CA sample) read sensor configuration */


#define C_MM2SSPIReadDeviceID_U16X            0x0100u  /* (changed for CA sample) Read Device ID */
#define C_MM2SSPIReadMonitorData1_U16X        0x3b00u  /* (changed for CA sample) Read Monitor Data 1 */
#define C_MM2SSPIReadMonitorData2_U16X        0x3d00u  /* (changed for CA sample) Read Monitor Data 2 */
#define C_MM2SSPIReadMonitorData3_U16X        0x3e00u  /*                         Read Monitor Data 3 */

#define C_MM2SSPIWrEOP_U16X                   0x0d00u  /* (changed for CA sample) Write to EOP control register */

#define C_MM2SSPIDemandBitePos_U16X           0x3801u  /* Selftest: positive deflection */
#define C_MM2SSPIDemandBiteNeg_U16X           0x3802u  /* Selftest: negative deflection */
#define C_MM2SSPIDemandBiteOFF_U16X           0x3800u  /* Selftest: off  */

#define C_MM2SSPIReadPartId1_U16X             0x5E00u  /*                         Read Part ID block 1 */
#define C_MM2SSPIReadPartId2_U16X             0x5d00u  /* (changed for CA sample) Read Part ID block 2 */
#define C_MM2SSPIReadPartId3_U16X             0x5B00u  /* (changed for CA sample) Read Part ID block 3 */
#define C_MM2SSPIReadPartId4_U16X             0x5800u  /*                         Read Part ID block 4 */
#define C_MM2SSPIReadPartId5_U16X             0x5700u  /* (changed for CA sample) Read Part ID block 5 */
#define C_MM2SSPIReadPartId6_U16X             0x5400u  /*                         Read Part ID block 6 */

/* commands for inital tests / programming */
#define C_MM2SSPIOffsetCancellationON_U16X    0x7901u  /* (changed for CA sample) switch on offset cancellation */
#define C_MM2SSPIOffsetCancellationOFF_U16X   0x7900u  /* (changed for CA sample) switch off offset cancellation */
#define C_MM2SSPIReadOffsetCancellation_U16X  0x7A00u  /*                         Read Offset cancellation status */
#define C_MM2SSPIEOPCommand_U16X              0x0D00u  /* (changed for CA sample) End of programming */
/* EasyCASE - */
/* SPI responses */
/* EasyCASE - */
#define C_MM2SResetResponse_U16X              0xFFFF   /* expected SPI response 10�s after reset command was sent */
/* EasyCASE - */
#define C_MM2SDeviceID_U8X                    0x97u   /* expected Device ID of a MM2S */
#define C_MM2SDeviceIDRsp_U16X                0x3097u /* expected Device ID 16 bit response of the MM2S */
#define C_MM2SPartIdLengt_U8X                 0x06u   /* MM2S has 6 bytes Part-ID */
/*!DEF ARRAYLEN C_MM2SPartIdLengt_U8X 6 */
/* EasyCASE - */
/* SPI-Communication Masks */
#define M_MM2SSPIOffsetCancellationFast_U8X     0x03u    /* fast offset cancellation active */
#define M_MM2SSPIOffsetStatusAfterEOP_U16X      0x1002u  /* TFF not set, TST not set, NRO not set, slow offset regulation active */
#define M_MM2SSPIOffsetCancellationOff_U8X      0x00u    /* offset cancellation off (bit1, bit0) */
/* EasyCASE - */
#define M_MM2SSPIMoni1ADCrat_U8X                0x04u    /* mask for SPI response status monibit ADCRAT_ERR */
#define M_MM2SMoniData12NoADCrat_U16X           0xFBFFu  /* mask for SPI response status data monitoring 1,2 other than ADCRAT_ERR, 
ADCRAT_ERR belongs to monitor data2 bit2 */
/* EasyCASE ) */
/* EasyCASE ( 933
   masks for detailed faults */
/* Mask for additional fault information */
#define M_MM2SCsStatusInfoNRO_U8X            0x01u /* */
#define M_MM2SCsStatusInfoTST_U8X            0x02u /* */
#define M_MM2SCsStatusInfoMonitorData12_U8X  0x04u /* */
#define M_MM2SCsStatusInfoADCratFlt_U8X      0x08u /* */
#define M_MM2SCsStatusInfoIntrnFlt_U8X       0x10u /* */
/* EasyCASE - */
/* Mask for internal faults - reasons */
#define M_MM2SSWResetFailed_U8X         0x01u
#define M_MM2SWrongDeviceID_U8X         0x02u
#define M_MM2SWrongSensorConfig_U8X     0x04u
#define M_MM2SMonitoringDataFault_U8X   0x08u
#define M_MM2SWrongSensorType_U8X       0x10u
/* EasyCASE - */
#ifdef Y_SMG100ErrorTestCases
/* EasyCASE - */
/* Mask for test case generations */
/* for V_MM2SDbgFaultControl1_U16E */
#define M_MM2SDbgCtrlA1_U16X         0x0001u /* A1, FltCsAsicRolloverProgramming fault, init phase */
#define M_MM2SDbgCtrlA2_U16X         0x0002u /* A2, FltCsAsicRolloverProgramming fault, init phase */
#define M_MM2SDbgCtrlA3_U16X         0x0004u /* A3, FltCsAsicRolloverProgramming fault, init phase */
#define M_MM2SDbgCtrlA4_U16X         0x0008u /* A4, FltCsAsicRolloverProgramming fault, init phase */
#define M_MM2SDbgCtrlA5_U16X         0x0010u /* A5, FltCsAsicRolloverProgramming fault, init phase */
#define M_MM2SDbgCtrlA6_U16X         0x0020u /* A6, FltCsAsicRolloverProgramming fault, init phase */

#define M_MM2SDbgCtrlB1_U16X         0x0040u /* B1, FltCsAsicRolloverInternalMonitoring, init phase, sensor reset failed, expected response is wrong */
#define M_MM2SDbgCtrlB2_U16X         0x0080u /* B2, FltCsAsicRolloverInternalMonitoring, device ID is wrong */
#define M_MM2SDbgCtrlB3_U16X         0x0100u /* B3, FltCsAsicRolloverInternalMonitoring, sensor configuration is wrong */
#define M_MM2SDbgCtrlB4_U16X         0x0200u /* B4, FltCsAsicRolloverInternalMonitoring, init phase, incorrect response of read monitor data1 */
#define M_MM2SDbgCtrlB5_U16X         0x0400u /* B5, FltCsAsicRolloverInternalMonitoring, init phase, TST is active */
#define M_MM2SDbgCtrlB6_U16X         0x0800u /* B6, FltCsAsicRolloverInternalMonitoring, steady state, TST is expected to be set */

#define M_MM2SDbgChkMoniBits_U16X    0x1000u /* test case to check if monitoring bits are set in EEPROM 
                                                data monitor 2 = 0xaa, data monitor 1 = 0xbb =>
                                                A_CSAdditFaults_U8E[0] = 0xaa keeps monitoring data 2 
                                                A_CSAdditFaults_U8E[1] = 0xbb keeps monitoring data 1 */
#define M_MM2SDbgCtrlC1_U16X         0x2000u /* C1, FltCsChannelXOffsetCancellation, offset cancellation value is out of range */
#define M_MM2SDbgCtrlD1_U16X         0x4000u /* D1, FltCsCentralSensorRollRateBITE, BITE1 result is out of range */
#define M_MM2SDbgCtrlE1_U16X         0x8000u /* E1, FltCsCentralSensorRollRateCommunication, init phase, SID wrong and indicated in handshake variable */

/* for V_MM2SDbgFaultControl2_U16E */
#define M_MM2SDbgCtrlE2_U16X         0x0001u /* E2, FltCsCentralSensorRollRateCommunication, steady state, ID wrong and indicated in handshake variable */
#define M_MM2SDbgCtrlF1_U16X         0x0002u /* F1, FltCsCentralSensorRollRatePlausibility, steady state, sensor value permanently beyond threshold */

#define M_MM2SDbgCtrlB61_U16X        0x0004u /* B6, FltCsAsicRolloverInternalMonitoring, error delayed during in steady state, TST is expected */

#define M_MM2SDbgCtrlG1_U16X         0x0008u /* G1, rollover vibration fault is qualified and dequalifies after 2500ms */
                                             /* ADCrat is active for 2000ms */  
#define M_MM2SDbgCtrlG2_U16X         0x0010u /* G2, rollover vibration fault and internal monitoring fault caused by vibration */
                                             /* ADCrat is active for 12000ms */
#define M_MM2SDbgCtrlG1dist_U16X     0x0020u /* G1, rollover vibration fault and internal monitoring fault disturbed 
                                                   because 1 NRO is correct.
                                                ADCrat is active for 11000ms, subsequently 1 NRO is inactive */
#define M_MM2SDbgCtrlB51_U16X        0x0040u /* B5, FltCsAsicRolloverInternalMonitoring, in init phase, NRO is active */
#define M_MM2SDbgCtrlB62_U16X        0x0080u /* B6, FltCsAsicRolloverInternalMonitoring, error delayed in steady state, NRO is set */

#define M_MM2SDbgCtrlB63_U16X        0x0100u /* B6, FltCsAsicRolloverInternalMonitoring, error delayed in steady state, vibration current + active, 
                                                    NRO is set, check if monitoring bits are written to EEPROM 
                                                    A_CSAdditFaults_U8E[0] = 0xbb, A_CSAdditFaults_U8E[1] = 0xb6 */

#define M_MM2SDbgCtrlB64_U16X        0x0200u /* B6, FltCsAsicRolloverInternalMonitoring, in steady state, fault is dequalified because of 1 inactive
                                                    NRO after 750ms */
#define M_MM2SDbgCtrlG1dequal_U16X   0x0400u /* G1, vibration fault is dequalified after 1900ms in steady state */
/* EasyCASE - */
#endif
/* EasyCASE - */
/* Mask for StepUpIni-Repetitions */
#define M_MM2SRepB1_U8X              0x01u /* repetition StepUpIni for error handling B1 */
#define M_MM2SRepB2_U8X              0x02u /* repetition StepUpIni for error handling B2 */
#define M_MM2SRepB3_U8X              0x04u /* repetition StepUpIni for error handling B3 */
#define M_MM2SRepB4_U8X              0x08u /* repetition StepUpIni for error handling B4 */
#define M_MM2SInRepB1234_U8X         0x0Fu /* mask if error handling is in repetition of 
                                              B1, B2, B3, B4  */
/* EasyCASE - */
#define M_OfdgBitsExlNRO_U8X 0xdcu           /* mask for offending bits excluding NRO comparison */
/* EasyCASE ) */
/* EasyCASE ( 928
   miscellaneous */
#define C_MM2SALLBitsSet_U8X                   0xFFu    /* used to initialize V_MM2SADCratOver3BgAND_U8R for logical AND  */
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicRolloverProgramming: E_NoDisable */
/*! FLTREACTION FltCsAsicRolloverInternalMonitoring: E_DisableAlgoRollover */
/*! FLTREACTION FltCsAsicRolloverVibration: E_NoDisable */
/* EasyCASE - */
/*! FLTREACTION FltCsCentralSensorRollRateBITE: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRateOffsetCancellation: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRateCommunication: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRatePlausibility: E_NoDisable */
/* EasyCASE - */
/*! FLTDESC FltCsAsicRolloverProgramming: Rollover ASIC: Programming Fault */
/* EasyCASE - */
/*! FLTDESC FltCsAsicRolloverInternalMonitoring: Rollrate Sensor: internal monitoring error */
/* EasyCASE - */
/*! FLTDESC FltCsCentralSensorRollRateBITE: Central Sensor Roll Rate BITE Fault */
/*! FLTDESC FltCsCentralSensorRollRateOffsetCancellation: Central Sensor Roll Rate Offset Cancellation Fault */
/*! FLTDESC FltCsCentralSensorRollRateCommunication: Central Sensor Roll Rate Communication Fault */
/*! FLTDESC FltCsCentralSensorRollRatePlausibility: Central Sensor Roll Rate Plausibility Fault */
/* EasyCASE - */
/*! FLTDESC FltCsAsicRolloverVibration: Rollrate Sensor: internal error */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_m2s_rollratemm2s)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_m2s_rollratemm2s leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 916
   enum te_MM2SStatus */
/* EasyCASE < */
/* This enum encodes the states for a MM2S sensor */
typedef enum          
{                             /*!DEF ENUM te_MM2SStatus */
  E_MM2SNotConfigured         /*! E_MM2SNotConfigured: sensor is not configured */,
  E_MM2SSensorDisabled        /*! E_MM2SSensorDisabled: sensor disabled because of a fault */,
  E_MM2SInitPart1             /*! E_MM2SInitPart1: initialization part1 */,
  E_MM2SInitPart2             /*! E_MM2SInitPart2: initialization part2 */,
  E_MM2SSteadyState1          /*! E_MM2SSteadyState1: sensor is in steady state 1 (evaluate SID of sensor data) */,
  E_MM2SSteadyState2          /*! E_MM2SSteadyState2: sensor is in steady state 2 (fetch internal moni bits) */,
  E_MM2SSteadyState3          /*! E_MM2SSteadyState3: sensor is in steady state 3 (evaluate moni flags, NRO,TST) */
} te_MM2SStatus;              /*!END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 941
   enum te_MM2SInitPart1 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                 /*! DEF ENUM te_MM2SInitPart1 */
  E_MM2SStartupTest               /*! E_MM2SStartupTest: initial reset and startup test */,
  E_MM2SStartupTestPart2          /*! E_MM2SStartupTestPart2: initial reset and startup test - part 2 */,
  E_MM2SReadConfig                /*! E_MM2SReadConfig: read sensor configuration */,
  E_MM2SReadMonitoringData        /*! E_MM2SReadMonitoringData: read monitoring data MONI_I MONI_II */,
  E_MM2SInitResetTestDelay        /*! E_MM2SInitResetTestDelay: delay for initial reset test */,
  E_MM2SInitResetTestEval         /*! E_MM2SInitResetTestEval: evaluation of initial reset test */,
  E_MM2SInitReadPartID            /*! E_MM2SInitReadPartID : read MM2S part ID part */,
  E_MM2SInitRawOffsetDelay        /*! E_MM2SInitRawOffsetDelay: delay till raw offset can be measured */,
  E_MM2SInitRawOffsetMeasurement  /*! E_MM2SInitRawOffsetMeasurement:measurement  of the raw offset */,
  E_MM2SInitFastOffsetStart       /*! E_MM2SInitFastOffsetStart: start fast offset cancellation */,
  E_MM2SInitFastOffsetDelay       /*! E_MM2SInitFastOffsetDelay: delay till fast offset offset cancellation is done */,
  E_MM2SInitFastOffsetEval        /*! E_MM2SInitFastOffsetEval: measurement  and evaluation of the raw offset */
} te_MM2SInitPart1;               /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 945
   enum te_MM2SInitPart2 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                 /*! DEF ENUM te_MM2SInitPart2 */
  E_MM2SInitBite1Start            /*! E_MM2SInitBite1Start: start BITE (build in self test) */,
  E_MM2SInitBite1Delay            /*! E_MM2SInitBite1Delay: wait for BITE 1 settling time */,
  E_MM2SInitBiteSwitch            /*! E_MM2SInitBiteSwitch: store result of BITE 1 and switch to BITE 2 test */,
  E_MM2SInitBite2Delay            /*! E_MM2SInitBite2Delay: wait for BITE 2 settling time */,
  E_MM2SInitBiteEval              /*! E_MM2SInitBiteEval: evaluate result of BITE test */,
  E_MM2SInitBiteSendOff           /*! E_MM2SInitBiteSendOff: send Bite-off command to sensor */,
  E_MM2SInitBiteCheckOff          /*! E_MM2SInitBiteCheckOff: check if Testmode is off */,
  E_MM2SInitProgramSensor         /*! E_MM2SInitProgramSensor: program the sensor (EOP and Offset Cancellation) */,
  E_MM2SInitCompleteInit          /*! E_MM2SInitCompleteInit: evaluates the initialisation and completes it */
} te_MM2SInitPart2;               /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   M2S_Init */
/******************************************************************************
 * Description:
 *    Initialises the handling for the MM2S. This includes:
 *    - check if the sensor type is correct, that means if this module really
 *      accesses a MM2S
 *    - extract configuration data and add it to the management tables in
 *      centralsensors module
 *    - set the initial sensor/channel states
 *    - initiate the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the channel of this sensor, this index
 *      is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    Number of channels this sensor has, for a MM2S this is one.
 * 
 * Scheduling:
 *    Called once in 10ms background after cfg-data is available
 * 
 * Usage guide: -
 * 
 * Remarks:
 * The below Permanent Faults are checked for stored state using Central sensor
 * API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared.This function does all the necessary actions to register a
 * MM2S, so that it can be read in and monitored in a proper way. It sets up
 * the internal RAM tables with all the information needed.
 ******************************************************************************/
U8 M2S_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   M2S_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialisation or continuous cyclic monitoring.
 * 
 * Arguments: none
 * 
 * Return: none
 * 
 * Scheduling:
 *    10ms
 * 
 * Usage guide:
 *    called by centralsensors-module once in each 10ms background cycle.
 * 
 * Remarks: subsequent remark is only important if CRQ149 or CRQ168 is
 * implemented within this module.
 * Function m2s_ChkRTFlagsForIntrnlMoniFlts() is blocked if semaphore
 * V_StepUpIniIntrlMoniFlt_U16R is set to prevent that an internal monitoring
 * fault which is currently stepped up in CFM_StepUpIni() will not be stepped
 * down in m2s_ChkRTFlagsForIntrnlMoniFlts() during initialization phase.
 ******************************************************************************/
void M2S_BackgroundMonitoring10ms( void );
/* EasyCASE ) */
/* EasyCASE (
   M2S_EvaluateSensorDataFIQ */
/******************************************************************************
 * Description:
 *    This function does the standard real-time data evaluation for the sensor
 *    channel of the MM2S.
 * 
 * Arguments:
 *    - v_rawData_u16r : the raw sensor data received from the sensor
 *    - v_sensor_u8r   : the index for the sensors internal data table
 *    - v_channel_u8r  : the index for the sensors channel data interface
 * 
 * Return: -
 * 
 * Scheduling:
 *    realtime (FIQ)
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor channel. For that purpose a pointer to this function
 *    and its parameters are stored inside the sensormanager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    !!! This function shall not be used by module revisions which do not
 *    support CRQ149 or CRQ168 (System_CRQ_149_NRO_Flag_handling_SMG100,
 *    System_CRQ_168_SMG100_Fault_Handling).
 *    (Increase robustness or fault filtering for the SMG100 and SMG102). In
 *    case that CRQ 149 or CRQ168 is not required this functionality is taken
 *    over by the standard function of CS_EvaluateSensorDataFIQ() in
 *    <sem_cs_centralsensors.c> and no overloading takes place.
 *    For simplicity to have the same AMEOS model regarding module
 *    <sem_m2s_rollratemm2s.c> the function frame continues to exist by having
 *    an empty body.
 * 
 *    This function is highly runtime critical.
 *    It performs a check of the sensor data based on two criterias:
 *    - is the safety ID as expected?
 *    - are the checked SPI bits (TST, NRO) as expected?
 *    This test uses two variables:
 *    S_CsIntData_XXR.A_ChannelRTExpSpiBits_U8X: to define the expected SPI
 *    values which are compared to the data of read sensor data
 *    S_CsIntData_XXR.A_ChannelRTCheckedSpiBits_U8X: to define the respective
 *    bits which are checked. Only those bits which are defined as checked can
 *    participate for expected SPI comparison.
 *    - NRO strategy for steady state. An internal NRO monitoring fault can
 *      only be stepped up if all NRO flags of the incoming sensor raw data
 *      are set to 1 during 30ms.
 *    - If the sensor the sensor is in steady state and no offending bits are
 *      set the sensor data is written into the data interface
 *      S_CsSensorDataINTW_XXR.A_SensorValue_S16X  and the data valid flag is
 *      set for this channel. Additionally the NRO flag within the handshake
 *      variable S_CsIntData_XXR.A_ChannelRTFaultFlagsINTW_U8X[] is set to 0
 *      which causes to step down the internal monitoring fault in the BG
 *      m2s_ChkRTFlagsForIntrnlMonitrngFlts().
 *    - If the sensor is in steady state but offending bits are detected the
 *      offendings bits are put to the handshake variable for fault
 *      qualification in the BG process, but not for NRO in steady state. For
 *      steady state the NRO from current sensor data is logical AND combined
 *      with the NRO position inside the handshake variable and the result
 *      overwrites the current NRO entry of the handshake variable.
 *    - If NRO is cleared inside the handshake variable due to logical AND
 *      function the NRO remains cleared until
 *      m2s_ChkRTFlagsForIntrnlMonitrngFlts() is called again because
 *      m2s_ChkRTFlagsForIntrnlMonitrngFlts() sets NRO to 1. This give the
 *      possibilty to cause a possible new fault stepup for the next 30ms in
 *      the upcoming NRO RT comparisions.
 *    - During sensor initialisation this function can be used to generate an
 *      average value. This is triggered via the API
 *      CS_StartAverageCalculation. Then the sensor values are summed up in
 *      S_CsIntData_XXR.A_ChannelAvgSignalINTW_S16X.
 ******************************************************************************/
void M2S_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
