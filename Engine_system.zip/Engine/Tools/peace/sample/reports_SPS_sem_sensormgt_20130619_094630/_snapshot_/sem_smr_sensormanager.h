/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_smr_sensormanager.h */
#ifndef Y_sem_smr_sensormanagerH
#define Y_sem_smr_sensormanagerH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 25/07/2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_smr_sensormanager Header Author) Author*/
/*  $Source: sem_smr_sensormanager.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * The sensor manager is the main interface to the rest of the system as far as
 * 'managing functionality' of crash sensors (central/peripheral) is concerned.
 * It contains APIs for real-time data evaluation as well as all the different
 * background loops for monitoring and measurement tasks.
 * 
 * The sensor manager stores an internal array listing all crash sensors. This
 * array is used to call all the specific functions to read/monitor the
 * different sensors present in the system. This is done by registering
 * function pointers to the sensor specific functions for each sensor channel
 * during ECU initialization.
 *
 *
 *  Reference to Documentation:  sem_smr_sensormanager_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_smr_sensormanager Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_smr_sensormanager.h  $ */
/*  Revision 1.1 2019/09/05 11:16:44CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:05MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.10 2012/03/15 19:35:21IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor)  */
/*  merged from 5.9.1.3 */
/*  --- Added comments ---  bhs6kor [2012/03/16 05:08:00Z] */
/*  State changed: develop -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  kps1kor [2012/03/16 13:29:45Z] */
/*  State changed: reviewed -> release by kps1kor */
/*  Revision 5.9.1.3 2012/03/12 15:30:46IST bhs6kor  */
/*  updated after review */
/*  Revision 5.9.1.2 2012/02/16 16:02:20IST bhs6kor  */
/*  modelled in AMEOS */
/*  A_SMRMibSpiBufferIndex_U8R */
/*  V_SemNoSensorsSamplesRead_U8R */
/*  --- Added comments ---  bhs6kor [2012/02/23 09:25:31Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*  Revision 5.9.1.1 2011/11/23 21:09:42IST HKU2SI  */
/*  E_SMRSensorMgrState_XXR modelled in Ameos */
/*  Revision 5.9 2011/04/15 18:44:16IST HKU2SI  */
/*  rerun create code */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:38:50Z] */
/*  Delta review done by EPS3-Frueh. */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:38:50Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:39:06Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.8 2011/04/15 15:04:12CEST HKU2SI  */
/*  FLRTREACTION adapted predefined in SFT. */
/*  Only comment is changed */
/*  Revision 5.7 2011/02/25 10:10:47CET HKU2SI  */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:09:14Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:09:14Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.6 2011/01/31 09:30:04CET HKU2SI  */
/*  history adapted */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:07:42Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:07:47Z] */
/*  State changed: reviewed -> tested by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/02/04 13:07:52Z] */
/*  State changed: tested -> release by HKU2SI */
/*  Revision 5.5 2011/01/31 09:28:48CET HKU2SI  */
/*  SMR_CheckSignalPlausibility() description improved */
/*  Revision 5.3 2011/01/21 11:17:57CET HKU2SI  */
/*  CRQ_179 new plausibility function implemented */
/*  --- Added comments ---  HKU2SI [2011/01/21 10:57:39Z] */
/*  State changed: develop -> ready_for_review by HKU2SI */
/*  Revision 5.2 2010/10/26 11:47:01CEST fru1si  */
/*  Moved fault description comments to the mask definition so that both are found in one place. */
/*  --- Added comments ---  fru1si [2010/11/23 10:36:19Z] */
/*  Only comments moved inside the file. No change in resulting hex code. Previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/11/23 10:36:19Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.1 2010/08/05 10:04:29CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:15Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.4 2010/01/26 14:52:44CET fru1si  */
/*  Reverted name of API SMR_BeginSensorInitialisation to avoid conflict with ITM. */
/*  --- Added comments ---  fru1si [2010/02/15 08:25:57Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2010/02/15 08:37:55Z] */
/*  review:Ptedt00038969 */
/*  --- Added comments ---  fru1si [2010/02/15 08:38:25Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2010/02/23 11:32:37Z] */
/*  fix:Ptedt00043342 */
/*  --- Added comments ---  fru1si [2010/02/23 11:32:53Z] */
/*  fix:Ptedt00043342 */
/*  --- Added comments ---  fru1si [2010/03/05 11:51:19Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.3 2010/01/25 12:56:23CET fru1si  */
/*  - Introduced new APIs for 2ms and 100ms BG layer */
/*  - Renamed 10ms BG APIs for consistency */
/*  - Added check of SPI bits TST and NRO/EOP for PES during steady state */
/*  Revision 4.2 2009/10/12 13:34:56CEST fru1si  */
/*  Introduced new optional interface sem_csf_custsensorfaulthandler. This can be used */
/*  to implement additional fault handling actions when a line fault is qualified by the platform. */
/*  --- Added comments ---  fru1si [2009/10/14 13:24:33Z] */
/*  State changed: develop -> tested by fru1si */
/*  Revision 4.1 2009/09/25 13:21:39CEST fru1si  */
/*  Ran code generator to update type definition of te_SensorMgrStateList, but no functional change. */
/*  --- Added comments ---  fru1si [2009/10/02 14:45:58Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:36:53Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/10/02 16:37:01Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 4.0 2009/08/27 10:42:17CEST hku2si  */
/*  new ASI (algo sensor interface) located to main branch */
/*  reminder:  */
/*  check !!! attention te_SensorMgmStatusList is coded manually  */
/*  enumeration has to be removed properly */
/*  Revision 2.35 2009/08/20 09:54:22CEST fru1si  */
/*  Placed FLTDESC in ENUM section. */
/*  --- Added comments ---  fru1si [2009/08/20 08:21:40Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/08/20 08:22:43Z] */
/*  Only small change reviewed by walkthrough with ESW3-K�nzel. */
/*  --- Added comments ---  fru1si [2009/08/20 14:24:31Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/08/20 14:29:02Z] */
/*  State changed: tested -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/08/20 14:29:48Z] */
/*  Release granted by ESW3-Thiel on 2009/8/20. */
/*  --- Added comments ---  fru1si [2009/08/20 14:36:50Z] */
/*  fix:Ptedt00019602 */
/*  Revision 2.34 2009/07/28 16:04:16CEST fru1si  */
/*  In case of FltSEMConfiguration error all sensor relevant ITM tests are skipped to avoid hanging up of ITM which results in additional fault entries. */
/*  --- Added comments ---  fru1si [2009/07/28 14:12:43Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/07/28 14:14:01Z] */
/*  Re-ran code generator. */
/*  Revision 2.33 2009/07/27 14:36:17CEST fru1si  */
/*  When configuration fault is set, all affected ITM tests will be reported as skipped. */
/*  Otherwise the ITM hangs and the fault results in additional fault entries (e.g. ITM timeout). */
/*  Additionally adapted some comments and API descriptions in AMEOS. */
/*  Revision 2.32 2009/07/06 15:51:27CEST fru1si  */
/*  Added FLTDESC comment for FltSEMConfiguration used by Diagsym. */
/*  Revision 2.31 2009/03/12 16:00:28CET fru1si  */
/*  Moved state check from RTP module to public API in SMR module. */
/*  Revision 2.30 2009/02/02 13:17:19CET fru1si  */
/*  Added Diagsym mask definition for FltSEMConfigurationError. */
/*  Only comments changed so release status is taken over from previous revision. */
/*  --- Added comments ---  fru1si [2009/02/02 12:17:28Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/02/02 12:17:31Z] */
/*  Member revision set by fru1si */
/*  Revision 2.29 2008/12/18 17:00:47CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:16Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:24Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.28 2008/08/26 18:15:32CEST hkr2kor  */
/*  Daisy chain sensor initialisation function is now called from the SMR RT function. */
/*  --- Added comments ---  hkr2kor [2008/09/24 11:35:15Z] */
/*  State changed: develop -> ready_for_review by hkr2kor */
/*   */
/*  --- Added comments ---  hek3kor [2008/10/23 13:36:24Z] */
/*  REVIEWED AND BASELINED - Ptedt00008564, Ptedt00016033, Ptedt00016235 */
/*  --- Added comments ---  hek3kor [2008/10/23 13:36:26Z] */
/*  State changed: ready_for_review -> reviewed by hek3kor */
/*   */
/*  --- Added comments ---  hek3kor [2008/10/23 13:36:30Z] */
/*  State changed: reviewed -> release by hek3kor */
/*   */
/*  --- Added comments ---  hkr2kor [2008/11/24 15:12:18Z] */
/*  Member revision set by hkr2kor on variant CG107_Saphir */
/*  Revision 2.27 2008/07/31 17:38:31IST hkr2kor  */
/*  SMR_BackGroundMonitoring2 now has an input parameter.  */
/*  This is to avoid integration errors - Refer Ptedt00016033 */
/*  Revision 2.26 2007/10/19 20:58:03IST zuk2si  */
/*  review finding was corrected. */
/*  --- Added comments ---  zuk2si [2007/10/22 07:51:19Z] */
/*  State changed: develop -> tested by zuk2si */
/*   */
/*  --- Added comments ---  zuk2si [2007/10/22 07:51:24Z] */
/*  State changed: tested -> release by zuk2si */
/*  Revision 2.25 2007/10/12 17:31:39CEST zuk2si  */
/*  create_code done. */
/*  Revision 2.24 2007/10/12 16:33:55CEST zuk2si  */
/*  ts_SMRInternalSensorData was defined. */
/*   */
/*  Reason: */
/*  NEC CarGateM controller does not support a Multi-buffered-SPI.  */
/*  Hence data transmission is done via a SPI in compatibility mode. */
/*  The a.m. structure is necessary for a SPI in compatibility mode. */
/*  Revision 2.23 2007/01/30 15:33:35CET wjd2si  */
/*  Split the initialization state E_SMRConfiguring into three new states for central sensors, peripheral  */
/*  sensors and initialization of customer specific things. */
/*  --- Added comments ---  ngk2si [2007/02/01 16:09:36Z] */
/*  Performed delta review, no findings. */
/*  --- Added comments ---  ngk2si [2007/02/01 16:09:37Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  wjd2si [2007/03/02 07:05:00Z] */
/*  Tested by ESW3-Widmaier without findings. Set to release with two deviations */
/*  from the design guidelines ("100�s BG load rule") See approved deviations */
/*  N:\Process\Sw-QS\42_SoftwareRules\D.Deviations */
/*  --- Added comments ---  wjd2si [2007/03/02 07:05:00Z] */
/*  State changed: reviewed -> release by wjd2si */
/*  Revision 2.22 2006/07/31 15:30:20CEST wjd2si  */
/*  Renamed constant mask M_FltSemPasIfInitialisation_U8X to M_FltSemPasIfLineMapping_U8X to have a  */
/*  more flexible usage of the constant */
/*  --- Added comments ---  wjd2si [2006/07/31 13:47:02Z] */
/*  Inherited release state after review by EPD3-Angstmann on 31.07.2006 */
/*  --- Added comments ---  wjd2si [2006/07/31 13:47:03Z] */
/*  State changed: develop -> release by wjd2si */
/*  Revision 2.21 2006/07/25 15:27:03CEST wjd2si  */
/*  Added enum value E_SMRSensorMonitoringOff to enumeration te_SensorStatusList */
/*  (set for not monitored sensors) */
/*  --- Added comments ---  ngk2si [2006/07/25 15:33:21Z] */
/*  Delta review done by K.Angstmann, set to release as no code relevant change */
/*  --- Added comments ---  ngk2si [2006/07/25 15:33:22Z] */
/*  State changed: develop -> release by ngk2si */
/*  Revision 2.20 2006/07/20 15:40:40CEST ngk2si  */
/*  Added new Enum value for Sensor status (option test) */
/*  --- Added comments ---  ngk2si [2006/07/20 13:41:42Z] */
/*  delta review with J.Widmaier */
/*  --- Added comments ---  ngk2si [2006/07/20 13:41:43Z] */
/*  State changed: develop -> release by ngk2si */
/*  Revision 2.19 2006/06/03 15:18:23CEST ngk2si  */
/*  Removed not needed macros */
/*  Revision 2.18 2006/05/27 16:20:59CEST ngk2si  */
/*  Regenerated after architecure changes (only includes changed) */
/*  Revision 2.17 2006/05/22 17:51:25CEST ngk2si  */
/*  Updated after SDS review. */
/*  Revision 2.16 2006/05/16 13:54:08CEST ngk2si  */
/*  regenerated with updated CodeGen */
/*  Revision 2.15 2006/05/12 17:11:23CEST ngk2si  */
/*  Rerun with updated codegen, fixed one QAC finding. */
/*  Revision 2.14 2006/04/21 11:30:26CEST ngk2si  */
/*  Removed event based waiting for configuration data. Not needed as that is now ensured by ITM */
/*  Revision 2.13 2006/04/11 17:44:29CEST ngk2si  */
/*  Corrected QAC findings */
/*  Revision 2.12 2006/04/07 16:38:20CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.11 2006/04/03 13:00:30CEST ngk2si  */
/*  Regenerated with updated templates */
/*  Revision 2.10 2006/03/10 15:47:18CET ngk2si  */
/*  Regenerated with updated template */
/*  Revision 2.9 2006/02/28 17:14:20CET ngk2si  */
/*  Updated parameter access (now with macro in sensormgtpar.p). */
/*  Revision 2.8 2006/02/22 12:09:01CET ngk2si  */
/*  Updated description of FIQ function */
/*  Revision 2.7 2006/02/21 11:08:11CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 2.6 2006/02/07 18:10:39CET ngk2si  */
/*  Restructured data interfaces */
/*  Misra updated */
/*  Revision 2.5 2006/01/02 15:16:21CET ngk2si  */
/*  Changed architecture of sensor data interface */
/*  Revision 2.4 2005/12/28 13:11:20CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 2.3 2005/12/01 15:03:57CET ngk2si  */
/*  Added PasIF-Infit-Fault-Flag */
/*  Revision 2.2 2005/11/15 17:45:23CET ngk2si  */
/*  Made SMR_NoOperationFIQ a protected function so it can be used  */
/*  by specific sensor implementations (e.g. for deconfigured cases). */
/*  Revision 2.1 2005/10/25 18:27:00CEST ngk2si  */
/*  RT-Runtime optimization: centralised handling of no ini-data passing */
/*  Revision 2.0 2005/10/13 16:07:06CEST ngk2si  */
/*  C_Sample general rework */
/*  Revision 0.34 2005/04/21 11:11:05CEST kcl2si  */
/*  update due to codegen update for event listeners */
/*  Revision 0.33 2005/03/31 16:09:06CEST ngk2si  */
/*  Corrected Findings from Code Review */
/*  Revision 0.32 2005/03/23 18:21:52CET ngk2si  */
/*  Corrected Spelling mistake in API SMR_DisableChannelReading */
/*  Revision 0.31 2005/03/23 17:39:43CET ngk2si  */
/*  Improved handling of configuration faults */
/*  Revision 0.30 2005/03/21 12:03:31CET ngk2si  */
/*  - added pass-data parameter to cust-specific realtime hooks */
/*  - split internal data-mgm table to avoid padding of struct */
/*  Revision 0.29 2005/03/16 15:36:01CET ngk2si  */
/*  Added disable sensor CHANNEL api */
/*  Revision 0.28 2005/03/16 14:01:05CET ngk2si  */
/*  Architecture updated: separated smb460 specific stuff from global centralsensors-module */
/*  Revision 0.27 2005/03/09 11:49:03CET ngk2si  */
/*  Corrections after first peripheralsensor tests */
/*  Revision 0.26 2005/03/02 13:50:59CET ngk2si  */
/*  RTRTed Version, used for 1st unit test */
/*  Revision 0.25 2005/02/22 19:38:00CET ngk2si  */
/*  Rework after changes to sensor data interface */
/*  Revision 0.24 2005/02/18 22:39:40CET fsa2si  */
/*  Architecture and Code Gen Update */
/*  Revision 0.23 2005/02/18 16:10:37CET ngk2si  */
/*  temporary version for code-gen-change */
/*  Revision 0.22 2005/02/14 19:28:41CET ngk2si  */
/*  Corrected naming of PDI-variables containing the sensor data */
/*  Revision 0.21 2005/02/10 17:25:14CET ngk2si  */
/*  Minor changes, re-checkin to get rid of merger warnings */
/*  Revision 0.20 2005/02/04 15:04:08CET ngk2si  */
/*  Reworked after SAS review */
/*  Revision 0.19 2005/01/14 17:08:21CET ngk2si  */
/*  several architecture updates, adapted API-descriptions to new template */
/*  Revision 0.18 2004/12/30 17:21:27CET ngk2si  */
/*  End of year 2004 Edition */
/*  Revision 0.17 2004/12/10 14:52:29CET ngk2si  */
/*  New Checkin because of changes in the build-script */
/*  Revision 0.16 2004/12/01 17:58:45CET ngk2si  */
/*  architecture adaptations, new code_gen script (runtime tooling) */
/*  Revision 0.15 2004/11/19 17:10:25CET ngk2si  */
/*  Div changes */
/*  Revision 0.14 2004/11/03 15:53:21CET ngk2si  */
/*  Merged with Alex changes */
/*  Revision 0.13 2004/10/27 10:52:16CEST ngk2si  */
/*  Architecture rework */
/*  Revision 0.12 2004/10/23 17:15:37CEST ngk2si  */
/*  fixed small bug caused by code generation */
/*  Revision 0.11 2004/10/23 16:57:47CEST ngk2si  */
/*  Major architecture rework */
/*  Revision 0.10 2004/10/20 12:12:19CEST ngk2si  */
/*  tmporary development version */
/*  Revision 0.9 2004/10/15 17:57:32CEST ngk2si  */
/*  Added plausibility test */
/*  Revision 0.8 2004/10/14 14:13:34CEST jan2si  */
/*  differences for stack calculation tooling */
/*  Revision 0.7 2004/10/07 18:31:37CEST ngk2si  */
/*  Should compile again, several architecture changes */
/*  Revision 0.6 2004/09/14 14:40:15CEST ngk2si  */
/*  small architecture changes */
/* EasyCASE - */
/*  Revision 0.5 2004/09/07 17:02:21CEST ngk2si  */
/*  Made some architecture changes, should again compile */
/*  Revision 0.4 2004/08/04 16:40:32CEST ngk2si  */
/*  Adopted names to conventions */
/*  Revision 0.3 2004/07/30 15:05:53CEST ngk2si  */
/*  div changes in code generation */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_smr_sensormanager_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#include "spi_spi_spidriver.h" 
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_smr_sensormanager_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_smr_sensormanager)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 27
   Utility Macros */
/* checks if value is in beween two other values: returns 1 if yes, 0 if no. */
#define Z_BETWEEN(x, min, max) ( ((x) >= (min)) AND_THEN ((x) <= (max)) )

/* extracts the acutal sensor data (the 10 lowest bits) from the SPI message,
 * This is done by two shifts because the 10 bit are in 2s-complement
 */
#define Z_ExtractSensorData(x) (((S16)((x) << 6u)) >> 6u)
/* EasyCASE ) */
/* EasyCASE ( 23462
   SPI stuff */
/* Min/max valid SPI sensor signals */
#define C_MaxValidSensorValue_S16X 480   /* the maximum valid sensor signal */
#define C_MinValidSensorValue_S16X -480  /* the minimum valid sensor signal */
/* EasyCASE ) */
/* EasyCASE ( 23485
   FltSEMConfiguration detailed information */
/* Masks for additional fault info of FltSEMConfiguration error. */
                                                /*! DEF MASKS SEMConfigFlt */
#define M_FltSemAddSensorChannel_U8X    0x01u   /*! 00: Error while adding channels to sensormanagement table */
#define M_FltSemInvalidPasType_U8X      0x02u   /*! 01: Invalid PES type in configuration */
#define M_FltSemInvalidCsType_U8X       0x04u   /*! 02: Invalid CS type in configuration */
#define M_FltSemPasIfLineMapping_U8X    0x08u   /*! 03: Invalid PES-IF line mapping */
#define M_FltSemOutOfPasSpecificRam_U8X 0x10u   /*! 04: Not enough RAM for PES specific data */
                                                /*! END DEF */
/* EasyCASE - */
/*! FLTDESC MASKS SEMConfigFlt FltSEMConfiguration: Configuration fault in sensor parameters */
/* EasyCASE - */
/*! FLTREACTION FltSEMConfiguration: E_IdleModeForCurrentPon */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_smr_sensormanager)  Enums*/
/*#end ACD#*/
/*
 * Sensor management background execution parts. Used to split up runtime of BG
 * monitoring.
 */
typedef enum
{
   E_SEMBGExecutionPart1,
   E_SEMBGExecutionPart2,
   E_SEMBGExecutionPart3
} te_SEMBGExecutionPart;
/*! DEF ENUM te_SEMBGExecutionPart */
   /*! E_SEMBGExecutionPart1: Background execution part 1              */
   /*! E_SEMBGExecutionPart2: Background execution part 2              */
   /*! E_SEMBGExecutionPart3: Background execution part 3              */
/*! END DEF */
/* EasyCASE - */
/*
 * Encodes the system wide public state of a peripheral sensor. This status is
 * filtered.
 * 
 * Not all states are used by all types of sensors.
 * 
 * Attention: the order is important! Especially the initialization states have
 * to be in the order Init1 ... InitDone!
 */
typedef enum
{
   E_SMRSensorOK,
   E_SMRSensorSwitchedOff,
   E_SMRSensorInitializing1,
   E_SMRSensorInitializing2,
   E_SMRSensorInitializing3,
   E_SMRSensorInitializingDone,
   E_SMRSensorInitializingError,
   E_SMRSensorError,
   E_SMRSensorErrorAndOff,
   E_SMRSensorDead,
   E_SMRNoSensorConfigured,
   E_SMRSensorOptionTest,
   E_SMRSensorMonitoringOff
} te_SensorStateList;
/*! DEF ENUM te_SensorStateList */
   /*! E_SMRSensorOK: Sensor operating normally                */
   /*! E_SMRSensorSwitchedOff: Sensor switched off                      */
   /*! E_SMRSensorInitializing1: Sensor init phase I                      */
   /*! E_SMRSensorInitializing2: Sensor init phase II                     */
   /*! E_SMRSensorInitializing3: Sensor init phase III                    */
   /*! E_SMRSensorInitializingDone: Sensor init done - waiting for SW to finish */
   /*! E_SMRSensorInitializingError: Error during init - some init tasks left */
   /*! E_SMRSensorError: Disabled temporarily because of an error */
   /*! E_SMRSensorErrorAndOff: Switched off while in temporary error    */
   /*! E_SMRSensorDead: Disabled for the PON cycle               */
   /*! E_SMRNoSensorConfigured: Sensor configured as absent              */
   /*! E_SMRSensorOptionTest: Sensor doing option test (check if really absent) */
   /*! E_SMRSensorMonitoringOff: Sensor monitoring disabled               */
/*! END DEF */
/* EasyCASE - */
/*
 * Encodes the sensor manager's overall state.
 * 
 * Attention: The order is important, so don't change it without thorough
 * consideration!
 */
typedef enum
{
   E_SMRInit,
   E_SMRIdleMode,
   E_SMRConfiguringCS,
   E_SMRConfiguringPES,
   E_SMRConfiguringCust,
   E_SMRStartRtReading,
   E_SMRStartUp,
   E_SMRSteadyState
} te_SensorMgrStateList;
/*! DEF ENUM te_SensorMgrStateList */
   /*! E_SMRInit: Initial sensor manager state             */
   /*! E_SMRIdleMode: Sensor manager idle state                */
   /*! E_SMRConfiguringCS: State for configuring central sensors    */
   /*! E_SMRConfiguringPES: State for configuring peripheral sensors */
   /*! E_SMRConfiguringCust: State for configuring customer specific sensors */
   /*! E_SMRStartRtReading: Start reading of receive registers via SPI */
   /*! E_SMRStartUp: Finish up sensor/ASIC initialization     */
   /*! E_SMRSteadyState: Steady state during normal operation     */
/*! END DEF */
/* EasyCASE - */
/*#ACD# M(Enums sem_smr_sensormanager leadout)  Enums*/
/* EasyCASE - */
/* Type definition for the function pointers pointing to the sensor specific
 * data evaluation functions.
 * Parameters are: U16 v_RawData_u16r, U8 v_SensorIndex_u8r, U8 v_ChannelIndex_u8r
 */
typedef void (*tp_SensorSpecificFunction) (U16, U8, U8);
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Protected Data Interfaces (description) */
/* EasyCASE (
   PDI: te_SensorMgrStateList E_SMRSensorMgrState_XXR */
/*
 * Encodes the sensor manager's overall state
 */
/* Declaration of te_SensorMgrStateList E_SMRSensorMgrState_XXR can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE (
   SMR_Init */
/******************************************************************************
 * Description:
 *     Called during startup, this function's main task is to set variables to
 *     a safe default value. Since all memory is automatically initialized to 0
 *     this function only sets variables for which the default is different
 *     than 0.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once during ECU startup.
 * 
 * Usage guide:
 *    Must be called before the system starts its normal operation (background
 *    loops etc).
 * 
 * Remarks:
 *    As the configuration data is not yet loaded, a complete initialization is
 *    not possible at this point. Here only fixed defaults are set.
 *    Configuration data is evaluated in the background loops.
 ******************************************************************************/
void SMR_Init( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_ReadSensorsFIQ */
/******************************************************************************
 * Description:
 *    This function handles the real-time reading of crash sensors and triggers
 *    the data evaluation. Communication with the sensors (or the PES interface
 *    to be more precise) is done via SPI. TI controllers use a multi-buffered
 *    SPI (MibSPI), NEC uses a similar approach (DMA mode).
 * 
 *    This API does two things:
 *    - fetch the data received from the sensor (via PES interface) from the
 *      MibSPI buffers.
 *    - call sensor specific real-time processing methods and pass the data for
 *      evaluation.
 * 
 *    Additionally, if daisy chain sensors are present, this function calls the
 *    daisy chain initialization function.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    - Has to be called close to the beginning of every real-time cycle
 *      (before algorithm).
 *    - As it uses the MibSPI, it is important that the MibSPI transfer has
 *      been started before calling this function (the transfer does not need
 *      to be finished, as this function will wait for the availability of
 *      every data word).
 *    - Ideally the MibSPI should have a head start, so that no waiting is
 *      necessary. Therefore having a few microseconds between starting the
 *      transfer group and calling this function is preferable.
 *    - The daisy chain initialization function may only be called after all
 *      the sensor data has been processed.
 * 
 * Remarks:
 *    This function obviously needs to be highly runtime optimized. Because of
 *    that and because of the many different supported sensor types the sensor
 *    specific data processing methods are called via function pointers stored
 *    inside this module.
 ******************************************************************************/
void SMR_ReadSensorsFIQ( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_Background2ms */
/******************************************************************************
 * Description:
 *    This function acts as the interface to the rest of the system for all
 *    sensor tasks running in the 2ms background layer (central and peripheral
 *    sensors). The API is placed in a 2ms BG container in the background loops
 *    module. It's only job is to call all sensor related 2ms background
 *    functions, e.g. CG974 line measurements.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    2ms background
 * 
 * Usage guide:
 *    Called by background loops.
 * 
 * Remarks: -
 ******************************************************************************/
void SMR_Background2ms( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_Background10msInitAndCS */
/******************************************************************************
 * Description:
 *    This function controls part of the cyclic monitoring of crash sensors.
 * 
 *    It has two responsibilities:
 *    - during system init organize calling of the different sensor init
 *      functions from sensor specific modules. This is done for central and
 *      peripheral sensors together.
 *    - during steady state operation call the sensor specific monitoring
 *      functions for central sensors.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms background
 * 
 * Usage guide:
 *    Called by background loops.
 * 
 * Remarks:
 *    Peripheral sensors are monitored in SMR_Backgroung10msPES (split because
 *    of runtime restrictions).
 ******************************************************************************/
void SMR_Background10msInitAndCS( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_Background10msPES */
/******************************************************************************
 * Description:
 *    This function controls the second part of the cyclic monitoring of crash
 *    sensors, i.e. the monitoring of external sensors.
 * 
 * Arguments:
 *    - e_bgexecpart_xxr: BG execution part 1 or 2 or 3
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms background
 * 
 * Usage guide:
 *    Called by background loops.
 * 
 * Remarks:
 *    The initialization for all sensors is done inside
 *    SMR_Background10msInitAndCS. The split of steady state monitoring into
 *    two 10ms BG functions was necessary due to runtime restrictions.
 * 
 *    This function is called three times from different containers of the 10ms
 *    BG loop. Each time one execution part is called. This was necessary since
 *    the peripheral sensors' background function took huge runtime and had to
 *    be split into 3 parts to bring the runtime to acceptable limits.
 ******************************************************************************/
void SMR_Background10msPES(te_SEMBGExecutionPart e_bgexecpart_xxr );
/* EasyCASE ) */
/* EasyCASE (
   SMR_Background100ms */
/******************************************************************************
 * Description:
 *    This function acts as the interface to the rest of the system for all
 *    sensor tasks running in the 100ms background layer. The API is placed in
 *    a 100ms BG container in the background loops module. It's only job is to
 *    call all sensor related 100ms background functions, e.g. PPS absolute
 *    pressure checks.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    100ms background
 * 
 * Usage guide:
 *    Called by background loops.
 * 
 * Remarks: -
 ******************************************************************************/
void SMR_Background100ms( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_BeginSensorInitialisation */
/******************************************************************************
 * Description:
 *    Informs the sensor manager to begin the initialization of crash sensors.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once during ECU startup.
 * 
 * Usage guide:
 *    To be called by ITM at the beginning of system initialization. Before
 *    calling this API make sure that:
 *    - basic uC tests (fast ROM & RAM tests, ADC, chip select and SPI tests)
 *      are finished
 *    - software version check has been passed
 *    - energy reserve test is not running
 *    - sensor EEPROM config data has been loaded
 * 
 * Remarks:
 *    This function only sets a state. The "real" initialization starts with
 *    the 10ms BG monitoring.
 ******************************************************************************/
void SMR_BeginSensorInitialisation( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_EnableDataPassing */
/******************************************************************************
 * Description:
 *     Called at the end of the initialization phase to switch on the provision
 *     of acquired sensor data to the rest of the system (especially the
 *     algorithm). Before that call the sensor data output will stay at 0. This
 *     API also enables the monitoring of sensor signals by the SCON, which is
 *     disabled during the init phase.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once during ECU startup.
 * 
 * Usage guide:
 *    Needs to be called once by ITM. Before calling this API make sure that:
 *    - all sensor tests (PES/central/roll over) are finished
 *    - EOP is sent to central sensors
 *    - all power stage tests are finished
 *    - SVR test is finished
 * 
 * Remarks: -
 ******************************************************************************/
void SMR_EnableDataPassing( void );
/* EasyCASE ) */
/* EasyCASE (
   SMR_SetDCInitPulseMaskFIQ */
/******************************************************************************
 * Description:
 *    This API triggers the PLH module to program the next sync pulse mask in
 *    order to generate init commands for daisy chain sensors.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This API must be called from the realtimeprocess module if daisy chain
 *    sensors are used. Preferrably it should be called at the end so that
 *    sensor reading and algo calculation are not disturbed/delayed.
 * 
 * Remarks: -
 ******************************************************************************/
void SMR_SetDCInitPulseMaskFIQ( void );
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   SMR_CheckSignalPlausibility */
/******************************************************************************
 * Description:
 *    Utility-function that does the sensor signal plausibility test:
 *     Is signal greater than value x?
 *        Yes: increment counter
 *     Is signal less than value x?
 *        Yes: decrement counter
 *     Otherwise
 *        No : reset counter back to 0.
 * 
 *    The plausibility can only be checked if the sensor delivered a valid
 *    value. If not the counter will remain unchanged.
 * 
 * Arguments:
 *    - v_sensordata_s16r:      the sensor data to be checked
 *    - p_counter_s16r:         pointer to (signed!) counter
 *    - v_signalThreshold_s16r: threshold for the signal strength (x), !!! only
 *      positive values are allowed because an absolute value is expected. (If
 *      v_sensordata_s16r is negative function SMR_ChkSignalPlausiSteps()
 *      internally inverts the threshold to perform the threshold comparison.)
 *    - e_signalValid_xxr:      indicates if the sensor data is valid (valid =
 *      E_True)
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms background: called once for each sensor channel.
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    This is a pure function that depends only on the parameters.
 * 
 *    Algorithm:
 *      if signal > signal_threshold (e.g. 2g)
 *         counter = MAX (0, counter) + 1
 *      elseif signal < - signal_threshold
 *         counter = MIN (0, counter) -1
 *      else
 *         counter = 0
 ******************************************************************************/
void SMR_CheckSignalPlausibility(S16 v_sensordata_s16r, S16 * p_counter_s16r, S16 v_signalThreshold_s16r, te_Boolean e_dataValid_xxr );
/* EasyCASE ) */
/* EasyCASE (
   SMR_ChkSignalPlausiSteps */
/******************************************************************************
 * Description:
 *     Utility function that performs the sensor signal plausibility test
 *     similar to SMR_CheckSignalPlausibility. Additionally the step size for
 *     plausibility counter update is passed by the function argument
 *     v_Step_u8r.
 * 
 *     Is signal greater than value x?
 *        Yes: increment counter
 *     Is signal less than value x?
 *        Yes: decrement counter
 *     Otherwise
 *        No : reset counter back to 0.
 * 
 *     The plausibility can only be checked if the sensor delivers a valid
 *     value. If not the counter will remain unchanged.
 * 
 * Arguments:
 *     - v_sensordata_s16r    : sensor data to be checked
 *     - p_counter_s16r       : pointer to (signed!) counter
 *     - v_signalThreshold_u8r: threshold for the sensor signal (x)
 *     - v_Step_u8r           : step size to update the plausibility counter
 *     - e_signalValid_xxr    : indicates if the sensor data is valid (valid =
 *       E_True)
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms background: called once for each sensor channel.
 * 
 * Usage guide:
 *    -
 * 
 * Remarks:
 *     This is a pure function that depends only on the parameters.
 * 
 *     Algorithm:
 *       if signal > signal_threshold (e.g. 2g)
 *          counter = MAX (0, counter) + v_Step_u8r
 *       elseif signal < - signal_threshold
 *          counter = MIN (0, counter) - v_Step_u8r
 *       else
 *          counter = 0
 ******************************************************************************/
void SMR_ChkSignalPlausiSteps(S16 v_sensordata_s16r, S16 * p_counter_s16r, U16 v_signalThreshold_u16r, U8 v_Step_u8r, te_Boolean e_dataValid_xxr );
/* EasyCASE ) */
/* EasyCASE (
   SMR_AddSensorChannel */
/******************************************************************************
 * Description:
 *    Adds a sensor channel to the sensor manager's internal table. It has to
 *    be called with data for every sensor read command (central1, central2 ...
 *    pes1old, pes1new ...).
 * 
 * Arguments:
 *    - v_spicommand_u16r : read command for sensor sent via SPI
 *    - e_spidevice_xxr   : the SPI device to which this sensor is connected
 *      (only without SCON monitoring set!)
 *    - v_sensor_u8r      : index of the sensor in the data structures
 *    - v_channel_u8r     : index of the sensor channel in the sensor data
 *      interface
 *    - p_realtimeeval_xfr: function pointer to the sensor's real-time data
 *      evaluation
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven: called during Init2.
 * 
 * Usage guide:
 *    Each module that has to read an SPI-connected sensor in real-time (e.g.
 *    sem_cs_centralsensors, PES-IF specific modules) has to call this API once
 *    for each sensor value to be read. It must only be called during the Init2
 *    phase (after configuration data is available). If this is violated,
 *    passed parameters are detected to be invalid, or it is called too often
 *    so that not enough indices are available in the internal management
 *    table. In this case the SEMConfiguration fault will be set! The arguments
 *    v_sensor_u8r/v_channelIndex_u8r are later used as parameters for the
 *    real-time evaluation function.
 * 
 * Remarks:
 *    Note that the indices are not unique as they might refer to different
 *    data structures (e.g. for central or peripheral sensors).
 ******************************************************************************/
void SMR_AddSensorChannel(U16 v_spicommand_u16r, te_SpiDeviceList e_spidevice_xxr, U8 v_sensor_u8r, U8 v_channel_u8r, tp_SensorSpecificFunction p_realtimeeval_xfr );
/* EasyCASE ) */
/* EasyCASE (
   SMR_DisableChannelEvaluation */
/******************************************************************************
 * Description:
 *    Disables the real-time evaluation of a sensor channel for the rest of the
 *    POC.
 * 
 *    After calling this function the sensor will still be read in real-time,
 *    however, without SCON monitoring set. Therefore the SCON will react no
 *    longer to this sensor). Additionally the real-time evaluation function
 *    will no longer be called.
 * 
 * Arguments:
 *    - e_SPIDevice_xxr: sensor device as specified in the SPI (chipselect)
 *      definition.
 *    - v_channel_u8r  : index of the sensor channel as specified in the
 *      SMR_AddSensorChannel API.
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven: in 10ms BG after sensor errors that disable the sensor for
 *    the POC.
 * 
 * Usage guide:
 *    Call this API to disable the sensor channel evaluation for a sensor which
 *    is disabled for the POC. Note that one call will only disable a single
 *    channel, so for a standard asynchronous PES you have to call it twice
 *    (old and new value).
 * 
 *    ATTENTION: It is important to set the channel's data output variable to 0
 *    and clear the "data valid" bit. Otherwise as the real-time data
 *    evaluation of the sensor will no longer be called afterwards the old data
 *    output would remain. This needs to be done by the caller!
 * 
 * Remarks:
 *    The identification of the sensor via the SPI device is a bit tricky and
 *    not extremely elegant. However, it is the only possibility, as the sensor
 *    specific modules know nothing about the indices in the sensor management
 *    table and the indices stored inside the sensor manager are not unique -
 *    but fortunately the combination of SPI device and index is unique.
 * 
 *    The evaluation is disabled by clearing the SCON monitoring chipselect.
 ******************************************************************************/
void SMR_DisableChannelEvaluation(te_SpiDeviceList e_SPIDevice_xxr, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   SMR_SensorCfgError */
/******************************************************************************
 * Description:
 *    Called by other sensor modules (e.g. SMB460) to inform the sensor manager
 *    that a configuration fault was detected.
 * 
 *    As this indicates a severe problem, it will lead to the deactivation of
 *    all sensors and set a SEMConfiguration fault!
 * 
 * Arguments:
 *    - v_faultDetails_u8r: detailed information to be stored together with the
 *      fault
 * 
 * Return: -
 * 
 * Scheduling:
 *    Event-driven
 * 
 * Usage guide: -
 * 
 * Remarks: -
 * 
 ******************************************************************************/
void SMR_SensorCfgError(U8 v_faultDetails_u8r );
/* EasyCASE ) */
/* EasyCASE (
   SMR_NoOperationFIQ */
/******************************************************************************
 * Description:
 *    As the name implies this function does nothing. It is merely used as a
 *    secure default value in the function pointer array for the real-time
 *    sensor evaluation.
 * 
 * Arguments:
 *    The arguments are only for compatibility of the function call, but they
 *    are not used.
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *   This function is called by the sensor management, e.g. for sensors that
 *   are disabled or not configured.
 * 
 * Remarks: -
 ******************************************************************************/
void SMR_NoOperationFIQ(U16 v_RawData_u16r, U8 v_SensorIndex_u8r, U8 v_ChannelIndex_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
