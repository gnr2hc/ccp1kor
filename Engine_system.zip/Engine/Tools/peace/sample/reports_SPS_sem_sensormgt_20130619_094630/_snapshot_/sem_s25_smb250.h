/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_s25_smb250.h */
#ifndef Y_sem_s25_smb250H
#define Y_sem_s25_smb250H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_s25_smb250 Header Author) Author*/
/*  $Source: sem_s25_smb250.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific Module for SMB250 series single channel central acceleration sensor.
 * 
 * The SMB250 features one in plane measurement axis with a measurement range
 * of 96g. It is typically used for X-plausibility. The communication with the
 * SMB250 is done via the SPI.
 * 
 * This module contains the sensor specific initialistion and background
 * monitoring tasks.
 *
 *
 *  Reference to Documentation:  sem_s25_smb250_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_s25_smb250 Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_s25_smb250.h  $ */
/*  Revision 1.1 2019/09/05 11:16:44CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:02MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.6 2012/06/18 20:03:16IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor)  */
/*  new plausi handling added */
/*  --- Added comments ---  bhs6kor [2012/06/18 14:39:09Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/27 11:34:02Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/29 09:16:46Z] */
/*  State changed: reviewed -> release by bhs6kor */
/*  Revision 5.5 2011/04/19 10:48:17MESZ HKU2SI  */
/*  sensor has only 1 channel. Fault reaction, fault description changed */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:29:00Z] */
/*  Delta review done by EPS3-Frueh. */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:29:00Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:41:10Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.4 2011/04/18 17:31:33CEST HKU2SI  */
/*  comment for fault reaction and fault description reworked */
/*  Revision 5.3 2011/02/25 10:06:58CET HKU2SI  */
/*  sem_s20_smb200 */
/*  --- Added comments ---  HKU2SI [2011/02/25 09:08:18Z] */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:37Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:37Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.2 2011/01/04 14:56:48CET bhs6kor  */
/*  updated after review */
/*  --- Added comments ---  bhs6kor [2011/01/06 09:03:24Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2011/02/18 08:48:27Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:38:10Z] */
/*  REVIEWED AND BASELINED */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:38:10Z] */
/*  State changed: reviewed -> release by rdd3kor */
/*  Revision 5.1 2010/08/05 13:34:30IST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:44Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.1 2009/09/29 15:15:40CEST hku2si  */
/*  module generated with AMEOS AB10 from main path */
/*  Revision 4.0 2009/08/27 12:04:21CEST hku2si  */
/*  new ASI (algo sensor interface) located to main branch */
/*  Revision 2.11.1.1 2009/03/11 12:12:37CET hku2si  */
/*  new sensor interface introduced (sem_std_sensortypedefs.h) */
/*  Revision 2.11 2008/12/18 17:00:58CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:22Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:32Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.10 2006/08/15 15:23:46CEST ngk2si  */
/*  Fixed one Misra finding: BITE thresholds are now signed constants */
/*  --- Added comments ---  ngk2si [2006/08/15 13:25:13Z] */
/*  Delta review with G.Heilmann, no findings */
/*  --- Added comments ---  ngk2si [2006/08/15 13:25:13Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2006/08/23 13:19:29Z] */
/*  SDT passed sucessfully (v2.3.1.1) */
/*  --- Added comments ---  ngk2si [2006/08/23 13:19:29Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 2.9 2006/07/27 16:58:25CEST ngk2si  */
/*  Background monitoring in steady state split into three states (for BG runtime reduction) */
/*  Revision 2.8 2006/07/10 14:24:44CEST ngk2si  */
/*  Updated Thresholds for BITE after new imput from EPD4. */
/*  Revision 2.7 2006/05/27 16:19:23CEST ngk2si  */
/*  Updated after code review of cs_centralsensors, updated average signal calculation */
/*  --- Added comments ---  ngk2si [2006/06/22 16:36:59Z] */
/*  review with J.Widmaier, 22.06.06 */
/*  --- Added comments ---  ngk2si [2006/06/22 16:36:59Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.6 2006/05/16 13:53:24CEST ngk2si  */
/*  - new SPI API names */
/*  - regenerated with updated CodeGen */
/*  - new StepUpIni Return type */
/*  - improved commenting */
/*  Revision 2.5 2006/04/11 17:44:30CEST ngk2si  */
/*  Corrected QAC findings */
/*  Revision 2.4 2006/04/07 16:38:14CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.3 2005/12/28 13:11:18CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 2.2 2005/12/12 18:32:42CET ngk2si  */
/*  Corrected ini-sequence: switching of Offset-cancellation */
/*  Revision 2.1 2005/11/11 10:32:36CET ngk2si  */
/*  Added handling for not configured sensors */
/*  Revision 2.0 2005/11/08 18:30:45CET ngk2si  */
/*  1st working version. */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_s25_smb250_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_s25_smb250_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_s25_smb250)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 914
   SPI Commands for SMB250 */
#define C_SMB250SPIReadChannel_U16X             0x8000u  /* Read sensor channel */

#define C_SMB250SPIReadDeviceID_U16X            0x0000u  /* Read Device ID */
#define C_SMB250SPIReadRevisionID_U16X          0x0600u  /* Read Revision ID */

/* commands for inital tests */
#define C_SMB250SPIOffsetCancellationON_U16X    0x7801u  /* switch on offset cancellation */
#define C_SMB250SPIOffsetCancellationOFF_U16X   0x7800u  /* switch off offset cancellation */
#define C_SMB250SPIReadOffsetCancellation_U16X  0x7A00u  /* Read Offset cancellation status */

#define C_SMB250SPIDemandBite1_U16X             0x3801u  /* Selftest: Channel pos  */
#define C_SMB250SPIDemandBite2_U16X             0x3802u  /* Selftest: Channel neg */
#define C_SMB250SPIDemandBiteOFF_U16X           0x3800u  /* Selftest: off  */

#define C_SMB250SPIEOPCommand_U16X              0x0C00u  /* End of programming */
/* EasyCASE ) */
/* EasyCASE ( 915
   Masks */
/* Mask for monitoring data SPI-message */
#define M_SMB250OffsetStatusAfterEOP_U16X   0x1002u  /* slow offset cancellation active */

#define M_SMB250OffsetCancellationFast_U8X  0x03u    /* fast offset cancellation active */
#define M_SMB250OffsetCancellationOff_U8X   0x00u    /* offset cancellation off */
/* EasyCASE ) */
/* EasyCASE ( 916
   HW-Constants */
#define C_SMB250DeviceID_U8X                    0x10u   /* Device ID of SMB250 */

#define C_SMB250AverageExp_U8X                     4u   /* number of realtime measurements used for an averaged signal,
                                                         * specified in 2^x fashion (4 => 16 samples) */

/* Offset check */
#define C_SMB250OffsetDelay_U16X                150u    /* delay till fast offset cancellation can be evaluated (ms) */
#define C_SMB250OffsetTreshold_U16X             0x0Au   /* threshold for offset cancellation check (2g) */

/* BITE */
#define C_SMB250BiteDelay_U16X                   50u    /* delay till Bite can be evaluated (ms) */
#define C_SMB250BiteOffDelay_U16X                10u    /* delay between Bite-Off-Command and TST-Bit cleared */
#define C_SMB250BiteMinThreshold_S16X            120    /* minimum threshold for the BITE test */
#define C_SMB250BiteMaxThreshold_S16X            389    /* maximum threshold for the BITE test */
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicPlausiProgramming: E_NoDisable */
/*! FLTREACTION FltCsAsicPlausiInternalMonitoring: E_NoDisable */
/* EasyCASE - */
/*! FLTREACTION FltCsChannel1PlausiBITE: E_NoDisable */
/*! FLTREACTION FltCsChannel1PlausiOffsetCancellation: E_NoDisable */
/*! FLTREACTION FltCsChannel1PlausiCommunication: E_NoDisable */
/*! FLTREACTION FltCsChannel1Plausibility: E_NoDisable */
/* EasyCASE - */
/*! FLTDESC FltCsAsicPlausiProgramming: !!!-X Sensor: Programming failed */
/*! FLTDESC FltCsAsicPlausiInternalMonitoring: !!!-X Sensor: internal monitoring error */
/* EasyCASE - */
/*! FLTDESC FltCsChannel1PlausiBITE: !!!-X Sensor Ch 1: selftest failed */
/*! FLTDESC FltCsChannel1PlausiOffsetCancellation: !!!-X Sensor Ch 1: offset cancellation failed */
/*! FLTDESC FltCsChannel1PlausiCommunication: !!!-X Sensor Ch 1: communication error (SPI) */
/*! FLTDESC FltCsChannel1PlausiPlausibility: !!!-X Sensor Ch 1: sensor signal plausibility error */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_s25_smb250)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_s25_smb250 leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 923
   enum te_SMB250Status */
/* EasyCASE < */
/* This enum encodes the states of a smb250 sensor */
typedef enum
{
  E_SMB250NotConfigured,                     /* sensor is not configured */
  E_SMB250SensorDisabled,                    /* sensor disabled because of a fault */
  E_SMB250InitCalcRawOffset,                 /* start calculation of raw offset */
  E_SMB250InitEvalRawOffset,                 /* Calculate the raw offset */
  E_SMB250InitStartFastOffsetCancellation,   /* start fast offset cancellation */
  E_SMB250InitWaitForOffsetCancellation,     /* wait for fast offset cancellation */
  E_SMB250InitEvalOffsetCancellation,        /* evaluate result of fast offset cancellation */
  E_SMB250InitStartBite1,                    /* start build in self test */
  E_SMB250InitWaitForBite1,                  /* wait for bite 1 settling time */
  E_SMB250InitSwitchBite2,                   /* switch to bite 2 test */
  E_SMB250InitWaitForBite2,                  /* wait for bite 2 settling time */
  E_SMB250InitEvalBite,                      /* evaluate result of bite test */
  E_SMB250InitCheckTestModeOff,              /* check if Testmode is off */
  E_SMB250InitEvaluateErrorsAndEOP,          /* evaluate the initalisation error and send EOP */
  E_SMB250SteadyState1,                      /* sensor is in steady state 1 (do nothing) */
  E_SMB250SteadyState2,                      /* sensor is in steady state 2 (do nothing) */
  E_SMB250SteadyState3                       /* sensor is in steady state 3 (communication check) */
} te_SMB250Status;
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   S25_Init */
/******************************************************************************
 * Description:
 *    Initialises the handling for one SMB250. This includes:
 *    - checking if the sensor type is correct, that means if this module
 *      really accesses a SMB250
 *    - extracting configuration data and adding it to the management tables in
 *      centralsensors module
 *    - setting the initial sensor/channel states
 *    - initiating the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the first channel of this sensor, this
 *      index is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    The number of channels this sensor has, for a smb250 this is 1.
 * 
 * Scheduling:
 *    Called once in 10ms background after cfg-data is availible.
 * 
 * Usage guide: -
 * 
 * Remarks:
 * The below Permanent Faults are checked for stored state using Central sensor
 * API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared.
 ******************************************************************************/
U8 S25_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   S25_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialisation or continous cyclic monitoring.
 * 
 * Arguments:
 *    - v_asic_u8r: the sensor for which to do the monitoring
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms
 * 
 * Usage guide:
 *    called by centralsensors-module once for each smb250 in each 10ms
 *    background cycle.
 * 
 * Remarks: -
 ******************************************************************************/
void S25_BackgroundMonitoring10ms(U8 v_asic_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
