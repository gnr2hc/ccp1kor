/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_pp2_pps2.h */
#ifndef Y_sem_pp2_pps2H
#define Y_sem_pp2_pps2H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_pp2_pps2 Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pp2_pps2.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * This module contains the specific implementation for the PPS2 and PPS3
 * peripheral pressure sensors.
 * 
 * It mainly features:
 * - real-time data evaluation
 * - background monitoring
 * 
 * The PPS2/PPS3 is a pressure sensor that transmits two types of pressure data:
 * - relative pressure changes: this is the "real" data that is used for the
 *   crash algorithm. This data is transmitted just like acceleration data for
 *   a PAS. Resolution is 53.5LSB/kPa.
 * - absolute pressure: this is used for sensor testing. This data is
 *   transmitted using a special protocol.
 * 
 * The PTS1 is a specialized variant of the PPS3 used in pedestrian protection
 * applications. The "sensing unit" consists of two PTS1 sensors which are
 * connected by a flexible tube. This unit is mounted in the front bumper. For
 * the AB10 sensor management it is treated as two separate sensor channels.
 * 
 * This SW module is re-used to support PPS3 and PTS1, since most of the
 * handling is identical to PPS2. For reduced rework overhead the names of most
 * variables and constants still contain the prefix "PPS2" and remain
 * unchanged. This is also to keep the naming consistent to the module name.
 * The same approach was employed for PAS5/PAS6.
 * 
 * However, the absolute pressure check has to be done separately for the PTS1,
 * because they might face differing ambient pressure than the "regular" PPS
 * due to the connecting tube.
 *
 *
 *  Reference to Documentation:  sem_pp2_pps2_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_pp2_pps2 Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_pp2_pps2.h  $ */
/*  Revision 1.1 2019/09/05 11:16:44CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:01MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.5 2012/07/10 13:29:51IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Re-ran code generator after adding comment in AMEOS model due to review finding. */
/*  Only comments changed. No functional change. */
/*  --- Added comments ---  fru1si [2012/07/10 08:00:24Z] */
/*  review:Ptedt00114986 */
/*  --- Added comments ---  fru1si [2012/07/10 08:00:24Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2012/07/10 09:50:47Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2012/07/10 09:51:32Z] */
/*  SDT finished on 2012/7/10. */
/*  --- Added comments ---  fru1si [2012/07/10 10:29:03Z] */
/*  deliver:Ptedt00098953 */
/*  --- Added comments ---  fru1si [2012/07/10 10:29:03Z] */
/*  State changed: tested -> release by fru1si */
/*  Revision 5.4 2012/07/02 14:06:45MESZ fru1si  */
/*  Code generated after updating API descriptions in UML model due to PTS1 introduction. */
/*  No functional change. */
/*  Revision 5.3 2012/05/21 10:44:50MESZ fru1si  */
/*  Re-ran code generator after updating descriptions in AMEOS for PPS3 support. */
/*  --- Added comments ---  fru1si [2012/05/21 08:45:57Z] */
/*  Also added some new constants for PPS3 handling. */
/*  --- Added comments ---  fru1si [2012/05/22 14:43:00Z] */
/*  State changed: develop -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2012/05/22 14:43:54Z] */
/*  review:Ptedt00109413 */
/*  --- Added comments ---  fru1si [2012/05/25 12:22:43Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2012/05/25 12:23:11Z] */
/*  State changed: tested -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2012/05/25 12:28:14Z] */
/*  deliver:Ptedt00106754 */
/*  Revision 5.2 2011/03/23 16:32:56CET fru1si  */
/*  Added fault reaction. */
/*  Only comments added. No functional change. */
/*  Release state taken over. */
/*  --- Added comments ---  fru1si [2011/03/23 15:33:04Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.1 2010/08/05 10:04:28CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:15Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.2 2010/01/25 12:57:48CET fru1si  */
/*  - Added check of SPI bits TST and NRO/EOP during steady state */
/*  - Fixed handling of additional fault info */
/*  Revision 4.1 2009/09/28 16:48:35CEST fru1si  */
/*  Re-ran code generator and fixed some typos. */
/*  Revision 4.0 2009/09/25 13:26:12CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.7 2009/08/19 13:04:20CEST fru1si  */
/*  FLTDESC added for absolute pressure fault. */
/*  --- Added comments ---  fru1si [2009/08/19 11:04:54Z] */
/*  Only comments modified --> take over previous state. */
/*  --- Added comments ---  fru1si [2009/08/19 11:04:55Z] */
/*  State changed: develop -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/08/20 14:29:06Z] */
/*  State changed: tested -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/08/20 14:30:03Z] */
/*  Release granted by ESW3-Thiel on 2009/8/20. */
/*  --- Added comments ---  fru1si [2009/08/20 14:37:37Z] */
/*  fix:Ptedt00034536 */
/*  Revision 3.6 2009/08/12 13:35:15CEST fru1si  */
/*  Handling of pressure receive flags adapted: */
/*  - in case of communication fault both pn and p0 are marked as received. */
/*  - "SensorDefect" fault is no longer qualified in this case. */
/*  Changed so that a fault in physical data transmission does not lead to a "SensorDefect" fault as observed during EMC test at customer Mazda. */
/*  Revision 3.5 2009/05/19 17:09:41CEST fru1si  */
/*  - Fixed issue with slow voltage drop test (refer to Ptedt00024211). */
/*  - Changed local variables to U32 type according to design rules. */
/*  - Also corrected some typos and re-ran code generator. */
/*  --- Added comments ---  fru1si [2009/05/19 15:10:59Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/07/10 07:25:34Z] */
/*  Reviewed without findings on 2009/7/9 with ESW3-Jonkmann. */
/*  Refer to Ptedt00034320. */
/*  --- Added comments ---  fru1si [2009/07/10 07:25:36Z] */
/*  State changed: ready_for_review -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/07/15 07:17:42Z] */
/*  State changed: reviewed -> tested by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/07/29 13:24:16Z] */
/*  Thresholds for absolute pressure check adapted to AK-LV29 specification. */
/*  Revision 3.4 2009/04/07 12:44:07CEST fru1si  */
/*  Current thresholds adapted according to latest information from EHW3-Sch�tze. */
/*   */
/*  --- Added comments ---  fru1si [2009/04/22 09:06:23Z] */
/*  This change does not affect functionality since only a HW constant was adapted. */
/*  Therefore module state is taken over. */
/*  --- Added comments ---  fru1si [2009/04/22 09:06:23Z] */
/*  State changed: develop -> reviewed by fru1si */
/*  Revision 3.3 2009/02/02 13:41:07CET fru1si  */
/*  API PP2_DoCyclicAbsPressCheck() is obsolete and therefore removed. */
/*  Added Diagsym mask definition for absolute pressure fault. */
/*  --- Added comments ---  fru1si [2009/02/02 12:41:59Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/02/23 11:26:01Z] */
/*  State changed: ready_for_review -> reviewed by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2009/02/23 11:28:32Z] */
/*  Only minor changes reviewed by walkthrough with ESW3-Kuenzel on 23.02.09 without findings. */
/*  Revision 3.2 2008/12/18 17:00:43CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:14Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:21Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.1 2008/12/04 13:04:06CET fru1si  */
/*  Adapted current threshold constant after discussions with HW responsible. */
/*  This does not affect functionality of the module, therefore revision state is taken over. */
/*  --- Added comments ---  fru1si [2008/12/04 12:04:19Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/11 12:06:57CET fru1si  */
/*  Merged new functionality from side branch back to trunk: */
/*  - new Algo-SW sensor data interface */
/*  - option constants moved to sem_pes_peripheralsensors */
/*  --- Added comments ---  fru1si [2008/11/11 15:59:42Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/11/11 16:01:36Z] */
/*  State inherited from merged revision. */
/*  Revision 1.12.1.5 2008/10/27 09:02:11CET fru1si  */
/*  Modified absolute pressure check in order to add support for AK-LV29 standard pressure sensors. */
/*  Revision 1.12.1.4 2008/07/24 12:36:40CEST wjd2si  */
/*  Interchanged the order of elements in structure ts_Pps2SpecificData to get it word alligned again */
/*  --- Added comments ---  wjd2si [2008/07/24 12:30:23Z] */
/*  Delta-Review to last revision by ESW3-Fr�h without findings */
/*  --- Added comments ---  wjd2si [2008/07/24 12:30:23Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/08/20 09:36:03Z] */
/*  Test finished on 20.08.2008 by ESW3-Widmaier */
/*  --- Added comments ---  wjd2si [2008/08/20 09:36:04Z] */
/*  State changed: reviewed -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/08/20 10:22:00Z] */
/*  Release granted by ESW3-Breu on 20.08.2008 */
/*  --- Added comments ---  wjd2si [2008/08/20 10:22:00Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 1.12.1.3 2008/07/24 12:28:29CEST wjd2si  */
/*  Changes after review by Manuel Fr�h (CC-OS/ESW3): */
/*  - Naming conventions (postfix of function pointers) */
/*  Revision 1.12.1.2 2008/06/13 15:31:25CEST wjd2si  */
/*  - Removed no longer used options */
/*  Revision 1.12.1.1 2008/05/28 16:16:00CEST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW. The mean value calculation of the */
/*  sensor values was shifted from Algo to SEM: */
/*  - Introduced three new functions (PP2_EvaluateFirstSampleFIQ, PP2_EvaluateSecondSampleFIQ, */
/*    PP2_EvaluateSingleSampleFIQ) which replace the function PP2_EvaluateSensorDataFIQ. This was done */
/*    to handle the 2 and 4 kHz version and the mean value calculation of the 4 kHz version. */
/*  - Added new parameter to PP2_Init to be able to hand over two RT evaluation functions. One for the first */
/*    and one for the second sample. */
/*  Revision 1.12 2008/04/04 15:16:35CEST wjd2si  */
/*  - Reintroduced absolute pressure receive check (abs pressure seen last 2 seconds?) to solve Ptedt00012923 */
/*  - Corrected miss alignment of sensor defect additional fault information */
/*  --- Added comments ---  wjd2si [2008/04/08 07:32:39Z] */
/*  Tests finished by ESW3-Widmaier on 8.4.08 */
/*  --- Added comments ---  wjd2si [2008/04/08 07:32:40Z] */
/*  State changed: develop -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/04/08 07:58:12Z] */
/*  Delta review to revision 1.11 done by ESW3-Angstmann on 8.4.08 */
/*  --- Added comments ---  wjd2si [2008/04/08 13:50:11Z] */
/*  Release granted by ESW3-Thiel on 8.4.08 */
/*  --- Added comments ---  wjd2si [2008/04/08 13:50:11Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 1.11 2008/04/03 15:47:55CEST wjd2si  */
/*  Reran create_code after tool update. No changes to functionality -> take over old state */
/*  --- Added comments ---  wjd2si [2008/04/03 13:48:01Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*  Revision 1.10 2008/03/28 13:44:08CET wjd2si  */
/*  Moved fault information bit for ready but unlocked information one to the left (now it is bit 5) and adapted comment */
/*  Revision 1.9 2008/03/05 12:14:06CET wjd2si  */
/*  Changed quiescent threshold from 10mA to 6,7 mA */
/*  Revision 1.8 2008/02/22 18:34:13CET jer2abt  */
/*  Corrections after review. */
/*  Revision 1.7 2008/02/14 16:33:37CET jer2abt  */
/*  Check for absolute pressure (2s) has been removed. */
/*  --- Added comments ---  jer2abt [2008/02/14 15:33:44Z] */
/*  State changed: develop -> ready_for_review by jer2abt */
/*  Revision 1.6 2008/02/01 16:16:13CET jer2abt  */
/*  Working implementaion of PPS2 for pre-release. */
/*  Revision 1.5 2008/01/08 17:45:01CET ngk2si  */
/*  Minor bugfix regarding naming of bitfields. */
/*  Revision 1.4 2008/01/07 16:04:29CET ngk2si  */
/*  - Ptedt00009290: Adapted sensor data bitfields for NEC controllers (big => little endian) */
/*  - added compiler switches to TI specific pragmas (also for NEC) */
/*  - fixed several QAC findings (and added msg. suppression for existing deviations). */
/*  Revision 1.3 2007/09/18 14:40:29CEST wjd2si  */
/*  - Changed name of enumeration values, as they are also defined in PPS1. Could lead to trouble, if PPS1  */
/*    and PPS2 are used in the same project. */
/*   */
/*  FOR A SAMPLE ONLY: */
/*  - Set manufacturer code to 0x00 (C_PPS2ManuBosch_U8X) for the Bosch sensor. The A sample sensors */
/*    return 0x00 instead of 0x10 for the manufacturer code. */
/*   */
/*  This is also the reason, why this header file is set to bug. The manufacturer code is not like in the HW */
/*  spec, and as soon as the sensors return the correct code a corrected header file has to be provided!! */
/*  --- Added comments ---  wjd2si [2007/09/18 12:40:38Z] */
/*  State changed: develop -> bug by wjd2si */
/*  Revision 1.2 2007/09/18 11:09:44CEST wjd2si  */
/*  First implementation. It is very, very similar to the PPS1 implementation. */
/*  Revision 1.41 2006/09/01 19:43:00CEST ngk2si  */
/*  Includes macro fix by Manuel Carrara: Macro can now either be moddeld in Ameos */
/*  or an empty user editable section is generated. */
/*  Revision 1.40 2006/05/09 11:27:01CEST kcl2si  */
/*  changed e_event_sxr to e_event_xxr */
/*  Revision 1.39 2006/04/21 08:32:26CEST ngk2si  */
/*  Removed #define Y_INC_FROM... section from interface realisation includes, as these  */
/*  should never be in a header file. */
/*  Revision 1.38 2006/04/07 12:49:19CEST ngk2si  */
/*  - Major rework and restructuring */
/*  - changed toplevel layout and commenting of h-files */
/*  - now normal headers and interfaces both use this template */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_pp2_pps2_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct Includes */
#ifdef Y_Option_sem_pes_peripheralsensors
#include "sem_pes_peripheralsensors.h" 
#endif
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_pp2_pps2_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_pp2_pps2)  Definitions*/
/* EasyCASE - */
#define C_PPS2INIT1Timeout_U16X             98u      /* Maximum PPS2 INIT1 phase startup time (65ms nominal + 50%) */
#define C_PPS2StartupTimeout_U16X           500u     /* Maximum PPS2 startup time (333ms nominal + 50% safety margin) */
        /* Note: 333ms is the slower timing used for the Bus-Mode, other modes would be done within 268ms). */
#define C_PPS3INIT1Timeout_U16X             225u     /* Maximum PPS3 INIT1 phase startup time (150ms nominal + 50%) */
#define C_PPS3StartupTimeout_U16X           615u     /* Maximum PPS3 startup time (410ms nominal + 50% safety margin) */
/* Note: 410ms is the slower timing used for the Bus-Mode, other modes would be done within 328ms). */

#define C_PPS2SerialNumberLength_U8X        6u     /* PPS2 has 6 bytes serial number */
#define C_PPS2StatusMessageLength_U8X       16u    /* PPS2 sends 16 bytes of status data */

#define C_PPS2PesIfSettings_U8X             0x0Bu     /* => 000X XXXY: X = current threshold, Y = 8/10bit */
        /* current setting: 0101 (19mA) + 10 bit option, see HW-Spec "Software relevant features for SISSI PAS-IF, v2.0 */

/* The PPS2 does not use the full sensor range of +-480LSB. The valid data range is defined here. */
#define C_PPS2MinValidSensorValue_S16X      -102
#define C_PPS2MaxValidSensorValue_S16X      307

#define C_PPS2FirstPageComplete_U32X        0x0000FFFFu   /* 16 messages from first page received */
#define C_PPS2StatusMessagesComplete_U32X   0xFFFFFFFFu   /* All 32 messages received */
#define C_PPS2IndexSecondPage_U8X           16u           /* Each page has 16 entries */

/* Absolute pressure */
#define C_PPS2AbsPressureIDMask_U16X        0x0018u     /* Mask for the ID part of an absolute pressure message */
#define C_PPS2AbsPressureValueMask_U16X     0x0007u     /* Mask for the value part of an absolute pressure message */
#define C_PPS2AbsPressureID1_U16X           0x0000u     /* ID for the 1st part of the absolute pressure value */
#define C_PPS2AbsPressureID2_U16X           0x0008u     /* ID for the 2nd part of the absolute pressure value */
#define C_PPS2AbsPressureID3_U16X           0x0010u     /* ID for the 3rd part of the absolute pressure value */
#define C_PPS2AbsPressureID4_U16X           0x0018u     /* ID for the 4th part of the absolute pressure value */
#define C_PPS2ShiftAbsPressPart1_U8X        0x09u
#define C_PPS2ShiftAbsPressPart2_U8X        0x06u
#define C_PPS2ShiftAbsPressPart3_U8X        0x03u
#define C_PPS2ShiftAbsPressPart4_U8X        0x00u
/* EasyCASE - */
/* Thresholds for plausibility check */
#define C_PPS2SignalPlausiThreshold_U16X     16u     /* signal threshold used for a sensor plausibility fault (lsb) */
#define C_PPS2SignalPlausiTimeThreshold_U16X 100u    /* samples used for a sensor plausibility fault
                                                      * (100 samples * 10ms => 1s) */
/* EasyCASE - */
/* Mask for the receiption of relative pressure check (V_PressureReceiveFlagsINTW_U8X) */
#define C_PPS2RelPressureReceived_U8X       0x01u
#define C_PPS2AbsPressureReceived_U8X       0x02u
#define C_PPS2BothPressureReceived_U8X      0x03u

#define C_PPS2MaxMissingAbsMessages_U8X     20u
/* Maximum number of 100ms cycles where the absolute pressure messages is allowed to be missed -> if
 * in 2s no absolute pressure message was seen at all, then something is wrong! This timing should be
 * higher then the plausibility check timing (this is 1s). */
/* EasyCASE - */
/* Constants for the PPS init data  - see PPS2 spec */

/* Data 1..3: Protocol Information (always constant) */
#define C_PPS2SdProtocolA_U8X               0x42u       /* Protocol-Revision 4, lenth 2 */
#define C_PPS2SdProtocolB_U8X               0x00u       /* lenght information part B */

/* Data 4+5: Manufacturer information */
/* Bit wise according to PSI5 spec 1.3 */
#define C_PPS2ManuBoschBIT_U8X              0x10u
#define C_PPS2ManuVdoBIT_U8X                0x20u
#define C_PPS2ManuAutolivBIT_U8X            0x40u
#define C_PPS2ManuTemicBIT_U8X              0x80u
/* ASCII coded according to PSI5 spec 1.4 for PPS3 support */
#define C_PPS2ManuBoschASCII_U8X            0x42u
#define C_PPS2ManuAutolivASCII_U8X          0x41u
#define C_PPS2ManuTemicASCII_U8X            0x43u
#define C_PPS2ManuTrwASCII_U8X              0x54u

/* Data 6+7 : Sensor type (always constant - pressure sensor: 0000 1000) */
#define C_PPS2SdSensorTypeA_U8X             0x00u
#define C_PPS2SdSensorTypeB_U8X             0x08u
/* EasyCASE - */
/* Constants for absolute pressure handling */
#define C_PPS2AbsDefaultValue_U16X              0xFFFFu   /* Default value for absolute pressure */
#define C_PPS2AbsMinimumThresh_U16X             0x0006u   /* Threshold for absolture pressure minimum check */
#define C_PPS2AbsMaximumThresh_U16X             0x0D47u   /* Threshold for absolture pressure maximum check */
#define C_PPS2AbsDeltaThresh_U16X               0x01AEu   /* Threshold for delta of minimum and maximum check */

#define M_PPS2MinimumAbsPressureFlt_U8X         0x01u
#define M_PPS2MaximumAbsPressureFlt_U8X         0x02u
#define M_PPS2DeltaAbsPressureFlt_U8X           0x04u

#define C_AbsPressFailMaxReboot_U8X             3u        /* Number of reboots if absolute pressure check fails (AK sensors only) */
/* EasyCASE - */
/* Constant for PPS2 specific sensor defective fault handling
 * Sensor specific fault information for the sensor defective fault can be done in the lower 6 bit. */

/* PPS2 sensor defect fault
 * 0x xxx1 ... No relative pressure received in 100ms
 * 0x xx1x ... No abolute pressure received in last C_PPS2MaxMissingAbsMessages_U8X * 100ms
 * 0x x1xx ... PPS2 is unlocked
 * 1y yyyy ... yyyyy is the additional fault information which is send out alternating to "Sensor Defect".
 *             See the PPS2 specification for specific meaning.
 */
#define M_PPS2NoRelativePressureRcvd_U8X        0x01u   /* No relative pressure received */
#define M_PPS2NoAbsIDRcvd_U8X                   0x02u   /* No absolute pressure received */
#define M_PPS2ReadyUnlocked_U8X                 0x04u   /* Sensor is not locked */
#define M_PPS2SensorDefectMsg_U8X               0x20u   /* Marks that lower five bit are sensor defect additional fault info */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_pp2_pps2)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_pp2_pps2 leadout)  Enums*/
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_NoPPS2Configured,
   E_PPS2AbsMinMaxUpdated,
   E_PPS2NoAbsMinMaxUpdate
} te_PPS2MinMaxUpdate;
/*! DEF ENUM te_PPS2MinMaxUpdate */
/*! E_NoPPS2Configured: No PPS2 configured */
/*! E_PSP2AbsMinMaxUpdated: Min and Max value updated */
/*! E_PPS2NoAbsMinMaxUpdate: Min and Max value not updated */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_NoAbsPress,
   E_FirstPartReceived,
   E_SecondPartReceived,
   E_ThirdPartReceived
} te_PPS2AbsPressureState;
/*! DEF ENUM te_PPS2AbsPressureState */
/*! E_NoAbsPress: No absolute pressure message received */
/*! E_FirstPartReceived: First part of absolute pressure message received */
/*! E_SecondPartReceived: Second part of absolute pressure message received */
/*! E_ThirdPartReceived: Third part of absolute pressure message received */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE C */
/* Structure for part 1 of the PPS2 init data.
 * Due to different endianess in TI and NEC controllers, the bitfield
 * definitions must be made uC specific (see AB10_60J20_017).
 */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_ProtocolA_U8X     : 8;   /* Data 1..2  : Protocol revision and length part A */
   U32 B_ProtocolB_U4X     : 4;   /* Data 3     : Protocol revision and length part B */
   U32 B_ManufacturerA_U4X : 4;   /* Data 4     : Manufacturer part A */
   U32 B_ManufacturerB_U4X : 4;   /* Data 5     : Manufacturer part B */
   U32 B_TypeA_U4X         : 4;   /* Data 6     : Sensor type part A (fixed to pressure sensor) */
   U32 B_TypeB_U4X         : 4;   /* Data 7     : Sensor type part B (fixed to pressure sensor) */
   U32 B_TransCRCMode_U4X :  4;   /* Data 8     : Absolute pressure transmission and CRC mode */
   #elif defined ab10nec
   U32 B_ProtocolA_U8X     : 8;   /* Data 1..2  : Protocol revision and length part A */
   U32 B_ManufacturerA_U4X : 4;   /* Data 4     : Manufacturer part A */
   U32 B_ProtocolB_U4X     : 4;   /* Data 3     : Protocol revision and length part B */
   U32 B_TypeA_U4X         : 4;   /* Data 6     : Sensor type part A (fixed to pressure sensor) */
   U32 B_ManufacturerB_U4X : 4;   /* Data 5     : Manufacturer part B */
   U32 B_TransCRCMode_U4X :  4;   /* Data 8     : Absolute pressure transmission and CRC mode */
   U32 B_TypeB_U4X         : 4;   /* Data 7     : Sensor type part B (fixed to pressure sensor) */
   #else
      #error unsupported uC type!
   #endif
   } ts_Pps2StatusPart1;
/* EasyCASE E */
/* EasyCASE C */
/* Structure for part 2 of the PPS2 init data. */
typedef struct
   {
   #if defined ab10andromeda
   U32 B_PSI_U4X          :  4;   /* Data 9     : Sensor type PSI configuration */
   U32 B_HousingCodeA_U4X :  4;   /* Data 10    : Electronic housing code part A */
   U32 B_HousingCodeB_U4X :  4;   /* Data 11    : Electronic housing code part B */
   U32 B_SeriesCodeA_U4X  :  4;   /* Data 12    : Customer series code part A */
   U32 B_SeriesCodeB_U8X  :  8;   /* Data 13..14: Customer series code part B*/
   U32 B_ProdDateUp_U8X   :  8;   /* Data 15..16: Production date upper part */
   #elif defined ab10nec
   U32 B_HousingCodeA_U4X :  4;   /* Data 10    : Electronic housing code part A */
   U32 B_PSI_U4X          :  4;   /* Data 9     : Sensor type PSI configuration */
   U32 B_SeriesCodeA_U4X  :  4;   /* Data 12    : Customer series code part A */
   U32 B_HousingCodeB_U4X :  4;   /* Data 11    : Electronic housing code part B */
   U32 B_SeriesCodeB_U8X  :  8;   /* Data 13..14: Customer series code part B*/
   U32 B_ProdDateUp_U8X   :  8;   /* Data 15..16: Production date upper part */
   #else
      #error unsupported uC type!
   #endif
   } ts_Pps2StatusPart2;
/* EasyCASE E */
/* EasyCASE C */
/* structure for the pas-init data */
typedef struct
   {
   ts_Pps2StatusPart1 S_Part1_XXX;   /* Data 1..8  : First word of status data */
   ts_Pps2StatusPart2 S_Part2_XXX;   /* Data 9..16 : Second word of status data */
   U8 V_ProdDateLow_U8X;             /* Data 17..18: Production date lower part */
   U8 V_LotLineNo_U8X;               /* Data 19..20: Lot and line No. */
   U8 A_SerialNumber_U8X[C_PPS2SerialNumberLength_U8X]; /* Sensor serial number */
   } ts_Pps2StatusCode;
/* EasyCASE E */
/* EasyCASE C */
/* Contains the data needed for a single PPS 2
 * Attention: this struct must be word-aligned (size % 4 = 0) */
typedef struct
   {
   U8                      A_SensorStatusCodeINTW_U8X[C_PPS2StatusMessageLength_U8X]; /* PPS2 status message */
   U16                     V_AbsolutePressureINTW_U16X;                               /* Received absolute pressure */
   U16                     V_TempAbsolutePressureINTW_U16X;                           /* Temporary absolute pressure */
   te_PPS2AbsPressureState E_AbsPressureRcvd_XXX;                                     /* Last received abs press msg type */
   U8                      V_PressureReceiveFlagsINTW_U8X;                             /* Flags, if abs or rel pressure was received */
   U8                      V_MissingAbsCounter_U8X;                                    /* Counter for missing absolute pressure msg */
   U8                      V_Dummy_U8X;                                               /* Dummy to get the whole structure word-aligned */
   S16                     V_FirstSampleValueINTW_S16X;                               /* First received sample value */
   U16                     V_Dummy_U16X;                                              /* Dummy to get the whole structure word-aligned */
   } ts_Pps2SpecificData;
/* EasyCASE E */
#define C_PPS2SpecificRamSize_U16X sizeof(ts_Pps2SpecificData)
/* EasyCASE - */
/*! DEF MASKS PPS2AbsPressFlt */
/*! 00: Minimum pressure below threshold */
/*! 01: Maximum pressure above threshold */
/*! 02: Difference in pressure too high */
/*! END DEF */
/* The absolute pressure faults for both PPS and PTS use the same bit mask. */
/* EasyCASE - */
/*! FLTDESC MASKS PPS2AbsPressFlt FltPPS2AbsolutePressure: PPS2 absolute pressure fault */
/*! FLTREACTION FltPPS2AbsolutePressure: E_NoDisable */
/*! FLTDESC MASKS PPS2AbsPressFlt FltPTSAbsolutePressure: PTS1 absolute pressure fault */
/*! FLTREACTION FltPTSAbsolutePressure: E_NoDisable */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   PP2_Init */
/******************************************************************************
 * Description:
 *    Initializes the handling for a PPS2/PPS3/PTS1 sensor by
 *    - allocating RAM for this sensor
 *    - writing PPS2/PPS3/PTS1 specific settings into call by reference
 *      parameters
 *    - setting BG monitoring function to call for this sensor
 *    - setting up specific values in peripheral sensors data tables
 *    - setting the sensor's initial state
 * 
 * Arguments:
 *    - v_sensor_u8r               : index of current sensor
 *    - p_pesIfSettings_u8r        : pointer to settings for PES-IF
 *    - p_pps2FirstSampleFIQFp_xfr : pointer to FIQ evaluation function for the
 *      first sensor sample
 *    - p_pps2SecondSampleFIQFp_xfr: pointer to FIQ evalution function for the
 *      second sensor sample
 *      Note: Parameters two, three and four are call by reference!
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once in 10ms background after configuration data is available.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void PP2_Init(U8 v_sensor_u8r, U8 * p_pesIfSettings_u8r, tp_SensorSpecificFunction * p_pps2FirstSampleFIQFp_xfr, tp_SensorSpecificFunction * p_pps2SecondSampleFIQFp_xfr );
/* EasyCASE ) */
/* EasyCASE (
   PP2_EvaluateSingleSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt if the PPS2/PPS3/PTS1
 *    is a 2kHz sensor (e.g. synchronous) for the received sensor value. It
 *    performs the real-time checks (data in range, etc.) and writes valid
 *    results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the sensor channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PPS2/PPS3/PTS1 it
 *    obviously has to be highly runtime optimized.
 *    Note: While the PPS2/PPS3/PTS1 transmits an absolute pressure value the
 *    data valid flag is set and the output values are set to 0 (requirement by
 *    algorithm group).
 ******************************************************************************/
void PP2_EvaluateSingleSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PP2_EvaluateFirstSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the first received
 *    sensor value of a PPS2/PPS3/PTS1 (for old value).
 *    It performs the real-time checks (data in range, etc.) and keeps the
 *    sensor value for the mean value calculation by
 *    PP2_EvaluateSecondSampleFIQ.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of sensor the channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PPS2/PPS3/PTS1 it
 *    obviously has to be highly runtime optimized.
 *    Note: While the PPS2/PPS3/PTS1 transmits an absolute pressure value the
 *    data valid flag is set and the output values are set to 0 (requirement by
 *    algorithm group).
 ******************************************************************************/
void PP2_EvaluateFirstSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PP2_EvaluateSecondSampleFIQ */
/******************************************************************************
 * Description:
 *    Function is called during the real-time interrupt for the second received
 *    sensor value of a PPS2/PPS3/PTS1 (for new value).
 *    It performs the real-time checks (data in range, etc.), does the mean
 *    value calculation writes valid results into the sensor data PDI.
 * 
 * Arguments:
 *    - v_rawData_u16r: raw sensor data received from the sensor
 *    - v_sensor_u8r  : index of the sensor
 *    - v_channel_u8r : index of the sensor channel (not used)
 * 
 * Return: -
 * 
 * Scheduling:
 *    Real-time
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor manager and
 *    evaluates one sensor sample. For that to work the pointer to this
 *    function and its parameters are stored inside the sensor manager during
 *    initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    As this function is called during real-time for each PPS2/PPS3/PTS1 it
 *    obviously has to be highly runtime optimized.
 *    Note: While the PPS2/PPS3/PTS1 transmits an absolute pressure value the
 *    data valid flag is set and the output values are set to 0 (requirement by
 *    algorithm group).
 ******************************************************************************/
void PP2_EvaluateSecondSampleFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
/* EasyCASE (
   PP2_BackGroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Performs the background monitoring specific for PPS2/PPS3/PTS1 sensors.
 * 
 * Arguments:
 *    - v_sensor_u8r : index of current sensor in the data table in the
 *      sem_pes_peripheralsensors module
 *    - e_BGstate_xxr: current handled BG monitoring state
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called once for each PPS2/PPS3/PTS1 in each 10ms background cycle.
 * 
 * Usage guide:
 *    Called by sem_pes_peripheralsensors module via function pointer.
 * 
 * Remarks: -
 ******************************************************************************/
void PP2_BackGroundMonitoring10ms(U8 v_sensor_u8r, te_PesBgStates e_BGstate_xxr );
/* EasyCASE ) */
/* EasyCASE (
   PP2_BackGroundMonitoring100ms */
/******************************************************************************
 * Description:
 *    The following tasks are handled by the 100ms BG task:
 *    - check if relative pressure is received. If not qualify a "SensorDefect"
 *      fault and set the sensor to dead state. This is only done, if the
 *      sensor is configured and in steady state.
 *    - determination of minimum and maximum absolute pressure value (only
 *      configured PPS2/PPS3 which are in steady state and have sent an
 *      absolute pressure value during the last 100ms are taken into account).
 *    - comparison of minimum and maximum absolute pressure against thresholds.
 *      If comparison fails, qualify absolute pressure check fault and disable
 *      all PPS2/PPS3 sensors (sensor dead state).
 *    - comparison of difference between minimum and maximum absolute pressure
 *      against threshold. If comparison fails, qualify absolute pressure check
 *      fault and disable all PPS2/PPS3 sensors (sensor dead state).
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called in the 100ms background cycle only if PPS2/PPS3 sensors are
 *    included as option in the architecture. Behavior depends on the type of
 *    PPS2/PPS3 sensors used (normal Bosch mode / AK-LV29 mode):
 *    - in normal Bosch mode the function is called periodically during normal
 *      operation.
 *    - in AK-LV29 mode the function is called only during ECU start-up phase
 *      until either the absolute pressure check is passed or no more reboots
 *      are available.
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    The absolute pressure check is performed for PPS and PTS sensors
 *    separately. There are also two separate faults (PPSAbsolutePressure <-->
 *    PTSAbsolutePressure). This is required, because the absolute pressure
 *    could be quite different for the pressure tube sensors in the front
 *    bumper compared to the "normal" pressure sensors in the vehicle doors. As
 *    a consequence the absolute pressure fault for PTS only disables the PTS
 *    sensors, so the PPS may continue to work normally (and vice versa).
 ******************************************************************************/
void PP2_BackGroundMonitoring100ms( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
