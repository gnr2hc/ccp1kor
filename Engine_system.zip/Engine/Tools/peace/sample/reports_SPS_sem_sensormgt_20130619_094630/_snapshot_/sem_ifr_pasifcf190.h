/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_ifr_pasifcf190.h */
#ifndef Y_sem_ifr_pasifcf190H
#define Y_sem_ifr_pasifcf190H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2009 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_ifr_pasifcf190 Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_ifr_pasifcf190.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific module for controlling the dedicated PES interface ASIC CF190
 * (Ramses 2). Currently the CF190 contains a similar PES interface like the
 * SAPHIR (CG107) but with two instead of four sensor lines. It supports the
 * PSI5 synchronous mode of communication. Although there are many
 * similarities, it was not feasible to reuse the SAPHIR PES interface module
 * because the SPI commands to control the ASIC have changed significantly.
 * 
 * Main tasks:
 * - inital testing of the EClk montitoring feature
 * - initial programming
 * - control & monitoring of PES power supply
 *
 *
 *  Reference to Documentation:  sem_ifr_pasifcf190_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_ifr_pasifcf190 Header) History*/
/*
 *  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_ifr_pasifcf190.h  $
 *  Revision 1.1 2019/09/05 11:16:42CEST Prosch Christian (CC-PS/EPS2) (PHC2SI) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj
 *  Revision 1.1 2013/07/30 19:03:30CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj
 *  Revision 1.1 2013/06/19 06:18:54MESZ Vernon Hawes (RBEI/ESA1) (ver6cob) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj
 *  Revision 5.7 2012/08/16 14:16:01IST Frueh Manuel (CC-PS/EPS3) (fru1si) 
 *  - Added constant definitions for WRITE_SYNC_TIME command.
 *  - Moved some comments and definitions from c-file to h-file.
 *  --- Added comments ---  fru1si [2012/08/16 08:50:36Z]
 *  Merged from side branch. File corresponds to released revision 5.6.1.2.
 *  --- Added comments ---  fru1si [2012/08/16 08:50:36Z]
 *  State changed: develop -> release by fru1si
 *  
 *  --- Added comments ---  fru1si [2012/08/16 08:51:27Z]
 *  deliver:Ptedt00115074
 *  Revision 5.6.1.2 2011/11/09 14:04:30MEZ fru1si 
 *  Only moved some definitions and comments from c-file to h-file.
 *  No functional change. Previous state is taken over.
 *  --- Added comments ---  fru1si [2011/11/09 13:04:42Z]
 *  State changed: develop -> release by fru1si
 *  Revision 5.6.1.1 2011/08/08 18:22:41IST fru1si 
 *  Added constants for programming of T_SYNC via SPI command.
 *  --- Added comments ---  fru1si [2011/09/28 09:25:28Z]
 *  State changed: develop -> reviewed by fru1si
 *  
 *  --- Added comments ---  fru1si [2011/09/28 09:26:41Z]
 *  Reviewed by RBEI/Bharath S on 2011/9/28 without findings.
 *  review:Ptedt85185
 *  --- Added comments ---  fru1si [2011/09/29 12:43:22Z]
 *  State changed: reviewed -> tested by fru1si
 *  
 *  --- Added comments ---  fru1si [2011/09/29 13:45:29Z]
 *  State changed: tested -> release by fru1si
 *  Revision 5.6 2011/03/23 16:34:26CET fru1si 
 *  Added fault reaction.
 *  Only comments added. No functional change.
 *  Release state taken over.
 *  --- Added comments ---  fru1si [2011/03/23 15:34:32Z]
 *  State changed: develop -> release by fru1si
 *  Revision 5.5 2011/02/18 12:29:55CET bhs6kor 
 *  fixed for qac required rule
 *  --- Added comments ---  bhs6kor [2011/02/18 12:34:51Z]
 *  State changed: develop -> reviewed by bhs6kor
 *  
 *  --- Added comments ---  rdd3kor [2011/02/18 13:35:33Z]
 *  REVIEWED AND BASELINED
 *  --- Added comments ---  rdd3kor [2011/02/18 13:35:34Z]
 *  State changed: reviewed -> release by rdd3kor
 *  Revision 5.4 2011/02/14 17:08:27IST bhs6kor 
 *  added new enum state
 *  --- Added comments ---  bhs6kor [2011/02/18 08:40:35Z]
 *  State changed: develop -> reviewed by bhs6kor
 *  Revision 5.3 2010/12/07 19:18:31IST juv2kor 
 *  Added PasLineRegs enum --> This cannot be shared from the saphir .h file
 *  --- Added comments ---  juv2kor [2010/12/07 13:48:41Z]
 *  State changed: develop -> ready_for_review by juv2kor
 *  
 *  --- Added comments ---  hkr2kor [2010/12/08 08:09:17Z]
 *  State changed: ready_for_review -> reviewed by hkr2kor
 *  
 *  --- Added comments ---  rdd3kor [2010/12/10 11:54:16Z]
 *  REVIEWED AND BASELINED
 *  --- Added comments ---  rdd3kor [2010/12/10 11:54:17Z]
 *  State changed: reviewed -> release by rdd3kor
 *  Revision 5.2 2010/06/09 17:52:38IST fru1si 
 *  - Removed SPI commands for IPP programming.
 *  - Renamed init state InitSIDAndIPP --> InitSID.
 *  --- Added comments ---  fru1si [2010/06/21 14:43:58Z]
 *  State changed: develop -> reviewed by fru1si
 *  
 *  --- Added comments ---  fru1si [2010/06/21 14:45:01Z]
 *  review:Ptedt00052467
 *  --- Added comments ---  fru1si [2010/06/23 13:15:55Z]
 *  State changed: reviewed -> tested by fru1si
 *  
 *  --- Added comments ---  fru1si [2010/06/25 11:50:28Z]
 *  State changed: tested -> release by fru1si
 *  Revision 5.1 2010/03/26 15:49:36CET jnr1si 
 *  Added API to get the first element from te_AsicList which is of type CF190.
 *  related to defect Ptedt00046388
 *  --- Added comments ---  jnr1si [2010/04/08 09:39:40Z]
 *  review:Ptedt00049020
 *  --- Added comments ---  jnr1si [2010/04/08 09:39:40Z]
 *  State changed: develop -> reviewed by jnr1si
 *  
 *  --- Added comments ---  jnr1si [2010/04/19 12:27:05Z]
 *  State changed: reviewed -> release by jnr1si
 *  Revision 4.2 2010/03/02 16:14:49CET jnr1si 
 *  Implemented changes and new features for CF190 BA-sample.
 *  Main changes:
 *  -updated configuration settings
 *  new APIs for 
 *  - EClkMonitoring test
 *  - disabling all sensors on a sensor line
 *  - check if sensor line is connected to CF190
 *  deliver:Ptedt00041346: SCR 09_065 CF190 B-Si  - NEC - SEM
 *  no changes to version 4.1.1.4 (dev branch), therefore states inherited
 *  --- Added comments ---  jnr1si [2010/03/05 09:50:01Z]
 *  State changed: develop -> release by jnr1si
 *  Revision 4.1.1.4 2010/03/02 14:23:41CET jnr1si 
 *  Added macro to make it possible for the si_ini_systeminitialization.c to check if the EClkMonTest is supported before calling the API IFR_Initial4MHzEClkMonTest
 *  --- Added comments ---  jnr1si [2010/03/02 13:25:10Z]
 *  no functional change -> inherit states
 *  
 *  --- Added comments ---  jnr1si [2010/03/02 13:25:18Z]
 *  State changed: develop -> tested by jnr1si
 *  Revision 4.1.1.3 2010/02/26 11:27:43CET jnr1si 
 *  reran create code, to add missing variable names to parameter list
 *  no functional change.
 *  Revision 4.1.1.2 2010/02/17 14:04:44CET jnr1si 
 *  Added new state for the Init state machine to inform ITM about EClkMonTest execution status.
 *  Updated constants for the PROG_CONFIG.
 *  According to Guenter Weiss is the activation of the Vsync monitoring inverted to the description in the specification.
 *  (last bit needs to be 1, not 0).
 *  Revision 4.1.1.1 2010/02/08 12:21:02CET jnr1si 
 *  New APIs for CF190 B-Sample
 *  - 4MHz EClk monitoring test
 *  - APIs for cyclic EClk monitoring and fault handling/reaction
 *  Revision 4.1 2009/12/08 13:25:13CET hkr2kor 
 *  Check-in to avoid merge warning. No functional change.
 *  --- Added comments ---  jnr1si [2009/12/18 09:21:06Z]
 *  release inherited, no code change
 *  --- Added comments ---  jnr1si [2009/12/18 09:21:06Z]
 *  State changed: develop -> release by jnr1si
 *  Revision 4.0 2009/09/25 16:56:19IST fru1si 
 *  Introduced new ASI interface
 *  --- Added comments ---  fru1si [2009/10/02 14:45:47Z]
 *  State changed: develop -> reviewed by fru1si
 *  
 *  --- Added comments ---  fru1si [2009/10/02 16:36:54Z]
 *  State changed: reviewed -> tested by fru1si
 *  
 *  --- Added comments ---  fru1si [2009/10/02 16:37:02Z]
 *  State changed: tested -> release by fru1si
 *  Revision 1.4 2009/04/24 10:43:17CEST jnr1si 
 *  moved constant C_FirstCf190AsicPos_U8X from .c to .h file
 *  --- Added comments ---  jnr1si [2009/05/13 09:45:59Z]
 *  State changed: develop -> tested by jnr1si
 *  
 *  --- Added comments ---  jnr1si [2009/05/13 14:59:35Z]
 *  State changed: tested -> release by jnr1si
 *  Revision 1.3 2009/04/08 11:46:07CEST jnr1si 
 *  moved PSI line constants to sem_pes_peripheralsensors.h because they are used in the Saphir module as well.
 *  Revision 1.2 2009/04/07 12:09:55CEST jnr1si 
 *  create_code / updated architecture
 *  Revision 1.1 2009/03/16 11:15:19CET jnr1si 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/ab10_core_assets/ab10lib_hwd/sem_sensormgt/sem_sensormgt.pj
 */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_ifr_pasifcf190_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_ifr_pasifcf190_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_ifr_pasifcf190)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* Makro to allow the systemstartup to check if the EClk monitoring test is supported.
 * -> ssu_systemstartup.pj\si_ini_systeminitialization.c 
 */
#define Y_Feature_sem_ifr_Initial4MHzEClkMonTest
/* EasyCASE - */
/* position of the configuration data for the first CF190 asic 
   in the p-file */
#define C_FirstCf190AsicPos_U8X ((U8)(E_MaxSystemAsics + E_MaxCg974Asics))
/* EasyCASE - */
/* A CF190 Asic with 2 lines uses 2 x 4 = 8 samples */
#define C_Cf190MaxPasSamples_U8X             ((U8)8)

/* A CF190 has 2 lines */
#define C_Cf190NumberOfPasLines_U8X          ((U8)2)
/*!DEF ARRAYLEN C_Cf190NumberOfPasLines_U8X 2 */

/* The number of supported Cf190 asics on one ECU */
#define C_Cf190MaxSupportedCF190_U8X         0x4u

/* bit mask to be shifted to the position of the fist pas line of the current CF190 */
#define M_Cf190Lines_U16X                     0x0003u
/* EasyCASE - */
/* SPI-Command-Bits and fixed default values */

/* Read Diagnosis 1 command */
#define C_Cf190ReadDIA1_U16X                  0x6100u

/* Read commands */
#define C_Cf190ReadPasCommand_U16X            0x8000u
#define C_Cf190SelectPasCommand_U16X          0xC200u

/* PAS-power supply commands */
#define C_Cf190ReadSupply_U16X                0x1000u
#define C_Cf190SwitchSupply_U16X              0x1300u  /* differs to CG107 */

/* Prog and read commands for the safety ID */
#define C_Cf190ProgSID_U16X                   0x7600u  /* differs to CG107 */
#define C_Cf190ReadSID_U16X                   0x7500u  /* differs to CG107 */

/* Prog and read commands for the pas line configuration 
   The Pas Lines and the parity bit has to be added to the upper byte,
   e.g. prog: 01011xxp 00000000    with xx = bits for line number  
                                         p = parity bit for odd parity     */
#define C_Cf190ProgPsiMode_U16X               0x5800u  /* differs to CG107 */
#define C_Cf190ReadPsiMode_U16X               0x5000u  /* differs to CG107 */

/* prog and read commands for the sync mode */
#define C_Cf190ProgSyncMode_U16X              0x7300u /* differs to CG107 */
#define C_Cf190ReadSyncMode_U16X              0x7000u /* differs to CG107 */
/* Current default value used for this register programming */
#define C_Cf190SyncMode_U8X                   0x00u

/* set and read commands for sync mask */
#define C_Cf190SetSyncMask_U16X               0xF700u /* differs to CG107 */
#define C_Cf190ReadSyncMask_U16X              0xF400u /* differs to CG107 */

/* Set and read commands for sync time */
#define C_Cf190SetSyncTime_U16X               0x2800u
#define C_Cf190ReadSyncTime_U16X              0x3000u
#define C_Cf190ProgTSyncLine1_U16X            0x0100u
#define C_Cf190ProgTSyncLine2_U16X            0x0200u
/* Current default value used for this register programming */
#define C_Cf190SyncTime_U8X                   0x1Fu

/* command for sync pulse generation */
#define C_Cf190SyncGen_U16X                   0xF800u /* differs to CG107 */

/* prog and read command for special parameters like Vsync monitoring */
#define C_Cf190ProgConfig_U16X               0x6E00u  /* differs to CG107 */
#define C_Cf190ReadConfig_U16X               0x6D00u  /* differs to CG107 */
/* special parameters (PROG_CONFIG) default values (Vsync monitoring ON, automatic bit stuffing OFF) */
#define C_Cf190ConfigModeNoDC_U8X              0x05u      /* default: dynamic current limitation 10us */
#define C_Cf190ConfigModeDC_U8X                0x07u      /* with DaisyChain: dynamic current limitation 10ms */
/* EasyCASE - */
/* help constants for IPP setting and reading */
#define C_Cf190Shift2DataRegPos_U8X           4u   /* differs to CG107 */
#define C_Cf190Shift2LinePos_U8X              6u   /* differs to CG107 */

#define M_Cf190EopAndSIDBits_U8X                (U8)0x3C
/* EasyCASE - */
/* programming fault flags
   can be directly used as 6 bit additional fault info
   0000ffff
       ||||
       |||+--- PES line programming fault bit
       ||+---- PSI sync mode programming fault bit
       |+----- SID programming fault bit
       +------ Special parameter programming fault bit
*/
#define M_ProgPESLineFault_U8X                  (U8)0x01
#define M_ProgPSISyncModeFault_U8X              (U8)0x02
#define M_ProgSIDFault_U8X                      (U8)0x04
#define M_ProgConfigFault_U8X                   (U8)0x08
/*! DEF MASKS CF190RegProgFailed */
/*! 00: Prog PSI Mode failed */
/*! 01: Prog Sync Mode/Mask failed */
/*! 02: Prog SID failed */
/*! 03: Prog special parameters failed */
/*! END DEF */
/* EasyCASE - */
/*! FLTDESC MASKS CF190RegProgFailed MACRO Flt<Z_Cf190AsicMacro>PasLine1RegProg: <Z_Cf190AsicMacro> line 1 prog failed */
/*! FLTDESC MASKS CF190RegProgFailed MACRO Flt<Z_Cf190AsicMacro>PasLine2RegProg: <Z_Cf190AsicMacro> line 2 prog failed */
/*! FLTDESC MACRO Flt<Z_Cf190AsicMacro>EClkMonTest: <Z_Cf190AsicMacro> initial EClk test failed */
/*! FLTDESC MACRO Flt<Z_Cf190AsicMacro>EClkInterruption: <Z_Cf190AsicMacro> EClk interrupted */

/*! FLTREACTION MACRO Flt<Z_Cf190AsicMacro>PasLine1RegProg: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_Cf190AsicMacro>PasLine2RegProg: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_Cf190AsicMacro>EClkMonTest: E_NoDisable */
/*! FLTREACTION MACRO Flt<Z_Cf190AsicMacro>EClkInterruption: E_NoDisable */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_ifr_pasifcf190)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_ifr_pasifcf190 leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE - */
/* EasyCASE < */
/* struct to temporarily store the pas-setup data for the initialisation */
typedef struct
   {
   tp_SensorSpecificFunction P_PasSpecificFIQFp_XFX;
   U16                       V_ReadCommand_U16X;
   U8                        V_SensorIndex_U8X;
   U8                        V_ChannelIndex_U8X;
   } ts_PasifCf190SetupData;
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_IFRSetEclkTestExecutionState,
   E_IFRInitStaticData,
   E_IFRInitSMR,
   E_IFRCalculatePASLineSettings,
   E_IFRProgramPASLines,
   E_IFRInitSID,
   E_IFRInitSyncMode,
   E_IFRInitSpecialParameters,
   E_IFRInitEopAndFaultHandling,
   E_IFRInitCheckNextCf190,
   E_IFRInitFinished
}te_IFRInitStates;

/*! DEF ENUM te_IFRInitStates */
/*! E_IFRSetEclkTestExecutionState: Eclk test */
/*! E_IFRInitStaticData: Setup static data */
/*! E_IFRInitSMR: Add sensor channels */
/*! E_IFRCalculatePASLineSettings: PAS line settings */
/*! E_IFRProgramPASLines: Program PAS lines */
/*! E_IFRInitSID: Init SID for PAS registers */
/*! E_IFRInitSyncMode: Initialise sync mode */
/*! E_IFRInitSpecialParameters: spl parameter */
/*! E_IFRInitEopAndFaultHandling: End of Prog & flt handle */
/*! E_IFRInitCheckNextCf190: Check if another CF190 has to be handled */
/*! E_IFRInitFinished: Init of all CF190s is finished */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_CF190PASLineReg1,
   E_CF190PASLineReg2,
   E_CF190PASLineReg3,
   E_CF190PASLineReg4,
   E_MaxCF190PASLineRegs
}te_CF190PASLineRegs;

/*! DEF ENUM te_CF190PASLineRegs */
/*! E_CF190PASLineReg1: Register 1 on PAS line */
/*! E_CF190PASLineReg2: Register 2 on PAS line */
/*! E_CF190PASLineReg3: Register 3 on PAS line */
/*! E_CF190PASLineReg4: Register 4 on PAS line */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Protected Data Interfaces (description) */
/* EasyCASE (
   PDI: U16 A_IFRSyncMask_U16R [E_MaxCf190Asics] */
/*
 * PSI sync mask set for this line
 */
/* Declaration of U16 A_IFRSyncMask_U16R [E_MaxCf190Asics] can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE (
   PDI: U8 A_IFRNumberOfLines_U8R [E_MaxCf190Asics] */
/*
 * Number of lines the ASIC controls. The number of lines is also an indicator,
 * if this ASIC is programmed and if anything has to be done for it. If the
 * number of lines is equal to zero, then the evaluation tasks will be skipped.
 */
/* Declaration of U8 A_IFRNumberOfLines_U8R [E_MaxCf190Asics] can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE (
   IFR_Initial4MHzEClkMonTest */
/******************************************************************************
 * Description:
 *    This API performs a test of the EClk monitoring feature of the CF190
 *    ASIC. The monitoring feature detects if there was no EClk signal between
 *    2 SPI commands. If this happens, the SID is set to '111' to mark the
 *    sensor data as invalid.
 *    The sequence of the test is the following:
 *     1) program valid SID into one register (pre-condition)
 *     2) turn off EClk and check if SID is set to invalid ('111'),
 *        turn EClk on afterwards
 *     3) check normal operation by reading sensor data and checking if
 *        the SID is valid again
 *     4) set SID back to default ('111'), the real programming is done during
 *        IFR_Init()
 * 
 * Arguments:
 *    -
 * 
 * Return:
 *    -
 * 
 * Scheduling:
 *    Called once during system initialization, before RT and BG have started.
 * 
 * Usage guide:
 *    Because this test switches off the EClk for a short time it has to be
 *    executed as early as possible during the system start up, to keep the
 *    effects on the system as low as possible.
 *    Preconditions:
 *       SPI and SPI slaves have to be initialized.
 *       EEPROM configuration data have to be available.
 * 
 * Remarks:
 *    -
 ******************************************************************************/
void IFR_Initial4MHzEClkMonTest( void );
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   IFR_Init */
/******************************************************************************
 * Description:
 *    Performs the initialization for the PES interface ASIC CF190 (Ramses 2)
 *    as well as the SW setup for all PES connected to them. This includes:
 *    - programming of the CF190 line registers
 *    - calling the sensor type specific init methods (via
 *      PES_CallSensorSpecificInit)
 *    - set up the PES read commands for the sensor management (via
 *      SMR_AddSensorChannel)
 * 
 * Arguments: -
 * 
 * Return:
 *    E_InComplete: initialization has not finished yet
 *    E_Complete  : initialization has finished
 * 
 * 
 * Scheduling:
 *    Called by pes_peripheralsensors at the very first 10ms background.
 * 
 * Usage guide:
 *    Call the function from peripheral sensors module in the early init, until
 *    the function returns E_Complete.
 * 
 * Remarks:
 * 
 *    Setting up the PES read commands is rather complicated, as with each read
 *    command the NEXT buffer to be read has to be indicated.
 *    Example - reading of two PAS4:
 * 
 *    buffers to read:     commands sent:
 *    ----------------     --------------
 *    buffer 1 old value:  read buffer (next: 1 new)
 *    buffer 1 new value:  read buffer (next: 2 old)
 *    buffer 2 old value:  read buffer (next: 2 new)
 *    buffer 2 new value:  read buffer (next: 1 old)
 * 
 *    That means, the read commands are "rotated" by one. This "feature" makes
 *    this function rather complicated, especially as it is also necessary to
 *    handle a flexible order of buffers and even unused buffers. Therefore
 *    this whole sequence is first built up in RAM, then rotated and then
 *    written into the structures in sensor management.
 * 
 *    The synchronous transmission rate - 2kHz or 4kHz or the asynchronous
 *    transmission rate of 4kHz have to be taken care of while setting up the
 *    RAM buffer for sensor reading.
 * 
 *    The function has to be split because of runtime reasons, as a lot of
 *    CF190 registers need to be programmed, leading to very high BG runtime.
 ******************************************************************************/
te_Complete IFR_Init( void );
/* EasyCASE ) */
/* EasyCASE (
   IFR_MakeLineMeasurement */
/******************************************************************************
 * Description:
 *    Measures the PES line status of the PES-IF lines on the PES-IF ASIC
 *    CF190. The result is stored by setting the corresponding bits in
 *    S_PesLineData_XXR.F_MeasuredStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the beginning of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void IFR_MakeLineMeasurement( void );
/* EasyCASE ) */
/* EasyCASE (
   IFR_MakeLineSwitching */
/******************************************************************************
 * Description:
 *    Performs the line switching for the CF190 PES interface ASIC lines by
 *    sending the "supply SPI" command. Requested values are taken from
 *    variable the S_PesLineData_XXR.F_RequestedStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the very end of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void IFR_MakeLineSwitching( void );
/* EasyCASE ) */
/* EasyCASE (
   IFR_DisableSensorsOnAsic */
/******************************************************************************
 * Description:
 *    Disables all sensors connected to the respective CF190 PesInterfaceAsic
 *    for the current power on cycle.
 * 
 * Arguments:
 *    te_Cf190AsicList - Cf190 ASIC on which all sensors shall be disabled
 * 
 * Return:
 *    -
 * 
 * Scheduling:
 *    event driven in background
 * 
 * Usage guide:
 *    Intended to be used when a 4MHz EClk interruption was detected and
 *    qualified during normal operation
 * 
 * Remarks:
 *    The runtime of the function depends on the number of sensors connected to
 *    the ASIC
 ******************************************************************************/
void IFR_DisableSensorsOnAsic(te_Cf190AsicList e_cf190Asic_xxr );
/* EasyCASE ) */
/* EasyCASE (
   IFR_IsLineConnectedToCf190 */
/******************************************************************************
 * Description:
 *    Checks if a peripheral sensor line is connected to a CF190
 *    PesInterfaceAsic
 *    With the relation sensor -> line -> ASIC, the API can be used to check if
 *    a sensor is connected to a CF190.
 * 
 * Arguments:
 *    te_PasLineList: line which the sensor is connected to.
 * 
 * Return:
 *    te_Boolean:
 *    - E_True    line is connected to a CF190
 *    - E_False   line is NOT connected to a CF190
 * 
 * Scheduling:
 *    Event driven in background
 * 
 * Usage guide:
 *    Intended usage is during cyclic fault monitoring
 * 
 * Remarks:
 *    This API is needed because some cyclic faults are only relevant for a
 *    CF190 (e.g. 4MHz EClk interruption)
 ******************************************************************************/
te_Boolean IFR_IsLineConnectedToCf190(te_PasLineList e_line_xxr );
/* EasyCASE ) */
/* EasyCASE (
   IFR_GetFirstCf190InAsicList */
/******************************************************************************
 * Description:
 *    Returns the first occurrence of a CF190 ASIC in the enum list te_AsicList
 * 
 * Arguments: -
 * 
 * Return:
 *    te_AsicList - first element of te_AsicList which is of type CF190
 * 
 * Scheduling:
 *    eventdriven
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
te_AsicList IFR_GetFirstCf190InAsicList( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
