/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_ifp_pasifsaphir.h */
#ifndef Y_sem_ifp_pasifsaphirH
#define Y_sem_ifp_pasifsaphirH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 19/05/2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_ifp_pasifsaphir Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_ifp_pasifsaphir.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific module for controlling the PES interface inside SAPHIR ASIC CG107.
 * The SAPHIR is a system ASIC like the standard AB10 system ASICs, but also
 * supports the PSI5 synchronous mode of communication. The PES-IF programming
 * of the SAPHIR is significantly different compared to the standard AB10
 * system ASICs, hence this is designed to be a separate module.
 * 
 * Main tasks:
 * - initial programming
 * - control & monitoring of PES line power supply
 *
 *
 *  Reference to Documentation:  sem_ifp_pasifsaphir_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_ifp_pasifsaphir Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_ifp_pasifsaphir.h  $ */
/*  Revision 1.1 2019/09/05 11:16:42CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:30CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:53MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.2 2011/03/23 21:04:25IST Frueh Manuel (CC-PS/EPS3) (fru1si)  */
/*  Added fault reaction. */
/*  Only comments added. No functional change. */
/*  Release state taken over. */
/*  --- Added comments ---  fru1si [2011/03/23 15:34:32Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 5.1 2010/08/05 10:04:29CEST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:07:29Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.2 2010/06/09 14:22:38CEST fru1si  */
/*  - Removed SPI commands for IPP programming. */
/*  - Renamed init state InitSIDAndIPP --> InitSID. */
/*  Revision 4.1 2009/09/29 17:19:58CEST fru1si  */
/*  Merged CG147 support from side branch 3.8.1.1. */
/*  Due to major revision change the visual merge could not be performed. */
/*  Revision 4.0 2009/09/25 13:26:14CEST fru1si  */
/*  Introduced new ASI interface */
/*  Revision 3.8 2009/08/19 09:32:01CEST fru1si  */
/*  Support for macro-generated additional fault info added. */
/*  Revision 3.7 2009/07/29 13:25:00CEST fru1si  */
/*  IPP programming fixed. */
/*  Adapted local function definitions. */
/*  Removed HET-API for NEC controllers since it is not needed. */
/*  fix:Ptedt00033766 */
/*  --- Added comments ---  fru1si [2009/07/29 11:25:24Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*  Revision 3.6 2009/04/07 15:48:16CEST jnr1si  */
/*  moved constants for the configuration of PSI lines from sem_ifp_pasifsaphir.h to this sem_pes_peripheralsensors.h (3.5), because they are also used by the new CF190 modul */
/*  Revision 3.5 2009/03/26 10:36:38CET fru1si  */
/*  Fixed review findings. */
/*  Refer to Ptedt00027623. */
/*  --- Added comments ---  fru1si [2009/03/26 09:37:09Z] */
/*  State changed: develop -> reviewed by fru1si */
/*  Revision 3.4 2009/02/23 16:50:00CET fru1si  */
/*  Merged changes from side branch: */
/*  - bug fix for Ptedt00024160 */
/*  --- Added comments ---  fru1si [2009/03/06 09:50:27Z] */
/*  State changed: develop -> ready_for_review by fru1si */
/*  Revision 3.2 2009/02/11 12:10:24CET fru1si  */
/*  Module adapted for BA sample. */
/*  Revision 3.1 2008/12/18 17:00:50CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:18Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:27Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 3.0 2008/11/12 17:11:00CET hkr2kor  */
/*  Merged the implementation on the dev branches back to the main path.  */
/*  - New Algo SW Interface */
/*  - Sissi-Sissi Coupling */
/*  --- Added comments ---  fru1si [2008/12/18 10:42:51Z] */
/*  Take over state from merged revision. */
/*  --- Added comments ---  fru1si [2008/12/18 10:42:51Z] */
/*  State changed: develop -> release by fru1si */
/*   */
/*  --- Added comments ---  fru1si [2008/12/18 10:43:39Z] */
/*  Member revision set by fru1si */
/*  Revision 1.7.1.2 2008/07/29 20:22:50IST hkr2kor  */
/*  New module pes line handler requires sync line information, hence they are made as PDIs */
/*  --- Added comments ---  wjd2si [2008/08/21 06:38:46Z] */
/*  Reviewed by ESW3-Widmaier on 21.08.2008 */
/*  --- Added comments ---  wjd2si [2008/08/21 06:38:46Z] */
/*  State changed: develop -> reviewed by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/08/21 06:39:19Z] */
/*  Test finished by ESW3-Widmaier on 20.08.2008 */
/*  --- Added comments ---  wjd2si [2008/08/21 06:39:19Z] */
/*  State changed: reviewed -> tested by wjd2si */
/*   */
/*  --- Added comments ---  wjd2si [2008/08/21 09:15:41Z] */
/*  Release granted by ESW3-Breu on 21.08.2008 */
/*  --- Added comments ---  wjd2si [2008/08/21 09:15:41Z] */
/*  State changed: tested -> release by wjd2si */
/*  Revision 1.7.1.1 2008/05/29 13:30:49IST wjd2si  */
/*  Adapted the module to the new interface between Algo and SW: */
/*  - Introduced new states for init state machine (te_IFPInitStates) */
/*  Revision 1.7 2008/05/21 10:31:40CEST hkr2kor  */
/*  Updated after review of previous version. */
/*  IFP Init function split into a state machine to distribute the huge runtime. */
/*  QAC warnings removed. */
/*  Revision 1.6 2008/03/13 17:53:28IST hkr2kor  */
/*  Data length, Bit rate, Protection type of sensor data transmitted and sensor slots  */
/*  configured on each line combined to a single PSI line setting element. */
/*  Revision 1.5 2008/03/11 18:03:55CET hkr2kor  */
/*  Added the Select PAS SPI Instruction definition */
/*  Revision 1.4 2008/02/22 11:00:17CET hkr2kor  */
/*  Constant definitions for Push and pull current values for the rising/falling edge of the  */
/*  sync pulse added. The discharge bit info added directly in the pull current value. */
/*  Revision 1.3 2008/02/21 15:01:01CET hkr2kor  */
/*  RPM functions used to program the SAPHIR PAS IF registers. */
/*  Removed unused constant definitions. */
/*  Revision 1.2 2008/02/21 10:54:50CET hkr2kor  */
/*  First implementation - for the FPGA dev board */
/*  RPM functions not yet called */
/*  Revision 1.1 2008/02/21 10:30:34CET hkr2kor  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/ab10_base/ab10lib_hwd/sem_sensormgt/sem_sensormgt.pj */
/*  Revision 1.41 2006/09/01 19:43:00CEST ngk2si  */
/*  Includes macro fix by Manuel Carrara: Macro can now either be moddeld in Ameos */
/*  or an empty user editable section is generated. */
/*  Revision 1.40 2006/05/09 11:27:01CEST kcl2si  */
/*  changed e_event_sxr to e_event_xxr */
/*  Revision 1.39 2006/04/21 08:32:26CEST ngk2si  */
/*  Removed #define Y_INC_FROM... section from interface realisation includes, as these  */
/*  should never be in a header file. */
/*  Revision 1.38 2006/04/07 12:49:19CEST ngk2si  */
/*  - Major rework and restructuring */
/*  - changed toplevel layout and commenting of h-files */
/*  - now normal headers and interfaces both use this template */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_ifp_pasifsaphir_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_ifp_pasifsaphir_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_ifp_pasifsaphir)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE - */
/* A SAPHIR ASIC with 4 lines uses 4 x 4 = 16 samples */
#define C_SaphirMaxPESSamples_U8X              16u

/* A SAPHIR has 4 lines */
#define C_SaphirMaxPESLines_U8X                4u
/*!DEF ARRAYLEN C_SaphirMaxPESLines_U8X 4 */

#define M_SaphirFourLines_U16X                 0x000Fu
#define C_SaphirNumberOfPSIReceiveReg_U8X      16u

/* SPI command bits */
/* Test commands */
#define C_SaphirTestModePSICons_U16X               0x3810u
#define C_SaphirTestModeOff_U16X                           0x3800u
#define C_SaphirTestPSICons_U16X                           0xDC00u

/* Read commands */
#define C_SaphirReadPESCommand_U16X            0x8000u
#define C_SaphirSelectPESCommand_U16X          0xC200u

/* PAS-power supply commands */
#define C_SaphirReadSupply_U16X                0x1000u
#define C_SaphirSwitchSupply_U16X              0x10C0u

/* Bit masks for the 4 lines of Saphir PES lines in the absolute position */
#define M_SaphirLinePos_U16X                   (0x000Fu << E_PasLineSissi1)
/* EasyCASE - */
/* SAPHIR ASIC SPI commands for PSI Interface */

#define C_SaphirSyncMask_U16X                  0xF400u
#define C_SaphirSyncGen_U16X                   0xF200u

/* Currently Default value used for this register programming */
#define C_SaphirProgSyncMode_U8X               0x00u

#define C_Shift2LinePosReadCmd_U8X             1u
#define C_Shift2DataRegPos_U8X                 3u
#define C_Shift2LinePos_U8X                    5u
/* EasyCASE - */
/*! FLTDESC ENUM te_SystemAsicList FltAsicPsiInterface: ASIC internal signal path corrupted */
/*! FLTREACTION FltAsicPsiInterface: E_NoDisable */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_ifp_pasifsaphir)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_ifp_pasifsaphir leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE C */
/* struct to temporarily store the pas-setup data for the initialisation */
typedef struct
   {
   tp_SensorSpecificFunction P_PESSpecificFIQFp_XFX;
   U16                       V_ReadCommand_U16X;
   U8                        V_SensorIndex_U8X;
   U8                        V_ChannelIndex_U8X;
   } ts_PasIfSaphirSetupData;
/* EasyCASE E */
/* EasyCASE < */
typedef enum
{
   E_PASLineReg1,
   E_PASLineReg2,
   E_PASLineReg3,
   E_PASLineReg4,
   E_MaxPASLineRegs
}te_PASLineRegs;

/*! DEF ENUM te_PASLineRegs */
/*! E_PASLineReg1: Register 1 on PAS line */
/*! E_PASLineReg2: Register 2 on PAS line */
/*! E_PASLineReg3: Register 3 on PAS line */
/*! E_PASLineReg4: Register 4 on PAS line */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_IFPInitStaticData,
   E_IFPInitSMR,
   E_IFPCalculatePASLineSettings,
   E_IFPProgramPASLines,
   E_IFPInitSID,
   E_IFPInitSyncMode,
   E_IFPSignalPathMonTest,
   E_IFPInitCheckNextSaphir,
   E_IFPInitFinished
}te_IFPInitStates;

/*! DEF ENUM te_IFPInitStates */
/*! E_IFPInitStaticData: Setup static data */
/*! E_IFPInitSMR: Add sensor channels */
/*! E_IFPCalculatePASLineSettings: Define PAS line settings */
/*! E_IFPProgramPASLines: Program PAS lines */
/*! E_IFPInitSID: Initialise SID for PAS registers */
/*! E_IFPInitSyncMode: Initialise sync mode */
/*! E_IFPSignalPathMonTest: Signal path monitoring test on CG147 */
/*! E_IFPInitCheckNextSaphir: Check if another Saphir has to be handled */
/*! E_IFPInitFinished: Init of all Saphirs is finished */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/* EasyCASE < */
typedef enum
{
   E_IFPTestWait,
   E_IFPTestOngoing,
   E_IFPTestFinished
}te_IFPSignalPathMonTestState;

/*! DEF ENUM te_IFPSignalPathMonTestState */
/*! E_IFPTestWait: Wait until next signal path test is triggered. */
/*! E_IFPTestOngoing: Performing signal path test */
/*! E_IFPTestFinished: Last signal path test finished */
/*! END DEF */
/* EasyCASE > */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Protected Data Interfaces (description) */
/* EasyCASE (
   PDI: U16 A_IFPSyncMask_U16R [E_MaxSystemAsics] */
/*
 * PSI Sync mask set for this line
 */
/* Declaration of U16 A_IFPSyncMask_U16R [E_MaxSystemAsics] can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE (
   PDI: U8 A_IFPNumberOfLines_U8R [E_MaxSystemAsics] */
/*
 * Number of lines the ASIC controls. The number of lines is also an indicator,
 * if this ASIC is programmed and if anything has to be done for it. If the
 * number of lines is equal to zero, then the evaluation tasks will be skipped
 * (e.g. for non SAPHIR system ASICs).
 */
/* Declaration of U8 A_IFPNumberOfLines_U8R [E_MaxSystemAsics] can be found in realising c file */
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE (
   IFP_InitSignalPathMonTestFIQ */
/******************************************************************************
 * Description:
 *    Performs a test of the internal logic of the PSI5 interface, which
 *    monitors the correct behavior of the multiplexer which maps the sensor
 *    data from the receive register (timeslot) to the SPI output register.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Shall be called in the RT cylce, only during initialization.
 * 
 * Usage guide:
 *    The test will be triggered after the SIDs have been programmed
 *    successfully into the PSI5 interface. This is done through background
 *    during initialization, after the SIDs have been programmed and before EOP
 *    was set.
 * 
 * Remarks:
 *    The fault handling is done outside this function in the background.
 *    Although it is an FIQ function the runtime necessary for the test will be
 *    high due to several SPI commands which are necessary for the test. The
 *    exact runtime depends on how many timeslots (max 16) of the PSI5
 *    interface are actually used. Therefore it has to be ensured that this
 *    function is only called  in the initialization phase.
 ******************************************************************************/
void IFP_InitSignalPathMonTestFIQ( void );
/* EasyCASE ) */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   IFP_Init */
/******************************************************************************
 * Description:
 *    Performs the initialization for the SAPHIR system ASIC (CG107/CG147)
 *    PES-IF lines as well as the SW setup for all PES connected to them. This
 *    includes:
 *    - programming of the SAPHIR line registers
 *    - calling the sensor type specific init methods (via
 *      PES_CallSensorSpecificInit)
 *    - set up the PES read commands for the sensor management (via
 *      SMR_AddSensorChannel)
 * 
 * Arguments: -
 * 
 * Return:
 *    E_InComplete: initialization has not finished yet
 *    E_Complete  : initialization has finished
 * 
 * 
 * Scheduling:
 *    Called by pes_peripheralsensors at the very first 10ms background.
 * 
 * Usage guide:
 *    Call the function from peripheral sensors module in the early init, until
 *    the function returns E_Complete.
 * 
 * Remarks:
 * 
 *    Setting up the PES read commands is rather complicated, as with each read
 *    command the NEXT buffer to be read has to be indicated.
 *    Example - reading of two PAS4:
 * 
 *    buffers to read:     commands sent:
 *    ----------------     --------------
 *    buffer 1 old value:  read buffer (next: 1 new)
 *    buffer 1 new value:  read buffer (next: 2 old)
 *    buffer 2 old value:  read buffer (next: 2 new)
 *    buffer 2 new value:  read buffer (next: 1 old)
 * 
 *    That means, the read commands are "rotated" by one. This "feature" makes
 *    this function rather complicated, especially as it is also necessary to
 *    handle a flexible order of buffers and even unused buffers. Therefore
 *    this whole sequence is first built up in RAM, then rotated and then
 *    written into the structures in sensor management.
 * 
 *    The synchronous transmission rate - 2kHz or 4kHz or the asynchronous
 *    transmission rate of 4kHz have to be taken care of while setting up the
 *    RAM buffer for sensor reading.
 * 
 *    The function has to be split because of runtime reasons, as a lot of
 *    SAPHIR registers need to be programmed, leading to very high BG runtime.
 ******************************************************************************/
te_Complete IFP_Init( void );
/* EasyCASE ) */
/* EasyCASE (
   IFP_MakeLineMeasurement */
/******************************************************************************
 * Description:
 *    Measures the PES line status of the SAPHIR system ASIC PES-IF lines. The
 *    result is stored by setting the corresponding bits in
 *    S_PesLineData_XXR.F_MeasuredStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the beginning of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void IFP_MakeLineMeasurement( void );
/* EasyCASE ) */
/* EasyCASE (
   IFP_MakeLineSwitching */
/******************************************************************************
 * Description:
 *    Performs the line switching for the SAPHIR System ASIC PES lines by
 *    sending the "supply SPI" command. Requested values are taken from
 *    variable the S_PesLineData_XXR.F_RequestedStatus_U16X.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Called from pes_peripheralsensors at the very end of its 10ms cyclic
 *    monitoring.
 * 
 * Usage guide: -
 * 
 * Remarks: -
 ******************************************************************************/
void IFP_MakeLineSwitching( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
