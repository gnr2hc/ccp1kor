/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_s20_smb200.h */
#ifndef Y_sem_s20_smb200H
#define Y_sem_s20_smb200H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_s20_smb200 Header Author) Author*/
/*  $Source: sem_s20_smb200.h                                                    */
/*  $Revision: 1.1 $                                                          */
/*  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $                                                        */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific Module for SMB200 series dual channel central acceleration sensor.
 * 
 * The SMB200 features one in- and one out-of-plane axis and defines a full
 * scale measurement range +- 4.8g for both channels.
 * It is used a a lowG yz-sensor for rollover detection. The communication with
 * the SMB200 is done via the SPI.
 * 
 * This module contains the sensor specific initialisation and background
 * monitoring tasks.
 *
 *
 *  Reference to Documentation:  sem_s20_smb200_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_s20_smb200 Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_s20_smb200.h  $ */
/*  Revision 1.1 2019/09/05 11:16:44CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:19:01MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.6 2012/06/18 20:02:01IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor)  */
/*  new plausi handling added */
/*  --- Added comments ---  bhs6kor [2012/06/18 14:38:58Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/27 11:33:51Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/29 09:16:36Z] */
/*  State changed: reviewed -> release by bhs6kor */
/*  Revision 5.5 2011/05/13 13:36:39MESZ HKU2SI  */
/*  review finding, disable algo rollover for internal monitoring fault */
/*  --- Added comments ---  HKU2SI [2011/05/13 11:37:24Z] */
/*  delta review done by EPS3-Frueh */
/*  --- Added comments ---  HKU2SI [2011/05/13 11:37:24Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/06/20 14:42:58Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.4 2011/04/18 17:31:12CEST HKU2SI  */
/*  comment for fault reaction and fault description reworked */
/*  Revision 5.3 2011/02/25 10:06:13CET HKU2SI  */
/*  sem_s20_smb200 */
/*  --- Added comments ---  HKU2SI [2011/02/25 09:08:07Z] */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:24Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:08:24Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.2 2011/01/04 14:21:49CET bhs6kor  */
/*  updated after review */
/*  --- Added comments ---  bhs6kor [2011/01/06 09:03:16Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2011/02/18 08:47:27Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:37:38Z] */
/*  REVIEWED AND BASELINED */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:37:38Z] */
/*  State changed: reviewed -> release by rdd3kor */
/*  Revision 5.1 2010/08/05 13:34:29IST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:11:44Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.1 2009/09/29 15:15:45CEST hku2si  */
/*  module generated with AMEOS AB10 from main path */
/*  Revision 4.0 2009/08/27 12:00:22CEST hku2si  */
/*  new ASI (algo sensor interface) located to main branch */
/*  Revision 2.17.1.1 2009/03/11 12:12:33CET hku2si  */
/*  new sensor interface introduced (sem_std_sensortypedefs.h) */
/*  Revision 2.17 2008/12/18 17:00:51CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:18Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:27Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.16 2007/03/12 13:54:20CET hku2si  */
/*  module object description changed  */
/*  --- Added comments ---  hku2si [2007/03/12 16:19:21Z] */
/*  State changed: develop -> reviewed by hku2si */
/*   */
/*  --- Added comments ---  hku2si [2007/10/29 14:56:35Z] */
/*  State changed: reviewed -> release by hku2si */
/*  Revision 2.15 2007/02/07 14:42:02CET hku2si  */
/*  comment reworked */
/*  Revision 2.14 2006/08/15 15:24:24CEST ngk2si  */
/*  Fixed one Misra finding: BITE thresholds are now signed constants */
/*  Updated Test thresholds/delays after review with EPD4-Schruellkamp */
/*  Revision 2.13 2006/07/27 16:59:04CEST ngk2si  */
/*  Background monitoring in steady state split into three states (for BG runtime reduction) */
/*  Fixed internal monitoring bug (CQ:ees100004674) */
/*  Revision 2.12 2006/06/28 16:33:31CEST ngk2si  */
/*  Added check for TFF flag, corrected some typos */
/*  Revision 2.11 2006/05/27 16:19:23CEST ngk2si  */
/*  Updated after code review of cs_centralsensors, updated average signal calculation */
/*  Revision 2.10 2006/05/16 13:52:33CEST ngk2si  */
/*  - new SPI API names */
/*  - regenerated with updated CodeGen */
/*  - new StepUpIni Return type */
/*  - improved commenting */
/*  Revision 2.9 2006/04/11 17:44:31CEST ngk2si  */
/*  Corrected QAC findings */
/*  Revision 2.8 2006/04/07 16:38:22CEST ngk2si  */
/*  Regenerated with new template */
/*  Revision 2.7 2006/04/03 16:42:54CEST ngk2si  */
/*  - Regenerated with new templates */
/*  - adapted to new init-test repetition requirements from HW (20 repetions if offset/bite fails) */
/*  Revision 2.6 2006/03/20 17:42:46CET ngk2si  */
/*  Corrected test borders for plausibility-fault, BITE and offset cancellation */
/*  Revision 2.5 2006/03/13 08:00:19CET ngk2si  */
/*  Regenerated with new template, only comments changed. */
/*  Revision 2.4 2006/02/21 11:08:23CET ngk2si  */
/*  Changed API-names according to new coding rules (FIQ...) */
/*  Revision 2.3 2005/12/28 13:11:17CET ngk2si  */
/*  Corrected naming of enums */
/*  Revision 2.2 2005/12/12 18:33:40CET ngk2si  */
/*  Corrected init sequence: switching of Offset-Cancellation */
/*  Revision 2.1 2005/11/11 10:32:34CET ngk2si  */
/*  Added handling for not configured sensors */
/*  Revision 2.0 2005/10/24 17:46:02CEST ngk2si  */
/*  corrected version number */
/*  Revision 0.4 2005/10/24 17:45:21CEST ngk2si  */
/*  Major design change, adapted to new (2.0) sensormgt structure */
/*  Revision 0.3 2005/08/23 16:11:17CEST hmg2si  */
/*  Corrected findings of code review */
/*  Revision 0.2 2005/05/20 08:54:21CEST hmg2si  */
/*  Initial revision of SMB200 module header */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_s20_smb200_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_s20_smb200_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_s20_smb200)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 939
   SPI Commands for SMB200 */
#define C_SMB200SPIReadChannel1_U16X            0x8000u  /* Read sensor Channel 1 */
#define C_SMB200SPIReadChannel2_U16X            0xC000u  /* Read sensor Channel 2 */

#define C_SMB200SPIReadDeviceID_U16X            0x0000u  /* Read Device ID */
#define C_SMB200SPIReadRevisionID_U16X          0x0600u  /* Read Revision ID */
#define C_SMB200SPIReadMonitorData_U16X         0x0E00u  /* Read Monitor Data */

/* commands for inital tests */
#define C_SMB200SPIOffsetCancellationON_U16X    0x7805u  /* switch on offset cancellation for both channels */
#define C_SMB200SPIOffsetCancellationOFF_U16X   0x7800u  /* switch off offset cancellation for both channels */
#define C_SMB200SPIReadOffsetCancellation_U16X  0x7A00u  /* Read Offset cancellation status */

#define C_SMB200SPIDemandBite1_U16X             0x3809u  /* Selftest: Channel 1: pos Channel 2: neg */
#define C_SMB200SPIDemandBite2_U16X             0x3806u  /* Selftest: Channel 1: neg Channel 2: pos */
#define C_SMB200SPIDemandBiteOFF_U16X           0x3800u  /* Selftest: both Channels off  */

#define C_SMB200SPIEOPCommand_U16X              0x0C00u  /* End of programming */
/* EasyCASE ) */
/* EasyCASE ( 940
   SPI-Masks */
/* Mask that combines all SPI Message bits (TFF, TST, NRO and safety ID) */
#define M_SMB200AllSpiBits_U8X 0xFCu

/* Mask for monitoring data SPI-message */
#define M_SMB200MonitorFaultBits_U16X       0x000Fu  /* bits 0 to 3 of byte 1 represent moni faults  */
#define M_SMB200FinalSensorStatus_U16X      0x100Au  /* slow offset cancellation active on both channels, EOP set */

#define M_SMB200OffsetCancellationFast_U8X  0x0Fu    /* fast offset cancellation on both cannels active */
#define M_SMB200OffsetCancellationOff_U8X   0x00u    /* offset cancellation off */
/* EasyCASE ) */
/* EasyCASE ( 941
   HW-Constants */
#define C_SMB200DeviceID_U8X                    0x35u   /* Device ID of this SMB200 */

/* number of realtime measurements used for an averaged signal, specified in 2^x fashion */
#define C_SMB200AverageRawOffsetExp_U8X           4u    /* Raw Offset Cancellation: 2^4 => 16 samples */
#define C_SMB200AverageTestExp_U8X                6u    /* Offset+Bite Test: 2^6 => 64 samples */

/* Offset check */
#define C_SMB200OffsetDelay_U16X                500u    /* delay till fast offset cancellation can be evaluated (ms) */
#define C_SMB200OffsetTreshold_U16X             0x0C8u  /* threshold for offset cancellation check (2g) */

/* BITE */
#define C_SMB200BiteDelay_U16X                  100u    /* delay till Bite can be evaluated (ms) */
#define C_SMB200BiteOffDelay_U16X                36u    /* delay between Bite-Off-Command and TST-Bit cleared (32ms+10%) */
#define C_SMB200BiteMinThresholdChannel1_S16X   250     /* minimum threshold for the BITE test channel 1 */
#define C_SMB200BiteMaxThresholdChannel1_S16X   470     /* maximum threshold for the BITE test channel 1 */
#define C_SMB200BiteMinThresholdChannel2_S16X   110     /* minimum threshold for the BITE test channel 2 */
#define C_SMB200BiteMaxThresholdChannel2_S16X   450     /* maximum threshold for the BITE Test channel 2 */
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicLowGProgramming: E_NoDisable */
/*! FLTREACTION FltCsAsicLowGInternalMonitoring: E_DisableAlgoRollover */
/* EasyCASE - */
/*! FLTREACTION FltCsCentralSensorLowYBITE: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowYOffsetCancellation: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowYCommunication: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowYPlausibility: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowZBITE: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowZOffsetCancellation: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowZCommunication: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorLowZPlausibility: E_NoDisable */
/* EasyCASE - */
/*! FLTDESC FltCsAsicLowGProgramming: LowG Sensor: Programming failed */
/* EasyCASE - */
/*! FLTDESC FltCsAsicLowGInternalMonitoring: LowG Sensor: internal monitoring error */
/* EasyCASE - */
/*! FLTDESC FltCsCentralSensorLowYBITE: Central Sensor LowY BITE Fault */
/*! FLTDESC FltCsCentralSensorLowYOffsetCancellation: Central Sensor LowY Offset Cancellation Fault */
/*! FLTDESC FltCsCentralSensorLowYCommunication: Central Sensor LowY Communication Fault */
/*! FLTDESC FltCsCentralSensorLowYPlausibility: Central Sensor LowY Plausibility Fault */
/* EasyCASE - */
/*! FLTDESC FltCsCentralSensorLowZBITE: Central Sensor LowZ BITE Fault */
/*! FLTDESC FltCsCentralSensorLowZOffsetCancellation: Central Sensor LowZ Offset Cancellation Fault */
/*! FLTDESC FltCsCentralSensorLowZCommunication: Central Sensor LowZ Communication Fault */
/*! FLTDESC FltCsCentralSensorLowZPlausibility: Central Sensor LowZ Plausibility Fault */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_s20_smb200)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_s20_smb200 leadout)  Enums*/
/* EasyCASE ( 914
   enum te_SMB200Status */
/* EasyCASE < */
/* This enum encodes the states of a smb200 sensor */
typedef enum
{
  E_SMB200NotConfigured,                     /* sensor is not configured */
  E_SMB200SensorDisabled,                    /* sensor disabled because of a fault */
  E_SMB200InitCalcRawOffset,                 /* start calculation of raw offset */
  E_SMB200InitEvalRawOffset,                 /* Calculate the raw offset */
  E_SMB200InitStartFastOffsetCancellation,   /* start fast offset cancellation */
  E_SMB200InitWaitForOffsetCancellation,     /* wait for fast offset cancellation */
  E_SMB200InitEvalOffsetCancellation,        /* evaluate result of fast offset cancellation */
  E_SMB200InitStartBite1,                    /* start build in self test */
  E_SMB200InitWaitForBite1,                  /* wait for bite 1 settling time */
  E_SMB200InitSwitchBite2,                   /* switch to bite 2 test */
  E_SMB200InitWaitForBite2,                  /* wait for bite 2 settling time */
  E_SMB200InitEvalBite,                      /* evaluate result of bite test */
  E_SMB200InitCheckTestModeOff,              /* check if Testmode is off */
  E_SMB200InitEvaluateErrorsAndEOP,          /* evaluate the initalisation error and send EOP */
  E_SMB200SteadyState1,                      /* sensor is in steady state 1 (fetch internal monitoring) */
  E_SMB200SteadyState2,                      /* sensor is in steady state 2 (eval internal monitoring) */
  E_SMB200SteadyState3                       /* sensor is in steady state 3 (communication check) */
} te_SMB200Status;
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   S20_Init */
/******************************************************************************
 * Description:
 *    Initialises the handling for lowG SMB200. This includes:
 *    - checking if the sensor type is correct, that means if this module
 *      really accesses a SMB200
 *    - extracting configuration data and adding it to the management tables in
 *      centralsensors module
 *    - setting the initial sensor/channel states
 *    - initiating the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the first channel of this sensor, this
 *      index is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    Number of channels this sensor has, for a smb200 this is two.
 * 
 * Scheduling:
 *    Called once in 10ms background after cfg-data is available
 * 
 * Usage guide: -
 * 
 * Remarks:
 * The below Permanent Faults are checked for stored state using Central sensor
 * API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared.This function does all the necessary actions to register an
 * SMB200 ASIC, so that it can be read in and monitored in a proper way. It
 * sets up the internal RAM tables with all the information needed.
 ******************************************************************************/
U8 S20_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   S20_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialisation or continous cyclic monitoring.
 * 
 * Arguments: -
 * 
 * Return: -
 * 
 * Scheduling:
 *    Cyclic 10ms
 * 
 * Usage guide:
 *    Called by centralsensors-module in a 10ms background cycle
 * 
 * Remarks:
 *    In difference to the SMB460 it is not necessary to specify in a parameter
 *    which sensor to monitor, as a Airbag system will always have only one
 *    SMB200.
 ******************************************************************************/
void S20_BackgroundMonitoring10ms( void );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
