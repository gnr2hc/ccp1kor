/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_m2r_rollratemm2r.h */
#ifndef Y_sem_m2r_rollratemm2rH
#define Y_sem_m2r_rollratemm2rH
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_m2r_rollratemm2r Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_m2r_rollratemm2r.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * Specific Module for MM2R (SMG060) series angular-rate sensor.
 * 
 * This module contains the sensor specific initialisation and background
 * monitoring tasks. Additionally the MM2R has a dedicated realtime evaluation
 * function, as the requirements differ from other central sensors.
 *
 *
 *  Reference to Documentation:  sem_m2r_rollratemm2r_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_m2r_rollratemm2r Header) History*/
/*  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_m2r_rollratemm2r.h  $ */
/*  Revision 1.1 2019/09/05 11:16:42CEST Prosch Christian (CC-PS/EPS2) (PHC2SI)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj */
/*  Revision 1.1 2013/07/30 19:03:30CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj */
/*  Revision 1.1 2013/06/19 06:18:55MESZ Vernon Hawes (RBEI/ESA1) (ver6cob)  */
/*  Initial revision */
/*  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj */
/*  Revision 5.7 2012/06/18 20:00:15IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor)  */
/*  new plausi handling added */
/*  --- Added comments ---  bhs6kor [2012/06/18 14:38:28Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/27 11:33:16Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2012/06/29 09:16:11Z] */
/*  State changed: reviewed -> release by bhs6kor */
/*  Revision 5.6 2011/07/25 12:29:05MESZ hkr2kor  */
/*  Fixed review finding - only description changed, no fuctional change. */
/*  review:Ptedt00079997 */
/*  --- Added comments ---  hkr2kor [2011/07/25 10:30:02Z] */
/*  State changed: develop -> reviewed by hkr2kor */
/*   */
/*  --- Added comments ---  hkr2kor [2011/08/19 08:13:35Z] */
/*  fix:Ptedt00074066 */
/*  --- Added comments ---  juv2kor [2011/08/24 10:22:40Z] */
/*  State changed: reviewed -> release by juv2kor */
/*  Revision 5.5 2011/05/13 17:03:06IST HKU2SI  */
/*  review finding, disable algo rollover for internal monitoring fault */
/*  --- Added comments ---  HKU2SI [2011/05/13 11:33:46Z] */
/*  delta review done by EPS3-Frueh */
/*  --- Added comments ---  HKU2SI [2011/05/13 11:33:46Z] */
/*  State changed: develop -> reviewed by HKU2SI */
/*   */
/*  --- Added comments ---  HKU2SI [2011/07/18 13:16:43Z] */
/*  State changed: reviewed -> release by HKU2SI */
/*  Revision 5.4 2011/04/18 17:29:08CEST HKU2SI  */
/*  comment for fault reaction and fault description reworked */
/*  Revision 5.3 2011/02/25 09:34:37CET HKU2SI  */
/*  FLTREACTION introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:07:45Z] */
/*  release again, because only faultreaction as comment was introduced */
/*  --- Added comments ---  HKU2SI [2011/02/25 14:07:45Z] */
/*  State changed: develop -> release by HKU2SI */
/*  Revision 5.2 2011/01/04 14:52:04CET bhs6kor  */
/*  updated after review */
/*  --- Added comments ---  bhs6kor [2011/01/06 09:12:32Z] */
/*  State changed: develop -> ready_for_review by bhs6kor */
/*   */
/*  --- Added comments ---  bhs6kor [2011/02/18 08:41:12Z] */
/*  State changed: ready_for_review -> reviewed by bhs6kor */
/*   */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:36:01Z] */
/*  REVIEWED AND BASELINED */
/*  --- Added comments ---  rdd3kor [2011/02/18 13:36:02Z] */
/*  State changed: reviewed -> release by rdd3kor */
/*  Revision 5.1 2010/08/05 13:34:29IST fru1si  */
/*  - Removed DCU from AB10lib sensor management. */
/*  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions). */
/*  - Re-ran code generator with latest templates. */
/*  - No functional change --> previous state is taken over. */
/*  --- Added comments ---  fru1si [2010/08/05 08:09:34Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 4.1 2009/09/29 15:15:50CEST hku2si  */
/*  module generated with AMEOS AB10 from main path */
/*  Revision 4.0 2009/08/27 11:40:29CEST hku2si  */
/*  new ASI (algo sensor interface) located to main branch */
/*  Revision 2.6.1.1 2009/03/11 12:11:13CET hku2si  */
/*  new sensor interface introduced (sem_std_sensortypedefs.h) */
/*  Revision 2.6 2008/12/18 17:00:51CET fru1si  */
/*  Re-ran code generator after Hydra update ("#pragma arm" issue) */
/*  --- Added comments ---  fru1si [2008/12/18 16:03:19Z] */
/*  Member revision set by fru1si */
/*  --- Added comments ---  fru1si [2008/12/18 16:04:28Z] */
/*  State changed: develop -> release by fru1si */
/*  Revision 2.5 2007/04/30 12:52:09CEST ngk2si  */
/*  Bugfix: */
/*  - Communication fault lead to a follow-up BITE fault */
/*  - BITE fault lead to a follow-up disturbed programming fault. */
/*  --- Added comments ---  ngk2si [2007/04/30 12:15:39Z] */
/*  Delta review with C.Plesse, no findings. */
/*  --- Added comments ---  ngk2si [2007/04/30 12:15:40Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*   */
/*  --- Added comments ---  ngk2si [2007/04/30 14:34:33Z] */
/*  Unit tests completed sucessfully. */
/*  --- Added comments ---  ngk2si [2007/04/30 14:34:33Z] */
/*  State changed: reviewed -> release by ngk2si */
/*  Revision 2.4 2007/04/26 15:50:57CEST ngk2si  */
/*  Corrected various findings found in 2nd review (mostly typos, incorrect comments etc). */
/*  Revision 2.3 2007/04/03 18:02:58CEST ngk2si  */
/*  Only comments changed (findings from SDTP review and other minor improvements) */
/*  Revision 2.2 2007/03/23 13:34:55CET ngk2si  */
/*  Bugfix: Corrected Bitmasks for Monitor-Register supervision. */
/*  Revision 2.1 2007/03/09 17:58:00CET ngk2si  */
/*  Realised review findings (only improvement of some descriptions) */
/*  --- Added comments ---  ngk2si [2007/03/09 16:59:33Z] */
/*  Review done by H.Kuramswamy */
/*  --- Added comments ---  ngk2si [2007/03/09 16:59:33Z] */
/*  State changed: develop -> reviewed by ngk2si */
/*  Revision 2.0 2007/02/28 11:45:02CET ngk2si  */
/*  Completed Module: */
/*  - added Fault-Info for internal Monitoring */
/*  Revision 1.1 2007/02/08 17:42:49CET ngk2si  */
/*  Module completely rewritten, adapted to AB10 structure. */
/*  Functional, but two features missing: */
/*  - Mapping of Moni-Bits to MonitoringFault */
/*  - Reset Test */
/*  Revision 1.0 2007/01/12 17:12:42CET ngk2si  */
/*  Start of module re-implementation for complete integration in AB10 Platform. */
/*  Revision contains only generated code! */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_m2r_rollratemm2r_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_m2r_rollratemm2r_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_m2r_rollratemm2r)  Definitions*/
/* EasyCASE ( 914
   sensor specific thresholds / constants */
#define C_MM2RDeviceID_U8X                    0x95u   /* expected Device ID of a MM2R */
#define C_MM2RPartIdLengt_U8X                 0x04u   /* MM2R has 4 bytes Part-ID */
                                                      /*!DEF ARRAYLEN C_MM2RPartIdLengt_U8X 4 */

#define C_MM2RAverageExp_U8X                     6u   /* number of realtime measurements used for an averaged signal,
* specified in 2^x fashion (6 => 64 samples) */

#define C_MM2R55msLatch_U8X                    110u   /* counter is decremented every 500us => 110 = 55ms */

#define C_MM2RResetDelay_U8X                     2u   /* delay between activation of reset and it is effective (us) */
#define C_MM2RResetEvaluationDelay_U16X        150u   /* delay between reset and check of sensor startup (ms) */

#define C_MM2RRawOffsetDelay_U16X              500u   /* delay till raw offset can be sampled (delay since reset, ms) */
#define C_MM2ROffsetThreshold_U16X            0x32u   /* threshold for offset cancellation check (+-25deg/s) */
#define C_MM2ROffsetDelayFirst_U16X            500u   /* delay till fast offset cancellation can be evaluated (ms) */
#define C_MM2ROffsetDelayRetry_U16X            200u   /* delay for fast offset in case of a retry (ms) */

#define C_MM2RBiteDelay_U16X                  60u     /* delay till Bite can be evaluated (ms) */
#define C_MM2RBiteOffDelay_U16X               70u     /* delay between BITE-off command and real end of BITE (ms) */
#define C_MM2RBiteMinThreshold_S16X           115     /* minimum threshold for the BITE Test (ms) */
#define C_MM2RBiteMaxThreshold_S16X           460     /* maximum threshold for the BITE Test (ms) */

#define C_MM2REOPDelay_U16X                   100u    /* delay between EOP and the final evaluation (ms) */
/* EasyCASE ) */
/* EasyCASE ( 915
   SPI Commands & Masks for MM2R */
/* read commands */
#define C_MM2RSPIReadSensorData_U16X          0x8000u  /* Read sensor data */

#define C_MM2RSPIReadDeviceID_U16X            0x0000u  /* Read Device ID */
#define C_MM2RSPIReadMonitorData1_U16X        0x3A00u  /* Read Monitor Data 1 */
#define C_MM2RSPIReadMonitorData2_U16X        0x3C00u  /* Read Monitor Data 2 */

/* commands for inital tests / programming */
#define C_MM2RSPIOffsetCancellationON_U16X    0x7801u  /* switch on offset cancellation */
#define C_MM2RSPIOffsetCancellationOFF_U16X   0x7800u  /* switch off offset cancellation */
#define C_MM2RSPIReadOffsetCancellation_U16X  0x7A00u  /* Read Offset cancellation status */

#define C_MM2RSPIDemandBitePos_U16X           0x3801u  /* Selftest: positive deflection */
#define C_MM2RSPIDemandBiteNeg_U16X           0x3802u  /* Selftest: negative deflection */
#define C_MM2RSPIDemandBiteOFF_U16X           0x3800u  /* Selftest: off  */

#define C_MM2RSPIReadPartId1_U16X             0x5E00u  /* Read Part ID block 1 */
#define C_MM2RSPIReadPartId2_U16X             0x5C00u  /* Read Part ID block 2 */
#define C_MM2RSPIReadPartId3_U16X             0x5A00u  /* Read Part ID block 3 */
#define C_MM2RSPIReadPartId4_U16X             0x5800u  /* Read Part ID block 4 */

#define C_MM2RSPIEOPCommand_U16X              0x0C00u  /* End of programming */
/* EasyCASE - */
/* SPI-Communication Masks */
#define M_MM2RNROBit_U8X                        0x20u  /* NRO = Bit 13 */
#define M_MM2RSafetyID_U8X                      0x0Cu  /* Safety ID of MM2R is fixed to 011, stored in bit 2..4 */

#define M_MM2RInitMoni1Expected_U16X          0x1000u  /* Expected Monitor1 data after reset: Bit 12=1, others=0 */
#define M_MM2RInitMoni1Checked_U16X           0x100Au  /* Checked are bit 12, 3 and 1 (CPDAC, CPMax) */
#define M_MM2RCheckedMonibitsInit_U16R        0x01FFu  /* Moni Bits checked during Init (all Moni1 + Zap) */
#define M_MM2RCheckedMonibitsSteady_U16R      0x05FFu  /* Moni Bits checked during steady state (+ Offset mode) */

#define M_MM2RSPIOffsetCancellationFast_U8X     0x03u  /* fast offset cancellation active */
#define M_MM2RSPIOffsetCancellationSlow_U8X     0x02u  /* slow offset cancellation active */
#define M_MM2RSPIOffsetCancellationOff_U8X      0x00u  /* offset cancellation off */
#define M_MM2RSPIOffsetStatusAfterEOP_U16X    0x1002u  /* TFF, TST, NRO not set, slow offset regulation active */
/* EasyCASE - */
/* Part ID masks */
#define M_MM2RSPIPartIDApplication_U8X          0x30u  /* bits 4 and 5 determine application (APL) */
/* EasyCASE ) */
/* EasyCASE ( 916
   Masks for Monitoring Register */
/* Masks for Internal Monitoring SPI-Messages
 *   The MM2R has two internal monitoring registers (8bit each), that indicate
 *   the sensor errors or stati detected by the monitoring logic inside the asic.
 *   The bits are combined into one U16 and have the following meaning:
 *
 *   Flags that set the NRO-SPI-Bit:
 *     Moni 1:
 *      xxxx xxxx xxxx xxx1: ADCRAT: Rate ADC out of range (-512...+512 LSB)
 *      xxxx xxxx xxxx xx1x: CPDAC:  Drive DAC / amplitude of in-plane-oscillation out-of-range
 *      xxxx xxxx xxxx x1xx: ADCDRV: Drive ADC / amplitude of drive signal out of range
 *      xxxx xxxx xxxx 1xxx: CPMAX:  PLL-counter out of range (1013...1033 LSB) / PLL not locked
 *      xxxx xxxx xxx1 xxxx: OFFREG: Offset-controller out of range (-1024 ... +1024 LSB)
 *      xxxx xxxx xx1x xxxx: CMRD:   Difference in Common mode controller in RATE channel out of range
 *      xxxx xxxx x1xx xxxx: AMPREG: DC-value representing drive amplitude out of range
 *      xxxx xxxx 1xxx xxxx: CMRA:   Difference in Common mode controller in drive channel out of range
 *
 *     Moni 2:
 *      xxxx xxx1 xxxx xxxx: PARITY:  Zap array communication parity bit = 1
 *      xxxx xx1x xxxx xxxx: not used
 *      xxxx x1xx xxxx xxxx: OFFMODE:  Fast instead of slow offset cancellation effective
 *      xxxx 1xxx xxxx xxxx: not used
 *   Flags that do not set the NRO-SPI-Bit (these are not monitored in the ECU):
 *      xxx1 xxxx xxxx xxxx: Exceptional operation mode: Rate exceeding full-scale dynamic range
 *      xx1x xxxx xxxx xxxx: Parameter out of look-up-table for temperature sensitivity compensation
 *      x1xx xxxx xxxx xxxx: Parameter out of look-up-table for temperature BITE compensation
 *      1xxx xxxx xxxx xxxx: not used
 */
#define M_MM2RMoniDrive_U16X            0x0002u
#define M_MM2RMoniPll_U16X              0x0008u
#define M_MM2RMoniRateChannel_U16X      0x0021u
#define M_MM2RMoniDriveChannel_U16X     0x00C4u
#define M_MM2RMoniOffset_U16X           0x0410u
#define M_MM2RMoniParity_U16X           0x0100u

/* Mapping for the 6 bits detailed fault info stored withing the CSMonitoring Fault:
 *      xx xxx1: Drive: CPDAC
 *      xx xx1x: PLL: CPMAX
 *      xx x1xx: Rate-Channel: ADCRAT & CMRD
 *      xx 1xxx: Drive-Channel: ADCDRV, CMRA & AMPREG
 *      x1 xxxx: Offset-Regulation: OFFREG & OFFMODE
 *      1x xxxx: Parity-Error: PARITY
 */
#define M_MM2RMoniFaultDrive_U8X        0x01u
#define M_MM2RMoniFaultPll_U8X          0x02u
#define M_MM2RMoniFaultRateChannel_U8X  0x04u
#define M_MM2RMoniFaultDriveChannel_U8X 0x08u
#define M_MM2RMoniFaultOffset_U8X       0x10u
#define M_MM2RMoniFaultParity_U8X       0x20u
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicRolloverProgramming: E_NoDisable */
/*! FLTREACTION FltCsAsicRolloverInternalMonitoring: E_DisableAlgoRollover */
/* EasyCASE - */
/*! FLTREACTION FltCsCentralSensorRollRateBITE: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRateOffsetCancellation: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRateCommunication: E_NoDisable */
/*! FLTREACTION FltCsCentralSensorRollRatePlausibility: E_NoDisable */
/* EasyCASE - */
/*! FLTDESC FltCsAsicRolloverProgramming: Rollover ASIC: Programming Fault */
/* EasyCASE - */
/*! FLTDESC FltCsAsicRolloverInternalMonitoring: Rollrate Sensor: internal monitoring error */
/* EasyCASE - */
/*! FLTDESC FltCsCentralSensorRollRateBITE: Central Sensor Roll Rate BITE Fault */
/*! FLTDESC FltCsCentralSensorRollRateOffsetCancellation: Central Sensor Roll Rate Offset Cancellation Fault */
/*! FLTDESC FltCsCentralSensorRollRateCommunication: Central Sensor Roll Rate Communication Fault */
/*! FLTDESC FltCsCentralSensorRollRatePlausibility: Central Sensor Roll Rate Plausibility Fault */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_m2r_rollratemm2r)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_m2r_rollratemm2r leadout)  Enums*/
/* EasyCASE ( 918
   enum te_MM2RStatus */
/* EasyCASE < */
/* This enum encodes the states for a MM2R sensor */
typedef enum
{
  E_MM2RNotConfigured,                     /* sensor is not configured */
  E_MM2RSensorDisabled,                    /* sensor disabled because of a fault */
  E_MM2RInitResetTestStart,                /* start reset line check */
  E_MM2RInitResetTestDelay,                /* delay for initial reset test */
  E_MM2RInitResetTestEval,                 /* evaluation of initial reset test */
  E_MM2RInitReadPartID ,                   /* read MM2R part ID part */
  E_MM2RInitRawOffsetDelay,                /* delay till raw offset can be measured */
  E_MM2RInitRawOffsetMeasurement,          /* measurement  of the raw offset */
  E_MM2RInitFastOffsetStart,               /* start fast offset cancellation */
  E_MM2RInitFastOffsetDelay,               /* delay till fast offset offset cancellation is done */
  E_MM2RInitFastOffsetEval,                /* measurement  and evaluation of the raw offset */
  E_MM2RInitBite1Start,                    /* start BITE (build in self test) */
  E_MM2RInitBite1Delay,                    /* wait for BITE 1 settling time */
  E_MM2RInitBiteSwitch,                    /* store result of BITE 1 and switch to BITE 2 test */
  E_MM2RInitBite2Delay,                    /* wait for BITE 2 settling time */
  E_MM2RInitBiteEval,                      /* evaluate result of BITE test */
  E_MM2RInitBiteSendOff,                   /* send Bite-off command to sensor */
  E_MM2RInitBiteCheckOff,                  /* check if Testmode is off */
  E_MM2RInitProgramSensor,                 /* program the sensor (EOP and Offset Cancellation)*/
  E_MM2RInitCompleteInit,                  /* evaluates the initialisation and completes it */
  E_MM2RSteadyState1,                      /* sensor is in steady state 1 (fetch internal monitoring) */
  E_MM2RSteadyState2,                      /* sensor is in steady state 2 (evaluate internal monitoring) */
  E_MM2RSteadyState3                       /* sensor is in steady state 3 (communication check) */
} te_MM2RStatus;
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   M2R_Init */
/******************************************************************************
 * Description:
 *    Initialises the handling for the MM2R. This includes:
 *    - check if the sensor type is correct, that means if this module really
 *      accesses a MM2R
 *    - extract configuration data and add it to the management tables in
 *      centralsensors module
 *    - set the initial sensor/channel states
 *    - initiate the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the channel of this sensor, this index
 *      is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    Number of channels this sensor has, for a MM2R this is one.
 * 
 * Scheduling:
 *    Called once in 10ms background after cfg-data is available
 * 
 * Usage guide: -
 * 
 * Remarks:
 *    The below Permanent Faults are checked for stored state using Central
 *    sensor API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared. This function does all the necessary actions to register a
 * MM2R, so that it can be read in and monitored in a proper way. It sets up
 * the internal RAM tables with all the information needed.
 ******************************************************************************/
U8 M2R_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   M2R_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialisation or continuous cyclic monitoring.
 * 
 * Arguments: none
 * 
 * Return: none
 * 
 * Scheduling:
 *    10ms
 * 
 * Usage guide:
 *    called by centralsensors-module once in each 10ms background cycle.
 * 
 * Remarks:
 *    The function m2s_ChkRTFlagsForIntrnlMoniFlts() is blocked if the
 *    semaphore F_StepUpIniIntrlMoniFlt_U8R is set. This is done to prevent
 *    that an internal monitoring fault which is currently stepped up in
 *    CFM_StepUpIni() will not be stepped down in
 *    m2s_ChkRTFlagsForIntrnlMoniFlts() for initialization phase.
 ******************************************************************************/
void M2R_BackgroundMonitoring10ms( void );
/* EasyCASE ) */
/* EasyCASE (
   M2R_EvaluateSensorDataFIQ */
/******************************************************************************
 * Description:
 *    This function does the realtime data evaluation specific for the MM2R.
 * 
 *    It is a separate function for the MM2R (other sensors use
 *    CS_EvaluateSensorDataFIQ), as the MM2R has one special requirement: if
 *    the sensor signals an error condition with a NRO flag set, this error
 *    state has to be latched for 55ms (and data values have to be 0 during
 *    that time). This is a SW-Workaround for a HW-bug that clears that error
 *    information too early.
 * 
 * Arguments:
 *    - v_rawData_u16r : the raw sensor data received from the sensor
 *    - v_sensor_u8r   : the index for the sensors internal data table
 *    - v_channel_u8r  : the index for the sensors channel data interface
 * 
 * Return: -
 * 
 * Scheduling:
 *    realtime (FIQ)
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor-manager. For
 *    that to work a pointer to this function and its parameters are stored
 *    inside the sensormanager during initialization (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    Obviously this function is runtime critical.
 * 
 *    It performs a check of the sensor data based on two criteria:
 *    - are the SPI-Checkbits as expected?
 *    - did a NRO flag occur during the last 55ms (110 cycles)?
 *    The first test uses two variables
 *    (S_CsIntData_XXR.A_ChannelRTExpSpiBits_U8X and
 *    S_CsIntData_XXR.A_ChannelRTCheckedSpiBits_U8X). The first variable
 *    determines which bits of the read sensor-data are compared to the
 *    expected value specified by the second variable.
 * 
 *    If the sensor-data is OK AND the sensor is in steady-state, the
 *    sensor-data is written into the data interface (S_CsSensorDataINTW_XXR)
 * and the data-valid flag is set for this channel. Otherwise 0 is written and
 * data-valid is cleared.
 * 
 *    During sensor initialisation, this function can also be used to generate
 *    an averaged signal. This is triggered via the API
 *    CS_StartAverageCalculation. Then sensor values are summed up in
 *    S_CsIntData_XXR.A_ChannelAvgSignalINTW_S16X.
 ******************************************************************************/
void M2R_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
