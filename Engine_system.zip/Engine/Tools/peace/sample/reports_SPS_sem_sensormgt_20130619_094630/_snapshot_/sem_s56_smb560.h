/* EasyCASE V6.5 01.01.2008 00:00:00 */
/* EasyCASE O
If=vertical
LevelNumbers=no
LineNumbers=no
Colors=16777215,0,12582912,12632256,0,0,0,16711680,8388736,0,33023,32768,0,0,0,0,0,32768,12632256,255,65280,255,255,16711935
ScreenFont=Courier New,,80,4,-11,0,400,0,0,0,0,0,0,3,2,1,49,96,96
PrinterFont=Courier New,,80,4,-66,0,400,0,0,0,0,0,0,3,2,1,49,600,600
LastLevelId= */
/* EasyCASE (
   sem_s56_smb560.h */
#ifndef Y_sem_s56_smb560H
#define Y_sem_s56_smb560H
/* EasyCASE - */
/*#ACD# M(Bosch Copyright) */
/* ************************************************************************** */
/*                                                                            */
/*  Copyright (c) 2008 Robert Bosch GmbH, Germany                             */
/*                All rights reserved                                         */
/*                                                                            */
/* ************************************************************************** */
/*#end ACD#*/
/*#ACD# M(sem_s56_smb560 Header Author) Author*/
/*
 *  $Source: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_s56_smb560.h $
 *  $Revision: 1.1 $
 *  $Author: Prosch Christian (CC-PS/EPS2) (PHC2SI) $
 */
/*#end ACD#*/
/* ************************************************************************** *
 *  Description:
 * The SMA560 features two perpendicular, in plane measurement axis with a
 * measurement range of +-96g each. The communication with the SMA560 is done
 * via the SPI.
 * 
 * This module contains the sensor specific initialisation and background
 * monitoring tasks. Additionally this module has a dedicated real-time
 * evaluation function, as the requirements differ from other central sensors.
 * 
 * Reference to Documentation:  sem_s56_smb560_SDS.HTML
 *
 *
 *  Reference to Documentation:  sem_s56_smb560_SDS.HTML
 */
/* ********************** Framecode-Generator V2.0 ************************** */
/* EasyCASE (
   History */
/* ****************************** History *********************************** */
/*#ACD# M(sem_s56_smb560 Header) History*/
/*
 *  $Log: Tools/peace/sample/reports_SPS_sem_sensormgt_20130619_094630/_snapshot_/sem_s56_smb560.h  $
 *  Revision 1.1 2019/09/05 11:16:44CEST Prosch Christian (CC-PS/EPS2) (PHC2SI) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/System/Engine_SCM/Engine_SCM.pj
 *  Revision 1.1 2013/07/30 19:03:31CEST Reddivari Devendra Kumar (RBEI/ESA-PE1) (dvn2kor) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Tools/Tools.pj
 *  Revision 1.1 2013/06/19 06:19:04MESZ Vernon Hawes (RBEI/ESA1) (ver6cob) 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/TurboLIFT/Projects/AB12/AB12.pj
 *  Revision 5.14 2012/06/19 20:45:57IST Bharath Sambamoorthy (RBEI/ESA3) (bhs6kor) 
 *  removed diagsym masks for plausi fault
 *  --- Added comments ---  bhs6kor [2012/06/19 15:16:19Z]
 *  State changed: develop -> ready_for_review by bhs6kor
 *  
 *  --- Added comments ---  bhs6kor [2012/06/27 11:34:21Z]
 *  State changed: ready_for_review -> reviewed by bhs6kor
 *  
 *  --- Added comments ---  bhs6kor [2012/06/29 09:17:02Z]
 *  State changed: reviewed -> release by bhs6kor
 *  Revision 5.13 2012/06/18 16:35:00MESZ bhs6kor 
 *  new plausi handling added
 *  --- Added comments ---  bhs6kor [2012/06/18 14:39:35Z]
 *  State changed: develop -> ready_for_review by bhs6kor
 *  Revision 5.12 2012/02/20 15:07:13MEZ hkr2kor 
 *  Moved some definitions and comments related to fault info from c-file to h-file.
 *  No functional changes.
 *  --- Added comments ---  hkr2kor [2012/02/20 14:12:29Z]
 *  No change in hex files, release state inherited.
 *  --- Added comments ---  hkr2kor [2012/02/20 14:12:29Z]
 *  State changed: develop -> release by hkr2kor
 *  Revision 5.11 2011/08/19 14:39:41MESZ HKU2SI 
 *  version 5.10.1.3 copied to main branch
 *  --- Added comments ---  HKU2SI [2011/08/19 12:49:03Z]
 *  State changed: develop -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/08/19 12:49:08Z]
 *  State changed: reviewed -> tested by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/08/22 08:54:11Z]
 *  fix:Ptedt00082500
 *  --- Added comments ---  HKU2SI [2011/08/22 13:34:40Z]
 *   fix:Ptedt00082500
 *  --- Added comments ---  HKU2SI [2011/08/22 15:10:33Z]
 *  State changed: tested -> release by HKU2SI
 *  Revision 5.10.1.3 2011/08/17 10:23:04CEST HKU2SI 
 *  review findings Ptedt00082211 incorporated
 *  --- Added comments ---  HKU2SI [2011/08/18 11:33:27Z]
 *  State changed: develop -> reviewed by HKU2SI
 *  Revision 5.10.1.2 2011/08/15 13:47:41CEST HKU2SI 
 *  new system decision given by EPY2-Maier to realize g-range monitoring in background
 *  Revision 5.10.1.1 2011/08/03 14:54:18CEST HKU2SI 
 *  API S56_CheckGRangeFIQ added with empty body for CRQ189 implementation
 *  Revision 5.10 2011/06/20 11:36:28CEST HKU2SI 
 *  empty diagsym comments filled
 *  --- Added comments ---  HKU2SI [2011/06/20 14:25:32Z]
 *  Delta review done by EPS3-Frueh.
 *  --- Added comments ---  HKU2SI [2011/06/20 14:25:32Z]
 *  State changed: develop -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/06/20 14:39:47Z]
 *  State changed: reviewed -> release by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/06/30 09:15:11Z]
 *  fix:Ptedt00076211
 *  --- Added comments ---  HKU2SI [2011/06/30 12:04:37Z]
 *  minor changes to satisfy diagsym generation in build process
 *  Revision 5.9 2011/04/18 17:33:07CEST HKU2SI 
 *  comment for fault reaction and fault description reworked
 *  Revision 5.8 2011/04/11 08:48:57CEST HKU2SI 
 *  create_code rerun
 *  --- Added comments ---  HKU2SI [2011/04/11 07:02:14Z]
 *  State changed: develop -> ready_for_review by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/04/11 07:02:42Z]
 *  delta review done by ESP3-Frueh
 *  --- Added comments ---  HKU2SI [2011/04/11 07:02:42Z]
 *  State changed: ready_for_review -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/04/11 07:03:19Z]
 *  delta review done by ESP3-Frueh
 *  Revision 5.7 2011/04/08 09:23:04CEST HKU2SI 
 *  target values for BITE test changed
 *  Revision 5.6 2011/02/25 10:09:07CET HKU2SI 
 *  FLTREACTION introduced
 *  --- Added comments ---  HKU2SI [2011/02/25 14:09:02Z]
 *  release again, because only faultreaction as comment was introduced
 *  --- Added comments ---  HKU2SI [2011/02/25 14:09:02Z]
 *  State changed: develop -> release by HKU2SI
 *  Revision 5.5 2011/02/17 12:19:59CET HKU2SI 
 *  thresholds for BITE1,2 changed
 *  --- Added comments ---  HKU2SI [2011/02/21 10:41:45Z]
 *  State changed: develop -> tested by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/21 10:41:53Z]
 *  State changed: tested -> ready_for_review by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/21 13:14:32Z]
 *  deliver: Ptedt00067930 
 *  --- Added comments ---  HKU2SI [2011/02/21 13:27:35Z]
 *  State changed: ready_for_review -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/21 13:27:40Z]
 *  State changed: reviewed -> release by HKU2SI
 *  Revision 5.4 2011/01/21 11:14:03CET HKU2SI 
 *  CRQ_179 new plausibility function implemented
 *  --- Added comments ---  HKU2SI [2011/01/21 10:58:09Z]
 *  State changed: develop -> ready_for_review by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/04 13:05:52Z]
 *  State changed: ready_for_review -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/04 13:05:59Z]
 *  State changed: reviewed -> tested by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2011/02/04 13:06:03Z]
 *  State changed: tested -> release by HKU2SI
 *  Revision 5.3 2011/01/04 14:25:11CET bhs6kor 
 *  updated after review
 *  --- Added comments ---  bhs6kor [2011/01/06 09:03:39Z]
 *  State changed: develop -> ready_for_review by bhs6kor
 *  
 *  --- Added comments ---  bhs6kor [2011/01/14 10:10:40Z]
 *  State changed: ready_for_review -> reviewed by bhs6kor
 *  
 *  --- Added comments ---  bhs6kor [2011/01/14 10:10:46Z]
 *  State changed: reviewed -> tested by bhs6kor
 *  Revision 5.2 2010/11/29 15:53:58IST HKU2SI 
 *  revision 5.1.16 taken over unchanged to main branch
 *  --- Added comments ---  HKU2SI [2010/11/29 10:26:01Z]
 *  correction
 *  revision 5.1.1.6 taken unchanged to main branch
 *  --- Added comments ---  HKU2SI [2010/12/06 10:33:43Z]
 *  State changed: develop -> release by HKU2SI
 *  Revision 5.1.1.6 2010/11/29 09:37:46CET HKU2SI 
 *  parameters for BITE test updated. (Request from Kopplin Sascha (CC/EPY2))
 *  --- Added comments ---  HKU2SI [2010/11/29 09:08:05Z]
 *  delta review done by ESP3-Jonkmann 29.11.2010
 *  --- Added comments ---  HKU2SI [2010/11/29 09:08:05Z]
 *  State changed: develop -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2010/11/29 09:52:00Z]
 *  State changed: reviewed -> tested by HKU2SI
 *  Revision 5.1.1.5 2010/11/25 12:23:19CET HKU2SI 
 *  review findings incorporated Ptedt00062997
 *  Revision 5.1.1.4 2010/11/23 16:26:10CET HKU2SI 
 *  rebiew findings incorporated
 *  Revision 5.1.1.3 2010/11/19 17:16:57CET HKU2SI 
 *  create_code caught up
 *  --- Added comments ---  HKU2SI [2010/11/19 17:04:14Z]
 *  State changed: develop -> ready_for_review by HKU2SI
 *  Revision 5.1.1.2 2010/11/15 15:05:37CET HKU2SI 
 *  temporary check-in, new test cases added F3,F4
 *  Revision 5.1.1.1 2010/11/15 10:07:43CET HKU2SI 
 *  temporary check-in clock count monitoring improved
 *  Revision 5.1 2010/08/05 10:04:26CEST fru1si 
 *  - Removed DCU from AB10lib sensor management.
 *  - Adapted UML model for cust specific sensor modules (dependencies to lib APIs, separate header for struct definitions).
 *  - Re-ran code generator with latest templates.
 *  - No functional change --> previous state is taken over.
 *  --- Added comments ---  fru1si [2010/08/05 08:12:04Z]
 *  State changed: develop -> release by fru1si
 *  Revision 4.4 2010/05/06 09:30:27CEST HKU2SI 
 *  revision 4.3.1.8 taken over to main branch
 *  --- Added comments ---  HKU2SI [2010/05/06 07:34:19Z]
 *  State changed: develop -> reviewed by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2010/05/06 07:34:25Z]
 *  State changed: reviewed -> tested by HKU2SI
 *  
 *  --- Added comments ---  HKU2SI [2010/05/11 11:12:06Z]
 *  State changed: tested -> release by HKU2SI
 *  Revision 4.3.1.8 2010/05/05 10:10:45CEST HKU2SI 
 *  review findings incorporated
 *  Revision 4.3.1.7 2010/04/30 16:11:56CEST HKU2SI 
 *  beautification
 *  Revision 4.3.1.6 2010/04/30 12:07:52CEST HKU2SI 
 *  synchronization internal monitoring faults (StepupIni and clock count)
 *  Revision 4.3.1.5 2010/04/23 17:19:32CEST HKU2SI 
 *  variable, constant names corrected
 *  fault handling for clock count measurement improved
 *  Revision 4.3.1.4 2010/04/22 11:47:47CEST HKU2SI 
 *  for debugging: clock count stored in ringbuffer
 *  Revision 4.3.1.3 2010/04/19 13:40:34CEST HKU2SI 
 *  create_code executed
 *  Revision 4.3.1.2 2010/04/19 13:24:50CEST HKU2SI 
 *  comment added
 *  Revision 4.3.1.1 2010/04/16 16:29:54CEST HKU2SI 
 *  temporary check-in
 *  module merged between EAO1-Satheesh R and EPS3-Kuenzel
 *  !!! INLINE is not activated
 *  Revision 4.3 2010/03/29 17:47:57CEST HKU2SI 
 *  debug variable removed
 *  Revision 4.2 2010/03/29 11:29:57CEST HKU2SI 
 *  superfluous constants removed
 *  Revision 4.1.1.11 2010/03/26 13:32:38CET str3kor 
 *  moved C_SMA560MaxSensors_U8X to sem_sensormgtpar.p(1.2.1.18.3.1)
 *  Revision 4.1.1.10 2010/03/25 19:41:57IST str3kor 
 *  temporary check in (clock count and timer constants size changed)
 *  Revision 4.1.1.9 2010/03/24 21:07:16IST HKU2SI 
 *  revision 4.1.1.8.1.1 merged with 4.1.1.8.2.2 to 4.1.1.8.2.3 and checked in as 4.1.1.9
 *  review findings from Satheesh with error test cases from Kuenzel
 *  Revision 4.1.1.8.2.3 2010/03/24 16:28:00CET HKU2SI 
 *  revision 4.1.1.8.1.1 merged with 4.1.1.8.2.2 to 4.1.1.9
 *  review findings from Satheesh with error test cases from Kuenzel
 *  Revision 4.1.1.8.2.2 2010/03/24 14:31:20CET HKU2SI 
 *  temporary check-in, error test cases added
 *  Revision 4.1.1.8.2.1 2010/03/24 14:06:55CET HKU2SI 
 *  temporary ckeck-in
 *  - error test cases introduced
 *  - ALL appended to timer function name
 *  Revision 4.1.1.8 2010/03/23 09:18:07CET HKU2SI 
 *  temporary check-in (clock monitoring reworked, findings incorporated)
 *  Revision 4.1.1.7 2010/03/17 11:55:45CET HKU2SI 
 *  Y_SMB560EMC disabled
 *  Revision 4.1.1.6 2010/03/16 15:03:05CET HKU2SI 
 *  temporary check-in (clock clounter monitoring is working)
 *  Revision 4.1.1.5 2010/03/12 16:52:37CET HKU2SI 
 *  temporary check-in findings and rudimentary clock count monitoring
 *  Revision 4.1.1.3 2010/03/05 17:33:19CET HKU2SI 
 *  temporary check-in
 *  MISRA, cyclic complexity removed, variables instanced
 *  Revision 4.1.1.1 2010/01/15 14:16:22CET HKU2SI 
 *  temprary solution for ASIC hw measurement
 *  Revision 4.1 2009/09/29 15:15:44CEST hku2si 
 *  module generated with AMEOS AB10 from main path
 *  Revision 4.0 2009/08/27 13:25:15CEST hku2si 
 *  new ASI (algo sensor interface) located to main branch
 *  Revision 1.11.1.1 2009/05/18 14:41:35CEST hku2si 
 *  changes for C0-Sample tapeout verification
 *  Revision 1.2.1.1 2008/10/14 11:36:32CEST hku2si 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/au1043/ab10lib_hwd/sem_sensormgt/sem_sensormgt.pj
 *  Revision 1.1 2008/10/09 13:41:44CEST hku2si 
 *  Initial revision
 *  Member added to project g:/MKS/Projects/ab10_base/ab10lib_hwd/sem_sensormgt/sem_sensormgt.pj
 */
/*#end ACD#*/
/* ************************************************************************** */
/* EasyCASE ) */
/* EasyCASE (
   Includes */
/* PRQA S 1-9999 suppress_foreign_warnings_sem_s56_smb560_h */
/* EasyCASE (
   Standard includes (utils + own header) */
#include "utl_options.p"
#include "utl_tb_typesbase.h"
/* EasyCASE ) */
/* EasyCASE (
   Direct includes for package SEM_SensorMgt */
#include "sem_smr_sensormanager.h" 
#include "sem_std_sensortypedefs.h" 
/* EasyCASE ) */
/* PRQA L:suppress_foreign_warnings_sem_s56_smb560_h */
/* EasyCASE ) */
/* EasyCASE (
   #Define Constants */
/*#ACD# M(Constants sem_s56_smb560)  Definitions*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE - */
/* #define Y_SMA560ErrorTestCases */ /* control error test cases */
                                     /* precondition, inclusion of eem_eem_eeprommgr.h */
#undef Y_SMA560ErrorTestCases        /* control error test cases to include eem_eem_eeprommgr.h */
                                     /* which is needed for te_EEMgrOperStatus */
/* EasyCASE - */
#ifdef Y_SMA560ErrorTestCases
#include "eem_eem_eeprommgr.h"
#endif
/* EasyCASE - */
/* #define Y_SMB560DbgInfo */       /* !!! debug information ony for test purposes */
#undef Y_SMB560DbgInfo              /* no debug information (normal mode) */
/* EasyCASE - */
/* #define Y_SMB560EMC */           /* !!! do not react on SMA560 faults */ 
#undef Y_SMB560EMC                  /* EMC not activated (normal mode) */
/* EasyCASE - */
/*!DEF SWITCH Y_Option_sma560_error_ctrl OFF  */ /* OFF  for normal mode */
/*!DEF SWITCH Y_Option_sma560_dbg_info   OFF  */ /* OFF  for normal mode */
/* EasyCASE ( 19
   sensor specific thresholds */
#define C_SMA560DeviceID_U8X                     0x56u  /* expected Device ID of this Asic */

#define C_SMA560AverageExp_U8X                   4u     /* number of realtime measurements used for an averaged signal,
specified in 2^x fashion (4 => 16 samples) */

#define C_SMA560BitePosMinThreshold_S16X         59     /* minimum threshold for the positive BITE test */
#define C_SMA560BitePosMaxThreshold_S16X         181    /* maximum threshold for the positive BITE test */

#define C_SMA560BiteNegMinThreshold_S16X        -181    /* minimum threshold for the negative BITE test */
#define C_SMA560BiteNegMaxThreshold_S16X        -59     /* maximum threshold for the negative BITE test */

#define C_SMA560OffsetValueMin_S16X             -10     /*  offset value min for each sensor channel */
#define C_SMA560OffsetValueMax_S16X              10     /*  offset value max for each sensor channel */

#define C_SMA560ResetDelay_U8X                   20u    /* delay after G range selection and activation is active (us) */
                                                        /* reason: TFF equal 1 is checked after a delay of 20�s */
#define C_SMA560Delay10ms_U16X                   10u    /* delay 10 ms */
#define C_SMA560Delay20ms_U16X                   20u    /* delay 20 ms */
#define C_SMA560Delay30ms_U16X                   30u    /* delay 30 ms */

#define C_SMA560Delay1_U32X                      15000u /* delay 15 ms in �s */
#define C_SMA560MaxDelayClkCnt_U32X              31000u /* delay 31 ms in �s, after this time clock count evalutaion 
                                                           is discarded */ 

#define C_SMA560OutOfRng496LSB_S16X               496   /* out of range value 496LSB after SW reset */
/* EasyCASE - */
/* clock counter percentage */
/* example:
 *             - calculation of percentage for clock count tolerance
 *               8 percent => 0,08 / (1/2^16) = 0,08 / (1/65536) = 0,08 / 0,00001526 = 5242
 *                            0,08 * 2^16 = 5242
 *                            0,08 = 5242 / 2^16 = 5242 >> 16
*/
#define C_SMA560ClockCntPercent_U16X             5242
/* EasyCASE ) */
/* EasyCASE ( 20
   SPI Commands for SMB560 */
/* read commands */
#define C_SMA560SPIReadIniOfsChA8Bits_U16X      0x5100u  /* Read initial offset cancellation value channel A lower 8 bits */
#define C_SMA560SPIReadIniOfsChA4Bits_U16X      0x5200u  /* Read initial offset cancellation value channel A lower 4 bits */
#define C_SMA560SPIReadIniOfsChB8Bits_U16X      0x5400u  /* Read initial offset cancellation value channel B lower 8 bits */
#define C_SMA560SPIReadIniOfsChB4Bits_U16X      0x5700u  /* Read initial offset cancellation value channel B lower 4 bits */

#define C_SMA560SPIReadChannel1_U16X            0x8000u  /* Read sensor Channel 1 */
#define C_SMA560SPIReadChannel2_U16X            0xE000u  /* Read sensor Channel 2 */

#define C_SMA560SPIReadDeviceID_U16X            0x0100u  /* Read Device ID */
#define C_SMA560SPIReadMonitorData1_U16X        0x2300u  /* Read Monitor Data 1 */
#define C_SMA560SPIReadMonitorData2_U16X        0x2500u  /* Read Monitor Data 2 */


/* commands for inital tests / programming */
#define C_SMA560SPISelect96GRange_U16X          0x5d00u  /* select G range 96g for channel A and B */
#define C_SMA560SPIReadAccelRange_U16X          0x0b00u  /* read acceleration range for channel A and B */
#define C_SMA560SPIAccel96gRange_U16X           0x0000u  /* target value 96g range for channel A and B */

#define C_SMA560SPIOffsetCancellationON_U16X    0x7905u  /* switch on offset cancellation for both channels */
#define C_SMA560SPIOffsetCancellationOFF_U16X   0x7900u  /* switch off offset cancellation for both channels */
#define C_SMA560SPIReadOffsetCancellation_U16X  0x7A00u  /* Read Offset cancellation status */

#define C_SMA560OffsetCancellationFast_U8X      0x0Fu    /* fast offset cancellation on both cannels active */
#define C_SMA560OffsetCancellationSlow_U8X      0x0Au    /* slow offset cancellation on both cannels active */
#define C_SMA560OffsetCancellationOff_U8X       0x00u    /* offset cancellation off */

#define C_SMA560SPIDemandBite1_U16X             0x3809u  /* Selftest: Channel 1: pos Channel 2: neg */
#define C_SMA560SPIDemandBite2_U16X             0x3806u  /* Selftest: Channel 1: neg Channel 2: pos */
#define C_SMA560SPIDemandBiteOFF_U16X           0x3800u  /* Selftest: both Channels off  */

#define C_SMA560SPIDemandInterpolationOn_U16X   0x6b01u  /* switch linear interpolation on */

#define C_SMA560SPIProgSafetyID_U16X            0x5b00u  /* program safety-ID */
#define C_SMA560SPIReadSafetyID_U16X            0x3700u  /* read safety-ID */

#define C_SMA560SPIReadClockCount_U16X          0x0400u  /* read clock count */

#define C_SMA560SPIEOPCommand_U16X              0x0d00u  /* End of programming */
/* EasyCASE - */
/* SPI-Communication Masks */
#define M_SMA560TFFMisoResponse_U16X            0x8000u  /* MISO response  */

#define M_SMA560SPIMoni2LinearInterpol_U16X     0x0001u  /* bit mask for interpolation mode, 
                                                            if bit0 is 0 => linear interpolation active */

#define M_SMA560SPIMoni2Interpolation_U16X      0x0001u  /* LSB on Monitor2-Regster indicates interpolation mode */

#define M_SMA560MISOResponseLower8Bits_U16X     0x00ffu  /* lower 8 bits auf MISO response */
#define M_SMA560MISOChkMaskLower4Bits_U16X      0x000fu  /* mask for lower 4 bits of MISO response */
#define M_SMA560MISOResponseLower4Bits_U16X     0x000fu  /* lower 4 bits of MISO response */
#define M_SMA560MISOResponseSOCActive_U16X      0x100Au  /* slow offset cancellation active on both channels */
/* EasyCASE ) */
/* EasyCASE ( 21
   Masks */
/* Masks for Internal Monitoring SPI-Messages
 *    The SMB560 has two internal monitoring registers (8bit each), which indicate
 *    the sensor errors detected by the internal monitoring of the asic.
 */
 

/* group 1 */
#define M_SMA560MoniOC1_U16X                  0x0001u    /* data monitor1 bit0 OC1 */
#define M_SMA560MoniOC2_U16X                  0x0002u    /* data monitor1 bit1 OC2 */

#define M_SMA560MoniOCC1_U16X                 0x0004u    /* data monitor1 bit2 OCC1 */
#define M_SMA560MoniOCC2_U16X                 0x0008u    /* data monitor1 bit3 OCC2  */

/* group 2 */
#define M_SMA560MoniNoEclk_U16X               0x0010u    /* data monitor1 bit4 No ECLK */

/* group 3 */
#define M_SMA560MoniEMprod_U16X               0x0020u    /* data monitor1 bit5 extended mode for production relevant tests */

/* group 4 */
#define M_SMA560MoniSID_U16X                  0x0200u    /* data monitor2 bit1 SID (channel1 and channel 2) is in 
                                                            default state, no SID programming occurred in this power on cycle. */

#define M_SMA560MoniNoOff1_U16X               0x0800u    /* data monitor2 bit3, NoOff1: No Fast or slow offset cancellation 
                                                            triggered for channel1 during this power-on cycle. */
#define M_SMA560MoniNoOff2_U16X               0x1000u    /* data monitor2 bit4, NoOff2: No Fast or slow offset cancellation 
                                                            triggered for channel2 during this power-on cycle. */

#define M_SMA560MoniNoTe1_U16X                0x2000u    /* data monitor2 bit5, no selftest function of channel1 triggered 
                                                            during this power on cycle. */
#define M_SMA560MoniNoTe2_U16X                0x4000u    /* data monitor2 bit6, no selftest function of channel2 triggered 
                                                            during this power on cycle. */
#define M_SMA560MoniNoEOP_U16X                0x8000u    /* data monitor2 bit7 */

/* group 5 */
#define M_SMA560MoniCRC_U16X                  0x0040u    /* data monitor1 bit6, EEPROM check error, CRC Error */
#define M_SMA560MoniSPIEC_U16X                0x0080u    /* data monitor1 bit7, SPI-interface error check. Deviation between 
                                                            data register and data_check register. */

/* group 6 */
#define M_SMA560MoniLI_U16X                   0x0100u    /* data monitor2 bit0 Interpolation in wrong mode (on vs off) */
                                                         /* the remaining bits of Moni 2 are not monitored */
 

/* */
#define M_SMA560MoniFaultGrp1_U8X              0x01u  /* OC1, OC2, OCC1, OCC2 together */
#define M_SMA560MoniFaultGrp2_U8X              0x02u  /* no ECLK */
#define M_SMA560MoniFaultGrp3_U8X              0x04u  /* extended mode for production relevant tests */
#define M_SMA560MoniFaultGrp4_U8X              0x08u  /* SID, NoOff1, NoOff2, NoTe1, NoTe2, NoEOP */
#define M_SMA560MoniFaultGrp5_U8X              0x10u  /* SPI-interface error check */
#define M_SMA560MoniFaultGrp6_U8X              0x20u  /* Interpolation in wrong mode (on vs off) */


#define M_SMA560FOCoff_U16X                    0x000fu /* status FOC is switched of */
/* EasyCASE - */
#define M_SMA560LowNibble_U16X                 0x000fu /* mask low nibble */
#define M_SMA560LowByte_U16X                   0x00ffu /* mask low byte */
/* EasyCASE - */
#define M_SMA560Lower2Bits_U16X                0x0003u /* mask for logical AND bit1,0 */
#define M_SMA560Lower3Bits_U16X                0x0007u /* mask for logical AND bit2,1,0 */
/* EasyCASE - */
/* masks to prevent fault step down if internal monitoring fault is active */
#define M_SMA560StepupIniFlt_U8X               0x01u /* mask, if 1 => fault for StepupIni active */
/* EasyCASE ) */
/* EasyCASE ( 42
   Constants */
#define C_SMA560Shift8_U8X                    0x08u   /* shift constant */
#define C_SMA560Shift4_U8X                    0x04u   /* shift constant */
/* EasyCASE - */
#define C_SMA560RTDataErrRetries_U8X          3u      /* maximum no of times sensor data is read in case of error in sensor data*/
#define C_SMA560MaxOfsOrBITEErrCnt_U8X        19u     /* maximum no of repetition in case offset error or BITE failed*/
/* EasyCASE - */
#define C_SMA560NoOfChannels_U8X              2u      /*!DEF ARRAYLEN C_SMA560NoOfChannels_U8X 2 */
/* EasyCASE - */
#define C_SMA560MaxLIRepetit_U8X              3u      /* maximal number of repetitions to enable LI */
/* EasyCASE - */
#define C_SMA560ClkCntrRepetit_U8X            4u      /* maximal number of clock count repetitions failed in series  */
/* EasyCASE - */
#define C_SMA560Div4_S8X                      4       /* division by 4 */
/* EasyCASE - */
#ifdef Y_SMB560DbgInfo
/* EasyCASE - */
#define C_SMA560RngBufSize_U8X                5       /*!DEF ARRAYLEN C_SMA560RngBufSize_U8X 5 */
/* EasyCASE - */
#endif
/* EasyCASE - */
#ifdef Y_SMA560ErrorTestCases
/* EasyCASE - */
/* Mask for test case generations */
/* for V_SMA560DbgFaultControl1_U16E */
#define M_SMA560_DbgCtrlA1_U16X         0x0001 /* A1 FOC is not switched on */
#define M_SMA560_DbgCtrlA2_U16X         0x0002 /* A2 BITE 1 is not activated */
#define M_SMA560_DbgCtrlA3_U16X         0x0004 /* A3 BITE 2 is not activated */
#define M_SMA560_DbgCtrlA4_U16X         0x0008 /* A4 BITE is not switched off */
#define M_SMA560_DbgCtrlA5_U16X         0x0010 /* A5 SPI for safetyID response manipulated */
#define M_SMA560_DbgCtrlA6_U16X         0x0020 /* A6 interpolation mode is not activated */

#define M_SMA560_DbgCtrlB1_U16X         0x0040 /* B1 wrong device ID */
#define M_SMA560_DbgCtrlB2_U16X         0x0080 /* B2 TFF not in ASIC response */
#define M_SMA560_DbgCtrlB3_U16X         0x0100 /* B3 G range is not 96g */
#define M_SMA560_DbgCtrlB4_U16X         0x0200 /* B4 FOC is not switched off */
#define M_SMA560_DbgCtrlB5_U16X         0x0400 /* B5 FOC is not switched off, in reinitialize FOC */
#define M_SMA560_DbgCtrlB6_U16X         0x0800 /* B6 clock count out of range, init phase */
#define M_SMA560_DbgCtrlB7_U16X         0x1000 /* B7 monitor data12 unequal 0  and  no SOC */
#define M_SMA560_DbgCtrlB8_U16X         0x2000 /* B8 group 1..5 set */   
#define M_SMA560_DbgCtrlB9_U16X         0x4000 /* B9 clock count out of range, steady state */
#define M_SMA560_DbgCtrlB10_U16X        0x8000 /* B10 g-range selection invalid */

#define M_SMA560_DbgCtrlC1_U16X         0x00010000 /* C1 channel register offset out of range */
#define M_SMA560_DbgCtrlC2_U16X         0x00020000 /* C2 offset value out of range */

#define M_SMA560_DbgCtrlD1_U16X         0x00040000 /* D1 channel BITE1 value out of range */

#define M_SMA560_DbgCtrlE1_U16X         0x00080000 /* E1 offending bits TST, NRO in init phase */
#define M_SMA560_DbgCtrlE2_U16X         0x00100000 /* E2 offending bits SID */
#define M_SMA560_DbgCtrlE3_U16X         0x00200000 /* !!! not used */

#define M_SMA560_DbgCtrlF1_U16X         0x00400000 /* F1 error test case, sensor value hanging */
#define M_SMA560_DbgCtrlF2_U16X         0x00800000 /* F2 plausibilty fault out of range  -480 .. 480LSB */
#define M_SMA500_DbgCtrlF3_U16X         0x01000000 /* F3 BITE1 channel B 19times out of range than in range after BITE */
#define M_SMA500_DbgCtrlF4_U16X         0x02000000 /* F4 OC channel A 19times out of range than in range after BITE */
/* EasyCASE - */
#endif
/* EasyCASE ) */
/* EasyCASE ( 67
   Fault masks */
/* Additional fault info regarding programming fault */
                                     /*! DEF MASKS SMA560InternAsicPrgmMask */
#define M_SMA560IntrlPrgm0_U8X 0x01u /*! 00:  A1 reinit FOC, FOC failed to switch on */
#define M_SMA560IntrlPrgm1_U8X 0x02u /*! 01:  A2 BITE1 not activated */
#define M_SMA560IntrlPrgm2_U8X 0x04u /*! 02:  A3 BITE2 not activated */
#define M_SMA560IntrlPrgm3_U8X 0x08u /*! 03:  A4 BITE not switched off */
#define M_SMA560IntrlPrgm4_U8X 0x10u /*! 04:  A5 SID programming failed */
#define M_SMA560IntrlPrgm5_U8X 0x20u /*! 05:  A6 linear interpolation not activated */
                                     /*! END DEF */
/* EasyCASE - */
/* Additional fault info regarding BITE fault */
                                    /*! DEF MASKS SMA560BITEMask */
#define M_SMA560OfsChA_U8X   0x01u /*! 00:  D1 Channel A Ofs not in range */
#define M_SMA560BITE1ChA_U8X 0x02u /*! 01:  D1 Channel A BITE1 failed */
#define M_SMA560BITE2ChA_U8X 0x04u /*! 02:  D1 Channel A BITE2 failed */
#define M_SMA560OfsChB_U8X   0x08u /*! 03:  D1 Channel B Ofs not in range */
#define M_SMA560BITE1ChB_U8X 0x10u /*! 04:  D1 Channel B BITE1 failed */
#define M_SMA560BITE2ChB_U8X 0x20u /*! 05:  D1 Channel B BITE2 failed */
                                    /*! END DEF */
/* EasyCASE - */
/* Additional fault info regarding offset cancellation faults */
/* Faults are stored temporarily in p_SMA560Data_xsr->V_StatusInfo_U8X */
/* For offset cancellation fault the faults from BITE1,2 and respective channel A or B are mapped to OC fault. */
/* Because the mask has only 6 bits the root case for BITE1, BITE2 is summarized
   M_SMA560OfsChA_U8X   => M_SMA560OfsChAafterBITE_U8X
   M_SMA560OfsChB_U8X   => M_SMA560OfsChBafterBITE_U8X
   M_SMA560BITE1ChA_U8X => M_SMA560OfsChABITE1or2_U8X
   M_SMA560BITE2ChA_U8X => M_SMA560OfsChABITE1or2_U8X
   M_SMA560BITE1ChB_U8X => M_SMA560OfsChBBITE1or2_U8X
   M_SMA560BITE2ChB_U8X => M_SMA560OfsChBBITE1or2_U8X
*/
                                    /*! DEF MASKS SMA560OfsCancellMask */
#define M_SMA560ReinitFOC_U8X        0x01u /*! 00:  C1 reinit FOC, FOC out of range */
#define M_SMA560OfsChAafterBITE_U8X  0x02u /*! 01:  C2 channel A OC fault after BITE */
#define M_SMA560OfsChBafterBITE_U8X  0x04u /*! 02:  C2 channel B OC fault after BITE */
#define M_SMA560OfsChABITE1or2_U8X   0x08u /*! 03:  C2 channel A OC fault BITE1 or 2 after BITE */
#define M_SMA560OfsChBBITE1or2_U8X   0x10u /*! 04:  C2 channel B OC fault BITE1 or 2 after BITE */
                                    /*! END DEF */
/* EasyCASE ) */
/*! FLTREACTION FltCsAsicXYProgramming: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsAsicXYInternalMonitoring: E_DisableAlgoFrontRear */
/* EasyCASE - */
/*! FLTREACTION FltCsChannel1BITE: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1OffsetCancellation: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1Communication: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel1Plausibility: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2BITE: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2OffsetCancellation: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2Communication: E_DisableAlgoFrontRear */
/*! FLTREACTION FltCsChannel2Plausibility: E_DisableAlgoFrontRear */
/* EasyCASE - */
/*! FLTDESC MASKS SMA560InternAsicPrgmMask FltCsAsicXYProgramming: XY Sensor: Programming failed */
/* EasyCASE - */
/*! FLTDESC ENUM te_SMA560IntrnlMoniFault FltCsAsicXYInternalMonitoring: XY Sensor: Internal monitoring error */
/* EasyCASE - */
/*! FLTDESC MASKS SMA560BITEMask FltCsChannel1BITE: XY Sensor Ch 1: selftest failed */
/*! FLTDESC MASKS SMA560OfsCancellMask FltCsChannel1OffsetCancellation: XY Sensor Ch 1: offset cancellation failed */
/*! FLTDESC ENUM te_CsCommFault FltCsChannel1Communication: XY Sensor Ch 1: communication error (SPI) */
/* EasyCASE - */
/*! FLTDESC MASKS SMA560BITEMask FltCsChannel2BITE: XY Sensor Ch 2: selftest failed */
/*! FLTDESC MASKS SMA560OfsCancellMask FltCsChannel2OffsetCancellation: XY Sensor Ch 2: offset cancellation failed */
/*! FLTDESC ENUM te_CsCommFault FltCsChannel2Communication: XY Sensor Ch 2: communication error (SPI) */
/* EasyCASE - */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   ENUM and struct Definitions */
/*#ACD# M(Enums sem_s56_smb560)  Enums*/
/*#end ACD#*/
/*#ACD# M(Enums sem_s56_smb560 leadout)  Enums*/
/* EasyCASE - */
/* user defined code to be added here ... */
/* EasyCASE ( 17
   enum te_SMA560Status */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum                                 /*! DEF ENUM te_SMA560Status */
{
  E_SMA560NotConfigured,                     /*! E_SMA560NotConfigured: sensor is not configured */
  E_SMA560SensorDisabled,                    /*! E_SMA560SensorDisabled: sensor disabled because of a fault */
  E_SMA560InitPart1,                         /*! E_SMA560InitPart1: call of state machine for initialization part1 */
  E_SMA560InitPart2,                         /*! E_SMA560InitPart2: call of state machine for initialization part2 */
  E_SMA560InitPart3,                         /*! E_SMA560InitPart3: call of state machine for initialization part3 */
  E_SMA560InitPart4,                         /*! E_SMA560InitPart4: call of state machine for initialization part4 */
  E_SMA560InitPart5,                         /*! E_SMA560InitPart5: call of state machine for initialization part5 */
  E_SMA560InitEOPAndEvaluation,              /*! E_SMA560InitEOPAndEvaluation: send EOP and check status in regard */
                                             /*  to monitor data1,2 and change monitoring of communication flags */
  E_SMA560SteadyState1,                      /*! E_SMA560SteadyState1: sensor is in steady state 1 (fetch internal monitoring) */
  E_SMA560SteadyState2,                      /*! E_SMA560SteadyState2: sensor is in steady state 2 (evaluate internal monitoring) */
  E_SMA560SteadyState3                       /*! E_SMA560SteadyState3: sensor is in steady state 3 (communication check) */
} te_SMA560Status;                           /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 25
   enum te_SMA560InitPart1 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                            /*! DEF ENUM te_SMA560InitPart1 */
  E_SMA560InitGRangePart1,                   /*! E_SMA560InitGRangePart1: perform SW reset and select G-Range for 96g */
  E_SMA560CheckAccelRange                    /*! E_SMA560CheckAccelRange: verify selected G-Range */ 
} te_SMA560InitPart1;                        /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 29
   enum te_SMA560InitPart2 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                 /*! DEF ENUM te_SMA560InitPart2 */
  E_CheckIfFOCisOFF,              /*! E_CheckIfFOCisOFF: wait until 22ms are elapsed after G-Range selection of ASIC */
                                  /*  check if FOC is automatically switched of by the ASIC */
  E_SMA560ReadInitialOfs,         /*! E_SMA560ReadInitialOfs: read initial offset register values */
                                  /* and build 12 bit value in two's complement respectively for both channels */
  E_SMA560DoAveragingAndEval      /*! E_SMA560DoAveragingAndEval: build averge value over 16 samples for both channels */
} te_SMA560InitPart2;             /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 37
   enum te_SMA560InitPart3 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                            /*! DEF ENUM te_SMA560InitPart3 */
  E_SMA560ReinitFOC,                         /*! E_SMA560ReinitFOC: reinit FOC if previous evaluation failed */
  E_SMA560WaitCheckIfFOCisOff,               /*! E_SMA560WaitCheckIfFOCisOff: wait minimum 18ms and check if FOC is off */
  E_SMA560BuildAverageAfterFOC,              /*! E_SMA560BuildAverageAfterFOC: build averge value over 16 samples for both channels */
  E_SMA560InitStartBite1,                    /*! E_SMA560InitStartBite1: start BITE 1, switch on BITE 1 (pos channel 1 / neg channel 2) */
  E_SMA560InitWaitForBite1,                  /*! E_SMA560InitWaitForBite1: perform waiting time and continue with building average value */
  E_SMA560InitStartBite2                     /*! E_SMA560InitStartBite2: start BITE 2, switch on BITE 2 (neg channel 1 / pos channel 2) */
} te_SMA560InitPart3;                        /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 61
   enum te_SMA560InitPart4 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                            /*! DEF ENUM te_SMA560InitPart4 */
  E_SMA560InitWaitForBite2,                  /*! E_SMA560InitWaitForBite2: perform waiting time and continue with building average value */
  E_SMA560StoreBITE2,                        /*! E_SMA560StoreBITE2: store channel1,2 for BITE 2 */
  E_SMA560TestIfBiteOff,                     /*! E_SMA560TestIfBiteOff: check if sensor test is off */
  E_SMA560SOfsAfterBITE,                     /*! E_SMA560SOfsAfterBITE: store offset values after BITE */
  E_SMA560InitEvalOfsAfterBITE,              /*! E_SMA560InitEvalOfsAfterBITE: do evaluation of offset values */
  E_SMA560InitEvalBite                       /*! E_SMA560InitEvalBite: do evaluation of BITE tests and check if sensor is used for SCON test */
} te_SMA560InitPart4;                        /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 41
   enum te_SMA560InitPart5 */
/* EasyCASE < */
/* This enum encodes the states for a SMB560 sensor */
typedef enum
{                                    /*! DEF ENUM te_SMA560InitPart5 */
  E_SMA560SensorUsedForSCON,         /*! E_SMA560TestIfBiteOff: check if SMA560 sensor is used for SCON */ 
  E_SMA560InitWaitSconTest,          /*! E_SMA560InitWaitSconTest: wait until SCON test is done if sensor is used for SCON test */
  E_SMA560ProgramSID,                /*! E_SMA560ProgramSID: program safety UD */
  E_SMA560ChkLinearInterpolation,    /*! E_SMA560ChkLinearInterpolation: check if linear interpolation LI is active (automatically switched on by ASIC) */
  E_SMA560EnableLinearInterpolation  /*! E_SMA560EnableLinearInterpolation: if LI mode is not automatically switched on switch LI on manually by initialization routine */
} te_SMA560InitPart5;                /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 57
   struct ts_SMA560Data */
/* EasyCASE < */
typedef struct {     /*! DEF STRUCT ts_SMA560Data */
U32 V_DelayTimer_U32X;                              /*! V_DelayTimer_U32X: Measures time delay during clock counter check all 20ms */
U16 V_PrevClockCount_U16X;                          /*! V_PrevClockCount_U16X: Previous clock count */
S16 V_IniOfsRegValueChA_S16X;                       /*! V_IniOfsRegValueChA_S16X: Stores initial offset value for Channel A */
S16 V_IniOfsRegValueChB_S16X;                       /*! V_IniOfsRegValueChB_S16X: Stores initial offset value for Channel B */
S16 V_ChannelBiteOfsChA_S16X;                       /*! V_ChannelBiteOfsChA_S16X: Stores offset value for channel A after BITE */
S16 V_ChannelBiteOfsChB_S16X;                       /*! V_ChannelBiteOfsChB_S16X: Stores offset value for channel B after BITE */
te_SMA560InitPart1 E_InitPart1_SXX;                 /*!ENUM te_SMA560InitPart1 E_InitPart1_SXX: state init part 1 */
te_SMA560InitPart2 E_InitPart2_SXX;                 /*!ENUM te_SMA560InitPart2 E_InitPart2_SXX: state init part 2 */
te_SMA560InitPart3 E_InitPart3_SXX;                 /*!ENUM te_SMA560InitPart3 E_InitPart3_SXX: state init part 3 */
te_SMA560InitPart4 E_InitPart4_SXX;                 /*!ENUM te_SMA560InitPart4 E_InitPart4_SXX: state init part 4 */
te_SMA560InitPart5 E_InitPart5_SXX;                 /*!ENUM te_SMA560InitPart5 E_InitPart5_SXX: state init part 5 */
te_Boolean E_IsInterMoniFltQual_SXX;                /*!ENUM te_Boolean E_IsInterMoniFltQual_SXX: Indicates whether internal monitoring fault is qualified or not */
U8 V_IntrlMoniFltActiv_U8X;                         /*! V_IntrlMoniFltActiv_U8X: internal monitoring fault activ clock count, StepUpIni fault */


U8 V_ClkCntrRepetit_U8X;                            /*! V_ClkCntrRepetit_U8X:Counts No.of clock count samples taken during counter check */
U8 V_Counter_U8X;                                   /*! V_Counter_U8X: Number of retries to activate linear interpolation */
U8 F_InitTestPassed_U8X;                            /*! F_InitTestPassed_U8X: Indicates Initial Tests (Offset, BITE) are finished or not */
U8 V_OfsBITECntr_U8X;                               /*! V_OfsBITECntr_U8X: Number of offset cancel / BITE test repetitions */
U8 V_StatusInfo_U8X;                                /*! V_StatusInfo_U8X: stores fault status for OC and BITE test after BITE test is done */
U8 A_NoOfWrongDataINTW_U8X[C_SMA560NoOfChannels_U8X]; /*! ARRAY A_NoOfWrongDataINTW_U8X[C_SMA560NoOfChannels_U8X]:No of times sensor data is out of range for each channel */

#ifdef Y_SMB560DbgInfo
U8 V_CntrNoTFFset_U8X;                              /*! SWITCH Y_Option_sma560_dbg_info=ON V_CntrNoTFFset_U8X: No of times the TFF flag is not set after Initial SW reset */
U8 V_CntrSWReset_U8X;                               /*! SWITCH Y_Option_sma560_dbg_info=ON V_CntrSWReset_U8X: No of times SW reset during sensor initialization */
U8 V_AsicNr_U8X;                                    /*! SWITCH Y_Option_sma560_dbg_info=ON V_AsicNr_U8X: Indicates ASIC number */
U8 V_AsicNrCnv_U8X;                                 /*! SWITCH Y_Option_sma560_dbg_info=ON V_AsicNrCnv_U8X: Z_CsAsicDev2SpiDev(for ASIC no) */
U16 V_Devicedata_U16X;                              /*! SWITCH Y_Option_sma560_dbg_info=ON V_Devicedata_U16X: SPI response after Device ID reading */
U16 V_TFFResponse_U16X;                             /*! SWITCH Y_Option_sma560_dbg_info=ON V_TFFResponse_U16X: SPI response after SW reset to check expected TFF */
U16 V_GRange_U16X;                                  /*! SWITCH Y_Option_sma560_dbg_info=ON V_GRange_U16X: monitors actual G-range */
U16 V_ClockCount_U16X;                              /*! SWITCH Y_Option_sma560_dbg_info=ON V_ClockCount_U16X: Current clock count value */
U16 V_MonitorData12_U16X;                           /*! SWITCH Y_Option_sma560_dbg_info=ON V_MonitorData12_U16X: Stores Asic Monitor data 1 and 2  */
U16 V_SOCStatus_U16X;                               /*! SWITCH Y_Option_sma560_dbg_info=ON V_SOCStatus_U16X: Slow Offset Cancellation status after EOP */
U8 V_StatusInfo1_U8X;                               /*! SWITCH Y_Option_sma560_dbg_info=ON V_StatusInfo1_U8X: Stores additional flt info after EOP */
S16 V_CancelFOCValueChA_S16X;                       /*! SWITCH Y_Option_sma560_dbg_info=ON V_CancelFOCValueChA_S16X: Initial Cancelled Offset value for channel X */
S16 V_CancelFOCValueChB_S16X;                       /*! SWITCH Y_Option_sma560_dbg_info=ON V_CancelFOCValueChB_S16X: Initial Cancelled Offset value for channel Y */
U8  V_Channel_U8R;                                  /*! SWITCH Y_Option_sma560_dbg_info=ON V_Channel_U8R: Shows Channel index */
U8  V_ChIdxForInst_U8R;                             /*! SWITCH Y_Option_sma560_dbg_info=ON V_ChIdxForInst_U8R: Channel index 0 or 1 for current sensor */
U16 V_PrevMainCtrlState_U16X;                       /*! SWITCH Y_Option_sma560_dbg_info=ON V_PrevMainCtrlState_U16X: previous main control state */
U32 V_TimeDiff_U32X;                                /*! SWITCH Y_Option_sma560_dbg_info=ON V_TimeDiff_U32X: Stores time difference between two clock count samples */
U32 V_CurrentTime_U32X;                             /*! SWITCH Y_Option_sma560_dbg_info=ON V_CurrentTime_U32X: Stores current time value before actual time delay calculation  */
U8  V_TimeDiffms_U8X;                               /*! SWITCH Y_Option_sma560_dbg_info=ON V_TimeDiffms_U8X: Stores time difference in ms for debugging */
S16 V_ClockCountDiff_S16R;                          /*! SWITCH Y_Option_sma560_dbg_info=ON V_ClockCountDiff_S16R: clock count difference */
S16 V_ClkCntTrgtValue_S16R;                         /*! SWITCH Y_Option_sma560_dbg_info=ON V_ClkCntTrgtValue_S16R: clock count target value */
S16 V_MinClkCntTrgtValue_S16R;                      /*! SWITCH Y_Option_sma560_dbg_info=ON V_MinClkCntTrgtValue_S16R: clock count target value min */
S16 V_MaxClkCntTrgtValue_S16R;                      /*! SWITCH Y_Option_sma560_dbg_info=ON V_MaxClkCntTrgtValue_S16R: clock count target value max */
U16 V_RawClockCount_U16R;                           /*! SWITCH Y_Option_sma560_dbg_info=ON V_RawClockCount_U16R: clock count raw value */

#endif
#ifdef Y_SMA560ErrorTestCases                       /* !!! only for error test case generation */
te_EEMgrOperStatus E_EEMSuccess1_SXX;
U8  V_EERead1_U8X;                                  /*! SWITCH Y_Option_sma560_error_ctrl=ON V_EERead1_U8X: EEPROM value during error condition */
U32 V_DbgFaultControl_U32X;                         /*! SWITCH Y_Option_sma560_error_ctrl=ON V_DbgFaultControl_U32X: Used to debug fault */
U32 V_RTCounter_U32X;                               /*! SWITCH Y_Option_sma560_error_ctrl=ON V_RTCounter_U32X: Real time counter during error condition */
#endif
} ts_SMA560Data;  /*! END DEF*/
/* EasyCASE > */
/* EasyCASE ) */
/* EasyCASE ( 71
   internal monitoring fault */
/* EasyCASE < */
/* Additional fault info regarding internal monitoring fault */
typedef enum                              /*! DEF ENUM te_SMA560IntrnlMoniFault */
{
/* 00, 0x00 */E_SMA560IntrnlMoniFlt000000,/*! E_SMA560IntrnlMoniFlt000000: not used */
/* 01, 0x01 */E_SMA560IntrnlMoniFlt000001,/*! E_SMA560IntrnlMoniFlt000001: B8 group1, OC1, OC2, OCC1, OCC2 */
/* 02, 0x02 */E_SMA560IntrnlMoniFlt000010,/*! E_SMA560IntrnlMoniFlt000010: B8 group2, CLK, LI */
/* 03, 0x03 */E_SMA560IntrnlMoniFlt000011,/*! E_SMA560IntrnlMoniFlt000011: B8 group1,2 */
/* 04, 0x04 */E_SMA560IntrnlMoniFlt000100,/*! E_SMA560IntrnlMoniFlt000100: B8 group3, EMprod */
/* 05, 0x55 */E_SMA560IntrnlMoniFlt000101,/*! E_SMA560IntrnlMoniFlt000101: B8 group1,3 */
/* 06, 0x06 */E_SMA560IntrnlMoniFlt000110,/*! E_SMA560IntrnlMoniFlt000110: B8 group2,3 */
/* 07, 0x07 */E_SMA560IntrnlMoniFlt000111,/*! E_SMA560IntrnlMoniFlt000111: B8 group1,2,3 */
/* 08, 0x08 */E_SMA560IntrnlMoniFlt001000,/*! E_SMA560IntrnlMoniFlt001000: B8 group4 SID NoOff12 NoTe112 NoEOP */
/* 09, 0x09 */E_SMA560IntrnlMoniFlt001001,/*! E_SMA560IntrnlMoniFlt001001: B8 group1,4 */
/* 10, 0x0a */E_SMA560IntrnlMoniFlt001010,/*! E_SMA560IntrnlMoniFlt001010: B8 group1,2 */
/* 11, 0x0b */E_SMA560IntrnlMoniFlt001011,/*! E_SMA560IntrnlMoniFlt001011: B8 group1,2,4 */
/* 12, 0x0c */E_SMA560IntrnlMoniFlt001100,/*! E_SMA560IntrnlMoniFlt001100: B8 group3,4 */
/* 13, 0x0d */E_SMA560IntrnlMoniFlt001101,/*! E_SMA560IntrnlMoniFlt001101: B8 group1,3,4 */
/* 14, 0x0e */E_SMA560IntrnlMoniFlt001110,/*! E_SMA560IntrnlMoniFlt001110: B8 group2,3,4 */
/* 15, 0x0f */E_SMA560IntrnlMoniFlt001111,/*! E_SMA560IntrnlMoniFlt001111: B8 group1,2,3,4 */
/* 16, 0x10 */E_SMA560IntrnlMoniFlt010000,/*! E_SMA560IntrnlMoniFlt010000: B8 group5 CRC, SPIEC */
/* 17, 0x11 */E_SMA560IntrnlMoniFlt010001,/*! E_SMA560IntrnlMoniFlt010001: B8 group1,5 */
/* 18, 0x12 */E_SMA560IntrnlMoniFlt010010,/*! E_SMA560IntrnlMoniFlt010010: B8 group2,5 */
/* 19, 0x13 */E_SMA560IntrnlMoniFlt010011,/*! E_SMA560IntrnlMoniFlt010011: B8 group1,2,5 */
/* 20, 0x14 */E_SMA560IntrnlMoniFlt010100,/*! E_SMA560IntrnlMoniFlt010100: B8 group3,5 */
/* 21, 0x15 */E_SMA560IntrnlMoniFlt010101,/*! E_SMA560IntrnlMoniFlt010101: B8 group1,3,5 */
/* 22, 0x16 */E_SMA560IntrnlMoniFlt010110,/*! E_SMA560IntrnlMoniFlt010110: B8 group2,4,5 */
/* 23, 0x17 */E_SMA560IntrnlMoniFlt010111,/*! E_SMA560IntrnlMoniFlt010111: B8 group1,2,3,5 */
/* 24, 0x18 */E_SMA560IntrnlMoniFlt011000,/*! E_SMA560IntrnlMoniFlt011000: B8 group4,5 */
/* 25, 0x19 */E_SMA560IntrnlMoniFlt011001,/*! E_SMA560IntrnlMoniFlt011001: B8 group1,4,5 */
/* 26, 0x1a */E_SMA560IntrnlMoniFlt011010,/*! E_SMA560IntrnlMoniFlt011010: B8 group2,4,5 */
/* 27, 0x1b */E_SMA560IntrnlMoniFlt011011,/*! E_SMA560IntrnlMoniFlt011011: B8 group1,2,4,5 */
/* 28, 0x1c */E_SMA560IntrnlMoniFlt011100,/*! E_SMA560IntrnlMoniFlt011100: B8 group3,4,5 */
/* 29, 0x1d */E_SMA560IntrnlMoniFlt011101,/*! E_SMA560IntrnlMoniFlt011101: B8 group1,3,4,5 */
/* 30, 0x1e */E_SMA560IntrnlMoniFlt011110,/*! E_SMA560IntrnlMoniFlt011110: B8 group2,3,4,5 */
/* 31, 0x1f */E_SMA560IntrnlMoniFlt011111,/*! E_SMA560IntrnlMoniFlt011111: B8 group1,2,3,4,5 */
/* 32, 0x20 */E_SMA560IntrnlMoniFlt100000,/*! E_SMA560IntrnlMoniFlt100000: not used */
/* 33, 0x21 */E_SMA560IntrnlMoniFlt100001,/*! E_SMA560IntrnlMoniFlt100001: B1 ASICD does not match */
/* 34, 0x22 */E_SMA560IntrnlMoniFlt100010,/*! E_SMA560IntrnlMoniFlt100010: B2 TFF wrong after SW reset */
/* 35, 0x23 */E_SMA560IntrnlMoniFlt100011,/*! E_SMA560IntrnlMoniFlt100011: B2 sensor data is 496LSB after SW reset */
/* 36, 0x24 */E_SMA560IntrnlMoniFlt100100,/*! E_SMA560IntrnlMoniFlt100100: B3 g range is not 96g after SW reset */
/* 37, 0x25 */E_SMA560IntrnlMoniFlt100101,/*! E_SMA560IntrnlMoniFlt100101: B4 FOC is not automatically switched off */
/* 38, 0x26 */E_SMA560IntrnlMoniFlt100110,/*! E_SMA560IntrnlMoniFlt100110: B5 FOC is not switched off (reinit. FOC) */
/* 39, 0x27 */E_SMA560IntrnlMoniFlt100111,/*! E_SMA560IntrnlMoniFlt100111: B6 wrong clock count, init. phase */
/* 40, 0x28 */E_SMA560IntrnlMoniFlt101000,/*! E_SMA560IntrnlMoniFlt101000: B7 monitor data1 or data2 bit set */
/* 41, 0x29 */E_SMA560IntrnlMoniFlt101001,/*! E_SMA560IntrnlMoniFlt101001: B7 NRO is not 0 directly after EOP */
/* 42, 0x2a */E_SMA560IntrnlMoniFlt101010,/*! E_SMA560IntrnlMoniFlt101010: B7 monitor data1,2 NRO unequal 0 after EOP */
/* 43, 0x2b */E_SMA560IntrnlMoniFlt101011,/*! E_SMA560IntrnlMoniFlt101011: B9 clock count out of range, steady state */
/* 44, 0x2c */E_SMA560IntrnlMoniFlt101100,/*! E_SMA560IntrnlMoniFlt101100: B10 g-range selection invalid */
/* 45, 0x2d */E_SMA560IntrnlMoniFlt101101,/*! E_SMA560IntrnlMoniFlt101101: not used */
/* 46, 0x2e */E_SMA560IntrnlMoniFlt101110,/*! E_SMA560IntrnlMoniFlt101110: not used */
/* 47, 0x2f */E_SMA560IntrnlMoniFlt101111,/*! E_SMA560IntrnlMoniFlt101111: not used */
/* 48, 0x30 */E_SMA560IntrnlMoniFlt110000,/*! E_SMA560IntrnlMoniFlt110000: not used */
/* 49, 0x31 */E_SMA560IntrnlMoniFlt110001,/*! E_SMA560IntrnlMoniFlt110001: not used */
/* 50, 0x32 */E_SMA560IntrnlMoniFlt110010,/*! E_SMA560IntrnlMoniFlt110010: not used */
/* 51, 0x33 */E_SMA560IntrnlMoniFlt110011,/*! E_SMA560IntrnlMoniFlt110011: not used */
/* 52, 0x34 */E_SMA560IntrnlMoniFlt110100,/*! E_SMA560IntrnlMoniFlt110100: not used */
/* 53, 0x35 */E_SMA560IntrnlMoniFlt110101,/*! E_SMA560IntrnlMoniFlt110101: not used */
/* 54, 0x36 */E_SMA560IntrnlMoniFlt110110,/*! E_SMA560IntrnlMoniFlt110110: not used */
/* 55, 0x37 */E_SMA560IntrnlMoniFlt110111,/*! E_SMA560IntrnlMoniFlt110111: not used */
/* 56, 0x38 */E_SMA560IntrnlMoniFlt111000,/*! E_SMA560IntrnlMoniFlt111000: not used */
/* 57, 0x39 */E_SMA560IntrnlMoniFlt111001,/*! E_SMA560IntrnlMoniFlt111001: not used */
/* 58, 0x3a */E_SMA560IntrnlMoniFlt111010,/*! E_SMA560IntrnlMoniFlt111010: not used */
/* 59, 0x3b */E_SMA560IntrnlMoniFlt111011,/*! E_SMA560IntrnlMoniFlt111011: not used */
/* 60, 0x3c */E_SMA560IntrnlMoniFlt111100,/*! E_SMA560IntrnlMoniFlt111100: not used */
/* 61, 0x3d */E_SMA560IntrnlMoniFlt111101,/*! E_SMA560IntrnlMoniFlt111101: not used */
/* 62, 0x3e */E_SMA560IntrnlMoniFlt111110,/*! E_SMA560IntrnlMoniFlt111110: not used */
/* 63, 0x3f */E_SMA560IntrnlMoniFlt111111 /*! E_SMA560IntrnlMoniFlt111111: not used */
} te_SMA560IntrnlMoniFault;   /*! END DEF */
/* EasyCASE > */
/* EasyCASE ) */
/*#end ACD#*/
/* EasyCASE ) */
/* EasyCASE (
   Public API Declarations */
/* EasyCASE ) */
/* EasyCASE (
   Package protected API Declarations */
#ifdef Y_INC_FROM_PKG_SEM_SensorMgt
/* EasyCASE (
   S56_Init */
/******************************************************************************
 * Description:
 *      this API initializes the handling for one SMA560. This includes:
 *      - checking if the sensor type is correct, that means if this module
 *        really accesses a SMA560
 *      - extracting configuration data and adding it to the management tables
 *        in
 *        centralsensors module
 *      - setting the initial sensor/channel states
 *      - initiating the realtime reading by the sensor-manager
 * 
 * Arguments:
 *    - v_asic_u8r: the asic-number of this sensor as specified in PDM
 *    - v_channelNo_u8r: the number of the first channel of this sensor, this
 *      index is e.g. used in the protected data interface.
 *    - e_configured_xxr: is the sensor configured in PDM or not
 * 
 * Return:
 *    the number of channels this sensor has, for a SMA560 this is two.
 * 
 * Scheduling:
 *    called once in 10ms background after cfg-data is available.
 * 
 * Usage guide: -
 * 
 * Remarks:
 * The below Permanent Faults are checked for stored state using Central sensor
 * API's
 *   - FltCs[ASIC]Programming
 *   - FltCs[ASIC]InternalMonitoring
 *   - Flt[CsChannel]OffsetCancellation
 *   - Flt[CsChannel]BITE
 *   - Flt[CsChannel]Plausibility.
 * If the sensor is not configured (e_configured_xxr = false) then this API
 * clears all non-permanent faults related to this sensor. The permanent faults
 * are not cleared.
 ******************************************************************************/
U8 S56_Init(U8 v_asic_u8r, U8 v_channelNo_u8r, te_Boolean e_configured_xxr );
/* EasyCASE ) */
/* EasyCASE (
   S56_BackgroundMonitoring10ms */
/******************************************************************************
 * Description:
 *    Controls the background monitoring for this sensor, depending on sensor
 *    state that is initialization or continuous cyclic monitoring.
 * 
 * Arguments:
 *    - v_asic_u8r: the sensor for which the monitoring has to be done
 * 
 * Return: -
 * 
 * Scheduling:
 *    10ms
 * 
 * Usage guide:
 *    Called by centralsensors-module once for each SMA560 in each 10ms
 *    background cycle.
 * 
 * Remarks: -
 ******************************************************************************/
void S56_BackgroundMonitoring10ms(U8 v_asic_u8r );
/* EasyCASE ) */
/* EasyCASE (
   S56_EvaluateSensorDataFIQ */
/******************************************************************************
 * Description:
 *    This function does the realtime data evaluation specific for the SMA560.
 *    The function additionally checks the valid sensor data range -480LSB <=
 *    sensor value <= 480LSB.
 *    Reason: in comparison to other central sensors the design is realized to
 *    deliver +496LSB value.
 *            The check was introduced to verify if something goes wrong in
 *            regard to the value range.
 *    Apart from that the function is identical to CS_EvaluateSensorDataFIQ().
 * 
 * 
 * 
 * Arguments:
 *    - v_rawData_u16r : the raw sensor data received from the sensor
 *    - v_sensor_u8r   : the index for the sensors internal data table
 *    - v_channel_u8r  : the index for the sensors channel data interface
 * 
 * Return: -
 * 
 * Scheduling:
 *    realtime (FIQ)
 * 
 * Usage guide:
 *    This function is called via function pointer by the sensor-manager.
 *    Therefore a pointer to this function and
 *    its parameters are stored inside the sensormanager during initialization
 *    (see SMR_AddSensorChannel).
 * 
 * Remarks:
 *    Obviously this function is runtime critical.
 * 
 *    It performs a check of the sensor data based on two criteria:
 *    - are the SPI-Checkbits as expected?
 *    - are the SPI-Checkbits (NRO etc.) as expected?
 *    - This test uses two variables (S_CsIntData_XXR.A_ChannelRTExpSpiBits_U8X
 *      and S_CsIntData_XXR.A_ChannelRTCheckedSpiBits_U8X).
 *    - The first variable determines which bits of the read sensor-data are
 *      compared to the expected value specified by the second variable.
 *      If the sensor-data is OK AND the sensor is in steady-state, the
 *      sensor-data is written into the data interface (S_CsSensorDataINTW_XXR).
 *      Beside this the data-valid flag is set for this channel.
 *      Otherwise 0 is written to the sensor data and the data-valid flag is
 *      cleared.
 ******************************************************************************/
void S56_EvaluateSensorDataFIQ(U16 v_rawData_u16r, U8 v_sensor_u8r, U8 v_channel_u8r );
/* EasyCASE ) */
#endif
/* EasyCASE ) */
#endif
/* EasyCASE ) */
