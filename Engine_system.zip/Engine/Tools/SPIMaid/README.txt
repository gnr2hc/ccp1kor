
Files has been moved out of Engine into new component under Platform

Component name : rbh.test_dev_turbolift.SPI_decoder_files

Component structure :
rbh.xxxxxxxxx.Platform
  - rbh.test_dev_turbolift.CommonData
       -rbh.test_dev_turbolift.SPI_decoder_files    <<<<----------


Target Stream for updates : TurboLIFT_Testarea_development_RT4
Owner : Test Automation Team 

