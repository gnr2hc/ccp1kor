use strict;
use warnings;
use Cwd;
use File::Find;
use Tk::ProgressBar;

#use Obsolete_modules;
#use Getopt::Long;
use Tk;
my $NUMBER_OF_FILES;
my $progress;


#
# OBSOLETE MODULES AND FUNCTIONS MAPPING STARTS HERE
#


# Add here Obsolete module name (OBSOLETE MODULES LIST)
my $obsolete_modules_href = { LIFT_CANoe => 'Module: LIFT_can_access', LIFT_POWER => 'Module: LIFT_labcar', };

# Add here obsolete functions list and proposed new functions if present (OBSOLETE FUNCTIONS AND THERE MAPPING)
my $obsolete_functions_href = {

    #LIFT_POWER    #LIFT_labcar
    POW_init    => 'Module: LIFT_labcar, function: LC_init',
    POW_exit    => 'Module: LIFT_labcar, function: LC_exit',
    POW_on      => 'Module: LIFT_labcar, function: LC_ECU_On',
    POW_off     => 'Module: LIFT_labcar, function: LC_ECU_Off',
    POW_voltage => 'Module: LIFT_labcar, function: LC_SetVoltage',

    #Functions LIFT_CANoe              #Functions LIFT_can_access
    CAN_init                      => 'called automatically inside EQUIP_init_testbench , no direct called required , however if needed use Module: LIFT_NET_access, function: NET_Init  or Module: Module: LIFT_can_access, function: CA_init',
    CAN_start_measurement         => 'Module: LIFT_NET_access, function: NET_trace_start  or Module: Module: LIFT_can_access, function: CA_trace_start',
    CAN_stop_measurement          => 'Module: LIFT_NET_access, function: NET_trace_stop  or Module: Module: LIFT_can_access, function: CA_trace_stop',
    CAN_trace_store               => 'Module: LIFT_NET_access, function: NET_trace_store  or Module: Module: LIFT_can_access, function: CA_trace_store',
    CAN_close_application         => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_trace_can_get_dataref     => 'Module: LIFT_NET_access, function: NET_trace_get_dataref  or Module: Module: LIFT_can_access, function: CA_trace_get_dataref',
    CAN_get_env_variable          => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_get_EnvVar_value          => 'Module: LIFT_NET_access, function: NET_get_envVar_value  or Module: Module: LIFT_can_access, function: CA_get_EnvVar_value',
    CAN_set_EnvVar_value          => 'Module: LIFT_NET_access, function: NET_set_envVar_value  or Module: Module: LIFT_can_access, function: CA_set_EnvVar_value',
    CAN_get_signal_variable       => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_get_Signal_value          => 'Module: LIFT_NET_access, function: NET_read_signal  or Module: Module: LIFT_can_access, function: CA_read_can_signal',
    CAN_set_Signal_value          => 'Module: LIFT_NET_access, function: NET_write_signal  or Module: Module: LIFT_can_access, function: CA_write_can_signal',
    CAN_open_configuration        => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_start_application         => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_trace_get_data_can_signal => 'called internally in LIFT_NET_access and LIFT_can_access, no direct call required',
    CAN_logging_start             => 'Module: LIFT_NET_access, use functions: NET_simulation_start ->  NET_trace_start  or Module: Module: LIFT_can_access, function: CA_simulation_start -> CA_trace_start',
    CAN_logging_stop              => 'Module: LIFT_NET_access, use functions: NET_simulation_start ->  NET_trace_start -> NET_trace_stop or Module: Module: LIFT_can_access, function: CA_simulation_start -> CA_trace_start -> CA_trace_stop',
    CAN_log_store                 => 'Module: LIFT_NET_access, function: NET_trace_store  or Module: Module: LIFT_can_access, function: CA_trace_store',

};


#
# OBSOLETE MODULES AND FUNCTIONS MAPPING ENDS HERE
#



#
#ALTERNATE MODULES AND FUNCTIONS STARTS HERE
#


#Add here New Alternate modules to be used. (NOT OBSOLETE MODULES LIST)
my $alternate_modules_href = { FuncLib_TNT_GEN => 'Module: LIFT_general or LIFT_ProdDiag based on function to be used', LIFT_PD => 'Module: LIFT_ProdDiag or LIFT_FaultMemory' };



#Add here New alternate functions to be used instead of old functions(NOT OBSOLETE FUNCTIONS)
my $alternateFuncToBeUsed_href = {

    #FuncLib_TNT_GEN
    #    GEN_print_caller                      => 'TBD',
    GEN_printTestStep => 'Module: LIFT_general: Function: S_teststep',
    GEN_printComment  => 'Module: LIFT_general: Function: S_w2log',

    #    GEN_byteString2hexaref                => 'TBD',
    #    GEN_hexaref2byteString                => 'TBD',
    GEN_Read_mandatory_testcase_parameter => 'Module: LIFT_general: Function: S_read_mandatory_testcase_parameter',
    GEN_Read_optional_testcase_parameter  => 'Module: LIFT_general: Function: S_read_optional_testcase_parameter',

    #    GEN_Power_on_Reset                    => 'TBD',
    #    GEN_StandardPrepNoFault               => 'TBD',
    GEN_Finalization          => 'Dummy function no point in using this function',
    GEN_EVAL_CompareStrArrays => 'Module: LIFT_general: Function: S_compare_str_arrays',
    GEN_EVAL_CompareNumArrays => 'Module: LIFT_general: Function: S_compare_num_arrays',

    #    GEN_get_trace_eval_params             => 'TBD',
    #    GEN_EVAL_trace_sequence               => 'TBD',
    #    GEN_EVAL_trace_times                  => 'TBD',
    #    GEN_EVAL_trace_signals                => 'TBD',
    #    GEN_setECUMode                        => 'TBD',
    GEN_readWLStatus => 'Module: LIFT_ProdDiag: Function: PRD_Get_ECU_Properties',

    #    GEN_readPowerONCounter                => 'TBD',
    #    GEN_generateUniqueTraceName           => 'TBD',
    #    GEN_printLink                         => 'TBD',
    #    GEN_printTableToReport                => 'TBD',
    #    GEN_generateValuesForTesting          => 'TBD',
    #    GEN_filterChildarrayFromParentarray   => 'TBD',
    GEN_AutoECUFlash => 'Module: LIFT_ECU_SW_Flash: Function: ECU_SW_AutoFlash',
    
    
    
    
    #LIFT_PD	#LIFT_ProdDiag + LIFT_FaultMemory
    PD_InitDiagnosis               => 'Module: LIFT_ProdDiag, function: PRD_init',
    PD_InitCommunication           => 'Module: LIFT_ProdDiag, function: PRD_init',
    PD_ECUlogin                    => 'Module: LIFT_ProdDiag, function: PRD_ECU_Login',
    PD_CloseDiagnosis              => 'Module: LIFT_ProdDiag, function: PRD_exit',
    PD_ReadFaultMemory             => 'Module: LIFT_ProdDiag, function: PRD_Read_Fault_Memory or Module: LIFT_FaultMemory, function: LIFT_FaultMemory -> read_fault_memory',
    PD_DumpFaultMemoryTable        => 'Module: LIFT_ProdDiag, function: PRD_Read_Fault_Memory or Module: LIFT_FaultMemory, function: ???',
    PD_ClearFaultMemory            => 'Module: LIFT_ProdDiag, function: PRD_Clear_Fault_Memory or Module: LIFT_FaultMemory, function: FaultObj -> clear_in_ECU',
    PD_GetExtendedFaultInformation => 'Module: LIFT_FaultMemory, function: LIFT_FaultMemory -> read_fault_memory',
    PD_check_fault_status          => 'Module: LIFT_FaultMemory, function: FaultObj -> evaluate_faults',
    PD_GetFaultAttribute           => 'Module: LIFT_FaultMemory, function: FaultObj -> get_fault_attribute',
    PD_get_fault_info              => 'Module: LIFT_FaultMemory, function: FaultObj -> get_fault_attribute',
    PD_get_fault_status            => 'Module: LIFT_FaultMemory, function: FaultObj -> get_fault_attribute',
    PD_GetFaultID                  => 'Module: LIFT_ProdDiag, function: PRD_Get_Symbol_Mapping',
    PD_count_fault                 => 'Module: LIFT_FaultMemory, function: FaultObj -> get_number_of_faults',
    PD_evaluate_faults             => 'Module: LIFT_FaultMemory, function: FaultObj -> evaluate_faults',

    #PD_get_faults                  => 'Module: LIFT_ProdDiag, function: - (neither used in CRAFT or CREIS)',
    PD_FreezeFaultMemory     => 'Module: LIFT_ProdDiag, function: PRD_Freeze_Fault_Memory',
    PD_ManipulateFaultMemory => 'Module: LIFT_ProdDiag, function: PRD_Manipulate_Fault_Memory or Module: LIFT_FaultMemory, function: FaultObj -> manipulate_in_ECU',
    PD_WriteMemoryByName     => 'Module: LIFT_ProdDiag, function: PRD_Write_Memory',
    PD_WriteMemoryByAddress  => 'Module: LIFT_ProdDiag, function: PRD_Write_Memory',

    #PD_SetMemoryBits               => 'Module: LIFT_ProdDiag, function:  - not used in test cases',
    #PD_ClearMemoryBits             => 'Module: LIFT_ProdDiag, function:  - not used in test cases',
    PD_ReadMemoryByName    => 'Module: LIFT_ProdDiag, function: PRD_Read_Memory',
    PD_ReadMemoryByAddress => 'Module: LIFT_ProdDiag, function: PRD_Read_Memory',
    PD_GetAddressByName    => 'Module: LIFT_ProdDiag, function: PRD_Get_Symbol_Mapping',
    PD_get_type_from_name  => 'Module: LIFT_ProdDiag, function: PRD_Read_Memory',

    #PD_ReadMemoryBit               => 'Module: LIFT_ProdDiag, function: - not used in test cases',
    PD_ReadCrashRecorder          => 'Module: LIFT_ProdDiag, function: PRD_Read_EDR',
    PD_ClearCrashRecorder         => 'Module: LIFT_ProdDiag, function: PRD_Clear_EDR',
    PD_GetECUStatus               => 'Module: LIFT_ProdDiag, function: PRD_Get_ECU_Properties',
    PD_GetABGeneration            => 'Module: LIFT_ProdDiag, function: PRD_Get_ECU_Properties',
    PD_ReadLampStates             => 'Module: LIFT_ProdDiag, function: PRD_Get_ECU_Properties',
    PD_GetECUMode                 => 'Module: LIFT_ProdDiag, function: PRD_Get_ECU_Properties',
    PD_StartFastDiagName          => 'Module: LIFT_ProdDiag, function: PRD_Start_Fast_Diagnosis',
    PD_StartFastDiagAddress       => 'Module: LIFT_ProdDiag, function: PRD_Start_Fast_Diagnosis',
    PD_StopFastDiag               => 'Module: LIFT_ProdDiag, function: PRD_Stop_Fast_Diagnosis',
    PD_get_FDtrace                => 'Module: LIFT_ProdDiag, function: PRD_Get_Fast_Diagnosis_Data',
    PD_plot_FDtrace               => 'Module: LIFT_evaluation, function: use EVAL_createGraphFromMeasurement',
    PD_Device_configuration       => 'Module: LIFT_ProdDiag, function: PRD_Set_Device_Configuration',
    PD_DumpDeviceConfiguration    => 'Module: LIFT_ProdDiag, function: PRD_Get_Device_Configuration',
    PD_get_device_config          => 'Module: LIFT_ProdDiag, function: PRD_Get_Device_Configuration',
    PD_get_device_index           => 'Module: LIFT_ProdDiag, function: PRD_Get_Device_Configuration',
    PD_WriteNVMSection            => 'Module: LIFT_ProdDiag, function: PRD_Write_NVM',
    PD_WriteAllNVMSections        => 'Module: LIFT_ProdDiag, function: PRD_Write_NVM',
    PD_ReadNVMSection             => 'Module: LIFT_ProdDiag, function: PRD_Read_NVM',
    PD_DumpEEPROM                 => 'Module: LIFT_ProdDiag, function: PRD_Dump_Memory_To_File',
    PD_DumpRAM                    => 'Module: LIFT_ProdDiag, function: PRD_Dump_Memory_To_File',
    PD_DumpFLASH                  => 'Module: LIFT_ProdDiag, function: PRD_Dump_Memory_To_File',
    PD_DumpNVMData                => 'Module: LIFT_ProdDiag, function: PRD_Dump_Memory_To_File',
    PD_DumpCrashRecorder          => 'Module: LIFT_ProdDiag, function: PRD_Read_EDR',
    PD_ECUreset                   => 'Module: LIFT_ProdDiag, function: PRD_ECU_Reset',
    PD_Prepare_electronic_firing  => 'Module: LIFT_ProdDiag, function: PRD_Electronic_Firing_Enable',
    PD_Trigger_electronic_firing  => 'Module: LIFT_ProdDiag, function: PRD_Electronic_Firing_Fire',
    PD_SMI7xy_verification        => 'Module: LIFT_ProdDiag, function: PRD_Sensor_Verification',
    pd_GetSADItemDesc             => 'Module: LIFT_ProdDiag, function: PRD_Get_Symbol_Mapping',
    pd_ReadName                   => 'Module: LIFT_ProdDiag, function: PRD_Read_Memory',
    PD_send_request_wait_response => 'Module: LIFT_ProdDiag, function: PRD_Send_Request_Wait_Response',
    
};


#
#ALTERNATE MODULES AND FUNCTIONS STARTS HERE
#





my $MAPP_FILE_VERSION = "LIFT obsolete module list generator VER: 1.0";

my ( $obsoleteSearchString, $alternateSearchString, @FilesList, @obsoleteFuncOrModUsed, @alternateFuncOrModUsed, $obsolete_modules_aref, $alternate_modules_aref );
my ( $main, $Frame1, $Frame2, $Frame1_1, $start_button, $button, $inp_Folder_entry, $opt_output_file );
my $output_file = 'Obsolete_modules_list.txt';
GUI();
MainLoop;

sub GUI {

##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( "-background" => "#00BFFF" );

    # define minimum size of main window 'main'
    $main->minsize( 800, 100 );

    # create title in main window 'main'
    $main->title($MAPP_FILE_VERSION);

##------------------------------------------------------------------
## create frame 'F1' in main window 'main'
##------------------------------------------------------------------
    $Frame1 = $main->Frame( "-background" => "#a3e4d7" )->pack(
        "-side"   => 'top',
        "-expand" => 1,
        "-fill"   => 'both',
    );

##------------------------------------------------------------------
## create frame 'F2' in main window 'main'
##------------------------------------------------------------------
    $Frame2 = $main->Frame( "-background" => "#a3e4d7" )->pack(
        "-side" => 'bottom',
        "-fill" => 'x',
    );

##------------------------------------------------------------------
## write head line in frame 'F1'
##------------------------------------------------------------------
    $Frame1->Label(
        "-text"     => 'LIFT Obsolete module list Generator : Configuration Window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#17202a",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( "-side" => "top" );

    #Frame for keeping .csv file generated from Fibex/Autosar explorer and frame based
    my $frame1_csv = $Frame1->Frame( "-background" => "#7d3c98", -relief => 'solid', -borderwidth => 1, )->pack(
        "-side"   => 'top',
        "-expand" => 0,
        "-fill"   => 'both',
        "-pady"   => 5,
        "-padx"   => 5,
    );

##------------------------------------------------------------------
## Choose input directory for searching obsolete modules and functions
##------------------------------------------------------------------
    $Frame1_1 = $frame1_csv->Frame( "-background" => "#7d3c98" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "Enter the Folder path to search for obsolete modules and functions ", -background => "#7d3c98", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$inp_Folder_entry, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#17202a",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            my $temp = $inp_Folder_entry;    # store old value
            $inp_Folder_entry = $main->chooseDirectory(
                -initialdir => '~',
                -title      => 'Choose a directory'
            );
            if ( !defined $inp_Folder_entry ) {
                warn 'No directory selected';
            }
            unless ($inp_Folder_entry) { print "Mandatory input missing: Folder path is a must!" }    # if no new value, restore old one
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

##------------------------------------------------------------------
## create Frame for choosing output mapping file(.pm) for flexray with label, entry and button
##------------------------------------------------------------------
    $Frame1_1 = $frame1_csv->Frame( "-background" => "#7d3c98" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "output file(*.txt) for Obsolete list ", -background => "#7d3c98", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95' )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$opt_output_file, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $button = $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#17202a",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            $opt_output_file = $main->getSaveFile(
                "-filetypes" => [ [ "Perl modules", '.txt' ], [ "All files", '.*' ] ],
                "-title" => "Obsolete modules and functions Output Files",
                "-initialdir"  => '.',
                "-initialfile" => $output_file,
            );

            $opt_output_file = $opt_output_file . ".txt" if ( $opt_output_file && $opt_output_file !~ /^.+\.txt$/ );
            unless ($opt_output_file) {
                $main->messageBox(
                    '-icon'    => "error",
                    '-type'    => "OK",
                    '-title'   => 'Error',
                    '-message' => "The .txt file entered is invalid ",
                );

            }
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

##------------------------------------------------------------------
## create exit and start buttons in frame 'F2'
##------------------------------------------------------------------
    $Frame2->Button(
        "-text"     => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        "-command"  => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        "-side"  => 'left',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );

    $start_button = $Frame2->Button(
        "-text"     => "Create",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        "-command"  => sub {
            if ( -d $inp_Folder_entry and $opt_output_file ) {

                $opt_output_file = $opt_output_file . ".txt" if ( $opt_output_file && $opt_output_file !~ /^.+\.txt$/ );

                #execute LPCM_engine
                $obsoleteSearchString = PrepareObsoleteModuleAndFunctionList( 'obsolete', $obsolete_functions_href );
                return unless ($obsoleteSearchString);
                $alternateSearchString = PrepareObsoleteModuleAndFunctionList( 'alternate', $alternateFuncToBeUsed_href );

                my $funcOrModule_aref = GetListOfAbsFuncAndModules();
                unless ($funcOrModule_aref) {
                    print "Could not fetch obsolete modules and functions!";
                    exit;
                }

                my $fh;
                unless ( open( $fh, '>', $opt_output_file ) ) {
                    print "Could not open $opt_output_file : $!";
                    exit;
                }
                print $fh "\n!!!!!!!!!START of List of obsolete functions!!!!!!!!!\n";
                print $fh @$funcOrModule_aref;
                print $fh "\n\nEND of List of obsolete functions!!!!\n\n";
                print $fh "\n\n!!!!HIGHLY RECOMMENDED!!!!\n\n";
                print $fh "\nFollowing are the Alternate functions to be used instead of OLD TNT library functions!!!!!!!!!!!!!!!!\n\n";
                print $fh @alternateFuncOrModUsed;
                close $fh;
                print "ObsoleteModuleList Generated\n";
                print " Finished -> Press QUIT \n";
            }
            else {
                ##------------------------------------------------------------------
                ## inform user that options are missing
                ##------------------------------------------------------------------
                $main->messageBox(
                    '-icon'    => "error",
                    '-type'    => "OK",
                    '-title'   => 'Error',
                    '-message' => "! not enough options defined ! Input folder to search obsolete modules and functions and Output File are needed ",
                );
            }
        }
      )->pack(
        "-side"  => 'right',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );

    return 1;
}

sub GetListOfAbsFuncAndModules {

    find( \&Recurse_PM_Files, $inp_Folder_entry );

    $NUMBER_OF_FILES = scalar @FilesList;
    my $counter = $NUMBER_OF_FILES;

    unless ( defined $progress ) {
        $progress = $Frame2->ProgressBar(
            -width  => 40,
            -length => 200,
            -anchor => 'w',
            -state  => 'normal',
            -value  => 0,
            -from   => 0,
            -to     => $NUMBER_OF_FILES,
            -blocks => 10,
            -colors => [ 0, 'blue' ]
          )->pack(
            "-side"  => 'right',
            "-pady"  => 20,
            "-padx"  => 20,
            "-ipady" => 5,
            "-ipadx" => 5,
          );
    }
    $start_button->configure( -state => "normal" );
    foreach my $file (@FilesList) {
        my $fileContent_aref = ReadFile($file);
        return unless ($fileContent_aref);

        #find usage of obsolete functions/modules in
        FetchObsoleteFuncOrModuleInFile( $file, $fileContent_aref );
        $counter--;
        $progress->value($counter);
        $progress->update();
        
    }
    $progress = undef;

    return \@obsoleteFuncOrModUsed;
}

sub Recurse_PM_Files {
    if ( $File::Find::name =~ /.*\.pm/ ) {
        push @FilesList, $File::Find::name;
    }
    return;
}

sub FetchObsoleteFuncOrModuleInFile {
    my $file        = shift;
    my $lines_aref  = shift;
    my $linecounter = 1;
    $obsoleteSearchString =~ s/\n//;
    $alternateSearchString =~ s/\n//;
    my $proposedModuleOrFun;
    my $alternateFun;
    my $filecounter     = 0;
    my $altfilecounter  = 0;
    my $extractfileName = $file;
    $extractfileName =~ s/.*\/(.*).pm/$1/;
    foreach my $line (@$lines_aref) {
        if ( $line !~ /^(\s+|\t+)?#/ and $line =~ /$obsoleteSearchString/ ) {
            my $matched_str = $&;
            if ( !exists $obsolete_modules_href->{$extractfileName} ) {
                Fill_Obsolete_alternate_list( 'obsolete', $file, $line, $matched_str, \$filecounter, \$linecounter );
            }
        }
        elsif ( $line !~ /^(\s+|\t+)?#/ and $line =~ /$alternateSearchString/ ) {
            my $matched_str = $&;
            if ( !exists $alternate_modules_href->{$extractfileName} ) {
                Fill_Obsolete_alternate_list( 'alternate', $file, $line, $matched_str, \$altfilecounter, \$linecounter );
            }

        }
        $linecounter++;
    }

    return 1;

}

sub Fill_Obsolete_alternate_list {

    my ( $type, $file, $line, $matched_str, $filecounter, $linecounter ) = ( shift, shift, shift, shift, shift, shift );
    my $proposedModuleOrFun;
    my $comment_design = '=' x 200;
    if ( $matched_str =~ /use\s+/ ) {
        $matched_str =~ s/\s|\(|use|;//g;
        $proposedModuleOrFun = $obsolete_modules_href->{$matched_str}  if ( $type eq 'obsolete' );
        $proposedModuleOrFun = $alternate_modules_href->{$matched_str} if ( $type eq 'alternate' );
        $proposedModuleOrFun = 'To be used instead: ' . $proposedModuleOrFun . "\n";
        if ( $$filecounter == 0 ) {
            push( @obsoleteFuncOrModUsed,  "\n$comment_design\nFileName: $file:\n $comment_design\n" ) if ( $type eq 'obsolete' );
            push( @alternateFuncOrModUsed, "\n$comment_design\nFileName: $file:\n $comment_design\n" ) if ( $type eq 'alternate' );
            $$filecounter++;
        }

        push( @obsoleteFuncOrModUsed,  'Line Number : ' . $$linecounter . ":" . $line . $proposedModuleOrFun . "\n" ) if ( $type eq 'obsolete' );
        push( @alternateFuncOrModUsed, 'Line Number : ' . $$linecounter . ":" . $line . $proposedModuleOrFun . "\n" ) if ( $type eq 'alternate' );
    }

    else {
        $matched_str =~ s/\s|\(//g;
        $proposedModuleOrFun = $obsolete_functions_href->{$matched_str}    if ( $type eq 'obsolete' );
        $proposedModuleOrFun = $alternateFuncToBeUsed_href->{$matched_str} if ( $type eq 'alternate' );
        $proposedModuleOrFun = 'To be used instead: ' . $proposedModuleOrFun;
        if ( $$filecounter == 0 ) {
            push( @obsoleteFuncOrModUsed,  "\n$comment_design\nFileName: $file:\n $comment_design\n" ) if ( $type eq 'obsolete' );
            push( @alternateFuncOrModUsed, "\n$comment_design\nFileName: $file:\n $comment_design\n" ) if ( $type eq 'alternate' );
            $$filecounter++;
        }

        push( @obsoleteFuncOrModUsed,  'Line Number : ' . $$linecounter . ":" . $line . $proposedModuleOrFun . "\n\n" ) if ( $type eq 'obsolete' );
        push( @alternateFuncOrModUsed, 'Line Number : ' . $$linecounter . ":" . $line . $proposedModuleOrFun . "\n\n" ) if ( $type eq 'alternate' );
    }
}

sub ReadFile {
    my $file = shift;
    my $fh;
    unless ( open( $fh, '<', $file ) ) {
        print "Couldnot open File: $file : $!";
    }
    my @lines = readline $fh;
    close $fh;
    return \@lines;
}

sub PrepareObsoleteModuleAndFunctionList {

    my $listingtype     = shift;
    my $functions_href  = shift;
    my @FuncsCollection = ( keys %{$functions_href} );
    my $SearchString    = join( '\s*\(|\b', @FuncsCollection );
    $SearchString = $SearchString . '\s*\(';
    unless ( keys %$obsolete_modules_href ) {
        print "Could not fetch obsolete module details!";
        return;
    }
    if ( $listingtype eq 'obsolete' ) {
        foreach my $module ( keys %$obsolete_modules_href ) {
            push( @$obsolete_modules_aref, '\s*use\s*' . $module . '\s*;|' );
        }
        $SearchString = join( '', @$obsolete_modules_aref ) . $SearchString;
    }
    if ( $listingtype eq 'alternate' ) {
        foreach my $module ( keys %$alternate_modules_href ) {
            push( @$alternate_modules_aref, '\s*use\s*' . $module . '\s*;|' );
        }
        $SearchString = join( '', @$alternate_modules_aref ) . $SearchString;
    }

    return $SearchString;
}

sub Check_state {
    if ( defined $inp_Folder_entry && $inp_Folder_entry ne '' ) {
        $button->configure( -state => 'normal' );

    }
    else {
        $button->configure( -state => 'disabled' );
    }
}
