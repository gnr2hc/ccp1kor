#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use Getopt::Long;

my $Toolversion = "results2DOORS ($VERSION)";      # Tool version number

# start section configured by file
our $XML_in; 
# end section configured by file
#my $start_dir = 'C:\MKS\MLC';
my ($main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);
my ($FileFrame_1_1, $SelectFrame2, $MapFrame, $Generic);
my (@result_CSV_file, $result_CSV, %result, $txt_file, $SWversion, $scan_type, $MapFile);
my (@scanned_ids, %maphash);
my $GenID="";
my $treat_inconc_as_fail=0;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 500, 400 );

# create title in window 'main'
$main -> title ( "get results from LIFT result file and map to SRTP IDs $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create DOORS import file from LIFT result file",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );
$FileFrame_1_1 = $main -> Frame() -> pack( "-pady" => 5 );
$SelectFrame2 = $main -> Frame() -> pack( "-pady" => 10 );
$MapFrame = $main -> Frame() -> pack( "-pady" => 10 );
$Generic = $main -> Frame() -> pack( "-pady" => 5 );
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in 'FileFrame_1_1'
$FileFrame_1_1 -> Label( "-text" => "result file: ", )
            -> pack( "-side" => 'left', );

# create entry in 'FileFrame_1_1'
$FileFrame_1_1 -> Entry(
            "-width" => 50,
            "-textvariable" => \$XML_in, #reference 
            )-> pack( "-side" => 'left', );

# create 'browse file' button in 'FileFrame_1_1'
$FileFrame_1_1 -> Button
  (
  "-text" => "Browse file",
  "-command" => sub
    {
      # browse for file
      $XML_in = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["LIFT files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "choose report file",
        );
      # if a file was chosen
      if ( $XML_in )
        {
        #extract directory
        print "\n $XML_in was chosen\n";
        }
      else
        {
          print "no filename!\n";
          # prompt user
          $main->messageBox(
              '-icon'    => "error", #qw/error info question warning/
              '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
              '-title'   => 'Attention',
              '-message' => "!Please select file first!"
          );


       }
    },
  )
    -> pack ("-side" => 'left',"-padx" => 5,);


# create label in 'SelectFrame'

$SelectFrame2->Checkbutton(
            "-variable" => \$treat_inconc_as_fail,
            "-text" => "INCONC=fail",)
            -> pack( "-side" => 'left', );
            

# create label in 'MapFrame'
$MapFrame -> Label( "-text" => "Mapping File: ", )
            -> pack( "-side" => 'left', );

# create entry in 'MapFrame'
$MapFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$MapFile, #reference 
            )-> pack( "-side" => 'left', );
 
#This is to create a browse button to select the already created Map file 
$MapFrame -> Button
  (
  "-text" => "Browse file",
  "-command" => sub
    {
      # browse for file
      # browse for .txt files
      $MapFile = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["text files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "Open MapFile",
        );
      # if a file was chosen
      if ( $MapFile )
        {
        #extract directory
        print "\n $MapFile was chosen\n";
        }
      # If map file is not selected properly  
      else
        {
          print "no filename!\n";
          # prompt user
          $main->messageBox(
              '-icon'    => "error", #qw/error info question warning/
              '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
              '-title'   => 'Attention',
              '-message' => "!Please select file first!"
          );


       }
    },
  )
    -> pack ("-side" => 'left',"-padx" => 5,);
            

# create label in 'GenID'
$Generic -> Label( "-text" => "Generic ID for creating mapfile: ", )
            -> pack( "-side" => 'left', );

# create entry in 'GenID'
$Generic -> Entry(
            "-width" => 15,
            "-textvariable" => \$GenID, #reference 
            )-> pack( "-side" => 'left', );
            
# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create 'create map file' button
$ButtonFrame -> Button
  (
  "-text" => "Create MapFile",
  "-command" => sub
    {
      if($GenID =~ /[0-9]+/)  #If Generic ID contains numbers
      {

      $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Numbers Present in generic ID!"
      );

      }
      
          
      elsif($XML_in eq "")    #If XML file is not selected
      {

      $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!result file is needed to generate Map file!"
      );

      }
      
      
      else
      {
        unless ($MapFile){
        # browse for file
        $MapFile = $main -> getSaveFile
          (
          "-filetypes"  =>
            [
            ["text files", '.txt'],
            ["All files", '.*']
            ],
          "-title"      => "Create MapFile",
          );
        }  
        # if a map file was chosen
        if ( $MapFile )
        {
          scan_txt_for_LIFT();
          print "\n $MapFile was created\n";
          
        }
        else
        {
          print "no filename!\n";
          # prompt user
          $main->messageBox(
              '-icon'    => "error", #qw/error info question warning/
              '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
              '-title'   => 'Attention',
              '-message' => "!File Not Created!"
          );
        }
      }
    },
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "EVALUATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($XML_in) { # create project if scan_file was given
          if($MapFile){
            if($scan_type eq "TC"){
              $main->messageBox(
                              '-icon'    => "error", #qw/error info question warning/
                              '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Evaluation can be done only for TestStep ID using MapFile!"
              );
            }
            else{
              evaluate_xml();
            }
          }
          else{
            evaluate_xml();
          }  
        }
        
        else{
        # prompt user if project_id is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

my $logfile=$0;
$logfile =~ s/\.(\S+)$/_logfile.txt/;

open(LOG, ">$logfile") or die "ERROR: File not found!\n";
w2log("\n\n\n* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
w2log("* * * * * * * * * * * S C R I P T   L O G F I L E * * * * * * * * * * *\n");
w2log("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
w2log("\n* * * $Toolversion - Scriptname: $0\n\n");
w2log("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

# run with CLI
GetOptions('XML_in=s' => \$XML_in);
if ($XML_in){ # source files
    w2log("not yet implemented\n");
    #evaluate_xml();
}
else{
  # if no options, run TK GUI

  w2log("running with TK\n");
  MainLoop;
}

w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++







#################################################################################################################
# * * * * * M A I N - C o n t r o l * * * * *
#################################################################################################################
sub evaluate_xml {
my $result_CSV_new;

%result=();
@result_CSV_file = ();
%maphash = ();
@scanned_ids = ();

$result_CSV = $XML_in;
$result_CSV =~ s/\.\w+$/_importfile.txt/;

my $line;
my $ID = "none";
my $blankID = "blank";
my $previousID = $blankID;
my $verdict = "na";

my ($TcID,$DoorsID);

  if($MapFile){    
      my (@DoorsIDs,$line);
      open(MAP,"<$MapFile");
      @scanned_ids = <MAP>;
      foreach $line (@scanned_ids){
        chomp($line);
        ($TcID,@DoorsIDs) = split(/[;,]/,$line);
        foreach $DoorsID (@DoorsIDs){
        
          $maphash{$TcID}{$DoorsID}++;
        }
      }  
  }


  if (-T $XML_in){
      # if normal text file modify content and rename
        w2log("#####################################################################\n");
        w2log("#### evaluating  $XML_in\n");
        w2log("#####################################################################\n");

        open(FILEHANDLE, $XML_in) or die "could not open (read) $XML_in\n";
        while($line = <FILEHANDLE>){

         # if line contains SW version
         #e.g.ECU_SW_VERSION;PLX0812A;
         if ($line =~ /^\s*ECU_SW_VERSION;([^;]+)/){
            $SWversion=$1;
         }

         # if line contains test verdict
         # e.g. TC_VD;TC_SPI_Monitoring.DATA_CAPTURE_MOSI;VERDICT_PASS;
         if ($line =~ /^\s*TC_VD;([^;]+);([^;]+);/){
            $TcID = $1;
            $verdict = $2;
            if ($treat_inconc_as_fail and $verdict eq "VERDICT_INCONC"){
             $verdict="VERDICT_FAIL";
            }

            if($MapFile){    
                foreach $DoorsID (keys(%{$maphash{$TcID}})){
                    update_resulttable($DoorsID,$verdict);
                }

            }
            else{
            update_resulttable($TcID,$verdict);
            }         }
         else {print"skipped $line";}

       } #END while($line = <FILEHANDLE>)
       close(FILEHANDLE);


    

  open(NEWFILE, ">$result_CSV") or die "could not open (write) $result_CSV\n";
  # add comment at beginning of list
  print NEWFILE "#$SWversion;$Toolversion\n";

  foreach (sort keys %result){
    print NEWFILE "$_;$result{$_}\n";
  }
  close(NEWFILE);

    $display_txt = "file <$result_CSV> created";

} # END if (-T $XML_in)


  w2log("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
  w2log("\n* * * FINISHED: $0\n\n");
  w2log("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");


  #################################################################################
  ### END MAIN Control Part
  #################################################################################

} #evaluate_xml end





#################################################################################################################
# * * * * * H E L P E R   F U N C T I O N S * * * * *
#################################################################################################################





##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


sub map_verdict{
my $result = shift;
  # map TC verdicts to SRTP verdicts
    if ($result eq "pass" or $result eq "VERDICT_PASS" or $result eq "passed"){
      $result = "passed";
    }
    elsif ($result eq "fail" or $result eq "VERDICT_FAIL" or $result eq "failed"){
      $result = "failed";
    }
    else {print "$result\n";$result = "not done";}
return $result;
}


sub update_resulttable{
my $ID = shift;
my $verdict = shift;
$verdict=map_verdict($verdict);
 if (exists $result{$ID}) {
  # overwrite if no verdict was set or result = fail
  if ($result{$ID} eq "not done" or $verdict eq "failed"){
   $result{$ID}=$verdict;
  }
  # result = warn overwrites any verdict except fail
  elsif ($result{$ID} ne "fail" and $verdict eq "warning"){
   $result{$ID}=$verdict;
  }
 }
 else{
  #create new
  $result{$ID}=$verdict;
 }

}


#############################################################################

sub scan_txt_for_LIFT{
  my %found_ids;
  my $line;
  my $ID;
  if($MapFile !~ /.txt$/)
  {
    $MapFile = $MapFile.".txt";
  }  
w2log("creatign mapfile for LIFT\n");
  
  open(FILEHANDLE, $XML_in) or die "could not open (read) $XML_in\n";
  while($line = <FILEHANDLE>){


     # if line contains test verdict
     # e.g. TC_VD;TC_SPI_Monitoring.DATA_CAPTURE_MOSI;VERDICT_PASS;
     if ($line =~ /^\s*TC_VD;([^;]+);([^;]+);/){
        $ID = $1;
w2log("ID= $ID\n");
        $found_ids{$ID}=1;
      
    }
  }
  close(FILEHANDLE);
  
  open(MAP,">$MapFile");
  print MAP "#Software Version : $SWversion\n#ToolVersion : $Toolversion\n#TXT file : $XML_in\n";
  foreach $ID (sort keys %found_ids)
  {
    print MAP "$ID;$GenID\n";
  } 
  close(MAP);
}  

# end of program

=head1 usage

create file for result import to DOORS from LIFT result file

logfile will be written containing all actions. use 'EXIT' button to finish logfile properly

to prepare a mapfile template to map TC_ID to DOORS_ID for import use 'Create MapFile' Button

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut
