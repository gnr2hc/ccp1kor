Bosch Software Center (SCCM) automatically enables sleep mode and monitor switch off after each update.

How to disable once automatic sleep mode and automatic monitor switch off?
Run no_sleep.bat.

How to disable permanently automatic sleep mode and automatic monitor switch off for one user?
Copy no_sleep.bat into startup folder: C:\Users\<USERNAME>\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
