#!usr\bin\perl

use strict;
use warnings;
use File::Find;
use File::Basename;
use File::Copy;
use List::MoreUtils qw(uniq);
use Data::Dumper;
use Digest::MD5 qw(md5_hex);
use File::Slurp qw(read_file write_file);


my @folders = qw(Documentation htmldata modules run_once Tools);


my $file_found_info;
my $map_scm_mks_folders_path = {
	ENGINE => {
		SCM => {
			Documentation=> 'C:\sandboxes\TurboLIFT_Bosch_Engine_development\upe1cob\tools_TurboLIFT\Engine\Documentation',
			htmldata=> 		'C:\sandboxes\TurboLIFT_Bosch_Engine_development\upe1cob\tools_TurboLIFT\Engine\htmldata',
			run_once => 	'C:\sandboxes\TurboLIFT_Bosch_Engine_development\upe1cob\tools_TurboLIFT\Engine\run_once',
			modules=> 		 ['C:\sandboxes\TurboLIFT_Bosch_Engine_development\upe1cob\tools_TurboLIFT\Engine\modules',
							  'C:\sandboxes\TurboLIFT_Bosch_Engine_development\upe1cob\tools_TurboLIFT\Engine\funclib_generic']
			
		},
		MKS => {
			Documentation=> 'C:\TurboLIFT_TSG4\Engine\Documentation',
			htmldata=> 'C:\TurboLIFT_TSG4\Engine\htmldata',
			run_once=> 'C:\TurboLIFT_TSG4\Engine\run_once',
			modules=> 'C:\TurboLIFT_TSG4\Engine\modules',
		}, 	
		
	},

};

# recurseFiles_MKS_SCM_sandbox

sub recurseFiles_MKS_SCM_sandbox{
	
	my $files_store_info_href ;
	
	foreach my $confMgmt ( keys %{$map_scm_mks_folders_path-> {ENGINE}} ) {
	
		my $docu_path = $map_scm_mks_folders_path-> {ENGINE}{$confMgmt}{Documentation}; # documentation
		if (-d $docu_path) {
			$files_store_info_href->{$confMgmt}{Documentation}  = getFiles_from_dirs(  $docu_path  ) 
		}
		
		my $htmldata_path = $map_scm_mks_folders_path-> {ENGINE}{$confMgmt}{htmldata}; # documentation
		if (-d $htmldata_path) {
			$files_store_info_href->{$confMgmt}{htmldata}  = getFiles_from_dirs(  $htmldata_path  ) 
		}
		
		my $run_once_path = $map_scm_mks_folders_path-> {ENGINE}{$confMgmt}{run_once}; # documentation
		if (-d $run_once_path) {
			$files_store_info_href->{$confMgmt}{run_once}  = getFiles_from_dirs(  $run_once_path  ) 
		}
		$files_store_info_href->{SCM}{modules}  = getFiles_from_dirs(  $map_scm_mks_folders_path-> {ENGINE}{SCM}{modules});
		$files_store_info_href->{MKS}{modules}  = getFiles_from_dirs(  $map_scm_mks_folders_path-> {ENGINE}{MKS}{modules})			
	
	}

	print (Dumper $files_store_info_href->{MKS}{modules});
	print (Dumper $files_store_info_href->{SCM}{modules});
	return $files_store_info_href;
}


# 
#  Find files and folders of directory and its sub-directory
# 
sub getFiles_from_dirs {
	my @args = @_;
	my $dirPath_aref = shift @args;
	my %files_store; 

	if ($dirPath_aref =~ /ARRAY/) {
		foreach my $dirPath (@$dirPath_aref) {
			print ("..." . $dirPath."\n");
			unless (-d $dirPath) { print ("ERROR : dir $dirPath does not exists.\n") ; return } ;
			find( sub { 
					my 	$fileName = $File::Find::name;
						$files_store{basename $fileName} = $fileName if (-f $fileName)
					}, $dirPath
				);
		}
	}
	else {
		my $dirPath = $dirPath_aref ;
		print ("..." . $dirPath."\n");
		unless (-d $dirPath) { print ("ERROR : dir $dirPath does not exists.\n") ; return } ;
		find( sub { 
				my 	$fileName = $File::Find::name;
					$files_store{basename $fileName} = $fileName if (-f $fileName)
				}, $dirPath
			);
	}

	
	return \%files_store;
}


sub gather_missing_or_common_files_Info {
	my @args = @_;
	my $parent_hash_to_compare = shift @args;
	my $compare_element = shift @args; # Documentation , htmldata

	# <MKS or SCM> => {	 
		# <Engine folder element> => {
			  # 'E05_Spec.png' => 'C:\\TurboLIFT_TSG4\\Engine\\Documentation/pics/sVTT/E05_Spec.png',
			  # 'marktree.js' => 'C:\\TurboLIFT_TSG4\\Engine\\Documentation/perldoc_framework/static/marktree.js',
			  # 'SQ_microcut_7.png' => 'C:\\TurboLIFT_TSG4\\Engine\\Documentation/pics/TSG4/SQ_microcut_7.png',
			  # 'PAS2_microcut_7.png' => 'C:\\TurboLIFT_TSG4\\Engine\\Documentation/pics/TSG4/PAS2_microcut_7.png',
			  # 'measure_Ubat.png' => 'C:\\TurboLIFT_TSG4\\Engine\\Documentation/pics/TSG4/measure_Ubat.png',
		# }
	# }


	my $files_mks_sbox_href = 	$parent_hash_to_compare->{MKS}{$compare_element};
	my $files_scm_sbox_href = 	$parent_hash_to_compare->{SCM}{$compare_element};
	my @allFiles =  uniq(keys %{$files_mks_sbox_href}, keys %{$files_scm_sbox_href});

	foreach my $file (@allFiles) {
		
		# print ("$file => " .  $files_mks_sbox_href->{$file}."\n");
		# print ("$file => " .  $files_scm_sbox_href->{$file}."\n");

		if (defined $files_mks_sbox_href->{$file} and defined $files_scm_sbox_href->{$file})   {
			print ("MKS and SCM : " . $file."\n");
			$file_found_info->{$compare_element}{MKS_SCM}{FILE_COUNT} += 1; 
			push @{$file_found_info->{$compare_element}{MKS_SCM}{FILES_FOUND}}, $file;
			push @{$file_found_info->{$compare_element}{MKS_SCM}{FILES_SCM_MKS_CS_DIFFERENT}}, $file 
												if doMD5Comparision($files_mks_sbox_href->{$file}, $files_scm_sbox_href->{$file}) == 0;
		}

		if (not defined $files_mks_sbox_href->{$file} and defined $files_scm_sbox_href->{$file})   {
			print ("only  SCM : " . $file."\n");
						$file_found_info->{$compare_element}{SCM}{FILE_COUNT} += 1; 
			push @{$file_found_info->{$compare_element}{SCM}{FILES_FOUND}}, $file;
		}

		if (defined $files_mks_sbox_href->{$file} and not defined $files_scm_sbox_href->{$file})   {
			print ("only  MKS : " . $file."\n");
			$file_found_info->{$compare_element}{MKS}{FILE_COUNT} += 1; 
			push @{$file_found_info->{$compare_element}{MKS}{FILES_FOUND}}, $file;
		}	
	}

	print scalar  @allFiles ;

}


sub doMD5Comparision{
	my @args = @_;
	my $file1_to_compare = shift @args;
	my $file2_to_compare = shift @args;
   
	my $file1_CS = md5_hex( read_file($file1_to_compare) );
	my $file2_CS = md5_hex( read_file($file2_to_compare) );
	
	return 1 if ($file1_CS eq $file2_CS);
	return 0;
  
}

sub print_files_of_differnt_md5CS{
	my @args = @_;
	my $files_engine_SCM_MKS_href = shift @args;
	my $engine_compare_folder = shift @args;

	my $files_diff_cs = $file_found_info->{$engine_compare_folder}{MKS_SCM}{FILES_SCM_MKS_CS_DIFFERENT}; 
	
	print ("\nprint_files_of_differnt_md5CS function start ..\n");
	
	print ("\nprint_files_of_differnt_md5CS : Files which are having different CS for common files (SCM and MKS sandbox) for : '$engine_compare_folder' ...\n");
	foreach my $file_cs (@$files_diff_cs) {
		print (".. $file_cs  -> ". $files_engine_SCM_MKS_href->{SCM}{$engine_compare_folder}{$file_cs} . "\n"); # either MKS or SCM
	}
	
	return 1;
}

sub show_orphan_files{
	my @args = @_;
	my $files_engine_SCM_MKS_href = shift @args;
	my $engine_compare_folder = shift @args;
	my $cfmgmt = shift @args;  # MKS or SCM 
	
	my $files_found = $file_found_info->{$engine_compare_folder}{$cfmgmt}{FILES_FOUND}; 
	print ("=====================================\n");
	print ("orphan files of '$cfmgmt' sandbox in $engine_compare_folder .. \n");
	print ("none .. \n") unless (defined $files_found );
	foreach my $file (@$files_found) {
		print (".. $file  -> ". $files_engine_SCM_MKS_href->{$cfmgmt}{$engine_compare_folder}{$file} . "\n");
	}
}

sub copyFiles_onlyOfDifferent_CS{
	my @args = @_;
	my $files_engine_SCM_MKS_href = shift @args;
	my $engine_compare_folder = shift @args;
	my $src_cfg_mgmt = shift @args;  # MKS or SCM
	my $dest_cfg_mgmt = shift @args; # MKS or SCM

	
	my $files_diff_cs = $file_found_info->{$engine_compare_folder}{MKS_SCM}{FILES_SCM_MKS_CS_DIFFERENT}; 
	
	print ("\n copyFiles_onlyOfDifferent_CS :  copy files from '$src_cfg_mgmt' to '$dest_cfg_mgmt' which has different CS for '$engine_compare_folder' .. \n");
	foreach my $file_cs (@$files_diff_cs) {
		my $src_file = $files_engine_SCM_MKS_href->{$src_cfg_mgmt}{$engine_compare_folder}{$file_cs};
		my $dest_file = $files_engine_SCM_MKS_href->{$dest_cfg_mgmt}{$engine_compare_folder}{$file_cs};
		
		copy($src_file, $dest_file) or print  "Copy failed: $!";	
	}
	return 1;
}


# ===============================================================================
my $enginefiles__SCM_MKS_sandbox_href =  recurseFiles_MKS_SCM_sandbox();

gather_missing_or_common_files_Info($enginefiles__SCM_MKS_sandbox_href, 'modules'); 		# modules, Documentation , htmldata, run_once, modules
print_files_of_differnt_md5CS($enginefiles__SCM_MKS_sandbox_href, 'modules'); 				# modules, Documentation , htmldata, run_once, modules
show_orphan_files($enginefiles__SCM_MKS_sandbox_href, 'modules', "MKS");
show_orphan_files($enginefiles__SCM_MKS_sandbox_href, 'modules', "SCM");
#copyFiles_onlyOfDifferent_CS($enginefiles__SCM_MKS_sandbox_href, 'htmldata', "MKS", "SCM"); # modules, Documentation , htmldata, run_once, modules



print ("\n");
# print (Dumper $file_found_info);
