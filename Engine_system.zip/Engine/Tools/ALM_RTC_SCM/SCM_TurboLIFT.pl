#!usr\bin\perl

use strict;
use warnings;

use Data::Dumper;
use scmlib;


my $user = getlogin;
my $sandbox_root_path = 'C:\sandboxes';


my ($result_string, $result_href, $result_aref);
my $componentLevel = 0;

# =========    INPUTS    =============
my $outlook_name = 'Rathore Upendra Singh';						# changed the outlook for this as who ever is executing this	
my $rep_url = 'https://rb-ubk-clm-04.de.bosch.com:9443/ccm/';	# Playground server connection, alias name used in script as PS_SCM
my $task_number = '20207' ;										# task number for the playground, but for productive server check it.
# ====================================


## FUNCTION CALL : changes these parameters
# 
#  CAUTION : DO NOT RUN THIS SCRIPT IF YOU DONT KNOW ABOUT RTC SCM.
# 
Create_stream_from_template_for_customer_project('Fiat', '5120');


sub Create_stream_from_template_for_customer_project {

	my @args = @_;
	my $customer_name = shift @args;
	my $project_name = shift @args;
	

	my $src_stream =  "TurboLIFT_".$customer_name."_".$project_name ; 					 # example TurboLIFT_Daimler_MRA
	my $snapshot_name = "Initial_Snapshot_".$customer_name."_".$project_name;

	# CALL Create stream
	create_stream($src_stream);
	
	# components mapping
	my $cmpng_href = {
		CONFIG_CPMNT =>  'tools.turboLIFT.Config.'.$customer_name."\.".$project_name,
		Engine => 'tools.turboLIFT.Engine',
		TCs => 'tools.turboLIFT.TCs',
		TestArea => 'tools.turboLIFT.TestArea',
		funclib_customer => 'tools.turboLIFT.Engine.'.$customer_name.'.funclib_customer',
		funclib_project => 'tools.turboLIFT.Engine.'.$customer_name."\.".$project_name.'.funclib_project',
		TCs_Customer => 'tools.turboLIFT.TCs.'.$customer_name.'.TCs_Customer',
		TCs_project=> 'tools.turboLIFT.TCs.'.$customer_name."\.".$project_name.'.TCs_project',
		
	};

	my $cfg_component = $cmpng_href->{CONFIG_CPMNT}; # tools.turboLIFT.Config.Daimler.MRA
	
	# CALL add componets to add all the required components
	add_component($src_stream, $cfg_component) ;
	add_component($src_stream, $cmpng_href->{Engine}, 	{SRC_WK_OR_STREAM => 'TurboLIFT_Project_Tempate'}  );
	add_component($src_stream, $cmpng_href->{TCs}, 		{SRC_WK_OR_STREAM => 'TurboLIFT_Project_Tempate'});
	add_component($src_stream, $cmpng_href->{TestArea}, {SRC_WK_OR_STREAM => 'TurboLIFT_Project_Tempate'});
	add_component($src_stream, $cmpng_href->{funclib_customer}) ;
	add_component($src_stream, $cmpng_href->{funclib_project}) ;
	add_component($src_stream, $cmpng_href->{TCs_Customer}) ;
	add_component($src_stream, $cmpng_href->{TCs_project}) ;

	# STEP create workspace is not create before:
	my $rws_name = $src_stream.'_RWS_'.$user;
	create_rws($src_stream, $user) if not rws_already_existed($rws_name, $outlook_name);
	
	# STEP add the sub component
	my $chageset_nbr;
	$chageset_nbr = add_subComponent($rws_name, $cfg_component, $cmpng_href->{Engine});	
	$chageset_nbr = add_subComponent($rws_name, $cfg_component, $cmpng_href->{TestArea});
	$chageset_nbr = add_subComponent($rws_name, $cfg_component, $cmpng_href->{TCs});
	checkinAndDeliver($rws_name, undef, undef, $cfg_component, 'Add sub components', $task_number, {CHANGESET_NBR=> $chageset_nbr});
	
	$chageset_nbr = add_subComponent($rws_name, $cmpng_href->{Engine}, $cmpng_href->{funclib_customer});
	$chageset_nbr = add_subComponent($rws_name, $cmpng_href->{Engine}, $cmpng_href->{funclib_project});
	checkinAndDeliver($rws_name, undef, undef, $cmpng_href->{Engine}, 'Add sub components', $task_number, {CHANGESET_NBR=> $chageset_nbr});

	$chageset_nbr = add_subComponent($rws_name, $cmpng_href->{TCs}, $cmpng_href->{TCs_Customer});
	$chageset_nbr = add_subComponent($rws_name, $cmpng_href->{TCs}, $cmpng_href->{TCs_project});
	checkinAndDeliver($rws_name, undef, undef, $cmpng_href->{TCs}, 'Add sub components', $task_number, {CHANGESET_NBR=> $chageset_nbr});

	# STEP generate load rule file
	my $load_rule_file = 'C:\sandboxes\TurboLIFT_Generated.loadrule' ;
	generate_load_rule_file($src_stream, $load_rule_file, $cfg_component);
	
	# STEP load workspace form load rule file
	load_rws_from_load_rule_file($src_stream, 
								 'C:\\sandboxes\\'.$src_stream,	 # eg 'C:\\sandboxes\\TurboLIFT_Project_Tempate', 
								 $load_rule_file);
	
	
	# STEP  Checkin the template config files for component and deliver.	
	my $sub_dir = '';
	$sub_dir = $1 if ($cfg_component=~/\.(\w+)$/) ;
	
	my $src = 'K:\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\RB_EI\4Upendra\SCM\Template_Files';
	my $dest = 'C:\\sandboxes\\'.$src_stream.'\\'.$user.'\\'.$sub_dir;
	S_wr2log ("$src -> $dest");
	system ("XCOPY $src $dest /E /C /I /Q /R /K /Y /Z /J");

	checkinAndDeliver( 		$rws_name, 													# worksapce name
							'C:\\sandboxes\\'.$src_stream, 								# worksapce dir
							$dest, 														# dir where changes have to be made or commit
							$cfg_component, 											# componenet name
							'add config files and sub components',						# comment	
							$task_number,												# tasks number
	);
	
	# STEP Create snapshot	
	CreateSnapshot($src_stream, $snapshot_name);
}




sub load_rws_from_load_rule_file{
	my @args = @_;
	my $src_stream = shift @args;
	my $rootdir_savefiles = shift @args;
	my $load_rule_file = shift @args;
	
	my $rws_name = $src_stream.'_RWS_'.$user;
	S_wr2log ("load rws from '$src_stream' with name '$rws_name' at root dir '$rootdir_savefiles' with load rule '$load_rule_file' ");
	
	# STEP create workspace is not create before
	mkdir $rootdir_savefiles;
	my $working_directory = $sandbox_root_path . '\\' . $src_stream;
	chdir $working_directory;
	
	#CALL load_rws
	load_rws($rws_name, $rootdir_savefiles, $load_rule_file);
}


sub getlatest_snapshot_of_a_stream{
	my @args = @_;
	my $stream = shift @args;
	$result_string = execute("lscm list snapshots -j -r PS_SCM $stream");
	$result_href = DecodeJSONContent( $result_string );
	

	my $latest_snapshot_name = $result_href->{snapshots}[0]{name};
	my $latest_snapshot_uuid = $result_href->{snapshots}[0]{uuid};
	print("Latest snapshot of stream $stream is '$latest_snapshot_name' with uuid '$latest_snapshot_uuid'\n");

	return 1;
}










