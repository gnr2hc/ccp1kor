# *****************************************************************************************************
#
#  Copyright (c) 2019  Robert Bosch Engineering and Bussiness soltions Ltd
#                      Germany
#                      All rights reserved
#
# ******************************************************************************************************
#    $Source: Tools/ALM_RTC_SCM/scmlib.pm $
#    $Revision: 1.1 $
# ******************************************************************************************************

package scmlib;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

use strict;
use warnings;
use File::Slurp;
use Data::Dumper;
use File::Basename;
use File::Path qw( make_path );
use JSON::PP;

# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.1 $;

@ISA    = qw(Exporter);
@EXPORT = qw(
	create_stream
	CreateSnapshot
	
	create_component
	add_component
	add_subComponent
	remove_component

	create_rws
	load_rws
	rws_already_existed
	generate_load_rule_file

	checkinAndDeliver
	
	S_wr2log
);

our ( $VERSION, $HEADER );
$VERSION = q$Revision: 1.1 $;

# defines
# SWITCH FOR DEBUG PRINTOUT'S in the log file:
# - 1 : helpful for developers for debugging, as it print outs a lot of logs. Exection time increases by ~10 sec more.
# - 0 : for users, just switch off.
my $FLAG_EN_DEBUG_PRINT_OUTS = 1;
my $FLAG_EN_DEEP_DEBUG_PRINT_OUTS = 0;
my $log_File = 'C:\sandboxes\SCM_log.txt';
my ($result_string, $result_href, $result_aref);
my $componentLevel = 0;
my $componentsInfo_href;;




sub create_stream {
	my @args = @_;
	my $stream = shift @args;

	S_wr2log ("input Stream name = '$stream'.");
	return 1 if CheckStream_Existence($stream ) == 1;	

	return 1;
}


sub create_component{
	my @args = @_;
	my $stream_or_rws = shift @args;
	my $component_to_create = shift @args;
	
	S_wr2log ("component '$component_to_create' to create in stream (or rws) '$stream_or_rws' .. ");
	$result_string = execute("lscm create component $component_to_create $stream_or_rws -r PS_SCM");
	$result_string = execute("lscm show status");
	S_wr2log ("status --> : \n $result_string..");

}

sub add_component{
	my @args = @_;
	my $stream_or_rws = shift @args;
	my $component_to_add = shift @args;
	my $options_href = shift @args;

	S_wr2log ("add component '$component_to_add' to stream (or rws) '$stream_or_rws' .. ");
	
	#STEP check if the component already exists in the streams if not then create it
	return 1 if (Check_component_existence_in_stream($stream_or_rws, $component_to_add) == 1 ) ;
	
	# TO DO Check if component already exists
	create_component ($stream_or_rws, $component_to_add) ;
	
	#STEP add the component to the stream_or_rws or Rws.
	my $src_wk = $options_href->{SRC_WK_OR_STREAM};
	my $mul_hierarchy = $options_href->{MUL_HRCHY} ; # Hierarchy
	
	if (defined $src_wk and defined $mul_hierarchy) {
		$result_string = execute("lscm add component $stream_or_rws $component_to_add  -r PS_SCM -s $src_wk -m");
	}	
	elsif (defined $src_wk) {
		$result_string = execute("lscm add component $stream_or_rws $component_to_add  -r PS_SCM -s $src_wk");
	}
	else {
		$result_string = execute("lscm add component $stream_or_rws $component_to_add  -r PS_SCM");
	}  
	S_wr2log ("status --> : \n $result_string..");
		
	return 1;
}

sub add_subComponent{
	my @args = @_;
	my $strm_or_rws = shift @args;
	my $parent_component = shift @args;
	my $components_to_add = shift @args;
	
	S_wr2log ("'$components_to_add' to parent component '$parent_component' in wkspc = '$strm_or_rws' .. ");
	$result_string = execute("lscm add subcomponent $strm_or_rws $parent_component $components_to_add -r PS_SCM ");
	S_wr2log ("Status =  $result_string .. ");
	my $changeset_nbr = getChangeSetNbr($result_string );
	
	return $changeset_nbr;
}

sub remove_component{
	my @args = @_;
	my $strm_or_rws = shift @args;
	my $components_to_remove = shift @args;
	
	S_wr2log ("'$components_to_remove' from in wkspc = '$strm_or_rws' .. ");
	$result_string = execute("lscm remove component $strm_or_rws $components_to_remove -r PS_SCM ");
	S_wr2log ("Status =  $result_string .. ");
}


sub CheckStream_Existence {
	my @args = @_;
	my $stream = shift @args;

	$result_string = execute("lscm list streams -n $stream -r PS_SCM -j");
	$result_href = DecodeJSONContent( $result_string );
	
	# return 1 if stream already exists
	foreach my $found_stream (@$result_href) {
		if ($found_stream-> {type} eq 'STREAM' and  $found_stream-> {name} eq $stream) {
			my $owner = $found_stream->{owner};
			my $uuid = $found_stream->{uuid};
			S_wr2log ("stream '$stream' already exists (owner= '$owner' and uuid = '$uuid')..");
			return 1;
		}
	}
	return;
}

sub Check_component_existence_in_stream{
	my @args = @_;
	my $stream = shift @args;
	my $component_to_check = shift @args;

	$result_string = execute("lscm list components $stream -r PS_SCM -j");
	$result_href = DecodeJSONContent( $result_string );
	
	my $ws_name = $result_href->{workspaces}[0]{name};
	S_wr2log( "Checking changes in stream '$stream' in workspace '$ws_name' ...\n" );
	my $components_aref = $result_href->{workspaces}[0]{components};
	 if (scalar @{$components_aref} == 0)  {
		S_wr2log ("no components found for stream '$stream'.."); 
		return 0;
	} 
	
	foreach my $component_href ( @$components_aref ) {
		Recurse_component($component_href);
	}

	my @found_components = keys %{$componentsInfo_href};
	S_wr2log ("found components for stream '$stream' are = @found_components .");

	if ( grep {$_ =~ /$component_to_check/} @found_components ) {
		S_wr2log (" '$component_to_check' already present in $stream'");
		return 1;
	}
	else {
		S_wr2log ("'$component_to_check' not found in $stream' .. ");
		return 0; 
	} 	

	undef $componentsInfo_href;
	
	return;
}



sub Recurse_component{
    my $component_href = shift;

    my $spaces = '  ' x $componentLevel;
    my $name = $spaces . $component_href->{name};
    S_wr2log( "Component $name" ); 

	# store component name and uuid
	my $component_name = $component_href->{name};
	$componentsInfo_href->{$component_name} = $component_href->{uuid};
	
    my $subcomponents_aref = $component_href->{subcomponents};
    if( defined $subcomponents_aref and ref($subcomponents_aref) eq 'ARRAY' and @$subcomponents_aref > 0 ) {
        foreach my $subcomponent_href ( @$subcomponents_aref ) {
            $componentLevel++;
            Recurse_component($subcomponent_href);
            $componentLevel--;
        }
    }
}


sub create_rws{
	my @args = @_;
	my $src_stream = shift @args;
	my $user = shift @args;
	
	S_wr2log ("for $src_stream for user '$user' ..");
	
	# create workspace
	my $rws_name = $src_stream.'_RWS_'.$user;
	$result_string = execute("lscm create workspace -u $user -s $src_stream -r PS_SCM $rws_name -j");
	S_wr2log ("status = $result_string ..");
	
	$result_string = execute("lscm show status");
	S_wr2log ("status for creating '$rws_name' = $result_string ..");
		
	return $rws_name;
}


sub rws_already_existed{
	my @args = @_;
	my $rws_toCheck = shift @args;
	my $outlook_name = shift @args;

	S_wr2log ("check wether rws = '$rws_toCheck' for '$outlook_name' already exists ..");
	$result_string = execute("lscm list ws -r PS_SCM  -n TurboLIFT -m all -j");
	$result_aref = DecodeJSONContent( $result_string );

	my $rws_found_flag = 0;	
	foreach my $found_rws (@$result_aref) {
		if ($found_rws->{'owner'} =~ $outlook_name and $found_rws->{'name'} eq $rws_toCheck){
			S_wr2log ("Found : '$found_rws->{name}' --> owner as $found_rws->{'owner'} ..");
			$rws_found_flag = 1;
		}
	}
	S_wr2log ("$rws_toCheck found status = '$rws_found_flag' ..");
	
	return $rws_found_flag;
}

sub load_rws{
	my @args = @_;
	my $rws_name  = shift @args;
	my $rootdir_savefiles = shift @args;
	my $load_rule_file = shift @args;

	S_wr2log ("name 'rws_name' dir to save file = '$rootdir_savefiles' with rule '$load_rule_file' ..");

	# load the workspace
	$result_string = execute("lscm load -r PS_SCM $rws_name -d $rootdir_savefiles -L $load_rule_file");
	$result_string = execute("lscm show status");
	S_wr2log ("status = $result_string ..");

}

sub getChangeSetNbr{
	my @args = @_;
	my $result_string = shift @args;

	# baseline: *(2875) 4 "baseline_B_check_share_02"
	# Outgoing:
	  # Change sets:
		# (2956) -*--@  "<No comment>" 29-May-2019 04:45 PM
		  # Changes:
	
	S_wr2log ($result_string); 
	my $changeset_nbr =  $1  if ($result_string =~ /.+Change sets:\s+\((\d+)\)/); 
	if (not defined $changeset_nbr)  {	
		S_wr2log ("Changeset number is not found. May be chnages are not detected.");
		return ;
	}
	S_wr2log ("detected changset number = $changeset_nbr ");
	return $changeset_nbr;
}

sub checkinAndDeliver {
	my @args = @_;
	my $wbs_name = shift @args;
	my $wbs_dir = shift @args;
	my $path_to_commit_forCheckin = shift @args; # eg C:\sandboxes\TurboLIFT_Project_Tempate\TurboLIFT_Project_Tempate\Template
	
	my $component_name = shift @args;
	my $comment_changeset = shift @args;
	my $alm_workItemNumber = shift @args;
	my $options_href = shift @args;
	
	S_wr2log (" $wbs_name $wbs_dir $component_name $comment_changeset $alm_workItemNumber ");

	my $changeset_nbr;
	$changeset_nbr = $options_href->{CHANGESET_NBR} ;
	if (not defined $changeset_nbr) { 
		
		# -----------------------
		# checkin and create a changeset
		# -----------------------
		
		# set do the checkin
		# lscm checkin C:\sandboxes\TurboLIFT_Project_Tempate\TurboLIFT_Project_Tempate\Template -j  -d c:\sandboxes\TurboLIFT_Project_Tempate
		$result_string = execute("lscm checkin  $path_to_commit_forCheckin -d $wbs_dir");
		$changeset_nbr  = getChangeSetNbr($result_string) // return ;
	}
	S_wr2log ("Found changset number is : $changeset_nbr ");

	# set the comment for the changeset
	$result_string = execute("lscm set changeset $changeset_nbr --comment \"$comment_changeset\" -r PS_SCM ");
	S_wr2log ("$result_string"); 
	
	# add the workitem
	$result_string = execute("lscm add workitem $changeset_nbr $alm_workItemNumber -r PS_SCM");
	S_wr2log ("$result_string"); 
	
	# deliver the changeset
	$result_string = execute("lscm deliver -r PS_SCM -s $wbs_name");
	S_wr2log ("$result_string"); 
}

sub CreateSnapshot{

	my @args = @_;
	my $src_stream_wksp = shift @args;
	my $snapshot_name = shift @args;
	
	$result_string = execute("lscm create snapshot $src_stream_wksp -n $snapshot_name -r PS_SCM");
	S_wr2log ("$result_string"); 
	
}

sub getLatestChangeset {
	my @args = @_;
	my $wbs_name = shift @args;
	
	$result_string = execute("lscm list changeset -r PS_SCM -w $wbs_name");
	return $result_string ; 
}


sub execute{
    my $cmd = shift;
    my $output;
    
    #print "executing command <$cmd>\n";
    S_wr2log ("command [$cmd] ", 5);
	$output = `$cmd`;
	#S_wr2log ("command output is => \n '$output' ", 5);
    
    return $output;
}

sub DecodeJSONContent{
    my $json_string = shift;

    #try to decode JSON string
    my $decodeCommand = 'my $eval = decode_json($json_string)';
    my $responseContent_href = eval $decodeCommand; # using eval to avoid a crash if the string is not a proper JSON string

    #return undecoded string if decoding was not successful
    unless( $responseContent_href ) {
        S_wr2log ( "ERROR: Could not decode JSON string: $json_string\n , 2 ");
        return;
    }
	S_wr2log ( "Dumper = \n".Dumper($responseContent_href)."\n") if $FLAG_EN_DEEP_DEBUG_PRINT_OUTS;
    
	return $responseContent_href;
}




sub get_component_desc_from_stream{
	my @args = @_;
	my $stream = shift @args;
	
	$result_string = execute("lscm list components $stream -r PS_SCM -j");
	$result_href = DecodeJSONContent( $result_string );
	
	my $ws_name = $result_href->{workspaces}[0]{name};
	S_wr2log( "Checking changes in stream '$stream' in workspace '$ws_name' ...\n" );
	my $components_aref = $result_href->{workspaces}[0]{components};
	 if (scalar @{$components_aref} == 0)  {
		S_wr2log ("no components found for stream '$stream'.."); 
		return 0;
	} 
	
	foreach my $component_href ( @$components_aref ) {
	   Recurse_component($component_href);
	}
	
	my $return_component_info_href;	
	foreach my $key (keys %{$componentsInfo_href}) {
		$return_component_info_href->{$key}{name} = $key;
		$return_component_info_href->{$key}{uuid} = $componentsInfo_href->{$key};
	}
	undef $componentsInfo_href;
	return $return_component_info_href;
}

sub generate_load_rule_file{
	my @args = @_;
	my $src_stream = shift @args;  
	my $loadRuleFile = shift @args; 
	my $config_component = shift @args;  	
	
	unlink $loadRuleFile; # delete the load rule file before creating it.
	
	S_wr2log(Dumper(get_component_desc_from_stream($src_stream )));
	my $componets_info_href = get_component_desc_from_stream($src_stream );
	
	
my $HeaderTxt = << 'HEADER';
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<scm:sourceControlLoadRule version="1" xmlns:scm="http://com.ibm.team.scm">
HEADER
	
	
	write_file($loadRuleFile, {append => 1}, $HeaderTxt);
	
	my $username = getlogin; 
	my $cfComp_shname = $1 if ($config_component =~ /\.(\w+)$/);
	foreach my $component ( keys %{$componets_info_href}) {
		my $compName = $componets_info_href->{$component}{name};
		my $compUuid = $componets_info_href->{$component}{uuid};
		
		my $comp_shname = $1 if ($compName =~ /\.(\w+)$/);

		# config component
		my $path_prefix = "/$username";
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix) 					 if ($compName eq $config_component );
		
		# Engine
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname") if ($compName =~ /\.Engine$/ );
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname"."/Engine") if ($compName =~ /\.Engine\./ );
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname"."/Engine") if ($compName =~ /\.Tools$/ );
		
		# TCS
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname") if ($compName =~ /\.TCs$/ );
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname"."/TCs") if ($compName =~ /\.TCs\./ );

		# Test area
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname") if ($compName =~ /TestArea$/ );
		writeloadRuleTxt( $loadRuleFile, $compName, $compUuid,   $path_prefix."/$cfComp_shname"."/TestArea") if ($compName =~ /\.TestArea\./ );
	
	}
	
my $footerTxt = << 'FOOTER';
</scm:sourceControlLoadRule>
FOOTER
	write_file($loadRuleFile, {append => 1}, $footerTxt);
	return 1;
}

sub writeloadRuleTxt {

	my @args = @_;
	my $loadRuleFile = shift @args;  
	my $compfullqualifiedName = shift @args;  
	my $comp_uuid = shift @args; 	
	my $path_prefix = shift @args; 	

	my $compAltName = $1 if $compfullqualifiedName=~/\.(\w+)$/ ;

my $formatTxt = << "XMLFormat";
    <itemLoadRule alternateName="$compAltName">
        <component itemId="$comp_uuid"/>
        <!-- <component name="$compfullqualifiedName" /> -->
        <item repositoryPath="/"/>
        <sandboxRelativePath pathPrefix="$path_prefix"/>
    </itemLoadRule>
XMLFormat

	write_file($loadRuleFile, {append => 1}, $formatTxt);
}





sub S_wr2log {
    my @args = @_;

    my $text         = shift @args;
    my $loggingLevel = shift @args;

    $text = $text . "\n";
    my $date_time = S_get_date_extension();

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    $loggingLevel = 4 if not defined $loggingLevel;
    return if ( $loggingLevel == 5 and $FLAG_EN_DEBUG_PRINT_OUTS == 0 );    # no logging to file.

    my $loggingLevels_href = {
        1 => 'CRITICAL',
        2 => 'ERROR',
        3 => 'WARNING',
        4 => 'INFO',
        5 => 'CMD',
    };
	
	my $txt_wr_log_file  = "$callingFunction: $text";
    write_file( $log_File, { append => 1 }, "[$date_time] [$loggingLevels_href->{$loggingLevel}]:" . $txt_wr_log_file   );
    print $txt_wr_log_file  ;
    return 1;
}

sub S_get_date_extension {
    my $given_time = shift;

    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst );

    if ( defined $given_time ) {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($given_time);
    }
    else {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime( time() );
    }

    return sprintf( "%04d%02d%02d_%02d%02d%02d", $year + 1900, $mon + 1, $mday, $hour, $min, $sec );
}

1;

