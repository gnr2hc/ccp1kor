#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################
use strict;
use warnings;
use Getopt::Long;

my ($template,$testlist,$pick,%found,@content);
%found=();
GetOptions('template=s' =>\$template, 'testlist=s' =>\$testlist, 'pick=s' =>\$pick);

die "Template2TL.pl --template [file] --testlist [file] --pick [number]" unless ($template and $testlist and $pick);

# create test list based on template by picking random entries from sections
print("open $template\n");
open(TEMPLATE, $template) or die("Could not open template file.");
my $section;
@content = ();

push(@content,"# found outside a section:\n");

while(my $line = <TEMPLATE>) {
	if ($line =~ m/^\s*#>>>\s*(.+)/) {
		$section = $1;
#		print("found section $section\n");
		next;
	}
	elsif ($line =~ m/^\s*#<<</) {
#		print("closing section $section\n");
		$section = '';
		next;
	}
	elsif ($line =~ m/^\s*$/) {
#		print("skipping empty line\n");
		next;
	}
	elsif ($line =~ m/^\s*#/) {
#		print("skipping commented line\n");
		next;
	}
	elsif ($section){
		push(@{$found{$section}},$line);
	}
	else{
		# take everything outside a section
	    push(@content,$line);
	}
}
close(TEMPLATE);
push(@content,"\n");
    
foreach my $sec (sort keys %found){
	my $size = scalar(@{$found{$sec}});
    push(@content,"# picked from section <$sec>:\n");
	foreach (1..$pick){
		my $randomNO = rand( $size-1 );
	    my $entry = $found{$sec}[$randomNO];
#	    print "$entry was picked from <$sec>\n\n";
	    push(@content,$entry);
	}
    push(@content,"\n");
}

print("create $testlist\n");
open(TL, "> $testlist") or die("Could not open test list file.");
print TL @content;
close(TL);


=head1 usage

create test list based on template by picking random entries from sections

	Template should look like
	#>>> switch open
	TC_FLT_Active.PADS1_open
	TC_FLT_Active.BLRC_open
	#<<<
	
	#>>> switch Ubat
	TC_FLT_Active.PADS1_Bat
	TC_FLT_Active.BLRC_Bat
	TC_FLT_Active.BLFP_Bat
	TC_FLT_Active.BLRD_Bat
	#<<<

	sections with same name will be merged
	entries outside section will be taken always
	empty or commented lines will be skipped

 CLI: Template2TL.pl --template [file] --testlist [file] --pick [number]
 
 e.g. Template2TL.pl --template=C:/TurboLift/AB12_CI/Testlists/TLT_FLT_Active.txt --testlist=C:/TurboLift/AB12_CI/Testlists/TL_FLT_Active.txt  --pick=1

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
