=head1 NAME
coverage_per_function.pl - calculate test coverage for each TurboLIFT function

=head1 SYNOPSIS

finder_LIFT_functions.pl

=head1 VERSION

$Revision: 1.1 $

=head1 DESCRIPTION

coverage_per_function.pl is a tool that calculates the test coverage for each TurboLIFT function from cover_db data.
Precondition for successful usage of the tool is that TurboLIFT engine tests (*.t) have been run and the cover command has
created a coverage database in the folder cover_db.
coverage_per_function.pl asks for the cover_db folder and finds all html files with statement coverage information. The html files are read
and statement coverage information for each TurboLIFT function is extracted. The results (TurboLIFT module, function, statement coverage value) 
are written into the file LIFT_function_coverage.csv.

=cut

use strict;
use File::Find;
use POSIX qw/strftime strtod setlocale LC_NUMERIC/;
use Tk;
use Getopt::Long;

my $searchPath;
GetOptions( "inputdir=s" => \$searchPath, );


if( not defined $searchPath ) {
    my $mw = tkinit();

    #my $searchPath = 'C:\Users\phc2si\Documents\LIFT\TSG4\Engine\test\cover_db';
    $searchPath = $mw->chooseDirectory(-title => 'Choose a cover_db folder');

}

my %function_stats;
find(\&Stats4Module, ($searchPath) );

setlocale LC_NUMERIC, "";

open( OUT, ">LIFT_function_coverage.csv"  ) or die $!;
print OUT strftime('%Y-%m-%d',localtime)."\n";
print OUT "module;function;stmt\n";

foreach my $module (sort keys %function_stats){
	foreach my $function (sort keys %{$function_stats{$module}}){
		my $covered = $function_stats{$module}{$function}{'stmt_yes'};
		my $notCovered = $function_stats{$module}{$function}{'stmt_no'};
		if( $covered + $notCovered != 0 ){
			$function_stats{$module}{$function}{'stmt_coverage'} = $covered/($covered + $notCovered);			
		}
		else{
			$function_stats{$module}{$function}{'stmt_coverage'} = 'n/a';
		}
		print OUT "$module;$function;$function_stats{$module}{$function}{'stmt_coverage'}\n";
		$function_stats{$module}{'_SUMMARY'}{'stmt_yes'} += $covered;
		$function_stats{$module}{'_SUMMARY'}{'stmt_no'} += $notCovered;
	}

	my $covered = $function_stats{$module}{'_SUMMARY'}{'stmt_yes'};
	my $notCovered = $function_stats{$module}{'_SUMMARY'}{'stmt_no'};
	if( $covered + $notCovered != 0 ){
		$function_stats{$module}{'_SUMMARY'}{'stmt_coverage'} = $covered/($covered + $notCovered);
	}
	else{
		$function_stats{$module}{'_SUMMARY'}{'stmt_coverage'} = 'n/a';
	}
	print OUT "$module;_SUMMARY;$function_stats{$module}{'_SUMMARY'}{'stmt_coverage'}\n";
}

close OUT;


my $dummy;


sub Stats4Module {
	my $fileName = $File::Find::name;
	#my $fileName = 'C:\Users\phc2si\Documents\LIFT\TSG4\Engine\test\cover_db\C--Users-phc2si-Documents-LIFT-TSG4-Engine-modules-LIFT_general-pm.html';

	return unless( $fileName =~ /pm\.html$/ );
	
	open( IN, '<', $fileName) or die "cannot open input file $fileName : $!";
	my @lines = <IN>;
	close IN;
	
	my $module = 'UNKNOWN';
	my $function = 'NOFUNC';
	
	foreach my $line (@lines){
		if( $line =~ m{(\w+).pm</title>} ){
			$module = $1;
		}
		if( $line =~ m{<td></td><td></td><td></td><td></td><td></td><td></td><td class="s">\s*sub\s(\w+)\s*\{?</td>} ){
			$function = $1;
			$function_stats{$module}{$function}{'stmt_yes'} = 0;
			$function_stats{$module}{$function}{'stmt_no'} = 0;
		}
		while( $line =~ m{<td class="h">\d+</td><td><div class="c(\d)">(.*)} ){
			if( $1 == 0 ){
				$function_stats{$module}{$function}{'stmt_no'}++;
			}
			else{
				$function_stats{$module}{$function}{'stmt_yes'}++;
			}
			$line = $2;
		}
	}
}


