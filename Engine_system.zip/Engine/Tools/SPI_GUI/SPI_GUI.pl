#!usr\bin\perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################

my $addpath;
use File::Basename;
BEGIN
{
    use Config;
    use File::Spec;
	my $LIFT_exec_path='./../..';
    $addpath = "$LIFT_exec_path/modules/Device_layer/IDXSPI";
    $addpath =~ s/\//\\/g; # replace all slashes with backslahes
    my $win32 = $addpath . "\\Win32";       #perl 5.12, 32-bit DLL directory
	if($] =~ m/5.012/i) {  #if Perl version is 5.12
		unshift @INC, ($addpath, $win32);       #Include IDEFIX.pm from Root directory, Load IDEFIX.dll from "Win32"
		$ENV{PATH} = $win32 . ";$ENV{PATH}";    #Load IdefixInterface.dll from "Win32"
	}
}

#Add libraries
use strict;
use IDXSPI;
use Tk;
use Tk::BrowseEntry;


my $Toolversion = "SPI_GUI ($VERSION)";      # Tool version number
#Variables
my ($main, $display_txt,$count);
my ($Config_Box,$Export_Box,$EE_Box,$LA_Box,$Btn_Box,$Start_Btn,$Stop_Btn);
my ($CSVfile,$BINfile,$LAfile,$SADfile,$EEfile,$Help_String);
my ($Enable_Frm,$Bus_Frm,$LA_Frm,$bin_Frm,$Export_Frm,$EEfile1_Frm,$EEfile2_Frm,$EEfile3_Frm,$LAfile1_Frm,$LAfile2_Frm);
my (@Enable_bit,@Bus_bit,@LA_bit,@Export_bit);

my ($status);

@Enable_bit=(0)x13;
@Bus_bit=(0)x13;
@LA_bit=(0)x8;
@Export_bit=(0)x16;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 500, 600 );

# create title in window 'main'
$main -> title ( "SPI_GUI $VERSION" );

$display_txt = "SPI_GUI $VERSION";

# create frames in window 'main'
$Config_Box = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );
$Btn_Box = $main -> Frame() -> pack( "-padx" => 5,"-pady" => 10 );
$Export_Box = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );
$EE_Box = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );
$LA_Box = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );

#create Frame Elements
$Enable_Frm = $Config_Box -> Frame() -> pack( "-pady" =>  5);
$Bus_Frm = $Config_Box -> Frame() -> pack( "-pady" => 5 );
$LA_Frm = $Config_Box -> Frame() -> pack( "-pady" => 5 );
$bin_Frm = $Config_Box -> Frame() -> pack( "-pady" => 5 );

$Export_Frm = $Export_Box -> Frame() -> pack( "-pady" =>  5);
$EEfile1_Frm = $EE_Box -> Frame() -> pack( "-pady" =>  5);
$EEfile2_Frm = $EE_Box -> Frame() -> pack( "-pady" =>  5);
$EEfile3_Frm = $EE_Box -> Frame() -> pack( "-pady" =>  5);

$LAfile1_Frm = $LA_Box -> Frame() -> pack( "-pady" =>  5);
$LAfile2_Frm = $LA_Box -> Frame() -> pack( "-pady" =>  5);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );


######## Config_Box


# create label 
$Enable_Frm -> Label( "-text" => "recording mask: ",)-> pack( "-side" => 'left', "-pady" => 5 );
for ($count=0;$count<=12;$count++){

    $Enable_Frm -> Checkbutton  (
      "-text"     => "CS$count",
      "-variable" => \$Enable_bit[$count],
      )
    -> pack( "-side" => 'left', );

}

# create label 
$Bus_Frm -> Label( "-text" => "bus mask (checked = SPI2): ",)-> pack( "-side" => 'left', "-pady" => 5 );
for ($count=0;$count<=12;$count++){

    $Bus_Frm -> Checkbutton  (
      "-text"     => "CS$count",
      "-variable" => \$Bus_bit[$count],
      )
    -> pack( "-side" => 'left', );

}

# create label 
$LA_Frm -> Label( "-text" => "LA mask: ",)-> pack( "-side" => 'left', "-pady" => 5 );
for ($count=0;$count<=7;$count++){

    $LA_Frm -> Checkbutton  (
      "-text"     => "LA$count",
      "-variable" => \$LA_bit[$count],
      )
    -> pack( "-side" => 'left', );

}

# create label 
$bin_Frm -> Label( "-text" => "store dump to ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );

# create entry 
$bin_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$BINfile, 
            )
-> pack( "-side" => 'left', );

# create 'browse save file' button
$bin_Frm -> Button
(
"-text" => "Browse save file",
"-command" => sub
  {      
        #store old variable value
        $Help_String =  $BINfile;
      
      # browse for file
      $BINfile = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.bin'],
          ["All files", '.*']
          ],
        "-title"      => "select file to save values",
        "-defaultextension" => 'sat',
        );
      # if a file was chosen
      if ( $BINfile )
        {
        print "\n $BINfile was chosen\n";
        }
      else
        {
          #restore old variable value
         $BINfile = $Help_String;
          print "no filename!\n";
       }
  }
)
-> pack ("-side" => 'left',"-padx" => 5,);


# create 'use config' button
$Config_Box -> Button
  (
  "-text" => "use config",
  "-activebackground" => "green",
  "-command" => sub
    { # execute when button is pressed  

        my $CSEnabled = oct("0b".join('',reverse(@Enable_bit)));
        my $Bus0orBus1 = oct("0b".join('',reverse(@Bus_bit)));
        my $LAMask = oct("0b".join('',reverse(@LA_bit)));
        
        if ($CSEnabled>0 and $BINfile){

        $display_txt = "use config: ixs_SetSPIConfiguration( $CSEnabled, 0, IDM_CS12, $Bus0orBus1, $LAMask)";
        w2log("ixs_SetSPIConfiguration( $CSEnabled, 0, IDM_CS12, $Bus0orBus1, $LAMask)\n");
        $status = ixs_SetSPIConfiguration( $CSEnabled, 0, IDM_CS12, $Bus0orBus1, $LAMask);
        w2log("($status) ixs_SetSPIConfiguration\n");

        $Start_Btn-> configure("-state" => "normal");
        $Stop_Btn-> configure("-state" => "normal");
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please define config details first!\nat least one recording CS and save file name"
                );
        }

    }
  )
-> pack ("-side" => 'right');




######## Btn_Box

# create 'start' button
$Start_Btn = $Btn_Box -> Button
  (
  "-text" => "start",
  "-state" => "disabled",
  "-activebackground" => "green",
  "-command" => sub
    { # execute when button is pressed  
        $display_txt = "start: ixs_StartMeasurementThread($BINfile)";
        $status = ixs_StartMeasurementThread($BINfile);
        w2log("($status) ixs_StartMeasurementThread $BINfile\n");
        checkError($status);
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-padx" => 50);

# create 'stop' button
$Stop_Btn = $Btn_Box -> Button
  (
  "-text" => "stop",
  "-state" => "disabled",
  "-activebackground" => "orange",
  "-command" => sub
    { # execute when button is pressed  
        $display_txt = "stop: ixs_StopMeasurementThread for $BINfile";
        $status = ixs_StopMeasurementThread();
        w2log("($status) ixs_StopMeasurementThread\n");
        checkError($status);
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-padx" => 50);

# create 'exit' button
$Btn_Box -> Button
  (
  "-text" => "E X I T",
  #"-background" => "red",
  "-activebackground" => "red",
  "-command" => sub
    {$main->destroy;}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-padx" => 70);


######## Export_Box


# create label 
$Export_Frm -> Label( "-text" => "export mask: ",)-> pack( "-side" => 'left', "-pady" => 5 );
for ($count=0;$count<=15;$count++){

    $Export_Frm -> Checkbutton  (
      "-text"     => "CS$count",
      "-variable" => \$Export_bit[$count],
      )
    -> pack( "-side" => 'left', );

}

# create label 
$Export_Box -> Label( "-text" => "open dump from ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );



# create entry 
$Export_Box -> Entry(
            "-width" => 50,
            "-textvariable" => \$BINfile, 
            )
-> pack( "-side" => 'left', );


# create 'browse file' button
$Export_Box -> Button
(
"-text" => "Browse open file",
"-command" => sub
  {
        #store old variable value
        $Help_String =  $BINfile;
        
      # browse for file
      $BINfile = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.bin'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $BINfile )
        {
        print "\n $BINfile was chosen\n";
      }
      else
      {
            #restore old variable value
            $BINfile = $Help_String;
            print "no filename!\n";
      }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# create label 
$Export_Box -> Label( "-text" => "store CSV to ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );

# create entry 
$Export_Box -> Entry(
            "-width" => 50,
            "-textvariable" => \$CSVfile, 
            )
-> pack( "-side" => 'left', );

# create 'browse save file' button
$Export_Box -> Button
(
"-text" => "Browse save file",
"-command" => sub
  {      
        #store old variable value
        $Help_String =  $CSVfile;
      
      # browse for file
      $CSVfile = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.csv'],
          ["All files", '.*']
          ],
        "-title"      => "select file to save values",
        "-defaultextension" => 'sat',
        );
      # if a file was chosen
      if ( $CSVfile )
        {
        print "\n $CSVfile was chosen\n";
        }
      else
        {
          #restore old variable value
         $CSVfile = $Help_String;
          print "no filename!\n";
       }
  }
)
-> pack ("-side" => 'left',"-padx" => 5,);


# create  button
$Export_Box -> Button
  (
  "-text" => "export CS",
  "-activebackground" => "green",
  "-command" => sub
    { # execute when button is pressed  
        my $CSExport = oct("0b".join('',reverse(@Export_bit)));
        
        if ($CSExport>0 and $BINfile and $CSVfile){

        $display_txt = "export CS: ixs_ExportSelectedCS($CSExport,$BINfile,$CSVfile)";
        w2log("ixs_ExportSelectedCS($CSExport,$BINfile,$CSVfile)\n");
        $status = ixs_ExportSelectedCS($CSExport,$BINfile,$CSVfile);
        w2log("($status) ixs_ExportSelectedCS\n");

        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please define export details first!\nat least one export CS and save file name"
                );
        }

    }
  )
-> pack ("-side" => 'right');


######## EE_Box



# create label 
$EEfile1_Frm -> Label( "-text" => "open CSV from ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );



# create entry 
$EEfile1_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$CSVfile, 
            )
-> pack( "-side" => 'left', );


# create 'browse file' button
$EEfile1_Frm -> Button
(
"-text" => "Browse open file",
"-command" => sub
  {
        #store old variable value
        $Help_String =  $CSVfile;
        
      # browse for file
      $CSVfile = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.csv'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $CSVfile )
        {
        print "\n $CSVfile was chosen\n";
      }
      else
      {
            #restore old variable value
            $CSVfile = $Help_String;
            print "no filename!\n";
      }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);

# create label 
$EEfile2_Frm -> Label( "-text" => "open SAD from ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );



# create entry 
$EEfile2_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$SADfile, 
            )
-> pack( "-side" => 'left', );


# create 'browse file' button
$EEfile2_Frm -> Button
(
"-text" => "Browse open file",
"-command" => sub
  {
        #store old variable value
        $Help_String =  $SADfile;
        
      # browse for file
      $SADfile = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.sad'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $SADfile )
        {
        print "\n $SADfile was chosen\n";
      }
      else
      {
            #restore old variable value
            $SADfile = $Help_String;
            print "no filename!\n";
      }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# create label 
$EEfile3_Frm -> Label( "-text" => "store EE to ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );

# create entry 
$EEfile3_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$EEfile, 
            )
-> pack( "-side" => 'left', );

# create 'browse save file' button
$EEfile3_Frm -> Button
(
"-text" => "Browse save file",
"-command" => sub
  {      
        #store old variable value
        $Help_String =  $EEfile;
      
      # browse for file
      $EEfile = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "select file to save values",
        "-defaultextension" => 'sat',
        );
      # if a file was chosen
      if ( $EEfile )
        {
        print "\n $EEfile was chosen\n";
        }
      else
        {
          #restore old variable value
         $EEfile = $Help_String;
          print "no filename!\n";
       }
  }
)
-> pack ("-side" => 'left',"-padx" => 5,);


# create  button
$EE_Box -> Button
  (
  "-text" => "decode EE",
  "-activebackground" => "green",
  "-command" => sub
    { # execute when button is pressed  
        
        if ($EEfile and $CSVfile){

        $display_txt = "decode EE: xs_decodeEEPROM($CSVfile,$EEfile,$SADfile)";
        w2log("ixs_decodeEEPROM($CSVfile,$EEfile,$SADfile)\n");
        $status = ixs_decodeEEPROM($CSVfile,$EEfile,$SADfile);
        w2log("($status) ixs_decodeEEPROM\n");

        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please define EE details first!\nat least CSV and save file name"
                );
        }


    }
  )
-> pack ("-side" => 'right');


######## LA_Box


# create label 
$LAfile1_Frm -> Label( "-text" => "open CSV from ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );



# create entry 
$LAfile1_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$CSVfile, 
            )
-> pack( "-side" => 'left', );


# create 'browse file' button
$LAfile1_Frm -> Button
(
"-text" => "Browse open file",
"-command" => sub
  {
        #store old variable value
        $Help_String =  $CSVfile;
        
      # browse for file
      $CSVfile = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.csv'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $CSVfile )
        {
        print "\n $CSVfile was chosen\n";
      }
      else
      {
            #restore old variable value
            $CSVfile = $Help_String;
            print "no filename!\n";
      }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# create label 
$LAfile2_Frm -> Label( "-text" => "store LA to ", 
         )
-> pack( "-side" => 'left', "-pady" => 5 );

# create entry 
$LAfile2_Frm -> Entry(
            "-width" => 50,
            "-textvariable" => \$LAfile, 
            )
-> pack( "-side" => 'left', );

# create 'browse save file' button
$LAfile2_Frm -> Button
(
"-text" => "Browse save file",
"-command" => sub
  {      
        #store old variable value
        $Help_String =  $LAfile;
      
      # browse for file
      $LAfile = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["curve files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "select file to save values",
        "-defaultextension" => 'sat',
        );
      # if a file was chosen
      if ( $LAfile )
        {
        print "\n $LAfile was chosen\n";
        }
      else
        {
          #restore old variable value
         $LAfile = $Help_String;
          print "no filename!\n";
       }
  }
)
-> pack ("-side" => 'left',"-padx" => 5,);


# create  button
$LA_Box -> Button
  (
  "-text" => "export LA",
  "-activebackground" => "green",
  "-command" => sub
    { # execute when button is pressed  
        if ($LAfile and $CSVfile){

        $display_txt = "decode LA: ixs_decodeLA($CSVfile,$LAfile)";
        w2log("ixs_decodeLA($CSVfile,$LAfile)\n");
        $status = ixs_decodeLA($CSVfile,$LAfile);
        w2log("($status) ixs_decodeLA\n");

        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please define LA details first!\nat least CSV and save file name"
                );
        }

    }
  )
-> pack ("-side" => 'right');


#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">SPI_GUI_log.txt" ) or die "Couldn't open SPI_GUI_log.txt : $@";

w2log("######################################################################\n");
w2log("### IDEfix SPI monitor GUI ###\n"); 
w2log("######################################################################\n");
w2log("$Toolversion logfile\n");

init_Idefix();
MainLoop;

$status = ixs_End();
w2log("($status) ixs_End\n");


w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++


sub init_Idefix{
    my ($ret,$version);
    $ret = ixs_getPMrevision();
    w2log("PM $ret\n");
    $ret = ixs_getXSrevision();
    w2log("XS $ret\n");
    $ret = ixs_getCWrevision();
    w2log("CW $ret\n");

    $status = ixs_Start();
    w2log("($status) ixs_Start\n");
    checkError($status);

    $status = ixs_IniUSB();
    w2log("($status) ixs_IniUSB\n");
    checkError($status);

    ($status,$version) = ixs_GetDescription();
    w2log("($status) $version\n");
    $display_txt="found IDEfix $version";
    checkError($status);

    ($status, $version) = ixs_GetFirmware();
    w2log("($status) ixs_GetFirmware: $version\n");
    checkError($status);

    ($status, $version) = ixs_GetVersion();
    w2log("($status) ixs_GetVersion: $version\n");

}


sub checkError{
    my $stat = shift;
    if ($stat<0){
        $display_txt ="ERROR:".ixs_GetErrortext($stat);
        w2log( $display_txt."\n");
        
    }
    
}


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}

=head1 usage

    the tool is designed to support workflow from top to bottom:
    1. configure measurement (which chip selects to monitor, dumpfile name)
    2. start and stop measurement
    3. export several chip selects as CSV file
    4. decode EEPROM communication from CSV file
    5. export logic analyzer channels form CSV file
    
    each action is performed by pressing the corrwsponding button
    a logfile will be written containing all actions.
    use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, IDEfix manual.

=cut
