#!perl -w

#****************************************************************************************************
#                                                                           						*
# Copyright (c) 2013 Robert Bosch GmbH, Germany                             						*
#               All rights reserved                                         						*
#                                                                           						*
#****************************************************************************************************
# $Revision : 1.0 $        																			*
#                     																				*
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd; 
use Tk::LabFrame;

my $color = 0;
if(eval{require Win32::Console::ANSI}){
	$color = 1;
}
use Term::ANSIColor;
use Term::ANSIColor qw(:constants);

my ($File_Name_Path,$input_File_Name);

sub Creatre_About_Window(){
	my $mw = MainWindow->new("-background" => "#888888");
	$mw->minsize(100,25);
	$mw->title("Help");

	#Making a text area
	my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

	$txt->delete('1.0','end');
		$txt->insert('end','
	#	
	#	MKS $Revision : 1.0 $  
	#
	#	DESCRIPTION:                               
	#	This tool will generate an EDID mapping file from an exported excel sheet of EDID List SRS              
	#
	#	FOLLOW THESE STEPS:
	#	1. Export Rqmts to excel sheet: EDID list SRS->File->Export->Microsoft Office->Excel..
	#	2. Check for these mandatory columns in excel sheet
	#		EDID 
	#		Data element 
	#		Data Length (Byte)
	#		Data samples
	#		Unit
	#		Factor (Data)
	#		Offset (Data)
	#		Data value "invalid data"
	#		Data value "data not available"
	#		Data value to convert
	#
	#	3. Add the missing columns/values if not present                                      
	#  
	#	REMARKS:                                    
	#	1. Perl Version 5.12 32 bit(installed using Peacy package) is required
	#	2. Perl TK is to be installed                
	#                                       
	'
	);

}
my ($main,$end_frame,$path_frame,$entry);
my ($Designation_path,@File_Select_Arr,$status,);
my ($EDID_Start_Byte_From_Panel,$EDR_Service_IDs,$Diag_Request_ID_From_Panel,$Diag_Response_ID_From_Panel);
my  @EDR_Services_DID_Array ;
my $DID_Value;
# Default Designation Path
$Designation_path='C:';
my  $TK_ERROR_INDICATION_FLAG_i=0;
my $project_name ="";
$main = MainWindow->new("-background" => "#888888");

# Size to the TK window 
$main->minsize(450,100);

$main->title("Device Mapping file Generator ");
# Get the current path 
my $pwd = cwd();
#print "$pwd","\n";
my @path_structure;
@path_structure =split(/\//,$pwd); 
# Remove the last Folder 
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path=join("\\",@path_structure);
print "File_With_Path =$File_With_Path","\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder
  

#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#The Main Buttons
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);


## File Menu ##
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );
 
#******************************************************************************************** 
$help -> command(-label =>"ReadMe",  -command=>sub {Creatre_About_Window()});

$main->Label(
    -text=>'Device Mapping file Generator',
    -font=>'{Segoe UI} 15 bold',
    -background => '#888888',
    -foreground => 'white',
    -height=>'001')->pack(-side=>'top',-pady=>'003');




 my $labeled_frame1   = $main->Frame(-borderwidth => 2, 
                                 -relief => 'groove',
                                 -background => "#888888",
                                 )->pack(-side => "top",-padx=>'150',-anchor=>'nw');


#my $shot = $main->Photo(-file => "$File_With_Path\\logo\\AUDI.gif");
#$main->Label(-image => $shot)->pack(-side => 'top');
 $main->Label(
            -text=>'NOTE: Select the ProjectConst file which contains the MLC device details',
            -font=>'{Segoe UI Semibold} 8 bold',
            -background => "#888888",
            -foreground => "white",
             )->pack(-side=>'left',-padx=>'75',-pady=>'02',-side=>'top',-anchor=>'w');

$path_frame = $main->Frame("-background" => "#888888")->pack(-pady=>'0',-padx=>'05' );

$path_frame->Label(
        -text=>'  File  :',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI bold} 15 ')->pack(-side=>'left', -pady=>'0',-padx=>'05');

$status= ' Not Started ';
$entry = $path_frame->Entry(
        -width=>'50',
        -textvariable=>\$File_Name_Path,
        -background => "white",
        -foreground  => "black",
        )->pack(-side=>'left',
                -pady=>'0');

                $path_frame->Button(
                        -text=>"Browse",
                        -width=>'8',
                        -relief => 'groove',
                        -background => "#333366",
                        -foreground  => "white",
                         -font=>'{Segoe UI Semibold} 12 ',
                        -command=>sub
                        {
                            $File_Name_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["pm files", ['.pm'] ],
											["pm files", ['.pm'] ],
                                       ],
                                        -title=>"Choose the pm file ",
                        );
                
                            if($File_Name_Path)
                            {
                               @File_Select_Arr=split(/\[/, $File_Name_Path);
                               $input_File_Name=$File_Select_Arr[-1];
                               print "File Name =$input_File_Name";
                               $Designation_path = dirname($File_Name_Path); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side=>'left',-pady=>'0',-padx=>'05',-pady=>'02');

	
$end_frame = $main->Frame("-background" => "#888888")->pack(-ipadx=>'10', -padx=>'2');
$end_frame->Button(
        -text=>'Exit',
        -width=>'8',
        -font=>'{Segoe UI Semibold} 12 ',
         -background => "Red4",
         -foreground => "white",
          -relief => 'groove',
        -command=>[$main=>'destroy']
        )->pack(-pady=> 10,  -side=>'right');


$end_frame->Button(
        -text=>'Generate',
        -width=>'8',
        -font=>'{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief => 'groove',
        -background => "ForestGreen",
        -command=>sub {Generate_File()}
        )->pack(-pady=> 10, -padx=> 10,  -side=>'right');   
        
 # create label in window 'main'
 $main -> Label(
        -textvariable => \$status, #reference to display the status
         -font=>'{Segoe UI Semibold} 12 bold',
        -background  => "#888888",
        -foreground  => "white",
        )-> pack( "-pady" => 6,-side=>'top' );
        
MainLoop;

 
  
sub Generate_File(){   


    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI   
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if(!$input_File_Name){
        $main->messageBox(
                           '-icon'    => "error", #qw/error info question warning/
                           '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                           '-title'   => 'Attention',
                           '-title'   => 'Attention',
                           '-message' => "Select the *.xls files !"
                          );

		$TK_ERROR_INDICATION_FLAG_i=1;
		$main->update();
    }
	else{
		
		if(defined $input_File_Name and $input_File_Name =~ m/ProjectConst|Mapping/i){
			#do nothing, File is correct!
		}
		else{
			$status= "!!ERROR: Wrong file loaded!!\nPlease load the ProjectConst file which contains the MLC device mappings";
			$main->update();
			
			die RED, "\n\n!!!!ERROR: Wrong file loaded!!!!\nPlease load the ProjectConst file which contains the MLC device mappings \n\n", RESET;
		}
	
		$status= ' Not Started ';
		$main->update();
			   
		#SheetName of the Exported Decoder sheet
		my %input_data_Sheet = (
								'in_Data'=>"Sheet1",
								);

		my (@switches,@squibs, @lamps, @FSswitches);
		my $errorcount = 0;
		
		my %devicelabel = ('BLFD' => 'BeltLockFrontDriver',
							'BBFD' => 'BeltLockFrontDriver',
							'BLFP' => 'BeltLockFrontPassenger',
							'BBFP' => 'BeltLockFrontPassenger',
							'BLR1D' => 'BeltLockFrontDriver',
							'BLR1P' => 'BeltLockFrontPassenger',
							'BL2RD' => 'BeltLock2ndRowDriver',
							'BL2RC' => 'BeltLock2ndRowCenter',
							'BL2RP' => 'BeltLock2ndRowPassenger',
							'BLR2D' => 'BeltLock2ndRowDriver',
							'BLR2C' => 'BeltLock2ndRowCenter',
							'BLR2P' => 'BeltLock2ndRowPassenger',
							'BL3RD' => 'BeltLock3rdRowDriver',
							'BL3RP' => 'BeltLock3rdRowPassenger',
							'BLR3D' => 'BeltLock3rdRowDriver',
							'BLR3P' => 'BeltLock3rdRowPassenger',
							'DSPOS' => 'SeatTrackPositionSwitchDriver',
							'PSPOS' => 'SeatTrackPositionSwitchPassenger',
							'SPSD' => 'SeatTrackPositionSwitchDriver',
							'SPSP' => 'SeatTrackPositionSwitchPassenger',
							'SPSR1D' => 'SeatTrackPositionSwitchDriver',
							'SPSR1P' => 'SeatTrackPositionSwitchPassenger',
							'PADS' => 'PassengerAirbagDeactivationSwitch');
		
		require $input_File_Name;
		my $MLChash = $LIFT_PROJECT::Defaults -> {'MLC'};
		my $TSG4hash = $LIFT_PROJECT::Defaults -> {'TSG4'};
		
		unless (defined $MLChash){
			die RED, "\n\n!!!!ERROR: Wrong file loaded!!!!\nPlease load the ProjectConst file which contains an 'MLC' section\n\n", RESET;
		}
		
		
		open(OUTFILE, ">Mapping_DEVICE.pm") || die("Cannot find file to write!");
		open(ERRORLOG, ">ErrorLog.txt") || die("Cannot find file to write!");
		
		print OUTFILE "#### This file is generated by the Device mapping creator tool #### \n";
		print OUTFILE "#### Can be edited manually! #### \n\n";
		
		print OUTFILE "package LIFT_PROJECT;\n\n";
		
		print OUTFILE "########################################################## \n";
		print OUTFILE '$VERSION = q$Revision: 1.3 $;';
		print OUTFILE "\n";
		print OUTFILE "\n";
		print OUTFILE "########################################################## \n";
		print OUTFILE "\n\n";
		
		print OUTFILE '$Defaults->{"MLC"}= {';
		print OUTFILE "\n";
		
		####################General Section######################
		print OUTFILE "\t\t'General' => { \n";
		unless (defined $MLChash->{'General'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'General' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$MLChash->{'General'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$MLChash->{'General'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		
		####################POWER Supply Section#################
		print OUTFILE "\t\t'POWER_SUPPLY_LINES' => { \n";
		unless (defined $MLChash->{'POWER_SUPPLY_LINES'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'POWER_SUPPLY_LINES' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$MLChash->{'POWER_SUPPLY_LINES'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$MLChash->{'POWER_SUPPLY_LINES'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################SQUIB Section########################
		print OUTFILE "\t\t'SQUIBS' => { \n";
		unless (defined $MLChash->{'SQUIBS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'SQUIBS' section is not found in MLC hash\n";
		}
		foreach my $num( 1..40) {
			my $dev = "SQ$num"."_Name";
			my $squib = $MLChash->{'SQUIBS'}{$dev};
			push (@squibs, $squib) if defined $squib;
			print OUTFILE "\t\t\t\t\t'$dev' => '$squib',\n" if defined $squib;	
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		
		####################SWITCH Section#######################
		print OUTFILE "\t\t'SWITCHES' => { \n";
		unless (defined $MLChash->{'SWITCHES'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'SWITCHES' section is not found in MLC hash\n";
		}
		foreach my $num( 1..20) {
			my $dev = "SW$num"."_Name";
			my $switch = $MLChash->{'SWITCHES'}{$dev};
			push (@switches, $switch) if defined $switch;
			print OUTFILE "\t\t\t\t\t'$dev' => '$switch',\n" if defined $switch;	
		}
		print OUTFILE "\n";
		foreach my $switch (@switches){
			my $switch_open = "$switch"."_OPEN";
			my $switch_closed = "$switch"."_CLOSED";
			my $switch_open_state = $MLChash->{'SWITCHES'}{$switch_open};
			my $switch_closed_state = $MLChash->{'SWITCHES'}{$switch_closed};
			unless(defined $switch_open_state and $switch_open_state ne ''){
				$errorcount++;
				print ERRORLOG "$errorcount. $switch_open is not defined or empty\n";
			}
			unless(defined $switch_closed_state and $switch_closed_state ne ''){
				$errorcount++;
				print ERRORLOG "$errorcount. $switch_closed is not defined or empty\n";
			}
			print OUTFILE "\t\t\t\t\t'$switch_open' => '$switch_open_state',\n";
			print OUTFILE "\t\t\t\t\t'$switch_closed' => '$switch_closed_state',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################CAN Section##########################
		print OUTFILE "\t\t'CAN' => { \n";
		unless (defined $MLChash->{'CAN'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'CAN' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$MLChash->{'CAN'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$MLChash->{'CAN'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################PAS Section##########################
		print OUTFILE "\t\t'PAS' => { \n";
		unless (defined $MLChash->{'PAS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'PAS' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$MLChash->{'PAS'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$MLChash->{'PAS'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################WARNING_LAMPS Section################
		print OUTFILE "\t\t'WARNING_LAMPS' => { \n";
		unless (defined $MLChash->{'WARNING_LAMPS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'WARNING_LAMPS' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$MLChash->{'WARNING_LAMPS'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$MLChash->{'WARNING_LAMPS'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		##############FREELY_USABLE_SWITCHES Section##############
		print OUTFILE "\t\t'FREELY_USABLE_SWITCHES' => { \n";
		unless (defined $MLChash->{'FREELY_USABLE_SWITCHES'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'FREELY_USABLE_SWITCHES' section is not found in MLC hash\n";
		}
		foreach my $num( 1..10) {
			my $dev = "FS$num"."_Name";
			my $switch = $MLChash->{'FREELY_USABLE_SWITCHES'}{$dev};
			push (@FSswitches, $switch) if defined $switch;
			print OUTFILE "\t\t\t\t\t'$dev' => '$switch',\n" if defined $switch;	
		}
		print OUTFILE "\n";
		foreach my $switch (@FSswitches){
			my $switch_state_CA = "$switch"."_STATE_CA";
			my $switch_state_CB = "$switch"."_STATE_CB";
			my $switch_state_NC = "$switch"."_STATE_NC";
			my $switch_CA_state = $MLChash->{'FREELY_USABLE_SWITCHES'}{$switch_state_CA};
			my $switch_CB_state = $MLChash->{'FREELY_USABLE_SWITCHES'}{$switch_state_CB};
			my $switch_NC_state = $MLChash->{'FREELY_USABLE_SWITCHES'}{$switch_state_NC};
			
			unless(defined $switch_CA_state and $switch_CA_state ne ''){
				$errorcount++;
				print ERRORLOG "$errorcount. $switch_state_CA is not defined or empty\n";
			}
			unless(defined $switch_CB_state and $switch_CB_state ne ''){
				$errorcount++;
				print ERRORLOG "$errorcount. $switch_state_CA is not defined or empty\n";
			}
			unless(defined $switch_NC_state and $switch_NC_state ne ''){
				$errorcount++;
				print ERRORLOG "$errorcount. $switch_state_CA is not defined or empty\n";
			}
			
			print OUTFILE "\t\t\t\t\t'$switch_state_CA' => '$switch_CA_state',\n";
			print OUTFILE "\t\t\t\t\t'$switch_state_CB' => '$switch_CB_state',\n";
			print OUTFILE "\t\t\t\t\t'$switch_state_NC' => '$switch_NC_state',\n";
			print OUTFILE "\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		print OUTFILE "\n };\n\n";
		
		print OUTFILE '$Defaults->{"Mapping_DEVICE"}= {';
		print OUTFILE "\n\n\t\t\#'label' --> give a label corresponding to the device\n";
		print OUTFILE "\t\t\#'type' --> type can be any of these: 'hall', 'mech' or 'resistive'\n";
		
		foreach my $switch (@switches){
			print OUTFILE "\n\t\t\'$switch' => {\n";
			print OUTFILE "\t\t\t\t\t'label' => '$devicelabel{$switch}',\n";
			print OUTFILE "\t\t\t\t\t'type' => '',\n";
			print OUTFILE "\t\t\t\t\t\#Switch states/values to be set (current in mA or resistance in ohm)\n";
			print OUTFILE "\t\t\t\t\t'Undefined' => '',\n";
			print OUTFILE "\t\t},\n";
		}
		
		print OUTFILE "\n\t\t'Thresholds' => { #Thresholds for each band\n\n";
		
		print OUTFILE "\t\t\t\t'Switch_hall' => { #current in mA\n\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'LowUndefined' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'UndefinedHigh' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n\n";
		
		print OUTFILE "\t\t\t\t'Switch_resistive' => { #resistance in ohm\n\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'LowUndefined' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'UndefinedHigh' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n\n";
		
		print OUTFILE "\t\t\t\t'Squib' => { #resistance in ohm\n\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n";
		
		print OUTFILE "\t\t},"; #close Thresholds
					
		print OUTFILE "\n\n };";
		
		
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>TSG4 section<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

if(defined $TSG4hash){		
		print OUTFILE "\n\n";
		print OUTFILE '$Defaults->{"TSG4"}= {';
		print OUTFILE "\n";
		
		####################General Section######################
		print OUTFILE "\t\t'General' => { \n";
		unless (defined $TSG4hash->{'General'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'General' section is not found in TSG4 hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'General'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'General'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		
		####################POWER Supply Section#################
		print OUTFILE "\t\t'POWER_SUPPLY_LINES' => { \n";
		unless (defined $TSG4hash->{'POWER_SUPPLY_LINES'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'POWER_SUPPLY_LINES' section is not found in TSG4 hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'POWER_SUPPLY_LINES'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'POWER_SUPPLY_LINES'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################SQUIB Section########################
		print OUTFILE "\t\t'SQUIBS' => { \n";
		unless (defined $TSG4hash->{'SQUIBS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'SQUIBS' section is not found in TSG4 hash\n";
		}
		foreach my $num( 1..40) {
			my $devname = "SQ$num"."_Name";
			my $devDefault = "SQ$num"."_Default";
			my $squib = $TSG4hash->{'SQUIBS'}{$devname};
			my $squibRes = $TSG4hash->{'SQUIBS'}{$devname};
			push (@squibs, $squib) if defined $squib;
			print OUTFILE "\t\t\t\t\t'$devname' => '$squib',\n" if defined $squib;	
			print OUTFILE "\t\t\t\t\t'$devDefault' => '$squibRes',\n" if defined $squib;
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		
		####################BELT_LOCKS Section#######################
		print OUTFILE "\t\t'BELT_LOCKS' => { \n";
		unless (defined $TSG4hash->{'BELT_LOCKS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'BELT_LOCKS' section is not found in TSG4 hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'BELT_LOCKS'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'BELT_LOCKS'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################CAN FR Section##########################
		print OUTFILE "\t\t'CAN_FR' => { \n";
		unless (defined $TSG4hash->{'CAN_FR'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'CAN_FR' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'CAN_FR'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'CAN_FR'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
				
		####################K LIN Section##########################
		print OUTFILE "\t\t'K_LIN' => { \n";
		unless (defined $TSG4hash->{'K_LIN'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'K_LIN' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'K_LIN'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'K_LIN'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################PAS_LINES Section##########################
		print OUTFILE "\t\t'PAS_LINES' => { \n";
		unless (defined $TSG4hash->{'PAS_LINES'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'PAS_LINES' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'PAS_LINES'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'PAS_LINES'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		####################WARNING_LAMPS Section################
		print OUTFILE "\t\t'WARNING_LAMPS' => { \n";
		unless (defined $TSG4hash->{'WARNING_LAMPS'}){
			$errorcount++;
			print ERRORLOG "$errorcount. 'WARNING_LAMPS' section is not found in MLC hash\n";
		}
		foreach my $key (sort keys %{$TSG4hash->{'WARNING_LAMPS'}}) {
			print OUTFILE "\t\t\t\t\t'$key'=> '$TSG4hash->{'WARNING_LAMPS'}{$key}',\n";
		}
		print OUTFILE "\t\t},\n\n";
		#########################################################
		
		print OUTFILE "\n\t\t\'Thresholds' => {\n";
		
		print OUTFILE "\t\t\t\t'Switch_hall' => { #current in mA\n\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'LowUndefined' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'UndefinedHigh' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n\n";
		
		print OUTFILE "\t\t\t\t'Switch_resistive' => { #resistance in ohm\n\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'LowUndefined' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'UndefinedHigh' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n\n";
		
		print OUTFILE "\t\t\t\t'Squib' => {\n";
		print OUTFILE "\t\t\t\t\t\t'Min' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Low' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'High' => '',\n";
		print OUTFILE "\t\t\t\t\t\t'Max' => '',\n";
		print OUTFILE "\t\t\t\t},\n";
		
		print OUTFILE "\t\t},"; #close Thresholds
		
		print OUTFILE "\n };\n\n";
} #close TSG4 section

		print OUTFILE "\n 1;";
		
		if($color == 1){
			print GREEN, "\n\n\n!!SUCCESS: Mapping_DEVICE.pm file has been created successfully!! :-)\n\n", RESET;
			print CYAN, "\nPerform the below steps:\n", RESET;
			print CYAN, "1. Delete the section 'MLC' from file: $input_File_Name\n", RESET;
			print CYAN, "2. Make sure this new mapping file is declared in the CFG file for your project. Insert the below statements\n", RESET;
			print YELLOW, 'require "$LIFT_PRJCFG_path/Mapping_DEVICE.pm";', RESET;
			print "\n";
			print YELLOW, '$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{"Mapping_DEVICE"};', RESET;
			print "\n\n\n";
		}
		else{
			print "\n\n\n!!SUCCESS: Mapping_DEVICE.pm file has been created successfully!! :-)\n\n";
			print "\nPerform the below steps:\n";
			print "1. Delete the section 'MLC' and/or 'TSG4' from file: $input_File_Name if this is your Project Const\n";
			print "2. Make sure this new mapping file is declared in the CFG file for your project. Insert the below statements\n";
			print 'require "$LIFT_PRJCFG_path/Mapping_DEVICE.pm";';
			print "\n";
			print '$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{"Mapping_DEVICE"};';
			print "\n\n\n";
		}
		
		
		
		if(	$errorcount == 0){
			print ERRORLOG "NO ERRORS :-)\n";
			if($color == 1){
				print GREEN, "No ERRORS!! :-)\n\n", RESET;
			}
			else{
				print "No ERRORS!! :-)\n\n";
			}
		}
		else{
			if($color == 1){
				print RED, "\nHave a look at ErrorLog.txt for Warnings and Errors\n\n", RESET;
			}
			else{
				print "\nHave a look at ErrorLog.txt for Warnings and Errors\n\n";
			}
			
		}
		
		print ERRORLOG "\n\n!!!!!INFO!!!!!\n";
		print ERRORLOG "\nPerform the below steps:\n";
		print ERRORLOG "1. Delete the section 'MLC' and/or 'TSG4' from file: $input_File_Name if this is your Project Const\n";
		print ERRORLOG "2. Make sure this new mapping file is declared in the CFG file for your project. Insert the below statements\n";
		print ERRORLOG 'require "$LIFT_PRJCFG_path/Mapping_DEVICE.pm";';
		print ERRORLOG "\n";
		print ERRORLOG '$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{"Mapping_DEVICE"};';
		
		undef %$MLChash;
		#undef $TSG4hash;
		undef %$TSG4hash;
		undef $input_File_Name;
		undef $File_Name_Path;
	}

	close OUTFILE;
	close ERRORLOG;
	
	
	
	$status= "Completed Press Exit! \nHave a look at ErrorLog.txt file for Errors and Warnings";
    $main->update(); # sub 

}

# create
__END__

