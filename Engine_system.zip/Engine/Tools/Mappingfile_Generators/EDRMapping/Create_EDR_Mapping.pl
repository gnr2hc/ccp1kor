#!perl -w

#****************************************************************************************************
#                                                                                                   *
# Copyright (c) 2013 Robert Bosch GmbH, Germany                                                     *
#               All rights reserved                                                                 *
#                                                                                                   *
#****************************************************************************************************
# $Revision : 1.0 $                                                                                    *
#                                                                                                     *
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd; 
use Tk::LabFrame;
use File::Copy qw(copy);

sub Create_About_Window(){
    my $mw = MainWindow->new("-background" => "#888888");
    $mw->minsize(100,25);
    $mw->title("Help");

    #Making a text area
    my $txt = $mw -> Scrolled('Text',-width => 100,-scrollbars=>'e') -> pack ();

    $txt->delete('1.0','end');
        $txt->insert('end','
#
#    DESCRIPTION:                               
#    This tool will generate an EDID mapping file from an exported excel sheet of EDID List SRS              
#
#    FOLLOW THESE STEPS:
#    1. Check for these mandatory columns in DOORS SRS EDID List. Add to view if not present.
#		EDID 
#		Data element 
#		Data Length (Byte)
#		Data samples
#		Bytes / Data sample
#		Unit
#		Factor (Data)
#		Offset (Data)
#		Data value "invalid data"
#		Data value "data not available"
#		Data value to convert
#		From
#		Header (Byte)
#       Rec. start time (necessary for dynamic EDIDs)
#       Rec. end time (necessary for dynamic EDIDs)
# 		
#		Mandatory if available:
#		Bits / Data sample
#		Data Length (Bits)
#		Reporting Bit
#		Reporting Byte
#
#       Additionally mandatory in Supplier EDID List
#       SDID (replaces column EDID)
#           Note that SDID will be transformed to a unique integer number to enable parsing. This integer will be stored in EDID while the original SDID is stored in SDID.
#           This is done by replacing the supplier sectoins with numbers.
#               .Header. replaced with 1
#               .EDP. replaced with 2
#               .Fc. replaced with 3
#               .Gen. replaced with 4
#           Example:
#               SDID = 999.Header.2
#               --> EDID = 99912
#               SDID = 999.Gen.3
#               --> EDID 99943
#
#    2. Export Rqmts to excel sheet: EDID list SRS->File->Export->Microsoft Office->Excel..
#
#    3. Add missing values if not present                                      
#  
#    REMARKS:                                    
#    1. Perl Version 5.12 32 bit(installed using Peacy package) is required
#    2. Perl TK is to be installed                
#                                       
    '
    );

}
my ($main,$end_frame,$path_frame_xls_generic,$path_frame_xls_oem,$path_frame_xls_supplier,$path_frame_template,$entry);
my ($Designation_path,$ExcelFile_Name_Path_generic,$ExcelFile_Name_Path_oem,$ExcelFile_Name_Path_supplier,$templateFile_Name_Path,@File_Select_Arr,$status,);
my ($EDID_Start_Byte_From_Panel,$input_excel_File_Name_generic,$input_excel_File_Name_oem,$input_excel_File_Name_supplier,$input_template_File_Name,$EDR_Service_IDs,$Diag_Request_ID_From_Panel,$Diag_Response_ID_From_Panel);
my  @EDR_Services_DID_Array ;
my $EDID_control;
my $DID_Value;
# Default Designation Path
$Designation_path='C:';
my  $TK_ERROR_INDICATION_FLAG_i=0;
my $project_name ="";
$main = MainWindow->new("-background" => "#888888");

# Size to the TK window 
$main->minsize(450,100);

$main->title("EDR Mapping file Generator ");
# Get the current path 
my $pwd = cwd();
#print "$pwd","\n";
my @path_structure;
@path_structure =split(/\//,$pwd); 
# Remove the last Folder 
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path=join("\\",@path_structure);
print "File_With_Path = $File_With_Path","\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder
  

#Declare that there is a menu
my $mbar = $main -> Menu();
$main -> configure(-menu => $mbar);

#The Main Buttons
my $file = $mbar -> cascade(-label=>"File", -underline=>0, -tearoff => 0);
my $help = $mbar -> cascade(-label =>"Help", -underline=>0, -tearoff => 0);


## File Menu ##
$file -> command(-label =>"Exit", -underline => 1,
        -command => sub { exit } );
 
#******************************************************************************************** 
$help -> command(-label =>"ReadMe",  -command=>sub {Create_About_Window()});

$main->Label(
    -text=>'EDR Mapping file Generator  ',
    -font=>'{Segoe UI} 15 bold',
    -background => '#888888',
    -foreground => '#333366',
    -height=>'001')->pack(-side=>'top',-pady=>'003');




 my $labeled_frame1   = $main->Frame(-borderwidth => 2, 
                                 -relief => 'groove',
                                 -background => "#888888",
                                 )->pack(-side => "top",-padx=>'150',-anchor=>'nw');


#my $shot = $main->Photo(-file => "$File_With_Path\\logo\\AUDI.gif");
#$main->Label(-image => $shot)->pack(-side => 'top');
 $main->Label(
            -text=>'Select the excel files (exported from the EDID List SRS) and EDR mapping template',
            -font=>'{Segoe UI Semibold} 8 bold',
            -background => "#888888",
            -foreground => "#333366",
             )->pack(-side=>'top',-pady=>'02',-side=>'top');

$path_frame_xls_generic = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$path_frame_xls_oem = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$path_frame_xls_supplier = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );
$path_frame_template = $main->Frame("-background" => "#888888")->pack(-pady=>'1',-padx=>'03', -anchor=>'nw' );

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> generic <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$path_frame_xls_generic->Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ')->pack(-side=>'left');
        
$status= ' Not Started ';
$entry = $path_frame_xls_generic->Entry(
        -width=>'50',
        -textvariable=>\$ExcelFile_Name_Path_generic,
        -background => "grey",
        #-foreground  => "black",
        )->pack(-side=>'right',
                -pady=>'0');

                $path_frame_xls_generic->Button(
                        -text=>"Select generic EDIDs",
                        -width=>'18',
                        #-relief => 'groove',
                        -background => "DodgerBlue1",
                        -foreground  => "white",
                         -font=>'{Segoe UI Semibold} 10 ',
                        -command=>sub
                        {
                            $ExcelFile_Name_Path_generic = $main->getOpenFile(
                                        -filetypes=>[
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
                                       ],
                                        -title=>"Choose the xls file ",
                        );
                
                            if($ExcelFile_Name_Path_generic)
                            {
                               @File_Select_Arr=split(/\[/, $ExcelFile_Name_Path_generic);
                               $input_excel_File_Name_generic= $File_Select_Arr[-1];
                               print "Excel File Name = $input_excel_File_Name_generic";
                               $Designation_path = dirname($ExcelFile_Name_Path_generic); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side => "left",-padx=>'05',-pady=>'03');
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> generic end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<       


#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> oem <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$path_frame_xls_oem->Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 11 ')->pack(-side=>'left');
        
$status= ' Not Started ';
$entry = $path_frame_xls_oem->Entry(
        -width=>'50',
        -textvariable=>\$ExcelFile_Name_Path_oem,
        -background => "grey",
        #-foreground  => "black",
        )->pack(-side=>'right',
                -pady=>'0');

                $path_frame_xls_oem->Button(
                        -text=>"Select OEM EDIDs",
                        -width=>'18',
                        #-relief => 'groove',
                        -background => "DodgerBlue1",
                        -foreground  => "white",
                         -font=>'{Segoe UI Semibold} 10 ',
                        -command=>sub
                        {
                            $ExcelFile_Name_Path_oem = $main->getOpenFile(
                                        -filetypes=>[
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
                                            ["xls xlsx files", ['.xlsx', '.xls'] ],
                                       ],
                                        -title=>"Choose the xls file ",
                        );
                
                            if($ExcelFile_Name_Path_oem)
                            {
                               @File_Select_Arr=split(/\[/, $ExcelFile_Name_Path_oem);
                               $input_excel_File_Name_oem= $File_Select_Arr[-1];
                               print "Excel File Name = $input_excel_File_Name_oem";
                               $Designation_path = dirname($ExcelFile_Name_Path_oem); 
                               $Designation_path= $Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side => "left",-padx=>'05',-pady=>'03');
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> oem end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<        
        
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> supplier <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<  
$path_frame_xls_supplier->Label(
       -text=>'',
       -background => "#888888",
        -foreground => "blue1",
       -font=>'{Segoe UI} 11 ')->pack(-side=>'left');
       
$status= ' Not Started ';
$entry = $path_frame_xls_supplier->Entry(
       -width=>'50',
       -textvariable=>\$ExcelFile_Name_Path_supplier,
       -background => "grey",
       #-foreground  => "black",
       )->pack(-side=>'right',
               -pady=>'0');

               $path_frame_xls_supplier->Button(
                       -text=>"Select Supplier EDIDs",
                       -width=>'18',
                       #-relief => 'groove',
                       -background => "DodgerBlue1",
                       -foreground  => "white",
                        -font=>'{Segoe UI Semibold} 10 ',
                       -command=>sub
                       {
                           $ExcelFile_Name_Path_supplier = $main->getOpenFile(
                                       -filetypes=>[
                                           ["xls xlsx files", ['.xlsx', '.xls'] ],
                                           ["xls xlsx files", ['.xlsx', '.xls'] ],
                                      ],
                                       -title=>"Choose the xls file ",
                       );
               
                           if($ExcelFile_Name_Path_supplier)
                           {
                              @File_Select_Arr=split(/\[/, $ExcelFile_Name_Path_supplier);
                              $input_excel_File_Name_supplier=$File_Select_Arr[-1];
                              print "Excel File Name =$input_excel_File_Name_supplier";
                              $Designation_path = dirname($ExcelFile_Name_Path_supplier); 
                              $Designation_path=$Designation_path."/";
                            
                           }
                                                   
                       }
       )->pack(-side => "left",-padx=>'05',-pady=>'03');
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> supplier end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> template <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<      
$path_frame_template->Label(
        -text=>'',
        -background => "#888888",
         -foreground => "blue1",
        -font=>'{Segoe UI} 12 ')->pack(-side=>'left');        


        
$entry = $path_frame_template->Entry(
        -width=>'50',
        -textvariable=>\$templateFile_Name_Path,
        -background => "grey",
        #-foreground  => "black",
        )->pack(-side=>'right',
                -pady=>'1');

                $path_frame_template->Button(
                        -text=>"Select Template",
                        -width=>'18',
                        #-relief => 'groove',
                        -background => "DodgerBlue1",
                        -foreground  => "white",
                         -font=>'{Segoe UI Semibold} 10 ',
                        -command=>sub
                        {
                            $templateFile_Name_Path = $main->getOpenFile(
                                        -filetypes=>[
                                            ["pm files", ['.pm'] ],
                                            ["pm files", ['.pm'] ],
                                       ],
                                        -title=>"Choose the pm file ",
                        );
                
                            if($templateFile_Name_Path)
                            {
                               @File_Select_Arr=split(/\[/, $templateFile_Name_Path);
                               $input_template_File_Name= $File_Select_Arr[-1];
                               print "Template File Name = $input_template_File_Name";
                               $Designation_path = dirname($templateFile_Name_Path); 
                               $Designation_path=$Designation_path."/";
                             
                            }
                                                    
                        }
        )->pack(-side => "top",-padx=>'06');
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>> template end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


$end_frame = $main->Frame("-background" => "#888888")->pack(-ipadx=>'10', -padx=>'2');
$end_frame->Button(
        -text=>'EXIT',
        -width=>'9',
        -font=>'{Segoe UI Semibold} 10 ',
         -background => "#333366",
         -foreground => "white",
      #    -relief => 'groove',
        -command=>[$main=>'destroy']
        )->pack(-pady=> 10,  -side=>'right');


$end_frame->Button(
        -text=>'GENERATE',
        -width=>'9',
        -font=>'{Segoe UI Semibold} 10 ',
        -foreground => "white",
       # -relief => 'groove',
        -background => "#333366",
        -command=>sub {Generate_File()}
        )->pack(-pady=> 10, -padx=> 10,  -side=>'right');   
        
 # create label in window 'main'
 $main -> Label(
        -textvariable => \$status, #reference to display the status
         -font=>'{Segoe UI Semibold} 10.5',
        -background  => "#888888",
        -foreground  => "white",
        )-> pack( "-pady" => 6,-side=>'top' );
        
MainLoop;

 
  
sub Generate_File(){   
    
    my %EDIDexcelFiles;
    
    $EDIDexcelFiles{'generic'} = $input_excel_File_Name_generic;
    $EDIDexcelFiles{'oem'} = $input_excel_File_Name_oem;
    $EDIDexcelFiles{'supplier'} = $input_excel_File_Name_supplier;

    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI   
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if(!$input_excel_File_Name_generic and !$input_excel_File_Name_oem and !$input_excel_File_Name_supplier){
           $status= "Select the excel files !!"; 
        $main->update();
        die("excel file is not found!\n");
    }
    else{
        $status= ' Not Started ';
        $main->update();
               
        #SheetName of the Exported Decoder sheet
        my %input_data_Sheet = (
                                'in_Data'=>"Sheet1",
                                );
                                
        #copy ".\\template\\Mapping_EDR_template.pm", ".\\Mapping_EDR.pm";                                

        unless(open (TEMPLATE,$input_template_File_Name)){
            $status= "Select the template file !!"; 
            $main->update();
            die("template file $input_template_File_Name is not found!\n");
        }
        open (TEMPWRITE,">temp_EDID_mappings.txt") || die("temp_EDID_mappings.txt could not be created!\n");  
        open (EDRMAP,">Mapping_EDR.pm") || die("Mapping_EDR.pm could not be created!\n");  
        open (ERRORLOG,">ErrorLog.txt") || die("ErrorLog.txt could not be created!\n");  
        #print WRITE "#### Mappings are generated by EDID mapping creator tool #### \n";
        #print WRITE "#### Copy all data from here into EDR mapping file Mapping_EDR.pm #### \n";
        #print WRITE "\n\n";
        
        my (@error_messages,@warning_messages);
        
        foreach my $excelFile(sort keys %EDIDexcelFiles){
                sleep(1);
                my $fileName = $EDIDexcelFiles{$excelFile};
                
                #create all hashes in tempwrite file
                print TEMPWRITE "\n\n 'GENERIC_EDIDS' => { #hash containing all Generic EDIDs \n\n" if ($excelFile =~ m/generic/i);
                print TEMPWRITE "\n\n 'OEM_EDIDS' => { #hash containing all OEM EDIDs \n\n" if ($excelFile =~ m/oem/i);
                print TEMPWRITE "\n\n 'SUPPLIER_EDIDS' => { #hash containing all Supplier EDIDs \n\n" if ($excelFile =~ m/supplier/i);
                
                if(defined $excelFile and defined $fileName){                
                    my $excel;
                    my $input_WorkBook;
                    my $input_WorkSheet;
                    
                    my $xls_State_column;
                    my $xls_EDID_column;
                    my $xls_SDID_column;
                    my $xls_DataElement_column;
                    my $xls_DataSource_column;
                    my $xls_BytesPerDataSample_column;
                    my $xls_BitsPerDataSample_column;
                    my $xls_DataSamples_column;
                    my $xls_DataLength_column;
                    my $xls_DataLength_Bits_column;
					my $xls_ReportingByte_column;
					my $xls_ReportingBit_column;
                    my $xls_Unit_column;
                    my $xls_Factor_column;
                    my $xls_Offset_column;
                    my $xls_HeaderByte_column;
                    my $xls_CaptureSampleRateHz_column;
                    my $xls_RecSampleRateHz_column;
                    my $xls_RecStartTime_column;
                    my $xls_RecEndTime_column;
                    my $xls_BytePosition_column;
                    my $xls_DataPosition_column;
                    my $xls_From_column;                    
                    my $xls_InvalidData_column;
                    my $xls_DataNotAvailable_column;
                    my $xls_DataValueTable_column;
                    
                    my @datavaluelines;
            
                    # Open the xls using the WIN OLE package  
                    use Win32::OLE qw(in with);
                    use Win32::OLE::Const 'Microsoft Excel';
                    $Win32::OLE::Warn = 3;
            
                    # get already active Excel application or open new
                    $excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application', 'Quit');  
                    #$excel->{DisplayAlerts}=0;
                    $excel->{Visible} =1;
            
                    # open Excel file which comtain  the decoder information 
                    $input_WorkBook = $excel->Workbooks->Open("$fileName");
                    # select workSheet number 1 (you can also select a workSheet by name)
                    #$input_WorkSheet = $input_WorkBook->WorkSheets("$input_data_Sheet{'in_Data'}");
                    $input_WorkSheet = $input_WorkBook->Worksheets(1);        
                      
                            
                    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
                    my $LastRow_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
                    SearchDirection=>xlPrevious,
                    SearchOrder=>xlByRows})->{Row};
                    print "\nLast Row of input file =",$LastRow_input_data,"\n";
                    
                    my $LastColoumn_input_data = $input_WorkSheet->UsedRange->Find({What=>"*",
                    SearchDirection=>xlPrevious,
                    SearchOrder=>xlByColumns})->{Column};
                    print "\nLast Coloumn of input file =",$LastColoumn_input_data,"\n";
                                
                    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
                            
                    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^       
                    $status = "Conversion in progress!!!.";
                    $main->update();
                            
                    #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attrributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
                    my $Header_Filter_Row =1;
                    my $column =1;
                    my $column_Read;
                    foreach $column(1..$LastColoumn_input_data){
                        $column_Read=""; # clear the old data 
                        # Read the bit byte cell value from xls File 
                        $column_Read = $input_WorkSheet->Cells($Header_Filter_Row,$column)->{'Value'};
                        
                        if($column_Read =~ m/EDID/i){
                            $xls_EDID_column = $column;
                        }
                        elsif($column_Read =~ m/SDID/i){
                            if(defined $xls_SDID_column) {
                                push(@error_messages,  "Two columns containing 'SDID' identified. First one will be taken (column $xls_SDID_column). Delete the unnecessary column.\n");
                            }
                            else {
                                $xls_SDID_column = $column;
                            }
                        }
                        elsif($column_Read =~ m/State/i){
                            $xls_State_column = $column;
                        }
                        elsif($column_Read =~ m/Data element/i or $column_Read =~ m/DataElement/i){
                            if(defined $xls_DataElement_column) {
                                push(@error_messages,  "Two columns containing 'Data element' identified. First one will be taken (column $xls_DataElement_column). Delete the unnecessary column.\n");
                            }
                            else {
                                $xls_DataElement_column = $column;
                            }
                        }
                        elsif($column_Read =~ m/Data source/i){
                            $xls_DataSource_column = $column;
                        }
                        elsif($column_Read =~ m/Bytes\s\/\sData\ssample/i or $column_Read =~ m/BytesPerDataSample/i){
                            $xls_BytesPerDataSample_column = $column;
                        }
                        elsif($column_Read =~ m/Bits\s\/\sData\sSample/i  or $column_Read =~ m/BitsPerDataSample/i){
                            $xls_BitsPerDataSample_column = $column;
                        }
                        elsif($column_Read =~ m/Data samples/i  or $column_Read =~ m/DataSamples/i){
                            $xls_DataSamples_column = $column;
                        }
                        elsif($column_Read =~ m/Data length \SBits\S/i or $column_Read =~ m/DataLength_Bits/i){
                            $xls_DataLength_Bits_column = $column;
                        }
						elsif($column_Read =~ m/Reporting Byte\SStarting Byte\S/i  or $column_Read =~ m/ReportingByte/i){
                            $xls_ReportingByte_column = $column;
                        }
						elsif($column_Read =~ m/Reporting Bit\SStarting Bit\S/i or $column_Read =~ m/Reporting Bit \SStarting Bit\S/i or $column_Read =~ m/ReportingBit/i){
                            $xls_ReportingBit_column = $column;
                        }
                        elsif($column_Read =~ m/Unit/i){
                            $xls_Unit_column = $column;
                        }
                        elsif($column_Read =~ m/Factor/i  or $column_Read =~ m/DataFactor/i){
                            $xls_Factor_column = $column;
                        }
                        elsif($column_Read =~ m/Offset/i  or $column_Read =~ m/DataOffset/i){
                            $xls_Offset_column = $column;
                        }
                        elsif($column_Read =~ m/invalid data/i  or $column_Read =~ m/DataValue_InvalidData/i){
                            $xls_InvalidData_column = $column;
                        }
                        elsif($column_Read =~ m/data not available/i  or $column_Read =~ m/DataValue_DataNotAvailable/i){
                            $xls_DataNotAvailable_column = $column;
                        }
                        elsif($column_Read =~ m/Data value to convert/i  or $column_Read =~ m/ReportFormatDescription/i or $column_Read =~ m/FormatDescriptionBosch/i){
                            $xls_DataValueTable_column = $column;
                        }  
                        elsif($column_Read =~ m/Header/i  or $column_Read =~ m/HeaderBytes/i){
                            $xls_HeaderByte_column = $column;
                        }
                        elsif($column_Read =~ m/rec\.\sSample\sRate/i or $column_Read =~ m/Sampling/i or $column_Read =~ m/SampleRate/i) {
                            $xls_RecSampleRateHz_column = $column;
                        }
                        elsif( $column_Read =~ m/rec\.\sStart/i or $column_Read =~ m/Start/i){
                            $xls_RecStartTime_column = $column;
                        }
                        elsif($column_Read =~ m/rec\.\sEnd/i or $column_Read =~ m/End/i){
                            $xls_RecEndTime_column = $column;
                        }  
                        elsif($column_Read =~ m/Byte Position/i){
                            $xls_BytePosition_column = $column;
                        }
                        elsif($column_Read =~ m/Data Position/i){
                        	$xls_DataPosition_column = $column;
                        }
                        #$xls_From_column
                        elsif($column_Read =~ m/From/i){
                            $xls_From_column = $column;
                        }
                        
                    }    
                    #++++++++++++++++++++++++++++++++++++++++++++++++++++++
                    # check if all expected columns are present in excel sheet
                    unless (defined $xls_DataElement_column){
                        push(@error_messages,  "'Data Element' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_EDID_column or defined $xls_SDID_column){
                        push(@error_messages,  "'EDID' and 'SDID' column is missing in $excelFile file. One of these must be added to the excel sheet (SDID for supplier, EDID for generic and OEM)\n");
                    }
                    unless (defined $xls_State_column){
                        push(@error_messages,  "'State' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_DataSamples_column){
                        push(@error_messages,  "'Data samples' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }    
                    unless (defined $xls_BytesPerDataSample_column){
                        push(@error_messages,  "'Bytes / Data sample' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_Unit_column){
                        push(@error_messages,  "'Unit' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_Factor_column){
                        push(@error_messages,  "'Factor (Data)' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_Offset_column){
                        push(@error_messages,  "'Offset (Data)' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_InvalidData_column){
                        push(@error_messages,  "column for invalid data  is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_DataNotAvailable_column){
                        push(@error_messages,  "column for 'data not available' is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_DataValueTable_column){
                        push(@error_messages,  "column for 'Data value to convert' is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_HeaderByte_column){
                        push(@error_messages,  "'Header (Byte)' column is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_RecSampleRateHz_column){
                        push(@error_messages,  "column for 'Sample Rate [Hz]'  is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_RecStartTime_column){
                        push(@error_messages,  "column for 'Start [ms]' is missing in $excelFile file. Please add this to the excel sheet\n");
                    }
                    unless (defined $xls_RecEndTime_column){
                        push(@error_messages,  "column for 'End [ms]' is missing in $excelFile file. Please add this to the excel sheet\n");
                    }

                    #++++++++++++++++++++++++++++++++++++++++++++++++++++++


                    #++++++++++++++++++++++++++++create the EDID list HASH+++++++++++++++++++++++++++++++++++++++                
                    my ($xls_EDID_read,
                        $xls_SDID_read,
                        $xls_DataElement_read, 
                        $xls_State_read,
                        $xls_DataLength_Bits_read,
						$xls_ReportingByte_read,
                        $xls_ReportingBit_read,                     
                        $xls_DataSamples_read,
                        $xls_DataSource_read,
                        $xls_BytesPerDataSample_read,
                        $xls_BitsPerDataSample_read,
                        $xls_Unit_read,
                        $xls_Factor_read,
                        $xls_Offset_read,
                        $xls_InvalidData_read,
                        $xls_DataNotAvailable_read,
                        $xls_DataValueTable_read,
                        $xls_HeaderByte_read,
                        $xls_RecSampleRateHz_read,
                        $xls_RecStartTimeMillisec_read,
                        $xls_RecEndTimeMillisec_read,
                        $xls_BytePosition_read,
                        $xls_DataPosition_read,
                        $xls_From_read,
                    );

					my $hash_All_DataElements;
                    foreach my $row(2..$LastRow_input_data){
                        my (@keys,@values);
                        my $count = 0;
                        
                        $xls_EDID_read  = $input_WorkSheet->Cells($row,$xls_EDID_column)->{'Value'} if defined $xls_EDID_column;
                        $xls_SDID_read  = $input_WorkSheet->Cells($row,$xls_SDID_column)->{'Value'} if defined $xls_SDID_column;
                        # convert SDID to numbers
                        my $original_SDID_read = $xls_SDID_read;
                        if(defined $xls_SDID_read) {
							my @sdid_array = split(/\./, $xls_SDID_read);
							# Replace supplier section with numeric value
							my $supplierSection = $sdid_array[1]; # Header, EDP, Fc, Gen
                            $supplierSection =~ s/Header/1/g;
                            $supplierSection =~ s/EDP/2/g;
                            $supplierSection =~ s/Fc/3/g;
                            $supplierSection =~ s/Gen/4/g;
							
							# Replace ID with 2 digit number (one leading zero, up to 99 supplier EDIDs per section supported)
							my $sdid_ID = sprintf("%02d", $sdid_array[2]);
							
							# Put together complete supplier EDID ID
                            $xls_EDID_read = $sdid_array[0].$supplierSection.$sdid_ID;
                            $xls_SDID_read = $original_SDID_read;
                        }
                        $xls_DataElement_read = $input_WorkSheet->Cells($row,$xls_DataElement_column)->{'Value'} if defined $xls_DataElement_column;
                        $xls_DataElement_read =~ s/(\x0D)?(\x0A)?//g;  # removes the line breaks
                        
                        my @edidNbrToCompare_array = split(/_/, $xls_EDID_read);
                        my $edidNbrToCompare = $edidNbrToCompare_array[0];
                        
                        if (defined $xls_EDID_read and defined $xls_DataElement_read and ($edidNbrToCompare < 3000 or defined $xls_SDID_read)){                             
                            $xls_DataLength_Bits_read        = $input_WorkSheet->Cells($row,$xls_DataLength_Bits_column)->{'Value'} if defined $xls_DataLength_Bits_column;
							chomp($xls_DataLength_Bits_read);
							$xls_ReportingByte_read          = $input_WorkSheet->Cells($row,$xls_ReportingByte_column)->{'Value'} if defined $xls_ReportingByte_column;
							chomp($xls_ReportingByte_read);
							$xls_ReportingBit_read           = $input_WorkSheet->Cells($row,$xls_ReportingBit_column)->{'Value'} if defined $xls_ReportingBit_column;
							chomp($xls_ReportingBit_read);
                            $xls_State_read                  = $input_WorkSheet->Cells($row,$xls_State_column)->{'Value'} if defined $xls_State_column;
							chomp($xls_State_read);
                            $xls_DataSamples_read            = $input_WorkSheet->Cells($row,$xls_DataSamples_column)->{'Value'} if defined $xls_DataSamples_column;
							chomp($xls_DataSamples_read);
                            $xls_DataSource_read             = $input_WorkSheet->Cells($row,$xls_DataSource_column)->{'Value'} if defined $xls_DataSource_column;
							chomp($xls_DataSource_read);
                            $xls_BytesPerDataSample_read     = $input_WorkSheet->Cells($row,$xls_BytesPerDataSample_column)->{'Value'} if defined $xls_BytesPerDataSample_column;
							chomp($xls_BytesPerDataSample_read);
                            $xls_BitsPerDataSample_read     = $input_WorkSheet->Cells($row,$xls_BitsPerDataSample_column)->{'Value'} if defined $xls_BitsPerDataSample_column;
							chomp($xls_BitsPerDataSample_read);
                            $xls_Unit_read                   = $input_WorkSheet->Cells($row,$xls_Unit_column)->{'Value'} if defined $xls_Unit_column;
 							chomp($xls_Unit_read);
                            $xls_Factor_read                 = $input_WorkSheet->Cells($row,$xls_Factor_column)->{'Value'} if defined $xls_Factor_column;
							chomp($xls_Factor_read);
                            $xls_Offset_read                 = $input_WorkSheet->Cells($row,$xls_Offset_column)->{'Value'} if defined $xls_Offset_column;
							chomp($xls_Offset_read);
                            $xls_InvalidData_read            = $input_WorkSheet->Cells($row,$xls_InvalidData_column)->{'Value'} if defined $xls_InvalidData_column;
							chomp($xls_InvalidData_read);
                            $xls_DataNotAvailable_read       = $input_WorkSheet->Cells($row,$xls_DataNotAvailable_column)->{'Value'} if defined $xls_DataNotAvailable_column;
							chomp($xls_DataNotAvailable_read);
                            $xls_DataValueTable_read         = $input_WorkSheet->Cells($row,$xls_DataValueTable_column)->{'Value'} if defined $xls_DataValueTable_column;
                            $xls_HeaderByte_read             = $input_WorkSheet->Cells($row,$xls_HeaderByte_column)->{'Value'} if defined $xls_HeaderByte_column;
							chomp($xls_HeaderByte_read);
                            $xls_RecSampleRateHz_read        = $input_WorkSheet->Cells($row,$xls_RecSampleRateHz_column)->{'Value'} if defined $xls_RecSampleRateHz_column;
							chomp($xls_RecSampleRateHz_read);
                            $xls_RecStartTimeMillisec_read   = $input_WorkSheet->Cells($row,$xls_RecStartTime_column)->{'Value'} if defined $xls_RecStartTime_column;
							chomp($xls_RecStartTimeMillisec_read);
                            $xls_RecEndTimeMillisec_read     = $input_WorkSheet->Cells($row,$xls_RecEndTime_column)->{'Value'} if defined $xls_RecEndTime_column;
							chomp($xls_RecEndTimeMillisec_read);
                            $xls_BytePosition_read     = $input_WorkSheet->Cells($row,$xls_BytePosition_column)->{'Value'} if defined $xls_BytePosition_column;
							chomp($xls_BytePosition_read);
                            $xls_DataPosition_read     = $input_WorkSheet->Cells($row,$xls_DataPosition_column)->{'Value'} if defined $xls_DataPosition_column;
                            chomp($xls_DataPosition_read);
                            $xls_From_read     = $input_WorkSheet->Cells($row,$xls_From_column)->{'Value'} if defined $xls_From_column;
                            chomp($xls_From_read);
                            
                            my($endByte);
                            if(defined $xls_DataPosition_read){
                            	$xls_DataPosition_read =~ m/Byte\s(\d+).*/;
                            	$xls_BytePosition_read = $1;
                            	$endByte = $1;
                            	if(not defined $xls_BytePosition_read){
                                    $xls_DataPosition_read =~ m/Bytes\s(\d+)\s-\s(\d+)/;
                            		$xls_BytePosition_read = $1;
                            		$endByte = $2;
                            	}
                                print ERRORLOG "Data Position EDID $xls_EDID_read: $xls_DataPosition_read\n\n";
                                print ERRORLOG "Start byte $xls_BytePosition_read\n\n";
                                print ERRORLOG "End byte $endByte\n\n";
                            }
                            
                            if(defined $xls_DataValueTable_read and $xls_DataValueTable_read ne '1'){ #if it contains multiple lines
                                @datavaluelines = split('\n', $xls_DataValueTable_read);
                                foreach my $line (@datavaluelines){
                                    if(defined $line and $line ne "..."){
                                        if($line =~ m/(.*):\s(.*)/){
                                            my $key = $1;
                                            my $value = $2;
                                            push(@keys, $key);
                                            push(@values, $value);
                                        }
                                        elsif($line =~ m/(.*):(.*)/){
                                            my $key = $1;
                                            my $value = $2;
                                            push(@keys, $key);
                                            push(@values, $value);
                                        }        
                                    }
                                }
                            }


                            #check for any empty fields!
                            unless (defined $xls_DataElement_read){
                                push(@error_messages,  "Data element is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }

                            unless (defined $xls_DataSamples_read){
                                push(@error_messages,  "Data samples is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            unless (defined $xls_InvalidData_read){
                                push(@error_messages,  "Data value (Invalid data) is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            unless (defined $xls_DataNotAvailable_read){
                                push(@error_messages,  "Data value (Data Not Available) is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            unless (defined $xls_HeaderByte_read){
                                push(@error_messages,  "Header (Byte) is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            if( $xls_RecSampleRateHz_column and not defined $xls_RecSampleRateHz_read ) {
                                push(@error_messages,  "rec. Sample Rate [Hz] is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            unless (defined $xls_RecStartTimeMillisec_read){
                                push(@error_messages,  "rec. Start [ms] is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }
                            unless (defined $xls_RecEndTimeMillisec_read){
                                push(@error_messages,  "rec. End [ms] is not defined for EDID $xls_EDID_read in $excelFile file. Please add this\n");
                            }

                            if( $xls_State_read =~ /rejected/i) {
                                push(@error_messages,  "State '$xls_State_read' [$xls_EDID_read] $xls_DataElement_read -> to be verified\n");
                            }

                            if( defined $EDID_control->{$xls_EDID_read}) {
                                my $prev_xls_DataElement_read = $EDID_control->{$xls_EDID_read}{'DataElement'};
                                push(@error_messages,  "Double use of EDID nbr : '$xls_EDID_read' (Label1 = $prev_xls_DataElement_read ; Label2= $xls_DataElement_read)\n");
                            }

                            if( defined $EDID_control->{$xls_DataElement_read}) {
                                my $prev_xls_EDID_read = $EDID_control->{$xls_DataElement_read}{'EDID'};
                                push(@error_messages,  "Double use of EDID DataElement : '$xls_DataElement_read' (EDID1 = $prev_xls_EDID_read ; EDID2= $xls_EDID_read)\n");
                            }

                            $EDID_control->{$xls_EDID_read}{'DataElement'} = $xls_DataElement_read;
                            $EDID_control->{$xls_DataElement_read}{'EDID'} = $xls_EDID_read;
                            
                            #### check format of reporting byte and reporting bit
                            $xls_ReportingByte_read = _format_Content_To_Hash($xls_ReportingByte_read);
                            $xls_ReportingBit_read = _format_Content_To_Hash($xls_ReportingBit_read);
               
                            #print TEMPWRITE "\n";
							
							# Check whether a data element with the same name already exists. If so, append a number to the data elment.
							# -> Reason: EDR mapping will be loaded to TurboLIFT as a hash. The data element of an EDID will be the key. The key has to be unique. If it is not, it will be overwritten and the EDID can't be used.
							if($hash_All_DataElements -> {$xls_DataElement_read}){
								my $number = $hash_All_DataElements -> {$xls_DataElement_read};
								$hash_All_DataElements -> {$xls_DataElement_read} += 1;
								$xls_DataElement_read = $xls_DataElement_read." ".$number;
							}
							else {
								$hash_All_DataElements -> {$xls_DataElement_read} = 1;
							}
                            #---------------------------------------------------------------------------------------------------#                           
                            print TEMPWRITE  "\t'$xls_DataElement_read' => {\n";
                            print TEMPWRITE  "\t\t\t\t\t'EDID' => '$xls_EDID_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'SDID' => '$xls_SDID_read',\n" if(defined $xls_SDID_read);
                            print TEMPWRITE  "\t\t\t\t\t'DataElement' => '$xls_DataElement_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'DataLength_Bits' => '$xls_DataLength_Bits_read',\n" if(defined $xls_DataLength_Bits_read);
                            _print_Hash_Or_String('ReportingByte', $xls_ReportingByte_read) if(defined $xls_ReportingByte_read);
                            _print_Hash_Or_String('ReportingBit', $xls_ReportingBit_read) if(defined $xls_ReportingBit_read);
                            print TEMPWRITE  "\t\t\t\t\t'DataSamples' => '$xls_DataSamples_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'BytesPerDataSample' => '$xls_BytesPerDataSample_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'BitsPerDataSample' => '$xls_BitsPerDataSample_read',\n" if(defined $xls_BitsPerDataSample_read);
                            print TEMPWRITE  "\t\t\t\t\t'DataSource' => '$xls_DataSource_read',\n" if(defined $xls_DataSource_read);
                            print TEMPWRITE  "\t\t\t\t\t'Unit' => '$xls_Unit_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'Factor' => '$xls_Factor_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'Offset' => '$xls_Offset_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'HeaderByte' => '$xls_HeaderByte_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'RecSampleRateHz' => '$xls_RecSampleRateHz_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'RecStartTimeMillisec' => '$xls_RecStartTimeMillisec_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'RecEndTimeMillisec' => '$xls_RecEndTimeMillisec_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'BytePosition' => '$xls_BytePosition_read',\n" if(defined $xls_BytePosition_read);
                            print TEMPWRITE  "\t\t\t\t\t'EndBytePosition' => '$endByte',\n" if(defined $endByte);
                            print TEMPWRITE  "\t\t\t\t\t'DataValueTable' => {\n";    #open DataValueTable
                            if($xls_DataValueTable_read eq '1' or not defined $xls_DataValueTable_read){    
                                print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'InvalidData' => '$xls_InvalidData_read',\n";
                                print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'DataNotAvailable' => '$xls_DataNotAvailable_read',\n";        
                            }
                            else{
                                foreach my $key (@keys){    
                                    print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'$values[$count]' => '$key',\n";
                                    $count++;
                                }
                                print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'Invalid_Data' => '$xls_InvalidData_read',\n";
                                print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'DataNotAvailable' => '$xls_DataNotAvailable_read',\n";    
                            }
                            print TEMPWRITE  "\t\t\t\t\t\t\t\t\t},\n";    #close DataValueTable
                            print TEMPWRITE  "\t\t\t\t\t'SourceDocument' => '".basename( $fileName )."',\n";
                            print TEMPWRITE  "\t\t\t\t\t'StateEDID' => '$xls_State_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t'From' => '$xls_From_read',\n";
                            print TEMPWRITE  "\t\t\t\t\t},\n";
                            print TEMPWRITE  "#----------------------------------------------------------------------------------#"."\n";              
                        }                           
                    }
                    $input_WorkBook->Close();     
            } #close if defined excel file
            else{
                push(@warning_messages,"Exported excel file for $excelFile EDIDs is not available. $excelFile EDIDs are not generated!!\n");
            }            
            print TEMPWRITE  "}, #close $excelFile EDID hash\n";    

        }#close for each EDID file
        
        print TEMPWRITE  "#\n";    
        print TEMPWRITE  "# Generated by $0 \n";    
        print TEMPWRITE  "# Generated at ".localtime(time())." \n";    
        print TEMPWRITE  "#\n";    
        close TEMPWRITE;
        
        open (TEMPWRITE,"temp_EDID_mappings.txt") || die("temp_EDID_mappings.txt could not be opened \n!");  
        while (my $line_template = <TEMPLATE>){
            print EDRMAP $line_template;
            if($line_template=~m/SECTION FOR GENERATED EDIDS/i){
                while (my $line_temp = <TEMPWRITE>){
                    print EDRMAP $line_temp;
                }    
            }
        }
        close TEMPWRITE;
        unlink "temp_EDID_mappings.txt" or warn "Could not delete file temp_EDID_mappings.txt!";    

        my $errorcount = 0;
        print ERRORLOG "!!!!!!!!!!!!!!!!!!!!!!!!ERRORS!!!!!!!!!!!!!!!!!!!!!!!!\n\n";
        foreach my $error (@error_messages){
            $errorcount++;
            print ERRORLOG "$errorcount. $error";
        }
        
        my $warningcount = 0;
        print ERRORLOG "\n\n!!!!!!!!!!!!!!!!!!!!!!!!WARNINGS!!!!!!!!!!!!!!!!!!!!!!\n\n";
        foreach my $warning (@warning_messages){
            $warningcount++;
            print ERRORLOG "$warningcount. $warning";
        }
                    
        print ERRORLOG "\n\n!!!!!!!!!!!!!!!!!!!!!!!INFO!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";
        print ERRORLOG "\nPerform the below steps:\n";
        #print ERRORLOG "1. Copy the generated EDID mappings (from EDID_mappings.txt) into the EDR mapping file template (Mapping_EDR.pm) under section for EDID MAPPINGS\n";
        print ERRORLOG "1. Make sure this new mapping file is declared in the CFG file for your project. Insert the below statements\n";
        print ERRORLOG 'require "$LIFT_PRJCFG_path/Mapping_EDR.pm";';
        print ERRORLOG "\n";
        print ERRORLOG '$LIFT_PROJECT::Defaults->{"Mapping_EDR"};';
                  
        ##################  Save File is completed ###############################       
    }    
    
    close ERRORLOG;
    close EDRMAP;
    close TEMPLATE;
    
    $status= "Completed Press Exit! \nHave a look at ErrorLog.txt file for Errors and Warnings";
    $main->update(); # sub 

}

sub _format_Content_To_Hash {
	my $string = shift;
	
    if(not $string =~ m/^(0|([+-]?\d+))$/ and not $string eq ''){
        my @splitReportingByteInfo = split(/\n/, $string);
        my $size = @splitReportingByteInfo;
        return $string if($size == 1);

        my $key;
        my $formattedString;
        foreach my $section (@splitReportingByteInfo){
            next if($section eq '');
            if(not defined $key){                                   
                $key = $section;
            }
            else {
                $formattedString -> {$key} = $section;
                $key = undef;
            }
            $string = $formattedString;
        }        
    }

    return $string;
	
}

sub _print_Hash_Or_String {
	my $mainKeyText = shift;
	my $variableToPrint = shift;

    if(ref($variableToPrint) eq 'HASH'){
        print TEMPWRITE  "\t\t\t\t\t'$mainKeyText' => {\n";    #open ReportingByte
        foreach my $key (keys %{$variableToPrint}){
             my $value = $variableToPrint -> {$key};
             print TEMPWRITE  "\t\t\t\t\t\t\t\t\t'$key' => '$value',\n";                                
        }
        print TEMPWRITE  "\t\t\t\t\t\t\t\t\t},\n";    #close ReportingByte                              
    }
    else{
        print TEMPWRITE  "\t\t\t\t\t'$mainKeyText' => '$variableToPrint',\n";                               
    }
	
	return 1;
}

# create
__END__
