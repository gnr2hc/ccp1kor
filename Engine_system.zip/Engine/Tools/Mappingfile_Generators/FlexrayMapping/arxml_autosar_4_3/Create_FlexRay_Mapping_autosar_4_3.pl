use strict;
use XML::Hash::LX;
use File::Slurp;
use Data::Dumper;
use File::Basename;
use File::Path qw( make_path );
use Tk;

use Extract_autosar_4_3;

# my $file = 'C:\Tickets_Support\Daimler\Daimler_MRA2_Test_V1\Databases\ORC_STAR_3_2020_Ecu_Extract_2017_29a0_AR43.arxml';

use vars qw($VERSION );
$VERSION = q$Revision: 1.2 $;

my $MAPP_FILE_VERSION = "FlexRay Mapping from 'ARXML database 4.3', tool version = '$VERSION'";

# =====================================================
#           variables
# =====================================================
my $log_File = "FlxrMpngArxml_log.txt";
my $opt_output_file;
my $output_FlexRay_mapping = "FlexRayMapping_AutosarARXML_4_3.pm";
my $input_arxml_file;
my $signal_count_href;

# =====================================================
#           FUNCTION CALLS
# =====================================================

LaunhGUI();
MainLoop;

#Process_allSignals();
#Process_Pdus();

sub MpngGnr_start {

    # STEP Start the mapping generator
    open( LOG,     "> $log_File" )        || die("Open file: $!\n");
    open( OUTFILE, "> $opt_output_file" ) || die("Open file $opt_output_file : $!\n");

    my $arxml_flxr_extract_href = Extract_autosar_4_3::GetFlexrayMappingContents_fromARXML($input_arxml_file);

    # CALL MpngGnr_createMappingFile
    MpngGnr_createMappingFile($arxml_flxr_extract_href);
    return 1;
}

sub MpngGnr_createMappingFile {
    my @args = @_;

    my $arxml_flxr_extract_href = shift @args;

    my $allPdu_href     = $arxml_flxr_extract_href->{'PDUINFO'};
    my $allSignals_href = $arxml_flxr_extract_href->{'SIGNALINFO'};
    my $arxml_version   = $arxml_flxr_extract_href->{'ARXML_VERSION'};

    WrMpng_wr2outfile("package LIFT_PROJECT;\n\n");
    WrMpng_wr2outfile( "\$Defaults->{" . '"' . "Mapping_FLEXRAY" . '"' . "}" . " = { \n" );

    # CALL ARXML_getAutosarSchemaVersion write to mapping file
    WrMpng_wr2outfile( "'AUTOSAR_SCHEMA_VERSION'      => '" . $arxml_version . "', \n" );

    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("    'FR_PDU'  => { \n");
    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("# 1. Begin Definition of Received PDU's \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("################################################################################ \n");

    foreach my $pdu ( keys %{ $allPdu_href->{'FR_PDU'} } ) {

        WrMpng_wr2outfile( "      '" . $pdu . "'  => { \n" );
        WrMpng_wr2outfile( "                         'DLC'        => " . $allPdu_href->{'FR_PDU'}{$pdu}{'DLC'} . ", \n" );
        WrMpng_wr2outfile( "                         'FRAME_NAME' => '" . $allPdu_href->{'FR_PDU'}{$pdu}{'FRAME_NAME'} . "', \n" );
        WrMpng_wr2outfile( "                         'PDU_ID_SHORT_HEADER' => '" . $allPdu_href->{'FR_PDU'}{$pdu}{'PDU_ID_SHORT_HEADER'} . "', \n" )                       if defined $allPdu_href->{'FR_PDU'}{$pdu}{'PDU_ID_SHORT_HEADER'};
        WrMpng_wr2outfile( "                         'UPDATE-INDICATION-BIT-POSITION' => '" . $allPdu_href->{'FR_PDU'}{$pdu}{'UPDATE-INDICATION-BIT-POSITION'} . "', \n" ) if defined $allPdu_href->{'FR_PDU'}{$pdu}{'UPDATE-INDICATION-BIT-POSITION'};
        WrMpng_wr2outfile( "                         'START-BIT-POSITION' => '" . $allPdu_href->{'FR_PDU'}{$pdu}{'START-POSITION'} . "', \n" )                             if defined $allPdu_href->{'FR_PDU'}{$pdu}{'START-POSITION'};
        WrMpng_wr2outfile( "                         'SENDER'     => '' , \n");
        WrMpng_wr2outfile( "                         'CYCLE' => '" . $allPdu_href->{'FR_PDU'}{$pdu}{'CYCLE_TIME_S'} * 1000 . "', #ms \n" );
        WrMpng_wr2outfile( "                         'CANOE_DISABLE'      => 'EnvStart" . $pdu . "', \n" );
        WrMpng_wr2outfile("                         },\n");
    }

    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("# 1. End Definition Received PDU's \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("              }, \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("################################################################################ \n");

    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("# 2. Beginning of RECIEVE signal Definition \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("################################################################################ \n");

    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("# 2. Beginning of RECIEVE signal Definition \n");
    WrMpng_wr2outfile("# \n");
    WrMpng_wr2outfile("################################################################################ \n");

    foreach my $signal ( sort keys %{ $allSignals_href->{'SIGNALS'} } ) {
        print "$signal = $allSignals_href->{'SIGNALS'}{$signal} \n";

        my @signal_short_name = split( /~~/, $signal ) if defined $signal;

        my $signal_key = $signal_short_name[1];
        $signal_key = $signal if ( GetSignalCounts_href()->{$signal_key} > 1 );

        WrMpng_wr2outfile( "        '" . $signal_key . "'  => { \n" );
        WrMpng_wr2outfile( "                         'SIGNAL_NAME'        =>  '" . $signal_short_name[1] . "', \n" );
        WrMpng_wr2outfile( "                         'FR_PDU_NAME'        =>  '" . $allSignals_href->{'SIGNALS'}{$signal}{'FR_PDU_NAME'} . "', \n" );
        WrMpng_wr2outfile("                         'SENDER'             =>  '' ,    \n");
        WrMpng_wr2outfile("                         'MULTIPLEX'          =>  undef, \n");
        WrMpng_wr2outfile( "                         'STARTBIT'           => '" . $allSignals_href->{'SIGNALS'}{$signal}{'STARTBIT'} . "', \n" );
        WrMpng_wr2outfile( "                         'LENGTH'             => '" . $allSignals_href->{'SIGNALS'}{$signal}{'LENGTH'} . "', \n" );
        WrMpng_wr2outfile( "                         'OFFSET'             => '" . $allSignals_href->{'SIGNALS'}{$signal}{'OFFSET'} . "', \n" );
        WrMpng_wr2outfile( "                         'FACTOR'             => '" . $allSignals_href->{'SIGNALS'}{$signal}{'FACTOR'} . "', \n" );
        WrMpng_wr2outfile( "                         'FORMAT'             => '" . $allSignals_href->{'SIGNALS'}{$signal}{'FORMAT'} . "', \n" );
        WrMpng_wr2outfile( "                         'TYPE'               => '" . $allSignals_href->{'SIGNALS'}{$signal}{'TYPE'} . "', \n" );
        WrMpng_wr2outfile("                         'UNIT'               => '', \n");
        WrMpng_wr2outfile("                                              }, \n");
    }

    WrMpng_wr2outfile("}; \n");
    WrMpng_wr2outfile("################################################################################ \n");
    WrMpng_wr2outfile("####################### end of FlexRay mapping ################################## \n");
    WrMpng_wr2outfile("################################################################################# \n");
    WrMpng_wr2outfile("1; \n");

}

sub WrMpng_wr2outfile {
    my $text = shift;
    print "OUT : $text";
    print OUTFILE $text;
}

sub LaunhGUI {

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'

    my $main = MainWindow->new( "-background" => "#888888" );
    my $button;

    # define minimum size of main window 'main'
    $main->minsize( 800, 100 );

    # create title in main window 'main'
    $main->title($MAPP_FILE_VERSION);

    ##------------------------------------------------------------------
    ## create frame 'F1' in main window 'main'
    ##------------------------------------------------------------------
    my $Frame1 = $main->Frame( "-background" => "honeydew4" )->pack(
        "-side"   => 'top',
        "-expand" => 1,
        "-fill"   => 'both',
    );

    ##------------------------------------------------------------------
    ## create frame 'F2' in main window 'main'
    ##------------------------------------------------------------------
    my $Frame2 = $main->Frame( "-background" => "honeydew4" )->pack(
        "-side" => 'bottom',
        "-fill" => 'x',
    );

    ##------------------------------------------------------------------
    ## write head line in frame 'F1'
    ##------------------------------------------------------------------
    $Frame1->Label(
        "-text"     => 'LIFT Prepare Flexray Mapping : Configuration Window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( "-side" => "top" );

    #Frame for keeping .csv file generated from Fibex/Autosar explorer and frame based
    my $frame1_csv = $Frame1->Frame( "-background" => "#888888", -relief => 'solid', -borderwidth => 1, )->pack(
        "-side"   => 'top',
        "-expand" => 0,
        "-fill"   => 'both',
        "-pady"   => 5,
        "-padx"   => 5,
    );

    ##------------------------------------------------------------------
    ## create Frame for choosing database file(.csv) for flexray with label, entry and button
    ##------------------------------------------------------------------
    my $Frame1_1 = $frame1_csv->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "Select the AUTOSAR arxml file : ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$input_arxml_file, -validate => 'focusout', -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            my $temp = $input_arxml_file;    # store old value
            $input_arxml_file = $main->getOpenFile(
                "-filetypes" => [ [ "Autosar arxml files", '.arxml' ], [ "All files", '.*' ] ],
                "-title" => "Fibex/Autosar file which have to be scanned",
                "-initialdir" => '.',
            );
            unless ($input_arxml_file) { $input_arxml_file = $temp; }    # if no new value, restore old one
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

    ##------------------------------------------------------------------
    ## create Frame for choosing output mapping file(.pm) for flexray with label, entry and button
    ##------------------------------------------------------------------
    $Frame1_1 = $frame1_csv->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "Flexray Mapping Output File(*.pm) ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95' )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$opt_output_file, -validate => 'focusout', -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $button = $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {

            my $temp = $opt_output_file;    # store old value
            $opt_output_file = $main->getSaveFile(
                "-filetypes" => [ [ "Perl modules", '.pm' ], [ "All files", '.*' ] ],
                "-title" => "Flexray Mapping Output Files",
                "-initialdir"  => '.',
                "-initialfile" => $output_FlexRay_mapping,
            );

            $opt_output_file = $opt_output_file . ".pm" if ( $opt_output_file && $opt_output_file !~ /^.+\.pm$/ );

            unless ($opt_output_file) { $opt_output_file = $temp; }    # if no new value, restore old one

        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

    ##------------------------------------------------------------------
    ## create exit and start buttons in frame 'F2'
    ##------------------------------------------------------------------
    $Frame2->Button(
        "-text"     => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        "-command"  => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        "-side"  => 'left',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );

    my $start_button = $Frame2->Button(
        "-text"     => "Create",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        "-command"  => sub {
            if ( -f $input_arxml_file and $opt_output_file ) {
                $opt_output_file = $opt_output_file . ".pm" if ( $opt_output_file && $opt_output_file !~ /^.+\.pm$/ );
                MpngGnr_start();
                WrMpng_wr2outfile("## Finished -> Press QUIT \n");
                close(OUTFILE);
                close(LOG);
            }
            else {
                ##------------------------------------------------------------------
                ## inform user that options are missing
                ##------------------------------------------------------------------
                $main->messageBox(
                    '-icon'    => "error",
                    '-type'    => "OK",
                    '-title'   => 'Error',
                    '-message' => "! not enough options defined ! at least arxml file and Output File are needed. ",
                );
            }
        }
      )->pack(
        "-side"  => 'right',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );
}

1;
