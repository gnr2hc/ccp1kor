#!perl -w

#****************************************************************************************************
#                                                                                                   *
# Copyright (c) 2013 Robert Bosch GmbH, Germany                                                     *
#               All rights reserved                                                                 *
#                                                                                                   *
#****************************************************************************************************                                                       *
#  $Source: Tools/Mappingfile_Generators/DiagMapping/Create_Diag_Mapping.pl $
#  $Revision: 1.3 $
#  $State: develop $                                                                               		
#****************************************************************************************************

use strict;
use warnings;
use Tk;
use Tk::Frame;
use Data::Dumper;
use Win32::File;
use File::Copy;
use File::Basename;
use Win32::OLE;
use Win32::OLE::Const;
use File::Find;
use File::Path;
use Getopt::Long;
use File::Glob ':glob';
use Cwd;
use Tk::LabFrame;
use Spreadsheet::ParseExcel;

my $NRC_map = {
    '10' => "generalReject",
    '11' => "serviceNotSupported",
    '12' => "subFunctionNotSupported",
    '13' => "incorrectMessageLengthOrInvalidFormat",
    "14" => "responseTooLong",
    "21" => "busyRepeatRequest",
    "22" => "conditionsNotCorrect",
    "24" => "requestSequenceError",
    "25" => "noResponseFromSubnetComponent",
    "26" => "failurePreventsExecutionOfRequestedAction",
    "31" => "requestOutOfRange",
    "33" => "securityAccessDenied",
    "35" => "invalidKey",
    "36" => "exceedNumberOfAttempts",
    "37" => "requiredTimeDelayNotExpired",
    "70" => "uploadDownloadNotAccepted",
    "71" => "transferDataSuspended",
    "72" => "generalProgrammingFailure",
    "73" => "wrongBlockSequenceCounter",
    "78" => "requestCorrectlyReceived_ResponsePending",
    "7E" => "subFunctionNotSupportedInActiveSession",
    "7F" => "serviceNotSupportedInActiveSession",
    "81" => "rpmTooHigh",
    "82" => "rpmTooLow",
    "83" => "engineIsRunning",
    "84" => "engineIsNotRunning",
    "85" => "engineRunTimeTooLow",
    "86" => "temperatureTooHigh",
    "87" => "temperatureTooLow",
    "88" => "vehicleSpeedTooHigh",
    "89" => "vehicleSpeedTooLow",
    "8A" => "throttle_PedalTooHigh",
    "8B" => "throttle_PedalTooLow",
    "8C" => "transmissionRangeNotInNeutral",
    "8D" => "transmissionRangeNotInGear",
    "8F" => "brakeSwitchNotClosed",
    "90" => "shifterLeverNotInPark",
    "91" => "torqueConverterClutchLocked",
    "92" => "voltageTooHigh",
    "93" => "voltageTooLow",
};

sub Creatre_About_Window() {
    my $mw = MainWindow->new( "-background" => "#888888" );
    $mw->minsize( 100, 25 );
    $mw->title("Help");

    #Making a text area
    my $txt = $mw->Scrolled( 'Text', -width => 100, -scrollbars => 'e' )->pack();

    $txt->delete( '1.0', 'end' );
    $txt->insert(
        'end', '
#   
#   DESCRIPTION:                               
#   This tool will generate a Diag mapping file from an exported excel sheet of SPR_DSM_ConfigTable              
#
#   FOLLOW THESE STEPS:
#   1. Export SPR to excel sheet: current SPR_DSM_ConfigTable->File->Export->Microsoft Office->Excel..
#   2. Check for these mandatory columns in excel sheet
#       ID
#       Type
#       Service description
#       Description
#       Additional Parameter
#       Addressing Mode
#       Preconditions Prohibiting Execution
#       Security Access
#       Session
#       Protocol
#
#   3. Add the missing columns/values if not present                                      
#  
#   REMARKS:                                    
#   1. TurboLIFT/Tools/Engine should be synced from MKS
#   2. TurboLIFT-Perl should have been installed using the _run_once.bat file               
#                                       
    '
    );

}
my ( $main,             $end_frame,           $path_frame_xls,         $path_frame_Lookup, $entry, $Diag_Lookup );
my ( $Designation_path, $ExcelFile_Name_Path, $LookupFile_Name_Path, @File_Select_Arr,     $status, );
my (
    $EDID_Start_Byte_From_Panel, $input_excel_File_Name,      $input_Lookup_File_Name,
    $EDR_Service_IDs,            $Diag_Request_ID_From_Panel, $Diag_Response_ID_From_Panel
);
my @EDR_Services_DID_Array;
my $DID_Value;
my ( $LastRow_input_data, $LastColoumn_input_data );

# Default Designation Path
$Designation_path = 'C:';
my $TK_ERROR_INDICATION_FLAG_i = 0;
my $project_name               = "";
$main = MainWindow->new( "-background" => "#888888" );

# Size to the TK window
$main->minsize( 450, 100 );

$main->title("Diag Mapping file Generator ");

# Get the current path
my $pwd = cwd();

#print "$pwd","\n";
my @path_structure;
@path_structure = split( /\//, $pwd );

# Remove the last Folder
#pop(@path_structure);
# Add the string with \\ to get the complete path
my $File_With_Path = join( "\\", @path_structure );
#print "File_With_Path =$File_With_Path", "\n";
$pwd =~ s/\//\\/g;
$pwd =~ s/\//\\/;

#Remove the files if is already present in the canoe folder

#Declare that there is a menu
my $mbar = $main->Menu();
$main->configure( -menu => $mbar );

#The Main Buttons
my $file = $mbar->cascade( -label => "File", -underline => 0, -tearoff => 0 );
my $help = $mbar->cascade( -label => "Help", -underline => 0, -tearoff => 0 );

## File Menu ##
$file->command(
    -label     => "Exit",
    -underline => 1,
    -command   => sub { exit }
);

#********************************************************************************************
$help->command( -label => "ReadMe", -command => sub { Creatre_About_Window() } );

$main->Label(
    -text       => 'Diag Mapping File Generator  ',
    -font       => '{Segoe UI} 15 bold',
    -background => '#888888',
    -foreground => 'white',
    -height     => '001'
)->pack( -side => 'top', -pady => '003' );

my $labeled_frame1 = $main->Frame(
    -borderwidth => 2,
    -relief      => 'groove',
    -background  => "#888888",
)->pack( -side => "top", -padx => '150', -anchor => 'nw' );

#my $shot = $main->Photo(-file => "$File_With_Path\\logo\\AUDI.gif");
#$main->Label(-image => $shot)->pack(-side => 'top');
$main->Label(
    -text       => 'NOTE: Select .xls file exported from SPR_DSM_ConfigTable',
    -font       => '{Segoe UI Semibold} 8 bold',
    -background => "#888888",
    -foreground => "white",
)->pack( -side => 'left', -padx => '120', -pady => '02', -side => 'top', -anchor => 'w' );

$path_frame_xls      = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '05', -anchor => 'nw' );
$path_frame_Lookup = $main->Frame( "-background" => "#888888" )->pack( -pady => '1', -padx => '05', -anchor => 'nw' );

$path_frame_xls->Label(
    -text       => 'Excel File:        ',
    -background => "#888888",
    -foreground => "blue1",
    -font       => '{Segoe UI} 12 '
)->pack( -side => 'left' );

$status = ' Not Started ';
$entry  = $path_frame_xls->Entry(
    -width        => '50',
    -textvariable => \$ExcelFile_Name_Path,
    -background   => "white",
    -foreground   => "black",
  )->pack(
    -side => 'left',
    -pady => '0'
  );

$path_frame_xls->Button(
    -text       => "Browse",
    -width      => '8',
    -relief     => 'groove',
    -background => "#333366",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 12 ',
    -command    => sub {
        $ExcelFile_Name_Path = $main->getOpenFile(
            -filetypes => [ [ "xls xlsx files", [ '.xlsx', '.xls' ] ], [ "xls xlsx files", [ '.xlsx', '.xls' ] ], ],
            -title => "Choose the xls file ",
        );

        if ($ExcelFile_Name_Path) {
            @File_Select_Arr = split( /\[/, $ExcelFile_Name_Path );
            $input_excel_File_Name = $File_Select_Arr[-1];
            print "Excel File Name =$input_excel_File_Name";
            $Designation_path = dirname($ExcelFile_Name_Path);
            $Designation_path = $Designation_path . "/";

        }

    }
)->pack( -side => "right", -padx => '05', -pady => '03' );

$path_frame_Lookup->Label(
    -text       => 'LookupTable: ',
    -background => "#888888",
    -foreground => "blue1",
    -font       => '{Segoe UI} 12 '
)->pack( -side => 'left' );

$entry = $path_frame_Lookup->Entry(
    -width        => '50',
    -textvariable => \$LookupFile_Name_Path,
    -background   => "white",
    -foreground   => "black",
  )->pack(
    -side => 'left',
    -pady => '1'
  );

$path_frame_Lookup->Button(
    -text       => "Browse",
    -width      => '8',
    -relief     => 'groove',
    -background => "#333366",
    -foreground => "white",
    -font       => '{Segoe UI Semibold} 12 ',
    -command    => sub {
        $LookupFile_Name_Path = $main->getOpenFile(
            -filetypes => [ [ "pm files", ['.pm'] ], [ "pm files", ['.pm'] ], ],
            -title => "Choose the pm file ",
        );

        if ($LookupFile_Name_Path) {
            @File_Select_Arr = split( /\[/, $LookupFile_Name_Path );
            $input_Lookup_File_Name = $File_Select_Arr[-1];
            print "Lookup File Name =$input_Lookup_File_Name";
            $Designation_path = dirname($LookupFile_Name_Path);
            $Designation_path = $Designation_path . "/";

        }

    }
)->pack( -side => "top", -padx => '06' );

$end_frame = $main->Frame( "-background" => "#888888" )->pack( -ipadx => '10', -padx => '2' );
$end_frame->Button(
    -text       => 'Exit',
    -width      => '8',
    -font       => '{Segoe UI Semibold} 12 ',
    -background => "Red4",
    -foreground => "white",
    -relief     => 'groove',
    -command    => [ $main => 'destroy' ]
)->pack( -pady => 10, -side => 'right' );

$end_frame->Button(
    -text       => 'Generate',
    -width      => '8',
    -font       => '{Segoe UI Semibold} 12 ',
    -foreground => "white",
    -relief     => 'groove',
    -background => "ForestGreen",
    -command    => sub { Generate_File() }
)->pack( -pady => 10, -padx => 10, -side => 'right' );

# create label in window 'main'
$main->Label(
    -textvariable => \$status,                        #reference to display the status
    -font         => '{Segoe UI Semibold} 12 bold',
    -background   => "#888888",
    -foreground   => "white",
)->pack( "-pady" => 6, -side => 'top' );

MainLoop;

sub Generate_File() {

    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    #            Error Handling from the GUI
    #@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if ( !$input_excel_File_Name ) {
        $main->messageBox(
            '-icon'    => "error",                     #qw/error info question warning/
            '-type'    => "OK",                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
            '-title'   => 'Attention',
            '-title'   => 'Attention',
            '-message' => "Select the *.xlsx files !"
        );

        $TK_ERROR_INDICATION_FLAG_i = 1;
        $main->update();
    }
    else {
        $status = ' Not Started ';
        $main->update();

        #SheetName of the Exported Decoder sheet
        my %input_data_Sheet = ( 'in_Data' => "Sheet1", );
        
        unless(open (Lookup,$input_Lookup_File_Name)){
            $status= "Select the LookupTable file !!";
            $main->update();
            die("Lookup file $input_Lookup_File_Name is not found!\n");
        }
        
        require $input_Lookup_File_Name;
        $Diag_Lookup = $DIAG_LOOKUPTABLE::TABLE;

        open( OUTPUT, ">Mapping_DIAG.pm" ) || die("Mapping_DIAG.pm could not be created!\n");
        #        open (ERRORLOG,">ErrorLog.txt") || die("ErrorLog.txt could not be created \n $_!");

        my ( @error_messages, @warning_messages );
        my $excel;
        my $input_WorkBook;
        my $input_WorkSheet;
        my %SPR_DATA_h;

        # Open the xls using the WIN OLE package
        use Win32::OLE qw(in with);
        use Win32::OLE::Const 'Microsoft Excel';
        $Win32::OLE::Warn = 3;

        # get already active Excel application or open new
        $excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new( 'Excel.Application', 'Quit' );

        #$excel->{DisplayAlerts}=0;
        $excel->{Visible} = 1;

        # open Excel file which comtain  the decoder information
        $input_WorkBook = $excel->Workbooks->Open("$input_excel_File_Name");

        # select workSheet number 1 (you can also select a workSheet by name)
        #$input_WorkSheet = $input_WorkBook->WorkSheets("$input_data_Sheet{'in_Data'}");
        $input_WorkSheet = $input_WorkBook->Worksheets(1);

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
        $LastRow_input_data = $input_WorkSheet->UsedRange->Find(
            {
                What            => "*",
                SearchDirection => xlPrevious,
                SearchOrder     => xlByRows
            }
        )->{Row};

        #        print "\nLast Row of input file =",$LastRow_input_data,"\n";

        $LastColoumn_input_data = $input_WorkSheet->UsedRange->Find(
            {
                What            => "*",
                SearchDirection => xlPrevious,
                SearchOrder     => xlByColumns
            }
        )->{Column};

        #        print "\nLast Coloumn of input file =",$LastColoumn_input_data,"\n";

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^

        #^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Status update in the GUI Window ^^^^^^^^^^^^^^^^^^^^^^^^
        $status = "Conversion in progress...";
        $main->update();

        my @MandatoryColumns = (
            qw(
              ID
              Type
              Service description
              Description
              Additional Parameter
              Addressing Mode
              Preconditions Prohibiting Execution
              Security Access
              Session
              Protocol
              )
        );

        my $heading_href;
        my @tmp;

        $heading_href = identifyColums($input_WorkSheet);

        #Check for mandatory Colums
        my $headingsFoundInExcel = join( ' | ', keys %$heading_href );

        my $skipFile_FLAG;
        $skipFile_FLAG = 0;
        foreach my $clmn (@MandatoryColumns) {
            if ( $headingsFoundInExcel !~ $clmn ) {
                print("ERROR: Mandatory Column: $clmn Not found in Excel Skipping File: $input_excel_File_Name !!!\n");
                $skipFile_FLAG = 1;
                last;
            }
        }
        if ( $skipFile_FLAG == 1 ) {
            next;    #Skip Current File Processing
        }

        #my ( $row_min, $row_max ) = $input_WorkSheet->row_range();
        my $row_min = 1;
        my $row_max = $LastRow_input_data;

        my $ActiveTestCaseName;
        for my $row ( ( $row_min + 1 ) .. $row_max ) {

            if (    ( defined $input_WorkSheet->Cells( $row, $heading_href->{'Type'}{'COLUMN'} ) )
                and ( $input_WorkSheet->Cells( $row, $heading_href->{'Type'}{'COLUMN'} ) )->{'Value'} !~ /Parameter/i )
            {
                next;

            }
            my $Service_description_Cell =
              $input_WorkSheet->Cells( $row, $heading_href->{'Service description'}{'COLUMN'} );
            my $Service_description;

            if ( defined $Service_description_Cell ) {
                $Service_description = $Service_description_Cell->{'Value'};

                next unless ( defined $Service_description );

                $Service_description =~ s/[\n\t ]//gi;    #remove additional NewLines and space and tab
                $SPR_DATA_h{$Service_description}{'Type'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Type'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Type'}{'COLUMN'} );

                $SPR_DATA_h{$Service_description}{'ID'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'ID'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'ID'}{'COLUMN'} );
                $SPR_DATA_h{$Service_description}{'Description'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Description'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Description'}{'COLUMN'} );
                if ( defined $input_WorkSheet->Cells( $row, $heading_href->{'Additional Parameter'}{'COLUMN'} ) ) {
                    $SPR_DATA_h{$Service_description}{'Additional Parameter'} =
                      ( $input_WorkSheet->Cells( $row, $heading_href->{'Additional Parameter'}{'COLUMN'} ) )->{'Value'};
                }
                else {
                    $SPR_DATA_h{$Service_description}{'Additional Parameter'} = 'none';
                }

                $SPR_DATA_h{$Service_description}{'Addressing Mode'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Addressing Mode'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Addressing Mode'}{'COLUMN'} );
                $SPR_DATA_h{$Service_description}{'Preconditions Prohibiting Execution'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Preconditions Prohibiting Execution'}{'COLUMN'} ) )
                  ->{'Value'}
                  if defined $input_WorkSheet->Cells( $row,
                    $heading_href->{'Preconditions Prohibiting Execution'}{'COLUMN'} );
                $SPR_DATA_h{$Service_description}{'Security Access'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Security Access'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Security Access'}{'COLUMN'} );
                $SPR_DATA_h{$Service_description}{'Session'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Session'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Session'}{'COLUMN'} );
                $SPR_DATA_h{$Service_description}{'Protocol'} =
                  ( $input_WorkSheet->Cells( $row, $heading_href->{'Protocol'}{'COLUMN'} ) )->{'Value'}
                  if defined $input_WorkSheet->Cells( $row, $heading_href->{'Protocol'}{'COLUMN'} ); 

                #To remove new line to spaces
                foreach ( keys %{ $SPR_DATA_h{$Service_description} } ) {
                    next unless ( defined $Service_description );

                    #next if ($_ eq 'Description');#skip for Description as multi line is easier to read
                    if ( $_ eq 'Description' ) {
                        $SPR_DATA_h{$Service_description}{'Description'} =~ s/This contains an example.*//;
                        $SPR_DATA_h{$Service_description}{'Description'} =~ s/[ \$\r\n]//g;
                        chomp( $SPR_DATA_h{$Service_description}{'Description'} );
                        my $n = 2;
                        my @temp = unpack "a$n" x ( length( $SPR_DATA_h{$Service_description}{$_} ) / $n ),
                          $SPR_DATA_h{$Service_description}{$_};
                        $SPR_DATA_h{$Service_description}{$_} = join( ' ', @temp );
                    }
                    
                    $SPR_DATA_h{$Service_description}{$_} =~ s/\n/,/g
                      if ( defined $SPR_DATA_h{$Service_description}{$_} );

                    if ( $_ eq 'Addressing Mode' ) {
                        $SPR_DATA_h{$Service_description}{$_} = lc( $SPR_DATA_h{$Service_description}{$_} );
                        $SPR_DATA_h{$Service_description}{$_} =~ s/ //g;    #remove Space
                        my @list = split( ',', $SPR_DATA_h{$Service_description}{$_} );
                        foreach my $a (@list) { $a = "'$a'"; }
                        $SPR_DATA_h{$Service_description}{$_} = join( ', ', @list );
                    }
                    if ( $_ eq 'Preconditions Prohibiting Execution' ) {

               #                    $SPR_DATA_h{$Service_description}{$_} = lc( $SPR_DATA_h{$Service_description}{$_} );
               #                    $SPR_DATA_h{$Service_description}{$_} =~ s/ //g;    #remove Space
                        my @list = split( ',', $SPR_DATA_h{$Service_description}{$_} );
                        foreach my $a (@list) { $a = "'$a'"; }
                        $SPR_DATA_h{$Service_description}{$_} = join( ', ', @list );
                    }
                    if ( $_ eq 'Security Access' ) {
                        $SPR_DATA_h{$Service_description}{$_} =~ s/ //g;    #remove Space
                        my @list = split( ',', $SPR_DATA_h{$Service_description}{$_} );
                        foreach my $a (@list) { $a = "'$a'"; }
                        $SPR_DATA_h{$Service_description}{$_} = join( ', ', @list );
                    }
                    if ( $_ eq 'Session' ) {
                        $SPR_DATA_h{$Service_description}{$_} =~ s/ //g;    #remove Space
                        my @list = split( ',', $SPR_DATA_h{$Service_description}{$_} );
                        foreach my $a (@list) { $a = "'$a'"; }
                        $SPR_DATA_h{$Service_description}{$_} = join( ', ', @list );
                    }
                }

            }
        }    #Row Loop

        my $service;

        foreach ( sort( keys %SPR_DATA_h ) ) {
            my @tempReq  = split( ' ', $SPR_DATA_h{$_}{'Description'} );
            my @tempServ = split( '_', $_ );
            my ( $byte0_SID, @remBytes ) = @tempReq;

#            my ( $servName, $subFuncName1, $subFuncName2 ) = @tempServ;
            my ( $servName, @subFun ) = @tempServ;
            $service->{$servName}{'Service_ID'} = $byte0_SID;
            $service->{$servName}{'Supported_SubFuns'}{ join( '_', @subFun ) } = join( ' ', @remBytes );
#            if ( defined $subFuncName2 ) {
#                $service->{$servName}{'Supported_SubFuns'}{ $subFuncName1 . "_$subFuncName2" } = join( ' ', @remBytes );
#            }
#            elsif ( defined $subFuncName1 ) {
#                $service->{$servName}{'Supported_SubFuns'}{$subFuncName1} = join( ' ', @remBytes );
#            }
            $service->{$servName}{'NEG_Responses'} = $Diag_Lookup->{'Service_Supported_NRCs'}{"Service_$byte0_SID"};
        }


        print OUTPUT "#### This file is generated from SPR export by the Diag mapping generator tool #### \n\n";
        print OUTPUT "package LIFT_PROJECT; \n\n";
        print OUTPUT "######################################################### \n";
        print OUTPUT 'my $VERSION = q$Revision: 1.3 $;' . "\n";
        print OUTPUT "########################################################## \n\n";
        print OUTPUT '$Defaults->{"Mapping_DIAG"} = {' . "\n";


        print OUTPUT "\n\n############# PRJ_SUPPORTED_SERVICES ##################\n";
        print OUTPUT "\n'PRJ_SUPPORTED_SERVICES' => {\n";
        foreach ( sort { hex ($service->{$a}{'Service_ID'}) <=> hex($service->{$b}{'Service_ID'}) } keys %$service ) {
            print OUTPUT "\t'$_' => '$service->{$_}{'Service_ID'}',\n";
        }
        print OUTPUT "},\n";
        print OUTPUT "#---------------------------------------------------------#" . "\n";


        print OUTPUT "\n\n############# DIAG SERVICES ##################\n";
        print OUTPUT "\n'DIAG_SERVICES' => {\n\n";
        foreach ( sort { hex ($service->{$a}{'Service_ID'}) <=> hex($service->{$b}{'Service_ID'}) } keys %$service ) {
            print OUTPUT "\t'$_' => {\n";
            print OUTPUT "\t\t\t\t\t'Service_ID' => '$service->{$_}{'Service_ID'}',\n";

            _print_Hash_newline( 'Supported_SubFuns', $service->{$_}{'Supported_SubFuns'} );

            print OUTPUT "\t\t\t\t\t'NEG_Responses' => {\n";
            _print_NRCs( $service->{$_}{'Service_ID'}, $service->{$_}{'NEG_Responses'} )
              if ( defined $service->{$_}{'NEG_Responses'} );
            print OUTPUT "\t\t\t\t\t},\n";

            print OUTPUT "\t},\n";
            print OUTPUT "#----------------------------------------------------------------------------------#" . "\n";
        }
        print OUTPUT "\n},\n";
        print OUTPUT "##### END OF DIAG_SERVICES Section #######\n";


        print OUTPUT "\n\n######### Request Response Section ########\n";
        print OUTPUT "\n'Requests_Responses' => {\n\n";
        my %ReqResp_hash;
        
#        foreach ( sort { hex (substr( $SPR_DATA_h{$a}{'Description'}, 0, 2 )) <=> hex(substr( $SPR_DATA_h{$b}{'Description'}, 0, 2 )) } keys %SPR_DATA_h ) {
        foreach ( sort keys %SPR_DATA_h ) {
            #========================================add 0x40 to Service to generate positive respone
            my $SID;
            my @tempReq;
            @tempReq = split( ' ', $SPR_DATA_h{$_}{'Description'} );
            ($SID) = @tempReq;
            my $tempPstvResp = sprintf( "%02X", ( hex($SID) + hex(40) ) );
            splice( @tempReq, 0, 1 );
            if ($SID eq '85'){
                $tempPstvResp = $tempPstvResp." $tempReq[0]";
            }
            elsif($SID eq '14'){
                #do nothing (only 1 byte for $tempPstvResp)
            }
            else{
               $tempPstvResp = $tempPstvResp . ' ' . join( ' ', @tempReq ); 
            }

            #=======================================End of section to add 0x40 to Service to generate positive respone

            my ( $RequestString, $RequestString_3byte, $RequestString_2byte );
            $RequestString       = $SPR_DATA_h{$_}{'Description'};                                    #complete request
            $RequestString_3byte = substr( $RequestString, 0, 8 ) if ( length $RequestString > 5 );
            $RequestString_2byte = substr( $RequestString, 0, 5 ) if ( length $RequestString > 2 );

            if ( defined $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString} ) {
                $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ }{'Request'} =
                  "$RequestString " . $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString};
            }
            elsif ( defined $RequestString_3byte
                and defined $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString_3byte} )
            {
                $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ }{'Request'} =
                  "$RequestString " . $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString_3byte};
            }
            elsif ( defined $RequestString_2byte
                and defined $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString_2byte} )
            {
                $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ }{'Request'} =
                  "$RequestString " . $Diag_Lookup->{'Request_Input_Parameters'}{$RequestString_2byte};
            }
            elsif ( defined $Diag_Lookup->{'Request_Input_Parameters'}{$SID} ) {
                $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ }{'Request'} =
                  "$RequestString " . $Diag_Lookup->{'Request_Input_Parameters'}{$SID};
            }
            else {
                $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ }{'Request'} = $RequestString;
            }

            $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ }{'Response'} = $tempPstvResp;    #Response
            $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ }{'Mode'} = "relax";   #Mode by default all mode set to relax
            $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ }{'Desc'} =
              $_;    #Desc by default all mode set to same as service description
            $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ }{'DataLength'} = ''; #( scalar(@tempReq) + 1 );    #Desc by default all mode set to same as service description
            $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ }{'DoorsIDs'} = ["$SPR_DATA_h{$_}{'ID'}"];    #push Doors ID's

            print OUTPUT "\t'$_' => {\n";
            print OUTPUT "\t\t\t\t\t'Requests' => {\n";
            _print_Hash_Or_String( 'REQ_' . $_, $ReqResp_hash{$_}{'Requests'}{ 'REQ_' . $_ } );
            print OUTPUT "\t\t\t\t\t},\n";

            print OUTPUT "\t\t\t\t\t'POS_Responses' => {\n";
            _print_Hash_Or_String( 'PR_' . $_, $ReqResp_hash{$_}{'POS_Responses'}{ 'PR_' . $_ } );
            print OUTPUT "\t\t\t\t\t},\n";

            print OUTPUT "\t\t\t\t\t'protocol' => '$SPR_DATA_h{$_}{'Protocol'}',\n";
            print OUTPUT "\t\t\t\t\t'preconditions_prohibiting_execution' => ["
              . $SPR_DATA_h{$_}{'Preconditions Prohibiting Execution'} . "],\n";
            print OUTPUT "\t\t\t\t\t'allowed_in_sessions' => [" . $SPR_DATA_h{$_}{'Session'} . "],\n";
            print OUTPUT "\t\t\t\t\t'allowed_in_addressingmodes' => [" . $SPR_DATA_h{$_}{'Addressing Mode'} . "],\n";
            print OUTPUT "\t\t\t\t\t'allowed_in_securitylevels' => [" . $SPR_DATA_h{$_}{'Security Access'} . "],\n";
            print OUTPUT "\t\t\t\t\t'additional_parameter' => '$SPR_DATA_h{$_}{'Additional Parameter'}',\n";
            print OUTPUT "\t},\n";
            print OUTPUT "#----------------------------------------------------------------------------------#" . "\n";
        }

        print OUTPUT "\n},\n";
        print OUTPUT "##### END OF Request Response Section #######\n\n";
        
        
        print OUTPUT "\n\n############# GlobalNRC ##################\n";
        print OUTPUT "\n'GlobalNRC' => {\n";
        foreach ( sort keys %$NRC_map ) {
            print OUTPUT "\t'$_' => '$NRC_map->{$_}',\n";
        }
        print OUTPUT "},\n";
        print OUTPUT "#---------------------------------------------------------#" . "\n\n";
        
        
        print OUTPUT "};    #end of Mapping_DIAG\n";
        print OUTPUT "1;";

        close OUTPUT;
    }    #main File Loop

    #	print "\n\n##################PRESS ANY KEY TO EXIT##################\n\n";
    $status = "Completed! Press Exit \n";
    print "\n\nCompleted! Press Exit... \n";
    $main->update();    # sub
}

sub identifyColums {
    my $input_WorkSheet = shift;
    my %Heading_h;
    my $TopRow;
    my $CellValue;

    my $row_min = 1;
    my $col_min = 1;
    my $row_max = $LastRow_input_data;
    my $col_max = $LastColoumn_input_data;

    $TopRow = $row_min;
    for my $col ( $col_min .. $col_max ) {
        my $cell = $input_WorkSheet->Cells( $TopRow, $col );
        $CellValue = $cell->{'Value'};

        $Heading_h{$CellValue}{'ROW'}    = $TopRow;
        $Heading_h{$CellValue}{'COLUMN'} = $col;
    }

    return \%Heading_h;
}

sub _print_Hash_Or_String {
    my $mainKeyText     = shift;
    my $variableToPrint = shift;

    if ( ref($variableToPrint) eq 'HASH' ) {
        print OUTPUT "\t\t\t\t\t\t'$mainKeyText' => {";    #open ReportingByte
        foreach my $key ( sort keys %{$variableToPrint} ) {
            my $value = $variableToPrint->{$key};
            if ( ref($value) eq 'ARRAY' ){
                my $listString = "'".join( "', '", @$value)."'";
                print OUTPUT "'$key' => [$listString], ";
            } 
            else{
                print OUTPUT "'$key' => '$value', ";
            }
        }
        print OUTPUT "},\n";                               #close ReportingByte
    }
    else {
        print OUTPUT "\t\t\t\t\t\t'$mainKeyText' => '$variableToPrint',\n";
    }

    return 1;
}

sub _print_Hash_newline {
    my $mainKeyText     = shift;
    my $variableToPrint = shift;

    if ( ref($variableToPrint) eq 'HASH' ) {
        print OUTPUT "\t\t\t\t\t'$mainKeyText' => {\n";    #open ReportingByte
        foreach my $key ( sort keys %{$variableToPrint} ) {
            my $value = $variableToPrint->{$key};
            print OUTPUT "\t\t\t\t\t\t\t\t'$key' => '$value', \n" if ( defined $key );
        }
        print OUTPUT "\t\t\t\t\t},\n";                     #close ReportingByte
    }
    else {
        print OUTPUT "\t\t\t\t\t'$mainKeyText' => {},\n";
    }

    return 1;
}

sub _print_NRCs {
    my $SID  = shift;
    my $NRCs = shift;

    foreach ( sort @$NRCs ) {
        my $NRC_desc = $NRC_map->{$_};
        my $nrc_addrModes = "'".join( "', '", @{$Diag_Lookup->{'NRC_Supported_AddressingModes'}{"NRC_$_"}})."'";
            print OUTPUT
"\t\t\t\t\t\t\t\t'NR_$NRC_desc' => { 'Response' =>  '7F $SID $_' , 'Mode' =>  'strict' , 'Desc' =>  '$NRC_desc' , 'AddrModes' => [ $nrc_addrModes ]},\n";
    }

    return 1;
}

