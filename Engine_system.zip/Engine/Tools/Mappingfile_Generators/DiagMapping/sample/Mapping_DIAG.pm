#### This file is generated from SPR export by the Diag mapping generator tool #### 

package LIFT_PROJECT; 

######################################################### 
my $VERSION = q$Revision: 1.2 $;
########################################################## 

$Defaults->{"Mapping_DIAG"} = {


############# PRJ_SUPPORTED_SERVICES ##################

'PRJ_SUPPORTED_SERVICES' => {
	'DiagnosticSessionControl' => '10',
	'ECUReset' => '11',
	'ClearDTCInformation' => '14',
	'ReadDTCInformation' => '19',
	'ReadDataByIdentifier' => '22',
	'SecurityAccess' => '27',
	'CommunicationControl' => '28',
	'WriteDataByIdentifier' => '2E',
	'inputOutputControlParameter' => '2F',
	'RoutineControl' => '31',
	'TesterPresent' => '3E',
	'ControlDTCSetting' => '85',
},
#---------------------------------------------------------#


############# DIAG SERVICES ##################

'DIAG_SERVICES' => {

	'DiagnosticSessionControl' => {
					'Service_ID' => '10',
					'Supported_SubFuns' => {
								'DefaultSession' => '01', 
								'DefaultSession_ForDisposal' => '01', 
								'ExtendedSession' => '03', 
								'SafetySession' => '04', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 10 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 10 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 10 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 10 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 10 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 10 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ECUReset' => {
					'Service_ID' => '11',
					'Supported_SubFuns' => {
								'FastSoftReset' => '63', 
								'HardReset_ForDisposal' => '01', 
								'NormalHardReset' => '01', 
								'NormalSoftReset' => '03', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 11 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 11 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 11 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 11 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 11 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 11 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 11 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_subFunctionNotSupportedInActiveSession' => { 'Response' =>  '7F 11 7E' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 11 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ClearDTCInformation' => {
					'Service_ID' => '14',
					'Supported_SubFuns' => {
								'all' => 'FF FF FF', 
					},
					'NEG_Responses' => {
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 14 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 14 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 14 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 14 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 14 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 14 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 14 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation' => {
					'Service_ID' => '19',
					'Supported_SubFuns' => {
								'ReportDtcSnapshotRecordByDtcNumber' => '04', 
								'ReportDtcsByStatusMask' => '02', 
								'ReportNumberOfDtcByStatusMask' => '01', 
								'ReportSupportedDtcs' => '0A', 
								'RepotDtcExtDataRecordByDtcNumber' => '06', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 19 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 19 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 19 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 19 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 19 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 19 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier' => {
					'Service_ID' => '22',
					'Supported_SubFuns' => {
								'2000' => '20 00', 
								'3000' => '30 00', 
								'3001' => '30 01', 
								'3100' => '31 00', 
								'3101' => '31 01', 
								'4000' => '40 00', 
								'4001' => '40 01', 
								'4003' => '40 03', 
								'4009' => '40 09', 
								'4100' => '41 00', 
								'4101' => '41 01', 
								'4103' => '41 03', 
								'4109' => '41 09', 
								'5000' => '50 00', 
								'5001' => '50 01', 
								'5003' => '50 03', 
								'5004' => '50 04', 
								'5B02' => '5B 02', 
								'6001' => '60 01', 
								'AddressInformation' => 'FA 12', 
								'AddressInformationOfPCU' => 'FA 02', 
								'D112' => 'D1 12', 
								'DeploymentLoopTable' => 'FA 06', 
								'DeploymentMethodVersion' => 'FA 01', 
								'DismantlerInfo' => 'FA 07', 
								'EDREntry01' => 'FA 13', 
								'EDREntry02' => 'FA 14', 
								'EDREntry03' => 'FA 15', 
								'EDREntry04' => 'FA 16', 
								'EDREntry05' => 'FA 17', 
								'EDREntry06' => 'FA 18', 
								'EDRIdentification' => 'FA 11', 
								'F186' => 'F1 86', 
								'F190' => 'F1 90', 
								'NumberOfEDRDevices' => 'FA 10', 
								'NumberOfPCU' => 'FA 00', 
								'OEMSpecificAddressInformation' => '10 12', 
								'OEMSpecificEDREntry01' => '10 13', 
								'OEMSpecificEDREntry02' => '10 14', 
								'OEMSpecificEDREntry03' => '10 15', 
								'OEMSpecificEDREntry04' => '10 16', 
								'OEMSpecificEDREntry05' => '10 17', 
								'OEMSpecificEDREntry06' => '10 18', 
								'OEMSpecificEDRIdentification' => '10 11', 
								'OEMSpecificNumberOfEDRDevices' => '10 10', 
								'VIN_ForDisposal' => 'F1 90', 
					},
					'NEG_Responses' => {
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 22 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_responseTooLong' => { 'Response' =>  '7F 22 14' , 'Mode' =>  'strict' , 'Desc' =>  'responseTooLong' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 22 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 22 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 22 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 22 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 22 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 22 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess' => {
					'Service_ID' => '27',
					'Supported_SubFuns' => {
								'RequestSeed_Deployment' => '5F', 
								'RequestSeed_Level1' => '01', 
								'RequestSeed_Level2' => '03', 
								'SendKey_Deployment' => '60', 
								'SendKey_Level1' => '02', 
								'SendKey_Level2' => '04', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 27 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 27 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 27 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 27 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestSequenceError' => { 'Response' =>  '7F 27 24' , 'Mode' =>  'strict' , 'Desc' =>  'requestSequenceError' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 27 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_invalidKey' => { 'Response' =>  '7F 27 35' , 'Mode' =>  'strict' , 'Desc' =>  'invalidKey' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_exceedNumberOfAttempts' => { 'Response' =>  '7F 27 36' , 'Mode' =>  'strict' , 'Desc' =>  'exceedNumberOfAttempts' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requiredTimeDelayNotExpired' => { 'Response' =>  '7F 27 37' , 'Mode' =>  'strict' , 'Desc' =>  'requiredTimeDelayNotExpired' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 27 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 27 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl' => {
					'Service_ID' => '28',
					'Supported_SubFuns' => {
								'CommunicationControl_EnableRxAndDisableTx' => '01', 
								'CommunicationControl_EnableRxAndTx' => '00', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 28 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 28 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 28 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 28 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 28 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 28 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 28 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier' => {
					'Service_ID' => '2E',
					'Supported_SubFuns' => {
								'DismantlerInfo' => 'FA 07', 
								'EOL' => '60 01', 
								'Generic' => '20 00', 
					},
					'NEG_Responses' => {
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 2E 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 2E 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 2E 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 2E 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 2E 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 2E 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 2E 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 2E 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'inputOutputControlParameter' => {
					'Service_ID' => '2F',
					'Supported_SubFuns' => {
								'FreezeCurrentState' => '2F 00 02', 
								'ResetCtrlToECU' => '2F 00 00', 
								'ResetToDefault' => '2F 00 01', 
								'ShortTermAdjustment' => '2F 00 03', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 2F 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 2F 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 2F 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 2F 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 2F 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 2F 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 2F 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 2F 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'RoutineControl' => {
					'Service_ID' => '31',
					'Supported_SubFuns' => {
								'RequestResults_CalculateSignatureOrCRC' => '03 E2 10', 
								'RequestResults_VDSCalibration' => '03 60 00', 
								'RequestRoutineResults_DeployLoopRoutineID' => '03 E2 01', 
								'RequestRoutineResults_ExecuteSPL' => '03 E2 00', 
								'StartRoutine_CalculateSignatureOrCRC' => '01 E2 10', 
								'StartRoutine_DeployLoopRoutineID' => '01 E2 01', 
								'StartRoutine_ExecuteSPL' => '01 E2 00', 
								'StartRoutine_VDSCalibration' => '01 60 00', 
								'StopRoutine_CalculateSignatureOrCRC' => '02 E2 10', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 31 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 31 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 31 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 31 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestSequenceError' => { 'Response' =>  '7F 31 24' , 'Mode' =>  'strict' , 'Desc' =>  'requestSequenceError' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 31 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_securityAccessDenied' => { 'Response' =>  '7F 31 33' , 'Mode' =>  'strict' , 'Desc' =>  'securityAccessDenied' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_generalProgrammingFailure' => { 'Response' =>  '7F 31 72' , 'Mode' =>  'strict' , 'Desc' =>  'generalProgrammingFailure' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 31 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 31 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'TesterPresent' => {
					'Service_ID' => '3E',
					'Supported_SubFuns' => {
								'zeroSubfunction' => '00', 
								'zeroSubfunction_ForDisposal' => '00', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 3E 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 3E 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting' => {
					'Service_ID' => '85',
					'Supported_SubFuns' => {
								'Off' => '02', 
								'On' => '01', 
					},
					'NEG_Responses' => {
								'NR_subFunctionNotSupported' => { 'Response' =>  '7F 85 12' , 'Mode' =>  'strict' , 'Desc' =>  'subFunctionNotSupported' , 'AddrModes' => [ 'physical' ]},
								'NR_incorrectMessageLengthOrInvalidFormat' => { 'Response' =>  '7F 85 13' , 'Mode' =>  'strict' , 'Desc' =>  'incorrectMessageLengthOrInvalidFormat' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_busyRepeatRequest' => { 'Response' =>  '7F 85 21' , 'Mode' =>  'strict' , 'Desc' =>  'busyRepeatRequest' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_conditionsNotCorrect' => { 'Response' =>  '7F 85 22' , 'Mode' =>  'strict' , 'Desc' =>  'conditionsNotCorrect' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestOutOfRange' => { 'Response' =>  '7F 85 31' , 'Mode' =>  'strict' , 'Desc' =>  'requestOutOfRange' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_requestCorrectlyReceived_ResponsePending' => { 'Response' =>  '7F 85 78' , 'Mode' =>  'strict' , 'Desc' =>  'requestCorrectlyReceived_ResponsePending' , 'AddrModes' => [ 'physical', 'functional' ]},
								'NR_serviceNotSupportedInActiveSession' => { 'Response' =>  '7F 85 7F' , 'Mode' =>  'strict' , 'Desc' =>  'serviceNotSupportedInActiveSession' , 'AddrModes' => [ 'physical', 'functional' ]},
					},
	},
#----------------------------------------------------------------------------------#

},
##### END OF DIAG_SERVICES Section #######


######### Request Response Section ########

'Requests_Responses' => {

	'ClearDTCInformation_all' => {
					'Requests' => {
						'REQ_ClearDTCInformation_all' => {'Request' => '14 FF FF FF', },
					},
					'POS_Responses' => {
						'PR_ClearDTCInformation_all' => {'DataLength' => '', 'Desc' => 'ClearDTCInformation_all', 'DoorsIDs' => ['SPR_ConfigTable236'], 'Mode' => 'relax', 'Response' => '54', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl_CommunicationControl_EnableRxAndDisableTx' => {
					'Requests' => {
						'REQ_CommunicationControl_CommunicationControl_EnableRxAndDisableTx' => {'Request' => '28 01 CommunicationType', },
					},
					'POS_Responses' => {
						'PR_CommunicationControl_CommunicationControl_EnableRxAndDisableTx' => {'DataLength' => '', 'Desc' => 'CommunicationControl_CommunicationControl_EnableRxAndDisableTx', 'DoorsIDs' => ['SPR_ConfigTable286'], 'Mode' => 'relax', 'Response' => '68 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'CommunicationControl_CommunicationControl_EnableRxAndTx' => {
					'Requests' => {
						'REQ_CommunicationControl_CommunicationControl_EnableRxAndTx' => {'Request' => '28 00 CommunicationType', },
					},
					'POS_Responses' => {
						'PR_CommunicationControl_CommunicationControl_EnableRxAndTx' => {'DataLength' => '', 'Desc' => 'CommunicationControl_CommunicationControl_EnableRxAndTx', 'DoorsIDs' => ['SPR_ConfigTable285'], 'Mode' => 'relax', 'Response' => '68 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting_Off' => {
					'Requests' => {
						'REQ_ControlDTCSetting_Off' => {'Request' => '85 02', },
					},
					'POS_Responses' => {
						'PR_ControlDTCSetting_Off' => {'DataLength' => '', 'Desc' => 'ControlDTCSetting_Off', 'DoorsIDs' => ['SPR_ConfigTable294'], 'Mode' => 'relax', 'Response' => 'C5 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ControlDTCSetting_On' => {
					'Requests' => {
						'REQ_ControlDTCSetting_On' => {'Request' => '85 01', },
					},
					'POS_Responses' => {
						'PR_ControlDTCSetting_On' => {'DataLength' => '', 'Desc' => 'ControlDTCSetting_On', 'DoorsIDs' => ['SPR_ConfigTable293'], 'Mode' => 'relax', 'Response' => 'C5 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_DefaultSession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_DefaultSession' => {'Request' => '10 01', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_DefaultSession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_DefaultSession', 'DoorsIDs' => ['SPR_ConfigTable218'], 'Mode' => 'relax', 'Response' => '50 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_DefaultSession_ForDisposal' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_DefaultSession_ForDisposal' => {'Request' => '10 01', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_DefaultSession_ForDisposal' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_DefaultSession_ForDisposal', 'DoorsIDs' => ['SPR_ConfigTable124'], 'Mode' => 'relax', 'Response' => '50 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_ExtendedSession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_ExtendedSession' => {'Request' => '10 03', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_ExtendedSession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_ExtendedSession', 'DoorsIDs' => ['SPR_ConfigTable219'], 'Mode' => 'relax', 'Response' => '50 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'DiagnosticSessionControl_SafetySession' => {
					'Requests' => {
						'REQ_DiagnosticSessionControl_SafetySession' => {'Request' => '10 04', },
					},
					'POS_Responses' => {
						'PR_DiagnosticSessionControl_SafetySession' => {'DataLength' => '', 'Desc' => 'DiagnosticSessionControl_SafetySession', 'DoorsIDs' => ['SPR_ConfigTable125'], 'Mode' => 'relax', 'Response' => '50 04', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'VehicleSpeedTooHighCheck', 'InitTestNotCompletedCheck', 'ProductionModeActiveCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ECUReset_FastSoftReset' => {
					'Requests' => {
						'REQ_ECUReset_FastSoftReset' => {'Request' => '11 63', },
					},
					'POS_Responses' => {
						'PR_ECUReset_FastSoftReset' => {'DataLength' => '', 'Desc' => 'ECUReset_FastSoftReset', 'DoorsIDs' => ['SPR_ConfigTable303'], 'Mode' => 'relax', 'Response' => '51 63', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ECUReset_HardReset_ForDisposal' => {
					'Requests' => {
						'REQ_ECUReset_HardReset_ForDisposal' => {'Request' => '11 01', },
					},
					'POS_Responses' => {
						'PR_ECUReset_HardReset_ForDisposal' => {'DataLength' => '', 'Desc' => 'ECUReset_HardReset_ForDisposal', 'DoorsIDs' => ['SPR_ConfigTable129'], 'Mode' => 'relax', 'Response' => '51 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ECUReset_NormalHardReset' => {
					'Requests' => {
						'REQ_ECUReset_NormalHardReset' => {'Request' => '11 01', },
					},
					'POS_Responses' => {
						'PR_ECUReset_NormalHardReset' => {'DataLength' => '', 'Desc' => 'ECUReset_NormalHardReset', 'DoorsIDs' => ['SPR_ConfigTable234'], 'Mode' => 'relax', 'Response' => '51 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ECUReset_NormalSoftReset' => {
					'Requests' => {
						'REQ_ECUReset_NormalSoftReset' => {'Request' => '11 03', },
					},
					'POS_Responses' => {
						'PR_ECUReset_NormalSoftReset' => {'DataLength' => '', 'Desc' => 'ECUReset_NormalSoftReset', 'DoorsIDs' => ['SPR_ConfigTable235'], 'Mode' => 'relax', 'Response' => '51 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {'Request' => '19 04 DTC DTCExtendedDataRecordNumber', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportDtcSnapshotRecordByDtcNumber', 'DoorsIDs' => ['SPR_ConfigTable239'], 'Mode' => 'relax', 'Response' => '59 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportDtcsByStatusMask' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportDtcsByStatusMask' => {'Request' => '19 02 DTCStatusMask', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportDtcsByStatusMask' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportDtcsByStatusMask', 'DoorsIDs' => ['SPR_ConfigTable237'], 'Mode' => 'relax', 'Response' => '59 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {'Request' => '19 01 DTCStatusMask', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportNumberOfDtcByStatusMask' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportNumberOfDtcByStatusMask', 'DoorsIDs' => ['SPR_ConfigTable240'], 'Mode' => 'relax', 'Response' => '59 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_ReportSupportedDtcs' => {
					'Requests' => {
						'REQ_ReadDTCInformation_ReportSupportedDtcs' => {'Request' => '19 0A', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_ReportSupportedDtcs' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_ReportSupportedDtcs', 'DoorsIDs' => ['SPR_ConfigTable241'], 'Mode' => 'relax', 'Response' => '59 0A', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {
					'Requests' => {
						'REQ_ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {'Request' => '19 06', },
					},
					'POS_Responses' => {
						'PR_ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber' => {'DataLength' => '', 'Desc' => 'ReadDTCInformation_RepotDtcExtDataRecordByDtcNumber', 'DoorsIDs' => ['SPR_ConfigTable238'], 'Mode' => 'relax', 'Response' => '59 06', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_2000' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_2000' => {'Request' => '22 20 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_2000' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_2000', 'DoorsIDs' => ['SPR_ConfigTable252'], 'Mode' => 'relax', 'Response' => '62 20 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_3000' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_3000' => {'Request' => '22 30 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_3000' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_3000', 'DoorsIDs' => ['SPR_ConfigTable253'], 'Mode' => 'relax', 'Response' => '62 30 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_3001' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_3001' => {'Request' => '22 30 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_3001' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_3001', 'DoorsIDs' => ['SPR_ConfigTable254'], 'Mode' => 'relax', 'Response' => '62 30 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_3100' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_3100' => {'Request' => '22 31 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_3100' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_3100', 'DoorsIDs' => ['SPR_ConfigTable255'], 'Mode' => 'relax', 'Response' => '62 31 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_3101' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_3101' => {'Request' => '22 31 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_3101' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_3101', 'DoorsIDs' => ['SPR_ConfigTable256'], 'Mode' => 'relax', 'Response' => '62 31 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4000' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4000' => {'Request' => '22 40 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4000' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4000', 'DoorsIDs' => ['SPR_ConfigTable257'], 'Mode' => 'relax', 'Response' => '62 40 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4001' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4001' => {'Request' => '22 40 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4001' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4001', 'DoorsIDs' => ['SPR_ConfigTable258'], 'Mode' => 'relax', 'Response' => '62 40 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4003' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4003' => {'Request' => '22 40 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4003' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4003', 'DoorsIDs' => ['SPR_ConfigTable259'], 'Mode' => 'relax', 'Response' => '62 40 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4009' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4009' => {'Request' => '22 40 09', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4009' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4009', 'DoorsIDs' => ['SPR_ConfigTable260'], 'Mode' => 'relax', 'Response' => '62 40 09', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4100' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4100' => {'Request' => '22 41 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4100' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4100', 'DoorsIDs' => ['SPR_ConfigTable261'], 'Mode' => 'relax', 'Response' => '62 41 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4101' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4101' => {'Request' => '22 41 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4101' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4101', 'DoorsIDs' => ['SPR_ConfigTable262'], 'Mode' => 'relax', 'Response' => '62 41 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4103' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4103' => {'Request' => '22 41 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4103' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4103', 'DoorsIDs' => ['SPR_ConfigTable263'], 'Mode' => 'relax', 'Response' => '62 41 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_4109' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_4109' => {'Request' => '22 41 09', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_4109' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_4109', 'DoorsIDs' => ['SPR_ConfigTable264'], 'Mode' => 'relax', 'Response' => '62 41 09', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_5000' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_5000' => {'Request' => '22 50 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_5000' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_5000', 'DoorsIDs' => ['SPR_ConfigTable265'], 'Mode' => 'relax', 'Response' => '62 50 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_5001' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_5001' => {'Request' => '22 50 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_5001' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_5001', 'DoorsIDs' => ['SPR_ConfigTable266'], 'Mode' => 'relax', 'Response' => '62 50 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_5003' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_5003' => {'Request' => '22 50 03', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_5003' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_5003', 'DoorsIDs' => ['SPR_ConfigTable267'], 'Mode' => 'relax', 'Response' => '62 50 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_5004' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_5004' => {'Request' => '22 50 04', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_5004' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_5004', 'DoorsIDs' => ['SPR_ConfigTable268'], 'Mode' => 'relax', 'Response' => '62 50 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_5B02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_5B02' => {'Request' => '22 5B 02', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_5B02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_5B02', 'DoorsIDs' => ['SPR_ConfigTable269'], 'Mode' => 'relax', 'Response' => '62 5B 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_6001' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_6001' => {'Request' => '22 60 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_6001' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_6001', 'DoorsIDs' => ['SPR_ConfigTable270'], 'Mode' => 'relax', 'Response' => '62 60 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_AddressInformation' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_AddressInformation' => {'Request' => '22 FA 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_AddressInformation' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_AddressInformation', 'DoorsIDs' => ['SPR_ConfigTable165'], 'Mode' => 'relax', 'Response' => '62 FA 12', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_AddressInformationOfPCU' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_AddressInformationOfPCU' => {'Request' => '22 FA 02', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_AddressInformationOfPCU' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_AddressInformationOfPCU', 'DoorsIDs' => ['SPR_ConfigTable136'], 'Mode' => 'relax', 'Response' => '62 FA 02', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_D112' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_D112' => {'Request' => '22 D1 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_D112' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_D112', 'DoorsIDs' => ['SPR_ConfigTable271'], 'Mode' => 'relax', 'Response' => '62 D1 12', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DeploymentLoopTable' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DeploymentLoopTable' => {'Request' => '22 FA 06', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DeploymentLoopTable' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DeploymentLoopTable', 'DoorsIDs' => ['SPR_ConfigTable137'], 'Mode' => 'relax', 'Response' => '62 FA 06', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DeploymentMethodVersion' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DeploymentMethodVersion' => {'Request' => '22 FA 01', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DeploymentMethodVersion' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DeploymentMethodVersion', 'DoorsIDs' => ['SPR_ConfigTable135'], 'Mode' => 'relax', 'Response' => '62 FA 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_DismantlerInfo' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_DismantlerInfo' => {'Request' => '22 FA 07', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_DismantlerInfo' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_DismantlerInfo', 'DoorsIDs' => ['SPR_ConfigTable138'], 'Mode' => 'relax', 'Response' => '62 FA 07', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry01' => {'Request' => '22 FA 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry01', 'DoorsIDs' => ['SPR_ConfigTable166'], 'Mode' => 'relax', 'Response' => '62 FA 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry02' => {'Request' => '22 FA 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry02', 'DoorsIDs' => ['SPR_ConfigTable167'], 'Mode' => 'relax', 'Response' => '62 FA 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry03' => {'Request' => '22 FA 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry03', 'DoorsIDs' => ['SPR_ConfigTable168'], 'Mode' => 'relax', 'Response' => '62 FA 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry04' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry04' => {'Request' => '22 FA 16', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry04' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry04', 'DoorsIDs' => ['SPR_ConfigTable169'], 'Mode' => 'relax', 'Response' => '62 FA 16', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry05' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry05' => {'Request' => '22 FA 17', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry05' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry05', 'DoorsIDs' => ['SPR_ConfigTable170'], 'Mode' => 'relax', 'Response' => '62 FA 17', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDREntry06' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDREntry06' => {'Request' => '22 FA 18', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDREntry06' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDREntry06', 'DoorsIDs' => ['SPR_ConfigTable171'], 'Mode' => 'relax', 'Response' => '62 FA 18', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_EDRIdentification' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_EDRIdentification' => {'Request' => '22 FA 11', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_EDRIdentification' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_EDRIdentification', 'DoorsIDs' => ['SPR_ConfigTable164'], 'Mode' => 'relax', 'Response' => '62 FA 11', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_F186' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_F186' => {'Request' => '22 F1 86', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_F186' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_F186', 'DoorsIDs' => ['SPR_ConfigTable272'], 'Mode' => 'relax', 'Response' => '62 F1 86', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_F190' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_F190' => {'Request' => '22 F1 90', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_F190' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_F190', 'DoorsIDs' => ['SPR_ConfigTable273'], 'Mode' => 'relax', 'Response' => '62 F1 90', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_NumberOfEDRDevices' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_NumberOfEDRDevices' => {'Request' => '22 FA 10', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_NumberOfEDRDevices' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_NumberOfEDRDevices', 'DoorsIDs' => ['SPR_ConfigTable163'], 'Mode' => 'relax', 'Response' => '62 FA 10', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_NumberOfPCU' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_NumberOfPCU' => {'Request' => '22 FA 00', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_NumberOfPCU' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_NumberOfPCU', 'DoorsIDs' => ['SPR_ConfigTable134'], 'Mode' => 'relax', 'Response' => '62 FA 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificAddressInformation' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificAddressInformation' => {'Request' => '22 10 12', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificAddressInformation' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificAddressInformation', 'DoorsIDs' => ['SPR_ConfigTable184'], 'Mode' => 'relax', 'Response' => '62 10 12', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry01' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry01' => {'Request' => '22 10 13', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry01' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry01', 'DoorsIDs' => ['SPR_ConfigTable185'], 'Mode' => 'relax', 'Response' => '62 10 13', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry02' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry02' => {'Request' => '22 10 14', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry02' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry02', 'DoorsIDs' => ['SPR_ConfigTable186'], 'Mode' => 'relax', 'Response' => '62 10 14', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry03' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry03' => {'Request' => '22 10 15', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry03' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry03', 'DoorsIDs' => ['SPR_ConfigTable187'], 'Mode' => 'relax', 'Response' => '62 10 15', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry04' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry04' => {'Request' => '22 10 16', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry04' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry04', 'DoorsIDs' => ['SPR_ConfigTable188'], 'Mode' => 'relax', 'Response' => '62 10 16', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry05' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry05' => {'Request' => '22 10 17', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry05' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry05', 'DoorsIDs' => ['SPR_ConfigTable189'], 'Mode' => 'relax', 'Response' => '62 10 17', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDREntry06' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDREntry06' => {'Request' => '22 10 18', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDREntry06' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDREntry06', 'DoorsIDs' => ['SPR_ConfigTable190'], 'Mode' => 'relax', 'Response' => '62 10 18', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificEDRIdentification' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificEDRIdentification' => {'Request' => '22 10 11', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificEDRIdentification' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificEDRIdentification', 'DoorsIDs' => ['SPR_ConfigTable183'], 'Mode' => 'relax', 'Response' => '62 10 11', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {'Request' => '22 10 10', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_OEMSpecificNumberOfEDRDevices', 'DoorsIDs' => ['SPR_ConfigTable182'], 'Mode' => 'relax', 'Response' => '62 10 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['Choosesession(s)(multiselection)'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'ReadDataByIdentifier_VIN_ForDisposal' => {
					'Requests' => {
						'REQ_ReadDataByIdentifier_VIN_ForDisposal' => {'Request' => '22 F1 90', },
					},
					'POS_Responses' => {
						'PR_ReadDataByIdentifier_VIN_ForDisposal' => {'DataLength' => '', 'Desc' => 'ReadDataByIdentifier_VIN_ForDisposal', 'DoorsIDs' => ['SPR_ConfigTable133'], 'Mode' => 'relax', 'Response' => '62 F1 90', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestResults_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_RequestResults_CalculateSignatureOrCRC' => {'Request' => '31 03 E2 10', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestResults_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestResults_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPR_ConfigTable177'], 'Mode' => 'relax', 'Response' => '71 03 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestResults_VDSCalibration' => {
					'Requests' => {
						'REQ_RoutineControl_RequestResults_VDSCalibration' => {'Request' => '31 03 60 00', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestResults_VDSCalibration' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestResults_VDSCalibration', 'DoorsIDs' => ['SPR_ConfigTable298'], 'Mode' => 'relax', 'Response' => '71 03 60 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['---'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {'Request' => '31 03 E2 01', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResults_DeployLoopRoutineID' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResults_DeployLoopRoutineID', 'DoorsIDs' => ['SPR_ConfigTable154'], 'Mode' => 'relax', 'Response' => '71 03 E2 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Level48'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_RequestRoutineResults_ExecuteSPL' => {
					'Requests' => {
						'REQ_RoutineControl_RequestRoutineResults_ExecuteSPL' => {'Request' => '31 03 E2 00', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_RequestRoutineResults_ExecuteSPL' => {'DataLength' => '', 'Desc' => 'RoutineControl_RequestRoutineResults_ExecuteSPL', 'DoorsIDs' => ['SPR_ConfigTable153'], 'Mode' => 'relax', 'Response' => '71 03 E2 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Level48'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {'Request' => '31 01 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPR_ConfigTable175'], 'Mode' => 'relax', 'Response' => '71 01 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_DeployLoopRoutineID' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_DeployLoopRoutineID' => {'Request' => '31 01 E2 01 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_DeployLoopRoutineID' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_DeployLoopRoutineID', 'DoorsIDs' => ['SPR_ConfigTable152'], 'Mode' => 'relax', 'Response' => '71 01 E2 01', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Level48'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_ExecuteSPL' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_ExecuteSPL' => {'Request' => '31 01 E2 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_ExecuteSPL' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_ExecuteSPL', 'DoorsIDs' => ['SPR_ConfigTable151'], 'Mode' => 'relax', 'Response' => '71 01 E2 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['Level48'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StartRoutine_VDSCalibration' => {
					'Requests' => {
						'REQ_RoutineControl_StartRoutine_VDSCalibration' => {'Request' => '31 01 60 00 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StartRoutine_VDSCalibration' => {'DataLength' => '', 'Desc' => 'RoutineControl_StartRoutine_VDSCalibration', 'DoorsIDs' => ['SPR_ConfigTable297'], 'Mode' => 'relax', 'Response' => '71 01 60 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['---'],
					'allowed_in_securitylevels' => ['---'],
	},
#----------------------------------------------------------------------------------#
	'RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {
					'Requests' => {
						'REQ_RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {'Request' => '31 02 E2 10 RoutineControlOption', },
					},
					'POS_Responses' => {
						'PR_RoutineControl_StopRoutine_CalculateSignatureOrCRC' => {'DataLength' => '', 'Desc' => 'RoutineControl_StopRoutine_CalculateSignatureOrCRC', 'DoorsIDs' => ['SPR_ConfigTable176'], 'Mode' => 'relax', 'Response' => '71 02 E2 10', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AlgoIsActiveOrCrashStorageInProgressCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_Deployment' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_Deployment' => {'Request' => '27 5F', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_Deployment' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_Deployment', 'DoorsIDs' => ['SPR_ConfigTable142'], 'Mode' => 'relax', 'Response' => '67 5F', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_Level1' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_Level1' => {'Request' => '27 01', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_Level1' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_Level1', 'DoorsIDs' => ['SPR_ConfigTable283'], 'Mode' => 'relax', 'Response' => '67 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_RequestSeed_Level2' => {
					'Requests' => {
						'REQ_SecurityAccess_RequestSeed_Level2' => {'Request' => '27 03', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_RequestSeed_Level2' => {'DataLength' => '', 'Desc' => 'SecurityAccess_RequestSeed_Level2', 'DoorsIDs' => ['SPR_ConfigTable284'], 'Mode' => 'relax', 'Response' => '67 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_Deployment' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_Deployment' => {'Request' => '27 60', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_Deployment' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_Deployment', 'DoorsIDs' => ['SPR_ConfigTable143'], 'Mode' => 'relax', 'Response' => '67 60', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_Level1' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_Level1' => {'Request' => '27 02 Key', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_Level1' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_Level1', 'DoorsIDs' => ['SPR_ConfigTable295'], 'Mode' => 'relax', 'Response' => '67 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'SecurityAccess_SendKey_Level2' => {
					'Requests' => {
						'REQ_SecurityAccess_SendKey_Level2' => {'Request' => '27 04 Key', },
					},
					'POS_Responses' => {
						'PR_SecurityAccess_SendKey_Level2' => {'DataLength' => '', 'Desc' => 'SecurityAccess_SendKey_Level2', 'DoorsIDs' => ['SPR_ConfigTable296'], 'Mode' => 'relax', 'Response' => '67 04', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['VehicleSpeedTooHighCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'TesterPresent_zeroSubfunction' => {
					'Requests' => {
						'REQ_TesterPresent_zeroSubfunction' => {'Request' => '3E 00', },
					},
					'POS_Responses' => {
						'PR_TesterPresent_zeroSubfunction' => {'DataLength' => '', 'Desc' => 'TesterPresent_zeroSubfunction', 'DoorsIDs' => ['SPR_ConfigTable217'], 'Mode' => 'relax', 'Response' => '7E 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['n/a'],
	},
#----------------------------------------------------------------------------------#
	'TesterPresent_zeroSubfunction_ForDisposal' => {
					'Requests' => {
						'REQ_TesterPresent_zeroSubfunction_ForDisposal' => {'Request' => '3E 00', },
					},
					'POS_Responses' => {
						'PR_TesterPresent_zeroSubfunction_ForDisposal' => {'DataLength' => '', 'Desc' => 'TesterPresent_zeroSubfunction_ForDisposal', 'DoorsIDs' => ['SPR_ConfigTable158'], 'Mode' => 'relax', 'Response' => '7E 00', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['n/a'],
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_DismantlerInfo' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_DismantlerInfo' => {'Request' => '2E FA 07 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_DismantlerInfo' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_DismantlerInfo', 'DoorsIDs' => ['SPR_ConfigTable147'], 'Mode' => 'relax', 'Response' => '6E FA 07', },
					},
					'protocol' => 'Disposal',
					'preconditions_prohibiting_execution' => ['IdleModeCheck', 'AutarkieModeCheck'],
					'allowed_in_sessions' => ['DefaultSession', 'SafetySession'],
					'allowed_in_addressingmodes' => ['physical'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_EOL' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_EOL' => {'Request' => '2E 60 01 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_EOL' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_EOL', 'DoorsIDs' => ['SPR_ConfigTable288'], 'Mode' => 'relax', 'Response' => '6E 60 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AutarkieModeCheck', 'InitTestNotCompletedCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
	},
#----------------------------------------------------------------------------------#
	'WriteDataByIdentifier_Generic' => {
					'Requests' => {
						'REQ_WriteDataByIdentifier_Generic' => {'Request' => '2E 20 00 Data', },
					},
					'POS_Responses' => {
						'PR_WriteDataByIdentifier_Generic' => {'DataLength' => '', 'Desc' => 'WriteDataByIdentifier_Generic', 'DoorsIDs' => ['SPR_ConfigTable287'], 'Mode' => 'relax', 'Response' => '6E 20 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['AutarkieModeCheck'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['None'],
	},
#----------------------------------------------------------------------------------#
	'inputOutputControlParameter_FreezeCurrentState' => {
					'Requests' => {
						'REQ_inputOutputControlParameter_FreezeCurrentState' => {'Request' => '2F 2F 00 02', },
					},
					'POS_Responses' => {
						'PR_inputOutputControlParameter_FreezeCurrentState' => {'DataLength' => '', 'Desc' => 'inputOutputControlParameter_FreezeCurrentState', 'DoorsIDs' => ['SPR_ConfigTable291'], 'Mode' => 'relax', 'Response' => '6F 2F 00 02', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
	},
#----------------------------------------------------------------------------------#
	'inputOutputControlParameter_ResetCtrlToECU' => {
					'Requests' => {
						'REQ_inputOutputControlParameter_ResetCtrlToECU' => {'Request' => '2F 2F 00 00', },
					},
					'POS_Responses' => {
						'PR_inputOutputControlParameter_ResetCtrlToECU' => {'DataLength' => '', 'Desc' => 'inputOutputControlParameter_ResetCtrlToECU', 'DoorsIDs' => ['SPR_ConfigTable289'], 'Mode' => 'relax', 'Response' => '6F 2F 00 00', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
	},
#----------------------------------------------------------------------------------#
	'inputOutputControlParameter_ResetToDefault' => {
					'Requests' => {
						'REQ_inputOutputControlParameter_ResetToDefault' => {'Request' => '2F 2F 00 01', },
					},
					'POS_Responses' => {
						'PR_inputOutputControlParameter_ResetToDefault' => {'DataLength' => '', 'Desc' => 'inputOutputControlParameter_ResetToDefault', 'DoorsIDs' => ['SPR_ConfigTable290'], 'Mode' => 'relax', 'Response' => '6F 2F 00 01', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
	},
#----------------------------------------------------------------------------------#
	'inputOutputControlParameter_ShortTermAdjustment' => {
					'Requests' => {
						'REQ_inputOutputControlParameter_ShortTermAdjustment' => {'Request' => '2F 2F 00 03', },
					},
					'POS_Responses' => {
						'PR_inputOutputControlParameter_ShortTermAdjustment' => {'DataLength' => '', 'Desc' => 'inputOutputControlParameter_ShortTermAdjustment', 'DoorsIDs' => ['SPR_ConfigTable292'], 'Mode' => 'relax', 'Response' => '6F 2F 00 03', },
					},
					'protocol' => 'UDS',
					'preconditions_prohibiting_execution' => ['None'],
					'allowed_in_sessions' => ['ExtendedSession'],
					'allowed_in_addressingmodes' => ['physical', 'functional'],
					'allowed_in_securitylevels' => ['Level1'],
	},
#----------------------------------------------------------------------------------#

},
##### END OF Request Response Section #######



############# GlobalNRC ##################

'GlobalNRC' => {
	'10' => 'generalReject',
	'11' => 'serviceNotSupported',
	'12' => 'subFunctionNotSupported',
	'13' => 'incorrectMessageLengthOrInvalidFormat',
	'14' => 'responseTooLong',
	'21' => 'busyRepeatRequest',
	'22' => 'conditionsNotCorrect',
	'24' => 'requestSequenceError',
	'25' => 'noResponseFromSubnetComponent',
	'26' => 'failurePreventsExecutionOfRequestedAction',
	'31' => 'requestOutOfRange',
	'33' => 'securityAccessDenied',
	'35' => 'invalidKey',
	'36' => 'exceedNumberOfAttempts',
	'37' => 'requiredTimeDelayNotExpired',
	'70' => 'uploadDownloadNotAccepted',
	'71' => 'transferDataSuspended',
	'72' => 'generalProgrammingFailure',
	'73' => 'wrongBlockSequenceCounter',
	'78' => 'requestCorrectlyReceived_ResponsePending',
	'7E' => 'subFunctionNotSupportedInActiveSession',
	'7F' => 'serviceNotSupportedInActiveSession',
	'81' => 'rpmTooHigh',
	'82' => 'rpmTooLow',
	'83' => 'engineIsRunning',
	'84' => 'engineIsNotRunning',
	'85' => 'engineRunTimeTooLow',
	'86' => 'temperatureTooHigh',
	'87' => 'temperatureTooLow',
	'88' => 'vehicleSpeedTooHigh',
	'89' => 'vehicleSpeedTooLow',
	'8A' => 'throttle_PedalTooHigh',
	'8B' => 'throttle_PedalTooLow',
	'8C' => 'transmissionRangeNotInNeutral',
	'8D' => 'transmissionRangeNotInGear',
	'8F' => 'brakeSwitchNotClosed',
	'90' => 'shifterLeverNotInPark',
	'91' => 'torqueConverterClutchLocked',
	'92' => 'voltageTooHigh',
	'93' => 'voltageTooLow',
},
#---------------------------------------------------------#

};    #end of Mapping_DIAG
1;