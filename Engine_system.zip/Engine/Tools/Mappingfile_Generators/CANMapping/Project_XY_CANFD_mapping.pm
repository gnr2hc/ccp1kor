### file generated with Mappingfile_Generators/CANMapping/LIFT_prepare_CAN_mapping.pl 1.8 2017/06/15 15:29:22IST Prabhu Pallavi Maruti (RBEI/ESA-PP3) (RBP6KOR) release  
### input dbc files:
### C:/TurboLIFT/Tools/Mappingfile_Generators/CANMapping/CAN_FD_Powertrain.dbc
package LIFT_PROJECT;

$Defaults->{"Mapping_CAN"} = {
'NODE_UNDER_TEST'       => 'Airbag',

'Diag_Byte_1'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_1',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'Diag_Byte_2'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_2',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_3'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_3',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 23, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_4'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_4',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 31, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_5'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_5',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 39, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_6'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_6',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 47, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_7'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_7',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },
'Diag_Byte_8'  =>
               {
               'SIGNAL_NAME'   => 'Diag_Byte_8',
               'SENDER'        => 'AB_ECU',
               'MESSAGE'       => 'Can_ABECU_2_Diag',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 63, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'PD_req_2' =>
               {
               'SIGNAL_NAME'   => 'PD_req_2',  
               'SENDER'        => 'Tester',
               'MESSAGE'       => 'Can_PDiag_2_ABECU',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               },

'CAN_MESSAGES'  => {
       'MLC_A3'  =>
                      {
                        'ID'            => 163,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A2'  =>
                      {
                        'ID'            => 162,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A1'  =>
                      {
                        'ID'            => 161,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_A4'  =>
                      {
                        'ID'            => 164,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'MLC_110'  =>
                      {
                        'ID'            => 272,
                        'DLC'           => 6,
                        'SENDER'        => 'MLC',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_101'  =>
                      {
                        'ID'            => 257,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_102'  =>
                      {
                        'ID'            => 258,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_201'  =>
                      {
                        'ID'            => 513,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },
       'IDX_202'  =>
                      {
                        'ID'            => 514,
                        'DLC'           => 6,
                        'SENDER'        => 'IDX',
                        'CAN_BUS_NBR'   => 2,
                        'CYCLE'         => 10,
                      },

       'EngineData'  =>
                      {
                        'ID'            => 100,
                        'DLC'           => 64,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvEngineDataTo_' ,
                        'CANOE_DLC'     => 'EnvEngineDataDlc_' ,
                        'CANOE_TIMING'  => 'EnvEngineDataTime_' ,
                      },
       'EngineStatus'  =>
                      {
                        'ID'            => 101,
                        'DLC'           => 24,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvEngineStatusTo_' ,
                        'CANOE_DLC'     => 'EnvEngineStatusDlc_' ,
                        'CANOE_TIMING'  => 'EnvEngineStatusTime_' ,
                      },
       'Diag_Request'  =>
                      {
                        'ID'            => 512,
                        'DLC'           => 8,
                        'SENDER'        => 'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvDiag_RequestTo_' ,
                        'CANOE_DLC'     => 'EnvDiag_RequestDlc_' ,
                        'CANOE_TIMING'  => 'EnvDiag_RequestTime_' ,
                      },
       'GearBoxInfo'  =>
                      {
                        'ID'            => 1020,
                        'DLC'           => 32,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 50,
                        'CANOE_DISABLE' => 'EnvGearBoxInfoTo_' ,
                        'CANOE_DLC'     => 'EnvGearBoxInfoDlc_' ,
                        'CANOE_TIMING'  => 'EnvGearBoxInfoTime_' ,
                      },
       'Diag_Response'  =>
                      {
                        'ID'            => 1024,
                        'DLC'           => 8,
                        'SENDER'        => 'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvDiag_ResponseTo_' ,
                        'CANOE_DLC'     => 'EnvDiag_ResponseDlc_' ,
                        'CANOE_TIMING'  => 'EnvDiag_ResponseTime_' ,
                      },
       'NM_Gateway_PowerTrain'  =>
                      {
                        'ID'            => 1306,
                        'DLC'           => 4,
                        'SENDER'        => 'Gateway',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvNM_Gateway_PowerTrainTo_' ,
                        'CANOE_DLC'     => 'EnvNM_Gateway_PowerTrainDlc_' ,
                        'CANOE_TIMING'  => 'EnvNM_Gateway_PowerTrainTime_' ,
                      },
       'NM_Engine'  =>
                      {
                        'ID'            => 1307,
                        'DLC'           => 4,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvNM_EngineTo_' ,
                        'CANOE_DLC'     => 'EnvNM_EngineDlc_' ,
                        'CANOE_TIMING'  => 'EnvNM_EngineTime_' ,
                      },
       'DiagRequest_Motor'  =>
                      {
                        'ID'            => 1537,
                        'DLC'           => 8,
                        'SENDER'        => 'Gateway',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvDiagRequest_MotorTo_' ,
                        'CANOE_DLC'     => 'EnvDiagRequest_MotorDlc_' ,
                        'CANOE_TIMING'  => 'EnvDiagRequest_MotorTime_' ,
                      },
       'DiagResponse_Motor'  =>
                      {
                        'ID'            => 1544,
                        'DLC'           => 8,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvDiagResponse_MotorTo_' ,
                        'CANOE_DLC'     => 'EnvDiagResponse_MotorDlc_' ,
                        'CANOE_TIMING'  => 'EnvDiagResponse_MotorTime_' ,
                      },
       'DropOutMessage'  =>
                      {
                        'ID'            => 1792,
                        'DLC'           => 32,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvDropOutMessageTo_' ,
                        'CANOE_DLC'     => 'EnvDropOutMessageDlc_' ,
                        'CANOE_TIMING'  => 'EnvDropOutMessageTime_' ,
                      },
       'FallbackMessage'  =>
                      {
                        'ID'            => 1793,
                        'DLC'           => 12,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvFallbackMessageTo_' ,
                        'CANOE_DLC'     => 'EnvFallbackMessageDlc_' ,
                        'CANOE_TIMING'  => 'EnvFallbackMessageTime_' ,
                      },
       'Test_Message_CAN_FD'  =>
                      {
                        'ID'            => 2047,
                        'DLC'           => 64,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 100,
                        'CANOE_DISABLE' => 'EnvTest_Message_CAN_FDTo_' ,
                        'CANOE_DLC'     => 'EnvTest_Message_CAN_FDDlc_' ,
                        'CANOE_TIMING'  => 'EnvTest_Message_CAN_FDTime_' ,
                      },
       'ABSdata'  =>
                      {
                        'ID'            => 2147535173,
                        'DLC'           => 12,
                        'SENDER'        => 'Engine',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 50,
                        'CANOE_DISABLE' => 'EnvABSdataTo_' ,
                        'CANOE_DLC'     => 'EnvABSdataDlc_' ,
                        'CANOE_TIMING'  => 'EnvABSdataTime_' ,
                      },
       'Ignition_Info'  =>
                      {
                        'ID'            => 2147555696,
                        'DLC'           => 48,
                        'SENDER'        => 'Gateway',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 50,
                        'CANOE_DISABLE' => 'EnvIgnition_InfoTo_' ,
                        'CANOE_DLC'     => 'EnvIgnition_InfoDlc_' ,
                        'CANOE_TIMING'  => 'EnvIgnition_InfoTime_' ,
                      },
       'VECTOR__INDEPENDENT_SIG_MSG'  =>
                      {
                        'ID'            => 3221225472,
                        'DLC'           => 0,
                        'SENDER'        => 'Vector__XXX',
                        'CAN_BUS_NBR'   => 1,
                        'CYCLE'         => 10,
                        'CANOE_DISABLE' => 'EnvVECTOR__INDEPENDENT_SIG_MSGTo_' ,
                        'CANOE_DLC'     => 'EnvVECTOR__INDEPENDENT_SIG_MSGDlc_' ,
                        'CANOE_TIMING'  => 'EnvVECTOR__INDEPENDENT_SIG_MSGTime_' ,
                      },
           },

############################################# 

## --- Signal List (msg by msg , IDs ascending) of System under Test node 

############################################# 

## Signal List (msg by msg , IDs ascending) from Simulator 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EngineData (Engine) ID: 100 (0x64), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'EcoMode' =>
               {
               'SIGNAL_NAME'   => 'EcoMode',      'CANOE_ENV_VAR' => 'EnvEcoMode_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 42, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EcoMode.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EcoMode.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b00001100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngForce' =>
               {
               'SIGNAL_NAME'   => 'EngForce',      'CANOE_ENV_VAR' => 'EnvEngForce_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 64, 'LENGTH' => 32, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => 'N',
               'LC_READ_PHYS'  => 'EngForce.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngForce.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngIgnitionAngle' =>
               {
               'SIGNAL_NAME'   => 'EngIgnitionAngle',      'CANOE_ENV_VAR' => 'EnvEngIgnitionAngle_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 400, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngIgnitionAngle.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngIgnitionAngle.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b11111111' , 56 => '0b11111111' , 57 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngKnocking' =>
               {
               'SIGNAL_NAME'   => 'EngKnocking',      'CANOE_ENV_VAR' => 'EnvEngKnocking_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 464, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngKnocking.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngKnocking.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 58 => '0b11111111' , 59 => '0b11111111' , 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b11111111' , 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngPower' =>
               {
               'SIGNAL_NAME'   => 'EngPower',      'CANOE_ENV_VAR' => 'EnvEngPower_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 48, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 0.010000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'kW',
               'LC_READ_PHYS'  => 'EngPower.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngPower.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngSpeed' =>
               {
               'SIGNAL_NAME'   => 'EngSpeed',      'CANOE_ENV_VAR' => 'EnvEngSpeed_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 96, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => 'rpm',
               'LC_READ_PHYS'  => 'EngSpeed.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngSpeed.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 12 => '0b11111111' , 13 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngStates' =>
               {
               'SIGNAL_NAME'   => 'EngStates',      'CANOE_ENV_VAR' => 'EnvEngStates_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 336, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngStates.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngStates.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b11111111' , 49 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngTemp' =>
               {
               'SIGNAL_NAME'   => 'EngTemp',      'CANOE_ENV_VAR' => 'EnvEngTemp_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 7, 'OFFSET' => -50.000000, 'FACTOR' => 2.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'degC',
               'LC_READ_PHYS'  => 'EngTemp.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngTemp.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b01111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngTorque' =>
               {
               'SIGNAL_NAME'   => 'EngTorque',      'CANOE_ENV_VAR' => 'EnvEngTorque_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 128, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngTorque.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngTorque.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' , 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngTubePressure' =>
               {
               'SIGNAL_NAME'   => 'EngTubePressure',      'CANOE_ENV_VAR' => 'EnvEngTubePressure_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 208, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngTubePressure.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngTubePressure.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 26 => '0b11111111' , 27 => '0b11111111' , 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngValvePos' =>
               {
               'SIGNAL_NAME'   => 'EngValvePos',      'CANOE_ENV_VAR' => 'EnvEngValvePos_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 272, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngValvePos.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngValvePos.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 34 => '0b11111111' , 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngineData::Gear' =>
               {
               'SIGNAL_NAME'   => 'Gear',      'CANOE_ENV_VAR' => 'EnvGear_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 44, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Gear.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Gear.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 5 => '0b01110000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'IdleRunning' =>
               {
               'SIGNAL_NAME'   => 'IdleRunning',      'CANOE_ENV_VAR' => 'EnvIdleRunning_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'IdleRunning.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'IdleRunning.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'PetrolLevel' =>
               {
               'SIGNAL_NAME'   => 'PetrolLevel',      'CANOE_ENV_VAR' => 'EnvPetrolLevel_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 24, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'l',
               'LC_READ_PHYS'  => 'PetrolLevel.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'PetrolLevel.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ShiftRequest' =>
               {
               'SIGNAL_NAME'   => 'ShiftRequest',      'CANOE_ENV_VAR' => 'EnvShiftRequest_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 200, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ShiftRequest.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ShiftRequest.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 25 => '0b00000001' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngineData::SleepInd' =>
               {
               'SIGNAL_NAME'   => 'SleepInd',      'CANOE_ENV_VAR' => 'EnvSleepInd_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineData',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 201, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SleepInd.EngineData.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SleepInd.EngineData.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 25 => '0b00000010' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: EngineStatus (Engine) ID: 101 (0x65), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'EngStatusFD_FillByte1' =>
               {
               'SIGNAL_NAME'   => 'EngStatusFD_FillByte1',      'CANOE_ENV_VAR' => 'EnvEngStatusFD_FillByte1_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngStatusFD_FillByte1.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngStatusFD_FillByte1.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngStatusFD_FillByte2' =>
               {
               'SIGNAL_NAME'   => 'EngStatusFD_FillByte2',      'CANOE_ENV_VAR' => 'EnvEngStatusFD_FillByte2_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngStatusFD_FillByte2.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngStatusFD_FillByte2.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngStatusFD_FillByte3' =>
               {
               'SIGNAL_NAME'   => 'EngStatusFD_FillByte3',      'CANOE_ENV_VAR' => 'EnvEngStatusFD_FillByte3_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 24, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngStatusFD_FillByte3.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngStatusFD_FillByte3.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'EngStatusFD_FillByte4' =>
               {
               'SIGNAL_NAME'   => 'EngStatusFD_FillByte4',      'CANOE_ENV_VAR' => 'EnvEngStatusFD_FillByte4_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 64, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngStatusFD_FillByte4.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngStatusFD_FillByte4.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 8 => '0b11111111' , 9 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'ErrorCode' =>
               {
               'SIGNAL_NAME'   => 'ErrorCode',      'CANOE_ENV_VAR' => 'EnvErrorCode_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 2, 'LENGTH' => 6, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'ErrorCode.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'ErrorCode.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111100' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Status' =>
               {
               'SIGNAL_NAME'   => 'Status',      'CANOE_ENV_VAR' => 'EnvStatus_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'EngineStatus',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 2, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Status.EngineStatus.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Status.EngineStatus.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Diag_Request (Vector__XXX) ID: 512 (0x200), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: GearBoxInfo (Engine) ID: 1020 (0x3fc), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'GearBoxInfo::Gear' =>
               {
               'SIGNAL_NAME'   => 'Gear',      'CANOE_ENV_VAR' => 'EnvGear_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'GearBoxInfo',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 3, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Gear.GearBoxInfo.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Gear.GearBoxInfo.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Diag_Response (Vector__XXX) ID: 1024 (0x400), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: NM_Gateway_PowerTrain (Gateway) ID: 1306 (0x51a), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: NM_Engine (Engine) ID: 1307 (0x51b), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'NM_Engine::SleepInd' =>
               {
               'SIGNAL_NAME'   => 'SleepInd',      'CANOE_ENV_VAR' => 'EnvSleepInd_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'NM_Engine',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'SleepInd.NM_Engine.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'SleepInd.NM_Engine.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000001' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: DiagRequest_Motor (Gateway) ID: 1537 (0x601), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: DiagResponse_Motor (Engine) ID: 1544 (0x608), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: DropOutMessage (Engine) ID: 1792 (0x700), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'DropOutMessage_Byte_00_05' =>
               {
               'SIGNAL_NAME'   => 'DropOutMessage_Byte_00_05',      'CANOE_ENV_VAR' => 'EnvDropOutMessage_Byte_00_05_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'DropOutMessage',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'DropOutMessage_Byte_00_05.DropOutMessage.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DropOutMessage_Byte_00_05.DropOutMessage.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'DropOutMessage_Byte_06_10' =>
               {
               'SIGNAL_NAME'   => 'DropOutMessage_Byte_06_10',      'CANOE_ENV_VAR' => 'EnvDropOutMessage_Byte_06_10_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'DropOutMessage',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'DropOutMessage_Byte_06_10.DropOutMessage.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'DropOutMessage_Byte_06_10.DropOutMessage.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: FallbackMessage (Engine) ID: 1793 (0x701), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'FallbackMessage_Byte_00_05' =>
               {
               'SIGNAL_NAME'   => 'FallbackMessage_Byte_00_05',      'CANOE_ENV_VAR' => 'EnvFallbackMessage_Byte_00_05_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'FallbackMessage',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 7, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'FallbackMessage_Byte_00_05.FallbackMessage.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'FallbackMessage_Byte_00_05.FallbackMessage.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'FallbackMessage_Byte_06_10' =>
               {
               'SIGNAL_NAME'   => 'FallbackMessage_Byte_06_10',      'CANOE_ENV_VAR' => 'EnvFallbackMessage_Byte_06_10_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'FallbackMessage',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 55, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'MOTOROLA', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'FallbackMessage_Byte_06_10.FallbackMessage.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'FallbackMessage_Byte_06_10.FallbackMessage.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' , 10 => '0b11111111' , 11 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Test_Message_CAN_FD (Engine) ID: 2047 (0x7ff), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'Test_Signal_Byte_00' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_00',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_00_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_00.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_00.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_01_02' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_01_02',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_01_02_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 8, 'LENGTH' => 16, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_01_02.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_01_02.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b11111111' , 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_03_05' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_03_05',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_03_05_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 24, 'LENGTH' => 24, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_03_05.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_03_05.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_06_09' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_06_09',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_06_09_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 48, 'LENGTH' => 32, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_06_09.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_06_09.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 6 => '0b11111111' , 7 => '0b11111111' , 8 => '0b11111111' , 9 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_10_14' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_10_14',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_10_14_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 80, 'LENGTH' => 40, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_10_14.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_10_14.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 10 => '0b11111111' , 11 => '0b11111111' , 12 => '0b11111111' , 13 => '0b11111111' , 14 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_15_20' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_15_20',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_15_20_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 120, 'LENGTH' => 48, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_15_20.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_15_20.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 15 => '0b11111111' , 16 => '0b11111111' , 17 => '0b11111111' , 18 => '0b11111111' , 19 => '0b11111111' , 20 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_21_27' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_21_27',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_21_27_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 168, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_21_27.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_21_27.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 21 => '0b11111111' , 22 => '0b11111111' , 23 => '0b11111111' , 24 => '0b11111111' , 25 => '0b11111111' , 26 => '0b11111111' , 27 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_28_34' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_28_34',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_28_34_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 224, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_28_34.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_28_34.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 28 => '0b11111111' , 29 => '0b11111111' , 30 => '0b11111111' , 31 => '0b11111111' , 32 => '0b11111111' , 33 => '0b11111111' , 34 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_35_41' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_35_41',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_35_41_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 280, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_35_41.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_35_41.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 35 => '0b11111111' , 36 => '0b11111111' , 37 => '0b11111111' , 38 => '0b11111111' , 39 => '0b11111111' , 40 => '0b11111111' , 41 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_Signal_Byte_63' =>
               {
               'SIGNAL_NAME'   => 'Test_Signal_Byte_63',      'CANOE_ENV_VAR' => 'EnvTest_Signal_Byte_63_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 504, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_Signal_Byte_63.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_Signal_Byte_63.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 63 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_signal_Byte_42_48' =>
               {
               'SIGNAL_NAME'   => 'Test_signal_Byte_42_48',      'CANOE_ENV_VAR' => 'EnvTest_signal_Byte_42_48_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 336, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_signal_Byte_42_48.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_signal_Byte_42_48.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 42 => '0b11111111' , 43 => '0b11111111' , 44 => '0b11111111' , 45 => '0b11111111' , 46 => '0b11111111' , 47 => '0b11111111' , 48 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_signal_Byte_49_55' =>
               {
               'SIGNAL_NAME'   => 'Test_signal_Byte_49_55',      'CANOE_ENV_VAR' => 'EnvTest_signal_Byte_49_55_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 392, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_signal_Byte_49_55.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_signal_Byte_49_55.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 49 => '0b11111111' , 50 => '0b11111111' , 51 => '0b11111111' , 52 => '0b11111111' , 53 => '0b11111111' , 54 => '0b11111111' , 55 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Test_signal_Byte_56_62' =>
               {
               'SIGNAL_NAME'   => 'Test_signal_Byte_56_62',      'CANOE_ENV_VAR' => 'EnvTest_signal_Byte_56_62_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'Test_Message_CAN_FD',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 448, 'LENGTH' => 52, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Test_signal_Byte_56_62.Test_Message_CAN_FD.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Test_signal_Byte_56_62.Test_Message_CAN_FD.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 56 => '0b11111111' , 57 => '0b11111111' , 58 => '0b11111111' , 59 => '0b11111111' , 60 => '0b11111111' , 61 => '0b11111111' , 62 => '0b00001111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: ABSdata (Engine) ID: 2147535173 (0x8000c945), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'AccelarationForce' =>
               {
               'SIGNAL_NAME'   => 'AccelarationForce',      'CANOE_ENV_VAR' => 'EnvAccelarationForce_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'ABSdata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 32, 'LENGTH' => 16, 'OFFSET' => -10000.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'N',
               'LC_READ_PHYS'  => 'AccelarationForce.ABSdata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'AccelarationForce.ABSdata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 4 => '0b11111111' , 5 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'CarSpeed' =>
               {
               'SIGNAL_NAME'   => 'CarSpeed',      'CANOE_ENV_VAR' => 'EnvCarSpeed_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'ABSdata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 10, 'OFFSET' => 0.000000, 'FACTOR' => 0.500000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => 'mph',
               'LC_READ_PHYS'  => 'CarSpeed.ABSdata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'CarSpeed.ABSdata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b00000011' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'Diagnostics' =>
               {
               'SIGNAL_NAME'   => 'Diagnostics',      'CANOE_ENV_VAR' => 'EnvDiagnostics_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'ABSdata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 16, 'LENGTH' => 8, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'Diagnostics.ABSdata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'Diagnostics.ABSdata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 2 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

'GearLock' =>
               {
               'SIGNAL_NAME'   => 'GearLock',      'CANOE_ENV_VAR' => 'EnvGearLock_',
               'SENDER'        => 'Engine',
               'MESSAGE'       => 'ABSdata',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 15, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'GearLock.ABSdata.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'GearLock.ABSdata.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 1 => '0b10000000' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: Ignition_Info (Gateway) ID: 2147555696 (0x80011970), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'StarterKey' =>
               {
               'SIGNAL_NAME'   => 'StarterKey',      'CANOE_ENV_VAR' => 'EnvStarterKey_',
               'SENDER'        => 'Gateway',
               'MESSAGE'       => 'Ignition_Info',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 1, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'UNSIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'StarterKey.Ignition_Info.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'StarterKey.Ignition_Info.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b00000001' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

# -------------------------------------------------------------------------------------- 

# ----------- CAN MESSAGE: VECTOR__INDEPENDENT_SIG_MSG (Vector__XXX) ID: 3221225472 (0xc0000000), DBC File name :CAN_FD_Powertrain ------------- 

# -------------------------------------------------------------------------------------- 

'EngInjectionVol' =>
               {
               'SIGNAL_NAME'   => 'EngInjectionVol',      'CANOE_ENV_VAR' => 'EnvEngInjectionVol_',
               'SENDER'        => 'Vector__XXX',
               'MESSAGE'       => 'VECTOR__INDEPENDENT_SIG_MSG',
               'MULTIPLEX'     => undef,
               'STARTBIT'      => 0, 'LENGTH' => 64, 'OFFSET' => 0.000000, 'FACTOR' => 1.000000,
               'FORMAT'        => 'INTEL', 'TYPE' => 'SIGNED', 'UNIT' => '',
               'LC_READ_PHYS'  => 'EngInjectionVol.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # verify with CAN block parameters of LC model (*.dcm-file)
               'LC_WRITE_PHYS' => 'EngInjectionVol.VECTOR__INDEPENDENT_SIG_MSG.CAN_engine',     # set to 0 if LC model controlled and
               'LC_MODEL_CTRL' => 0,                               # set to 1 if LC model controlled
               'LC_EDIT_BYTES' => { 0 => '0b11111111' , 1 => '0b11111111' , 2 => '0b11111111' , 3 => '0b11111111' , 4 => '0b11111111' , 5 => '0b11111111' , 6 => '0b11111111' , 7 => '0b11111111' },   # affected Byte(s) & BitMask(s) (used when 'LC_MODEL_CTRL')
               },

};
# end of CAN mapping

1;
