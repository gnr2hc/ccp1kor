# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************

use strict;
use warnings;
use File::Spec;

=head1 NAME

create_liftincludepath

=head1 SYNOPSIS

    create_liftincludepath

=head1 DESCRIPTION

This tool creates a file .liftincludepath in the root folder (usually "tools_TurboLIFT") of an RTC-SCM TurboLIFT project.
The file contains all paths in which TurboLIFT modules are located, 
so that these paths do not have to be added manually in iStar.
If a file .liftincludepath already exists then this file will be renamed to .liftincludepath_old.

=cut

#STEP get path of file .liftincludepath
my $filename = '../../../.liftincludepath';
$filename = File::Spec->rel2abs($filename);

#STEP rename to *_old if file already exists
if( -e $filename ) {
    my $renameFile = $filename.'_old';
    print "Renaming file $filename to $renameFile...\n";
    rename $filename, $renameFile or die "Cannot rename file $filename: $!";
}

print "Getting all include paths...\n";

#STEP get LIFT exec path
my $lift_exec_path = File::Spec->rel2abs('../..');
my @pathList;

#STEP collect directories for perl modules
unshift @pathList, $lift_exec_path.'\modules\Common_library';
unshift @pathList, $lift_exec_path.'\modules\Functional_layer';
unshift @pathList, $lift_exec_path.'\modules\Convenience_layer';
unshift @pathList, $lift_exec_path.'\funclib_generic';

#CALL Add_paths for Device_layer
Add_paths($lift_exec_path.'\modules\Device_layer');

#STEP collect TC_FunctionLib paths for MKS project compatibility
unshift @pathList, $lift_exec_path.'\modules\TC_FunctionLib';
unshift @pathList, $lift_exec_path.'\modules\TC_FunctionLib\TC_CustLib';
unshift @pathList, $lift_exec_path.'\modules\TC_FunctionLib\TC_Project';

#CALL Add_paths for funclib_Customer
my $funclibPath = File::Spec->rel2abs('../../../Custlib/funclib_Customer');
Add_paths($funclibPath);

#CALL Add_paths for Platform with "Engine" as $subsubDir
my $tcPath = File::Spec->rel2abs('../../../Platform');
Add_paths( $tcPath, "Engine" );

#STEP build content string for output file
my $contentString = '<?xml version="1.0" encoding="UTF-8"?>'."\n<includepath>\n";
foreach my $path ( @pathList ) {
    $contentString .= '  <includepathentry path="'.$path.'" />'."\n";
}
$contentString .= "</includepath>\n";

#STEP write content string to output file
print "Writing include paths to file '$filename'...\n";
open( my $outfh, '>', $filename ) or die "Can't open '$filename': $!";
print $outfh $contentString;
close $outfh;

print "READY.\n";

#END end


=head2 Add_paths

    Add_paths( $path [, $subsubDir] );
    
Adds all subdirectories of $path to @pathList.
If $subsubDir is defined then it is added to each subdirectory path before adding to @pathList.

=cut

sub Add_paths {
    my $path      = shift;
    my $subsubDir = shift;

    #IF $path is a directoty?
    if ( -d $path ) {
    	#IF-YES-START

        #STEP add $path to @pathList
        unshift @pathList, $path;
        opendir my $dh, $path or die "$0: opendir: $!";

        #STEP get all sub-directories which are not . or ..
        my @subDirs = grep { -d "$path/$_" && !/^\.{1,2}$/ } readdir($dh);

        #print "sub dirs: @subDirs\n";
        foreach my $subDir (@subDirs) {
            my $fullPath = $path.'\\'.$subDir;
            #STEP if $subsubDir is defined then it is added to each subdirectory path
            $fullPath .= '\\'.$subsubDir if defined $subsubDir;
            #STEP add each subdirectory to @pathList
            unshift @pathList, $fullPath;
        }
    	#IF-YES-END
    }
    	#IF-NO-START
    	#IF-NO-END
	#END return 1
    return 1;
}


1;
