
# *****************************************************************************************************
#
#  Copyright (c) 2018  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: Tools/CANoe/Perl_CANoe_COMInfc/Perl_CANoe_COMInfc.pl $
#    $Revision: 1.3 $
#    $State: develop $
#******************************************************************************************************
use warnings;
use strict;

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################

#################################################################################
#
#  ATTENTION :
#
#  Please do not include any TurboLIFT/engine functionality inside this module.
#  Main intention of this tool is to run this independenlty of TurboLIFT such as to
#  assist Vector when we need support from them.
#################################################################################

use Win32::OLE;
use Sys::Hostname;
use Tk;
use File::Slurp;

#####################################
#               VARIABLES
#####################################
my $o_handle;
my $main;
my $opt_cfg_file;
my $log_File = "CANoe_Eventlog".'_'.S_get_date_extension().'.txt';

# main loop

Init_GUI();
MainLoop;

# main loop end

#####################################
#               FUNCTIONs
#####################################

sub Create_OLE {
    my @args = @_;

    my ( $application, $host, $quit_func_ref ) = @args;
    unless ( defined($application) ) {
        S_wr2log( "! too less parameters ! SYNTAX: Create_OLE ( application [, host ])", 2 );
        return;
    }

    unless ( defined($host) ) {
        S_wr2log( "No Host given -> set to 'localhost", 2 );
        return;
    }

    print( 4, " Create_OLE : creating '$application' object on host: '$host' \n" );
    my $ole_handle = Win32::OLE->new( [ $host, $application ], $quit_func_ref );

    if ( defined $ole_handle ) {
        S_wr2log("Win32::OLE -> new ([ $host , $application ]) successful done.");
        return $ole_handle;
    }
    else {
        S_wr2log( "Error creating: Win32::OLE -> new ([ $host , $application ])", 2 );
        return;
    }

    S_wr2log("OLE created on $host\n");
    return 1;
}

sub Start_application {
    my $hostname = hostname();
    my $ole_handle;
    unless ( $ole_handle = Create_OLE( "CANoe.Application", $hostname, \&close_application ) ) {
        return;
    }
    sleep(1);
    S_wr2log("OLE handle is created , value = $ole_handle");
    
    CANoe_get_application_version($ole_handle);
    
    return $ole_handle;
}

sub Close_application {

    my @args       = @_;
    my $ole_handle = shift @args;

    if ( $ole_handle->Measurement->Running() ) {
        $ole_handle->Measurement->Stop();
    }

    my $result = $ole_handle->Application->Quit();
    S_wr2log("Close application is closed successfully. ");
    return 1;
}

sub Open_configuration {

    my @args        = @_;
    my $ole_handle  = shift @args;
    my $config_file = shift @args;

    my ($read_config_fullname);
    unless ( defined $config_file ) {
        S_wr2log("Error Open_configuration :$config_file ");
        return;
    }
    $ole_handle->Application->Open( $config_file, 1, 0 );
    sleep(1);
    S_wr2log("Open_configuration done, file = '$config_file'.");
    return 1;
}

sub CANoe_get_application_version {
    my @args = @_;
    
    my $ole_handle = shift @args;
    my $type       = shift @args;

    
    # STEP Get CANoe application version
    my $version_object;
    unless ( $version_object = GetCOM_Object( $ole_handle, [ 'Application', 'Version' ] ) ) {
        S_wr2log( "could not get object : OLE_handle -> Application -> Version. Not supported from CANoe", 2 );
        return;
    }

    $type = 'fullname' if not defined $type;
    my $cantool_version;

    # STEP Get CANoe application version for type FullName
    if ( $type =~ /fullname/i ) {
        S_wr2log( " OLE_handle -> Application -> Version -> { 'FullName' } .. " );
        $cantool_version = GetCOM_objProperty( $ole_handle, [ 'Application', 'Version' ], 'FullName' );
        S_wr2log(" 'FullName' version '$cantool_version' ");

    }

    # STEP Get CANoe application version for type 'major'
    if ( $type =~ /major/i ) {
        S_wr2log( " OLE_handle -> Application -> Version -> { 'Major' } .. " );
        $cantool_version = GetCOM_objProperty( $ole_handle, [ 'Application', 'Version' ], 'Major' );
        S_wr2log(" 'Major' version '$cantool_version' ");
    }

    # STEP return found CANoe application version
    return $cantool_version;
}

sub Start_measurement {
    my @args       = @_;
    my $ole_handle = shift @args;

    # Start the measurement
    $ole_handle->Measurement->Start();
    sleep(2);
    S_wr2log("Start_measurement is done");
    return 1;
}

sub Stop_measurement {
    my @args       = @_;
    my $ole_handle = shift @args;
    S_wr2log( "Stop_measurement has been called", 4 );
    $ole_handle->Measurement->Stop();
    sleep(1);
    S_wr2log("Stop_measurement done");
    return 1;
}

sub Read_signal {
    my @args        = @_;
    my $ole_handle  = shift @args;
    my $busType     = shift @args;
    my $busNbr      = shift @args;
    my $msg_name    = shift @args;
    my $signal_name = shift @args;

    my $bus_Object;

    $bus_Object = $ole_handle->Bus            if ( $busType =~ /CAN/i );
    $bus_Object = $ole_handle->Bus("Lin")     if ( $busType =~ /LIN/i );
    $bus_Object = $ole_handle->Bus("FlexRay") if ( $busType =~ /FLEXRAY/i );
    unless ($bus_Object) {
        S_wr2log( "Unable to get bus Object for BUS type $busType ", 2 );
        return;
    }

    my $signal_object = $bus_Object->GetSignal( $busNbr, $msg_name, $signal_name );

    unless ( defined $signal_object ) {
        sleep 1;
        S_wr2log(" 2nd try to read the signal value");
        $signal_object = $ole_handle->Bus->GetSignal( $busNbr, $msg_name, $signal_name );
    }

    my $phys_value = $signal_object->{"Value"};
    my $raw_value  = $signal_object->{"RawValue"};

    my $raw_value_hex = sprintf( "0x%X", $raw_value );

    S_wr2log("value of '$busType :: $busNbr :: $msg_name :: $signal_name'  => ( physical = '$phys_value', raw =  '$raw_value_hex' )");
    return ( $phys_value, $raw_value_hex );
}


sub GetCOM_Object {
    my @args = @_;
    my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;

    my $object;

    # STEP error if not at least one object passed
    my $nbrObjHierarchy = scalar @$com_objectHierarchy_aref;
    if ( $nbrObjHierarchy < 1 ) {
        S_wr2log( "Invalid params ! atleast one COM object is expected.)", 2 );
        return;
    }

    # STEP find the required object
    my $firstObject = 1;
    foreach my $com_objects (@$com_objectHierarchy_aref) {

        # for first COM object in Object hierarchy
        if ($firstObject) {
            $object      = $oleHandle->$com_objects;
            $firstObject = 0;
            return $object if ( $nbrObjHierarchy == 1 );
        }

        # for rest of the objects
        $object = $object->$com_objects;
    }
    S_get_LastError_OLE();
    return $object;
}

sub GetCOM_objProperty {
    my @args = @_;
     my $oleHandle                = shift @args;
    my $com_objectHierarchy_aref = shift @args;
    my $property                 = shift @args;

    my $propertyValue;
    my $object = GetCOM_Object( $oleHandle, $com_objectHierarchy_aref ) || return;
    $propertyValue = $object->{$property};

    return $propertyValue;
}

sub S_wr2log {
    my @args = @_;

    my $text         = shift @args;
    my $loggingLevel = shift @args;

    $text = $text . "\n";
    my $date_time = S_get_date_extension();

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    $loggingLevel = 4 if not defined $loggingLevel;

    my $loggingLevels_href = {
        1 => 'CRITICAL',
        2 => 'ERROR',
        3 => 'WARNING',
        4 => 'INFO',
        5 => 'DEBUG',
    };

    my $text_to_log = "[$date_time] [$loggingLevels_href->{$loggingLevel}]:" . "$callingFunction: $text";
    write_file( $log_File , { append => 1 }, $text_to_log );
    print $text_to_log;
    return 1;
}

sub S_get_LastError_OLE
{
    my $err = "";
    return 0 unless $err = Win32::OLE->LastError();
    S_w2log(" OLE ERROR : $err ",  2 );
    return $err;
}


sub S_get_date_extension {
    my $given_time = shift;
    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst );

    if ( defined $given_time ) {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($given_time);
    }
    else {
        ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime( time() );
    }
    return sprintf( "%04d%02d%02d_%02d%02d%02d", $year + 1900, $mon + 1, $mday, $hour, $min, $sec );
}
## =============== ======
# USER INTERFACE
## ======================

#Inits the genrator by loading GUI
sub Init_GUI {

    ##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( -background => "#888888" );
    $main->minsize( 800, 300 );    # define minimum size of main window 'main'
    $main->title("Perl program controlling the CANoe..");    # create title in main window 'main'

    #create frame 'F1' in main window 'main'
    my $frame1 = $main->Frame( -background => "#333546" )->pack(
        -side   => 'top',
        -expand => 1,
        -fill   => 'both',
    );

    # create frame 'F2' in main window 'main'
    my $frame2 = $main->Frame( -background => "#333546" )->pack(
        -side => 'bottom',
        -fill => 'x',
    );

    # write head line in frame 'F1'
    $frame1->Label(
        -text       => 'CANoe Interactive Controlling window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( -side => "top" );

    # create exit and start buttons in frame 'F2'
    $frame2->Button(
        -text       => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        -command    => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        -side  => 'left',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

    ###################################################################################
    # create Frame for choosing DB file with label, entry and button
    my $db_file_1 = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $db_file_1->Label( -text => "CANoe Configuratoin file (*.cfg): ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( -side => 'left' );
    $db_file_1->Entry( -textvariable => \$opt_cfg_file, -validate => 'focusout', -background => "grey" )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    # create 'browse file' button
    $db_file_1->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $opt_cfg_file;    # store old value
            $opt_cfg_file = $main->getOpenFile(
                -filetypes => [ [ "CANoe config file", ['.cfg'] ], [ "All files", '.*' ] ],
                -title => "Configuration file which has to be loaded",
                -initialdir => '.',
            );
            unless ($opt_cfg_file) { $opt_cfg_file = $temp; }    # if no new value, restore old one

        },
    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5 );

    my $adminStuff = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $adminStuff->Button(
        -text       => "Start CANoe Application ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            $o_handle = Start_application();
            
        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 10, -padx => 30 );

    $adminStuff->Button(
        -text       => "Load Configuration ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            Open_configuration( $o_handle, $opt_cfg_file );
        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 10, -padx => 30 );

    $adminStuff->Button(
        -text       => "Start measurement ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            Start_measurement($o_handle);

        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 5, -padx => 30 );

    $adminStuff->Button(
        -text       => "Stop measurement ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            Stop_measurement($o_handle);

        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 5, -padx => 30 );

    $adminStuff->Button(
        -text       => "Quit CANoe Application ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            Close_application($o_handle);
            
        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 10, -padx => 30 );

    my $read_Signals = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    my $signals      = ('CAN::1::Message::Singal1');
    my $phys_value   = 0;
    my $raw_value    = 0;
    $read_Signals->Label( -text => "Signal as in CANoe (CAN /LIN /FR) db", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( -side => 'left' );
    $read_Signals->Entry( -textvariable => \$signals, -validate => 'focusout', -background => "grey", )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );
    $read_Signals->Button(
        -text       => "Read Signals ",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {

            print( $signals. "\n" );
            my ( $busType, $busNbr, $msg, $signal ) = split( /\s?::\s?/, $signals );
            print("$busType $busNbr :: $msg :: $signal\n");
            ( $phys_value, $raw_value ) = Read_signal( $o_handle, $busType, $busNbr, $msg, $signal );

        },
    )->pack( -side => 'left', -ipadx => 15, -ipady => 2, -pady => 10, -padx => 30 );

    $read_Signals->Entry( -textvariable => \$raw_value,  -validate => 'focusout', -background => "grey", )->pack( -side => 'right', -fill => 'x', -expand => 0, -padx => 5 );
    $read_Signals->Entry( -textvariable => \$phys_value, -validate => 'focusout', -background => "grey", )->pack( -side => 'right', -fill => 'x', -expand => 0, -padx => 5 );

    return;
}

