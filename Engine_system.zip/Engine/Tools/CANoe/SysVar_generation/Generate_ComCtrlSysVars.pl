use strict;
use warnings;
use File::Slurp;
use File::Spec;
use Tk;

my $log_File = 'sysvar_log.txt';
unlink $log_File;

# main loop
Init_GUI();
MainLoop;

#####################################
#               VARIABLES
#####################################
my $main;
my $nbr_analysis_signals = 50;
my $nbr_stimulus_signals = 200;
my $opt_sysVar_file      = '';

# ==================================================================================
#  write to system variable file. Adapted for CANoeCtrl (Dynamic signal stimulation)
# ==================================================================================
sub Write_to_sysvar_xml_file {

    # STEP Delete if the sysvar file already exists..
    unlink $opt_sysVar_file if defined $opt_sysVar_file;

    my $xmlheader = <<XMLHEADER;
<?xml version="1.0" encoding="utf-8"?>
<systemvariables version="4">
    <namespace name="" comment="">
XMLHEADER
    WrTextTo_xml_File($xmlheader);

    ## CALL WrSysVar_AnalysSignals for analysis signals
    WrSysVar_AnalysSignals();

    ## CALL WrSysVar_StimulusSignals for dynamic signal stimualation
    WrSysVar_StimulusSignals();

	## Sysvar for LIFT_CAN_access for logging
	WrSysVar_Logging_LIFT_CAN_Access();

    my $xmlfooter = <<XMLFOOTER;
    </namespace>
</systemvariables>
XMLFOOTER

    WrTextTo_xml_File($xmlfooter);
    return 1;
}

# ==================================================================================
#  write to system variable file.
#  Create system varible related to Analysis signals.
#  Not required for Dynamic signal stimulation but to compile the template CAPL provied by Vector
#  which has analysis + Dynamic signal together.
# ==================================================================================
sub WrSysVar_AnalysSignals {
    my $xmlAnalysis_header = <<XML_ANALYSIS_HEADER;
		<namespace comment="" name="Analysis">
XML_ANALYSIS_HEADER
    WrTextTo_xml_File($xmlAnalysis_header);

    my $xmlAnalysis_body_fixed = <<XML_ANALYSIS_BODY_FIXED;
			<variable anlyzLocal="2" arrayLength="50" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVOperator" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="50" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVResponseTime" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="50" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVTriggerType" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="50" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVThreshold" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVMonitoringTime" readOnly="false" type="int" unit="" valueSequence="false"/>
XML_ANALYSIS_BODY_FIXED
    WrTextTo_xml_File($xmlAnalysis_body_fixed);

    foreach my $nbr ( 0 .. $nbr_analysis_signals - 1 ) {
        my $xmlAnalysis_body_dynamic = <<XML_ANALYSIS_BODY_DYNAMIC;
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVSignal$nbr" readOnly="false" startValue="0" type="float" unit="" valueSequence="false"/>
XML_ANALYSIS_BODY_DYNAMIC
        WrTextTo_xml_File($xmlAnalysis_body_dynamic);
    }

    my $xmlAnalysis_footer = <<XML_ANALYSIS_FOOTER;
		</namespace>
XML_ANALYSIS_FOOTER
    WrTextTo_xml_File($xmlAnalysis_footer);
    return 1;
}

# ==================================================================================
#  write to system variable file.
#  Create system varible related to Analysis signals.
#  Not required for Dynamic signal stimulation but to compile the template CAPL provied by Vector
#  which has analysis + Dynamic signal together.
# ==================================================================================

sub WrSysVar_StimulusSignals {
    my $xmlStimulys_header = <<XML_STIMULUS_HEADER;
		<namespace comment="" name="Stimulus">
XML_STIMULUS_HEADER
    WrTextTo_xml_File($xmlStimulys_header);

    my $xmlStimulus_body_fixed = <<XML_STIMULUS_BODY_FIXED;
			<variable anlyzLocal="2" arrayLength="10" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVTimedTriggerType" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="10" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVTimeshift" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="10" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVTimedSignalA" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="10" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVTimedSignalB" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="$nbr_stimulus_signals" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVNumSignals" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="$nbr_stimulus_signals" bitcount="32" comment="" encoding="65001" isSigned="true" name="SVTriggerType" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" maxValue="1" maxValuePhys="1" minValue="0" minValuePhys="0" name="SVTriggerEnabled" readOnly="false" startValue="0" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" maxValue="1" maxValuePhys="1" minValue="0" minValuePhys="0" name="SVTriggerHard" readOnly="false" startValue="0" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" maxValue="1" maxValuePhys="1" minValue="0" minValuePhys="0" name="SVTriggerSoft" readOnly="false" startValue="0" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="8" comment="" encoding="65001" isSigned="true" name="SVSignalName" readOnly="false" type="string" unit="" valueSequence="false"/>
XML_STIMULUS_BODY_FIXED
    WrTextTo_xml_File($xmlStimulus_body_fixed);

    foreach my $nbr ( 0 .. $nbr_stimulus_signals - 1 ) {
        my $xmlStimulus_body_dynamic = <<XML_STIMULUS_BODY_DYNAMIC;
			<variable anlyzLocal="2" arrayLength="20000" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVSignalValues$nbr" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" name="SVSignal$nbr" readOnly="false" type="float" unit="" valueSequence="false"/>
XML_STIMULUS_BODY_DYNAMIC
        WrTextTo_xml_File($xmlStimulus_body_dynamic);
    }

    my $xmlStimulus_footer = <<XML_STIMULUS_FOOTER;
		</namespace>
XML_STIMULUS_FOOTER
    WrTextTo_xml_File($xmlStimulus_footer);
    return 1;
}

sub WrTextTo_xml_File {
    my @args    = @_;
    my $textMsg = shift @args;
    write_file( $opt_sysVar_file, { append => 1 }, $textMsg );
    return 1;
}

sub WrSysVar_Logging_LIFT_CAN_Access {
    my $xml_can_access = <<XML_CAN_ACCESS;
		<namespace comment="" name="LIFT_CAN_access">
			<namespace comment="" name="MultipleLevel">
				<variable anlyzLocal="2" arrayLength="10" bitcount="32" comment="" encoding="65001" isSigned="true" name="SysVar_IntegerArray" readOnly="false" type="intarray" unit="" valueSequence="false"/>
				<variable anlyzLocal="2" arrayLength="10" bitcount="64" comment="" encoding="65001" isSigned="true" name="SysVar_FloatArray" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
				<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" name="SysVar_Type_Int" readOnly="false" type="int" unit="" valueSequence="false"/>
				<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" name="SysVar_Type_Float" readOnly="false" type="float" unit="" valueSequence="false"/>
				<variable anlyzLocal="2" bitcount="8" comment="" encoding="65001" isSigned="true" name="SysVar_Type_String" readOnly="false" type="string" unit="" valueSequence="false"/>
			</namespace>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" name="SysVar_logging_control" readOnly="false" startValue="-1" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="10" bitcount="32" comment="" encoding="65001" isSigned="true" name="SysVar_IntegerArray" readOnly="false" type="intarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" arrayLength="10" bitcount="64" comment="" encoding="65001" isSigned="true" name="SysVar_FloatArray" readOnly="false" type="floatarray" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="false" name="SysVar_MsgStimulus3_CANTo_" readOnly="false" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" maxValue="1000" maxValuePhys="1000" minValue="0" minValuePhys="0" name="SysVar_Simulate_Hw_Trigger" readOnly="false" startValue="0" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="" encoding="65001" isSigned="true" maxValue="1000" maxValuePhys="1000" minValue="0" minValuePhys="0" name="SysVar_Type_Int" readOnly="false" startValue="0" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="32" comment="SysVar_MsgStimulus3_CANDlc_" encoding="65001" isSigned="true" name="LIFT_CAN_access" readOnly="false" type="int" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="false" name="SysVar_MsgStimulus3_CANDlc_" readOnly="false" type="longlong" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="false" name="SysVar_MsgStimulus3_CANTime_" readOnly="false" type="longlong" unit="" valueSequence="false">
				<valuetable definesMinMax="false"/>
			</variable>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="false" name="SysVar_ValidMsgStimulus3_BZ" readOnly="false" type="longlong" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="false" name="SysVar_ValidMsgStimulus3_CRC" readOnly="false" type="longlong" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" maxValue="1000" minValue="0" name="SysVar_Type_Float" readOnly="false" startValue="0" type="float" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" name="SysVar_MethodMsgStimulus3_BZ" readOnly="false" type="float" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="64" comment="" encoding="65001" isSigned="true" name="SysVar_MethodMsgStimulus3_CRC" readOnly="false" type="float" unit="" valueSequence="false"/>
			<variable anlyzLocal="2" bitcount="8" comment="" encoding="65001" isSigned="true" name="SysVar_Type_String" readOnly="false" startValue="0" type="string" unit="" valueSequence="false"/>
		</namespace>
XML_CAN_ACCESS
    WrTextTo_xml_File($xml_can_access);
}

#Inits the genrator by loading GUI
sub Init_GUI {
##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( -background => "#888888" );
    $main->minsize( 800, 150 );    # define minimum size of main window 'main'
    $main->title("Perl program to generate sysvar (xml) file for dynamic signal stimulation..");    # create title in main window 'main'

    #create frame 'F1' in main window 'main'
    my $frame1 = $main->Frame( -background => "#333546" )->pack(
        -side   => 'top',
        -expand => 1,
        -fill   => 'both',
    );

    # create frame 'F2' in main window 'main'
    my $frame2 = $main->Frame( -background => "#333546" )->pack(
        -side => 'bottom',
        -fill => 'x',
    );

    # write head line in frame 'F1'
    $frame1->Label(
        -text       => '** Window to Generate sysvar file **',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( -side => "top" );

    # create exit and start buttons in frame 'F2'
    $frame2->Button(
        -text       => "Quit",
        -width      => '5',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        -command    => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        -side  => 'left',
        -pady  => 20,
        -padx  => 20,
        -ipady => 5,
        -ipadx => 5,
      );

    my $start_button = $frame2->Button(
        "-text"     => "Generate sysVar file",
        -width      => '15',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        "-command"  => sub {
            Write_to_sysvar_xml_file();
            my $abs_path = File::Spec->rel2abs($opt_sysVar_file);
            $frame2->messageBox(
                '-icon'    => "info",
                '-type'    => "OK",
                '-title'   => 'System variable file',
                '-message' => "System variable file is generated.\n\nSee file :-\n'$abs_path'",
            );
        }
      )->pack(
        "-side"  => 'right',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );

    $nbr_analysis_signals = 50;

    # STEP create Frame for choosing sysvar file with label, entry and button
    my $analysis_sysvar = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $analysis_sysvar->Label( -text => "Max nbr of 'Analysis' signals: ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '45', -wraplength => 200 )->pack( -side => 'left' );
    $analysis_sysvar->Entry( -textvariable => \$nbr_analysis_signals, -validate => 'focusout', -background => "grey" )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    $nbr_stimulus_signals = 200;

    # create Frame for choosing DB file with label, entry and button
    my $output_sysvar = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $output_sysvar->Label( -text => "Max nbr of 'Stimulus' signals: ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '45', -wraplength => 200 )->pack( -side => 'left' );
    $output_sysvar->Entry( -textvariable => \$nbr_stimulus_signals, -validate => 'focusout', -background => "grey" )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    my $syssvar_file = $frame1->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $syssvar_file->Label( -text => "Select the sysvar file path: ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( -side => 'left' );
    $syssvar_file->Entry( -textvariable => \$opt_sysVar_file, -validate => 'focusout', -background => "grey" )->pack( -side => 'left', -fill => 'x', -expand => 1, -padx => 5 );

    $opt_sysVar_file = 'ComCtrlSysVars.xml';

    # create 'browse file' button
    $syssvar_file->Button(
        -text       => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        -command    => sub {
            my $temp = $opt_sysVar_file;    # store old value
            $opt_sysVar_file = $main->getOpenFile(
                -filetypes => [ [ "Sysvar file", ['.xml'] ], [ "All files", '.*' ] ],
                -title => "Configuration file which has to be loaded",
                -initialdir => '.',
            );
            unless ($opt_sysVar_file) { $opt_sysVar_file = $temp; }    # if no new value, restore old one

        },
    )->pack( -side => 'right', -ipadx => 5, -ipady => 2, -pady => 5, -padx => 5 );

    return 1;
}

