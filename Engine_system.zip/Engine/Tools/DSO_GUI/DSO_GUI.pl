#!usr\bin\perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################


BEGIN
{
    my $LIFT_exec_path='../..';

    # add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/Device_layer/DSO1";
}

use strict;
use DSO;
use Tk;
use Tk::BrowseEntry;

my $Toolversion = "DSO_GUI ($VERSION)";      # Tool version number

my ($main, $ConnectionFrame, $ButtonFrame, $ConnectionEntry, $display_txt, $ScopeLabel, $ScopeMenu);
my ($ConnButton_text, $value_file,$value2_file, $Box_Save_Value_Frame,$Box_Restore_Value_Frame, $ValueEntry,$Value2Entry);
my ($Box_Save_Button_Frame, $Box_Restore_Button_Frame, $Box_channel_Frame);
my ($connected, $connection,$DeviceID, $dso, $Box_Save, $Box_Restore, $configcomment, $Box_Save_Value_Conf_Frame);
my ($Button_Trigger, $Trigger_Frame, $Help_String);
my ($Button_Browse_Save_File, $Button_Save_Screen, $Button_Save_Date_A_Screen, $Button_Save_Conf);
my ($Button_Browse_Open_File, $Button_Restore_Config);
my ($Device_ID, $Conn_Status, $Status);
my ($count);
my @Channelnames= qw(C1 C2 C3 C4 M1 M2 M3 M4 TA TB TC TD);
my @Channels = (0) x 12;

$ConnButton_text="CONNECT";
$configcomment="created with $Toolversion";

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "DSO_GUI $VERSION" );

# create frame 'ConnectionFrame' in window 'main'
$ConnectionFrame = $main -> Frame() -> pack( "-pady" => 20 );

$Trigger_Frame = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 5, "-fill" => 'x' ) -> pack( );

# create frames in window 'main'

#create Box 1: For 'Save Parameters'
$Box_Save = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );

#create Box 2: For 'Save restore'
$Box_Restore = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );

#create Sub Frames in Box_Save
$Box_Save_Value_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );
$Box_Save_Value_Conf_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );
$Box_channel_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );
$Box_Save_Button_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );

#create Sub Frames in Box_Restore
$Box_Restore_Value_Frame = $Box_Restore -> Frame() -> pack( "-pady" => 5 );
$Box_Restore_Button_Frame = $Box_Restore -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 10 );


# create label in window 'main'
$main -> Label( "-textvariable" => \$DeviceID, 
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 5 );


# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt,
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );


######## connection

# create 'connect' button
$ConnectionFrame -> Button
  (
  "-textvariable" => \$ConnButton_text,
  "-command" => sub
    { # execute when button is pressed  
    
        if ($connection) {
          unless ($connected){
             $dso = DSO->new(\*LOG);
            
            ($Status, $Device_ID) = $dso->connect($connection);            
            
             if($Status < 0)
             {
                #write Error Message
                $display_txt= "Connection failed"; 
                w2log("Connection failed \n"); 
             }
             else
             {                
                $ConnButton_text= "disconnect";
                $display_txt= "connected to Device $Device_ID ";
                w2log("connected to Device $Device_ID \n");
                $connected = 1;
                Set_Active();
             }
          }
          else {
             if($dso->disconnect()<0)
             {
                $display_txt= "Disconnection failed"; 
                w2log("disconnection failed \n"); 
             }
             else
             {
                $ConnButton_text= "CONNECT";
                $display_txt= "disconnected from Device";
                w2log("disconnected from Device \n");
                $connected = 0;
                #clear handle
                undef $dso;
                Set_Inactive();
             }
          }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select connection details first!"
            );
        }
    }
  )
-> pack ("-side" => 'left');

# create label in Frame 'ConnectionFrame'
$ConnectionFrame -> Label( "-text" => " via ", )
            -> pack( "-side" => 'left', );

# create entry 'ConnectionEntry' in 'ConnectionFrame'
$ConnectionEntry = $ConnectionFrame -> BrowseEntry(
            "-width" => 20,
            "-variable" => \$connection, 
            );
$ConnectionEntry -> pack( "-side" => 'left', );
$ConnectionEntry -> insert("end",'COM1: 9600,8,N,1');
$ConnectionEntry -> insert("end",'GPIB: 1');
$ConnectionEntry -> insert("end",'IP:10.3.40.187');

# create 'exit' button
$ConnectionFrame -> Button
  (
  "-text" => "E X I T",
  "-background" => "red",
  "-command" => sub
    {$main->destroy;}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-padx" => 20);


# create 'Trigger' button
$Button_Trigger = $Trigger_Frame -> Button
  (
  "-text" => "Set Trigger",
  "-state" => "disabled",
  "-command" => sub
    {  
        if($dso->setTriggermode('SINGLE') <0)
        {
            $display_txt= "not possible set Trigger mode"; 
            w2log("not possible set Trigger mode \n"); 
        }
        else 
        {
            if($dso->arm() <0)
            {
                $display_txt= "Not Possible to execute func arm()"; 
                w2log("Not Possible to execute func arm() \n"); 
            }
            else {
                $display_txt= "change in Trigger Mode"; 
                w2log ("change in Trigger Mode \n"); 
            }
        }
    }
  )
-> pack ("-ipadx" => 5,"-ipady" => 5,"-padx" => 5);



######## values


# create entry 'ValueEntry' in 'Box_Save_Value_Frame'
$ValueEntry = $Box_Save_Value_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$value_file, 
            );
$ValueEntry -> pack( "-side" => 'left', );

# create 'browse file' button
$Button_Browse_Save_File = $Box_Save_Value_Frame -> Button
(
"-text" => "Browse save file",
"-state" => "disabled",
"-command" => sub
  {
        #store old variable value
      $Help_String = $value_file;
      
      # browse for file
      $value_file = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["All files", '.*'],
          ["png files", '.png']
          ],
        "-title"      => "select file to save values",
        );
      # if a file was chosen
      if ( $value_file )
        {
        #extract directory
        
        print "\n $value_file was chosen\n";
        }
      else
        {
          #restore old variable value
          $value_file = $Help_String;
          print "no filename!\n";
       }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# create label in window 'main'
$Box_Save_Value_Conf_Frame -> Label( "-text" => "config comment: ", 
         )
      -> pack( "-side" => 'left', "-pady" => 5 );

# create entry 'ValueEntry' in 'Box_Save_Button_Frame'
$Box_Save_Value_Conf_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$configcomment, #reference to $prj_id
            )-> pack( "-side" => 'left', );



for ($count=0;$count<12;$count++){
    $Box_channel_Frame -> Checkbutton  (
      "-text"     => $Channelnames[$count],
      "-onvalue"  => $Channelnames[$count],
      "-variable" => \$Channels[$count],
      )
    -> pack( "-side" => 'left', );
}


# create 'save SCREEN' button
$Button_Save_Screen = $Box_Save_Button_Frame -> Button
  (
  "-text" => "save SCREEN",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value_file) { # create project if scan_file was given
                $display_txt="saving screen to $value_file";
                $main -> update();
                                         
                if($dso->saveScreen($value_file)<0)
                {
                    $display_txt="screen cannot be saved";
                    w2log("screen cannot be saved");
                }
                else {
                                       
                    #Save File Name              
                    $Help_String = $value_file;

                    #change file extension to png 

                    if($value_file =~ /\.\w+$/ ) 
                    {
                        $value_file =~ s/\.\w+$/.png/;
                    }
                    else {
                        $value_file = $value_file . ".png";
                    }

                    $Help_String = "\"".$value_file."\"";
                    $Help_String =~ s/\//\\/g;

                    #Open picture
                    system("CMD /C start \"\" $Help_String") or $display_txt="screen saved to: ". $Help_String;
                    
                    $display_txt="screen saved";
                    w2log("screen saved"); 
                }
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);



# create 'save DATA' button
$Button_Save_Date_A_Screen = $Box_Save_Button_Frame -> Button
  (
  "-text" => "save DATA+SCREEN",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value_file) {
                my @ch=();
                for ($count=0;$count<12;$count++){
#                    w2log("$count = $Channels[$count]\n");
                    push (@ch,$Channels[$count]) if ($Channels[$count] ne '0');
                }
                my $CHstr= join('+',@ch);

                $display_txt="saving channels $CHstr to $value_file";
                $main -> update();


                if($dso->saveValues($value_file,$CHstr,10000000,1) <0)
                {
                    $display_txt= "not able to save Data";
                    w2log("not able to save Data");
                }
                else {   
                                          
                     #Save File Name              
                     $Help_String = $value_file;
                    
                    #change file extension to png 
                    if($value_file =~ /\.\w+$/ ) 
                    {
                        $value_file =~ s/\.\w+$/.png/;
                    }
                    else {
                        $value_file = $value_file . ".png";
                    }

                    $Help_String = "\"".$value_file."\"";
                    $Help_String =~ s/\//\\/g;

                    #Open graph
                    system("CMD /C start \"\" $Help_String") or $display_txt="screen saved to: ". $Help_String;
                  
                    $display_txt="values saved";
                    w2log("values saved");
                  #  $main -> update();
                }
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);



# create 'SAVE config' button
$Button_Save_Conf = $Box_Save_Button_Frame -> Button
  (
  "-text" => "SAVE config",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value_file) { 
            
                #save Config File as a txt File
                
                #first. check whether file name contains an extension or not  
                if($value_file =~ /\.\w+$/ ) {
                
                    #replace extention with txt
                    $value_file =~ s/\.\w+$/.txt/;
                                        
                    $Help_String = $value_file;
                                    
                    $display_txt="saving config to $Help_String";
                    $main -> update(); 
                    
                    #Pass Name with txt extention to SaveConfig 
                    if($dso->saveConfig($Help_String,$configcomment) <0)
                    {
                        $display_txt= "Config File cannot be saved";
                        w2log("Config File cannot be saved");
                    }
                    else {                
                        $display_txt= "Config saved: $Help_String";
                        w2log("Config saved: $Help_String");  
                    }
                } # File name contains no extension
                else {
                    #Add txt extention
                    $Help_String = $value_file . ".txt";
                    
                    $value_file = $Help_String;
                    
                    $display_txt="saving config to $Help_String";
                    $main -> update(); 
                    
                    #Pass Name with txt extention to SaveConfig
                    if($dso->saveConfig($Help_String,$configcomment))
                    {
                        $display_txt= "Config File cannot be saved";
                        w2log("Config File cannot be saved");
                    }
                    else {                
                        $display_txt= "Config saved: $Help_String";
                        w2log("Config saved: $Help_String");  
                    }
                }                
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
               '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);



# create entry 'ValueEntry' in 'Box_Save_Value_Frame'
$Value2Entry = $Box_Restore_Value_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$value2_file, #reference to $prj_id
            );
$Value2Entry -> pack( "-side" => 'left', );


# create 'browse file' button
$Button_Browse_Open_File = $Box_Restore_Value_Frame -> Button
(
"-text" => "Browse open file",
"-state" => "disabled",
"-command" => sub
  {
      # browse for file
      $value2_file = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["config files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $value2_file )
        {
        #extract directory
        print "\n $value_file was chosen\n";
        }
      else
        {
          print "no filename!\n";
       }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# =head1 create 'RESTORE config' button
$Button_Restore_Config = $Box_Restore_Button_Frame -> Button
  (
  "-text" => "RESTORE config",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value2_file) { 
                $display_txt="restoring config from $value2_file";
                $main -> update();
                                
                if($dso->restoreConfig($value2_file) <0)
                {
                    w2log("config cannot be restored");
                    $display_txt="config cannot be restored";
                }
                else {
                    $display_txt="config restored";
                    w2log("config restored");
                }
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);

#Fuction Set all Buttons into Normal (active) State
sub Set_Active(){

     $Button_Trigger -> configure("-state" => "normal");
     $Button_Browse_Save_File -> configure("-state" => "normal");
     $Button_Browse_Open_File-> configure("-state" => "normal");
     $Button_Save_Screen -> configure("-state" => "normal");
     $Button_Save_Date_A_Screen-> configure("-state" => "normal");
     $Button_Save_Conf -> configure("-state" => "normal");
     $Button_Restore_Config -> configure("-state" => "normal");
}


#Fuction Set all Buttons into Inactive State
sub Set_Inactive(){

     $Button_Trigger -> configure("-state" => "disabled");
     $Button_Browse_Save_File -> configure("-state" => "disabled");
     $Button_Browse_Open_File-> configure("-state" => "disabled");     
     $Button_Save_Screen -> configure("-state" => "disabled");
     $Button_Save_Date_A_Screen-> configure("-state" => "disabled");
     $Button_Save_Conf -> configure("-state" => "disabled");
     $Button_Restore_Config -> configure("-state" => "disabled");
 }



#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">DSO_GUI_log.txt" ) or die "Couldn't open DSO_GUI_log.txt : $@";
w2log("######################################################################\n");
w2log("### Digital Storage Oscilloscope GUI ###\n"); 
w2log("######################################################################\n");
w2log("$Toolversion logfile\n");

MainLoop;

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}

=head1 usage

first of all you have to connect to the device you want to control. For DSO GPIB or IP is recommended. Edit the address according to your device settings.

Press CONNECT button before any other action.

to load a config just select the file with 'Browse open file' button and press 'RESTORE config' button.

to save a config just select the file with 'Browse save file' button, edit comment if required and press 'SAVE config' button.

to save a screenshot just select the file with 'Browse save file' button and press 'save SCREEN' button.

to save screenshot and data in UNIVIEW format just select the file with 'Browse save file' button and press 'save DATA+SCREEN' button.

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, activeDSO documentation, LeCroy manual.

=cut
