#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################




use strict;
use warnings;
use Getopt::Long;
#use Tk;

my ($INfile,$offset,$CANreplace,$FXRreplace);

=head1 usage

create parameter files for CANoeCTRL based on .iso file


 CLI: CANoeCTRL_param.pl --busNameCan [string] --busNameFR [string] --file [file]
 e.g. CANoeCTRL_param.pl --busNameCan MLBevo_SCCAN --busNameFR MLBevo_Fx_Cluster --file C:\TurboLIFT\Tools\ParaGen\TF_INT_0055_PCR_Ausloesung_Vollstraffung_extern_IN_V01.iso


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

# CLI: CANoeCTRL_param.pl --busNameCan [string] --busNameFR [string] --file [file]
GetOptions('file=s'       => \$INfile,
           'busNameCan=s' => \$CANreplace,
           'busNameFR=s'  => \$FXRreplace);
$CANreplace .= '::';
$FXRreplace .= '::';
if ($INfile && $CANreplace && $FXRreplace){ # source file
    create_params();
}
else{
  print "Usage: CANoeCTRL_param.pl --busNameCan [string] --busNameFR [string] --file [file]\n";
}



sub create_params{
my @BUSsignals;
$offset = 0; # Currently all CANoeCtrl signals are generated without leading gap (no index offset needed now)

if($INfile =~ /\.iso$/){
    my $line;
#    print "processing iso file\n";
    open ( IN,"<$INfile" ) or die "Couldn't open $_ : $@";

    while($line = <IN>){ 
        #scan for line labels
        if ($line =~ /((CAN|FXR)::\S+)/) {
			my $signal = $1;
			$signal =~ s/CAN::/$CANreplace/;
			$signal =~ s/FXR::/$FXRreplace/;
            push(@BUSsignals,$signal);
        }
    }
    
}
else {die"unknown file format $INfile\n";}

my $outputFile = "CANoe_CTRL_para.txt";
open (FILE,">", $outputFile) or warn "could not write $outputFile: $@\n";

for (my $index = 0;$index<scalar(@BUSsignals);$index++){
	print FILE ($index+$offset)." , $BUSsignals[$index]\n";
}

print FILE "\n\n\n\n\n";

for (my $index = 0;$index<scalar(@BUSsignals);$index++){
	my $num = $index+$offset;

print FILE '
on signal_update '.$BUSsignals[$index].'
{
    if (gTriggered['.$num.'])   // checking gTriggered ensures that the mapping is done in only one network node
        @Stimulus::SVSignal'.$num.' = this;
}
';

}

print FILE "\n\n\n\n\n";

for (my $index = 0;$index<scalar(@BUSsignals);$index++){
	my $num = $index+$offset;

print FILE '
    case '.$num.': 
        {  	
            SetSignal('.$BUSsignals[$index].', value); 
            gTriggered[id] = 1;             // prevents check of node name in later iterations
           
        }
        break;
';
}

close(FILE);
print "DONE CANoe-Setup (See: $outputFile)\n\n";
}



# end of program
