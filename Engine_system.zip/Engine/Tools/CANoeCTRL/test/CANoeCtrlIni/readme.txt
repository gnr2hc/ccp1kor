Input and output files used for (regression) testing

Input files: 
# KMatrixExtract_CAN.txt (saved in parallel sub-folder KMatrixExtract)
# KMatrixExtract_FR.txt (saved in parallel sub-folder KMatrixExtract)
# TF_INT_0055_PCR_Ausloesung_Vollstraffung_extern_IN_V01.iso

Output file:
# CANoeCtrlIni.txt             if flag '$replaceBusPara4Setup' in Perl script is set to 1: replace para for ini-setup (default selection)
# CANoeCtrlIni_noReplace.txt   if flag '$replaceBusPara4Setup' in Perl script is set to 0: keep original bus infos in output files
