Input and output files used for (regression) testing

Input files: 
# MLBevo_SCCAN_KMatrix_V8.05F_20130201_JH.xls
# MLBevo_FlexRay_KMatrix_V8_05_01F_20130206_BP.xls
	(alternatively renamed for checking empty spaces in paths/filenames: MLBevo_FlexRay_KMatrix_V8_05_01F_20130206_BP Copy.xls)

Output files:
# KMatrixExtract_CAN.txt
# KMatrixExtract_FR.txt
