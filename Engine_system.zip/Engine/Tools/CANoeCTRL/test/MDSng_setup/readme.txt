Input and output files used for (regression) testing

Input parameter
===============

 <CrashCodeList>.txt   contains full crash code with optional version after semicolon (only crashCodes marked with _IN are read)
 <Default>.design.xml  contains a default MDSng setup, which is used as signal exclusion list




Output files
============
# AnyPrj.design.xml
# AnyPrj.crashset.xml
# AnyPrj.mapping.xml
# Excluded_Locations.txt (for information only, no MDS input)


-------------------------------------------------------
MLBevo-specific hints
-------------------------------------------------------
Before running this Perl script:
- <Default>.design.xml can also be made by re-using a previous generated and fixed AnyPrj.design.xml, by
  removing again the generated 'AlgoInputChannel' xml-blocks inside, which are marked with 'inSimCoreOnly="true"'
After running this Perl script:
- Place xml files, where you like and start MDS with them (double-click design.xml)
- Fix assigns of only one crash code
  a) Re-Map PreCare x,y,z to corresponding PSP-signals
  b) PreSense x,y,z  => ZERO EMULATION
  c) 3 x Messzeitpunkt => ZERO EMULATION
  d) Periphery signals => ZERO EMULATION
- Add all other crash codes


-------------------------------------------------------
Obsolete usage of Excel export to CrashDBExtract.xls,
since updated Perl script reads directly from crash DB:
-------------------------------------------------------

Input files
===========
# CrashDBExtract.xls (Export from C:\MDSng\db\mdslocal99.mdb)

--------
Option 1
--------
	- Change category view to Queries (Abfragen)
	- Create a new query by icon QueryDesign (Abfrageentwurf)
	- Change view to SQL-view and copy this query into the SQL view

SQL-String to create this extract file (execute this query):
------------------------------------------------------------
SELECT CHANNELTAB.CHANNELNR_CN, CHANNELTAB.CRASHCODE_CN, CHANNELTAB.DIRECTION_CN, CHANNELTAB.LOCATION_CN, CRASHTAB.VERSION
FROM CHANNELTAB INNER JOIN CRASHTAB ON CHANNELTAB.CRASHCODE_CN = CRASHTAB.CRASHCODE_CH
ORDER BY CHANNELTAB.CRASHCODE_CN;
------------------------------------------------------------

	- Continue with Excel-Export

--------
Option 2
--------
	Notes for Access before start of export:
	- Some columns might be hidden (required columns from CHANNELTAB: CHANNELNR_CN, CRASHCODE_CN, LOCATION_CN, DIRECTION_CN, from CRASHTAB: VERSION)
	- Change category view to Queries (Abfragen)
	- Create a new query by icon QueryDesign (Abfrageentwurf)
	- Choose tables to add
	- Connect in graph both tables, by drag and drop of CRASHCODE_CN (in CHANNELTAB) over CRASHCODE_CH (in CRASHTAB)
	- Drag and drop required table entries to table below
	- Sort column "CRASHCODE_CN" ascending
	- Continue with Excel-Export

------------
Excel-Export
------------
	- I M P O R T A N T: Save query as "CrashDBExtract" (leads to xls-worksheetName = "CrashDBExtract", which is expected by Perl script)
	- Run Query
	- Filter for required crash codes
	- Access menu: External Data > Export to Excel
	- Choose path and xls-filename: CrashDBExtract.xls
	- Format Excel 97 - Excel 2003 Workbook (*.xls)
	- Activate Export Option: Export data with format and layout


Output files
============
# AnyPrj.design.xml
# AnyPrj.crashset.xml
# AnyPrj.mapping.xml
