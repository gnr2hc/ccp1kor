#!/usr/bin/perl -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

=head1 usage

Prepares CANoeCtrl-INI entries of output signals for usage in CANoeCtrl-setup

 CANoeCtrl_sigOut4ini.pl <BusName_CAN> <CAN_Extract>.txt <BusName_FR> <FR_Extract>.txt <ISO_File>.iso
 
 e.g.: CANoeCtrl_sigOut4ini.pl MLBevo_SCCAN KMatrixExtract_CAN.txt MLBevo_Fx_Cluster KMatrixExtract_FR.txt \\siz1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\65.System_Testing\CREIS\PSP\PreSense\03.SCI_PreS_AB1044_C01_C11_X060\Customer_Testvectoren\BeispielExport\TF_INT_0055_PCR_Ausloesung_Vollstraffung_extern_IN_V01.iso

 Where
 <BusName_CAN>     = MLBevo_SCCAN
 <CAN_Extract>.txt = KMatrixExtract_CAN.txt
 <BusName_FR>      = MLBevo_Fx_Cluster
 <FR_Extract>.txt  = KMatrixExtract_FR.txt
 ISO_File          = \\siz1130\aerse$\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\65.System_Testing\CREIS\PSP\PreSense\03.SCI_PreS_AB1044_C01_C11_X060\Customer_Testvectoren\BeispielExport\TF_INT_0055_PCR_Ausloesung_Vollstraffung_extern_IN_V01.iso

 Output will be:
 CANoeCtrlIni.txt


=head1 AUTHOR

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=cut

use strict;
use warnings;

my @errorMessages;

#check usage
if (@ARGV != 5) 
{
	my $numArgs = scalar(@ARGV);
	printf "numArgs = $numArgs (5 exptected, check your commandline)\n";
	if ( $numArgs > 0 )
	{
		printf "CAN Bus Name = $ARGV[0]\n";
	}
	if ( $numArgs > 1 )
	{
		printf "CAN_Extract File = $ARGV[1]\n";
	}
	if ( $numArgs > 2 )
	{
		printf "FR Bus Name = $ARGV[2]\n";
	}
	if ( $numArgs > 3 )
	{
		printf "FR_Extract File = $ARGV[3]\n";
	}
	if ( $numArgs > 4 )
	{
		printf "ISO_File = $ARGV[4]\n";
	}
	die "usage: makeCANoeCtrlIniFile.pl CAN_Bus_Name KMatrixExtract_CAN.txt FR_Bus_Name KMatrixExtract_FR.txt ISO_File\n";
}
my $CANbusName = $ARGV[0];
my $CAN_KMatrix_Extract_File = $ARGV[1];
my $FRbusName = $ARGV[2];
my $FR_KMatrix_Extract_File = $ARGV[3];
my $ISO_File = $ARGV[4];

#printf "CANbusName               = $CANbusName\n";
#printf "CAN_KMatrix_Extract_File = $CAN_KMatrix_Extract_File\n";
#printf "FRbusName                = $FRbusName\n";
#printf "FR_KMatrix_Extract_File  = $FR_KMatrix_Extract_File\n";
#printf "ISO_File                 = $ISO_File\n";
#printf "Processing input files . . .\n";
#__END__

my $fileHandle;

#######################################################################
# Read CAN Extract File into array of string lines
#######################################################################
unless ( open($fileHandle, "<", $CAN_KMatrix_Extract_File) ) {
	push(@errorMessages, "Can't open $CAN_KMatrix_Extract_File: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $CAN_KMatrix_Extract_File: $!";
	}
my @CANLinesK = <$fileHandle>;
close ($fileHandle);

#######################################################################
# Read FR Extract File into array of string lines
#######################################################################
unless ( open($fileHandle, "<", $FR_KMatrix_Extract_File) ) {
	push(@errorMessages, "Can't open $FR_KMatrix_Extract_File: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $FR_KMatrix_Extract_File: $!";
	}
my @FRLinesK = <$fileHandle>;
close ($fileHandle);

#######################################################################
# Read ISO File into array of signal names
#######################################################################
my @signals4Ini;

if ( $ISO_File =~ /\.iso$/ )
{
    my $isoLine;
    unless ( open ( $fileHandle,"<", "$ISO_File" ) ) {
		push(@errorMessages, "Can't open $ISO_File: $!\n");
		writeErrorLog("Wrong file path", @errorMessages);
		die "Can't open $ISO_File: $!";
		}
	
    while ( $isoLine = <$fileHandle> )
	{ 
        if ( $isoLine =~ /(CAN::\S+)/)
		{
			my $signalIso = $1;
			$signalIso =~ s/CAN:://;
			# Append corresponding signals porperties from @CANLines
            foreach my $CANsignalK ( @CANLinesK )
			{
				chomp($CANsignalK);
				if ( $CANsignalK =~ /$signalIso=\S+/i)
				{
					if ( $CANsignalK !~ /$signalIso=\S+/)
					{
						push(@errorMessages, "\nSignals have different case:\nK-Matrix: $CANsignalK\nISO-File: $signalIso\n");
					}
					$CANsignalK = $CANbusName."::".$CANsignalK;
					push(@signals4Ini, $CANsignalK);
				}
			}
        }
        if ( $isoLine =~ /(FXR::\S+)/)
		{
			my $signalIso = $1;
			$signalIso =~ s/FXR:://;
			# Append corresponding signals porperties from @FRLines
            foreach my $FRsignalK ( @FRLinesK )
			{
				chomp($FRsignalK);
				if ( $FRsignalK =~ /$signalIso=\S+/i)
				{
					if ( $FRsignalK !~ /$signalIso=\S+/)
					{
						push(@errorMessages, "\nSignals have different case:\nK-Matrix: $FRsignalK\nISO-File: $signalIso\n");
					}
					$FRsignalK = $FRbusName."::".$FRsignalK;
					push(@signals4Ini, $FRsignalK);
				}
			}
        }
	}
    
}
else {die "unknown file format $ISO_File\n";}

#######################################################################
# Save hash to file
#######################################################################

# Flag to control output of signal names, cycle times and default values
# 0: Keep original infos from K-Matrix in generated output file
# 1: Rename signal names for correct ini-file (MDS-compatible), assign cycle times and default values to -1
my $replaceBusPara4Setup = 1;

my $fileLine = "";
my $outputFile = "CANoeCtrlIni.txt";
	
if ( !$replaceBusPara4Setup )
{
	$outputFile = "CANoeCtrlIni_noReplace.txt";
}

unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fileHandle, ">", $outputFile)     or die "Can't open $outputFile: $!";
binmode($fileHandle, ":utf8"); # Avoid message 'Wide character in print at...' in line print $fileHandle "$signal";

print $fileHandle "Format: BusType::PDU/MSG::Signal=idx#cycleTime_ms#initVal_phys#\n";
print $fileHandle "- cycleTime_ms = -1: Test program does not need to resample the bus signals (Crash-DB sampling rate = Bus cycle time)\n";
print $fileHandle "- initVal_phys = factor * initValRaw + offset (or with headline names: \"Skalierung\" * \"InitWert roh [dez]\" + \"Offset\")\n";
print $fileHandle "               = -1: Test program does not need to handle an extra default value (signal arrays start with expected default)\n";
print $fileHandle "- ATTENTION: ? is written, if a value does not exist in K-Matrix\n";
print $fileHandle "--------------------------------END_OF_HEADER-----------------------------------------------\n";

my $idx = 0;
foreach my $signal4Ini ( @signals4Ini )
{
    # Keep order and all lines as is, otherwise depending replacements might not work anymore
	$signal4Ini =~ s/=idx#/=$idx#/; # replace placeholder "idx" by running index
	if ( $replaceBusPara4Setup )
	{
		if ( $signal4Ini =~ /.+\(signalSendType:Cyclic\).+/ ) {
			$signal4Ini =~ s/#[.0-9]+>Fast>[.0-9]+\(signalSendType:\S*\)#/#-1#/; # replace pairs of normal and fast cycle times and further text by -1 (DB-sampling rate = bus cycle time)
			}
		$signal4Ini =~ s/[0-9a-zA-Z_]+::[0-9a-zA-Z_]+::/ECU: /; # replace bus prefix by MDS prefix of signal name
		$signal4Ini =~ s/=/: Bus: SENSOR: NoFilter_For_Bus_Signals=/; # append MDS postfix (direction, filter) to signal name
		$signal4Ini =~ s/\?factor\?offset//; # remove "?factor?offset", since if values are empty in K-Matrix, they are factor=1, offset=0 (for logical signals)
		$signal4Ini =~ s/\?initValRaw/-1/; # replace all ?initValRaw by -1
		$signal4Ini =~ s/=([0-9]+)#[0-9]+\(signalSendType:\S*\)#([0-9.eE-]+)#/=$1#-1#$2#/; # replace all single cycle times and further text by -1 (DB-sampling rate = bus cycle time)
		$signal4Ini =~ s/=([0-9]+)#-1#[0-9.eE-]+#/=$1#-1#-1#/; # replace all init values of non-switched cycle times by -1 (correct default value expected in "first ms" of signal arrays)
		$signal4Ini =~ s/=([0-9]+)#(.+\(signalSendType:.+)\)#([0-9.eE-]+)#/=$1#$2,inactiveValue:$3\)#-1#/; # Append inactiveValue to signalSendType and replace init value by -1
		# If signalSendType contains "..IfActive.." (e.g. "IfActive", "IfActiveWithRepetition", "OnChangeAndIfActiveWithRepetition"), mark inactiveValue with template brackets
		if ( $signal4Ini =~ /.+\(signalSendType:.*IfActive.+/ ) {
			# Rename keyword, in order to disable automatic usage in test program, since further manual check is required.
			# Reason: Sometimes the customer test oracle contains same value as in K-Matrix column "InitWert roh [dez]" as initial value,
			#         but sometimes another value only available in comment column "Beschreibung"
			$signal4Ini =~ s/,inactiveValue:/,inactiveValue<CHECK_VALUE_DELETE_THIS_AND_BRACKETS>:/;			
			}
		# If signalSendType does NOT contain "..IfActive..", do not use inactiveValue		
		else {
			# Rename keyword, in order to disable automatic usage in test program, since not required for these signal send types
			$signal4Ini =~ s/,inactiveValue:/,inactiveValue<NOT_USED>:/;			
			}
	}
	print $fileHandle "$signal4Ini\n";
	$idx++;
}
print $fileHandle "\n\n\n";
foreach my $message ( @errorMessages )
{
    print $fileHandle "$message";
}
close ($fileHandle);

# write error messages, if they exist
writeErrorLog("Error Messages", @errorMessages);

#######################################################################
print "DONE testprog-Setup (See: $outputFile)\n\n";

# Write any error messages to log file
# Usage: writeErrorLog($headline, @errorMessages)
# If no error messages exist, calling this function will just delete any old error log file
sub writeErrorLog {
	my $headline = shift;
	my @errorMessages = @_;
	my $errorOutputFile = "ErrorLog_CANoeCtrl_sigOUT4ini.txt";
	unlink $errorOutputFile if ( -e $errorOutputFile ); # delete old errorOutputFile, if it exists already
	
	my $numErrorMessages = scalar(@errorMessages);
	if ( $numErrorMessages > 0) {
		my $fhErrorOutputFile;
		print "numErrorMessages = $numErrorMessages (see: $errorOutputFile)\n";
		open($fhErrorOutputFile, ">", $errorOutputFile)     or die "Can't open $errorOutputFile: $!";
		#binmode($fhErrorOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'
		print $fhErrorOutputFile "$headline\n";
		foreach my $message ( @errorMessages )
		{
			print $fhErrorOutputFile "$message";
		}
		close ($fhErrorOutputFile);
	}
}
