#!/usr/bin/perl -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

=head1 usage

Copies first crash mapping to all other crashes

 MDSng_copyMapping.pl <CrashCodeList>.txt <AnyPrj>.mapping.xml
 
 e.g.: MDSng_copyMapping.pl C:\TurboLIFT\Tools\CANoeCTRL\test\MDSng_copyMapping\crashCodeList1.txt C:\TurboLIFT\Tools\CANoeCTRL\test\MDSng_setup\AnyPrj.mapping.xml

 Input:
 <CrashCodeList>.txt   contains full crash code with optional version after semicolon (only crashCodes marked with _IN are read)
 <AnyPrj>.mapping.xml
 
 Output:
 <AnyPrj>_OUT.mapping.xml


=head1 AUTHOR

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=cut

use strict;
use warnings;
use DBI;

my @errorMessages;

#check usage
if (@ARGV != 2) 
{
	my $numArgs = scalar(@ARGV);
	printf "numArgs = $numArgs (2 exptected, check your commandline)\n";
	if ( $numArgs > 0 )
	{
		printf "<CrashCodeList>.txt = $ARGV[0]\n";
	}
	if ( $numArgs > 1 )
	{
		printf "<AnyPrj>.mapping.xml = $ARGV[1]\n";
	}
	die "usage: MDSng_setup.pl <CrashCodeList>.txt <AnyPrj>.mapping.xml\n";
}
my $CrashCodeListFile = $ARGV[0];
my $MDSngMappingFile = $ARGV[1];

if ( $MDSngMappingFile !~ /\.mapping\.xml$/ ) {die "unknown file format $MDSngMappingFile\n";}

printf "<CrashCodeList>.txt  = $CrashCodeListFile\n";
printf "<AnyPrj>.mapping.xml = $MDSngMappingFile\n";
#__END__

#######################################################################
# Get relevant crash codes named with "_IN" or "_IN;digits" at the end
#######################################################################
my $fileHandle;
unless ( open($fileHandle, "<", $CrashCodeListFile) ) {
	push(@errorMessages, "Can't open $CrashCodeListFile: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $CrashCodeListFile: $!";
	}

my $CrashCodeLine;
my @crashCodesJob;
while ( $CrashCodeLine = <$fileHandle> )
{ 
	chomp($CrashCodeLine);
	# if line ends with "_IN" or contains "_IN;" and if it isn't a comment line
	if ( $CrashCodeLine =~ /(_IN$|_IN;)/ && $CrashCodeLine !~ /^;/ )
	{
		push(@crashCodesJob, $CrashCodeLine);
		printf "crashCode: $CrashCodeLine\n";
	}
}
close ($fileHandle);
my $numCrashCodesInJob = scalar(@crashCodesJob);

#__END__

#######################################################################
# Read Crash DB
#######################################################################
# Relevant columns: CHANNELTAB: CHANNELNR_CN, CRASHCODE_CN, LOCATION_CN, DIRECTION_CN, CRASHTAB: VERSION

#SELECT CHANNELTAB.CHANNELNR_CN, CHANNELTAB.CRASHCODE_CN, CHANNELTAB.DIRECTION_CN, CHANNELTAB.LOCATION_CN, CRASHTAB.VERSION
#FROM CHANNELTAB INNER JOIN CRASHTAB ON CHANNELTAB.CRASHCODE_CN = CRASHTAB.CRASHCODE_CH
#ORDER BY CHANNELTAB.CRASHCODE_CN;

# Each crashcode has a time stamp and many locations. Each location has a number and a direction
# 
# my %HoH = (
# 	TF_INT_0055_PCR_Ausloesung_Vollstraff_IN => {
# 			timeStamp	                                => 2013-09-06 13:25:39,
# 			FXR__SDF_PSF_Obj_01__SDF_PSF_MessZeitpunkt	=>	{
#															no =>  1,
#															dir => "n/a"
#															}
# 			CAN__RGS_VL_02__RGS_L_Bauteilfehler	        => {
#															no =>  10,
#															dir => "n/a"
#															}
#       	...
#         	},
# 	TF_INT_0065_PCB070201_IN => {
# 			timeStamp	                                => 2013-09-06 14:35:48,
# 			FXR__Motor_20__MO_Fahrpedalrohwert_01	    => {
#															no =>  1,
#															dir => "n/a"
#															}
# 			s_SC_Accel_Y_010	                        => {
#															no =>  10,
#															dir => "n/a"
#															}
# 			...
#         	}

my %HoH; # Hash of hash for crash codes and its properties
my %locations;
my $numLocs = 0;
my $numCodes = 0;

my $dsn               = "mdsnglocal";
my $database          = "DBI:ODBC:$dsn";
my $db_user           = "";
my $db_password       = "";

# connect to the Access db.
my $dbh;
$dbh = DBI->connect($database,$db_user,$db_password) or die $dbh->errstr;

# Create SQL-Statement
my $sqlStatement =
"SELECT CHANNELTAB.CHANNELNR_CN, CHANNELTAB.CRASHCODE_CN, CHANNELTAB.DIRECTION_CN, CHANNELTAB.LOCATION_CN, CRASHTAB.VERSION
FROM CHANNELTAB INNER JOIN CRASHTAB ON CHANNELTAB.CRASHCODE_CN = CRASHTAB.CRASHCODE_CH\n";

# Append condition for 1st crash code
if ( $numCrashCodesInJob > 0 ) {
	$sqlStatement .= "WHERE CRASHTAB.CRASHCODE_CH = '$crashCodesJob[0]'\n";
	}
# Append conditions for remaining crash codes
for (my $i = 1; $i < $numCrashCodesInJob; $i++) {
	$sqlStatement .= "OR CRASHTAB.CRASHCODE_CH = '$crashCodesJob[$i]'\n";
	}

$sqlStatement .= "ORDER BY CHANNELTAB.CRASHCODE_CN;\n";

#print $sqlStatement; 

my $sth = $dbh->prepare($sqlStatement);

my $chNr;
my $crashCode;
my $direction;
my $location;
my $timeStamp;

$sth->execute;
while (($chNr, $crashCode, $direction, $location, $timeStamp) = $sth->fetchrow_array) {
	# Assumption: DB-Location: FXR__PSF_01__PSF_Obj_Klasse => MDS: PSF_Obj_Klasse
	$location =~ s/^\S+__\S+__//;
	
	# new location
	if ( !exists $locations{$location} )
	{
		$locations{$location}{'dir'} = $direction;
		if ($direction ne 'ignoreSignal')
		{
			$locations{$location}{'no'} = $chNr;
		}
		else
		{
			$locations{$location}{'no'} = -1; # set to ZEROEMULATION
		}
		$numLocs++;
	}
	# new crash code
	if ( !exists $HoH{$crashCode} )
	{
		$HoH{$crashCode}{'timeStamp'} = $timeStamp;
		$numCodes++;
	}
	# new location
	if ( !exists $HoH{$crashCode}{$location} )
	{	
		$HoH{$crashCode}{$locations{$location}}{'dir'} = $direction;
		if ($direction ne 'ignoreSignal')
		{
			$HoH{$crashCode}{$locations{$location}}{'no'} = $chNr;		
		}
		else
		{
			$HoH{$crashCode}{$locations{$location}}{'no'} = -1; # set to ZEROEMULATION
		}
	}
}
my $rc  = $dbh->disconnect;
if ( $rc == 1 ) {print "Crash DB disconnected\n\n";}
else {print "Crash DB disconnection F A I L E D\n\n";}

# Check whether all crash codes were found in DB
if ( $numCrashCodesInJob > $numCodes ) {
	printf "Number of crash codes requested: $numCrashCodesInJob\nNumber of crash codes found in DB: $numCodes\n";
	for (my $i = 0; $i < $numCrashCodesInJob; $i++) {
		if ( !exists $HoH{$crashCodesJob[$i]} ) { push(@errorMessages, "Crash code not found in DB: $crashCodesJob[$i]\n"); }
		}
	}

printf "numCodes = $numCodes\n";
printf "numLocs = $numLocs\n";	
if ( $numCodes == 0 ) {
	writeErrorLog("None of the required crash codes were found in local crash DB", @errorMessages);
	die "None of the required crash codes were found in local crash DB";
	}

my $fhMDSngMappingFile;
my $fhMDSngMappingFileNew;
my $mappingFileLine;
my $outputFile;

#######################################################################
# Read AnyPrj>.mapping.xml and copy top-part to AnyPrj.design.xml
#######################################################################
$outputFile = $MDSngMappingFile;
$outputFile =~ s/.mapping.xml/_OUT.mapping.xml/;
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
unless ( open($fhMDSngMappingFileNew, ">", $outputFile) ) {
	push(@errorMessages, "Can't open $outputFile: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $outputFile: $!";
	}

#binmode($fhMDSngMappingFileNew, ":utf8"); # Avoid message 'Wide character in print at...'
unless ( open ( $fhMDSngMappingFile,"<", "$MDSngMappingFile" ) ) {
	push(@errorMessages, "Couldn't open file: $MDSngMappingFile : $@\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Couldn't open file: $MDSngMappingFile : $@";
	}

my $linePos = 0; # 0: Before 1st crash, 1: Inside 1st crash, 2: After 1st crash
my @assignArray;
my $currentCrashCode;
my $numAssigns = 0;
my $idxAssigns = 0;
my $numCrashes = 0;
while ( $mappingFileLine = <$fhMDSngMappingFile> )
{ 
	# Copy header and 1st crash to output file
	if ( $linePos < 2) {
		print $fhMDSngMappingFileNew $mappingFileLine;
		}
		
	# Start of next crash?
	#    <crash crashcode="TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;2" assignmentComment="" crashversion="2013-09-11 06:47:13">
	if ( $mappingFileLine =~ /\s*<crash crashcode="(\S+)"/ )
	{
		$numCrashes++;
		$currentCrashCode = $1;
		
		if ( $linePos == 0 ) { $linePos = 1; }
		if ( $linePos == 2 ) {
			print $fhMDSngMappingFileNew $mappingFileLine;
			$idxAssigns = 0;
			}
	}
	
	# Inside 1st crash
	if ( $linePos == 1 )
	{
		if ( $mappingFileLine =~ /\s*<Assignment/ ) {
			push(@assignArray, $mappingFileLine);
			$numAssigns++;
			}
	}
	
	# End of crash?
	if ( $mappingFileLine =~ /\s*<\/crash>/ )
	{
		# End of 1st crash?
		if ( $linePos == 1 ) {
			$linePos = 2;
			}
		# Further crashes
		else {
			print $fhMDSngMappingFileNew $mappingFileLine;
			}
	}
			
	if ( $linePos == 2 && $numCrashes > 1 )
	{
		if ( $idxAssigns < $numAssigns && $mappingFileLine !~ /\s*<\/crash>/ ) {
			#	<Assignment channelNumber="1" sensorLocation="AAG_Anhaenger_erkannt" />			
			if ($assignArray[$idxAssigns] =~ /<Assignment channelNumber="(\S+)"/ ) {
				if ( $1 != -1 ) {
					if ( exists $HoH{$currentCrashCode} ) {
						# Replace channelNumber integer by finding it in hash via name of sensorLocation (reason: sensorLocation name is same, but channelNumber might be different in different crash codes)
						$assignArray[$idxAssigns] =~ s/<Assignment channelNumber="\S+" sensorLocation="(\S+)"/<Assignment channelNumber="$HoH{$currentCrashCode}{$locations{$1}}{'no'}" sensorLocation="$1"/;
						}
					else {
						$assignArray[$idxAssigns] =~ s/<Assignment channelNumber="\S+" sensorLocation="(\S+)"/<Assignment channelNumber=">>>$currentCrashCode not found (mapping.xml inconsistent to requested crash set)<<<" sensorLocation="$1"/;
						}
					}
				}
			print $fhMDSngMappingFileNew $assignArray[$idxAssigns];
			$idxAssigns++;
			}
	}
	
	if ( $mappingFileLine =~ /\s*<\/Assignments>/ || $mappingFileLine =~ /\s*<\/AssignmentList>/ ) {
		print $fhMDSngMappingFileNew $mappingFileLine;
		}
}

close ($fhMDSngMappingFileNew);
close ($fhMDSngMappingFile);
print "Created: $outputFile\n";

# Write any error messages to log file
writeErrorLog("Error Messages", @errorMessages);

#######################################################################
print "DONE\n";


# Write any error messages to log file
# Usage: writeErrorLog($headline, @errorMessages)
# If no error messages exist, calling this function will just delete any old error log file
sub writeErrorLog {
	my $headline = shift;
	my @errorMessages = @_;
	my $errorOutputFile = "ErrorLog_MDSng_copyMapping.txt";
	unlink $errorOutputFile if ( -e $errorOutputFile ); # delete old errorOutputFile, if it exists already
	
	my $numErrorMessages = scalar(@errorMessages);
	if ( $numErrorMessages > 0) {
		my $fhErrorOutputFile;
		print "numErrorMessages = $numErrorMessages (see: $errorOutputFile)\n";
		open($fhErrorOutputFile, ">", $errorOutputFile)     or die "Can't open $errorOutputFile: $!";
		#binmode($fhErrorOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'
		print $fhErrorOutputFile "$headline\n";
		foreach my $message ( @errorMessages )
		{
			print $fhErrorOutputFile "$message";
		}
		close ($fhErrorOutputFile);
	}
}
