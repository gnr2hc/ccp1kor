#!/usr/bin/perl -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

=head1 usage

Generates testlist and parameter file for TurboLIFT for PreSense-Evaluation

 TurboLIFT_setup.pl <CrashCodeList>.txt <numIter> <offlineTraceFilePath>
 
 e.g.: TurboLIFT_setup.pl C:\TurboLIFT\Tools\CANoeCTRL\test\TurboLIFT_setup\crashCodeList1.txt 2 C:\temp

 Input:
 <CrashCodeList>.txt     contains full crash code with optional version after semicolon
                         (Empty lines or comment lines starting with ; in first column are allowed/ignored)
 <numIter>               number of iterations per crash
 <offlineTraceFilePath>  Path of trace files recorded earlier (Optionally: Write NA in online mode, if TurboLIFT starts/stops testprog automatically)
                         (trace file format: CANoeTrace_C<XX>_S0_I<YY>.asc, <XX>=1-based crash number, <YY>=1-based iteration number, S0=1st state as default always)
 
 Output:
 PSP.txt                 test list
 PSP_start.par           parameter file for testcase start

=head1 AUTHOR

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=cut

use strict;
use warnings;

my @errorMessages;

#check usage
if (@ARGV != 3) 
{
	my $numArgs = scalar(@ARGV);
	printf "numArgs = $numArgs (3 exptected, check your commandline)\n";
	if ( $numArgs > 0 )
	{
		printf "<CrashCodeList>.txt = $ARGV[0]\n";
	}
	if ( $numArgs > 1 )
	{
		printf "<numIter> = $ARGV[1]\n";
	}
	if ( $numArgs > 2 )
	{
		printf "<offlineTraceFilePath> = $ARGV[2]\n";
	}
	die "usage: TurboLIFT_setup.pl <CrashCodeList>.txt <numIter> <offlineTraceFilePath>\n";
}
my $CrashCodeListFile = $ARGV[0];
my $numIterations = $ARGV[1];
my $offlineTraceFilePath = $ARGV[2];
chomp($offlineTraceFilePath);

#printf "<CrashCodeList>.txt  = $CrashCodeListFile\n";
#printf "<numIter> = $numIterations\n";
#printf "<offlineTraceFilePath> = $offlineTraceFilePath\n";
#__END__

#######################################################################
# Get relevant crash codes named with "_IN" or "_IN;digits" at the end
#######################################################################
my $fileHandle;
unless ( open($fileHandle, "<", $CrashCodeListFile) ) {
	push(@errorMessages, "Can't open $CrashCodeListFile: $!\n");
	writeErrorLog("Wrong file path", @errorMessages);
	die "Can't open $CrashCodeListFile: $!";
	}

my $CrashCodeLine;
my @crashCodesJob;
while ( $CrashCodeLine = <$fileHandle> )
{ 
	chomp($CrashCodeLine);
	if ( $CrashCodeLine ne "" && $CrashCodeLine !~ /^;/ ) {
		push(@crashCodesJob, $CrashCodeLine);
		}
}
close ($fileHandle);
my $numCrashCodesInJob = scalar(@crashCodesJob);

#__END__

#printf "numCrashCodesInJob = $numCrashCodesInJob\n";
if ( $numCrashCodesInJob == 0 ) {
	writeErrorLog("No crash codes found in list", @errorMessages);
	die "No crash codes found in list";
	}
if ( $numCrashCodesInJob % 2 ) {
	push(@errorMessages, "Number of crash codes has to be even, but it is uneven: $numCrashCodesInJob\n");
	}

my $outputFile;
my $fhOutputFile;

#######################################################################
# Generate testlist
#######################################################################
$outputFile = "PSP.txt";
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fhOutputFile, ">", $outputFile)     or die "Can't open $outputFile: $!";
#binmode($fhOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'

my $crashCodeLastCorrect = "none";
my $pairCounter = 0;
for my $crashCode (sort @crashCodesJob) {
	my $crashCodePairName = $crashCode;
	$crashCodePairName =~ s/;\d*$//; # remove optional appended semicolon with version number
	$crashCodePairName =~ s/(_IN$|_IN;|_OUT$|_OUT;)//; # remove _IN or _OUT
	if ( $pairCounter == 0 ) {	
		if ( $crashCode !~ /(_IN$|_IN;)/ ) { push(@errorMessages, "IN expected, but found: $crashCode (Last correct: $crashCodeLastCorrect)\n"); }
		else { $crashCodeLastCorrect = $crashCode; }
		# First IN then OUT in pairs together (in case of TurboLIFT online evaluation, with testprog used)
		for (my $iter = 0; $iter < $numIterations; $iter++) {
			printf $fhOutputFile "PSP_start.%s_IN_I%d\n", $crashCodePairName, $iter + 1;
			printf $fhOutputFile "PSP_start.%s_OUT_I%d\n", $crashCodePairName, $iter + 1;
			}
		}
	else {
		if ( $crashCode !~ /(_OUT$|_OUT;)/ ) { push(@errorMessages, "OUT expected, but found: $crashCode (Last correct: $crashCodeLastCorrect)\n"); }
		else { $crashCodeLastCorrect = $crashCode; }
		}
	$pairCounter ^= 1; 
}
	
close ($fhOutputFile);
print "\n\nDONE TurboLIFT-Setup (See: $outputFile)\n";

#######################################################################
# Generate parameter file for testcase start
#######################################################################
$outputFile = "PSP_start.par";
unlink $outputFile if ( -e $outputFile ); # delete old outputFile, if it exists already
open($fhOutputFile, ">", $outputFile)     or die "Can't open $outputFile: $!";
#binmode($fhOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'

#[PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_OUT_I1]
#CrashCode_IN   = 'TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;4'
#StateNumber    = '0'
#CrashToEvaluate  = 'OUT'
#OfflineBusTraceFile   = 'N:\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\65.System_Testing\CREIS\PSP\PreSense\05.SCI_PreS_AB1044_C02_C15_0010\02.From_CREIS\DCI_AB1044_C2_C15_PreSense_0010_No_3_CANoeCtrl\CANoeTrace_C1_S0_I1.asc'

# Iteration loop outside, in order to have first IN and OUT in pairs together as in testlist (see further comments above)
for (my $iter = 0; $iter < $numIterations; $iter++) {	
	my $crashNo = 0;
	for my $crashCode (sort @crashCodesJob) {
		# Input and Output data are in one single asc trace file, since CREIS injects only Input data => Per Input one trace containing both IN and OUT
		if ( $crashCode =~ /(_IN$|_IN;)/ ) {
			$crashNo++;
			}
		my $crashCodeTC = $crashCode;
		my $crashCodeIN = $crashCode;
		$crashCodeTC =~ s/;\d*$//; # remove optional appended semicolon with version number
		$crashCodeIN =~ s/(.*?)_OUT(;?\d*)$/$1_IN$2/; # rename OUT crash code to same IN crash code
		printf $fhOutputFile "[PSP_start.%s_I%d]\n", $crashCodeTC, $iter + 1;
		printf $fhOutputFile "CrashCode_IN   = '%s'\n", $crashCodeIN;
		printf $fhOutputFile "StateNumber   = '0'\n";
		my $crashToEvaluate;
		if ( $crashCode =~ /(_IN$|_IN;)/ ) {
			$crashToEvaluate = "IN";
			}
		else {
			$crashToEvaluate = "OUT";
			}
		printf $fhOutputFile "CrashToEvaluate   = '$crashToEvaluate'\n";
		if ( $offlineTraceFilePath eq "NA" ) {
			# write nothing, just LF
			printf $fhOutputFile "\n";
			}
		else {
			printf $fhOutputFile "OfflineBusTraceFile   = '%s\\CANoeTrace_C%d_S0_I%d.asc'\n\n", $offlineTraceFilePath, $crashNo, $iter + 1;		
			}
	} # end crash code loop
} # end iteration loop

close ($fhOutputFile);
print "DONE TurboLIFT-Setup (See: $outputFile)\n\n";


# Write any error messages to log file
writeErrorLog("Error Messages", @errorMessages);

#######################################################################


# Write any error messages to log file
# Usage: writeErrorLog($headline, @errorMessages)
# If no error messages exist, calling this function will just delete any old error log file
sub writeErrorLog {
	my $headline = shift;
	my @errorMessages = @_;
	my $errorOutputFile = "ErrorLog_TurboLIFT_setup.txt";
	unlink $errorOutputFile if ( -e $errorOutputFile ); # delete old errorOutputFile, if it exists already
	
	my $numErrorMessages = scalar(@errorMessages);
	if ( $numErrorMessages > 0) {
		my $fhErrorOutputFile;
		print "numErrorMessages = $numErrorMessages (see: $errorOutputFile)\n";
		open($fhErrorOutputFile, ">", $errorOutputFile)     or die "Can't open $errorOutputFile: $!";
		#binmode($fhErrorOutputFile, ":utf8"); # Avoid message 'Wide character in print at...'
		print $fhErrorOutputFile "$headline\n";
		foreach my $message ( @errorMessages )
		{
			print $fhErrorOutputFile "$message";
		}
		close ($fhErrorOutputFile);
	}
}
