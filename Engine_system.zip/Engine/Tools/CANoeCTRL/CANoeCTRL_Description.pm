# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::                                          ::: #
# ::: this file is only used for documentation ::: #
# :::                                          ::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #
# :::::::::::::::::::::::::::::::::::::::::::::::: #

=head1 NAME

CANoeCTRL_description $Revision: 1.1 $

How to setup, run and evaluate PSP testing

=head1 REQUIREMENTS

=for html
<UL>
<LI>For Excel processing of K-Matrix additional Perl modules have to be installed:</LI>
<LI>Use Perl Package Manager of your Perl version: E.g.: C:\TurboLIFT\Perl512\bin\ppm.bat</LI>
<LI>Install:</LI>
<LI>1. Spreadsheet-ParseExcel</LI>
<LI>2. Spreadsheet-XLSX</LI>
<LI>More documentation: g:/MKS/Projects/test_sw/dllprojects/CANoeCtrl/CANoeCtrl.pj. Sub-Folders /docu (Bosch) and /Product_Documentation (Vector)</LI>
<LI>First read latest OPL for important issues.</LI>
<LI>All ISO files contain same signal names.</LI>
</UL>

=head1 Setup and Test Flow

Setup Steps:

=for html
<UL>
<LI>Optional, if PCs changed: CANoe-Client and -Server PC: Setup DCOM configuration</LI>
<LI>Optional, if CANoe changed (new version, service pack): CANoe-Client PC: Copy and register type library for updated CANoe</LI>
<LI>Edit header of CANoeCtrl_allPara.cmd</LI>
<LI>Run CANoeCtrl_allPara.cmd</LI>
<LI>Move generated files to each corresponding tool folder: MDSng, TurboLIFT</LI>
<LI>Copy&paste generated file content to each corresponding tool file: CANoe, testprog</LI>
</UL>

Offline Test Steps (default):

=for html
<UL>
<LI>Run testprog, which creates asc-trace-files</LI>
<LI>Run TurboLIFT, which evaluates asc-trace-files and writes test report</LI>
</UL>

Online Test Steps (optional):

=for html
<UL>
<LI>Run TurboLIFT, which starts/stops testprog, evaluates asc-trace-files and writes test report crash-wise</LI>
</UL>

=head1 CANoe setup

Important reminder points:

=for html
<UL>
<LI>IO-Piggy configuration of HW-Trigger Input</LI>
<LI>Add CREIS-Node (containing trigger start, start&stop CAN-trace, mastertime handling)</LI>
<LI>Configure filter for CAN and FR (allow PDUs/messges required in trace)</LI>
<LI>Configure logging block</LI>
<LI>Outpus signals, which are CAN messages with normal and fast cycle time: Change attribut to ifActive</LI>
</UL>



=head1 testprog setup

Important reminder points:

=for html
<UL>
<LI>If cycle times and default values are defined by the given signals, use -1, -1 as parameter (see also flag '$replaceBusPara4Setup' in CANoeCtrl_sigOut4ini.pl)</LI>
</UL>


=head1 MDSng setup

Input and output files for MDSng_setup.pl

Input parameter

 (CrashCodeList).txt   contains full crash code with optional version after semicolon (only crashCodes marked with _IN are read)
 (Default).design.xml  contains a default MDSng setup, which is used as signal exclusion list


Output files

 AnyPrj.design.xml
 AnyPrj.crashset.xml
 AnyPrj.mapping.xml

MLBevo(PSP)-specific hints

 Before running this Perl script:
  - (Default).design.xml can also be made by re-using a previous generated and fixed AnyPrj.design.xml, by
    removing again the generated 'AlgoInputChannel' xml-blocks inside, which are marked with 'inSimCoreOnly="true"'
 After running this Perl script:
  - Place xml files, where you like and start MDS with them (double-click XXXdesign.xml)
  - Fix assigns for ONE crash code
    First two points a) and b) consider, that, at present, the PreCare-MDS-Sensor-Keywords do not match the corresponding generated PreSense-MDS-Sensor-Keywords
	for overlapping (common) signals (ref. also to exclusion list mentioned in MDSng_setup.pl)
    a) Re-Map PreCare x,y,z to corresponding PSP-signals (PreCare-MDS-Sensor-Keywords, which are delivered again as PSP-Signals have to be re-used,
	   i.e. cannot just be deleted, since this would break the pre-defined MLBevo project setup)
    b) PreSense x,y,z  => ZERO EMULATION (Automatically generated PreSense-MDS-Sensor-Keywords are disabled, see previous comment)
    c) 3 x Messzeitpunkt => ZERO EMULATION (those signals are derived from other signals and therefore sent always automatically by CAPL code,
	   no need to inject them like other signals)
  - "Transfer" channel assignments to ALL OTHER crash codes, by "versed" usage of MDS features
  - After MDS setup is done, create MDS-Result-Database
  - Open MDS-Result-File-Database (Macro-GUI) to 1. edit and 2. generate the text format output for testprog
 Known pitfalls, when using MDS or MDS-Result-DB-GUI:
  - Do NOT vary environments or sampling time for PSP-Test (this reduces simulation run time)
  - Check all AMPLITUDE values to be 1.0 and all OFFSET values to be 0.0 for MDS Result File

=head1 TurboLIFT setup

Input for TurboLIFT_setup.pl
- file containing crash codes (empty lines and comment lines starting with ; are allowed)
- number of iterations
- offlineTraceFilePath (path or NA for online test)

Output

1) parameter file for testcase start

   C:\TurboLIFT\MLB\TC_par\_MLB\PSP\PSP_start.par

   Offline-Format:
   [PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_OUT_I1]
   CrashCode_IN   = 'TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;4'
   StateNumber    = '0'
   CrashToEvaluate  = 'OUT'
   OfflineBusTraceFile   = 'N:\Projekte\Audi_VW\AB10\AB10.44_MLB_Evo\65.System_Testing\CREIS\PSP\PreSense\05.SCI_PreS_AB1044_C02_C15_0010\02.From_CREIS\DCI_AB1044_C2_C15_PreSense_0010_No_3_CANoeCtrl\CANoeTrace_C1_S0_I1.asc'

   Online-Format: Line 'OfflineBusTraceFile' can be omitted
   [PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_IN_I1]
   CrashCode_IN   = 'TF_INT_0055_PCR_Ausloesung_Vollstraff_IN;5'
   StateNumber   = '0'
   CrashToEvaluate   = 'IN'

2) Test list

   C:\TurboLIFT\MLB\Testlists\PSP.txt

   Format
   PSP_start.TF_INT_0055_PCR_Ausloesung_Vollstraff_IN_I1


Usage TurboLIFT

  Control online or offline selection (default: use offline [testrog finished test before evaluation], optional: online [TurboLIFT remote controls testprog])
  -----------------------------------------------------------------------------------------------------------------------------------------------------------
   1. PSP_start.par: Before automatic generation of this file, specify above parameter 'offlineTraceFilePath' as
          - valid path => offline trace files *.asc
          - NA => online test
   2. \TurboLIFT\MLB\config\MLB_ProjectConst.pm
      'PSP'   =>   {
              'EVALUATION_MODE'    => 'NoTestprog',  # 'NoTestprog' (or) 'UseTestprog'

  Control tstLog-Header Information
  ---------------------------------
   \TurboLIFT\MLB\config\CFG_MLB.pm contains header information for tstLog:
    # $LIFT_ProjectDescription = "Audi MLBevo 10.44 : C2 sample phase";
    # $SAD_file = 'c:\Program Files (x86)\Windiag\SAD\au1044_BB00000_c16_Cat2_20131107.sad';
    # $EEPROM_file = 'D:\MLBEVO\AU1044_BB00000_C16_Cat2_20131107\Initialised_EEPROM.hex';

  Running the test
  ----------------
   1. Copy generated files (PSP.txt and PSP_start.par) to
      - \TurboLIFT\MLB\Testlists\PSP.txt
      - \TurboLIFT\MLB\TC_par\_MLB\PSP\PSP_start.par
   2. Before running OFFLINE evaluation, switch on ECU, since PSP evaluation reads ECU identification
   3. Run: \TurboLIFT\MLB\start_PSP.bat

  Archiving test reports
  ----------------------
   How to archive test reports after test has finished
      a) Open testreports.html with Windows Explorer (C:\TurboLIFT\MLB\Reports.html)
      b) Use Archive Button, which creates a zip-file (name and place is fixed and will be below C:\TurboLIFT\MLB\reports)
      c) Delete inside same zip-file all unnecessary files ():
         - -snapshot- (all testcases, configuration files, all files in config-folder
         - IC and EC (start with two __)
         - 3 files (...eval.txt, ...log.txt, ...result.txt, but keep ...result.html)
      d) Optional: Unzip again and run 7-Zip > Add to archive... and specify 'Split to volumes, bytes' 50M (example: acceptable size for Audi engineering portal)
		
   Note: With next checkpoint (~E11/2013) same files will be placed differently (inside the root folder at one single place)

=cut