use strict;
use warnings;
use REST::Client;
use LWP::UserAgent;
use JSON::PP;
use Archive::Zip qw(:ERROR_CODES);

# input: stream name, query, apiKey
# Todo: 
# - input arguments
# - from stream name get Compiler_Results and corresponding ?other hexfiles (e.g. EDR)?

my $ua = LWP::UserAgent->new;
$ua->ssl_opts(SSL_verify_mode => 0, verify_hostname => 0);
my $username = 'phc2si';
my $apiKey = "AKCp8hz3iTEkXhfMMSkdeqDuQhRwkm4bE5aoCF57Rx6gT3AC5y9d5FnwagGWpzRXUbspbXqqv"; # APIkey can be retrieved from Artifactory
$ua->credentials("rb-airbag-artifactory.de.bosch.com", "", $username, $apiKey);
my $client = REST::Client->new(useragent => $ua);
my $host = "https://rb-airbag-artifactory.de.bosch.com";


print("Getting latest builds with BATBasic=PASSED...\n");
my $response_href = Request( 'GET', "$host/api/search/prop?repos=ab12_dev&build.name=ab12 :: ab12_ca_RT4&BATBasic=PASSED" );
my $content_href = DecodeJSONContent($response_href);
my ($uri, $filename);
foreach my $element ( reverse @{$content_href->{results}} ) {
    $uri = $element->{uri};
    if( $uri =~ /(Compiler_Results_\d+\.zip)$/ ){
        $filename = $1;
        last;
    }
}
print("Getting download link for latest build ($filename)...\n");
$response_href = Request( 'GET', $uri );
$content_href = DecodeJSONContent($response_href);
my $downloadUri = $content_href->{downloadUri};
my $file = 'C:\temp\\'.$filename;

print("Downloading latest build ($filename)...\n");
$response_href = Request( 'GET', $downloadUri );
my @rows = $response_href->{content};
open ( my $fhwrite, ">:raw", "$file") or die "$file: $!";
if (defined $fhwrite) {
    print $fhwrite @rows;
    close ( $fhwrite );
}

print("Extracting files from zip-file ($filename)...\n");
my $extractFolder = $file;
$extractFolder =~ s/\.zip//;

my $zip = Archive::Zip->new();
my $status = $zip->read( $file );
die "Read of $file failed\n" if $status != AZ_OK;
my @members = $zip->members();
foreach my $member ( @members ) {
    my $extractFilename = $extractFolder.'\\'.$member->{fileName};
    $status = $zip->extractMember($member, $extractFilename);
    die "Extracting $member from $file failed\n" if $status != AZ_OK;
}
print("Files extracted to $extractFolder.\n");

1;


sub Request {
    my $method       = shift;
    my $uri          = shift;
    my $body_content = shift;
    my $options      = shift;

    $client->request( $method, $uri, $body_content, $options );
    my $responseCode         = $client->responseCode();
    my $responseContent      = $client->responseContent();
    die "Error (code = $responseCode) in request '$method $uri': Content = '$responseContent'\n" if $responseCode != 200;
    my $responseHeaders_href = {};
    foreach ( $client->responseHeaders() ) {
        $responseHeaders_href->{$_} = $client->responseHeader($_);
    }

    print "Response code = $responseCode for $method $uri\n";

    my $response_href = {
        code    => $responseCode,
        content => $responseContent,
        headers => $responseHeaders_href,
    };

    return $response_href;
}

sub DecodeJSONContent{
    my $response_href = shift;

    #try to decode JSON string
    my $responseContent_JSON = $response_href->{content};
    my $decodeCommand = 'my $eval = decode_json($responseContent_JSON)';
    my $responseContent_href = eval $decodeCommand; # using eval to avoid a crash if the string is not a proper JSON string

    #return undecoded string if decoding was not successful
    unless( $responseContent_href ) {
        print "ERROR: Could not decode JSON string of response: $response_href->{content}\n";
        return;
    }

    return $responseContent_href;
}
