use strict;
use Win32::EventLog;

print( "Collecting perl.exe errors from Windows event logs...\n");


my ($recs, $base, $x, $event_href, $message_href);

# get handle to Windows event log, Application section
my $eventLogHandle = Win32::EventLog->new("Application") or die "Can't open Application EventLog\n";

# get number of event log entries into $recs
$eventLogHandle->GetNumber($recs) or die "Can't get number of EventLog records\n";

# get oldest event log entry into $base
$eventLogHandle->GetOldest($base) or die "Can't get number of oldest EventLog record\n";

# loop over all events
my $outputText = '';
while ($x < $recs) {
    # read current event
    $eventLogHandle->Read(EVENTLOG_FORWARDS_READ|EVENTLOG_SEEK_READ, $base+$x, $event_href) or die "Can't read EventLog entry #$x\n";

    # check if the event is an error
    if ($event_href->{Source} eq "Application Error") {

        # get the event text
        Win32::EventLog::GetMessageText($event_href);
        my $messageText = $event_href->{Message};

        # create output if the event text contains TurboLIFT (as part of the perl.exe path)
        if( $messageText =~ /perl\.exe/i ) {
            my $dateTime = scalar localtime $event_href->{'TimeGenerated'}; # convert secs after 1970 into readable time string 
            $outputText .= "Error Event Date/Time: $dateTime\n\n";
            $outputText .= "$messageText\n\n";
        }
    }
    $x++;
}

# write output text to output file
my $outputFile = 'EventLogTurboLIFT.txt';
open(my $fh, ">", $outputFile) or die "Can't open > $outputFile : $!";
print $fh $outputText;
close $fh;

print( "perl.exe error events written to file $outputFile .\n");
print( "READY.\n");
system('pause');
