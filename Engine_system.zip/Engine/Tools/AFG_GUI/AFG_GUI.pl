#!usr\bin\perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################

use File::Basename;


BEGIN
{
 	unless ( defined $ENV{TURBOLIFT_PERL_HOME} ) {
        print "ENVIRONMET VARIABLE %TURBOLIFT_PERL_HOME% not defined\nplease execute Engine/run_once/_run_once.bat !!!\n\7";
        sleep(10);
        exit;
    }
	
	print ("Used perl from location : '$^X' \n");
    if ( uc($^X) ne uc("$ENV{TURBOLIFT_PERL_HOME}\\bin\\perl.exe") ) {
        print "wrong perl, recalling engine with TURBOLIFT_PERL %TURBOLIFT_PERL_HOME% = $ENV{TURBOLIFT_PERL_HOME} ...\n";
        system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $0 @ARGV");
        print "recalling done\n";
        exit;
    }
	
	my $LIFT_exec_path='../..';

    # add directories to search path for perl modules    
    unshift @INC, "$LIFT_exec_path/modules/Common_library";
    unshift @INC, "$LIFT_exec_path/modules/Device_layer/AFG1";
	unshift @INC, "$LIFT_exec_path/modules/Device_layer/GPIB/Win32";
}

use strict;
use AFG332x0;
use Tk;
use Tk::BrowseEntry;

my $Toolversion = "AFG_GUI ($VERSION)";      # Tool version number

my ($main, $ConnectionFrame, $ButtonFrame, $ConnectionEntry, $display_txt, $ScopeLabel, $ScopeMenu);
my ($ConnButton_text, $value_file,$value2_file, $Box_Save_Value_Frame,$Box_Restore_Value_Frame, $ValueEntry,$Value2Entry);
my ($Box_Save_Button_Frame, $Box_Restore_Button_Frame);
my ($connected, $connection,$DeviceID, $afg, $Box_Save, $Box_Restore, $configcomment, $Box_Save_Value_Conf_Frame);
my ($Button_Trigger, $Trigger_Frame, $Help_String);
my ($Button_Browse_Save_File, $Button_Save_Screen, $Button_Save_Date_A_Screen, $Button_Save_Conf);
my ($Button_Browse_Open_File, $Button_Restore_Config);
my ($Device_ID, $Conn_Status);

$ConnButton_text="CONNECT";
$configcomment="created with $Toolversion";

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "AFG_GUI $VERSION" );

# create frame 'ConnectionFrame' in window 'main'
$ConnectionFrame = $main -> Frame() -> pack( "-pady" => 20 );

$Trigger_Frame = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 5, "-fill" => 'x' ) -> pack( );

# create frames in window 'main'

#create Box 1: For 'Save Parameters'
$Box_Save = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );

#create Box 2: For 'Save restore'
$Box_Restore = $main -> Frame("-relief" => 'groove', "-bd" => 2) -> pack( "-padx" => 5,"-pady" => 10, "-fill" => 'x' );

#create Sub Frames in Box_Save
$Box_Save_Value_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );
$Box_Save_Value_Conf_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );
$Box_Save_Button_Frame = $Box_Save -> Frame() -> pack( "-pady" => 5 );

#create Sub Frames in Box_Restore
$Box_Restore_Value_Frame = $Box_Restore -> Frame() -> pack( "-pady" => 5 );
$Box_Restore_Button_Frame = $Box_Restore -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 10 );


# create label in window 'main'
$main -> Label( "-textvariable" => \$DeviceID, 
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 5 );


# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt,
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );


######## connection

# create 'connect' button
$ConnectionFrame -> Button
  (
  "-textvariable" => \$ConnButton_text,
  "-command" => sub
    { # execute when button is pressed  
    
        if ($connection) {
          unless ($connected){
             $afg = AFG332x0->new(\*LOG);
            
            #exception handlig for Connect function
            eval {                        
                $Device_ID = $afg->connect($connection);            
             };
             
                              
             if($Device_ID eq "")
             {
                #write Error Message
                $display_txt= "Connection failed"; 
                w2log("Connection failed"); 
             }
             else
             {                
                $ConnButton_text= "disconnect";
                $display_txt= "connected to Device $Device_ID ";
                $connected = 1;
                Set_Active();
             }
          }
          else{
             $afg->disconnect();
             $ConnButton_text= "CONNECT";
             $display_txt= "disconnected from Device";
             $connected = 0;
             #clear handle
             undef $afg;
             Set_Inactive();
          }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select connection details first!"
            );
        }
    }
  )
-> pack ("-side" => 'left');


# create label in Frame 'ConnectionFrame'
$ConnectionFrame -> Label( "-text" => " via ", )
            -> pack( "-side" => 'left', );

# create entry 'ConnectionEntry' in 'ConnectionFrame'
$ConnectionEntry = $ConnectionFrame -> BrowseEntry(
            "-width" => 20,
            "-variable" => \$connection, 
            );
$ConnectionEntry -> pack( "-side" => 'left', );
$ConnectionEntry -> insert("end",'GPIB: 2');

# create 'exit' button
$ConnectionFrame -> Button
  (
  "-text" => "E X I T",
  "-background" => "red",
  "-command" => sub
    {$main->destroy;}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-padx" => 20);



######## values


# create entry 'ValueEntry' in 'Box_Save_Value_Frame'
$ValueEntry = $Box_Save_Value_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$value_file, 
            );
$ValueEntry -> pack( "-side" => 'left', );

# create 'browse file' button
$Button_Browse_Save_File = $Box_Save_Value_Frame -> Button
(
"-text" => "Browse save file",
"-state" => "disabled",
"-command" => sub
  {
        #store old variable value
      $Help_String = $value_file;
      
      # browse for file
      $value_file = $main -> getSaveFile
        (
        "-filetypes"  =>
          [
          ["All files", '.*'],
          ["png files", '.png']
          ],
        "-title"      => "select file to save values",
        );
      # if a file was chosen
      if ( $value_file )
        {
        #extract directory
        
        print "\n $value_file was chosen\n";
        }
      else
        {
          #restore old variable value
          $value_file = $Help_String;
          print "no filename!\n";
       }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# create label in window 'main'
$Box_Save_Value_Conf_Frame -> Label( "-text" => "config comment: ", 
         )
      -> pack( "-side" => 'left', "-pady" => 5 );

# create entry 'ValueEntry' in 'Box_Save_Button_Frame'
$Box_Save_Value_Conf_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$configcomment, #reference to $prj_id
            )-> pack( "-side" => 'left', );




# create 'save DATA' button
$Button_Save_Date_A_Screen = $Box_Save_Button_Frame -> Button
  (
  "-text" => "save DATA",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value_file) {
                $display_txt="saving values to $value_file";
                $main -> update();
                $afg->saveValues($value_file,"1+2+3+4",100000,1);
                $display_txt="values saved";
                
                 #Save File Name              
                 $Help_String = $value_file;
                 
                 #change file extension to png 
                 if($value_file =~ /\.\w+$/ ) {
                    $value_file =~ s/\.\w+$/.png/;
                 
                    $Help_String = $value_file;
                                     
                    system(exec, $Help_String) or $display_txt="graph created in: ". $Help_String;
                    $display_txt= $Help_String                    
                 }
                 else {
                    $Help_String = $value_file . ".png";
                    #Open graph
                    system(exec, $Help_String) or $display_txt="graph created in: ". $Help_String;
                    $display_txt= $Help_String;
                }
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);



# create 'SAVE config' button
$Button_Save_Conf = $Box_Save_Button_Frame -> Button
  (
  "-text" => "SAVE config",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value_file) { 
            
                #save Config File as a txt File
                
                #first. check whether file name contains an extension or not  
                if($value_file =~ /\.\w+$/ ) {
                
                    #replace extention with txt
                    $value_file =~ s/\.\w+$/.txt/;
                                        
                    $Help_String = $value_file;
                                    
                    $display_txt="saving config to $Help_String";
                    $main -> update(); 
                    
                    #Pass Name with txt extention to SaveConfig 
                    $afg->saveConfig($Help_String,$configcomment);
                                    
                    $display_txt= $Help_String;#"config saved";
                    
                } # File name contains no extension
                else {
                    #Add txt extention
                    $Help_String = $value_file . ".txt";
                    
                    $value_file = $Help_String;
                    
                    $display_txt="saving config to $Help_String";
                    $main -> update(); 
                    
                    #Pass Name with txt extention to SaveConfig
                    $afg->saveConfig($Help_String,$configcomment);
                                    
                    $display_txt= $Help_String;# $display_txt="config saved";
                }                
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
               '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);



# create entry 'ValueEntry' in 'Box_Save_Value_Frame'
$Value2Entry = $Box_Restore_Value_Frame -> Entry(
            "-width" => 50,
            "-textvariable" => \$value2_file, #reference to $prj_id
            );
$Value2Entry -> pack( "-side" => 'left', );


# create 'browse file' button
$Button_Browse_Open_File = $Box_Restore_Value_Frame -> Button
(
"-text" => "Browse open file",
"-state" => "disabled",
"-command" => sub
  {
      # browse for file
      $value2_file = $main -> getOpenFile
        (
        "-filetypes"  =>
          [
          ["config files", '.txt'],
          ["All files", '.*']
          ],
        "-title"      => "select file to load values",
        );
      # if a file was chosen
      if ( $value2_file )
        {
        #extract directory
        print "\n $value_file was chosen\n";
        }
      else
        {
          print "no filename!\n";
       }
  }
)
  -> pack ("-side" => 'left',"-padx" => 5,);


# =head1 create 'RESTORE config' button
$Button_Restore_Config = $Box_Restore_Button_Frame -> Button
  (
  "-text" => "RESTORE config",
  "-state" => "disabled",
  "-command" => sub
    { # execute when button is pressed  
        if($connected){
            if ($value2_file) { 
                $display_txt="restoring config from $value2_file";
                $main -> update();
                                
                $afg->restoreConfig($value2_file);
                $display_txt="config restored";
            }
            else{
                $main->messageBox(
                    '-icon'    => "error", #qw/error info question warning/
                    '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                    '-title'   => 'Attention',
                    '-message' => "!Please select file first!"
                );
            }
        }
        else{
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please connect first to Device!"
            );
        }
    }
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-padx" => 30);

#Fuction Set all Buttons into Normal (active) State
sub Set_Active(){

     $Button_Browse_Save_File -> configure("-state" => "normal");
     $Button_Browse_Open_File-> configure("-state" => "normal");
     #$Button_Save_Date_A_Screen-> configure("-state" => "normal");
     $Button_Save_Conf -> configure("-state" => "normal");
     $Button_Restore_Config -> configure("-state" => "normal");
}


#Fuction Set all Buttons into Inactive State
sub Set_Inactive(){

     $Button_Browse_Save_File -> configure("-state" => "disabled");
     $Button_Browse_Open_File-> configure("-state" => "disabled");     
     #$Button_Save_Date_A_Screen-> configure("-state" => "disabled");
     $Button_Save_Conf -> configure("-state" => "disabled");
     $Button_Restore_Config -> configure("-state" => "disabled");
 }



#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">AFG_GUI_log.txt" ) or die "Couldn't open DSO_GUI_log.txt : $@";
w2log("######################################################################\n");
w2log("### AFG Agilent 332x0 GUI ###\n"); 
w2log("######################################################################\n");
w2log("$Toolversion logfile\n");

MainLoop;

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}

=head1 usage

first of all you have to connect to the device you want to control. For AFG GPIB  is recommended. Edit the address according to your device settings.

Press CONNECT button before any other action.

to load a config just select the file with 'Browse open file' button and press 'RESTORE config' button.

to save a config just select the file with 'Browse save file' button, edit comment if required and press 'SAVE config' button.


a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, AFG documentation.

=cut
