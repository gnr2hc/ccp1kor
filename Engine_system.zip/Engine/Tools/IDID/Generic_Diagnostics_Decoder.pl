#!/C:/perl/bin -w
#****************************************************************************
#                                                                           *
# Copyright (c) 2011 Robert Bosch GmbH, Germany                             *
#               All rights reserved                                         *
#                                                                           *
#****************************************************************************
#
# $Source: Tools/IDID/Generic_Diagnostics_Decoder.pl $
# $Revision : 1.0 $
#
# Description:
#      IDID is Diagnostics Interactive Decoder
#   EDR decoder for  all AKLV 37 projects
#   File Needed :
#          AKLV xls for decoder and canoe for simulation
#
#
#  Remarks: -
#           - Perl Version 5.6 and more  are needed to run this script
#
#****************************************************************************

use strict;
use warnings;
use Fcntl;    #The Module
use Sys::Hostname;
my $User_ID       = getlogin;
my $Computer_Name = hostname;
print "+++++++++++++++++++++++++++++++++";
print "$User_ID";
print "$Computer_Name";
print "+++++++++++++++++++++++++++++++++";

my $numArgs;
my $excel;
my $Book;
my $Sheet;
my $argnum;
my $Local_Time = scalar localtime;

my @EDID_Error_Array;
my $EDID_Start_Byte;
my $EDID_Received_Value_HEX;
my $EDID_Expected_Value_HEX;
my $Total_Number_Of_bytes_Notreported_Edid;

my %Month_Decimal = (
    "Jan" => '1',
    "Feb" => '2',
    "Mar" => '3',
    "Apr" => '4',
    "May" => '5',
    "Jun" => '6',
    "Jul" => '7',
    "Aug" => '8',
    "Sep" => '9',
    "Oct" => '10',
    "Nov" => '11',
    "Dec" => '12',
);

my @Time_Split_Array = split( / /, $Local_Time, );
my @temp_array;

foreach (@Time_Split_Array) {
    if ($_) {
        push( @temp_array, $_ );
    }
}
@Time_Split_Array = @temp_array;

my $weekday = $Time_Split_Array[0];
my $month   = $Time_Split_Array[1];
my $date    = $Time_Split_Array[2];
my $time    = $Time_Split_Array[3];
my $year    = $Time_Split_Array[4];

my $RowCnt1 = 0;
use File::Basename;
my $File_Path = dirname(__FILE__);
print " File_Path = $File_Path", "\n";

# Provide the file Path
#my $File_Path ="D:\Tools\Muthu_Createed_Tools\EDR1l";
$File_Path =~ s/\//\\\\/;
print " File_Path = $File_Path", "\n";

# Select the project you want to run the Script
my $Project_Name = "AKLV_Decoder";

#my $Project_Name ="Ford";
#my $Project_Name ="Daimler";
#my $Project_Name ="DTruck";

my $Response_Length_Check_Status;

# Provide the Input Decoder Xls Doccument  Eg: DTruck.xls,Chrysler.xls
my $Input_Xls_File = "$Project_Name.xls";

# Output HTML File with Full path
my $HTML_File_Name_With_Path = "$File_Path\\" . "$Project_Name" . "Diagnostics_Response.html";

my $Logo_Name = "Team_Logo" . ".jpg";
print "HTML_File_Name_With_Path  =$HTML_File_Name_With_Path \n\n";
if ( -e "$HTML_File_Name_With_Path" ) {
    print "File Exists!",              "\n";
    print "Remove the Readonly Flag ", "\n";
    chmod 0777, $HTML_File_Name_With_Path;

    #Win32::File::SetAttributes ($HTML_File_Name_With_Path, NORMAL) or die "Can't modifly perms: $!\n";
    #print "Delete the Existing File","\n";
    #unlink("$File_Path\\EDR_Response.html");
    close("$HTML_File_Name_With_Path");
}

# Open the file for writing
open F1, (">$HTML_File_Name_With_Path") || die "$!";
print "Content-type :'text/html;' \n\n";

# Write the Files in HTML Syntax Form
print F1 "<html>", "\n";
print F1 "<head>", "\n";

# Title of the HTML File
print F1 "<div>",                                                                                                              "\n";
print F1 "<title>$Project_Name Diag Response Decoder</title>",                                                                 "\n";
print F1 '<div id="content" style="background-color:#FFFFFF;height:1px;width:100%;vertical-align:middle; text-align:center">', "\n";

#<img src= 'Team_Logo.jpg'  align=center alt=AKLV_Decoder.'Logo' width='200' height='125' ><br>

print F1 "<img src= " . '.\Logo\Tool_Logo.jpg' . " align='center' alt='Tool Logo' width='100' height='25' ><br>", "\n";
print F1 "</div>", "\n";
print F1 "<div>",  "\n";
print F1 '<h1 align=center >  <font face="Segoe UI Semibold" color = "#B00000 ">' . 'Diagnostics Interacive Decoder' . "</font></h1>", "\n";

#print F1 '<h2 align=center >  <font face="Segoe UI Semibold" color = "#B00000 ">'.  "$Project_Name Project"."</font></h2>","\n";
#print F1 "<h2 align=center Font  =Segoe UI Semibold color='#990000'> $Project_Name Project </h2>","\n";
print F1 "</div>", "\n";

print F1 "</head>\n";

# Script to get the response from HTML Tag Java script
print F1 '<script>',                                                                 " \n";
print F1 'function Get_Response_Bytes( variable1, variable2)',                       "\n";
print F1 "{ \n",                                                                     "\n";
print F1 'var Response_String = document.getElementById("Response").innerHTML',      "\n";
print F1 ' var HTML_Response_Array = Response_String.split(/ /g)',                   "\n";
print F1 ' var END_Array =parseInt(variable1)+parseInt(variable2);',                 "\n";
print F1 'var Slice_Response_Array= HTML_Response_Array.slice(variable1,END_Array)', "\n";
print F1 'document.getElementById("demo").innerHTML= Slice_Response_Array',          "\n";
print F1 "}",                                                                        "\n";

# Script to Clear the response from HTML Tag Java script
print F1 'function Clear_Area( )', "\n";
print F1 "{ \n",                   "\n";

print F1 'document.Read.Start_Byte.value= ""',            "\n";
print F1 'document.Read.No_of_Bytes.value= ""',           "\n";
print F1 'document.getElementById("demo").innerHTML= ""', "\n";

print F1 "}", "\n";

print F1 'function writeToExcel() ', "\n";
print F1 ' { ',                      "\n";

print F1 ' var i, j, str,col_val; ',                                                   "\n";
print F1 ' myTable = document.getElementById("HTML_Table"); ',                         "\n";
print F1 'rowCount = myTable.rows.length, ',                                           "\n";
print F1 'excel = new ActiveXObject("Excel.Application");// Activates Excel ',         "\n";
print F1 'excel.Workbooks.Add(); // Opens a new Workbook ',                            "\n";
print F1 'excel.Application.Visible = true; // Shows Excel on the screen ',            "\n";
print F1 'for (i = 0; i < rowCount; i++) { ',                                          "\n";
print F1 'for (j = 0; j < myTable.rows[i].cells.length; j++) { ',                      "\n";
print F1 'str = myTable.rows[i].cells[j].innerText; ',                                 "\n";
print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Value = str; // Writes to the sheet ', "\n";
print F1 'col_val =myTable.rows[i].cells[j].bgColor ;',                                "\n";

#print F1 ' alert(myTable.rows[i].cells[j].bgColor );',"\n";
#xls.Selection.Interior.ColorIndex = #8A2BE2;
print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Font.Size= 10 // Writes to the sheet ', "\n";
print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Font.Name = "Segoe UI Semibold";',      "\n";
print F1 'if(col_val.toLowerCase()  =="#AAAAAA".toLowerCase())',                        "\n";

#print F1 'if (col_val.equalsIgnoreCase("#AAAAAA") )',"\n";
print F1 '{', "\n";

#print F1 'alert("Grey matces");',"\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'16';", "\n";
print F1 '}',                                                    "\n";
print F1 'if(col_val.toLowerCase()  =="#FFFFFF".toLowerCase())', "\n";
print F1 '{ ',                                                   "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'2';", "\n";
print F1 '}', "\n";

#lINEAR
print F1 'if(col_val.toLowerCase()  =="#66FFFF".toLowerCase())', "\n";
print F1 '{ ',                                                   "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'8';", "\n";    #sky blue
print F1 '}', "\n";

#Tabel
print F1 'if(col_val.toLowerCase()  =="#DEBDFF".toLowerCase())', "\n";
print F1 '{ ',                                                   "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'39';", "\n";    # Violet
print F1 '}', "\n";

#identical
print F1 'if(col_val.toLowerCase()  =="#9966FF".toLowerCase())', "\n";
print F1 '{ ',                                                   "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'40';", "\n";
print F1 '}', "\n";

#Red
print F1 'if(col_val.toLowerCase()  =="#FF0000".toLowerCase())', "\n";
print F1 '{ ',                                                   "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'3';", "\n";
print F1 '}', "\n";

#print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex= myTable.rows[i].cells[j].style.backgroundColor ;',"\n"; rows[i].style.backgroundColor;
print F1 'if(i+1 ==1)', "\n";
print F1 '{',           "\n";
print F1 'excel.ActiveSheet.Cells(i+1,j+1).Interior.ColorIndex=' . "'30';", "\n";
print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Font.Size= 12 // Writes to the sheet ', "\n";

print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Font.ColorIndex= 2 // Writes to the sheet ', "\n";
print F1 'excel.ActiveSheet.Cells(i + 1, j + 1).Font.Name = "Segoe UI Semibold";',           "\n";

#xls.ActiveCell.EntireRow.Font.ColorIndex = 2;

#print F1 'excel.ActiveSheet.Cells(i+1,j+1).HorizontalAlignment='.'"xlHAlignCenter";',"\n";
print F1 '}',                                                  "\n";
print F1 '} ',                                                 "\n";
print F1 '} ',                                                 "\n";
print F1 'excel.Range("A2", "E1000").EntireColumn.AutoFit();', "\n";
print F1 'excel.Range("H2", "H1000").EntireColumn.AutoFit();', "\n";

#print F1 'excel.Range("A1", "H1").HorizontalAlignment.FontStyle='.'" -xlHAlignLeft";',"\n";
print F1 'excel.Range("A2", "H1000").Font.FontStyle=' . '"Normal";', "\n";
print F1 'excel.Range("A2", "C1000").HorizontalAlignment = -4108;', "\n";    # Center
print F1 'excel.Range("E2", "G1000").HorizontalAlignment = -4108;', "\n";    # Center
print F1 'excel.Range("H2", "H1000").HorizontalAlignment = -4131;', "\n";    # Center
print F1 'excel.Range("D2", "D1000").HorizontalAlignment = -4131;', "\n";    # Center
                                                                             #print F1 'excel.Range("H2").HorizontalAlignment := "xlHAlignCenter";',"\n";

print F1 '} ',        "\n";
print F1 '</script>', "\n";

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

print F1 '<div id="content" style="background-color:#FFFFFF;height:50px;width:100%;vertical-align:middle; text-align:center">', "\n";
print F1 "<img src= " . '.\Logo\Team_Logo.jpg' . " align='center' alt='Teamlogo' width='200' height='125' ><br>", "\n";

print F1 '<FieldSet> ',                                                                                                  "\n";
print F1 '<FONT COLOR=WHITE FACE=Segoe UI bold SIZE=4>',                                                                 "\n";
print F1 '<Legend style="color: #B00000" > Report Info </Legend>',                                                       "\n";
print F1 '<FONT COLOR=WHITE FACE=Segoe UI bold SIZE=2>',                                                                 "\n";
print F1 "<p  align=left> <font face='Segoe UI Semibold' color = '#330099'> User_ID   ::  $User_ID </font> </p> ",       "\n";
print F1 "<p  align=left> <font face='Segoe UI Semibold' color = '#330099'> PC_Name   ::  $Computer_Name </font> </p> ", "\n";

# Time and Date of the Generated report
print F1 "<p  align=left> <font face='Segoe UI Semibold' color = '#330099'> DATE   ::  $weekday ::$date-$Month_Decimal{$month}-$year </font> </p> ", "\n";
print F1 "<p  align=left> <font face='Segoe UI Semibold' color = '#330099'> TIME   ::  $time </font> </p> ",                                         "\n";
print F1 "</div>",                                                                                                                                   "\n";
print F1 '<br> ',                                                                                                                                    "\n";

# print F1  '</FieldSet> ',"\n";

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
print F1 '<FieldSet> ',                                          "\n";
print F1 '<FONT COLOR=WHITE FACE=Segoe UI bold SIZE=4>',         "\n";
print F1 '<Legend style="color: #B00000" > Reference </Legend>', "\n";
print F1 '</FONT>',                                              "\n";

#print F1  '<Legend style="color: #B00000;>< font face="Segoe UI Semibold" font-size: 12pt"> Reference </font></Legend>',"\n";
print F1 '<p > <font face="Segoe UI Semibold" color = "#330099 ">Decoder Reference</p></font>', "\n";
print F1 "<p><a href= file:///$File_Path\\$Input_Xls_File>File Reference Link</a></p>",         "\n";
my $AKLV_Doors_Export_File_Name;
$AKLV_Doors_Export_File_Name = "EDID list.xls";
print F1 '<p > <font face="Segoe UI Semibold" color = "#330099 ">AKLV SRS Export Reference</p></font>',    "\n";
print F1 "<p><a href= file:///$File_Path\\$AKLV_Doors_Export_File_Name>AKLV SRS Export Reference</a></p>", "\n";

print F1 '<br> ',        "\n";
print F1 '</FieldSet> ', "\n";
print F1 '<br> ',        "\n";
my @EDR_response;

#Use for Debugging purpose
# @EDR_response= qw (62 FA 13 00 01 00 01 00 00 04 00 00 00 05 00 02 00 06 FF FF 00 07 FF FF 00 09 FF FF 00 15 64 FF FF FF 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7E 7F 00 17 64 FF FF FF 7F FB 7F F9 7F FA 7F FA 7F FA 7F FA 7F F9 7F FA 7F FA 7F FA 7F FA 7F FA 7F FA 7F FA 7F FA 7F FA 7F FA 7F FF 7F FF 7F FF 7F FF 7F FF 7F FF 7F FF 7F FF 7F FF 00 19 64 FF FF FF 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 7F 00 1B 0A FF FF FF 6E 6E 86 F4 F4 00 86 7A E8 F4 FE FE 00 E8 7A 6E 7A 6E 00 0C 6E 7A 00 92 7A 6E 00 7A 86 E8 F4 00 7A 00 6E 7A 6E F4 00 E8 7A 7A F4 F4 86 F4 6E 00 9E 00 6E 7A F4 86 00 86 00 7A 0C 7A F4 00 1F 64 FF FF FF 7F 83 8D 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 92 00 20 64 FF FF FF 7F 7E 7B 77 74 70 6D 69 66 62 5F 5B 58 54 51 4E 4A 47 46 46 46 46 46 46 46 46 00 21 92 00 22 46 00 23 0A 00 24 45 00 25 45 00 28 FF 00 29 FF 00 2D 01 00 2E FF FF 00 2F 01 9A 00 33 00 0C 00 34 00 11 00 36 00 00 38 00 0C 00 39 00 11 00 3A FF FF 00 3B 00 00 3C FF 00 3D FF FF 00 3E FF FF 00 3F FF FF 00 41 FF FF 00 42 FF FF 00 43 FF FF 00 47 00 00 48 FF 00 4B FF 00 4D 00 00 4E FF 00 4F FF 00 5B 32 32 32 32 32 32 32 32 32 32 32 00 5C 2C 36 45 59 09 0E 18 22 2C 36 45 00 5D 32 3A 42 4A 00 00 03 0B 13 1B 23 00 5E 6C 78 85 91 9E AA 4D 4D 53 5F 6C 00 5F 02 01 01 01 01 00 01 01 01 02 02 00 6D FF FF 00 6E FF FF 00 70 FF FF 00 71 FF FF 03 E8 A5 03 E9 00 12 03 EA 00 12 03 FB 04 03 FD 00 01 03 FE 1E B8 E9 BC );
# Read the data from commans lIne Arguments
# This parameter are passing from the CAPL Script
$numArgs = $#ARGV + 1;

# Number of parameters ie Length of the response
print " Total Number of command-line arguments =  $numArgs \n";
if ( $ARGV[$0] =~ m /Response/i ) {
    my $Ressponse_File_Name_With_Path = "$File_Path\\Response.txt";
    unless ( -e $Ressponse_File_Name_With_Path ) {
        print "\n\nERROR:",                                                      "\n\n";
        print "***************************************************************", "\n";
        print " $Ressponse_File_Name_With_Path is not created",                  "\n";
        print "***************************************************************", "\n";

        print F1 "</table>", "\n";
        my $temp_Line = " Error in Generating EDR Decoder Report :\n";
        print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#3D18E5">' . "$temp_Line" . "</font></h2>";

        $temp_Line = " Response.txt is not  created from Canoe \n";

        print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";

        print F1 "</body>", "\n";
        print F1 "</html>", "\n";

        print "************************************************************************************" . "\n";
        print "$HTML_File_Name_With_Path is created ", "\n";
        print "************************************************************************************" . "\n";

        # Close the HTML Files
        close F1;
        sleep(1);
        my $ret = system("$HTML_File_Name_With_Path");
        print " ret = $ret";

        #close $excel;
        print "exit";

        #exit 1;
    }

    # If File is present then read from File
    open( READ, "<$Ressponse_File_Name_With_Path" ) || die("$Ressponse_File_Name_With_Path could not open file \n $_!");
    my @FileReadArray = <READ>;
    close READ;
    foreach (@FileReadArray) {
        my @responseline = split( / /, $_ );
        push( @EDR_response, @responseline );
    }
}

#response length is less tna 1024 bytes
else {
    foreach $argnum ( 0 .. $#ARGV ) {

        # Store the Each parameter into an array
        if ( length( $ARGV[$argnum] ) == 1 ) {
            $EDR_response[$argnum] = "0$ARGV[$argnum]";
        }
        else {
            $EDR_response[$argnum] = $ARGV[$argnum];
        }
    }
}
print @EDR_response, "\n";
my $Received_Response_Length = scalar(@EDR_response);
my $Resp_col_TextArea        = int( $Received_Response_Length / 30 );
print "Resp_col_TextArea = $Resp_col_TextArea",  "\n";
print "Resp_Length = $Received_Response_Length", "\n";

# Extracting the resonse from the response fro the request
# To Get the SIDfrom the response
my $SID          = ( $EDR_response[0] - 40 );
my $Diag_request = "$SID  $EDR_response[1]  $EDR_response[2] \n";
print F1 '<FieldSet> ',                                                                                                                           "\n";
print F1 '<FONT COLOR=WHITE FACE=Segoe UI bold SIZE=4>',                                                                                          "\n";
print F1 '<Legend style="color: #B00000" > Request and Response </Legend>',                                                                       "\n";
print F1 '</FONT>',                                                                                                                               "\n";
print F1 '<br> ',                                                                                                                                 "\n";
print F1 '<table style="border:1px solid black;">',                                                                                               "\n";
print F1 '<tr>',                                                                                                                                  "\n";
print F1 "<th width=200 align=Left  bgcolor='#006600' > <FONT COLOR=WHITE FACE=Segoe UI Semibold SIZE=4>Diagnostics Request</FONT>  </th> </tr>", "\n";
print F1 "</table>",                                                                                                                              "\n";
print F1 "<br>",                                                                                                                                  "\n";
print F1 '<textarea  id="Request" rows=1 cols=100 >',                                                                                             "\n";

# print F1 '<p >';
print F1 "$Diag_request ", "\n";

#print F1  '</p>',"\n"; # Response Data
print F1 "</textarea>",                                                                                                                            "\n";
print F1 "<br>",                                                                                                                                   "\n";
print F1 '<table style="border:1px solid black;">',                                                                                                "\n";
print F1 '<tr>',                                                                                                                                   "\n";
print F1 '<br>',                                                                                                                                   "\n";
print F1 "<th width=200 align=Left  bgcolor='#006600' > <FONT COLOR=WHITE FACE=Segoe UI Semibold SIZE=4>Diagnostics Response</FONT>  </th> </tr>", "\n";
print F1 "</table>";
print F1 '<h5 align=left >  <font face="Segoe UI Semibold" color = "#660066 ">' . 'Note :' . "</font></h5>";
print F1 '<h5 align=left >  <font face="Segoe UI Semibold"  color = "#330099">' . "Each Line contains 30 Bytes of response" . "</font></h5>", "\n";

# print F1 "<h1 align=left> <font face='Segoe UI Semibold' Semibold SIZE=2  color = '#006600' Semibold SIZE=2> Note :</font> </h1>";
#print F1 "<h1 align=left> <font face='Segoe UI Semibold' color = '#330099' Semibold SIZE=2> Each Line has 30 Bytes</font> </h1> ","\n";
print F1 '<textarea  id=' . '"Response" rows=' . "$Resp_col_TextArea" . ' cols=90 >', "\n";

# print F1 '<p >';
print F1 "@EDR_response ", "\n";

#print F1  '</p>',"\n"; # Response Data
print F1 "</textarea>",           "\n";
print F1 " <br>",                 "\n";
print F1 '</FieldSet> ',          "\n";
print F1 '<form Name = "Read"> ', "\n";
print F1 "<left>",                "\n";
print F1 '<FieldSet> ',           "\n";

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
print F1 '<FONT COLOR=WHITE FACE=Segoe UI bold SIZE=4>',                                                                                "\n";
print F1 '<Legend style="color: #B00000" > Byte Extraction From Response </Legend>',                                                    "\n";
print F1 '</FONT>',                                                                                                                     "\n";
print F1 '<br> ',                                                                                                                       "\n";
print F1 ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ',                                                                                            "\n";
print F1 ' Start Byte &nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp; &nbsp; &nbsp;: <input type="text" id="start_Id" name="Start_Byte"><br>  ', "\n";
print F1 ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ',                                                                                            "\n";
print F1 ' Number of  Bytes   : <input type="text"  id="number_of_bytes_Id" name="No_of_Bytes"><br>',                                   "\n";
print F1
' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
  "\n";
print F1
'<button type="button" style="font: bold 14px Segoe UI " style="color:#F8F8FF" style="background-color:#000080" onclick="Get_Response_Bytes(document.Read.Start_Byte.value,document.Read.No_of_Bytes.value)"> Enter</button>',
  "\n";
print F1 ' &nbsp;&nbsp;&nbsp;', "\n";
print F1
  '<button type="button" style="font: bold 14px Segoe UI " style="color: #F8F8FF" style="background-color:#000080" onclick="Clear_Area()">Clear</button>', "\n";
print F1 " <br>",                                                                                                        "\n";
print F1 ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ',                                                                             "\n";
print F1 " <br>",                                                                                                        "\n";
print F1 ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',                                                                  "\n";
print F1 '<span style="background-color: #FFFFFF" style="font: Normal 14px Segoe UI Semibold">Extracted Bytes :</span>', "\n";

#print F1  '<p id = "dummy" > &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>',"\n";
# print F1 '<p id="Btart" > Extracted Bytes form the response</p>',"\n";
#print F1 '<p id="demo"   >     &nbsp;       </p>',"\n";

print F1 '<Textarea id = "demo"   rows=2 cols=100> </Textarea>', "\n";
print F1 '<br>',                                                 "\n";

#print F1 '<p id="demo"   >     &nbsp;       </p>',"\n";
#print F1 '<table style="border:2px solid blue;">',"\n";
#print F1 '<tr>',"\n";
#print F1  ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ',"\n";
#print F1 '<td ID= "demo" width=200 align=Left > &nbsp; &nbsp;  </td> </tr>',"\n";
#print F1 "</table>","\n";

print F1 "<br>", "\n";
print F1
' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
  "\n";
print F1
'<button type="button" style="font: bold 14px Segoe UI " style="color: #F8F8FF" style="background-color:#500000 " onclick="writeToExcel()">Export To Excel</button>',
  "\n";
print F1 "<br>", "\n";
print F1 "<br>", "\n";

print F1 '</Fieldset> ', "\n";
print F1 "</left>",      "\n";
print F1 '</form> ',     "\n";
print F1 "<br>",         "\n";

# Html Border for the data entry of the response
######################################################################################################################################################
######################################################################################################################################################
print F1 '<body>', "\n";
my $Table_line = " EDR Decoder Table: \n";
print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#3B0B39  ">' . "$Table_line" . "</font></h2>";
print F1 '<br>', "\n";

#print F1 "<h2>","\n";

print F1
'<table border="1" id="HTML_Table" style="background-color:white;border:3px solid black;width:100%;border-collapse:collapse; > <font face="Segoe UI semibold" color = "#DC143C">',
  "\n";

#print F1 '<table style="border:3px solid black;" id="HTML_Table">',"\n";

print F1 '<tr style="background-color:#660000;color:white;">', "\n";

# print F1 '<table border><tr bgcolor="#FFC0CB">',"\n";
print F1 "<th  align=Center style='width:6%;'>Byte Bit</th>",      "\n";
print F1 "<th  align=Left style='width:4%;'>EDID in DEC</th>",     "\n";
print F1 "<th  align=Left style='width:4%;'>EDID in HEX</th>",     "\n";
print F1 "<th  align=Left style='width:4%;'>Number of Bytes</th>", "\n";

#print F1 "<th width=25 align=Left>Number of Bits</th>","\n";
print F1 "<th  align=Left style='width:4%;'>Number of Samples</th>",       "\n";
print F1 "<th  align=Left style='width:2%;'>Sample Rate</th>",             "\n";
print F1 "<th  align=Left style='width:4%;'>Header</th>",                  "\n";
print F1 "<th  align=Center style='width:20%;'>Byte Bit Description</th>", "\n";
print F1 "<th  align=Center style='width:5%;'>Conversion Type</th>",       "\n";
print F1 "<th  align=Center style='width:18%;'>Encoding Value</th>",       "\n";
print F1 "<th  align=Center style='width:18%;'>Hex Value</th>",            "\n";
print F1 "<th  align=Left style='width:20%;'>Encoding Name </th>",         "\n";
print F1 '</tr>',                                                          "\n";

######################################################################################################################################################
######################################################################################################################################################
# Open the xls using the WIN OLE package
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
$Win32::OLE::Warn = 3;

# die on errors...

# get already active Excel application or open new
$excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new( 'Excel.Application', 'Quit' );

unless ( defined @EDR_response ) {
    print "\n\nERROR:",                                                      "\n\n";
    print "***************************************************************", "\n";
    print " No Response is received to generate the HTML file",              "\n";
    print "***************************************************************", "\n";

    print F1 "</table>", "\n";
    my $temp_Line = " Error in Generating EDR Decoder Report :\n";
    print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#3D18E5">' . "$temp_Line" . "</font></h2>";

    $temp_Line = " No Response is received to generate the HTML file \n";

    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";

    print F1 "</body>", "\n";
    print F1 "</html>", "\n";

    print "************************************************************************************" . "\n";
    print "$HTML_File_Name_With_Path is created ", "\n";
    print "************************************************************************************" . "\n";

    # Close the HTML Files
    close F1;
    sleep(1);
    my $ret = system("$HTML_File_Name_With_Path");
    print " ret = $ret";

    #close $excel;
    print "exit";

    #exit 1;
}

unless ( -e "$File_Path\\$Input_Xls_File" ) {
    print "\n\nERROR:",                                                                "\n\n";
    print "***************************************************************",           "\n";
    print " DECODER Input File $Input_Xls_File is Not present in the path $File_Path", "\n";
    print "***************************************************************",           "\n";

    print F1 "</table>", "\n";
    my $temp_Line = " Error in Generating EDR Decoder Report :\n";
    print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#3D18E5">' . "$temp_Line" . "</font></h2>";

    $temp_Line = " DECODER Input File $Input_Xls_File  is Not present in the path $File_Path \n";

    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";

    print F1 "</body>", "\n";
    print F1 "</html>", "\n";

    print "************************************************************************************" . "\n";
    print "$HTML_File_Name_With_Path is created ", "\n";
    print "************************************************************************************" . "\n";

    # Close the HTML Files
    close F1;
    sleep(1);
    my $ret = system("$HTML_File_Name_With_Path");
    print " ret = $ret";

    #close $excel;
    print "exit";

    #exit 1;
}

# open Excel file which comtain  the decoder information
print "Xls File path =" . "$File_Path\\$Input_Xls_File", "\n";
$Book = $excel->Workbooks->Open("$File_Path\\$Input_Xls_File");

# select workSheet number 1 (you can also select a workSheet by name)
#$Sheet = $Book->WorkSheets(1);
# select workSheet number 1 (you can also select a workSheet by name)
# To Select the sheet name using Response Bytes
my $DID_HB = "$EDR_response[1]";
my $DID_LB = "$EDR_response[2]";

if ( length( $EDR_response[1] ) == 1 )    # To Make the reponse to 2 Nibbles (2 are converted to 02)
{
    $DID_HB = "0$EDR_response[1]";
}
if ( length( $EDR_response[2] ) == 1 )    # To Make the reponse to 2 Nibbles (2 are converted to 02)
{
    $DID_LB = "0$EDR_response[2]";
}
my $Sheet_Name = "$DID_HB$DID_LB";        #Join the two DID's #SID Value (02B1 |A002)
print "############### High Byte = $DID_HB#############################",                  "\n";
print "############### Low Byte = $DID_LB#############################",                   "\n";
print "############### HighFileSheet_NameByte = $Sheet_Name#############################", "\n";

my $wkSheetCount           = $Book->Worksheets->Count;
my $Worksheet_Present_Flag = 0;

foreach my $sheetnum ( 1 .. $wkSheetCount ) {
    my $Work_sheet_Name = $Book->Worksheets($sheetnum);
    my $name            = $Work_sheet_Name->Name;
    print "Working on sheet # $sheetnum - Its name is $name\n";
    if ( uc($Sheet_Name) eq uc($name) ) {
        print "sheet Name $Sheet_Name is present ", "\n";
        $Worksheet_Present_Flag = 1;
    }

}

if ( $Worksheet_Present_Flag == 0 ) {
    print "\n\nERROR:",                                                          "\n\n";
    print "***************************************************************",     "\n";
    print " Sheet Name $Sheet_Name is Not present in the $Input_Xls_File  File", "\n";
    print "***************************************************************",     "\n";

    print F1 "</table>", "\n";
    my $temp_Line = " Error in Generating EDR Decoder Report :\n";
    print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#3D18E5">' . "$temp_Line" . "</font></h2>";

    $temp_Line = " Sheet Name " . '"' . "$Sheet_Name" . '"' . " is Not present in the $Input_Xls_File  File \n";

    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";

    print F1 "</body>", "\n";
    print F1 "</html>", "\n";

    print "************************************************************************************" . "\n";
    print "$HTML_File_Name_With_Path is created ", "\n";
    print "************************************************************************************" . "\n";

    # Close the HTML Files
    close F1;

    # Close Workbook
    $Book->close();
    sleep(1);
    my $ret = system("$HTML_File_Name_With_Path");
    print " ret = $ret";

    #close $excel;
    print "exit";

    #exit 1;
}

$Sheet = $Book->WorkSheets($Sheet_Name);    # Select the Sheets based on SID Name (02B1 |A002)
$Sheet->Activate();
my $Byte_Bit;
my @start_Byte_Bit_values;
my $Start_Byte;
my @Start_Bit_Array;
my $Start_Bit;
my $Description;
my $Conversion_Type;
my $EDID_Value_DEC;
my @Size_Byte_Bit_values;
my $NumberofBytes;
my @Size_Byte_Bit_Array;
my $Size_Byte_Bit;
my $NumberofBits;
my $Header_length;
my $Encoding_Name;
my $Encoding_value;
my $Conversion_name;
my $Sampling_Rate;
my $Linear_Conversion_Unit;
my $Conversion_factor_string;
my $Raw_value;
my $row;
my $bit;
my $Rec_Decoded_value;
my $Rec_Header_Raw_value;
my $Rec_Header_Decoded_value;
my $Rec_bit_value;
my $Byte_Bit_check;
my $row_encoding;
my $read_data_Cell_A;
my $LastRow;
my $LastColoumn;

# Update the xls Coloum Here

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Finding the Last Row and Coloumn of the doors Document ^^^^^^^^^^^^^^^^^^^^^^^^
$LastRow = $Sheet->UsedRange->Find(
    {
        What            => "*",
        SearchDirection => xlPrevious,
        SearchOrder     => xlByRows
    }
)->{Row};
print "Last Row of EDR File =", $LastRow, "\n";

#$LastRow = $LastRow -1; # Remove the END_OF_EDID

$LastColoumn = $Sheet->UsedRange->Find(
    {
        What            => "*",
        SearchDirection => xlPrevious,
        SearchOrder     => xlByColumns
    }
)->{column};
print "Last Coloumn of EDR File =", $LastColoumn, "\n";

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Declaration for  the coloumn cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
my $xls_Bit_Byte_Coloumn;
my $xls_Description_Coloumn;
my $xls_Size_Coloumn;
my $xls_Header_Coloumn;
my $xls_Type_Coloumn;
my $xls_Name_Coloumn;
my $xls_ID_Coloumn;
my $xls_Encoding_Name_Coloumn;
my $xls_Encoding_Value_Coloumn;
my $xls_SampleRate_Coloumn;

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Assigning the coloumn attrributes for  the column cells of doors doccuments  ^^^^^^^^^^^^^^^^^^^^^^^^
my $Header_Filter_Row = 1;
my $firstrowcoloumn   = 1;
my $FirstRowColoumn_Read;
print " ########################################################################################### ;", "\n\n";
print " Coloumn Find Started  ;",                                                                       "\n\n";
foreach $firstrowcoloumn ( 1 .. $LastColoumn ) {
    $FirstRowColoumn_Read = "";                                                                 # clear the old data
                                                                                                # Read the bit byte cell value from xls File
    $FirstRowColoumn_Read = $Sheet->Cells( $Header_Filter_Row, $firstrowcoloumn )->{'Value'};
    print " FirstRowColoumn_Read = $FirstRowColoumn_Read;", "\n";
    if ( $FirstRowColoumn_Read =~ m/Byte-Bit/ ) {
        $xls_Bit_Byte_Coloumn = $firstrowcoloumn;
        print " xls_Bit_Byte_Coloumn = $xls_Bit_Byte_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/Description/ ) {
        $xls_Description_Coloumn = $firstrowcoloumn;
        print " xls_Description_Coloumn = $xls_Description_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/Size/ ) {
        $xls_Size_Coloumn = $firstrowcoloumn;
        print " xls_Size_Coloumn = $xls_Size_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/Header/ ) {
        $xls_Header_Coloumn = $firstrowcoloumn;
        print " xls_Header_Coloumn = $xls_Header_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/Type/ ) {
        $xls_Type_Coloumn = $firstrowcoloumn;
        print " xls_Type_Coloumn = $xls_Type_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/^Name/ ) {
        $xls_Name_Coloumn = $firstrowcoloumn;
        print " xls_Name_Coloumn = $xls_Name_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/ID/ ) {
        $xls_ID_Coloumn = $firstrowcoloumn;
        print " xls_ID_Coloumn = $xls_ID_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/^Encoding Name/ ) {
        $xls_Encoding_Name_Coloumn = $firstrowcoloumn;
        print " xls_Encoding_Name_Coloumn = $xls_Encoding_Name_Coloumn;", "\n";
    }
    if ( $FirstRowColoumn_Read =~ m/^Encoding Value/ ) {
        $xls_Encoding_Value_Coloumn = $firstrowcoloumn;
        print " xls_Encoding_Value_Coloumn = $xls_Encoding_Value_Coloumn;", "\n";
    }

    if ( $FirstRowColoumn_Read =~ m/^Sample Rate/ ) {
        $xls_SampleRate_Coloumn = $firstrowcoloumn;
        print " xls_SampleRate_Coloumn = $xls_SampleRate_Coloumn;", "\n";
    }
}

print " Coloumn Find completed ;",                                                                      "\n";
print " ########################################################################################### ;", "\n\n";

##################################  Coloumn find is completed ########################################

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^Finding  the Last EDID Row  ^^^^^^^^^^^^^^^^^^^^^^^^
my $row_dummy = $LastRow - 1;
$Byte_Bit_check = $Sheet->Cells( $row_dummy, 1 )->{'Value'};
print "****************Byte_Bit_check = $Byte_Bit_check  ***********", "\n";
while ( ( length($Byte_Bit_check) ) == 0 ) {
    $row_dummy--;
    $Byte_Bit_check = $Sheet->Cells( $row_dummy, 1 )->{'Value'};
}
print "**************************************************************", "\n";
print "****************Last Row for EDID is $row_dummy   ***********",  "\n";
print "****************Byte_Bit_check =$Byte_Bit_check   ***********",  "\n";
print "**************************************************************", "\n";

@start_Byte_Bit_values = split( /\[/, $Byte_Bit_check );
print "****************start_Byte_Bit_values[1] is $start_Byte_Bit_values[1]   ***********", "\n";
my @Start_Bit_array_temp = split( /\]/, $start_Byte_Bit_values[0] );
print "****************Start_Bit_array_temp[0] is $Start_Bit_array_temp[0]   ***********", "\n";
print "****************Start_Bit_array_temp[0] is $Start_Bit_array_temp[1]   ***********", "\n";
$Start_Byte = $Start_Bit_array_temp[0];
print "****************Start_Byte is $Start_Byte   ***********", "\n";
$Start_Bit = $Start_Bit_Array[0];
$Header_length = $Sheet->Cells( $row_dummy, $xls_Header_Coloumn )->{'Value'};
print "****************Header_length is $Header_length   ***********", "\n";
$Size_Byte_Bit = $Sheet->Cells( $row_dummy, $xls_Size_Coloumn )->{'Value'};
print "Size_Byte_Bits without Header = $Size_Byte_Bit", "\n";
my ( $Size_Byte_Bit_Values_Split, $Number_Of_Samples ) = split( /-/, $Size_Byte_Bit );

#print "Size_Byte_Bit_Values_Split= $Size_Byte_Bit_Values_Split","\n";
#print "Number_Of_Samples $Number_Of_Samples","\n";
@Size_Byte_Bit_values = split( /\[/, $Size_Byte_Bit_Values_Split );
$NumberofBytes = $Size_Byte_Bit_values[0];

#print "NumberofBytes without Header = $NumberofBytes","\n";

@Size_Byte_Bit_Array = split( /\]/, $Size_Byte_Bit_values[1] );
$NumberofBits = $Size_Byte_Bit_Array[0];
my $len_and_samples = $NumberofBytes * $Number_Of_Samples;
my $total_length_EDR_resp = $Start_Byte + ($len_and_samples) + $Header_length;

#Read the EDID value
my $Last_EDID_Value_DEC = $Sheet->Cells( $row_dummy, $xls_ID_Coloumn )->{'Value'};
my $Last_EDID_Value_HEC = sprintf( "0x%x", $Last_EDID_Value_DEC );
print "Last_EDID_Value_DEC= $Last_EDID_Value_DEC", "\n";
print "Last_EDID_Value_HEC= $Last_EDID_Value_HEC", "\n";

print "**************************************************************",         "\n";
print "****  Total EXPECTED response Length  is $total_length_EDR_resp ***",    "\n";
print "****  Total RECEIVED response Length  is $Received_Response_Length ***", "\n";
print "**************************************************************",         "\n";

my $start_row           = 1;
my $EDID_Length_Default = 2;
do {
    $read_data_Cell_A = $Sheet->Cells( $start_row, $xls_Bit_Byte_Coloumn )->{'Value'};

    #print " read_data_Cell_A  ::: $start_row=  $read_data_Cell_A ","\n";
    $start_row++;
} while ( $read_data_Cell_A ne "Service Response Format" );

#print "Start Row of Xls File =",$start_row,"\n";
foreach $row ( $start_row .. $LastRow )

  #foreach $row(14..17)
{
    # Read the bit byte cell value from xls File
    $Byte_Bit = $Sheet->Cells( $row, $xls_Bit_Byte_Coloumn )->{'Value'};
    next unless $Byte_Bit;
    {

        if ( $Byte_Bit eq "END_OF_EDID" ) {

            # Check the Response Length

            print "****  Total EXPECTED response Length  is $total_length_EDR_resp ***",    "\n";
            print "****  Total RECEIVED response Length  is $Received_Response_Length ***", "\n";
            if ( $total_length_EDR_resp == $Received_Response_Length ) {
                $Response_Length_Check_Status = "PASSED";
                print "**** Response_Length_Check_Status  is $Response_Length_Check_Status***", "\n";
            }

            else {
                $Response_Length_Check_Status = "FAILED";
                print "**** Response_Length_Check_Status  is $Response_Length_Check_Status***", "\n";
            }

        }
        else {

            # Read the bit byte cell value from xls File
            $Byte_Bit = $Sheet->Cells( $row, $xls_Bit_Byte_Coloumn )->{'Value'};
            @start_Byte_Bit_values = split( /\[/, $Byte_Bit );
            @Start_Bit_Array       = split( /\]/, $start_Byte_Bit_values[1] );
            $Start_Byte            = $start_Byte_Bit_values[0];

            #Not reported byte total length need to be added  to go to the next EDID
            $Start_Byte      = ( $Start_Byte - $Total_Number_Of_bytes_Notreported_Edid );
            $Byte_Bit        = "$Start_Byte  [0]";
            $EDID_Start_Byte = $Start_Byte - $EDID_Length_Default;
            print "EDID_Start_Byte = $EDID_Start_Byte ", "\n";
            $Start_Bit = $Start_Bit_Array[0];

            #print " Start_Byte  ::  $Start_Byte ","\n";
            #print " Start_Bit  :::=  $Start_Bit ","\n";

            #Read the Description value from xls sheet
            $Description = $Sheet->Cells( $row, $xls_Description_Coloumn )->{'Value'};
            print "Description= $Description", "\n";

            #Read the EDID value
            $EDID_Value_DEC = $Sheet->Cells( $row, $xls_ID_Coloumn )->{'Value'};
            $EDID_Expected_Value_HEX = sprintf( "0x%x", $EDID_Value_DEC );
            print "EDID_Value_DEC= $EDID_Value_DEC",                   "\n";
            print "EDID_Expected_Value_HEX= $EDID_Expected_Value_HEX", "\n";

            #Read the Header length
            $Conversion_Type = $Sheet->Cells( $row, $xls_Type_Coloumn )->{'Value'};
            $Conversion_name = "";

            #Read the Header length
            $Header_length = $Sheet->Cells( $row, $xls_Header_Coloumn )->{'Value'};
            print "Header_length= $Header_length", "\n";

            #Read the Conversion  Name
            $Conversion_name = $Sheet->Cells( $row, $xls_Name_Coloumn )->{'Value'};

            #Read the Sample Rate  Name
            $Sampling_Rate = $Sheet->Cells( $row, $xls_SampleRate_Coloumn )->{'Value'};

            # Read the Size of bit byte cell value from xls File
            $Size_Byte_Bit = $Sheet->Cells( $row, $xls_Size_Coloumn )->{'Value'};
            print "Size_Byte_Bits without Header = $Size_Byte_Bit", "\n";
            my ( $Size_Byte_Bit_Values_Split, $Number_Of_Samples ) = split( /-/, $Size_Byte_Bit );

            #print "Size_Byte_Bit_Values_Split= $Size_Byte_Bit_Values_Split","\n";
            #print "Number_Of_Samples $Number_Of_Samples","\n";
            @Size_Byte_Bit_values = split( /\[/, $Size_Byte_Bit_Values_Split );
            $NumberofBytes = $Size_Byte_Bit_values[0];

            #print "NumberofBytes without Header = $NumberofBytes","\n";

            @Size_Byte_Bit_Array = split( /\]/, $Size_Byte_Bit_values[1] );
            $NumberofBits = $Size_Byte_Bit_Array[0];
            print "NumberofBytes including Header = $NumberofBytes", "\n";
            print "NumberofBits = $NumberofBits",                    "\n";

            # Set the Grey and White colour in  the grid perl
            if ( ( $RowCnt1 % 2 ) == 0 ) {
                print F1 "<tr>",                                                             "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$Byte_Bit</td>",                "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$EDID_Value_DEC</td>",          "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$EDID_Expected_Value_HEX</td>", "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$NumberofBytes</td>",           "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$Number_Of_Samples</td>",       "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$Sampling_Rate</td>",           "\n";
                print F1 "<td align=center bgcolor='#AAAAAA'>$Header_length</td>",           "\n";
                print F1 "<td align=left bgcolor='#AAAAAA'>$Description</td>",               "\n";

                #print F1  "<td>$Conversion_Type</td>";

            }
            else {
                print F1 "<tr>";
                print F1 "<td align=center bgcolor='#FFFFFF'>$Byte_Bit</td>",                "\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$EDID_Value_DEC</td>",          "\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$EDID_Expected_Value_HEX</td>", "\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$NumberofBytes</td>",           "\n";

                #print F1  "<td align=center bgcolor='#FFFFFF'>$NumberofBits</td>","\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$Number_Of_Samples</td>", "\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$Sampling_Rate</td>",     "\n";
                print F1 "<td align=center bgcolor='#FFFFFF'>$Header_length</td>",     "\n";
                print F1 "<td align=Left bgcolor='#FFFFFF'>$Description</td>",         "\n";

                #print F1  "<td>$Conversion_Type</td>";
            }

            $EDID_Received_Value_HEX = F_Get_Table_Data( $EDID_Start_Byte, $EDID_Length_Default );
            print "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&", "\n";
            print " EDID start Byte   = $EDID_Start_Byte   ",                                          "\n";
            print " EDID Received Hex Value = $EDID_Received_Value_HEX ",                              "\n";
            print " EDID Expected Hex Value = $EDID_Expected_Value_HEX ",                              "\n";
            print "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&", "\n";
            if ( hex($EDID_Expected_Value_HEX) == hex($EDID_Received_Value_HEX) ) {

                print "Received EDID $EDID_Received_Value_HEX and  Expected EDID $EDID_Expected_Value_HEX are Equal ", "\n";

                # Do the operation
                #Set the Decoded value to Empty
                $Rec_Decoded_value        = '';
                $Rec_Header_Raw_value     = '';
                $Encoding_value           = '';
                $Raw_value                = '';
                $Encoding_Name            = '';
                $Linear_Conversion_Unit   = "";
                $Conversion_factor_string = "";

                if ( ( $RowCnt1 % 2 ) == 0 ) {
                    print F1 " <td align=Center bgcolor='#AAAAAA'>$Conversion_Type</td>", "\n";    # Light blue

                }
                else {
                    print F1 " <td align=Center bgcolor='#FFFFFF'>$Conversion_Type</td>", "\n";    # Light blue

                }

                if ( $Start_Byte > $Received_Response_Length ) {

                    print F1 "</table>", "\n";
                    print F1 "<h2>",     "\n";
                    my $temp_Line = " Error:  \n";
                    print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#DF0174 ">' . "$temp_Line" . "</font></h2>";

                    $temp_Line = " Start Byte index  $Start_Byte is greater than Received response Length $Received_Response_Length  \n";
                    print F1 '<h2 align=left  >  <font face="Segoe UI Semibold" color = "##2E2EFE ">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h2>",
                      "\n";

                    print F1 "</h3>", "\n";

                    print F1 "</body>", "\n";
                    print F1 "</html>", "\n";
                    print "************************************************************************************" . "\n";
                    print "$HTML_File_Name_With_Path is created ", "\n";
                    print "************************************************************************************" . "\n";
                    close F1;
                    sleep(1);
                    my $ret = system("$HTML_File_Name_With_Path");
                    print " ret = $ret";
                    print "exit";
                    exit 1;
                }
                else {

                    if ( ( $NumberofBytes == 0 ) && ( $NumberofBits != 0 ) && ( $Conversion_Type eq 'Table' ) ) {
                        $Encoding_Name     = "";
                        $Rec_Decoded_value = F_Get_Bits( $Start_Byte, $Start_Bit, $NumberofBits );
                        $Raw_value         = F_Get_Byte($Start_Byte);
                    }
                    elsif (( $NumberofBytes >= 1 )
                        && ( $NumberofBytes <= 8 )
                        && ( $NumberofBits == 0 )
                        && ( $Conversion_Type eq 'Table' )
                        && ( $Number_Of_Samples == 1 ) )
                    {
                        $Encoding_Name     = "";
                        $Rec_Decoded_value = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                        $Raw_value         = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                    }
                    elsif (( $NumberofBytes >= 1 )
                        && ( $NumberofBits == 0 )
                        && ( $Conversion_Type eq 'Table' )
                        && ( $Number_Of_Samples > 1 )
                        && ( $Header_length == 0 ) )
                    {
                        $Encoding_Name     = "";
                        $Rec_Decoded_value = F_Get_Table_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Number_Of_Samples );
                        $Raw_value         = F_Get_Table_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Number_Of_Samples );
                    }
                    elsif (( $NumberofBytes >= 1 )
                        && ( $NumberofBits == 0 )
                        && ( $Conversion_Type eq 'Linear' )
                        && ( $Number_Of_Samples > 1 )
                        && ( $Header_length == 0 ) )
                    {

                        if ( $Conversion_name =~ m/^ERROR:/i ) {
                            $Rec_Decoded_value      = $Conversion_name;
                            $Linear_Conversion_Unit = $Conversion_name;
                        }
                        else {
                            ( $Rec_Decoded_value, $Linear_Conversion_Unit, $Conversion_factor_string ) =
                              F_Get_Linear_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Conversion_name, $Number_Of_Samples );
                        }
                        $Raw_value = F_Get_Table_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Number_Of_Samples );
                    }
                    elsif (( $NumberofBytes >= 1 )
                        && ( $NumberofBits == 0 )
                        && ( $Conversion_Type eq 'Table' )
                        && ( $Number_Of_Samples > 1 )
                        && ( $Header_length > 0 ) )
                    {
                        $Encoding_Name = "";

                        $Rec_Header_Raw_value = F_Get_Header_Bytes_Raw_value( $Start_Byte, $Header_length );
                        $Rec_Header_Decoded_value = F_Get_Header_Bytes_Decoded_value( $Start_Byte, $Header_length );
                        my $sample_start_byte = ( $Start_Byte + $Header_length );
                        $Rec_Decoded_value = F_Get_Table_Data_With_Number_Of_Samples( ($sample_start_byte), $NumberofBytes, $Number_Of_Samples );
                        $Raw_value         = F_Get_Table_Data_With_Number_Of_Samples( ($sample_start_byte), $NumberofBytes, $Number_Of_Samples );
                    }
                    elsif (( $NumberofBytes >= 1 )
                        && ( $NumberofBits == 0 )
                        && ( $Conversion_Type eq 'Linear' )
                        && ( $Number_Of_Samples > 1 )
                        && ( $Header_length > 0 ) )
                    {
                        if ( $Conversion_name =~ m/^ERROR:/i ) {
                            $Rec_Decoded_value      = $Conversion_name;
                            $Linear_Conversion_Unit = $Conversion_name;
                        }
                        else {
                            my $sample_start_byte = ( $Start_Byte + $Header_length );
                            ( $Rec_Decoded_value, $Linear_Conversion_Unit, $Conversion_factor_string ) =
                              F_Get_Linear_Data_With_Number_Of_Samples( ($sample_start_byte), $NumberofBytes, $Conversion_name, $Number_Of_Samples );

                            #print "***********************************************************************\n\n";
                            #print "Linear_Conversion_Unit = $Linear_Conversion_Unit\n";
                        }
                        my $sample_start_byte = ( $Start_Byte + $Header_length );
                        $Rec_Header_Raw_value = F_Get_Header_Bytes_Raw_value( $Start_Byte, $Header_length );
                        $Raw_value = F_Get_Table_Data_With_Number_Of_Samples( ($sample_start_byte), $NumberofBytes, $Number_Of_Samples );

                        #print "Raw_value =  $Raw_value","\n";
                    }
                    elsif ( ( $NumberofBytes >= 1 ) && ( $NumberofBits == 0 ) && ( $Conversion_Type eq 'Identical' ) && ( $Number_Of_Samples > 1 ) ) {
                        ( $Rec_Decoded_value, $Linear_Conversion_Unit ) =
                          F_Get_Table_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Conversion_name, $Number_Of_Samples );
                        $Raw_value = F_Get_Table_Data_With_Number_Of_Samples( $Start_Byte, $NumberofBytes, $Number_Of_Samples );
                    }
                    elsif ( ( $NumberofBytes == 1 ) && ( $NumberofBits == 0 ) && ( $Conversion_Type eq 'Linear' ) && ( $Number_Of_Samples == 1 ) ) {
                        if ( $Conversion_name =~ m/^ERROR:/i ) {
                            $Rec_Decoded_value      = $Conversion_name;
                            $Linear_Conversion_Unit = $Conversion_name;
                        }
                        else {
                            ( $Rec_Decoded_value, $Linear_Conversion_Unit, $Conversion_factor_string ) =
                              F_Get_Linear_Data( $Start_Byte, $NumberofBytes, $Conversion_name );
                        }
                        $Raw_value = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                    }
                    elsif (( $NumberofBytes >= 8 )
                        && ( ( $Conversion_Type eq 'Table' ) | ( $Conversion_Type eq 'Linear' ) )
                        && ( $Number_Of_Samples == 1 )
                        && ( $Header_length == 0 ) )
                    {
                        $Encoding_Name = "";
                        print "MOre than 8 Byte ############################################", "\n";
                        if ( $Conversion_name =~ m/^ERROR:/i ) {
                            $Rec_Decoded_value      = $Conversion_name;
                            $Linear_Conversion_Unit = $Conversion_name;
                        }
                        else {
                            $Rec_Decoded_value = F_Get_Linear_Bytes_Decoded_value_More_than_8_Bytes( $Start_Byte, $NumberofBytes );
                        }
                        print "Rec_Decoded_value =  $Rec_Decoded_value ############################################", "\n";
                        $Raw_value = F_Get_Linear_Bytes_Raw_value_More_than_8_Bytes( $Start_Byte, $NumberofBytes );
                    }
                    elsif ( ( $NumberofBytes <= 8 ) && ( $NumberofBits == 0 ) && ( $Conversion_Type eq 'Linear' ) && ( $Number_Of_Samples == 1 ) ) {
                        if ( $Conversion_name =~ m/^ERROR:/i ) {
                            $Rec_Decoded_value      = $Conversion_name;
                            $Linear_Conversion_Unit = $Conversion_name;
                        }
                        else {
                            ( $Rec_Decoded_value, $Linear_Conversion_Unit, $Conversion_factor_string ) =
                              F_Get_Linear_Data( $Start_Byte, $NumberofBytes, $Conversion_name );
                        }
                        $Raw_value = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                    }

                    elsif ( ( $NumberofBytes >= 1 ) && ( $NumberofBytes < 6 ) && ( $Conversion_Type eq 'Identical' ) ) {
                        $Encoding_Name          = "";
                        $Linear_Conversion_Unit = "";
                        $Rec_Decoded_value      = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                        $Raw_value              = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                    }

                    elsif ( ( $NumberofBytes >= 1 ) && ( $NumberofBytes > 6 ) && ( $Conversion_Type eq 'Identical' ) ) {
                        $Encoding_Name     = "";
                        $Rec_Decoded_value = F_Get_Table_Data_NewLine( $Start_Byte, $NumberofBytes );
                        $Raw_value         = F_Get_Table_Data_NewLine( $Start_Byte, $NumberofBytes );
                    }
                    elsif ( ( $NumberofBytes == 1 ) && ( $NumberofBits == 0 ) && ( $Conversion_Type eq 'Identical' ) ) {
                        $Linear_Conversion_Unit = "";
                        $Encoding_Name          = "";
                        ( $Rec_Decoded_value, $Linear_Conversion_Unit, $Conversion_factor_string ) = F_Get_Linear_Data( $Start_Byte, $NumberofBytes );
                        $Raw_value = F_Get_Table_Data( $Start_Byte, $NumberofBytes );
                    }
                    else {
                        $Rec_Decoded_value = "ERROR in xls Format";
                        $Raw_value         = "ERROR";
                    }
                }
                ################################### Check if the Header is Not zero we need to print the value in the HTML
                print "Linear_Conversion_Unit after return  = $Linear_Conversion_Unit", "\n";
                if ( ( $Header_length != 0 ) ) {
                    if ( $Conversion_name =~ m/^ERROR:/i ) {
                        print F1 " <td align= center  bgcolor='#FF0000' >  <font face='Segoe UI semibold' color = '#FFFFFF'>" . "Header " . "<br>" . "
                    <font  face='Segoe UI bold' color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#000000'>" . "Samples" . "<br>" . "
                   <font   face='Segoe UI bold' color = '#000000' >" . "$Rec_Decoded_value" . "<br>" . "</td>", "\n";

                        print F1 " <td align= center  bgcolor='#FF0000' >  <font face='Segoe UI semibold' color = '#FFFFFF'>" . "Header " . "<br>" . "
                   <font  face='Segoe UI bold'  color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#000000'>" . "Samples" . "<br>" . "
                   <font  face='Segoe UI bold' color = '#000000'>" . "$Raw_value" . "<br>" . "</td>", "\n";
                    }

                    elsif ( ( $RowCnt1 % 2 ) == 0 ) {
                        print F1 " <td align= center  bgcolor='#AAAAAAA' >  <font face='Segoe UI semibold' color = '#DC143C'>" . "Header " . "<br>" . "
                   <font  face='Segoe UI bold' color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#DC143C'>" . "Samples" . "<br>" . "
                   <font   face='Segoe UI bold' color = '#000000' >" . "$Rec_Decoded_value" . "<br>" . "</td>", "\n";

                        print F1 " <td align= center  bgcolor='#AAAAAAA' >  <font face='Segoe UI semibold' color = '#DC143C'>" . "Header " . "<br>" . "
                   <font  face='Segoe UI bold'  color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#DC143C'>" . "Samples" . "<br>" . "
                   <font  face='Segoe UI bold' color = '#000000'>" . "$Raw_value" . "<br>" . "</td>", "\n";

                        print F1 " <td align= left  bgcolor='#AAAAAAA' >  
                                       <font  face='Segoe UI semibold' color = '#0000CD'> " . "$Conversion_factor_string" . "<br>" . "
                                       <font  face='Segoe UI semibold'SIZE =4  color = '#006633'>" . "" . "Unit = $Linear_Conversion_Unit" . "<br><br>" . "
                                      <font face='Segoe UI semibold' SIZE =2 color = '#DC143C'>" . "Conversion Formula " . "<br>" . "
                                      <font  face='Segoe UI semibold' SIZE =2 color = '#000000'>" . "Value =[(Recvalue in Dec + Offest) * Factor ]" . "<br>" . "
                                      </td>", "\n";

                    }
                    else {
                        print F1 " <td align= center  bgcolor='#FFFFFF' >  <font face='Segoe UI semibold' color = '#DC143C'>" . "Header " . "<br>" . "
                   <font  face='Segoe UI bold' color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#DC143C'>" . "Samples" . "<br>" . "
                   <font   face='Segoe UI bold' color = '#000000' >" . "$Rec_Decoded_value" . "<br>" . "</td>", "\n";

                        print F1 " <td align= center  bgcolor='#FFFFFF' >  <font face='Segoe UI semibold' color = '#DC143C'>" . "Header " . "<br>" . "
                   <font  face='Segoe UI bold'  color = '#000000'>" . "$Rec_Header_Raw_value" . "<br>" . "
                   <font  face='Segoe UI semibold' color = '#DC143C'>" . "Samples" . "<br>" . "
                   <font  face='Segoe UI bold' color = '#000000'>" . "$Raw_value" . "<br>" . "</td>", "\n";

                        print F1 " <td align= left  bgcolor='#FFFFFF' >  
                                       <font  face='Segoe UI semibold' color = '#0000CD'> " . "$Conversion_factor_string" . "<br>" . "
                                       <font  face='Segoe UI semibold'SIZE =4  color = '#006633'>" . "" . "Unit = $Linear_Conversion_Unit" . "<br><br>" . "
                                      <font face='Segoe UI semibold' SIZE =2 color = '#DC143C'>" . "Conversion Formula " . "<br>" . "
                                      <font  face='Segoe UI semibold' SIZE =2 color = '#000000'>" . "Value =[(Recvalue in Dec + Offest) * Factor ]" . "<br>" . "
                                      </td>", "\n";
                    }

                }    # if(($Header_length != 0))

                else {
                    if ( $Conversion_name =~ m/^ERROR:/i ) {
                        print F1 " <td align=Center  bgcolor='#FF0000'>$Rec_Decoded_value</td>", "\n";    # Red
                        print F1 " <td align=Center bgcolor='#AAAAAAA'>$Raw_value</td>",         "\n";
                    }

                    elsif ( ( $RowCnt1 % 2 ) == 0 ) {
                        print F1 " <td align=Center  bgcolor='#AAAAAAA'>$Rec_Decoded_value</td>", "\n";
                        print F1 " <td align=Center bgcolor='#AAAAAAA'>$Raw_value</td>",          "\n";
                    }
                    else {
                        print F1 " <td align=Center bgcolor='#FFFFFF'>$Rec_Decoded_value</td>", "\n";
                        print F1 " <td align=Center bgcolor='#FFFFFF'>$Raw_value</td>",         "\n";

                    }

                    print "Last_EDID_Value_DEC = $Last_EDID_Value_DEC", "\n";
                    if ( $Last_EDID_Value_DEC == hex($EDID_Received_Value_HEX) ) {
                        my $len_and_samples_this_edid = $NumberofBytes * $Number_Of_Samples;
                        my $exp_Length_of_this_edid   = ($len_and_samples_this_edid) + $Header_length;
                        my $rec_Length_of_this_edid   = ($Received_Response_Length) - $Start_Byte;
                        if ( $exp_Length_of_this_edid != $rec_Length_of_this_edid ) {
                            print F1
                              " <td align=Left bgcolor='#FF0000'>Expected Bytes $exp_Length_of_this_edid    <br>  Received Bytes $rec_Length_of_this_edid</td>",
                              "\n";    # Red
                        }
                    }    #     if($Last_EDID_Value_DEC == hex($EDID_Received_Value_HEX ))
                    else {

                        if ( $Conversion_Type eq 'Linear' ) {

                            if ( $Conversion_name =~ m/^ERROR:/i ) {

                                print F1 " <td align= left  bgcolor='#FFFFFF' >  <font face='Segoe UI semibold' color = '#DC143C'>"
                                  . "Conversion Formula " . "<br>" . "
                                                              <font  face='Segoe UI semibold' SIZE =2 color = '#000000'>"
                                  . "Value =[(Recvalue in Dec + Offest) * Factor ]" . "<br>" . "
                                                              <font  face='Segoe UI semibold' color = '#000000'>" . "$Conversion_factor_string" . "<br>" . "
                                                             <font  face='Segoe UI semibold' SIZE =4 color = '#DC143C'>" . "Unit" . "<br>" . "
                            <font   face='Segoe UI bold' color = '#FF0000' >" . "$Linear_Conversion_Unit" . "<br>" . "</td>", "\n";
                            }
                            else {

                                if ( ( $RowCnt1 % 2 ) == 0 ) {

                                    print F1 " <td align= left  bgcolor='#AAAAAAA' >  
                                                  <font  face='Segoe UI semibold' color = '#0000CD'> " . "$Conversion_factor_string" . "<br>" . "
                                                  <font  face='Segoe UI semibold'SIZE =4  color = '#006633'>" . ""
                                      . "Unit = $Linear_Conversion_Unit"
                                      . "<br><br>" . "
                                                 <font face='Segoe UI semibold' SIZE =2 color = '#DC143C'>" . "Conversion Formula " . "<br>" . "
                                                 <font  face='Segoe UI semibold' SIZE =2 color = '#000000'>"
                                      . "Value =[(Recvalue in Dec + Offest) * Factor ]" . "<br>" . "
                                      </td>", "\n";
                                }
                                else {
                                    print F1 " <td align= left  bgcolor='#FFFFFF' >  
                                                                                      <font  face='Segoe UI semibold' color = '#0000CD'> "
                                      . "$Conversion_factor_string" . "<br>" . "
                                                                                      <font  face='Segoe UI semibold'SIZE =4  color = '#006633'>" . ""
                                      . "Unit = $Linear_Conversion_Unit"
                                      . "<br><br>" . "
                                                                                     <font face='Segoe UI semibold' SIZE =2 color = '#DC143C'>"
                                      . "Conversion Formula " . "<br>" . "
                                                                                     <font  face='Segoe UI semibold' SIZE =2 color = '#000000'>"
                                      . "Value =[(Recvalue in Dec + Offest) * Factor ]" . "<br>" . "
                                      </td>", "\n";

                                }
                            }
                        }    # End of if($Conversion_Type eq 'Linear')

                        if ( $Conversion_Type eq 'Identical' ) {
                            if ( $Encoding_Name eq '' ) {
                                print F1 " <td align=Left bgcolor='#FFFFFF'>$Encoding_Name</td>", "\n";    # White
                            }
                            else {
                                print F1 " <td align=Left bgcolor='#9966FF'>$Encoding_Name</td>", "\n";    # Pink
                            }
                        }    # End of    if($Conversion_Type eq 'Identical')
                        if ( $Conversion_Type eq 'Table' ) {
                            if ( $Conversion_name =~ /Undefined/i ) {
                                print F1 " <td align=Left bgcolor='#87CEFF'>Undefined</td>", "\n";    # White
                            }
                            else {
                                my $row_dummy = $row + 1;
                                $Byte_Bit_check = $Sheet->Cells( $row_dummy, 1 )->{'Value'};
                                while ( ( ( length($Byte_Bit_check) ) == 0 ) && ( $Byte_Bit_check ne "END_OF_EDID" ) ) {
                                    $row_dummy++;
                                    $Byte_Bit_check = $Sheet->Cells( $row_dummy, 1 )->{'Value'};
                                }    # while ( ((length($Byte_Bit_check))==0) &&($Byte_Bit_check ne "END_OF_EDID"))

                                for ( $row_encoding = $row ; $row_encoding < $row_dummy ; $row_encoding++ ) {
                                    $Encoding_value = $Sheet->Cells( $row_encoding, $xls_Encoding_Value_Coloumn )->{'Value'};
                                    $Encoding_value =~ s/0x//g;    # remove the 0xvalue if it is already preset
                                    my $Encoding_value_Hex    = sprintf "0x%s", $Encoding_value;
                                    my $Encoding_value_Dec    = hex($Encoding_value_Hex);
                                    my $Rec_Decoded_value_Dec = hex($Rec_Decoded_value);
                                    $Encoding_Name = '';
                                    if ( $Rec_Decoded_value_Dec == $Encoding_value_Dec ) {
                                        $Encoding_Name = $Sheet->Cells( $row_encoding, $xls_Encoding_Name_Coloumn )->{'Value'};
                                        print F1 " <td bgcolor='#DEBDFF'> $Encoding_Name </td>", "\n";
                                    }                              # Enf IF
                                }    # End For Loop
                            }    # End other than undefined ie     else
                        }    # End IF for table
                    }    # End of     if($exp_Length_of_this_edid != $rec_Length_of_this_edid )
                }
            }
            else {
                my $Error_Flag_Bit = 0;
                if ( $Error_Flag_Bit != 1 ) {
                    $Error_Flag_Bit = 1;
                }

                &CLose_HTML_Report_EDID_Error_Generate_Report();

            }    # End the Main EDID loop

            #Increment the cells in the xls File and do the same Operation
            $RowCnt1++;
            print F1 "</tr>", "\n";
        }
    }

    # Close the HTML if all the EDID are complete

}
&F_ClosingTable_LengthCheck_Generate_HTMLReport();

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Bits {
    my ( $start_byte_local, $start_bit_local, $number_of_bits_local ) = @_;
    my ( $Resp_Hex, $Resp_Binary, $Resp_Binary_Rev, $Bit_values, $Bit_values_Reverse, $Bit_value_b8, $Decimal_value_Return_b, $Hex_value_Return_b );

    #print "EDR_response[start_byte_local]=",$EDR_response[$start_byte_local], "\n";
    $Resp_Hex = sprintf "0x%s", $EDR_response[$start_byte_local];

    #print "Resp_Hex=",$Resp_Hex, "\n";
    $Resp_Binary = sprintf "%08b", hex($Resp_Hex);
    $Resp_Binary_Rev = reverse($Resp_Binary);

    # print "Binary=",$Resp_Binary, "\n";
    # print "Binaryreverse=",($Resp_Binary_Rev), "\n";
    $Bit_values = substr( $Resp_Binary_Rev, $start_bit_local, $number_of_bits_local );

    #print "Bit_values=",($Bit_values), "\n";
    $Bit_values_Reverse = reverse($Bit_values);

    #print "Bitvalue_Reverse=",($Bit_values), "\n";
    $Bit_value_b8 = "" . ( 0 x ( 8 - $number_of_bits_local ) . $Bit_values_Reverse );

    #print "Bit_value_b8=",($Bit_value_b8), "\n";
    $Decimal_value_Return_b = bin2dec($Bit_value_b8);

    # print "decimal_value_b=",($Decimal_value_Return_b), "\n";
    $Hex_value_Return_b = unpack( "H*", pack( "B*", $Bit_value_b8 ) );

    #print "Hex_value_b=",($Hex_value_Return_b), "\n";
    return ($Decimal_value_Return_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Byte {
    my $hex_value_Return_b;
    my ($start_byte_local) = @_;

    #print "start_byte_local]",$start_byte_local, "\n";
    #print "EDR_response[start_byte_local]=",$EDR_response[$start_byte_local], "\n";
    $hex_value_Return_b = sprintf( "0x%s", ( $EDR_response[$start_byte_local] ) );
    print "hex_value_Return_b +++++++++++++++=", ($hex_value_Return_b), "\n";
    return ($hex_value_Return_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Table_Data {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $header_hex_value_combine_b );
    my ( $start_byte_local, $number_of_bytes ) = @_;
    $hex_bytes_dw = $EDR_response[$start_byte_local];
    for ( $v_byte_i = 0 ; $v_byte_i < $number_of_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $EDR_response[ $start_byte_local + $v_byte_i ];

        if ( ($v_byte_i) == 0 ) {
            $header_hex_value_combine_b = "$hex_bytes_dw";
        }
        else {
            $header_hex_value_combine_b = "$header_hex_value_combine_b" . "$hex_bytes_dw";
        }

        #$start_byte_local= $start_byte_local++;

    }

    #print "hex_bytes_dw in samples =",$header_hex_value_combine_b, "\n";
    #return ($header_hex_value_combine_b);

    # print "hex_bytes_dw=",$hex_bytes_dw, "\n";
    $hex_value_Return_b = sprintf( "0x%s", ($header_hex_value_combine_b) );

    #print "hex_bytes_dw in Hex=",$hex_value_Return_b, "\n";
    return ($hex_value_Return_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Table_Data_With_Number_Of_Samples {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $sample_number_i );
    my ( $start_byte_local, $number_of_bytes, $number_of_samples_in_decoder ) = @_;

    #print "start_byte_local in samples =",$start_byte_local, "\n";
    #print "number_of_bytes in samples =",$number_of_bytes, "\n";
    #print "number_of_samples_in_decoder in samples =",$number_of_samples_in_decoder, "\n";
    my $hex_value_combine_b;
    my $nextline_count = 6;

    for ( $sample_number_i = 1 ; $sample_number_i <= $number_of_samples_in_decoder ; $sample_number_i++ ) {

        $hex_bytes_dw = $EDR_response[$start_byte_local];

        #print "hex_bytes_dw in samples =",$hex_bytes_dw, "\n";
        for ( $v_byte_i = 1 ; $v_byte_i < $number_of_bytes ; $v_byte_i++ ) {
            $hex_bytes_dw = $hex_bytes_dw . $EDR_response[ $start_byte_local + $v_byte_i ];
        }
        $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

        #print "hex_value_Return_b in samples =",$hex_value_Return_b, "\n";

        if ( ($sample_number_i) == 1 ) {
            $hex_value_combine_b = "$hex_value_Return_b";
        }
        elsif ( $sample_number_i == $nextline_count ) {
            $hex_value_combine_b = "$hex_value_combine_b" . "<br>" . "$hex_value_Return_b";
            $nextline_count      = $nextline_count + 5;
        }
        else {
            $hex_value_combine_b = "$hex_value_combine_b" . " , " . "$hex_value_Return_b";
        }

        #print" hex_value_Return_b in loop  =",$hex_value_combine_b, "\n";
        $start_byte_local = $start_byte_local + $number_of_bytes;

        #print "start_byte_local again =",$start_byte_local, "\n";
    }

    #print "hex_bytes_dw in samples =",$hex_value_combine_b, "\n";
    return ($hex_value_combine_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Linear_Bytes_Raw_value_More_than_8_Bytes {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $sample_number_i );
    my ( $start_byte_local, $number_of_bytes ) = @_;

    #print "start_byte_local in samples =",$start_byte_local, "\n";
    #print "number_of_bytes in samples =",$number_of_bytes, "\n";
    #print "number_of_samples_in_decoder in samples =",$number_of_samples_in_decoder, "\n";
    my $header_hex_value_combine_b;
    my $nextline_count = 6;

    for ( $v_byte_i = 1 ; $v_byte_i <= $number_of_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $EDR_response[$start_byte_local];

        $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

        #print "hex_value_Return_b in samples =",$hex_value_Return_b, "\n";

        if ( $v_byte_i == 1 ) {
            $header_hex_value_combine_b = "$hex_value_Return_b";
        }
        elsif ( $v_byte_i == $nextline_count ) {
            $header_hex_value_combine_b = "$header_hex_value_combine_b" . "<br>" . "$hex_value_Return_b";
            $nextline_count             = ( $nextline_count + 5 );
        }
        else {
            $header_hex_value_combine_b = "$header_hex_value_combine_b" . " , " . "$hex_value_Return_b";
        }
        $start_byte_local = $start_byte_local + 1;
    }

    #print "hex_bytes_dw in samples =",$header_hex_value_combine_b, "\n";
    return ($header_hex_value_combine_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Linear_Bytes_Decoded_value_More_than_8_Bytes {
    my ( $hex_value_Return_b, $dec_value_Return_b, $hex_bytes_dw, $v_byte_i, $sample_number_i );
    my ( $start_byte_local, $number_of_bytes ) = @_;

    print "start_byte_local  =", $start_byte_local, "\n";
    print "number_of_bytes =",   $number_of_bytes,  "\n";
    my $Linear_Dec_value_combine_b;
    my $nextline_count = 6;

    for ( $v_byte_i = 1 ; $v_byte_i <= $number_of_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $EDR_response[$start_byte_local];

        $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );
        $dec_value_Return_b = hex($hex_value_Return_b);

        #print "hex_value_Return_b in samples =",$hex_value_Return_b, "\n";

        if ( $v_byte_i == 1 ) {
            $Linear_Dec_value_combine_b = "$dec_value_Return_b";
        }
        elsif ( $v_byte_i == $nextline_count ) {
            $Linear_Dec_value_combine_b = "$Linear_Dec_value_combine_b" . "<br>" . "$dec_value_Return_b";
            $nextline_count             = ( $nextline_count + 5 );
        }
        else {
            $Linear_Dec_value_combine_b = "$Linear_Dec_value_combine_b" . " , " . "$dec_value_Return_b";
        }
        $start_byte_local = $start_byte_local + 1;
    }

    #print "Linear data in samples =",$Linear_Dec_value_combine_b, "\n";
    return ($Linear_Dec_value_combine_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Header_Bytes_Raw_value {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $sample_number_i );
    my ( $start_byte_local, $number_of_header_bytes, ) = @_;

    # print "start_byte_local in samples =",$start_byte_local, "\n";

    #print "number_of_samples_in_decoder in samples =",$number_of_header_bytes, "\n";
    my $header_hex_value_combine_b;
    my $nextline_count = 6;

    for ( $v_byte_i = 0 ; $v_byte_i < $number_of_header_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $EDR_response[ ( $start_byte_local + $v_byte_i ) ];
        print "hex_bytes_dw in byte ($start_byte_local+$v_byte_i) =", $hex_bytes_dw, "\n";

        $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

        #print "hex_value_Return_b in samples =",$hex_value_Return_b, "\n";

        if ( ($v_byte_i) == 0 ) {
            $header_hex_value_combine_b = "$hex_value_Return_b";
        }
        elsif ( $v_byte_i == $nextline_count ) {
            $header_hex_value_combine_b = "$header_hex_value_combine_b" . "<br>" . "$hex_value_Return_b";
            $nextline_count             = $nextline_count + 5;
        }
        else {
            $header_hex_value_combine_b = "$header_hex_value_combine_b" . " , " . "$hex_value_Return_b";
        }
        $start_byte_local = $start_byte_local++;
    }

    print "hex_bytes_dw in samples =", $header_hex_value_combine_b, "\n";
    return ($header_hex_value_combine_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Table_Data_NewLine {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i );
    my ( $start_byte_local, $number_of_bytes ) = @_;
    $hex_bytes_dw = $EDR_response[$start_byte_local];
    for ( $v_byte_i = 1 ; $v_byte_i < $number_of_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $hex_bytes_dw . "\n" . $EDR_response[ $start_byte_local + $v_byte_i ];
    }
    $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

    #print "hex_bytes_dw=",$hex_bytes_dw, "\n";
    return ($hex_value_Return_b);

}

#**********************************************************************************************************************
#**********************************************************************************************************************

sub F_Get_Linear_Data_With_Number_Of_Samples {

    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $decimal_value_return_b, $Linear_value_After_conv_return_b, $sample_number_i );
    my ( @linear_Mx_arr, $linear_Mx, @linear_C_arr, $linear_C );
    my ( @conv_Array, $Conv_Unit );
    my ( $start_byte_local, $number_of_bytes, $conver_name_local, $number_of_samples_in_decoder, @conv_para_split, @conv_para_values ) = @_;

    #print "start_byte_local=",$start_byte_local, "\n";
    #print "number_of_bytes=",$number_of_bytes, "\n";
    #print "conver_name_local=",$conver_name_local, "\n";
    #print "number_of_samples_in_decoder=",$number_of_samples_in_decoder, "\n";
    @conv_para_split = split( /\(/, $conver_name_local );

    #print "linear_Mx=",$linear_Mx, "\n";
    #print "conv_para_split[0]=",$conv_para_split[0], "\n";
    (@conv_Array) = split( / /, $conv_para_split[0] );

    #print "conv_Array[-1]", $conv_Array[-1], "\n";
    $Conv_Unit = $conv_Array[-1];

    #print "Conv_Unit[-1]", $Conv_Unit, "\n";
    $conv_Array[1] =~ s/[\W\d_]//g;
    (@linear_Mx_arr) = split( /\,/, $conv_para_split[1] );
    ($linear_Mx) = $linear_Mx_arr[0];

    #print "linear_Mx=",$linear_Mx, "\n";
    @linear_C_arr = split( /\)/, $linear_Mx_arr[1] );
    ($linear_C) = $linear_C_arr[0];

    # print "linear_C=",$linear_C, "\n";
    $hex_bytes_dw = $EDR_response[$start_byte_local];

    #print "linear_C=",$linear_C, "\n";
    my $linear_value_combine_b;
    my $nextline_count = 6;

    for ( $sample_number_i = 1 ; $sample_number_i <= $number_of_samples_in_decoder ; $sample_number_i++ ) {

        $hex_bytes_dw = $EDR_response[$start_byte_local];

        #print "hex_bytes_dw in samples =",$hex_bytes_dw, "\n";
        for ( $v_byte_i = 1 ; $v_byte_i < $number_of_bytes ; $v_byte_i++ ) {
            $hex_bytes_dw = $hex_bytes_dw . $EDR_response[ $start_byte_local + $v_byte_i ];
        }
        $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

        #print "hex_value_Return_b in samples =",$hex_value_Return_b, "\n";

        $decimal_value_return_b = hex($hex_value_Return_b);

        #print "Decimal_value_Return_b=",$decimal_value_return_b, "\n";
        # Y(x)=Mx+c is used earlier
        #$Linear_value_After_conv_return_b=(($linear_Mx*$decimal_value_return_b)+$linear_C);
        # As per the resolution provided by the author(Prasad)on 11-03-2013 the Formula got changed to Y(x)=(x+c)*M;
        print "linear_C before  Division =", $linear_C, "\n";

        # Added as per the information provided by Deepak patel for Orlando Dailmler   we have followed the below formula
        #Below are the mail references

=head
From: Muthu Ramalingam (RBEI/ESA1) 
Sent: Mittwoch, 24. April 2013 10:22
To: Madhusudhan N (RBEI/ESA1); Deepak Patil (RBEI/ESA2)
Cc: Devendra Kumar (RBEI/ESA1)
Subject: RE: [Orlando CP NHTSA EDR] Algo EDID evaluation
Hello Both ,
    
Step1: convert the factor in g to LSB 
Offset = (offset/factor) - LSB

Step 2 : Add the data with the received value in decimal 

Step 3 : multiply with factor
Factor= 0.01  in g
Offset =-327.67 

Conversion Formula 
Value =[(Recvalue in Dec +{ (Offest/factor) }* Factor ]

Example
Received : 0x7F
Factor= 0.1 
Offset =-12.7 
Unit = g

Step1: convert the factor in g to LSB 
Offset = (offset/factor)  LSB
1)  Offset = -12.7/0.1  = -127 LSB

Step 2 : Add the data with the received value in decimal 
2)  127 +(-127)

Step 3 : multiply with factor
1)  0*0.1 = 0  = 0 g

=cut

        my $linear_C_inLSB = ( $linear_C / $linear_Mx );    # Added for g to LSB conversion
        print "linear_C after Division =",                 $linear_C,               "\n";
        print "linear_C_inLSB after Division =",           $linear_C_inLSB,         "\n";
        print "decimal_value_return_b before  Division =", $decimal_value_return_b, "\n";
        $Linear_value_After_conv_return_b = ( $decimal_value_return_b + $linear_C_inLSB ) * ($linear_Mx);
        $Linear_value_After_conv_return_b = sprintf '%.4f', $Linear_value_After_conv_return_b;
        my ( $integer_value, $floating_value ) = split( /\./, $Linear_value_After_conv_return_b );
        print "Linear_value_After_conv_return_b=", $Linear_value_After_conv_return_b, "\n";
        print "integer_value=",                    $integer_value,                    "\n";
        print "floating_value=",                   $floating_value,                   "\n";
        if ( $floating_value == 0000 ) {
            $Linear_value_After_conv_return_b = int($Linear_value_After_conv_return_b);
        }
        if ( ($sample_number_i) == 1 ) {
            $linear_value_combine_b = "$Linear_value_After_conv_return_b";
        }
        elsif ( $sample_number_i == $nextline_count ) {
            $linear_value_combine_b = "$linear_value_combine_b" . "<br>" . "$Linear_value_After_conv_return_b";
            $nextline_count         = $nextline_count + 5;
        }
        else {
            $linear_value_combine_b = "$linear_value_combine_b" . " , " . "$Linear_value_After_conv_return_b";
        }

        # print" hex_value_Return_b in loop  =",$linear_value_combine_b, "\n";
        #print" linearvalue_Return_b in loop  =",$linear_value_combine_b, "\n";
        $start_byte_local = $start_byte_local + $number_of_bytes;

        #print "start_byte_local again =",$start_byte_local, "\n";
    }

    my $conv_factor_string = "Factor= $linear_Mx_arr[0] <br> Offset =$linear_C_arr[0] ";
    return ( $linear_value_combine_b, $Conv_Unit, $conv_factor_string );

}

#**********************************************************************************************************************
#**********************************************************************************************************************
sub F_Get_Linear_Data {
    my ( $hex_value_Return_b, $hex_bytes_dw, $v_byte_i, $decimal_value_return_b, $Linear_value_After_conv_return_b );
    my ( @linear_Mx_arr, $linear_Mx, @linear_C_arr, $linear_C );
    my ( @conv_Array, $Conv_Unit );
    my ( $start_byte_local, $number_of_bytes, $conver_name_local, @conv_para_split, @conv_para_values ) = @_;

    #print "start_byte_local=",$start_byte_local, "\n";
    #print "number_of_bytes=",$number_of_bytes, "\n";
    #print "conver_name_local=",$conver_name_local, "\n";
    @conv_para_split = split( /\(/, $conver_name_local );

    #print "linear_Mx=",$linear_Mx, "\n";
    #print "conv_para_split[0]=",$conv_para_split[0], "\n";
    (@conv_Array) = split( / /, $conv_para_split[0] );

    #print "conv_Array[-1]", $conv_Array[-1], "\n";
    $Conv_Unit = $conv_Array[-1];

    #print "Conv_Unit[-1]", $Conv_Unit, "\n";
    $conv_Array[1] =~ s/[\W\d_]//g;
    (@linear_Mx_arr) = split( /\,/, $conv_para_split[1] );
    ($linear_Mx) = $linear_Mx_arr[0];

    #print "linear_Mx=",$linear_Mx, "\n";
    @linear_C_arr = split( /\)/, $linear_Mx_arr[1] );
    ($linear_C) = $linear_C_arr[0];

    # print "linear_C=",$linear_C, "\n";
    $hex_bytes_dw = $EDR_response[$start_byte_local];

    #print "linear_C=",$linear_C, "\n";
    for ( $v_byte_i = 1 ; $v_byte_i < $number_of_bytes ; $v_byte_i++ ) {
        $hex_bytes_dw = $hex_bytes_dw . $EDR_response[ $start_byte_local + $v_byte_i ];

        # print "hex_bytes_dw for byte ($start_byte_local+$v_byte_i)=","$hex_bytes_dw", "\n";
    }
    $hex_value_Return_b = sprintf( "0x%s", ($hex_bytes_dw) );

    #print "hex_value_Return_b=",$hex_value_Return_b, "\n";
    $decimal_value_return_b = hex($hex_value_Return_b);

    #print "Decimal_value_Return_b=",$decimal_value_return_b, "\n";
    # Y(x)=Mx+c;
    #$Linear_value_After_conv_return_b=(($linear_Mx*$decimal_value_return_b)+$linear_C);
    # As per the resolution provided by the author(Prasad)on 11-03-2013 the Formula got changed to Y(x)=(x+c)*M;
    $linear_C = ( $linear_C / $linear_Mx );    # Added for g to LSB conversion
    print "linear_C before  Division =", $linear_C, "\n";
    $Linear_value_After_conv_return_b = ( $decimal_value_return_b + $linear_C ) * ($linear_Mx);
    print "linear_C after Division =", $linear_C, "\n";
    $Linear_value_After_conv_return_b = sprintf '%.4f', $Linear_value_After_conv_return_b;
    my ( $integer_value, $floating_value ) = split( /\./, $Linear_value_After_conv_return_b );
    print "Linear_value_After_conv_return_b=", $Linear_value_After_conv_return_b, "\n";
    print "integer_value=",                    $integer_value,                    "\n";
    print "floating_value=",                   $floating_value,                   "\n";

    if ( $floating_value == 0000 ) {
        $Linear_value_After_conv_return_b = int($Linear_value_After_conv_return_b);
    }
    print "Linear_value_After_conv_return_b=", $Linear_value_After_conv_return_b, "\n";
    my $conv_factor_string = " Factor = $linear_Mx_arr[0] <br> Offset=  $linear_C_arr[0] ";
    return ( $Linear_value_After_conv_return_b, $Conv_Unit, $conv_factor_string );

}

#---------------------------------------------------------------------------------------------------------------------
#                    This function convert the Decimal to Binary value
#---------------------------------------------------------------------------------------------------------------------

sub dec2bin {
    my $str = unpack( "B32", pack( "N", shift ) );
    $str =~ s/^0+(?=\d)//;    # otherwise you'll get leading zeros
    return $str;
}

#---------------------------------------------------------------------------------------------------------------------
#                    This function convert the string to hEX
#---------------------------------------------------------------------------------------------------------------------

sub String2Hex {
    my ($string_value) = @_;
    $string_value = s/0x//g;
    my $hex_value_Return_b = sprintf "0x%s", $string_value;
    return $hex_value_Return_b;
}

#---------------------------------------------------------------------------------------------------------------------
#                    This function convert the Hex to Binary value
#---------------------------------------------------------------------------------------------------------------------

sub HexToBinary {
    my (%h) = (
        '0' => '0000',
        '1' => '0001',
        '2' => '0010',
        '3' => '0011',
        '4' => '0100',
        '5' => '0101',
        '6' => '0110',
        '7' => '0111',
        '8' => '1000',
        '9' => '1001',
        'A' => '1010',
        'B' => '1011',
        'C' => '1100',
        'D' => '1101',
        'E' => '1110',
        'F' => '1111'
    );
    $_ = uc $_[0];
    s/([0-9A-F])/$h{$1}/g;
    return $_;
}

#---------------------------------------------------------------------------------------------------------------------
#                    This function convert the Binary to Decimal value
#---------------------------------------------------------------------------------------------------------------------

sub bin2dec {
    return unpack( "N", pack( "B32", substr( "0" x 32 . shift, -32 ) ) );
}

sub CLose_HTML_Report_EDID_Error_Generate_Report {
    print F1 "</table>", "\n";
    my $temp_Line = " Error: \n";
    print F1 '<h2 align=left >  <font face="Segoe UI Semibold" color = "#20B2AA">' . "$temp_Line" . "</font></h2>";
    my $temp         = $EDID_Received_Value_HEX;
    my $rec_dec      = hex($temp);
    my $edid_llb_pos = $EDID_Start_Byte + 1;
    $temp_Line = " In EDID  Byte  Position $EDID_Start_Byte ,$edid_llb_pos\n";
    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "##2E2EFE ">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";
    $temp_Line = " Expected EDID is $EDID_Expected_Value_HEX (DEC: $EDID_Value_DEC)  \n";
    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#0B3B17 ">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";
    $temp_Line = "  Received EDID is $temp (DEC: ($rec_dec) \n";
    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000 ">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";
    print F1 "</body>", "\n";
    print F1 "</html>", "\n";
    print "************************************************************************************" . "\n";
    print "$HTML_File_Name_With_Path is created ", "\n";
    print "************************************************************************************" . "\n";
    close F1;
    sleep(1);

    # Close the HTML Files
    close F1;

    # Close Workbook
    $Book->close();
    my $ret = system("$HTML_File_Name_With_Path");
    print " ret = $ret";
    print "exit";
    exit 1;
}

sub F_EDR_Response_Length_Check {
    my $temp_Line = " Response Length Check :: \n";
    print F1 '<h3 align=left  >  <font face="Segoe UI Semibold" color = "##008B8B">' . "&nbsp&nbsp&nbsp&nbsp" . "$temp_Line" . "</font></h3>", "\n";
    print F1
'<table border="1" id="HTML_Table" style="background-color:white;border:3px solid black;width:40%;border-collapse:collapse; > <font face="Segoe UI semibold" color = "#000000">',
      "\n";

    #print F1 '<table style="border:3px solid black;" id="HTML_Table">',"\n";

    print F1 '<tr style="background-color:#505050 ;color:white;">', "\n";

    # print F1 '<table border><tr bgcolor="#FFC0CB">',"\n";
    print F1 "<th  align=Center style='width:15%;'> Expected Response Length</th>", "\n";
    print F1 "<th  align=Left style='width:15%;'> Received Response Length</th>",   "\n";
    print F1 "<th  align=Left style='width:10%;'> status</th>",                     "\n";
    print F1 '</tr>',                                                               "\n";

    print F1 '<tr style="background-color:#FFFFFF;color:white;">',                                                                  "\n";
    print F1 "<td align=Center  bgcolor='#FFFFFF'><font face='Segoe UI Semibold' color = '#000066'>$total_length_EDR_resp</td>",    "\n";
    print F1 "<td align=Center  bgcolor='#FFFFFF'><font face='Segoe UI Semibold' color = '#000066'>$Received_Response_Length</td>", "\n";
    if ( $Response_Length_Check_Status eq "PASSED" ) {

        print F1 "<td align=Center  bgcolor='#00FF00'> $Response_Length_Check_Status</td>", "\n";
    }
    else {

        print F1 "<td align=Center  bgcolor='#FF0000'> $Response_Length_Check_Status</td>", "\n";
    }
    print F1 '</tr>',    "\n";
    print F1 "</table>", "\n";

}

sub F_Missing_EDID_Reporting {
    if (@EDID_Error_Array) {

        #print F1 "<h3>------------------------------------------------------------------------------------------------------------------</h3>","\n";
        print F1 '<div>', "\n";
        print F1 '<h2 align=left > <span style="background-color: #FF0000"> <font face="Segoe UI Semibold" color = "#FFFFFF">'
          . " Missing EDID in EDR Response"
          . "</font> </span></h2>";
        print F1 '</div>', "\n";
    }

    #print F1 "<h3>------------------------------------------------------------------------------------------------------------------</h3>","\n";
    my $edid_count = 0;
    foreach my $error_edid (@EDID_Error_Array) {

        #print F1 "$error_edid";
        my @error_split = split( /;;/, $error_edid );

        foreach my $error_split_line (@error_split) {
            if ( $error_split_line =~ m/In EDID/i ) {

            #print F1 '<h2 align=left  >  <font face="Segoe UI Semibold" color = "##2E2EFE ">'."&nbsp&nbsp&nbsp&nbsp" . "$error_split_line"."</font></h2>","\n";
            }
            if ( $error_split_line =~ m/Expected /i ) {
                $edid_count++;
                $error_split_line =~ s/Expected/$edid_count ) /i;
                print F1 '<h5 align=left  >  <font face="Segoe UI Semibold" color = "#660099">' . "&nbsp&nbsp&nbsp&nbsp" . "$error_split_line" . "</font></h5>",
                  "\n";
            }
            if ( $error_split_line =~ m/Received /i ) {

              #print F1 '<h5 align=left  >  <font face="Segoe UI Semibold" color = "#FF0000">'."&nbsp&nbsp&nbsp&nbsp" . "$error_split_line"."</font></h5>","\n";
            }

            #print F1 "<br>";
        }
    }
}

sub F_ClosingTable_LengthCheck_Generate_HTMLReport {

    # For HTML Closing Header
    print F1 "</table>", "\n";
    &F_EDR_Response_Length_Check();
    print F1 "</body>", "\n";
    print F1 "</html>", "\n";
    print "************************************************************************************" . "\n";
    print "$HTML_File_Name_With_Path is created ", "\n";
    print "************************************************************************************" . "\n";

    # Close the HTML Files
    close F1;

    # Close Workbook
    $Book->close();
    sleep(1);
    my $ret = system("$HTML_File_Name_With_Path");
    print " ret = $ret";

    #close $excel;
    print "exit";
}

package main;
__END__











































