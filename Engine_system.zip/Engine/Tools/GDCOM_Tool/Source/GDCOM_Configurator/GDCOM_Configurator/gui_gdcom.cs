﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace GDCOM_Configurator
{
    public partial class gui_gdcom : Form
    {

        Read_ODX_File rodx = new Read_ODX_File();
        Write_ODX_Mapping wodx = new Write_ODX_Mapping();        
        Unzip un = new Unzip();
        

        public gui_gdcom()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Browse_btn_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                file_Name_txt.Text = folderBrowserDialog1.SelectedPath;
            }       
        }
        private void file_Name_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void create_diagmap_btn_Click(object sender, EventArgs e)
        {
            wodx.flag = 0;
            wodx.Write_odx_Contents(rodx);            
        }

        private void Read_odx_btn_Click(object sender, EventArgs e)
        {                    
            rodx.file_path = file_Name_txt.Text;
            rodx.flag = 0;
            rodx.Read_ODX();                    
        }      

        private void button5_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "PDX Files (*.pdx)|*.pdx";
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                string pdxfile = openFileDialog2.FileName;
                DirectoryInfo in_dir = new DirectoryInfo(Path.GetDirectoryName(pdxfile));
                string odx_file = in_dir + "\\" + Path.GetFileNameWithoutExtension(pdxfile);
                string directory = Environment.CurrentDirectory;                
                string gpath = directory + "\\Settings\\Global_Data_Settings.xml";
                if (File.Exists(gpath))
                    rodx.global_data_path = gpath;
                else
                    rodx.global_data_path = null;
                String odx = un.extractFileFromZip(pdxfile, odx_file);
                if (odx == "null")
                {
                    Application.Exit();
                }
                file_Name_txt.Text = odx;             
                textBox2.Text = pdxfile;
            }      
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
