﻿namespace GDCOM_Configurator
{
    partial class gui_gdcom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.file_Name_txt = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.GDCOM = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.GDCOM.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(215, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 49);
            this.button1.TabIndex = 0;
            this.button1.Text = "Create Diag_Mapping File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.create_diagmap_btn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(393, 75);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "Browse";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Browse_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "ODX Folder Path";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // file_Name_txt
            // 
            this.file_Name_txt.Location = new System.Drawing.Point(97, 78);
            this.file_Name_txt.Multiline = true;
            this.file_Name_txt.Name = "file_Name_txt";
            this.file_Name_txt.Size = new System.Drawing.Size(274, 42);
            this.file_Name_txt.TabIndex = 3;
            this.file_Name_txt.TextChanged += new System.EventHandler(this.file_Name_txt_TextChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(26, 183);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(167, 52);
            this.button3.TabIndex = 4;
            this.button3.Text = "Read_ODX_File";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Read_odx_btn_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(393, 25);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(123, 43);
            this.button5.TabIndex = 8;
            this.button5.Text = "Browse";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "PDX File ";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(97, 30);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(274, 38);
            this.textBox2.TabIndex = 10;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // GDCOM
            // 
            this.GDCOM.Controls.Add(this.button6);
            this.GDCOM.Controls.Add(this.textBox2);
            this.GDCOM.Controls.Add(this.label3);
            this.GDCOM.Controls.Add(this.button5);
            this.GDCOM.Controls.Add(this.button3);
            this.GDCOM.Controls.Add(this.file_Name_txt);
            this.GDCOM.Controls.Add(this.label1);
            this.GDCOM.Controls.Add(this.button2);
            this.GDCOM.Controls.Add(this.button1);
            this.GDCOM.Location = new System.Drawing.Point(146, 104);
            this.GDCOM.Name = "GDCOM";
            this.GDCOM.Size = new System.Drawing.Size(531, 283);
            this.GDCOM.TabIndex = 11;
            this.GDCOM.TabStop = false;
            this.GDCOM.Text = "GDCOM";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(378, 183);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(138, 49);
            this.button6.TabIndex = 11;
            this.button6.Text = "Exit";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(303, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "GDCOM Configurator";
            // 
            // gui_gdcom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 463);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.GDCOM);
            this.Name = "gui_gdcom";
            this.Text = "GDCOM Configurator Tool";
            this.GDCOM.ResumeLayout(false);
            this.GDCOM.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox file_Name_txt;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox GDCOM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button6;
    }
}

