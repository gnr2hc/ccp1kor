﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml;
using System.Data;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;

namespace GDCOM_Configurator
{
    public class Read_ODX_File
    {
        TextWriter ErrorHandle;

        public XDocument ODXContents; 
        public XDocument GlobalData;
        
        public string global_data_path; 
        public string file_path;
        public int flag;

        string ODXname;        
       
        //DataTable Creation
        public DataTable diag_table = new DataTable(); 
        public DataTable struct_table = new DataTable(); 
        public DataTable DTC = new DataTable(); 
        public DataTable Global_NRC = new DataTable(); 

        //Creating Dictionary
        public Dictionary<string,List<string>> odx_dic = new Dictionary<string,List<string>>();

        
                        
        public void Read_ODX()
        {
            String log_file_name = DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss");

            string path = Environment.CurrentDirectory +"\\Reports\\Log_" + log_file_name + ".txt";

            ErrorHandle = new StreamWriter(path);
           
            ErrorHandle.WriteLine("-------------------------------------");
            ErrorHandle.WriteLine("GDCOM Configurator - Error Handle Report");
            ErrorHandle.WriteLine("Date  :  " + log_file_name);
            ErrorHandle.WriteLine("-------------------------------------");
            
            //Reset the Table values
            diag_table.Rows.Clear();
            diag_table.Columns.Clear();
            
            struct_table.Rows.Clear();
            struct_table.Columns.Clear();

            DTC.Rows.Clear();
            DTC.Columns.Clear();

            Global_NRC.Rows.Clear();
            Global_NRC.Columns.Clear();

            if (global_data_path == null)
            {
                ErrorHandle.WriteLine("Error : Global Setting File Path is not defined");
                ErrorHandle.WriteLine("-------------------------------------");
                if (flag == 0)
                {
                    MessageBox.Show("Global setting File is missing", "File", MessageBoxButtons.OK);
                    Application.Exit();
                }
                else
                {
                    Console.Out.WriteLine("\nGlobal setting File is missing");
                    Environment.Exit(0);
                }
            }
            else
            {
                GlobalData = XDocument.Load(global_data_path);

                Global_NRC.Columns.Add("ID");//Adding the Column into global Table
                Global_NRC.Columns.Add("Label");

                read_global_response(GlobalData); //call the function to read data

                Global_NRC.DefaultView.Sort = "ID"; //Sorting the Table by Global ID
                Global_NRC = Global_NRC.DefaultView.ToTable();
            }

            if (file_path == "") 
            {
                if (flag == 0)
                {
                    MessageBox.Show("Please Provide the Correct ODX data path", "File Path", MessageBoxButtons.OK);
                }
                else
                {
                    Console.Out.WriteLine("\nPlease Provide the Correct ODX data path");
                }
                ErrorHandle.WriteLine("Error : ODX data path is not defined");
                ErrorHandle.WriteLine("-------------------------------------");
                
            }
            
            else
            {
                string[] filePaths = Directory.GetFiles(file_path, "*.odx");
                ODXContents = XDocument.Load(filePaths[0]);

                for (int i = 1; i < filePaths.Length; i++)
                {
                    ODXContents.Root.Add(XDocument.Load(filePaths[i]).Root.Elements());
                }               

               
                diag_table.Columns.Add("Service_Name");
                diag_table.Columns.Add("DS_Req_ID");                
                diag_table.Columns.Add("Request");
                diag_table.Columns.Add("DS_Resp_ID");
                diag_table.Columns.Add("Response");
                diag_table.Columns.Add("Neg_Response");
                diag_table.Columns.Add("Sessions");
                
               
                struct_table.Columns.Add("Struct_Key");
                struct_table.Columns.Add("Byte-Position");
                struct_table.Columns.Add("Offset");
                struct_table.Columns.Add("Factor");                
                struct_table.Columns.Add("Denominator");
                struct_table.Columns.Add("Bit_Length");
                struct_table.Columns.Add("Type");
                struct_table.Columns.Add("Precision");
                struct_table.Columns.Add("Unit");
                struct_table.Columns.Add("LName");
                struct_table.Columns.Add("TI");
                 
                read_Odx_Contents();
                
                diag_table.DefaultView.Sort = "DS_Req_ID";
                diag_table = diag_table.DefaultView.ToTable();

                struct_table.DefaultView.Sort = "Struct_Key";
                struct_table = struct_table.DefaultView.ToTable(true);

                read_dtc_values();
                
                if(flag == 0)
                MessageBox.Show("ODX Files Read Successfully", "GDCOM-Configurator"); 
            }
            
            ErrorHandle.Close();
        }
        ///////////////////////////////
        //To read the Global NRC data//
        ///////////////////////////////

        public void read_global_response(XDocument GlobalData)
        {
            var NRC = from nrc_table in GlobalData.Descendants("GNRC")
                      let id = nrc_table.Attribute("ID") as XAttribute
                      let label = nrc_table.Element("LABEL") as XElement
                      select new
                      {
                          id = (id != null) ? id.Value : "",
                          label = (label != null) ? label.Value : "",
                      };

            if (NRC != null)
            {
                foreach (var nrc in NRC)
                {
                    DataRow dt = Global_NRC.NewRow();
                    dt[0] = nrc.id.ToString();
                    dt[1] = nrc.label.ToString();
                    Global_NRC.Rows.Add(dt);
                }
            }
            else
            {
                ErrorHandle.WriteLine("Error : GNRC Node is not Found in " + global_data_path);
                ErrorHandle.WriteLine("-------------------------------------");
            }
        }

        ///////////////////////////////////
        //To Read the Diagnostic Services//       
        ///////////////////////////////////
       
        public void read_Odx_Contents()
        {
            try
            {
                var layer = from odx_layer_table in ODXContents.Descendants("DIAG-LAYER-CONTAINER")                            
                            let odx_name = odx_layer_table.Attribute("ID") as XAttribute
                            select new
                            {
                                odx_name = (odx_name != null) ? odx_name.Value : "",
                                odx_layer_table,
                                
                            };

                if (layer != null)
                {

                    foreach (var layer_1 in layer)
                    {//Read Diagnostic services from each layer 

                        ODXname = layer_1.odx_name;

                        var diag_services = from ds_table in layer_1.odx_layer_table.Descendants("DIAG-SERVICE")                                                                                  
                                            let id_sn = ds_table.Attribute("ID") as XAttribute
                                            let address = ds_table.Attribute("ADDRESSING") as XAttribute
                                            let l_name = ds_table.Element("LONG-NAME") as XElement
                                            where l_name != null
                                            select new
                                            {
                                                id_sn = (id_sn != null) ? id_sn.Value : "",
                                                address = (address != null) ? address.Value : "",
                                                l_name = (l_name != null) ? l_name.Value : "",
                                                rel_diag_ref = (ds_table.Elements("RELATED-DIAG-COMM-REFS").Count() != 0) ? ds_table.Elements("RELATED-DIAG-COMM-REFS") : null,
                                                pos_resp_ref = (ds_table.Descendants("POS-RESPONSE-REF").Count() != 0) ? ds_table.Descendants("POS-RESPONSE-REF") : null,
                                                neg_resp_ref = (ds_table.Descendants("NEG-RESPONSE-REF").Count() != 0) ? ds_table.Descendants("NEG-RESPONSE-REF") : null,
                                                req_ref = (ds_table.Elements("REQUEST-REF").Count() != 0) ? ds_table.Elements("REQUEST-REF") : null,
                                            };


                        if (diag_services != null )
                        {
                           

                           
                            foreach (var ds_one in diag_services)                               
                            {//loop for all diag services

                                DataRow dr = diag_table.NewRow();

                                string id_sn_ds = ds_one.id_sn;
                                string address_ds = ds_one.address;
                                string req_res_id;
                                string doc_ref;
                                string all_session = null;

                                dr[0] = ds_one.l_name.ToString().Replace("/", "_");

                                //***Session Types for each diag services***//
                                if (ds_one.rel_diag_ref != null)
                                {
                                    var session_type = from session in ds_one.rel_diag_ref.Descendants("RELATED-DIAG-COMM-REF")
                                                       let allw_session = session.Attribute("ID-REF") as XAttribute
                                                       select new
                                                       {//Read the session from each diagnostic service
                                                           allw_session = (allw_session != null) ? allw_session.Value : "",
                                                       };

                                    if (session_type != null)
                                    {
                                        foreach (var ses in session_type)
                                        {
                                            if (ses.allw_session.Contains("DiagnServi_"))
                                            {
                                                string[] sess_arr = ses.allw_session.Split('_');
                                                if (sess_arr[1].Contains("Devel"))
                                                {
                                                    sess_arr[1] = "DevelopmentSession";
                                                }
                                                if (sess_arr[1].Contains("ECUPro"))
                                                {
                                                    sess_arr[1] = "ECUProgrammingSession";
                                                }
                                                if (sess_arr[1].Contains("Exten"))
                                                {
                                                    sess_arr[1] = "ExtendedSession";
                                                }
                                                if (sess_arr[1].Contains("OBDIIAndVW"))
                                                {
                                                    sess_arr[1] = "OBDIIAndVWDefaultSession";
                                                }
                                                if (sess_arr[1].Contains("VWEndOfLine"))
                                                {
                                                    sess_arr[1] = "VWEndOfLineSession";
                                                }
                                                if (sess_arr[1].Contains("FUNC"))
                                                {
                                                    sess_arr[1] = "FunctionalSession";
                                                }
                                                all_session = all_session + " " + sess_arr[1];
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ErrorHandle.WriteLine("Error : RELATED-DIAG-COMM-REFS is not Found. " + "SERVICE NAME => " + ds_one.l_name + ", LAYER => " + ODXname);
                                        ErrorHandle.WriteLine("-------------------------------------");
                                    }
                                }
                                else
                                {
                                    ErrorHandle.WriteLine("Error : RELATED-DIAG-COMM-REFS is not Found. " + "SERVICE NAME => " + ds_one.l_name + ", LAYER => " + ODXname);
                                    ErrorHandle.WriteLine("-------------------------------------");
                                }
                                dr[6] = all_session;
                                if (ds_one.req_ref != null)
                                {
                                //***Request for each diag services***//
                                foreach (var req_att1 in ds_one.req_ref)
                                {
                                    //Check for document reference
                                    if (req_att1.Attribute("DOCREF") != null)
                                    {
                                        req_res_id = req_att1.Attribute("ID-REF").Value;
                                        doc_ref = req_att1.Attribute("DOCREF").Value;
                                    }
                                    else
                                    {
                                        req_res_id = req_att1.Attribute("ID-REF").Value;
                                        doc_ref = ODXname;
                                    }

                                    //To read the request details from Request structure
                                    refer_Odx_File(req_res_id, doc_ref, dr);
                                }
                                }
                                else
                                {
                                    dr[2] = "undef";
                                    ErrorHandle.WriteLine("Error : REQUEST-REF is not Found. " + "SERVICE NAME => " + ds_one.l_name + ", LAYER => " + ODXname);
                                    ErrorHandle.WriteLine("-------------------------------------");
                                }

                                if (ds_one.pos_resp_ref != null)
                                {
                                    //***Response for each diag services***//
                                    foreach (var req_att1 in ds_one.pos_resp_ref)
                                    {
                                        //Check for document reference
                                        if (req_att1.Attribute("DOCREF") != null)
                                        {
                                            req_res_id = req_att1.Attribute("ID-REF").Value;
                                            doc_ref = req_att1.Attribute("DOCREF").Value;
                                        }
                                        else
                                        {
                                            req_res_id = req_att1.Attribute("ID-REF").Value;
                                            doc_ref = ODXname;
                                        }
                                        //To read the response details from Response structure
                                        refer_Odx_File(req_res_id, doc_ref, dr);
                                    }
                                }
                                else
                                {
                                    dr[4] = "undef";
                                    ErrorHandle.WriteLine("Error : POS-RESPONSE-REF is not Found. " + "SERVICE NAME => " + ds_one.l_name + ", LAYER => " + ODXname);
                                    ErrorHandle.WriteLine("-------------------------------------");
                                }

                                if (ds_one.neg_resp_ref != null)
                                {
                                    //***Neg-Response for each diag services***//
                                    foreach (var req_att1 in ds_one.neg_resp_ref)
                                    {
                                        //Check for document reference
                                        if (req_att1.Attribute("DOCREF") != null)
                                        {
                                            req_res_id = req_att1.Attribute("ID-REF").Value;
                                            doc_ref = req_att1.Attribute("DOCREF").Value;
                                        }
                                        else
                                        {
                                            req_res_id = req_att1.Attribute("ID-REF").Value;
                                            doc_ref = ODXname;
                                        }

                                        //To read the Neg-response details from Neg-Response structure
                                        refer_Odx_File(req_res_id, doc_ref, dr);
                                    }
                                }
                                else
                                {
                                    dr[5] = "undef";
                                    ErrorHandle.WriteLine("Error : NEG-RESPONSE-REF is not Found. " + "SERVICE NAME => " + ds_one.l_name + ", LAYER => " + ODXname);
                                    ErrorHandle.WriteLine("-------------------------------------");                                    
                                }

                                diag_table.Rows.Add(dr);
                            }
                        }
                        else
                        {
                            ErrorHandle.WriteLine("Error : DIAG-SERVICE is not Found in layer. " + " LAYER => " + ODXname);
                            ErrorHandle.WriteLine("-------------------------------------");
                        }

                    }
                }
                else
                {
                    ErrorHandle.WriteLine("Error : DIAG-LAYER-CONTAINER is not Found in Parsed ODX files. ");
                    ErrorHandle.WriteLine("-------------------------------------");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private static bool IsEmpty(IEnumerable<XElement> source)
        {
            return !source.Any();
        }

        //////////////////////////////////////////////////////////////
        //Read the Request, Response and Negative response structure//
        //////////////////////////////////////////////////////////////

        public void refer_Odx_File(string req_res_id, string doc_ref, DataRow dr)
        {
            try
            {             
                string label;
                string ref_lab_table = null;
                string doc_ref_table = null;

                var layer_refer = from odx_layer_table in ODXContents.Descendants("DIAG-LAYER-CONTAINER")
                                  where odx_layer_table.Attribute("ID").Value.Contains(doc_ref)
                                  select new
                                  {
                                      odx_layer_table
                              };

                if (layer_refer != null)
                {
                    foreach (var req_res in layer_refer)
                    {             
                        string check = null;
                        Regex re = new Regex("^bc3.*?dsc$");
                        
                        //Request
                        if (new Regex("^Req.*?").IsMatch(req_res_id) || new Regex("RQ.*?").IsMatch(req_res_id))
                        {
                            check = "REQUEST";
                            dr[2] = req_res_id;
                        }
                        //Response
                        if (new Regex("^Resp.*?").IsMatch(req_res_id) || new Regex("PR.*?").IsMatch(req_res_id))
                        {
                            check = "POS-RESPONSE";
                            dr[4] = req_res_id;

                        }
                        //Negative Response
                        if (new Regex("^NegatResp.*?").IsMatch(req_res_id) || new Regex("NR.*?").IsMatch(req_res_id))
                        {
                            check = "NEG-RESPONSE";
                            dr[5] = req_res_id;
                        }
                        
                        var req1 = from req_table in req_res.odx_layer_table.Descendants(check)
                                   where req_table.Attribute("ID").Value.Equals(req_res_id)
                                   select new
                                   {
                                       req_param = (req_table.Elements("PARAMS").Count() != 0) ? req_table.Elements("PARAMS") : null,
                                   };

                        if (req1 != null)
                        {//Check for Request and Response PARAM Values
                            foreach (var req_val in req1)
                            {
                                foreach (var r_val in req_val.req_param)
                                {

                                  

                                    var values = from param_table in r_val.Descendants("PARAM")
                                                 let semantic = param_table.Attribute("SEMANTIC") as XAttribute
                                                 let service_id = param_table.Element("CODED-VALUE") as XElement
                                                 let phy_con_val = param_table.Element("PHYS-CONSTANT-VALUE") as XElement
                                                 let phys_def_val = param_table.Element("PHYSICAL-DEFAULT-VALUE") as XElement
                                                 let phy_def_val = param_table.Element("PHYS-DEFAULT-VALUE") as XElement
                                                 select new
                                                 {
                                                     semantic = (semantic != null) ? semantic.Value : null,
                                                     service_id = (service_id != null) ? service_id.Value : null,
                                                     phy_con_val = (phy_con_val != null) ? phy_con_val.Value : null,
                                                     phys_def_val = (phys_def_val != null) ? phys_def_val.Value : null,
                                                     phy_def_val = (phy_def_val != null) ? phy_def_val.Value : null,
                                                     dop_ref = (param_table.Elements("DOP-REF").Count() != 0) ? param_table.Elements("DOP-REF") : null,
                                                     dop_sn_ref = (param_table.Elements("DOP-SNREF").Count() != 0) ? param_table.Elements("DOP-SNREF") : null,
                                                     tab_ref = (param_table.Elements("TABLE-REF").Count() != 0) ? param_table.Elements("TABLE-REF") : null,
                                                 };
                                    
                                    List<String> Val_limit = new List<String>();
                                    if (values != null)
                                    {
                                        foreach (var val in values)
                                        {
                                            if (val.semantic != null)
                                            {
                                                if (!val.semantic.Contains("SUPPRESS"))
                                                {
                                                    if (val.service_id != null) //Check for service ID
                                                    {
                                                        int service_id = int.Parse(val.service_id);
                                                        if ((check == "REQUEST") && (val.semantic == "SERVICE-ID"))
                                                        {
                                                            dr[1] = service_id.ToString("X");
                                                            dr[3] = (service_id + 64).ToString("X");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (val.phy_con_val != null)
                                                        {
                                                            label = val.phy_con_val;
                                                        }
                                                        else if (val.phy_def_val != null)
                                                        {
                                                            label = val.phy_def_val;
                                                        }
                                                        else if (val.phys_def_val != null)
                                                        {
                                                            label = val.phys_def_val;
                                                        }
                                                        else
                                                        {
                                                            label = null;
                                                        }

                                                        if (val.dop_ref != null || val.dop_sn_ref != null || val.tab_ref != null)
                                                        {//check for reference values
                                                            if (val.dop_ref != null)
                                                            {
                                                                foreach (var d_ref in val.dop_ref)
                                                                {
                                                                    if (d_ref.Attribute("DOCREF") != null)
                                                                    {
                                                                        ref_lab_table = d_ref.Attribute("ID-REF").Value;
                                                                        doc_ref_table = d_ref.Attribute("DOCREF").Value;
                                                                    }
                                                                    else
                                                                    {
                                                                        ref_lab_table = d_ref.Attribute("ID-REF").Value;
                                                                        doc_ref_table = doc_ref;
                                                                    }

                                                                }
                                                                //To read the Value Labels from particular table
                                                                refer_odx_dop(ref_lab_table, doc_ref_table, label, Val_limit, req_res_id);
                                                            }

                                                            else if (val.dop_sn_ref != null)
                                                            {
                                                                foreach (var sn_ref in val.dop_sn_ref)
                                                                {
                                                                    if (sn_ref.Attribute("DOCREF") != null)
                                                                    {
                                                                        ref_lab_table = sn_ref.Attribute("SHORT-NAME").Value;
                                                                        doc_ref_table = sn_ref.Attribute("DOCREF").Value;

                                                                    }
                                                                    else
                                                                    {
                                                                        ref_lab_table = sn_ref.Attribute("SHORT-NAME").Value;
                                                                        doc_ref_table = doc_ref;
                                                                    }

                                                                }
                                                                //To read the Value Labels from particular table
                                                                refer_odx_dop(ref_lab_table, doc_ref_table, label, Val_limit, req_res_id);
                                                            }

                                                            else if (val.tab_ref != null)
                                                            {
                                                                foreach (var t_ref in val.tab_ref)
                                                                {
                                                                    if (t_ref.Attribute("DOCREF") != null)
                                                                    {
                                                                        ref_lab_table = t_ref.Attribute("ID-REF").Value;
                                                                        doc_ref_table = t_ref.Attribute("DOCREF").Value;

                                                                    }
                                                                    else
                                                                    {
                                                                        ref_lab_table = t_ref.Attribute("ID-REF").Value;
                                                                        doc_ref_table = doc_ref;
                                                                    }

                                                                }
                                                                refer_odx_dop(ref_lab_table, doc_ref_table, label, Val_limit, req_res_id);
                                                            }
                                                            else
                                                            {
                                                            }
                                                        }

                                                    }
                                                }
                                            }

                                        }
                                    }
                                    else
                                    {
                                        ErrorHandle.WriteLine("Error : PARAM values are not Found. " + "ID => " + req_res_id + ", LAYER => " + doc_ref);
                                        ErrorHandle.WriteLine("-------------------------------------");
                                    }
                                    if (!odx_dic.ContainsKey(req_res_id))
                                    {
                                        odx_dic.Add(req_res_id, Val_limit);
                                    }
                                }
                            }
                        }
                        else
                        {
                            ErrorHandle.WriteLine("Error : " + check + "is not Found. " + "REQUEST RESPONSE ID => " + req_res_id + ", LAYER => " + doc_ref);
                            ErrorHandle.WriteLine("-------------------------------------");
                        }
                    }
                }
                else
                {
                    ErrorHandle.WriteLine("Error : Document refernce layer is not Found. " + "LAYER => " + doc_ref);
                    ErrorHandle.WriteLine("-------------------------------------");
                }
            

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + req_res_id, "refer_Odx_File");
            }
        }
    
        ////////////////////////////////////////////////////////////////////////////
        //To read the DOP Table or Table Datas for particular request or response///
        ////////////////////////////////////////////////////////////////////////////

        public void refer_odx_dop(string ref_lab_table, string doc_ref_table, string label, List<string> Val_limit, string req_res_id)
        {
            try
            {
                List<String> key_labels = new List<String>();
                List<String> tab_struct = new List<string>();
                string struct_doc_ref = null;
                string structure_id = null;

                var refer_layer = from layer_tab in ODXContents.Descendants("DIAG-LAYER-CONTAINER")
                                  where layer_tab.Attribute("ID").Value.Contains(doc_ref_table)
                                  select new
                                  {
                                      layer_tab
                                  };

                if (refer_layer != null)
                {
                    foreach (var ref_layer in refer_layer)
                    {
                        if (ref_lab_table.Contains("TAB_")) //Check either Tables or DOP
                        {
                            label = "TAB";
                            var table_values = from dop in ref_layer.layer_tab.Descendants("TABLE")
                                               where dop.Attribute("ID").Value.Equals(ref_lab_table)
                                               let key_id = dop.Element("KEY-DOP-REF").Attribute("ID-REF") as XAttribute
                                               let key_doc_ref = dop.Element("KEY-DOP-REF").Attribute("DOCREF") as XAttribute
                                               select new
                                               {
                                                   key_id = (key_id != null) ? key_id.Value : null,
                                                   key_doc_ref = (key_doc_ref != null) ? key_doc_ref.Value : null,
                                                   key_val = (dop.Elements("TABLE-ROW").Count() != 0) ? dop.Elements("TABLE-ROW") : null,
                                               };
                            if (table_values != null)
                            {
                                foreach (var t_val in table_values)
                                {
                                    ref_lab_table = t_val.key_id;

                                    if (t_val.key_doc_ref != null)
                                    {
                                        doc_ref_table = t_val.key_doc_ref;
                                    }

                                    if (t_val.key_val != null)
                                    {
                                        foreach (var key in t_val.key_val)
                                        {
                                            key_labels.Add(key.Element("KEY").Value);

                                            if (key.Element("STRUCTURE-REF") != null)
                                            {
                                                structure_id = key.Element("STRUCTURE-REF").Attribute("ID-REF").Value.ToString();
                                                if (key.Element("STRUCTURE-REF").Attribute("DOCREF") != null)
                                                {
                                                    struct_doc_ref = key.Element("STRUCTURE-REF").Attribute("DOCREF").Value.ToString();
                                                }
                                                else
                                                {
                                                    struct_doc_ref = doc_ref_table;
                                                }
                                            }
                                            else
                                            {
                                                structure_id = null;
                                                struct_doc_ref = null;
                                            }
                                            tab_struct.Add(structure_id + "@" + struct_doc_ref);
                                        }
                                    }
                                    else
                                    {
                                        label = null;
                                    }
                                }
                            }
                            else
                            {
                                ErrorHandle.WriteLine("Error : Table Not found. " + "REQUEST-RESPONSE ID => " + req_res_id + ", TABLE NAME => " + ref_lab_table + ", LAYER => " + doc_ref_table);
                                ErrorHandle.WriteLine("-------------------------------------");
                            }
                        }
                        var dop_compu_values = from dop in ref_layer.layer_tab.Descendants("DATA-OBJECT-PROP")
                                               where dop.Attribute("ID").Value.Equals(ref_lab_table)
                                               select new
                                               {
                                                   val = (dop.Descendants("COMPU-SCALE").Count() != 0) ? dop.Descendants("COMPU-SCALE") : null,
                                               };

                        if (dop_compu_values != null)
                        {
                            foreach (var comp_val in dop_compu_values)
                            {

                                if (comp_val.val != null)
                                {
                                    if (label != null && label != "TAB") //Dop Table 
                                    {
                                        foreach (var c_val in comp_val.val)
                                        {
                                            if (c_val.Element("LOWER-LIMIT") != null)
                                            {

                                                if (c_val.Element("COMPU-CONST").Element("VT").Value == label)
                                                {
                                                    string limit_val = c_val.Element("LOWER-LIMIT").Value;
                                                    Int32 li_val;

                                                    if (int.TryParse(limit_val, out li_val))
                                                    {
                                                        string val = (int.Parse((c_val.Element("LOWER-LIMIT").Value).ToString())).ToString("X");
                                                        int len = val.Length;
                                                        if (len % 2 != 0)
                                                        {
                                                            val = val.PadLeft((len + 1), '0');
                                                        }

                                                        string test = Regex.Replace(val, @"(.{2})", "$1 ");
                                                        Val_limit.Add((label + "@" + test));
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (label == "TAB") // Tables
                                    {
                                        while (key_labels.Count != 0)
                                        {
                                            label = key_labels[0];
                                            string[] structure = tab_struct[0].Split('@');
                                            structure_id = structure[0];
                                            struct_doc_ref = structure[1];
                                            foreach (var c_val in comp_val.val)
                                            {
                                                if (c_val.Element("LOWER-LIMIT") != null)
                                                {
                                                    if (c_val.Element("COMPU-CONST").Element("VT").Value == label)
                                                    {
                                                        string limit_val = c_val.Element("LOWER-LIMIT").Value;
                                                        Int32 li_val;

                                                        if (int.TryParse(limit_val, out li_val))
                                                        {
                                                            string val = (int.Parse((c_val.Element("LOWER-LIMIT").Value).ToString())).ToString("X");
                                                            int len = val.Length;
                                                            string vt_ti;
                                                            if (c_val.Element("COMPU-CONST").Element("VT").Attribute("TI") != null)
                                                            {
                                                                vt_ti = c_val.Element("COMPU-CONST").Element("VT").Attribute("TI").Value;
                                                            }
                                                            else
                                                            {
                                                                vt_ti = "undef";
                                                            }
                                                            if (len % 2 != 0)
                                                            {
                                                                val = val.PadLeft((len + 1), '0');
                                                            }
                                                            string test = Regex.Replace(val, @"(.{2})", "$1 ");
                                                            Val_limit.Add((label + "@" + test));

                                                            //to read the refered Structure tables from DOP tables
                                                            read_structure(structure_id, struct_doc_ref, val + "_" + label,vt_ti, req_res_id, ref_lab_table);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            key_labels.RemoveAt(0);
                                            tab_struct.RemoveAt(0);
                                        }
                                    }
                                    else if (label == null)
                                    {//If label is null read the all the values from table
                                        foreach (var c_val in comp_val.val)
                                        {
                                            if (c_val.Element("LOWER-LIMIT") != null)
                                            {
                                                string limit_val = c_val.Element("LOWER-LIMIT").Value;
                                                Int32 li_val;

                                                if (int.TryParse(limit_val, out li_val))
                                                {
                                                    string val = (int.Parse((c_val.Element("LOWER-LIMIT").Value).ToString())).ToString("X");
                                                    int len = val.Length;

                                                    if (len % 2 != 0)
                                                    {
                                                        val = val.PadLeft((len + 1), '0');
                                                    }
                                                    string test = Regex.Replace(val, @"(.{2})", "$1 ");
                                                    if (c_val.Element("COMPU-CONST") != null)
                                                    {
                                                        Val_limit.Add((c_val.Element("COMPU-CONST").Element("VT").Value).Replace(" ", "") + "@" + test);
                                                    }
                                                    else
                                                    {
                                                        Val_limit.Add("undef");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                    }
                                }
                                //else
                                //{
                                //    ErrorHandle.WriteLine("Error : COMPU-SCALE is Not found. " + "REQUEST-RESPONSE ID => " + req_res_id + "TABLE NAME => " + ref_lab_table + " LAYER => " + doc_ref_table);
                                //    ErrorHandle.WriteLine("-------------------------------------");                                    
                                //}
                            }
                        }
                        else
                        {
                            ErrorHandle.WriteLine("Error : DOP Table Not found. " + "REQUEST-RESPONSE ID => " + req_res_id + "TABLE NAME => " + ref_lab_table + " LAYER => " + doc_ref_table);
                            ErrorHandle.WriteLine("-------------------------------------");
                        }
                    }
                }
                else
                {
                    ErrorHandle.WriteLine("Error : Document refernce layer is not Found. " + "REQUEST-RESPONSE ID => " + req_res_id + ", LAYER => " + doc_ref_table);
                    ErrorHandle.WriteLine("-------------------------------------");
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message + ref_lab_table, "refer_odx_dop");
            }
        }

        //////////////////////////
        //structure table values//
        //////////////////////////

        public void read_structure(string struct_id, string struct_doc_ref, string key,string vt_ti, string req_res_id, string ref_lab_table)
        {
            var struct_layer = from odx_tab in ODXContents.Descendants("DIAG-LAYER-CONTAINER")
                              where odx_tab.Attribute("ID").Value.Contains(struct_doc_ref)                              
                              select new
                              {                                  
                                  struct_ref = odx_tab.Descendants("STRUCTURE")
                              };

            if (struct_layer != null)
            {
                foreach (var st_id in struct_layer)
                {
                    foreach (var str_id in st_id.struct_ref)
                    {
                        if (str_id.Attribute("ID").Value.Equals(struct_id))
                        {
                            var struct_ref = from struct_tab in str_id.Descendants("PARAM")
                                             select new
                                             {
                                                 struct_tab
                                             };
                            foreach (var st in struct_ref)
                            {
                                string i_ref = null;
                                string d_ref = null;

                                string lname = st.struct_tab.Element("LONG-NAME").Value.ToString();

                                if (st.struct_tab.Element("DOP-REF") != null)
                                {
                                    i_ref = st.struct_tab.Element("DOP-REF").Attribute("ID-REF").Value.ToString();

                                    if (st.struct_tab.Element("DOP-REF").Attribute("DOCREF") != null)
                                    {
                                        d_ref = st.struct_tab.Element("DOP-REF").Attribute("DOCREF").Value.ToString();
                                    }
                                    else
                                    {
                                        d_ref = struct_doc_ref;
                                    }
                                    string BytePosition = st.struct_tab.Element("BYTE-POSITION").Value;
                                    read_srtucture_values(i_ref, d_ref, lname, key, vt_ti,BytePosition, req_res_id, struct_id);
                                }
                            }
                        }                       
                    }
                }
            }
            else
            {
                ErrorHandle.WriteLine("Error :Structure is not Found. " + "REQUEST-RESPONSE ID => " + req_res_id + ", TABLE NAME => "+ref_lab_table+ ", STRUCT ID => " + struct_id + ", LAYER => " + struct_doc_ref);
                ErrorHandle.WriteLine("-------------------------------------");
            }
        }

        //////////////////////////
        //structure table values//
        //////////////////////////

        public void read_srtucture_values(string i_ref, string d_ref, string lname, string key,string vt_ti, string BytePosition, string req_res_id, string struct_id)
        {     
            
            var refer_layer = from lr_tab in ODXContents.Descendants("DIAG-LAYER-CONTAINER")
                              where lr_tab.Attribute("ID").Value.Contains(d_ref)
                              select new
                              {
                                  tabs = lr_tab.Descendants("DATA-OBJECT-PROP"),
                              };
          
                if (refer_layer != null)
                {
                    foreach (var tab in refer_layer)
                    {
                        foreach (var tab1 in tab.tabs)
                        {
                            if (tab1.Attribute("ID").Value.Equals(i_ref))
                            {
                                if (!tab1.Element("COMPU-METHOD").Element("CATEGORY").Value.Equals("TEXTTABLE"))
                                {
                                    DataRow sr = struct_table.NewRow();
                                    sr[0] = key.Replace(" ", "") + "_" + lname.Replace(" ", "");
                                    sr[1] = BytePosition;
                                    
                                    sr[10] = vt_ti;
                                    if (!tab1.Element("COMPU-METHOD").Element("CATEGORY").Value.Equals("IDENTICAL"))
                                    {
                                        sr[9] = lname;
                                        var num_val = from c_tab in tab1.Descendants("COMPU-NUMERATOR")
                                                      select new
                                                      {
                                                          num_value = c_tab.Descendants("V")
                                                      };
                                        int i = 2;
                                        foreach (var n_val in num_val)
                                        {
                                            foreach (var nvalu in n_val.num_value)
                                            {
                                                sr[i] = nvalu.Value;
                                                i++;
                                            }
                                        }
                                        var de_val = from c_tab in tab1.Descendants("COMPU-DENOMINATOR")
                                                     select new
                                                     {
                                                         den_value = c_tab.Descendants("V")
                                                     };

                                        foreach (var d_val in de_val)
                                        {
                                            foreach (var dvalu in d_val.den_value)
                                            {
                                                sr[4] = dvalu.Value;
                                            }
                                        }
                                        if (tab1.Element("DIAG-CODED-TYPE") != null & tab1.Element("DIAG-CODED-TYPE").Element("BIT-LENGTH") != null)
                                        {
                                            sr[5] = tab1.Element("DIAG-CODED-TYPE").Element("BIT-LENGTH").Value;
                                        }
                                        else
                                        {
                                            sr[5] = null;
                                        }
                                        if (tab1.Element("PHYSICAL-TYPE") != null & tab1.Element("PHYSICAL-TYPE").Attribute("BASE-DATA-TYPE") != null)
                                        {
                                            sr[6] = tab1.Element("PHYSICAL-TYPE").Attribute("BASE-DATA-TYPE").Value;
                                        }
                                        else
                                        {
                                            sr[6] = null;
                                        }
                                        if (tab1.Element("PHYSICAL-TYPE") != null & tab1.Element("PHYSICAL-TYPE").Element("PRECISION") != null)
                                        {
                                            sr[7] = tab1.Element("PHYSICAL-TYPE").Element("PRECISION").Value;
                                        }
                                        else
                                        {
                                            sr[7] = 0;
                                        }
                                        string unit_ref = null;
                                        string unit_dref = null;

                                        if (tab1.Element("UNIT-REF") != null)
                                        {

                                            if (tab1.Element("UNIT-REF").Attribute("DOCREF") != null)
                                            {
                                                unit_ref = tab1.Element("UNIT-REF").Attribute("ID-REF").Value;
                                                unit_dref = tab1.Element("UNIT-REF").Attribute("DOCREF").Value;
                                            }
                                            else
                                            {
                                                unit_ref = tab1.Element("UNIT-REF").Attribute("ID-REF").Value;
                                                unit_dref = d_ref;
                                            }
                                            unit_structure(unit_ref, unit_dref, sr);
                                        }
                                    }
                                    else
                                    {

                                        string[] name = key.Split(new char[] { '_' }, 2);
                                        sr[9] = name[1];
                                        sr[2] = 0.0;
                                        sr[3] = 1.0;
                                        sr[4] = 1.0;
                                        sr[5] = 1.0;
                                        sr[6] = "undef";
                                        sr[7] = 0.0;
                                        sr[8] = "undef";
                                        ErrorHandle.WriteLine("Error : COMPU-METHOD category is IDENTICAL. " + "LONG NAME => " + name[1] + ", STRUCT-ID => " + struct_id + ", STRUCT_REFER_TABLE => " + i_ref + ", REQUEST-RESPONSE ID => " + req_res_id + ", LAYER => " + d_ref);
                                        ErrorHandle.WriteLine("-------------------------------------");
                                    }
                                        struct_table.Rows.Add(sr);
                                   
                                }
                                else
                                {
                                    //ErrorHandle.WriteLine("Error : COMPU-METHOD category is not Textable. " + "STRUCT-ID : " + i_ref + "LAYER : " + d_ref);
                                    //ErrorHandle.WriteLine("-------------------------------------");
                                }
                            }

                        }
                    }
                }
                else
                {
                    ErrorHandle.WriteLine("Error : Structure refered table is not Found. " + "STRUCT-ID => " + struct_id + ", STRUCT_REFER_TABLE => " + i_ref + ", LAYER => " + d_ref);
                    ErrorHandle.WriteLine("-------------------------------------");
                }
            
        }

        //////////////////////////
        //To read UNIT structure//
        //////////////////////////

        public void unit_structure(string unit_ref, string unit_dref, DataRow sr)
        {
            var unit_layer = from unit_tab in ODXContents.Descendants("DIAG-LAYER-CONTAINER")
                             where unit_tab.Attribute("ID").Value.Contains(unit_dref)
                              select new
                              {
                                  unit_tab,
                              };
            if (unit_layer != null)
            {
                foreach (var uni in unit_layer)
                {
                    var unit_val = from uni_tab in uni.unit_tab.Descendants("UNIT")
                                   where uni_tab.Attribute("ID").Value.Equals(unit_ref)
                                   select new
                                   {
                                       uni_tab,
                                   };
                    foreach (var unit in unit_val)
                    {
                        sr[8] = unit.uni_tab.Element("DISPLAY-NAME").Value;
                    }
                }
            }
            else
            {
                ErrorHandle.WriteLine("Error : UNIT is not Found. " + unit_ref + " LAYER => " + unit_dref);
                ErrorHandle.WriteLine("-------------------------------------");
            }
        }    
   
        //////////////////////////////////////
        //To read Display Trouble Code (DTC)//
        //////////////////////////////////////
        
        public void read_dtc_values()
        {
            DTC.Columns.Add("TROUBLE-CODE");
            DTC.Columns.Add("ID");
            DTC.Columns.Add("SHORT-NAME");
            DTC.Columns.Add("DISPLAY-TROUBLE-CODE");
            DTC.Columns.Add("TEXT");
            DTC.Columns.Add("LEVEL");

            var dtc_layer = from dtc_table in ODXContents.Descendants("DTC")
                            let dtc_id = dtc_table.Attribute("ID") as XAttribute
                            let dtc_sn = dtc_table.Element("SHORT-NAME") as XElement
                            let dtc_tro_code = dtc_table.Element("TROUBLE-CODE") as XElement
                            let dtc_dis_code = dtc_table.Element("DISPLAY-TROUBLE-CODE") as XElement
                            let dtc_text = dtc_table.Element("TEXT") as XElement
                            let dtc_level = dtc_table.Element("LEVEL") as XElement
                        select new
                        {
                            dtc_id = (dtc_id != null) ? dtc_id.Value : "",
                            dtc_sn = (dtc_sn != null) ? dtc_sn.Value : "",
                            dtc_tro_code = (dtc_tro_code != null) ? dtc_tro_code.Value : "",
                            dtc_dis_code = (dtc_dis_code != null) ? dtc_dis_code.Value : "",
                            dtc_text = (dtc_text != null) ? dtc_text.Value : "",
                            dtc_level = (dtc_level != null) ? dtc_level.Value : "",
                        };
            if (dtc_layer != null)
            {
                foreach (var dtc in dtc_layer)
                {
                    DataRow dr = DTC.NewRow();
                    dr[0] = int.Parse(dtc.dtc_tro_code.ToString()).ToString("X");
                    dr[1] = dtc.dtc_id;
                    dr[2] = dtc.dtc_sn;
                    dr[3] = dtc.dtc_dis_code;
                    dr[4] = dtc.dtc_text;
                    dr[5] = dtc.dtc_level;
                    DTC.Rows.Add(dr);
                }
            }
            else
            {
                ErrorHandle.WriteLine("Error :No DISPLAY-TROUBLE-CODE in parsed ODX Files. ");
                ErrorHandle.WriteLine("-------------------------------------");
            }

        }
    }
}
///////////////
//End of File//
///////////////
