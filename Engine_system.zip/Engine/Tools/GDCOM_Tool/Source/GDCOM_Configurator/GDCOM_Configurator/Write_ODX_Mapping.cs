﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Windows.Forms;

namespace GDCOM_Configurator
{

    class Write_ODX_Mapping
    {        
        TextWriter FileHandle;        
        DataTable dst = new DataTable();
        Dictionary<string, List<string>> sub_dic = new Dictionary<string, List<string>>();
        public int flag;
        public void Write_odx_Contents(Read_ODX_File read_odx)
        {

            dst.Rows.Clear();
            dst.Columns.Clear();
            
            dst.Columns.Add("Diag_service");
            dst.Columns.Add("Sub_services");
            dst.Columns.Add("ID");
            dst.Columns.Add("Neg_Resp");

            String DM_fname = DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss");
            string path = Environment.CurrentDirectory +"\\Reports\\Diag_Mapping_" + DM_fname + ".pm";

            FileHandle = new StreamWriter(@path);
            FileHandle.WriteLine("package STEPS_DIAG_MAPPING; \n$Mapping = \n{ ");

            //////////////////////////////
            //Project Supported services//
            //////////////////////////////          

            FileHandle.WriteLine("\t\"PRJ_SUPPORTED_SERVICES\" => \n\t{ ");
            int rowindex = 0;
            string service = "0";

            while (rowindex < read_odx.diag_table.Rows.Count)
            {
                string diag = read_odx.diag_table.Rows[rowindex].ItemArray[1].ToString();
                if (!service.Contains(diag))
                {
                    service = diag;
                    string[] diag_ser = read_odx.diag_table.Rows[rowindex].ItemArray[0].ToString().Split('_');
                    FileHandle.WriteLine("\t\t\"" + diag_ser[0].Replace(" ","") + "\" => \"" + service + "\",");
                }
                rowindex++;
            }
            FileHandle.WriteLine("\t},");
            FileHandle.WriteLine("\t#***************************#");

            //////////////////////////////////////////
            //Negative Response supported Basic info//
            //////////////////////////////////////////

            FileHandle.WriteLine("\t\"NR_ServiceNotSupported\" => \n\t{ \n\t\t\"Response\" => \"7F\",\n\t\t\"Mode\" => \"relax\",\n\t\t\"Desc\" => \"Service not supported\",");
            FileHandle.WriteLine("\t},");
            FileHandle.WriteLine("\t#***************************#");

            //////////////////////
            //Request & Response//
            //////////////////////
            
            write_request_response(read_odx);

            /////////////////
            //Diag_services//
            /////////////////
            
            write_diagServices(read_odx);

            /////////////////////
            //Response_Phys2Hex//
            /////////////////////
            
            FileHandle.WriteLine("\t\"Response_Phys2Hex\" => \n\t{ ");
            foreach (DataRow sr in read_odx.struct_table.Rows)
            {
                int start_bit = (int.Parse(sr.ItemArray[1].ToString()) * 8) + int.Parse(sr.ItemArray[5].ToString()) + 16;
                FileHandle.WriteLine("\t\t\"" + sr.ItemArray[0] + "\" => { \"STARTBIT\"=> " + start_bit + ",\"LENGTH\"=> " + sr.ItemArray[5] + ",\"OFFSET\"=> " + sr.ItemArray[2] + ",\"FACTOR\"=> " + sr.ItemArray[3] + ",\"TYPE\"=> \"" + sr.ItemArray[6] + "\" ,\"UNIT\"=> \"" + sr.ItemArray[8] + "\" ,\"LONGNAME\"=> \"" + sr.ItemArray[9] +"\" ,\"TI\"=> \"" + sr.ItemArray[10] + "\" },");
            }
            FileHandle.WriteLine("\t}, # end of Response_Phys2Hex ");
            FileHandle.WriteLine("\t#***************************#");

            ////////////////////////////
            //Diagnostic Trouble Codes//
            ////////////////////////////

            FileHandle.WriteLine("\t\"DTC_INFO\" => \n\t{ ");
            foreach (DataRow row in read_odx.DTC.Rows)
            {
                FileHandle.WriteLine("\t\t\"" + row.ItemArray[0] + "\" => { \"Name\" => \"" + row.ItemArray[2] + "\" , \"Display_Code\" => \"" + row.ItemArray[3] + "\" , \"Text\" => \"" + row.ItemArray[4] + "\" , \"Level\" => \"" + row.ItemArray[5] + "\"},");
            }
            FileHandle.WriteLine("\t},# end of DTC ");
            FileHandle.WriteLine("\t#------------------------------------------------------------------");

            //////////////
            //Global NRC//
            //////////////

            write_globalNrc(read_odx);

            //End lines
            FileHandle.WriteLine("\t#------------------------------------------------------------------");
            FileHandle.WriteLine("}; # end of DIAG mapping \n1;");
            FileHandle.Close();
        }

        //////////////
        //Global NRC//
        //////////////

        public void write_globalNrc(Read_ODX_File read_odx)
        {
            FileHandle.WriteLine("\t\"GlobalNRC\" => \n\t{ ");

            foreach (DataRow grow in read_odx.Global_NRC.Rows)
            {
                FileHandle.WriteLine("\t\t\"" + grow.ItemArray[0] + "\" => \"" + grow.ItemArray[1] + "\",");
            }
            FileHandle.WriteLine("\t}, #end of Global NRC");
        }

        //////////////////////
        //Request & Response//
        //////////////////////

        public void write_request_response(Read_ODX_File read_odx)
        {
            FileHandle.WriteLine("\t\"Requests_Responses\" => \n\t{ ");

            foreach (DataRow row in read_odx.diag_table.Rows)
            {
                List<string> listVal = new List<string>();
                if (read_odx.odx_dic.ContainsKey(row.ItemArray[2].ToString()))
                {
                    listVal = read_odx.odx_dic[row.ItemArray[2].ToString()];
                }
                foreach (string val in listVal)
                {
                    string[] value = val.Split('@');
                    string id_val;
                    string res_id;

                    if (value.Length > 1)
                    {
                        id_val = row.ItemArray[1] + " " + value[1].Trim();
                        res_id = row.ItemArray[3] + " " + value[1].Trim();
                    }
                    else
                    {
                        id_val = row.ItemArray[1].ToString();
                        res_id = row.ItemArray[3].ToString();
                    }
                    string int_val = value[0];

                    if(!row.ItemArray[5].Equals("undef"))
                    {
                        DataRow dr = dst.NewRow();
                        string full = row.ItemArray[0] + "_" + value[0];
                        string[] temp = full.Split(new char[] { '_' }, 2);
                        dr[0] = temp[0];
                        dr[1] = temp[1];
                        dr[2] = id_val;
                        dr[3] = row.ItemArray[5];
                        dst.Rows.Add(dr);
                    }
                    
                    FileHandle.WriteLine("\t\t\"" + row.ItemArray[0].ToString().Replace(" ", "") + "_" + value[0].Replace(" ", "") + "\" =>\n\t\t{");
                    FileHandle.WriteLine("\t\t\t\"Requests\" => {");
                    FileHandle.WriteLine("\t\t\t\"REQ_" + row.ItemArray[0].ToString().Replace(" ","") + "_" + value[0].Replace(" ","") + "\" => { \"Request\" => \"" + id_val + "\" },\n\t\t\t\t},");
                    FileHandle.WriteLine("\t\t\t\"POS_Responses\" => {");
                    FileHandle.WriteLine("\t\t\t\"RESP_" + row.ItemArray[0].ToString().Replace(" ", "") + "_" + value[0].Replace(" ", "") + "\" => { \"Responses\" => \"" + res_id + "\" , \"Mode\" => \"relax\" , \"Desc\" => \"" + row.ItemArray[0] + " : " + value[0] + "\" \"DoorsIDs\" => [ \"\" ]},\n\t\t\t\t},");
                    FileHandle.Write("\t\t\t\"allowed_in_sessions\" => [");

                    string[] session_types = row.ItemArray[6].ToString().Split(' ');
                    int index = 1;

                    while (index < session_types.Count() - 1)
                    {
                        FileHandle.Write("\"" + session_types[index] + "\" , ");
                        index++;
                    }

                    FileHandle.Write("\"" + session_types[session_types.Count() - 1] + "\" ");
                    FileHandle.WriteLine("],");
                    FileHandle.WriteLine("\t\t},");
                    FileHandle.WriteLine("\t\t#------------------------------------------------------------------");
                }
            }
            FileHandle.WriteLine("\t},");

            FileHandle.WriteLine("\t#***************************#");
        }
        
        /////////////////
        //Diag_services//
        /////////////////

        public void write_diagServices(Read_ODX_File read_odx)
        {
            int i = 0;

            FileHandle.WriteLine("\t\"DIAG_SERVICES\" => \n\t{ ");

            while (i < dst.Rows.Count - 1)
            {
                string service = dst.Rows[i].ItemArray[0].ToString();
                List<string> sub_service = new List<string>();
               
                string[] service_ids = dst.Rows[i].ItemArray[2].ToString().Split(new char[] {' '},2);

                string id = service_ids[0];
                if (service_ids.Count() <= 1 || service_ids[1] == null)
                {
                    sub_service.Add("\"" + "undef" + "_" + dst.Rows[i].ItemArray[1].ToString().Replace(" ", "") + "\"   => \"" + "undef" + "\"");
                }
                else
                {
                    sub_service.Add("\"" + service_ids[1].Replace(" ", "") + "_" + dst.Rows[i].ItemArray[1].ToString().Replace(" ", "") + "\"   => \"" + service_ids[1] + "\"");
                }

                while (dst.Rows[i].ItemArray[3].Equals(dst.Rows[i + 1].ItemArray[3]))
                {
                    string[] ids = dst.Rows[i+1].ItemArray[2].ToString().Split(new char[] { ' ' }, 2);
                    if (ids.Count() <= 1 || ids[1] == null)
                    {
                        sub_service.Add("\"" + "undef" + "_" + dst.Rows[i + 1].ItemArray[1].ToString().Replace(" ", "") + "\"   => \"" + "undef" + "\"");
                    }
                    else
                    {
                        sub_service.Add("\"" + ids[1].Replace(" ", "") + "_" + dst.Rows[i + 1].ItemArray[1].ToString().Replace(" ", "") + "\"   => \"" + ids[1] + "\"");
                    }
                    i++;
                    if (i == dst.Rows.Count - 1)
                    {
                        break;
                    }
                }
                FileHandle.WriteLine("\t\t\"" + service.Replace(" ","") + "\" => \n\t\t{");
                FileHandle.WriteLine("\t\t\t\"Service_ID\" => \"" + id + "\" ,");

                FileHandle.WriteLine("\t\t\t\"Supported_SubFuns\" => \n\t\t\t{");
                foreach (string a in sub_service)
                {
                    FileHandle.WriteLine("\t\t\t\t" + a + ",");
                }
                FileHandle.WriteLine("\t\t\t},");
                FileHandle.WriteLine("\t\t\t\"NEG_Responses\" => \n\t\t\t{");

                List<string> Neg_val = new List<string>();
                if (read_odx.odx_dic.ContainsKey(dst.Rows[i].ItemArray[3].ToString()))
                {
                    Neg_val = read_odx.odx_dic[dst.Rows[i].ItemArray[3].ToString()];
                }
                foreach (string val in Neg_val)
                {
                    string[] value = val.Split('@');
                    string id_val;
                    string res_id;

                    if (value.Length > 1)
                    {
                        id_val = "7F" + " " + value[1].Trim();
                        res_id = "NR_" + value[0];
                    }
                    else
                    {
                        id_val = "7F";
                        res_id = "NR_" + value[0];
                    }

                    FileHandle.WriteLine("\t\t\t\t\"" + res_id + "\"  =>  { \"Response\" => \"" + id_val + "\" , \"Mode\" => \"relax\" , \"Desc\" => \"" + service + " : " + value[0] + "\" , \"AddrModes\" => [\"Physical\",\"Functional\"]},");
                }
                FileHandle.WriteLine("\t\t\t},");
                FileHandle.WriteLine("\t\t},");
                FileHandle.WriteLine("\t\t#------------------------------------------------------------------");
                i++;
            }   
            FileHandle.WriteLine("\t}, #end of DIAG_SERVICES");
            FileHandle.WriteLine("\t#***************************#");
            if(flag == 0)
            MessageBox.Show("DiagMapping File Created Successfully", "GDCOM-Configurator");
        }

    }
}

