﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GDCOM_Configurator
{
    class Constants
    {
        public static readonly string sevenZip = System.Windows.Forms.Application.StartupPath + @"\doc\7z.exe";
    }
}
