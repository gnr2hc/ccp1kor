﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.IO.Compression;

namespace GDCOM_Configurator
{
    class Unzip
    {              
        //This function extract a specified file of a specified zip file to a specified folder 
        public string extractFileFromZip(string source, string destination)
        {
            if (Directory.Exists(destination))
            {
                FolderBrowserDialog folderDlg = new FolderBrowserDialog();
                folderDlg.Description = "ODX Folder Already Exists. Please select new folder to Unzip";
                if (folderDlg.ShowDialog() == DialogResult.OK)
                {
                    destination = folderDlg.SelectedPath;
                    using (ZipArchive archive = ZipFile.OpenRead(source))
                    {
                        foreach (ZipArchiveEntry entry in archive.Entries)
                        {

                            entry.ExtractToFile(Path.Combine(destination, entry.FullName), true);

                        }
                    } 
                    return destination;
                }
                else
                {
                    return "null";
                }
                
            }
            else
            {
                System.IO.Directory.CreateDirectory(destination);               
                ZipFile.ExtractToDirectory(source, destination);
                return destination;
            }
            
        }  
    }
}
