using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace GDCOM_Configurator
{
    class unzip_pdx
    {
        
        //This function extract a specified file of a specified zip file to a specified folder 
      
        public static string extractFileFromZip(string fileName, FileInfo zipFile, DirectoryInfo directory)
        {
            //string param = " e \"" + zipFile.FullName + "\" " + fileName + " -o\"" + directory.FullName ;
            string param = "a -tgzip \"" + zipFile.FullName + "\" \"" + fileName + "\" -mx=9";

            ProcessExecutor processExecutor = new ProcessExecutor("\"" + Constants.sevenZip + "\"", param);
            Thread processThread = new Thread(processExecutor.startProcess);
            processThread.Start();

            //Waiting for the unzip to be finished
            while (processThread.ThreadState != ThreadState.Stopped)
            {
                Application.DoEvents();
                Thread.Sleep(50);
            }

            string file =  directory.FullName + "\\" + fileName;
            return file;
        }
       
       
    }
}
