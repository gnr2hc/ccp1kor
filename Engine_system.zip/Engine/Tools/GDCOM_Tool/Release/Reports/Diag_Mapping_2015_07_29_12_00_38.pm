package STEPS_DIAG_MAPPING; 
$Mapping = 
{ 
	"PRJ_SUPPORTED_SERVICES" => 
	{ 
		"RequestCurrentPowertrainDiagnosticData" => "1",
		"DiagnosticSessionControl" => "10",
		"ECUReset" => "11",
		"ClearDiagnosticInformation" => "14",
		"ReadDTCInformation" => "19",
		"ReadDataByIdentifier" => "22",
		"ReadMemoryByAddress" => "23",
		"SecurityAccess" => "27",
		"CommunicationControl" => "28",
		"WriteDataByIdentifier" => "2E",
		"InputOutputControlByIdentifier" => "2F",
		"RoutineControl" => "31",
		"RequestDownload" => "34",
		"RequestUpload" => "35",
		"TransferData" => "36",
		"RequestTransferExit" => "37",
		"WriteMemoryByAddress" => "3D",
		"TesterPresent" => "3E",
		"Clear" => "4",
		"ControlDTCSetting" => "85",
	},
	#***************************#
	"NR_ServiceNotSupported" => 
	{ 
		"Response" => "7F",
		"Mode" => "relax",
		"Desc" => "Service not supported",
	},
	#***************************#
	"Requests_Responses" => 
	{ 
		"RequestCurrentPowertrainDiagnosticData_PID$01" =>
		{
			"Requests" => {
			"REQ_RequestCurrentPowertrainDiagnosticData_PID$01" => { "Request" => "1 01" },
				},
			"POS_Responses" => {
			"RESP_RequestCurrentPowertrainDiagnosticData_PID$01" => { "Responses" => "41 01" , "Mode" => "relax" , "Desc" => "Request Current Powertrain Diagnostic Data : PID$01" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["OBDIIAndVWDefaultSession" , "DevelopmentSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_OBDIIAndVWDefaultDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_OBDIIAndVWDefaultDiagnosticSession" => { "Request" => "10 01" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_OBDIIAndVWDefaultDiagnosticSession" => { "Responses" => "50 01" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : OBDII And VW Default Diagnostic Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControlFUNCTIONAL_OBDIIAndVWDefaultDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControlFUNCTIONAL_OBDIIAndVWDefaultDiagnosticSession" => { "Request" => "10 01" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControlFUNCTIONAL_OBDIIAndVWDefaultDiagnosticSession" => { "Responses" => "50 01" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control FUNCTIONAL : OBDII And VW Default Diagnostic Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["OBDIIAndVWDefaultSession" , "ExtendedSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_DevelopmentSession_DevelopmentSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_DevelopmentSession_DevelopmentSession" => { "Request" => "10 4F" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_DevelopmentSession_DevelopmentSession" => { "Responses" => "50 4F" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control _ Development Session : Development Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_ECUProgrammingSession_ProgrammingSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_ECUProgrammingSession_ProgrammingSession" => { "Request" => "10 02" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_ECUProgrammingSession_ProgrammingSession" => { "Responses" => "50 02" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control _ ECU Programming Session : Programming Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ExtendedSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_ExtendedSession_ExtendedDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_ExtendedSession_ExtendedDiagnosticSession" => { "Request" => "10 03" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_ExtendedSession_ExtendedDiagnosticSession" => { "Responses" => "50 03" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control _ Extended Session : Extended Diagnostic Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_OBDIIAndVWDefaultSession_OBDIIAndVWDefaultDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_OBDIIAndVWDefaultSession_OBDIIAndVWDefaultDiagnosticSession" => { "Request" => "10 01" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_OBDIIAndVWDefaultSession_OBDIIAndVWDefaultDiagnosticSession" => { "Responses" => "50 01" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control _ OBDII And VW Default Session : OBDII And VW Default Diagnostic Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"DiagnosticSessionControl_VWEndOfLineSession_VWEndOfLine(EoL)-Session" =>
		{
			"Requests" => {
			"REQ_DiagnosticSessionControl_VWEndOfLineSession_VWEndOfLine(EoL)-Session" => { "Request" => "10 40" },
				},
			"POS_Responses" => {
			"RESP_DiagnosticSessionControl_VWEndOfLineSession_VWEndOfLine(EoL)-Session" => { "Responses" => "50 40" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control _ VW End Of Line Session : VW End Of Line (EoL)-Session" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" ],
		},
		#------------------------------------------------------------------
		"ECUReset_HardReset_HardReset" =>
		{
			"Requests" => {
			"REQ_ECUReset_HardReset_HardReset" => { "Request" => "11 01" },
				},
			"POS_Responses" => {
			"RESP_ECUReset_HardReset_HardReset" => { "Responses" => "51 01" , "Mode" => "relax" , "Desc" => "ECU Reset _ Hard Reset : Hard Reset" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ECUReset_KeyOffOnReset_KeyOffOnReset" =>
		{
			"Requests" => {
			"REQ_ECUReset_KeyOffOnReset_KeyOffOnReset" => { "Request" => "11 02" },
				},
			"POS_Responses" => {
			"RESP_ECUReset_KeyOffOnReset_KeyOffOnReset" => { "Responses" => "51 02" , "Mode" => "relax" , "Desc" => "ECU Reset _ Key Off On Reset : Key Off On Reset" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ECUReset_SoftReset_SoftReset" =>
		{
			"Requests" => {
			"REQ_ECUReset_SoftReset_SoftReset" => { "Request" => "11 03" },
				},
			"POS_Responses" => {
			"RESP_ECUReset_SoftReset_SoftReset" => { "Responses" => "51 03" , "Mode" => "relax" , "Desc" => "ECU Reset _ Soft Reset : Soft Reset" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_ReportDTCByStatusMask" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_ReportDTCByStatusMask" => { "Request" => "19 02" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_ReportDTCByStatusMask" => { "Responses" => "59 02" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Report DTC By Status Mask" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_WarningIndicatorOff" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_WarningIndicatorOff" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_WarningIndicatorOff" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Warning Indicator Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedThisMonitoringCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedThisMonitoringCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedThisMonitoringCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Test Completed This Monitoring Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Test Not Failed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_TestCompletedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Test Completed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_NotConfirmedDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_NotConfirmedDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_NotConfirmedDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Not Confirmed DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_NotPendingDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_NotPendingDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_NotPendingDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Not Pending DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedThisOperationCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedThisOperationCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_TestNotFailedThisOperationCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : Test Not Failed This Operation Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveStatus_active" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveStatus_active" => { "Request" => "19 01" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveStatus_active" => { "Responses" => "59 01" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Status : active" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_ReportDTCByStatusMask" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_ReportDTCByStatusMask" => { "Request" => "19 02" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_ReportDTCByStatusMask" => { "Responses" => "59 02" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Report DTC By Status Mask" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_WarningIndicatorOff" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_WarningIndicatorOff" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_WarningIndicatorOff" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Warning Indicator Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestCompletedThisMonitoringCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestCompletedThisMonitoringCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestCompletedThisMonitoringCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Test Completed This Monitoring Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Test Not Failed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotCompletedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotCompletedSinceLastClear" => { "Request" => "19 01" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotCompletedSinceLastClear" => { "Responses" => "59 01" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Test Not Completed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotConfirmedDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotConfirmedDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotConfirmedDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Not Confirmed DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotPendingDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotPendingDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_NotPendingDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Not Pending DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedThisOperationCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedThisOperationCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedThisOperationCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : Test Not Failed This Operation Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_passive" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_passive" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByActiveTestNotCompletedStatus_passive" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Active Test Not Completed Status : passive" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ReportDTCByStatusMask" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ReportDTCByStatusMask" => { "Request" => "19 02" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ReportDTCByStatusMask" => { "Responses" => "59 02" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Report DTC By Status Mask" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_WarningIndicatorOff" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_WarningIndicatorOff" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_WarningIndicatorOff" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Warning Indicator Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedThisMonitoringCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedThisMonitoringCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedThisMonitoringCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Test Completed This Monitoring Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Test Not Failed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestCompletedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Test Completed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ConfirmedDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ConfirmedDTC" => { "Request" => "19 01" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_ConfirmedDTC" => { "Responses" => "59 01" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Confirmed DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_PendingDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_PendingDTC" => { "Request" => "19 01" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_PendingDTC" => { "Responses" => "59 01" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Pending DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedThisOperationCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedThisOperationCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_TestNotFailedThisOperationCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : Test Not Failed This Operation Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_passive" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_passive" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByConfirmedAndPendingStatus_passive" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Confirmed And Pending Status : passive" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_ReportDTCByStatusMask" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_ReportDTCByStatusMask" => { "Request" => "19 02" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_ReportDTCByStatusMask" => { "Responses" => "59 02" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Report DTC By Status Mask" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_WarningIndicatorOff" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_WarningIndicatorOff" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_WarningIndicatorOff" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Warning Indicator Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_TestCompletedThisMonitoringCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_TestCompletedThisMonitoringCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_TestCompletedThisMonitoringCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Test Completed This Monitoring Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Test Not Failed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_TestCompletedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_TestCompletedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_TestCompletedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Test Completed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_NotConfirmedDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_NotConfirmedDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_NotConfirmedDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Not Confirmed DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_NotPendingDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_NotPendingDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_NotPendingDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Not Pending DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedThisOperationCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedThisOperationCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_TestNotFailedThisOperationCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : Test Not Failed This Operation Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCByStatusMask_passive" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCByStatusMask_passive" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCByStatusMask_passive" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC By Status Mask : passive" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_ReportDTCExtendedDataRecordByDTCNumber" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_ReportDTCExtendedDataRecordByDTCNumber" => { "Request" => "19 06" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_ReportDTCExtendedDataRecordByDTCNumber" => { "Responses" => "59 06" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC Extended Data Record By DTC Number : Report DTC Extended Data Record By DTC Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_AllDTCExtendedDataRecordNumbers" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_AllDTCExtendedDataRecordNumbers" => { "Request" => "19 FF" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportDTCExtendedDataRecordByDTCNumber_AllDTCExtendedDataRecordNumbers" => { "Responses" => "59 FF" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report DTC Extended Data Record By DTC Number : All DTC Extended Data Record Numbers" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_ReportEmissionsRelatedOBDDTCByStatusMask" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_ReportEmissionsRelatedOBDDTCByStatusMask" => { "Request" => "19 13" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_ReportEmissionsRelatedOBDDTCByStatusMask" => { "Responses" => "59 13" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Report Emissions Related OBD DTC By Status Mask" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_WarningIndicatorOff" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_WarningIndicatorOff" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_WarningIndicatorOff" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Warning Indicator Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedThisMonitoringCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedThisMonitoringCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedThisMonitoringCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Test Completed This Monitoring Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Test Completed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedSinceLastClear" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedSinceLastClear" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedSinceLastClear" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Test Not Failed Since Last Clear" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotConfirmedDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotConfirmedDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotConfirmedDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Not Confirmed DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotPendingDTC" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotPendingDTC" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_NotPendingDTC" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Not Pending DTC" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedThisOperationCycle" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedThisOperationCycle" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedThisOperationCycle" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : Test Not Failed This Operation Cycle" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_passive" =>
		{
			"Requests" => {
			"REQ_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_passive" => { "Request" => "19 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDTCInformation_ReportEmissionRelatedOBDDTCByStatusMask_passive" => { "Responses" => "59 00" , "Mode" => "relax" , "Desc" => "Read DTC Information _ Report Emission Related OBD DTC By Status Mask : passive" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Request" => "22 01 03" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Responses" => "62 01 03" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : InvalidKeyCounter" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Request" => "22 01 10" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Responses" => "62 01 10" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : CANCommunicationStatus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Request" => "22 01 11" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Responses" => "62 01 11" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : EMCTimeoutDetection" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Request" => "22 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Responses" => "62 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value Basic Settings : DummyMeasurementValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Request" => "22 04 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Responses" => "62 04 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Calibration Data : VWCommonApplicationDataIdentifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Request" => "22 01 03" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Responses" => "62 01 03" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : InvalidKeyCounter" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Request" => "22 01 10" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Responses" => "62 01 10" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : CANCommunicationStatus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Request" => "22 01 11" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Responses" => "62 01 11" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : EMCTimeoutDetection" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Request" => "22 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Responses" => "62 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value Basic Settings : DummyMeasurementValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Request" => "22 04 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Responses" => "62 04 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Calibration Data : VWCommonApplicationDataIdentifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" => { "Request" => "22 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" => { "Responses" => "62 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value Actuator Test : DummyMeasurementValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" => { "Request" => "22 04 05" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" => { "Responses" => "62 04 05" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : StateOfFlashMemory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" => { "Request" => "22 04 07" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" => { "Responses" => "62 04 07" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockCounterOfProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" => { "Request" => "22 04 08" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" => { "Responses" => "62 04 08" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" => { "Request" => "22 04 09" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" => { "Responses" => "62 04 09" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataCounterOfProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" => { "Request" => "22 04 0A" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" => { "Responses" => "62 04 0A" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataCounterOfSuccessfulProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" => { "Request" => "22 04 0F" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" => { "Responses" => "62 04 0F" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockLockValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" => { "Request" => "22 06 06" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" => { "Responses" => "62 06 06" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : IdentifiedSlaveSystems" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" => { "Request" => "22 07 60" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" => { "Responses" => "62 07 60" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLINIdentificationTable(Slave-Class0)" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" => { "Request" => "22 F1 5B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" => { "Responses" => "62 F1 5B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCodingDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCodingDate" => { "Request" => "22 F1 7B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCodingDate" => { "Responses" => "62 F1 7B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCodingDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" => { "Request" => "22 F1 7C" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" => { "Responses" => "62 F1 7C" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWFAZITIdentificationString" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" => { "Request" => "22 F1 7E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" => { "Responses" => "62 F1 7E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUProductionChangeNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" => { "Request" => "22 F1 81" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" => { "Responses" => "62 F1 81" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWStandardApplicationSoftwareIdentification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" => { "Request" => "22 F1 82" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" => { "Responses" => "62 F1 82" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWApplicationDataIdentification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" => { "Request" => "22 F1 86" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" => { "Responses" => "62 F1 86" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ActiveDiagnosticSession" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" => { "Request" => "22 F1 87" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" => { "Responses" => "62 F1 87" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWSparePartNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" => { "Request" => "22 F1 89" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" => { "Responses" => "62 F1 89" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWApplicationSoftwareVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" => { "Request" => "22 F1 8C" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" => { "Responses" => "62 F1 8C" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" => { "Request" => "22 F1 90" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" => { "Responses" => "62 F1 90" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VehicleIdentificationNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" => { "Request" => "22 F1 91" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" => { "Responses" => "62 F1 91" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWECUHardwareNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" => { "Request" => "22 F1 97" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" => { "Responses" => "62 F1 97" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWSystemNameOrEngineType" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 9A" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 9A" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCalibrationRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" => { "Request" => "22 F1 9B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" => { "Responses" => "62 F1 9B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCalibrationDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" => { "Request" => "22 F1 9E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" => { "Responses" => "62 F1 9E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ASAMODXFileIdentifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" => { "Request" => "22 F1 A0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" => { "Responses" => "62 F1 A0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetNumberOrECUDataContainerNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" => { "Request" => "22 F1 A1" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" => { "Responses" => "62 F1 A1" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" => { "Request" => "22 F1 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" => { "Responses" => "62 F1 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ASAMODXFileVersion" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" => { "Request" => "22 F1 A3" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" => { "Responses" => "62 F1 A3" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWECUHardwareVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" => { "Request" => "22 F1 A4" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" => { "Responses" => "62 F1 A4" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VehicleEquipmentCodeAndPRNumberCombination" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 A5" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 A5" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCodingRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 A8" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 A8" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" => { "Request" => "22 F1 A9" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" => { "Responses" => "62 F1 A9" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetProgrammingDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" => { "Request" => "22 F1 AA" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" => { "Responses" => "62 F1 AA" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWWorkshopSystemName" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" => { "Request" => "22 F1 AB" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" => { "Responses" => "62 F1 AB" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockVersion" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" => { "Request" => "22 F1 AC" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" => { "Responses" => "62 F1 AC" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWEOLConfiguration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_NumberOfLogins" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_NumberOfLogins" => { "Request" => "22 F1 AE" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_NumberOfLogins" => { "Responses" => "62 F1 AE" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : NumberOfLogins" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" => { "Request" => "22 F1 AF" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" => { "Responses" => "62 F1 AF" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : AUTOSAR_standard_application_software_identification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_FDS_project_data" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_FDS_project_data" => { "Request" => "22 F1 D5" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_FDS_project_data" => { "Responses" => "62 F1 D5" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : FDS_project_data" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" => { "Request" => "22 F1 DF" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" => { "Responses" => "62 F1 DF" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUProgrammingInformation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" => { "Request" => "22 F1 E0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" => { "Responses" => "62 F1 E0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUDataProgrammingInformation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" => { "Request" => "22 F1 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" => { "Responses" => "62 F1 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ASAM ODX File Version : ASAM ODX File Version" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" => { "Request" => "22 F1 87" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" => { "Responses" => "62 F1 87" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Spare Part Number : VW Spare Part Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" => { "Request" => "22 F1 9E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" => { "Responses" => "62 F1 9E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ASAM ODX File Identifier : ASAM ODX File Identifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" => { "Request" => "22 F1 A3" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" => { "Responses" => "62 F1 A3" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW ECU Hardware Version Number : VW ECU Hardware Version Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" => { "Request" => "22 F1 AB" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" => { "Responses" => "62 F1 AB" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Logical Software Block Version : VW Logical Software Block Version" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" => { "Request" => "22 F1 89" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" => { "Responses" => "62 F1 89" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Application Software Version Number : VW Application Software Version Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" => { "Request" => "22 F1 91" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" => { "Responses" => "62 F1 91" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW ECU Hardware Number : VW ECU Hardware Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" => { "Request" => "22 F1 9E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ASAMODXFileIdentifier_ASAMODXFileIdentifier" => { "Responses" => "62 F1 9E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ASAM ODX File Identifier : ASAM ODX File Identifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" => { "Request" => "22 F1 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ASAMODXFileVersion_ASAMODXFileVersion" => { "Responses" => "62 F1 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ASAM ODX File Version : ASAM ODX File Version" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Request" => "22 04 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_CalibrationData_VWCommonApplicationDataIdentifier" => { "Responses" => "62 04 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Calibration Data : VWCommonApplicationDataIdentifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" => { "Request" => "22 04 05" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_StateOfFlashMemory" => { "Responses" => "62 04 05" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : StateOfFlashMemory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" => { "Request" => "22 04 07" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts" => { "Responses" => "62 04 07" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockCounterOfProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" => { "Request" => "22 04 08" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" => { "Responses" => "62 04 08" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" => { "Request" => "22 04 09" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfProgrammingAttempts" => { "Responses" => "62 04 09" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataCounterOfProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" => { "Request" => "22 04 0A" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts" => { "Responses" => "62 04 0A" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataCounterOfSuccessfulProgrammingAttempts" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" => { "Request" => "22 04 0F" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockLockValue" => { "Responses" => "62 04 0F" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockLockValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" => { "Request" => "22 06 06" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_IdentifiedSlaveSystems" => { "Responses" => "62 06 06" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : IdentifiedSlaveSystems" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" => { "Request" => "22 07 60" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLINIdentificationTable(Slave-Class0)" => { "Responses" => "62 07 60" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLINIdentificationTable(Slave-Class0)" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" => { "Request" => "22 F1 5B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" => { "Responses" => "62 F1 5B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : FingerprintAndProgrammingDateOfLogicalSoftwareBlocks" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCodingDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCodingDate" => { "Request" => "22 F1 7B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCodingDate" => { "Responses" => "62 F1 7B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCodingDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" => { "Request" => "22 F1 7C" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWFAZITIdentificationString" => { "Responses" => "62 F1 7C" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWFAZITIdentificationString" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" => { "Request" => "22 F1 7E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUProductionChangeNumber" => { "Responses" => "62 F1 7E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUProductionChangeNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" => { "Request" => "22 F1 81" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWStandardApplicationSoftwareIdentification" => { "Responses" => "62 F1 81" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWStandardApplicationSoftwareIdentification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" => { "Request" => "22 F1 82" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWApplicationDataIdentification" => { "Responses" => "62 F1 82" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWApplicationDataIdentification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" => { "Request" => "22 F1 86" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ActiveDiagnosticSession" => { "Responses" => "62 F1 86" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ActiveDiagnosticSession" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" => { "Request" => "22 F1 87" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWSparePartNumber" => { "Responses" => "62 F1 87" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWSparePartNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" => { "Request" => "22 F1 89" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWApplicationSoftwareVersionNumber" => { "Responses" => "62 F1 89" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWApplicationSoftwareVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" => { "Request" => "22 F1 8C" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUSerialNumber" => { "Responses" => "62 F1 8C" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" => { "Request" => "22 F1 90" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VehicleIdentificationNumber" => { "Responses" => "62 F1 90" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VehicleIdentificationNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" => { "Request" => "22 F1 91" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWECUHardwareNumber" => { "Responses" => "62 F1 91" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWECUHardwareNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" => { "Request" => "22 F1 97" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWSystemNameOrEngineType" => { "Responses" => "62 F1 97" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWSystemNameOrEngineType" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 9A" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 9A" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCalibrationRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" => { "Request" => "22 F1 9B" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCalibrationDate" => { "Responses" => "62 F1 9B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCalibrationDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" => { "Request" => "22 F1 9E" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ASAMODXFileIdentifier" => { "Responses" => "62 F1 9E" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ASAMODXFileIdentifier" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" => { "Request" => "22 F1 A0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber" => { "Responses" => "62 F1 A0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetNumberOrECUDataContainerNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" => { "Request" => "22 F1 A1" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetVersionNumber" => { "Responses" => "62 F1 A1" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" => { "Request" => "22 F1 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ASAMODXFileVersion" => { "Responses" => "62 F1 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ASAMODXFileVersion" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" => { "Request" => "22 F1 A3" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWECUHardwareVersionNumber" => { "Responses" => "62 F1 A3" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWECUHardwareVersionNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" => { "Request" => "22 F1 A4" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination" => { "Responses" => "62 F1 A4" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VehicleEquipmentCodeAndPRNumberCombination" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 A5" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 A5" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWCodingRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" => { "Request" => "22 F1 A8" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber" => { "Responses" => "62 F1 A8" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetRepairShopCodeOrSerialNumber" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" => { "Request" => "22 F1 A9" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWDataSetProgrammingDate" => { "Responses" => "62 F1 A9" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWDataSetProgrammingDate" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" => { "Request" => "22 F1 AA" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWWorkshopSystemName" => { "Responses" => "62 F1 AA" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWWorkshopSystemName" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" => { "Request" => "22 F1 AB" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWLogicalSoftwareBlockVersion" => { "Responses" => "62 F1 AB" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWLogicalSoftwareBlockVersion" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" => { "Request" => "22 F1 AC" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_VWEOLConfiguration" => { "Responses" => "62 F1 AC" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : VWEOLConfiguration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_NumberOfLogins" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_NumberOfLogins" => { "Request" => "22 F1 AE" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_NumberOfLogins" => { "Responses" => "62 F1 AE" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : NumberOfLogins" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" => { "Request" => "22 F1 AF" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_AUTOSAR_standard_application_software_identification" => { "Responses" => "62 F1 AF" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : AUTOSAR_standard_application_software_identification" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_FDS_project_data" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_FDS_project_data" => { "Request" => "22 F1 D5" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_FDS_project_data" => { "Responses" => "62 F1 D5" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : FDS_project_data" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" => { "Request" => "22 F1 DF" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUProgrammingInformation" => { "Responses" => "62 F1 DF" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUProgrammingInformation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" => { "Request" => "22 F1 E0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_ECUIdentification_ECUDataProgrammingInformation" => { "Responses" => "62 F1 E0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ ECU Identification : ECUDataProgrammingInformation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_IdentifiedSlaveSystems_IdentifiedSlaveSystems" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_IdentifiedSlaveSystems_IdentifiedSlaveSystems" => { "Request" => "22 06 06" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_IdentifiedSlaveSystems_IdentifiedSlaveSystems" => { "Responses" => "62 06 06" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Identified Slave Systems : Identified Slave Systems" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Request" => "22 01 03" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_InvalidKeyCounter" => { "Responses" => "62 01 03" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : InvalidKeyCounter" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Request" => "22 01 10" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_CANCommunicationStatus" => { "Responses" => "62 01 10" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : CANCommunicationStatus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Request" => "22 01 11" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValue_EMCTimeoutDetection" => { "Responses" => "62 01 11" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value : EMCTimeoutDetection" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" => { "Request" => "22 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValueActuatorTest_DummyMeasurementValue" => { "Responses" => "62 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value Actuator Test : DummyMeasurementValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Request" => "22 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_MeasurementValueBasicSettings_DummyMeasurementValue" => { "Responses" => "62 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Measurement Value Basic Settings : DummyMeasurementValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_Immobilizer-Challenge" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_Immobilizer-Challenge" => { "Request" => "22 02 E0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_Immobilizer-Challenge" => { "Responses" => "62 02 E0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : Immobilizer-Challenge" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDcurrentKey" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDcurrentKey" => { "Request" => "22 02 E4" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDcurrentKey" => { "Responses" => "62 02 E4" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDcurrentKey" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey1" => { "Request" => "22 02 E5" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey1" => { "Responses" => "62 02 E5" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey2" => { "Request" => "22 02 E6" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey2" => { "Responses" => "62 02 E6" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey3" => { "Request" => "22 02 E7" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey3" => { "Responses" => "62 02 E7" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey4" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey4" => { "Request" => "22 02 E8" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey4" => { "Responses" => "62 02 E8" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey4" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey5" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey5" => { "Request" => "22 02 E9" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey5" => { "Responses" => "62 02 E9" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey5" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey6" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey6" => { "Request" => "22 02 EA" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey6" => { "Responses" => "62 02 EA" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey6" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey7" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey7" => { "Request" => "22 02 EB" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey7" => { "Responses" => "62 02 EB" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey7" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_TransponderIDKey8" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey8" => { "Request" => "22 02 EC" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_TransponderIDKey8" => { "Responses" => "62 02 EC" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : TransponderIDKey8" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_StateofImmobilizer" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_StateofImmobilizer" => { "Request" => "22 02 ED" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_StateofImmobilizer" => { "Responses" => "62 02 ED" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : StateofImmobilizer" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_StateofImmobilizerSlaves" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_StateofImmobilizerSlaves" => { "Request" => "22 02 EE" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_StateofImmobilizerSlaves" => { "Responses" => "62 02 EE" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : StateofImmobilizerSlaves" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_TheftProtectionData_StateBlockingTime" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_TheftProtectionData_StateBlockingTime" => { "Request" => "22 02 EF" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_TheftProtectionData_StateBlockingTime" => { "Responses" => "62 02 EF" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Theft Protection Data : StateBlockingTime" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VariantCoding_VWCodingValue" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VariantCoding_VWCodingValue" => { "Request" => "22 06 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VariantCoding_VWCodingValue" => { "Responses" => "62 06 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ Variant Coding : VWCodingValue" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" => { "Request" => "22 F1 89" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" => { "Responses" => "62 F1 89" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Application Software Version Number : VW Application Software Version Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" => { "Request" => "22 F1 91" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWECUHardwareNumber_VWECUHardwareNumber" => { "Responses" => "62 F1 91" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW ECU Hardware Number : VW ECU Hardware Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" => { "Request" => "22 F1 A3" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" => { "Responses" => "62 F1 A3" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW ECU Hardware Version Number : VW ECU Hardware Version Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" => { "Request" => "22 F1 AB" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion" => { "Responses" => "62 F1 AB" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Logical Software Block Version : VW Logical Software Block Version" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveCodingValue_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveCodingValue_Slave1" => { "Request" => "22 06 10" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveCodingValue_Slave1" => { "Responses" => "62 06 10" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Coding Value : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveCodingValue_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveCodingValue_Slave2" => { "Request" => "22 06 11" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveCodingValue_Slave2" => { "Responses" => "62 06 11" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Coding Value : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveCodingValue_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveCodingValue_Slave3" => { "Request" => "22 06 12" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveCodingValue_Slave3" => { "Responses" => "62 06 12" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Coding Value : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave1" => { "Request" => "22 07 A0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave1" => { "Responses" => "62 07 A0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave FAZIT Identification String : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave2" => { "Request" => "22 07 A1" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave2" => { "Responses" => "62 07 A1" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave FAZIT Identification String : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave3" => { "Request" => "22 07 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveFAZITIdentificationString_Slave3" => { "Responses" => "62 07 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave FAZIT Identification String : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareNumber_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave1" => { "Request" => "22 06 A0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave1" => { "Responses" => "62 06 A0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Number : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareNumber_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave2" => { "Request" => "22 06 A1" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave2" => { "Responses" => "62 06 A1" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Number : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareNumber_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave3" => { "Request" => "22 06 A2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareNumber_Slave3" => { "Responses" => "62 06 A2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Number : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave1" => { "Request" => "22 06 D0" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave1" => { "Responses" => "62 06 D0" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Version Number : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave2" => { "Request" => "22 06 D1" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave2" => { "Responses" => "62 06 D1" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Version Number : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave3" => { "Request" => "22 06 D2" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveHardwareVersionNumber_Slave3" => { "Responses" => "62 06 D2" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Hardware Version Number : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSerialNumber_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSerialNumber_Slave1" => { "Request" => "22 07 00" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSerialNumber_Slave1" => { "Responses" => "62 07 00" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Serial Number : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSerialNumber_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSerialNumber_Slave2" => { "Request" => "22 07 01" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSerialNumber_Slave2" => { "Responses" => "62 07 01" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Serial Number : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSerialNumber_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSerialNumber_Slave3" => { "Request" => "22 07 02" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSerialNumber_Slave3" => { "Responses" => "62 07 02" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Serial Number : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave1" => { "Request" => "22 06 70" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave1" => { "Responses" => "62 06 70" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Software Version Number : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave2" => { "Request" => "22 06 71" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave2" => { "Responses" => "62 06 71" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Software Version Number : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave3" => { "Request" => "22 06 72" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSoftwareVersionNumber_Slave3" => { "Responses" => "62 06 72" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Software Version Number : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSparePartNumber_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave1" => { "Request" => "22 06 40" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave1" => { "Responses" => "62 06 40" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Spare Part Number : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSparePartNumber_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave2" => { "Request" => "22 06 41" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave2" => { "Responses" => "62 06 41" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Spare Part Number : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSparePartNumber_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave3" => { "Request" => "22 06 42" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSparePartNumber_Slave3" => { "Responses" => "62 06 42" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave Spare Part Number : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSystemName_Slave1" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSystemName_Slave1" => { "Request" => "22 07 30" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSystemName_Slave1" => { "Responses" => "62 07 30" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave System Name : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSystemName_Slave2" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSystemName_Slave2" => { "Request" => "22 07 31" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSystemName_Slave2" => { "Responses" => "62 07 31" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave System Name : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSlaveSystemName_Slave3" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSlaveSystemName_Slave3" => { "Request" => "22 07 32" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSlaveSystemName_Slave3" => { "Responses" => "62 07 32" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Slave System Name : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" =>
		{
			"Requests" => {
			"REQ_ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" => { "Request" => "22 F1 87" },
				},
			"POS_Responses" => {
			"RESP_ReadDataByIdentifier_VWSparePartNumber_VWSparePartNumber" => { "Responses" => "62 F1 87" , "Mode" => "relax" , "Desc" => "Read Data By Identifier _ VW Spare Part Number : VW Spare Part Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeed_RequestSeedLogin" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeed_RequestSeedLogin" => { "Request" => "27 03" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeed_RequestSeedLogin" => { "Responses" => "67 03" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed : RequestSeedLogin" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeed_RequestSeedSystemSpecific" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeed_RequestSeedSystemSpecific" => { "Request" => "27 09" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeed_RequestSeedSystemSpecific" => { "Responses" => "67 09" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed : RequestSeedSystemSpecific" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeed_RequestSeedBootloader" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeed_RequestSeedBootloader" => { "Request" => "27 11" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeed_RequestSeedBootloader" => { "Responses" => "67 11" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed : RequestSeedBootloader" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeed_RequestSeedAirbagDeployment" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeed_RequestSeedAirbagDeployment" => { "Request" => "27 5F" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeed_RequestSeedAirbagDeployment" => { "Responses" => "67 5F" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed : RequestSeedAirbagDeployment" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKey_SendKeyLogin" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKey_SendKeyLogin" => { "Request" => "27 04" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKey_SendKeyLogin" => { "Responses" => "67 04" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key : SendKeyLogin" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKey_SendKeySystemSpecific" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKey_SendKeySystemSpecific" => { "Request" => "27 0A" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKey_SendKeySystemSpecific" => { "Responses" => "67 0A" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key : SendKeySystemSpecific" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKey_SendKeyBootloader" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKey_SendKeyBootloader" => { "Request" => "27 12" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKey_SendKeyBootloader" => { "Responses" => "67 12" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key : SendKeyBootloader" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKey_SendKeyAirbagDeployment" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKey_SendKeyAirbagDeployment" => { "Request" => "27 60" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKey_SendKeyAirbagDeployment" => { "Responses" => "67 60" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key : SendKeyAirbagDeployment" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeedLogin_RequestSeedLogin" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeedLogin_RequestSeedLogin" => { "Request" => "27 03" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeedLogin_RequestSeedLogin" => { "Responses" => "67 03" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed Login : Request Seed Login" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_RequestSeedSystemSpecific_RequestSeedSystemSpecific" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_RequestSeedSystemSpecific_RequestSeedSystemSpecific" => { "Request" => "27 09" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_RequestSeedSystemSpecific_RequestSeedSystemSpecific" => { "Responses" => "67 09" , "Mode" => "relax" , "Desc" => "Security Access _ Request Seed System Specific : Request Seed System Specific" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKeyLogin_SendKeyLogin" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKeyLogin_SendKeyLogin" => { "Request" => "27 04" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKeyLogin_SendKeyLogin" => { "Responses" => "67 04" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key Login : Send Key Login" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"SecurityAccess_SendKeySystemSpecific_SendKeySystemSpecific" =>
		{
			"Requests" => {
			"REQ_SecurityAccess_SendKeySystemSpecific_SendKeySystemSpecific" => { "Request" => "27 0A" },
				},
			"POS_Responses" => {
			"RESP_SecurityAccess_SendKeySystemSpecific_SendKeySystemSpecific" => { "Responses" => "67 0A" , "Mode" => "relax" , "Desc" => "Security Access _ Send Key System Specific : Send Key System Specific" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndTx" => { "Request" => "28 00" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndTx" => { "Responses" => "68 00" , "Mode" => "relax" , "Desc" => "Communication Control : EnableRxAndTx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndDisableTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndDisableTx" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndDisableTx" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control : EnableRxAndDisableTx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_DisableRxAndEnableTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_DisableRxAndEnableTx" => { "Request" => "28 02" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_DisableRxAndEnableTx" => { "Responses" => "68 02" , "Mode" => "relax" , "Desc" => "Communication Control : DisableRxAndEnableTx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_DisableRxAndTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_DisableRxAndTx" => { "Request" => "28 03" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_DisableRxAndTx" => { "Responses" => "68 03" , "Mode" => "relax" , "Desc" => "Communication Control : DisableRxAndTx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_AllNetworks" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_AllNetworks" => { "Request" => "28 00" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_AllNetworks" => { "Responses" => "68 00" , "Mode" => "relax" , "Desc" => "Communication Control : AllNetworks" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#1" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#1" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#1" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#2" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#2" => { "Request" => "28 02" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#2" => { "Responses" => "68 02" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#3" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#3" => { "Request" => "28 03" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#3" => { "Responses" => "68 03" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#4" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#4" => { "Request" => "28 04" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#4" => { "Responses" => "68 04" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#4" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#5" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#5" => { "Request" => "28 05" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#5" => { "Responses" => "68 05" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#5" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#6" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#6" => { "Request" => "28 06" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#6" => { "Responses" => "68 06" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#6" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#7" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#7" => { "Request" => "28 07" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#7" => { "Responses" => "68 07" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#7" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#8" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#8" => { "Request" => "28 08" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#8" => { "Responses" => "68 08" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#8" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#9" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#9" => { "Request" => "28 09" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#9" => { "Responses" => "68 09" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#9" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#10" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#10" => { "Request" => "28 0A" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#10" => { "Responses" => "68 0A" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#10" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#11" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#11" => { "Request" => "28 0B" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#11" => { "Responses" => "68 0B" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#11" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#12" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#12" => { "Request" => "28 0C" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#12" => { "Responses" => "68 0C" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#12" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#13" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#13" => { "Request" => "28 0D" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#13" => { "Responses" => "68 0D" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#13" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_SubNetwork#14" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_SubNetwork#14" => { "Request" => "28 0E" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_SubNetwork#14" => { "Responses" => "68 0E" , "Mode" => "relax" , "Desc" => "Communication Control : SubNetwork#14" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_MainNetwork" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_MainNetwork" => { "Request" => "28 0F" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_MainNetwork" => { "Responses" => "68 0F" , "Mode" => "relax" , "Desc" => "Communication Control : MainNetwork" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_NormalCommunicationMessages" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_NormalCommunicationMessages" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_NormalCommunicationMessages" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control : NormalCommunicationMessages" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_NetworkManagementCommunicationMessages" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_NetworkManagementCommunicationMessages" => { "Request" => "28 02" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_NetworkManagementCommunicationMessages" => { "Responses" => "68 02" , "Mode" => "relax" , "Desc" => "Communication Control : NetworkManagementCommunicationMessages" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_NormalAndNetworkManagementCommunicationMessages" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_NormalAndNetworkManagementCommunicationMessages" => { "Request" => "28 03" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_NormalAndNetworkManagementCommunicationMessages" => { "Responses" => "68 03" , "Mode" => "relax" , "Desc" => "Communication Control : NormalAndNetworkManagementCommunicationMessages" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_EnableRxAndDisableTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_EnableRxAndDisableTx" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_EnableRxAndDisableTx" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Disable Tx _ Normal Communication Messages : Enable Rx And Disable Tx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_AllNetworks" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_AllNetworks" => { "Request" => "28 00" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_AllNetworks" => { "Responses" => "68 00" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Disable Tx _ Normal Communication Messages : All Networks" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_NormalCommunicationMessages" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_NormalCommunicationMessages" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndDisableTx_NormalCommunicationMessages_NormalCommunicationMessages" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Disable Tx _ Normal Communication Messages : Normal Communication Messages" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_EnableRxAndTx" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_EnableRxAndTx" => { "Request" => "28 00" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_EnableRxAndTx" => { "Responses" => "68 00" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Tx _ Normal Communication Messages : Enable Rx And Tx" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_AllNetworks" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_AllNetworks" => { "Request" => "28 00" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_AllNetworks" => { "Responses" => "68 00" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Tx _ Normal Communication Messages : All Networks" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_NormalCommunicationMessages" =>
		{
			"Requests" => {
			"REQ_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_NormalCommunicationMessages" => { "Request" => "28 01" },
				},
			"POS_Responses" => {
			"RESP_CommunicationControl_EnableRxAndTx_NormalCommunicationMessages_NormalCommunicationMessages" => { "Responses" => "68 01" , "Mode" => "relax" , "Desc" => "Communication Control _ Enable Rx And Tx _ Normal Communication Messages : Normal Communication Messages" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Request" => "2E 11 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Responses" => "6E 11 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Anti-slip_regulation_(ASR)" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Request" => "2E 11 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Responses" => "6E 11 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronisches Stabilisierungsprogramm" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Request" => "2E 11 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Responses" => "6E 11 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Request" => "2E 05 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Responses" => "6E 05 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Kalibrierungsprotokoll XCP" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Request" => "2E 0E 0E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Responses" => "6E 0E 0E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Rollenprüfstandsmodus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Request" => "2E 0E 10" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Responses" => "6E 0E 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Geradeausbremsstabilisierung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Berganfahrassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Request" => "2E 0E 0D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Responses" => "6E 0E 0D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Berganfahrassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Request" => "2E 0E 1E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Responses" => "6E 0E 1E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Overboost im Bremssystem" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Request" => "2E 0E 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Responses" => "6E 0E 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hydraulischer Bremsassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Request" => "2E 0E 1C" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Responses" => "6E 0E 1C" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Erweiterte elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Request" => "2E 0E 1D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Responses" => "6E 0E 1D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hinterachsvollverzögerung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Request" => "2E 0E 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Responses" => "6E 0E 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Warnschwellen Reifenkontrollanzeige" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Request" => "2E 0E 26" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Responses" => "6E 0E 26" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Reifenkontrollanzeige Reifenauswahl" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_RKADatenlogging" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Request" => "2E 11 09" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Responses" => "6E 11 09" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : RKA Datenlogging" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Request" => "2E 0E 0A" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Responses" => "6E 0E 0A" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Motorschleppmomentregelung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_EvacAndFillByte" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Request" => "2E 05 FF" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Responses" => "6E 05 FF" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Evac And Fill Byte" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Request" => "2E 09 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Responses" => "6E 09 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Aktivieren und Deaktivieren aller Entwicklungsbotschaften" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Request" => "2E 11 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Responses" => "6E 11 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Anti-slip_regulation_(ASR)" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Request" => "2E 11 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Responses" => "6E 11 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronisches Stabilisierungsprogramm" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Request" => "2E 11 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Responses" => "6E 11 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Request" => "2E 05 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Responses" => "6E 05 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Kalibrierungsprotokoll XCP" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Request" => "2E 0E 0E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Responses" => "6E 0E 0E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Rollenprüfstandsmodus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Request" => "2E 0E 10" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Responses" => "6E 0E 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Geradeausbremsstabilisierung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Berganfahrassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Request" => "2E 0E 0D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Responses" => "6E 0E 0D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Berganfahrassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Request" => "2E 0E 1E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Responses" => "6E 0E 1E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Overboost im Bremssystem" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Request" => "2E 0E 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Responses" => "6E 0E 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hydraulischer Bremsassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Request" => "2E 0E 1C" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Responses" => "6E 0E 1C" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Erweiterte elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Request" => "2E 0E 1D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Responses" => "6E 0E 1D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hinterachsvollverzögerung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Request" => "2E 0E 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Responses" => "6E 0E 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Warnschwellen Reifenkontrollanzeige" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Request" => "2E 0E 26" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Responses" => "6E 0E 26" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Reifenkontrollanzeige Reifenauswahl" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_RKADatenlogging" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Request" => "2E 11 09" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Responses" => "6E 11 09" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : RKA Datenlogging" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Request" => "2E 0E 0A" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Responses" => "6E 0E 0A" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Motorschleppmomentregelung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_EvacAndFillByte" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Request" => "2E 05 FF" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Responses" => "6E 05 FF" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Evac And Fill Byte" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Request" => "2E 09 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Responses" => "6E 09 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Aktivieren und Deaktivieren aller Entwicklungsbotschaften" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Request" => "2E 11 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Anti-slip_regulation_(ASR)" => { "Responses" => "6E 11 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Anti-slip_regulation_(ASR)" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Request" => "2E 11 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischesStabilisierungsprogramm" => { "Responses" => "6E 11 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronisches Stabilisierungsprogramm" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Request" => "2E 11 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ElektronischeDifferenzialsperre" => { "Responses" => "6E 11 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Request" => "2E 05 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_KalibrierungsprotokollXCP" => { "Responses" => "6E 05 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Kalibrierungsprotokoll XCP" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Request" => "2E 0E 0E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Rollenprüfstandsmodus" => { "Responses" => "6E 0E 0E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Rollenprüfstandsmodus" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Request" => "2E 0E 10" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Geradeausbremsstabilisierung" => { "Responses" => "6E 0E 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Geradeausbremsstabilisierung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Berganfahrassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Request" => "2E 0E 0D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Berganfahrassistent" => { "Responses" => "6E 0E 0D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Berganfahrassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Request" => "2E 0E 1E" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_OverboostimBremssystem" => { "Responses" => "6E 0E 1E" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Overboost im Bremssystem" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Request" => "2E 0E 01" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_HydraulischerBremsassistent" => { "Responses" => "6E 0E 01" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hydraulischer Bremsassistent" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Request" => "2E 0E 1C" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ErweiterteelektronischeDifferenzialsperre" => { "Responses" => "6E 0E 1C" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Erweiterte elektronische Differenzialsperre" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Request" => "2E 0E 1D" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Hinterachsvollverzögerung" => { "Responses" => "6E 0E 1D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Hinterachsvollverzögerung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Request" => "2E 0E 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_WarnschwellenReifenkontrollanzeige" => { "Responses" => "6E 0E 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Warnschwellen Reifenkontrollanzeige" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Request" => "2E 0E 26" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_ReifenkontrollanzeigeReifenauswahl" => { "Responses" => "6E 0E 26" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Reifenkontrollanzeige Reifenauswahl" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_RKADatenlogging" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Request" => "2E 11 09" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_RKADatenlogging" => { "Responses" => "6E 11 09" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : RKA Datenlogging" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Request" => "2E 0E 0A" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_Motorschleppmomentregelung" => { "Responses" => "6E 0E 0A" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Motorschleppmomentregelung" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_EvacAndFillByte" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Request" => "2E 05 FF" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_EvacAndFillByte" => { "Responses" => "6E 05 FF" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Evac And Fill Byte" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Request" => "2E 09 02" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften" => { "Responses" => "6E 09 02" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Calibration Data : Aktivieren und Deaktivieren aller Entwicklungsbotschaften" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_ECUIdentification_BootloaderTPBlocksize" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_ECUIdentification_BootloaderTPBlocksize" => { "Request" => "2E 04 10" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_ECUIdentification_BootloaderTPBlocksize" => { "Responses" => "6E 04 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ ECU Identification : Bootloader TP Blocksize" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_ECUIdentification_Fingerprint" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_ECUIdentification_Fingerprint" => { "Request" => "2E F1 5A" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_ECUIdentification_Fingerprint" => { "Responses" => "6E F1 5A" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ ECU Identification : Fingerprint" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_ECUIdentification_ProgrammingDate" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_ECUIdentification_ProgrammingDate" => { "Request" => "2E F1 99" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_ECUIdentification_ProgrammingDate" => { "Responses" => "6E F1 99" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ ECU Identification : Programming Date" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_ECUIdentification_RepairShopCodeOrTesterSerialNumber" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_ECUIdentification_RepairShopCodeOrTesterSerialNumber" => { "Request" => "2E F1 98" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_ECUIdentification_RepairShopCodeOrTesterSerialNumber" => { "Responses" => "6E F1 98" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ ECU Identification : Repair Shop Code Or Tester Serial Number" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadIMS" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadIMS" => { "Request" => "2E 02 E3" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadIMS" => { "Responses" => "6E 02 E3" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Immobilizer - Download IMS" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadPowertrain" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadPowertrain" => { "Request" => "2E 02 E2" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadPowertrain" => { "Responses" => "6E 02 E2" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Immobilizer - Download Powertrain" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadWFS4" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadWFS4" => { "Request" => "2E 02 FB" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_Immobilizer-DownloadWFS4" => { "Responses" => "6E 02 FB" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Immobilizer - Download WFS 4" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_Immobilizer-Login" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_Immobilizer-Login" => { "Request" => "2E 02 E1" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_Immobilizer-Login" => { "Responses" => "6E 02 E1" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Immobilizer - Login" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_Immobilizer-SlaveLogin" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_Immobilizer-SlaveLogin" => { "Request" => "2E 02 F1" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_Immobilizer-SlaveLogin" => { "Responses" => "6E 02 F1" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Immobilizer - Slave Login" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadGFA-Key" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadGFA-Key" => { "Request" => "2E BD" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadGFA-Key" => { "Responses" => "6E BD" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Theft Protection - Download GFA-Key" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadIKA-Key" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadIKA-Key" => { "Request" => "2E BE" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_TheftProtectionData_TheftProtection-DownloadIKA-Key" => { "Responses" => "6E BE" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Theft Protection Data : Theft Protection - Download IKA-Key" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_VariantCoding_VWCodingValue" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_VariantCoding_VWCodingValue" => { "Request" => "2E 06 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_VariantCoding_VWCodingValue" => { "Responses" => "6E 06 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Variant Coding : VW Coding Value" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_VariantCodingTextual_VWCodingValue" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_VariantCodingTextual_VWCodingValue" => { "Request" => "2E 06 00" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_VariantCodingTextual_VWCodingValue" => { "Responses" => "6E 06 00" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ Variant Coding Textual : VW Coding Value" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_VWSlaveCodingValue_Slave1" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_VWSlaveCodingValue_Slave1" => { "Request" => "2E 06 10" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_VWSlaveCodingValue_Slave1" => { "Responses" => "6E 06 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ VW Slave Coding Value : Slave1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_VWSlaveCodingValue_Slave2" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_VWSlaveCodingValue_Slave2" => { "Request" => "2E 06 11" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_VWSlaveCodingValue_Slave2" => { "Responses" => "6E 06 11" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ VW Slave Coding Value : Slave2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier_VWSlaveCodingValue_Slave3" =>
		{
			"Requests" => {
			"REQ_WriteDataByIdentifier_VWSlaveCodingValue_Slave3" => { "Request" => "2E 06 12" },
				},
			"POS_Responses" => {
			"RESP_WriteDataByIdentifier_VWSlaveCodingValue_Slave3" => { "Responses" => "6E 06 12" , "Mode" => "relax" , "Desc" => "Write Data By Identifier _ VW Slave Coding Value : Slave3" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Request" => "2F 02 58" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Responses" => "6F 02 58" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Request" => "2F 02 59" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Responses" => "6F 02 59" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Request" => "2F 02 5A" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Responses" => "6F 02 5A" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Request" => "2F 02 5B" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Responses" => "6F 02 5B" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Request" => "2F 02 5C" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Responses" => "6F 02 5C" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Request" => "2F 02 5D" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Responses" => "6F 02 5D" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Request" => "2F 02 5E" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Responses" => "6F 02 5E" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Request" => "2F 02 5F" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Responses" => "6F 02 5F" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Request" => "2F 02 60" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Responses" => "6F 02 60" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Request" => "2F 02 61" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Responses" => "6F 02 61" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Request" => "2F 02 62" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Responses" => "6F 02 62" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Request" => "2F 02 63" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Responses" => "6F 02 63" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Request" => "2F 02 64" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Responses" => "6F 02 64" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : ABS_return_flow_pump" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Request" => "2F 04 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Responses" => "6F 04 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Dynamic_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Request" => "2F 04 01" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Responses" => "6F 04 01" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Wheel_Speed_Sensor_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Request" => "2F 04 03" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Responses" => "6F 04 03" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Static_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Request" => "2F 02 58" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Responses" => "6F 02 58" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Request" => "2F 02 59" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Responses" => "6F 02 59" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Request" => "2F 02 5A" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Responses" => "6F 02 5A" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Request" => "2F 02 5B" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Responses" => "6F 02 5B" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Request" => "2F 02 5C" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Responses" => "6F 02 5C" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Request" => "2F 02 5D" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Responses" => "6F 02 5D" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Request" => "2F 02 5E" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Responses" => "6F 02 5E" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Request" => "2F 02 5F" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Responses" => "6F 02 5F" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Request" => "2F 02 60" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Responses" => "6F 02 60" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Request" => "2F 02 61" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Responses" => "6F 02 61" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Request" => "2F 02 62" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Responses" => "6F 02 62" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Request" => "2F 02 63" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Responses" => "6F 02 63" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Request" => "2F 02 64" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Responses" => "6F 02 64" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : ABS_return_flow_pump" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Request" => "2F 04 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Responses" => "6F 04 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Dynamic_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Request" => "2F 04 01" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Responses" => "6F 04 01" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Wheel_Speed_Sensor_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Request" => "2F 04 03" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Responses" => "6F 04 03" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Static_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_Reserved" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_Reserved" => { "Request" => "2F 01 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_Reserved" => { "Responses" => "6F 01 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Freeze Current State : Reserved" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_FreezeCurrentState" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_FreezeCurrentState" => { "Request" => "2F 02" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_FreezeCurrentState_FreezeCurrentState" => { "Responses" => "6F 02" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Freeze Current State : Freeze Current State" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_Reserved" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_Reserved" => { "Request" => "2F 01 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_Reserved" => { "Responses" => "6F 01 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Return Control To ECU : Reserved" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_ReturnControlToECU" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_ReturnControlToECU" => { "Request" => "2F 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ReturnControlToECU_ReturnControlToECU" => { "Responses" => "6F 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Return Control To ECU : Return Control To ECU" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Request" => "2F 02 58" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve" => { "Responses" => "6F 02 58" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Request" => "2F 02 59" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve" => { "Responses" => "6F 02 59" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Request" => "2F 02 5A" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve" => { "Responses" => "6F 02 5A" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Request" => "2F 02 5B" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve" => { "Responses" => "6F 02 5B" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Front_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Request" => "2F 02 5C" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve" => { "Responses" => "6F 02 5C" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Request" => "2F 02 5D" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve" => { "Responses" => "6F 02 5D" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_left_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Request" => "2F 02 5E" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve" => { "Responses" => "6F 02 5E" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_inlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Request" => "2F 02 5F" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve" => { "Responses" => "6F 02 5F" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Rear_right_ABS_outlet_valve" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Request" => "2F 02 60" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1" => { "Responses" => "6F 02 60" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Request" => "2F 02 61" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2" => { "Responses" => "6F 02 61" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Vehicle_stabilization_program_switch_valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Request" => "2F 02 62" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" => { "Responses" => "6F 02 62" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Request" => "2F 02 63" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" => { "Responses" => "6F 02 63" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Request" => "2F 02 64" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump" => { "Responses" => "6F 02 64" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : ABS_return_flow_pump" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Request" => "2F 04 00" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Dynamic_Test" => { "Responses" => "6F 04 00" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Dynamic_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Request" => "2F 04 01" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test" => { "Responses" => "6F 04 01" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Wheel_Speed_Sensor_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" =>
		{
			"Requests" => {
			"REQ_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Request" => "2F 04 03" },
				},
			"POS_Responses" => {
			"RESP_InputOutputControlByIdentifier_ActuatorTest_ShortTermAdjustment_Static_Test" => { "Responses" => "6F 04 03" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier _ Actuator Test _ Short Term Adjustment : Static_Test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Reset of Adaption Values" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Rollertestbench" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Rollertestbench" => { "Request" => "31 04 14" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Rollertestbench" => { "Responses" => "71 04 14" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Roller test bench" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_EvacAndFill" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_EvacAndFill" => { "Request" => "31 02 12" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_EvacAndFill" => { "Responses" => "71 02 12" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : EvacAndFill" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Emergencybrakesignaltest" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Request" => "31 04 15" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Responses" => "71 04 15" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Emergency brake signal test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_RepairBleed" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_RepairBleed" => { "Request" => "31 02 11" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_RepairBleed" => { "Responses" => "71 02 11" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Repair Bleed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Bleed_brakes" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Request" => "31 03 9E" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Responses" => "71 03 9E" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Bleed_brakes" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_InertialSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Request" => "31 04 09" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Responses" => "71 04 09" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Inertial Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Request" => "31 02 10" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Responses" => "71 02 10" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Steering Angle Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Request" => "31 03 AF" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Responses" => "71 03 AF" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Interchange_test_hydraulic_connections" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_PressureSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Request" => "31 04 0A" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Responses" => "71 04 0A" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Pressure Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ESPDeactivation" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Request" => "31 04 1B" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Responses" => "71 04 1B" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : ESP Deactivation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Request" => "31 03" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Responses" => "71 03" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : Request Routine Results" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : ResetofAdaptionValues" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Reset of Adaption Values" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Rollertestbench" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Rollertestbench" => { "Request" => "31 04 14" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Rollertestbench" => { "Responses" => "71 04 14" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Roller test bench" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_EvacAndFill" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_EvacAndFill" => { "Request" => "31 02 12" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_EvacAndFill" => { "Responses" => "71 02 12" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : EvacAndFill" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Emergencybrakesignaltest" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Request" => "31 04 15" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Responses" => "71 04 15" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Emergency brake signal test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_RepairBleed" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_RepairBleed" => { "Request" => "31 02 11" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_RepairBleed" => { "Responses" => "71 02 11" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Repair Bleed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Bleed_brakes" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Request" => "31 03 9E" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Responses" => "71 03 9E" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Bleed_brakes" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_InertialSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Request" => "31 04 09" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Responses" => "71 04 09" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Inertial Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Request" => "31 02 10" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Responses" => "71 02 10" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Steering Angle Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Request" => "31 03 AF" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Responses" => "71 03 AF" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Interchange_test_hydraulic_connections" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_PressureSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Request" => "31 04 0A" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Responses" => "71 04 0A" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Pressure Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ESPDeactivation" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Request" => "31 04 1B" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Responses" => "71 04 1B" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : ESP Deactivation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Request" => "31 03" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Responses" => "71 03" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : Request Routine Results" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : ResetofAdaptionValues" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckMemory_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckMemory_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckMemory_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Memory : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckMemory_CheckMemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckMemory_CheckMemory" => { "Request" => "31 02 02" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckMemory_CheckMemory" => { "Responses" => "71 02 02" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Memory : Check Memory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckMemory(MCD2.00.01)_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckMemory(MCD2.00.01)_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckMemory(MCD2.00.01)_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Memory (MCD 2.00.01) : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckMemory(MCD2.00.01)_CheckMemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckMemory(MCD2.00.01)_CheckMemory" => { "Request" => "31 02 02" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckMemory(MCD2.00.01)_CheckMemory" => { "Responses" => "71 02 02" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Memory (MCD 2.00.01) : Check Memory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckProgrammingDependencies_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckProgrammingDependencies_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckProgrammingDependencies_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Programming Dependencies : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckProgrammingDependencies_CheckProgrammingDependencies" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckProgrammingDependencies_CheckProgrammingDependencies" => { "Request" => "31 FF 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckProgrammingDependencies_CheckProgrammingDependencies" => { "Responses" => "71 FF 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Programming Dependencies : Check Programming Dependencies" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckProgrammingPreconditions_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckProgrammingPreconditions_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckProgrammingPreconditions_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Programming Preconditions : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_CheckProgrammingPreconditions_CheckProgrammingPreconditions" =>
		{
			"Requests" => {
			"REQ_RoutineControl_CheckProgrammingPreconditions_CheckProgrammingPreconditions" => { "Request" => "31 02 03" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_CheckProgrammingPreconditions_CheckProgrammingPreconditions" => { "Responses" => "71 02 03" , "Mode" => "relax" , "Desc" => "Routine Control _ Check Programming Preconditions : Check Programming Preconditions" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_EraseMemory_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_EraseMemory_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_EraseMemory_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Erase Memory : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_EraseMemory_EraseMemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_EraseMemory_EraseMemory" => { "Request" => "31 FF 00" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_EraseMemory_EraseMemory" => { "Responses" => "71 FF 00" , "Mode" => "relax" , "Desc" => "Routine Control _ Erase Memory : Erase Memory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_EraseMemory(MCD2.00.01)_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_EraseMemory(MCD2.00.01)_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_EraseMemory(MCD2.00.01)_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Erase Memory (MCD 2.00.01) : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_EraseMemory(MCD2.00.01)_EraseMemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_EraseMemory(MCD2.00.01)_EraseMemory" => { "Request" => "31 FF 00" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_EraseMemory(MCD2.00.01)_EraseMemory" => { "Responses" => "71 FF 00" , "Mode" => "relax" , "Desc" => "Routine Control _ Erase Memory (MCD 2.00.01) : Erase Memory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["ECUProgrammingSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Request" => "31 03" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_RequestRoutineResults" => { "Responses" => "71 03" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : Request Routine Results" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_BasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Basic Setting : ResetofAdaptionValues" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartRoutine_DataSet_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartRoutine_DataSet_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartRoutine_DataSet_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Routine _ Data Set : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartRoutine_DataSet_Calculatechecksum" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartRoutine_DataSet_Calculatechecksum" => { "Request" => "31 02 EF" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartRoutine_DataSet_Calculatechecksum" => { "Responses" => "71 02 EF" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Routine _ Data Set : Calculatechecksum" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartRoutine_DataSet_EraseVWmemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartRoutine_DataSet_EraseVWmemory" => { "Request" => "31 03 00" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartRoutine_DataSet_EraseVWmemory" => { "Responses" => "71 03 00" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Routine _ Data Set : EraseVWmemory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_DataSet_RequestRoutineResults" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_DataSet_RequestRoutineResults" => { "Request" => "31 03" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_DataSet_RequestRoutineResults" => { "Responses" => "71 03" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Data Set : Request Routine Results" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_DataSet_Calculatechecksum" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_DataSet_Calculatechecksum" => { "Request" => "31 02 EF" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_DataSet_Calculatechecksum" => { "Responses" => "71 02 EF" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Data Set : Calculatechecksum" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_RequestRoutineResults_DataSet_EraseVWmemory" =>
		{
			"Requests" => {
			"REQ_RoutineControl_RequestRoutineResults_DataSet_EraseVWmemory" => { "Request" => "31 03 00" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_RequestRoutineResults_DataSet_EraseVWmemory" => { "Responses" => "71 03 00" , "Mode" => "relax" , "Desc" => "Routine Control _ Request Routine Results _ Data Set : EraseVWmemory" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_StartRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_StartRoutine" => { "Request" => "31 01" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_StartRoutine" => { "Responses" => "71 01" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Start Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Reset of Adaption Values" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Rollertestbench" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Rollertestbench" => { "Request" => "31 04 14" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Rollertestbench" => { "Responses" => "71 04 14" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Roller test bench" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_EvacAndFill" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_EvacAndFill" => { "Request" => "31 02 12" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_EvacAndFill" => { "Responses" => "71 02 12" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : EvacAndFill" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Emergencybrakesignaltest" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Request" => "31 04 15" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Emergencybrakesignaltest" => { "Responses" => "71 04 15" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Emergency brake signal test" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_RepairBleed" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_RepairBleed" => { "Request" => "31 02 11" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_RepairBleed" => { "Responses" => "71 02 11" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Repair Bleed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Bleed_brakes" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Request" => "31 03 9E" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Bleed_brakes" => { "Responses" => "71 03 9E" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Bleed_brakes" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_InertialSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Request" => "31 04 09" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_InertialSensorCalibration" => { "Responses" => "71 04 09" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Inertial Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Request" => "31 02 10" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_SteeringAngleSensorCalibration" => { "Responses" => "71 02 10" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Steering Angle Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Request" => "31 03 AF" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_Interchange_test_hydraulic_connections" => { "Responses" => "71 03 AF" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Interchange_test_hydraulic_connections" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_PressureSensorCalibration" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Request" => "31 04 0A" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_PressureSensorCalibration" => { "Responses" => "71 04 0A" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : Pressure Sensor Calibration" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StartBasicSetting_ESPDeactivation" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Request" => "31 04 1B" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StartBasicSetting_ESPDeactivation" => { "Responses" => "71 04 1B" , "Mode" => "relax" , "Desc" => "Routine Control _ Start Basic Setting : ESP Deactivation" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StopBasicSetting_StopRoutine" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StopBasicSetting_StopRoutine" => { "Request" => "31 02" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StopBasicSetting_StopRoutine" => { "Responses" => "71 02" , "Mode" => "relax" , "Desc" => "Routine Control _ Stop Basic Setting : Stop Routine" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RoutineControl_StopBasicSetting_ResetofAdaptionValues" =>
		{
			"Requests" => {
			"REQ_RoutineControl_StopBasicSetting_ResetofAdaptionValues" => { "Request" => "31 03 17" },
				},
			"POS_Responses" => {
			"RESP_RoutineControl_StopBasicSetting_ResetofAdaptionValues" => { "Responses" => "71 03 17" , "Mode" => "relax" , "Desc" => "Routine Control _ Stop Basic Setting : ResetofAdaptionValues" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestDownload_Uncompressed" =>
		{
			"Requests" => {
			"REQ_RequestDownload_Uncompressed" => { "Request" => "34 00" },
				},
			"POS_Responses" => {
			"RESP_RequestDownload_Uncompressed" => { "Responses" => "74 00" , "Mode" => "relax" , "Desc" => "Request Download : Uncompressed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestDownload_Unencrypted" =>
		{
			"Requests" => {
			"REQ_RequestDownload_Unencrypted" => { "Request" => "34 00" },
				},
			"POS_Responses" => {
			"RESP_RequestDownload_Unencrypted" => { "Responses" => "74 00" , "Mode" => "relax" , "Desc" => "Request Download : Unencrypted" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestDownload(MCD2.00.01)_Uncompressed" =>
		{
			"Requests" => {
			"REQ_RequestDownload(MCD2.00.01)_Uncompressed" => { "Request" => "34 00" },
				},
			"POS_Responses" => {
			"RESP_RequestDownload(MCD2.00.01)_Uncompressed" => { "Responses" => "74 00" , "Mode" => "relax" , "Desc" => "Request Download (MCD 2.00.01) : Uncompressed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestDownload(MCD2.00.01)_Unencrypted" =>
		{
			"Requests" => {
			"REQ_RequestDownload(MCD2.00.01)_Unencrypted" => { "Request" => "34 00" },
				},
			"POS_Responses" => {
			"RESP_RequestDownload(MCD2.00.01)_Unencrypted" => { "Responses" => "74 00" , "Mode" => "relax" , "Desc" => "Request Download (MCD 2.00.01) : Unencrypted" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestUpload_Uncompressed" =>
		{
			"Requests" => {
			"REQ_RequestUpload_Uncompressed" => { "Request" => "35 00" },
				},
			"POS_Responses" => {
			"RESP_RequestUpload_Uncompressed" => { "Responses" => "75 00" , "Mode" => "relax" , "Desc" => "Request Upload : Uncompressed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestUpload_Unencrypted" =>
		{
			"Requests" => {
			"REQ_RequestUpload_Unencrypted" => { "Request" => "35 00" },
				},
			"POS_Responses" => {
			"RESP_RequestUpload_Unencrypted" => { "Responses" => "75 00" , "Mode" => "relax" , "Desc" => "Request Upload : Unencrypted" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestUpload(MCD2.00.01)_Uncompressed" =>
		{
			"Requests" => {
			"REQ_RequestUpload(MCD2.00.01)_Uncompressed" => { "Request" => "35 00" },
				},
			"POS_Responses" => {
			"RESP_RequestUpload(MCD2.00.01)_Uncompressed" => { "Responses" => "75 00" , "Mode" => "relax" , "Desc" => "Request Upload (MCD 2.00.01) : Uncompressed" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"RequestUpload(MCD2.00.01)_Unencrypted" =>
		{
			"Requests" => {
			"REQ_RequestUpload(MCD2.00.01)_Unencrypted" => { "Request" => "35 00" },
				},
			"POS_Responses" => {
			"RESP_RequestUpload(MCD2.00.01)_Unencrypted" => { "Responses" => "75 00" , "Mode" => "relax" , "Desc" => "Request Upload (MCD 2.00.01) : Unencrypted" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"TesterPresent_ZeroSubFunction" =>
		{
			"Requests" => {
			"REQ_TesterPresent_ZeroSubFunction" => { "Request" => "3E 00" },
				},
			"POS_Responses" => {
			"RESP_TesterPresent_ZeroSubFunction" => { "Responses" => "7E 00" , "Mode" => "relax" , "Desc" => "Tester Present : Zero Sub Function" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ECUProgrammingSession" , "ExtendedSession" , "OBDIIAndVWDefaultSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
		"ControlDTCSetting_Off" =>
		{
			"Requests" => {
			"REQ_ControlDTCSetting_Off" => { "Request" => "85 02" },
				},
			"POS_Responses" => {
			"RESP_ControlDTCSetting_Off" => { "Responses" => "C5 02" , "Mode" => "relax" , "Desc" => "Control DTC Setting : Off" "DoorsIDs" => [ "" ]},
				},
			"allowed_in_sessions" => ["DevelopmentSession" , "ExtendedSession" , "VWEndOfLineSession" ],
		},
		#------------------------------------------------------------------
	},
	#***************************#
	"DIAG_SERVICES" => 
	{ 
		"DiagnosticSessionControl" => 
		{
			"Service_ID" => "10" ,
			"Supported_SubFuns" => 
			{
				"01_OBDIIAndVWDefaultDiagnosticSession"   => "01",
				"01_OBDIIAndVWDefaultDiagnosticSession"   => "01",
				"4F_DevelopmentSession_DevelopmentSession"   => "4F",
				"02_ECUProgrammingSession_ProgrammingSession"   => "02",
				"03_ExtendedSession_ExtendedDiagnosticSession"   => "03",
				"01_OBDIIAndVWDefaultSession_OBDIIAndVWDefaultDiagnosticSession"   => "01",
				"40_VWEndOfLineSession_VWEndOfLine(EoL)-Session"   => "40",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Diagnostic Session Control : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"ECUReset" => 
		{
			"Service_ID" => "11" ,
			"Supported_SubFuns" => 
			{
				"01_HardReset_HardReset"   => "01",
				"02_KeyOffOnReset_KeyOffOnReset"   => "02",
				"03_SoftReset_SoftReset"   => "03",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "ECU Reset  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "ECU Reset  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "ECU Reset  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "ECU Reset  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "ECU Reset  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "ECU Reset  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "ECU Reset  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "ECU Reset  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "ECU Reset  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "ECU Reset  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "ECU Reset  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "ECU Reset  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "ECU Reset  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "ECU Reset  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "ECU Reset  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "ECU Reset  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "ECU Reset  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "ECU Reset  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "ECU Reset  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "ECU Reset  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "ECU Reset  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "ECU Reset  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "ECU Reset  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "ECU Reset  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "ECU Reset  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "ECU Reset  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "ECU Reset  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "ECU Reset  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"ReadDTCInformation" => 
		{
			"Service_ID" => "19" ,
			"Supported_SubFuns" => 
			{
				"02_ReportDTCByActiveStatus_ReportDTCByStatusMask"   => "02",
				"00_ReportDTCByActiveStatus_WarningIndicatorOff"   => "00",
				"00_ReportDTCByActiveStatus_TestCompletedThisMonitoringCycle"   => "00",
				"00_ReportDTCByActiveStatus_TestNotFailedSinceLastClear"   => "00",
				"00_ReportDTCByActiveStatus_TestCompletedSinceLastClear"   => "00",
				"00_ReportDTCByActiveStatus_NotConfirmedDTC"   => "00",
				"00_ReportDTCByActiveStatus_NotPendingDTC"   => "00",
				"00_ReportDTCByActiveStatus_TestNotFailedThisOperationCycle"   => "00",
				"01_ReportDTCByActiveStatus_active"   => "01",
				"02_ReportDTCByActiveTestNotCompletedStatus_ReportDTCByStatusMask"   => "02",
				"00_ReportDTCByActiveTestNotCompletedStatus_WarningIndicatorOff"   => "00",
				"00_ReportDTCByActiveTestNotCompletedStatus_TestCompletedThisMonitoringCycle"   => "00",
				"00_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedSinceLastClear"   => "00",
				"01_ReportDTCByActiveTestNotCompletedStatus_TestNotCompletedSinceLastClear"   => "01",
				"00_ReportDTCByActiveTestNotCompletedStatus_NotConfirmedDTC"   => "00",
				"00_ReportDTCByActiveTestNotCompletedStatus_NotPendingDTC"   => "00",
				"00_ReportDTCByActiveTestNotCompletedStatus_TestNotFailedThisOperationCycle"   => "00",
				"00_ReportDTCByActiveTestNotCompletedStatus_passive"   => "00",
				"02_ReportDTCByConfirmedAndPendingStatus_ReportDTCByStatusMask"   => "02",
				"00_ReportDTCByConfirmedAndPendingStatus_WarningIndicatorOff"   => "00",
				"00_ReportDTCByConfirmedAndPendingStatus_TestCompletedThisMonitoringCycle"   => "00",
				"00_ReportDTCByConfirmedAndPendingStatus_TestNotFailedSinceLastClear"   => "00",
				"00_ReportDTCByConfirmedAndPendingStatus_TestCompletedSinceLastClear"   => "00",
				"01_ReportDTCByConfirmedAndPendingStatus_ConfirmedDTC"   => "01",
				"01_ReportDTCByConfirmedAndPendingStatus_PendingDTC"   => "01",
				"00_ReportDTCByConfirmedAndPendingStatus_TestNotFailedThisOperationCycle"   => "00",
				"00_ReportDTCByConfirmedAndPendingStatus_passive"   => "00",
				"02_ReportDTCByStatusMask_ReportDTCByStatusMask"   => "02",
				"00_ReportDTCByStatusMask_WarningIndicatorOff"   => "00",
				"00_ReportDTCByStatusMask_TestCompletedThisMonitoringCycle"   => "00",
				"00_ReportDTCByStatusMask_TestNotFailedSinceLastClear"   => "00",
				"00_ReportDTCByStatusMask_TestCompletedSinceLastClear"   => "00",
				"00_ReportDTCByStatusMask_NotConfirmedDTC"   => "00",
				"00_ReportDTCByStatusMask_NotPendingDTC"   => "00",
				"00_ReportDTCByStatusMask_TestNotFailedThisOperationCycle"   => "00",
				"00_ReportDTCByStatusMask_passive"   => "00",
				"06_ReportDTCExtendedDataRecordByDTCNumber_ReportDTCExtendedDataRecordByDTCNumber"   => "06",
				"FF_ReportDTCExtendedDataRecordByDTCNumber_AllDTCExtendedDataRecordNumbers"   => "FF",
				"13_ReportEmissionRelatedOBDDTCByStatusMask_ReportEmissionsRelatedOBDDTCByStatusMask"   => "13",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_WarningIndicatorOff"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedThisMonitoringCycle"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_TestCompletedSinceLastClear"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedSinceLastClear"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_NotConfirmedDTC"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_NotPendingDTC"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_TestNotFailedThisOperationCycle"   => "00",
				"00_ReportEmissionRelatedOBDDTCByStatusMask_passive"   => "00",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Read DTC Information  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"ReadDataByIdentifier" => 
		{
			"Service_ID" => "22" ,
			"Supported_SubFuns" => 
			{
				"0103_MeasurementValue_InvalidKeyCounter"   => "01 03",
				"0110_MeasurementValue_CANCommunicationStatus"   => "01 10",
				"0111_MeasurementValue_EMCTimeoutDetection"   => "01 11",
				"00_MeasurementValueBasicSettings_DummyMeasurementValue"   => "00",
				"0400_CalibrationData_VWCommonApplicationDataIdentifier"   => "04 00",
				"0103_MeasurementValue_InvalidKeyCounter"   => "01 03",
				"0110_MeasurementValue_CANCommunicationStatus"   => "01 10",
				"0111_MeasurementValue_EMCTimeoutDetection"   => "01 11",
				"00_MeasurementValueBasicSettings_DummyMeasurementValue"   => "00",
				"0400_CalibrationData_VWCommonApplicationDataIdentifier"   => "04 00",
				"00_MeasurementValueActuatorTest_DummyMeasurementValue"   => "00",
				"0405_ECUIdentification_StateOfFlashMemory"   => "04 05",
				"0407_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts"   => "04 07",
				"0408_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts"   => "04 08",
				"0409_ECUIdentification_VWDataCounterOfProgrammingAttempts"   => "04 09",
				"040A_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts"   => "04 0A",
				"040F_ECUIdentification_VWLogicalSoftwareBlockLockValue"   => "04 0F",
				"0606_ECUIdentification_IdentifiedSlaveSystems"   => "06 06",
				"0760_ECUIdentification_VWLINIdentificationTable(Slave-Class0)"   => "07 60",
				"F15B_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks"   => "F1 5B",
				"F17B_ECUIdentification_VWCodingDate"   => "F1 7B",
				"F17C_ECUIdentification_VWFAZITIdentificationString"   => "F1 7C",
				"F17E_ECUIdentification_ECUProductionChangeNumber"   => "F1 7E",
				"F181_ECUIdentification_VWStandardApplicationSoftwareIdentification"   => "F1 81",
				"F182_ECUIdentification_VWApplicationDataIdentification"   => "F1 82",
				"F186_ECUIdentification_ActiveDiagnosticSession"   => "F1 86",
				"F187_ECUIdentification_VWSparePartNumber"   => "F1 87",
				"F189_ECUIdentification_VWApplicationSoftwareVersionNumber"   => "F1 89",
				"F18C_ECUIdentification_ECUSerialNumber"   => "F1 8C",
				"F190_ECUIdentification_VehicleIdentificationNumber"   => "F1 90",
				"F191_ECUIdentification_VWECUHardwareNumber"   => "F1 91",
				"F197_ECUIdentification_VWSystemNameOrEngineType"   => "F1 97",
				"F19A_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber"   => "F1 9A",
				"F19B_ECUIdentification_VWCalibrationDate"   => "F1 9B",
				"F19E_ECUIdentification_ASAMODXFileIdentifier"   => "F1 9E",
				"F1A0_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber"   => "F1 A0",
				"F1A1_ECUIdentification_VWDataSetVersionNumber"   => "F1 A1",
				"F1A2_ECUIdentification_ASAMODXFileVersion"   => "F1 A2",
				"F1A3_ECUIdentification_VWECUHardwareVersionNumber"   => "F1 A3",
				"F1A4_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination"   => "F1 A4",
				"F1A5_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber"   => "F1 A5",
				"F1A8_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber"   => "F1 A8",
				"F1A9_ECUIdentification_VWDataSetProgrammingDate"   => "F1 A9",
				"F1AA_ECUIdentification_VWWorkshopSystemName"   => "F1 AA",
				"F1AB_ECUIdentification_VWLogicalSoftwareBlockVersion"   => "F1 AB",
				"F1AC_ECUIdentification_VWEOLConfiguration"   => "F1 AC",
				"F1AE_ECUIdentification_NumberOfLogins"   => "F1 AE",
				"F1AF_ECUIdentification_AUTOSAR_standard_application_software_identification"   => "F1 AF",
				"F1D5_ECUIdentification_FDS_project_data"   => "F1 D5",
				"F1DF_ECUIdentification_ECUProgrammingInformation"   => "F1 DF",
				"F1E0_ECUIdentification_ECUDataProgrammingInformation"   => "F1 E0",
				"F1A2_ASAMODXFileVersion_ASAMODXFileVersion"   => "F1 A2",
				"F187_VWSparePartNumber_VWSparePartNumber"   => "F1 87",
				"F19E_ASAMODXFileIdentifier_ASAMODXFileIdentifier"   => "F1 9E",
				"F1A3_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber"   => "F1 A3",
				"F1AB_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion"   => "F1 AB",
				"F189_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber"   => "F1 89",
				"F191_VWECUHardwareNumber_VWECUHardwareNumber"   => "F1 91",
				"F19E_ASAMODXFileIdentifier_ASAMODXFileIdentifier"   => "F1 9E",
				"F1A2_ASAMODXFileVersion_ASAMODXFileVersion"   => "F1 A2",
				"0400_CalibrationData_VWCommonApplicationDataIdentifier"   => "04 00",
				"0405_ECUIdentification_StateOfFlashMemory"   => "04 05",
				"0407_ECUIdentification_VWLogicalSoftwareBlockCounterOfProgrammingAttempts"   => "04 07",
				"0408_ECUIdentification_VWLogicalSoftwareBlockCounterOfSuccessfulProgrammingAttempts"   => "04 08",
				"0409_ECUIdentification_VWDataCounterOfProgrammingAttempts"   => "04 09",
				"040A_ECUIdentification_VWDataCounterOfSuccessfulProgrammingAttempts"   => "04 0A",
				"040F_ECUIdentification_VWLogicalSoftwareBlockLockValue"   => "04 0F",
				"0606_ECUIdentification_IdentifiedSlaveSystems"   => "06 06",
				"0760_ECUIdentification_VWLINIdentificationTable(Slave-Class0)"   => "07 60",
				"F15B_ECUIdentification_FingerprintAndProgrammingDateOfLogicalSoftwareBlocks"   => "F1 5B",
				"F17B_ECUIdentification_VWCodingDate"   => "F1 7B",
				"F17C_ECUIdentification_VWFAZITIdentificationString"   => "F1 7C",
				"F17E_ECUIdentification_ECUProductionChangeNumber"   => "F1 7E",
				"F181_ECUIdentification_VWStandardApplicationSoftwareIdentification"   => "F1 81",
				"F182_ECUIdentification_VWApplicationDataIdentification"   => "F1 82",
				"F186_ECUIdentification_ActiveDiagnosticSession"   => "F1 86",
				"F187_ECUIdentification_VWSparePartNumber"   => "F1 87",
				"F189_ECUIdentification_VWApplicationSoftwareVersionNumber"   => "F1 89",
				"F18C_ECUIdentification_ECUSerialNumber"   => "F1 8C",
				"F190_ECUIdentification_VehicleIdentificationNumber"   => "F1 90",
				"F191_ECUIdentification_VWECUHardwareNumber"   => "F1 91",
				"F197_ECUIdentification_VWSystemNameOrEngineType"   => "F1 97",
				"F19A_ECUIdentification_VWCalibrationRepairShopCodeOrSerialNumber"   => "F1 9A",
				"F19B_ECUIdentification_VWCalibrationDate"   => "F1 9B",
				"F19E_ECUIdentification_ASAMODXFileIdentifier"   => "F1 9E",
				"F1A0_ECUIdentification_VWDataSetNumberOrECUDataContainerNumber"   => "F1 A0",
				"F1A1_ECUIdentification_VWDataSetVersionNumber"   => "F1 A1",
				"F1A2_ECUIdentification_ASAMODXFileVersion"   => "F1 A2",
				"F1A3_ECUIdentification_VWECUHardwareVersionNumber"   => "F1 A3",
				"F1A4_ECUIdentification_VehicleEquipmentCodeAndPRNumberCombination"   => "F1 A4",
				"F1A5_ECUIdentification_VWCodingRepairShopCodeOrSerialNumber"   => "F1 A5",
				"F1A8_ECUIdentification_VWDataSetRepairShopCodeOrSerialNumber"   => "F1 A8",
				"F1A9_ECUIdentification_VWDataSetProgrammingDate"   => "F1 A9",
				"F1AA_ECUIdentification_VWWorkshopSystemName"   => "F1 AA",
				"F1AB_ECUIdentification_VWLogicalSoftwareBlockVersion"   => "F1 AB",
				"F1AC_ECUIdentification_VWEOLConfiguration"   => "F1 AC",
				"F1AE_ECUIdentification_NumberOfLogins"   => "F1 AE",
				"F1AF_ECUIdentification_AUTOSAR_standard_application_software_identification"   => "F1 AF",
				"F1D5_ECUIdentification_FDS_project_data"   => "F1 D5",
				"F1DF_ECUIdentification_ECUProgrammingInformation"   => "F1 DF",
				"F1E0_ECUIdentification_ECUDataProgrammingInformation"   => "F1 E0",
				"0606_IdentifiedSlaveSystems_IdentifiedSlaveSystems"   => "06 06",
				"0103_MeasurementValue_InvalidKeyCounter"   => "01 03",
				"0110_MeasurementValue_CANCommunicationStatus"   => "01 10",
				"0111_MeasurementValue_EMCTimeoutDetection"   => "01 11",
				"00_MeasurementValueActuatorTest_DummyMeasurementValue"   => "00",
				"00_MeasurementValueBasicSettings_DummyMeasurementValue"   => "00",
				"02E0_TheftProtectionData_Immobilizer-Challenge"   => "02 E0",
				"02E4_TheftProtectionData_TransponderIDcurrentKey"   => "02 E4",
				"02E5_TheftProtectionData_TransponderIDKey1"   => "02 E5",
				"02E6_TheftProtectionData_TransponderIDKey2"   => "02 E6",
				"02E7_TheftProtectionData_TransponderIDKey3"   => "02 E7",
				"02E8_TheftProtectionData_TransponderIDKey4"   => "02 E8",
				"02E9_TheftProtectionData_TransponderIDKey5"   => "02 E9",
				"02EA_TheftProtectionData_TransponderIDKey6"   => "02 EA",
				"02EB_TheftProtectionData_TransponderIDKey7"   => "02 EB",
				"02EC_TheftProtectionData_TransponderIDKey8"   => "02 EC",
				"02ED_TheftProtectionData_StateofImmobilizer"   => "02 ED",
				"02EE_TheftProtectionData_StateofImmobilizerSlaves"   => "02 EE",
				"02EF_TheftProtectionData_StateBlockingTime"   => "02 EF",
				"0600_VariantCoding_VWCodingValue"   => "06 00",
				"F189_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber"   => "F1 89",
				"F191_VWECUHardwareNumber_VWECUHardwareNumber"   => "F1 91",
				"F1A3_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber"   => "F1 A3",
				"F1AB_VWLogicalSoftwareBlockVersion_VWLogicalSoftwareBlockVersion"   => "F1 AB",
				"0610_VWSlaveCodingValue_Slave1"   => "06 10",
				"0611_VWSlaveCodingValue_Slave2"   => "06 11",
				"0612_VWSlaveCodingValue_Slave3"   => "06 12",
				"07A0_VWSlaveFAZITIdentificationString_Slave1"   => "07 A0",
				"07A1_VWSlaveFAZITIdentificationString_Slave2"   => "07 A1",
				"07A2_VWSlaveFAZITIdentificationString_Slave3"   => "07 A2",
				"06A0_VWSlaveHardwareNumber_Slave1"   => "06 A0",
				"06A1_VWSlaveHardwareNumber_Slave2"   => "06 A1",
				"06A2_VWSlaveHardwareNumber_Slave3"   => "06 A2",
				"06D0_VWSlaveHardwareVersionNumber_Slave1"   => "06 D0",
				"06D1_VWSlaveHardwareVersionNumber_Slave2"   => "06 D1",
				"06D2_VWSlaveHardwareVersionNumber_Slave3"   => "06 D2",
				"0700_VWSlaveSerialNumber_Slave1"   => "07 00",
				"0701_VWSlaveSerialNumber_Slave2"   => "07 01",
				"0702_VWSlaveSerialNumber_Slave3"   => "07 02",
				"0670_VWSlaveSoftwareVersionNumber_Slave1"   => "06 70",
				"0671_VWSlaveSoftwareVersionNumber_Slave2"   => "06 71",
				"0672_VWSlaveSoftwareVersionNumber_Slave3"   => "06 72",
				"0640_VWSlaveSparePartNumber_Slave1"   => "06 40",
				"0641_VWSlaveSparePartNumber_Slave2"   => "06 41",
				"0642_VWSlaveSparePartNumber_Slave3"   => "06 42",
				"0730_VWSlaveSystemName_Slave1"   => "07 30",
				"0731_VWSlaveSystemName_Slave2"   => "07 31",
				"0732_VWSlaveSystemName_Slave3"   => "07 32",
				"F187_VWSparePartNumber_VWSparePartNumber"   => "F1 87",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Read Data By Identifier  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"SecurityAccess" => 
		{
			"Service_ID" => "27" ,
			"Supported_SubFuns" => 
			{
				"03_RequestSeed_RequestSeedLogin"   => "03",
				"09_RequestSeed_RequestSeedSystemSpecific"   => "09",
				"11_RequestSeed_RequestSeedBootloader"   => "11",
				"5F_RequestSeed_RequestSeedAirbagDeployment"   => "5F",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Security Access  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Security Access  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Security Access  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Security Access  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Security Access  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Exceedednumberofattempts"  =>  { "Response" => "7F 36" , "Mode" => "relax" , "Desc" => "Security Access  : Exceedednumberofattempts" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requiredtimedelaynotexpired"  =>  { "Response" => "7F 37" , "Mode" => "relax" , "Desc" => "Security Access  : Requiredtimedelaynotexpired" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Security Access  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Security Access  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Security Access  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Security Access  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Security Access  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"SecurityAccess" => 
		{
			"Service_ID" => "27" ,
			"Supported_SubFuns" => 
			{
				"04_SendKey_SendKeyLogin"   => "04",
				"0A_SendKey_SendKeySystemSpecific"   => "0A",
				"12_SendKey_SendKeyBootloader"   => "12",
				"60_SendKey_SendKeyAirbagDeployment"   => "60",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Security Access  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Security Access  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Security Access  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Security Access  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestsequenceerror"  =>  { "Response" => "7F 24" , "Mode" => "relax" , "Desc" => "Security Access  : Requestsequenceerror" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Security Access  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Invalidkey"  =>  { "Response" => "7F 35" , "Mode" => "relax" , "Desc" => "Security Access  : Invalidkey" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Security Access  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Security Access  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Security Access  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Security Access  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Security Access  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"SecurityAccess" => 
		{
			"Service_ID" => "27" ,
			"Supported_SubFuns" => 
			{
				"03_RequestSeedLogin_RequestSeedLogin"   => "03",
				"09_RequestSeedSystemSpecific_RequestSeedSystemSpecific"   => "09",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Security Access  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Security Access  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Security Access  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Security Access  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Security Access  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Exceedednumberofattempts"  =>  { "Response" => "7F 36" , "Mode" => "relax" , "Desc" => "Security Access  : Exceedednumberofattempts" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requiredtimedelaynotexpired"  =>  { "Response" => "7F 37" , "Mode" => "relax" , "Desc" => "Security Access  : Requiredtimedelaynotexpired" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Security Access  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Security Access  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Security Access  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Security Access  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Security Access  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"SecurityAccess" => 
		{
			"Service_ID" => "27" ,
			"Supported_SubFuns" => 
			{
				"04_SendKeyLogin_SendKeyLogin"   => "04",
				"0A_SendKeySystemSpecific_SendKeySystemSpecific"   => "0A",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Security Access  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Security Access  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Security Access  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Security Access  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestsequenceerror"  =>  { "Response" => "7F 24" , "Mode" => "relax" , "Desc" => "Security Access  : Requestsequenceerror" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Security Access  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Invalidkey"  =>  { "Response" => "7F 35" , "Mode" => "relax" , "Desc" => "Security Access  : Invalidkey" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Security Access  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Security Access  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Security Access  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Security Access  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Security Access  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Security Access  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Security Access  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Security Access  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Security Access  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Security Access  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Security Access  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Security Access  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Security Access  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Security Access  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"CommunicationControl" => 
		{
			"Service_ID" => "28" ,
			"Supported_SubFuns" => 
			{
				"00_EnableRxAndTx"   => "00",
				"01_EnableRxAndDisableTx"   => "01",
				"02_DisableRxAndEnableTx"   => "02",
				"03_DisableRxAndTx"   => "03",
				"00_AllNetworks"   => "00",
				"01_SubNetwork#1"   => "01",
				"02_SubNetwork#2"   => "02",
				"03_SubNetwork#3"   => "03",
				"04_SubNetwork#4"   => "04",
				"05_SubNetwork#5"   => "05",
				"06_SubNetwork#6"   => "06",
				"07_SubNetwork#7"   => "07",
				"08_SubNetwork#8"   => "08",
				"09_SubNetwork#9"   => "09",
				"0A_SubNetwork#10"   => "0A",
				"0B_SubNetwork#11"   => "0B",
				"0C_SubNetwork#12"   => "0C",
				"0D_SubNetwork#13"   => "0D",
				"0E_SubNetwork#14"   => "0E",
				"0F_MainNetwork"   => "0F",
				"01_NormalCommunicationMessages"   => "01",
				"02_NetworkManagementCommunicationMessages"   => "02",
				"03_NormalAndNetworkManagementCommunicationMessages"   => "03",
				"01_EnableRxAndDisableTx_NormalCommunicationMessages_EnableRxAndDisableTx"   => "01",
				"00_EnableRxAndDisableTx_NormalCommunicationMessages_AllNetworks"   => "00",
				"01_EnableRxAndDisableTx_NormalCommunicationMessages_NormalCommunicationMessages"   => "01",
				"00_EnableRxAndTx_NormalCommunicationMessages_EnableRxAndTx"   => "00",
				"00_EnableRxAndTx_NormalCommunicationMessages_AllNetworks"   => "00",
				"01_EnableRxAndTx_NormalCommunicationMessages_NormalCommunicationMessages"   => "01",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Communication Control : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Communication Control : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Communication Control : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Communication Control : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Communication Control : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Communication Control : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Communication Control : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Communication Control : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Communication Control : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Communication Control : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Communication Control : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Communication Control : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Communication Control : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Communication Control : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Communication Control : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Communication Control : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Communication Control : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Communication Control : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Communication Control : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Communication Control : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Communication Control : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Communication Control : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Communication Control : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Communication Control : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Communication Control : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Communication Control : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Communication Control : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Communication Control : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Communication Control : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"WriteDataByIdentifier" => 
		{
			"Service_ID" => "2E" ,
			"Supported_SubFuns" => 
			{
				"1100_CalibrationData_Anti-slip_regulation_(ASR)"   => "11 00",
				"1101_CalibrationData_ElektronischesStabilisierungsprogramm"   => "11 01",
				"1102_CalibrationData_ElektronischeDifferenzialsperre"   => "11 02",
				"0501_CalibrationData_KalibrierungsprotokollXCP"   => "05 01",
				"0E0E_CalibrationData_Rollenprüfstandsmodus"   => "0E 0E",
				"0E10_CalibrationData_Geradeausbremsstabilisierung"   => "0E 10",
				"0E0D_CalibrationData_Berganfahrassistent"   => "0E 0D",
				"0E1E_CalibrationData_OverboostimBremssystem"   => "0E 1E",
				"0E01_CalibrationData_HydraulischerBremsassistent"   => "0E 01",
				"0E1C_CalibrationData_ErweiterteelektronischeDifferenzialsperre"   => "0E 1C",
				"0E1D_CalibrationData_Hinterachsvollverzögerung"   => "0E 1D",
				"0E00_CalibrationData_WarnschwellenReifenkontrollanzeige"   => "0E 00",
				"0E26_CalibrationData_ReifenkontrollanzeigeReifenauswahl"   => "0E 26",
				"1109_CalibrationData_RKADatenlogging"   => "11 09",
				"0E0A_CalibrationData_Motorschleppmomentregelung"   => "0E 0A",
				"05FF_CalibrationData_EvacAndFillByte"   => "05 FF",
				"0902_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften"   => "09 02",
				"1100_CalibrationData_Anti-slip_regulation_(ASR)"   => "11 00",
				"1101_CalibrationData_ElektronischesStabilisierungsprogramm"   => "11 01",
				"1102_CalibrationData_ElektronischeDifferenzialsperre"   => "11 02",
				"0501_CalibrationData_KalibrierungsprotokollXCP"   => "05 01",
				"0E0E_CalibrationData_Rollenprüfstandsmodus"   => "0E 0E",
				"0E10_CalibrationData_Geradeausbremsstabilisierung"   => "0E 10",
				"0E0D_CalibrationData_Berganfahrassistent"   => "0E 0D",
				"0E1E_CalibrationData_OverboostimBremssystem"   => "0E 1E",
				"0E01_CalibrationData_HydraulischerBremsassistent"   => "0E 01",
				"0E1C_CalibrationData_ErweiterteelektronischeDifferenzialsperre"   => "0E 1C",
				"0E1D_CalibrationData_Hinterachsvollverzögerung"   => "0E 1D",
				"0E00_CalibrationData_WarnschwellenReifenkontrollanzeige"   => "0E 00",
				"0E26_CalibrationData_ReifenkontrollanzeigeReifenauswahl"   => "0E 26",
				"1109_CalibrationData_RKADatenlogging"   => "11 09",
				"0E0A_CalibrationData_Motorschleppmomentregelung"   => "0E 0A",
				"05FF_CalibrationData_EvacAndFillByte"   => "05 FF",
				"0902_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften"   => "09 02",
				"1100_CalibrationData_Anti-slip_regulation_(ASR)"   => "11 00",
				"1101_CalibrationData_ElektronischesStabilisierungsprogramm"   => "11 01",
				"1102_CalibrationData_ElektronischeDifferenzialsperre"   => "11 02",
				"0501_CalibrationData_KalibrierungsprotokollXCP"   => "05 01",
				"0E0E_CalibrationData_Rollenprüfstandsmodus"   => "0E 0E",
				"0E10_CalibrationData_Geradeausbremsstabilisierung"   => "0E 10",
				"0E0D_CalibrationData_Berganfahrassistent"   => "0E 0D",
				"0E1E_CalibrationData_OverboostimBremssystem"   => "0E 1E",
				"0E01_CalibrationData_HydraulischerBremsassistent"   => "0E 01",
				"0E1C_CalibrationData_ErweiterteelektronischeDifferenzialsperre"   => "0E 1C",
				"0E1D_CalibrationData_Hinterachsvollverzögerung"   => "0E 1D",
				"0E00_CalibrationData_WarnschwellenReifenkontrollanzeige"   => "0E 00",
				"0E26_CalibrationData_ReifenkontrollanzeigeReifenauswahl"   => "0E 26",
				"1109_CalibrationData_RKADatenlogging"   => "11 09",
				"0E0A_CalibrationData_Motorschleppmomentregelung"   => "0E 0A",
				"05FF_CalibrationData_EvacAndFillByte"   => "05 FF",
				"0902_CalibrationData_AktivierenundDeaktivierenallerEntwicklungsbotschaften"   => "09 02",
				"0410_ECUIdentification_BootloaderTPBlocksize"   => "04 10",
				"F15A_ECUIdentification_Fingerprint"   => "F1 5A",
				"F199_ECUIdentification_ProgrammingDate"   => "F1 99",
				"F198_ECUIdentification_RepairShopCodeOrTesterSerialNumber"   => "F1 98",
				"02E3_TheftProtectionData_Immobilizer-DownloadIMS"   => "02 E3",
				"02E2_TheftProtectionData_Immobilizer-DownloadPowertrain"   => "02 E2",
				"02FB_TheftProtectionData_Immobilizer-DownloadWFS4"   => "02 FB",
				"02E1_TheftProtectionData_Immobilizer-Login"   => "02 E1",
				"02F1_TheftProtectionData_Immobilizer-SlaveLogin"   => "02 F1",
				"BD_TheftProtectionData_TheftProtection-DownloadGFA-Key"   => "BD",
				"BE_TheftProtectionData_TheftProtection-DownloadIKA-Key"   => "BE",
				"0600_VariantCoding_VWCodingValue"   => "06 00",
				"0600_VariantCodingTextual_VWCodingValue"   => "06 00",
				"0610_VWSlaveCodingValue_Slave1"   => "06 10",
				"0611_VWSlaveCodingValue_Slave2"   => "06 11",
				"0612_VWSlaveCodingValue_Slave3"   => "06 12",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestsequenceerror"  =>  { "Response" => "7F 24" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Requestsequenceerror" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Generalprogrammingfailure"  =>  { "Response" => "7F 72" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Generalprogrammingfailure" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Write Data By Identifier  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"InputOutputControlByIdentifier" => 
		{
			"Service_ID" => "2F" ,
			"Supported_SubFuns" => 
			{
				"0258_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve"   => "02 58",
				"0259_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve"   => "02 59",
				"025A_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve"   => "02 5A",
				"025B_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve"   => "02 5B",
				"025C_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve"   => "02 5C",
				"025D_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve"   => "02 5D",
				"025E_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve"   => "02 5E",
				"025F_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve"   => "02 5F",
				"0260_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1"   => "02 60",
				"0261_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2"   => "02 61",
				"0262_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1"   => "02 62",
				"0263_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2"   => "02 63",
				"0264_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump"   => "02 64",
				"0400_ActuatorTest_ShortTermAdjustment_Dynamic_Test"   => "04 00",
				"0401_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test"   => "04 01",
				"0403_ActuatorTest_ShortTermAdjustment_Static_Test"   => "04 03",
				"0258_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve"   => "02 58",
				"0259_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve"   => "02 59",
				"025A_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve"   => "02 5A",
				"025B_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve"   => "02 5B",
				"025C_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve"   => "02 5C",
				"025D_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve"   => "02 5D",
				"025E_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve"   => "02 5E",
				"025F_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve"   => "02 5F",
				"0260_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1"   => "02 60",
				"0261_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2"   => "02 61",
				"0262_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1"   => "02 62",
				"0263_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2"   => "02 63",
				"0264_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump"   => "02 64",
				"0400_ActuatorTest_ShortTermAdjustment_Dynamic_Test"   => "04 00",
				"0401_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test"   => "04 01",
				"0403_ActuatorTest_ShortTermAdjustment_Static_Test"   => "04 03",
				"0100_ActuatorTest_FreezeCurrentState_Reserved"   => "01 00",
				"02_ActuatorTest_FreezeCurrentState_FreezeCurrentState"   => "02",
				"0100_ActuatorTest_ReturnControlToECU_Reserved"   => "01 00",
				"00_ActuatorTest_ReturnControlToECU_ReturnControlToECU"   => "00",
				"0258_ActuatorTest_ShortTermAdjustment_Front_left_ABS_inlet_valve"   => "02 58",
				"0259_ActuatorTest_ShortTermAdjustment_Front_left_ABS_outlet_valve"   => "02 59",
				"025A_ActuatorTest_ShortTermAdjustment_Front_right_ABS_inlet_valve"   => "02 5A",
				"025B_ActuatorTest_ShortTermAdjustment_Front_right_ABS_outlet_valve"   => "02 5B",
				"025C_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_inlet_valve"   => "02 5C",
				"025D_ActuatorTest_ShortTermAdjustment_Rear_left_ABS_outlet_valve"   => "02 5D",
				"025E_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_inlet_valve"   => "02 5E",
				"025F_ActuatorTest_ShortTermAdjustment_Rear_right_ABS_outlet_valve"   => "02 5F",
				"0260_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_1"   => "02 60",
				"0261_ActuatorTest_ShortTermAdjustment_Vehicle_stabilization_program_switch_valve_2"   => "02 61",
				"0262_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_1"   => "02 62",
				"0263_ActuatorTest_ShortTermAdjustment_Driving_Dynamics_Regulation_High_Pressure_Switch_Valve_2"   => "02 63",
				"0264_ActuatorTest_ShortTermAdjustment_ABS_return_flow_pump"   => "02 64",
				"0400_ActuatorTest_ShortTermAdjustment_Dynamic_Test"   => "04 00",
				"0401_ActuatorTest_ShortTermAdjustment_Wheel_Speed_Sensor_Test"   => "04 01",
				"0403_ActuatorTest_ShortTermAdjustment_Static_Test"   => "04 03",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestsequenceerror"  =>  { "Response" => "7F 24" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Requestsequenceerror" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Input Output Control By Identifier  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"RoutineControl" => 
		{
			"Service_ID" => "31" ,
			"Supported_SubFuns" => 
			{
				"01_StartBasicSetting_StartRoutine"   => "01",
				"0317_StartBasicSetting_ResetofAdaptionValues"   => "03 17",
				"0414_StartBasicSetting_Rollertestbench"   => "04 14",
				"0212_StartBasicSetting_EvacAndFill"   => "02 12",
				"0415_StartBasicSetting_Emergencybrakesignaltest"   => "04 15",
				"0211_StartBasicSetting_RepairBleed"   => "02 11",
				"039E_StartBasicSetting_Bleed_brakes"   => "03 9E",
				"0409_StartBasicSetting_InertialSensorCalibration"   => "04 09",
				"0210_StartBasicSetting_SteeringAngleSensorCalibration"   => "02 10",
				"03AF_StartBasicSetting_Interchange_test_hydraulic_connections"   => "03 AF",
				"040A_StartBasicSetting_PressureSensorCalibration"   => "04 0A",
				"041B_StartBasicSetting_ESPDeactivation"   => "04 1B",
				"03_RequestRoutineResults_BasicSetting_RequestRoutineResults"   => "03",
				"0317_RequestRoutineResults_BasicSetting_ResetofAdaptionValues"   => "03 17",
				"01_StartBasicSetting_StartRoutine"   => "01",
				"0317_StartBasicSetting_ResetofAdaptionValues"   => "03 17",
				"0414_StartBasicSetting_Rollertestbench"   => "04 14",
				"0212_StartBasicSetting_EvacAndFill"   => "02 12",
				"0415_StartBasicSetting_Emergencybrakesignaltest"   => "04 15",
				"0211_StartBasicSetting_RepairBleed"   => "02 11",
				"039E_StartBasicSetting_Bleed_brakes"   => "03 9E",
				"0409_StartBasicSetting_InertialSensorCalibration"   => "04 09",
				"0210_StartBasicSetting_SteeringAngleSensorCalibration"   => "02 10",
				"03AF_StartBasicSetting_Interchange_test_hydraulic_connections"   => "03 AF",
				"040A_StartBasicSetting_PressureSensorCalibration"   => "04 0A",
				"041B_StartBasicSetting_ESPDeactivation"   => "04 1B",
				"03_RequestRoutineResults_BasicSetting_RequestRoutineResults"   => "03",
				"0317_RequestRoutineResults_BasicSetting_ResetofAdaptionValues"   => "03 17",
				"01_CheckMemory_StartRoutine"   => "01",
				"0202_CheckMemory_CheckMemory"   => "02 02",
				"01_CheckMemory(MCD2.00.01)_StartRoutine"   => "01",
				"0202_CheckMemory(MCD2.00.01)_CheckMemory"   => "02 02",
				"01_CheckProgrammingDependencies_StartRoutine"   => "01",
				"FF01_CheckProgrammingDependencies_CheckProgrammingDependencies"   => "FF 01",
				"01_CheckProgrammingPreconditions_StartRoutine"   => "01",
				"0203_CheckProgrammingPreconditions_CheckProgrammingPreconditions"   => "02 03",
				"01_EraseMemory_StartRoutine"   => "01",
				"FF00_EraseMemory_EraseMemory"   => "FF 00",
				"01_EraseMemory(MCD2.00.01)_StartRoutine"   => "01",
				"FF00_EraseMemory(MCD2.00.01)_EraseMemory"   => "FF 00",
				"03_RequestRoutineResults_BasicSetting_RequestRoutineResults"   => "03",
				"0317_RequestRoutineResults_BasicSetting_ResetofAdaptionValues"   => "03 17",
				"01_StartRoutine_DataSet_StartRoutine"   => "01",
				"02EF_StartRoutine_DataSet_Calculatechecksum"   => "02 EF",
				"0300_StartRoutine_DataSet_EraseVWmemory"   => "03 00",
				"03_RequestRoutineResults_DataSet_RequestRoutineResults"   => "03",
				"02EF_RequestRoutineResults_DataSet_Calculatechecksum"   => "02 EF",
				"0300_RequestRoutineResults_DataSet_EraseVWmemory"   => "03 00",
				"01_StartBasicSetting_StartRoutine"   => "01",
				"0317_StartBasicSetting_ResetofAdaptionValues"   => "03 17",
				"0414_StartBasicSetting_Rollertestbench"   => "04 14",
				"0212_StartBasicSetting_EvacAndFill"   => "02 12",
				"0415_StartBasicSetting_Emergencybrakesignaltest"   => "04 15",
				"0211_StartBasicSetting_RepairBleed"   => "02 11",
				"039E_StartBasicSetting_Bleed_brakes"   => "03 9E",
				"0409_StartBasicSetting_InertialSensorCalibration"   => "04 09",
				"0210_StartBasicSetting_SteeringAngleSensorCalibration"   => "02 10",
				"03AF_StartBasicSetting_Interchange_test_hydraulic_connections"   => "03 AF",
				"040A_StartBasicSetting_PressureSensorCalibration"   => "04 0A",
				"041B_StartBasicSetting_ESPDeactivation"   => "04 1B",
				"02_StopBasicSetting_StopRoutine"   => "02",
				"0317_StopBasicSetting_ResetofAdaptionValues"   => "03 17",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Routine Control  : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Routine Control  : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Routine Control  : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Routine Control  : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Routine Control  : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Routine Control  : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Routine Control  : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Routine Control  : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Routine Control  : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Routine Control  : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Generalprogrammingfailure"  =>  { "Response" => "7F 72" , "Mode" => "relax" , "Desc" => "Routine Control  : Generalprogrammingfailure" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Routine Control  : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Routine Control  : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Routine Control  : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Routine Control  : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Routine Control  : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Routine Control  : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Routine Control  : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Routine Control  : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Routine Control  : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Routine Control  : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Routine Control  : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Routine Control  : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Routine Control  : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Routine Control  : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Routine Control  : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Routine Control  : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Routine Control  : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Routine Control  : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Routine Control  : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Routine Control  : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Routine Control  : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"RequestDownload" => 
		{
			"Service_ID" => "34" ,
			"Supported_SubFuns" => 
			{
				"00_Uncompressed"   => "00",
				"00_Unencrypted"   => "00",
				"00_Uncompressed"   => "00",
				"00_Unencrypted"   => "00",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Request Download : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Request Download : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Request Download : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Request Download : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Request Download : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Request Download : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Request Download : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Request Download : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Request Download : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Upload/Downloadnotaccepted"  =>  { "Response" => "7F 70" , "Mode" => "relax" , "Desc" => "Request Download : Upload/Downloadnotaccepted" , "AddrModes" => ["Physical","Functional"]},
				"NR_Generalprogrammingfailure"  =>  { "Response" => "7F 72" , "Mode" => "relax" , "Desc" => "Request Download : Generalprogrammingfailure" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Request Download : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Request Download : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Request Download : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Request Download : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Request Download : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Request Download : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Request Download : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Request Download : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Request Download : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Request Download : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Request Download : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Request Download : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Request Download : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Request Download : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Request Download : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Request Download : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Request Download : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Request Download : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Request Download : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Request Download : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"RequestUpload" => 
		{
			"Service_ID" => "35" ,
			"Supported_SubFuns" => 
			{
				"00_Uncompressed"   => "00",
				"00_Unencrypted"   => "00",
				"00_Uncompressed"   => "00",
				"00_Unencrypted"   => "00",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Request Upload : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Request Upload : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Request Upload : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Request Upload : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Conditionsnotcorrect"  =>  { "Response" => "7F 22" , "Mode" => "relax" , "Desc" => "Request Upload : Conditionsnotcorrect" , "AddrModes" => ["Physical","Functional"]},
				"NR_Noresponsefromsubnetcomponent"  =>  { "Response" => "7F 25" , "Mode" => "relax" , "Desc" => "Request Upload : Noresponsefromsubnetcomponent" , "AddrModes" => ["Physical","Functional"]},
				"NR_Failurepreventsexecutionofrequestedaction"  =>  { "Response" => "7F 26" , "Mode" => "relax" , "Desc" => "Request Upload : Failurepreventsexecutionofrequestedaction" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestoutofrange"  =>  { "Response" => "7F 31" , "Mode" => "relax" , "Desc" => "Request Upload : Requestoutofrange" , "AddrModes" => ["Physical","Functional"]},
				"NR_Securityaccessdenied"  =>  { "Response" => "7F 33" , "Mode" => "relax" , "Desc" => "Request Upload : Securityaccessdenied" , "AddrModes" => ["Physical","Functional"]},
				"NR_Upload/Downloadnotaccepted"  =>  { "Response" => "7F 70" , "Mode" => "relax" , "Desc" => "Request Upload : Upload/Downloadnotaccepted" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Request Upload : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Request Upload : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoohigh"  =>  { "Response" => "7F 81" , "Mode" => "relax" , "Desc" => "Request Upload : Revolutionsperminutetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Revolutionsperminutetoolow"  =>  { "Response" => "7F 82" , "Mode" => "relax" , "Desc" => "Request Upload : Revolutionsperminutetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisrunning"  =>  { "Response" => "7F 83" , "Mode" => "relax" , "Desc" => "Request Upload : Engineisrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineisnotrunning"  =>  { "Response" => "7F 84" , "Mode" => "relax" , "Desc" => "Request Upload : Engineisnotrunning" , "AddrModes" => ["Physical","Functional"]},
				"NR_Engineruntimetoolow"  =>  { "Response" => "7F 85" , "Mode" => "relax" , "Desc" => "Request Upload : Engineruntimetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoohigh"  =>  { "Response" => "7F 86" , "Mode" => "relax" , "Desc" => "Request Upload : Temperaturetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Temperaturetoolow"  =>  { "Response" => "7F 87" , "Mode" => "relax" , "Desc" => "Request Upload : Temperaturetoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoohigh"  =>  { "Response" => "7F 88" , "Mode" => "relax" , "Desc" => "Request Upload : Vehiclespeedtoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Vehiclespeedtoolow"  =>  { "Response" => "7F 89" , "Mode" => "relax" , "Desc" => "Request Upload : Vehiclespeedtoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoohigh"  =>  { "Response" => "7F 8A" , "Mode" => "relax" , "Desc" => "Request Upload : Throttle/Pedaltoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Throttle/Pedaltoolow"  =>  { "Response" => "7F 8B" , "Mode" => "relax" , "Desc" => "Request Upload : Throttle/Pedaltoolow" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotinneutral"  =>  { "Response" => "7F 8C" , "Mode" => "relax" , "Desc" => "Request Upload : Transmissionrangenotinneutral" , "AddrModes" => ["Physical","Functional"]},
				"NR_Transmissionrangenotingear"  =>  { "Response" => "7F 8D" , "Mode" => "relax" , "Desc" => "Request Upload : Transmissionrangenotingear" , "AddrModes" => ["Physical","Functional"]},
				"NR_Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)"  =>  { "Response" => "7F 8F" , "Mode" => "relax" , "Desc" => "Request Upload : Brakeswitch(es)notclosed(brakepedalnotpressedorapplied)" , "AddrModes" => ["Physical","Functional"]},
				"NR_Shifterlevernotinpark"  =>  { "Response" => "7F 90" , "Mode" => "relax" , "Desc" => "Request Upload : Shifterlevernotinpark" , "AddrModes" => ["Physical","Functional"]},
				"NR_Torqueconverterclutchlocked"  =>  { "Response" => "7F 91" , "Mode" => "relax" , "Desc" => "Request Upload : Torqueconverterclutchlocked" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoohigh"  =>  { "Response" => "7F 92" , "Mode" => "relax" , "Desc" => "Request Upload : Voltagetoohigh" , "AddrModes" => ["Physical","Functional"]},
				"NR_Voltagetoolow"  =>  { "Response" => "7F 93" , "Mode" => "relax" , "Desc" => "Request Upload : Voltagetoolow" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
		"TesterPresent" => 
		{
			"Service_ID" => "3E" ,
			"Supported_SubFuns" => 
			{
				"00_ZeroSubFunction"   => "00",
			},
			"NEG_Responses" => 
			{
				"NR_Generalreject"  =>  { "Response" => "7F 10" , "Mode" => "relax" , "Desc" => "Tester Present : Generalreject" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupported"  =>  { "Response" => "7F 11" , "Mode" => "relax" , "Desc" => "Tester Present : Servicenotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupported"  =>  { "Response" => "7F 12" , "Mode" => "relax" , "Desc" => "Tester Present : Sub-functionnotsupported" , "AddrModes" => ["Physical","Functional"]},
				"NR_Incorrectmessagelengthorinvalidformat"  =>  { "Response" => "7F 13" , "Mode" => "relax" , "Desc" => "Tester Present : Incorrectmessagelengthorinvalidformat" , "AddrModes" => ["Physical","Functional"]},
				"NR_Busy-repeatrequest"  =>  { "Response" => "7F 21" , "Mode" => "relax" , "Desc" => "Tester Present : Busy-repeatrequest" , "AddrModes" => ["Physical","Functional"]},
				"NR_Requestcorrectlyreceived-responsepending"  =>  { "Response" => "7F 78" , "Mode" => "relax" , "Desc" => "Tester Present : Requestcorrectlyreceived-responsepending" , "AddrModes" => ["Physical","Functional"]},
				"NR_Sub-functionnotsupportedinactivesession"  =>  { "Response" => "7F 7E" , "Mode" => "relax" , "Desc" => "Tester Present : Sub-functionnotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
				"NR_Servicenotsupportedinactivesession"  =>  { "Response" => "7F 7F" , "Mode" => "relax" , "Desc" => "Tester Present : Servicenotsupportedinactivesession" , "AddrModes" => ["Physical","Functional"]},
			},
		},
		#------------------------------------------------------------------
	}, #end of DIAG_SERVICES
	#***************************#
	"Response_Phys2Hex" => 
	{ 
		"00_DummyMeasurementValue_HEXParameter" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Dummy Measurement Value" ,"TI"=> "MAS00478" },
		"01_PID$01_CompletionStatusOfNon-ContinuousMonitorsSinceDTCCleared" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "PID $01" ,"TI"=> "undef" },
		"01_PID$01_NumberofDTCsstoredinthisECU" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "PID $01" ,"TI"=> "undef" },
		"0103_InvalidKeyCounter_CounterValue" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Invalid Key Counter" ,"TI"=> "IDE00323" },
		"0211_RepairBleed_Bleeding_Phase" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Repair Bleed" ,"TI"=> "undef" },
		"0211_RepairBleed_RepairBleedPhaseRepetitons" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Repair Bleed" ,"TI"=> "undef" },
		"02E0_Immobilizer-Challenge_ImmobilizerChallenge" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Challenge" ,"TI"=> "undef" },
		"02E1_Immobilizer-Login_ImmobilizerLogin" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Login" ,"TI"=> "undef" },
		"02E2_Immobilizer-DownloadPowertrain_ImmobilizerDownloadPowertrain" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download Powertrain" ,"TI"=> "undef" },
		"02E3_Immobilizer-DownloadIMS_ImmobilizerDownloadIMS" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download IMS" ,"TI"=> "undef" },
		"02E4_TransponderIDcurrentKey_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID current Key" ,"TI"=> "undef" },
		"02E5_TransponderIDKey1_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 1" ,"TI"=> "undef" },
		"02E6_TransponderIDKey2_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 2" ,"TI"=> "undef" },
		"02E7_TransponderIDKey3_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 3" ,"TI"=> "undef" },
		"02E8_TransponderIDKey4_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 4" ,"TI"=> "undef" },
		"02E9_TransponderIDKey5_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 5" ,"TI"=> "undef" },
		"02EA_TransponderIDKey6_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 6" ,"TI"=> "undef" },
		"02EB_TransponderIDKey7_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 7" ,"TI"=> "undef" },
		"02EC_TransponderIDKey8_KeyTransponderID" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Transponder ID Key 8" ,"TI"=> "undef" },
		"02ED_StateofImmobilizer_StateofImmobilizer" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "State of Immobilizer" ,"TI"=> "undef" },
		"02EE_StateofImmobilizerSlaves_StateofImmobilizerSlaves" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "State of Immobilizer Slaves" ,"TI"=> "undef" },
		"02EF_StateBlockingTime_StateBlockingTime" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "State Blocking Time" ,"TI"=> "undef" },
		"02F1_Immobilizer-SlaveLogin_ImmobilizerLogin" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Slave Login" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_Immo-ID" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_MAC" => { "STARTBIT"=> 385,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_PIN_S" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_P-Klasse" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_SKC" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_VIN" => { "STARTBIT"=> 249,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"02FB_Immobilizer-DownloadWFS4_WFS-Konfiguration" => { "STARTBIT"=> 417,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Immobilizer - Download WFS 4" ,"TI"=> "undef" },
		"0300_RoutineResult:EOLDynamicTest_WheelSpeedFL" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed FL" ,"TI"=> "undef" },
		"0300_RoutineResult:EOLDynamicTest_WheelSpeedFR" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed FR" ,"TI"=> "undef" },
		"0300_RoutineResult:EOLDynamicTest_WheelSpeedRL" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed RL" ,"TI"=> "undef" },
		"0300_RoutineResult:EOLDynamicTest_WheelSpeedRR" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed RR" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontLeftAverageSpeed" => { "STARTBIT"=> 160,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Average Speed " ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontLeftMaximumSpeed" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Maximum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontLeftMinimumSpeed" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Minimum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontRightAverageSpeed" => { "STARTBIT"=> 176,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Average Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontRightMaximumSpeed" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Maximum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedFrontRightMinimumSpeed" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Minimum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearLeftAverageSpeed" => { "STARTBIT"=> 192,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Average Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearLeftMaximumSpeed" => { "STARTBIT"=> 96,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Maximum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearLeftMinimumSpeed" => { "STARTBIT"=> 112,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Minimum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearRightAverageSpeed" => { "STARTBIT"=> 208,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Average Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearRightMaximumSpeed" => { "STARTBIT"=> 128,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Maximum Speed" ,"TI"=> "undef" },
		"0301_RoutineResult:EOLWheelSpeedSensorTest_WheelSpeedRearRightMinimumSpeed" => { "STARTBIT"=> 144,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Minimum Speed" ,"TI"=> "undef" },
		"0400_Dynamic_Test_ActuationTime" => { "STARTBIT"=> 168,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 10.0,"TYPE"=> "A_INT32" ,"UNIT"=> "ms" ,"LONGNAME"=> "ActuationTime" ,"TI"=> "undef" },
		"0400_Dynamic_Test_Waiting_Time_1" => { "STARTBIT"=> 104,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 10.0,"TYPE"=> "A_INT32" ,"UNIT"=> "ms" ,"LONGNAME"=> "Waiting_Time_1" ,"TI"=> "undef" },
		"0400_Dynamic_Test_Waiting_Time_2" => { "STARTBIT"=> 184,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 10.0,"TYPE"=> "A_INT32" ,"UNIT"=> "ms" ,"LONGNAME"=> "Waiting_Time_2" ,"TI"=> "undef" },
		"0400_Dynamic_Test_WaitingTime" => { "STARTBIT"=> 184,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 10.0,"TYPE"=> "A_INT32" ,"UNIT"=> "ms" ,"LONGNAME"=> "WaitingTime" ,"TI"=> "undef" },
		"0400_VWCommonApplicationDataIdentifier_VWCommonApplicationDataIdentifier" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Common Application Data Identifier" ,"TI"=> "MAS00478" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontLeftAverageSpeed" => { "STARTBIT"=> 160,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Average Speed " ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontLeftMaximumSpeed" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Maximum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontLeftMinimumSpeed" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Minimum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontRightAverageSpeed" => { "STARTBIT"=> 176,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Average Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontRightMaximumSpeed" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Maximum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedFrontRightMinimumSpeed" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Minimum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearLeftAverageSpeed" => { "STARTBIT"=> 192,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Average Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearLeftMaximumSpeed" => { "STARTBIT"=> 96,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Maximum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearLeftMinimumSpeed" => { "STARTBIT"=> 112,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Minimum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearRightAverageSpeed" => { "STARTBIT"=> 208,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Average Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearRightMaximumSpeed" => { "STARTBIT"=> 128,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Maximum Speed" ,"TI"=> "undef" },
		"0401_Wheel_Speed_Sensor_Test_WheelSpeedRearRightMinimumSpeed" => { "STARTBIT"=> 144,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Minimum Speed" ,"TI"=> "undef" },
		"0404_wheelspeedroutine_ControlParameter" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "wheel speed routine" ,"TI"=> "undef" },
		"0404_wheelspeedroutine_ExecutionTime" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "wheel speed routine" ,"TI"=> "undef" },
		"0404_wheelspeedroutine_V_stop" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "wheel speed routine" ,"TI"=> "undef" },
		"0404_wheelspeedroutineResults_WheelSpeedFrontLeftSpeed" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Left Speed" ,"TI"=> "undef" },
		"0404_wheelspeedroutineResults_WheelSpeedFrontRightSpeed" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Front Right Speed" ,"TI"=> "undef" },
		"0404_wheelspeedroutineResults_WheelSpeedRearLeftSpeed" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Left Speed" ,"TI"=> "undef" },
		"0404_wheelspeedroutineResults_WheelSpeedRearRightSpeed" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.015625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s" ,"LONGNAME"=> "Wheel Speed Rear Right Speed" ,"TI"=> "undef" },
		"0409_VWDataCounterOfProgrammingAttempts_CounterValueBlock1" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Counter Of Programming Attempts" ,"TI"=> "IDE00052" },
		"040A_VWDataCounterOfSuccessfulProgrammingAttempts_CounterValueBlock1" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Counter Of Successful Programming Attempts" ,"TI"=> "IDE00053" },
		"0410_BootloaderTPBlocksize_BootloaderTPBlocksize" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Bootloader TP Blocksize" ,"TI"=> "IDE02639" },
		"0413_RücksetzenaufWerkseinstellungderReifenkontrollanzeige_empty" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Rücksetzen auf Werkseinstellung der Reifenkontrollanzeige" ,"TI"=> "IDE05060" },
		"0418_RücksetzenderWarnungenderReifenkontrollanzeige_empty" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Rücksetzen der Warnungen der Reifenkontrollanzeige" ,"TI"=> "IDE05334" },
		"05FF_EvacAndFillByte_EvacAndFillByte" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Evac And Fill Byte" ,"TI"=> "undef" },
		"0600_VWCodingValue_Bytefield" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Coding Value" ,"TI"=> "IDE00003" },
		"0600_VWCodingValue_Raw-Data" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Coding Value" ,"TI"=> "IDE00003" },
		"0610_Slave1_Raw-Data" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"0611_Slave2_Raw-Data" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"0612_Slave3_Raw-Data" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"0640_Slave1_VWSparePartNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"0641_Slave2_VWSparePartNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"0642_Slave3_VWSparePartNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"0670_Slave1_VWApplicationSoftwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"0671_Slave2_VWApplicationSoftwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"0672_Slave3_VWApplicationSoftwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"06A0_Slave1_VWECUHardwareNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"06A1_Slave2_VWECUHardwareNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"06A2_Slave3_VWECUHardwareNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"06D0_Slave1_VWECUHardwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"06D1_Slave2_VWECUHardwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"06D2_Slave3_VWECUHardwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"0700_Slave1_VWSlaveSerialNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"0701_Slave2_VWSlaveSerialNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"0702_Slave3_VWSlaveSerialNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"0730_Slave1_VWSystemNameOrEngineType" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"0731_Slave2_VWSystemNameOrEngineType" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"0732_Slave3_VWSystemNameOrEngineType" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"07A0_Slave1_ConsecutiveSupplierNumber" => { "STARTBIT"=> 169,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"07A0_Slave1_ECUManufacturingDate" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"07A0_Slave1_ECUProductionPlantNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"07A0_Slave1_ECUProductionTestSystemNumber" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 1" ,"TI"=> "undef" },
		"07A1_Slave2_ConsecutiveSupplierNumber" => { "STARTBIT"=> 169,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"07A1_Slave2_ECUManufacturingDate" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"07A1_Slave2_ECUProductionPlantNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"07A1_Slave2_ECUProductionTestSystemNumber" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 2" ,"TI"=> "undef" },
		"07A2_Slave3_ConsecutiveSupplierNumber" => { "STARTBIT"=> 169,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"07A2_Slave3_ECUManufacturingDate" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"07A2_Slave3_ECUProductionPlantNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"07A2_Slave3_ECUProductionTestSystemNumber" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Slave 3" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_ActivityHSENmode" => { "STARTBIT"=> 129,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_ActivityHSENmode" => { "STARTBIT"=> 233,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Availabilitycounter_1" => { "STARTBIT"=> 361,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Availabilitycounter_1" => { "STARTBIT"=> 465,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Availabilitycounter_2" => { "STARTBIT"=> 369,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Availabilitycounter_2" => { "STARTBIT"=> 473,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Datade-activation" => { "STARTBIT"=> 113,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Datade-activation" => { "STARTBIT"=> 209,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Datalearningtroubles" => { "STARTBIT"=> 97,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Datalearningtroubles" => { "STARTBIT"=> 161,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Dataprogresstirecalibrationhighspeed" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Dataprogresstirecalibrationhighspeed" => { "STARTBIT"=> 32,"LENGTH"=> 8,"OFFSET"=> 0,"FACTOR"=> 0.39215687,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "%" ,"LONGNAME"=> "Data progress tire calibration high speed" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Dataprogresstirecalibrationlowspeed" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Dataprogresstirecalibrationlowspeed" => { "STARTBIT"=> 24,"LENGTH"=> 8,"OFFSET"=> 0,"FACTOR"=> 0.39215687,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "%" ,"LONGNAME"=> "Data progress tire calibration low speed" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphdays" => { "STARTBIT"=> 297,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphdays" => { "STARTBIT"=> 401,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphhours" => { "STARTBIT"=> 305,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphhours" => { "STARTBIT"=> 409,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphminutes" => { "STARTBIT"=> 313,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphminutes" => { "STARTBIT"=> 417,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphseconds" => { "STARTBIT"=> 321,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime100-120kmphseconds" => { "STARTBIT"=> 425,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphdays" => { "STARTBIT"=> 169,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphdays" => { "STARTBIT"=> 273,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphhours" => { "STARTBIT"=> 177,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphhours" => { "STARTBIT"=> 281,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphminutes" => { "STARTBIT"=> 185,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphminutes" => { "STARTBIT"=> 289,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphseconds" => { "STARTBIT"=> 193,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime10-40kmphseconds" => { "STARTBIT"=> 297,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphdays" => { "STARTBIT"=> 201,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphdays" => { "STARTBIT"=> 305,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphhours" => { "STARTBIT"=> 209,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphhours" => { "STARTBIT"=> 313,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphminutes" => { "STARTBIT"=> 217,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphminutes" => { "STARTBIT"=> 321,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphseconds" => { "STARTBIT"=> 225,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime40-60kmphseconds" => { "STARTBIT"=> 329,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphdays" => { "STARTBIT"=> 233,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphdays" => { "STARTBIT"=> 337,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphhours" => { "STARTBIT"=> 241,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphhours" => { "STARTBIT"=> 345,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphminutes" => { "STARTBIT"=> 249,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphminutes" => { "STARTBIT"=> 353,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphseconds" => { "STARTBIT"=> 257,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime60-80kmphseconds" => { "STARTBIT"=> 361,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphdays" => { "STARTBIT"=> 265,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphdays" => { "STARTBIT"=> 369,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphhours" => { "STARTBIT"=> 273,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphhours" => { "STARTBIT"=> 377,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphminutes" => { "STARTBIT"=> 281,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphminutes" => { "STARTBIT"=> 385,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphseconds" => { "STARTBIT"=> 289,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtime80-100kmphseconds" => { "STARTBIT"=> 393,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimedays" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimedays" => { "STARTBIT"=> 241,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphdays" => { "STARTBIT"=> 329,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphdays" => { "STARTBIT"=> 433,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphhours" => { "STARTBIT"=> 337,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphhours" => { "STARTBIT"=> 441,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphminutes" => { "STARTBIT"=> 345,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphminutes" => { "STARTBIT"=> 449,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphseconds" => { "STARTBIT"=> 353,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimefaster120kmphseconds" => { "STARTBIT"=> 457,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimehours" => { "STARTBIT"=> 145,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimehours" => { "STARTBIT"=> 249,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimeminutes" => { "STARTBIT"=> 153,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimeminutes" => { "STARTBIT"=> 257,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimeseconds" => { "STARTBIT"=> 161,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Drivingtimeseconds" => { "STARTBIT"=> 265,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Middlewareversion" => { "STARTBIT"=> 97,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWRAfrontaxle" => { "STARTBIT"=> 561,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWRAleftside" => { "STARTBIT"=> 577,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWRArearaxle" => { "STARTBIT"=> 569,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWRArightside" => { "STARTBIT"=> 585,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWSAfrontleft" => { "STARTBIT"=> 593,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWSAfrontright" => { "STARTBIT"=> 601,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWSArearleft" => { "STARTBIT"=> 609,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualityofcalibrationWSArearright" => { "STARTBIT"=> 617,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWRAfrontaxle" => { "STARTBIT"=> 497,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWRAleftside" => { "STARTBIT"=> 513,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWRArearaxle" => { "STARTBIT"=> 505,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWRArightside" => { "STARTBIT"=> 521,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWSAfrontleft" => { "STARTBIT"=> 529,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWSAfrontright" => { "STARTBIT"=> 537,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWSArearleft" => { "STARTBIT"=> 545,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_QualitywarningindicatorWSArearright" => { "STARTBIT"=> 553,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_Softwareversion" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_SystemactivityWRA" => { "STARTBIT"=> 377,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_SystemactivityWRA" => { "STARTBIT"=> 481,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_SystemactivityWSA" => { "STARTBIT"=> 385,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_SystemactivityWSA" => { "STARTBIT"=> 489,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_TimeinHSENmode" => { "STARTBIT"=> 121,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_TimeinHSENmode" => { "STARTBIT"=> 225,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_WarningType" => { "STARTBIT"=> 105,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1000_RKADevelopmentInformation_WarningType" => { "STARTBIT"=> 193,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Development Information" ,"TI"=> "undef" },
		"1800_Drehzahlfühlervornlinks_AverageValue" => { "STARTBIT"=> 128,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Average Value" ,"TI"=> "IDE04425" },
		"1800_Drehzahlfühlervornlinks_Data" => { "STARTBIT"=> 24,"LENGTH"=> 8,"OFFSET"=> 0.0,"FACTOR"=> 2.0,"TYPE"=> "A_UINT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04425" },
		"1800_Drehzahlfühlervornlinks_Data" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.05625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04425" },
		"1800_Drehzahlfühlervornlinks_MaximumValue" => { "STARTBIT"=> 96,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Maximum Value" ,"TI"=> "IDE04425" },
		"1800_Drehzahlfühlervornlinks_MinimumValue" => { "STARTBIT"=> 64,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Minimum Value" ,"TI"=> "IDE04425" },
		"1801_Drehzahlfühlervornrechts_AverageValue" => { "STARTBIT"=> 128,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Average Value" ,"TI"=> "IDE04426" },
		"1801_Drehzahlfühlervornrechts_Data" => { "STARTBIT"=> 24,"LENGTH"=> 8,"OFFSET"=> 0.0,"FACTOR"=> 2.0,"TYPE"=> "A_UINT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04426" },
		"1801_Drehzahlfühlervornrechts_Data" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.05625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04426" },
		"1801_Drehzahlfühlervornrechts_MaximumValue" => { "STARTBIT"=> 96,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Maximum Value" ,"TI"=> "IDE04426" },
		"1801_Drehzahlfühlervornrechts_MinimumValue" => { "STARTBIT"=> 64,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Minimum Value" ,"TI"=> "IDE04426" },
		"1802_Drehzahlfühlerhintenlinks_AverageValue" => { "STARTBIT"=> 128,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Average Value" ,"TI"=> "IDE04427" },
		"1802_Drehzahlfühlerhintenlinks_Data" => { "STARTBIT"=> 24,"LENGTH"=> 8,"OFFSET"=> 0.0,"FACTOR"=> 2.0,"TYPE"=> "A_UINT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04427" },
		"1802_Drehzahlfühlerhintenlinks_Data" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.05625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04427" },
		"1802_Drehzahlfühlerhintenlinks_MaximumValue" => { "STARTBIT"=> 96,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Maximum Value" ,"TI"=> "IDE04427" },
		"1802_Drehzahlfühlerhintenlinks_MinimumValue" => { "STARTBIT"=> 64,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Minimum Value" ,"TI"=> "IDE04427" },
		"1803_Drehzahlfühlerhintenrechts_AverageValue" => { "STARTBIT"=> 128,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Average Value" ,"TI"=> "IDE04428" },
		"1803_Drehzahlfühlerhintenrechts_Data" => { "STARTBIT"=> 24,"LENGTH"=> 8,"OFFSET"=> 0.0,"FACTOR"=> 2.0,"TYPE"=> "A_UINT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04428" },
		"1803_Drehzahlfühlerhintenrechts_Data" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.05625,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "km/h" ,"LONGNAME"=> "Data" ,"TI"=> "IDE04428" },
		"1803_Drehzahlfühlerhintenrechts_MaximumValue" => { "STARTBIT"=> 96,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Maximum Value" ,"TI"=> "IDE04428" },
		"1803_Drehzahlfühlerhintenrechts_MinimumValue" => { "STARTBIT"=> 64,"LENGTH"=> 32,"OFFSET"=> 0.0,"FACTOR"=> 0.23842,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "µs" ,"LONGNAME"=> "Minimum Value" ,"TI"=> "IDE04428" },
		"1804_GeberfürSchlupfregelsystem_Drehratensensor1,Z-Achse" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.0021326,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad/s" ,"LONGNAME"=> "Drehratensensor 1, Z-Achse" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Drehratensensor1,Z-Achse" => { "STARTBIT"=> 32,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.0021326,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad/s" ,"LONGNAME"=> "Drehratensensor 1, Z-Achse" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_GeberfürLenkwinkel" => { "STARTBIT"=> 112,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.001745,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad" ,"LONGNAME"=> "Geber für Lenkwinkel" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_GeberfürLenkwinkel" => { "STARTBIT"=> 112,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.001745,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad" ,"LONGNAME"=> "Geber für Lenkwinkel" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Längsbeschleunigungssensor" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Längsbeschleunigungssensor" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Längsbeschleunigungssensor" => { "STARTBIT"=> 80,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Längsbeschleunigungssensor" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Längsbeschleunigungssensor,Offset" => { "STARTBIT"=> 96,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Längsbeschleunigungssensor, Offset" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Längsbeschleunigungssensor,Offset" => { "STARTBIT"=> 96,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Längsbeschleunigungssensor, Offset" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Lenkwinkel,Offset" => { "STARTBIT"=> 128,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.001745,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad" ,"LONGNAME"=> "Lenkwinkel, Offset" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Lenkwinkel,Offset" => { "STARTBIT"=> 128,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.001745,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "rad" ,"LONGNAME"=> "Lenkwinkel, Offset" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Querbeschleunigungssensor1" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Querbeschleunigungssensor 1" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Querbeschleunigungssensor1" => { "STARTBIT"=> 48,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Querbeschleunigungssensor 1" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Querbeschleunigungssensor1,Offset" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Querbeschleunigungssensor 1, Offset" ,"TI"=> "IDE04443" },
		"1804_GeberfürSchlupfregelsystem_Querbeschleunigungssensor1,Offset" => { "STARTBIT"=> 64,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.027127,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "m/s²" ,"LONGNAME"=> "Querbeschleunigungssensor 1, Offset" ,"TI"=> "IDE04443" },
		"1816_GeberfürBremssystem_BrakePressureSensorVoltage" => { "STARTBIT"=> 56,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.03226,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "V" ,"LONGNAME"=> "Brake Pressure Sensor Voltage" ,"TI"=> "IDE04422" },
		"1816_GeberfürBremssystem_Bremsdruckgeber1" => { "STARTBIT"=> 40,"LENGTH"=> 16,"OFFSET"=> 0.0,"FACTOR"=> 0.3255,"TYPE"=> "A_FLOAT32" ,"UNIT"=> "bar" ,"LONGNAME"=> "Bremsdruckgeber 1" ,"TI"=> "IDE04422" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionfrontleft" => { "STARTBIT"=> 177,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionfrontleft" => { "STARTBIT"=> 233,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionfrontright" => { "STARTBIT"=> 185,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionfrontright" => { "STARTBIT"=> 241,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionrearleft" => { "STARTBIT"=> 193,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionrearleft" => { "STARTBIT"=> 249,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionrearright" => { "STARTBIT"=> 201,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Indicatorfortyrepressurediffusionrearright" => { "STARTBIT"=> 257,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading2ndlastlearning" => { "STARTBIT"=> 57,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading2ndlastlearning" => { "STARTBIT"=> 65,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading2ndlastwarning" => { "STARTBIT"=> 121,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading2ndlastwarning" => { "STARTBIT"=> 161,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading3rdlastlearning" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading3rdlastlearning" => { "STARTBIT"=> 89,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading3rdlastwarning" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading3rdlastwarning" => { "STARTBIT"=> 185,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading4thlastlearning" => { "STARTBIT"=> 89,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading4thlastlearning" => { "STARTBIT"=> 113,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreading4thlastwarning" => { "STARTBIT"=> 153,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreading4thlastwarning" => { "STARTBIT"=> 209,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreadinglastlearning" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreadinglastlearning" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Kilometerreadinglastwarning" => { "STARTBIT"=> 105,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Kilometerreadinglastwarning" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Lesspressurerecognitiondamagefrontleft" => { "STARTBIT"=> 209,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Lesspressurerecognitiondamagefrontleft" => { "STARTBIT"=> 265,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Lesspressurerecognitiondamagefrontright" => { "STARTBIT"=> 217,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Lesspressurerecognitiondamagefrontright" => { "STARTBIT"=> 273,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Lesspressurerecognitiondamagerearleft" => { "STARTBIT"=> 225,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Lesspressurerecognitiondamagerearleft" => { "STARTBIT"=> 281,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"1821_RKAInformation_Lesspressurerecognitiondamagerearright" => { "STARTBIT"=> 233,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "undef" },
		"1821_RKAInformation_Lesspressurerecognitiondamagerearright" => { "STARTBIT"=> 289,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "RKA Information" ,"TI"=> "IDE04939" },
		"18F5_StatusInputSignalCAN_VehicleIdentificationNumber" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Status Input Signal CAN" ,"TI"=> "IDE02270" },
		"BD_TheftProtection-DownloadGFA-Key_GFA-Key" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Theft Protection - Download GFA-Key" ,"TI"=> "undef" },
		"BE_TheftProtection-DownloadIKA-Key_IKA-Key" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Theft Protection - Download IKA-Key" ,"TI"=> "undef" },
		"F17C_VWFAZITIdentificationString_ConsecutiveSupplierNumber" => { "STARTBIT"=> 169,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW FAZIT Identification String" ,"TI"=> "IDE00034" },
		"F17C_VWFAZITIdentificationString_ECUManufacturingDate" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW FAZIT Identification String" ,"TI"=> "IDE00034" },
		"F17C_VWFAZITIdentificationString_ECUProductionPlantNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW FAZIT Identification String" ,"TI"=> "IDE00034" },
		"F17C_VWFAZITIdentificationString_ECUProductionTestSystemNumber" => { "STARTBIT"=> 137,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW FAZIT Identification String" ,"TI"=> "IDE00034" },
		"F17E_ECUProductionChangeNumber_ConstructionStatus" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ECU Production Change Number" ,"TI"=> "IDE00035" },
		"F17E_ECUProductionChangeNumber_ECUFamily" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ECU Production Change Number" ,"TI"=> "IDE00035" },
		"F17E_ECUProductionChangeNumber_MountingType" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ECU Production Change Number" ,"TI"=> "IDE00035" },
		"F17E_ECUProductionChangeNumber_ProductionStatus" => { "STARTBIT"=> 57,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ECU Production Change Number" ,"TI"=> "IDE00035" },
		"F187_VWSparePartNumber_VWSparePartNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Spare Part Number" ,"TI"=> "IDE00007" },
		"F189_VWApplicationSoftwareVersionNumber_VWApplicationSoftwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Application Software Version Number" ,"TI"=> "IDE00008" },
		"F18C_ECUSerialNumber_ECUSerialNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ECU Serial Number" ,"TI"=> "IDE00010" },
		"F190_VehicleIdentificationNumber_VehicleIdentificationNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Vehicle Identification Number" ,"TI"=> "IDE00011" },
		"F191_VWECUHardwareNumber_VWECUHardwareNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW ECU Hardware Number" ,"TI"=> "IDE00012" },
		"F197_VWSystemNameOrEngineType_VWSystemNameOrEngineType" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW System Name Or Engine Type" ,"TI"=> "IDE00013" },
		"F198_RepairShopCodeOrTesterSerialNumber_ImporterNumber" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Repair Shop Code Or Tester Serial Number" ,"TI"=> "IDE00319" },
		"F198_RepairShopCodeOrTesterSerialNumber_VWDeviceNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Repair Shop Code Or Tester Serial Number" ,"TI"=> "IDE00319" },
		"F198_RepairShopCodeOrTesterSerialNumber_WorkshopNumber" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Repair Shop Code Or Tester Serial Number" ,"TI"=> "IDE00319" },
		"F19A_VWCalibrationRepairShopCodeOrSerialNumber_ImporterNumber" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Calibration Repair Shop Code Or Serial Number" ,"TI"=> "IDE00044" },
		"F19A_VWCalibrationRepairShopCodeOrSerialNumber_VWDeviceNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Calibration Repair Shop Code Or Serial Number" ,"TI"=> "IDE00044" },
		"F19A_VWCalibrationRepairShopCodeOrSerialNumber_WorkshopNumber" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Calibration Repair Shop Code Or Serial Number" ,"TI"=> "IDE00044" },
		"F19E_ASAMODXFileIdentifier_ASAMODXFileIdentifier" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ASAM ODX File Identifier" ,"TI"=> "IDE00072" },
		"F1A0_VWDataSetNumberOrECUDataContainerNumber_VWDataSetNumberOrECUDataContainerNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Set Number Or ECU Data Container Number" ,"TI"=> "IDE00048" },
		"F1A1_VWDataSetVersionNumber_VWDataSetVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Set Version Number" ,"TI"=> "IDE00047" },
		"F1A2_ASAMODXFileVersion_ASAMODXFileVersion" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "ASAM ODX File Version" ,"TI"=> "IDE00073" },
		"F1A3_VWECUHardwareVersionNumber_VWECUHardwareVersionNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW ECU Hardware Version Number" ,"TI"=> "IDE00016" },
		"F1A4_VehicleEquipmentCodeAndPRNumberCombination_VehicleEquipmentCodeAndPRNumberCombination" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Vehicle Equipment Code And PR Number Combination" ,"TI"=> "IDE00036" },
		"F1A5_VWCodingRepairShopCodeOrSerialNumber_ImporterNumber" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Coding Repair Shop Code Or Serial Number" ,"TI"=> "IDE00045" },
		"F1A5_VWCodingRepairShopCodeOrSerialNumber_VWDeviceNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Coding Repair Shop Code Or Serial Number" ,"TI"=> "IDE00045" },
		"F1A5_VWCodingRepairShopCodeOrSerialNumber_WorkshopNumber" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Coding Repair Shop Code Or Serial Number" ,"TI"=> "IDE00045" },
		"F1A8_VWDataSetRepairShopCodeOrSerialNumber_ImporterNumber" => { "STARTBIT"=> 33,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Set Repair Shop Code Or Serial Number" ,"TI"=> "IDE00046" },
		"F1A8_VWDataSetRepairShopCodeOrSerialNumber_VWDeviceNumber" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Set Repair Shop Code Or Serial Number" ,"TI"=> "IDE00046" },
		"F1A8_VWDataSetRepairShopCodeOrSerialNumber_WorkshopNumber" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Data Set Repair Shop Code Or Serial Number" ,"TI"=> "IDE00046" },
		"F1AA_VWWorkshopSystemName_VWWorkshopSystemName" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW Workshop System Name" ,"TI"=> "IDE00017" },
		"F1AC_VWEOLConfiguration_HardwareAssemblyGroup" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW EOL Configuration" ,"TI"=> "IDE00551" },
		"F1AC_VWEOLConfiguration_HardwareTypeCode" => { "STARTBIT"=> 41,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW EOL Configuration" ,"TI"=> "IDE00551" },
		"F1AC_VWEOLConfiguration_SoftwareAssemblyGroup" => { "STARTBIT"=> 73,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW EOL Configuration" ,"TI"=> "IDE00551" },
		"F1AC_VWEOLConfiguration_SoftwareTypeCode" => { "STARTBIT"=> 97,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW EOL Configuration" ,"TI"=> "IDE00551" },
		"F1AC_VWEOLConfiguration_SoftwareTypeVariant" => { "STARTBIT"=> 129,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "VW EOL Configuration" ,"TI"=> "IDE00551" },
		"F1AE_NumberOfLogins_NumberOfLogins" => { "STARTBIT"=> 17,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "Number Of Logins" ,"TI"=> "IDE00798" },
		"F1D5_FDS_project_data_FDSprojectID" => { "STARTBIT"=> 25,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "FDS_project_data" ,"TI"=> "undef" },
		"F1D5_FDS_project_data_hashvalue" => { "STARTBIT"=> 57,"LENGTH"=> 1,"OFFSET"=> 0,"FACTOR"=> 1,"TYPE"=> "undef" ,"UNIT"=> "undef" ,"LONGNAME"=> "FDS_project_data" ,"TI"=> "undef" },
	}, # end of Response_Phys2Hex 
	#***************************#
	"DTC_INFO" => 
	{ 
		"1" => { "Name" => "DTC_1" , "Display_Code" => "C1069F0" , "Text" => "Abs_ContControl" , "Level" => "2"},
		"2" => { "Name" => "DTC_2" , "Display_Code" => "P057100" , "Text" => "AcmBls_PermHigh" , "Level" => "2"},
		"3" => { "Name" => "DTC_3" , "Display_Code" => "P057100" , "Text" => "AcmBls_PermHighHHC" , "Level" => "2"},
		"4" => { "Name" => "DTC_4" , "Display_Code" => "P057100" , "Text" => "AcmPbs_PlausPsBlsTh1" , "Level" => "2"},
		"5" => { "Name" => "DTC_5" , "Display_Code" => "P057100" , "Text" => "AcmPbs_PlausPsBlsTh3" , "Level" => "2"},
		"7" => { "Name" => "DTC_7" , "Display_Code" => "C101504" , "Text" => "AcmPs_OffsetMC1" , "Level" => "1"},
		"A" => { "Name" => "DTC_10" , "Display_Code" => "C101504" , "Text" => "AcmPs_TestpulseMC1" , "Level" => "1"},
		"D" => { "Name" => "DTC_13" , "Display_Code" => "C104B29" , "Text" => "Axs_Offset" , "Level" => "2"},
		"E" => { "Name" => "DTC_14" , "Display_Code" => "C104B29" , "Text" => "Axs_Plaus" , "Level" => "2"},
		"F" => { "Name" => "DTC_15" , "Display_Code" => "C104B29" , "Text" => "Ays_MonOffset" , "Level" => "2"},
		"11" => { "Name" => "DTC_17" , "Display_Code" => "C104B29" , "Text" => "Ays_PlausLimVal" , "Level" => "2"},
		"12" => { "Name" => "DTC_18" , "Display_Code" => "C104B29" , "Text" => "Ays_PlausValidity" , "Level" => "2"},
		"13" => { "Name" => "DTC_19" , "Display_Code" => "C104B29" , "Text" => "Ays_Standstill" , "Level" => "2"},
		"14" => { "Name" => "DTC_20" , "Display_Code" => "B200000" , "Text" => "BERT_FAULT" , "Level" => "1"},
		"15" => { "Name" => "DTC_21" , "Display_Code" => "P057100" , "Text" => "BlsLine" , "Level" => "2"},
		"18" => { "Name" => "DTC_24" , "Display_Code" => "B200000" , "Text" => "CCM_FAULT" , "Level" => "1"},
		"5E" => { "Name" => "DTC_94" , "Display_Code" => "B200000" , "Text" => "DeadlineMonTaskx1Ovr" , "Level" => "1"},
		"73" => { "Name" => "DTC_115" , "Display_Code" => "B200000" , "Text" => "ESMSafety_FAULT" , "Level" => "1"},
		"74" => { "Name" => "DTC_116" , "Display_Code" => "B200000" , "Text" => "ESM_NMI_FAULT" , "Level" => "1"},
		"75" => { "Name" => "DTC_117" , "Display_Code" => "B200000" , "Text" => "EcuADCConversionError" , "Level" => "1"},
		"76" => { "Name" => "DTC_118" , "Display_Code" => "B200000" , "Text" => "EcuBandGap" , "Level" => "1"},
		"77" => { "Name" => "DTC_119" , "Display_Code" => "B200000" , "Text" => "EcuEnContinuousError" , "Level" => "1"},
		"79" => { "Name" => "DTC_121" , "Display_Code" => "B200000" , "Text" => "EcuEnableHyFails" , "Level" => "1"},
		"7A" => { "Name" => "DTC_122" , "Display_Code" => "B200000" , "Text" => "EcuErrpinCounterTestFails" , "Level" => "1"},
		"7B" => { "Name" => "DTC_123" , "Display_Code" => "B200000" , "Text" => "EcuHETException" , "Level" => "1"},
		"7C" => { "Name" => "DTC_124" , "Display_Code" => "B200000" , "Text" => "EcuHETTUAddressingError" , "Level" => "1"},
		"7D" => { "Name" => "DTC_125" , "Display_Code" => "B200000" , "Text" => "EcuHETTUBusError" , "Level" => "1"},
		"7E" => { "Name" => "DTC_126" , "Display_Code" => "B200000" , "Text" => "EcuHETTUBusyError" , "Level" => "1"},
		"7F" => { "Name" => "DTC_127" , "Display_Code" => "B200000" , "Text" => "EcuHETTUException" , "Level" => "1"},
		"80" => { "Name" => "DTC_128" , "Display_Code" => "B200000" , "Text" => "EcuRomCheck" , "Level" => "1"},
		"81" => { "Name" => "DTC_129" , "Display_Code" => "B200000" , "Text" => "EcuTaskMissing" , "Level" => "1"},
		"82" => { "Name" => "DTC_130" , "Display_Code" => "B200000" , "Text" => "EcuVrOnWhileWdTimeout" , "Level" => "1"},
		"83" => { "Name" => "DTC_131" , "Display_Code" => "B200000" , "Text" => "EcuVrViaSpiFails" , "Level" => "1"},
		"84" => { "Name" => "DTC_132" , "Display_Code" => "B200000" , "Text" => "EcuWdErrCntContinuousError" , "Level" => "1"},
		"85" => { "Name" => "DTC_133" , "Display_Code" => "B200000" , "Text" => "EcuWdScheduleTimeout" , "Level" => "1"},
		"86" => { "Name" => "DTC_134" , "Display_Code" => "B200000" , "Text" => "EcuWdStartuptestFails" , "Level" => "1"},
		"87" => { "Name" => "DTC_135" , "Display_Code" => "B200000" , "Text" => "EcuWdStatusContinuousError" , "Level" => "1"},
		"8E" => { "Name" => "DTC_142" , "Display_Code" => "U140000" , "Text" => "HydraulicSupplyUndervoltage" , "Level" => "6"},
		"90" => { "Name" => "DTC_144" , "Display_Code" => "B200000" , "Text" => "MicIntVoltMonCompFail" , "Level" => "1"},
		"92" => { "Name" => "DTC_146" , "Display_Code" => "B200000" , "Text" => "MicSpiTransferError" , "Level" => "1"},
		"A8" => { "Name" => "DTC_168" , "Display_Code" => "B200000" , "Text" => "OSErrorHook" , "Level" => "1"},
		"AB" => { "Name" => "DTC_171" , "Display_Code" => "B200000" , "Text" => "PBISTError" , "Level" => "1"},
		"B1" => { "Name" => "DTC_177" , "Display_Code" => "C101504" , "Text" => "PressSensMC1Line" , "Level" => "2"},
		"B8" => { "Name" => "DTC_184" , "Display_Code" => "B200000" , "Text" => "RAMInitError" , "Level" => "1"},
		"B9" => { "Name" => "DTC_185" , "Display_Code" => "B200000" , "Text" => "RAMSINLGE_FAULT" , "Level" => "1"},
		"BB" => { "Name" => "DTC_187" , "Display_Code" => "C109E29" , "Text" => "ReverseGearHigh" , "Level" => "2"},
		"BC" => { "Name" => "DTC_188" , "Display_Code" => "C109E29" , "Text" => "ReverseGearLow" , "Level" => "2"},
		"C0" => { "Name" => "DTC_192" , "Display_Code" => "B200000" , "Text" => "RfpIFSTestFailed" , "Level" => "1"},
		"C1" => { "Name" => "DTC_193" , "Display_Code" => "B200000" , "Text" => "RfpMRAuCLineTestFailed" , "Level" => "1"},
		"C2" => { "Name" => "DTC_194" , "Display_Code" => "C101816" , "Text" => "RfpMRDSupplyError" , "Level" => "2"},
		"C3" => { "Name" => "DTC_195" , "Display_Code" => "C101504" , "Text" => "RfpMRGInverseTestFailed" , "Level" => "1"},
		"C4" => { "Name" => "DTC_196" , "Display_Code" => "C101504" , "Text" => "RfpMRGTestFailed" , "Level" => "1"},
		"C5" => { "Name" => "DTC_197" , "Display_Code" => "C101504" , "Text" => "RfpMRPUTestFailed" , "Level" => "1"},
		"C7" => { "Name" => "DTC_199" , "Display_Code" => "B200000" , "Text" => "RfpMRolError" , "Level" => "1"},
		"C8" => { "Name" => "DTC_200" , "Display_Code" => "B200000" , "Text" => "RfpMRscError" , "Level" => "1"},
		"CA" => { "Name" => "DTC_202" , "Display_Code" => "C101811" , "Text" => "RfpStopMonFailed" , "Level" => "2"},
		"108" => { "Name" => "DTC_264" , "Display_Code" => "B200000" , "Text" => "SYSErrorHook" , "Level" => "1"},
		"10B" => { "Name" => "DTC_267" , "Display_Code" => "U111200" , "Text" => "Sas_MonConstSig" , "Level" => "2"},
		"10C" => { "Name" => "DTC_268" , "Display_Code" => "U111200" , "Text" => "Sas_MonGrad" , "Level" => "2"},
		"10E" => { "Name" => "DTC_270" , "Display_Code" => "U111200" , "Text" => "Sas_MonMsgCnt" , "Level" => "2"},
		"10F" => { "Name" => "DTC_271" , "Display_Code" => "B116829" , "Text" => "Sas_MonOffset" , "Level" => "2"},
		"110" => { "Name" => "DTC_272" , "Display_Code" => "B116829" , "Text" => "Sas_MonRange" , "Level" => "2"},
		"111" => { "Name" => "DTC_273" , "Display_Code" => "B116829" , "Text" => "Sas_PlausYrs" , "Level" => "2"},
		"112" => { "Name" => "DTC_274" , "Display_Code" => "B116807" , "Text" => "Sas_Sign" , "Level" => "2"},
		"113" => { "Name" => "DTC_275" , "Display_Code" => "B200000" , "Text" => "StackOverUnderFlow" , "Level" => "1"},
		"115" => { "Name" => "DTC_277" , "Display_Code" => "B200000" , "Text" => "UC_SAFETY_FAULT" , "Level" => "1"},
		"11A" => { "Name" => "DTC_282" , "Display_Code" => "C101504" , "Text" => "ValveAvFlGeneric" , "Level" => "1"},
		"11B" => { "Name" => "DTC_283" , "Display_Code" => "B200000" , "Text" => "ValveAvFlQx" , "Level" => "1"},
		"11C" => { "Name" => "DTC_284" , "Display_Code" => "C101504" , "Text" => "ValveAvFlResOutOfRange" , "Level" => "1"},
		"11D" => { "Name" => "DTC_285" , "Display_Code" => "C101504" , "Text" => "ValveAvFlSvdt" , "Level" => "1"},
		"11F" => { "Name" => "DTC_287" , "Display_Code" => "C101504" , "Text" => "ValveAvFrGeneric" , "Level" => "1"},
		"120" => { "Name" => "DTC_288" , "Display_Code" => "B200000" , "Text" => "ValveAvFrQx" , "Level" => "1"},
		"121" => { "Name" => "DTC_289" , "Display_Code" => "C101504" , "Text" => "ValveAvFrResOutOfRange" , "Level" => "1"},
		"122" => { "Name" => "DTC_290" , "Display_Code" => "C101504" , "Text" => "ValveAvFrSvdt" , "Level" => "1"},
		"124" => { "Name" => "DTC_292" , "Display_Code" => "C101504" , "Text" => "ValveAvRlGeneric" , "Level" => "1"},
		"125" => { "Name" => "DTC_293" , "Display_Code" => "B200000" , "Text" => "ValveAvRlQx" , "Level" => "1"},
		"126" => { "Name" => "DTC_294" , "Display_Code" => "C101504" , "Text" => "ValveAvRlResOutOfRange" , "Level" => "1"},
		"127" => { "Name" => "DTC_295" , "Display_Code" => "C101504" , "Text" => "ValveAvRlSvdt" , "Level" => "1"},
		"129" => { "Name" => "DTC_297" , "Display_Code" => "C101504" , "Text" => "ValveAvRrGeneric" , "Level" => "1"},
		"12A" => { "Name" => "DTC_298" , "Display_Code" => "B200000" , "Text" => "ValveAvRrQx" , "Level" => "1"},
		"12B" => { "Name" => "DTC_299" , "Display_Code" => "C101504" , "Text" => "ValveAvRrResOutOfRange" , "Level" => "1"},
		"12C" => { "Name" => "DTC_300" , "Display_Code" => "C101504" , "Text" => "ValveAvRrSvdt" , "Level" => "1"},
		"12E" => { "Name" => "DTC_302" , "Display_Code" => "C101504" , "Text" => "ValveEvFlGeneric" , "Level" => "1"},
		"12F" => { "Name" => "DTC_303" , "Display_Code" => "B200000" , "Text" => "ValveEvFlQx" , "Level" => "1"},
		"130" => { "Name" => "DTC_304" , "Display_Code" => "C101504" , "Text" => "ValveEvFlResOutOfRange" , "Level" => "1"},
		"131" => { "Name" => "DTC_305" , "Display_Code" => "C101504" , "Text" => "ValveEvFlSvdt" , "Level" => "1"},
		"133" => { "Name" => "DTC_307" , "Display_Code" => "C101504" , "Text" => "ValveEvFrGeneric" , "Level" => "1"},
		"134" => { "Name" => "DTC_308" , "Display_Code" => "B200000" , "Text" => "ValveEvFrQx" , "Level" => "1"},
		"135" => { "Name" => "DTC_309" , "Display_Code" => "C101504" , "Text" => "ValveEvFrResOutOfRange" , "Level" => "1"},
		"136" => { "Name" => "DTC_310" , "Display_Code" => "C101504" , "Text" => "ValveEvFrSvdt" , "Level" => "1"},
		"138" => { "Name" => "DTC_312" , "Display_Code" => "C101504" , "Text" => "ValveEvRlGeneric" , "Level" => "1"},
		"139" => { "Name" => "DTC_313" , "Display_Code" => "B200000" , "Text" => "ValveEvRlQx" , "Level" => "1"},
		"13A" => { "Name" => "DTC_314" , "Display_Code" => "C101504" , "Text" => "ValveEvRlResOutOfRange" , "Level" => "1"},
		"13B" => { "Name" => "DTC_315" , "Display_Code" => "C101504" , "Text" => "ValveEvRlSvdt" , "Level" => "1"},
		"13D" => { "Name" => "DTC_317" , "Display_Code" => "C101504" , "Text" => "ValveEvRrGeneric" , "Level" => "1"},
		"13E" => { "Name" => "DTC_318" , "Display_Code" => "B200000" , "Text" => "ValveEvRrQx" , "Level" => "1"},
		"13F" => { "Name" => "DTC_319" , "Display_Code" => "C101504" , "Text" => "ValveEvRrResOutOfRange" , "Level" => "1"},
		"140" => { "Name" => "DTC_320" , "Display_Code" => "C101504" , "Text" => "ValveEvRrSvdt" , "Level" => "1"},
		"142" => { "Name" => "DTC_322" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Generic" , "Level" => "1"},
		"143" => { "Name" => "DTC_323" , "Display_Code" => "B200000" , "Text" => "ValveHsv1Qx" , "Level" => "1"},
		"144" => { "Name" => "DTC_324" , "Display_Code" => "C101504" , "Text" => "ValveHsv1ResOutOfRange" , "Level" => "1"},
		"145" => { "Name" => "DTC_325" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Svdt" , "Level" => "1"},
		"147" => { "Name" => "DTC_327" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Generic" , "Level" => "1"},
		"148" => { "Name" => "DTC_328" , "Display_Code" => "B200000" , "Text" => "ValveHsv2Qx" , "Level" => "1"},
		"149" => { "Name" => "DTC_329" , "Display_Code" => "C101504" , "Text" => "ValveHsv2ResOutOfRange" , "Level" => "1"},
		"14A" => { "Name" => "DTC_330" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Svdt" , "Level" => "1"},
		"14C" => { "Name" => "DTC_332" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Generic" , "Level" => "1"},
		"14D" => { "Name" => "DTC_333" , "Display_Code" => "B200000" , "Text" => "ValveUsv1Qx" , "Level" => "1"},
		"14E" => { "Name" => "DTC_334" , "Display_Code" => "C101504" , "Text" => "ValveUsv1ResOutOfRange" , "Level" => "1"},
		"14F" => { "Name" => "DTC_335" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Svdt" , "Level" => "1"},
		"151" => { "Name" => "DTC_337" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Generic" , "Level" => "1"},
		"152" => { "Name" => "DTC_338" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Qx" , "Level" => "1"},
		"153" => { "Name" => "DTC_339" , "Display_Code" => "C101504" , "Text" => "ValveUsv2ResOutOfRange" , "Level" => "1"},
		"154" => { "Name" => "DTC_340" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Svdt" , "Level" => "1"},
		"155" => { "Name" => "DTC_341" , "Display_Code" => "C1069F0" , "Text" => "Vdc_ContControl" , "Level" => "2"},
		"156" => { "Name" => "DTC_342" , "Display_Code" => "B200000" , "Text" => "VrHighOhmicShortToGndContinuous" , "Level" => "1"},
		"157" => { "Name" => "DTC_343" , "Display_Code" => "B200000" , "Text" => "VrOnFails" , "Level" => "1"},
		"158" => { "Name" => "DTC_344" , "Display_Code" => "B200000" , "Text" => "VrOnFailsContinuous" , "Level" => "1"},
		"15A" => { "Name" => "DTC_346" , "Display_Code" => "B200000" , "Text" => "VrShortToGndContinuous" , "Level" => "1"},
		"15B" => { "Name" => "DTC_347" , "Display_Code" => "B200000" , "Text" => "VrStuck" , "Level" => "1"},
		"15C" => { "Name" => "DTC_348" , "Display_Code" => "B200000" , "Text" => "VrStuckContinuous" , "Level" => "1"},
		"15D" => { "Name" => "DTC_349" , "Display_Code" => "B200000" , "Text" => "WSSHetMonMuxSigError" , "Level" => "1"},
		"160" => { "Name" => "DTC_352" , "Display_Code" => "C101A07" , "Text" => "WssFLAirGap" , "Level" => "2"},
		"162" => { "Name" => "DTC_354" , "Display_Code" => "C101A01" , "Text" => "WssFLLineFail" , "Level" => "2"},
		"163" => { "Name" => "DTC_355" , "Display_Code" => "C101A14" , "Text" => "WssFLLineGnd" , "Level" => "2"},
		"164" => { "Name" => "DTC_356" , "Display_Code" => "C101A12" , "Text" => "WssFLLineHigh" , "Level" => "2"},
		"165" => { "Name" => "DTC_357" , "Display_Code" => "C101A01" , "Text" => "WssFLLineUndef" , "Level" => "2"},
		"166" => { "Name" => "DTC_358" , "Display_Code" => "C101A01" , "Text" => "WssFLNoEdge" , "Level" => "2"},
		"169" => { "Name" => "DTC_361" , "Display_Code" => "C101A11" , "Text" => "WssFLSupplyGnd" , "Level" => "2"},
		"16A" => { "Name" => "DTC_362" , "Display_Code" => "C101B07" , "Text" => "WssFRAirGap" , "Level" => "2"},
		"16C" => { "Name" => "DTC_364" , "Display_Code" => "C101B01" , "Text" => "WssFRLineFail" , "Level" => "2"},
		"16D" => { "Name" => "DTC_365" , "Display_Code" => "C101B14" , "Text" => "WssFRLineGnd" , "Level" => "2"},
		"16E" => { "Name" => "DTC_366" , "Display_Code" => "C101B12" , "Text" => "WssFRLineHigh" , "Level" => "2"},
		"16F" => { "Name" => "DTC_367" , "Display_Code" => "C101B01" , "Text" => "WssFRLineUndef" , "Level" => "2"},
		"170" => { "Name" => "DTC_368" , "Display_Code" => "C101B01" , "Text" => "WssFRNoEdge" , "Level" => "2"},
		"173" => { "Name" => "DTC_371" , "Display_Code" => "C101B11" , "Text" => "WssFRSupplyGnd" , "Level" => "2"},
		"174" => { "Name" => "DTC_372" , "Display_Code" => "C101C07" , "Text" => "WssRLAirGap" , "Level" => "2"},
		"176" => { "Name" => "DTC_374" , "Display_Code" => "C101C01" , "Text" => "WssRLLineFail" , "Level" => "2"},
		"177" => { "Name" => "DTC_375" , "Display_Code" => "C101C14" , "Text" => "WssRLLineGnd" , "Level" => "2"},
		"178" => { "Name" => "DTC_376" , "Display_Code" => "C101C12" , "Text" => "WssRLLineHigh" , "Level" => "2"},
		"179" => { "Name" => "DTC_377" , "Display_Code" => "C101C01" , "Text" => "WssRLLineUndef" , "Level" => "2"},
		"17A" => { "Name" => "DTC_378" , "Display_Code" => "C101C01" , "Text" => "WssRLNoEdge" , "Level" => "2"},
		"17D" => { "Name" => "DTC_381" , "Display_Code" => "C101C11" , "Text" => "WssRLSupplyGnd" , "Level" => "2"},
		"17E" => { "Name" => "DTC_382" , "Display_Code" => "C101D07" , "Text" => "WssRRAirGap" , "Level" => "2"},
		"180" => { "Name" => "DTC_384" , "Display_Code" => "C101D01" , "Text" => "WssRRLineFail" , "Level" => "2"},
		"181" => { "Name" => "DTC_385" , "Display_Code" => "C101D14" , "Text" => "WssRRLineGnd" , "Level" => "2"},
		"182" => { "Name" => "DTC_386" , "Display_Code" => "C101D12" , "Text" => "WssRRLineHigh" , "Level" => "2"},
		"183" => { "Name" => "DTC_387" , "Display_Code" => "C101D01" , "Text" => "WssRRLineUndef" , "Level" => "2"},
		"184" => { "Name" => "DTC_388" , "Display_Code" => "C101D01" , "Text" => "WssRRNoEdge" , "Level" => "2"},
		"187" => { "Name" => "DTC_391" , "Display_Code" => "C101D11" , "Text" => "WssRRSupplyGnd" , "Level" => "2"},
		"188" => { "Name" => "DTC_392" , "Display_Code" => "C101A01" , "Text" => "WssTestFLFailure" , "Level" => "2"},
		"189" => { "Name" => "DTC_393" , "Display_Code" => "C101B01" , "Text" => "WssTestFRFailure" , "Level" => "2"},
		"18A" => { "Name" => "DTC_394" , "Display_Code" => "C101C01" , "Text" => "WssTestRLFailure" , "Level" => "2"},
		"18B" => { "Name" => "DTC_395" , "Display_Code" => "C101D01" , "Text" => "WssTestRRFailure" , "Level" => "2"},
		"18C" => { "Name" => "DTC_396" , "Display_Code" => "B200000" , "Text" => "WssTestSystemICFailure" , "Level" => "1"},
		"18D" => { "Name" => "DTC_397" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDoHi_FL" , "Level" => "2"},
		"18E" => { "Name" => "DTC_398" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDoHi_FR" , "Level" => "2"},
		"18F" => { "Name" => "DTC_399" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDoHi_RL" , "Level" => "2"},
		"190" => { "Name" => "DTC_400" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDoHi_RR" , "Level" => "2"},
		"191" => { "Name" => "DTC_401" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDoLo_FL" , "Level" => "2"},
		"192" => { "Name" => "DTC_402" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDoLo_FR" , "Level" => "2"},
		"193" => { "Name" => "DTC_403" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDoLo_RL" , "Level" => "2"},
		"194" => { "Name" => "DTC_404" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDoLo_RR" , "Level" => "2"},
		"195" => { "Name" => "DTC_405" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDyn_FL" , "Level" => "2"},
		"196" => { "Name" => "DTC_406" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDyn_FR" , "Level" => "2"},
		"197" => { "Name" => "DTC_407" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDyn_RL" , "Level" => "2"},
		"198" => { "Name" => "DTC_408" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDyn_RR" , "Level" => "2"},
		"199" => { "Name" => "DTC_409" , "Display_Code" => "C106B29" , "Text" => "Wss_MonGenericTempFail" , "Level" => "2"},
		"19A" => { "Name" => "DTC_410" , "Display_Code" => "C101A29" , "Text" => "Wss_MonNoise_FL" , "Level" => "2"},
		"19B" => { "Name" => "DTC_411" , "Display_Code" => "C101B29" , "Text" => "Wss_MonNoise_FR" , "Level" => "2"},
		"19C" => { "Name" => "DTC_412" , "Display_Code" => "C101C29" , "Text" => "Wss_MonNoise_RL" , "Level" => "2"},
		"19D" => { "Name" => "DTC_413" , "Display_Code" => "C101D29" , "Text" => "Wss_MonNoise_RR" , "Level" => "2"},
		"19E" => { "Name" => "DTC_414" , "Display_Code" => "C101A29" , "Text" => "Wss_MonRange_FL" , "Level" => "2"},
		"19F" => { "Name" => "DTC_415" , "Display_Code" => "C101B29" , "Text" => "Wss_MonRange_FR" , "Level" => "2"},
		"1A0" => { "Name" => "DTC_416" , "Display_Code" => "C101C29" , "Text" => "Wss_MonRange_RL" , "Level" => "2"},
		"1A1" => { "Name" => "DTC_417" , "Display_Code" => "C101D29" , "Text" => "Wss_MonRange_RR" , "Level" => "2"},
		"1A2" => { "Name" => "DTC_418" , "Display_Code" => "C101A29" , "Text" => "Wss_MonVDiff_FL" , "Level" => "2"},
		"1A3" => { "Name" => "DTC_419" , "Display_Code" => "C101B29" , "Text" => "Wss_MonVDiff_FR" , "Level" => "2"},
		"1A4" => { "Name" => "DTC_420" , "Display_Code" => "C106B29" , "Text" => "Wss_MonVDiff_Gen" , "Level" => "2"},
		"1A5" => { "Name" => "DTC_421" , "Display_Code" => "C101C29" , "Text" => "Wss_MonVDiff_RL" , "Level" => "2"},
		"1A6" => { "Name" => "DTC_422" , "Display_Code" => "C101D29" , "Text" => "Wss_MonVDiff_RR" , "Level" => "2"},
		"1A7" => { "Name" => "DTC_423" , "Display_Code" => "C106B07" , "Text" => "Wss_SignFA" , "Level" => "2"},
		"1A8" => { "Name" => "DTC_424" , "Display_Code" => "C106B07" , "Text" => "Wss_SignRA" , "Level" => "2"},
		"1AD" => { "Name" => "DTC_429" , "Display_Code" => "C104B29" , "Text" => "Yrs_FastOffset1" , "Level" => "2"},
		"1AE" => { "Name" => "DTC_430" , "Display_Code" => "C104B29" , "Text" => "Yrs_FastOffset2" , "Level" => "2"},
		"1AF" => { "Name" => "DTC_431" , "Display_Code" => "C104B29" , "Text" => "Yrs_Gain" , "Level" => "2"},
		"1B0" => { "Name" => "DTC_432" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonGrad" , "Level" => "2"},
		"1B2" => { "Name" => "DTC_434" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonRangeDriving" , "Level" => "2"},
		"1B4" => { "Name" => "DTC_436" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonRangeVehStandstill" , "Level" => "2"},
		"1B5" => { "Name" => "DTC_437" , "Display_Code" => "C104B29" , "Text" => "Yrs_NormalOffset" , "Level" => "2"},
		"1B6" => { "Name" => "DTC_438" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausLimVal" , "Level" => "2"},
		"1B7" => { "Name" => "DTC_439" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausSas" , "Level" => "2"},
		"1B8" => { "Name" => "DTC_440" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausValidity" , "Level" => "2"},
		"1B9" => { "Name" => "DTC_441" , "Display_Code" => "C104B29" , "Text" => "Yrs_Sign" , "Level" => "2"},
		"1BA" => { "Name" => "DTC_442" , "Display_Code" => "C104B29" , "Text" => "Yrs_StandstillComp" , "Level" => "2"},
		"1C1" => { "Name" => "DTC_449" , "Display_Code" => "B200000" , "Text" => "MicInitSpiTestFail" , "Level" => "1"},
		"1C2" => { "Name" => "DTC_450" , "Display_Code" => "U101200" , "Text" => "SupplyOvervoltage" , "Level" => "2"},
		"1C3" => { "Name" => "DTC_451" , "Display_Code" => "B200000" , "Text" => "EcuWdFaultCounterTestFails" , "Level" => "1"},
		"1C8" => { "Name" => "DTC_456" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Vdc" , "Level" => "1"},
		"1C9" => { "Name" => "DTC_457" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Vdc" , "Level" => "1"},
		"1CA" => { "Name" => "DTC_458" , "Display_Code" => "B200000" , "Text" => "EcuWssDfaConfFail" , "Level" => "1"},
		"1CB" => { "Name" => "DTC_459" , "Display_Code" => "B200000" , "Text" => "CPUException" , "Level" => "1"},
		"1CE" => { "Name" => "DTC_462" , "Display_Code" => "U140000" , "Text" => "NET_Undervoltage" , "Level" => "2"},
		"1D3" => { "Name" => "DTC_467" , "Display_Code" => "B200000" , "Text" => "VlvBist" , "Level" => "1"},
		"1D9" => { "Name" => "DTC_473" , "Display_Code" => "C101504" , "Text" => "AcmHyd_ReturnPumpGenVoltageHigh" , "Level" => "1"},
		"1DA" => { "Name" => "DTC_474" , "Display_Code" => "C101504" , "Text" => "AcmHyd_ReturnPumpWeak" , "Level" => "1"},
		"1E7" => { "Name" => "DTC_487" , "Display_Code" => "C104B29" , "Text" => "Axs_MonConstSig" , "Level" => "2"},
		"1E8" => { "Name" => "DTC_488" , "Display_Code" => "C104B29" , "Text" => "Axs_PlausHighAccel" , "Level" => "2"},
		"1EA" => { "Name" => "DTC_490" , "Display_Code" => "C10C2F2" , "Text" => "AcmBtm_OverheatDuringActiveBraking" , "Level" => "6"},
		"1F1" => { "Name" => "DTC_497" , "Display_Code" => "C106B29" , "Text" => "Wss_MoreThanOneSuspectedStore" , "Level" => "2"},
		"20D" => { "Name" => "DTC_525" , "Display_Code" => "B200000" , "Text" => "ValveAvFlLeakage" , "Level" => "1"},
		"20E" => { "Name" => "DTC_526" , "Display_Code" => "B200000" , "Text" => "ValveAvFrLeakage" , "Level" => "1"},
		"20F" => { "Name" => "DTC_527" , "Display_Code" => "B200000" , "Text" => "ValveAvRlLeakage" , "Level" => "1"},
		"210" => { "Name" => "DTC_528" , "Display_Code" => "B200000" , "Text" => "ValveAvRrLeakage" , "Level" => "1"},
		"211" => { "Name" => "DTC_529" , "Display_Code" => "B200000" , "Text" => "ValveEvFlLeakage" , "Level" => "1"},
		"212" => { "Name" => "DTC_530" , "Display_Code" => "B200000" , "Text" => "ValveEvFrLeakage" , "Level" => "1"},
		"213" => { "Name" => "DTC_531" , "Display_Code" => "B200000" , "Text" => "ValveEvRlLeakage" , "Level" => "1"},
		"214" => { "Name" => "DTC_532" , "Display_Code" => "B200000" , "Text" => "ValveEvRrLeakage" , "Level" => "1"},
		"215" => { "Name" => "DTC_533" , "Display_Code" => "B200000" , "Text" => "ValveHsv1Leakage" , "Level" => "1"},
		"216" => { "Name" => "DTC_534" , "Display_Code" => "B200000" , "Text" => "ValveHsv2Leakage" , "Level" => "1"},
		"217" => { "Name" => "DTC_535" , "Display_Code" => "B200000" , "Text" => "ValveUsv1Leakage" , "Level" => "1"},
		"218" => { "Name" => "DTC_536" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Leakage" , "Level" => "1"},
		"219" => { "Name" => "DTC_537" , "Display_Code" => "B200000" , "Text" => "ValveFreeWheelingContOn" , "Level" => "1"},
		"21A" => { "Name" => "DTC_538" , "Display_Code" => "B2008F0" , "Text" => "ValveOverHeatProtection" , "Level" => "6"},
		"21B" => { "Name" => "DTC_539" , "Display_Code" => "B200000" , "Text" => "ValvePwmCheckContOn" , "Level" => "1"},
		"221" => { "Name" => "DTC_545" , "Display_Code" => "C101A29" , "Text" => "WssFLHetBufNoise" , "Level" => "2"},
		"222" => { "Name" => "DTC_546" , "Display_Code" => "C101B29" , "Text" => "WssFRHetBufNoise" , "Level" => "2"},
		"223" => { "Name" => "DTC_547" , "Display_Code" => "C101C29" , "Text" => "WssRLHetBufNoise" , "Level" => "2"},
		"224" => { "Name" => "DTC_548" , "Display_Code" => "C101D29" , "Text" => "WssRRHetBufNoise" , "Level" => "2"},
		"225" => { "Name" => "DTC_549" , "Display_Code" => "C106B16" , "Text" => "WssUndervoltage" , "Level" => "2"},
		"229" => { "Name" => "DTC_553" , "Display_Code" => "B2008F0" , "Text" => "RfpDiagHydrProtection" , "Level" => "6"},
		"22A" => { "Name" => "DTC_554" , "Display_Code" => "B200000" , "Text" => "RfpPMTFailed" , "Level" => "1"},
		"22B" => { "Name" => "DTC_555" , "Display_Code" => "B200000" , "Text" => "MicSpiTimeOut" , "Level" => "1"},
		"22D" => { "Name" => "DTC_557" , "Display_Code" => "U000100" , "Text" => "NET_BusOffNetwork0" , "Level" => "2"},
		"22F" => { "Name" => "DTC_559" , "Display_Code" => "U101200" , "Text" => "NET_Overvoltage" , "Level" => "2"},
		"231" => { "Name" => "DTC_561" , "Display_Code" => "B200000" , "Text" => "CUBAS_CAN_E_Timeout" , "Level" => "1"},
		"233" => { "Name" => "DTC_563" , "Display_Code" => "C101504" , "Text" => "ValveAvFlVart" , "Level" => "1"},
		"234" => { "Name" => "DTC_564" , "Display_Code" => "C101504" , "Text" => "ValveAvFrVart" , "Level" => "1"},
		"235" => { "Name" => "DTC_565" , "Display_Code" => "C101504" , "Text" => "ValveAvRlVart" , "Level" => "1"},
		"236" => { "Name" => "DTC_566" , "Display_Code" => "C101504" , "Text" => "ValveAvRrVart" , "Level" => "1"},
		"237" => { "Name" => "DTC_567" , "Display_Code" => "C101504" , "Text" => "ValveEvFlVart" , "Level" => "1"},
		"238" => { "Name" => "DTC_568" , "Display_Code" => "C101504" , "Text" => "ValveEvFrVart" , "Level" => "1"},
		"239" => { "Name" => "DTC_569" , "Display_Code" => "C101504" , "Text" => "ValveEvRlVart" , "Level" => "1"},
		"23A" => { "Name" => "DTC_570" , "Display_Code" => "C101504" , "Text" => "ValveEvRrVart" , "Level" => "1"},
		"23B" => { "Name" => "DTC_571" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Vart" , "Level" => "1"},
		"23C" => { "Name" => "DTC_572" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Vart" , "Level" => "1"},
		"23D" => { "Name" => "DTC_573" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Vart" , "Level" => "1"},
		"23E" => { "Name" => "DTC_574" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Vart" , "Level" => "1"},
		"23F" => { "Name" => "DTC_575" , "Display_Code" => "C101504" , "Text" => "ValveAvFlPwm" , "Level" => "1"},
		"240" => { "Name" => "DTC_576" , "Display_Code" => "C101504" , "Text" => "ValveAvFrPwm" , "Level" => "1"},
		"241" => { "Name" => "DTC_577" , "Display_Code" => "C101504" , "Text" => "ValveAvRlPwm" , "Level" => "1"},
		"242" => { "Name" => "DTC_578" , "Display_Code" => "C101504" , "Text" => "ValveAvRrPwm" , "Level" => "1"},
		"243" => { "Name" => "DTC_579" , "Display_Code" => "C101504" , "Text" => "ValveEvFlPwm" , "Level" => "1"},
		"244" => { "Name" => "DTC_580" , "Display_Code" => "C101504" , "Text" => "ValveEvFrPwm" , "Level" => "1"},
		"245" => { "Name" => "DTC_581" , "Display_Code" => "C101504" , "Text" => "ValveEvRlPwm" , "Level" => "1"},
		"246" => { "Name" => "DTC_582" , "Display_Code" => "C101504" , "Text" => "ValveEvRrPwm" , "Level" => "1"},
		"247" => { "Name" => "DTC_583" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Pwm" , "Level" => "1"},
		"248" => { "Name" => "DTC_584" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Pwm" , "Level" => "1"},
		"249" => { "Name" => "DTC_585" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Pwm" , "Level" => "1"},
		"24A" => { "Name" => "DTC_586" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Pwm" , "Level" => "1"},
		"24B" => { "Name" => "DTC_587" , "Display_Code" => "B200000" , "Text" => "VlvINxFailure" , "Level" => "1"},
		"24C" => { "Name" => "DTC_588" , "Display_Code" => "B200000" , "Text" => "ValveReferenceResistor" , "Level" => "1"},
		"24D" => { "Name" => "DTC_589" , "Display_Code" => "B200000" , "Text" => "ValveReferenceEEPromError" , "Level" => "1"},
		"251" => { "Name" => "DTC_593" , "Display_Code" => "B200000" , "Text" => "VlvUVRmeasureComparisonFailure" , "Level" => "1"},
		"25C" => { "Name" => "DTC_604" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionFL" , "Level" => "2"},
		"25D" => { "Name" => "DTC_605" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionFR" , "Level" => "2"},
		"25E" => { "Name" => "DTC_606" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionRL" , "Level" => "2"},
		"25F" => { "Name" => "DTC_607" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionRR" , "Level" => "2"},
		"260" => { "Name" => "DTC_608" , "Display_Code" => "C109DF0" , "Text" => "RKA_ERROR_CODE_CAL_INCOMPLETE" , "Level" => "2"},
		"261" => { "Name" => "DTC_609" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_INCORRECTLY_EXECUTED" , "Level" => "2"},
		"262" => { "Name" => "DTC_610" , "Display_Code" => "B200000" , "Text" => "RKA_ERROR_CODE_INCORRECT_LIB" , "Level" => "2"},
		"263" => { "Name" => "DTC_611" , "Display_Code" => "B200000" , "Text" => "RKA_ERROR_CODE_INVALID_F_MAPING" , "Level" => "2"},
		"264" => { "Name" => "DTC_612" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_INVALID_V_MAPING" , "Level" => "2"},
		"265" => { "Name" => "DTC_613" , "Display_Code" => "C109DF0" , "Text" => "RKA_ERROR_CODE_LOW_AVAILABILITY" , "Level" => "2"},
		"266" => { "Name" => "DTC_614" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_PermanentEepromAccess" , "Level" => "2"},
		"267" => { "Name" => "DTC_615" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_FL" , "Level" => "2"},
		"268" => { "Name" => "DTC_616" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_FR" , "Level" => "2"},
		"269" => { "Name" => "DTC_617" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_RL" , "Level" => "2"},
		"26A" => { "Name" => "DTC_618" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_RR" , "Level" => "2"},
		"26B" => { "Name" => "DTC_619" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_FL" , "Level" => "2"},
		"26C" => { "Name" => "DTC_620" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_FR" , "Level" => "2"},
		"26D" => { "Name" => "DTC_621" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_RL" , "Level" => "2"},
		"26E" => { "Name" => "DTC_622" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_RR" , "Level" => "2"},
		"26F" => { "Name" => "DTC_623" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_0" , "Level" => "2"},
		"270" => { "Name" => "DTC_624" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_1" , "Level" => "2"},
		"272" => { "Name" => "DTC_626" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_0" , "Level" => "2"},
		"273" => { "Name" => "DTC_627" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_1" , "Level" => "2"},
		"274" => { "Name" => "DTC_628" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_2" , "Level" => "2"},
		"275" => { "Name" => "DTC_629" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureFL" , "Level" => "2"},
		"276" => { "Name" => "DTC_630" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureFR" , "Level" => "2"},
		"277" => { "Name" => "DTC_631" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureRL" , "Level" => "2"},
		"278" => { "Name" => "DTC_632" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureRR" , "Level" => "2"},
		"292" => { "Name" => "DTC_658" , "Display_Code" => "C109C07" , "Text" => "PATA_HandbagLogic" , "Level" => "2"},
		"293" => { "Name" => "DTC_659" , "Display_Code" => "B200000" , "Text" => "PdmFieldSizeMismatch" , "Level" => "1"},
		"295" => { "Name" => "DTC_661" , "Display_Code" => "B200000" , "Text" => "PdmDeviceOutOfMemory" , "Level" => "1"},
		"296" => { "Name" => "DTC_662" , "Display_Code" => "B200000" , "Text" => "PdmCustomerIdMismatch" , "Level" => "1"},
		"297" => { "Name" => "DTC_663" , "Display_Code" => "B200000" , "Text" => "PdmDatFormatMismatch" , "Level" => "1"},
		"298" => { "Name" => "DTC_664" , "Display_Code" => "B200000" , "Text" => "PdmInternalHWError" , "Level" => "1"},
		"29E" => { "Name" => "DTC_670" , "Display_Code" => "B200000" , "Text" => "RTP_ENA_High" , "Level" => "1"},
		"2F3" => { "Name" => "DTC_755" , "Display_Code" => "B200000" , "Text" => "ValveEvFlFreeWheeling" , "Level" => "1"},
		"2F4" => { "Name" => "DTC_756" , "Display_Code" => "B200000" , "Text" => "ValveEvFrFreeWheeling" , "Level" => "1"},
		"2F5" => { "Name" => "DTC_757" , "Display_Code" => "B200000" , "Text" => "ValveEvRlFreeWheeling" , "Level" => "1"},
		"2F6" => { "Name" => "DTC_758" , "Display_Code" => "B200000" , "Text" => "ValveEvRrFreeWheeling" , "Level" => "1"},
		"2F7" => { "Name" => "DTC_759" , "Display_Code" => "B200000" , "Text" => "ValveHsv1FreeWheeling" , "Level" => "1"},
		"2F8" => { "Name" => "DTC_760" , "Display_Code" => "B200000" , "Text" => "ValveHsv2FreeWheeling" , "Level" => "1"},
		"2F9" => { "Name" => "DTC_761" , "Display_Code" => "B200000" , "Text" => "ValveUsv1FreeWheeling" , "Level" => "1"},
		"2FA" => { "Name" => "DTC_762" , "Display_Code" => "B200000" , "Text" => "ValveUsv2FreeWheeling" , "Level" => "1"},
		"2FB" => { "Name" => "DTC_763" , "Display_Code" => "B200000" , "Text" => "VlvAsicConfigEchoError" , "Level" => "1"},
		"2FC" => { "Name" => "DTC_764" , "Display_Code" => "B200000" , "Text" => "VlvUvrToUbvrLeakage" , "Level" => "1"},
		"2FD" => { "Name" => "DTC_765" , "Display_Code" => "B200000" , "Text" => "EcuADCSelftestError" , "Level" => "1"},
		"2FE" => { "Name" => "DTC_766" , "Display_Code" => "C106A16" , "Text" => "HydraulicSupplyHardUndervoltage" , "Level" => "2"},
		"2FF" => { "Name" => "DTC_767" , "Display_Code" => "C106B12" , "Text" => "WssReverseCurrent" , "Level" => "2"},
		"300" => { "Name" => "DTC_768" , "Display_Code" => "B200000" , "Text" => "WssModeFail" , "Level" => "1"},
		"302" => { "Name" => "DTC_770" , "Display_Code" => "B200000" , "Text" => "ValveInverseActTestFault" , "Level" => "1"},
		"317" => { "Name" => "DTC_791" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_MEMORY_PROTECTION" , "Level" => "2"},
		"318" => { "Name" => "DTC_792" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_RUNTIME_OVERFLOW" , "Level" => "2"},
		"31B" => { "Name" => "DTC_795" , "Display_Code" => "C101A01" , "Text" => "WssFLWrongSens" , "Level" => "2"},
		"31C" => { "Name" => "DTC_796" , "Display_Code" => "C101B01" , "Text" => "WssFRWrongSens" , "Level" => "2"},
		"31D" => { "Name" => "DTC_797" , "Display_Code" => "C101C01" , "Text" => "WssRLWrongSens" , "Level" => "2"},
		"31E" => { "Name" => "DTC_798" , "Display_Code" => "C101D01" , "Text" => "WssRRWrongSens" , "Level" => "2"},
		"333" => { "Name" => "DTC_819" , "Display_Code" => "B200000" , "Text" => "VlvOpenLoadUnderCurrentBitFailureVart" , "Level" => "1"},
		"347" => { "Name" => "DTC_839" , "Display_Code" => "B200000" , "Text" => "ValveSvdtContOn" , "Level" => "1"},
		"351" => { "Name" => "DTC_849" , "Display_Code" => "B200000" , "Text" => "VlvUvrLowSPIBitFailure" , "Level" => "1"},
		"352" => { "Name" => "DTC_850" , "Display_Code" => "C106A01" , "Text" => "VlvSupplyLineTest" , "Level" => "2"},
		"35E" => { "Name" => "DTC_862" , "Display_Code" => "B200000" , "Text" => "UnsupportedHardware" , "Level" => "1"},
		"35F" => { "Name" => "DTC_863" , "Display_Code" => "B200000" , "Text" => "MicIntMonGenericBitMon" , "Level" => "1"},
		"361" => { "Name" => "DTC_865" , "Display_Code" => "B200000" , "Text" => "VrSafetySwitchTestTimeout" , "Level" => "1"},
		"363" => { "Name" => "DTC_867" , "Display_Code" => "B200000" , "Text" => "STM_AswSystemTimeOut" , "Level" => "1"},
		"369" => { "Name" => "DTC_873" , "Display_Code" => "B200000" , "Text" => "VoltagePreRegModeFail" , "Level" => "1"},
		"36D" => { "Name" => "DTC_877" , "Display_Code" => "C10A700" , "Text" => "RollerBenchMode" , "Level" => "1"},
		"36F" => { "Name" => "DTC_879" , "Display_Code" => "U101100" , "Text" => "EcuSupplyVoltageDividerDrift" , "Level" => "1"},
		"370" => { "Name" => "DTC_880" , "Display_Code" => "U000100" , "Text" => "CUBAS_CAN_E_HW_ERROR" , "Level" => "2"},
		"371" => { "Name" => "DTC_881" , "Display_Code" => "U101300" , "Text" => "VehicleConfigPDMEmpty" , "Level" => "2"},
		"372" => { "Name" => "DTC_882" , "Display_Code" => "U101300" , "Text" => "VehicleConfigPDMReadError" , "Level" => "2"},
		"373" => { "Name" => "DTC_883" , "Display_Code" => "U101300" , "Text" => "VehicleConfigUncoded" , "Level" => "2"},
		"374" => { "Name" => "DTC_884" , "Display_Code" => "U101300" , "Text" => "VehicleConfigVarCodeNotFound" , "Level" => "2"},
		"375" => { "Name" => "DTC_885" , "Display_Code" => "U044700" , "Text" => "VarCheckNetVinTimeout" , "Level" => "2"},
		"376" => { "Name" => "DTC_886" , "Display_Code" => "U044700" , "Text" => "VarCheckNetVinNotinitialized" , "Level" => "2"},
		"377" => { "Name" => "DTC_887" , "Display_Code" => "C104AF0" , "Text" => "VarCheckVinSanityCheckFailed" , "Level" => "2"},
		"378" => { "Name" => "DTC_888" , "Display_Code" => "U101300" , "Text" => "VarCheckVariantNotFound" , "Level" => "2"},
		"379" => { "Name" => "DTC_889" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_GearboxTypeNotAvailable" , "Level" => "2"},
		"37A" => { "Name" => "DTC_890" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_GearboxPlausibilityError" , "Level" => "2"},
		"37B" => { "Name" => "DTC_891" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_SteeringPositionNotAvailable" , "Level" => "2"},
		"37C" => { "Name" => "DTC_892" , "Display_Code" => "U10BC00" , "Text" => "VarCodVehicleModelNotFound" , "Level" => "2"},
		"37D" => { "Name" => "DTC_893" , "Display_Code" => "U10BC00" , "Text" => "VarCodNetVinTimeout" , "Level" => "2"},
		"37E" => { "Name" => "DTC_894" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_GearboxTypeNotAvailable" , "Level" => "2"},
		"37F" => { "Name" => "DTC_895" , "Display_Code" => "U10BC00" , "Text" => "VarCodNetVinNotinitialized" , "Level" => "2"},
		"380" => { "Name" => "DTC_896" , "Display_Code" => "C104AF0" , "Text" => "VarCodVinMismatch" , "Level" => "2"},
		"381" => { "Name" => "DTC_897" , "Display_Code" => "U10BC00" , "Text" => "VarCodVariantNotFound" , "Level" => "2"},
		"382" => { "Name" => "DTC_898" , "Display_Code" => "U101400" , "Text" => "VAR_StartStopPlausibiltyError" , "Level" => "2"},
		"383" => { "Name" => "DTC_899" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_1_DataCorrupt" , "Level" => "2"},
		"384" => { "Name" => "DTC_900" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_1_Timeout" , "Level" => "2"},
		"385" => { "Name" => "DTC_901" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_2_DataCorrupt" , "Level" => "2"},
		"386" => { "Name" => "DTC_902" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_2_Timeout" , "Level" => "2"},
		"387" => { "Name" => "DTC_903" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineTrq_Invalid" , "Level" => "2"},
		"388" => { "Name" => "DTC_904" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineTrqLoss_Invalid" , "Level" => "2"},
		"389" => { "Name" => "DTC_905" , "Display_Code" => "U101F00" , "Text" => "Scl_DriverReqTrq_Invalid" , "Level" => "2"},
		"38A" => { "Name" => "DTC_906" , "Display_Code" => "U101F00" , "Text" => "Scl_AccPedalPos_Invalid" , "Level" => "2"},
		"38B" => { "Name" => "DTC_907" , "Display_Code" => "U101F00" , "Text" => "Scl_AccPedalPosRaw_Invalid" , "Level" => "2"},
		"38C" => { "Name" => "DTC_908" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineSpeed_Invalid" , "Level" => "2"},
		"38D" => { "Name" => "DTC_909" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineECU_Faulty" , "Level" => "2"},
		"38E" => { "Name" => "DTC_910" , "Display_Code" => "U101F00" , "Text" => "Scl_MotDrvReqTrqLimitation_Invalid" , "Level" => "2"},
		"38F" => { "Name" => "DTC_911" , "Display_Code" => "U101F00" , "Text" => "Scl_GearBoxType_Invalid" , "Level" => "2"},
		"390" => { "Name" => "DTC_912" , "Display_Code" => "U044700" , "Text" => "ComScl_mGate_Komf_1_DataCorrupt" , "Level" => "2"},
		"391" => { "Name" => "DTC_913" , "Display_Code" => "U014600" , "Text" => "ComScl_mGate_Komf_1_Timeout" , "Level" => "2"},
		"392" => { "Name" => "DTC_914" , "Display_Code" => "U040200" , "Text" => "ComScl_mGetriebe_1_DataCorrupt" , "Level" => "2"},
		"393" => { "Name" => "DTC_915" , "Display_Code" => "U010100" , "Text" => "ComScl_mGetriebe_1_Timeout" , "Level" => "2"},
		"394" => { "Name" => "DTC_916" , "Display_Code" => "U102600" , "Text" => "Scl_TargetGear_Invalid" , "Level" => "2"},
		"395" => { "Name" => "DTC_917" , "Display_Code" => "U102600" , "Text" => "Scl_GearLever_Invalid" , "Level" => "2"},
		"397" => { "Name" => "DTC_919" , "Display_Code" => "U042300" , "Text" => "ComScl_mKombi_3_DataCorrupt" , "Level" => "2"},
		"398" => { "Name" => "DTC_920" , "Display_Code" => "U015500" , "Text" => "ComScl_mKombi_3_Timeout" , "Level" => "2"},
		"399" => { "Name" => "DTC_921" , "Display_Code" => "U045200" , "Text" => "ComScl_mAirbag_1_DataCorrupt" , "Level" => "3"},
		"39A" => { "Name" => "DTC_922" , "Display_Code" => "U015100" , "Text" => "ComScl_mAirbag_1_Timeout" , "Level" => "3"},
		"39B" => { "Name" => "DTC_923" , "Display_Code" => "U044700" , "Text" => "ComScl_mDiagnose_1_DataCorrupt" , "Level" => "2"},
		"39C" => { "Name" => "DTC_924" , "Display_Code" => "U014600" , "Text" => "ComScl_mDiagnose_1_Timeout" , "Level" => "2"},
		"39D" => { "Name" => "DTC_925" , "Display_Code" => "U045200" , "Text" => "ComScl_AB1_Checksum" , "Level" => "3"},
		"39E" => { "Name" => "DTC_926" , "Display_Code" => "U045200" , "Text" => "ComScl_AB1_ACounter" , "Level" => "3"},
		"39F" => { "Name" => "DTC_927" , "Display_Code" => "U042300" , "Text" => "ComScl_mIdent_DataCorrupt" , "Level" => "2"},
		"3A0" => { "Name" => "DTC_928" , "Display_Code" => "U015500" , "Text" => "ComScl_mIdent_Timeout" , "Level" => "2"},
		"3A1" => { "Name" => "DTC_929" , "Display_Code" => "U014000" , "Text" => "Scl_ReverseLight_Invalid" , "Level" => "2"},
		"3A2" => { "Name" => "DTC_930" , "Display_Code" => "U014000" , "Text" => "Scl_DriverDoor_Invalid" , "Level" => "2"},
		"3A3" => { "Name" => "DTC_931" , "Display_Code" => "U102400" , "Text" => "Scl_WheelCircumference_Invalid" , "Level" => "2"},
		"3A4" => { "Name" => "DTC_932" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_10_DataCorrupt" , "Level" => "2"},
		"3A5" => { "Name" => "DTC_933" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_10_Timeout" , "Level" => "2"},
		"3A6" => { "Name" => "DTC_934" , "Display_Code" => "U101F00" , "Text" => "Scl_TiOutBr_EngineTimeout" , "Level" => "2"},
		"3A7" => { "Name" => "DTC_935" , "Display_Code" => "U101F00" , "Text" => "Scl_NormTorque_Invalid" , "Level" => "2"},
		"3AB" => { "Name" => "DTC_939" , "Display_Code" => "U043200" , "Text" => "IISMM8ConfigurationError" , "Level" => "2"},
		"3AD" => { "Name" => "DTC_941" , "Display_Code" => "U043200" , "Text" => "IISEEPromError" , "Level" => "2"},
		"3AF" => { "Name" => "DTC_943" , "Display_Code" => "U043200" , "Text" => "IISOEMCalibrationError" , "Level" => "2"},
		"3B0" => { "Name" => "DTC_944" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_SteeringPositionPlausibilityError" , "Level" => "2"},
		"3B1" => { "Name" => "DTC_945" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_BuiltGatewayInfoSetToInvalid" , "Level" => "2"},
		"3B2" => { "Name" => "DTC_946" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_SteeringPositionNotAvailable" , "Level" => "2"},
		"3B3" => { "Name" => "DTC_947" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_SteeringPositionPlausibilityError" , "Level" => "2"},
		"3B4" => { "Name" => "DTC_948" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_BuiltGatewayInfoSetToInvalid" , "Level" => "2"},
		"3CF" => { "Name" => "DTC_975" , "Display_Code" => "U10B100" , "Text" => "A2S_MonRange" , "Level" => "2"},
		"3D0" => { "Name" => "DTC_976" , "Display_Code" => "U043200" , "Text" => "A1S_MonRange" , "Level" => "2"},
		"3D2" => { "Name" => "DTC_978" , "Display_Code" => "C101729" , "Text" => "Axs_MissAllignmentDetect" , "Level" => "2"},
		"3D3" => { "Name" => "DTC_979" , "Display_Code" => "C101729" , "Text" => "Ays_MissAllignmentDetect" , "Level" => "2"},
		"3D4" => { "Name" => "DTC_980" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_3_DataCorrupt" , "Level" => "2"},
		"3D5" => { "Name" => "DTC_981" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_3_Timeout" , "Level" => "2"},
		"3D6" => { "Name" => "DTC_982" , "Display_Code" => "U042300" , "Text" => "ComScl_mKombi_1_DataCorrupt" , "Level" => "2"},
		"3D7" => { "Name" => "DTC_983" , "Display_Code" => "U015500" , "Text" => "ComScl_mKombi_1_Timeout" , "Level" => "2"},
		"3D8" => { "Name" => "DTC_984" , "Display_Code" => "U044700" , "Text" => "ComScl_mSysteminfo_1_DataCorrupt" , "Level" => "2"},
		"3D9" => { "Name" => "DTC_985" , "Display_Code" => "U014600" , "Text" => "ComScl_mSysteminfo_1_Timeout" , "Level" => "2"},
		"3DA" => { "Name" => "DTC_986" , "Display_Code" => "U042800" , "Text" => "ComScl_mLW_1_DataCorrupt" , "Level" => "2"},
		"3DB" => { "Name" => "DTC_987" , "Display_Code" => "U012600" , "Text" => "ComScl_mLW_1_Timeout" , "Level" => "2"},
		"3DC" => { "Name" => "DTC_988" , "Display_Code" => "U042800" , "Text" => "ComScl_LW1_Checksum" , "Level" => "2"},
		"3DD" => { "Name" => "DTC_989" , "Display_Code" => "U042800" , "Text" => "ComScl_LW1_ACounter" , "Level" => "2"},
		"3DE" => { "Name" => "DTC_990" , "Display_Code" => "B116854" , "Text" => "Scl_CalibrationWrongSasIDFailure" , "Level" => "2"},
		"3DF" => { "Name" => "DTC_991" , "Display_Code" => "B116854" , "Text" => "Scl_PDM_SASIDWriteError" , "Level" => "2"},
		"3E0" => { "Name" => "DTC_992" , "Display_Code" => "B116854" , "Text" => "Scl_PDM_SASIDReadError" , "Level" => "2"},
		"3E1" => { "Name" => "DTC_993" , "Display_Code" => "B116854" , "Text" => "Scl_SasID_Invalid" , "Level" => "2"},
		"3E2" => { "Name" => "DTC_994" , "Display_Code" => "U102D00" , "Text" => "Scl_SasStatus_Invalid" , "Level" => "2"},
		"3E3" => { "Name" => "DTC_995" , "Display_Code" => "B200FF0" , "Text" => "Scl_Sas_InitSource_Invalid" , "Level" => "255"},
		"3E4" => { "Name" => "DTC_996" , "Display_Code" => "B200FF0" , "Text" => "Scl_Sas_InvalidReInitialization" , "Level" => "255"},
		"3E5" => { "Name" => "DTC_997" , "Display_Code" => "C113404" , "Text" => "EbdLampPlausibility" , "Level" => "1"},
		"3E6" => { "Name" => "DTC_998" , "Display_Code" => "C113604" , "Text" => "AbsLampPlausibility" , "Level" => "1"},
		"3E7" => { "Name" => "DTC_999" , "Display_Code" => "C113504" , "Text" => "EspAsrLampPlausibility" , "Level" => "1"},
		"3EB" => { "Name" => "DTC_1003" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2ABSbyAC1100" , "Level" => "2"},
		"3EC" => { "Name" => "DTC_1004" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2TCSbyAC1101" , "Level" => "2"},
		"3ED" => { "Name" => "DTC_1005" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2ABSwithPTCbyAC1102" , "Level" => "2"},
		"3EE" => { "Name" => "DTC_1006" , "Display_Code" => "C107629" , "Text" => "DoorSwitchPlausibility" , "Level" => "3"},
		"3EF" => { "Name" => "DTC_1007" , "Display_Code" => "B200000" , "Text" => "HETReferenceError" , "Level" => "1"},
		"3F0" => { "Name" => "DTC_1008" , "Display_Code" => "U043200" , "Text" => "IISMM8ClockCountMonitor" , "Level" => "2"},
		"3F1" => { "Name" => "DTC_1009" , "Display_Code" => "U043200" , "Text" => "IISMM8GeneralAsFault" , "Level" => "2"},
		"3F2" => { "Name" => "DTC_1010" , "Display_Code" => "C107D04" , "Text" => "IISMM8GeneralYrsFault" , "Level" => "2"},
		"3F3" => { "Name" => "DTC_1011" , "Display_Code" => "U043200" , "Text" => "IISMM8InternalHWTestTimeout" , "Level" => "2"},
		"3F4" => { "Name" => "DTC_1012" , "Display_Code" => "U043200" , "Text" => "IISMM8RetrieveHWVersionErr" , "Level" => "2"},
		"3F5" => { "Name" => "DTC_1013" , "Display_Code" => "U043200" , "Text" => "IISMM8RetrieveInitialTempErr" , "Level" => "2"},
		"3F6" => { "Name" => "DTC_1014" , "Display_Code" => "U012500" , "Text" => "IISMM8SpiTransError" , "Level" => "2"},
		"3F7" => { "Name" => "DTC_1015" , "Display_Code" => "U043200" , "Text" => "IISMM8WrongHWRevision" , "Level" => "2"},
		"3F8" => { "Name" => "DTC_1016" , "Display_Code" => "B200000" , "Text" => "MicInitSpiTransferError" , "Level" => "1"},
		"3F9" => { "Name" => "DTC_1017" , "Display_Code" => "C101504" , "Text" => "RfpActUBMRSupplyError" , "Level" => "1"},
		"3FA" => { "Name" => "DTC_1018" , "Display_Code" => "B200FF0" , "Text" => "LimitSystemByBS041B" , "Level" => "255"},
		"40C" => { "Name" => "DTC_1036" , "Display_Code" => "B200FF0" , "Text" => "IISMM8YrsFailureIntegral" , "Level" => "255"},
		"40D" => { "Name" => "DTC_1037" , "Display_Code" => "B200FF0" , "Text" => "IISMM8SpiTimingViolation" , "Level" => "255"},
		"40E" => { "Name" => "DTC_1038" , "Display_Code" => "B200FF0" , "Text" => "IISMM8SensorCRCCheck" , "Level" => "255"},
		"40F" => { "Name" => "DTC_1039" , "Display_Code" => "B200FF0" , "Text" => "IISMM8AsFailureIntegral" , "Level" => "255"},
		"410" => { "Name" => "DTC_1040" , "Display_Code" => "B200FF0" , "Text" => "IISMM8GSBitsMissed" , "Level" => "255"},
		"411" => { "Name" => "DTC_1041" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_2" , "Level" => "2"},
		"412" => { "Name" => "DTC_1042" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_WRITE_DIAGNOSE_DATA" , "Level" => "255"},
		"413" => { "Name" => "DTC_1043" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_READ_DIAGNOSE_DATA" , "Level" => "255"},
		"414" => { "Name" => "DTC_1044" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_CALIB_BUTTON_STUCK" , "Level" => "255"},
		"415" => { "Name" => "DTC_1045" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_TPID_INCORRECT_LIB" , "Level" => "255"},
		"1" => { "Name" => "DTC_1" , "Display_Code" => "C1069F0" , "Text" => "Abs_ContControl" , "Level" => "2"},
		"2" => { "Name" => "DTC_2" , "Display_Code" => "P057100" , "Text" => "AcmBls_PermHigh" , "Level" => "2"},
		"3" => { "Name" => "DTC_3" , "Display_Code" => "P057100" , "Text" => "AcmBls_PermHighHHC" , "Level" => "2"},
		"4" => { "Name" => "DTC_4" , "Display_Code" => "P057100" , "Text" => "AcmPbs_PlausPsBlsTh1" , "Level" => "2"},
		"5" => { "Name" => "DTC_5" , "Display_Code" => "P057100" , "Text" => "AcmPbs_PlausPsBlsTh3" , "Level" => "2"},
		"7" => { "Name" => "DTC_7" , "Display_Code" => "C101504" , "Text" => "AcmPs_OffsetMC1" , "Level" => "1"},
		"A" => { "Name" => "DTC_10" , "Display_Code" => "C101504" , "Text" => "AcmPs_TestpulseMC1" , "Level" => "1"},
		"D" => { "Name" => "DTC_13" , "Display_Code" => "C104B29" , "Text" => "Axs_Offset" , "Level" => "2"},
		"E" => { "Name" => "DTC_14" , "Display_Code" => "C104B29" , "Text" => "Axs_Plaus" , "Level" => "2"},
		"F" => { "Name" => "DTC_15" , "Display_Code" => "C104B29" , "Text" => "Ays_MonOffset" , "Level" => "2"},
		"11" => { "Name" => "DTC_17" , "Display_Code" => "C104B29" , "Text" => "Ays_PlausLimVal" , "Level" => "2"},
		"12" => { "Name" => "DTC_18" , "Display_Code" => "C104B29" , "Text" => "Ays_PlausValidity" , "Level" => "2"},
		"13" => { "Name" => "DTC_19" , "Display_Code" => "C104B29" , "Text" => "Ays_Standstill" , "Level" => "2"},
		"14" => { "Name" => "DTC_20" , "Display_Code" => "B200000" , "Text" => "BERT_FAULT" , "Level" => "1"},
		"15" => { "Name" => "DTC_21" , "Display_Code" => "P057100" , "Text" => "BlsLine" , "Level" => "2"},
		"18" => { "Name" => "DTC_24" , "Display_Code" => "B200000" , "Text" => "CCM_FAULT" , "Level" => "1"},
		"5E" => { "Name" => "DTC_94" , "Display_Code" => "B200000" , "Text" => "DeadlineMonTaskx1Ovr" , "Level" => "1"},
		"73" => { "Name" => "DTC_115" , "Display_Code" => "B200000" , "Text" => "ESMSafety_FAULT" , "Level" => "1"},
		"74" => { "Name" => "DTC_116" , "Display_Code" => "B200000" , "Text" => "ESM_NMI_FAULT" , "Level" => "1"},
		"75" => { "Name" => "DTC_117" , "Display_Code" => "B200000" , "Text" => "EcuADCConversionError" , "Level" => "1"},
		"76" => { "Name" => "DTC_118" , "Display_Code" => "B200000" , "Text" => "EcuBandGap" , "Level" => "1"},
		"77" => { "Name" => "DTC_119" , "Display_Code" => "B200000" , "Text" => "EcuEnContinuousError" , "Level" => "1"},
		"79" => { "Name" => "DTC_121" , "Display_Code" => "B200000" , "Text" => "EcuEnableHyFails" , "Level" => "1"},
		"7A" => { "Name" => "DTC_122" , "Display_Code" => "B200000" , "Text" => "EcuErrpinCounterTestFails" , "Level" => "1"},
		"7B" => { "Name" => "DTC_123" , "Display_Code" => "B200000" , "Text" => "EcuHETException" , "Level" => "1"},
		"7C" => { "Name" => "DTC_124" , "Display_Code" => "B200000" , "Text" => "EcuHETTUAddressingError" , "Level" => "1"},
		"7D" => { "Name" => "DTC_125" , "Display_Code" => "B200000" , "Text" => "EcuHETTUBusError" , "Level" => "1"},
		"7E" => { "Name" => "DTC_126" , "Display_Code" => "B200000" , "Text" => "EcuHETTUBusyError" , "Level" => "1"},
		"7F" => { "Name" => "DTC_127" , "Display_Code" => "B200000" , "Text" => "EcuHETTUException" , "Level" => "1"},
		"80" => { "Name" => "DTC_128" , "Display_Code" => "B200000" , "Text" => "EcuRomCheck" , "Level" => "1"},
		"81" => { "Name" => "DTC_129" , "Display_Code" => "B200000" , "Text" => "EcuTaskMissing" , "Level" => "1"},
		"82" => { "Name" => "DTC_130" , "Display_Code" => "B200000" , "Text" => "EcuVrOnWhileWdTimeout" , "Level" => "1"},
		"83" => { "Name" => "DTC_131" , "Display_Code" => "B200000" , "Text" => "EcuVrViaSpiFails" , "Level" => "1"},
		"84" => { "Name" => "DTC_132" , "Display_Code" => "B200000" , "Text" => "EcuWdErrCntContinuousError" , "Level" => "1"},
		"85" => { "Name" => "DTC_133" , "Display_Code" => "B200000" , "Text" => "EcuWdScheduleTimeout" , "Level" => "1"},
		"86" => { "Name" => "DTC_134" , "Display_Code" => "B200000" , "Text" => "EcuWdStartuptestFails" , "Level" => "1"},
		"87" => { "Name" => "DTC_135" , "Display_Code" => "B200000" , "Text" => "EcuWdStatusContinuousError" , "Level" => "1"},
		"8E" => { "Name" => "DTC_142" , "Display_Code" => "U140000" , "Text" => "HydraulicSupplyUndervoltage" , "Level" => "6"},
		"90" => { "Name" => "DTC_144" , "Display_Code" => "B200000" , "Text" => "MicIntVoltMonCompFail" , "Level" => "1"},
		"92" => { "Name" => "DTC_146" , "Display_Code" => "B200000" , "Text" => "MicSpiTransferError" , "Level" => "1"},
		"A8" => { "Name" => "DTC_168" , "Display_Code" => "B200000" , "Text" => "OSErrorHook" , "Level" => "1"},
		"AB" => { "Name" => "DTC_171" , "Display_Code" => "B200000" , "Text" => "PBISTError" , "Level" => "1"},
		"B1" => { "Name" => "DTC_177" , "Display_Code" => "C101504" , "Text" => "PressSensMC1Line" , "Level" => "2"},
		"B8" => { "Name" => "DTC_184" , "Display_Code" => "B200000" , "Text" => "RAMInitError" , "Level" => "1"},
		"B9" => { "Name" => "DTC_185" , "Display_Code" => "B200000" , "Text" => "RAMSINLGE_FAULT" , "Level" => "1"},
		"BB" => { "Name" => "DTC_187" , "Display_Code" => "C109E29" , "Text" => "ReverseGearHigh" , "Level" => "2"},
		"BC" => { "Name" => "DTC_188" , "Display_Code" => "C109E29" , "Text" => "ReverseGearLow" , "Level" => "2"},
		"C0" => { "Name" => "DTC_192" , "Display_Code" => "B200000" , "Text" => "RfpIFSTestFailed" , "Level" => "1"},
		"C1" => { "Name" => "DTC_193" , "Display_Code" => "B200000" , "Text" => "RfpMRAuCLineTestFailed" , "Level" => "1"},
		"C2" => { "Name" => "DTC_194" , "Display_Code" => "C101816" , "Text" => "RfpMRDSupplyError" , "Level" => "2"},
		"C3" => { "Name" => "DTC_195" , "Display_Code" => "C101504" , "Text" => "RfpMRGInverseTestFailed" , "Level" => "1"},
		"C4" => { "Name" => "DTC_196" , "Display_Code" => "C101504" , "Text" => "RfpMRGTestFailed" , "Level" => "1"},
		"C5" => { "Name" => "DTC_197" , "Display_Code" => "C101504" , "Text" => "RfpMRPUTestFailed" , "Level" => "1"},
		"C7" => { "Name" => "DTC_199" , "Display_Code" => "B200000" , "Text" => "RfpMRolError" , "Level" => "1"},
		"C8" => { "Name" => "DTC_200" , "Display_Code" => "B200000" , "Text" => "RfpMRscError" , "Level" => "1"},
		"CA" => { "Name" => "DTC_202" , "Display_Code" => "C101811" , "Text" => "RfpStopMonFailed" , "Level" => "2"},
		"108" => { "Name" => "DTC_264" , "Display_Code" => "B200000" , "Text" => "SYSErrorHook" , "Level" => "1"},
		"10B" => { "Name" => "DTC_267" , "Display_Code" => "U111200" , "Text" => "Sas_MonConstSig" , "Level" => "2"},
		"10C" => { "Name" => "DTC_268" , "Display_Code" => "U111200" , "Text" => "Sas_MonGrad" , "Level" => "2"},
		"10E" => { "Name" => "DTC_270" , "Display_Code" => "U111200" , "Text" => "Sas_MonMsgCnt" , "Level" => "2"},
		"10F" => { "Name" => "DTC_271" , "Display_Code" => "B116829" , "Text" => "Sas_MonOffset" , "Level" => "2"},
		"110" => { "Name" => "DTC_272" , "Display_Code" => "B116829" , "Text" => "Sas_MonRange" , "Level" => "2"},
		"111" => { "Name" => "DTC_273" , "Display_Code" => "B116829" , "Text" => "Sas_PlausYrs" , "Level" => "2"},
		"112" => { "Name" => "DTC_274" , "Display_Code" => "B116807" , "Text" => "Sas_Sign" , "Level" => "2"},
		"113" => { "Name" => "DTC_275" , "Display_Code" => "B200000" , "Text" => "StackOverUnderFlow" , "Level" => "1"},
		"115" => { "Name" => "DTC_277" , "Display_Code" => "B200000" , "Text" => "UC_SAFETY_FAULT" , "Level" => "1"},
		"11A" => { "Name" => "DTC_282" , "Display_Code" => "C101504" , "Text" => "ValveAvFlGeneric" , "Level" => "1"},
		"11B" => { "Name" => "DTC_283" , "Display_Code" => "B200000" , "Text" => "ValveAvFlQx" , "Level" => "1"},
		"11C" => { "Name" => "DTC_284" , "Display_Code" => "C101504" , "Text" => "ValveAvFlResOutOfRange" , "Level" => "1"},
		"11D" => { "Name" => "DTC_285" , "Display_Code" => "C101504" , "Text" => "ValveAvFlSvdt" , "Level" => "1"},
		"11F" => { "Name" => "DTC_287" , "Display_Code" => "C101504" , "Text" => "ValveAvFrGeneric" , "Level" => "1"},
		"120" => { "Name" => "DTC_288" , "Display_Code" => "B200000" , "Text" => "ValveAvFrQx" , "Level" => "1"},
		"121" => { "Name" => "DTC_289" , "Display_Code" => "C101504" , "Text" => "ValveAvFrResOutOfRange" , "Level" => "1"},
		"122" => { "Name" => "DTC_290" , "Display_Code" => "C101504" , "Text" => "ValveAvFrSvdt" , "Level" => "1"},
		"124" => { "Name" => "DTC_292" , "Display_Code" => "C101504" , "Text" => "ValveAvRlGeneric" , "Level" => "1"},
		"125" => { "Name" => "DTC_293" , "Display_Code" => "B200000" , "Text" => "ValveAvRlQx" , "Level" => "1"},
		"126" => { "Name" => "DTC_294" , "Display_Code" => "C101504" , "Text" => "ValveAvRlResOutOfRange" , "Level" => "1"},
		"127" => { "Name" => "DTC_295" , "Display_Code" => "C101504" , "Text" => "ValveAvRlSvdt" , "Level" => "1"},
		"129" => { "Name" => "DTC_297" , "Display_Code" => "C101504" , "Text" => "ValveAvRrGeneric" , "Level" => "1"},
		"12A" => { "Name" => "DTC_298" , "Display_Code" => "B200000" , "Text" => "ValveAvRrQx" , "Level" => "1"},
		"12B" => { "Name" => "DTC_299" , "Display_Code" => "C101504" , "Text" => "ValveAvRrResOutOfRange" , "Level" => "1"},
		"12C" => { "Name" => "DTC_300" , "Display_Code" => "C101504" , "Text" => "ValveAvRrSvdt" , "Level" => "1"},
		"12E" => { "Name" => "DTC_302" , "Display_Code" => "C101504" , "Text" => "ValveEvFlGeneric" , "Level" => "1"},
		"12F" => { "Name" => "DTC_303" , "Display_Code" => "B200000" , "Text" => "ValveEvFlQx" , "Level" => "1"},
		"130" => { "Name" => "DTC_304" , "Display_Code" => "C101504" , "Text" => "ValveEvFlResOutOfRange" , "Level" => "1"},
		"131" => { "Name" => "DTC_305" , "Display_Code" => "C101504" , "Text" => "ValveEvFlSvdt" , "Level" => "1"},
		"133" => { "Name" => "DTC_307" , "Display_Code" => "C101504" , "Text" => "ValveEvFrGeneric" , "Level" => "1"},
		"134" => { "Name" => "DTC_308" , "Display_Code" => "B200000" , "Text" => "ValveEvFrQx" , "Level" => "1"},
		"135" => { "Name" => "DTC_309" , "Display_Code" => "C101504" , "Text" => "ValveEvFrResOutOfRange" , "Level" => "1"},
		"136" => { "Name" => "DTC_310" , "Display_Code" => "C101504" , "Text" => "ValveEvFrSvdt" , "Level" => "1"},
		"138" => { "Name" => "DTC_312" , "Display_Code" => "C101504" , "Text" => "ValveEvRlGeneric" , "Level" => "1"},
		"139" => { "Name" => "DTC_313" , "Display_Code" => "B200000" , "Text" => "ValveEvRlQx" , "Level" => "1"},
		"13A" => { "Name" => "DTC_314" , "Display_Code" => "C101504" , "Text" => "ValveEvRlResOutOfRange" , "Level" => "1"},
		"13B" => { "Name" => "DTC_315" , "Display_Code" => "C101504" , "Text" => "ValveEvRlSvdt" , "Level" => "1"},
		"13D" => { "Name" => "DTC_317" , "Display_Code" => "C101504" , "Text" => "ValveEvRrGeneric" , "Level" => "1"},
		"13E" => { "Name" => "DTC_318" , "Display_Code" => "B200000" , "Text" => "ValveEvRrQx" , "Level" => "1"},
		"13F" => { "Name" => "DTC_319" , "Display_Code" => "C101504" , "Text" => "ValveEvRrResOutOfRange" , "Level" => "1"},
		"140" => { "Name" => "DTC_320" , "Display_Code" => "C101504" , "Text" => "ValveEvRrSvdt" , "Level" => "1"},
		"142" => { "Name" => "DTC_322" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Generic" , "Level" => "1"},
		"143" => { "Name" => "DTC_323" , "Display_Code" => "B200000" , "Text" => "ValveHsv1Qx" , "Level" => "1"},
		"144" => { "Name" => "DTC_324" , "Display_Code" => "C101504" , "Text" => "ValveHsv1ResOutOfRange" , "Level" => "1"},
		"145" => { "Name" => "DTC_325" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Svdt" , "Level" => "1"},
		"147" => { "Name" => "DTC_327" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Generic" , "Level" => "1"},
		"148" => { "Name" => "DTC_328" , "Display_Code" => "B200000" , "Text" => "ValveHsv2Qx" , "Level" => "1"},
		"149" => { "Name" => "DTC_329" , "Display_Code" => "C101504" , "Text" => "ValveHsv2ResOutOfRange" , "Level" => "1"},
		"14A" => { "Name" => "DTC_330" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Svdt" , "Level" => "1"},
		"14C" => { "Name" => "DTC_332" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Generic" , "Level" => "1"},
		"14D" => { "Name" => "DTC_333" , "Display_Code" => "B200000" , "Text" => "ValveUsv1Qx" , "Level" => "1"},
		"14E" => { "Name" => "DTC_334" , "Display_Code" => "C101504" , "Text" => "ValveUsv1ResOutOfRange" , "Level" => "1"},
		"14F" => { "Name" => "DTC_335" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Svdt" , "Level" => "1"},
		"151" => { "Name" => "DTC_337" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Generic" , "Level" => "1"},
		"152" => { "Name" => "DTC_338" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Qx" , "Level" => "1"},
		"153" => { "Name" => "DTC_339" , "Display_Code" => "C101504" , "Text" => "ValveUsv2ResOutOfRange" , "Level" => "1"},
		"154" => { "Name" => "DTC_340" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Svdt" , "Level" => "1"},
		"155" => { "Name" => "DTC_341" , "Display_Code" => "C1069F0" , "Text" => "Vdc_ContControl" , "Level" => "2"},
		"156" => { "Name" => "DTC_342" , "Display_Code" => "B200000" , "Text" => "VrHighOhmicShortToGndContinuous" , "Level" => "1"},
		"157" => { "Name" => "DTC_343" , "Display_Code" => "B200000" , "Text" => "VrOnFails" , "Level" => "1"},
		"158" => { "Name" => "DTC_344" , "Display_Code" => "B200000" , "Text" => "VrOnFailsContinuous" , "Level" => "1"},
		"15A" => { "Name" => "DTC_346" , "Display_Code" => "B200000" , "Text" => "VrShortToGndContinuous" , "Level" => "1"},
		"15B" => { "Name" => "DTC_347" , "Display_Code" => "B200000" , "Text" => "VrStuck" , "Level" => "1"},
		"15C" => { "Name" => "DTC_348" , "Display_Code" => "B200000" , "Text" => "VrStuckContinuous" , "Level" => "1"},
		"15D" => { "Name" => "DTC_349" , "Display_Code" => "B200000" , "Text" => "WSSHetMonMuxSigError" , "Level" => "1"},
		"160" => { "Name" => "DTC_352" , "Display_Code" => "C101A07" , "Text" => "WssFLAirGap" , "Level" => "2"},
		"162" => { "Name" => "DTC_354" , "Display_Code" => "C101A01" , "Text" => "WssFLLineFail" , "Level" => "2"},
		"163" => { "Name" => "DTC_355" , "Display_Code" => "C101A14" , "Text" => "WssFLLineGnd" , "Level" => "2"},
		"164" => { "Name" => "DTC_356" , "Display_Code" => "C101A12" , "Text" => "WssFLLineHigh" , "Level" => "2"},
		"165" => { "Name" => "DTC_357" , "Display_Code" => "C101A01" , "Text" => "WssFLLineUndef" , "Level" => "2"},
		"166" => { "Name" => "DTC_358" , "Display_Code" => "C101A01" , "Text" => "WssFLNoEdge" , "Level" => "2"},
		"169" => { "Name" => "DTC_361" , "Display_Code" => "C101A11" , "Text" => "WssFLSupplyGnd" , "Level" => "2"},
		"16A" => { "Name" => "DTC_362" , "Display_Code" => "C101B07" , "Text" => "WssFRAirGap" , "Level" => "2"},
		"16C" => { "Name" => "DTC_364" , "Display_Code" => "C101B01" , "Text" => "WssFRLineFail" , "Level" => "2"},
		"16D" => { "Name" => "DTC_365" , "Display_Code" => "C101B14" , "Text" => "WssFRLineGnd" , "Level" => "2"},
		"16E" => { "Name" => "DTC_366" , "Display_Code" => "C101B12" , "Text" => "WssFRLineHigh" , "Level" => "2"},
		"16F" => { "Name" => "DTC_367" , "Display_Code" => "C101B01" , "Text" => "WssFRLineUndef" , "Level" => "2"},
		"170" => { "Name" => "DTC_368" , "Display_Code" => "C101B01" , "Text" => "WssFRNoEdge" , "Level" => "2"},
		"173" => { "Name" => "DTC_371" , "Display_Code" => "C101B11" , "Text" => "WssFRSupplyGnd" , "Level" => "2"},
		"174" => { "Name" => "DTC_372" , "Display_Code" => "C101C07" , "Text" => "WssRLAirGap" , "Level" => "2"},
		"176" => { "Name" => "DTC_374" , "Display_Code" => "C101C01" , "Text" => "WssRLLineFail" , "Level" => "2"},
		"177" => { "Name" => "DTC_375" , "Display_Code" => "C101C14" , "Text" => "WssRLLineGnd" , "Level" => "2"},
		"178" => { "Name" => "DTC_376" , "Display_Code" => "C101C12" , "Text" => "WssRLLineHigh" , "Level" => "2"},
		"179" => { "Name" => "DTC_377" , "Display_Code" => "C101C01" , "Text" => "WssRLLineUndef" , "Level" => "2"},
		"17A" => { "Name" => "DTC_378" , "Display_Code" => "C101C01" , "Text" => "WssRLNoEdge" , "Level" => "2"},
		"17D" => { "Name" => "DTC_381" , "Display_Code" => "C101C11" , "Text" => "WssRLSupplyGnd" , "Level" => "2"},
		"17E" => { "Name" => "DTC_382" , "Display_Code" => "C101D07" , "Text" => "WssRRAirGap" , "Level" => "2"},
		"180" => { "Name" => "DTC_384" , "Display_Code" => "C101D01" , "Text" => "WssRRLineFail" , "Level" => "2"},
		"181" => { "Name" => "DTC_385" , "Display_Code" => "C101D14" , "Text" => "WssRRLineGnd" , "Level" => "2"},
		"182" => { "Name" => "DTC_386" , "Display_Code" => "C101D12" , "Text" => "WssRRLineHigh" , "Level" => "2"},
		"183" => { "Name" => "DTC_387" , "Display_Code" => "C101D01" , "Text" => "WssRRLineUndef" , "Level" => "2"},
		"184" => { "Name" => "DTC_388" , "Display_Code" => "C101D01" , "Text" => "WssRRNoEdge" , "Level" => "2"},
		"187" => { "Name" => "DTC_391" , "Display_Code" => "C101D11" , "Text" => "WssRRSupplyGnd" , "Level" => "2"},
		"188" => { "Name" => "DTC_392" , "Display_Code" => "C101A01" , "Text" => "WssTestFLFailure" , "Level" => "2"},
		"189" => { "Name" => "DTC_393" , "Display_Code" => "C101B01" , "Text" => "WssTestFRFailure" , "Level" => "2"},
		"18A" => { "Name" => "DTC_394" , "Display_Code" => "C101C01" , "Text" => "WssTestRLFailure" , "Level" => "2"},
		"18B" => { "Name" => "DTC_395" , "Display_Code" => "C101D01" , "Text" => "WssTestRRFailure" , "Level" => "2"},
		"18C" => { "Name" => "DTC_396" , "Display_Code" => "B200000" , "Text" => "WssTestSystemICFailure" , "Level" => "1"},
		"18D" => { "Name" => "DTC_397" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDoHi_FL" , "Level" => "2"},
		"18E" => { "Name" => "DTC_398" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDoHi_FR" , "Level" => "2"},
		"18F" => { "Name" => "DTC_399" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDoHi_RL" , "Level" => "2"},
		"190" => { "Name" => "DTC_400" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDoHi_RR" , "Level" => "2"},
		"191" => { "Name" => "DTC_401" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDoLo_FL" , "Level" => "2"},
		"192" => { "Name" => "DTC_402" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDoLo_FR" , "Level" => "2"},
		"193" => { "Name" => "DTC_403" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDoLo_RL" , "Level" => "2"},
		"194" => { "Name" => "DTC_404" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDoLo_RR" , "Level" => "2"},
		"195" => { "Name" => "DTC_405" , "Display_Code" => "C101A29" , "Text" => "Wss_MonDyn_FL" , "Level" => "2"},
		"196" => { "Name" => "DTC_406" , "Display_Code" => "C101B29" , "Text" => "Wss_MonDyn_FR" , "Level" => "2"},
		"197" => { "Name" => "DTC_407" , "Display_Code" => "C101C29" , "Text" => "Wss_MonDyn_RL" , "Level" => "2"},
		"198" => { "Name" => "DTC_408" , "Display_Code" => "C101D29" , "Text" => "Wss_MonDyn_RR" , "Level" => "2"},
		"199" => { "Name" => "DTC_409" , "Display_Code" => "C106B29" , "Text" => "Wss_MonGenericTempFail" , "Level" => "2"},
		"19A" => { "Name" => "DTC_410" , "Display_Code" => "C101A29" , "Text" => "Wss_MonNoise_FL" , "Level" => "2"},
		"19B" => { "Name" => "DTC_411" , "Display_Code" => "C101B29" , "Text" => "Wss_MonNoise_FR" , "Level" => "2"},
		"19C" => { "Name" => "DTC_412" , "Display_Code" => "C101C29" , "Text" => "Wss_MonNoise_RL" , "Level" => "2"},
		"19D" => { "Name" => "DTC_413" , "Display_Code" => "C101D29" , "Text" => "Wss_MonNoise_RR" , "Level" => "2"},
		"19E" => { "Name" => "DTC_414" , "Display_Code" => "C101A29" , "Text" => "Wss_MonRange_FL" , "Level" => "2"},
		"19F" => { "Name" => "DTC_415" , "Display_Code" => "C101B29" , "Text" => "Wss_MonRange_FR" , "Level" => "2"},
		"1A0" => { "Name" => "DTC_416" , "Display_Code" => "C101C29" , "Text" => "Wss_MonRange_RL" , "Level" => "2"},
		"1A1" => { "Name" => "DTC_417" , "Display_Code" => "C101D29" , "Text" => "Wss_MonRange_RR" , "Level" => "2"},
		"1A2" => { "Name" => "DTC_418" , "Display_Code" => "C101A29" , "Text" => "Wss_MonVDiff_FL" , "Level" => "2"},
		"1A3" => { "Name" => "DTC_419" , "Display_Code" => "C101B29" , "Text" => "Wss_MonVDiff_FR" , "Level" => "2"},
		"1A4" => { "Name" => "DTC_420" , "Display_Code" => "C106B29" , "Text" => "Wss_MonVDiff_Gen" , "Level" => "2"},
		"1A5" => { "Name" => "DTC_421" , "Display_Code" => "C101C29" , "Text" => "Wss_MonVDiff_RL" , "Level" => "2"},
		"1A6" => { "Name" => "DTC_422" , "Display_Code" => "C101D29" , "Text" => "Wss_MonVDiff_RR" , "Level" => "2"},
		"1A7" => { "Name" => "DTC_423" , "Display_Code" => "C106B07" , "Text" => "Wss_SignFA" , "Level" => "2"},
		"1A8" => { "Name" => "DTC_424" , "Display_Code" => "C106B07" , "Text" => "Wss_SignRA" , "Level" => "2"},
		"1AD" => { "Name" => "DTC_429" , "Display_Code" => "C104B29" , "Text" => "Yrs_FastOffset1" , "Level" => "2"},
		"1AE" => { "Name" => "DTC_430" , "Display_Code" => "C104B29" , "Text" => "Yrs_FastOffset2" , "Level" => "2"},
		"1AF" => { "Name" => "DTC_431" , "Display_Code" => "C104B29" , "Text" => "Yrs_Gain" , "Level" => "2"},
		"1B0" => { "Name" => "DTC_432" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonGrad" , "Level" => "2"},
		"1B2" => { "Name" => "DTC_434" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonRangeDriving" , "Level" => "2"},
		"1B4" => { "Name" => "DTC_436" , "Display_Code" => "C104B29" , "Text" => "Yrs_MonRangeVehStandstill" , "Level" => "2"},
		"1B5" => { "Name" => "DTC_437" , "Display_Code" => "C104B29" , "Text" => "Yrs_NormalOffset" , "Level" => "2"},
		"1B6" => { "Name" => "DTC_438" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausLimVal" , "Level" => "2"},
		"1B7" => { "Name" => "DTC_439" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausSas" , "Level" => "2"},
		"1B8" => { "Name" => "DTC_440" , "Display_Code" => "C104B29" , "Text" => "Yrs_PlausValidity" , "Level" => "2"},
		"1B9" => { "Name" => "DTC_441" , "Display_Code" => "C104B29" , "Text" => "Yrs_Sign" , "Level" => "2"},
		"1BA" => { "Name" => "DTC_442" , "Display_Code" => "C104B29" , "Text" => "Yrs_StandstillComp" , "Level" => "2"},
		"1C1" => { "Name" => "DTC_449" , "Display_Code" => "B200000" , "Text" => "MicInitSpiTestFail" , "Level" => "1"},
		"1C2" => { "Name" => "DTC_450" , "Display_Code" => "U101200" , "Text" => "SupplyOvervoltage" , "Level" => "2"},
		"1C3" => { "Name" => "DTC_451" , "Display_Code" => "B200000" , "Text" => "EcuWdFaultCounterTestFails" , "Level" => "1"},
		"1C8" => { "Name" => "DTC_456" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Vdc" , "Level" => "1"},
		"1C9" => { "Name" => "DTC_457" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Vdc" , "Level" => "1"},
		"1CA" => { "Name" => "DTC_458" , "Display_Code" => "B200000" , "Text" => "EcuWssDfaConfFail" , "Level" => "1"},
		"1CB" => { "Name" => "DTC_459" , "Display_Code" => "B200000" , "Text" => "CPUException" , "Level" => "1"},
		"1CE" => { "Name" => "DTC_462" , "Display_Code" => "U140000" , "Text" => "NET_Undervoltage" , "Level" => "2"},
		"1D3" => { "Name" => "DTC_467" , "Display_Code" => "B200000" , "Text" => "VlvBist" , "Level" => "1"},
		"1D9" => { "Name" => "DTC_473" , "Display_Code" => "C101504" , "Text" => "AcmHyd_ReturnPumpGenVoltageHigh" , "Level" => "1"},
		"1DA" => { "Name" => "DTC_474" , "Display_Code" => "C101504" , "Text" => "AcmHyd_ReturnPumpWeak" , "Level" => "1"},
		"1E7" => { "Name" => "DTC_487" , "Display_Code" => "C104B29" , "Text" => "Axs_MonConstSig" , "Level" => "2"},
		"1E8" => { "Name" => "DTC_488" , "Display_Code" => "C104B29" , "Text" => "Axs_PlausHighAccel" , "Level" => "2"},
		"1EA" => { "Name" => "DTC_490" , "Display_Code" => "C10C2F2" , "Text" => "AcmBtm_OverheatDuringActiveBraking" , "Level" => "6"},
		"1F1" => { "Name" => "DTC_497" , "Display_Code" => "C106B29" , "Text" => "Wss_MoreThanOneSuspectedStore" , "Level" => "2"},
		"20D" => { "Name" => "DTC_525" , "Display_Code" => "B200000" , "Text" => "ValveAvFlLeakage" , "Level" => "1"},
		"20E" => { "Name" => "DTC_526" , "Display_Code" => "B200000" , "Text" => "ValveAvFrLeakage" , "Level" => "1"},
		"20F" => { "Name" => "DTC_527" , "Display_Code" => "B200000" , "Text" => "ValveAvRlLeakage" , "Level" => "1"},
		"210" => { "Name" => "DTC_528" , "Display_Code" => "B200000" , "Text" => "ValveAvRrLeakage" , "Level" => "1"},
		"211" => { "Name" => "DTC_529" , "Display_Code" => "B200000" , "Text" => "ValveEvFlLeakage" , "Level" => "1"},
		"212" => { "Name" => "DTC_530" , "Display_Code" => "B200000" , "Text" => "ValveEvFrLeakage" , "Level" => "1"},
		"213" => { "Name" => "DTC_531" , "Display_Code" => "B200000" , "Text" => "ValveEvRlLeakage" , "Level" => "1"},
		"214" => { "Name" => "DTC_532" , "Display_Code" => "B200000" , "Text" => "ValveEvRrLeakage" , "Level" => "1"},
		"215" => { "Name" => "DTC_533" , "Display_Code" => "B200000" , "Text" => "ValveHsv1Leakage" , "Level" => "1"},
		"216" => { "Name" => "DTC_534" , "Display_Code" => "B200000" , "Text" => "ValveHsv2Leakage" , "Level" => "1"},
		"217" => { "Name" => "DTC_535" , "Display_Code" => "B200000" , "Text" => "ValveUsv1Leakage" , "Level" => "1"},
		"218" => { "Name" => "DTC_536" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Leakage" , "Level" => "1"},
		"219" => { "Name" => "DTC_537" , "Display_Code" => "B200000" , "Text" => "ValveFreeWheelingContOn" , "Level" => "1"},
		"21A" => { "Name" => "DTC_538" , "Display_Code" => "B2008F0" , "Text" => "ValveOverHeatProtection" , "Level" => "6"},
		"21B" => { "Name" => "DTC_539" , "Display_Code" => "B200000" , "Text" => "ValvePwmCheckContOn" , "Level" => "1"},
		"221" => { "Name" => "DTC_545" , "Display_Code" => "C101A29" , "Text" => "WssFLHetBufNoise" , "Level" => "2"},
		"222" => { "Name" => "DTC_546" , "Display_Code" => "C101B29" , "Text" => "WssFRHetBufNoise" , "Level" => "2"},
		"223" => { "Name" => "DTC_547" , "Display_Code" => "C101C29" , "Text" => "WssRLHetBufNoise" , "Level" => "2"},
		"224" => { "Name" => "DTC_548" , "Display_Code" => "C101D29" , "Text" => "WssRRHetBufNoise" , "Level" => "2"},
		"225" => { "Name" => "DTC_549" , "Display_Code" => "C106B16" , "Text" => "WssUndervoltage" , "Level" => "2"},
		"229" => { "Name" => "DTC_553" , "Display_Code" => "B2008F0" , "Text" => "RfpDiagHydrProtection" , "Level" => "6"},
		"22A" => { "Name" => "DTC_554" , "Display_Code" => "B200000" , "Text" => "RfpPMTFailed" , "Level" => "1"},
		"22B" => { "Name" => "DTC_555" , "Display_Code" => "B200000" , "Text" => "MicSpiTimeOut" , "Level" => "1"},
		"22D" => { "Name" => "DTC_557" , "Display_Code" => "U000100" , "Text" => "NET_BusOffNetwork0" , "Level" => "2"},
		"22F" => { "Name" => "DTC_559" , "Display_Code" => "U101200" , "Text" => "NET_Overvoltage" , "Level" => "2"},
		"231" => { "Name" => "DTC_561" , "Display_Code" => "B200000" , "Text" => "CUBAS_CAN_E_Timeout" , "Level" => "1"},
		"233" => { "Name" => "DTC_563" , "Display_Code" => "C101504" , "Text" => "ValveAvFlVart" , "Level" => "1"},
		"234" => { "Name" => "DTC_564" , "Display_Code" => "C101504" , "Text" => "ValveAvFrVart" , "Level" => "1"},
		"235" => { "Name" => "DTC_565" , "Display_Code" => "C101504" , "Text" => "ValveAvRlVart" , "Level" => "1"},
		"236" => { "Name" => "DTC_566" , "Display_Code" => "C101504" , "Text" => "ValveAvRrVart" , "Level" => "1"},
		"237" => { "Name" => "DTC_567" , "Display_Code" => "C101504" , "Text" => "ValveEvFlVart" , "Level" => "1"},
		"238" => { "Name" => "DTC_568" , "Display_Code" => "C101504" , "Text" => "ValveEvFrVart" , "Level" => "1"},
		"239" => { "Name" => "DTC_569" , "Display_Code" => "C101504" , "Text" => "ValveEvRlVart" , "Level" => "1"},
		"23A" => { "Name" => "DTC_570" , "Display_Code" => "C101504" , "Text" => "ValveEvRrVart" , "Level" => "1"},
		"23B" => { "Name" => "DTC_571" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Vart" , "Level" => "1"},
		"23C" => { "Name" => "DTC_572" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Vart" , "Level" => "1"},
		"23D" => { "Name" => "DTC_573" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Vart" , "Level" => "1"},
		"23E" => { "Name" => "DTC_574" , "Display_Code" => "B200000" , "Text" => "ValveUsv2Vart" , "Level" => "1"},
		"23F" => { "Name" => "DTC_575" , "Display_Code" => "C101504" , "Text" => "ValveAvFlPwm" , "Level" => "1"},
		"240" => { "Name" => "DTC_576" , "Display_Code" => "C101504" , "Text" => "ValveAvFrPwm" , "Level" => "1"},
		"241" => { "Name" => "DTC_577" , "Display_Code" => "C101504" , "Text" => "ValveAvRlPwm" , "Level" => "1"},
		"242" => { "Name" => "DTC_578" , "Display_Code" => "C101504" , "Text" => "ValveAvRrPwm" , "Level" => "1"},
		"243" => { "Name" => "DTC_579" , "Display_Code" => "C101504" , "Text" => "ValveEvFlPwm" , "Level" => "1"},
		"244" => { "Name" => "DTC_580" , "Display_Code" => "C101504" , "Text" => "ValveEvFrPwm" , "Level" => "1"},
		"245" => { "Name" => "DTC_581" , "Display_Code" => "C101504" , "Text" => "ValveEvRlPwm" , "Level" => "1"},
		"246" => { "Name" => "DTC_582" , "Display_Code" => "C101504" , "Text" => "ValveEvRrPwm" , "Level" => "1"},
		"247" => { "Name" => "DTC_583" , "Display_Code" => "C101504" , "Text" => "ValveHsv1Pwm" , "Level" => "1"},
		"248" => { "Name" => "DTC_584" , "Display_Code" => "C101504" , "Text" => "ValveHsv2Pwm" , "Level" => "1"},
		"249" => { "Name" => "DTC_585" , "Display_Code" => "C101504" , "Text" => "ValveUsv1Pwm" , "Level" => "1"},
		"24A" => { "Name" => "DTC_586" , "Display_Code" => "C101504" , "Text" => "ValveUsv2Pwm" , "Level" => "1"},
		"24B" => { "Name" => "DTC_587" , "Display_Code" => "B200000" , "Text" => "VlvINxFailure" , "Level" => "1"},
		"24C" => { "Name" => "DTC_588" , "Display_Code" => "B200000" , "Text" => "ValveReferenceResistor" , "Level" => "1"},
		"24D" => { "Name" => "DTC_589" , "Display_Code" => "B200000" , "Text" => "ValveReferenceEEPromError" , "Level" => "1"},
		"251" => { "Name" => "DTC_593" , "Display_Code" => "B200000" , "Text" => "VlvUVRmeasureComparisonFailure" , "Level" => "1"},
		"25C" => { "Name" => "DTC_604" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionFL" , "Level" => "2"},
		"25D" => { "Name" => "DTC_605" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionFR" , "Level" => "2"},
		"25E" => { "Name" => "DTC_606" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionRL" , "Level" => "2"},
		"25F" => { "Name" => "DTC_607" , "Display_Code" => "C102D00" , "Text" => "RKA_DiffusionRR" , "Level" => "2"},
		"260" => { "Name" => "DTC_608" , "Display_Code" => "C109DF0" , "Text" => "RKA_ERROR_CODE_CAL_INCOMPLETE" , "Level" => "2"},
		"261" => { "Name" => "DTC_609" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_INCORRECTLY_EXECUTED" , "Level" => "2"},
		"262" => { "Name" => "DTC_610" , "Display_Code" => "B200000" , "Text" => "RKA_ERROR_CODE_INCORRECT_LIB" , "Level" => "2"},
		"263" => { "Name" => "DTC_611" , "Display_Code" => "B200000" , "Text" => "RKA_ERROR_CODE_INVALID_F_MAPING" , "Level" => "2"},
		"264" => { "Name" => "DTC_612" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_INVALID_V_MAPING" , "Level" => "2"},
		"265" => { "Name" => "DTC_613" , "Display_Code" => "C109DF0" , "Text" => "RKA_ERROR_CODE_LOW_AVAILABILITY" , "Level" => "2"},
		"266" => { "Name" => "DTC_614" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_PermanentEepromAccess" , "Level" => "2"},
		"267" => { "Name" => "DTC_615" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_FL" , "Level" => "2"},
		"268" => { "Name" => "DTC_616" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_FR" , "Level" => "2"},
		"269" => { "Name" => "DTC_617" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_RL" , "Level" => "2"},
		"26A" => { "Name" => "DTC_618" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_LARGER_RR" , "Level" => "2"},
		"26B" => { "Name" => "DTC_619" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_FL" , "Level" => "2"},
		"26C" => { "Name" => "DTC_620" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_FR" , "Level" => "2"},
		"26D" => { "Name" => "DTC_621" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_RL" , "Level" => "2"},
		"26E" => { "Name" => "DTC_622" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_RADIUS_SMALLER_RR" , "Level" => "2"},
		"26F" => { "Name" => "DTC_623" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_0" , "Level" => "2"},
		"270" => { "Name" => "DTC_624" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_1" , "Level" => "2"},
		"272" => { "Name" => "DTC_626" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_0" , "Level" => "2"},
		"273" => { "Name" => "DTC_627" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_1" , "Level" => "2"},
		"274" => { "Name" => "DTC_628" , "Display_Code" => "C10A800" , "Text" => "RKA_ERROR_CODE_WRITE_PRIO_2" , "Level" => "2"},
		"275" => { "Name" => "DTC_629" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureFL" , "Level" => "2"},
		"276" => { "Name" => "DTC_630" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureFR" , "Level" => "2"},
		"277" => { "Name" => "DTC_631" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureRL" , "Level" => "2"},
		"278" => { "Name" => "DTC_632" , "Display_Code" => "C102D00" , "Text" => "RKA_PunctureRR" , "Level" => "2"},
		"292" => { "Name" => "DTC_658" , "Display_Code" => "C109C07" , "Text" => "PATA_HandbagLogic" , "Level" => "2"},
		"293" => { "Name" => "DTC_659" , "Display_Code" => "B200000" , "Text" => "PdmFieldSizeMismatch" , "Level" => "1"},
		"295" => { "Name" => "DTC_661" , "Display_Code" => "B200000" , "Text" => "PdmDeviceOutOfMemory" , "Level" => "1"},
		"296" => { "Name" => "DTC_662" , "Display_Code" => "B200000" , "Text" => "PdmCustomerIdMismatch" , "Level" => "1"},
		"297" => { "Name" => "DTC_663" , "Display_Code" => "B200000" , "Text" => "PdmDatFormatMismatch" , "Level" => "1"},
		"298" => { "Name" => "DTC_664" , "Display_Code" => "B200000" , "Text" => "PdmInternalHWError" , "Level" => "1"},
		"29E" => { "Name" => "DTC_670" , "Display_Code" => "B200000" , "Text" => "RTP_ENA_High" , "Level" => "1"},
		"2F3" => { "Name" => "DTC_755" , "Display_Code" => "B200000" , "Text" => "ValveEvFlFreeWheeling" , "Level" => "1"},
		"2F4" => { "Name" => "DTC_756" , "Display_Code" => "B200000" , "Text" => "ValveEvFrFreeWheeling" , "Level" => "1"},
		"2F5" => { "Name" => "DTC_757" , "Display_Code" => "B200000" , "Text" => "ValveEvRlFreeWheeling" , "Level" => "1"},
		"2F6" => { "Name" => "DTC_758" , "Display_Code" => "B200000" , "Text" => "ValveEvRrFreeWheeling" , "Level" => "1"},
		"2F7" => { "Name" => "DTC_759" , "Display_Code" => "B200000" , "Text" => "ValveHsv1FreeWheeling" , "Level" => "1"},
		"2F8" => { "Name" => "DTC_760" , "Display_Code" => "B200000" , "Text" => "ValveHsv2FreeWheeling" , "Level" => "1"},
		"2F9" => { "Name" => "DTC_761" , "Display_Code" => "B200000" , "Text" => "ValveUsv1FreeWheeling" , "Level" => "1"},
		"2FA" => { "Name" => "DTC_762" , "Display_Code" => "B200000" , "Text" => "ValveUsv2FreeWheeling" , "Level" => "1"},
		"2FB" => { "Name" => "DTC_763" , "Display_Code" => "B200000" , "Text" => "VlvAsicConfigEchoError" , "Level" => "1"},
		"2FC" => { "Name" => "DTC_764" , "Display_Code" => "B200000" , "Text" => "VlvUvrToUbvrLeakage" , "Level" => "1"},
		"2FD" => { "Name" => "DTC_765" , "Display_Code" => "B200000" , "Text" => "EcuADCSelftestError" , "Level" => "1"},
		"2FE" => { "Name" => "DTC_766" , "Display_Code" => "C106A16" , "Text" => "HydraulicSupplyHardUndervoltage" , "Level" => "2"},
		"2FF" => { "Name" => "DTC_767" , "Display_Code" => "C106B12" , "Text" => "WssReverseCurrent" , "Level" => "2"},
		"300" => { "Name" => "DTC_768" , "Display_Code" => "B200000" , "Text" => "WssModeFail" , "Level" => "1"},
		"302" => { "Name" => "DTC_770" , "Display_Code" => "B200000" , "Text" => "ValveInverseActTestFault" , "Level" => "1"},
		"317" => { "Name" => "DTC_791" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_MEMORY_PROTECTION" , "Level" => "2"},
		"318" => { "Name" => "DTC_792" , "Display_Code" => "C109D53" , "Text" => "RKA_ERROR_CODE_RUNTIME_OVERFLOW" , "Level" => "2"},
		"31B" => { "Name" => "DTC_795" , "Display_Code" => "C101A01" , "Text" => "WssFLWrongSens" , "Level" => "2"},
		"31C" => { "Name" => "DTC_796" , "Display_Code" => "C101B01" , "Text" => "WssFRWrongSens" , "Level" => "2"},
		"31D" => { "Name" => "DTC_797" , "Display_Code" => "C101C01" , "Text" => "WssRLWrongSens" , "Level" => "2"},
		"31E" => { "Name" => "DTC_798" , "Display_Code" => "C101D01" , "Text" => "WssRRWrongSens" , "Level" => "2"},
		"333" => { "Name" => "DTC_819" , "Display_Code" => "B200000" , "Text" => "VlvOpenLoadUnderCurrentBitFailureVart" , "Level" => "1"},
		"347" => { "Name" => "DTC_839" , "Display_Code" => "B200000" , "Text" => "ValveSvdtContOn" , "Level" => "1"},
		"351" => { "Name" => "DTC_849" , "Display_Code" => "B200000" , "Text" => "VlvUvrLowSPIBitFailure" , "Level" => "1"},
		"352" => { "Name" => "DTC_850" , "Display_Code" => "C106A01" , "Text" => "VlvSupplyLineTest" , "Level" => "2"},
		"35E" => { "Name" => "DTC_862" , "Display_Code" => "B200000" , "Text" => "UnsupportedHardware" , "Level" => "1"},
		"35F" => { "Name" => "DTC_863" , "Display_Code" => "B200000" , "Text" => "MicIntMonGenericBitMon" , "Level" => "1"},
		"361" => { "Name" => "DTC_865" , "Display_Code" => "B200000" , "Text" => "VrSafetySwitchTestTimeout" , "Level" => "1"},
		"363" => { "Name" => "DTC_867" , "Display_Code" => "B200000" , "Text" => "STM_AswSystemTimeOut" , "Level" => "1"},
		"369" => { "Name" => "DTC_873" , "Display_Code" => "B200000" , "Text" => "VoltagePreRegModeFail" , "Level" => "1"},
		"36D" => { "Name" => "DTC_877" , "Display_Code" => "C10A700" , "Text" => "RollerBenchMode" , "Level" => "1"},
		"36F" => { "Name" => "DTC_879" , "Display_Code" => "U101100" , "Text" => "EcuSupplyVoltageDividerDrift" , "Level" => "1"},
		"370" => { "Name" => "DTC_880" , "Display_Code" => "U000100" , "Text" => "CUBAS_CAN_E_HW_ERROR" , "Level" => "2"},
		"371" => { "Name" => "DTC_881" , "Display_Code" => "U101300" , "Text" => "VehicleConfigPDMEmpty" , "Level" => "2"},
		"372" => { "Name" => "DTC_882" , "Display_Code" => "U101300" , "Text" => "VehicleConfigPDMReadError" , "Level" => "2"},
		"373" => { "Name" => "DTC_883" , "Display_Code" => "U101300" , "Text" => "VehicleConfigUncoded" , "Level" => "2"},
		"374" => { "Name" => "DTC_884" , "Display_Code" => "U101300" , "Text" => "VehicleConfigVarCodeNotFound" , "Level" => "2"},
		"375" => { "Name" => "DTC_885" , "Display_Code" => "U044700" , "Text" => "VarCheckNetVinTimeout" , "Level" => "2"},
		"376" => { "Name" => "DTC_886" , "Display_Code" => "U044700" , "Text" => "VarCheckNetVinNotinitialized" , "Level" => "2"},
		"377" => { "Name" => "DTC_887" , "Display_Code" => "C104AF0" , "Text" => "VarCheckVinSanityCheckFailed" , "Level" => "2"},
		"378" => { "Name" => "DTC_888" , "Display_Code" => "U101300" , "Text" => "VarCheckVariantNotFound" , "Level" => "2"},
		"379" => { "Name" => "DTC_889" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_GearboxTypeNotAvailable" , "Level" => "2"},
		"37A" => { "Name" => "DTC_890" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_GearboxPlausibilityError" , "Level" => "2"},
		"37B" => { "Name" => "DTC_891" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_SteeringPositionNotAvailable" , "Level" => "2"},
		"37C" => { "Name" => "DTC_892" , "Display_Code" => "U10BC00" , "Text" => "VarCodVehicleModelNotFound" , "Level" => "2"},
		"37D" => { "Name" => "DTC_893" , "Display_Code" => "U10BC00" , "Text" => "VarCodNetVinTimeout" , "Level" => "2"},
		"37E" => { "Name" => "DTC_894" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_GearboxTypeNotAvailable" , "Level" => "2"},
		"37F" => { "Name" => "DTC_895" , "Display_Code" => "U10BC00" , "Text" => "VarCodNetVinNotinitialized" , "Level" => "2"},
		"380" => { "Name" => "DTC_896" , "Display_Code" => "C104AF0" , "Text" => "VarCodVinMismatch" , "Level" => "2"},
		"381" => { "Name" => "DTC_897" , "Display_Code" => "U10BC00" , "Text" => "VarCodVariantNotFound" , "Level" => "2"},
		"382" => { "Name" => "DTC_898" , "Display_Code" => "U101400" , "Text" => "VAR_StartStopPlausibiltyError" , "Level" => "2"},
		"383" => { "Name" => "DTC_899" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_1_DataCorrupt" , "Level" => "2"},
		"384" => { "Name" => "DTC_900" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_1_Timeout" , "Level" => "2"},
		"385" => { "Name" => "DTC_901" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_2_DataCorrupt" , "Level" => "2"},
		"386" => { "Name" => "DTC_902" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_2_Timeout" , "Level" => "2"},
		"387" => { "Name" => "DTC_903" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineTrq_Invalid" , "Level" => "2"},
		"388" => { "Name" => "DTC_904" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineTrqLoss_Invalid" , "Level" => "2"},
		"389" => { "Name" => "DTC_905" , "Display_Code" => "U101F00" , "Text" => "Scl_DriverReqTrq_Invalid" , "Level" => "2"},
		"38A" => { "Name" => "DTC_906" , "Display_Code" => "U101F00" , "Text" => "Scl_AccPedalPos_Invalid" , "Level" => "2"},
		"38B" => { "Name" => "DTC_907" , "Display_Code" => "U101F00" , "Text" => "Scl_AccPedalPosRaw_Invalid" , "Level" => "2"},
		"38C" => { "Name" => "DTC_908" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineSpeed_Invalid" , "Level" => "2"},
		"38D" => { "Name" => "DTC_909" , "Display_Code" => "U101F00" , "Text" => "Scl_EngineECU_Faulty" , "Level" => "2"},
		"38E" => { "Name" => "DTC_910" , "Display_Code" => "U101F00" , "Text" => "Scl_MotDrvReqTrqLimitation_Invalid" , "Level" => "2"},
		"38F" => { "Name" => "DTC_911" , "Display_Code" => "U101F00" , "Text" => "Scl_GearBoxType_Invalid" , "Level" => "2"},
		"390" => { "Name" => "DTC_912" , "Display_Code" => "U044700" , "Text" => "ComScl_mGate_Komf_1_DataCorrupt" , "Level" => "2"},
		"391" => { "Name" => "DTC_913" , "Display_Code" => "U014600" , "Text" => "ComScl_mGate_Komf_1_Timeout" , "Level" => "2"},
		"392" => { "Name" => "DTC_914" , "Display_Code" => "U040200" , "Text" => "ComScl_mGetriebe_1_DataCorrupt" , "Level" => "2"},
		"393" => { "Name" => "DTC_915" , "Display_Code" => "U010100" , "Text" => "ComScl_mGetriebe_1_Timeout" , "Level" => "2"},
		"394" => { "Name" => "DTC_916" , "Display_Code" => "U102600" , "Text" => "Scl_TargetGear_Invalid" , "Level" => "2"},
		"395" => { "Name" => "DTC_917" , "Display_Code" => "U102600" , "Text" => "Scl_GearLever_Invalid" , "Level" => "2"},
		"397" => { "Name" => "DTC_919" , "Display_Code" => "U042300" , "Text" => "ComScl_mKombi_3_DataCorrupt" , "Level" => "2"},
		"398" => { "Name" => "DTC_920" , "Display_Code" => "U015500" , "Text" => "ComScl_mKombi_3_Timeout" , "Level" => "2"},
		"399" => { "Name" => "DTC_921" , "Display_Code" => "U045200" , "Text" => "ComScl_mAirbag_1_DataCorrupt" , "Level" => "3"},
		"39A" => { "Name" => "DTC_922" , "Display_Code" => "U015100" , "Text" => "ComScl_mAirbag_1_Timeout" , "Level" => "3"},
		"39B" => { "Name" => "DTC_923" , "Display_Code" => "U044700" , "Text" => "ComScl_mDiagnose_1_DataCorrupt" , "Level" => "2"},
		"39C" => { "Name" => "DTC_924" , "Display_Code" => "U014600" , "Text" => "ComScl_mDiagnose_1_Timeout" , "Level" => "2"},
		"39D" => { "Name" => "DTC_925" , "Display_Code" => "U045200" , "Text" => "ComScl_AB1_Checksum" , "Level" => "3"},
		"39E" => { "Name" => "DTC_926" , "Display_Code" => "U045200" , "Text" => "ComScl_AB1_ACounter" , "Level" => "3"},
		"39F" => { "Name" => "DTC_927" , "Display_Code" => "U042300" , "Text" => "ComScl_mIdent_DataCorrupt" , "Level" => "2"},
		"3A0" => { "Name" => "DTC_928" , "Display_Code" => "U015500" , "Text" => "ComScl_mIdent_Timeout" , "Level" => "2"},
		"3A1" => { "Name" => "DTC_929" , "Display_Code" => "U014000" , "Text" => "Scl_ReverseLight_Invalid" , "Level" => "2"},
		"3A2" => { "Name" => "DTC_930" , "Display_Code" => "U014000" , "Text" => "Scl_DriverDoor_Invalid" , "Level" => "2"},
		"3A3" => { "Name" => "DTC_931" , "Display_Code" => "U102400" , "Text" => "Scl_WheelCircumference_Invalid" , "Level" => "2"},
		"3A4" => { "Name" => "DTC_932" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_10_DataCorrupt" , "Level" => "2"},
		"3A5" => { "Name" => "DTC_933" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_10_Timeout" , "Level" => "2"},
		"3A6" => { "Name" => "DTC_934" , "Display_Code" => "U101F00" , "Text" => "Scl_TiOutBr_EngineTimeout" , "Level" => "2"},
		"3A7" => { "Name" => "DTC_935" , "Display_Code" => "U101F00" , "Text" => "Scl_NormTorque_Invalid" , "Level" => "2"},
		"3AB" => { "Name" => "DTC_939" , "Display_Code" => "U043200" , "Text" => "IISMM8ConfigurationError" , "Level" => "2"},
		"3AD" => { "Name" => "DTC_941" , "Display_Code" => "U043200" , "Text" => "IISEEPromError" , "Level" => "2"},
		"3AF" => { "Name" => "DTC_943" , "Display_Code" => "U043200" , "Text" => "IISOEMCalibrationError" , "Level" => "2"},
		"3B0" => { "Name" => "DTC_944" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_SteeringPositionPlausibilityError" , "Level" => "2"},
		"3B1" => { "Name" => "DTC_945" , "Display_Code" => "U101400" , "Text" => "VAR_Checking_BuiltGatewayInfoSetToInvalid" , "Level" => "2"},
		"3B2" => { "Name" => "DTC_946" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_SteeringPositionNotAvailable" , "Level" => "2"},
		"3B3" => { "Name" => "DTC_947" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_SteeringPositionPlausibilityError" , "Level" => "2"},
		"3B4" => { "Name" => "DTC_948" , "Display_Code" => "U10BC00" , "Text" => "VAR_Coding_BuiltGatewayInfoSetToInvalid" , "Level" => "2"},
		"3CF" => { "Name" => "DTC_975" , "Display_Code" => "U10B100" , "Text" => "A2S_MonRange" , "Level" => "2"},
		"3D0" => { "Name" => "DTC_976" , "Display_Code" => "U043200" , "Text" => "A1S_MonRange" , "Level" => "2"},
		"3D2" => { "Name" => "DTC_978" , "Display_Code" => "C101729" , "Text" => "Axs_MissAllignmentDetect" , "Level" => "2"},
		"3D3" => { "Name" => "DTC_979" , "Display_Code" => "C101729" , "Text" => "Ays_MissAllignmentDetect" , "Level" => "2"},
		"3D4" => { "Name" => "DTC_980" , "Display_Code" => "U040100" , "Text" => "ComScl_mMotor_3_DataCorrupt" , "Level" => "2"},
		"3D5" => { "Name" => "DTC_981" , "Display_Code" => "U010000" , "Text" => "ComScl_mMotor_3_Timeout" , "Level" => "2"},
		"3D6" => { "Name" => "DTC_982" , "Display_Code" => "U042300" , "Text" => "ComScl_mKombi_1_DataCorrupt" , "Level" => "2"},
		"3D7" => { "Name" => "DTC_983" , "Display_Code" => "U015500" , "Text" => "ComScl_mKombi_1_Timeout" , "Level" => "2"},
		"3D8" => { "Name" => "DTC_984" , "Display_Code" => "U044700" , "Text" => "ComScl_mSysteminfo_1_DataCorrupt" , "Level" => "2"},
		"3D9" => { "Name" => "DTC_985" , "Display_Code" => "U014600" , "Text" => "ComScl_mSysteminfo_1_Timeout" , "Level" => "2"},
		"3DA" => { "Name" => "DTC_986" , "Display_Code" => "U042800" , "Text" => "ComScl_mLW_1_DataCorrupt" , "Level" => "2"},
		"3DB" => { "Name" => "DTC_987" , "Display_Code" => "U012600" , "Text" => "ComScl_mLW_1_Timeout" , "Level" => "2"},
		"3DC" => { "Name" => "DTC_988" , "Display_Code" => "U042800" , "Text" => "ComScl_LW1_Checksum" , "Level" => "2"},
		"3DD" => { "Name" => "DTC_989" , "Display_Code" => "U042800" , "Text" => "ComScl_LW1_ACounter" , "Level" => "2"},
		"3DE" => { "Name" => "DTC_990" , "Display_Code" => "B116854" , "Text" => "Scl_CalibrationWrongSasIDFailure" , "Level" => "2"},
		"3DF" => { "Name" => "DTC_991" , "Display_Code" => "B116854" , "Text" => "Scl_PDM_SASIDWriteError" , "Level" => "2"},
		"3E0" => { "Name" => "DTC_992" , "Display_Code" => "B116854" , "Text" => "Scl_PDM_SASIDReadError" , "Level" => "2"},
		"3E1" => { "Name" => "DTC_993" , "Display_Code" => "B116854" , "Text" => "Scl_SasID_Invalid" , "Level" => "2"},
		"3E2" => { "Name" => "DTC_994" , "Display_Code" => "U102D00" , "Text" => "Scl_SasStatus_Invalid" , "Level" => "2"},
		"3E3" => { "Name" => "DTC_995" , "Display_Code" => "B200FF0" , "Text" => "Scl_Sas_InitSource_Invalid" , "Level" => "255"},
		"3E4" => { "Name" => "DTC_996" , "Display_Code" => "B200FF0" , "Text" => "Scl_Sas_InvalidReInitialization" , "Level" => "255"},
		"3E5" => { "Name" => "DTC_997" , "Display_Code" => "C113404" , "Text" => "EbdLampPlausibility" , "Level" => "1"},
		"3E6" => { "Name" => "DTC_998" , "Display_Code" => "C113604" , "Text" => "AbsLampPlausibility" , "Level" => "1"},
		"3E7" => { "Name" => "DTC_999" , "Display_Code" => "C113504" , "Text" => "EspAsrLampPlausibility" , "Level" => "1"},
		"3EB" => { "Name" => "DTC_1003" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2ABSbyAC1100" , "Level" => "2"},
		"3EC" => { "Name" => "DTC_1004" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2TCSbyAC1101" , "Level" => "2"},
		"3ED" => { "Name" => "DTC_1005" , "Display_Code" => "C10C800" , "Text" => "LimitSystem2ABSwithPTCbyAC1102" , "Level" => "2"},
		"3EE" => { "Name" => "DTC_1006" , "Display_Code" => "C107629" , "Text" => "DoorSwitchPlausibility" , "Level" => "3"},
		"3EF" => { "Name" => "DTC_1007" , "Display_Code" => "B200000" , "Text" => "HETReferenceError" , "Level" => "1"},
		"3F0" => { "Name" => "DTC_1008" , "Display_Code" => "U043200" , "Text" => "IISMM8ClockCountMonitor" , "Level" => "2"},
		"3F1" => { "Name" => "DTC_1009" , "Display_Code" => "U043200" , "Text" => "IISMM8GeneralAsFault" , "Level" => "2"},
		"3F2" => { "Name" => "DTC_1010" , "Display_Code" => "C107D04" , "Text" => "IISMM8GeneralYrsFault" , "Level" => "2"},
		"3F3" => { "Name" => "DTC_1011" , "Display_Code" => "U043200" , "Text" => "IISMM8InternalHWTestTimeout" , "Level" => "2"},
		"3F4" => { "Name" => "DTC_1012" , "Display_Code" => "U043200" , "Text" => "IISMM8RetrieveHWVersionErr" , "Level" => "2"},
		"3F5" => { "Name" => "DTC_1013" , "Display_Code" => "U043200" , "Text" => "IISMM8RetrieveInitialTempErr" , "Level" => "2"},
		"3F6" => { "Name" => "DTC_1014" , "Display_Code" => "U012500" , "Text" => "IISMM8SpiTransError" , "Level" => "2"},
		"3F7" => { "Name" => "DTC_1015" , "Display_Code" => "U043200" , "Text" => "IISMM8WrongHWRevision" , "Level" => "2"},
		"3F8" => { "Name" => "DTC_1016" , "Display_Code" => "B200000" , "Text" => "MicInitSpiTransferError" , "Level" => "1"},
		"3F9" => { "Name" => "DTC_1017" , "Display_Code" => "C101504" , "Text" => "RfpActUBMRSupplyError" , "Level" => "1"},
		"3FA" => { "Name" => "DTC_1018" , "Display_Code" => "B200FF0" , "Text" => "LimitSystemByBS041B" , "Level" => "255"},
		"40C" => { "Name" => "DTC_1036" , "Display_Code" => "B200FF0" , "Text" => "IISMM8YrsFailureIntegral" , "Level" => "255"},
		"40D" => { "Name" => "DTC_1037" , "Display_Code" => "B200FF0" , "Text" => "IISMM8SpiTimingViolation" , "Level" => "255"},
		"40E" => { "Name" => "DTC_1038" , "Display_Code" => "B200FF0" , "Text" => "IISMM8SensorCRCCheck" , "Level" => "255"},
		"40F" => { "Name" => "DTC_1039" , "Display_Code" => "B200FF0" , "Text" => "IISMM8AsFailureIntegral" , "Level" => "255"},
		"410" => { "Name" => "DTC_1040" , "Display_Code" => "B200FF0" , "Text" => "IISMM8GSBitsMissed" , "Level" => "255"},
		"411" => { "Name" => "DTC_1041" , "Display_Code" => "C102C00" , "Text" => "RKA_ERROR_CODE_READ_PRIO_2" , "Level" => "2"},
		"412" => { "Name" => "DTC_1042" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_WRITE_DIAGNOSE_DATA" , "Level" => "255"},
		"413" => { "Name" => "DTC_1043" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_READ_DIAGNOSE_DATA" , "Level" => "255"},
		"414" => { "Name" => "DTC_1044" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_CALIB_BUTTON_STUCK" , "Level" => "255"},
		"415" => { "Name" => "DTC_1045" , "Display_Code" => "B200FF0" , "Text" => "RKA_ERROR_CODE_TPID_INCORRECT_LIB" , "Level" => "255"},
		"FFFFFF" => { "Name" => "DTC_16777215" , "Display_Code" => "" , "Text" => "All Supported DTCs" , "Level" => "9"},
	},# end of DTC 
	#------------------------------------------------------------------
	"GlobalNRC" => 
	{ 
		"10" => "generalReject",
		"11" => "serviceNotSupported",
		"12" => "subFunctionNotSupported",
		"13" => "incorrectMessageLengthOrInvalidFormat",
		"14" => "responseTooLong",
		"21" => "busyRepeatRequest",
		"22" => "conditionsNotCorrect",
		"24" => "requestSequenceError",
		"25" => "noResponseFromSubnetComponent",
		"26" => "failurePreventsExecutionOfRequestedAction",
		"31" => "requestOutOfRange",
		"33" => "securityAccessDenied",
		"35" => "invalidKey",
		"36" => "exceedNumberOfAttempts",
		"37" => "requiredTimeDelayNotExpired",
		"70" => "uploadDownloadNotAccepted",
		"71" => "transferDataSuspended",
		"72" => "generalProgrammingFailure",
		"73" => "wrongBlockSequenceCounter",
		"78" => "requestCorrectlyReceived_ResponsePending",
		"7E" => "subFunctionNotSupportedInActiveSession",
		"7F" => "serviceNotSupportedInActiveSession",
		"81" => "rpmTooHigh",
		"82" => "rpmTooLow",
		"83" => "engineIsRunning",
		"84" => "engineIsNotRunning",
		"85" => "engineRunTimeTooLow",
		"86" => "temperatureTooHigh",
		"87" => "temperatureTooLow",
		"88" => "vehicleSpeedTooHigh",
		"89" => "vehicleSpeedTooLow",
		"8A" => "throttle_PedalTooHigh",
		"8B" => "throttle_PedalTooLow",
		"8C" => "transmissionRangeNotInNeutral",
		"8D" => "transmissionRangeNotInGear",
		"8F" => "brakeSwitchNotClosed",
		"90" => "shifterLeverNotInPark",
		"91" => "torqueConverterClutchLocked",
		"92" => "voltageTooHigh",
		"93" => "voltageTooLow",
	}, #end of Global NRC
	#------------------------------------------------------------------
}; # end of DIAG mapping 
1;
