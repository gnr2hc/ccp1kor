#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################


my $addpath;
BEGIN
{
    my $LIFT_exec_path='./../../';

    # add directories to search path for perl modules    
    unshift @INC, "$LIFT_exec_path/modules";

}


use strict;
use warnings;
use Getopt::Long;
use Tk;

my $INfile;

=head1 usage

create parameter files for TC_LV124_E_13.pm based on project defaults file


 CLI: LV124_E13_paraGen.pl --file [file]
 e.g. LV124_E13_paraGen.pl --file C:\Users\phc2si\Documents\LIFT\MLB\config\MLB_ProjectConstX1X2.pm


=head1 AUTHOR

Christian Prosch, E<lt>Christian.Prosch@de.bosch.comE<gt>

=cut



my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "create LV124_E13 parameter file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create parameter file for LV124_E13 test based on project defaults file",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$INfile, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $INfile = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["perl modules", '.pm'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.pm)",
                        );
                      # if a file was chosen
                      if ( $INfile )
                        {
                        #extract directory
                        print "\n $INfile was chosen\n";
                        $display_txt="$INfile was chosen";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($INfile) { # create project if scan_file was given
        create_params();
        $INfile = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)


# run with CLI
GetOptions('file=s' => \$INfile );
if ($INfile){ # source file
    print("running with CLI\n");
    create_params();
}
else{
  # if no options, run TK GUI
  print("running with TK\n");
  MainLoop();
}


#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++






sub create_params{

# check for blanks !

	if ($INfile !~ /\.pm$/){
    	$display_txt="error: see error message in the Perl.exe window";
		die "input file $INfile is not a .pm file\n";
	}

    print "loading Project defaults\n";
    require "$INfile";        # contains package LIFT_PROJECT
    
    if( not defined $LIFT_PROJECT::Defaults ){
    	$display_txt="error: see error message in the Perl.exe window";
    	die "input file $INfile has no \$LIFT_PROJECT::Defaults defined\n";
    }
    if( not defined $LIFT_PROJECT::Defaults->{"TSG4"} ){
    	$display_txt="error: see error message in the Perl.exe window";
    	die "input file $INfile has no TSG4 section\n";    	
    }

	my @deviceTypes = ('SQUIBS', 'PAS_LINES', 'BELT_LOCKS');
	my $testcaseName = 'TC_LV124_E_13';
	my @sequences = ('10s_single', '1ms_single', '1us_cycle_4s');
	open (FILE,">$testcaseName.par") or warn "could not write output file $testcaseName.par: $@\n";
	
	print FILE"# Parameter file  '$testcaseName.par'\n";
	print FILE"\n";
	
	my ($reset, $lineFault);

	foreach my $deviceType ( @deviceTypes ){
		foreach my $key ( sort keys %{$LIFT_PROJECT::Defaults->{"TSG4"}{$deviceType}} ){
			if( $key =~ /_Name$/ ){
				my $line = $LIFT_PROJECT::Defaults->{"TSG4"}{$deviceType}{$key};
				if( $deviceType =~ /PAS_LINES/i ){
					$reset = 1;
					$lineFault = 'Flt'.$line.'ExternalCommunication';
				}
				elsif( $deviceType =~ /SQUIBS/i ){
					$reset = 0;
					$lineFault = 'Flt'.$line.'ResistanceOpen';
				}
				elsif( $deviceType =~ /BELT_LOCKS/i ){
					$reset = 0;
					$lineFault = 'FltSwitch'.$line.'OpenLine';					
				}
				foreach my $sequence (@sequences){
					my $sequenceShort = $sequence;
					$sequenceShort =~ s/_//g;
					print FILE "[$testcaseName.".$line."_".$sequenceShort."]\n";
					print FILE "purpose               = 'line = $line, sequence = $sequence'\n";
					print FILE "line                  = '$line'\n";
					print FILE "sequence              = '$sequence'\n";
					print FILE "reset                 = '$reset'\n";
					print FILE "lineFault             = '$lineFault'\n";
					print FILE "waitAfterInterrupt_ms = 10000\n";
					print FILE "voltage               = 13\n";
					print FILE "\n";

				}
			}
		}
	}
		
	
	
	close(FILE);
	
	
	$display_txt="done";
}

# end of program
