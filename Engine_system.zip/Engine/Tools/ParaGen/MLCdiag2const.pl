# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: Tools/ParaGen/MLCdiag2const.pl $
#    $Revision: 1.2 $
#    $State: develop $
#******************************************************************************************************

use strict;
use warnings;
use Data::Dumper;
use Getopt::Long;

my ($diag_file, $SAD_file);
my (@diag_file,$line);
my $CAN_parameter = './../Engine/modules/DLLs/PD/CAN_parameter.txt';

GetOptions('diag=s' => \$diag_file, 'sad=s' => \$SAD_file );

unless ($SAD_file){
	warn "\!!! no SAD file given !!!\n CLI: MLCdiag2const.pl --diag [file] --sad [file]\n\n";
	#exit;
}
unless ($diag_file){
	warn "\!!! no diag file given !!!\n CLI: MLCdiag2const.pl --diag [file] --sad [file]\n\n";
	#exit;
}

my ($baud,$Tseg1,$Tseg2,$SJW,$SAM,$RESPONSE_ID,$REQUEST_ID,$SIZE_OF_DTC,$EXTENTED_ADDRESS_MODE,$USE_EXT_CAN_ID,$DLC_ZERO_PADDING,$ECU_NUMBER,$TARGET_ADDRESS);
$baud=$Tseg1=$Tseg2=$SJW=$SAM=$SIZE_OF_DTC=$EXTENTED_ADDRESS_MODE=$USE_EXT_CAN_ID=$DLC_ZERO_PADDING=$ECU_NUMBER=$TARGET_ADDRESS="'?'";
$REQUEST_ID=$RESPONSE_ID='?';

# store file in array
if (defined $diag_file){
	if (open (IN, "<$diag_file")){ 
		while($line =<IN>){
			if ($line =~ /^\s*SIZE_OF_DTC\s*=\s*(\w+)/){$SIZE_OF_DTC=$1;}
			if ($line =~ /^\s*REQUEST_ID\s*=\s*(\w+)/){$REQUEST_ID=$1;}
			if ($line =~ /^\s*RESPONSE_ID\s*=\s*(\w+)/){$RESPONSE_ID=$1;}
			if ($line =~ /^\s*EXTENTED_ADDRESS_MODE\s*=\s*(\w+)/){$EXTENTED_ADDRESS_MODE=$1;}
			if ($line =~ /^\s*USE_EXT_CAN_ID\s*=\s*(\w+)/){$USE_EXT_CAN_ID=$1;}
			if ($line =~ /^\s*DLC_ZERO_PADDING\s*=\s*(\w+)/){$DLC_ZERO_PADDING=$1;}
			if ($line =~ /^\s*TARGET_ADDRESS\s*=\s*(\w+)/){$TARGET_ADDRESS=$1;}
			if ($line =~ /^\s*ECU_NUMBER\s*=\s*(\w+)/){$ECU_NUMBER=$1;}
		}
		close(IN);
	}
	else{
		warn "\!!! input file $diag_file not found !!!\n";
	}
}

#$DLC_ZERO_PADDING is inverted!
if ($DLC_ZERO_PADDING eq '0'){
	$DLC_ZERO_PADDING = 1;
}
else{
	$DLC_ZERO_PADDING = 0;
}


my $CANtype='';
if (defined $SAD_file){
	if (open (IN, "<$SAD_file")){ 
		while ($line = <IN>){
			#match	CAN Type            : MB_CAN_01
			if ($line =~ m/^\s*CAN Type\s+:\s+(\S+)/){
				$CANtype=$1;
				print"CANtype $CANtype\n";
				last;			
			}
		}
		close(IN);
	}
	else{
		warn "\!!! input file $SAD_file not found !!!\n";
	}
}

if ($CANtype ne ''){
	if (open (IN, "<$CAN_parameter")){ 
		while ($line = <IN>){
			#match	CANTyp_MB_CAN_01=7A120,C,3,3,1,64C,509,BR221,High Speed 251
			if ($line =~ m/^CANTyp_$CANtype=(\S+)/){
				my $CANpara=$1;
				
				#BAUDRATE,TSEG1,TSEG2,SJW,SAM,Id(PDiag_2_ABECU),Id(ABECU_2_Pdiag)
				#7A120,C,3,3,1,64C,509
				($baud,$Tseg1,$Tseg2,$SJW,$SAM) = split(/,/,$CANpara);
				$Tseg1 = '0x'.$Tseg1;
				$Tseg2 = '0x'.$Tseg2;
				$baud = hex($baud);
				last;			
			}
		}
		close(IN);
	}
	else{
		warn "\!!! input file $CAN_parameter not found !!!\n";
	}
}


open (OUT, ">DIAG_const.txt");

	print OUT "   'CUSTOMER_DIAGNOSIS' => {\n";
	print OUT "        'RequestID_phys' => '$REQUEST_ID',\n";
	print OUT "        'ResponseID_phys' => '$RESPONSE_ID',\n";
	print OUT "        'FlowControlID_phys' => '$REQUEST_ID',\n";
	print OUT "        'Timeout_phys' => 10000,\n";
	print OUT "\n";
	print OUT "        'RequestID_func' => '$REQUEST_ID',\n";
	print OUT "        'ResponseID_func' => '$RESPONSE_ID',\n";
	print OUT "        'FlowControlID_func' => '$REQUEST_ID',\n";
	print OUT "        'Timeout_func' => 10000,              #in milliseconds\n";
	print OUT "\n";
	print OUT "        'FlowControl' => [0x30,0x0f,0x01],       #3 Bytes as array ref\n";
	print OUT "        'clearDTC' => [0x14,0xff,0xff,0xff],     #Bytes as array ref\n";
	print OUT "        'SAM' => $SAM,\n";
	print OUT "        'SJW' => $SJW,\n";
	print OUT "        'Tseg1' => $Tseg1,\n";
	print OUT "        'Tseg2' => $Tseg2,\n";
	print OUT "        'Baudrate' => $baud,\n";
	print OUT "        'DLCmode' => $DLC_ZERO_PADDING,                     # 0 for 8 byte, 1 for dynamic DLC\n";
	print OUT "        'DTCdefaultstate' => 0x8,\n";
	print OUT "        'DTCbytes' => $SIZE_OF_DTC,                    # bytes per DTC\n"; 
	print OUT "        'ExtID' => $USE_EXT_CAN_ID,                       # 1 for Extended Identifier, 0 for Standard\n"; 
	print OUT "        'ExtAddressing' => $EXTENTED_ADDRESS_MODE,               # 1 for Extended Addressing, 0 for Normal\n";
	print OUT "        'EcuAddr' => $TARGET_ADDRESS,                  # ECU id for Extended Addressing.\n";
	print OUT "        'TargetAddr' => $ECU_NUMBER,               # Target address for Extended Addressing.\n";
	print OUT "\n";
	print OUT "        'DISABLE' => 1,                 # optional, to disable all CD features (similar to debug mode)\n";
	print OUT "    },\n";
	
close(OUT);
print"DIAG_const.txt created\n";

# end of program

=head1 usage

create MLC ProjectConst section for TurboLIFT from MLC_diag.ini file and SAD file

 CLI: MLCdiag2const.pl --diag [file] --sad [file]
 e.g. MLCdiag2const.pl --diag MLC_diag.ini --sad BB25736.sad


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

