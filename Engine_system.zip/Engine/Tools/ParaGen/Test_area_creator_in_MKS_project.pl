# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

use strict;
use warnings;
use File::Basename;
use Win32;


#######################################################################################
#
# PURPOSE: 
#
# This tool creates test areas in MKS(only) to the project name given as input.
#
# All the released test areas in MKS will be configured to the Project.
#
# Each test area to configured manually to a particual test area checkpoint/Version.
#
#######################################################################################


############## ROOT PROJECT ##############################################


# TODO Enter the MKS path one level below the actual created project
my $rootproject= 'g:/MKS/Projects/TurboLIFT/Projects/Projects.pj';

##################### NEW PROJECT NAME ####################################
# TODO name of project to be created
my $projectname = "IN_MS";

# just for testing: comment later
my $rootfolder = dirname($rootproject);


# create folders in sandbox

my ($cmd, $result, @file, $line);

 my ($response);
    my %resp_map = (
        6 => 'yes',
        7 => 'no',
    );
	
my $response = Win32::MsgBox( "Executing this file will create test areas for project '$projectname' in MKS.\n Are you Sure you want to create it ? ", ( 4 ), 'Warning!' );
 $response = $resp_map{$response};

 unless ($response eq 'yes'){
	print "Pressed 'cancel' no project will be created\n";
	exit;
 }

print "Pressed 'ok' creating test areas for Project '$projectname'\n";

 
 #share the subproject Test area CREIS
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_CREIS\TestArea_CREIS.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_CREIS\TestArea_CREIS.pj';
 MKS_command($cmd);
 
  # #share the subproject Test area EDR
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_EDR\TestArea_EDR.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_EDR\TestArea_EDR.pj';
 MKS_command($cmd);
 
 # #share the subproject Test area CRAFT
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_CRAFT\TestArea_CRAFT.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_CRAFT\TestArea_CRAFT.pj';
 MKS_command($cmd);
 
 #share the subproject Test area PROD
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_PROD\TestArea_PROD.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_PROD\TestArea_PROD.pj';
 MKS_command($cmd);
 
 #share the subproject Test area VDS
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_VDS\TestArea_VDS.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_VDS\TestArea_VDS.pj';
 MKS_command($cmd);
 
 #share the subproject Test area FaultList
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_FaultList\TestArea_FaultList.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_FaultList\TestArea_FaultList.pj';
 MKS_command($cmd);
 
 #share the subproject Test area DISP
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_DISP\TestArea_DISP.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_DISP\TestArea_DISP.pj';
 MKS_command($cmd);
 
 # share the subproject Test area AOD
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_AOD\TestArea_AOD.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_AOD\TestArea_AOD.pj';
 MKS_command($cmd);

 #share the subproject Test area SCM
 $cmd='si sharesubproject --sharedProject=G:\MKS\Projects\TurboLIFT\System\TestArea_SCM\TestArea_SCM.pj -P '."$rootfolder\\$projectname\\$projectname.pj $rootfolder\\$projectname".'\Platform\TestArea_SCM\TestArea_SCM.pj';
 MKS_command($cmd);
#
print"Test areas created - configure specfic checkpoint/Version for each of the test area created in MKS";



system('pause');

###################
### subroutines ###
###################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    print "ret < @ret >\n";
    
    return @ret;

}