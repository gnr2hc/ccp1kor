# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: Tools/ParaGen/MLCini2const.pl $
#    $Revision: 1.2 $
#    $State: develop $
#******************************************************************************************************

use strict;
use warnings;
use Data::Dumper;
use Getopt::Long;

my $MLC_file;
my (@file,$line);

GetOptions('mlc=s' => \$MLC_file );
#$MLC_file='MLC.ini';
unless ($MLC_file){
	warn "\!!! no input file given !!!\n CLI: MLCini2const.pl --mlc [file]\n\n";
	exit;
}

# parse old MLC.ini and generate MLC project const template
my ($section,$name,$value);
my $MLC_struct={};
if (open (IN, "<$MLC_file")){ 
	@file=<IN>;
	close(IN);
}
else{
	warn "\!!! input file $MLC_file not found !!!\n";
	exit;
}

foreach $line (@file){
	if ($line =~ /^\s*\[([\w_]+)\]/){$section=$1;}
	if ($line =~ /^\s*(\w+)\s*=\s*(\w+)/) {
		$name=$1;
		$value=$2;
		if ($name =~ /_Name|_CLOSED|_OPEN|_STATE_|MaxVoltage/){
			$MLC_struct->{$section}{$name}=$value;
		}
	}
}

$Data::Dumper::Indent = 1;
$Data::Dumper::Sortkeys = 1;
$Data::Dumper::Varname = "MLC";

open (OUT, ">MLC_const.txt");
	print OUT Dumper($MLC_struct);
close(OUT);
print"MLC_const.txt created\n";

# end of program

=head1 usage

create MLC ProjectConst section for TurboLIFT from MLC_HW.ini file

 CLI: MLCini2const.pl --mlc [file] 
 e.g. MLCini2const.pl --mlc MLC_HW.ini


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

