# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#    $Source: Tools/ALM_RQM_Rest_API/RQM_library.pm $
#    $Revision: 1.2 $
#    $State: develop $
#******************************************************************************************************

package RQM_library;

use strict;
use warnings;
use REST::Client;
use LWP::UserAgent;
use HTTP::Cookies;
use Crypt::RC4;
use XML::Hash::LX;
use JSON::PP;

our ( $VERSION );
$VERSION = q$Revision: 1.2 $;

$ENV{HTTPS_VERSION}                = 3;
$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;

my $client_g;
my $host_context_g;
my $projectAlias_g;

=head1 NAME

RQM_library $Revision: 1.2 $

=head1 SYNOPSIS

    use RQM_library;

    RQM_library::CreateEncryptedPwdFile('C:\TurboLIFT\messteam_PW_encrypted.txt');
    
    my $success = RQM_library::Connect('https://rb-ubk-clm-04.de.bosch.com:9443/qm', 'messteam', 'C:\TurboLIFT\messteam_PW_encrypted.txt');
    RQM_library::SetProject('ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29');
    my $testcase_href = RQM_library::GetArtifact({ type => 'testcase', id => 85 });


=head1 DESCRIPTION

Library with useful functions for access to REST API of mainly RQM but also of TurboLIFT server.

=head1 FUNCTIONS

=head2 Connect

    $success = RQM_library::Connect($host_context, $username, $encryptedPwdFilename);

Connects to REST API server $host_context and authenticates for RQM if $username and $encryptedPwdFilename is given.

B<Arguments:>

=over

=item $host_context

Base address of the REST API server. Examples:

    https://rb-ubk-clm-04.de.bosch.com:9443/qm : RQM
    http://localhost:3000                      : TurboLIFT

=item $username

(Optional) User name for authentification, required for RQM

=item $encryptedPwdFilename

(Optional) Path to a file that contains the password as encrypted string. See L</CreateEncryptedPwdFile>. Required for RQM.

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise.

=back

B<Examples:>

    $success = RQM_library::Connect('https://rb-ubk-clm-04.de.bosch.com:9443/qm', 'messteam', 'C:\TurboLIFT\messteam_PW_encrypted.txt');
    $success = RQM_library::Connect('http://localhost:3000');

=cut

sub Connect {
    my $host_context         = shift;
    my $username             = shift;
    my $encryptedPwdFilename = shift;

    print "Connecting to $host_context...\n";

    $host_context_g = $host_context;

    #IF username and password file given?
    my $response_href;
    if ( defined $username and defined $encryptedPwdFilename ) {    # RQM client
    	#IF-YES-START

        #STEP create REST client with user agent and cookies
        my $cookie_jar = HTTP::Cookies->new( file => "alm_cookies.dat", autosave => 1 );
        my $userAgent = LWP::UserAgent->new( agent => 'perl get' );
        $userAgent->cookie_jar($cookie_jar);

        $client_g = REST::Client->new( { useragent => $userAgent } );
        $client_g->setFollow(1);

        #STEP authenticate with RQM server using username and password
        my $auth = "j_username=$username&j_password=" . _GetPwd($encryptedPwdFilename);
        my $header_href = { "Content-Type" => "application/x-www-form-urlencoded; charset=utf-8" };
        $response_href = Request( 'POST', "$host_context_g/j_security_check", $auth, $header_href );
        #STEP redirect manually as long as response-code == 302
        while( $response_href->{code} == 302 ){
            my $newLocation = $response_href->{headers}{Location};
            $response_href = Request( 'POST', $newLocation, $auth, $header_href );
        }
    	#IF-YES-END
    }
    else {    # TurboLIFT client
    	#IF-NO-START
    	#STEP create simple REST client
        $client_g = REST::Client->new();
        SetServerTimeout(2);

        $response_href = Request( 'GET', "$host_context_g" );
    	#IF-NO-END
    }

    #STEP return undef last response code is not 200
    return if $response_href->{code} != 200;
    print "Connection to $host_context successful.\n";

    #STEP return 1
    return 1;
}

=head2 CreateEncryptedPwdFile

    RQM_library::CreateEncryptedPwdFile($pwdFilename);

Reads the (plain text) contents of file $pwdFilename, which should be a RQM password.
It encrypts the password and writes the encrypted password back to the file $pwdFilename, 
overwriting the plain text.

B<Arguments:>

=over

=item $pwdFilename

Path to the password file.

=back

B<Return Values:>

1

=cut

sub CreateEncryptedPwdFile {
    my $pwdFilename = shift;

    #STEP read plain text of file
    open( my $fh_in, '<', $pwdFilename )
      or die "Could not open file '$pwdFilename' $!";
    my $plaintext = <$fh_in>;
    close $fh_in;

    #STEP encrypt plain text
    my $encrypted = RC4( _GetPassPhrase(), $plaintext );

    #STEP write encrypted text to file
    open( my $fh_out, '>', $pwdFilename )
      or die "Could not open file '$pwdFilename' $!";
    print $fh_out $encrypted;
    close $fh_out;
    print "Overwritten plain text password with encrypted password in file $pwdFilename.\n";
    return 1;
}

=head2 SetProject

    RQM_library::SetProject($projectAlias);

Sets the current RQM project.

B<Arguments:>

=over

=item $projectAlias

Name of the RQM project.

=back

B<Return Values:>

1

B<Examples:>

    RQM_library::SetProject('ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29');

=cut

sub SetProject {
    $projectAlias_g = shift;
    print "Project alias set to $projectAlias_g.\n";
    return 1;
}

=head2 GetArtifact

    $response_href = RQM_library::GetArtifact($config_href);

Gets an artifact or a list of artifacts based on the given $config_href in the current RQM project 
and returns the response of the REST API including the artifact data as a sub-hash.

B<Arguments:>

    $config_href = {
        url => <artifact url>,
        type => <artifact type>,    
        id => <artifact ID in RQM>,
        linked_with => '<type>:<id>' or <url>
    };

To identify an artifact or a list of artifacts either url or type and id or type and linked_with must be given.
If type and linked_with is given then all artifacts of type <type> that are linked with the artifact specified by linked_with are fetched.
Otherwise one artifact specified by url or type and id is fetched.

B<Return Values:>

    $response_href = {
        code => <response code>,
        headers => { ... },
        content => <artifacts xml data string>,
        artifacts => {
            0 => {                # artifact #0
                'ns2:<type>' => {
                    ...             # artifact data hash
                },
            }
            1 => {},              # artifact #1
        },
    }

B<Examples:>

    $response_href = RQM_library::GetArtifact({ uri => $uri });
    $response_href = RQM_library::GetArtifact({ type => 'testcase', id => 85 });
    $response_href = RQM_library::GetArtifact({ type => 'testsuite', linked_with => 'testcase:8' } );
    $response_href = RQM_library::GetArtifact({ type => 'testsuite', linked_with => $uri } );

=cut

sub GetArtifact {
    my $config_href = shift;

    if ( not defined $projectAlias_g ) {
        print "ERROR: Project alias not defined. Please call SetProjectAlias before.\n";
        return;
    }

    my $url         = $config_href->{url};
    my $type        = $config_href->{type};
    my $id          = $config_href->{id};
    my $linked_with = $config_href->{linked_with};

    my $restURL;
    if ( defined $url ) {
        print "GetArtifact: getting artifact with url '$url'...\n";
        $restURL = $url;
    }
    elsif ( defined $type and defined $id ) {
        print "GetArtifact: getting artifact with type '$type' and id '$id'...\n";
        $restURL = _GetIdUrl( $type, $id );
    }
    elsif ( defined $type and defined $linked_with ) {
        print "GetArtifact: getting artifact with type '$type' that is linked with '$linked_with'...\n";
        $restURL = _GetFeedUrl( $type, $linked_with );
    }
    else {
        print "ERROR in GetArtifact: url not given or type and id not given or type and linked_with not given in \$config_href.\n";
        return;
    }

    my $response_href = Request( 'GET', $restURL );
    my $artifact_href = _CreateArtifactHref( $type, $response_href );

    if ( defined $artifact_href->{feed} and defined $artifact_href->{feed}{entry} and ref( $artifact_href->{feed}{entry} ) eq 'ARRAY' ) {
        print "Retrieving $type elements from feed:\n";
        my $index = 0;
        foreach my $entry_href ( @{ $artifact_href->{feed}{entry} } ) {
            my $entryUrl           = $entry_href->{id};
            my $entryResponse_href = Request( 'GET', $entryUrl );
            my $entryArtifact_href = _CreateArtifactHref( $type, $entryResponse_href );
            _PrintArtifactSummary($entryArtifact_href);
            $response_href->{artifacts}{$index} = $entryArtifact_href;
            $index++;
        }
    }
    else {
        _PrintArtifactSummary($artifact_href);
        $response_href->{artifacts}{0} = $artifact_href;
    }

    return $response_href;
}

=head2 Request

    $response_href = RQM_library::Request($method, $uri [, $body_content, $options ] );

Sends a REST API request with $method and $uri and optionally with $body_content and $options to the connected server.

B<Arguments:>

=over

=item $method

REST method, e.g. 'GET', 'POST', etc.

=item $uri

REST uri

=item $body_content

REST request body content

=item $body_content

options for REST request

=back

B<Return Values:>

    $response_href = {
        code => <response code>,
        headers => { ... },
        content => <response content>,
    }

B<Examples:>

    $response_href = RQM_library::Request( 'GET', "$host_context/clients" );
    $response_href = RQM_library::Request( 'POST', "$host_context_g/j_security_check", "j_username=$username&j_password=$password", { "Content-Type" => "application/x-www-form-urlencoded; charset=utf-8" } );

=cut

sub Request {
    my $method       = shift;
    my $uri          = shift;
    my $body_content = shift;
    my $options      = shift;

    $client_g->$method( $uri, $body_content, $options );
    my $responseCode         = $client_g->responseCode();
    my $responseContent      = $client_g->responseContent();
    my $responseHeaders_href = {};
    foreach ( $client_g->responseHeaders() ) {
        $responseHeaders_href->{$_} = $client_g->responseHeader($_);
    }

    print "Response code = $responseCode for $method $uri\n";

    my $response_href = {
        code    => $responseCode,
        content => $responseContent,
        headers => $responseHeaders_href,
    };

    return $response_href;
}

sub SetServerTimeout{
    my $timeout_s = shift;
    
    $client_g->setTimeout($timeout_s);
    
    return 1;
}

sub DecodeJSONContent{
    my $response_href = shift;

    #try to decode JSON string
    my $responseContent_JSON = $response_href->{content};
    my $decodeCommand = 'my $eval = decode_json($responseContent_JSON)';
    my $responseContent_href = eval $decodeCommand; # using eval to avoid a crash if the string is not a proper JSON string

    #return undecoded string if decoding was not successful
    unless( $responseContent_href ) {
        print "ERROR: Could not decode JSON string of response: $response_href->{content}\n";
        return;
    }

    return $responseContent_href;
}

sub EncodeHashToJSON{
    my $data_href = shift;
    
    my $jsonString = encode_json($data_href);
    
    return $jsonString;
}

=head1 Internal Functions

=head2 _GetIdUrl (internal function)

    $restURL = _GetIdUrl($type, $id );

Builds RQM ID url from $type and $id. Connect and SetProject has to be called before. 

=cut

sub _GetIdUrl {
    my $type = shift;
    my $id   = shift;

    my $integrationURL       = "$host_context_g/service/com.ibm.rqm.integration.service.IIntegrationService";
    my $singleProjectFeedUrl = "$integrationURL/resources/$projectAlias_g";
    my $artifact             = "$type/urn:com.ibm.rqm:$type:$id";
    my $restURL              = "$singleProjectFeedUrl/$artifact";

    return $restURL;
}

=head2 _GetFeedUrl (internal function)

    $restURL = _GetFeedUrl($type, $linked_with );

Builds RQM feed url from $type and $linked_with. Connect and SetProject has to be called before. 

=cut

sub _GetFeedUrl {
    my $type        = shift;
    my $linked_with = shift;

    my ( $linkedType, $linkedID );
    if ( $linked_with =~ /(\w+):(\d+)$/ ) {
        $linkedType = $1;
        $linkedID   = $2;
    }
    else {
        print "ERROR in GetArtifact: linked_with is not of form '<type>:<id>'.\n";
    }

    #$restURL example: https://rb-ubk-clm-04.de.bosch.com:9443/qm/service/com.ibm.rqm.integration.service.IIntegrationService/resources/ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29/testcase/urn:com.ibm.rqm:testcase:50
    my $integrationURL       = "$host_context_g/service/com.ibm.rqm.integration.service.IIntegrationService";
    my $singleProjectFeedUrl = "$integrationURL/resources/$projectAlias_g";
    my $resourceUrl          = "$singleProjectFeedUrl/$linkedType/urn:com.ibm.rqm:$linkedType:$linkedID";
    my $href                 = '@href';
    my $testsuiteExtra       = '';
    $testsuiteExtra = 'suiteelements/suiteelement/' if ( $type eq 'testsuite' );
    my $restURL = "$singleProjectFeedUrl/$type?fields=feed/entry/content/$type/$testsuiteExtra$linkedType" . "[$href='$resourceUrl']";

    return $restURL;
}

=head2 _PrintArtifactSummary (internal function)

    _PrintArtifactSummary($artifact_href);

Prints the summary of artifact $artifact_href. 

=cut

sub _PrintArtifactSummary {
    my $artifact_href = shift;

    my @topKeys = sort {$a <=> $b} keys %{$artifact_href};
    my $topKey  = shift @topKeys;

    my $identifierKey;
    my $titleKey;
    foreach my $secondaryKey ( keys %{ $artifact_href->{$topKey} } ) {
        $identifierKey = $secondaryKey if $secondaryKey =~ /:identifier/;
        $titleKey = $secondaryKey if $secondaryKey =~ /:title/;
    }

    my ( $type, $id );
    my $identifier = $artifact_href->{$topKey}{$identifierKey} // '';
    if ( $identifier =~ /(\w+):(\d+)$/ ) {
        $type = $1;
        $id   = $2;
    }
    elsif( $identifier =~ /(datapool)\/(\w+)$/ ){
        $type = $1;
        $id   = $2;
    }
    else {
        $type = 'unknown artifact';
        $id   = 'unknown id';
    }

    my $title = $artifact_href->{$topKey}{$titleKey} // 'unknown title';
    print "$type with id $id has the title '$title'\n";
    return 1;
}

sub _GetPwd {
    my $pwdFilename = shift;

    open( my $fh, '<', $pwdFilename )
      or die "Could not open file '$pwdFilename' $!";
    my $encrypted = <$fh>;
    close $fh;
    return RC4( _GetPassPhrase(), $encrypted );
}

sub _GetPassPhrase {
    my $passphrase = '>.%=+,R5%0#,B0W$Q0TP_=T@B+6TA?CUI14T];4-)';
    return unpack( chr( ord("a") + 19 + print "" ), $passphrase );
}

=head2 _CreateArtifactHref (internal function)

    $artifact_href = _CreateArtifactHref($type, $response_href);

Creates the RQM artifact data hash structure from given $type and $response_href.
Supported response content types are: xml (e.g. testcase, testsuite) and excel () 

=cut

sub _CreateArtifactHref {
    my $type          = shift;
    my $response_href = shift;

    my $responseCode    = $response_href->{code};
    my $responseContent = $response_href->{content};
    if ( $responseCode != 200 ) {
        print "ERROR: Response code $responseCode received. Full response is: $responseContent\n";
        return;
    }
    my $contentType = $response_href->{headers}{'Content-Type'};

    my $filename = 'last_artifact.txt';
    open( my $out_fh, '>', $filename ) or die "Could not open file '$filename' $!";
    print $out_fh $responseContent;
    close $out_fh;

    my $artifact_href;
    if ( $contentType =~ /xml/ ) {
        $artifact_href = xml2hash $responseContent;
    }
    elsif ( $contentType =~ /excel/ ) {
        $artifact_href = _Csv2href( $type, $responseContent );
    }
    else {
        print "ERROR: content type $contentType is not supported.\n";
    }
    return $artifact_href;
}

=head2 _Csv2href (internal function)

    $artifact_href = _Csv2href($type, $responseContent);

Creates the RQM artifact data hash structure from csv data string.
Separator character is ';'. 

=cut

sub _Csv2href {
    my $type            = shift;
    my $responseContent = shift;

    my $artifact_href;
    my @lines = split /\n/, $responseContent;
    my $headerline = shift @lines;
    chop $headerline;
    my @variables = split /;/, $headerline;
    foreach my $rowIndex ( 0 .. @lines - 1 ) {
        my $line = $lines[$rowIndex];
        chop $line;
        my @data = split /;/, $line;
        foreach my $columnIndex ( 0 .. @data - 1 ) {
            my $variable = $variables[$columnIndex];
            $artifact_href->{$rowIndex}{$variable} = $data[$columnIndex];
        }

    }
    return $artifact_href;
}

1;
