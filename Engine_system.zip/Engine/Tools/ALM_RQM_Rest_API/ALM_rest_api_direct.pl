use strict;
use warnings;
use RQM_library;

#RQM_library::CreateEncryptedPwdFile('U:\ALM\pwd.txt');
#die;

my $success = RQM_library::Connect('https://rb-ubk-clm-04.de.bosch.com:9443/qm', 'phc2si', 'U:\ALM\pwd.txt');

RQM_library::SetProject('ProjectPlay_RM+%28Qualit%C3%A4tsmanagement%29');
my $testcase_href = RQM_library::GetArtifact({type => 'testcase', id => 62});
my $testscriptUrl = $testcase_href->{artifacts}{0}{'ns2:testcase'}{'ns2:testscript'}{'-href'};
my $testscript_href = RQM_library::GetArtifact({url => $testscriptUrl});
my $datapoolUrl = $testscript_href->{artifacts}{0}{'ns2:testscript'}{'ns2:datapool'}{'-href'};
my $datapool_href = RQM_library::GetArtifact({url => $datapoolUrl});
my $attachmentUrl = $datapool_href->{artifacts}{0}{'ns2:datapool'}{'ns2:attachment'}{'-href'};
my $attachment_href = RQM_library::GetArtifact({url => $attachmentUrl});
my $rqmParams_href = $attachment_href->{artifacts}{0};

1;