use strict;
use warnings;
use IO::Tee;
use RQM_library;

our ( $VERSION );
$VERSION = q$Revision: 1.2 $;

#COMMENT-START
# Script that is started by RQM_TurboLIFT_start_server.bat which is in turn started by RQM command line adapter.
# Gets TurboLIFT testcase IDs, sends them to TurboLIFT REST server, triggers test execution of those testcase IDs
# and sends back to RQM the verdict and the path to the test report. 
#COMMENT-END

my $tuliServer = 'http://localhost:3000';
my $shutdown;

open my $log, '>', "RQM_TurboLIFT_executor.log" or die "Can't write logfile: $!";
my $tee = new IO::Tee(\*STDOUT, $log);

my $datestring = localtime();
print $tee "RQM TurboLIFT executor $VERSION started $datestring\n";

#CALL Check_Environment_Variables
Check_Environment_Variables() or die "Not all required environment variables are defined";

#CALL Get_TurboLIFT_Testcase_IDs
my $testcaseIDs_href = Get_TurboLIFT_Testcase_IDs() if not $shutdown;

#CALL Register_With_TurboLIFT_Server
my $clientName = $ENV{'qm_RQM_TESTCASE_EXECUTIONRECORD_WEBID'}.'_'.$datestring;
$clientName =~ s/\s/_/g;
Register_With_TurboLIFT_Server() or die "Could not register on TurboLIFT server";

#IF qm_TurboLIFT_Testcase_IDs is 'TurboLIFT_Server_Shutdown'?
if( $shutdown ) {
	#IF-YES-START
	#STEP Send shutdown request to server
    print $tee "Shutting down TurboLIFT server...\n";
    RQM_library::Request( 'POST', "$tuliServer/shutdown" );
	#STEP Write verdict PASS
    Write_Verdict('VERDICT_PASS');
    #END exit
    exit;
	#IF-YES-END
	#IF-NO-START
	#IF-NO-END    
}

#CALL Add_Testcases_To_Server
Add_Testcases_To_Server($testcaseIDs_href) or die "Could not add testcases to server";

#CALL Execute_Testlist
Execute_Testlist() or die "Error in test execution";

#CALL Create_Execution_Report
my $reportID = Create_Execution_Report() or die "Error in report creation";

#CALL Write_Report_And_Verdict
Write_Report_And_Verdict($reportID) or die "Could not write report and verdict";

#STEP Unregister from server
my $response_href = RQM_library::Request( 'DELETE', "$tuliServer/clients?name=$clientName" );
Check_Response($response_href) or die "Could not unregister from server";

#END end
exit;




=head2 Check_Environment_Variables

    $success = Check_Environment_Variables();

Checks if all required environment variables from RQM are defined.

Sets shutdown flag if qm_TurboLIFT_Testcase_IDs = 'turbolift_server_shutdown'.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Check_Environment_Variables{
    my @envVariables = qw(qm_RQM_PROJECT_ALIAS qm_RQM_TESTCASE_NAME qm_RQM_TESTCASE_WEBID qm_RQM_TESTCASE_EXECUTIONRECORD_WEBID);
    
    #LOOP-START loop over all required environment variables 
    foreach my $envVariable ( @envVariables ) {
        #STEP throw error and return if environment variable is not defined
        if( not defined $ENV{$envVariable} ) {
            my $text = "ERROR: Environment variable $envVariable is not defined\n";
            print $tee $text;
            print STDERR $text;
            return;
        }
        else{
            print $tee "Environment variable $envVariable = ".$ENV{$envVariable}."\n";
        }
    }
    #LOOP-END last environment variable?
    
    @envVariables = qw(qm_TurboLIFT_Testcase_IDs);
    
    #LOOP-START loop over all optional environment variables 
    foreach my $envVariable ( @envVariables ) {
        #STEP print value of environment variable
        my $value = $ENV{$envVariable} // '<not defined>';
        print $tee "Environment variable $envVariable = ".$ENV{$envVariable}."\n";
    }
    #LOOP-END last environment variable?

    #STEP set shutdown flag if qm_TurboLIFT_Testcase_IDs = 'turbolift_server_shutdown'
    my $tuli_Testcase_IDs = lc( $ENV{'qm_TurboLIFT_Testcase_IDs'} );
    $shutdown = $tuli_Testcase_IDs eq 'turbolift_server_shutdown';

    return 1;
}

=head2 Get_TurboLIFT_Testcase_IDs

    $testcaseIDs_href = Get_TurboLIFT_Testcase_IDs();

Retrieves the TurboLIFT testcase IDs and test parameter from either environment variable 'qm_TurboLIFT_Testcase_IDs'
(which is an execution variable in the RQM test case) or from environment variable 'qm_RQM_TESTCASE_NAME'
(which is the RQM test case name).

Test parameters are taken from RQM test data in a manual test script that is linked to the RQM test case
(if such test data exist)  

B<Return Values:>

    $testcaseIDs_href = {
        1 => {
            testcaseID => <TurboLIFT testcaseID 1>,
        },
        2 => {
            testcaseID => <TurboLIFT testcaseID 2>,
            parameter => {
                TC_PARAMETER => {<parameter data>},
            },
        },
        ...
    }

=cut

sub Get_TurboLIFT_Testcase_IDs{
    #STEP get list of TurboLIFT testcaseIDs from env-variable 'qm_TurboLIFT_Testcase_IDs' (space separated)
    my $tuliTestcaseIDs = $ENV{'qm_TurboLIFT_Testcase_IDs'};
    my @testcaseIDs = split(/\s/, $tuliTestcaseIDs);
    
    #IF list of TurboLIFT testcaseIDs has more than 1 entry or it has one entry and the entry is a fully qualified testcaseID (contains a '.')?
    my $testcaseIDs_href;
    if( @testcaseIDs > 1 or ( @testcaseIDs == 1 and $testcaseIDs[0] =~ /(\w+)\.(\w+)/ ) ) {
    	#IF-YES-START
        print $tee "TurboLIFT testcase IDs = @testcaseIDs\n";
        #STEP add testcaseIDs to $testcaseIDs_href
        foreach my $index ( 0 .. @testcaseIDs-1 ) {
            $testcaseIDs_href->{$index+1}{testcaseID} = $testcaseIDs[$index];
        }
        #END return $testcaseIDs_href
        return $testcaseIDs_href;
    	#IF-YES-END
    }
    	#IF-NO-START
    	#IF-NO-END

    #IF env-variable 'qm_TurboLIFT_Testcase_IDs' is defined?
    my $testcaseName;
    if( defined $tuliTestcaseIDs ) {
    	#IF-YES-START
    	#STEP take this env-variable as $testcaseName
        $testcaseName = $tuliTestcaseIDs;
    	#IF-YES-END
    }
    else{
    	#IF-NO-START
    	#STEP take env-variable 'qm_RQM_TESTCASE_NAME' as $testcaseName
        $testcaseName = $ENV{'qm_RQM_TESTCASE_NAME'};
    	#IF-NO-END
    }

    #CALL Get_Parameter_From_RQM
    $testcaseIDs_href = Get_Parameter_From_RQM($testcaseName);
    
    #STEP add $testcaseName as single entry in $testcaseIDs_href if no parameters were found
    if( not defined $testcaseIDs_href ) {
        $testcaseIDs_href->{1}{testcaseID} = $testcaseName;
    }

    #END return $testcaseIDs_href
    return $testcaseIDs_href;
}

=head2 Register_With_TurboLIFT_Server

    $success = Register_With_TurboLIFT_Server();

Checks if all required environment variables from RQM are defined.

Sets shutdown flag if qm_TurboLIFT_Testcase_IDs = 'turbolift_server_shutdown'.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Register_With_TurboLIFT_Server{
    my $success;

    # wait until the server is up
    my $maxTrials = 12;
    my $trials = 0;
    #STEP tries max. 12 times to connect to TurboLIFT server
    while( not $success ){
        $trials++;
        print $tee "Trying to connect to TurboLIFT server #".$trials."...\n";
        $success = RQM_library::Connect($tuliServer);
        last if $trials > $maxTrials;
    }

    #STEP throw error and return if no success
    if( not $success ) {
        my $text = "ERROR: Timeout while trying to connect to TurboLIFT server.\n";
        print $tee $text;
        print STDERR $text;
        return;
    }
    
    #STEP register client on server
    print $tee "Registering on TurboLIFT server with name = '$clientName'...\n";
    my $response_href = RQM_library::Request( 'POST', "$tuliServer/clients?name=$clientName" );
    
    #STEP throw error and return if no positive response
    if( $response_href->{code} != 200 ) {
        my $text = "ERROR: Could not register on TurboLIFT server: $response_href->{content}\n";
        print $tee $text;
        print STDERR $text;
        return;
    }
    
    #END return 1
    print $tee "Registration on TurboLIFT server successful.\n";
    return 1;
}

=head2 Add_Testcases_To_Server

    $success = Add_Testcases_To_Server( $testcaseIDs_href );

Adds all test cases in $testcaseIDs_href to server test list.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Add_Testcases_To_Server{
    my $testcaseIDs_href = shift;
    
    print $tee "Adding TurboLIFT testcaseIDs to server list...\n";

    #STEP delete existing test list on server
    my $response_href = RQM_library::Request( 'DELETE', "$tuliServer/testcases" );
    Check_Response($response_href) or return;
    
    #LOOP-START loop over test case IDs in $testcaseIDs_href
    foreach my $listID ( sort {$a <=> $b} keys %$testcaseIDs_href ) {
        my $testcaseID = $testcaseIDs_href->{$listID}{testcaseID};
        my $parameter_href = $testcaseIDs_href->{$listID}{parameter};
        #IF current test case has parameters?
        if( defined $parameter_href ) {
        	#IF-YES-START
            #STEP add TurboLIFT testcase ID with parameters to server test list
            print $tee "    Adding '$testcaseID' with parameters...\n";
            my $jsonString = RQM_library::EncodeHashToJSON( $parameter_href );
            $response_href = RQM_library::Request( 'PUT', "$tuliServer/testcases/$listID?name=$testcaseID", $jsonString );
            Check_Response($response_href) or return;
        	#IF-YES-END
        }
        else{
        	#IF-NO-START
            #STEP add only TurboLIFT testcase ID to server test list
            print $tee "    Adding '$testcaseID'...\n";
            $response_href = RQM_library::Request( 'PUT', "$tuliServer/testcases/$listID?name=$testcaseID" );
            Check_Response($response_href) or return;
        	#IF-NO-END
        }
    }
    #LOOP-END last test case ID?
    
    #END return 1
    return 1;
}

sub Check_Response{
    my $response_href = shift;
    
    if( $response_href->{code} != 200 ) {
        my $text = "ERROR: Negative reponse to last request: $response_href->{content}\n";
        print $tee $text;
        print STDERR $text;
        return;
    }
    
    return 1;
}

=head2 Execute_Testlist

    $success = Execute_Testlist();

Sends command to server to execute the current test list.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Execute_Testlist{
    #STEP get list of last execution IDs
    my $response_href = RQM_library::Request( 'GET', "$tuliServer/executions" );

    #STEP create new execution ID
    my $responseContent_aref = RQM_library::DecodeJSONContent($response_href);
    return if not defined $responseContent_aref;
    my $executionID = @$responseContent_aref +1;
    
    #STEP send execution command with new execution ID
    $response_href = RQM_library::Request( 'PUT', "$tuliServer/executions/$executionID" );
    Check_Response($response_href) or return;
    
    return 1;
}

=head2 Create_Execution_Report

    $reportID = Create_Execution_Report();

Sends command to server to create a report for the last execution.

B<Return Values:>

$reportID: report ID of the creted report

=cut

sub Create_Execution_Report{
    #STEP get list of last report IDs
    my $response_href = RQM_library::Request( 'GET', "$tuliServer/reports" );

    #STEP create new report ID
    my $responseContent_aref = RQM_library::DecodeJSONContent($response_href);
    return if not defined $responseContent_aref;
    my $reportID = @$responseContent_aref +1;
    
    #STEP send command for report creation with new execution ID
    $response_href = RQM_library::Request( 'PUT', "$tuliServer/reports/$reportID" );
    Check_Response($response_href) or return;
    
    return $reportID;
}

=head2 Write_Report_And_Verdict

    $reportID = Write_Report_And_Verdict( $reportID );

Writes report path to file reportPath.txt and report verdict code to file verdictCode.txt.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Write_Report_And_Verdict{
    my $reportID = shift;
    
    #STEP get report data for report ID $reportID from server
    my $response_href = RQM_library::Request( 'GET', "$tuliServer/reports/$reportID" );
    Check_Response($response_href) or return;
    
    my $responseContent_href = RQM_library::DecodeJSONContent($response_href);
    return if not defined $responseContent_href;

    #STEP create URL for report path
    my $report_html = $responseContent_href->{report_html};
    $report_html =~ s/\\/\//g;
    $report_html = 'file:///'.$report_html;
    print $tee "Test report is stored in the following path: '$report_html'\n";

    #STEP get report verdict
    my $report_verdict = $responseContent_href->{report_verdict};
    print $tee "Consolidated verdict is: '$report_verdict'\n";
    
    #STEP write report path to file reportPath.txt
    my $filename = "reportPath.txt";
    print $tee "Writing report path to file '$filename'...\n";
    open my $report_fh, '>', $filename or die "Can't write file '$filename': $!";
    print $report_fh $report_html;
    close $report_fh;

    #CALL Write_Verdict
    Write_Verdict($report_verdict);

    return 1;
}

=head2 Write_Verdict

    $reportID = Write_Verdict( $verdict );

Writes report verdict code to file verdictCode.txt.

B<Return Values:>

1 on success, undef otherwise

=cut

sub Write_Verdict{
    my $verdict = shift;

    #STEP get (RQM) verdict code from verdict
    my $verdictMapping_href = {
        VERDICT_PASS => 0,
        VERDICT_FAIL => 1,
        VERDICT_INCONC => 42,
        VERDICT_NONE => 41,
    };
    my $verdictCode = $verdictMapping_href->{$verdict};

    #STEP write verdict code to file verdictCode.txt
    my $filename = "verdictCode.txt";
    print $tee "Writing verdict code ($verdictCode) to file '$filename'...\n";
    open my $verdict_fh, '>', $filename or die "Can't write file '$filename': $!";
    print $verdict_fh $verdictCode;
    close $verdict_fh;
    
    return 1;
}

=head2 Get_Parameter_From_RQM

    $testcaseIDs_href = Get_Parameter_From_RQM( $testcaseName );

Connect to RQM REST server and get test data from the test script that is linked to the current RQM test case.
TurboLIFT testcaseID and parameter data are added to $testcaseIDs_href  for each row of test data.
If no test data exist then undef is returned.

B<Return Values:>

    $testcaseIDs_href = {
        1 => {
            testcaseID => <TurboLIFT testcaseID 1>,
            parameter => {
                TC_PARAMETER => {<parameter data>},
            },
        },
        2 => {
            testcaseID => <TurboLIFT testcaseID 2>,
            parameter => {
                TC_PARAMETER => {<parameter data>},
            },
        },
        ...
    }

=cut

sub Get_Parameter_From_RQM{
    my $testcaseName = shift;

    #STEP return if test case name contains a . (fully qualified TurboLIFT testcase ID)
    return if $testcaseName =~ /(\w+)\.(\w+)/;

    my $host_context = 'https://rb-ubk-clm-04.de.bosch.com:9443/qm';
    
    #STEP get user name and path to password file from file RQM_user.txt
    my $userFile = 'RQM_user.txt';
    open( my $userFile_fh, '<', $userFile ) or die "Error reading file $userFile: $!\n";
    my @userFileLines = <$userFile_fh>;
    close $userFile_fh;

    my $username = shift @userFileLines;
    chomp $username;
    
    my $encryptedPwdFilename = shift @userFileLines;
    chomp $encryptedPwdFilename;
    
    #STEP connect and login to RQM REST server
    RQM_library::Connect($host_context, $username, $encryptedPwdFilename) or die "Error on Login to RQM";

    my $rqm_project_alias = $ENV{'qm_RQM_PROJECT_ALIAS'};
    RQM_library::SetProject($rqm_project_alias);

    #STEP get RQM test case data using env variable qm_RQM_TESTCASE_WEBID
    my $rqm_testcase_webid = $ENV{'qm_RQM_TESTCASE_WEBID'};
    my $testcase_href = RQM_library::GetArtifact({type => 'testcase', id => $rqm_testcase_webid});
    my $testscriptUrl = $testcase_href->{artifacts}{0}{'ns2:testcase'}{'ns2:testscript'}{'-href'};

    #STEP return if no test script URL is defined
    return if not defined $testscriptUrl;
    
    #STEP get RQM datapool URL from test script 
    my $testscript_href = RQM_library::GetArtifact({url => $testscriptUrl});
    my $datapoolUrl = $testscript_href->{artifacts}{0}{'ns2:testscript'}{'ns2:datapool'}{'-href'};

    #STEP return if no datapool URL is defined
    return if not defined $datapoolUrl;

    #STEP get RQM attachment URL from datapool 
    my $datapool_href = RQM_library::GetArtifact({url => $datapoolUrl});
    my $attachmentUrl = $datapool_href->{artifacts}{0}{'ns2:datapool'}{'ns2:attachment'}{'-href'};

    #STEP return if no attachment URL is defined
    return if not defined $attachmentUrl;
    
    #STEP get attachment data
    my $attachment_href = RQM_library::GetArtifact({url => $attachmentUrl});
    
    my $rqmParams_href = $attachment_href->{artifacts}{0};
    return if ref($rqmParams_href) ne 'HASH';
    
    #LOOP-START loop over all lines (index) in attachment 
    my $testcaseIDs_href;
    foreach my $paraSetIndex ( sort {$a <=> $b} keys %{ $rqmParams_href } ) {
        my ($paraSetName, $paraSetData_href);
        #STEP get name of parameter set from test data column 'par_set_name'
        foreach my $paraName ( sort keys %{ $rqmParams_href->{$paraSetIndex} } ) {
            if( lc($paraName) eq 'par_set_name' ) {
                $paraSetName = $rqmParams_href->{$paraSetIndex}{$paraName};
            }
            else{
        #STEP get names of parameters from other test data columns
                $paraSetData_href->{$paraName} = $rqmParams_href->{$paraSetIndex}{$paraName};
            }
        }
        #STEP return with error if column 'par_set_name' is not found in attachment
        if( not defined $paraSetName ) {
            my $text = "ERROR: column 'par_set_name' not found in test data\n";
            print $tee $text;
            print STDERR $text;
            return;
        }
        #CALL Convert_Parameter_To_Tuli
        my $paraSetDataTuli_href = Convert_Parameter_To_Tuli($paraSetData_href);
        if( not defined $paraSetDataTuli_href ) {
            my $text = "ERROR: test data not in TurboLIFT format\n";
            print $tee $text;
            print STDERR $text;
            return;
        }

        #STEP add TurboLIFT test case ID (testcase_name.parameter_set_name) to $testcaseIDs_href->{index+1}
        $testcaseIDs_href->{$paraSetIndex+1}{testcaseID} = $testcaseName.'.'.$paraSetName;

        #STEP add parameter data to $testcaseIDs_href->{index+1}
        $testcaseIDs_href->{$paraSetIndex+1}{parameter}{TC_PARAMETER} = $paraSetDataTuli_href;
        
    }
    #LOOP-END last line?
        
    #END return $testcaseIDs_href
    return $testcaseIDs_href;
}

=head2 Convert_Parameter_To_Tuli

    $paraSetDataTuli_href = Convert_Parameter_To_Tuli( $paraSetData_href );

Converts the parameter values of RQM parameter set ($paraSetData_href) into TurboLIFT parameter format.

B<Return Values:>

 $paraSetDataTuli_href = {
     <parameter name 1> => <scalar>,
     <parameter name 2> => [list],
     <parameter name 3> => {hash},
     ...
 }

=cut

sub Convert_Parameter_To_Tuli{
    my $paraSetData_href = shift;
    
    #LOOP-START loop over all parameters in $paraSetData_href
    my $paraSetDataTuli_href;
    foreach my $paraName ( sort keys %{ $paraSetData_href } ) {
        my $paraValue = $paraSetData_href->{$paraName};
        #STEP add a list reference if the parameter value is @(...)
        if( $paraValue =~ /
                            \s*   # possible whitespace
                            \@    # @
                            \s*   # possible whitespace
                            \(    # (
                            (.*)  # anything -> $1
                            \)    # )
                            \s*   # possible whitespace
                            $     # end of string
                          /x
                          ){
            my $listString = $1;
            my @listValues = split(/,/, $listString);
            my @goodValues;
            foreach my $element ( @listValues ) {
                push(@goodValues, TrimElement($element) );
            }
            $paraSetDataTuli_href->{$paraName}{LIST} = \@goodValues;
        }
        #STEP add a hash reference if the parameter value is %(...)
        elsif( $paraValue =~ /
                            \s*   # possible whitespace
                            \%    # %
                            \s*   # possible whitespace
                            \(    # (
                            (.*)  # anything -> $1
                            \)    # )
                            \s*   # possible whitespace
                            $     # end of string
                          /x
                          ){
            my $hashString = $1;
            my @hashPairs = split(/,/, $hashString);
            foreach my $pairString ( @hashPairs ) {
                my @pairElements = split(/=>/, $pairString);
                if( @pairElements != 2 ) {
                    my $text = "ERROR: wrongly formatted hash pair '$pairString' in test data\n";
                    print $tee $text;
                    print STDERR $text;
                    return;
                }
                my $key = $pairElements[0];
                $key = TrimElement($key);
                my $value = $pairElements[1];
                $value = TrimElement($value);
                $paraSetDataTuli_href->{$paraName}{HASH}{$key} = $value;
            }
        }
        #STEP add a scalar if the parameter value is something else
        else{
            $paraValue = TrimElement($paraValue);
            $paraSetDataTuli_href->{$paraName}{SCALAR} = $paraValue;
        }
    }
    #LOOP-END last parameter set?
    
    #END return $paraSetDataTuli_href
    return $paraSetDataTuli_href;
}

sub TrimElement{
    my $string = shift;
    
    $string =~ s/^\s+|\s+$//g;  # remove leading and trailing blanks
    $string =~ s/^"|"$//g;  # remove enclosing "
    $string =~ s/^'|'$//g;  # remove enclosing '
    
    return $string;
}

1;
