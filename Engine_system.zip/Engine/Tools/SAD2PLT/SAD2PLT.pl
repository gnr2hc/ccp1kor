#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "SAD2PLT ($VERSION)";      # Tool version number

my %fault_table;

my ($scan_file, $out_file);
my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "create uniview config out of SAD file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "create PLT",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.sad'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.sad)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        scan_file_content($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if scan_file is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">SAD2PLT_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('par=s' => \$scan_file );
if ($scan_file){ # source file
    w2log("running with CLI\n");
    scan_file_content($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++





###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub scan_file_content
{
    my (@in_file, $line, $key);
    my $scan_file = shift;
    my ($ID,@vars,@enums,@bits,$list,$count);

    w2log("\nscanning file: <$scan_file>\n\n");

    $out_file = $scan_file;
    # replace e.g. C:\myhome\myfile.sad with C:\myhome\myfile
    $out_file =~ s/\.\w+$//; # cut off file extension

    # replace e.g. C:\myhome\myfile with C:\myhome\myfile.plt
    $out_file .= '.plt'; # extend filename

    # read file to array

    open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";
    open ( IN,"<$scan_file" ) or die "Couldn't open $_ : $@";
    my @bitcolour=(2,3,4,5,10,11,12,13);
    my $enumcolour=9;
    my $fltcolour=11;
    my @FLTstates= qw( filtered latched stored current active disturb bit_6 bit_7 );

    # skip header
    while ($line=<IN>){
        last if ($line =~ /END OF HEADER/);
    }

    while($line = <IN>){ 
        #scan for e.g. 
        #V_ITMTestExecutedStatus_U32R,03FF82FC, 0 Test executed status,E_ITMIniEnd,E_ITMMicroControllerInitialized,E_ITMSpiCrossCouplingTest,E_ITMAmuTest,E_ITMAmuInputTest,E_ITMSafetyIdThreshldProgr,E_ITMEnergyReserveTest,E_ITMWatchdogServiced1Sec,
        #E_ITMStateMachine2_XXR,03FF82EF,State machine 2,,,,,,,,,Start ENFL Aout short detection test,Perform initial VSW test,Start AMU tests,Disposal condition check,Start energy reserve test,Start switch monitoring,Start PAS test,Start sensor data acquisition,Start Disposal operation,Wait for the algo to be ready.,End of state machine 2,
        #F_IFSCrcLine_U32R.1,03FF921D, 1 CRC per line,,,,,,,,,
        if ($line =~ /^([^,]+),[^,]*,[^,]*,(.+)$/){
            $ID = $1;
            $list=$2;
            push(@vars,$ID);
            if ($ID =~ /^E_/ ){
                $list =~ s/^,+//; # drop all leading commas
                @enums=split(/,/,$list);
                #check if enum is not empty
                if (scalar(@enums)>0){
                    #for loop to replace blank with underscore
                    for ($count=0;$count<scalar(@enums);$count++){
                        $enums[$count]=~ s/ /_/g;
                    #store ID and enum array in hash for better sorting?
                        print OUT "$ID bit $enumcolour key=$enums[$count] unit= scansc EXP=EQ(x,$count)\n";

                    }
                }
                #else enum is empty
            }
            elsif ($ID =~ /^V_/ ){
                @bits=split(/,/,$list);
                #check if bits is not empty
                if (scalar(@bits)>0){
                    #for loop to replace blank with underscore
                    for ($count=0;$count<scalar(@bits);$count++){
                        $bits[$count]=~ s/ /_/g;
                    #store ID and bit array in hash for better sorting?
                        print OUT "$ID:$count:1 bit $bitcolour[$count] key=$bits[$count] unit= scansc\n";
                    }
                }
                #else bits is empty

            }

            if ($ID =~ /FltMemState/i ){
                for ($count=0;$count<scalar(@FLTstates);$count++){
                #store ID and bit array in hash for better sorting?
                    print OUT "$ID:$count:1 bit $fltcolour key=$ID$FLTstates[$count] unit= scansc\n";
                }
            }        

        }

    }

    my $color = 16;
    foreach $ID (@vars){
        print OUT "$ID nobit $color unit= scansc fmt=g\n";
        $color++;
        $color = 16 if ($color > 31);
    }

    close (IN);
    close (OUT);


    w2log("\ncreated file: <$out_file>\n\n");

    print"... done\n\n";
    $display_txt = "file <$scan_file> created";
}
# END sub scan_faults


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

create uniview PLT file from SAD file, to be used for production diagnosis traces

expands enums (E_*) and bitfields (V_*) and faultbits (FltMemState) other things to be added

 CLI: SAD2PLT.pl --par [file]
 e.g. SAD2PLT.pl --par C:/myproject/somefile.sad

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
