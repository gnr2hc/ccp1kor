#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "SAD_cleaner ($VERSION)";      # Tool version number
my $SADfile;

#clean_SAD('AB1202_BB00000_Z05_Cat2_20120702.sad');

my ( $main, $ValueFrame, $ButtonFrame, $ValueEntry, $display_txt);


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "clean SAD file $VERSION" );

# create label in window 'main'
$main -> Label( "-text" => "clean SAD",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$SADfile,
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $SADfile = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["par files", '.sad'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to clean (*.sad)",
                        );
                      # if a file was chosen
                      if ( $SADfile )
                        {
                        #extract directory
                        print "\n $SADfile was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CLEAN",
  "-command" => sub
    { # execute when button is pressed  
        if ($SADfile) { # create project if SADfile was given
        clean_SAD($SADfile);
        $SADfile = ""; # set SADfile to undefined

        }
        else{
        # prompt user if SADfile is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 50);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );



#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">SAD_cleaner_log.txt" ) or die "Couldn't open logfile : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('sad=s' =>\$SADfile);
if ($SADfile){ # source file
    w2log("running with CLI\n");
    clean_SAD($SADfile);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++




sub clean_SAD{
	my $file =shift;
	my ($line);
	print "$file\n";
	open (IN,'<',"$file") or die "can't open file";
	open (OUT,'>',"$file.clean") or die "can't open file";
	w2log("\ncleaning $file\n\n");
	$display_txt="cleaning $file";
	$main->update();
	
	#skip header
	while ($line = <IN>){
		print OUT $line;
		last if $line =~ m/END OF HEADER/;
	}
	
	while ($line = <IN>){#
		chomp($line);
		last if $line =~ m/^EOF/;
	
		my @elem = split(/,/,$line);
		my $name = $elem[0];
		my $size = length($name); 
		if ($size < 2){
			w2log("!!! $name too short (size < 2)\n\n");
			next;
		}
		if ($size > 70){
			w2log("!!! $name too long (size > 70)\n\n");
			next;
		}
		my $commas=scalar(@elem);

#rb_psem_RomCfgFirstLineOnAsic_caen(0),0000C9C4,,,,,,,,,,System ASIC 1 Line 1,System ASIC 1 Line 2,System ASIC 1 Line 3,System ASIC 1 Line 4,System ASIC 1 Line 5,System ASIC 1 Line 6,System ASIC 2 Line 1,System ASIC 2 Line 2,System ASIC 2 Line 3,System ASIC 2 Line 4,System ASIC 2 Line 5,System ASIC 2 Line 6,Maximum sensor line,Sensor is not connected to any line,
#V_RoseFireFlags_U16R.1,FEDECB01,RoseFireFlags,Plausibility for RoSe,RoSe pre-fire flag,RoSe soil trip was first event flag (everlasting),RoSe soil trip was first event flag (resetable),,,
		if ($line !~ m/^([^,]+),([^,]+),([^,]*),,,,,,,,,/ and $commas > 11){
			w2log("!!! wrong line: <$line>\n\n");
			next;
		}
		
		# print line if checks were ok
		print OUT $line."\n";

	}

	print OUT "EOF\n";
	close (IN);
	$display_txt="$file cleaned";


}

sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}



=head1 usage

clean SAD file from too short(<2), too long(>70) variables and variables with faulty (bit AND enum) description.

 CLI: SAD_cleaner.pl --sad [file]
 
 e.g. SAD_cleaner.pl --sad=BB62866.SAD
      
a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

