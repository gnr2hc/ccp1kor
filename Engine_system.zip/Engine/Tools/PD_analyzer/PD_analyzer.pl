#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "PD_analyzer ($VERSION)";      # Tool version number

my %sadTBL;

my ($scan_file, $out_file,$ABgen);
my ( $main, $ValueFrame,$ValueFrame2,$ValueFrame3,$ValueFrame4, $ButtonFrame, $ValueEntry, $display_txt);
my $SADfile;
my $IDecu;
my $IDpd;

$ABgen= 'AB12';
################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "decode PD in CANoe trace file $VERSION" );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );
# create frame 'ValueFrame' in window 'main'
$ValueFrame2 = $main -> Frame() -> pack( "-pady" => 5 );
$ValueFrame3 = $main -> Frame() -> pack( "-pady" => 5 );
$ValueFrame4 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "asc file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["ASC files", '.asc'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.asc)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create label in window 'ValueWindow'
$ValueFrame2 -> Label( "-text" => "SAD file: (opt) ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
 $ValueFrame2 -> Entry(
            "-width" => 50,
            "-textvariable" => \$SADfile, #reference to $prj_id
            )-> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame2 -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $SADfile = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["SAD files", '.sad'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.sad)",
                        );
                      # if a file was chosen
                      if ( $SADfile )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);



# create label in window 'ValueWindow'
$ValueFrame3 -> Label( "-text" => "ECU ID: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
 $ValueFrame3 -> Entry(
            "-width" => 30,
            "-textvariable" => \$IDecu, #reference to $prj_id
            )-> pack( "-side" => 'left', );

# create label in window 'ValueWindow'
$ValueFrame3 -> Label( "-text" => "PD ID: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
 $ValueFrame3 -> Entry(
            "-width" => 30,
            "-textvariable" => \$IDpd, #reference to $prj_id
            )-> pack( "-side" => 'left', );

$ValueFrame4 -> Label( "-text" => "decode for ", )
            -> pack( "-side" => 'left', );
$ValueFrame4 -> Radiobutton  (
            "-text"     => "AB10",
            "-value"    => 'AB10',
            "-variable" => \$ABgen,
            "-command"  => sub    {
            }  ) -> pack  (  "-side" => 'left',  );
       
$ValueFrame4 -> Radiobutton  (
            "-text"     => "AB12",
            "-value"    => 'AB12',
            "-variable" => \$ABgen,
            "-command"  => sub    {
            }  ) -> pack  (  "-side" => 'left',  );


# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "decode",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        scan_asc($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if project_id is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">PD_analyzer_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('asc=s' => \$scan_file , 'sad=s' =>\$SADfile, 'pdID=s' =>\$IDpd, 'ecuID=s' =>\$IDecu);
if ($scan_file and $SADfile and $IDpd and $IDecu){ # source file
    w2log("running with CLI\n");
    scan_asc($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++








###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub scan_asc
{
  my ($line,$oldID,@bytes,$ID,$DATA,);
  my $scan_file = shift;
  w2log("\nscanning file: <$scan_file>\n\n");
  
  $oldID=0;
  
  $out_file = $scan_file;
  # replace e.g. C:\myhome\myfile.asc with C:\myhome\myfile.txt
  $out_file =~ s/(\.\w+)/_analyzed.txt/;
   
  w2log("\ncreating file: <$out_file>\n\n");
  
    open ( IN,"<$SADfile" ) or warn "Couldn't open $_ : $@";
    while ($line= <IN>){
      if($line =~ /^([^,]+),([^,]+),/){
          $sadTBL{"0x".$2}=$1;
      }
    }

  open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";
  # loop over all lines
  open ( IN,"<$scan_file" ) or die "Couldn't open $_ : $@";
  while ($line= <IN>){
      # if line contains message 
      # e.g.      4.626162 2  A3   Rx   d 8 50 44 30 38 32 65 FF FF
      # or     |  8.436529 1  781  Rx     8 24 80 0E 42 4D 10 01 00                                                                    
#      if ($line =~ /^.+\s+(\w+)\s+\wx\s+d?\s+\d+\s*(.+)$/) {
      if ($line =~ /^.+\s+(\w+)\s+\wx\s+d?\s+\d+\s*([\d\sA-F]+)/) {

          $ID = $1;
          $DATA = $2;
          if ($ID eq $IDecu or $ID eq $IDpd){
            $oldID=$ID if ($oldID eq 0);

            #append on same message
            if ($oldID eq $ID){
                push (@bytes,split(/ /,$DATA));
            }
            else{
            #new message
            	decodeAB12(@bytes) if ($ABgen eq 'AB12');
            	decodeAB10(@bytes) if ($ABgen eq 'AB10');
                @bytes=();
                push (@bytes,split(/ /,$DATA));
                $oldID=$ID;

            }

            print OUT $line;

          }
      
      
      }
      else {w2log("skipped $line");}
      

  } #END while $line
  close (IN);
  # decode last message
  decodeAB12(@bytes) if ($ABgen eq 'AB12');
  decodeAB10(@bytes) if ($ABgen eq 'AB10');
                
  close (OUT);


    print"... done\n\n";
    $display_txt = "file <$out_file> created";
}
# END sub scan_asc

sub decodeAB10{
    my @bytes = @_;
    my ($name,$byte_num,$temp);
    
   
    if (hex($bytes[0]) > 7){
        $byte_num = 1;
            $temp = hex($bytes[0])-7;
    
        while ($temp>0) {
                $temp = $temp-8;
            $byte_num++;
        }
        $byte_num = $byte_num*8;
    }
    else {
        $byte_num = 8;
    }
    
    
    #check if multiple requests, lenth >= 254 bytes will be treated as single request because lenght byte will not match
    if ( scalar(@bytes) > $byte_num and scalar(@bytes) < 255){
        #splice first request and call decode recursively
        print OUT "\n### multiple requests: ".scalar(@bytes)." > $byte_num ###\n\n";
        decodeAB10(splice(@bytes,0,$byte_num));
    }

    
    print OUT "--> ".join(' ', @bytes)."\n";
    if ($bytes[1] eq "01"){
        my $cells = hex($bytes[2].$bytes[3]);
        my $addr = "0x".$bytes[4].$bytes[5].$bytes[6].$bytes[7];
        if ( not defined ($name = $sadTBL{$addr}) ) {
           $name = "unknown";
        }
        print OUT "==> read $cells cells starting from $addr ($name)\n";
        
    }
    elsif ($bytes[1] eq "81"){
        my $num = hex($bytes[0])-1;
        print OUT "==> cells: ".join(' ',@bytes[2 .. $num])."\n";
    }

    elsif ($bytes[1] eq "02"){
        my $cells = hex($bytes[0])-7;
        my $addr = "0x".$bytes[3].$bytes[4].$bytes[5].$bytes[6];
        if ( not defined ($name = $sadTBL{$addr}) ) {
           $name = "unknown";
        }
        print OUT "==> write (".join(' ',@bytes[8 .. 7+$cells]).") to $cells cells starting from $addr ($name)\n";
        
    }
    elsif ($bytes[1] eq "82"){
        if (uc($bytes[2]) eq "AA"){
            print OUT "==> write successful\n";
        }
        else{
            print OUT "==> write error\n";
        }
    }

    elsif ($bytes[1] eq "03"){
        print OUT "==> clear fault memory \n";
    }
    elsif ($bytes[1] eq "83"){
        if (uc($bytes[2]) eq "78"){
            print OUT "==> busy (ok)\n";
        }
        else{
            print OUT "==> error\n";
        }
    }

    elsif ($bytes[1] eq "04"){
        print OUT "==> clear crash recorder \n";
    }
    elsif ($bytes[1] eq "84"){
        if (uc($bytes[2]) eq "78"){
            print OUT "==> busy (ok)\n";
        }
        else{
            print OUT "==> error\n";
        }
    }

    elsif ($bytes[1] eq "05"){
        print OUT "==> ECU status \n";
    }
    elsif ($bytes[1] eq "85"){
            printf OUT "==> status (%08b)\n",hex($bytes[6]);
    }

    elsif ($bytes[1] eq "08"){
        my $num = hex($bytes[2]);
        print OUT "==> calculate CRC for area $num \n";
    }
    elsif ($bytes[1] eq "88"){
        if (uc($bytes[2]) eq "AA"){
            print OUT "==> CRC successful\n";
        }
        else{
            print OUT "==> CRC error\n";
        }
    }

    elsif ($bytes[1] eq "09"){
        print OUT "==> ECU reset \n";
    }
    elsif ($bytes[1] eq "89"){
        if (uc($bytes[2]) eq "AA"){
            print OUT "==> reset will start soon\n";
        }
        else{
            print OUT "==> error\n";
        }
    }

    elsif ($bytes[1] eq "00" and uc($bytes[2]) eq "A1"){
        print OUT "==> request seed\n";
    }
    elsif ($bytes[1] eq "80" and uc($bytes[2]) eq "A1"){
        print OUT "==> seed response\n";
    }
    elsif ($bytes[1] eq "00" and uc($bytes[2]) eq "A2"){
        print OUT "==> send key\n";
    }
    elsif ($bytes[1] eq "80" and hex($bytes[0]) > 28){
        print OUT "==> key ok response, SW is ";
        if (hex($bytes[0]) > 29){
          #print OUT "==> ".chr(hex($bytes[3])).chr(hex($bytes[4])).$bytes[5].$bytes[6]."_BB".$bytes[7].$bytes[8].$bytes[9]."_".chr(hex($bytes[10])).$bytes[11]."_CAT".$bytes[12]."_".$bytes[13].$bytes[14].$bytes[15].$bytes[16]."\n";
          printf OUT ("%c%c%02X%02X_BB%X%02X%02X_%c%02X_CAT%X_%02X%02X%02X%02X \n",hex($bytes[3]),hex($bytes[4]),hex($bytes[5]),hex($bytes[6]),hex($bytes[7]),hex($bytes[8]),hex($bytes[9]),hex($bytes[10]),hex($bytes[11]),hex($bytes[12]),hex($bytes[13]),hex($bytes[14]),hex($bytes[15]),hex($bytes[16]));
        }
        else{
          printf OUT ("%c%c%c%c%c%c%c%c\n",hex($bytes[2]),hex($bytes[3]),hex($bytes[4]),hex($bytes[5]),hex($bytes[6]),hex($bytes[7]),hex($bytes[8]),hex($bytes[9]));
        }
    }
    elsif (uc($bytes[1]) eq "9F" and $bytes[2] eq "55"){
        print OUT "==> login denied !\n";
    }
    elsif (uc($bytes[1]) eq "0F" ){
        print OUT "==> start fast diagnosis\n";
    }

        print OUT "\n";

}


sub decodeAB12{
    my @bytes = @_;
    my ($name,$byte_num,$temp);
    
   
    if (hex($bytes[0]) > 7){
        $byte_num = 1;
            $temp = hex($bytes[0])-7;
    
        while ($temp>0) {
                $temp = $temp-8;
            $byte_num++;
        }
        $byte_num = $byte_num*8;
    }
    else {
        $byte_num = 8;
    }
    
    
    #check if multiple requests, lenth >= 254 bytes will be treated as single request because lenght byte will not match
    if ( scalar(@bytes) > $byte_num and scalar(@bytes) < 255){
        #splice first request and call decode recursively
        print OUT "\n### multiple requests: ".scalar(@bytes)." > $byte_num ###\n\n";
        decodeAB12(splice(@bytes,0,$byte_num));
    }

    
    print OUT "--> ".join(' ', @bytes)."\n";
    if ($bytes[1] eq "01"){ # read cells
        my $cells = hex($bytes[2].$bytes[3]);
        my $addr = "0x".$bytes[4].$bytes[5].$bytes[6].$bytes[7];
        if ( not defined ($name = $sadTBL{$addr}) ) {
           $name = "unknown";
        }
        print OUT "==> read $cells cells starting from $addr ($name)\n";
        
    }
    elsif ($bytes[1] eq "41"){ # read cells response
        my $num = hex($bytes[0])-1;
        print OUT "==> cells: ".join(' ',@bytes[2 .. $num])."\n";
    }

    elsif ($bytes[1] eq "02"){ # write cells
        my $cells = hex($bytes[0])-7;
        my $addr = "0x".$bytes[3].$bytes[4].$bytes[5].$bytes[6];
        if ( not defined ($name = $sadTBL{$addr}) ) {
           $name = "unknown";
        }
        print OUT "==> write (".join(' ',@bytes[8 .. 7+$cells]).") to $cells cells starting from $addr ($name)\n";
        
    }
    elsif ($bytes[1] eq "42"){ # write cells response
        print OUT "==> write successful\n";
    }

    elsif ($bytes[1] eq "04"){ # clear faults
        print OUT "==> clear fault memory \n";
    }
    elsif ($bytes[1] eq "44"){ # clear faults response
        print OUT "==> clear fault memory started\n";
    }

    elsif ($bytes[1] eq "10"){ # read faults
        print OUT "==> read fault memory \n";
    }
    elsif ($bytes[1] eq "50"){ # read faults response
        print OUT "==> read fault memory done\n";
    }
    elsif ($bytes[1] eq "08"){ # clear EDR
        print OUT "==> clear crash recorder \n";
    }
    elsif ($bytes[1] eq "48"){ # clear EDR response
        print OUT "==> clear crash recorder started\n";
    }

    elsif ($bytes[1] eq "09"){ # ECU staus
        print OUT "==> ECU status \n";
    }
    elsif ($bytes[1] eq "49"){ # ECU staus response
            printf OUT "==> status (%08b %08b %08b %08b %08b)\n",hex($bytes[2]),hex($bytes[3]),hex($bytes[4]),hex($bytes[5]),hex($bytes[6]);
    }

    elsif ($bytes[1] eq "12"){ # reset
        print OUT "==> ECU reset \n";
    }
    elsif ($bytes[1] eq "52"){ # reset response
        print OUT "==> reset will start soon\n";
    }

    elsif ($bytes[1] eq "00" and uc($bytes[2]) eq "A1"){ # request seed
        print OUT "==> request seed\n";
    }
    elsif ($bytes[1] eq "40" and uc($bytes[2]) eq "A1"){ # seed response
        print OUT "==> seed response\n";
    }
    elsif ($bytes[1] eq "00" and uc($bytes[2]) eq "A2"){ # send key
        print OUT "==> send key\n";
    }
    elsif ($bytes[1] eq "40" and uc($bytes[2]) eq "A2" and hex($bytes[0]) > 28){ # login response
        print OUT "==> key ok response, SW is ";
        printf OUT ("%c%c%02d%02X_%c%c_%X%02X_BB%X%02X%02X_Cat%c \n",
        hex($bytes[6]),hex($bytes[7]),hex($bytes[3]),hex($bytes[8]),hex($bytes[9]),hex($bytes[10]),
        hex($bytes[11]),hex($bytes[12]),hex($bytes[13]),hex($bytes[14]),hex($bytes[15]),
        hex($bytes[16]));
		# AB1200_BD_057_BB00000_Cat2
		#		   12       A  B  00  B D   057    00000   2
		# 36 40 A2 0C 03 0B 41 42 00 42 44 00 57 00 00 00 32 00 00 00 00 20
		#          3        6  7  8  9  10 11+12 13-15    16                  nr
		#          d        c  c  x  c  c  x      x       c                   type
		#
		#      2 byte customer_id ASCII
		#      1 byte project_id BCD
		#      1 byte HW sample phase ASCII
		#      1 byte HW sample number ASCII
		#      2 byte sequence number of software baseline BCD
		#      3 byte BB number BCD
		#      1 byte baseline category ASCII	
		#
		# The BCD with packed format is used (2 numerals encoded in a single byte).
		# BB number is 5 digit BCD, and hence the high nibble in byte 0 of BCD, shall always be 0 in the response.

    }
    elsif (uc($bytes[1]) eq "7F" ){ # negative response
        print OUT "==> negative response !\n";
    }
    elsif (uc($bytes[1]) eq "90" ){ # fast diag
        print OUT "==> start fast diagnosis\n";
    }

        print OUT "\n";

}

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program



=head1 usage

create commented text file from CANoe can trace for production diagnosis. For resolving address to name give SAD file. pdID is similar to RESPONSE_ID, 
ecuID is similar to REQUEST_ID in DIAG.ini and can be symbolic strings all other CAN IDs will be skipped.

 CLI: PD_analyzer.pl --asc [file] --sad [file] --pdID [hex] --ecuID [hex]
 
 e.g. PD_analyzer.pl --asc=ProdDiag.asc --sad=BB62866.SAD --pdID=680 --ecuID=681
      PD_analyzer.pl --asc=1pd.asc --sad=bm1001_BB00000_b37_Cat2_20090909.sad --pdID=Diag_2_ABECU --ecuID=ABECU_2_Diag

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

