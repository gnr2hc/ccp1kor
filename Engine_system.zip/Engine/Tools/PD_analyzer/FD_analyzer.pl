#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use File::Path;
use Getopt::Long;

my $Toolversion = "FD_analyzer ($VERSION)";      # Tool version number

my %sadTBL;

my ($scan_file, $out_file);
my ( $main, $ValueFrame,$ValueFrame2,$ValueFrame3, $ButtonFrame, $ValueEntry, $display_txt);
my $SADfile;
my $IDecu;
my $IDpd;


################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "decode FD in CANoe trace file $VERSION" );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );
# create frame 'ValueFrame' in window 'main'
$ValueFrame2 = $main -> Frame() -> pack( "-pady" => 5 );
$ValueFrame3 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "asc file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["ASC files", '.asc'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.asc)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);


# create label in window 'ValueWindow'
$ValueFrame3 -> Label( "-text" => "FD ID: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
 $ValueFrame3 -> Entry(
            "-width" => 30,
            "-textvariable" => \$IDpd, #reference to $prj_id
            )-> pack( "-side" => 'left', );

# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "CREATE",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        scan_asc($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if project_id is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );
        }
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">FD_analyzer_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with CLI
GetOptions('asc=s' => \$scan_file , 'pdID=s' =>\$IDpd, 'ecuID=s' =>\$IDecu);
if ($scan_file and $IDpd and $IDecu){ # source file
    w2log("running with CLI\n");
    scan_asc($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++








###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub scan_asc
{
  my ($line,$oldID,@bytes,$ID,$DATA,);
  my $scan_file = shift;
  w2log("\nscanning file: <$scan_file>\n\n");
  
  $oldID=0;
  
  $out_file = $scan_file;
  # replace e.g. C:\myhome\myfile.asc with C:\myhome\myfile.txt
  $out_file =~ s/(\.\w+)/_timchecked.txt/;
   
  w2log("\ncreating file: <$out_file>\n\n");
  
  open ( OUT,">$out_file" ) or die "Couldn't open $_ : $@";
  # loop over all lines
  open ( IN,"<$scan_file" ) or die "Couldn't open $_ : $@";
  
  my ($last_time,$new_resp,$violation);
  $violation=0;
  while ($line= <IN>){
      # if line contains message 
      # e.g.      4.626162 2  A3   Rx   d 8 50 44 30 38 32 65 FF FF
      # or     |  8.436529 1  781  Rx     8 24 80 0E 42 4D 10 01 00                                                                    


      if ($line =~ /^\s*(\S+)\s+\w\s+(\w+)/) {

          $ID = $2;
          $DATA = $1;
          if ($ID eq $IDpd){
			$new_resp=0;
		  }
          if ($ID eq $IDecu){
			  unless ($new_resp){
				$last_time=$DATA;
				$new_resp=1;
			  }
			  else{
				  my $delta = $DATA-$last_time;
				  if ($delta>0.003){
					print OUT "!!! time delay $delta > 30 ms !!!\n";
					w2log("!!! time delay $delta > 30 ms !!!\n");
					$violation++;
					
				  }
				  $last_time=$DATA;
			  }


          }
      
      
      }
#      else {w2log("skipped $line");}
      
      print OUT $line;

	  
  } #END while $line
  close (IN);

  close (OUT);

	w2log("\nfound $violation violations.\n\n");
      print OUT "\nfound $violation violations.\n";

    print"... done\n\n";
    $display_txt = "file <$out_file> created";
}
# END sub scan_asc

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program



=head1 usage

create commented text file from CAnoe trace or PD analyzed file and check if consecutive ECU frames have less than 30 ms delay. pdID is similar to RESPONSE_ID, 
ecuID is similar to REQUEST_ID in DIAG.ini and can be symbolic strings.

 CLI: FD_analyzer.pl --asc [file] --pdID [hex] --ecuID [hex]
 
 e.g. FD_analyzer.pl --asc=ProdDiag.asc --pdID=680  --ecuID 681

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut

