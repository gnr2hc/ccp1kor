
#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.3 $;
#################################################################################

package LIFT_config;
our $LIFT_Testbench;
1;

use File::Basename;

my $addpath;

BEGIN {
	my $LIFT_exec_path = './../..';

	# add directories to search path for perl modules
	unshift @INC, "$LIFT_exec_path/modules/Common_library";
	unshift @INC, "$LIFT_exec_path/modules/Device_layer";
}

#Add libraries
use strict;
use warnings;
use LIFT_general;
use LIFT_stub;

use LIFT_TOELLNER;
use Tk;
use Tk::BrowseEntry;
use Tk::Pane;

my $log_path = dirname($0);

# just define some Engine variables
#our $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
our $ProjectDefaults = '';
our $opt_offline     = 0;    # $opt_offline = 1; # set offline mode
our $opt_silent      = 0;    # $opt_silent = 1; # set silent mode (logging will not print)
our $save_name;              # name of log/report/result-files, given from user or Testlist will be taken
our $CURRENT_TC = 'test';

STUB_init();

my $Toolversion = "Toellner_GUI ($VERSION)";    # Tool version number

#Variables
my ( $main, $ConnectionFrame, $ButtonFrame, $ConnectionEntry, $display_txt, $ScopeLabel, $ScopeMenu );
my ( $ConnButton_text, $Save_File_String, $Open_File_String, $Box_Graph, $Box_Save_Value_Frame, $Box_Load_Value_Frame );
my ( $Box_Run_Value_Frame, $Box_Settings_Value_Frame, $Text_Box_Open_File, $Text_Box_Save_File, $Box_Save_Value_Button_Frame );
my ( $Box_Load_Value_Button_Frame, $connected, $connection, $Box_Save, $Box_Load, $Box_Settings, $Box_Ramps, $Box_Ramps_Button_Frame, @Box_Ramps_Ramp_Frame, $Box_Ramps_Ramps_Frame );
my ( $Box_Run, $start, $end, $voltage, $runstart, $runend, $runrepeat, $Help_String, $Rampcount, $count );
my ( $Button_Connect, $Button_Browse_open_file, $Button_Browse_Save_file, $Button_Save_Curve, $Button_Load_curve );
my ( $Box_Ramps_load_Frame, $Open_Ramp_String, $Text_Box_Open_Ramp,      $Button_Browse_open_ramp );
my ( $Box_Ramps_save_Frame, $Save_Ramp_String, $Button_Browse_Save_ramp, $Text_Box_Save_Ramp );
my ( $Button_Save_Ramp,     $Button_Load_Ramp, $Button_Download_Ramp,    $Button_create_Rampgraph );
my ( $Button_create_graph,  $Button_On,        $Button_Off,              $Button_Run_Curve, $Button_Run_Curve_trigger, $Device_ID );
my ( @Vstart,               @Vend,             @time,                    @samples, @VstartEntry, @VendEntry, @timeEntry, @samplesEntry );
my ( $Conn_Status, $current_ramp_lenght, $GPIBdevice );

my $name = 'Toellner';
#Set initial Values
$ConnButton_text = "CONNECT";
$start           = 0;
$end             = 999;
$voltage         = 13.8;
$runstart        = 0;
$runend          = 999;
$runrepeat       = 0;
$Rampcount       = 50;
$GPIBdevice      = 0;
$connection      = '8';

@Vstart = @Vend = @time = @samples = (0) x $Rampcount;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow->new();

# create title in window 'main'
$main->title("Toellner_GUI $VERSION");

# create frames with heading lables in window 'main'
$main->Label( "-text" => "\nConnect to device", )->pack( '-anchor' => 'w' );
$ConnectionFrame = $main->Frame( "-relief" => 'groove', "-bd" => 2 )->pack();
$main->Label( "-text" => "\nSave curve from device to file", )->pack( '-anchor' => 'w' );
$Box_Save = $main->Frame( "-relief" => 'groove', "-bd" => 2,"-background" => "grey" )->pack( "-padx" => 5, "-fill" => 'x' );
$main->Label( "-text" => "\nLoad curve from file to device", )->pack( '-anchor' => 'w' );
$Box_Load = $main->Frame( "-relief" => 'groove', "-bd" => 2,"-background" => "grey" )->pack( "-padx" => 5, "-fill" => 'x' );
$main->Label( "-text" => "\nPower settings", )->pack( '-anchor' => 'w' );
$Box_Settings = $main->Frame( "-relief" => 'groove', "-bd" => 2,"-background" => "grey" )->pack( "-padx" => 5, "-fill" => 'x' );
$main->Label( "-text" => "\nRun curve", )->pack( '-anchor' => 'w' );
$Box_Run = $main->Frame( "-relief" => 'groove', "-bd" => 2,"-background" => "grey" )->pack( "-padx" => 5, "-fill" => 'x' );
$main->Label( "-text" => "\nCreate Ramps", )->pack( '-anchor' => 'w' );
$Box_Ramps = $main->Frame( "-relief" => 'groove', "-bd" => 2,"-background" => "grey" )->pack( "-padx" => 5, "-fill" => 'x' );

#create Frame Elements
$Box_Save_Value_Frame        = $Box_Save->Frame()->pack( "-pady" => 5 );
$Box_Save_Value_Button_Frame = $Box_Save->Frame()->pack( "-pady" => 5 );

$Box_Load_Value_Frame        = $Box_Load->Frame()->pack( "-pady" => 5 );
$Box_Load_Value_Button_Frame = $Box_Load->Frame()->pack( "-pady" => 5 );

$Box_Settings_Value_Frame = $Box_Settings->Frame()->pack( "-pady" => 5 );

$Box_Run_Value_Frame = $Box_Run->Frame()->pack( "-pady" => 5 );

$Box_Ramps_save_Frame   = $Box_Ramps->Frame()->pack( "-pady" => 5 );
$Box_Ramps_load_Frame   = $Box_Ramps->Frame()->pack( "-pady" => 5 );
$Box_Ramps_Button_Frame = $Box_Ramps->Frame()->pack( "-pady" => 5 );
$Box_Ramps_Ramps_Frame  = $Box_Ramps->Scrolled(
	'Pane',
	'-scrollbars' => 'e',
	"-height"     => 200,
)->pack( "-pady" => 5 );
for ( $count = 0 ; $count < $Rampcount ; $count++ ) {
	$Box_Ramps_Ramp_Frame[$count] = $Box_Ramps_Ramps_Frame->Frame()->pack( "-pady" => 5 );
}

# create label in window 'main'
$main->Label(
	"-textvariable" => \$display_txt,               #reference to $display_txt
	"-font"         => "{MS Sans Serif} 10 bold",
)->pack();
######## connection Frame

# create 'connect' button
$Button_Connect = $ConnectionFrame->Button(
	"-textvariable" => \$ConnButton_text,
	"-command"      => sub {                # execute when button is pressed
		if ($connection) {
			$LIFT_config::LIFT_Testbench->{'Devices'}{'TOELLNER'}{'Toellner'}{'gpib'}      = $connection;
			$LIFT_config::LIFT_Testbench->{'Devices'}{'TOELLNER'}{'Toellner'}{'interface'} = $GPIBdevice;

			unless ($connected) {

				$Device_ID = TOE_connect($name);

				# if Device is not connected TOE_connect will return ''
				if ( $Device_ID eq "" ) {

					#write Error Message
					$display_txt = "Connection failed";
					w2log("Connection failed");
				}
				else {
					$ConnButton_text = "disconnect";
					$display_txt     = "connected to Device" . $Device_ID;
					$connected       = 1;
					Set_Active();
					Set_Active_Arbitrary() if (TOE_isArbitrary( $name ));
				}
			}
			else {
				TOE_disconnect($name);
				$ConnButton_text = "CONNECT";
				$display_txt     = "disconnected from Device";
				$connected       = 0;
				Set_Inactive();
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                                     #qw/error info question warning/
				'-type'    => "OK",                                        #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please select connection details first!"
			);
		}
	}
)->pack( "-side" => 'left' );

# create label in Frame 'ConnectionFrame'
$ConnectionFrame->Label( "-text" => " GPIB address ", )->pack( "-side" => 'left', );

# create entry 'ConnectionEntry' in 'ConnectionFrame'
$ConnectionEntry = $ConnectionFrame->BrowseEntry(
	"-width"    => 5,
	"-variable" => \$connection,
);
$ConnectionEntry->pack( "-side" => 'left', );
$ConnectionEntry->insert( "end", '2' );
$ConnectionEntry->insert( "end", '8' );
$ConnectionEntry->insert( "end", '21' );
$ConnectionEntry->insert( "end", '23' );

$ConnectionFrame->Label( "-text" => " GPIBdevice ", )->pack( "-side" => 'left', );
$ConnectionFrame->Entry(
	"-width"        => 2,
	"-textvariable" => \$GPIBdevice,    #reference to variable
)->pack( "-side" => 'left', );

# create 'exit' button
$ConnectionFrame->Button(
	"-text"       => "E X I T",
	"-background" => "red",
	"-command"    => sub { $main->destroy; }
)->pack( "-side" => 'left', "-ipadx" => 20, "-ipady" => 20, "-padx" => 20 );

######## values

# create Save file dialog
$Text_Box_Save_File = $Box_Save_Value_Frame->Entry(
	"-width"        => 50,
	"-textvariable" => \$Save_File_String,    #reference to variable
);
$Text_Box_Save_File->pack( "-side" => 'left', );

# create 'browse save file' button
$Button_Browse_Save_file = $Box_Save_Value_Frame->Button(
	"-text"    => "Browse save file",
	"-state"   => "disabled",
	"-command" => sub {

		#store old variable value
		$Help_String = $Save_File_String;

		# browse for file
		$Save_File_String = $main->getSaveFile(
			"-filetypes" => [ [ "curve files", ['.sat'] ], [ "All files", '.*' ] ],
			"-title" => "select SAT file to save values",
			"-defaultextension" => 'sat',
		);

		# if a file was chosen
		if ($Save_File_String) {

			#extract directory
			print "\n $Save_File_String was chosen\n";
		}
		else {
			#restore old variable value
			$Save_File_String = $Help_String;
			print "no filename!\n";
		}
	}
)->pack( "-side" => 'left', "-padx" => 5, );

# create from .. to .. samlpe dialog
$Box_Save_Value_Button_Frame->Label( "-text" => "from sample", )->pack( "-side" => 'left', "-pady" => 5 );

$Box_Save_Value_Button_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$start,
)->pack( "-side" => 'left', );

$Box_Save_Value_Button_Frame->Label( "-text" => "to", )->pack( "-side" => 'left', "-pady" => 5 );

$Box_Save_Value_Button_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$end,
)->pack( "-side" => 'left', );

# create 'save CURVE' button
$Button_Save_Curve = $Box_Save_Value_Button_Frame->Button(
	"-text"    => "save CURVE",
	"-state"   => "disabled",
	"-command" => sub {           # execute when button is pressed, first show if connected
		if ($connected) {
			if ($Save_File_String) {    # store Curve if Save_File_String is not ''

				#Range Check for Inputs
				if ( ( $end >= 1 ) && ( $end <= 999 ) ) {

					if ( ( $start >= 0 ) && ( $start < 999 ) ) {

						if ( $start == $end ) {
							$display_txt = "Range Bad, start and End have the same Value";
							w2log("curve cannot be run, start and End have the same Value");
						}
						else {
							if ( $start > $end ) {
								$display_txt = "Range Bad, start is higher as end";
								w2log("curve cannot be run, start is higher as end");
							}
							else {
								$display_txt = "saving curve from $start to $end to $Save_File_String";
								$main->update();
								TOE_saveCurveFile( $name, $Save_File_String, $start, $end );
								$display_txt = "curve saved";
							}
						}
					}
					else {
						$display_txt = "Start Range Bad";
						w2log("curve cannot be run, Start Range Bad");
					}
				}
				else {
					$display_txt = "Range Bad, End Range Bad";
					w2log("curve cannot be run, End Range Bad");
				}
			}
			else {
				# prompt user if Curve File name is undefined
				$main->messageBox(
					'-icon'    => "error",                            #qw/error info question warning/
					'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
					'-title'   => 'Attention',
					'-message' => "!Please select save file first!"
				);
			}
		}
		else {
			# not connected
			$main->messageBox(
				'-icon'    => "error",                                #qw/error info question warning/
				'-type'    => "OK",                                   #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create Open file dialog
$Text_Box_Open_File = $Box_Load_Value_Frame->Entry(
	"-width"        => 50,
	"-textvariable" => \$Open_File_String,
);
$Text_Box_Open_File->pack( "-side" => 'left', );

# create 'browse file' button
$Button_Browse_open_file = $Box_Load_Value_Frame->Button(
	"-text"    => "Browse open file",
	"-state"   => "disabled",
	"-command" => sub {

		#store old variable value
		$Help_String = $Open_File_String;

		# browse for file
		$Open_File_String = $main->getOpenFile(
			"-filetypes" => [ [ "curve files", ['.sat'] ], [ "All files", '.*' ] ],
			"-title" => "select SAT file to load values",
		);

		# if a file was chosen
		if ($Open_File_String) {

			#extract directory
			print "\n $Open_File_String was chosen\n";
		}
		else {
			#restore old variable value
			$Open_File_String = $Help_String;
			print "no filename!\n";
		}
	}
)->pack( "-side" => 'left', "-padx" => 5, );

# create 'Load Curve' button
$Button_Load_curve = $Box_Load_Value_Button_Frame->Button(
	"-text"    => "load CURVE",
	"-state"   => "disabled",
	"-command" => sub {           # execute when button is pressed
		if ($connected) {
			if ($Open_File_String) {
				$display_txt = "load curve from $Open_File_String";
				$main->update();
				TOE_setCurveFile( $name, $Open_File_String );
				TOE_writeString( $name, "FAE?");
				$runend = TOE_readString( $name );
				$display_txt = "curve loaded: $runend points";
			}
			else {
				$main->messageBox(
					'-icon'    => "error",                            #qw/error info question warning/
					'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
					'-title'   => 'Attention',
					'-message' => "!Please select open file first!"
				);
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                                #qw/error info question warning/
				'-type'    => "OK",                                   #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}
	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create 'create graph' button
$Button_create_graph = $Box_Load_Value_Button_Frame->Button(
	"-text"    => "create graph",
	"-state"   => "disabled",
	"-command" => sub {

		# execute when button is pressed
		if ($Open_File_String) {
			$display_txt = "create graph from $Open_File_String";
			$main->update();

			if ( $Help_String = TOE_createGraph($Open_File_String) ) {
				$display_txt = "graph created";
				system( exec, $Help_String ) or $display_txt = "graph created";
			}
			else {
				$display_txt = "Graph, cannot be created";
				w2log("Graph, cannot be created");
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                            #qw/error info question warning/
				'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please select open file first!"
			);
		}
	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create voltage dialog
$Box_Settings_Value_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$voltage,
)->pack( "-side" => 'left', );

$Box_Settings_Value_Frame->Label( "-text" => "V", )->pack( "-side" => 'left', "-pady" => 5 );

# create 'On' button
$Button_On = $Box_Settings_Value_Frame->Button(
	"-text"    => "ON",
	"-state"   => "disabled",
	"-command" => sub {         # execute when button is pressed
		if ($connected) {
			$main->update();

			#Range Check for Voltage input, max. 32.00 Volt
			if ( $voltage <= 32 ) {
				TOE_VOLTAGE( $name, $voltage );
				TOE_ON( $name );
				$display_txt = "switched on at $voltage V";
			}
			else {
				$display_txt = "Value out of Range, Voltage max. Range is 32.0V";
				w2log("Value out of Range, Voltage max. Range is 32.0V");
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                             #qw/error info question warning/
				'-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create 'Off' button
$Button_Off = $Box_Settings_Value_Frame->Button(
	"-text"    => "OFF",
	"-state"   => "disabled",
	"-command" => sub {         # execute when button is pressed
		if ($connected) {
			$main->update();
			TOE_OFF( $name );;
			$display_txt = "switched off";
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                             #qw/error info question warning/
				'-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}
	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create 'run CURVE' button
$Button_Run_Curve = $Box_Run_Value_Frame->Button(
	"-text"    => "run CURVE",
	"-state"   => "disabled",
	"-command" => sub {                                            # execute when button is pressed
		if ($connected) {
			$display_txt = "running curve from $runstart to $runend repeat $runrepeat";
			$main->update();

			#Range Check for Inputs
			if ( ( $runend >= 1 ) && ( $runend <= 999 ) ) {
				if ( ( $runstart >= 0 ) && ( $runstart < 999 ) ) {
					if ( $runrepeat <= 255 ) {
						if ( $runstart == $runend ) {
							$display_txt = "Range Bad, Begin and End have the same Value";
							w2log("curve cannot be run, Begin and End have the same Value");
						}
						else {
							if ( $runstart > $runend ) {
								$display_txt = "Range Bad, start is higher as begin";
								w2log("curve cannot be run, start is higher as end");
							}
							else {
								TOE_setRepetition( $name, $runrepeat );
								TOE_setCurveStart( $name, $runstart );
								TOE_setCurveEnd( $name, $runend );
								TOE_runCurve( $name );
							}
						}
					}
					else {
						$display_txt = "repetition must can be max. 255";
						w2log( "curve cannot be run, repetition out of range: " . $runrepeat );

					}
				}
				else {
					$display_txt = "Run start must be from 0 to 998";
					w2log( "curve cannot be run, Run start: " . $runstart );
				}
			}
			else {
				$display_txt = "Curve end bad";
				w2log( "curve cannot be run, Run end: " . $runend );
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                             #qw/error info question warning/
				'-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

# create from sample .. to .. repetition .. dialog
$Box_Run_Value_Frame->Label( "-text" => "from sample", )->pack( "-side" => 'left', "-pady" => 5 );

$Box_Run_Value_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$runstart,
)->pack( "-side" => 'left', );

$Box_Run_Value_Frame->Label( "-text" => "to", )->pack( "-side" => 'left', "-pady" => 5 );

$Box_Run_Value_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$runend,
)->pack( "-side" => 'left', );

$Box_Run_Value_Frame->Label( "-text" => "repetition", )->pack( "-side" => 'left', "-pady" => 5 );

$Box_Run_Value_Frame->Entry(
	"-width"        => 4,
	"-textvariable" => \$runrepeat,
)->pack( "-side" => 'left', );

# create 'run CURVE trigger' button
$Button_Run_Curve_trigger = $Box_Run_Value_Frame->Button(
	"-text"    => "run CURVE on trigger",
	"-state"   => "disabled",
	"-command" => sub {                     # execute when button is pressed
		if ($connected) {
			$display_txt = "triggering curve to run from $runstart to $runend repeat $runrepeat";
			$main->update();

			#Range Check for Inputs
			if ( ( $runend >= 1 ) && ( $runend <= 999 ) ) {
				if ( ( $runstart >= 0 ) && ( $runstart < 999 ) ) {
					if ( $runrepeat <= 255 ) {
						if ( $runstart == $runend ) {
							$display_txt = "Range Bad, Begin and End have the same Value";
							w2log("curve cannot be run, Begin and End have the same Value");
						}
						else {
							if ( $runstart > $runend ) {
								$display_txt = "Range Bad, start is higher as begin";
								w2log("curve cannot be run, start is higher as end");
							}
							else {
								TOE_setRepetition( $name, $runrepeat );
								TOE_setCurveStart( $name, $runstart );
								TOE_setCurveEnd( $name, $runend );
								TOE_runCurve( $name, 1);
							}
						}
					}
					else {
						$display_txt = "repetition must can be max. 255";
						w2log( "curve cannot be run, repetition out of range: " . $runrepeat );

					}
				}
				else {
					$display_txt = "Run start must be from 0 to 998";
					w2log( "curve cannot be run, Run start: " . $runstart );
				}
			}
			else {
				$display_txt = "Curve end bad";
				w2log( "curve cannot be run, Run end: " . $runend );
			}
		}
		else {
			$main->messageBox(
				'-icon'    => "error",                             #qw/error info question warning/
				'-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 30 );

### ramps

# create Save ramp dialog
$Text_Box_Save_Ramp = $Box_Ramps_save_Frame->Entry(
	"-width"        => 50,
	"-textvariable" => \$Save_Ramp_String,    #reference to variable
);
$Text_Box_Save_Ramp->pack( "-side" => 'left', );

# create 'browse save file' button
$Button_Browse_Save_ramp = $Box_Ramps_save_Frame->Button(
	"-text"    => "Browse save ramps",
	"-state"   => "disabled",
	"-command" => sub {

		#store old variable value
		$Help_String = $Save_Ramp_String;

		# browse for file
		$Save_Ramp_String = $main->getSaveFile(
			"-filetypes" => [ [ "curve files", ['.txt'] ], [ "All files", '.*' ] ],
			"-title" => "select RAMP file to save ramps",
			"-defaultextension" => 'txt',
		);

		# if a file was chosen
		if ($Save_Ramp_String) {

			#extract directory
			print "\n $Save_Ramp_String was chosen\n";
		}
		else {
			#restore old variable value
			$Save_Ramp_String = $Help_String;
			print "no filename!\n";
		}
	}
)->pack( "-side" => 'left', "-padx" => 5, );

# create load ramp dialog
$Text_Box_Open_Ramp = $Box_Ramps_load_Frame->Entry(
	"-width"        => 50,
	"-textvariable" => \$Open_Ramp_String,
);
$Text_Box_Open_Ramp->pack( "-side" => 'left', );

# create 'browse file' button
$Button_Browse_open_ramp = $Box_Ramps_load_Frame->Button(
	"-text"    => "Browse open ramps",
	"-state"   => "disabled",
	"-command" => sub {

		#store old variable value
		$Help_String = $Open_Ramp_String;

		# browse for file
		$Open_Ramp_String = $main->getOpenFile(
			"-filetypes" => [ [ "curve files", ['.txt'] ], [ "All files", '.*' ] ],
			"-title" => "select RAMP file to load ramps",
		);

		# if a file was chosen
		if ($Open_Ramp_String) {

			#extract directory
			print "\n $Open_Ramp_String was chosen\n";
		}
		else {
			#restore old variable value
			$Open_Ramp_String = $Help_String;
			print "no filename!\n";
		}
	}
)->pack( "-side" => 'left', "-padx" => 5, );

# create 'download RAMP' button
$Button_Download_Ramp = $Box_Ramps_Button_Frame->Button(
	"-text"    => "download RAMPS to device",
	"-state"   => "disabled",
	"-command" => sub {                         # execute when button is pressed, first show if connected
		if ($connected) {

			$display_txt = "downloading ramp to device";
			$main->update();

			if ( check_ramp() ) {
				my $RampStruct = [ [] ];
				my $lastpoint = -1;
				my ( $full_duration, $duration );
				$full_duration=0;

				# stop running curve
				if ( TOE_isCurveRunning( $name ) ) {
					TOE_stopCurve( $name );
				}
				for ( $count = 0 ; $count < $current_ramp_lenght ; $count++ ) {
					$duration = TOE_setCurveRamp( $name, $Vstart[$count], $Vend[$count], $time[$count], $lastpoint + 1, $lastpoint + $samples[$count] );
					$lastpoint += $samples[$count];
					$full_duration += $duration;
				}

				$runstart = 0;
				$runend   = $lastpoint;

				$display_txt = "ramp downloaded, will run $full_duration ms";

			}

		}
		else {
			# not connected
			$main->messageBox(
				'-icon'    => "error",                             #qw/error info question warning/
				'-type'    => "OK",                                #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 10 );

# create 'save RAMP' button
$Button_Save_Ramp = $Box_Ramps_Button_Frame->Button(
	"-text"    => "save RAMPS to file",
	"-state"   => "disabled",
	"-command" => sub {                   # execute when button is pressed, first show if connected
		if ($connected) {

			$display_txt = "saving ramp to device";
			$main->update();
			if ( check_ramp() ) {
				my ( @VstartNew, @VendNew, @timeNew, @samplesNew );

				if ($Save_Ramp_String) {    # store Graph if Save_Ramp_String is not ''

					for ( $count = 0 ; $count < $current_ramp_lenght ; $count++ ) {

						push( @VstartNew,  $Vstart[$count] );
						push( @VendNew,    $Vend[$count] );
						push( @timeNew,    $time[$count] );
						push( @samplesNew, $samples[$count] );
					}

					open( OUT, ">$Save_Ramp_String" ) or die "";
					print OUT "Vstart     = @(" . join( ',', @VstartNew ) . ")\n";
					print OUT "Vend       = @(" . join( ',', @VendNew ) . ")\n";
					print OUT "Time_ms    = @(" . join( ',', @timeNew ) . ")\n";
					print OUT "points     = @(" . join( ',', @samplesNew ) . ")\n";
					print OUT "repetition = $runrepeat\n";

					close(OUT);

					$display_txt = "ramp saved to $Save_Ramp_String";
				}
				else {
					# prompt user if Curve File name is undefined
					$main->messageBox(
						'-icon'    => "error",                            #qw/error info question warning/
						'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
						'-title'   => 'Attention',
						'-message' => "!Please select save file first!"
					);
				}
			}

		}
		else {
			# not connected
			$main->messageBox(
				'-icon'    => "error",                                    #qw/error info question warning/
				'-type'    => "OK",                                       #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 10 );

# create 'load RAMP file' button
$Button_Load_Ramp = $Box_Ramps_Button_Frame->Button(
	"-text"    => "load RAMPS from file",
	"-state"   => "disabled",
	"-command" => sub {                     # execute when button is pressed, first show if connected

		if ($Open_Ramp_String) {
			$display_txt = "load ramp from $Open_Ramp_String";
			$main->update();

			#reset arrays
			@Vstart = @Vend = @time = @samples = (0) x $Rampcount;
			my ( $line, $values, @VstartNew, @VendNew, @timeNew, @samplesNew );

			open( IN, "<$Open_Ramp_String" ) or die "";
			while ( $line = <IN> ) {
				if ( $line =~ m/\s*Vstart\s*=\s*@\s*\(([^)]+)\)/ ) {
					$values = $1;
					$values =~ s/\s+//g;    # drop all whitespaces
					@VstartNew = split( /,/, $values );
				}
				elsif ( $line =~ m/\s*Vend\s*=\s*@\s*\(([^)]+)\)/ ) {
					$values = $1;
					$values =~ s/\s+//g;    # drop all whitespaces
					@VendNew = split( /,/, $values );
				}
				elsif ( $line =~ m/\s*Time_ms\s*=\s*@\s*\(([^)]+)\)/ ) {
					$values = $1;
					$values =~ s/\s+//g;    # drop all whitespaces
					@timeNew = split( /,/, $values );
				}
				elsif ( $line =~ m/\s*points\s*=\s*@\s*\(([^)]+)\)/ ) {
					$values = $1;
					$values =~ s/\s+//g;    # drop all whitespaces
					@samplesNew = split( /,/, $values );
				}
				elsif ( $line =~ m/\s*repetition\s*=\s*(\d+)/ ) {
					$values = $1;
					if ( $values >= 0 and $values <= 255 ) {
						$runrepeat = $values;
					}
					else { $runrepeat = 0; }
				}

			}
			close(IN);

			# check if arrays have same length before overwriting values
			if ( ( @VstartNew + @VendNew + @timeNew + @samplesNew ) / 4 == @VstartNew ) {

				# overwrite values
				for ( $count = 0 ; $count < scalar(@VstartNew) ; $count++ ) {
					$Vstart[$count]  = $VstartNew[$count];
					$Vend[$count]    = $VendNew[$count];
					$time[$count]    = $timeNew[$count];
					$samples[$count] = $samplesNew[$count];
				}

				# update GUI
				for ( $count = 0 ; $count < $Rampcount ; $count++ ) {
					$VstartEntry[$count]->configure( -textvariable => \$Vstart[$count] );
					$VendEntry[$count]->configure( -textvariable => \$Vend[$count] );
					$timeEntry[$count]->configure( -textvariable => \$time[$count] );
					$samplesEntry[$count]->configure( -textvariable => \$samples[$count] );
				}

				$display_txt = "ramp loaded";
			}
			else {
				$main->messageBox(
					'-icon'    => "error",                  #qw/error info question warning/
					'-type'    => "OK",                     #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
					'-title'   => 'Attention',
					'-message' => "!Error in array size!"
				);
				$display_txt = "Error in $Open_Ramp_String";
			}

		}
		else {
			$main->messageBox(
				'-icon'    => "error",                            #qw/error info question warning/
				'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please select open file first!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 10 );

# create 'create RAMP file' button
$Button_create_Rampgraph = $Box_Ramps_Button_Frame->Button(
	"-text"    => "create RAMPS graph",
	"-state"   => "disabled",
	"-command" => sub {                   # execute when button is pressed, first show if connected
		if ($connected) {

			$display_txt = "create ramp graph";
			$main->update();
			if ( check_ramp() ) {
				my $RampStruct = [ [] ];
				my $lastpoint = -1;
				my ( $status, $picfile );

				if ($Save_Ramp_String) {    # store Graph if Save_Ramp_String is not ''
					for ( $count = 0 ; $count < $current_ramp_lenght ; $count++ ) {
						$RampStruct->[$count] = [ $Vstart[$count], $Vend[$count], $time[$count], $lastpoint + 1, $lastpoint + $samples[$count] ];
						$lastpoint += $samples[$count];
					}

					if ( $Help_String = TOE_createRampGraph( $Save_Ramp_String, $RampStruct ) ) {
						$display_txt = "ramp graph $Help_String created";
						system( exec, $Help_String ) or $display_txt = "graph created";
					}
					else {
						$display_txt = "ramp graph cannot be created";
						w2log("ramp graph cannot be created");
					}

				}
				else {
					# prompt user if Curve File name is undefined
					$main->messageBox(
						'-icon'    => "error",                            #qw/error info question warning/
						'-type'    => "OK",                               #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
						'-title'   => 'Attention',
						'-message' => "!Please select save file first!"
					);
				}

			}

		}
		else {
			# not connected
			$main->messageBox(
				'-icon'    => "error",                                    #qw/error info question warning/
				'-type'    => "OK",                                       #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
				'-title'   => 'Attention',
				'-message' => "!Please connect first to Device!"
			);
		}

	}
)->pack( "-side" => 'left', "-ipadx" => 20, "-padx" => 10 );

for ( $count = 0 ; $count < $Rampcount ; $count++ ) {

	# create labels and entries for each ramp
	$Box_Ramps_Ramp_Frame[$count]->Label( "-text" => "Ramp $count: Vstart=", )->pack( "-side" => 'left', "-pady" => 5 );

	$VstartEntry[$count] = $Box_Ramps_Ramp_Frame[$count]->Entry(
		"-width"        => 6,
		"-textvariable" => \$Vstart[$count],
	)->pack( "-side" => 'left', );

	$Box_Ramps_Ramp_Frame[$count]->Label( "-text" => "V, Vend=", )->pack( "-side" => 'left', "-pady" => 5 );

	$VendEntry[$count] = $Box_Ramps_Ramp_Frame[$count]->Entry(
		"-width"        => 6,
		"-textvariable" => \$Vend[$count],
	)->pack( "-side" => 'left', );

	$Box_Ramps_Ramp_Frame[$count]->Label( "-text" => "V, time=", )->pack( "-side" => 'left', "-pady" => 5 );

	$timeEntry[$count] = $Box_Ramps_Ramp_Frame[$count]->Entry(
		"-width"        => 6,
		"-textvariable" => \$time[$count],
	)->pack( "-side" => 'left', );

	$Box_Ramps_Ramp_Frame[$count]->Label( "-text" => "ms, samples=", )->pack( "-side" => 'left', "-pady" => 5 );

	$samplesEntry[$count] = $Box_Ramps_Ramp_Frame[$count]->Entry(
		"-width"        => 6,
		"-textvariable" => \$samples[$count],
	)->pack( "-side" => 'left', );
}

############# Buttons

#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open( LOG, ">Toellner_GUI_log.txt" ) or die "Couldn't open Toellner_GUI_log.txt : $@";

w2log("######################################################################\n");
w2log("### Toellner Power Supply GUI ###\n");
w2log("######################################################################\n");
w2log("$Toolversion logfile\n");

MainLoop;

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");
close(LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++

#Fuction Set all Buttons into Normal (active) State
sub Set_Active() {
	$Button_Off->configure( "-state" => "normal" );
	$Button_On->configure( "-state" => "normal" );
	$Box_Settings->configure( "-background" => "SystemButtonFace" );
}
sub Set_Active_Arbitrary() {
	$Button_Browse_open_file->configure( "-state" => "normal" );
	$Button_Browse_Save_file->configure( "-state" => "normal" );
	$Button_Save_Curve->configure( "-state" => "normal" );
	$Button_Load_curve->configure( "-state" => "normal" );
	$Button_create_graph->configure( "-state" => "normal" );
	$Button_Run_Curve->configure( "-state" => "normal" );
	$Button_Run_Curve_trigger->configure( "-state" => "normal" );
	$Button_Save_Ramp->configure( "-state" => "normal" );
	$Button_Load_Ramp->configure( "-state" => "normal" );
	$Button_create_Rampgraph->configure( "-state" => "normal" );
	$Button_Download_Ramp->configure( "-state" => "normal" );
	$Button_Browse_open_ramp->configure( "-state" => "normal" );
	$Button_Browse_Save_ramp->configure( "-state" => "normal" );
	$Box_Save->configure( "-background" => "SystemButtonFace" );
	$Box_Load->configure( "-background" => "SystemButtonFace" );
	$Box_Run->configure( "-background" => "SystemButtonFace" );
	$Box_Ramps->configure( "-background" => "SystemButtonFace" );
}

#Fuction Set all Buttons into Inactive State
sub Set_Inactive() {
	$Button_Browse_open_file->configure( "-state" => "disabled" );
	$Button_Browse_Save_file->configure( "-state" => "disabled" );
	$Button_Save_Curve->configure( "-state" => "disabled" );
	$Button_Load_curve->configure( "-state" => "disabled" );
	$Button_create_graph->configure( "-state" => "disabled" );
	$Button_Off->configure( "-state" => "disabled" );
	$Button_On->configure( "-state" => "disabled" );
	$Button_Run_Curve->configure( "-state" => "disabled" );
	$Button_Run_Curve_trigger->configure( "-state" => "disabled" );
	$Button_Save_Ramp->configure( "-state" => "disabled" );
	$Button_Load_Ramp->configure( "-state" => "disabled" );
	$Button_create_Rampgraph->configure( "-state" => "disabled" );
	$Button_Download_Ramp->configure( "-state" => "disabled" );
	$Button_Browse_open_ramp->configure( "-state" => "disabled" );
	$Button_Browse_Save_ramp->configure( "-state" => "disabled" );
	$Box_Settings->configure( "-background" => "grey" );
	$Box_Save->configure( "-background" => "grey" );
	$Box_Load->configure( "-background" => "grey" );
	$Box_Run->configure( "-background" => "grey" );
	$Box_Ramps->configure( "-background" => "grey" );
}

#Fuction to check if the ramp values are valid
sub check_ramp() {

	# @Vstart,@Vend,@time,@samples

	$current_ramp_lenght = 0;
	my $samplecount = 0;
	for ( $count = 0 ; $count < $Rampcount ; $count++ ) {

		# first invalid entry ends curve
		if ( $samples[$count] <= 0 or $time[$count] <= 0 ) {
			$current_ramp_lenght = $count;
			last;
		}
	}

	#w2log("current_ramp_lenght $current_ramp_lenght\n");

	if ( $current_ramp_lenght <= 0 ) {
		$display_txt = "Ramps must have at least one valid entry";
		w2log("$display_txt\n");
		return 0;
	}

	for ( $count = 0 ; $count < $current_ramp_lenght ; $count++ ) {

		# first invalid entry ends curve
		if ( $samples[$count] <= 1 or $time[$count] <= 0 ) {
			$display_txt = "$count. samples ($samples[$count]) must be > 1 and time ($time[$count]) must be > 0!";
			w2log("$display_txt\n");
			return 0;
		}
		if ( $time[$count] / $samples[$count] < 0.2 ) {
			$display_txt = "$count. timedelta time/samples (" . $time[$count] / $samples[$count] . ") must be >= 0.2 ms!";
			w2log("$display_txt\n");
			return 0;
		}
		if ( $time[$count] / $samples[$count] > 100000 ) {
			$display_txt = "$count. timedelta time/samples (" . $time[$count] / $samples[$count] . ") must be <= 100 s!";
			w2log("$display_txt\n");
			return 0;
		}

		$samplecount += $samples[$count];

	}

	return 1;
}

##################################
# Logfile handling
##################################
sub w2log {
	my $text = shift;
	print LOG $text;
	print $text;
}

=head1 usage

GUI for Toellner power supply TOE8805/TOE8815, TOE8871 and TOE8952 using LIFT_TOELLNER.

first of all you have to connect to the device you want to control. For Toellner only GPIB is implemented. Edit the GPIB address according to your device settings.

Press CONNECT button before any other action.

to load a curve just select the file with 'Browse open file' button and press 'load CURVE' button.

to save a curve just select the file with 'Browse save file' button, change start and end points if required and press 'save CURVE' button.

to create graph from a curve file just select the file with 'Browse open file' button and press 'create graph' button.

to set a voltage just change voltage value and press 'ON' button, this will switch on with given voltage (works also to change voltage if was already ON before)

ON and OFF will set output to on or off

'run CURVE' button will run curve in memory with given settings (repetition 0 means infinite)

'run CURVE on trigger' button will run curve in memory with given settings (repetition 0 means infinite) if a HW trigger (rising TTL) is detected on pin 12

a logfile will be written containing all actions.

for non-arbitrary devices only limites functionality is enabled

---

curve files:

B<NOTE>: the TOE8805/TOE8815 device only supports up to 1000 points in memory, if you have more points you have to split in several files and run seperately

---

you can just run .sat files directly which are created by RB_RVT_levels or used in RB_voltage_file.par

to create a curve via .sat file manually file you can use either german header

    e.g.
    Dateiname:       C:/LIFT/LIFT_tools/Toellner_GUI/SUR_2V_10V_10min.sat
    Punkte:          1000
    Strombegrenzung: 5.00
    Wiederholungen:  1

or english header

    e.g.
    File name           : C:/LIFT/LIFT_tools/Toellner_GUI\seq_1305277995.sat
    Points              : 38
    Current Limitations : 4.00
    Repetitions         : 3

do not change the header names since they will be parsed!

the curve data is just listed in 2 columns where each line defines a point in Toellner memory 

    e.g.:
    U[V]   t[s]
    7.195     2.3520
    0.000     6.8850
    8.087     9.4850
    0.000     6.5400
    5.275     0.3000

    this will set 7.195 V for 2.352 seconds, 0 V for 6.885 seconds and so on

to create a curve via .sat from B<MLC_on_off_sequence.par> please use B<PAR2SAT.pl>

B<NOTE>: since the accuracy of Toellner is higher than of MLC you might not get always the expected results.

---

to create a curve via ramps you can define each ramp seperately with start and end voltage, duration and samples in Toellner memory.

you can load and save ramps in the same format as RB_voltage_ramps parameters (.txt recommended). NOTE: only one set should be in the file. 

to load a ramp just select the file with 'Browse open ramps' button and press 'load CURVE' button.

to save a ramp just select the file with 'Browse save ramps' button, change start and end points if required and press 'save CURVE' button.

to create graph from ramps just select the file with 'Browse save ramps' button and press 'create RAMPS graph' button.

    e.g.
    Vstart      = @(12.0, 5.0)
    Vend        = @(5.0,  3.0)
    Time_ms     = @(600000, 36000000)
    points      = @(100,  900)

repetition default is 0.

you can even use a copy of one parameter set from RB_voltage_ramps.par since this has the same format:

    [RB_voltage_ramps.pyramid_0_18_10s]
    purpose     = 'pyramid 0 to 18 V in 10 sec'
    Vstart      = @(0.0, 18.0)
    Vend        = @(18.0,  0.0)
    Time_ms     = @(10000, 10000)
    points      = @(500,  500)
    FLTopt     = @('FltVbatLow','FltVbatHigh')
    repetition  = 10

    here the heading, purpose and FLTopt will be ignored

after loading or creating ramp you have to download to device via button and use 'run CURVE' button (or 'run CURVE on trigger') to start

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, Toellner manual.

=cut
