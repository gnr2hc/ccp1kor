More infos at:
https://inside-docupedia.bosch.com/confluence/display/aeos/BSI
