#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################

use Tk;
use strict;
use Win32::OLE;
use File::Path;
use Getopt::Long;
use Data::Dumper;

my $Toolversion = "map_TSG4_harness ($VERSION)";      # Tool version number

my $mapfile_rack = 'TSG4_Harness_Mapping.txt';

my ($line,  %rack_pins, %ext_pins);

# key = pinname, val = [TSG4 labels]
open ( IN,"<$mapfile_rack" ) or die "Couldn't open $_ : $@";
  while ($line = <IN>){
    if ($line =~ /^\s*\w+_X-SG/){
    chomp($line);
      my @cols = split(/;/,$line);
      my $key = shift(@cols);
      foreach my $label (@cols){
      	push(@{$rack_pins{$key}},$label) if defined $label;
      }
    }
  }
close (IN);



my $scan_file;
my ( $main, $ValueFrame, $WarningFrame, $SettingFrame1, $SettingFrame2, $ButtonFrame, $ValueEntry, $display_txt);

my $sheet_number = 1;
my $start_line = 9;
my $pin_col = "A";
my $label_col = "C";
my $target_col = "F";
my $lastline = 1000;

#$scan_file = "./MQB_A0_Low_TSG4_Wizard_Config_V2.xlsx";
my $sheet_name;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "map_TSG4_harness $VERSION" );

# create frame 'ValueFrame' in window 'main'
$ValueFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'WarningFrame' in window 'main'
$WarningFrame = $main -> Frame() -> pack( "-pady" => 10 );

# create frame 'SettingFrame1' in window 'main'
$SettingFrame1 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'SettingFrame2' in window 'main'
$SettingFrame2 = $main -> Frame() -> pack( "-pady" => 5 );

# create frame 'ButtonFrame' in window 'main'
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create label in window 'ValueWindow'
$ValueFrame -> Label( "-text" => "file: ", )
            -> pack( "-side" => 'left', );

# create entry 'ValueEntry' in 'ValueFrame'
$ValueEntry = $ValueFrame -> Entry(
            "-width" => 50,
            "-textvariable" => \$scan_file, #reference to $prj_id
            );
$ValueEntry -> pack( "-side" => 'left', );

          # create 'browse file' button
          $ValueFrame -> Button
            (
            "-text" => "Browse file",
            "-command" => sub
              {
                      # browse for file
                      $scan_file = $main -> getOpenFile
                        (
                        "-filetypes"  =>
                          [
                          ["XLSX files", '.xlsx'],
                          ["XLS files", '.xls'],
                          ["All files", '.*']
                          ],
                        "-title"      => "choose one of the files to scan (*.xls)",
                        );
                      # if a file was chosen
                      if ( $scan_file )
                        {
                        #extract directory
                        print "\n $scan_file was chosen\n";
                        }
                      else
                        {
                          print "no filename!\n";
                          # prompt user
                          $main->messageBox(
                              '-icon'    => "error",#qw/error info question warning/
                              '-type'    => "OK",#qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                              '-title'   => 'Attention',
                              '-message' => "!Please select file first!"
                          );


                       }
              },
            )
              -> pack ("-padx" => 5,);

# create label in 'WarningFrame'
$WarningFrame -> Label( "-text" => "change defaults only if necessary :",
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );


# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "start line: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$start_line, #reference to $start_line
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   columns for pin: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$pin_col, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   label: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$label_col, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame1'
$SettingFrame1 -> Label( "-text" => "   target: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame1'
$SettingFrame1 -> Entry(
            "-width" => 4,
            "-textvariable" => \$target_col, #reference
            )-> pack( "-side" => 'left', );


# create label in 'SettingFrame2'
$SettingFrame2 -> Label( "-text" => "   last line: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame'2
$SettingFrame2 -> Entry(
            "-width" => 10,
            "-textvariable" => \$lastline, #reference 
            )-> pack( "-side" => 'left', );

# create label in 'SettingFrame2'
$SettingFrame2 -> Label( "-text" => "   sheet number: ", )
            -> pack( "-side" => 'left', );
# create entry 'ValueEntry' in 'SettingFrame2'
$SettingFrame2 -> Entry(
            "-width" => 3,
            "-textvariable" => \$sheet_number, #reference 
            )-> pack( "-side" => 'left', );



# create 'exit' button
$ButtonFrame -> Button
  (
  "-text" => "E X I T",
  "-command" => sub
    {exit}
  )
-> pack ("-side" => 'left',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);


# create 'create' button
$ButtonFrame -> Button
  (
  "-text" => "DO_MAPPING",
  "-command" => sub
    { # execute when button is pressed  
        if ($scan_file) { # create project if scan_file was given
        map_labels($scan_file);
        $scan_file = ""; # set scan_file to undefined

        }
        else{
        # prompt user if project_id is undefined
            $main->messageBox(
                '-icon'    => "error", #qw/error info question warning/
                '-type'    => "OK", #qw/AbortRetryIgnore OK OKCancel RetryCancel YesNo YesNoCancel/
                '-title'   => 'Attention',
                '-message' => "!Please select file first!"
            );


        }
    
    }
  )
-> pack ("-side" => 'right',"-ipadx" => 20,"-ipady" => 20,"-pady" => 30,"-padx" => 30);

# create label in window 'main'
$main -> Label( "-textvariable" => \$display_txt, #reference to $display_txt
                "-font" => "{MS Sans Serif} 10 bold",
         )
      -> pack( "-pady" => 10 );






#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">map_TSG4_logfile.txt" ) or die "Couldn't open map_TSG4_logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

w2log (" MAPPING : \n\n");
$Data::Dumper::Indent = 1;
$Data::Dumper::Sortkeys = 1;
$Data::Dumper::Varname = "rack";

w2log (Dumper(\%rack_pins)."\n");

w2log (" END OF MAPPING : \n\n");

# run with CLI
GetOptions(
  'xls=s' => \$scan_file, 
  'sheet=s' => \$sheet_number,
  'start=i' => \$start_line,
  'pin=s' => \$pin_col,
  'label=s' => \$label_col,
  'target=s' => \$target_col,
  'end=i' => \$lastline,
);
if ($scan_file){ # source file
    w2log("running with CLI\n");
    map_labels($scan_file);
}
else{
  # if no options, run TK GUI
  w2log("running with TK\n");
  MainLoop;
}
w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++




###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################

sub map_labels
{
  my (@in_file, $line, $mask);
  my ($Excel, $workbook, $worksheet);
  
  my $scan_file = shift;
  w2log("\nscanning file: <$scan_file>\n\n");

  # get already active Excel application or open new
  # see C:/Perl/html/site/lib/Win32/OLE.html
  eval {$Excel = Win32::OLE->GetActiveObject('Excel.Application')};
  die "Excel not installed" if $@;
  unless (defined $Excel) {
      $Excel = Win32::OLE->new('Excel.Application', sub {$_[0]->Quit;})
              or die "Oops, cannot start Excel";
  }
  $Excel -> {Visible} = 1;

  # load wokbook and select worksheet
  w2log("opened excel: $Excel\n");
  $workbook = $Excel -> Workbooks -> Open("$scan_file");
  w2log("opened workbook $scan_file : $workbook\n");

  #workaround to open sheet by given number
  my $name;
  for (1..$workbook->Sheets->Count) {
  	$sheet_name=$workbook->Sheets($_)->Name;
  #    print "$_: <", $name, ">\n";
    last if ($sheet_number == $_);
  }

  $worksheet = $workbook -> Sheets("$sheet_name");
  w2log("opened worksheet $sheet_number $sheet_name : $worksheet \n");

  w2log("start line is: $start_line\n");
  w2log("last line is : $lastline\n");
  w2log("pin_col is: $pin_col\n");
  w2log("label_col is: $pin_col\n");
  w2log("target_col is: $target_col\n");

  my $text = $worksheet -> Cells(16, "$pin_col") -> {'Value'};


  my $TSG4_struct;
  
  # loop over selected lines
  foreach $line ($start_line .. $lastline){
    # if source _col contains value
    my $TSG4pin = $worksheet -> Cells($line, "$pin_col") -> {'Value'};
    if ($TSG4pin){
      w2log("value in line $line is: <$TSG4pin>\n");

      if (exists $rack_pins{$TSG4pin}){
      my @devices = @{$rack_pins{$TSG4pin}};

      # loop over all devices
      foreach my $device (@devices){

			  $worksheet -> Cells($line, "$target_col") -> {'Value'} = $device;
			  my $label = $worksheet -> Cells($line, "$label_col") -> {'Value'};
			  if (defined $label){
				  $label =~ s/[+-]$//; # remove sign at the end
				  if ($device =~ /^SQ/){
					  $TSG4_struct->{'SQUIBS'}{$device.'_Name'} = $label;
					  $TSG4_struct->{'SQUIBS'}{$device.'_Default'} = 2.2;
				  }
				  elsif ($device =~ /^BL/){
					  $TSG4_struct->{'BELT_LOCKS'}{$device.'_Name'} = $label;
					  $TSG4_struct->{'BELT_LOCKS'}{$device.'_Unit'} = 'R';
					  $TSG4_struct->{'BELT_LOCKS'}{$device.'_Default'} = 100;
				  }
				  elsif ($device =~ /^PSL/){
					  $TSG4_struct->{'POWER_SUPPLY_LINES'}{$device.'_Name'} = $label;
					  $TSG4_struct->{'POWER_SUPPLY_LINES'}{$device.'_Default'} = 'Ubat';
				  }
				  elsif ($device =~ /^PAS/){
					  $TSG4_struct->{'PAS_LINES'}{$device.'_Name'} = $label;
				  }
				  elsif ($device =~ /^CF/){
					  $TSG4_struct->{'CAN_FR'}{$device.'_Name'} = $label;
				  }
				  elsif ($device =~ /^KL/){
					  $TSG4_struct->{'K_LIN'}{$device.'_Name'} = $label;
				  }
				  elsif ($device =~ /^WL/){
					  $TSG4_struct->{'WARNING_LAMPS'}{$device.'_Name'} = $label;
				  }
			      w2log ("mapped $TSG4pin to $device with label $label\n");
				  
			  }
			  else{
				w2log ("mapped $TSG4pin to $device, no label\n");
			  }
		  
      } #END foreach $device
      }
      else {
      	w2log ("$TSG4pin not in mapping\n");
      }
    } #END if ($TSG4pin)
  } #END foreach $line

  undef $workbook;
  undef $Excel;

 
open (FILE,">TSG4_harness_const.txt") or warn "could not write TSG4_const: $@\n";

print FILE"add to projects default section and change values if required:\n\n";

$Data::Dumper::Indent = 1;
$Data::Dumper::Sortkeys = 1;
$Data::Dumper::Varname = "TSG4_";

print FILE Dumper($TSG4_struct);

close(FILE);

  print"... done\n\n";
  $display_txt = "file <$scan_file> scanned";
}


##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

small script to map TSG4 harness labels created by wizard to TSG4 devices

this tool promts user for <excel_file> which needs pin in B_X-SG1 format (wizard harness description)

reads map_file TSG4_Harness_Mapping.txt

scan labels from start_line to last_line 
 if pin exists in pin_col write corresponding label to target_col for cross check
 writes project const snippet for TSG4

since the mapping is ambigous all variants will be created (e.g. for PAS and BL)
please modify the created file according to your setup !

 sheet  - which sheet contains mapping information e.g. 1 (sheet number !)
 start  - at which line does the mapping start (usually for jack 1) e.g. 7
 pin    - which column contains the Wiring (like B_X-SG1/c2) information e.g. "B"
 label  - which column contains the project label (like AB1FD) information e.g. "E"
 target - to which column to write the TSG4 device names for cross check e.g. "S"

by modifying default settings you can adapt tool for your sheet layout

CLI: map_TSG4_harness.pl --xls [file] --start [line] --end [line] --pin [col] --label [col] --target [col] --sheet [number]
e.g. map_TSG4_harness.pl --xls C:\_work_\MQB_A0_Low_TSG4_Wizard_Config_V2.xlsx --start 20 --end 30 --pin B --label C --target F --sheet 3

     map_TSG4_harness.pl --xls C:\_work_\MQB_A0_Low_TSG4_Wizard_Config_V2.xlsx will use default values

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut