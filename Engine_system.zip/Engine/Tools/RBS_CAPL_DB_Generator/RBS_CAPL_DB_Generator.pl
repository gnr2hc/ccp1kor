use strict;
use warnings;
use Data::Dumper;
use Time::HiRes;
use File::Path qw( make_path );

#----------------------------
my $MsgsSignals_href ;
my $msgSignals_Database = {};
my $lastMsg_Read_DB = undef;
my $CAPLCode = {};
my @cinBuf2Wr_Msgs;
my @cinBuf2Wr_timers;
#--------- for Dbc file ------------------
my @DBCBuf2Wr_intVar;
my @DBCBuf2Wr_floatVar;


#----------------------------
# generate CAPL & Database ".dbc"
#----------------------------
Intro_Tool();
BlockCode_generateCAPL();
#wr2CAPLBuffer_printHash();


sub Intro_Tool {

	print "\n";
	print " *****************************************************  \n";
	print " ** TOOL to Generate the CAPL & Database file 		   \n";
	print " *****************************************************  \n\n";

	if ( length $ARGV[0] == 0 ) {
		print " -> ERROR : No input '*.dbc' file has been passed. <-\n";
		print "    Please pass 1st command line argument as .dbc for which CAPL & database of Environment varaibales has to be generated.\n\n\n";
		exit;
	}
	else {
		print " --> Input database '*.dbc' passed  is =  '$ARGV[0]'\n\n";
	}

	print " Press Enter to continue :   \n";
	<STDIN>;

	return 1;
}

#------------------------------
# Get Messages and signals from Database
#------------------------------  
sub GetMsgandSignals {
	my @args     = @_;
	my $filename = shift @args;

	open( my $fh, '<', $filename );

	my $cnt = 0;
	while ( my $row = <$fh> ) {
		chomp $row;

		#BO_ 180 VSC1S03: 8 ABS
		if (
			$row =~ m/^
 			BO_    # BO_ keyword
			\s+    # some white char
			\d+    # match BOTSCHAFTS ID
			\s+    # some white char
			(\w+)  # match BOTSCHAFTS NAME
			/x
		  )
		{
			$msgSignals_Database->{$1} = undef;
			$lastMsg_Read_DB = $1;
		}

		# SG_ SP1 : 47|16@0+ (1,0) [0|0] ""  ABG
		if (
			$row =~ m/^ 
		   \s+    # some white char
           SG_    # match the KEY
           \s+    # some white char
           (\w+)  # match the NAME
           \s*    # maybe some white char
			/x
		  )
		{
			push @{ $msgSignals_Database->{$lastMsg_Read_DB} }, $1;
		}
	}

	close ($fh) ;
	return 1;
}



sub BlockCode_generateCAPL {

	# delete all the files, before existing in this directory
	unlink glob "./nodes/*.can";
	unlink glob "./nodes/*.cin";
	unlink glob "./db/NodeDatabase.dbc";

	## input :-
	# messages & signals for which CAPL, dbc has to be generated.

	GetMsgandSignals( $ARGV[0] );    #take database as an input
	parseMsgSignlas();
	print_input_MsgSignals();

	foreach my $msg_nameDB ( keys %$MsgsSignals_href ) {
		my $file_name;
		my $msgInstance      = "MSG_" . $msg_nameDB;
		my $EnvMsgStart_Stop = "Env" . $msg_nameDB . "To_";
		my $timer_name_msg   = "T_$msgInstance";

		print " -> CAPL code & Env varaibales will be generted for Message => $msg_nameDB *** \n\n";

		$file_name = "$MsgsSignals_href->{$msg_nameDB}{'FileName'}.can";
		wr2CAPLBuffer_setCAPLFileNames_Mgsdb( $file_name, $msg_nameDB );

		## --------------------------------------
		#  for Header section
		## --------------------------------------
		my $text = "includes \n" . "{\n" . "#include \"NodeLibrary.cin\"\n" . "}";
		wr2CAPLBuffer_setCAPL_HeaderInclude( $file_name, $text );

		## --------------------------------------
		#  for CIN file writing
		## --------------------------------------
		wr2CinBuffer_msgs("Message $msg_nameDB		$msgInstance;");
		wr2CinBuffer_timers("mstimer 	$timer_name_msg;");

		## --------------------------------------
		#  for CAPL file writing
		## --------------------------------------
		wr2CAPLBuffer_setCAPL_OnTimerEvent_Header( $file_name, $msg_nameDB, "\non timer T_MSG_$msg_nameDB \n{" );		
		
		my $EnvNameDlc = "Env" . $msg_nameDB . "Dlc_";
		wr2DbcBuffer_IntVar($EnvNameDlc);

		my $signals_name_aref = $MsgsSignals_href->{$msg_nameDB}{'Signals'};
		blockCode_setSignalValue( $file_name, $msg_nameDB, $signals_name_aref );
		blockCode_Enable_DiableMsg( $file_name, $msg_nameDB );

		my $EnvNameCycleTime = "Env" . $msg_nameDB . "Time_";
		
		wr2CAPLBuffer_setCAPL_onStartEvent_setCyclicTimes( $file_name, "settimer($timer_name_msg, getvalue($EnvNameCycleTime));" );
		
		#wr2CAPLBuffer_setCAPL_onStartEvent_CycleTime( $file_name, "putvalue($EnvNameCycleTime, $msgInstance.CycleTime);" );
		wr2CAPLBuffer_setCAPL_onStartEvent_CycleTime( $file_name, "putvalue($EnvNameCycleTime, $msgInstance.GenMsgCycleTime);" );
		
		wr2CAPLBuffer_setCAPL_onStartEvent_Dlc( $file_name, "putvalue($EnvNameDlc, $msgInstance.Dlc);" );
		wr2CAPLBuffer_setCAPL_onStartEvent_setEnvTrue( $file_name, "putvalue ( $EnvMsgStart_Stop, 1 );" );

		wr2DbcBuffer_IntVar($EnvNameCycleTime);

		Time::HiRes::sleep(0.250);    #.1 seconds
	}

	## Create CAPL file
	write_CAPL_file();

	## Create CIN file
	write_cin_file();

	## Create database file
	Write_dbc_file();

	return 1;
}



# - Enable & Disable Messages Block code
sub blockCode_Enable_DiableMsg {

	my @args        = @_;
	my $fileName    = shift @args;
	my $msg_name_db = shift @args;

	my $msgInstance      = "MSG_$msg_name_db";
	my $EnvNameStartMsg  = "Env" . $msg_name_db . "To_";
	my $EnvNameCycleTime = "Env" . $msg_name_db . "Time_";
	my $EnvNameDlc 		 = "Env" . $msg_name_db . "Dlc_";

	wr2DbcBuffer_IntVar($EnvNameStartMsg);

	my $txt2Buffer;      
    $txt2Buffer = "\n\t/*  Output  */"												."\n".
				 "\t".  "\n\t$msgInstance.Dlc = getvalue ( $EnvNameDlc);"				."\n".
				 "\t".   " "  										                ."\n".
				 "\t".  "if(getvalue($EnvNameStartMsg))"							."\n".
                 "\t".  "{"															."\n".
				 "\t".  "\toutput($msgInstance);"									."\n".
				 "\t".  "}"															."\n".
				 "\t".  "else"														."\n".
				 "\t".  "{"															."\n".
				 "\t".  "\tWrite(\"$msg_name_db Message is not sent \");"	        ."\n".
				 "\t".   "}"											            ."\n".
				 "\t".   " "  										                ."\n".
				 "\t".   "settimer(T_$msgInstance,  getvalue($EnvNameCycleTime));"  ."\n".
				 "\t".   " "												        ."\n"
				 ;
				 
						 
    wr2CAPLBuffer_setCAPL_OnTimerEvent_EnableDisaleMsg ($fileName, $msg_name_db, $txt2Buffer);				  
    return 1;
}

# - Set signal Block code
sub blockCode_setSignalValue {

	my @args            = @_;
	my $file_name       = shift @args;
	my $msg_DB_name     = shift @args;
	my $signals_DB_name = shift @args;

	my $msgInstance = "MSG_$msg_DB_name";

	foreach my $signal_DB_name (@$signals_DB_name) {
		my $EnvNameSignal = "Env" . $signal_DB_name . "_";
		my $signalText    = "\t" . "$msgInstance" . ".$signal_DB_name = getvalue ( $EnvNameSignal);";
		wr2CAPLBuffer_setCAPL_OnTimerEvent_setSignal( $file_name, $msg_DB_name, $signalText );
		wr2DbcBuffer_floatVar($EnvNameSignal);
	}

	return 1;
}



sub print_input_MsgSignals {

	print " ** Input messages and signals for which CAPL & DB has to be generated **  \n";

	foreach my $msg_nameDB ( keys %$MsgsSignals_href ) {

		if ( defined $msg_nameDB ) {
			if ( defined @{ $MsgsSignals_href->{$msg_nameDB}{'Signals'} } ) {
				print "$msg_nameDB :- 	@{$MsgsSignals_href->{$msg_nameDB}{'Signals'}} \n\n";
			}
		}
	}
	print "\n\n";

	return 1;
}


#----------------------------
# Helper functions
#----------------------------
sub openFile {

	my @args     = @_;
	my $fileName = shift @args;
	print "opening file : $fileName \n";
	open( my $file_handle, ">>", $fileName ) or die $!;    ## open in append mode
	return $file_handle;
}

sub parseMsgSignlas {

	foreach my $msg ( keys %{$msgSignals_Database} ) {
		$MsgsSignals_href->{$msg}{'Signals'} = $msgSignals_Database->{$msg};

		#$MsgsSignals_href->{$msg}{'FileName'} 	=  substr($msg, 0, 3);
		$MsgsSignals_href->{$msg}{'FileName'} = 'MSG_SIGNALS';
	}
}

sub wr2CAPLBuffer_printHash {
	my @args       = @_;
	my $onStartTxt = shift @args;

	foreach my $file ( @{ $CAPLCode->{'CAPL_FileNames'} } ) {
		print "File name is = $file \n";
		print "SetTimertext -: \n @{$CAPLCode->{$file}{'onStartEvent'}{'setCyclicTimes'}} \n";
		print "CycleTime - :\n @{$CAPLCode->{$file}{'onStartEvent'}{'CycleTime'}} \n";
		print "Dlc - :\n @{$CAPLCode->{$file}{'onStartEvent'}{'Dlc'}} \n";
		print "setEnvTrue - :\n @{$CAPLCode->{$file}{'onStartEvent'}{'setEnvTrue'}} \n";
		print "Msg DB for $file are - : @{$CAPLCode->{$file}{'MSGs'}} \n";
	}
}

sub wr2CAPLBuffer_setCAPL_HeaderInclude {
	my @args              = @_;
	my $CAPL_fileName     = shift @args;
	my $HeaderIncludeText = shift @args;
	$CAPLCode->{$CAPL_fileName}{'HeaderInclude'} = $HeaderIncludeText . "\n";

}

sub wr2CAPLBuffer_setCAPL_OnTimerEvent_Header {

	my @args          = @_;
	my $CAPL_fileName = shift @args;
	my $msgName_db    = shift @args;
	my $timerHeader   = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{$msgName_db}{'OnTimerEvent'}{'Header'} }, $timerHeader . "\n";
}

sub wr2CAPLBuffer_setCAPL_OnTimerEvent_setSignal {

	my @args          = @_;
	my $CAPL_fileName = shift @args;
	my $msgName_db    = shift @args;
	my $setSignalTxt  = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{$msgName_db}{'OnTimerEvent'}{'setSignal'} }, $setSignalTxt . "\n";
}

sub wr2CAPLBuffer_setCAPL_OnTimerEvent_EnableDisaleMsg {

	my @args               = @_;
	my $CAPL_fileName      = shift @args;
	my $msgName_db         = shift @args;
	my $EnableDisaleMsgTxt = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{$msgName_db}{'OnTimerEvent'}{'EnableDisaleMsg'} }, $EnableDisaleMsgTxt . "\n";
}

sub wr2CAPLBuffer_setCAPLFileNames_Mgsdb {
	my @args     = @_;
	my $fileName = shift @args;
	my $msg_db   = shift @args;

	push @{ $CAPLCode->{'CAPL_FileNames'} }, $fileName;
	push @{ $CAPLCode->{$fileName}{'MSGs'} }, $msg_db;
}

sub wr2CAPLBuffer_setCAPL_onStartEvent_CycleTime {
	my @args            = @_;
	my $CAPL_fileName   = shift @args;
	my $CycleTime = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{'onStartEvent'}{'CycleTime'} }, "\t" . $CycleTime . "\n";
}

sub wr2CAPLBuffer_setCAPL_onStartEvent_Dlc {
	my @args            = @_;
	my $CAPL_fileName   = shift @args;
	my $GenDlc		    = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{'onStartEvent'}{'Dlc'} }, "\t" . $GenDlc . "\n";
}

sub wr2CAPLBuffer_setCAPL_onStartEvent_setCyclicTimes {
	my @args           = @_;
	my $CAPL_fileName  = shift @args;
	my $setCyclicTimes = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{'onStartEvent'}{'setCyclicTimes'} }, "\t" . $setCyclicTimes . "\n";
}

sub wr2CAPLBuffer_setCAPL_onStartEvent_setEnvTrue {
	my @args          = @_;
	my $CAPL_fileName = shift @args;
	my $setEnvTrue    = shift @args;
	push @{ $CAPLCode->{$CAPL_fileName}{'onStartEvent'}{'setEnvTrue'} }, "\t" . $setEnvTrue . "\n";
}

sub write_CAPL_file {

	my %seen = ();
	my $dirPath;
	my @unique_CAPLFiles = grep { !$seen{$_}++ } @{ $CAPLCode->{'CAPL_FileNames'} };

	print "unique File name are : @unique_CAPLFiles \n";

	foreach my $file (@unique_CAPLFiles) {
		print "\n" . " ---------------------------------------------------  \n";
		print " Start writing to file ->  : ./nodes/$file \n";
		print " --------------------------------------------------- \n";

		my $FH_CAPL;

		$dirPath = "./nodes/";
		if ( !-d $dirPath ) {
			make_path $dirPath or die "Failed to create path: $dirPath";
		}
		$FH_CAPL = openFile("./nodes/$file");

		## on Header Event
		print $FH_CAPL ( $CAPLCode->{$file}{'HeaderInclude'} );

		## on start event
		print $FH_CAPL "on start\n";
		print $FH_CAPL "{\n";
		print $FH_CAPL @{ $CAPLCode->{$file}{'onStartEvent'}{'setEnvTrue'} };
		print $FH_CAPL "\n\n";
		print $FH_CAPL @{ $CAPLCode->{$file}{'onStartEvent'}{'CycleTime'} };
		print $FH_CAPL "\n\n";
		print $FH_CAPL @{ $CAPLCode->{$file}{'onStartEvent'}{'Dlc'} };
		print $FH_CAPL "\n\n";
		print $FH_CAPL @{ $CAPLCode->{$file}{'onStartEvent'}{'setCyclicTimes'} };
		print $FH_CAPL "\n}";

		## on Timer Event
		foreach my $msgs ( @{ $CAPLCode->{$file}{'MSGs'} } ) {
			print $FH_CAPL @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'Header'} }          if defined @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'Header'} };
			print $FH_CAPL @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'setSignal'} }       if defined @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'setSignal'} };
			print $FH_CAPL @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'EnableDisaleMsg'} } if defined @{ $CAPLCode->{$file}{$msgs}{'OnTimerEvent'}{'EnableDisaleMsg'} };
			print $FH_CAPL "}";
		}

		close $FH_CAPL;
		print "done .. writing to file ->  : ./nodes/$file \n \n";
	}

	return 1;
}
 
 
 
# ------------------------------
## CIN file
# -----------------------------------
sub wr2CinBuffer_msgs {
	my @args    = @_;
	my $txtMsgs = shift @args;
	push @cinBuf2Wr_Msgs, "\t" . $txtMsgs . "\n";
}

sub wr2CinBuffer_timers {
	my @args      = @_;
	my $txtTimers = shift @args;
	push @cinBuf2Wr_timers, "\t" . $txtTimers . "\n";
}

sub write_cin_file {

	print "\n" . " ---------------------------------------------------  \n";
	print " Start writing to file ->  : ./nodes/NodeLibrary.cin \n";
	print " --------------------------------------------------- \n";

	my $FH_Cin;
	$FH_Cin = openFile("./nodes/NodeLibrary.cin");

	print $FH_Cin "variables\n";
	print $FH_Cin "{\n";

	print $FH_Cin @cinBuf2Wr_Msgs;
	print $FH_Cin "\n\n";
	print $FH_Cin @cinBuf2Wr_timers;

	print $FH_Cin "\n}";
	close $FH_Cin;
	print "done .. writing to file ->  : ./nodes/NodeLibrary.cin \n";

	return 1;
}

# ------------------------------
## Dbc file Buffers
# -----------------------------------

sub wr2DbcBuffer_IntVar {
	my @args   = @_;
	my $intVar = shift @args;
	push @DBCBuf2Wr_intVar, "EV_ $intVar: 0 [0|0] \"\" 0 1 DUMMY_NODE_VECTOR0 Vector__XXX;\n";
}

sub wr2DbcBuffer_floatVar {
	my @args     = @_;
	my $floatVar = shift @args;
	push @DBCBuf2Wr_floatVar, "EV_ $floatVar: 1 [0|0] \"\" 0 1 DUMMY_NODE_VECTOR0 Vector__XXX;\n";
}

## ------------------------
#  Write to the dbc file
## ------------------------
sub Write_dbc_file {
	my $FH_dbc;
	print "\n" . " ---------------------------------------------------  \n";
	print " Start writing to file ->  : ./db/NodeDatabase.dbc \n";
	print " --------------------------------------------------- \n";

	my $dirPath = "./db/";
	if ( !-d $dirPath ) {
		make_path $dirPath or die "Failed to create path: $dirPath";
	}

	$FH_dbc = openFile("./db/NodeDatabase.dbc");

	print $FH_dbc "VERSION \"\"\n\n\n";
	print $FH_dbc "NS_ : \n";
	print $FH_dbc "BS_: \n";
	print $FH_dbc "BU_: \n";
	print $FH_dbc @DBCBuf2Wr_intVar;
	print $FH_dbc @DBCBuf2Wr_floatVar;

	close $FH_dbc;
	print "done .. writing to file ->  : ./db/NodeDatabase.dbc \n";

	return 1;
}



