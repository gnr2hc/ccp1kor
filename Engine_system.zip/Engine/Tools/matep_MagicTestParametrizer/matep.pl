#!usr\bin\perl.exe -w
# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#    $Source: Tools/matep_MagicTestParametrizer/matep.pl $
#    $Revision: 1.2 $
#    $State: develop $
#******************************************************************************************************

use strict;
use Getopt::Long;
use Cwd;
use Win32::OLE;
use File::Basename;
use File::Find;
use File::Path;
use Data::Dumper;

###------------------------------------------------------------------
### VARIABLES OF MAIN
###------------------------------------------------------------------
use vars qw( $VERSION $HEADER );
# next 2 lines edited by CVS, DO NOT MODIFY
$VERSION = q$Revision: 1.2 $;

###############################################################################
our ( 
        $opt_infile , 
        $opt_worksheet , 
        $opt_parfilesfolder ,  
        $opt_testlist ,  
        $opt_logfile ,
        $opt_MATDNC_FMVSS ,
     );
     
my (
    $used_infile ,
    $used_worksheet ,
    $used_parfilesfolder ,
    $used_testlist ,
    $ExcelApplication ,
    $ExcelWorkbook ,
    $Xls_Worksheet_Tests ,
    $excel_was_closed_flag ,
    $table_content ,
    $TcParFileConfig ,
    $used_parfilesfolder ,
    $log_file ,
    );

    use constant max_col => 100;   # MAX is 255 !!
    use constant max_row => 5000;
    
##################################
### START OF MAIN
##################################

    GetOptions(
                "infile=s",
                "worksheet=s",
                "parfilesfolder=s",
                "testlist=s",
                "MATDNC_FMVSS:i",   # optional
                #- - - - - - - - - 
                "logfile=s" ,
                );
    
    if( $opt_logfile ) { 
        $log_file = $opt_logfile; 
    } else { 
        $log_file = "./log_file.txt";
    }

    if( $opt_infile ) { 
        $used_infile = $opt_infile; 
        if( basename($used_infile) eq $used_infile ) {
            $used_infile = cwd."/".$used_infile;
        }
    } else { 
        $used_infile = FindNewestXls(); 
    }
    
    if( $opt_worksheet ) {
        $used_worksheet = $opt_worksheet;
    } else {
        $used_worksheet = 'Tests';
    }
    
    if( $opt_parfilesfolder ) {
        $used_parfilesfolder = $opt_parfilesfolder;
    } else {
        $used_parfilesfolder = cwd."/STEPS_par_files/";
    }
    
    if( $opt_testlist ) {
        $used_testlist = $opt_testlist;
    } else {
        $used_testlist = $used_parfilesfolder."generated_TL.txt";
    }
        
    
    print( "\n MAIN: Starting $0 ... \n\n" );

    open ( LOG , ">$log_file" ) || die "Opening logfile '$log_file'";

    $excel_was_closed_flag = 0;
    print_log ( "Trying to get Excel : Win32::OLE->GetActiveObject('Excel.Application')\n" );
    $ExcelApplication = Win32::OLE->GetActiveObject('Excel.Application');
    unless( defined $ExcelApplication ) {
        $excel_was_closed_flag = 1;
        print_log ( "Could not : Win32::OLE->GetActiveObject('Excel.Application'); -> Create new\n" ); 
        $ExcelApplication = Win32::OLE->new('Excel.Application', 'Quit');
        unless ( defined $ExcelApplication ) {
            print_log ( "Could not : Win32::OLE->new('Excel.Application', 'Quit'); -> Exit\n" ); 
            exit(0);
        }
    }

    

    print_log ( "Opening Workbook : $used_infile..\n" );
    $ExcelWorkbook = $ExcelApplication -> Workbooks -> Open( $used_infile );
    unless( defined $ExcelWorkbook ) { print_log ( "Could not : Excel -> Workbooks -> Open( $used_infile ) -> Exit\n" ); exit(0); }

    print_log ( "Opening Worksheet : '$used_worksheet'..\n" );
    $Xls_Worksheet_Tests = $ExcelWorkbook -> Worksheets( $used_worksheet );
    unless( defined $Xls_Worksheet_Tests ) { print_log ( "Could not : Xls_Worksheet_Tests = $ExcelWorkbook -> Worksheets('Tests') -> Exit\n" ); exit(0); }
    $table_content = ReadTestTable( $Xls_Worksheet_Tests );
    dump_log( " ReadTestTable : table_content" , $table_content );
    $ExcelWorkbook -> Close if $excel_was_closed_flag;


    $TcParFileConfig = SetupParFileConfig( $table_content );
    $TcParFileConfig = MATDNC_FMVSS_postprocessing ( $TcParFileConfig ) if ($opt_MATDNC_FMVSS == 1);
#     dump_log( "TcParFileConfig" , $TcParFileConfig );

    CreateTargetPath( $used_parfilesfolder );
    
    WriteParFiles( $TcParFileConfig , $used_parfilesfolder );

    WriteTestlist( $table_content , $used_testlist );

    print( " MAIN: END \n" );

    close LOG;

exit(0);

##################################
### END OF MAIN
##################################


###############################################################################

###----------------------------------------------------------------------------
sub WriteTestlist {
###----------------------------------------------------------------------------
    my $table_content = shift;
    my $testlist_name = shift;
        
    unless( -d dirname $testlist_name ) {
        unless ( mkpath( dirname $testlist_name ) ) { print_log( " ERROR : Creating Path '".dirname $testlist_name."' .. \n" ); return }
    }
    
    print_log( "\n WriteTestlist : Writing '$testlist_name' .. \n" );
    unless( open( TL , ">$testlist_name" ) ) { print_log( " ERROR : Opening '$testlist_name' .. \n" ); return }
    print TL "# Generated Testlist from matep-tool (".localtime(time).")\n\n";
    foreach ( sort{$a<=>$b} keys %$table_content ) {
        print TL $table_content->{$_}{'TC_ID'}."\n";
    }
    close TL;
    return 1;
}


###----------------------------------------------------------------------------
sub WriteParFiles {
###----------------------------------------------------------------------------
    my $TcParFileConfig = shift;
    my $used_parfilesfolder = shift;
    
#                 $TcParFileConfig->{$tc_par_file}{$tc_cnt}{$tc_par_set_name}{'SCALAR'} = $tc_par_value;

    my ( 
        $tc_par_file ,
        $tc_par_file_long ,
        $tc_parset_cnt ,
        $tc_par_cnt ,
        $tc_par_set_name ,
        $tc_par_name ,
        $tc_par_value ,
        $tc_par_value_joined ,
        $created_par_sets ,
        $nbr_used ,
        $key , 
        $val , 
    );


    foreach $tc_par_file ( keys %$TcParFileConfig ) {
        $tc_par_file_long = $used_parfilesfolder.$tc_par_file;
        print_log( "\n WriteParFiles : Writing '$tc_par_file_long' .. \n" );
        unless( open( PAR_FILE , ">$tc_par_file_long" ) ) { print_log( " ERROR : Opening '$tc_par_file_long' .. \n" ); return }

        $tc_par_value_joined = ""; 
        $tc_par_value_joined .= " '$_' ," foreach(keys %{$TcParFileConfig->{$tc_par_file}{'used_STEPS_CondParExt'}});
        chop $tc_par_value_joined; 
        print PAR_FILE "\n";
        print PAR_FILE "PROJECT_PARAMETER = @( $tc_par_value_joined )\n" if $tc_par_value_joined;
        print PAR_FILE "\n";
        
        foreach $tc_parset_cnt ( sort{$a<=>$b} keys %{$TcParFileConfig->{$tc_par_file}} ) {

            next unless $tc_par_set_name = $TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcParSet_Name'};

            if( $nbr_used = $created_par_sets->{$tc_par_set_name} ) {
                $nbr_used++; $created_par_sets->{$tc_par_set_name} = $nbr_used;
                print_log( " WriteParFiles : Steps_ParSet '$tc_par_set_name' used $nbr_used times .. no check implemented !! \n" );
                next;
            }
            
            print PAR_FILE "\n[$tc_par_set_name]\n";
            
            foreach $tc_par_cnt ( sort{$a<=>$b} keys %{$TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcPar'}} ) {

                next unless $tc_par_name = $TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'};
                $tc_par_value = $TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'SCALAR'};
                if( defined $tc_par_value ) {
                    print PAR_FILE "$tc_par_name = '$tc_par_value'\n";
                    next;
                }
                $tc_par_value = $TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'LIST'};
                if( defined $tc_par_value ) {
                    $tc_par_value_joined = ""; $tc_par_value_joined .= " '$_' ," foreach @$tc_par_value; chop $tc_par_value_joined; 
                    print PAR_FILE "$tc_par_name = @( $tc_par_value_joined )\n";
                    next;
                }
                                
                $tc_par_value = $TcParFileConfig->{$tc_par_file}{$tc_parset_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'HASH'};
                if( defined $tc_par_value ) {
                    $tc_par_value_joined = "";  
                    $tc_par_value_joined .= " '$key' => '$val' ," while( ( $key , $val  ) = each %$tc_par_value );
                    chop $tc_par_value_joined;
                    print PAR_FILE "$tc_par_name = %($tc_par_value_joined)\n";
                    next;
                }                               
            }
            $created_par_sets->{$tc_par_set_name} = 1;            
        } 
        
        close PAR_FILE;
        print_log( " WriteParFiles : Writing '$tc_par_file' .. done \n" );
    }    
    
    
    return 1;
}

###----------------------------------------------------------------------------
sub SetupParFileConfig {
###----------------------------------------------------------------------------
    my $table_content = shift;
    
    my ( 
         $TcParFileConfig ,
         $tc_cnt ,
         $tc_id ,
         $tc_par_cnt ,
         $tc_par_name ,
         $tc_par_value ,
         $tc_par_file ,
         $tc_par_set_name ,
         $STEPS_CondParExt ,
    );

    print( " SUB SetupParFileConfig ... \n" );
    
    foreach $tc_cnt ( sort{$a <=> $b} keys %$table_content ) {
        next unless $table_content->{$tc_cnt}{'STEPS_Par'};

        next unless $tc_id = $table_content->{$tc_cnt}{'TC_ID'};
        next unless $tc_par_set_name = $table_content->{$tc_cnt}{'STEPS_TcParSet_Name'};
        next unless $tc_par_file = $table_content->{$tc_cnt}{'STEPS_TcParFile'};

        $TcParFileConfig->{$tc_par_file}{$tc_cnt}{'STEPS_TcParSet_Name'} = $tc_par_set_name;
        if( $STEPS_CondParExt = $table_content->{$tc_cnt}{'STEPS_CondParExt'} ) {
            $TcParFileConfig->{$tc_par_file}{'used_STEPS_CondParExt'}{$STEPS_CondParExt}++; 
        }
        $table_content->{$tc_cnt}{'STEPS_CondParExt'} = $STEPS_CondParExt if $STEPS_CondParExt;
        
        foreach $tc_par_cnt( sort{$a <=> $b} keys %{$table_content->{$tc_cnt}{'STEPS_Par'}} ) {
            last unless $tc_par_name = $table_content->{$tc_cnt}{'STEPS_Par'}{$tc_par_cnt}{'STEPS_Par_NAME'};

            $tc_par_value = GetSingleTcPar( $table_content->{$tc_cnt}{'STEPS_Par'}{$tc_par_cnt} );
            unless( defined $tc_par_value ) {
                print_log( " Could not get STEPS parameter for : $tc_par_name (TC_ID : $tc_id) \n" );
                next;
            }

            $TcParFileConfig->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} = $tc_par_name;


            if( not ref $tc_par_value ) {
                $TcParFileConfig->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'SCALAR'} = $tc_par_value;
            }
            elsif( ref $tc_par_value eq 'ARRAY' ) {
                $TcParFileConfig->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'LIST'} = $tc_par_value;
            }
            elsif( ref $tc_par_value eq 'HASH' ) {
                $TcParFileConfig->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{'HASH'} = $tc_par_value;
            }
            else {
                print_log( " Undefined type of : $tc_par_name (TC_ID : $tc_id) \n" );
            }
        }        
    }    

    print( " SUB SetupParFileConfig ... done\n" );
    
    return $TcParFileConfig;
}

###----------------------------------------------------------------------------
sub MATDNC_FMVSS_postprocessing {
###----------------------------------------------------------------------------
    my $TcParFileConfig_upd = shift;
    
    my (
         $tc_par_file ,
         $tc_cnt ,
         $tc_cnt_mod ,
         $tc_par_set_name ,
         $tc_par_cnt ,
         $data_type ,
         $mep_usage_line ,
         $rb_mand_fault_line ,
         $cu_mand_fault_line ,
         $rb_opt_fault_line ,
         $cu_opt_fault_line ,
         $tc_par_cnt_max ,
         $tc_par_cnt_max_mod ,
         @rb_mandatory_faults ,
         @rb_mandatory_faults_1 ,
         @rb_disjunction_faults_2 ,
         @rb_mandatory_faults_3 ,
         @cu_mandatory_faults ,
         @rb_optional_faults_2 ,
         @rb_optional_faults ,
         @cu_optional_faults ,
         $tc_par_cnt_mod ,
         $tc_par_cnt_offset ,
         $bus_usage ,
         @rb_fault_eval_types ,
         $par_item ,
    );

    print( " SUB MATDNC_FMVSS_postprocessing ... \n" );

    foreach $tc_par_file ( keys %{$TcParFileConfig_upd} ){
            
        foreach $tc_cnt ( sort{$a <=> $b} keys %{$TcParFileConfig_upd->{$tc_par_file}} ){
            undef @rb_fault_eval_types;
            # create FMVSS parameter
            next if ( $tc_cnt =~ /used_STEPS_CondParExt/ );
            $tc_cnt_mod = "$tc_cnt"."_FMVSS";
            $tc_par_set_name = $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcParSet_Name'};
            $tc_par_set_name .= "_FMVSS";
            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcParSet_Name'} = $tc_par_set_name;
            $tc_par_cnt_max = 0;
            $tc_par_cnt_max_mod = 0;
            $mep_usage_line = 0;
            $tc_par_cnt_mod = 0;
            $tc_par_cnt_offset = 0;
            undef @rb_fault_eval_types;
            # pre-detection of fault evaluation type (mandatory, disjunction, optional faults)
            foreach $tc_par_cnt ( sort{$a <=> $b} keys %{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}} ){
                $par_item = $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'};
                push( @rb_fault_eval_types , $par_item ) if ( $par_item =~ /RB_.+_faults/g );
            }
            foreach $tc_par_cnt ( sort{$a <=> $b} keys %{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}} ){
                # copy existing lines into new parameter
                $tc_par_cnt_mod = $tc_par_cnt+$tc_par_cnt_offset;
                $rb_mand_fault_line = 0;
                $cu_mand_fault_line = 0;
                $rb_opt_fault_line = 0;
                $cu_opt_fault_line = 0;
                $mep_usage_line = $tc_par_cnt if ( $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} =~ /MEP_usage/g );
                $rb_mand_fault_line = $tc_par_cnt if ( $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} =~ /RB_mandatory_faults/g );
                $cu_mand_fault_line = $tc_par_cnt if ( $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} =~ /CU_mandatory_faults/g );
                $rb_opt_fault_line = $tc_par_cnt if ( $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} =~ /RB_optional_faults/g );
                $cu_opt_fault_line = $tc_par_cnt if ( $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'} =~ /CU_optional_faults/g );
                $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}";
                
                foreach $data_type ( keys %{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}} ){
                    if( $data_type =~ /HASH/ ) {
                        %{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = %{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                    }
                    elsif( $data_type =~ /LIST/ ){
                        if ( $rb_mand_fault_line != 0 ){
                            undef @rb_mandatory_faults_1;
                            undef @rb_disjunction_faults_2;
                            undef @rb_mandatory_faults_3;
                            # update rb mandatory faults
                            @rb_mandatory_faults = @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                            @rb_mandatory_faults_1 = map{$_ .= ":Set_Fault";}(@rb_mandatory_faults);    # add :Set_Fault
                            @rb_mandatory_faults_3 = map{$_ .= "_Good_Checked";}(@rb_mandatory_faults);   # add :Set_Fault_Good_Checked
                            # add Set_Fault_Restored
                            @rb_disjunction_faults_2 = @rb_mandatory_faults_1 if ( defined($rb_mandatory_faults_1[0]) );
                            foreach (@rb_mandatory_faults_1){
                                my $fault_temp = $_;
                                $fault_temp =~ s/\:Set_Fault/\:Set_Fault_Restored/g;
                                push( @rb_disjunction_faults_2 , $fault_temp ) if ( defined($fault_temp) );
                            }                            
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_mandatory_faults_1;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "RB_disjunction_faults_2";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_disjunction_faults_2;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_3";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_mandatory_faults_3;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                        }
                        elsif ( $cu_mand_fault_line != 0 ){
                            # update cu mandatory and add rb optional faults
                            @cu_mandatory_faults = @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_mandatory_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_2";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_mandatory_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_3";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_mandatory_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            @rb_optional_faults_2 = map{$_ .= ":Good_Check";}(@cu_mandatory_faults);    # add :Good_Check
                            unless ( grep( /optional/g , @rb_fault_eval_types ) ){
                                $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "RB_optional_faults_3";
                                @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_optional_faults_2;
                                $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            }
                        }
                        elsif ( $rb_opt_fault_line != 0 ){
                            # update rb optional faults
                            @rb_optional_faults = @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_optional_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_2";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_optional_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_3";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @rb_optional_faults_2;
                            push( @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} , @rb_optional_faults);
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                        }
                        elsif ( $cu_opt_fault_line != 0 ){
                            # update cu optional faults
                            @cu_optional_faults = @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_optional_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_2";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_optional_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'NAME'} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'NAME'}"."_3";
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @cu_optional_faults;
                            $tc_par_cnt_offset++;$tc_par_cnt_mod++;
                        }
                        else{
                            @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type}} = @{$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}};
                        }
                    }
                    elsif( $data_type =~ /SCALAR/ ){
                        $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_mod}{'VALUE'}{$data_type} = "$TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt}{'VALUE'}{$data_type}";
                    }
                }
                $tc_par_cnt_max = $tc_par_cnt_mod if ($tc_par_cnt_max <= $tc_par_cnt_mod);
            }
            $tc_par_cnt_max_mod = $tc_par_cnt_max;
            # add MEP_usage restriction to none FMVSS tests (critical timing)
            $tc_par_cnt_max++;
            unless ($mep_usage_line){
                $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt_max}{'NAME'} = "MEP_usage";
                $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt}{'STEPS_TcPar'}{$tc_par_cnt_max}{'VALUE'}{'LIST'} = [ 'MEP_FINIT' , 'MEP_FRESET' , 'MEP_FGOODCHK' ];
            }
            # add FMVSS specific lines
            $tc_par_cnt_max_mod++;
            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_max_mod}{'NAME'} = "switch_goodcheck";
            $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$tc_par_cnt_max_mod}{'VALUE'}{'SCALAR'} = "FMVSS";
            # remove MEP usage for FMVSS tests in general
            delete $TcParFileConfig_upd->{$tc_par_file}{$tc_cnt_mod}{'STEPS_TcPar'}{$mep_usage_line};
        }
    }
#     dump_log( "TcParFileConfig_upd" , $TcParFileConfig_upd );
    
    print( " SUB MATDNC_FMVSS_postprocessing ... done\n" );
    
    return $TcParFileConfig_upd;
}


###----------------------------------------------------------------------------
sub GetSingleTcPar {
###----------------------------------------------------------------------------
    my $tc_par_data = shift;
    
    my ( $tc_par_value , $tc_par_name , $isList , $isHash , $temp_values , $temp_keys , $data_value , $key , $index );
    $isList = 0; $isHash = 0;
    
    $tc_par_name = $tc_par_data->{'STEPS_Par_NAME'};
    foreach ( keys %$tc_par_data ) {
        next if /STEPS_Par_NAME/;
        $data_value = $tc_par_data->{$_};
        
        next if $data_value =~ /^$/;  # weiter wenn nuescht drin
        
        if( /STEPS_Par_SCALAR/ ) {
            if ( $isList ) { print_log( " ERROR : LIST and SCALAR mixed for STEPS_Par : '$tc_par_name'" ); return } 
            if ( $isHash ) { print_log( " ERROR : HASH and SCALAR mixed for STEPS_Par : '$tc_par_name'" ); return } 
            $tc_par_value = $data_value; last;
        }
        if( /STEPS_Par_LIST_VAL_(\d+)/ ) {
            $index = $1;
            if ( $isHash ) { print_log( " ERROR : HASH and LIST mixed for STEPS_Par : '$tc_par_name'" ); return } 
            if( defined $tc_par_value->[$index-1] ) { 
                print_log( " ERROR : LIST has 2nd definition $_ for STEPS_Par : '$tc_par_name'" ); return  
            }
            $tc_par_value->[$index-1] = $data_value;
            $isList = 1;
            next;
        }
        if( /STEPS_Par_HASH_KEY_(\d+)/ ) {
            $index = $1;
            $key = $data_value;
            if ( $isList ) { print_log( " ERROR : LIST and HASH mixed for STEPS_Par : '$tc_par_name'" ); return } 
            if( exists $tc_par_value->{$key} ) { 
                print_log( " ERROR : HASH has 2nd definition of KEY $_ ($key) for STEPS_Par : '$tc_par_name'" ); return  
            }
            if( defined $temp_values->{$index} ) { 
                $tc_par_value->{$key} = $temp_values->{$index};
            } else { 
                $temp_keys->{$index} = $key;
            }
            $isHash = 1;
            next;
        }
        if( /STEPS_Par_HASH_VAL_(\d+)/ ) {
            $index = $1;
            if ( $isList ) { print_log( " ERROR : LIST and HASH mixed for STEPS_Par : '$tc_par_name'\n" ); return } 
            if( defined $temp_values->{$index} ) { 
                print_log( " ERROR : HASH has 2nd definition of $_ for STEPS_Par : '$tc_par_name'\n" ); return  }            
            if( defined $temp_keys->{$index} ) { 
                $key = $temp_keys->{$index};
                $tc_par_value->{ $key } = $data_value;
            } else {
                $temp_values->{$index} = $data_value;
            }
            $isHash = 1;
            next;
        }
        
    }
        
    return $tc_par_value;
}

###----------------------------------------------------------------------------
sub ReadTestTable {
###----------------------------------------------------------------------------

    my $Xls_Worksheet_Tests = shift;

    my ( 
        $table_content ,
        $Anchor ,
        $Header ,
        $content_CELL, 
        $row, 
        $col,
        $col_last ,
        $header_item ,
        $header_item_last ,
        $tc_cnt ,
        $tcpar_cnt ,
        $header_typedef ,
        $Typedef_Check ,
        $HeaderSTEPS_ID ,
        $col_TC_ID, 
        $key_TC_ID, 
        $STEPS_Module ,
        $STEPS_TcParExt ,
        $STEPS_CondParExt ,
        $STEPS_SELECTION ,
    );
    
    print( " SUB ReadTestTable ... \n" );
    
    ( $Anchor->{'ANCHOR_ITEM'}{'Row'}, $Anchor->{'ANCHOR_ITEM'}{'Col'} ) 
        = SearchAnchor( 'ANCHOR_ITEM' , 20 , 20 );
    
    ($Anchor->{'ANCHOR_TYPEDEF'}{'Row'}, $Anchor->{'ANCHOR_TYPEDEF'}{'Col'}) 
        = SearchAnchor( 'ANCHOR_TYPEDEF' , 20 , 20 );

    #
    # reading Items from Header Line
    #
    foreach $col ( $Anchor->{'ANCHOR_ITEM'}{'Col'}+1 .. max_col ) {
        $col_last = $col;
        $content_CELL = $Xls_Worksheet_Tests->Cells( $Anchor->{'ANCHOR_ITEM'}{'Row'} , $col)->{'Value'} ;
        last unless $Header->{$col}{'ITEM'} = $content_CELL;
        $HeaderSTEPS_ID->{'SELECTION'}{'Col'} = $col if $content_CELL eq "SELECTION";
        $HeaderSTEPS_ID->{'STEPS_Module'}{'Col'} = $col if $content_CELL eq "STEPS_Module";
        $HeaderSTEPS_ID->{'STEPS_TcParExt'}{'Col'} = $col if $content_CELL eq "STEPS_TcParExt";
        $HeaderSTEPS_ID->{'STEPS_CondParExt'}{'Col'} = $col if $content_CELL eq "STEPS_CondParExt";
    }

    #
    # reading Typedefs from Header Line
    #
    foreach $col( $Anchor->{'ANCHOR_TYPEDEF'}{'Col'}+1 .. $col_last ) {
        $Header->{$col}{'TYPEDEF'} = $Xls_Worksheet_Tests->Cells($Anchor->{'ANCHOR_TYPEDEF'}{'Row'}, $col)->{'Value'};
    }
    
    #
    # check of Typedefs
    #
    foreach $col ( keys %$Header ) {
        $header_item = $Header->{$col}{'ITEM'};
        $header_typedef = $Header->{$col}{'TYPEDEF'};
        
        if( exists $Typedef_Check->{ $header_item }{ $header_typedef } ) {
            print_log ( " ERROR : Header Definition Wrong ! -> Item : '$header_item' has double Typedef : $header_typedef (col1:$Typedef_Check->{ $header_item }{ $header_typedef } col2:$col)\n" );
            return;            
        }
        $Typedef_Check->{ $header_item }{ $header_typedef } = $col;
    }
    
#     dump_log ( "HEADER :" , $Header );

    $tc_cnt=0;
    foreach $row ( $Anchor->{'ANCHOR_ITEM'}{'Row'}+1 .. max_row ) {
        next unless $STEPS_Module = $Xls_Worksheet_Tests -> Cells($row, $HeaderSTEPS_ID->{'STEPS_Module'}{'Col'})->{'Value'};
        $STEPS_TcParExt = $Xls_Worksheet_Tests -> Cells($row, $HeaderSTEPS_ID->{'STEPS_TcParExt'}{'Col'})->{'Value'};
        $STEPS_CondParExt = $Xls_Worksheet_Tests -> Cells($row, $HeaderSTEPS_ID->{'STEPS_CondParExt'}{'Col'})->{'Value'};

        $key_TC_ID = $STEPS_Module;
        $key_TC_ID .= "." if $STEPS_TcParExt || $STEPS_CondParExt;
        $key_TC_ID .= $STEPS_TcParExt if $STEPS_TcParExt;
        $key_TC_ID .= "." if $STEPS_CondParExt;
        $key_TC_ID .= $STEPS_CondParExt if $STEPS_CondParExt;

        if( defined $HeaderSTEPS_ID->{'SELECTION'}{'Col'} ) {
            $STEPS_SELECTION = $Xls_Worksheet_Tests -> Cells($row, $HeaderSTEPS_ID->{'SELECTION'}{'Col'})->{'Value'};
            unless( Check_SELECTION( $STEPS_SELECTION ) ) {
                print_log ( "[ $row (row) ] \t Testcase TC_ID not selected : $key_TC_ID \n" );
                next;
            }
        }


        $tc_cnt++;

        print_log ( "[ $tc_cnt ] \t Adding new TC_ID : $key_TC_ID \n" );
        $table_content->{$tc_cnt}{'SELECTION'} = $STEPS_SELECTION;
        $table_content->{$tc_cnt}{'TC_ID'} = $key_TC_ID;
        $table_content->{$tc_cnt}{'STEPS_Module'} = $STEPS_Module;
        $table_content->{$tc_cnt}{'STEPS_TcParExt'} = $STEPS_TcParExt if $STEPS_TcParExt;
        $table_content->{$tc_cnt}{'STEPS_TcParSet_Name'} = $STEPS_Module.".".$STEPS_TcParExt if $STEPS_TcParExt;        
        $table_content->{$tc_cnt}{'STEPS_CondParExt'} = $STEPS_CondParExt if $STEPS_CondParExt;

        $table_content->{$tc_cnt}{'STEPS_TcParFile'} = $1.".par" if( $STEPS_Module =~ /^(\w+)__/ );
        $table_content->{$tc_cnt}{'STEPS_TcParFile'} = $STEPS_Module.".par" unless $STEPS_Module =~ /^(\w+)__/;
        
#         if( exists $table_content->{$key_TC_ID} ) {
#             print_log ( " ERROR : Testcase exists already : '$key_TC_ID' -> LINE: $row \n" );
#             next;
#         }            
                 
        $tcpar_cnt = 0;
        $header_item_last = "";
        foreach $col ( $Anchor->{'ANCHOR_ITEM'}{'Col'}+1 .. $col_last ) {
            $content_CELL = $Xls_Worksheet_Tests -> Cells($row, $col)->{'Value'};
            next unless defined $content_CELL;
            next if $content_CELL =~ /^$/;
            $header_item = $Header->{$col}{'ITEM'};
            $header_typedef = $Header->{$col}{'TYPEDEF'};
            next if $header_item =~ /STEPS_Module|STEPS_TcParExt|STEPS_CondParExt|SELECTION/;
            
            if( ! $header_typedef ) {
                $table_content->{$tc_cnt}{'OTHER'}{ $header_item } = $content_CELL;
            }
            elsif( $header_typedef =~ /^STEPS_Par/i ) {
                unless ( $header_item eq $header_item_last ) { 
                    $tcpar_cnt++;
                    $table_content->{$tc_cnt}{'STEPS_Par'}{$tcpar_cnt}{'STEPS_Par_NAME'} = $header_item ;
                }
                $table_content->{$tc_cnt}{'STEPS_Par'}{$tcpar_cnt}{ $header_typedef } = $content_CELL;
            }
            elsif( $header_typedef =~ /QC_TestAttr/i ) {
                $table_content->{$tc_cnt}{'QC_TestAttr'}{ $header_item }{ $header_typedef } = $content_CELL;
            }
            else {
                $table_content->{$tc_cnt}{'OTHER'}{ $header_item }{ $header_typedef } = $content_CELL;
            }
            
            $header_item_last = $header_item;
        }        
    } # while ( $row != max_row )

    print( " SUB ReadTestTable ... done\n" );

    return $table_content;
}

###----------------------------------------------------------------------------
sub Check_SELECTION {
###----------------------------------------------------------------------------
    my $SELECTION_cell_content = shift;
    
    return 0 unless defined $SELECTION_cell_content;
    return 0 if( $SELECTION_cell_content =~ /n|no|false|0|-/i );
    return 1 if( $SELECTION_cell_content =~ /^y|yes|true|x|1|\+$/i );

    print_log( " Check_SELECTION : unexpected marker for (De)Selection : '$SELECTION_cell_content' \n" );
    return 0;
}

###----------------------------------------------------------------------------
sub CreateTargetPath {
###----------------------------------------------------------------------------
    my $used_parfilesfolder = shift;

#     if( -d $used_parfilesfolder ) { 
#         print_log ( "Deleting Path : $used_parfilesfolder \n" );
#         rmtree( $used_parfilesfolder ) || die "ERROR deleting Path : $used_parfilesfolder"; 
#     }

    if( -d $used_parfilesfolder ) { 
        print_log ( "Target Path exists already: $used_parfilesfolder (nothing to do) \n" );
    }
    else { 
        print_log ( "Creating Path : $used_parfilesfolder \n" );
        mkpath( $used_parfilesfolder ) || die "ERROR creating Path : $used_parfilesfolder";
    }
        
    return 1;
}


###----------------------------------------------------------------------------
sub FindNewestXls {
###----------------------------------------------------------------------------
    my ( @xls , $XlsFiles , $used_infile );
    #
    # This section is searching the newest (last modified) excel dir in cwd (current working dir)
    #
    print_log ( " SUB FindNewestXls ... \n" );
    find(\&wanted, cwd );
    sub wanted { return unless /\.xls/i; my $file = $File::Find::name; $file =~ s/\//\\\\/g; push (@xls , $file); }
    
    unless( @xls ) { print_log ( "No *.xls files in cwd:".cwd." -> Exit\n" ); exit(1);}
    
    foreach ( @xls ) { $XlsFiles->{ (stat($_))[9] } = $_ } 
    my @sorted_times = sort {$b<=>$a} keys %$XlsFiles;      # descending sorting
    $used_infile = $XlsFiles->{ $sorted_times[0] };  # take the 1st (=newest)
    
    return $used_infile;
}

###----------------------------------------------------------------------------
sub SearchAnchor {
###----------------------------------------------------------------------------
    my ( $anchor , $max_row , $max_col ) = @_;    
    my ( $row , $col );
    foreach $col ( 1 .. $max_col ) {
        foreach $row ( 1 .. $max_row ) {
            if( $Xls_Worksheet_Tests -> Cells($row, $col)->{'Value'} eq $anchor ) { 
                print_log ( "Found Anchor '$anchor' in Cell($row,$col)\n" ); return( $row,$col );
            }
        }
    }
    print_log ( "Could not find Anchor '$anchor' between Row(1..$max_row) and Col(1..$max_col)\n\n" );
    exit;
}

###----------------------------------------------------------------------------
sub print_log {
###----------------------------------------------------------------------------
    print LOG @_;
    print @_;
}
###----------------------------------------------------------------------------
sub dump_log {
###----------------------------------------------------------------------------
    my $label = shift;
    my $dump = shift;
    print LOG " DUMPER : $label : \n".Dumper($dump)."\n\n";
}


__END__
:endofperl
@rem pause