package LIFT_PROJECT;

our $Defaults;

$Defaults = {
                     
########################################################################################################################
# here you define the MLC configuration
# section => {device name => label}
########################################################################################################################
'MLC' => {
                   'General' =>
                                   {
                                    # CAN settings will be overwritten form testbench config settings
                                    'MaxVoltage' => 20,
                                    },
                   'POWER_SUPPLY_LINES' =>
                                   {
                                    'PSL1_Name'   => 'PSL1',        
                                    'PSL2_Name'   => 'PSL2',            
                                    'PSL3_Name'   => 'PSL3',            
                                    'PSL4_Name'   => 'PSL4',            
                                    },
                   'SQUIBS' =>
                                   {
                                    'SQ1_Name'  => 'SQ1',
                                    'SQ2_Name'  => 'SQ2',
                                    'SQ3_Name'  => 'SQ3',
                                    'SQ4_Name'  => 'SQ4',
                                    'SQ5_Name'  => 'SQ5',
                                    'SQ6_Name'  => 'SQ6',
                                    'SQ7_Name'  => 'SQ7',
                                    'SQ8_Name'  => 'SQ8',
                                    'SQ9_Name'  => 'SQ9',
                                    'SQ10_Name' => 'SQ10',
                                    'SQ11_Name' => 'SQ11',
                                    'SQ12_Name' => 'SQ12',
                                    'SQ13_Name' => 'SQ13',
                                    'SQ14_Name' => 'SQ14',
                                    'SQ15_Name' => 'SQ15',
                                    'SQ16_Name' => 'SQ16',
                                    'SQ17_Name' => 'SQ17',
                                    'SQ18_Name' => 'SQ18',
                                    'SQ19_Name' => 'SQ19',
                                    'SQ20_Name' => 'SQ20',
                                    'SQ21_Name' => 'SQ21',
                                    'SQ22_Name' => 'SQ22',
                                    'SQ23_Name' => 'SQ23',
                                    'SQ24_Name' => 'SQ24',
                                    'SQ25_Name' => 'SQ25',
                                    'SQ26_Name' => 'SQ26',
                                    'SQ27_Name' => 'SQ27',
                                    'SQ28_Name' => 'SQ28',
                                    'SQ29_Name' => 'SQ29',
                                    'SQ30_Name' => 'SQ30',
                                    'SQ31_Name' => 'SQ31',
                                    'SQ32_Name' => 'SQ32',
                                    },
                   'SWITCHES' =>
                                   {
                                    'SW1_Name'  => 'SW1',
                                    'SW2_Name'  => 'SW2',
                                    'SW3_Name'  => 'SW3',
                                    'SW4_Name'  => 'SW4',
                                    'SW5_Name'  => 'SW5',
                                    'SW6_Name'  => 'SW6',
                                    'SW7_Name'  => 'SW7',
                                    'SW8_Name'  => 'SW8',
                                    'SW9_Name'  => 'SW9',
                                    'SW10_Name' => 'SW10',
                                    'SW1_OPEN '   => '  open',
                                    'SW1_CLOSED ' => ' closed',
                                    'SW2_OPEN '   => '  open',
                                    'SW2_CLOSED ' => ' closed',
                                    'SW3_OPEN '   => '  open',
                                    'SW3_CLOSED ' => ' closed',
                                    'SW4_OPEN '   => '  open',
                                    'SW4_CLOSED ' => ' closed',
                                    'SW5_OPEN '   => '  open',
                                    'SW5_CLOSED ' => ' closed',
                                    'SW6_OPEN '   => '  open',
                                    'SW6_CLOSED ' => ' closed',
                                    'SW7_OPEN '   => '  open',
                                    'SW7_CLOSED ' => ' closed',
                                    'SW8_OPEN '   => '  open',
                                    'SW8_CLOSED ' => ' closed',
                                    'SW9_OPEN '   => '  open',
                                    'SW9_CLOSED ' => ' closed',
                                    'SW10_OPEN '  => '  open',
                                    'SW10_CLOSED '=> ' closed',

                                    },
                   'CAN' =>
                                   {
                                    'CAN1_Name'   => 'CAN_1',       
                                    'CAN2_Name'   => 'CAN_2',
                                    },
                   'PAS' =>
                                   {
                                    'PAS1_Name'  => 'PAS1',
                                    'PAS2_Name'  => 'PAS2',
                                    'PAS3_Name'  => 'PAS3',
                                    'PAS4_Name'  => 'PAS4',
                                    'PAS5_Name'  => 'PAS5',
                                    'PAS6_Name'  => 'PAS6',
                                    'PAS7_Name'  => 'PAS7',
                                    'PAS8_Name'  => 'PAS8',
                                    'PAS9_Name'  => 'PAS9',
                                    'PAS10_Name' => 'PAS10',
                                    'PAS11_Name' => 'PAS11',
                                    'PAS12_Name' => 'PAS12',
                                    },
                   'WARNING_LAMPS' =>
                                   {
                                    'WL1_Name ' => ' WL1',
                                    'WL2_Name ' => ' WL2',
                                    'WL3_Name ' => ' WL3',
                                    'WL4_Name ' => ' WL4',
                                    'WL5_Name ' => ' WL5',
                                    },
                   'FREELY_USABLE_SWITCHES' =>
                                   {
                                    'FS1_Name ' => ' FS1',
                                    'FS2_Name ' => ' FS2',
                                    'FS3_Name ' => ' FS3',
                                    'FS4_Name ' => ' FS4',
                                    'FS5_Name ' => ' FS5',
                                    'FS6_Name ' => ' FS6',
                                    'FS7_Name ' => ' FS7',
                                    'FS8_Name ' => ' FS8',
                                    'FS1_STATE_CA ' => ' CA',
                                    'FS1_STATE_CB ' => ' CB',
                                    'FS1_STATE_NC ' => ' OPEN',
                                    'FS2_STATE_CA ' => ' CA',
                                    'FS2_STATE_CB ' => ' CB',
                                    'FS2_STATE_NC ' => ' OPEN',
                                    'FS3_STATE_CA ' => ' CA',
                                    'FS3_STATE_CB ' => ' CB',
                                    'FS3_STATE_NC ' => ' OPEN',
                                    'FS4_STATE_CA ' => ' CA',
                                    'FS4_STATE_CB ' => ' CB',
                                    'FS4_STATE_NC ' => ' OPEN',
                                    'FS5_STATE_CA ' => ' CA',
                                    'FS5_STATE_CB ' => ' CB',
                                    'FS5_STATE_NC ' => ' OPEN',
                                    'FS6_STATE_CA ' => ' CA',
                                    'FS6_STATE_CB ' => ' CB',
                                    'FS6_STATE_NC ' => ' OPEN',
                                    'FS7_STATE_CA ' => ' CA',
                                    'FS7_STATE_CB ' => ' CB',
                                    'FS7_STATE_NC ' => ' OPEN',
                                    'FS8_STATE_CA ' => ' CA',
                                    'FS8_STATE_CB ' => ' CB',
                                    'FS8_STATE_NC ' => ' OPEN',
                                    },
                       },


};


1;