# please change settings according to your project/testbench

package LIFT_PROJECT;
our $Defaults;
$Defaults = {

'MLC' => {
                   'General' =>
                                   {
                                    # CAN settings will be overwritten from testbench config settings
                                    'MaxVoltage' => 20,
                                    },
                                    
                    #components list for MLC1
                    'MLC1'   =>
                        {
                        'POWER_SUPPLY_LINES' =>
                                       {
                                        'PSL1_Name'   => 'UB1',        
                                        'PSL2_Name'   => 'UB2',            
                                        'PSL3_Name'   => 'UB3',            
                                        'PSL4_Name'   => 'UDISP',            
                                        },
                       'SQUIBS' =>
                                       {
                                        'SQ1_Name' => 'AB1FD',
                                        'SQ2_Name' => 'AB2FD',
                                        'SQ3_Name' => 'AB1FP',
                                        'SQ4_Name' => 'AB2FP',
                                        'SQ5_Name' => 'BT1FD',
                                        'SQ6_Name' => 'BT1FP',
                                        'SQ7_Name' => 'SABD',
                                        'SQ8_Name' => 'SABP',
                                        'SQ9_Name' => 'BATDIS',
                                        'SQ10_Name' => 'BT1RD',
                                        'SQ11_Name' => 'BT1RP',
                                        'SQ12_Name' => 'BT1RC',
                                        },
                       'SWITCHES' =>
                                       {
                                        'SW1_Name' => 'PSPOS',
                                        'SW3_Name' => 'BLRL',
                                        'SW4_Name' => 'BLRM',
                                        'SW5_Name' => 'DSPOS',
                                        'SW10_Name' => 'BLFR',
                                        'PSPOS_OPEN' => ' FRONT',
                                        'PSPOS_CLOSED' => ' REAR',
                                        'BLRL_OPEN' => 'BUCKLED',
                                        'BLRL_CLOSED' => 'UNBUCKLED',
                                        'BLRM_OPEN' => 'BUCKLED',
                                        'BLRM_CLOSED' => 'UNBUCKLED',
                                        'DSPOS_OPEN' => ' FRONT',
                                        'DSPOS_CLOSED' => ' REAR',
                                        'BLFR_OPEN' => 'BUCKLED',
                                        'BLFR_CLOSED' => 'UNBUCKLED',
                                        },
                       'CAN' =>
                                       {
                                        'CAN1_Name'   => 'Airbag_Bus',       
                                        'CAN2_Name'   => 'MLC_Bus',
                                        },
                       'PAS' =>
                                       {
                                        'PAS1_Name' => 'LineSissi11',
                                        'PAS2_Name' => 'LineSissi12',
                                        'PAS3_Name' => 'LineSissi13',
                                        'PAS4_Name' => 'LineSissi14',
                                        'PAS5_Name' => 'LineSissi21',
                                        'PAS6_Name' => 'LineSissi22',
                                        'PAS7_Name' => 'LineSissi23',
                                        'PAS8_Name' => 'LineSissi24',
                                        },
                       'WARNING_LAMPS' =>
                                       {
                                        'WL1_Name'   => 'WL',       
                                        'WL2_Name'   => 'PADL',       
                                        },
                       'FREELY_USABLE_SWITCHES' =>
                                       {
                                        'FS1_Name' => 'FS_ISOFIX1',
                                        'FS2_Name' => 'FS_ISOFIX2',
                                        'FS4_Name' => 'FS_BLMR',
                                        'FS_BLMR_STATE_CA' => 'BUCKLED_100',
                                        'FS_BLMR_STATE_CB' => 'UNBUCKLED_400',
                                        'FS_BLMR_STATE_NC' => 'OPEN',
                                        'FS_ISOFIX1_STATE_CA' => 'ISO1_100',
                                        'FS_ISOFIX1_STATE_CB' => 'ISO1_400',
                                        'FS_ISOFIX1_STATE_NC' => 'OPEN',
                                        'FS_ISOFIX2_STATE_CA' => 'ISO2_100',
                                        'FS_ISOFIX2_STATE_CB' => 'ISO2_400',
                                        'FS_ISOFIX2_STATE_NC' => 'OPEN',
                                        },
                       'EMPTY' => { },
                    },   
                    
                #components list for MLC2
               'MLC2'  =>
                    {

                        'SQUIBS'  =>
                        {
                            'SQ1_Name' => 'WB1D',
                            'SQ2_Name' => 'WB1P',
                            'SQ3_Name' => 'HEADD',
                            'SQ4_Name' => 'HEADP',
                            'SQ5_Name' => 'KABD',
                            'SQ6_Name' => 'KABP',
                            'SQ7_Name' => 'WB2D',
                            'SQ8_Name' => 'WB2P',
                            'SQ9_Name' => 'SARD',
                            'SQ10_Name' => 'SARP',
                            'SQ11_Name' => 'BLFD',
                            'SQ12_Name' => 'BLFP',

                        },

                       'SWITCHES' =>
                       {
                        'SW1_Name' => '_ISOFIX',
                        'SW2_Name' => 'BLRR',
                        'SW3_Name' => '_BLM',
                        'SW4_Name' => 'PADS',
                        'SW9_Name' => 'BLFL',
                        '_ISOFIX_OPEN' => 'OPEN',
                        '_ISOFIX_CLOSED' => 'CLOSED',
                        'BLRR_OPEN' => 'BUCKLED',
                        'BLRR_CLOSED' => 'UNBUCKLED',
                        '_BLM_OPEN' => 'OPEN',
                        '_BLM_CLOSED' => 'CLOSED',
                        'PADS_OPEN' => 'ACTIVATED',
                        'PADS_CLOSED' => 'DEACTIVATED',
                        'BLFL_OPEN' => 'BUCKLED',
                        'BLFL_CLOSED' => 'UNBUCKLED',
                        },
                                        
                      'FREELY_USABLE_SWITCHES' =>
                        {
                            'FS3_Name' => 'FS_BLML',
                            'FS_BLML_STATE_CA' => 'BUCKLED_100',
                            'FS_BLML_STATE_CB' => 'UNBUCKLED_400',
                            'FS_BLML_STATE_NC' => 'OPEN',  
                        }
                    }
 },


};

1;

