use strict;
use warnings;
use Data::Dumper;
use CBOR::XS;
use Readonly;
use Tk;
use Storable qw(dclone);
use File::Basename;
use File::Spec;

use constant SIMULATION_CYCLE_MS     => 20;
Readonly my $NUM_ROUND_THRESHOLD     => 0.5;
Readonly our $NUM_SYS_INT_MAX        => ~0 >> 1;
Readonly our $NUM_SYS_INT_MIN        => -$NUM_SYS_INT_MAX - 1;
Readonly our $NUM_EPSILON_1E_MINUS_6 => 0.000001;
Readonly my $NUM_ERR_CODE_1          => -1;
Readonly my $NUM_ERR_CODE_2          => -2;

my $data_href;
my $arraysize;
my @temp_arraysize;

my ( $main, $Frame1, $Frame2, $Frame1_1, $start_button, $button, $entry );
my ( $input_File, $output_file, $default_input_File );

my $FILE_VERSION       = "1.0";
my $sil_Input_File     = "Signal.csv";
my $simulation_time_ms = SIMULATION_CYCLE_MS;

GUI();
MainLoop;

######################################################################################
# This function is used to handle GUI related properties
#####################################################################################
sub GUI {

##------------------------------------------------------------------
    ## create main window 'main'
    ##------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow->new( "-background" => "#888888" );

    # define minimum size of main window 'main'
    $main->minsize( 800, 100 );

    # create title in main window 'main'
    $main->title($FILE_VERSION);

    ##------------------------------------------------------------------
    ## create frame 'F1' in main window 'main'
    ##------------------------------------------------------------------
    $Frame1 = $main->Frame( "-background" => "honeydew4" )->pack(
        "-side"   => 'top',
        "-expand" => 1,
        "-fill"   => 'both',
    );

    ##------------------------------------------------------------------
    ## create frame 'F2' in main window 'main'
    ##------------------------------------------------------------------
    $Frame2 = $main->Frame( "-background" => "honeydew4" )->pack(
        "-side" => 'bottom',
        "-fill" => 'x',
    );

    ##------------------------------------------------------------------
    ## write head line in frame 'F1'
    ##------------------------------------------------------------------
    $Frame1->Label(
        "-text"     => 'SIL INPUT FILE GENERATOR : Configuration Window',
        -font       => '{Segoe UI Semibold} 13 bold ',
        -background => "#333546",
        -foreground => "white",
        -width      => 50,
        -relief     => 'groove',
    )->pack( "-side" => "top" );

    #Frame for accepting input *.pm for input file generator
    my $frame1_sub = $Frame1->Frame( "-background" => "#888888", -relief => 'solid', -borderwidth => 1, )->pack(
        "-side"   => 'top',
        "-expand" => 0,
        "-fill"   => 'both',
        "-pady"   => 5,
        "-padx"   => 5,
    );
    
    ##------------------------------------------------------------------
    ## create Frame for choosing default .pm signal file
    ##------------------------------------------------------------------
    $Frame1_1 = $frame1_sub->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "Enter the default input *.pm file for input file generator ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$default_input_File, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            my $temp = $default_input_File;    # store old value
            $default_input_File = $main->getOpenFile(
                "-filetypes" => [ [ "Input files", '.pm' ], [ "All files", '.*' ] ],
                "-title" => "Default Input *.pm file which have to be scanned",
                "-initialdir" => '.',
            );

            unless ($default_input_File) { $default_input_File = $temp; }    # if no new value, restore old one
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

    ##------------------------------------------------------------------
    ## create Frame for choosing testcase specific .pm file
    ##------------------------------------------------------------------
    $Frame1_1 = $frame1_sub->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "Enter the input *.pm file for input file generator ", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95', -wraplength => 260 )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$input_File, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            my $temp = $input_File;    # store old value
            $input_File = $main->getOpenFile(
                "-filetypes" => [ [ "Input files", '.pm' ], [ "All files", '.*' ] ],
                "-title" => "Input *.pm file which have to be scanned",
                "-initialdir" => '.',
            );

            unless ($input_File) { $input_File = $temp; }    # if no new value, restore old one
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

    ##------------------------------------------------------------------
    ## create Frame for choosing output mapping file(.pm)
    ##------------------------------------------------------------------
    $Frame1_1 = $frame1_sub->Frame( "-background" => "#888888" )->pack( -pady => '2', "-fill" => 'x', );

    $Frame1_1->Label( "-text" => "SIL Input File (*.csv)", -background => "#888888", -foreground => 'white', -font => '{Segoe UI Semibold} 10 bold', -width => '33.95' )->pack( "-side" => 'left' );

    $Frame1_1->Entry( "-textvariable" => \$output_file, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 1, "-padx" => 5 );

    # create 'browse file' button
    $button = $Frame1_1->Button(
        "-text"     => "Browse...",
        -relief     => 'groove',
        -background => "#333366",
        -foreground => "white",
        -font       => '{Segoe UI Semibold} 10 ',
        "-command"  => sub {
            if ( -f $input_File and $input_File =~ /^.+\.pm$/ ) {

                my $temp = $output_file;    # store old value
                $output_file = $main->getSaveFile(
                    "-filetypes" => [ [ ".csv SIL Input File", '.csv' ], [ "All files", '.*' ] ],
                    "-title" => "SIL Input Files",
                    "-initialdir"  => '.',
                    "-initialfile" => $sil_Input_File,
                );

                $output_file = $output_file . ".csv" if ( $output_file && $output_file !~ /^.+\.csv$/ );

                unless ($output_file) { $output_file = $temp; }    # if no new value, restore old one
            }
            else {
                $main->messageBox(
                    '-icon'    => "error",
                    '-type'    => "OK",
                    '-title'   => 'Error',
                    '-message' => "The .pm file entered does'nt exist or the type of file selected is wrong",
                );

            }
        },
    )->pack( "-side" => 'right', "-ipadx" => 5, "-ipady" => 2, "-pady" => 5, "-padx" => 5 );

    #create Frame for choosing simulation time
    my $simulation_time_Frame = $frame1_sub->Frame( -background => "#888888" )->pack( -pady => 5, -fill => 'x', -padx => 5, );
    $simulation_time_Frame->Label(
        -text       => "Simulation Time in ms: ",
        -background => "#888888",
        -foreground => 'white',
        -font       => '{Segoe UI Semibold} 10 bold',
        -width      => '34',
    )->pack( -side => 'left' );

    $entry = $simulation_time_Frame->Entry( "-textvariable" => \$simulation_time_ms, -validate => 'focusout', -vcmd => [ \&Check_state ], -background => "grey", )->pack( "-side" => 'left', "-fill" => 'x', "-expand" => 0, "-padx" => 5 );

    ##------------------------------------------------------------------
    ## create exit and start buttons in frame 'F2'
    ##------------------------------------------------------------------
    $Frame2->Button(
        "-text"     => "Quit",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -background => "Red4",
        -foreground => "white",
        -relief     => 'groove',
        "-command"  => sub { print " QUIT pressed -> Exit\n"; exit; }
      )->pack(
        "-side"  => 'left',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );

    $start_button = $Frame2->Button(
        "-text"     => "Create",
        -width      => '8',
        -font       => '{Segoe UI Semibold} 12 ',
        -foreground => "white",
        -relief     => 'groove',
        -background => "ForestGreen",
        "-command"  => sub {
            if ( -f $input_File and $output_file and $input_File =~ /^.+\.pm$/ ) {

                $output_file = $output_file . ".csv" if ( $output_file && $output_file !~ /^.+\.csv$/ );

                #execute LPCM_engine
                Resample_edr4ad_input();
                write_data_to_csv();
                Convert_data_to_cbor_format();

                my $output_file_path = dirname($output_file);
                $main->messageBox( -icon => "info", -message => "Created SIL input file(.csv and cbor) in the location $output_file_path", -title => 'Finished' );
            }
            else {
                ##------------------------------------------------------------------
                ## inform user that options are missing
                ##------------------------------------------------------------------
                $main->messageBox(
                    '-icon'    => "error",
                    '-type'    => "OK",
                    '-title'   => 'Error',
                    '-message' => "! Smthing went wrong ",
                );
            }
        }
      )->pack(
        "-side"  => 'right',
        "-pady"  => 20,
        "-padx"  => 20,
        "-ipady" => 5,
        "-ipadx" => 5,
      );
    return 1;

}

sub Check_state {
    if ( defined $input_File && $input_File ne '' ) {
        $button->configure( -state => 'normal' );

    }
    else {
        $button->configure( -state => 'disabled' );
    }
    return 1;
}

=head2 Resample_default_edr4ad_input

 Function Name   : Resample_default_edr4ad_input

 Description     : This function takes the default EDR4AD data input and resamples it

 Syntax          : Resample_default_edr4ad_input()

 Return Value(s) : resampled data

 Example         : Resample_default_edr4ad_input();
 
=cut

sub Resample_default_edr4ad_input {    

    require $default_input_File;
    our $inputDataDEFAULT_href;

    #$input_File =~ /.+[\/\\](.+)\.pm$/;
    #store the input hash read from the Signal file to another variable
    my $extracted_inputData_href = dclone($edr4ad_sil_DEFAULT_input::inputDataDEFAULT_href);
    
    delete $INC{$default_input_File};

    my $data_temp_href;
    undef $data_href;

    #loop over the keys of signal value hash
    foreach my $sig ( keys %$extracted_inputData_href ) {
        extract_and_format_inputdata( $extracted_inputData_href, $sig );               #Generate ramp values
    }
    
    return 1;
}


=head2 Resample_edr4ad_input

 Function Name   : Resample_edr4ad_input

 Description     : This function takes the EDR4AD data input and resamples it

 Syntax          : Resample_edr4ad_input()

 Return Value(s) : resampled data

 Example         : Resample_edr4ad_input();
 
=cut

sub Resample_edr4ad_input {    
    
    Resample_default_edr4ad_input() if (-e $default_input_File);

    require $input_File;
    our $inputData_href;

    #$input_File =~ /.+[\/\\](.+)\.pm$/;
    #store the input hash read from the Signal file to another variable
    my $extracted_inputData_href = dclone($edr4ad_sil_input::inputData_href);
    
    delete $INC{$input_File};

    my $data_temp_href;

    #loop over the keys of signal value hash
    foreach my $sig ( keys %$extracted_inputData_href ) {        

        if ( $sig eq 'SignalSet_randomValues' ) {
            my $file = $extracted_inputData_href->{$sig}{file};
            $file =~ s/\\+/\//g;

            require $file;
            our $inputDataRandom_href;

            $extracted_inputData_href = dclone($edr4ad_sil_input::inputDataRandom_href);
            
            delete $INC{$file};
            
            foreach my $random_sig ( keys %$extracted_inputData_href ) {
                extract_and_format_inputdata( $extracted_inputData_href, $random_sig );    #Generate random values
            }
        }
        elsif ( $sig eq 'Test_Case_Name' ) {
            $data_href->{Test_Case_Name} = $extracted_inputData_href->{Test_Case_Name};    #Store the testcase name
            next;
        }
        else {
            extract_and_format_inputdata( $extracted_inputData_href, $sig );               #Generate ramp values
        }
    }

    #Find the maximum nbr of signals to write to csv to maintain uniformity for all signals
    @temp_arraysize = sort { $a <=> $b } @temp_arraysize;
    $arraysize      = $temp_arraysize[$#temp_arraysize];

    #append the last value of the signal to make nbr of values for all signals equal
    foreach my $sig ( keys %{ $data_href->{sig} } ) {
        my $nbr_of_val = $data_href->{sig}{$sig}{nbr_of_val};
        if ( $nbr_of_val < $arraysize ) {
            $main->messageBox( -icon => "info", -message => "The signal $sig has less datavalues compared to other signal(s)", -title => 'Finished' );

            for ( my $i = 0 ; $i < $arraysize - $nbr_of_val ; $i++ ) {
                push( @{ $data_href->{sig}{$sig}{'val'} }, $data_href->{sig}{$sig}{'val'}[-1] );
            }
        }

        #make the time according to the simulation time
        my @time_stamps_ms;
        my $time = 0;
        foreach ( 0 .. $arraysize - 1 ) {
            $time = $_ * $simulation_time_ms;
            push( @time_stamps_ms, $time );

        }
        undef @{ $data_href->{sig}{$sig}->{'time'} };
        @{ $data_href->{sig}{$sig}->{'time'} } = @time_stamps_ms;
        $data_href->{sig}{$sig}{nbr_of_val} = $arraysize;

    }
    return 1;
}

=head2 extract_and_format_inputdata

 Function Name   : extract_and_format_inputdata

 Description     : converts the signals data in the file provided by the user in the below mentioned format
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }

 Syntax          : extract_and_format_inputdata()

 Input Arguments : data fetched from the input file provided by the user

 Return Value(s) : $data_href as mentioned in the description

 Example         : extract_and_format_inputdata();

=cut

sub extract_and_format_inputdata {

    my $inputdata_href           = shift @_;
    my $sig                      = shift @_;
    my $extracted_inputData_href = $inputdata_href;

    my ($data_temp_href);
    my $curveFileName;
    
    delete $data_href->{sig}{$sig} if(exists $data_href->{sig}{$sig});

    foreach my $data ( @{ $extracted_inputData_href->{$sig}{data} } ) {

        $data =~ s/\s+//g;

        my $curveStruct_href = { 1 => $data };
        $curveFileName = LC_PowerGenCurve($curveStruct_href);
        my ( $sig_val_aref, $time_val_aref ) = extract_dataFromCurveFile($curveFileName);

        undef $data_temp_href;

        @{ $data_temp_href->{$sig}->{'val'} }  = @$sig_val_aref;
        @{ $data_temp_href->{$sig}->{'time'} } = @$time_val_aref;

        my $output_href = resample_data( $data_temp_href->{$sig}->{'val'}, $data_temp_href->{$sig}->{'time'}[1] );

        foreach my $val ( @{ $output_href->{dataOutValues_aref} } ) {
            $val = NUM_round2Int($val);
        }
        push( @{ $data_href->{sig}{$sig}->{'val'} },  @{ $output_href->{dataOutValues_aref} } );
        push( @{ $data_href->{sig}{$sig}->{'time'} }, @{ $output_href->{dataOutTimes_aref} } );
        $data_href->{sig}{$sig}->{'unit'} = $extracted_inputData_href->{$sig}{unit};

        $data_href->{sig}{$sig}{'nbr_of_val'} = scalar( @{ $data_href->{sig}{$sig}{'val'} } );
        push( @temp_arraysize, $data_href->{sig}{$sig}{'nbr_of_val'} );

    }
    unlink($curveFileName);
}

=head2 write_data_to_csv

 Function Name   : write_data_to_csv

 Description     : write the data in the signals hashref to csv file
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }

 Syntax          : write_data_to_csv()

 Input Arguments : $data_href = hash reference containing signal info

 Return Value(s) : csv file containing the signal data

 Example         : write_data_to_csv();
 
=cut

sub write_data_to_csv {

    my @endmarker;

    if ( -e $output_file ) {
        unlink $output_file;
    }

    open FH1, ">$output_file";

    #print the testcase name
    if ( exists $data_href->{Test_Case_Name} ) {
        print FH1 $data_href->{Test_Case_Name};
        print FH1 "\n";
    }

    #print the signal names
    my $sig_name_str = join ';', keys %{ $data_href->{sig} };    # revert
                                                                 #my @temp_sig = ('RCM_MajorImpact','RCM_MinorImpact','PowerLoss','NetworkLoss');
                                                                 #my $sig_name_str = join ';', @temp_sig; # revert
    print FH1 $sig_name_str;
    print FH1 "\n";

    my @units;

    #fetch units
    foreach my $sig ( keys %{ $data_href->{sig} } ) {

        #foreach my $sig (@temp_sig ) {
        push( @units, $data_href->{sig}{$sig}{unit} );
    }

    #print the units
    if ( scalar( grep { defined } @units ) ) {
        my $unit_str = join ';', @units;
        print FH1 $unit_str;
        print FH1 "\n";
    }

    #print the signal values
    foreach my $index ( 0 .. $arraysize - 1 ) {
        my @sig_values;
        my $sig_value;
        undef @endmarker;
        foreach my $sig ( keys %{ $data_href->{sig} } ) {

            #foreach my $sig ( @temp_sig ) {
            push( @sig_values, $data_href->{sig}{$sig}->{'val'}[$index] );
            push( @endmarker,  100 );                                        #endmarker
        }
        $sig_value = join ';', @sig_values;
        print FH1 $sig_value;
        print FH1 "\n";
    }
    print FH1 join ';', @endmarker;

    close FH1;
}

=head2 Convert_data_to_cbor_format

 Function Name   : Convert_data_to_cbor_format

 Description     : converts signals hashref to cbor format
 
                   $data_href=>{
                      Test_case_Name => "EventMonitor", 
                      sig => {
                          sig_name1 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },
                          sig_name2 => {
                              nbr_of_val => 2250,
                              time => [1,2,3...],
                              val => [1,2,3...],
                              unit => lsb                              
                          },                          
                      }
                   }

 Syntax          : Convert_data_to_cbor_format()

 Input Arguments : $data_href = hash reference containing signal info

 Return Value(s) : cbor format of the $data_href

 Example         : Convert_data_to_cbor_format();
 
=cut

sub Convert_data_to_cbor_format {

    my $dataToBeConvertedToCBOR_href;
    my $cbor_file_path = $output_file;
    $cbor_file_path =~ s/\.csv$/\.txt/;

    my $index = 0;

    my @signals = keys %{ $data_href->{sig} };
    my @time    = @{ $data_href->{sig}->{ $signals[0] }->{'time'} };
    @time = @time[ 0 .. $arraysize - 1 ];

    foreach my $time (@time) {

        foreach my $sig (@signals) {

            $dataToBeConvertedToCBOR_href->{ $index + 1 }{$sig} = $data_href->{sig}{$sig}->{'val'}[$index];
        }
        $index++;
    }

    my $binary_cbor_data = encode_cbor $dataToBeConvertedToCBOR_href;

    if ( -e $cbor_file_path ) {
        unlink $cbor_file_path;
    }

    open FH1, ">$cbor_file_path";
    print FH1 $binary_cbor_data;
    close FH1;

    open FH1, '<C:\Temp\LIFT\Signal_cbor.txt';
    my $decoded_href = decode_cbor <FH1>;
    close FH1;

}

#####################################################################################
# This function resamples the input data
#####################################################################################
sub resample_data {

    my $dataIn_aref = shift @_;
    my $dtIn_sec    = shift @_;
    my $dtOut_sec   = shift @_;

    my $args_href = {
        'dataIn_aref' => $dataIn_aref,                  # input data, to be resampled (type: floating point)
        'dtIn_sec'    => $dtIn_sec,                     # input cycle
        'dtOut_sec'   => $simulation_time_ms / 1000,    # desired output cycle,
    };

    return NUM_ResampleData($args_href);

}

=head2 extract_dataFromCurveFile

 Function Name   : extract_dataFromCurveFile

 Description     : extracts data from .sat file and returns as an array reference

 Syntax          : extract_dataFromCurveFile($curveFileName)

 Input Arguments : $curveFileName

 Return Value(s) : array reference of signals and time data present in curve file

 Example         : extract_and_format_inputdata();

=cut

sub extract_dataFromCurveFile {

    my $curveFileName = shift @_;

    unless ( -e $curveFileName ) {
        print "File doesnt exist";
    }

    open FH, "<", $curveFileName;
    my @lines = <FH>;
    close FH;

    my @sig_values;
    my @time_values;

    foreach my $line (@lines) {
        chomp($line);

        next if ( $line =~ /Dateiname|Punkte|Strombegrenzung|Wiederholungen|U\[V\]/ );

        if ($line) {
            my @data = split /\s/, $line;

            push( @sig_values,  $data[0] );
            push( @time_values, $data[4] );

        }
    }

    return \@sig_values, \@time_values;

}

=head2 NUM_round2Int

 Function Name   : NUM_round2Int

 Description     : Rounds floating point value to integer

 Syntax          : $iVal = NUM_round2Int($dblVal)

 Input Arguments : $dblVal = floating point value

 Return Value(s) : $iVal   = �nteger value

 Example         : 5 = NUM_round2Int(4.5);
 
 Source: LIFT_numerics.pm
 TurboLIFT Revision: 1.19

=cut

sub NUM_round2Int {
    my $dblVal = shift;

    my $roundedInt = 0;

    # Round double value to integer
    if ( $dblVal >= 0.0 ) {
        $dblVal += $NUM_ROUND_THRESHOLD;
    }
    else {
        $dblVal -= $NUM_ROUND_THRESHOLD;
    }

    # If necessary, limit it to interval [$intMin, $intMax]
    if ( $dblVal > $NUM_SYS_INT_MAX ) {
        $dblVal = $NUM_SYS_INT_MAX;
    }
    elsif ( $dblVal < $NUM_SYS_INT_MIN ) {
        $dblVal = $NUM_SYS_INT_MIN;
    }

    $roundedInt = int($dblVal);

    return $roundedInt;
}

=head2 LC_PowerGenCurve

	($curveFileName) = LC_PowerGenCurve( $curveStruct_href,[$filename] );
	
Creates a Ramp or Random curve or both and returns the $curveFileName of the curve generated.
The $curveFileName gives complete path of generated file.

B<Arguments:>

=over

=item $curveStruct_href

Hash reference containing curve parameters that are to be generated.

# Format and example

($curveFileName) = LC_PowerGenCurve( $curveStruct_href,[$filename] );
  
  $curveStruct_href = {
   1 => 'Ramp : start_Voltage (V): End_Voltage(V) : Time_Duration(s) : [no_of_samples]',
   2 => 'Random : ONMax(ms) : ONmin(ms) : OFFmax(ms) : OFFmin(ms) : Von_max(V) :  Von_min(V) : Voff_max(V) : Voff_min(V): $max_duration(s)',
     
  }; 

Ramp -> start_Voltage (V), End_Voltage(V) , Time_Duration(s) , [no_of_samples]
   
   start_Voltage (V)       -  Start voltage of Ramp in Volts
   End_Voltage(V)          -  End voltage of Ramp in Volts
   Time_Duration(s)        -  Time duration in s
   [no_of_samples]optional -  No of samples in ramp curve.
   
Random -> ONMax(ms) , ONmin(ms) ,OFFmax(ms), OFFmin(ms),Von_max(V), Von_min(V),Voff_max(V), Voff_min(V), $max_duration(s)
   
   ONMax(ms)  -  Maximum ON time in milliseconds.
   ONmin(ms)  -  Minimum ON time in milliseconds.
   OFFmax(ms) -  Maximum OFF time in milliseconds.
   OFFmin(ms) -  Minimum OFF time in milliseconds.
   
   Von_max(V) -  Max ON voltage.
   Von_min(V) -  Min ON Voltage. 
   Voff_max(V)-  Max OFF voltage.
   Voff_min(V)-  Min OFF Voltage.
   $max_duration(s) - Max Duration in seconds.
   
Eg: Only Ramp Curve

   $curveStruct_href = {
    1 => 'Ramp:12.6 : 3.8 : 3.6 ',    
  }

=for html
<IMG SRC='..\..\pics\Ramp.jpg'  alt="Ramp Curve" border="0">
<br><br>

Eg: Only Random Curve

   $curveStruct_href = {
   1 => 'Random:3000:2000:700:500:12.5:10.8:6.5:3:60, 
  }
  
=for html
<IMG SRC='..\..\pics\Random.jpg'  alt="Random curve" border="0">
<br><br>

Eg: Both Ramp and Random Curve, number curves as per required sequence

  $curveStruct_href = {
    1 => 'Ramp:12.6 : 3.8 : 3.6 ',    
    2 => 'Random:3000:2000:700:500:12.5:10.8: 0.5 :0:60, 
    3 => 'Ramp:1.6 : 3.8 : 2.8  ', 
    4 => 'Random:1500:800:700:500:12.5 :10.8: 0.5 :0:30,
  }


If the Power device used is toellner or TSG4, the device can run Max 1000 points(Limitation of Toellner and TSG4).
In this case, use optional parameters for 'Ramp' to accomodate multiple curves together as mentioned in Below example.
If no_of_samples are mentioned,so many no of samples will used to generate that particular curve ( min no_of_samples >= 50)  

Eg: Multiple curves and no. of samples mentioned for ramp curve.

    $curveStruct_href = {

    1 => 'Ramp:12.6 : 3.8 : 3.6 :100',
    2 => 'Ramp:1.6 : 3.8 : 2.8 : 100',	
    3 => 'Random:1500:800:700:500:12.5 :10.8: 0.5 :0:30,
}


=item $filename

Optional parameter : voltage curve file name eg: Curvefile.sat (only .sat extension is supported)
if not defined, by default takes MyCustomCurve.sat as Curve filename

=back

B<Return Value:>

=over

=item ($curveFileName)

On success : Complete path of Curve filename (with Timestamp)

           e.g. : 'D:/TurboLIFT_Sandbox/Projects/TSG4/reports/TL_LRT_20170720_095810/20170720_095904_MyCustomCurve.sat'
           
On error : 0

=back

B<Notes:> 

Curve file will be stored in main reports path.

Configuring and Running the curve with power dynamic device (TSG4 or NIDAQ or TOELLNER) should be explicitly done after this function call.

Source: LIFT_labcar.pm
TurboLIFT Revision: 1.74

=cut

sub LC_PowerGenCurve {
    my @args = @_;

    #Curve files can be generated offline and does not Require LC_Init();
    my ($curveStruct_href) = shift @args;

    #COMMENT-START
    # Get all the arguments
    # mandatory
    # - $curveStruct_href,
    # optional
    # - $filename
    #COMMENT-END
    my ( $volt_aref, $time_aref, @volt_levels, @timesteps );
    my $status = 0;
    my $curve_type;
    my $filename;
    my @curve_item_arg;

    #STEP check if filename is defined and if it is a .sat
    $filename = $output_file;
    $filename =~ s/.csv$/.sat/;

    # IF no. of sub-curves >1
    # IF-YES-START
    #    CALL CheckandUpdateParamters
    # IF-YES-END
    # IF-NO-START
    # IF-NO-END

    my $no_sub_curves = keys %$curveStruct_href;
    if ( $no_sub_curves > 1 ) {
        $curveStruct_href = CheckandUpdateParamters($curveStruct_href);
    }
    return 0 if $curveStruct_href == 0;

    #LOOP-START loop through contents of HASH and call curresponding curve function

    foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {
        my $curve_item = $$curveStruct_href{$key_of_hash};
        @curve_item_arg = split /:/, $curve_item;
        $curve_type = $curve_item_arg[0];

        shift @curve_item_arg;
        foreach (@curve_item_arg) {
            if ( $_ !~ /^\s*\d+((.|,)\d+)?\s*$/ ) {

                #S_set_error( "LC_PowerGenCurve : $_ is not a valid Numeric input", 114 );
                #return $status;
            }
        }

        # IF type of the curve is random
        # IF-YES-START
        #      CALL CreateRandomOnOffCurve
        # IF-YES-END
        if ( $curve_type =~ /Random$/ ) {
            ( $status, $volt_aref, $time_aref ) = CreateRandomOnOffCurve( \@curve_item_arg );
        }

        # IF-NO-START
        # IF type of the curve is ramp
        # IF-YES-START
        #      CALL CreateRampCurvefile
        # IF-YES-END
        elsif ( $curve_type =~ /Ramp$/ ) {
            ( $status, $volt_aref, $time_aref ) = CreateRampCurve( \@curve_item_arg );
        }

        # IF-NO-START
        #      STEP ERROR : Wrong curvetype
        # IF-NO-END
        # IF-NO-END
        else {
            #S_set_error( "LC_PowerGenCurve : Wrong Curve type given : $curve_type", 114 );
            #return $status;
        }

        if ( $status > 0 ) {
            push( @volt_levels, @$volt_aref );
            push( @timesteps,   @$time_aref );
        }
        else {
            #S_set_error( " LC_PowerGenCurve : Creation of curve file failed", 23 );
            #return $status;
        }
    }

    #LOOP-END end of hash
    #STEP Dump all curve points to curve
    if ( open( OUT, ">$filename" ) ) {
        print OUT "Dateiname:       $filename\n";
        print OUT "Punkte:          " . scalar(@timesteps) . "\n";
        print OUT "Strombegrenzung: 1\n";
        print OUT "Wiederholungen:  1\n\n";
        print OUT "U[V]    t[s]\n\n";

        for ( my $i = 0 ; $i < @timesteps ; $i++ ) {
            print OUT "$volt_levels[$i]    $timesteps[$i]\n";
        }
        close(OUT);
    }
    else {
        #S_set_error( "LC_PowerGenCurve : could not open out file $filename", 1 );
        #return $status;
    }

    #S_w2log( 5, "LC_PowerGenCurve:  Created a curve file with name $filename \n" );

    #STEP Set a warning if no of samples in curve is >1000
    my $total_pts_curve = scalar @volt_levels;
    if ( scalar @volt_levels > 1000 ) {

        #S_set_warning( "no_of_samples in curve  > 1000, this may only work with NIDAQ", 114 );
    }

    #S_w2log( 5, "LC_PowerGenCurve:  Total no of points in curve : $total_pts_curve \n" );
    return $filename;
}

=head2 CreateRandomOnOffCurve

    ( $status , $volts_aref , $time_aref ) = CreateRandomOnOffCurve( $max_on_voltage, $min_on_voltage,$max_off_voltage , $min_off_voltage, $max_duration );
    e.g. CreateRandomOnOffcurve( 3000, 2000, 700, 500, 12.5, 10.8,1.5,0, 60);

create random voltage curve file (switching on and off at random voltage level for random time under given Boundary conditions).

time $max_on_time,$min_on_time,$max_off_time,$min_off_time in msec, voltage $max_on_voltage, $min_on_voltage,$max_off_voltage ,$min_off_voltage in V and $max_duration in seconds

Source: LIFT_labcar.pm
TurboLIFT Revision: 1.74

=cut

sub CreateRandomOnOffCurve {

    my @args = @_;

    my $randon_inputs_aref = shift @args;
    my @random_curve_input = @$randon_inputs_aref;

    #STEP Get all the mandatory arguments for Random curve
    my ( $valMax, $valMin, $max_duration ) = @random_curve_input;

    my $status = 0;
    my ( @volts, @time );

    #S_w2log( 3,"createRandomOnOffCurve with Paramters :  ON($max_on_time - $min_on_time) OFF($max_off_time - $min_off_time) V_ON($max_on_voltage - $min_on_voltage) V_OFF($max_off_voltage - $min_off_voltage )  MAXduration $max_duration\n");

    my ( $points, $duration );

    $duration = 0;
    $points   = 0;

    # STEP Generate curve points upto max duration
    while ( $duration < $max_duration and $points <= 1000 ) {

        my $val = rand( $valMax - $valMin ) + $valMin;

        #$duration += ($on_time + $off_time);

        if ( $duration < $max_duration ) {
            push( @volts, $val );
            push( @time,  $duration );
            $points++;
        }
        $duration += $simulation_time_ms / 1000;
    }

    $status = 1;

    #S_w2log( 5, "createRandomOnOff Points status - $status \n" );

    # STEP Return the voltage and time values
    return ( $status, \@volts, \@time );
}

=head2 CreateRampCurve

    ( $status , $volt_aref, $time_aref ) = CreateRampCurve($start_V, $end_V, $time_s, [$no_of_samples]);
    e.g.
    ( $status , $volt_aref, $time_aref) = CreateRampCurve(0,1.2,1,500);
    ( $status , $volt_aref, $time_aref) = CreateRampCurve(3.0,5.2,2,500);                       

($start_V, $end_V, $time_s, $no_of_samples)

Time in seconds, start_V/end_V in volts, $no_of_samples in samples. ($no_of_samples >= 50,  <= 1000)

Time delta between 2 points has to be between 0.2 ms and 100 s.

Returns:Status, $volt_aref, $time_aref

Source: LIFT_labcar.pm
TurboLIFT Revision: 1.74

=cut

sub CreateRampCurve {

    my @args             = @_;
    my $ramp_inputs_aref = shift @args;
    my @ramp_curve_arg   = @$ramp_inputs_aref;

    #STEP Get all the mandatory arguments for Ramp curve
    my $status = 0;
    my @volts;
    my @time;

    #checking the correctness of the inputs

    my ( $start_V, $end_V, $time_s, $no_of_samples ) = @ramp_curve_arg;

    $no_of_samples = 1000 unless ( defined $no_of_samples );

    #S_w2log( 3,"CreateRampCurve with Paramters : Start voltage = $start_V  End voltage = $end_V  Time duration = $time_s no. of samples = $no_of_samples \n");

    #STEP Check for correctness of paramters

    # IF Check for correctness of paramters no_of_samples and timedelta
    # IF-YES-START
    # IF-YES-END

    # IF-NO-START
    # STEP Set Error and return status
    # IF-NO-END

    if ( $no_of_samples < 50 ) {

        #S_set_error( "too less no of samples to plot ramp : $no_of_samples < 50", 114 );
        #return $status;
    }

    my $timedelta = $time_s / $no_of_samples;

    if ( $timedelta < 0.0002 ) {

        #S_set_error( "error in RampStruct, timedelta $timedelta < 0.0002", 109 );
        #return $status;
    }
    if ( $timedelta > 100 ) {

        #S_set_error( "error in RampStruct, timedelta $timedelta > 100", 109 );
        #return $status;
    }
    my $time_value_s = 0;
    $time_value_s += $timedelta;
    $start_V = sprintf( "%.3f", $start_V );
    push( @volts, $start_V );
    $time_value_s = sprintf( "%.4f", $time_value_s );
    push( @time, $time_value_s );

    #LOOP-START Generate ramp curve points
    # STEP Calculate voltage values and push data into array
    #LOOP-END Till end of samples

    foreach my $count ( 1 .. ( $no_of_samples - 1 ) ) {

        my $volt_value_V = $start_V + ($count) / ($no_of_samples) * ( $end_V - $start_V );
        $volt_value_V = sprintf( "%.3f", $volt_value_V );
        $time_value_s = sprintf( "%.4f", $time_value_s );
        push( @volts, $volt_value_V );
        push( @time,  $time_value_s );
    }
    $status = 1;

    #STEP Return values of voltage and time
    return ( $status, \@volts, \@time );
}

=head2 CheckandUpdateParamters

    $modified_curveStruct_href = CheckandUpdateParamters($curveStruct_href );
    
Checks and updates paramters if no of sub curves in LC_PowerGenCurve is more than 1.

B<Arguments:>

=over

=item $curveStruct_href

for details on $curveStruct_href,  Refer : L</"LC_PowerGenCurve"> 

=back

B<Return Value:>

=over

=item ($modified_curveStruct_href)

On success : Updated paramter of $curveStruct_href
           
On error : 0

=back

=cut

sub CheckandUpdateParamters {
    my @args             = @_;
    my $curveStruct_href = shift @args;

    #STEP Get all the mandatory arguments for CheckandUpdateParamters
    my $max_samples               = 0;
    my $not_defined_ramps_samples = 0;

    #LOOP-START loop through contents of HASH and check for paramters and calculate max samples
    foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {
        my $curve_item     = $$curveStruct_href{$key_of_hash};
        my @curve_item_arg = split /:/, $curve_item;
        my $curve_type     = $curve_item_arg[0];

        shift @curve_item_arg;

        #STEP check if all paramters are numeric
        foreach (@curve_item_arg) {
            if ( $_ !~ /^\s*\d+((.|,)\d+)?\s*$/ ) {

                #S_set_error( "LC_PowerGenCurve : $_ is not a valid Numeric input", 114 );
                #return 0;
            }
        }

        #STEP Calculate maximum curve points from the input and calculate no of ramps for which there is no sample given
        if ( $curve_type =~ /Random$/ ) {
            foreach my $count ( 0 .. 8 ) {
                unless ( defined $curve_item_arg[$count] ) {

                    #S_set_error("check arguments : syntax : CreateRandomOnOffFile( ONmax, ONmin, OFFmax, OFFmin, Von_max, Von_min, Voff_max, Voff_min, MAXduration ) ",114);
                    #return 0;
                }
            }
            $max_samples += ( $curve_item_arg[8] * 2 * 1000 ) / ( $curve_item_arg[1] + $curve_item_arg[3] );

            # Multiplying by 2 to include ON and OFF values in Random curve
            # Multiplying by 1000 - as MaxDuration i.e. $curve_item_arg[8] is in seconds while others are in milliseconds
        }
        elsif ( $curve_type =~ /Ramp$/ ) {
            foreach my $count ( 0 .. 2 ) {
                unless ( defined $curve_item_arg[$count] ) {

                    #S_set_error("check arguments : syntax : CreateRampCurvefile( start_V, end_V, time_s[,no_of_samples])",114 );
                    #return 0;
                }
            }
            if ( defined $curve_item_arg[3] ) {
                $max_samples += $curve_item_arg[3];
            }
            else {
                $not_defined_ramps_samples += 1;
            }
        }
        else {
            #S_set_error( "LC_PowerGenCurve : Wrong Curve type given : $curve_type", 114 );
            #return 0;
        }

    }

    #LOOP-END end of hash

    # IF max samples is 1000 and Not defined ramps >0
    if ( $max_samples <= 1000 && $not_defined_ramps_samples > 0 ) {

        # STEP divide the remaining curve points to rest of ramps
        my $rem_samples      = 1000 - $max_samples;
        my $samples_per_ramp = int $rem_samples / $not_defined_ramps_samples;

        if ( $samples_per_ramp < 50 ) {

            #S_set_error("LC_PowerGenCurve : Too less curve samples for undefined ramp curves to plot : $samples_per_ramp ",114 );
            #return 0;
        }

        # STEP Loop through input for all undefined ramp-sub-curves and update
        foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {

            my $curve_item     = $$curveStruct_href{$key_of_hash};
            my @curve_item_arg = split /:/, $curve_item;
            my $curve_type     = $curve_item_arg[0];

            if ( $curve_type =~ /Ramp$/ && ( not defined $curve_item_arg[4] ) ) {
                $$curveStruct_href{$key_of_hash} .= ": $samples_per_ramp ";

            }
        }
    }

    # IF-YES-END
    # IF-NO-START
    # IF-NO-END

    # STEP Return modified input
    return $curveStruct_href;
}

=head2 NUM_ResampleData

Resamples the data to required cycle time, using linear interpolation.

    Syntax : $retVals_href = NUM_ResampleData( $args_href )

Input Arguments :

   $args_href = {
        'dataIn_aref'      =>  $dataIn_aref,      # input data, to be resampled (type: floating point)
        'dtIn_sec'         =>  $dtIn_sec,         # input cycle
        'dtOut_sec'        =>  $dtOut_sec,        # desired output cycle,
        'dtResolution_sec' =>  $dtResolution_sec, # OPTION: Used for adapting the resolution of dtOut_sec,
                                                  # if it is required to have a defined output rate resolution.
                                                  # Choose a value, which avoids integer overflow in fraction
                                                  # dtOut_sec / dtResolution_sec < INT_MAX(=2147483647)
                                                  # and take care dtOut_sec > dtResolution_sec
                                                  # (the smaller, against dtOut_sec, the better;
                                                  # typically used examples: 1E-6, 1E-9, 1E-12)
                                                  # DEFAULT, if omitted: dtOut_sec / (INT_MAX-1)
                                                  # (-1 avoids rounding effects at the border value)
   }

Return values :

   $retVals_href  = {
       'status'       => $status,    # -1: Error with input argument args_href
                                     # -2: Integer overflow, try different dtResolution_sec,
                                     #     which is closer to dtOut_sec
                                     #  0: no re-sampling done, because unnecessary
                                     #  1: re-sampling done
       'dataOutValues_aref' => [],   # Array reference to resampled data (type: floating point)
       'dataOutTimes_aref'  => []    # Array reference to new time values (type: floating point)
   }

Example (success) :

    # Doubles the sampling rate
    $retVals_href = NUM_ResampleData(
                                        {
                                        'dataIn_aref'        => [1, 2, 3, 4, 5], 
                                        'dtIn_sec'           => 2.4,
                                        'dtOut_sec'          => 1.2,
                                        'dtResolution_sec'   => 0.1,
                                        }
    );

    $retVals_href = {
        'status'             => 1,
        'dataOutValues_aref' => [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.0]
        'dataOutTimes_aref'  => [0.0, 1.2, 2.4, 3.6, 4.8, 6.0, 7.2, 8.4, 9.6, 10.8]
    }

Return values (error) :

    $retVals_href = 0 : Error with keys inside argument hash (wrong keys listed in error message in report)

    $retVals_href->{'status'} = -1 : Error with input argument 'args_href' itself

    $retVals_href->{'status'} = -2 : 'dtResolution_sec' out of range: [dtOut_sec / (INT_MAX-1) ... dtOut_sec].
    
Source: LIFT_numerics.pm
TurboLIFT Revision: 1.19 

=cut

sub NUM_ResampleData {
    my @args = @_;
    my %retVals_href;

    #    unless ( S_checkFunctionArguments( 'NUM_ResampleData( $args_href )', @args ) ) {
    #        $retVals_href{'status'} = $NUM_ERR_CODE_1;
    #        return ( \%retVals_href );
    #    }

    my $inArgs_href = shift;

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'dataIn_aref'      => 1,
        'dtIn_sec'         => 1,
        'dtOut_sec'        => 1,
        'dtResolution_sec' => 1
    };
    my $mandatory_keys = {
        'dataIn_aref' => 1,
        'dtIn_sec'    => 1,
        'dtOut_sec'   => 1
    };

    #    return 0 unless S_checkFunctionArgumentHashKeys( "NUM_ResampleData", $inArgs_href, $valid_in_arg_keys, $mandatory_keys );

    my $dataIn_aref      = $inArgs_href->{'dataIn_aref'};         # signal data to sample array reference
    my $dtIn_sec         = $inArgs_href->{'dtIn_sec'};            # cycle_time data in
    my $dtResolution_sec = $inArgs_href->{'dtResolution_sec'};    # min resolution
    my $dtOut_sec        = $inArgs_href->{'dtOut_sec'};           # cycle time data out
    my $status           = $NUM_ERR_CODE_1;
    my ( $resampleFactor, $quotient, $delta, $dtOutInMinResolution_sec, @dataOut, $numPtsOut, $numPtsIn );

    unless ( ref $dataIn_aref eq "ARRAY" ) {

        # S_set_error( "dataIn_aref is not an array reference \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    $numPtsIn = scalar(@$dataIn_aref);
    if ( $numPtsIn <= 0 ) {

        #S_set_error( "dataIn_aref is an empty array reference \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    if ( $dtIn_sec <= 0 ) {

        #        S_set_error( "dtIn_sec should be greater than zero \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    if ( not defined $dtResolution_sec ) { $dtResolution_sec = $dtOut_sec / ( $NUM_SYS_INT_MAX - 1 ); }

    if ( $dtResolution_sec <= 0 ) {

        #        S_set_error( "dtResolution_sec should be greater than zero \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_1;
        return ( \%retVals_href );
    }

    #    S_w2log( 1, "No of points :: $numPtsIn \n" );

    $quotient = $dtOut_sec / $dtResolution_sec;

    if ( $quotient < 1 || $quotient > $NUM_SYS_INT_MAX ) {
        my $minRes = $dtOut_sec / ( $NUM_SYS_INT_MAX - 1 );

        #        S_set_error( "dtResolution_sec = $dtResolution_sec s out of allowed range: [$minRes s ... $dtOut_sec s], see hint in API documentation \n", 114 );
        $retVals_href{'status'} = $NUM_ERR_CODE_2;
        return ( \%retVals_href );
    }

    $quotient = NUM_round2Int($quotient);

    $dtOutInMinResolution_sec = $quotient * $dtResolution_sec;
    $resampleFactor           = $dtOutInMinResolution_sec / $dtIn_sec;
    $delta                    = abs( $resampleFactor - 1.0 );

    if ( $delta > $NUM_EPSILON_1E_MINUS_6 ) {
        $status    = 1;                                              #re-sampling necessary
        $numPtsOut = NUM_round2Int( $numPtsIn / $resampleFactor );
    }
    else {
        $status = 0;                                                 #re-sampling unnecessary
    }

    if ( $status == 1 ) {
        foreach my $i ( 0 .. $numPtsOut - 1 ) {

            #Calculate next x0, x, x1, based on next index and re-sampling factor
            #Converted x-position used as basis to calculate the re-sampled curve
            my $x  = $i * $resampleFactor;
            my $x0 = int($x);                #integral value (index) left from x
            my $x1 = $x0 + 1;                #integral value (index) right from x

            #if x0 and x1 are both within pdDataIn
            if ( $x1 < $numPtsIn ) {

                #Calculate output curve from input curve by linear interpolation
                $dataOut[$i] = $$dataIn_aref[$x0] + ( $x - $x0 ) * ( $$dataIn_aref[$x1] - $$dataIn_aref[$x0] );
            }
            elsif ( $x0 < $numPtsIn ) {
                $dataOut[$i] = $$dataIn_aref[$x0];
            }
        }

        # Last point in output and input shall be identical
        $delta = abs( $dataOut[-1] - $$dataIn_aref[-1] );
        if ( $delta > $NUM_EPSILON_1E_MINUS_6 ) {
            $dataOut[-1] = $$dataIn_aref[-1];
        }
    }
    else {
        @dataOut = @$dataIn_aref;    # output = Input  as no re-sampling needed
                                     #S_w2log( 1, "As no re-sampling needed Output data is same as Input data\n" );
    }

    my @timeOut_s;
    foreach my $i ( 0 .. scalar(@dataOut) - 1 ) {
        $timeOut_s[$i] = $i * $dtOutInMinResolution_sec;
    }

    $retVals_href{'status'}             = $status;
    $retVals_href{'dataOutValues_aref'} = \@dataOut;
    $retVals_href{'dataOutTimes_aref'}  = \@timeOut_s;

    return ( \%retVals_href );
}
