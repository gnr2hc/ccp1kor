use strict;
use warnings;
use Device::Modbus::TCP::Server;
 
my $serverPort = 503;
my $hex2floatFactor = 0.01;
my $readTempAddr    = 0x00A0;
my $writeTempAddr   = 0x06CE;
my $writeActiveAddr = 0x00C8;
my $readTemperature = -10;

{
    package My::Unit;
    our @ISA = ('Device::Modbus::Unit');
 
    sub init_unit {
        my $unit = shift;
 
        #                Zone            addr           qty   method
        #           -------------------  ----           ---  ---------
        $unit->get('holding_registers',  $readTempAddr,  1,  'get_temperature');
        $unit->put('holding_registers',  $writeTempAddr, 1,  'set_temperature');
        $unit->put('holding_registers',  $writeActiveAddr, 1,  'set_value_direct');
    }
 
    sub get_temperature{
        my ($unit, $server, $req, $addr, $qty) = @_;
        $server->log(4,"Executing get_temperature routine for address $addr: Responding with temperature $readTemperature deg C.");
        my $int = sprintf("%d", $readTemperature/$hex2floatFactor); # round to integer
        return ($int);
    }

    sub set_temperature{
        my ($unit, $server, $req, $addr, $qty, $values) = @_;
        
        my $int = $$values[0];
        if( $int & 0x8000 ) {
            $int = $int - 0x10000;
        }
        my $setTemperature = $int*$hex2floatFactor;
        $server->log(4,"Executing set_temperature routine for address $addr. Requested temperature is $setTemperature deg C.");
        return 1;
    }

    sub set_value_direct{
        my ($unit, $server, $req, $addr, $qty, $values) = @_;
        
        my $value = $$values[0];
        $server->log(4,"Executing set_value_direct routine for address $addr. Value written is $value.");
        return 1;
    }

}
 
my $server = Device::Modbus::TCP::Server->new(
    port      => $serverPort,
    log_level => 4,
    log_file  => 'modbus_logfile.txt'
);
 
my $unit = My::Unit->new(id => 1);
$server->add_server_unit($unit);
 
$server->start;