use strict;
use warnings;
use Net::TcpDumpLog;

my $log = Net::TcpDumpLog->new(); 
$log->read('C:\Users\phc2si\Documents\Tools\loopback.pcap');

my @indexes = $log->indexes;
foreach my $index ( @indexes ) {
    my ($length_orig,$length_incl,$drops,$secs,$msecs) = $log->header($index);
    my $data = $log->data($index);
    my $dataHex = uc unpack "H*", $data;
    $dataHex = join (' ', $dataHex =~ /(..)/g);
    print("$index : $dataHex\n");
    if( $dataHex =~ /AA/ ) {
        1;
    }
    1;
}

1;
