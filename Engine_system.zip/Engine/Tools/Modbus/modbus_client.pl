use strict;
use warnings;
use Device::Modbus::TCP::Client;
use Data::Dumper;

my $ipAddressChamber = '127.0.0.1'; 
my $portChamber = 503;      # 503-506 is possible
my $hex2floatFactor = 0.01; # either 0.01 or 0.1 depending on the chamber settings
my $readTempAddr    = 0x00A0;
my $writeTempAddr   = 0x06CE;
my $writeActiveAddr = 0x00C8;
my $client_href = {};
my $debugPrint = 1;

SetupClient();

ReadTemperature();

#SetChamberActive(1);

SetTemperature(-10);

#SetChamberActive(0);

print("READY.\n");


sub SetupClient{
    my $client = Device::Modbus::TCP::Client->new(
        host => $ipAddressChamber,
        port => $portChamber,
    );

    $client_href->{client} = $client;
    
    return 1;
}

sub ReadTemperature{
    print("Reading temperature...\n");
    my $values_aref = ReadHoldingRegisters(1, $readTempAddr, 1);
    
    my $int = $$values_aref[0];
    if( $int & 0x8000 ) {
        $int = $int - 0x10000;
    }
    my $readTemperature = $int*$hex2floatFactor;
    print("Read temperature: $readTemperature deg C\n");
    return $readTemperature;
}

sub SetTemperature{
    my $setTemperature = shift;

    print("Setting temperature $setTemperature deg C...\n");

    my $int = sprintf("%d", $setTemperature/$hex2floatFactor); # round to integer
    if( $int < 0 ) {
        $int += 0x10000;
    }

    WriteMultipleRegisters(1, $writeTempAddr, [$int],);

    print("Set temperature: finished\n");
    return 1;
}

sub SetChamberActive{
    my $activeFlag = shift;

    print("Switching chamber active to $activeFlag...\n");

    WriteMultipleRegisters(1, $writeActiveAddr, [$activeFlag]);

    print("Switching chamber finished\n");
    return 1;
}

sub ReadHoldingRegisters{
    my $unit = shift;
    my $address = shift;
    my $quantity = shift;

    my $client = $client_href->{client};

    my $readRequest = $client->read_holding_registers(
        unit     => $unit,
        address  => $address,
        quantity => $quantity,
    );

    my $values = SendRequestGetResponseValues($readRequest);

    return $values;    
}

sub WriteMultipleRegisters{
    my $unit = shift;
    my $address = shift;
    my $values_aref = shift;
    
    my $client = $client_href->{client};

    my $writeRequest = $client->write_multiple_registers(
        unit     => $unit,
        address  => $address,
        values   => $values_aref,
    );

    SendRequestGetResponseValues($writeRequest);

    return 1;
}

sub SendRequestGetResponseValues{
    my $request = shift;

    my $client = $client_href->{client};

    print("Request: ".Dumper($request)."\n") if $debugPrint;

    $client->send_request($request) || die "Send error: $!";
    my $response = $client->receive_response;
    print("Response: ".Dumper($response)."\n") if $debugPrint;
    my $values;
    if ($response->success) {
        $values = $response->values;
    }
    else{
        die "No successful response received: $!";
    }

    return $values;        
}

1;


=head1

Request read_holding_registers(unit => 1, address  => 0x00A0, quantity => 1)

Request: $VAR1 = bless( {
                 'unit' => 1,
                 'function' => 'Read Holding Registers',
                 'quantity' => 1,
                 'address' => 160,
                 'code' => 3
               }, 'Device::Modbus::Request' );

Response: $VAR1 = bless( {
                 'unit' => 1,
                 'length' => 5,
                 'id' => 1,
                 'message' => bless( {
                                       'bytes' => 2,
                                       'function' => 'Read Holding Registers',
                                       'values' => [
                                                     64536
                                                   ],
                                       'code' => 3
                                     }, 'Device::Modbus::Response' )
               }, 'Device::Modbus::TCP::ADU' );


Procedure
=========
Record communication on localhost (127.0.0.1) with RawCap.exe (version 0.2.0): RawCap_020.exe 127.0.0.1 loopback.pcap 
Start modbus_server.pl
Start modbus_client.pl
Stop recording
Decode IP messages in loopback.pcap with a Perl script using Net::TcpDumpLog (pcap.pl)


IP-Request read_holding_registers(unit => 1, address  => 0x00A0, quantity => 1)
45 00 00 40 07 0F 40 00 80 06 00 00 7F 00 00 01 7F 00 00 01 CC 67 01 F7 76 ED 99 7E 9A 7A 4E AC 80 18 03 FF 99 BD 00 00 01 01 08 0A 01 21 87 8A 01 21 87 81 00 01 00 00 00 06 01 03 00 A0 00 01
IPv4  <len> <id > <frg>   tcp <chk> <Src-Addr > <Dest-Addr> <spt> <dpt> < seq-nr  > < ack-nr  > of fl <win> <chk> <urg> <opt> <        time stamp         > <               modbus data       >

modbus-data:
00 01 00 00 00 06 01 03 00 A0 00 01
<Tid> <Pid> <len> un fc <adr> <qua>
fc=3: Read Holding Registers


IP-Response:
45 00 00 3F 07 11 40 00 80 06 00 00 7F 00 00 01 7F 00 00 01 01 F7 CC 67 9A 7A 4E AC 76 ED 99 8A 80 18 04 FE 7E 3A 00 00 01 01 08 0A 01 21 87 A0 01 21 87 8A 00 01 00 00 00 05 01 03 02 FC 18
IPv4  <len> <id > <frg>   tcp <chk> <Src-Addr > <Dest-Addr> <spt> <dpt> < seq-nr  > < ack-nr  > of fl <win> <chk> <urg> <opt> <        time stamp         > <            modbus data       >

modbus-data:
00 01 00 00 00 05 01 03 02 FC 18
<Tid> <Pid> <len> un fc by <data>
fc=3: Read Holding Registers
data = FC 18 = -10 deg C



IP-Request write_multiple_registers(unit => 1, address  => 0x06CE, quantity => 1)
45 00 00 43 07 13 40 00 80 06 00 00 7F 00 00 01 7F 00 00 01 CC 67 01 F7 76 ED 99 8A 9A 7A 4E B7 80 18 03 FF 78 32 00 00 01 01 08 0A 01 21 87 A1 01 21 87 A0 00 02 00 00 00 09 01 10 06 CE 00 01 02 FC 18
IPv4  <len> <id > <frg>   tcp <chk> <Src-Addr > <Dest-Addr> <spt> <dpt> < seq-nr  > < ack-nr  > of fl <win> <chk> <urg> <opt> <        time stamp         > <               modbus data                >

modbus-data:
00 02 00 00 00 09 01 10 06 CE 00 01 02 FC 18
<Tid> <Pid> <len> un fc <adr> <qua> by <data>
fc=0x10: Write Multiple Registers
data = FC 18 = -10 deg C


IP-Response:
45 00 00 40 07 15 40 00 80 06 00 00 7F 00 00 01 7F 00 00 01 01 F7 CC 67 9A 7A 4E B7 76 ED 99 99 80 18 04 FE 92 24 00 00 01 01 08 0A 01 21 87 A2 01 21 87 A1 00 02 00 00 00 06 01 10 06 CE 00 01
IPv4  <len> <id > <frg>   tcp <chk> <Src-Addr > <Dest-Addr> <spt> <dpt> < seq-nr  > < ack-nr  > of fl <win> <chk> <urg> <opt> <        time stamp         > <            modbus data          >

modbus-data:
00 02 00 00 00 06 01 10 06 CE 00 01
<Tid> <Pid> <len> un fc <adr> <qua>
fc=0x10: Write Multiple Registers


