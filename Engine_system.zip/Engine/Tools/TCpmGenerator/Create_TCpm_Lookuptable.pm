package CREATE_TCPM_LOOKUP; 

$TABLE = {
#Map the keywords from TS to function names and input arguments

#Example 1: if TS has test step with text:- [ readDataByIdentifier:: ActiveSession ] , 
		#Based on the above statement, in the below example, 'readDataByIdentifier' is the function keyword, 'ActiveSession' is treated as the parameter keyword (will be mapped from Look up table)
		#FunctionName corresponding to readDataByIdentifier is GDCOM_RequestGeneral
		#Function arguments for ActiveSession is "REQ_ReadActiveSession"
		#GDCOM_RequestGeneral ( "REQ_ReadActiveSession" ); will be printed in the pm file
		
#Example 2: if TS has test step with text:- [ readDataByIdentifier:: <ActiveSession> ] , 
		#Based on the above statement, in the below example, 'readDataByIdentifier' is the function keyword, <ActiveSession> is treated as a parameter from par file
		#FunctionName corresponding to readDataByIdentifier is GDCOM_RequestGeneral
		#GDCOM_RequestGeneral ( $tcpar_ActiveSession ); will be printed in the pm file		


	'KEYWORD' => {
		
		#example	
		'readDataByIdentifier' => {
							'FunctionName' 	=> 'GDCOM_RequestGeneral',
							'ActiveSession'	=> '"REQ_ReadActiveSession"',
							#add any more parameter keywords here which should be replaced in the pm file
		},
		
		
		'enterSession' => {
							'FunctionName' 	=> 'GDCOM_StartSession',
							'Session_to_be_entered'	=> '',	
		},
		
		
	},
	

};
1;


