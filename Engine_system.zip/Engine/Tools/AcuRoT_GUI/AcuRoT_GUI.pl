#!C:\Perl\bin\Perl.exe -w

#################################################################################
# this tool is under version management
my $VERSION = q$Revision: 1.2 $;
#################################################################################


BEGIN
{
    my $LIFT_exec_path='../..';

    # add directories to search path for perl modules    
    unshift @INC, "$LIFT_exec_path/modules/Device_layer/ACUROT";
    unshift @INC, "$LIFT_exec_path/modules/Common_library";
}



use Tk;
use strict;
use warnings;
use File::Path;
use Getopt::Long;
use ACUROT;

my $Toolversion = "AcuRoT_GUI ($VERSION)";      # Tool version number


my ( $main, $VFrame,$HFrame, $ButtonFrame, $ValueEntry, $display_txt, $RotationFrame, $PositionFrame, $WobbleFrame, $SelectionFrame, $GeneralFrame);
my ($COMh, $COMv, $stat, $ROT, $POS, $POS1, $POS2, $ACC,$zeroh,$zerov, $table,$zero_pos);
my ($V_rad,$H_rad,$C_button);
$COMh=3;
$COMv=4;
$zeroh=4.647000;
$zerov=292.192000;
$table='V';
$zero_pos=$zerov;

$ROT=360;
$POS=100;
$POS1=-45;
$POS2=45;
$ACC=100;
my $connected=0;

################################
# create those nice TK widgets #
################################

# create main window 'main'
$main = MainWindow -> new();

# define minimum size of window 'main'
$main -> minsize( 400, 300 );

# create title in window 'main'
$main -> title ( "operate AcuRoT $VERSION" );

# create frames  in window 'main'
$HFrame = $main -> Frame() -> pack( "-pady" => 5 );
$VFrame = $main -> Frame() -> pack( "-pady" => 5 );
$ButtonFrame = $main -> Frame() -> pack( "-pady" => 5 );
$SelectionFrame = $main -> Frame() -> pack( "-pady" => 5 );
$GeneralFrame = $main -> Frame() -> pack( "-pady" => 5 );
$RotationFrame = $main -> Frame() -> pack( "-pady" => 5 );
$PositionFrame = $main -> Frame() -> pack( "-pady" => 5 );
$WobbleFrame = $main -> Frame() -> pack( "-pady" => 5 );

# create HFrame content
$HFrame -> Label(
            "-text" => "Horizontal Rotation Table COM ", 
            )-> pack( "-side" => 'left', );

$HFrame -> Entry(
            "-width" => 2,
            "-textvariable" => \$COMh, 
            )-> pack( "-side" => 'left', );

$HFrame -> Label( 
            "-text" => "zero point offset ", 
            )-> pack( "-side" => 'left', );

$HFrame -> Entry(
            "-width" => 10,
            "-textvariable" => \$zeroh, 
            )-> pack( "-side" => 'left', );



# create VFrame content
$VFrame -> Label( 
            "-text" => "Vertical Rotation Table COM ", 
            )-> pack( "-side" => 'left', );

$VFrame -> Entry(
            "-width" => 2,
            "-textvariable" => \$COMv, 
            ) -> pack( "-side" => 'left', );
            
$VFrame -> Label( "-text" => "zero point offset ", )
            -> pack( "-side" => 'left', );

$VFrame -> Entry(
            "-width" => 10,
            "-textvariable" => \$zerov, 
            )-> pack( "-side" => 'left', );


# create 'exit' button
$ButtonFrame -> Button(
                "-text" => "E X I T",
                "-command" => sub
                {exit;}
                )-> pack ("-side" => 'left',"-ipadx" => 10,"-ipady" => 10,"-pady" => 10,"-padx" => 10);


# create 'CONNECT' button
$C_button=$ButtonFrame -> Button(
              "-text" => "CONNECT","-background" => "yellow","-activebackground" => "yellow",
              "-command" => sub
                { # execute when button is pressed  
                    $stat = ar_connect($COMh, $COMv);
                    $display_txt="connected on hCOM$COMh, vCOM$COMv";
                    w2log($display_txt."\n");
                    check_error($stat);
                    if($stat==0){
                        $connected = 1;
                        # change colour and text of button if successfully connected
                        $C_button -> configure( "-background" => "green","-activebackground" => "green","-text" => "connected");
                    }
                })-> pack ("-side" => 'left',"-ipadx" => 10,"-ipady" => 10,"-pady" => 10,"-padx" => 10);



# create SelectionFrame content

$SelectionFrame -> Label( 
            "-text" => "use table", 
            )-> pack( "-side" => 'left', );

$V_rad=$SelectionFrame -> Radiobutton  (
            "-text"     => "V",
            "-value"    => 'V',
            "-variable" => \$table,
            "-command"  => sub    {
                        $zero_pos=$zerov;
                        $main -> update();
            }  ) -> pack  (  "-side" => 'left',  );
       
$H_rad=$SelectionFrame -> Radiobutton  (
            "-text"     => "H",
            "-value"    => 'H',
            "-variable" => \$table,
            "-command"  => sub    {
                        $zero_pos=$zeroh;
                        $main -> update();
            }  ) -> pack  (  "-side" => 'left',  );


# create GeneralFrame content

$GeneralFrame -> Button(
            "-text" => "INIT table",
            "-command" => sub
            { # execute when button is pressed  
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}

                $display_txt="initializing table $table ...";
                $main->update();
                $stat = ar_init($table,$zero_pos);
                $display_txt="initialized $table with $zero_pos zero offset";
                w2log($display_txt."\n");
                check_error($stat);

                if ($table eq 'V'){
                    $V_rad -> configure( "-background" => "green","-activebackground" => "green");
                }
                else{
                    $H_rad -> configure( "-background" => "green","-activebackground" => "green");
                }

            })-> pack ("-side" => 'left',"-padx" => 10);

$GeneralFrame -> Button(
            "-text" => "stop table",
            "-command" => sub{
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}
                $display_txt="prepare stopping ...";
                $main->update();
                $stat = ar_stop($table); 
                $display_txt="table $table stopped";
                w2log($display_txt."\n");
                check_error($stat);
            })-> pack( "-side" => 'left', "-padx" => 10);

$GeneralFrame -> Button(
            "-text" => "set new zero point",
            "-command" => sub{
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}

                $display_txt="prepare new null ...";
                $main->update();
                ($stat,$zero_pos) = ar_set_null($table);
                $display_txt="new null pos $table is $zero_pos";
                w2log($display_txt."\n");
                check_error($stat);

                if ($table eq 'V'){
                    $zerov=$zero_pos;
                }
                else{
                    $zeroh=$zero_pos;
                }
            })-> pack( "-side" => 'left', "-padx" => 10);





# create RotationFrame content

$RotationFrame -> Button(
            "-text" => "+",
            "-font" => "{MS Sans Serif} 10 bold",
            "-command" => sub{
                $ROT+=1;
            })-> pack( "-side" => 'left', );
            
$RotationFrame -> Button(
            "-text" => "-",
            "-font" => "{MS Sans Serif} 10 bold",
            "-command" => sub{
                $ROT-=1;
            })-> pack( "-side" => 'left', );

$RotationFrame -> Entry(
            "-width" => 6,
            "-textvariable" => \$ROT, 
            ) -> pack( "-side" => 'left', );

$RotationFrame -> Button(
            "-text" => "start rotation",
            "-command" => sub{
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}
                $display_txt="prepare rotating ...";
                $main->update();
                $stat = ar_rotate($table,$ROT); 
                $display_txt="rotating $table with $ROT";
                w2log($display_txt."\n");
                check_error($stat);
            })-> pack( "-side" => 'left', );


# create PositionFrame content

$PositionFrame -> Button(
            "-text" => "+1",
            "-command" => sub{
                $POS+=1;
            })-> pack( "-side" => 'left', );

$PositionFrame -> Button(
            "-text" => "-1",
            "-command" => sub{
                $POS-=1;
            })-> pack( "-side" => 'left', );

$PositionFrame -> Entry(
            "-width" => 6,
            "-textvariable" => \$POS, 
            ) -> pack( "-side" => 'left', );

$PositionFrame -> Button(
            "-text" => "+",
            "-font" => "{MS Sans Serif} 10 bold",
            "-command" => sub{
                $POS+=0.01;
            })-> pack( "-side" => 'left', );

$PositionFrame -> Button(
            "-text" => "-",
            "-font" => "{MS Sans Serif} 10 bold",
            "-command" => sub{
                $POS-=0.01;
            })-> pack( "-side" => 'left', );

$PositionFrame -> Button(
            "-text" => "move to position",
            "-command" => sub{
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}
                $display_txt="prepare moving ...";
                $main->update();
                $stat = ar_position($table,$POS); 
                $display_txt="moved $table to $POS";
                w2log($display_txt."\n");
                check_error($stat);
            })-> pack( "-side" => 'left', );





# create WobbleFrame content
$WobbleFrame -> Label( 
            "-text" => "from pos", 
            )-> pack( "-side" => 'left', );
            
$WobbleFrame -> Entry(
            "-width" => 6,
            "-textvariable" => \$POS1, 
            ) -> pack( "-side" => 'left', );
            
$WobbleFrame -> Label( 
            "-text" => "to pos", 
            )-> pack( "-side" => 'left', );
            
$WobbleFrame -> Entry(
            "-width" => 6,
            "-textvariable" => \$POS2, 
            ) -> pack( "-side" => 'left', );
            
$WobbleFrame -> Label( 
            "-text" => " with acc ", 
            )-> pack( "-side" => 'left', );
            
$WobbleFrame -> Entry(
            "-width" => 6,
            "-textvariable" => \$ACC, 
            ) -> pack( "-side" => 'left', );
            
$WobbleFrame -> Button(
            "-text" => "wobble",
            "-command" => sub{
                unless ($connected){$display_txt="not connected !!!";w2log($display_txt."\n");return;}
                $display_txt="prepare wobbling ...";
                $main->update();
                $stat = ar_wobble($table,$POS1, $POS2, $ACC); 
                $display_txt="wobbling $table from $POS1 to $POS2 with $ACC acceleration";
                w2log($display_txt."\n");
                check_error($stat);
            })-> pack( "-side" => 'left', );


# create display label in window 'main'
$main -> Label( 
            "-textvariable" => \$display_txt, 
            "-font" => "{MS Sans Serif} 10 bold",
            )-> pack( "-pady" => 10 );




#++++++++++++++++++++++++++++++++++++++++++++++
########################## MAIN ###############
# the MainLoop is used by perlTK, when it is called all widgets are created and the
# connected actions are done (e.g. when you press a button)

open ( LOG,">AcuRoT_GUI_log.txt" ) or die "Couldn't open logfile.txt : $@";
# create logfile in chosen directory
w2log("######################################################################\n");
w2log("      $Toolversion logfile\n");
w2log("######################################################################\n");

# run with TK
  MainLoop;

w2log("\n######################################################################\n");
w2log(" END OF LOGFILE\n");

close (LOG);

#-------------------- MAIN end ---------------#
#++++++++++++++++++++++++++++++++++++++++++++++





###########################################
###########################################
############### SUBROUTINES ###############
###########################################
###########################################


sub check_error{
    my $error = shift;
    if ($error < 0){
        $display_txt = "ERROR: ".ar_get_error();
        w2log($display_txt."\n");
    }
}

##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print LOG $text;
     print $text;
}


# end of program

=head1 usage

operatwe AcuRoT

a logfile will be written containing all actions.

use 'EXIT' button to finish logfile properly


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=cut
