# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FuncLib_TNT_crash_simulation;

use strict;
use warnings;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_LIN_Access;
use LIFT_evaluation;
use LIFT_general;
use LIFT_labcar;
use LIFT_ProdDiag;
use FuncLib_SYC_INTERFACE;
use LIFT_QuaTe;
use Import::Into;

our ( $VERSION, $HEADER );
use Exporter;

BEGIN {
    our @ISA    = qw(Exporter);
    our @EXPORT = qw(
      ExternalSensorError__Set
      ExternalSensorConfiguration__Set
      NetSignal__Reset
      NetSignal__Set
      SpecialBehaviourBit__Set
      PdLabel__Verify
      Switch_OCS_Configured__Verify
      Switch_OCS_State__Verify
      SwitchConfiguration__Set
      SwitchConfiguration__Verify
      SwitchDiagnosable__Verify
      SwitchState__Set
      SwitchState__Verify
      PostCrashActions
      FaultManipulation__Set
      CsEcuHighGXMonOverloadBhvr__Set
      CsEcuHighGYMonOverloadBhvr__Set
    );
}

=head1 NAME

FuncLib_TNT_crash_simulation 

=head1 SYNOPSIS

    Should not be accessed directly.
    Access to the functions happens from LIFT_crash_simulation. 

=head1 DESCRIPTION

This module provides functions and data structures for crash simulation environment setting.
All functions and data structures in this module can be overwritten by functions/data structures 
with the same name in FuncLib_CustLib_crash_simulation and/or FuncLib_Project_crash_simulation
if they are exported in one of those modules.

=cut

=head1 Function Group "Helper Functions for customer and project functions"

=head2 PostCrashActions

    $success = PostCrashActions( $crashData_href );

This is the default for post crash actions: nothing!
If project or customer specific post crash actions are required, then copy this function to
FuncLib_Project_crash_simulation or FuncLib_Cust_crash_simulation
and implement the functionality there.

=cut

sub PostCrashActions {
    my @args = @_;
    return unless S_checkFunctionArguments( 'PostCrashActions( $crashData_href )', @args );

    my $crashData_href = shift @args;

    return 1;
}

=head2 GetStateOfEnvVariable

    GetStateOfEnvVariable( $crashData_href, $environment );

Returns the value of the environment $environment (static or dynamic) from the crash data $crashData_href.

Returns undef on error or if $environment cannot be found in $crashData_href.

This function is not exported, therefore it must be called with the fully qualify subroutine name 
(package::function) like in the example below.

Example:

    my $physValue = FuncLib_TNT_crash_simulation::GetStateOfEnvVariable( $crashData_href, $environmentForValue );

=cut

sub GetStateOfEnvVariable {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetStateOfEnvVariable( $crashData_href, $environment )', @args );

    my $crashData_href = shift @args;
    my $environment    = shift @args;
    my $envValue;

    if ( exists $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment} ) {
        $envValue = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{Value};
    }
    elsif ( exists $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment} ) {
        $envValue = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{Value};
    }
    else {
        return;
    }

    S_w2log( 3, "Value of environment '$environment' is '$envValue'.\n" );
    return $envValue;
}

=head2 SetStateOfEnvVariable

    SetStateOfEnvVariable( $crashData_href, $environment, $value );

Overrides the given value of the environment $environment (static or dynamic) from the crash data $crashData_href with $value.

Returns undef on error or if $environment cannot be found in $crashData_href.

This function is not exported, therefore it must be called with the fully qualify subroutine name 
(package::function) like in the example below.

Example:

    FuncLib_TNT_crash_simulation::SetStateOfEnvVariable( $crashData_href, $environmentForValue, $value );

=cut

sub SetStateOfEnvVariable {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SetStateOfEnvVariable( $crashData_href, $environmentForValue, $value )', @args );

    my $crashData_href = shift @args;
    my $environment    = shift @args;
    my $value          = shift @args;

    if ( exists $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment} ) {
        $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{Value} = $value;
    }
    elsif ( exists $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment} ) {
        $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{Value} = $value;
    }
    else {
        S_set_error( "Value of environment '$environment' is requested, but '$environment' is not defined in the crash environment.", 114 );
        return;
    }

    return 1;
}

sub HandleSourcedEnvironment {
    my @args = @_;
    return unless S_checkFunctionArguments( 'HandleSourcedEnvironment( $element,$value,$crashData_href,$mappingData_href); )', @args );

    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    #check mapping of the sourceEnvironment

    my $sourceEnvironment = $mappingData_href->{SourceEnvironment};
    my $source = GetStateOfEnvVariable( $crashData_href, $sourceEnvironment );
    unless ( defined $source ) {
        S_set_error( "$element: Given SourceEnvironment '$sourceEnvironment' not present / or not set to CREIS relevant in MDB.", 109 );
        return 0;
    }

    my $sourceMapping_href = $mappingData_href->{SourceMapping};
    unless ( exists $sourceMapping_href->{$source} ) {
        S_set_error( "$element: Given value '$source' for SourceEnvironment '$sourceEnvironment' not allowed. See 'SourceMapping'.", 109 );
        return 0;
    }

    my $sourceText = $sourceMapping_href->{$source};

    if ( not defined $sourceText ) {
        SetStateOfEnvVariable( $crashData_href, $element, 'N/A' );
        return ( 1, undef, "Source = '$source': nothing will be done." );
    }
    elsif ( $sourceText eq $element ) {
        S_w2log( 3, "Source = '$source': Use value defined in Environment '$element'" );
        return ( 1, $value, "Source = '$source': Use value defined in Environment '$element'" );
    }
    elsif ( exists $crashData_href->{METADATA}{$sourceText} ) {
        my $value_aref = $crashData_href->{METADATA}{$sourceText};
        $value = $$value_aref[0];
        SetStateOfEnvVariable( $crashData_href, $element, $value );
        S_w2log( 3, "Source = '$source': Use value defined in crash METADATA '$sourceText'" );
        return ( 1, $value, "Source = '$source': Use value defined in crash METADATA '$sourceText'" );
    }

    S_set_error( "Given Keyword is not defined in crash data or environment data. Please check your CREIS_Mapping.", 109 );

    return 0;
}

=head1 Function Group "Functions for individual environments"

=head2 NetSignal__Reset

    NetSignal__Reset( $value, $crashData_href );

=cut

sub NetSignal__Reset {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $signalName = $mappingData_href->{SignalName};
    my $unit_mdb   = $mappingData_href->{EnvUnit_Mdb};
    my $unit_net   = $mappingData_href->{SignalUnit_Net};
    my $success    = 0;

    # get and check NetworkType
    my $networkType = $mappingData_href->{NetworkType};
    if ( $networkType !~ /^CAN|FLXR|LIN$/i ) {
        S_set_error( "$element: Given NetworkType '$networkType' not supported for EnvType 'NetSignal'", 109 );
        return 0;
    }

    S_w2log( 3, "Set $networkType signal '$signalName' to value '$value'.\n" );
    $success = CA_write_can_signal( $signalName, $value, 'phys' ) if $networkType eq "CAN";
    $success = FR_write_flxr_signal( $signalName, $value, 'phys' ) if $networkType eq "FLXR";
    $success = LIN_write_LIN_signal( $signalName, $value, 'phys' ) if $networkType eq "LIN";

    return $success;
}

=head2 NetSignal__Set

    NetSignal__Set( $value, $crashData_href );

=cut

sub NetSignal__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my ( $setTexts_aref, $mappedValue, $updatedValue, $validityEnvironment, $validity, $used4Environment );

    my $signalName = $mappingData_href->{SignalName};
    my $unit_mdb   = $mappingData_href->{EnvUnit_Mdb};
    my $unit_net   = $mappingData_href->{SignalUnit_Net};
    my $success    = 0;

    # get and check NetworkType
    my $networkType = $mappingData_href->{NetworkType};
    if ( $networkType !~ /^CAN|FLXR|LIN$/i ) {
        S_set_error( "$element: Given NetworkType '$networkType' not supported for EnvType 'NetSignal'", 109 );
        return 0;
    }

    # if environment has a validity
    if ( exists $mappingData_href->{ValidityEnvironment} ) {
        $validityEnvironment = $mappingData_href->{ValidityEnvironment};
        $validity = GetStateOfEnvVariable( $crashData_href, $validityEnvironment );

        unless ( defined $validity ) {
            S_set_error( "$element: Given ValidityEnvironment '$validityEnvironment' not present / or not set to CREIS relevant in MDB.", 109 );
            return 0;
        }

        if ($validity) {
            push( @$setTexts_aref, "Remains VALID as Environment '$validityEnvironment' => '$validity'" );
        }
        else {
            $value = "INVALID";
            push( @$setTexts_aref, "Set to INVALID by Environment '$validityEnvironment' => '$validity'" );
        }
    }

    # check if signal mapping mdb to net exists
    if ( exists $mappingData_href->{SignalMapping_Mdb2Net} ) {
        my $signalMapping_Mdb2Net = $mappingData_href->{SignalMapping_Mdb2Net};
        $mappedValue = $signalMapping_Mdb2Net->{$value};
    }

    if ( $value eq "INVALID" and not defined $mappedValue ) {
        S_set_error( "$element: Environment is set to INVALID by Environment '$validityEnvironment' => '$validity', but INVALID is not mapped by 'SignalMapping_Mdb2Net'.", 109 );
        return 0;
    }

    # if environment needs source handling...
    if ( exists $mappingData_href->{SourceEnvironment} and not defined $mappedValue ) {
        my ( $result, $setText );
        ( $result, $updatedValue, $setText ) = HandleSourcedEnvironment( $element, $value, $crashData_href, $mappingData_href );
        return 0 unless $result;
        push( @$setTexts_aref, $setText );
        return ( 1, $setTexts_aref ) unless defined $updatedValue;

        $value = $updatedValue;
    }

    # apply factor if defined and not a mappedValue
    if ( exists $mappingData_href->{SignalFactor_Mdb2Net} and not defined $mappedValue ) {
        my $factor = $mappingData_href->{SignalFactor_Mdb2Net};
        $mappedValue = $value * $factor;
        push @$setTexts_aref, "Mdb value: $value $unit_mdb <--> Net value: $mappedValue $unit_net";
    }

    unless ( defined $mappedValue ) {
        S_set_error( "$element: no mapped value found Check and update mapping file.", 109 );
        return 0;
    }

    S_w2log( 3, "Set $networkType signal '$signalName' to value '$mappedValue'.\n" );
    push @$setTexts_aref, "Set $networkType signal '$signalName' to value '$mappedValue'.";
    $success = CA_write_can_signal( $signalName, $mappedValue, 'phys' ) if $networkType eq "CAN";
    $success = FR_write_flxr_signal( $signalName, $mappedValue, 'phys' ) if $networkType eq "FLXR";
    $success = LIN_write_LIN_signal( $signalName, $mappedValue, 'phys' ) if $networkType eq "LIN";

    return ( $success, $setTexts_aref );
}

=head2 SpecialBehaviourBit__Set

    SpecialBehaviourBit__Set( $value, $crashData_href );

Configure the special behaviour bit for RightHandDriver to the value $value (0=not set, 1=set).

The argument $crashData_href is not used in this function, but it is passed by default from the caller 
(LIFT_crash_simulation::CallEnvironmentSpecificFunction)

=cut

sub SpecialBehaviourBit__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $specialBitName = $mappingData_href->{SpecialBitName};

    if ( not defined PRD_Get_Device_Property($specialBitName) and not $main::opt_offline ) {
        my $errorText = "Device '$specialBitName' is not known for Production Diagnosis.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    my $standardConfigurations_href;

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{MappingMDS2Configuration} ) {
        $standardConfigurations_href = $mappingData_href->{MappingMDS2Configuration};
    }
    else {
        $standardConfigurations_href = {
            0 => 'clear_Configure',
            1 => 'set_Configure',
        };
    }

    # get switch state from MDS value
    my $state = $standardConfigurations_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # configure switch(es) with value $value
    my $setTexts_aref;

    S_w2log( 3, "Environment (configuration of '$specialBitName') will be set to value $value (state '$state')\n" );
    my $result = PRD_Set_Device_Configuration( { $specialBitName => $state } );

    if ($result) {
        push @$setTexts_aref, "SpecialBehaviourBitConfiguration '$specialBitName': '$state'.";
    }

    return ( $result, $setTexts_aref );
}

=head2 PdLabel__Verify

    PdLabel__Verify( $value, $crashData_href );

=cut

sub PdLabel__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    if ( $value eq "N/A" ) {
        return ( 1, ["Nothing has been set before. Verification skipped."] );
    }

    my $pdLabel = $mappingData_href->{Verify}{PdLabel};

    my $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => $pdLabel } );
    unless ($mapping_info) {
        my $errorText = "Given PdLabel '$pdLabel' is not known for Production Diagnosis.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    my ( $validityEnvironment, $validity, $checkTexts_aref, $verdicts_aref );    # if environment has a validity

    if ( exists $mappingData_href->{Verify}{ValidityEnvironment} ) {
        $validityEnvironment = $mappingData_href->{Verify}{ValidityEnvironment};
        $validity = GetStateOfEnvVariable( $crashData_href, $validityEnvironment );
        unless ( defined $validity ) {
            S_set_error( "$element: Given ValidityEnvironment '$validityEnvironment' not present / or set to CREIS relevant in MDB.", 109 );
            return 0;
        }
        unless ($validity) {
            $value = "INVALID";
            push( @$checkTexts_aref, "Set to INVALID by Environment '$validityEnvironment' => '$validity'" );
            push( @$verdicts_aref,   VERDICT_NONE );
        }
    }

    my $mappedValue;

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{Verify}{SignalMapping_Mdb2PdLabel} ) {
        my $standardConfigurations_href = $mappingData_href->{Verify}{SignalMapping_Mdb2PdLabel};

        # get switch state from MDS value
        $mappedValue = $standardConfigurations_href->{$value};

    }

    my $expValue;
    $expValue = $mappedValue if defined $mappedValue;

    # in case of BitNbr given, value needs to be defined at this point
    if ( not defined $expValue and exists $mappingData_href->{Verify}{BitNbr_ZeroBased} ) {
        S_set_error( "$element: BitNbr_ZeroBased is given, but value '$value' is not mapped in 'SignalMapping_Mdb2PdLabel' table.", 109 );
        return 0;
    }

    my ( $tolerance, $tolerance_type, $factor, $unit );

    $factor = 1;

    # apply factor and offset if value was not mapped before
    unless ( defined $expValue ) {
        $expValue = $value;

        $factor = $mappingData_href->{Verify}{Factor_LsbPdLabel2Mdb} if exists $mappingData_href->{Verify}{Factor_LsbPdLabel2Mdb};

        $unit = "-";
        $unit = $mappingData_href->{EnvUnit_Mdb} if exists $mappingData_href->{EnvUnit_Mdb};

        $tolerance = 1;
        $tolerance = $mappingData_href->{Verify}{Tolerance} if exists $mappingData_href->{Verify}{Tolerance};

        $tolerance_type = "absolute";
    }

    my $decValue = PRD_Read_Memory( $pdLabel, { memoryContentsAsInteger => 1 } );

    return 0 unless defined $decValue;

    my $bitNbr;

    if ( exists $mappingData_href->{Verify}{BitNbr_ZeroBased} ) {
        my $bitmask = 1;
        $bitNbr = $mappingData_href->{Verify}{BitNbr_ZeroBased};
        unless ( $bitNbr =~ /^\d+$/ ) {
            S_set_error( "$element: Given BitNbr_ZeroBased '$bitNbr' is not a whole number. Please correct in CREIS Mapping.", 109 );
            return 0;
        }
        $bitmask = $bitmask << $bitNbr;
        S_w2log( 3, "Bitmask: $bitmask" );
        my $bitValue = 0;
        $bitValue = 1 if ( $decValue & $bitmask );

        $decValue = $bitValue;
    }

    my $physValue = $decValue * $factor;
    my $verdict = EVAL_evaluate_value_NOVERDICT( "$element verification", $physValue, "==", $expValue, $tolerance, $tolerance_type );

    if ( defined $bitNbr ) {
        push( @$checkTexts_aref, "Bit $bitNbr of '$pdLabel'" );
        push( @$verdicts_aref,   VERDICT_NONE );
    }
    else {
        push( @$checkTexts_aref, "PD label '$pdLabel'" );
        push( @$verdicts_aref,   VERDICT_NONE );
    }

    if ( defined $tolerance ) {
        push @$checkTexts_aref, "EXP: $expValue $unit +-$tolerance DET: $physValue $unit [~ $decValue LSB * $factor]";
    }
    else {
        push @$checkTexts_aref, "EXP: '$expValue' DET: '$decValue'";
    }
    push( @$verdicts_aref, $verdict );

    if ( $verdict eq "VERDICT_PASS" ) {
        S_w2log( 3, "$element verification: passed\n", 'green' );
        return ( 1, $checkTexts_aref, $verdicts_aref );
    }
    elsif ( $verdict eq "VERDICT_FAIL" ) {
        S_w2log( 3, "$element verification: failed\n", 'red' );
        return ( -1, $checkTexts_aref, $verdicts_aref );
    }

    return ( 0, $checkTexts_aref, $verdicts_aref );
}

=head2 ExternalSensorConfiguration__Set

    ExternalSensorConfiguration__Set($element, $value, $crashData_href, $mappingData_href);

Returns 1 on success and 0 otherwise.

=cut

sub ExternalSensorConfiguration__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $sensorName = $mappingData_href->{SensorName};

    my $standardConfigurations_href;
    if ( not defined PRD_Get_Device_Property($sensorName) and not $main::opt_offline ) {
        my $errorText = "Device '$sensorName' is not known for Production Diagnosis.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{MappingMDS2Configuration} ) {
        $standardConfigurations_href = $mappingData_href->{MappingMDS2Configuration};
    }
    else {
        $standardConfigurations_href = {
            0 => 'clear_Configure',
            1 => 'set_Configure',
        };
    }

    # get switch state from MDS value
    my $state = $standardConfigurations_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # configure switch(es) with value $value
    my $setTexts_aref;

    S_w2log( 3, "Environment (configuration of '$sensorName') will be set to value $value (state '$state')\n" );
    my $result = PRD_Set_Device_Configuration( { $sensorName => $state } );

    if ($result) {
        push @$setTexts_aref, "ExternalSensorConfiguration '$sensorName': '$state'.";
    }

    return ( $result, $setTexts_aref );
}

=head2 ExternalSensorError__Set

    ExternalSensorError__Set($element, $value, $crashData_href, $mappingData_href);

Returns 1 on success and 0 otherwise.

=cut

sub ExternalSensorError__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $sensorName = $mappingData_href->{SensorName};
    my @sensors    = LC_Get_names('PAS_LINES');
    unless ( $sensorName ~~ @sensors ) {
        my $errorText = "Given 'Sensor' is '$sensorName', \n but this sensor is not known as Sensor (PAS_line) for test system. \n Check your mappings / settings.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # disconnect or connect sensor line depending on $value
    if ( $value == 0 ) {
        S_w2log( 3, "Environment $element (error behaviour of sensor) '$sensorName' will be set to error state\n" );
        my $success = LC_DisconnectLine($sensorName);
        return ( $success, ["Environment $element (error behaviour of sensor) '$sensorName' will be set to error state."] );
    }
    elsif ( $value == 1 ) {
        S_w2log( 3, "Environment $element (error behaviour of sensor) '$sensorName' will be set to normal state\n" );
        my $success = LC_ConnectLine($sensorName);
        return ( $success, ["Environment $element (error behaviour of sensor) '$sensorName' will be set to normal state."] );
    }
    my $errorText = "Given value '$value' from MDB not supported.";
    S_set_error( $errorText, 109 );
    return ( 0, ["ERROR: $errorText."] );
}

=head2 Switch_OCS_Configured__Verify

    Switch_OCS_Configured__Verify($element, $value, $crashData_href, $mappingData_href);

=cut

sub Switch_OCS_Configured__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    # set switch(es) to state/value $state_value
    my $success = 1;
    my ( $checkTexts_aref, $verdicts_aref );

    my $valueExtStatusFiltered_en_aref = PRD_Read_Memory("rb_swmp_CustOcsExtendedStatus_en");
    return 0 unless @$valueExtStatusFiltered_en_aref;

    my $detectedValue = 0;
    $detectedValue = 1 if ( $$valueExtStatusFiltered_en_aref[0] & 0b00000100 );

    my $verdict = EVAL_evaluate_value_NOVERDICT( "Switch_OCS_Configuration__Check", $detectedValue, '==', $value );

    push( @$checkTexts_aref, "Bit 2 of 'rb_swmp_CustOcsExtendedStatus_en'" );
    push( @$verdicts_aref,   "VERDICT_NONE" );
    push( @$checkTexts_aref, "EXP: '$value' DET: '$detectedValue'" );
    push( @$verdicts_aref,   $verdict );

    if ( $verdict eq "VERDICT_PASS" ) {
        S_w2log( 3, "Switch_OCS_Configuration__Check: passed\n", 'green' );
    }
    elsif ( $verdict eq "VERDICT_FAIL" ) {
        S_w2log( 3, "Switch_OCS_Configuration__Check: failed\n", 'red' );
        $success = -1;
    }

    return ( $success, $checkTexts_aref, $verdicts_aref );
}

=head2 Switch_OCS_State__Verify

    Switch_OCS_State__Verify($switch, $value); (not exported)

Returns 1 on success and 0 otherwise.

=cut

sub Switch_OCS_State__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $standardOCSStates_href;

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{MappingMDS2OCS} ) {
        $standardOCSStates_href = $mappingData_href->{MappingMDS2OCS};
    }
    else {
        $standardOCSStates_href = {
            0 => 'Fault',
            1 => 'NotPresent',
            2 => 'Empty',
            3 => "Child",
            4 => "SmallAdult",
            5 => "MediumAdult",
            6 => "LargeAdult",
        };
    }

    # get switch state from MDS value
    my $state = $standardOCSStates_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # set switch(es) to state/value $state_value
    my $success = 1;
    my ( $checkTexts_aref, $verdicts_aref );

    # ExtStatusFiltered_en
    my $valueExtStatusFiltered_en_aref = PRD_Read_Memory("rb_swmp_CustOcsExtendedStatus_en");
    return 0 unless @$valueExtStatusFiltered_en_aref;
    my $decExtStatusFiltered_en = S_aref2dec( $valueExtStatusFiltered_en_aref, 'U8' );
    my $decExtStatusFiltered_en_Bit1_2 = $decExtStatusFiltered_en & 0b00000011;

    my $lookUpTableExtStatus_href = {
        Empty       => 1,
        Child       => 1,
        SmallAdult  => 1,
        MediumAdult => 1,
        LargeAdult  => 1,
        Fault       => 2,
        NotPresent  => 3,
    };

    my $verdictStatus = EVAL_evaluate_value_NOVERDICT( "Switch_OCS_State__StatusCheck", $decExtStatusFiltered_en_Bit1_2, '==', $lookUpTableExtStatus_href->{$state} );
    push @$checkTexts_aref, "'rb_swmp_CustOcsExtendedStatus_en' - Bit 1,2";
    push @$checkTexts_aref, "EXP: '$lookUpTableExtStatus_href->{$state}' DET: '$decExtStatusFiltered_en_Bit1_2'";
    push @$verdicts_aref,   "VERDICT_NONE";
    push @$verdicts_aref,   $verdictStatus;

    if ( $verdictStatus eq "VERDICT_PASS" ) {
        S_w2log( 3, "Switch_OCS_State__StatusCheck: passed\n", 'green' );
    }
    elsif ( $verdictStatus eq "VERDICT_FAIL" ) {
        S_w2log( 3, "Switch_OCS_State__StatusCheck: failed\n", 'red' );
        $success = -1;
    }

    # PositionFiltered_en
    my $valuePositionFiltered_en_aref = PRD_Read_Memory("rb_swmp_CustOcsState_en");
    return 0 unless @$valuePositionFiltered_en_aref;
    my $decValuePositionFiltered_en = S_aref2dec( $valuePositionFiltered_en_aref, 'U8' );

    my $lookUpTablePosition_href = {
        Empty       => 0,
        Child       => 1,
        SmallAdult  => 2,
        MediumAdult => 3,
        LargeAdult  => 4,
        Fault       => undef,
        NotPresent  => undef,
    };

    my $exp_Position = $lookUpTablePosition_href->{$state};
    $exp_Position = $decValuePositionFiltered_en unless defined $exp_Position;

    my $verdictPosition = EVAL_evaluate_value_NOVERDICT( "Switch_OCS_State__PositionCheck", $decValuePositionFiltered_en, '==', $exp_Position );
    push @$checkTexts_aref, "'rb_swmp_CustOcsState_en'";
    push @$checkTexts_aref, "EXP: '$exp_Position' DET: '$decValuePositionFiltered_en'";
    push @$verdicts_aref,   "VERDICT_NONE";
    push @$verdicts_aref,   $verdictPosition;

    if ( $verdictPosition eq "VERDICT_PASS" ) {
        S_w2log( 3, "Switch_OCS_State__PositionCheck: passed\n", 'green' );
    }
    elsif ( $verdictPosition eq "VERDICT_FAIL" ) {
        S_w2log( 3, "Switch_OCS_State__PositionCheck: failed\n", 'red' );
        $success = -1;
    }

    return ( $success, $checkTexts_aref, $verdicts_aref );
}

=head2 SwitchConfiguration__Set

     SwitchConfiguration__Set($element, $value, $crashData_href, $mappingData_href);

Returns 1 on success and 0 otherwise.

=cut

sub SwitchConfiguration__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    # check if multiple switches are defined for MDS switch name
    my $switches_aref = $mappingData_href->{MultipleSwitches};
    $switches_aref = [ $mappingData_href->{SwitchName} ] if not defined $switches_aref;

    my $standardConfigurations_href;

    # overwrite standard mapping with MappingMdb2Switch if defined
    if ( exists $mappingData_href->{MappingMdb2Configuration} ) {
        $standardConfigurations_href = $mappingData_href->{MappingMdb2Configuration};
    }
    else {
        $standardConfigurations_href = {
            0 => 'clear_Configure',
            1 => 'set_Configure',
        };
    }

    # get switch state from MDS value
    my $state = $standardConfigurations_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # configure switch(es) with value $value
    my $success = 1;
    my $setTexts_aref;
    foreach my $singleSwitch ( @{$switches_aref} ) {

        if ( not defined PRD_Get_Device_Property($singleSwitch) and not $main::opt_offline ) {
            my $errorText = "Device '$singleSwitch' is not known for Production Diagnosis.";
            S_set_error( $errorText, 109 );
            return ( 0, ["ERROR: $errorText."] );
        }

        S_w2log( 3, "Environment (configuration of '$singleSwitch') will be set to value $value (state '$state')\n" );
        my $result = PRD_Set_Device_Configuration( { $singleSwitch => $state } );
        if ($result) {
            push @$setTexts_aref, "SwitchConfiguration '$singleSwitch': '$state'.";
        }
        else {
            $success = 0;
        }
    }
    return ( $success, $setTexts_aref );
}

=head2 SwitchConfiguration__Verify

    SwitchConfiguration__Verify($element, $value, $crashData_href, $mappingData_href);

=cut

sub SwitchConfiguration__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    # check if multiple switches are defined for MDS switch name
    my $switches_aref = $mappingData_href->{MultipleSwitches};
    $switches_aref = [ $mappingData_href->{SwitchName} ] if not defined $switches_aref;

    # set switch(es) to state/value $state_value
    my $success = 1;
    my ( $checkTexts_aref, $verdicts_aref );

    foreach my $singleSwitch ( @{$switches_aref} ) {
        my $switch_nbr = PRD_Get_Device_Property($singleSwitch);

        if ( not defined $switch_nbr and not $main::opt_offline ) {
            my $errorText = "Device '$singleSwitch' is not known for Production Diagnosis.";
            S_set_error( $errorText, 109 );
            return ( 0, ["ERROR: $errorText."] );
        }

        my $valueExtStatusFiltered_en_aref = PRD_Read_Memory("rb_swm_SwitchInfo_ast($switch_nbr).ExtStatusFiltered_en");
        return 0 unless @$valueExtStatusFiltered_en_aref;

        my $detectedValue = 0;
        $detectedValue = 1 if ( $$valueExtStatusFiltered_en_aref[0] & 0b00000100 );

        my $verdict = EVAL_evaluate_value_NOVERDICT( "Switch_" . $singleSwitch . "_Configuration__Check", $detectedValue, '==', $value );

        push( @$checkTexts_aref, "Bit 2 of 'rb_swm_SwitchInfo_ast($switch_nbr).ExtStatusFiltered_en'" );
        push( @$verdicts_aref,   "VERDICT_NONE" );
        push( @$checkTexts_aref, "EXP: '$value' DET: '$detectedValue'" );
        push( @$verdicts_aref,   $verdict );

        if ( $verdict eq "VERDICT_PASS" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_Configuration__Check: passed\n", 'green' );
        }
        elsif ( $verdict eq "VERDICT_FAIL" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_Configuration__Check: failed\n", 'red' );
            $success = -1;
        }

    }

    return ( $success, $checkTexts_aref, $verdicts_aref );
}

=head2 SwitchDiagnosable__Verify

    SwitchDiagnosable__Verify($element, $value, $crashData_href, $mappingData_href);

=cut

sub SwitchDiagnosable__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    if ( $value == 1 ) {
        $value = 0;
    }
    else {
        $value = 1;
    }

    # check if multiple switches are defined for MDS switch name
    my $switches_aref = $mappingData_href->{MultipleSwitches};
    $switches_aref = [ $mappingData_href->{SwitchName} ] if not defined $switches_aref;

    # set switch(es) to state/value $state_value
    my $success = 1;
    my ( $checkTexts_aref, $verdicts_aref );

    foreach my $singleSwitch ( @{$switches_aref} ) {
        my $switch_nbr = PRD_Get_Device_Property($singleSwitch);

        if ( not defined $switch_nbr and not $main::opt_offline ) {
            my $errorText = "Device '$singleSwitch' is not known for Production Diagnosis.";
            S_set_error( $errorText, 109 );
            return ( 0, ["ERROR: $errorText."] );
        }

        # check diagnosable of configured default type
        my ( $switchType, $switchTypeEvaluationSettings_aref, $label4switchType );

        if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).type_en" } ) ) {
            $label4switchType = "type_en";
        }
        elsif ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).Type_en" } ) ) {
            $label4switchType = "Type_en";
        }
        else {
            S_set_error("SwitchDiagnosable__Verify : Label rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).(T|t)ype_en not available in SAD - File.");
            return ( 0, ["Label rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).(T|t)ype_en not available in SAD - File."] );
        }
        $switchType = PRD_Read_Memory( "rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).$label4switchType", { memoryContentsAsInteger => 1, } );

        if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_swm_Types_cast($switchType).evaluationSettings_b8" } ) ) {
            $switchTypeEvaluationSettings_aref = PRD_Read_Memory( "rb_swm_Types_cast($switchType).evaluationSettings_b8", );
        }
        elsif ( PRD_Get_Symbol_Mapping( { 'symbol_name' => "rb_swm_Types_cast($switchType).EvaluationSettings_b8" } ) ) {
            $switchTypeEvaluationSettings_aref = PRD_Read_Memory( "rb_swm_Types_cast($switchType).EvaluationSettings_b8", );
        }
        else {
            S_set_error("SwitchDiagnosable__Verify : Label rb_swm_Types_cast($switchType).(E|e)valuationSettings_b8 not available in SAD - File.");
            return ( 0, ["Label rb_swm_Types_cast($switchType).(E|e)valuationSettings_b8 not available in SAD - File."] );
        }

        my $detectedValue = 0;
        $detectedValue = 1 if ( $$switchTypeEvaluationSettings_aref[0] & 0b00000010 );

        my $verdict = EVAL_evaluate_value_NOVERDICT( "Switch_" . $singleSwitch . "_Diagnosable__Check", $detectedValue, '==', $value );

        push( @$checkTexts_aref, "Switch type 'rb_swm_NvmCfg_dfst.SwitchCfg_ast($switch_nbr).$label4switchType' =  $switchType" );
        push( @$verdicts_aref,   "VERDICT_NONE" );
        push( @$checkTexts_aref, "Bit 2 of 'rb_swm_Types_cast(switchType).(E|e)valuationSettings_b8'" );
        push( @$verdicts_aref,   "VERDICT_NONE" );
        push( @$checkTexts_aref, "EXP: '$value' DET: '$detectedValue'" );
        push( @$verdicts_aref,   $verdict );

        if ( $verdict eq "VERDICT_PASS" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_Diagnosable__Check: passed\n", 'green' );
        }
        elsif ( $verdict eq "VERDICT_FAIL" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_Diagnosable__Check: failed\n", 'red' );
            $success = -1;
        }

    }

    return ( $success, $checkTexts_aref, $verdicts_aref );
}

=head2 SwitchState__Set

    SwitchState__Set($element, $value, $crashData_href, $mappingData_href );

Returns 1 on success and 0 otherwise.

=cut

sub SwitchState__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $standardSwitchStates_href;

    # "Source4SwitchValue" => "SYC|TSG4_Mapping",
    my $source4SwitchValue = $mappingData_href->{Source4SwitchValue};
    if ( $source4SwitchValue !~ /^SYC|TSG4_Mapping$/i ) {
        my $errorText = "Given 'Source4SwitchValue' is '$source4SwitchValue', \n but it must be one of: 'SYC', 'TSG4_Mapping'";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{MappingMdb2Switch} ) {
        $standardSwitchStates_href = $mappingData_href->{MappingMdb2Switch};
    }
    else {
        $standardSwitchStates_href = {
            0 => 'PositionA',
            1 => 'PositionB',
            2 => 'UndefinedValue',    # or 'Short2Gnd'(?) for value = 2 there must be a list of values; try element 0, if not possible
            3 => 'OpenLineValue',
        };
    }

    # get switch state from MDS value
    my $state = $standardSwitchStates_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    S_w2log( 3, "Environment '$element' will be set to value $value (state '$state')\n" );

    # check if multiple switches are defined for MDS switch name
    my $switches_aref = $mappingData_href->{MultipleSwitches};
    $switches_aref = [ $mappingData_href->{SwitchName} ] if not defined $switches_aref;

    # set switch(es) to state/value $state_value
    my $success = 1;
    my $setTexts_aref;
    foreach my $singleSwitch ( @{$switches_aref} ) {
        my @switches = LC_Get_names('BELT_LOCKS');
        unless ( $singleSwitch ~~ @switches ) {
            my $errorText = "Given 'SwitchName' is '$singleSwitch', \n but this switch name is not known as switch for test system. \n Check your mappings / settings.";
            S_set_error( $errorText, 109 );
            return ( 0, ["ERROR: $errorText."] );
        }

        my $result;

        if ( $state eq "OpenLineValue" ) {
            $result = LC_DisconnectLine($singleSwitch);
            push @$setTexts_aref, "Set '$singleSwitch' to '$state' (disonnect line).";
        }
        else {
            my ( $state_value, $state_unit, $foundInSYC );

            LC_ConnectLine($singleSwitch);

            if ( $source4SwitchValue =~ /^SYC$/i ) {
                ( $foundInSYC, $state_value, $state_unit ) = SYC_SWITCH_get_state_NOERROR( $singleSwitch, $state );

                if ( $state_unit eq 'R' ) {

                    # resistive switch, set resistance
                    $result = LC_SetResistance( $singleSwitch, $state_value );
                    push @$setTexts_aref, "Set '$singleSwitch' to '$state' ($state_value Ohm).";
                }
                elsif ( $state_unit eq 'I' ) {

                    # hall switch, set current
                    $result = LC_SetCurrent( $singleSwitch, $state_value );
                    push @$setTexts_aref, "Set '$singleSwitch' to '$state' ($state_value mA).";
                }
                else {
                    my $errorText = "Not able to fetch data for switch '$singleSwitch' and state '$state' from SYC.";
                    S_set_error( $errorText, 109 );
                    push @$setTexts_aref, "ERROR: $errorText.";
                }
            }
            else {
                # no SYC interface available or no data found in SYC interface for current switch;
                # set switch state using LC_SetLogicalState and rely on TSG4 or MLC mapping
                ( $state_value, $state_unit, $result ) = LC_SetLogicalState( $singleSwitch, $state );

                push @$setTexts_aref, "Set '$singleSwitch' to '$state' ($state_value mA)."  if ( $state_unit eq 'I' );
                push @$setTexts_aref, "Set '$singleSwitch' to '$state' ($state_value Ohm)." if ( $state_unit eq 'R' );
            }
        }
        $success = 0 if not $result;
    }

    return ( $success, $setTexts_aref );
}

=head2 SwitchState__Verify

    SwitchState__Verify($switch, $value); (not exported)

Sets the switch state of $switch to value $value for a crash. 
Uses $standardSwitchStates_href to translate from MDS values to switch states that are known in LIFT_labcar.

Returns 1 on success and 0 otherwise.

=cut

sub SwitchState__Verify {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $standardSwitchStates_href;

    # overwrite standard mapping with MappingMDS2Switch if defined
    if ( exists $mappingData_href->{MappingMDS2Switch} ) {
        $standardSwitchStates_href = $mappingData_href->{MappingMDS2Switch};
    }
    else {
        $standardSwitchStates_href = {
            0 => 'PositionA',
            1 => 'PositionB',
            2 => 'UndefinedValue',    # or 'Short2Gnd'(?) for value = 2 there must be a list of values; try element 0, if not possible
            3 => 'OpenLineValue',
        };
    }

    # get switch state from MDS value
    my $state = $standardSwitchStates_href->{$value};
    unless ( defined $state ) {
        my $errorText = "Given \$value '$value' from MDB is not supported for '$element'.";
        S_set_error( $errorText, 109 );
        return ( 0, ["ERROR: $errorText."] );
    }

    # check if multiple switches are defined for MDS switch name
    my $switches_aref = $mappingData_href->{MultipleSwitches};
    $switches_aref = [ $mappingData_href->{SwitchName} ] if not defined $switches_aref;

    # set switch(es) to state/value $state_value
    my $success = 1;
    my ( $checkTexts_aref, $verdicts_aref );

    foreach my $singleSwitch ( @{$switches_aref} ) {
        my ( $verdictStatus, $verdictPosition );
        my $switch_nbr = PRD_Get_Device_Property($singleSwitch);

        if ( not defined $switch_nbr and not $main::opt_offline ) {
            my $errorText = "Device '$singleSwitch' is not known for Production Diagnosis.";
            S_set_error( $errorText, 109 );
            return ( 0, ["ERROR: $errorText."] );
        }

        # ExtStatusFiltered_en
        my $valueExtStatusFiltered_en_aref = PRD_Read_Memory("rb_swm_SwitchInfo_ast($switch_nbr).ExtStatusFiltered_en");
        return 0 unless @$valueExtStatusFiltered_en_aref;
        my $decExtStatusFiltered_en = S_aref2dec( $valueExtStatusFiltered_en_aref, 'U8' );
        my $decExtStatusFiltered_en_Bit1_2 = $decExtStatusFiltered_en & 0b00000011;

        my $lookUpTableExtStatus_href = {
            PositionA      => 1,
            PositionB      => 1,
            UndefinedValue => 2,
            Short2GndValue => 2,
            OpenLineValue  => 3,
        };

        $verdictStatus = EVAL_evaluate_value_NOVERDICT( "Switch_" . $singleSwitch . "_State__StatusCheck", $decExtStatusFiltered_en_Bit1_2, '==', $lookUpTableExtStatus_href->{$state} );
        push @$checkTexts_aref, "'rb_swm_SwitchInfo_ast($switch_nbr).ExtStatusFiltered_en' - Bit 1,2";
        push @$checkTexts_aref, "EXP: '$lookUpTableExtStatus_href->{$state}' DET: '$decExtStatusFiltered_en_Bit1_2'";
        push @$verdicts_aref,   "VERDICT_NONE";
        push @$verdicts_aref,   $verdictStatus;

        if ( $verdictStatus eq "VERDICT_PASS" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_State__StatusCheck: passed\n", 'green' );
        }
        elsif ( $verdictStatus eq "VERDICT_FAIL" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_State__StatusCheck: failed\n", 'red' );
            $success = -1;
        }

        # PositionFiltered_en
        my $valuePositionFiltered_en_aref = PRD_Read_Memory("rb_swm_SwitchInfo_ast($switch_nbr).PositionFiltered_en");
        return 0 unless @$valuePositionFiltered_en_aref;
        my $decValuePositionFiltered_en = S_aref2dec( $valuePositionFiltered_en_aref, 'U8' );

        my $exp_Position = CalculateSwitchPosition( $state, $switch_nbr );

        $exp_Position = $decValuePositionFiltered_en unless defined $exp_Position;

        $verdictPosition = EVAL_evaluate_value_NOVERDICT( "Switch_" . $singleSwitch . "_State__PositionCheck", $decValuePositionFiltered_en, '==', $exp_Position );
        push @$checkTexts_aref, "'rb_swm_SwitchInfo_ast($switch_nbr).PositionFiltered_en'";
        push @$checkTexts_aref, "EXP: '$exp_Position' DET: '$decValuePositionFiltered_en'";
        push @$verdicts_aref,   "VERDICT_NONE";
        push @$verdicts_aref,   $verdictPosition;

        if ( $verdictPosition eq "VERDICT_PASS" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_State__PositionCheck: passed\n", 'green' );
        }
        elsif ( $verdictPosition eq "VERDICT_FAIL" ) {
            S_w2log( 3, "Switch_" . $singleSwitch . "_State__PositionCheck: failed\n", 'red' );
            $success = -1;
        }
    }

    return ( $success, $checkTexts_aref, $verdicts_aref );
}

sub CalculateSwitchPosition {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CalculateSwitchPosition( $state , $switch_nbr);', @args );

    my $state                    = shift @args;
    my $switch_nbr               = shift @args;
    my $lookUpTablePosition_href = {
        PositionA      => 0,
        PositionB      => 1,
        UndefinedValue => undef,
        Short2GndValue => undef,
        OpenLineValue  => undef,
    };
    my $lookUpTableThresholdBand_href = {
        UndefinedValue => 2,
        Short2GndValue => 0,
        OpenLineValue  => 4,
        PositionA      => 0,
        PositionB      => 1,
    };

    # only continue if sdl is available
    if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_swm_SdlAvailable_bo' } ) ) {
        my $sdlAvailable_aref = PRD_Read_Memory('rb_swm_SdlAvailable_bo');
        my $sdlAvailable = S_aref2dec( $sdlAvailable_aref, 'U8' );
        return $lookUpTablePosition_href->{$state} unless $sdlAvailable;
    }

    # Read sdlSwitch from switchConfiguration
    my @possibleSymbols = ( "rb_swm_NvmCfg_cnvmst.sdlSwitch_en", "rb_swm_NvmCfg_cnvmst.SdlSwitch_en", "rb_swm_NvmCfg_nvmst.sdlSwitch_en", "rb_swm_NvmCfg_nvmst.SdlSwitch_en", "rb_swm_NvmCfg_st.sdlSwitch_en", "rb_swm_NvmCfg_st.SdlSwitch_en" );
    my ( $dec_sdlSwitch, $sdlSwitch_aref );

    foreach my $symbol (@possibleSymbols) {
        if ( PRD_Get_Symbol_Mapping( { 'symbol_name' => $symbol } ) ) {
            $sdlSwitch_aref = PRD_Read_Memory($symbol);
            $dec_sdlSwitch = S_aref2dec( $sdlSwitch_aref, 'U8' );
            last;
        }
    }

    # only continue if current switch == SDL Switch
    return $lookUpTablePosition_href->{$state} unless ( @$sdlSwitch_aref and $dec_sdlSwitch == $switch_nbr );

    my $lowThresholdBand_aref = PRD_Read_Memory("rb_swm_SdlConfiguration_st.LowThresholdBand_en");
    my $dec_lowThresholdBand = S_aref2dec( $lowThresholdBand_aref, 'U8' );

    my $highThresholdBand_aref = PRD_Read_Memory("rb_swm_SdlConfiguration_st.HighThresholdBand_en");
    my $dec_highThresholdBand = S_aref2dec( $highThresholdBand_aref, 'U8' );

    my $position_aref = PRD_Read_Memory("rb_swm_SdlConfiguration_st.Position_en");
    my $dec_Position = S_aref2dec( $position_aref, 'U8' );

    # check that band 1 and 3 are not covered in parallel by threshold bands used for SDL
    # and return correspondig value for PositionA or PositionB
    # continue for all other states
    if ( not( $dec_highThresholdBand >= 3 and $dec_lowThresholdBand <= 1 ) and defined $lookUpTablePosition_href->{$state} ) {
        return $lookUpTablePosition_href->{$state};
    }

    # for all other cases return value as defined in SDL config
    if ( $dec_lowThresholdBand <= $lookUpTableThresholdBand_href->{$state} and $lookUpTableThresholdBand_href->{$state} <= $dec_highThresholdBand ) {
        return $dec_Position;
    }
    else {
        return 0 if $dec_Position;
        return 1;
    }

    return;
}

=head2 FaultManipulation__Set

    FaultManipulation__Set( $value, $crashData_href );

=cut

sub FaultManipulation__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;
    my ( $success, $setTexts_aref );

    my $manipulationConfig_href = { 'fault_name' => $mappingData_href->{FaultName}, };

    if ( $value == 0 ) {
        $manipulationConfig_href->{'action'} = 'qualify';
        $success = PRD_Manipulate_Fault_Memory($manipulationConfig_href);

        push( @$setTexts_aref, "Qualify '$mappingData_href->{FaultName}' by fault manipulation (ProdDiag)." );
    }
    else {
        $success = 1;
        push( @$setTexts_aref, "Nothing to do ... Fault '$mappingData_href->{FaultName}' is automatically dequalified by TC init." );
    }

    return ( $success, $setTexts_aref );
}

=head2 CsEcuHighGXMonOverloadBhvr__Set

    CsEcuHighGXMonOverloadBhvr__Set( $value, $crashData_href );

=cut

sub CsEcuHighGXMonOverloadBhvr__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;
    my ( $result, $setTexts_aref );

    my $sensor      = "HighGXMon";
    my $errorPrefix = "CsEcuHighGXMonOverloadBhvr";

    if ( $value !~ /[0-3]/ ) {
        S_set_error( "$errorPrefix unknown value '$value'. Value must be 0, 1, 2 or 3", 114 );
        return 0;
    }

    my $crashSensorMapping_href = S_get_contents_of_hash( [ 'CRASH_SIMULATION', 'STIMULATION', 'CRASH_SENSORS' ] );
    if ( not defined $crashSensorMapping_href ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' is not defined in project constants.", 114 );
        return 0;
    }

    my $crashSensor = $mappingData_href->{SensorName};
    if ( not defined $crashSensor ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'ENVIRONMENT'=>'$element'=>'SensorName' is not defined in project constants.", 114 );
        return 0;
    }

    my $sensorSimulatorName = $crashSensorMapping_href->{$crashSensor};
    if ( not defined $sensorSimulatorName ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to crash sensor '$crashSensor', but the latter is not found in 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' in project constants.", 114 );
        return 0;
    }

    my $deviceName  = $sensorSimulatorName;
    my $channelName = $sensorSimulatorName;
    if ( $sensorSimulatorName =~ /^\s*(.+)::(.+)\s*$/ ) {
        $deviceName  = $1;
        $channelName = $2;
    }

    if ( $value == 0 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "DISABLE" );
        return ( 1, ["Overload activated in 'DISABLE' mode"] );
    }

    my $stimulationData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'}{$crashSensor};
    if ( not defined $stimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to sensor '$crashSensor', but no data found for '$crashSensor' in the crash data.", 114 );
        return 0;
    }
    my $dataSamples   = scalar( @{ $stimulationData_href->{'SIGNALS'} } );
    my $sampleTime_us = $stimulationData_href->{'SAMPLETIME_US'};

    if ( $value == 1 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "PERMANENT", $dataSamples, $sampleTime_us );
        return ( 1, ["Overload activated in 'PERMANENT' mode"] );
    }

    my $envAddName   = 'CsEcu' . $sensor . 'OverloadStart';
    my $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName};
    $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName} if not defined $startTime_ms;
    if ( not defined $startTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }
    $envAddName = 'CsEcu' . $sensor . 'OverloadEnd';
    my $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName};
    $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName} if not defined $endTime_ms;
    if ( not defined $endTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }

    if ( $value == 2 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "START2END", $dataSamples, $sampleTime_us, [], [], [], $startTime_ms, $endTime_ms );
        return ( 1, ["Overload activated in 'START2END' mode"] );
    }

    my $overloadChannel              = $mappingData_href->{OverloadChannel};
    my $overloadStimulationData_href = $crashData_href->{'STIMULATION'}{'UNMAPPED'}{$overloadChannel};
    if ( not defined $overloadStimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with overload channel '$overloadChannel', but no data found for '$overloadChannel' in the crash data.", 114 );
        return 0;
    }
    my $overloadData_aref    = $overloadStimulationData_href->{'SIGNALS'};
    my $overloadDataSamples  = scalar( @{$overloadData_aref} );
    my $overoadSampleTime_us = $overloadStimulationData_href->{'SAMPLETIME_US'};

    # if $value == 3
    QuaTe_SetOverloadChannel( $deviceName, $channelName, "DBSIGNAL", $dataSamples, $sampleTime_us, $overloadDataSamples, $overoadSampleTime_us, $overloadData_aref );

    return ( 1, ["Overload activated in 'DBSIGNAL' mode"] );
}

=head2 CsEcuHighGYMonOverloadBhvr__Set

    CsEcuHighGYMonOverloadBhvr__Set( $value, $crashData_href );

=cut

sub CsEcuHighGYMonOverloadBhvr__Set {
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;
    my ( $result, $setTexts_aref );

    my $sensor      = "HighGYMon";
    my $errorPrefix = "CsEcuHighGXMonOverloadBhvr";

    if ( $value !~ /[0-3]/ ) {
        S_set_error( "$errorPrefix unknown value '$value'. Value must be 0, 1, 2 or 3", 114 );
        return 0;
    }

    my $crashSensorMapping_href = S_get_contents_of_hash( [ 'CRASH_SIMULATION', 'STIMULATION', 'CRASH_SENSORS' ] );
    if ( not defined $crashSensorMapping_href ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' is not defined in project constants.", 114 );
        return 0;
    }

    my $crashSensor = $mappingData_href->{SensorName};
    if ( not defined $crashSensor ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'ENVIRONMENT'=>'$element'=>'SensorName' is not defined in project constants.", 114 );
        return 0;
    }

    my $sensorSimulatorName = $crashSensorMapping_href->{$crashSensor};
    if ( not defined $sensorSimulatorName ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to crash sensor '$crashSensor', but the latter is not found in 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' in project constants.", 114 );
        return 0;
    }

    my $deviceName  = $sensorSimulatorName;
    my $channelName = $sensorSimulatorName;
    if ( $sensorSimulatorName =~ /^\s*(.+)::(.+)\s*$/ ) {
        $deviceName  = $1;
        $channelName = $2;
    }

    if ( $value == 0 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "DISABLE" );
        return ( 1, ["Overload activated in 'DISABLE' mode"] );
    }

    my $stimulationData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'}{$crashSensor};
    if ( not defined $stimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to sensor '$crashSensor', but no data found for '$crashSensor' in the crash data.", 114 );
        return 0;
    }
    my $dataSamples   = scalar( @{ $stimulationData_href->{'SIGNALS'} } );
    my $sampleTime_us = $stimulationData_href->{'SAMPLETIME_US'};

    if ( $value == 1 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "PERMANENT", $dataSamples, $sampleTime_us );
        return ( 1, ["Overload activated in 'PERMANENT' mode"] );
    }

    my $envAddName   = 'CsEcu' . $sensor . 'OverloadStart';
    my $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName};
    $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName} if not defined $startTime_ms;
    if ( not defined $startTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }
    $envAddName = 'CsEcu' . $sensor . 'OverloadEnd';
    my $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName};
    $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName} if not defined $endTime_ms;
    if ( not defined $endTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }

    if ( $value == 2 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "START2END", $dataSamples, $sampleTime_us, [], [], [], $startTime_ms, $endTime_ms );
        return ( 1, ["Overload activated in 'START2END' mode"] );
    }

    my $overloadChannel              = $mappingData_href->{OverloadChannel};
    my $overloadStimulationData_href = $crashData_href->{'STIMULATION'}{'UNMAPPED'}{$overloadChannel};
    if ( not defined $overloadStimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with overload channel '$overloadChannel', but no data found for '$overloadChannel' in the crash data.", 114 );
        return 0;
    }
    my $overloadData_aref    = $overloadStimulationData_href->{'SIGNALS'};
    my $overloadDataSamples  = scalar( @{$overloadData_aref} );
    my $overoadSampleTime_us = $overloadStimulationData_href->{'SAMPLETIME_US'};

    # if $value == 3
    QuaTe_SetOverloadChannel( $deviceName, $channelName, "DBSIGNAL", $dataSamples, $sampleTime_us, $overloadDataSamples, $overoadSampleTime_us, $overloadData_aref );

    return ( 1, ["Overload activated in 'DBSIGNAL' mode"] );
}

=head2 import
    
There is no builtin import function. It is just an ordinary method (subroutine) defined (or inherited) by modules that wish to export names to another module.
The use function calls the import method for the package used. See also use, perlmod, and Exporter. When using this builtin import Exporter's import method is
no longer called, but Exporter has a special method, 'export_to_level' which is used in situations where you can't directly call Exporter's import method.

http://perldoc.perl.org/Exporter.html

=cut

sub import {
    my @args = @_;

    my $caller = caller;

    # export functions of this module into caller
    FuncLib_TNT_crash_simulation->export_to_level( 1, @args );

    # optional CustLib module (will only be imported if *.pm file exists)
    eval { require FuncLib_CustLib_crash_simulation; 1; };

    if ( $@ =~ /Can't locate FuncLib_CustLib_crash_simulation.pm in \@INC.*/ ) {
        S_w2log( 3, "LIFT_crash_simulation: no 'FuncLib_CustLib_crash_simulation' found. This is OK if there are no CustLib specific functions in crash simulation." );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_CustLib_crash_simulation' : $@", 112 );
    }
    else {
        'FuncLib_CustLib_crash_simulation'->import::into($caller);
    }

    # optional Project module (will only be imported if *.pm file exists)
    eval { require FuncLib_Project_crash_simulation; 1; };

    if ( $@ =~ /Can't locate FuncLib_Project_crash_simulation.pm in \@INC.*/ ) {
        S_w2log( 3, "LIFT_crash_simulation: no 'FuncLib_Project_crash_simulation' found. This is OK if there are no project specific functions in crash simulation." );
    }
    elsif ($@) {
        S_set_error( "Error occured while loading FuncLib 'FuncLib_Project_crash_simulation' : $@", 112 );
    }
    else {
        'FuncLib_Project_crash_simulation'->import::into($caller);
    }

    return 1;
}

1;
__END__

