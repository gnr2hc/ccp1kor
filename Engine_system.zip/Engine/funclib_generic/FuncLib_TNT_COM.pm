package FuncLib_TNT_COM;

######################################################

=head1 FuncLib_TNT_COM

TNT_COM_Functions

Provide TNT COM generic functions

=cut

######################################################

use strict;
use LIFT_general;
use LIFT_can_access;
use LIFT_flexray_access;
use Data::Dumper;


use Exporter;
BEGIN {
	our @ISA = qw(Exporter);
	our @EXPORT = qw(

                    COM_stopMessages
					COM_startMessages
					COM_setSignalState
					COM_fetchSignalByLabel
					COM_fetchSignalName
					COM_fetchSignalDataValue
					COM_fetchSignalInfo
					COM_fetchProtocolForSignal
					COM_rampUpSignal
					COM_stepOrSquareSignal
					COM_CreateCRCErrors
					COM_RemoveCRCErrors
					COM_CreateDLCErrors
					COM_RemoveDLCErrors
					COM_checkCommunication
					COM_traceGetAllMsg
	);
}

use INCLUDES_Project;

my $ProjectConstants = $main::ProjectDefaults;
my $DiagMapping = $ProjectConstants->{'Mapping_DIAG'};
my $FlexrayMapping= $ProjectConstants->{'Mapping_FLEXRAY'};
my $CANMapping= $ProjectConstants->{'Mapping_CAN'};
my $FaultMapping= $ProjectConstants->{'Mapping_FAULT'};
my $DeviceMapping = $ProjectConstants->{'Mapping_DEVICE'};
my $EDRMapping = $ProjectConstants->{'Mapping_EDR'};

=head1 SYNOPSIS

	use strict;
	use LIFT_general;
	use LIFT_can_access;
	use LIFT_flexray_access;
	use FuncLib_TNT_GEN;

=head1 DESCRIPTION

COM generic functions

=cut

=head2 COM_stopMessages

	COM_stopMessages( $messages [,$protocol] );

I<B<Description:>> Stop CAN/Flexray messages.

$messages = Mandatory parameter, message to be stopped.

	When only one message to be stopped, mention the message name as string.
	When more than one messages to be stopped, give the array referance to messages to be stopped.

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>>	none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_stopMessages( ['NMF_BVS'], 'Flexray' );

=cut


sub COM_stopMessages{
    GEN_print_caller();
    my $messages = shift;
    my $protocol = shift;
    my $stateofSuccess = 0;
	my @Messages_Array;
	my $functionToBeCalled;
	my $message_ref;
	my $canMapping;
	my $flexrayMapping;

    unless(defined $protocol)
    {
        $protocol = 'Can';
        GEN_printComment("COM_stopMessages : Parameter Protocol is not received. Setting Protocol as CAN");
    }

	$protocol = uc($protocol); #To print protocol in upper case.

    unless (defined $messages)
    {
        S_set_error("No message reference received. Hence no change for message state",109);
        return $stateofSuccess;
    }

	if(ref($messages) eq "HASH")
	{
		S_set_error("Parameter messages is nither STRING, nor ARRAY_Ref to messages",114);
        return $stateofSuccess;
	}
	if(ref($messages) eq "ARRAY")
	{
		@Messages_Array = @$messages;
	}
	else
	{
		push(@Messages_Array,$messages);
	}

	if($protocol =~  m/^can$/i)
	{
		$canMapping = S_get_contents_of_hash(['Mapping_CAN']); #access the mapping file
		$message_ref = $canMapping->{'CAN_MESSAGES'};
		$functionToBeCalled = \&CA_disable_message;
	}
	elsif ($protocol =~  m/^flexray$/i)
	{
		$flexrayMapping = S_get_contents_of_hash(['Mapping_FLEXRAY']); #access the mapping file
		$message_ref = $flexrayMapping->{'FR_PDU'};
		$functionToBeCalled = \&FR_disable_PDU_update;
	}
	else
	{
		S_set_error("COM_stopMessages : unknown protocol $protocol",114);
		return $stateofSuccess;
	}

	foreach my $Msg(@Messages_Array)
	{
		$stateofSuccess = $functionToBeCalled->($Msg);
		if ($stateofSuccess == 1)
		{
			GEN_printTestStep("Message $Msg disabled in $protocol Protocol");
		}
		else
		{
			S_set_error("Failed to stop the message $Msg in $protocol protocol",15);
		}
	}

	return $stateofSuccess;

} #End of COM_stopMessages


=head2 COM_startMessages

	COM_startMessages( $messages [,$protocol] );

I<B<Description:>> Start CAN/Flexray messages.

$messages = Mandatory parameter, message to be started.

			When only one message to be started, mention the message name as string.
			When more than one messages to be started, give the array referance to messages to be stopped.

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>> none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_startMessages( 'NMF_BVS', 'Flexray' );

=cut

sub COM_startMessages{
    GEN_print_caller();
    my $messages = shift;
    my $protocol = shift;
    my $stateofSuccess = 0;
	my @Messages_Array;
	my $functionToBeCalled;
	my $message_ref;
	my $canMapping;
	my $flexrayMapping;

    unless(defined $protocol)
    {
        $protocol = 'can';
        GEN_printComment("COM_startMessages : Parameter Protocol is not received. Setting Protocol as CAN");
    }

	$protocol = uc($protocol); #To print protocol in upper case.

    unless (defined $messages)
    {
        S_set_error("No message reference received. Hence no change for message state",109);
        return $stateofSuccess;
    }

	if(ref($messages) eq "HASH")
	{
		S_set_error("Parameter messages is nither STRING, nor ARRAY_Ref to messages",114);
        return $stateofSuccess;
	}
	elsif(ref($messages) eq "ARRAY")
	{
		@Messages_Array = @$messages;
	}
	else
	{
		push(@Messages_Array,$messages);
	}

	if($protocol =~  m/^can$/i)
	{
		$canMapping = S_get_contents_of_hash(['Mapping_CAN']); #access the mapping file
		$message_ref = $canMapping->{'CAN_MESSAGES'};
		$functionToBeCalled = \&CA_enable_message;
	}
	elsif ($protocol =~  m/^flexray$/i)
	{
		$flexrayMapping = S_get_contents_of_hash(['Mapping_FLEXRAY']); #access the mapping file
		$message_ref = $flexrayMapping->{'FR_PDU'};
		$functionToBeCalled = \&FR_enable_PDU_update;
	}
	else
	{
		S_set_error("COM_startMessages : unknown protocol $protocol",114);
		return $stateofSuccess;
	}

	foreach my $Msg(@Messages_Array)
	{
		$stateofSuccess = $functionToBeCalled->($Msg);
		if ($stateofSuccess == 1)
		{
			GEN_printTestStep("Message $Msg enabled in $protocol Protocol");
		}
		else
		{
			S_set_error("Failed to stop the message $Msg in $protocol protocol",15);
		}
	}

    return $stateofSuccess;

} #End of COM_startMessages

=head2 COM_CreateCRCErrors

	COM_CreateCRCErrors($aref_MsgNames,$tcpar_Method,[$tcpar_Protocol] );

I<B<Description:>>Create CRC error on CAN/Flexray messages.

$aref_MsgNames = Mandatory parameter, message on which CRC error should be created.

			When only one message under test, mention the message name as string.
			When more than one messages under test, give the array referance to messages to be stopped.
$tcpar_Method = Mandatory parameter, method via which CRC error needs to be created			

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>> none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_CreateCRCErrors( 'NMF_BVS','Constant', 'Flexray' );

=cut

sub COM_CreateCRCErrors{
    GEN_print_caller();
    my $Messages = shift;
    my $Method = shift;
    my $Protocol = shift;
    
    my $StateofSuccess = 0;
    
    unless(defined $Protocol)
    {
        $Protocol = 'Can';
    }
    
    unless (defined $Messages)
    {
        S_set_error("No message reference received. Hence no change for message state | Syntax :COM_CreateCRCErrors(aref_MsgNames,tcpar_Method,[tcpar_Protocol]) ");
        return $StateofSuccess;
    }
    
    unless (defined $Method)
    {
        S_set_error("No method received. Hence no change for message state | Syntax : COM_CreateCRCErrors(aref_MsgNames,tcpar_Method,[tcpar_Protocol]) ");
        return $StateofSuccess;
    }
    
        
    foreach my $Msg(@$Messages)
    {
        GEN_printComment("Creating CRC error for Message : $Msg in $Protocol Protocol", "Blue");
        if(lc($Protocol) =~ m/can/i)
        {
            $StateofSuccess = CA_set_invalidCRC($Msg,$Method);
        }
        elsif(lc($Protocol) =~  m/flexray/i)
        {
            $StateofSuccess = FR_set_invalidCRC($Msg,$Method);
        }
        
    }
      
    return $StateofSuccess;  
    
}
=head2 COM_RemoveCRCErrors

	COM_RemoveCRCErrors($aref_MsgNames,[$tcpar_Protocol] );

I<B<Description:>>Remove CRC error on CAN/Flexray messages.

$aref_MsgNames = Mandatory parameter, message on which CRC error has to be removed.

			When only one message under test, mention the message name as string.
			When more than one messages under test, give the array referance to messages to be stopped.		

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>> none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_RemoveCRCErrors( 'NMF_BVS', 'Flexray' );

=cut


sub COM_RemoveCRCErrors{
    GEN_print_caller();
    my $Messages = shift;
    my $Protocol = shift;
    
    my $StateofSuccess = 0;
    
    unless(defined $Protocol)
    {
        $Protocol = 'Can';
    }
    
    unless (defined $Messages)
    {
        S_set_error("No message reference received. Hence no change for message state | Syntax :COM_RemoveCRCErrors(aref_MsgNames,[tcpar_Protocol]) ");
        return $StateofSuccess;
    }
    
        
    foreach my $Msg(@$Messages)
    {
        GEN_printComment("Removing CRC error for Message : $Msg in $Protocol Protocol", "Blue");
        if(lc($Protocol) =~  m/can/i)
        {
            $StateofSuccess = CA_set_validCRC($Msg);
        }
        elsif(lc($Protocol) =~  m/flexray/i)
        {
            $StateofSuccess = FR_set_validCRC($Msg);
        }
        
    }
       
    return $StateofSuccess;   

}
=head2 COM_CreateDLCErrors

	COM_CreateDLCErrors($aref_MsgNames,[$tcpar_Protocol] );

I<B<Description:>>Create DLC error on CAN/Flexray messages.

$aref_MsgNames = Mandatory parameter, message on which DLC error has to be created.

			When only one message under test, mention the message name as string.
			When more than one messages under test, give the array referance to messages to be stopped.		

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>> none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_CreateDLCErrors( 'NMF_BVS', 'Flexray' );

=cut


sub COM_CreateDLCErrors{
    GEN_print_caller();
    my $Messages = shift;
    my $Protocol = shift;
    
    my $StateofSuccess = 0;
    my $Dlc;
    my $CAN_Mapping = S_get_contents_of_hash(['Mapping_CAN']);
    unless(defined $Protocol)
    {
        $Protocol = 'Can';
    }
    
    unless (defined $Messages)
    {
        S_set_error("No message reference received. Hence no change for message state | Syntax :COM_CreateDLCErrors(aref_MsgNames,tcpar_Method,[tcpar_Protocol]) ");
        return $StateofSuccess;
    }
	
    foreach my $Msg(@$Messages)
    {
    	$Dlc = $CANMapping->{'CAN_MESSAGES'}{$Msg}{'DLC'};
        GEN_printComment("Creating DLC error for Message : $Msg in $Protocol Protocol", "Blue");
			
        if(lc($Protocol) =~ m/can/i)
        {
        	GEN_printComment("Debug step 1 Creating DLC error for Message : $Msg in $Protocol Protocol,$Dlc", "Blue");
            $StateofSuccess = CA_set_DLC($Msg,$Dlc-1);
		}
        elsif(lc($Protocol) =~  m/flexray/i)
        {
            $StateofSuccess = FR_set_DLC($Msg,$Dlc-1);
        }
        
    }
      
    return $StateofSuccess;  
    
}
=head2 COM_RemoveDLCErrors

	COM_RemoveDLCErrors($aref_MsgNames,[$tcpar_Protocol] );

I<B<Description:>>Create DLC error on CAN/Flexray messages.

$aref_MsgNames = Mandatory parameter, message on which DLC error has to be removed.

			When only one message under test, mention the message name as string.
			When more than one messages under test, give the array referance to messages to be stopped.		

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> 1 or 0,

	1: Successful
	0: Failure

I<B<Verdict:>> none

I<B<Error:>> If parameter $messages is not defined and for unknown protocol.

I<B<Example:>> $stateofSuccess = COM_RemoveDLCErrors( 'NMF_BVS', 'Flexray' );

=cut

sub COM_RemoveDLCErrors{
    GEN_print_caller();
    my $Messages = shift;
    my $Protocol = shift;
    
    my $StateofSuccess = 0;
    my $Dlc;
    my $CAN_Mapping = S_get_contents_of_hash(['Mapping_CAN']);
	
    unless(defined $Protocol)
    {
        $Protocol = 'Can';
    }
    
    unless (defined $Messages)
    {
        S_set_error("No message reference received. Hence no change for message state | Syntax :COM_RemoveDLCErrors(aref_MsgNames,[tcpar_Method]) ");
        return $StateofSuccess;
    }

    foreach my $Msg(@$Messages)
    {
	    $Dlc = $CANMapping->{'CAN_MESSAGES'}{$Msg}{'DLC'};
		GEN_printComment("Removing DLC error for Message : $Msg in $Protocol Protocol", "Blue");
        if(lc($Protocol) =~  m/can/i)
        {
            $StateofSuccess = CA_set_DLC($Msg,$Dlc);
        }
        elsif(lc($Protocol) =~  m/flexray/i)
        {
            $StateofSuccess = FR_set_DLC($Msg,$Dlc);			
        }
		
    }   
    
    return $StateofSuccess;

}



=head2 COM_setSignalState

	$PhysicalValue = COM_setSignalState( $signal, $stateOrPhysValue [, $protocol] );

I<B<Description:>> Set CAN/Flexray signal state or physical value.

When $stateOrPhysValue = SignalAvailable :

	COM_setSignalState function, starts the signal and makes signal not available to signal available state.

When $stateOrPhysValue = RandomInRangeValue :

	COM_setSignalState function, read the minimum and maximum value of the signal from CAN/Flexray mapping file and set any randam value between them to  physical value of signal.

When $stateOrPhysValue = SignalNotAvailable :

	COM_setSignalState function, stops the signal and makes signal available to signal not available state.

When $stateOrPhysValue = OutOfRangeValue :

	COM_setSignalState function, read the minimum value of the signal from CAN/Flexray mapping file and set out of range value (minimum value+1) to physical value of signal.

When $stateOrPhysValue = any value (decimal number) :

	COM_setSignalState function, set physical value of signal to $stateOrPhysValue.

$signal = Mandatory parameter, signal to be set to the state.

$stateOrPhysValue = Mandatory parameter, physical value or state to be set to signal.

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. If this parameter not passed, by default this parameter is set to CAN.

I<B<Return value(s):>> $PhysicalValue or 0,

	$PhysicalValue : Returns the physical value written into the signal, when writing of signal is success.
	0 : Returns undef, when any mandatory parameter is not received, or when writing of signal is failed.

I<B<Verdict:>> none

I<B<Error:>> If any Mandatory parameter is not received, or if signal writing fails.

I<B<Example:>> $PhysicalValue = COM_setSignalState( 'RGS_R_ROM_RAM_Fehler', 'SignalAvailable', 'CAN' );

=cut

sub COM_setSignalState{
    GEN_print_caller();
    my $signal = shift;
    my $stateOrPhysValue = shift;
    my $protocol = shift;
    my $signalInfo;
    my $state;
	my $PhysicalValue;

    my $mode = 'phys';  # Mode is selected as phys and this indicates values in CAN/Flexray mapping DataValueList shall be physical data ( Not raw hex data) 

    unless (defined $signal)
    {
        S_set_error("COM_setSignalState : Parameter Signal is not received.",109);
        return 0;
    }

    unless (defined $stateOrPhysValue)
    {
        S_set_error("COM_setSignalState : Parameter StateOrPhysValue is not received.",109);
        return 0;
    }

    unless (defined $protocol)
    {
    	my ($obtainedProtocol, $obtainedSignalLabel) = COM_fetchProtocolForSignal($signal);
    	if(not defined $obtainedProtocol){
	        $protocol = 'Can';
	        GEN_printComment("COM_setSignalState : Parameter Protocol is not received. Setting Protocol as CAN");   		
    	}
    	else {
    		$protocol = $obtainedProtocol;
    		$signal = $obtainedSignalLabel;
    	}
    }

	$protocol = uc($protocol); #To print protocol in upper case.

	$signalInfo = COM_fetchSignalInfo($signal, $protocol);
	
	my $PhysicalValue = $signalInfo->{'DataValueTable'}{$stateOrPhysValue};
	
    unless(defined $PhysicalValue)
    {

        if($stateOrPhysValue eq 'SignalAvailable')
        {
            $PhysicalValue = $signalInfo->{'DataValueTable'}{'Default_Value'};

            if($protocol =~ m/^can$/i)
            {
                COM_startMessages([$signalInfo->{'MESSAGE'}]);
                GEN_printComment("COM_setSignalState : Setting SignalAvailable : Starting Message : ". $signalInfo->{'MESSAGE'} );
            }
            elsif($protocol =~ m/^flexray$/i)
            {
                COM_startMessages([$signalInfo->{'FR_PDU_NAME'}],'Flexray');
                GEN_printComment("COM_setSignalState : Setting SignalAvailable : Starting Message : ". $signalInfo->{'FR_PDU_NAME'});
            }
            return 1;

        }
        elsif($stateOrPhysValue eq 'RandomInRangeValue')
        {
            my $MinValue = $signalInfo->{'DataValueTable'}{'Min_Value'};
            my $MaxValue = $signalInfo->{'DataValueTable'}{'Max_Value'};
            $PhysicalValue = int(rand($MaxValue));
			while($PhysicalValue < $signalInfo->{'DataValueTable'}{'Min_Value'})
			{
				$PhysicalValue = int(rand($MaxValue));
			}
            GEN_printComment("COM_setSignalState : Setting RandomInRangeValue : $PhysicalValue ");

        }
        elsif($stateOrPhysValue eq 'SignalNotAvailable')
        {

            if($protocol =~ m/^can$/i)
            {
                COM_stopMessages([$signalInfo->{'MESSAGE'}]);
                GEN_printComment("COM_setSignalState : Setting SignalNotAvailable : Stopping Message : ". $signalInfo->{'MESSAGE'} );
            }
            elsif($protocol =~ m/^flexray$/i)
            {
                COM_stopMessages([$signalInfo->{'FR_PDU_NAME'}],'Flexray');
                GEN_printComment("COM_setSignalState : Setting SignalNotAvailable : Stopping Message : ". $signalInfo->{'FR_PDU_NAME'});
            }
            return 1;

        }
        elsif($stateOrPhysValue eq 'OutOfRangeValue' or $stateOrPhysValue eq 'RangeExceeded')
        {
            my $MaxValue = $signalInfo->{'DataValueTable'}{'Max_Value'};
            my $factor = $signalInfo -> {'FACTOR'};
            $PhysicalValue = $MaxValue + ( 1 * $factor);
            GEN_printComment("COM_setSignalState : Setting OutOfRangeValue (range exceeded) : $PhysicalValue ");
        }
        elsif($stateOrPhysValue eq 'RangeDeceeded'){           
            my $minValue = $signalInfo->{'DataValueTable'}{'Min_Value'};
            my $factor = $signalInfo -> {'FACTOR'};
            $PhysicalValue = $minValue - (1 * $factor);
            GEN_printComment("COM_setSignalState : Setting RangeDeceeded : $PhysicalValue ");
        }
        elsif($stateOrPhysValue =~ m/^0x[0-9A-F]+$/i or $stateOrPhysValue =~ m/^-*\d+$/ or $stateOrPhysValue =~ m/^-*\d+\.\d+$/ ) #can be a decimal, hex or float value or a negative number too..
        {
			GEN_printTestStep("COM_setSignalState : $signal -> DataValueTable does not belong to any state or any datavalue table values. Hence setting the signal to Physical Value to $stateOrPhysValue ");
			$PhysicalValue = $stateOrPhysValue;
        }
		else
		{
			S_set_error("COM_setSignalState : unknown stateOrPhysValue $stateOrPhysValue",114);
			return 0;
		}

    }

    if(($protocol =~ m/^can$/i) && ($stateOrPhysValue ne 'SignalNotAvailable'))
    {
            $state = CA_write_can_signal ($signal,$PhysicalValue,$mode);
    }
    elsif(($protocol =~ m/^flexray$/i) && ($stateOrPhysValue ne 'SignalNotAvailable'))
    {
            $state = FR_write_flxr_signal ($signal,$PhysicalValue,$mode);
    }

	unless($state)
	{
		S_set_error("Error Occured while writing the Value $PhysicalValue to Signal $signal",15);
        return 0;
	}

    return $PhysicalValue ;

} #End of COM_setSignalState


=head2 COM_fetchSignalByLabel

	COM_fetchSignalByLabel( $label [,$protocol] );

I<B<Description:>> To fetch the signal name by using the label at the CAN or Flexray mapping file.

$label = Mandatory parameter, label to the signal as mentioned in CAN or Flexray mapping file.

Mapping_FR.pm file signal hash structure.

          'AB_Erh_Auf_VB' => {
								.
								.
								'LENGTH' => '2',
								'UNIT' => undef,
								'CANOE_ENV_VAR' => 'S_Airbag_01_AB_Erh_Auf_VB',
								'FACTOR' => '1',
								'Label' => 'SSSLSwitchState',
								'DataValueTable' => {
											'Notused'=>3,
											'AirbagEnabled' => 2,
											'AirbagDisabled' => 1,
											'NOTAVAILABLE' => 0,
										},
								.
							},

$protocol = Optional parameter, this parameter tells signal is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> $signalName or undef,

	$signalName: Returns signal name, when label found in CAN or Flexray mapping file.
	undef: Returns failure, when mandatory parameter missing, unknown protocol and for wrong label.

I<B<Verdict:>> none

I<B<Error:>> If mandatory parameter missing, unknown protocol and for wrong label.

I<B<Example:>> $signalName = COM_fetchSignalByLabel( 'AdaptationSignal', 'Flexray' );

=cut 

sub COM_fetchSignalByLabel{
    GEN_print_caller();
     my $label = shift;
     my $protocol = shift;
     my $Search;

     unless (defined $label)
    {
        S_set_error("COM_fetchSignalByLabel : Missing mandatory parameter $label.",109);
		return undef;
    }

     unless (defined $protocol)
    {
        $protocol = 'Can';
        GEN_printComment("COM_setSignalState : Protocol not passed. Setting Protocol as CAN");
    }

	$protocol = uc($protocol); #To print protocol in upper case.

	#Creating the search hash to be searched in mapping file.
    $Search->{'Label'} = $label;

    my @signalNames = @{COM_fetchSignalName($Search,$protocol)}[0];

	if ( scalar(@signalNames) > 1 ) {
			S_set_error( "There are more than one signals @signalNames found with given label - $label", 0 );    #warning!
			return undef;
	}
	elsif ( scalar(@signalNames) == 0 ) {
			S_set_error( "label - $label is not present in COM mapping file", 0 );                           #warning!
			return undef;
	}
	else {
			return $signalNames[0];
	}

} #End of COM_fetchSignalByLabel


=head2 COM_fetchSignalInfo

	COM_fetchSignalInfo( $Signal [,$protocol] );

I<B<Description:>> To fetch the signal information from CAN/Flexray mapping file.

$signal = Mandatory parameter, signal name for which information should be fetch from the CAN/Flexray mapping file.

$protocol = Optional parameter, this parameter tells signal is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> $SignalInfo_href or undef,

	$SignalInfo_href: Returns hash referance to the signal information, when signal found in CAN/Flexray mapping file.
	undef: Returns failure, when mandatory parameter missing, unknown protocol and for wrong signal.

I<B<Verdict:>> none

I<B<Error:>> If mandatory parameter missing, unknown protocol and for wrong signal.

I<B<Example:>> $SignalInfo_href = COM_fetchSignalInfo( 'AB_Deaktiviert', 'Flexray' );

=cut

sub COM_fetchSignalInfo{

	GEN_print_caller();
	my $Signal = shift;
	my $protocol =shift;
	my $SignalInfo_href;

     unless (defined $Signal)
    {
        S_set_error("COM_fetchSignalInfo : Missing mandatory parameter $Signal.",109);
		return undef;
    }

     unless (defined $protocol)
    {
        $protocol = 'Can';
        GEN_printComment("COM_fetchSignalInfo : Protocol not passed. Setting Protocol as CAN");
    }

	$protocol = uc($protocol); #To print protocol in upper case.

	if($protocol =~ m/^can$/i)
    {
        $SignalInfo_href = CA_get_can_signal_info($Signal);
    }
    elsif($protocol =~ m/^flexray$/i)
    {
        $SignalInfo_href = FR_get_flxr_signal_info($Signal);
    }
	else
	{
        S_set_error("COM_fetchSignalInfo : Unknown protocol $protocol",114);
		return undef;
	}

    return $SignalInfo_href;
} #End of COM_fetchSignalInfo


=head2 COM_fetchSignalDataValue

	COM_fetchSignalDataValue( $label, $DataEnum [,$protocol] );

I<B<Description:>> To fetch the signal data value mentioned in the CAN/Flexray mapping file in the section "DataValueTable".

$label = Mandatory parameter, label to the signal of which data to be fetched from the CAN/Flexray mapping file.

$DataEnum = Mandatory parameter, DataEnum is any key from "DataValueTable" of signal from the CAN/Flexray mapping file.

Mapping_CAN.pm file signal hash structure.

		'RGS_L_Crashabschaltung' =>
		{
				.
				.
				'SIGNAL_NAME' => 'RGS_L_Crashabschaltung',
				'SENDER' => 'RGS_VL',
				'TYPE' => 'UNSIGNED',
				'MESSAGE' => 'RGS_VL_02',
				'Label' => 'SSSLSwitchState',				
				'DataValueTable' => {
										'Valid' => 11,
										'Invalid' => 0,
										'MIN_Value => 10,
										'MAX_Value => 25
									},
				'LENGTH' => 1,
				.
				.
		},

$protocol = Optional parameter, this parameter tells signal is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> $dataValue or undef,

	$dataValue: Any key value from "DataValueTable" of signal from the CAN/Flexray mapping file.
	undef: Returns failure, when mandatory parameter missing, unknown protocol and for wrong label.

I<B<Verdict:>> none

I<B<Error:>> If mandatory parameter missing, unknown protocol and for wrong label.

I<B<Example:>> $dataValue = COM_fetchSignalDataValue( 'AdaptationSignal', 'Set', 'Flexray' );

=cut

sub COM_fetchSignalDataValue{

	 GEN_print_caller();
	 my $label = shift;
	 my $DataEnum = shift;
	 my $protocol =shift;
	 my $SignalInfo; 

	unless (defined $label)
    {
        S_set_error("COM_fetchSignalDataValue : Missing mandatory parameter $label.",109);
		return undef;
    }

	unless (defined $DataEnum)
    {
        S_set_error("COM_fetchSignalDataValue : Missing mandatory parameter $DataEnum.",109);
		return undef;
    }

     unless (defined $protocol)
    {
        $protocol = 'CAN';
        GEN_printComment("COM_fetchSignalInfo : Protocol not passed. Setting Protocol as CAN");
    }

	$protocol = uc($protocol); #To print protocol in upper case.

	my $Signal = COM_fetchSignalByLabel($label,$protocol);

	$SignalInfo = COM_fetchSignalInfo($Signal,$protocol);

	if(defined $SignalInfo->{'DataValueTable'})
	{
		if(defined $SignalInfo->{'DataValueTable'}{$DataEnum})
		{
			return $SignalInfo->{'DataValueTable'}{$DataEnum};
		}
		else
		{
			GEN_printComment(" Signal $Signal -> 'DataValueTable' in $protocol mapping file, does not contain enumeration $DataEnum ");
			return undef;
		}
	}
	else
	{
		GEN_printComment(" Signal $Signal -> 'DataValueTable' is not defined in $protocol mapping file ");
		return undef;	
	}

} #End of COM_fetchSignalDataValue


=head2 COM_fetchSignalName

	COM_fetchSignalName( $searchHashRef, [,$protocol] );

I<B<Description:>> To fetch the signals from the CAN/Flexray mapping file which matches the search HASH fields (in $searchHashRef).

$searchHashRef = Mandatory parameter, HASH ref containing the search fields from the CAN/Flexray mapping file.

I<B<Example:>> This function can be used to fetch a list of signals which have the same label.

or it can be used to fetch the signal names, which are in same message.

		'RGS_L_Crashabschaltung' =>
		{
				.
				.
				'SIGNAL_NAME' => 'RGS_L_Crashabschaltung',
				'SENDER' => 'RGS_VL',
				'TYPE' => 'UNSIGNED',
				'MESSAGE' => 'RGS_VL_02',
				'Label' => 'SSSLSwitchState',				
				'DataValueTable' => {
										'Valid' => 11,
										'Invalid' => 0,
										'MIN_Value => 10,
										'MAX_Value => 25
									},
				'LENGTH' => 1,
				.
				.
		},
		
To find this state, search hashs can be:

	$searchHashRef->{'Label'} = 'SSSLSwitchState';
	$searchHashRef->{'MESSAGE'} = 'RGS_VL_02';

$protocol = Optional parameter, this parameter tells signal is from CAN or Flexray. By default this parameter considered as CAN.

I<B<Return value(s):>> \@signalArray or undef,

	\@signalArray: Referance to the array of signal names which have the $searchHashRef.
	undef: Returns failure, when mandatory parameter missing, unknown protocol.

I<B<Verdict:>> none

I<B<Error:>> If mandatory parameter missing, unknown protocol.

=cut

sub COM_fetchSignalName{

	GEN_print_caller();
	my $searchHashRef =shift;
	my $protocol = shift;
	my $signalName = ''; 
	my @signalArray;
	my $COMmapping;

	unless (defined $searchHashRef)
    {
        S_set_error("COM_fetchSignalName : Missing mandatory parameter $searchHashRef.",109);
		return undef;
    }

	unless (defined $protocol)
	{
		$protocol = 'CAN';
		GEN_printComment("COM_fetchSignalName : Protocol not passed. Setting Protocol as CAN");
	}

	#access the mapping files
	if($protocol =~ m/^can$/i)
	{
		$COMmapping = S_get_contents_of_hash(['Mapping_CAN']);
	}
	elsif($protocol =~ m/^flexray$/i)
	{
		$COMmapping = S_get_contents_of_hash(['Mapping_FLEXRAY']);
	}
	else
	{
		S_set_error("COM_fetchSignalName : Unknown protocol $protocol",114);
		return undef;
	}

	unless(defined $COMmapping)
	{
		GEN_printComment("Mapping File not found. \$LIFT_PROJECT::Defaults->{'Mapping_CAN'} OR \$LIFT_PROJECT::Defaults->{'Mapping_FLEXRAY'} is not defined");
		return undef;
	}

	foreach my $signal (keys %{$COMmapping})
	{
		$signalName = $signal;

		#Skip the hash which do not have sub hashes defined inside.
		if(($signalName eq 'CAN_MESSAGES') or ($signalName eq 'NODE_UNDER_TEST') or ($signalName eq  'FR_PDU' ))
		{
			next;
		}

		foreach my $SearchField (keys %{$searchHashRef})
		{
			my $matched = 0;
			my $check = $searchHashRef->{$SearchField};
			if($COMmapping->{$signal}{$SearchField} !~ m/^\Q$check\E$/i)
			{
				$matched = 1;
			}
			if($matched == 0)
			{
				GEN_printComment("Fetch signalName : Adding Signal : $signalName");
				push(@signalArray,$signalName);
			}
		}
	}

	return \@signalArray;

} #End of COM_fetchSignalName


=head2 COM_fetchProtocolForSignal

    $protocol = COM_fetchProtocolForSignal( $Signal );

I<B<Description:>> To fetch the signal information whether it is a CAN or Flexray signal

$signal = Mandatory parameter, signal name for which information should be fetch from the CAN/Flexray mapping file.

I<B<Return value(s):>> $protocol or undef,

    $protocol: Returns 'FR' or 'CAN'
    undef: Returns nothing, in case protocol can't be obtained from signal name or mapping

I<B<Verdict:>> none

I<B<Error:>> If mandatory parameter missing

I<B<Example:>> a) Protocol given in signal name
                    Syntax of signal name: 'Protocol::SignalName'
                    Example:
                        ($protocol , $signalName)= COM_fetchProtocolForSignal( 'FR::AB_Deaktiviert');
                            --> $protocol = 'FLEXRAY', $signalName = 'AB_Deaktiviert'
                        ($protocol , $signalName)= COM_fetchProtocolForSignal( 'CA::AB_Deaktiviert');
                            --> $protocol = 'CAN', $signalName = 'AB_Deaktiviert'
                b) Protocol to be obtained from mapping
                   --> Function will check whether given signal name is there in flexray or can mapping and set $protocol accordingly
                    Syntax of signal name: 'SignalName'
                    Example:
                        ($protocol , $signalName)= COM_fetchProtocolForSignal( 'AB_Deaktiviert');
                            --> $protocol = 'FLEXRAY' if 'AB_Deaktiviert' is defined in 'Mapping_FLEXRAY'
                                $protocol = 'CAN' if 'AB_Deaktiviert' is defined in 'Mapping_CAN', 
                                $signalName = 'AB_Deaktiviert'

=cut

sub COM_fetchProtocolForSignal{

    GEN_print_caller();
    my $Signal = shift;
    
     unless (defined $Signal){
        S_set_error("COM_fetchProtocolForSignal : Missing mandatory parameter $Signal.",109);
        return undef;
    }

    my $protocol;
    my @protocolInSignalName = split(/::/, $Signal);
    my $numberOfElements = @protocolInSignalName;

    if($numberOfElements == 2){
        S_w2log(3, "COM_fetchProtocolForSignal: Get protocol from signal prefix");
        $protocol = $protocolInSignalName[0];
	    if(lc($protocolInSignalName[0]) eq 'fr' or lc($protocolInSignalName[0]) eq 'ca'){
	        S_w2log(3, "COM_fetchProtocolForSignal: Protocol ($protocol) found in signal name");
	        $protocol = 'CAN' if(lc($protocolInSignalName[0]) eq 'ca');
	        $protocol = 'FLEXRAY' if(lc($protocolInSignalName[0]) eq 'fr');
	        $Signal = $protocolInSignalName[1];
	    }
	    else {
	    	S_set_warning("Given protocol '$protocol' as prefix to signal name not known.");
	    	return;
	    }  	
    }
    elsif($numberOfElements == 1){
    	S_w2log(3, "COM_fetchProtocolForSignal: Get protocol from mapping");
    	my $mappingCAN = S_get_contents_of_hash_NOERROR( ['Mapping_CAN'] );
    	my $signalFoundInCAN = 0;
    	if((defined $mappingCAN -> {$Signal}) or (defined $mappingCAN -> {'CAN_MESSAGES'} -> {$Signal})){
    		$signalFoundInCAN = 1;
    	}

        my $flexrayMapping = S_get_contents_of_hash_NOERROR( ['Mapping_FLEXRAY'] );
        my $signalFoundInFlexray = 0;
    	if((defined $flexrayMapping -> {$Signal}) or (defined $flexrayMapping -> {'FR_PDU'} -> {$Signal})){
    		$signalFoundInFlexray = 1;
    	}
    	
    	if($signalFoundInCAN and $signalFoundInFlexray){
    		S_set_warning("Signal '$Signal' is there in both flexray and CAN mapping. Can't be mapped to a specific protocol.");
    		return;
    	}
    	elsif($signalFoundInCAN and not $signalFoundInFlexray){
    		$protocol = 'CAN';
    	}
        elsif(not $signalFoundInCAN and $signalFoundInFlexray){
            $protocol = 'FLEXRAY';
        }
    }
    else {
    	S_set_warning("Given signal name '$Signal' not in right format.\n"
    	               ."Give 'SignalLabel' or 'Protocol::SignalLabel'.\n"
    	               ."Example: 'VehicleSpeed', 'CAN::VehicleSpeed'");
    	return;
    }   
    
    S_w2log(3, "COM_fetchProtocolForSignal: Return Protocol ($protocol) for $Signal");

    return ($protocol, $Signal);
} #End of COM_fetchProtocolForSignal



#COM_rampUpSignals
=head2 COM_rampUpSignal

	$PhysicalValue = COM_rampUpSignals( $signal, $deltaT_ms , $nbrOfValues, [$minValue, $maxValue, $protocol] );

I<B<Description:>> Ramp up CAN/Flexray signal with physical values from min to max value.

$signal = Mandatory parameter, signal to be ramped up.

$deltaT_ms = Mandatory, Time in ms between each signal value to be set

$nbrOfValues = Mandatory, Number of Values to be set in range 

$minValue = Optional, gives start value. If not given must be defined in CAN mapping as 'Min_Value'

$maxValue = Optional, gives end value. If not given must be defined in CAN mapping as 'Max_Value'

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. If this parameter not passed, by default this parameter is set to CAN.

$mode=Optional, gives which format value is written to signal. Default is 'phys'.

I<B<Return value(s):>> $PhysicalValue or 0,

	$PhysicalValue : Returns the physical value written into the signal, when writing of signal is success.
	0 : Returns undef, when any mandatory parameter is not received, or when writing of signal is failed.

I<B<Verdict:>> none

I<B<Error:>> If any Mandatory parameter is not received, or if signal writing fails.

I<B<Example:>> COM_rampUpSignals( 'ApedPos_Pc_ActlArb', 500, 10 );
			   COM_rampUpSignals( 'ApedPos_Pc_ActlArb', 500, 10, 0, 100, 'CAN' );

=cut

sub COM_rampUpSignal{

    GEN_print_caller();
    my $signal = shift;
    my $deltaT_ms = shift;
    my $nbrOfValues = shift;
    my $minValue = shift;
    my $maxValue = shift;
	my $protocol = shift;
	my $mode=shift;
    $mode = 'phys' unless (not defined $mode);  # Mode is selected as phys and this indicates values in CAN/Flexray mapping DataValueList shall be physical data ( Not raw hex data) 

    unless (defined $signal) {
        S_set_error("COM_rampUpSignals : Parameter Signal is not received.",109);
        return 0;
    }

    unless (defined $protocol){
        $protocol = 'Can';
        GEN_printComment("COM_rampUpSignals : Parameter Protocol is not received. Setting Protocol as CAN");
    }

	my $signalInfo = COM_fetchSignalInfo($signal, $protocol); # gets signal info from COM mapping

	unless (defined $minValue){
        $minValue = $signalInfo->{'DataValueTable'}->{'Min_Value'};
		unless (defined $minValue) {
			S_set_error("No min value defined as parameter or in mapping! Nothing will be returned", 109) ;
			return;		
		}
    }
	unless (defined $maxValue){
        $maxValue = $signalInfo->{'DataValueTable'}->{'Max_Value'};
		unless (defined $maxValue) {
			S_set_error("No min value defined as parameter or in mapping! Nothing will be returned", 109) ;
			return;		
		}
    }

	$protocol = uc($protocol); #To print protocol in upper case.

	my @physicalRampValues;
	my $physicalIncrement = ($maxValue - $minValue)/($nbrOfValues - 1);
	my $currentValue = $minValue;
	
	for (my $sampleNbr = 1; $sampleNbr < $nbrOfValues; $sampleNbr ++) 
	{
		push(@physicalRampValues, $currentValue);
		$currentValue = $currentValue + $physicalIncrement;
	}
	$currentValue = $maxValue;	
 	push(@physicalRampValues, $currentValue);

	foreach my $physicalValue (@physicalRampValues)
	{
		S_w2log(3, "Set $signal to $physicalValue");
		my $valueSet = COM_setSignalState ($signal, $physicalValue, $protocol);
		unless(defined $valueSet) {		
			S_set_warning("Setting Signal $signal to '$physicalValue' was not successful. Go to next signal value.");
		}		
		S_wait_ms($deltaT_ms);
	}
   
   return 1;

} #End of COM_rampUpSignals

#COM_stepOrSquareSignal
=head2 COM_stepOrSquareSignal

	$success = COM_stepOrSquareSignal( $signal, $value1, $duration_ms, $value2, [$protocol, $squareDuration_ms] );

I<B<Description:>> Step up (and optionally down again) CAN/Flexray signal with physical values.

1) Step up - give only mandatory parameters

						     Value 2  -----
                                      |						 	
                                      |  					 
						 - Duration --|                      
                         |            |   					 
									  |
			  Value 1    ------------- 						 		
						 |
some initial value	-----


2) Square signal - give all parameters

									  - Square Duration     -					

						     Value 2  -----------------------
                                      |						 |	
                                      |  					 |
						 - Duration --|                      |
                                      |   					 |
			  Value 1    ------------- 						 ------ 		
						 |
some initial value	-----

$signal = Mandatory parameter, signal to manipulated.

$value1 = First state to be set (step up/down)

$duration_ms = Duration of Value 1 being set

$value2 = Optional, gives start value. If not given must be defined in CAN mapping as 'Min_Value'

$protocol = Optional parameter, this parameter tells message is from CAN or Flexray. If this parameter not passed, by default this parameter is set to CAN.

$squareDuration_ms = Optional, gives square duration. If not given must be defined in CAN mapping as 'Max_Value'

$mode=Optional, gives which format value is written to signal. Default is 'phys'.

I<B<Return value(s):>> 1 on success or 0,

	$success : Manipulation successful
	0 : Returns undef, when any mandatory parameter is not received, or when writing of signal is failed.

I<B<Verdict:>> none

I<B<Error:>> If any Mandatory parameter is not received, or if signal writing fails.

I<B<Example:>> COM_rampUpSignals( 'ApedPos_Pc_ActlArb', 1, 500, 10 );
			   COM_rampUpSignals( 'ApedPos_Pc_ActlArb', 500, 10, 0, 100, 'CAN' );

=cut

sub COM_stepOrSquareSignal{

    GEN_print_caller();
    my $signal = shift;
    my $firstValue = shift;
    my $durationFirstValue_ms = shift;
    my $secondValue = shift;
	my $protocol = shift;
    my $squareDuration_ms = shift;

    my $mode=shift;
    $mode = 'phys' unless (not defined $mode); # Mode is selected as phys and this indicates values in CAN/Flexray mapping DataValueList shall be physical data ( Not raw hex data) 

    unless (defined $signal) {
        S_set_error("COM_stepOrSquareSignal : Parameter Signal is not received.",109);
        return 0;
    }
    unless (defined $firstValue) {
        S_set_error("COM_stepOrSquareSignal : Parameter first signal value is not received.",109);
        return;
    }
    unless (defined $durationFirstValue_ms) {
        S_set_error("COM_stepOrSquareSignal : Parameter duration of first signal value is not received.",109);
        return;
    }
	
    unless (defined $secondValue) {
        S_set_error("COM_stepOrSquareSignal : Parameter second signal value is not received.",109);
        return;
    }

    unless (defined $protocol){
        $protocol = 'Can';
        GEN_printComment("COM_stepOrSquareSignal : Parameter Protocol is not received. Setting Protocol as CAN");
    }

	my $manipulationType = 'Square';
   unless (defined $squareDuration_ms){
        $manipulationType = 'Step';
        GEN_printComment("COM_stepOrSquareSignal : No squre duration recieved. Therefore manipulation type will be step.");
    }

	my $signalInfo = COM_fetchSignalInfo($signal, $protocol); # gets signal info from COM mapping

	$protocol = uc($protocol); #To print protocol in upper case.

	GEN_printComment("Set $signal to first value: $firstValue");
	my $valueSet = COM_setSignalState ($signal, $firstValue, $protocol);
	unless(defined $valueSet) {		
		S_set_warning("Setting Signal $signal to '$firstValue' was not successful. Return nothing.");
		return;
	}
	$valueSet = undef;
	S_wait_ms($durationFirstValue_ms);

	GEN_printComment("Set $signal to second value: $secondValue");
	$valueSet = COM_setSignalState ($signal, $secondValue, $protocol);
	unless(defined $valueSet) {		
		S_set_warning("Setting Signal $signal to '$secondValue' was not successful. Return nothing.");
		return;
	}
	$valueSet = undef;
	# Function end if manipulation type is step
	return 1 if ($manipulationType eq 'Step');
	
	GEN_printComment("Wait for $squareDuration_ms ms");
	S_wait_ms($squareDuration_ms);

	GEN_printComment("Set $signal back to first value: $firstValue");
	$valueSet = COM_setSignalState ($signal, $firstValue, $protocol);
	unless(defined $valueSet) {		
		S_set_warning("Setting Signal $signal to '$secondValue' was not successful. Return nothing.");
		return;
	}

    return 1;

} #End of COM_rampUpSignals

=head2 COM_checkCommunication

	COM_checkCommunication($can_log_file,$msgList,[,$can_bus_nbr]);
$can_log_file => log file path. Eg:"C:\\MKS\\Projects\\TurboLIFT\\Projects\\CN_MS\\Geely_NL_3\\reports\\TC_NMnMM_Shutdown-ABS-StepStep7.asc";
$can_bus_nbr => CAN channel on which comm status is to be checked
$msgList => List of messages whose transmission status is to be checked

I<B<Description:>> Checks the messages among the $msgList that are present in trace

I<B<Return value(s):>> Reference to array containing messages among the $msgList that are present in trace
I<B<Error:>> If any one of mandatory parameter is not defined.
I<B<Example:>>$arrRef = COM_checkCommunication($can_log_file,['ABM_1','YRS1'],1);

=cut

sub COM_checkCommunication
{
	GEN_print_caller();
	my $can_log_file = shift;
	my $msgList      = shift;
	my $can_bus_nbr  = shift;
	my ( @msgInTrace, @uniqueMsgs );
	unless ( defined($can_log_file) )
	{
		S_set_error( "SYNTAX: COM_checkCommunication( can_log_file , $msgList ,can_bus_nbr)", 110 );
		return 0;
	}
	unless ( defined($msgList) )
	{
		S_set_error( "SYNTAX: COM_checkCommunication( can_log_file , $msgList ,can_bus_nbr)", 110 );
		return 0;
	}
	unless ( defined($can_log_file) )
	{
		$can_bus_nbr = 1;
	}
	return 1 if $main::opt_offline;    # just return if running in offline mode
	my $msgRef = COM_traceGetAllMsg( $can_log_file, $can_bus_nbr );
	foreach my $msg (@$msgList)
	{
		foreach my $timestamps ( sort keys %$msgRef )
		{
			if ( $msgRef->{$timestamps}{'MsgID'} eq $msg )
			{
				push( @msgInTrace, $msg );
			}
		}
	}
	@uniqueMsgs = keys %{ { map { $_ => 1 } @msgInTrace } };    #to remove repeated elements of array

	#	S_w2rep( Dumper( \@msgInTrace ) );
	S_w2rep( Dumper( \@uniqueMsgs ) );
	if ( scalar(@uniqueMsgs) == 0 )
	{
		S_w2rep(" The messages in the '@$msgList' are not present in trace");
		return 'Not Transmitted';
	}
	else
	{
		S_w2rep(" The messages '@uniqueMsgs' from '@$msgList' are present in trace");
		return 'Transmitted';
	}
}#End of COM_checkCommunication
=head2 COM_traceGetAllMsg

	COM_traceGetAllMsg($can_log_file[,$can_bus_nbr]);

I<B<Description:>> returns hash referance to all the messsages in the trace incuding the error messages;

I<B<Return value(s):>> Reference to hash and sets error if no messages are found in the log.
I<B<Error:>> If any one of mandatory parameter is not defined
I<B<Example:>>COM_traceGetAllMsg($can_log_file,$can_bus_nbr);

=cut

sub COM_traceGetAllMsg
{
	GEN_print_caller();
	my $can_log_file = shift;
	my $can_bus_nbr  = shift;
	my ( $msg_cnt, $all_msgs );
	unless ( defined($can_log_file) )
	{
		S_set_error( "SYNTAX: COM_traceGetAllMsg( can_log_file [, can_bus_nbr])", 110 );
		return 0;
	}
	unless ( defined $can_bus_nbr )
	{
		$can_bus_nbr = 1;
	}
	return 1 if $main::opt_offline;    # just return if running in offline mode
	my $traceFH = new FileHandle;
	unless ( $traceFH->open($can_log_file) )
	{
		S_set_error( " Couldnt open CAN Trace '$can_log_file' $!", 131 );
		return 0;
	}
	$msg_cnt = 0;
	S_w2log( 4, " COM_traceGetAllMsg : Reading CAN frame on Bus-Nbr $can_bus_nbr from $can_log_file\n" );
	while (<$traceFH>)
	{
		
		if (/^\s*(\d+\.\d+)\s+$can_bus_nbr\s+(\w+)/i)
		{
			$msg_cnt++;
			$all_msgs->{$1}{'MsgID'} = $2;
		}
	}
	$traceFH->close;
	if ( $msg_cnt == 0 )
	{
		S_set_error("No messages found in trace log");
	}
	return $all_msgs;
}
1;