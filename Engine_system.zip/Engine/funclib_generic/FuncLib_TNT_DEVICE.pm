package FuncLib_TNT_DEVICE;

######################################################

=head1 NAME

FuncLib_TNT_Device

FuncLib for handling of ECU Peripherals (External Devices)

Provide LIFT Device functions - generic functions

=cut

######################################################

use strict;
use LIFT_general;
use LIFT_MLC;
use LIFT_TSG4;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_CANoe;
use LIFT_POWER;

use Exporter;

BEGIN {
	our @ISA    = qw(Exporter);
	our @EXPORT = qw(
	  DEVICE_fetchDeviceInfo
	  DEVICE_fetchDeviceName
	  DEVICE_fetchDeviceType
	  DEVICE_fetchDeviceNamebyDeviceNumber
	  DEVICE_fetchSwitchType
	  DEVICE_fetchDeviceThreshold
	  DEVICE_fetchDevicebyLabel
	  DEVICE_setDeviceState
	  DEVICE_setDeviceResistance
	  DEVICE_setDeviceCurrent
	  DEVICE_resetDeviceState
	  DEVICE_shortLines
	  DEVICE_undoShortLines
	  DEVICE_setDeviceConfiguration
	);
}
use INCLUDES_Project;

=head1 SYNOPSIS

    use LIFT_general;
	use LIFT_MLC;
	use LIFT_TSG4;
	use LIFT_PD;
	use LIFT_evaluation;
	use LIFT_CANoe;
	use LIFT_POWER;
    reads constants/mappings from Device mapping file Mapping_DEVICE.pm


=head1 DESCRIPTION

Generic functions for devices

=cut

=head2 DEVICE_fetchDeviceInfo

	$deviceInfo_Href = DEVICE_fetchDeviceInfo($devicename);

I<B<Description:>> Returns for the HASH ref corresponding to $devicename in Mapping_DEVICE (device mapping) file.

$devicename  =  device name which is present in the the device mapping file

Device Mapping file should be declared in the Project_CFG file

example from CFG file:

	require './config/Mapping_DEVICE.pm';  
	$LIFT_FaultMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'}; 


I<B<Return:>> ref of found HASH

I<B<Verdict:>> none

I<B<Error:>> sets error if device name is not found in the mapping file

=cut	

sub DEVICE_fetchDeviceInfo {
	GEN_print_caller();

	my $devicename = shift;
	my %deviceInfo;

	#access the mapping file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );

	unless ( defined $devicename ) {    #check if parameters are defined
		S_set_error( "device name is not defined", 114 );    #Error!
		return undef;
	}

	foreach my $key ( keys %{ $DeviceMapping->{$devicename} } ) {
		if ( defined $DeviceMapping->{$devicename}{$key} ) {
			$deviceInfo{$key} = $DeviceMapping->{$devicename}{$key};
		}
		else {
			S_set_error( "$devicename -> $key is not found in device mapping file", 0 );    #warning!
			return undef;
		}
	}

	if ( keys(%deviceInfo) ) {                                                              #check if keys are read successfully from mapping file
		return \%deviceInfo;
	}
	else {
		S_set_error( "$devicename is not found in device mapping file", 114 );              #error!
		return undef;
	}

}

=head2 DEVICE_fetchDeviceName

	$matchedkeys_aref = DEVICE_fetchDeviceName($SearchHashRef);

I<B<Description:>> Searches for the key(s) from the device mapping file which matches the search HASH fields

$SearchHashRef = HASH ref containing the search fields from the mapping file

I<B<Example:>> This function can be used to get a list of devices which match a particular type 

or it can be used to get the device name which matches with a particular label..

	'BLFD' => {
					'label' => 'BeltLockFrontDriver',
					'type' => 'hall',
		},

To find this device, search hash can be:

	$SearchHashRef->{'label'} = 'BeltLockFrontDriver';

The mapping file should be defined in the CFG file of the project:

	$LIFT_DeviceMapping = $LIFT_PROJECT::Defaults->{'Mapping_DEVICE'};

I<B<Return:>> array reference to a list of matched keys (undef for no match)

I<B<Verdict:>> none

I<B<Error:>> sets error(warning) for wrong/undefined mapping file

=cut

sub DEVICE_fetchDeviceName {
	GEN_print_caller();

	my $SearchHashRef = shift;
	my $foundkey      = '';
	my @returnarray;
	my $matched;

	#access the mapping file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );

	unless ( defined $DeviceMapping ) {
		S_set_error( "Device mapping File not found. Check the Project_CFG document for variable LIFT_DeviceMapping", 1 );    #error!
		return undef;
	}

	foreach my $key ( keys %{$DeviceMapping} ) {
		$foundkey = $key;

		$matched = 0;

		foreach my $SearchField ( keys %{$SearchHashRef} ) {
			if ( $DeviceMapping->{$key}{$SearchField} ne $SearchHashRef->{$SearchField} ) {
				$matched = 1;
			}
		}

		if ( $matched == 0 ) {
			GEN_printComment("Fetch key : Adding key : $foundkey");
			push( @returnarray, $foundkey );
		}

	}
	return \@returnarray;
}

=head2 DEVICE_fetchDeviceNamebyDeviceNumber
      
	$name = DEVICE_fetchDeviceNamebyDeviceNumber ($deviceNumber);

I<B<Description:>>  fetch the name of the device from the device mapping file based on the number 

$deviceNumber = ref number of the device. e.g. SQ1 or WL1 etc

I<B<Return:>> return the device name

I<B<Verdict:>> none

I<B<Error:>> sets warning if device name is not defined for the corresponding number/label

=cut

sub DEVICE_fetchDeviceNamebyDeviceNumber {
	GEN_print_caller();

	my $deviceNumber = shift;
	my $devicetype;
	my $deviceName;
	my $deviceNameLabel;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	if ( $deviceNumber =~ m/SQ/i ) {
		$devicetype = "SQUIBS";
	}
	elsif ( $deviceNumber =~ m/SW/i ) {
		$devicetype = "SWITCHES" if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		$devicetype = "BELT_LOCKS" if ( $TestHW eq 'TSG4' );
	}
	elsif ( $deviceNumber =~ m/BL/i ) {
		$devicetype = "SWITCHES" if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		$devicetype = "BELT_LOCKS" if ( $TestHW eq 'TSG4' );
	}
	elsif ( $deviceNumber =~ m/PAS/i ) {
		$devicetype = "PAS" if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		$devicetype = "PAS_LINES" if ( $TestHW eq 'TSG4' );
	}
	elsif ( $deviceNumber =~ m/WL/i ) {
		$devicetype = "WARNING_LAMPS";
	}

	$deviceNameLabel = "$deviceNumber" . "_Name";

	$deviceName = $main::ProjectDefaults->{'MLC'}{$devicetype}{$deviceNameLabel} if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	$deviceName = $main::ProjectDefaults->{'TSG4'}{$devicetype}{$deviceNameLabel} if ( $TestHW eq 'TSG4' );

	unless ( defined $deviceName ) {
		S_set_error( "device for label $deviceNameLabel is not defined in device mapping file", 0 );    #warning!
		return undef;
	}

	GEN_printComment("Fetched device name: $deviceName");
	return $deviceName;

}

=head2 DEVICE_fetchDeviceType
      
	$type = DEVICE_fetchDeviceType ($devicename);

I<B<Description:>>  fetch the type of the device from the device mapping file

$devicename = name of device

I<B<Return:>> return the device type (return values can be: 'Squib' or 'Switch' or 'PAS' or 'Lamp')

I<B<Verdict:>> none

I<B<Error:>> sets warning if device is not found in the mapping file

=cut	

sub DEVICE_fetchDeviceType {
	GEN_print_caller();

	my $devicename = shift;
	my ( $devicetype, $section );
	my $MLCMapping;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	$MLCMapping = $LIFT_PROJECT::Defaults->{'MLC'}  if ( $TestHW eq 'LabCar' );
	$MLCMapping = $LIFT_PROJECT::Defaults->{'MLC'}  if ( $TestHW eq 'MLC' );
	$MLCMapping = $LIFT_PROJECT::Defaults->{'TSG4'} if ( $TestHW eq 'TSG4' );

	foreach my $key1 ( keys %$MLCMapping ) {
		foreach my $key2 ( keys %{ $MLCMapping->{$key1} } ) {
			my $currentdevice = $MLCMapping->{$key1}{$key2};
			if ( defined $currentdevice and $currentdevice eq $devicename ) {
				$section = $key1;
			}
		}
	}

	if ( defined $section ) {
		if ( $section =~ m/SQUIBS/i ) {
			$devicetype = "Squib";
		}
		elsif ( $section =~ m/SWITCHES|BELT_LOCKS/i ) {
			$devicetype = "Switch";
		}
		elsif ( $section =~ m/^PAS/i ) {
			$devicetype = "PAS";
		}
		elsif ( $section =~ m/WARNING_LAMPS/i ) {
			$devicetype = "Lamp";
		}
		else {
			S_set_error( "device name - $devicename is not found in allowed sections (SQUIBS/SWITCHES/BELT_LOCKS/PAS/WARNING_LAMPS/). It is found in $section of Project Const/Device mapping file", 114 );    #error!
			return 0;
		}

		GEN_printComment("Fetched device type: $devicetype");
		return $devicetype;
	}
	else {
		S_set_error( "device name - $devicename is not found in Project Const/Device mapping file", 114 );                                                                                                     #error!
		return 0;
	}

}

=head2 DEVICE_fetchSwitchType

	$switchtype = DEVICE_fetchSwitchType ($devicename);

I<B<Description:>>  fetch the type of the switch from the device mapping file

$devicename = name of device

For example:

used to get the switch type by passing switch name.

Mapping_Device.pm file hash structure.

	'BLFD' => {
					'label' => 'BeltLockFrontDriver',
					'type' => 'hall',
		},

To find 'BLFD' switch type, use DEVICE_fetchSwitchType('BLFD'). It returns 'hall'.

I<B<Return:>> return the switch type (return values can be: 'hall' or 'resistive' or 'mech')

I<B<Verdict:>> none

I<B<Error:>> sets warning if switch type is not found in the mapping file

=cut	

sub DEVICE_fetchSwitchType {
	GEN_print_caller();

	my $devicename = shift;
	my ( $switchtype, $devicetype );

	#access the mapping file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );

	unless ( defined $devicename ) {
		S_set_error( "Missing mandatory parameter device", 110 );
		return 0;
	}

	$devicetype = DEVICE_fetchDeviceType($devicename);

	unless ( defined $devicetype and $devicetype eq 'Switch' ) {
		S_set_error( "Device $devicename type is not 'Switch'. Can't fetch the Switch type", 114 );    #warning!
		return undef;
	}

	unless ( defined $DeviceMapping ) {
		S_set_error( "Device mapping File not found. Check the Project_CFG document for variable LIFT_DeviceMapping", 1 );    #warning!
		return undef;
	}

	$switchtype = $DeviceMapping->{$devicename}{'type'};

	unless ( defined $switchtype ) {                                                                                          #check if parameters are valid
		S_set_error( "Switch type is not found for the device $devicename in Device mapping file", 114 );                     #warning!
		return 0;
	}
	GEN_printComment("Fetched switch type: $switchtype");
	return $switchtype;
}

=head2 DEVICE_fetchDeviceThreshold 

	$thresholdvalue = DEVICE_fetchDeviceThreshold ($devicename,$thresholdlabel);

I<B<Description:>>  fetch the Threshold label value from the device mapping file

$devicename = name of device

For example:

used to get the threshold value by passing the of device name and threshold label.

Mapping_Device.pm file hash structure.

		'Thresholds' => { 
			
			'Switch_hall' => {				
						'Min' => '',						
						'Low' => '1.1',						
						'LowUndefined' => '8',						
						'UndefinesHigh' => '',						
						'High' => '9.5',						
						'Max' => '',										
			},
			
			'Switch_resistive' => {				
						'Min' => '',						
						'Low' => '1.1',						
						'LowUndefined' => '8',						
						'UndefinesHigh' => '',						
						'High' => '9.5',						
						'Max' => '',										
			},
			
			'SSSL1' => {				
						'Min' => '',						
						'Low' => '1.1',						
						'LowUndefined' => '8',						
						'UndefinesHigh' => '',						
						'High' => '',						
						'Max' => '',											
			},
			
			'Squib' => {				
						'Min' => '0.5',						
						'Low' => '1.6',						
						'High' => '6.5',						
						'Max' => '7',				
			},
			
			'AB3FD' => {				
						'Min' => '0.5',						
						'Low' => '1.6',						
						'High' => '6.5',						
						'Max' => '7',											
			},
			
To find 'BLFD' 'Low' threshold value, use DEVICE_fetchDeviceThreshold('BLFD','Low'). It returns '1.1'.

If devicename is not found in the hash then the thresholds of device type will be used.

For example: DEVICE_fetchDeviceThreshold('SA1FD','High'), It returns '9.5' if device type Switch. It returns '6.5' if the device type is Squib.

$thresholdlabel = threshold label name

I<B<Return:>> return the threshold value

I<B<Verdict:>> none

I<B<Error:>> sets warning if Threshold label is not found in the mapping file

=cut		

sub DEVICE_fetchDeviceThreshold {
	GEN_print_caller();

	my $devicename     = shift;
	my $thresholdlabel = shift;
	my ( $thresholdvalue, $currentdevice, $finddevice, $devicetype, $switchtype );

	#access the mapping file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );

	unless ( defined $devicename ) {
		S_set_error( "Missing mandatory parameter devicename", 110 );
		return 0;
	}
	unless ( defined $thresholdlabel ) {
		S_set_error( "Missing mandatory parameter thresholdlabel", 110 );
		return 0;
	}

	$devicetype = DEVICE_fetchDeviceType($devicename);

	if ( exists $DeviceMapping->{'Thresholds'}{$devicename} ) {    # check for the device name, whether it exists in  the hash or not
		$finddevice = $devicename;
	}

	if ( defined $finddevice and $finddevice eq $devicename ) {
		$thresholdvalue = $DeviceMapping->{'Thresholds'}{$devicename}{$thresholdlabel};
		if ( defined $thresholdvalue ) {
			GEN_printComment("Device $devicename, thresholdlabel $thresholdlabel value is: $thresholdvalue");
		}
		else {
			S_set_error( "Threshold label $thresholdlabel is not defined in Thresholds hash in Device mapping file", 114 );    #error!
			return undef;
		}
	}
	else {
		GEN_printComment("Device $devicename is not found in threshold hash, So based on device type default(Squib/Switch_resistive/Switch_hall) thresholds are used");
		if ( $devicetype eq 'Squib' ) {
			$thresholdvalue = $DeviceMapping->{'Thresholds'}{'Squib'}{$thresholdlabel};
			if ( defined $thresholdvalue ) {
				GEN_printComment("Device $devicename, thresholdlabel $thresholdlabel value is: $thresholdvalue");
			}
			else {
				S_set_error( "Threshold label $thresholdlabel is not defined in Thresholds hash in Device mapping file", 114 );    #error!
				return undef;
			}
		}
		elsif ( $devicetype eq 'Switch' ) {
			$switchtype     = DEVICE_fetchSwitchType($devicename);
			$thresholdvalue = $DeviceMapping->{'Thresholds'}{"Switch_$switchtype"}{$thresholdlabel};
			if ( defined $thresholdvalue ) {
				GEN_printComment("Device $devicename, thresholdlabel $thresholdlabel value is: $thresholdvalue");
			}
			else {
				S_set_error( "Threshold label $thresholdlabel is not defined in Thresholds hash in Device mapping file", 114 );    #error!
				return undef;
			}
		}
		else {
			S_set_error( "Device type $devicename, is not Squib or Switch", 114 );
		}
	}

	return $thresholdvalue;
}

=head2 DEVICE_fetchDevicebyLabel 

DEVICE_fetchDevicebyLabel ($label);

I<B<Description:>>  fetch the device name from given label

For example:

DEVICE_fetchDevicebyLabel ('BeltLockFrontDriver'); returns 'BLFD'

Mapping_Device.pm file hash structure.

$Defaults->{"Mapping_DEVICE"}= {

		#'label' --> give a label corresponding to the device
		#'type' --> type can be any of these: 'hall', 'mech' or 'resistive'

		'BLFD' => {
					'label' => 'BeltLockFrontDriver',
					'type' => 'hall',
					'BelowLow' => '',
					'Low' => '',
					'Undefined' => '8',
					'High' => '',
					'AboveHigh' => '',					
		},
	},

I<B<Return:>> return the device name

I<B<Verdict:>> none

I<B<Error:>> sets warning if label is not found in the mapping file

=cut		

sub DEVICE_fetchDevicebyLabel {
	GEN_print_caller();

	my $label = shift;

	my $devicename;
	my $matched = 0;
	my @returnarray;

	#access the mapping file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );

	unless ( defined $label ) {
		S_set_error( "Missing mandatory parameter devicename", 110 );
		return 0;
	}

	foreach $devicename ( keys %$DeviceMapping ) {
		if ( ref( $DeviceMapping->{$devicename} ) eq 'HASH' ) {
			if ( ( $DeviceMapping->{$devicename}{'label'} ) eq $label ) {

				#GEN_printComment("device name is = $devicename");
				push( @returnarray, $devicename );
			}
		}
	}

	if ( scalar(@returnarray) > 1 ) {
		S_set_error( "There are more than one device @returnarray found with given label - $label", 0 );    #warning!
		return undef;
	}
	elsif ( scalar(@returnarray) == 0 ) {
		S_set_error( "label - $label is not present in device mapping file", 0 );                           #warning!
		return undef;
	}
	else {
		return @returnarray[0];
	}

}

=head2 DEVICE_setDeviceState

	$status = DEVICE_setDeviceState ($devicename, $state);

I<B<Description:>>  Set an appropriate state for the device

$devicename = name of device

$state = label of the state to be created on the device

I<B<Valid states (labels):>>

1. Any of the below fault conditions

	'Configuration'
	'Openline'
	'Short2Bat'
	'Short2Bat_lowSide'
	'Short2Gnd'
	'Short2Gnd_lowSide'
	'ShortResistance' (sets device resistance to 0 ohm)
	'CrossCouple'
	'resistanceTooHigh' (sets squib resistance to 10 ohm)
	'resistanceTooLow' (sets squib resistance to 0.2 ohm)

2. Any valid state defined in MLC/TSG4 switch hash like 'BUCKLED', 'UNBUCKLED' etc.

3. Any valid state (label) defined for the device in the DEVICE mapping file. Example: DEVICE_setDeviceState ('DSPOS', 'Undefined')

			'BLFD' => { #BLR1D
					'label' => 'BeltLockFrontDriver',
					'type' => 'hall',
					 #Switch states/values to be set (current in mA or resistance in ohm)
					'Undefined' => '8',
					...
				}

4. Any valid current or resistance value in mA/ohm. If device is a Squib or a resistive Switch, resistance value will be set. if device is a hall Switch, current value will be set.

I<B<Pre-requisites for using this function:>>

1. DEVICE mapping file should be available. This should contain the MLC/TSG4 hash and Mapping_DEVICE hash

2. DEVICE type is defined for all switches with below structure:

		'BLFD' => { #BLR1D
				'label' => 'BeltLockFrontDriver',
				'type' => 'hall',
				...
			}

I<B<Examples:>>

	DEVICE_setDeviceState ('BLFD', 'Openline');
	DEVICE_setDeviceState ('BLR2D', 'BUCKLED'); 
	DEVICE_setDeviceState ('DSPOS', 'Undefined');
	DEVICE_setDeviceState ('BLFP', 100); #ohm
	DEVICE_setDeviceState ('BLFP', 0x50); #80 ohm
	DEVICE_setDeviceState ('PADS', 10); #mA
	
	DEVICE_setDeviceState ('AB1FD', 'Short2Bat');
	DEVICE_setDeviceState ('SA1FP', 'resistanceTooHigh'); #ohm
	DEVICE_setDeviceState ('BT1FD', 8); #ohm
	
	DEVICE_setDeviceState ('UFSL', 'Short2Gnd');
		
I<B<Return:>> return 0 on error

I<B<Verdict:>> none

I<B<Error:>> sets error for invalid state label

=cut

sub DEVICE_setDeviceState {
	GEN_print_caller();

	my $device    = shift;
	my $condition = shift;
	my $switchtype;
	my $devicetype;
	my @devices;
	my $UndefinedVal;
	my $MLCMapping;
	my $Switch_Hash;

	#access the mapping file and testbench file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	$MLCMapping = $LIFT_PROJECT::Defaults->{'MLC'} if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	$MLCMapping = $LIFT_PROJECT::Defaults->{'TSG4'} if ( $TestHW eq 'TSG4' );

	unless ( defined $device ) {
		S_set_error( "Missing mandatory parameter device", 110 );
		return 0;
	}
	unless ( defined $condition ) {
		S_set_error( "Missing mandatory parameter condition", 110 );
		return 0;
	}

	if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'TSG4' ) or ( $TestHW eq 'MLC' ) ) {

		#Peribox is selected a PERIPHERIE device
		GEN_printComment("PERIPHERIE device $TestHW is selected");
	}
	else {
		S_set_error( "Wrong  PERIPHERIE device $TestHW is selected", 114 );    #Error!
		return 0;
	}

	$devicetype = DEVICE_fetchDeviceType($device);
	if ( $devicetype eq 'Switch' ) {
		$switchtype  = DEVICE_fetchSwitchType($device);
		$Switch_Hash = $MLCMapping->{'SWITCHES'} if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		$Switch_Hash = $MLCMapping->{'BELT_LOCKS'} if ( $TestHW eq 'TSG4' );
	}

	if ( $condition =~ m/^0x[0-9A-F]+$/i or $condition =~ m/^\d+$/ ) {         #contains hex or decimal numbers, set the current/resistance value
		if ( $devicetype eq 'Switch' and $switchtype eq 'hall' ) {
			DEVICE_setDeviceCurrent( $device, $condition );
		}
		elsif ( $devicetype eq 'Squib' or ( $devicetype eq 'Switch' and $switchtype eq 'resistive' ) ) {    #squibs and other switches
			DEVICE_setDeviceResistance( $device, $condition );
		}
		elsif ( $devicetype eq 'Switch' and $switchtype eq 'mech' ) {
			S_set_error( "Setting value $condition is not possible for mech switch\n", 0 );                 #warning!;
		}
	}
	elsif ( $condition =~ m/^Configuration/i ) {
		DEVICE_setDeviceConfiguration( $device, 'clear' );
	}
	elsif ( $condition =~ m/Openline/i ) {
		MLC_DisconnectLine($device) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_DisconnectLine($device) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Bat_lowSide/i ) {
		MLC_ShortLine( $device . "-", 'VBAT' ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_ShortLines( [ $device . '-', 'B+' ] ) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Bat/i ) {
		MLC_ShortLine( $device . "+", 'VBAT' ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_ShortLines( [ $device . '+', 'B+' ] ) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Gnd_lowSide/i ) {
		MLC_ShortLine( $device . "-", 'GND' ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_ShortLines( [ $device . '-', 'B-' ] ) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Gnd/i ) {
		MLC_ShortLine( $device . "+", 'GND' ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_ShortLines( [ $device . '+', 'B-' ] ) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/ShortResistance/i ) {
		DEVICE_setDeviceResistance( $device, 20 )  if ( $devicetype eq 'Switch' );
		DEVICE_setDeviceResistance( $device, 0.2 ) if ( $devicetype eq 'Squib' );
	}
	elsif ( $condition =~ m/CrossCoupl/i ) {
		if ( $devicetype =~ m/Switch/i ) {
			@devices = MLC_get_names('SWITCHES') if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			@devices = TSG4_get_names('BELT_LOCKS') if ( $TestHW eq 'TSG4' );
		}
		elsif ( $devicetype =~ m/Squib/i ) {
			@devices = MLC_get_names('SQUIBS') if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			@devices = TSG4_get_names('SQUIBS') if ( $TestHW eq 'TSG4' );
		}
		elsif ( $devicetype =~ m/PAS/i ) {
			@devices = MLC_get_names('PAS') if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			@devices = TSG4_get_names('PAS_LINES') if ( $TestHW eq 'TSG4' );
			
		}
		else{
			S_set_error("Device type is not support for cross coupling");
		}
		if ( $devicetype =~ m/PAS/i ) {
			if ( $device eq "UFSD" ) {
				DEVICE_shortLines( $device . '+', 'UFSP+' );
				return 'UFSP';
			}
			else {
				DEVICE_shortLines( $device . '+', 'UFSD+' );
				return 'UFSD';
			}
		}
		else{
			if ( $device eq $devices[0] ) {
				DEVICE_shortLines( $device . '+', $devices[1] . '+' );
				return $devices[1];
			}
			else {
				DEVICE_shortLines( $device . '+', $devices[0] . '+' );
				return $devices[0];
			}
		}

	}
	elsif ( $condition =~ m/resistanceTooHigh/i ) {
		DEVICE_setDeviceResistance( $device, 10 );    #confirm
	}
	elsif ( $condition =~ m/resistanceTooLow/i ) {    # 'resistanceTooLow' -> squib resistance is too low
		DEVICE_setDeviceResistance( $device, 0.2 );    #confirm
	}
	else {
		if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) ) {
			if ( $devicetype eq 'Switch' and ( $condition eq $Switch_Hash->{ "$device" . "_OPEN" } or $condition eq $Switch_Hash->{ "$device" . "_CLOSED" } ) ) {    #set switch states
				MLC_SetLogicalState( $device, $condition );
			}
			else {                                                                                                                                                   #set current/resistance values based on labels/enums from mapping file
				my $value = $DeviceMapping->{$device}{$condition};

				unless ( defined $value ) {
					S_set_error( "Invalid state $condition Unable to set state", 114 );                                                                              #error!
					return 0;
				}

				if ( $devicetype eq 'Switch' and $switchtype eq 'hall' ) {
					DEVICE_setDeviceCurrent( $device, $value );
				}
				elsif ( $devicetype eq 'Squib' or ( $devicetype eq 'Switch' and $switchtype eq 'resistive' ) ) {                                                     #squibs and other switches
					DEVICE_setDeviceResistance( $device, $value );
				}
				elsif ( $devicetype eq 'Switch' and $switchtype eq 'mech' ) {
					S_set_error( "setting state $condition is not possible for mech switch\n", 0 );                                                                  #warning!;
				}
			}
		}
		elsif ( $TestHW eq 'TSG4' ) {

			#TSG4_SetLogicalState( $device, $condition ) if ( $TestHW eq 'TSG4' );
			if ( $devicetype eq 'Switch' and ( $condition eq $Switch_Hash->{ "$device" . "_OPEN" } or $condition eq $Switch_Hash->{ "$device" . "_CLOSED" } ) ) {    #set switch states
				TSG4_SetLogicalState( $device, $condition );
			}
			else {                                                                                                                                                   #set current/resistance values based on labels/enums from mapping file
				my $value = $DeviceMapping->{$device}{$condition};

				unless ( defined $value ) {
					S_set_error( "Invalid state $condition Unable to set state", 114 );                                                                              #error!
					return 0;
				}

				if ( $devicetype eq 'Switch' and $switchtype eq 'hall' ) {
					DEVICE_setDeviceCurrent( $device, $value );
				}
				elsif ( $devicetype eq 'Squib' or ( $devicetype eq 'Switch' and $switchtype eq 'resistive' ) ) {                                                     #squibs and other switches
					DEVICE_setDeviceResistance( $device, $value );
				}
				elsif ( $devicetype eq 'Switch' and $switchtype eq 'mech' ) {
					S_set_error( "setting state $condition is not possible for mech switch\n", 0 );                                                                  #warning!;
				}
			}    #handles all the above cases
		}
	}

	return 1;

}

=head2 DEVICE_setDeviceResistance 
      
	$Status = DEVICE_setDeviceResistance ($devicename,$resistance);

I<B<Description:>>  Sets given resistance to required device

$devicename = name of device

$resistance = value of the resistance

For example:

DEVICE_setDeviceResistance ('AB2FD',2.2); #Set device 'AB2FD' resistance to 2.2 ohms.

I<B<Return:>> 0 on error

I<B<Verdict:>> none

I<B<Error:>> none 

=cut		

sub DEVICE_setDeviceResistance {
	GEN_print_caller();

	my $devicename = shift;
	my $resistance = shift;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	unless ( defined $devicename ) {
		S_set_error( "Missing mandatory parameter devicename", 110 );
		return 0;
	}
	unless ( defined $resistance ) {
		S_set_error( "Missing mandatory parameter resistance", 110 );
		return 0;
	}

	MLC_SetResistance( $devicename, $resistance ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	TSG4_SetResistance( $devicename, $resistance ) if ( $TestHW eq 'TSG4' );

	return 1;
}

=head2 DEVICE_setDeviceCurrent 
      
	$status = DEVICE_setDeviceCurrent ($devicename,$current);

I<B<Description:>>  Sets given current to required device

$devicename = name of device

$resistance = value of the current

For example:

DEVICE_setDeviceCurrent ('BLFP',8); #Set device 'BLFP' current to 8 mA.

I<B<Return:>> 0 on error

I<B<Verdict:>> none

I<B<Error:>> none

=cut		

sub DEVICE_setDeviceCurrent {
	GEN_print_caller();

	my $devicename = shift;
	my $current    = shift;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	unless ( defined $devicename ) {
		S_set_error( "Missing mandatory parameter device", 110 );
		return 0;
	}
	unless ( defined $current ) {
		S_set_error( "Missing mandatory parameter current", 110 );
		return 0;
	}

	MLC_SetCurrent( $devicename, $current ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	TSG4_SetCurrent( $devicename, $current ) if ( $TestHW eq 'TSG4' );

	return 1;
}

=head2 DEVICE_resetDeviceState        

	$status = DEVICE_resetDeviceState ($devicename, $state);

I<B<Description:>> Remove/reset the state that was set using the function DEVICE_setDeviceState

For details refer description of DEVICE_setDeviceState

I<B<Valid states (labels) that can be reset:>>

	'Configuration'
	'Openline'
	'Short2Bat'
	'Short2Bat_lowSide'
	'Short2Gnd'
	'Short2Gnd_lowSide'
	'ShortResistance'
	'CrossCouple'
	'resistanceTooHigh'
	'resistanceTooLow'
	'Undefined'

Also, any valid switch state can be passed. This will reset the switch to CLOSED/DEFAULT MLC/TSG4 position

Currently handeled switch states: buckled|belted|rear|forward|position|activate|foremost

I<B<Return:>> return 0 on error

I<B<Verdict:>> none

I<B<Error:>> sets error for invalid fault label

=cut

sub DEVICE_resetDeviceState {
	GEN_print_caller();

	my $device    = shift;
	my $condition = shift;
	my $switchtype;
	my $devicetype;

	#access the mapping file and testbench file
	my $DeviceMapping = S_get_contents_of_hash( ['Mapping_DEVICE'] );
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	unless ( defined $device ) {
		S_set_error( "Missing mandatory parameter device", 110 );
		return 0;
	}
	unless ( defined $condition ) {
		S_set_error( "Missing mandatory parameter condition", 110 );
		return 0;
	}

	if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) or ( $TestHW eq 'TSG4' ) ) {

		#Peribox is selected a PERIPHERIE device
		GEN_printComment("PERIPHERIE device $TestHW is selected");
	}
	else {
		S_set_error( "Wrong  PERIPHERIE device $TestHW is selected", 114 );    #Error!
		return 0;
	}

	$devicetype = DEVICE_fetchDeviceType($device);
	if ( $devicetype eq 'Switch' ) {
		$switchtype = DEVICE_fetchSwitchType($device);
	}

	if ( $condition =~ m/Configuration/i ) {
		PD_Device_configuration( 'set', [$device] );
	}
	elsif ( $condition =~ m/Openline/i ) {
		MLC_ReconnectLine($device) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_ConnectLine($device) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Bat/i ) {
		MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_UndoShortLines() if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Short2Gnd/i ) {
		MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_UndoShortLines() if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/ShortResistance|ResistanceShort/i ) {
		if ( $devicetype =~ m/Switch/i ) {
			MLC_SetLogicalState( $device, $main::ProjectDefaults->{'MLC'}{'SWITCHES'}{ "$device" . "_CLOSED" } ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			TSG4_SetLogicalState( $device, 'DEFAULT' ) if ( $TestHW eq 'TSG4' );
		}
		if ( $devicetype =~ m/Squib/i ) {
			MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			TSG4_SetResistance( $device, 'DEFAULT' ) if ( $TestHW eq 'TSG4' );
		}
	}
	elsif ( $condition =~ m/CrossCoupl/i ) {
		MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_UndoShortLines() if ( $TestHW eq 'TSG4' );
	}
	elsif ( ( $condition =~ m/resistanceTooLow|resistanceTooHigh/i ) ) {
		MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_SetResistance( $device, 'DEFAULT' ) if ( $TestHW eq 'TSG4' );
	}
	elsif ( $condition =~ m/Undefined/i ) {
		if ( $devicetype =~ m/Switch/i ) {
			MLC_SetLogicalState( $device, $main::ProjectDefaults->{'MLC'}{'SWITCHES'}{ "$device" . "_CLOSED" } ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
			TSG4_SetLogicalState( $device, 'DEFAULT' ) if ( $TestHW eq 'TSG4' );
		}
	}
	elsif ( $devicetype eq 'Switch' and $condition =~ m/buckled|belted|rear|forward|position|activate|foremost/i ) {    #reset to default/closed state
		MLC_SetLogicalState( $device, $main::ProjectDefaults->{'MLC'}{'SWITCHES'}{ "$device" . "_CLOSED" } ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
		TSG4_SetLogicalState( $device, 'DEFAULT' ) if ( $TestHW eq 'TSG4' );
	}
	else {
		S_set_error( "Invalid state $condition Unable to reset state", 114 );                                           #error!
		return 0;
	}

	return 1;

}

=head2 DEVICE_shortLines

	DEVICE_shortLines ($terminal1, $terminal2, [$resistance]);

I<B<Description:>> Creates a short (between 2 device terminals)

Calls internally MLC_ShortLine/TSG4_ShortLines. Refer documentation for MLC_ShortLine

I<B<Return:>> none

I<B<Verdict:>> none

I<B<Error:>> as per MLC_ShortLine/TSG4_ShortLines

=cut

sub DEVICE_shortLines {
	GEN_print_caller();

	my $terminal1  = shift;
	my $terminal2  = shift;
	my $resistance = shift;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	MLC_ShortLine( $terminal1, $terminal2, $resistance ) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	TSG4_ShortLines( [ $terminal1, $terminal2 ], $resistance ) if ( $TestHW eq 'TSG4' );

	return 1;

}

=head2 DEVICE_undoShortLines

	DEVICE_undoShortLines ();

I<B<Description:>> Removes the short between 2 device terminals

Calls internally MLC_UndoShortLine/TSG4_UndoShortLines

I<B<Return:>> none

I<B<Verdict:>> none

I<B<Error:>> as per MLC_UndoShortLine/TSG4_UndoShortLines

=cut

sub DEVICE_undoShortLines {
	GEN_print_caller();

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	# Remove the Short Line Fault
	GEN_printComment("Removing the short");
	MLC_UndoShortLine() if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );
	TSG4_UndoShortLines() if ( $TestHW eq 'TSG4' );

	return 1;

}

=head2 DEVICE_setDeviceConfiguration

	$status = DEVICE_setDeviceConfiguration ($device,$mode);

I<B<Description:>>  Sets the device configuration (monitoring bit, config bit or presence bit). Calls internally PD_Device_configuration to set the configuration

$mode = can be 'set', 'clear', 'set_Mon' or 'clear_Mon' - Refer the LIFT documentation of PD_Device_configuration for details

$mode can also be 'NotPresent' or 'Present' - this sets the device presence status based on Present or NotPresent (i.e. connect or disconnect device)

I<B<Return:>>  1 if config is successfully set, else return 0

I<B<Verdict:>>  none

I<B<Error:>>  based on PD_Device_configuration

=cut

sub DEVICE_setDeviceConfiguration {
	GEN_print_caller();

	my $device = shift;
	my $mode   = shift;
	my $status;

	#access the testbench file
	my $TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
	unless ( defined $TestHW ) {
		$TestHW = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'line'};
	}

	unless ( defined $mode and defined $device ) {    #check if parameters are defined
		S_set_error( "Parameter not defined", 114 );    #Error!
		return 0;
	}

	if ( ( $mode eq "set" ) || ( $mode eq "clear" ) || ( $mode eq "set_Mon" ) || ( $mode eq "clear_Mon" ) ) {

		#GEN_printComment("Setting the mode $mode for the device $device");
		PD_Device_configuration( "$mode", ["$device"] );    #Sets or clear the device configuration (monitoring bit or config bit)
	}
	elsif ( ( $mode =~ m/^NotPresent$/i ) ) {
		GEN_printComment("Clearing the physical presence bit for the device $device");
		MLC_DisconnectLine($device) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );    # disconnect device
		TSG4_DisconnectLine($device) if ( $TestHW eq 'TSG4' );
	}
	elsif ( ( $mode =~ m/^Present$/i ) ) {
		GEN_printComment("Setting the physical presence bit for the device $device");
		MLC_ReconnectLine($device) if ( ( $TestHW eq 'LabCar' ) or ( $TestHW eq 'MLC' ) );     # connect device
		TSG4_ConnectLine($device) if ( $TestHW eq 'TSG4' );                                    # connect device
	}
	else {
		S_set_error( "Invalid mode : $mode. Device Config is not done successfully", 114 );    #error!
		return 0;
	}

	return 1;

}

1;
