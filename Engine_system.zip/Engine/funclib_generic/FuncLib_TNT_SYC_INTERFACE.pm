# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package FuncLib_TNT_SYC_INTERFACE;

use strict;
use warnings;
use LIFT_general;
use XML::Simple;
use FuncLib_SYC_INTERFACE;
use Import::Into;
use Clone 'clone';

our ( $VERSION, $HEADER );
use Exporter;

BEGIN {
    our @ISA    = qw(Exporter);
    our @EXPORT = qw(
      SYC_CAN_get_FirstCommunicationTime
      SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits
      SYC_ECU_get_InitTime_s
      SYC_EDR_get_AllowOnlineDiag
      SYC_EDR_get_Architecture
      SYC_EDR_get_CrashTelegramInternalSize
      SYC_EDR_get_CrashTelegramSize
      SYC_EDR_get_DiagInMotion
      SYC_EDR_get_EnableExtendedEvent
      SYC_EDR_get_EventRecordingPriority
      SYC_EDR_get_MultiEventHandling
      SYC_EDR_get_NumberOfEventsToBeStored
      SYC_EDR_get_NumberOfEventsToBeStoredPEP
      SYC_EDR_get_NumberOfParallelEvents
      SYC_EDR_get_SectionCRC
      SYC_EDR_get_SpecialEvent
      SYC_EDR_get_SpecialEventSet
      SYC_EDR_get_ThresholdValueForInternalError
      SYC_EDR_get_TriggerThresholdSpeed
      SYC_EDR_get_TriggerThresholdTime
      SYC_EDR_get_Type
      SYC_EDR_get_UnlockRecord
      SYC_FLT_get_BoschMemorySize
      SYC_FLT_get_DemDisturbanceMemorySize
      SYC_FLT_get_DemBswErrorBufferSize
      SYC_FLT_get_DemMaxNumberEventEntryPrimary
      SYC_InternalSensor_getAllSensors
      SYC_InternalSensor_getSensorType
      SYC_LIN_get_FirstCommunicationTime
      SYC_PAD_get_MeasurementRepetition
      SYC_PAD_get_RedundantHwPath
      SYC_PAD_get_StateIfDataInvalid
      SYC_PAD_get_StateIfFault
      SYC_PAD_get_StateIfNotConfigured
      SYC_PAD_get_StateInit
      SYC_PLANT_get_PlantModeConfiguration
      SYC_PLANT_get_WhiteListFaults
      SYC_POWERSUPPLY_get_HighVoltageDetectionLimit
      SYC_POWERSUPPLY_get_LowVoltageDetectionLimit
      SYC_POWERSUPPLY_get_MinAutarkyTime
      SYC_POWERSUPPLY_get_NumberOfSupplyLines
      SYC_POWERSUPPLY_get_ReverseVoltageTestConditions
      SYC_SQUIB_get_all_configured
      SYC_SQUIB_get_all_DeactivatedByPAD
      SYC_SQUIB_get_all_monitored
      SYC_SQUIB_get_ASIC_connection
      SYC_SQUIB_get_Configured
      SYC_SQUIB_get_DeactivatedByPAD
      SYC_SQUIB_get_firing_mode
      SYC_SQUIB_get_firing_pulse_min_current
      SYC_SQUIB_get_firing_pulse_min_duration
      SYC_SQUIB_get_Monitored
      SYC_SQUIB_get_RepetitionTime
      SYC_SQUIB_get_ResistanceOkLowerThd
      SYC_SQUIB_get_ResistanceOkUpperThd
      SYC_SQUIB_get_ResistanceHighLowerThd
      SYC_SQUIB_get_ResistanceLowUpperThd
      SYC_SQUIB_get_ResistanceLowerThd
      SYC_SQUIB_get_ResistanceShort2Bat
      SYC_SQUIB_get_ResistanceUpperThd
      SYC_SQUIB_get_TestCurrent
      SYC_SQUIB_get_type
      SYC_SWITCH_get_all_configured
      SYC_SWITCH_get_all_monitored
      SYC_SWITCH_get_ASIC_connection
      SYC_SWITCH_get_Configured
      SYC_SWITCH_get_DefaultCondition
      SYC_SWITCH_get_FaultReaction
      SYC_SWITCH_get_InitialCondition
      SYC_SWITCH_get_InitTime_ms
      SYC_SWITCH_get_MeasurementMode
      SYC_SWITCH_get_Monitored
      SYC_SWITCH_get_RepetitionTime
      SYC_SWITCH_get_state
      SYC_SWITCH_get_state_thresholds
      SYC_SWITCH_get_TestCurrent
      SYC_SWITCH_get_type
      SYC_SYSTEMASIC_get_MasterAsicType
      SYC_SYSTEMASIC_get_Slave1AsicType
      SYC_SYSTEMASIC_get_Slave2AsicType
      SYC_SENSOR_get_Configured
      SYC_SENSOR_get_Monitored
      SYC_AnalogueOutput_get_Configured
      SYC_AnalogueOutput_get_Monitored
      SYC_AnalogueOutput_isHighSideDriver
      SYC_AnalogueOutput_isLowSideDriver
    );
}

=head1 NAME

FuncLib_TNT_SYC_INTERFACE 

=head1 SYNOPSIS

=head1 DESCRIPTION

=cut

=head1 Function Group "CAN"

All functions to access SYC, which are currently supported for CAN.

= cut

=head2 SYC_CAN_get_FirstCommunicationTime

    ( $result , $firstCommunicationTime_ms ) = SYC_CAN_get_FirstCommunicationTime( );

returns the FirstCommunicationTime on CAN Bus in ms.

=cut

sub SYC_CAN_get_FirstCommunicationTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_CAN_get_FirstCommunicationTime( )', @args );

    my ( $result, $firstCommunicationTime_ms );

    S_w2log( 3, "SYC_CAN_get_FirstCommunicationTime called.\n" );
    ( $result, $firstCommunicationTime_ms ) = SYC_get_ConfigId_Content( 'FirstCommunicationTime', ['Can'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $firstCommunicationTime_ms ) = SYC_get_ScipPM_Content( [ 'Communication_Interfaces', 'Can', 'FirstCommunication_Time_ms' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $firstCommunicationTime_ms =~ s/\s//g;

    if ( $firstCommunicationTime_ms =~ /([0-9]*)ms/ ) {
        $firstCommunicationTime_ms = $1;
    }
    elsif ( $firstCommunicationTime_ms =~ /([0-9]*)/ ) {
        $firstCommunicationTime_ms = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'FirstCommunicationTime' for CAN is not in the expected format.", 20 );
        return 0;
    }

    if ( $firstCommunicationTime_ms > 500 || $firstCommunicationTime_ms < 120 ) {
        S_set_error( "Content of ConfigID 'FirstCommunicationTime' for CAN is out of expected range (120 <= X <= 500).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_CAN_get_FirstCommunicationTime returns \$firstCommunicationTime_ms '$firstCommunicationTime_ms'.\n" );

    return ( 1, $firstCommunicationTime_ms );
}

=head1 Function Group "ECU"

All functions to access SYC, which are currently supported for ECU.

= cut

=head2 SYC_ECU_get_InitTime_s

    ( $result , $ecuInitTime_s ) = SYC_ECU_get_InitTime_s( );

returns the ecuInitTime in s

=cut

sub SYC_ECU_get_InitTime_s {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_ECU_get_InitTime_s( )', @args );

    my ( $result, $ecuInitTime_s );

    S_w2log( 3, "SYC_ECU_get_InitTime_s called.\n" );
    ( $result, $ecuInitTime_s ) = SYC_get_ConfigId_Content('EcuInitTime') if SYC_getSycType() eq "doorsXML";
    ( $result, $ecuInitTime_s ) = SYC_get_ScipPM_Content( [ 'OperatingModes', 'EcuInitTime_s' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $ecuInitTime_s =~ s/\s//g;
    $ecuInitTime_s =~ s/,/./g;

    if ( $ecuInitTime_s =~ /([0-9]*\.?[0-9]+)s/ ) {
        $ecuInitTime_s = $1;
    }
    elsif ( $ecuInitTime_s =~ /([0-9]*\.?[0-9]+)/ ) {
        $ecuInitTime_s = $1;
    }
    else {
        S_set_error( "Content of ConfigID '$ecuInitTime_s' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_ECU_get_InitTime_s returns \$ecuInitTime_s '$ecuInitTime_s'.\n" );

    return ( 1, $ecuInitTime_s );
}

=head1 Function Group "PlantTopics"

All functions to access SYC, which are currently supported for PlantTopics Section.

= cut

=head2 SYC_PLANT_get_PlantModeConfiguration

    ( $result , $modeConfigured ) = SYC_PLANT_get_PlantModeConfiguration( $plantMode );

returns the configuration of given $plantMode

$plantMode has to be FullName of PlantModes:
	'PM1Selfdiagnosticthresholds'
	'PM2Externaldevicesnotpresent'
	'PM3NoEnergyReservecharging'
	'PM4Suppressfaultqualification'
	'PM5acceleratedfaultqualification'
	'PM6Airbagdeploymentprohibitedinalgorithm'
	'PM7Electronicfiringmode'
	'PM8PSItestmode'
	'PM9AIOandAINtestmode'
	'PM10Suppressexpectedfaultscommunication'
	'PM11EMCcapacitortest'
	'PM12activateonlyplantfaultmemory'
	'PM13automaticdetectionpanelsingleECU001'
	'Plant_modes_configuration_CustomerPlantModeER'
	'PM15CANfastsleepmodeactivated'
	'PM16notused'
	'PM17NoEnergyReservechargingforonepoweroncycle'
	'PM18notused'
	'PM19testofLINFlexRaycommunicationinterfaces'
			
=cut

sub SYC_PLANT_get_PlantModeConfiguration {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_PLANT_get_PlantModeConfiguration( $plantMode )', @args );

    my $plantMode = shift @args;

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_InternalSensor_getSensorType' not supported for DOORS based SYC Exports.");
        return 0;
    }

    my ( $result, $modeConfigured, $content_href, $plantModeReal );

    S_w2log( 3, "SYC_PLANT_get_PlantModeConfiguration called.\n" );
    ( $result, $content_href ) = SYC_get_ScipPM_Content( [ 'PlantTopics', 'Plant_modes_configuration' ] );
    ( $result, $content_href ) = SYC_get_ScipPM_Content( [ 'Plant_PlantConfiguration', 'Plant_Plant_modes_configuration' ] ) unless $result;
    return 0 unless $result;

    $plantModeReal = "Plant_$plantMode" if exists $content_href->{"Plant_$plantMode"};
    $plantModeReal = $plantMode if exists $content_href->{$plantMode};
    
    unless ( $plantModeReal ) {
        S_set_error("SYC_PLANT_get_PlantModeConfiguration: given PlantMode '$plantMode' not supported.");
        return 0;
    }

    $modeConfigured = $content_href->{$plantModeReal}{selected};

    S_w2log( 3, "SYC_PLANT_get_PlantModeConfiguration returns \$modeConfigured '$modeConfigured'.\n" );

    return ( 1, $modeConfigured );
}

=head2 SYC_PLANT_get_WhiteListFaults

    ( $result , $whiteListFaults_aref ) = SYC_PLANT_get_WhiteListFaults();

returns the WhiteList faults has aref, will return empty listref in case Feature is not selected

=cut

sub SYC_PLANT_get_WhiteListFaults {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_PLANT_get_WhiteListFaults( )', @args );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_InternalSensor_getSensorType' not supported for DOORS based SYC Exports.");
        return 0;
    }

    my ( $result, $whiteListFaults_aref, $whiteListFeatureSelected );

    S_w2log( 3, "SYC_PLANT_get_PlantModeConfiguration called.\n" );
    ( $result, $whiteListFeatureSelected ) = SYC_get_ScipPM_Content( [ 'PlantTopics', 'WhiteList', 'selected' ] );
    ( $result, $whiteListFeatureSelected ) = SYC_get_ScipPM_Content( [ 'Plant_PlantConfiguration', 'Plant_WhiteList', 'selected' ] ) unless $result;
    return 0 unless $result;

    if ( $whiteListFeatureSelected eq "false" ) {
        S_w2log( 3, "SYC_PLANT_get_PlantModeConfiguration: Feature 'PlantTopics' -> 'WhiteList' not selected in SYC Model.\n" );
        return ( 1, [] );
    }

    ( $result, $whiteListFaults_aref ) = SYC_get_ScipPM_Content( [ 'PlantTopics', 'WhiteList', 'CustomerPlantTolFaults' ] );
    ( $result, $whiteListFaults_aref ) = SYC_get_ScipPM_Content( [ 'Plant_PlantConfiguration', 'Plant_WhiteList', 'CustomerPlantTolFaults' ] ) unless $result;
    return 0 unless $result;

    S_w2log( 3, "SYC_PLANT_get_PlantModeConfiguration returns \$whiteListFaults_aref '$whiteListFaults_aref'.\n" );

    return ( 1, $whiteListFaults_aref );
}

=head1 Function Group "PassengerAirbagDeactivation"

All functions to access SYC, which are currently supported for PassengerAirbagDeactivation.

= cut

=head2 SYC_PAD_get_MeasurementRepetition

    ( $result , $nbrOfRepetitions ) = SYC_PAD_get_MeasurementRepetition( );

returns the nbr of repetitions (Change special disable line state after a number of consecutive samples within the same PADS switch value range)
returns 'NA' if MeasurementRepetition is not used

=cut

sub SYC_PAD_get_MeasurementRepetition {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_MeasurementRepetition( )', @args );

    my ( $result, $nbrOfRepetitions );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_MeasurementRepetition' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_MeasurementRepetition called.\n" );
    ( $result, $nbrOfRepetitions ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'MeasurementRepetition' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_MeasurementRepetition returns \$nbrOfRepetitions '$nbrOfRepetitions'.\n" );

    return ( 1, $nbrOfRepetitions );
}

=head2 SYC_PAD_get_RedundantHwPath

    ( $result , $switch ) = SYC_PAD_get_RedundantHwPath( );

returns the switch that is configured as RedundantHwPath
returns 'NA' if RedundantHwPath is not used

=cut

sub SYC_PAD_get_RedundantHwPath {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_RedundantHwPath( )', @args );

    my ( $result, $switch );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_RedundantHwPath' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_RedundantHwPath called.\n" );
    ( $result, $switch ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'RedundantHwPath' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_RedundantHwPath returns \$switch '$switch'.\n" );

    return ( 1, $switch );
}

=head2 SYC_PAD_get_StateIfNotConfigured

    ( $result , $state ) = SYC_PAD_get_StateIfNotConfigured( );

returns the state if PAD is not configured (use state of PAD | activated | deactivated)

=cut

sub SYC_PAD_get_StateIfNotConfigured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_StateIfNotConfigured( )', @args );

    my ( $result, $state );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_StateIfNotConfigured' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_StateIfNotConfigured called.\n" );
    ( $result, $state ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'PadStateIfNotConfigured' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_StateIfNotConfigured returns \$state '$state'.\n" );

    return ( 1, $state );
}

=head2 SYC_PAD_get_StateIfDataInvalid

    ( $result , $state ) = SYC_PAD_get_StateIfDataInvalid( );

returns the output state in case of invalid PAD input data (keep last valid state | activated | deactivated)

=cut

sub SYC_PAD_get_StateIfDataInvalid {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_StateIfDataInvalid( )', @args );

    my ( $result, $state );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_StateIfDataInvalid' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_StateIfDataInvalid called.\n" );
    ( $result, $state ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'PadStateIfDataInvalid' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_StateIfDataInvalid returns \$state '$state'.\n" );

    return ( 1, $state );
}

=head2 SYC_PAD_get_StateIfFault

    ( $result , $state ) = SYC_PAD_get_StateIfFault( );

returns the Output state in case of a detected PADS fault (activated | deactivated)

=cut

sub SYC_PAD_get_StateIfFault {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_StateIfFault( )', @args );

    my ( $result, $state );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_StateIfFault' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_StateIfFault called.\n" );
    ( $result, $state ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'PadStateIfFault' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_StateIfFault returns \$state '$state'.\n" );

    return ( 1, $state );
}

=head2 SYC_PAD_get_StateInit

    ( $result , $state ) = SYC_PAD_get_StateInit( );

returns the init state of PAD (activated | deactivated)

=cut

sub SYC_PAD_get_StateInit {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_PAD_get_StateInit( )', @args );

    my ( $result, $state );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_PAD_get_StateInit' not supported for DOORS based SYC Exports.");
        return 0;
    }

    S_w2log( 3, "SYC_PAD_get_StateInit called.\n" );
    ( $result, $state ) = SYC_get_ScipPM_Content( [ 'PassengerAirbagDeactivation', 'GeneralData', 'PadStateInit' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_PAD_get_StateInit returns \$state '$state'.\n" );

    return ( 1, $state );
}

=head1 Function Group "PowerSupply"

All functions to access SYC, which are currently supported for PowerSupply.

= cut

=head2 SYC_POWERSUPPLY_get_HighVoltageDetectionLimit

    ( $result , $highVoltageDetectionLimit_V ) = SYC_POWERSUPPLY_get_HighVoltageDetectionLimit( );

returns the high voltage detection limit in V

=cut

sub SYC_POWERSUPPLY_get_HighVoltageDetectionLimit {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_HighVoltageDetectionLimit( )', @args );

    my ( $result, $highVoltageDetectionLimit_V );

    S_w2log( 3, "SYC_POWERSUPPLY_get_HighVoltageDetectionLimit called.\n" );
    ( $result, $highVoltageDetectionLimit_V ) = SYC_get_ConfigId_Content( 'HighVoltageDetectionLimit', ['PowerSupply'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $highVoltageDetectionLimit_V ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'HighVoltageDetectionLimit_V' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $highVoltageDetectionLimit_V =~ s/\s//g;
    $highVoltageDetectionLimit_V =~ s/,/./g;

    if ( $highVoltageDetectionLimit_V =~ /([0-9]*\.?[0-9]+)V/ ) {
        $highVoltageDetectionLimit_V = $1;
    }
    elsif ( $highVoltageDetectionLimit_V =~ /([0-9]*\.?[0-9]+)/ ) {
        $highVoltageDetectionLimit_V = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'HighVoltageDetectionLimit' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_POWERSUPPLY_get_HighVoltageDetectionLimit returns \$highVoltageDetectionLimit_V '$highVoltageDetectionLimit_V'.\n" );

    return ( 1, $highVoltageDetectionLimit_V );
}

=head2 SYC_POWERSUPPLY_get_LowVoltageDetectionLimit

    ( $result , $lowVoltageDetectionLimit_V ) = SYC_POWERSUPPLY_get_LowVoltageDetectionLimit( );

returns the low voltage detection limit in V

=cut

sub SYC_POWERSUPPLY_get_LowVoltageDetectionLimit {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_LowVoltageDetectionLimit( )', @args );

    my ( $result, $lowVoltageDetectionLimit_V );

    S_w2log( 3, "SYC_POWERSUPPLY_get_LowVoltageDetectionLimit called.\n" );
    ( $result, $lowVoltageDetectionLimit_V ) = SYC_get_ConfigId_Content( 'LowVoltageDetectionLimit', ['PowerSupply'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $lowVoltageDetectionLimit_V ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'LowVoltageDetectionLimit_V' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $lowVoltageDetectionLimit_V =~ s/\s//g;
    $lowVoltageDetectionLimit_V =~ s/,/./g;

    if ( $lowVoltageDetectionLimit_V =~ /([0-9]*\.?[0-9]+)V/ ) {
        $lowVoltageDetectionLimit_V = $1;
    }
    elsif ( $lowVoltageDetectionLimit_V =~ /([0-9]*\.?[0-9]+)/ ) {
        $lowVoltageDetectionLimit_V = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'LowVoltageDetectionLimit' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_POWERSUPPLY_get_LowVoltageDetectionLimit returns \$lowVoltageDetectionLimit_V '$lowVoltageDetectionLimit_V'.\n" );

    return ( 1, $lowVoltageDetectionLimit_V );
}

=head2 SYC_POWERSUPPLY_get_MinAutarkyTime

    ( $result , $minAutarkyTime_ms ) = SYC_POWERSUPPLY_get_MinAutarkyTime( );

returns the minimum autarky time in ms

=cut

sub SYC_POWERSUPPLY_get_MinAutarkyTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_MinAutarkyTime( )', @args );

    my ( $result, $minAutarkyTime_ms );

    S_w2log( 3, "SYC_POWERSUPPLY_get_MinAutarkyTime called.\n" );
    ( $result, $minAutarkyTime_ms ) = SYC_get_ConfigId_Content( 'MinAutarkyTime', ['PowerSupply'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $minAutarkyTime_ms ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'MinAutarkyTime_ms' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $minAutarkyTime_ms =~ s/\s//g;
    $minAutarkyTime_ms =~ s/,/./g;

    if ( $minAutarkyTime_ms =~ /([0-9]+)ms/ ) {
        $minAutarkyTime_ms = $1;
    }
    elsif ( $minAutarkyTime_ms =~ /([0-9]+)/ ) {
        $minAutarkyTime_ms = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'MinAutarkyTime' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_POWERSUPPLY_get_MinAutarkyTime returns \$minAutarkyTime_ms '$minAutarkyTime_ms'.\n" );

    return ( 1, $minAutarkyTime_ms );
}

=head2 SYC_POWERSUPPLY_get_NumberOfSupplyLines

    ( $result , $numberOfSupplyLines ) = SYC_POWERSUPPLY_get_NumberOfSupplyLines( );

returns the number of supply lines

=cut

sub SYC_POWERSUPPLY_get_NumberOfSupplyLines {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_NumberOfSupplyLines( )', @args );

    my ( $result, $numberOfSupplyLines );

    S_w2log( 3, "SYC_POWERSUPPLY_get_NumberOfSupplyLines called.\n" );
    ( $result, $numberOfSupplyLines ) = SYC_get_ConfigId_Content( 'NumberOfSupplyLines', ['PowerSupply'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $numberOfSupplyLines ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'NumberOfSupplyLines' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( 3, "SYC_POWERSUPPLY_get_NumberOfSupplyLines returns \$numberOfSupplyLines '$numberOfSupplyLines'.\n" );

    return ( 1, $numberOfSupplyLines );
}

=head2 SYC_POWERSUPPLY_get_ReverseVoltageTestConditions

    ( $result , $ubat_RVT , $duration_RVT , $temperature_RVT ) = SYC_POWERSUPPLY_get_ReverseVoltageTestConditions( );

returns the reverse voltage test condition (Ubat, Duration and temperature)

=cut

sub SYC_POWERSUPPLY_get_ReverseVoltageTestConditions {
    my @args = @_;

    my $subName      = ( split( /::/, ( caller(0) )[3] ) )[-1];
    my $sycType      = SYC_getSycType();
    my $loadFunction = "FuncLib_TNT_SYC_INTERFACE_" . $sycType . "::" . $subName;

    no strict 'refs';
    return &$loadFunction(@args);
}

=head1 Function Group "Configuration_Management"

All functions to access SYC, which are currently supported for Configuration_Management.

=head2 SYC_ConfigurationManagement_CompleteSection

   ( $result , $section_href ) = SYC_ConfigurationManagement_CompleteSection( );

returns the complete section from SycExport as nested hash structure

=cut

sub SYC_ConfigurationManagement_CompleteSection {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_ConfigurationManagement_CompleteSection( )', @args );

    my ( $result, $section_href );

    S_w2log( 3, "SYC_ConfigurationManagement_CompleteSection called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_ConfigurationManagement_CompleteSection' not supported for DOORS based SYC Exports.");
        return 0;
    }

    ( $result, $section_href ) = SYC_get_ScipPM_Content( ['Configuration_Management'] );
    return 0 unless $result;

    S_w2log( 3, "SYC_ConfigurationManagement_CompleteSection returns \$section_href.\n" );

    return ( 1, $section_href );
}

=head2 SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits

   ( $result , $staticBehaviourBits_href, $dynamicBehaviourBits_href ) = SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits( );

returns 2 hashes with all static and dynamic behaviour bits as key and the current selection as value

 $staticBehaviourBits_href = {
 	'PCP_bitEnabled' 				=> "true",
	'PCP_MsbFDConfig_bitEnabled' 	=> 'false',
	'PCP_MsbFPConfig_bitEnabled' 	=> 'false',
	'PCP_MsbRDConfig_bitEnabled' 	=> 'true',
	'PCP_MsbRPConfig_bitEnabled' 	=> 'false',
	'PCP_MsbRCConfig_bitEnabled' 	=> 'false',
 };
 
$dynamicBehaviourBits_href = {
 	'CustBAplantmode' 							=> "true",
	'CustAssemblyFlashforplant' 				=> 'false',
	'CustRapidFlash' 							=> 'false',
	'CustOccupantClassificationSensorEnabled' 	=> 'true',
	'CustVinConfigurationCheckEnabled' 			=> 'false',
	'CustCalibrationSelectionEnabled' 			=> 'false',
 };
 
=cut

sub SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits( )', @args );

    my ( $result, $section_href );

    S_w2log( 3, "SYC_ConfigurationManagement_CompleteSection called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits' not supported for DOORS based SYC Exports.");
        return 0;
    }

    # Static_behaviour_bits Platform
    ( $result, $section_href ) = SYC_get_ScipPM_Content( [ 'Configuration_Management', 'Static_and_dynamic_behaviour_bits', 'Static_behaviour_bits' ] );
    return 0 unless $result;
    my $staticBehaviourBits_href = {};
    my @pointer;
    my $reGenericBehaviourBitEnabled = qr{ (SBB_)?(\w+)_bitEnabled }xms;
    crawlBehaviourBits( $section_href, $reGenericBehaviourBitEnabled, $staticBehaviourBits_href );

    # Static_behaviour_bits Customer specific
    ( $result, $section_href ) = SYC_get_ScipPM_Content( [ 'Configuration_Management', 'Static_and_dynamic_behaviour_bits', 'Static_behaviour_bits', 'SBB_Cust' ] );
    return 0 unless $result;
    @pointer = ();
    my $reCustBehaviourBitEnabled = qr{ ()?(\w+):BitEnabled }xms;
    crawlBehaviourBits( $section_href, $reCustBehaviourBitEnabled, $staticBehaviourBits_href );

    # Dynamic_behaviour_bits Customer specific
    ( $result, $section_href ) = SYC_get_ScipPM_Content( [ 'Configuration_Management', 'Static_and_dynamic_behaviour_bits', 'DynamicBehaviorBits' ] );
    return 0 unless $result;
    @pointer = ();
    my $dynamicBehaviourBits_href = {};
    crawlBehaviourBits( $section_href, $reCustBehaviourBitEnabled, $dynamicBehaviourBits_href );

    S_w2log( 3, "SYC_ConfigurationManagement_getAllStaticAndDynamicBehaviourBits returns \$staticBehaviourBits_href and \$dynamicBehaviourBits_href.\n" );

    return ( 1, $staticBehaviourBits_href, $dynamicBehaviourBits_href );
}

sub crawlBehaviourBits {
    my @args = @_;

    my $section_href = shift @args;
    my $regEx        = shift @args;
    my $output_href  = shift @args;

    foreach my $key ( keys %{$section_href} ) {
        if ( $key =~ $regEx ) {
            $output_href->{$2} = $section_href->{$key}{selected};
        }
        elsif ( ref( $section_href->{$key} ) eq 'HASH' and $section_href->{$key}{selected} eq 'true' ) {
            crawlBehaviourBits( $section_href->{$key}, $regEx, $output_href );
        }
    }

    return 1;
}

=head1 Function Group "Squibs"

All functions to access SYC, which are currently supported for Squibs.

=head2 SYC_SQUIB_get_all_configured

   ( $result , $configured_squibs_aref ) = SYC_SQUIB_get_all_configured( );

returns a list of all squibs which are cofigured in the current variant.

=cut

sub SYC_SQUIB_get_all_configured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_all_configured( )', @args );

    my ( $result, $configured_squibs_aref, $squibs_aref, $configured, $text );

    S_w2log( 3, "SYC_SQUIB_get_all_configured called.\n" );

    ( $result, $squibs_aref ) = SYC_get_ConfigId_List( 'Actuator', ['Actuators'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $squibs_aref ) = SYC_get_ScipPM_List( [ 'Actuators', 'DeviceData' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    foreach my $squib_name (@$squibs_aref) {
        S_w2log( 4, "SYC_SQUIB_get_all_configured checking configured information for squib_name '$squib_name'.\n" );
        ( $result, $configured ) = SYC_SQUIB_get_Configured($squib_name);
        return 0 unless $result;

        push @$configured_squibs_aref, $squib_name if $configured eq 'yes';
    }

    $text = join ',', @$configured_squibs_aref if @$configured_squibs_aref;
    S_w2log( 3, "SYC_SQUIB_get_all_configured returns configured_squibs_aref '$text'.\n" );

    return ( 1, $configured_squibs_aref );
}

=head2 SYC_SQUIB_get_all_monitored

   ( $result , $monitored_squibs_aref ) = SYC_SQUIB_get_all_monitored( );

returns a list of all squibs which are cofigured in the current variant.

=cut

sub SYC_SQUIB_get_all_monitored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_all_monitored( )', @args );

    my ( $result, $monitored_squibs_aref, $squibs_aref, $monitored, $text );

    S_w2log( 3, "SYC_SQUIB_get_all_monitored called.\n" );

    ( $result, $squibs_aref ) = SYC_get_ConfigId_List( 'Actuator', ['Actuators'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $squibs_aref ) = SYC_get_ScipPM_List( [ 'Actuators', 'DeviceData' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    foreach my $squib_name (@$squibs_aref) {
        S_w2log( 4, "SYC_SQUIB_get_all_monitored checking configured information for squib_name '$squib_name'.\n" );
        ( $result, $monitored ) = SYC_SQUIB_get_Monitored($squib_name);
        return 0 unless $result;

        push @$monitored_squibs_aref, $squib_name if $monitored eq 'yes';
    }

    $text = join ',', @$monitored_squibs_aref if @$monitored_squibs_aref;
    S_w2log( 3, "SYC_SQUIB_get_all_monitored returns \$monitored_squibs_aref '$text'.\n" );

    return ( 1, $monitored_squibs_aref );
}

=head2 SYC_SQUIB_get_all_DeactivatedByPAD

   ( $result , $deactivatedByPAD_squibs_aref ) = SYC_SQUIB_get_all_DeactivatedByPAD( );

returns a list of all squibs which are be deactivated by PAD feature.

=cut

sub SYC_SQUIB_get_all_DeactivatedByPAD {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_all_DeactivatedByPAD( )', @args );

    my ( $result, $deactivatedByPAD_squibs_aref, $squibs_aref, $deactivatedByPAD, $text );

    S_w2log( 3, "SYC_SQUIB_get_all_configured called.\n" );

    ( $result, $squibs_aref ) = SYC_get_ConfigId_List( 'Actuator', ['Actuators'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $squibs_aref ) = SYC_get_ScipPM_List( [ 'Actuators', 'DeviceData' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    foreach my $squib_name (@$squibs_aref) {
        S_w2log( 4, "SYC_SQUIB_get_all_DeactivatedByPAD checking deactivatedByPAD information for squib_name '$squib_name'.\n" );
        ( $result, $deactivatedByPAD ) = SYC_SQUIB_get_DeactivatedByPAD($squib_name);
        return 0 unless $result;

        push @$deactivatedByPAD_squibs_aref, $squib_name if $deactivatedByPAD eq 'true';
    }

    $text = join ',', @$deactivatedByPAD_squibs_aref if @$deactivatedByPAD_squibs_aref;
    S_w2log( 3, "SYC_SQUIB_get_all_DeactivatedByPAD returns \$deactivatedByPAD_squibs_aref '$text'.\n" );

    return ( 1, $deactivatedByPAD_squibs_aref );
}

=head2 SYC_SQUIB_get_ASIC_connection

    ( $result , $calc_array_idx , $asic_connection , $asic_connectionCBR , $asic_connectionIGH , $asic_connectionIGL ) = SYC_SQUIB_get_ASIC_connection( $squib_name );

returns the asic connection of the given  squib '$squib_name' [depending on given variant].
and additional returns CBR , IGH, IGL [ CBR1_IGH1-IGL1 --> CBR = 1 , IGH = 1 , IGL = 1 ]

=cut

sub SYC_SQUIB_get_ASIC_connection {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_ASIC_connection( $squib_name )', @args );

    my $squib_name = shift @args;

    my ( $result, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL, $calc_array_idx );

    ( $result, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL ) = FuncLib_TNT_SYC_INTERFACE_doorsXML::SYC_SQUIB_get_ASIC_connection($squib_name) if ( SYC_getSycType() eq "doorsXML" );
    ( $result, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL ) = FuncLib_TNT_SYC_INTERFACE_scipPM::SYC_SQUIB_get_ASIC_connection($squib_name)   if ( SYC_getSycType() eq "scipPM" );

    S_w2log( 3, "SYC_SQUIB_get_ASIC_connection returns asic_connection '$asic_connection' , CBR '$asic_connectionCBR' , IGH '$asic_connectionIGH' , IGL '$asic_connectionIGL' , array index '$calc_array_idx'.\n" );

    return ( 1, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL );
}

=head2 SYC_SQUIB_get_Configured

    ( $result , $configured ) = SYC_SQUIB_get_Configured( $squib_name );

returns content of the config id "Configured" of the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_Configured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_Configured( $squib_name )', @args );

    my $squib_name = shift @args;
    my $configured;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_Configured called for \$squib_name '$squib_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'configured' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $configured = "yes";
        }
        else {
            $configured = "no";
        }
    }
    else {
        ( $result, $configured ) = SYC_get_ConfigId_Content_NOERROR( 'Configured', [ 'Actuator', $squib_name ] );
        ( $result, $configured ) = SYC_get_ConfigId_Content( 'Configured', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SQUIB_get_Configured returns \$configured '$configured'.\n" );

    return ( 1, $configured );
}

=head2 SYC_SQUIB_get_DeactivatedByPAD

    ( $result , $deactivatedByPAD ) = SYC_SQUIB_get_DeactivatedByPAD( $squib_name );

returns true if the given squib '$squib_name' can be deactivated by PAD feature.

=cut

sub SYC_SQUIB_get_DeactivatedByPAD {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_DeactivatedByPAD( $squib_name )', @args );

    my $squib_name = shift @args;
    my $deactivatedByPAD;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_Configured called for \$squib_name '$squib_name' .\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_SQUIB_get_DeactivatedByPAD' not supported for DOORS based SYC Exports.");
        return 0;
    }

    ( $result, $deactivatedByPAD ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'IsDeactivatedByPassengerAirbagDeactivation' ] );
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_SQUIB_get_DeactivatedByPAD returns \$deactivatedByPAD '$deactivatedByPAD'.\n" );

    return ( 1, $deactivatedByPAD );
}

=head2 SYC_SQUIB_get_Monitored

    ( $result , $monitored ) = SYC_SQUIB_get_Monitored( $squib_name );

returns content of the config id "Monitored" of the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_Monitored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_Monitored( $squib_name )', @args );

    my $squib_name = shift @args;
    my $monitored;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_Monitored called for \$squib_name '$squib_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {

        my ( $onlyMonitored, $configured );
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'configured' ] );
        return 0 unless $result;
        ( $result, $onlyMonitored ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'onlyMonitored' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $monitored = "yes";
        }
        elsif ( $onlyMonitored eq "true" ) {
            $monitored = "yes";
        }
        else {
            $monitored = "no";
        }
    }
    else {
        ( $result, $monitored ) = SYC_get_ConfigId_Content_NOERROR( 'Monitored', [ 'Actuator', $squib_name ] );
        ( $result, $monitored ) = SYC_get_ConfigId_Content( 'Monitored', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SQUIB_get_Monitored returns \$monitored '$monitored'.\n" );

    return ( 1, $monitored );
}

=head2 SYC_InternalSensor_getAllSensors

    ( $result , $internalSensors_aref ) = SYC_InternalSensor_getAllSensors(  );

returns all internal sensors

=cut

sub SYC_InternalSensor_getAllSensors {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_InternalSensor_getAllSensors(  )', @args );

    my $internalSensors_aref;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_InternalSensor_getAllSensors () called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_InternalSensor_getAllSensors' not supported for DOORS based SYC Exports.");
        return 0;
    }

    ( $result, $internalSensors_aref ) = SYC_get_ScipPM_List( [ 'InternalSensors', 'DeviceData' ] );
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_InternalSensor_getAllSensors returns \$internalSensors_aref '$internalSensors_aref'.\n" );

    return ( 1, $internalSensors_aref );
}

=head2 SYC_InternalSensor_getSensorType

    ( $result , $internalSensors_aref ) = SYC_InternalSensor_getSensorType( $internalSensor );

returns the sensor type of given internal sensor

=cut

sub SYC_InternalSensor_getSensorType {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_InternalSensor_getSensorType( $internalSensor )', @args );

    my $internalSensor = shift @args;
    my $sensorType;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_InternalSensor_getSensorType called for \$internalSensor $internalSensor.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_InternalSensor_getSensorType' not supported for DOORS based SYC Exports.");
        return 0;
    }

    ( $result, $sensorType ) = SYC_get_ScipPM_Content( [ 'InternalSensors', 'DeviceData', $internalSensor ] );
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_InternalSensor_getSensorType returns \$sensorType '$sensorType'.\n" );

    return ( 1, $sensorType );
}

=head2 SYC_SENSOR_get_Configured

    ( $result , $configured ) = SYC_SENSOR_get_Configured( $sensor_name );

returns content of the config id "Configured" of the given sensor '$sensor_name' in the configured variant.

=cut

sub SYC_SENSOR_get_Configured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SENSOR_get_Configured( $sensor_name )', @args );

    my $sensor_name = shift @args;
    my $configured;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SENSOR_get_Configured called for \$sensor_name '$sensor_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $configured ) = SYC_get_ScipPM_Content_NOERROR( [ 'Sensors', 'DeviceData', $sensor_name, 'ch1', 'configured' ] );
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Sensors', 'DeviceData', $sensor_name, 'CH1', 'configured' ] ) unless $result;
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $configured = "yes";
        }
        else {
            $configured = "no";
        }

    }
    else {
        ( $result, $configured ) = SYC_get_ConfigId_Content_NOERROR( 'Configured', [ 'Sensor', $sensor_name ] );
        ( $result, $configured ) = SYC_get_ConfigId_Content( 'Configured', [ 'Sensor', ".*" . $sensor_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SENSOR_get_Configured returns \$configured '$configured'.\n" );

    return ( 1, $configured );
}

=head2 SYC_SENSOR_get_Monitored

    ( $result , $monitored ) = SYC_SENSOR_get_Monitored( $sensor_name );

returns content of the config id "Monitored" of the given squib '$sensor_name' in the configured variant.

=cut

sub SYC_SENSOR_get_Monitored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SENSOR_get_Monitored( $sensor_name )', @args );

    my $sensor_name = shift @args;
    my $monitored;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SENSOR_get_Monitored called for \$sensor_name '$sensor_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {

        my ( $onlyMonitored, $configured );
        ( $result, $configured ) = SYC_get_ScipPM_Content_NOERROR( [ 'Sensors', 'DeviceData', $sensor_name, 'ch1', 'configured' ] );
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Sensors', 'DeviceData', $sensor_name, 'CH1', 'configured' ] ) unless $result;
        return 0 unless $result;
        ( $result, $onlyMonitored ) = SYC_get_ScipPM_Content_NOERROR( [ 'Sensors', 'DeviceData', $sensor_name, 'ch1', 'onlyMonitored' ] );
        ( $result, $onlyMonitored ) = SYC_get_ScipPM_Content( [ 'Sensors', 'DeviceData', $sensor_name, 'CH1', 'onlyMonitored' ] ) unless $result;
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $monitored = "yes";
        }
        elsif ( $onlyMonitored eq "true" ) {
            $monitored = "yes";
        }
        else {
            $monitored = "no";
        }
    }
    else {
        ( $result, $monitored ) = SYC_get_ConfigId_Content_NOERROR( 'Monitored', [ 'Sensor', $sensor_name ] );
        ( $result, $monitored ) = SYC_get_ConfigId_Content( 'Monitored', [ 'Sensor', ".*" . $sensor_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SENSOR_get_Monitored returns \$monitored '$monitored'.\n" );

    return ( 1, $monitored );
}

=head2 SYC_AnalogueOutput_get_Configured

    ( $result , $configured ) = SYC_AnalogueOutput_get_Configured( $AnalogueOutput_name );

returns content of the config id "Configured" of the given analog output '$AnalogueOutput_name' in the configured variant.

=cut

sub SYC_AnalogueOutput_get_Configured {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_AnalogueOutput_get_Configured( $analogueOutput_name )', @args );

    my $analogueOutput_name = shift @args;
    my $configured;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_AnalogueOutput_get_Configured called for \$sensor_name '$analogueOutput_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'configured' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $configured = "yes";
        }
        else {
            $configured = "no";
        }

    }
    else {
        ( $result, $configured ) = SYC_get_ConfigId_Content_NOERROR( 'Configured', [ 'AnalogueOutput', $analogueOutput_name ] );
        ( $result, $configured ) = SYC_get_ConfigId_Content( 'Configured', [ 'AnalogueOutput', ".*" . $analogueOutput_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_AnalogueOutput_get_Configured returns \$configured '$configured'.\n" );

    return ( 1, $configured );
}

=head2 SYC_AnalogueOutput_get_Monitored

    ( $result , $monitored ) = SYC_AnalogueOutput_get_Monitored( $AnalogueOutput_name );

returns content of the config id "Configured" of the given analog output '$AnalogueOutput_name' in the configured variant.

=cut

sub SYC_AnalogueOutput_get_Monitored {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_AnalogueOutput_get_Monitored( $analogueOutput_name )', @args );

    my $analogueOutput_name = shift @args;
    my $monitored;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_AnalogueOutput_get_Monitored called for \$analogueOutput_name '$analogueOutput_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {

        my ( $onlyMonitored, $configured );
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'configured' ] );
        return 0 unless $result;
        ( $result, $onlyMonitored ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'onlyMonitored' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $monitored = "yes";
        }
        elsif ( $onlyMonitored eq "true" ) {
            $monitored = "yes";
        }
        else {
            $monitored = "no";
        }
    }
    else {
        ( $result, $monitored ) = SYC_get_ConfigId_Content_NOERROR( 'Monitored', [ 'AnalogueOutput', $analogueOutput_name ] );
        ( $result, $monitored ) = SYC_get_ConfigId_Content( 'Monitored', [ 'AnalogueOutput', ".*" . $analogueOutput_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_AnalogueOutput_get_Monitored returns \$monitored '$monitored'.\n" );

    return ( 1, $monitored );
}

=head2 SYC_AnalogueOutput_isLowSideDriver

    ( $result , $isLowSideDriver ) = SYC_AnalogueOutput_isLowSideDriver( $AnalogueOutput_name );

returns 'true' if Analogue Output $AnalogueOutput_name is a LowSideDriver (always if ASIC is selected and depending on selection if discrete is selected).
returns 'false' otherwise

=cut

sub SYC_AnalogueOutput_isLowSideDriver {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_AnalogueOutput_isLowSideDriver( $analogueOutput_name )', @args );

    my $analogueOutput_name = shift @args;
    my $isLowSideDriver;
    my $isASCI;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_AnalogueOutput_isLowSideDriver called for \$analogueOutput_name '$analogueOutput_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {

        ( $result, $isLowSideDriver ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'lowSideDriver' ] );
        return 0 unless $result;
        ( $result, $isASCI ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'ASIC' ] );
        return 0 unless $result;

        $isLowSideDriver = 'true' if ( $isASCI eq 'true' );
    }
    else {
        my $type;
        ( $result, $type ) = SYC_get_ConfigId_Content_NOERROR( 'Type', [ 'AnalogueOutput', $analogueOutput_name ] );
        ( $result, $type ) = SYC_get_ConfigId_Content( 'Type', [ 'AnalogueOutput', ".*" . $analogueOutput_name . ".*" ] ) unless $result;
        return 0 unless $result;

        if ( $type =~ /low side driver/ ) {
            $isLowSideDriver = 'yes';
        }
        else {
            $isLowSideDriver = 'no';
        }
    }

    S_w2log( $loglevel, "SYC_AnalogueOutput_isLowSideDriver returns \$isLowSideDriver '$isLowSideDriver'.\n" );

    return ( 1, $isLowSideDriver );
}

=head2 SYC_AnalogueOutput_isHighSideDriver

    ( $result , $isHighSideDriver ) = SYC_AnalogueOutput_isHighSideDriver( $AnalogueOutput_name );

returns 'true' if Analogue Output $AnalogueOutput_name is a HighSideDriver
returns 'false' otherwise

=cut

sub SYC_AnalogueOutput_isHighSideDriver {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_AnalogueOutput_isHighSideDriver( $analogueOutput_name )', @args );

    my $analogueOutput_name = shift @args;
    my $isHighSideDriver;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_AnalogueOutput_isHighSideDriver called for \$analogueOutput_name '$analogueOutput_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {

        ( $result, $isHighSideDriver ) = SYC_get_ScipPM_Content( [ 'AnalogueOutputs', 'DeviceData', $analogueOutput_name, 'highSideDriver' ] );
        return 0 unless $result;

    }
    else {
        my $type;
        ( $result, $type ) = SYC_get_ConfigId_Content_NOERROR( 'Type', [ 'AnalogueOutput', $analogueOutput_name ] );
        ( $result, $type ) = SYC_get_ConfigId_Content( 'Type', [ 'AnalogueOutput', ".*" . $analogueOutput_name . ".*" ] ) unless $result;
        return 0 unless $result;

        if ( $type =~ /high side driver/ ) {
            $isHighSideDriver = 'yes';
        }
        else {
            $isHighSideDriver = 'no';
        }
    }

    S_w2log( $loglevel, "SYC_AnalogueOutput_isHighSideDriver returns \$isHighSideDriver '$isHighSideDriver'.\n" );

    return ( 1, $isHighSideDriver );
}

=head2 SYC_SQUIB_get_firing_mode

    ( $result , $firing_mode ) = SYC_SQUIB_get_firing_mode( $squib_name );

returns the firing mode for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_firing_mode {
    my @args = @_;

    my $subName      = ( split( /::/, ( caller(0) )[3] ) )[-1];
    my $sycType      = SYC_getSycType();
    my $loadFunction = "FuncLib_TNT_SYC_INTERFACE_" . $sycType . "::" . $subName;

    no strict 'refs';
    return &$loadFunction(@args);
}

=head2 SYC_SQUIB_get_firing_pulse_min_current

    ( $result , $min_current_A , $min_current_backup_A ) = SYC_SQUIB_get_firing_pulse_min_current( $squib_name );

returns the expected minimum firing current and if configured backup current (currently only used for dynamic switching in mode V).

=cut

sub SYC_SQUIB_get_firing_pulse_min_current {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_firing_pulse_min_current( $squib_name )', @args );

    my $squib_name = shift @args;
    my ( $firing_mode, $min_current_A, $min_current_backup_A, $fire_modes );
    my $result;

    S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_current called for squib_name '$squib_name' .\n" );

    ( $result, $firing_mode ) = SYC_SQUIB_get_firing_mode($squib_name);
    return 0 unless $result;

    ( $result, $min_current_A ) = SYC_get_FiringModeDetails( $firing_mode, 'current_A' );
    return 0 unless $result;

    ( $result, $min_current_backup_A ) = SYC_get_FiringModeDetails( $firing_mode, 'current_A', 'backup' );

    if ($result) {
        S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_current returns min_current_A '$min_current_A' , min_current_backup_A '$min_current_backup_A' ...\n" );
        return ( 1, $min_current_A, $min_current_backup_A );
    }

    S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_current returns min_current_A '$min_current_A' ...\n" );
    return ( 1, $min_current_A );
}

=head2 SYC_SQUIB_get_firing_pulse_min_duration

    ( $result , $min_duration_ms [, $min_duration_backup_ms ] ) = SYC_SQUIB_get_firing_pulse_min_duration( $squib_name );

returns the expected minimum firing duration and if configured backup duration (currently only used for dynamic switching in mode V).

=cut

sub SYC_SQUIB_get_firing_pulse_min_duration {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_firing_pulse_min_duration( $squib_name )', @args );

    my $squib_name = shift @args;
    my ( $firing_mode, $min_duration_ms, $min_duration_backup_ms, $fire_modes );
    my $result;

    S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_duration called for squib_name '$squib_name' .\n" );

    ( $result, $firing_mode ) = SYC_SQUIB_get_firing_mode($squib_name);
    return 0 unless $result;

    ( $result, $min_duration_ms ) = SYC_get_FiringModeDetails( $firing_mode, 'duration_ms' );
    return 0 unless $result;

    ( $result, $min_duration_backup_ms ) = SYC_get_FiringModeDetails( $firing_mode, 'duration_ms', 'backup' );

    if ($result) {
        S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_duration returns min_duration_ms '$min_duration_ms' , min_duration_backup_ms '$min_duration_backup_ms' ...\n" );
        return ( 1, $min_duration_ms, $min_duration_backup_ms );
    }

    S_w2log( 3, "SYC_SQUIB_get_firing_pulse_min_duration returns min_duration_ms '$min_duration_ms' ...\n" );
    return ( 1, $min_duration_ms );
}

=head2 SYC_SQUIB_get_RepetitionTime

    ( $result , $repetionTime_ms ) = SYC_SQUIB_get_RepetitionTime( );

returns the repetition time for the firing loop monitoring in ms.

=cut

sub SYC_SQUIB_get_RepetitionTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_RepetitionTime( )', @args );

    my $squib_name = shift @args;

    my ( $result, $repetionTime_ms );

    S_w2log( 3, "SYC_SQUIB_get_RepetitionTime called.\n" );

    ( $result, $repetionTime_ms ) = SYC_get_ConfigId_Content( 'RepetitionTime', [ 'Actuators', 'FaultHandling' ] ) if ( SYC_getSycType() eq "doorsXML" );
    ( $result, $repetionTime_ms ) = SYC_get_ScipPM_Content( [ 'Actuators', 'GeneralData', 'RepetitionTime_ms' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $repetionTime_ms =~ /([0-9]+)ms/ ) {
        $repetionTime_ms = $1;
    }

    S_w2log( 3, "SYC_SQUIB_get_RepetitionTime returns RepetitionTime '$repetionTime_ms'.\n" );

    return ( 1, $repetionTime_ms );
}

=head2 SYC_SQUIB_get_ResistanceHighLowerThd

    ( $result , $resistanceHighLowerThd ) = SYC_SQUIB_get_ResistanceHighLowerThd( $squib_name );

returns the ResistanceHighLowerThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceHighLowerThd {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceHighLowerThd( $squib_name )', @args );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_SQUIB_get_ResistanceHighLowerThd' not supported for Doors based SYC.");
        return 0;
    }

    my $squib_name = shift @args;
    my $resistanceHighLowerThd;
    my ($result);

    S_w2log( 3, "SYC_SQUIB_get_ResistanceHighLowerThd called for squib_name '$squib_name' .\n" );

    ( $result, $resistanceHighLowerThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceHigh_LowerThreshold_Ohm' ] );
    return 0 unless $result;

    $resistanceHighLowerThd =~ s/\s//g;
    $resistanceHighLowerThd =~ s/,/./g;

    if ( $resistanceHighLowerThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceHighLowerThd = $1;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceHighLowerThd returns ResistanceHighLowerThd '$resistanceHighLowerThd'.\n" );

    return ( 1, $resistanceHighLowerThd );
}

=head2 SYC_SQUIB_get_ResistanceOkLowerThd

    ( $result , $resistanceOkLowerThd ) = SYC_SQUIB_get_ResistanceOkLowerThd( $squib_name );

returns the ResistanceOkLowerThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceOkLowerThd {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceOkLowerThd( $squib_name )', @args );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_SQUIB_get_ResistanceOkLowerThd' not supported for Doors based SYC.");
        return 0;
    }

    my $squib_name = shift @args;
    my $resistanceOkLowerThd;
    my ($result);

    S_w2log( 3, "SYC_SQUIB_get_ResistanceOkLowerThd called for squib_name '$squib_name' .\n" );
    ( $result, $resistanceOkLowerThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceOk_LowerThreshold_Ohm' ] );
    return 0 unless $result;

    $resistanceOkLowerThd =~ s/\s//g;
    $resistanceOkLowerThd =~ s/,/./g;

    if ( $resistanceOkLowerThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceOkLowerThd = $1;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceOkLowerThd returns ResistanceOkLowerThd '$resistanceOkLowerThd'.\n" );

    return ( 1, $resistanceOkLowerThd );
}

=head2 SYC_SQUIB_get_ResistanceOkUpperThd

    ( $result , $resistanceOkUpperThd ) = SYC_SQUIB_get_ResistanceOkUpperThd( $squib_name );

returns the ResistanceOkUpperThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceOkUpperThd {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceOkUpperThd( $squib_name )', @args );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_SQUIB_get_ResistanceOkUpperThd' not supported for Doors based SYC.");
        return 0;
    }

    my $squib_name = shift @args;
    my $resistanceOkUpperThd;
    my ($result);

    S_w2log( 3, "SYC_SQUIB_get_ResistanceOkUpperThd called for squib_name '$squib_name' .\n" );
    ( $result, $resistanceOkUpperThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceOk_UpperThreshold_Ohm' ] );
    return 0 unless $result;

    $resistanceOkUpperThd =~ s/\s//g;
    $resistanceOkUpperThd =~ s/,/./g;

    if ( $resistanceOkUpperThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceOkUpperThd = $1;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceOkUpperThd returns ResistanceOkUpperThd '$resistanceOkUpperThd'.\n" );

    return ( 1, $resistanceOkUpperThd );
}

=head2 SYC_SQUIB_get_ResistanceLowUpperThd

    ( $result , $resistanceLowUpperThd ) = SYC_SQUIB_get_ResistanceLowUpperThd( $squib_name );

returns the ResistanceLowUpperThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceLowUpperThd {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceLowUpperThd( $squib_name )', @args );

    if ( SYC_getSycType() eq "doorsXML" ) {
        S_set_error("Function 'SYC_SQUIB_get_ResistanceLowUpperThd' not supported for Doors based SYC.");
        return 0;
    }

    my $squib_name = shift @args;
    my $resistanceLowUpperThd;
    my ($result);

    S_w2log( 3, "SYC_SQUIB_get_ResistanceLowUpperThd called for squib_name '$squib_name' .\n" );
    ( $result, $resistanceLowUpperThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceLow_UpperThreshold_Ohm' ] );
    return 0 unless $result;

    $resistanceLowUpperThd =~ s/\s//g;
    $resistanceLowUpperThd =~ s/,/./g;

    if ( $resistanceLowUpperThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceLowUpperThd = $1;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceLowUpperThd returns ResistanceLowUpperThd '$resistanceLowUpperThd'.\n" );

    return ( 1, $resistanceLowUpperThd );
}

=head2 SYC_SQUIB_get_ResistanceLowerThd

    ( $result , $resistanceLowerThd ) = SYC_SQUIB_get_ResistanceLowerThd( $squib_name );

returns the ResistanceLowerThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceLowerThd {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceLowerThd( $squib_name )', @args );

    my $squib_name = shift @args;
    my $resistanceLowerThd;
    my $result;

    S_w2log( 3, "SYC_SQUIB_get_ResistanceLowerThd called for squib_name '$squib_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $resistanceLowerThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceLowThreshold_Ohm' ] );
        return 0 unless $result;
    }
    else {
        ( $result, $resistanceLowerThd ) = SYC_get_ConfigId_Content_NOERROR( 'ResistanceLowerThd', [ 'Actuator', $squib_name ] );
        ( $result, $resistanceLowerThd ) = SYC_get_ConfigId_Content( 'ResistanceLowerThd', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    $resistanceLowerThd =~ s/\s//g;
    $resistanceLowerThd =~ s/,/./g;

    if ( $resistanceLowerThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceLowerThd = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'ResistanceLowerThd' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceLowerThd returns ResistanceLowerThd '$resistanceLowerThd'.\n" );

    return ( 1, $resistanceLowerThd );
}

=head2 SYC_SQUIB_get_ResistanceShort2Bat

    ( $result , $resistanceShort2Bat_kOhm ) = SYC_SQUIB_get_ResistanceShort2Bat( );

returns the resistance threshold in kOhm for high-ohmic short to battery.

=cut

sub SYC_SQUIB_get_ResistanceShort2Bat {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceShort2Bat( )', @args );

    my $squib_name = shift @args;

    my ( $result, $resistanceShort2Bat_kOhm );

    S_w2log( 3, "SYC_SQUIB_get_ResistanceShort2Bat called.\n" );
    ( $result, $resistanceShort2Bat_kOhm ) = SYC_get_ConfigId_Content( 'ResistanceShort2Bat', [ 'Actuators', 'FaultHandling' ] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $resistanceShort2Bat_kOhm ) = SYC_get_ScipPM_Content( [ 'Actuators', 'GeneralData', 'ResistanceShort2Bat_kOhm' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $resistanceShort2Bat_kOhm =~ s/\s//g;

    if ( $resistanceShort2Bat_kOhm =~ /(\d+)kOhm/ ) {
        $resistanceShort2Bat_kOhm = $1;
    }
    elsif ( $resistanceShort2Bat_kOhm =~ /(\d+)/ ) {
        $resistanceShort2Bat_kOhm = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'ResistanceShort2Bat' is not in the expected format ( 5;20 [kOhm]).", 20 );
        return 0;
    }

    unless ( $resistanceShort2Bat_kOhm == 5 or $resistanceShort2Bat_kOhm == 20 ) {
        S_set_error( "Content of ConfigID 'ResistanceShort2Bat' is not in the expected format ( 5;20 [kOhm]).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceShort2Bat returns ResistanceShort2Bat '$resistanceShort2Bat_kOhm'.\n" );

    return ( 1, $resistanceShort2Bat_kOhm );
}

=head2 SYC_SQUIB_get_ResistanceUpperThd

    ( $result , $resistanceUpperThd ) = SYC_SQUIB_get_ResistanceUpperThd( $squib_name );

returns the ResistanceLowerThd for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_ResistanceUpperThd {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ResistanceUpperThd( $squib_name )', @args );

    my $squib_name = shift @args;
    my $resistanceUpperThd;
    my $result;

    S_w2log( 3, "SYC_SQUIB_get_ResistanceUpperThd called for squib_name '$squib_name' .\n" );

    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $resistanceUpperThd ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ResistanceHighThreshold_Ohm' ] );
        return 0 unless $result;
    }
    else {
        ( $result, $resistanceUpperThd ) = SYC_get_ConfigId_Content_NOERROR( 'ResistanceUpperThd', [ 'Actuator', $squib_name ] );
        ( $result, $resistanceUpperThd ) = SYC_get_ConfigId_Content( 'ResistanceUpperThd', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    $resistanceUpperThd =~ s/\s//g;
    $resistanceUpperThd =~ s/,/./g;

    if ( $resistanceUpperThd =~ /([0-9]*\.?[0-9]+)/ ) {
        $resistanceUpperThd = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'ResistanceUpperThd' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SQUIB_get_ResistanceUpperThd returns ResistanceUpperThd '$resistanceUpperThd'.\n" );

    return ( 1, $resistanceUpperThd );
}

=head2 SYC_SQUIB_get_TestCurrent

    ( $result , $testCurrent_mA ) = SYC_SQUIB_get_TestCurrent( );

returns the level of firing loop test current in mA.

=cut

sub SYC_SQUIB_get_TestCurrent {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_TestCurrent( )', @args );

    my $squib_name = shift @args;

    my ( $result, $testCurrent_mA );

    S_w2log( 3, "SYC_SQUIB_get_TestCurrent called.\n" );
    ( $result, $testCurrent_mA ) = SYC_get_ConfigId_Content( 'FiringLoopTestCurrent', [ 'Actuators', 'FaultHandling' ] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $testCurrent_mA ) = SYC_get_ScipPM_Content( [ 'Actuators', 'GeneralData', 'TestCurrent_mA' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( 3, "SYC_SQUIB_get_TestCurrent returns FiringLoopTestCurrent '$testCurrent_mA'.\n" );

    return ( 1, $testCurrent_mA );
}

=head2 SYC_SQUIB_get_type

    ( $result , $squib_type ) = SYC_SQUIB_get_type( $squib_name );

returns the configured squib type for the given squib '$squib_name' in the configured variant.

=cut

sub SYC_SQUIB_get_type {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SQUIB_get_type( $squib_name )', @args );

    my $squib_name = shift @args;
    my $squib_type;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_type called for squib_name '$squib_name' .\n" );

    ( $result, $squib_type ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'ActuatorType' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_SQUIB_get_type returns squib_type '$squib_type'.\n" );

    return ( 1, $squib_type );
}

=head1 Function Group "Switches"

All functions to access SYC, which are currently supported for switches.

=head2 SYC_SWITCH_get_all_configured

   ( $result , $configured_switches_aref ) = SYC_SWITCH_get_all_configured( );

returns a list of all switches which are cofigured in the current variant.

=cut

sub SYC_SWITCH_get_all_configured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_all_configured( )', @args );

    my ( $result, $configured_switches_aref, $switches_aref, $configured, $text );

    S_w2log( 3, "SYC_SWITCH_get_all_configured called.\n" );

    ( $result, $switches_aref ) = SYC_get_ConfigId_List( 'Switch', ['Switches'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $switches_aref ) = SYC_get_ScipPM_List( [ 'Switches', 'DeviceData' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    foreach my $switch_name (@$switches_aref) {
        S_w2log( 4, "SYC_SWITCH_get_all_configured checking configured information for switch_name '$switch_name'.\n" );
        ( $result, $configured ) = SYC_SWITCH_get_Configured($switch_name);
        return 0 unless $result;

        push @$configured_switches_aref, $switch_name if $configured eq 'yes';
    }

    $text = join ',', @$configured_switches_aref if @$configured_switches_aref;
    S_w2log( 3, "SYC_SWITCH_get_all_configured returns configured_switches_aref '$text'.\n" );

    return ( 1, $configured_switches_aref );
}

=head2 SYC_SWITCH_get_all_monitored

   ( $result , $monitored_switches_aref ) = SYC_SWITCH_get_all_monitored( );

returns a list of all switches which are monitored in the current variant.

=cut

sub SYC_SWITCH_get_all_monitored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_all_monitored( )', @args );

    my ( $result, $monitored_switches_aref, $switches_aref, $monitored, $text );

    S_w2log( 3, "SYC_SWITCH_get_all_monitored called.\n" );

    ( $result, $switches_aref ) = SYC_get_ConfigId_List( 'Switch', ['Switches'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $switches_aref ) = SYC_get_ScipPM_List( [ 'Switches', 'DeviceData' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    foreach my $switch_name (@$switches_aref) {
        S_w2log( 4, "SYC_SWITCH_get_all_monitored checking monitored information for switch_name '$switch_name'.\n" );
        ( $result, $monitored ) = SYC_SWITCH_get_Monitored($switch_name);
        return 0 unless $result;

        push @$monitored_switches_aref, $switch_name if $monitored eq 'yes';
    }

    $text = join ',', @$monitored_switches_aref if @$monitored_switches_aref;
    S_w2log( 3, "SYC_SWITCH_get_all_monitored returns configured_switches_aref '$text'.\n" );

    return ( 1, $monitored_switches_aref );
}

=head2 SYC_SWITCH_get_ASIC_connection

    ( $result , $calc_array_idx , $asic_connection , $asic_connectionCBR , $asic_connectionA_MEAS  ) = SYC_SWITCH_get_ASIC_connection( $switch_name );

returns the asic connection of the given switch '$switch_name' [depending on given variant].
and additional returns CBR , A_MEAS [ A_MEAS5_CBR1 --> CBR = 1 , A_MEAS = 5 ]

=cut

sub SYC_SWITCH_get_ASIC_connection {
    my @args = @_;

    my $subName      = ( split( /::/, ( caller(0) )[3] ) )[-1];
    my $sycType      = SYC_getSycType();
    my $loadFunction = "FuncLib_TNT_SYC_INTERFACE_" . $sycType . "::" . $subName;

    no strict 'refs';
    return &$loadFunction(@args);
}

=head2 SYC_SWITCH_get_Configured

    ( $result , $configured ) = SYC_SWITCH_get_Configured( $switch_name );

returns content of the config id "Configured" of the given switch '$switch_name' in the configured variant.

=cut

sub SYC_SWITCH_get_Configured {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_Configured( $switch_name )', @args );

    my $switch_name = shift @args;
    my $configured;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SWITCH_get_Configured called for switch_name '$switch_name' .\n" );
    if ( SYC_getSycType() eq "scipPM" ) {
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'configured' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $configured = "yes";
        }
        else {
            $configured = "no";
        }
    }
    else {
        ( $result, $configured ) = SYC_get_ConfigId_Content_NOERROR( 'Configured', [ 'Switch', $switch_name ] );
        ( $result, $configured ) = SYC_get_ConfigId_Content( 'Configured', [ 'Switch', ".*" . $switch_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SWITCH_get_Configured returns \$configured '$configured'.\n" );

    return ( 1, $configured );
}

=head2 SYC_SWITCH_get_Monitored

    ( $result , $monitored ) = SYC_SWITCH_get_Monitored( $switch_name );

returns content of the config id "Configured" of the given switch '$switch_name' in the configured variant.

=cut

sub SYC_SWITCH_get_Monitored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_Monitored( $switch_name )', @args );

    my $switch_name = shift @args;
    my $monitored;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SWITCH_get_Monitored called for switch_name '$switch_name' .\n" );
    if ( SYC_getSycType() eq "scipPM" ) {
        my ( $onlyMonitored, $configured );
        ( $result, $configured ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'configured' ] );
        return 0 unless $result;
        ( $result, $onlyMonitored ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'onlyMonitored' ] );
        return 0 unless $result;

        if ( $configured eq "true" ) {
            $monitored = "yes";
        }
        elsif ( $onlyMonitored eq "true" ) {
            $monitored = "yes";
        }
        else {
            $monitored = "no";
        }
    }
    else {
        ( $result, $monitored ) = SYC_get_ConfigId_Content_NOERROR( 'Monitored', [ 'Switch', $switch_name ] );
        ( $result, $monitored ) = SYC_get_ConfigId_Content( 'Monitored', [ 'Switch', ".*" . $switch_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }

    S_w2log( $loglevel, "SYC_SWITCH_get_Monitored returns \$monitored '$monitored'.\n" );

    return ( 1, $monitored );
}

=head2 SYC_SWITCH_get_DefaultCondition

    ( $result, $default_condition ) = SYC_SWITCH_get_DefaultCondition( $switch_name );
    
returns the configured default condition of the given switch '$switch_name' [depending on given variant].

=cut

sub SYC_SWITCH_get_DefaultCondition {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_DefaultCondition( $switch_name )', @args );

    my $switch_name = shift @args;

    my ( $result, $default_condition, $switch_type );

    S_w2log( 3, "SYC_SWITCH_get_DefaultCondition called for switch_name '$switch_name'.\n" );
    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
        return 0 unless $result;
        ( $result, $default_condition ) = SYC_get_ConfigId_Content_NOERROR( 'DefaultCondition', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $default_condition ) = SYC_get_ConfigId_Content( 'DefaultCondition', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $default_condition ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'InitialCondition' ] );
        return 0 unless $result;
    }
    $default_condition =~ s/\s//g;

    unless ( $default_condition eq 'PositionA' or $default_condition eq 'PositionB' ) {
        S_set_error( "Content of ConfigID 'DefaultCondition' for switch type '$switch_type' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SWITCH_get_DefaultCondition returns default condition '$default_condition'.\n" );

    return ( 1, $default_condition );
}

=head2 SYC_SWITCH_get_FaultReaction

    ( $result, $fault_reaction ) = SYC_SWITCH_get_FaultReaction( $switch_name );
    
returns the configured fault reaction of the given switch '$switch_name' [depending on given variant].

=cut

sub SYC_SWITCH_get_FaultReaction {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_FaultReaction( $switch_name )', @args );

    my $switch_name = shift @args;

    my ( $result, $fault_reaction, $switch_type );

    S_w2log( 3, "SYC_SWITCH_get_ASIC_connection called for switch_name '$switch_name'.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
        return 0 unless $result;
        ( $result, $fault_reaction ) = SYC_get_ConfigId_Content_NOERROR( 'FaultReaction', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $fault_reaction ) = SYC_get_ConfigId_Content( 'FaultReaction', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $fault_reaction ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'FaultReaction' ] );
        return 0 unless $result;
    }

    unless ( $fault_reaction =~ /keep last condition/ or $fault_reaction =~ /default condition/ ) {
        S_set_error( "Content of ConfigID 'FaultReaction' for switch type '$switch_type' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SWITCH_get_FaultReaction returns fault reaction '$fault_reaction'.\n" );

    return ( 1, $fault_reaction );
}

=head2 SYC_SWITCH_get_InitialCondition

    ( $result, $initial_condition ) = SYC_SWITCH_get_InitialCondition( $switch_name );
    
returns the configured initial condition of the given switch '$switch_name' [depending on given variant].

=cut

sub SYC_SWITCH_get_InitialCondition {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_InitialCondition( $switch_name )', @args );

    my $switch_name = shift @args;

    my ( $result, $initial_condition, $switch_type );

    S_w2log( 3, "SYC_SWITCH_get_InitialCondition called for switch_name '$switch_name'.\n" );
    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
        return 0 unless $result;
        ( $result, $initial_condition ) = SYC_get_ConfigId_Content_NOERROR( 'InitialCondition', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $initial_condition ) = SYC_get_ConfigId_Content( 'InitialCondition', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $initial_condition ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'InitialCondition' ] );
        return 0 unless $result;
    }

    $initial_condition =~ s/\s//g;

    unless ( $initial_condition eq 'PositionA' or $initial_condition eq 'PositionB' ) {
        S_set_error( "Content of ConfigID 'InitialCondition' for switch type '$switch_type' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SWITCH_get_InitialCondition returns initial condition '$initial_condition'.\n" );

    return ( 1, $initial_condition );
}

=head2 SYC_SWITCH_get_MeasurementMode

    ( $result , $measurement_mode) = SYC_SWITCH_get_MeasurementMode( $switch_name );

returns the configured measurement mode ('Current'|'Voltage') for the given switch '$switch_name' in the configured variant.

=cut

sub SYC_SWITCH_get_MeasurementMode {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_MeasurementMode( $switch_name )', @args );

    my $switch_name = shift @args;
    my $switch_type;
    my $measurement_mode;
    my $result;

    S_w2log( 3, "SYC_SWITCH_get_MeasurementMode called for switch_name '$switch_name' .\n" );
    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
        return 0 unless $result;

        ( $result, $measurement_mode ) = SYC_get_ConfigId_Content_NOERROR( 'MeasurementMode', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $measurement_mode ) = SYC_get_ConfigId_Content( 'MeasurementMode', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $measurement_mode ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'MeasurementMode' ] );
        return 0 unless $result;
    }

    if ( $measurement_mode =~ /current/ ) {
        $measurement_mode = "Current";
    }
    elsif ( $measurement_mode =~ /voltage/ ) {
        $measurement_mode = "Voltage";
    }

    S_w2log( 3, "SYC_SWITCH_get_type returns \$measurement_mode '$measurement_mode'.\n" );

    return ( 1, $measurement_mode );
}

=head2 SYC_SWITCH_get_RepetitionTime

    ( $result , $repetionTime_ms ) = SYC_SWITCH_get_RepetitionTime( );

returns the repetition time for the switch measurement ms.

=cut

sub SYC_SWITCH_get_RepetitionTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_RepetitionTime( )', @args );

    my ( $result, $repetionTime_ms );

    S_w2log( 3, "SYC_SWITCH_get_RepetitionTime called.\n" );

    ( $result, $repetionTime_ms ) = SYC_get_ConfigId_Content( 'RepetitionTime', ['Switches'] ) if ( SYC_getSycType() eq "doorsXML" );
    ( $result, $repetionTime_ms ) = SYC_get_ScipPM_Content( [ 'Switches', 'GeneralData', 'RepetitionTime_ms' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $repetionTime_ms =~ /([0-9]+)ms/ ) {
        $repetionTime_ms = $1;
    }

    S_w2log( 3, "SYC_SWITCH_get_RepetitionTime returns RepetitionTime '$repetionTime_ms'.\n" );

    return ( 1, $repetionTime_ms );
}

=head2 SYC_SWITCH_get_InitTime_ms

    ( $result , $initTime_ms ) = SYC_SWITCH_get_InitTime_ms( );

returns the time span between ECU start-up and when the first�measurement of switch input channel is finished.

=cut

sub SYC_SWITCH_get_InitTime_ms {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_InitTime_ms( )', @args );

    my ( $result, $initTime_ms );

    S_w2log( 3, "SYC_SWITCH_get_InitTime_ms called.\n" );

    ( $result, $initTime_ms ) = SYC_get_ConfigId_Content( 'SwitchInput_InitTime', ['Switches'] ) if ( SYC_getSycType() eq "doorsXML" );
    ( $result, $initTime_ms ) = SYC_get_ScipPM_Content( [ 'Switches', 'GeneralData', 'SwitchInput_InitTime_ms' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $initTime_ms =~ /([0-9]+)ms/ ) {
        $initTime_ms = $1;
    }

    S_w2log( 3, "SYC_SWITCH_get_InitTime_ms returns InitTime '$initTime_ms'.\n" );

    return ( 1, $initTime_ms );
}

=head2 SYC_get_switch_state

    ( $result , $state_value , $state_unit ) = SYC_get_switch_state( $switch_name , $state );

returns a value and unit for a given state '$state' of a switch '$switch_name' [depending on given variant].

=cut

sub SYC_SWITCH_get_state {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_state( $switch_name , $state )', @args );

    my $switch_name = shift @args;
    my $state       = shift @args;
    my ( $switch_type, $stateDefinition, $threshold_min, $threshold_max, $threshold_unit, $state_value, $result );

    S_w2log( 3, "SYC_SWITCH_get_state called for switch_name '$switch_name' and state '$state'.\n" );
    ( $result, $threshold_min, $threshold_max, $threshold_unit ) = SYC_SWITCH_get_state_thresholds( $switch_name, $state );
    return 0 unless $result;

    $state_value = ( $threshold_min + $threshold_max ) / 2;

    S_w2log( 3, "SYC_SWITCH_get_state returns state_value '$state_value', threshold_unit '$threshold_unit'.\n" );

    return ( 1, $state_value, $threshold_unit );
}

=head2 SYC_SWITCH_get_state_thresholds

    ( $result , $threshold_min , $threshold_max , $threshold_unit ) = SYC_SWITCH_get_state_thresholds( $switch_name , $state );

returns min, max threshold and the unit of the threshold for a given state '$state' of a switch '$switch_name' [depending on given variant].
    $state          =>  should be the state out of the switch type definitions of SYC document ( PositionA, PositionB, Short2Gnd, Undefined, OpenLine )
                        the suffix "Value" is not necessary
    $switch_name    =>  switch name as used in SYC
    
=cut

sub SYC_SWITCH_get_state_thresholds {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_state_thresholds( $switch_name , $state )', @args );

    my $switch_name = shift @args;
    my $state       = shift @args;
    my ( $threshold_min, $threshold_max, $threshold_unit, $result );
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SWITCH_get_state_thresholds called for switch_name '$switch_name' and state '$state'.\n" );

    ( $result, $threshold_min, $threshold_max, $threshold_unit ) = FuncLib_TNT_SYC_INTERFACE_doorsXML::SYC_SWITCH_get_state_thresholds( $switch_name, $state ) if ( SYC_getSycType() eq "doorsXML" );
    ( $result, $threshold_min, $threshold_max, $threshold_unit ) = FuncLib_TNT_SYC_INTERFACE_scipPM::SYC_SWITCH_get_state_thresholds( $switch_name, $state ) if ( SYC_getSycType() eq "scipPM" );

    S_w2log( $loglevel, "SYC_SWITCH_get_state_thresholds returns threshold_min '$threshold_min', threshold_max '$threshold_max', threshold_unit '$threshold_unit'.\n" ) if $result;

    return ( 1, $threshold_min, $threshold_max, $threshold_unit );
}

=head2 SYC_SWITCH_get_TestCurrent

    ( $result , $testCurrent_mA ) = SYC_SWITCH_get_TestCurrent( $switch_name );

returns the expected test current of a given switch 
    $switch_name    =>  switch name as used in SYC
    
=cut

sub SYC_SWITCH_get_TestCurrent {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_TestCurrent( $switch_name  )', @args );

    my $switch_name = shift @args;
    my ( $testCurrent_mA, $result, $switch_type, $supplyMode, $constantCurrent_mA );

    S_w2log( 3, "SYC_SWITCH_get_TestCurrent called for switch_name '$switch_name'.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
        return 0 unless $result;

        ( $result, $constantCurrent_mA ) = SYC_get_ConfigId_Content_NOERROR( 'ConstantCurrent', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $constantCurrent_mA ) = SYC_get_ConfigId_Content( 'ConstantCurrent', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $constantCurrent_mA ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'ConstantCurrent' ] );
        return 0 unless $result;
    }

    $constantCurrent_mA =~ s/\s//g;
    $constantCurrent_mA =~ s/,/./g;
    $constantCurrent_mA = $1 if ( $constantCurrent_mA =~ /I\=\D*([0-9]*\.?[0-9]+)/ );

    if ( $constantCurrent_mA eq "N/A" or $constantCurrent_mA == 0 ) {
        S_set_error( "'ConstantCurrent' is 'N/A' or 0, but SwitchType was used for switch '$switch_name'.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SWITCH_get_TestCurrent returns \$constantCurrent_mA '$constantCurrent_mA'.\n" );

    return ( 1, $constantCurrent_mA );
}

=head2 SYC_SWITCH_get_type

    ( $result , $switch_type ) = SYC_SWITCH_get_type( $switch_name );

returns the configured switch type for the given switch '$switch_name' in the configured variant.

=cut

sub SYC_SWITCH_get_type {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SWITCH_get_type( $switch_name )', @args );

    my $switch_name = shift @args;
    my $switch_type;
    my $switch_type_text;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SWITCH_get_type called for switch_name '$switch_name' .\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $switch_type ) = SYC_get_ConfigId_Content_NOERROR( 'SwitchType', [ 'Switch', $switch_name ] );
        ( $result, $switch_type ) = SYC_get_ConfigId_Content( 'SwitchType', [ 'Switch', ".*" . $switch_name . ".*" ] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $switch_type ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'SwitchType' ] );
        return 0 unless $result;
    }

    $switch_type_text = $switch_type;

    if ( $switch_type =~ /<(.*)>/ ) {
        $switch_type_text = $1;
    }

    S_w2log( $loglevel, "SYC_SWITCH_get_type returns switch_type '$switch_type_text'.\n" );

    return ( 1, $switch_type );
}

=head1 Function Group "FaultRecording"

=head2 SYC_FLT_get_BoschMemorySize

    ( $result , $boschMemorySize ) = SYC_FLT_get_BoschMemorySize( );

returns the number of faults which can be stored in Bosch fault recorder

=cut

sub SYC_FLT_get_BoschMemorySize {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_FLT_get_BoschMemorySize( )', @args );

    my ( $result, $boschMemorySize );

    S_w2log( 3, "SYC_FLT_get_BoschMemorySize called.\n" );
    ( $result, $boschMemorySize ) = SYC_get_ConfigId_Content( 'BoschMemorySize', ['FaultRecording'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $boschMemorySize ) = SYC_get_ScipPM_Content( [ 'FaultRecording', 'GeneralData', 'BoschMemorySize' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $boschMemorySize =~ /([0-9]+)/ ) {
        $boschMemorySize = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'BoschMemorySize' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_FLT_get_BoschMemorySize returns \$boschMemorySize '$boschMemorySize'.\n" );

    return ( 1, $boschMemorySize );
}

=head2 SYC_FLT_get_DemDisturbanceMemorySize

    ( $result , $demDisturbanceMemorySize ) = SYC_FLT_get_DemDisturbanceMemorySize( );

returns the number of faults which can be stored in Disturbance fault recorder

=cut

sub SYC_FLT_get_DemDisturbanceMemorySize {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_FLT_get_DemDisturbanceMemorySize( )', @args );

    my ( $result, $demDisturbanceMemorySize );

    S_w2log( 3, "SYC_FLT_get_DemDisturbanceMemorySize called.\n" );
    ( $result, $demDisturbanceMemorySize ) = SYC_get_ConfigId_Content( 'DemDisturbanceMemorySize', ['FaultRecording'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $demDisturbanceMemorySize ) = SYC_get_ScipPM_Content( [ 'FaultRecording', 'GeneralData', 'DemDisturbanceMemorySize' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $demDisturbanceMemorySize =~ /([0-9]+)/ ) {
        $demDisturbanceMemorySize = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'DemDisturbanceMemorySize' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_FLT_get_BoschMemorySize returns \$demDisturbanceMemorySize '$demDisturbanceMemorySize'.\n" );

    return ( 1, $demDisturbanceMemorySize );
}

=head2 SYC_FLT_get_DemMaxNumberEventEntryPrimary

    ( $result , $demMaxNumberEventEntryPrimary ) = SYC_FLT_get_DemMaxNumberEventEntryPrimary( );

returns the number of faults which can be stored in fault recorder

=cut

sub SYC_FLT_get_DemMaxNumberEventEntryPrimary {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_FLT_get_DemMaxNumberEventEntryPrimary( )', @args );

    my ( $result, $demMaxNumberEventEntryPrimary );

    S_w2log( 3, "SYC_FLT_get_DemBswErrorBufferSize called.\n" );
    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $demMaxNumberEventEntryPrimary ) = SYC_get_ConfigId_Content_NOERROR_NOHTML( 'DemBswErrorBufferSize', ['FaultRecording'] );
        ( $result, $demMaxNumberEventEntryPrimary ) = SYC_get_ConfigId_Content( 'DemMaxNumberEventEntryPrimary', ['FaultRecording'] ) unless $result;
        return 0 unless $result;
    }
    else {
        ( $result, $demMaxNumberEventEntryPrimary ) = SYC_get_ScipPM_Content( [ 'FaultRecording', 'GeneralData', 'DemMaxNumberEventEntryPrimary' ] );
        return 0 unless $result;
    }

    if ( $demMaxNumberEventEntryPrimary =~ /([0-9]+)/ ) {
        $demMaxNumberEventEntryPrimary = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'DemMaxNumberEventEntryPrimary' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_FLT_get_DemMaxNumberEventEntryPrimary returns \$demMaxNumberEventEntryPrimary '$demMaxNumberEventEntryPrimary'.\n" );

    return ( 1, $demMaxNumberEventEntryPrimary );
}

=head2 SYC_FLT_get_DemBswErrorBufferSize

    ( $result , $demBswErrorBufferSize ) = SYC_FLT_get_DemBswErrorBufferSize( );

returns the number of faults which can be stored in fault recorder

=cut

sub SYC_FLT_get_DemBswErrorBufferSize {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_FLT_get_DemBswErrorBufferSize( )', @args );

    my ( $result, $demBswErrorBufferSize );

    S_w2log( 3, "SYC_FLT_get_DemBswErrorBufferSize called.\n" );
    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $demBswErrorBufferSize ) = SYC_get_ConfigId_Content_NOERROR_NOHTML( 'DemMaxNumberEventEntryPrimary', ['FaultRecording'] );
        ( $result, $demBswErrorBufferSize ) = SYC_get_ConfigId_Content( 'DemBswErrorBufferSize', ['FaultRecording'] ) unless $result;
        return 0 unless $result;
    }
    else {
        S_set_error( "SYC_FLT_get_DemBswErrorBufferSize function is obsolete. Use SYC_FLT_get_DemMaxNumberEventEntryPrimary instead.", 20 );
        return 0;
    }

    if ( $demBswErrorBufferSize =~ /([0-9]+)/ ) {
        $demBswErrorBufferSize = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'DemBswErrorBufferSize' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_FLT_get_DemBswErrorBufferSize returns \$demBswErrorBufferSize '$demBswErrorBufferSize'.\n" );

    return ( 1, $demBswErrorBufferSize );
}

=head1 Function Group "EventDataRecorder"

=head2 SYC_EDR_get_Type

    ( $result , $type ) = SYC_EDR_get_Type( );

returns the type of the EventDataRecorder

=cut

sub SYC_EDR_get_Type {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_Type( )', @args );

    my ( $result, $type );

    S_w2log( 3, "SYC_EDR_get_Type called.\n" );
    ( $result, $type ) = SYC_get_ConfigId_Content( 'Type', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $type ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'Type' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $type =~ /(NHTSA|AKLV37)/ ) {
        $type = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'Type' is not in the expected format ('NHTSA' or 'AKLV37').", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_Type returns \$type '$type'.\n" );

    return ( 1, $type );
}

=head2 SYC_EDR_get_NumberOfEventsToBeStored

    ( $result , $numberOfEventsToBeStored ) = SYC_EDR_get_NumberOfEventsToBeStored( );

returns the number of events which can be stored in EDR

=cut

sub SYC_EDR_get_NumberOfEventsToBeStored {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_NumberOfEventsToBeStored( )', @args );

    my ( $result, $numberOfEventsToBeStored );

    S_w2log( 3, "SYC_EDR_get_NumberOfEventsToBeStored called.\n" );
    ( $result, $numberOfEventsToBeStored ) = SYC_get_ConfigId_Content( 'NumberOfEventsToBeStored', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $numberOfEventsToBeStored ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'NumberOfEventsToBeStored' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $numberOfEventsToBeStored =~ /([0-9]+)/ ) {
        $numberOfEventsToBeStored = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'NumberOfEventsToBeStored' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_NumberOfEventsToBeStored returns \$numberOfEventsToBeStored '$numberOfEventsToBeStored'.\n" );

    return ( 1, $numberOfEventsToBeStored );
}

=head2 SYC_EDR_get_NumberOfEventsToBeStoredPEP

    ( $result , $numberOfEventsToBeStoredPEP ) = SYC_EDR_get_NumberOfEventsToBeStoredPEP( );

returns the number of events which can be stored in PEP EDR
returns 0 if ConfigId 'NumberOfEventsToBeStoredPEP' is set to 'N/A' as PEP EDR is optional feature

=cut

sub SYC_EDR_get_NumberOfEventsToBeStoredPEP {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_NumberOfEventsToBeStoredPEP( )', @args );

    my ( $result, $numberOfEventsToBeStoredPEP );

    S_w2log( 3, "SYC_EDR_get_NumberOfEventsToBeStoredPEP called.\n" );
    ( $result, $numberOfEventsToBeStoredPEP ) = SYC_get_ConfigId_Content( 'NumberOfEventsToBeStoredPEP', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $numberOfEventsToBeStoredPEP ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'NumberOfEventsToBeStoredPEP' ] ) if SYC_getSycType() eq "scipPM";

    return 0 unless $result;

    if ( $numberOfEventsToBeStoredPEP =~ /([0-9]+)/ ) {
        $numberOfEventsToBeStoredPEP = $1;
    }
    elsif ( $numberOfEventsToBeStoredPEP eq 'N/A' ) {
        $numberOfEventsToBeStoredPEP = 0;
    }
    else {
        S_set_error( "Content of ConfigID 'NumberOfEventsToBeStoredPEP' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_NumberOfEventsToBeStoredPEP returns \$numberOfEventsToBeStoredPEP '$numberOfEventsToBeStoredPEP'.\n" );

    return ( 1, $numberOfEventsToBeStoredPEP );
}

=head2 SYC_EDR_get_ThresholdValueForInternalError

    ( $result , $thresholdForInternalError ) = SYC_EDR_get_ThresholdValueForInternalError( );

returns the threshold value of available unlocked records for an internal error

=cut

sub SYC_EDR_get_ThresholdValueForInternalError {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_ThresholdValueForInternalError( )', @args );

    my ( $result, $thresholdForInternalError );

    S_w2log( 3, "SYC_EDR_get_ThresholdValueForInternalError called.\n" );
    ( $result, $thresholdForInternalError ) = SYC_get_ConfigId_Content( 'ThresholdValueForInternalError', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $thresholdForInternalError ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'ThresholdValueForInternalError' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $thresholdForInternalError =~ /([0-9]+)/ ) {
        $thresholdForInternalError = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'ThresholdValueForInternalError' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_ThresholdValueForInternalError returns \$thresholdForInternalError '$thresholdForInternalError'.\n" );

    return ( 1, $thresholdForInternalError );
}

=head2 SYC_EDR_get_NumberOfParallelEvents

    ( $result , $numberOfParallelEvents ) = SYC_EDR_get_NumberOfParallelEvents( );

returns the number of records which can be captured in parallel

=cut

sub SYC_EDR_get_NumberOfParallelEvents {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_NumberOfParallelEvents( )', @args );

    my ( $result, $numberOfParallelEvents );

    S_w2log( 3, "SYC_EDR_get_NumberOfParallelEvents called.\n" );
    ( $result, $numberOfParallelEvents ) = SYC_get_ConfigId_Content( 'NumberOfParallelEvents', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $numberOfParallelEvents ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'NumberOfParallelEvents' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $numberOfParallelEvents =~ /([0-9]+)/ ) {
        $numberOfParallelEvents = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'NumberOfParallelEvents' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_NumberOfParallelEvents returns \$numberOfParallelEvents '$numberOfParallelEvents'.\n" );

    return ( 1, $numberOfParallelEvents );
}

=head2 SYC_EDR_get_CrashTelegramSize

    ( $result , $crashTelegramSize ) = SYC_EDR_get_CrashTelegramSize( );

returns the size of the crash telegram in byte

=cut

sub SYC_EDR_get_CrashTelegramSize {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_CrashTelegramSize( )', @args );

    my ( $result, $crashTelegramSize );

    S_w2log( 3, "SYC_EDR_get_CrashTelegramSize called.\n" );
    ( $result, $crashTelegramSize ) = SYC_get_ConfigId_Content( 'EDR_CT_SIZE', ['EventDataRecorder'] );
    return 0 unless $result;

    if ( $crashTelegramSize =~ /([0-9]+)/ ) {
        $crashTelegramSize = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_CT_SIZE' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_CrashTelegramSize returns \$crashTelegramSize '$crashTelegramSize'.\n" );

    return ( 1, $crashTelegramSize );
}

=head2 SYC_EDR_get_CrashTelegramInternalSize

    ( $result , $crashTelegramInternalSize ) = SYC_EDR_get_CrashTelegramInternalSize( );

returns the size of the internal crash telegram in byte

=cut

sub SYC_EDR_get_CrashTelegramInternalSize {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_CrashTelegramInternalSize( )', @args );

    my ( $result, $crashTelegramInternalSize );

    S_w2log( 3, "SYC_EDR_get_CrashTelegramInternalSize called.\n" );
    ( $result, $crashTelegramInternalSize ) = SYC_get_ConfigId_Content( 'EDR_CT_INTERNAL_SIZE', ['EventDataRecorder'] );
    return 0 unless $result;

    if ( $crashTelegramInternalSize =~ /([0-9]+)/ ) {
        $crashTelegramInternalSize = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_CT_INTERNAL_SIZE' is not in the expected format (integer).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_CrashTelegramInternalSize returns \$crashTelegramInternalSize '$crashTelegramInternalSize'.\n" );

    return ( 1, $crashTelegramInternalSize );
}

=head2 SYC_EDR_get_SpecialEvent

    ( $result , $specialEvent ) = SYC_EDR_get_SpecialEvent( );

returns the parallel handling of special events

=cut

sub SYC_EDR_get_SpecialEvent {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_SpecialEvent( )', @args );

    my ( $result, $specialEvent );

    S_w2log( 3, "SYC_EDR_get_SpecialEvent called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $specialEvent ) = SYC_get_ConfigId_Content( 'EDR_SPECIAL_EVENT', ['EventDataRecorder'] );
        return 0 unless $result;

        if ( $specialEvent =~ /(true|false)/ ) {
            $specialEvent = $1;
        }
        else {
            S_set_error( "Content of ConfigID 'EDR_SPECIAL_EVENT' is not in the expected format ('true' or 'false').", 20 );
            return 0;
        }
    }
    elsif ( SYC_getSycType() eq "scipPM" ) {
        ($result) = SYC_get_ConfigId_Content_NOERROR( 'EDR_SPECIAL_EVENT', ['EventDataRecorder'] );

        if ($result) {
            $specialEvent = "true";
        }
        else {
            $specialEvent = "false";
        }
    }

    S_w2log( 3, "SYC_EDR_get_SpecialEvent returns \$specialEvent '$specialEvent'.\n" );

    return ( 1, $specialEvent );
}

=head2 SYC_EDR_get_Architecture

    ( $result , $architecture ) = SYC_EDR_get_Architecture( );

returns the architecture of the EDR

=cut

sub SYC_EDR_get_Architecture {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_Architecture( )', @args );

    my ( $result, $architecture );

    S_w2log( 3, "SYC_EDR_get_Architecture called.\n" );
    ( $result, $architecture ) = SYC_get_ConfigId_Content( 'EDR_ARCHITECTURE', ['EventDataRecorder'] );
    return 0 unless $result;

    if ( $architecture =~ /(Central|MasterCentral|MasterOthers|MasterNoEDR)/ ) {
        $architecture = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_ARCHITECTURE' is not in the expected format ('Central', 'MasterCentral', 'MasterOthers, 'MasterNoEDR').", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_Architecture returns \$architecture '$architecture'.\n" );

    return ( 1, $architecture );
}

=head2 SYC_EDR_get_SpecialEventSet

    ( $result , $specialEventSet ) = SYC_EDR_get_SpecialEventSet( );

returns the events which are treated as special event

=cut

sub SYC_EDR_get_SpecialEventSet {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_SpecialEventSet( )', @args );

    my ( $result, $specialEventSet );

    S_w2log( 3, "SYC_EDR_get_SpecialEventSet called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $specialEventSet ) = SYC_get_ConfigId_Content( 'EDR_SPECIAL_EVENT_SET', ['EventDataRecorder'] );
        return 0 unless $result;
    }
    elsif ( SYC_getSycType() eq "scipPM" ) {
        ($result) = SYC_get_ConfigId_Content_NOERROR( 'EDR_SPECIAL_EVENT_SET', ['EventDataRecorder'] );

        if ($result) {
            $specialEventSet = "true";
        }
        else {
            $specialEventSet = "false";
        }
    }

    S_w2log( 3, "SYC_EDR_get_SpecialEventSet returns \$specialEventSet '$specialEventSet'.\n" );

    return ( 1, $specialEventSet );
}

=head2 SYC_EDR_get_AllowOnlineDiag

    ( $result , $allowOnlineDiag ) = SYC_EDR_get_AllowOnlineDiag( );

returns the events which are treated as special event

=cut

sub SYC_EDR_get_AllowOnlineDiag {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_AllowOnlineDiag( )', @args );

    my ( $result, $allowOnlineDiag );

    S_w2log( 3, "SYC_EDR_get_AllowOnlineDiag called.\n" );

    ( $result, $allowOnlineDiag ) = SYC_get_ConfigId_Content( 'EDR_ALLOW_ONLINE_DIAG', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $allowOnlineDiag ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'EDR_ALLOW_ONLINE_DIAG' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $allowOnlineDiag =~ /(true|false)/ ) {
        $allowOnlineDiag = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_ALLOW_ONLINE_DIAG' is not in the expected format ('true' or 'false').", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_AllowOnlineDiag returns \$allowOnlineDiag '$allowOnlineDiag'.\n" );

    return ( 1, $allowOnlineDiag );
}

=head2 SYC_EDR_get_EnableExtendedEvent

    ( $result , $enableExtendedEvent ) = SYC_EDR_get_EnableExtendedEvent( );

returns whether extended event is enabled

=cut

sub SYC_EDR_get_EnableExtendedEvent {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_EnableExtendedEvent( )', @args );

    my ( $result, $enableExtendedEvent );

    S_w2log( 3, "SYC_EDR_get_EnableExtendedEvent called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $enableExtendedEvent ) = SYC_get_ConfigId_Content( 'EDR_ENABLE_EXT_EV', ['EventDataRecorder'] );
        return 0 unless $result;

        if ( $enableExtendedEvent =~ /(true|false)/ ) {
            $enableExtendedEvent = $1;
        }
        else {
            S_set_error( "Content of ConfigID 'EDR_ENABLE_EXT_EV' is not in the expected format ('true' or 'false').", 20 );
            return 0;
        }
    }
    elsif ( SYC_getSycType() eq "scipPM" ) {
        ($result) = SYC_get_ConfigId_Content_NOERROR( 'EDR_ENABLE_EXT_EV', ['EventDataRecorder'] );

        if ($result) {
            $enableExtendedEvent = "true";
        }
        else {
            $enableExtendedEvent = "false";
        }
    }

    S_w2log( 3, "SYC_EDR_get_EnableExtendedEvent returns \$enableExtendedEvent '$enableExtendedEvent'.\n" );

    return ( 1, $enableExtendedEvent );
}

=head2 SYC_EDR_get_TriggerThresholdSpeed

    ( $result , $triggerThresholdSpeed ) = SYC_EDR_get_TriggerThresholdSpeed( );

returns the trigger threshold for storage in kmph

=cut

sub SYC_EDR_get_TriggerThresholdSpeed {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_TriggerThresholdSpeed( )', @args );

    my ( $result, $triggerThresholdSpeed );

    S_w2log( 3, "SYC_EDR_get_TriggerThresholdSpeed called.\n" );
    ( $result, $triggerThresholdSpeed ) = SYC_get_ConfigId_Content( 'EDR_TRIGGER_THRESHOLD_SPEED', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $triggerThresholdSpeed ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'EDR_TRIGGER_THRESHOLD_SPEED' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $triggerThresholdSpeed =~ s/\s//g;    # remove white spaces
    $triggerThresholdSpeed =~ s/,/./g;    # replace ',' with '.'

    if ( $triggerThresholdSpeed =~ /([0-9]+)kmh/ ) {
        $triggerThresholdSpeed = $1;
    }
    elsif ( $triggerThresholdSpeed =~ /([0-9]+)kmph/ ) {
        $triggerThresholdSpeed = $1;
    }
    elsif ( $triggerThresholdSpeed =~ /([0-9]+)km\/h/ ) {
        $triggerThresholdSpeed = $1;
    }
    elsif ( $triggerThresholdSpeed =~ /([0-9]+)/ ) {
        $triggerThresholdSpeed = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_TRIGGER_THRESHOLD_SPEED' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_TriggerThresholdSpeed returns \$triggerThresholdSpeed '$triggerThresholdSpeed' kmph.\n" );

    return ( 1, $triggerThresholdSpeed );
}

=head2 SYC_EDR_get_TriggerThresholdTime

    ( $result , $triggerThresholdTime ) = SYC_EDR_get_TriggerThresholdTime( );

returns the trigger threshold time window for storage

=cut

sub SYC_EDR_get_TriggerThresholdTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_TriggerThresholdTime( )', @args );

    my ( $result, $triggerThresholdTime );

    S_w2log( 3, "SYC_EDR_get_TriggerThresholdTime called.\n" );
    ( $result, $triggerThresholdTime ) = SYC_get_ConfigId_Content( 'EDR_TRIGGER_THRESHOLD_TIME', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $triggerThresholdTime ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'EDR_TRIGGER_THRESHOLD_TIME' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $triggerThresholdTime =~ s/\s//g;    # remove white spaces
    $triggerThresholdTime =~ s/,/./g;    # replace ',' with '.'

    if ( $triggerThresholdTime =~ /([0-9]+)ms/ ) {
        $triggerThresholdTime = $1;      # kmph
    }
    elsif ( $triggerThresholdTime =~ /([0-9]+)/ ) {
        $triggerThresholdTime = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_TRIGGER_THRESHOLD_TIME' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_TriggerThresholdTime returns \$triggerThresholdTime '$triggerThresholdTime' ms.\n" );

    return ( 1, $triggerThresholdTime );
}

=head2 SYC_EDR_get_UnlockRecord

    ( $result , $unlockRecord ) = SYC_EDR_get_UnlockRecord( );

returns whether unlocking of records is possible with CD or not

=cut

sub SYC_EDR_get_UnlockRecord {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_UnlockRecord( )', @args );

    my ( $result, $unlockRecord );

    S_w2log( 3, "SYC_EDR_get_UnlockRecord called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $unlockRecord ) = SYC_get_ConfigId_Content( 'EDR_UNLOCK_RECORD', ['EventDataRecorder'] );
        return 0 unless $result;

        if ( $unlockRecord =~ /(true|false)/ ) {
            $unlockRecord = $1;
        }
        else {
            S_set_error( "Content of ConfigID 'EDR_UNLOCK_RECORD' is not in the expected format ('true' or 'false').", 20 );
            return 0;
        }
    }
    elsif ( SYC_getSycType() eq "scipPM" ) {
        ($result) = SYC_get_ConfigId_Content_NOERROR( 'EDR_UNLOCK_RECORD', ['EventDataRecorder'] );

        if ($result) {
            $unlockRecord = "true";
        }
        else {
            $unlockRecord = "false";
        }
    }
    S_w2log( 3, "SYC_EDR_get_UnlockRecord returns \$unlockRecord '$unlockRecord'.\n" );

    return ( 1, $unlockRecord );
}

=head2 SYC_EDR_get_EventRecordingPriority

    ( $result , $eventRecordingPriority_aref ) = SYC_EDR_get_EventRecordingPriority( );

returns the storage priority of events

=cut

sub SYC_EDR_get_EventRecordingPriority {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_EventRecordingPriority( )', @args );

    my ( $result, $eventRecordingPriority_aref );

    S_w2log( 3, "SYC_EDR_get_EventRecordingPriority called.\n" );
    ( $result, $eventRecordingPriority_aref ) = SYC_get_ConfigId_Content( 'EDR_EVENT_REC_PRIORITY', ['EventDataRecorder'] );
    return 0 unless $result;

    $eventRecordingPriority_aref =~ s/\s//g;    # remove white spaces
    $eventRecordingPriority_aref =~ s/{//g;     # remove curly brackets
    $eventRecordingPriority_aref =~ s/}//g;     # remove curly brackets

    my @eventPriorityArray = split( /,/, $eventRecordingPriority_aref );
    $eventRecordingPriority_aref = \@eventPriorityArray;

    S_w2log( 3, "SYC_EDR_get_EventRecordingPriority returns \$eventRecordingPriority_aref '$eventRecordingPriority_aref'.\n" );

    return ( 1, $eventRecordingPriority_aref );
}

=head2 SYC_EDR_get_DiagInMotion

    ( $result , $diagInMotion ) = SYC_EDR_get_DiagInMotion( );

returns whether EDR diagnosis functions are enabled when vehicle is moving

=cut

sub SYC_EDR_get_DiagInMotion {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_DiagInMotion( )', @args );

    my ( $result, $diagInMotion );

    S_w2log( 3, "SYC_EDR_get_DiagInMotion called.\n" );

    if ( SYC_getSycType() eq "doorsXML" ) {
        ( $result, $diagInMotion ) = SYC_get_ConfigId_Content( 'EDR_DIAG_IN_MOTION', ['EventDataRecorder'] );
        return 0 unless $result;

        if ( $diagInMotion =~ /(true|false)/ ) {
            $diagInMotion = $1;
        }
        else {
            S_set_error( "Content of ConfigID 'EDR_DIAG_IN_MOTION' is not in the expected format ('true' or 'false').", 20 );
            return 0;
        }
    }
    elsif ( SYC_getSycType() eq "scipPM" ) {
        ($result) = SYC_get_ConfigId_Content_NOERROR( 'EDR_DIAG_IN_MOTION', ['EventDataRecorder'] );

        if ($result) {
            $diagInMotion = "true";
        }
        else {
            $diagInMotion = "false";
        }
    }

    S_w2log( 3, "SYC_EDR_get_DiagInMotion returns \$diagInMotion '$diagInMotion'.\n" );

    return ( 1, $diagInMotion );
}

=head2 SYC_EDR_get_MultiEventHandling

    ( $result , $meHandlingOption ) = SYC_EDR_get_MultiEventHandling( );

returns whether EDR diagnosis functions are enabled when vehicle is moving

=cut

sub SYC_EDR_get_MultiEventHandling {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_MultiEventHandling( )', @args );

    my ( $result, $meHandlingOption );

    S_w2log( 3, "SYC_EDR_get_MultiEventHandling called.\n" );
    ( $result, $meHandlingOption ) = SYC_get_ConfigId_Content( 'EDR_ME_HANDLING', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $meHandlingOption ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'EDR_ME_HANDLING' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $meHandlingOption =~ /(EDR_MEHandlingType_Discard|EDR_MEHandlingType_Drop|EDR_MEHandlingType_Extend)/ ) {
        $meHandlingOption = $1;
    }
    elsif ( $meHandlingOption =~ /(Discard|Drop|Extend)/ ) {
        $meHandlingOption = 'EDR_MEHandlingType_' . $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_ME_HANDLING' is not in the expected format ('EDR_MEHandlingType_Discard' or 'EDR_MEHandlingType_Drop' or 'EDR_MEHandlingType_Extend').", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_MultiEventHandling returns \$meHandlingOption '$meHandlingOption'.\n" );

    return ( 1, $meHandlingOption );
}

=head2 SYC_EDR_get_SectionCRC

    ( $result , $diagInMotion ) = SYC_EDR_get_SectionCRC( );

returns whether calculation for each EDR section is enabled

=cut

sub SYC_EDR_get_SectionCRC {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_EDR_get_SectionCRC( )', @args );

    my ( $result, $sectionCRC );

    S_w2log( 3, "SYC_EDR_get_SectionCRC called.\n" );

    ( $result, $sectionCRC ) = SYC_get_ConfigId_Content( 'EDR_SECTION_CRC', ['EventDataRecorder'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $sectionCRC ) = SYC_get_ScipPM_Content( [ 'EDR', 'GeneralData', 'EDR_SECTION_CRC' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    if ( $sectionCRC =~ /(true|false)/ ) {
        $sectionCRC = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'EDR_SECTION_CRC' is not in the expected format ('true' or 'false').", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_EDR_get_SectionCRC returns \$sectionCRC '$sectionCRC'.\n" );

    return ( 1, $sectionCRC );
}

=head1 Function Group "LIN"

All functions to access SYC, which are currently supported for LIN.

= cut

=head2 SYC_LIN_get_FirstCommunicationTime

    ( $result , $firstCommunicationTime_ms ) = SYC_LIN_get_FirstCommunicationTime( );

returns the FirstCommunicationTime on LIN Bus in ms.

=cut

sub SYC_LIN_get_FirstCommunicationTime {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_LIN_get_FirstCommunicationTime( )', @args );

    my ( $result, $firstCommunicationTime_ms );

    S_w2log( 3, "SYC_LIN_get_FirstCommunicationTime called.\n" );
    ( $result, $firstCommunicationTime_ms ) = SYC_get_ConfigId_Content( 'FirstCommunicationTime',  ['Lin'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $firstCommunicationTime_ms ) = SYC_get_ConfigId_Content( 'FirstCommunication_Time', ['Lin'] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    $firstCommunicationTime_ms =~ s/\s//g;

    if ( $firstCommunicationTime_ms =~ /([0-9]*)ms/ ) {
        $firstCommunicationTime_ms = $1;
    }
    elsif ( $firstCommunicationTime_ms =~ /([0-9]*)/ ) {
        $firstCommunicationTime_ms = $1;
    }
    else {
        S_set_error( "Content of ConfigID 'FirstCommunicationTime' for LIN is not in the expected format.", 20 );
        return 0;
    }

    if ( $firstCommunicationTime_ms > 500 || $firstCommunicationTime_ms < 120 ) {
        S_set_error( "Content of ConfigID 'FirstCommunicationTime' for LIN is out of expected range (120 <= X <= 500).", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_LIN_get_FirstCommunicationTime returns \$firstCommunicationTime_ms '$firstCommunicationTime_ms'.\n" );

    return ( 1, $firstCommunicationTime_ms );
}

=head1 Function Group "SystemAsics"

All functions to access SYC, which are currently supported for system asics.

=head2 SYC_SYSTEMASIC_get_MasterAsicType

   ( $result , $master_asic_type ) = SYC_SYSTEMASIC_get_MasterAsicType( );

returns the tpye of master asic which is used in the current variant.

=cut

sub SYC_SYSTEMASIC_get_MasterAsicType {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SYSTEMASIC_get_MasterAsicType( )', @args );

    my ( $result, $master_asic_type );

    S_w2log( 3, "SYC_SYSTEMASIC_get_MasterAsicType called.\n" );
    ( $result, $master_asic_type ) = SYC_get_ConfigId_Content( 'Master', ['SystemAsics'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $master_asic_type ) = SYC_get_ScipPM_Content( [ 'ASICs', 'DeviceData', 'MasterAsicType' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( 3, "SYC_SYSTEMASIC_get_MasterAsicType returns \$master_asic_type '$master_asic_type'.\n" );

    return ( 1, $master_asic_type );
}

=head2 SYC_SYSTEMASIC_get_Slave1AsicType

   ( $result , $slave1_asic_type ) = SYC_SYSTEMASIC_get_Slave1AsicType( );

returns the tpye of slave1 asic which is used in the current variant.

=cut

sub SYC_SYSTEMASIC_get_Slave1AsicType {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SYSTEMASIC_get_Slave1AsicType( )', @args );

    my ( $result, $slave1_asic_type );

    S_w2log( 3, "SYC_SYSTEMASIC_get_Slave1AsicType called.\n" );
    ( $result, $slave1_asic_type ) = SYC_get_ConfigId_Content( 'Slave1', ['SystemAsics'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $slave1_asic_type ) = SYC_get_ScipPM_Content( [ 'ASICs', 'DeviceData', 'Slave1AsicType' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( 3, "SYC_SYSTEMASIC_get_Slave1AsicType returns \$slave1_asic_type '$slave1_asic_type'.\n" );

    return ( 1, $slave1_asic_type );
}

=head2 SYC_SYSTEMASIC_get_Slave2AsicType

   ( $result , $slave2_asic_type ) = SYC_SYSTEMASIC_get_Slave2AsicType( );

returns the tpye of slave2 asic which is used in the current variant.

=cut

sub SYC_SYSTEMASIC_get_Slave2AsicType {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_SYSTEMASIC_get_Slave2AsicType( )', @args );

    my ( $result, $slave2_asic_type );

    S_w2log( 3, "SYC_SYSTEMASIC_get_Slave2AsicType called.\n" );
    ( $result, $slave2_asic_type ) = SYC_get_ConfigId_Content( 'Slave2', ['SystemAsics'] ) if SYC_getSycType() eq "doorsXML";
    ( $result, $slave2_asic_type ) = SYC_get_ScipPM_Content( [ 'ASICs', 'DeviceData', 'Slave2AsicType' ] ) if SYC_getSycType() eq "scipPM";
    return 0 unless $result;

    S_w2log( 3, "SYC_SYSTEMASIC_get_Slave2AsicType returns \$slave2_asic_type '$slave2_asic_type'.\n" );

    return ( 1, $slave2_asic_type );
}

=head1 not exported functions

=head2 CalculateResistance

    CalculateResistance( $voltage_V , $current_A);

Calculate resistance from given voltage and current.
 
=cut

sub CalculateResistance {
    my $voltage_V = shift;
    my $current_A = shift;
    my $resistance_Omh;

    S_w2log( 4, "CalculateResistance called for voltage_V '$voltage_V' and current_A '$current_A' ...\n" );

    $resistance_Omh = $voltage_V / $current_A if ( $current_A > 0 );

    S_w2log( 4, "CalculateResistance returns resistance_Omh '$resistance_Omh'...\n" );

    return $resistance_Omh;
}

############################################################################################################
#
#
# package FuncLib_TNT_SYC_INTERFACE_doorsXML
#
#
############################################################################################################

package FuncLib_TNT_SYC_INTERFACE_doorsXML;

use strict;
use warnings;
use LIFT_general;
use FuncLib_SYC_INTERFACE;

sub SYC_POWERSUPPLY_get_ReverseVoltageTestConditions {
    my @args = @_;
    return 0
      unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_ReverseVoltageTestConditions( )', @args );

    my ( $result, $ubat_RVT, $duration_RVT, $temperature_RVT, $condition_RVT );

    S_w2log( 3, "SYC_POWERSUPPLY_get_ReverseVoltageTestConditions called.\n" );
    ( $result, $condition_RVT ) = SYC_get_ConfigId_Content( 'ReverseVoltageTest', ['PowerSupply'] );
    return 0 unless $result;

    $condition_RVT =~ s/\s//g;
    $condition_RVT =~ s/,/./g;

    if ( $condition_RVT =~ /\-([0-9]*\.?[0-9]+)V\/([0-9]*\.?[0-9]+)min\/Tamb=(\-*[0-9]*\.?[0-9]+)�/ ) {
        $ubat_RVT        = $1;
        $duration_RVT    = $2;
        $temperature_RVT = $3;
    }
    else {
        S_set_error( "Content of ConfigID 'ReverseVoltageTest' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_POWERSUPPLY_get_ReverseVoltageTestConditions returns ubat '$ubat_RVT', duration '$duration_RVT', temperature '$temperature_RVT'.\n" );

    return ( 1, $ubat_RVT, $duration_RVT, $temperature_RVT );
}

sub SYC_SQUIB_get_ASIC_connection {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ASIC_connection( $squib_name )', @args );

    my $squib_name = shift @args;

    my ( $result, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL, $calc_array_idx );

    ( $result, $asic_connection ) = SYC_get_ConfigId_Content_NOERROR( 'AsicConnection', [ 'Actuator', $squib_name ] );
    ( $result, $asic_connection ) = SYC_get_ConfigId_Content( 'AsicConnection', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
    return 0 unless $result;

    # CBR1_IGH1-IGL1
    if ( $asic_connection =~ /CBR(\d+)_IGH(\d+)-IGL(\d+)/ ) {
        $asic_connectionCBR = $1;
        $asic_connectionIGH = $2;
        $asic_connectionIGL = $3;

        $calc_array_idx = ( $asic_connectionCBR - 1 ) * 16 + ( $asic_connectionIGH - 1 );

        unless ( $asic_connectionIGH == $asic_connectionIGL ) {
            S_set_warning("asic_connectionIGH '$asic_connectionIGH' is different from asic_connectionIGL '$asic_connectionIGL'");
        }
    }
    else {
        S_set_error( "Content of ConfigID 'AsicConnection' for squib '$squib_name' is not in the expected format.", 20 );
        return 0;
    }

    return ( 1, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionIGH, $asic_connectionIGL );
}

sub SYC_SQUIB_get_firing_mode {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_firing_mode( $squib_name )', @args );

    my $squib_name = shift @args;
    my $firing_mode;
    my $result;
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_firing_mode called for squib_name '$squib_name' .\n" );

    ( $result, $firing_mode ) = SYC_get_ConfigId_Content_NOERROR_NOHTML( 'FiringMode', [ 'Actuator', $squib_name ] );
    ( $result, $firing_mode ) = SYC_get_ConfigId_Content( 'FiringMode', [ 'Actuator', ".*" . $squib_name . ".*" ] ) unless $result;
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_SQUIB_get_firing_mode returns firing_mode '$firing_mode'.\n" );

    return ( 1, $firing_mode );
}

sub SYC_SWITCH_get_ASIC_connection {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SWITCH_get_ASIC_connection( $switch_name )', @args );

    my $switch_name = shift @args;

    my ( $result, $asic_connection, $asic_connectionCBR, $asic_connectionA_MEAS, $calc_array_idx );

    S_w2log( 3, "SYC_SWITCH_get_ASIC_connection called for switch_name '$switch_name'.\n" );
    ( $result, $asic_connection ) = SYC_get_ConfigId_Content_NOERROR( 'AsicConnection', [ 'Switch', $switch_name ] );
    ( $result, $asic_connection ) = SYC_get_ConfigId_Content( 'AsicConnection', [ 'Switch', ".*" . $switch_name . ".*" ] ) unless $result;
    return 0 unless $result;

    if ( $asic_connection =~ /A_MEAS(\d+)_CBR(\d+)/ ) {
        $asic_connectionA_MEAS = $1;
        $asic_connectionCBR    = $2;

        $calc_array_idx = ( $asic_connectionCBR - 1 ) * 16 + ( $asic_connectionA_MEAS - 1 );
    }
    else {
        S_set_error( "Content of ConfigID 'AsicConnection' for switch '$switch_name' is not in the expected format.", 20 );
        return 0;
    }

    S_w2log( 3, "SYC_SWITCH_get_ASIC_connection asic_connection '$asic_connection' , CBR '$asic_connectionCBR' , A_MEAS '$asic_connectionA_MEAS' , array index '$calc_array_idx'.\n" );

    return ( 1, $calc_array_idx, $asic_connection, $asic_connectionCBR, $asic_connectionA_MEAS );
}

sub SYC_SWITCH_get_state_thresholds {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SWITCH_get_state_thresholds( $switch_name, $state )', @args );

    my $switch_name = shift @args;
    my $state       = shift @args;
    my ( $switch_type, $stateDefinition, $threshold_min, $threshold_max, $threshold_unit, $supplyMode, $constantCurrent_mA, $result );

    ( $result, $switch_type ) = SYC_SWITCH_get_type($switch_name);
    return 0 unless $result;

    ( $result, $stateDefinition ) = SYC_get_ConfigId_Content_NOERROR( $state, [ 'SwitchTypeDefinition', $switch_type ] );
    ( $result, $stateDefinition ) = SYC_get_ConfigId_Content_NOERROR( $state, [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
    ( $result, $stateDefinition ) = SYC_get_ConfigId_Content_NOERROR( $state . "Value", [ 'SwitchTypeDefinition', $switch_type ] ) unless $result;
    ( $result, $stateDefinition ) = SYC_get_ConfigId_Content( $state . "Value", [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
    return 0 unless $result;

    $stateDefinition =~ s/\s//g;
    $stateDefinition =~ s/,/./g;

    if ( $stateDefinition eq "N/A" ) {
        S_set_error( "Content of state '$state' for switch type '$switch_type' is 'N/A', but SwitchType was used for switch '$switch_name'.", 20 );
        return 0;
    }

    # get min and if possible max value from stateDefinition
    elsif ( $stateDefinition =~ /([0-9]*\.?[0-9]+)<.*([URI])<\D*([0-9]*\.?[0-9]+)/ ) {
        $threshold_min  = $1;
        $threshold_unit = $2;
        $threshold_max  = $3;
    }
    elsif ( $stateDefinition =~ /([0-9]*\.?[0-9]+)<.*([URI])<.*(max)/ ) {
        $threshold_min  = $1;
        $threshold_unit = $2;
    }
    elsif ( $stateDefinition =~ /([URI])<\D*([0-9]*\.?[0-9]+)/ ) {
        $threshold_min  = 0;
        $threshold_unit = $1;
        $threshold_max  = $2;
    }
    elsif ( $stateDefinition =~ /([URI])>\D*([0-9]*\.?[0-9]+)/ ) {
        $threshold_unit = $1;
        $threshold_min  = $2;
    }
    else {
        S_set_error( "Content of state '$state' for switch type '$switch_type' does not contain thresholds.", 20 );
        return 0;
    }

    # add maximum values depending on SupplyMode (values taken from SYC Range definition, but they are depending on SupplyMode)
    unless ( defined $threshold_max ) {
        ( $result, $supplyMode ) = SYC_get_ConfigId_Content_NOERROR( 'SupplyMode', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $supplyMode ) = SYC_get_ConfigId_Content( 'SupplyMode', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;

        # supply mode "constant current (Vup)" and Unit "R"
        if ( $supplyMode =~ /Vup/ and $threshold_unit =~ /R/i ) {
            $threshold_max = 10000;
        }

        # supply mode "constant current (VAS)" or all other supply modes and Unit "R"
        # the smaller of the two known thresholds in default case
        elsif ( $threshold_unit =~ /R/i ) {
            $threshold_max = 1250;
        }

        # supply mode "constant current (Vup)" and Unit "U"
        elsif ( $supplyMode =~ /Vup/ and $threshold_unit =~ /U/i ) {
            $threshold_max = 30;
        }

        # supply mode "constant current (VAS)" or all other supply modes and Unit "U"
        # the smaller of the two known thresholds in default case
        elsif ( $threshold_unit =~ /U/i ) {
            $threshold_max = 7;
        }

        # Unit "I", only supply mode "constant current (VAS)" allowed
        elsif ( $threshold_unit =~ /I/i ) {
            $threshold_max = 30;
        }
    }

    # for mechanical switches, calculate resistance from given U and current from SYC
    if ( $threshold_unit =~ /U/i ) {
        S_w2log( 5, "SYC_SWITCH_get_state_thresholds - unit is 'U', recalculation of 'R' necessary.\n" );
        S_w2log( 5, "SYC_SWITCH_get_state_thresholds - before recalculation threshold_min '$threshold_min', threshold_max '$threshold_max', threshold_unit '$threshold_unit'.\n" );
        S_w2log( 5, "SYC_SWITCH_get_state_thresholds - get ConfigId 'ConstantCurrent' for switch_type '$switch_type'.\n" );

        ( $result, $constantCurrent_mA ) = SYC_get_ConfigId_Content_NOERROR( 'ConstantCurrent', [ 'SwitchTypeDefinition', $switch_type ] );
        ( $result, $constantCurrent_mA ) = SYC_get_ConfigId_Content( 'ConstantCurrent', [ 'SwitchTypeDefinition', '<' . $switch_type . '>' ] ) unless $result;
        return 0 unless $result;

        $constantCurrent_mA =~ s/\s//g;
        $constantCurrent_mA =~ s/,/./g;
        $constantCurrent_mA = $1 if ( $constantCurrent_mA =~ /I\=\D*([0-9]*\.?[0-9]+)/ );

        if ( $constantCurrent_mA eq "N/A" or $constantCurrent_mA == 0 ) {
            S_set_error( "'ConstantCurrent' for '$switch_type' is 'N/A' or 0, but SwitchType was used for switch '$switch_name'.", 20 );
            return 0;
        }

        # threshold_R = threshold_U / current
        $threshold_max = FuncLib_TNT_SYC_INTERFACE::CalculateResistance( $threshold_max, $constantCurrent_mA / 1000 );
        $threshold_min = FuncLib_TNT_SYC_INTERFACE::CalculateResistance( $threshold_min, $constantCurrent_mA / 1000 );
        $threshold_unit = "R";
    }

    return ( 1, $threshold_min, $threshold_max, $threshold_unit );
}

############################################################################################################
#
#
# package FuncLib_TNT_SYC_INTERFACE_scipPM
#
#
############################################################################################################

package FuncLib_TNT_SYC_INTERFACE_scipPM;

use strict;
use warnings;
use LIFT_general;
use FuncLib_SYC_INTERFACE;

sub SYC_POWERSUPPLY_get_ReverseVoltageTestConditions {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_POWERSUPPLY_get_ReverseVoltageTestConditions( )', @args );

    my ( $result, $ubat_RVT, $duration_RVT, $temperature_RVT );

    S_w2log( 3, "SYC_POWERSUPPLY_get_ReverseVoltageTestConditions called.\n" );
    ( $result, $ubat_RVT ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'ReverseVoltageTest_voltage_V' ] );
    return 0 unless $result;
    ( $result, $duration_RVT ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'ReverseVoltageTest_duration_s' ] );
    return 0 unless $result;
    ( $result, $temperature_RVT ) = SYC_get_ScipPM_Content( [ 'PowerSupply', 'GeneralData', 'ReverseVoltageTest_temperature_C' ] );
    return 0 unless $result;

    S_w2log( 3, "SYC_POWERSUPPLY_get_ReverseVoltageTestConditions returns ubat '$ubat_RVT', duration '$duration_RVT', temperature '$temperature_RVT'.\n" );

    return ( 1, $ubat_RVT, $duration_RVT, $temperature_RVT );
}

sub SYC_SQUIB_get_ASIC_connection {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_ASIC_connection( $squib_name )', @args );

    my $squib_name = shift @args;

    my ( $result, $asicNo, $loopNo, $asic_connection, $calc_array_idx );
    ( $result, $asicNo ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'asicNo' ] );
    return 0 unless $result;
    ( $result, $loopNo ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'loopNo' ] );
    return 0 unless $result;

    $calc_array_idx = ( $asicNo - 1 ) * 16 + ( $loopNo - 1 );

    $asic_connection = "CBR" . $asicNo . "_IGH" . $loopNo . "-IGL" . $loopNo;

    return ( 1, $calc_array_idx, $asic_connection, $asicNo, $loopNo, $loopNo );
}

sub SYC_SQUIB_get_firing_mode {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SQUIB_get_firing_mode( $squib_name )', @args );

    my $squib_name = shift @args;
    my $firing_mode;
    my ( $result, $squib_type );
    my $loglevel = SYC_getLogLevel();

    S_w2log( $loglevel, "SYC_SQUIB_get_firing_mode called for squib_name '$squib_name' .\n" );

    ( $result, $firing_mode ) = SYC_get_ScipPM_Content( [ 'Actuators', 'DeviceData', $squib_name, 'firingMode' ] );
    return 0 unless $result;

    S_w2log( $loglevel, "SYC_SQUIB_get_firing_mode returns firing_mode '$firing_mode'.\n" );

    return ( 1, $firing_mode );
}

sub SYC_SWITCH_get_ASIC_connection {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SWITCH_get_ASIC_connection( $switch_name )', @args );

    my $switch_name = shift @args;

    my ( $result, $asicNo, $loopNo, $asic_connection, $calc_array_idx );
    ( $result, $asicNo ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'asicNo' ] );
    return 0 unless $result;
    ( $result, $loopNo ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, 'loopNo' ] );
    return 0 unless $result;

    $calc_array_idx = ( $asicNo - 1 ) * 16 + ( $loopNo - 1 );

    $asic_connection = "A_MEAS" . $loopNo . "_CBR" . $asicNo;

    S_w2log( 3, "SYC_SWITCH_get_ASIC_connection asic_connection '$asic_connection' , CBR '$asicNo' , A_MEAS '$loopNo' , array index '$calc_array_idx'.\n" );

    return ( 1, $calc_array_idx, $asic_connection, $asicNo, $loopNo );
}

sub SYC_SWITCH_get_state_thresholds {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SYC_SWITCH_get_state_thresholds( $switch_name, $state )', @args );

    my $switch_name = shift @args;
    my $state       = shift @args;
    my ( $switch_type, $type, $stateDefinition, $threshold, $threshold_min, $threshold_max, $threshold_unit, $supplyMode, $constantCurrent_mA, $result, $maxMeasurementLimit, $thresholdType, $threshold_A_Below_B );

    my $stateMapping_href = {
        'Short2Gnd' => 'Short2GndValue',
        'OpenLine'  => 'OpenLineValue',
        'Undefined' => 'UndefinedValue',
    };
    my $unitMapping_href = {
        'Hall Switch'             => 'I',
        'Resistive Switch'        => 'R',
        'Mechanical Switch'       => 'R',
        'External voltage switch' => 'R',
    };

    my $opposingStateMapping_href = {
        "PositionA" => "PositionB",
        "PositionB" => "PositionA",
    };

    ( $result, $type ) = SYC_SWITCH_get_type($switch_name);
    return 0 unless $result;

    if ( $type eq "Bus Switch" ) {
        S_set_error("SYC_SWITCH_get_state_thresholds not supported for switches of Type 'Bus Switch'");
    }

    ( $result, $maxMeasurementLimit ) = SYC_get_ScipPM_Content_NOERROR( [ 'Switches', 'DeviceData', $switch_name, "MaxMeasurementLimit" ] );
    return 0 unless $result;

    $threshold_unit = $unitMapping_href->{$type};

    $state = $stateMapping_href->{$state} if exists $stateMapping_href->{$state};

    if ( $state eq "PositionA" or $state eq "PositionB" ) {
        ( $result, $thresholdType ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_Type" ] );

        if ( $thresholdType eq "Range" ) {
            ( $result, $threshold_min ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_Low" ] );
            ( $result, $threshold_max ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_High" ] );
        }
        else {
            ( $result, $threshold ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_ThresholdValue_Ohm" ] );
            return 0 unless $result;

            ( $result, $threshold_A_Below_B ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, "Threshold_A_Below_B" ] );
            return 0 unless $result;

            if (   $threshold_A_Below_B eq "true" and $state eq "PositionA"
                or $threshold_A_Below_B eq "false" and $state eq "PositionB" )
            {
                $threshold_min = 0;
                $threshold_max = $threshold;
            }
            else {
                $threshold_min = $threshold;
                $threshold_max = $maxMeasurementLimit;
            }
        }
    }
    elsif ( $state eq "UndefinedValue" ) {
        ( $result, $threshold_min ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_Low" ] );
        ( $result, $threshold_max ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state . "_High" ] );
    }
    elsif ( $state eq "OpenLineValue" ) {
        ( $result, $threshold ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state ] );

        if ( $type eq "Hall Switch" ) {
            $threshold_max = $threshold;
            $threshold_min = 0;
        }
        else {
            $threshold_max = $maxMeasurementLimit;
            $threshold_min = $threshold;
        }
    }
    elsif ( $state eq "Short2GndValue" ) {
        ( $result, $threshold ) = SYC_get_ScipPM_Content( [ 'Switches', 'DeviceData', $switch_name, $state ] );

        if ( $type eq "Hall Switch" ) {
            $threshold_max = $maxMeasurementLimit;
            $threshold_min = $threshold;
        }
        else {
            $threshold_max = $threshold;
            $threshold_min = 0;
        }
    }

    if ( $threshold_min eq 'N/A' or $threshold_max eq 'N/A' or $threshold_min eq 'NA' or $threshold_max eq 'NA' ) {
        S_set_error( "State '$state' not supported for switch type '$type'.", 109 );
        return 0;
    }

    return ( 1, $threshold_min, $threshold_max, $threshold_unit );
}

1;
__END__

