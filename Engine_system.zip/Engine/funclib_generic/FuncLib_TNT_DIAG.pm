package FuncLib_TNT_DIAG;

######################################################

=head1 NAME

TNT_Diag_Functions

Provide LIFT General functions for Diagnostics

=cut

######################################################

use strict;
use LIFT_general;
use LIFT_CD;
use GENERIC_DCOM;
use LIFT_labcar;
use LIFT_can_access;
use LIFT_flexray_access;
use LIFT_PD;
use LIFT_crash_simulation;
use LIFT_equipment;


use Exporter;

BEGIN {
	our @ISA    = qw(Exporter);
	our @EXPORT = qw(
	  DIAG_request_DependentServices
	  DIAG_getByteBitDecValue
	  DIAG_getStateFromResponse
	  DIAG_ECUReset
	  DIAG_getSecurityAccess
	  DIAG_setProhibitingPrecondition
	  DIAG_removeProhibitingPrecondition
	  DIAG_StartSession
	  DIAG_ReadActiveSession_SW_var
	  
	  Prod_Diag_ReadHistoryFltMemory
	  Prod_Diag_Fast_Diagnosis_CAN
	  Prod_Diag_Fast_Diagnosis_Flexray
	);
}

use INCLUDES_Project;
my ($Real,$Monitored_ID,$Prog);

=head1 SYNOPSIS

	use LIFT_general;
    use GENERIC_DCOM;
    use LIFT_CD;
    use INCLUDES_Project;

      DIAG_request_DependentServices
      DIAG_getByteBitDecValue
      DIAG_getStateFromResponse
      DIAG_ECUReset

=head1 DESCRIPTION

Generic functions for Diagnostics

=cut

=head2 DIAG_request_DependentServices

	DIAG_request_DependentServices($requestLabel [,$NRC_type]);

I<B<Description:>> This function send the dependent services (as mentioned in the mapping file) before it send the actual request.

$requestLabel = Mandatory parameter, label for the request to be sent.
$NRC_type = Optional parameter, expected NRC for the request. Depending on this the dependent services will be sent.
			(NRC_type : As of now only for NRC24 it is implementd)

I<B<Return value(s):>> None

I<B<Verdict:>>	none

I<B<Error:>> If the mandatory parameter is missing.

I<B<Example:>> DIAG_request_DependentServices('REQ_SecurityAccess_SendKey');

I<B<Example for the mapping File:>>

	"SecurityAccess_SendKey" => {  
                "Requests" => {
					"REQ_SecurityAccess_SendKey"     					=> { 'Request' => "27 60 Key" },
					"REQ_SecurityAccess_SendKey_DependentServices"     	=> ["SecurityAccess_RequestSeed"],
                 },  
                "POS_Responses" => { 
                    "PR_SecurityAccess_SendKey"      => { "Response" =>  "67 60 " , "Mode" =>  "strict" , "Desc" =>  "PR: Security Access - Send Seed" ,},
                 },  
		"allowed_in_sessions" => ["DisposalSession"] ,    				 
         },

=cut

sub DIAG_request_DependentServices {

	my $requestLabel = shift;
	my $NRC_type     = shift;

	my ( $request_info, @RequestArray, @request_Data, %DataValue, $index, );

	#access the mapping file
	my $DiagMapping = S_get_contents_of_hash( ['Mapping_DIAG'] );

	unless ( defined $requestLabel ) {
		S_set_error( "Missing mandatory parameter 'requestLabel'!", 110 );
		return;
	}

	#get the request information from the diag mapping file.
	$request_info = GDCOM_getRequestInfofromMapping($requestLabel);

	#    S_wait_ms(2000);    #wait

	if ( not defined $NRC_type ) {
		if ( defined $request_info->{'Requests'}{ "REQ_" . $requestLabel . "_DependentServices" } ) {
			@RequestArray = @{ $request_info->{'Requests'}{ "REQ_" . $requestLabel . "_DependentServices" } };
		}    #end of if
		else {
			GEN_printComment( "REQ_" . $requestLabel . "_DependentServices is not defined in the DiagMapping file. May be it is optional" );
		}
	}
	elsif ( $NRC_type =~ m/sequence/i ) {
		if ( defined $request_info->{'Requests'}{ "REQ_" . $requestLabel . "_NRC24" } ) {
			@RequestArray = @{ $request_info->{'Requests'}{ "REQ_" . $requestLabel . "_NRC24" } };
		}    #end of if
		else {
			GEN_printComment( "REQ_" . $requestLabel . "_NRC24 is not defined in the DiagMapping file. May be it is optional" );
		}
	}
	else {
		GEN_printComment("Wrong NRC type");
	}

	foreach my $request (@RequestArray) {
		@request_Data = split( /\|/, $request );
		if ( defined( $request_Data[1] ) ) {
			for ( $index = 0x01 ; $index < scalar(@request_Data) ; $index++ ) {

				#store data parameter values.
				$DataValue{ $request_Data[$index] } =
				  $request_Data[ ( $index + 1 ) ];
				$index++;
			}

			#Send request with all data bytes
			GDCOM_request_general( "REQ_" . $request_Data[0], "PR_" . $request_Data[0], \%DataValue );
		}
		else {

			#Request do not have ant data field as a parameter.
			GDCOM_request_general( "REQ_" . $request, "PR_" . $request );
		}
	}
	return 1;
}    # end of DIAG_request_DependentServices

=head1 DIAG_getByteBitDecValue

    $Formatted_req = DIAG_getByteBitDecValue($response, $interpretationDescription_href);

I<B<Description:>> Return the Decimal Value of Byte/Bit Data from the response. Retuns Byte decimal value if bit is not defined.

I<B<Example:>>
 
   $response = Diag Service Response string 22 A0 0E XX XX XX XX 
   $interpretationDescription_href = {"Byte_Position" => "0", "Number_of_Bytes" => "1", "Bit_Position"=>"4", "Number_of_Bits"=>"2" }
   
   Byte_Position   = Byte position
   Byte Index        0  1  2  3  4  5  6  7  8 (Starting from 0 from right)
                     22 A0 0E XX XX XX XX XX XX 
                                          |
                                    0b x x x x x x x x
                                       7 6 5 4 3 2 1 0 Bit Index
                     
   Number_of_Bytes or Number_of_Bits one should be defined at a time.

   Number_of_Bytes  = No of Bytes Optional Paramater 	

   Bit_Position     = Bit Position Optional Parameter (Starting from 0 from right)

   Number_of_Bits   = Bit length Optional Parameter 

I<B<Return:>> Return the Decimal Value of Byte/Bit Data from the response

I<B<Verdict:>> None

I<B<Error:>> Set Error if mandatory parameters are not there and byte index is greater than the obtained reponse.

=cut

sub DIAG_getByteBitDecValue {
	my $response                       = shift;
	my $interpretationDescription_href = shift;
	unless ( defined $response ) {
		S_set_error( "Missing mandatory parameter $response\n", 110 );
		return 0;
	}

	unless ( defined $interpretationDescription_href->{"Byte_Position"} ) {
		S_set_error( "Missing mandatory parameter Byte_Position \n", 110 );
		return 0;
	}

	my @byte_Array =
	  split( / /, "$response" );    # Splitting the bytes in response
	my $byte_Index = $interpretationDescription_href->{"Byte_Position"};
	my $bit_Index  = $interpretationDescription_href->{"Bit_Position"};

	my $Number_of_Bytes = $interpretationDescription_href->{"Number_of_Bytes"};
	$Number_of_Bytes = 1
	  unless ( defined $Number_of_Bytes );    # Setting the length to 1 if not defined

	my $Number_of_Bits = $interpretationDescription_href->{"Number_of_Bits"};
	$Number_of_Bits = 1
	  unless ( defined $Number_of_Bits );     # Setting the length to 1 if not defined

	S_w2log( 4, "Byte Position : $byte_Index, Bit Position : $bit_Index, Number Of Bits : $Number_of_Bits, Number Of Bytes : $Number_of_Bytes" );
	if ( $byte_Index >= @byte_Array ) {
		S_set_error( "Byte Index $byte_Index is greater than obtained reponse $response", 110 );
		return 0;
	}

	unless ( defined $bit_Index ) {
		my $hex_Value;

		foreach ( $byte_Index .. ( $byte_Index + $Number_of_Bytes - 1 ) ) {
			$hex_Value .= $byte_Array[$_];    #Extract bit value
		}

		my $dec_Value_Byte = sprintf( '%d', hex("$hex_Value") );    # Hex to Decimal conversion
		return $dec_Value_Byte;                                     # The fucntion return byte decimal value if [Bit position value is not defined]
	}

	my $binary_Value = sprintf( "%08b", hex( $byte_Array[$byte_Index] ) );    # Byte to Bit Conversion to extract the value at specified bit
	S_w2log( 4, "Binary Bit Extraction $binary_Value\n" );

	my @bit_Array = ( $binary_Value =~ m/./g );                               # Split the bits into array elements
	@bit_Array = reverse @bit_Array;                                                     #reverse the array since bit position start from right

	my $binary_Value_Extracted;
	foreach ( $bit_Index .. ( $bit_Index + $Number_of_Bits - 1 ) ) {
		S_w2log( 4, "Index $_" );
		$binary_Value_Extracted .= $bit_Array[$_];                            #Extract bit value

	}
	
	$binary_Value_Extracted = reverse $binary_Value_Extracted;

	S_w2log( 4, "Extracted Binary Value $binary_Value_Extracted \n" );
	my $dec_Value_Bit = S_bin2dec($binary_Value_Extracted);                   # binary to Decimal conversion

	return $dec_Value_Bit;
}

=head1 DIAG_getStateFromResponse

    $Formatted_req = DIAG_getStateFromResponse( $request_Label, $device_Label );

I<B<Description:>> Function interprets the state from the reponse obtained through customer diagnostic service, The interpretation details are mentioned in ResponseInterpretationTable hash. A sample is given below 

          "ReadDataByIdentifier_HardwiredInputelectronicvalues" => {
                                                                     "protocol" => [
                                                                                     "UDS"
                                                                                   ],
                                                                     "preconditions_prohibiting_execution" => [
                                                                                                                "None"
                                                                                                              ],
                                                                     "POS_Responses" => {
                                                                                          "PR_ReadDataByIdentifier_HardwiredInputelectronicvalues" => {
                                                                                                                                                        "DataLength" => 3,
                                                                                                                                                        "DoorsIDs" => [
                                                                                                                                                                        "SPS_ConfigTable267"
                                                                                                                                                                      ],
                                                                                                                                                        "Desc" => "ReadDataByIdentifier_HardwiredInputelectronicvalues",
                                                                                                                                                        "Mode" => "relax",
                                                                                                                                                        "Response" => "62 01 0E"
                                                                                                                                                      }
                                                                                        },
                                                                     "Requests" => {
                                                                                     "REQ_ReadDataByIdentifier_HardwiredInputelectronicvalues" => {
                                                                                                                                                    "Request" => "22 01 0E"
                                                                                                                                                  }
                                                                                   },
                                                                     "ResponseInterpretationTable" => {
                                                                                "BLFD" => {             
                                                                                    "Byte_Position"   => 4, "Bit_Position" => 2, "Number_of_Bytes => 1, "Number_of_Bits" => 2,
																					"InterpretedValue" =>
     																					{
     																					  0 => "PositionA",
     																					  1 => "PositionB",
     																					  2 => "Faulty",
     																					}
																					},
																					............. n


                                                                        }


I<B<Example:>>
  
  Inputs : example : ($request_Label => ReadDataByIdentifier_HardwiredInputelectronicvalues, $switch_Name => BLFP)      

ReadHarwireInputs service $22 01 0E returns all swicth states together in reponse
 0  1  2  3   4  5 6  7  8     Byte Index
$62 01 0E XX XX XX XX XX XX
             |
       0b X X X X X X X X      Bit Index
          7 6 5 4 3 2 1 0  
BLFD state is obtained in 4th byte from bit 2 to 3,This binary information is extracted and retuned as decimal value 

I<B<Return:>> Return decimal value of state and Interpreted state based on decimal value.

I<B<Verdict:>> None

I<B<Error:>> Sets error if mandatory parameters are missing and entered there is parameter is having typo.
=cut

sub DIAG_getStateFromResponse {

	my $request_Label = shift;
	my $device_Label  = shift;

	unless ( defined $request_Label ) {
		S_set_error("Madatory Parameter $request_Label is not defined ");
	}

	unless ( defined $device_Label ) {
		S_set_error("Madatory Parameter $device_Label is not defined ");
	}

	my $interpretationDescription_href = S_get_contents_of_hash( [ 'Mapping_DIAG', "Requests_Responses", $request_Label, 'ResponseInterpretationTable', $device_Label ] );

	unless ( defined $interpretationDescription_href->{"Byte_Position"} ) {
		S_set_error( " Byte Position is mandatory. Define in Mapping_DIAG --> ResponseInterpretationTable section under request  $request_Label" );
		return 0;
	}

	my $response = GDCOM_request_general( "REQ_" . $request_Label, "PR_" . $request_Label );

	unless ($response) {
		S_set_error( "Error while calling GDCOM_request_general for request $request_Label" );
		return 0;
	}

	$response = "62 01 0E FF FF FF FF FF FF" if ($main::opt_offline);

	my $state_Value_dec = DIAG_getByteBitDecValue( $response, $interpretationDescription_href );

	unless ($state_Value_dec) {
		S_set_error( "Error while calling DIAG_getByteBitDecValue for response($response) of $request_Label" );
		return 0;
	}

	my $state_Value_Interpreted;
	if ( $interpretationDescription_href->{"InterpretedValue"} ) {
		$state_Value_Interpreted = $interpretationDescription_href->{"InterpretedValue"}->{$state_Value_dec};
	}

	return ( $state_Value_dec, $state_Value_Interpreted );

}

sub DIAG_ECUReset {
	my $resetType = shift;

	$resetType = 'hard' unless ( defined $resetType );

	GDCOM_set_addressing_mode('physical');

	GDCOM_request( '10 01', '50 01', 'relax' );
	S_wait_ms(2000);
	GDCOM_request( '10 03', '50 03', 'relax' );

	GDCOM_request( '11 01', '51 01', 'relax' ) if ( $resetType =~ m/hard/i );
	GDCOM_request( '11 03', '51 03', 'relax' ) if ( $resetType =~ m/soft/i );
}

sub DIAG_getSecurityAccess {
	my $level = shift;
	
	S_set_error ("This function DIAG_getSecurityAccess needs to be implemented in the Project/CustLib DIAG FuncLib", 0);

}


=head2 DIAG_setProhibitingPrecondition

	DIAG_setProhibitingPrecondition ($DiagPrecondition [,$parameters_href]);

I<B<Description:>> This function will set the different diagnostic preconditions which prohibit service execution. Supported preconditions:

	IdleMode
	AutarkieMode
	InternalFaultConfirmed
	VehicleSpeedTooHigh
	VoltageTooHigh
	VoltageTooLow
	InitTestsNotCompleted
	ProductionModeActive
	DeviceMonitored
	DeviceConfigured
	StaticBehaviorBit
	DynamicBehaviourBit
	AlgoIsActiveOrCrashStorageInProgress
	AnyEventStored
	AnyDeployStored
	AnyLockedDeployStored
	AnyAirbagDeployStored

For 'InternalFaultConfirmed': $parameters_href should be in format {"InternalFaultName" => 'rb_pom_OverTemperatureSystemAsic1_flt'}

For 'VehicleSpeedTooHigh': $parameters_href should be in format {"SpeedSignal" => 'Veh_V_ActlEng', "SignalValue" => '6'}

For 'DeviceConfigured', 'DeviceMonitored', 'StaticBehaviorBit', 'DynamicBehaviourBit': $parameters_href should be in format: {"Device" => 'BLFD'}

For 'AlgoIsActiveOrCrashStorageInProgress', 'AnyEventStored', 'AnyDeployStored', 'AnyLockedDeployStored', 'AnyAirbagDeployStored' : $parameters_href should be in format: {"RESULTDB" => 'EDR', 'CRASHNAME'=> 'Single_EDR_Front_Inflatable'}

=cut


sub DIAG_setProhibitingPrecondition {

	my $DiagPrecondition = shift;
	my $parameters_href  = shift;

	S_w2rep("Setting $DiagPrecondition condition");

	unless ( defined $DiagPrecondition ) {
		S_set_error( "Missing mandatory parameter DiagPrecondition", 110 );
		return 0;
	}
	
	if ($DiagPrecondition =~ m/InternalFaultConfirmed/i){
		_QualifyFault ($parameters_href->{'InternalFaultName'});
		GDCOM_set_addressing_mode('physical'); #since mode changes in above function to 'PD'
		S_wait_ms (5000);
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/voltagetoohigh/i ) {
		GEN_setECUMode('OverVoltage');
		S_wait_ms (10000, 'wait after setting voltage');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/voltagetoolow/i ) {
		GEN_setECUMode('UnderVoltage');
		S_wait_ms (10000, 'wait after setting voltage');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/IdleMode/i ) {
		GEN_setECUMode('IdleMode');
		return 1;
	}

	if ( $DiagPrecondition =~ m/DeviceConfig|StaticBehaviorBit|DynamicBehaviorBit/i  ) {
		($Real,$Monitored_ID,$Prog) = PD_get_device_config_NOERROR ( $parameters_href->{'Device'} );
		($Real,$Monitored_ID,$Prog) = PD_get_device_config_NOERROR ( $parameters_href->{'Device'} );
		
		if ( $DiagPrecondition =~ m/StaticBehaviorBit/i  ) { #since PD_get_device_config doesnt work for SPB
			my $device_data_href = PD_DumpDeviceConfiguration_NOHTML ( );
			$Prog = $device_data_href->{'spb'}{'Prog'}{$parameters_href->{'Device'}};
		}
		
		if ( $DiagPrecondition =~ m/DynamicBehaviorBit/i  ) { #since PD_get_device_config doesnt work for SPB
			my $device_data_href = PD_DumpDeviceConfiguration_NOHTML ( );
			$Prog = $device_data_href->{'pars'}{'Prog'}{$parameters_href->{'Device'}};
		}
		
		if($Prog == 1){ #device is configured
			my $status = PD_Device_configuration_NOERROR( "clear", [$parameters_href->{'Device'}], 'no', 'yes' );
			#retry if error
			PD_Device_configuration_NOERROR( 'clear', [$parameters_href->{'Device'}], 'no', 'yes' ) if(!$status);
			S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
		}
		else{
			S_w2rep ("Device $parameters_href->{'Device'} is not configured already. No action taken");
		}
		return 1;
	}
	
	if( $DiagPrecondition =~ m/DeviceMonitor/i  ) {
		($Real,$Monitored_ID,$Prog) = PD_get_device_config( $parameters_href->{'Device'} );
		if($Monitored_ID == 1){ #device is monitored
			my $status = PD_Device_configuration_NOERROR( 'clear_Mon', [$parameters_href->{'Device'}], 'no', 'yes' );
			#retry if error
			PD_Device_configuration_NOERROR( 'clear_Mon', [$parameters_href->{'Device'}], 'no', 'yes' ) if(!$status);
			S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
		}
		else{
			S_w2rep ("Device $parameters_href->{'Device'} is not monitored already. No action taken");
		}
		return 1;
	}

	if ( $DiagPrecondition =~ m/ProductionModeActive/i ) {
		GEN_setECUMode('PlantMode7_ElectronicFiringMode');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/Autark/i ) {
		LC_ECU_Off();
		S_wait_ms(800,'wait after power off');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/InitTestNotCompleted/i ) {
		LC_ECU_Off();
		S_wait_ms('TIMER_ECU_OFF');
		LC_ECU_On();
		S_wait_ms(500, 'wait after power ON');
		return 1;
	}

	if ( $DiagPrecondition =~ m/AlgoIsActive|AnyEventStored|AnyDeployStored|AnyLockedDeployStored|AnyAirbagDeployStored/i ) {
		my $crashSettings = CSI_GetCrashDataFromMDS($parameters_href);
		S_wait_ms(1000);
		CSI_PrepareEnvironment( $crashSettings, 'init_complete' );
		S_wait_ms(1000);
		CSI_LoadCrashSensorData2Simulator($crashSettings);
		S_wait_ms(1000);
		CSI_TriggerCrash();
		if ( $DiagPrecondition =~ m/AlgoIsActive/i ){
			S_wait_ms(500, 'wait after crash trigger');
		}
		else{
			S_wait_ms(15000, 'wait for crash storage');
		}
		return 1;
	}

	if ( $DiagPrecondition =~ m/VehicleSpeedTooHigh/i ) {
		if (defined EQUIP_get_devices ( 'FlexRay_Access' , 'basic')){ #Flexray used
			FR_write_flxr_signal ( $parameters_href->{'SpeedSignalName'}, $parameters_href->{'SpeedSignalValue'}  );
		}
		else{
			CA_write_can_signal( $parameters_href->{'SpeedSignalName'}, $parameters_href->{'SpeedSignalValue'} );
		}
		
		S_wait_ms (2000);
		return 1;
	}
	return 1;
}


=head2 DIAG_removeProhibitingPrecondition

	DIAG_removeProhibitingPrecondition ($DiagPrecondition [,$parameters_href]);

I<B<Description:>> This function will remove the different diagnostic preconditions which were set using DIAG_setProhibitingPrecondition. See documentation for this function

=cut

sub DIAG_removeProhibitingPrecondition{
	my $DiagPrecondition = shift;
	my $parameters_href  = shift;
	
	S_w2rep("Removing $DiagPrecondition condition");

	unless ( defined $DiagPrecondition ) {
		S_set_error( "Missing mandatory parameter DiagPrecondition", 110 );
		return 0;
	}
	
	if ($DiagPrecondition =~ m/InternalFaultConfirmed/i){
		_DequalifyFault ($parameters_href->{'InternalFaultName'});
		GDCOM_set_addressing_mode('physical');
		S_wait_ms (5000);
		PD_ClearFaultMemory ();
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/voltagetoohigh|voltagetoolow/i ) {
		GEN_setECUMode('NormalVoltage');
		S_wait_ms (10000, 'wait after setting voltage');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/IdleMode/i ) {
		GEN_setECUMode('RemoveIdleMode');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/Autark/i ) {
		LC_ECU_On();
		S_wait_ms('TIMER_ECU_READY');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/ProductionModeActive/i ) {
		GEN_setECUMode('RemovePlantModes');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/InitTestNotCompleted/i ) {
		S_wait_ms('TIMER_ECU_READY', 'wait for init time');
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/VehicleSpeedTooHigh/i ) {
		if (defined EQUIP_get_devices ( 'FlexRay_Access' , 'basic')){ #Flexray used
			FR_write_flxr_signal ( $parameters_href->{'SpeedSignalName'}, 0  );
		}
		else{
			CA_write_can_signal( $parameters_href->{'SpeedSignalName'}, 0 );
		}
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/DeviceConfig|StaticBehaviorBit|DynamicBehaviorBit/i  ) {
		if($Prog == 1){ #device was configured
			PD_GetECUMode_NOERROR();
			my $status = PD_Device_configuration_NOERROR( "set", [$parameters_href->{'Device'}], 'no', 'yes' );
			#retry if error
			PD_Device_configuration_NOERROR( 'set', [$parameters_href->{'Device'}], 'no', 'yes' ) if(!$status);
			S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
		}
		else{
			S_w2rep ("Device $parameters_href->{'Device'} is not configured already. No action taken");
		}
		return 1;
	}
	
	if( $DiagPrecondition =~ m/DeviceMonitor/i  ) {
		if($Monitored_ID == 1){ #device was monitored
			my $status = PD_Device_configuration_NOERROR( 'set_Mon', [$parameters_href->{'Device'}], 'no', 'yes' );
			#retry if error
			PD_Device_configuration_NOERROR( 'set_Mon', [$parameters_href->{'Device'}], 'no', 'yes' ) if(!$status);
			S_wait_ms( 'TIMER_ECU_READY', 'wait after reset' );
		}
		else{
			S_w2rep ("Device $parameters_href->{'Device'} is not monitored already. No action taken");
		}
		return 1;
	}
	
	if ( $DiagPrecondition =~ m/AlgoIsActive|AnyEventStoredAnyDeployStored|AnyLockedDeployStored|AnyAirbagDeployStored/i ){
		S_wait_ms(15000, 'wait for crash storage') if ( $DiagPrecondition =~ m/AlgoIsActive/i );
	    PD_ClearCrashRecorder ();
	    S_wait_ms (4000);
	    return 1;
	}
	
}

sub DIAG_StartSession { 

   	my $session = shift;
   	my $requestLabel = shift;

   	my ( $request, $response ); 
     
   	unless(defined( $session )) {
        S_set_error( " too less parameters ! SYNTAX: GDCOM_StartSession ( $session [, $requestLabel] )", 110 );
        return 0;
   	}
   
   	unless (defined $requestLabel){
   		$requestLabel = "DiagnosticSessionControl";
   	}

	#check for security access for the session 
   	GDCOM_GetAccessToRequest($requestLabel."_$session");

	#Enter a session
  	return GDCOM_request_general(  "REQ_$requestLabel"."_$session" , "PR_$requestLabel"."_$session");

}

sub DIAG_ReadActiveSession_SW_var {
	
	my $SW_var_session = shift;
	
	my $session_val = PD_ReadMemoryByName_NOERROR ( $SW_var_session ); #will return error in programming session since PD communication not possible in bootloader mode
	
	return S_aref2hex ( $session_val ) if(defined $session_val and scalar @$session_val);

	return 2; #else, programming session
	
}
=head2 Prod_Diag_Fast_Diagnosis_CAN

	Prod_Diag_Fast_Diagnosis_CAN ();
	
	This a dummy function, as platform support this functionality. Must be overwritten by project specific function

I<B<Description:>> This function should return response 'PdPayload' in hex string (without appending '0x'),compare other functions in main test script

=cut

sub Prod_Diag_Fast_Diagnosis_CAN{
	
	
	S_set_error("Platform doesnt support 'Prod_Diag_Fast_Diagnosis_CAN', please overwrite this function with similar function defined in Funclib_Project_Diag,testcase aborted");
	return;
}

=head2 Prod_Diag_Fast_Diagnosis_Flexray

	Prod_Diag_Fast_Diagnosis_Flexray ();
	
	This a dummy function, as platform support this functionality. Must be overwritten by project specific function

I<B<Description:>> This function should return response 'PdPayload' in hex string (without appending '0x'),compare other functions in main test script

=cut
sub Prod_Diag_Fast_Diagnosis_Flexray{
	
	#This function should return response 'PdPayload' in hex string (without appending '0x'),compare other functions in main test script
	S_set_error("Platform doesnt support 'Prod_Diag_Fast_Diagnosis_Flexray', please overwrite this function with similar function defined in Funclib_Project_Diag,testcase aborted");
	return;
}

=head2 Prod_Diag_ReadHistoryFltMemory

	Prod_Diag_ReadHistoryFltMemory ();
	
	This a dummy function, as platform support this functionality. Must be overwritten by project specific function

I<B<Description:>> This function should return response 'PdPayload' in hex string (without appending '0x'),compare other functions in main test script

=cut
sub Prod_Diag_ReadHistoryFltMemory{
	
	#This function should return response 'PdPayload' in hex string (without appending '0x'),compare other functions in main test script
	S_set_error("Platform doesnt support 'Prod_Diag_ReadHistoryFltMemory', please overwrite this function with similar function defined in Funclib_Project_Diag,testcase aborted");
	return;
}

sub _DequalifyFault{
	
	my $faultName = shift;
	
	my $faultID = PD_GetFaultID_NOHTML( $faultName );
	my $faultID_aref = S_dec2aref ( $faultID, 'U16' );
	my $checksum = 5 + 19 + @$faultID_aref[0] + @$faultID_aref[1];
	my $checksum_aref = S_dec2aref ( $checksum, 'U16' );
    
    PD_send_request_wait_response( [ 0x05, 0x13, @$faultID_aref[0], @$faultID_aref[1], 0x00, @$checksum_aref[1] ] );
}

sub _QualifyFault{
	
	my $faultName = shift;
	
	my $faultID = PD_GetFaultID_NOHTML( $faultName );
	my $faultID_aref = S_dec2aref ( $faultID, 'U16' );
	my $checksum = 5 + 19 + @$faultID_aref[0] + @$faultID_aref[1] + 1;
	my $checksum_aref = S_dec2aref ( $checksum, 'U16' );
    
    PD_send_request_wait_response( [ 0x05, 0x13, @$faultID_aref[0], @$faultID_aref[1], 0x01, @$checksum_aref[1] ] );
}

1;
