package FuncLib_TNT_GEN;

######################################################

=head1 NAME

TNT_General_Functions

Provide LIFT General functions

=cut

######################################################

use File::Basename;
use strict;
use LIFT_general;
use LIFT_PD;
use LIFT_evaluation;
use LIFT_CANoe;
use LIFT_CD;
use LIFT_labcar;
use LIFT_ECU_SW_Flash;
use GENERIC_DCOM;
use Data::Dumper;
use LIFT_PRITT;
use File::Spec;
$Data::Dumper::Sortkeys = 1;    #Sort the keys in the output


use Exporter;

BEGIN {
    our @ISA    = qw(Exporter);
    our @EXPORT = qw(
      GEN_print_caller
      GEN_printTestStep
      GEN_printComment
      GEN_byteString2hexaref
      GEN_hexaref2byteString
      GEN_Read_mandatory_testcase_parameter
      GEN_Read_optional_testcase_parameter
      GEN_Power_on_Reset      
      GEN_StandardPrepNoFault
      GEN_Finalization
      GEN_EVAL_CompareStrArrays
      GEN_EVAL_CompareNumArrays
      GEN_setECUMode
      GEN_readWLStatus
      GEN_readPowerONCounter
	  GEN_generateUniqueTraceName
	  GEN_printLink
	  GEN_printTableToReport
	  GEN_generateValuesForTesting
	  GEN_filterChildarrayFromParentarray
	  GEN_AutoECUFlash
    );
}

my $AB12_flag = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'AB12'};                #AB12 or AB10
my $systemMode_old;
=head1 SYNOPSIS

	use LIFT_general;
	use LIFT_MLC;
	use LIFT_PD;
	use LIFT_evaluation;
	use LIFT_CANoe;
	use LIFT_POWER;


=head1 DESCRIPTION

Generic functions

=cut

sub GEN_print_caller {

    my $subfunction = ( caller(1) )[3];
    my $filename    = ( caller(0) )[1];
    my $package     = $subfunction;
    $package =~ s/(.*)::.*/\1/i;
    my $packagesub = $subfunction;
    $packagesub =~ s/.*::(.*)$/\1/i;

    if ( $package =~ m/TNT/i ) {
        S_w2log( '5', "<div style =\' color:teal;font-size:75%;\'> call $subfunction [ <a href='../../Engine/Documentation/html/modules/TC_FunctionLib/TC_TNT/$package.html#$packagesub' style =\" color:gray;font-size:85%;\">  documentation </a> ] </div>", 'Teal' );
    }
    else {
        S_w2log( '5', "<div style =\' color:teal;font-size:75%;\'> call $subfunction [ <a href='file:///$filename'  style =\"color:gray;font-size:80%;\"> file</a>, <a href='../../Engine/Documentation/html/modules/TC_FunctionLib/TC_Project/$package.html#$packagesub' style =\" color:gray;font-size:85%;\">  documentation </a> ] </div>", 'Teal' );
    }

}

=head1 Function 'testcase_basic'
=head2 GEN_printComment

	GEN_printComment($string);

I<B<Description:>> Print a comment to the report

$string: string to be printed to the report

Example: GEN_printComment ("Read fault name from mapping file");

I<B<Return:>> None

I<B<Verdict:>> None

I<B<Error:>> as per S_w2log

=cut

sub GEN_printComment {

    my $Comment = shift;
    S_w2log( '3', $Comment, 'GoldenRod' );

}


=head2 GEN_printTestStep

	GEN_printTestStep($string);

I<B<Description:>> Print a test step text to the report

$string: string to be printed to the report

Steps in stimulation and measurement should have this syntax: GEN_printTestStep ("Step 1: Read fault memory");

Steps in evaluation section should have this syntax: GEN_printTestStep ("Evaluation for Step 1: No faults are present in fault memory");

Additionally, for steps in stimulation and measurement, link to the corresponding evaluation step is provided and vice versa

I<B<Return:>> None

I<B<Verdict:>> None

I<B<Error:>> as per S_w2rep

=cut

sub GEN_printTestStep {

    my $TestStep = shift;
    my $stepNum;

    my $subfunction = ( caller(1) )[3];
    $subfunction =~ s/.*::(.*)$/$1/i;

    if(($subfunction eq 'TC_evaluation') and ($TestStep =~ m/Evaluation for Step\s*(\d)/i)){
    	$stepNum = $1;
        S_teststep_detected( $TestStep , 'TNT_teststep_'.$stepNum );        
#     	my $nextStep = $stepNum + 1;
#     	S_w2rep( "$TestStep <span style =\' color:teal;font-size:75%;\'> <a id = 'eval$stepNum' style=\"position: relative; padding-top: 40px\"></a> [ <a href = '#eval$nextStep' style =\" color:gray;font-size:75%;\">NextStep</a> ] [ <a href = '#stimu$stepNum' style =\" color:gray;font-size:75%;\">stimulation step $stepNum</a> ] </span>", 'DodgerBlue', "EVAL_Step$stepNum" );
    }
    elsif(($subfunction eq 'TC_stimulation_and_measurement') and ($TestStep =~ m/Step\s*(\d)/i)){
    	$stepNum = $1;
        S_teststep ( $TestStep , 'NO_AUTO_NBR' , 'TNT_teststep_'.$stepNum );        
#     	my $nextStep = $stepNum + 1;
#     	S_w2rep( "$TestStep <span style =\' color:teal;font-size:75%;\'> <a id = 'stimu$stepNum' style=\"position: relative; padding-top: 40px\"></a> [ <a href = '#stimu$nextStep' style =\" color:gray;font-size:75%;\">NextStep</a> ] [ <a href = '#eval$stepNum' style =\" color:gray;font-size:75%;\">evaluation step $stepNum</a> ] </span>", 'DodgerBlue', "STIMU_Step$stepNum" );
    }
    else{
        S_teststep ( $TestStep , 'NO_AUTO_NBR' );        
#     	S_w2rep( $TestStep, 'DodgerBlue' );
    }
    
    return 1;
}

=head2 GEN_byteString2hexaref

	$hexaref = GEN_byteString2hexaref($string);

I<B<Description:>> Convert a string (of diag response) to a hex array reference

$string: response string from GDCOM function which contains all response bytes separated by a space. Example: "03 7F 22 13"

This maybe useful for handling strings/arefs with DCOM functions.

I<B<Return:>> array ref of bytes in hex. Example: [0x03, 0x7F, 0x22, 0x13]

I<B<Verdict:>> None

I<B<Error:>> sets error if string is empty or not defined

=cut

sub GEN_byteString2hexaref {
    my $responseString = shift;
    my @hexAref;

    my @array_response = split( / /, $responseString );
    foreach (@array_response) { 
    	push(@hexAref, "0x$_") if ( defined $_ and $_ ne '' and $_ ne ' ' ); 
    }
    return \@hexAref;

}

=head2 GEN_hexaref2byteString

	$string = GEN_hexaref2byteString($hexaref);

I<B<Description:>> Convert a hex array reference (of diag response) to a string with each byte separated by a space

$hexaref: array ref of bytes in hex. Example: [0x03, 0x7F, 0x22, 0x13]

This maybe useful for handling strings/arefs with DCOM functions.

I<B<Return:>> string which contains all response bytes from hex aref separated by a space. Example: "03 7F 22 13"

I<B<Verdict:>> None

I<B<Error:>> sets error if aref is empty or not defined

=cut

sub GEN_hexaref2byteString {
    my $hexaref = shift;

    foreach (@$hexaref) { $_ = sprintf( "%02X", $_ ) if ( defined $_ and $_ ne '' ); }
    my $responseString = join( ' ', @$hexaref );
    return $responseString;

}

=head2 GEN_Read_mandatory_testcase_parameter

	GEN_Read_mandatory_testcase_parameter( $tcpar,[$mode] );

I<B<Description:>>
Read a mandatory TC parameter from the .par file

$tcpar = mandatory parameter to be read

$mode = (optional) if mode is 'byref' this function returns the list reference for Lists and the hash reference for Hashes

I<B<Return:>> value/ref of the parameter

I<B<Verdict: >> none

I<B<Error:>> If parameter is not found in the .par file

=cut 

sub GEN_Read_mandatory_testcase_parameter {

    #GEN_print_caller();

    my $tcpar = shift;
    my $mode  = shift;

    my $tcpar_val = S_read_testcase_parameter( $tcpar, 'byref' );    #read the ref
    unless ( defined $tcpar_val ) {
        S_set_error( "Missing mandatory parameter $tcpar \n", 110 );
        GEN_print_caller();
    }

    if ( $mode eq 'byref' ) {
        return $tcpar_val;
    }
    else {
        if ( ref $tcpar_val eq 'ARRAY' ) {
            return @$tcpar_val;
        }
        elsif ( ref $tcpar_val eq 'HASH' ) {
            return %$tcpar_val;
        }
        elsif ( ref $tcpar_val eq '' ) {
            return $tcpar_val;
        }
    }

}

=head2 GEN_Read_optional_testcase_parameter

	GEN_Read_optional_testcase_parameter( $tcpar,[$mode] );

I<B<Description:>>	Read a TC parameter from the .par file

$tcpar = optional parameter to be read

$mode = (optional) if mode is 'byref' this function returns the list reference for Lists and the hash reference for Hashes

I<B<Return:>> value/ref of the parameter

I<B<Verdict:>> none

I<B<Error:>> none

=cut 

sub GEN_Read_optional_testcase_parameter {

    #GEN_print_caller();

    my $tcpar = shift;
    my $mode  = shift;

    return S_read_testcase_parameter( $tcpar, $mode );

}

=head2 GEN_Power_on_Reset

	GEN_Power_on_Reset(['NO_WAIT']);

I<B<Description:>>	Performs ECU Hard reset (does not set or change the voltage. Only connects/disconnects the power supply lines)

Switches OFF for 'TIMER_ECU_OFF' ms and then switches ON

'NO_WAIT' - optional parameter

if optional parameter is defined and equal to 'NO_WAIT' Then no wait is provided after power ON.

if optional parameter is not defined then waits for 'TIMER_ECU_READY' ms after power ON

TIMER_ECU_OFF and TIMER_ECU_READY are taken from the Project Const file

	'TIMER'=> 
		{
		'TIMER_ECU_READY'=> 5000, 
		...
		},	

I<B<Return:>> 1

I<B<Verdict:>> none

I<B<Error:>> none

=cut

sub GEN_Power_on_Reset {
    GEN_print_caller();
	
	my $no_Wait = shift;
	
    LC_ECU_Off();
    S_wait_ms('TIMER_ECU_OFF');
    LC_ECU_On();
	unless ((defined $no_Wait) && ($no_Wait eq 'NO_WAIT')){
		S_wait_ms('TIMER_ECU_READY');
	}
	
	return 1;
}

=head2 GEN_StandardPrepNoFault

    GEN_StandardPrepNoFault();

I<B<Description:>>	Preconditions before each test case. Calls the below functions

1. PD_ClearCrashRecorder();

2. PD_ClearFaultMemory();

3. Hard reset

4. PD_ReadFaultMemory();


I<B<Return:>> none

I<B<Verdict:>> none

I<B<Error:>> none

=cut

sub GEN_StandardPrepNoFault {
    GEN_print_caller();

    # LC_ECU_On();
	# LC_SetVoltage('U_BATT_DEFAULT');
	LC_ECU_On ('U_BATT_DEFAULT'); 
	S_wait_ms('TIMER_ECU_READY');

    #PD_ClearCrashRecorder();
	PD_ECUlogin();
	#PD_InitCommunication();
    GEN_printComment(" clear fault memory \n");
    PD_ClearFaultMemory();
	S_wait_ms('2000', 'wait for fault memory to be cleared');

    GEN_Power_on_Reset();
	PD_ECUlogin();
    my $flt_mem_struct = PD_ReadFaultMemory();

    return PD_evaluate_faults( $flt_mem_struct, [] );    # will check for empty fault memory

}

=head2 GEN_Finalization

    GEN_Finalization();

I<B<Description:>>	Finalization steps (executed after each TC)

I<B<Return:>> none

I<B<Verdict:>> none

I<B<Error:>> none

=cut

sub GEN_Finalization {

    #GEN_print_caller();

    return 1;
}

=head1 Function 'eval'
=head2 GEN_EVAL_CompareStrArrays

	$status = GEN_EVAL_CompareStrArrays($aref_observed,$aref_expected,[$expectedStatus]);

I<B<Description:>>	Compares 2 string arrays

$aref_observed  =  array ref of observed array

$aref_expected = array ref of expected array

$expectedStatus = 'Equal' or 'NotEqual' (this is an optional parameter)

Calls internally S_compare_str_arrays

I<B<Return:>> 1 if arrays match, 0 if not

I<B<Verdict:>> PASS or FAIL based on $expectedStatus

I<B<Error:>> error if array is empty

=cut

sub GEN_EVAL_CompareStrArrays {
    GEN_print_caller();

    my $aref_observed  = shift;
    my $aref_expected  = shift;
    my $expectedStatus = shift;

    #unless(scalar(@$aref_observed)){
    #	S_set_error("observed array is empty", 109);
    #	return undef;
    #}

    unless ( defined $aref_expected and scalar(@$aref_expected) ) {
        S_set_error( "expected array is empty", 109 );
        return undef;
    }

    my $result = S_compare_str_arrays( $aref_observed, $aref_expected );

    #my @hex_expected_resp=(@$aref_expected);
    #foreach (@hex_expected_resp){$_ = "0x".sprintf("%02X",$_);}
    #my @hex_observed_resp=(@$aref_observed);
    #foreach (@hex_observed_resp){$_ = "0x".sprintf("%02X",$_);}

    if ( defined $aref_observed and defined $aref_expected and ( ref($aref_observed) eq "ARRAY" ) and ( ref($aref_expected) eq "ARRAY" ) ) {
        GEN_printComment("Expected: @$aref_expected \n Observed: @$aref_observed");
    }

    if ( defined $expectedStatus and $expectedStatus =~ m/NotEqual/i ) {
        if ( $result == 0 ) {
            S_w2rep( "arrays dont match", "green" );
            S_set_verdict('VERDICT_PASS');
            return 0;
        }
        else {
            S_set_error( "arrays match", 0 );
            S_set_verdict('VERDICT_FAIL');
            return 1;
        }
    }
    elsif ( defined $expectedStatus and $expectedStatus =~ m/Equal/i ) {
        if ( $result == 1 ) {
            S_w2rep( "arrays match", "green" );
            S_set_verdict('VERDICT_PASS');
            return 1;
        }
        else {
            S_set_error( "arrays dont match", 0 );
            S_set_verdict('VERDICT_FAIL');
            return 0;
        }
    }
    else {
        if ( $result == 1 ) {
            GEN_printComment("arrays match");
            return 1;
        }
        else {
            GEN_printComment("arrays dont match");
            return 0;
        }
    }

}

=head2 GEN_EVAL_CompareNumArrays

	$status = GEN_EVAL_CompareNumArrays($aref_observed,$aref_expected,[$expectedStatus]);

I<B<Description:>>	Compares 2 number arrays

$aref_observed  =  array ref of observed array

$aref_expected = array ref of expected array

$expectedStatus = 'Equal' or 'NotEqual' (this is an optional parameter). Verdict will be set only if this parameter is defined!

Calls internally S_compare_num_arrays

I<B<Return:>> 1 if arrays match, 0 if not

I<B<Verdict:>> PASS or FAIL based on $expectedStatus

Equal: PASS if both arrays match, else FAIL

NotEqual: FAIL if both arrays match, else PASS

I<B<Error:>> error if array is empty

=cut

sub GEN_EVAL_CompareNumArrays {
    GEN_print_caller();

    my $aref_observed  = shift;
    my $aref_expected  = shift;
    my $expectedStatus = shift;

    #unless(scalar(@$aref_observed)){
    #	S_set_error("observed array is empty", 109);
    #	return undef;
    #}

    return 1 if $main::opt_offline;

    unless ( defined $aref_expected and scalar(@$aref_expected) ) {
        S_set_error( "expected array is empty", 109 );
        return undef;
    }

    my $result = S_compare_num_arrays( $aref_observed, $aref_expected );
    if ( defined $aref_observed and defined $aref_expected and ( ref($aref_observed) eq "ARRAY" ) and ( ref($aref_expected) eq "ARRAY" ) ) {
        GEN_printComment("Expected: @$aref_expected \n Observed: @$aref_observed");
    }

    if ( defined $expectedStatus and $expectedStatus =~ m/NotEqual/i ) {
        if ( $result == 0 ) {
            S_w2rep( "arrays dont match", "green" );
            S_set_verdict('VERDICT_PASS');
            return 0;
        }
        else {
            S_set_error( "arrays match", 0 );
            S_set_verdict('VERDICT_FAIL');
            return 1;
        }
    }
    elsif ( defined $expectedStatus and $expectedStatus =~ m/Equal/i ) {
        if ( $result == 1 ) {
            S_w2rep( "arrays match", "green" );
            S_set_verdict('VERDICT_PASS');
            return 1;
        }
        else {
            S_set_error( "arrays dont match", 0 );
            S_set_verdict('VERDICT_FAIL');
            return 0;
        }
    }
    else {
        if ( $result == 1 ) {
            GEN_printComment("arrays match");
            return 1;
        }
        else {
            GEN_printComment("arrays dont match");
            return 0;
        }
    }

}

=head1 Function 'pd'
=head2 GEN_setECUMode

	$status = GEN_setECUMode ($mode);

I<B<Description:>>  Set the ECU to an appropriate mode

$mode =  can be ProductionMode/RemoveProductionMode, IdleMode/RemoveIdleMode, OverVoltage, UnderVoltage or NormalVoltage

AB12 plant modes can also be set with this function. Allowed labels:

	PlantMode7_ElectronicFiringMode
	PlantMode9_AIxTestMode
	PlantMode10_SuppressComFaults
	PlantMode12_OnlyPlantDemActive
	RemovePlantModes

I<B<Return:>>  1 if mode is successfully set, else return 0

I<B<Verdict:>>  none

I<B<Error:>>  sets error for invalid mode

=cut

sub GEN_setECUMode {
    GEN_print_caller();

    my $mode = shift;
    my $status;
	my ($systemMode);
	
	GEN_printComment("Original value=$systemMode_old");
    unless ( defined $mode ) {    #check if parameter is defined
        S_set_error( "Parameter not defined", 114 );    #Error!
        return 0;
    }

    if ( ( $mode =~ m/^RemoveProductionMode$/i ) ) {
        GEN_printComment("Removing ECU from Production Mode");
        $status = PD_WriteMemoryByName( "S_PDMProgVarTbl1_XXE.V_ProdMode_U16X", [ 00, 00 ] );    #
		PD_CalculateChecksum('PROG_VAR_TBL');
		GEN_Power_on_Reset();	
    }
    elsif ( $mode =~ m/^ProductionMode$/i ) {
        GEN_printComment("Setting ECU to Production Mode");
        $status = PD_WriteMemoryByName( "S_PDMProgVarTbl1_XXE.V_ProdMode_U16X", [ 00, 12 ] );    #
		PD_CalculateChecksum('PROG_VAR_TBL');
		GEN_Power_on_Reset();		
    }
    elsif ( $mode =~ m/^RemoveIdleMode$/i ) {
        GEN_printComment("Removing ECU from Idle Mode");
                                                                    #AB12
             GEN_printComment("To be written:$systemMode_old");                                                                                    #TO BE UPDATED
			$status=PD_WriteMemoryByName('rb_swv_SwVersionNvmCfg_dfst.ProjectId_u8',[$systemMode_old]);
			GEN_printComment("Status after writting: $status");
			GEN_Power_on_Reset();
			PD_ECUlogin();
			PD_ClearFaultMemory();
			S_wait_ms(5000);
			$systemMode=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
			GEN_printComment("$systemMode");
			if($systemMode=='0x0005')
			{
				S_w2log(1,"System is in Normal Mode",'Green');
			}
			else
			{
				S_set_error("ECU is still in IdleMode");
			}
        
    }
    elsif ( ( $mode =~ m/^IdleMode$/i ) ) {
        GEN_printComment("Setting ECU to Idle Mode");
		
         
				$systemMode_old=S_aref2hex(PD_ReadMemoryByName('rb_swv_SwVersionNvmCfg_dfst.ProjectId_u8'));		#AB12
                GEN_printComment("Loop Started");                                                                                                                      #TO BE UPDATED
				$status=PD_WriteMemoryByName('rb_swv_SwVersionNvmCfg_dfst.ProjectId_u8',[05]);
				GEN_printComment("Status=$status");
				GEN_Power_on_Reset();
				PD_ECUlogin();

				$systemMode=S_aref2hex(PD_ReadMemoryByName('rb_bswm_ActualSystemMode_au16(0)'));
				GEN_printComment("$systemMode");
			if($systemMode=='0x0004')
			{
				S_w2log(1,"System is in Idle mode",'red');
			}
			else
			{
				S_set_error("ECU is not in IdleMode");
			}        
            return 0;
      
    }
    
#/*! DEF ENUM rb_ssm_PlantModes_ten */
#/* List of the available plant modes. */
#/*! rb_ssm_AdaptedTestThresholdMode_e:    Adapted test thresholds plant mode. */
#/*! rb_ssm_NoExternalDevicesMode_e:    No external device plant mode. */
#/*! rb_ssm_NoErChargingMode_e:    No ER charging plant mode. */
#/*! rb_ssm_NoFaultQualiService_e:    No fault qualification plant service mode. */
#/*! rb_ssm_FastFaultQualiMode_e:    Fast fault qualification plant mode. */
#/*! rb_ssm_DisableDeploymentMode_e:    Disable deployment plant mode. */
#/*! rb_ssm_ElectronicFiringMode_e:    Electronic firing plant mode. */
#/*! rb_ssm_SuppressPesFaults_e:    Suppress PES faults plant mode. */
#/*! rb_ssm_AIxTestMode_e:    AIO and AIN test mode. */
#/*! rb_ssm_SuppressComFaults_e:    Suppress COM faults plant mode. */
#/*! rb_ssm_PerformEmcCapTests_e:    Perform Emc Cap tests plant mode. */
#/*! rb_ssm_OnlyPlantDemActive_e:    Only plant fault memory (DEM) active plant mode. */
#/*! rb_ssm_AutomaticPlantModeDetection_e:    Automatic plant mode detection plant mode. */
#/*! rb_ssm_Smi7OtpProgramming_e:    Perform OTP programming of SMI7 sensors. */
#/*! rb_ssm_FastSleepMode_e:    Fast activation of sleep mode plant mode. */
#/*! rb_ssm_Smi7RampUpSelfDiagnosis_e:    SMI7 ramp up self diagnosis plant mode. */
#/*! END DEF */

    elsif ( $mode =~ m/^RemovePlantModes$/i ) {      
            
        	GEN_printComment("Removing all plant modes");                                                                                                  #AB12
            $status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [ 0x00 ] ); 
			$status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [ 0x00 ] ); 
			$status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(2)', [ 0x00 ] ); 
			GEN_Power_on_Reset();	
        
    }
    elsif ( $mode =~ m/^PlantMode7_ElectronicFiringMode/i ) {       
    
        	GEN_printComment("Setting ECU to Electronic Firing Mode - Plant Mode 7");                                                                                                    #AB12
            $status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [ 0x40 ] );
			GEN_Power_on_Reset();

    }
     elsif ( $mode =~ m/^PlantMode9_AIxTestMode/i ) {       
            
        	GEN_printComment("Setting ECU to AIx Test Mode - Plant Mode 9");                                                                                                  #AB12
            $status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [ 0x01 ] );
			GEN_Power_on_Reset();
        
    }
    elsif ( $mode =~ m/^PlantMode12_OnlyPlantDemActive/i ) {       
  
        	GEN_printComment("Setting ECU to Plant Mode 12 - OnlyPlantDemActive");                                                                                                   #AB12
            $status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [ 0x08 ] );
			GEN_Power_on_Reset();
        
    }
	elsif ( $mode =~ m/^PlantMode10_SuppressComFaults/i ) {
				GEN_printComment("Setting ECU to Plant Mode 10 - SuppressComFaults");                                                                                                   #AB12
            $status = PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(1)', [ 0x02 ] );
			GEN_Power_on_Reset();
		}	
    elsif ( ( $mode =~ m/^OverVoltage$/i ) ) {
        GEN_printComment("Setting ECU to over voltage Mode");
        LC_SetVoltage('U_BATT_OVERVOLTAGE');
        return 0;
    }
    elsif ( ( $mode =~ m/^UnderVoltage$/i ) ) {
        GEN_printComment("Setting ECU to under voltage Mode");
        LC_SetVoltage('U_BATT_UNDERVOLTAGE');
        return 0;
    }
    elsif ( ( $mode =~ m/^NormalVoltage$/i ) ) {
        GEN_printComment("Setting ECU to normal voltage Mode");
        LC_SetVoltage('U_BATT_DEFAULT');
        return 0;
    }
    else {
        S_set_error( "Invalid mode : $mode. ECU mode is not set successfully", 0 );    #warning!
        return 0;
    }

    if ( defined $status and $status == 0 ) {
        return 0;
    }
    else {
        return 1;
    }

}

=head2 GEN_readWLStatus

	GEN_readWLStatus();

I<B<Description:>> reads warning lamp status using PD for AB 10 and AB 12.

Calls internally PD_ReadLampStates (); for AB 10
Reads rb_wimi_SysWIStatus_aen(0) value for AB 12 projects

I<B<Return:>> status of 'SysWL' 

I<B<Verdict:>> none

I<B<Error:>> undef

=cut

sub GEN_readWLStatus {

    #!!!!!!!!Define in Project FuncLib if UPDATE is REQUIRED BY CUSTOMER PROJECT!!!!!!!!!!!!!
    #Read Warning Lamp status using CD/CAN/FR or PD and return the status
	# my $ABVersion=PD_GetABGeneration() || return;
	
	return "Lamp Off" if $main::opt_offline;

	my $SysWL_status;
	
	my $value_aref  = PD_ReadLampStates() || return;
	my %Lamp_status = %$value_aref;
	
	# if($ABVersion==12)	{
		if ( $Lamp_status{'System Warning Lamp'} ) #AB12
		{
			$SysWL_status = "Lamp ".$Lamp_status{'System Warning Lamp'};   
		}
	# }
	# else
	# {
		elsif ( $Lamp_status{'SysWL'} ) #AB10
		{
			$SysWL_status = $Lamp_status{'SysWL'};   
		}
	# }
	S_w2log( 3, " GEN_readWLStatus: return '$SysWL_status'\n" );
	return $SysWL_status;
}

=head2 GEN_readPowerONCounter

    $poweronCounter_Decvalue = GEN_readPowerONCounter();

I<B<Description:>>  This Function reads the power ON Counter variable using PD and returns the decimal value

B<For AB10:> Variable used is V_POnCounter_U32E

B<For AB12:> Variable used is rb_tim_EcuOnTimeDataEe_dfst(0)..(3)

I<B<Return:>> Decimalvalue of power ON counter

I<B<Verdict:>> None

I<B<Error:>> Set the Error if the power on Counter variable is not Found in  the sad file

=cut


sub GEN_readPowerONCounter {
    GEN_print_caller();

    my $Power_ONCounter_Value_decimal;
    my $used_ECU_variable = "";

    return time() if $main::opt_offline;

    my $AB_generation = PD_GetABGeneration() || return;
    unless( $AB_generation == 10 || $AB_generation == 12 ) {
        S_set_error( "AB_generation '$AB_generation' not supported" ); 
        return;
    }

    if ( $AB_generation == 12 ) {
    	
        PD_ECUlogin() || return;

        $used_ECU_variable = "rb_tim_EcuOnTimeDataEe_dfst(0)..(3)";

    	my $PowOnCounter_byte0 = "rb_tim_EcuOnTimeDataEe_dfst(0)";  
    	my $PowOnCounter_byte1 = "rb_tim_EcuOnTimeDataEe_dfst(1)";
    	my $PowOnCounter_byte2 = "rb_tim_EcuOnTimeDataEe_dfst(2)";
    	my $PowOnCounter_byte3 = "rb_tim_EcuOnTimeDataEe_dfst(3)";
    	
    	
    	my $PowOnCounter_byte0_value = PD_ReadMemoryByName( $PowOnCounter_byte0 );
    	my $PowOnCounter_byte1_value = PD_ReadMemoryByName( $PowOnCounter_byte1 );
    	my $PowOnCounter_byte2_value = PD_ReadMemoryByName( $PowOnCounter_byte2 );
    	my $PowOnCounter_byte3_value = PD_ReadMemoryByName( $PowOnCounter_byte3 );
    
        unless(    @$PowOnCounter_byte0_value        # each list must contain a value
                && @$PowOnCounter_byte1_value 
                && @$PowOnCounter_byte2_value
                && @$PowOnCounter_byte3_value                
                )  
        {
            S_set_error( "Error while reading ECU labels" ); return;        
        }      
    
    	my $PowOnCounter_hex = [
    								$PowOnCounter_byte3_value->[0] , # byte 3 
    								$PowOnCounter_byte2_value->[0] , # byte 2
    								$PowOnCounter_byte1_value->[0] , # byte 1 
    								$PowOnCounter_byte0_value->[0] , # byte 0 
    							];
    	
        # convert [ 0x00 , 0x00 , 0x01 , 0x01 ] => 17 dec
        $Power_ONCounter_Value_decimal = S_aref2dec ( $PowOnCounter_hex , U32 ) || return;	
        	
    }
    
    if ( $AB_generation == 10 ) {
        
        if ( PD_GetAddressByName('V_POnCounter_U32E') != 1 )  # Note: PD_GetAddressByName return 1 for Error
        {
            $used_ECU_variable = "V_POnCounter_U32E";
            my $value_aref_U32 = PD_ReadMemoryByName('V_POnCounter_U32E');
            $Power_ONCounter_Value_decimal = S_aref2dec( $value_aref_U32, U32 ) || return;
        
        } 
        elsif ( PD_GetAddressByName('V_POnCounter_U16E') != 1 )  # Note: PD_GetAddressByName return 1 for Error
        {
            $used_ECU_variable = "V_POnCounter_U16E";
            my $value_aref_U16 = PD_ReadMemoryByName('V_POnCounter_U16E');
            $Power_ONCounter_Value_decimal = S_aref2dec( $value_aref_U16, U16 ) || return;
        }
        else 
        {
            S_set_error( "No variable known for AB10 ( V_POnCounter_U32E and V_POnCounter_U16E are not available)" ); 
            return;
        }
    }

    unless( defined $Power_ONCounter_Value_decimal ) {
        S_set_error( "unexpected error while calculating 'Power_ONCounter_Value_decimal'" ); return;
    }

	S_w2log(  3 , " GEN_readPowerONCounter: Return Power On Counter = $Power_ONCounter_Value_decimal (read from $used_ECU_variable / AB $AB_generation)\n" );
	return $Power_ONCounter_Value_decimal;
}




=head1 Function 'various'
=head2 GEN_generateUniqueTraceName

	$tracePath = GEN_generateUniqueTraceName([$Label]);

I<B<GEN_generateUniqueTraceName:>>	This Functions creates Canoe Trace file Name with Testcase name and added the Link to the testcase

I<B<Parameters:>> Optional parameter $Label - A label to append to trace name in oder to make the trace name unique

if label is not provided, the TC name will be appended with current time

I<B<Return:>> Trace File Name with path (Complete path)

I<B<Verdict:>> None

=cut


sub GEN_generateUniqueTraceName {
	
	GEN_print_caller();

	my $Label = shift;

	my $current_testcase_name;
	$current_testcase_name =$main::CURRENT_TC;
	$current_testcase_name=~ s/\./-/g; 
	if (defined $Label){
		$current_testcase_name = "$current_testcase_name-Trace_".$Label.".asc";
	}
	else{
		$current_testcase_name = "$current_testcase_name-Trace_".time().".asc";
	}
	GEN_printComment("Trace Name Generated : $current_testcase_name");
	
	return ("$main::REPORT_PATH/$current_testcase_name");
}


=head2 GEN_printLink

	$Path = GEN_printLink($Path);

I<B<GEN_generateUniqueTraceName:>>	This Functions creates clickable link in the report for a given path

I<B<Parameters:>> $Path - A path of the file

I<B<Return:>> path of the file

I<B<Verdict:>> None

=cut


sub GEN_printLink
{
	GEN_print_caller();
	
	my $Path = shift;
	
	my $rel_path = File::Spec->abs2rel($Path,$main::REPORT_PATH) ;
	GEN_printComment("Link for the file :<u><a href=\"./$rel_path\" style=\"color:purple\" > $rel_path </a></u>");
	
	return $Path;

}

=head2 GEN_printTableToReport

	GEN_printTableToReport($titles_aref, $tableContents, [$printIndex]);

I<B<Description:>> prints a table generated for a given titles for each column and given table content. 

$titles_aref: reference to a list containing titles for each column
	ex:titles_aref = ['Squibname', 'FaultName', 'Verdict']
$tableContents: reference to a array of references to an arrays containing contents of each row
ex:$tableContents = [['AB1FD', 'Short2GND', 'PASS'],
				  ['KB2RP', 'Short2VBAT', 'FAIL'],
				  ['BT3FD', 'Openline', 'PASS'],
				  ]
$printIndex = optional parameter and $printIndex = yes if user intends to print index also.
				  
table may look like:
Index Suibname FaultName   Verdict
1     AB1FD    Short2GND   PASS
2     KB2RP    Short2VBAT  FAIL
3	  BT3FD    Openline    PASS

I<B<Return:>> 1

I<B<Verdict:>> None

I<B<Error:>> sets error if mandatory parameters are missing

=cut

sub GEN_printTableToReport{
	my $titles_aref = shift;
	my $tableContents = shift;
	my $printIndex = shift;

	#error handling for the missing parameters
    unless (defined $titles_aref){
        S_set_error( "Missing mandatory parameter titles_aref \n", 110 );
    }	
	if(ref($titles_aref) ne "ARRAY"){
		S_set_error( "titles_aref is not an array reference\n");
	}
    unless (defined $tableContents){
        S_set_error( "Missing mandatory parameter tableContents \n", 110 );
    }
	foreach my $aref (@$tableContents){
		if(ref($aref) ne "ARRAY"){
			S_set_error( "SoOne or more elements of array tableContents is not an array reference\n");
		}	
	}
	if(defined $printIndex){
		if($printIndex ne 'yes'){
			S_set_error("wrong parameters printIndex,  Allowed values is = yes \n", 109 );
		}	
    }

	#column titles
	my @table;
	if($printIndex eq 'yes'){
		push(@table,'<div class="w2rep"><TABLE class="tablesorter"><TR><TH>Index</TH>');	
	}
	else{
		push(@table,'<div class="w2rep"><TABLE class="tablesorter"><TR>');	
	}	
	foreach my $title (@$titles_aref){	
		push(@table,"<TH>$title</TH>");	
	}
	push(@table,'</TR>');		

	#table content rows
	my $index = 1;
	foreach my $rowContent_aref (@$tableContents){	
		if($printIndex eq 'yes'){
			push(@table,"<TR><TD>$index</TD>");	
		}
		else{
			push(@table,'<TR>');	
		}
		foreach my $rowContent (@$rowContent_aref){
			push(@table,"<TD>$rowContent</TD>");	
		}
		push(@table,'</TR>');
		$index++;
	}	

	#close table
	push( @table, "</TABLE></div>\n" );

	#make it a string
	my $tableString = join( '', @table );

	#print to report
	S_w2rep("$tableString");

	return 1;	
}

=head2 GEN_generateValuesForTesting

	$boundaryTestingValues_aref = GEN_generateValuesForTesting($boundaries_aref, $technique, [$delta]);

I<B<Description:>> generates a list of values from the given boundaries using Equivalence Partitioning or Boundary value analysis technique.

$boundaries_aref: reference to a list containing boundaries. ex: [6, 12, 18] are the boundary values of supply voltages.
Note: removes the duplicate boundaries if any from the list @$boundaries_aref
$technique: 'BVT' = boundary value testing technique, 'EPT' = Equivalence Partitioning, 'BVT_EPT' = boundary value analysis technique and Equivalence Partitioning
$delta: parameter relevant only when $technique = 'BVT', a delta value to determine the valid neighbouring values to a boundary

I<B<Example:>>
1)  $boundaries_aref = [6, 18]
	$technique = 'BVT_EPT'
	$delta = 0.1
	$boundaryTestingValues_aref = [5.9, 6, 6.1, 12, 17.9, 18, 18.1]
	values (5.9, 6, 6.1, 17.9, 18, 18.1) are generated using BVT and values (12) are generated using EPT

2)  $boundaries_aref = [6, 18]
	$technique = 'BVT'
	$delta = 0.1
	$boundaryTestingValues_aref = [5.9, 6, 6.1, 17.9, 18, 18.1]
	
3)  $boundaries_aref = [6, 18]
	$technique = 'EPT'
	$boundaryTestingValues_aref = [12]

I<B<Return:>> reference to a list containing the values generated using boundary value analysis technique and /or Equivalence Partitioning for a given boundaries.

I<B<Verdict:>> None

I<B<Error:>> sets error if mandatory parameters are missing

=cut

sub GEN_generateValuesForTesting{
	GEN_print_caller();

	my $boundaries_aref = shift;
	my $technique = shift;
	my $delta = shift;
#error handling for the missing parameters
    unless (defined $boundaries_aref){
        S_set_error( "Missing mandatory parameter $boundaries_aref \n", 110 );
        GEN_print_caller();
    }	
	if(ref($boundaries_aref) ne "ARRAY"){
		S_set_error( "boundaries_aref is not an array reference\n");
        GEN_print_caller();
	}	
    unless (defined $technique){
        S_set_error( "Missing mandatory parameter $technique \n", 110 );
        GEN_print_caller();
    }
	if(($technique ne 'BVT') && ($technique ne 'EPT') && ($technique ne 'BVT_EPT')){	
		S_set_error( "wrong parameters $technique,  Allowed values are: BVT or EPT or BVT_EPT\n", 109 );
		GEN_print_caller();
	}
	if(($technique eq 'BVT') || ($technique eq 'BVT_EPT')){
		unless (defined $delta){
			S_set_error( "Missing mandatory parameter $delta \n", 110 );
			GEN_print_caller();
		}	
	}
	
#removes the duplicate boundaries if any	
	my @boundaries;
	foreach my $value1 (@$boundaries_aref){
	  if(!grep(/"$value1"/, @boundaries)){
		 push( @boundaries, $value1);
	  }
	}	
#generating values at the baoundaries
	my @tempBoundaryTestingValues;
	if(($technique eq 'BVT') || ($technique eq 'BVT_EPT')){		
		foreach my $value2 (@boundaries){
			push(@tempBoundaryTestingValues, ($value2 - $delta));
			push(@tempBoundaryTestingValues, $value2);
			push(@tempBoundaryTestingValues, ($value2 + $delta));
		}
	}	
#additionally generating values between the neighbouring baoundaries
	if(($technique eq 'EPT') || ($technique eq 'BVT_EPT')){	
		for(my $index = 0; $index < (scalar(@boundaries) - 1); $index++){
			push(@tempBoundaryTestingValues, (($boundaries[$index] + $boundaries[$index + 1]) / 2));
		}
	}	

#removes the duplicate boundaries if any	
	my @boundaryTestingValues;
	foreach my $value3 (@tempBoundaryTestingValues){
	  if(!grep(/\Q$value3\E/, @boundaryTestingValues)){
		 push( @boundaryTestingValues, $value3 );
	  }
	}	
#sorting the generated values in ascending order
	my @sortedBoundaryTestingValues = sort {$a <=> $b} @boundaryTestingValues;
#returnung generated values
	return \@sortedBoundaryTestingValues;
}

=head2 GEN_filterChildarrayFromParentarray

	$filteredarray_aref = GEN_filterChildarrayFromParentarray($parentarray_aref, $childarray_aref);

I<B<Description:>> generates reference to array containing the elements those are in parent array (superset), but not in child array (subset)

$parentarray_aref: reference to a parent array (superset)
childarray_aref: reference to a child array (subset)

I<B<Example:>>
$parentarray_aref = ['a', 'b', 'c']
$childarray_aref = ['d', 'b', 'e', 'f']
$filteredarray_aref = ['a', 'c']

I<B<Return:>> reference to a filtered array

I<B<Verdict:>> None

I<B<Error:>> sets error if mandatory parameters are missing

=cut

sub GEN_filterChildarrayFromParentarray{
	GEN_print_caller();

	my $parentarray_aref = shift;
	my $childarray_aref = shift;
	#error handling of mandatory parameters
    unless (defined $parentarray_aref){
        S_set_error( "Missing mandatory parameter $parentarray_aref \n", 110 );
        GEN_print_caller();
    }	
	if(ref($parentarray_aref) ne "ARRAY"){
		S_set_error( "parentarray_aref is not an array reference\n");
        GEN_print_caller();
	}		
    unless (defined $childarray_aref){
        S_set_error( "Missing mandatory parameter $childarray_aref \n", 110 );
        GEN_print_caller();
    }	
	if(ref($childarray_aref) ne "ARRAY"){
		S_set_error( "childarray_aref is not an array reference\n");
        GEN_print_caller();
	}	
	
	my @filteredarray;
	my $skip = 0;
	#loop through each element of parent array
	foreach my $parentarrayElement(@$parentarray_aref){
		$skip = 0;
		#loop through each element of child array
		foreach my $childarrayElement (@$childarray_aref){
			#compare element of parent array against that of element of child array
			if($childarrayElement eq $parentarrayElement){
				$skip = 1;
				last;
			}
		}
		#store the element of parent array only if it is not matching with any of the element of child array
		if($skip == 0){
			push (@filteredarray, $parentarrayElement);
		}
	}
	#returning reference to array containing the elements those are in parent array, but not in child array
	return \@filteredarray;
}

#!!TBD: Not yet exported. Implementation is in progress!!
#The below functions are used to collapse and expand a particular section of a report. Use case: to hide some details if not needed like - cyclic diagnositc response loops which make the report very long

sub GEN_collapseSectionStart{
	my $comment = shift;
	
	unless(defined $comment){
		$comment = "Expand"; #to expand and collapse
	}
	
	my $randomNum1 = rand ();
	my $randomNum2 = rand ();
	
	my $Expand = <<EOHTML;  
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">   
<head>   
<title>The div Expand and Collapse control function</title>
<link href="DivControlFunction.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript">
<!-- Begin
function ExpandCollapse(ElementId) {
	var ClickedElement = document.getElementById(ElementId);
	var SectionElement = ClickedElement.parentNode;
	var GroupElement = SectionElement.parentNode;
	var SpanSiblings = SectionElement.getElementsByTagName("span");
	var DivSiblings = SectionElement.getElementsByTagName("div");
	if (ClickedElement.innerHTML == "- hide") {
		// this code turns this section off
		ClickedElement.innerHTML = "+ show";
		DivSiblings[0].style.display = "none";
	} 
	else {
		// this code turns this section on and all other sections off
		ClickedElement.innerHTML = "- hide";
		DivSiblings[0].style.display = "block";
		var otherSections = GroupElement.getElementsByTagName("div");
		for (i=0; i<otherSections.length; i++) {
			// first make sure this div is an immediate child of the parent group
			if (otherSections[i].parentNode.id == GroupElement.id ) {
				// next make sure this section is not the one you just expanded
				if (otherSections[i].id != SectionElement.id) {
					// collapse this section
					var x = document.getElementById(otherSections[i].id);
					var SpanSiblings = x.getElementsByTagName("span");
					var DivSiblings = x.getElementsByTagName("div");
					SpanSiblings[0].innerHTML = "+ show";
					DivSiblings[0].style.display = "none";
				}
			}
		}
	}
}
//  End -->
</script>
</head>
<body>
<div class=""><div id = "CollapseText" class="TCtext">
<span id="span 1 $randomNum1" class="clickit" onclick="ExpandCollapse(this.id);" style="cursor: pointer; color:Blue;">+ show</span> <span style="color:DarkOrchid; font-weight:bold">$comment </span>
<div id="div 1 $randomNum2" style="display: none;">
EOHTML

#		SpanSiblings[1].innerHTML = "Show";
#		SpanSiblings[1].innerHTML = "Hide";
#					SpanSiblings[1].innerHTML = "Show";
#loglevel1, TCtext

#<span id="span 2 $randomNum1" style="color:DarkOrchid; font-weight:bold">$comment</span>
	push( @TC_HTML_TEXT, "$Expand"  );	
	
}

=head2 GEN_AutoECUFlash

	GEN_AutoECUFlash();
	
I<B<Description:>> This function flash ECU software(AB12) automatically with the help of PRITT Tool.

This function will get the SW path base on the .sad file declared in CFG file, then get SW (.hex file) to flash.

ECU_SW_AutoFlash will be called, required to configure Renesas tool in test bench. Refer below link for detail:

http://si-airbag-web.de.bosch.com/support/testportal/common/LIFT/APIdocumentation/latest/modules/LIFT_ECU_SW_Flash.html#ECU_SW_AutoFlash

Example:
GEN_AutoECUFlash()

I<B<Return:>> None

=cut 


sub GEN_AutoECUFlash {

	my $SW2flash;

	$SW2flash = $LIFT_config::SAD_file;
	unless ($SW2flash) { S_set_error("could not get SAD file from LIFT_config"); return }
	$SW2flash =~ s/\.sad$/.hex/i;
	$SW2flash =~ s/\//\\/g;
	
	$SW2flash = File::Spec->rel2abs($SW2flash);
    $SW2flash = File::Spec->canonpath($SW2flash);
    
	my $SW_file_name = basename($SW2flash);
	
	S_teststep( "Flash SW $SW_file_name ... ", 'AUTO_NBR' );
	my $flash_result = ECU_SW_AutoFlash($SW2flash);
	_EDR_initialization();
	return 1;
}


sub GEN_collapseSectionEnd{
	
	my $ExpandEnd = <<EOHTML; 
	<BR>
	</div>
</div>
</div>

</body>
</html>
EOHTML

	push( @TC_HTML_TEXT, "$ExpandEnd"  );

}
sub _EDR_initialization {

    return 1 if ($main::opt_offline);

    # --- EDR Initialization start ---
    S_teststep( "EDR Initialization", 'AUTO_NBR' );

    S_teststep_2nd_level( "Read 'rb_dcbm_FirstStartUpIndication_u16' ", 'AUTO_NBR' );
    my $edr_initialization_value = S_aref2hex( PD_ReadMemoryByName_NOERROR('rb_dcbm_FirstStartUpIndication_u16'), U16 );

    unless ( defined $edr_initialization_value ) {
        S_w2rep(" EDR Initialization: Could not read 'rb_dcbm_FirstStartUpIndication_u16' - do nothing \n");
        return 1;
    }

    S_teststep_detected(" 'rb_dcbm_FirstStartUpIndication_u16' = $edr_initialization_value");

    # clear EDR when initialized
    if ( $edr_initialization_value eq '0x5555' )    # 0x5555 = EDR is initialized --> ADAPT IF REQUIRED
    {
        S_w2rep("EDR is already initialized ( rb_dcbm_FirstStartUpIndication_u16 = 0x5555) - just erase it now\n");

        S_teststep_2nd_level( "Clear Crash Recorder", 'AUTO_NBR' );
        PD_ClearCrashRecorder();
        S_wait_ms(2000);
        S_w2rep("EDR initialization finished\n");
        return 1;
    }

    S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
    LC_ECU_Reset(1);                                # make sure that power on counter is >= 2

    S_teststep_2nd_level( "Set a plant mode (mode 6 / 20hex / 32 dec (Airbag deployment shall be prohibited in the algorithm) ) to enable EDR initialization", 'AUTO_NBR' );

    #    PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00000001] ) || return;
    PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00100000] ) || return;
    S_wait_ms(200);

    S_teststep_2nd_level( "Reset ECU in order to activate PLant mode and trigger EDR initialzation procedure", 'AUTO_NBR' );
    LC_ECU_Reset(1);

    # Wait for EDR initialization to be completed
    my $maxWaitTime_ms          = 60000;                                         # 60 sec, 1 minute --> ADAPT IF REQUIRED
    my $intervalWaitTime_ms     = 1000;
    my $maxWaitTimeIteration    = $maxWaitTime_ms / $intervalWaitTime_ms + 1;    # 1 loop: 2000ms wait time
    my $edr_expected_init_value = '0x5555';

    my $edrInitialized   = 0;
    my $totalWaitTime_ms = 0;
    S_teststep_2nd_level( "Read cyclic 'rb_dcbm_FirstStartUpIndication_u16'", 'AUTO_NBR' );
    foreach my $waitTimeIteration ( 1 .. $maxWaitTimeIteration ) {
        $edr_initialization_value = S_aref2hex( PD_ReadMemoryByName_NOERROR('rb_dcbm_FirstStartUpIndication_u16'), U16 );
        S_teststep_detected(" (Loop $waitTimeIteration / $maxWaitTimeIteration) 'rb_dcbm_FirstStartUpIndication_u16' = $edr_initialization_value");
        if ( $edr_initialization_value eq $edr_expected_init_value )             # 0x5555 = EDR is initialized --> ADAPT IF REQUIRED
        {
            $edrInitialized = 1;
            S_teststep_expected(" 'rb_dcbm_FirstStartUpIndication_u16' must be $edr_expected_init_value ");
            S_w2rep("EDR initialized successfully after ECU reset + $totalWaitTime_ms ms");
            last;
        }

        S_wait_ms($intervalWaitTime_ms);
        $totalWaitTime_ms += $intervalWaitTime_ms;
    }

    S_teststep_2nd_level( "Reset plant mode", 'AUTO_NBR' );
    PD_WriteMemoryByName( 'rb_sycg_PlantModes_dfst.rb_sycg_ActivePlantModes_au8(0)', [0b00000000] ) || return;
    S_wait_ms(200);

    S_teststep_2nd_level( "Reset ECU", 'AUTO_NBR' );
    LC_ECU_Reset(1);

    unless ($edrInitialized) {
        S_set_verdict(VERDICT_FAIL);
        S_w2rep("EDR initialization could not be completed within max wait time of 60000 ms (1 minute).\n"
              . "Measure the required initialization time with PSDiag fast diagnosis and adapt max wait time if required.\n"
              . "Procedure for measurement:\n"
              . "- Turn on ECU and check that Power on Counter is >= 2\n"
              . "- Set plant mode\n"
              . "- Check value of variable 'rb_dcbm_FirstStartUpIndication_u16' with fast diagnosis and get time when it goes to 0x5555.\n"
              . "(Note: 0x5555 is the value for EDR initialized in CA - this value is configurable in SPS and might be different in your project!)" );
        return;
    }

    S_teststep_2nd_level( "Just wait some extra time (5sec) before clearing EDR Crash Recorder", 'AUTO_NBR' );
    S_wait_ms(5000);
    
    S_teststep_2nd_level( "Clear EDR Crash Recorder", 'AUTO_NBR' );
    PD_ClearCrashRecorder();
    S_wait_ms(2000);

    return 1;
}
1;
