//Global Declarations
var ie = (document.all) ? true : false;

function hideClass(objClass)
{
    //  This function will hide Elements by object Class
    //  Works with IE and Mozilla based browsers
    var elements = (ie) ? document.all : document.getElementsByTagName('*');
    var rgxp = new RegExp(objClass);
    for (i=0; i<elements.length; i++)
    {
        if (elements[i].className.match(rgxp))
        {
            elements[i].style.display="none"
        }
    }
}

function showClass(objClass){
  //  This function will show Elements by object Class
  //  Works with IE and Mozilla based browsers
    var elements = (ie) ? document.all : document.getElementsByTagName('*');
    var rgxp = new RegExp(objClass);
    for (i=0; i<elements.length; i++)
    {
        if (elements[i].className.match(rgxp))
        {
             elements[i].style.display="block"
        }
  }
}

function colorelement(elementID, bgcolor, textcolor)
{
	document.getElementById(elementID).style.backgroundColor = bgcolor;
	document.getElementById(elementID).style.color = textcolor;
}

function levelbuttonON(levelNum)
{
	colorelement('lev'+levelNum, '#567F9F', '#FFFFFF')
}

function levelbuttonOFF(levelNum)
{
	colorelement('lev'+levelNum, '#E2E8EE', '#000000')
}


function showLevel(level)
{
    if (document.getElementById)
    {
        var i
		for (i=5;i>=0;i--)
		{
			if (i<=level)
			{
				if (i>0)
				{
					showClass(i);
				}
				levelbuttonON(i)
			}
			else
			{
				if (i>0)
				{
					hideClass(i);
				}
				levelbuttonOFF(i)
			}
		}
    showClass('w2rep');
    showClass('teststep');
    }
}



function hideall()
{
    if (document.getElementById)
    {
        var i
		for (i=0;i<=5;i++)
		{
			if (i>0)
			{
				hideClass(i);
			}
			levelbuttonOFF(i)
		}
    	hideClass('w2rep');
	hideClass('teststep')
    }
}

