
#!usr\bin\perl

# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
use strict;
use warnings;

# 'our' scope, because the variable is used in LIFT_general also
our $LIFT_exec_path;

BEGIN {

    use File::Basename;
    use Config;
    $LIFT_exec_path = dirname($0);

    print "ENGINE called by $^X\n";

    unless ( defined $ENV{TURBOLIFT_PERL_HOME} ) {
        print "ENVIRONMET VARIABLE %TURBOLIFT_PERL_HOME% not defined\nplease execute Engine/run_once/_run_once.bat !!!\n\7";
        sleep(10);
        exit;
    }
    if ( uc($^X) ne uc("$ENV{TURBOLIFT_PERL_HOME}\\bin\\perl.exe") ) {
        print "wrong perl, recalling engine with TURBOLIFT_PERL %TURBOLIFT_PERL_HOME% = $ENV{TURBOLIFT_PERL_HOME} ...\n";
        system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $0 @ARGV");
        print "recalling done\n";
        exit;
    }

    #check the supported perl version during compilation or BEGIN time
    my @supportedPerlVersions = qw(5.12.x);

    # change the format of perl version from 5.12 to 5.012
    my @versions = map { sprintf( "%d.%03d", split( /\./, $_ ) ) } @supportedPerlVersions;
    my $currentVersion = substr( $], 0, 5 );    # extract first five characters of perl version $] (ex., 5.012)
    unless ( ( grep { /$currentVersion/ } @versions ) && $Config{ptrsize} == 4 ) {
        my $perl_bitness = ( $Config{ptrsize} == 4 ) ? "32-bit" : "64-bit";

        # log the error message with complete details to the console
        print "\n\n************* Important Message from TurboLIFT ************** \n\n";
        print "\n  I am supported only in <" . join( ", ", @supportedPerlVersions ) . "> Perl 32-bit version(s). \n\n    Current version of Perl : $^V $perl_bitness\n\n";
        print "  TODO ==> Please install the correct version of Perl and continue.\n\n";

        # wait for user key & exit
        system('pause');
        exit;
    }

    #
    # avoid warning subroutine redefined
    #
    local $SIG{__WARN__} = sub {
        my $warning = shift;
        warn $warning unless $warning =~ /Subroutine .* redefined at/;
    };

    # add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/Common_library";
    unshift @INC, "$LIFT_exec_path/modules/Functional_layer";
    unshift @INC, "$LIFT_exec_path/modules/Convenience_layer";
    unshift @INC, "$LIFT_exec_path/funclib_generic";

    Add_paths("$LIFT_exec_path/modules/Device_layer");

    # support for projects in MKS; shared MKS projects are checked out to the following folders
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_CustLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_Project";

    #
    # paths for custlib and test areas are added in PrepareCampaignExecution because the path to config folder is required for them
    #

    sub Add_paths {
        my $path      = shift;
        my $subsubDir = shift;
        if ( -d $path ) {
            unshift @INC, $path;
            opendir my $dh, $path or die "$0: opendir: $!";

            # get all sub-directories which are not . or ..
            my @subDirs = grep { -d "$path/$_" && !/^\.{1,2}$/ } readdir($dh);

            #print "sub dirs: @subDirs\n";
            foreach my $subDir (@subDirs) {
                my $fullPath = "$path/$subDir";
                $fullPath .= "/$subsubDir" if defined $subsubDir;
                unshift @INC, $fullPath;
            }
        }
        return 1;
    }

}

#### MODULES ####
use Getopt::Long;
use File::Basename;
use File::Find;
use File::Copy;
use File::Spec;
use File::Path;
use File::Slurp;
use LIFT_general;
use Cwd 'abs_path';
my $Registry;
use Win32::TieRegistry ( TiedRef => \$Registry );
use Win32::Process;    # for killing perl
use Win32;
use XML::LibXML;
use Sys::Hostname;
use JSON::PP;
use Digest::MD5;
use Dancer qw(get post put patch del set dance params status request :script);
use Try::Tiny;
set serializer => 'JSON';
set logger     => 'console';

#set port => 443; # default 3000

###------------------------------------------------------------------
### VARIABLES OF MAIN
###------------------------------------------------------------------
use vars qw($ProjectDefaults $REPORT_PATH $TC_REPORT_NAME $CAMPAIGN_STATUS $RERUN_PATH $LIFT_EXEC_OPTIONS_href );

our $CURRENT_TC = "NOT_SET";

my $RERUN_name = '_snapshot_';

# define all function names which will be called in each testcase module
my $para_init_func        = "TC_set_parameters";
my $init_func             = "TC_initialization";
my $stimu_func            = "TC_stimulation_and_measurement";
my $eval_func             = "TC_evaluation";
my $final_func            = "TC_finalization";
my $tc_purpose_var        = "PURPOSE";
my $LIFT_logo             = "$LIFT_exec_path/modules/LifT_logo_32x32.bmp";
my $LIFT_htmldataSource   = "$LIFT_exec_path/htmldata";
my $csv_result_delim      = ";";
my $csv_result_delim_repl = ",";
my $not_given             = "not given";

my $USER_STOP = 0;

#Global Declarations
my @tc_paths;
my $TC_PARA_path;
my $TC_INIT_path;
my $TC_INIT_CAMPAIGN;
my $TC_END_path;
my $TC_END_CAMPAIGN;
my $DOCS_path;
my $Simulator;
my $tc_html_dir_relative;
my $LIFT_version;
my $LIFT_version_API_docu;
my $LIFT_ProjectDescription;
my $ECU_SW_VERSION;
my $VARIANT_ID;
my $VARIANT_VERSION;
my $ECU_FINGERPRINT;
my $ECU_HW_details;
my $TTNO     = $not_given;
my $HW_ver   = $not_given;
my $HW_serNo = $not_given;
my $JUNIT_XmlRoot_href;
my $total_TCs_time          = 0;
my $checksumResultsAll_href = {};
my $checksumAdvice          = "This is the reason for the remark 'Running with a modified engine...' in your report. _main__result.txt will have no entries for test cases. Please make sure your TurboLIFT engine and test areas are baselines checked out from version control and not locally modified.";
my $modifiedEngineAdvice    = "Running with a modified engine or test area. Do not use for release testing. _main__result.txt will have no entries for test cases. Check IC test report for more information.";

my $checkpointlogtext                     = "Do not use for release testing unless you can prove that the used version is supported or you can justify using an unsupported version.<br>";
my $nw_or_path_access_err                 = "1. No Network connection  ( or )<br> 2. You do not have access rights to TurboLIFT network drive. <br> ";
my $component_version_file_access_err_log = "Check with respective Topic owners regarding the validity.<br>";
my $ALL_VERDICTS                          = {
    'TOTAL_EXECUTED_TC' => {
        VERDICT_PASS    => 0,
        VERDICT_FAIL    => 0,
        VERDICT_INCONC  => 0,
        VERDICT_NONE    => 0,
        VERDICT_BLOCKED => 0,
    },
};

# hash structure for all TCs to be executed
my $ALL_TC = {};
my %all_TC_IC;    # structure as above for IC for use in server mode
my %all_TC_EC;    # structure as above for EC for use in JUnit xml

# --------------------------------------------------------------------------------
# hash structure ALL_TC (just for reference)
#      -> <tc_number>
#           -> TC_ID        = TC_12345
#           -> TC_MODULE_FILE    = "testcases//TC_12345.pm"
#           -> TC_COMMENT   = "test xy, project Audi, manipulation of CAN signal"
#           -> TC_ERRORS    = ( 100, 107 )
#           -> TC_INIT      = 'OK' or 'ERROR' or '----'
#           -> TC_STIMU     = 'OK' or 'ERROR' or '----'
#           -> TC_EVAL      = 'OK' or 'ERROR' or '----'
#           -> TC_FINAL     = 'OK' or 'ERROR' or '----'
#           -> TC_VERDICT   = 'VERDICT_PASS' or 'VERDINCT_FAIL' or 'VERDICT_INCONC' or 'VERDICT_NONE'
#           -> TC_PARAMETER -> "MY_SCALAR_PARAMETER_1" -> "SCALAR" = 123
#                           -> "MY_LIST_PARAMETER_1" -> "LIST" = ( listval_1 , listval_2 )
#                           -> "MY_HASH_PARAMETER_1" -> "HASH" = ( "key_1" => val_1 , "key_2" => val_2 )
#           -> TC_PRJ_PARAMETER = %PRJ_PARAMETER->{"PRJ_PARAMETER_1"}
# -----------------------------------------------------------------------------

# public variables which will be set by GetOptions (module Getopt::Long)
# $opt_testlist -> testlist file to be executed
# $opt_conf -> config module to be used with project/testbed specific parameters
# $opt_offline -> runs in offline mode (HW not needed)
# $opt_silent  ->  option to avoid printing more text to console
# $opt_IC  -> to specify the Init Campaign name as a commandline argument (it will override the Initcampaign specified in CFG file)
# $opt_EC  -> to specify the End Campaign name as a commandline argument (it will override the Endcampaign specified in CFG file)
# $opt_polite ->  option to suppress the Browser pop-up
# $opt_minimalsnapshot  ->  option to take only a minimum snapshot (which includes all the Config files, testcases, parameter files)
our ( $opt_testlist, $opt_conf, $opt_exec_options_file, $opt_use_exec_options, $opt_tc_para, $opt_offline, $opt_evaluation_only, $opt_beep, $opt_silent, $opt_IC, $opt_EC, $opt_polite, $opt_simulation, $opt_minimalsnapshot, $opt_server_mode, $opt_report_overview, $opt_keep_last_SCCM_state );
our $save_name;             # name of log/report/result-files, given from user or Testlist will be taken
our $file_prefix_number;    # for function S_get_TC_number

my $TestList;               # test list file given from command option $opt_testlist

my $main_LOG_name = '_main__result.html';

my @status_msg;
my @runtime_ERRORS   = ();
my @runtime_WARNINGS = ();
my @command_line_arg;

#### HTML stuff for LIFT testcase report
my ( $OFFLINE, $tc_id_for_file_name, $tc_html_file );    #global declaration
my $LIFT_ProjectDescription_html_code = "";              #global declaration

my $pre_TC_function_text = <<EOHTML;
    <div class="TCfunction"><A NAME="LIFT_FUNCTION_NAME">LIFT_FUNCTION_NAME</A></div>
EOHTML

my $post_TC_function_text = <<EOHTML;
EOHTML

my $left_logo_html    = "";
my $right_logo_html   = "";
my $TCleft_logo_html  = "";
my $TCright_logo_html = "";

##################################
### START OF MAIN
##################################
#COMMENT-START
# Usage:
# LIFT_exec_engine.pl .....
#
#
#COMMENT-END

unless ( $LIFT_exec_path eq $Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\LIFT\\\\EnginePath"} ) {
    print "setting EnginePath to $LIFT_exec_path\n\n";
    $Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\"} = { "LIFT\\" => { "\\EnginePath" => $LIFT_exec_path } };
}

$Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\"} = { "LIFT\\" => { "\\STOPafterTC" => 0 } };

unless ( -d 'c:\temp\LIFT' ) {
    system('mkdir c:\temp\LIFT');
}
else {
    system('rmdir /S /Q c:\temp\LIFT');
    system('mkdir c:\temp\LIFT');
}

# create empty file
my $statusFile = 'c:\temp\LIFT\status.txt';
open( my $statusFh, '>', $statusFile ) or die "Could not open file '$statusFile' $!";
close($statusFh);
my $skipFile = 'c:\temp\LIFT\skip_copy.txt';
open( my $skipFh, '>', $skipFile ) or die "Could not open file '$skipFile' $!";
print $skipFh ".asc\n";
print $skipFh ".blf\n";
print $skipFh ".log\n";
print $skipFh ".mdf\n";
print $skipFh ".bak\n";
print $skipFh ".cbf\n";
close($skipFh);

#CALL LIFT_init
LIFT_init();

# LIFT_init controls
#   - read of program parameters
#   - Status Window
#   - CALLS THE sub 'LIFT_engine'
#      which runs in a big loop

##################################
### END OF MAIN
##################################

###------------------------------------------------------------------
### LIFT_init
###------------------------------------------------------------------

=head

    Subroutine Name :: LIFT_init 
    Description     :: This function initiates the Engine. Reads the options for the execution of  engine.
    Syntax          :: LIFT_init ()
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: None
    Description     :: None

=cut

sub LIFT_init {
    ###------------------------------------------------------------------
    ### GET OPTIONS : check if enough options were passed
    ###------------------------------------------------------------------

    #STEP read LIFT version
    if ( open( VERSION, "<$LIFT_exec_path/modules/Common_library/LIFT_version.txt" ) ) {
        $LIFT_version = <VERSION>;
        chop $LIFT_version;
        $LIFT_version_API_docu = <VERSION>;
        chop $LIFT_version_API_docu;
    }
    else {
        $LIFT_version          = 'could not read version information';
        $LIFT_version_API_docu = '';
        S_set_error( "Could not open file modules\\LIFT_version.txt", 0 );
    }
    close(VERSION);

    @command_line_arg = @ARGV;

    #STEP get command line arguments
    my $optionsOK = GetOptions(
        "testlist=s",             # test list file
        "conf=s",                 # config
        "tc_para=s",              # path to TC-parameter folder
        "exec_options_file=s",    # Name of exec option file with data sets
        "use_exec_options=s",     # Name of of Data Set to be used (out of exec option file)
        "beep",                   # beep after every TC
        "offline",
        "simulation",
        "evaluation_only",        # can be considered from online testscripts tp skip over
        "silent",
        "polite",
        "IC=s",
        "EC=s",
        "minimalsnapshot",
        "server_mode",
        "report_overview",
        "keep_last_SCCM_state",
    );

    #IF unknown arguments given or not all mandatory arguments given?
    if ( not $optionsOK or not $opt_conf ) {

        #IF-YES-START
        # STEP print error in console
        print "\nERROR: LIFT Engine has not received the mandatory command line arguments (-conf) (or) received additional unknown parameters. \n\nHint: \n1. Check the execution batch file \n"
          . "2. Maybe TurboLIFT perl is not properly installed: Follow the steps under 'Install TurboLIFT perl' from the Bosch Connect Wiki page 'Installing TurboLIFT and setting up a project'\n\n";

        print "Open the Bosch Connect Wiki page 'Installing TurboLIFT and setting up a project' (y/n) : ";

        # STEP ask if Bosch Connect Wiki page shall be opened
        my $option = <STDIN>;

        #STEP if option is 'y', open the webpage
        if ( $option =~ /y/i ) {
            print "\n\nTrying to open the Bosch Connect Wiki page 'Installing TurboLIFT and setting up a project' \n\n";
            system('explorer "https://connect.bosch.com/wikis/home?lang=de-de#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Installing%20TurboLIFT%20and%20setting%20up%20a%20project?section=ii10"');
        }

        #STEP return
        return;

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP error and return if both -testlist and -server_mode given as arguments
    if ( $opt_testlist and $opt_server_mode ) {
        print "\nERROR: LIFT Engine has received command line arguments -testlist AND -server_mode, but only one of them is allowed.\n";
        return;
    }

    #STEP error and return if neither -testlist nor -server_mode given as arguments
    if ( not $opt_testlist and not $opt_server_mode ) {
        print "\nERROR: LIFT Engine has NOT received command line arguments -testlist OR -server_mode. One of them must be specified.\n";
        return;
    }

    # run with option
    ### prepare the 'OFFLINE_' text for use in file name when Campaign run in OFFLINE mode
    $OFFLINE = "";
    if ($opt_offline) {
        $OFFLINE = "OFFLINE_";

    }

    #STEP create dummy test list for server mode
    if ($opt_server_mode) {
        $opt_testlist = 'C:\temp\server_mode.txt';
        open my $testlistFH, '>', $opt_testlist or die "Could not open dummy file '$opt_testlist' $!";
        close $testlistFH;
    }

    $TestList = $opt_testlist;

    #CALL CheckLiftProcesses and return if another LIFT process is running
    CheckLiftProcesses() or return;

    # CALL Update_status to show status window for first time
    Update_status();

    # CALL LIFT_engine
    LIFT_engine();

    #STEP STOP
    return 1;
}

###------------------------------------------------------------------
###
### $success = CheckLiftProcesses ();
###
### Gets the number of Windows processes that currently run LIFT_exec_engine.pl by running a power shell command.
### A number > 1 is not allowed.
###
###------------------------------------------------------------------

sub CheckLiftProcesses {

    # power shell command: gwmi win32_process -filter "CommandLine like '%LIFT_exec_engine.pl%'" | select CommandLine | Format-List *
    # has to be encoded because of too many nested quotes
    # encoding is done in the power shell:
    #   $filter = "`"CommandLine like '%LIFT_exec_engine.pl%'`""
    #   $command = "gwmi win32_process -filter $filter | select CommandLine | Format-List *"
    #   $bytes = [System.Text.Encoding]::Unicode.GetBytes($command)
    #   $encodedCommand = [Convert]::ToBase64String($bytes)
    #   echo $encodedCommand
    # output is:
    # ZwB3AG0AaQAgAHcAaQBuADMAMgBfAHAAcgBvAGMAZQBzAHMAIAAtAGYAaQBsAHQAZQByACAAIgBDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIABsAGkAawBlACAAJwAlAEwASQBGAFQAXwBlAHgAZQBjAF8AZQBuAGcAaQBuAGUALgBwAGwAJQAnACIAIAB8ACAAcwBlAGwAZQBjAHQAIABDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIAB8ACAARgBvAHIAbQBhAHQALQBMAGkAcwB0ACAAKgA=
    #
    my $command =
"PowerShell -encodedCommand ZwB3AG0AaQAgAHcAaQBuADMAMgBfAHAAcgBvAGMAZQBzAHMAIAAtAGYAaQBsAHQAZQByACAAIgBDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIABsAGkAawBlACAAJwAlAEwASQBGAFQAXwBlAHgAZQBjAF8AZQBuAGcAaQBuAGUALgBwAGwAJQAnACIAIAB8ACAAcwBlAGwAZQBjAHQAIABDAG8AbQBtAGEAbgBkAEwAaQBuAGUAIAB8ACAARgBvAHIAbQBhAHQALQBMAGkAcwB0ACAAKgA=";
    my $psReturn = qx/ $command /;    # call command in windows system and get return value

    # the output of the command looks like this:
    # CommandLine : "C:\TurboLIFT\Perl512\bin\perl.exe"
    #               "C:\Users\phc2si\Documents\TurboLIFT\TSG4\Engine\LIFT_exec_engine.pl"
    #               -conf .\c...

    my @lines = split( /CommandLine\s:/, $psReturn );

    my @liftProcesses;
    foreach my $line (@lines) {
        if ( $line =~ /perl\.exe/i and $line =~ /LIFT_exec_engine\.pl/ ) {
            push( @liftProcesses, $line );
        }
    }

    if ( @liftProcesses > 1 ) {
        my $numberOfProcesses = @liftProcesses;
        print "\nERROR: LIFT Engine is running $numberOfProcesses times (including this instance) on this PC. Only one instance is allowed. Currently running LIFT Engine processes are:\n@liftProcesses";
        return;
    }

    print("\n");
    return 1;
}

###------------------------------------------------------------------
### LIFT_engine
###------------------------------------------------------------------

=head

    Subroutine Name :: LIFT_engine
    Description     :: This function is the heart for the execution of the test cases. 
                       This function sets the state of execution to INIT, read the configuration details, 
                       test cases and test case parameters for the execution. The Initialization of the 
                       test cases execution (INIT Campaign), execution of test cases and end of engine 
                       takes place. Once the execution was done, generates the report.
    Syntax          :: LIFT_engine()
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: None
    Description     :: None

    Note :
    ECU-Hardware Information shall be added to Project Defaults section ( fields to be filled by the user ),    

    Example for ECU-Hardware Information : 
     'ECU_HW_INFO'  => {
        'fingerprint_A'  => { 
            'TT_No'=> '1236',
            'HW_version'=>'2.36',
            'HW_serial_no'=>'65328',
        },
        'fingerprint_B'  => { 
            'TT_No'=> '1238',
            'HW_version'=>'2.311',
            'HW_serial_no'=>'56490',
        },
    }, 
    which will be added to report header.

=cut

sub LIFT_engine {
    ##################################
    ### START OF MAIN
    ##################################
    my $lift_start_time = time();    # store time of LIFT start
    S_reset_TC_time();

    #CALL PrepareCampaignExecution
    my $max_nr = PrepareCampaignExecution($lift_start_time);

    ### execution of init_campaign here
    #CALL ProcessInitCampaign
    my $last_flag = ProcessInitCampaign($max_nr) if defined $TC_INIT_CAMPAIGN;

    ### STARTING MAIN EXECUTION LOOP HERE
    #IF server mode selected in arguments?
    if ($opt_server_mode) {

        #IF-YES-START
        #CALL ProcessServerMode
        ProcessServerMode();

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #CALL ProcessTestCases
        ProcessTestCases( $max_nr, $last_flag );

        #IF-NO-END
    }

    ### execution of end_campaign here
    #CALL ProcessEndCampaign
    ProcessEndCampaign($max_nr) if defined $TC_END_CAMPAIGN;

    #CALL Write_result_summary_to_logs
    Write_result_summary_to_logs();

    # switch again automatic software updates by SCCM depending on option keep_last_SCCM_state
    #CALL LIFT_general::S_SCCM_SetSoftwareDistribution
    my $newSCCMState;
    if ($opt_keep_last_SCCM_state) {
        $newSCCMState = 'reset';
    }
    else {
        $newSCCMState = 'enabled';
    }
    S_SCCM_SetSoftwareDistribution($newSCCMState);

    # write execution logging data
    my $lift_end_time = time();

    #CALL WriteExecutionLoggingData
    WriteExecutionLoggingData( $lift_start_time, $lift_end_time );

    #CALL Close_all_logs
    Close_all_logs( $lift_start_time, $lift_end_time, $max_nr );

    if ($opt_report_overview) {

        #STEP call CreateHtmlResultOverview.pl to update latest test results in overview report
        system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $LIFT_exec_path/CreateHtmlResultOverview.pl --dir $LIFT_config::LIFT_LOG_path");
    }

    #STEP print campaign status
    print "\n$CAMPAIGN_STATUS\n";
    print "\n...ready :o)\n";

    ##################################
    ### END OF CAMPAIGN
    ##################################
    return 1;
}

=head

    ValidateTCStructure ($tc_module, $tc_id, $tc_cnt ); 

    This function checks whether atleast any one of the mandatory methods (initialization, 
    stimulation and measurement, evaluation, finalization) is present in the TC module


    Return values : 
        Normal case : return 1
        Error case  : return undef + set_error

    No special behaviour in OFFLINE mode 

=cut

sub ValidateTCStructure {

    my $tc_module = shift;
    my $tc_id     = shift;
    my $tc_cnt    = shift;

    # check whether atleast one mandatory function is existing.
    # if not, provide error in the test report
    my $at_least_one_function = 0;

    if ( defined &{ $tc_module . "::" . $init_func } )  { $at_least_one_function = 1 }
    if ( defined &{ $tc_module . "::" . $stimu_func } ) { $at_least_one_function = 1 }
    if ( defined &{ $tc_module . "::" . $eval_func } )  { $at_least_one_function = 1 }
    if ( defined &{ $tc_module . "::" . $final_func } ) { $at_least_one_function = 1 }

    #
    # Error case
    #
    unless ($at_least_one_function) {
        my $error_text =
"TC_ID $tc_id : \n at least 1 function of 4-step-method have to be present in the module '$tc_module' : \n - $init_func \n - $stimu_func \n - $eval_func \n - $final_func\n\n PLEASE check also name of 'package' and name of 'file' which must be same until top seperation of sub-package ('__') \n(inconsistent package declaration?)!\n";
        S_set_error( $error_text, 21 );
        $ALL_TC->{$tc_cnt}{'WRONG_DESIGN_TC_MODULE'} = $error_text;    # will be used in Campaign Report to show wrong TC modules
        return;                                                        # Error case
    }

    #
    # TC module design is OK
    #
    return 1;
}

###------------------------------------------------------------------
### Read_config ( )
###------------------------------------------------------------------

=head

    Subroutine Name :: Read_config
    Description     :: This function reads all used global vars from config file.
                       Configuration contains the information as project constants, test bench setup details.
    Syntax          :: Read_config ()
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: 1
    Description     :: Returns 1 success and 0 on failure

=cut

sub Read_config {

    if ( defined $LIFT_config::LIFT_TC_path and defined @LIFT_config::LIFT_TC_paths ) {
        S_set_error( "Both \$LIFT_TC_path and \@LIFT_TC_paths are defined in main CFG file. Only one of the variables (preferably \@LIFT_TC_paths) may exist.\n", 21 );
        return;
    }
    elsif ( defined $LIFT_config::LIFT_TC_path ) {
        @tc_paths = ($LIFT_config::LIFT_TC_path);
    }
    else {
        @tc_paths = @LIFT_config::LIFT_TC_paths;
    }

    if ( defined $opt_tc_para ) {
        $TC_PARA_path = $opt_tc_para;
        print " TC_PARA_path : $TC_PARA_path ( from command line option '-tc_para' )\n";
    }
    elsif ( defined $LIFT_config::LIFT_PARA_path ) {
        $TC_PARA_path = $LIFT_config::LIFT_PARA_path;
        print " TC_PARA_path : $TC_PARA_path ( from LIFT_config::LIFT_PARA_path )\n";
    }
    else {
        print " TC_PARA_path : not set (neither with option '-tc_para' nor with LIFT_config::LIFT_PARA_path) \n";
        undef $TC_PARA_path;
    }

    $TC_INIT_path = $LIFT_config::LIFT_TC_INIT_path
      if defined $LIFT_config::LIFT_TC_INIT_path;
    $TC_INIT_CAMPAIGN = $LIFT_config::LIFT_TC_INIT_CAMPAIGN
      if defined $LIFT_config::LIFT_TC_INIT_CAMPAIGN;

    #overwrite with engine -IC if given
    $TC_INIT_CAMPAIGN = $opt_IC
      if defined $opt_IC;

    $TC_END_path = $LIFT_config::LIFT_TC_END_path
      if defined $LIFT_config::LIFT_TC_END_path;
    $TC_END_CAMPAIGN = $LIFT_config::LIFT_TC_END_CAMPAIGN
      if defined $LIFT_config::LIFT_TC_END_CAMPAIGN;

    #overwrite with engine -EC if given
    $TC_END_CAMPAIGN = $opt_EC
      if defined $opt_EC;

    #determine the simulator (PeriBox or LabCar or no_MLC)
    if ( defined $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'} ) {
        $Simulator = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'};
    }
    else { $Simulator = "no_MLC" }

    # read $ProjectDefaults from config module
    # in fact it's the hash Defaults
    # from module LIFT_PROJECT in Project defaults config file
    $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults
      if defined $LIFT_config::LIFT_ProjectDefaults;

    #
    #  command argument -exec_options "name_of_data_set_in_LIFT_EXEC_OPTIONS"
    #
    if ( defined $opt_exec_options_file ) {

        unless ( -f $opt_exec_options_file ) {
            print "\n == ERROR == given File for Exec options '$opt_exec_options_file' not existing \n";
            return;
        }

        # eval & require the $opt_exec_options_file to check for syntax errors
        eval "require '$opt_exec_options_file'";

        #check whether any error in loading the TC module
        if ($@) {
            print "\n == ERROR == while loading File for Exec options '$opt_exec_options_file': $@ \n";
            return;
        }

        unless ( defined $LIFT_EXEC_OPTIONS::EXEC_OPTIONS ) {
            print "\n == ERROR == LIFT_EXEC_OPTIONS::EXEC_OPTIONS  is not defined in '$opt_exec_options_file' \n";
            return;
        }

        unless ( defined $opt_use_exec_options ) {
            print "\n option -use_exec_options not set => use 'DEFAULT' \n";
            $opt_use_exec_options = 'DEFAULT';
        }

        unless ( defined $LIFT_EXEC_OPTIONS::EXEC_OPTIONS->{$opt_use_exec_options} ) {
            print "\n == ERROR == LIFT_EXEC_OPTIONS::EXEC_OPTIONS does not contain Data Set '$opt_use_exec_options' -> -use_exec_options called with wrong value ('$opt_use_exec_options') \n";
            return;
        }

        unless ( 'HASH' eq ref $LIFT_EXEC_OPTIONS::EXEC_OPTIONS->{$opt_use_exec_options} ) {
            print "\n == ERROR == LIFT_EXEC_OPTIONS::EXEC_OPTIONS->{$opt_use_exec_options} must be a HASH REF\n";
            return;
        }

        $LIFT_EXEC_OPTIONS_href = $LIFT_EXEC_OPTIONS::EXEC_OPTIONS->{$opt_use_exec_options};
        print "\n LIFT_EXEC_OPTIONS : use Data Set '$opt_use_exec_options' defined in Exec Option file '$opt_exec_options_file' \n\n";
    }

    $LIFT_EXEC_OPTIONS_href->{'testlist'}             = $opt_testlist          if defined $opt_testlist          and not defined $LIFT_EXEC_OPTIONS_href->{'testlist'};
    $LIFT_EXEC_OPTIONS_href->{'conf'}                 = $opt_conf              if defined $opt_conf              and not defined $LIFT_EXEC_OPTIONS_href->{'conf'};
    $LIFT_EXEC_OPTIONS_href->{'tc_para'}              = $opt_tc_para           if defined $opt_tc_para           and not defined $LIFT_EXEC_OPTIONS_href->{'tc_para'};
    $LIFT_EXEC_OPTIONS_href->{'IC'}                   = $opt_IC                if defined $opt_IC                and not defined $LIFT_EXEC_OPTIONS_href->{'IC'};
    $LIFT_EXEC_OPTIONS_href->{'EC'}                   = $opt_IC                if defined $opt_EC                and not defined $LIFT_EXEC_OPTIONS_href->{'EC'};
    $LIFT_EXEC_OPTIONS_href->{'tc_exec_options_file'} = $opt_exec_options_file if defined $opt_exec_options_file and not defined $LIFT_EXEC_OPTIONS_href->{'exec_options_file'};
    $LIFT_EXEC_OPTIONS_href->{'beep'}                 = 1                      if defined $opt_beep              and not defined $LIFT_EXEC_OPTIONS_href->{'beep'};
    $LIFT_EXEC_OPTIONS_href->{'offline'}              = 1                      if defined $opt_offline           and not defined $LIFT_EXEC_OPTIONS_href->{'offline'};
    $LIFT_EXEC_OPTIONS_href->{'simulation'}           = 1                      if defined $opt_simulation        and not defined $LIFT_EXEC_OPTIONS_href->{'simulation'};
    $LIFT_EXEC_OPTIONS_href->{'evaluation_only'}      = 1                      if defined $opt_evaluation_only   and not defined $LIFT_EXEC_OPTIONS_href->{'evaluation_only'};
    $LIFT_EXEC_OPTIONS_href->{'silent'}               = 1                      if defined $opt_silent            and not defined $LIFT_EXEC_OPTIONS_href->{'silent'};
    $LIFT_EXEC_OPTIONS_href->{'polite'}               = 1                      if defined $opt_polite            and not defined $LIFT_EXEC_OPTIONS_href->{'polite'};
    $LIFT_EXEC_OPTIONS_href->{'minimalsnapshot'}      = 1                      if defined $opt_minimalsnapshot   and not defined $LIFT_EXEC_OPTIONS_href->{'minimalsnapshot'};

    # just needed for docu file link in LIFT testcase report
    $DOCS_path = $LIFT_config::LIFT_TC_DOCS_path
      if $LIFT_config::LIFT_TC_DOCS_path;

    unless ( defined $LIFT_config::LIFT_LOG_path ) {
        S_set_error( "no log path 'LIFT_LOG_path' defined in config module", 21 );
        return;
    }

    # create path if necessary
    unless ( -d $LIFT_config::LIFT_LOG_path ) {

        # try to create path
        my $abs_LOG_path = abs_path($LIFT_config::LIFT_LOG_path);

        S_w2log( 2, "LOG_path '$LIFT_config::LIFT_LOG_path' doesnt exists - trying to create it ($abs_LOG_path)\n" );

        # $LIFT_config::LIFT_PRJCFG_path
        unless ( mkpath($abs_LOG_path) ) {
            S_set_error("Error creating LOG_path '$abs_LOG_path': $!");
            return;
        }

        #check if now existing
        unless ( -d $LIFT_config::LIFT_LOG_path ) {
            S_set_error("path 'LIFT_LOG_path' ( $LIFT_config::LIFT_LOG_path ) defined in config module could not be created");
            return;
        }

        S_w2log( 2, "LOG_path '$abs_LOG_path' have been created successfully\n" );
    }

    return 1;
}

=head

    Subroutine Name :: Fetch_sad_file_config
    Description     :: This function reads sad file configuration done.
                       Configuration may contain sad file path with filename or just only folder name
    Syntax          :: Fetch_sad_file_config ()
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: 1
    Description     :: Returns 1 success and undef on failure

=cut

sub Fetch_sad_file_config {

    #IF $SAD_file not defined and $SAD_fpath defined?
    #IF-YES-START
    unless ( -e $LIFT_config::SAD_file ) {
        my $configured_sad_file = $LIFT_config::SAD_file;
        if ( defined $LIFT_config::SAD_fpath ) {

            #IF no sad file or multiple sad file found
            my @check_valid_sad_file = glob( $LIFT_config::SAD_fpath . '/*.sad' );

            #STEP Error return undef
            unless (@check_valid_sad_file) {
                S_set_error( "Fetch_sad_file_config: No sad file found in the path '$LIFT_config::SAD_fpath' ", 109 );
                return;
            }
            if ( @check_valid_sad_file > 1 ) {
                map { "$_\n" } @check_valid_sad_file;
                S_set_error( "Fetch_sad_file_config: More than one sad files \n'@check_valid_sad_file'\n found in the path '$LIFT_config::SAD_fpath' ", 109 );
                return;
            }

            #IF-YES-END
            #IF-NO-START
            #STEP fetch sad file and assign to LIFT_config::SAD_file
            $LIFT_config::SAD_file = shift @check_valid_sad_file;
            S_w2log( 3, "SAD file configured in variable '\$SAD_file' doesnot exist, hence SAD file '$LIFT_config::SAD_file' configured for variable '\$SAD_fpath' is considered" );

            #IF-NO-END
        }

        #IF-YES-END
        #IF-NO-START
        #STEP consider default as LIFT_config::SAD_file
        #IF-NO-END
        #STEP END
    }
    return 1;
}

################## DEVELOPMENT OF COMPACT TESTS

###------------------------------------------------------------------
### Read_testlist ( )
###------------------------------------------------------------------

=head

    Subroutine Name :: Read_testlist
    Description     ::  This function reads the testlist files which contains the 
                        test cases and test parameters file details. The test cases 
                        and test params for the IC, TC and EC.
    Syntax          :: Read_testlist(TestList, LIFT_TC_path, LIFT_PARA_path)
    Input Arguments :: TestList, LIFT_TC_path, LIFT_PARA_path
    Description     :: 
          		TestList       :: This contains the testcases and testpara path
          		LIFT_TC_path   :: This contains the details of test cases to be executed
          		LIFT_PARA_path :: This contains the details of test parameters to be executed
    Return Value(s) :: number of test cases
    Description     :: maximum number of test cases read

=cut

sub Read_testlist {
    my $parameters_from_server_href = shift;

    my $tc_para_path = $TC_PARA_path;
    my @all_testlist_lines;

    my $testList_path = dirname $TestList;

    ###------------------------------------------------------------------
    #STEP read all lines from testlist file
    ###------------------------------------------------------------------
    open( my $mainTestlistFh, '<', $TestList ) or die "Opening $TestList \n";
    my @testListLines = <$mainTestlistFh>;
    close $mainTestlistFh;
    foreach my $line (@testListLines) {

        if ( $line =~ /^\s*TESTLIST\s*=\s*([a-z\._0-9]+)\s*/ig ) {
            my $sub_Testlist = "$testList_path/$1";
            if ( -f $sub_Testlist ) {
                S_w2log( 5, " Reading Sub Testlist : $sub_Testlist\n" );    # before IC (will not be written to html)
                open( my $subTestlistFh, '<', $sub_Testlist ) or die "Opening $sub_Testlist\n";
                push( @all_testlist_lines, $_ ) while (<$subTestlistFh>);
                close $subTestlistFh;
            }
            else { S_set_error( "Sub Testlist : $sub_Testlist NOT found\n", 21 ); }
        }
        else {
            if ( ( $line !~ /^#/ ) && ( $line !~ /^\s*$/ ) ) {
                push( @all_testlist_lines, $line );

            }
        }
    }

    find(
        {
            wanted => sub { Search_module( \@all_testlist_lines ) }
        },
        @tc_paths
    );

    find(
        {
            wanted => sub { Search_parafile( \@all_testlist_lines ) }
        },
        $tc_para_path
    );

    if ( defined $DOCS_path ) {
        S_w2log( 5, " Defined TC Docu Path : $DOCS_path (LIFT_config::LIFT_TC_DOCS_path) \n" );
        if ( -d $DOCS_path ) {
            find(
                {
                    wanted => sub { Search_docufile_sub( \@all_testlist_lines ) }
                },
                $DOCS_path
            );
        }
        else {
            S_w2log( 5, " Defined TC Docu Path doesnt exists physically: $DOCS_path (LIFT_config::LIFT_TC_DOCS_path)\n" );
        }
    }
    else {
        S_w2log( 5, " No path defined for TC Docu (LIFT_config::LIFT_TC_DOCS_path) \n" );
    }

    ###------------------------------------------------------------------
    #STEP analyse all lines in testlist file and initialise hash $ALL_TC
    ###------------------------------------------------------------------
    my ( $tc_id, $tc_module, $tc_par_ext, $prj_par_ext, $tc_par_file_long );

    my $tc_cnt = 0;
    foreach (@all_testlist_lines) {

        # forget all lines commented out
        next if /^\s*#/ || /^\s*$/;

        undef $tc_id;
        undef $tc_module;
        undef $tc_par_ext;
        undef $prj_par_ext;

        # try to match a double parametrized testcase (e.g. TC_ABC.01.XY)
        # TC_ABC -> tc_module
        # 01 -> tc_par_ext
        # XY -> prj_par_ext
        # note: when using project para the tc para is optional (e.g. TC_ABC..XY)
        ( $tc_module, $tc_par_ext, $prj_par_ext ) = /^\s*(\w+)\.(\w*)\.(\w+)\s*/;

        # try to match a single parametrized testcase (e.g. TC_ABC.01)
        ( $tc_module, $tc_par_ext ) = /^\s*(\w+)\.(\w+)\s*/ unless defined $prj_par_ext;

        # try to match unparametrized testcase (e.g. TC_ABC)
        ($tc_module) = /^\s*(\w+)\s*/ unless defined $tc_par_ext;

        # combine TC_module and TC_PAR_EXT (and PRJ_PAR_EXT) to TC_ID
        # (eg.g. 'TC_ABC' and '01'' together to TC_ABC.01)
        # (eg.g. 'TC_ABC' and '01' and 'XY' together to TC_ABC.01.XY)
        $tc_id = "$tc_module";
        $tc_id .= "." . "$tc_par_ext"  if defined $tc_par_ext;     ## add tc_par_extension (optional available)
        $tc_id .= "." . "$prj_par_ext" if defined $prj_par_ext;    ## add prj_par_extension (optional available)

        next unless $tc_id;

        my $tc_module_filename_part = $tc_module;

        ### change the filenames when '__' (double underscore) matched ( e.g. MODULEFILE__TESTCASEPACKAGE.tcpar.projectpar )
        if ( $tc_module =~ /^(\w+)__\w+$/ ) { $tc_module_filename_part = $1; }

        # increment KEY counter
        $tc_cnt++;
        S_w2log( 5, "==> $tc_cnt\tAdding TC: -> $tc_id <- to Execution List\n" );    # before IC (will not be written to html)
        $ALL_TC->{$tc_cnt}->{'TC_ID'} = $tc_id;

        # verify if testcase module exist
        my $tc_module_file_long = $main::All_TC_Modulefiles->{ "$tc_module_filename_part" . ".pm" };

        #      S_w2log( 5, "file= $tc_module_file_long\n");

        $ALL_TC->{$tc_cnt}->{'TC_MODULE'} = $tc_id unless defined $tc_module;
        $ALL_TC->{$tc_cnt}->{'TC_MODULE'} = $tc_module if defined $tc_module;
        $ALL_TC->{$tc_cnt}->{'TC_MODULE_FILE'} = $tc_module_file_long;

        unless ( -f $tc_module_file_long ) {
            my $error_text = " TC $tc_id : TC Module '$tc_module_filename_part\.pm' not found in TC_paths '@tc_paths' \n";

            #            S_w2log( 5,"==> skipped TC: $tc_id ... TC File: '$tc_module_filename_part\.pm' does not exist in TC_path '$tc_path' \n");
            S_set_error( $error_text, 0 );
            $ALL_TC->{$tc_cnt}->{'ERROR_READING_TESTSOURCES'} = $error_text;
            $ALL_TC->{$tc_cnt}->{'NO_TC_MODULE'}              = 1;
            next;
        }
        Copy2rerun($tc_module_file_long);

        if ( defined $tc_par_ext and not defined $parameters_from_server_href->{$tc_id} ) {
            $tc_par_file_long = $main::All_TC_Parafiles->{ "$tc_module_filename_part" . ".par" };
            unless ( -f $tc_par_file_long ) {
                my $error_text = " TC $tc_id : TC Parameter File '$tc_module_filename_part\.par' not found in TC_para_path '$tc_para_path' \n";

                #                S_w2log( 5,"==> skipped TC: $tc_id ... TC Para File: '$tc_module_filename_part\.par' does not exist in TC_para_path '$tc_para_path' \n");
                S_set_error( $error_text, 0 );
                $ALL_TC->{$tc_cnt}->{'ERROR_READING_TESTSOURCES'} = $error_text;
                $ALL_TC->{$tc_cnt}->{'NO_TC_PARA_FILE'}           = 1;
                next;
            }
            Copy2rerun($tc_par_file_long);
        }

        $ALL_TC->{$tc_cnt}->{'TC_PAR_FILE'}      = $tc_par_file_long              if defined $tc_par_ext;
        $ALL_TC->{$tc_cnt}->{'TC_PARAMETER'}     = undef                          if defined $tc_par_ext;
        $ALL_TC->{$tc_cnt}->{'TC_PAR_ID'}        = $tc_module . "." . $tc_par_ext if defined $tc_par_ext;
        $ALL_TC->{$tc_cnt}->{'TC_PRJ_PARAMETER'} = undef                          if defined $prj_par_ext;
        $ALL_TC->{$tc_cnt}->{'TC_PRJ_EXT'}       = $prj_par_ext                   if defined $prj_par_ext;

        my $tc_docufile_long = $main::All_TC_Docufiles->{ "$tc_module_filename_part" . ".html" };

        #        unless ( -f $tc_docufile_long ) { S_w2log( 5,"\n  Please do the TC documentation ($tc_id) \n  Docu File: '$tc_module_filename_part\.html' does not exist in DOCS_path '$DOCS_path' \n" );  }
        $ALL_TC->{$tc_cnt}->{'TC_DOCU_FILE'} = $tc_docufile_long if defined $tc_docufile_long;

        # try to find the comment behind the testcase ID
        my $tc_comment = "";
        ($tc_comment) = /^\s*\w+\s*#\s*(.*)\s*$/           if defined $tc_id;
        ($tc_comment) = /^\s*\w+\.\w+\s*#\s*(.*)\s*$/      if defined $tc_par_ext;
        ($tc_comment) = /^\s*\w+\.\w*\.\w+\s*#\s*(.*)\s*$/ if defined $prj_par_ext;

        if ($tc_comment) {
            S_w2log( 5, "==> $tc_cnt\tTC Comment: $tc_comment\n" );
            $ALL_TC->{$tc_cnt}->{'TC_COMMENT'} = $tc_comment;
        }
        else {
            $ALL_TC->{$tc_cnt}->{'TC_COMMENT'} = "";
        }

        # initialize remaining keys
        $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = VERDICT_NONE;
        $ALL_TC->{$tc_cnt}{'TC_INIT'}    = INCONC;
        $ALL_TC->{$tc_cnt}{'TC_STIMU'}   = INCONC;
        $ALL_TC->{$tc_cnt}{'TC_EVAL'}    = INCONC;
        $ALL_TC->{$tc_cnt}{'TC_FINAL'}   = INCONC;
        $ALL_TC->{$tc_cnt}{'TC_ERRORS'}  = [];

    }

    # store nbr of testcases which will be executed
    return $tc_cnt;
}

###------------------------------------------------------------------
### search_module
### The sub is called anonymously using a variable. Otherwise it would throw a warning: "variable ... will not stay shared"
###------------------------------------------------------------------

sub Search_module {
    my $all_testlist_lines_aref = shift;

    if (/\.pm/) {
        if ( exists $main::All_TC_Modulefiles->{$_} ) {
            my ($tc_module_tmp) = fileparse( $_, ".pm" );
            if ( grep { /$tc_module_tmp/ } @$all_testlist_lines_aref ) {
                my $first_name    = $main::All_TC_Modulefiles->{$_};
                my $next_name     = $File::Find::name;
                my $testAreaRegex = '/TestArea_\w+/';
                my $logText1      = "TC Module $_ exists more than once: $first_name AND $next_name.";
                my $logText2      = " is used because it is part of a TestArea.\n";
                if ( $first_name =~ m{$testAreaRegex} ) {

                    # Already found test case is part of a test area. Return here and do not add the current file to $main::All_TC_Modulefiles
                    S_w2log( 4, $logText1 . $first_name . $logText2 );
                    return 1;
                }
                elsif ( $next_name =~ m{$testAreaRegex} ) {

                    # Current file is part of a test area. Delete the previously existing entry $main::All_TC_Modulefiles->{$_}
                    S_w2log( 4, $logText1 . $next_name . $logText2 );
                    delete $main::All_TC_Modulefiles->{$_};
                }
                else {
                    S_set_error( "\n\tTC Module: $_ exists more than once!!\n\t $first_name AND $next_name \n\t please remove one file ", 21 );
                }
            }
            else {
                delete $main::All_TC_Modulefiles->{$_};
            }
        }
        $main::All_TC_Modulefiles->{$_} = $File::Find::name;
    }
    return 1;
}

###------------------------------------------------------------------
### search_parafile
### The sub is called anonymously using a variable. Otherwise it would throw a warning: "variable ... will not stay shared"
###------------------------------------------------------------------

sub Search_parafile {
    my $all_testlist_lines_aref = shift;

    my ( $tc_parafile_tmp, $first_name, $next_name );
    if (/\.par/) {
        if ( exists $main::All_TC_Parafiles->{$_} ) {
            ($tc_parafile_tmp) = fileparse( $_, ".par" );
            if ( grep { /$tc_parafile_tmp/ } @$all_testlist_lines_aref ) {
                $first_name = $main::All_TC_Parafiles->{$_};
                $next_name  = $File::Find::name;
                S_set_error( "\n\tTC Para File: $_ exists more than once!!\n\t $first_name AND $next_name \n\t please remove one file ", 21 );
            }
        }
        $main::All_TC_Parafiles->{$_} = $File::Find::name;
    }
    return 1;
}

###------------------------------------------------------------------
### search_docufile
### The sub is called anonymously using a variable. Otherwise it would throw a warning: "variable ... will not stay shared"
###------------------------------------------------------------------

sub Search_docufile_sub {
    my $all_testlist_lines_aref = shift;

    my ( $tc_docufile_tmp, $first_name, $next_name );
    if (/\.html/) {
        if ( exists $main::All_TC_Docufiles->{$_} ) {
            ($tc_docufile_tmp) = fileparse( $_, ".html" );
            if ( grep { /$tc_docufile_tmp/ } @$all_testlist_lines_aref ) {
                $first_name = $main::All_TC_Docufiles->{$_};
                $next_name  = $File::Find::name;
                S_set_error( "\n\tTC Docu File: $_ exists more than once!!\n\t $first_name AND $next_name \n\t please remove one file ", 21 );
            }
        }
        $main::All_TC_Docufiles->{$_} = $File::Find::name;
    }
    return 1;
}

###------------------------------------------------------------------
### Read_all_parameter ()
###------------------------------------------------------------------

=head

    Subroutine Name  :: Read_all_parameter
    Description      :: This function reads the  parameters for the testcases.
    Syntax           :: Read_all_parameter ( $LIFT_config::LIFT_PROJECT_PARAMETER_file )
    Input Arguments  :: LIFT_PROJECT_PARAMETER_file
    Description      :: 
            LIFT_PROJECT_PARAMETER_file :: Project Parameter file path
    Return Value(s)  :: number of test cases
    Description      :: maximum number of test cases read

=cut

sub Read_all_parameter {

    my $tcparfile_VERSION;
    my $prj_par_file                = shift;
    my $parameters_from_server_href = shift;

    my (
        $tc_id,
        $tc_par_file,
        $all_tc_ids,
        $all_small_tc_ids,
        $prj_par_ext,
        $temp_prj_par_ext,
        $prj_par_result,
        $tc_par_result,
        $error_text,
        $validTCProjParSets,    ## hash ref with all allowed 'PROJECT_PARAMETER' sets of TC para file
    );

    #LOOP-START Loop over all test cases in $ALL_TC hash
    #    foreach $tc_cnt ( sort {$a<=>$b} keys %$ALL_TC ) {
    foreach my $tc_cnt ( sort keys %$ALL_TC ) {
        $tc_id = $ALL_TC->{$tc_cnt}->{'TC_ID'};

        # create a hash $all_tc_ids->{TC_ID} = TC_CNT
        #   will be used in Read_parameter_file
        if ( defined $ALL_TC->{$tc_cnt}->{'TC_PAR_FILE'} ) {
            push( @{ $all_tc_ids->{$tc_id} }, $tc_cnt );
        }

        #CALL Read_parameter_file with project parameter file name if project parameters exist
        if ( exists $ALL_TC->{$tc_cnt}->{'TC_PRJ_PARAMETER'} ) {
            ### read the whole PRJ para file because at least 1 TC needs project paramters
            unless ( defined $prj_par_result ) {
                S_w2log( 5, " --> Read all Project Parameter from '$prj_par_file'\n" );    # before IC (will not be written to html)
                $prj_par_result = Read_parameter_file( $prj_par_file, "PRJ" );
            }
        }

        # create a hash $all_small_tc_ids->{'TC_ABC.01'}
        #  which collects all tc's with this parameter set in a list
        #   will be used in Read_parameter_file
        if ( $tc_id =~ /^(\w+\.\w+)/ ) {
            push( @{ $all_small_tc_ids->{$1} }, $tc_id );
        }

    }

    #LOOP-END Last test case?

    #LOOP-START Loop over all test cases in $ALL_TC hash
    ### main loop over all entries found in testlist
    #    foreach $tc_cnt ( sort {$a<=>$b} keys %$ALL_TC ) {
    foreach my $tc_cnt ( sort keys %$ALL_TC ) {

        $tc_id = $ALL_TC->{$tc_cnt}->{'TC_ID'};

        #STEP if parameter values are available from the server then set test case parameters to those values
        if ( defined $parameters_from_server_href->{$tc_id} ) {
            $ALL_TC->{$tc_cnt}->{'TC_PARAMETER'} = $parameters_from_server_href->{$tc_id};
        }

        #IF test case parameters exist?
        if ( exists $ALL_TC->{$tc_cnt}->{'TC_PARAMETER'} ) {

            #IF-YES-START

            next if defined $ALL_TC->{$tc_cnt}->{'TC_PARAMETER'};

            #CALL Read_parameter_file with test case parameter file name
            $tc_par_file = $ALL_TC->{$tc_cnt}->{'TC_PAR_FILE'};
            ( $tc_par_result, $validTCProjParSets, $tcparfile_VERSION ) = Read_parameter_file( $tc_par_file, "TC", $tc_cnt, $all_small_tc_ids );
            S_w2log( 5, " -> All tc parameter of $tc_par_file read\n" );                            # before IC (will not be written to html)
            S_w2log( 5, " -> Assign all found tc parameter to the appropiate testcase ID's\n" );    # before IC (will not be written to html)

            #STEP assign parameter names and values to test cases in $ALL_TC hash
            ### loop over all found TC parameter sets
            foreach my $small_tc_id ( keys %$tc_par_result ) {

                #### e.g. $small_tc_id = TC_XY.TCPARSET_01

                ### loop over list of all TC IDs which need this TC parameter set
                foreach my $tc_id_tmp ( @{ $all_small_tc_ids->{$small_tc_id} } ) {

                    #### e.g. $tc_id_tmp = TC_XY.TCPARSET_01.ABS

                    ### loop over all entries of e.g TC_XY.TCPARSET_01.ABS (because it can be called many times)
                    foreach my $tc_cnt_tmp ( @{ $all_tc_ids->{$tc_id_tmp} } ) {

                        next if $ALL_TC->{$tc_cnt_tmp}->{'TC_PARAMETER'};

                        S_w2log( 5, "  --> Assign TC para of '$small_tc_id' to TC $tc_id_tmp (nr.$tc_cnt_tmp)\n" );    # before IC (will not be written to html)
                        %{ $ALL_TC->{$tc_cnt_tmp}->{'TC_PARAMETER'} } = %{ $tc_par_result->{$small_tc_id} };
                        $ALL_TC->{$tc_cnt_tmp}->{'TC_PAR_FILE_VERSION'} = $tcparfile_VERSION;

                        unless ( $temp_prj_par_ext = $ALL_TC->{$tc_cnt_tmp}->{'TC_PRJ_EXT'} ) {
                            S_w2log( 5, "  --> TC (nr.$tc_cnt_tmp) '$tc_id_tmp' has no PRJ parameter\n" );             # before IC (will not be written to html)
                            next;
                        }
                        unless ( defined $prj_par_result->{$temp_prj_par_ext} ) {
                            $error_text = " TC (nr.$tc_cnt_tmp) '$tc_id_tmp': Project Parameter Extension '$temp_prj_par_ext' not defined \n";
                            $error_text .= " in '$prj_par_file'\n";
                            S_set_error( $error_text, 0 );
                            $ALL_TC->{$tc_cnt_tmp}{'ERROR_READING_TESTSOURCES'} = $error_text;
                            $ALL_TC->{$tc_cnt_tmp}{'BAD_PRJ_EXT'}               = 1;
                            next;
                        }

                        #                      unless( $validTCProjParSets ) {
                        #                          $error_text = " TC (nr.$tc_cnt_tmp) '$tc_id_tmp': Missing declaration of allowed PROJECT_PARAMETER\n";
                        #                          $error_text .= "in Testcase Parameter File: '$tc_par_file'  SYNTAX: 'PROJECT_PARAMETER = @( '<PRJPAR_x>', '<PRJPAR_y>') (outside of TC para set)\n";
                        #                          $error_text .= "SYNTAX: 'PROJECT_PARAMETER = @( '<PRJPAR_x>', '<PRJPAR_y>') (outside of TC para set)\n";
                        #                          S_set_error( $error_text , 0 );
                        #                          $ALL_TC->{$tc_cnt_tmp}{'ERROR_READING_TESTSOURCES'} = $error_text;
                        #                          $ALL_TC->{$tc_cnt_tmp}{'BAD_PRJ_EXT'} = 1;
                        #                          next;
                        #                      }
                        #                      unless( $validTCProjParSets->{ $temp_prj_par_ext } ) {
                        #                          $error_text = " TC (nr.$tc_cnt_tmp) '$tc_id_tmp': Execution not allowed with Project Parameter Set: '$temp_prj_par_ext' (verify PROJECT_PARAMETER in '$prj_par_file')\n";
                        #                          $error_text .= "(verify PROJECT_PARAMETER in '$prj_par_file')\n";
                        #                          S_set_error( $error_text , 0 );
                        #                          $ALL_TC->{$tc_cnt_tmp}{'ERROR_READING_TESTSOURCES'} = $error_text;
                        #                          $ALL_TC->{$tc_cnt_tmp}{'BAD_PRJ_EXT'} = 1;
                        #                          next;
                        #                      }

                        S_w2log( 5, "  --> Assign PRJ para set '$temp_prj_par_ext' to TC $tc_id_tmp (nr.$tc_cnt_tmp)\n\n" );    # before IC (will not be written to html)
                        %{ $ALL_TC->{$tc_cnt_tmp}->{'TC_PRJ_PARAMETER'} } = %{ $prj_par_result->{$temp_prj_par_ext} };

                    }    ## foreach $tc_cnt_tmp
                }    ## foreach $tc_id_tmp
            }    ## foreach $small_tc_id

            ## error if TC didnt got its TC parameters (error is just a warning, this leads to verdict INCONC when test list will be executed)
            unless ( defined $ALL_TC->{$tc_cnt}{'TC_PARAMETER'} ) {
                $error_text = " TC ($tc_cnt) $tc_id : No TC Parameter found in '$tc_par_file' \n";
                S_set_error( $error_text, 0 );
                $ALL_TC->{$tc_cnt}{'ERROR_READING_TESTSOURCES'} = $error_text;
                $ALL_TC->{$tc_cnt}{'NO_TC_PARA'}                = 1;
                next;
            }

            #IF-YES-END
        }
        else {
            #IF-NO-START
            ### TC has no TC parameters and no Project Parameters
            next unless $prj_par_ext = $ALL_TC->{$tc_cnt}->{'TC_PRJ_EXT'};
            ### TC has PRJ parameters
            unless ( $prj_par_result->{$prj_par_ext} ) {
                S_set_error( " TC (nr.$tc_cnt) '$tc_id': Project Parameter Extension '$prj_par_ext' not defined in '$prj_par_file'\n", 21 );
                next;
            }

            S_w2log( 5, "  --> Assign PRJ para set '$prj_par_ext' to TC $tc_id (nr.$tc_cnt)\n" );    # before IC (will not be written to html)
            %{ $ALL_TC->{$tc_cnt}->{'TC_PRJ_PARAMETER'} } = %{ $prj_par_result->{$prj_par_ext} };

            #IF-NO-END
        }

    }    #  foreach tc_cnt
         #LOOP-END Last test case?

    return 1;
}    #  sub

=head2 CheckAndThrowErrorIfDefined

To check whether the particular 'parameter_name' is already defined in parameter_set.

If the parameter is already defined, Error will be set & effectively the SYS_STATE will be changed by the S_set_error function

    SYNTAX: CheckAndThrowErrorIfDefined($allParameterBuffer, $parameter_set_name, $parameter_name)

=cut

sub CheckAndThrowErrorIfDefined {
    my $allParameterBuffer = shift;
    my $parameter_set_name = shift;
    my $parameter_name     = shift;

    # log the error , if parameter name is already defined for given parameter set
    if ( exists $allParameterBuffer->{$parameter_set_name} && exists $allParameterBuffer->{$parameter_set_name}{$parameter_name} ) {
        S_set_error(
            "Parameter '$parameter_name' already defined for parameter set '$parameter_set_name' \n Possible reasons: 
                     1. The same parameter set ([$parameter_set_name]) is defined twice in .par file
                     2. The parameter '$parameter_name' is defined twice in the parameter set [$parameter_set_name]
                     3. wrong format of TC_ID previously", 21
        );    # LIFT processing error
    }

    return 1;
}

###------------------------------------------------------------------
### Read_parameter_file ()
###------------------------------------------------------------------

=head

    Subroutine Name :: Read_parameter_file
    Description     :: this reads all the parameter files , checks for parameter repetition if any .
    Syntax          :: Read_parameter_file ($par_file , $par_file_type , $tc_cnt , $all_small_tc_ids); 
    Input Arguments :: $par_file , $par_file_type , $tc_cnt , $all_small_tc_ids
    Description     :: 
                      $par_file - parameter file (from testcase OR project!)
                      $par_file_type - only 'TC' or 'PRJ' are allowed
                      $tc_cnt - tc counter of global ALL_TC structure; is '0' when reading project para file
                      $all_small_tc_ids - is '0' when reading project para file
    Return Value(s) :: returns a hash reference for the read parameters

=cut

sub Read_parameter_file {
    my $par_file      = shift;
    my $par_file_type = shift;
    my $tc_cnt        = shift;

    #    my $all_tc_ids = shift;         # needed to get the tc_cnt when another interesting tc_id was found; is '0' when reading project para file
    my $all_small_tc_ids = shift;

    unless ( defined $par_file ) { S_set_error( "no parameter file given", 21 ); return 0; }
    unless ( $par_file_type =~ /[TC|PRJ]/i ) {
        S_set_error( "wrong para file type given only 'TC' or 'PRJ' are allowed", 21 );
        return 0;
    }

    my $found_para_sets;
    my $parameter_set_active;

    my ( @all_lines, $tc_id, $tc_id_small, $tc_id_tmp, $tc_comment, $tc_module, $tc_module_file, $tc_par_ext, $tc_para_key, $max_nr, @rawlist, @goodlist, $text, %goodhash, $userkey, $uservalue, $validTCProjParSets, $tcparfile_VERSION, );

    unless ( open( PARA_F, $par_file ) ) {
        S_set_error( "Opening $par_file: $! \n", 1 );
        return 0;
    }
    @all_lines = (<PARA_F>);
    unless ( close(PARA_F) ) {
        S_set_error( "Closing $par_file: $! \n", 1 );
        return 0;
    }

    foreach (@all_lines) {
        next if /^\s*#/ or /^\W+$/;    # next if just comments no characters
        s/#.*$//g;                     # substitute comments

        ## try to match the right entry in testcase parameter file
        if ( $par_file_type =~ /TC/i ) {

            # try to match a line like : "   [  TC_ABC.01  ]    \n"
            if (/^\s*\[.+\]\s*$/) {    # match line with square brackets
                if (
                    /^\s*    # maybe line start with whitespaces
	                \[        # match the [
	                \s*        # whitespaces optional
	                (\w+)    # match the tc_module in tc_id (the "TC_ABC" in "TC_ABC.01")
	                \.        # match the .
	                (\w+)    # match the tc_extension in tc_id (the "01" in "TC_ABC.01")
	                \s*        # whitespaces optional
	                \]        # match the ]
	                 /x
                  )                    # and of matching
                {
                    undef $parameter_set_active;

                    # read matched items into variables
                    $tc_module   = $1;
                    $tc_par_ext  = $2;
                    $tc_id_small = "$1" . "." . "$2";

                    # check if tc_module (the "TC_ABC") is valid in this parameter file
                    unless ( $tc_module eq $ALL_TC->{$tc_cnt}->{'TC_MODULE'} ) {

                        #this will throw bat TC_id for DCOM tests, rework needed
                        # S_w2log ( 5, " -> wrong: $par_file (bad tc_id $tc_id_small)\n"); # before IC (will not be written to html)
                        undef $tc_id_small;
                        undef $tc_module;
                        undef $tc_par_ext;
                        next;
                    }

                    # check if found tc_id is part of testlist
                    unless ( exists $all_small_tc_ids->{$tc_id_small} ) {

                        #    S_w2log( 5, " Skip $tc_id_small    (not part of testlist) \n" ); # before IC (will not be written to html)
                        undef $tc_id;
                        undef $tc_module;
                        undef $tc_par_ext;
                        next;
                    }

                    S_w2log( 5, " -> start reading testcase parameters for '$tc_id_small' \n" );    # before IC (will not be written to html)
                    if ($tc_id_small) {
                        $parameter_set_active = $tc_id_small;
                        $tc_id                = $tc_id_small;
                    }
                }
                else {
                    chomp();
                    S_set_error( "wrong format of TC_ID '$_' in TCpar file. Should be [something.something] where something may contain only word characters '0-9a-zA-Z_'\n NOTE: you might get additional 'Parameter X already defined' errors because this TC_ID is skipped", 21 );
                }
            }
            if (/^\s*PROJECT_PARAMETER\s*=\s*@\s*\(.+\)\s*$ /xg) {
                $parameter_set_active = 'PROJECT_PARAMETER';
            }
            if (/^\s*\$VERSION\s*=\s*(.+);$/) {
                $tcparfile_VERSION = eval($1);
            }

        }

        if ( $par_file_type =~ /PRJ/i ) {

            # try to match a line like : "   [  CS0_UD  ]    \n"
            if (
                /^\s*    # maybe line start with whitespaces
                \[        # match the [
                \s*       # whitespaces
                (\w+)     # match the name of project parameter set (e.g. 'CS0_UD')
                \s*       # whitespaces
                \]        # match the ]
                 /x
              )    # and of matching
            {
                # read matched items into variables
                $parameter_set_active = $1;
                S_w2log( 5, " -> start reading project parameter set for '$1' \n" );    # before IC (will not be written to html)
                $tc_id = $1;
            }
        }

        # read next line if not defined a tc_id which is part of testlist
        #  and if not defined a prj_par_extension which is part of the testlist
        next unless $parameter_set_active;

        ### now start to find parameters for current tc_id

        # match simple numbers ( 13 , 13.8 , +13.8 , -13.8 , .001 )
        # e.g. MY_NUMBER = -13.8
        if (
            / ^\s*(\w+)\s*=\s*             # the " parameter name = "
               ([+-]?\d+\.?\d*|[+-]?\.\d+)    # numbers with-out "+-" and with-out "."
               \s*$                         # whitespaces to the end
             /xg
          )    # and of matching
        {
            $tc_para_key = $1;

            # check for redundant definition of parameters
            CheckAndThrowErrorIfDefined( $found_para_sets, $parameter_set_active, $tc_para_key );

            $found_para_sets->{$parameter_set_active}{$tc_para_key}{'SCALAR'} = $2;
            S_w2log( 5, " Parameter (number) for $tc_id : $tc_para_key = $2 \n" );    # before IC (will not be written to html)
        }

        # match a "string"
        # e.g. MY_STRING = " wfjw  ff  fw(% ($p iwu f "
        if (/ ^\s*(\w+)\s*=\s*[\'\"](.+)[\'\"]\s*$ /xg) {
            $tc_para_key = $1;

            #check for redundant definition of parameters
            CheckAndThrowErrorIfDefined( $found_para_sets, $parameter_set_active, $tc_para_key );

            $found_para_sets->{$parameter_set_active}{$tc_para_key}{'SCALAR'} = $2;
            S_w2log( 5, " Parameter (string) for $tc_id : $tc_para_key = $2 \n" );    # before IC (will not be written to html)
        }

        # match list
        # e.g. MY_LIST = @ ( "fg irf" , "31 2" , +13.8 , -.12 )
        if (/ ^\s*(\w+)\s*=\s*@\s*\((.*?)\)\s*$ /xg) {
            $tc_para_key = $1;

            #check for redundant definition of parameters
            CheckAndThrowErrorIfDefined( $found_para_sets, $parameter_set_active, $tc_para_key );

            @rawlist  = ();
            @goodlist = ();
            $text     = "";

            # trim the spaces in string at both ends
            my $listString = $2;
            $listString =~ s/^\s+|\s+$//g;

            # split the string to get the actual list
            @rawlist = split( ',', $listString );
            foreach (@rawlist) {
                s/^\s+//;    # drop leading blanks
                s/\s+$//;    # drop trailing blanks
                unless (/[\'\"]/) {

                    # match the number if element is no string
                    if (/^\s*([+-]?\d+\.?\d*|[+-]?\.\d+)\s*$/g) {
                        push( @goodlist, $1 );
                        $text .= " $1 ,";
                    }
                    else {
                        S_set_error( " LIST Parameter error in $par_file: tc:$tc_id para:$tc_para_key value: <$_> \n file skipped!!", 21 );
                        return;
                    }
                }
                else {
                    # its a string
                    $text .= " $_ ,";
                    s/[\'\"]//g;    # substitute all whitespaces
                    push( @goodlist, $_ );
                }    #  else
            }    # end foreach rawlist
            if ( $parameter_set_active eq 'PROJECT_PARAMETER' ) {
                foreach (@goodlist) { $validTCProjParSets->{$_} = 1; }
            }
            else {
                @{ $found_para_sets->{$parameter_set_active}{$tc_para_key}{'LIST'} } = @goodlist;
                chop $text;
                S_w2log( 5, " Parameter ( list ) for $tc_id : $tc_para_key = @($text) \n" );    # before IC (will not be written to html)
            }
        }    #  if / /

        # match hash
        # e.g. LAMPS = % ( "MFL" => 1  , "ABS" => " IS ON " )
        if (/ ^\s*(\w+)\s*=\s*%\s*\((.*?)\)\s*$ /xg) {
            $tc_para_key = $1;

            #check for redundant definition of parameters
            CheckAndThrowErrorIfDefined( $found_para_sets, $parameter_set_active, $tc_para_key );

            @rawlist  = [];
            %goodhash = ();
            $text     = "";

            # trim the spaces in string at both ends
            my $hashString = $2;
            $hashString =~ s/^\s+|\s+$//g;

            # split the string to get the actual keyvalue-pair list
            @rawlist = split( ',', $hashString );
            foreach (@rawlist) {
                ( $userkey, $uservalue ) = split( /=>/, $_ );
                $userkey =~ s/^\s*([\'\"])/$1/g;    # substitute all whitespaces before " or '
                $userkey =~ s/([\'\"])\s*$/$1/g;    # substitute all whitespaces after " or '
                $userkey =~ s/[\'\"]//g;            # delete all ticks and double ticks
                unless ( $uservalue =~ /[\'\"]/ ) {

                    # match the number if element is no string
                    if ( $uservalue =~ /^\s*([+-]?\d+\.?\d*|[+-]?\.\d+)\s*$/g ) {
                        $uservalue =~ s/^\s+//g;
                        $uservalue =~ s/\s+$//g;
                        $goodhash{$userkey} = $uservalue;
                        $text .= " $userkey => $uservalue ,";
                    }
                    else {
                        S_set_error( " HASH Parameter error in $par_file: tc:$tc_id para:$tc_para_key userkey:$userkey value:$uservalue \n file skipped!!", 21 );
                        return;
                    }
                }
                else {
                    # its a string
                    $uservalue =~ s/^\s*([\'\"])/$1/g;    # substitute all whitespaces before " or '
                    $uservalue =~ s/([\'\"])\s*$/$1/g;    # substitute all whitespaces after " or '
                    $text .= " $userkey => $uservalue ,";
                    $uservalue =~ s/[\'\"]//g;            # delete all ticks and double ticks
                    $goodhash{$userkey} = $uservalue;
                }    #  else
                undef $userkey;
                undef $uservalue;
            }    # end foreach rawlist

            %{ $found_para_sets->{$parameter_set_active}{$tc_para_key}{'HASH'} } = %goodhash;
            chop $text;
            S_w2log( 5, " Parameter ( hash ) for $tc_id : $tc_para_key = %($text) \n" );    # before IC (will not be written to html)
        }    #  if / /
    }    #  foreach @all_lines

    if ( $par_file_type =~ /PRJ/i ) {
        return \%$found_para_sets;
    }

    if ( $par_file_type =~ /TC/i ) {
        return ( \%$found_para_sets, $validTCProjParSets, $tcparfile_VERSION );
    }
}

###------------------------------------------------------------------
### execute_init_campaign
###------------------------------------------------------------------

=head

    Subroutine Name :: execute_init_campaign
    Description     :: This function fills the hash with the details needed for the Init campaign
    Syntax          :: $init_cpg_result = execute_init_campaign();
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: verdict of the IC
    Description     :: Execution status of the IC such as pass, fail, inconclusive

=cut

sub execute_init_campaign {

    # validate whether the IC exist
    unless ( exists $ALL_TC->{'IC'} ) {
        S_set_error( " execute_init_campaign: bad function call ; ALL_TC->{'IC'} doesn't exist", 21 );
        $ALL_TC->{'IC'}{'TC_VERDICT'} = VERDICT_INCONC;
        $ALL_TC->{'IC'}{'END_TIME'}   = time();
        return $ALL_TC->{'IC'}{'TC_VERDICT'};
    }

    my $tc_id          = $ALL_TC->{'IC'}{'TC_ID'};
    my $tc_module      = $ALL_TC->{'IC'}{'TC_MODULE'};
    my $tc_module_file = $ALL_TC->{'IC'}{'TC_MODULE_FILE'};
    S_w2log( 5, "==> (INIT_CAMPAIGN) importing module $tc_module_file\n" );

    # throw warnings about checksums
    S_check_LIFT_component_integrity();

    return unless Fetch_sad_file_config();

    S_log_testbenchconfig_NOHTML();

    # note the start time of execution
    $ALL_TC->{'IC'}{'START_TIME'} = time();

    # eval & require the test module to check for syntax errors
    eval "require '$tc_module_file'";

    #check whether any error in loading the TC module
    if ($@) {
        S_set_error( "Error occured while loading Init campaign '$tc_module_file': $@", 21 );
        $ALL_TC->{'IC'}{'TC_VERDICT'} = $VERDICT;
        $ALL_TC->{'IC'}{'END_TIME'}   = time();
        return $ALL_TC->{'IC'}{'TC_VERDICT'};
    }

    # validate the structure of IC
    unless ( ValidateTCStructure( $tc_module, $tc_id ) ) {

        # log the error into report
        # S_set_error( " execute_init_campaign: invalid IC module '$tc_module' provided for the test", 21);
        #
        #  -> throwing error commented / function is already throwing an error
        #
        $ALL_TC->{'IC'}{'TC_VERDICT'} = $VERDICT;
        $ALL_TC->{'IC'}{'END_TIME'}   = time();
        return $ALL_TC->{'IC'}{'TC_VERDICT'};
    }

    ### PREPARE TC PARAMETERS
    if ( defined $ALL_TC->{'IC'}{'TC_PARAMETER'} ) {
        %TC_PARAMETER = %{ $ALL_TC->{'IC'}{'TC_PARAMETER'} };
    }
    ### INIT TC
    S_w2log( 5, "==> (INIT_CAMPAIGN) $tc_id Initialisation\n" );
    $ALL_TC->{'IC'}{'TC_INIT'} = do_TC_initialization($tc_module);

    #    return VERDICT_INCONC if $SYS_STATE eq SYS_FAIL;

    ### STIMU AND MEASURE TC
    if ( $SYS_STATE eq TC_INIT ) {
        S_w2log( 5, "==> (INIT_CAMPAIGN) $tc_id Stimulation and Measurement\n" );
        $ALL_TC->{'IC'}{'TC_STIMU'} = do_TC_stimulation_and_measurement($tc_module);

        #        return VERDICT_INCONC if $SYS_STATE eq SYS_FAIL;
    }

    ### EVAL TC
    if ( $SYS_STATE eq TC_STIMU ) {
        S_w2log( 5, "==> (INIT_CAMPAIGN) $tc_id Evaluation\n" );
        $ALL_TC->{'IC'}{'TC_EVAL'} = do_TC_evaluation($tc_module);
        $ALL_TC->{'IC'}{'TC_VERDICT'} = $VERDICT if $SYS_STATE eq TC_EVAL;    # <<--- VERDICT SETTING

        #        return VERDICT_INCONC if $SYS_STATE eq SYS_FAIL;
    }

    ### FINAL TC
    S_w2log( 5, "==> (INIT_CAMPAIGN) $tc_id Finalization\n" );
    $ALL_TC->{'IC'}{'TC_FINAL'} = do_TC_finalization($tc_module);

    #    return VERDICT_INCONC if $SYS_STATE eq SYS_FAIL;

    $ALL_TC->{'IC'}{'TC_VERDICT'} = $VERDICT;
    $ALL_TC->{'IC'}{'END_TIME'}   = time();

    return $ALL_TC->{'IC'}{'TC_VERDICT'};
}

###------------------------------------------------------------------
### execute_end_campaign
###------------------------------------------------------------------

=head

    Subroutine Name :: execute_end_campaign
    Description     :: This function fills the hash with the details needed for the end campaign
    Syntax          :: $end_cpg_result = execute_end_campaign();
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: verdict of the EC
    Description     :: Execution status of the EC such as pass, fail, inconclusive

=cut

sub execute_end_campaign {
    unless ( exists $ALL_TC->{'EC'} ) {
        S_set_error( " execute_end_campaign: bad function call ; ALL_TC->{'EC'} doesn't exist", 21 );
        return VERDICT_INCONC;
    }

    my $tc_id          = $ALL_TC->{'EC'}{'TC_ID'};
    my $tc_module      = $ALL_TC->{'EC'}{'TC_MODULE'};
    my $tc_module_file = $ALL_TC->{'EC'}{'TC_MODULE_FILE'};
    S_w2log( 5, "==> (END_CAMPAIGN) importing module $tc_module_file\n" );

    # note the start time of execution
    $ALL_TC->{'EC'}{'START_TIME'} = time();

    # eval & require the test module to check for syntax errors
    eval "require '$tc_module_file'";

    #check whether any error in loading the TC module
    if ($@) {
        S_set_error( "Error occured while loading End campaign '$tc_module_file': $@", 21 );
        $ALL_TC->{'EC'}{'TC_VERDICT'} = $VERDICT;
        $ALL_TC->{'EC'}{'END_TIME'}   = time();
        return $ALL_TC->{'EC'}{'TC_VERDICT'};
    }

    # validate the structure of IC
    unless ( ValidateTCStructure( $tc_module, $tc_id ) ) {

        # log the error into report
        # S_set_error( " execute_end_campaign: invalid EC module '$tc_module' provided for the test", 21);
        #
        #  -> throwing error commented / function is already throwing an error
        #
        $ALL_TC->{'EC'}{'TC_VERDICT'} = $VERDICT;
        $ALL_TC->{'EC'}{'END_TIME'}   = time();
        return $ALL_TC->{'EC'}{'TC_VERDICT'};
    }

    ### PREPARE TC PARAMETERS
    if ( defined $ALL_TC->{'EC'}{'TC_PARAMETER'} ) {
        %TC_PARAMETER = %{ $ALL_TC->{'EC'}{'TC_PARAMETER'} };
    }
    ### END TC
    S_w2log( 5, "==> (END_CAMPAIGN) $tc_id Initialisation\n" );
    $ALL_TC->{'EC'}{'TC_INIT'} = do_TC_initialization($tc_module);

    ### STIMU AND MEASURE TC
    if ( $SYS_STATE eq TC_INIT ) {
        S_w2log( 5, "==> (END_CAMPAIGN) $tc_id Stimulation and Measurement\n" );
        $ALL_TC->{'EC'}{'TC_STIMU'} = do_TC_stimulation_and_measurement($tc_module);
    }

    ### EVAL TC
    if ( $SYS_STATE eq TC_STIMU ) {
        S_w2log( 5, "==> (END_CAMPAIGN) $tc_id Evaluation\n" );
        $ALL_TC->{'EC'}{'TC_EVAL'} = do_TC_evaluation($tc_module);
        $ALL_TC->{'EC'}{'TC_VERDICT'} = $VERDICT if $SYS_STATE eq TC_EVAL;    # <<--- VERDICT SETTING AFTER EVALUATION
    }

    ### FINAL TC
    S_w2log( 5, "==> (END_CAMPAIGN) $tc_id Finalization\n" );
    $ALL_TC->{'EC'}{'TC_FINAL'} = do_TC_finalization($tc_module);

    $ALL_TC->{'EC'}{'TC_VERDICT'} = $VERDICT;
    $ALL_TC->{'EC'}{'END_TIME'}   = time();

    return $ALL_TC->{'EC'}{'TC_VERDICT'};
}

###------------------------------------------------------------------
### read_TC_meta_data (tc_module)
###------------------------------------------------------------------

sub read_TC_meta_data {    #  ${"${pack}::$name"}
    my $tc_module = shift;

    my ( $purpose, $version );

    no strict 'refs';
    if ( eval { $tc_module . "::" . $tc_purpose_var } ) {
        S_w2log( 5, " ==> Reading PURPOSE of $tc_module \n" );
        $purpose = ${ $tc_module . "::" . $tc_purpose_var };
    }
    else {
        S_w2log( 5, " ==> $tc_module has no PURPOSE \n" );
        $purpose = "no_purpose";
    }
    if ( eval { $tc_module . "::VERSION" } ) {
        S_w2log( 5, " ==> Reading VERSION of $tc_module \n" );
        $version = ${ $tc_module . "::VERSION" };
    }
    else {
        S_w2log( 5, " ==> $tc_module has no VERSION \n" );
        $version = "no_version";
    }
    return ( $purpose, $version );
}

###------------------------------------------------------------------
### do_TC_initialization
###------------------------------------------------------------------

=head

    Subroutine Name :: do_TC_initialization
    Description     :: This function helps in initialization of the testcases and campaigns and sets the  status of the test case as initialized
    Syntax          :: $ret_value  = do_TC_initialization( $tc_module );
    Input Arguments :: $tc_module
    Description     :: Testcase module
    Return Value(s) :: status
    Description     :: status of the test case

=cut

sub do_TC_initialization {
    my $tc_module = shift;

    my $para_return;
    my $init_return;

    S_set_sys_state(TC_INIT);

    # let the testcase read its parameters
    #IF parameter initialize function defined?
    if ( defined &{ $tc_module . "::" . $para_init_func } ) {

        #IF-YES-START
        my $pre_para_function_text = $pre_TC_function_text;
        $pre_para_function_text =~ s/LIFT_FUNCTION_NAME/$para_init_func/g;
        push( @TC_HTML_TEXT, $pre_para_function_text );

        S_w2log( 5, "==> Call $para_init_func\n" );

        #STEP call the TC set parameters function inside 'eval'
        {
            no strict 'refs';
            $para_return = eval { &{ $tc_module . "::" . $para_init_func }(); };
        }

        #STEP log the error to report if any runtime error found
        S_set_error( "perl execution error in function $tc_module" . "::" . "$para_init_func : $@", 21 ) if $@;

        unless ($para_return) {
            S_set_error( " TC_Module: $tc_module Function: $para_init_func() failed\n", 21 );
            return (ERROR);
        }

        push( @TC_HTML_TEXT, $post_TC_function_text );

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #IF testcase initialize function defined?
    if ( defined &{ $tc_module . "::" . $init_func } ) {

        #IF-YES-START

        my $pre_init_function_text = $pre_TC_function_text;
        $pre_init_function_text =~ s/LIFT_FUNCTION_NAME/$init_func/g;

        push( @TC_HTML_TEXT, $pre_init_function_text );

        #STEP call the TC_initialization function inside 'eval'
        {
            no strict 'refs';
            $init_return = eval { &{ $tc_module . "::" . $init_func }(); };
        }

        #STEP log the error to report if any runtime error found
        S_set_error( "perl execution error in function $tc_module" . "::" . "$init_func : $@", 21 ) if $@;
        unless ($init_return) {
            S_set_error( " TC_Module: $tc_module Function: $init_func() failed\n", 21 );
            return (ERROR);
        }
        push( @TC_HTML_TEXT, $post_TC_function_text );

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #      S_set_error ( "$init_func () in package $tc_module failed (bad package declaration?)!" , 22);
        #STEP log that no init function is defined
        S_w2log( 5, " -- INFO -- No $init_func () in package $tc_module defined\n" );

        #IF-NO-END
    }

    #STEP end
    if   ( $SYS_STATE eq TC_INIT ) { return ( OK, OK ) }
    else                           { return ( OK, ERROR ) }
}

###------------------------------------------------------------------
### do_TC_stimulation_and_measurement
###------------------------------------------------------------------

=head

    Subroutine Name :: do_TC_stimulation_and_measurement
    Description     :: This function helps in stimulating the given conditions in the testcases 
                       and sets the system state to either OK or ERROR depending on the TC status.
    Syntax          :: Result  = do_TC_stimulation_and_measurement( $tc_module );
    Input Arguments :: $tc_module
    Description     :: Testcase module
    Return Value(s) :: Result - ERROR , OK
    Description     :: status of the test case execution

=cut

sub do_TC_stimulation_and_measurement {
    my $tc_module = shift;

    my $tc_return;

    no strict 'refs';

    S_set_sys_state(TC_STIMU);

    #IF testcase stimulation and measurement function defined?
    if ( defined &{ $tc_module . "::" . $stimu_func } ) {

        #IF-YES-START

        my $pre_stimu_function_text = $pre_TC_function_text;
        $pre_stimu_function_text =~ s/LIFT_FUNCTION_NAME/$stimu_func/g;

        push( @TC_HTML_TEXT, $pre_stimu_function_text );

        #STEP call the TC_stimulation_and_measurement function inside 'eval'
        $tc_return = eval { &{ $tc_module . "::" . $stimu_func }(); };

        #STEP log the error to report if any runtime error found
        S_set_error( "perl execution error in function $tc_module" . "::" . "$stimu_func : $@", 21 ) if $@;

        unless ($tc_return) {
            S_set_error( " TC_Module: $tc_module Function: $stimu_func() failed\n", 21 );
            return (ERROR);
        }

        push( @TC_HTML_TEXT, $post_TC_function_text );

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #      S_set_error ( "$stimu_func () in package $tc_module failed (bad package declaration?)!" , 22);
        #STEP log that no stimu function is defined
        S_w2log( 5, " -- INFO -- No $stimu_func () in package $tc_module defined\n" );

        #IF-NO-END
    }

    #STEP end
    if   ( $SYS_STATE eq TC_STIMU ) { return OK }
    else                            { return ERROR }
}

###------------------------------------------------------------------
### do_TC_evaluation
###------------------------------------------------------------------

=head

    Subroutine Name :: do_TC_evaluation
    Description     :: This function evaluates the results of stimulation done in previous phase
                       and sets the system state to either OK or ERROR depending on the TC evaluation results.
    Syntax          :: Result  = do_TC_evaluation( $tc_module );
    Input Arguments :: $tc_module
    Description     :: Testcase module
    Return Value(s) :: Result - ERROR , OK
    Description     :: status of the test case evaluation

=cut

sub do_TC_evaluation {
    my $tc_module = shift;

    my $tc_return;

    no strict 'refs';

    S_set_sys_state(TC_EVAL);

    #IF testcase evaluation function defined?
    if ( defined &{ $tc_module . "::" . $eval_func } ) {

        #IF-YES-START
        my $pre_eval_function_text = $pre_TC_function_text;
        $pre_eval_function_text =~ s/LIFT_FUNCTION_NAME/$eval_func/g;

        push( @TC_HTML_TEXT, $pre_eval_function_text );

        #STEP call the TC_evaluation function inside 'eval'
        $tc_return = eval { &{ $tc_module . "::" . $eval_func }(); };

        #STEP log the error to report if any runtime error found
        S_set_error( "perl execution error in function $tc_module" . "::" . "$eval_func : $@", 21 ) if $@;

        unless ($tc_return) {
            S_set_error( " TC_Module: $tc_module Function: $eval_func() failed\n", 21 );
            return (ERROR);
        }

        push( @TC_HTML_TEXT, $post_TC_function_text );

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #      S_set_error ( "$eval_func() in package $tc_module failed (bad package declaration?)!" , 22);
        #STEP log that no eval function is defined
        S_w2log( 5, " -- INFO -- No $eval_func () in package $tc_module defined\n" );

        #IF-NO-END
    }

    #STEP end
    if   ( $SYS_STATE eq TC_EVAL ) { return OK }
    else                           { return ERROR }
}

###------------------------------------------------------------------
### do_TC_finalization
###------------------------------------------------------------------

=head

    Subroutine Name :: do_TC_finalization
    Description     :: This function sets the final verdict of the TC execution based on evaluation phase result
                       and sets the system state to either OK or ERROR.
    Syntax          :: Result  = do_TC_finalization( $tc_module );
    Input Arguments :: $tc_module
    Description     :: Testcase module
    Return Value(s) :: Result - ERROR , OK
    Description     :: status of the test case execution

=cut

sub do_TC_finalization {
    my $tc_module = shift;

    my $tc_return;

    no strict 'refs';

    S_set_sys_state(TC_FINAL);

    #IF testcase finalization function defined?
    if ( defined &{ $tc_module . "::" . $final_func } ) {

        #IF-YES-START

        my $pre_final_function_text = $pre_TC_function_text;
        $pre_final_function_text =~ s/LIFT_FUNCTION_NAME/$final_func/g;

        push( @TC_HTML_TEXT, $pre_final_function_text );

        #STEP call the TC_finalization function inside 'eval'
        $tc_return = eval { &{ $tc_module . "::" . $final_func }(); };

        #STEP log the error to report if any runtime error found
        S_set_error( "perl execution error in function $tc_module" . "::" . "$final_func : $@", 21 ) if $@;

        unless ($tc_return) {
            S_set_error( " TC_Module: $tc_module Function: $final_func() failed\n", 21 );
            return (ERROR);
        }

        push( @TC_HTML_TEXT, $post_TC_function_text );

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP log that no final function is defined
        S_w2log( 5, " -- INFO -- No $final_func () in package $tc_module defined\n" );

        #IF-NO-END
    }

    #STEP end
    if   ( $SYS_STATE eq TC_FINAL ) { return OK }
    else                            { return ERROR }
}

###------------------------------------------------------------------
### write report
###------------------------------------------------------------------

=head

    Subroutine Name :: Write_result_summary_to_logs
    Description     :: Writes a summary of the TC results to the logs.
    Syntax          :: Write_result_summary_to_logs();
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: Success/Failure
    Description     :: Returns success or failure status of the report generation

=cut

sub Write_result_summary_to_logs {

    my ( $tc_id, $tc_init, $tc_stimu, $tc_eval, $tc_final, $tc_verdict, $err_str );

    my @tc_errors = ("");

    S_w2log( 5, "\nNr  TC_ID                -> TC_VERDICT   <- init - stimu - eval - final  errors \n" );    # after EC (will not be written to html)
                                                                                                             #LOOP-START Loop over all test cases in $ALL_TC hash
    foreach my $tc_cnt ( sort { $a <=> $b } keys %$ALL_TC ) {
        $tc_id = $ALL_TC->{$tc_cnt}{'TC_ID'};

        next unless defined $tc_id;

        # initialize all keys
        $tc_verdict = $ALL_TC->{$tc_cnt}{'TC_VERDICT'};
        $tc_init    = $ALL_TC->{$tc_cnt}{'TC_INIT'};
        $tc_stimu   = $ALL_TC->{$tc_cnt}{'TC_STIMU'};
        $tc_eval    = $ALL_TC->{$tc_cnt}{'TC_EVAL'};
        $tc_final   = $ALL_TC->{$tc_cnt}{'TC_FINAL'};
        @tc_errors  = @{ $ALL_TC->{$tc_cnt}{'TC_ERRORS'} } if defined $ALL_TC->{$tc_cnt}{'TC_ERRORS'};

        #STEP write summary line for testcase to logs
        $err_str = "";
        foreach my $err (@tc_errors) { $err_str .= " $err" unless $err == 0 }

        while ( length($tc_id) < 20 ) { $tc_id .= " "; }
        while ( length($tc_cnt) < 3 ) { $tc_cnt = "0" . $tc_cnt; }
        if ( $tc_verdict eq VERDICT_PASS ) {
            S_w2log( 5, "$tc_cnt $tc_id -> $tc_verdict <- $tc_init $tc_stimu $tc_eval $tc_final $err_str \n", 'green' );    # after EC (will not be written to html)
        }
        elsif ( $tc_verdict eq VERDICT_FAIL ) {
            S_w2log( 5, "$tc_cnt $tc_id -> $tc_verdict <- $tc_init $tc_stimu $tc_eval $tc_final $err_str \n", 'red' );      # after EC (will not be written to html)
        }
        elsif ( $tc_verdict eq VERDICT_INCONC ) {
            S_w2log( 5, "$tc_cnt $tc_id -> $tc_verdict <- $tc_init $tc_stimu $tc_eval $tc_final $err_str \n", 'yellow' );    # after EC (will not be written to html)
        }
        elsif ( $tc_verdict eq VERDICT_BLOCKED ) {
            S_w2log( 5, "$tc_cnt $tc_id -> $tc_verdict <- $tc_init $tc_stimu $tc_eval $tc_final $err_str \n", 'magenta' );    # after EC (will not be written to html)
        }
        else {
            S_w2log( 5, "$tc_cnt $tc_id -> $tc_verdict <- $tc_init $tc_stimu $tc_eval $tc_final $err_str \n", 'cyan' );       # after EC (will not be written to html)
        }
    }

    #LOOP-END Last test case?

    return 1;
}

###------------------------------------------------------------------
### open_all_logs ( )
###------------------------------------------------------------------

=head

    Subroutine Name :: open_all_logs
    Description     :: open all log files and write start text in them
    Syntax          :: open_all_logs($lift_start_time);
    Input Arguments :: $lift_start_time
    Description     :: start time of LIFT execution
    Return Value(s) :: 1 
    Description     :: 1 upon success

=cut

sub open_all_logs {
    my $lift_start_time = shift;

    my ( $start_text, $start_date, $start_time, $LC_text );

    my $hint_text      = '';
    my $time_extension = Get_date_extension($lift_start_time);

    #STEP create name for report folder
    ### take just the filename from long name of testlist
    ### (e.g. take 'TL.txt' from '...../Testlistdir/TL.txt')
    ($save_name) = fileparse($TestList) unless $save_name;

    ### replace my_special.test_list.txt with my_special_test_list
    if ( $save_name =~ /\./g ) {
        my $save_name_temp = $save_name;
        my @pieces = split( /\./, $save_name );
        pop @pieces;    ## delete .txt extension
        $save_name = join( '_', @pieces );
    }

    ### add time extension
    $save_name = $save_name . "_" . $time_extension;

    ### add OFFLINE_ before folder and log files if campaign run in OFFLINE mode
    $save_name = "OFFLINE_" . $save_name if $opt_offline;

    ### store this name file name
    ###    for later creation of the right hyper link in Campaign report
    ###      (used in function 'Write_tc_results_to_logs')
    $tc_html_dir_relative = ".";

    $save_name = "$LIFT_config::LIFT_LOG_path/$save_name" if $LIFT_config::LIFT_LOG_path;

    #STEP create folder for tc logs of complete campaign
    unless ( mkdir($save_name) ) { S_set_error( "Creating dir $save_name : $!", 1 ); return 0; }
    $REPORT_PATH = abs_path($save_name);

    #CALL S_open_log
    S_open_log("$save_name/$main_LOG_name");

    #CALL S_open_result
    S_open_result("$save_name/_main");

    #CALL Create_jUnit_xml_root for junit xml reporting
    Create_jUnit_xml_root();

    #STEP Write command line options to log
    S_w2log( 5, " Executing with command line options : @command_line_arg\n" );

    #STEP copy all html stuff to the report folder (in directory htmldata: gifs for the table sorter, stylesheets, javascript)
    S_w2log( 5, " copy htmldata to $save_name\n" );    # before IC (will not be written to html)
    $LIFT_htmldataSource =~ s/\//\\/g;                 # replace all slashes with backslahes
    my $LIFT_htmldataTarget = "$REPORT_PATH\\htmldata";
    $LIFT_htmldataTarget =~ s/\//\\/g;                 # replace all slashes with backslahes
    my $result = system("xcopy $LIFT_htmldataSource $LIFT_htmldataTarget /E /I /H /Q > nul");    # copy path with DOS command xcopy
                                                                                                 #error?
    if ($result) {
        my $text = "WARNING: could not copy entire '$LIFT_htmldataTarget' directory to $REPORT_PATH: $!<br>Please check manually which files could not be copied by comparing folders ! Test will be started nevertheless but reports might not look pretty.";
        S_w2res_html("<span style=\"color:red;font-weight:bold\">$text</span>\n");
        S_w2log( 5, " 2nd try: Copy eveything which is possible\n" );                            # before IC (will not be written to html)
        system("xcopy $LIFT_htmldataSource $LIFT_htmldataTarget /E /I /H /Q /C > nul");          # copy path with DOS command xcopy
    }
    else {
        S_w2log( 5, " Copied 'htmldata' folder.\n" );                                            # before IC (will not be written to html)
    }

    #STEP create snapshot folder
    $RERUN_PATH = $REPORT_PATH . "/$RERUN_name";
    unless ( mkdir($RERUN_PATH) ) { S_set_error( "Creating dir $RERUN_PATH : $!", 1 ); return 0; }
    $RERUN_PATH =~ s/\//\\/g;                                                                    # replace all slashes with backslahes

    ( $start_date, $start_time ) = S_formated_timestamp($lift_start_time);

    #STEP set report logos
    if ( defined $LIFT_config::left_logo ) {
        $left_logo_html   = "<IMG SRC=\"$LIFT_config::left_logo\" alt=\"$LIFT_config::left_logo\" >";
        $TCleft_logo_html = $LIFT_config::left_logo;
        $TCleft_logo_html = "<IMG SRC=\"$TCleft_logo_html\" alt=\"$TCleft_logo_html\" >";
    }
    if ( defined $LIFT_config::right_logo ) {
        $right_logo_html   = "<IMG SRC=\"$LIFT_config::right_logo\" alt=\"$LIFT_config::right_logo\" >";
        $TCright_logo_html = $LIFT_config::right_logo;
        $TCright_logo_html = "<IMG SRC=\"$TCright_logo_html\" alt=\"$TCright_logo_html\" >";
    }

    if ( defined $Simulator ) {
        $LC_text = "--> runs on Simulator  : $Simulator";
    }
    else { $Simulator = $not_given; }

    my $username = getlogin || getpwuid($<);

    #     my $LIFT_version_HTML_link = "<a href=\"$LIFT_version_API_docu\" TYPE=\"execution/pl\" class=\"thoughtbot\">$LIFT_version</a>";
    my $LIFT_version_HTML_link = "<a href=\"$LIFT_version_API_docu\">$LIFT_version</a>";

    #STEP create text log file header
    $start_text = <<EOT;

--> LIFT version      : $LIFT_version
--> LIFT exec engine  : $0
--> LIFT testcases    : @tc_paths
--> Testlist           : $TestList
--> Configuration      : $opt_conf
--> started at         : $start_date  $start_time
--> started on         : $LIFT_config::LIFT_host
--> started by         : $username
$LC_text
EOT

    $start_text .= "--> RUNNING IN OFFLINE MODE\n"                  if $opt_offline;
    $start_text .= "--> taking IC from Engine option -IC $opt_IC\n" if $opt_IC;
    $start_text .= "--> taking EC from Engine option -EC $opt_EC\n" if $opt_EC;

    S_w2rep($start_text);

    S_w2res( "CPG_START" . $csv_result_delim . "$save_name" . $csv_result_delim . "$Simulator" . $csv_result_delim . "$start_date" . $csv_result_delim . "$start_time" . "\n" );

    #CALL Check_checksums to evaluate if the engine modules are according to a baseline
    Check_checksums();
    my $engineVersion = $checksumResultsAll_href->{Components}{'TurboLIFT_Engine'}{Version} // 'unknown';

    #CALL Get_component_integrity to check if used version is Obsolete or not
    my $componentCheckPoint_log = Get_component_integrity();

    #STEP define extra red hint for html report if test is offline or checksums not correct
    if ($opt_offline) {
        $hint_text .= <<EOD;
    <!-- Remark that Test run in OFFLINE mode -->
    <H3 style="font-family:Arial; color:red">(running in OFFLINE mode, not on real HW)</H3>
EOD
    }
    if ( not $checksumResultsAll_href->{overallOK} ) {
        $hint_text .= <<EOD;
    <!-- Remark that Test run with modified engine -->
    <H3 style="font-family:Arial; color:red">$modifiedEngineAdvice</H3>
EOD
    }

    if ( $componentCheckPoint_log ne 'ALL_OK' ) {
        $hint_text .= <<EOD;
    <!-- Remark that Test run with Obsolete engine -->
    <H3 style="font-family:Arial; color:red">$componentCheckPoint_log</H3>
EOD
    }

    #STEP set project description
    if ( defined $LIFT_config::LIFT_ProjectDescription ) {
        $LIFT_ProjectDescription           = $LIFT_config::LIFT_ProjectDescription;
        $LIFT_ProjectDescription_html_code = <<EOLVER;
        $LIFT_ProjectDescription
EOLVER

    }
    else {
        S_set_warning(" Missing definition of LIFT_config::LIFT_ProjectDescription in LIFT project config (Project Name to be set)");
        $LIFT_ProjectDescription = " - - - LIFT_config::LIFT_ProjectDescription - - - (Project Name to be set)";
    }

    #STEP create html log file header
    $start_text = <<EOHTML;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Start HTML Header -->
    <HTML><HEAD>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
    <META HTTP-EQUIV="refresh" CONTENT="60">
    <META NAME="Generator" CONTENT="LIFT exec engine">
    <TITLE>LIFT RESULT: $save_name ( $start_date  $start_time )</TITLE>
    <script type="text/javascript" src="$tc_html_dir_relative/htmldata/js/jquery-latest.js"></script>
    <script type="text/javascript" src="$tc_html_dir_relative/htmldata/js/jquery.tablesorter.js"></script>
    <script type="text/javascript">
        \$.tablesorter.addParser({
            id: "customID",
            is: function(s) {
                return /\\d{1,5}|ID/.test(s);
            },
            format: function(s) {
                s = s.replace(/IC/g,0);
                s = s.replace(/EC/g,9999999);
                return \$.tablesorter.formatFloat(s);
            },
            type: "numeric"
        });

        \$(document).ready(function()
        {
            \$("#executionList").tablesorter({
                headers: { 0: {sorter:'customID'} },
                sortList: [[0,0]],
            });

        });
    </script>
    <link rel="stylesheet" href="$tc_html_dir_relative/htmldata/css/style.css" type="text/css" media="print, projection, screen" >
    </HEAD>
<!-- End HTML Header -->
<!-- Start HTML Body -->
<BODY DIR="LTR" BGCOLOR="#FFFFFF">
    <!-- LIFT Headline -->
<div id="header">
<ul id="navlist">
<li><a href="../Reports.html">Back to report overview</a></li>
<li>Jump to</li>
<li><a href="#Top">Top</a></li>
<li><a href="#Summary">Summary</a></li>
</ul>
</div>

<div id="content"><a name="Top" id="Top"></a>
<TABLE><TR>
    <TD>$left_logo_html</TD><TD WIDTH="100%">
    <div style="font-family:Arial; color:grey; font-size:x-large; font-weight:bold; text-align:center">LIFT Campaign Report</div>
    <div style="font-family:Arial; font-weight:bold; text-align:center">$LIFT_ProjectDescription_html_code</div>
    </TD><TD>$right_logo_html</TD>
</TR></TABLE>

$hint_text
    <!-- horizontal line -->
    <HR>
    <!-- header table with start informations -->
    <TABLE style="font-family:Courier"  class="tablesorter" WIDTH=562>
	    <!-- Command line options: Executed options -->
        <TR><TH WIDTH="34%">Executed with command line options:</TH><TD WIDTH="66%">@command_line_arg</TD></TR>
        <!-- Processed Testlist: myTestlist -->
        <TR><TH WIDTH="34%">Processed Testlist:</TH><TD WIDTH="66%">$TestList</TD></TR>
        <!-- Used Configuration: myConfiguration -->
        <TR><TH WIDTH="34%">Used Configuration:</TH><TD WIDTH="66%">$opt_conf</TD></TR>
        <!-- Start Date/Time:  -->
        <TR><TH WIDTH="34%">Start Date/Time:</TH><TD WIDTH="66%">$start_date  $start_time</TD></TR>
        <!-- hostname/user:  -->
        <TR><TH WIDTH="34%">user/hostname:</TH><TD WIDTH="66%">$username on $LIFT_config::LIFT_host</TD></TR>
        <!-- LIFT version:  -->       
        <TR><TH WIDTH="34%">LIFT version:</TH><TD WIDTH="66%">$LIFT_version_HTML_link</TD></TR>
        <!-- LIFT engine component version:  -->       
        <TR><TH WIDTH="34%">LIFT engine version:</TH><TD WIDTH="66%">$engineVersion</TD></TR>
    </TABLE>

    <!-- horizontal line -->
    <HR>
    <iframe src="file:///C:/temp/LIFT/status.txt" width="100%" height=250 name="status_box" ><p>your browser cannot display embedded frames, so you miss the status_box</p></iframe>
    <p ID="thoughtbot" style="margin:20px 10px;"><a href="file:///$LIFT_exec_path\\stop_after_TC.pl" TYPE="execution/pl" class="thoughtbot">stop test execution after current test case (via perl script)</a></p>

    <!-- headline " Execution List "-->
 <a name="ExecutionList" id="ExecutionList"></a>
<h2 style="font-family:Arial">Execution List</h2>
$hint_text
    <!-- start main table of testcase execution -->

    <TABLE style="font-family:Courier" id="executionList"  class="tablesorter">
        <!-- header of table of testcase execution -->
        <!-- Nbr | TC_ID | VERDICT | Time (sec) | INIT | STIM | EVAL | FINA | Purpose | Exec Errors -->
         <thead>
        <TR ALIGN="CENTER">
            <TH COLSPAN=4>Test Case Summary</TH>
            <TH COLSPAN=3>Test Purpose</TH>
        </TR>
        <TR ALIGN="CENTER">
            <TH WIDTH="5%">Nbr&nbsp;</TH>
            <TH WIDTH="29%">Testcase ID</TH>
            <TH WIDTH="8%">VERDICT&nbsp;</TH>
            <TH WIDTH="6%">Time (sec)&nbsp;&nbsp;</TH>
            <TH WIDTH="26%">TC Module</TH>
            <TH WIDTH="15%">TC Para</TH>
            <TH WIDTH="11%">Prj Para</TH>
        </TR>
        </thead>
        
EOHTML

    S_w2res_html($start_text);

    #STEP fill meta data into project info for further use with S_get_project_info
    my $project_info_href = {
        'testlist'           => $TestList,
        'configuration'      => $opt_conf,
        'start_date'         => $start_date,
        'start_time'         => $start_time,
        'username'           => $username,
        'hostname'           => hostname(),
        'LIFT_version'       => $LIFT_version,
        'ProjectDescription' => $LIFT_ProjectDescription,
    };

    S_set_project_info($project_info_href);

    #STEP open html report in browser if not polite mode
    if ($opt_polite) {
        S_w2log( 5, "report popup suppressed (polite mode)\n" );
    }
    else {
        #    system('start "C:\Program Files\Internet Explorer\iexplore.exe" '."$REPORT_PATH"."_result.html"); # open in IE
        #    system('start "C:\Program Files\Mozilla Firefox\firefox.exe" file:///'."$REPORT_PATH"."_result.html"); # open in Firefox
        if ( -e 'C:\Program Files (x86)\Mozilla Firefox\firefox.exe' ) {

            # workaround with 'CMD' because just calling 'start' causes MKS error 'wrong OS' (there is a start.exe in MKS subfolder)
            system( 'CMD /C start "C:\Program Files (x86)\Mozilla Firefox\firefox.exe" file:///' . "$REPORT_PATH" . '/' . $main_LOG_name );    # open in Firefox Win7
        }
        elsif ( -e 'C:\Program Files\Mozilla Firefox\firefox.exe' ) {
            system( 'start "C:\Program Files\Mozilla Firefox\firefox.exe" file:///' . "$REPORT_PATH" . '/' . $main_LOG_name );                 # open in Firefox
        }
        else {
            S_w2log( 5, " could not open Firefox to display report\n" );
        }
    }

    return 1;
}

###------------------------------------------------------------------
### Write_tc_results_to_logs ( $TC_start_time, $TC_end_time )
###------------------------------------------------------------------

=head

    Subroutine Name :: Write_tc_results_to_logs
    Description     :: write testcase infos in several log files
    Syntax          :: Write_tc_results_to_logs($tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time);
    Input Arguments :: $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time
    Description     :: $tc_id - TC ID, $tc_cnt - TC count, $max_nr - number of TCs to execute, $TC_start_time - TC start time , $TC_end_time - TC end time
    Return Value(s) :: 1 
    Description     :: 1 upon success

=cut

sub Write_tc_results_to_logs {
    my ( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time ) = (@_);

    #CALL Prepare_tc_results_data
    my $tc_results_href = Prepare_tc_results_data( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );

    #CALL Write_text_result_file
    Write_to_text_result_file($tc_results_href);

    #CALL Write_to_status_window
    Write_to_status_window($tc_results_href);

    #CALL Write_to_campaign_report
    Write_to_campaign_report($tc_results_href);

    #STEP START LIFT TESTCASE HTML REPORT

    my $summary_file = "$main_LOG_name";
    ### header of TC HTML log file --------------------------------------------
    my $tc_start_text_in_html_log = <<EOHTML;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Start HTML Header -->
    <HTML><HEAD>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
    <META NAME="Generator" CONTENT="LIFT exec engine">
    <TITLE>LIFT Testcase Report: $tc_id</TITLE>

EOHTML

    $tc_results_href->{summary_file}              = $summary_file;
    $tc_results_href->{tc_start_text_in_html_log} = $tc_start_text_in_html_log;

    #IF html filters configured?
    if ( not defined $ProjectDefaults->{'REPORTING'}{'HTML_FILTER_USE'} or $ProjectDefaults->{'REPORTING'}{'HTML_FILTER_USE'} == 1 ) {

        #IF-YES-START
        #CALL Write_html_with_filter
        Write_html_with_filter($tc_results_href);

        #IF-YES-END
    }

    else {
        #IF-NO-START
        #CALL Write_html_no_filter
        Write_html_no_filter($tc_results_href);

        #IF-NO-END
    }

    #CALL Write_to_testcase_report
    Write_to_testcase_report($tc_results_href);

    #STEP CREATE EVAL TABLE
    my $start_date = $tc_results_href->{start_date};
    my $start_time = $tc_results_href->{start_time};
    my $tc_verdict = $tc_results_href->{tc_verdict};

    S_add2eval_collection( 'NBR',       $file_prefix_number );
    S_add2eval_collection( 'DATE_TIME', "$start_date $start_time" );
    S_add2eval_collection( 'TC_ID',     $tc_id );

    my $eval_verdict = $tc_verdict;
    $eval_verdict =~ s/VERDICT_//;
    S_add2eval_collection( 'VERDICT', $eval_verdict );

    ### write all TC eval infos in on (excel) line into eval file (%EVAL_COLLECTION in LIFT_general)
    S_w2eval();
    ### now %EVAL_COLLECTION is empty for next TC

    return 1;
}

sub Prepare_tc_results_data {
    my ( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time ) = (@_);

    my $tc_results_href;

    $tc_results_href->{tc_id}  = $tc_id;
    $tc_results_href->{tc_cnt} = $tc_cnt;
    $tc_results_href->{max_nr} = $max_nr;

    my ( @tc_par_description_key,  $tc_par_purpose );
    my ( @prj_par_description_key, $prj_par_purpose );
    my ( $SRT_ID_txt,              $SRT_fullname_txt );

    if ( @tc_par_description_key = grep { /purpose|description/i } keys %{ $ALL_TC->{$tc_cnt}{'TC_PARAMETER'} } ) {
        $tc_par_purpose = $ALL_TC->{$tc_cnt}{'TC_PARAMETER'}{ $tc_par_description_key[0] }{'SCALAR'};
    }

    if ( defined $ALL_TC->{$tc_cnt}{'TC_PARAMETER'}{'SRT_ID'}{'SCALAR'} ) {
        $SRT_ID_txt = $ALL_TC->{$tc_cnt}{'TC_PARAMETER'}{'SRT_ID'}{'SCALAR'};
    }
    else { $SRT_ID_txt = $not_given; }
    if ( defined $ALL_TC->{$tc_cnt}{'TC_PARAMETER'}{'SRT_fullname'}{'SCALAR'} ) {
        $SRT_fullname_txt = $ALL_TC->{$tc_cnt}{'TC_PARAMETER'}{'SRT_fullname'}{'SCALAR'};
    }
    else { $SRT_fullname_txt = $not_given; }

    ## in case of missing TC parameter file
    if ( $ALL_TC->{$tc_cnt}->{'NO_TC_PARA_FILE'} ) { $tc_par_purpose = "ERROR: No TC Parameter File found"; }

    ## in case of missing TC parameters set hint
    if ( $ALL_TC->{$tc_cnt}->{'NO_TC_PARA'} ) { $tc_par_purpose = "ERROR: NO TC Parameter Set found"; }

    if ( @prj_par_description_key = grep { /purpose|description/i } keys %{ $ALL_TC->{$tc_cnt}{'TC_PRJ_PARAMETER'} } ) {
        $prj_par_purpose = $ALL_TC->{$tc_cnt}{'TC_PRJ_PARAMETER'}{ $prj_par_description_key[0] }{'SCALAR'};
    }

    ## in case of bad Prj Par Ext overwrite $prj_par_purpose
    if ( $ALL_TC->{$tc_cnt}->{'BAD_PRJ_EXT'} ) { $prj_par_purpose = "ERROR: Bad Parameter Extension"; }

    #    my $tc_html_file_link = $tc_html_dir_relative."/".$OFFLINE.$tc_cnt."_".$tc_id.".html";
    my $tc_html_file_link = $tc_html_dir_relative . "/" . $OFFLINE . $file_prefix_number . "_" . $tc_id_for_file_name . ".html";

    my ( $tc_purpose, $tc_version ) = read_TC_meta_data( $ALL_TC->{$tc_cnt}{'TC_MODULE'} );
    $tc_version = '?' unless defined($tc_version);

    ## in case of missing TC parameters set hint  (change purpose)
    $tc_purpose = "ERROR: NO TC Module File found" if $ALL_TC->{$tc_cnt}->{'NO_TC_MODULE'};

    ## in case of wrong module design set hint  (change purpose)
    $tc_purpose = "ERROR: Wrong Design of TC Module" if $ALL_TC->{$tc_cnt}->{'WRONG_DESIGN_TC_MODULE'};

    my $tc_verdict = $ALL_TC->{$tc_cnt}{'TC_VERDICT'};

    my ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);
    my ( $end_date,   $end_time )   = S_formated_timestamp($TC_end_time);
    my $duration = $TC_end_time - $TC_start_time;

    S_w2log( 5, "   >>>>  $tc_id  <<<<\n",   'cyan' );
    S_w2log( 5, "   ==> $tc_verdict <<<<\n", 'cyan' );
    S_w2rep("   stopped at $end_date $end_time \n");
    S_w2log( 5, "   elapsed $duration sec\n\n" );
    print "\a" if $opt_beep;

    $tc_results_href->{tc_purpose}        = $tc_purpose;
    $tc_results_href->{tc_par_purpose}    = $tc_par_purpose;
    $tc_results_href->{prj_par_purpose}   = $prj_par_purpose;
    $tc_results_href->{start_date}        = $start_date;
    $tc_results_href->{start_time}        = $start_time;
    $tc_results_href->{tc_cnt}            = $tc_cnt;
    $tc_results_href->{tc_verdict}        = $tc_verdict;
    $tc_results_href->{duration}          = $duration;
    $tc_results_href->{SRT_fullname_txt}  = $SRT_fullname_txt;
    $tc_results_href->{SRT_ID_txt}        = $SRT_ID_txt;
    $tc_results_href->{tc_html_file_link} = $tc_html_file_link;
    $tc_results_href->{tc_version}        = $tc_version;

    return $tc_results_href;
}

sub Write_to_text_result_file {
    my $tc_results_href = shift;

    my $tc_cnt           = $tc_results_href->{tc_cnt};
    my $tc_id            = $tc_results_href->{tc_id};
    my $duration         = $tc_results_href->{duration};
    my $start_date       = $tc_results_href->{start_date};
    my $start_time       = $tc_results_href->{start_time};
    my $tc_purpose       = $tc_results_href->{tc_purpose};
    my $tc_par_purpose   = $tc_results_href->{tc_par_purpose};
    my $prj_par_purpose  = $tc_results_href->{prj_par_purpose};
    my $tc_verdict       = $tc_results_href->{tc_verdict};
    my $SRT_fullname_txt = $tc_results_href->{SRT_fullname_txt};
    my $SRT_ID_txt       = $tc_results_href->{SRT_ID_txt};

    if   ($tc_purpose) { $tc_purpose =~ s/$csv_result_delim/$csv_result_delim_repl/g; }
    else               { $tc_purpose = $not_given; }

    if   ($tc_par_purpose) { $tc_par_purpose =~ s/$csv_result_delim/$csv_result_delim_repl/g; }
    else                   { $tc_par_purpose = $not_given; }

    if   ($prj_par_purpose) { $prj_par_purpose =~ s/$csv_result_delim/$csv_result_delim_repl/g; }
    else                    { $prj_par_purpose = $not_given; }

    unless ( $tc_cnt eq 'IC' or $tc_cnt eq 'EC' or not $checksumResultsAll_href->{overallOK} ) {
        ## get contents from eval_text
        my ( $expected, $detected, $stimulation ) = S_get_eval_text();

        ## add global informations
        $detected = "{\\i SW: $ECU_SW_VERSION \t Started at $start_date $start_time} \t" . $detected;

        if ( defined $stimulation ) {    # --> new format (stimulation steps)
            S_w2res("TC_VD"
                  . $csv_result_delim
                  . "$tc_id"
                  . $csv_result_delim
                  . "$tc_verdict"
                  . $csv_result_delim
                  . "$start_date"
                  . $csv_result_delim
                  . "$start_time"
                  . $csv_result_delim
                  . "$duration"
                  . $csv_result_delim
                  . "$file_prefix_number"
                  . $csv_result_delim
                  . "$tc_purpose"
                  . $csv_result_delim
                  . "$tc_par_purpose"
                  . $csv_result_delim
                  . "$prj_par_purpose"
                  . $csv_result_delim
                  . "$SRT_fullname_txt"
                  . $csv_result_delim
                  . "$SRT_ID_txt"
                  . $csv_result_delim
                  . $expected
                  . $csv_result_delim
                  . $detected
                  . $csv_result_delim
                  . $stimulation );
        }
        else {    # --> old format (no stimulation steps)
            S_w2res("TC_VD"
                  . $csv_result_delim
                  . "$tc_id"
                  . $csv_result_delim
                  . "$tc_verdict"
                  . $csv_result_delim
                  . "$start_date"
                  . $csv_result_delim
                  . "$start_time"
                  . $csv_result_delim
                  . "$duration"
                  . $csv_result_delim
                  . "$file_prefix_number"
                  . $csv_result_delim
                  . "$tc_purpose"
                  . $csv_result_delim
                  . "$tc_par_purpose"
                  . $csv_result_delim
                  . "$prj_par_purpose"
                  . $csv_result_delim
                  . "$SRT_fullname_txt"
                  . $csv_result_delim
                  . "$SRT_ID_txt"
                  . $csv_result_delim
                  . $expected
                  . $csv_result_delim
                  . $detected );
        }
    }

    $tc_results_href->{tc_purpose}      = $tc_purpose;
    $tc_results_href->{tc_par_purpose}  = $tc_par_purpose;
    $tc_results_href->{prj_par_purpose} = $prj_par_purpose;

    return 1;
}

=head2 Write_jUnit_XML_file

    Write_jUnit_XML_file ();

writes Junit xml data to _main__result.xml

B<Arguments:>

=over

NONE

B<Return Value: 1>

=back

=cut

sub Write_jUnit_XML_file {

    unless ( defined $JUNIT_XmlRoot_href->{'jUnitXML_obj'} ) {
        S_w2log( 3, " Write_jUnit_XML_file: NO jUNitXml Object defined -> return\n" );
        return;
    }

    my $JUNIT_XML_obj = $JUNIT_XmlRoot_href->{'jUnitXML_obj'};

    open( my $fhMeasurementXMLFile, ">", "$REPORT_PATH/_main__result.xml" ) or S_set_error(" $! ");
    print $fhMeasurementXMLFile $JUNIT_XML_obj->toString( 1, 'utf-8' );
    close($fhMeasurementXMLFile);

    return 1;
}

sub Write_to_status_window {
    my $tc_results_href = shift;

    my $tc_cnt          = $tc_results_href->{tc_cnt};
    my $max_nr          = $tc_results_href->{max_nr};
    my $tc_id           = $tc_results_href->{tc_id};
    my $duration        = $tc_results_href->{duration};
    my $start_date      = $tc_results_href->{start_date};
    my $start_time      = $tc_results_href->{start_time};
    my $tc_purpose      = $tc_results_href->{tc_purpose};
    my $tc_par_purpose  = $tc_results_href->{tc_par_purpose};
    my $prj_par_purpose = $tc_results_href->{prj_par_purpose};

    my ( $tc_passed, $tc_failed, $tc_inconc, $tc_blocked, $tc_none ) = 0;
    $tc_passed  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_PASS};
    $tc_failed  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_FAIL};
    $tc_inconc  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_INCONC};
    $tc_blocked = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_BLOCKED};
    $tc_none    = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_NONE};

    #update status after test case
    my $err_str = "";
    foreach my $err ( @{ $ALL_TC->{$tc_cnt}{'TC_ERRORS'} } ) { $err_str .= " $err" unless $err == 0 }
    @status_msg = ("running Test $tc_cnt of $max_nr: $tc_id");
    push( @status_msg, "" );
    push( @status_msg, "$opt_testlist" );
    push( @status_msg, "$opt_conf" );
    push( @status_msg, "" );
    push( @status_msg, "$file_prefix_number $tc_id -> $VERDICT <- " . $ALL_TC->{$tc_cnt}{'TC_INIT'} . " " . $ALL_TC->{$tc_cnt}{'TC_STIMU'} . " " . $ALL_TC->{$tc_cnt}{'TC_EVAL'} . " " . $ALL_TC->{$tc_cnt}{'TC_FINAL'} . " errors: " . $err_str );
    push( @status_msg, "duration : $duration (sec), started on $start_date at $start_time " );
    push( @status_msg, "TC purpose : \"$tc_purpose\"" );
    push( @status_msg, "TC Para Purpose : \"$tc_par_purpose\"" );
    push( @status_msg, "Prj Para Purpose : \"$prj_par_purpose\"" );
    push( @status_msg, "" );
    push( @status_msg, " $tc_passed PASSED    $tc_failed FAILED    $tc_inconc INCONC    $tc_blocked BLOCKED    $tc_none NONE " );

    $CAMPAIGN_STATUS = " $tc_passed PASSED    $tc_failed FAILED    $tc_inconc INCONC    $tc_blocked BLOCKED    $tc_none NONE    of $max_nr TOTAL";
    Update_status_external();

    return 1;
}

sub Write_to_campaign_report {
    my $tc_results_href = shift;

    my $tc_verdict        = $tc_results_href->{tc_verdict};
    my $tc_cnt            = $tc_results_href->{tc_cnt};
    my $duration          = $tc_results_href->{duration};
    my $tc_html_file_link = $tc_results_href->{tc_html_file_link};
    my $tc_id             = $tc_results_href->{tc_id};
    my $tc_purpose        = $tc_results_href->{tc_purpose};
    my $tc_par_purpose    = $tc_results_href->{tc_par_purpose};
    my $prj_par_purpose   = $tc_results_href->{prj_par_purpose};

    my $verdict_color;
    $verdict_color = "green"   if $tc_verdict eq VERDICT_PASS;
    $verdict_color = "red"     if $tc_verdict eq VERDICT_FAIL;
    $verdict_color = "purple"  if $tc_verdict eq VERDICT_INCONC;
    $verdict_color = "magenta" if $tc_verdict eq VERDICT_BLOCKED;
    $verdict_color = "blue"    if $tc_verdict eq VERDICT_NONE;

    my $html_verdict = $tc_verdict;
    $html_verdict =~ s/VERDICT_//;

    my $tc_html_verdict_link = $tc_html_file_link . '#' . $tc_verdict;    # create a link to where the test case verdict is set

    my $tc_text_in_cpg_result = <<EOHTML;
        <!-- info line of testcase: $tc_id -->
        <!-- Nbr | TC_ID | VERDICT | Time (sec) | TC Mod Purpose | TC par Purpose | Prj Par Purpose  -->
            <TR>
                <TD ALIGN="RIGHT">$tc_cnt</TD>
                <TD><A HREF="$tc_html_file_link">$tc_id</A></TD>
                <TD ALIGN="CENTER"><A HREF="$tc_html_verdict_link"><span style="color:$verdict_color">$html_verdict</span></TD>
                <TD>$duration</TD>
                <TD>$tc_purpose</TD>
                <TD>$tc_par_purpose</TD>
                <TD>$prj_par_purpose</TD>
            </TR>
EOHTML

    ### write tc in execution table of HTML campaign result file --------------
    S_w2res_html($tc_text_in_cpg_result);

    my $html_init = $ALL_TC->{$tc_cnt}{'TC_INIT'};
    $html_init =~ s/-//g;
    my $html_stimu = $ALL_TC->{$tc_cnt}{'TC_STIMU'};
    $html_stimu =~ s/-//g;
    my $html_eval = $ALL_TC->{$tc_cnt}{'TC_EVAL'};
    $html_eval =~ s/-//g;
    my $html_final = $ALL_TC->{$tc_cnt}{'TC_FINAL'};
    $html_final =~ s/-//g;

    $tc_results_href->{html_init}     = $html_init;
    $tc_results_href->{html_stimu}    = $html_stimu;
    $tc_results_href->{html_eval}     = $html_eval;
    $tc_results_href->{html_final}    = $html_final;
    $tc_results_href->{html_verdict}  = $html_verdict;
    $tc_results_href->{verdict_color} = $verdict_color;

    return 1;
}

sub Write_html_with_filter {
    my $tc_results_href = shift;

    my $tc_start_text_in_html_log = $tc_results_href->{tc_start_text_in_html_log};
    my $summary_file              = $tc_results_href->{summary_file};
    my $html_init                 = $tc_results_href->{html_init};
    my $html_stimu                = $tc_results_href->{html_stimu};
    my $html_eval                 = $tc_results_href->{html_eval};
    my $html_final                = $tc_results_href->{html_final};

    $tc_start_text_in_html_log .= <<EOHTML;
    <script type="text/javascript" src="htmldata/js/LIFT.js"></script>
    <link rel="stylesheet" href="htmldata/css/style.css" type="text/css" media="print, projection, screen" >
    </HEAD>
<!-- End HTML Header -->
<!-- Start HTML Body -->

<BODY DIR="LTR" BGCOLOR="#FFFFFF"  onload="javascript:on_load();">
<div id="header">
<ul id="navlist">
    <li>Filter:</li>
    <li id="filter_show"><a href="javascript:filter_show()">show</a></li>
    <li id="filter_hide"><a href="javascript:filter_hide(0)">hide</a></li>
    <li>&nbsp;&nbsp;</li>
    <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li>Jump to</li>
    <li><A href="#TOP">TOP</a></li>
    <li><A HREF="#TC_set_parameters">TC_set_parameters</A></li>
    <li><A HREF="#TC_initialization">TC_initialization ($html_init)</A></li>
    <li><A HREF="#TC_stimulation_and_measurement">TC_stimulation_and_measurement ($html_stimu)</A></li>
    <li><A HREF="#TC_evaluation">TC_evaluation ($html_eval)</A></li>
    <li><A HREF="#TC_finalization">TC_finalization ($html_final)</A></li>
    <li><A HREF="$summary_file">SUMMARY</A></li>
</ul>

    <div id= "filter_options" hidden = "true">
    <TABLE name = "values_filter_type" >
        
EOHTML

    #STEP ELEMENT_SELECTION
    my $filter_type_data_str = '';
    my %filter_type          = (
        'TABLE'    => { 'display' => 1 },
        'GRAPHICS' => { 'display' => 1 },
        'TEXT'     => { 'display' => 1 },
        'TIME'     => { 'display' => 1 },
    );

    my $local_report_href = S_get_contents_of_hash( ['REPORTING'] );
    my $local_element_section_href = $local_report_href->{'ELEMENT_SELECTION'};

    #If ELEMENT_SELECTION is given in project defaults
    if ( defined $local_element_section_href ) {
        my @elements = keys %{$local_element_section_href};

        foreach my $ele ( keys %{$local_element_section_href} ) {
            unless ( grep { /$ele/ } keys %filter_type ) {
                S_set_error( "Elements in 'ProjectDefaults->{'REPORTING'}{'ELEMENT_SELECTION'}' should be TABLE, GRAPHICS, TEXT and TIME", 114 );

                #                S_set_verdict ( VERDICT_FAIL );
                return 0;
            }
        }

        foreach my $ele ( keys %$local_element_section_href ) {
            $filter_type{$ele}{'display'} = $local_element_section_href->{$ele}{'display'};
        }
    }

    foreach my $type_data ( keys %filter_type ) {
        $filter_type_data_str .= '<TR> <TD> <div class="filter_type_data">' . $type_data . ' </div></TD> <TD><div class="filter_type_data">' . $filter_type{$type_data}{'display'} . '</div></TD> </TR>';
    }

    $tc_start_text_in_html_log .= $filter_type_data_str . <<EOHTML;

    </TABLE>
    <TABLE name = "values_filter_priority">

EOHTML

    #STEP LOGLEVEL_SELECTION

    my $filter_loglevel_data_str = '';

    #
    # required order of Filter selection must be
    #    teststep
    #    w2rep
    #    1 2 3 4 5
    #    warningmessage
    #
    my @level_sort_given = sort keys %$report_log_level;
    my @level_sort       = ();
    push( @level_sort, 'teststep' ) if grep { /teststep/ } @level_sort_given;
    push( @level_sort, 'w2rep' )    if grep { /w2rep/ } @level_sort_given;

    foreach my $num_level (@level_sort_given) {
        next unless $num_level =~ /^\d+$/;
        push( @level_sort, $num_level );
    }

    push( @level_sort, 'warningmessage' ) if grep { /warningmessage/ } @level_sort_given;

    #If LOGLEVEL_SELECTION is given in project defaults
    if ( defined $ProjectDefaults->{'REPORTING'}{'LOGLEVEL_SELECTION'} ) {
        foreach my $level (@level_sort) {
            if ( defined $ProjectDefaults->{'REPORTING'}{'LOGLEVEL_SELECTION'}{$level}{'display'} ) {
                $filter_loglevel_data_str .= '<TR><TD> <div class="filter_priority_data">' . $level . ' </div></TD>   <TD><div class="filter_priority_data">' . $ProjectDefaults->{'REPORTING'}{'LOGLEVEL_SELECTION'}{$level}{'display'} . ' </div></TD>    </TR>';
            }
            else {
                $filter_loglevel_data_str .= '<TR><TD> <div class="filter_priority_data">' . $level . ' </div></TD>   <TD><div class="filter_priority_data"> 1 </div></TD>    </TR>';
            }

        }
    }

    #If LOGLEVEL_SELECTION is not given in project defaults then level upto loglevel3, w2rep and teststep and warningmessage information will display
    else {
        my @default_log = qw/1 2 3 w2rep teststep warningmessage/;
        foreach my $level (@level_sort) {
            if ( grep { /$level/ } @default_log ) {
                $filter_loglevel_data_str .= '<TR><TD> <div class="filter_priority_data">' . $level . ' </div></TD>   <TD><div class="filter_priority_data"> 1 </div></TD>    </TR>';
            }
            else {
                $filter_loglevel_data_str .= '<TR><TD> <div class="filter_priority_data">' . $level . ' </div></TD>   <TD><div class="filter_priority_data"> 0 </div></TD>    </TR>';
            }
        }
    }

    $tc_start_text_in_html_log .= $filter_loglevel_data_str . <<EOHTML;
    </TABLE>
    <TABLE name = "values_filter_library">
EOHTML

    #STEP LIB_SELECTION

    my $filter_library_data_str = '';

    my @uniq_report_level_library = @report_level_library;

    #If LIB_SELECTION is given in project defaults
    if ( defined $ProjectDefaults->{'REPORTING'}{'LIB_SELECTION'} ) {
        foreach my $lib (@uniq_report_level_library) {
            if ( defined $ProjectDefaults->{'REPORTING'}{'LIB_SELECTION'}{$lib}{'hide_from_filter'} ) {
                if ( $ProjectDefaults->{'REPORTING'}{'LIB_SELECTION'}{$lib}{'hide_from_filter'} != 1 ) {
                    $filter_library_data_str .= '<TR><TD> <div class="filter_library_data">' . $lib . ' </div></TD>   <TD><div class="filter_library_data">' . $ProjectDefaults->{'REPORTING'}{'LIB_SELECTION'}{$lib}{'display'} . '</div></TD>    </TR>';
                }
            }
            else {
                $filter_library_data_str .= '<TR><TD> <div class="filter_library_data">' . $lib . ' </div></TD>   <TD><div class="filter_library_data">' . $ProjectDefaults->{'REPORTING'}{'LIB_SELECTION'}{$lib}{'display'} . '</div></TD>    </TR>';
            }
        }
    }
    else {
        foreach my $lib (@uniq_report_level_library) {
            $filter_library_data_str .= '<TR><TD> <div class="filter_library_data">' . $lib . ' </div></TD>   <TD><div class="filter_library_data"> 1 </div></TD>    </TR>';
        }
    }

    $tc_start_text_in_html_log .= $filter_library_data_str . <<EOHTML;
    </TABLE>
    </div>

    <div id="filter" style = "background-color:#E2E8EE;" hidden = "true">

        <form onsubmit="return false" method="post" name="Formular">
            <TABLE class = "headertable";>
                <colgroup>
                    <col width="15%" />
                    <col width="15%" />
                    <col width="15%" />
                    <col width="25%" />
                </colgroup>

                <TR>
                    <TD>Type</TD>
                    <TD>LogLevel</TD>
                    <TD>Library</TD>
                    <TD>Hold down ctrl to select multiple options</TD>
                </TR>

                <TR>
                    <TD><select multiple="multiple" id="filter_type" size="5" name="filter_type"  class="inputfield" ></select></TD>
                    <TD><select multiple="multiple" id="filter_priority" size="5" name="filter_priority"  class="inputfield" ></select></TD>
                    <TD><select multiple="multiple" id="filter_library" size="5" name="filter_library"  class="inputfield" ></select></TD>
                    <TD><input style="clear:both;" type="button" value="Set Filter" onclick="set_filter()" class="myButton"></TD>
                    <TD><input style="clear:both;" type="button" value="Show ALL" onclick="show_ALL()" class="myButton"></TD>
                </TR>

            </TABLE>
        </form>
    </div>

</div>
EOHTML

    $tc_results_href->{tc_start_text_in_html_log} = $tc_start_text_in_html_log;

    return 1;
}

sub Write_html_no_filter {
    my $tc_results_href = shift;

    my $tc_start_text_in_html_log = $tc_results_href->{tc_start_text_in_html_log};
    my $summary_file              = $tc_results_href->{summary_file};
    my $html_init                 = $tc_results_href->{html_init};
    my $html_stimu                = $tc_results_href->{html_stimu};
    my $html_eval                 = $tc_results_href->{html_eval};
    my $html_final                = $tc_results_href->{html_final};

    #    my $html_init = $ALL_TC->{$tc_cnt}{'TC_INIT'};
    #    $html_init =~ s/-//g;
    #    my $html_stimu = $ALL_TC->{$tc_cnt}{'TC_STIMU'};
    #    $html_stimu =~ s/-//g;
    #    my $html_eval = $ALL_TC->{$tc_cnt}{'TC_EVAL'};
    #    $html_eval =~ s/-//g;
    #    my $html_final = $ALL_TC->{$tc_cnt}{'TC_FINAL'};
    #    $html_final =~ s/-//g;

    $tc_start_text_in_html_log .= <<EOHTML;
    <script type="text/javascript" src="htmldata/js/LIFT_old.js"></script>
    <link rel="stylesheet" href="htmldata/css/style.css" type="text/css" media="print, projection, screen" >
    </HEAD>
    <!-- End HTML Header -->
    <!-- Start HTML Body -->
    
        <BODY DIR="LTR" BGCOLOR="#FFFFFF"  onload="showLevel(5);"> 
    <div id="header">
    <ul id="navlist">
   <li>Loglevel:</li>
    <li id="hideall"><a href="javascript:hideall()">hide all</a></li>
    <li><a href="javascript:showLevel(0)" id="lev0"> 0</a></li>
    <li><a href="javascript:showLevel(1)" id="lev1"> 1</a></li>
    <li><a href="javascript:showLevel(2)" id="lev2"> 2</a></li>
    <li><a href="javascript:showLevel(3)" id="lev3"> 3</a></li>
    <li><a href="javascript:showLevel(4)" id="lev4"> 4</a></li>
    <li><a href="javascript:showLevel(5)" id="lev5"> 5</a></li>
    <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li>Jump to</li>
    <li><A href="#TOP">TOP</a></li>
    <li><A HREF="#TC_set_parameters">TC_set_parameters</A></li>
    <li><A HREF="#TC_initialization">TC_initialization ($html_init)</A></li>
    <li><A HREF="#TC_stimulation_and_measurement">TC_stimulation_and_measurement ($html_stimu)</A></li>
    <li><A HREF="#TC_evaluation">TC_evaluation ($html_eval)</A></li>
    <li><A HREF="#TC_finalization">TC_finalization ($html_final)</A></li>
    <li><A HREF="$summary_file">SUMMARY</A></li>
    </ul>
EOHTML

    return 1;
}

sub Write_to_testcase_report {
    my $tc_results_href = shift;

    my $tc_cnt                    = $tc_results_href->{tc_cnt};
    my $tc_id                     = $tc_results_href->{tc_id};
    my $tc_par_purpose            = $tc_results_href->{tc_par_purpose};
    my $prj_par_purpose           = $tc_results_href->{prj_par_purpose};
    my $tc_start_text_in_html_log = $tc_results_href->{tc_start_text_in_html_log};
    my $tc_purpose                = $tc_results_href->{tc_purpose};
    my $duration                  = $tc_results_href->{duration};
    my $start_date                = $tc_results_href->{start_date};
    my $start_time                = $tc_results_href->{start_time};
    my $tc_verdict                = $tc_results_href->{tc_verdict};
    my $SRT_fullname_txt          = $tc_results_href->{SRT_fullname_txt};
    my $SRT_ID_txt                = $tc_results_href->{SRT_ID_txt};
    my $tc_version                = $tc_results_href->{tc_version};
    my $html_verdict              = $tc_results_href->{html_verdict};
    my $verdict_color             = $tc_results_href->{verdict_color};

    my ( $tc_module_file, $tc_par_file, $tc_docufile, $tcparfile_version );

    if ( $ALL_TC->{$tc_cnt}{'TC_MODULE_FILE'} ) {
        $tc_module_file = "./$RERUN_name/" . basename( $ALL_TC->{$tc_cnt}{'TC_MODULE_FILE'} );    # relative path
    }
    else { $tc_module_file = $not_given }

    if ( $ALL_TC->{$tc_cnt}{'TC_PAR_FILE'} ) {
        $tc_par_file = "./$RERUN_name/" . basename( $ALL_TC->{$tc_cnt}{'TC_PAR_FILE'} );          # relative path
    }
    else { $tc_par_file = $not_given; }

    if ( $ALL_TC->{$tc_cnt}->{'TC_PAR_FILE_VERSION'} ) {
        $tcparfile_version = $ALL_TC->{$tc_cnt}->{'TC_PAR_FILE_VERSION'};
    }
    else { $tcparfile_version = "?"; }

    if ( $ALL_TC->{$tc_cnt}{'TC_MODULE_FILE'} ) {
        $tc_docufile = "./$RERUN_name/" . basename( $ALL_TC->{$tc_cnt}{'TC_MODULE_FILE'} );       # relative path
    }
    else { $tc_docufile = $not_given; }
    $tc_docufile =~ s/\.pm$/\.html/;

    ## prepare offline text, will be written in Headline of TC Report if TC runs in OFFLINE mode
    my $hint_text = '';
    if ($opt_offline) {
        $hint_text .= <<EOD;
    <H3 style="font-family:Arial; color:red">(running in OFFLINE mode, not on real HW)</H3>
EOD

    }
    if ( not $checksumResultsAll_href->{overallOK} ) {
        $hint_text .= <<EOD;
    <!-- Remark that Test run with modified engine -->
    <H3 style="font-family:Arial; color:red">$modifiedEngineAdvice</H3>
EOD
    }

    my $docu_html_code;
    if ( defined $tc_docufile ) {
        $docu_html_code = <<EODOC;
        <A HREF="$tc_docufile">$tc_docufile</A>
EODOC

    }

    my $tc_par_purpose_html_code;
    if ( defined $tc_par_purpose ) {
        $tc_par_purpose_html_code = <<EOPURP;
        <TR><TH>Purpose (2):</TH>
            <TD>$tc_par_purpose</TD></TR>
EOPURP

    }
    my $prj_par_purpose_html_code;
    if ( defined $prj_par_purpose ) {
        $prj_par_purpose_html_code = <<EOPURP;
        <TR><TH>Purpose (3):</TH>
            <TD>$prj_par_purpose</TD></TR>
EOPURP

    }
    my $LC_html_code;
    if ( defined $Simulator ) {
        $LC_html_code = <<EOLC;
        <TR><TH>Simulator :</TH>
            <TD>$Simulator</TD></TR>
EOLC

    }
    my $ECU_SW_Version_html_code = "";
    if ($ECU_SW_VERSION) {
        $ECU_SW_Version_html_code = <<EOLVER;
        <TR><TH>ECU SW Version :</TH>
            <TD>$ECU_SW_VERSION</TD></TR>
EOLVER

    }
    if ($VARIANT_VERSION) {
        $ECU_SW_Version_html_code .= <<EOLVER;
        <TR><TH>Variant Version :</TH>
            <TD>$VARIANT_VERSION</TD></TR>
EOLVER

    }
    if ($VARIANT_ID) {
        $ECU_SW_Version_html_code .= <<EOLVER;
        <TR><TH>Variant ID :</TH>
            <TD>$VARIANT_ID</TD></TR>
EOLVER

    }
    if ($ECU_FINGERPRINT) {
        $ECU_SW_Version_html_code .= <<EOLVER;
        <TR><TH>ECU fingerprint :</TH>
            <TD>$ECU_FINGERPRINT</TD></TR>
EOLVER

    }
    my $HW_ID_html_code = "";
    if ($TTNO) {
        $HW_ID_html_code .= <<EOHWID;
        <TR><TH>TT Number :</TH>
            <TD>$TTNO</TD></TR>
EOHWID

    }

    if ($HW_ver) {
        $HW_ID_html_code .= <<EOHWID;
        <TR><TH>HW Version :</TH>
            <TD>$HW_ver</TD></TR>
EOHWID

    }

    if ($HW_serNo) {
        $HW_ID_html_code .= <<EOHWID;
        <TR><TH>HW Serial Number :</TH>
            <TD>$HW_serNo</TD></TR>
EOHWID

    }

    my $bookmarkText = '<p>Quick Links:  ';
    foreach my $bookmark (@htmlBookmarks) {
        $bookmarkText .= "<a href=\"#$bookmark\">$bookmark</a> &nbsp; &nbsp;";
    }
    $bookmarkText .= '</p>';

    $tc_start_text_in_html_log .= <<EOHTML;
<div id="content">
<A NAME="TOP"></A>
<TABLE>
  <TR>
    <TD>$TCleft_logo_html</TD>
    <TD WIDTH="100%">
      <div style="font-family:Arial; color:grey; font-size:x-large; font-weight:bold; text-align:center">LIFT Testcase Report</div>
      <div style="font-family:Arial; font-weight:bold; text-align:center">$LIFT_ProjectDescription_html_code</div>
    </TD>
    <TD>$TCright_logo_html</TD>
  </TR>
</TABLE>

$hint_text
    <HR>
    <TABLE style="font-family:Courier"  class="tablesorter">
        <TR><TH>Testcase ID</TH>
            <TD>$tc_id</TD></TR>
        <TR style="font-weight:bold"><TH>VERDICT</TH>
            <TD><B><A HREF="#$tc_verdict"><span style="color:$verdict_color">$html_verdict</span></A></B></TD></TR>
        <TR><TH>Module File:</TH>
            <TD><A HREF="$tc_module_file" TYPE="text/pm">$tc_module_file</A> ($tc_version)</TD></TR>
        <TR><TH>Parameter File:</TH>
            <TD><A HREF="$tc_par_file" TYPE="text/par">$tc_par_file</A> ($tcparfile_version)</TD></TR>
        <TR><TH>SRT_fullname:</TH>
            <TD>$SRT_fullname_txt</TD></TR>
        <TR><TH>SRT_ID:</TH>
            <TD>$SRT_ID_txt</TD></TR>
        <TR><TH>Start Date/Time:</TH>
            <TD>$start_date $start_time</TD></TR>
        <TR><TH>Duration:</TH>
            <TD>$duration sec</TD></TR>
        <TR><TH>Purpose:</TH>
            <TD>$tc_purpose</TD></TR>
        $tc_par_purpose_html_code
        $prj_par_purpose_html_code
        <TR><TH>Documentation:</TH>
            <TD>$docu_html_code</TD></TR>
        $ECU_SW_Version_html_code
        $HW_ID_html_code
    </TABLE>
$bookmarkText

EOHTML

    ## put the header on the top of collected tc log text
    unshift( @TC_HTML_TEXT, $tc_start_text_in_html_log );

    ### footer of TC HTML log file---------------------------------------------
    my $tc_end_text_in_html_log = <<EOHTML;
</div>
</BODY>
</HTML>
EOHTML

    ## put footer at the end of collected tc log text
    push( @TC_HTML_TEXT, "<div class=\"5\">Writing $tc_html_file</div>" );
    push( @TC_HTML_TEXT, $tc_end_text_in_html_log );

    S_w2tc_html($tc_html_file);

    return 1;
}

###------------------------------------------------------------------
### Close_all_logs ( )
###------------------------------------------------------------------

=head

    Subroutine Name :: Close_all_logs
    Description     :: close all log files and write end text in them
    Syntax          :: Close_all_logs($lift_start_time, $lift_end_time);
    Input Arguments :: $lift_start_time, $lift_end_time
    Description     :: $lift_start_time - LIFT engine start time, $lift_end_time - LIFT engine end time
    Return Value(s) :: None
    Description     :: None

=cut

sub Close_all_logs {
    my ( $lift_start_time, $lift_end_time ) = (@_);
    my ( $total_tc_passed, $total_tc_failed, $total_tc_inconc, $total_tc_blocked, $total_tc_none, $total_nr );

    $total_tc_passed  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_PASS};
    $total_tc_failed  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_FAIL};
    $total_tc_inconc  = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_INCONC};
    $total_tc_none    = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_NONE};
    $total_tc_blocked = $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{VERDICT_BLOCKED};
    $total_nr         = $total_tc_passed + $total_tc_failed + $total_tc_inconc + $total_tc_none + $total_tc_blocked;

    my ( $end_date, $end_time ) = S_formated_timestamp($lift_end_time);
    my $duration = $lift_end_time - $lift_start_time;
    my ( $sec, $min, $hour ) = gmtime($duration);
    my $days          = int( $duration / 86400 );
    my $duration_text = "$days d $hour h $min min $sec sec ($duration sec) ";

    #### - section only for Junit-XML
    my $junit_nbr_tests = $total_nr;
    $junit_nbr_tests++ if defined $TC_INIT_CAMPAIGN;
    $junit_nbr_tests++ if defined $TC_END_CAMPAIGN;
    my $junit_tc_failed = $total_tc_failed;
    $junit_tc_failed++ if $all_TC_IC{TC_VERDICT} eq VERDICT_FAIL;
    $junit_tc_failed++ if $all_TC_EC{TC_VERDICT} eq VERDICT_FAIL;
    my $junit_tc_inconc = $total_tc_inconc;
    $junit_tc_inconc++ if $all_TC_IC{TC_VERDICT} eq VERDICT_INCONC;
    $junit_tc_inconc++ if $all_TC_EC{TC_VERDICT} eq VERDICT_INCONC;

    unless ( defined $JUNIT_XmlRoot_href ) {
        S_set_error("Internal strcut doesnt exists - sub : Create_jUnit_xml_root must be called before");
        return;
    }
    my $testsuite_obj = $JUNIT_XmlRoot_href->{'testsuite_obj'};

    $testsuite_obj->setAttribute( "tests",    $junit_nbr_tests );
    $testsuite_obj->setAttribute( "errors",   $junit_tc_inconc );
    $testsuite_obj->setAttribute( "failures", $junit_tc_failed );
    $testsuite_obj->setAttribute( "time",     $duration );          # time only contain Testcases of Testlist - not including IC + EC
                                                                    #STEP write junit xml
    Write_jUnit_XML_file();
    #### - - - - - - - - - - - - - -

    ### write to result file of LIFTtat procedure

    S_w2res("CPG_VD"
          . $csv_result_delim
          . "$save_name"
          . $csv_result_delim
          . "$total_nr"
          . $csv_result_delim
          . "$total_tc_passed"
          . $csv_result_delim
          . "$total_tc_failed"
          . $csv_result_delim
          . "$total_tc_inconc"
          . $csv_result_delim
          . "$total_tc_none"
          . $csv_result_delim
          . "$end_date"
          . $csv_result_delim
          . "$end_time,$duration" );

    my $end_text = <<EOLMH;
    <!-- end main table of testcase execution -->
    </TABLE>
    
    <TABLE style="font-family:Courier" CELLSPACING=0 BORDER=0 CELLPADDING=4 WIDTH=628>
        <!-- LIFT end Date/Time: -->
        <TR><TD WIDTH="34%">End Date/Time:</TD>
            <TD WIDTH="66%">$end_date $end_time</TD></TR>
        <!-- LIFT total duration -->
        <TR><TD WIDTH="34%">LIFT total duration:</TD>
            <TD WIDTH="66%">$duration_text</TD></TR>
        <TR><TD WIDTH="34%">ECU SW Version:</TD>
            <TD WIDTH="66%">$ECU_SW_VERSION</TD></TR>
		<TR><TD WIDTH="34%">Variant ID:</TD>
            <TD WIDTH="66%">$VARIANT_ID</TD></TR>	
		<TR><TD WIDTH="34%">Variant Version:</TD>
            <TD WIDTH="66%">$VARIANT_VERSION</TD></TR>		
        <TR><TD WIDTH="34%">ECU fingerprint:</TD>
            <TD WIDTH="66%">$ECU_FINGERPRINT</TD></TR>
        <TR><TD WIDTH="34%">TT Number:</TD>
            <TD WIDTH="66%">$TTNO</TD></TR>
        <TR><TD WIDTH="34%">HW Version:</TD>
            <TD WIDTH="66%">$HW_ver</TD></TR>
        <TR><TD WIDTH="34%">HW Serial Number:</TD>
            <TD WIDTH="66%">$HW_serNo</TD></TR>
    </TABLE>


    <!-- horizontal line -->
    <HR>
    <a name="Summary" id="Summary"></a>
    <H2 style="font-family:Arial">Summary</H2>
     <TABLE style="font-family:Courier;font-size:100%"  class="tablesorter" WIDTH="70%" >
      <thead>
        <TR ALIGN="CENTER" style="font-weight:bold">
			<TH WIDTH="22%" style="font-weight:bold;font-size:100%"><B>Test Class</B></TH>
            <TH WIDTH="13%" HEIGHT="25px" style="background:red;color:white;font-size:100%"><B>FAIL</B></TH>
            <TH WIDTH="13%" HEIGHT="25px" style="background:purple;color:white;font-size:100%"><B>INCONC</B></TH>
            <TH WIDTH="13%" HEIGHT="25px" style="background:magenta;color:white;font-size:100%"><B>BLOCKED</B></TH>
            <TH WIDTH="13%" HEIGHT="25px" style="background:blue;color:white;font-size:100%"><B>NONE</B></TH>
            <TH WIDTH="13%" HEIGHT="25px" style="background:green;color:white;font-size:100%"><B>PASS</B></TH>
            <TH WIDTH="13" HEIGHT="25px" style="background:lightblue;color:black;font-size:100%"><B>TOTAL</B></TH>
        </TR>
      </thead>
      <tbody>
        <TR ALIGN="CENTER" style="font-weight:bold">
            <TH WIDTH="22%" style="font-weight:bold;font-size:100%">Executed Testcases</TH>
            <TD WIDTH="13%" HEIGHT="25px" style="color:red">$total_tc_failed</TD>
            <TD WIDTH="13%" HEIGHT="25px" style="color:purple">$total_tc_inconc</TD>
            <TD WIDTH="13%" HEIGHT="25px" style="color:magenta">$total_tc_blocked</TD>
            <TD WIDTH="13%" HEIGHT="25px" style="color:blue">$total_tc_none</TD>
            <TD WIDTH="13%" HEIGHT="25px" style="color:green">$total_tc_passed</TD>
            <TD WIDTH="13%" HEIGHT="25px" >$total_nr</TD>
        </TR>
      </tbody>
    </TABLE>
    <P><I>Remark: Order of Global Verdict is (descending): PASS->NONE->INCONC->FAIL->BLOCKED</I></P>
EOLMH

    $end_text .= "</div></BODY></HTML>";

    S_w2res_html($end_text);

    S_w2log( 5, "### LIFT stopped at $end_date $end_time \n" );      # after EC (will not be written to html)
    S_w2log( 5, "### whole test run elapsed $duration sec\n\n" );    # after EC (will not be written to html)
    print "\a\a" if $opt_beep;                                       # \a is the bell

    S_close_all();

    my $result_html = abs_path($save_name) . '/' . $main_LOG_name;
    $result_html =~ s/\//\\/g;                                       # replace all slashes with backslahes

    # print" backup $result_html\n";
    my $result = system( "copy $result_html $result_html" . 'copy /A /Y' );    # copy single file with DOS command xcopy
    unless ($result) {
        my $line;

        #copy successful, remove refresh and button
        open( COPY_HTML,   "<$result_html" . 'copy' ) or die "\n!!! couldn't open RESULT_HTML file '$result_html': $! \n";
        open( RESULT_HTML, ">$result_html" )          or die "\n!!! couldn't open RESULT_HTML file '$result_html': $! \n";
        while ( $line = <COPY_HTML> ) {
            if ( $line =~ /^\s*(<META HTTP-EQUIV="refresh"|<p ID="thoughtbot"|<iframe src=)/i ) {

                #     print "skipping ".$line;
            }
            else {
                print RESULT_HTML $line;
            }
        }
        close(COPY_HTML);
        close(RESULT_HTML);
        unlink( $result_html . 'copy' );
    }
    else { print " could not copy report: $result\n"; }

    return 1;
}

###------------------------------------------------------------------
### Get_date_extension
###------------------------------------------------------------------

=head

    Subroutine Name :: Get_date_extension
    Description     :: returns the date and time in YYMMDD and time in Hours: Minutes: Seconds
    Syntax          :: Get_date_extension($given_time);
    Input Arguments :: $given_time
    Description     :: $given_time - time
    Return Value(s) :: None
    Description     :: None
    
=cut

sub Get_date_extension {
    my $given_time = shift;
    my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($given_time);
    return sprintf( "%04d%02d%02d_%02d%02d%02d", $year + 1900, $mon + 1, $mday, $hour, $min, $sec );
}

###------------------------------------------------------------------
### Update_status_external
###------------------------------------------------------------------

=head

    Subroutine Name :: Update_status_external
    Description     :: writes the status of current execution into status.txt a file saved in location c:\temp\LIFT\
    Syntax          :: Update_status_external();
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: None
    Description     :: None
    
=cut

sub Update_status_external {
    my $file = 'c:\temp\LIFT\status.txt';
    if ( open( my $statusFh, ">", $file ) ) {
        foreach (@status_msg) {
            print $statusFh $_ . "\n";
        }
        close($statusFh);
    }
    else { S_w2log( 5, "ERROR: could not update status in $file\n" ); }

    if ( $LIFT_config::report_PC and $LIFT_config::report_PC ne $LIFT_config::LIFT_host ) {
        my $remote_pc   = $LIFT_config::report_PC;
        my $remote_path = "\\\\$remote_pc\\c\$\\temp\\LIFT\\";

        my $result = system("xcopy $file $remote_path > nul");    # copy single file with DOS command xcopy
    }

    return 1;
}

###------------------------------------------------------------------
### Update_status
###------------------------------------------------------------------

=head

    Subroutine Name :: Update_status
    Description     :: this function checks whether registry is updated to stop the execution of the engine.
    Syntax          :: Update_status();
    Input Arguments :: None
    Description     :: None
    Return Value(s) :: None
    Description     :: None
    
=cut

sub Update_status {
    if ( $Registry->{"HKEY_CURRENT_USER\\Software\\Bosch\\LIFT\\\\STOPafterTC"} ) {
        S_w2rep("@@@@@@@@@@@ TEST EXECUTION STOPPED BY USER @@@@@@@@@@@\n");
        $USER_STOP = 1;
    }
    return 1;
}

=head

    Subroutine Name :: Copy2rerun
    Description     :: This functions creates a snap shot of the current files in the work folder which could be used later to reproduce the same environment. 
    Syntax          :: Copy2rerun($temp);
    Input Arguments :: $temp
    Description     :: path of the TC module , parameter files etc 
    Return Value(s) :: None
    Description     :: None
    
=cut

sub Copy2rerun {
    my $temp = shift;
    unless ( -f ( "$RERUN_PATH/" . basename($temp) ) ) {
        my $file = abs_path( dirname($temp) ) . '/' . basename($temp);
        $file =~ s/\//\\/g;    # replace all slashes with backslahes
        S_w2log( 5, " copy $file to $RERUN_PATH\n" );    # before IC (will not be written to html)
        my $result = system("xcopy $file $RERUN_PATH\  /H /Q /C > nul");    # copy single file with DOS command xcopy
        if ($result) {
            my $text = "WARNING: could not copy $file to $RERUN_PATH : $!";
            S_w2res_html("<span style=\"color:red;font-weight:bold\">$text</span>\n");
        }
    }
    return 1;
}

###------------------------------------------------------------------
### USAGE, HELP if invalid program call
###------------------------------------------------------------------

sub Usage {
    my $help = <<"EOF";
------------------------------------------------------------------------------
PROGRAM: $0
 call program with options:

 EXAMPLE:
 perl $0

------------------------------------------------------------------------------
EOF

    print $help;
    exit(0);
}

=head

    Subroutine Name :: WriteExecutionLoggingData
    Description     :: This functions writes data like hostname, date, time, test duration, etc. to logging files in csv format. 
    Syntax          :: WriteExecutionLoggingData( $lift_start_time, $lift_end_time );
    Input Arguments :: $lift_start_time, $lift_end_time
    Description     :: $lift_start_time - LIFT engine start time, $lift_end_time - LIFT engine end time
    Return Value(s) :: 1
    Description     :: None
    
=cut

sub WriteExecutionLoggingData {
    my $startTime_s = shift;
    my $endTime_s   = shift;

    return 1 if $opt_offline or $opt_simulation;

    #STEP collect data to be logged in a list
    #COMMENT-START
    # data are:
    # host name, date, start time, end time, duration,SW version name, Variant ID, Variant Version, test list name, project name, TSG4 base rack S/N, engine version number, engine OK
    #COMMENT-END
    my $duration_s = $endTime_s - $startTime_s;
    my ( $startDate, $startTimeFormated ) = S_formated_timestamp($startTime_s);
    my ( $endDate,   $endTimeFormated )   = S_formated_timestamp($endTime_s);
    my $dateISO = join( '-', reverse split( /\./, $startDate ) );       # converts from e.g. 21.02.2017 to 2017-02-21 (ISO 8601 format)
    my $tsg4BaseRackSN = $LIFT_TSG4::detectedDevices->{'RC'}{1}{HW};    #  get TSG4 base rack serial number
    $LIFT_TSG4::detectedDevices if 0;                                   # to get rid of the warning "used only once: possible typo"
    $tsg4BaseRackSN = 'no TSG4' if not defined $tsg4BaseRackSN;
    my $engineVersion = $checksumResultsAll_href->{Components}{TurboLIFT_Engine}{Version} // 'unknown';
    my $engineOK = $checksumResultsAll_href->{overallOK} // 'unknown';

    my @executionLoggingData;
    push( @executionLoggingData, hostname() );
    push( @executionLoggingData, $dateISO );
    push( @executionLoggingData, $startTimeFormated );
    push( @executionLoggingData, $endTimeFormated );
    push( @executionLoggingData, $duration_s );
    push( @executionLoggingData, $ECU_SW_VERSION );
    push( @executionLoggingData, $VARIANT_ID );
    push( @executionLoggingData, $VARIANT_VERSION );
    push( @executionLoggingData, basename($TestList) );
    push( @executionLoggingData, $LIFT_config::LIFT_ProjectDescription );
    push( @executionLoggingData, $tsg4BaseRackSN );
    push( @executionLoggingData, $engineVersion );
    push( @executionLoggingData, $engineOK );

    my $loggingFilePath;

    #CALL AppendLoggingDataToFile with local file
    $loggingFilePath = 'C:\TurboLIFT\Execution_logging\TurboLIFT_execution_logging_DO_NOT_TOUCH.txt';
    my $success = AppendLoggingDataToFile( $loggingFilePath, \@executionLoggingData );

    #CALL AppendLoggingDataToFile with year and month as part of the remote file name
    my $date_yyyy_mm = join( "_", @{ [ split( /-/, $dateISO ) ] }[ 0 .. 1 ] );    # extract only year and month (yyyy-mm) from (yyyy-mm-dd)

    $loggingFilePath = '\\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\execution_logging\TurboLIFT_execution_logging_' . $date_yyyy_mm . '_DO_NOT_TOUCH.txt';
    $success = AppendLoggingDataToFile( $loggingFilePath, \@executionLoggingData );

    #CALL AppendLoggingDataToFile to store missed network drive logging
    my $missedLoggingFilePath = 'C:\TurboLIFT\Execution_logging\Missed_TurboLIFT_execution_logging_DO_NOT_TOUCH.txt';
    unless ($success) {
        my $missed_log_status = AppendLoggingDataToFile( $missedLoggingFilePath, \@executionLoggingData );
    }

    #CALL FetchAndDumpDataFromMissedLogs if the missed logs are present and Network drive is accessible.
    if ( -e $missedLoggingFilePath and $loggingFilePath =~ /^\\\\/ and $success ) {

        #CALL FetchAndDumpDataFromMissedLogs
        FetchAndDumpDataFromMissedLogs($missedLoggingFilePath);
    }
    return 1;
}

=head

    Subroutine Name :: AppendLoggingDataToFile
    Description     :: This functions writes the given list of data as one line, separated by , into the given file. 
    Syntax          :: AppendLoggingDataToFile( $loggingFilePath, $executionLoggingData_aref );
    Input Arguments :: $loggingFilePath, $executionLoggingData_aref
    Description     :: $loggingFilePath - path to a logging file, $executionLoggingData_aref - list of data elements to be written
    Return Value(s) :: 1 on success, undef otherwise
    Description     :: None
    
=cut

sub AppendLoggingDataToFile {

    #COMMENT-START
    # AppendLoggingDataToFile( $loggingFilePath, $executionLoggingData_aref)
    #COMMENT-END
    my $loggingFilePath           = shift;
    my $executionLoggingData_aref = shift;

    #STEP check if folder for $loggingFilePath exists and if not create it
    my $dirname = dirname($loggingFilePath);
    unless ( -d $dirname ) {
        unless ( mkdir($dirname) ) {
            my $parentDir = dirname($dirname);
            S_set_warning("Can't create directory $dirname for execution logging: $! . At least the directory $parentDir should exist.");
            return;
        }
    }

    #STEP open $loggingFilePath, if does not exists create and append
    my $fh;
    unless ( open $fh, '+>>', $loggingFilePath ) {
        S_set_warning("Can't open $loggingFilePath for execution logging: $!");
        return;
    }

    #STEP lock the file
    unless ( flock( $fh, 2 ) ) {
        S_set_warning("Can't lock $loggingFilePath for execution logging: $!");
        return;
    }

    #STEP write data in $executionLoggingData_aref separated by , to the file
    my $loggingString = join( ',', @$executionLoggingData_aref );
    print $fh "$loggingString\n";

    #STEP close the file
    unless ( close($fh) ) {
        S_set_warning("Can't close $loggingFilePath for execution logging: $!");
        return;
    }

    return 1;
}

=head2 FetchAndDumpDataFromMissedLogs

    1 or undef = FetchAndDumpDataFromMissedLogs($missedLoggingFilePath);
    
When there is network/access issues to network drive log files the execution logs will be missed.

Those logs will be written to "Missed_TurboLIFT_execution_logging_DO_NOT_TOUCH.txt" file in local PC.

This function writes those logs when the network/access is resolved.

Copying of log information will be done to respective network file paths which are created monthly.

This function is called by function L</"AppendLoggingDataToFile">.

This function gets called only:

    1. When the network drive is accessible and 
    2. There is content in missed execution log file "Missed_TurboLIFT_execution_logging_DO_NOT_TOUCH.txt".
    
Log file which contains missed execution logs will be deleted after the content is copied to network file.

B<Arguments:>

=over

=item $missedLoggingFilePath

Log file path of "Missed_TurboLIFT_execution_logging_DO_NOT_TOUCH.txt"

=back

B<Return Values:>

1 on success

undef on failure 

=cut

sub FetchAndDumpDataFromMissedLogs {

    my @args = @_;
    S_checkFunctionArguments( 'FetchAndDumpDataFromMissedLogs($missedLoggingFilePath)', @args ) or return;

    my $missedLoggingFilePath = shift @args;

    my @tempData   = ();
    my $error_flag = 0;

    my $fh;

    #STEP read content of Missed_TurboLIFT_execution_logging_DO_NOT_TOUCH.txt
    unless ( open $fh, '<', $missedLoggingFilePath ) {
        S_set_warning("Can't open $missedLoggingFilePath for reading: $!");
        return;
    }
    @tempData = <$fh>;

    #STEP close the file
    unless ( close($fh) ) {
        S_set_warning("Can't close $missedLoggingFilePath: $!");
        return;
    }

    my $logs_to_files_href = {};
    my $filename;

    #LOOP-START collect content of execution log based on month and year
    foreach my $exec_log (@tempData) {
        my ( $pc_name, $year_month ) = $exec_log =~ /^(.*?),(\d{4}\-\d{2})/;    #extract year and month from the log.
        $year_month =~ s/-/_/g;
        $filename = 'TurboLIFT_execution_logging_' . $year_month . '_DO_NOT_TOUCH.txt';
        push( @{ $logs_to_files_href->{$filename} }, $exec_log );               # creates href with filename as key and aref with logs as value
    }

    #LOOP-END last log data

    #LOOP-START append execution log to respective execution log files
    foreach my $filename ( keys %$logs_to_files_href ) {
        my $network_path      = '\\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\execution_logging\\';
        my $absolute_filename = $network_path . $filename;

        #STEP open file for appending data
        unless ( open $fh, '+>>', $absolute_filename ) {
            S_set_warning("Can't open $absolute_filename for appending: $!");
            return;
        }

        #STEP lock file
        unless ( flock( $fh, 2 ) ) {
            S_set_warning("Can't lock $absolute_filename for execution logging: $!");
            return;
        }

        #STEP Copy data to network file
        print $fh "@{ $logs_to_files_href->{$filename} }";

        #STEP close the file
        unless ( close($fh) ) {
            S_set_warning("Can't close $absolute_filename: $!");
            return;
        }
    }

    #LOOP-END last file

    #STEP Delete the temp file.
    unlink $missedLoggingFilePath;
    return 1;
}

sub CreateSnapshot {

    # collect the list of files to be copied to rerun path
    my %conf_files = ();

    # find the file name to have as a key in %conf_files hash
    $opt_testlist =~ /([^\\\/]+)$/i;
    $conf_files{$1} = $opt_testlist;

    # determine the files to be copied from ./config folder by using the %INC perl environment hash
    foreach my $configfile ( ( keys %INC ) ) {

        # if any of the files are included from ./config, then copy that to rerun folder
        if ( $INC{$configfile} =~ /[\/\\]config[\/\\](.*?\.pm)$/ig ) {
            $conf_files{$1} = $configfile;
        }
        if ( $INC{$configfile} =~ /[\/\\]COMMON_config[\/\\](.*?\.pm)$/ig ) {
            $conf_files{$1} = $configfile;
        }
    }

    # copy all the configuration files determined, to the rerun path for reproducibility
    foreach my $tempfile ( keys %conf_files ) {
        Copy2rerun( $conf_files{$tempfile} );
    }

    # create the full config folder snapshot only if -minimalsnapshot commandline option is not given/defined for Engine execution
    unless ( defined $opt_minimalsnapshot ) {

        # get path to config folder
        my $path = dirname($opt_conf);
        $path =~ s/\//\\/g;    # replace all slashes with backslahes
        S_w2log( 1, "Zipping $path to $RERUN_PATH\\config.zip ...\n\n!!! If this takes too long then you have probably too much data in $path. In this case check if you can delete something there !!!\n\n" );    # before IC (will not be written to html)

        # write entire directory $path into a zip file for rerun
        my $result;
        my $config_zip_handle = S_open_zip("$RERUN_PATH/config.zip");
        $result = S_add_to_zip( $config_zip_handle, $path ) if $config_zip_handle;
        $result = S_close_zip($config_zip_handle) if $result;

        # check if zip was successful
        unless ($result) {
            my $text = "WARNING: could not zip entire path $path to $RERUN_PATH\\config.zip: $!<br>Please check manually by comparing folders (or) look into _log.txt file to know which files could not be copied  ! Test will be started nevertheless but might not be reproducible !";
            S_w2res_html("<span style=\"color:red;font-weight:bold\">$text</span>\n");
        }
        else {
            S_w2log( 5, " Copied $path\n" );    # before IC (will not be written to html)
        }
    }

    #create html docu in rerun
    use Pod::Html;
    opendir( DIR, $RERUN_PATH ) || die "can't opendir $RERUN_PATH: $!";
    my @modules = grep { /\.pm$/ } readdir(DIR);
    closedir DIR;
    my ( $targetFile, $cssfile );

    # determine the css file based on perl installation folder
    $cssfile = dirname( dirname($^X) ) . '\html\Active.css';
    my @allConfigFiles = keys %conf_files;

    foreach my $sourceFile (@modules) {

        # if $sourceFile is not a configuration file (i.e., $sourceFile is a testcase), run the POD documentation compiler on the file
        unless ( grep { /$sourceFile/i } @allConfigFiles ) {
            $sourceFile = "$RERUN_PATH\\" . $sourceFile;
            S_w2log( 5, " POD $sourceFile\n" );    # before IC (will not be written to html)
            $targetFile = $sourceFile;
            $targetFile =~ s/\.pm/\.html/;

            pod2html( $sourceFile, "--outfile=$targetFile", "--css=file:///$cssfile", "--quiet", );
        }
    }

    # write runtime errors/warnings to report summary
    foreach my $warning (@runtime_WARNINGS) {
        S_w2res_html("<div class=\"warningmessage\">$warning</div>\n");
    }
    foreach my $error (@runtime_ERRORS) {
        S_w2res_html("<div class=\"errormessage\">$error</div>\n");
    }

    return 1;
}

sub ProcessInitCampaign {
    my $max_nr    = shift;
    my $last_flag = 0;

    if ( exists $ALL_TC->{'IC'} ) {

        #STEP prepare varables for execution
        @TC_HTML_TEXT = ();

        my $TC_start_time = time();
        my ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);
        my $tc_id = $ALL_TC->{'IC'}{'TC_ID'};
        S_reset_TC_time();
        S_w2log( 5, "   >>>>  $tc_id  <<<<\n" );
        S_w2rep("  started at $start_date $start_time \n");

        # create TC html file name and update global var $TC_REPORT_NAME
        $file_prefix_number = '___';

        #### IMPORTANT! TC ID used for filenames have been replaced the '.' with '-'
        $tc_id_for_file_name = $tc_id;
        $tc_id_for_file_name =~ s/\./-/g;
        $TC_REPORT_NAME = $OFFLINE . $file_prefix_number . "_" . $tc_id_for_file_name . ".html";

        $tc_html_file = $save_name . "/" . $TC_REPORT_NAME;

        #CALL execute_init_campaign
        my $init_cpg_result = execute_init_campaign();

        ## if SW version has been read in INIT campaign
        if ( $ENV{'ECU_SW_VERSION'} ) {

            #STEP store ECU SW Version for use in all LIFT TC reports
            $ECU_SW_VERSION = $ENV{'ECU_SW_VERSION'};

            ## write the ECU SW Version into result file for archiving in Test Project Management
            S_w2res( "ECU_SW_VERSION" . $csv_result_delim . "$ECU_SW_VERSION" . $csv_result_delim );
        }
        else { $ECU_SW_VERSION = $not_given; }

        ## if Variant ID has been read in INIT campaign
        if ( $ENV{'VARIANT_ID'} ) {

            #STEP store Variant ID for use in all LIFT TC reports
            $VARIANT_ID = $ENV{'VARIANT_ID'};

            ## write the Variant ID into result file for archiving in Test Project Management
            S_w2res( "VARIANT_ID" . $csv_result_delim . "$VARIANT_ID" . $csv_result_delim );
        }
        else { $VARIANT_ID = $not_given; }

        ## if Variant Version has been read in INIT campaign
        if ( $ENV{'VARIANT_VERSION'} ) {

            #STEP store Variant Version for use in all LIFT TC reports
            $VARIANT_VERSION = $ENV{'VARIANT_VERSION'};

            ## write the Variant Version into result file for archiving in Test Project Management
            S_w2res( "VARIANT_VERSION" . $csv_result_delim . "$VARIANT_VERSION" . $csv_result_delim );
        }
        else { $VARIANT_VERSION = $not_given; }

        if ( $ENV{'ECU_fingerprint'} ) {

            #STEP store ECU SW Version for use in all LIFT TC reports
            $ECU_FINGERPRINT = $ENV{'ECU_fingerprint'};

            ## write the ECU SW Version into result file for archiving in Test Project Management
            S_w2res( "ECU_fingerprint" . $csv_result_delim . "$ECU_FINGERPRINT" . $csv_result_delim );
        }
        else { $ECU_FINGERPRINT = $not_given; }

        #STEP store metadata (TT_No, HW_version, HW_serial_no) in project_info
        my $HW_details = undef;

        if ( defined($ECU_HW_details) ) {
            foreach my $ecu_fp ( keys %$ECU_HW_details ) {
                if ( $ecu_fp eq $ECU_FINGERPRINT ) {
                    $HW_details = $ECU_HW_details->{$ecu_fp};
                }
            }
        }
        if ( defined($HW_details) ) {
            $TTNO     = ( defined $HW_details->{'TT_No'}        && $HW_details->{'TT_No'} !~ /^\s*$/ )        ? $HW_details->{'TT_No'}        : $not_given;
            $HW_ver   = ( defined $HW_details->{'HW_version'}   && $HW_details->{'HW_version'} !~ /^\s*$/ )   ? $HW_details->{'HW_version'}   : $not_given;
            $HW_serNo = ( defined $HW_details->{'HW_serial_no'} && $HW_details->{'HW_serial_no'} !~ /^\s*$/ ) ? $HW_details->{'HW_serial_no'} : $not_given;
        }
        my $project_info_href = S_get_project_info();
        $project_info_href->{'TT_No'}    = $TTNO;
        $project_info_href->{'HW_ver'}   = $HW_ver;
        $project_info_href->{'HW_serNo'} = $HW_serNo;
        S_set_project_info($project_info_href);

        #STEP write to result file
        $TC_start_time = $ALL_TC->{'IC'}{'START_TIME'};
        my $TC_end_time = $ALL_TC->{'IC'}{'END_TIME'};

        ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);

        my $duration   = $ALL_TC->{'IC'}{'END_TIME'} - $ALL_TC->{'IC'}{'START_TIME'};
        my $tc_comment = "";
        $tc_comment = $ALL_TC->{'IC'}{'TC_COMMENT'} if $ALL_TC->{'IC'}{'TC_COMMENT'};

        S_w2res( "INITC_VD" . $csv_result_delim . "$tc_id" . $csv_result_delim . "$init_cpg_result" . $csv_result_delim . "$start_date" . $csv_result_delim . "$start_time" . $csv_result_delim . "$duration" . $csv_result_delim . "INIT_CAMPAIGN" . $csv_result_delim . "$tc_comment" );

        Write_tc_results_to_logs( $tc_id, 'IC', $max_nr, $TC_start_time, $TC_end_time );

        @TC_HTML_TEXT = ();

        #CALL Fill_jUnit_XML
        Fill_jUnit_XML(
            {
                'tc_id'         => $tc_id,
                'TC_end_time'   => $TC_end_time,
                'TC_start_time' => $TC_start_time
            }
        );

        #STEP store IC info for use in server mode
        %all_TC_IC = %{ $ALL_TC->{'IC'} };
        delete $ALL_TC->{'IC'};

        #STEP set $last_flag if init campaign not successful
        unless ( ( $init_cpg_result eq VERDICT_PASS ) or ( $main::opt_offline and $init_cpg_result eq VERDICT_NONE ) ) {
            S_w2rep("\n END OF EXECUTION because INIT_CAMPAIGN NOT SUCCESSFUL \n");
            $last_flag = 1;
        }
    }
    else {
        $ECU_SW_VERSION  = "";
        $VARIANT_ID      = "";
        $VARIANT_VERSION = "";
        $ECU_FINGERPRINT = "";
        $TTNO            = $not_given;
        $HW_ver          = $not_given;
        $HW_serNo        = $not_given;
    }

    return $last_flag;
}

=head2 Create_jUnit_xml_root

    $dec_value = Create_jUnit_xml_root ();

creates Junit xml root object with root name as testlist name.

B<Arguments:>

NONE

B<Return Value:>

=over

=item $JUNIT_XmlRoot_href 

Global Variable '$JUNIT_XmlRoot_href' will be created
Returns 1 for success

=back

=cut

sub Create_jUnit_xml_root {

    S_w2log( 4, " Create_jUnit_xml_root: initialize Junit XML \n ", 'grey' );
    my $JUNIT_XML_obj = XML::LibXML::Document->new( '1.0', 'utf-8' );

    unless ( defined $JUNIT_XML_obj ) { S_set_error("Creating XML::LibXML::Document->new"); return }

    #STEP create testsuite as root element
    my $testsuite_obj = $JUNIT_XML_obj->createElement("testsuite");
    unless ( defined $testsuite_obj ) { S_set_error("Creating 'testsuite' element failed JUNIT_XML_obj->createElement"); return }

    my $testsuitename = $TestList;

    # extract only Test list name e.g. (TL_LRT) from : C:\..\..\TL_LRT.txt
    $testsuitename =~ s/.*(\\|\/)(.*)\.txt$/$2/;

    #STEP set testlist name as testsuite name
    $testsuite_obj->setAttribute( "name", $testsuitename );

    #STEP return junitxml object, test suite name and test suite object
    # set the document root element
    $JUNIT_XML_obj->setDocumentElement($testsuite_obj);
    $JUNIT_XmlRoot_href = { 'jUnitXML_obj' => $JUNIT_XML_obj, 'testsuitename' => $testsuitename, 'testsuite_obj' => $testsuite_obj, };
    return 1;

    #STEP END
}

sub ProcessTestCases {
    my $max_nr            = shift;
    my $last_flag         = shift;
    my $tcStartAfterIndex = shift;

    S_w2log( 5, "====> Processing Execution List\n" );    # (will not be written to html)

    # loop over all (numerical sorted) process numbers
    #LOOP-START Loop over all test cases in $ALL_TC hash
    foreach my $tc_cnt ( sort { $a <=> $b } keys %$ALL_TC ) {

        next if $tc_cnt eq 'EC';                                                 ### don't execute the END campaign in this loop
        next if defined $tcStartAfterIndex and $tc_cnt <= $tcStartAfterIndex;    # ignore all test cases with index <= $tcStartAfterIndex

        # stops testlist processing
        #   if user requested end of LIFT in GUI
        #     or a serious serious problem was found (SYSFAIL)
        last if $USER_STOP or $last_flag;

        #  if ($Flag_VerifyECUState) { last unless Start_TC_VerifyECUState() }

        #STEP reset sys_state and verdict
        S_set_sys_state(SYS_READY);
        S_set_verdict(VERDICT_NONE);
        S_teststep_reset_all();

        #STEP set variables for execution
        ## global from LIFT_general
        @TC_HTML_TEXT  = ();
        @htmlBookmarks = ();

        # TC iteration count and tc required for S_repeat_testcase called with option for separate HTML report
        my $iterationThisTC = 0;
        my $originalTCcount = $tc_cnt;

      BEGIN_TC_LOOP:

        @ACTUAL_ERROR_CODES = ();

        ## global from LIFT_general
        %TC_PARAMETER = ();

        @report_level_library = ();

        my $tc_id     = $ALL_TC->{$tc_cnt}{'TC_ID'};
        my $tc_module = $ALL_TC->{$tc_cnt}{'TC_MODULE'};

        # take testcase module in name space
        my $tc_module_file = $ALL_TC->{$tc_cnt}{'TC_MODULE_FILE'};
        S_reset_TC_time();
        S_w2log( 5, "==> $tc_cnt\t importing module $tc_module_file\n" );

        my $TC_start_time = time();
        my ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);
        S_w2log( 5, "   >>>>  $tc_id  <<<<\n" );
        S_w2rep("  started at $start_date $start_time \n");

        # Update_status before test case
        shift(@status_msg);    # cut the first lien
        unshift( @status_msg, "running Test $tc_cnt of $max_nr: $tc_id" );
        Update_status();

        # set the global var CURRENT_TC for use in useful functions
        $CURRENT_TC = $tc_id;

        # create TC html file name and update global var $TC_REPORT_NAME
        if ( $tc_cnt =~ /^\d+$/ ) {
            $file_prefix_number = sprintf( "%04d", $tc_cnt );
        }
        elsif ( $tc_cnt =~ m/./ ) {    # in case same TC is repeated and TC number is combination of original test case number and iteration
            my $mainTCNumber = abs($tc_cnt);
            $tc_cnt =~ m/^[0-9]+\.([0-9]+)/;
            my $iterationNumber = $1;
            $file_prefix_number = sprintf( "%04d", $mainTCNumber ) . "_" . sprintf( "%04d", $iterationNumber );
        }
        else {
            $file_prefix_number = '___';
        }

        #### IMPORTANT! TC ID used for filenames have been replaced the '.' with '-'
        $tc_id_for_file_name = $tc_id;
        $tc_id_for_file_name =~ s/\./-/g;
        $TC_REPORT_NAME = $OFFLINE . $file_prefix_number . "_" . $tc_id_for_file_name . ".html";

        $tc_html_file = $save_name . "/" . $TC_REPORT_NAME;

        ###------------------------------------------------------------------
        #STEP CHECK FIRST FOR ERRORS WHILE READING TESTLIST AND PARAMETERS
        ###------------------------------------------------------------------

        if ( my $error_text = $ALL_TC->{$tc_cnt}{'ERROR_READING_TESTSOURCES'} ) {
            S_set_error( $error_text, 21 );
            ## S_set_error has been set the verdict to VERDICT_INCONC
            $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = $VERDICT;
            $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{$VERDICT}++;

            my $TC_end_time = time();
            Write_tc_results_to_logs( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );
            next;    ### because nothing to do on the test system
        }

        ###------------------------------------------------------------------
        #STEP PREPARE TC PARAMETERS
        ###------------------------------------------------------------------
        if ( defined $ALL_TC->{$tc_cnt}{'TC_PARAMETER'} ) {
            %TC_PARAMETER = %{ $ALL_TC->{$tc_cnt}{'TC_PARAMETER'} };
        }
        if ( defined $ALL_TC->{$tc_cnt}{'TC_PRJ_PARAMETER'} ) {
            %TC_PRJ_PARAMETER = %{ $ALL_TC->{$tc_cnt}{'TC_PRJ_PARAMETER'} };
        }

        #            while ( ($key, $value) = each %TC_PARAMETER ) { S_w2log( 5, "KEY: $key VAL: $value\n"); }
        #            prepare_testcase_parameters ( $ALL_TC->{$tc_cnt}{'TC_PARAMETER'} );

        ###------------------------------------------------------------------
        ### INCLUDING THE TESTCASE MODULE FILE
        ###------------------------------------------------------------------
        #STEP eval & require the test module to check for syntax errors
        eval "require '$tc_module_file'";

        #check whether any error in loading the TC module
        if ($@) {
            S_set_error( "Error occured while loading testcase '$tc_module_file' : $@", 21 );
            $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = $VERDICT;
            $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{$VERDICT}++;

            my $TC_end_time = time();
            Write_tc_results_to_logs( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );
            Update_status();
            next;
        }

        #check whether the testcase (TC module) is containing all the four necessary TC functions (initialization, stimulation and measurement, evaluation, finalization)
        #STEP check if testcase contains necessary functions
        unless ( ValidateTCStructure( $tc_module, $tc_id, $tc_cnt ) ) {

            # log the error into report
            # S_set_error( " execute_testcase: invalid TC module '$tc_module' provided for the test", 21);
            #
            #  -> throwing error commented / function is already throwing an error
            #
            $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = $VERDICT;
            $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{$VERDICT}++;

            my $TC_end_time = time();
            Write_tc_results_to_logs( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );

            # update the status and move to next testcase
            Update_status();
            next;
        }

        ###------------------------------------------------------------------
        ### TC INITIALIZATION
        ###------------------------------------------------------------------

        my $read_parameters;

        #CALL do_TC_initialization
        ( $read_parameters, $ALL_TC->{$tc_cnt}{'TC_INIT'} ) = do_TC_initialization($tc_module);
        if ( $read_parameters eq ERROR ) {
            $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = $VERDICT;
            $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{$VERDICT}++;

            my $TC_end_time = time();
            Write_tc_results_to_logs( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );
            $last_flag = 1 if $SYS_STATE eq SYS_FAIL;
            next;    ### because nothing to do on the test system
        }
        $last_flag = 1 if $SYS_STATE eq SYS_FAIL;

        ###------------------------------------------------------------------
        ### TC STIMULATION & MEASUREMENT
        ###------------------------------------------------------------------
        if ( $SYS_STATE eq TC_INIT and not $last_flag ) {

            #            S_w2log( 5, "==> ($tc_cnt/$max_nr) $tc_id Execution\n");
            #CALL do_TC_stimulation_and_measurement
            $ALL_TC->{$tc_cnt}{'TC_STIMU'} = do_TC_stimulation_and_measurement($tc_module);
            $last_flag = 1 if $SYS_STATE eq SYS_FAIL;
        }

        Update_status();

        ###------------------------------------------------------------------
        ### TC EVALUATION
        ###------------------------------------------------------------------
        if ( $SYS_STATE eq TC_STIMU and not $last_flag ) {

            #            S_w2log( 5, "==> ($tc_cnt/$max_nr) $tc_id Evaluation\n");
            #CALL do_TC_evaluation
            $ALL_TC->{$tc_cnt}{'TC_EVAL'} = do_TC_evaluation($tc_module);
            $last_flag = 1 if $SYS_STATE eq SYS_FAIL;
        }

        Update_status();

        ###------------------------------------------------------------------
        ### TC FINALIZATION
        ###------------------------------------------------------------------
        if ( not $last_flag ) {

            #CALL do_TC_finalization
            $ALL_TC->{$tc_cnt}{'TC_FINAL'} = do_TC_finalization($tc_module);
        }
        $last_flag = 1 if $SYS_STATE eq SYS_FAIL;

        #
        # evaluation of LIFT_general::REPEAT_TC_FLAG (set by S_repeat_testcase() )
        # in case that user wants to repeat the testcase which is currently running
        #
        #STEP go to start of loop if REPEAT_TC_FLAG is 1
        if ( ( $LIFT_general::REPEAT_TC_FLAG == 1 ) and not $last_flag and not $USER_STOP ) {
            $LIFT_general::REPEAT_TC_FLAG = 0;
            S_set_sys_state(SYS_READY);
            S_set_verdict(VERDICT_NONE);
            S_teststep_reset_all();
            goto BEGIN_TC_LOOP;
        }

        ###------------------------------------------------------------------
        ### POST TC PROCESSING OF LIFT exec engine
        ###------------------------------------------------------------------

        $ALL_TC->{$tc_cnt}{'TC_VERDICT'} = $VERDICT;

        $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}{$VERDICT}++;

        # save error(s) of TC and reset @ACTUAL_ERROR_CODES
        @{ $ALL_TC->{$tc_cnt}{'TC_ERRORS'} } = @ACTUAL_ERROR_CODES;

        ###------------------------------------------------------------------
        ### check of sys state planned here in case of problems in processing testcase
        ###------------------------------------------------------------------

        # check sys state bla bla if testcase processing not OK

        my $TC_end_time = time();

        #CALL Fill_jUnit_XML
        Fill_jUnit_XML(
            {
                'tc_id'         => $tc_id,
                'TC_end_time'   => $TC_end_time,
                'TC_start_time' => $TC_start_time
            }
        );

        #CALL Write_tc_results_to_logs
        Write_tc_results_to_logs( $tc_id, $tc_cnt, $max_nr, $TC_start_time, $TC_end_time );

        Update_status();

        $last_flag = 1 if $SYS_STATE eq SYS_FAIL;

        # unload the testcase module for uninitializing all the gloabl variables in that module
        delete $INC{$tc_module_file};

        $total_TCs_time += $TC_end_time - $TC_start_time;

        #
        # evaluation of LIFT_general::REPEAT_TC_FLAG (set by S_repeat_testcase() )
        # in case that user wants to repeat the testcase which is currently running
        #
        #STEP go to start of loop if REPEAT_TC_FLAG is 2
        if ( ( $LIFT_general::REPEAT_TC_FLAG == 2 ) and not $last_flag and not $USER_STOP ) {
            $LIFT_general::REPEAT_TC_FLAG = 0;
            S_set_sys_state(SYS_READY);
            S_set_verdict(VERDICT_NONE);
            S_teststep_reset_all();

            $iterationThisTC++;
            $tc_cnt = $originalTCcount . "." . sprintf( "%04d", $iterationThisTC );

            # Add test case iteration to $ALL_TC and set all relevant attributes
            $ALL_TC->{"$tc_cnt"}               = $ALL_TC->{$originalTCcount};
            $ALL_TC->{"$tc_cnt"}{'TC_VERDICT'} = VERDICT_NONE;
            $ALL_TC->{"$tc_cnt"}{'TC_INIT'}    = INCONC;
            $ALL_TC->{"$tc_cnt"}{'TC_STIMU'}   = INCONC;
            $ALL_TC->{"$tc_cnt"}{'TC_EVAL'}    = INCONC;
            $ALL_TC->{"$tc_cnt"}{'TC_FINAL'}   = INCONC;
            $ALL_TC->{"$tc_cnt"}{'TC_ERRORS'}  = [];

            # Empty HTML Text and bookmarks for separate HTML report
            @TC_HTML_TEXT  = ();
            @htmlBookmarks = ();

            # Restart test case
            goto BEGIN_TC_LOOP;
        }
    }

    #LOOP-END Last testcase?

    # STEP add total test case executed, total time taken, passed, failed, inconc info to Junit xml
    my $total_tcs_executed = 0;
    foreach my $verdict ( keys %{ $ALL_VERDICTS->{TOTAL_EXECUTED_TC} } ) {
        $total_tcs_executed = $total_tcs_executed + $ALL_VERDICTS->{TOTAL_EXECUTED_TC}{$verdict};
    }

    #STEP end
    return 1;
}

=head2 Fill_jUnit_XML

    Fill_jUnit_XML ($jUnitprop_href);

Fills Junit xml data with test case details

B<Arguments:>

=over

=item $jUnitprop_href 

href containing the details of testsuitname, test case id,  end time, start time, test suit object, junitxml object.

=back

B<Return Value: 1>

=cut

sub Fill_jUnit_XML {

    my $jUnitprop_href = shift;

    unless ( defined $JUNIT_XmlRoot_href ) {
        S_set_error("Internal strcut doesnt exists - sub : Create_jUnit_xml_root must be called before");
        return;
    }

    my $tc_id         = $jUnitprop_href->{'tc_id'};
    my $TC_end_time   = $jUnitprop_href->{'TC_end_time'};
    my $TC_start_time = $jUnitprop_href->{'TC_start_time'};

    my $testsuitename = $JUNIT_XmlRoot_href->{'testsuitename'};
    my $testsuite_obj = $JUNIT_XmlRoot_href->{'testsuite_obj'};
    my $JUNIT_XML_obj = $JUNIT_XmlRoot_href->{'jUnitXML_obj'};

    S_w2log( 4, " Fill_jUnit_XML: Adding Entry '$tc_id' to Junit XML \n ", 'grey' );

    #STEP create test case node
    my $testcase_node = $JUNIT_XML_obj->createElement("testcase");

    #STEP set tescase attributes

    $testcase_node->setAttribute( "classname", $testsuitename );
    $testcase_node->setAttribute( "name",      $tc_id );
    $testcase_node->setAttribute( "time",      $TC_end_time - $TC_start_time );
    $testsuite_obj->appendChild($testcase_node);

    #STEP add test cases details with failures to Junit XML
    if ( $VERDICT eq VERDICT_FAIL ) {
        my @evaltxt       = @LIFT_general::EVAL_TEXT;
        my @failure_cause = grep { $_ =~ /MISMATCH/ } @evaltxt;
        my $failure_node  = $JUNIT_XML_obj->createElement("failure");
        $failure_node->appendText( $failure_cause[0] );
        $testcase_node->appendChild($failure_node);
    }

    #STEP add test cases details with errors to Junit XML
    if ( $VERDICT eq VERDICT_INCONC ) {
        my ( $err_type, $err_txt ) = split( /#/, $TC_errors[0] );
        my $error_node = $JUNIT_XML_obj->createElement("error");
        $error_node->setAttribute( "type", $err_type );
        $error_node->appendText($err_txt);
        $testcase_node->appendChild($error_node);

        @TC_errors = ();
    }

    #STEP add test case details with verdict none to XML
    if ( $VERDICT eq VERDICT_NONE or $VERDICT eq VERDICT_BLOCKED ) {
        my $skipped_node = $JUNIT_XML_obj->createElement("skipped");
        $skipped_node->setAttribute( "message", $VERDICT );
        $testcase_node->appendChild($skipped_node);
    }

    #STEP END
    return 1;
}

sub ProcessEndCampaign {
    my $max_nr = shift;

    if ( exists $ALL_TC->{'EC'} ) {

        S_set_sys_state(SYS_READY);
        S_set_verdict(VERDICT_NONE);
        S_teststep_reset_all();

        @ACTUAL_ERROR_CODES = ();
        ## global from LIFT_general
        @TC_HTML_TEXT = ();
        ## global from LIFT_general
        %TC_PARAMETER = ();

        my $TC_start_time = time();
        my ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);

        my $tc_id = $ALL_TC->{'EC'}{'TC_ID'};
        S_reset_TC_time();
        S_w2log( 5, "   >>>>  $tc_id  <<<<\n" );
        S_w2rep("  started at $start_date $start_time \n");

        # create TC html file name and update global var $TC_REPORT_NAME
        $file_prefix_number = '___';

        #### IMPORTANT! TC ID used for filenames have been replaced the '.' with '-'
        $tc_id_for_file_name = $tc_id;
        $tc_id_for_file_name =~ s/\./-/g;
        $TC_REPORT_NAME = $OFFLINE . $file_prefix_number . "_" . $tc_id_for_file_name . ".html";

        $tc_html_file = $save_name . "/" . $TC_REPORT_NAME;

        my $end_cpg_result = execute_end_campaign();

        ## writing to result file
        $TC_start_time = $ALL_TC->{'EC'}{'START_TIME'};
        my $TC_end_time = $ALL_TC->{'EC'}{'END_TIME'};

        ( $start_date, $start_time ) = S_formated_timestamp($TC_start_time);

        my $duration   = $ALL_TC->{'EC'}{'END_TIME'} - $ALL_TC->{'EC'}{'START_TIME'};
        my $tc_comment = "";
        $tc_comment = $ALL_TC->{'EC'}{'TC_COMMENT'} if $ALL_TC->{'EC'}{'TC_COMMENT'};

        S_w2res( "ENDTC_VD" . $csv_result_delim . "$tc_id" . $csv_result_delim . "$end_cpg_result" . $csv_result_delim . "$start_date" . $csv_result_delim . "$start_time" . $csv_result_delim . "$duration" . $csv_result_delim . "END_CAMPAIGN" . $csv_result_delim . "$tc_comment" );

        #CALL Fill_jUnit_XML
        Fill_jUnit_XML(
            {
                'tc_id'         => $tc_id,
                'TC_end_time'   => $TC_end_time,
                'TC_start_time' => $TC_start_time
            }
        );

        Write_tc_results_to_logs( $tc_id, 'EC', $max_nr, $TC_start_time, $TC_end_time );

        @TC_HTML_TEXT = ();
        %all_TC_EC    = %{ $ALL_TC->{'EC'} };
        delete $ALL_TC->{'EC'};
    }

    return 1;
}

sub PrepareCampaignExecution {
    my $lift_start_time = shift;

    my $useless_dummy;    # dirty workaround to avoid warning "xx used only once, possible typo" for included vars

    ### initialize hash with LIFT error codes (LIFT_general)
    my $errorCodesPath = "$LIFT_exec_path/modules/Common_library/LIFT_error_codes.txt";
    S_init_LIFT_error_list($errorCodesPath) if -f $errorCodesPath;

    ###------------------------------------------------------------------
    ### initialize LIFT variables from LIFT_config package
    ###------------------------------------------------------------------

    #STEP load code of config module
    unless ( -f $opt_conf ) {
        S_set_error( "Given main CFG file ($opt_conf) does not exist.\n", 21 );
        return;
    }

    require $opt_conf;

    ###------------------------------------------------------------------
    #CALL Read_config to read all used global vars from config file
    ###------------------------------------------------------------------
    return unless Read_config();

    $ECU_HW_details = $ProjectDefaults->{'ECU_HW_INFO'};

    ###------------------------------------------------------------------
    #CALL open_all_logs to open all log files and write start text in them
    ###------------------------------------------------------------------
    return unless open_all_logs($lift_start_time);

    #
    #STEP set initial state of LIFT state machine
    #
    S_set_sys_state(SYS_INIT);

    #STEP add paths for engine modules in funclib_Customer and test areas
    my $configPath  = dirname($opt_conf);
    my $custlibPath = "$configPath/..";     # first guess for custlib path
    my ( $funclibPath, $funclibPathFound );
    foreach ( 1 .. 9 ) {                    # max 9 trials to find the path to funclib_Customer
        $funclibPath = "$custlibPath/funclib_Customer";    # guess for path to funclib_Customer
        if ( -d $funclibPath ) {
            $funclibPathFound = 1;
            last;
        }
        $custlibPath = "$custlibPath/..";                  # if the path is not right yet, try to go one level up
    }

    if ($funclibPathFound) {
        S_w2log( 1, "PrepareCampaignExecution: Folder 'funclib_Customer' found: $funclibPath\n" );
        Add_paths($funclibPath);
    }
    else {
        S_set_warning("PrepareCampaignExecution: No folder 'funclib_Customer' found in the vicinity of the main CFG file ($opt_conf). No customer specific engine modules will be used.\n");
    }

    foreach my $tcPath (@tc_paths) {
        Add_paths( $tcPath, "Engine" );
    }

    if ($opt_report_overview) {
        my $callstate = system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $LIFT_exec_path/CreateHtmlResultOverview.pl --dir $LIFT_config::LIFT_LOG_path");
        push( @runtime_ERRORS, "error in Engine/CreateHtmlResultOverview.pl ($callstate) $@, <br>please try running Engine/run_once/install_ALL_modules.bat to ensure anll required modules are present" ) if ( $callstate != 0 );
    }

    $useless_dummy = $LIFT_config::LIFT_PARA_path;
    $useless_dummy = $LIFT_config::LIFT_PROJECT_PARAMETER_file;

    # flag to indicate whether the reading of testlists & parameters is successful
    my $IsReadingFailed = 0;

    #CALL Check_init_end_campaign to prepare init and end campaign
    Check_init_end_campaign();

    ###------------------------------------------------------------------
    #CALL Read_testlist to read all available testcases from testlist
    ### create the structure ALL_TC
    ###------------------------------------------------------------------
    # $TestList defined by user option -testlist (-> $opt_testlist)

    my $max_nr = Read_testlist();

    # set the flag if testlist reading is not successful
    unless ( $SYS_STATE eq SYS_INIT ) {
        S_w2rep("\n END OF EXECUTION because reading Testlist NOT SUCCESSFUL \n");
        $IsReadingFailed = 1;
    }

    ###------------------------------------------------------------------
    #CALL Read_all_parameter to read the testcase parameter
    ### of each testcase from testcase parameter file and
    ### from project parameter file
    ### and store tc para in ALL_TC structure
    ###------------------------------------------------------------------
    Read_all_parameter($LIFT_config::LIFT_PROJECT_PARAMETER_file);

    # set the flag if parameters reading is not successful
    unless ( $SYS_STATE eq SYS_INIT ) {
        S_w2rep("\n END OF EXECUTION because reading Parameter NOT SUCCESSFUL \n");
        $IsReadingFailed = 1;
    }

    #STEP check whether the parameter reading & testlist reading is failed, if so, stop the execution
    if ($IsReadingFailed) {
        S_close_all();

        # determine the log file name & its absolute path
        my $LOG_file_name = File::Spec->rel2abs("$save_name/$main_LOG_name");
        $LOG_file_name =~ s/\.\w+$/_log.txt/g;    # replace file extension (e.g. .html) with _log.txt

        # open the log file automatically to show the issues found in parameter file & testlist file
        # if the testlist is long, it is tough for the user to find out the issue. hence, opening the log automatically
        print "\nRefer to the LOG file (*_log.txt) for further information. \n\nTrying to open the log file '$LOG_file_name' \n\n";
        system("explorer.exe \"$LOG_file_name\"");
        return;
    }

    #CALL LIFT_general::S_setSystemSleepMode to switch off the sleep mode of PC
    S_setSystemSleepMode('disabled');

    #CALL LIFT_general::S_SCCM_SetSoftwareDistribution to switch off automatic software updates by SCCM
    S_SCCM_SetSoftwareDistribution('disabled');

    ###------------------------------------------------------------------
    ### TAKE THE SNAPSHOTS FOR REPRODUCING THE SAME TEST BEHAVIOR
    ###------------------------------------------------------------------
    #CALL CreateSnapshot
    CreateSnapshot();

    #STEP initialize the state & verdict to SYS_INIT, VERDICT_NONE before IC
    S_set_sys_state(SYS_INIT);
    $LIFT_general::VERDICT = VERDICT_NONE;

    return $max_nr;
}

sub Check_init_end_campaign {
    my $tc_para_path = $TC_PARA_path;

    unless ( defined $TestList )     { S_set_error( "no testlist given",                      21 ); return 0; }
    unless ( scalar(@tc_paths) )     { S_set_error( "no path of testcases given",             21 ); return 0; }
    unless ( defined $tc_para_path ) { S_set_error( "no path of parameter files given",       21 ); return 0; }
    unless ( -f $TestList )          { S_set_error( "given testlist $TestList doesn't exist", 21 ); return 0; }
    foreach my $tc_path (@tc_paths) {
        unless ( -d $tc_path ) { S_set_error( "given path of testcases $tc_path doesn't exist", 21 ); return 0; }
    }
    unless ( -d $tc_para_path ) { S_set_error( "given path of parameter files $tc_para_path doesn't exist", 21 ); return 0; }

    my ( $tc_init_module, $tc_init_module_file, $tc_init_par_file, $tc_end_module, $tc_end_module_file, $tc_end_par_file );

    # $TC_INIT_CAMPAIGN in config file ??
    if ( defined $TC_INIT_CAMPAIGN ) {

        ### if IC looks like 'MY_IC.MY_PARA'
        if ( $TC_INIT_CAMPAIGN =~ /^\s*(\w+)\.(\w+)\s*/ ) {
            $tc_init_module      = $1;
            $tc_init_module_file = "$TC_INIT_path/$1" . ".pm";
            $tc_init_par_file    = "$TC_INIT_path/$1" . ".par";
        }
        ### if IC looks like 'MY_IC'
        elsif ( $TC_INIT_CAMPAIGN =~ /^\s*(\w+)\s*/ ) {
            $tc_init_module      = $1;
            $tc_init_module_file = "$TC_INIT_path/$1" . ".pm";
        }
        else {
            S_set_error( " Invalid format of TC_INIT_CAMPAIGN '$TC_INIT_CAMPAIGN' (use: 'MY_IC' or 'MY_IC.MY_PAR') ", 21 );
        }

        unless ( -f $tc_init_module_file ) {
            S_set_error( " INIT Campaign TC Module file '$tc_init_module_file' not found\n", 21 );
            return 0;
        }
        Copy2rerun($tc_init_module_file);

        if ($tc_init_par_file) {
            unless ( -f $tc_init_par_file ) {
                S_set_error( " INIT Campaign TC Para file '$tc_init_par_file' not found\n", 21 );
                return 0;
            }
            Copy2rerun($tc_init_par_file);
        }

        $ALL_TC->{'IC'}->{'TC_ID'}          = $TC_INIT_CAMPAIGN;
        $ALL_TC->{'IC'}->{'TC_MODULE'}      = $tc_init_module;
        $ALL_TC->{'IC'}->{'TC_MODULE_FILE'} = $tc_init_module_file;
        $ALL_TC->{'IC'}->{'TC_PAR_FILE'}    = $tc_init_par_file if $tc_init_par_file;
        $ALL_TC->{'IC'}->{'TC_PARAMETER'}   = undef if $tc_init_par_file;
        $ALL_TC->{'IC'}->{'TC_COMMENT'}     = "";

    }

    # $TC_END_CAMPAIGN in config file ??
    if ( defined $TC_END_CAMPAIGN ) {

        ### if EC looks like 'MY_EC.MY_PARA'
        if ( $TC_END_CAMPAIGN =~ /^\s*(\w+)\.(\w+)\s*/ ) {
            $tc_end_module      = $1;
            $tc_end_module_file = "$TC_END_path/$1" . ".pm";
            $tc_end_par_file    = "$TC_END_path/$1" . ".par";
        }
        ### if EC looks like 'MY_EC'
        elsif ( $TC_END_CAMPAIGN =~ /^\s*(\w+)\s*/ ) {
            $tc_end_module      = $1;
            $tc_end_module_file = "$TC_END_path/$1" . ".pm";
        }
        else {
            S_set_error( " Invalid format of TC_END_CAMPAIGN '$TC_END_CAMPAIGN' (use: 'MY_EC' or 'MY_EC.MY_PAR') ", 21 );
        }

        unless ( -f $tc_end_module_file ) {
            S_set_error( " END Campaign TC Module file '$tc_end_module_file' not found\n", 21 );
            return 0;
        }
        Copy2rerun($tc_end_module_file);

        if ($tc_end_par_file) {
            unless ( -f $tc_end_par_file ) {
                S_set_error( " END Campaign TC Para file '$tc_end_par_file' not found\n", 21 );
                return 0;
            }
            Copy2rerun($tc_end_par_file);
        }

        $ALL_TC->{'EC'}->{'TC_ID'}          = $TC_END_CAMPAIGN;
        $ALL_TC->{'EC'}->{'TC_MODULE'}      = $tc_end_module;
        $ALL_TC->{'EC'}->{'TC_MODULE_FILE'} = $tc_end_module_file;
        $ALL_TC->{'EC'}->{'TC_PAR_FILE'}    = $tc_end_par_file if $tc_end_par_file;
        $ALL_TC->{'EC'}->{'TC_PARAMETER'}   = undef if $tc_end_par_file;
        $ALL_TC->{'EC'}->{'TC_COMMENT'}     = "";

    }

    return 1;
}

=head2 Check_checksums

    $allChecksumsOK = Check_checksums();

Searches for files named 'LIFT_checksums.md5' in the engine folder structure, 
extracts all file names and corresponding md5 checksums from those files
and checks if the files have the same md5 checksums as listed in the LIFT_checksums.md5 files.

Fills a global data structure ($checksumResultsAll_href) that is used to write "Running with a modified engine...""
to the test reports if some checksums are not OK. 

Returns 1 if all checksums are OK, 0 otherwise.

=cut

sub Check_checksums {

    my $engineComponentName = 'TurboLIFT_Engine';
    $checksumResultsAll_href->{Warnings} = [];
    my @checksumFiles;

    #STEP search for checksum files 'LIFT_checksums.md5' in engine folders
    my $allChecksumsOK = 1;
    S_w2log( 4, "Check_checksums: Searching for checksum files...\n" );

    find(
        {
            wanted => sub {
                if ( $_ eq 'LIFT_checksums.md5' ) { push( @checksumFiles, $File::Find::name ); }
              }
        },
        $LIFT_exec_path,
        @tc_paths
    );

    #CALL Remove_duplicate_components
    my ( $cleanedChecksumFiles_aref, $duplicatesWarnings_aref ) = Remove_duplicate_components( \@checksumFiles );
    if ( @$duplicatesWarnings_aref > 0 ) {
        push( @{ $checksumResultsAll_href->{Warnings} }, @$duplicatesWarnings_aref );
        $allChecksumsOK = 0;
    }

    my $mainEngineComponentFound;
    my $checkedFiles_aref = [];

    #LOOP-START loop over found checksum files
    foreach my $checksumFile ( reverse @$cleanedChecksumFiles_aref ) {
        S_w2log( 4, "Check_checksums: Checking checksum file '$checksumFile'...\n" );

        #CALL Check_checksum_file
        my $checksumResultsSingle_href = Check_checksum_file( $checksumFile, $checkedFiles_aref );

        #STEP fill list with already checked files
        push( @$checkedFiles_aref, @{ $checksumResultsSingle_href->{'AllFiles'} } );

        #STEP fill global structure $checksumResultsAll_href for current component
        my $component = $checksumResultsSingle_href->{Component} // 'unknown';
        $checksumResultsAll_href->{Components}{$component} = $checksumResultsSingle_href;

        $mainEngineComponentFound = 1 if $component eq $engineComponentName;

        #STEP write check result for current component to log
        my $resultText = "Check_checksums: Checksum check result for file '$checksumFile' (Component '$component') is";
        if ( not $checksumResultsSingle_href->{OK} ) {
            $allChecksumsOK = 0;
            S_w2log( 4, "$resultText >>> NOT OK <<<\n" );
        }
        else {
            S_w2log( 4, "$resultText OK\n" );
        }

    }

    #LOOP-END last checksum file?

    #STEP store warning if main engine component was not found
    if ( not $mainEngineComponentFound ) {
        push( @{ $checksumResultsAll_href->{Warnings} }, "Check_checksums: Checksum file for main engine component (Engine/LIFT_checksums.md5) not found or corrupt. $checksumAdvice\n" );
        $allChecksumsOK = 0;
    }

    #CALL Check_dependent_components
    my $dependenciesOK = Check_dependent_components();
    $allChecksumsOK = 0 if not $dependenciesOK;

    #STEP write overall check result to log
    $checksumResultsAll_href->{overallOK} = $allChecksumsOK;
    my $overallResultText = "Check_checksums: Overall checksum check result is";
    if ($allChecksumsOK) {
        S_w2log( 4, "$overallResultText OK\n" );
    }
    else {
        S_w2log( 4, "$overallResultText >>> NOT OK <<<\n" );
        S_w2log( 4, "Reason: see below.\n" );
        S_check_LIFT_component_integrity();
        S_w2log( 4, "###################################################################\n" );
        S_w2log( 4, "# Running with a modified engine. Do not use for release testing. #\n" );
        S_w2log( 4, "###################################################################\n" );
    }

    return $allChecksumsOK;
}

=head2 Get_component_integrity

    $status = Get_component_integrity();

B<Description>: 

Checks the component checkpoint under use is Obsolete or not.

Reads valid versions from file '<component_name>.txt' which contains the checkpoint versions under Maintenance/released.

components can be extended for the version check by adding a file with name <component_name.txt> in below mentioned location. 

File location : \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\valid_versions\<component_name>.txt

B<Example> :

TurboLIFT_Engine component:

    \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\valid_versions\TurboLIFT_Engine.txt
    
    Content should be the currently valid version numbers in each line :
    2.04
    2.03
    2.02
    2.013
    2.00

Returns log as 'ALL_OK' if components are valid, otherwise returns the log messages for components with obsolete versions used.

=cut

sub Get_component_integrity {
    my ( $checkpointcompletelog, $accessErrorLog, $invalidVersionsLog );
    my $invalid_ver_flag       = 0;
    my $access_err_flag        = 0;
    my $turboLIFT_K_drive_path = '\\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\valid_versions';

    #IF Is Network drive accessible?
    #IF-YES-START
    if ( -e $turboLIFT_K_drive_path ) {

        #LOOP-START loop over each component
        foreach my $component ( keys %{ $checksumResultsAll_href->{Components} } ) {
            my $component_version_used = $checksumResultsAll_href->{Components}{$component}{Version};

            my $component_file_path = "$turboLIFT_K_drive_path" . '\\' . "$component" . '.txt';
            if ( -e $component_file_path ) {
                my $options_href = { 'file_path' => $component_file_path };

                #CALL Get_valid_component_versions to read valid versions
                my $valid_versions_aref = Get_valid_component_versions($options_href);
                unless ($valid_versions_aref) {
                    if ( $access_err_flag == 0 ) {
                        $accessErrorLog .= 'Validity of following component version(s) cannot be determined: <br> ';
                    }
                    $access_err_flag++;
                    $accessErrorLog .= "&nbsp; &nbsp; $access_err_flag. '$component' <br> ";
                    next;
                }

                #STEP Report to log if used version of component is not valid
                if ( not $component_version_used ~~ @$valid_versions_aref ) {
                    if ( $invalid_ver_flag == 0 ) {
                        $invalidVersionsLog .= 'Running with an unsupported: <br>';
                    }
                    $invalid_ver_flag++;

                    #&nbsp; is used to provide extra space in html report for better reporting
                    $invalidVersionsLog .= " &nbsp; &nbsp; $invalid_ver_flag. '$component' version : $component_version_used. " . "<br>";
                }
            }
        }

        #LOOP-END all components are looped?
        #IF-YES-END
    }

    #IF-NO-START
    #STEP Report to log if component files containing valid versions are not accessible
    else {
        $checkpointcompletelog .= "Validity of Engine version cannot be determined. Could be because of following reasons: <br>" . $nw_or_path_access_err;
    }

    #IF-NO-END

    $accessErrorLog .= $component_version_file_access_err_log if ($accessErrorLog);
    $checkpointcompletelog .= $invalidVersionsLog . $accessErrorLog;
    unless ( $checkpointcompletelog eq '' ) {
        $checkpointcompletelog .= $checkpointlogtext;
    }

    #STEP return 'ALL_OK' if no invalid versions are found
    $checkpointcompletelog = 'ALL_OK' unless ($checkpointcompletelog);
    return $checkpointcompletelog;

    #STEP END
}

=head2 Get_valid_component_versions

    $versions_aref = Get_valid_component_versions();

Returns the content of version list file containing valid versions of component.

B<Return Values:>

=over

=item $versions_aref

aref containing list of valid versions.

undef on error.

=back

B<Examples:>

    [2.04, 2.03, 2.02] = Get_valid_component_versions({'file_path' => '\\\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Projects\Testing_exchange\TurboLIFT\valid_versions\TurboLIFT_Engine.txt'});

=cut

sub Get_valid_component_versions {
    my @args         = @_;
    my $options_href = shift @args;

    my $file_path = $options_href->{'file_path'};
    my @versions = read_file( $file_path, { err_mode => "quiet" } );
    unless (@versions) {
        S_w2log( 4, "Get_valid_component_versions:  Couldn't open $file_path for reading $!" );
        return;
    }
    map { $_ =~ s/(\s+)?\n// } @versions;    #  remove tabs and spaces if any for each line
    @versions = grep { $_ ne '' } @versions; # handle empty lines if present
    return \@versions;
}

=head2 Remove_duplicate_components

    ($cleanedChecksumFiles_aref, $warnings_aref) = Remove_duplicate_components($checksumFiles_aref);

Looks for duplicate components in $checksumFiles_aref. If there are duplicates then the component in a test-area remains 
and the non-test-area component will be removed from the list. If there are duplicates and both are non-test-area components
then a warning will be added to $warnings_aref.

Returns:

    $cleanedChecksumFiles_aref: list of checksum files with duplicates removed
    $warnings_aref: list of warnings if exist

=cut

sub Remove_duplicate_components {
    my $checksumFiles_aref = shift;

    my $allComponents_href = {};
    my @cleanedChecksumFiles;
    my @warnings;

    #LOOP-START loop over found checksum files
    foreach my $checksumFile (@$checksumFiles_aref) {

        #CALL Get_checksum_component
        my $component = Get_checksum_component($checksumFile);

        #IF current component is not in $allComponents_href?
        if ( not exists $allComponents_href->{$component} ) {

            #IF-YES-START
            #STEP add current component to $allComponents_href
            $allComponents_href->{$component} = $checksumFile;

            #IF-YES-END
        }
        else {
            #IF-NO-START
            my $previousChecksumFile = $allComponents_href->{$component};
            my $testAreaRegex        = '/TestArea_\w+/';
            my $logText1             = "Remove_duplicate_components: Checksum file for component $component exists more than once: $previousChecksumFile AND $checksumFile.";
            my $logText2             = " is used because it is part of a TestArea.\n";

            #IF previous component is a test area and current component is no test area?
            if ( $previousChecksumFile =~ m{$testAreaRegex} and $checksumFile !~ m{$testAreaRegex} ) {

                #IF-YES-START
                #STEP Previous checksum file is part of a test area. Next loop iteration and do not add the current path to @cleanedChecksumFiles
                S_w2log( 4, $logText1 . " Checksum file " . $previousChecksumFile . $logText2 );
                next;

                #IF-YES-END
            }

            #IF-NO-START
            #IF current component is a test area and previous component is no test area?
            elsif ( $checksumFile =~ m{$testAreaRegex} and $previousChecksumFile !~ m{$testAreaRegex} ) {

                #IF-YES-START
                #STEP Current checksum file is part of a test area. Delete the previously existing entry in @cleanedChecksumFiles
                S_w2log( 4, $logText1 . " Checksum file " . $checksumFile . $logText2 );
                my $index = 0;
                $index++ until $cleanedChecksumFiles[$index] eq $previousChecksumFile;
                splice( @cleanedChecksumFiles, $index, 1 );

                #IF-YES-END
            }
            else {
                #IF-NO-START
                #STEP Checksum file for component $component exists more than once but neither or both of them are part of a TestArea
                my $warning = $logText1 . " Neither or both of them are part of a TestArea. Don't know which to prefer but using now $previousChecksumFile (first in the list).\n";
                S_w2log( 4, $warning );
                push( @warnings, $warning );
                next;
            }

            #IF-NO-END
            #IF-NO-END
            #IF-NO-END
        }
        push( @cleanedChecksumFiles, $checksumFile );
    }

    #LOOP-END last checksum file?

    return ( \@cleanedChecksumFiles, \@warnings );
}

=head2 Get_checksum_component

    $component = Get_checksum_component($checksumPath);

Reads a checksum file ($checksumPath) extracts the header and returns the name of the componet.

Returns:

    $component = <sting>       # component name 

=cut

sub Get_checksum_component {
    my $checksumPath = shift;

    #CALL Read_checksum_file
    my $fileLines_aref = Read_checksum_file($checksumPath) or return { 'OK' => 0 };

    my $checkResults_href = {};

    #CALL Get_checksum_file_header
    my $headerFound = Get_checksum_file_header( $checksumPath, $fileLines_aref, $checkResults_href );

    #STEP get component name from header
    my $component = $checkResults_href->{Component} // 'unknown';
    S_w2log( 4, "Get_checksum_component: Component name for LIFT checksum file '$checksumPath' is '$component'.\n" );

    #END return component name
    return $component;
}

=head2 Check_checksum_file

    $checkResults_href = Check_checksum_file($checksumPath, $checkedFiles_aref);

Reads a checksum file ($checksumPath), extracts all file names and corresponding md5 checksums from it
and checks if the files have the same md5 checksums as listed in the checksum file.

Returns:

    $checkResults_href = {
        Component => <sting>,        # component name 
        Version => <number>,         # component version number
        OK => 0|1,                   # 1 if all checksums are OK
        AllFiles => [...],           # list of all checked files
        NotExistFiles => [...],      # list of files that are listed in the checksum-
                                     # file but not found in the sandbox
        WrongChecksumFiles => [...], # list of files with wrong checksum
    }

=cut

sub Check_checksum_file {
    my $checksumPath      = shift;
    my $checkedFiles_aref = shift;

    S_w2log( 4, "Check_checksum_file: Checking checksums of TurboLIFT files according to LIFT checksum file '$checksumPath'.\n" );

    #CALL Read_checksum_file
    my $fileLines_aref = Read_checksum_file($checksumPath) or return { 'OK' => 0 };

    my $checkResults_href = {
        AllFiles           => [],
        NotExistFiles      => [],
        WrongChecksumFiles => [],
        Warnings           => [],
    };

    #CALL Get_checksum_file_header
    my $headerFound = Get_checksum_file_header( $checksumPath, $fileLines_aref, $checkResults_href );

    #CALL Check_checksum_file_checksum
    Check_checksum_file_checksum( $checksumPath, $headerFound, $fileLines_aref, $checkResults_href ) or return $checkResults_href;

    my $componentRootPath = dirname($checksumPath);

    #LOOP-START loop over checksum list
    foreach my $line (@$fileLines_aref) {

        #CALL Check_list_entry_checksum
        Check_list_entry_checksum( $line, $componentRootPath, $checkResults_href, $checkedFiles_aref );
    }

    #LOOP-END last list entry?

    #CALL Evaluate_checks
    Evaluate_checksum_checks($checkResults_href);

    return $checkResults_href;
}

=head2 Read_checksum_file

    $fileLines_aref = Read_checksum_file($checksumPath);

Reads a checksum file ($checksumPath) and returns all lines of the file as list reference.

=cut

sub Read_checksum_file {
    my $checksumPath = shift;

    #STEP open file in binmode
    my $fh;
    unless ( open $fh, "<", $checksumPath ) {
        S_set_error("Could not open LIFT checksum file '$checksumPath': $!\n");
        return;
    }
    binmode($fh);

    #STEP put the contents of the file into a string
    my $fileString = do { local $/; <$fh> };    # put the contents of the file into a string
    close $fh;

    #STEP split string into lines
    my @fileLines = split( /\n/, $fileString );

    return \@fileLines;
}

=head2 Get_checksum_file_header

    $headerFound = Get_checksum_file_header($checksumPath, $fileLines_aref, $checkResults_href);

Extracts header information from a checksum file ($checksumPath, $fileLines_aref). 
A header line is optional and has the form:

    <key>: <value> 

Possible keys are 'Component' and 'Version'.

Header information (if found) is stored in $checkResults_href.

Returns 1 if a header is found, undef otherwise.

=cut

sub Get_checksum_file_header {
    my $checksumPath      = shift;
    my $fileLines_aref    = shift;
    my $checkResults_href = shift;

    my $headerFound;
    S_w2log( 4, "Get_checksum_file_header: Reading header of LIFT checksum file...\n" );

    #LOOP-START loop over all file lines
    foreach my $line (@$fileLines_aref) {

        #STEP extract header key and value if line contains key/value pair
        if ( $line =~ /^\s*(\w+):\s+(.+)$/ ) {
            $headerFound = 1;
            my $key   = $1;
            my $value = $2;
            $value =~ s/\r//g;

            #STEP store key/value pair in $checkResults_href if key is 'Component' or 'Version'
            if ( $key =~ /^(Component|Version)$/ ) {
                $checkResults_href->{$key} = $value;
                S_w2log( 4, "Get_checksum_file_header: header found: $key = $value\n" );
            }
            elsif ( $key =~ /^(Requires)$/ ) {
                if ( $value =~ /(\S+)\s+(>=|=|==)\s*(\S+)/ ) {
                    my $requiresComponent = $1;
                    my $operator          = $2 // '=';
                    my $requiredVersion   = $3;
                    $operator = '==' if $operator eq '=';
                    $checkResults_href->{$key}{$requiresComponent}{Operator} = $operator;
                    $checkResults_href->{$key}{$requiresComponent}{Expected} = $requiredVersion;
                    S_w2log( 4, "Get_checksum_file_header: header found: $key = $requiresComponent $operator $requiredVersion\n" );
                }
                else {
                    S_w2log( 4, "Get_checksum_file_header: WARNING: unknown value ($value) found for key '$key'. This key will be ignored\n" );
                }
            }
            else {
                S_w2log( 4, "Get_checksum_file_header: WARNING: unknown header key found: $key. This key will be ignored\n" );
            }
        }

        #STEP exit loop if first checksum is found in line
        if ( $line =~ /^\s*\w{32}/ ) {
            last;
        }
    }

    #LOOP-END last line?

    #STEP if Component was not found in header then use folder name of checksum file as Component name
    if ( not defined $checkResults_href->{Component} ) {
        my $dirname    = dirname($checksumPath);
        my $foldername = basename($dirname);
        $checkResults_href->{Component} = $foldername;
        S_w2log( 4, "Get_checksum_file_header: no Component info found in header. Using folder name ($foldername) of checksum file as Component name.\n" );
    }

    #STEP set Version as 0 if not defined in header
    $checkResults_href->{Version} = 0 if not defined $checkResults_href->{Version};

    return $headerFound;
}

=head2 Check_checksum_file_checksum

    $checkOK = Check_checksum_file_checksum($checksumPath, $headerFound, $fileLines_aref, $checkResults_href);

If $headerFound is true: Extracts the last line of the checksum file that contains the expected checksum of
the checksum file and calculates the actual checksum of the remaining lines.

Returns 1 if expected checksum == actual checksum or if $headerFound is false. Returns undef otherwise.

=cut

sub Check_checksum_file_checksum {
    my $checksumPath      = shift;
    my $headerFound       = shift;
    my $fileLines_aref    = shift;
    my $checkResults_href = shift;

    #IF header found?
    if ($headerFound) {

        #IF-YES-START

        #STEP extract last line with expected checksum from file lines
        my $checksumFileChecksum = pop @$fileLines_aref;
        chomp $checksumFileChecksum;    # just in case there is an additional newline

        #STEP join remaining file lines to a string
        my $fileRemainingString = join '', map { "$_\n" } @$fileLines_aref;
        chop $fileRemainingString;
        chop $fileRemainingString;      # chop off remaining line feed (2 characters)

        #STEP calculate the actual md5 checksum of the string
        my $md5Checksum = uc( Digest::MD5->new->add($fileRemainingString)->hexdigest );

        #STEP store warning if expected checksum != actual checksum
        if ( $md5Checksum ne $checksumFileChecksum ) {
            push( @{ $checkResults_href->{Warnings} }, "Checksum of LIFT checksum file ($checksumPath) does not match the stored checksum: $checksumFileChecksum. The checksum file is either corrupt or locally modified. $checksumAdvice\n" );
            $checkResults_href->{'OK'} = 0;
            return;
        }

        S_w2log( 4, "Check_checksum_file_checksum: Checksum of LIFT checksum file is OK.\n" );

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP log that no checksum of checksum file will be evaluated
        S_w2log( 4, "Check_checksum_file_checksum: No header found. No checksum of checksum file will be evaluated.\n" );

        #IF-NO-END
    }

    #STEP end
    return 1;
}

=head2 Check_list_entry_checksum

    $checkOK = Check_list_entry_checksum($line, $componentRootPath, $checkResults_href, $checkedFiles_aref);

Gets expected checksum and relative file path from $line. Calculates actual checksum for file.

Returns 1 if expected checksum == actual checksum, undef otherwise.

=cut

sub Check_list_entry_checksum {
    my $line              = shift;
    my $componentRootPath = shift;
    my $checkResults_href = shift;
    my $checkedFiles_aref = shift;

    #STEP get expected checksum and relative file path from line
    my ( $expectedChecksum, $fileRelPath );
    if ( $line =~ /^\s*(\w{32})\s+\*([^\s]+)/ ) {
        $expectedChecksum = $1;
        $fileRelPath      = $2;
    }
    else {
        return;
    }

    my $fileFullPath = $componentRootPath . '/' . $fileRelPath;

    #STEP skip check if file has been checked before
    my $fileBasename = basename($fileRelPath);
    foreach my $checkedFile (@$checkedFiles_aref) {
        if ( basename($checkedFile) eq $fileBasename ) {
            S_w2log( 5, "Check_list_entry_checksum: TurboLIFT file '$fileFullPath' was already checked in a previous checksum file.\n" );
            return;
        }
    }

    #STEP check if file exists on disk
    unless ( -f $fileFullPath ) {
        push( @{ $checkResults_href->{'NotExistFiles'} }, $fileFullPath );
        S_w2log( 5, "Check_list_entry_checksum: WARNING: TurboLIFT file '$fileFullPath' does not exist.\n" );
        return;
    }

    #STEP calculate checksum of file on disk
    my $fh2;
    unless ( open( $fh2, '<', $fileFullPath ) ) {
        push( @{ $checkResults_href->{Warnings} },             "Can't open '$fileFullPath' for checksum calculation: $!. $checksumAdvice" );
        push( @{ $checkResults_href->{'WrongChecksumFiles'} }, $fileFullPath );
        return;
    }
    binmode($fh2);
    my $detectedChecksum = uc( Digest::MD5->new->addfile($fh2)->hexdigest );
    close $fh2;

    push( @{ $checkResults_href->{'AllFiles'} }, $fileFullPath );

    #STEP compare calculated checksum with checksum from list
    if ( $detectedChecksum ne $expectedChecksum ) {
        push( @{ $checkResults_href->{'WrongChecksumFiles'} }, $fileFullPath );
        S_w2log( 5, "Check_list_entry_checksum: WARNING: TurboLIFT file '$fileFullPath' has wrong checksum: $expectedChecksum.\n" );
        return;
    }

    S_w2log( 5, "Check_list_entry_checksum: TurboLIFT file '$fileFullPath' has correct checksum $expectedChecksum.\n" );
    return 1;
}

=head2 Evaluate_checksum_checks

    $componentOK = Evaluate_checksum_checks($checkResults_href);

Evaluates $checkResults_href and stores warnings if any files did not exist or any checksums were wrong.

Returns 1 if all checks are OK, 0 otherwise.

=cut

sub Evaluate_checksum_checks {
    my $checkResults_href = shift;

    #STEP throw warning if any files did not exist
    my $componentOK      = 1;
    my $warningTextStart = "Evaluate_checks: The following files of TurboLIFT component '$checkResults_href->{Component}' version '$checkResults_href->{Version}'";
    my @notExistFiles    = @{ $checkResults_href->{'NotExistFiles'} };
    if ( @notExistFiles > 0 ) {
        my $warningText = $warningTextStart . " do not exist in the current sandbox. $checksumAdvice\n";
        foreach my $file (@notExistFiles) {
            $warningText .= "    $file\n";
        }
        push( @{ $checkResults_href->{Warnings} }, $warningText );
        $componentOK = 0;
    }

    #STEP throw warning if any checksums were wrong
    my @wrongChecksumFiles = @{ $checkResults_href->{'WrongChecksumFiles'} };
    if ( @wrongChecksumFiles > 0 ) {
        my $warningText = $warningTextStart . " have a wrong checksum in the current sandbox (wrong version or locally modified). $checksumAdvice\n";
        foreach my $file (@wrongChecksumFiles) {
            $warningText .= "    $file\n";
        }
        push( @{ $checkResults_href->{Warnings} }, $warningText );
        $componentOK = 0;
    }

    $checkResults_href->{'OK'} = $componentOK;

    return $componentOK;
}

=head2 Get_checksumResultsAll

    $checksumResultsAll_href = Get_checksumResultsAll();

Returns global variable $checksumResultsAll_href for use in e.g. S_get_LIFT_component_version.

=cut

sub Get_checksumResultsAll {
    return $checksumResultsAll_href;
}

=head2 Check_dependent_components

    $success = Check_dependent_components();

Checks in $checksumResultsAll_href if dependencies of components (keyword "Requires") are fulfilled.

Returns 1 if all dependencies are OK, 0 otherwise.

=cut

sub Check_dependent_components {
    my $allDependenciesOK = 1;

    S_w2log( 4, "Check_dependent_components: Checking if dependencies between components are fulfilled...\n" );

    #LOOP-START loop over all components in checksum results
    foreach my $component ( keys %{ $checksumResultsAll_href->{Components} } ) {
        S_w2log( 4, "Check_dependent_components: Checking dependencies for component '$component'...\n" );
        my $componentResult_href = $checksumResultsAll_href->{Components}{$component};

        #IF component has dependencies on other components?
        if ( defined $componentResult_href->{Requires} ) {

            #IF-YES-START
            #LOOP-START loop over dependent components
            foreach my $dependentComponent ( keys %{ $componentResult_href->{Requires} } ) {

                #STEP evaluate if the dependent component is OK with respect to checksums
                my $operator        = $componentResult_href->{Requires}{$dependentComponent}{Operator};
                my $expectedVersion = $componentResult_href->{Requires}{$dependentComponent}{Expected};
                my $actualVersion   = $checksumResultsAll_href->{Components}{$dependentComponent}{Version};
                $componentResult_href->{Requires}{$dependentComponent}{Actual} = $actualVersion;
                my $evalExpression = "$actualVersion $operator $expectedVersion";
                my $resultText     = "Check_dependent_components: Component '$component' requires component '$dependentComponent' $operator $expectedVersion ...\n";
                my $evalOK         = eval $evalExpression;
                $componentResult_href->{Requires}{$dependentComponent}{OK} = $evalOK;
                $resultText .= "Check_dependent_components: Actual version of component '$dependentComponent' is $actualVersion :";

                #STEP store warning if dependent component is not OK
                if ($evalOK) {
                    S_w2log( 4, "$resultText OK\n" );
                }
                else {
                    $resultText .= " >>> NOT OK <<<.\n $checksumAdvice Additionally make sure that all used components have the required version.\n";
                    S_w2log( 4, $resultText );
                    push( @{ $componentResult_href->{Warnings} }, $resultText );
                    $allDependenciesOK = 0;
                }
            }

            #LOOP-END last dependent component?
            #IF-YES-END
        }

        #IF-NO-START
        #IF-NO-END
    }

    #LOOP-END last component?

    #STEP return 1 if all dependencies are OK
    return $allDependenciesOK;
}

=head2 ProcessServerMode

    ProcessServerMode();

A REST server (= dancer) is set up in this function that will listen for requests on http port 3000.

Requests as defined below will be processed.

The dancer will never exit and has to be killed if TurboLIFT shall be quit.

=cut

sub ProcessServerMode {

    $opt_silent = 1;
    my $testcases_href  = {};
    my $executions_href = {};
    my $reports_href    = {};
    my $codelines_href  = {};
    my $clients_href    = {};
    my $tranfer_href    = { tcStartAfterIndex => 0, };

    # http://localhost:3000/testcases/1?name=tc2.VERDICT_FAIL
    # http://localhost:3000/testcases/1?name=tc2.VERDICT_PASS
    # {"TC_PARAMETER" : { "verdict" : { "SCALAR" : "VERDICT_PASS"}}}
    # http://localhost:3000/testcases/1?name=TC_SMI7xy_CCVT_eval.ay_DaimlerMRA2AB12
    # http://localhost:3000/testcases/2?name=TC_SMI7xy_result_overview
    # http://localhost:3000/executions/1
    # http://localhost:3000/reports/1
    # http://localhost:3000/codelines/1
    # http://localhost:3000/clients?name=a

    #IF request get '/'
    #IF-YES-START
    #STEP return welcome message
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/' => sub {
        return { message => 'TurboLIFT Rest Server' };
    };

    #IF request get '/testcases'
    #IF-YES-START
    #CALL GetCollection with $testcases_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/testcases' => sub {
        return GetCollection($testcases_href);
    };

    #IF request del '/testcases'
    #IF-YES-START
    #STEP delete $testcases_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    del '/testcases' => sub {
        $testcases_href = {};
        return { message => "Deleted all testcase items" };
    };

    #IF request get '/testcases/:index'
    #IF-YES-START
    #CALL GetItemByIndex with $testcases_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/testcases/:index' => sub {
        return GetItemByIndex( "testcase item", $testcases_href );
    };

    #IF request put '/testcases/:index'
    #IF-YES-START
    #CALL PutTestcaseItem
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    put '/testcases/:index' => sub {
        return PutTestcaseItem($testcases_href);
    };

    #IF request get '/executions'
    #IF-YES-START
    #CALL GetCollection with $executions_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/executions' => sub {
        return GetCollection($executions_href);
    };

    #IF request get '/executions/:index'
    #IF-YES-START
    #CALL GetItemByIndex with $executions_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/executions/:index' => sub {
        return GetItemByIndex( "execution", $executions_href );
    };

    #IF request put '/executions/:index'
    #IF-YES-START
    #CALL PutExecutionItem
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    put '/executions/:index' => sub {
        return PutExecutionItem( $executions_href, $testcases_href, $tranfer_href );
    };

    #IF request get '/reports'
    #IF-YES-START
    #CALL GetCollection with $reports_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/reports' => sub {
        return GetCollection($reports_href);
    };

    #IF request get '/reports/:index'
    #IF-YES-START
    #CALL GetItemByIndex with $reports_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/reports/:index' => sub {
        return GetItemByIndex( "report", $reports_href );
    };

    #IF request put '/reports/:index'
    #IF-YES-START
    #CALL PutReportItem
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    put '/reports/:index' => sub {
        return PutReportItem( $reports_href, $executions_href, $tranfer_href );
    };

    #IF request get '/codelines'
    #IF-YES-START
    #CALL GetCollection with $codelines_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/codelines' => sub {
        return GetCollection($codelines_href);
    };

    #IF request get '/codelines/:index'
    #IF-YES-START
    #CALL GetItemByIndex with $codelines_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/codelines/:index' => sub {
        return GetItemByIndex( "codelines", $codelines_href );
    };

    #IF request put '/codelines/:index'
    #IF-YES-START
    #CALL PutCodelineItem
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    put '/codelines/:index' => sub {
        return PutCodelineItem($codelines_href);
    };

    #IF request post '/shutdown'
    #IF-YES-START
    #STEP commit suicide
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    post '/shutdown' => sub {
        my $ownPID = $$;
        debug("TurboLIFT Server: received shutdown command, committing suicide...");
        Win32::Process::KillProcess( $ownPID, 0 );
    };

    #IF request get '/clients'
    #IF-YES-START
    #CALL GetCollection with $clients_href
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    get '/clients' => sub {
        return GetCollection($clients_href);
    };

    #IF request post '/clients'
    #IF-YES-START
    #CALL PostClient
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    post '/clients' => sub {
        return PostClient($clients_href);
    };

    #IF request del '/clients'
    #IF-YES-START
    #CALL DeleteClient
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    del '/clients' => sub {
        return DeleteClient($clients_href);
    };

    #STEP start dancer (will run an infinite loop)
    dance;
    return;    # will never be reached
}

sub GetCollection {

    #STEP get argument $collection_href
    my $collection_href = shift;

    #STEP return keys of $collection_href
    my @items = sort keys %$collection_href;
    return \@items;
}

sub GetItemByIndex {
    my $name = shift;

    #STEP get argument $collection_href
    my $collection_href = shift;

    #STEP get index from request parameter
    my $index = params->{index};

    #IF key index is defined in $collection_href?
    if ( defined $collection_href->{$index} ) {

        #IF-YES-START
        #STEP return value of key index
        return $collection_href->{$index};

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #STEP return error message
        status "Forbidden";
        return { message => "$name with index $index does not exist" };

        #IF-NO-END
    }

    #STEP end
}

sub PutTestcaseItem {

    #COMMENT-START
    #Structure of $testcases_href:
    #$testcases_href = {
    #    <index> => {
    #        name => <name>,
    #        TC_PARAMETER => { # optional
    #            <parameter1 name> => { <type1> => <value1>},
    #            <parameter2 name> => { <type2> => <value2>},
    #            ...
    #        },
    #    },
    #    ...
    #}
    #COMMENT-END
    my $testcases_href = shift;

    #STEP get index and name from request parameter
    my $index = params->{index};
    my $name  = params->{name};

    #STEP return error message if name is not defined
    if ( not defined $name ) {
        status "Forbidden";
        return { message => "Parameter 'name' not given" };
    }

    #STEP get parameter from request body
    my $params_JSON = request->body;

    #CALL ParamsJSON2href to convert JSON parameter to hash
    my $params_href = ParamsJSON2href($params_JSON);
    if ( defined $params_href->{error} ) {
        my $message = $params_href->{error};
        status "Forbidden";
        return { message => $message };
    }

    #STEP create new element in $testcases_href with index and name
    $testcases_href->{$index} = { name => $name, };

    #STEP Add parameter hash (TC_PARAMETER) to new element if defined
    if ( defined $params_href->{TC_PARAMETER} ) {
        $testcases_href->{$index}{TC_PARAMETER} = $params_href->{TC_PARAMETER};
    }

    #STEP return success message
    my $message = "Created testcase item with index = $index   name = $name";
    debug("TurboLIFT Server: $message");
    return { message => $message };
}

sub ParamsJSON2href {
    my $params_JSON = shift;

    return if ( not defined $params_JSON ) or ( $params_JSON eq '' );

    #STEP decode JSON string to a Perl hash
    my $decodeCommand = 'my $eval = decode_json($params_JSON)';
    my $params_href   = eval $decodeCommand;                      # using eval to avoid a crash if the string is not a proper JSON string

    #STEP return error message if decoding was not successful
    unless ($params_href) {
        $params_href->{error} = $@;
        return $params_href;
    }

    #STEP return error message if decoded hash does not have a key TC_PARAMETER
    if ( not defined $params_href->{TC_PARAMETER} ) {
        $params_href = { error => "request body hash did not have a key 'TC_PARAMETER'", };
        return $params_href;
    }

    #STEP return decoded hash
    return $params_href;
}

sub PutExecutionItem {

    #COMMENT-START
    #Structure of $executions_href:
    #$executions_href = {
    #    <index> => {
    #        "testcases" => {
    #            0 => {
    #                report_index => 'IC',
    #                verdict => <init campaign verdict>,
    #                ALL_TC => { ... },
    #            },
    #            1 => {
    #                report_index => <index in report>,
    #                verdict => <testcase verdict>,
    #                ALL_TC => { ... },
    #            },
    #            2 => { ... },
    #            ...
    #        },
    #        execution_verdict => <consolidated verdict>,
    #    },
    #    ...
    #}
    #COMMENT-END
    my $executions_href = shift;
    my $testcases_href  = shift;
    my $tranfer_href    = shift;

    #STEP get index from request parameter
    my $executionIndex = params->{index};

    #STEP return message if execution_verdict already exists for index
    my $executionVerdict = $executions_href->{$executionIndex}{execution_verdict};
    if ( defined $executionVerdict ) {
        return { message => "Execution item with index = $executionIndex already run. Verdict is $executionVerdict" };
    }

    #STEP get results from IC
    my $ic_verdict = $all_TC_IC{TC_VERDICT};
    $executions_href->{$executionIndex}{testcases}{0}{report_index} = 'IC';
    $executions_href->{$executionIndex}{testcases}{0}{ALL_TC}       = \%all_TC_IC;
    $executions_href->{$executionIndex}{testcases}{0}{verdict}      = $ic_verdict;

    #STEP return error message if verdict of IC is not PASS
    if ( $ic_verdict ne 'VERDICT_PASS' ) {
        $executions_href->{$executionIndex}{execution_verdict} = $ic_verdict;
        status "Forbidden";
        return { message => "Execution aborted because IC is not PASS" };
    }

    my $tcStartAfterIndex = $tranfer_href->{tcStartAfterIndex};

    #CALL ExecuteTestsFromServer
    $tranfer_href->{execution_start_time} = time() if not defined $tranfer_href->{execution_start_time};
    $tranfer_href->{max_nr} = ExecuteTestsFromServer( $executions_href->{$executionIndex}, $testcases_href, $tcStartAfterIndex );
    $tranfer_href->{tcStartAfterIndex} = $tranfer_href->{max_nr};

    $executionVerdict = $executions_href->{$executionIndex}{execution_verdict};

    #STEP return success message
    return { message => "Created new execution with index = $executionIndex. Verdict is $executionVerdict" };
}

sub ExecuteTestsFromServer {
    my $executionItem_href = shift;
    my $testcases_href     = shift;
    my $tcStartAfterIndex  = shift;

    my $parameters_from_server_href;

    #STEP create test list string from names in $testcases_href
    debug("TurboLIFT Server: Building test list...\n");
    my $testListString;
    foreach my $index ( sort keys %{$testcases_href} ) {
        my $testcaseID = $testcases_href->{$index}{name};
        debug("TurboLIFT Server:    Adding test case $testcaseID to test list.\n");
        $testListString .= "$testcaseID\n";

        if ( defined $testcases_href->{$index}{TC_PARAMETER} ) {
            $parameters_from_server_href->{$testcaseID} = $testcases_href->{$index}{TC_PARAMETER};
        }
    }

    #STEP write test list string to test list file
    open my $testlistFH, '>>', $opt_testlist or die "Could not open test list file '$opt_testlist' $!";
    print $testlistFH $testListString;
    close $testlistFH;

    #CALL Read_testlist
    my $max_nr = Read_testlist($parameters_from_server_href);

    #CALL Read_all_parameter
    Read_all_parameter( $LIFT_config::LIFT_PROJECT_PARAMETER_file, $parameters_from_server_href );

    #CALL ProcessTestCases
    debug("TurboLIFT Server: Executing testcases...\n");
    ProcessTestCases( $max_nr, 0, $tcStartAfterIndex );

    #CALL Write_result_summary_to_logs
    Write_result_summary_to_logs();

    my $runningNumber    = 0;
    my $executionVerdict = VERDICT_NONE;

    #LOOP-START loop over all testcases in $testcases_href
    foreach my $index ( sort keys %{$testcases_href} ) {
        $runningNumber++;
        my $tc_cnt  = $runningNumber + $tcStartAfterIndex;
        my $verdict = $ALL_TC->{$tc_cnt}{TC_VERDICT};
        $executionVerdict = S_determine_overall_verdict( $executionVerdict, $verdict );

        #STEP set report_index, ALL_TC and verdict of $executions_href for the testcase
        $executionItem_href->{testcases}{$index}{report_index} = $tc_cnt;
        $executionItem_href->{testcases}{$index}{ALL_TC}       = $ALL_TC->{$tc_cnt};
        $executionItem_href->{testcases}{$index}{verdict}      = $verdict;
    }

    #LOOP-END last testcase?

    #STEP determine overall verdict of all testcases and store it as execution_verdict of $executions_href
    $executionItem_href->{execution_verdict} = $executionVerdict;

    debug("TurboLIFT Server: Execution finished. Verdict is $executionVerdict.\n");

    return $max_nr;
}

sub PutReportItem {

    #COMMENT-START
    #Structure of $reports_href:
    #$reports_href = {
    #    <index> => {
    #        report_html => "<path to report folder>\\_main__result.html",
    #        report_verdict => <consolidated report verdict>,
    #    },
    #    ...
    #}
    #COMMENT-END
    my $reports_href    = shift;
    my $executions_href = shift;
    my $tranfer_href    = shift;

    #STEP get index from request parameter
    my $index = params->{index};

    my $execution_end_time = time();

    #CALL Close_all_logs
    Close_all_logs( $tranfer_href->{execution_start_time}, $execution_end_time, $tranfer_href->{max_nr} );

    #STEP Set report_html of $reports_href
    $reports_href->{$index}{report_html} = File::Spec->rel2abs( $save_name . '/' . $main_LOG_name );

    #STEP determine overall verdict of all executions and store it as report_verdict of $reports_href
    my $reportVerdict = VERDICT_NONE;
    foreach my $executionIndex ( keys %{$executions_href} ) {
        if ( not defined $executions_href->{$executionIndex}{report_html} ) {
            $executions_href->{$executionIndex}{report_html} = $reports_href->{$index}{report_html};
            my $executionVerdict = $executions_href->{$executionIndex}{execution_verdict};
            $reportVerdict = S_determine_overall_verdict( $reportVerdict, $executionVerdict );
        }
    }

    $reports_href->{$index}{report_verdict} = $reportVerdict;

    $tranfer_href->{execution_start_time} = time();
    $save_name                            = undef;
    $ALL_VERDICTS->{'TOTAL_EXECUTED_TC'}  = {
        VERDICT_PASS    => 0,
        VERDICT_FAIL    => 0,
        VERDICT_INCONC  => 0,
        VERDICT_BLOCKED => 0,
        VERDICT_NONE    => 0,
    };

    #CALL open_all_logs
    open_all_logs( $tranfer_href->{execution_start_time} );

    #STEP return success message
    debug("TurboLIFT Server: Created new report with index = $index");
    return { message => "Created new report with index = $index" };
}

sub PutCodelineItem {

    #COMMENT-START
    #Structure of $codelines_href:
    #$codelines_href = {
    #    <index> => {
    #        code => <code lines>,
    #        return_value => <return value of executed code>,
    #    },
    #    ...
    #}
    #COMMENT-END
    my $codelines_href = shift;

    #STEP get index from request parameter
    my $index = params->{index};

    #STEP get code lines from request body
    my $code = request->body;

    #STEP execute code lines and get return value
    my $returnValue = eval $code;

    #STEP store code and return_value in $codelines_href
    $codelines_href->{$index}{code}         = $code;
    $codelines_href->{$index}{return_value} = $returnValue;

    #STEP return success message
    return { message => "Executed code with index = $index   code = $code   return value = $returnValue" };
}

sub PostClient {

    #COMMENT-START
    #Structure of $clients_href:
    #$clients_href = {
    #    1 => {
    #        name => <name>,
    #    },
    #}
    #COMMENT-END
    my $clients_href = shift;

    #STEP get name from request parameter
    my $name = params->{name};

    #STEP return error message if name is not defined
    if ( not defined $name ) {
        status "Forbidden";
        return { message => "Parameter 'name' not given" };
    }

    my $otherClient;
    if ( defined $clients_href->{1} ) {
        $otherClient = $clients_href->{1}{name};
    }

    #STEP return error message if another client is already registered
    if ( defined $otherClient and $otherClient ne $name ) {
        status "Forbidden";
        return { message => "Another client is already registered on the server" };
    }

    #STEP register client with given name
    $clients_href->{1}{name} = $name;

    return { message => "Client successfully registered on the server with name = '$name'" };
}

sub DeleteClient {

    my $clients_href = shift;

    #STEP get name from request parameter
    my $name = params->{name};

    #STEP return error message if name is not defined
    if ( not defined $name ) {
        status "Forbidden";
        return { message => "Parameter 'name' not given" };
    }

    my $otherClient;
    if ( defined $clients_href->{1} ) {
        $otherClient = $clients_href->{1}{name};
    }

    #STEP unregister client with given name if it is registered
    if ( defined $otherClient and $otherClient eq $name ) {
        delete $clients_href->{1};
        return { message => "Client with name '$name' is no more registered on the server" };
    }

    return { message => "Client with name '$name' is not registered on the server" };
}

1;
