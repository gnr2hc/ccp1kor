#!usr\bin\perl -w

use strict;
use Tk;

# TK vars:
my ($main,$mainlevel,$F1,$F2,$F1_1,$F1_2,$F1_3,$menubar,$start_button);

#
# optional flags
#
my $minimalsnapshot_flag = " ";
my $offline_flag = " ";
my $beep_flag = " "; 

#
# mandatory options pre-defined
#
my $opt_conf="Configuration File Path";
my $opt_testlist="Testlist File Path";

# my $homepage = 'http://si-airbag-web.de.bosch.com/support/testportal/common/LIFT/';
my $homepage = 'http://si-airbag-web.de.bosch.com/support/testportal/common/LIFT/APIdocumentation/latest/index.html';
my $browser_call = 'C:\PROGRA~2\MOZILL~1\firefox.exe';

my $LIFT_logo = "./modules/Common_library/LifT_logo_32x32.bmp";

LIFT_init();
MainLoop;

###------------------------------------------------------------------
### LIFT_init
###------------------------------------------------------------------
sub LIFT_init {

    ###------------------------------------------------------------------
    ### create main window 'main'
    ###------------------------------------------------------------------
    # create main window 'main'
    $main = MainWindow -> new();

    $main -> geometry("+200+200");

    # define minimum size of main window 'main'
    $main -> minsize(400,200);

    # create title in main window 'main'
    $main -> title
      ( " LIFT GUI" );
    my $iconImage = $main->Photo( -file => $LIFT_logo );
    $main-> Icon(-image => $iconImage);

    ###------------------------------------------------------------------
    ### create menubar in main window 'main'
    ###------------------------------------------------------------------
    $mainlevel = $main -> toplevel;
    $menubar = $main -> Menu("-type" => 'menubar');
    $mainlevel -> configure ("-menu" => $menubar);

    ###------------------------------------------------------------------
    ### create help menu in menubar
    ###------------------------------------------------------------------

    $menubar -> command(
               "-label" => '~Homepage',
               "-command" => sub{ system($browser_call." $homepage") },
    );

    ###------------------------------------------------------------------
    ### create frame 'F1' in main window 'main'
    ###------------------------------------------------------------------
    $F1 = $main -> Frame
    -> pack
      (
      "-side"   => 'top',
      "-expand" => 1,
      "-fill"   => 'both',
      );

    ###------------------------------------------------------------------
    ### create frame 'F2' in main window 'main'
    ###------------------------------------------------------------------
    $F2 = $main -> Frame
    -> pack
      (
      "-side"   => 'bottom',
      "-fill"   => 'x',
      );

    ###------------------------------------------------------------------
    ### write head line in frame 'F1'
    ###------------------------------------------------------------------
    $F1 -> Label
      (
      "-text" => 'Initializing System',
      "-font" => "{MS Sans Serif} 15 bold",
      )
    -> pack ("-side"   => "top");

    ###------------------------------------------------------------------
    ### create exit and start buttons in frame 'F2'
    ###------------------------------------------------------------------
    $F2 -> Button
      (
      "-text"    => "Exit",
      "-font" => "{MS Sans Serif} 15 bold",
      "-background" => "red",
      "-command" => sub
        {exit}
      )
    -> pack
      (
      "-side"  => 'left',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

    $start_button = $F2 -> Button
      (
      "-text"    => "Start",
      "-font" => "{MS Sans Serif} 15 bold",
      "-background" => "green",
      "-command" => sub{
                        ###------------------------------------------------------------------
                        ### check options
                        ###------------------------------------------------------------------
                        if ($opt_testlist and $opt_conf){
                            #execute LIFT_engine
                            #add here the system call
							
                            system "LIFT_exec_engine.pl -testlist $opt_testlist -conf $opt_conf $offline_flag $beep_flag $minimalsnapshot_flag";
                        }
                        else{
                             ###------------------------------------------------------------------
                             ### inform user that options are missing
                             ###------------------------------------------------------------------
                             $main->messageBox (
                              '-icon'    => "error",
                              '-type'    => "OK",
                              '-title'   => 'Error',
                              '-message' => "! not enough options defined !",
                             );
                        }
                    }
      )
    -> pack
      (
      "-side"  => 'right',
      "-pady"  => 20,
      "-padx"  => 20,
      "-ipady" => 5,
      "-ipadx" => 5,
      );

    ###------------------------------------------------------------------
    ### create Frame for choosing test list with label, entry and button
    ###------------------------------------------------------------------
    $F1_1 = $F1 -> Frame
    -> pack
      (
      "-side"   => 'top',
      "-fill"   => 'x',
      );

    $F1_1 -> Label (
       "-text" => "test list:           ",
       "-font" => "{MS Sans Serif} 10 bold",
       )    -> pack ("-side" => 'left');

    $F1_1 -> Entry (  "-textvariable" => \$opt_testlist , )
    -> pack
       (
       "-side"   => 'left',
       "-fill"   => 'x',
       "-expand" => 1,
       );

    # create 'browse file' button
    $F1_1 -> Button       (
      "-text" => "Browse...",
      "-font" => "{MS Sans Serif} 10 bold",
      "-command" => sub{
                        my $previous_value = $opt_testlist;       # store old value
                        $opt_testlist = $main -> getOpenFile (
                            "-filetypes"  => [ ["text files", '.txt'], ["All files", '.*'] ],
                            "-title"      => "test list for LIFT ececution engine" ,
                            "-initialdir" => '.\testlists',
                        );
                        unless ($opt_testlist) {$opt_testlist = $previous_value;} # if no new value, restore old one
                    },
      )
    -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 10,"-padx" => 5,);

    ###------------------------------------------------------------------
    ### create Frame for choosing configuration with label, entry and button
    ###------------------------------------------------------------------
    $F1_2 = $F1 -> Frame
    -> pack
      (
      "-side"   => 'top',
      "-fill"   => 'x',
      );

    $F1_2 -> Label (
      "-text" => "configuration: ",
      "-font" => "{MS Sans Serif} 10 bold",
      )
    -> pack ("-side"   => 'left');

    $F1_2 -> Entry (  "-textvariable" => \$opt_conf , )
    -> pack
       (
       "-side"   => 'left',
       "-fill"   => 'x',
       "-expand" => 1,
       );

    # create 'browse file' button
    $F1_2 -> Button
      (
      "-text" => "Browse...",
      "-font" => "{MS Sans Serif} 10 bold",
      "-command" => sub{
                        my $previous_value = $opt_conf;       # store old value
                        $opt_conf = $main -> getOpenFile (
                            "-filetypes"  => [ ["perl module", '.pm'], ["All files", '.*'] ],
                            "-title"      => "configuration for LIFT ececution engine" ,
                            "-initialdir" => '.\configs',
                        );
                        unless ($opt_conf) {$opt_conf = $previous_value;} # if no new value, restore old one
                    },
      )
    -> pack ("-side"   => 'right',"-ipadx" => 5,"-ipady" => 2,"-pady" => 10,"-padx" => 5,);

    ###------------------------------------------------------------------
    ### create Frame for choosing verbose level and debug mode
    ###------------------------------------------------------------------
    $F1_3 = $F1 -> Frame
    -> pack
      (
      "-side"   => 'top',
      "-fill"   => 'x',
      );

     $F1_3 ->Checkbutton(
       "-text" => "run in offline mode",
       "-font" => "{MS Sans Serif} 10 bold",
       "-onvalue" => "-offline",
       "-offvalue" => " ",
       "-variable" => \$offline_flag,
      )
     ->pack(-side => "left");

     $F1_3 ->Checkbutton(
       "-text" => "minimalsnapshot",
       "-font" => "{MS Sans Serif} 10 bold",
       "-onvalue" => "-minimalsnapshot",
       "-offvalue" => " ",
       "-variable" => \$minimalsnapshot_flag,
      )
     ->pack(-side => "right");

     $F1_3 ->Checkbutton(
       "-text" => "run with beep",
       "-font" => "{MS Sans Serif} 10 bold",
       "-onvalue" => "-beep",
       "-offvalue" => " ",
       "-variable" => \$beep_flag,
      )
     ->pack(-side => "right");

}

