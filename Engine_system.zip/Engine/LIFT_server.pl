#################################################################################
my $VERSION = 'SCM';
#################################################################################

BEGIN
{
    # add directories to search path for perl modules    
    use Config;
    use File::Spec;
    use File::Basename;
    my $LIFT_exec_path=File::Spec->rel2abs(dirname(__FILE__)) ;

    # add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/";
	# add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/Common_library";
    unshift @INC, "$LIFT_exec_path/modules/Functional_layer";
    unshift @INC, "$LIFT_exec_path/modules/Convenience_layer";
    unshift @INC, "$LIFT_exec_path/funclib_generic";

    my $deviceLayerDir = "$LIFT_exec_path/modules/Device_layer";
    unshift @INC, $deviceLayerDir;
    opendir my $dh, $deviceLayerDir or die "$0: opendir: $!";
    # get all sub-directories which are not . or ..
    my @subDirs = grep {-d "$deviceLayerDir/$_" && ! /^\.{1,2}$/} readdir($dh);
    #print "Device layer dirs: @subDirs\n";
    foreach my $subDir ( @subDirs ) {
        unshift @INC, "$deviceLayerDir/$subDir";
    }
}

=head1 NAME

LIFT_server - Perl server for interactive LIFT control

=head1 SYNOPSIS

just start the server by doubleclick: TCP port 9000

use e.g. LIFT_shell to connect to server

=head1 DESCRIPTION

=head2 any LIFT command

any of the LIFT commands will be executed and values (with verdict added first) returned as text. See docu for commands and return values.

	e.g. request 'TSG4_SetVoltage( 'U_BATT_DEFAULT' )' will get response 'VERDICT_NONE' if executed successfully
	     request 'TSG4_lowlevel_command("rc_get_firmware(1)")) will get response 'VERDICT_NONE',0,'FW_X0013' if executed successfully

=for html
<a href='..\..\..\Engine\Documentation\index.html' target="blank">link to LIFT docu</a><br>



=head2 server requests

 on request 'PING' you will get 'PONG' response
 
 on request 'ServerVersion' you will get e.g. 'Revision: 1.5 ' response

 on request 'ServerSetOffline($NewValue)' server will set offline mode and return new value e.g. 'offline = 1'

 on request 'ServerSetSimulation($NewValue)' server will set simulation mode and return new value e.g. 'simulation = 1'

 on request 'ServerLoadLIFTconfig($configfile)' the LIFT configuration will be loaded. THIS HAS TO BE DONE FIRST !

 loads automatically 
 LIFT_general
 LIFT_TSG4
 LIFT_POWER
 LIFT_stub
 LIFT_DMM1
 LIFT_PD
 LIFT_POWER
 LIFT_QuaTe
 LIFT_simulation



 in case you need additional modules you can just load them by calling e.g. 'use LIFT_DSO1'

=head2 error

on error, server will return '! error:' and system error message


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, LIFT module documentation

=cut 


use strict;
use warnings;
use Data::Dumper;
use JSON;

use LIFT_general;
use LIFT_TSG4;
use LIFT_POWER;
use LIFT_stub;
use LIFT_DMM1;
use LIFT_PD;
use LIFT_POWER;
use LIFT_QuaTe;
use LIFT_simulation;

$Data::Dumper::Indent = 0; # all in one line
$Data::Dumper::Sortkeys = 1;

our $ProjectDefaults; # to be configured by load_config($cgf_file);
our $opt_simulation = 0; # $opt_simulation = 1; # set simulation mode#
our $opt_offline = 0; # $opt_offline = 1; # set offline mode
our $opt_silent = 0; # $opt_silent = 1; # set silent mode (logging will not print)
our $save_name; # name of log/report/result-files, given from user or Testlist will be taken
our $CURRENT_TC = 'LIFTserver';

our $opt_conf; # lift cfg file to load
our $REPORT_PATH = File::Spec->rel2abs(dirname(__FILE__));

my ($SOCKET,$PORT,$timeout,$Connect_Count);

my ($stat,$ERRORflag);
my $str='';
$ERRORflag=0;
system("Color 0E");
open ( LOG, ">LIFT_server_log.txt" );     # open shell logfile
select((select(LOG), $|=1)[0]);       # Make LOG hot.(autoflush)

w2log( "LIFT_server $VERSION logfile\n\n");
w2log("\n*** LIFT_server started ***\n\n");

#execute loop only if no error
if ($ERRORflag == 0){
    until (lc($str) eq "exit"){
        Open_socket_Connection();
        my $loopcount = 0;
        $str="";
        until (lc($str) eq "restart") {
            #$loopcount++;
            $str = Read_socket();
            last if ($str =~ /\bexit\b|\brestart\b/i);
            {
             no warnings; # bad hack to exit loop on error
             exec_command($str) or ($str='exit' and last);
            }
        }

        Close_socket_Connection();

        w2log("perl: connection closed\n");

    }

}


w2log("\n*** LIFT_server stopped ***\n\n");

close (LOG);
#system('pause');

################
#  subroutines
################


sub w2log{
    my $text = shift;
    print LOG "$text";
    print "$text";
}

sub exec_command{
    my $command = shift;
    
    if($command eq ""){
    }
    elsif ($command eq "ServerVersion"){
        w2log("$VERSION\n");
        Write_socket($VERSION);
    }
    elsif ($command  =~ /^ServerSetOffline\((\d+)\)/){
    	my $new_val = $1;
        w2log("change offline from $opt_offline to $new_val\n");
        $opt_offline = $new_val;
        Write_socket( "offline = $opt_offline");
    }
    elsif ($command  =~ /^ServerSetSimulation\((\d+)\)/){
    	my $new_val = $1;
        w2log("change simulation from $opt_simulation to $new_val\n");
        $opt_simulation = $new_val;
        Write_socket( "simulation = $opt_simulation");
    }
    elsif ($command eq "PING"){
        w2log("playing ping pong\n");
		Write_socket("PONG");
    }
    elsif ($command =~ /^ServerLoadLIFTconfig\((.+)\)/){
    	my $cgf_file = $1;
    	$cgf_file =~ s/('|")//g; # remove all quotes if any
		my $config = load_config($cgf_file);
		Write_socket($config);

    }
     else{
        # execute $command as perl copmmand and get return values
        STUB_reset();
        my @result = eval($command);
        my ($val,$response);
        $response='';
        if ($@){
        	my $error = $@;
        	$error =~ s/\n/ /g;
        	
        	w2log("! error: $error\n");Write_socket("! error: $error");
        }
        else{
	        #check if at least one return value was there
#	        if (defined ($result[0])) {
#	        	print"result0 <$result[0]> ".length($result[0])."\n";
	        	#add verdict as first element
	        	if (scalar(@result) == 0){
	        		$result[0] = S_get_current_verdict();
	        	}
	        	else{
	                my $verdict = S_get_current_verdict();
	                unshift(@result,$verdict);
	        	}
	        	
			    $Data::Dumper::Sortkeys = 1;
			    $Data::Dumper::Varname = "LIFT";
	            foreach $val (@result){
			        my $out = Dumper($val);
			    ###    
			        $out =~ s/^\$LIFT1 = //; # remove leading variable from dumper
			        chomp ($out);	# remove trailing newline if any
			        $out =~ s/\;$//;	# remove trailing ; if any
			        if($out =~ /\S+/){ # only append if not only whitespaces or empty
			            print "out <$out>\n";
			        	$response.="$out,";
			        }
	            }
	            $response =~ s/,$//; # cut off trailing comma
				Write_socket("$response");
				w2log(" $response = $command \n")            
#	        }
#	        else {w2log("? unknown command: $command or timeout\n");Write_socket("? unknown command or timeout");}
        }
    }

}

sub init{
    my ($errorcount);
    $errorcount = 0;
	w2log("handshake\n");
}

sub load_config{
    $opt_conf= shift;;
    w2log("loading LIFT configuration $opt_conf\n");
    eval "require '$opt_conf'";
    if ($@){
        	my $error = $@;
        	$error =~ s/\n/ /g;
        	w2log("! error: $error\n");
        	Win32::MsgBox( "$error", ( 0 + 32 ), 'load config error' );
    }
    $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
	my $TSG4_json = to_json( $ProjectDefaults->{'TSG4'} );

	return $TSG4_json;
}



sub check_status{
    my $status = shift;

    if ($status<0){
      my $errortext = pd_GetErrorString($status);
      w2log( "LIFT server error ($status): $errortext\n");
      $ERRORflag++;
    }

}


sub Open_socket_Connection{
    use IO::Socket;
    use Net::hostent;               # for OO version of gethostbyaddr
    # Set up the server object

    $PORT = 9000;
    $timeout = 60000;
    
    my $server = IO::Socket::INET->new(    Proto     => 'tcp',
    #Type => SOCK_STREAM, 
                                        LocalPort => $PORT,
                                        Listen    => SOMAXCONN,
                                        Reuse     => 1,
                                        Timeout   => $timeout);

    die "can't setup TCP server" unless $server;
    
    $Connect_Count++;
    printf "Server port: $PORT Timeout value: $timeout Connect count: $Connect_Count\n";
    
    # Now set up a client filehandle, $SOCKET. This will be a global used in other places
    $SOCKET = $server->accept(); 
    
    $SOCKET->autoflush(1);
    printf "SOCKET connected \n";
    return $SOCKET;
    
}


sub Close_socket_Connection{
    close($SOCKET);
    print"server closed\n";
}

sub Write_socket{ 
my $out = shift;
    if ($SOCKET) 
    {
        print $SOCKET $out."\r\n";      # Send command     
        print "S-> $out\n";
    } 
    else 
    {
        return 0;
    }
    
}


sub Read_socket{
my $in;
    while ($in=<$SOCKET>) 
    {
        next unless $in =~ /\S/;             # ignore blank lines
        $in =~ s/\r\n$//;
        chomp($in);
        print"<-R $in\n";
        return $in;
    }
}

