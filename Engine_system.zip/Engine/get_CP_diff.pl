#!usr\bin\perl

use strict;
use warnings;
use Getopt::Long;

my ($change,@differences,@changes,$cmd,@revisions,$opt_rev);
#compare current working project to last checkpoint

GetOptions(
             "rev=s" => \$opt_rev,    # checkpoint to compare with
);

open(LOG,">CP_changes.txt") or die "could not open file: $! ";

if (defined $opt_rev){
	print LOG "comparing working project with checkpoint $opt_rev\n\n";
	$opt_rev=" -r ".$opt_rev;
}
else{
	$opt_rev='';
	print LOG "comparing working project with last checkpoint\n\n";
	
}
$cmd='si mods -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj'.$opt_rev.' -R';
@differences = MKS_command($cmd);

#system('pause');

#check if no modules are locked
$cmd='si rlog --noHeaderFormat --noTrailerFormat --format="{lockrecord}\n" --lockRecordFormat="{member} {revision} by {locker} on {hostname}" --rfilter=locked -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj -R';
my @locked = MKS_command($cmd);
if ( scalar(@locked) > 0 )
{
    print LOG "!!! detected locked module(s):\n\n";
    print LOG " @locked \n----------------------------------------------------\n\n";
}
    foreach $change (@differences){
        print LOG "#".$change;

        #check for e.g. "Member revision changed: LIFT_exec_engine.pl from 2.6 to 2.11"
        if ($change =~ /^Member revision changed: (\S+) from (\S+)/){
            my $file = $1;
            my $oldrev = $2;

            #get next version number (element n-1 from query)
            $cmd='si rlog --noHeaderFormat --noTrailerFormat --format="{revision}\n" --rfilter=range:'.$oldrev.'- -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj '.$file;
            @revisions =  MKS_command($cmd);
            my $firstnewrev=$revisions[-2]; # this version contains the first change description
            chomp($firstnewrev); #cutt of newline

            #get accumulated revision descriptions from selected version till latest version
            $cmd='si viewhistory --fields=description --rfilter=range:'.$firstnewrev.'- -P G:\MKS\Projects\TurboLIFT\System\Engine\Engine.pj '.$file;
            @changes=  MKS_command($cmd);
            shift(@changes);
            print LOG " @changes";
        }
    }
close(LOG);



###################
### subroutines ###
###################

sub MKS_command{
    my $cmd = shift;
    my @ret;
    
    print "executing <$cmd>\n";
    @ret = `$cmd`;
    
    return @ret;

}