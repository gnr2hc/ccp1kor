use strict;
use warnings;
use Getopt::Long;

our $LIFT_exec_path;
BEGIN
{
    # add directories to search path for perl modules    
    use Config;
    use File::Spec;
    use File::Basename;
    $LIFT_exec_path=File::Spec->rel2abs(dirname(__FILE__)) ;

	print "REPLshell called by $^X\n";

	unless (defined $ENV{TURBOLIFT_PERL_HOME}){
		print "ENVIRONMET VARIABLE %TURBOLIFT_PERL_HOME% not defined\nplease execute Engine/run_once/_run_once.bat !!!\n\7";
		sleep(10);
		exit;
	}	
	if ($^X ne "$ENV{TURBOLIFT_PERL_HOME}\\bin\\perl.exe"){
		print "wrong perl, recalling REPLshell with TURBOLIFT_PERL %TURBOLIFT_PERL_HOME% ...\n";
		system("%TURBOLIFT_PERL_HOME%\\bin\\perl.exe $0 @ARGV");
		print "recalling done\n";
		exit;
	}
	
    # add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/";
	# add directories to search path for perl modules
    unshift @INC, "$LIFT_exec_path/modules/Common_library";
    unshift @INC, "$LIFT_exec_path/modules/Functional_layer";
    unshift @INC, "$LIFT_exec_path/modules/Convenience_layer";
    unshift @INC, "$LIFT_exec_path/funclib_generic";

    my $deviceLayerDir = "$LIFT_exec_path/modules/Device_layer";
    unshift @INC, $deviceLayerDir;
    opendir my $dh, $deviceLayerDir or die "$0: opendir: $!";
    # get all sub-directories which are not . or ..
    my @subDirs = grep {-d "$deviceLayerDir/$_" && ! /^\.{1,2}$/} readdir($dh);
    #print "Device layer dirs: @subDirs\n";
    foreach my $subDir ( @subDirs ) {
        unshift @INC, "$deviceLayerDir/$subDir";
    }

    # support for projects in MKS; shared MKS projects are checked out to the following folders
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_CustLib";
    unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_Project";
	unshift @INC, "$LIFT_exec_path/modules/TC_FunctionLib/TC_TNT";

}

our $ProjectDefaults; # to be configured by load_config($cgf_file);
our $opt_simulation = 0; # $opt_simulation = 1; # set simulation mode#
our $opt_offline = 0; # $opt_offline = 1; # set offline mode
our $opt_silent = 0; # $opt_silent = 1; # set silent mode (logging will not print)
our $save_name; # name of log/report/result-files, given from user or Testlist will be taken
our $CURRENT_TC = 'LIFT_REPL';

our $opt_conf = 'unused'; # lift cfg file to load
our $REPORT_PATH = $LIFT_exec_path.'/REPL_log';

our @LIFT_functions=('load_LIFT_config','help');

use Term::ANSIColor;
use File::Find;
# search all modules and add export array to global array whic will be used by autocompleteion plugin for LIFT function names
find(\&wanted, "$LIFT_exec_path/modules/");

use Devel::REPL;
use LIFT_general;
use LIFT_stub;
use Sys::Hostname;

STUB_init();
my $LIFT_start_time = time();
my ($start_date, $start_time) = S_formated_timestamp($LIFT_start_time);
my $username = getlogin || getpwuid($<) ;
my $LIFT_host = hostname();
my $LIFT_version = '';
my $LIFT_ProjectDescription_html_code = ''; # take from const
@htmlBookmarks = ();
my $scriptfile;

mkdir( $REPORT_PATH );

S_open_log ( $REPORT_PATH.'/LIFT_REPL_shell.html' );

S_w2log(1,"LIFT_shell logfile\n\n");
S_w2log(1,"\n*** LIFT_shell started ***\n\n");

## read LIFT version
if( open(VERSION,"<$LIFT_exec_path/modules/LIFT_version.txt") ){
	$LIFT_version = <VERSION>;
	chop $LIFT_version;
}
else {
	$LIFT_version = 'could not read version information';
	S_set_error( "Could not open file modules\\LIFT_version.txt" , 0);
}
close(VERSION);


use Devel::REPL::Script;

### this does the same as Devel::REPL::Script->import('run') but we can define the rcfile directly  

# since 'rcfile' Is defined as read only in Devel::REPL::Script we have to write it during object creation
my $repl=Devel::REPL::Script->new( rcfile => './repl.rc');

# if script file given, execute before starting shell
GetOptions('script=s' =>\$scriptfile);
if ($scriptfile){ 
	S_w2log(1,"running script $scriptfile\n");
    $repl->apply_script($scriptfile);
}

# to change prompt use this API
#$repl->_repl->prompt( '* ' );


# add own plugin for running script/ reporting verdict ... ?
# like Devel::REPL::Plugin::DumpHistory or Devel::REPL::Plugin::Timing


# run shell
$repl->run;





sub wanted { 
	no strict 'refs';
	my $module =  $_;
	# skip modules not starting with LIFT
	return unless $module =~ /^LIFT/;
	return unless $module =~ /\.pm$/;
	# skip LIFT_sVTT_Curves since this will start TK window
	return if $module =~ /LIFT_sVTT_Curves/;
	
	$module =~ s/\.\w+$//;
	# add export array of each LIFT module to LIFT_functions
	my @APIs = eval{ require "$module.pm"; return( @ { $module."::EXPORT" } ); };  # get EXPORT from module without actually loading the module
	push (@LIFT_functions,@APIs);
}




sub Devel::REPL::Plugin::Packages::DefaultScratchpad::help {
	print color 'bold green';
	print "\n ## any of the high level commands from LIFT will be executed in project engine context ## \n\n";
	print '\nto execute script on startup, call this file with option --script filename (do not use single quotes for filename)'."\n\n";
	print 'to enable silent mode (default off)    : $ $main::opt_silent = 1'."\n";
	print 'to enable simulation mode (default off): $ $main::opt_simulation = 1'."\n";
	print 'to enable offline mode (default off)   : $ $main::opt_offline = 1'."\n";
	print 'to load LIFT configuration : $ load_LIFT_config(\'C:\TurboLIFT\TSG4\config\TSG4_CFG.pm\')'."\n";
	print '
$ <TAB>
 just start typing the command and hit <TAB>. 
 It will be either completetd or a bell will sound (ambigous or no match). 
 on second hit <TAB> all commands starting like this are listed
 or a bell will sound (no matches)

$ <CRTL+p> will go back in history list
$ <CRTL+n> will go forward in history list

$ do "$filename"	e.g. $ do "test.txt"
 run a shell script, all lines in this file will be executed as shell command, comments will be ignored

$ my $variable	e.g. $ my $name = "Frank"
 define a variable for later use

$ help
 show this help with list of commands

$ system("pause")
 wait for key pressed, useful for shell scripts

$ sleep x	e.g. $ sleep 3
 wait for x seconds, useful for shell scripts

$ :dump file	e.g. $ :dump history.txt
 dump history to a file (which you can run by \'do\' later)

$ exit 
 exit shell';

    print color 'reset';
	print "\n\n";

return 1;
}




sub Devel::REPL::Plugin::Packages::DefaultScratchpad::load_LIFT_config{
    $opt_conf= shift;;
    S_w2log(1,"loading LIFT configuration $opt_conf\n");
    require $opt_conf;
    $ProjectDefaults = $LIFT_config::LIFT_ProjectDefaults;
	S_log_testbenchconfig();
	
	if( defined $LIFT_config::LIFT_ProjectDescription ) {
        $LIFT_ProjectDescription_html_code= <<EOLVER;
        $LIFT_config::LIFT_ProjectDescription
EOLVER

    }


	return 1;
}




END {
    # this will be called when shell is quit

    my $duration = time() - $LIFT_start_time;
    my ($sec,$min,$hour) = gmtime($duration); 
    my $days = int($duration / 86400);
    my $duration_text = "$days d $hour h $min min $sec sec ($duration sec) ";
	my $bookmarkText = '<p>Quick Links:  ';
	foreach my $bookmark (@htmlBookmarks){
		$bookmarkText .= "<a href=\"#$bookmark\">$bookmark</a> &nbsp; &nbsp;";
	}
	$bookmarkText .= '</p>';
	my $verdict_color;
	my $tc_verdict=$VERDICT;
	
	$verdict_color = "green" if $tc_verdict eq VERDICT_PASS;
    $verdict_color = "red" if $tc_verdict eq VERDICT_FAIL;
    $verdict_color = "purple" if $tc_verdict eq VERDICT_INCONC;
    $verdict_color = "blue" if $tc_verdict eq VERDICT_NONE;

    my $html_verdict = $tc_verdict; $html_verdict =~ s/VERDICT_//;
	
    my $tc_start_text_in_html_log= <<EOHTML;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Start HTML Header -->
    <HTML><HEAD>
    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
    <META NAME="Generator" CONTENT="LIFT exec engine">
    <TITLE>LIFT REPL shell Report: </TITLE>
    <script type="text/javascript" src="../htmldata/js/LIFT.js"></script>
    <link rel="stylesheet" href="../htmldata/css/style.css" type="text/css" media="print, projection, screen" >
    </HEAD>
<!-- End HTML Header -->
<!-- Start HTML Body -->
<BODY DIR="LTR" BGCOLOR="#FFFFFF"  onload="showLevel(5);"> 
<div id="header">
<ul id="navlist">
    <li>Loglevel:</li>
    <li id="hideall"><a href="javascript:hideall()">hide all</a></li>
    <li><a href="javascript:showLevel(0)" id="lev0"> 0</a></li>
    <li><a href="javascript:showLevel(1)" id="lev1"> 1</a></li>
    <li><a href="javascript:showLevel(2)" id="lev2"> 2</a></li>
    <li><a href="javascript:showLevel(3)" id="lev3"> 3</a></li>
    <li><a href="javascript:showLevel(4)" id="lev4"> 4</a></li>
    <li><a href="javascript:showLevel(5)" id="lev5"> 5</a></li>
    <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
    <li>Jump to</li>
    <li><A href="#TOP">TOP</a></li>
</ul>
</div>
<div id="content">
<A NAME="TOP"></A>
<TABLE>
  <TR>
    <TD><IMG SRC=\"..\\Documentation\\pics\\LifT_logo.png\" alt=\"LIFT_logo\" width=90 ></TD>
    <TD WIDTH="100%">
      <div style="font-family:Arial; color:grey; font-size:x-large; font-weight:bold; text-align:center">LIFT REPL shell log</div>
      <div style="font-family:Arial; font-weight:bold; text-align:center">$LIFT_ProjectDescription_html_code</div>
    </TD>
    <TD><IMG SRC=\"..\\Documentation\\pics\\repl.png\" alt=\"repl_logo\" ></TD>
  </TR>
</TABLE>
    <!-- horizontal line -->
    <HR>
    <!-- header table with start informations -->
    <TABLE style="font-family:Courier"  class="tablesorter" WIDTH=562>
        <TR style="font-weight:bold"><TH>VERDICT</TH><TD><B><A HREF="#$tc_verdict"><span style="color:$verdict_color">$html_verdict</span></A></B></TD></TR>
        <!-- Used Configuration: myConfiguration -->
        <TR><TH WIDTH="34%">Used Configuration:</TH><TD WIDTH="66%">$opt_conf</TD></TR>
        <!-- Start Date/Time:  -->
        <TR><TH WIDTH="34%">Start Date/Time:</TH><TD WIDTH="66%">$start_date  $start_time</TD></TR>
		<TR><TH>Duration:</TH><TD>$duration_text</TD></TR>
        <!-- hostname/user:  -->
        <TR><TH WIDTH="34%">user/hostname:</TH><TD WIDTH="66%">$username on $LIFT_host</TD></TR>
        <!-- LIFT version:  -->
        <TR><TH WIDTH="34%">LIFT version:</TH><TD WIDTH="66%">$LIFT_version</TD></TR>
    </TABLE>
$bookmarkText
    <!-- horizontal line -->
    <HR>	
EOHTML

    ## put the header on the top of collected tc log text
    unshift( @TC_HTML_TEXT , $tc_start_text_in_html_log );

    ### footer of TC HTML log file---------------------------------------------
    my $tc_end_text_in_html_log= <<EOHTML;
</div>
</BODY>
</HTML>
EOHTML

	S_w2log(1,"\n*** LIFT_shell stopped ***\n\n");
    ## put footer at the end of collected tc log text
    push( @TC_HTML_TEXT , $tc_end_text_in_html_log );

    S_w2tc_html($REPORT_PATH.'/LIFT_REPL_shell.html');	
	
}


=head1 NAME

LIFT_REPL_shell - Perl REPL (read eval print loop) shell with LIFT command autocompletion

=head1 SYNOPSIS

just start the shell by doubleclick

    $ load_LIFT_config('C:\TurboLIFT\TSG4\config\TSG4_CFG.pm')
    $ TSG4_InitHW()
    $ TSG4_SetVoltage( 12.5 )
    $ sleep 2
    $ exit    

or with options

    LIFT_REPL_shell.pl --script 'test.pl'    


=head1 DESCRIPTION

perl shell for LIFT

B<NOTE: do not run shell in parallel to another LIFT application e.g. LIFT !>

=head2 CLI

to execute script on startup, call this file with option --script filename  (do not use single quotes for filename)

=head2 LIFT modes

to enable silent mode (default off)    : $ $main::opt_silent = 1

to enable simulation mode (default off): $ $main::opt_simulation = 1

to enable offline mode (default off)   : $ $main::opt_offline = 1
	
=head2 autocomplete

	$ <TAB>

just start typing the command and hit <TAB>. 
It will be either completetd or a bell will sound (ambigous or no match). 
on sechond hit <TAB> all commands starting like this are listed or a bell will sound (no matches)
 

=head2 history

	$ <CRTL+p> will go back in history list
	$ <CRTL+n> will go forward in history list

=head2 load LIFT config

	$ load_LIFT_config('C:\TurboLIFT\TSG4\config\TSG4_CFG.pm')

this should be done before executing LIFT commands. 


=head2 any LIFT command

any of the high level commands from LIFT will be executed in project engine context. 


=head2 run file

    $ do '$filename'
    e.g. $ do 'test.txt' 

run a shell script, all lines in this file will be executed as shell command, comments will be ignored


=head2 show help

    $ help

show small help with list of commands


=head2 wait for key

    $ system('pause')

wait for key pressed, useful for shell scripts


=head2 wait

    $ sleep x
    e.g. $ sleep 3

wait for x seconds, useful for shell scripts


=head2 dump history

	$ :dump file
	e.g. $ :dump history.txt
	
dump history to a file (which you can run by 'do' later)


=head2 exit

	$ exit
	
exit shell 


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, LIFT documentation

=cut 

