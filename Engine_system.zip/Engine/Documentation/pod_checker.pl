#!/usr/bin/perl

use strict; use warnings;

use Pod::Checker;

# The POD file path is sent as a command line argument

my $pod_file = shift or die "Specify POD file as command line argumentn";

# Create checker object

my $checker = Pod::Checker->new();

# Parse the POD file, with errors sent to STDERR

$checker->parse_from_file($pod_file, \*STDERR);
