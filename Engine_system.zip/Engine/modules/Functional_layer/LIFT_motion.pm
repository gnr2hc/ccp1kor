# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_motion;

use strict;
use warnings;
use LIFT_general;
use LIFT_functional_layer;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  MOT_Init
  MOT_Exit
  MOT_Position
  MOT_GetPosition
  MOT_Rotate
  MOT_Stop
  MOT_Wobble
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_motion 

=head1 SYNOPSIS

    use LIFT_motion;

    MOT_Init();
    
    MOT_Position('H', 90);
    MOT_Rotate('V', 30);

    MOT_Stop('V');

    MOT_Exit();

=head1 DESCRIPTION

This is a wrapper module for motion devices, currently Acurot and RAT. 
If the ECU is attached to the motion device then defined positions and rotations can be set on various axes.

This wrapper module is a functional layer module.

The device that is used for the different functions is defined in testbench config (LIFT_Testbenches.pm) under 'Functions'->'Motion'.

=head2 Testbench configuration

=head3 Devices section:

    'Devices' => {
        ...
        'ACUROT' => {
            'COM_hor'  => 3,            # COM port for horizontal axis
            'zero_hor' => 4.647000,     # offset for horizontal axis zero position
            'COM_ver'  => 4,            # COM port for vertical axis
            'zero_ver' => 292.192000,   # offset for vertical axis zero position
        },
        'RAT' => {
            'IP' => '10.10.90.1',       # TCP socket IP-address of RAT controller
            'port' => 22,               # TCP socket port
        },
        ...
    },


=head3 Functions section:

    'Functions' => {
        ...
        'Motion' => {
            'Position' => <device>, # device supported - ACUROT, RAT 
            'Rotate'   => <device> , # device supported - ACUROT
        },
        ...  
    },

=cut

my $configuredDevices_href;
my $initFunctions_href;
my $mot_initialized = 0;

# In this data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.
my $functionMapping_href = {

    # marker for perltidy
    'base' => {
                'ACUROT' => {
                            'MOT_Init' => 'AR_init',    # for documentation purposes only
                            'MOT_Exit' => 'AR_exit',
                            },
                'RAT' => {
                            'MOT_Init' => 'RAT_connect',    # for documentation purposes only
                            'MOT_Exit' => 'RAT_disconnect',
                         },
            },
    'Position' => {
                'ACUROT' => {
                                'MOT_Position'   => 'AR_position',
                                'MOT_GetPosition'   => 'AR_get_position',
                                'MOT_Wobble'     => 'AR_wobble',
                            },
                 'RAT' => {
                            'MOT_Position'   => 'RAT_position',
                            'MOT_GetPosition'   => 'Not Supported',
                            'MOT_Wobble'     => 'Not Supported',
                          },
    },
    'Rotate' => {
                    'ACUROT' => {
                                    'MOT_Rotate' => 'AR_rotate',
                                    'MOT_Stop'  => 'AR_stop',
                                },
    },
};

my @availableTestbenchFunctionGroups = qw{ Position Rotate};

=head1 Function Group 'base'

=head2 MOT_Init

    $success = MOT_Init();

Initialize the devices for motion according to testbench settings and moves all axes to zero position.

Has to be called before any other MOT Function call.

Return Value : 1 on success, 0 otherwise.

=cut

sub MOT_Init{
    return FL_Init( 'motion', $functionMapping_href, \@availableTestbenchFunctionGroups );
}


=head2 MOT_Exit

    $success = MOT_Exit();

Stop all motions and disconnect from device hardware.

Return Value : 1 on success, 0 otherwise

=cut

sub MOT_Exit {
    return FL_Exit( 'motion', $functionMapping_href );      
}

=head1 Function Group 'Position'

=head2 MOT_Position

    $success = MOT_Position( $axis, $position_deg [, $speed_deg_s, $acceleration_deg_s2] );

Moves axis $axis of the device from current position to position $position_deg.
Optionally the maximum positioning speed (in deg/s) and acceleration until positioning speed (in deg/s2) can be given.
The device accelerates the axis from speed 0 to $speed_deg_s with acceleration $acceleration_time_ms, 
then moves with constant speed towards $position_deg, then decelerates from speed $speed_deg_s to 0 with acceleration $acceleration_time_ms
and finally stops at position $position_deg.

B<Arguments:>

=over

=item $axis 

Axis on which the desired position will be set. 
Can be either 'H' (horizontal axis), 'V' (vertical axis), 'x' (horizontal axis), 'y' (horizontal axis) or 'z' (vertical axis).

=item $position_deg 

Desired position in in �, range is -360 .. 360.

=item $speed_deg_s 

(optional) Maximum positioning speed in �/s. Default value depends on the configured device, see API documentation of the corresp�onding device

=item $acceleration_deg_s2 

(optional) Acceleration/deceleration until maximum positioning speed/speed 0 is reached.

=back

B<Return Value:>

=over

=item $success 

1 on success, 0 otherwise.

=back

=cut

sub MOT_Position {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MOT_Position( $axis, $position_deg [, $speed_deg_s, $acceleration_deg_s2] )', @args );
    return CallDeviceFunction(@args);
}

=head2 MOT_GetPosition

    $position_deg = MOT_GetPosition( $axis );

Returns the current position of axis $axis in deg.

Returns 0 in offline mode and undef on error.

=cut

sub MOT_GetPosition {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MOT_GetPosition( $axis )', @args );
    return CallDeviceFunction(@args);
}

=head2 MOT_Wobble

    $success = MOT_wobble($axis, $position1_deg, $position2_deg, $acceleration_ms);
    
Move axis $axis between given position $position1_deg and $position2_deg (clockwise) 
with acceleration time $acceleration_ms until maximum speed.

B<Arguments:>

=over

=item $axis 

Axis on which the desired position will be set. 
Can be either 'H' (horizontal axis), 'V' (vertical axis), 'x' (horizontal axis), 'y' (horizontal axis) or 'z' (vertical axis).

=item $position1_deg, $position2_deg 

End positions in in �, range is -360 .. 360.

=item $acceleration_time_ms 

(optional) Acceleration/deceleration time until Maximum positioning speed/speed 0 is reached.

=back

B<Return Value:>

=over

=item $success 

1 on success, 0 otherwise.

=back

This function is not supported for device RAT. In this case, it throws an error and returns.

=cut

sub MOT_Wobble {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MOT_Wobble( $axis, $position1_deg, $position2_deg, $acceleration_ms )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'Rotate'

=head2 MOT_Rotate

    $success = MOT_Rotate( $axis, $speed_deg_s );

Starts a rotation of axis $axis with rotation speed $speed_deg_s and returns immediately.

B<Arguments:>

=over

=item $axis 

Axis on which the desired position will be set. 
Can be either 'H' (horizontal axis), 'V' (vertical axis), 'x' (horizontal axis), 'y' (horizontal axis) or 'z' (vertical axis).

=item $speed_deg_s 

Rotation speed in �/s.

=back

B<Return Value:>

=over

=item $success 

1 on success, 0 otherwise.

=back

=cut

sub MOT_Rotate {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MOT_Rotate( $axis, $speed_deg_s )', @args );
    return CallDeviceFunction(@args);
}

=head2 MOT_Stop

    $success = MOT_Stop( $axis );

Stops any rotation of axis $axis that has been started with MOT_Rotate before.

=cut

sub MOT_Stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MOT_Stop( $axis )', @args );
    return CallDeviceFunction(@args);
}

=head1 Non exported functions

=head2 CallDeviceFunction 

 This Function will fetch the caller function name. With this it gets the function group name.
 Then it fetches the required Function API for the device configured.

=cut

sub CallDeviceFunction {
    my @args = @_;
    return FL_CallDeviceFunction('motion', $functionMapping_href, @args);
}

sub CreateArchitectureStructure {
    return FL_CreateArchitectureStructure('motion', $functionMapping_href);
}

sub Init_ACUROT {
    eval "use LIFT_ACUROT";
    AR_init();
    return 1;
}

sub Init_RAT {
    eval "use LIFT_RAT";
    RAT_connect();
    return 1;
}


1;