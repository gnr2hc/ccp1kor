# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_labcar;

use strict;
use warnings;
use LIFT_general;
use LIFT_numerics;
use LIFT_functional_layer;
use Readonly;
use File::Basename;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  LC_Init
  LC_Exit
  LC_Standby
  LC_ShortLines
  LC_UndoShortLines
  LC_ConnectLine
  LC_DisconnectLine
  LC_SetLogicalState
  LC_SetResistance
  LC_SetCurrent
  LC_Get_names
  LC_SendPWMDisposalStart
  LC_SendPWMDisposalStop
  LC_LV124_microcut
  LC_LV124_E10
  LC_LV124_E13
  LC_Digital2CAN_On
  LC_Digital2CAN_Off
  LC_DecodeLampStates
  LC_SetVoltage
  LC_GetVoltage
  LC_PowerConnect
  LC_PowerDisconnect
  LC_ECU_On
  LC_ECU_Off
  LC_ECU_Reset
  LC_PowerConfigCurve
  LC_PowerStartCurve
  LC_PowerStopCurve
  LC_PowerStartCurveOnTrigger
  LC_SetDVMscanner
  LC_ResetDVMscanner
  LC_ConfigureTRCchannels
  LC_SetTRCscanner
  LC_ResetTRCscanner
  LC_MeasureTraceDigitalStart
  LC_MeasureTraceDigitalStop
  LC_MeasureTraceDigitalSendSWTrigger
  LC_MeasureTraceDigitalPlotValues
  LC_MeasureTraceDigitalConfigureThresholds
  LC_MeasureTraceDigitalGetValues
  LC_ConfigureChannels
  LC_MeasureTraceAnalogStart
  LC_MeasureTraceAnalogStop
  LC_MeasureTraceAnalogSendSWTrigger
  LC_MeasureTraceAnalogPlotValues
  LC_MeasureTraceAnalogGetValues
  LC_MeasureOnceGetVoltage
  LC_PowerGenCurve
  LC_PowerPlotCurve
);

our ( $VERSION, $HEADER );

#Global variable accessible inside of package
Readonly my $MAXNUMSAMPSFORGRAPHPLOT => 500000;    #500000 is the Maximum Number of points S_create_graph can take at once

=head1 NAME

LIFT_labcar 

=head1 SYNOPSIS

    use LIFT_labcar;

    LC_Init();
    
    # function group 'line'
    LC_ShortLines( ['AB1FD+', 'BT1FP-'] );
    LC_DisconnectLine( 'BLRR' );
    LC_SetLogicalState( 'PADS', 'PAB_disabled' );

    # function group 'lineRT'
    LC_LV124_microcut( 'BT1FP', 24 );
    
    # function group 'digital2CAN'
    LC_Digital2CAN_On();
    LC_Digital2CAN_Off();
    
    # function group 'disposal'
    LC_SendPWMDisposalStart( 'DISP' );
    LC_SendPWMDisposalStop( 'DISP' );
    
    # function group 'power_static'
    LC_SetVoltage( 'U_BATT_DEFAULT' );
    LC_PowerConnect( 'Ubat' );
    # or alternatively
    LC_ECU_On();

    LC_PowerDisconnect( 'Ubat' );
    LC_SetVoltage( 0 );
    # or alternatively
    LC_ECU_Off();
    
    LC_ECU_Reset( 2 );
    
    # function group 'power_dynamic'
    LC_PowerGenCurve($curveStruct_href [, $filename]);
    LC_PowerPlotCurve($filename);
    LC_PowerConfigCurve( 'mycurve.sat' );
    LC_PowerStartCurve();
    LC_PowerStopCurve();
    
    # function group 'measure_connector'
    LC_SetTRCscanner( ['ALL_SQUIBS::current'], {'SignalMode' => 'differential','VoltageRange' => 5} );
    LC_ConfigureTRCchannels();

    # function group 'measure_trace_digital'
    LC_MeasureTraceDigitalConfigureThresholds( {'ALL' => 0.8},  );
    LC_MeasureTraceDigitalStart();
    LC_MeasureTraceDigitalStop();
    my $digitalData_href = LC_MeasureTraceDigitalGetValues();

    # function group 'measure_trace_analog'
    LC_MeasureTraceAnalogStart();
    LC_MeasureTraceAnalogStop();
    my $analogData_href = LC_MeasureTraceAnalogGetValues();

    # function group 'measure_once'
    my $voltage = LC_MeasureOnceGetVoltage( [$range] );

    LC_Exit();

=head1 DESCRIPTION

This is a wrapper library for all devices which are involved in airbag ECU I/O lines, power and line measurement.
There are many functions available in LIFT_labcar. For better structuring and also because different devices are involved 
the functions are organized in function groups:

    Function Group 'line':          Simple line manipulations like disconnect or short lines
    Function Group 'lineRT':        Line microcut and special LV124 line manipulation
    Function Group 'digital2CAN':   Creating a CAN trace of digital line signals
    Function Group 'disposal':      Sending a disposal PWM signal on a line
    Function Group 'power_static':  Setting voltage on a power device and switching power lines on and off
    Function Group 'power_dynamic': Handling voltage curves on a power device
    Function Group 'measure_connector':     Setting scanner positions for DVM and TRC
    Function Group 'measure_trace_digital': Handling digital line measurements (e.g. LCT) 
    Function Group 'measure_trace_analog':  Handling analog line measurements (e.g. TRC)
    Function Group 'measure_once':          Getting the voltage measured by a oscilloscope (DSO)

In the TurboLIFT architecture LIFT_labcar is a functional module and should be used instead of device specific modules
(see TurboLIFT module architecture below).

=for html
<a href='../index-architecture.html'>TurboLIFT module architecture</a>

The following table shows which function groups of LIFT_labcar should be used instead of device level modules or older modules:

    Function Group 'line', 'lineRT', 'digital2CAN', 'disposal': should be used instead of respective LIFT_MLC and LIFT_TSG4 functions
    Function Group 'power_static' and 'power_dynamic': should be used instead of LIFT_POWER functions
    Function Group 'measure_connector': should be used instead of LIFT_TSG4 scanner functions
    Function Group 'measure_trace_digital' and 'measure_trace_analog': should be used instead of LIFT_TRC and LIFT_LCT functions
    Function Group 'measure_once': should be used instead of LIFT_DMM1 functions

Test cases that use LIFT_POWER will still work, but in future LIFT_POWER will become obsolete and will be deactivated. 
So please use LIFT_labcar power functions instead.

The devices that are used for the different function groups are defined in testbench config (LIFT_Testbenches.pm) under 'Functions'->'Labcar':

 ### --- Function Area : Labcar, function groups for I/O lines, power and line measurement
 'Labcar' => {
   'line'     =>   '<device>', # possible devices: TSG4, MLC, SPILC, PeriBox, PeriBox_NoPower(if peribox is used 
                               # as only line device, not for power control)
   'extended' =>   '<device>', # testbench function group 'extended', contains architecture function groups 
                               # 'lineRT', 'digital2CAN'; device only TSG4
   'disposal' =>   '<device>', # possible devices: TSG4, MLC (with ACL box), PeriBox (with ACL box), 
                               # PeriBox_NoPower (with ACL box, no user action on init)
   'power_Ubat' => '<device>', # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX, IXS, GOS1, PRITT, 
                               # Manitoo, NONE
   'power_UF' =>   '<device>', # possible devices: TSG4, MLC, TOE1, TOELLNER, NIDAQ, IDX, IXS, GOS1, PRITT, 
                               # NONE
   'measure_connector' =>     '<device>', # possible devices: TSG4, wired
   'measure_trace_digital' => '<device>', # possible devices: TRC, LCT
   'measure_trace_analog' =>  '<device>', # possible devices: TRC, NIDAQ
   'measure_once' =>          '<device>', # possible devices: DMM1, later possibly HP3458A, HP34401A               
 },


Note about power functions: TurboLIFT supports up to 2 power lines: Ubat (default) and optionally UF. 
In testbench config the devices that are connected to Ubat and (optionally) UF must be configured.
There are 2 groups of power functions: power_static and power_dynamic. Dynamic power functions are supported only by TOE1, NIDAQ, TSG4.


The functions of the groups 'measure_connector', 'measure_trace_digital' and 'measure_trace_analog' are closely related.
Below are some example use cases for the usage of measure functions:

1) Measure firing times for crash injection (LCT64 or MF Transi)

    LC_SetTRCscanner(abc);
    LC_ConfigureTRCchannels();
    LC_MeasureTraceDigitalConfigureThresholds( {'ALL' => 0.8},  );
    LC_MeasureTraceDigitalStart();
    # make Quate trigger
    LC_MeasureTraceDigitalStop();
    my $firingTimes_href = LC_MeasureTraceDigitalGetValues();
    # evaluate $firingTimes_href using LIFT_evaluation


2) Measure first abc then xyz with MF Transi and TSG4 with scanner

    LC_SetTRCscanner(abc);
    LC_ConfigureTRCchannels();
    LC_MeasureTraceAnalogStart();
    # make Quate trigger
    LC_MeasureTraceAnalogStop();
    my $someData_href = LC_MeasureTraceAnalogGetValues();
    # evaluate $someData_href using LIFT_evaluation

    LC_SetTRCscanner(xyz);
    LC_ConfigureTRCchannels();
    LC_MeasureTraceAnalogStart();
    # make Quate trigger
    LC_MeasureTraceAnalogStop();
    my $someData_href = LC_MeasureTraceAnalogGetValues();
    # evaluate $someData_href using LIFT_evaluation

3) Measure first abc then xyz with MF Transi and TSG4/MLC/PeriBox without scanner

    LC_ConfigureTRCchannels();
    LC_MeasureTraceAnalogStart();
    # make Quate trigger
    LC_MeasureTraceAnalogStop();
    my $someData_href = LC_MeasureTraceAnalogGetValues();
    # evaluate $someData_href using LIFT_evaluation

    LC_ConfigureTRCchannels();
    LC_MeasureTraceAnalogStart();
    # make Quate trigger
    LC_MeasureTraceAnalogStop();
    my $someData_href = LC_MeasureTraceAnalogGetValues();
    # evaluate $someData_href using LIFT_evaluation



Some devices need their own specific mappings in project const, see the individual device documentation pages for more details:

=for html
<a href='LIFT_TSG4.html'>LIFT_TSG4 documentation</a>
<a href='LIFT_MLC.html'>LIFT_MLC documentation</a>
<a href='TC_FunctionLib/FuncLib_SPILC_Framework.html'>FuncLib_SPILC_Framework documentation</a>

However, to ensure compatibility between different devices it should be made sure that the names of the lines are the same in each mapping.

The functions that are called internally in this module are defined in $functionMapping_href.

=cut

my $IDXdevices;
our $currentPowerSource;

# In this data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.
my $functionMapping_href = {

    # marker for perltidy
    'base' => {
        'TSG4' => {
            'LC_Init' => 'TSG4_InitHW',    # for documentation purposes only
            'LC_Exit' => 'TSG4_CloseHW',
        },
        'MLC' => {
            'LC_Init' => 'MLC_InitHW',
            'LC_Exit' => 'MLC_CloseHW',
        },
        'PeriBox' => {
            'LC_Init' => 'S_user_action',
            'LC_Exit' => 'None',
        },
        'PeriBox_NoPower' => {
            'LC_Init' => 'None',
            'LC_Exit' => 'None',
        },
        'TOE1' => {
            'LC_Init' => 'TOE1_connect',
            'LC_Exit' => 'TOE1_disconnect',
        },
        'TOELLNER' => {
            'LC_Init' => 'TOE_connect',
            'LC_Exit' => 'LIFT_labcar_TOELLNER::LC_Exit',
        },
        'NIDAQ' => {
            'LC_Init' => 'NIDAQ_init',
            'LC_Exit' => 'NIDAQ_exit',
        },
        'Manitoo' => {
            'LC_Init' => 'MANITOO_init',
            'LC_Exit' => 'MANITOO_exit',
        },
        'IDX' => {
            'LC_Init' => 'IDX_InitHW',
            'LC_Exit' => 'IDX_CloseHW',
        },
        'IXS' => {
            'LC_Init' => 'IXS_InitHW',
            'LC_Exit' => 'IXS_CloseHW',
        },
        'GOS1' => {
            'LC_Init' => 'GOS1_connect',
            'LC_Exit' => 'GOS1_disconnect',
        },
        'NONE' => {
            'LC_Init' => 'S_user_action',
            'LC_Exit' => 'None',
        },
        'TRC' => {
            'LC_Init' => 'TRC_InitHW',
            'LC_Exit' => 'TRC_CloseHW',
        },
        'LCT' => {
            'LC_Init' => 'LCT_InitHW',
            'LC_Exit' => 'None',
        },
        'DMM1' => {
            'LC_Init' => 'DMM1_connect',
            'LC_Exit' => 'DMM1_disconnect',
        },
        'PRITT' => {
            'LC_Init' => 'PRT_init',
            'LC_Exit' => 'PRT_exit',
        },
        'SPILC' => {
            'LC_Init' => 'SPILC_init',
            'LC_Exit' => 'SPILC_exit',
        },
        'STAC' => {
            'LC_Init' => 'STAC_InitHW',
            'LC_Exit' => 'STAC_CloseHW',
        },
    },
    'line' => {
        'TSG4' => {
            'LC_Standby'              => 'TSG4_Standby',
            'LC_ConnectLine'          => 'TSG4_ConnectLine',
            'LC_DisconnectLine'       => 'TSG4_DisconnectLine',
            'LC_ShortLines'           => 'TSG4_ShortLines',
            'LC_UndoShortLines'       => 'TSG4_UndoShortLines',
            'LC_SetLogicalState'      => 'TSG4_SetLogicalState',
            'LC_SetResistance'        => 'TSG4_SetResistance',
            'LC_SetCurrent'           => 'TSG4_SetCurrent',
            'LC_Get_names'            => 'LIFT_labcar_TSG4::LC_Get_names',
            'LC_ConnectPowerLines'    => 'LIFT_labcar_TSG4::LC_PowerConnect',
            'LC_DisconnectPowerLines' => 'LIFT_labcar_TSG4::LC_PowerDisconnect',
        },
        'MLC' => {
            'LC_Standby'              => 'LIFT_labcar_MLC::LC_Standby',
            'LC_ConnectLine'          => 'MLC_ReconnectLine',
            'LC_DisconnectLine'       => 'MLC_DisconnectLine',
            'LC_ShortLines'           => 'LIFT_labcar_MLC::LC_ShortLines',
            'LC_UndoShortLines'       => 'MLC_UndoShortLine',
            'LC_SetLogicalState'      => 'MLC_SetLogicalState',
            'LC_SetResistance'        => 'MLC_SetResistance',
            'LC_SetCurrent'           => 'MLC_SetCurrent',
            'LC_Get_names'            => 'LIFT_labcar_MLC::LC_Get_names',
            'LC_ConnectPowerLines'    => 'LIFT_labcar_MLC::LC_PowerConnect',
            'LC_DisconnectPowerLines' => 'LIFT_labcar_MLC::LC_PowerDisconnect',
        },
        'PeriBox' => {
            'LC_Standby'              => 'None',
            'LC_ConnectLine'          => 'LIFT_labcar_PeriBox::LC_ConnectLine',
            'LC_DisconnectLine'       => 'LIFT_labcar_PeriBox::LC_DisconnectLine',
            'LC_ShortLines'           => 'LIFT_labcar_PeriBox::LC_ShortLines',
            'LC_UndoShortLines'       => 'LIFT_labcar_PeriBox::LC_UndoShortLines',
            'LC_SetLogicalState'      => 'LIFT_labcar_PeriBox::LC_SetLogicalState',
            'LC_SetResistance'        => 'LIFT_labcar_PeriBox::LC_SetResistance',
            'LC_SetCurrent'           => 'LIFT_labcar_PeriBox::LC_SetCurrent',
            'LC_Get_names'            => 'NotSupported',
            'LC_ConnectPowerLines'    => 'LIFT_labcar_PeriBox::LC_PowerConnect',
            'LC_DisconnectPowerLines' => 'LIFT_labcar_PeriBox::LC_PowerDisconnect',
        },

        'PeriBox_NoPower' => {
            'LC_Standby'              => 'None',
            'LC_ConnectLine'          => 'LIFT_labcar_PeriBox::LC_ConnectLine',
            'LC_DisconnectLine'       => 'LIFT_labcar_PeriBox::LC_DisconnectLine',
            'LC_ShortLines'           => 'LIFT_labcar_PeriBox::LC_ShortLines',
            'LC_UndoShortLines'       => 'LIFT_labcar_PeriBox::LC_UndoShortLines',
            'LC_SetLogicalState'      => 'LIFT_labcar_PeriBox::LC_SetLogicalState',
            'LC_SetResistance'        => 'LIFT_labcar_PeriBox::LC_SetResistance',
            'LC_SetCurrent'           => 'LIFT_labcar_PeriBox::LC_SetCurrent',
            'LC_Get_names'            => 'NotSupported',
            'LC_ConnectPowerLines'    => 'None',
            'LC_DisconnectPowerLines' => 'None',
        },

        'SPILC' => {
            'LC_ConnectLine'          => 'SPILC_ConnectLine',
            'LC_DisconnectLine'       => 'SPILC_DisconnectLine',
            'LC_ShortLines'           => 'SPILC_ShortLines',
            'LC_UndoShortLines'       => 'SPILC_UndoShortLines',
            'LC_Standby'              => 'NotSupported',
            'LC_SetLogicalState'      => 'NotSupported',
            'LC_SetResistance'        => 'NotSupported',
            'LC_SetCurrent'           => 'NotSupported',
            'LC_Get_names'            => 'NotSupported',
            'LC_ConnectPowerLines'    => 'None',
            'LC_DisconnectPowerLines' => 'None',
        },
        'STAC' => {
            'LC_Standby'              => 'None',
            'LC_ConnectLine'          => 'STAC_ConnectLine',
            'LC_DisconnectLine'       => 'STAC_DisconnectLine',
            'LC_ShortLines'           => 'None',
            'LC_UndoShortLines'       => 'None',
            'LC_SetLogicalState'      => 'STAC_SetLogicalState',
            'LC_SetResistance'        => 'None',
            'LC_SetCurrent'           => 'None',
            'LC_Get_names'            => 'LIFT_labcar_STAC::LC_Get_names',
            'LC_ConnectPowerLines'    => 'LIFT_labcar_STAC::LC_PowerConnect',
            'LC_DisconnectPowerLines' => 'LIFT_labcar_STAC::LC_PowerDisconnect',
        },
    },
    'disposal' => {
        'TSG4' => {
            'LC_SendPWMDisposalStart' => 'TSG4_PWM_Disposal',
            'LC_SendPWMDisposalStop'  => 'TSG4_PWM_stop',
        },
        'MLC' => {
            'LC_SendPWMDisposalStart' => 'LIFT_labcar::ManualPWMDisposalStart',
            'LC_SendPWMDisposalStop'  => 'LIFT_labcar::ManualPWMDisposalStop',
        },
        'PeriBox' => {
            'LC_SendPWMDisposalStart' => 'LIFT_labcar::ManualPWMDisposalStart',
            'LC_SendPWMDisposalStop'  => 'LIFT_labcar::ManualPWMDisposalStop',
        },
        'PeriBox_NoPower' => {
            'LC_SendPWMDisposalStart' => 'LIFT_labcar::ManualPWMDisposalStart',
            'LC_SendPWMDisposalStop'  => 'LIFT_labcar::ManualPWMDisposalStop',
        },
    },
    'lineRT' => {
        'TSG4' => {
            'LC_LV124_microcut' => 'TSG4_LV124_microcut',
            'LC_LV124_E10'      => 'TSG4_LV124_E10',
            'LC_LV124_E13'      => 'TSG4_LV124_E13',
        },
    },
    'digital2CAN' => {
        'TSG4' => {
            'LC_Digital2CAN_On'   => 'LIFT_labcar_TSG4::LC_Digital2CAN_On',
            'LC_Digital2CAN_Off'  => 'LIFT_labcar_TSG4::LC_Digital2CAN_Off',
            'LC_DecodeLampStates' => 'TSG4_DecodeLampStates',
        },
    },
    'power_static' => {
        'TSG4' => {
            'LC_SetVoltage'      => 'LIFT_labcar_TSG4::LC_SetVoltage',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_TSG4::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_TSG4::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'MLC' => {
            'LC_SetVoltage'      => 'MLC_SetVoltage',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_MLC::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_MLC::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'TOE1' => {
            'LC_SetVoltage'      => 'TOE1_PPSvoltage',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'TOE1_PPSon',
            'LC_PowerDisconnect' => 'TOE1_PPSoff',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'TOELLNER' => {
            'LC_SetVoltage'      => 'LIFT_labcar_TOELLNER::LC_SetVoltage',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_TOELLNER::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_TOELLNER::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'NIDAQ' => {
            'LC_SetVoltage'      => 'LIFT_labcar_NIDAQ::LC_SetVoltage',
            'LC_GetVoltage'      => 'LIFT_labcar_NIDAQ::LC_GetVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_NIDAQ::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_NIDAQ::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'Manitoo' => {
            'LC_SetVoltage'      => 'LIFT_labcar_Manitoo::LC_SetVoltage',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_Manitoo::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_Manitoo::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'IDX' => {
            'LC_SetVoltage'      => 'LIFT_labcar::SetVoltageManually',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_IDX::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_IDX::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'IXS' => {
            'LC_SetVoltage'      => 'LIFT_labcar::SetVoltageManually',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_IXS::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_IXS::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'GOS1' => {
            'LC_SetVoltage'      => 'GOS1_voltage',
            'LC_GetVoltage'      => 'GOS1_measureVoltage',
            'LC_PowerConnect'    => 'GOS1_on',
            'LC_PowerDisconnect' => 'GOS1_off',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'PRITT' => {
            'LC_SetVoltage'      => 'LIFT_labcar::SetVoltageWarning',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'PRT_power_connect',
            'LC_PowerDisconnect' => 'PRT_power_disconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
        'NONE' => {
            'LC_SetVoltage'      => 'LIFT_labcar::SetVoltageManually',
            'LC_GetVoltage'      => 'LIFT_labcar::GetLastVoltage',
            'LC_PowerConnect'    => 'LIFT_labcar_NONE::LC_PowerConnect',
            'LC_PowerDisconnect' => 'LIFT_labcar_NONE::LC_PowerDisconnect',
            'LC_ECU_On'          => 'internal',
            'LC_ECU_Off'         => 'internal',
        },
    },
    'power_dynamic' => {
        'TSG4' => {
            'LC_PowerConfigCurve'         => 'LIFT_labcar_TSG4::LC_PowerConfigCurve',
            'LC_PowerStartCurve'          => 'TSG4_runCurve',
            'LC_PowerStopCurve'           => 'LIFT_labcar_TSG4::LC_PowerStopCurve',
            'LC_PowerStartCurveOnTrigger' => 'TSG4_runCurveOnTrigger',
        },
        'TOE1' => {
            'LC_PowerConfigCurve'         => 'LIFT_labcar_TOE1::LC_PowerConfigCurve',
            'LC_PowerStartCurve'          => 'TOE1_runCurve',
            'LC_PowerStopCurve'           => 'TOE1_stopCurve',
            'LC_PowerStartCurveOnTrigger' => 'TOE1_runCurveOnTrigger',
        },
        'TOELLNER' => {
            'LC_PowerConfigCurve'         => 'LIFT_labcar_TOELLNER::LC_PowerConfigCurve',
            'LC_PowerStartCurve'          => 'LIFT_labcar_TOELLNER::LC_PowerStartCurve',
            'LC_PowerStopCurve'           => 'LIFT_labcar_TOELLNER::LC_PowerStopCurve',
            'LC_PowerStartCurveOnTrigger' => 'LIFT_labcar_TOELLNER::LC_PowerStartCurveOnTrigger',
        },
        'NIDAQ' => {
            'LC_PowerConfigCurve'         => 'LIFT_labcar_NIDAQ::LC_PowerConfigCurve',
            'LC_PowerStartCurve'          => 'LIFT_labcar_NIDAQ::LC_PowerStartCurve',
            'LC_PowerStopCurve'           => 'NIDAQ_StopArbitrary',
            'LC_PowerStartCurveOnTrigger' => 'NotSupported',
        },
    },
    'measure_connector' => {
        'TSG4' => {
            'LC_SetDVMscanner'        => 'TSG4_SetDVMscanner',
            'LC_ResetDVMscanner'      => 'TSG4_ResetDVMscanner',
            'LC_ConfigureTRCchannels' => 'TSG4_ConfigureTRCchannels',
            'LC_SetTRCscanner'        => 'TSG4_SetTRCscanner',
            'LC_ResetTRCscanner'      => 'TSG4_ResetTRCscanner',
        },
        'wired' => {
            'LC_SetDVMscanner'        => 'None',
            'LC_ResetDVMscanner'      => 'None',
            'LC_ConfigureTRCchannels' => 'LIFT_TRC::TRC_ConfigureChannels',
            'LC_SetTRCscanner'        => 'None',
            'LC_ResetTRCscanner'      => 'None',
        },
    },
    'measure_trace_digital' => {
        'TRC' => {
            'LC_MeasureTraceDigitalStart'               => 'LIFT_labcar_TRC::LC_MeasureTraceDigitalStart',
            'LC_MeasureTraceDigitalStop'                => 'LIFT_labcar_TRC::LC_MeasureTraceDigitalStop',
            'LC_MeasureTraceDigitalSendSWTrigger'       => 'TRC_SendSWTrigger',
            'LC_MeasureTraceDigitalGetValues'           => 'LIFT_labcar_TRC::LC_MeasureTraceDigitalGetValues',
            'LC_MeasureTraceDigitalPlotValues'          => 'TRC_plot_values',
            'LC_MeasureTraceDigitalConfigureThresholds' => 'LIFT_labcar_TRC::LC_MeasureTraceDigitalConfigureThresholds',
        },
        'LCT' => {
            'LC_MeasureTraceDigitalStart'               => 'LCT_StartMeasurement',
            'LC_MeasureTraceDigitalStop'                => 'LCT_StopMeasurement',
            'LC_MeasureTraceDigitalSendSWTrigger'       => 'LCT_SendSWTrigger',
            'LC_MeasureTraceDigitalGetValues'           => 'LCT_get_values',
            'LC_MeasureTraceDigitalPlotValues'          => 'LCT_plot_values',
            'LC_MeasureTraceDigitalConfigureThresholds' => 'LIFT_TSG4::TSG4_SetSquibCurrentThreshold',
        },
        'LA_AcuteTravelLogic' => {
            'LC_MeasureTraceDigitalStart'               => 'LIFT_labcar_LATL::LC_MeasureTraceDigitalStart',
            'LC_MeasureTraceDigitalStop'                => 'LATL_StopMeasurement',
            'LC_MeasureTraceDigitalSendSWTrigger'       => 'None',
            'LC_MeasureTraceDigitalGetValues'           => 'None',
            'LC_MeasureTraceDigitalPlotValues'          => 'LIFT_labcar_LATL::LC_MeasureTraceDigitalPlotValues',
            'LC_MeasureTraceDigitalConfigureThresholds' => 'None',
        },
    },
    'measure_trace_analog' => {
        'TRC' => {
            'LC_ConfigureChannels'               => 'None',
            'LC_MeasureTraceAnalogStart'         => 'LIFT_labcar_TRC::LC_MeasureTraceAnalogStart',
            'LC_MeasureTraceAnalogStop'          => 'LIFT_labcar_TRC::LC_MeasureTraceAnalogStop',
            'LC_MeasureTraceAnalogSendSWTrigger' => 'TRC_SendSWTrigger',
            'LC_MeasureTraceAnalogGetValues'     => 'LIFT_labcar_TRC::LC_MeasureTraceAnalogGetValues',
            'LC_MeasureTraceAnalogPlotValues'    => 'TRC_plot_values',
        },

        'NIDAQ' => {
            'LC_ConfigureChannels'               => 'NIDAQ_ConfigureChannels',
            'LC_MeasureTraceAnalogStart'         => 'NIDAQ_StartAnalogInput',
            'LC_MeasureTraceAnalogStop'          => 'NIDAQ_StopAnalogInput',
            'LC_MeasureTraceAnalogSendSWTrigger' => 'NIDAQ_SendSwTrigger',
            'LC_MeasureTraceAnalogGetValues'     => 'NIDAQ_GetValues',
            'LC_MeasureTraceAnalogPlotValues'    => 'NIDAQ_StoreAnalogInput',
        },
    },
    'measure_once' => {
        'DMM1' => {
            'LC_MeasureOnceGetVoltage' => 'DMM1_getVoltage',
        },
    },
};

my @availableTestbenchFunctionGroups = qw{ line extended disposal power_Ubat power_UF measure_connector measure_trace_digital measure_trace_analog measure_once};

my $lastVoltage_href = {
    'Ubat' => 0,
    'UF'   => 0,
};

#
#
# Definition of all functions in LIFT_labcar
#
#

=head1 Function Group 'base'

Base functions for init and exit of LIFT_labcar

=head2 LC_Init

    LC_Init();
    
Initialize the devices for all Labcar function groups.
This function has to be called before calling any other function in this library.
Calls internally the init functions of all devices that are configured in LIFT_Testbenches.pm for this functional module.
By convention the init functions must have the name "Init_<device>", e.g. Init_TSG4, Init_MLC, ...

=cut

sub LC_Init {
    return FL_Init( 'labcar', $functionMapping_href, \@availableTestbenchFunctionGroups );
}

=head2 LC_Exit

    LC_Exit();
    
Disconnect from the devices for all Labcar functions.

=cut

sub LC_Exit {
    return FL_Exit( 'labcar', $functionMapping_href );
}

=head1 Function Group 'line'

Functions for simple line manipulations like disconnect or short lines (and reverse functions) 
and setting resistance or current values of switch lines.

=head2 LC_Standby

    LC_Standby( [$time] );

     $time in seconds 1..9999, default is 1 sec for standby

will set periphery device to standby mode after $time (disable internal 12V supply). should be called in ENDcampaign. 
Periphery device will be set to normal mode again by LC_Init.
Has only effect on TSG4. Nothing will happen for other periphery devices.

=cut

sub LC_Standby {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_Standby( [$time] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ShortLines

    LC_ShortLines( $lines_aref, [$resistance] );

create a short between $lines (with leakage resistor $resistance). 
$lineX may be a label from ProjectConst with + or - added, or "B+","B-", "UF+" or "UF-".
for WARNING_LAMPS sign will be ignored
$resistance can take value from 0 to 100000 Ohms, default is 0.

B< Note: only one short at same time is possible !>

 e.g.
    LC_ShortLines( ['AB1FD+', 'BT1FP-'] );
    LC_ShortLines( ['AB1FD+', 'PADS+'] );
    LC_ShortLines( ['AB1FD+', 'UFS1+'] );
    LC_ShortLines( ['AB1FD+', 'BT1FP-'], 100); # AB1FD+ will be shorthed via 100 Ohms to BT1FP-
    LC_ShortLines( ['AB1FD+', 'B+'] );
    LC_ShortLines( ['AB1FD+', 'B-'] );
    LC_ShortLines( ['AB1FD+', 'BT1FP-', 'UF+'], 100 ); # AB1FD+ connected to BT1FP- will be shorthed via 100 Ohms to UF+
    LC_ShortLines( ['AB1FD+', 'UF-'], 100 );

B< Note 1: For periphery device MLC a short of only 2 lines is possible  !>

B< Note 2: For periphery device SPILC: >

B<         - no short via leakage resistor supported>

B<         - only shorts to B+, B-, UF+, UF- are supported for device types squibs, pases and switches>

B<         - more than one device short to  B+, B-, UF+, UF- are supported for device types squibs, pases and switches>

B<         - Two different kinds of line faults e.g openline and shortline cannnot be performed in parallel by periphery device SPILC >

=cut

sub LC_ShortLines {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ShortLines( $lines_aref, [$resistance] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_UndoShortLines

    LC_UndoShortLines( );

Remove a short condition created by LC_ShortLines.

B< Note: For periphery device SPILC only device types squibs, pases and switches are supported >

=cut

sub LC_UndoShortLines {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_UndoShortLines(  )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ConnectLine

    LC_ConnectLine( $line );
    
(re-)connect line of periphery device, $line has to be a label from ProjectConst section of the periphery device.

 e.g.
    LC_ConnectLine( 'BT1FP' );
    LC_ConnectLine( 'PPSL' );
    LC_ConnectLine( 'BLRR' );
    LC_ConnectLine( 'UB1' );

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

B< Note: For periphery device SPILC only device types squibs, pases and switches are supported >

=cut

sub LC_ConnectLine {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ConnectLine( $line )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_DisconnectLine

    LC_DisconnectLine( $line );

disconnect line of periphery device, $line has to be a label from ProjectConst section of the periphery device.

 e.g.
    LC_DisconnectLine( 'BT1FP' );
    LC_DisconnectLine( 'PPSL' );
    LC_DisconnectLine( 'BLRR' );
    LC_DisconnectLine( 'UB1' );

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

B< Note: For periphery device SPILC only device types squibs, pases and switches are supported >

B< Two different kinds of line faults e.g openline and shortline cannnot be performed in parallel by periphery device SPILC >

=cut

sub LC_DisconnectLine {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_DisconnectLine( $line )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_SetLogicalState

    LC_SetLogicalState( $switch, $state )

Set switch to state, $switch and $state have to be a label from ProjectConst.
If state is 'DEFAULT' then the default value is taken.

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

e.g.
    LC_SetLogicalState( 'PADS', 'PAB_disabled' );  # will set PADS to 200 mA
    LC_SetLogicalState( 'BLRR', 'unbuckled' );     # will set BLRR to 400 Ohm
    LC_SetLogicalState( 'PADS', 'DEFAULT' );       # will set PADS to 100 mA
    LC_SetLogicalState( 'BLR2P_VW', 'unbuckled' ); # will set PADS to 9990 Ohm (open)
    LC_SetLogicalState( 'BLR2P_VW', 'DEFAULT' );   # will set BLR2P_VW to 20 Ohm (short/closed)

=cut

sub LC_SetLogicalState {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetLogicalState( $switch, $state )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_SetResistance

    LC_SetResistance( $label, $resistance);

Sets resistance $resistance (in ohm) for switch or squib with label $label.

    For Squibs:
    $resistance between 0.1 .. 99.9 Ohm step 0.1 Ohm

    For Switch:
    $resistance between 20 .. 9990 Ohm step 10 Ohm

Will not connect device automatically if it was disconnected before!
You may also use 'DEFAULT' to set squibs/switches to default value.

Only applicable for Switches and Squibs !

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

e.g.
    LC_SetResistance( 'AB1FD', 10 );
    LC_SetResistance( 'BLRR', 26.5);
    LC_SetResistance( 'AB1FD', 'DEFAULT' );
    LC_SetResistance( 'BLRR', 'DEFAULT' );


=cut

sub LC_SetResistance {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetResistance( $label, $resistance)', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_SetCurrent

    LC_SetCurrent( $label, $currentvalue);

Set current equal to $currentvalue (in mA) across the Switch $label. Only applicable for Switches!

Will not connect device automatically if it was disconnected before!

You may also use 'DEFAULT' to set switch to default value (only useful for I switches).
 
$currentvalue in mA between 0.1 .. 100.0 mA step 0.1 mA

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

    LC_SetCurrent( 'PADS', 25.5 );
    LC_SetCurrent( 'BLRR', 15.0 ); # will set current where a resistor switch is configured

    LC_SetCurrent( 'PADS', 'DEFAULT' );
    LC_SetCurrent( 'BLRR', 'DEFAULT' ); # will lead to out of range error because default is intended for resistor switch

=cut

sub LC_SetCurrent {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetCurrent( $label, $currentvalue)', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_Get_names

  @names = LC_Get_names( $section[,$which] );

Return names of section $section defined in periphery device ProjectConst in ascending order depending on $which option choosed. 

$section can be: SQUIBS POWER_SUPPLY_LINES SWITCHES/BELT_LOCKS WARNING_LAMPS

For TSG4 additionally: PAS_LINES CAN_FR K_LIN DVM_SCANNER TRC_SCANNER

Possible values for $which:

'all' : all names of lines in the given $section will be returned.
    
'connected' : only names of lines in the given $section will be returned that have 'Default' not equal to  "not_connected" in the mapping.
    
'not_connected' : only names of lines in the given $section will be returned that have 'Default' equal to "not_connected" in the mapping.

By Default if no value or wrong value for $which, is given : it simply returns all names. 

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

e.g.

    LC_Get_names( 'SQUIBS', 'connected' ) can return ('AB1FD','BT1FP','AB1FP') on TSG4
    
    LC_Get_names( 'SQUIBS', 'not_connected' ) can return ('AB2FD') on TSG4              

=cut

sub LC_Get_names {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_Get_names( $section[,$which] )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'disposal'

Functions for sending a disposal PWM signal on a line

=head2 LC_SendPWMDisposalStart

    LC_SendPWMDisposalStart( $line [, $ignoreUserAction ] );

Start sending disposal PWM signal on line $line.

If $ignoreUserAction = 1 then any kind of user action will be ignored, assuming that an ACL signal is already provided.
$ignoreUserAction does not have any effect if device = TSG4.

=cut

sub LC_SendPWMDisposalStart {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SendPWMDisposalStart( $line [, $ignoreUserAction ] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_SendPWMDisposalStop

    LC_SendPWMDisposalStop( $line [, $ignoreUserAction ] );

Stop sending disposal PWM signal on line $line.

If $ignoreUserAction = 1 then any kind of user action will be ignored, assuming that it does not matter if the ACL signal is still there.
$ignoreUserAction does not have any effect if device = TSG4.

=cut

sub LC_SendPWMDisposalStop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SendPWMDisposalStop( $line [, $ignoreUserAction ] )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'lineRT' (part of testbench function group 'extended')

Functions for line microcut and special LV124 line manipulation (LV124_E10 and LV124_E13)

=head2 LC_LV124_microcut

    LC_LV124_microcut( $line, $time_us );

Perform single microcut on line $line with duration $time_us in microseconds. 
$line has to be a label from ProjectConst.

e.g.

	LC_LV124_microcut( 'BT1FP', 24 );

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_LV124_microcut {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_LV124_microcut( $line, $time_us )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_LV124_E10

    LC_LV124_E10( $mode, $time_us );

perform LV124 E10 interruption on UF input, 

    $mode may be '100K', '10K' or '0.1R'
    '100K': S1 closed, S2 open,           R=100K
    '10K' : S1 closed, S2 inverted to S1, R=10K
    '0.1R': S1 closed, S2 open,           R=0.1R

     $time_us may be 5 to 1000000000 microseconds

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

 e.g.
    LC_LV124_E10( '100K', 200 ); #interrupt UF input for 200 microsec

    UF has to be connected to the Power line you want to test.
    e.g. by LC_ConnectLine( 'UB1' );


=for html
<IMG SRC='..\..\pics\LV124_Ubat.png'  alt="LV124_E10 Ubat circuit" border="0" width=400px>
<IMG SRC='..\..\pics\LV124_Ubat2.png'  alt="LV124_10 Ubat switching" border="0">
<br>Oscilloscope screenshots of LV124 E-10 microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_Ubat.png' target="blank">measurement circuit</a><br>
mode '100K':
<a href='..\..\pics\TSG4\Ubat_1_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_1_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_1_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_1_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_1_100.png' target="blank">100 us</a>
<br>mode '10K':
<a href='..\..\pics\TSG4\Ubat_2_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_2_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_2_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_2_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_2_100.png' target="blank">100 us</a>
<br>mode '0.1R':
<a href='..\..\pics\TSG4\Ubat_3_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_3_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_3_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_3_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_3_100.png' target="blank">100 us</a>
<br>
timing <a href='..\..\pics\TSG4\Ubat_2_100can.png' target="blank">message to interruption</a>
, timing <a href='..\..\pics\TSG4\Ubat_2_100decoding.png' target="blank">message decoding</a>

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_LV124_E10 {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_LV124_E10( $mode, $time_us )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_LV124_E13

    LC_LV124_E13( $line, $sequence );

perform LV124 E-13 sequence on line, $line has to be a label from ProjectConst

$sequence may be one of 

    '10s_single'
    '1ms_single'
    '100us_single'
    '1us_cycle_4s'    t=1us,   t1=1ms, t2=4s
    '100us_cycle_4s'  t=0.1ms, t1=1ms, t2=4s

 e.g.
    LC_LV124_E13( 'BT1FP', '1ms_single' );
    LC_LV124_E13( 'PPSL', '1ms_single' );
    LC_LV124_E13( 'BLRR', '1ms_single' );
    LC_LV124_E13( 'PADL', '1ms_single' );
    LC_LV124_E13( 'Lin1', '1ms_single' );
    LC_LV124_E13( 'CANdiag::L', '1ms_single' ); # H L G - high low ground

Refer L</"DESCRIPTION"> for ProjectConst and Testbench configuration settings

=for html
<IMG SRC='..\..\pics\LV124_E13.png'  alt="LV124_E13 pin switching" border="0">
<br><br>
Oscilloscope screenshots of Squib E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_SQ.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_SQ_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_SQ_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_SQ_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_SQ_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_SQ_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_SQ_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_SQ_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_SQ_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_SQ_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_SQ_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_SQ_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_SQ_can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of PAS E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_PAS.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_PAS_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_PAS_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_PAS_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_PAS_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_PAS_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_PAS_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_PAS_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_PAS_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_PAS_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_PAS_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_PAS_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_PAS_can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of Warning Lamp 4 E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_WL.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_WL_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_WL_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_WL_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_WL_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_WL_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_WL_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_WL_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_WL_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_WL_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_WL_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_WL_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_WL_can.png' target="blank">message to interruption</a>

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_LV124_E13 {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_LV124_E13( $line, $sequence )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'digital2CAN' (part of testbench function group 'extended')

Functions for creating a CAN trace of digital line signals (PWM signal or WL states)

=head2 LC_Digital2CAN_On

    LC_Digital2CAN_On();

Start a trace of digital line signals (PWM signal or WL states) on device internal CAN.

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_Digital2CAN_On {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_Digital2CAN_On()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_Digital2CAN_Off

    LC_Digital2CAN_Off();

Stop and store the trace of digital line signals (PWM signal or WL states) on device internal CAN.

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_Digital2CAN_Off {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_Digital2CAN_Off()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_DecodeLampStates

    $wl_trace_data_ref = LC_DecodeLampStates( $can_trace_data_href, $wl1bitmask );

Extract wl signals from CAN trace (created with LC_Digital2CAN_On/LC_Digital2CAN_Off).
Currently extracts only data for Wl card 1.

$wl1bitmask bit order is 123456 e.g. 010000 for WL_1_2

B< Note: This function is only supported for device = TSG4  !>

=cut

sub LC_DecodeLampStates {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_DecodeLampStates( $can_trace_data_href, $wl1bitmask )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'power_static'

Functions for setting voltage on a power device and switching power lines on and off.

=head2 LC_SetVoltage

    LC_SetVoltage( $voltage [, $powerSource] );

Set voltage of the device that is configured for the selected power source ($powerSource). 
$powerSource can be 'Ubat' (default) or 'UF'.
$voltage has to be a float value or a label that is defined in ProjectConst.

=cut

sub LC_SetVoltage {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetVoltage( $voltage [, $powerSource] )', @args );
    my $voltage = shift @args;
    $currentPowerSource = GetPowerSource( shift @args );

    my $voltageValue;
    if ( $voltage =~ /^-?\d+\.?\d*$/ ) {
        $voltageValue = $voltage;
    }
    elsif ( defined S_get_contents_of_hash( [ 'VEHICLE', $voltage ] ) ) {
        $voltageValue = S_get_contents_of_hash( [ 'VEHICLE', $voltage ] );
    }
    else {
        S_set_error( "Could not resolve given voltage '$voltage'", 114 );
        return 0;
    }
    $lastVoltage_href->{$currentPowerSource} = $voltageValue;
    unshift( @args, $voltageValue );
    return CallDeviceFunction(@args);
}

=head2 LC_GetVoltage

    LC_GetVoltage( [$powerSource] );

Get voltage value of the device that is configured for the selected power source ($powerSource). 
$powerSource can be 'Ubat' (default) or 'UF'.

Only device NIDAQ actually measures the voltage, all other devices will just return the voltage that was last set.

=cut

sub LC_GetVoltage {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_GetVoltage( [$powerSource] )', @args );
    $currentPowerSource = GetPowerSource( shift @args );
    return CallDeviceFunction(@args);
}

=head2 LC_PowerConnect

    LC_PowerConnect( [$powerSource] );
    
Connect all power lines of the device that is configured for the selected power source ($powerSource). 
$powerSource can be 'Ubat' (default) or 'UF'.
If LC_SetVoltage has been called before with sufficient voltage, then this will usually switch on the ECU.

=cut

sub LC_PowerConnect {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerConnect( [$powerSource] )', @args );
    my $device = GetConfiguredDevice('line');
    $currentPowerSource = GetPowerSource( shift @args );
    my $status = CallDeviceFunction(@args);    # connect power lines on power device
    LC_ConnectPowerLines() if defined $device; # connect power lines on lines device
    return $status;
}

=head2 LC_PowerDisconnect

    LC_PowerDisconnect( [$powerSource] );

Disconnect all power lines of the device that is configured for the selected power source ($powerSource). 
$powerSource can be 'Ubat' (default) or 'UF'.
This will usually switch off the ECU.

=cut

sub LC_PowerDisconnect {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerDisconnect( [$powerSource] )', @args );
    my $device = GetConfiguredDevice('line');
    LC_DisconnectPowerLines() if defined $device;    # disconnect power lines on lines device
    $currentPowerSource = GetPowerSource( shift @args );
    return CallDeviceFunction(@args);                # disconnect power lines on power device
}

=head2 LC_ECU_On

    LC_ECU_On( [$voltage] );

Set voltage of the device that is configured for 'power_Ubat' to $voltage if given, otherwise to 'U_BATT_DEFAULT' (must be defined in ProjectConst)
and connect all power lines of that device.
This will usually switch on the ECU (if voltage is sufficiently high).

=cut

sub LC_ECU_On {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ECU_On( [$voltage] )', @args );

    my $setVoltage = $args[0];
    $setVoltage = 'U_BATT_DEFAULT' if not defined $setVoltage;
    LC_SetVoltage($setVoltage);
    LC_PowerConnect();
    return 1;
}

=head2 LC_ECU_Off

    LC_ECU_Off();

Set voltage of the device that is configured for 'power_Ubat' to 0V
and disconnect all power lines of that device.
This will usually switch off the ECU.

=cut

sub LC_ECU_Off {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ECU_Off()', @args );

    LC_PowerDisconnect();
    LC_SetVoltage(0);
    return 1;
}

=head2 LC_ECU_Reset

    LC_ECU_Reset( [ $numberOfResets, $voltage ] );

Executes LC_ECU_Off, S_wait_ms( 'TIMER_ECU_OFF' ), LC_ECU_On($voltage), S_wait_ms( 'TIMER_ECU_READY' ).
This sequence is repeated $numberOfResets times, but at least once if $numberOfResets is not given
or if $numberOfResets is <= 0

Set voltage of the device that is configured for 'power_Ubat' to $voltage if given, otherwise to 'U_BATT_DEFAULT' (must be defined in ProjectConst)
and connect all power lines of that device.

B<Arguments:>

=over

=item $numberOfResets 

Resets the device that is configured to $numberOfResets, otherwise it resets 1 time.

=item $voltage 

Set voltage of the device that is configured for 'power_Ubat' to $voltage if given, otherwise to 'U_BATT_DEFAULT' (must be defined in ProjectConst)

=back

B<Return Value:>

Returns 1 on sucessful completion else undef.

=back

B<Examples:>

    LC_ECU_Reset();     Reset will happen for one time with 'U_BATT_DEFAULT' voltage

    LC_ECU_Reset(2);    Reset will happen for two time with 'U_BATT_DEFAULT' voltage

    LC_ECU_Reset(2,2);  Reset will happen for two time with '2V' voltage

=cut

sub LC_ECU_Reset {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ECU_Reset( [ $numberOfResets, $voltage ] )', @args );

    #STEP check if $numberOfResets is defined and if not assign 1 by default
    my $numberOfResets = shift @args // 1;

    #STEP check if $voltage is defined and if not assign U_BATT_DEFAULT voltage value by default
    my $voltage = shift @args;

    #IF Is $voltage not in range or not a valid format?
    #IF-YES-START
    #STEP Return undef with error message to report
    #IF-YES-END
    if ( defined($voltage) ) {
        if ( $voltage < 0 ) {
            S_set_error( "Given voltage is not valid range should be positive float or integer", 109 );
            return;
        }
        if ( $voltage !~ /^\d+\.?\d*$/ ) {
            S_set_error( "Given voltage contains Non-numeric character, valid format should be positive float or integer", 109 );
            return;
        }
    }

    # IF-NO-START

    #LOOP-START loop through number of $numberOfResets and resets the ECU
    # STEP Resets the ECU with $voltage(if voltage not defined then U_BATT_DEFAULT is considered)
    foreach my $resetCounter ( 1 .. $numberOfResets ) {
        S_w2log( 2, "LC_ECU_Reset: Performing reset # $resetCounter\n" );
        LC_ECU_Off();
        S_wait_ms('TIMER_ECU_OFF');
        S_w2log( 3, "LC_ECU_Reset: Performing ECU ON with $voltage voltage\n" ) if ( defined($voltage) );    #logging the voltage Level
        LC_ECU_On($voltage);                                                                                 #'U_BATT_DEFAULT' will be considered if $voltage argument is not defined. For more details refer "LC_ECU_On" function
        S_wait_ms('TIMER_ECU_READY');
    }

    #LOOP-END end of $numberOfResets
    # STEP Return 1
    # IF-NO-END

    #STEP END
    return 1;
}

=head1 Function Group 'power_dynamic'

Functions for executing voltage curves on a power device.

=head2 LC_PowerConfigCurve

	($curveDuration_s, $u_min, $u_max) = LC_PowerConfigCurve( $curveFile [, $powerSource] );
	
Load voltage curve file $curveFile to the device that is configured for the selected power source ($powerSource).
$curveFile can be a .svtc or .sat file.

B<Arguments:>

=over

=item $curveFile

voltage curve file

=back

B<Return Value:>

=over

=item ($curveDuration_s, $u_min, $u_max)

(duration,u_min,u_max) - success

(duration, u_min,u_max) - offline (duration = 1, if configured device is TOE1)

(undef,undef,undef) - error

=back

=cut

sub LC_PowerConfigCurve {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerConfigCurve( $curveFile [, $powerSource] )', @args );
    my $curveFile = shift @args;
    $currentPowerSource = GetPowerSource( shift @args );
    unshift( @args, $curveFile );
    return CallDeviceFunction(@args);
}

=head2 LC_PowerPlotCurve

    LC_PowerPlotCurve( $input_file_path );

This function will plot the curve from the file ($input_file_path) and add it to the report.

B<Arguments:>

=over

=item $input_file_path

Path of the curve file.  
	 
=back

B<Return Value:>

=over

=item Success : 1 

The graph plot is added onto the report. 
In case of long curves that have points(samples) more than 500000 the curve is resampled and plotted. 

=item Failure 

undef

=back

B<Examples:>

=over

=item  

LC_PowerPlotCurve("C:\\TurboLIFT_TSG4\\Engine\\test\\config\\sVTT\\LV124_e_01_1_check.svtc");

=item  

LC_PowerPlotCurve("C:\\TurboLIFT_TSG4\\Engine\\test\\config\\sVTT\\E_08_forVW_test_10.sat");  

=back

=cut

sub LC_PowerPlotCurve {
    my @args = @_;
    return unless S_checkFunctionArguments( 'LC_PowerPlotCurve ( $input_file_path )', @args );
    my $input_file_path = shift @args;
    my ( $input_file, $fileType );

    unless ( $input_file_path =~ /(.sat|.svtc|.txt)$/ ) {
        S_set_error( "$input_file_path should be in .sat or .svtc or .txt file format \n", 114 );
        return;
    }

    $input_file = basename($input_file_path);    #filename
    $fileType   = $1;                            #extracts the extension type of the file.

    my $inpFH;
    unless ( open( $inpFH, '<', "$input_file_path" ) ) {
        S_set_error( "couldn't open $input_file_path\n", 21 );
        return;
    }

    my @inpFH_ary  = <$inpFH>;
    my $inpFH_aref = \@inpFH_ary;
    close($inpFH);

    my $time_volt_href           = {};
    my $resampled_time_volt_href = {};

    my ( $curve_arb_vol_aref, $curve_arb_time_aref ) = Parse_CurveFile($inpFH_aref);

    if ( ( !defined(@$curve_arb_vol_aref) ) || ( scalar(@$curve_arb_vol_aref) == 1 ) ) {
        S_set_error( "File '$input_file_path'  for curve '$input_file' doesnot contain the voltage value(s) \n", 114 );
        return;
    }

    if ( ( !defined(@$curve_arb_time_aref) ) || ( scalar(@$curve_arb_time_aref) == 1 ) ) {
        S_set_error( "File '$input_file_path'  for curve '$input_file' doesnot contain the time value(s) \n", 114 );
        return;
    }

    $time_volt_href = {
        'time' => $curve_arb_time_aref,
        'volt' => $curve_arb_vol_aref,
    };

    my $numSamps_acquired  = @$curve_arb_vol_aref;        #number of voltage samples acquired.
    my $maxNumSampsForPlot = $MAXNUMSAMPSFORGRAPHPLOT;    #maximum number of samples the graph plotting function can plot

    if ( $numSamps_acquired > $maxNumSampsForPlot ) {

        S_w2log( 5, " The number of samples obtained exceeds the memory limit (=$maxNumSampsForPlot). Hence it needs Re-sampling..\n " );

        my $res_factor = $numSamps_acquired / $maxNumSampsForPlot;

        my $resampled_time_aref = $time_volt_href->{'time'};
        my $total_time          = @$resampled_time_aref[ $numSamps_acquired - 1 ];
        my $mean_time           = ( $total_time / $numSamps_acquired );
        my $dtOut_sec           = $mean_time * $res_factor;
        my $dataIn_aref         = $time_volt_href->{'volt'};

        $resampled_time_volt_href = {
            'dataIn_aref' => $dataIn_aref,
            'dtIn_sec'    => $mean_time,
            'dtOut_sec'   => $dtOut_sec,
        };
        $resampled_time_volt_href = NUM_ResampleData($resampled_time_volt_href);
        my $resampled_voltages_aref = $resampled_time_volt_href->{dataOutValues_aref};
        $numSamps_acquired = scalar(@$resampled_voltages_aref);

        if ( $resampled_time_volt_href->{status} != 1 || $numSamps_acquired > $maxNumSampsForPlot ) {
            S_set_warning("File '$input_file_path' for curve '$input_file' contains too many values ( $numSamps_acquired ) to plot and hence plotting not possible \n");
            return;
        }
        else {
            $time_volt_href = {
                'volt' => $resampled_time_volt_href->{dataOutValues_aref},
                'time' => $resampled_time_volt_href->{dataOutTimes_aref},
            };
        }
    }

    my $graph_directory = "$main::REPORT_PATH/PlottedGraphs";
    unless ( -e $graph_directory or mkdir $graph_directory ) {
        S_set_error("Unable to create $graph_directory\n");
        return;
    }

    my $curveFile = $graph_directory . "\\$input_file";
    $curveFile =~ s/\.\w+$//;    # cut off file extension
    S_w2rep("Plot for Curve File : $input_file\n");
    my $status = S_create_graph( $time_volt_href, $curveFile, 'Curve Plot', 'white', 'no_interpolation', 'Voltage in v' );
    S_add_pic2html( "file:///$curveFile.png", 'width=600', "file:///$curveFile.txt.unv", 'TYPE="text/unv"', 1 );
    S_w2log( 5, "Status of S_create_graph ($time_volt_href, $curveFile) :: $status \n" );

    return 1;
}

=head2 LC_PowerGenCurve

	($curveFileName) = LC_PowerGenCurve( $curveStruct_href,[$filename] );
	
Creates a Ramp or Random curve or both and returns the $curveFileName of the curve generated.
The $curveFileName gives complete path of generated file.

B<Arguments:>

=over

=item $curveStruct_href

Hash reference containing curve parameters that are to be generated.

# Format and example

($curveFileName) = LC_PowerGenCurve( $curveStruct_href,[$filename] );
  
  $curveStruct_href = {
   1 => 'Ramp : start_Voltage (V): End_Voltage(V) : Time_Duration(s) : [no_of_samples]',
   2 => 'Random : ONMax(ms) : ONmin(ms) : OFFmax(ms) : OFFmin(ms) : Von_max(V) :  Von_min(V) : Voff_max(V) : Voff_min(V): $max_duration(s)',
     
  }; 

Ramp -> start_Voltage (V), End_Voltage(V) , Time_Duration(s) , [no_of_samples]
   
   start_Voltage (V)       -  Start voltage of Ramp in Volts
   End_Voltage(V)          -  End voltage of Ramp in Volts
   Time_Duration(s)        -  Time duration in s
   [no_of_samples]optional -  No of samples in ramp curve.
   
Random -> ONMax(ms) , ONmin(ms) ,OFFmax(ms), OFFmin(ms),Von_max(V), Von_min(V),Voff_max(V), Voff_min(V), $max_duration(s)
   
   ONMax(ms)  -  Maximum ON time in milliseconds.
   ONmin(ms)  -  Minimum ON time in milliseconds.
   OFFmax(ms) -  Maximum OFF time in milliseconds.
   OFFmin(ms) -  Minimum OFF time in milliseconds.
   
   Von_max(V) -  Max ON voltage.
   Von_min(V) -  Min ON Voltage. 
   Voff_max(V)-  Max OFF voltage.
   Voff_min(V)-  Min OFF Voltage.
   $max_duration(s) - Max Duration in seconds.
   
Eg: Only Ramp Curve

   $curveStruct_href = {
    1 => 'Ramp:12.6 : 3.8 : 3.6 ',    
  }

=for html
<IMG SRC='..\..\pics\Ramp.jpg'  alt="Ramp Curve" border="0">
<br><br>

Eg: Only Random Curve

   $curveStruct_href = {
   1 => 'Random:3000:2000:700:500:12.5:10.8:6.5:3:60, 
  }
  
=for html
<IMG SRC='..\..\pics\Random.jpg'  alt="Random curve" border="0">
<br><br>

Eg: Both Ramp and Random Curve, number curves as per required sequence

  $curveStruct_href = {
    1 => 'Ramp:12.6 : 3.8 : 3.6 ',    
    2 => 'Random:3000:2000:700:500:12.5:10.8: 0.5 :0:60, 
    3 => 'Ramp:1.6 : 3.8 : 2.8  ', 
    4 => 'Random:1500:800:700:500:12.5 :10.8: 0.5 :0:30,
  }


If the Power device used is toellner or TSG4, the device can run Max 1000 points(Limitation of Toellner and TSG4).
In this case, use optional parameters for 'Ramp' to accomodate multiple curves together as mentioned in Below example.
If no_of_samples are mentioned,so many no of samples will used to generate that particular curve ( min no_of_samples >= 50)  

Eg: Multiple curves and no. of samples mentioned for ramp curve.

    $curveStruct_href = {

    1 => 'Ramp:12.6 : 3.8 : 3.6 :100',
    2 => 'Ramp:1.6 : 3.8 : 2.8 : 100',	
    3 => 'Random:1500:800:700:500:12.5 :10.8: 0.5 :0:30,
}


=item $filename

Optional parameter : voltage curve file name eg: Curvefile.sat (only .sat extension is supported)
if not defined, by default takes MyCustomCurve.sat as Curve filename

=back

B<Return Value:>

=over

=item ($curveFileName)

On success : Complete path of Curve filename (with Timestamp)

           e.g. : 'D:/TurboLIFT_Sandbox/Projects/TSG4/reports/TL_LRT_20170720_095810/20170720_095904_MyCustomCurve.sat'
           
On error : 0

=back

B<Notes:> 

Curve file will be stored in main reports path.

Configuring and Running the curve with power dynamic device (TSG4 or NIDAQ or TOELLNER) should be explicitly done after this function call.

=cut

sub LC_PowerGenCurve {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerGenCurve( $curveStruct_href [, $filename] )', @args );

    #Curve files can be generated offline and does not Require LC_Init();
    my ( $curveStruct_href, $filename ) = @args;

    #COMMENT-START
    # Get all the arguments
    # mandatory
    # - $curveStruct_href,
    # optional
    # - $filename
    #COMMENT-END
    my ( $volt_aref, $time_aref, @volt_levels, @timesteps );
    my $status = 0;
    my $curve_type;
    my @curve_item_arg;

    #STEP check if filename is defined and if it is a .sat
    unless ( defined $filename ) {
        $filename = "MyCustomCurve.sat";
        S_w2log( 5, "LC_PowerGenCurve: Default Curve Filename used : $filename \n" );
    }
    else {
        if ( $filename !~ m/^.*.sat$/ ) {
            S_set_error( "LC_PowerGenCurve : curve file type must be .sat", 114 );
            return 0;
        }
    }

    #STEP add filepath of curve file to reports folder
    $filename = $main::REPORT_PATH . '/' . S_get_TC_number() . '_' . $filename;

    $curveStruct_href = CheckandUpdateParamters($curveStruct_href);

    return 0 if $curveStruct_href == 0;

    #LOOP-START loop through contents of HASH and call curresponding curve function

    foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {
        my $curve_item = $$curveStruct_href{$key_of_hash};
        @curve_item_arg = split /:/, $curve_item;
        $curve_type = $curve_item_arg[0];

        shift @curve_item_arg;
        foreach (@curve_item_arg) {
            if ( $_ !~ /^\s*[-+]?[0-9]*\.?[0-9]+\s*$/ ) {
                S_set_error( "LC_PowerGenCurve : $_ is not a valid Numeric input", 114 );
                return $status;
            }
        }

        # IF type of the curve is random
        # IF-YES-START
        #      CALL CreateRandomOnOffCurve
        # IF-YES-END
        if ( $curve_type =~ /Random$/ ) {
            ( $status, $volt_aref, $time_aref ) = CreateRandomOnOffCurve( \@curve_item_arg );
        }

        # IF-NO-START
        # IF type of the curve is ramp
        # IF-YES-START
        #      CALL CreateRampCurvefile
        # IF-YES-END
        elsif ( $curve_type =~ /Ramp$/ ) {
            ( $status, $volt_aref, $time_aref ) = CreateRampCurve( \@curve_item_arg );
        }

        # IF-NO-START
        #      STEP ERROR : Wrong curvetype
        # IF-NO-END
        # IF-NO-END
        else {
            S_set_error( "LC_PowerGenCurve : Wrong Curve type given : $curve_type", 114 );
            return $status;
        }

        if ( $status > 0 ) {
            push( @volt_levels, @$volt_aref );
            push( @timesteps,   @$time_aref );
        }
        else {
            S_set_error( " LC_PowerGenCurve : Creation of curve file failed", 23 );
            return $status;
        }
    }

    #LOOP-END end of hash
    #STEP Dump all curve points to curve
    if ( open( OUT, ">$filename" ) ) {
        print OUT "Filename:       		$filename\n";
        print OUT "Points:          	" . scalar(@timesteps) . "\n";
        print OUT "Current Limitations:	4\n";
        print OUT "Repetitions:		  	1\n\n";
        print OUT "U[V]    t[s]\n\n";

        for ( my $i = 0 ; $i < @timesteps ; $i++ ) {
            print OUT "$volt_levels[$i]    $timesteps[$i]\n";
        }
        close(OUT);
    }
    else {
        S_set_error( "LC_PowerGenCurve : could not open out file $filename", 1 );
        return $status;
    }
    S_w2log( 5, "LC_PowerGenCurve:  Created a curve file with name $filename \n" );

    #STEP Set a warning if no of samples in curve is >1000
    my $total_pts_curve = scalar @volt_levels;
    if ( scalar @volt_levels > 1000 ) {
        S_set_warning( "no_of_samples in curve  > 1000, this may only work with NIDAQ", 114 );
    }
    S_w2log( 5, "LC_PowerGenCurve:  Total no of points in curve : $total_pts_curve \n" );
    return $filename;
}

=head2 LC_PowerStartCurve

    LC_PowerStartCurve( [ $powerSource] );

Start the voltage curve that has been loaded before by LC_PowerConfigCurve on the device that is configured for the selected power source ($powerSource).
Does not wait until the curve is finished, but returns immediately after curve start.

=cut

sub LC_PowerStartCurve {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerStartCurve( [ $powerSource] )', @args );
    $currentPowerSource = GetPowerSource( shift @args );
    return CallDeviceFunction(@args);
}

=head2 LC_PowerStopCurve

    LC_PowerStopCurve( [ $powerSource] );

Stop the voltage curve that has been started before by LC_PowerStartCurve on the device that is configured for the selected power source ($powerSource).

=cut

sub LC_PowerStopCurve {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerStopCurve( [ $powerSource] )', @args );
    $currentPowerSource = GetPowerSource( shift @args );
    return CallDeviceFunction(@args);
}

=head2 LC_PowerStartCurveOnTrigger

    LC_PowerStartCurveOnTrigger( [ $powerSource] );

Set all starting conditions for the voltage curve that has been loaded before by LC_PowerConfigCurve 
on the device that is configured for the selected power source ($powerSource), waiting for external trigger.

=cut

sub LC_PowerStartCurveOnTrigger {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_PowerStartCurveOnTrigger( [ $powerSource] )', @args );
    $currentPowerSource = GetPowerSource( shift @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'measure_connector'

Functions for setting scanner positions for DVM and TRC.

=head2 LC_SetDVMscanner

    LC_SetDVMscanner( $label );

Switch scanner to position described by $label.

    $label may have ::current attached e.g. 'UB2::current'
    $label may have ::H or ::L or ::G attached for CAN pins
    $label may have ::K or ::N or ::L attached K-line/LIN pins

=cut

sub LC_SetDVMscanner {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetDVMscanner( $label )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ResetDVMscanner

    LC_ResetDVMscanner( );

Reset scannerposition(s)

=cut

sub LC_ResetDVMscanner {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ResetDVMscanner()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_SetTRCscanner

    LC_SetTRCscanner( $label_aref, $CH_config_href [, $TRG_config_href] );

Switch scanner(s) to corresponding position(s) and create data structure for transient recorder settings.
See TSG4 documentation for more details:

=for html
<a href='LIFT_TSG4.html#TSG4_SetTRCscanner'>TSG4_SetTRCscanner</a>

Note: This function has no effect if device 'wired' is configured for function group 'measure_connector'.

=cut

sub LC_SetTRCscanner {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_SetTRCscanner( $label_aref, $CH_config_href [, $TRG_config_href] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ConfigureTRCchannels

    LC_ConfigureTRCchannels([$TRC_general_config_href],[$TRC_ExtTrg_config_href]);

(re)configure transient recorder channel settings with data generated by LC_SetTRCscanner, has to be called after last LC_SetTRCscanner and before next usage of transient recorder.

See TSG4 documentation for more details:

=for html
<a href='LIFT_TSG4.html#TSG4_ConfigureTRCchannels'>TSG4_ConfigureTRCchannels</a>

=cut

sub LC_ConfigureTRCchannels {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ConfigureTRCchannels( [ $TRC_general_config_href, $TRC_ExtTrg_config_href ] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ResetTRCscanner

    LC_ResetTRCscanner( );

Reset corresponding scannerposition(s). Implicitly stop any running measurement (digital and analog).

=cut

sub LC_ResetTRCscanner {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ResetTRCscanner()', @args );
    my $deviceDigital = GetConfiguredDevice('measure_trace_digital');
    LC_MeasureTraceDigitalStop() if defined $deviceDigital;    # this is required because the user may forget to stop the measurment
    my $deviceAnalog = GetConfiguredDevice('measure_trace_analog');
    LC_MeasureTraceAnalogStop() if defined $deviceAnalog;      # see above
    return CallDeviceFunction(@args);
}

=head1 Function Group 'measure_trace_digital'

Functons for handling digital line measurements (0/1 information over time, e.g. LCT)

=head2 LC_MeasureTraceDigitalStart

    LC_MeasureTraceDigitalStart();

Start a new measurement and wait for trigger. Until one of the configured trigger or Software trigger(refer LC_MeasureTraceDigitalSendSWTrigger()) is obtained, 
the trace recorder will not start recording.

=cut

sub LC_MeasureTraceDigitalStart {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalStart()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceDigitalStop

    LC_MeasureTraceDigitalStop();

Stop the already running measurement, if any. If measurement is not running, no error will be returned.

=cut

sub LC_MeasureTraceDigitalStop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalStop()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceDigitalSendSWTrigger

    LC_MeasureTraceDigitalSendSWTrigger();

Trigger the trace recorder by software. The trace recorder starts recording as soon as it gets the software trigger. 
Measurement should be already started (by LC_MeasureTraceDigitalStart()) before calling this function.

=cut

sub LC_MeasureTraceDigitalSendSWTrigger {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalSendSWTrigger()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceDigitalPlotValues

    LC_MeasureTraceDigitalPlotValues( $plotfilename [, $minWaitTime_ms] );

Plot the recorded signals for All the configured channels into UNIVIEW formatted file(data with semi-colon seperated format) or .law format only for acute travel logic (to open it with LA viewer).

	$plotfilename : the file name for the plot
	$minWaitTime_ms : Optional wait time to wait for data to be recorded in trace recorder (used for fail-safe measurement)
	                  Has only an effect for Transient Recorder.

=cut

sub LC_MeasureTraceDigitalPlotValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalPlotValues( $plotfilename [, $minWaitTime_ms] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceDigitalConfigureThresholds

    LC_MeasureTraceDigitalConfigureThresholds( $labels_aref, $currentThreshold [, $shuntResistance ] );

Configure the current thresholds ($currentThreshold in A) and optionally the shunt resistance ($shuntResistance in Ohm) 
for a group of squibs ($labels_aref) for firing time evaluation (LC_MeasureTraceDigitalGetValues). 

$labels_aref can also be ['ALL'] to set one threshold (and shunt resistance) for all squibs.

The function can be called several times. Then the settings will be remembered. A later call for one same squib will overwrite earlier settings.

For MF Transi by default the shunt resistance is set to 1 Ohm (TSG4 pin 'TRC+- I ZKx'). If the MF Transi is connected directly to the squibs
then the shunt resistance can be set explicitly.

For LCT64 $shuntResistance will not be used.


Examples:

    1)
    LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 0.8, 2.2 );
    LC_MeasureTraceDigitalConfigureThresholds( ['AB1FD', 'AB2FD'], 0.8, 3.2 );
    Will configure 'AB1FD' and 'AB2FD' to a shunt resistance of 3.2 Ohms 
    and all other squibs to a shunt resistance of 2.2 Ohms. 
    Current threshold is set to 0.8 A for all squibs.
    Only useful for MF Transi connected directly to squibs.
    
    2)
    LC_MeasureTraceDigitalConfigureThresholds( ['ALL'], 1.5 );
    Will configure all squibs to a current threshold of 1.5 A.
    Can be used for LCT64 or MF Transi connected to TSG4.
    
=cut

sub LC_MeasureTraceDigitalConfigureThresholds {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalConfigureThresholds( $labels_aref, $currentThreshold [, $shuntResistance ] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceDigitalGetValues

    $data_href = LC_MeasureTraceDigitalGetValues( [ $labels_aref, $constantValueThreshold, $dataCompressionFactor ] );

Return the digital data values of the labels in $labels_aref if given, otherwise the digital data values of all measurement channels that are configured by LC_MeasureTraceDigitalConfigureThresholds.
Digital data values are either 1 if the signal is above the threshold defined in LC_MeasureTraceDigitalConfigureThresholds or 0 otherwise.
It is possible to perform a data reduction algorithm on the data:
If the difference between 2 data point is < $constantValueThreshold then data points are removed until a data comression factor $dataCompressionFactor is reached.
If $dataCompressionFactor is not defined then a compression factor of 10 is used, i.e. up to 9 of 10 data points will be removed.
If $constantValueThreshold is not defined then no data compression is performed.

$data_href has the following structure:

    $data_href = {
                  <time1> => { <labelA> = <valueA1>, <labelB> = <valueB1>, ... } ,
                  <time2> => { <labelA> = <valueA2>, <labelB> = <valueB2>, ... } ,
                  ...
                };

=cut

sub LC_MeasureTraceDigitalGetValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceDigitalGetValues( [ $labels_aref, $constantValueThreshold, $dataCompressionFactor ] )', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'measure_trace_analog'

Functons for handling analog line measurements (analog information over time, e.g. TRC)

=head2 LC_MeasureTraceAnalogStart

    LC_MeasureTraceAnalogStart();

Start a new measurement and wait for trigger. Until one of the configured trigger or Software trigger(refer LC_MeasureTraceAnalogSendSWTrigger()) is obtained, 
the trace recorder will not start recording.

=cut

sub LC_MeasureTraceAnalogStart {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceAnalogStart()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceAnalogStop

    LC_MeasureTraceAnalogStop();

Stop the already running measurement, if any. If measurement is not running, no error will be returned.

=cut

sub LC_MeasureTraceAnalogStop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceAnalogStop()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceAnalogSendSWTrigger

    LC_MeasureTraceAnalogSendSWTrigger();

Trigger the trace recorder by software. The trace recorder starts recording as soon as it gets the software trigger. 
Measurement should be already started (by LC_MeasureTraceAnalogStart()) before calling this function.

=cut

sub LC_MeasureTraceAnalogSendSWTrigger {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceAnalogSendSWTrigger()', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceAnalogPlotValues

    LC_MeasureTraceAnalogPlotValues( $plotfilename [, $minWaitTime_ms] );

Plot the recorded signals for All the configured channels into UNIVIEW formatted file. (data with semi-colon seperated format)

	$plotfilename : the file name for the UNIVIEW plot
	$minWaitTime_ms : Optional wait time to wait for data to be recorded in trace recorder (used for fail-safe measurement)
	                  Has only an effect for Transient Recorder.

=cut

sub LC_MeasureTraceAnalogPlotValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceAnalogPlotValues( $plotfilename [, $minWaitTime_ms] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_MeasureTraceAnalogGetValues

    $data_href = LC_MeasureTraceAnalogGetValues( $labels_aref  [, $constantValueThreshold, $dataCompressionFactor ] );

Return the analog data values of the labels in $labels_aref if given, otherwise the digital data values of all configured measurement channels.
Analog data values are directly the values that are measured by the transient recorder.
It is possible to perform a data reduction algorithm on the data:
If the difference between 2 data point is < $constantValueThreshold then data points are removed until a data comression factor $dataCompressionFactor is reached.
If $dataCompressionFactor is not defined then a maximum compression factor of 1E7 is used, i.e. as many data points as possible will be removed.
If $constantValueThreshold is not defined then no data compression is performed.

$data_href has the following structure:

    $data_href = {
                  <time1> => { <labelA> = <valueA1>, <labelB> = <valueB1>, ... } ,
                  <time2> => { <labelA> = <valueA2>, <labelB> = <valueB2>, ... } ,
                  ...
                };
                
=cut

sub LC_MeasureTraceAnalogGetValues {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureTraceAnalogGetValues( $labels_aref  [, $constantValueThreshold, $dataCompressionFactor ] )', @args );
    return CallDeviceFunction(@args);
}

=head2 LC_ConfigureChannels

    LC_ConfigureChannels();

This function validates & configures all channels mentioned in the ProjectConst for acquisition. Configures the Trigger based on the mentioned configuration.

B<Notes:> 

Can be called only if NIDAQ is configured as 'measure_analog' in labcar Testbench.

=cut

sub LC_ConfigureChannels {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ConfigureChannels()', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'measure_once'

Function for getting the voltage measured by a oscilloscope (DSO).

=head2 LC_MeasureOnceGetVoltage

    $voltage = LC_MeasureOnceGetVoltage( [$range] );
    
Return the measured voltage in V. $range (in V) can be 0.1, 1, 10, 100, 1000. If $range is not given then autorange is used.

=cut

sub LC_MeasureOnceGetVoltage {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_MeasureOnceGetVoltage( [$range] )', @args );
    return CallDeviceFunction(@args);
}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=cut

sub Init_TSG4 {

    # check if the testbench settings for power are consistent between TSG4 and Labcar
    my $success = CrosscheckTSG4TestbenchPowerSettings();
    return 0 if not $success;

    eval "use LIFT_TSG4";
    TSG4_InitHW();
    return 1;
}

sub CrosscheckTSG4TestbenchPowerSettings {

    # no use of S_get_contents_of_hash for access to $LIFT_config::LIFT_Testbench in this function
    # because non-existance of elements can be a normal case and should not lead to error or warning
    my $ubatLC = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'power_Ubat'};
    my $success = CrosscheckSinglePowerSetting( 'Ubat', $ubatLC );
    return 0 if not $success;

    my $ufLC = $LIFT_config::LIFT_Testbench->{'Functions'}{'Labcar'}{'power_UF'};
    $success = CrosscheckSinglePowerSetting( 'UF', $ufLC );
    return 0 if not $success;
    return 1;
}

sub CrosscheckSinglePowerSetting {
    my $type     = shift;
    my $deviceLC = shift;

    # if there is no power device defined for LIFT_Labcar then we have no problem
    return 1 if not defined $deviceLC;

    my $deviceTSG4new = 'internal';
    $deviceTSG4new = 'TOE1' if $deviceLC eq 'TOE1';

    # overwrite TSG4 power settings with labcar settings
    $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{'POWER'}{$type} = $deviceTSG4new;

    return 1;
}

sub Init_MLC {
    eval "use LIFT_MLC";
    MLC_InitHW();
    return 1;
}

sub Init_PeriBox {
    S_user_action("PeriBox is selected as device for Labcar functions in LIFT_Testbenches.\nThis will be a semi-automated test run.\nPlease be prepared to operate the PeriBox manually during the test.");
    return 1;
}

sub Init_PeriBox_NoPower {
    return 1;
}

sub Init_TOE1 {
    eval "use LIFT_TOE1";
    TOE1_connect();
    return 1;
}

sub Init_TOELLNER {
    eval "use LIFT_TOELLNER";

    # init TOELLNER for each power source separately
    my $power_Ubat_device = GetConfiguredDevice('power_static_Ubat');
    my $power_UF_device   = GetConfiguredDevice('power_static_UF');

    TOE_connect('Ubat') if ( $power_Ubat_device eq 'TOELLNER' );
    TOE_connect('UF')   if ( $power_UF_device eq 'TOELLNER' );
    return 1;
}

sub Init_NIDAQ {
    eval "use LIFT_NIDAQ";
    NIDAQ_init();
    return 1;
}

sub Init_Manitoo {
    eval "use LIFT_manitoo";
    MANITOO_init();
    return 1;
}

sub Init_LA_AcuteTravelLogic {
    eval "use LIFT_LA_AcuteTravelLogic";
    LATL_InitHW();
    return 1;
}

sub Init_IDX {
    eval "use LIFT_IDEFIX";
    $IDXdevices = IDX_InitHW();
    return 1;
}

sub Init_IXS {
    eval "use LIFT_IDXSPI";
    IXS_InitHW();
    return 1;
}

sub Init_PRITT {
    eval "use LIFT_PRITT";
    PRT_init();
    return 1;
}

sub Init_GOS1 {
    eval "use LIFT_GOS1";

    my $connection = S_get_contents_of_hash( [ 'Devices', 'GOS1', 'connect' ], $LIFT_config::LIFT_Testbench );

    if ( not defined $connection ) {
        S_set_error( "GOS1 connection information in LIFT_Testbenches not found. It should be configured in \$Testbench->{'Devices'}->{'GOS1'}->{'connect'} .\n", 20 );
        return 0;
    }
    GOS1_connect($connection);
    return 1;
}

sub Init_NONE {
    S_user_action("'NONE' is selected as device for Labcar power functions in LIFT_Testbenches.\nThis will be a semi-automated test run.\nPlease be prepared to operate the power supply manually during the test.");
    return 1;
}

sub Init_wired {
    S_w2log( 1, "'wired' is selected as device for Labcar measure_connector function in LIFT_Testbenches.\nThe test cases will be run assuming that the measurement device is connected properly to the line device." );
    return 1;
}

sub Init_TRC {
    eval "use LIFT_TRC";
    TRC_InitHW();
    return 1;
}

sub Init_LCT {
    eval "use LIFT_LCT";
    LCT_InitHW();
    return 1;
}

sub Init_DMM1 {
    eval "use LIFT_DMM1";
    DMM1_connect();
    return 1;
}

sub Init_STAC {
    eval "use LIFT_STAC";
    STAC_InitHW();
    return 1;
}

sub Init_SPILC {
    my @check_inc = @INC;
    eval "use FuncLib_SPILC_Framework";
    SPILC_init();
    return 1;
}

=head2 CallDeviceFunction

    CallDeviceFunction( @args );
    
Calls a function that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.
Values of $functionMapping_href are either directly functions of the device layer if a 1:1 mapping is possible.
Otherwise a function of the package LIFT_labcar_xyz is called.

Returns the return values of the called functions. On error returns 0.

=cut

sub CallDeviceFunction {
    my @args = @_;
    return FL_CallDeviceFunction( 'labcar', $functionMapping_href, @args );
}

=head2 GetPowerSource

    $powerSource = GetPowerSource( $powerSource );

Return either "Ubat" or "UF", depending on $powerSource. Default is "Ubat".

Called by all power functions.

=cut

sub GetPowerSource {
    my $powerSource = shift;

    if ( not defined $powerSource or $powerSource eq 'Ubat' ) {
        return 'Ubat';
    }
    elsif ( $powerSource eq 'UF' ) {
        return 'UF';
    }
    else {
        S_set_error( "'\$powerSource' is set to unsupported value '$powerSource'. Supported values are: Ubat, UF", 20 );
        return;
    }

}

=head2 CreateRandomOnOffCurve

    ( $status , $volts_aref , $time_aref ) = CreateRandomOnOffCurve( $max_on_time, $min_on_time, $max_off_time, $min_off_time, $max_on_voltage, $min_on_voltage,$max_off_voltage , $min_off_voltage, $max_duration );
    e.g. CreateRandomOnOffcurve( 3000, 2000, 700, 500, 12.5, 10.8,1.5,0, 60);

create random voltage curve file (switching on and off at random voltage level for random time under given Boundary conditions).

time $max_on_time,$min_on_time,$max_off_time,$min_off_time in msec, voltage $max_on_voltage, $min_on_voltage,$max_off_voltage ,$min_off_voltage in V and $max_duration in seconds


=cut

sub CreateRandomOnOffCurve {

    my @args = @_;

    my $randon_inputs_aref = shift @args;
    my @random_curve_input = @$randon_inputs_aref;
    return 0 unless S_checkFunctionArguments( 'CreateRandomOnOffCurve( $max_on_time, $min_on_time, $max_off_time, $min_off_time, $max_on_voltage, $min_on_voltage,$max_off_voltage , $min_off_voltage, $max_duration )', @random_curve_input );

    #STEP Get all the mandatory arguments for Random curve
    my ( $max_on_time, $min_on_time, $max_off_time, $min_off_time, $max_on_voltage, $min_on_voltage, $max_off_voltage, $min_off_voltage, $max_duration ) = @random_curve_input;

    my $status = 0;
    my ( @volts, @time );

    S_w2log( 3, "createRandomOnOffCurve with Paramters :  ON($max_on_time - $min_on_time) OFF($max_off_time - $min_off_time) V_ON($max_on_voltage - $min_on_voltage) V_OFF($max_off_voltage - $min_off_voltage )  MAXduration $max_duration\n" );

    #avoid division of a not defined value
    # STEP Make appropriate unit conversion for calculations

    $max_on_time  = $max_on_time / 1000;
    $min_on_time  = $min_on_time / 1000;
    $max_off_time = $max_off_time / 1000;
    $min_off_time = $min_off_time / 1000;

    my ( $points, $duration, $on_time, $off_time, $on_voltage, $off_voltage );

    $duration = 0;
    $points   = 0;

    # STEP Generate curve points upto max duration
    while ( $duration < $max_duration and $points <= 1000 ) {
        if ( $max_on_time == $min_on_time ) {
            $on_time = $min_on_time;
        }
        else {
            $on_time = rand( $max_on_time - $min_on_time ) + $min_on_time;
        }

        if ( $max_off_time == $min_off_time ) {
            $off_time = $min_off_time;
        }
        else {
            $off_time = rand( $max_off_time - $min_off_time ) + $min_off_time;
        }

        if ( $max_on_voltage == $min_on_voltage ) {
            $on_voltage = $min_on_voltage;
        }
        else {
            $on_voltage = rand( $max_on_voltage - $min_on_voltage ) + $min_on_voltage;
        }

        if ( $max_off_voltage == $min_off_voltage ) {
            $off_voltage = $min_off_voltage;
        }
        else {
            $off_voltage = rand( $max_off_voltage - $min_off_voltage ) + $min_off_voltage;
        }

        $on_time  = sprintf( "%6.3f", $on_time );
        $off_time = sprintf( "%6.3f", $off_time );

        $on_voltage  = sprintf( "%6.3f", $on_voltage );
        $off_voltage = sprintf( "%6.3f", $off_voltage );

        $duration += ( $on_time + $off_time );
        if ( $duration < $max_duration ) {
            push( @volts, $on_voltage, $off_voltage );
            push( @time,  $on_time,    $off_time );
            $points++;
        }
    }

    $status = 1;
    S_w2log( 5, "createRandomOnOff Points status - $status \n" );

    # STEP Return the voltage and time values
    return ( $status, \@volts, \@time );
}

=head2 CreateRampCurve

    ( $status , $volt_aref, $time_aref ) = CreateRampCurve($start_V, $end_V, $time_s, [$no_of_samples]);
    e.g.
    ( $status , $volt_aref, $time_aref) = CreateRampCurve(0,1.2,1,500);
    ( $status , $volt_aref, $time_aref) = CreateRampCurve(3.0,5.2,2,500);                       

($start_V, $end_V, $time_s, $no_of_samples)

Time in seconds, start_V/end_V in volts, $no_of_samples in samples. ($no_of_samples >= 50,  <= 1000)

Time delta between 2 points has to be between 0.2 ms and 100 s.

Returns:Status, $volt_aref, $time_aref

=cut

sub CreateRampCurve {

    my @args             = @_;
    my $ramp_inputs_aref = shift @args;
    my @ramp_curve_arg   = @$ramp_inputs_aref;
    return 0 unless S_checkFunctionArguments( 'CreateRampCurve( $start_V, $end_V, $time_ms[,$no_of_samples])', @ramp_curve_arg );

    #STEP Get all the mandatory arguments for Ramp curve
    my $status = 0;
    my @volts;
    my @time;

    #checking the correctness of the inputs

    my ( $start_V, $end_V, $time_s, $no_of_samples ) = @ramp_curve_arg;

    $no_of_samples = 1000 unless ( defined $no_of_samples );

    S_w2log( 3, "CreateRampCurve with Paramters : Start voltage = $start_V  End voltage = $end_V  Time duration = $time_s no. of samples = $no_of_samples \n" );

    #STEP Check for correctness of paramters

    # IF Check for correctness of paramters no_of_samples and timedelta
    # IF-YES-START
    # IF-YES-END

    # IF-NO-START
    # STEP Set Error and return status
    # IF-NO-END

    if ( $no_of_samples < 50 ) {
        S_set_error( "too less no of samples to plot ramp : $no_of_samples < 50", 114 );
        return $status;
    }

    my $timedelta = $time_s / ( $no_of_samples - 1 );

    if ( $timedelta < 0.0002 ) {
        S_set_error( "error in RampStruct, timedelta $timedelta < 0.0002", 109 );
        return $status;
    }
    if ( $timedelta > 100 ) {
        S_set_error( "error in RampStruct, timedelta $timedelta > 100", 109 );
        return $status;
    }
    my $time_value_s = 0;
    $time_value_s += $timedelta;
    $start_V = sprintf( "%.3f", $start_V );
    push( @volts, $start_V );
    $time_value_s = sprintf( "%.4f", $time_value_s );
    push( @time, $time_value_s );

    #LOOP-START Generate ramp curve points
    # STEP Calculate voltage values and push data into array
    #LOOP-END Till end of samples

    foreach my $count ( 1 .. ( $no_of_samples - 2 ) ) {

        my $volt_value_V = $start_V + ($count) / ( $no_of_samples - 2 ) * ( $end_V - $start_V );
        $volt_value_V = sprintf( "%.3f", $volt_value_V );
        $time_value_s = sprintf( "%.4f", $time_value_s );
        push( @volts, $volt_value_V );
        push( @time,  $time_value_s );
    }

    # add last value 0V to always have same exit from curves
    push( @volts, 0 );
    push( @time,  $time_value_s );

    $status = 1;

    #STEP Return values of voltage and time
    return ( $status, \@volts, \@time );
}

=head2 Parse_CurveFile

    ( $curve_arbitrary_voltage_aref, $curve_arbitrary_time_aref ) = Parse_CurveFile($inpFH_aref);

Parses file data for voltage and corresponding time values to plot using LC_PowerPlotCurve. 

B<Arguments:>

=over

=item $inpFH_aref

Array reference of contents of the file   
	 
=back

B<Return Value:>

=over

=item Success

$curve_arbitrary_voltage_aref, $curve_arbitrary_time_aref

=item Failure 

undef

=back

B<Example:>

=over

=item 

( $curve_arbitrary_voltage_aref, $curve_arbitrary_time_aref ) = Parse_CurveFile($inpFH_aref);

=back

=cut

sub Parse_CurveFile {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Parse_CurveFile( $inpFH_aref ) )', @args );
    my $inpFH_aref = shift @args;
    my ( $curve_time, $curve_time_diff ) = 0;
    my ( @curve_arbitrary_voltage, @curve_arbitrary_time );
    my $count = 0;

    S_w2log( 5, "Parsing the curve value for voltage and time values..\n" );
    foreach my $line (@$inpFH_aref) {
        chomp($line);
        if ( $line !~ /^\s*$/x )    # checking for an empty line
        {
            #matching 'Time[s] : 0.1'
            if ( $line =~ /^Time\s*\[s\]\s*:\s*(.+)/ix ) {
                $curve_time_diff = $1;
            }

            #matching '16'
            #         '12'
            #         '13.5'
            #column being voltage values
            if ( $line =~ /^\s*(\d+)(\.?)(\d*?)\s*$/ ) {    #in case of .svtc
                chomp($line);
                push( @curve_arbitrary_voltage, $line );
                push( @curve_arbitrary_time,    $curve_time * 1000 );    #multiplication with 1000 to change it to miliseconds
                $curve_time = $curve_time + $curve_time_diff;
                $count++;
            }

            #matching '16       1.2'
            #         '12       2.2'
            #         '13.5     0.5'
            #first column being voltage values and second one being time values
            elsif ( $line =~ /^\s*(\d+\.?\d*)\s*(\d+\.?\d*)\s*$/ ) {    #incase of .sat and .txt
                push( @curve_arbitrary_voltage, $1 );
                push( @curve_arbitrary_time,    $curve_time * 1000 );    #multiplication with 1000 to change it to miliseconds
                $curve_time = $curve_time + $2;
                $count++;
            }

        }
    }

    #to extend the last value for the read last duration number of seconds
    if ( $count > 0 ) {
        $curve_arbitrary_voltage[$count] = $curve_arbitrary_voltage[ $count - 1 ];
        $curve_arbitrary_time[$count]    = $curve_time * 1000;
    }

    my $curve_arb_vol_aref  = \@curve_arbitrary_voltage;
    my $curve_arb_time_aref = \@curve_arbitrary_time;

    return ( $curve_arb_vol_aref, $curve_arb_time_aref );
}

=head2 CheckandUpdateParamters

    $modified_curveStruct_href = CheckandUpdateParamters($curveStruct_href );
    
Checks and updates paramters if no of sub curves in LC_PowerGenCurve is more than 1.

B<Arguments:>

=over

=item $curveStruct_href

for details on $curveStruct_href,  Refer : L</"LC_PowerGenCurve"> 

=back

B<Return Value:>

=over

=item ($modified_curveStruct_href)

On success : Updated paramter of $curveStruct_href
           
On error : 0

=back

=cut

sub CheckandUpdateParamters {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CheckandUpdateParamters( $curveStruct_href )', @args );
    my $curveStruct_href = shift @args;

    #STEP Get all the mandatory arguments for CheckandUpdateParamters
    my $max_samples               = 0;
    my $not_defined_ramps_samples = 0;

    #LOOP-START loop through contents of HASH and check for paramters and calculate max samples
    foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {
        my $curve_item     = $$curveStruct_href{$key_of_hash};
        my @curve_item_arg = split /:/, $curve_item;
        my $curve_type     = $curve_item_arg[0];

        shift @curve_item_arg;

        #STEP check if all paramters are numeric
        foreach (@curve_item_arg) {
            if ( $_ !~ /^\s*\d+((.|,)\d+)?\s*$/ ) {
                S_set_error( "LC_PowerGenCurve : $_ is not a valid Numeric input", 114 );
                return 0;
            }
        }

        #STEP Calculate maximum curve points from the input and calculate no of ramps for which there is no sample given
        if ( $curve_type =~ /Random$/ ) {
            foreach my $count ( 0 .. 8 ) {
                unless ( defined $curve_item_arg[$count] ) {
                    S_set_error( "check arguments : syntax : CreateRandomOnOffFile( ONmax, ONmin, OFFmax, OFFmin, Von_max, Von_min, Voff_max, Voff_min, MAXduration ) ", 114 );
                    return 0;
                }
            }
            $max_samples += ( $curve_item_arg[8] * 2 * 1000 ) / ( $curve_item_arg[1] + $curve_item_arg[3] );

            # Multiplying by 2 to include ON and OFF values in Random curve
            # Multiplying by 1000 - as MaxDuration i.e. $curve_item_arg[8] is in seconds while others are in milliseconds
        }
        elsif ( $curve_type =~ /Ramp$/ ) {
            foreach my $count ( 0 .. 2 ) {
                unless ( defined $curve_item_arg[$count] ) {
                    S_set_error( "check arguments : syntax : CreateRampCurvefile( start_V, end_V, time_s[,no_of_samples])", 114 );
                    return 0;
                }
            }
            if ( defined $curve_item_arg[3] ) {
                $max_samples += $curve_item_arg[3];
            }
            else {
                $not_defined_ramps_samples += 1;
            }
        }
        else {
            S_set_error( "LC_PowerGenCurve : Wrong Curve type given : $curve_type", 114 );
            return 0;
        }

    }

    #LOOP-END end of hash

    # IF max samples is 1000 and Not defined ramps >0
    if ( $max_samples <= 1000 && $not_defined_ramps_samples > 0 ) {

        # STEP divide the remaining curve points to rest of ramps
        my $rem_samples      = 1000 - $max_samples;
        my $samples_per_ramp = int $rem_samples / $not_defined_ramps_samples;

        if ( $samples_per_ramp < 50 ) {
            S_set_error( "LC_PowerGenCurve : Too less curve samples for undefined ramp curves to plot : $samples_per_ramp ", 114 );
            return 0;
        }

        # STEP Loop through input for all undefined ramp-sub-curves and update
        foreach my $key_of_hash ( sort { $a <=> $b } keys %{$curveStruct_href} ) {

            my $curve_item     = $$curveStruct_href{$key_of_hash};
            my @curve_item_arg = split /:/, $curve_item;
            my $curve_type     = $curve_item_arg[0];

            if ( $curve_type =~ /Ramp$/ && ( not defined $curve_item_arg[4] ) ) {
                $$curveStruct_href{$key_of_hash} .= ": $samples_per_ramp ";

            }
        }
    }

    # IF-YES-END
    # IF-NO-START
    # IF-NO-END

    # STEP Return modified input
    return $curveStruct_href;
}

=head2 GetLastVoltage

    $voltage = GetLastVoltage( $powerSource );

Return the voltage that was last set for Ubat (default) or UF.

Used in $functionMapping_href as device implementation of LC_GetVoltage for some devices.

=cut

sub GetLastVoltage {
    if ( $currentPowerSource eq 'UF' ) {
        return $lastVoltage_href->{'UF'};
    }
    else {
        return $lastVoltage_href->{'Ubat'};
    }
}

=head2 SetVoltageManually

    SetVoltageManually( $voltage, $powerSource );

Instructs the user to set a voltage manually.

Used in $functionMapping_href as device implementation of LC_SetVoltage for some devices.

=cut

sub SetVoltageManually {
    my $voltage = shift;

    S_user_action("Please set voltage on $currentPowerSource power device to $voltage V");
    return 1;
}

=head2 SetVoltageWarning

    SetVoltageWarning( $voltage, $powerSource );

Warns that the voltage can not be set by this device.

Used in $functionMapping_href as device implementation of LC_SetVoltage for some devices.

=cut

sub SetVoltageWarning {
    my $voltage = shift;
    S_set_warning("Set voltage on $currentPowerSource power device not possible");
    return 1;
}

=head2 ManualPWMDisposalStart

    ManualPWMDisposalStart( $line [, $ignoreUserAction ] );

Instructs the user to start the disposal PWM signal with ACL box.
If $ignoreUserAction = 1 then the user action will be ignored, assuming that an ACL signal is already provided.

Used in $functionMapping_href as device implementation of LC_SendPWMDisposalStart for some devices.

=cut

sub ManualPWMDisposalStart {
    my $line             = shift;
    my $ignoreUserAction = shift;

    unless ($ignoreUserAction) {
        S_user_action("Please connect and activate the disposal PWM signal on line '$line' with ACL simulator.");
    }
    return 1;
}

=head2 CalcUminUmax

    CalcUminUmax( $voltage );

This function will return the u_min and u_max values calculated from the voltage array reference passed.

B<Arguments:>

=over

=item $voltage_aref

voltage array reference from which the u_min and u_max to be calculated
	 
=back

B<Return Value:>

=over

=item $u_min,$u_max 

=back

=cut

sub CalcUminUmax {
    my $voltage = shift;

    my ( $u_max, $u_min ) = ( -1e99, 1e99 );    # Initialize to values outside anything in your list
    map { $u_max = $_ if ( $_ > $u_max ); $u_min = $_ if ( $_ < $u_min ); } @$voltage;

    return ( $u_min, $u_max );

}

=head2 ManualPWMDisposalStop

    ManualPWMDisposalStop( $line [, $ignoreUserAction ] );

Instructs the user to stop the disposal PWM signal with ACL box.
If $ignoreUserAction = 1 then the user action will be ignored, assuming that it does not matter if the ACL signal is still there.

Used in $functionMapping_href as device implementation of LC_SendPWMDisposalStop for some devices.

=cut

sub ManualPWMDisposalStop {
    my $line             = shift;
    my $ignoreUserAction = shift;

    unless ($ignoreUserAction) {
        S_user_action("Please disconnect/deactivate the disposal PWM signal on line '$line' with ACL simulator.");
    }
    return 1;
}

=head2 Check_Connection

    Check_Connection( $section, $names_aref , $which, $devType );
    
Depending on the $devType ( TSG4, STAC, MLC ) and the type of option $which the function returns the names of lines  - connected or not_connected.   

Used inside LC_Get_names to return the names of either connected lines or not_connected lines.

=cut

sub Check_Connection {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'Check_Connection( $section, $names_aref , $which, $devType );', @args );
    my $section = shift @args;
    my $names   = shift @args;
    my $which   = shift @args;
    my $devType = shift @args;

    my @dev_names_connected;
    my @dev_names_not_connected;
    my @dev_names;

    #reads entire section for the device type mentioned.
    my $section_info = S_get_contents_of_hash( [ $devType, $section ] );
    unless ( defined($section_info) ) {
        S_set_error( " $section not present for $devType in Project Defaults", 110 );
        return;
    }

    #reversing to get names of $section lines as keys to get the value as "sectionName_Name"
    my %rsection = reverse %$section_info;
    foreach (@$names) {
        my $sec_num_name    = $rsection{$_};
        my $sec_num_default = $sec_num_name;
        $sec_num_default =~ s/_Name/_Default/;    #replace Name with Default to get "sectionName_Default"
        if ( ( defined( $section_info->{$sec_num_default} ) ) && ( $section_info->{$sec_num_default} =~ /^\s*not_connected\s*$/i || $section_info->{$sec_num_default} =~ /^\s*$/ ) ) {
            push( @dev_names_not_connected, $section_info->{$sec_num_name} );    #if the "sectionName_Default" is defined and has not_connected as value or has empty value, store it as not connected lines
        }
        else {
            push( @dev_names_connected, $section_info->{$sec_num_name} );        #otherwise, store it as connecte lines
        }
    }

    if ( $which eq "NOT_CONNECTED" ) {
        @dev_names = @dev_names_not_connected;
        S_w2log( 3, " NOT_CONNECTED $section : @dev_names \n" );
    }
    else {
        @dev_names = @dev_names_connected;
        S_w2log( 3, " CONNECTED $section : @dev_names \n" );
    }
    return @dev_names;
}

sub CreateArchitectureStructure {
    return FL_CreateArchitectureStructure( 'labcar', $functionMapping_href );
}

sub LC_ConnectPowerLines {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_ConnectPowerLines()', @args );
    return CallDeviceFunction(@args);
}

sub LC_DisconnectPowerLines {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'LC_DisconnectPowerLines()', @args );
    return CallDeviceFunction(@args);
}

sub GetConfiguredDevice {
    my $functionGroup = shift;

    return FL_GetConfiguredDevice( 'labcar', $functionGroup );
}

############################################################################################################
#
#
# package LIFT_labcar_TSG4
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and TSG4_* function is not possible.

package LIFT_labcar_TSG4;

use strict;
use warnings;
use LIFT_general;
use LIFT_TSG4;
use File::Basename;

sub LC_Get_names {
    my $section = shift;
    my $which   = shift;

    #convert to uppercase if which option is defined otherwise set to empty string
    $which = ( defined $which ) ? uc($which) : '';
    my @dev_names;

    $section = 'BELT_LOCKS' if ( $section eq 'SWITCHES' );
    my @names = TSG4_get_names($section);

    my $names_aref = \@names;

    if ( ( $which eq 'CONNECTED' ) || ( $which eq 'NOT_CONNECTED' ) ) {
        @dev_names = LIFT_labcar::Check_Connection( $section, $names_aref, $which, 'TSG4' );
    }
    else {
        #return all names incase of option 'ALL' or when 'which' option is not defined
        @dev_names = @names;
        S_w2log( 3, " $section : @dev_names \n" );

    }

    return @dev_names;
}

sub LC_PowerConnect {
    return TSG4_ConnectLine('ALL_SUPPLY');
}

sub LC_PowerDisconnect {
    return TSG4_DisconnectLine('ALL_SUPPLY');
}

sub LC_PowerStopCurve {
    return TSG4_SetVoltage(0);
}

sub LC_Digital2CAN_On {
    return TSG4_PWM_Trace('on');
}

sub LC_Digital2CAN_Off {
    return TSG4_PWM_Trace('off');
}

sub LC_SetVoltage {
    my $voltage       = shift;
    my $power_source  = $LIFT_labcar::currentPowerSource;
    my $lowestVoltage = 4.3;
    if ( $voltage < $lowestVoltage ) {
        $voltage = $lowestVoltage;
    }
    return TSG4_SetVoltage( $voltage, $power_source );
}

sub LC_PowerConfigCurve {
    my $curveFile = shift;
    my $curveDuration_s;

    # check file extension
    my $satFile;
    if ( $curveFile =~ /\.sat$/i or $curveFile =~ /\.txt$/i ) {
        $satFile = $curveFile;
    }
    elsif ( $curveFile =~ /\.svtc$/i ) {
        S_w2log( 3, "LC_PowerConfigCurve: curve file '$curveFile' is svtc format. Converting to sat for TSG4...\n " );
        my ( $samples, $iteration, $time_s, $voltage_aref, $curve_name ) = LIFT_labcar_NIDAQ::Svtc2Nidaq($curveFile);
        $satFile = Array2Sat( $iteration, $time_s, $voltage_aref, $curveFile );
    }
    else {
        S_set_error( "Given curve file '$curveFile' is not supported. Supported curve files for device TSG4 are *.sat or *.svtc or *.txt.\n", 114 );
        return ( undef, undef, undef );
    }

    S_w2log( 3, "LC_PowerConfigCurve: Downloading curve file '$satFile' to TSG4...\n " );
    my ( $u_min, $u_max, $curveDuration_ms ) = TSG4_setCurveFile($satFile);

    if ($curveDuration_ms) {
        $curveDuration_s = $curveDuration_ms / 1000;
    }
    return ( $curveDuration_s, $u_min, $u_max );
}

sub Array2Sat {
    my $iteration    = shift;
    my $time_s       = shift;
    my $voltage_aref = shift;
    my $curveFile    = shift;

    # determine .sat filename from .svtc filename
    my $baseName = basename($curveFile);
    $baseName =~ s/\.svtc$/.sat/i;
    my $satFile = "c:/temp/LIFT/$baseName";

    # open .sat file for writing
    my $fh;

    # we cannot hold the file contents in a list and write the whole list in one go to the output file because that could be a very large list and lead to memory overflow; therefore a perl critics error may be unavoidable here
    ## no critic (RequireBriefOpen)
    unless ( open( $fh, '>', $satFile ) ) {
        S_set_error( "Couldn't open file '$satFile' for writing: $!\n", 1 );
        return;
    }

    # print required header for TSG4
    print( $fh "Repetitions: $iteration\n" );
    print( $fh "U[V]  t[s]\n" );

    # print .sat file data lines; repeated same voltages are combined to a single line
    my $lastVoltage        = $$voltage_aref[0];
    my $sameVoltageCounter = 0;
    foreach my $voltage (@$voltage_aref) {
        if ( $voltage != $lastVoltage ) {
            my $duration_s = $time_s * $sameVoltageCounter;
            print( $fh "$lastVoltage  $duration_s\n" );
            $sameVoltageCounter = 1;
        }
        else {
            $sameVoltageCounter++;
        }
        $lastVoltage = $voltage;
    }
    my $duration_s = $time_s * $sameVoltageCounter;
    print( $fh "$lastVoltage  $duration_s\n" );
    close $fh;
    ## use critic

    return $satFile;
}

############################################################################################################
#
#
# package LIFT_labcar_MLC
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and MLC_* function is not possible.

package LIFT_labcar_MLC;

use strict;
use warnings;
use LIFT_general;
use LIFT_MLC;

sub LC_Standby {

    S_w2log( 5, "LC_Standby has no effect on MLC.\n" );

    return 1;
}

sub LC_ShortLines {
    my $lines_aref = shift;
    my $resistance = shift;

    if ( @{$lines_aref} != 2 ) {
        S_set_error("Number of lines to be shorted must be 2 for MLC.\n");
        return 0;
    }

    # handle B+, B-, UF+, UF- for MLC
    my @renamedLines;
    foreach my $line ( @{$lines_aref} ) {
        $line =~ s/B\-/GND/;
        $line =~ s/B\+/VBAT/;
        if ( $line =~ /UF/ ) {
            $line =~ s/UF\-/GND/;
            $line =~ s/UF\+/VBAT/;
            S_set_warning("UF is not supported by MLC, using Ubatt instead.");
        }
        push( @renamedLines, $line );
    }

    MLC_ShortLine( $renamedLines[0], $renamedLines[1], $resistance );

    return 1;
}

sub LC_Get_names {
    my $section       = shift;
    my $which         = shift;
    my @valid_options = ( 'ALL', 'CONNECTED', 'NOT_CONNECTED' );

    #convert which to uppercase if defined or make it empty string if undefined
    $which = ( defined $which ) ? uc($which) : '';

    my @dev_names_connected;
    my @dev_names_not_connected;
    my @dev_names;

    $section = 'SWITCHES' if ( $section eq 'BELT_LOCKS' );
    my @names      = MLC_get_names($section);
    my $names_aref = \@names;
    if ( ( $which eq 'CONNECTED' ) || ( $which eq 'NOT_CONNECTED' ) ) {

        @dev_names = LIFT_labcar::Check_Connection( $section, $names_aref, $which, 'MLC' );
    }
    else {
        #return all names incase of option 'ALL' or when 'which' option is not defined
        @dev_names = @names;
        S_w2log( 3, " $section : @dev_names \n" );

    }

    return @dev_names;
}

sub LC_PowerConnect {
    return MLC_PSconnect('ALL');
}

sub LC_PowerDisconnect {
    return MLC_PSdisconnect('ALL');
}

############################################################################################################
#
#
# package LIFT_labcar_NIDAQ
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and NIDAQ_* function is not possible.

package LIFT_labcar_NIDAQ;

use strict;
use warnings;
use Readonly;
use Math::BigInt qw(bgcd);
use File::Basename;
use LIFT_general;
use LIFT_NIDAQ;

my $last_voltage = 0;
my $last_state   = 'OFF';

sub LC_SetVoltage {
    my $voltage = shift;

    $last_voltage = $voltage;

    if ( $last_state eq 'ON' ) {
        return NIDAQ_SetVoltage($voltage);    # sets voltage on both channels 'AO0' and 'AO1'  # call NIDAQ_SetVoltage if power is on
    }
    else {
        S_w2log( 5, "NIDAQ: Power will be set to $voltage volts and connected on next call of LC_PowerConnect.\n" );    # just change voltage variable if power is off
        return 1;
    }
}

sub LC_GetVoltage {
    return NIDAQ_GetAnalogInputVoltage('AO0');                                                                          #LC_SetVoltage sets the same voltage for both the channels(AO0 and AO1) it is enough to measure one of them and return it
}

sub LC_PowerConnect {
    $last_state = 'ON';
    return NIDAQ_SetVoltage($last_voltage);
}

sub LC_PowerDisconnect {
    $last_state = 'OFF';
    return NIDAQ_SetVoltage(0);
}

sub LC_PowerConfigCurve {
    my $curveFile = shift;

    my ( $iterationNidaq, $timeNidaq_s, $samplesNidaq );
    my ( $voltage_aref, $curve_name, $time_s_aref, $current );
    my ( $u_min, $u_max );
    if ( $curveFile =~ /\.svtc$/i ) {
        ( $samplesNidaq, $iterationNidaq, $timeNidaq_s, $voltage_aref, $curve_name ) = Svtc2Nidaq($curveFile);

        ( $u_min, $u_max ) = LIFT_labcar::CalcUminUmax($voltage_aref);
    }
    elsif ( $curveFile =~ /\.sat$/i ) {
        ( $samplesNidaq, $iterationNidaq, $time_s_aref, $voltage_aref, $current, $u_min, $u_max ) = LIFT_labcar_TOELLNER::Sat2Toe($curveFile);
        ( $samplesNidaq, $timeNidaq_s, $voltage_aref ) = Toe2nidaq( $time_s_aref, $voltage_aref );
        $curve_name = basename($curveFile);
    }
    else {
        S_set_error( "Given curve file '$curveFile' is not supported. Supported curve files for device NIDAQ are .svtc or .sat .\n", 114 );
        return ( undef, undef, undef );
    }

    my $status = NIDAQ_INITArbitrary( $iterationNidaq, $timeNidaq_s, $voltage_aref, $curve_name );
    if ( $status < 0 ) {
        S_set_error( "Error in starting the curve '$curveFile'.\n", 114 );
        return ( undef, undef, undef );
    }

    my $curveDuration_s = $samplesNidaq * $iterationNidaq * $timeNidaq_s;
    return ( $curveDuration_s, $u_min, $u_max );
}

sub Svtc2Nidaq {
    my $curveFile = shift;

    my $svtcHeader_href = {
        'Curve Name' => { 'regex' => qr{^Curve\s*Name\s*:\s*(.+)}i },    #Matching 'Curve Name : AUDI_lv124_e_01_long_term_over_voltage'
        'Samples'    => { 'regex' => qr{^Samples\s*:\s*(.+)}i },         #Matching 'Samples : 36060'
        'Iteration'  => { 'regex' => qr{^Iteration\s*:\s*(.+)}i },       #Matching 'Iteration : 1'
        'Time[s]'    => { 'regex' => qr{^Time\s*\[s\]\s*:\s*(.+)}i },    #matching 'Time[s] : 0.1'
    };

    open my $SVTCFH, '<', $curveFile or S_set_error( "Cannot open curve file $curveFile: $!.\n", 109 );
    my @svtcLines = <$SVTCFH>;
    close($SVTCFH);

    my $headerCount = 0;
    foreach my $line (@svtcLines) {

        foreach my $headerItem ( keys %{$svtcHeader_href} ) {
            my $regex = $svtcHeader_href->{$headerItem}{'regex'};
            if ( $line =~ $regex ) {
                $svtcHeader_href->{$headerItem}{'value'} = $1;
                last;
            }
        }

        #Matching 'U[V]'
        # after U[V] the data start, so strip off the header and keep the rest in the list
        if ( $line =~ /U\[V\]/ix ) {
            splice( @svtcLines, 0, $headerCount + 1 );
            last;
        }
        $headerCount++;
    }

    # cut off \n from the entire data list
    chomp(@svtcLines);

    # check if header is correct
    foreach my $headerItem ( keys %{$svtcHeader_href} ) {
        if ( not defined $svtcHeader_href->{$headerItem}{'value'} ) {
            S_set_error( "SVTC file '$curveFile' does not contain $headerItem \n", 114 );
            return ( 0, 0, [], 0 );
        }
    }

    my $samples    = $svtcHeader_href->{'Samples'}{'value'};
    my $dataPoints = scalar(@svtcLines);
    if ( $samples != $dataPoints ) {
        S_set_error( "In SVTC file '$curveFile' the number of data points ($dataPoints) does not match the 'Samples' in the header ($samples) \n", 114 );
        return ( 0, 0, [], 0 );
    }

    return ( $samples, $svtcHeader_href->{'Iteration'}{'value'}, $svtcHeader_href->{'Time[s]'}{'value'}, \@svtcLines, $svtcHeader_href->{'Curve Name'}{'value'} );
}

sub Toe2nidaq {
    my $time_s_aref  = shift;
    my $voltage_aref = shift;

    Readonly my $SCALAR_FACTOR => 1000000;    # allow time samples until 0.000001s / 1us

    my @times_us = map { int( $_ * $SCALAR_FACTOR + 0.5 ) } @$time_s_aref;    # round to next integer to avoid consequences of inaccuracies in the representation of float numbers (e.g. 3.3 = 3.29999999999999980000)
    my $time_us_gcd = bgcd(@times_us);                                        # get greatest common divisor
    $time_us_gcd = $time_us_gcd->numify();

    my @voltagesIn = @{$voltage_aref};
    my @voltagesOut;

    foreach my $time_us (@times_us) {
        my $voltage = shift @voltagesIn;
        my $count   = int( $time_us / $time_us_gcd + 0.1 );
        push @voltagesOut, ($voltage) x $count;
    }

    my $time_s = $time_us_gcd / $SCALAR_FACTOR;

    return ( scalar(@voltagesOut), $time_s, \@voltagesOut );
}

sub LC_PowerStartCurve {
    return NIDAQ_StartArbitrary( 0, 0, 0 );    # call NIDAQ_StartArbitrary without any waiting time
}

############################################################################################################
#
#
# package LIFT_labcar_TOE1
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and TOE1_* function is not possible.

package LIFT_labcar_TOE1;

use strict;
use warnings;
use Readonly;
use LIFT_general;
use LIFT_TOE1;

sub LC_PowerConfigCurve {
    my $curveFile = shift;

    my ( $samples, $iteration, $time_s_aref, $voltage_aref, $current, $time_s, $curve_name );

    my ( $u_min, $u_max );
    if ( $curveFile =~ /\.sat$/i ) {
        ( $samples, $iteration, $time_s_aref, $voltage_aref, $current, $u_min, $u_max ) = LIFT_labcar_TOELLNER::Sat2Toe($curveFile);
    }
    elsif ( $curveFile =~ /\.svtc$/i ) {
        ( $samples, $iteration, $time_s, $voltage_aref, $curve_name ) = LIFT_labcar_NIDAQ::Svtc2Nidaq($curveFile);
        ( $time_s_aref, $voltage_aref, $samples ) = LIFT_labcar_TOELLNER::Nidaq2Toe( $time_s, $voltage_aref );
        $current = 2;    # set current limit hard to 2A
        ( $u_min, $u_max ) = LIFT_labcar::CalcUminUmax($voltage_aref);
    }
    else {
        S_set_error( "Given curve file '$curveFile' is not supported. Supported curve files for device TOE1 are *.sat or *.svtc .\n", 114 );
        return ( undef, undef, undef );
    }

    my $curveDuration_s = TOE1_initArbitrary( $samples, $iteration, $time_s_aref, $voltage_aref, $current );

    return ( $curveDuration_s, $u_min, $u_max );
}

############################################################################################################
#
#
# package LIFT_labcar_TOELLNER
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and TOE_* function is not possible.

package LIFT_labcar_TOELLNER;

use strict;
use warnings;
use Readonly;
use LIFT_general;
use LIFT_TOELLNER;

sub LC_PowerConfigCurve {
    my $curveFile    = shift;
    my $power_source = $LIFT_labcar::currentPowerSource;

    my ( $samples, $iteration, $time_s_aref, $voltage_aref, $current, $time_s, $curve_name );
    my ( $u_min, $u_max );
    if ( $curveFile =~ /\.sat$/i ) {
        ( $samples, $iteration, $time_s_aref, $voltage_aref, $current, $u_min, $u_max ) = Sat2Toe($curveFile);
    }
    elsif ( $curveFile =~ /\.svtc$/i ) {
        ( $samples, $iteration, $time_s, $voltage_aref, $curve_name ) = LIFT_labcar_NIDAQ::Svtc2Nidaq($curveFile);
        ( $time_s_aref, $voltage_aref, $samples ) = Nidaq2Toe( $time_s, $voltage_aref );
        $current = 2;    # set current limit hard to 2A
        ( $u_min, $u_max ) = LIFT_labcar::CalcUminUmax($voltage_aref);
    }
    else {
        S_set_error( "Given curve file '$curveFile' is not supported. Supported curve files for device TOE1 are *.sat or *.svtc .\n", 114 );
        return ( undef, undef, undef );
    }

    my $curveDuration_s = TOE_initArbitrary( $power_source, $samples, $iteration, $time_s_aref, $voltage_aref, $current );
    return ( $curveDuration_s, $u_min, $u_max );
}

sub Sat2Toe {
    my $curveFile = shift;

    Readonly my $NUMBER     => qr{ [-+]? [0-9]* \.? [0-9]+ }xms;
    Readonly my $TWONUMBERS => qr{ ($NUMBER) \s+ ($NUMBER) }xms;

    my $satHeader_href = {
        'Dateiname'       => { 'regex' => qr{^(Dateiname|Filename)\s*:\s+(.+)}i },                     #Matching 'Dateiname:     ...'
        'Punkte'          => { 'regex' => qr{^(Punkte|Points)\s*:\s*(.+)}i },                          #Matching 'Punkte:     3'
        'Strombegrenzung' => { 'regex' => qr{^(Strombegrenzung|Current Limitations)\s*:\s*(.+)}i },    #Matching 'Strombegrenzung: 2.00'
        'Wiederholungen'  => { 'regex' => qr{^(Wiederholungen|Repetitions)\s*:\s*(.+)}i },             #matching 'Wiederholungen: 1'

    };

    open my $SATFH, '<', $curveFile or S_set_error( "Cannot open curve file $curveFile: $!.\n", 109 );
    my @svtcLines = <$SATFH>;
    close($SATFH);

    my ( @voltages, @times_s );
    foreach my $line (@svtcLines) {

        foreach my $headerItem ( keys %{$satHeader_href} ) {
            my $regex = $satHeader_href->{$headerItem}{'regex'};
            if ( $line =~ $regex ) {
                $satHeader_href->{$headerItem}{'value'} = $2;
                last;
            }
        }

        #Matching 10.800000	4.000000 : first number is voltage (in V), second number is time (in s)
        if ( $line =~ $TWONUMBERS ) {
            push( @voltages, $1 );
            push( @times_s,  $2 );
        }

    }

    #identify the minimum and maximum voltage value to do DSO settings
    my ( $u_max, $u_min ) = ( -1e99, 1e99 );    # Initialize to values outside anything in your list
    map { $u_max = $_ if ( $_ > $u_max ); $u_min = $_ if ( $_ < $u_min ); } @voltages;

    # check if header is correct
    foreach my $headerItem ( keys %{$satHeader_href} ) {
        if ( not defined $satHeader_href->{$headerItem}{'value'} ) {
            S_set_error( "SAT file '$curveFile' does not contain $headerItem \n", 114 );
            return ( 0, 0, [], 0 );
        }
    }

    my $samples    = $satHeader_href->{'Punkte'}{'value'};
    my $dataPoints = scalar(@voltages);
    if ( $samples != $dataPoints ) {
        S_set_error( "In SAT file '$curveFile' the number of data points ($dataPoints) does not match the 'Punkte' in the header ($samples) \n", 114 );
        return ( 0, 0, [], 0 );
    }
    return ( $satHeader_href->{'Punkte'}{'value'}, $satHeader_href->{'Wiederholungen'}{'value'}, \@times_s, \@voltages, $satHeader_href->{'Strombegrenzung'}{'value'}, $u_min, $u_max );
}

sub Nidaq2Toe {
    my $time_s         = shift;
    my $voltageIn_aref = shift;

    my ( $lastVoltage, @voltages, @times_s );

    my $samples          = 0;
    my $sameValueCounter = 0;
    foreach my $voltage ( @{$voltageIn_aref} ) {
        $sameValueCounter++;
        if ( defined $lastVoltage and $voltage == $lastVoltage ) {

            # nothing
        }
        else {
            $samples++;
            push( @voltages, $voltage );
            push( @times_s, $sameValueCounter * $time_s ) if defined $lastVoltage;
            $lastVoltage      = $voltage;
            $sameValueCounter = 0;
        }

    }

    push( @times_s, ( $sameValueCounter + 1 ) * $time_s );

    return ( \@times_s, \@voltages, $samples );
}

sub LC_PowerStartCurve {
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_runCurve( $power_source, 0 );
}

sub LC_PowerStopCurve {
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_stopCurve($power_source);
}

sub LC_PowerStartCurveOnTrigger {
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_runCurve( $power_source, 1 );
}

sub LC_SetVoltage {
    my $voltage      = shift;
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_VOLTAGE( $power_source, $voltage );
}

sub LC_PowerConnect {
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_ON($power_source);
}

sub LC_PowerDisconnect {
    my $power_source = $LIFT_labcar::currentPowerSource;

    return TOE_OFF($power_source);
}

sub LC_Exit {

    # exit TOELLNER for each power source separately
    my $power_Ubat_device = LIFT_labcar::GetConfiguredDevice('power_static_Ubat');
    my $power_UF_device   = LIFT_labcar::GetConfiguredDevice('power_static_UF');

    TOE_disconnect('Ubat') if ( $power_Ubat_device eq 'TOELLNER' );
    TOE_disconnect('UF')   if ( $power_UF_device eq 'TOELLNER' );
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_PeriBox
#
#
############################################################################################################

# Define here PeriBox functions.

package LIFT_labcar_PeriBox;

use strict;
use warnings;
use LIFT_general;

sub LC_ConnectLine {
    my $line = shift;
    S_user_action("Please (re-)connect line '$line' on PeriBox.");
    return 1;
}

sub LC_DisconnectLine {
    my $line = shift;
    S_user_action("Please disconnect line '$line' on PeriBox.");
    return 1;
}

sub LC_PowerConnect {
    my $line = shift;
    S_user_action("Please (re-)connect all power lines on PeriBox.");
    return 1;
}

sub LC_PowerDisconnect {
    my $line = shift;
    S_user_action("Please disconnect all power lines on PeriBox.");
    return 1;
}

sub LC_ShortLines {
    my $lines_aref = shift;
    my $resistance = shift;
    $resistance = 0 if not defined $resistance;
    S_user_action("Please short lines '@$lines_aref' via $resistance Ohms on PeriBox.");
    return 1;
}

sub LC_UndoShortLines {
    S_user_action("Please undo the last short lines activity on PeriBox.");
    return 1;
}

sub LC_SetLogicalState {
    my $switch = shift;
    my $state  = shift;
    S_user_action("Please set switch '$switch' to state '$state' on PeriBox.");
    return 1;
}

sub LC_SetResistance {
    my $label      = shift;
    my $resistance = shift;
    S_user_action("Please set resistance '$resistance Ohms' for line '$label' on PeriBox.");
    return 1;
}

sub LC_SetCurrent {
    my $label        = shift;
    my $currentvalue = shift;
    S_user_action("Please set current equal to '$currentvalue mA' for line '$label' on PeriBox.");
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_Manitoo
#
#
############################################################################################################

# Define here Manitoo functions.

package LIFT_labcar_Manitoo;

use strict;
use warnings;
use LIFT_general;
use LIFT_manitoo;

sub LC_PowerConnect {
    return MANITOO_FET_power_on();
}

sub LC_PowerDisconnect {
    return MANITOO_FET_power_off();
}

sub LC_SetVoltage {
    my $voltage = shift;

    S_set_warning(" VOLTAGE '$voltage' V will not be set on Manitoo - (Not really) \n ");
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_IDX
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and IDX_* function is not possible.

package LIFT_labcar_IDX;

use strict;
use warnings;
use LIFT_IDEFIX;

sub LC_PowerConnect {
    foreach my $iDXdevice ( 0 .. $IDXdevices - 1 ) {
        IDX_SetOutput( $iDXdevice, 1, 1 );
    }
    return 1;
}

sub LC_PowerDisconnect {
    foreach my $iDXdevice ( 0 .. $IDXdevices - 1 ) {
        IDX_SetOutput( $iDXdevice, 0, 0 );
    }
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_IXS
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and IXS_* function is not possible.

package LIFT_labcar_IXS;

use strict;
use warnings;
use LIFT_IDXSPI;

sub LC_PowerConnect {
    IXS_SetOutput( 1, 1 );
    return 1;
}

sub LC_PowerDisconnect {
    IXS_SetOutput( 0, 0 );
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_NONE
#
#
############################################################################################################

# Define here functions for power device NONE.

package LIFT_labcar_NONE;

use strict;
use warnings;
use LIFT_general;

sub LC_PowerConnect {
    S_user_action("Please switch ON power at manual $currentPowerSource power device.");
    return 1;
}

sub LC_PowerDisconnect {
    S_user_action("Please switch OFF power at manual $currentPowerSource power device.");
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_TRC
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and TRC_* function is not possible.

package LIFT_labcar_TRC;

use strict;
use warnings;
use LIFT_general;
use LIFT_TRC;

my $channelConfiguration_href;
my $measurementStarted = 0;

sub LC_MeasureTraceDigitalConfigureThresholds {
    my $labels_aref      = shift;
    my $currentThreshold = shift;
    my $shuntResistance  = shift;

    my @labels = @{$labels_aref};

    # get transi channel definitions from project const
    my $transiChannels_href = S_get_contents_of_hash( [ 'TRANSI', 'CHANNELS' ] );
    if ( not defined $transiChannels_href ) {
        S_set_error( "'TRANSI'->'CHANNELS' not configured in project const. \n", 114 );
        return 0;
    }

    # create a list with all defined chanels
    my @allChannels;
    foreach my $channel ( keys %{$transiChannels_href} ) {
        my $channelName = $transiChannels_href->{$channel}{'ChannelName'};
        push( @allChannels, $channelName ) if defined $channelName;
    }

    if ( scalar(@labels) == 1 and $labels[0] eq 'ALL' ) {
        @labels = @allChannels;
    }

    foreach my $channel (@labels) {
        $channelConfiguration_href->{$channel}{'currentTreshold'} = $currentThreshold;
        $channelConfiguration_href->{$channel}{'shuntResistance'} = $shuntResistance if defined $shuntResistance;
    }

    return 1;
}

sub LC_MeasureTraceDigitalGetValues {
    my $labels_aref            = shift;
    my $constantValueThreshold = shift;
    my $dataCompressionFactor  = shift;

    my $data_href = MeasureTraceGetValues( 'digital', $labels_aref, $constantValueThreshold, $dataCompressionFactor );    # call eventually TRC_get_values( ... ); keep this comment, it is used for architecture documentation

    return $data_href;
}

sub LC_MeasureTraceAnalogGetValues {
    my $labels_aref            = shift;
    my $constantValueThreshold = shift;
    my $dataCompressionFactor  = shift;

    my $data_href = MeasureTraceGetValues( 'analog', $labels_aref, $constantValueThreshold, $dataCompressionFactor );     # call eventually TRC_get_values( ... ); keep this comment, it is used for architecture documentation

    return $data_href;
}

sub MeasureTraceGetValues {
    my $type                   = shift;
    my $labels_aref            = shift;
    my $constantValueThreshold = shift;
    my $dataCompressionFactor  = shift;

    my $digital;
    if ( $type =~ /digital/i ) {
        $digital = 1;
    }
    else {
        $digital = 0;
    }

    if ($digital) {
        my @allLabels = keys %{$channelConfiguration_href};
        $labels_aref = \@allLabels if not defined $labels_aref;
    }

    my $data_href = TRC_get_values( $labels_aref, 1000, 'HoH', $constantValueThreshold, $dataCompressionFactor );

    return $data_href if not $digital;

    foreach my $time ( sort { $a <=> $b } keys %{$data_href} ) {
        foreach my $signal ( keys %{ $data_href->{$time} } ) {
            my $value = $data_href->{$time}{$signal};

            my $threshold = $channelConfiguration_href->{$signal}{'currentTreshold'};
            if ( not defined $threshold ) {
                S_set_error( "For channel $signal there is no currentTreshold defined. Please use the function LC_MeasureTraceDigitalConfigureThresholds to define a threshold. \n", 114 );
                return {};
            }

            if ( $value > $threshold ) {
                $value = 1;
            }
            else {
                $value = 0;
            }

            $data_href->{$time}{$signal} = $value;
        }
    }
    return $data_href;
}

sub LC_MeasureTraceDigitalStart {
    if ( not $measurementStarted ) {
        TRC_StartMeasurement();
    }
    $measurementStarted = 1;
    return 1;
}

sub LC_MeasureTraceDigitalStop {
    if ($measurementStarted) {
        TRC_StopMeasurement();
    }
    $measurementStarted = 0;
    return 1;
}

sub LC_MeasureTraceAnalogStart {
    if ( not $measurementStarted ) {
        TRC_StartMeasurement();
    }
    $measurementStarted = 1;
    return 1;
}

sub LC_MeasureTraceAnalogStop {
    if ($measurementStarted) {
        TRC_StopMeasurement();
    }
    $measurementStarted = 0;
    return 1;
}

############################################################################################################
#
#
# package LIFT_labcar_STAC
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and STAC_* function is not possible.

package LIFT_labcar_STAC;

use strict;
use warnings;
use LIFT_general;
use LIFT_STAC;

sub LC_Get_names {
    my $section = shift;
    my $which   = shift;

    #convert the which to uppercase if defined else make it empty string
    $which = ( defined $which ) ? uc($which) : '';

    my @dev_names_connected;
    my @dev_names_not_connected;
    my @dev_names;

    $section = 'MEASURED_SQUIBS' if ( $section eq 'SQUIBS' );

    my @names      = STAC_GetNames($section);
    my $names_aref = \@names;
    if ( ( $which eq 'CONNECTED' ) || ( $which eq 'NOT_CONNECTED' ) ) {

        @dev_names = LIFT_labcar::Check_Connection( $section, $names_aref, $which, 'STAC' );

    }
    else {
        #return all names incase of option 'ALL' or when 'which' option is not defined
        @dev_names = @names;
        S_w2log( 3, " $section : @dev_names \n" );
    }
    return @dev_names;
}

sub LC_PowerConnect {
    return STAC_ConnectLine('ALL_SUPPLY');
}

sub LC_PowerDisconnect {
    return STAC_DisconnectLine('ALL_SUPPLY');
}

############################################################################################################
#
#
# package LIFT_LA_AcuteTravelLogic
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of LC_* function and LATL_* function is not possible.
package LIFT_labcar_LATL;

use strict;
use warnings;
use LIFT_LA_AcuteTravelLogic;

sub LC_MeasureTraceDigitalPlotValues {
    my @args = @_;

    my $fileName         = shift @args;
    my $fileNameTemplate = shift @args;
    my $fileFormat       = shift @args;
    my $title            = shift @args;
    my $data_href        = shift @args;
    return LATL_plot_values( $fileName, $fileNameTemplate, $fileFormat, $title, $data_href );
}

sub LC_MeasureTraceDigitalStart {
    my @args = @_;

    my $inArgs_href = shift @args;
    return LATL_StartMeasurement($inArgs_href);
}

1;
__END__
