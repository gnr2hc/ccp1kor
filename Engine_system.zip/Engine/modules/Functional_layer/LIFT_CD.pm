# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_CD;

use strict;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_ODIS ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  CD_check_fault_status
  CD_clear_DTC
  CD_DumpDTCTable
  CD_evaluate_faults
  CD_exit
  CD_get_fault_status
  CD_get_FaultDTC
  CD_getEDIDdata
  CD_init
  CD_parseEDID
  CD_read_DTC
  CD_send_message
  CD_send_request_wait_response
  CD_send_request_get_all_response_timestamp
  CD_set_addressing_mode
  CD_start_simulation
  CD_stop_message
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_CD 

Perl extension for managing different Diagnostic Communication(DCOM).

=head1 SYNOPSIS

  use LIFT_CD;

    CD_init();
    CD_start_simulation();
    ('0x7f4', '0x6dc', '0x7f7', 10000) = CD_set_addressing_mode( 'disposal' );
    $response_aref = CD_send_request_wait_response( [0x19,0x2,0x20], 0x03);
    (1, $response_timestamp_href) = CD_send_request_get_all_response_timestamp( [0x19,0x2,0x20], 0x03);
    $DTC_struct = CD_read_DTC('defaultsubfunc','defaultstate');
    $response_aref = CD_clear_DTC( );
    CD_DumpDTCTable($DTC_struct);
    CD_evaluate_faults( $DTC_struct, ['FltWB1DResistanceOpen','FltSABDTerminalShort2Gnd'],['FltBT1RPCrossCoupled','FltAB2FPCrossCoupled'] );
    CD_check_fault_status($DTC_struct, 'FltAB2FPCrossCoupled', '0bxx1xxxxx');
    S_wait_ms(1000);
    $EDIDstruct = CD_parseEDID([0x62, 0xFA, 0x13, 0x00, 0x00, 0x00, 0x01, 0xAB],"SUPPLIER",'strict');
    $EDIDdata_aref = CD_getEDIDdata($EDIDstruct,'Event Type','SUPPLIER');
    CD_exit();

=head1 DESCRIPTION

Perl extension for Customer Diagnosis using either CAN (Vector box) or ODIS tool (VW/Audi customer tool).

=head1 CONFIGURATION

=head2 Testbench Configuration (LIFT_Testbenches.pm)

=head3 Devices section

If you use CANcaseXL for diagnosis no extra setting is required, settings of PD will be used.

If you use VN89xx or VN16xx for diagnosis you have to specify CANHWSerialNo and CANchannel.

B<Important note> for CANchannel: for CD only CAN channels are counted, so if CH1,2 = LIN and CH3,4 = CAN then 
CANchannel = 1 if CH3 is used and CANchannel = 2 if CH4 is used.
B<The way of counting is different for PD!> 
So it can happen that the same physical channel has different 'CANchannel' numbers for PD and CD  

    'Devices' => {
        ...
        'CD' => {
                'CANchannel' => 1,
                'CANHWSerialNo' => 28761,           #e.g. for serial no 007129-028761
            },
        
        # when configured function for CD = 'CANoeFR' or 'CANoeCANFD'  
        'CAN_Access' => {
            'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
             'stimulate' => 'CANoe',    # function groups: Stimulate signals ,CAPL
        },
            
        ...
    },

=head3 Functions section

    'Functions' => {
        ...
        'CD' => 'CAN',  # either 'CAN' (CD via vector vxlapi) 
                        # or 'CANoeFR' (CD via CANoe FlexRay - Diagnosis panel and CAPL)
						# or 'CANoeCANFD' (CD via CANoe CANFD - Diagnosis panel and CAPL)
        ...
    },


Alternative (for backwards compatibility):

    'Functions' => {
        ...
        'Diagnosis' => 'CAN', #either 'CAN' (for CD via vector vxlapi) or 'ODIS' (for CD via ODIS tool)
        ...
    },

=head2 Project Constant

   'CUSTOMER_DIAGNOSIS' => {
        'RequestID_physical' => '0x6dc',          #as hex string
        'ResponseID_physical' => '0x4fc',         #as hex string
        'FlowControlID_physical' => '0x6dc',      #as hex string
        'Timeout_physical' => 10000,              #in milliseconds
        'P3_mintime_physical' => 200 ,              #in milliseconds(by default its 0)        
         
        'AddressingMode_physical' => [ 0x10, 0x53],  # 2 bytes as array ref (req. only for CD via FlexRay)
        'TesterAddress_physical'  => [ 0x0E, 0xF8 ], # 2 bytes as array ref (req. only for CD via FlexRay)
        

        'RequestID_functional' => '0x6dc',          #as hex string
        'ResponseID_functional' => '0x4fc',         #as hex string
        'FlowControlID_functional' => '0x6dc',      #as hex string
        'Timeout_functional' => 10000,              #in milliseconds
        'P3_mintime_functional' => 400,              #in milli seconds (by default its 0)
         
        'AddressingMode_functional' => [ 0xFF, 0xFF ], # 2 bytes as array ref (req. only for CD via FlexRay)
        'TesterAddress_functional'  => [ 0xEF, 0xEF ], # 2 bytes as array ref (req. only for CD via FlexRay)
        
        'FlowControl' => [0x30,0x0f,0x01],       #3 Bytes as array ref
        'clearDTC' => [0x14,0xff,0xff,0xff],     #Bytes as array ref
        'SAM' => 1,
        'SJW' => 3,
        'Tseg1' => 0xc,
        'Tseg2' => 3,
        'Baudrate' => 500000,
        'DLCmode' => 0,                     # 0 for 8 byte, 1 for dynamic DLC
        'DTCdefaultstate' => 0x8,
        'DTCdefaultsubfunction' => 0x2,
        'DTCbytes' => 3,                    # bytes per DTC
        'ExtID' => 0,                       # 1 for Extended Identifier, 0 for Standard
        'ExtAddressing' => 1,               # 1 for Extended Addressing, 0 for Normal
        'EcuAddr' => 0x01,                  # ECU id for Extended Addressing.
        'TargetAddr' => 0xF1,               # Target address for Extended Addressing.

        'DISABLE' => 1,                 # optional, to disable all CD features (similar to offline mode)
    },

B<Fault Status Byte - Bit Description: (ISO bits)>

    Bit 0: Test Failed (Filtered)
    Bit 1: Test Failed This Operation Cycle (Latched)
    Bit 2: Pending
    Bit 3: Confirmed DTC (Stored)
    Bit 4: Test Not Completed Since Last Clear
    Bit 5: Test Failed Since Last Clear
    Bit 6: Test Not Completed This Operation Cycle
    Bit 7: Warning Lamp Indicator

=cut

######################################################################################################################
# Datastructures and variables used  across different functions in LIFT_CD
#######################################################################################################################

my $CD_initialised = 0;    #flag to indicate whether Diag is initialized using CD_init()
my $CFG_diag;
my ( $DLCmode, $DTCdefaultstate, $DTCdefaultsubfunction, $ClearDTC, $DTCbytes, %FLT2DTC, %DTC2FLT );
my ( $CD_RequestID, $CD_FlowControlID, $CD_ResponseID, $CD_Timeout );
my $dummy_href = { '1' => '1' };
my $Dynamic_load_module;

my $module_name = __PACKAGE__;

######################################################################################################################
# Definition of functions in LIFT_CD
#######################################################################################################################

=head1 Function Group 'base'

=head2 CD_exit

    Function Name    :: CD_exit
    Description      :: closes the established diagnostics connection
    Syntax           :: CD_exit();
    Input Arguments  :: None
    Return Value(s)  :: 0 - Error
    Example          :: CD_exit();

    B<Note:> call this function in END campaign.

=cut

sub CD_exit
{
    #     S_w2log( 5, " CD_exit : Closing Diagnostics\n" );  # added comment below

    unless ($CD_initialised)
    {
        S_set_error( " CD_exit: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    #
    # here was error before
    #

    my $func = "CD_" . $CFG_diag . "_exit";

    unless ( exists &$func )
    {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_exit : Calling function $func \n" );

    $func = \&$func;    #address reference of the function
    $func->();          #call the function

    #
    #  TODO : what are result values and do they mean ?  no result check here ??
    #

    $CD_initialised = 0;    #reset flag

    S_w2log( 5, " CD_exit : Customer Diagnostics is not initialized anymore\n" );

    return 1;
}

=head2 CD_init

    Function Name    :: CD_init
    Description      :: This function will initialise the either ODIS communication or CD communication which is configured in LIFT Testbench.
    Syntax           :: CD_init();
    Input Arguments  :: None
    Return Value(s)  :: 0 - Error
    Example          :: CD_init();

    B<Note:> call this function in INIT campaign.

=cut

sub CD_init {
    S_w2log( 4, " CD_init : Initialise Customer Diagnostics\n" );

    my $testbench = $LIFT_config::LIFT_Testbench;
    $CFG_diag              = $testbench->{'Functions'}{'CD'};
    $CFG_diag              = $testbench->{'Functions'}{'Diagnosis'} if not defined $CFG_diag;
    $DTCdefaultstate       = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCdefaultstate'};
    $DTCdefaultsubfunction = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCdefaultsubfunction'};
    $DTCbytes              = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'DTCbytes'};
    $ClearDTC              = $main::ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'clearDTC'};

    # check whether Testbench->{'Functions'}{'Diagnosis'} is defined, if not assume it as 'CAN'
    unless ( defined $CFG_diag ) {

        #provide a warning & assume the 'CFG_diag' as CAN
        S_set_warning("Testbench->{'Functions'}{'CD'} or Testbench->{'Functions'}{'Diagnosis'} not found. Taking default as 'CAN' & proceeding to use LIFT_CD_CAN");
        $CFG_diag = 'CAN';
    }

    unless ( defined $DTCdefaultstate )       { S_set_error( "! DTCdefaultstate for DIAGNOSIS not found in ProjectConst )",       114 ); return; }
    unless ( defined $DTCdefaultsubfunction ) { S_set_error( "! DTCdefaultsubfunction for DIAGNOSIS not found in ProjectConst )", 114 ); return; }
    unless ( defined $ClearDTC )              { S_set_error( "! ClearDTC for DIAGNOSIS not found in ProjectConst )",              114 ); return; }
    my $FLTfile;

    %FLT2DTC = {};
    %DTC2FLT = ();
    {
        no warnings;
        $FLTfile = $LIFT_config::SAD_file;
    }

    S_w2log( 5, " CD_init: preparing DTC mapping from flt file\n" );    # added function name

    $FLTfile =~ s/\.sad$/.flt/i;
    unless ( -f $FLTfile ) {
        S_set_error( "$FLTfile does not exist", 1 );
        return;
    }

    unless ( open( IN, "<$FLTfile" ) ) {
        S_set_error( "could not read $FLTfile", 1 );
        return 0;
    }

    while ( my $line = <IN> ) {

        #e.g. 1,FltIdleMode,90EF49
        if ( $line =~ /^\d+,(\S+),(\S+)/ ) {
            my $dtc_num = $2;
            $dtc_num     = hex($dtc_num);
            $dtc_num     = sprintf( "%06X", $dtc_num );
            $FLT2DTC{$1} = $dtc_num;
        }
    }
    close(IN);

    foreach my $flt ( keys %FLT2DTC ) {
        push( @{ $DTC2FLT{ $FLT2DTC{$flt} } }, $flt );
    }

    my @supported_CFG_diag = qw (CAN CANoeFR CANoeCANFD);
    unless ( grep ( /^$CFG_diag$/i, @supported_CFG_diag ) ) {
        S_set_error( "ERROR : wrong/unsupported configuration : CD_init: Testbench->{'Functions'}{'CD'} = '$CFG_diag'. Supported are '@supported_CFG_diag'. \n", 20 );
        return;
    }

    # if CD already initialized, return warning
    if ($CD_initialised) {
        S_set_warning(" CD_init: Diagnostics already initialized!");
        return 1;
    }

    $Dynamic_load_module = "LIFT_CD_" . $CFG_diag;

    S_w2log( 5, " CD_init: Eval Dynamic module $Dynamic_load_module \n" );    # added printout
    #check if the $Dynamic_load_module module exists
    unless ( eval "require $Dynamic_load_module" ) {
        S_set_error( "File $Dynamic_load_module not found in current search PATHs (or) Failed to Load : $@\n", 120 );
        return 0;
    }

    S_w2log( 5, " CD_init: starting dynamic module import \n" );    # added printout

    $Dynamic_load_module->import();
    my $func = "CD_" . $CFG_diag . "_init";
    unless ( exists &$func ) {
        S_set_error( "$func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_init: Calling function $func \n" );            # added printout

    $func = \&$func;                                                #address reference of the function
    $func->();                                                      #call the function

    #
    #  TODO : what are result values and do they mean ?  no result check here ??
    #

    $CD_initialised = 1;

    S_w2log( 4, " CD_init: Customer Diag is initialized \n" );    # added printout

    return 1;
}

=head2 CD_send_message

    $MSG_handle = CD_send_message( $payload_aref, $ID, $cycletime );

Send cyclic message with interval $cycletime.

B<Arguments:>

=over

=item $payload_aref 

CAN message bytes to be sent.

=item $ID 

CAN ID to send the CAN message.

=item $cycletime 

cycletime in milliseconds ( 0 = Send only once, non-zero = send continuously with $cycletime as interval time).

=back

B<Return Value:>

=over

=item $MSG_handle 

Error return : 0

Success return : $MSG_handle.

=back

B<Examples:>

     $MSG_handle = CD_send_message( $payload_aref, $ID, $cycletime );          
     
B<Note:> use L</CD_stop_message>() to stop cyclic message sending

=cut

sub CD_send_message
{
    my @arguments = @_;

    my $MSG_handle;

    #     S_w2log( 5, "CD_send_message\n" );    # printout not required (added one below)

    unless ($CD_initialised)
    {
        S_set_error( " CD_send_message: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    my $func = "CD_" . $CFG_diag . "_send_message";
    unless ( exists &$func )
    {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_send_message : Calling function $func ( @arguments ) \n" );    #  added printout

    $func       = \&$func;                                                          #address reference of the function
    $MSG_handle = $func->(@arguments);                                              #call the function

    #
    #  TODO : what are result values and do they mean ?
    #

    S_w2log( 4, " CD_send_message : Return MSG_handle (?) \n" );    #  added printout

    return $MSG_handle;
}

=head2 CD_send_request_wait_response

    ($response_status, $response_bytes_aref) = CD_send_request_wait_response($Request[,$options_href] );     

Sends the given request bytes to ECU and waits for response for the given mode of diag communication.

B<Arguments:>

=over

=item $Request 

Array reference to the request array

=item $options_href 

(optional) This is a hash reference containing the values for optional parameters.

Below are the optional parameters in the hash reference
           
=> $options_href->{'Manipulated_length'} : This holds the value to manipulate the request length(valid range = 0-255(0x00-0xFF))
                                           and if the value is not provided , then the request length will not be manipulated.

=back

B<Return Value:>

=over

=item $response_status 

Success : Returns the status of the response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

Returns 3 if Got no response

Error : undef

=item $response_bytes_aref 

Success : Response bytes obtained from ECU

Error : []

=back

B<Examples:>

    (2, [0x7F, 0x19, 0x12]) = CD_send_request_wait_response([0x19,0x1,0x20]);
    
    $options_href->{'Manipulated_length'} = 0x03
    (1, [20],[0x7F, 0x19, 0x12]) = CD_send_request_wait_response( [0x19,0x1,0x20], $options_href);

=cut

sub CD_send_request_wait_response {

    ### DESIGN  ###

    # COMMENT-START
    # get arguments
    # mandatory :
    # - $Request,
    # optional
    # - $options_href ($options_href->{'Manipulated_length'})
    # COMMENT-END

    # IF $manipulated_length is defined ?
    #IF-YES-START
    # Pass the request and the manipulated length to the lower level function(CD_CAN_send_request_wait_response)
    # IF Request is Single frame ?
    # IF-NO-START
    # STEP Second Byte of the request frame will be replaced with the $manipulated_length
    # IF-NO-END
    # IF-YES-START
    # STEP First Byte of the request frame will be replaced with the $manipulated_length
    # IF-YES-END
    #IF-YES-END
    #IF-NO-START
    # STEP The length of the request will not be manipulated
    #IF-NO-END
    # STEP Return status and response array

    my @args = @_;
    return ( undef, [] ) unless S_checkFunctionArguments( 'CD_send_request_wait_response( $request_aref [,$options_href] )', @args );

    my $request_aref = shift @args;
    my $options_href = shift @args;

    #     S_w2log( 5, " CD_send_request_wait_response : Send Request\n" );     # printout not required  (added one below)

    unless ($CD_initialised) {
        S_set_error( " CD_send_request_wait_response: Diagnostics not initialized. Please call CD_init first", 20 );
        return ( undef, [] );
    }

    if ( ref($request_aref) ne "ARRAY" ) {
        S_set_error( " CD_send_request_wait_response : request_aref is not an array reference", 114 );
        return ( undef, [] );
    }

    my $func = "CD_" . $CFG_diag . "_send_request_wait_response";

    unless ( exists &$func ) {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return ( undef, [] );
    }

    S_w2log( 4, " CD_send_request_wait_response : Calling function $func ( @$request_aref ) \n" );    #  added printout

    my ( $response_bytes_aref, $response_time_aref, $response_status );

    $func = \&$func;                                                                                  #address reference of the function
    ( $response_status, $response_time_aref, $response_bytes_aref ) = $func->( $request_aref, $options_href );

    #
    #  TODO : what are result values and do they mean ?
    #

    S_w2log( 4, " CD_send_request_wait_response : Return Response : @$response_bytes_aref \n" );    #  added printout

    return ( $response_status, $response_bytes_aref );
}

=head2 CD_send_request_get_all_response_timestamp

    ($status, $response_timestamp_href) = CD_send_request_get_all_response_timestamp( $request_aref [,$options_href] )     

Sends request and waits for response. Sends flow control, if response is of Multiple frames (response code : 0x78)

Fetches all types of response(negative/positive/pending) and their coressponding inter-Can-frame timings 

B<Arguments:>

=over

=item $request_aref 

Array reference to the request array

=item $options_href 

(optional) This is a hash reference containing the values for optional parameters.

Below are the optional parameters in the hash reference
           
=> $options_href->{'Manipulated_length'} : This holds the value to manipulate the request length(valid range = 0-255(0x00-0xFF))
                                           and if the value is not provided , then the request length will not be manipulated.

=back

B<Return Value:>

=over

=item $status 

Success : Returns the status of the obtained response

Returns 0 if Got positive response

Returns 1 if Got response after pending

Returns 2 if Got negative response

Returns 3 if Got no response

Offline : 1

Error : undef

=item $response_timestamp_href 

Success : Returns Hash reference of all response and their respective inter-CAN-frame timings (with precision of +2 or -2 ms) in milliseconds
          $response_timestamp_href->{$response_sequence}->{time} = [response];

Offline : {}

Error : undef

=back

B<Examples:>

    (1, $response_timestamp_href) = CD_send_request_get_all_response_timestamp( [0x19,0x1,0x20] );
    
    $options_href->{'Manipulated_length'} = '0x03'
    (1, $response_timestamp_href) = CD_send_request_get_all_response_timestamp( [0x19,0x1,0x20], $options_href);

=cut

sub CD_send_request_get_all_response_timestamp {

    ### DESIGN  ###

    # COMMENT-START
    # get arguments
    # mandatory :
    # - $Request,
    # optional
    # - $options_href ($options_href->{'Manipulated_length'})
    # COMMENT-END

    # IF $manipulated_length is defined ?
    #IF-YES-START
    # Pass the request and the manipulated length to the lower level function(CD_CAN_send_request_fetch_all_response_timestamp)
    # IF Request is Single frame ?
    # IF-NO-START
    # STEP Second Byte of the request frame will be replaced with the $manipulated_length
    # IF-NO-END
    # IF-YES-START
    # STEP First Byte of the request frame will be replaced with the $manipulated_length
    # IF-YES-END
    #IF-YES-END
    #IF-NO-START
    # STEP The length of the request will not be manipulated
    #IF-NO-END

    # Get the hash reference containing all response and their respective inter can frame timings from lower level function(CD_CAN_send_request_wait_response)

    # STEP Return status and response array

    my @args = @_;
    return ( undef, undef ) unless S_checkFunctionArguments( 'CD_send_request_get_all_response_timestamp( $request_aref [,$options_href] )', @args );

    my $request_aref = shift @args;
    my $options_href = shift @args;

    unless ($CD_initialised) {
        S_set_error( " CD_send_request_get_all_response_timestamp : Diagnostics not initialized. Please call CD_init first", 20 );
        return ( undef, undef );
    }

    my $func = "CD_" . $CFG_diag . "_send_request_get_all_response_timestamp";

    unless ( exists &$func ) {
        S_set_error( " CD_send_request_get_all_response_timestamp : $func function not found in package $Dynamic_load_module\n", 22 );
        return ( undef, undef );
    }

    S_w2log( 4, " CD_send_request_get_all_response_timestamp : Calling function $func ( @$request_aref ) \n" );    #  added printout

    my ( $response_timestamp_href, $response_status );

    $func = \&$func;                                                                                            #address reference of the function
    ( $response_status, $response_timestamp_href ) = $func->( $request_aref, $options_href );

    return ( $response_status, $response_timestamp_href );
}

=head2 CD_set_addressing_mode

    $returnValue = CD_set_addressing_mode($address_mode);

sets the addressing mode to $address_mode

B<Arguments:>

=over

=item $address_mode 

Address mode to be set. shall be either physical, functional or disposal (case insensitive).
For CD , it could also be disposal.

=back

B<Return Value:>

=over

=item $returnValue 

Error return : 0

Success return : Returns RequestID, FlowControlID, ResponseID, Timeout values and P3_mintime of the corresponding Addressing mode, which is set.

=back

B<Examples:>

     $returnValue = CD_set_addressing_mode('physical');  

=cut

sub CD_set_addressing_mode
{
    my $address_mode = shift;
    my @return_value;

    #    S_w2log( 5, " CD_set_addressing_mode : setting addressing Mode\n" );      # printout not required  (added one below)

    unless ( defined $address_mode )
    {
        S_set_error( "! too less parameters ! SYNTAX: CD_set_addressing_mode($address_mode)", 110 );
        return 0;
    }

    unless ($CD_initialised)
    {
        S_set_error( " CD_set_addressing_mode: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }
    my $func = "CD_" . $CFG_diag . "_set_addressing_mode";
    unless ( exists &$func )
    {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_set_addressing_mode: Calling function $func ( $address_mode )\n" );    # added printout in order to show what will be called

    $func         = \&$func;                                                                #address reference of the function
    @return_value = $func->($address_mode);                                                 #call the function

    #
    #  TODO : what are result values and do they mean ?
    #

    S_w2log( 4, " CD_set_addressing_mode: return @return_value \n" );    # added printout

    return @return_value;
}

=head2 CD_start_simulation

    Function Name    :: CD_start_simulation
    Description      :: This will start either ODIS communication or CD simulation depending on the LIFT Testbench config.
    Syntax           :: CD_start_simulation([@arguments]);
    Input Arguments  :: arguments - could be CANscript to start communication (used only in CD_CAN). This field is Optional.
                        No arguments for CD_ODIS.
    Return Value(s)  :: 0 - failure
    Example          :: CD_start_simulation([$CANscript]);

    B<Note:> call this function in INIT campaign after CD_init();

=cut

sub CD_start_simulation
{
    my @arguments = @_;

    #     S_w2log( 5, " CD_start_simulation : start Simulation\n" );   # printout not required (added one below)

    unless ($CD_initialised)
    {
        S_set_error( " CD_start_simulation: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }
    my $func = "CD_" . $CFG_diag . "_start_simulation";

    unless ( exists &$func )
    {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_start_simulation: Calling function $func with arguments : @arguments \n" );    # added printout in order to show what will be called

    $func = \&$func;                                                                                #address reference of the function
    my @result = $func->(@arguments);                                                               #call the function

    #
    #  TODO : what are result values and do they mean ?
    #

    S_w2log( 5, " CD_stop_message: Result '@result' \n" );    # added printout of result

    return 1;
}

######################################################

=head2 CD_stop_message

    Function Name    :: CD_stop_message
    Description      :: stop cyclic message referred by $MSG_handle
    Syntax           :: CD_stop_message( $MSG_handle );
    Input Arguments  :: $MSG_handle - message handle of the message to be stopped
    Return Value(s)  :: 1 - Success , 0 - failure
    Example          :: $CD_stop_message( $MSG_handle );

=cut

sub CD_stop_message
{
    my @arguments = @_;

    #     S_w2log( 5, "CD_stop_message\n" );     # printout not required (added on below)

    unless ($CD_initialised)
    {
        S_set_error( " CD_stop_message: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    my $func = "CD_" . $CFG_diag . "_stop_message";
    unless ( exists &$func )
    {
        S_set_error( " $func function not found in package $Dynamic_load_module\n", 22 );
        return 0;
    }

    S_w2log( 4, " CD_stop_message: Calling function $func with arguments : @arguments \n" );    # added printout in order to show what will be called

    $func = \&$func;                                                                            #address reference of the function
    my @result = $func->(@arguments);                                                           #call the function

    #
    #  TODO : what are result values and do they mean ?
    #

    S_w2log( 5, " CD_stop_message: Result '@result' \n" );    # added printout of result

    return 1;
}

=head1 Function Group 'fault'

=head2 CD_check_fault_status

    $returnValue = CD_check_fault_status( $DTC_struct, $fault_name, $expected_states );

Sets PASS if the status byte for $fault_name matches $expected_states, else FAIL
Sets ERROR if $fault_name not found
Calls internally for each matching DTC in $DTC_struct
EVAL_evaluate_value ( $DTC,  $found_status, '==', $expected_states  );

B<Arguments:>

=over

=item $DTC_struct 

Fault structure (returned from CD_read_DTC() function).

=item $fault_name 

Fault name as in Fault file.

=item $expected_states 

Expected_states can be dec, hex or as bitmask.

=back

B<Return Value:>

=over

=item $returnValue 

Error return : 0

Offline : 1

Success return : 1

=back

B<Examples:>

     $returnValue = CD_check_fault_status($DTC_struct, 'FltAB2FPCrossCoupled', '0bxx1xxxxx');   

=cut

sub CD_check_fault_status
{
    my $DTC_struct      = shift;
    my $fault_name      = shift;
    my $expected_states = shift;

    S_w2log( 4, " CD_check_fault_status\n" );

    unless ( defined $expected_states )
    {
        S_set_error( "too less parameters ,SYNTAX: CD_check_fault_status( \$DTC_struct, \$fault_name, \$expected_states ) ", 110 );
        return 0;
    }

    if ( ref($DTC_struct) ne "HASH" )
    {
        S_set_error( " DTC_struct is not a hash reference", 114 );
        return 0;
    }

    unless ($CD_initialised)
    {
        S_set_error( " CD_check_fault_status: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    my $DTC = $FLT2DTC{$fault_name};
    unless ( defined $DTC )
    {
        S_set_error( "! error; $fault_name not found in .flt file", 20 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my $found_count = 0;

    my @states = @{ $DTC_struct->{'state'} };
    my @DTCs   = @{ $DTC_struct->{'DTC'} };

    foreach my $index ( 0 .. @DTCs - 1 )
    {
        # compare each DTC in lowercase (case insensitive)
        if ( hex( $DTCs[$index] ) == hex($DTC) )
        {
            $found_count++;
            LIFT_evaluation::EVAL_evaluate_value( "STATUS($found_count)_" . $DTC, $states[$index], '==', $expected_states );
        }
    }

    if ( $found_count == 0 )
    {
        LIFT_evaluation::EVAL_evaluate_value( "STATUS(DTC not found)_" . $DTC, 0, '==', $expected_states );
    }

    return 1;
}

=head2 CD_clear_DTC

    Function Name    :: CD_clear_DTC
    Description      :: sends request for clear fault memory taken from ProjectConst.
                        IDs will be taken from CD_set_addressing_mode.
    Syntax           :: $response_aref = CD_clear_DTC( );
    Input Arguments  :: None
    Return Value(s)  :: $response_aref - ECU response for ClearDTC request
    Example          :: $response_aref = CD_clear_DTC( );

 Project constants setting:

    'CUSTOMER_DIAGNOSIS' => {
        'clearDTC' => [0x14,0xff,0xff,0xff],     #Bytes as array ref
    }

=cut

sub CD_clear_DTC
{
    #     S_w2log( 4, "CD_clear_DTC\n" );   # comment added below

    if ( ref($ClearDTC) ne "ARRAY" )
    {
        S_set_error( " clearDTC in ProjectConst is not an array reference", 114 );
        return 0;
    }

    unless ($CD_initialised)
    {
        S_set_error( " CD_clear_DTC: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    S_w2log( 4, " CD_clear_DTC: Send request ClearDTC\n" );

    my $data_aref = CD_send_request_wait_response($ClearDTC);

    S_w2log( 4, " CD_clear_DTC: Resturn response @$data_aref \n" );

    # call project specific function
    return ($data_aref);

}

=head2 CD_DumpDTCTable

    Function Name    :: CD_DumpDTCTable
    Description      :: Reads the DTC structure of CD and generates the HTML table
    Syntax           :: CD_DumpDTCTable($DTC_struct);
    Input Arguments  :: $DTC_struct
                    $DTC_struct = {
                                    "response"   => 'type',
                                    "DTC"        => [@DTC],
                                    "state"      => [@states]
                                  }

    Return Value(s)  :: Error return (0)

=cut

sub CD_DumpDTCTable
{
    S_w2log( 4, "CD_DumpDTCTable\n" );

    my $DTC_struct = shift;

    my ( $DTC, $DTCstate, $item, @states, @state_text, @table, $text, $data_aref );

    unless ( defined $DTC_struct ) {
        S_set_error( "! too less parameters ! SYNTAX: CD_DumpDTCTable($DTC_struct)", 110 );
        return 0;
    }

    unless ( ref $DTC_struct eq "HASH" ) {
        S_set_error( "DTC_struct is not a hash reference", 114 );
        return 0;
    }

    unless ( exists( $DTC_struct->{'state'} ) ) {
        S_set_error( " \$DTC_struct->{'state'} does not exists", 114 );
        return 0;
    }

    unless ( exists( $DTC_struct->{'DTC'} ) ) {
        S_set_error( " \$DTC_struct->{'DTC'} does not exists", 114 );
        return 0;
    }

    if ( S_check_array( $DTC_struct->{'state'}, "\$DTC_struct->{'state'}" ) == 0 ) {
        S_set_error( "S_check_array reported state key error", 114 );
        return 0;
    }

    if ( S_check_array( $DTC_struct->{'DTC'}, "\$DTC_struct->{'DTC'}" ) == 0 ) {
        S_set_error( "S_check_array reported DTC key error", 114 );
        return 0;
    }

    my @DTCs = @{ $DTC_struct->{'DTC'} };

    unless (@DTCs) {
        S_set_error( "DTCs are not present in structure DTC_struct->{'DTC'}", 114 );
        return 0;
    }

    my $found_DTC = scalar(@DTCs);

    S_w2log( 4, " CD_DumpDTCTable: $found_DTC DTCs is\are found in Structure DTC_struct->{'DTC'}" );

    @states = @{ $DTC_struct->{'state'} };

    unless (@states) {
        S_set_error( " states are not present in structure DTC_struct->{'state'}", 114 );
        return 0;
    }

    my $found_state = scalar(@states);

    S_w2log( 4, " CD_DumpDTCTable: $found_state states is\are found in Structure DTC_struct->{'state'}" );

    if (@states) {
        my $table_fields = [ 'DTC', 'DTC Status', 'WIR 7', 'TNCTOC 6', 'TFSLC 5', 'TNCSLC 4', 'CDTC 3', 'PDTC 2', 'TFTOC 1', 'TF 0' ];
        my $table = S_TableCreate($table_fields);

        for ( $item = 0 ; $item < @states ; $item++ ) {
            my $bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
            $bits =~ tr/01/-X/;
            my @bittext = split( //, $bits );
            S_TableAddRow( $table, [ $DTC_struct->{"DTC"}[$item], $states[$item], @bittext ] );

        }

        S_TablePrint( CONSOLE|TEXT|HTML|4, $table, 'CD_DumpDTCTable' );
    }

    return 1;
}

=head2 CD_evaluate_faults

    Function Name    :: CD_evaluate_faults
    Description      :: This function evaluates the faults present in fault memory according to the given condition (Mandatory , Optional or disjunction).
                        fault names will be mapped to DTCs for evaluation.
    Syntax           :: VERDICT = CD_evaluate_faults( $DTC_struct, $mandatory_faults_aref, [ $optional_faults_aref, $disjunction_faults_aref ] );
                        VERDICT = CD_evaluate_faults( $DTC_struct, [] ); # will check for empty fault memory
    Input Arguments  :: mandatory: all faults have to be in fault memory (all)
                        optional: all faults may be in fault memory (0-all)
                        disjunction : faults will be treated as optional faults
                        a violation of the conditions above or any other fault will set verdict fail
    Return Value(s)  :: returns VERDICT_PASS - if all expected faults found AND there is no other fault entry
                        returns VERDICT_FAIL - if additional fault entries found or missing mandatory faults or both
                        returns 0 - upon error
    Example          :: CD_evaluate_faults( $DTC_struct, ['FltWB1DResistanceOpen','FltSABDTerminalShort2Gnd'],['FltBT1RPCrossCoupled','FltAB2FPCrossCoupled'] );

=cut

sub CD_evaluate_faults
{
    S_w2log( 4, " CD_evaluate_faults\n" );

    my $flt_struct               = shift;
    my $given_mandatory_faults   = shift;
    my $given_optional_faults    = shift;
    my $given_disjunction_faults = shift;

    my ( @expected_mandatory_list, @expected_optional_list, @expected_disjunction_list,    @remaining_faults,      %unify );
    my ( @found_mandatory_list,    @found_optional_list,    @found_disjunction_list,       %found_additional_list, @found_DTCs );
    my ( $fault,                   $faultname,              $flag_not_all_mandatory_found, $FCMoth,                $text, $flag_not_one_disjunction_found, $eval_keyword );
    my $OPTcomment = "";
    $eval_keyword = 'CU_FAULTS';

    unless ($CD_initialised)
    {
        S_set_error( " CD_evaluate_faults: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    # if less than $flt_mem_struct $given_mandatory_faults  -> set error
    unless ( defined $given_mandatory_faults )
    {
        S_set_error( " too less parameters ! SYNTAX: CD_evaluate_faults( DTC_struct , mandatory_faults_aref, [ optional_faults_aref, disjunction_faults_aref ])", 110 );
    }

    if ( ref($flt_struct) ne "HASH" )
    {
        S_set_error( " DTC_struct is not a hash reference", 114 );
        return 0;
    }

    if ( ref($given_mandatory_faults) ne "ARRAY" )
    {
        S_set_error( " mandatory_faults_aref is not an array reference", 114 );
        return 0;
    }

    @expected_mandatory_list = @$given_mandatory_faults;

    if ( defined $given_optional_faults )
    {
        if ( ref($given_optional_faults) ne "ARRAY" )
        {
            S_set_error( " optional_faults_aref is not an array reference", 114 );
            return 0;
        }
        @expected_optional_list = @$given_optional_faults;
    }

    if ( exists $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} )
    {
        S_w2log( 5, " Add project defined optional faults '" . @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } . "'\n" );
        push( @expected_optional_list, @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } );
        $OPTcomment = " with TEMP_OPTIONAL_FAULTS" if @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} };
    }

    # set disjunction_faults as optional !
    if ( defined $given_disjunction_faults )
    {
        if ( ref($given_disjunction_faults) ne "ARRAY" )
        {
            S_set_error( " disjunction_faults_aref is not an array reference", 114 );
            return 0;
        }
        push( @expected_optional_list, @$given_disjunction_faults );
    }

    {
        no warnings;

        # map flts to dtcs and unify list
        my $DTC;
        %unify = ();
        foreach (@expected_mandatory_list)
        {
            $DTC = $FLT2DTC{$_};
            S_set_error( "! error; $_ not found in .flt file", 20 ) unless ( defined $DTC );
            $unify{$DTC} = 1;
        }
        @expected_mandatory_list = keys(%unify);

        if (@expected_optional_list)
        {
            %unify = ();
            foreach (@expected_optional_list)
            {
                $DTC = $FLT2DTC{$_};
                S_set_error( "! error; $_ not found in .flt file", 20 ) unless ( defined $DTC );
                $unify{$DTC} = 1;
            }
            @expected_optional_list = keys(%unify);
        }

        %unify = ();
        foreach ( @{ $flt_struct->{'DTC'} } )
        {
            $unify{$_} = 1;
        }
        @found_DTCs = keys(%unify);
    }

    foreach $fault (@found_DTCs)
    {
        #add fault to additional fault list, using hash to avoid double occurence and make deleting easy !
        $found_additional_list{$fault} = 1;
    }

    foreach $faultname (@expected_mandatory_list)
    {
        foreach $fault (@found_DTCs)
        {
            if ( $faultname eq $fault )
            {
                push( @found_mandatory_list, $fault );

                #delete fault from additional fault list
                delete $found_additional_list{$fault};
            }
        }
    }

    foreach $faultname (@expected_optional_list)
    {
        foreach $fault (@found_DTCs)
        {
            if ( $faultname eq $fault )
            {
                push( @found_optional_list, $fault );

                #delete fault from additional fault list
                delete $found_additional_list{$fault};
            }
        }
    }

    $flag_not_all_mandatory_found = $FCMoth = $flag_not_one_disjunction_found = 0;

    $flag_not_all_mandatory_found = 1 if ( scalar(@expected_mandatory_list) != scalar(@found_mandatory_list) );

    my @missing_mandatory_faults  = grep{ not $_ ~~ @found_mandatory_list } @expected_mandatory_list;
    
    $FCMoth = 1 if ( scalar( keys(%found_additional_list) ) != 0 );
    @remaining_faults = keys(%found_additional_list);

    $flag_not_one_disjunction_found = 1 if ( scalar(@found_disjunction_list) == 0 );

    $text = "\nCD_evaluate_faults$OPTcomment\n MAND: @expected_mandatory_list\n OPT: @expected_optional_list\n";

    ###########   SECTION FOR EVALUATION TABLE  #############

    if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} ) {
        my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
        my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
    
        S_add2eval_collection( $eval_keyword, "$expect_marker @expected_mandatory_list (mand)" );
    
        if (@expected_optional_list)
        {
            S_add2eval_collection( $eval_keyword, "$expect_marker @expected_optional_list (opt)" );
        }
    
        S_add2eval_collection( $eval_keyword, "$detect_marker @found_DTCs" );
    }
    
    ### all variants without @expected_disjunction_list
    ### OK case
    if (     not $flag_not_all_mandatory_found
         and not $FCMoth
         and not @expected_disjunction_list )
    {
        $text .= "      => OK -> all expected faults found AND there is no other fault entry\n";
        S_w2rep($text);
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
    ### FAIL cases
    elsif (     not $flag_not_all_mandatory_found
            and $FCMoth
            and not @expected_disjunction_list )
    {
        $text .= "      => FAIL -> because of additional other entries: @remaining_faults\n";
        S_w2rep($text);
        S_add2eval_collection( 'MISMATCH', "Found additional other entries: @remaining_faults" ) if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and not $FCMoth
            and not @expected_disjunction_list )
    {
        $text .= "      => FAIL -> because of missing mandatory faults: @missing_mandatory_faults\n";
        S_w2rep($text);
        S_add2eval_collection( 'MISMATCH', "Missing mandatory faults: @missing_mandatory_faults" ) if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and $FCMoth
            and not @expected_disjunction_list )
    {
        $text .= "      => FAIL -> because of missing mandatory faults: @missing_mandatory_faults AND additional other entries: @remaining_faults\n";
        S_w2rep($text);
        S_add2eval_collection( 'MISMATCH',"Missing mandatory faults: @missing_mandatory_faults AND additional other entries: @remaining_faults" ) if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
}

=head2 CD_get_fault_status

    $status = CD_get_fault_status( $DTC_struct, $fault_name_or_DTC);

returns the status byte for corresponding fault or DTC in hex e.g. 0x1f
returns 0, if given fault name or DTC does not exists

B<Arguments:>

=over

=item $DTC_struct 

Fault structure (returned from CD_read_DTC() function).

=item $fault_name_or_DTC 

Fault name (or) DTC.

=back

B<Return Value:>

=over

=item $status 

Error return : 0

Offline : 1

Success return : the status byte

=back

B<Examples:>

     $status = CD_get_fault_status($DTC_struct, 'FltAB2FPCrossCoupled'); 
     $status = CD_get_fault_status($DTC_struct, '90EF49');  

=cut

sub CD_get_fault_status
{
    my $DTC_struct        = shift;
    my $fault_name_or_DTC = shift;

    S_w2log( 5, " CD_get_fault_status : looking for Fault Status in DTC structure\n" );

    unless ( defined $fault_name_or_DTC )
    {
        S_set_error( "! too less parameters ! SYNTAX: CD_get_fault_status($DTC_struct,$fault_name_or_DTC)", 110 );
        return 0;
    }

    if ( ref($DTC_struct) ne "HASH" )
    {
        S_set_error( " DTC_struct is not a hash reference", 114 );
        return 0;
    }

    unless ($CD_initialised)
    {
        S_set_error( " CD_read_DTC: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    my $DTC = $fault_name_or_DTC;

    # if $DTC is not in the HEX form, it indicates that a Fault name is passed in parameter. So, retrieve the corresponding DTC from FaultDTC mapping from .flt file
    unless ( $DTC =~ /^[0-9A-F]+$/i )
    {
        $DTC = $FLT2DTC{$DTC};
    }

    # this case will be executed if Fault name is provided for $fault_name_or_DTC instead of DTC & that fault name is not found in .flt file
    unless ( defined $DTC )
    {
        S_set_error( "! error; Fault name $fault_name_or_DTC not found in .flt file", 20 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my @states = @{ $DTC_struct->{'state'} };
    my @DTCs   = @{ $DTC_struct->{'DTC'} };

    foreach my $index ( 0 .. @DTCs - 1 )
    {
        # compare each DTC in lowercase (case insensitive)
        if ( hex( $DTCs[$index] ) == hex($DTC) )
        {
            #if DTC matches, then return the corresponding state from states array
            my $status = $states[$index];
            S_w2log( 4, " CD_get_fault_status: '$fault_name_or_DTC' has status $status\n" );
            return ($status);
        }
    }

    #if DTC is not found, then state is returned as '0'
    S_w2log( 4, " CD_get_fault_status: '$fault_name_or_DTC' not found in provided DTC_struct\n" );
    return 0;
}

=head2 CD_get_FaultDTC

    Function Name    :: CD_get_FaultDTC
    Description      :: Returns the DTC from the fault file for the given Fault Name.
    Syntax           :: $fault_DTC = CD_get_FaultDTC ( $fault_name );
    Input Arguments  :: $fault_name - Fault Name whose $fault_DTC will be returned
    Return Value(s)  :: $fault_DTC : Fault DTC of $fault_name
    Example          :: $fault_DTC = CD_get_FaultDTC ( 'FltWB1DResistanceOpen' );

=cut

sub CD_get_FaultDTC
{
    my $fault_name = shift;

    #     S_w2log( 5 , "CD_get_FaultDTC : \n" );    # printout done below

    unless ( defined($fault_name) )
    {
        S_set_error( 'too less parameters ,SYNTAX: CD_get_FaultDTC( $fault_name )', 110 );
        return 0;
    }
    unless ($CD_initialised)
    {
        S_set_error( " CD_read_DTC: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    my $fault_DTC = $FLT2DTC{$fault_name};

    unless ( defined $fault_DTC )
    {
        S_set_error( "! error; $fault_name not found in .flt file", 20 );
        return 0;
    }

    S_w2log( 4, "CD_get_FaultDTC: $fault_name -> $fault_DTC \n" );    # added printout with more info

    return $fault_DTC;
}

=head2 CD_read_DTC

    Function Name    :: CD_read_DTC
    Description      :: read DTCs (19 SUBFUNC STATE) and return refernce to DTC fault memory structure
                        ID will be taken from CD_set_addressing_mode
                        can be accessed like $DTC_struct->{"state"}[1] ; $DTC_struct->{"DTC"}[1] ;
    Syntax           :: $DTC_struct = CD_read_DTC( $subfunction [, $state ] );
    Input Arguments  :: $subfunction - Subfunction in ReadDTC service
                        $state - State in ReadDTC service
    Return Value(s)  :: $DTC_struct - DTC structure (structure given below)
    Example          :: eg 1 : $DTC_struct = CD_read_DTC('defaultsubfunc'[,'defaultstate']);
                        This will read the 'defaultsubfunc' and 'defaultstate' from Project Constants.
                        eg 2 : $DTC_struct = CD_read_DTC( '02', '08');

     $DTC_struct = {
          "response"   => 'type',
          "DTC"        => [@DTC],
          "state"      => [@states],
          "fault_text" => [@faultTexts]}

    offline_return :  {"response"   => 'offline',
                     "DTC"        => [],
                     "state"      => [],
                     "fault_text" => [],}

   "response" can be
        - "PR" (positive response)
        - "NRC" (negative response)
        - "unknown" (incase of timeout, error)

=cut

sub CD_read_DTC {

    #     S_w2log( 5, " CD_read_DTC \n" );    # newline was missing   / printout not required

    my $subfunction = shift;
    my $state       = shift;
    my $DTC_struct  = { "response" => 'init', "DTC" => [], "state" => [] };
    my ( $DTC, $DTCstate, @states, @table, $item, $text );

    unless ( defined $subfunction ) {
        S_set_error( "! too less parameters ! SYNTAX: CD_read_DTC($subfunction,$state)", 110 );
        return 0;
    }
    unless ($CD_initialised) {
        S_set_error( " CD_read_DTC: Diagnostics not initialized. Please call CD_init first", 20 );
        return 0;
    }

    $state       = $DTCdefaultstate       if ( $state =~ /^defaultstate$/i );
    $subfunction = $DTCdefaultsubfunction if ( $subfunction =~ /^defaultsubfunc$/i );

    return {
             "response" => 'offline',
             "DTC"      => [],
             "state"    => [],
             "fault_text" => [],
      }
      if $main::opt_offline;

    S_w2log( 3, " CD_read_DTC : Sending request '0x19' ( subfunction : $subfunction ; state : $state ) \n" );    # added printout here
    my $data_aref = CD_send_request_wait_response( [ '0x19', $subfunction, $state ] );
    my @DTCs = @$data_aref;
    if ( scalar(@DTCs) <= 2 ) { # Try a second time in case no response received on first try
        S_w2log(4, "CD_read_DTC : No response received for request '0x19' ( subfunction : $subfunction ; state : $state ), send service again \n");
        $data_aref = CD_send_request_wait_response( [ '0x19', $subfunction, $state ] );        
        @DTCs = @$data_aref;
    }
    
    if( scalar(@DTCs) <= 2 ){
        $DTC_struct->{"response"} = 'unknown';
        S_set_error( "wrong response format after second try (<3 bytes) - @DTCs -", 102 );
        return ($DTC_struct);       
    }

    #
    #  TODO : following deep if-structure to be reworked !
    #

    foreach (@DTCs) { $_ = sprintf( "%02X", $_ ); }

    my $resp = shift(@DTCs);    # drop pos/neg response
    if ( $resp eq '59' ) {
        $DTC_struct->{"response"} = 'PR';
        shift(@DTCs);           # drop subfunc
        shift(@DTCs);           # drop supported states info

        # if not multiple of ($DTCbytes+1)
        if ( ( scalar @DTCs ) % ( $DTCbytes + 1 ) != 0 ) {
            S_set_error( "wrong response format (bytes -@DTCs-not mutliple of $DTCbytes+1)", 102 );
        }

        while (@DTCs) {
            $DTC = join( '', splice( @DTCs, 0, $DTCbytes ) );
            $DTCstate = shift(@DTCs);
             
            if(exists $DTC2FLT{$DTC}){
             push( @{ $DTC_struct->{"DTC"} },   $DTC );
             push( @{ $DTC_struct->{"state"} }, "0x" . $DTCstate );
             push( @{ $DTC_struct->{"fault_text"} }, join( '<br>', @{ $DTC2FLT{$DTC} } ) );
            }
            else{
             S_set_warning("CD_read_DTC : Skipping $DTC! as it is not present in the fault file");
            }
        }

        S_w2log( 3, " CD_read_DTC : returned " . scalar( @{ $DTC_struct->{"DTC"} } ) . " DTCs\n" );
        @states = @{ $DTC_struct->{'state'} };

        if (@states) {
            my $table_fields = [ 'DTC', 'DTC Status', 'WIR 7', 'TNCTOC 6', 'TFSLC 5', 'TNCSLC 4', 'CDTC 3', 'PDTC 2', 'TFTOC 1', 'TF 0', 'FLT' ];
            my $table = S_TableCreate($table_fields);

            for ( $item = 0 ; $item < @states ; $item++ ) {
                my $bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                $bits =~ tr/01/-X/;
                my @bittext = split( //, $bits );

                my $DTC = $DTC_struct->{"DTC"}[$item];
                my $FLT_text = join( '<br>', @{ $DTC2FLT{$DTC} } );

                S_TableAddRow( $table, [ $DTC, $states[$item], @bittext, $FLT_text ] );
            }

            S_TablePrint( CONSOLE|TEXT|HTML|4, $table, 'Read DTC' );
            
          }
        else {
            S_w2log( 3, "No DTCs were found.\n" );
        }
    }
    elsif ( $resp eq '7F' ) {
        $DTC_struct -> {"response"} = 'NRC';
        S_set_error( "negative response", 102 );
    }
    else {
        $DTC_struct -> {"response"} = 'unknown';
        S_set_error( "unknown response $resp", 102 );
    }

    return ($DTC_struct);

}

=head1 Function Group 'edr'

=head2 CD_getEDIDdata

    FUNCTION WILL BE OBSOLETE

    use the EDR framework from TC_FunctionLib


    Function Name    :: CD_getEDIDdata
    Description      :: This function reads the EDID number or Data element ,EDR mapping hash name  and ECU crash information,
                        Reads the crash info of  required crash number from ECU crash information(Generated from the CD_parseEDID)
                        and writes the crash info to html report
    Syntax           :: $EDIDdata_aref = CD_getEDIDdata($crash_info_href,$DataEle_EDIDNo,$EDID_Hash_Name)
    Input Arguments  :: $crash_info_href - input from CD_parseEDID
                        $DataEle_EDIDNo - EDID number or Data element
                        $EDID_Hash_Name - GENERIC , OEM , SUPPLIER
    Return Value(s)  :: $EDIDdata_aref - on success , 0 - error
    Example          :: [0x00, 0x05] = CD_getEDIDdata($EDID_struct_href, 271, 'GENERIC');

=cut

sub CD_getEDIDdata
{
    my ( $number, $html_report_info, $EDRMapping_hash );    #Reads the EDID no of $DataEle_EDIDNo
    my @ECU_crashdata;                                      #Reads the crash information of particular $DataEle_EDIDNo
    my @EDID_sort;
    my $EDID_struct_href = shift;
    my $DataEle_EDIDNo   = shift;                           #Reads the EDID number or Data element to return the crash information
    my $EDID_Hash_Name   = shift;

    S_set_warning("CD_getEDIDdata - FUNCTION WILL BE OBSOLETE - use the EDR framework from TC_FunctionLib\n");

    #
    #   NOTE : here are invalid HTML printouts - but no rework is required (Function obsolete)
    #

    my $EDRMapping = $main::ProjectDefaults->{'Mapping_EDR'};

    unless ( defined($EDRMapping) )
    {
        S_set_error( " EDRMapping is not defined \n", 114 );
        return 0;
    }

    unless ( defined($EDID_Hash_Name) )
    {
        S_set_error( 'too less parameters ,SYNTAX: CD_getEDIDdata($crash_info_href,$DataEle_EDIDNo, $EDID_Hash_Name); \n', 110 );
        return 0;
    }

    unless ( defined($DataEle_EDIDNo) )
    {
        S_set_error( 'Not defined either EDID number or Name of the EDID \n', 114 );
        return 0;
    }

    unless ( defined($EDID_struct_href) )
    {
        S_set_error( 'EDID_struct_href is not defined \n', 114 );
        return 0;
    }

    unless ( ref $EDRMapping eq "HASH" )
    {
        S_set_error( " EDRMapping is not hash reference \n", 114 );
        return 0;
    }

    unless ( ( $EDID_Hash_Name =~ /GENERIC/i ) || ( $EDID_Hash_Name =~ /OEM/i ) || ( $EDID_Hash_Name =~ /SUPPLIER/i ) )
    {
        S_set_error( " EDID_Hash_Name is not given, should be either GENERIC or OEM or SUPPLIER \n", 114 );
        return 0;
    }

    unless ( ref($EDID_struct_href) eq "HASH" )
    {
        S_set_error( " EDID_struct_href is not an hash reference \n", 114 );
        return 0;
    }

    my %EDID_struct_hash = %$EDID_struct_href;

    #EDID numbers read from the EDR Mapping file
    $EDID_Hash_Name  = uc($EDID_Hash_Name) . '_EDIDS';
    $EDRMapping_hash = $$EDRMapping{$EDID_Hash_Name};

    foreach my $EDID_Label_descr ( keys %$EDRMapping_hash )
    {
        push( @EDID_sort, $$EDRMapping_hash{$EDID_Label_descr}{'EDID'} );
    }

    @EDID_sort = sort { $a <=> $b } @EDID_sort;

    if ( ( $DataEle_EDIDNo =~ /\d+/ ) && ( $DataEle_EDIDNo !~ /[A-Za-z]/ ) )
    {
        $number = $DataEle_EDIDNo;
    }
    elsif ( $DataEle_EDIDNo =~ /\w+/ )
    {
        foreach my $EDID_Label_descr ( keys %$EDRMapping_hash )
        {
            if ( $DataEle_EDIDNo eq $EDID_Label_descr )
            {
                $number = $$EDRMapping_hash{$EDID_Label_descr}{'EDID'};
                S_w2log( 4, " CD_getEDIDdata : EDID number of $DataEle_EDIDNo is $number\n" );
            }
        }
    }
    if ( defined $EDID_struct_hash{$number} )
    {
        push( @ECU_crashdata, @{ $EDID_struct_hash{$number} } );
    }
    else
    {
        S_w2log( 4, " CD_getEDIDdata : EDID number $number is not having the ECU crash information\n" );
    }

    #pushes ECU crashdata into hex_output in hex format (Eg: FF as 0XFF)

    foreach my $data (@ECU_crashdata) { $data = S_hex2dec($data) }

    if ( defined($DataEle_EDIDNo) && scalar(@ECU_crashdata) > 0 )
    {

        #
        #  TODO : table function must be used normally
        #

        $html_report_info = "<div class='w2rep ',$module_name,''><TABLE Name = 'RequiredCrashInfo' class='tablesorter'
        <caption><h4>Required Data element Crash Info</h4></caption>
        <TR bgcolor = grey><TH>EDID number/Data element</TH><TH>crash Information</TH></TR>
        <TR bgcolor = silver><TD>$DataEle_EDIDNo</TD><TD>@ECU_crashdata</TD></TR></TABLE></div>";

        push( @TC_HTML_TEXT, $html_report_info );
    }
    else
    {
        #
        #  TODO : table function must be used normally
        #

        $html_report_info = "<div class='w2rep ',$module_name,''><TABLE Name = 'RequiredCrashInfo' class='tablesorter'>
        <caption><h4>Required Data element Crash Info</h4></caption>
        <TR bgcolor = grey><TH>EDID number/Data element</TH><TH>crash Information</TH></TR>
        <TR bgcolor = silver><TD>$DataEle_EDIDNo</TD><TD>EDID number $number is not having the ECU crash information</TD></TR></TABLE></div>";

        push( @TC_HTML_TEXT, $html_report_info );
    }

    return ( \@ECU_crashdata );
}

=head2 CD_parseEDID

    NOTE : FUNCTION WILL BE OBSOLETE -> new EDR_parseEDID is existing already !

    Function Name    :: CD_parseEDID
    Description      :: This function reads the crash information from the ECU response, EDR mapping hash and type of output.
                        Writes the crash information and EDID number to hash.
    Syntax           :: $EDIDstruct = CD_parseEDID( $ECU_crash_info_aref , $EDID_Hash_Name, [$str_flex] );
    Input Arguments  :: $ECU_crash_info_aref :: ECU response in array format
                        $EDID_Hash_Name :: 'GENERIC', 'OEM', 'SUPPLIER'
                        type of output($str_flex) is optional, default value is "Flexible"
    Return Value(s)  :: $EDIDstruct - on success , 0 - error
    Example          :: $EDIDstruct = CD_parseEDID([98, 0x25, 75, 102, 12, 250, 10, 140], 'GENERIC', 'strict');

    '$EDIDstruct' hash structure::

        $hash_ref = {

                        EDID_number => [Crash Info of EDID number],
                        EDID_number => [Crash Info of EDID number],
                        .
                        .
                        .
                        .
                    }



    Example ::

    $var1 = {
                1 => [AB],
                2=> [AB,CD],
                .
                .
                .
                .
            }

=cut

sub CD_parseEDID
{
    #Local Variables
    my ( $EDR_byte_pos, $ndx_EDR_mapping,     $str_flex )       = 0;
    my ( $EDID_number,  $ECU_crash_info_aref, $EDID_Hash_Name ) = 0;
    my ($html_report_info) = 0;     #Variables to create HTML Report
    my %EDR_data_from_ECU  = ();    # Holds the content of the crashed data
    my $EDRMapping_hash    = {};
    my ( @ECU_CrashData, @sort_flag, @keys_EDR_data_from_ECU, @ECU_info_edidno, @EDID_sort ) = ();
    my ( $flag_aref, $duplicate_EDID_No_aref, $order_mismatch_EDID_No_aref, $ECU_Crash_extra_edid_aref, $excel_extra_edid_aref );    #Holds the error messages

    my $EDID_label_mapping;

    $ECU_crash_info_aref = shift;                                                                                                    # Array reference
    $EDID_Hash_Name      = shift;                                                                                                    # EDR Mapping Hash Name ('Generic', 'OEM' ,'Supplier')
    $str_flex            = shift;                                                                                                    # Strict or Flexible

    #     S_w2log( 5, " CD_parseEDID\n" );

    S_set_warning(" CD_parseEDID - FUNCTION WILL BE OBSOLETE - just EDR_parseEDIDs from FuncLib_TNT_EDR shall be used\n");

    unless ( defined($EDID_Hash_Name) )
    {
        S_set_error( 'too less parameters ,SYNTAX: CD_parseEDID( CD_Response, EDID_Hash_Name, [strict\flexible] ); \n', 110 );
        return 0;
    }

    my $EDRMapping = $main::ProjectDefaults->{'Mapping_EDR'};

    unless ( defined $EDRMapping )
    {
        S_set_error( " EDRMapping is not defined \n", 114 );
        return 0;
    }

    if ( ref($ECU_crash_info_aref) ne "ARRAY" )
    {
        S_set_error( " ECU_crash_info_aref is not an array reference \n", 114 );
        return 0;
    }

    unless ( ref $EDRMapping eq "HASH" )
    {
        S_set_error( " EDRMapping is not hash reference \n", 114 );
        return 0;
    }

    unless ( ( $EDID_Hash_Name =~ /GENERIC/i ) || ( $EDID_Hash_Name =~ /OEM/i ) || ( $EDID_Hash_Name =~ /SUPPLIER/i ) )
    {
        S_set_error( " EDID_Hash_Name is not given, should be either GENERIC or OEM or SUPPLIER \n", 114 );
        return 0;
    }

    unless ( defined $str_flex )
    {
        S_w2log( 4, " CD_parseEDID: Strict or Flexible is not defined, Default:: Flexible \n" );
        $str_flex = 'Flexible';
    }

    unless ( ( $str_flex =~ /strict/i ) || ( $str_flex =~ /flexible/i ) )
    {
        S_set_error( "str_flex is incorrect, should be either 'strict' or 'flexible' \n", 114 );
        return 0;
    }

    $EDID_Hash_Name = uc($EDID_Hash_Name) . '_EDIDS';

    $EDRMapping_hash = $$EDRMapping{$EDID_Hash_Name};

    unless ( defined $EDRMapping_hash )
    {
        S_set_error( "Empty hash found in EDR Mapping with $EDID_Hash_Name hash name \n", 114 );
        return 0;
    }

    foreach my $EDID_Label_descr ( keys %$EDRMapping_hash )
    {
        my $EDID_nbr = $$EDRMapping_hash{$EDID_Label_descr}{'EDID'};
        push( @EDID_sort, $EDID_nbr );
        $EDID_label_mapping->{$EDID_nbr} = $EDID_Label_descr;
    }

    @EDID_sort = sort { $a <=> $b } @EDID_sort;
    foreach my $data (@$ECU_crash_info_aref)
    {
        my $data_1;
        if ( $data =~ m/^(0x|0X)/g )
        {
            $data_1 = $data;
            $data_1 =~ s/^(0x|0X)//g;
            push( @ECU_CrashData, $data_1 );
        }
        else
        {
            $data_1 = sprintf( "%02X", $data );
            push( @ECU_CrashData, $data_1 );
        }
    }

    #Start of reading EDID no from the crash record data

    S_w2log( 4, " CD_parseEDID : Start parsing EDIDs from response\n" );

  EDID_PARSING_LOOP:
    for ( $EDR_byte_pos = 5, $ndx_EDR_mapping = 0 ; $EDR_byte_pos < scalar @ECU_CrashData, $ndx_EDR_mapping <= $#EDID_sort ; )
    {

        if ( $EDR_byte_pos > scalar @ECU_CrashData )
        {
            S_w2log( 5, " CD_parseEDID: END OF LOOP EDR DATA DUMP reached - 'for' loop must be improved!!\n" );
            last;
        }

        $EDID_number = $ECU_CrashData[$EDR_byte_pos] . $ECU_CrashData[ $EDR_byte_pos + 1 ];    # take 2 bytes as EDID nbr ( 00 1A )
        $EDR_byte_pos++;
        my $EDID_nbr_dec = hex($EDID_number);

        #         S_w2rep( " NEXT EDID of EDR DATA to be checked: $EDID_nbr_dec ( $EDID_number hex ) \n" );

        push( @ECU_info_edidno, $EDID_nbr_dec );

        while ( $EDID_nbr_dec > $EDID_sort[$ndx_EDR_mapping] )
        {
            if ( $str_flex =~ /strict/i )
            {
                S_w2log( 4, " CD_parseEDID: EDID numbers Mismatch found!: EDR mapping file ( EDID NO :: $EDID_sort[$ndx_EDR_mapping]) and  ECU crash information(EDID NO :: $EDID_nbr_dec)  \n" ) unless $main::opt_offline;
                last EDID_PARSING_LOOP;
            }

            #             S_w2log(4, "EDID numbers Mismatch found!: EDR mapping file ( EDID NO :: $EDID_sort[$ndx_EDR_mapping]) and  ECU crash information(EDID NO :: $EDID_nbr_dec)  \n") unless $main::opt_offline;
            $ndx_EDR_mapping++;
        }

        unless ( $EDID_nbr_dec == $EDID_sort[$ndx_EDR_mapping] )
        {
            S_w2log( 4, " CD_parseEDID: unexpected EDID in data stream $EDID_nbr_dec -> next expected from Mapping is $EDID_sort[$ndx_EDR_mapping]\n" );
            last;
        }

        #
        # start reading EDID data from here
        #
        my $Data_length      = 0;
        my $EDID_Label_descr = $EDID_label_mapping->{$EDID_nbr_dec};
        unless ( $Data_length = $$EDRMapping_hash{$EDID_Label_descr}{'DataLength'} )
        {
            S_set_error("Could not resolve 'DataLength' of EDID $EDID_nbr_dec (Label: '$EDID_Label_descr')");
            last;
        }

        my @EDR_data;
        unless ( defined $ECU_CrashData[ $EDR_byte_pos + $Data_length - 1 ] )
        {
            S_set_error("ERROR : EDR data are to short ; more bytes expected for EDID $EDID_number Label '$EDID_Label_descr' Length '$Data_length' \n");
            last;
        }

        for ( 1 .. $Data_length )
        {
            $EDR_byte_pos++;
            push( @EDR_data, $ECU_CrashData[$EDR_byte_pos] );
        }

        $EDR_data_from_ECU{$EDID_nbr_dec} = \@EDR_data;

        S_w2log( 3, " CD_parseEDID: Reading EDID nbr '$EDID_number' ($EDID_nbr_dec dec) [$Data_length bytes] : @EDR_data ($EDID_Label_descr) \n" );
        #
        # reading EDID data finished
        #

        $EDR_byte_pos++;    # next EDR byte prepared for next loop

        #
        # normal way to next loop iteration
        #
        next unless $ndx_EDR_mapping eq $#EDID_sort;

        #
        # final check when end of known EDID in EDR mapping is reached
        #
        S_w2log( 4, " CD_parseEDID: Last known EDID from EDR mapping already reached (EDID $EDID_sort[$ndx_EDR_mapping]) - no more data expected\n" );
        while ( $EDR_byte_pos <= $#ECU_CrashData )
        {
            my $byte_content = $ECU_CrashData[$EDR_byte_pos];
            $EDR_byte_pos++;
            S_w2log( 4, " CD_parseEDID: Checking last bytes in EDR data stream : '$byte_content' (only 00 expected) \n" );
            next if hex $byte_content == 0;
            S_set_error("Unexpected byte [$byte_content] in EDR stream - just 00 bytes expected\n");
        }
        last;
    }

    S_w2log( 5, " CD_parseEDID : Calling Check_EDID_mining_info \n" );

    #Checking the ECU crash and Mining report EDID numbers
    my @Error_messages = &Check_EDID_mining_info( \@ECU_info_edidno, $EDID_Hash_Name );

    $duplicate_EDID_No_aref      = shift(@Error_messages);
    $order_mismatch_EDID_No_aref = shift(@Error_messages);
    $ECU_Crash_extra_edid_aref   = shift(@Error_messages);
    $excel_extra_edid_aref       = shift(@Error_messages);

    # Creating HTML Report
    $html_report_info = <<"HTML_HEADER";
        <div class='w2rep'>
        <TABLE Name = Crash_Info_Table class='tablesorter'>
            <caption><h4>Crash Record Information</h4></caption>
            <TR bgcolor = grey>
                <TH>EDID NO</TH>
                <TH>DATA ELEMENT</TH>
                <TH>LENGTH</TH>
                <TH>CRASH DATA</TH>
            </TR>
HTML_HEADER

    push( @TC_HTML_TEXT, $html_report_info );

    foreach my $EDID_nbr_dec ( sort { $a <=> $b } ( keys %EDR_data_from_ECU ) )
    {
        my $EDID_Label_descr = $EDID_label_mapping->{$EDID_nbr_dec};
        my @data             = @{ $EDR_data_from_ECU{$EDID_nbr_dec} };
        my $length           = scalar @data;
        my $html             = "<TR bgcolor = silver><TD>$EDID_nbr_dec</TD><TD>$EDID_Label_descr</TD><TD>$length</TD><TD>@data</TD><TR>";
        push( @TC_HTML_TEXT, $html );
    }
    my $close_table_text = '</TABLE></div><br/>';
    push( @TC_HTML_TEXT, $close_table_text );

    if (    scalar(@$duplicate_EDID_No_aref) > 0
         || scalar(@$order_mismatch_EDID_No_aref) > 0
         || scalar(@$ECU_Crash_extra_edid_aref) > 0
         || scalar(@$excel_extra_edid_aref) > 0 )
    {
        $html_report_info = <<"ERROR_TEXT";
        <br/><br/>
        <div class="w2rep">
            <TABLE Name = "CrashRecordErrorMessages" class="tablesorter">
            <caption><h4>Crash Record Error Messages</h4></caption>
            <TR bgcolor = grey>
                <TH>Duplicate EDID No</TH><TH>Mismatch EDID No of Excel and Crash Record</TH>
                <TH>Extra EDID No in CrashRecord</TH><TH>Extra EDID No in Excel</TH>
            </TR>
            <TR bgcolor = silver>
                <TD>@$duplicate_EDID_No_aref</TD>
                <TD>@$order_mismatch_EDID_No_aref</TD>
                <TD>@$ECU_Crash_extra_edid_aref</TD>
                <TD>@$excel_extra_edid_aref</TD>
            </TR>
            </TABLE>
        </div>
ERROR_TEXT

        push( @TC_HTML_TEXT, $html_report_info );
    }

    return ( \%EDR_data_from_ECU );
}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=head2 Check_EDID_mining_info

 Check_EDID_mining_info not exported


  (\@flag,\@duplicate_EDID_No,\@order_mismatch_EDID_No,\@ECU_Crash_extra_edid,\@excel_extra_edid) = &Check_EDID_mining_info(\@ECU_info_edidno, $EDID_Hash_Name);

 Input Values: @ECU_info_edidno - EDID numbers in the ECU generated information
               $EDID_Hash_Name -  'GENERIC', 'OEM', 'SUPPLIER'

 Return Values:

    @duplicate_EDID_No : Holds the redudant elements
    @excel_extra_edid : Holds the EDID elements which are not in the crash information
    @order_mismatch_EDID_No : Holds the mismatch elements between EDR Mapping file and crash information
    @ECU_Crash_extra_edid : Holds the EDID elements which are not in the EDR Mapping file
    @flag : Holds the all the elements in the above arrays


    NOTE :
        Function will be OBSOLETE in future !
        Function will be planned to be moved into another lib

=cut

sub Check_EDID_mining_info
{
    my ( $html_line,         @ECU_info_edidno,        @EDID_sort,            $EDRMapping_hash );
    my ( @duplicate_EDID_No, @order_mismatch_EDID_No, @ECU_Crash_extra_edid, @excel_extra_edid );    #Holds the error messages

    my $ECU_info_edidno_aref = shift;
    my $EDID_Hash_Name       = shift;

    S_w2log( 5, " Check_EDID_mining_info\n" );                                                       # level 5 - just for debugging / function will be moved out

    unless ( defined($ECU_info_edidno_aref) )
    {
        S_set_error( " ECU_info_edidno_aref is not defined", 114 );
        return 0;
    }

    my $EDRMapping = $main::ProjectDefaults->{'Mapping_EDR'};

    unless ( defined($EDRMapping) )
    {
        S_set_error( " EDRMapping is not defined", 114 );
        return 0;
    }

    unless ( ref($ECU_info_edidno_aref) eq "ARRAY" )
    {
        S_set_error( '$ECU_info_edidno_aref is not array reference', 114 );
        return 0;
    }

    unless ( ref $EDRMapping eq "HASH" )
    {
        S_set_error( " EDRMapping is not hash reference", 114 );
        return 0;
    }

    @ECU_info_edidno = @$ECU_info_edidno_aref;

    #EDID numbers read from the EDR Mapping file
    $EDRMapping_hash = $$EDRMapping{$EDID_Hash_Name};

    foreach my $EDID_Label_descr ( keys %$EDRMapping_hash )
    {
        push( @EDID_sort, $$EDRMapping_hash{$EDID_Label_descr}{'EDID'} );
    }

    @EDID_sort = sort { $a <=> $b } @EDID_sort;

    #Start of checking for redundant in an array
    my %seen = ();
    @duplicate_EDID_No = map { 1 == $seen{$_}++ ? $_ : () } @ECU_info_edidno;

    #Start of checking whether the elements are in same order in both arrays
    for ( my $loop_counter2 = 0 ; $loop_counter2 <= $#ECU_info_edidno ; $loop_counter2++ )
    {
        if ( $EDID_sort[$loop_counter2] ne $ECU_info_edidno[$loop_counter2] )
        {
            $html_line = qq/$EDID_sort[$loop_counter2] :: $ECU_info_edidno[$loop_counter2]<br>/;
            push( @order_mismatch_EDID_No, $html_line );
        }
    }    #End of checking whether the elements are in same order in both arrays

    #Start of checking whether the edid number in excel is present in crash record
    foreach my $elmnt (@EDID_sort)
    {
        unless ( grep /$elmnt/, @ECU_info_edidno )
        {
            $html_line = qq/$elmnt &nbsp;/;
            push( @excel_extra_edid, $html_line );
        }
    }    #End of checking whether the edid number in excel is present in crash record

    #Start of checking whether there is an extra edidno in crash record
    foreach my $ele (@ECU_info_edidno)
    {
        unless ( grep /$ele/, @EDID_sort )
        {
            $html_line = qq/$ele &nbsp;/;
            push( @ECU_Crash_extra_edid, $html_line );
        }
    }    #End of checking whether there is an extra edidno in crash record

    return ( \@duplicate_EDID_No, \@order_mismatch_EDID_No, \@ECU_Crash_extra_edid, \@excel_extra_edid );
}

1;

__END__
