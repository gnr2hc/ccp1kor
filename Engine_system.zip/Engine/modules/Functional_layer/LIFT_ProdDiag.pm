# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_ProdDiag;

use strict;
use warnings;
use LIFT_general;
use LIFT_functional_layer;
use Data::Dumper;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  PRD_init
  PRD_exit
  PRD_Send_Request_Wait_Response
  PRD_ECU_Login
  PRD_Get_ECU_Properties
  PRD_ECU_Reset
  PRD_Check_ECU_Properties
  PRD_Read_Fault_Memory
  PRD_Read_Memory
  PRD_Clear_Fault_Memory
  PRD_Freeze_Fault_Memory
  PRD_Start_Fast_Diagnosis
  PRD_Stop_Fast_Diagnosis
  PRD_Get_Fast_Diagnosis_Data
  PRD_Read_EDR
  PRD_Clear_EDR
  PRD_Electronic_Firing_Enable
  PRD_Electronic_Firing_Fire
  PRD_Sensor_Verification
  PRD_Read_ECU_NVM
  PRD_Write_ECU_NVM
  PRD_Write_Memory
  PRD_Set_Device_Configuration
  PRD_Get_Device_Configuration
  PRD_Dump_Memory_To_File
  PRD_Write_Dump_To_ECU
  PRD_Get_Symbol_Mapping
  PRD_Manipulate_Fault_Memory
  PRD_Get_Device_Property
  PRD_Get_Last_Response
  PRD_Activate_AIO_Test_Pattern
  PRD_Set_Secure_PIN
  PRD_Read_Serial_Numbers
  PRD_Read_ECU_LifeCycle_Data
  PRD_Switch_ECU_LifeCycle
  PRD_SHEKeyCalculatorProtocol
  PRD_Get_Signature_from_KMS
  PRD_Disable_Initial_Login
  PRD_Do_Initial_Login
  PRD_Enable_KMS_Simulator
  PRD_SetAutoLogin
);

our ( $VERSION, $HEADER );

my $functionMapping_href = {
    'generation' => {
        'AB12' => {
            'PRD_init'                       => 'PRD12_init',
            'PRD_Send_Request_Wait_Response' => 'PRD12_Send_Request_Wait_Response',
            'PRD_Read_Fault_Memory'          => 'PRD12_Read_Fault_Memory',
            'PRD_Clear_Fault_Memory'         => 'PRD12_Clear_Fault_Memory',
            'PRD_Read_Memory'                => 'PRD12_Read_Cell',
            'PRD_Write_Memory'               => 'PRD12_Write_Cell',
            'PRD_ECU_Login'                  => 'PRD12_ECU_Login',
            'PRD_Get_ECU_Properties'         => 'PRD12_Get_ECU_Properties',
            'PRD_ECU_Reset'                  => 'PRD12_SW_Reset',
            'PRD_Manipulate_Fault_Memory'    => 'PRD12_Manipulate_Fault_Memory',
            'PRD_Check_ECU_Properties'       => 'PRD12_Check_ECU_Properties',
            'PRD_Freeze_Fault_Memory'        => 'PRD12_Freeze_Fault_Memory',
            'PRD_Start_Fast_Diagnosis'       => 'PRD12_Start_Fast_Diagnosis',
            'PRD_Stop_Fast_Diagnosis'        => 'PRD12_Stop_Fast_Diagnosis',
            'PRD_Get_Fast_Diagnosis_Data'    => 'PRD12_Get_Fast_Diagnosis_Data',
            'PRD_Read_EDR'                   => 'PRD12_Read_EDR',
            'PRD_Clear_EDR'                  => 'PRD12_Clear_EDR',
            'PRD_Electronic_Firing_Enable'   => 'PRD12_Electronic_Firing_Enable',
            'PRD_Electronic_Firing_Fire'     => 'PRD12_Electronic_Firing_Fire',
            'PRD_Sensor_Verification'        => 'PRD12_Sensor_Verification',
            'PRD_Read_ECU_NVM'               => 'PRD12_Read_ECU_NVM',
            'PRD_Write_ECU_NVM'              => 'PRD12_Write_NVM_cells',
            'PRD_Set_Device_Configuration'   => 'PRD12_Set_Device_Configuration',
            'PRD_Get_Device_Configuration'   => 'PRD12_Get_Device_Configuration',
            'PRD_Dump_Memory_To_File'        => 'PRD12_Dump_Memory_To_File',
            'PRD_Write_Dump_To_ECU'          => 'LIFT_ProdDiag::NotImplementedYetWarning',
            'PRD_Get_Symbol_Mapping'         => 'PRD12_Get_Symbol_Mapping',
            'PRD_exit'                       => 'PRD12_exit',
            'PRD_Get_Device_Property'        => 'PRD12_Get_Device_Property',
            'PRD_Get_Last_Response'          => 'PRD12_Get_Last_Response',
            'PRD_Activate_AIO_Test_Pattern'  => 'PRD12_AIO_Test_Pattern',
            'PRD_Set_Secure_PIN'             => 'PRD12_Set_Secure_PIN',
            'PRD_Read_Serial_Numbers'        => 'PRD12_Read_ASIC_Serial_Numbers',
            'PRD_Read_ECU_LifeCycle_Data'    => 'PRD12_Read_ECU_LifeCycle_Data',
            'PRD_Switch_ECU_LifeCycle'       => 'PRD12_Switch_ECU_LifeCycle',
            'PRD_SHEKeyCalculatorProtocol'   => 'PRD12_SHEKeyCalculatorProtocol',
            'PRD_Get_Signature_from_KMS'     => 'PRD12_Get_Signature_from_KMS',
            'PRD_Do_Initial_Login'           => 'PRD12_Do_Initial_Login',
            'PRD_SetAutoLogin'               => 'PRD12_SetAutoLogin',
        },
    },
};

my @availableTestbenchFunctionGroups = qw{ generation };
my $setSecurePIN                     = 0;
my $setInitialLogin                  = 1;
my $enable_KMSsimulator              = 0;
my $setAutoLogin                     = 1;

our $prodDiag_Initialized;

=head1 NAME

LIFT_ProdDiag 

=head1 SYNOPSIS

    use LIFT_ProdDiag

    $ecuDetails_href = PRD_init();
    $response_href = PRD_Send_Request_Wait_Response( $request [, $options_href ] );
    $success = PRD_Send_Request_No_Wait( $request [, $options_href ] );
    $success = PRD_ECU_Login();
    $ecuProperties_href = PRD_Get_ECU_Properties( $options_href );
    $success = PRD_ECU_Reset( $resetType );
    $success = PRD_Check_ECU_Properties( $options_href );
    $faultMemory_href = PRD_Read_Fault_Memory( $faultType );
    $success = PRD_Manipulate_Fault_Memory( $manipulationConfig_href );
    $success = PRD_Clear_Fault_Memory( $mode, $wait_timeout );
    $success = PRD_Freeze_Fault_Memory();
    $csv_data_file_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href );
    $success = PRD_Stop_Fast_Diagnosis();
    $fdData_href = PRD_Get_Fast_Diagnosis_Data([, $options_href ]);
    $response_href = PRD_Read_EDR( $recorderType, $did );
    $response_href = PRD_Clear_EDR( $options_href );
    $filename = PRD_Dump_EDR( $edrContents_aref );
    $success = PRD_Electronic_Firing_Enable([$options_href]);
    $firingStatus_href = PRD_Electronic_Firing_Fire();
    $sensorData_href = PRD_Sensor_Verification( $sensorConfig_href );
    $data_aref = PRD_Read_Memory( $label[, $options_href] );
    $success = PRD_Write_Memory( $label, $memoryContents_aref );
    $nvmContents_aref = PRD_Read_ECU_NVM( $label );
    $success = PRD_Write_ECU_NVM( $label, $nvmContents_mix );
    $success = PRD_Set_Device_Configuration( $device_modes_href  [, $options_href ] );
    $device_config_href = PRD_Get_Device_Configuration([, $options_href ]);
    $filename = PRD_Dump_Memory_To_File( $memoryType [, $options_href ]  );
    $success = PRD_Write_Dump_To_ECU( $dumpfile );
    $propertyValue = PRD_Get_Device_Property( $device [, $options_href ] );
    $success = PRD_exit();
    $response_href = PRD_Get_Last_Response();
    $success = PRD_Activate_AIO_Test_Pattern();
    $success = PRD_Set_Secure_PIN();
    $serialNumbers_href = PRD_Read_Serial_Numbers( [$options_href] );
    $response_href = PRD_Read_ECU_LifeCycle_Data();
    $response_href = PRD_Switch_ECU_LifeCycle( $options_href );
    $response_href = PRD_SHEKeyCalculatorProtocol( $options_href );
    $signature_KMS_aref = PRD_Get_Signature_from_KMS( $challenge_aref );
    $success = PRD_Enable_KMS_Simulator();
    
    Different use cases for PRD_SetAutoLogin:

    Case 1: If called before PRD_init(), Autologin will be disabled/enabled after the PRD communication is initialised by PRD_init()
    
        PRD_SetAutoLogin(0);  # Disable autologin called
        PRD_init();           # Autologin is disabled after initialising communication 
        
        # Call other PRD services

    Case 2: If called after PRD_init(), Autologin will be disabled/enabled with immediate effect when the function call is made.
    
        PRD_init();
        PRD_SetAutoLogin(0);  # Autologin disabled with immediate effect
    
        # Call other PRD services
    
        PRD_SetAutoLogin(1);  # Autologin enabled with immediate effect

        # Call other PRD services

=head1 DESCRIPTION

Device independent and airbag generation independent functional layer module for production diagnosis

=head1 CONFIGURATION

=head2 Testbench Configuration for generation AB12 and device PDLayer (LIFT_Testbenches.pm)

    'Devices' => {
        ...
        'PDLayer' => {         # example values given here
            'BusType'             => 'CAN',   # bus type, possible values are 'CAN', 'FlexRay', 'CANFD'
            'Channel_Nbr_0-based' => 3,       # Vector hardware channel number (0-based)
            'Hw_Serial_Nbr'       => 30679,   # Vector hardware serial number
            'FastDiagBusType'     => 'CANFD', # optional and only valid for 'BusType' => 'CANFD':
                                              # can be set to 'CANFD' (default) or to 'CAN'
        },  
            ...
    },
        
    'Functions' => {
        ...
        'ProdDiag' => {
            'generation' => 'AB12',     # Airbag generation, possible values: currently 'AB12' only
            'basic'      => 'PDLayer',  # Device for function group 'basic' (all functions): 
                                        # device currently only 'PDLayer'
        },
        ...
    },

B<Notes:> Settings in 'Devices'=>'PDLayer' will only be used if Project Defaults=>'ProdDiag'=>'ProjectName' 
is not 'TakeFromPSDiag', see next section.

=head2 Project Defaults for AB12:

=head3 Project definition for production diagnosis:
    
    'ProdDiag' => { 
        'ProjectName' => <project name>,  
              # possible values of <project name> are :
               #  1) 'TakeFromPSDiag' 
               #     - settings from PSDiag config file for CAN, CANFD and FlexRay are taken. 
               
               #  2) 'BOSCH_CAN_03' or 'FORD_CAN_05' etc 
               #     - for CAN (CANType from PSDiag_CAN_Parameter.txt).
               
               #  3) 'DAIMLER' or 'JAGUAR' 
               #     - for FlexRay (Customer name).
               
               #  4) 'BOSCH', 'TOYOTA', 'VOLVO', 'HRYT' or 'MASERATI'  
               #     - for CANFD (Customer name).
               
               # NOTE :                    
               # - pt 2) 3) and 4):
               #   - additional setting under Devices -> PDLayer are required. 
               #   - This can be be choosen if there is no PSDiag.
               #
               # - pt 1):
               #   - this can save some of your configuration effort with respect to
               #     Bus type, channel number, hw serial number, SAD file name and path.   
               #
               #  - Default is 'TakeFromPSDiag' if section 'ProdDiag' is not defined.                    

        'CommunicationParameter' => <name of communication parameter set>,
              # In case 4) above for TOYOTA there are 2 different communication parameter sets:
              # '19PF_EMC_B3' or '19PF'
    }, 
    
B<Notes:> If either one of below  settings was done : 
 
=over

=item section 'ProdDiag' is not defined or

=item <project name> is not defined, means left blank  or

=item explicitly defined as 'TakeFromPSDiag'

=back   
   
then below things happens :

'CANType'/'FlexrayType'/'CANFDType', 'SAD file path', 'BusType', 'Channel_Nbr_0-Based' and 'Hw_Serial_Nbr' will be taken from B<PSDiag config> file 
and any those values given in Project Defaults/Main config file/Testbench Configuration will be B<ignored>. 

Otherwise those quantities will be taken from Project Defaults/Main config file/Testbench Configuration.

B<Remark:> If you want to B<save some configuration effort> then.

=over

=item dont define section 'ProdDiag' in Project constant.

=item dont define section 'PDLayer' in Testbench.

=item and most important is to set the PSDiag properly and that's all.  

=back

=head2 Device configuration variables

Configuration of squibs, pases, switches, asics, etc. are read from predefined enums in the .cns file and can be configured in the ECU 
using predefined variables in the .sad file (function PRD_Set_Device_Configuration). 
If required the predefined variables can be overwritten by defining the following section in ..._ProjectConst.pm. 
If this section does not exist then the default values as shown below will be used.

    'DEVICE_CONFIG_VARIABLES' => {
        'AB12' => {
            'lamps' => {
                'enum'       => 'rb_syco_AOuts_ten',
                'monitored'  => 'rb_syco_SysConfAOutEeData_dfst.AoutMonitored_ab8',
                'real'       => 'rb_syco_AOutPresence_ab8',
                'configured' => 'rb_syco_SysConfAOutEeData_dfst.AoutConfigured_ab8',
            },
            'squibs' => {
                'enum'       => 'rb_sycf_SquibDevice_ten',
                'monitored'  => 'rb_sycf_SysConfSquib_dfst.SquibMonitored_ab8',
                'real'       => 'rb_sycf_SquibPresence_ab8',
                'configured' => 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8',
            },

            'SpBehaviour' => {
                'enum'       => 'rb_sycg_StaticBitPositions_ten',
                'configured' => 'rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8',
            },
            'parSections' => {
                'enum'       => 'rb_sycg_DynamicBitPositions_ten',
                'configured' => 'rb_sycg_DynamicBehaviorBits_dfst.rb_sycg_DynamicBits_ab8',
            },
            'pases' => {
                'enum'       => 'rb_sycp_SensorChannels_ten',
                'monitored'  => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelMonitored_ab8',
                'real'       => 'rb_sycp_PsPresence_ab8',
                'configured' => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelConfigured_ab8',
            },
            'switches' => {
                'enum'       => 'rb_sycs_SwitchDevices_ten',
                'monitored'  => 'rb_sycs_SysConfSwmEeData_dfst.SwitchMonitored_ab8',
                'real'       => 'rb_sycs_SwitchPresence_ab8',
                'configured' => 'rb_sycs_SysConfSwmEeData_dfst.SwitchConfigured_ab8',
            },
            'asics' => {
                'enum'       => 'rb_syca_AllAsics_ten',
                'real'       => 'rb_syca_AsicPresence_ab8',
                'configured' => 'rb_syca_SysConfAsicEeData_dfst.AsicConfigured_ab8',
            },
          },
    },    # end of 'DEVICE_CONFIG_VARIABLES'

B<Notes:> Only those values that need to overwrite the default values must be defined in this section.
    
=head2 Main configuration file (..._CFG.pm)

Define the path to .sad, .flt, .cns, .nvm files in $SAD_file or $SAD_fpath:

    ### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ### replace path with SAD file for current ECU SW under test
    our $SAD_file = "$LIFT_PRJCFG_path/SW/dummy_sad_file.sad";
    ###
    # variable $SAD_file will be replaced with sad file present in the folder configured $SAD_fpath
    our $SAD_fpath = "$LIFT_PRJCFG_path/SW/";
    # If both $SAD_file and $SAD_fpath is configured then sad file configured in $SAD_file will be considered.
    # If both $SAD_file and $SAD_fpath is configured but sad file does not exist then $SAD_fpath is considered. 
    ### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

=head1 FUNCTIONS

=head2 PRD_init

    $testbenchDevices_href = PRD_init();

Reads the AB generation from testbench (L</"CONFIGURATION">). According to the AB generation, the corresponding generation specific function is called for init.

For AB12 - LIFT_ProdDiag_AB12::PRD12_init is invoked

Does initialization of ECU communication, login into ECU and fetches the ECU details.

B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $testbenchDevices_href

Devices that are configured for the function groups. 

E.g. for AB12 and PDLayer:

    $testbenchDevices_href = {
        basic => 'PDLayer',
        generation => 'AB12'
    };  

$testbenchDevices_href = undef on error.

=back

B<Examples:>

    $testbenchDevices_href = PRD_init();

=cut

sub PRD_init {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_init()', @args ) or return;

    my $baseDevice = S_get_contents_of_hash( [ 'Functions', 'ProdDiag', 'basic' ], $LIFT_config::LIFT_Testbench );
    delete $LIFT_config::LIFT_Testbench->{'Functions'}{'ProdDiag'}{'basic'};

    #CALL FL_Init for ProdDiag to initialize the AB dependent module
    my $configuredDevices_href = FL_Init( 'ProdDiag', $functionMapping_href, \@availableTestbenchFunctionGroups );
    $LIFT_config::LIFT_Testbench->{'Functions'}{'ProdDiag'}{'basic'} = $baseDevice;
    $configuredDevices_href->{'basic'} = $baseDevice;

    # setting this flag is required to distinguish between LIFT_PD and LIFT_ProdDiag in LIFT_FaultMemory.
    $prodDiag_Initialized = 1;

    #STEP call AB dependent init function
    my $ecuDetails_href = CallDeviceFunction(
        {
            setSecurePIN       => $setSecurePIN,           # option to set secure PIN
            setInitialLogin    => $setInitialLogin,        # option to disable initial login
            enableKMSsimulator => $enable_KMSsimulator,    # option to enable KMS simulator
            setAutoLogin       => $setAutoLogin,           #option to enable or disable autologin
        }
    ) or return;

    $setSecurePIN        = 0;
    $setInitialLogin     = 1;
    $enable_KMSsimulator = 0;

    return $configuredDevices_href;
}

=head2 PRD_exit

    $success = PRD_exit();
    
B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>
    
    $success = PRD_exit();
    
=cut

sub PRD_exit {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_exit()', @args ) or return;

    $prodDiag_Initialized = 0;

    $setSecurePIN        = 0;
    $setInitialLogin     = 1;
    $enable_KMSsimulator = 0;
    $setAutoLogin        = 1;

    return CallDeviceFunction();

}

=head2 PRD_Send_Request_Wait_Response

    $response_href = PRD_Send_Request_Wait_Response( $request_mix [, $options_href ] );
    
Sends any service as defined in $request to the ECU

B<Arguments:>

=over

=item $request_mix

$request_mix can be an array reference or a string.

If the $request_mix is an array reference then the contents should be integer numbers, e.g. [4, 58, 1, 120] or [0x04, 0x3A, 0x01, 0x78].

If the $request_mix is a string then the contents should be a sequence of hex bytes separated by white space, e.g. '04 3A 01 78'.

=item $options_href

    $options_href = {
        'add_length_checksum' => 0|1 # default = 0,
    }
    
If add_length_checksum = 1 then the length (first byte) and checksum (last byte) is calculated automatically and added to $request_mix.   

=back

B<Return Values:>

=over

=item $response_href

Hash reference with the response to the request sent. 

 $response_href = {
    'Status' => <int>,                  # response status, >= 0 on success, <0 on negative response or error
    'ErrorDescription' => <string>,     # 'OK' on success or error description
    'PdLength' => <int>,                # first byte of response = number of following response bytes
    'Id' => <integer>,                  # response ID (positive resonse or 0x7F/127 for negative response)
    'PdPayload' => [<int>, <int>, ...], # array ref with response payload = reponse without PdLength and 
                                        # Checksum
    'Checksum' => <int>,                # last byte of response = checksum (= sum of bytes modulo 256 )
    'CompletePdMsg' => [<int>, <int>, ...], # array ref with complete response
 }

$response_href = undef on error

=back

B<Examples:>

    # Request to be sent to ECU will be 2 9 11 / 0x02 0x09 0x0B (= service 0x09 ECU Status)
    $response_href = PRD_Send_Request_Wait_Response( [2, 9, 11] );

    # Request to be sent to ECU will be 0x02 0x09 0xB, same as above
    $response_href = PRD_Send_Request_Wait_Response( '02 09 0B');

    # same as above (length and checksum is added in the function)
    $response_href = PRD_Send_Request_Wait_Response( '09', {add_length_checksum => 1}); 

A positive response for the above examples will look similar to this:

    $response_href = {
        'Status' => 0,
        'ErrorDescription' => 'OK',
        'PdLength' => 7,
        'Id' => 73,   # positive reponse to 0x09 = 0x49
        'PdPayload' => [73, 0, 0, 0, 3, 0],
        'Checksum' => 83,
        'CompletePdMsg' => [7, 73, 0, 0, 0, 3, 0, 83],
    }

B<Notes: Response_length more than 255 is not supported. > 

=cut

sub PRD_Send_Request_Wait_Response {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Send_Request_Wait_Response( $request_mix [, $options_href ] )', @args ) or return;
    return CallDeviceFunction(@args);
}

#=head2 PRD_Send_Request_No_Wait
#
#    $success = PRD_Send_Request_No_Wait( $request [, $options_href ] );
#
#B<Arguments:>
#
#=over
#
#=item $request
#
#=item $options_href
#
#=back
#
#
#B<Return Values:>
#
#=over
#
#=item $success
#
#=back
#
#
#B<Examples:>
#
#B<Notes:>
#
#=cut

sub PRD_Send_Request_No_Wait {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Send_Request_No_Wait( $request [, $options_href ] )', @args ) or return;
    my $request      = shift @args;
    my $options_href = shift @args;

    my $success;

    return $success;
}

=head2 PRD_ECU_Login

    $success = PRD_ECU_Login();

Does the inital login into ECU.

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    $success = PRD_ECU_Login();

=cut

sub PRD_ECU_Login {

    # todo: return value of this function should be changed in LIFT_ProdDiag_AB12
    # Then also the error handling below can be removed
    my $response_href = CallDeviceFunction();
    return if not defined $response_href;
    return 1;
}

=head2 PRD_Manipulate_Fault_Memory

    $success = PRD_Manipulate_Fault_Memory( $manipulationConfig_href );

Manipulates the fault memory according to $manipulationConfig_href. If fault type is mentioned, dequalifies all the faults.

B<Arguments:>

=over

=item $manipulationConfig_href

    $manipulationConfig_href = {
        'fault_name' => <fault>, # string with a fault name that shall be manipulated   OR
        'fault_type' => <type>,  # string that defines the fault memory type that shall be manipulated
                                 (PLANT | PRIMARY | BOSCH | DISTURBANCE)  
        'action'     => <action>,# either "qualify" or "dequalify" (case independent)
    }
    
1. B<Either fault_name or fault_type must be defined, but not both.>

2. If fault_name is defined then action can be "qualify" or "dequalify". In that case the given fault will be qualified or dequalified.

3. If fault_type is defined then action can only be "dequalify". In that case all stored faults of that type will be dequalified.

4. Action can be omitted if fault_type is defined, otherwise it has to be given.

=back


B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    #Fault type is mentioned. Action is by default 'dequalify'. So all the faults in that type are dequalified.
    $manipulationConfig_href = {
        'fault_type' => 'PRIMARY',
    }
    $success = PRD_Manipulate_Fault_Memory( $manipulationConfig_href );
    
    #Fault name is mentioned. according to the action, fault is manipulated
    $manipulationConfig_href = {
        'fault_name' => 'rb_acc_ParameterLayoutIDInvalid_flt',
        'action'     => 'qualify',
    }
    $success = PRD_Manipulate_Fault_Memory( $manipulationConfig_href );
    
=cut

sub PRD_Manipulate_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Manipulate_Fault_Memory( $manipulationConfig_href )', @args ) or return;
    my $manipulationConfig_href = shift @args;

    return CallDeviceFunction($manipulationConfig_href);
}

=head2 PRD_Get_ECU_Properties

    $ecuProperties_href = PRD_Get_ECU_Properties( [$options_href] );
    
Read ECU properties as defined by $options_href, see argument description.

B<Arguments:>

=over

=item optional $options_href

    $options_href = {
        'Property_names' => [<property1>, <property2>, ...]
    }

The key 'Property_names' has array reference of properties.
Properties can be following : 'ECU_status', 'ECU_details' and 'Lamp_status'

B<If 'Property_names' is not defined, then all applicable properties are considered.>

=back

B<Return Values:>

=over

=item $ecuProperties_href 

Below all possible keys are listed for AB12. Sub-keys of 'Lamp_status' are project specific and the shown ones are only examples.

B<Note: Currently, the Lamp_status enums with comments are defined only for Core Asset, JLR and Daimler. Please contact TurboLIFT Team to add your project specific Lamp_status enums.>


    $ecuProperties_href = {
        'ECU_status' => {
            'Fault_memory_status' => 0|1
            'EDR_status' => 0|1
            'Data_flash_status' => 0|1
            'Electronic_firing_status' => 0|1
            'ECU_mode' => 'Init1'|'Init2'|'Init3'|'Idle'|'NormalDriving'|'Disposal'|'Crash'|'ReProg'
        },
        'ECU_details' => {
            'EcuGeneration'  => ab_generation,
            'PdVersionNr'    => version_nbr,
            'DMC_PlantID'    => plant_id,
            'DMC_LineID'     => line_id,
            'DMC_CounterID'  => counter_id,
            'DMC_Date'       => date,
            'DMC_PartNumber' => part_num,
            'EcuSwVersion'   => SW_version,
            'ECU_fingerprint'=> finger_print
            'ECU_AlgoParameter_ID' => algo_id
            'Variant_ID'     => variant_id
            'Variant_Version => variant_ver
        },
        'Lamp_status' => { 
             SystemWarningLamp => 'On',
             AOutPassAirbagOffIndicator => 'Off', #example 
             AOutPassAirbagOnIndicator => 'Off',  #example
        },
    }

$ecuProperties_href = undef on error

=back

B<Examples:>
   
    # All ECU properties will be returned
    $ecuProperties_href = PRD_Get_ECU_Properties();
    
    # Only 'ECU_details' will be returned
    $options_href = { 'Property_names' => ['ECU_details'] };
    $ecuProperties_href = PRD_Get_ECU_Properties( $options_href );
    
    # 'ECU_details' and 'ECU_status' will be returned
    $options_href = { 'Property_names' => ['ECU_details', 'ECU_status'] };
    $ecuProperties_href = PRD_Get_ECU_Properties( $options_href );
    
    # Only 'Lamp_status' will be returned
    $options_href = { 'Property_names' => ['Lamp_status'] };
    $ecuProperties_href = PRD_Get_ECU_Properties( $options_href );
    
=cut

sub PRD_Get_ECU_Properties {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Get_ECU_Properties( [,$options_href] )', @args ) or return;
    my $options_href = shift @args;

    return CallDeviceFunction($options_href);
}

=head2 PRD_ECU_Reset

    $success = PRD_ECU_Reset( [$options_href] );

Resets the ECU (soft reset by default) and optionally waits after resetting.

Number of ECU resets can be configured by parameter 'numberOfResets'.

B<Arguments:>

=over

=item optional $options_href

    $options_href = {
        'resetType' => 'SOFT'|'HARD' (case insensitive)
        'wait_time_after_reset_ms' => <positive integer> or <string> (eg:5/'TIMER_ECU_RESET')
        'numberOfResets' => <positive integer>
    }
    
Default value for reset type is B<SOFT>
Default value for wait time is B<0>.
Default value for number of resets is B<1>.

If wait time is a string then it is used as a key in project const and the function waits for the amount of ms defined by the value in project const.
   
=back

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    # soft reset without waiting
    $success = PRD_ECU_Reset();    

    # hard reset with 3sec. waiting
    $options_href = {
        'resetType'                => 'HARD',
        'wait_time_after_reset_ms' =>  3000,
    }    
    $success = PRD_ECU_Reset($options_href);
    
    # assuming $Defaults => {'TIMER'}{'TIMER_ECU_RESET'} is set to 5000
    # soft reset with 5sec. waiting
    $success = PRD_ECU_Reset( {wait_time_after_reset_ms => 'TIMER_ECU_RESET'} );
    
    # Hard reset, number of resets set to 3
    $options_href = {
        'resetType'                => 'HARD',
        'wait_time_after_reset_ms' =>  3000,
        'numberOfResets' => 3,
    }

=cut

sub PRD_ECU_Reset {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_ECU_Reset( [$options_href] )', @args ) or return;

    return CallDeviceFunction(@args);
}

=head2 PRD_Check_ECU_Properties

    $success = PRD_Check_ECU_Properties( $expectedProperties_href );

Checks if the actual ECU properties match all expected values of ECU properties in $expectedProperties_href.

B<Arguments:>

=over

=item $expectedProperties_href

Expected ECU properties and their values.

    $expectedProperties_href = {
        <property1> => <expected_value1>,    # any property of section ECU_details from function 
                                             # PRD_Get_ECU_Properties with an expected value
        <property2> => <expected_value2>,    # see above
        ...
        action_on_mismatch => <action>,      # can be one of 'none' (default), 'warning', 'error', 'fail'
    }

If <property> is 'EcuSwVersion' then <expected_value> can also be given as 'ROMCODE'. In that case the expected EcuSwVersion is defined by the SAD file.

'action_on_mismatch' controls the behaviour of the function if one or more of the properties do not match the expected values (mismatch). 

If 'action_on_mismatch' is not provided the by default it will be considered as 'none'.

If 'action_on_mismatch' = 'none' then only the return value is set to undef on mismatch of properties.

If 'action_on_mismatch' = 'warning' then a warning is set on mismatch of properties. 

If 'action_on_mismatch' = 'error' then an error is set on mismatch of properties. 

If 'action_on_mismatch' = 'fail' then the verdict 'FAIL' is set on mismatch of properties.

=back

B<Return Values:>

=over

=item $success

Returns 1 if all expected values of properties in $expectedProperties_href are equal to the actual values.

Returns undef otherwise.

=back

B<Examples:>

    # Checks if ECU SW version matches the one defined in the SAD file and sets the verdict 'FAIL' if not
    my $success = PRD_Check_ECU_Properties({ 'EcuSwVersion' => 'ROMCODE',
                                             'action_on_mismatch' => 'fail',  });
                                             
    # Checks if 'ECU_FingerPrint' is '01#010101' and 'Fault_memory_status' is 1 and returns undef if not.                              
    my $success = PRD_Check_ECU_Properties({ 'ECU_FingerPrint' => '01#010101', 'Fault_memory_status' => 1});

=cut

sub PRD_Check_ECU_Properties {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Check_ECU_Properties( $expectedProperties_href )', @args ) or return;
    my $expectedProperties_href = shift @args;
    return CallDeviceFunction($expectedProperties_href);
}

=head2 PRD_Read_Fault_Memory

    $faultMemory_href = PRD_Read_Fault_Memory( $faultType );

Reads the fault memory, based on $faultType given.

The FLT file should be present in the same location where the SAD file is present.

B<Important note: No evaluation functions for fault memory are implemented in LIFT_ProdDiag. 
Therefore if any evaluation of fault memory is to be done then the function LIFT_FaultMemory::read_fault_memory
and the corresponding evaluation functions of LIFT_FaultMemory should be used. See:>

=for html
<a href='LIFT_FaultMemory.html#read_fault_memory'>LIFT_FaultMemory::read_fault_memory documentation</a>
<br><br>

B<Arguments:>

=over

=item $faultType

Supported fault types:

    PLANT
    PRIMARY
    BOSCH
    DISTURBANCE

=back

B<Return Values:>

=over

=item $faultMemory_href

Below examples are given for the different fault types for AB12.

B<PRIMARY FAULT MEMORY:>

    $faultMemory_href = {
        # fault index starts from 0 and continues based on number of faults
        '0' => {
            'Test_not_completed_this_operation_cycle' => '0',
            'Test_failed_since_last_clear' => '1',
            'Confirmed_DTC_Stored' => '1',
            'Status' => '0xAF',
            'Pending' => '1',
            'Warning_lamp_indicator' => '1',
            'FaultName' => 'rb_sqm_UnexpectedBT1FD_flt',
            'DTC' => '0x807E55',
            'Test_failed_this_operation_cycle_Latched' => '1',
            'FaultID' => '633',
            'Test_failed_Filtered' => '1',
            'Test_not_completed_since_last_clear' => '0'
        },
        ...
    }
                        
B<BOSCH FAULT MEMORY:>

    $faultMemory_href = {
        # fault index starts from 0 and continues based on number of faults
        '0' => {
            'Status' => '0x01',
            'VUp_OutOfRange_present' => '0',
            'Squib_fired_in_the_current_POC' => '0',
            'FaultName' => 'rb_cap_TimeoutSeatMemSeatLgthPosnD_flt',
            'InitMode_active' => '0',
            'Test_not_Failed' => '0',
            'Qualification_PowerOn_Cycle' => '84281101',
            'Test_Failed' => 1,
            'DequalificationTime' => '0',
            'EventDebug_Data_HB' => '0x00',
            'ASIC_Temperature' => '67',
            'VBat_OutOfRange_present' => '0',
            'AlwaysCleared' => '0',
            'OccurrenceCounter' => '1',
            'GeneralStatus' => '0x20',
            'IdleMode_active' => '0',
            'QualificationTime' => '17408764',
            'DTC' => '0xC21087',
            'Dequalification_PowerOn_Cycle' => '0',
            'EventDebug_Data_LB' => '0x00',
            'Algo_active' => '0',
            'DIS_ALP_Low_side_power_lines_disabled' => '1',
            'FaultID' => '60'
        },
        ...
    }

B<PLANT FAULT MEMORY:>

    $faultMemory_href = {
        # fault index starts from 0 and continues based on number of faults
        '0' => {
            'Test_not_completed_this_operation_cycle' => '0',
            'Test_failed_since_last_clear' => '1',
            'Confirmed_DTC_Stored' => '1',
            'Status' => '0xAF',
            'Pending' => '1',
            'Warning_lamp_indicator' => '1',
            'FaultName' => 'rb_sqm_UnexpectedBT1FD_flt',
            'DTC' => '0x807E55',
            'Test_failed_this_operation_cycle_Latched' => '1',
            'FaultID' => '633',
            'Test_failed_Filtered' => '1',
            'Test_not_completed_since_last_clear' => '0'
        },
        ...
    }

B<DISTURBANCE FAULT MEMORY:>

    $faultMemory_href = {
        # fault index starts from 0 and continues based on number of faults
        '0' => {
            'Status' => '0x01',
            'VUp_OutOfRange_present' => '0',
            'Squib_fired_in_the_current_POC' => '0',
            'FaultName' => 'rb_sqm_UnexpectedAB1FP_flt',
            'InitMode_active' => '0',
            'TestDisturbed' => '0',
            'EventDebug_Data_HB' => '0x00',
            'VBat_OutOfRange_present' => '0',
            'TestCurrent' => '1',
            'AlwaysCleared' => '0',
            'GeneralStatus' => '0x20',
            'IdleMode_active' => '0',
            'DTC' => '0x801055',
            'EventDebug_Data_LB' => '0x00',
            'Algo_active' => '0',
            'FaultID' => '624',
            'DIS_ALP_Low_side_power_lines_disabled' => '1',
            'DisturbaneceCounter' => '0'
        },
        ...
    }

$faultMemory_href = undef on error

$faultMemory_href = {} # empty href when no faults

=back

B<Examples:>

    $faultMemory_href = PRD_Read_Fault_Memory('PRIMARY');     # Reads PRIMARY fault memory.
    $faultMemory_href = PRD_Read_Fault_Memory('BOSCH');       # Reads BOSCH fault memory.
    $faultMemory_href = PRD_Read_Fault_Memory('PLANT');       # Reads PLANT fault memory.
    $faultMemory_href = PRD_Read_Fault_Memory('DISTURBANCE'); # Reads DISTURBANCE fault memory.

=cut

sub PRD_Read_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Read_Fault_Memory( $faultType )', @args ) or return;
    my $faultType = shift @args;

    my $faultMemory_href = CallDeviceFunction($faultType);

    return unless ($faultMemory_href);    # error message handled in device layer

    return $faultMemory_href;
}

=head2 PRD_Clear_Fault_Memory

    $success = PRD_Clear_Fault_Memory( [, $options_href] );

Clears the fault memory. By default all fault memories are cleared and the function waits until the fault memory is actually cleared.

Optionally (see $options_href below) only the plant fault memory can be cleared. Also it is possible to let the function return immediately
without waiting until the memory s cleared. 

If the execution option "PD_ClearFaultMemory_using_ManipulateFaultMemory" is set, then the service for manipulating the fault memory to dequalify the primary faults is called first. 
Faults are cleared after this.

B<Arguments:>

=over

=item $options_href (optional)

    $options_href => {
        'faultType' => 'plant' or 'all' (default)
        'waitUntilClear' => 0 or 1 (default)
                     }

    'waitUntilClear': 1 -> Waits until the fault memory is cleared.
                      0 -> Does not wait until the fault memory is cleared.

=back

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    # clears all fault memories BOSCH, PLANT, PRIMARY and DISTURBANCE and waits until cleared 
    $success = PRD_Clear_Fault_Memory();

    # clears all fault memories and do not wait until the fault memory is cleared. 
    $success = PRD_Clear_Fault_Memory({'waitUntilClear' => 0});
    
    # clear only PLANT fault memory and do not wait until the fault memory is cleared.
    $success = PRD_Clear_Fault_Memory({'faultType' => 'PLANT'});

B<Notes: 1. Either all types of memories can be cleared or only 'PLANT', other memories can't be cleared explicitly
         2. 'waitUntilClear' can be used only for 'all' fault types, not for 'PLANT'.>

B<For information on how to use exec options please refer

=for html
<a href="https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Execution%20Options?section=ii1">WIKI page link</a><br />
<br>

=cut

sub PRD_Clear_Fault_Memory {
    my @args = @_;

    S_checkFunctionArguments( 'PRD_Clear_Fault_Memory( [,$options_href] )', @args ) or return;

    my $options_href = shift @args;

    return unless CallDeviceFunction($options_href);

    return 1;
}

=head2 PRD_Read_Memory

    $memoryContents = PRD_Read_Memory( $label [, $options_href] );

Reads data from a memory location ($label) from various sections like RAM, ROM, external EEPROM, Dataflash and NVM.
The memory location can be given either as variable name or as memory address.
The return value can be either a single integer number or an array reference with the byte values.

B<Arguments:>

=over

=item $label

If given as variable name then the corresponding address is fetched from the SAD file.

If given as address then this address is directly used and it is not verified whether the address is present in SAD file or not.
Address may be integer or hex e.g '0x40006F4'. If address is given in hex format then the address should be prefixed with 0x.

=item $options_href

    $options_href = {
        NbrOfBytes => <integer>,
        memoryContentsAsInteger => 0|1,
    };

NbrOfBytes: Number of bytes to be read. If not given then the number of bytes is determined from the variable type. 
E.g. 1 byte for U8/S8, 2 bytes for U16/S16, etc. If no type can be determined then 1 byte is read.
    
If memoryContentsAsInteger is 0 (default) then $memoryContents is an array ref of memory bytes
    
If memoryContentsAsInteger is 1 then $memoryContents is an integer number, calculated from the bytes and depending on label type and endianness. 
So, if the label type is S8, S16, ... then the integer number can be negative. If no type can be determined then U8 shall be assumed.
        
Total number of bytes to be read (integer), can not be greater than 2047.

B<Note:> When both 'memoryContentsAsInteger' and 'noOfBytes' are passed only 'memoryContentsAsInteger' is considered.
                                   
=back

B<Return Values:>

=over

=item $memoryContents 

Success      : Integer or reference to the array containing the data(integer byte values) read from the respective memory address.

Offline mode : 1 or [1]

Error        : undef

=back

B<Examples:>
    
    # Read 3 bytes, starting from the address 0xFED48004
    $options_href = {NbrOfBytes => 3};
    $memoryContents = PRD_Read_Memory( '0xFED48004', $options_href );
    # $memoryContents = [ 40, 0, 6]
    
    # Read contents of variable name 'rb_res_IllegalEventData_dfst'. Address is fetched from the SAD file.  
    # Nbr of bytes is not given by user and not defined by the variable name, so 1 byte is read.
    $memoryContents = PRD_Read_Memory('rb_res_IllegalEventData_dfst'); 
    # $memoryContents = [40]
    
    # Read 4 bytes from location of 'rb_res_IllegalEventData_dfst'
    $memoryContents = PRD_Read_Memory('rb_res_IllegalEventData_dfst', {NbrOfBytes => 4});
    # $memoryContents = [40, 0, 6, 4]
    
    # Read 4 bytes from given variable location, since 'u32' is mentioned in the variable name 
    # and Nbr of bytes is not provided by the user
    $memoryContents = PRD_Read_Memory('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32');  
    # $memoryContents = [0, 0, 2, 44]
    
    # Returns memory contents as integer: [0, 0, 2, 44] => 556 because memoryContentsAsInteger = 1
    $memoryContents = PRD_Read_Memory('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', {memoryContentsAsInteger => 1});
    # $memoryContents = 556
    
    # When both 'memoryContentsAsInteger' and 'noOfBytes' are passed only 'memoryContentsAsInteger' is considered
    $memoryContents = PRD_Read_Memory('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32', {memoryContentsAsInteger => 1, NbrOfBytes => 4 });
    # $memoryContents = 556

=cut

sub PRD_Read_Memory {
    my @args = @_;

    S_checkFunctionArguments( 'PRD_Read_Memory( $label[, $options_href] )', @args ) or return;
    my $label        = shift @args;
    my $options_href = shift @args;

    return CallDeviceFunction( $label, $options_href );

}

=head2 PRD_Freeze_Fault_Memory

    $success = PRD_Freeze_Fault_Memory();

Requests for freezing of fault memory. No faults will qualify/Disqualify until a reset is done.

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Notes:> 

User will not able to request the Freeze fault memory again after already freezing the fault memory. 

During the period of freezing fault memory, No fault will qualify or disqualify until an ECU reset is done.

=cut

sub PRD_Freeze_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Freeze_Fault_Memory()', @args ) or return;
    return CallDeviceFunction();
}

=head2 PRD_Start_Fast_Diagnosis

    $csv_data_file_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href );
    
Starts the fast diagnosis recording as defined by $fastDiagConfig_href and returns the path to the folder with the created csv data files. 

B<Arguments:>

=over

=item $fastDiagConfig_href

    $fastDiagConfig_href = {
        labels => [<label_1>, <label_2>, ...], 
        number_of_BUS_Ids => ...,   # optional
        time_resolution_ms => ...,  # optional
        is_next_POC => 0|1,         # optional
        csv_data_file_path => ...,  # optional
    }

Below are the parameters in the hash reference

B<labels> : Array reference with label names for which fast diagnosis data will be read. Maximum 28 bytes of data are allowed to read for CAN.
Each label name can be in the below formats:

    '<SAD file label>',                      e.g. 'Adc_GroupInfo(0).resultBuffer_puo_U8'
    '<SAD file label>;<type specification>', e.g. 'rb_sycc_SysConfCsemDataEe_st.sensorID;U8'
    '<address>;<type specification>',        e.g. '0xFEDFF395;U8'        

If types are not given as input or the label does not have the type as a part of the name then 'U8' is assumed for those labels.
Possible data types are U8,U16,U32,U64,S8,S10,S16,S32,U64,S64.

B<number_of_BUS_Ids> (optional): Number of bus IDs to be used for recording. For CAN it can be 1 - 4, 
but the maximum number of IDs can be limited for certain projects.
The higher the number_of_BUS_Ids, the better the time resolution of the recorded data.
For CAN-FD and flexray number_of_BUS_Ids can be only 1.

If neither number_of_BUS_Ids nor time_resolution_ms is defined then number_of_BUS_Ids will be the maximum number of BUS IDs supported by the project.

Defining number_of_BUS_Ids and time_resolution_ms at the same time is not allowed.

B<time_resolution_ms> (optional): Not yet supported. Desired time resolution of the data, possible values for CAN:  0.5, 1, 2, 4, 6, 8

B<is_next_POC> (optional): If set to 0 (default) then fast diagnosis starts immediately. If set to 1 then fast diagnosis starts on next ECU power on.

B<csv_data_file_path> (optional): Path of the directory where the data files for the individual labels shall be stored. 
If not given then the path is <report-folder>\FastDiagData_<date>_<time>.

=back

B<Return Values:>

=over

=item $csv_data_file_path

Success : Path of the directory where the data files for the individual labels are stored

Offline mode : Path of the directory where a dummy data file is stored

Error        : undef

=back

B<Examples:>

    # fast Diagnosis will start with 2 BUS IDs for label 'Adc_GroupInfo(0).resultBuffer_puo_U8'
    # for which type is U8 and files will be stored in the given folder
    $fastDiagConfig_href = {
        labels => ['Adc_GroupInfo(0).resultBuffer_puo_U8'], 
        number_of_BUS_Ids => 2,
        is_next_POC => 0,
        csv_data_file_path => 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/',
    }
    $csv_data_file_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href ); 

    # fast Diagnosis will start with 4 BUS IDs for label 'rb_sycc_SysConfCsemDataEe_st.sensorID' 
    # for which type is 'U16'
    $fastDiagConfig_href = {
        labels => ['rb_sycc_SysConfCsemDataEe_st.sensorID;U16'],     
    }
    $csv_data_file_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href );

    # fast Diagnosis will start 4 BUS IDs, for address '0xFEDFF395' and for
    # 'rb_sycc_SysConfCsemDataEe_st.sensorID', both with type U8, in the next power on cycle
    $fastDiagConfig_href = {
        labels => ['0xFEDFF395;U8', 'rb_sycc_SysConfCsemDataEe_st.sensorID'],     
        is_next_POC => 1,
    }
    $csv_data_file_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href );

=cut

sub PRD_Start_Fast_Diagnosis {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Start_Fast_Diagnosis( $fastDiagConfig_href )', @args ) or return;

    my $fastDiagConfig_href = shift @args;

    return CallDeviceFunction($fastDiagConfig_href);
}

=head2 PRD_Stop_Fast_Diagnosis

    $success = PRD_Stop_Fast_Diagnosis();
    
Stops a previously started fast diagnosis session.

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

=cut

sub PRD_Stop_Fast_Diagnosis {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Stop_Fast_Diagnosis()', @args ) or return;

    return CallDeviceFunction();
}

=head2 PRD_Get_Fast_Diagnosis_Data

    $fdData_href = PRD_Get_Fast_Diagnosis_Data([$options_href]);      
    
Gets the recorded fast diagnosis data from last recording (or from $options_href->{data_path}) and converts to standard data hash ($fdData_href). 
Timebase of $fdData_href is in seconds.

B<Arguments:>

=over

=item $options_href 

    $options_href ={
        'data_path' => <path to data files>
    }
    
B<data_path> (optional): path to the folder containing .csv files having the fast diagnosis data.
If data_path is not defined then the path last used in PRD_Start_Fast_Diagnosis is taken by default.    

=back

B<Return Value:>

=over

=item $fdData_href 

Success : Fast diagnosis data hash. For .csv data files time=0s is the start of the measurement.

Offline : { 0 => { 'dummy' => 0 } }

Error : undef

=back

B<Examples:>

    $data_path = PRD_Start_Fast_Diagnosis( $fastDiagConfig_href );
    S_wait_ms( 5000 ); 	
    PRD_Stop_Fast_Diagnosis();
    $fdData_href  = PRD_Get_Fast_Diagnosis_Data({'data_path' =>  $data_path});    
    
=cut

sub PRD_Get_Fast_Diagnosis_Data {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Get_Fast_Diagnosis_Data( [$options_href] )', @args ) or return;

    my $options_href = shift @args;

    return CallDeviceFunction($options_href);
}

=head2 PRD_Read_EDR

    $response_href = PRD_Read_EDR( $did [, $options_href] );

Reads EDR contents based on DID ($did) and returns the ECU response ($response_href).

In some projects Defect 219169 is not fixed and therefore an incomplete response will be sent by the ECU (last byte of the response is missing).
Normally this results in an error and undef being returned in this function. However if the execution option "Defect_219169_workaround" is set, 
then there will be only a warning in such cases and the response will be returned.

B<Arguments:>

=over

=item $did

Data id (did) is a hex byte. Depending on its value normal crash records or Pedestrian protection crash records are read.

    [0x00 to 0x0F] => Normal crash record.
    [0x10 to 0x1F] => Pedestrian protection crash record.

=item $options_href

    $options_href ={
        dump_filename => 'C:/TurboLIFT/TSG4/temp/craschrecord.txt'
        dump_file_format_version => 2|3, #default =2
        date_time_in_file_name => 0|1, # default = 1
    }
    
If 'dump_filename' is just a file name then the file will be created in the respective reports folder.

If 'dump_filename' is a complete path then it will be created in the respective file path.

If date_time_in_file_name is 1, the file name will be appended with a date/timestamp.

In $options_href, 

    dump_file_format_version => 2 for (.txt) file   
    dump_file_format_version => 3 for (.xml) file

If 'dump_file_format_version' is not defined then the default value of '2' is taken.

B<To know more about dump_file_format_version 3, please refer

=for html
<a href= "https://inside-docupedia.bosch.com/confluence/display/aeos/EDR+Crash+Record+-+Dump+Format#EDRCrashRecord-DumpFormat-FileFormatVersion3">File Formats Documentation</a><br />
<br>

=back

B<Return Values:>

=over

=item $response_href

Response hashref. See L</"PRD_Send_Request_Wait_Response"> for details.

undef on error.

=back


B<Examples:>

    # normal crash record with dump edr data with complete file path
    # If dump_file_format_version is not defined then the default value of 2 is taken
    $response_href = PRD_Read_EDR( 0x01, {'dump_filename' => 'C:/TurboLIFT/TSG4/temp/craschrecord.txt'} );

    # normal crash record with dump edr data with just file name: file will be generated in the reports folder
    # If dump_file_format_version is not defined then the default value of 2 is taken
    $response_href = PRD_Read_EDR( 0x01, {'dump_filename' => 'craschrecord.txt'} );

    # normal crash record without dump edr data
    $response_href = PRD_Read_EDR( 0x01 );
    
    # normal crash record with dump edr data with complete file path and edr dump file format version
    $response_href = PRD_Read_EDR(0x01, {'dump_filename' => 'C:/TurboLIFT/TSG4/temp/craschrecord.xml', dump_file_format_version => 3});
    
    # If dump_file_format_version other than 2 or 3 is given, default dump_file_format_version => 2 is considered and the execution continues with a warning.
    $response_href = PRD_Read_EDR(0x01, {'dump_filename' => 'C:/TurboLIFT/TSG4/temp/craschrecord.txt', dump_file_format_version => 5});

=cut

sub PRD_Read_EDR {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Read_EDR( $did, [,$options_href] )', @args ) or return;
    my $did          = shift @args;
    my $options_href = shift @args;

    return CallDeviceFunction( $did, $options_href );
}

=head2 PRD_Clear_EDR

    $response_href = PRD_Clear_EDR( [ $options_href ] );

Sends the service for Clear crash recorder and returns the ECU response immediatly if no wait time is given.

If a timeout ($options_href ->{timeout_ms}) is configured then the functions waits until the crash recorder has been cleared
or the timeout time is reached, which ever occurs first.

B<Arguments:>

=over

=item $options_href ( optional )

    $options_href = {
        timeout_ms => 10000 or 'TIMER_CLEAR_CRASH_RECORDER'
    }

If 'timeout_ms' is a positive number then that many ms as timeout.

If 'timeout_ms' is a string then take that string (e.g. 'TIMER_CLEAR_CRASH_RECORDER'):
consider the string as key in project const section 'TIMER' and wait the amount of ms defined by the value in project const.

If timeout_ms is not defined then timeout is 0 and the function returns immediately after receiving the response.
In that case the crash recorder will not yet be cleared when the function returns.

=back

B<Return Values:>

=over

=item $response_href

Response hashref. See L</"PRD_Send_Request_Wait_Response"> for details.

=back

B<Examples:>

    # no wait time
    $response_href = PRD_Clear_EDR();

    #Explicit wait time (positive integer) configured
    $response_href = PRD_Clear_EDR({timeout_ms => 10000});

    #Explicit wait time configured in project constant 'TIMER' section
    $response_href = PRD_Clear_EDR({timeout_ms => 'TIMER_CLEAR_CRASH_RECORDER'});

=cut

sub PRD_Clear_EDR {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Clear_EDR( [,$options_href] )', @args ) or return;
    my $options_href = shift @args;
    return CallDeviceFunction($options_href);
}

=head2 PRD_Electronic_Firing_Enable

    $success = PRD_Electronic_Firing_Enable( [$options_href] );
    
This function is to prepare ECU for electronic firing. Plant mode is set by default to facilitate electronic firing. 
    
B<Arguments:>

=over

=item $options_href (optional)

    $options_href = {
         set_plant_mode => 0|1, # default is 1
    }
    
If set_plant_mode = 1 then plant mode is set before sending the service. Otherwise plant mode is not set.
   
=back    

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    $success = PRD_Electronic_Firing_Enable({set_plant_mode => 0}); # Plant mode is not enabled     
    $success = PRD_Electronic_Firing_Enable(); # Plant mode is enabled 

B<Note: This function needs to be called before calling PRD_Electronic_Firing_Fire.> 

=cut

sub PRD_Electronic_Firing_Enable {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Electronic_Firing_Enable( [$options_href] )', @args ) or return;

    my $options_href = shift @args;

    return CallDeviceFunction($options_href);
}

=head2 PRD_Electronic_Firing_Fire

    $firingStatus_href = PRD_Electronic_Firing_Fire();
    
Triggers the electronic firing of all devices. Has to be enabled by calling PRD_Electronic_Firing_Enable before.
    
B<Return Values:>

=over

=item $firingStatus_href

    $firingStatus_href = {
        response_href => <response hashref>
        # other useful information to be returned is not yet defined
    }

=back

B<Note: This will not work if reset was done after calling PRD_Electronic_Firing_Fire, because values are only in RAM> 

=cut

sub PRD_Electronic_Firing_Fire {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Electronic_Firing_Fire()', @args ) or return;

    return CallDeviceFunction();
}

=head2 PRD_Sensor_Verification

    $sensorData_href = PRD_Sensor_Verification( $sensorConfig_href );
    
Sends the sensor verification service request to the ECU. Returns sensor type and ECU response.

B<Arguments:>

=over

=item $sensorConfig_href

Configuration settings of individual sensors, specifying how the verification data shall be collected by the ECU.

    my $sensorConfig_href = {
        sensor_type => 'SMI7'|'SMI8',
        <sensor1> => <processing1>,
        <sensor2> => <processing2>,
        ...
        amount_samples  => <integer>, # typically 1000
     }; 

For B<SMI7> each <sensorX> can be "Sensor<n>_<channel>" with <n> = 1|2|3|4 and <channel> = "Rate"|"ACC1"|"ACC2".
Each <processingX> can be 'LF_raw'|'HF_raw'|'LF_processed'|'HF_processed'.
E.g. Sensor1_Rate => 'LF_raw' or Sensor4_ACC2 => 'HF_processed'.

For B<SMI8> for accelerations each <sensorX> can be "Acc<D>_<type>" with <D> = "X"|"X_redundant"|"Y"|"Y_redundant"|"Z"|"Z_redundant" 
and <type> = "low_g"|"mid_g"|"high_h". Only those combination that are defined in requirement SRS_PRD_1918 are valid.
For rates each <sensorX> can be "Rate_w<D>" with <D> = "X"|"Y"|"Z"|"Z_redundant"
Each <processingX> can be 'raw'|'processed'.
E.g. AccX_low_g => 'raw' or Rate_wZ_redundant => 'processed'
If a sensor is not specified then by default its processing is set to 'raw'.

Alternatively for <sensorX> also "ALL" can be used. 
Then all sensors are configured to the same processing as given in the corresponding <processingX>.
E.g. ALL => 'processed' for SMI8.

The value of 'amount_samples' must be an integer > 1 and < 2049.
 
=back

B<Return Values:>

=over

=item $sensorData_href

    $sensorData_href = {
        sensor_type => ...,   # same as $sensorConfig_href->{sensor_type},
        response_href => ..., # ECU response hash
    }

The structure of response_href is defined in L</"PRD_Send_Request_Wait_Response">.
    
=back

B<Examples:>

For SMI7:

    my $sensorConfig_href = {
        'sensor_type'    => 'SMI7',
        'Sensor1_Rate'   => 'HF_raw',
        'Sensor1_ACC1'   => 'HF_raw',
        'Sensor1_ACC2'   => 'HF_raw',
        'Sensor2_Rate'   => 'HF_raw',
        'Sensor2_ACC1'   => 'HF_raw',
        'Sensor2_ACC2'   => 'HF_raw',
        'Sensor3_Rate'   => 'HF_raw',
        'Sensor3_ACC1'   => 'HF_raw',
        'Sensor3_ACC2'   => 'HF_raw',
        'Sensor4_Rate'   => 'HF_raw',
        'Sensor4_ACC1'   => 'HF_raw',
        'Sensor4_ACC2'   => 'HF_raw',
        'amount_samples' => 1000,
    };
    my $sensorData_href = PRD_Sensor_Verification($sensorConfig_href);

For SMI8:

    my $sensorConfig_href = {
        'sensor_type'          => 'SMI8',
        'AccZ_redundant_low_g' => 'processed'
        'AccX_mid_g'           => 'processed'
        'AccY_high_g'          => 'processed'
        'Rate_wX'              => 'processed'
        'amount_samples'       => 1000,
    };
    my $sensorData_href = PRD_Sensor_Verification($sensorConfig_href);


B<Note:>

See SRS_PROD_ProductionDiagnosis ID SRS_PRD_656 ff (SMI7) and SRS_PRD_1910 ff (SMI8) for more information about the response bytes.

=cut

sub PRD_Sensor_Verification {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Sensor_Verification( $sensorConfig_href )', @args ) or return;
    my $sensorConfig_href = shift @args;
    return CallDeviceFunction($sensorConfig_href);
}

=head2 PRD_Write_Memory

    $success = PRD_Write_Memory( $label, $memoryContents );
    
Writes the data given in $memoryContent into ECU at $label.

B<Arguments:>

=over

=item $label

Memory location. $label can be either a variable name or an address. 

If it is a variable name then the corresponding address is fetched from the SAD file.

If it is an address then this address is used for writing. Address can be given in decimal (e.g. 67110644) or as hex string (e.g '0x40006F4'). 
An address will not be verified whether it is present in SAD file or not.

=item $memoryContents

Data that shall be written into memory. $memoryContents can be either an array reference or an integer.

If $memoryContents is an array reference then it defines the bytes to be written.
Bytes can be given in decimal (e.g. [ 40, 0, 6 ]) or as hex strings (e.g. [ '0x28', '0x00', '0x06' ])

If $memoryContents is an integer then the bytes to be written are calculated from the integer depending on label type and endianness.
If no type can be determined then U8 will be assumed.

Example: if $memoryContents is 555 and the variable is of type U16 then it will be converted to array of bytes as below:

    555 => 22B (hex)
    2 2B => 2(2) 43(2B)
    Finally the data to be written to ECU will be [2, 43]. 

If $memoryContents is an integer, the calculated number of bytes will be validated with the allowed number of bytes
based on the type (U8,U32,S8,S16, etc.). An error is thrown if the data is exceeding the allowed number of bytes.

Example: If $memoryContents is 555 and the type is U8, an error will be thrown because 555 does not fit into 1 byte.
   
If the Integer is more than 32 bit long, It MUST be quoted, see examples below.

=back

B<Return Values:>

=over

=item $success 

1 on success or in offline mode, undef otherwise

=back

B<Examples:>

    # Address = 0xFED48004, Data to be written = 40, 0, 6
    $success = PRD_Write_Memory( '0xFED48004', [ 40, 0, 6] );
    
    # Address = rb_sycg_ActivePlantModes_au8(0), Data to be written = 2, 43 
    # Throws an error as the address is of 1 byte and trying to write 2 bytes of data
    $success = PRD_Write_Memory( 'rb_sycg_ActivePlantModes_au8(0)', 555 );

    # Address = rb_res_IllegalEventData_dfst, Data to be written = 0x40, 0x1A, 0x06, 0x04
    $success = PRD_Write_Memory('rb_res_IllegalEventData_dfst', [ 0x40, 0x1A, 0x06, 0x04]);
    
    # Address = rb_cs7m_RUVData_ast(0).QuadI_st.QuadSum_u64, 
    # Data to be written = [ 0x22, 0x45, 0x04, 0x12, 0x42, 0x28, 0x48, 0x84 ]
    $success = PRD_Write_Memory( 'rb_cs7m_RUVData_ast(0).QuadI_st.QuadSum_u64', '2469384447148443780' );

B<Notes:> 

If the number is negative and the datatype is Unsigned, an error will be shown to the user

If the $memoryContents is an integer, endianness format will be done based on ECU endianness

=cut

sub PRD_Write_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Write_Memory( $label, $memoryContents_mix )', @args ) or return;

    my $label          = shift @args;
    my $memoryContents = shift @args;

    return CallDeviceFunction( $label, $memoryContents );
}

=head2 PRD_Read_ECU_NVM

    $nvmMemoryContents_aref = PRD_Read_ECU_NVM( $nvmConfig_href );

Read data from a NVM memory block as defined by $nvmConfig_href.

B<Arguments:>

=over

=item $nvmConfig_href

    $nvmConfig_href = {
        block_name => ...,   # string, block name as defined in the nvm file
        block_ID => ...,     # integer, block ID number
        no_of_bytes => ... , # integer, number of bytes to be read
        format_data_by_endianness => 0|1, # default = 0
    }

If block_name is defined then block_ID and no_of_bytes is taken from the data of the NVM file.

If block_name is defined and no_of_bytes is also defined then no_of_bytes provided by the user will be taken

If block_name is defined and block_ID is defined then an error shall be thrown.

=back


B<Return Values:>

=over

=item $nvmMemoryContents_aref

Array of data bytes (integer) read from NVM memory.
By default or if format_data_by_endianness is set to false no correction for endianness of ECU is done.
If format_data_by_endianness is set to true then the data bytes will be corrected for endianness of ECU.

=back


B<Examples:>

B<Notes:> 

=cut

sub PRD_Read_ECU_NVM {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Read_ECU_NVM( $nvmConfig_href )', @args ) or return;
    my $nvmConfig_href = shift @args;

    return CallDeviceFunction($nvmConfig_href);
}

=head2 PRD_Write_ECU_NVM

    $success = PRD_Write_ECU_NVM( $nvmConfig_href, $nvmMemoryContents_aref );

Write data ($nvmMemoryContents_aref) to a NVM memory block as defined by $nvmConfig_href.

B<Arguments:>

=over

=item $nvmConfig_href

Defines the NVM memory location either as block_name or as block_ID:

    $nvmConfig_href = {
        block_name => ...,   # string, block name as defined in the nvm file _OR_
        block_ID => ...,     # integer, block ID number
        no_of_bytes => ... , # integer, number of bytes to be written (optional)
    }

If block_name is defined then block_ID and no_of_bytes is taken from the data of the NVM file.
If block_name is defined and no_of_bytes is also defined then no_of_bytes provided by the user will be taken.
If both block_name and block_ID is defined then an error will be thrown.

=item $nvmMemoryContents_aref

Array reference of data bytes (integer) to be written to NVM memory.

If no_of_bytes is not defined and not taken from NVM file then write all bytes from $nvmMemoryContents_aref.

If no_of_bytes is defined or taken from NVM file then:

- If no_of_bytes >= sizeof $nvmMemoryContents_aref then write all bytes in $nvmMemoryContents_aref.

- If no_of_bytes < sizeof $nvmMemoryContents_aref then write no_of_bytes bytes in $nvmMemoryContents_aref and throw a warning.

=back


B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back


B<Examples:>

=cut

sub PRD_Write_ECU_NVM {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Write_ECU_NVM( $nvmConfig_href, $nvmMemoryContents_aref )', @args ) or return;
    my $nvmConfig_href         = shift @args;
    my $nvmMemoryContents_aref = shift @args;

    return CallDeviceFunction( $nvmConfig_href, $nvmMemoryContents_aref );
}

=head2 PRD_Set_Device_Configuration

    $success = PRD_Set_Device_Configuration( $devices_modes_href  [, $options_href ] );
    
Sets device(s) to given mode(s) ('set_Configure', 'clear_Configure', 'set_Monitor' and 'clear_Monitor'), depending on $devices_modes_href.

B<Arguments:>

=over

=item $devices_modes_href

Defines which devices shall be set to which mode(s).

    $devices_modes_href = {    
      <device_1> => [<mode_1>, <mode_2>, ...],   
      <device_2> => <mode_3>,        
    }

B<<device_x>>: Name of a device as defined by project specific enums in the *.CNS file or defined in $ProjectDefaults->{'DEVICE_CONFIG'} ("DEVICE_CONFIG mapping"). 

Device names are B<CASE SENSITIVE>.

If <device_x> is found on the left side of the DEVICE_CONFIG mapping then the corresponding right side of the mapping will be searched in project specific enums in the *.CNS file.

Devices are grouped in device types: lamps, squibs, SpBehaviour, parSections, pases, switches, asics.

Examples: 

         device_x                           CNS file variables 

    'AOutSysWarningIndicator'   ->     rb_syco_AOutSysWarningIndicator_e    (lamps)
    'AB1FD'                     ->     rb_sycf_AB1FD_e                      (squibs)
    'SpecBehItmDebugDelay'      ->     rb_sycg_SpecBehItmDebugDelay_e       (staticbehaviour)
    'Dummy'                     ->     rb_sycg_Dummy_e                      (dynamicbehaviour)
    'UfsC'                      ->     rb_sycp_UfsC_e                       (pases)
    'PADS1'                     ->     rb_sycs_SwitchPADS1_e                (switches)
    'SystemAsic1'               ->     rb_syca_AllAsicsSystemAsic1_e        (asics)
           
B<<mode_x>> : It is one of: 'set_Configure', 'clear_Configure' to configure/unconfigure or 'set_Monitor', 'clear_Monitor' to enable/disable monitoring. 
It is case insensitive.

Values of $devices_modes_href can be either scalar, then only one mode will be set for a device, or array refs, 
then several modes will be set for one device in the order of the array.

B<Note: Monitoring will not work on devices of types asics, staticbehaviour, dynamicbehaviour.>

B<Note: It is possible that parts of DEVICE_CONFIG_VARIABLES hash can be overwritten by an appropriate section in project const (L</"Project-Defaults-for-AB12">)>

  
=item $options_href (optional)

$options_href determines whether there shall be a reset with possible wait time after the device configuration settings.

    $options_href = {
        'resetType' => 'SOFT'|'HARD',            # type of reset(SOFT/HARD), case insensitive
        'wait_time_after_reset_ms' => <integer>, # wait time (ms) after reset, positive integer
    }
 
If wait_time_after_reset_ms is a string (e.g. 'TIMER_ECU_RESET'): then the string is considered as key in project const 
and waits the amount of ms defined by the value in project const.

B< If $options_href is not defined then no reset and no waiting will be done.>

If resetType is not defined then by default 'SOFT' is considered.

=back

B<Return Values:>

=over

=item $success 

1 on success or in offline mode, undef otherwise

=back

B<Examples:>
     
     # Configure and Monitor bit will be set for Device 'AB1FD' and Configure bit will be cleared for device 'UFSL'
     $devices_modes_href = {
        'AB1FD' => ['set_Configure', 'set_Monitor'],
        'UFSL' => 'clear_Configure',
     };
     $success = PRD_Set_Device_Configuration( $devices_modes_href );
     
    # Same as above, but Hard reset will be done after device configuration 
    # and then waiting will be done for 10000 ms
    $options_href = {
        'resetType' => 'HARD',
        'wait_time_after_reset_ms' => 10000,
    };     
    $success = PRD_Set_Device_Configuration( $device_modes_href, $options_href );

=cut

sub PRD_Set_Device_Configuration {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Set_Device_Configuration( $device_modes_href  [, $options_href ] )', @args ) or return;

    my $device_modes_href = shift @args;
    my $options_href      = shift @args;

    return CallDeviceFunction( $device_modes_href, $options_href );
}

=head2 PRD_Get_Device_Configuration

    $device_config_href = PRD_Get_Device_Configuration([, $options_href ]);

Gets the Device configuration details for all devices with values for 'Configured', 'Monitored', 'Presence' and 'Index'.

Additionally 'Type' of device is returned for all devices. 'Asic_Id' and 'Asic_Channel' are returned only for squibs, switches and pases.

B<Note:>  1. If the squib is not present physically the Asic_Id is returned as 15 ( from ECU SW ).
          2. IF DEVICE_CONFIG is configured in project constant then the device names are taken from DEVICE_CONFIG.

B<Arguments:>

=over

=item $options_href

    $options_href = {
        'devices' => [<device1>, <device2>, ...],                  # OR
        'device_types' => [ <deviceType1>, <deviceType2>, ... ],
        'NOHTML' => 1, # device details table will not be printed to HTML report
    };

B<Defining both 'devices' and 'device_types' is not allowed.>

devices : Names of a devices as defined by project specific enums in the *.CNS file. Device names are CASE SENSITIVE

See L</"PRD_Set_Device_Configuration"> for examples.

device_types : Device types can be any of these: 'lamps', 'squibs', 'staticbehaviour', 'dynamicbehaviour', 'pases', 'switches', 'asics'

Device type names are case insensitive

=back

B<Return Values:>

=over

=item $device_config_href

Returns 'Presence', 'Configure', 'Index' and 'Type' values for all the devices.

'Monitor' is not returned for devices belonging to types: asics and special behaviour types 'StaticBehaviour' and 'DynamicBehaviour'.

'Asic_Id' and 'Asic_Channel' are returned only for squibs, switches and pases.

Success : 

     $device_config_href = {
         # For devices which belongs to one of types: pases, squibs, lamps or switches
        'squibs' => {
             'AB1FD' => {
                 'Presence' => 1,     # device is present
                 'Configured' => 1,   # device is configured
                 'Monitored' => 1,    # device is monitored
                 'Index' => 0         # device index is 0
                 'Asic_Id' => 0,      # device assigned to Asic ID 0
                 'Asic_Channel' => 4, # device assigned to Asic channel 4
                 'Type' => 'squibs'
             },
             'AB1FP' => {
                 'Presence' => 0,     # if device not present
                 'Configured' => 0,   # if device not configured
                 'Monitored' => 0     # if device not monitored
                 'Index' => 1,        # device index is 1
                 'Asic_Id' => 0,      # device assigned to Asic ID 0
                 'Asic_Channel' => 2, # device assigned to Asic channel 2
                 'Type' => 'squibs'
            },
            ...
        },
        ...
        # For devices which belongs to one of types: asics and StaticBehaviour and DynamicBehaviour
        'asics' => {
            'CentralSensorMain' => {
                 'Presence' => 1,
                 'Configured' => 1,
                 'Index' => 0,
                 'Type' => 'asics'                          
             },
             ...
        },
        ...
    }

Error : undef

=back

B<Examples:>

1. Returns all devices configuration details

    $device_config_href = PRD_Get_Device_Configuration();

2. Return specific Device types

    $device_config_href = PRD_Get_Device_Configuration({'device_types'  => [ 'squibs' ]});

3. Return specific Devices

    $device_config_href = PRD_Get_Device_Configuration({'devices'  => [ 'AB1FD'  , 'AB1FP' ]});

4. Returns Device names mapped in DEVICE_CONFIG.
   
   # In project constants
   $Defaults = {
                 'DEVICE_CONFIG' => {
                     
                  #mapped name     #actual name from cns,sad
                    'PASRC'     => 'PasRC',
                    'PTSP'      => 'PtsP',
                 }
               }

   # Function call
   $device_config_href = PRD_Get_Device_Configuration({'devices'  => [ 'PASRC'  , 'PTSP' ]});
   
   # Return value
   $device_config_href = {
        
        'PASRC' => {
                 'Presence' => 1,     # device is present
                 'Configured' => 1,   # device is configured
                 'Monitored' => 1,    # device is monitored
                 'Index' => 0         # device index is 0
                 'Asic_Id' => 0,      # device assigned to Asic ID 0
                 'Asic_Channel' => 4, # device assigned to Asic channel 4
                 'Type' => 'pases'
             },
        'PTSP' => {
                 'Presence' => 0,     # if device not present
                 'Configured' => 0,   # if device not configured
                 'Monitored' => 0     # if device not monitored
                 'Index' => 1,        # device index is 1
                 'Asic_Id' => 0,      # device assigned to Asic ID 0
                 'Asic_Channel' => 2, # device assigned to Asic channel 2
                 'Type' => 'pases'
            },
    }

=cut

sub PRD_Get_Device_Configuration {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Get_Device_Configuration(  [, $options_href ] )', @args ) or return;

    my $options_href = shift @args;

    return CallDeviceFunction($options_href);
}

=head2 PRD_Dump_Memory_To_File

    $fileName = PRD_Dump_Memory_To_File( $memoryType [, $options_href ] );

Dumps ECU memory of type $memoryType to a file.

B<Arguments:>

=over

=item $memoryType

Type of memory to dump, currently only 'NVM' is supported. In later versions also memory types 'EEPROM', 'RAM', 'FLASH' will be supported.

=item $options_href

    $options_href = {
        file_name => ...   # name or path of the file that will be written, default path is report folder
        date_time_in_file_name => 0|1, # default = 1
    }

If file_name is not defined then a file will be written in report folder. 
The file name and extention depends on $memoryType.

For $memoryType 'NVM' by default the file name format is 'ALL_NVM_Sections_<Date>_<Time>.txt'.
If date_time_in_file_name is 0 then _<Date>_<Time> will not be added to the file name.

=back

B<Return Values:>

=over

=item $filename

The full file name (incl. path) will be returned on success. Undef will be returned on error.

=back

B<Examples:>

    # file will be generated in the reports folder.
    $fileName = PRD_Dump_Memory_To_File('nvm');

    # file will be generated in the path C:/TurboLIFT/TSG4/Readmemory.txt
    $fileName = PRD_Dump_Memory_To_File('nvm', {file_name => 'C:/TurboLIFT/TSG4/Readmemory.txt'});

=cut

sub PRD_Dump_Memory_To_File {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Dump_Memory_To_File( $memoryType [, $options_href ]  )', @args ) or return;
    my $memoryType   = shift @args;
    my $options_href = shift @args;

    return CallDeviceFunction( $memoryType, $options_href );
}

=head2 PRD_Write_Dump_To_ECU

    $success = PRD_Write_Dump_To_ECU( $dumpfile );

Not yet implemented.

B<Arguments:>

=over

=item $dumpfile

=back


B<Return Values:>

=over

=item $success

=back


B<Examples:>

B<Notes:> 

=cut

sub PRD_Write_Dump_To_ECU {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Write_Dump_To_ECU( $dumpfile )', @args ) or return;
    my $dumpfile = shift @args;

    return CallDeviceFunction($dumpfile);
}

=head2 PRD_Get_Symbol_Mapping

    $mapping_info = PRD_Get_Symbol_Mapping( $mappingPart_href );

Returns information about SAD file variables, fault names or enum values.

B<Arguments:>

=over

=item $mappingPart_href
 
Defines for which SAD file variable or fault name the information should be retrieved.
    
    $mappingPart_href = {
        symbol_name => <name>,  # OR
        fault_name  => <name>,  # OR
        enum_type   => <type>
    }

B<Either "symbol_name" or "fault_name" or "enum_type" can be given but not more than one.>
    
=back

B<Return Values:>

=over

=item $mapping_info

Symbol mapping information based on the input (symbol_name or fault_name or enum_type).
    
If a B<symbol_name> is passed as input then the following hashref is returned:

    $mapping_info = {
        'enum_or_mask' => <string>, # enum or mask associated with the variable
        'address' => <integer>      # address of the variable
        'description' => <string>,  # description of the variable
    }
    
If a B<fault_name> is passed as input then the corresponding Fault ID is returned as scalar. 

If B<enum_type> is passed as input then the following hashref is returned:

    $mapping_info = {
        <enum_name1> => {
            'value'   => <integer>, # enum value that corresponds to enum_name1
            'comment' => <string>,  # comment for that enum value
        },
        <enum_name2> => {
            'value'   => <integer>, # enum value that corresponds to enum_name2
            'comment' => <string>,  # comment for that enum value
        },
        ...
    }

If no entry is found in the symbol mapping for the given inputs then no error is thrown but undef is returned.

=back

B<Examples:>

    $mapping_info = PRD_Get_Symbol_Mapping( { 'symbol_name' => 'rb_acc_AlgoIds_st.ParaId_u8' } );
    # returns e.g.:
    # $mapping_info = {
    #    'enum_or_mask' => '\n',
    #    'address' => 4273934933,
    #    'description' => 'Parameter ID'
    # }

    $mapping_info = PRD_Get_Symbol_Mapping( { 'fault_name' => 'rb_pom_VerLow_flt' } ); 
    # returns e.g.  $mapping_info = 100

    $mapping_info = PRD_Get_Symbol_Mapping( { 'enum_type' => 'rb_wimi_SysWIInidcatorMode_ten' } );
    # returns e.g.:
    # $mapping_info = {
    #    'rb_wimi_SysWIOffBeforeInitPhase_e' => {
    #        'value' => 0,
    #        'comment' => 'Indicator is off before the initialization phase'
    #    }
    #    ...
    # }

=cut

sub PRD_Get_Symbol_Mapping {
    my @args = @_;
    S_checkFunctionArguments( ' PRD_Get_Symbol_Mapping( $mappingPart_href )', @args ) or return;
    my $mappingPart_href = shift @args;

    return CallDeviceFunction($mappingPart_href);
}

=head2 PRD_Get_Device_Property

    $propertyValue = PRD_Get_Device_Property( $device [, $options_href ] );
    
Returns a property value ($propertyValue) of a given device ($device) based on property_name specified in $options_href.  

B<Arguments:>

=over

=item $device
 
Name of device whose property value needs to be fetched.

=item $options_href (optional)
 
Defines which property to be fetched.

    $options_href = {
        property_name => <name>, # <name> can be: index, bitmask or bytecount
    }
    
If property_name is not given then B<index> is used by default.
    
=back

B<Return Values:>

=over

=item $propertyValue

Value of property_name for given device

=back

B<Examples:>

    $propertyValue = PRD_Get_Device_Property( 'PasMP', { 'property_name' => 'index' } );
    
    $propertyValue = PRD_Get_Device_Property( 'PasMP', { 'property_name' => 'bytecount' } );
    
    $propertyValue = PRD_Get_Device_Property( 'PasMP', { 'property_name' => 'bitmask' } );
    
    $propertyValue = PRD_Get_Device_Property( 'PasMP' );  # By default property_name is considered as 'index'

=cut

sub PRD_Get_Device_Property {
    my @args = @_;
    S_checkFunctionArguments( ' PRD_Get_Device_Property( $device [,$options_href] )', @args ) or return;
    my $device       = shift @args;
    my $options_href = shift @args;

    return CallDeviceFunction( $device, $options_href );
}

=head2 PRD_Get_Last_Response

    $response_href = PRD_Get_Last_Response();

Returns the response hash of the last service that was sent to the ECU.

B<Return Values:>

=over

=item $response_href

Response hashref. See L</"PRD_Send_Request_Wait_Response"> for details.

=back

=cut

sub PRD_Get_Last_Response {
    my $response_href = CallDeviceFunction();

    return $response_href;
}

=head2 PRD_Activate_AIO_Test_Pattern

    $success = PRD_Activate_AIO_Test_Pattern();

Send the service AIO test pattern.

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

=cut

sub PRD_Activate_AIO_Test_Pattern {
    my $success = CallDeviceFunction();

    return $success;
}

=head2 PRD_Set_Secure_PIN

    $success = PRD_Set_Secure_PIN();

Asks the user with a pop-up window for the security PIN and passes it in an encrypted way to the diagnosis dll.

This function is only needed if a test with a security locked ECU will be performed. 
It must be called before PRD_init (which is called in e.g. EQUIP_init_testbench).

B<CAUTION: This is a blocking function. Use only in the init campaign!>

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

=cut

sub PRD_Set_Secure_PIN {
    $setSecurePIN = 1;

    return 1;
}

=head2 PRD_Read_ECU_LifeCycle_Data

    $response_href = PRD_Read_ECU_LifeCycle_Data();

Reads ECU Life cycle data.

For List of different Ecu Lifecycle states Refer SRS:

https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-1965-0003ea7f

B<Return Values:>

=over

=item $response_href

Response hashref on positive response. See L</"PRD_Send_Request_Wait_Response"> for details.

undef on error

=back

=cut

sub PRD_Read_ECU_LifeCycle_Data {

    return CallDeviceFunction();
}

=head2 PRD_Switch_ECU_LifeCycle

    $response_href = PRD_Switch_ECU_LifeCycle($options_href);

This function is used to switch ECU life cycle.

If ECU life cycle is switched to any of the secure modes, Secure pin is required for the login.

B<Note: Call L</PRD_Set_Secure_PIN> function in init campaign before using this function.
        Requires user to input the secure pin once in init campaign>

Switching back to Production mode from secure mode is not possible except reflashing ECU software.

B<Arguments:>

=over

=item $options_href

    $options_href = {
      
      'delayInPOC' => 0, # Indicates delay in POC's for switch in state transition
                         # 0 means trigger the state transition in this POC
                         # 1 means in next POC and so on
    
      'ecuMainLifeCycle' => 'IN_FIELD_1' # IN_FIELD_1
                                         # IN_FIELD_2
                                         # TEMPORARY
                                         # PRIVELEDGED_MODE_SERIAL 
                                         # PRIVELEDGED_MODE_DEVELOPMENT
                                         # DEBUG
                                         # PRODUCTION
                                         # RETURN
    }
    
    By default 'delayInPOC' is considered to be 0 if not configured.

=back

B<Return Values:>

=over

=item $response_href

Response hashref in case of positive response. See L</"PRD_Send_Request_Wait_Response"> for details.

undef in case of error.

=back

=cut

sub PRD_Switch_ECU_LifeCycle {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Switch_ECU_LifeCycle( $options_href )', @args ) or return;
    my $options_href = shift @args;
    return CallDeviceFunction($options_href);
}

=head2 PRD_SHEKeyCalculatorProtocol

    $response_href = PRD_SHEKeyCalculatorProtocol($options_href);

Writes SHE keys ( M1, M2, M3, SheKeyExtensionId, BankIndex) to ECU, returns back the response $response_href containing
M4 and M5 keys data.

M1: Information of destination where key is programmed.

M2: Encrypted data of the key which will be distributed.

M3: CMAC which is generated from M1 and M2.

M4 and M5: Response from the ECU. M4 and M5 are the proof that the key is successfully written.

Evaluation of M4 and M5 keys are not done in this function.

Note: The data lengths of Keys M1, M2 and M3 are not checked in this function.

B<Arguments:>

=over

=item $options_href

    $options_href = {
                     'M1_Hex_str' => '16 byte hex key'; # Mandatory
                     'M2_Hex_str' => '32 byte hex key'; # Mandatory
                     'M3_Hex_str' => '16 byte hex key'; # Mandatory
                     'SheKeyExtensionId' => 'FF'; # one byte, default value 'FF'
                     'BankIndex_Hex_str' => '4 byte hex key';
                        # default value 'FF FF FF FF'
                    }
                    
    e.g $options_href =  
        {
           'M1_Hex_str' => '30 bc 9d ff 2a 13 d5 95 72 57 2b 68 e9 a1 ac 11',
           'M2_Hex_str' => 'ff 8b 75 f7 3e 6a d5 a1 72 94 23 c6 e9 31 1f 1a
              69 cc ff 39 3e 17 ba ed a2 95 24 54 af 1b 23 11',
           'M3_Hex_str' => 'b2 5d 97 f5 6b 39 7d 8c 50 82 0d 5f 10 b3 d3 fb',
           'SheKeyExtensionId' => 'FF',
           'BankIndex_Hex_str' => 'FF FF FF FF'
        }

=back

B<Return Values:>

=over

=item $response_href

Response hashref which contains M4 and M5 keys in case of positive response . See L</"PRD_Send_Request_Wait_Response"> for details.

Undef in case of error

=back

Examples:

   $response_href = PRD_SHEKeyCalculatorProtocol(
                    {
                      'M1_Hex_str' => '30 bc 9d ff 2a 13 d5 95 72 57 2b 68 e9 a1 ac 11',
                      'M2_Hex_str' => 'ff 8b 75 f7 3e 6a d5 a1 72 94 23 c6 e9 31 1f 1a 
                    69 cc ff 39 3e 17 ba ed a2 95 24 54 af 1b 23 11',
                      'M3_Hex_str' => 'b2 5d 97 f5 6b 39 7d 8c 50 82 0d 5f 10 b3 d3 fb',
                      'SheKeyExtensionId' => 'FF',
                      'BankIndex_Hex_str' => 'FF FF FF FF'
                    }
                  );
                    
   $response_href = {
                        'ErrorDescription' => 'OK',
                        'PdLength' => 50,
                        'Id' => 98,
                        'CompletePdMsg' => [ 50, 98, 48, 188, 157, 255, 42, 19,
                                             213, 149, 114, 87, 43, 104, 233, 
                                             161, 172, 17, 238, 82, 240, 105,
                                             73, 42, 157, 61, 18, 131, 85, 126,
                                             166, 69, 116, 108, 236, 97, 57, 143,
                                             91, 216, 33, 185, 37, 163, 152,
                                             105, 69, 38, 61, 160, 178
                                           ],
                        'Status' => 0,
                        'PdPayload' => [ 98, 48, 188, 157, 255, 42, 19, 213, 149,
                                         114, 87, 43, 104, 233, 161, 172, 17, 238,
                                         82, 240, 105, 73, 42, 157, 61, 18, 131,
                                         85, 126, 166, 69, 116, 108, 236, 97, 57,
                                         143, 91, 216, 33, 185, 37, 163, 152, 105,
                                         69, 38, 61, 160
                                       ],
                        'Checksum' => 178
                    }

=cut

sub PRD_SHEKeyCalculatorProtocol {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_SHEKeyCalculatorProtocol( $options_href )', @args ) or return;
    my $options_href = shift @args;
    return CallDeviceFunction($options_href);
}

=head2 PRD_Get_Signature_from_KMS

    $signature_KMS_aref = PRD_Get_Signature_from_KMS($challenge_aref);

This service sends challenge aref received from ECU to KMS server, and returns signature from KMS server.

Note: Function L</"PRD_Set_Secure_PIN"> and L</"PRD_Send_Request_Wait_Response"> shall be called before calling this function to get challenge from ECU. 

B<Arguments:>

=over

=item $challenge_aref

Challenge aref received from ECU which is obtained from function PRD_Send_Request_Wait_Response.

    $response_href = PRD_Send_Request_Wait_Response('00 A5', {add_length_checksum => 1}); # login request.

    # challenge has to be extracted from $response_href->{'CompletePdMsg'} as per the requirement:
      https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-2002-0003ea7f

=back

B<Return Values:>

=over

=item $signature_KMS_aref

    $signature_KMS_aref = [ 48, 
                            130,
                            3,  
                            184,
                            128,
                             :   
                             :   
                            225,
                            243  ];

    undef, on failure.

=back

B<Example:>

    $signature_KMS_aref = PRD_Get_Signature_from_KMS( [ 48,129,139,128,1,1,129,1,0,138,1,0,144,
                                                        8,32,70,149,218,189,76,142,130,145,32,
                                                        78,49,88,89,51,55,45,53,49,32,11,255,45,
                                                        0,66,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                                                        159,32,27,82,66,65,49,65,73,82,66,65,71,
                                                        49,47,67,79,77,77,79,78,49,58,67,78,48,
                                                        48,48,48,49,159,33,15,43,6,1,4,1,169,70,
                                                        147,72,21,2,1,9,0,1,159,34,16,48,0,0,0,0,
                                                        0,0,127,0,0,0,0,0,167,255,255,159,35,16,
                                                        48,0,0,0,0,0,0,127,0,0,0,0,0,167,255,255
                                                      ] );


    $signature_KMS_aref = [ 48,130,3,184,128,1,1,129,1,1,159,41,130,1,0,13,52,83,137,253,185,89,
                            252,120,134,21,131,164,237,241,160,58,62,0,191,48,16,166,93,230,234,4,
                            3,138,25,85,218,241,200,73,239,80,46,6,1,177,33,25,234,14,172,179,66,
                            66,139,211,133,31,189,77,93,197,68,254,234,92,138,184,133,243,186,205,
                            230,169,202,104,65,190,67,141,158,255,164,72,36,192,134,170,96,121,33,
                            149,229,69,222,118,67,137,225,200,212,23,154,133,0,91,214,231,247,31,
                            252,82,251,88,138,136,110,74,6,36,178,150,107,132,118,44,13,89,240,253,
                            101,93,250,205,190,149,186,75,36,152,2,95,216,105,210,207,160,140,88,
                            154,180,249,241,222,108,32,84,55,39,67,63,246,135,136,77,133,167,155,
                            168,229,107,148,234,133,11,111,108,224,73,186,54,92,222,238,241,68,97,
                            3,181,88,46,128,208,153,145,139,36,212,170,208,218,59,65,226,149,221,
                            194,169,229,132,127,52,194,229,131,141,116,54,189,211,20,26,61,20,251,
                            11,109,208,98,144,78,36,250,79,104,150,243,43,186,20,14,171,165,158,70,
                            95,235,49,127,138,187,205,165,107,86,176,138,53,9,186,138,61,191,42,
                            130,2,168,4,130,2,164,127,33,130,2,159,127,78,130,1,149,95,41,1,0,66,
                            27,82,66,65,49,65,73,82,66,65,71,49,47,67,79,77,77,79,78,49,58,67,78,
                            48,48,48,48,49,127,73,130,1,24,6,13,43,6,1,4,1,169,70,147,72,21,1,8,
                            1,129,130,1,0,180,81,4,11,12,141,31,18,58,36,23,156,21,101,105,55,217,
                            233,133,159,56,200,49,207,156,225,225,176,107,22,117,252,183,223,191,
                            51,134,161,37,121,201,90,132,49,103,194,35,185,123,183,35,118,43,218,
                            241,206,202,137,146,179,116,149,207,74,180,248,122,79,163,249,150,213,
                            255,254,122,246,74,177,134,232,23,104,129,206,68,28,118,91,124,179,162,
                            89,230,33,118,26,254,164,212,132,161,75,98,150,127,87,95,229,249,150,
                            54,109,191,52,28,77,245,145,227,182,59,61,127,201,141,220,130,33,140,
                            65,130,107,113,141,59,180,116,198,186,99,119,120,10,159,206,138,16,152,
                            124,39,76,49,175,110,18,61,188,72,39,177,140,170,43,35,109,15,19,151,
                            114,242,107,138,229,102,182,117,88,127,157,90,66,90,97,79,180,7,180,
                            54,121,94,53,168,80,180,42,44,102,86,231,55,90,166,240,45,206,162,56,
                            185,217,231,227,254,81,243,4,252,73,208,60,161,97,189,157,111,63,232,
                            222,192,172,101,206,104,202,56,4,152,33,82,111,241,66,185,142,39,82,
                            127,196,99,130,40,78,43,215,3,73,151,130,3,1,0,1,95,32,28,82,66,65,52,
                            67,51,57,67,54,54,50,51,52,56,70,57,49,49,56,55,58,80,78,48,48,48,48,
                            49,127,76,35,6,15,43,6,1,4,1,169,70,147,72,21,2,1,9,0,1,83,16,48,0,0,
                            0,0,0,0,127,0,0,0,0,0,167,255,255,95,37,6,1,8,0,7,3,1,95,36,6,2,0,0,
                            7,3,0,95,55,130,1,0,176,75,16,98,247,193,137,195,254,232,118,87,153,
                            168,27,96,97,235,52,64,161,43,147,177,104,46,67,86,99,216,60,117,162,
                            137,253,43,51,134,39,125,246,247,7,253,223,30,115,174,197,62,218,239,
                            125,100,38,115,28,187,36,254,251,136,16,243,39,231,175,149,142,190,
                            243,98,190,59,55,150,148,194,186,49,160,94,115,84,35,190,53,242,29,
                            228,223,48,191,99,151,1,67,38,86,71,172,74,17,74,162,86,29,25,120,27,
                            20,31,182,222,44,172,2,156,99,227,86,192,63,64,204,251,120,6,10,36,22,
                            126,242,178,117,130,191,167,55,139,72,212,1,127,196,6,137,23,235,230,
                            82,14,226,92,101,89,159,186,199,212,208,36,109,94,76,178,189,238,186,
                            141,116,212,195,221,40,236,146,135,110,233,115,10,43,208,247,77,198,
                            9,176,161,139,219,208,220,15,223,221,13,6,38,161,159,74,51,214,18,89,
                            189,249,63,74,211,81,98,3,44,182,208,31,24,197,4,198,120,250,32,220,
                            245,235,233,239,89,216,152,96,158,241,94,158,103,78,103,160,97,60,24,
                            212,86,242,16,29,65,163,182,225,243,                                                 
                         ];                                              

=cut

sub PRD_Get_Signature_from_KMS {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Get_Signature_from_KMS( $challenge_aref )', @args ) or return;
    my $challenge_aref = shift @args;
    return CallDeviceFunction($challenge_aref);
}

=head2 PRD_Read_Serial_Numbers

    $serialNumbers_href = PRD_Read_Serial_Numbers( [$options_href] );

Send the service Read System ASIC Serial Number $17H and return the serial numbers in $serialNumbers_href.
Plant mode is set by default to facilitate this service.

B<Arguments:>

=over

=item $options_href (optional)

    $options_href = {
         set_plant_mode => 0|1, # default is 1
    }
    
If set_plant_mode = 1 then plant mode is set before sending the service. Otherwise plant mode is not set.
   
=back    

B<Return Values:>

=over

=item $serialNumbers_href

System ASIC serial numbers.

    $serialNumbers_href = {
        ASIC1 => <6 bytes hex string 1>,
        ASIC2 => <6 bytes hex string 2>,
        ASIC3 => <6 bytes hex string 3>,        
    }

=back

=cut

sub PRD_Read_Serial_Numbers {

    my @args = @_;
    S_checkFunctionArguments( 'PRD_Read_Serial_Numbers( [$options_href] )', @args ) or return;

    my $options_href = shift @args;

    return CallDeviceFunction($options_href);
}

=head2 PRD_Disable_Initial_Login

    $success = PRD_Disable_Initial_Login();

This function disables the ECU login, called by L</"PRD_init"> internally.
This function is only needed for security test where it is require to modify challenge of ECU. 

For this pre-requiste is - 'there should be no ECU login done before'. 

It must be called before L</"PRD_init"> and also PRD_init should be called explicitly not by EQUIP_init_testbench.

B<Note> : Because of this PRD_init cannot fetch ECU properties, so make a call of function L</"PRD_Do_Initial_Login"> after this.
See example of L</"PRD_Do_Initial_Login"> for use case.

B<Return Values:>

=over

=item $success

1 on success or in offline mode, undef otherwise

=back

=cut

sub PRD_Disable_Initial_Login {
    S_w2log( 3, "PRD_Disable_Initial_Login was called ...\n", 'purple' );
    $setInitialLogin = 0;    # by default Initial login is enabled.
                             # It can be disabled if reqiured.
    return 1;
}

=head2 PRD_Do_Initial_Login

    $ecuDetails_href = PRD_Do_Initial_Login();

This function call is require to do first ECU login and in case it is disabled by function  L</"PRD_Disable_Initial_Login">  

Note: call this function after L</"PRD_init"> (which is called in e.g. EQUIP_init_testbench) so that ecu details can be fetched.

B<Arguments:>

=over

=item none

=back

B<Return Values:>

=over

=item $ecuDetails_href

see return value of L</"PRD_Get_ECU_Properties"> 
    
=back

B<Example:>

    # Below is one of the use case for security test where ECU login should not be done if 
    # challange has to be modified.

    PRD_Disable_Initial_Login();
    PRD_init(); or EQUIP_init_testbench();
    < modify challenge from ECU or response from KMS >.
    PRD_Do_Initial_Login();
    
=cut

sub PRD_Do_Initial_Login {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_Do_Initial_Login( )', @args ) or return;
    return CallDeviceFunction();
}

=head2 PRD_Enable_KMS_Simulator

    $success = PRD_Enable_KMS_Simulator();

This function will enable KMS simlutor in PDLayer. This function is only needed for a test where
KMS simulator is required. 

It must be called before PRD_init (which is called in e.g. EQUIP_init_testbench).

B<Arguments:>

=over

=item none

=back

B<Return Values:>

=over

=item $success

1 on success and offline, otherwise undef.

=back

B<Examples:>
    
    PRD_Enable_KMS_Simulator();  # Enable KMS simulator
    PRD_init(); or EQUIP_init_testbench();  # Initialize login with simulator KMS

B<Notes:> 

    This function can work only with a ECU_SW_variant which supports KMS simulation.
    Same ECU software with real KMS cannot be used or vice versa.

=cut

sub PRD_Enable_KMS_Simulator {
    S_w2log( 3, "PRD_Enable_KMS_Simulator was called ...\n", 'purple' );
    $enable_KMSsimulator = 1;
    return 1;
}

=head2 PRD_SetAutoLogin

    $success = PRD_SetAutoLogin($enable_or_disable_bool);

This function will disable or enable autologin when PRD services are called.

Case 1: If PRD_SetAutoLogin is called before PRD_init(), then autologin will be disbaled or enabled after PRD communication is initialised.

Case 2: If PRD_SetAutoLogin is called after PRD_init(), then autologin will be disabled or enabled with immediate effect.

B<Arguments:>

=over

=item $enable_or_disable_bool : 1|0

1: Enable Autologin.
0: Disable Autologin.

=back

B<Return Values:>

=over

=item $success

1 on success and offline, otherwise undef.

=back

B<Examples:>

Different use cases for PRD_SetAutoLogin:

Case 1: If called before PRD_init() Autologin will be disabled/enabled after the PRD communication is initialised by PRD_init()
    
        PRD_SetAutoLogin(0);  # Disable autologin called
        PRD_init();           # Autologin is disabled after initialising communication 
        
        # Call other PRD services

Case 2: If called after PRD_init(), Autologin will be disabled/enabled with immediate effect when the function call is made.
    
        PRD_init();
        PRD_SetAutoLogin(0);  # Autologin disabled with immediate effect
    
        # Call other PRD services
    
        PRD_SetAutoLogin(1);  # Autologin enabled with immediate effect

        # Call other PRD services

=cut

sub PRD_SetAutoLogin {
    my @args = @_;
    S_checkFunctionArguments( 'PRD_SetAutoLogin( $enable_or_disable_bool )', @args ) or return;
    my $enable_or_disable_bool = shift @args;
    S_w2log( 3, "PRD_SetAutoLogin called with option $enable_or_disable_bool...\n" );

    #IF is Prodiag not initialised?
    #IF-YES-START
    #STEP set flag $setAutoLogin to configured $enable_or_disable_bool
    if ( not $prodDiag_Initialized ) {
        $setAutoLogin = $enable_or_disable_bool;
        return 1;
    }

    #IF-YES-END

    #IF-NO-START
    #CALL PRD12_SetAutoLogin with argument $enable_or_disable_bool
    elsif ($prodDiag_Initialized) {
        return CallDeviceFunction($enable_or_disable_bool);
    }

    #IF-NO-END
    #STEP-END
}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=head2 CallDeviceFunction

    CallDeviceFunction( @args );
    
Calls a function that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.
Values of $functionMapping_href are either directly functions of the device layer if a 1:1 mapping is possible.
Otherwise a function of the package LIFT_ProdDiag_AB12_xyz is called.

Returns the return values of the called functions. On error returns 0.

=cut

sub CallDeviceFunction {
    my @args            = @_;
    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        S_w2log( 3, "$2...\n" );    # print the name or the PRD_ function
    }
    return FL_CallDeviceFunction( 'ProdDiag', $functionMapping_href, @args );
}

sub Init_AB12 {
    eval "use LIFT_ProdDiag_AB12";
    return 1;
}

sub NotImplementedYetWarning {

    # get name of the calling function from calling stack
    my $callingFunction = ( caller(3) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    S_set_warning("Sorry, the function '$callingFunction' is not implemented yet.");
    return 0;
}

1;

