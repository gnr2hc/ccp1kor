# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_crash_simulation;

use strict;
use warnings;
use Readonly;
use LIFT_general;
use LIFT_functional_layer;
use FuncLib_TNT_crash_simulation;
use FuncLib_SYC_INTERFACE;
use FuncLib_SPI_SensorSimulation;
use LIFT_labcar;
use LIFT_QuaTe;
use LIFT_evaluation;
use JSON::PP;
use File::Slurp;
use File::Path 'make_path';

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  CSI_Init
  CSI_Exit
  CSI_GetCrashDataFromMDS
  CSI_LoadCrashSensorData2Simulator
  CSI_LoadNetworkDynamicData2Simulator
  CSI_TriggerCrash
  CSI_ExportCrashData
  CSI_VerifyEnvironment
  CSI_PrepareEnvironment
  CSI_LoadAllData2Simulator
  CSI_PostCrashActions
  CSI_GetChannelAssignmentOverview
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_crash_simulation 

=head1 SYNOPSIS

    use LIFT_crash_simulation;

    CSI_Init();
    
    $crashData_href = CSI_GetCrashDataFromMDS( $crashIdentifyParams_href );
    CSI_PrepareEnvironment( $crashData_href, 'init_complete' );
    CSI_LoadAllData2Simulator( $crashData_href );
    CSI_TriggerCrash();
    CSI_PostCrashActions( $crashData_href );
    
    CSI_Exit();

=head1 DESCRIPTION

This is a wrapper library for all devices which are involved in airbag ECU crash injection.
The following function groups are defined:

    Function Group 'crash_database':      Access to the crash database
    Function Group 'crash_sensors':       Injection of crash sensor signals
    Function Group 'network_dynamic':     Injection of dynamic network signals
    Function Group 'trigger':             Triggering of the injected crash
    Functions outside of Function Groups: Functions that are either independent of function groups 
                                          or combine functionality of several functon groups

See the API documentation of the individual functions for more detail about the functionality of each function group.

=head2 Testbench configuration

=head3 Functions section:

The devices that are used for the different function groups are defined in testbench config (LIFT_Testbenches.pm) under 'Functions'->'Crash_simulation':

    'Functions' => {
        ...
        ### --- Function Area : Crash_simulation, function groups for crash database access, download to simulators and triggering the simulated crash
        'Crash_simulation' => {
          'crash_database'  =>   '<device>', # possible devices: MDSRESULT, SPI_SensorSimulation
          'crash_sensors'   =>   '<device>', # possible devices: QuaTe, IDEFIX, SPI_SensorSimulation (e.g. by Manitoo)
          'network_dynamic' =>   '<device>', # possible devices: can_access
          'trigger'         =>   '<device>', # possible devices: QuaTe, IDEFIX, can_access, SPI_SensorSimulation (e.g. by Manitoo)
        },
        ...  
    },

=head2 Crash simulation mapping

A crash simulation mapping is required to translate from signal names in the crash database to independent names.
Those independent names will be further translated to simulator channels (e.g. using the QuaTe mapping) 
and to system variable indices (e.g. using the CANoeCtrl mapping).

    $Defaults->{'CRASH_SIMULATION'} = {
        'STIMULATION' => {
            'CRASH_SENSORS' => {
                # crash database SENSORS name => sensor simulator name ("sensorName" or "sensorName::channelName")
                "ECU: Acc_HG: -Y: SMA660_sync_axay_96g_426Hz" => "SMA660::-Y",
                 ...
            },
            'NETWORK_DYNAMIC' => {
                # crash database name => CAN or flexray signal name
                "ECU: CAN_ESP02_AccelLong: Bus: NoFilter_For_Bus_Signals" => "ESP_Laengsbeschl",
                ...
            },
        },
        'ENVIRONMENT' => {
            'SENSORS' =>{
                # crash database ENVIRONMENT name (only sensor name) => labcar name
                "UfsDr" => "UFSD",
            },
            'OVERLOAD' =>{
                # define for each overload environment the corresponding crash sensor and overload channel
                "LowGY" => {
                    "CRASH_SENSOR" => "ECU: Acc_LG: -Y: SMI7x0_sync_axay_6_5g_73Hz",
                    "OVERLOAD_CHANNEL" => "ECU: Valid: 0: NoFilter (1g=1LSB)",
                },
            },
            'RESET' =>{
                # crash database ENVIRONMENT name => value for reset (any MDS value or "reset"). 
                # The value "reset" must be handled in the corresponding functions in FuncLib_..._crash_simulation.
                "EnvVelocity_Source" => "reset",
                "Switch_SPSFD_State" => 0,
            },
        },
    };

=head2 Environment handling

All environments that are defined in the crash database are handled in a defined procedure, see L</"CSI_PrepareEnvironment">.
Environments that are not handled elsewhere must be handled as functions with the name of the environment in FuncLib_..._crash_simulation (TNT, Custlib or Project).

=head2 CANoeCtrl mapping

For stimulation of dynamic network signals simulateously with the sensor crash injection a CANoeCtrl mapping is required 
that defines signal indices, cycle times and default values of the signals to be stimulated as well as the CAPL functions to be called for stimulation.

=for html
<a href='LIFT_CANoeCtrl.html#SYNOPSIS'>See LIFT_CANoeCtrl documentation</a>

=head2 SPI_SensorSimulation

Manitoo modified ECU should be used when SPI_SensorSimulation is configured for 'crash_sensors'.

Mapping_SPI_Network.pm should be used for details refer:

=for html
<a href='../Convenience_layer/FuncLib_SPI_SensorSimulation.html#SYNOPSIS'>See FuncLib_SPI_SensorSimulation documentation</a> 

=head2 Note

The functions that are called internally in this module are defined in $functionMapping_href.

=cut

# In this data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.
my $functionMapping_href = {

    'base' => {
        'QuaTe' => {
            'CSI_Init' => 'QuaTe_Init',    # for documentation purposes only
            'CSI_Exit' => 'QuaTe_Exit',
        },
        'SPI_SensorSimulation' => {
            'CSI_Init' => 'SPISIM_Init',
            'CSI_Exit' => 'SPISIM_Exit',
        },
        'IDEFIX' => {
            'CSI_Init' => 'IDX_InitHW',    # for documentation purposes only
            'CSI_Exit' => 'IDX_CloseHW',
        },
        'MDSRESULT' => {
            'CSI_Init' => 'MDSRESULT_Init',    # for documentation purposes only
            'CSI_Exit' => 'MDSRESULT_Exit',
        },
        'can_access' => {
            'CSI_Init' => 'CA_init',           # for documentation purposes only
            'CSI_Exit' => 'None',
        },
    },
    'crash_database' => {
        'MDSRESULT' => {
            'CSI_GetCrashDataFromMDS' => 'LIFT_crash_simulation_MDSRESULT::CSI_GetCrashDataFromMDS',
        },
        'SPI_SensorSimulation' => {
            'CSI_GetCrashDataFromMDS' => 'LIFT_crash_simulation_SPI_SensorSimulation::CSI_GetCrashDataFromMDS',
        },
    },
    'crash_sensors' => {
        'QuaTe' => {
            'CSI_LoadCrashSensorData2Simulator' => 'LIFT_crash_simulation_QuaTe::CSI_LoadCrashSensorData2Simulator',
            'CSI_GetSensorProperties'           => 'LIFT_crash_simulation_QuaTe::CSI_GetSensorProperties',
        },
        'SPI_SensorSimulation' => {
            'CSI_LoadCrashSensorData2Simulator' => 'LIFT_crash_simulation_SPI_SensorSimulation::CSI_LoadCrashSensorData2Simulator',
            'CSI_GetSensorProperties'           => 'LIFT_crash_simulation_SPI_SensorSimulation::CSI_GetSensorProperties',
        },
        'IDEFIX' => {
            'CSI_LoadCrashSensorData2Simulator' => 'NotSupportedYet',
            'CSI_GetSensorProperties'           => 'NotSupportedYet',
        },
    },
    'network_dynamic' => {
        'can_access' => {
            'CSI_LoadNetworkDynamicData2Simulator' => 'LIFT_crash_simulation_can_access::CSI_LoadNetworkDynamicData2Simulator',
        },
    },
    'trigger' => {
        'QuaTe' => {
            'CSI_TriggerCrash' => 'LIFT_crash_simulation_QuaTe::CSI_TriggerCrash',
        },
        'SPI_SensorSimulation' => {
            'CSI_TriggerCrash' => 'LIFT_crash_simulation_SPI_SensorSimulation::CSI_TriggerCrash',
        },
        'IDEFIX' => {
            'CSI_TriggerCrash' => 'NotSupportedYet',
        },
        'can_access' => {
            'CSI_TriggerCrash' => 'LIFT_crash_simulation_can_access::CSI_TriggerCrash',
        },
    },
};

my @availableTestbenchFunctionGroups = qw{ crash_database crash_sensors network_dynamic peripheral_dynamic trigger};
my @channelAssignmentDataCrashSensors = ( 'MDS channel', 'Device name', 'Quate index', 'Device index', 'Channel index', 'Channel name', 'ROM file', 'Quate device description', 'Firmware', 'Quate chip select', 'Quate port' );

my $lastRESULTDB = 'not used';
our ( $channelAssignmentOverall_href, $channelAssignmentPerCrash_href );
my $environment_href;
Readonly our $SENSOR_PROPERTY_CRASH_DEVICE => "CRASH_DEVICE";

#
#
# Definition of all functions in LIFT_crash_simulation
#
#

=head1 Function Group 'base'

=head2 CSI_Init

    CSI_Init();
    
Initialize the devices for all crash simulation function groups.
This function has to be called before calling any other function in this library.
Calls internally the init functions of all devices that are configured in LIFT_Testbenches.pm for this functional module.
By convention the init functions must have the name "Init_<device>", e.g. Init_QuaTe, Init_IDEFIX, ...

=cut

sub CSI_Init {
    return FL_Init( 'Crash_simulation', $functionMapping_href, \@availableTestbenchFunctionGroups );
}

=head2 CSI_Exit

    CSI_Exit();
    
Disconnect from the devices for all crash simulation functions.

=cut

sub CSI_Exit {
    return FL_Exit( 'Crash_simulation', $functionMapping_href );
}

=head1 Function Group 'crash_database'

=head2 CSI_GetCrashDataFromMDS

    $crashData_href = CSI_GetCrashDataFromMDS( $crashIdentifyParams_href );

Loads crash data from database for one crash. Crash database and crash are identified by $CrashIdentifyParams_href. 
This is Hash reference containing specific Keys, see the example below.

This function calls internally CSI_GetSensorProperties to get sensor properties for all acceleration sensors from sensor simulation device.

B<For crash_database 'MDSRESULT' and MDSTYPE 'MDSNG' or 'MDSNG64':>

MDSNG or MDSNG64 has to be present in the Test PC.

For details about the possibilities for $CrashIdentifyParams_href see the documentation in LIFT_MDSRESULT:

=for html
<a href='LIFT_MDSRESULT.html#MDSRESULT_GetCrashDetails'>LIFT_MDSRESULT documentation</a>

    $crashIdentifyParams_href = { 
        'RESULTDB' => 'D:\Projects\MDSResult\Y352-default.mdb',
        'MDSTYPE'    => "MDSNG",    # or "MDSNG64"
        'CRASHNAME' => 'FrontCrash',
        'STATEVARIATION' => 1,
    };

Maps the signal names of the crash database to independent names using the crash simulation mapping (see L</"DESCRIPTION">).

Output is $crashData_href with the following contents:

    $crashData_href	= {	
    	'METADATA' => {	
    		'CRASHINDEX' => ...,
    		'CRASHNAME' => ...,
    		'CRASHDURATION_MS' => ...,
    		'ISMERGECRASH' => ...,
    		'STATEVARIATION' => ...,
    		'TIMESHIFT_ms' => ...,
    		'VELOCITY_kmh' => [...],
    		'VELOCITY_X_kmh' => [...],
    		'VELOCITY_CLOSING_kmh' => [...],
    		'TEMPERATURE_degCelsius' => [...],
    		'CRASH_ASSIGNMENT_COMMENT' => [...],
    		'ALGOIDS' => {...},
    	}
    	'ENVIRONMENT' => {
    	   'STATIC' => {
    	       'EnvStaticXYZ' => {
    	           'Value'     => ...,
    	           'SetText'   => [...],
    	           'CheckText' => [...],
    	           'Verdict'   => "VERDICT_NONE",  
    	       },
    	   },
    	   'DYNAMIC' => {
               'EnvStaticXYZ' => {
                   'Value'     => ...,
                   'SetText'   => [...],
                   'CheckText' => [...],
                   'Verdict'   => "VERDICT_NONE",  
               },
    	   },
    	},
    	'EXPECTEDRESULT' => {
    	   ...   
    	}	
    	'STIMULATION' => {
    		'CRASH_SENSORS' => {
    		    ...
    		}
    		'NETWORK_DYNAMIC' => {
    		    ...
    		}
    		'UNMAPPED' => {
    		    ...
    		}
    	}	

B<For crash_database 'SPI_SensorSimulation' and MDSTYPE 'SPISIM':>

MDSNG is not required to be present in the Test PC.

Input data base file is *.json file format stored in zip format.

    json file contains Crash data from MDS resampled to 500us.

For generating the data base file (.zip) format, Initialiially the data from MDS has to be exported using L</"CSI_ExportCrashData"> function.

    $crashIdentifyParams_href = { 
        'RESULTDB'  => 'D:\TurboLIFT\AB12\config\Single_EDR_Front_Inflatable;5.zip',
        'MDSTYPE'   => "SPISIM",
        'CRASHNAME' => 'Single_EDR_Front_Inflatable;5',
    };

Output is $crashData_href with the following contents:

    $crashData_href	= {	
    	'METADATA' => {	
    		'CRASHINDEX' => ...,
    		'CRASHNAME' => ...,
    		'CRASHDURATION_MS' => ...,
    		'ISMERGECRASH' => ...,
    		'STATEVARIATION' => ...,
    		'TIMESHIFT_ms' => ...,
    		'VELOCITY_kmh' => [...],
    		'VELOCITY_X_kmh' => [...],
    		'VELOCITY_CLOSING_kmh' => [...],
    		'TEMPERATURE_degCelsius' => [...],
    		'CRASH_ASSIGNMENT_COMMENT' => [...],
    		'ALGOIDS' => {...},
    	}
    	'ENVIRONMENT' => {
    	   'STATIC' => {
    	       'EnvStaticXYZ' => {
    	           'Value'     => ...,
    	           'SetText'   => [...],
    	           'CheckText' => [...],
    	           'Verdict'   => "VERDICT_NONE",  
    	       },
    	   },
    	   'DYNAMIC' => {
               'EnvStaticXYZ' => {
                   'Value'     => ...,
                   'SetText'   => [...],
                   'CheckText' => [...],
                   'Verdict'   => "VERDICT_NONE",  
               },
    	   },
    	},
    	'EXPECTEDRESULT' => {
    	   ...   
    	}	
    	'STIMULATION' => {
    		'CRASH_SENSORS' => {
    		    ...
    		}
    		'CRASH_SENSORS_SPI_SensorSimulation' => {
    		    ...
    		}
    		'NETWORK_DYNAMIC' => {
    		    ...
    		}
    		'UNMAPPED' => {
    		    ...
    		}
    	}	

=cut

sub CSI_GetCrashDataFromMDS {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CSI_GetCrashDataFromMDS( $crashIdentifyParams_href )', @args );
    my $crashIdentifyParams_href = shift @args;
    $environment_href = undef;    # clear environment href if new crash is loaded...

    # call CSI_GetSensorProperties if a device is configured for crash_sensors
    my ( $sensorProperties_href, $sensorPropertyKeys_aref );
    my $sensorDevice = FL_GetConfiguredDevice( 'Crash_simulation', 'crash_sensors' );
    if ( defined $sensorDevice ) {
        ( $sensorProperties_href, $sensorPropertyKeys_aref ) = CSI_GetSensorProperties();
    }

    return CallDeviceFunction( $crashIdentifyParams_href, $sensorProperties_href, $sensorPropertyKeys_aref );
}

=head1 Function Group 'crash_sensors'

=head2 CSI_LoadCrashSensorData2Simulator

    CSI_LoadCrashSensorData2Simulator( $crashData_href [, $modifySignals_href ] );
    
Loads all crash sensor stimulation data of $crashData_href to the sensor simulator.
$crashData_href is the output of CSI_GetCrashDataFromMDS.
Optionally the crash sensor stimulation data can be modified before sending to the simulator (factor, offset, exclude),
see the definition of $modifySignals_href below.

    $modifySignals_href = {
        <signal1> => {        # the signal name to use here is the name on the right side of the crash simulation mapping
            'factor'  => ..., # if set then a constant factor is multiplied to the signal value
            'offset'  => ..., # if set then a constant offset is added to the signal value
                              # if both factor and offset are given then first factor is applied and then offset
            'exclude' => ..., # if set (to any value other than 0) then the signal is excluded from crash simulation
        },
        <signal2> => {
            ...
        },
    };

Returns 1 on success, 0 otherwise.

=cut

sub CSI_LoadCrashSensorData2Simulator {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_LoadCrashSensorData2Simulator( $crashData_href [, $modifySignals_href ] )', @args );
    return CallDeviceFunction(@args);
}

=head2 CSI_GetSensorProperties

    ($sensorProperties_href, $sensorPropertyKeys_aref) = CSI_GetSensorProperties(); (not exported)

Gets sensor properties for all acceleration sensors from sensor simulation device.

This function is called by CSI_GetCrashDataFromMDS.

Returns ($sensorProperties_href, $sensorPropertyKeys_aref).

=cut

sub CSI_GetSensorProperties {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_GetSensorProperties()', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'trigger'

=head2 CSI_TriggerCrash

    CSI_TriggerCrash();
    
Starts the crash simulation on the configured device. This is usually the device for crash_sensors (QuaTe or Idefix or SPI_SensorSimulation). 
On a QuaTe the master QuaTe is triggered on both trigger lines. 
On SPI_SensorSimulation starting SPI manipulation is trigger.

If several simulators are used in parallel (e.g. crash_sensors and network_dynamic)
then the associated devices have to be connected via trigger cable, so that the trigger is available on each device.

It is also possible that a network_dynamic device (can_access) is configured for this function group. 
This is for cases in which no crash_sensors device is present and the crash data consist only of network_dynamic data.

A timer with name 'CSI_TriggerCrash' is set to zero in this function, so that following functionalities can sync with crash triggering. 

=cut

sub CSI_TriggerCrash {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_TriggerCrash()', @args );
    S_set_timer_zero('CSI_TriggerCrash');
    my $success = CallDeviceFunction(@args);

    my $device = FL_GetConfiguredDevice( 'Crash_simulation', 'trigger' );

    return $success if ( $device eq 'SPI_SensorSimulation' );    # no environment setting check

    #check that environments have been handled correctly
    unless ( defined $environment_href ) {

        S_set_error( "Incorrect status of crash environments detected. You have to call 'CSI_PrepareEnvironment' before 'CSI_TriggerCrash'", 109 );
        return 0;
    }

    my @unhandledEnvironments;
    my $errorCode = 0;

    foreach my $environment ( sort keys %{$environment_href} ) {
        if ( $environment_href->{$environment}{handled} == -1 ) {
            $errorCode = 109;
            push( @unhandledEnvironments, $environment );
        }
        if ( $environment_href->{$environment}{handled} == 0 ) {
            $errorCode = 0;
            push( @unhandledEnvironments, $environment );
        }
    }

    my $unsuccessfulString;
    foreach my $element (@unhandledEnvironments) {
        $unsuccessfulString .= $element . "\n";
    }

    if ($unsuccessfulString) {
        my $errorText = "Following environments have not been handled:\n$unsuccessfulString";
        $errorText .= "You have to call 'CSI_PrepareEnvironment' for scenario 'init_complete' or 'before_crash' \n";
        $errorText .= "and in case there are environments which require crash cycle manipulation,\n";
        $errorText .= " also for scenario 'before_crash_same_cycle'.\n";
        $errorText .= "Please check your test case and enviroment section of creis mapping file.\n";
        S_set_error( $errorText, $errorCode );
        return 0;

    }

    return $success;
}

=head1 Function Group 'network_dynamic'

=head2 CSI_LoadNetworkDynamicData2Simulator

    CSI_LoadNetworkDynamicData2Simulator( $crashData_href [, $modifySignals_href ] );
    
Loads all crash network dynamic data of $crashData_href to the network device.
$crashData_href is the output of CSI_GetCrashDataFromMDS.
Optionally the crash sensor stimulation data can be modified before sending to the simulator (factor, offset, exclude),
see the definition of $modifySignals_href in L<CSI_LoadCrashSensorData2Simulator>.

=cut

sub CSI_LoadNetworkDynamicData2Simulator {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_LoadNetworkDynamicData2Simulator( $crashData_href [, $modifySignals_href ] )', @args );
    return CallDeviceFunction(@args);
}

=head1 Functions outside of any Function Group

=head2 CSI_VerifyEnvironment

    $status = CSI_VerifyEnvironment( $crashData_href [, $errorHandling ] );

Loops over all environments that have been handled by CSI_PrepareEnvironment before and applies the following
procedure to each element:

B<1:> Try to find a function with the name of the element and prefix "Check" in FuncLib_..._crash_simulation (TNT, Custlib or Project)

B<2:> Try to find a generic solution for the element (e.g. for switches or sensors)

B<3:> Check if the element with the corresponding value can be ignored. This can be because of generic ignore rules or because the element and corresponding value is found in $standardExcludeList_href in FuncLib_TNT_crash_simulation

B<4:> Throw an error or warning if none of the above methods were successful (see $errorHandling below).

$crashData_href is the output of L</"CSI_GetCrashDataFromMDS">.

$errorHandling determines how the error handling is done if an environment could not be handled:

=over

=item *

If $errorHandling is "strict" then a system error is thrown if a static environment could not be handled. 
The verdict of the current test case will be set to "INCONC" and test execution will be stopped after the current test case.
A regular error is thrown if a dynamic environment could not be handled.

=item *

If $errorHandling is not defined or "normal" then a regular error is thrown if any environment could not be handled.
The verdict of the current test case will be set to "INCONC" but test execution will continue normally after the current test case.

=item *

If $errorHandling is "relaxed" then only a warning is thrown if any environment could not be handled or.
The verdict of the current test case will not be changed and test execution will continue normally after the current test case.

=back

Returns 1 on success, 0 otherwise.

=cut

sub CSI_VerifyEnvironment {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_VerifyEnvironment( $crashData_href, $scenario [, $failedHandling, $errorHandling ] )', @args );

    my $crashData_href = shift @args;
    my $scenario       = shift @args;
    my $failedHandling = shift @args;
    my $errorHandling  = shift @args;

    if ( $scenario !~ /^init_complete|before_crash|before_crash_same_cycle$/i ) {
        S_set_error( "Given argument \$scenario is '$scenario', but it must be one of: 'init_complete', 'before_crash', 'before_crash_same_cycle'", 109 );
        return 0;
    }

    $failedHandling = 'normal' if not defined $failedHandling;
    if ( $failedHandling !~ /^strict|normal|relaxed$/i ) {
        S_set_error( "Argument \$failedHandling is '$failedHandling', but it must be one of: 'strict', 'normal', 'relaxed'", 109 );
        return 0;
    }

    $errorHandling = 'normal' if not defined $errorHandling;
    if ( $errorHandling !~ /^strict|normal|relaxed$/i ) {
        S_set_error( "Argument \$errorHandling is '$errorHandling', but it must be one of: 'strict', 'normal', 'relaxed'", 109 );
        return 0;
    }

    my @filteredEnv = FilterEnvironments($scenario);

    # check if there are any environment data
    if ( @filteredEnv == 0 ) {
        S_w2log( 1, "CSI_CheckEnvironment: No environment data found in given crash data. Did you call 'CSI_PrepareEnvironment' before? Nothing will be done." );
        return 1;
    }

    my $unsuccessful_href = {};
    my $failed_href       = {};
    my $tableObject       = S_TableCreate( [ 'EnvironmentParameter', 'Value', 'Description', 'Verification' ] );

    foreach my $environment ( sort @filteredEnv ) {
        my $result = 0;
        my $checkTexts_aref;
        my $verdicts_aref;
        my $envType          = GetEnvironmentType( $crashData_href, $environment );
        my $setTexts_aref    = $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{SetText};
        my $value            = $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{Value};
        my $mappingData_href = $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$environment};

        S_w2log( 1, "CSI_VerifyEnvironment: Verify environment '$environment' with '$value'..." );

        # Try to find a function with the name of the environment in FuncLib_crash_simulation (TNT or Custlib or Project)
        ( $result, $checkTexts_aref, $verdicts_aref ) = CallEnvironmentSpecificFunction( 'Verify', $environment, $value, $crashData_href, $mappingData_href );

        # Try to find a generic solution (e.g. for switches)
        ( $result, $checkTexts_aref, $verdicts_aref ) = CallEnvironmentGenericFunction( 'Verify', $environment, $value, $crashData_href, $mappingData_href ) unless ( abs($result) );

        # Check Ignore-hash (ErrBehaviour='1'): construct hash from 3 subhashes (TNT, cust, proj)
        ( $result, $checkTexts_aref, $verdicts_aref ) = CanBeIgnored( 'Verify', $environment, $value, $crashData_href, $mappingData_href ) unless ( abs($result) );

        $checkTexts_aref = ["---"]          unless defined $checkTexts_aref;
        $verdicts_aref   = ["VERDICT_NONE"] unless defined $verdicts_aref;

        $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{CheckText} = $checkTexts_aref;
        $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{Verdict}   = $verdicts_aref;

        my $failed = 0;
        my $passed = 0;

        my @checkTexts4table;

        for my $i ( 0 .. $#{$checkTexts_aref} ) {
            if ( defined $$verdicts_aref[$i] and $$verdicts_aref[$i] eq "VERDICT_PASS" ) {
                push( @checkTexts4table, '<font color="green">' . $$checkTexts_aref[$i] . '</font>' );
                $passed = 1;
            }
            elsif ( defined $$verdicts_aref[$i] and $$verdicts_aref[$i] eq "VERDICT_FAIL" ) {
                push( @checkTexts4table, '<font color="red">' . $$checkTexts_aref[$i] . '</font>' );
                $failed = 1;
            }
            else {
                push( @checkTexts4table, $$checkTexts_aref[$i] );
            }
        }

        my $element4table = $environment;
        $element4table = '<font color="green">' . $environment . '</font>' if $passed;
        $element4table = '<font color="red">' . $environment . '</font>'   if $failed;
        $element4table = '<strong>' . $element4table . '</strong>';

        S_TableAddRow( $tableObject, [ $element4table, $value, join( "<br>", @$setTexts_aref ), join( "<br>", @checkTexts4table ) ] );

        # if check passed continue with next environment
        if ( $result == 1 ) {
            next;
        }

        # if check failed collect element in @failed, continue with next environment
        elsif ( $result == -1 ) {
            $failed_href->{$environment} = $value;
            next;
        }

        # if none of the above methods was successful, collect unsuccessful element in @unsuccessful
        $unsuccessful_href->{$environment} = $value;
    }

    S_TablePrint( HTML | 3, $tableObject, 'PrepareAndCheckEnvironments__' . $scenario, [ "#DDDDDD", "CCECFF", "#CCFFCC", ] );

    return 1 if ($main::opt_offline);    # return 1 in offline

    # Throw error if there was at least one unsuccessful element
    my $unsuccessfulString;
    my $staticNotHandled = 0;

    foreach my $element ( sort keys %{$unsuccessful_href} ) {
        $unsuccessfulString .= $element . " -> " . $unsuccessful_href->{$element} . "\n";
        my $environmentType = GetEnvironmentType( $crashData_href, $element );
        if ( $environmentType eq 'STATIC' ) {
            $staticNotHandled = 1;
        }
    }

    if ($unsuccessfulString) {
        my $errorText = "No successful method found to check the following environments:\n$unsuccessfulString";
        my $errorCode;
        if ( $errorHandling =~ /^strict$/i and $staticNotHandled ) {
            $errorCode = 112;    # system error!
        }
        elsif ( $errorHandling =~ /^relaxed$/i ) {
            $errorCode = 0;      # warning
        }
        else {
            $errorCode = 109;    # regular error
        }
        S_set_error( $errorText, $errorCode );
    }

    # Throw error if there was at least one failed element
    my $failedString;
    my $staticFailed = 0;

    foreach my $element ( sort keys %{$failed_href} ) {
        $failedString .= $element . " -> " . $failed_href->{$element} . "\n";
        my $environmentType = GetEnvironmentType( $crashData_href, $element );
        if ( $environmentType eq 'STATIC' ) {
            $staticFailed = 1;
        }
    }

    if ($failedString) {
        my $errorText = "Check Settings of following Environments failed:\n$failedString";
        my $errorCode;
        if ( $failedHandling =~ /^strict$/i and $staticFailed ) {
            $errorCode = 112;    # system error!
        }
        elsif ( $failedHandling =~ /^relaxed$/i ) {
            $errorCode = 0;      # warning
        }
        else {
            $errorCode = 109;    # regular error
        }
        S_set_error( $errorText, $errorCode );
    }

    return 0 if ( $failedString or $unsuccessfulString );
    return 1;

}

=head2 CSI_PrepareEnvironment

    $status = CSI_PrepareEnvironment( $crashData_href, $scenario [, $errorHandling ] );

Extracts the environment data from $crashData_href, loops over all or a subset of environments (depending on $scenario, see below) and applies the following
procedure to each element:

B<1:> Try to find a function with the name of the element in FuncLib_..._crash_simulation (TNT, Custlib or Project)

B<2:> Try to find a generic solution for the element (e.g. for switches or sensors)

B<3:> Check if the element with the corresponding value can be ignored. This can be because of generic ignore rules or because the element and corresponding value is found in $standardExcludeList_href in FuncLib_TNT_crash_simulation

B<4:> Throw an error or warning if none of the above methods were successful (see $errorHandling below).

$crashData_href is the output of L</"CSI_GetCrashDataFromMDS">.

$scenario can be 'init_complete', 'before_crash' or 'after_crash':

B<This function should not be used for crash_sensors of type SPI_SensorSimulation>

=over

=item 'init_complete'

Both static and dynamic environments will be set.

=item 'before_crash'

Static environments and reset environments (those environments that are defined in 
$Defaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{'RESET'}) will be set.

=item 'after_crash'

Static environments and reset environments (see above) will be reset. 
Reset values are either defined in $Defaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{'RESET'} or
in the functions that handle the environment.

=back

$errorHandling determines how the error handling is done if an environment could not be handled:

=over

=item *

If $errorHandling is "strict" then a system error is thrown if a static environment could not be handled. 
The verdict of the current test case will be set to "INCONC" and test execution will be stopped after the current test case.
A regular error is thrown if a dynamic environment could not be handled.

=item *

If $errorHandling is not defined or "normal" then a regular error is thrown if any environment could not be handled.
The verdict of the current test case will be set to "INCONC" but test execution will continue normally after the current test case.

=item *

If $errorHandling is "relaxed" then only a warning is thrown if any environment could not be handled.
The verdict of the current test case will not be changed and test execution will continue normally after the current test case.

=back

Returns 1 on success, 0 otherwise.

=cut

sub CSI_PrepareEnvironment {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_PrepareEnvironment( $crashData_href, $scenario [, $errorHandling ] )', @args );

    my $crashData_href = shift @args;
    my $scenario       = shift @args;
    my $errorHandling  = shift @args;

    if ( $scenario !~ /^init_complete|before_crash|before_crash_same_cycle|after_crash$/i ) {
        S_set_error( "Given argument \$scenario is '$scenario', but it must be one of: 'init_complete', 'before_crash', 'before_crash_same_cycle','after_crash'.", 109 );
        return 0;
    }

    $errorHandling = 'normal' if not defined $errorHandling;
    if ( $errorHandling !~ /^strict|normal|relaxed$/i ) {
        S_set_error( "Given argument \$errorHandling is '$errorHandling', but it must be one of: 'strict', 'normal', 'relaxed'", 109 );
        return 0;
    }

    # check if there is a database change
    if ( $scenario =~ /^before_crash$/i and $crashData_href->{'METADATA'}{'RESULTDB'} ne $lastRESULTDB ) {
        S_w2log( 1, "CSI_PrepareEnvironment: RESULTDB has changed. Scenario 'before_crash' will be changed into 'init_complete'." );
        $scenario = 'init_complete';

        Check4MissingMandatoryEnvironments( $errorHandling, $crashData_href );
        $lastRESULTDB = $crashData_href->{'METADATA'}{'RESULTDB'};
    }

    $environment_href = GetRelevantEnvironments( $crashData_href, $scenario, $errorHandling ) unless defined $environment_href;
    my @filteredEnv = FilterEnvironments($scenario);

    # check if there are any environment data
    if ( @filteredEnv == 0 ) {
        S_w2log( 1, "CSI_PrepareEnvironment: No environment data for scenario '$scenario' found in given crash data. Nothing will be done." );
        return 1;
    }

    my $unsuccessful_href = {};
    foreach my $environment ( sort @filteredEnv ) {
        my $result           = 0;
        my $setTexts_aref    = ["---"];
        my $envType          = GetEnvironmentType( $crashData_href, $environment );
        my $value            = $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{Value};
        my $mappingData_href = $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$environment};
        my $callType         = "Set";

        # store that environment has been handled
        $environment_href->{$environment}{handled} = 1;

        # get value for reset during scenario after_crash
        $value    = $mappingData_href->{ResetMdbValue} if ( $scenario =~ /^after_crash$/i and exists $mappingData_href->{ResetMdbValue} );
        $value    = $mappingData_href->{ResetValue}    if ( $scenario =~ /^after_crash$/i and exists $mappingData_href->{ResetValue} );
        $callType = "Reset"                            if ( $scenario =~ /^after_crash$/i and exists $mappingData_href->{ResetValue} );

        S_w2log( 1, "CSI_PrepareEnvironment scenario '$scenario': Setting environment '$environment' to value '$value'..." );

        # Try to find a function with the name of the environment in FuncLib_crash_simulation (TNT or Custlib or Project)
        ( $result, $setTexts_aref ) = CallEnvironmentSpecificFunction( $callType, $environment, $value, $crashData_href, $mappingData_href );

        # Try to find a generic solution (e.g. for switches)
        ( $result, $setTexts_aref ) = CallEnvironmentGenericFunction( $callType, $environment, $value, $crashData_href, $mappingData_href ) unless $result;

        # Check Ignore-hash (ErrBehaviour='1'): construct hash from 3 subhashes (TNT, cust, proj)
        ( $result, $setTexts_aref ) = CanBeIgnored( $callType, $environment, $value, $crashData_href, $mappingData_href ) unless $result;

        # store Texts for reporting if not after crash
        if ( $scenario !~ /^after_crash$/i ) {
            $setTexts_aref = ["---"] unless defined $setTexts_aref;
            $crashData_href->{'ENVIRONMENT'}{$envType}{$environment}{SetText} = $setTexts_aref;
        }

        next if ( $result == 1 );

        # if none of the above methods was successful, collect unsuccessful element in @unsuccessful
        $unsuccessful_href->{$environment} = $value;
    }

    # Throw error if there was at least one unsuccessful element
    my @unsuccessful = sort keys %{$unsuccessful_href};
    if ( @unsuccessful > 0 ) {
        my $unsuccessfulString;
        my $staticNotHandled = 0;
        foreach my $element (@unsuccessful) {
            $unsuccessfulString .= $element . " -> " . $unsuccessful_href->{$element} . "\n";
            my $environmentType = GetEnvironmentType( $crashData_href, $element );
            if ( $environmentType eq 'STATIC' ) {
                $staticNotHandled = 1;
            }
        }
        my $errorText = "No successful method found to handle the following environments:\n$unsuccessfulString";
        $errorText .= "If there were errors before about one or more of these environments, please fix those errors.\n";
        $errorText .= "Otherwise please add a function for each of the unsuccessful environments in either FuncLib_CustLib_crash_simulation.pm or FuncLib_Project_crash_simulation.pm that sets the environment.";
        my $errorCode;
        if ( $errorHandling =~ /^strict$/i and $staticNotHandled ) {
            $errorCode = 112;    # system error!
        }
        elsif ( $errorHandling =~ /^relaxed$/i ) {
            $errorCode = 0;      # warning
        }
        else {
            $errorCode = 109;    # regular error
        }
        S_set_error( $errorText, $errorCode );
        return 0;
    }
    else {
        return 1;
    }
}

sub FilterEnvironments {
    my $scenario = shift;

    my @filteredEnv;

    foreach my $environment ( sort keys %{$environment_href} ) {
        if (   $scenario =~ /^init_complete$/i and not exists $environment_href->{$environment}{SameCylceAsCrash}
            or $scenario =~ /^before_crash$/i            and not exists $environment_href->{$environment}{SameCylceAsCrash}
            or $scenario =~ /^before_crash_same_cycle$/i and exists $environment_href->{$environment}{SameCylceAsCrash}
            or $scenario =~ /^after_crash$/i             and exists $environment_href->{$environment}{Reset} )
        {
            push( @filteredEnv, $environment );
        }
    }

    return @filteredEnv;
}

sub GetRelevantEnvironments {
    my $crashData_href = shift;
    my $scenario       = shift;
    my $errorHandling  = shift;

    S_w2log( 3, "CSI_PrepareEnvironment: Collecting all relevant environments for given scenario '$scenario'." );

    my ($localEnvironment_href);

    foreach my $staticEnv ( sort keys %{ $crashData_href->{'ENVIRONMENT'}{'STATIC'} } ) {
        my $reset                        = exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{ResetValue} or exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{ResetMdbValue};
        my $crashCycle                   = exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{SameCylceAsCrash};
        my $crashCycleFaultManipulation  = ( exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} and $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} eq 'FaultManipulation' );
        my $force4eachIteration          = exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{Force4eachIteration};
        my $force4eachIterationNetSignal = ( exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} and $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} eq 'NetSignal' );
        my $force4eachIterationValidity  = ( exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} and $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$staticEnv}{EnvType} eq 'Validity' );

        # move static env to dynamic if reset, crashCycle or netSignal
        $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$staticEnv} = delete $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$staticEnv} if ( $reset or $crashCycle or $crashCycleFaultManipulation or $force4eachIteration or $force4eachIterationNetSignal or $force4eachIterationValidity );
        next unless ( $scenario =~ /^init_complete$/i );

        $localEnvironment_href->{$staticEnv} = {};
        $localEnvironment_href->{$staticEnv}{handled} = -1;
        $localEnvironment_href->{$staticEnv}{handled} = 0 if ( $errorHandling =~ /^relaxed$/i );
    }
    foreach my $dynamicEnv ( sort keys %{ $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'} } ) {
        $localEnvironment_href->{$dynamicEnv} = {};
        $localEnvironment_href->{$dynamicEnv}{Reset}            = 1 if exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$dynamicEnv}{ResetValue} or exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$dynamicEnv}{ResetMdbValue};
        $localEnvironment_href->{$dynamicEnv}{SameCylceAsCrash} = 1 if exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$dynamicEnv}{SameCylceAsCrash};
        $localEnvironment_href->{$dynamicEnv}{SameCylceAsCrash} = 1 if ( exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$dynamicEnv}{EnvType} and $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$dynamicEnv}{EnvType} eq 'FaultManipulation' );
        $localEnvironment_href->{$dynamicEnv}{handled}          = -1;
        $localEnvironment_href->{$dynamicEnv}{handled}          = 0 if ( $errorHandling =~ /^relaxed$/i );

    }

    return $localEnvironment_href;
}

sub Check4MissingMandatoryEnvironments {
    my $errorHandling  = shift;
    my $crashData_href = shift;

    my @missingMandatoryEnv;

    foreach my $envName ( keys %{ $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'} } ) {
        next unless exists $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$envName}{Mandatory};
        next unless $main::ProjectDefaults->{'CRASH_SIMULATION'}{'ENVIRONMENT'}{$envName}{Mandatory};
        next if exists $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envName};
        next if exists $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envName};
        push( @missingMandatoryEnv, $envName );
    }

    if ( @missingMandatoryEnv > 0 ) {
        my $unsuccessfulString;
        my $staticNotHandled = 0;
        foreach my $element (@missingMandatoryEnv) {
            $unsuccessfulString .= $element . "\n";
        }
        my $errorText = "Missing mandatory environments:\n$unsuccessfulString";
        $errorText .= "These environments have been defined as 'mandatory' in CREIS mapping, but are not selected as 'CREIS relevant' in *.mdb.\n";
        $errorText .= "Please discuss with SE - Team and get an updated *.mdb or mapping accordingly.\n";
        my $errorCode;
        if ( $errorHandling =~ /^relaxed$/i ) {
            $errorCode = 0;    # warning
        }
        else {
            $errorCode = 112;    # system error
        }
        S_set_error( $errorText, $errorCode );
        return 0;
    }
}

=head2 CSI_LoadAllData2Simulator

    CSI_LoadAllData2Simulator( $crashData_href [, $modifySignals_href ] );
    
Loads all crash sensor stimulation data of $crashData_href (crash sensor data, network dynamic data)
to the respective devices if they are configured in LIFT_testbenches.
See CSI_LoadAllData2Simulator and CSI_LoadNetworkDynamicData2Simulator for further details about functionality and arguments.

Returns 1 on success, 0 otherwise.

=cut

sub CSI_LoadAllData2Simulator {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_LoadAllData2Simulator( $crashData_href [, $modifySignals_href ] )', @args );

    my $crashData_href     = shift @args;
    my $modifySignals_href = shift @args;

    my $loadFunctions_href = {

        # <function group> => <load function>
        'crash_sensors'   => 'CSI_LoadCrashSensorData2Simulator',
        'network_dynamic' => 'CSI_LoadNetworkDynamicData2Simulator',
    };

    # loop over all function groups in $loadFunctions_href
    foreach my $functionGroup ( keys %{$loadFunctions_href} ) {

        # get the device that is configured in LIFT_testbenches for $functionGroup
        my $device = FL_GetConfiguredDevice( 'Crash_simulation', $functionGroup );
        if ( defined $device ) {

            # if a device is configured for $functionGroup then call the corresponding function for loading the data
            no strict 'refs';
            my $loadFunction = $loadFunctions_href->{$functionGroup};
            my $success = &$loadFunction( $crashData_href, $modifySignals_href );    # call the load function
            return 0 if not $success;
        }
        else {
            # otherwise tell the user that no data will be loaded
            S_w2log( 1, "CSI_LoadAllData2Simulator: No device configured for functional module 'Crash_simulation' and function group '$functionGroup' in LIFT_testbenches. No '$functionGroup' data will be used in this crash." );

            # check if data are present in crash that should be loaded
            my @crashSignals = keys %{ $crashData_href->{'STIMULATION'}{ uc($functionGroup) } };
            if ( @crashSignals > 0 ) {
                S_set_error( "Crash data present for '$functionGroup', but no device configured for functional module 'Crash_simulation' and function group '$functionGroup' in LIFT_testbenches.", 114 );
                return 0;
            }
        }
    }

    return 1;
}

=head2 CSI_ExportCrashData

    CSI_ExportCrashData( $crashData_href, $export_format, $exportPath );
    
Exports crash data to format specified in argument '$export_format'.

B<Note:> Function 'CSI_GetCrashDataFromMDS' should be called before calling this function.

B<Arguments:>

=over

=item $crashData_href

Output of function 'CSI_GetCrashDataFromMDS'.

=item $export_format

Desired format to which crash data to be exported.

Range: 

1. 'SPI_SensorSimulation'.
     
     -> Stores data in <CRASHNAME>.zip file containing '<CRASHNAME>.json' 
        file in JSON format.

=item $exportPath

Path of the folder.

Filename is considered as <CRASHNAME> configured in function CSI_GetCrashDataFromMDS.

=back

B<Return Value:>

In case of $export_format = 'SPI_SensorSimulation'

    Returns 1 on successfull creation of <crashname>.zip file with
        contents in JSON file format.  

    undef on error

B<Examples:>

1 = CSI_ExportCrashData($crashData_href, 'SPI_SensorSimulation', "D:\\TurboLIFT\\AB12\\config");

=cut

sub CSI_ExportCrashData {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CSI_ExportCrashData( $crashData_href, $export_type, $export_path, [, $modifySignals_href] )', @args );

    my $crashData_href     = shift @args;
    my $export_type        = shift @args;
    my $exportPath         = shift @args;
    my $modifySignals_href = shift @args;

    delete $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'};
    my $sensorData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'};
    unless ( keys %$sensorData_href ) {
        S_w2log( 3, "CSI_ExportCrashData: No crash sensor data are defined for the current crash. Nothing will be exported.\n" );
        return 1;
    }

    #IF export format SPI_SensorSimulation?
    #IF-NO-START
    #STEP return undef

    if ( $export_type ne 'SPI_SensorSimulation' ) {
        S_set_error( "CSI_ExportCrashData: Invalid Export format '$export_type' selected, Format supported : 'SPI_SensorSimulation' ", 109 );
        return;
    }

    #IF-NO-END

    #IF-YES-START
    if ( $export_type eq 'SPI_SensorSimulation' ) {

        my $device = FL_GetConfiguredDevice( 'Crash_simulation', 'crash_database' );

        unless ( $device eq 'MDSRESULT' ) {
            S_set_error("CSI_ExportCrashData: Input Crash data base device '$device' not supported for export, Valid device is 'MDSRESULT'");
            return;
        }

        S_w2log( 3, "CSI_ExportCrashData: Exporting crash data to SPI_SensorSimulation format started.\n" );

        #CALL Export_SPISIM_Format
        return unless ( Export_SPISIM_Format( $crashData_href, $sensorData_href, $exportPath, $modifySignals_href ) );

        #IF-YES-END
        #STEP END
        S_w2log( 3, "CSI_ExportCrashData: Exporting crash data to SPI_SensorSimulation format done.\n" );
        return 1;
    }
}

=head2 CSI_PostCrashActions

    $success = CSI_PostCrashActions( $crashData_href );

Performs actions that are required after each crash, but are not related to environment settings (e.g. eCall).
Calls internally the function PostCrashActions which is defined in FuncLib_TNT_crash_simulation and which is doing nothing by default.
If project or customer specific post crash actions are required, then those must be included in the function PostCrashActions in
FuncLib_Project_crash_simulation or FuncLib_Cust_crash_simulation.

Returns 1 on success, 0 otherwise.

=cut

sub CSI_PostCrashActions {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_PostCrashActions( $crashData_href )', @args );

    my $crashData_href = shift @args;

    my $success = PostCrashActions($crashData_href);    # this function is defined in FuncLib_TNT_crash_simulation and may be overwritten in FuncLib_Project_crash_simulation or FuncLib_Cust_crash_simulation
    return $success;
}

=head2 CSI_GetChannelAssignmentOverview

    $channelAssignment_href = CSI_GetChannelAssignmentOverview( [ $referenceName ] );

Prints and returns the collected channel assignment overviews for NETWORK_DYNAMIC and CRASH_SENSORS.
Printing is done as table on console, text log file and in html report.
For the html report bookmarks will be created as "$referenceName NETWORK_DYNAMIC" and "$referenceName CRASH_SENSORS",
depending on whether data exist.
If $referenceName is not given then it is set to "CSI ChannelAssignment".
The data are collected on each call to CSI_LoadCrashSensorData2Simulator and CSI_LoadNetworkDynamicData2Simulator.

Example return value:

    $channelAssignment_href = {
        'NETWORK_DYNAMIC' => {
            'net1' => {
                'Frame/PDU' => 'message 1',
                'Signal' => 'signal 1',
            },        
            'net2' => {
                'Frame/PDU' => 'message 2',
                'Signal' => 'signal 2',
            },        
        },
        'CRASH_SENSORS' => {
            'sensor1' => {
                'Device name' => 'device 1', 
                'Channel index' => 1, 
                'Channel name' => 'channel 1', 
                'ROM file' => 'rom 1', 
                'Quate device description' => 'description 1',
            },        
            'sensor2' => {
                'Device name' => 'device 2', 
                'Channel index' => 2, 
                'Channel name' => 'channel 2', 
                'ROM file' => 'rom 2', 
                'Quate device description' => 'description 2',
            },        
        },
    };

=cut

sub CSI_GetChannelAssignmentOverview {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CSI_GetChannelAssignmentOverview( [ $referenceName ] )', @args );

    my $referenceName = shift @args;

    $referenceName = "CSI ChannelAssignment overall" if not defined $referenceName;

    PrintChannelAssignment( $channelAssignmentOverall_href, 'NETWORK_DYNAMIC', [ 'MDS channel', 'Frame/PDU', 'Signal' ], $referenceName );
    PrintChannelAssignment( $channelAssignmentOverall_href, 'CRASH_SENSORS', \@channelAssignmentDataCrashSensors, $referenceName );

    return $channelAssignmentOverall_href;
}

sub PrintChannelAssignment {
    my $channelAssignmentData_href = shift;
    my $section                    = shift;
    my $headerNames_aref           = shift;
    my $referenceName              = shift;

    return 0 if not defined $channelAssignmentData_href->{$section};

    my $tableObject = S_TableCreate($headerNames_aref);
    my @dataKeys    = @$headerNames_aref;
    shift @dataKeys;    # remove first element (MDS channel) because it is the primary key of the channel assignment hash
    foreach my $channel ( sort keys %{ $channelAssignmentData_href->{$section} } ) {
        my @tableData;
        push( @tableData, $channel );
        foreach my $dataKey (@dataKeys) {
            push( @tableData, $channelAssignmentData_href->{$section}{$channel}{$dataKey} );
        }
        S_TableAddRow( $tableObject, \@tableData );
    }
    S_w2log( 1, "Channel assignment for $section data:\n" );
    my $success = S_TablePrint( CONSOLE | TEXT | HTML, $tableObject, "$referenceName $section" );

    return $success;
}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=cut

sub Init_QuaTe {
    eval "use LIFT_QuaTe";
    QuaTe_Init();
    return 1;
}

sub Init_IDEFIX {
    eval "use LIFT_IDEFIX";
    IDX_InitHW();
    return 1;
}

sub Init_MDSRESULT {
    eval "use LIFT_MDSRESULT";
    MDSRESULT_Init();
    return 1;
}

sub Init_can_access {
    eval "use LIFT_can_access";
    CA_init();
    return 1;
}

sub Init_SPI_SensorSimulation {
    eval "use FuncLib_SPI_SensorSimulation";
    SPISIM_Init();
    return 1;
}

=head2 CallDeviceFunction

    CallDeviceFunction( @args );
    
Calls a function that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.
Values of $functionMapping_href are either directly functions of the device layer if a 1:1 mapping is possible.
Otherwise a function of the package LIFT_crash_simulation_xyz is called.

Returns the return values of the called functions. On error returns 0.

=cut

sub CallDeviceFunction {
    my @args = @_;
    return FL_CallDeviceFunction( 'Crash_simulation', $functionMapping_href, @args );
}

sub CreateArchitectureStructure {
    return FL_CreateArchitectureStructure( 'Crash_simulation', $functionMapping_href );
}

=head2 CallEnvironmentSpecificFunction

    CallEnvironmentSpecificFunction( $element, $value, $crashData_href );
    
Checks if a function exists with the name $element. These functions can be defined in 
FuncLib_TNT_crash_simulation, FuncLib_Custlib_crash_simulation or FuncLib_Project_crash_simulation
and are imported into this module by FuncLib_TNT_crash_simulation.

If such a function exists it is called with $value and $crashData_href as arguments.

Returns 1 if the function execution was successful, 0 otherwise.

=cut

sub CallEnvironmentSpecificFunction {
    my $type             = shift;
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $envType             = $mappingData_href->{EnvType};
    my $verificationType    = $mappingData_href->{Verify}{EnvVerificationType};
    my $environmentFunction = $element . '__' . $type;

    if ( ( $envType =~ /^SpecificFunction$/ and ( $type eq 'Set' or not defined $verificationType ) ) or ( $verificationType =~ /^SpecificFunction$/ and $type eq 'Verify' ) ) {
        $environmentFunction = $element . '__' . $type;
    }
    else {
        return 0;
    }

    return 0 if not exists &$environmentFunction;

    S_w2log( 4, "'$type' of '$element' to value $value by function '$environmentFunction'\n" );
    {
        no strict 'refs';
        my ( $success, $setTexts_aref, $verdicts_aref ) = &$environmentFunction( $element, $value, $crashData_href, $mappingData_href );
        return ( $success, $setTexts_aref, $verdicts_aref );
    }

    return 1;
}

=head2 GetEnvironmentType

    $environmentType = GetEnvironmentType( $crashData_href, $environment );

For a given environment $environment looks in the 'ENVIRONMENT' section of $crashData_href and returns the environment type $environmentType:
'STATIC', 'DYNAMIC' or 'UNKOWN' (if $environment is not found in $crashData_href)

Called by CSI_PrepareEnvironment.

=cut

sub GetEnvironmentType {
    my $crashData_href = shift;
    my $environment    = shift;

    my $staticEnvironments_href  = $crashData_href->{'ENVIRONMENT'}{'STATIC'};
    my $dynamicEnvironments_href = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'};

    my $countStatic = 0;
    if ( ref($staticEnvironments_href) eq 'HASH' ) {
        $countStatic = grep { $_ eq $environment } keys %{$staticEnvironments_href};    # count how many times $environment occurs as key in $staticEnvironments_href
    }

    my $countDynamic = 0;
    if ( ref($dynamicEnvironments_href) eq 'HASH' ) {
        $countDynamic = grep { $_ eq $environment } keys %{$dynamicEnvironments_href};    # count how many times $environment occurs as key in $dynamicEnvironments_href
    }

    my $environmentType;
    if ( $countStatic > 0 ) {
        $environmentType = 'STATIC';
    }
    elsif ( $countDynamic > 0 ) {
        $environmentType = 'DYNAMIC';
    }
    else {
        $environmentType = 'UNKNOWN';
    }

    return $environmentType;
}

=head2 GetConfiguredTrigger

    $device = GetConfiguredTrigger( );

Get the trigger type that is configured under section 'Crash_simulation', device 'trigger'.
 Return value :  
 'Triggersoft' => if Crash_simulation=>{trigger} equals to 'can_access'
 'Triggerhard' => if Crash_simulation=>{trigger} equals to 'QuaTe'  
 'undef'       => if invalid device found.

Called by CSI_LoadCrashSensorData2Simulator and CSI_LoadNetworkDynamicData2Simulator.
 
=cut

sub GetConfiguredTrigger {
    my $trigger_type = FL_GetConfiguredDevice( 'Crash_simulation', 'trigger' );

    if ( defined $trigger_type ) {
        if ( $trigger_type =~ /^can_access$/i ) {
            return 'Triggersoft';
        }
        elsif ( $trigger_type =~ /^QuaTe/i ) {
            return 'Triggerhard';
        }
        else {
            S_set_error( "Invalid trigger found in Testbench under Section 'Crash_simulation'=>{'trigger'}. Expected 'can_access' or 'QuaTe'", 114 );
            return;
        }
    }

    return 1;
}

=head2 ModifySignal

    $dataModified_aref = ModifySignal( $signalName, $data_aref, $modifySignals_href );

Modifies a given data array ($data_aref) for signal $signalName with modification parameters ($modifySignals_href).
$modifySignals_href can contain the following keys:

    'factor':  a factor that is multiplied to each data point
    'offset':  an offset that is added to each data point
    'exclude': if set to 1 then undef will be returned; the data will be ignored for the given signal

The keys can be combined. 'factor' is applied before 'offset'.
The modified data array is returned ($dataModified_aref).

Called by CSI_LoadCrashSensorData2Simulator and CSI_LoadNetworkDynamicData2Simulator.

=cut

sub ModifySignal {
    my $signalName         = shift;
    my $data_aref          = shift;
    my $modifySignals_href = shift;

    if ( not defined $modifySignals_href->{$signalName} ) {
        return $data_aref;
    }

    my ( $factor, $offset, $exclude );
    foreach my $modifyType ( sort keys %{ $modifySignals_href->{$signalName} } ) {
        if ( $modifyType =~ /^factor$/i ) {
            $factor = $modifySignals_href->{$signalName}{$modifyType};
        }
        elsif ( $modifyType =~ /^offset$/i ) {
            $offset = $modifySignals_href->{$signalName}{$modifyType};
        }
        elsif ( $modifyType =~ /^exclude$/i ) {
            $exclude = $modifySignals_href->{$signalName}{$modifyType};
        }
        else {
            S_set_error("In '\$modifySignals_href' for signal '$signalName' the given modification option '$modifyType' is unknown. It must be 'factor', 'offset' or 'exclude'.");
            return;
        }
    }

    if ($exclude) {
        S_w2log( 2, "Excluding signal $signalName from simulation \n" );
        return;
    }

    my @modifiedData = @$data_aref;    # copy data into @modifiedData

    if ( defined $factor ) {
        @modifiedData = map { $_ * $factor } @modifiedData;
        S_w2log( 2, "Applying factor $factor to data for signal $signalName \n" );
    }

    if ( defined $offset ) {
        @modifiedData = map { $_ + $offset } @modifiedData;
        S_w2log( 2, "Applying offset $offset to data for signal $signalName \n" );
    }

    return \@modifiedData;

}

=head2 Fill_spi_channel_and_signal_details

    $collect_modified_data_href = Fill_spi_channel_and_signal_details( $sensorData_href, $modifySignals_href );

Modifies a given data array ($data_aref) for signal $signalName with modification parameters ($modifySignals_href).
and also collects the device name and and channel names required for crash injection using SPI_SensorSimulation

Called by CSI_ExportCrashData and CSI_LoadCrashSensorData2Simulator.

=cut

sub Fill_spi_channel_and_signal_details {

    my $sensorData_href    = shift;
    my $modifySignals_href = shift;

    my $collect_modified_data_href = {};
    foreach my $sensorName ( keys %{$sensorData_href} ) {
        my $sensorDeviceName = $sensorData_href->{$sensorName}{'DeviceName'};
        my $deviceName       = $sensorDeviceName;
        my $channelName      = $sensorDeviceName;
        if ( $sensorDeviceName =~ /^\s*(.+)::(.+)\s*$/ ) {
            $deviceName  = $1;
            $channelName = $2;
        }
        my $data_aref       = $sensorData_href->{$sensorName}{'SIGNALS'};
        my $samplingTime_us = $sensorData_href->{$sensorName}{'SAMPLETIME_US'};

        if ( $samplingTime_us > 0 ) {
            $data_aref = LIFT_crash_simulation::ModifySignal( $sensorDeviceName, $data_aref, $modifySignals_href ) if defined $modifySignals_href;
        }

        my $options_href = {
            'device_name'   => $deviceName,         # name must match the CREIS mapping
            'channel_name'  => $channelName,        # name must match the CREIS mapping
            'data_aref'     => $data_aref,          # crash data in g
            'sampling_time' => $samplingTime_us,    # sampling time in micro seconds.
        };
        $collect_modified_data_href->{$sensorName} = $options_href;
    }

    return $collect_modified_data_href;
}

=head2 Export_SPISIM_Format

    1 = Export_SPISIM_Format ( $crashData_href, $sensorData_href, $export_path, [, $modifySignals_href] );

Exports crash data into a json format file speficied in the export path argument.

Called by CSI_ExportCrashData

B<Returns>

    1 on success.
    undef on error.

=cut

sub Export_SPISIM_Format {

    my @args = @_;
    return unless S_checkFunctionArguments( 'Export_SPISIM_Format( $crashData_href, $sensorData_href, $export_path, [, $modifySignals_href] )', @args );

    my $crashData_href     = shift @args;
    my $sensorData_href    = shift @args;
    my $exportPath         = shift @args;
    my $modifySignals_href = shift @args;

    my $collect_devName_chnName_modifiedData_href = Fill_spi_channel_and_signal_details( $sensorData_href, $modifySignals_href );

    #CALL SPISIM_PrepareCrashData
    return unless ( SPISIM_PrepareCrashData( $collect_devName_chnName_modifiedData_href, $crashData_href ) );

    #STEP convert crash data to JSON format
    my $json_text = encode_json($crashData_href);

    #STEP Get crashname and export to <CRASHNAME>.json file
    my $crashname = $crashData_href->{METADATA}{CRASHNAME};
    unless ($crashname) {
        S_set_error( "CSI_ExportCrashData: 'CRASHNAME' not found in the crash data!", 109 );
        return;
    }

    # create export path if not exists
    unless ( -e $exportPath ) {
        make_path( $exportPath, { error => \my $err } );
        if ($err) {
            S_set_error( "CSI_ExportCrashData : Export Path '$exportPath' could not be created", 109 );
            return;
        }
    }

    my $dirname    = $exportPath . '/' . $crashname;
    my $zip_handle = S_open_zip("$dirname.zip");
    $crashname = $crashname . ".json";
    write_file( $crashname, { err_mode => 1 }, $json_text );
    unless ( -e $crashname ) {
        S_set_error( "CSI_ExportCrashData: Error in writting crash data to $crashname : $!", 109 );
        return;
    }

    return unless ( S_add_to_zip( $zip_handle, $crashname ) );
    return unless ( S_close_zip($zip_handle) );
    unlink $exportPath . '/' . $crashname;    #delete the the file after zipping it.
    return 1;
}

=head2 CanBeIgnored

    CanBeIgnored($environment, $value);

Looks up if crash environment $environment can be ignored because the settings defined by $environment and $value are default settings.
Generic ignore patterns and the hash $standardExcludeList_href (which is defined in FuncLib_TNT_crash_simulation) are used to find the entries to be ignored.

Returns 1 if the pair $environment, $value can be ignored and 0 otherwise.

=cut

sub CanBeIgnored {
    my $type             = shift;
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $envType          = $mappingData_href->{EnvType};
    my $text             = $mappingData_href->{Text};
    my $verificationType = $mappingData_href->{Verify}{EnvVerificationType};
    my $verificationText = $mappingData_href->{Verify}{Text};

    if ( $envType =~ /^Parameter$/ and ( $type eq 'Set' or not defined $verificationType ) ) {
        S_w2log( 3, "Environment '$element' will not be handled: $text\n" );
        return ( 1, ["Ignored: $text"], ['VERDICT_NONE'] );
    }

    if ( $verificationType =~ /^Parameter$/ and $type eq 'Verify' ) {
        S_w2log( 3, "Environment '$element' will not be handled: $text\n" );
        return ( 1, ["Ignored: $verificationText"], ['VERDICT_NONE'] );
    }

    return 0;
}

=head2 CallEnvironmentGenericFunction

    CallEnvironmentGenericFunction($environment, $value);

Tries to find a generic pattern in crash environment $environment 
(e.g. for switch State/Configured, sensor ErrBehaviour/Configured, sensor OverloadBhvr)
and calls the corresponding generic function to set the environment condition to value $value if a pattern was found.
If no generic pattern is found then nothing is done.

Returns 1 on success and 0 otherwise.

=cut

sub CallEnvironmentGenericFunction {
    my $type             = shift;
    my $element          = shift;
    my $value            = shift;
    my $crashData_href   = shift;
    my $mappingData_href = shift;

    my $environmentFunction;
    $environmentFunction = $mappingData_href->{EnvType} . '__Set'                        if $type eq 'Set';
    $environmentFunction = $mappingData_href->{EnvType} . '__Reset'                      if $type eq 'Reset';
    $environmentFunction = $mappingData_href->{Verify}{EnvVerificationType} . '__Verify' if $type eq 'Verify';

    return 0 if not exists &$environmentFunction;

    S_w2log( 4, "'$type' of '$element' to value $value by function '$environmentFunction'\n" );
    {
        no strict 'refs';
        my ( $success, $setTexts_aref, $verdicts_aref ) = &$environmentFunction( $element, $value, $crashData_href, $mappingData_href );
        return ( $success, $setTexts_aref, $verdicts_aref );
    }

    return 0;

}

=head2 SetOverloadChannel

    SetOverloadChannel($sensor, $value, $crashData_href); (not exported)

Returns 1 on success and 0 otherwise.

=cut

sub SetOverloadChannel {
    my $sensor         = shift;
    my $value          = shift;
    my $crashData_href = shift;

    my $environment = 'CsEcu' . $sensor . 'OverloadBhvr';
    my $errorPrefix = "Crash environment '$environment' for overload:";

    if ( $value !~ /[0-3]/ ) {
        S_set_error( "$errorPrefix unknown value '$value'. Value must be 0, 1, 2 or 3", 114 );
        return 0;
    }

    my $crashSensorMapping_href = S_get_contents_of_hash( [ 'CRASH_SIMULATION', 'STIMULATION', 'CRASH_SENSORS' ] );
    if ( not defined $crashSensorMapping_href ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' is not defined in project constants.", 114 );
        return 0;
    }

    my $overloadMapping_href = S_get_contents_of_hash( [ 'CRASH_SIMULATION', 'ENVIRONMENT', 'OVERLOAD' ] );
    if ( not defined $overloadMapping_href ) {
        S_set_error( "$errorPrefix Section 'CRASH_SIMULATION'=>'ENVIRONMENT'=>'OVERLOAD' is not defined in project constants.", 114 );
        return 0;
    }

    my $crashSensor = $overloadMapping_href->{$sensor}{'CRASH_SENSOR'};
    if ( not defined $crashSensor ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined, but not found in 'CRASH_SIMULATION'=>'ENVIRONMENT'=>'OVERLOAD' in project constants.", 114 );
        return 0;
    }

    my $sensorSimulatorName = $crashSensorMapping_href->{$crashSensor};
    if ( not defined $sensorSimulatorName ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to crash sensor '$crashSensor', but the latter is not found in 'CRASH_SIMULATION'=>'STIMULATION'=>'CRASH_SENSORS' in project constants.", 114 );
        return 0;
    }

    my $deviceName  = $sensorSimulatorName;
    my $channelName = $sensorSimulatorName;
    if ( $sensorSimulatorName =~ /^\s*(.+)::(.+)\s*$/ ) {
        $deviceName  = $1;
        $channelName = $2;
    }

    if ( $value == 0 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "DISABLE" );
        return 1;
    }

    my $stimulationData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'}{$sensorSimulatorName};
    if ( not defined $stimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined and mapped to sensor '$sensorSimulatorName', but no data found for '$sensorSimulatorName' in the crash data.", 114 );
        return 0;
    }
    my $dataSamples   = scalar( @{ $stimulationData_href->{'SIGNALS'} } );
    my $sampleTime_us = $stimulationData_href->{'SAMPLETIME_US'};

    if ( $value == 1 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "PERMANENT", $dataSamples, $sampleTime_us );
        return 1;
    }

    my $envAddName   = 'CsEcu' . $sensor . 'OverloadStart';
    my $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName}{Value};
    $startTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName}{Value} if not defined $startTime_ms;
    if ( not defined $startTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }
    $envAddName = 'CsEcu' . $sensor . 'OverloadEnd';
    my $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$envAddName}{Value};
    $endTime_ms = $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$envAddName}{Value} if not defined $endTime_ms;
    if ( not defined $endTime_ms ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with value '$value', but '$envAddName' is not defined in the crash environment.", 114 );
        return 0;
    }

    if ( $value == 2 ) {
        QuaTe_SetOverloadChannel( $deviceName, $channelName, "START2END", $dataSamples, $sampleTime_us, [], [], [], $startTime_ms, $endTime_ms );
        return 1;
    }

    my $overloadChannel              = $overloadMapping_href->{$sensor}{'OVERLOAD_CHANNEL'};
    my $overloadStimulationData_href = $crashData_href->{'STIMULATION'}{'UNMAPPED'}{$overloadChannel};
    if ( not defined $overloadStimulationData_href ) {
        S_set_error( "$errorPrefix Sensor '$sensor' defined with overload channel '$overloadChannel', but no data found for '$overloadChannel' in the crash data.", 114 );
        return 0;
    }
    my $overloadData_aref    = $overloadStimulationData_href->{'SIGNALS'};
    my $overloadDataSamples  = scalar( @{$overloadData_aref} );
    my $overoadSampleTime_us = $overloadStimulationData_href->{'SAMPLETIME_US'};

    # if $value == 3
    QuaTe_SetOverloadChannel( $deviceName, $channelName, "DBSIGNAL", $dataSamples, $sampleTime_us, $overloadDataSamples, $overoadSampleTime_us, $overloadData_aref );

    return 1;

}

############################################################################################################
#
#
# package LIFT_crash_simulation_MDSRESULT
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of CSI_* function and MDSRESULT_* function is not possible.

package LIFT_crash_simulation_MDSRESULT;

use strict;
use warnings;
use LIFT_general;
use LIFT_MDSRESULT;
use Readonly;
use Data::Dumper;

# Additional sensor properties
Readonly my $SENSOR_PROPERTY_AMPLITUDE        => "AMPLITUDE";
Readonly my $SENSOR_PROPERTY_OFFSET           => "OFFSET";
Readonly my $SENSOR_PROPERTY_CORRECTION_ANGLE => "CORRECTION_ANGLE";

# variables to hold crash data and config of last crash
my $lastCrashData_href   = {};
my $lastSerializedParams = '';

sub CSI_GetCrashDataFromMDS {

    my $crashIdentifyParams_href = shift;
    my $sensorProperties_href    = shift;
    my $sensorPropertyKeys_aref  = shift;

    my $crashData_href;

    S_w2log( 3, "CSI_GetCrashDataFromMDS: Getting crash data from MDS...\n" );

    # If the same $crashIdentifyParams_href is used as in the last crash then the same data can be used
    my $serializedParams = Dumper($crashIdentifyParams_href);
    if ( $serializedParams eq $lastSerializedParams ) {
        S_w2log( 3, "CSI_GetCrashDataFromMDS: Crash parameters are the same as for last successful crash. Re-using data of last successful crash.\n" );
        $crashData_href = $lastCrashData_href;
        return $crashData_href;
    }

    # add MDS related data to $sensorProperties_href and $sensorPropertyKeys_aref
    my @sensorPropertyKeys;
    my $noFiltering = 1;
    if ( defined $sensorProperties_href ) {
        $noFiltering = 0;
        foreach my $crashSensor ( keys %{$sensorProperties_href} ) {
            $sensorProperties_href->{$crashSensor}{$SENSOR_PROPERTY_AMPLITUDE}        = 1.0;
            $sensorProperties_href->{$crashSensor}{$SENSOR_PROPERTY_OFFSET}           = 0.0;
            $sensorProperties_href->{$crashSensor}{$SENSOR_PROPERTY_CORRECTION_ANGLE} = 0.0;

        }
        @sensorPropertyKeys = @$sensorPropertyKeys_aref if defined $sensorPropertyKeys_aref;
        push( @sensorPropertyKeys, $SENSOR_PROPERTY_AMPLITUDE );
        push( @sensorPropertyKeys, $SENSOR_PROPERTY_OFFSET );
        push( @sensorPropertyKeys, $SENSOR_PROPERTY_CORRECTION_ANGLE );
    }

    # get crash simulation mapping
    my $crashSimulationMapping_href = S_get_contents_of_hash( ['CRASH_SIMULATION'] );
    if ( not defined $crashSimulationMapping_href ) {
        S_set_error( "Section 'CRASH_SIMULATION' is not defined in project constants.", 114 );
        return;
    }

    # get all crash data
    $crashData_href = MDSRESULT_GetCrashDetails( $crashIdentifyParams_href, $noFiltering, $sensorProperties_href, \@sensorPropertyKeys );

    # get dynamic environments
    my ( $sensorName_aref, $simDevices_aref, $envName_Const_aref, $envName_Dynamic_aref ) = MDSRESULT_GetAllUsedDeviceNames();

    # sort environments to static and dynamic
    foreach my $environment ( keys %{ $crashData_href->{'ENVIRONMENT'} } ) {
        if ( grep { $_ eq $environment } @$envName_Dynamic_aref ) {
            $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{Value}     = delete $crashData_href->{'ENVIRONMENT'}{$environment};
            $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{SetText}   = [];
            $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{CheckText} = [];
            $crashData_href->{'ENVIRONMENT'}{'DYNAMIC'}{$environment}{Verdict}   = ["VERDICT_NONE"];
        }
        else {
            $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{Value}     = delete $crashData_href->{'ENVIRONMENT'}{$environment};
            $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{SetText}   = [];
            $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{CheckText} = [];
            $crashData_href->{'ENVIRONMENT'}{'STATIC'}{$environment}{Verdict}   = ["VERDICT_NONE"];
        }
    }

    # move all meta data keys under primary key METADATA
    my @metaKeys = qw(CRASHINDEX CRASHNAME ISMERGECRASH STATEVARIATION TIMESHIFT_ms VELOCITY_kmh VELOCITY_X_kmh VELOCITY_CLOSING_kmh TEMPERATURE_degCelsius CRASH_ASSIGNMENT_COMMENT);
    foreach my $metaKey (@metaKeys) {
        $crashData_href->{'METADATA'}{$metaKey} = delete $crashData_href->{$metaKey};
    }

    # add database name to metadata
    $crashData_href->{'METADATA'}{'RESULTDB'} = $crashIdentifyParams_href->{'RESULTDB'};

    # add algo IDs to metadata
    $crashData_href->{'METADATA'}{'ALGOIDS'} = MDSRESULT_GetAlgoIDs();

    # rename keys to have the names more logical for testers
    $crashData_href->{'STIMULATION'}{'UNMAPPED'} = delete $crashData_href->{'SENSORS'};
    $crashData_href->{'EXPECTEDRESULT'} = delete $crashData_href->{'SIMDEVICES'};

    # calculate the duration of the crash and store it in METADATA
    CalculateCrashDuration($crashData_href);

    # map the stimulation signals to sensor channels
    MapStimulationSignals( $crashData_href, $crashSimulationMapping_href, 'CRASH_SENSORS' );

    # map the stimulation signals to network signals
    MapStimulationSignals( $crashData_href, $crashSimulationMapping_href, 'NETWORK_DYNAMIC' );

    # Check for unmapped stimulation signals. Overload signals may remain unmapped. All other signals must not be unmapped and an error must be set.

    # First get a list with all overload signals. Several sensor signals can have the same overload signal.
    # Therefore we use a hash to collect the names without having duplicates.
    my %overloadHash;
    foreach my $signalName ( keys %{ $crashSimulationMapping_href->{'ENVIRONMENT'}{'OVERLOAD'} } ) {
        my $overloadChannel = $crashSimulationMapping_href->{'ENVIRONMENT'}{'OVERLOAD'}{$signalName}{'OVERLOAD_CHANNEL'};
        $overloadHash{$overloadChannel} = 1;
    }
    my @overloadNames = keys %overloadHash;

    # Now check for each unmapped signal if it is in the list of overload signals.
    # If so do nothing, otherwise push it into the list of unmapped signals.
    my @unmappedNames;
    foreach my $signalName ( keys %{ $crashData_href->{'STIMULATION'}{'UNMAPPED'} } ) {
        next if grep { /^$signalName$/ } @overloadNames;
        push( @unmappedNames, $signalName );
    }

    # Throw an error if there are entries in the list of unmapped signals
    if ( @unmappedNames > 0 ) {
        push( @unmappedNames, '.' );    # to have a \n after the last element
        my $unmappedNamesString = join( "\n", @unmappedNames );
        S_set_error( "The following stimulation signals from the crash database are not mapped in crash simulation mapping (\$Defaults->{'CRASH_SIMULATION'}):\n$unmappedNamesString\n\n", 110 );
        return;
    }

    # remember data and params for next crash
    $lastCrashData_href   = $crashData_href;
    $lastSerializedParams = $serializedParams;

    S_w2log( 3, "CSI_GetCrashDataFromMDS: Getting crash data from MDS done.\n" );

    return $crashData_href;
}

sub CalculateCrashDuration {
    my $crashData_href = shift;

    my $stimulationSignals_href = $crashData_href->{'STIMULATION'}{'UNMAPPED'};

    my $longestDuration_ms = 0;
    foreach my $signal ( keys %{$stimulationSignals_href} ) {
        my $sampletime_ms = $stimulationSignals_href->{$signal}{'SAMPLETIME_US'} / 1000;
        my $data_aref     = $stimulationSignals_href->{$signal}{'SIGNALS'};
        next if ref($data_aref) ne 'ARRAY';
        my $duration_ms = $sampletime_ms * @$data_aref;
        if ( $duration_ms > $longestDuration_ms ) {
            $longestDuration_ms = $duration_ms;
        }
    }

    $crashData_href->{'METADATA'}{'CRASHDURATION_MS'} = $longestDuration_ms;
    return 1;
}

sub MapStimulationSignals {

    # map the stimulation signals to the section $mappingSection
    my $crashData_href              = shift;
    my $crashSimulationMapping_href = shift;
    my $mappingSection              = shift;

    my $sectionMapping_href = $crashSimulationMapping_href->{'STIMULATION'}{$mappingSection};
    return if not defined $sectionMapping_href;

    my @unmappedNames = keys %{ $crashData_href->{'STIMULATION'}{'UNMAPPED'} };
    foreach my $signalName ( keys %{$sectionMapping_href} ) {
        my $mappedSensorName = $sectionMapping_href->{$signalName};
        if ( grep { $_ eq $signalName } @unmappedNames ) {
            $crashData_href->{'STIMULATION'}{$mappingSection}{$signalName} = delete $crashData_href->{'STIMULATION'}{'UNMAPPED'}{$signalName};
            $crashData_href->{'STIMULATION'}{$mappingSection}{$signalName}{'DeviceName'} = $mappedSensorName;
        }
    }

    return 1;
}

############################################################################################################
#
#
# package LIFT_crash_simulation_QuaTe
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of CSI_* function and QuaTe_* function is not possible.

package LIFT_crash_simulation_QuaTe;

use strict;
use warnings;
use LIFT_general;
use LIFT_QuaTe;

sub CSI_LoadCrashSensorData2Simulator {
    my $crashData_href     = shift;
    my $modifySignals_href = shift;

    delete $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'};
    my $sensorData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'};

    if ( not defined $sensorData_href ) {
        S_w2log( 3, "INFO: No crash sensor data are defined for the current crash. Nothing will be downloaded to QuaTe.\n" );
        return 1;
    }

    # If QuaTe-Logger enabled: Indication inside each QuaTe logger file: Next Crash-Code name and used QuaTe-DLL-Version
    # else harmless
    QuaTe_SetTestName( $crashData_href->{'METADATA'}{'CRASHNAME'} );
    QuaTe_GetDLLVersion();    # return value not needed here, just writes function and parameters to QuaTe log file

    foreach my $sensorName ( keys %{$sensorData_href} ) {
        my $sensorDeviceName = $sensorData_href->{$sensorName}{'DeviceName'};
        my $deviceName       = $sensorDeviceName;
        my $channelName      = $sensorDeviceName;
        if ( $sensorDeviceName =~ /^\s*(.+)::(.+)\s*$/ ) {
            $deviceName  = $1;
            $channelName = $2;
        }
        my $data_aref       = $sensorData_href->{$sensorName}{'SIGNALS'};
        my $samplingTime_us = $sensorData_href->{$sensorName}{'SAMPLETIME_US'};
        FillChannelAssignmentData( $sensorName, $deviceName, $channelName, $samplingTime_us );
        if ( $samplingTime_us > 0 ) {
            $data_aref = LIFT_crash_simulation::ModifySignal( $sensorDeviceName, $data_aref, $modifySignals_href ) if defined $modifySignals_href;
        }
        my $success = QuaTe_DownloadData( $deviceName, $channelName, $data_aref, $samplingTime_us );
        return 0 if not $success;
    }

    LIFT_crash_simulation::PrintChannelAssignment( $LIFT_crash_simulation::channelAssignmentPerCrash_href, 'CRASH_SENSORS', \@channelAssignmentDataCrashSensors, "CSI ChannelAssignment per crash" );

    return 1;
}

sub CSI_TriggerCrash {

    # check and prepare hardware trigger for stimulation signals
    LIFT_crash_simulation_can_access::NwDynamics_stimulate_start_with_external_trigger();

    return QuaTe_SendControllerTrigger(0);
}

sub CSI_GetSensorProperties {

    my @sensorPropertyKeys;
    push( @sensorPropertyKeys, $SENSOR_PROPERTY_DEV_TYPE_INTERN );
    push( @sensorPropertyKeys, $SENSOR_PROPERTY_INPUT_BIT_WIDTH );
    push( @sensorPropertyKeys, $SENSOR_PROPERTY_CRASH_DEVICE );

    # get 'CRASH_SENSORS' from crash simulation mapping
    my $crashSimulationMapping_href = S_get_contents_of_hash( ['CRASH_SIMULATION'] );
    if ( not defined $crashSimulationMapping_href ) {
        S_set_error( "Section 'CRASH_SIMULATION' is not defined in project constants.", 114 );
        return ( undef, \@sensorPropertyKeys );
    }
    my $crashSensorMapping_href = $crashSimulationMapping_href->{'STIMULATION'}{'CRASH_SENSORS'};

    my %sensorProperties;
    foreach my $crashSensor ( sort keys %{$crashSensorMapping_href} ) {
        my $sensorSimulatorName = $crashSensorMapping_href->{$crashSensor};
        my $deviceName          = $sensorSimulatorName;
        my $channelName         = $sensorSimulatorName;
        if ( $sensorSimulatorName =~ /^\s*(.+)::(.+)\s*$/ ) {
            $deviceName  = $1;
            $channelName = $2;
        }
        my $quaTeDeviceProperties_href = QuaTe_GetDeviceProperties_NOERROR( $deviceName, $channelName );
        my $devTypeIntern_Val          = 0;
        my $inputBitWidth_Val          = 0;
        if ($quaTeDeviceProperties_href) {
            $devTypeIntern_Val = $quaTeDeviceProperties_href->{$SENSOR_PROPERTY_DEV_TYPE_INTERN};
            $inputBitWidth_Val = $quaTeDeviceProperties_href->{$SENSOR_PROPERTY_INPUT_BIT_WIDTH};
        }
        else {
            # Error already handled and reported by QuaTe_GetDeviceProperties
        }
        $sensorProperties{$crashSensor}{$SENSOR_PROPERTY_DEV_TYPE_INTERN} = $devTypeIntern_Val;
        $sensorProperties{$crashSensor}{$SENSOR_PROPERTY_INPUT_BIT_WIDTH} = $inputBitWidth_Val;
        $sensorProperties{$crashSensor}{$SENSOR_PROPERTY_CRASH_DEVICE}    = 1;                    # digital QuaTe
    }

    my $networkDynamicMapping_href = $crashSimulationMapping_href->{'STIMULATION'}{'NETWORK_DYNAMIC'};

    foreach my $networkDynamic ( sort keys %{$networkDynamicMapping_href} ) {
        $sensorProperties{$networkDynamic}{$SENSOR_PROPERTY_DEV_TYPE_INTERN} = 0;
        $sensorProperties{$networkDynamic}{$SENSOR_PROPERTY_INPUT_BIT_WIDTH} = 0;
        $sensorProperties{$networkDynamic}{$SENSOR_PROPERTY_CRASH_DEVICE}    = 2;                 # Bus
    }

    return ( \%sensorProperties, \@sensorPropertyKeys );
}

sub FillChannelAssignmentData {
    my $sensorName      = shift;
    my $deviceName      = shift;
    my $channelName     = shift;
    my $samplingTime_us = shift;

    S_w2log( 3, "\nINFO: FillChannelAssignmentData - START\n" );

    my @headerNames = @LIFT_crash_simulation::channelAssignmentDataCrashSensors;

    # remove 'MDS channel', 'Device name' from @headerNames
    shift @headerNames;
    shift @headerNames;

    my $zeroEmulation = 'ZERO-Emulation';
    my $nothing       = '-';

    $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'}{$sensorName}{'Device name'}  = $deviceName;
    $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'}{$sensorName}{'Channel name'} = $channelName;

    my $sensorChannel_href = $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'}{$sensorName};

    # get data from Quate mapping
    my $quateMapping_href = $main::ProjectDefaults->{'QUATE'};
    if ( not defined $quateMapping_href ) {
        S_set_error( "Section 'QUATE' (QuaTe mapping) is not defined in project constants.", 114 );
        return;
    }

    # loop over all elements in quate mapping and get the necessary data for the channel assignment overview
    foreach my $quate ( keys %{$quateMapping_href} ) {
        foreach my $deviceID ( keys %{ $quateMapping_href->{$quate}{'DEVICES'} } ) {
            my $mappingDeviceName = $quateMapping_href->{$quate}{'DEVICES'}{$deviceID}{'DEVICE_NAME'};
            my $mappingROMfile    = $quateMapping_href->{$quate}{'DEVICES'}{$deviceID}{'ROM_FILE'};
            foreach my $channelID ( keys %{ $quateMapping_href->{$quate}{'DEVICES'}{$deviceID}{'CHANNELS'} } ) {
                my $mappingChannelName = $quateMapping_href->{$quate}{'DEVICES'}{$deviceID}{'CHANNELS'}{$channelID}{'CHANNEL_NAME'};
                if ( $deviceName eq $mappingDeviceName and $channelName eq $mappingChannelName ) {
                    $sensorChannel_href->{'Channel index'} = $channelID;
                    $sensorChannel_href->{'ROM file'}      = $mappingROMfile;
                    my ( $deviceDescription, $deviceVersion ) = QuaTe_GetDeviceDescription( $deviceName, $channelName );
                    $sensorChannel_href->{'Quate device description'} = $deviceDescription;
                    $sensorChannel_href->{'Firmware'}                 = $quateMapping_href->{$quate}{'FIRMWARE'};

                    # QuaTe chip select
                    my ( $chipSelect, $isEnabled ) = QuaTe_GetChipSelectByDeviceName($deviceName);
                    $sensorChannel_href->{'Quate chip select'} = $chipSelect;

                    # QuaTe port
                    my $port = QuaTe_GetPSIPortByDeviceName($deviceName);
                    $sensorChannel_href->{'Quate port'} = $port;

                    # QuaTe index and device index
                    my ( $quateIndex, $deviceIndex ) = QuaTe_GetIndexFromDevice($deviceName);
                    $sensorChannel_href->{'Quate index'}  = $quateIndex;
                    $sensorChannel_href->{'Device index'} = $deviceIndex;

                    # copy data from channelAssignmentPerCrash_href to channelAssignmentOverall_href
                    @{ $LIFT_crash_simulation::channelAssignmentOverall_href->{'CRASH_SENSORS'}{$sensorName} }{ keys %{$sensorChannel_href} } = values %{$sensorChannel_href};

                    # handle zero emulation channels (only for channelAssignmentPerCrash_href)
                    if ( $samplingTime_us <= 0 ) {
                        $sensorChannel_href->{'Device name'} = $zeroEmulation;
                        foreach my $headerName (@headerNames) {
                            $sensorChannel_href->{$headerName} = $nothing;
                        }
                    }
                    S_w2log( 3, "\nINFO: FillChannelAssignmentData return 1 - END\n" );
                    return 1;
                }
            }
        }
    }
    my $unmapped = 'not in mapping';
    foreach my $headerName (@headerNames) {
        $sensorChannel_href->{$headerName} = $unmapped;
    }

    S_w2log( 3, "\nINFO: FillChannelAssignmentData return 0 - END\n" );

    return 0;
}

############################################################################################################
#
#
# package LIFT_crash_simulation_can_access
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of CSI_* function and CA_* function is not possible.

package LIFT_crash_simulation_can_access;

use strict;
use warnings;
use LIFT_general;
use LIFT_can_access;

my $NwDynamics_SignalsPresent = 0;

sub CSI_LoadNetworkDynamicData2Simulator {
    my $crashData_href     = shift;
    my $modifySignals_href = shift;

    delete $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'NETWORK_DYNAMIC'};
    my $mdsNetworkData_href = $crashData_href->{'STIMULATION'}{'NETWORK_DYNAMIC'};

    if ( not defined $mdsNetworkData_href ) {
        S_w2log( 3, "INFO: No network dynamic data are defined for the current crash. Nothing will be downloaded to the CAN tool.\n" );
        return 1;
    }

    # create mds independent data structure and channel assignment overview
    my $networkData_href;
    foreach my $mdsSignal ( keys %{$mdsNetworkData_href} ) {

        # create mds independent data structure for passing to CA_ functions
        my $busSignal = $mdsNetworkData_href->{$mdsSignal}{'DeviceName'};
        $networkData_href->{$busSignal}{'SAMPLETIME_US'} = $mdsNetworkData_href->{$mdsSignal}{'SAMPLETIME_US'};
        $networkData_href->{$busSignal}{'SIGNALS'}       = $mdsNetworkData_href->{$mdsSignal}{'SIGNALS'};

        # build up $channelAssignment_href for network
        $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'NETWORK_DYNAMIC'}{$mdsSignal} = {};
        my $sensorChannel_href = $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'NETWORK_DYNAMIC'}{$mdsSignal};
        $sensorChannel_href->{'Signal'}    = $busSignal;
        $sensorChannel_href->{'Frame/PDU'} = GetFramePDUfromSignal($busSignal);
        @{ $LIFT_crash_simulation::channelAssignmentOverall_href->{'NETWORK_DYNAMIC'}{$mdsSignal} }{ keys %{$sensorChannel_href} } = values %{$sensorChannel_href};
        if ( $mdsNetworkData_href->{$mdsSignal}{'SAMPLETIME_US'} <= 0 ) {
            $sensorChannel_href->{'Signal'}    = '-';
            $sensorChannel_href->{'Frame/PDU'} = 'ZERO-Emulation';
        }
    }

    # set flag if Network dynamics signals are present, will be used later
    $NwDynamics_SignalsPresent = 1;

    # reset signal curves
    CA_stimulate_reset_signal_curves();

    # get the trigger type configured
    my $triggertype = LIFT_crash_simulation::GetConfiguredTrigger();
    S_w2log( 3, "CSI_LoadNetworkDynamicData2Simulator : used trigger is $triggertype.\n" );

    my $data_aref;
    my $modifiedData_aref;

    if ( defined $modifySignals_href ) {

        foreach my $signal_curve_name ( keys %{$networkData_href} ) {
            if ( defined $signal_curve_name && $networkData_href->{$signal_curve_name}{'SAMPLETIME_US'} > 0 ) {

                $data_aref = $networkData_href->{$signal_curve_name}{'SIGNALS'};
                $modifiedData_aref = LIFT_crash_simulation::ModifySignal( $signal_curve_name, $data_aref, $modifySignals_href );

                $networkData_href->{$signal_curve_name}{'SIGNALS'} = $modifiedData_aref;
            }
        }
    }

    # configure the signals
    CA_stimulate_load_signal_curves( $networkData_href, $triggertype );

    LIFT_crash_simulation::PrintChannelAssignment( $LIFT_crash_simulation::channelAssignmentPerCrash_href, 'NETWORK_DYNAMIC', [ 'MDS channel', 'Frame/PDU', 'Signal' ], "CSI ChannelAssignment per crash" );

    return 1;
}

sub CSI_TriggerCrash {

    return CA_stimulate_start_now();
}

sub NwDynamics_stimulate_start_with_external_trigger {

    if ($NwDynamics_SignalsPresent) {
        S_w2log( 4, "NwDynamics_stimulate_start_with_external_trigger : Hardware trigere configured.\n" );
        return CA_stimulate_start_with_external_trigger();
    }

    return 1;
}

sub GetFramePDUfromSignal {
    my $signal = shift;

    my $framePDU;
    my $mapping = $main::ProjectDefaults->{'Mapping_CAN'};
    if ( defined $mapping->{$signal} ) {
        $framePDU = $mapping->{$signal}{'MESSAGE'};
        return $framePDU if defined $framePDU;
    }
    $mapping = $main::ProjectDefaults->{'Mapping_FLEXRAY'};
    if ( defined $mapping->{$signal} ) {
        $framePDU = $mapping->{$signal}{'FR_PDU_NAME'};
        return $framePDU if defined $framePDU;
        $framePDU = $mapping->{$signal}{'FR_FRAME_NAME'};
        return $framePDU if defined $framePDU;
    }
    return 'not in mapping';
}

############################################################################################################
#
#
# package LIFT_crash_simulation_SPI_SensorSimulation
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of CSI_* function and SPI_SensorSimulation_* function is not possible.

package LIFT_crash_simulation_SPI_SensorSimulation;

use strict;
use warnings;
use LIFT_general;
use FuncLib_SPI_SensorSimulation;
use List::Util qw( min max );
use JSON::PP;
use File::Slurp;

sub CSI_GetCrashDataFromMDS {

    my $crashIdentifyParams_href = shift;
    my $sensorProperties_href    = shift;
    my $sensorPropertyKeys_aref  = shift;

    #STEP validate input parameters
    if ( $crashIdentifyParams_href->{'RESULTDB'} !~ /(.*)(\.zip)/ ) {
        my $error_text = "Input data base format" . $crashIdentifyParams_href->{'RESULTDB'} . "not supported! Supported data base format is (.zip) for crash_database of type 'SPI_SensorSimulation'";
        S_set_error( "CSI_GetCrashDataFromMDS: $error_text ", 109 );
        return;
    }

    if ( $crashIdentifyParams_href->{'MDSTYPE'} ne 'SPISIM' ) {
        my $error_text = "MDS type configured" . $crashIdentifyParams_href->{'MDSTYPE'} . "is wrong! valid type is 'SPISIM' for crash_database of type 'SPI_SensorSimulation'";
        S_set_error( "CSI_GetCrashDataFromMDS: $error_text ", 109 );
        return;
    }

    unless ( defined $crashIdentifyParams_href->{'CRASHNAME'} ) {
        S_set_error( "CSI_GetCrashDataFromMDS: 'CRASHNAME' not defined! ", 109 );
        return;
    }
    my $crash_database = $crashIdentifyParams_href->{'RESULTDB'};

    S_w2log( 3, "CSI_GetCrashDataFromMDS: Getting crash data for crash '$crashIdentifyParams_href->{'CRASHNAME'}' from '$crash_database' started.\n" );

    #STEP unzip database file and read crash data JSON file
    my $zip_handle = S_open_zip("$crash_database");
    unless ($zip_handle) {
        S_set_error( "CSI_GetCrashDataFromMDS: Could not open database '$crash_database'", 109 );
        return;
    }
    my $stored_path = $crash_database;
    $stored_path =~ s/(.*)(\\|\/)(.*\.zip)/$1/;    # extract folder path containing zip file.
    my $filename = $crashIdentifyParams_href->{'CRASHNAME'} . ".json";
    my @files    = ($filename);
    S_get_from_zip( $zip_handle, "$stored_path", @files );
    $filename = $stored_path . '\\' . $filename;
    my $file_content = read_file($filename);

    unless ($file_content) {
        S_set_error( "CSI_GetCrashDataFromMDS: No crash data found in crashfile '$filename'", 109 );
        return;
    }

    #STEP transfer data from json file to $crashData_href
    my $crashData_href = {};
    my $decodeCommand  = 'my $eval = decode_json($file_content)';
    $crashData_href = eval $decodeCommand;

    unless ($crashData_href) {
        S_set_error( "CSI_GetCrashDataFromMDS: $@", 109 );
        return;
    }

    unlink $filename;
    S_w2log( 3, "CSI_GetCrashDataFromMDS: Getting crash data for crash '$crashIdentifyParams_href->{'CRASHNAME'}' from '$crash_database' completed.\n" );

    #STEP return $crashData_href
    return $crashData_href;
}

sub CSI_LoadCrashSensorData2Simulator {

    my $crashData_href     = shift;
    my $modifySignals_href = shift;

    S_w2log( 3, "CSI_LoadCrashSensorData2Simulator: Uploading crash data to ManiToo started.\n" );

    #STEP If crash_database is 'SPI_SensorSimulation' upload data in SPISIM format to manitoo
    if ( exists( $crashData_href->{'STIMULATION'}{'CRASH_SENSORS_SPI_SensorSimulation'} ) ) {
        SpiSim_upload_crash_data($crashData_href);
    }

    #STEP If crash_database is 'MDSRESULT' and crash_sensors is 'SPI_SensorSimulation', prepare crash data in SPISIM format and upload to manitoo
    else {
        delete $LIFT_crash_simulation::channelAssignmentPerCrash_href->{'CRASH_SENSORS'};
        my $sensorData_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS'};
        if ( not defined $sensorData_href ) {
            S_w2log( 3, "INFO: No crash sensor data are defined for the current crash. Nothing will be downloaded to SPI_SensorSimulation.\n" );
            return 1;
        }
        S_w2log( 3, "INFO: crash data will be converted to SPI_SensorSimulation format and will be downloaded to SPI_SensorSimulation.\n" );
        my $collect_crash_data_href = LIFT_crash_simulation::Fill_spi_channel_and_signal_details( $sensorData_href, $modifySignals_href );
        return unless ( SPISIM_PrepareCrashData( $collect_crash_data_href, $crashData_href ) );
        return unless ( SpiSim_upload_crash_data($crashData_href) );
    }
    S_w2log( 3, "CSI_LoadCrashSensorData2Simulator: Uploading crash data to ManiToo completed.\n" );

    return 1;
}

=head2 SpiSim_upload_crash_data

    1 = SpiSim_upload_crash_data( $crashData_href );
    
Uploads crash data in format 'SPI_SensorSimulation' to Manitoo.

B<Arguments:>

=over

=item $crashData_href

Output of function 'SPISIM_PrepareCrashData'.

=back

B<Return Value:>

    Returns 1 on success.

    undef on error.

=cut

sub SpiSim_upload_crash_data {

    my @args = @_;
    return unless S_checkFunctionArguments( 'SpiSim_upload_crash_data( $crashData_href )', @args );

    my $crashData_href         = shift;
    my $spisim_crash_data_href = $crashData_href->{'STIMULATION'}{'CRASH_SENSORS_SPI_SensorSimulation'};

    #LOOP-START loop over all sensors which has crsah data
    foreach my $sensorName ( keys %{$spisim_crash_data_href} ) {

        my $options_href = {
            'Node'      => $spisim_crash_data_href->{$sensorName}{node},
            'Command'   => $spisim_crash_data_href->{$sensorName}{spi_cmd},
            'Signal'    => $spisim_crash_data_href->{$sensorName}{spi_signal},
            'CrashData' => $spisim_crash_data_href->{$sensorName}{spi_data_aref},
        };
        my $checkfor_valid_crash_data_aref = $spisim_crash_data_href->{$sensorName}{spi_data_aref};

        # load only channels which has crash data
        my $number_matches = grep { $_ ne '0000' } @$checkfor_valid_crash_data_aref;
        if ( $number_matches > 5 ) {    # data samples more than 5 is chosen because data coming from mds has some filtered data
                                        #CALL SPISIM_UploadCrashData for each sensor channel
            return unless ( SPISIM_UploadCrashData($options_href) );
        }
    }

    #LOOP-END last sensor
    return 1;
}

sub CSI_TriggerCrash {

    #CALL SPISIM_TriggerCrash to start crash injection using SPI manipulation
    return unless ( SPISIM_TriggerCrash() );
    return 1;
}

sub CSI_GetSensorProperties {

    my @sensorPropertyKeys;
    push( @sensorPropertyKeys, 'DEV_TYPE_INTERN' );
    push( @sensorPropertyKeys, 'INPUT_BIT_WIDTH' );
    push( @sensorPropertyKeys, $SENSOR_PROPERTY_CRASH_DEVICE );

    # get 'CRASH_SENSORS' from crash simulation mapping
    my $crashSimulationMapping_href = S_get_contents_of_hash( ['CRASH_SIMULATION'] );
    if ( not defined $crashSimulationMapping_href ) {
        S_set_error( "Section 'CRASH_SIMULATION' is not defined in project constants.", 114 );
        return ( undef, \@sensorPropertyKeys );
    }
    my $crashSensorMapping_href = $crashSimulationMapping_href->{'STIMULATION'}{'CRASH_SENSORS'};

    my $spi_mapping_details_href = S_get_contents_of_hash( ['Mapping_SPI'] );

    my %sensorProperties;
    foreach my $crashSensor ( sort keys %{$crashSensorMapping_href} ) {
        my $sensorSimulatorName = $crashSensorMapping_href->{$crashSensor};
        my $deviceName          = $sensorSimulatorName;
        my $channelName         = $sensorSimulatorName;
        if ( $sensorSimulatorName =~ /^\s*(.+)::(.+)\s*$/ ) {
            $deviceName  = $1;
            $channelName = $2;
        }
        my $devTypeIntern_Val = 0;

        $sensorProperties{$crashSensor}{'DEV_TYPE_INTERN'} = 0;
        if ( exists $spi_mapping_details_href->{$deviceName}{'Channels'}{$channelName}{COMPLETE_DATA_WIDTH_IN_BITS} ) {
            $sensorProperties{$crashSensor}{'INPUT_BIT_WIDTH'} = $spi_mapping_details_href->{$deviceName}{'Channels'}{$channelName}{COMPLETE_DATA_WIDTH_IN_BITS};
        }
        else {
            S_set_error( "CSI_GetSensorProperties: sensor property 'COMPLETE_DATA_WIDTH_IN_BITS' not found for channel '$channelName' in sensor $deviceName\n", 0 );
        }

        $sensorProperties{$crashSensor}{$SENSOR_PROPERTY_CRASH_DEVICE} = 1;

    }

    my $networkDynamicMapping_href = $crashSimulationMapping_href->{'STIMULATION'}{'NETWORK_DYNAMIC'};

    foreach my $networkDynamic ( sort keys %{$networkDynamicMapping_href} ) {
        $sensorProperties{$networkDynamic}{'DEV_TYPE_INTERN'}             = 0;
        $sensorProperties{$networkDynamic}{'INPUT_BIT_WIDTH'}             = 0;
        $sensorProperties{$networkDynamic}{$SENSOR_PROPERTY_CRASH_DEVICE} = 2;
    }

    return ( \%sensorProperties, \@sensorPropertyKeys );
}

1;
__END__

 
