#*****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_spi_access;

use strict;
use warnings;
use LIFT_general;
use LIFT_numerics;
use LIFT_evaluation;
use LIFT_functional_layer;
use LIFT_spi_database;
use LIFT_spi_instruction_set;
use Data::Dumper;
use XML::LibXML;
require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  SPI_init
  SPI_exit
  SPI_load_signal_manipulation
  SPI_load_pretrigger_module
  SPI_load_manipulation_set
  SPI_start_manipulation
  SPI_stop_manipulation
  SPI_verify_manipulation_counter
  SPI_get_manipulation_counter
  SPI_trace_start
  SPI_trace_stop
  SPI_trace_store
  SPI_trace_load_file
  SPI_trace_get_dataref
  SPI_logicanalyzer_start
  SPI_logicanalyzer_stop
  SPI_logicanalyzer_store
  SPI_EVAL_check_command_sequence
  SPI_load_invalid_CRC
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_spi_access 

=head1 SYNOPSIS

    use LIFT_spi_access;
   
    1. manipulating signal
    
    # Initilaise SPI
    
    SPI_init();
    
    # Initializes all devices configured in testbench config under function 'SPI_Access'.

    # Initializes database for signal based SPI testing.

    # Input for database is the project path of the SPIMaid project.
    
    SPI_load_invalid_CRC( 'Node'=>'SMI7xx' );

    # loads invalid crc value for the signal defined with name CRC (default name considered) 
    # in SPI_Maid project
    
    
    SPI_load_invalid_CRC( 'Node'=>'SMI7xx', 'Signal' => 'CRC/TF' );

    # loads invalid crc value for the signal defined with name 'CRC/TF' in SPI_Maid project
    
    SPI_load_signal_manipulation ( 'Node'=>'SMA660_M',
                                   'Command' => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'=>'data_CH2',
                                   'SignalValue' => '10'
                                   'FrameCycles' => '100'
                                   );

    # load signal value 10 to the Signal 'data_CH2' of the command 'RD_SENSOR_DATA_CH2_CAP'
    #   for 100 frames.
    
    SPI_start_manipulation();
    
    # starts manipulation of loaded signals/commands.
    
    S_wait_ms(4000);

    SPI_stop_manipulation(); #stops manipulation of loaded signals/commands.

    my $all_mani_counter_href = SPI_get_manipulation_counter();
    
    SPI_exit();
    
    # Destroys the the database object initialised.

        
    2. Trace functionality


    2.1 Trace device chosen as Manitoo
    
    # measure ALL SPI devices which are configured in Mapping_SPI_network.pm

    SPI_trace_start( );  
    
    #   or 
    # measure the given SPI devices which are configured in Mapping_SPI_network.pm

    SPI_trace_start( [ 'Cobra_Main' , 'Cobra_Plausi' , 'SMA660' ] );   

    #   or 
    #  trace configuration SPI bus number and chip select 
    #    SPI=1 CS=0  + SPI=1 CS=1 + SPI=1 CS=2

    SPI_trace_start( [ '1:0'  , '1:1' , '1:2' ] );   
    
    #
    #   do some SPI manipulations here
    #
    
    SPI_trace_stop();

    # default trace will be stored in the reports folder
    SPI_trace_store( );

    #   or
    # only file name passed as argument, will be stored the reports folder

    SPI_trace_store('SPI_Trace.mbt');

    #   or
    # Full file path passed as argument, will be stored the respective path

    SPI_trace_store('D:/Turbolift/trace/SPI_TRACE.mbt');

    2.2 Trace device chosen as SPIMaid
    
    # Load the trace file by giving a measurement label and complete trace file path 
    
    SPI_trace_load_file('MeasurementLabel' => 'Measurement_SMI7', # unique measurement label
                        'FileName' => 'C:\\AB12\\AB12_SPI_Record_B50_TestZip\\150331_151550.dat');
                        
    # Get data from the trace file
    
    my $measurement_data_href = SPI_trace_get_dataref( 'MeasurementLabel' => 'Measurement_SMI7',
                                            'SPI_Node' => 'SMI7',
                                            'StartTime_ms' => '3581',
                                            'EndTime_ms' => '3583' ); 
                                            
    # Evaluate command sequence
    SPI_EVAL_check_command_sequence(
                                    'MeasurementData_href' => $measurement_data_href,
                                    'CommandList' => ['READ_LF_ACC2__DATA__SMI700_2', 
                                                      'READ_LF_ACC1__CURRENT_DATA__SMI700_2', 
                                                      'READ_HF_ACC2__CURRENT_DATA__SMI700_2'] 
                                   );



    3. logicanalyzer functionality


    # Parameters configured in 'Mapping_LA_AcuteTravelLogic.pm'
    SPI_logicanalyzer_start();

    # Parameters passed as arguments to function directly
    SPI_logicanalyzer_start( { 'pinNames' => ['21_MOSI1', '22_MISO1_ASIC', 'MISO1_CPU', 
                                     '14_SCK_1', '24_CONTROL_MUX', '20_CS0_COBRA_M'],
                      'triggerPinName'      => '24_CONTROL_MUX',
                      'triggerEdge'         => 'rising',
                      'hwMode'              => 'HW_200M_36CH',
                      'numSamples_perCh'    => 2000,
                      'postTriggerSize_pct' => 90  } );
    
    SPI_logicanalyzer_stop();

    # default logicanalyzer measurement will be stored in the reports folder
    SPI_logicanalyzer_store('SPI_logicanalyzer_dump.law');



LIFT_spi_access functions:
    
    SPI_init
    SPI_load_signal_manipulation
    SPI_load_invalid_CRC
    SPI_load_frame_manipulation    # not implemented yet
    SPI_load_manipulation_set      # not implemented yet
    SPI_start_manipulation
    SPI_stop_manipulation
    SPI_verify_manipulation_counter
    SPI_get_manipulation_counter
    SPI_trace_configure            # not implemented yet
    SPI_trace_start
    SPI_trace_stop
    SPI_trace_store
    SPI_trace_load_file
    SPI_trace_get_dataref
    SPI_logicanalyzer_start
    SPI_logicanalyzer_stop
    SPI_logicanalyzer_store
    SPI_get_signal_info            # not implemented yet
    SPI_get_frame_info             # not implemented yet
    SPI_calc_hex_to_phys           # not implemented yet
    SPI_calc_phys_to_hex -- till V1 phase   # not implemented yet
    SPI_EVAL_check_command_sequence
 
=head1 DESCRIPTION

This is a wrapper module for ManiToo and SPI maid devices.

This wrapper module is a functional layer.

    CFG file :
    require "$LIFT_PRJCFG_path/Mappings/Mapping_SPI_network.pm";  # contains package LIFT_PROJECT

=head2 Testbench Configuration

$Testbench={

  'localhost' => {      # LIFT PC host name
    'Devices' => {
        'Manitoo' => {
             'Description' => "only for Manitoo testing ",   # only for logging purpose
             'Connection_Type' => 'COM1' ,
                # Supported types 'COM<PORT_NUMBER>', 'USB'
                # COM<PORT_NUMBER> : COM port detected when connected to TestPC
                # USB : USB-A to USB-A connector.
                # Drivers needs to be installed for this : refer link
                # https://inside-docupedia.bosch.com/confluence/display/MOBIT/Setup+USB+connection+for+mobiTOOL
        },
    },
    'Functions' => {
        ### --- Function Area : SPI_Access, select device used for trace / manipulate
        # currently no alternative configuration possible
        # function groups: trace, manipulate, logicanalyzer
        'SPI_Access' => {
           'manipulate'    => 'Manitoo', # possible devices only Manitoo
           'trace'         => 'Manitoo', # possible devices Manitoo or SPIMaid (manual start/stop only)
           'logicanalyzer' => 'LA_AcuteTravelLogic', # possible devices only LA_AcuteTravelLogic
        },
    },

  },

};


=cut

# In this data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.

my $functionMapping_href = {
    'trace' => {
        'SPIMaid' => {
            'SPI_trace_start'     => 'MAID_trace_start',
            'SPI_trace_stop'      => 'MAID_trace_stop',
            'SPI_trace_load_file' => 'MAID_trace_load_file',
        },

        'Manitoo' => {
            'SPI_trace_start'     => 'LIFT_manitoo::MANITOO_trace_start',
            'SPI_trace_stop'      => 'LIFT_manitoo::MANITOO_trace_stop',
            'SPI_trace_store'     => 'LIFT_manitoo::MANITOO_trace_store',
            'SPI_trace_load_file' => 'LIFT_manitoo::MANITOO_trace_load_file',
        },
        'NONE' => {
            'SPI_trace_start' => 'None',
            'SPI_trace_stop'  => 'None',
        }
    },

    'logicanalyzer' => {
        'LA_AcuteTravelLogic' => {
            'SPI_logicanalyzer_start' => 'LATL_StartMeasurement',
            'SPI_logicanalyzer_stop'  => 'LATL_StopMeasurement',
            'SPI_logicanalyzer_store' => 'LATL_plot_values',
        },
    },

    'manipulate' => {
        'Manitoo' => {
            'SPI_start_manipulation'       => 'LIFT_manitoo::MANITOO_start',
            'SPI_stop_manipulation'        => 'LIFT_manitoo::MANITOO_stop',
            'SPI_load_signal_manipulation' => 'tbd',
            'SPI_load_frame_manipulation'  => 'tbd',
            'SPI_load_manipulation_set'    => 'tbd',
        },
        'NONE' => {
            'SPI_start_manipulation' => 'None',
            'SPI_stop_manipulation'  => 'None',
        }
    },
};

my @availableTestbenchFunctionGroups = qw{ trace manipulate logicanalyzer};
my $spiDatabase_Object;
my $spiInstructionSet_object;
my $loadedMeasurements_href;
my $INIT_FLAG = 0;
my $mappingNetworkSPI;
my $MANIPULATION_COUNTER_HREF;    # used as intermediate storage of manipuluation counters

=head1 Function Group 'base'

=head2 SPI_init

    SPI_init();
    
Initializes all devices configured in testbench config under function 'SPI_Access'.

Initializes database for signal based SPI testing.

Input for database is the project path of the SPIMaid project.

The SPIMaid project contains decoding information for all commands and signals supported in the project.

B<Arguments:> None

B<Returns:> Initialization status.

B<Notes:> This function has to be called in the init campaign.

=cut

sub SPI_init {

    #STEP get contents of Mapping_SPI
    #STEP return error if Mapping_SPI not found or not defined
    #STEP Initialise the SPI database

    if ( $INIT_FLAG == 1 ) {
        S_set_warning("SPI Access already initialised, Nothing done!\n");
        return 1;
    }

    # initialization only required if not yet done
    unless ( defined $spiDatabase_Object ) {
        $mappingNetworkSPI = S_get_contents_of_hash( ['Mapping_SPI'] );
        unless ($mappingNetworkSPI) {
            S_set_error( "SPI_init : SPI mapping is mandatorily required for SPI initialization.\n" . "Get SPI mapping template from TurboLIFT template project and fill according to project configuration!\n", 110 );
            return;
        }
        S_w2log( 2, "\n Initialize SPI data base\n" );
        $spiDatabase_Object = LIFT_spi_database->new();
    }

    #STEP Initialise the Devices and Functions section configured for SPI_Access in test bench
    FL_Init( 'SPI_Access', $functionMapping_href, \@availableTestbenchFunctionGroups );

    unless ( $VERDICT eq 'VERDICT_PASS' or $VERDICT eq 'VERDICT_NONE' ) {
        S_set_error("SPI_init: SPI init not successfull!");
        $INIT_FLAG = 0;
        return;
    }
    $INIT_FLAG = 1;
    return 1;
}

=head2 SPI_Exit

    SPI_Exit()

B<Description: > Destroys the database object initialised.

=cut

sub SPI_exit {

    return unless ( Check_init() );

    S_w2log( 2, "\n SPI_exit: destroy database\n" );
    $spiDatabase_Object = undef;
    S_w2log( 2, "\n SPI_exit: destroy instruction set\n" );
    $spiInstructionSet_object = undef;
    $INIT_FLAG                = 0;
    return 1;
}

=head2 SPI_get_signal_info

    SPI_get_signal_info ('RATE_LF');

B<To be implemented>

=cut

sub SPI_get_signal_info {
    my $signal_name = shift;

    return 1;
}

=head2 SPI_get_frame_info

    SPI_get_frame_info

B<To be implemented>

=cut

sub SPI_get_frame_info {
    return 1;
}

=head2 SPI_calc_hex_to_phys

    SPI_calc_hex_to_phys

B<To be implemented>

=cut

sub SPI_calc_hex_to_phys {
    return 1;
}

=head2 SPI_calc_phys_to_hex

    SPI_calc_phys_to_hex

B<To be implemented>

=cut

sub SPI_calc_phys_to_hex {
    return 1;
}

=head1 Function Group 'manipulate'

=head2 SPI_load_signal_manipulation

    (all function args are listed here - different combinations are possible - depending from use-case)

    SPI_load_signal_manipulation( 'Node'                 => $nodeName, 
                                  'SMI7_Module'          => $smi7module,
                                  'SMI7_Page'            => $smi7page,
                                  'Command'              => $commandName,
                                  'Signal'               => $signalName,
                                  'SignalValues'         => $values_aref,
                                  'SignalValue'          => $staticSigVal,
                                  'Duration_us'          => $staticSignalDuration,# use micro-sec 
                                  'Duration_ms'          => $staticSignalDuration,# or milli-sec     
                                  'TimeUnit'             => $time_unit_string ,   # ms||us||s  'ms' is default 
                                  'SignalTimesValues'    => $valueDataSamples_href,
                                  'FrameCycles'          => $frames_mix,
                                  'PreTriggers'          => $preTriggerNames_aref #optional
                                  'Signals_and_Values'   => $signals_and_values_href,
                                  'Signals_Times_Values' => $signals_times_values_href );
 
B<Description>: This function loads the values for the signals to the ManiToo.
 
B<Arguments:>

=over

=item 'Node' ( $nodeName )

Node name for which the signal has to be manipulated.

=item 'Command' ( $commandName )

Command name which has to be manipulated.

=item 'Signal' ( $signalName )

Signal name which has to be manipulated.

=item  'SignalValue' ( $staticSigVal )

Static value to be written all through the write cycle.
To be used with any timing info : 'Duration_ms' or 'Duration_us' or 'FrameCycles'
Without timing info it es infinite manipulation 

Allows two formats

1. value to be written
    e.g : 'SignalValue' => '0x7' (hexvalue)
          'SignalValue' => '7'  (decimal)
          
2. existing signal value to be inverted
    e.g :  'SignalValue' => 'invert'

=item 'SignalValues' ( $values_aref )

values to be written to the signal in B<SPI_MODE>.  To be combined with 'FrameCycles'.

offers two formats

1. hex format : example : 'SignalValues' => ['0x4', '0xA', '0xB']
2. dec format : example : 'SignalValues' => ['4', '9', '12']


=item 'Duration_ms' or 'Duration_us' ( $staticSignalDuration )

(Optional)Duration in milli-sec or micro-sec till the manipulation should continue.
To be used only with 'SignalValue' => $staticSigVal !


=item 'FrameCycles' ( $frames_mix )

The number of frames to which the particular signal value has to be written.
If only only one value has to be then it should be configured as SCALAR, 
else if multiple it should be configured as aref.

  Nbr of frame cycles for one 'SignalValue' : integer 
  Nbr of frame cycles for muliple 'SignalValues' : [ <frames_for_value_1> , .. , <frames_for_value_n> ,  ] 

=item 'SignalTimesValues' ( $valueDataSamples_href )

values to be written to the signal in B<TIMER_MODE>

Allows value to configure in two formats:

1. hex format : example : 'SignalTimesValues' => [ 0 => '0x4', 2000 => '0xA', 4000 => '0xB']
                                                  (ms)        (ms)          (ms)
                                                  
2. dec format : example : 'SignalTimesValues' => [ 0 => '4', 2000 => '10', 4000 => '12']
                                                  (ms)        (ms)          (ms)


Allows time in three different formats using the parameter 'TimeUnit': 

=item 'TimeUnit' ( $time_unit_string )

B<(default 'ms' is considerd if parameter 'TimeUnit' not configured)>

1. Milli seconds : 'ms'.  -> 'TimeUnit' => 'ms' 
2. Micro second  : 'us'.  -> 'TimeUnit' => 'us'
3. Seconds       : 's'.   -> 'TimeUnit' => 's'


B<GENERAL NOTES:> 

1. 'stop_manipulaion' should be configured to stop the manipulation.

    e.g. 'SignalTimesValues' => [ 0 => '4', 2000 => '10', 4000 => 'stop_manipulation'].
    
2. At least any one of the mode should be configured. Not B<BOTH> Not B<NONE>

3. 'Duration_ms' (or 'Duration_us') and 'FrameCycles' should not be configured together. Only any B<one> or B<none>. 
    both these two parameters are only for static value

4. Do not combine binary format of signal values configuration with hex or dec format.

=item $SMI7_Module

(optional) SMI7 module for the respective sensor.

=item $smi7page

(optional) SMI7 page for the respective SMI7 module.

B<NOTE:> If configured, Both SMI7 module and SMI7 page should be configured. B<Not only one>.

=item  'PreTriggers' ($preTriggers_aref)

(optional) Array reference with the names of all pretriggers which shall be considered for this signal manipulation.
All selected pretriggers will be considered with a logical AND (all must be fulfilled for manipulation)
Up to 4 pretriggers can be selected.
The pretriggers can be configured with SPI_load_pretrigger_module.

=item  'Signals_Times_Values' ($signals_times_values_href)

(optional) Hash ref with Signalname as key and value as another hash ref with timestamps as key and signal value as value.

e.g:

    'Signals_Times_Values' => {
                            'Sig_A' => {
                                 0 => 1 ,
                                20 => 2 ,
                                30 => 0 ,
                                50 => 'stop_manipulation' ,
                                } ,
                            'Sig_B' => {
                                 0 => 0 ,
                                20 => 0 ,
                                30 => 1 ,
                                50 => 'stop_manipulation'
                                } ,
                            'Sig_C' => {
                                 0 => 0 ,
                                20 => 0 ,
                                30 => 1 ,
                                50 => 'stop_manipulation'
                                } ,
                            } ,

=item  'Signals_and_Values' ($signals_and_values_href)

(optional) Hash ref with signalname as key and signal value as value. To be configured with parameters ( 'Duration_ms', 'Duration_us' or  'FrameCycles' )

e.g:

    'Signals_and_Values' => {
                            'Sig_A' => 1 ,
                            'Sig_B' => 0 ,
                            'Sig_C' => 1 ,
                            } ,

=back

B<Different use Cases>:

B<usecase 1: Static value>: Write value 10 to signal 'data_CH2' for the command 'RD_SENSOR_DATA_CH2_CAP' constantly

    SPI_load_signal_manipulation ( 'Node'        => 'SMA660_M',
                                   'Command'     => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'      => 'data_CH2',
                                   'SignalValue' => '10' );

B<usecase 2: Static value hex>: Write value 10 (0xA) to signal 'data_CH2' for the command 'RD_SENSOR_DATA_CH2_CAP' constantly

    SPI_load_signal_manipulation ( 'Node'        => 'SMA660_M',
                                   'Command'     => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'      => 'data_CH2',
                                   'SignalValue' => '0xA' );

B<usecase 3: Static value>: Write value 10 to signal 'data_CH2' for the command 'RD_SENSOR_DATA_CH2_CAP' for 200 ms

    SPI_load_signal_manipulation ( 'Node'        => 'SMA660_M',
                                   'Command'     => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'      => 'data_CH2',
                                   'SignalValue' => '10'
                                   'Duration_ms' => '200' # alternative: give 'Duration_us' for time in us
                                   );

B<usecase 4: Static value>: Write value 10 to signal 'data_CH2' for the command 'RD_SENSOR_DATA_CH2_CAP' for 100 frames

    SPI_load_signal_manipulation ( 'Node'        => 'SMA660_M',
                                   'Command'     => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'      => 'data_CH2',
                                   'SignalValue' => '10'
                                   'FrameCycles' => '100'
                                   );

B<usecase 5: Dynamic Sequence (Time based)>: Write sequence of varying values to signal 'CRC/TF' for the command 'MODULE_COMMAND__READ_Adr' in TIMER_MODE mode with unit as .

B<(default 'ms' is considerd if parameter 'TimeUnit' not configured)>
    
    SPI_load_signal_manipulation ( 'Node'              => 'SMA660_M',
                                   'Command'           => 'RD_SENSOR_DATA_CH2_CAP',
                                   'Signal'            => 'data_CH2',
                                   'SignalTimesValues' => { 
                                                            0    => 10, 
                                                            2000 => 20, 
                                                            4000 => 30, 
                                                            6000 => 40 
                                                            } # 40 will be written until 'SPI_stop_manipulation' is called.
                                   );
                                   
B<usecase 6: Dynamic Sequence (Frame based)>: Write sequence of varying values to signal 'Vbat' for the command 'POM_READ_AUTO_VBAT1'. (Note: SignalValues need always FrameCycles (both as aref) ). 

    SPI_load_signal_manipulation ( 'Node'         => 'COBRA_M',
                                   'Command'      => 'POM_READ_AUTO_VBAT1',
                                   'Signal'       => 'Vbat',
                                   'SignalValues' => [  '5',  '5', '12', '13', '15' ] , 
                                   'FrameCycles'  => [ '10', '10', '20', '50', '10' ] ,
                                   );

B<usecase 7: SMI7 >: Write value 1(dec format) to signal 'SD' 3 times for the command 'MODULE_COMMAND__NEXT_PAGE'

    SPI_load_signal_manipulation ( 'Node'        => 'SMI7xx',
                                   'Command'     => 'MODULE_COMMAND__NEXT_PAGE,
                                   'Signal'      => 'SD',
                                   'SignalValue' => 1,
                                   'FrameCycles' => 3,
                                   'SMI7_Module' => 'SMI710_2_Roll', # only required for SMI7
                                   'SMI7_Page'   => 4,  # only required for SMI7
                                   );

B<usecase 8: CRC manipulation>: Invert signal 'CRC' value 3 times for the command 'MODULE_COMMAND__READ_Adr'

    SPI_load_signal_manipulation ( 'Node'        => 'SMI7xx',
                                   'Command'     => 'MODULE_COMMAND__READ_Adr',
                                   'Signal'      => 'CRC',
                                   'SignalValue' => 'invert',
                                   'FrameCycles' => 3,
                                   'SMI7_Module' => 'SMI710_2_Roll',
                                   'SMI7_Page'   => 4,
                                   );

B<usecase 9: binary format>: Invert first two bits of signal 'CRC' value 3 times for the command 'MODULE_COMMAND__READ_Adr'

    SPI_load_signal_manipulation ( 'Node'        => 'SMI7xx',
                                   'Command'     => 'MODULE_COMMAND__READ_Adr',
                                   'Signal'      => 'CRC',
                                   'SignalValue' => '0b-ii',
                                   'FrameCycles' => 3 ,
                                   'SMI7_Module' => 'SMI710_2_Roll',
                                   'SMI7_Page'   => 4,
                                   );

B<usecase 10: binary format>: Support of Space in between the bits of signal 'CRC'  for the command 'MODULE_COMMAND__READ_Adr'

    SPI_load_signal_manipulation ( 'Node'        => 'SMI7xx',
                                   'Command'     => 'MODULE_COMMAND__READ_Adr',
                                   'Signal'      => 'CRC',
                                   'SignalValue' => '0b-i i',
                                   'FrameCycles' => 3,
                                   'SMI7_Module' => 'SMI710_2_Roll',
                                   'SMI7_Page'   => 4,
                                   );

B<usecase 11: pretrigger>: Select pretriggers

    SPI_load_signal_manipulation ( 'Node'        => 'CG904',
                                   'Command'     => 'DISABLE_STATUS',
                                   'Signal'      => 'DIS_AHP',
                                   'SignalValue' => '0x0',
                                   'FrameCycles' => 3,
                                   'PreTriggers' => ['CG904::DEMAND_TEST', 'THRES_TEST_DATA::test_data'],
                                   );

B<usecase 12: multiple signals Dynamic values with same timestamps>: Support of multiple signals ('c1','c2','c4')  for the command 'POM_STATUS' with same timestamps for all signals.

    SPI_load_signal_manipulation ( 'Node'                 => 'Cobra_M',
                                   'Command'              => 'POM_STATUS',
                                   'Signals_Times_Values' => {
                                                                'c1c2' => {
                                                                    0  => '2',  
                                                                    20 => '1',
                                                                    30 => '0',
                                                                    50 => '1',
                                                                },
                                                                '| sl' => {
                                                                    0  => '1',
                                                                    20 => '1',
                                                                    30 => '1',
                                                                    50 => '0',
                                                                },
                                                                '| c4' => {
                                                                    0  => '1',
                                                                    20 => '1',
                                                                    30 => '0',
                                                                    50 => '1',
                                                                },
                                                            },
                                   );

B<usecase 13: multiple signals 1 static value>: Support of multiple signals ('c1','c2','c4')  for the command 'POM_STATUS' with 1 static value for each signal.

    SPI_load_signal_manipulation ( 'Node'               => 'Cobra_M',
                                   'Command'            => 'POM_STATUS',
                                   'Signals_and_Values' => {
                                                                'c1' => '0x1',
                                                                'c2' => '0x0',
                                                                'c4' => '0x1',
                                                            },
                                   'FrameCycles' => '5',
                                 );

=cut

sub SPI_load_signal_manipulation {

    my @args        = @_;
    my $params_href = {@args};

    return unless S_checkFunctionArguments( 'SPI_load_signal_manipulation ( $params_href )', ($params_href) );

    my $nodeName    = $params_href->{'Node'};
    my $commandName = $params_href->{'Command'};

    my $smi7module = $params_href->{'SMI7_Module'};
    my $smi7page   = $params_href->{'SMI7_Page'};

    my $signalName = $params_href->{'Signal'};

    # Static signal
    # a) Single signal
    my $staticSigVal = $params_href->{'SignalValue'};    # in combination with 'Signal'
    my $values_aref  = $params_href->{'SignalValues'};

    # b) Multiple signals
    my $signals_and_values_href = $params_href->{'Signals_and_Values'};
    my $frames_mix              = $params_href->{'FrameCycles'};

    # dynamic signal
    my $timeUnit = $params_href->{'TimeUnit'};

    # a) Single signal
    my $valueDataSamples_href = $params_href->{'SignalTimesValues'};

    # b) Multiple signasl
    my $signals_times_values_href = $params_href->{'Signals_Times_Values'};

    my $crashData_aref = $params_href->{'CrashData'};

    my $staticSignalDuration;
    my $multiple_val_err_flag = 0;    #err_flag to check that only one manipulation type (static, dynamic timer, dynamic SPI) is used
    my $err_flag              = 0;    #err_flag to check the return of function _Validate_and_Convert_Parameters
    if ( $params_href->{'Duration_ms'} ) {
        $staticSignalDuration = $params_href->{'Duration_ms'};
        $timeUnit             = 'ms';
    }
    elsif ( $params_href->{'Duration_us'} ) {
        $staticSignalDuration = $params_href->{'Duration_us'};
        $timeUnit             = 'us';
    }

    return
      unless S_checkFunctionArguments(
        'SPI_load_signal_manipulation ( $nodeName, $commandName, [,$signalName, $smi7module, $smi7page, $values_aref, $valueDataSamples_href,$staticSigVal,$staticSignalDuration,$frames_mix,$signals_and_values_href, $signals_times_values_href])',
        ( $nodeName, $commandName, $signalName, $smi7module, $smi7page, $values_aref, $valueDataSamples_href, $staticSigVal, $staticSignalDuration, $frames_mix, $signals_and_values_href, $signals_times_values_href )
      );

    my $frames_aref = [];
    my $staticSignalFrameNbr;
    ( $frames_aref, $valueDataSamples_href, $values_aref, $staticSignalFrameNbr, $timeUnit, $multiple_val_err_flag, $err_flag ) = _Validate_and_Convert_Parameters(@args);

    return if ($err_flag);

    return unless ( Check_init() );

    # A) Prepare values to be set for signal(s)

    # Static value, single signal
    # value to be written to the signal: for a certain duration, a certain nbr of frames or continuously
    if ( defined $staticSigVal ) {

        # check format of given signal value
        if ( $staticSigVal !~ /(0x[a-fA-F0-9\s*]+$)|(\s*\d+\s*$)|(Invert)|(0b[01i\-x\s*]+)/i ) {    # check for the format valididty
            S_set_error("SPI_load_signal_manipulation : Input format in the parameter 'SignalValue' wrong! check the format given.");
            return;
        }

        if ( $staticSigVal =~ /0x\s*([a-fA-F0-9\s*]+)$/i ) {                                        # hex value
            $staticSigVal =~ s/\s*//g;                                                              # remove spaces
        }

        # in case of 'Invert' signal value ($staticSigVal) will stay as it is
        my $signal_mask_bits;
        my $signalDetails_href = $spiDatabase_Object->Get_signal_details( $nodeName, $commandName, $signalName . "_MISO", { 'SignalMaskStartPosAndLength' => 1, 'SignalDecodingStyle' => 1 } );
        if ( $signalDetails_href->{'SignalDecodingStyle'} eq 'Signed' ) {
            if ( $staticSigVal !~ /^0b/ ) {
                if ( $staticSigVal =~ /^0x/ ) {
                    $staticSigVal = NUM_UnsignedInt2SignedInt( $staticSigVal, $signalDetails_href->{'SignalMaskLength'} );
                }
                $staticSigVal = NUM_SignedInt2UnsignedInt( $staticSigVal, $signalDetails_href->{'SignalMaskLength'} );    # convert $staticSigVal to unsigned if it is -ve.
                return unless ($staticSigVal);
            }

        }

        $multiple_val_err_flag++;

        # Timer mode
        if ($staticSignalDuration) {
            $valueDataSamples_href->{'0'} = $staticSigVal;
            $valueDataSamples_href->{$staticSignalDuration} = 'stop_manipulation';
            $valueDataSamples_href = _convert_time( $valueDataSamples_href, $timeUnit );
        }

        # Single command mode
        elsif ($staticSignalFrameNbr) {
            push( @{$values_aref}, $staticSigVal );
        }

        # Continuous manipulation (realized with timer mode)
        else {
            $valueDataSamples_href->{'0'} = $staticSigVal;
        }

    }

    # Static value, multiple signals
    my $signalMaskHex;
    if ( defined $signals_and_values_href ) {

        if ( not defined $staticSignalDuration and @{$frames_aref} == 0 ) {
            S_w2log( 3, "Parameter 'FrameCycles' or ('Duration_ms' or 'Duration_us') not defined - continuous manipulation of signal values" );
            push( @{$frames_aref}, 0 );
        }

        # Timer Mode
        if ($staticSignalDuration) {
            ( $signalMaskHex, $valueDataSamples_href ) = _Static_value_signals( $nodeName, $commandName, $signals_and_values_href, $staticSignalDuration, $staticSignalFrameNbr, $timeUnit );
            return unless ($signalMaskHex);
        }

        # Single command mode - certain nbr of frames or continuously
        else {
            ( $signalMaskHex, $values_aref ) = _Static_value_signals( $nodeName, $commandName, $signals_and_values_href, $staticSignalDuration, $staticSignalFrameNbr );
            return unless ($signalMaskHex);
        }
        $multiple_val_err_flag++;
    }

    # Dynamic signal values, timer mode
    if ( defined $signals_times_values_href ) {
        ( $signalMaskHex, $valueDataSamples_href ) = _Dynamic_value_signals( $nodeName, $commandName, $signals_times_values_href, $timeUnit );
        return unless ($signalMaskHex);
        $multiple_val_err_flag++;
    }

    if ( $multiple_val_err_flag != 1 and $crashData_aref eq undef ) {
        S_set_error( "SPI_load_signal_manipulation : Only one of these parameters" . " 'SignalValues', 'SignalTimesValues', 'SignalValue', 'Signals_and_Values' or 'Signals_Times_Values' should be defined. Manipulation unclear!", 109 );
        return;
    }

    # If no instruction set is defined at the moment, create a new one
    unless ( defined $spiInstructionSet_object ) {
        $spiInstructionSet_object = LIFT_spi_instruction_set->new();
    }

    # B) Trigger configuration
    # Set network details for node
    my ( $cs, $spiNbr ) = $spiDatabase_Object->GetNodeBusDetails($nodeName);

    #error handling node not found
    if ( not defined $cs or not defined $spiNbr ) {
        S_set_error("Node '$nodeName' not found, check the node name configured");
        return;
    }

    # Set trigger mask and value
    my ( $triggerMaskHex, $triggerMaskValue ) = $spiDatabase_Object->GetCommandMaskAndValue( $nodeName, $commandName );

    #error handling command mask not found
    if ( not defined $triggerMaskHex or not defined $triggerMaskValue ) {
        S_set_error("Command mask not found for the command '$commandName'");
        return;
    }

    # Get SMI7 module number if defined
    my $smi7moduleNbr;
    if ( defined $smi7page ) {
        if ($smi7module) {
            S_w2log( 4, "SPI_load_signal_manipulation: SMI7 module not contained in given given command.\n" . "Get SMI 7 module number from mapping and add to trigger mask and value." );
            ( $smi7moduleNbr, $triggerMaskHex, $triggerMaskValue ) = _prepare_SMI7_write_config( $smi7module, $nodeName, $triggerMaskHex, $triggerMaskValue );
        }
        else {
            S_w2log( 4, "SPI_load_signal_manipulation: SMI7 module not given - must be already considered in given command\n" . "Get SMI 7 module number command value" );
            my ( $triggerMaskBin, $triggerValueBin ) = $spiDatabase_Object->GetCommandMaskAndValue( $nodeName, $commandName, 'BIN' );
            my @binaryTriggerValueArray = split( //, $triggerValueBin );
            my $smi7moduleBin = $binaryTriggerValueArray[0] . $binaryTriggerValueArray[1];
            S_w2log( 1, "SMI7 module binary: $smi7moduleBin" );
            $smi7moduleNbr = hex( sprintf( "%02X", oct("0b$smi7moduleBin") ) );
            S_w2log( 1, "SMI7 module number:  $smi7moduleNbr" );
        }
    }

    # C) Write configuration
    # Set signal mask

    unless ($signalMaskHex) {
        $signalMaskHex = $spiDatabase_Object->GetSignalMask( $signalName . "_MISO", $commandName, $nodeName );

        # error handling signal mask not found
        if ( not defined $signalMaskHex ) {
            S_set_error("Signal mask not found for the signal $signalName");
            return;
        }
    }

    unless (
        $spiInstructionSet_object->AddSignalManipulation(
            'Node'              => $nodeName,
            'SMI7_Module'       => $smi7moduleNbr,
            'SMI7_Page'         => $smi7page,
            'Command'           => $commandName,
            'Signal'            => $signalName,
            'SignalValues'      => $values_aref,
            'SignalTimesValues' => $valueDataSamples_href,
            'ChipSelect'        => $cs,
            'FrameCycles'       => $frames_aref,
            'SPIBusNbr'         => $spiNbr,
            'TriggerMask'       => $triggerMaskHex,
            'TriggerValue'      => $triggerMaskValue,
            'SignalMask'        => $signalMaskHex,
            'PreTriggers'       => $params_href->{'PreTriggers'},
            'CrashData'         => $crashData_aref,

        )
      )
    {
        return;    #error messages handled in AddSignalManipulation
    }

    return 1;
}

=head2 SPI_load_invalid_CRC

    SPI_load_invalid_CRC ( 'Node' => $nodeName,
                           'Signal' => $signalName, # defualt is 'CRC'
                           'Command' => $commandName
                         );
    
B<Description>: This function loads the invalid crc value to the device signal.

B<Arguments:>

=over

=item $nodeName

Node name for which the 'CRC' signal has to be manipulated.

=item $signalName

Signal name for which the invalid crc value has to written.

=item $commandName

Command name for which the signal belongs to.

=back

B<Different use Cases>:

B<usecase 1 default:> Load invlaid crc value the device signal 'CRC' for node SMI7xx.
    B<By default the signal name is considered as 'CRC'>
    SPI_load_invalid_CRC ( 'Node' => 'SMI7xx' );

B<usecase 2 crc signal name changed:> Load invlaid crc value the device signal 'CRC/TF' for node SMI7xx.
    B<By default the signal name is considered as 'CRC'>
    SPI_load_invalid_CRC ( 'Node' => 'SMI7xx',  'Signal' => 'CRC/TF' );

B<usecase 3 crc signal for specific command:> Load invlaid crc value the signal 'CRC/TF' of the command 'MODULE_COMMAND__READ_Adr'
    for node SMI7xx.
    
    SPI_load_invalid_CRC ( 'Node' => 'SMI7xx',  'Signal' => 'CRC/TF', 'Command' => 'MODULE_COMMAND__READ_Adr' );
    
=cut

sub SPI_load_invalid_CRC {
    my @args = @_;

    my $params      = {@args};
    my $nodeName    = $params->{'Node'};
    my $commandName = $params->{'Command'};
    my $signalName  = $params->{'Signal'};
    unless ( defined $signalName ) {
        $signalName = 'CRC';
        push( @args, 'Signal', 'CRC' );
    }

    return unless S_checkFunctionArguments( 'SPI_load_invalid_CRC ( $nodeName [, $commandName, $signalName] )', ( $nodeName, $commandName, $signalName ) );

    return unless ( Check_init() );

    S_w2log( 2, 'processing load invalid CRC', 'blue' );

    if ( defined $commandName ) {
        my $load_status = SPI_load_signal_manipulation( @args, 'SignalValue' => 'invert' );

        unless ($load_status) {
            S_set_error("SPI_load_invalid_CRC : Loading failed!");
            return;
        }
    }
    else {
        # If no instruction set is defined at the moment, create a new one
        unless ( defined $spiInstructionSet_object ) {
            $spiInstructionSet_object = LIFT_spi_instruction_set->new();
        }

        my $signalMaskHex = $spiDatabase_Object->GetSignalMask( $signalName . "_MISO", $commandName, $nodeName );

        # error handling signal mask not found
        if ( not defined $signalMaskHex ) {
            S_set_error("Signal mask not found for the signal $signalName");
            return;
        }
        my ( $cs, $spiNbr ) = $spiDatabase_Object->GetNodeBusDetails($nodeName);

        #error handling node not found
        if ( not defined $cs or not defined $spiNbr ) {
            S_set_error("Node '$nodeName' not found, check the node name configured");
            return;
        }
        my $triggerMaskHex = sprintf( "%0" . '8' . "X", 0 );

        my $triggerMaskValue = sprintf( "%0" . '8' . "X", 0 );
        my $valueDataSamples_href = { 0 => 'invert' };

        $spiInstructionSet_object->AddSignalManipulation(
            'Node'              => $nodeName,
            'Signal'            => $signalName,
            'SignalMask'        => $signalMaskHex,
            'SignalTimesValues' => $valueDataSamples_href,
            'TriggerMask'       => $triggerMaskHex,
            'TriggerValue'      => $triggerMaskValue,
            'ChipSelect'        => $cs,
            'SPIBusNbr'         => $spiNbr,
        );
    }
    return 1;
}

=head2 SPI_load_pretrigger_module

    SPI_load_pretrigger_module ( 'PT_Node' => $nodeName,
                                 'PT_Command' => $commandName
                                 'PT_ActiveTime_us' => $pt_activeTime_us,
                                 'PT_MOSI_Signal' => $signalName,
                                 'PT_Signal_Value' => $signalValue,
                                );
    
B<Description>: This function configures a pretrigger module in Manitoo tool.
If a pretrigger module is configured for a signal manipulation, then the manipulation will only take place while the pretrigger is active.
Once the pretrigger condition is recognized on the SPI, a timer will start.
The pretrigger will stay active until the 'PT_ActiveTime_us' has passed.
Only during this time, the signal manipulation will take place.
Up to 4 pretriggers can be configured for each signal manipulation (see API of SPI_load_signal_manipulation).
If more than 1 pretrigger is selected for the signal manipulation, all pretriggers must be active for the manipulation to take place.
The name of the pretrigger is combined out of the 'PT_Node', 'PT_Command', and 'PT_MOSI_Signal'.
As the signal is optional, there are two variants of naming:
PT_Node::PT_Command
PT_Node::PT_Command::PT_MOSI_Signal

B<Arguments:>

=over

=item $nodeName

Node name for which the pretrigger shall get active

=item $commandName

Command name for which the pretrigger shall get active

=item $pt_activeTime_us

Time in us for which the pretrigger will stay active once activated

=item $signalName

MOSI Signal in command $commandName which must have value $signalValue for pretrigger to get activated

=item $signalValue

Value (decimal) of $signalName for which the pretrigger will get activated

=back

B<Different use Cases>:

B<usecase 1 default:>

    SPI_load_pretrigger_module ( 'PT_Node' => 'CG904',
                                 'PT_ActiveTime_us' => 10000, #us
                                 'PT_Command' => 'DEMAND_TEST');

B<usecase 2 signal:>

    SPI_load_pretrigger_module ( 'PT_Node' => 'CG904',
                                 'PT_ActiveTime_us' => 2000, #us
                                 'PT_Command' => 'THRES_TEST_DATA',
                                 'PT_MOSI_Signal' => 'test_data',
                                 'PT_Signal_Value' => 100);

=cut

sub SPI_load_pretrigger_module {
    my @args          = @_;
    my $params        = {@args};
    my $pt_node       = $params->{'PT_Node'};
    my $pt_command    = $params->{'PT_Command'};
    my $signalName    = $params->{'PT_MOSI_Signal'};
    my $signalValue   = $params->{'PT_Signal_Value'};
    my $activeTime_us = $params->{'PT_ActiveTime_us'};
    S_w2log( 2, 'processing SPI_load_pretrigger_module', 'blue' );

    # check function args
    return
      unless S_checkFunctionArguments( 'SPI_load_pretrigger_module ( $pt_node, $pt_command, $activeTime_us[,$signalName, $signalValue])', ( $pt_node, $pt_command, $activeTime_us, $signalName, $signalValue ) );

    return unless ( Check_init() );

    # --- PreTrigger configuration ---

    # Set network details for node
    my ( $pt_cs, $pt_spiNbr ) = $spiDatabase_Object->GetNodeBusDetails($pt_node);

    # error handling node not found
    if ( not defined $pt_cs or not defined $pt_spiNbr ) {
        S_set_error("Node '$pt_node' not found, check the node name ('PT_Node') configured");
        return;
    }

    # Set trigger mask and value
    my ( $pt_triggerMaskHex, $pt_triggerMaskValue ) = $spiDatabase_Object->GetCommandMaskAndValue( $pt_node, $pt_command );

    #error handling command mask not found
    if ( not defined $pt_triggerMaskHex or not defined $pt_triggerMaskValue ) {
        S_set_error("Command mask not found for the command '$pt_command' (pretrigger)");
        return;
    }

    # Add signal mask and value
    if ( defined $signalName ) {

        # 1 - get signal mask in binary format
        my $signalMaskBin = $spiDatabase_Object->GetSignalMask( $signalName . "_MOSI", $pt_command, $pt_node, 'BIN' );
        unless ( defined $signalMaskBin ) {
            S_set_error("Signal '$signalName' not found for command '$pt_command' in node '$pt_node'");
            return;
        }
        S_w2log( 3, "SPI_load_pretrigger_module : Mask for signal '$signalName' is '$signalMaskBin'" );
        my @signalMaskReverseArray = reverse( split( //, $signalMaskBin ) );

        # 2 - get signal value in binary format
        if ( not defined $signalValue ) {
            S_set_error("Defined signal $signalName in parameter 'PT_MOSI_Signal', but no value in parameter 'PT_Signal_Value'");
            return;
        }
        my $valueBin = S_dec2bin($signalValue);
        $valueBin =~ s/^0+(?=\d)//;    # Remove leading zeros

        S_w2log( 3, "SPI_load_pretrigger_module : Binary value is '$valueBin' " );
        my @signalValueReverseArray = reverse( split( //, $valueBin ) );
        my @signalValueCompleteArray;

        # 3 - map signal value to bit mask
        my $maskLength = 0;
        foreach my $bitInMask (@signalMaskReverseArray)    #starting from low bit as bit array is reversed
        {
            if ( $bitInMask == 1 and @signalValueReverseArray != 0 ) {
                $maskLength++;
                unshift( @signalValueCompleteArray, shift(@signalValueReverseArray) );    #prepend value
            }
            elsif ( $bitInMask == 0 and $maskLength > 0 and @signalValueReverseArray != 0 ) {    # mask is over but value is not -> value too big
                S_set_error("SPI_load_pretrigger_module : value $signalValue does not fit into signal mask for signal '$signalName'");
                return;
            }
            else {
                unshift( @signalValueCompleteArray, 0 );                                         #prepend value
            }
        }
        my $valueBinComplete = join( '', @signalValueCompleteArray );
        S_w2log( 3, "SPI_load_pretrigger_module : Value for signal '$signalName' is '$valueBinComplete' (original: $signalValue)" );

        # 4 - enhance trigger mask and trigger value (only containing command mask) with signal / value information
        my $pt_triggerMaskBin = S_dec2bin( hex($pt_triggerMaskHex) );
        $pt_triggerMaskBin = $signalMaskBin | $pt_triggerMaskBin;
        my $maskLengthByte = split( //, $pt_triggerMaskHex );
        $pt_triggerMaskHex = sprintf( "%0" . $maskLengthByte . "X", oct("0b$pt_triggerMaskBin") );
        S_w2log( 3, "SPI_load_pretrigger_module : Binary trigger mask is '$pt_triggerMaskBin', hex '$pt_triggerMaskHex'" );

        my $pt_triggerMaskValueBin = S_dec2bin( hex($pt_triggerMaskValue) );
        $pt_triggerMaskValueBin = $valueBinComplete | $pt_triggerMaskValueBin;
        $pt_triggerMaskValue = sprintf( "%0" . $maskLengthByte . "X", oct("0b$pt_triggerMaskValueBin") );
        S_w2log( 3, "SPI_load_pretrigger_module : Binary trigger mask value is '$pt_triggerMaskValueBin', hex '$pt_triggerMaskValue'" );
    }

    # If no instruction set is defined at the moment, create a new one
    unless ( defined $spiInstructionSet_object ) {
        $spiInstructionSet_object = LIFT_spi_instruction_set->new();
    }

    # --- Add PreTrigger module ---
    my $preTriggerModule = $spiInstructionSet_object->AddPreTriggerModule(
        'PT_Node'          => $pt_node,
        'PT_Command'       => $pt_command,
        'PT_Signal'        => $signalName,
        'PT_TriggerMask'   => $pt_triggerMaskHex,
        'PT_TriggerValue'  => $pt_triggerMaskValue,
        'PT_ActiveTime_us' => $activeTime_us,
        'PT_ChipSelect'    => $pt_cs,
        'PT_SPIBusNbr'     => $pt_spiNbr
    );

    if ($preTriggerModule) {
        S_w2log( 3, "SPI_load_pretrigger_module : Creation of pre trigger module successful." );
        return 1;
    }
    else {
        S_set_error("Creation of pre trigger module not successful! Check input parameters.");
        return;
    }
}

=head2 SPI_load_frame_manipulation

    SPI_load_frame_manipulation( chip_select, SPI_bus_nbr, Frame_ID_mask,
             Frame_ID_pattern, signal_mask, value );

B<To be implemented>

=cut

sub SPI_load_frame_manipulation {

    return 1;
}

=head2 SPI_load_manipulation_set

    SPI_load_manipulation_set(inst_1, inst_2, inst_3);
    
B<To be implemented>

=cut

sub SPI_load_manipulation_set {

    S_w2log( 2, "\n SPI_load_manipulation_set to be implemented\n" );
    return 1;
}

=head2 SPI_start_manipulation

    SPI_start_manipulation();
    
B<Description:> This function starts the manipulation. Before calling this function the manipulation instruction has to be loaded.

B<Arguments:> None.

=cut

sub SPI_start_manipulation {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SPI_start_manipulation( )', @args );

    S_w2log( 2, "\n SPI_start_manipulation\n" );
    return unless ( Check_init() );

    my $success = $spiInstructionSet_object->DownloadInstructionSetToManitoo();

    unless ($success) {
        S_set_error("Downloading instruction set failed !");
        return;
    }

    return CallDeviceFunction(@args);
}

=head2 SPI_stop_manipulation

    SPI_stop_manipulation();

B<Description:> This function reads and verify first values of manipulation counter and stops the manipulation of the SPI tool. 

B<Arguments:> None.

=cut

sub SPI_stop_manipulation {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SPI_stop_manipulation( )', @args );
    return unless ( Check_init() );

    S_w2log( 2, "\n SPI_stop_manipulation\n" );

    my ( $status, $usedManipulationModules_aref ) = $spiInstructionSet_object->GetUsedManipulationModules();
    if ($status) {
        SPI_verify_manipulation_counter($usedManipulationModules_aref);
    }

    $spiInstructionSet_object = undef;

    return CallDeviceFunction(@args);
}

=head2 SPI_get_manipulation_counter

    SPI_get_manipulation_counter( );
    
B<Description:> This function read the current counter values of manipulation modules. 
                When 0 it throws a WARNING.
                When sum of all is 0 it throws an ERROR. 

B<Return Value:>  $all_mani_counter_href

B<Examples:> 

    my $all_mani_counter_href = SPI_get_manipulation_counter( );# all manipulation modules will be returned
    
    $all_mani_counter_href : {  0 => 123 , 1 => 456 }   # all manipul modules and their counter values
    

=cut

sub SPI_get_manipulation_counter {

    return unless ( Check_init() );

    S_w2log( 2, "\n SPI_get_manipulation_counter\n" );

    foreach my $manip_module_index ( sort { $a <=> $b } keys %$MANIPULATION_COUNTER_HREF ) {
        my $nbr_of_manip = $MANIPULATION_COUNTER_HREF->{$manip_module_index};
        S_w2log( 2, "SPI_get_manipulation_counter : Module [$manip_module_index] -> $nbr_of_manip frames manipulated\n", 'blue' );
    }

    return $MANIPULATION_COUNTER_HREF;
}

=head2 SPI_verify_manipulation_counter

    SPI_verify_manipulation_counter( [ $manipulation_modules_to_check_aref ] );
    
B<Description:> This function read the current counter values of manipulation modules. 
                When 0 it throws a WARNING.
                When sum of all is 0 it throws an ERROR. 

B<Arguments:>  $manipulation_modules_to_check_aref : array ref with numbers of manipulation modules to be read and verified 

B<Examples:>

    SPI_verify_manipulation_counter( [ 0 , 1 ] );   # manipulation module 0,1 will be read and verified
    SPI_verify_manipulation_counter( );             # all manipulation modules will be read and verified

=cut

sub SPI_verify_manipulation_counter {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SPI_verify_manipulation_counter( [ $manipulation_modules_to_check_aref ] )', @args );
    my $manipulation_modules_to_check_aref = shift @args;

    return unless ( Check_init() );

    my ( $status, $response_hex_aref, $manipulation_counter_aref, $manipulation_counter_href );

    S_w2log( 2, "\n SPI_verify_manipulation_counter\n" );

    # collecting data
    #    either seperately
    if ( scalar @$manipulation_modules_to_check_aref ) {
        foreach my $manip_module_index (@$manipulation_modules_to_check_aref) {
            ( $status, $response_hex_aref, $manipulation_counter_aref ) = MANITOO_cmd_ReadManipulationCounter($manip_module_index);
            return unless $status;
            return unless defined $manipulation_counter_aref->[0];
            $manipulation_counter_href->{$manip_module_index} = $manipulation_counter_aref->[0];
        }
    }

    #   or ALL with one call (supported from Manitoo Firmware 4.x.x)
    else {
        my $manip_module_index = 0;
        ( $status, $response_hex_aref, $manipulation_counter_aref ) = MANITOO_cmd_ReadManipulationCounter("ALL");
        return unless $status;
        foreach (@$manipulation_counter_aref) {
            $manipulation_counter_href->{$manip_module_index} = $manipulation_counter_aref->[$manip_module_index];
            $manip_module_index++;
        }
    }

    #
    # print and summarize all manipulation counter from Manitoo
    #
    my $sum_of_manipulations = 0;
    foreach my $manip_module_index ( sort { $a <=> $b } keys %$manipulation_counter_href ) {
        my $nbr_of_manip = $manipulation_counter_href->{$manip_module_index};
        S_w2log( 2, "SPI_verify_manipulation_counter : Module [$manip_module_index] -> $nbr_of_manip frames manipulated\n", 'blue' );
        #
        # throw warning in case of no manipulation of one manipulation module
        #
        S_set_warning("Manipulation Module '$manip_module_index' have not manipulated any frame") unless $nbr_of_manip;

        $sum_of_manipulations = $sum_of_manipulations + $nbr_of_manip;
    }

    $MANIPULATION_COUNTER_HREF = {};
    $MANIPULATION_COUNTER_HREF = $manipulation_counter_href;

    #
    # at least one manipulation must occur
    #
    if ( $sum_of_manipulations == 0 ) {
        S_set_error("Check sum of all Manitoo manipulations = 0  -> no manipulation did happen !!!");
        return;
    }

    return 1;
}

=head2 _Validate_and_Convert_Parameters
    
Non export function.

This function validates the inputs to the function SPI_load_signal_manipulation and converts the data to the required format.

=cut

sub _Validate_and_Convert_Parameters {

    my @args                      = @_;
    my $params_href               = {@args};
    my $nodeName                  = $params_href->{'Node'};
    my $smi7module                = $params_href->{'SMI7_Module'};
    my $smi7page                  = $params_href->{'SMI7_Page'};
    my $commandName               = $params_href->{'Command'};
    my $signalName                = $params_href->{'Signal'};
    my $timeUnit                  = $params_href->{'TimeUnit'};
    my $signals_and_values_href   = $params_href->{'Signals_and_Values'};
    my $signals_times_values_href = $params_href->{'Signals_Times_Values'};
    my $crashData_aref            = $params_href->{'CrashData'};

    # assign frame cycles based on the static or dynamic frames configured

    # dynamic signal SPI Mode
    my $values_aref = $params_href->{'SignalValues'};

    # aref containing number of frames for each signal value
    my $frames_mix = $params_href->{'FrameCycles'};

    # dynamic signal timer mode
    my $valueDataSamples_href = $params_href->{'SignalTimesValues'};

    # Parameters for static signal
    my $staticSigVal = $params_href->{'SignalValue'};
    my $frames_aref  = [];
    my ($staticSignalFrameNbr);
    my $multiple_values_err_flag = 0;
    my $err_flag                 = 0;

    if ( defined $params_href->{'CrashData'} ) {
        if ( ref $params_href->{'CrashData'} ne 'ARRAY' ) {
            S_set_error( "_Validate_and_Convert_Parameters: CrashData must be of type Array ref! ", 109 );
            return;
        }
        if ( ref $params_href->{'CrashData'} eq 'ARRAY' ) {

            # return if it is Array reference as no further data validation is necessary for crash data
            return 1;
        }
    }

    if ( defined $frames_mix ) {
        if ( ref $frames_mix eq 'ARRAY' ) {
            $frames_aref = $params_href->{'FrameCycles'};
        }
        elsif ( not ref $frames_mix ) {

            # just a one value is given as normal integer , e.g. '100'
            $staticSignalFrameNbr = $params_href->{'FrameCycles'};
            push( @{$frames_aref}, $staticSignalFrameNbr );
        }
        else {
            S_set_error( "Unexpected case for use of 'FrameCycles'", 109 );
            $err_flag = 1;
        }
    }

    if ( $params_href->{'Duration_ms'} ) {
        $timeUnit = 'ms';
    }
    elsif ( $params_href->{'Duration_us'} ) {
        $timeUnit = 'us';
    }

    if ( not defined $values_aref and not defined $valueDataSamples_href and not defined $staticSigVal and not defined $signals_and_values_href and not defined $signals_times_values_href ) {
        S_set_error( "SPI_load_signal_manipulation: No value defined for stimulation. Configure any one of these 'SignalValues', 'SignalTimesValues', 'SignalValue', 'Signals_and_Values' or 'Signals_Times_Values'", 109 );
        $err_flag = 1;
    }

    if ( ( defined $signals_and_values_href or defined $signals_times_values_href ) and defined $signalName ) {
        S_set_error( "SPI_load_signal_manipulation : Do not define parameter 'Signal' while using parameters 'Signals_and_Values' or 'Signals_Times_Values'.\n", 109 );
        $err_flag = 1;
    }

    # Error handling: Both $smi7module and $smi7page should be defined
    if ( defined $smi7module and $smi7page eq '' ) {
        S_set_error( "SPI_load_signal_manipulation : Key 'smi7_page' should be defined," . "when the key 'smi7_module' is defined.\n", 109 );
        $err_flag = 1;
    }

    # Error if both ststic and dynamic values configured.
    if ( ( defined $values_aref and defined $staticSigVal ) ) {
        S_set_error( "SPI_load_signal_manipulation : Both static and Dynamic values cannot be configured for the same signal, configure any one! ", 109 );
        $err_flag = 1;
    }

    # Error if only FrameCycles defined without the values.
    if ( ( defined $values_aref and not defined $frames_mix ) ) {
        S_set_error( "SPI_load_signal_manipulation : Parameter 'FrameCycles' must be defined when 'SignalValues' is configured for SPI mode! ", 109 );
        $err_flag = 1;
    }

    # Error if both FrameCycles and SignalTimesValues defined.
    if ( ( defined $valueDataSamples_href and defined $frames_mix ) ) {
        S_set_error( "SPI_load_signal_manipulation : Either of one Parameter 'FrameCycles' or 'SignalTimesValues' must be defined! conflicts the mode selection.", 109 );
        $err_flag = 1;
    }

    if ( defined $values_aref ) {

        $values_aref = _convert_data( $values_aref, 'SPI' );

        unless ($values_aref) {
            $err_flag = 1;    #error message handled in the '_convert_data' function
        }
        $multiple_values_err_flag++;
    }

    # Timer mode parameter
    if ( defined $valueDataSamples_href ) {

        #convert the data to decimal
        $valueDataSamples_href = _convert_data( $valueDataSamples_href, 'TIMER' );

        unless ($valueDataSamples_href) {
            $err_flag = 1;    #error message handled in the '_convert_data' function
        }

        $valueDataSamples_href = _convert_time( $valueDataSamples_href, $timeUnit );

        unless ($valueDataSamples_href) {

            #error message handled in the _convert_time function
            $err_flag = 1;
        }
        $multiple_values_err_flag++;
    }

    return ( $frames_aref, $valueDataSamples_href, $values_aref, $staticSignalFrameNbr, $timeUnit, $multiple_values_err_flag, $err_flag );
}

=head2 _Static_value_signals

_Static_value_signals( $nodeName, $commandName, $signals_and_values_href, $duration, $timeUnit );

Non export function. Called by SPI_load_signal_manipulation when parameter 'Signals_and_Values' is configured.

This function combines the signals mask and values.

return: $signalMaskHex : Signal mask
        $valueDataSamples_href : values in TIMER mode (or)
        $values_aref : values in SPI mode

=cut

sub _Static_value_signals {

    my $nodeName                = shift;
    my $commandName             = shift;
    my $signals_and_values_href = shift;
    my $staticSignalDuration    = shift;
    my $staticSignalFrameNbr    = shift;
    my $timeUnit                = shift;
    my $signal_mask_aref        = [];
    my $signals_value;
    my $valueDataSamples_href = {};
    my $signalMaskHex;

    return
      unless S_checkFunctionArguments( '_Static_value_signals ( $nodeName, $commandName, $signals_and_values_href, [,$staticSignalDuration, $timeUnit])', ( $nodeName, $commandName, $signals_and_values_href, $staticSignalDuration, $timeUnit ) );

    ( $signalMaskHex, $signals_value ) = _Combine_signal_mask_and_value( $nodeName, $commandName, $signals_and_values_href );
    return unless ($signalMaskHex);
    if ( not defined $signalMaskHex and not defined $signals_value ) {
        return;    # error message handled in funtion _Combine_signal_mask_and_value
    }

    if ($staticSignalDuration) {
        $valueDataSamples_href->{'0'} = $signals_value;
        $valueDataSamples_href->{$staticSignalDuration} = 'stop_manipulation' unless ( $staticSignalDuration eq 'infinite' );
        $valueDataSamples_href = _convert_time( $valueDataSamples_href, $timeUnit );
        return ( $signalMaskHex, $valueDataSamples_href );
    }
    else {
        my $values_aref = [];
        push( @$values_aref, $signals_value );
        return ( $signalMaskHex, $values_aref );
    }
}

=head2 _Dynamic_value_signals

_Dynamic_value_signals( $nodeName, $commandName, $signals_and_values_href, $duration, $timeUnit );

Non export function. Called by SPI_load_signal_manipulation when parameter 'Signals_Times_Values' is configured.

This function combines the signals mask and values.

return: $signalMaskHex : Signal mask
        $valueDataSamples_href : values in TIMER mode (or)
        $values_aref : values in SPI mode

=cut

sub _Dynamic_value_signals {

    my $nodeName                  = shift;
    my $commandName               = shift;
    my $signals_times_values_href = shift;
    my $timeUnit                  = shift;
    my $signals_value;
    my $valueDataSamples_href = {};
    my ( $signalMaskHex, $time_stamp_check );

    my ( @time_stamps, $no_of_dynamic_values );
    my $signal_value_href = {};
    my $time_counter      = 0;

    return
      unless S_checkFunctionArguments( '_Dynamic_value_signals ( $nodeName, $commandName, $signals_times_values_href,[,$timeUnit] )', ( $nodeName, $commandName, $signals_times_values_href, $timeUnit ) );

    foreach my $signal ( keys %$signals_times_values_href ) {
        $no_of_dynamic_values = @time_stamps = sort keys %{ $signals_times_values_href->{$signal} };
        $time_stamp_check = join( '', @time_stamps ) unless ($time_counter);
        if ($time_counter) {
            my $time_stamps = join( '', @time_stamps );
            if ( $time_stamp_check != $time_stamps ) {
                S_set_error( "All time stamps for the signals should be same ", 109 );
                return;
            }
        }
        $time_counter++;
    }

    my $stop_manip_flag = 0;
    foreach my $time (@time_stamps) {
        foreach my $signal ( keys %$signals_times_values_href ) {
            my $time_value_href = $signals_times_values_href->{$signal};
            if ( $time_value_href->{$time} !~ /stop_manipulation/i ) {
                $signal_value_href->{$signal} = $time_value_href->{$time};
                next;
            }
            elsif ( $time_value_href->{$time} =~ /stop_manipulation/i ) {
                $valueDataSamples_href->{$time} = $time_value_href->{$time};
                $stop_manip_flag++;
            }

        }
        ( $signalMaskHex, $signals_value ) = _Combine_signal_mask_and_value( $nodeName, $commandName, $signal_value_href ) unless ($stop_manip_flag);
        $valueDataSamples_href->{$time} = $signals_value unless ( exists $valueDataSamples_href->{$time} );
    }
    $valueDataSamples_href = _convert_time( $valueDataSamples_href, $timeUnit );
    return ( $signalMaskHex, $valueDataSamples_href );
}

=head2 _Combine_signal_mask_and_value

_Combine_signal_mask_and_value( $nodeName, $commandName, $signals_and_values_href, $duration, $timeUnit );

Non export function. Called by _Dynamic_value_signals or  _Static_value_signals.

This function combines the signals mask and values.

return: $signalMaskHex : Signal mask
        $valueDataSamples_href : values in TIMER mode (or)
        $values_aref : values in SPI mode

=cut

sub _Combine_signal_mask_and_value {

    my $nodeName                = shift;
    my $commandName             = shift;
    my $signals_and_values_href = shift;
    my $signal_mask_aref        = [];
    my $signals_value;
    my $valueDataSamples_href = {};
    my $signalMaskHex;

    my $binary_values_aref = [];
    my %value_position_str;
    my @collective_signal_mask;
    my $binary_flag = 0;
    my $hex_flag    = 0;
    my $dec_flag    = 0;

    my $instructionLength_Nibble = $spiDatabase_Object->GetCommandInstructionLength( $nodeName, $commandName, 'Byte' ) * 2;
    my $instructionLength_Bit    = $spiDatabase_Object->GetCommandInstructionLength( $nodeName, $commandName, 'Bit' );

    # $value is required for creating an overall signal value which will contain all individual signal values
    # initialize $value with a all 0's
    my $value = '';
    foreach my $bitInInstruction ( 1 .. $instructionLength_Bit ) { $value .= '0' }

    foreach my $signal ( keys %${signals_and_values_href} ) {

        my $sig_mask = $spiDatabase_Object->GetSignalMask( $signal . "_MISO", $commandName, $nodeName, 'HEX' );
        if ( not defined $sig_mask ) {
            S_set_error( "Signal mask not found for the signal $signal", 109 );
            return;
        }

        my $mask_bin = sprintf( "%." . $instructionLength_Bit . "b", hex $sig_mask );

        # Store binary signal mask for each signal in $signal_mask_aref - will be basis for the overall signal mask
        push( @$signal_mask_aref, $spiDatabase_Object->GetSignalMask( $signal . "_MISO", $commandName, $nodeName, 'BIN' ) );

        my ( $values, $val_bin, @value_bin_array );

        # if binary format check for value exceeds mask and prepare value
        if ( $signals_and_values_href->{$signal} =~ /^0b/i ) {
            $val_bin = $signals_and_values_href->{$signal};
            $val_bin =~ s/^0b//;
            $val_bin =~ s/\s*//g;    #remove extra spaces if present
            my $val_length = length $val_bin;
            my @msk_len    = $mask_bin =~ /[1]+/g;
            @msk_len = split( //, $msk_len[0] );
            my $mask_len = scalar @msk_len;

            if ( $val_length > $mask_len ) {
                S_set_error( "The signal value '$signals_and_values_href->{$signal}' is greater than the signal mask", 109 );
                return;
            }

            $signals_and_values_href->{$signal} = $val_bin;
            $binary_flag = 1;
        }

        # if hex format convert to to decimal
        elsif ( $signals_and_values_href->{$signal} =~ /^0x/i ) {
            $values = $signals_and_values_href->{$signal};
            my $val = $values;

            my $signal_mask_bits;
            my $signalDetails_href = $spiDatabase_Object->Get_signal_details( $nodeName, $commandName, $signal . "_MISO", { 'SignalMaskStartPosAndLength' => 1, 'SignalDecodingStyle' => 1 } );
            my $signalDecodingStyle = $signalDetails_href->{'SignalDecodingStyle'};
            if ( $signalDecodingStyle eq 'Signed' ) {
                if ( $val =~ /^0x/i ) {
                    $val = NUM_UnsignedInt2SignedInt( $val, $signalDetails_href->{'SignalMaskLength'} );
                }
                $val = NUM_SignedInt2UnsignedInt( $val, $signalDetails_href->{'SignalMaskLength'} );    # convert $staticSigVal to unsigned if it is -ve.
                return unless ($val);
            }
            $val =~ s/^0x//;
            $val =~ s/\s*//g;                                                                           #remove extra spaces if present
            my @value_arr = split( //, $val );

            if ( $signalDecodingStyle eq 'Signed' ) {
                $val_bin = sprintf( "%b", $val );
            }
            else {
                $val_bin = sprintf( "%b", hex($val) );
            }

            @value_bin_array = reverse split( //, $val_bin );
            $hex_flag = 1;

        }

        # if value is decimal
        else {
            $values = $signals_and_values_href->{$signal};
            $values =~ s/\s*//g;    #remove extra spaces if present
            my $signal_mask_bits;
            my $signalDetails_href = $spiDatabase_Object->Get_signal_details( $nodeName, $commandName, $signal . "_MISO", { 'SignalMaskStartPosAndLength' => 1, 'SignalDecodingStyle' => 1 } );
            if ( $signalDetails_href->{'SignalDecodingStyle'} eq 'Signed' ) {
                $values = NUM_SignedInt2UnsignedInt( $values, $signalDetails_href->{'SignalMaskLength'} );    # convert $staticSigVal to unsigned if it is -ve.
                return unless ($values);
            }
            $val_bin = sprintf( "%b", ($values) );
            @value_bin_array = reverse split( //, $val_bin );
            $dec_flag = 1;
        }

        my @mask_bitarray = split( //, $mask_bin );
        my $binary_values = [];
        push( @$binary_values,         @mask_bitarray );
        push( @collective_signal_mask, $mask_bin );
        my @actual_value_bin;
        my $mask_length = 0;

        if ( ( $hex_flag == 1 and $binary_flag == 1 ) or ( $dec_flag == 1 and $binary_flag == 1 ) ) {
            S_set_error( "_Combine_signal_mask_and_value: Do not combine hex and integer format with binary format!", 109 );
            return;
        }

        # prepare combined value in the binary format
        foreach my $bit ( reverse 0 .. $#mask_bitarray ) {

            if ($binary_flag) {
                if ( $binary_values->[$bit] == 1 and length $val_bin > 0 ) {
                    $binary_values->[$bit] = chop $val_bin;
                    $value_position_str{$bit} = '#' . $bit;
                }
                elsif ( $binary_values->[$bit] == 1 and length $val_bin == 0 ) {
                    $binary_values->[$bit] = '-';    # 'don't care'
                }
            }
            else {

                if ( $mask_bitarray[$bit] == 1 and @value_bin_array != 0 ) {
                    unshift( @actual_value_bin, shift(@value_bin_array) );
                    $mask_length++;
                }
                elsif ( ( $mask_bitarray[$bit] == 0 and $mask_length > 0 )
                    and ( @value_bin_array != 0 ) )
                {
                    S_set_error( "The signal value '$signals_and_values_href->{$signal}' is greater than the signal mask", 109 );
                    return;
                }
                else {
                    unshift( @actual_value_bin, 0 );
                }
            }

        }

        my $bin_value = 0;
        if ($binary_flag) {
            $bin_value = join( '', @$binary_values );
            push( @$binary_values_aref, $bin_value );
        }

        unless ($binary_flag) {
            my $actual_val_bin = join( '', @actual_value_bin );
            $value = $value | $actual_val_bin;
        }
    }

    # With bit-wise OR, combine the masks of all signals to one overall mask
    # Result stored in $signal_mask_bin which is initialized with 0's
    my $signal_mask_bin = '';
    foreach my $bitInInstruction ( 1 .. $instructionLength_Bit ) { $signal_mask_bin .= '0' }

    foreach my $signal_mask (@$signal_mask_aref) {
        $signal_mask_bin = $signal_mask | $signal_mask_bin;
    }

    # prepare combined mask
    my ( $mask_start_pos, $mask_end_pos );
    my $hex_mask = $signal_mask_bin;
    if ( $signal_mask_bin =~ /^(0*)([1]+)(0*)$/ ) {
        my $pre_mask  = $1;
        my $mask      = $2;
        my $post_mask = $3;
        $mask_start_pos = length($pre_mask);
        $mask_end_pos   = $mask_start_pos + length($mask);

        $value = substr( $value, $mask_start_pos, ( $mask_end_pos - $mask_start_pos ) );

        if ($hex_flag) {
            $signals_value = '0x' . sprintf( "%.X", oct( "0b" . $value ) );
        }
        else {
            $signals_value = sprintf( "%d", oct( "0b" . $value ) );
        }
        $signalMaskHex = sprintf( "%." . $instructionLength_Nibble . "X", oct( "0b" . $signal_mask_bin ) );
    }
    elsif ( $signal_mask_bin =~ /(.*1)(0*)/ ) {
        my $mask_bits = $1;
        $mask_end_pos = length($mask_bits);
        my $unmasked_bits = $2;
        $mask_bits =~ m/1/g;
        $mask_start_pos = $-[0];    #match the starting position of mask bit from left. example: 0100 --> mask bit position 1 ( count starts from 0)
        substr( $mask_bits, $mask_start_pos, ( $mask_end_pos - $mask_start_pos ), 1 x ( $mask_end_pos - $mask_start_pos ) );
        $signal_mask_bin = $mask_bits . $unmasked_bits;
        $signalMaskHex   = sprintf( "%." . $instructionLength_Nibble . "X", oct( "0b" . $signal_mask_bin ) );
        $value           = substr( $value, $mask_start_pos, ( $mask_end_pos - $mask_start_pos ) );

        if ($hex_flag) {

            $signals_value = '0x' . sprintf( "%X", oct( "0b" . $value ) );
        }
        else {
            $signals_value = sprintf( "%d", oct( "0b" . $value ) );
        }

    }

    #prepare the binary mask and value
    if ($binary_flag) {
        my $mask_bit_pos = {};
        my $mask_length  = $instructionLength_Bit;
        my @temp_mask    = (0) x $mask_length;
        my $size         = @$binary_values_aref;
        foreach my $ele ( 0 .. ( $size - 1 ) ) {
            my @bin_values  = split( //, $binary_values_aref->[$ele] );
            my @signal_mask = split( //, $collective_signal_mask[$ele] );
            foreach my $bit_pos ( 0 .. $#bin_values ) {
                if ( $signal_mask[$bit_pos] == 1 ) {
                    $temp_mask[$bit_pos] = $bin_values[$bit_pos];
                    $mask_bit_pos->{$bit_pos} = 1;
                }
            }
        }

        my @sig_mask = split( //, $signal_mask_bin );
        foreach my $position ( 0 .. $#sig_mask ) {
            if ( !exists( $mask_bit_pos->{$position} ) and $sig_mask[$position] == 1 ) {
                $temp_mask[$position] = '-';
            }

        }
        my $binary_str = join( '', @temp_mask );
        $binary_str    = substr( $binary_str, $mask_start_pos, ( $mask_end_pos - $mask_start_pos ) );
        $binary_str    = '0b' . $binary_str;
        $signals_value = $binary_str;
    }

    unless ($binary_flag) {
        $signal_mask_bin = $hex_mask;
        $signalMaskHex = sprintf( "%." . $instructionLength_Nibble . "X", oct( "0b" . $signal_mask_bin ) );

    }

    return ( $signalMaskHex, $signals_value );
}

=head1 Function Group 'trace'


=head2 SPI_trace_start

    my $traceStartSuccessful = SPI_trace_start( [, $devices_aref] );

    Calls device function for starting SPI trace.
    Device configured in LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'trace'

Devices supported: Manitoo


B<Arguments:>

=over

=item $devices_aref

      array ref of logical SPI device names out of Mapping_SPI_network.pm 
      ( e.g. [ 'Cobra_Main' , 'SMA660' ] )
      
      or 
      
      array ref of combinations of SPI:CS ( Spi bus nbr and Chip Select )
      ( e.g. [ '1:0' , '1:1' , '1:2' ] )
      
      NOTE : if no argument given -> all configured devices from Mapping_SPI_network.pm will be measured
      

=back

B<Returns:>

Success: Returns the value from CallDeviceFunction.

Failure: undef

B<Examples:>

   # measure ALL SPI devices which are configured in Mapping_SPI_network.pm
   SPI_trace_start( );  

   # measure the given SPI devices which are configured in Mapping_SPI_network.pm
   SPI_trace_start( [ 'Cobra_Main' , 'Cobra_Plausi' , 'SMA660' ] );   

   # measure the given combination of SPI:CS  (bus nbr and Chip select)
   # SPI=1 CS=0  + SPI=1 CS=1 + SPI=1 CS=2
   SPI_trace_start( [ '1:0' , '1:1' , '1:2' ] );   

=cut

sub SPI_trace_start {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPI_trace_start( [, $devices_aref] )', @args );
    my $devices_aref = shift;

    return unless ( Check_init() );

    my $nodes_info_spi_cs_aref = [];

    # read first all SPI node names from Mapping_SPI
    my $all_spi_network_node_names_aref = $spiDatabase_Object->GetAllSpiNetworkNodeNames();

    unless ($devices_aref) {
        S_w2log( 4, " SPI_trace_start: no specific SPI nodes given -> configure all from Mapping_SPI\n" );
        $devices_aref = $all_spi_network_node_names_aref;
    }

    foreach my $spi_node (@$devices_aref) {
        if ( $spi_node =~ /^(\d+):(\d+)$/ ) {
            my $spi_nbr       = $1;
            my $cs            = $2;
            my $spi_node_name = $spiDatabase_Object->GetNodeName_NOERROR( $cs, $spi_nbr );    # trying to get the SPI node name , even when just SPI:CS is given
            $spi_node_name = " - SPI node name is '$spi_node_name'" if defined $spi_node_name;
            S_w2log( 3, " SPI_trace_start : Configure trace SPI:CS format ($spi_nbr:$cs) $spi_node_name \n" );
            push( @$nodes_info_spi_cs_aref, "$spi_nbr:$cs" );
        }
        else {
            unless ( grep { /^$spi_node$/ } @$all_spi_network_node_names_aref ) {
                S_set_error("Given SPI node '$spi_node' doesnt exist in Mapping_SPI database");
                return;
            }

            my ( $cs, $spi_nbr ) = $spiDatabase_Object->GetNodeBusDetails($spi_node);
            return unless ( defined $cs && defined $spi_nbr );
            S_w2log( 3, " SPI_trace_start : Configure SPI Node '$spi_node' ( $spi_nbr:$cs [SPI:CS] )\n" );
            push( @$nodes_info_spi_cs_aref, "$spi_nbr:$cs" );
        }
    }

    return CallDeviceFunction($nodes_info_spi_cs_aref);
}

=head2 SPI_trace_stop

    my $traceStatusSize = SPI_trace_stop();

    Calls device function for stopping SPI trace and return captured size in bytes.
    Device configured in LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'trace'

    Devices supported: Manitoo

B<Examples:>

    $size_in_bytes = SPI_trace_stop();

=cut

sub SPI_trace_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SPI_trace_stop( )', @args );

    #STEP call the respective stop trace function of device layer module configured in test bench, possible devices (SPIMaid and LA_AcuteTravelLogic)
    #CALL CallDeviceFunction
    #STEP return the value from CallDeviceFunction
    return unless ( Check_init() );
    return CallDeviceFunction(@args);
}

=head2 SPI_trace_store

    $return_traceFileNamePath = SPI_trace_store( [, $store_file_name , $nbr_leading_spi_frames , $nbr_follow_spi_frames ] );

B<Description:>

Calls device function for storing the SPI trace.

    Device configured in LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'trace'

B<Devices supported: Manitoo>

Trace file can be stored in three ways:

    1. Default the trace file will be stored in reports folder.

       SPI_trace_store();

       SPI_trace_store( 'USE_DEFAULT' );   # is the same

    2. trace file will be stored in the reports folder with given name.

       SPI_trace_store(  'SPI_TRACE.mbt' )

    3. Complete file path configured as argument  trace file will be stored in the path given

       SPI_trace_store(  'D:/Turbolift/TSG4/trace/SPI_TRACE.mbt' )

B<Arguments:>

=over

=item $store_file_name 

(optional) name of the Trace file. If not given then it will be stored under report folder. If default file name shall be generated and the trace size shall be adapted with following options use filename 'USE_DEFAULT'

=item $nbr_leading_spi_frames

(optional) integer nbr of leading (before manipulated region) SPI frames for SPI trace size reduction 

=item $nbr_follow_spi_frames

(optional) integer nbr of following (after manipulated region) SPI frames for SPI trace size reduction 

=back

B<Return:>

    Success:  $return_traceFileNamePath : complete <path>/<filename>   of trace file
    
    Error : undefined   

B<Examples:>

1. Default trace storage in report folder

   $return_traceFileNamePath = SPI_trace_store();

2. Only file name which will be stored in reports folder, 
   template file given for the label names

   SPI_trace_store( 'SPI_TRACE.mbt' )

3. Complete file path and template file configured as argument,
   trace file will be stored in the path given
   template file given for the label names.

   SPI_trace_store( 'D:/Turbolift/TSG4/trace/SPI_TRACE.mbt' )

4. Default trace storage in report folder , 
   trace_resizing with 
   5000 leading SPI frames and 
   7000 following SPI frames

   SPI_trace_store( 'USE_DEFAULT' , 5000 , 7000 )

=cut

sub SPI_trace_store {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPI_trace_store( [ $store_file_name , $nbr_leading_spi_frames , $nbr_follow_spi_frames ] )', @args );

    #STEP call the respective store trace function of device layer module configured in test bench, possible devices (Manitoo)
    #CALL CallDeviceFunction
    #STEP return the value from CallDeviceFunction
    return unless ( Check_init() );
    return CallDeviceFunction(@args);
}

=head2 SPI_trace_load_file

    SPI_trace_load_file  ( 'MeasurementLabel' => '$measurementLabel', # unique measurement label
                           'FileName' => "$traceFilePath", # complete measurement file path and name
                           'FirstTimeStampIsZero' => $firstTimeStampIsZero );

B<Description:>

Trace from Device will be loaded and stored in unified format (XML)
The XML file will be created by LIFT_spi_access to following form:

    <?xml version="1.0" encoding="utf-8"?>
    <SPI_Measurement>
      <MeasurementLabel>MyFirstMeasurement</MeasurementLabel>
    </SPI_Measurement>


Next, the device specific function (device configured in function group 'SPI_Access' -> 'trace')
will be called.
The device specific implementation shall fill the created XML (XML handle will be handed over)
with the measurement points obtained.
All information must be gien as attributes.
Following will be the result, e.g. from SPIMaid:

    <?xml version="1.0" encoding="utf-8"?>
    <SPI_Measurement>
      <MeasurementLabel>MyFirstMeasurement</MeasurementLabel>
      <MeasurementPoint MessageNumber="0" Time="0" MOSI_Hex="ff00ff00" MISO_Hex="00000000" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="1" Time="0.00531249999994543" MOSI_Hex="2080004c" MISO_Hex="00000000" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="2" Time="0.0106375000000298" MOSI_Hex="20000010" MISO_Hex="280a5028" ChipSelect="2" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="3" Time="0.0189000000000306" MOSI_Hex="ff00ff00" MISO_Hex="00000000" ChipSelect="3" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="4" Time="0.024212499999976" MOSI_Hex="2080004c" MISO_Hex="00000000" ChipSelect="3" FrameLength_Bits="32"/>
      <MeasurementPoint MessageNumber="5" Time="0.0295375000000604" MOSI_Hex="20000010" MISO_Hex="280a5028" ChipSelect="3" FrameLength_Bits="32"/>
    </SPI_Measurement>

If trace device is Manitoo:

    Trace data will be captured in MOBI format.
    Each frame of MOBI contains 64 bit data only,
    if the SPI data is more than 64 bits then mobi frame data is concatenated and
    converted into one SPI frame, by making use of toggle bit in MOBI frame.

Example:

    <?xml version="1.0" encoding="utf-8"?>
    <SPI_Measurement>
      <MeasurementLabel>My_SPI_Measurement_grt_32</MeasurementLabel>
      <MeasurementPoint MessageNumber="47" Time="621.953" MOSI_Hex="2b02" MISO_Hex="ff00" ChipSelect="6" FrameLength_Bits="16" ToolsID="1" FrameManipulated="false"/>
      <MeasurementPoint MessageNumber="35" Time="211.832" MOSI_Hex="03000022000000000000" MISO_Hex="ffffffff000013136fcb" ChipSelect="6" FrameLength_Bits="80" ToolsID="1" FrameManipulated="false"/>
    </SPI_Measurement>

B<Arguments:>

=over

=item $measurementLabel

Name of the measurement. It must be unique.

=item $traceFilePath

complete measurement file path and name (.dat file for SPIMaid .mbt for Manitoo).

=item $firstTimeStampIsZero

( optional ) If set to '0' Measurement with actual timestamps.
             If set to '1' Measurement will be shifted to start with timestamp 0.

=back

B<Returns:> creates a xml file and returns the measurement label.

B<Examples:>

    # trace device SPIMaid
    SPI_trace_load_file('MeasurementLabel' => 'My_SPI_Measurement',
                        'FileName' => "C:\\Manitoo\\SPI_Maid\\150331_151550.dat",
                        'FirstTimeStampIsZero' => 0,
                        );

    # trace device Manitoo
    SPI_trace_load_file('MeasurementLabel' => 'My_SPI_Measurement',
                        'FileName' => "C:\\Manitoo\\SPI_Maid\\150331_151550.mbt",
                        'FirstTimeStampIsZero' => 0,
                        );

=cut

sub SPI_trace_load_file {
    my @args   = @_;
    my $params = {@args};
    my $firstTimeStampIsZero;

    my $traceFilePath    = $params->{'FileName'};
    my $measurementLabel = $params->{'MeasurementLabel'};
    if ( defined $params->{'FirstTimeStampIsZero'} ) {
        $firstTimeStampIsZero = $params->{'FirstTimeStampIsZero'};
    }
    else {
        $firstTimeStampIsZero = 0;
    }

    return unless S_checkFunctionArguments( 'SPI_trace_load_file ( $traceFilePath , $measurementLabel [, $firstTimeStampIsZero])', ( $traceFilePath, $measurementLabel, $firstTimeStampIsZero ) );

    return unless ( Check_init() );

    unless ( -e $traceFilePath ) {
        S_set_error("Given trace file '$traceFilePath' does not exist.");
        return;
    }

    #get trace device configured
    my $trace_device = $LIFT_config::LIFT_Testbench->{'Functions'}{'SPI_Access'}{'trace'};
    if ( $traceFilePath =~ /(.*)\.dat$/i and $trace_device eq 'Manitoo' ) {
        S_set_error("SPI_trace_load_file: $traceFilePath Wrong trace file type configured, Correct format is .dat for SPIMaid and .mbt for Manitoo");
        return;
    }
    if ( $traceFilePath =~ /(.*)\.mbt$/i and $trace_device eq 'SPIMaid' ) {
        S_set_error("SPI_trace_load_file: $traceFilePath Wrong trace file type configured, Correct format is .dat for SPIMaid and .mbt for Manitoo");
        return;
    }
    S_w2log( 1,       "Starting SPI_trace_load_file...\n" );
    S_w2log( CONSOLE, "SPI_trace_load_file: This may take a while for big measurements!!\n" );
    S_w2log( 3,       "SPI_trace_load_file: Check whether measurement with same label already exists\n" );
    if ( exists $loadedMeasurements_href->{$measurementLabel} ) {
        if ( $traceFilePath eq $loadedMeasurements_href->{$measurementLabel}->{"OriginalMeasurementFileName"} ) {
            S_w2log( 3, "SPI_trace_load_file: Same measurement file has already been loaded. Nothing to do." );
            return $measurementLabel;
        }

        S_set_warning("Measurement with same label already exists for a different measurement file. '_TimeStamp' will be appended to label.");
        $measurementLabel = $measurementLabel . "_" . time();
        S_w2log( 3, "SPI_trace_load_file: Measurement label changed to $measurementLabel", 'red' );
    }

    my $measurementXML = _create_measurement_XML($measurementLabel);
    unless ($measurementXML) {
        S_set_error("Could not create XML file for measurement $measurementLabel (file path: $traceFilePath");
        return;
    }

    $measurementXML = CallDeviceFunction( ( $traceFilePath, $measurementLabel, $firstTimeStampIsZero, $measurementXML ) );
    unless ($measurementXML) {
        S_set_error("Device function could not fill XML file for measurement $measurementLabel (file path: $traceFilePath");
        return;
    }
    S_w2log( 4, " SPI_trace_load_file: Fill (upddate) measurement_XML Label : $measurementLabel \n" );
    _update_measurement_XML( $measurementLabel, $measurementXML );

    $loadedMeasurements_href->{$measurementLabel}->{"OriginalMeasurementFileName"} = $traceFilePath;
    S_w2log( 2, " SPI_trace_load_file: Reading $traceFilePath done\n" );

    #returns the measurement label
    return $measurementLabel;
}

=head2 SPI_trace_get_dataref

    my $measurment_href = SPI_trace_get_dataref('MeasurementLabel' => $measurementLabel,
                                                'SPI_Node' => $spiNode,
                                                'StartTime_ms' => $startTime,
                                                'EndTime_ms' => $endTime);

B<Description:> 

This function extracts the SPI data of node given. Function SPI_trace_load_file has to be called before calling this function.

SPI measurements can quickly become very large because the time between data samples is very short (few micro seconds).
Therefore it is recommended to filter the data to be extracted by:
- giving a specific SPI node as input parameter, e.g. 'Cobra_M'
- only SPI frames sent by that node will be considered.

Supports two formats:
1. 'Start time' and 'end time'.
    - giving a start and end time to define a small interval within a big measurement
    - only data sent on SPI within that time interval will be decoded and returned

2. 'Start command' and 'time offset after start command'.
    - giving the command as offset and the offset time from the command as reference.

B<Arguments:> 

=over

=item $measurementLabel

Name of the Measurement as given in SPI_trace_load_file function.

=item $spiNode

Node name as given in SPI_trace_load_file function.

=item $startTime

( optional ) Start time in milli seconds.

=item $endTime

( optional ) End time in milli seconds.

=item $startCommand

(optional) The command name from where the offset has to be started.

=item $offsetFromStartCommand_ms

(optional) The offset time in milli seconds after the start command.

=back

B<NOTE:> 

1. If none of the options are configured then complete data will be returned.

2. Any B<one> of the type can be used B<Not both> the type of arguments
    1. $startTime and $endTime.
                or 
    2. $startCommand and $offsetFromStartCommand_ms.

B<Return Value:> 

Returns a data reference in the standard TurboLIFT format which can be used as input for EVAL_ functions.

B<use case 1: > Get data in the time range 3581ms to 3583ms.

    $measurement_href = SPI_trace_get_dataref('MeasurementLabel' => 'measurement_1',
                                              'SPI_Node' => 'SMI7',
                                              'StartTime_ms' => 3581,
                                              'EndTime_ms' => 3583);
    $measurement_href = {
                           '3582.4400125' => {
                              'MODULE COMMAND__Write::MOSI::Data' => '147',
                              'MODULE COMMAND__Write::MISO::Page' => '0',
                              'MODULE COMMAND__Write' => '1',
                              },
                           '3582.4448125' => {
                              'MODULE COMMAND__Read Data::MOSI::Adr' => '5',
                              'MODULE COMMAND__Read Data::MISO::MIDSMI710_1' => '1',
                              'MODULE COMMAND__Read Data::MOSI::Page' => '0',
                              'MODULE COMMAND__Read Data::MISO::Page' => '0',
                              },
                           '3584.02' => {
                           	  'FrameManipulated' => '1',
                              'MODULE COMMAND__Read Data::MOSI::Adr' => '5',
                              'MODULE COMMAND__Read Data::MISO::MIDSMI710_1' => '1',
                              'MODULE COMMAND__Read Data::MOSI::Page' => '0',
                              'MODULE COMMAND__Read Data::MISO::Page' => '0',
                              'OriginalData' => {
	                              'MODULE COMMAND__Read Data::MOSI::Adr' => '10',
	                              'MODULE COMMAND__Read Data::MISO::MIDSMI710_1' => '1',
	                              'MODULE COMMAND__Read Data::MOSI::Page' => '0',
	                              'MODULE COMMAND__Read Data::MISO::Page' => '0',
                              },
                           },
                        }

=cut

sub SPI_trace_get_dataref {
    my @args   = @_;
    my $params = {@args};

    my $measurementLabel          = $params->{'MeasurementLabel'};
    my $spiNode                   = $params->{'SPI_Node'};
    my $startTime                 = $params->{'StartTime_ms'};
    my $startCommand              = $params->{'StartCommand'};
    my $offsetFromStartCommand_ms = $params->{'TimeOffsetStartCommand_ms'};
    my $endTime                   = $params->{'EndTime_ms'};

    return unless S_checkFunctionArguments( 'SPI_trace_get_dataref ( $measurementLabel [, $spiNode, $startTime, $startCommand, $offsetFromStartCommand_ms, $endTime])', ( $measurementLabel, $spiNode, $startTime, $startCommand, $offsetFromStartCommand_ms, $endTime ) );

    return unless ( Check_init() );

    unless ($spiDatabase_Object) {
        S_set_error("SPI_trace_get_dataref called without initializing SPI database. Call SPI_init first!");
        return;
    }

    if ( ( defined $startTime and defined $endTime ) and ( defined $startCommand or defined $offsetFromStartCommand_ms ) ) {
        S_set_error("Only one format should be used to get data: 1. Start and End time! ( or ) 2. Start command and offset!");
        return;
    }

    if ( ( defined $startCommand and defined $offsetFromStartCommand_ms ) and ( defined $startTime or defined $endTime ) ) {
        S_set_error("Only one format should be used to get data: 1. Start and End time! ( or ) 2. Start command and offset!");
        return;
    }

    unless ( defined $startTime ) {
        $startTime = 'START';
    }

    unless ( defined $endTime ) {
        $endTime = 'END';
    }
    S_w2log( 1,       "Starting SPI_trace_get_dataref...\n" );
    S_w2log( CONSOLE, "SPI_trace_get_dataref: This may take a while for big data structures...\n" );
    my $measurementFilePath = $loadedMeasurements_href->{$measurementLabel}->{"XML_FilePath"};
    S_w2log( 2, "Measurement file path: $measurementFilePath\n" );
    unless ($measurementFilePath) {
        S_set_error( "No measurement with label '$measurementLabel' loaded." . "Call SPI_trace_load_file(\$filename, \$measurementLabel) with \$measurementLabel = '$measurementLabel' first" );
        return;
    }

    # parse the summary XML file and get the reference of Document root element
    my $parser = XML::LibXML->new();
    unless ( defined $parser ) { S_set_error("could not create  XML::LibXML->new() : $! "); return }

    # important for formatting
    $parser->keep_blanks(0);

    # load the existing XML file
    my $measurementXML = $parser->load_xml( location => $measurementFilePath );
    unless ( defined $measurementXML ) { S_set_error("could not parser->load_xml( location => $measurementFilePath : $! "); return }

    # get the reference to root element
    my $rootElement = $measurementXML->documentElement;
    unless ( defined $rootElement ) { S_set_error("could not get measurementXML->documentElement"); return }

    my $xpc = XML::LibXML::XPathContext->new($rootElement);
    unless ( defined $xpc ) { S_set_error("could not get XML::LibXML::XPathContext->new "); return }

    # get time offset
    my @timeOffsetNodes = $xpc->findnodes("//TimeOffset");
    my $timeOffset;

    foreach my $timeOffsetNode (@timeOffsetNodes) {
        $timeOffset = $timeOffsetNode->textContent();
        if ( defined $timeOffset ) {
            S_w2log( 3, " SPI_trace_get_dataref: time offset = $timeOffset (node: $spiNode) \n" );
            last;
        }
    }

    if ( not defined $timeOffset ) {
        S_w2log( 3, " SPI_trace_get_dataref: time offset not defined -> set to 0 (default)\n" );
        $timeOffset = 0;
    }

    # get all measurement points
    my @measurementPointNodes = $xpc->findnodes("//MeasurementPoint");
    S_w2log( 3, " SPI_trace_get_dataref: Found " . scalar @measurementPointNodes . " measure points in XML file\n" );
    my $allTimeStampsDecoded_href;

    return { '0.1' => { 'ABC' => 42 } } if $main::opt_offline;

    foreach my $measurementPointNode (@measurementPointNodes) {

        # start and end time
        my $timeValue = $measurementPointNode->getAttribute('Time');
        $timeValue -= $timeOffset;    # subtract time offset
        next if ( ( not $startTime eq 'START' and $timeValue < $startTime )
            or ( not $endTime eq 'END' and $timeValue > $endTime ) );

        # get device
        my $chipSelect = $measurementPointNode->getAttribute('ChipSelect');

        #        my $nodeName   = $spiDatabase_Object->GetNodeName_NOHTML($chipSelect);
        my $nodeName = $spiDatabase_Object->GetNodeName($chipSelect);
        if ( not defined $nodeName ) {
            S_set_error("No node name defined for chip select '$chipSelect'");
            return;
        }

        if ( not defined $spiNode or $nodeName eq $spiNode ) {
            my $value_MOSI       = $measurementPointNode->getAttribute('MOSI_Hex');
            my $value_MISO       = $measurementPointNode->getAttribute('MISO_Hex');
            my $frameLength_Bits = $measurementPointNode->getAttribute('FrameLength_Bits');

            my ( $thisFrameSignalValues, $commandLabelWithSubCommands ) = $spiDatabase_Object->Interpret_SPI_Frame( $nodeName, $value_MOSI, $value_MISO, $frameLength_Bits );

            my ( $mosiHex, $misoHex );

            $mosiHex = $nodeName . '::' . $commandLabelWithSubCommands . '::' . 'MOSI_Hex' if ( $value_MISO and $commandLabelWithSubCommands );
            $misoHex = $nodeName . '::' . $commandLabelWithSubCommands . '::' . 'MISO_Hex' if ( $value_MISO and $commandLabelWithSubCommands );

            my $frameManipulated = $measurementPointNode->getAttribute('FrameManipulated');
            my $frameType;
            if ( defined $frameManipulated and $frameManipulated eq 'true' ) {
                $frameType = 'Manipulated';
            }
            else {
                $frameType = 'NotManipulated';
            }

            if ( defined $startCommand and $startCommand eq $commandLabelWithSubCommands ) {
                $allTimeStampsDecoded_href->{$frameType}->{$timeValue} = $thisFrameSignalValues;
                $startCommand = undef;
                $endTime = $timeValue + $offsetFromStartCommand_ms if ( defined $offsetFromStartCommand_ms );
            }
            elsif ( not defined $startCommand ) {
                $allTimeStampsDecoded_href->{$frameType}->{$timeValue} = $thisFrameSignalValues;
            }
            $allTimeStampsDecoded_href->{$frameType}->{$timeValue}{$mosiHex} = $value_MOSI if ($mosiHex);
            $allTimeStampsDecoded_href->{$frameType}->{$timeValue}{$misoHex} = $value_MISO if ($misoHex);
        }
    }

    unless ($allTimeStampsDecoded_href) {
        S_set_error(
            "No data could be obtained for given measurement label ('$measurementLabel').\n" . "Is given node '$spiNode' (if given) part of the measurement?.\n" . "Is given time range $startTime - $endTime ms (if given) part of the measurement? \n Is same chip select assigned for two nodes?" );
        return;
    }

    my $measurement_href;
    if ( defined $allTimeStampsDecoded_href->{'Manipulated'} ) {

        # merge manipulated frames into result href, keep details on manipulation separate
        foreach my $timeStamp ( keys %{ $allTimeStampsDecoded_href->{'NotManipulated'} } ) {
            if ( defined $allTimeStampsDecoded_href->{'Manipulated'}->{$timeStamp} ) {

                # Overwrite not manipulated with manipulated value
                $measurement_href->{$timeStamp}                       = $allTimeStampsDecoded_href->{'Manipulated'}->{$timeStamp};
                $measurement_href->{$timeStamp}->{'FrameManipulated'} = 1;
                $measurement_href->{$timeStamp}->{'OriginalValue'}    = $allTimeStampsDecoded_href->{'NotManipulated'}->{$timeStamp};
            }
            else {
                $measurement_href->{$timeStamp} = $allTimeStampsDecoded_href->{'NotManipulated'}->{$timeStamp};
            }
        }
    }
    else {
        $measurement_href = $allTimeStampsDecoded_href->{'NotManipulated'};
    }

    # returns the data requested in hashref format
    return $measurement_href;
}

=head1 Function Group 'logicanalyzer'

=head2 SPI_logicanalyzer_start

    my $traceStartSuccessful = SPI_logicanalyzer_start( [, $args_href] );

    Calls device function for starting SPI logic analyzer dump.
    Device configured in LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'logicanalyzer'

Devices supported: LA_AcuteTravelLogic

B<Note: Configuration for LA_AcuteTravelLogic can be made in 'Mapping_LA_AcuteTravelLogic.pm' or 
        can be passed as arguments to this function (which is not recommended) >

B<Arguments:>

=over

=item $args_href

    {

     'pinNames'       => [<text>, <text>, ...], # [REQUIRED] list of pin names,
                                                # (triggerPinName has to be included in list!)
                                                # (as defined in ProjectConst, section 'LA_AcuteTravelLogic')
    
     'triggerPinName' => <text>, # [REQUIRED, if triggerEdge unequal 'dontcare' 
                                 # otherwise OPTIONAL]
                                 # Any of the pin names given
                                 
     'triggerEdge'    => <text|int>, # [REQUIRED]
                                     # text: 'falling'|'rising'|'low'|'high'|'change'|'dontcare'
                                     # (dontcare = immediate trigger)
    
     'hwMode'         => <text>,     # [OPTIONAL]
                                     # (default: 'HW_200M_32CH_TR' = 200 MHz, 
                                     # transitional mode, 32 ch)
                                        'HW_4G_36CH'
                                        'HW_4G_18CH'
                                        'HW_4G_9CH'
                                        'HW_4G_4CH'
                                        'HW_2G_36CH'
                                        'HW_1600M_4CH'
                                        'HW_800M_9CH'
                                        'HW_400M_18CH'
                                        'HW_200M_36CH'
                                        'HW_200M_18CH'
                                        'HW_200M_12CH'
                                        'HW_200M_9CH'
                                        'HW_200M_6CH'
                                        'HW_200M_4CH'
                                        'HW_200M_2CH'
                                        'HW_200M_1CH'
                                        'HW_200M_32CH_TR'
                                        'HW_200M_8CH_TR'
     
     Note: The last two hwModes named '..._TR' are transitional modes with longer recording time
    
     'numSamples_perCh'   => <int>, # [OPTIONAL] default: max. available memory
     'postTriggerSize_pct => <int>, # [OPTIONAL] default: 90%

    }

=back

B<Returns:>

Success: Returns the value from CallDeviceFunction.

Failure: undef

B<Examples:>

1. Configuration for LA_AcuteTravelLogic done in 'Mapping_LA_AcuteTravelLogic.pm'

   SPI_logicanalyzer_start();
   
   In this case the element $Defaults->{'LA_AcuteTravelLogic'} must be defined and included as as part of ProjectDefaults.
   
   'LA_AcuteTravelLogic' => {
                              << see hash content as described above >>
       
                             }
                             
    Example is available in MKS project MRT.prj -> config -> mappings -> Mapping_LA_AcuteTravelLogic.pm

2. Configuration passed as arguments

   SPI_logicanalyzer_start( { 
                      'pinNames' => ['21_MOSI1', '22_MISO1_ASIC', 'MISO1_CPU', 
                                     '14_SCK_1', '24_CONTROL_MUX', '20_CS0_COBRA_M'],
                      'triggerPinName'      => '24_CONTROL_MUX',
                      'triggerEdge'         => 'rising',
                      'hwMode'              => 'HW_200M_36CH',
                      'numSamples_perCh'    => 2000,
                      'postTriggerSize_pct' => 90  } );

=cut

sub SPI_logicanalyzer_start {
    my @args = @_;

    #STEP call the respective start trace function of device layer module configured in test bench, possible devices (LA_AcuteTravelLogic)
    #CALL CallDeviceFunction
    #STEP return the value from CallDeviceFunction
    return unless S_checkFunctionArguments( 'SPI_logicanalyzer_start( [,$args_href] )', @args );
    return unless ( Check_init() );
    return CallDeviceFunction(@args);
}

=head2 SPI_logicanalyzer_stop

	my $traceStopSuccessful = SPI_logicanalyzer_stop();

    Calls device function for stopping SPI trace.
    Device configured in LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'logicanalyzer'

Devices supported: LA_AcuteTravelLogic

B<Examples:>

    SPI_logicanalyzer_stop();

=cut

sub SPI_logicanalyzer_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'SPI_logicanalyzer_stop( )', @args );

    #STEP call the respective stop trace function of device layer module configured in test bench, possible devices (LA_AcuteTravelLogic)
    #CALL CallDeviceFunction
    #STEP return the value from CallDeviceFunction
    return unless ( Check_init() );
    return CallDeviceFunction(@args);
}

=head2 SPI_logicanalyzer_store

    $stored_file_name = SPI_logicanalyzer_store( [, $store_file_name, $template_file_path] );

B<Description:>

Calls device function for storing the SPI trace.

    Device 'LA_AcuteTravelLogic' configured in 
		LIFT_Testbenches -> 'Functions' -> 'SPI_Access' -> 'logicanalyzer'
	
	Additional settings are possible in 
	package LIFT_PROJECT;
	$Defaults->{'LA_AcuteTravelLogic'} = {


See SYNOPSIS of LIFT_LA_AcuteTravelLogic.pm


B<Devices supported: LA_AcuteTravelLogic>

Trace file can be stored in three ways:

    1. Default the logic analyzer dump file will be stored in reports folder.

       SPI_logicanalyzer_store();

	   used Default result file is : <TC_name>_SPI_LA_DUMP.law
	   used Default template setting is coming from : 
	   $Defaults->{'LA_AcuteTravelLogic'} => { 'fileNameTemplate' => ... }
	   ( See also SYNOPSIS of LIFT_LA_AcuteTravelLogic )

		This usage is recommended
	   
    2. Only file name passed as argument
       trace file will be stored in the reports folder with given name.
	   (consider that result files in report folder must have always different names).
	   Template is taken as default from  'LA_viewer_template' in LIFT_testbenches.pm

       SPI_logicanalyzer_store(  'SPI_TRACE_12345.law' )

    3. Complete file path configured as argument
       logic analyzer dump file will be stored in the path given.
	   Specific template is given

       SPI_logicanalyzer_store(  'D:/Turbolift/TSG4/trace/SPI_TRACE.law', 'C:/Sandbox/Template/config/Tools/LA_AcuteTravelLogic/SPI_Template_Example.law' )

B<Arguments:>

=over

=item $store_file_name 

(optional) name of the logic analyzer file. If not given then it will be stored under report folder.

=item $template_file_path

(optional) name of the template file from where the labels for the channel names will be taken for the plot.

=back

B<Return:>

Success: $stored_file_name 

B<Examples:>

1. Default logic analyzer dump storage in report folder

   $stored_file_name = SPI_logicanalyzer_store();
   
2. Only file name which will be stored in reports folder, 
   template file given for the label names

   $stored_file_name = SPI_logicanalyzer_store( 'SPI_TRACE.law', 'C:/Sandbox/Template/config/Tools/LA_AcuteTravelLogic/SPI_Template_Example.law' )

3. Complete file path and template file configured as argument,
   logic analyzer dump file will be stored in the path given
   template file given for the label names.

   $stored_file_name = SPI_logicanalyzer_store( 'D:/Turbolift/TSG4/trace/SPI_TRACE.law', 'C:/Sandbox/Template/config/Tools/LA_AcuteTravelLogic/SPI_Template_Example.law' )

=cut

sub SPI_logicanalyzer_store {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SPI_logicanalyzer_store( [, $store_file_name, $template_file_path] )', @args );

    #STEP call the respective store trace function of device layer module configured in test bench, possible devices (LA_AcuteTravelLogic)
    #CALL CallDeviceFunction
    #STEP return the value from CallDeviceFunction
    return unless ( Check_init() );
    return CallDeviceFunction(@args);
}

=head1 Evaluation functions

=head2 SPI_EVAL_check_command_sequence

    my ($thisVerdict, 
        $detectedSequence_aref,
        $cmd_details_href)      = SPI_EVAL_check_command_sequence(
                                      'MeasurementData_href' => $measdata_href,
                                      'CommandList' => $expectedCommands_aref,
                                      'GetCmdDetails' => $cmd_details_flag,
                                      'FirstCmdOccuranceIndex' => $firstCmdOccuranceIndex,
                                      'PreCmdToStartEvalSeq' => $preCmdToStartEvalSeq  );

B<Description:> This function evaluates the sequence of commands.

B<Arguments:>

=over

=item $measdata_href

Hash data ref which can be obtained with SPI_trace_get_dataref

    $measdata_href = {
                       '3582.4400125' => {
                          'NODE_NAME::MODULE COMMAND::MOSI::Data' => '147',
                          'NODE_NAME::MODULE COMMAND::MISO::Page' => '0',
                          'NODE_NAME::MODULE COMMAND' => '1',
                          'NODE_NAME::MODULE COMMAND::MISO_Hex' => 'A0B00000',
                          'NODE_NAME::MODULE COMMAND::MOSI_Hex' => 'C0000000',
                          },
                       '3582.4448125' => {
                          'NODE_NAME::MODULE COMMAND::MOSI::Adr' => '5',
                          'NODE_NAME::MODULE COMMAND::MISO::MIDSMI710_1' => '1',
                          'NODE_NAME::MODULE COMMAND::MOSI::Page' => '0',
                          'NODE_NAME::MODULE COMMAND::MISO::Page' => '0',
                          'NODE_NAME::MODULE COMMAND::MISO_Hex' => 'B0D00000',
                          'NODE_NAME::MODULE COMMAND::MOSI_Hex' => 'F0000000',
                          },
                        }
    
=item $expectedCommands_aref:

List of commands which are expected in that sequence (no other commands in between)

=item GetCmdDetails (optional)

If set to 1 -> Details of the detected command sequence with signal value and command values will be returned. Else only detected sequence with verdict will be returned.

=item FirstCmdOccuranceIndex (optional)

Occurance count of the first command in the expected command sequence in a given trace.

If command 'X'  occurs twice and the second occurance to be considered for the start of sequence

then this parameter shall be set to 2. 

DEFAULT value is 1.

=item PreCmdToStartEvalSeq (optional)

The command name after which the sequence check should be started.

=back

B<Return values:>

default case: 

    Returns a verdict ('VERDICT_PASS' or 'VERDICT_FAIL'),
    
    an array reference with the detected command sequence
    
    command details href(if 'GetCmdDetails' is set to 1) with 
    command and signal values defined.


Return value if first command not found:
 
    VERDICT_FAIL , [], {};

Examples:

Return value in Success:

     VERDICT_PASS,
     
     ['CMD1','CMD2'],
     
     { 'CMD1' => {
                   COBRA_MAIN::CMD1::MOSI_Hex => '0A040000'
                 },
       'CMD2' => {
                   COBRA_MAIN::CMD2::MOSI_Hex => '0A070000'
                 }
     }

Return value if commands not in sequence :

    VERDICT_FAIL,
 
    ['CMD2','CMD1'],
    
    { 'CMD2' => {
                    COBRA_MAIN::CMD2::MOSI_Hex => '0A040000'
                }
    };


# Following input is used as input in use case 1 .. 3 in below example.

    $measdata_href =
        {
          '89.1736875000001' => {
                                  'SMA660_M::READ_EXT_MODE::MOSI_Hex' => '3900001c',
                                  'SMA660_M::READ_EXT_MODE::MISO_Hex' => '28000f7a',
                                  'SMA660_M::READ_EXT_MODE::MISO::extended mode  ON' => 1,
                                  'SMA660_M::READ_EXT_MODE' => 1
                                },
          '89.1827250000001' => {
                                  'SMA660_M::WR_OTP_ADDRESS::MOSI_Hex' => '4280070c',
                                  'SMA660_M::WR_OTP_ADDRESS::MOSI::address' => 56,
                                  'SMA660_M::WR_OTP_ADDRESS::MISO_Hex' => '2800000d',
                                  'SMA660_M::WR_OTP_ADDRESS' => 1
                                },
          '89.1923624999999' => {
                                  'SMA660_M::READ_OTP_ADDRESS::MOSI_Hex' => '42000010',
                                  'SMA660_M::READ_OTP_ADDRESS::MISO_Hex' => '2800038a',
                                  'SMA660_M::READ_OTP_ADDRESS::MISO::address' => 56,
                                  'SMA660_M::READ_OTP_ADDRESS' => 1
                                },
          '89.2019749999999' => {
                                  'SMA660_M::READ_OTP_DATA::MOSI_Hex' => '41000008',
                                  'SMA660_M::READ_OTP_DATA::MISO_Hex' => '28080bd8',
                                  'SMA660_M::READ_OTP_DATA::MISO::data low byte' => 189,
                                  'SMA660_M::READ_OTP_DATA::MISO::data high byte' => 128,
                                  'SMA660_M::READ_OTP_DATA' => 1
                                },
          '89.2110875000003' => {
                                  'SMA660_M::READ_OTP_DATA::MOSI_Hex' => '41000008',
                                  'SMA660_M::READ_OTP_DATA::MISO_Hex' => '28060008',
                                  'SMA660_M::READ_OTP_DATA::MISO::data low byte' => 0,
                                  'SMA660_M::READ_OTP_DATA::MISO::data high byte' => 96,
                                  'SMA660_M::READ_OTP_DATA' => 1
                                },
          '89.2186125000003' => {
                                  'SMA660_M::RD_REVISION_ID::MOSI_Hex' => '22000000',
                                  'SMA660_M::RD_REVISION_ID::MISO_Hex' => '28000128',
                                  'SMA660_M::RD_REVISION_ID::MISO::REV_ID' => 18,
                                  'SMA660_M::RD_REVISION_ID' => 1
                                }
       };


B<Use case 1 Correct sequence:>

Evaluate the SPI command sequence ('READ_OTP_ADDRESS', 'READ_OTP_DATA')

    my ($thisVerdict,
        $detectedSequence_aref,
        $cmd_details_href) = SPI_EVAL_check_command_sequence(
                              'MeasurementData_href' => $measdata_href,
                              'CommandList' => ['READ_OTP_ADDRESS', 'READ_OTP_DATA'],
                              'GetCmdDetails' => 1,
                              );

    $thisVerdict = 'VERDICT_PASS',
    $detectedSequence_aref = [ 'READ_OTP_ADDRESS [okay]', 'READ_OTP_DATA [okay]'];
    $cmd_details_href =

    {

     1 => {
           'READ_OTP_ADDRESS' => {
                            'SMA660_M::READ_OTP_ADDRESS' => '1',
                            'SMA660_M::READ_OTP_ADDRESS::MISO::address' => '56',
                            'SMA660_M::READ_OTP_ADDRESS::MISO_Hex' => '2800038a',
                            'SMA660_M::READ_OTP_ADDRESS::MOSI_Hex' => '42000010'
                           }
          }
     2 => {
           'READ_OTP_DATA' => { 
                         'SMA660_M::READ_OTP_DATA' => '1',
                         'SMA660_M::READ_OTP_DATA::MISO::data high byte' => '128',
                         'SMA660_M::READ_OTP_DATA::MISO::data low byte' => '189',
                         'SMA660_M::READ_OTP_DATA::MISO_Hex' => '28080bd8',
                         'SMA660_M::READ_OTP_DATA::MOSI_Hex' => '41000008'
                         } 
          }
    }

B<Use case 2 wrong sequence: >

Evaluate the SPI command sequence ('READ_OTP_DATA', 'READ_OTP_ADDRESS')

    my ($thisVerdict,
    $detectedSequence_aref,
    $cmd_details_href) = SPI_EVAL_check_command_sequence(
                          'MeasurementData_href' => $measdata_href,
                          'CommandList' => ['READ_OTP_DATA', 'READ_OTP_ADDRESS'],
                          'GetCmdDetails' => 1,
                          );

    $thisVerdict = 'VERDICT_FAIL',

    $detectedSequence_aref = [ 'READ_OTP_DATA [okay]', 
                               'READ_OTP_DATA [not okay]',
                               'RD_REVISION_ID [no eval]'
                             ];

    $cmd_details_href =

    {

     1 => {
            'READ_OTP_DATA' => { 
                         'SMA660_M::READ_OTP_DATA' => '1',
                         'SMA660_M::READ_OTP_DATA::MISO::data high byte' => '128',
                         'SMA660_M::READ_OTP_DATA::MISO::data low byte' => '189',
                         'SMA660_M::READ_OTP_DATA::MISO_Hex' => '28080bd8',
                         'SMA660_M::READ_OTP_DATA::MOSI_Hex' => '41000008'
                         }   
          }
    }

B<Use case 3 Sequence check based on Command occurance and Precommand: >

Evaluate the SPI command sequence ('READ_OTP_ADDRESS', 'READ_OTP_DATA')

    my ($thisVerdict,
    $detectedSequence_aref,
    $cmd_details_href) = SPI_EVAL_check_command_sequence(
                          'MeasurementData_href' => $measdata_href,
                          'CommandList' => ['READ_OTP_ADDRESS', 'READ_OTP_DATA'],
                          'GetCmdDetails' => 1,
                          'FirstCmdOccuranceIndex' => 1,
                          'PreCmdToStartEvalSeq' = > 'WR_OTP_ADDRESS'
                          );

    $thisVerdict = 'VERDICT_PASS',

    $detectedSequence_aref = [ 'READ_OTP_ADDRESS [okay]', 'READ_OTP_DATA [okay]'];

    $cmd_details_href =

    {

     1 => {
           'READ_OTP_ADDRESS' => {
                            'SMA660_M::READ_OTP_ADDRESS' => '1',
                            'SMA660_M::READ_OTP_ADDRESS::MISO::address' => '56',
                            'SMA660_M::READ_OTP_ADDRESS::MISO_Hex' => '2800038a',
                            'SMA660_M::READ_OTP_ADDRESS::MOSI_Hex' => '42000010'
                           }
          }
     2 => {
           'READ_OTP_DATA' => { 
                         'SMA660_M::READ_OTP_DATA' => '1',
                         'SMA660_M::READ_OTP_DATA::MISO::data high byte' => '128',
                         'SMA660_M::READ_OTP_DATA::MISO::data low byte' => '189',
                         'SMA660_M::READ_OTP_DATA::MISO_Hex' => '28080bd8',
                         'SMA660_M::READ_OTP_DATA::MOSI_Hex' => '41000008'
                         } 
          }
    }

=cut

sub SPI_EVAL_check_command_sequence {

    my @args   = @_;
    my $params = {@args};

    my $measdata_href          = $params->{'MeasurementData_href'};
    my $exp_cmd_seq_aref       = $params->{'CommandList'};
    my $cmd_details_flag       = $params->{'GetCmdDetails'} // 0;
    my $firstCmdOccuranceIndex = $params->{'FirstCmdOccuranceIndex'} // 1;
    my $preCmdToStartEvalSeq   = $params->{'PreCmdToStartEvalSeq'};

    return unless S_checkFunctionArguments( 'SPI_EVAL_check_command_sequence ( $measdata_href, $exp_cmd_seq_aref )', ( $measdata_href, $exp_cmd_seq_aref ) );

    return unless ( Check_init() );

    my ( @check_seq, $thisVerdict, $command_measured_to_check );
    my $report_cmd_cnt     = 0;
    my $measured_cmd_cnt   = 0;    # initial position of the first command in the command sequence
    my $long_name_used     = 0;
    my $cmd_details_href   = {};
    my $first_cmd_cnt_href = {};
    my $pre_cmd_flag;
    $pre_cmd_flag = 1 unless ( defined $preCmdToStartEvalSeq );
    my $cmdoccurenceincrement      = 0;
    my $expected_cmd_details_index = 1;
    my $pre_cmd;
    $thisVerdict = 'VERDICT_NONE';

    # loop through each of the time stamp to get the commands
    # report cmd count and expected command count are redundant
    foreach my $time ( sort { $a <=> $b } keys %$measdata_href ) {

        #        last if ( $measured_cmd_cnt == scalar @$exp_cmd_seq_aref );
        last if ( $measured_cmd_cnt - 3 > scalar @$exp_cmd_seq_aref );    # collect 3 more measured commands to be checked/displayed

        # all signals in syntax like : 'SMA660_Main::RD_SENSOR_DATA_CH1::MISO::Data_CH1'
        my @command_name = keys %{ $measdata_href->{$time} };             # collect the keys of the time stamp to collect only the command name

        # is list like : ( SMA660_Main , RD_SENSOR_DATA_CH1 , MISO , Data_CH1 )
        my @splitCommand = split( /::/, $command_name[0] );               # collect only the command name

        my $node_name_measured    = $splitCommand[0];
        my $command_name_measured = $splitCommand[1];

        my $command_measured_short_name = $command_name_measured;
        my $command_measured_long_name  = $node_name_measured . "::" . $command_name_measured;

        my $command_expected = $exp_cmd_seq_aref->[$report_cmd_cnt];
        if ( $command_expected =~ /::/ ) {
            $command_measured_to_check = $command_measured_long_name;
            $long_name_used            = 1;
        }
        else {
            $command_measured_to_check = $command_measured_short_name;
            $long_name_used            = 0;
        }

        if ( $measured_cmd_cnt >= scalar @$exp_cmd_seq_aref ) {
            $measured_cmd_cnt++;
            push( @check_seq, $command_measured_long_name . " [no eval]" ) if $long_name_used;
            push( @check_seq, $command_measured_short_name . " [no eval]" ) unless $long_name_used;
            next;
        }

        # to check first command in the sequence is found
        if ( ( @check_seq == 0 ) ) {

            if ( defined $preCmdToStartEvalSeq and ( $pre_cmd eq $preCmdToStartEvalSeq ) ) {
                $pre_cmd_flag = 1;
            }
            if ( $command_measured_to_check eq $command_expected ) {
                $first_cmd_cnt_href->{$command_measured_to_check} = ++$cmdoccurenceincrement;
                if ( ( $first_cmd_cnt_href->{$command_measured_to_check} == $firstCmdOccuranceIndex ) and ( $pre_cmd_flag == 1 ) ) {
                    push( @check_seq, $command_measured_to_check . " [okay]" );
                    $cmd_details_href->{ $expected_cmd_details_index++ }{$command_measured_to_check} = $measdata_href->{$time} if ($cmd_details_flag);
                    S_w2log( 1, "SPI_EVAL_check_command_sequence: First command '$command_measured_to_check' detected at time stamp $time\n" );
                    S_set_verdict('VERDICT_PASS');
                    $thisVerdict = 'VERDICT_PASS';
                    $report_cmd_cnt++;
                    $measured_cmd_cnt++;
                }

            }
            $pre_cmd = $command_measured_to_check;
            $pre_cmd_flag = 0 if ( defined $preCmdToStartEvalSeq );
            next;    # must jump to the next command in trace
        }

        # to check the subsequent commands in the sequence
        S_w2log( 1, "SPI_EVAL_check_command_sequence: Command $report_cmd_cnt expected '$command_expected' \n" );

        if ( $command_measured_to_check eq $command_expected ) {
            S_w2log( 1, "SPI_EVAL_check_command_sequence: Command $report_cmd_cnt detected '$command_measured_to_check' at time stamp $time \n" );
            S_set_verdict('VERDICT_PASS');
            push( @check_seq, $command_measured_to_check . " [okay]" );
            $cmd_details_href->{ $expected_cmd_details_index++ }{$command_measured_to_check} = $measdata_href->{$time} if ($cmd_details_flag);
        }
        else {
            S_w2log( 1, "SPI_EVAL_check_command_sequence: Command $report_cmd_cnt : MISMATCH !! (next command in trace is $command_measured_to_check at time stamp $time) \n", 'red' );
            S_set_verdict('VERDICT_FAIL');    # set verdict to fail if the command is not in sequence
            $thisVerdict = 'VERDICT_FAIL';
            push( @check_seq, $command_measured_to_check . " [not okay]" );
        }

        $report_cmd_cnt++;
        $measured_cmd_cnt++;

        # exit the loop if the expected command count exceeds the size of the sequence
        # note: the $measured_cmd_cnt starts with 0

    }

    if ( @check_seq == 0 ) {
        S_w2log( 1, "SPI_EVAL_check_command_sequence: Command sequence evaluation NOT_OK: First command in the sequence not found\n" );
        S_set_verdict('VERDICT_FAIL');
        $thisVerdict = 'VERDICT_FAIL';
        push( @check_seq, " << DID NOT FOUND FIRST COMMAND >> " );

    }

    if ($cmd_details_flag) {
        return ( $thisVerdict, \@check_seq, $cmd_details_href );
    }
    else {
        return ( $thisVerdict, \@check_seq );
    }

}

=head1 Non exported functions

=head2 CallDeviceFunction 

 This Function will fetch the caller function name. With this it gets the function group name.
 Then it fetches the required Function API for the device configured.

=cut

sub CallDeviceFunction {
    my @args = @_;

    #STEP call the FL_CallDeviceFunction by passing the $functionMapping_href
    #STEP return the value received from FL_CallDeviceFunction

    return FL_CallDeviceFunction( 'SPI_Access', $functionMapping_href, @args );
}

sub CreateArchitectureStructure {
    return FL_CreateArchitectureStructure( 'SPI_Access', $functionMapping_href );
}

=head2 Init_SPIMaid

    Init_SPIMaid();

Non export function.

This function is used for initialization of device SPIMaid

=cut

sub Init_SPIMaid {
    eval "use LIFT_SPIMaid";
    MAID_init();
    return 1;
}

=head2 Init_Manitoo

    Init_Manitoo();

Non export function.

This function is used for initialization of device Manitoo

=cut

sub Init_Manitoo {
    eval "use LIFT_manitoo";
    MANITOO_init();
    return 1;
}

=head2 Init_LA_AcuteTravelLogic

    Init_LA_AcuteTravelLogic();

Non export function.

This function is used for initialization of device LA Acute Travel Logic

=cut

sub Init_LA_AcuteTravelLogic {
    eval "use LIFT_LA_AcuteTravelLogic";
    LATL_InitHW();
    return 1;
}

=head2 Init_NONE

    Init_NONE();

Non export function.

This function is used for initialization of device NONE

=cut

sub Init_NONE {
    S_w2log( 4, "no SPI device configured\n" );
    return 1;
}

=head2 _create_measurement_XML

    _create_measurement_XML();

Non export function.

This function creates an XML file for the given measurement $measurementLabel.
Only content after creation will be the measurement label.
The rest of the content must be filled in SPI_trace_load_file.

=cut

sub _create_measurement_XML {
    my $measurementLabel = shift;

    my $measurementXML = XML::LibXML::Document->new( '1.0', 'utf-8' );

    # create the root element
    my $rootElement = $measurementXML->createElement("SPI_Measurement");

    # set the document root element
    $measurementXML->setDocumentElement($rootElement);

    # write measurement label to XML
    my $measurementLabelNode = $measurementXML->createElement("MeasurementLabel");
    $measurementLabelNode->appendText($measurementLabel);
    $rootElement->appendChild($measurementLabelNode);

    # create XML file, store file name in global variable $loadedMeasurements_href
    _update_measurement_XML( $measurementLabel, $measurementXML );

    return $measurementXML;
}

=head2 _update_measurement_XML

    _update_measurement_XML();

Non export function.

XML file for given measurement label will be updated.
    1) XML already exists in $loadedMeasurements_href -> {'XML_FilePath'} --> only update
    2) XML does not exist in $loadedMeasurements_href -> {'XML_FilePath'} --> file creation + update

=cut

sub _update_measurement_XML {
    my $measurementLabel = shift;
    my $measurementXML   = shift;

    #    S_w2log( 4 , " _update_measurement_XML: called with $measurementLabel, $measurementXML \n");

    my $measurementFileName;
    if ( not defined $loadedMeasurements_href->{$measurementLabel}->{"XML_FilePath"} ) {
        $measurementFileName = $main::REPORT_PATH . "\\SPI_Measurement_$measurementLabel.xml";
        $loadedMeasurements_href->{$measurementLabel}->{"XML_FilePath"} = $measurementFileName;
    }
    else {
        $measurementFileName = $loadedMeasurements_href->{$measurementLabel}->{"XML_FilePath"};
    }

    open( my $fhMeasurementXMLFile, ">", $measurementFileName ) or S_set_error("unable to write to XML file '$measurementFileName' ");
    binmode $fhMeasurementXMLFile;    # drop all PerlIO layers possibly created by a use open pragma
    print $fhMeasurementXMLFile $measurementXML->toString( 1, 'utf-8' );
    close($fhMeasurementXMLFile);

    undef $measurementXML;
    return 1;
}

=head2 _convert_time

    _convert_time($valueDataSamples_href, $timeUnit);
    
Non export function.

This function converts the time format to micro secs

=cut

sub _convert_time {

    my $valueDataSamples_href = shift;
    my $timeUnit              = shift;

    #for conversion
    my $unit_hash = { 'ms' => 1000, 's' => 1000000 };

    my %valueDataSamples_hash;

    # default considered as milli seconds
    unless ($timeUnit) {
        S_w2log( 3, "No time unit given. Default 'ms' will be used." );
        $timeUnit = 'ms';
    }

    if ( $timeUnit !~ /^ms$|^s$|^us$/i ) {
        my $function_name = ( caller(1) )[3];    # To get the calling function name
        $function_name =~ s/(.*):://;            # filter out only the function name
        S_set_error( "$function_name: Wrong format given for parameter 'TimeUnit'. Supported format: 'ms', 's' and 'us'.", 109 );
        return;
    }

    # converting to micro seconds
    while ( my ( $time, $val ) = each %$valueDataSamples_href ) {

        # millisecond
        if ( $timeUnit =~ /^ms$/i ) {
            $timeUnit                     = lc $timeUnit;
            $time                         = $time * $unit_hash->{$timeUnit};
            $valueDataSamples_hash{$time} = $val;
        }

        # Second
        elsif ( $timeUnit =~ /^s$/i ) {
            $timeUnit                     = lc $timeUnit;
            $time                         = $time * $unit_hash->{$timeUnit};
            $valueDataSamples_hash{$time} = $val;
        }

        # microsecond
        else {
            $timeUnit = lc $timeUnit;
            $valueDataSamples_hash{$time} = $val;
        }
    }
    $valueDataSamples_href = ();                         #clear the hash with original input values
    $valueDataSamples_href = \%valueDataSamples_hash;    #assign the converted values in micro seconds fomat to the hash

    return $valueDataSamples_href;
}

=head2 _convert_data

    _convert_data($values_mix, $mode);
    
Non export function.

This function converts the data to decimal

=cut

sub _convert_data {

    my $values_mix = shift;
    my $mode       = shift;

    # 1) Check whether given value format is purely hex or purely decimal
    my ( @hex_format, @dec_format, @bin_format );

    if ( $mode eq 'TIMER' ) {

        # collect all the hex format values given as '0x..' for counting
        @hex_format = grep { $_ =~ /0x\s*([A-Fa-f0-9\s*]+)/ } values %$values_mix;
        push( @hex_format, grep { $_ =~ /^stop_manipulation$/i } values %$values_mix ) if (@hex_format);

        # collect all decimal values  for counting
        @dec_format = grep { $_ =~ /^(\s*\d+\s*)$/ } values %$values_mix;
        push( @dec_format, grep { $_ =~ /^stop_manipulation$/i } values %$values_mix ) if (@dec_format);

        # collect all decimal values given as '0b..' for counting
        @bin_format = grep { $_ =~ /^0b\s*[01i\-x\s*]+$/i } values %$values_mix;
        push( @bin_format, grep { $_ =~ /^stop_manipulation$/i } values %$values_mix ) if (@bin_format);
    }

    if ( $mode eq 'SPI' ) {

        # collect all hex format values given as '0xA'  for counting
        @hex_format = grep { $_ =~ /0x\s*([A-Fa-f0-9\s*]+)$/ } @{$values_mix};    # collect all the hex format values

        # collect all decimal values  for counting
        @dec_format = grep { $_ =~ /^(\s*\d+\s*)$/ } @{$values_mix};              # collect all the dec format values

        # binary format support
        @bin_format = grep { $_ =~ /^0b\s*[01i\-x\s*]+/i } @{$values_mix};        # collect all the bin format values
    }

    # get the number of values for comparison
    my $cntval;
    $cntval = values %$values_mix if ( $mode eq 'TIMER' );
    $cntval = @{$values_mix}      if ( $mode eq 'SPI' );

    # if all the values are in same format or else throw error
    if ( not( ( @hex_format == $cntval ) or ( @dec_format == $cntval ) or ( @bin_format == $cntval ) ) ) {
        my $function_name = ( caller(1) )[3];                                     # To get the calling function name
        $function_name =~ s/(.*):://;                                             # filter out only the function name
        my $param_name = 'SignalValues';
        $param_name = 'SignalTimesValues' if ( $mode eq 'TIMER' );

        S_set_error( "$function_name : Input format in the parameter '$param_name' wrong!\n" . "Either pure hex or pure decimal or pure binary value declaration allowed", 109 );
        return;
    }

    # 2) convert to decimal if format is in hex
    if (@hex_format) {

        if ( $mode eq 'TIMER' ) {

            # all values are converted to decimal values, extra spaces removed and stored in $values_mix
            map { $values_mix->{$_} =~ s/\s*//g if ( $values_mix->{$_} !~ /^stop_manipulation$/i ); } keys %$values_mix;
        }

        if ( $mode eq 'SPI' ) {

            # all values are converted to decimal values, extra spaces removed and stored in $values_mix
            map { $_ =~ s/\s*//g } @{$values_mix};
        }
    }
    return $values_mix;

}

sub _prepare_SMI7_write_config {
    my $smi7module       = shift;
    my $nodeName         = shift;
    my $triggerMaskHex   = shift;
    my $triggerMaskValue = shift;
    my $mappingSPInode   = S_get_contents_of_hash( [ 'Mapping_SPI', "$nodeName" ] );
    unless ( defined $mappingSPInode->{'SMI7_Modules'} ) {
        S_set_error("Section 'SMI7_Modules' not defined for the node '$nodeName' in the SPI Mapping file");
        return;
    }
    my $smi7moduleNbr = $mappingSPInode->{'SMI7_Modules'}->{$smi7module};
    unless ( defined $smi7moduleNbr ) {
        S_set_error( "could not find module number for given module $smi7module. Define in mapping for node $nodeName in section 'SMI7_Modules'", 109 );
        return;
    }
    my ( $smi7MaskBin, $smi7ValueBin ) = $spiDatabase_Object->GetCommandMaskAndValue( $nodeName, $smi7module, 'BIN' );

    # Add to module mask and value
    my $numberOfBits    = length($smi7MaskBin);
    my $binMaskTrigger  = sprintf( "%0" . $numberOfBits . "b", hex($triggerMaskHex) );
    my $binValueTrigger = sprintf( "%0" . $numberOfBits . "b", hex($triggerMaskValue) );
    $binMaskTrigger  = $smi7MaskBin | $binMaskTrigger;
    $binValueTrigger = $smi7ValueBin | $binValueTrigger;
    my $numberOfNibbles = $numberOfBits / 4;
    $triggerMaskHex   = sprintf( "%0" . $numberOfNibbles . "X", oct("0b$binMaskTrigger") );
    $triggerMaskValue = sprintf( "%0" . $numberOfNibbles . "X", oct("0b$binValueTrigger") );
    return $smi7moduleNbr, $triggerMaskHex, $triggerMaskValue;
}

sub Check_init {
    unless ( $INIT_FLAG == 1 ) {
        my $function_name = ( caller(1) )[3];
        S_set_error("$function_name: SPI access not initialised! , Call SPI_init() before calling any of SPI access functions!");
        return;
    }
    return 1;
}

1;
