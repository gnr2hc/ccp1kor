# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_TEMPERATURE;

use strict;
use warnings;
use LIFT_general;
use LIFT_functional_layer;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_TEMPERATURE ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
	'all' => [
		qw(

		  )
	]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  TEMP_init
  TEMP_get_temperature
  TEMP_setTargetTemperature
  TEMP_waitForTemperature
  TEMP_getTargetTemperature
  TEMP_exit
);

our ( $VERSION, $HEADER );

my $port;
my $TEMP_initialized = 0;

=head1 NAME

LIFT_TEMPERATURE 

wrapper class for devices to measure temperature.

calls internally DTM5080, LIFT_VOETSCH or LIFT_ESPEC functions depending on testbench config.

=head1 SYNOPSIS

    use LIFT_TEMPERATURE;

    TEMP_init();

    TEMP_get_temperature();

    TEMP_setTargetTemperature(25);

    TEMP_waitForTemperature(20,2);

    $temperature = TEMP_getTargetTemperature();

    TEMP_exit();

=head1 DESCRIPTION

This is a wrapper library for all temperature devices.

In the TurboLIFT architecture LIFT_TEMPERATURE is a functional module.

The device that is used for the different functions is defined in testbench config (LIFT_Testbenches.pm) under 'Functions'->'Temperature'.

=head2 Testbench Configuration

=head3 Devices section:

    'Devices' => {
        ...
        'VOETSCH' => {
            'connect' => 'COM6',
        },
        'DTM5080' => {
            'connect' => 'COM6',
        },
        'ESPEC'   => {
        	'connect' => 'COM6',
        }
        ...
    },
    
=head3 Functions section:
    
    'Functions' => {
        ...
        ### --- Function Area : Temperature, 
        ### select device which controls or measures temperature (VOETSCH, DTM5080, ESPEC)
        'Temperature' => {
            'get'     =>   '<device>', # possible devices: VOETSCH , DTM5080, ESPEC, NONE
            'set'     =>   '<device>', # possible devices: VOETSCH, ESPEC
        },
        ...
    },
The functions that are called internally in this module are defined in $functionMapping_href.

In this $functionMapping_href data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.

=cut

# In this data structure for all function groups and devices the mapping of functional layer function to device layer function is defined.
my $functionMapping_href = {

	# marker for perltidy
	'base' => {    #Function Group
		'VOETSCH' => {    #device layer
			'TEMP_Init' => 'VT_connect',      # for documentation purposes only
			'TEMP_exit' => 'VT_disconnect',
		},
		'DTM5080' => {
			'TEMP_Init' => 'GetDTMPort',      # for documentation purposes only
			'TEMP_exit' => 'None',
		},
		'ESPEC' => {
			'TEMP_Init' => 'ESPEC_connect',      # for documentation purposes only
			'TEMP_exit' => 'ESPEC_disconnect',
		},
		'NONE' => {
			'TEMP_Init' => 'None',               # for documentation purposes only
			'TEMP_exit' => 'None',
		},
	},
	'get' => {                                   #Function Group
		'VOETSCH' => {                           #device layer
			'TEMP_get_temperature' => 'VT_getCurrentTemperature',
		},
		'DTM5080' => {
			'TEMP_get_temperature' => 'LIFT_TEMPERATURE_DTM::TEMP_get_temperature',
		},
		'ESPEC' => {
			'TEMP_get_temperature' => 'ESPEC_getCurrentTemperature',
		},
		'NONE' => {
			'TEMP_get_temperature' => 'LIFT_TEMPERATURE_NONE::TEMP_get_temperature',
		},
	},
	'set' => {    #Function Group
		'VOETSCH' => {    #device layer
			'TEMP_setTargetTemperature' => 'VT_setTargetTemperature',
			'TEMP_waitForTemperature'   => 'internal',
			'TEMP_getTargetTemperature' => 'VT_getTargetTemperature',
		},
		'ESPEC' => {      #device layer
			'TEMP_setTargetTemperature' => 'ESPEC_setTargetTemperature',
			'TEMP_waitForTemperature'   => 'internal',
			'TEMP_getTargetTemperature' => 'ESPEC_getTargetTemperature',
		},
	},
};

my @availableTestbenchFunctionGroups = qw{ get set };

=head1 Function Group 'base'

=head2 TEMP_init

    TEMP_init();

initialize TEMPERATURE hardware according to testbench settings.

has to be called before any other TEMP Function call.

=cut

sub TEMP_init {
	return FL_Init( 'temperature', $functionMapping_href, \@availableTestbenchFunctionGroups );
}

=head2 TEMP_exit

    TEMP_exit();

uninitialize the all used TEMPERATURE devices.

has to be called at the end. should be called in ENDcampaign. should have at least 1 second delay to previous TEMP function call.

=cut

sub TEMP_exit {
	return FL_Exit( 'temperature', $functionMapping_href );
}

=head1 Function Group 'get'

=head2 TEMP_get_temperature

    $temperature = TEMP_get_temperature();

returns temperature in degree Celsius, if no device was configured (NONE) default return value is 'RoomTemp' for room temperature

=cut

sub TEMP_get_temperature {

	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'TEMP_get_temperature( )', @args );
	return CallDeviceFunction(@args);
}

=head1 Function Group 'set'

=head2 TEMP_getTargetTemperature

    $temperature = TEMP_getTargetTemperature();

Returns the target temperature of the temperature chamber in degree celsius.

=cut

sub TEMP_getTargetTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'TEMP_getTargetTemperature( )', @args );
	return CallDeviceFunction(@args);
}

=head2 TEMP_setTargetTemperature

    TEMP_setTargetTemperature( $temperature_degC [, $gradient_Kpm] );

    e.g. TEMP_setTargetTemperature(25);

Sets the target temperature of the temperature chamber to $temperature_degC degree celsius.
Optionally a temperature gradient can be set ($gradient_Kpm in K/min).
If no gradient is set or if the gradient is higher than the chamber's capabilities 
then the temperature change is done as fast as possible.
Only Voetsch temperature chambers support setting a gradient. If a gradient is set for ESPEC chambers then it is ignored.

B<Arguments:>

=over

=item $temperature_degC 

Target temperature in degree celsius.

=item $gradient_Kpm 

(optional) Temperature gradient in K/min. 

=back

B<Return Value:>

=over

=item $success 

1 on success and in offline mode, 0 otherwise.

=back

B<Examples:>

    # set target temperature of 25 degC (as fast as possible)
    TEMP_setTargetTemperature(25);

    # set target temperature of 25 degC with a gradient of 5 K/min
    TEMP_setTargetTemperature(25, 5);

B<Notes:> 

This function will not change any settings on the temperature chamber, except the target temperature 
and optionally the temperature gradient.

=cut

sub TEMP_setTargetTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'TEMP_setTargetTemperature( $temperature_degC [, $gradient_Kpm] )', @args );
	return CallDeviceFunction(@args);
}

=head2 TEMP_waitForTemperature

    TEMP_waitForTemperature( [$retries,$tolerance] );

    e.g. TEMP_waitForTemperature(20,2);

To Wait until the temperature device has reached the temperature set by TEMP_setTargetTemperature($temperature);

- checks every 60 seconds for +/-$tolerance degC. Gives up after $retries tries.

Parameter $retries is optional, if not given, 30 is used (results in maximum 30 minutes).
Parameter $tolerance is optional, if not given, 0.5 is used.

Returns:
1 - Oven reached the target temperature with the given wait time(retries) and tolerance
0 - Oven Failed to reach the target temperature with the given wait time(retries) and tolerance

=cut

sub TEMP_waitForTemperature {
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'TEMP_waitForTemperature([$retries,$tolerance])', @args );

	my $retries   = shift;
	my $tolerance = shift;
	my $currentTemp;
	my $targetTemp;

	if ($main::opt_offline) {
		S_w2log( 4, "Waiting for Target Temperature: skipping in offline mode\n" );
		return 1;
	}

	# use default value if VT_waitForTemperature was called without parameter
	$retries   = 30  unless ( defined $retries );
	$tolerance = 0.5 unless ( defined $tolerance );

	my $givenRetries = $retries;

	# wait to reach target temperature +/- 0.5�C
	$currentTemp = TEMP_get_temperature();
	unless ($currentTemp) {
		S_set_error( "Error in reading current temperature", 120 );
		return 0;
	}
	$targetTemp = TEMP_getTargetTemperature();
	while ( ( abs( $currentTemp - $targetTemp ) > $tolerance ) && ( $retries > 0 ) ) {
		S_w2log( 3, "Target: $targetTemp degC; current: $currentTemp degC; tolerance $tolerance; waiting 60s... (try$retries/$givenRetries)\n" );
		sleep(60);
		$currentTemp = TEMP_get_temperature();
		$retries--;
	}
	if ( ( abs( $currentTemp - $targetTemp ) > $tolerance ) && ( $retries <= 0 ) ) {
		S_set_warning("WARNING!! Maximum retries reached but target temperature not reached yet!\n");
		return 0;
	}
	else {
		S_w2log( 3, "Target: $targetTemp degC; current: $currentTemp degC; +/-$tolerance degC reached.\n" );
	}
	return 1;
}

=head1 not exported functions

=head2 CallDeviceFunction

    CallDeviceFunction( @args );

Calls a function that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.
Values of $functionMapping_href are either directly functions of the device layer if a 1:1 mapping is possible.
Otherwise a function of the package LIFT_TEMPERATURE_xyz is called.

Returns the return values of the called functions. On error returns 0.

=cut

sub CallDeviceFunction {
	my @args = @_;
	return FL_CallDeviceFunction( 'temperature', $functionMapping_href, @args );
}

=head2 Init_VOETSCH

    Init_VOETSCH();

Non export function.

This function is used to intialize the VOETSCH device by calling VOETSCH Module

=cut

sub Init_VOETSCH {
	eval "use LIFT_VOETSCH";
	VT_connect();
	return 1;
}

=head2 Init_DTM5080

    Init_DTM5080();

Non export function.

This function is used to intialize the DTM5080 device by calling DTM5080 Module

=cut

sub Init_DTM5080 {
	eval "use DTM5080";
	$port = dtm_init();
	return 1;

}

=head2 Init_ESPEC

    Init_ESPEC();

Non export function.

This function is used to intialize the ESPEC device by calling ESPEC Module

=cut

sub Init_ESPEC {
	eval "use LIFT_ESPEC";
	ESPEC_connect();
	return 1;
}

=head2 Init_NONE

    Init_NONE();

Non export function.

This function is used for initialization of device NONE

=cut

sub Init_NONE {
	S_w2log( 4, "no Temperature device configured\n" );
	return 1;
}

sub CreateArchitectureStructure {
	return FL_CreateArchitectureStructure( 'temperature', $functionMapping_href );
}

############################################################################################################
#
#
# package LIFT_TEMPERATURE_DTM
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of TEMP_* function and DTM5080_* function is not possible.

package LIFT_TEMPERATURE_DTM;

use strict;
use warnings;
use LIFT_general;
use DTM5080;

sub TEMP_get_temperature {
	my ( $stat, $dtm_temperature );
	( $stat, $dtm_temperature ) = dtm_get_temperature($port);
	return $dtm_temperature;
}

############################################################################################################
#
#
# package LIFT_TEMPERATURE_NONE
#
#
############################################################################################################

# Define here those functions for which a 1:1 mapping of TEMP_* function and DTM5080_* function is not possible.

package LIFT_TEMPERATURE_NONE;

use strict;
use warnings;
use LIFT_general;

sub TEMP_get_temperature {
	S_w2log( 4, "no Temperature device configured, assuming room temperature\n" );
	if ( defined $LIFT_TSG4::TSG4_initialized and $LIFT_TSG4::TSG4_initialized == 1 ) {
		my $text = 'RoomTemp';    # chr(0xdf) is � on Rack CPU
		tsg4_rc::rc_display_text( 1, $text, 2 );
	}
	return 'RoomTemp';
}

1;

=head1 AUTHOR

Vanitha, E<lt>Vanitha.Thangavelu@in.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

