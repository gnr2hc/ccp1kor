# *****************************************************************************************************
#
#  Copyright (c) 2017  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_NET_access;
use strict;
use LIFT_general;
use LIFT_equipment;
use LIFT_functional_layer;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY
@ISA     = qw(Exporter);

@EXPORT = qw(
  NET_Init
  NET_trace_start
  NET_trace_stop
  NET_trace_store
  NET_trace_get_dataref

  NET_simulation_start
  NET_simulation_stop

  NET_read_signal
  NET_write_signal

  NET_set_envVar_value
  NET_get_envVar_value
  NET_set_sysVar_value
  NET_get_sysVar_value

  NET_enable_msg
  NET_disable_msg
  NET_set_dlc
  NET_reset_dlc
  NET_set_counter_error
  NET_reset_counter_error
  NET_set_crc_error
  NET_reset_crc_error

  NET_stimulate_reset_signal_curves
  NET_stimulate_load_signal_curves
  NET_stimulate_load_timed_signals
  NET_stimulate_start_now
  NET_stimulate_start_with_external_trigger
  NET_CAPL_config
  NET_CAPL_invoke

);

our ( $VERSION, $HEADER );

# Error codes
use constant ERR_MAPPING_FILES      => 20;
use constant ERR_INVALID_PARAMETERS => 114;

# log levels
use constant WRLOG_LEVEL_3 => 3;
use constant WRLOG_LEVEL_4 => 4;
use constant WRLOG_LEVEL_5 => 5;

my $is_net_access_mapping_present = 0;
my $mapping_converion_done        = 0;    # 0|1 ->  0 if net_access maping is not converted from <can><lin><flexray>_access mapping
                                          #         1 if net_access maping is converted from <can><lin><flexray>_access mapping
Check_if_NET_Access_Mapping_is_present();

=head1 NAME

LIFT_NET_access 

Provide libraray interface to access the CANoe functionalites via COM.

=head1 SYNOPSIS

    use LIFT_NET_access;    

=head2 Reading and writing of signals
        
    # ---------------------------------------------------------
    # For reading and writing of signals
    # ---------------------------------------------------------
    NET_trace_start(); 
    # read signals 
    NET_read_signal('SigStimulus_1_CAN');  # of type CAN,
    NET_read_signal('SigStimulus_1_Flxr'); # of type Flxray
    NET_read_signal('SigStimulus_1_LIN');  # of type LIN
    # write signals    
    NET_write_signal('SigStimulus_1_CAN', 20);  # of type CAN
    NET_write_signal('SigStimulus_1_Flxr', 20); # of type Flxray
    NET_write_signal('SigStimulus_1_LIN', 1);   # of type LIN
    NET_trace_stop();  

=head2 Control trace logging

    # ---------------------------------------------------------
    # for controlling of trace logging
    # ---------------------------------------------------------
    
    # There are three main use cases for trace file logging as explained below :
    
    # Case 1 : Trace logging (Start restbus simulation (RBS) and logging together )
    NET_trace_start();                  # starts RBS and logging / start measurement ('F9')
    #  - - - do something here - - -    
    NET_trace_stop();                   # stops logging and RBS / stop measurement
    $traceStore = NET_trace_store();    # storing the trace        
    
    # Case 2 : Trace logging ON/OFF (Start RBS without log, start & stop logging multiple times ...)
    NET_simulation_start();             # starts RBS &  switch - off logging fast
        NET_trace_start();              # switch - on logging the trace    
        #  - - - do something here - - -
        #  here several start/stop trace might be possible which append to log file
        NET_trace_stop();               #  switch - off logging (only) but not the measurement 
        # ....                                             
        NET_trace_start();              #   switch - on logging the trace  (appending data to the existing log) 
        #   - - - do something here - - -        
        NET_trace_stop();               #  switch - off logging (only) but not the measurement 
        $traceStore = NET_trace_store();# storing the trace        
    NET_simulation_stop();              # stops  RBS / stop measurement
       
    # Case 3 : No trace logging (Start RBS without log)
    NET_simulation_start();             # starts RBS &  switch - off logging fast
    #   - - - do something here - - -
    NET_simulation_stop();              # stops  RBS / stop measurement

=head2 Dynamic signal(s) stimulation

    # ---------------------------------------------------------
    # For stimulating signals and for calling CAPL functions
    # ---------------------------------------------------------    
    # measurement should not be running
    NET_stimulate_reset_signal_curves();
    NET_stimulate_load_signal_curves( $busSignal_curves_href, $triggertype );    
    NET_stimulate_load_timed_signals( $timeSignalName, $sigValue_1, $triggertype, $timeShift_ms, $sigValue_2); # optional
    NET_CAPL_config( ['MyCAPLFunc', 'MyCAPLFunc1']); # # optional -> for CAPL only    
    # start measurement
    NET_trace_start();
    NET_stimulate_start_with_external_trigger(); # for hardware trigger (either hardware or software trigger) 
    NET_stimulate_start_now(); # for software trigger (either hardware or software trigger)
    NET_CAPL_invoke('MyCAPLFunc'); # optional -> for CAPL only
    NET_CAPL_invoke('MyCAPLFunc1', [100] ); # optional -> for CAPL only    
    NET_trace_stop(); 
    # ---------------------------------------------------------

=head2 Message manipulations

    # ---------------------------------------------------------
    # For Message manipulations (enable/disable msg) (set/reset Dlc) (set/reset Counter error) (set/ reset crc error)
    # ---------------------------------------------------------
    NET_trace_start(); 
    # Here example is given with 'CAN message' but 'FlexRay PDU' or 'LIN frame' can also be passed at a time.    
    NET_disable_msg('MsgStimulus2_CAN');   
    NET_enable_msg('MsgStimulus2_CAN');
    NET_set_crc_error('MsgStimulus2_CAN');
    NET_reset_crc_error('MsgStimulus2_CAN');
    NET_set_counter_error('MsgStimulus2_CAN');
    NET_reset_counter_error('MsgStimulus2_CAN');
    NET_set_dlc('MsgStimulus2_CAN', 4 );
    NET_reset_dlc('MsgStimulus2_CAN' );    
    NET_trace_stop();
    # ---------------------------------------------------------

=head2 Getting the trace into dataref
    
    # ---------------------------------------------------------
    # For getting the Message, Signal or Sysvar information from CANoe trace
    # ---------------------------------------------------------
    NET_trace_start(); 
    # some wait time for getting the trace 
    NET_trace_stop();
    my $CANoe_trace_file = NET_trace_store();   
    my $data_href = NET_trace_get_dataref(
                                       $CANoe_trace_file,
                                       {
                                          'MESSAGES' => ['MsgStimulus2_CAN'],
                                          'SIGNALS'  => ['SigStimulus3_CAN'],
                                          'SYSVARS'  => ['LIFT_CAN_access::SysVar_Type_Float']
                                       }
                                      );

=head1 DESCRIPTION

This module access the CANoe application and provides below functionalities  :
 
=over 3

=item * start & stop RBS with or without trace logging 

=item * read (CAN, CANFD, LIN & FlexRay) signals

=item * write (CAN, CANFD, LIN & FlexRay) signals

=item * stimulation of (CAN, CANFD, LIN & FlexRay) signals

=item * set & get Environment variables.

=item * set & get system variables.

=item * to Enable & Disbale (CAN, CANFD, LIN & FlexRay) message.

=item * to reset & set DLC for (CAN, CANFD, LIN & FlexRay).

=item * to set valid & invalid CRC for (CAN, CANFD, LIN & FlexRay).

=item * to set valid & invalid Counter for (CAN, CANFD, LIN & FlexRay).

=item * get the copy of CANoe Trace if logged by CANoe.

=item * get the content of CANoe trace into a data structure for Evaluation.

=item * call user written CAPL functions .
 
=back

=head2 Prerequisites

In order to work with this module following are recommended :  

=over 3

=item to have basic knowledge of CAN, LIN & FlexRay protocol refer :

=for html
<a href='https://elearning.vector.com/vl_index_en.html'>vector CAN e-training</a>

=item basic knowledge of CANoe (for eg. compiling of .cfg file, editing some CAPL program, creating Environment variables in dbc file etc.)

=back

=head2 Mappings

=cut

=head3 B<NET Access mapping>

Many functions of this module need a mapping file that provides information about IDs of messages and bit and byte positions of signals.
The NET Access mapping file can be generated from the DBC/LDF/CSV (CAN and CADFD / LIN / FlexRay) files that defines the rest bus simulation. 
( Flexray database file (.xml/.arxml) converted to .csv file using FibexExplorer or AUTOSAR explorer (part of Canoe software package).

To do this there is a NET Access mapping file generator tool (with GUI) available: 

    <path to your TurboLIFT sandboxes>\Tools\Mappingfile_Generators\NET_Access_Mapping\Create_NET_Access_Mapping.pl
    
The generated NET Access mapping file should be copied to the "config" folder of your TurboLIFT project and 
in the main config file (..._CFG.pm) the mapping file must be loaded, e.g. like this:

    require "$LIFT_PRJCFG_path/NET_Access_mapping.pm"     if ( -f "$LIFT_PRJCFG_path/NET_Access_mapping.pm" );

=head2 Tutorials

Please refer below tutorials for better understanding of this module.

=over 3

=item *
  
=for html
<a href='https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Dynamic%20stimulation%20of%20CAN%20signals'>Dynamic stimulation of CAN signals</a> 

=> for the L</"Function Group 'stimulate'">. 

 
=item *
  
=for html
<a href='https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/CANoe%20IL%20%28CANoe%20Interaction%20Layer%29'>CANoe IL (CANoe Interaction Layer)</a> 

=> for reading & writing Bus signals. 

=back

=cut

=head2 TestBench configuration

=head3 Devices section:

    'Devices' => {
        ... 
        'CANoe' => {
            'Hostname'                       => 'BMH1045912',
            'Online_Config'                  => 'C:\TurboLIFT\Engine\test\CANoe\LIFT_CAN_access\COMDemo.cfg',
            'Log_File'                       => 'C:\temp\CANOE_log.asc',                          
            'Keep_Application_After_Test'    => 1,
            'ILUsed'                         => 'Yes',
        },
        ...
      },

B<'Hostname':> It is recommended to have Canoe running on the same host as TurboLIFT. 
If really needed then Canoe can also run on a different host, but then the handling of log files is more difficult.

B<'Online_Config':> Path B<on 'Hostname'> to the .cfg file to be loaded.

B<'Log_File':> Path B<on TurboLIFT host> to the log file that is configured in the defined .cfg file (see 'Online_Config').

B<'Keep_Application_After_Test':> (optional) If set to 1 then Canoe will stay open after test. 
By default Canoe will be closed after the test.

B<'ILUsed':> This can be either 'Yes' or 'No' Based on whether the Interaction layer is used or not.

=head3 Functions section:

    'Functions' => {
        ... 
        'NET_Access' => {
            'basic'     => 'CANoe',    # function groups: read, write, trace, simulation
            'stimulate' => 'CANoeCtrl',    # function groups: Stimulate signals ,CAPL            
        },
        ...
      },

B<'basic':> to perform read, write, trace, simulation function group. 
 
B<'stimulate':> to stimulate the CAN, LIN, FlexRay signals. and to call the user defined CAPL functions.

=cut

my $functionMapping_href = {

    # marker for perltidy
    'base' => {
        'CANoe' => {
            'NET_Init' => 'CANoe_Init',    # for documentation purposes only
            'NET_Exit' => 'NONE',
        },
    },

    'basic' => {
        'CANoe' => {

            # for read
            'NET_read_signal' => 'CANoe_read_signal',

            # for write
            'NET_write_signal'        => 'CANoe_write_signal',
            'NET_enable_msg'          => 'CANoe_enable_msg',
            'NET_disable_msg'         => 'CANoe_disable_msg',
            'NET_set_dlc'             => 'CANoe_set_dlc',
            'NET_reset_dlc'           => 'CANoe_reset_dlc',
            'NET_set_counter_error'   => 'CANoe_set_counter_error',
            'NET_reset_counter_error' => 'CANoe_reset_counter_error',
            'NET_set_crc_error'       => 'CANoe_set_crc_error',
            'NET_reset_crc_error'     => 'CANoe_reset_crc_error',

            # for 'measurement'
            'NET_trace_start'       => 'LIFT_NETaccess_CANoe::NET_trace_start',
            'NET_trace_stop'        => 'LIFT_NETaccess_CANoe::NET_trace_stop',
            'NET_simulation_start'  => 'LIFT_NETaccess_CANoe::NET_simulation_start',
            'NET_simulation_stop'   => 'LIFT_NETaccess_CANoe::NET_simulation_stop',
            'NET_trace_store'       => 'CANoe_trace_store',
            'NET_trace_get_dataref' => 'LIFT_NETaccess_CANoe::NET_trace_get_dataref',

            # for Environment & system variable
            'NET_set_envVar_value' => 'CANoe_set_envVar_value',
            'NET_get_envVar_value' => 'CANoe_get_envVar_value',
            'NET_set_sysVar_value' => 'CANoe_set_sysVar_value',
            'NET_get_sysVar_value' => 'CANoe_get_sysVar_value',
        },
    },

    'stimulate' => {
        'CANoeCtrl' => {

            # stimulate singals
            'NET_stimulate_reset_signal_curves'         => 'CANoeCtrl_ResetOutputSignal',
            'NET_stimulate_load_signal_curves'          => 'LIFT_NETaccess_CANoeCtrl::NET_stimulate_load_signal_curves',
            'NET_stimulate_load_timed_signals'          => 'LIFT_NETaccess_CANoeCtrl::NET_stimulate_load_timed_signals',
            'NET_stimulate_start_now'                   => 'LIFT_NETaccess_CANoeCtrl::NET_stimulate_start_now',
            'NET_stimulate_start_with_external_trigger' => 'CANoeCtrl_EnableOutputTriggers',

            # for CAPL
            'NET_CAPL_config'  => 'CANoeCtrl_CAPL_config',
            'NET_CAPL_invoke', => 'CANoeCtrl_CallCapl',
        },
    },
};

my @availableTestbenchFunctionGroups = qw{basic stimulate};

=head1 Function Group 'base'

=head2 NET_Init
    
    NET_Init();
    
Initialize the devices for all NET-access function groups (basic or stimulate).

This function has to be called before calling any other function in this library.
Calls internally the init functions of all devices that are configured in LIFT_Testbenches.pm for this functional module.
By convention the init functions must have the name "Init_<device>", e.g. Init_CANoe, ...

B<Note>: Its not needed to call this function explicitly if "EQUIP_init_testbench" was already called.

=cut

sub NET_Init {
    Check_if_NET_Access_Mapping_is_present();
    return FL_Init( 'NET_access', $functionMapping_href, \@availableTestbenchFunctionGroups );
}

=head1 Function Group 'basic'

=head2 NET_trace_start
    
    $status = NET_trace_start();

Starts the CANoe measurement. Refer L</"Control trace logging"> for different use cases of trace logging possible.    

B<Note :>

- After calling start measurement command it checks if really measurement has started or not for sucessive waitTime of 100, 200, 500, 1500, 5000 ms.

- If measurement was already started then it does nothing and it just returns.

=cut

sub NET_trace_start {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_start()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_trace_stop
    
    $status = NET_trace_stop();

Stops the CANoe measurement.

B<Note :>

- After calling stop measurement command it checks if really measurement has stopped or not for sucessive waitTime of 100, 200, 500, 1500, 5000 ms.

- If measurement was already stoped then it does nothing and it just returns.

=cut

sub NET_trace_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_stop()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_simulation_start

    $status = NET_simulation_start();

Start CANoe measurement if not running before and then B<STOPS logging of CANoe trace> fast. Refer L</"Control trace logging"> for different use cases of trace logging possible.

B<Note :>

If the measurement was already running then only logging of trace will be stopped. Otherwise first measurement will be started and then trace logging will be stopped.                       

=cut

sub NET_simulation_start {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_simulation_start()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_simulation_stop

    $status = NET_simulation_stop();

Stops the CANoe measurement. Refer L</"Control trace logging"> for different use cases of trace logging possible.

=cut

sub NET_simulation_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_simulation_stop()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_trace_store

    $trStore_filepath = NET_trace_store ( [$trStore_filepath] );   

Store the CANoe trace as mentioned in testbech  L</"Devices section:"> ['CANoe'->'Log_File']. under path $trStore_filepath.
If no $trStore_filepath given then it will be stored under test report folder.

B<Arguments:>

=over

=item $trStore_filepath 

(optional) full path of the Trace file.If not given then it will be stored under report folder.

=back

B<Return Value:>

=over

=item $trStore_filepath 

filepath of the CANoe trace log '.asc' where it has been stored.

=item Offline return

create a dummy log file in case of offline condition..

=item Error

Error return is undef.

=back

B<Examples:>

    $returned_trStore_filepath = NET_trace_store( );
    $returned_trStore_filepath = NET_trace_store('C:\temp\LIFT_CANOE_log.asc');

B<Note :> 

It Checks : what option user has selected from the logging file Configuration ?

B<CANoe 8.0, 8.2> :-

  Measurement setup -> Logging Block > Logging File Configuration
   -> if option "After each trigger block"  is :
    - checked : RBS won't be stopped to take the log file (log file name will be incremented with each trigger).
    - unchecked : stop the RBS & take the log file.

B<CANoe 8.5, 9.x , 10.x> :-

  Measurement setup -> Logging Block > Logging File Configuration > B<FieldCodes>
   -> if option B<"With each Trigger"> is :
    - selected : RBS won't be stopped to take the log file (log file name will be incremented with each trigger).
    - unselected : stop the RBS & take the log file.
    
=cut

sub NET_trace_store {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_store( [$trStore_filepath] )', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_read_signal

    ($signalvalue, $unit) = NET_read_signal( $bus_signal_name , [$mode, $busType];   

Reads the signal '$bus_signal_name' value for mode (phys or raw) from 'CANoe' while measurement was running.

It search the '$bus_signal_name' from the B<Mapping CAN, CAFD, LIN & FlexRay (order = CAN, CANFD LIN, FlexRay)> and in whichever mapping it founds the signal is defined, then from that Bus it reads the signal value.

B<Arguments:>

=over

=item $bus_signal_name 

bus signal name of type CAN, CANFD, LIN or FlexRay, as defined in CAN, CANFD, LIN or FlexRay mapping file.

=item $mode = ('phys' | 'raw') 

(optional) Mode of the bus signal. Default is 'phys' if not given.

- for 'phys' factor and offset calculation was done before returning the signal value. 

- for 'raw' directly the raw value of signal from CANoe was returned. 

=item $busType = ('CAN' | 'CANFD'| 'LIN' | 'FlexRay')

(optional) Precedence to read signal from  bus is B<CAN - CANFD - LIN - FlexRay>'. If signal '$bus_signal_name' was found in any of the bus (from Mapping_NET_Access_$busType.pm) then it reads the corresponding value.   

B<Note> : 

-   If it is required to write signal for a particular bus only (in case signal is present in two busess and there is a collision) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied signal name, matching signal value will be returned to the user.

-   If there there is an ambiguity in the supplied signal name, list of available signal names(fully qualified) will be displayed to the user in an error.  

=back

B<Return Value:>

=over

=item $returnValue 

$signalvalue - either Physical value or raw value depending on $mode.

$unit  - unit of the signal defined in Mapping file(returns only in case of phys mode , undef for raw mode).

- (Value, Unit)  : Successful

- (1, undef)     : Offline

- (undef, undef) : Failure

=back

B<Examples:>
    
    my $can_signal = 'SigStimulus1_CAN';
    # Read the '$can_signal' value if $can_signal found in Mapping CAN.    
    ( $sigvalue_phy, $unit ) = NET_read_signal( $can_signal);   # read CAN signal 'phys' value  
    ( $sigvalue_phy, $unit ) = NET_read_signal( $can_signal,  'phys' ); # read CAN signal 'phys' value
    ( $sigvalue_raw, $unit ) = NET_read_signal( $can_signal,  'raw' );  # read CAN signal 'raw' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $can_signal,  'phys', 'CAN' );  # read CAN signal 'phys' value only from 'CAN' bus. It will not look into LIN & FlexRay mapping 

    my $canfd_signal = 'SigStimulus1_CANFD';
    # Read the '$can_signal' value if $can_signal found in Mapping CANFD.    
    ( $sigvalue_phy, $unit ) = NET_read_signal( $canfd_signal);   # read CANFD signal 'phys' value  
    ( $sigvalue_phy, $unit ) = NET_read_signal( $canfd_signal,  'phys' ); # read CANFD signal 'phys' value
    ( $sigvalue_raw, $unit ) = NET_read_signal( $canfd_signal,  'raw' );  # read CANFD signal 'raw' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $canfd_signal,  'phys', 'CANFD' );  # read CANFD signal 'phys' value only from 'CANFD' bus. It will not look into CAN, LIN & FlexRay mapping 

    my $lin_signal = 'LockingSystem';    
    # Read the '$lin_signal' value if $lin_signal found in Mapping LIN.
    ( $sigvalue_phy, $unit ) = NET_read_signal( $lin_signal);   # reads the LIN signal 'phys' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $lin_signal,  'phys' ); # reads the LIN signal 'phys' value
    ( $sigvalue_raw, $unit ) = NET_read_signal( $lin_signal,  'raw' );  # reads the LIN signal 'raw' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $lin_signal,  'phys', 'LIN' );  # read LIN signal 'phys' value only from 'LIN' bus. It will not look into CAN, CANFD & FlexRay mapping
    
    my $flexRay_signal = 'SigStimlus1aii';
    # Read the '$flexRay_signal' value if $flexRay_signal found in Mapping FlexRay.        
    ( $sigvalue_phy, $unit ) = NET_read_signal( $flexRay_signal);   # reads the FlexRay signal 'phys' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $flexRay_signal,  'phys' ); # reads the FlexRay signal 'phys' value
    ( $sigvalue_raw, $unit ) = NET_read_signal( $flexRay_signal,  'raw' );  # reads the FlexRay signal 'raw' value
    ( $sigvalue_phy, $unit ) = NET_read_signal( $flexRay_signal,  'phys', 'FlexRay' );  # read FlexRay signal 'phys' value only from 'FlexRay' bus. It will not look into CAN, CANFD & LIN mapping

=cut

sub NET_read_signal {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_read_signal($bus_signal_name , [$mode, $busType])', @args );

    my $bus_signal_name = shift @args;
    my $mode            = shift @args;
    my $busType         = shift @args;

    # STEP Get the SIGNAL to be read
    # STEP Get all the matching occurances of SIGNAL from mapping
    # CALL Fetch_Msg_Or_Signal_Instances
    # IF Number of occurances is 0?
    #   IF-YES-START
    #       STEP Display an error saying the SIGNAL not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       IF Number of occurances is more than 1?
    #           IF-YES-START
    #               STEP Display an error with ist of available names(fully qualified).
    #           IF-YES-END
    #           IF-NO-START
    #               STEP Get the SIGNAL information from the mapping
    #               STEP Return the SIGNAL information to user
    #           IF-NO-END
    #   IF-NO-END
    # STEP End

    Write_Log_Text("Start..");
    my $matched_Signal_aref = Fetch_Msg_Or_Signal_Instances( $bus_signal_name, 'SIGNAL', 'ERR_MUL_INSTANCES', $busType ) || return;
    $bus_signal_name = $matched_Signal_aref->[0];
    my $signalInfo_href = GetSignalInfo( $bus_signal_name, $busType ) || return;
    my $validatedSignalInfo_href = Validate_signal_from_mapping( $signalInfo_href, $bus_signal_name, $signalInfo_href->{'BUS_TYPE'} ) || return;

    unshift @args, $mode;
    unshift @args, $validatedSignalInfo_href;
    my ( $sigValue, $unit ) = CallDeviceFunction(@args);
    Write_Log_Text("read value for signal name '$bus_signal_name' = $sigValue, unit = $unit.");
    return ( $sigValue, $unit );
}

=head2 NET_write_signal

  $status = NET_write_signal ( $bus_signal_name , $bus_signal_value, [$mode, $busType] );   

Write to the signal '$bus_signal_name' value = '$bus_signal_value' for mode (phys or raw) to 'CANoe' while measurement was running.

It search the '$bus_signal_name' from the B<Mapping CAN, CANFD LIN & FlexRay (order = CAN, CANFD, LIN, FlexRay)> and in whichever mapping it founds the signal is defined, then to that Bus it writes the signal value.

B<Arguments:>

=over

=item $bus_signal_name 

bus signal name of type CAN, CANFD, LIN or FlexRay, as defined in CAN, CAFD, LIN or FlexRay mapping file.

=item $mode = ('phys' | 'raw') 

(optional) Mode of the bus signal. Default is 'phys' if not given.

- for 'phys' factor and offset calculation was done before writing the signal value to CANoe. 

- for 'raw' directly the raw value of signal to CANoe was written. 

=item $busType = ('CAN' | 'CANFD'| 'LIN' | 'FlexRay')

(optional) Precedence to write signal to  bus is B<CAN - CANFD - LIN - FlexRay>'. If signal '$bus_signal_name' was found in any of the bus (from Mapping_NET_Access_$busType.pm) then it writes the corresponding value to CANoe.   

B<Note> : 

-   If it is required to write signal for a particular bus only (in case signal is present in two bussed and there is a collision) then pass explicitly the '$busType'.

-   If there is an ambiguity in the supplied signal name, all the matching names will be written with the provided value.

-   If there is NO ambiguity in the supplied signal name, value will be written to the matching name.  

-   If the Interaction Layer is used for RBS ( L</"Devices section:"> ILUsed = 'Yes'), Signal data will be directly written using the signal object.

-   If the Interaction Layer is NOT used for RBS ( L</"Devices section:"> ILUsed = 'No'), Respective Environment/System variable will be written with the signal value. 

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    my $can_signal = 'SigStimulus1_CAN'; 
    # Write the '$can_signal' if $can_signal found in Mapping CAN.    
    $status = NET_write_signal( $can_signal, 10);   # write 'phys' value = 10  to 'CAN' signal
    $status = NET_write_signal( $can_signal, 10 , 'phys' ); # write 'phys' value = 10 to 'CAN' signal
    $status = NET_write_signal( $can_signal, 0xA, 'raw' );  # write 'raw' value = 0xA to 'CAN' signal
    $status = NET_write_signal( $can_signal, 10,  'phys', 'CAN' );  # write 'phys' value = 10 only to 'CAN' signal. It will not look into CANFD, LIN & FlexRay mapping 

    my $canfd_signal = 'SigStimulus1_CANFD'; 
    # Write the '$can_signal' if $can_signal found in Mapping CANFD.    
    $status = NET_write_signal( $canfd_signal, 10);   # write 'phys' value = 10  to 'CANFD' signal
    $status = NET_write_signal( $canfd_signal, 10 , 'phys' ); # write 'phys' value = 10 to 'CANFD' signal
    $status = NET_write_signal( $canfd_signal, 0xA, 'raw' );  # write 'raw' value = 0xA to 'CANFD' signal
    $status = NET_write_signal( $canfd_signal, 10,  'phys', 'CAN' );  # write 'phys' value = 10 only to 'CANFD' signal. It will not look into CAN, LIN & FlexRay mapping 


    my $lin_signal = 'LockingSystem';    
    # Write the '$lin_signal' if $lin_signal found in Mapping LIN.
    $status = NET_write_signal( $lin_signal, 10);    # write 'phys' value = 10  to 'LIN' signal
    $status = NET_write_signal( $lin_signal, 10 , 'phys' ); # write 'phys' value = 10 to 'LIN' signal
    $status = NET_write_signal( $lin_signal, 0xA, 'raw' );  # write 'raw' value = 10 to 'LIN' signal
    $status = NET_write_signal( $lin_signal, 10 , 'phys', 'LIN' );  # write 'phys' value = 10 only to 'LIN' signal. It will not look into CAN, CANFD & FlexRay mapping
    
    my $flexRay_signal = 'SigStimlus1aii';
    # Write the '$flexRay_signal' if $flexRay_signal found in Mapping FlexRay.        
    $status = NET_write_signal( $flexRay_signal, 10);   # write 'phys' value = 10  to 'FlexRay' signal
    $status = NET_write_signal( $flexRay_signal, 10, 'phys' ); # write 'phys' value = 10  to 'FlexRay' signal
    $status = NET_write_signal( $flexRay_signal, 0xA, 'raw' );  # write 'raw' value = 10  to 'FlexRay' signal
    $status = NET_write_signal( $flexRay_signal, 10, 'phys', 'FlexRay' );  # write 'phys' value = 10 only to 'FlexRay' signal. It will not look into CAN, CANFD & LIN mapping

=cut

sub NET_write_signal {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_write_signal ( $bus_signal_name , $bus_signal_value, [$mode, $busType] )', @args );

    my $bus_signal_name  = shift @args;
    my $bus_signal_value = shift @args;
    my $mode             = shift @args;
    my $busType          = shift @args;

    # STEP Get the SIGNAL to be written
    # STEP Get all the matching occurances of SIGNAL from mapping
    # CALL Fetch_Msg_Or_Signal_Instances
    # IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the SIGNAL not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #        IF Is IL Based?
    #             IF-YES-START
    #                 STEP Write the data to all the matching signals using the signal object
    #             IF-YES-END
    #             IF-NO-START
    #                 STEP Get all matching Environment/System variables for the signals matched and write the value
    #                 CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #             IF-NO-END
    #   IF-NO-END
    # STEP End

    Write_Log_Text("Start..");
    Write_Log_Text("args:[signal name = $bus_signal_name, signal value = $bus_signal_value]");
    my $matched_signal_aref = Fetch_Msg_Or_Signal_Instances( $bus_signal_name, 'SIGNAL', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $signal (@$matched_signal_aref) {
        my $signalInfo_href = GetSignalInfo( $signal, $busType ) || return;
        my $validatedSignalInfo_href = Validate_signal_from_mapping( $signalInfo_href, $signal, $signalInfo_href->{'BUS_TYPE'} ) || return;
        unshift @args, $mode;
        unshift @args, $bus_signal_value;
        unshift @args, $validatedSignalInfo_href;
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("Signal - '$signal' = '$bus_signal_value' successfully written for the mode - '$mode'");
        }
        else {
            S_set_error( "NET_write_signal: Failed to write value = '$bus_signal_value' for Signal = '$signal' in the mode = '$mode'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_disable_msg

  NET_disable_msg ( $msgPduFrame, [$busType] );   

When NET Access mapping is present, In order to disable either 'message or pdu or frame' , it writes  B<value = 0> to corresponding Environment/System variable B<(mapping key = CANOE_ENABLE ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

When Mapping Conversion is done, In order to disable either 'message or pdu or frame' , it writes  B<value = 1> to corresponding Environment/System variable B<(mapping key = CANOE_DISABLE ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which disables the 'message or pdu or frame'.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for disabling is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to disable message for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied message name, matching Messages will be disabled.

-   If there is an ambiguity in the supplied message name, all the matching Message names will be disabled.

-   If NET Access Mapping is unavailable then mapping conversion is done.

B<Hint> : for CAN -> Look CANoeIL functionalites like B<ILDisableMsg or ILFaultInjectionDisableMsg>.   

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_disable_msg('MsgStimulus2_CAN');  # Disable CAN message 'MsgStimulus2_CAN'
    NET_disable_msg('PDU_Stimulus2B');  # Disable FlexRay PDU 'PDU_Stimulus2B'
    NET_disable_msg('GW_Ignition');  # Disable LIN Frame 'GW_Ignition'
    NET_disable_msg('GW_Ignition', 'LIN');  # Disable LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_disable_msg {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_disable_msg ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to be disabled
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_ENABLE) for each message matched
    #       STEP Write the value = 0 if NET Access Mapping is present and '1' when mapping conversion is done for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || next;
        Write_Log_Text("try to disable the message '$msgPduFrame' on busType - '$msgInfo_href->{'BUS_TYPE'}'.");
        $msgInfo_href->{'CANOE_ENABLE'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_ENABLE', $msgInfo_href->{'BUS_TYPE'} ) || next;

        unshift( @args, $mapping_converion_done );
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully disabled the message -> '$message'");
        }
        else {
            Write_Error_Text( "failed to disable the message -> '$message' ", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_enable_msg

  NET_enable_msg ( $msgPduFrame, [$busType] );   

When NET Access Mapping is present, In order to enable either 'message or pdu or frame' , it writes  B<value = 1> to corresponding Environment/System variable B<(mapping key = CANOE_ENABLE ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

When Mapping Conversion is done, In order to enable either 'message or pdu or frame' , it writes  B<value = 0> to corresponding Environment/System variable B<(mapping key = CANOE_DISABLE ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which enables the 'message or pdu or frame'.     

B<Hint> : for CAN : Look CANoeIL functionalites like B<ILEnableMsg or ILFaultInjectionEnableMsg>. 

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for enabling is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to enable message for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.   

-   If there is NO ambiguity in the supplied message name, matching Messages will be enabled.

-   If there is an ambiguity in the supplied message name, all the matching Message names will be enabled.

-   If NET Access Mapping is unavailable then mapping conversion is done.

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_enable_msg('MsgStimulus2_CAN');     # Enable CAN message 'MsgStimulus2_CAN'
    NET_enable_msg('PDU_Stimulus2B');       # Enable FlexRay PDU 'PDU_Stimulus2B'
    NET_enable_msg('GW_Ignition');          # Enable LIN Frame 'GW_Ignition'
    NET_enable_msg('GW_Ignition', 'LIN');   # Enable LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_enable_msg {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_enable_msg ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to be enabled
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_ENABLE) for each message matched
    #       STEP Write the value = 1 if NET Access Mapping is present and '0' when mapping conversion is done for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || next;
        Write_Log_Text("try to enable the message '$msgPduFrame' on busType - '$msgInfo_href->{'BUS_TYPE'}'.");
        $msgInfo_href->{'CANOE_ENABLE'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_ENABLE', $msgInfo_href->{'BUS_TYPE'} ) || next;

        unshift( @args, $mapping_converion_done );
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully enabled the Msg -> '$message'. ");
        }
        else {
            Write_Error_Text( "Failed to enable the Msg -> '$message'. ", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_set_dlc

  NET_set_dlc ( $msgPduFrame, $givenDlc, [$busType];   

In order to set DLC either for 'message or pdu or frame', it writes  B<$givenDlc> value to the corresponding Environment/System variable B<(mapping key = CANOE_DLC ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which sets the $givenDlc value for 'message or pdu or frame'.

B<Hint> : for CAN - Look CANoeIL functionalites like B<ILFaultInjectionSetMsgDlc>.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $givenDlc 

New DLC value to be set.

If the "ERROR" is passed, Set the wrong DLC. This is done by subtracting 1 from the DLC from mapping.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for setting $givenDlc is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to set DLC of for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied message name, matching Messages will be set with the supplied Dlc value..

-   If there is an ambiguity in the supplied message name, all the matching Message DLC value will be set with supplied DLC value.

-   If there is no DLC value provided, The DLC to be set will be taken from the mapping.   

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_set_dlc('MsgStimulus2_CAN', 4);  # set Dlc = 4 for CAN message 'MsgStimulus2_CAN'
    NET_set_dlc('PDU_Stimulus2B', 4);  # set Dlc = 4 for flexRay PDU 'PDU_Stimulus2B'
    NET_set_dlc('GW_Ignition', 2);  # # set Dlc = 2 for LIN Frame 'GW_Ignition'
    NET_set_dlc('GW_Ignition', 2, 'LIN');  # set Dlc = 2 for LIN Frame 'GW_Ignition' and look only for LIN frames
    NET_set_dlc('ERROR');  # Set the DLC error
        
=cut

sub NET_set_dlc {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_set_dlc ( $msgPduFrame, $givenDlc, [$busType] )', @args );

    #STEP Get the MESSAGE and DLC value to be Set
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       IF ( given_DLC < 1 and given_DLC > 8 )
    #       IF-YES-START
    #           STEP DLC_value = DLC from mapping(mapping key = 'DLC_Mapping')
    #       IF-YES-END
    #       IF-NO-START
    #       IF-NO-END
    #           STEP Get corresponding Environment/System variable(mapping key = CANOE_DLC) for each message matched
    #           STEP Write the value = DLC_set_value for each System/Environment variable
    #           CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $givenDlc    = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        my $validatedMsgInfo_href = Validate_dlc( $msgInfo_href, $message ) || return;
        unshift( @args, $givenDlc );
        unshift( @args, $validatedMsgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully set the DLC value for messsage -> '$message'.");
        }
        else {
            S_set_error( "NET_set_dlc: Failed to Set the DLC value for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_reset_dlc

  NET_reset_dlc ( $msgPduFrame, [$resetDlcValue, $busType] );   

In order to re-set DLC either for 'message or pdu or frame', it writes B<reset dlc value> to the corresponding Environment/System variable B<(mapping key = CANOE_DLC ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<reset dlc value> can be passed by user = $resetDlcValue or if '$resetDlcValue' is not defined then dlc value from mapping shall be taken.

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which re-sets the dlc value for 'message or pdu or frame'.

B<Hint> : for CAN - Look CANoeIL functionalites like B<ILFaultInjectionResetMsgDlc> or use B<ILFaultInjectionSetMsgDlc> with $resetDlcValue itself to reset the dlc.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $resetDlcValue 

(optional) Reset value can be passed by user $resetDlcValue or if '$resetDlcValue' is not defined then dlc value from mapping shall be taken.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for re-setting $resetDlcValue is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to re-set DLC of for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied message name, matching Messages will be reset with the supplied Dlc value..

-   If there is an ambiguity in the supplied message name, all the matching Message DLC value will be reset with supplied DLC value.

-   If there is no DLC value provided, The DLC to be reset will be taken from the mapping.  

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_reset_dlc('MsgStimulus2_CAN', 8);  # re-set Dlc = 8 for CAN message 'MsgStimulus2_CAN'
    NET_reset_dlc('MsgStimulus2_CAN');  # re-set Dlc = <value from CAN mapping> for CAN message 'MsgStimulus2_CAN'
    NET_reset_dlc('PDU_Stimulus2B', 8);  # reset Dlc = 8 for flexRay PDU 'PDU_Stimulus2B'
    NET_reset_dlc('GW_Ignition', 8);  # re-set Dlc = 8 for LIN Frame 'GW_Ignition'
    NET_reset_dlc('GW_Ignition', 8, 'LIN'); # reset Dlc = 8 for LIN Frame 'GW_Ignition' and look only for LIN frames
        
=cut

sub NET_reset_dlc {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_reset_dlc ( $msgPduFrame, [$resetDlcValue, $busType] )', @args );

    #STEP Get the MESSAGE and DLC value to be Reset
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       IF defined given_DLC and ( given_DLC >= 1 and given_DLC <= 8 )
    #       IF-YES-START
    #           STEP DLC_value = given_DLC
    #       IF-YES-END
    #       IF-NO-START
    #           STEP DLC_value = DLC from mapping(mapping key = 'DLC_Mapping')
    #       IF-NO-END
    #           STEP Get corresponding Environment/System variable(mapping key = CANOE_DLC) for each message matched
    #           STEP Write the value = DLC_reset_value for each System/Environment variable
    #           CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame   = shift @args;
    my $resetDlcValue = shift @args;
    my $busType       = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        my $validatedMsgInfo_href = Validate_dlc( $msgInfo_href, $message ) || return;
        unshift( @args, $resetDlcValue );
        unshift( @args, $validatedMsgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("Successfully reset the DLC value for message -> $message'");
        }
        else {
            S_set_error( "NET_reset_dlc: Failed to Reset the DLC value for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_set_counter_error

  NET_set_counter_error ( $msgPduFrame, [$busType] );   

In order to set Counter error either for 'message or pdu or frame' , it writes  B<value = 0> to corresponding Environment/System variable B<(mapping key = CANOE_VALIDCNT ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which sets Counter error for 'message or pdu or frame'.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for setting Counter error is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to set Counter error for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied Message name, Counter error will be set for the matching Message.

-   If there is an ambiguity in the supplied message name, Counter error will be set for all the matching Message names.
  
=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_set_counter_error('MsgStimulus2_CAN');  # set Counter error for CAN message 'MsgStimulus2_CAN'
    NET_set_counter_error('PDU_Stimulus2B');  # set Counter error for FlexRay PDU 'PDU_Stimulus2B'
    NET_set_counter_error('GW_Ignition');  # set Counter error for LIN Frame 'GW_Ignition'
    NET_set_counter_error('GW_Ignition', 'LIN');  # set Counter error for LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_set_counter_error {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_set_counter_error ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to which the Counter error to be Set
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_VALIDCNT) for each message matched
    #       STEP Write the value = 0 for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        $msgInfo_href->{'CANOE_VALIDCNT'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_VALIDCNT', $msgInfo_href->{'BUS_TYPE'} ) || return;
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully set the Counter error for message - >'$message'.");
        }
        else {
            S_set_error( "NET_set_counter_error: Failed to Set the Counter error for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_reset_counter_error

  NET_reset_counter_error ( $msgPduFrame, [$busType] );   

In order to re-set Counter error either for 'message or pdu or frame' , it writes  B<value = 1> to corresponding Environment/System variable B<(mapping key = CANOE_VALIDCNT ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which re-sets Counter error for 'message or pdu or frame'.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for re-setting Counter error is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to re-set Counter error for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied Message name, Counter error will be reset for the matching Message.

-   If there is an ambiguity in the supplied message name, Counter error will be reset for all the matching Message names. 

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_reset_counter_error('MsgStimulus2_CAN');  # reset Counter error for CAN message 'MsgStimulus2_CAN'
    NET_reset_counter_error('PDU_Stimulus2B');  # reset Counter error for FlexRay PDU 'PDU_Stimulus2B'
    NET_reset_counter_error('GW_Ignition');  # reset Counter error for LIN Frame 'GW_Ignition'
    NET_reset_counter_error('GW_Ignition', 'LIN');  # reset Counter error for LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_reset_counter_error {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_reset_counter_error ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to which the Counter error to be Reset
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_VALIDCNT) for each message matched
    #       STEP Write the value = 1 for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        $msgInfo_href->{'CANOE_VALIDCNT'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_VALIDCNT', $msgInfo_href->{'BUS_TYPE'} ) || return;
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully Reset the Counter error for message -> '$message'. ");
        }
        else {
            S_set_error( "NET_reset_counter_error: Failed to Reset the Counter error for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_set_crc_error

  NET_set_crc_error ( $msgPduFrame, [$busType] );   

In order to set CRC error either for 'message or pdu or frame' , it writes  B<value = 0> to corresponding Environment/System variable B<(mapping key = CANOE_VALIDCRC ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which creates CRC error for 'message or pdu or frame'.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for creating CRC error is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to set CRC error for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.
   
-   If there is NO ambiguity in the supplied Message name, CRC error will be set for the matching Message.

-   If there is an ambiguity in the supplied message name, CRC error will be set for all the matching Message names.

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_set_crc_error('MsgStimulus2_CAN');  # set CRC error for CAN message 'MsgStimulus2_CAN'
    NET_set_crc_error('PDU_Stimulus2B');  # set CRC error for FlexRay PDU 'PDU_Stimulus2B'
    NET_set_crc_error('GW_Ignition');  # set CRC error for LIN Frame 'GW_Ignition'
    NET_set_crc_error('GW_Ignition', 'LIN');  # set CRC error for LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_set_crc_error {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_set_crc_error ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to which the CRC error to be Set
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_VALIDCRC) for each message matched
    #       STEP Write the value = 0 for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        $msgInfo_href->{'CANOE_VALIDCRC'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_VALIDCRC', $msgInfo_href->{'BUS_TYPE'} ) || return;
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("NET_set_crc_error: successfully Set the CRC error for message -> '$message'.");
        }
        else {
            S_set_error( "NET_set_crc_error: Failed to Set the CRC error for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_reset_crc_error

  NET_reset_crc_error ( $msgPduFrame, [$busType] );   

In order to reset CRC error either for 'message or pdu or frame' , it writes  B<value = 1> to corresponding Environment/System variable B<(mapping key = CANOE_VALIDCRC ) > as defined in the Mapping file (CAN, CANFD, LIN or FlexRay).

B<Note> : User has to write the CAPL program on the Environment/System variable event in CANoe which resets CRC error for 'message or pdu or frame'.     

B<Arguments:>

=over

=item $msgPduFrame 

Message, PDU or Frame name of bus CAN, FlexRay or LIN as defined in CAN, LIN or FlexRay mapping file.

=item $busType = ('CAN' | 'CANFD' | 'LIN' | 'FlexRay'). 'CAN' if not defined

(optional) Precedence to search messsage for resetting CRC error is B<CAN - CANFD- LIN - FlexRay>'.   

B<Note> : 

-   If it is required to re-set CRC error for a particular bus only (in case message is present in two buses) then pass explicitly the '$busType'.

-   If there is NO ambiguity in the supplied Message name, CRC error will be reset for the matching Message.

-   If there is an ambiguity in the supplied message name, CRC error will be reset for all the matching Message names.   

=back

B<Return Value:>

=over

=item $returnValue 

$status  B<1>  : Successful & Offline - B<undef> : Failure

=back

B<Examples:>
    
    NET_reset_crc_error('MsgStimulus2_CAN');  # reset CRC error for CAN message 'MsgStimulus2_CAN'
    NET_reset_crc_error('PDU_Stimulus2B');  # reset CRC error for FlexRay PDU 'PDU_Stimulus2B'
    NET_reset_crc_error('GW_Ignition');  # reset CRC error for LIN Frame 'GW_Ignition'
    NET_reset_crc_error('GW_Ignition', 'LIN');  # reset CRC error for LIN Frame 'GW_Ignition' and look only for LIN frames
    
=cut

sub NET_reset_crc_error {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_reset_crc_error ( $msgPduFrame, [$busType] )', @args );

    #STEP Get the MESSAGE to which the CRC error to be Reset
    #STEP Get all the matching occurances of MESSAGE from mapping
    #CALL Fetch_Msg_Or_Signal_Instances
    #   IF Number of occurances is <=0?
    #   IF-YES-START
    #       STEP Display an error saying the MESSAGE not present in mapping.
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Get corresponding Environment/System variable(mapping key = CANOE_VALIDCRC) for each message matched
    #       STEP Write the value = 1 for each System/Environment variable
    #       CALL LIFT_CANoe_device::CANoe_Write_EnvOrSysVar
    #   IF-NO-END
    #STEP End

    my $msgPduFrame = shift @args;
    my $busType     = shift @args;

    Write_Log_Text("Start..");
    my $matched_msgs_aref = Fetch_Msg_Or_Signal_Instances( $msgPduFrame, 'MSG', 'NO_ERR_MUL_INSTANCES', $busType ) || return;
    foreach my $message (@$matched_msgs_aref) {
        my $msgInfo_href = GetMsgPDUInfo( $message, $busType ) || return;
        $msgInfo_href->{'CANOE_VALIDCRC'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $message, 'CANOE_VALIDCRC', $msgInfo_href->{'BUS_TYPE'} ) || return;
        unshift( @args, $msgInfo_href );
        my $status = CallDeviceFunction(@args);
        if ( $status == 1 ) {
            Write_Log_Text("successfully reset the CRC error for message - '$message'.");
        }
        else {
            S_set_error( "NET_reset_crc_error: Failed to Reset the CRC error for Msg='$message'", 23 );
            return;
        }
        undef @args;
    }
    return 1;
}

=head2 NET_set_envVar_value

    NET_set_envVar_value ( $env_var_name, $env_var_value );
    
Sets CANoe B<environment variable> '$env_var_name' to value '$env_var_value'.    

B<Arguments:>

=over

=item $env_var_name 

Environment variables name that must be defined in the *.dbc file & added to respective CANoe Configuration.
Supported variable types are "Integer, Float, String, Data".

=item $env_var_value 

value to be set for the environment variable. Value can be Integer, Float, String, data.

- expects $env_var_name as scalar value for EnvVar type of type B<Integer, Float, String>
 
- expects $env_var_name as array_ref if EnvVar type is B<Data>

- Integer and Data may be hex or dec or bin.

=back

B<Return Value:>

=over

=item Offine & Success = 1

=back

B<Examples:>    

    NET_set_envVar_value('Env_Var_Typ_int', 10);                         # Int  
    NET_set_envVar_value('Env_Var_Typ_int', 10.25);                      # Int (set value 10)
    NET_set_envVar_value('Env_Var_Typ_Float', 102.25);                   # Float
    NET_set_envVar_value('Env_Var_Typ_String', "LRT ENV testing");       # String
    NET_set_envVar_value('Env_Var_Typ_Data', [0xA, 0xB, 0xC, 0xD, 0xE]); # Data
 
=cut

sub NET_set_envVar_value {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_set_envVar_value( $env_var_name, $env_var_value_mix)', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_get_envVar_value

Returns scalar value for EnvVar of type B<Integer, Float, String> and returns array_ref of dec values if EnvVar type is B<Data>.

B<Arguments:>

=over

=item $env_var_name 

Environment variables name that must be defined in the *.dbc file & added to respective CANoe Configuration.
Supported variable types are "Integer, Float, String, Data".

=back

B<Return Value:>

=over

=item Offine = 1

=item $env_var_value 

- scalar value for EnvVar of type B<Integer, Float, String> 

- array_ref of dec values if EnvVar type is B<Data>.

=back

B<Examples:>    

    $intVal   = NET_get_envVar_value('Env_Var_Typ_int');       # Interger  
    $floatVal = NET_get_envVar_value('Env_Var_Typ_Float');     # Float
    $stringVal= NET_get_envVar_value('Env_Var_Typ_String');    # String
    $arrRef   = NET_get_envVar_value('Env_Var_Typ_Data');      # Data

=cut

sub NET_get_envVar_value {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_get_envVar_value( $env_var_name)', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_set_sysVar_value

    NET_set_sysVar_value( $sys_var_name, $sys_var_value );

Sets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array>  to CANoe. 

For configuration refer L</"Functions section:"> of Testbench configuration.

B<Arguments:>

=over

=item $sys_var_name 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are "Integer, Float, String, Integer Array , Float Array".

MULTIPLE level of namespace are also supported.

=item $sys_var_value 

value to be set for the system variable. Value can be Integer, Float, String, Integer Array , Float Array.
It depends on what kind of System variable has been defined in the system variable file. Pass it accordingly.

=back

B<Return Value:>

=over

=item Offine & Success = 1

=back

B<Examples:>

    # -----------------------------------
    # exmaples for SINGLE LEVEL NAMESPACE
    # -----------------------------------
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Int', 0xFF) ;        # set integer value
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Int', 255) ;         # set integer value
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_Type_Float',  525.25) ;    # set float value
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_Type_String',  "LRT SYSVAR testing") ;   # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    NET_set_sysVar_value('LIFT_CAN_access::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;  

    # -------------------------------------
    # exmaples for MULTIPLE LEVEL NAMESPACE
    # --------------------------------------
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 0xFF) ;      # set integer value
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 255) ;       # set integer value
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float',  525.25) ; # set float value
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String', "LRT SYSVAR testing") ; # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;    
    
    # -------------------------------------
    # Example for usage of wait time to read back the system variable value immediately
    # --------------------------------------
    NET_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 0xFF) ; 
    S_wait_ms(200); # Wait time to get the system variable value immediately

B<Notes:>
 
1) For Integer array & Float Array, B<specify all the values or dataPoints> as defiend in the system variable file. See the variable defination.

2) Multiple level of namespace for System varible are supported. 

3) To read back the system variable value immediately, the tester can give a wait time of 30ms to 200ms in TC_LRT_NET_Access__SystemVariables after NET_set_sysVar_value( $sysVarName, $sysVar_setVal ).

=cut

sub NET_set_sysVar_value {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_set_sysVar_value( $sys_var_name, $sys_var_value_mix)', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_get_sysVar_value

    $sys_var_value = NET_get_sysVar_value( $sys_var_name)

Gets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array>  from CANoe. 

For configuration refer L</"Functions section:"> of Testbench configuration.

B<Arguments:>

=over

=item $sys_var 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are of type : "Integer, Float, String, Integer Array , Float Array".

=back

B<Return Value:>

=over

=item $return_sys_var_value 

on Success it will return = "Integer, Float, String, Integer Array , Float Array" depends on the type of System variable defined in CANoe (System variable file) .

=item $offline 

Offline return is 1. 

=back

B<Examples:>
  
  # -----------------------------------
  # exmaples for SINGLE LEVEL NAMESPACE
  # -----------------------------------
  $intVal       = NET_get_sysVar_value('LIFT_CAN_access::SysVar_Type_Int') ;       # get integer value  
  $floatVal     = NET_get_sysVar_value('LIFT_CAN_access::SysVar_Type_Float') ;     # get float value
  $stringVal    = NET_get_sysVar_value('LIFT_CAN_access::SysVar_Type_String') ;    # get string value
  $float_aref   = NET_get_sysVar_value('LIFT_CAN_access::SysVar_FloatArray');      # get float array value as array reference
  $integer_aref = NET_get_sysVar_value('LIFT_CAN_access::SysVar_IntegerArray');    # get Integer array value as array reference

  # -------------------------------------
  # exmaples for MULTIPLE LEVEL NAMESPACE
  # --------------------------------------
  $intVal = NET_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int') ;     # get integer value  
  $floatVal = NET_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float') ;   # get float value
  $stringVal = NET_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String') ;  # get string value
  $float_aref = NET_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray');    # get float array value as array reference
  $integer_aref = NET_get_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray');  # get Integer array value as array reference  

B<Notes:>
 
Multiple level of namespace for System varible are supported.  

=cut

sub NET_get_sysVar_value {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_get_sysVar_value( $sys_var_name)', @args );
    return CallDeviceFunction(@args);
}

=head2  NET_trace_get_dataref

    $data_href = NET_trace_get_dataref ( $trace_file_path, $options_search_href );
    
Reads a trace file $trace_file_path and get the time stamps & data of passed B<signals, messages and system variables> 
into a hash-tree and returns the reference to that hash-tree.

Reads Signals and messages of bus type CAN, CANFD, LIN & FlexRay. 
    
B<Arguments:>

=over

=item $trace_file_path 

Path to the trace file.

=item $options_search_href 

Hash reference of message/signals/sysvars to be searched in the CANoe trace. 

B<Note>: atleast one of the option must be passed out of B<'MESSAGES', 'SIGNALS', 'SYSVARS'>. refer examples below for more info. 

=back

B<Return Value:>

=over

=item $data_href 

Hash reference of the data. See below for details.

=back

B<Examples:>

B< 1.0 - Example-General format:>    

    $data_href = NET_trace_get_dataref(
                           $can_log_file, 
                           {
                               'MESSAGES' => ['message_A', 'message_B'],
                               'SIGNALS'  => ['signal_1','signal_2'],
                               'SYSVARS'  => ['Full_qualified_system_variable']
                           }
                         );

    # Structure of returned $data_href:

    $data_href = {
        'timestamp_1' => {
                         'message_A' => {
                                        'DATA_A' => 'phys_value_at_time_1' ,
                                        'DLC_A' => 'DLC_A',
                                        }
                         'signal_1' => 'phys_value_at_time_1',
                         'signal_2' => 'phys_value_at_time_1',
                         'message_B' => {
                                        'DATA_B' => 'phys_value_at_time_1' ,
                                        'DLC_B' => 'DLC_B',
                                        }
                          },
        'timestamp_2' => {
                         'message_A' => {
                                        'DATA_A' => 'phys_value_at_time_2' ,
                                        'DLC_A' => 'DLC_A',
                                        }
                         'signal_1' => 'phys_value_at_time_2',
                         'signal_2' => 'phys_value_at_time_2',
                         'message_B' => {
                                        'DATA_B' => 'phys_value_at_time_2' ,
                                        'DLC_B' => 'DLC_B',
                                        }
                         },
        'timestamp_3' => {
                         'Full_qualified_system_variable' => 'value_at_timestamp_3',
                         },                                         
      };


B< 2.0 - Example dataref for MESSAGES - CAN, LIN and FlexRay togther>

Trace file 'Example_CANoe_trace.asc' content:

    base hex  timestamps absolute
    internal events logged
    // version 8.5.0
    Begin Triggerblock Wed Jul 5 03:23:20.244 pm 2017
       0.000000 Start of measurement
       0.000028 Fr PDU   0 24 1 1 1 0 Tx 0 34c02 5  20  638 PDU_Stimulus1A  2  2 00 00 0  0  0   0
       0.000028 Fr RMSG  0 24 1 1 1 0 Tx 0 284c02 5  20  638 FrameStimulus_1 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2A  3  3 00 00 00 0  0  0   0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2B  1  1 00 0  0  0   3
       0.000061 Fr RMSG  0 17 1 1 2 0 Tx 0 284c02 5  20  427 FrameStimulus_2 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.001254 1  0               Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 0
       0.001376 1  77F             Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 77F
       0.001494 1  2               Tx   d 1 00  Length = 112000 BitCount = 59 ID = 2
       0.001614 1  3               Tx   d 1 00  Length = 114000 BitCount = 60 ID = 3
       0.001808 1  4               Tx   d 5 00 00 00 00 01  Length = 188000 BitCount = 97 ID = 4
       0.001926 1  5               Tx   d 1 01  Length = 112000 BitCount = 59 ID = 5
       0.006000 Li 11              Tx     1 fe                       checksum = 01   header time =  40, full time =  60  SOF =    0.000000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.006000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic
       0.066000 Li f               Tx     1 fc                       checksum = 03   header time =  40, full time =  60  SOF =    0.060000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.066000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic  
    End TriggerBlock

2.1 example with B<full> name :

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'MESSAGES' => [  'CAN1::MsgStimulus2_CAN', 'CAN1::MsgStimulus1_CAN', 
                             'LIN1::GW_Ignition', 
                             'FLEXRAY1::PDU_Stimulus1A', 'FLEXRAY1::PDU_Stimulus2A' ]
        }
    );
    
    $trace_dataref =
    {
        '0.001254' => {
            'CAN1::MsgStimulus1_CAN' => {
                'DLC'  => '8',
                'DATA' => '00 00 00 00 00 00 00 00  '
            }
          },
          '0.000061' => {
            'FLEXRAY1::PDU_Stimulus2A' => {
                'DLC_2' => 3,
                'DATA'  => '00 00 00',
                'DLC_1' => 3
            }
          },
          '0.000028' => {
            'FLEXRAY1::PDU_Stimulus1A' => {
                'DLC_2' => 2,
                'DATA'  => '00 00',
                'DLC_1' => 2
            }
          },
          '0.066000' => {
            'LIN1::GW_Ignition' => {
                'DLC'  => '1',
                'DATA' => ' fc'
            }
          },
          '0.001494' => {
            'CAN1::MsgStimulus2_CAN' => {
                'DLC'  => '1',
                'DATA' => '00  '
            }
          }
    };


2.2 example with B<short> name :

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'MESSAGES' => [  'MsgStimulus2_CAN', 'MsgStimulus1_CAN', 
                             'GW_Ignition', 
                             'PDU_Stimulus1A', 'PDU_Stimulus2A' ]
        }
    );
    
    $trace_dataref =
    {
        '0.001254' => {
            'CAN1::MsgStimulus1_CAN' => {
                'DLC'  => '8',
                'DATA' => '00 00 00 00 00 00 00 00  '
            }
          },
          '0.000061' => {
            'FLEXRAY1::PDU_Stimulus2A' => {
                'DLC_2' => 3,
                'DATA'  => '00 00 00',
                'DLC_1' => 3
            }
          },
          '0.000028' => {
            'FLEXRAY1::PDU_Stimulus1A' => {
                'DLC_2' => 2,
                'DATA'  => '00 00',
                'DLC_1' => 2
            }
          },
          '0.066000' => {
            'LIN1::GW_Ignition' => {
                'DLC'  => '1',
                'DATA' => ' fc'
            }
          },
          '0.001494' => {
            'CAN1::MsgStimulus2_CAN' => {
                'DLC'  => '1',
                'DATA' => '00  '
            }
          }
    };


B< 3.0 Example dataref for MESSAGES - for FlexRay, AUTOSAR 4.3 version format>

Trace file 'Example_CANoe_trace.asc' content:
Note : There is no PDU line is present.

    date Wed Jul 5 03:23:20.244 pm 2017
    base hex  timestamps absolute
    internal events logged
    // version 8.5.0
    Begin Triggerblock Wed Jul 5 03:23:20.244 pm 2017
        0.000000 Start of measurement
        3702.736816 Fr RMSG  0 0 1 1 8 7 Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 3c 00 02 05 3f 35 14 ff ff 37 80 01 08 70 8e f8 00 00 00 00 00 47 8d 01 08 82 14 0a fc 00 00 00 00 3a 00 54 08 01 00 00 00 00 00 00 00 47 8d 07 0a 2b cb f8 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        3702.936812 Fr RMSG  0 0 1 1 8 2f Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 37 80 01 08 96 79 02 00 00 00 00 00 3a 00 54 08 00 01 00 00 00 00 00 00 80 d2 7f 10 80 00 06 00 80 ca 7f 09 80 ff ff 00 80 00 00 00 00 47 8d 07 0a 95 dc 02 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        3703.936795 Fr RMSG  0 0 1 1 8 37 Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 37 80 01 08 e6 72 34 00 00 00 00 00 3a 00 54 08 00 00 01 00 00 00 00 00 ff ff ff ff ff 00 86 ff ff ff ff ff ff ff ff ff ff 00 00 00 00 47 8d 07 0a f8 7e 34 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
        3704.336788 Fr RMSG  0 0 1 1 8 7 Rx 0 e 5  20  6f8 ORC_CHASSIS_Container_ST3 40 40 37 80 01 08 a1 7f 48 00 00 00 00 00 3a 00 54 08 00 00 00 01 00 00 00 00 ff ff ff ff ff 00 86 ff ff ff ff ff ff ff ff ff ff 00 00 00 00 47 8d 07 0a 87 30 48 00 00 fe 00 00 00 00 00 00 00 00 00 0  0  0
    End TriggerBlock
    START_TRACE

example :

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'MESSAGES' => ['ORC_CHASSIS_Container_ST3_ROE_ORC_ST3']
        }
    );
    
    $trace_dataref =
    {
        '3702.736816' => {
            'FLEXRAY1::ORC_CHASSIS_Container_ST3_ROE_ORC_ST3' => {
                'DLC_2' => 8,
                'DATA'  => '01 00 00 00 00 00 00 00',
                'DLC_1' => 8
            }
          },
          '3703.936795' => {
            'FLEXRAY1::ORC_CHASSIS_Container_ST3_ROE_ORC_ST3' => {
                'DLC_2' => 8,
                'DATA'  => '00 00 01 00 00 00 00 00',
                'DLC_1' => 8
            }
          },
          '3702.936812' => {
            'FLEXRAY1::ORC_CHASSIS_Container_ST3_ROE_ORC_ST3' => {
                'DLC_2' => 8,
                'DATA'  => '00 01 00 00 00 00 00 00',
                'DLC_1' => 8
            }
          },
          '3704.336788' => {
            'FLEXRAY1::ORC_CHASSIS_Container_ST3_ROE_ORC_ST3' => {
                'DLC_2' => 8,
                'DATA'  => '00 00 00 01 00 00 00 00',
                'DLC_1' => 8
            }
          }
    };


B<4.0 Example dataref for SIGNALS - CAN, LIN and FlexRay togther>

Trace file 'Example_CANoe_trace.asc' content:

    base hex  timestamps absolute
    internal events logged
    // version 8.5.0
    Begin Triggerblock Wed Jul 5 03:23:20.244 pm 2017
       0.000000 Start of measurement
       0.000028 Fr PDU   0 24 1 1 1 0 Tx 0 34c02 5  20  638 PDU_Stimulus1A  2  2 00 00 0  0  0   0
       0.000028 Fr RMSG  0 24 1 1 1 0 Tx 0 284c02 5  20  638 FrameStimulus_1 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2A  3  3 00 00 00 0  0  0   0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2B  1  1 00 0  0  0   3
       0.000061 Fr RMSG  0 17 1 1 2 0 Tx 0 284c02 5  20  427 FrameStimulus_2 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.001254 1  0               Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 0
       0.001376 1  77F             Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 77F
       0.001494 1  2               Tx   d 1 00  Length = 112000 BitCount = 59 ID = 2
       0.001614 1  3               Tx   d 1 00  Length = 114000 BitCount = 60 ID = 3
       0.001808 1  4               Tx   d 5 00 00 00 00 01  Length = 188000 BitCount = 97 ID = 4
       0.001926 1  5               Tx   d 1 01  Length = 112000 BitCount = 59 ID = 5
       0.006000 Li 11              Tx     1 fe                       checksum = 01   header time =  40, full time =  60  SOF =    0.000000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.006000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic
       0.066000 Li f               Tx     1 fc                       checksum = 03   header time =  40, full time =  60  SOF =    0.060000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.066000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic  
    End TriggerBlock

4.1 example with B<full> name :

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'SIGNALS' => [ 'CAN1::MsgStimulus1_CAN::SigStimulus1_CAN',
                            'LIN1::GW_Ignition::PowerOn', 
                            'FLEXRAY1::PDU_Stimulus1A::SigStimlus1ai', 'FLEXRAY1::PDU_Stimulus1A::SigStimlus1aii' ]
        }
    );
    
    $trace_dataref =
        {
        '0.001254' => {
            'CAN1::MsgStimulus1_CAN' => {
                'DLC'  => '8',
                'DATA' => '00 00 00 00 00 00 00 00  '
            },
            'CAN1::MsgStimulus1_CAN::SigStimulus1_CAN' => 0
          },
          '0.000028' => {
            'FLEXRAY1::PDU_Stimulus1A' => {
                'DLC_2' => 2,
                'DATA'  => '00 00',
                'DLC_1' => 2
            },
            'FLEXRAY1::PDU_Stimulus1A::SigStimlus1aii' => 0,
            'FLEXRAY1::PDU_Stimulus1A::SigStimlus1ai'  => 0
          },
          '0.066000' => {
            'LIN1::GW_Ignition' => {
                'DLC'  => '1',
                'DATA' => ' fc'
            },
            'LIN1::GW_Ignition::PowerOn' => 0
          }
    };


4.2 example with B<short> name :

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'SIGNALS' => [  'SigStimulus1_CAN',
                            'PowerOn', 
                            'SigStimlus1ai', 'SigStimlus1aii' ]
        }
    );
    
    $trace_dataref =
        {
        '0.001254' => {
            'CAN1::MsgStimulus1_CAN' => {
                'DLC'  => '8',
                'DATA' => '00 00 00 00 00 00 00 00  '
            },
            'CAN1::MsgStimulus1_CAN::SigStimulus1_CAN' => 0
          },
          '0.000028' => {
            'FLEXRAY1::PDU_Stimulus1A' => {
                'DLC_2' => 2,
                'DATA'  => '00 00',
                'DLC_1' => 2
            },
            'FLEXRAY1::PDU_Stimulus1A::SigStimlus1aii' => 0,
            'FLEXRAY1::PDU_Stimulus1A::SigStimlus1ai'  => 0
          },
          '0.066000' => {
            'LIN1::GW_Ignition' => {
                'DLC'  => '1',
                'DATA' => ' fc'
            },
            'LIN1::GW_Ignition::PowerOn' => 0
          }
    };


B<5.0 Example dataref for SYSVARS>

Trace file 'Example_CANoe_trace.asc' content:

    base hex  timestamps absolute
    internal events logged
    // version 8.5.0
    Begin Triggerblock Wed Jul 5 03:23:20.244 pm 2017
       0.000000 Start of measurement
       0.000000    SV: 5 0 1 ::Analysis::SVResponseTime = A32 ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff
       0.000028 Fr PDU   0 24 1 1 1 0 Tx 0 34c02 5  20  638 PDU_Stimulus1A  2  2 00 00 0  0  0   0
       0.000028 Fr RMSG  0 24 1 1 1 0 Tx 0 284c02 5  20  638 FrameStimulus_1 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2A  3  3 00 00 00 0  0  0   0
       0.000061 Fr PDU   0 17 1 1 2 0 Tx 0 34c02 5  20  427 PDU_Stimulus2B  1  1 00 0  0  0   3
       0.000061 Fr RMSG  0 17 1 1 2 0 Tx 0 284c02 5  20  427 FrameStimulus_2 10 10 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0  0  0
       0.001254 1  0               Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 0
       0.001376 1  77F             Tx   d 8 00 00 00 00 00 00 00 00  Length = 248000 BitCount = 127 ID = 77F
       0.001494 1  2               Tx   d 1 00  Length = 112000 BitCount = 59 ID = 2
       0.001614 1  3               Tx   d 1 00  Length = 114000 BitCount = 60 ID = 3
       0.001808 1  4               Tx   d 5 00 00 00 00 01  Length = 188000 BitCount = 97 ID = 4
       0.001926 1  5               Tx   d 1 01  Length = 112000 BitCount = 59 ID = 5
       0.006000 Li 11              Tx     1 fe                       checksum = 01   header time =  40, full time =  60  SOF =    0.000000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.006000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic
       0.066000 Li f               Tx     1 fc                       checksum = 03   header time =  40, full time =  60  SOF =    0.060000   BR = 0      break = 0      0        EOH =    0.000000    EOB =    0.000000    sim = 1    EOF =    0.066000   RBR = 0      HBR = 0.000000  HSO = 0         RSO = 0         CSM = classic  
       0.182629    SV: 2 0 1 ::Stimulus::SVTriggerEnabled = 1
       0.185710    SV: 2 0 1 ::Stimulus::SVTriggerSoft = 1
       0.186582    SV: 5 0 1 ::Analysis::SVResponseTime = A32 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
        End TriggerBlock
 
example:

    my $traceStorePath = 'C:\temp\Example_CANoe_trace.asc';
    my $trace_dataref = NET_trace_get_dataref(
        $traceStorePath,
        {
            'SYSVARS' => [ 'Analysis::SVResponseTime', 'Stimulus::SVTriggerSoft', 'Stimulus::SVTriggerEnabled' ]
        }
    );
    
    $trace_dataref =
    {
        '0.182629' => {
            'Stimulus::SVTriggerEnabled' => '1'
        },
        '0.000000' => {
            'Analysis::SVResponseTime' => 'A32'
        },
        '0.185710' => {
            'Stimulus::SVTriggerSoft' => '1'
        },
        '0.186582' => {
            'Analysis::SVResponseTime' => 'A32'
        }
    };


B<Hint for evaluation:> 

  The data hash can be sorted via :-
 
  foreach my $ascending_sorted_timestamp ( keys sort { $a <=> $b } %$data_href  ) {
     what you want to evaluate
  }

  (Note: for numerical descending just use { $b <=> $a } )
  or you can use the functions provided in LIFT_evaluation package,
  e.g.
  use LIFT_evaluation;
  EVAL_get_time_when
  EVAL_get_values_at_time
  EVAL_get_values_over_time
  EVAL_evaluate_values_at_time
  EVAL_evaluate_values_in_trace
  ...

=cut

sub NET_trace_get_dataref {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_get_dataref( $trace_file_path, $options_search_href)', @args );
    return CallDeviceFunction(@args);
}

=head1 Function Group 'stimulate'

=head2 NET_stimulate_load_signal_curves

    NET_stimulate_load_signal_curves($busSignal_curves_href, $Triggertype);

Loads the bus signal curves to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes, 
software  L</"NET_stimulate_start_now"> or hardware trigger L</"NET_stimulate_start_with_external_trigger">. 

B<Prerequiste> :

- prepare CANoeCtrl mapping.

- prepare the CAPL files (assign it to system variable and the signal name from CAN / FlexRay database).

- template is availble here :
g:/MKS/Projects/TurboLIFT/System/develop/develop.pj  

/develop/CANoeCtrl/CANoeCtrl_Control/template/nodes/CREIS/CREIS.can

- refer B< L<"Tutorials"> - Dynamic stimulation of CAN signals > for more info.

B<Remark> :

- This function shall be called before CANoe measurement starts (start of RBS), 

- In case B<measurement was already running> :
-   a) first it will B<stop the measurement> and signal(s) shall be configured.
-   b) once signal(s) are configured then B<measurement shall be started> if it was running before but without logging. If you want logging then call NET_trace_start.
  
- The signal is identified by an index, the mapping to the corresponding signal must be done in the CAPL program of the network node.
  Signal indices must be continuous, starting at 0. 
       
B<Arguments:>

=over

=item $busSignal_curves_href
 
hash reference containing the signal name, sample time and signal values.

=item $Triggertype

'Triggersoft' or 'Triggerhard'

=back

B<Return Value:>

B<1>  : Successful & Offline - B<undef> : Failure

B<Examples:>
  
    $busSignal_curves_href = {
        'SigStimulus1_CAN' => {
            'SAMPLETIME_US'=> 10000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
        'SigStimulus2_CAN' => {
            'SAMPLETIME_US'=> 20000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
         ...
    };

    NET_stimulate_load_signal_curves( $busSignal_curves_href, 'Triggersoft');
    NET_stimulate_load_signal_curves( $busSignal_curves_href, 'Triggerhard');

=cut

sub NET_stimulate_load_signal_curves {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_load_signal_curves($busSignal_curves_href, $triggertype)', @args );

    my $canoe_meas_was_running = CANoe_measurement_running_status();
    CallDeviceFunction(@args);

    # Start the measurement if it was running before but not otherwise
    NET_simulation_start() if ( $canoe_meas_was_running == 1 );
    return 1;
}

=head2 NET_stimulate_reset_signal_curves

    NET_stimulate_reset_signal_curves();

Resets the signal curve. Clears the system variable buffer data.
Shall be called before L<"NET_stimulate_load_signal_curves">.  

=cut

sub NET_stimulate_reset_signal_curves {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_reset_signal_curves()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_stimulate_load_timed_signals

    NET_stimulate_load_timed_signals( $signal_name, $signalValue_1, $triggertype , [$timeshift_ms, $signalValue_2]);

The signal value will be set to $signalValue_1 when the trigger occurs, and optional (if $timeshift_ms > 0) to $signalValue_2 after further <$timeshift_ms> milliseconds.
Loads the timed signal curves to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes, 
software (NET_stimulate_start_now) or hardware (NET_stimulate_start_with_external_trigger).

B<Arguments:>

=over

=item $signal_name
 
Signal name as defined in CANoeCtrl Mapping file.

=item $signalValue_1

First signal value to set when trigger occurs.

=item $Triggertype

'Triggersoft' or 'Triggerhard'

=item $timeshift_ms

(optional) timeshift value in ms after trigger occurs, require to set $signalValue_2. If not defined considered as 0. 

=item $signalValue_2

(optional) 2nd signal value to set after trigger occurs. If $timeshift_ms is 0. then it has no effect.

=back
  
B<Prerequiste> :

- prepare CANoeCtrl mapping.

- prepare the CAPL files (assign it to system variable and the signal name from CAN / FlexRay database).

- template is availble here :
g:/MKS/Projects/TurboLIFT/System/develop/develop.pj  

/develop/CANoeCtrl/CANoeCtrl_Control/template/nodes/CREIS/CREIS.can

- refer B< L<"Tutorials"> - Dynamic stimulation of CAN signals > for more info.

B<Examples>:

    NET_stimulate_load_timed_signals( 'SigTimed1_CAN', '45.25', 'Triggersoft',  '500', '100.55')  ;
    NET_stimulate_load_timed_signals( 'SigTimed1_CAN', '45.25', 'Triggerhard',  '500', '100.55')  ;
    NET_stimulate_load_timed_signals( 'SigTimed1_CAN', '45', 'Triggersoft',  0, 0)  ;
    NET_stimulate_load_timed_signals( 'SigTimed1_CAN', '45', 'Triggerhard',  0, 0)  ;
    
=cut

sub NET_stimulate_load_timed_signals {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_load_timed_signals ($signal_name, $signalValue_1, $triggertype , [$timeshift_ms, $signalValue_2])', @args );

    my $canoe_meas_was_running = CANoe_measurement_running_status();
    CallDeviceFunction(@args);

    # STEP Start the measurement if it was running before but not otherwise.
    NET_simulation_start() if ( $canoe_meas_was_running == 1 );
    return 1;
}

=head2 NET_stimulate_start_now

    NET_stimulate_start_now();

Starts the output of the configured signals curvers or timed signals on software trigger.
This function can only be called when measurement (RBS) is running, otherwise it has no effect and 0 is returned.

B<Example>:

    NET_stimulate_start_now();

=cut

sub NET_stimulate_start_now {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_start_now()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_stimulate_start_with_external_trigger

    NET_stimulate_start_with_external_trigger();

Starts the output of the configured signals curvers or timed signals on hardware trigger.
This function can only be called when measurement (RBS) is running, otherwise it has no effect and 0 is returned.

B<Example>:

    NET_stimulate_start_with_external_trigger() ;

=cut

sub NET_stimulate_start_with_external_trigger {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_start_with_external_trigger()', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_CAPL_config

    NET_CAPL_config( [$capl_functions_aref] );

Configures the CAPL functions that was written by user in CAPL script..  

B<Note> : This should be called before start of the measurement. 
call  L</"NET_CAPL_invoke"> to invoke it later after start of measurement.

B<Arguments:>

=over

=item $capl_functions_aref 

(optional) list of one or more function(s) to be configured before calling it. 
If not given then if will search if functions are given in the project constant [ 'CANoe', 'CAPL_Functions' ] to configure..

=back

B<Return Value:>

= B<1> : Successful & Offline - B<undef> : Failure

B<Examples:>

    NET_CAPL_config( ['MyCAPLFunc', 'MyCAPLFunc1', 'MyCAPLFunc2'] );
    NET_CAPL_config( ); # get the CAPL fucntion list from project constant.

=cut

sub NET_CAPL_config {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_CAPL_config( [$capl_functions_aref])', @args );
    return CallDeviceFunction(@args);
}

=head2 NET_CAPL_invoke

    ($status, $result) = NET_CAPL_invoke ($capl_function, [ $parameters_aref ]);

Calls the registered CAPL function with input arguments of the function.

B<Notes:> 

This can only be done during measurement (RBS is running). 
The passed number of arguments must be the same as the CAPL function in CANoe expects,
CAPL functions with return values are only supported in the evaluation branch of the CANoe configuration, 
i.e. CAPL functions in programs assigned to network nodes in the simulation setup cannot return result values.

B<Arguments:>

=over

=item $capl_function 

Function name from that must be configured first by  L</"NET_CAPL_config">

=item $parameters_aref 

(optionals) val1, val2, .. val8 - Input parameters for the given function name if any, max 8

=back

B<Return Value:>

=over

=item Offine & Success = 1

=back

B<Examples:>

    NET_CAPL_invoke('MyCAPLFunc');
    NET_CAPL_invoke( 'MyCAPLFunc1', [100] );
    NET_CAPL_invoke( 'MyCAPLFunc2', [200, 201] );    

=cut

sub NET_CAPL_invoke {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_CAPL_invoke( $capl_function, [ $parameters_aref ] )', @args );
    return CallDeviceFunction(@args);
}

=head1 NOT Exported functions

=head2 Init_CANoe

    Init_CANoe();

Initialize the module 'LIFT_CANoe_device'.    

=cut

sub Init_CANoe {
    eval "use LIFT_CANoe_device";
    CANoe_Init();
    return 1;
}

=head2 Init_CANoeCtrl

    Init_CANoeCtrl();

Initialize the module 'LIFT_CANoeCtrl'.

=cut

sub Init_CANoeCtrl {
    eval "use LIFT_CANoeCtrl";
    CANoeCtrl_Init();
    return 1;
}

=head2 WhichBusMapping_MsgOrSignal_BelongsTo

    $bus_Mapping = WhichBusMapping_MsgOrSignal_BelongsTo ($msgOrSignalName, $lookUp_MsgorSignal [$busType]);

It searches 'message or signal' as in which mapping files it is preset.  

B<Arguments:>

=over

=item $msgOrSignalName 

'message' or signal name as in mapping files.

=item $lookUp_MsgorSignal ('MSG' | 'SIGNAL')

look for message or signal

=back

B<example> :

    $msgName = 'M_Stimulus_CAN1';
    my $bus_Mapping = WhichBusMapping_MsgOrSignal_BelongsTo( $msgName, 'MSG', $busType );
    
    $busSignalName = 'Sig_Stimulus_CAN1';
    my $bus_Mapping = WhichBusMapping_MsgOrSignal_BelongsTo( $busSignalName, 'SIGNAL', $busType );

=cut

sub WhichBusMapping_MsgOrSignal_BelongsTo {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'WhichBusMapping_MsgOrSignal_BelongsTo ($msgOrSignalName, $lookUp_MsgorSignal [,$busType])', @args );
    my $msgOrSignalName    = shift @args;
    my $lookUp_MsgorSignal = shift @args;
    my $busType            = shift @args;

    my @netbus = qw (CAN CANFD LIN FlexRay);

    # STEP look specific $busType if given by user or else look into 'CAN LIN & FlexRay'
    if ( defined $busType ) {
        unless ( grep { /^$busType$/i } @netbus ) {
            S_set_error( "ERROR : BusType = '$busType' is not valid. It must be one of these : < @netbus > \n", 20 );
            return;
        }
        undef @netbus;
        $netbus[0] = $busType;
    }

    # STEP - search is 'msg or signal' based in mapping ?
    my @searchOptions = qw(MSG SIGNAL);
    unless ( grep { /^$lookUp_MsgorSignal$/i } @searchOptions ) {
        S_set_error( "ERROR : \$lookUp_MsgorSignal = '$lookUp_MsgorSignal' is not valid. It must be one of these : < @searchOptions > \n", 20 );
        return;
    }
    my ( $foundBus, $bus_Mapping );
    my $busMsg_grp_name;

    #Check if the Msg/Signal name has the hint to Bus_type
    if ( $msgOrSignalName =~ /^(CAN|CANFD|LIN|FLEXRAY)\d+::/i ) {
        $busType = $1;
        @netbus  = ($busType);
    }

    # STEP - $msgOrSignalName belongs to any one of mappings : <CAN LIN or FlexRay> ?
    foreach my $bus (@netbus) {
        $bus                       = uc($bus);
        $bus_Mapping               = S_get_contents_of_hash ( [ 'Mapping_NET_Access_' . "$bus" ], $main::ProjectDefaults , {action_on_mismatch=>'w2log'} );
        $bus_Mapping->{'BUS_TYPE'} = undef;

        if ( $lookUp_MsgorSignal =~ /^MSG$/i ) {
            if ( defined $bus_Mapping->{'MSGS_OR_PDUS_OR_FRAMES'}{$msgOrSignalName} ) {
                $bus_Mapping->{'BUS_TYPE'} = $bus;
                S_w2log( 4, "WhichBusMapping_MsgOrSignal_BelongsTo : Info msg '$msgOrSignalName' found in Mapping_NET_Access_$bus.\n", 'grey' );
                last;
            }
        }
        elsif ( $lookUp_MsgorSignal =~ /^SIGNAL$/i ) {
            if ( defined $bus_Mapping->{$msgOrSignalName} ) {
                $bus_Mapping->{'BUS_TYPE'} = $bus;
                S_w2log( 4, "WhichBusMapping_MsgOrSignal_BelongsTo : Info signal '$msgOrSignalName' found in Mapping_NET_Access_$bus.\n", 'grey' );
                last;
            }
        }
    }

    # STEP return the $bus_Mapping contents.
    return $bus_Mapping;
}

=head2 Fetch_Msg_Or_Signal_Instances

    ($found_MsgOrSignal_aref) = Fetch_Msg_Or_Signal_Instances ($msgOrSignalName, $lookUp_MsgorSignal, $err_Option [,$busType]);
    
Searches the Message/Signal in mapping,Validates the Message/Signal for the ERROR or NO_ERROR conditions on multiple instances, and stores in an array

B<Arguments:>

=over

=item $msgOrSignalName

-Name of the Msg or Signal to be validated and searched in mapping

=item $lookUp_MsgorSignal

-Lookup (MSG|SIGNAL)

=item $err_Option

-Lookup (NO_ERR_MUL_INSTANCES|ERR_MUL_INSTANCES)

=item $busType

-Valid bus type (CAN|CANFD|LIN|FLEXRAY)

=back

B<Return Values:>

=over

=item $found_MsgOrSignal_aref

-Array reference of the validated Msg/Signals from mapping

=back


B<Examples:>

    ['MsgStimulus_1'] = Fetch_Msg_Or_Signal_Instances ('MsgStimulus_1', 'MSG', 'ERR_MUL_INSTANCES', 'CAN') #only one instance of MSG is present
    
    ['CAN1::MsgStimulus_2','LIN1::MsgStimulus_2','FR1::MsgStimulus_2'] = Fetch_Msg_Or_Signal_Instances ('MsgStimulus_2', 'MSG', 'NO_ERR_MUL_INSTANCES') #multiple instances of MSG is present
    
B<Note:>

B<Reading the Message/Signal:>

-   If the fully qualified name is provided, the data will be returned to the user

-   If there is NO ambiguity in the supplied name, matching data will be returned to the user.

-   If there there is an ambiguity in the supplied name, list of available names(fully qualified) will be displayed to the user in an error.

B<Writing the Message/Signal:>

-   If the fully qualified name is provided, the data will be written to the matching Message/Signal.

-   If there is an ambiguity in the supplied name, all the matching names will be written with the provided data.

-   If there is NO ambiguity in the supplied name, data will be written to the matching name.

=cut

sub Fetch_Msg_Or_Signal_Instances {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'Fetch_Msg_Or_Signal_Instances ($msgOrSignalName, $lookUp_MsgorSignal, $err_Option [,$busType])', @args );
    my $msgOrSignalName    = shift @args;
    my $lookUp_MsgorSignal = shift @args;
    my $err_Option         = shift @args;
    my $busType            = shift @args;

    # STEP Search is 'msg or signal' based in mapping ?
    my @searchOptions = qw(MSG SIGNAL);
    unless ( grep { /^$lookUp_MsgorSignal$/i } @searchOptions ) {
        Write_Error_Text( "ERROR : \$lookUp_MsgorSignal = '$lookUp_MsgorSignal' is not valid. It must be one of these : < @searchOptions > \n", 20 );
        return;
    }

    # STEP Validate READ/WRITE option
    my @validErrOptions = qw(NO_ERR_MUL_INSTANCES  ERR_MUL_INSTANCES );
    unless ( grep { /^$err_Option$/i } @validErrOptions ) {
        Write_Error_Text( "ERROR : \$err_Option = '$err_Option' is not valid. It must be one of these : < @validErrOptions > \n", 20 );
        return;
    }

    # STEP Fetch the avalable Msg/Signal instances from the maping
    my $found_MsgOrSignal_aref = GetMsg_or_Signal_Instances_fromMapping( $msgOrSignalName, $lookUp_MsgorSignal, $busType ) || return;

    # STEP Throw an error if msg/signal is not present in mapping
    if ( scalar(@$found_MsgOrSignal_aref) == 0 ) {
        Write_Error_Text( "ERROR - NO entries found for the given $lookUp_MsgorSignal = '$msgOrSignalName' in the Mapping!!\n", 20 );
        return;
    }

    #STEP If the opeartion is READ and if there is an ambiguity in the supplied name, display list of available names(fully qualified) in an error.
    #STEP If the opeartion is Write and if there is an ambiguity in the supplied name, Write the data to all the supplied names.

    if ( scalar(@$found_MsgOrSignal_aref) > 1 ) {
        if ( $err_Option =~ /^ERR_MUL_INSTANCES/i ) {
            Write_Error_Text( "ERROR : Multiple entries found for the given $lookUp_MsgorSignal = '$msgOrSignalName'!! \nPlease specify any one among :- \n => " . join( "\n =>", @$found_MsgOrSignal_aref ), 20 );
            return;
        }
        else {
            S_w2log( 4, " Fetch_Msg_Or_Signal_Instances : Found Message/Signals =\n =>" . join( "\n =>", @$found_MsgOrSignal_aref ) . " for search on  $lookUp_MsgorSignal = '$msgOrSignalName'\n" );
        }
    }

    # STEP Return the list of validated MSG/Signals from the mapping
    return $found_MsgOrSignal_aref;
}

=head2 GetMsgPDUInfo
    
    $msgInfo_href = GetMsgPDUInfo ($msgName, [$busType]);

It search the $msgName as in which mapping file (CAN, CANFD, LIN or FlexRay) it is present.

Once it is found from the mappings then the $msgInfo_href was returned.
This '$msgInfo_href' shall be used to perform the message operations like enable , disable msg etc.  

Its a internal function.

=cut

sub GetMsgPDUInfo {
    my @args = @_;

    # STEP validate args : -$msgName, -$busType(optional)
    return 0 unless S_checkFunctionArguments( 'GetMsgPDUInfo ($msgName, [$busType])', @args );
    my $msgName = shift @args;
    my $busType = shift @args;

    # STEP is $msgName found in any mappings : <CAN LIN or FlexRay>, if yes get $bus_Mapping content ?
    # CALL WhichBusMapping_MsgOrSignal_BelongsTo
    my $bus_Mapping = WhichBusMapping_MsgOrSignal_BelongsTo( $msgName, 'MSG', $busType ) || return;
    my $foundBus = $bus_Mapping->{'BUS_TYPE'};

    my ( $errMsg, $hintMsg );
    my $msgInfo_href;
    $msgInfo_href->{'BUS_TYPE'} = $foundBus;

    # STEP is $msgName found in $bus_Mapping , if yes fetch the $msgInfo_href ?
    unless ( $msgInfo_href->{$msgName} = $bus_Mapping->{'MSGS_OR_PDUS_OR_FRAMES'}{$msgName} ) {
        $busType = "CAN CANFD LIN FlexRay" if not defined $busType;
        $busType = uc($busType);
        $errMsg  = "ERROR : Message or PDU '$msgName' not found in 'Mapping_NET_Access_$busType'. \n";
        $hintMsg = "Hint : Please verify the corresponding mapping file. \n";
        S_set_error( "$errMsg $hintMsg ", 20 );
        return;
    }
    $msgInfo_href->{'PDU_MESSAGE'} = $msgName;
    $msgInfo_href->{$msgName}->{'BUS_NBR'} = $1 if ( $msgName =~ /^(?:CAN|CANFD|LIN|FLEXRAY)(\d+)/i );
    unless ( defined $msgInfo_href->{$msgName}->{'BUS_NBR'} ) {
        $msgInfo_href->{$msgName}->{'BUS_NBR'} = '1';
    }
    $msgInfo_href->{'AUTOSAR_SCHEMA_VERSION'} = $bus_Mapping->{'AUTOSAR_SCHEMA_VERSION'} if (uc $foundBus eq 'FLEXRAY' and exists ($bus_Mapping->{'AUTOSAR_SCHEMA_VERSION'}));

    # STEP return $msgInfo_href
    return $msgInfo_href;
}

=head2 GetSignalInfo

    $signalInfo_href = GetSignalInfo ($busSignalName, [$busType]);

It search the $msgName$busSignalName as in which mapping file (CAN, CANFD, LIN or FlexRay) it is present.

Once it is found from the mappings then the $signalInfo_href was returned.
This '$signalInfo_href' shall be used to perform the signal operations like read & write.  

Its a internal function.

=cut

sub GetSignalInfo {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'GetSignalInfo ($busSignalName, [$busType])', @args );
    my $busSignalName = shift @args;
    my $busType       = shift @args;

    my $signalInfo_href;
    my ( $bus_num, $msg_pdu, $signal, $fully_qualified_msg );
    if ( $busSignalName =~ /^((?:CAN|CANFD|LIN|FLEXRAY)(\d+)::(.*))::(.*)$/i ) {
        ( $fully_qualified_msg, $bus_num, $msg_pdu, $signal ) = ( $1, $2, $3, $4 );
    }
    else {
        S_set_error( "GetSignalInfo : \$busSignalName = '$busSignalName' is not fully qualified. Failed to fetch the signal details(Bus num,Message)!!", 20 );
        return;
    }

    my $bus_Mapping = WhichBusMapping_MsgOrSignal_BelongsTo( $busSignalName, 'SIGNAL', $busType ) || return;
    my $foundBus = $bus_Mapping->{'BUS_TYPE'};

    my ( $errMsg, $hintMsg );

    # STEP is $busSignalName found in any mappings : <CAN LIN or FlexRay> ?
    unless ( $signalInfo_href->{$busSignalName} = $bus_Mapping->{$busSignalName} ) {
        $errMsg  = "ERROR : Signal '$busSignalName' not found in any one of these Mapping(s) - 'Mapping_NET_Access_ CAN LIN FlexRay'. \n";
        $hintMsg = "Hint : Please verify the corresponding mapping file. \n";
        S_set_error( "$errMsg $hintMsg ", 20 );
        return;
    }
    $signalInfo_href->{$busSignalName}->{'SIGNAL_NAME'} = $signal;
    $signalInfo_href->{'PDU_MESSAGE'}                   = $fully_qualified_msg;
    $signalInfo_href->{'BUS_TYPE'}                      = $foundBus;

    # STEP is mapped (Message , PDU or Frame) found in mapping_$bus ?
    unless ( $signalInfo_href->{$fully_qualified_msg} = $bus_Mapping->{'MSGS_OR_PDUS_OR_FRAMES'}{$fully_qualified_msg} ) {
        $errMsg  = "ERROR : Message '$fully_qualified_msg' not found in 'LIFT Mapping_NET_Access_$foundBus. \n";
        $hintMsg = "Hint : Is your 'LIFT Mapping_NET_Access_$foundBus generated properly from dbc ? \n";
        S_set_error( "$errMsg $hintMsg ", 20 );
        return;
    }
    $signalInfo_href->{$fully_qualified_msg}->{'BUS_NBR'} = $bus_num;

    # STEP return $signalInfo_href
    return $signalInfo_href;
}

=head2 Validate_signal_from_mapping

    $validated_signal_href = Validate_signal_from_mapping ($signalInfo_href, $signal_name, $bus_type );

It validates the signal attributes from the mapping files (CAN, CANFD, LIN or FlexRay).

B<sets> :

- 'error if not present' : SIGNAL_NAME, FACTOR , OFFSET , CANOE_ENV_VAR , UNIT , CYCLE

- 'warning if not present': 'BUS_NBR' 

Called internally by  L</"NET_read_signal">  & L</"NET_write_signal">
 
B<Returns> = $validated_signal_href after validation.
 
=cut

sub Validate_signal_from_mapping {

    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_signal_from_mapping ($signalInfo_href, $signal_name, $bus_type )', @args );

    # STEP inputs : -$signalInfo_href , -$signal_name , -$bus_type
    my $signalInfo_href = shift @args;
    my $signal_name     = shift @args;
    my $bus_type        = shift @args;

    # STEP validate all attributes from 'mapping_$bus_type' for '$signal_name'
    # COMMENT-START
    # - Keys to be validated :
    #   - 'error if not present' : SIGNAL_NAME, FACTOR , OFFSET , CANOE_ENV_VAR , UNIT , CYCLE
    #   - 'warning if not present': CANOE_SYS_VAR, $bus_type.'_BUS_NBR'
    # COMMENT-END
    # CALL ValidateSignalAttribute

    my $validated_signal_href;
    my ( $bus_nbr, $msg_pdu, $signal, $fully_qualified_msg );
    if ( $signal_name =~ /^((?:CAN|CANFD|LIN|FLEXRAY)(\d+)::(.*))::(.*)$/i ) {
        ( $fully_qualified_msg, $bus_nbr, $msg_pdu, $signal ) = ( $1, $2, $3, $4 );
    }
    else {
        S_set_error( "Validate_signal_from_mapping : \$signal_name = '$signal_name' is not fully qualified. Failed to fetch the signal details!!", 20 );
        return;
    }
    $validated_signal_href->{'PDU_MESSAGE'} = $msg_pdu;                          # already validated
    $validated_signal_href->{'SIGNAL_NAME'} = $signal;                           # already validated
    $validated_signal_href->{'BUS_NBR'}     = $bus_nbr;
    $validated_signal_href->{'BUS_TYPE'}    = $signalInfo_href->{'BUS_TYPE'};    # already validated

    # from signal
    $validated_signal_href->{'FACTOR'}          = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'FACTOR',          $bus_type );
    $validated_signal_href->{'OFFSET'}          = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'OFFSET',          $bus_type );
    $validated_signal_href->{'UNIT'}            = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'UNIT',            $bus_type );
    $validated_signal_href->{'CANOE_WR_SIGNAL'} = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'CANOE_WR_SIGNAL', $bus_type );

    # no environment & system variables in case of IL, so skipping checking for this.
    # $validated_signal_href->{'CANOE_ENV_VAR'} = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'CANOE_ENV_VAR', $bus_type );
    # $validated_signal_href->{'CANOE_SYS_VAR'} = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'CANOE_SYS_VAR', $bus_type, 'noError' );

    # from message
    $validated_signal_href->{'CYCLE'} = Validate_MsgOrSignal_Attribute( $signalInfo_href, $fully_qualified_msg, 'CYCLE', $bus_type );
    unless ( defined $validated_signal_href->{'BUS_NBR'} ) {
        $validated_signal_href->{'BUS_NBR'} = '1';
    }

    # STEP return validated $validated_signal_href
    return $validated_signal_href;
}

=head2 Validate_dlc

    Validate_dlc ($msgInfo_href, $msgPduFrame);

Validates the dlc. 
Checks if the environment variable (key = 'CANOE_DLC') for writing the DLC is present in the mapping file or not.
and the DLC value (key = 'DLC')from Mapping is in valid range [1..8] or not.
      
=cut

sub Validate_dlc {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_dlc ($msgInfo_href, $msgPduFrame)', @args );
    my $msgInfo_href = shift @args;
    my $msgPduFrame  = shift @args;

    # STEP Fetch Environment variable to for updating the DLC in CANoe
    $msgInfo_href->{'CANOE_DLC'} = Validate_MsgOrSignal_Attribute( $msgInfo_href, $msgPduFrame, 'CANOE_DLC', $msgInfo_href->{'BUS_TYPE'} );
    return unless $msgInfo_href->{'CANOE_DLC'};

    # STEP Get the DLC value of message as defined in the Mapping file
    my $dlcMapping = Validate_MsgOrSignal_Attribute( $msgInfo_href, $msgPduFrame, 'DLC', $msgInfo_href->{'BUS_TYPE'} );
    if ( $dlcMapping < 1 or $dlcMapping > 8 ) {
        S_set_error( " error in fetching 'DLC' value = '$dlcMapping' (valid range 1..8) from Mapping_NET_Access_$msgInfo_href->{'BUS_TYPE'} for '$msgPduFrame'. \n", 20 );
        return;
    }
    $msgInfo_href->{'DLC_Mapping'} = $dlcMapping;
    return $msgInfo_href;
}

=head2 CallDeviceFunction

   $status = CallDeviceFunction('NET_access', $functionMapping_href, @args);
 
Calls the device mapped function under $functionMapping_href.  
    
=cut

sub CallDeviceFunction {
    my @args = @_;
    return FL_CallDeviceFunction( 'NET_access', $functionMapping_href, @args );
}

=head2 Validate_MsgOrSignal_Attribute

    Validate_MsgOrSignal_Attribute ($msgOrSignal_href, $msgOrSignal_name, $attribute , $bus , [, $noError ]);    

It validates or checks if the '$attribute' for '$msgOrSignal_name' exsits for hashref '$msgOrSignal_href'    
if $noError = 'noError' then only warning was given.

called internally by sevaral functions like :

    $msgInfo_href->{'CANOE_DLC'}  = Validate_MsgOrSignal_Attribute( $msgInfo_href, $msgPduFrame, 'CANOE_DLC', $msgInfo_href->{'BUS_TYPE'} );
    
    $signalInfo_href->{'SIGNAL_NAME'} = Validate_MsgOrSignal_Attribute( $signalInfo_href, $signal_name, 'SIGNAL_NAME', $bus_type ); 

Returns $attribute if successful else undef.

=cut

sub Validate_MsgOrSignal_Attribute {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_MsgOrSignal_Attribute ($msgOrSignal_href, $msgOrSignal_name, $attribute , $bus , [, $noError ])', @args );

    my $msgOrSignal_href = shift @args;
    my $msgOrSignal_name = shift @args;
    my $attribute        = shift @args;
    my $bus              = shift @args;
    my $noError          = shift @args;

    my $validated_attribute;

    # STEP check if passed '$attribute' in Mapping_NET_Access_$bus ?
    unless ( exists $msgOrSignal_href->{$msgOrSignal_name}{$attribute} ) {
        if ( defined $noError ) {
            S_set_warning( " no '$attribute' exists for '$msgOrSignal_name' in Mapping_NET_Access_$bus \n", 0 );
        }
        else {
            S_set_error( " no '$attribute' exists for '$msgOrSignal_name' in Mapping_NET_Access_$bus \n", 20 );
        }
    }

    # STEP return the $validated_attribute
    $validated_attribute = $msgOrSignal_href->{$msgOrSignal_name}{$attribute};
    return $validated_attribute;
}

=head2 GetMsg_or_Signal_Instances_fromMapping

    ($foundMsgOrSignal_aref) = GetMsg_or_Signal_Instances_fromMapping($msgOrSignalName, $lookUp_MsgorSignal [,$bus_type]);

Fetches the matching Msg/Signal from the mapping and stores all the matched names in an array

B<Arguments:>

=over

=item $msgOrSignalName

-Full or part of the Message/Signal name to be searched in mapping

=item $lookUp_MsgorSignal ('MSG' | 'SIGNAL')

-Looks for the Message or Signal

=item $bus_type

-Type of the bus ('CAN' | 'CANFD' | 'LIN' | 'FlexRay')

=back


B<Return Values:>

=over

=item $foundMsgOrSignal_aref

- Array of the matched Message or Signal

=back


B<Examples:>

    ['CAN1::MsgStimulus_2','LIN1::MsgStimulus_2','FR1::MsgStimulus_2'] = GetMsg_or_Signal_Instances_fromMapping ('MsgStimulus_2', 'MSG') #multiple instances of MSG is present
    
    ['CAN1::MsgStimulus_2::Sig_Stimulus_1','LIN1::MsgStimulus_2::Sig_Stimulus_1','FR1::MsgStimulus_2::Sig_Stimulus_1'] = GetMsg_or_Signal_Instances_fromMapping ('Sig_Stimulus_1', 'SIGNAL') #multiple instances of SIGNAL is present

=cut

sub GetMsg_or_Signal_Instances_fromMapping {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetMsg_or_Signal_Instances_fromMapping ($msgOrSignalName, $lookUp_MsgorSignal [,$bus_type])', @args );
    my $msgOrSignalName    = shift @args;
    my $lookUp_MsgorSignal = shift @args;
    my $bus_type           = shift @args;
    my @searchOptions      = qw(MSG SIGNAL);
    my @netbus             = qw (CAN CANFD LIN FlexRay);

    # STEP Search is 'msg or signal' based in mapping ?
    unless ( grep { /^$lookUp_MsgorSignal$/i } @searchOptions ) {
        Write_Error_Text( "ERROR : \$lookUp_MsgorSignal = '$lookUp_MsgorSignal' is not valid. It must be one of these : < @searchOptions > \n", 20 );
        return;
    }

    #STEP Validate Bus_type vs (CAN|CANFD|LIN|FLEXRAY)
    if ( defined $bus_type && !grep { /^$bus_type$/i } @netbus ) {
        Write_Error_Text( "ERROR : \$bus_type = '$bus_type' is not valid. It must be one of these : < @netbus > \n", 20 );
        return;
    }

    @netbus = ($bus_type) if ($bus_type);
    my ( $bus_Mapping, $busMsg_grp_name );
    my $foundMsgOrSignal_aref = [];

    #STEP Search for the matching msg/signal from mapping and store them in an array
    foreach my $bus (@netbus) {
        $bus = uc($bus);
        $bus_Mapping = S_get_contents_of_hash( [ 'Mapping_NET_Access_' . "$bus" ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
        my @msg_or_signal;
        if ( $lookUp_MsgorSignal =~ /^MSG$/i ) {
            @msg_or_signal = grep { /$msgOrSignalName$/ } keys %{ $bus_Mapping->{'MSGS_OR_PDUS_OR_FRAMES'} };
        }
        elsif ( $lookUp_MsgorSignal =~ /^SIGNAL$/i ) {
            @msg_or_signal = grep { /$msgOrSignalName$/ } keys %$bus_Mapping;
        }

        push @$foundMsgOrSignal_aref, @msg_or_signal;
    }

    S_w2log( 4, "GetMsg_or_Signal_Instances_fromMapping - Nbr of intances matched for $lookUp_MsgorSignal '$msgOrSignalName' from mappings < @netbus >  = " . scalar(@$foundMsgOrSignal_aref) . " and matched values -> '@$foundMsgOrSignal_aref'.\n", 'grey' );

    #STEP Return the array
    return $foundMsgOrSignal_aref;
}

=head2 Check_if_NET_Access_Mapping_is_present

    Check_if_NET_Access_Mapping_is_present();

Checks if NET Access Mapping is present.

-   If it is present, then a flag '$is_net_access_mapping_present' is set to 1 and it continues with the program execution.

-   If it is not present then it calls the mapping conversion function that converts available CAN/LIN/FlexRay_Access_Mapping into NET_Access_(CAN/LIN/FlexRay)_Mapping respectively. 

B<Return Values:>

=over

=item return 1

- Returns 1 when the function Check_if_NET_Access_Mapping_is_present is called

=back


B<Example:>

    Check_if_NET_Access_Mapping_is_present();
    
=cut

sub Check_if_NET_Access_Mapping_is_present {
    
    my @netbus = qw ( CAN CANFD LIN FlexRay );
    my $bus_Mapping;
    foreach my $bus (@netbus) {
        $bus = uc($bus);
        $bus_Mapping = S_get_contents_of_hash( [ 'Mapping_NET_Access_' . "$bus" ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
        if ( defined $bus_Mapping and $mapping_converion_done == 0 ) {
            $is_net_access_mapping_present = 1;
            S_w2log( 5, "NET Access Mapping File is present  \n" );
            return 0;
            last;
        }

        if ( $is_net_access_mapping_present == 0 ) {

            #convert CAN Access Mapping to NET Access Mapping
            if ( $bus eq 'CAN' ) {
                Convert_CAN_Mapping_to_NET_Access_Mapping();
                $mapping_converion_done = 1;
            }
            if ( $bus eq 'LIN' ) {
                Convert_LIN_Mapping_to_NET_Access_Mapping();
                $mapping_converion_done = 1;
            }
            if ( $bus eq 'FLEXRAY' ) {
                Convert_FLEXRAY_Mapping_to_NET_Access_Mapping();
                $mapping_converion_done = 1;
            }                   
        }
    }
    return 1;
}

=head2 Convert_CAN_Mapping_to_NET_Access_Mapping

    Convert_CAN_Mapping_to_NET_Access_Mapping();

Converts CAN Mapping hash to NET Access CAN Mapping hash.

=cut

sub Convert_CAN_Mapping_to_NET_Access_Mapping {

    my $can_access_mapping = S_get_contents_of_hash( [ 'Mapping_' . "CAN" ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    my $can_messages = S_get_contents_of_hash( [ 'Mapping_' . "CAN", 'CAN_MESSAGES' ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    S_w2log( 3, "NET Access CAN Mapping File is not present - using CAN Mapping file\n", 'Magenta' );
    my $can_to_net_access_sig_href         = {};
    my $can_to_net_access_msg_href         = {};
    my $net_access_CAN_mapping_frames_href = {};
    my $bus_nbr                            = 1;    # default bus number is set to 1
    S_w2log( 4, "\n==============================\n", 'Indigo' );
    S_w2log( 4, "====CAN SIGNAL CONVERSION===", 'Indigo' );
    S_w2log( 4, "\n==============================\n", 'Indigo' );
    foreach my $signal ( keys %$can_access_mapping ) {
        if ( ( $signal ne 'CAN_MESSAGES' ) && ( $signal ne 'NODE_UNDER_TEST' ) ) {           
            my $msg_name = $can_access_mapping->{$signal}{'MESSAGE'};
            my @split_msg = split( /::/, $msg_name, 2 );
            $msg_name    = $split_msg[-1]; 
            $bus_nbr = $can_access_mapping->{CAN_MESSAGES}{$msg_name}{CAN_BUS_NBR} // 1;
            my $signal_name      = $can_access_mapping->{$signal}{SIGNAL_NAME};    
            my @split_msg = split( /::/, $signal_name, 2 );
            $signal_name    = $split_msg[-1];         
            my $full_signal_name = "CAN" . $bus_nbr . "::" . $msg_name . "::" . $signal_name;         
            S_w2log( 4, "Sig_Conv: CAN_access to NET_access - [ '$signal' ]  to  [ '$full_signal_name' ]" . "\n", 'Indigo' );
            
            # MULTIPLEX 
            my $master     = $can_access_mapping->{$signal}{MULTIPLEX}{MASTER};
            my $code       = $can_access_mapping->{$signal}{MULTIPLEX}{CODE};
            my $net_master = "CAN" . $bus_nbr . "::" . $msg_name . "::" . $master;
            if ( defined $master ) {
                $can_to_net_access_sig_href->{$full_signal_name}{MULTIPLEX}{MASTER} = $net_master;
                $can_to_net_access_sig_href->{$full_signal_name}{MULTIPLEX}{CODE} = $code if defined $code // undef;
            }
            else {
                $can_to_net_access_sig_href->{$full_signal_name}{MULTIPLEX} = undef;
            }
            $can_to_net_access_sig_href->{$full_signal_name}{CANOE_WR_SIGNAL} = $can_access_mapping->{$signal}{CANOE_ENV_VAR};            
            $can_to_net_access_sig_href->{$full_signal_name}{STARTBIT} = $can_access_mapping->{$signal}{STARTBIT};
            $can_to_net_access_sig_href->{$full_signal_name}{LENGTH}   = $can_access_mapping->{$signal}{LENGTH};
            $can_to_net_access_sig_href->{$full_signal_name}{OFFSET}   = $can_access_mapping->{$signal}{OFFSET};
            $can_to_net_access_sig_href->{$full_signal_name}{FACTOR}   = $can_access_mapping->{$signal}{FACTOR};
            $can_to_net_access_sig_href->{$full_signal_name}{FORMAT}   = $can_access_mapping->{$signal}{FORMAT};
            $can_to_net_access_sig_href->{$full_signal_name}{TYPE}     = $can_access_mapping->{$signal}{TYPE};
            $can_to_net_access_sig_href->{$full_signal_name}{UNIT}     = $can_access_mapping->{$signal}{UNIT};
        }
    }
    S_w2log( 4, "\n\n");
    $net_access_CAN_mapping_frames_href = $can_to_net_access_sig_href;
    S_w2log( 4, "\n===============================\n", 'Green' );
    S_w2log( 4, "===CAN MESSAGE CONVERSION===", 'Green' );
    S_w2log( 4, "\n===============================\n", 'Green' );
    foreach my $can_msg_key ( keys %$can_messages ) {
        unless ( ( $can_msg_key =~ /\bMLC_\w*\b/g ) or ( $can_msg_key =~ /\bIDX_\w*\b/g ) ) {
            $bus_nbr = $can_messages->{$can_msg_key}{CAN_BUS_NBR} // 1;
            my $can_msg_to_net;
            my @split_msg = split( /::/, $can_msg_key, 2 );
            my $new_can_msg_key    = $split_msg[-1];
            $can_msg_to_net = "CAN" . $bus_nbr . "::" . $new_can_msg_key;                     
            S_w2log( 4, "Msg_Conv: CAN_access to NET_access - [ '$can_msg_key' ]  to  [ '$can_msg_to_net' ]" . "\n", 'Green' );           
            
            $can_to_net_access_msg_href->{$can_msg_to_net}{ID}              = $can_messages->{$can_msg_key}{ID};
            $can_to_net_access_msg_href->{$can_msg_to_net}{DLC}             = $can_messages->{$can_msg_key}{DLC};
            $can_to_net_access_msg_href->{$can_msg_to_net}{SENDER}          = $can_messages->{$can_msg_key}{SENDER};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CYCLE}           = $can_messages->{$can_msg_key}{CYCLE};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CANOE_ENABLE}    = $can_messages->{$can_msg_key}{CANOE_DISABLE};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CANOE_DLC}       = $can_messages->{$can_msg_key}{CANOE_DLC};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CANOE_CYCLETIME} = $can_messages->{$can_msg_key}{CANOE_TIMING};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CANOE_VALIDCRC}  = $can_messages->{$can_msg_key}{CANOE_VALIDCRC};
            $can_to_net_access_msg_href->{$can_msg_to_net}{CANOE_VALIDCNT}  = $can_messages->{$can_msg_key}{CANOE_VALIDBZ};
        }
    }
    $net_access_CAN_mapping_frames_href->{MSGS_OR_PDUS_OR_FRAMES} = $can_to_net_access_msg_href;
    $main::ProjectDefaults->{Mapping_NET_Access_CAN}              = $net_access_CAN_mapping_frames_href;
    return 1;
}

=head2 Convert_LIN_Mapping_to_NET_Access_Mapping

    Convert_LIN_Mapping_to_NET_Access_Mapping();

Converts LIN Mapping hash to NET Access LIN Mapping hash.

=cut

sub Convert_LIN_Mapping_to_NET_Access_Mapping {

    my $lin_mapping = S_get_contents_of_hash( [ 'Mapping_' . "LIN" ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    my $lin_messages = S_get_contents_of_hash( [ 'Mapping_' . "LIN", 'LIN_MESSAGES' ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    S_w2log( 3, "NET Access LIN Mapping File is not present - using LIN Mapping file\n" , 'Magenta');
    my $lin_to_net_access_sig_href         = {};
    my $lin_to_net_access_msg_href         = {};
    my $net_access_lin_mapping_frames_href = {};
    
    S_w2log( 4, "\n==============================\n", 'Indigo' );
    S_w2log( 4, "====LIN SIGNAL CONVERSION====", 'Indigo' );
    S_w2log( 4, "\n==============================\n", 'Indigo' );
    foreach my $signal ( keys %$lin_mapping ) {

        if ( ( $signal ne 'LIN_MESSAGES' ) && ( $signal ne 'NODE_UNDER_TEST' ) ) {
            my $msg_name         = $lin_mapping->{$signal}{'MESSAGE'};
            my $full_signal_name = "LIN1" . "::" . $msg_name . "::" . $signal;            
            S_w2log( 4, "Sig_Conv: LIN_access to NET_access - [ '$signal' ]  to  [ '$full_signal_name' ]" . "\n", 'Indigo' );

            $lin_to_net_access_sig_href->{$full_signal_name}{CANOE_WR_SIGNAL} = $lin_mapping->{$signal}{CANOE_ENV_VAR};
            $lin_to_net_access_sig_href->{$full_signal_name}{MULTIPLEX}       = $lin_mapping->{$signal}{MULTIPLEX};
            $lin_to_net_access_sig_href->{$full_signal_name}{STARTBIT}        = $lin_mapping->{$signal}{STARTBIT};
            $lin_to_net_access_sig_href->{$full_signal_name}{LENGTH}          = $lin_mapping->{$signal}{LENGTH};
            $lin_to_net_access_sig_href->{$full_signal_name}{OFFSET}          = $lin_mapping->{$signal}{OFFSET};
            $lin_to_net_access_sig_href->{$full_signal_name}{FACTOR}          = $lin_mapping->{$signal}{FACTOR};
            $lin_to_net_access_sig_href->{$full_signal_name}{FORMAT}          = $lin_mapping->{$signal}{FORMAT};
            $lin_to_net_access_sig_href->{$full_signal_name}{TYPE}            = $lin_mapping->{$signal}{TYPE};
            $lin_to_net_access_sig_href->{$full_signal_name}{UNIT}            = $lin_mapping->{$signal}{UNIT};
        }
    }
    S_w2log( 4, "\n\n");
    my $net_access_lin_mapping_frames_href = $lin_to_net_access_sig_href;

    S_w2log( 4, "\n===============================\n", 'Green' );
    S_w2log( 4, "====LIN MESSAGE CONVERSION===", 'Green' );
    S_w2log( 4, "\n===============================\n", 'Green' );
    foreach my $lin_msg_key ( keys %$lin_messages ) {
        my $bus_nbr = $lin_messages->{$lin_msg_key}{LIN_BUS_NBR} // 1;
        my $lin_msg_to_net = "LIN" . $bus_nbr . "::" . $lin_msg_key;       
        S_w2log( 4, "Msg_Conv: LIN_access to NET_access - [ '$lin_msg_key' ]  to  [ '$lin_msg_to_net' ]" . "\n", 'Green' ); 
        
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{ID}              = $lin_messages->{$lin_msg_key}{ID};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{DLC}             = $lin_messages->{$lin_msg_key}{DLC};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{SENDER}          = $lin_messages->{$lin_msg_key}{SENDER};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CYCLE}           = $lin_messages->{$lin_msg_key}{CYCLE};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CANOE_ENABLE}    = $lin_messages->{$lin_msg_key}{CANOE_DISABLE};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CANOE_DLC}       = $lin_messages->{$lin_msg_key}{CANOE_DLC};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CANOE_CYCLETIME} = $lin_messages->{$lin_msg_key}{CANOE_TIMING};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CANOE_VALIDCRC}  = $lin_messages->{$lin_msg_key}{CANOE_VALIDCRC};
        $lin_to_net_access_msg_href->{$lin_msg_to_net}{CANOE_VALIDCNT}  = $lin_messages->{$lin_msg_key}{CANOE_VALIDBZ};
    }
    $net_access_lin_mapping_frames_href->{MSGS_OR_PDUS_OR_FRAMES} = $lin_to_net_access_msg_href;
    $main::ProjectDefaults->{Mapping_NET_Access_LIN}              = $net_access_lin_mapping_frames_href;
    return 1;
}

=head2 Convert_FLEXRAY_Mapping_to_NET_Access_Mapping

    Convert_FLEXRAY_Mapping_to_NET_Access_Mapping();

Converts Flexray Mapping hash to NET Access FlexRay Mapping hash.

=cut

sub Convert_FLEXRAY_Mapping_to_NET_Access_Mapping {

    my $fr_mapping = S_get_contents_of_hash( [ 'Mapping_' . "FLEXRAY" ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    my $fr_messages = S_get_contents_of_hash( [ 'Mapping_' . "FLEXRAY", 'FR_PDU' ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );
    S_w2log( 3, "NET Access FlexRay Mapping File is not present - using FlexRay Mapping file\n", 'Magenta' );
    my $fr_to_net_access_sig_href         = {};
    my $fr_to_net_access_msg_href         = {};
    my $net_access_fr_mapping_frames_href = {};

    S_w2log( 4, "\n==================================\n", 'Indigo' );
    S_w2log( 4, "====FLEXRAY SIGNAL CONVERSION===", 'Indigo' );
    S_w2log( 4, "\n==================================\n", 'Indigo' );
    foreach my $signal ( keys %$fr_mapping ) {

        if ( ( $signal ne 'FR_PDU' ) && ( $signal ne 'NODE_UNDER_TEST' ) ) {
            my $msg_name         = $fr_mapping->{$signal}{'FR_PDU_NAME'};
            my $full_signal_name = "FLEXRAY1" . "::" . $msg_name . "::" . $signal;           
            S_w2log( 4, "Sig_Conv: FR_access to NET_access - [ '$signal' ]  to  [ '$full_signal_name' ]" . "\n", 'Indigo' );

            $fr_to_net_access_sig_href->{$full_signal_name}{CANOE_WR_SIGNAL} = $fr_mapping->{$signal}{CANOE_ENV_VAR};
            $fr_to_net_access_sig_href->{$full_signal_name}{MULTIPLEX}       = $fr_mapping->{$signal}{MULTIPLEX};
            $fr_to_net_access_sig_href->{$full_signal_name}{STARTBIT}        = $fr_mapping->{$signal}{STARTBIT};
            $fr_to_net_access_sig_href->{$full_signal_name}{LENGTH}          = $fr_mapping->{$signal}{LENGTH};
            $fr_to_net_access_sig_href->{$full_signal_name}{OFFSET}          = $fr_mapping->{$signal}{OFFSET};
            $fr_to_net_access_sig_href->{$full_signal_name}{FACTOR}          = $fr_mapping->{$signal}{FACTOR};
            $fr_to_net_access_sig_href->{$full_signal_name}{FORMAT}          = $fr_mapping->{$signal}{FORMAT};
            $fr_to_net_access_sig_href->{$full_signal_name}{TYPE}            = $fr_mapping->{$signal}{TYPE};
            $fr_to_net_access_sig_href->{$full_signal_name}{UNIT}            = $fr_mapping->{$signal}{UNIT};
        }
    }
    S_w2log( 4, "\n\n");
    my $net_access_fr_mapping_frames_href = $fr_to_net_access_sig_href;
    S_w2log( 4, "\n===================================\n", 'Green' );
    S_w2log( 4, "====FLEXRAY MESSAGE CONVERSION==", 'Green' );
    S_w2log( 4, "\n===================================\n", 'Green' );
    foreach my $fr_msg_key ( keys %$fr_messages ) {

        my $fr_msg_to_net = "FLEXRAY1" . "::" . $fr_msg_key;       
        S_w2log( 4, "Msg_Conv: FR_access to NET_access - [ '$fr_msg_key' ]  to  [ '$fr_msg_to_net' ]" . "\n", 'Green' ); 

        $fr_to_net_access_msg_href->{$fr_msg_to_net}{ID}              = $fr_messages->{$fr_msg_key}{ID};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{DLC}             = $fr_messages->{$fr_msg_key}{DLC};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{SENDER}          = $fr_messages->{$fr_msg_key}{SENDER};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CYCLE}           = $fr_messages->{$fr_msg_key}{CYCLE};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CANOE_ENABLE}    = $fr_messages->{$fr_msg_key}{CANOE_DISABLE};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CANOE_DLC}       = $fr_messages->{$fr_msg_key}{CANOE_DLC};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CANOE_CYCLETIME} = $fr_messages->{$fr_msg_key}{CANOE_TIMING};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CANOE_VALIDCRC}  = $fr_messages->{$fr_msg_key}{CANOE_VALIDCRC};
        $fr_to_net_access_msg_href->{$fr_msg_to_net}{CANOE_VALIDCNT}  = $fr_messages->{$fr_msg_key}{CANOE_VALIDBZ};

    }
    $net_access_fr_mapping_frames_href->{MSGS_OR_PDUS_OR_FRAMES} = $fr_to_net_access_msg_href;
    $net_access_fr_mapping_frames_href->{'AUTOSAR_SCHEMA_VERSION'} = $fr_mapping->{'AUTOSAR_SCHEMA_VERSION'} if exists ($fr_mapping->{'AUTOSAR_SCHEMA_VERSION'});
    $main::ProjectDefaults->{Mapping_NET_Access_FLEXRAY}         = $net_access_fr_mapping_frames_href;
    return 1;
}

=head2 Write_Log_Text

    Write_Log_Text($errorText, $errorCodeNbr);

It write the log text to the log file and it appends the B<calling function name> before the text message.    

=cut

sub Write_Log_Text {
    my $text     = shift;
    my $logLevel = shift;

    $logLevel = WRLOG_LEVEL_4 if not defined $logLevel;

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }
    S_w2log( $logLevel, "$callingFunction : $text \n", 'purple' );
    return 1;
}

=head2 Write_Error_Text

    Write_Error_Text($errorText, $errorCodeNbr);

It write the error message to the log file. and it appends the B<calling function name> before the error message.    

=cut

sub Write_Error_Text {
    my $errorText    = shift;
    my $errorCodeNbr = shift;

    my $callingFunction = ( caller(1) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }
    S_set_error( " $callingFunction :  $errorText \n", $errorCodeNbr );
    return 1;
}

############################################################################################################
#
#
# package LIFT_NETaccess_CANoe
#
#
############################################################################################################

package LIFT_NETaccess_CANoe;

use strict;
use warnings;
use LIFT_general;
use LIFT_CANoe_device;

my $simulation_mode;

sub NET_trace_start {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_start()', @args );

    if ( not $simulation_mode ) {
        CANoe_start_measurement();
        CANoe_trace_logging_start();
    }
    else {
        CANoe_trace_logging_start();
    }

    return 1;
}

sub NET_trace_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_stop()', @args );

    if ($simulation_mode) {
        CANoe_trace_logging_stop();
    }
    else {
        CANoe_stop_measurement();
    }
    return 1;
}

sub NET_simulation_start {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_simulation_start()', @args );
    CANoe_trace_delete();
    CANoe_start_measurement();
    CANoe_trace_logging_stop();
    $simulation_mode = 1;
    return 1;
}

sub NET_simulation_stop {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_simulation_stop()', @args );
    CANoe_stop_measurement();
    $simulation_mode = 0;
    return 1;
}

sub NET_trace_get_dataref {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_trace_get_dataref( $trace_file_path, $options_search_href  )', @args );

    #STEP Read Tracefile and MESSAGE|SIGNAL|SYSVAR to be searched
    my $trace_file_path     = shift @args;
    my $options_search_href = shift @args;

    LIFT_NET_access::Write_Log_Text("Start..");
    LIFT_NET_access::Write_Log_Text("input trace file to get dataref is '$trace_file_path'");

    #STEP Check for the Mandatory arguments
    unless ( $options_search_href->{'MESSAGES'} || $options_search_href->{'SIGNALS'} || $options_search_href->{'SYSVARS'} ) {
        LIFT_NET_access::Write_Error_Text( "Please provide MESSAGES|SIGNALS|SYSVARS to get the dataref from trace\n", 20 );
        return;
    }

    #STEP Check if the trace file exists
    unless ( -f $trace_file_path ) {
        LIFT_NET_access::Write_Error_Text( "$trace_file_path File not found.", 109 );
        return;
    }

    #STEP Read the timestamp and data format of CANoe trace file
    my ( $data_format, $timestamps ) = CANoe_trace_analyze_format($trace_file_path);

    #STEP Validate format and timestamp of CANoe trace file
    unless ($data_format) {
        LIFT_NET_access::Write_Error_Text( "Couldn't determine format of trace '$trace_file_path'", 131 );
        return;
    }
    unless ( $timestamps =~ /absolute/i ) {
        LIFT_NET_access::Write_Error_Text( "Timestamps in trace:$trace_file_path must be configured as 'absolute'", 131 );
        return;
    }
    my $final_trace_dataref = {};

    #STEP Get the trace dataref for the Messages supplied by the user
    if ( exists $options_search_href->{'MESSAGES'} ) {
        LIFT_NET_access::Write_Log_Text("get dataref for the messages = '@{$options_search_href->{'MESSAGES'}}'  :- ");
        foreach my $message ( @{ $options_search_href->{'MESSAGES'} } ) {
            LIFT_NET_access::Write_Log_Text("get dataref for message -> '$message' .. ");
            my $matched_msg_arr = LIFT_NET_access::Fetch_Msg_Or_Signal_Instances( $message, 'MSG', 'NO_ERR_MUL_INSTANCES' ) || next;
            foreach my $matched_msgOrPDU (@$matched_msg_arr) {
                my $msg_PDU_info = LIFT_NET_access::GetMsgPDUInfo($matched_msgOrPDU) || next;
                $final_trace_dataref = CANoe_trace_get_message_dataref( $trace_file_path, $msg_PDU_info, $data_format, $final_trace_dataref );
            }
        }
    }

    #STEP Get the trace dataref for the Signals supplied by the user
    if ( exists $options_search_href->{'SIGNALS'} ) {
        LIFT_NET_access::Write_Log_Text("get dataref for the SIGNALS = '@{$options_search_href->{'SIGNALS'}}'  :- ");
        foreach my $signal ( @{ $options_search_href->{'SIGNALS'} } ) {
            LIFT_NET_access::Write_Log_Text("get dataref for signal -> '$signal' .. ");
            my $matched_signal_arr = LIFT_NET_access::Fetch_Msg_Or_Signal_Instances( $signal, 'SIGNAL', 'NO_ERR_MUL_INSTANCES' ) || next;
            foreach my $matched_signal (@$matched_signal_arr) {
                my $signal_info = LIFT_NET_access::GetSignalInfo($matched_signal) || next;
                $final_trace_dataref = CANoe_trace_get_signal_dataref( $trace_file_path, $signal_info, $matched_signal, $data_format, $final_trace_dataref );
            }
        }
    }

    #STEP Get the trace dataref for the System variables supplied by the user
    if ( exists $options_search_href->{'SYSVARS'} ) {
        LIFT_NET_access::Write_Log_Text("get dataref for the SYSVARS = '@{$options_search_href->{'SYSVARS'}}'  :- ");
        foreach my $sysVar ( @{ $options_search_href->{'SYSVARS'} } ) {
            LIFT_NET_access::Write_Log_Text("get dataref for sysvar -> '$sysVar' .. ");
            $final_trace_dataref = CANoe_trace_get_sysvar_dataref( $trace_file_path, $sysVar, $final_trace_dataref );
        }
    }

    LIFT_NET_access::Write_Log_Text("end..");

    #STEP Return the trace dataref
    return $final_trace_dataref;

}


############################################################################################################
#
#
# package LIFT_NETaccess_CANoeCtrl
#
#
############################################################################################################

package LIFT_NETaccess_CANoeCtrl;

use strict;
use warnings;
use LIFT_general;
use LIFT_CANoe_device;
use LIFT_CANoeCtrl;

sub NET_stimulate_start_now {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NET_stimulate_start_now ()', @args );

    S_w2log( 4, "NET_stimulate_start_now \n" );
    unless ( CANoeCtrl_EnableOutputTriggers() ) {
        S_set_error( " NET_stimulate_start_now : failed to enable trigger.\n", 131 );
        return;
    }

    unless ( CANoeCtrl_SetSoftwareTrigger() ) {
        S_set_error( " NET_stimulate_start_now : failed to set software trigger.\n", 131 );
        return;
    }
    return 1;
}

sub NET_stimulate_load_signal_curves {
    my @args = @_;
    return unless S_checkFunctionArguments( 'NET_stimulate_load_signal_curves($busSignal_curves_href, $triggertype)', @args );
    my $busSignal_curves_href = shift @args;
    my $triggertype           = shift @args;

    CANoe_stop_measurement();
    CANoeCtrl_load_signal_curves( $busSignal_curves_href, $triggertype );

    return 1;
}

sub NET_stimulate_load_timed_signals {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'NET_stimulate_load_timed_signals ($signal_name, $value1, $triggertype , [$timeshift_ms, $value2])', @args );

    my $signal_name  = shift @args;
    my $value1       = shift @args;
    my $triggertype  = shift @args;
    my $timeshift_ms = shift @args;
    my $value2       = shift @args;

    CANoe_stop_measurement();

    unless ( CANoeCtrl_SetTimedSignal( $signal_name, $value1, $triggertype, $timeshift_ms, $value2 ) ) {
        S_set_error( " NET_stimulate_load_timed_signals : failed to configure timed signals for the signal '$signal_name'. \n", 131 );
        return;
    }

    unless ( CANoeCtrl_SetSystemVariablesValues() ) {
        S_set_error( " NET_stimulate_load_timed_signals : failed to set System variables.\n", 131 );
        return;
    }

    return 1;
}

1;

__END__

=head1 AUTHORS

Upendra Singh Rathore, E<lt>Upendra.Rathore@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut
