# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_flexray_access;

use strict;
use LIFT_general;
use LIFT_equipment;
use LIFT_vector_cantool;    # check if FlexRay tool must be derived!
use Readonly;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(
  FR_init
  FR_read_configure
  FR_read_flxr_signal
  FR_write_configure
  FR_write_flxr_signal
  FR_write_flxr_signal_mask
  FR_disable_PDU_update
  FR_enable_PDU_update
  FR_trace_configure
  FR_trace_start
  FR_trace_stop
  FR_trace_check_running
  FR_trace_store
  FR_trace_store_both
  FR_get_flxr_signal_info
  FR_get_flxr_message_info
  FR_calc_hex_to_phys
  FR_trace_get_PDU_data
  FR_evaluate_PDU_CRC
  FR_trace_get_dataref
  FR_trace_get_PD_responses
  FR_set_invalidCRC
  FR_set_validCRC
  FR_set_invalidBZ
  FR_set_validBZ

  );    # export subs

my $FR_control;

#####################################################################

=head1 NAME

LIFT_flexray_access 

=head1 SYNOPSIS

   use LIFT_flexray_access;

   FR_read_configure
   FR_read_flxr_signal
   FR_write_configure
   FR_write_flxr_signal
   FR_write_flxr_signal_mask
   FR_disable_PDU_update
   FR_enable_PDU_update
   FR_trace_configure
   FR_trace_start
   FR_trace_stop
   FR_trace_check_running
   FR_trace_store
   FR_trace_store_both
   FR_get_flxr_signal_info
   FR_get_flxr_message_info
   FR_calc_hex_to_phys
   FR_trace_get_PDU_data
   FR_evaluate_PDU_CRC
   FR_trace_get_dataref
   FR_set_invalidCRC
   FR_set_validCRC
   FR_set_invalidBZ
   FR_set_validBZ

=cut

=head1 DESCRIPTION

This module controls the CANoe application and provides below functionalities  :
 
=over 3

=item * start & stop RBS with trace logging

=item * read FlexRay signals

=item * write FlexRay signals

=item * FlexRay PDU manipulation

=back

=head2 Prerequisites

You need to have basic knowledge of CANoe. For example compiling of .cfg file, editing some CAPL program etc.

=cut

=head2 Testbench configuration

=head3 Devices section:

=for html
<a href='LIFT_can_access.html#Testbench-configuration'>See LIFT_can_access -> Testbench configuration</a>

=head3 Functions section:

    'Functions' => {
        ...
        'FlexRay_Access' => {
           'basic'     =>  'CANoe',     # function groups: read, write, trace
        },
        ...  
    },

For backwards compatibility the old way of function configuration is also supported:

    'FlexRay_Access' => {
       'read' =>  [ 'CANoe' ],
       'write' => [ 'CANoe' ],
       'trace' => [ 'CANoe' ],
    },

=head2 FlexRay mapping

Many functions of this module need a FlexRay mapping file that provides information about IDs of PDUs/frames and bit and byte positions of signals.
The FlexRay mapping file can be generated from an export of the fibex file that defines the rest bus simulation. 
To do this there is a FlexRay mapping file generator tool (with GUI) available: 

    <path to your TurboLIFT sandboxes>\Tools\Mappingfile_Generators\FlexrayMapping\FlexrayMappingFileCreator.exe

The generated FlexRay mapping file should be copied to the "config" folder of your TurboLIFT project and 
in the main config file (..._CFG.pm) the FlexRay mapping file must be loaded, e.g. like this:

    require "$LIFT_PRJCFG_path/Mapping_FLEXRAY.pm" if ( -f "$LIFT_PRJCFG_path/Mapping_FLEXRAY.pm" );

=cut

=head1 FUNCTIONS

######################################################################

=head2 FR_read_configure

    Function Name    :: FR_read_configure
    Description      :: prepare FlexRay tool so that signals from FlexRay Bus can immediately be read ( start measurement )
                        (stop measurement if option 'deactivate')
    Syntax           :: FR_read_configure ( [$action] );
    Input Arguments  :: $action - action to be performed. its optional parameter. can take only 'deactivate' as the value.
    Return Value(s)  :: None
    Example          :: FR_read_configure ( ['deactivate'] );

=cut

######################################################################
sub FR_read_configure {
    S_w2log( 4, " FR_read_configure: Prepares Flexray to read the signals \n" );
    my $action = shift;

    my ( @devices, $devices_text, $OLE_handle );

    @devices = EQUIP_get_devices( 'FlexRay_Access', 'read' );

    $FR_control->{'read'}{'Devices'} = [];
    unless ( scalar @devices ) {
        S_set_error( " FR_read_configure : LIFT_Testbenches doesnt contain Devices for reading FlexRay signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " FR_read_configure : LIFT_Testbenches doesnt contain valid devices for reading FlexRay signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    # handle offline, return 1 and set offline device as CANoe
    if ($main::opt_offline) {
        push( @{ $FR_control->{'read'}{'Devices'} }, 'CANoe' );
        return 1;
    }

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {
            if ( $OLE_handle = VEC_read_flxr_configure( $device, $action ) ) {
                S_w2log( 3, " FR_read_configure : device $device read configured \n" );
                push( @{ $FR_control->{'read'}{'Devices'} }, $device );
                $FR_control->{'read'}{$device}{'OLE_handle'} = $OLE_handle;
                return 1;
            }
            else {
                S_set_error( " FR_trace_configure : Could not configure $device for reading FlexRay signals\n", 131 );
                return;
            }
        }
    }
    return 1;
}

######################################################################

=head2 FR_read_flxr_signal
    
    ( Value , unit) = FR_read_flxr_signal ( $flxr_signal_name [, mode ] );

Read FlexRay signal from FlexRay tool(s) which is/are configured in FR_read_configure() Unit will be returned just when physical signal value is requested

B<Arguments:>

=over

=item $flxr_signal_name 

Name of the Flexray signal

=item $mode 

(optional) Phys or hex

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(1, 'dummy')     : Offline

(undef, undef) : Failure

=back

B<Examples:> 
  
    ( hex Value , undef) = FR_read_flxr_signal ( 'PreCrash_Fo_Kopfstuetze_verfahren' ,' hex');
    ( phys Value , Unit) = FR_read_flxr_signal ( 'PreCrash_Fo_Kopfstuetze_verfahren' ,'phys');

=cut

######################################################################

sub FR_read_flxr_signal {
    ## DESIGN #######
    
   #COMMENT-START
        # get arguments
        # - $flxr_signal,         
        # - $mode (optional)
    #COMMENT-END

    # STEP set default $mode = phys if not given    
    # IF $mode = either phys or Hex ?
    # IF-NO-START
        # STEP set read value = undef & set Error - mode neither phys or hex (raw).
    # IF-NO-END
    # IF-YES-START
         # IF execution mode?
             # IF-OFFLINE-START
                # STEP success case of phys mode - (return read value = 1 and unit = dummy)
             # IF-OFFLINE-END
             # IF-ONLINE-START
                # STEP check if device was configured or not ?
                # IF Device type ? 
                    #IF-CANoe-START
                        # COMMENT-START
                           # argument : -oleHandle, -$flxr_signal, -$mode
                           # return : 1. $readvalue :-(raw or phys) , 
                           #          2. ($unit for phys, undef for raw)
                        # COMMENT-END
                        # CALL VEC_read_flxr_signal
                    #IF-CANoe-END
                    #IF-NOT_CANoe-START
                      # STEP set read value = undef & set Error - Device type not CANoe.
                    #IF-NOT_CANoe-END                
             # IF-ONLINE-END             
    # IF-YES-END
    
    # STEP return read value

    my @args = @_;
    return (undef, undef) unless S_checkFunctionArguments( 'FR_read_flxr_signal ($flxr_signal_name [, $mode] )', @args );    

    my $flxr_signal_name = shift @args;
    my $mode             = shift @args;

    my ( $dev, $value, $unit );

    unless ( defined $mode ) {
        S_w2log( 4, " FR_read_flxr_signal : no mode (phys/hex) given , set to 'phys' per default )\n" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( "FR_read_flxr_signal : Invalid params ! mode shall be either 'phys' or 'hex'\n )", 114 );
        return ( undef, undef );
    }    
    
    S_w2log( 4, " FR_read_flxr_signal: Reads the FR signal $flxr_signal_name with mode $mode\n" );

    return ( 1, 'dummy' ) if $main::opt_offline;    # just return if running in offline mode

    unless ( $dev = $FR_control->{'read'}{'Devices'}[0] ) {
        S_set_error( " no FlexRay access read configured , FR_read_flxr_signal is calling FR_read_configure ... ", 0 );
        unless ( FR_read_configure() ) {
            S_set_error( " Could not configure devices for FlexRay access read ", 131 );
            return ( undef, undef );
        }
    }

    foreach my $device ( @{ $FR_control->{'read'}{'Devices'} } ) {
        if ( $device eq "CANoe" ) {
            ( $value, $unit ) = VEC_read_flxr_signal( $FR_control->{'read'}{$device}{'OLE_handle'}, $flxr_signal_name, $mode );   
            
            S_w2log( 3, " FR_read_flxr_signal : $flxr_signal_name = $value , unit = $unit for mode = $mode \n" );
            return ( $value, $unit );         
        }
        else {
            S_set_error( " FR_read_flxr_signal : Device type is not CANoe\n", 131 );
            return ( undef, undef );
        }
    }
}

######################################################################

=head2 FR_write_configure

    Function Name    :: FR_write_configure
    Description      :: prepare FlexRay tool that FlexRay signals can be write immediately
    Syntax           :: FR_write_configure( );
    Input Arguments  :: None
    Return Value(s)  :: None
    Example          :: FR_write_configure( );

=cut

######################################################################
sub FR_write_configure {
    S_w2log( 4, " FR_write_configure: Prepares Flexray to write the signals\n" );

    my ( @devices, $devices_text, $OLE_handle );

    @devices = EQUIP_get_devices( 'FlexRay_Access', 'write' );

    $FR_control->{'write'}{'Devices'} = [];

    unless ( scalar @devices ) {
        S_set_error( " FR_write_configure : LIFT_Testbenches doesnt contain Devices for writing FlexRay signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " FR_write_configure : LIFT_Testbenches doesnt contain valid devices for writing FlexRay signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    # handle offline, return 1 and set offline device as CANoe
    if ($main::opt_offline) {
        push( @{ $FR_control->{'write'}{'Devices'} }, 'CANoe' );
        return 1;
    }

    foreach my $device (@devices) {

        if ( $device eq "CANoe" ) {
            if ( $OLE_handle = VEC_write_flxr_configure($device) ) {
                S_w2log( 3, " FR_write_configure : device $device write configured \n" );
                push( @{ $FR_control->{'write'}{'Devices'} }, $device );
                $FR_control->{'write'}{$device}{'OLE_handle'} = $OLE_handle;
                return 1;
            }
            else {
                S_set_error( " FR_write_configure : Could not configure $device for writing FlexRay signals\n", 131 );
                return;
            }
        }
    }
    return 1;
}
######################################################################

=head2 FR_write_flxr_signal_mask

    Function Name    :: FR_write_flxr_signal_mask
    Description      :: read FlexRay signal from FlexRay tool(s) which is/are configured in FR_write_flxr_signal_mask() if $signal_value includes "-"
                        "-" are replaced by digit read from FlexRay --> only signal which are not masked out are written to FelxRay
                        write FlexRay signal from FlexRay tool(s) which was/were configured in FR_write_flxr_signal_mask()
    Syntax           :: return_value = FR_write_flxr_signal_mask ( $given_flxr_signal , $signal_value , [ $mode , $reset_mode ] );
    Input Arguments  :: $given_flxr_signal  - Flexray signal name
                        $signal_value - '-'
                        $mode - phys or hex
                        $reset_mode - reset
    Return Value(s)  :: None
    Example          :: FR_write_flxr_signal_mask ( 'PreCrash_Fo_Kopfstuetze_verfahren' , '-' , 'phys ' , 'reset' );

    example :
        $output = S_calculate_value_by_mask ( 0b000111 , "0b10--00" );
        --> $output = 0b100100

=cut

######################################################################

sub FR_write_flxr_signal_mask
{
    S_w2log( 4, " FR_write_flxr_signal_mask\n" );

    my ( $given_flxr_signal, $signal_value, $mode, $reset_mode ) = @_;

    unless ( defined $mode )
    {
        S_w2log( 4, " FR_write_flxr_signal_mask : no mode (phys/hex) given , set to 'phys' per default )" );
        $mode = 'phys';
    }

    S_w2log(
        5, " FR_write_flxr_signal_mask : (given_flxr_signal='$given_flxr_signal', signal_value='$signal_value',
         mode='$mode', reset_mode='$reset_mode' )\n" );
    return 1 if $main::opt_offline;    # just return if running in offline mode

    if ( $signal_value =~ m/-/i )
    {
        my $read_signal_value = FR_read_flxr_signal( $given_flxr_signal, 'phys' );

        my $calculated_value = S_calculate_value_by_mask( $read_signal_value, $signal_value );
        S_w2log( 3, " FR_write_flxr_signal_mask : calculated_value='$calculated_value', mode='$mode' \n" );
        FR_write_flxr_signal( $given_flxr_signal, $calculated_value, $mode, $reset_mode );
    }
    else
    {
        S_w2log( 3, " FR_write_flxr_signal_mask : signal_value='$signal_value', mode='$mode' \n" );
        FR_write_flxr_signal( $given_flxr_signal, $signal_value, $mode, $reset_mode );
    }

    return 1;
}

######################################################################


=head2 FR_write_flxr_signal
    
    return_value = FR_write_flxr_signal ( $given_flxr_signal_name , $signal_value , [ $mode] );

Write FlexRay signal from FlexRay tool(s) which was/were configured in FR_write_configure()

B<Arguments:>

=over

=item $given_flxr_signal_name 

Name of the Flexray signal

=item $signal_value 

Value of the Flexray signal

=item $mode 

(optional) Phys or hex

=back

B<Return Value:>

=item $returnValue 

1 : Successful and in offline

undef : Failure

=back

B<Examples:> 
FR_write_flxr_signal ( 'PreCrash_Fo_Kopfstuetze_verfahren' , '25' , 'phys');
FR_write_flxr_signal ( 'PreCrash_Fo_Kopfstuetze_verfahren' , '0x50' , 'hex');

=cut

######################################################################

sub FR_write_flxr_signal {
    ## DESIGN 
    
    # COMMENT-START
       # Get arguments 
       #  - $given_flxr_signal, 
       #  - $signal_value, 
       #  - $mode (optional)
    # COMMENT-END
    
    # STEP set default $mode = 'phys' if not defined
    # IF $mode = either phys or Hex ?
        # IF-NO-START
            # STEP writing status = undef and set Error - mode neither phys or hex (raw).
        # IF-NO-END
        
        # IF-YES-START
            # IF execution mode?
                # IF-OFFLINE-START
                    # STEP success case of phys mode - (return write = 1)
                # IF-OFFLINE-END
                
                # IF-ONLINE-START
                    # STEP check if device was configured or not ?                        
                        # IF Device type ? 
                           #IF-NOT_CANoe-START
                               # STEP write status = undef & set Error - Device type not CANoe.
                           #IF-NOT_CANoe-END
                           #IF-CANoe-START
                               # STEP write '$given_flxr_signal' the  $signal_value with mode $mode
                               # CALL VEC_write_flxr_signal                               
                           #IF-CANoe-END
                # IF-ONLINE-END         
        # IF-YES-END        
                
    # STEP return the write status
    
    my @args = @_;
    return unless S_checkFunctionArguments( 'FR_write_flxr_signal ($given_flxr_signal_name, $signal_value [,$mode] )', @args );

    my $given_flxr_signal_name = shift @args;
    my $signal_value           = shift @args;
    my $mode                   = shift @args;

    my ( $dev, $return_value );

    S_w2log( 4, " FR_write_flxr_signal: Writes flexray signals \n" );
    #
    #
    # workaround for : '0b0001000---'
    #
    #    $signal_value =~s/-/0/g; #workaround for masked signals
    #
    #
    #
    #

    unless ( defined $mode ) {
        S_w2log( 4, " FR_write_flxr_signal : no mode (phys/hex) given , set to 'phys' per default )" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( "FR_write_flxr_signal : Invalid params ! mode shall be either 'phys' or 'hex'\n )", 114 );
        return;
    }
    
    S_w2log( 4, " FR_write_flxr_signal: Writes the FR signal $given_flxr_signal_name with value $signal_value and mode $mode\n" );

    # apply label mapping if defined for current label in project defaults
    # if( defined $main::ProjectDefaults->{'LABEL_MAPPING'}{ $given_flxr_signal_name } )
    # {
    # $given_flxr_signal_name = $main::ProjectDefaults->{'LABEL_MAPPING'}{ $given_flxr_signal_name };
    # }
    return 1 if $main::opt_offline;    # just return if running in offline mode

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no FlexRay access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() ) {
            S_set_error( " Could not configure devices for FlexRay access write ", 131 );
            return;
        }
    }

    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } ) {
        if ( $device eq "CANoe" ) {

            if ( $return_value = VEC_write_flxr_signal( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flxr_signal_name, $signal_value, $mode ) ) {
                S_w2log( 3, " FR_write_flxr_signal : returns status $return_value for $given_flxr_signal_name = $signal_value ( $mode ) \n" );
                return $return_value;
            }
            else {
                S_set_error( " FR_write_flxr_signal : Could not write '$given_flxr_signal_name' from $device\n", 5 );
                return;
            }
        }
        else {
            S_set_error( " FR_write_flxr_signal : Device type is not CANoe\n", 131 );
            return;
        }
    }
}

######################################################################

=head2 FR_disable_PDU_update

    Function Name    :: FR_disable_PDU_update
    Description      :: disables the Flexray PDU updating
                        Sets mapping key CANOE_DISABLE to 0 in case of old implementation.
                        Sets mapping key CANOE_DISABLE to 1 in case of new implementation.
    Syntax           :: $return_value = FR_disable_PDU_update ( $given_flexray_PDU [ , $time_out_info ]);
    Input Arguments  :: $given_flexray_PDU  - Flexray Frame name as used in LIFT FLXR mapping
                        $time_out_info - additional info value which will be set in CAPL environment variable (eg: number of timeout cycles,time value)
    Return Value(s)  :: $return_value
    Example          :: $return_value = FR_disable_PDU_update ( 'Kessy_12' );
	
B<Note:>

Based on whether the old handling of enabling and disabling the PDU updating has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling PDU updating.

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling PDU updating.

=cut

######################################################################

sub FR_disable_PDU_update
{
    ## FR_write_configure have to called before
    ## use out function VEC_disable_flxr_PDU_update() of LIFT_vector_cantool
    S_w2log( 4, " FR_disable_PDU_update\n" );
    my ( $given_flexray_PDU, $time_out_info ) = @_;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_disable_PDU_update( FlexRay_PDU )", 110 );
        return;
    }

    return 1 if $main::opt_offline;    # just return if running in offline mode

    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no FlexRay access write configured , FR_disable_PDU_update is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Couldnt configure devices for FlexRay access write ", 131 );
            return;
        }
    }

    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {

        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {

            if ( $return_value = VEC_disable_flxr_PDU_update( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU, $time_out_info ) )
            {
                S_w2log( 3, " FR_disable_PDU_update : $given_flexray_PDU disabled\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_disable_PDU_update : Couldnt disable '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

######################################################################

=head2 FR_enable_PDU_update

    Function Name    :: FR_enable_PDU_update
    Description      :: enables the Flexray PDU updating
                        Sets mapping key CANOE_DISABLE to 1 in case of old implementation.
                        Sets mapping key CANOE_DISABLE to 0 in case of new implementation.
    Syntax           :: $return_value = FR_enable_PDU_update ( $given_flexray_PDU );
    Input Arguments  :: $given_flexray_PDU  - Flexray Frame name as used in LIFT FLXR mapping
    Return Value(s)  :: $return_value
    Example          :: $return_value = FR_enable_PDU_update ( 'Kessy_12' );
	
B<Note:>

Based on whether the old handling of enabling and disabling the PDU updating has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling PDU updating.

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling PDU updating.

=cut

######################################################################

sub FR_enable_PDU_update
{
    ## FR_write_configure have to called before
    ## use out function VEC_enable_flexray_PDU_update() of LIFT_vector_cantool
    S_w2log( 4, " FR_enable_PDU_update\n" );
    my $given_flexray_PDU = shift;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_enable_PDU_update( FlexRay_PDU )", 110 );
        return;
    }

    return 1 if $main::opt_offline;    # just return if running in offline mode

    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no FlexRay access write configured , FR_enable_PDU_update is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Couldnt configure devices for FlexRay access write ", 131 );
            return;
        }
    }

    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {

        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_enable_flxr_PDU_update( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU ) )
            {
                S_w2log( 5, " FR_enable_PDU_update : $given_flexray_PDU enabled\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_enable_PDU_update : Couldnt enable '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

#####################################################################

=head2 FR_trace_configure

    Function Name    :: FR_trace_configure
    Description      :: prepare FlexRay tool to start the trace
    Syntax           :: FR_trace_configure ( );
    Input Arguments  :: None
    Return Value(s)  :: None
    Example          :: FR_trace_configure ( );

=cut

######################################################################

sub FR_trace_configure {
    S_w2log( 4, " FR_trace_configure: Prepares FR to start trace \n" );
    my ( @devices, $devices_text, $OLE_handle, );

    @devices = EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    $FR_control->{'trace'}{'Devices'} = [];

    unless ( scalar @devices ) {
        S_set_error( " FR_trace_configure : LIFT_Testbenches doesnt contain Devices for tracing FlexRay signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " FR_trace_configure : LIFT_Testbenches doesnt contain valid devices to capture Trace of FlexRay signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    # handle offline, return 1 and set offline device as CANoe
    if ($main::opt_offline) {
        push( @{ $FR_control->{'trace'}{'Devices'} }, 'CANoe' );
        return 1;
    }

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {
            if ( $OLE_handle = VEC_trace_configure($device) ) {
                S_w2log( 3, " FR_trace_configure : device $device trace configured \n" );
                push( @{ $FR_control->{'trace'}{'Devices'} }, $device );
                $FR_control->{'trace'}{$device}{'OLE_handle'} = $OLE_handle;
                return 1;
            }
            else {
                S_set_error( " FR_trace_configure : Could not configure $device for tracing FlexRay signals\n", 131 );
                return;
            }
        }
    }
    return 1;
}

######################################################################

=head2 FR_trace_start

    Function Name    :: FR_trace_start
    Description      :: start measurement of FlexRay tool , which must be configured before with FR_trace_configure()
                        if the measurement is already running (because of use of FR_read_configure() before)
                        the measurment will be stopped and started again immediately to start an new log file
    Syntax           :: FR_trace_start ( );
    Input Arguments  :: None
    Return Value(s)  :: None
    Example          :: FR_trace_start ( );

=cut

######################################################################

sub FR_trace_start
{
    S_w2log( 4, " FR_trace_start: Start measurement of FlexRay tool\n" );

    # return without doing if no FlexRay_Access trace configured
    return 1 unless EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    return 1 if $main::opt_offline;

    my $device;

    unless ( $device = $FR_control->{'trace'}{'Devices'}[0] )
    {
        S_set_error( " no FlexRay access trace configured , FR_trace_start is calling FR_trace_configure ... ", 0 );
        unless ( FR_trace_configure() )
        {
            S_set_error( " Could not configure devices for FlexRay access trace ", 131 );
            return;
        }
    }

    if ( $device eq "CANoe" )
    {
        #
        # stop measurement first if it is still running ,
        #  then start the measurement again to create a new trace file
        #
        if ( VEC_check_running( $FR_control->{'trace'}{$device}{'OLE_handle'} ) )
        {
            unless ( VEC_stop_measurement( $FR_control->{'trace'}{$device}{'OLE_handle'} ) )
            {
                S_set_error( " Could not stop $device measurement", 131 );
                return;
            }
        }
        unless ( VEC_start_measurement( $FR_control->{'trace'}{$device}{'OLE_handle'} ) )
        {
            S_set_error( " Could not start $device measurement", 131 );
            return;
        }
    }

    return 1;
}

######################################################################

=head2 FR_trace_stop

    Function Name    :: FR_trace_stop
    Description      :: stop measurement of FlexRay tool which must be
                        configured before with FR_trace_configure() and
                        started with FR_trace_start()
    Syntax           :: FR_trace_stop ( );
    Input Arguments  :: None
    Return Value(s)  :: None
    Example          :: FR_trace_stop ( );

=cut

######################################################################

sub FR_trace_stop
{
    S_w2log( 4, " FR_trace_stop: Stops measurement of FlexRay tool\n" );

    # return without doing if no FlexRay_Access trace configured
    return 1 unless EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    return 1 if $main::opt_offline;

    my $device;

    unless ( $device = $FR_control->{'trace'}{'Devices'}[0] )
    {
        S_set_error( " no trace configured , use FR_trace_configure() before", 131 );
        return;
    }

    my $check_run = FR_trace_check_running();

    if ( $check_run == 0 )
    {
        S_w2log(3, " FR_trace_stop : trace has been stopped already was not started on $device, use FR_trace_start() before");
    }
    else
    {
        if ( $device eq "CANoe" )
        {
            unless ( VEC_stop_measurement( $FR_control->{'trace'}{$device}{'OLE_handle'} ) )
            {
                S_set_error( " Could not stop $device measurement", 131 );
                return;
            }
        }
    }

    return 1;
}

######################################################################

=head2 FR_trace_check_running

    Function Name    :: FR_trace_check_running
    Description      :: check if the trace is still running on FlexRay tool
    Syntax           :: $return_value = FR_trace_check_running ( );
    Input Arguments  :: None
    Return Value(s)  :: return_value = 1 -> FlexRay trace still running
                        return_value = 0 -> FlexRay trace not running
    Example          :: $return_value = FR_trace_check_running ( );

=cut

######################################################################
sub FR_trace_check_running {
    S_w2log( 4, " FR_trace_check_running\n" );

    # return without doing if no FlexRay_Access trace configured
    return 1 unless EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    my $device;
    my $return_value;

    unless ( $device = $FR_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use FR_trace_configure() before", 131 );
        return;
    }

    return 1 if $main::opt_offline; # measurement is running - as offline  

    if ( $device eq "CANoe" ) {
        $return_value = VEC_check_running( $FR_control->{'trace'}{$device}{'OLE_handle'} );
        if ( $return_value == 1 ) {
            S_w2log( 3, " FR_trace_check_running : FlexRay trace still running\n" );
        }
        elsif ( $return_value == 0 ) {
            S_w2log( 3, " FR_trace_check_running : FlexRay trace not running\n" );
        }
        else {
            S_set_error( " error while checking running FlexRay trace\n", 131 );
        }
        return $return_value;
    }
}

######################################################################

=head2 FR_trace_store

    Function Name    :: FR_trace_store
    Description      :: store trace of FlexRay tool measurement configured before with FR_trace_configure() and started with FR_trace_start().
                        if measurement was not stopped before it will be restarted after store of trace
                        reason : possibly read can signals function needs the running measurement
    Syntax           :: $returned_store_file_name = FR_trace_store ( [ $store_file_name ] );
    Input Arguments  :: $store_file_name - Logfile name . If no store_file_name given the Flexray trace will be stored in Testdocumentation
    Return Value(s)  :: returned_store_file_name - returned trace name
    Example          :: $returned_store_file_name = FR_trace_store();

    special for devices : CANoe
        - VEC_check_running
        - VEC_trace_store
        - VEC_start_measurement ( if check running was true before )

=cut

######################################################################

sub FR_trace_store
{

    my $store_file_name = shift;

    S_w2log( 4, " FR_trace_store\n" );

    # return without doing if no FlexRay_Access trace configured
    return 1 unless EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    my ( $returned_store_file_name, $measurement_was_running, );

    my $device;
    unless ( $device = $FR_control->{'trace'}{'Devices'}[0] )
    {
        S_set_error( " no trace configured , use FR_trace_configure() before", 131 );
        return;
    }

    if ( $device eq "CANoe" )
    {
        # check whether measurement was running is necessary
        # to start measurement again after store of logfile
        # -> background : if TC needs read_flxr_signals via CANoe ,
        #                 the read configure condition (running measurement) must be fulfilled
        $measurement_was_running = VEC_check_running( $FR_control->{'trace'}{$device}{'OLE_handle'} );
        return unless ( $returned_store_file_name = VEC_trace_store( $FR_control->{'trace'}{$device}{'OLE_handle'}, $store_file_name ) );
    }
    S_w2log( 3, " FR_trace_store : file name of the trace returned in FR_trace_store is $returned_store_file_name\n" );
    return $returned_store_file_name;
}

######################################################################

=head2 FR_trace_store_both

    Function Name    :: FR_trace_store_both
    Description      :: stores both trace file and Signals file.
                        if measurement was not stopped before it will be restarted after store of trace
                        reason : possibly read can signals function needs the running measurement
    Syntax           :: ( $returned_trace_file_name , $returned_flxr_signals_file_name ) = FR_trace_store_both ( [ $store_file_name ] );
    Input Arguments  :: $store_file_name - Logfile name . If no store_file_name given the Flexray trace will be stored in Testdocumentation
    Return Value(s)  :: $returned_trace_file_name - returned trace name
                        $returned_flxr_signals_file_name - returned signals file name
    Example          :: ( $returned_trace_file_name , $returned_flxr_signals_file_name ) = FR_trace_store_both();

=cut

######################################################################

sub FR_trace_store_both
{

    S_w2log( 4, " FR_trace_store_both: stores both Trace file and Signals file \n" );

    my $store_trace_file_name = shift;

    # return without doing if no FlexRay_Access trace configured
    return 1 unless EQUIP_get_devices( 'FlexRay_Access', 'trace' );

    my ( $returned_trace_file_name, $returned_flxr_signals_file_name, $measurement_was_running, );

    my $device;
    unless ( $device = $FR_control->{'trace'}{'Devices'}[0] )
    {
        S_set_error( " no trace configured , use FR_trace_configure() before", 131 );
        return;
    }

    if ( $device eq "CANoe" )
    {
        # check whether measurement was running is necessary
        # to start measurement again after store of logfile
        # -> background : if TC needs read_flxr_signals via CANoe ,
        #                 the read configure condition (running measurement) must be fulfilled
        $measurement_was_running = VEC_check_running( $FR_control->{'trace'}{$device}{'OLE_handle'} );
        return unless ( $returned_trace_file_name = VEC_trace_store( $FR_control->{'trace'}{$device}{'OLE_handle'}, $store_trace_file_name ) );

        S_w2log( 3, " FR_trace_store_both: got trace file : '$returned_trace_file_name'\n" );

        $returned_flxr_signals_file_name = VEC_trace_flxr_store_signals_file( $FR_control->{'trace'}{$device}{'OLE_handle'} );

        unless ($returned_flxr_signals_file_name)
        {
            S_set_error( " Error while calling VEC_trace_flxr_store_signals_file()", 131 );
            return;
        }

        if ( $returned_flxr_signals_file_name == -1 )
        {
            S_w2log( 3, " FR_trace_store_both: ONLINE Signals file name not defined in Testbench config" );
            $returned_flxr_signals_file_name = undef;
        }
        else
        {
            S_w2log( 3, " FR_trace_store_both: got ONLINE signals file : '$returned_flxr_signals_file_name'\n" );
        }
    }

    return ( $returned_trace_file_name, $returned_flxr_signals_file_name );
}

######################################################################

=head2 FR_get_flxr_signal_info

    Function Name    :: FR_get_flxr_signal_info
    Description      :: is a hash reference containing the signal info from LIFT FlexRay Mapping module plus the message info
    Syntax           :: $returned_sig_info = FR_get_flxr_signal_info ( $flxr_signal_name );
    Input Arguments  :: $flxr_signal_name -  signal name or message name.
    Return Value(s)  :: $returned_sig_info - hash reference of signal data
    Example          :: $returned_sig_info = FR_get_flxr_signal_info ( 'Blinken_li_Kombi_Takt' );

=cut

######################################################################

sub FR_get_flxr_signal_info
{
    S_w2log( 4, " FR_get_flxr_signal_info: Reads signal and message info from FR mapping \n" );

    my $flxr_signal_name = shift;

    my $returned_sig_info;
    my $message;
    my ( $fr_pdu_or_frame_label, $fr_pdu_or_frame_name );

    unless ( defined $flxr_signal_name )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_get_flxr_signal_info( $flxr_signal_name )", 110 );
        return;
    }

    my $FlexrayMapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );

    unless (%$FlexrayMapping)
    {
        S_set_error( " LIFT FlexRayMapping is not defined", 20 );
        return;
    }

    unless ( $returned_sig_info = $FlexrayMapping->{$flxr_signal_name} )
    {
        S_set_error( " LIFT_FlexRayMapping doesnot contain info for signal : '$flxr_signal_name'", 20 );
        return;
    }

## Incase if user has defined $message under label 'FR_PDU' in FlexrayMapping file
    if ( defined $FlexrayMapping->{'FR_PDU'} )
    {
        $fr_pdu_or_frame_label = 'FR_PDU';
        $fr_pdu_or_frame_name  = 'FR_PDU_NAME';    ## In FlexrayMapping file message name of the signal is defined under 'FR_PDU_NAME'
    }

## Incase if user has defined $message under label 'FR_FRAMES'in FlexrayMapping file
    # elsif(defined $FlexrayMapping->{'FR_FRAMES'})
    # {
    # $fr_pdu_or_frame_label = 'FR_FRAMES';
    # $fr_pdu_or_frame_name = 'FR_FRAME_NAME';## In FlexrayMapping file message name of the signal is defined under 'FR_FRAME_NAME'
    # }

    unless ( $message = $returned_sig_info->{$fr_pdu_or_frame_name} )
    {
        S_set_error( " LIFT_FlexRayMapping doesnot contain 'FR_PDU_NAME'/'FR_FRAME_NAME' info for signal : '$flxr_signal_name'", 20 );
        return;
    }
    unless ( $returned_sig_info->{'MESSAGE_INFO'} = $FlexrayMapping->{$fr_pdu_or_frame_label}{$message} )
    {
        S_set_error( "'FR_PDU'/'FR_FRAMES' in LIFT_FlexRayMapping doesnot contain info for message : '$message'", 20 );
        return;
    }

    return $returned_sig_info;
}

######################################################################

=head2 FR_get_flxr_message_info

    Function Name    :: FR_get_flxr_message_info
    Description      :: is a hash reference containing the message info from LIFT FlexRay Mapping module
    Syntax           :: $returned_msg_info = FR_get_flxr_message_info ( $flxr_message_name );
    Input Arguments  :: $flxr_message_name - messages name.
    Return Value(s)  :: $returned_msg_info - hash reference of message info
    Example          :: $returned_msg_info = FR_get_flxr_message_info ( 'FRAME_2_2_4' );

=cut

######################################################################

sub FR_get_flxr_message_info
{
    S_w2log( 4, " FR_get_flxr_message_info: Reads message info from FR mapping \n" );

    my $flxr_message_name = shift;

    my $returned_msg_info;
    my @signals;
    my $fr_pdu_or_frame_name;

    unless ( defined $flxr_message_name )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_get_flxr_message_info( $flxr_message_name )", 110 );
        return;
    }

    my $FlexrayMapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );

    unless (%$FlexrayMapping)
    {
        S_set_error( " LIFT FlexRayMapping is not defined", 20 );
        return;
    }

## Incase if user has defined $message under label 'FR_PDU' in FlexrayMapping file
    if ( defined $FlexrayMapping->{'FR_PDU'} )
    {
        $fr_pdu_or_frame_name = 'FR_PDU_NAME';    ## In FlexrayMapping file message name of the signal is defined under 'FR_PDU_NAME'
        unless ( $returned_msg_info = $FlexrayMapping->{'FR_PDU'}{$flxr_message_name} )
        {
            S_set_error( " 'FR_PDU' in LIFT_FlexRayMapping doesnot contain info for message : '$flxr_message_name'", 20 );
            return;
        }
    }
## Incase if user has defined $message under label 'FR_FRAMES'in FlexrayMapping file
    # elsif(defined $FlexrayMapping->{'FR_FRAMES'})
    # {
    # $fr_pdu_or_frame_name = 'FR_FRAME_NAME';## In FlexrayMapping file message name of the signal is defined under 'FR_FRAME_NAME'
    # unless( $returned_msg_info = $FlexrayMapping->{'FR_FRAMES'}{ $flxr_message_name } )
    # {
    # S_set_error( "'FR_FRAMES' in LIFT_FlexRayMapping doesnot contain info for message : '$flxr_message_name'", 20 );
    # return;
    # }
    # }
    foreach my $signal ( keys %$FlexrayMapping )
    {
        next unless "HASH" eq ref $FlexrayMapping->{$signal};
        push( @signals, $signal ) if $flxr_message_name eq $FlexrayMapping->{$signal}{$fr_pdu_or_frame_name};
    }

    $returned_msg_info->{'FlexRay_SIGNALS'} = \@signals;

    return $returned_msg_info;
}

######################################################################

=head2 FR_calc_hex_to_phys

    Function Name    :: FR_calc_hex_to_phys
    Description      :: Converts the Hex_Value into its physical Value dependendly from the format of the FlexRay signal.
    Syntax           :: $phys_value = FR_calc_hex_to_phys ( $flxr_signal_info , $hex_value );
    Input Arguments  :: $flxr_signal_info is a hash reference containing the signal info from LIFT FlexRay Mapping module plus the message info
                        $hex_value - hex value of the signal
    Return Value(s)  :: $phys_value - physical value of the given $hex_value.
    Example          :: $phys_value = FR_calc_hex_to_phys ( $flxr_signal_info , $Hex_Value );

=cut

######################################################################

sub FR_calc_hex_to_phys
{
    S_w2log( 4, " FR_calc_hex_to_phys\n" );

    my ( $flxr_signal_info, $hex_value ) = @_;

    unless ( defined $hex_value )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_get_flxr_signal_info( $flxr_signal_info , $hex_value )", 110 );
        return;
    }

    my ( $phys_value, $sig_offset, $sig_type, $sig_factor, $signal_name, );

    unless ( $signal_name = $flxr_signal_info->{'SIGNAL_NAME'} )
    {
        S_set_error( " no 'SIGNAL_NAME' defined for given FlexRay signal\n", 109 );
        return;
    }

    $sig_offset = $flxr_signal_info->{'OFFSET'};
    unless ( defined $sig_offset )
    {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_type = $flxr_signal_info->{'TYPE'};
    unless ( defined $sig_type )
    {
        S_set_error( " no 'TYPE' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_factor = $flxr_signal_info->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 )
    {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }

    $phys_value = ( hex ($hex_value) * $sig_factor ) + $sig_offset;
    S_w2log( 3, "   Transformation '$signal_name' : $phys_value (phys) = ( $hex_value (hex) * $sig_factor (factor) + $sig_offset (offset) \n" );

    return $phys_value;
}

######################################################################

=head2 FR_calc_phys_to_hex

    Function Name     :: FR_calc_phys_to_hex
    Description       :: Converts the Phys_Value into its Raw Value dependendly from the fromat of the Flexray signal given in CAN_Signal_info.
    Syntax            :: $hex_value = FR_calc_phys_to_hex ( $flxr_signal_info , $phys_Value );
    Input Arguments   :: $flxr_signal_info - hash reference containing the signal info from LIFT Flexray Mapping module plus the message info
                         $Phys_Value - physical value of the signal
    Return Value(s)   :: $hex_value - it is the hex value of the signal
    Example           :: $hex_value = FR_calc_phys_to_hex( flxr_signal_info , phys_Value );

=cut

######################################################################

sub FR_calc_phys_to_hex
{
    S_w2log( 4, " FR_calc_phys_to_hex\n" );

    my ( $flxr_signal_info, $phys_value ) = @_;

    unless ( defined $phys_value )
    {
        S_set_error( " Too Less Params ! SYNTAX: FR_get_flxr_signal_info( $flxr_signal_info , $phys_value )", 110 );
        return;
    }

    my ( $hex_value, $sig_offset, $sig_type, $sig_factor, $signal_name, );

    unless ( $signal_name = $flxr_signal_info->{'SIGNAL_NAME'} )
    {
        S_set_error( " no 'SIGNAL_NAME' defined for given FlexRay signal\n", 109 );
        return;
    }

    $sig_offset = $flxr_signal_info->{'OFFSET'};
    unless ( defined $sig_offset )
    {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_type = $flxr_signal_info->{'TYPE'};
    unless ( defined $sig_type )
    {
        S_set_error( " no 'TYPE' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_factor = $flxr_signal_info->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 )
    {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }

    $hex_value = ( $phys_value - $sig_offset ) / $sig_factor;

    S_w2log( 3, "   Transformation '$signal_name' : $hex_value (hex) = ( $phys_value (phys) - $sig_offset (offset) / $sig_factor (factor) \n" );
    return $hex_value;
}

######################################################################

=head2 FR_trace_get_PDU_data

    Function Name    :: FR_trace_get_PDU_data
    Description      :: Reads a single frame from a CANoe trace file. $fr_trace_file is the full name of the trace file.
                        Returns reference to hash structure with information on Flexray frame.
    Syntax           :: $message_ref = FR_trace_get_PDU_data ( $fr_trace_file , $fr_PDU [, $fr_bus_nbr , $fr_ignore_uBit]);
    Input Arguments  :: $fr_trace_file - trace file path
                        $fr_PDU - Flerxray frame in the trace file.
                        $fr_bus_nbr - FR bus number
                        $fr_ignore_uBit - by default its FR
    Return Value(s)  :: $message_ref - hash reference of the PDU data.
    Example          :: $message_ref = FR_trace_get_PDU_data ( $fr_trace_file , 'Kessy_12' );

    $message_ref = {
                        'timestamp_1' => {
                                       'HEADER_CRC' => 'HEADER_CRC' ,
                                       'DLC_1' => 'DLC_1',
                                       'DLC_2' => 'DLC_2',
                                       'DATA' => raw data bytes of frame ,
                                          },
                        'timestamp_2' => {
                                       'HEADER_CRC' => 'HEADER_CRC' ,
                                       'DLC_1' => 'DLC_1',
                                       'DLC_2' => 'DLC_2',
                                       'DATA' => raw data bytes of frame ,
                                          },
                     };

=cut

######################################################################

sub FR_trace_get_PDU_data
{
    S_w2log( 4, " FR_trace_get_PDU_data\n" );

    my ( $fr_log_file, $fr_PDU, $fr_bus_nbr, $fr_ignore_uBit ) = @_;

    my $all_msgs;

    unless ( defined $fr_PDU )
    {
        S_set_error( " Too Less Params ! SYNTAX: undefined fr_PDU in FR_trace_get_PDU_data( fr_trace_file , fr_PDU [, fr_bus_nbr , fr_ignore_uBit])", 110 );
        return 0;
    }

    unless ( defined $fr_bus_nbr )
    {
        $fr_bus_nbr = "Fr";
    }

    $fr_ignore_uBit = 1 unless ( defined $fr_ignore_uBit );
    $all_msgs = VEC_trace_fr_get_PDU_data( $fr_log_file, $fr_PDU, $fr_bus_nbr, $fr_ignore_uBit );

    return $all_msgs;
}

=head2 FR_trace_get_PD_responses

    $responses_href = FR_trace_get_PD_responses( $traceFilename, $response [, $busNr ] );

Reads the Flexray trace file $traceFilename and extracts all PD responses with response code $response.

Input:

    $filename       : name of Flexray trace file with PD responses
    $response       : response code that shall be extracted from trace (in hex)
    $busNr          : (optional) bus number in trace, default = 1

Output:

    $responses_href : reference to hash with all responses of $response. Primary key is the time of the response

    $responses_href = {
        TIME_0 => [responseByte0, responseByte1, responseByte2, ...] ,
        TIME_1 => [responseByte0, responseByte1, responseByte2, ...] ,
        ...
    }

Note1: responseByteX is always in dec !!!
Note2: response FR-ID is taken from project const: $Defaults->{'CUSTOMER_DIAGNOSIS'}{'ResponseID_PD'}

Examples:

    Extract all responses (4D) of the PD request 0D (SMI7xy verification):
    $responses_href = FR_trace_get_PD_responses( 'myTraceFile.asc', '4D' );

=cut

sub FR_trace_get_PD_responses
{

    my @args = @_;
    return {} unless S_checkFunctionArguments( 'FR_trace_get_PD_responses( $traceFilename, $response [, $busNr ] )', @args );

    my $filename = shift @args;
    my $response = shift @args;
    my $busNr    = shift @args;

    Readonly my $BYTE_LENGTH => 256;

    $busNr = 1 if not defined $busNr;

    # get response FR-ID from project const
    my $responseID = S_get_contents_of_hash( [ 'CUSTOMER_DIAGNOSIS', 'ResponseID_PD' ] );
    if ( not defined $responseID )
    {
        S_set_error("'ResponseID_PD' not defined in project const in section 'CUSTOMER_DIAGNOSIS'.");
        return {};
    }
    $responseID =~ s/^0x(\w+)/$1/g;    # remove leading 0x

    # get all data frames of response ID from trace
    my $message_ref = VEC_trace_fr_get_PDU_data ( $filename , $responseID , $busNr, undef, 1 );

    if ( not defined $message_ref )
    {
        S_set_error("Could not get data from FR trace on bus $busNr and message ID $responseID.");
        return {};
    }

    my ( $responseString, %responses, $length, $timestamp );
    my $responseFound = 0;

    # loop over all response frames
    foreach my $frame ( sort { $a <=> $b } keys %$message_ref )
    {
        # get data string of response (string of hex bytes)
        my $data = $message_ref->{$frame}{'DATA'};

        # check if second byte is the expected resonse code
        if ( not $responseFound and $data =~ /^\s*(\w\w)\s+($response.+)$/i )
        {
            # set marker $responseFound because responses can be spread over several frames
            $responseFound = 1;

            # determine the expected data length in number of bytes
            $length = hex($1);
            my $responseFirstByte = substr($response, 0, 2);
            if ( uc($responseFirstByte) eq '4D' or uc($responseFirstByte) eq '4E')
            {
                # only for response 4D the length is in fact longer than 256
                $length += $BYTE_LENGTH;
            }

            # get first data bytes and frame time
            $responseString = $2;
            $timestamp      = $frame;
        }
        else
        {
            # second byte is not the expected resonse code
            if ($responseFound)
            {
                # add data bytes to $responseString if the response was found earlier
                $responseString .= ' ' . $data;
            }
            else
            {
                # do nothing
            }
        }

        # get current response bytes in a list
        my @hexBytes = split( /\s+/, $responseString );
        my $nrOfHexBytes = @hexBytes;

        # check if length of the list is => the expected response length
        if ( $responseFound and $nrOfHexBytes >= $length )
        {
            # the response is complete and can be put to the output data structure
            my @decBytes = map( { hex($_) } @hexBytes );

            # cut response bytes to be exactly $length bytes long
            splice( @decBytes, $length );
            $responses{$timestamp} = \@decBytes;
            $responseFound = 0;
        }
    }

    return \%responses;
}


######################################################################

=head2 FR_evaluate_PDU_CRC

    Function Name    :: FR_evaluate_PDU_CRC
    Description      :: CRC calculation is based on CRC-8 algorithm.Function is validated only for Flexray PDU
    Syntax           :: $verdict = FR_evaluate_PDU_CRC( $expected_CRC , $PDU_ID , @DATA_bytes );
    Input Arguments  :: $expected_CRC : Expected CRC, at a defined time stamp.It should be a decimal value.
                        $PDU_ID : The PDU ID to calculate the CRC.It should be a decimal value.
                        @DATA_bytes : DATA bytes obtained from the function call FR_trace_get_PDU_data.
                        Only bytes that should be considered for CRC calculation are to be passed.
    Return Value(s)  :: $Verdict - Verdict
    Example          :: $verdict = FR_evaluate_PDU_CRC( $expected_CRC , $PDU_ID , @DATA_bytes );

=cut

######################################################################

sub FR_evaluate_PDU_CRC
{
    S_w2log( 4, " FR_evaluate_PDU_CRC\n" );

    my $expected_CRC = shift;
    my $PDU_ID       = shift;
    my @DATA_bytes   = @_;

    my @crc8_lookup_tbl =(  0x00, 0x2f, 0x5e, 0x71, 0xbc, 0x93, 0xe2, 0xcd,
                            0x57, 0x78, 0x09, 0x26, 0xeb, 0xc4, 0xb5, 0x9a,
                            0xae, 0x81, 0xf0, 0xdf, 0x12, 0x3d, 0x4c, 0x63,
                            0xf9, 0xd6, 0xa7, 0x88, 0x45, 0x6a, 0x1b, 0x34,
                            0x73, 0x5c, 0x2d, 0x02, 0xcf, 0xe0, 0x91, 0xbe,
                            0x24, 0x0b, 0x7a, 0x55, 0x98, 0xb7, 0xc6, 0xe9,
                            0xdd, 0xf2, 0x83, 0xac, 0x61, 0x4e, 0x3f, 0x10,
                            0x8a, 0xa5, 0xd4, 0xfb, 0x36, 0x19, 0x68, 0x47,
                            0xe6, 0xc9, 0xb8, 0x97, 0x5a, 0x75, 0x04, 0x2b,
                            0xb1, 0x9e, 0xef, 0xc0, 0x0d, 0x22, 0x53, 0x7c,
                            0x48, 0x67, 0x16, 0x39, 0xf4, 0xdb, 0xaa, 0x85,
                            0x1f, 0x30, 0x41, 0x6e, 0xa3, 0x8c, 0xfd, 0xd2,
                            0x95, 0xba, 0xcb, 0xe4, 0x29, 0x06, 0x77, 0x58,
                            0xc2, 0xed, 0x9c, 0xb3, 0x7e, 0x51, 0x20, 0x0f,
                            0x3b, 0x14, 0x65, 0x4a, 0x87, 0xa8, 0xd9, 0xf6,
                            0x6c, 0x43, 0x32, 0x1d, 0xd0, 0xff, 0x8e, 0xa1,
                            0xe3, 0xcc, 0xbd, 0x92, 0x5f, 0x70, 0x01, 0x2e,
                            0xb4, 0x9b, 0xea, 0xc5, 0x08, 0x27, 0x56, 0x79,
                            0x4d, 0x62, 0x13, 0x3c, 0xf1, 0xde, 0xaf, 0x80,
                            0x1a, 0x35, 0x44, 0x6b, 0xa6, 0x89, 0xf8, 0xd7,
                            0x90, 0xbf, 0xce, 0xe1, 0x2c, 0x03, 0x72, 0x5d,
                            0xc7, 0xe8, 0x99, 0xb6, 0x7b, 0x54, 0x25, 0x0a,
                            0x3e, 0x11, 0x60, 0x4f, 0x82, 0xad, 0xdc, 0xf3,
                            0x69, 0x46, 0x37, 0x18, 0xd5, 0xfa, 0x8b, 0xa4,
                            0x05, 0x2a, 0x5b, 0x74, 0xb9, 0x96, 0xe7, 0xc8,
                            0x52, 0x7d, 0x0c, 0x23, 0xee, 0xc1, 0xb0, 0x9f,
                            0xab, 0x84, 0xf5, 0xda, 0x17, 0x38, 0x49, 0x66,
                            0xfc, 0xd3, 0xa2, 0x8d, 0x40, 0x6f, 0x1e, 0x31,
                            0x76, 0x59, 0x28, 0x07, 0xca, 0xe5, 0x94, 0xbb,
                            0x21, 0x0e, 0x7f, 0x50, 0x9d, 0xb2, 0xc3, 0xec,
                            0xd8, 0xf7, 0x86, 0xa9, 0x64, 0x4b, 0x3a, 0x15,
                            0x8f, 0xa0, 0xd1, 0xfe, 0x33, 0x1c, 0x6d, 0x42
                        );

    my ( $CRC, $CRC_Init, $byte_index, @detected_byte, $index, $detected_CRC, $DATA_BYTE_SIZE, );
    $CRC_Init       = 0xFF;
    $CRC            = $CRC_Init;
    $DATA_BYTE_SIZE = @DATA_bytes;
    $DATA_BYTE_SIZE = $DATA_BYTE_SIZE - 1;

    unless ( scalar @DATA_bytes )
    {
        S_set_error( "Too Less Params ! SYNTAX: undefined DATA_bytes in FR_evaluate_PDU_CRC( $expected_CRC , $PDU_ID , @DATA_bytes )", 110 );
        return VERDICT_INCONC;
    }

    return 1 if $main::opt_offline;    # just return if running in offline mode

    S_w2log( 3, "FR_evaluate_PDU_CRC: PDU_ID = $PDU_ID\n" );
    for ( $byte_index = 0 ; $byte_index <= $DATA_BYTE_SIZE ; $byte_index++ )
    {
        $detected_byte[$byte_index] = hex $DATA_bytes[$byte_index];
        S_w2log( 5, "FR_evaluate_PDU_CRC : detected_byte[$byte_index] = $detected_byte[$byte_index] \n" );

        $index = $CRC ^ $detected_byte[$byte_index];
        S_w2log( 5, "FR_evaluate_PDU_CRC : CRC XOR  detected_byte[$byte_index] is index = $index  \n" );

        $CRC = $crc8_lookup_tbl[$index];
        S_w2log( 5, "FR_evaluate_PDU_CRC : Value at crc8_lookup_tbl[$index] is: $CRC \n" );

    }

    $index = ( $CRC ^ $PDU_ID );
    S_w2log( 5, "FR_evaluate_PDU_CRC : CRC XOR PDU_ID is index = $index \n" );

    $CRC = $crc8_lookup_tbl[$index];
    S_w2log( 5, "FR_evaluate_PDU_CRC : Value at crc8_lookup_tbl[$index] is: $CRC \n" );

    $detected_CRC = $CRC_Init - $CRC;
    S_w2log( 5, "FR_evaluate_PDU_CRC : Detected CRC in decimal: $detected_CRC \n" );

    if ( $expected_CRC eq $detected_CRC )
    {
        S_w2log(3,"FR_evaluate_PDU_CRC: expected_CRC(dec): $expected_CRC == detected CRC(dec): $detected_CRC\n");
        S_set_verdict("VERDICT_PASS");
        return VERDICT_PASS;
    }
    else
    {
        S_w2log(3,"FR_evaluate_PDU_CRC: expected_CRC(dec): $expected_CRC != detected CRC(dec): $detected_CRC \n");
        S_set_verdict("VERDICT_FAIL");
        return VERDICT_FAIL;
    }
}

######################################################################

=head2 FR_trace_get_dataref

    Function Name    :: FR_trace_get_dataref
    Description      :: extracts the data reference of both signal and PDUs from CANoe trace file (timestamp in seconds).
    Syntax           :: $trace_data_ref = FR_trace_get_dataref ($fr_log_file,$given_flxr_signals_or_PDUs ,[$data_format, $fr_bus_nbr, $fr_ignore_uBit]);
    Input Arguments  :: $fr_log_file - trace file path , file format - .asc and timing should be absolute.
                        $given_flxr_signals_or_PDUs - array of Signals name and PDUs name whose Data ref needs to be extracted
                        optional parameters :: $data_format - DEC or HEX (case insensitive). HEX is taken as default.
                                               $fr_bus_nbr - FR bus number
                                               $fr_ignore_uBit - by default its 1
                                               If defined $fr_ignore_uBit ,then $fr_bus_nbr is mandatory
    Return Value(s)  :: $trace_data_ref - hash reference of the data of the required signals and PDUs
    Example          :: $trace_data_ref = FR_trace_get_dataref($fr_log_file,['Klemmen_Status_01','Kessy_12','Blinken_li_Kombi_Takt']);

        $trace_data_ref = {
                        'timestamp_1' => {
                                            'PDU_1' => {
                                                        'DATA' => 'phys_value_at_time_1' ,
                                                        'DLC_1' => 'DLC_1',
                                                        'DLC_2' => 'DLC_2',
                                                       }
                                            'signal_1' => 'phys_value_at_time_1',
                                            'signal_2' => 'phys_value_at_time_1',
                                            'PDU_2' => {
                                                        'DATA' => 'phys_value_at_time_1' ,
                                                        'DLC_1' => 'DLC_1',
                                                        'DLC_2' => 'DLC_2',
                                                       }
                                            'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                            'PDU_1' => {
                                                        'DATA' => 'phys_value_at_time_2' ,
                                                        'DLC_1' => 'DLC_1',
                                                        'DLC_2' => 'DLC_2',
                                                       }
                                            'signal_1' => 'phys_value_at_time_2',
                                            'signal_2' => 'phys_value_at_time_2',
                                            'PDU_2' => {
                                                        'DATA' => 'phys_value_at_time_2' ,
                                                        'DLC_1' => 'DLC_1',
                                                        'DLC_2' => 'DLC_2',
                                                       }
                                            'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub FR_trace_get_dataref
{
    S_w2log( 4, " FR_trace_get_dataref: Extracts the data reference of both signal and PDUs \n" );

    my $fr_log_file                = shift;
    my $given_flxr_signals_or_PDUs = shift;
    my $data_format                = shift;    #DEC or HEX
    my $fr_bus_nbr                 = shift;
    my $fr_ignore_uBit             = shift;
    my @flxr_signals_or_PDUs;

    my $ReturnDataRef = ();                    # < - - declared as hash ref initially

    my ( $FR_PDU, $found_PDU, $flxr_signal, $FR_signal, $just_PDU_infos, $found_Signal, );

    unless ( defined $given_flxr_signals_or_PDUs )
    {
        S_set_error( " Too Less Parameters ! SYNTAX:  FR_trace_get_dataref( fr_log_file, device, given_flxr_signals_or_PDUs , data_format [, fr_bus_nbr , fr_ignore_uBit])", 110 );
        return;
    }

    unless ( -f $fr_log_file )
    {
        S_set_error( " File $fr_log_file not found", 109 );
        return;
    }

    if ( ref $given_flxr_signals_or_PDUs eq 'ARRAY' )
    {
        @flxr_signals_or_PDUs = @$given_flxr_signals_or_PDUs;
    }
    else
    {
        S_set_error( " Invalid Parameters ! given_flxr_signals_or_PDUs is not an Array Reference", 114 );
        return;
    }
    unless ( defined($data_format) )
    {
        S_w2log( 5, "By default dataformat is hex" );
        $data_format = 'HEX';
    }
    unless (@flxr_signals_or_PDUs)
    {
        S_set_error( " Too Less Parameters ! SYNTAX:  FR_trace_get_dataref( fr_log_file, device, given_flxr_signals_or_PDUs , data_format [, fr_bus_nbr , fr_ignore_uBit])", 110 );
        return;

    }
    my $FlexrayMapping = S_get_contents_of_hash( ['Mapping_FLEXRAY'] );

    unless (%$FlexrayMapping)
    {
        S_set_error( " LIFT FlexRayMapping is not defined", 20 );
        return;
    }

    foreach my $FR_signal_or_PDU (@flxr_signals_or_PDUs)
    {
        if ( exists $FlexrayMapping->{'FR_PDU'}{$FR_signal_or_PDU} )
        {
            $FR_PDU         = $FR_signal_or_PDU;
            $just_PDU_infos = 1;
        }
        else
        {
            $FR_signal = $FR_signal_or_PDU;
            unless ( $FR_PDU = $FlexrayMapping->{$FR_signal}{'FR_PDU_NAME'} )
            {
                S_set_error( " FR_trace_get_dataref: no 'SIGNAL' defined for FR signal '$FR_signal' in FR MAPPING", 109 );
                return;
            }
            $just_PDU_infos = 0;
        }
        if ( defined $fr_ignore_uBit )
        {
            $found_PDU = FR_trace_get_PDU_data( $fr_log_file, $FR_PDU, $fr_bus_nbr, $fr_ignore_uBit );
        }
        elsif ( defined $fr_bus_nbr )
        {
            $found_PDU = FR_trace_get_PDU_data( $fr_log_file, $FR_PDU, $fr_bus_nbr );
        }
        else
        {
            $found_PDU = FR_trace_get_PDU_data( $fr_log_file, $FR_PDU );
        }

        unless (%$found_PDU)
        {
            S_set_error( " FR_trace_get_dataref: PDU not found in the Trace ", 109 );
            next;
        }

        foreach my $time ( keys %$found_PDU )
        {
            my $FR_PDU_local      = $$found_PDU{$time}{'FR_PDU'};
            my $FR_PDU_Data_local = $$found_PDU{$time}{'DATA'};
            my $FR_PDU_DLC_1      = $$found_PDU{$time}{'DLC_1'};
            my $FR_PDU_DLC_2      = $$found_PDU{$time}{'DLC_2'};
            $ReturnDataRef->{$time}->{$FR_PDU_local}->{'DATA'}  = $FR_PDU_Data_local;
            $ReturnDataRef->{$time}->{$FR_PDU_local}->{'DLC_1'} = $FR_PDU_DLC_1;
            $ReturnDataRef->{$time}->{$FR_PDU_local}->{'DLC_2'} = $FR_PDU_DLC_2;
        }

        if ($just_PDU_infos)
        {
            # If only PDU is given, skip current iteration
            next;
        }
        $found_Signal = FR_trace_fr_get_signal_data( $found_PDU, $FR_signal, $data_format );

        unless (%$found_Signal)
        {
            S_set_error( " FR_trace_get_dataref: PDU not found in the Trace", 109 );
            next;
        }

        foreach my $time ( keys %$found_Signal )
        {
            my $FR_signal_Data_local = $$found_Signal{$time};
            $ReturnDataRef->{$time}->{$FR_signal} = $FR_signal_Data_local;
        }
    }
    return $ReturnDataRef;
}

######################################################################

=head2 FR_trace_fr_get_signal_data

    Function Name    :: FR_trace_fr_get_signal_data
    Description      :: extracts the data reference of FR signal. This function shall be called after FR_trace_get_PDU_data.
    Syntax           :: $found_Signal = FR_trace_fr_get_signal_data( $found_PDU,$FR_signal,$data_format);
    Input Arguments  :: $found_PDU - data reference of the PDU data
                        $FR_signal - FR signal whose data refernce needs to be extracted
                        $data_format - DEC or HEX
    Return Value(s)  :: $found_Signal - hash reference of the data of the required signals
    Example          :: $found_PDU = FR_trace_get_PDU_data ( $fr_trace_file , 'PreCrash_02');
                        $found_Signal = FR_trace_fr_get_signal_data( $found_PDU,['Blinken_li_Kombi_Takt','KY_HD_Entriegelung_Autorisiert' ],'DEC');

      $trace_data_ref = {
                        'timestamp_1' => {
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };

=cut

######################################################################

sub FR_trace_fr_get_signal_data
{
    my $found_PDU   = shift;
    my $FR_signal   = shift;
    my $data_format = shift;

    S_w2log( 4, " FR_trace_fr_get_signal_data: Extracts the data reference of FR signal $FR_signal\n" );

    unless ( defined($data_format) )
    {
        S_set_error( "FR_trace_fr_get_signal_data: SYNTAX: FR_trace_fr_get_signal_data ( found_PDU, FR_signal, data_format )", 110 );
        return;
    }

    my $found_signal = VEC_trace_fr_get_signal_data( $found_PDU, $FR_signal, $data_format );
    return $found_signal;
}

######################################################################

=head2 FR_set_invalidCRC

    Syntax          :: return_value = FR_set_invalidCRC (FR_PDU [,$method]);

=cut

######################################################################

sub FR_set_invalidCRC
{
    ## FR_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool
    S_w2log( 4, " FR_set_invalidCRC\n" );

    my ( $given_flexray_PDU, $method ) = @_;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( " Too Less Params ! PDU Name missing |  SYNTAX:  FR_set_DLC(flexray_PDU [ , method ])", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices, );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no FlexRay access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Could not configure devices for Flexray access write ", 131 );
            return;
        }
    }
    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_set_flxr_crc_error( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU, $method ) )
            {
                S_w2log( 3, " FR_set_invalidCRC : $given_flexray_PDU is set to CRC error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_set_invalidCRC : Could not create a CRC error for '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

######################################################################

=head2 FR_set_validCRC

    Syntax          :: return_value = FR_set_validCRC (flexray_PDU);

=cut

######################################################################

sub FR_set_validCRC
{
    ## FR_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool
    S_w2log( 4, " FR_set_validCRC\n" );

    my ( $given_flexray_PDU, $method ) = @_;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( "Too Less Params ! PDU Name missing |  SYNTAX:  FR_set_DLC(flexray_PDU)", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices, );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no Flexray access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Could not configure devices for Flexray access write ", 131 );
        }
        return;
    }
    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_reset_flxr_crc_error( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU, $method ) )
            {
                S_w2log( 3, " FR_set_validCRC : $given_flexray_PDU is removed from CRC error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_set_validCRC : Could not remove a CRC error for '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

######################################################################

=head2 FR_set_invalidBZ

    Syntax          :: return_value = FR_set_invalidBZ ( flexray_PDU [ , method  ]);

=cut

######################################################################

sub FR_set_invalidBZ
{
    ## FR_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool
    S_w2log( 4, " FR_set_invalidBZ\n" );

    my ( $given_flexray_PDU, $method ) = @_;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( " Too Less Params ! PDU Name missing |  SYNTAX:  FR_set_DLC(flexray_PDU [ , method ])", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices, );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no Flexray access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Could not configure devices for Flexray access write ", 131 );
            return;
        }
    }
    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" and not defined $return_value )
        {
            if ( $return_value = VEC_set_flxr_bz_error( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU, $method ) )
            {
                S_w2log( 3, " FR_set_invalidBZ : $given_flexray_PDU is set to BZ error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_set_invalidBZ : Could not create a BZ error for '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

######################################################################

=head2 FR_set_validBZ

    Syntax          :: return_value = FR_set_validBZ (flexray_PDU);

=cut

######################################################################

sub FR_set_validBZ
{
    ## FR_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool
    S_w2log( 5, " FR_set_validBZ\n" );

    my ( $given_flexray_PDU, $method ) = @_;

    unless ( defined $given_flexray_PDU )
    {
        S_set_error( "Too Less Params ! PDU Name missing |  SYNTAX:  FR_set_DLC(flexray_PDU)", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices, );

    unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no Flexray access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
        unless ( FR_write_configure() )
        {
            S_set_error( " Could not configure devices for Flexray access write ", 131 );
        }
        return;
    }
    foreach my $device ( @{ $FR_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_reset_flxr_bz_error( $FR_control->{'write'}{$device}{'OLE_handle'}, $given_flexray_PDU, $method ) )
            {
                S_w2log( 3, " FR_set_validBZ : $given_flexray_PDU is removed from BZ error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " FR_set_validBZ : Could not remove a BZ error for '$given_flexray_PDU' from $device\n", 131 );
                return;
            }
        }
    }
}

=head2 FR_init

    FR_init();

=cut

sub FR_init{
    
    my $functionAreas_href = VEC_init ( 'FlexRay_Access' );
    EQUIP_set_devices ( 'FlexRay_Access' , $functionAreas_href );

    my $funcLib_href = S_get_contents_of_hash( ['Functions', 'FlexRay_Access'], $LIFT_config::LIFT_Testbench );
    
    foreach my $functionGroup ( keys %{ $funcLib_href } ) {
        my $devices_mix = $funcLib_href->{$functionGroup};
        my $number_of_devices = 0;
        if( ref( $devices_mix ) eq 'ARRAY' ) {
            $number_of_devices = @{ $devices_mix };
        }
        elsif( ref( $devices_mix ) eq '' ){
            $number_of_devices = 1 if defined $devices_mix;
        }
        else{
            # do nothing
        }
        next if $number_of_devices == 0;
        
        if( $functionGroup eq 'read' ){
            FR_read_configure ( );
        }
        elsif( $functionGroup eq 'write' ){
            FR_write_configure ( );
        }
        elsif( $functionGroup eq 'trace' ){
            FR_trace_configure ( );
        }
        elsif( $functionGroup eq 'basic' ){
            FR_read_configure ( );
            FR_write_configure ( );
            FR_trace_configure ( );
            #FR_simulation_configure ( );
        }
        elsif( $functionGroup eq 'stimulate' ){
            #FR_stimulate_configure ( );
        }
        else{
            S_set_error( "Invalid function group '$functionGroup' for 'FlexRay_Access' in LIFT_Testbenches.pm. Valid function groups are: basic, stimulate ( or read, write, trace ).", 20 );
            return;
        }
    }
    
    return $functionAreas_href;
    
}

#not used functions
######################################################################

# =head2 FR_read_flxr_lamps (not tested)

# Function Name    :: FR_read_flxr_lamps
# Description      :: Read Flexray lamps from Flexray tool(s) which is/are configured in $LIFT_config->LIFT_ProjectDefaults->{'FLXR_PROJECT_LAMPS'}
# Syntax           :: \%flxr_lamps_hash = FR_read_flxr_lamps( );
# Input Arguments  :: none
# Return Value(s)  :: \%flxr_lamps_hash - hash reference for Flexray lamps
# Example          :: \%flxr_lamps_hash = FR_read_flxr_lamps( );
# (example of the returned hash reference sall be updated soon)

# =cut

######################################################################

# sub FR_read_flxr_lamps
# {
# my $flxr_lamps = {};
# my $flxr_lamp_value;

# unless( $LIFT_config::LIFT_ProjectDefaults->{'FLXR_PROJECT_LAMPS'} ) {
# S_set_error( "LIFT_config::LIFT_ProjectDefaults->{'FLXR_PROJECT_LAMPS'} not defined" , 0 );
# return;
# }

# return 1 if $main::opt_offline; # just return if running in offline mode

# foreach my $flxr_lamp ( @{$LIFT_config::LIFT_ProjectDefaults->{'FLXR_PROJECT_LAMPS'}} ) {
# ( $flxr_lamp_value ) = FR_read_flxr_signal( $flxr_lamp , 'phys' );
# $flxr_lamps->{$flxr_lamp} = $flxr_lamp_value;
# S_w2log( 4, " FR_read_flxr_lamps: $flxr_lamp -> $flxr_lamp_value \n");
# }
# return $flxr_lamps;
# }

######################################################################

# =head2 FR_disable_frame (check this function )

    # Function Name    :: FR_disable_frame
    # Description      :: disables the Flexray Frame sending
    # Syntax           :: $return_value = FR_disable_frame ( $given_fr_frame [ , $time_out_info ]);
    # Input Arguments  :: $given_fr_frame  - Flexray Frame name as used in LIFT FLXR mapping
                        # $time_out_info - additional info value which will be set in CAPL environment variable (eg: number of timeout cycles,time value)
    # Return Value(s)  :: $return_value
    # Example          :: $return_value = FR_disable_frame ( 'FR_FRAME' );

# =cut

######################################################################

# sub FR_disable_frame
# {
   # FR_write_configure have to called before
   # use out function VEC_disable_can_message() of LIFT_vector_cantool

   # my (
         # $given_fr_frame ,
         # $time_out_info ,
      # ) = @_;

   # unless( defined $given_fr_frame ) {
      # S_set_error( " SYNTAX: FR_disable_frame( FR_FRAME )", 110 );
      # return;
   # }
    # return 1 if $main::opt_offline; # just return if running in offline mode

   # my (
         # $dev ,
         # $return_value ,
         # $devices_text ,
         # @devices ,
       # ) ;

   # unless ( $dev = $FR_control->{'write'}{'Devices'}[0] ) {
      # S_set_error( " no FLXR access write configured , FR_disable_frame is calling FR_write_configure ... ", 0 );
      # unless( FR_write_configure() ) {
         # S_set_error( " Couldnt configure devices for FLXR access write ", 131 );
         # return;
      # }
   # }

   # foreach my $device( @{$FR_control->{'write'}{'Devices'}} )   {

      ### Calling CANoe Device
       # if( $device eq "CANoe" and not defined $return_value ) {

          # if ( $return_value = VEC_disable_can_message( $FR_control->{'write'}{$device}{'OLE_handle'} , $given_fr_frame , $time_out_info ) ) {
             # S_w2log( 3, " FR_disable_frame : $given_fr_frame disabled\n" );
             # return $return_value;
          # }
          # else {
             # S_w2log( 3, " FR_disable_frame : Couldnt disable '$given_fr_frame' from $device\n" );
          # }
       # }

      # try to write from <tobedefinedtool>
      # if( not defined $return_value and $device eq "any_other_tool" ) {

      # }

      # if( defined $return_value ) {
         # return $return_value;
      # }

      # push( @devices , $device );  ### just for error text

   # }

   # unless( $return_value ) {
      # bad case
      # $devices_text = join( " " , @devices );
      # S_set_error( " Couldnt disable FLXR frame on device : $devices_text \n" , 15 );
      # return;
   # }

# }

######################################################################

# =head2 FR_enable_frame (check this function)

    # Function Name    :: FR_enable_frame
    # Description      :: enables the Flexray Frame sending
    # Syntax           :: $return_value = FR_enable_frame ( $given_fr_frame );
    # Input Arguments  :: $given_fr_frame  - Flexray Frame name as used in LIFT FLXR mapping
    # Return Value(s)  :: $return_value
    # Example          :: $return_value = FR_enable_frame ( FR_FRAME );

# =cut

######################################################################

# sub FR_enable_frame
# {
   # FR_write_configure have to called before
   # use out function VEC_enable_can_message() of LIFT_vector_cantool

   # my (
         # $given_fr_frame ,
      # ) = @_;

   # unless( defined $given_fr_frame ) {
      # S_set_error( " SYNTAX: FR_enable_frame( FR_FRAME )", 110 );
      # return;
   # }

   # return 1 if $main::opt_offline; # just return if running in offline mode

   # my (
         # $dev ,
         # $return_value ,
         # $devices_text ,
         # @devices ,
       # ) ;

   # unless ( $dev = $FR_control->{'write'}{'Devices'}[0] ) {
      # S_set_error( " no FLXR access write configured , FR_enable_frame is calling FR_write_configure ... ", 0 );
      # unless( FR_write_configure() ) {
         # S_set_error( " Couldnt configure devices for FLXR access write ", 131 );
         # return;
      # }
   # }

   # foreach my $device( @{$FR_control->{'write'}{'Devices'}} )   {

      ### Calling CANoe Device
       # if( $device eq "CANoe" and not defined $return_value ) {
          # if ( $return_value = VEC_enable_can_message( $FR_control->{'write'}{$device}{'OLE_handle'} , $given_fr_frame ) ) {
             # S_w2log( 3, " FR_enable_frame : $given_fr_frame enabled\n" );
             # return $return_value;
          # }
          # else {
             # S_w2log( 3, " FR_enable_frame : Couldnt enable '$given_fr_frame' from $device\n" );
          # }
      # }

      # try to write from <tobedefinedtool>
      # if( not defined $return_value and $device eq "any_other_tool" ) {

      # }

      # if( defined $return_value ) {
         # return $return_value;
      # }

      # push( @devices , $device );  ### just for error text

   # }

   # unless( $return_value ) {
      # bad case
      # $devices_text = join( " " , @devices );
      # S_set_error( " Couldnt enable FLXR frame on device : $devices_text \n" , 15 );
      # return;
   # }

# }
######################################################################

# =head2 FR_start_communictaion (check this function)

    # Function Name    :: FR_start_communictaion
    # Description      :: starts the Flexray communication
    # Syntax           :: $return_value = FR_start_communictaion ( [ $time_out_info  ]);
    # Input Arguments  :: $time_out_info - additional info value which will be set in CAPL environment variable (eg: number of timeout cycles,time value)
    # Return Value(s)  :: $return_value
    # Example          :: $return_value = FR_start_communictaion ( );

# =cut

######################################################################

# sub FR_start_communictaion
 # {
   # FR_write_configure have to called before
   # use out function VEC_disable_flxr_message() of LIFT_vector_cantool

    # my $time_out_info = shift;

    # my ($dev, $return_value, $devices_text, @devices) ;

    # return 1 if $main::opt_offline; # just return if running in offline mode

    # unless ( $dev = $FR_control->{'write'}{'Devices'}[0] )
    # {
      # S_set_error( " no FlexRay access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
      # unless( FR_write_configure() )
      # {
         # S_set_error( " Could not configure devices for FlexRay access write ", 131 );
         # return;
      # }
   # }

   # foreach my $device( @{$FR_control->{'write'}{'Devices'}} )
   # {
      ### Calling CANoe Device
      # if( $device eq "CANoe" and not defined $return_value )
      # {
         # if ( $return_value = VEC_start_flxr_communication( $FR_control->{'write'}{$device}{'OLE_handle'} , $time_out_info ) )
         # {
            # S_w2log( 3, " FR_start_communictaion : start FlexRay communication\n" );
            # return $return_value;
         # }
         # else
         # {
            # S_set_error( " FR_start_communictaion : Could not start FlexRay coomunication from $device\n" ,5);
            # return;
         # }
      # }

      ## try to write from <tobedefinedtool>
      # if( not defined $return_value and $device eq "any_other_tool" ) {

      # }

      # if( defined $return_value ) {
         # return $return_value;
      # }

      # push( @devices , $device );  ### just for error text

   # }

   # unless( $return_value ) {
      # bad case
      # $devices_text = join( " " , @devices );
      # S_set_error( " Could not start FlexRay communication on device : $devices_text \n" , 15 );
      # return;
   # }

# }

######################################################################

# =head2 FR_stop_communictaion

    # Function Name    :: FR_stop_communictaion
    # Description      :: stops the Flexray communication
    # Syntax           :: $return_value = FR_stop_communictaion ( [ $time_out_info  ]);
    # Input Arguments  :: $time_out_info - additional info value which will be set in CAPL environment variable (eg: number of timeout cycles,time value)
    # Return Value(s)  :: $return_value
    # Example          :: $return_value = FR_stop_communictaion ( );

# =cut

######################################################################

# sub FR_stop_communictaion
# {
   ## FR_write_configure have to called before
   ## use out function VEC_disable_flxr_message() of LIFT_vector_cantool

   # my (
         # $time_out_info ,
      # ) = @_;


   # my (
         # $dev ,
         # $return_value ,
         # $devices_text ,
         # @devices ,
       # ) ;

       # return 1 if $main::opt_offline; # just return if running in offline mode

   # unless ( $dev = $FR_control->{'write'}{'Devices'}[0] ) {
      # S_set_error( " no FlexRay access write configured , FR_write_flxr_signal is calling FR_write_configure ... ", 0 );
      # unless( FR_write_configure() ) {
         # S_set_error( " Could not configure devices for FlexRay access write ", 131 );
         # return;
      # }
   # }

   # foreach my $device( @{$FR_control->{'write'}{'Devices'}} )   {

      ### Calling CANoe Device
      # if( $device eq "CANoe" and not defined $return_value ) {
         # if ( $return_value = VEC_stop_flxr_communication( $FR_control->{'write'}{$device}{'OLE_handle'} , $time_out_info ) ) {
            # S_w2log( 3, " FR_stop_communictaion : stop FlexRay communication\n" );
            # return $return_value;
         # }
         # else {
            # S_w2log( 3, " FR_stop_communictaion : Could not stop FlexRay coomunication from $device\n" );
         # }
      # }

      # try to write from <tobedefinedtool>
      # if( not defined $return_value and $device eq "any_other_tool" ) {

      # }

      # if( defined $return_value ) {
         # return $return_value;
      # }

      # push( @devices , $device );  ### just for error text

   # }

   # unless( $return_value ) {
      # bad case
      # $devices_text = join( " " , @devices );
      # S_set_error( " Could not stop FlexRay communication on device : $devices_text \n" , 15 );
      # return;
   # }

# }
######################################################################

# =head2 FR_trace_get_dataref_ASCII

    # Function Name    :: FR_trace_get_dataref_ASCII
    # Description      :: Returns the hash refernce of data of both signals and messages from trace file.
                        # Reads a trace file $data_file_name (converts it into ASCII) and writes the data
                        # of all signals of @LABELLIST into a hash-tree and returns the reference
                        # to that hash-tree. 
    # Syntax           :: $all_signals = FR_trace_get_dataref_ASCII ( $data_file_name , @label_list );
    # Input Arguments  :: $store_file_name - Logfile name . If no store_file_name given the Flexray trace will be stored in Testdocumentation
    # Return Value(s)  :: $returned_trace_file_name - returned trace name
                        # $returned_flxr_signals_file_name - returned signals file name 
    # Example          :: $all_signals = FR_trace_get_dataref_ASCII ( data_file_name , label_list );

    # Structure of returned trace_data_ref is:
    
    # $all_signals = {
                        # 'timestamp_1' => {
                                       # 'message_A' => 'DLC_A1' ,
                                       # 'signal_1' => 'phys_value_at_time_1',
                                       # 'signal_2' => 'phys_value_at_time_1',
                                       # 'message_B' => 'DLC_B1' ,
                                       # 'signal_3' => 'phys_value_at_time_1',
                                          # },
                        # 'timestamp_2' => {
                                       # 'message_A' => 'DLC_A2' ,
                                       # 'signal_1' => 'phys_value_at_time_2',
                                       # 'signal_2' => 'phys_value_at_time_2',
                                       # 'message_B' => 'DLC_B2' ,
                                       # 'signal_3' => 'phys_value_at_time_2',
                                          # },
                     # };


   # For evaluation this hash can be sorted via
   
      # foreach $ascending_sorted_timestamp ( keys sort { $a <=> $b } %$all_signals  ) { 
         # what you want to evaluate
      # }
   
   # (Note: for numerical descending just use { $b <=> $a } )
      
   # or you can use the functions provided in LIFT_evaluation package, e.g.
   
      # use LIFT_evaluation;
      # EVAL_get_time_when
      # EVAL_get_values_at_time
      # EVAL_get_values_over_time
      # EVAL_evaluate_values_at_time
      # EVAL_evaluate_values_in_trace

      # <Note : This is the original FR_trace_get_dataref which was ported from STEPS, currently not in use.>

# =cut

######################################################################

# sub FR_trace_get_dataref_ASCII
# {
    # my $data_file_name = shift ;
    # my @label_list = @_;

   # return without doing if no FlexRay_Access trace configured
   # return 1 unless  EQUIP_get_devices( 'FlexRay_Access' , 'trace' );

    # my ($data_ref, $device);

    # unless(scalar @label_list ) {
        # S_set_error( " SYNTAX: FR_trace_get_dataref_ASCII ( data_file_name , label_list )", 110 );
        # return 0;
    # }

    # unless ( $device = $FR_control->{'trace'}{'Devices'}[0] ) {
        # S_set_error( " FR_trace_get_dataref_ASCII : no trace configured , use FR_trace_configure() before", 131 );
        # return;
    # }

    # if( $device eq "CANoe" or $device eq "CANalyzer" ) {
        # unless ( $data_ref = VEC_trace_flxr_get_dataref( $FR_control->{'trace'}{$device}{'OLE_handle'} , $device , $data_file_name , @label_list ) ) {
            # S_set_error( " FR_trace_get_dataref_ASCII : Could not get data structure for $data_file_name", 131 );
            # return;
        # }
    # }
    # else {
       # S_set_error( " FR_trace_get_dataref_ASCII : Device $device can only be 'CANoe' or 'CANalyzer'", 110 );
       # return;
    # }

    # return $data_ref;
# }

######################################################################

# =head2 FR_enable_safecomm_Flexray

    # FR_enable_safecomm_Flexray (\%SafeComm_signals);

    # Safecomm signal manipulations will be processed. Module uses Global trigger for its functionality.  

    # $SafeComm_signals => {
                        # 'Signalname1' => {
                                            # 'Manipulation_data' => {
                                                                      # 'Manip_cycles' => '4',
                                                                      # 'Manip_mode' => '',
                                                                      # 'Manip_value' => '5',
                                                                      # 'Manip_offset' => '2',
                                                                   # },
                                             # 'Trigger_data' => {
                                                                  # 'Trigger_id' => '3',
                                                                  # 'Manipulation_time_sec' => '4',
                                                                  # 'Delay_time_sec' => '2',
                                                                  # 'Trigger_mode' => '1' ,
                                                                  # 'Event_operand1' => '1',
                                                                  # 'Event_operand2' => '2',
                                                                  # 'Event_constant_value' => '2',
                                                                  # 'Event_operator' => '2',
                                                                  # 'Logic_operand1' => '2',
                                                                  # 'Logic_operand2' => '2',
                                                                  # 'Logic_operand3' => '2',
                                                                  # 'Logic_operator1' => '3',
                                                                  # 'Logic_operator2' => '3',
                                                                  # 'Sequence_condition1' => '1',
                                                                  # 'Sequence_condition2' => '1',
                                                                  # 'Sequence_condition3' => '1',
                                                                  # 'Sequence_condition4' => '1',
                                                                  # 'Sequence_condition5' => '1',
                                                               # },                      
                                         # },
                        # 'Signalname2' => {
                                         # }
                     # }

# =cut

###################################################################

# sub FR_enable_safecomm_Flexray {

    # my $SafeComm_signals = shift;
    # my $result;

   # no strict 'subs';
    # unless ( ref( $SafeComm_signals) eq HASH ) {
        # S_set_error( " parameter error ! given parameter of SafeComm signal data IS NOT a HASH REFERENCE", 110 );
        # return 0;
    # }

    # foreach my $signal ( keys %{$SafeComm_signals}) {

        # my $Manipulation_data = $SafeComm_signals->{$signal}{'Manip_data'};
        # my $Trigger_data = $SafeComm_signals->{$signal}{'Trig_data'};

        # S_w2log( 3, " FR_enable_safecomm_Flexray : Set manipulation data for signal $signal\n" );
        # LC_set_signal("pl_manipul_SEND_".$signal."_b.FR_NM.FR_Node_1",1);

        # if (  my $Number_Of_Manip_cycles = $Manipulation_data->{'Manip_cycles'}){
               # LC_set_signal("pl_dyn_quantity_SEND_".$signal."_ud.FR_NM.FR_Node_1",$Number_Of_Manip_cycles);
          # }

        # if ( my $Manip_Value = $Manipulation_data->{'Manip_value'}){
               # LC_set_signal("pl_dyn_value_SEND_".$signal."_ud.FR_NM.FR_Node_1",$Manip_Value);
          # }

          # if ( my $Manip_Offset = $Manipulation_data->{'Manip_offset'}){
               # LC_set_signal("pl_offset_SEND_".$signal."_ud.FR_NM.FR_Node_1",$Manip_Offset);
          # }

          # if (my $triggerID = $Trigger_data->{'Trigger_id'}) {
              # LC_set_signal("pl_triggerID_modus_SEND_".$signal."_ud.FR_NM.FR_Node_1",$triggerID);
          # }

          # if (my $Manipulation_mode = $Manipulation_data->{'Manip_mode'}) {
              # LC_set_signal("pl_modus_SEND_".$signal."_ud.FR_NM.FR_Node_1",$Manipulation_mode);
          # }

          # S_w2log( 3, " FR_enable_safecomm_Flexray : Set Global Trigger data for signal $signal\n" );
          # unless (LC_set_globaltrigger($Trigger_data)) {
            # S_set_error( " FR_enable_safecomm_Flexray : Unable to set Global Trigger for signal $signal!!!\n", 114 );
            # return 0;
        # }

    # }

# }

######################################################################

# =head2 FR_evaluate_flxr_lamps

    # Function Name    :: FR_evaluate_flxr_lamps
    # Description      :: Does a FR_check_flxr_lamps(\%STATE_MEASURED,\%STATE_EXPECTED).
                        # If the result is 1 then the verdict VERDICT_PASS is set and returned.
                        # Otherwise the verdict VERDICT_FAIL is set and returned.
                        # If the parameters are not correct then VERDICT_INCONC is set and returned.
    # Syntax           :: $VERDICT = FR_evaluate_flxr_lamps ( \%STATE_MEASURED , \%STATE_EXPECTED );
    # Input Arguments  :: \%STATE_MEASURED - measured state of the Flexray lamp
                        # \%STATE_EXPECTED - expected state of the Flexray lamp 
    # Return Value(s)  :: $VERDICT - Verdict
    # Example          :: $VERDICT = FR_evaluate_flxr_lamps ( \%STATE_MEASURED , \%STATE_EXPECTED );

# =cut

######################################################################

# sub FR_evaluate_flxr_lamps {
    # my $state_lamps = shift;
    # my $lamps_expected = shift;

    # unless ( defined $lamps_expected ) { # if less than 2 parameters: set error
        # S_set_error( " too less parameters ! FR_evaluate_flxr_lamps (\%detected_lamps ,\%expected_lamps) ", 110 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }

    # if( $main::opt_offline ) { S_set_verdict(VERDICT_PASS); return 1; }

    # no strict 'subs';                        # needed to check the reference type
    # unless ( ref( $state_lamps) eq HASH ) {
        # S_set_error( " parameter error ! given parameter of detected lamps IS NOT a HASH REFERENCE", 114 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }
    # unless ( ref( $lamps_expected) eq HASH ) {
        # S_set_error( " parameter error ! given parameter of expected lamps IS NOT a HASH REFERENCE", 114 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }

     ## CALL check lamps function
     # my ( $result ,
          # $expected_lamp_eval_text ,
          # $detected_lamp_eval_text
        # ) = FR_check_flxr_lamps( $state_lamps, $lamps_expected , 'get_text' );

   ### ---- for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell ----
    # my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    # my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    # S_add2eval_collection( 'FLXR_LAMPS' , $expect_marker.$expected_lamp_eval_text );
    # S_add2eval_collection( 'FLXR_LAMPS' , $detect_marker.$detected_lamp_eval_text );
   ### ----------------------------------------------------------------------------------------

    # if ( $result ) {
       # my $pass_text=<<EOPASS;
# FR_evaluate_flxr_lamps ==> expected result
  # $expect_marker: $expected_lamp_eval_text
  # $detect_marker: $detected_lamp_eval_text
# EOPASS
       # S_w2rep( $pass_text );
       # S_set_verdict( VERDICT_PASS );
       # return VERDICT_PASS;
    # }
    # else {
       # my $fail_text=<<EOFAIL;
# FR_evaluate_flxr_lamps ==> FAIL, not expected result
  # $expect_marker: $expected_lamp_eval_text
  # $detect_marker: $detected_lamp_eval_text
# EOFAIL
       # S_w2rep( $fail_text );
       # S_set_verdict(VERDICT_FAIL);
       # S_add2eval_collection( 'MISMATCH' , 'FLXR_LAMPS' );
       # return VERDICT_FAIL;
    # }
# }
#####################################################################

# =head2 FR_check_flxr_lamps

    # Function Name    :: FR_check_flxr_lamps
    # Description      :: Checks if the values in \%STATE_MEASURED are equal to the corresponding values in \%STATE_EXPECTED. If so $RESULT will be 1, otherwise 0.
                        # Note that all keys in \%STATE_EXPECTED must also exist in \%STATE_MEASURED,but \%STATE_MEASURED could have more keys.
                        # If \%STATE_EXPECTED contains 'FLXR_LAMP_STRATEGY' as key, the lamp behaviour will be taken form PROJECT DEFAULTS 'FLXR_LAMP_STRATEGY'.
    # Syntax           :: ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line ) = FR_check_flxr_lamps ( $result_ref , $expected_ref , $get_text_option );
    # Input Arguments  ::$result_ref - 
                       # $expected_ref -
                       # $get_text_option -
    # Return Value(s)  :: $VERDICT - Verdict
    # Example          :: ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line ) = FR_check_flxr_lamps ( $result_ref , $expected_ref , $get_text_option );                

# =cut

######################################################################

# sub FR_check_flxr_lamps
# {
    # could perhaps be replaced by "if (%result eq %expected) {...}
    # my $result_ref = shift;
    # my $expected_ref = shift;
    # my $get_text_option = shift;

    # my $fault_flag;
    # my ($lamp_res_expect, $lamp_res_detect , $real_lamp );
    # my $strategy_key = "FLXR_LAMP_STRATEGY"; # key for mapping of expected lamps

    # unless (defined( $expected_ref )) {
           # HERE YOU COULD CHOOSE A DEFAULT ARRAY !
        # S_set_error( '! too less parameters ! SYNTAX: FR_check_flxr_lamps(\%result,\%expected)', 110 );
        # return 0;
    # }

   # check if a mapping of lamps is recommendet
   # if (defined $expected_ref->{$strategy_key}) {
  # S_w2log( 5, "found STRATEGY: ".$expected_ref->{$strategy_key}.", trying to map it\n" );

       # check if strategy is defined in Project defaults
        # if( exists $main::ProjectDefaults->{'FLXR_LAMP_STRATEGY'}{ $expected_ref->{$strategy_key} } ) {
            # map strategy to expected lamp behavoiur
            # S_w2log( 3, "  => expected lamps found in ProjectDefaults->{'FLXR_LAMP_STRATEGY'}{".$expected_ref->{$strategy_key}."}\n" );
            # %$expected_ref = %{$main::ProjectDefaults->{'FLXR_LAMP_STRATEGY'}{ $expected_ref->{$strategy_key} } };
        # }
        # else { S_set_error( "FLXR lamp mapping failed for strategy ".$expected_ref->{$strategy_key}, 20); }
   # }
  # else {S_w2log( 3, "no STRATEGY found, using lamps directly\n" );}

   # my $expected_lamp_eval_line;
   # my $detected_lamp_eval_line;

   # $fault_flag = 1;
   ## ----------------------------------------------------------------------------------------
   # step through whole hash %expected
   # foreach my $lamp ( sort keys %$expected_ref) {

       # $lamp_res_expect = $expected_ref->{$lamp};

       # if( $real_lamp = $main::ProjectDefaults->{'LABEL_MAPPING'}{$lamp} ) {
           # S_w2log( 5, " FR_check_flxr_lamps : $lamp (mapped) is $real_lamp (real) (out of LABEL_MAPPING) \n" );
           # $lamp = $real_lamp;
       # }

       # unless( exists $result_ref->{$lamp} ) {
           # S_set_error( " FR_check_flxr_lamps : Expected lamp '$lamp' not in given lamps results \n", 0 );
           # $fault_flag = 0;
           # next;
       # }

       # $expected_lamp_eval_line .= " $lamp -> $lamp_res_expect";

       # $lamp_res_detect = $result_ref->{$lamp};
       # $detected_lamp_eval_line .= " $lamp -> $lamp_res_detect";


       # if lamp state in result differs from lamp state in expected, delete fault flag
       # if ( $lamp_res_expect eq $lamp_res_detect ) {
          # S_w2log( 4, " FR_check_flxr_lamps: $lamp is $lamp_res_detect => expected state\n" );
       # }
       # else {
          # S_w2log( 4, " FR_check_flxr_lamps: $lamp is $lamp_res_detect => FAIL, not expected state ($lamp_res_expect)\n" );
          # $fault_flag = 0;
       # }
    # }

    ## ----------------------------------------------------------------------------------------

     # if ( $get_text_option =~ /get_text/i ) {
         # return ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line);
    # } else {
         # return $fault_flag;
    # }
# }

1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut 
