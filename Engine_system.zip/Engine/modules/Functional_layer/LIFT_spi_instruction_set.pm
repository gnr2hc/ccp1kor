# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_spi_instruction_set;
use strict;
use warnings;
use LIFT_general;
use LIFT_spi_database;
use Data::Dumper;
use XML::LibXML;
use Readonly;
our ( $VERSION, $HEADER );

Readonly::Scalar my $MAX_PARALLEL_MANIPULATIONS => 12;
Readonly::Scalar my $MAX_PRE_TRIGGER_MODULES    => 4;

=head1 NAME: LIFT_spi_instruction_set

LIFT_spi_instruction_set 

=head1 DESCRIPTION

    This package provides the SPI Instruction set functions.

=head1 SYNOPSIS

    use LIFT_spi_instruction_set;

    LIFT_spi_instruction_set -> new();
    GetSignalManipulationList();              #not implemented
    GetUsedManipulationModules();
    AddSignalManipulation();
    DownloadInstructionSetToManitoo();

=head2 new

    $spiInstructionSet_object = LIFT_spi_instruction_set -> new( $spiDatabase_Object );

B<Description:> Instances a new object of spi instruction set class.

B<Arguments:>

=over

=item $spiDatabase_Object

SPI Data base object has to initialised first.

=back

B<Return Value:>

=over

=item $spiInstructionSet_object 

Returns the blessed (instanced) instruction set object. Returns nothing if missing mandatory parameter.

B<Example:>

    $spiInstructionSet_object = LIFT_spi_instruction_set->new($spiDatabase_Object);

=cut

#------------------------ Constructor ------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $class = shift;    # reference to class
    my $self  = {
        SignalManipulationList         => [],
        UsedManipulationModules        => [],
        MaxNumberParallelManipulations => $MAX_PARALLEL_MANIPULATIONS,
        PreTriggerModuleList           => [],
        MaxNumberPreTriggerModules     => $MAX_PRE_TRIGGER_MODULES,
        UniqueMosiFrame                => {},
    };
    bless $self, $class;

    # object $self is attached to the class $class
    return $self;
}
###############################################################################

=head2 GetSignalManipulationList

    $spiInstructionSet_object -> GetSignalManipulationList();

 
B<Description:>  Provides list of signal manipulation list. spiInstructionSet_object has to be initilised before calling.

B<Arguments:> None.

B<Return Value:>

A list of signal manipulation list:

B<Verdict:> none

=cut

#-------------------------------------------------------------------------------
sub GetSignalManipulationList {

    #-------------------------------------------------------------------------------
    my $self = shift;
    return $self->{SignalManipulationList};
}

###############################################################################

=head2 GetUsedManipulationModules

    ($status, $usedManipulationModules_aref) =  $spiInstructionSet_object -> GetUsedManipulationModules();

 
B<Description:>  Provides content of class Member 'UsedManipulationModules' list of used Manipulation modules ( 0, 1, 2, .. )  after call of DownloadInstructionSetToManitoo()

B<Arguments:> None.

B<Return Value:>
    $status -> 1  success
    $usedManipulationModules_aref -> [ 0, 1, 2, ...]   success


    $status -> 0  error
    $usedManipulationModules_aref -> [ ]   error
    

B<Verdict:> none

=cut

#-------------------------------------------------------------------------------
sub GetUsedManipulationModules {

    #-------------------------------------------------------------------------------
    my $self = shift;

    my $usedManipulationModules_aref = $self->{UsedManipulationModules};
    unless ( defined $usedManipulationModules_aref ) {
        S_set_error(" Attribut 'UsedManipulationModules' have not been set - Method to be called after DownloadInstructionSetToManitoo()");
        return ( 0, [] );
    }
    my $print_list_text = join( " , ", @$usedManipulationModules_aref );

    S_w2log( 4, " GetUsedManipulationModules : Returning used Modules [ $print_list_text ]\n" );

    return ( 1, $usedManipulationModules_aref );
}

###############################################################################

=head2 AddSignalManipulation

    $spiInstructionSet_object->AddSignalManipulation( $nodeName, [,$smi7moduleNbr, $smi7page, $commandName, $signalName, $values_aref, $valueDataSamples_href, $cs, $frames_aref, $spiNbr, $triggerMaskHex, $triggerMaskValue, $signalMaskHex]);

B<Description:> This function adds the Signal to be manipulated to the instruction set. spiInstructionSet_object has to be initilised before calling

B<Arguments:>

=over

=item $nodeName

Name of the node to which the signal belongs.

=item $smi7moduleNbr

( optional ) SMI7 module number which has to be configured in Mapping_SPI.pm file.(SMI7 specific).

=item $smi7page

( optional ) SMI7 page number which has to be configured in Mapping_SPI.pm file.(SMI7 specific).

=item $commandName

( optional ) Command name to which the signal belongs.

=item $signalName

( optional ) Name of the signal.

=item $values_aref

( optional ) Array reference which contains the list of signal values.

=item $valueDataSamples_href

( optional ) Hash reference which contains the pairs of time(hash key) & signal value( hash value).

=item $cs

( optional ) Chip select selection.

=item $frames_aref

( optional ) Array reference contains list of frames.


=item $spiNbr

( optional ) Spi channel number.

=item $triggerMaskHex

( optional ) Mask for the trigger command.

=item $triggerMaskValue

( optional ) Mask value of the trigger command.

=item $signalMaskHex

( optional ) Mask for the signal.

=back

B<Return Value:>

Returns the manipulation module on success and 'undef' on error.

B<Examples:>

    $spiInstructionSet_object->AddSignalManipulation(
      'Node'              => 'SMI7xx',
      'SMI7_Module'       => 4,
      'SMI7_Page'         => 2,
      'Command'           => 'MODULE_COMMAND',
      'Signal'            => 'CRC',
      'SignalValues'      => [4, 5, 6],
      'FrameCycles'       => [12, 13, 14],
      'SPIBusNbr'         => 1
      'TriggerMask'       => 'FFC00000'
      'TriggerValue'      => '70000000'
      'SignalMask'        => 7);

=cut

#-------------------------------------------------------------------------------
sub AddSignalManipulation {
    my @args                  = @_;
    my $self                  = shift @args;
    my $params                = {@args};
    my $nodeName              = $params->{'Node'};
    my $smi7module            = $params->{'SMI7_Module'};
    my $smi7page              = $params->{'SMI7_Page'};
    my $commandName           = $params->{'Command'};
    my $signalName            = $params->{'Signal'};
    my $values_aref           = $params->{'SignalValues'};
    my $frames_aref           = $params->{'FrameCycles'};
    my $valueDataSamples_href = $params->{'SignalTimesValues'};
    my $cs                    = $params->{'ChipSelect'};
    my $spiNbr                = $params->{'SPIBusNbr'};
    my $triggerMaskHex        = $params->{'TriggerMask'};
    my $triggerMaskValue      = $params->{'TriggerValue'};
    my $signalMaskHex         = $params->{'SignalMask'};
    my $preTriggers_aref      = $params->{'PreTriggers'};
    my $crashData_aref        = $params->{'CrashData'};

    return
      unless S_checkFunctionArguments( 'AddSignalManipulation ( $nodeName,  [$commandName, $signalName, $smi7module, $smi7page, $values_aref, $valueDataSamples_href])', ( $nodeName, $commandName, $signalName, $smi7module, $smi7page, $values_aref, $valueDataSamples_href ) );

    if ( not defined $commandName ) {
        if ( $triggerMaskHex !~ /^[0]+$/ or $triggerMaskValue !~ /^[0]+$/ ) {
            S_set_error( "No command name given but trigger mask or trigger value is not zero!", 109 );
            return;
        }
    }
    if ( defined $values_aref and defined $valueDataSamples_href ) {
        S_set_error( "Parameters 'SignalValues' and 'SignalTimesValues' can't be defined both! Manipulation unclear.", 109 );
        return;
    }
    elsif ( not defined $values_aref and not defined $valueDataSamples_href and not defined $crashData_aref ) {
        S_set_error( "No value defined for stimulation. Give either 'SignalValues' or 'SignalTimesValues'", 109 );
        return;
    }
    my $numberOfManipulations = @{ $self->{'SignalManipulationList'} };
    if ( $numberOfManipulations == $self->{'MaxNumberParallelManipulations'} ) {
        S_set_error("No further manipulations allowed in this instruction set. Nothing will be done.");
        return;
    }

    my $unique_node_mosi_frame = $commandName . $nodeName;
    if ( exists $self->{'UniqueMosiFrame'}{$unique_node_mosi_frame} ) {
        S_set_error( "Command '$commandName' already exists in manipulation module '$numberOfManipulations'. Same command can not be used with two different manipulation modules.", 109 );
        return;
    }
    else {
        $self->{'UniqueMosiFrame'}{$unique_node_mosi_frame} = "$commandName";
    }

    my $signalManipulation = Manipulation_Module->new( $nodeName, $commandName, $signalName );
    if ( defined $signalManipulation ) {
        push( @{ $self->{'SignalManipulationList'} }, $signalManipulation );
    }

    # A) Trigger configuration
    # Set network details for node
    $signalManipulation->SetNodeChipSelect($cs);
    $signalManipulation->SetNodeSPINbr($spiNbr);

    # SMI7 details
    $signalManipulation->SetSMI7Module($smi7module);
    $signalManipulation->SetSMI7Page($smi7page);

    # Set trigger mask and value
    $signalManipulation->SetTriggerMask($triggerMaskHex);
    $signalManipulation->SetTriggerValue($triggerMaskValue);

    # Set pre triggers
    if ( defined $preTriggers_aref ) {
        my $preTriggerList = $self->{PreTriggerModuleList};
        my $preTriggerNamesNumbers_href;
        foreach my $preTriggerObject ( @{$preTriggerList} ) {
            my $thisPreTriggerName = $preTriggerObject->GetPreTriggerName();
            $preTriggerNamesNumbers_href->{$thisPreTriggerName} = $preTriggerObject->GetPreTriggerNbr();
        }

        #GetPreTriggerName
        my $preTriggerNbrs_aref;
        foreach my $preTrigger ( @{$preTriggers_aref} ) {

            # check if pretrigger with this name exists
            if ( not defined $preTriggerNamesNumbers_href->{$preTrigger} ) {
                S_set_error( "AddSignalManipulation: Given pre trigger '$preTrigger' not defined. Load Pre Trigger first!", 110 );
                return;
            }
            else {
                push( @{$preTriggerNbrs_aref}, $preTriggerNamesNumbers_href->{$preTrigger} );
            }
        }
        $signalManipulation->SetPreTriggerNumbers($preTriggerNbrs_aref);
    }

    # B) Write configuration

    unless ($crashData_aref) {

        # Set signal mask
        $signalManipulation->SetWriteMask($signalMaskHex);

        # Set signal values / times / frames
        if ( defined $values_aref and defined $frames_aref ) {
            my $setValueSuccess = $signalManipulation->SetValues($values_aref);
            unless ($setValueSuccess) {
                pop( @{ $self->{'SignalManipulationList'} } );
                return;
            }
            $signalManipulation->SetFrames($frames_aref);
        }
        elsif ( defined $valueDataSamples_href ) {
            my ( $compressedValues, $times_aref ) = _extractValuesAndTimes($valueDataSamples_href);
            my $setValueSuccess = $signalManipulation->SetValues($compressedValues);
            unless ($setValueSuccess) {
                pop( @{ $self->{'SignalManipulationList'} } );
                return;
            }
            $signalManipulation->SetTimes($times_aref);
        }
    }
    if ($crashData_aref) {
        $signalManipulation->SetCrashData($crashData_aref);
    }

    return $signalManipulation;
}
###############################################################################

=head2 AddPreTriggerModule

    $spiInstructionSet_object->AddPreTriggerModule( $nodeName, [,$smi7moduleNbr, $smi7page, $commandName, $signalName, $values_aref, $valueDataSamples_href, $cs, $frames_aref, $spiNbr, $triggerMaskHex, $triggerMaskValue, $signalMaskHex]);

B<Description:> This function adds the Signal to be manipulated to the instruction set. spiInstructionSet_object has to be initilised before calling

B<Arguments:>

=over

=item $nodeName

Name of the node to which the signal belongs.

=item $commandName

( optional ) Command name to which the signal belongs.

=item $cs

( optional ) Chip select selection.

=item $spiNbr

( optional ) Spi channel number.

=item $triggerMaskHex

( optional ) Mask for the trigger command.

=item $triggerMaskValue

( optional ) Mask value of the trigger command.

=back

B<Return Value:>

Returns the manipulation module on success and 'undef' on error.

B<Examples:>

    $spiInstructionSet_object-> AddPreTriggerModule(
      'PT_Node'              => 'SMI7xx',
      'PT_Command'           => 'MODULE_COMMAND',
      'PT_TriggerMask'       => 'FFC00000'
      'PT_TriggerValue'      => '70000000'
      'PT_ActiveTime_us'        => 7,
      'PT_ChipSelect' => 2,
      'PT_SPIBusNbr' => 1);

=cut

#-------------------------------------------------------------------------------
sub AddPreTriggerModule {
    my @args                = @_;
    my $self                = shift @args;
    my $params              = {@args};
    my $pt_nodeName         = $params->{'PT_Node'};
    my $pt_commandName      = $params->{'PT_Command'};
    my $pt_signalName       = $params->{'PT_Signal'};
    my $pt_cs               = $params->{'PT_ChipSelect'};
    my $pt_spiNbr           = $params->{'PT_SPIBusNbr'};
    my $pt_triggerMaskHex   = $params->{'PT_TriggerMask'};
    my $pt_triggerMaskValue = $params->{'PT_TriggerValue'};
    my $pt_activeTime_us    = $params->{'PT_ActiveTime_us'};
    return unless S_checkFunctionArguments( 'AddPreTriggerModule ( $pt_nodeName,  [$pt_commandName])', ( $pt_nodeName, $pt_commandName ) );

    if ( not defined $pt_commandName ) {
        if ( $pt_triggerMaskHex !~ /^[0]+$/ or $pt_triggerMaskValue !~ /^[0]+$/ ) {
            S_set_error("No command name given but trigger mask or trigger value is not zero!");
            return;
        }
    }
    my $numberOfPreTriggerModules = @{ $self->{'PreTriggerModuleList'} };
    if ( $numberOfPreTriggerModules == $self->{'MaxNumberPreTriggerModules'} ) {
        S_set_error("No further pre trigger modules allowed in this instruction set. Nothing will be done.");
        return;
    }
    my $pt_Number = $numberOfPreTriggerModules;                                                                   # number of next PT module as counting starts from zero
    my $preTriggerModule = PreTrigger_Module->new( $pt_Number, $pt_nodeName, $pt_commandName, $pt_signalName );
    if ( defined $preTriggerModule ) {
        push( @{ $self->{'PreTriggerModuleList'} }, $preTriggerModule );
    }

    # A) Pre trigger configuration
    # Set network details for node
    $preTriggerModule->SetNodeChipSelect($pt_cs);
    $preTriggerModule->SetNodeSPINbr($pt_spiNbr);

    # Set trigger mask and value
    $preTriggerModule->SetTriggerMask($pt_triggerMaskHex);
    $preTriggerModule->SetTriggerValue($pt_triggerMaskValue);

    # Set pretrigger active time
    $preTriggerModule->SetActiveTime($pt_activeTime_us);
    return $preTriggerModule;
}
###############################################################################

=head2 DownloadInstructionSetToManitoo

    $spiInstructionSet_object->DownloadInstructionSetToManitoo();

B<Description:> This function Downloads the instructions set to the ManiToo.
Initialize the list of used Manipulation modules ( 0, 1, 2, .. ) Class Member 'UsedManipulationModules'    (aref)

B<Note:> All the instruction of the signal has to be loaded before calling this function. spiInstructionSet_object has to be initilised before calling

B<Arguments:> None

B<Return Value:> Returns 1 on success and 'undef' on error.

B<Example:>

     $spiInstructionSet_object->DownloadInstructionSetToManitoo();

=cut

sub DownloadInstructionSetToManitoo {

    #-------------------------------------------------------------------------------
    my $self                        = shift;
    my $signalManipulationList_aref = $self->{SignalManipulationList};
    my $error_flag                  = 0;
    my $manipulationModuleNbr       = 0;
    my $usedManipulationModules     = [];
    foreach my $signalManipulation ( @{$signalManipulationList_aref} ) {

        #collect return value from DownloadSignalManipulationToManitoo and check for success
        my ( $statusTrigger, $statusWrite ) = $signalManipulation->DownloadSignalManipulationToManitoo($manipulationModuleNbr);
        unless ($statusTrigger) {
            S_set_error("Loading Trigger configuration to ManiToo failed");
            $error_flag = 1;
        }
        unless ($statusWrite) {
            S_set_error("Loading Write configuration to ManiToo failed");
            $error_flag = 1;
        }
        push( @$usedManipulationModules, $manipulationModuleNbr );
        $manipulationModuleNbr++;
        return if ($error_flag);
    }
    my $preTriggerModules_aref = $self->{PreTriggerModuleList};
    my $preTriggerModuleNbr    = 0;
    foreach my $preTriggerModule ( @{$preTriggerModules_aref} ) {
        my $statusTrigger = $preTriggerModule->DownloadPreTriggerToManitoo($preTriggerModuleNbr);
        unless ($statusTrigger) {
            S_set_error("Loading Pretrigger configuration to ManiToo failed");
            $error_flag = 1;
        }
        $preTriggerModuleNbr++;
        return if ($error_flag);
    }

    $self->{'UsedManipulationModules'} = $usedManipulationModules;

    return 1;
}

# The function _extractValuesAndFrames is removed as the input format for SPI mode is changed as per the
# Story 29274.
# internal function
sub _extractValuesAndTimes {

    #-------------------------------------------------------------------------------
    my $dataSamples_href = shift;
    return unless S_checkFunctionArguments( '_extractValuesAndTimes ( $dataSamples_href )', ($dataSamples_href) );
    my ( $values_aref, $times_aref );
    my $previousTimeStamp;
    foreach my $timeStamp ( sort { $a <=> $b } keys %{$dataSamples_href} ) {
        if ( not defined $previousTimeStamp ) {
            $previousTimeStamp = $timeStamp;
            next;
        }
        push( @{$values_aref}, $dataSamples_href->{$previousTimeStamp} );
        push( @{$times_aref},  $timeStamp - $previousTimeStamp );
        $previousTimeStamp = $timeStamp;
    }
    if ( $dataSamples_href->{$previousTimeStamp} eq 'stop_manipulation' ) {
        S_w2log( 4, "Nothing to do..." );
    }
    else {
        S_w2log( 2, "Last value will be manipulated until stimulation stop" );
        push( @{$values_aref}, $dataSamples_href->{$previousTimeStamp} );
        push( @{$times_aref},  0 );                                         # manipulate last value for rest of manipulation time
    }
    return ( $values_aref, $times_aref );
}

=head2 DESTROY

    $spiInstructionSet_object->DESTROY();

B<Description:> This function destroys instructions set object initialised.

B<Arguments:> None

B<Return Value:> Returns 1 on success.

B<Example:>

     $spiInstructionSet_object->DESTROY();

=cut

sub DESTROY {
    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    return 1;
}

package Manipulation_Module;
####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####
use strict;
use warnings;
use LIFT_general;
use Storable qw(dclone);
Readonly::Scalar my $MAX_DATA_SETS => 15;

=head1 NAME

Manipulation_Module 

manipulation module class for spi instruction set

=head1 DESCRIPTION

this class is only instanced and accessed by functions of the spi instruction set

=head1 SYNOPSIS

    use Manipulation_Module;

    Manipulation_Module -> new();
    SetValues();
    SetTimes();
    SetFrames();
    SetTriggerMask();
    SetTriggerValue();
    SetWriteMask();
    SetNodeChipSelect();
    SetNodeSPINbr();
    SetSMI7Module();
    SetSMI7Page();
    DownloadSignalManipulationToManitoo();

=head2 new

    $signalManipulation = Manipulation_Module -> new( $nodeName, $commandName, $signalName);

B<Description:> Instances a new object of manipulation module class -> manipulation module object ($signalManipulation).

B<Arguments:>

=over

=item $nodeName

Name of the node to which the signal belongs.

=item $commandName

Command name to which the signal belongs.

=item $signalName

Name of the signal.

=back

B<Return Value:> Returns the blessed (instanced) manipulation module object.
                 Returns nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation = Manipulation_Module->new( 'SMI7xx', 'Module_command', 'CRC' );

=cut

#------------------------ Constructor ------------------------------------------
sub new {
    my $class = shift;    # reference to class
    my $self  = {
        NodeName        => shift,
        CommandName     => shift,
        SignalName      => shift,
        Values          => [],
        InvertValue     => 'false',
        BinaryValue     => 'false',
        Times_us        => [],
        Frames          => [],
        NodeChipSelect  => undef,
        NodeSPINbr      => undef,
        SMI7Module      => undef,
        SMI7Page        => undef,
        TriggerMask     => undef,
        TriggerValue    => undef,
        WriteMask       => undef,
        InvertValue_BIN => undef,
        MaskValue_BIN   => undef,
        BinaryValue_BIN => undef,
        PreTriggerNbrs  => undef,
        CrashData       => undef,
    };

    # ToDo: Check that all mandatory parameters were given
    S_w2log( 5, " Instancing new device by running Manipulation_Module -> new() \n" );

    # object $self is attached to the class $class
    return bless $self, $class;
}

=head2 SetValues

    $signalManipulation->SetValues($values_aref);

B<Description:> sets value of the signals.

B<Arguments:>

=over

=item $values_aref

Array reference containing the list of values.

B<Return Value:>

    Return 1 on success.
    Return 'undef' if error.

B<Example:>

    $signalManipulation->SetValues($values_aref);

=cut

sub SetValues {

    #------------------------------------------------------------------
    my $self        = shift;
    my $values_aref = shift;
    $self->{Values} = $values_aref;
    map { $_ =~ s/\s*//g } @{$values_aref};    #remove all the spaces
    my $invertValue    = 0;
    my $binaryValue    = 0;
    my $numberOfValues = @{$values_aref};
    if ( $numberOfValues > $MAX_DATA_SETS ) {
        S_set_error("The number of values exceeds '$MAX_DATA_SETS'. The maximum Data sets limit is '$MAX_DATA_SETS'");
        $self->{Values} = undef;
        return;
    }
    my $manip_bin_values = [];
    foreach my $value ( @{$values_aref} ) {
        if ( lc($value) eq 'invert' ) {
            $invertValue++;
        }
        if ( $value =~ /0b[01i\-x\s*]+/i ) {    # check for binary format
            $value =~ s/^0b\s*//;               # remove the starting '0b' bits
            my $tempmaskbin  = $self->{MaskValue_BIN};
            my $vallength    = length $value;
            my @mask_bit_cnt = $tempmaskbin =~ /1/g;     # collect the length of mask bits

            # error if the signal value exceeds the signal mask
            if ( $vallength > scalar @mask_bit_cnt ) {
                S_set_error( "Signal Value '$value' to write to the signal '$self->{SignalName}' exceeds the signal mask", 109 );
                return;
            }
            my $replace_val = '1' x $vallength;
            $binaryValue++;

            #convert the values to 32 bit mvb format
            if ( $tempmaskbin =~ s/(.*)?($replace_val)(.*)?/('-' x length($1))/e ) {    #convert the bits before to start position of the mask to '-'(mvb format)
                my $post_mask = $3;

                #convert the bits after the mask bits to '-' mvb format
                if ($post_mask) {
                    my $post_mask_length = length $post_mask;
                    $post_mask = '-' x $post_mask_length;
                }
                $tempmaskbin = $tempmaskbin . $value . $post_mask;                      # append the converted bits into a 32 bit string
            }
            push( @$manip_bin_values, $tempmaskbin );
        }
    }
    $values_aref = $manip_bin_values;                                                   # re-assign the manipulated values to the $values_aref
    if ( $invertValue > 0 and not $invertValue == $numberOfValues ) {
        S_set_error( "Only static values can be inverted - no mixing of valid values and inverted values for the same signal allowed.\n" . "Setting values for signal manipulation not successful" );
        $self->{Values} = undef;
        return;
    }
    if ( $invertValue > 0 ) {
        S_w2rep("Invert value");
        $self->{InvertValue} = 'true';
        $self->{Values}      = undef;
    }

    # assign the binary values to the respective object
    if ( $binaryValue > 0 ) {
        $self->{BinaryValue}     = 'true';
        $self->{BinaryValue_BIN} = $values_aref;
    }
    return 1;
}

=head2 SetTimes

    $signalManipulation->SetTimes($times_aref);

B<Description:> sets time for the signal.

B<Arguments:>

=over

=item $times_aref

Array reference containing the list of time values.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetTimes($times_aref);

    $times_aref = [2000, 3000, 4000];

=cut

sub SetTimes {

    #------------------------------------------------------------------
    my $self       = shift;
    my $times_aref = shift;
    $self->{Times_us} = $times_aref;
    return 1;
}

=head2 SetFrames

     $signalManipulation->SetFrames($frames_aref);

B<Description:> sets number of frames for the signal.

B<Arguments:>

=over

=item $frames_aref

Array reference containing the list of number of frame values.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetFrames($frames_aref);
    
    $frames_aref = [23, 34, 21];

=cut

sub SetFrames {

    #------------------------------------------------------------------
    my $self        = shift;
    my $frames_aref = shift;
    $self->{Frames} = $frames_aref;
    return 1;
}

=head2 SetTriggerMask

      $signalManipulation->SetTriggerMask( $triggerMaskHex );

B<Description:> sets the trigger mask for the command.

B<Arguments:>

=over

=item $triggerMaskHex

Command mask in hex.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetTriggerMask( $triggerMaskHex );
    
    $triggerMaskHex = 'FFC00000';

=cut

sub SetTriggerMask {

    #------------------------------------------------------------------
    my $self        = shift;
    my $triggerMask = shift;
	# Manitoo expects exactly 32 bit -> 8 characters
	my $stringLength = length($triggerMask);
	if($stringLength < 8){
		foreach my $missingCharacter ($stringLength + 1..8){
			$triggerMask .= '0';
		}
	}
    $self->{TriggerMask} = $triggerMask;
    
    return 1;
}

=head2 SetTriggerValue

      $signalManipulation->SetTriggerValue($triggerMaskValue);

B<Description:> sets the trigger value for the command.

B<Arguments:>

=over

=item $triggerMaskValue

Mask value of the command in hex.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetTriggerValue($triggerMaskValue);
    
    $triggerMaskValue = '09C00000';

=cut

sub SetTriggerValue {

    #------------------------------------------------------------------
    my $self         = shift;
    my $triggerValue = shift;
 	# Manitoo expects exactly 32 bit -> 8 characters
	my $stringLength = length($triggerValue);
	if($stringLength < 8){
		foreach my $missingCharacter ($stringLength + 1..8){
			$triggerValue .= '0';
		}
	}
	$self->{TriggerValue} = $triggerValue;
    return 1;
}

=head2 SetWriteMask

      $signalManipulation->SetWriteMask($signalMaskHex);

B<Description:> sets the mask for the signal.

B<Arguments:>

=over

=item $signalMaskHex

Signal Mask in hex.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

     $signalManipulation->SetWriteMask($signalMaskHex);
    
    $signalMaskHex = '00000007';

=cut

sub SetWriteMask {

    #------------------------------------------------------------------
    my $self      = shift;
    my $writeMask = shift;
    $self->{WriteMask} = $writeMask;

    # Convert WriteMask to BIN
    S_w2log( 5, "SetWriteMask: Convert write mask into binary value mask" );
    my $numberOfNibbles = length($writeMask);
 	# Manitoo expects exactly 32 bit -> 8 characters
	if($numberOfNibbles < 8){
		foreach my $missingCharacter ($numberOfNibbles + 1..8){
			$writeMask .= '0';
		}
	}
	my $numberOfBits = 32;
    my $binMaskWrite    = sprintf( "%0" . $numberOfBits . "b", hex($writeMask) );
    $self->{MaskValue_BIN} = $binMaskWrite;    #mask value binary format

    # Replace all 0 with x
    S_w2log( 5, "SetWriteMask: Binary write mask $binMaskWrite" );
    $binMaskWrite =~ tr/01/xi/;
    S_w2log( 5, "SetWriteMask: invert value mask $binMaskWrite" );
    $self->{InvertValue_BIN} = $binMaskWrite;
    return 1;
}

=head2 SetNodeChipSelect

      $signalManipulation->SetNodeChipSelect($cs);

B<Description:> This function sets the chip select for the node.
                ( Pre - condition ) Manipulation module object has to be initialised.
B<Arguments:>

=over

=item $cs

Chip select number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetNodeChipSelect($cs);
    
    $cs = 2;

=cut

sub SetNodeChipSelect {
    my $self       = shift;
    my $chipSelect = shift;

    # chip select selection starts with CS0 in SPI_Maid tool, manitoo command format starts with '0' for CS selection
    $self->{NodeChipSelect} = $chipSelect;
    return 1;
}

=head2 SetNodeSPINbr

      $signalManipulation->SetNodeSPINbr($spiNbr);

B<Description:> This function sets the spi channel number.
                ( Pre - condition ) Manipulation module object ( $signalManipulation ) has to be initialised.

B<Arguments:>

=over

=item $spiNbr

SPI channel number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetNodeSPINbr($spiNbr);
    
    $spiNbr = 1;

=cut

sub SetNodeSPINbr {
    my $self   = shift;
    my $spiNbr = shift;
    $self->{NodeSPINbr} = $spiNbr;
    return 1;
}

=head2 SetPreTriggerNumbers

      $signalManipulation->SetPreTriggerNumbers($preTriggers_aref);

B<Description:> This function sets used pre triggers

B<Arguments:>

=over

=item $preTriggers_aref

Array reference with list of predefined pre trigger numbers

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetPreTriggerNumbers([0, 2]);
    
    $spiNbr = 1;

=cut

sub SetPreTriggerNumbers {
    my $self             = shift;
    my $preTriggers_aref = shift;
    $self->{PreTriggerNbrs} = $preTriggers_aref;
    return 1;
}

=head2 SetSMI7Module

      $signalManipulation->SetSMI7Module($smi7module);

B<Description:> This function sets the SMI7 module number.
                ( Pre - condition ) Manipulation module object ( $signalManipulation ) has to be initialised.

B<Arguments:>

=over

=item $smi7module

SMI7 module number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetSMI7Module($smi7module);
    
    $smi7module = 4;

=cut

sub SetSMI7Module {
    my $self       = shift;
    my $smi7module = shift;
    $self->{SMI7Module} = $smi7module;
    return 1;
}

=head2 SetSMI7Page

      $signalManipulation->SetSMI7Page($smi7page);

B<Description:> This function sets the SMI7 module page number.
                ( Pre - condition ) Manipulation module object ( $signalManipulation ) has to be initialised.

B<Arguments:>

=over

=item $smi7page

SMI7 module page number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $signalManipulation->SetSMI7Page($smi7page);
    
    $smi7page = 6;

=cut

sub SetSMI7Page {
    my $self     = shift;
    my $smi7page = shift;
    $self->{SMI7Page} = $smi7page;
    return 1;
}

sub SetCrashData {
    my $self      = shift;
    my $crashData = shift;
    $self->{CrashData} = $crashData;
    return 1;
}

=head2 DownloadSignalManipulationToManitoo

      $signalManipulation->DownloadSignalManipulationToManitoo($manipulationModuleNbr);

B<Description:> This function downloads the instruction set to the ManiToo.
                ( Pre - condition ) Manipulation module object ( $signalManipulation ) has to be initialised.

B<Arguments:>

=over

=item $manipulationModuleNbr

Manipulation module number.

B<Return Value:>

    Returns the status of writing the Trigger and Write functionality.

    $statusTrigger = 1 on success, 0 on failure.
    $statusWrite = 1 on success, 0 on failure.

B<Example:>

    $signalManipulation->DownloadSignalManipulationToManitoo($manipulationModuleNbr);
    
    $manipulationModuleNbr = 1;

=cut

sub DownloadSignalManipulationToManitoo {
    my $self               = shift;
    my $manipulationModule = shift;
    my $statusTrigger      = LIFT_manitoo::MANITOO_trigger_config(
        {
            'spi_manipulation_module' => $manipulationModule,        # for all
            'spi_selection'           => $self->{NodeSPINbr},        # => for 31 and 71
            'chip_select'             => $self->{NodeChipSelect},    # => for 31 and 71
            'frame_mask'              => $self->{TriggerMask},       # => for 32
            'frame_pattern'           => $self->{TriggerValue},      # => for 33
            'smi7_module'             => $self->{SMI7Module},        # => for 72, optional
            'smi7_page'               => $self->{SMI7Page},          # => for 72, optional
            'pre_trigger'             => $self->{PreTriggerNbrs},    # => for 65, optional
        }
    );

    if ( $self->{CrashData} ) {
        my $download_status = LIFT_manitoo::MANITOO_cmd_DYN_SPI_DATA_LOAD(
            {
                'spi_manipulation_module' => $manipulationModule,
                'spi_data'                => join( "", @{ $self->{CrashData} } ),
            }
        );

        return unless ($download_status);

        return $statusTrigger, $download_status;
    }

    my $statusWrite;
    if ( @{ $self->{Frames} } > 0 ) {
        if ( $self->{InvertValue} eq 'false' ) {
            if ( $self->{BinaryValue} eq 'true' ) {
                $statusWrite = LIFT_manitoo::MANITOO_write_config(
                    {
                        'spi_manipulation_module' => $manipulationModule,
                        'frames'                  => $self->{Frames},
                        'masked_value_bin'        => $self->{BinaryValue_BIN},
                    }
                );
            }
            else {
                $statusWrite = LIFT_manitoo::MANITOO_write_config(
                    {
                        'spi_manipulation_module' => $manipulationModule,
                        'frames'                  => $self->{Frames},
                        'mask_hex'                => $self->{WriteMask},
                        'value_hex'               => $self->{Values},
                    }
                );
            }
        }
        $statusWrite = LIFT_manitoo::MANITOO_write_config(
            {
                'spi_manipulation_module' => $manipulationModule,
                'frames'                  => $self->{Frames},
                'masked_value_bin'        => $self->{InvertValue_BIN},
            }
        ) if ( $self->{InvertValue} eq 'true' );
    }
    elsif ( @{ $self->{Times_us} } > 0 ) {
        if ( $self->{InvertValue} eq 'false' ) {
            if ( $self->{BinaryValue} eq 'true' ) {
                $statusWrite = LIFT_manitoo::MANITOO_write_config(
                    {
                        'spi_manipulation_module' => $manipulationModule,
                        'time_us'                 => $self->{Times_us},
                        'masked_value_bin'        => $self->{BinaryValue_BIN},
                    }
                );
            }
            else {
                $statusWrite = LIFT_manitoo::MANITOO_write_config(
                    {
                        'spi_manipulation_module' => $manipulationModule,
                        'time_us'                 => $self->{Times_us},
                        'mask_hex'                => $self->{WriteMask},
                        'value_hex'               => $self->{Values},
                    }
                );
            }
        }
        $statusWrite = LIFT_manitoo::MANITOO_write_config(
            {
                'spi_manipulation_module' => $manipulationModule,
                'time_us'                 => $self->{Times_us},
                'masked_value_bin'        => $self->{InvertValue_BIN},
            }
        ) if ( $self->{InvertValue} eq 'true' );
    }
    return $statusTrigger, $statusWrite;
}

=head2 DESTROY

    $signalManipulation->DESTROY();

B<Description:> This function destroys manipulation module object initialised.

B<Arguments:> None

B<Return Value:> Returns 1 on success.

B<Example:>

     $signalManipulation->DESTROY();

=cut

sub DESTROY {
    #
    # Destructor - just to have one
    #
    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    return 1;
}

package PreTrigger_Module;
####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####
use strict;
use warnings;
use LIFT_general;
use Storable qw(dclone);

=head1 NAME

PreTrigger_Module 

manipulation module class for spi instruction set

=head1 DESCRIPTION

this class is only instanced and accessed by functions of the spi instruction set

=head1 SYNOPSIS

    use PreTrigger_Module;

    PreTrigger_Module -> new();
    GetPreTriggerName();
    GetPreTriggerNbr();
    SetActiveTime();
    SetNodeChipSelect();
    SetTriggerMask();
    SetTriggerValue();
    DownloadPreTriggerToManitoo();

=head2 new

    $preTrigger = PreTrigger_Module -> new( $ptNumber, $ptNodeName, $ptCommand [, $ptSignal]);

B<Description:> Instances a new object of pretrigger class -> pretrigger object ($preTrigger).
The pretrigger can either trigger to a command or to a command with a certain signal value.

B<Arguments:>

=over

=item $ptNodeName

Name of the node to which the pretrigger command belongs

=item $ptCommand

Command name on which the pretrigger shall be set

=item $ptSignal

Name of the signal (if required)

=back

B<Return Value:> Returns the blessed (instanced) pretrigger object.
                 Returns nothing if missing mandatory parameter.

B<Example:>

    $preTrigger = PreTrigger_Module -> new( 0, 'CG904', 'DEMAND_TEST');
    $preTrigger = PreTrigger_Module -> new( 1, 'CG904', 'THRES_TEST_DATA', 'test_data');

=cut

#------------------------ Constructor ------------------------------------------
sub new {
    my $class = shift;    # Perl �bergibt als erstes eine Referenz auf die Klasse, dessen Methode gerufen wurde
    my $self  = {
        PT_Number         => shift,
        PT_NodeName       => shift,
        PT_Command        => shift,
        PT_Signal         => shift,    #optional
        PT_NodeChipSelect => undef,
        PT_NodeSPINbr     => undef,
        PT_TriggerMask    => undef,
        PT_TriggerValue   => undef,
        PT_ActiveTime_us  => undef,
    };

    # Check that all mandatory parameters were given
    S_w2log( 2, " Instancing new pretrigger module by running PreTrigger_Module -> new() \n" );

    # object $self is attached to the class $class
    return bless $self, $class;
}

=head2 GetPreTriggerName

      $preTriggerName = $preTrigger -> GetPreTriggerName(  );

B<Description:> returns the pre trigger module name, which consists of node, command, and signal (if defined)

B<Arguments:>

B<Return Value:>

    Return $preTriggerName on success.

B<Example:>

    my $preTriggerName = $preTrigger -> GetPreTriggerName(  );

    $preTriggerName = 'CG904::DEMAND_TEST';

=cut

sub GetPreTriggerName {
    my $self            = shift;
    my $thisTriggerName = $self->{PT_NodeName} . "::" . $self->{PT_Command};
    if ( $self->{PT_Signal} ) {
        $thisTriggerName .= "::" . $self->{PT_Signal};
    }
    return $thisTriggerName;
}

=head2 GetPreTriggerNbr

      $preTriggerNbr = $preTrigger -> GetPreTriggerNbr(  );

B<Description:> returns the pre trigger module number (0..3)

B<Arguments:>

B<Return Value:>

    Return $preTriggerNbr on success.

B<Example:>

    my $preTriggerNbr = $preTrigger -> GetPreTriggerNbr(  );
    
    $preTriggerNbr = 2;

=cut

sub GetPreTriggerNbr {
    my $self = shift;
    return $self->{PT_Number};
}

=head2 SetTriggerMask

      $preTrigger -> SetTriggerMask( $triggerMaskHex );

B<Description:> sets the trigger mask for the command.

B<Arguments:>

=over

=item $triggerMaskHex

Command mask in hex.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $preTrigger -> SetTriggerMask( $triggerMaskHex );
    
    $triggerMaskHex = 'FFC00000';

=cut

sub SetTriggerMask {

    #------------------------------------------------------------------
    my $self        = shift;
    my $triggerMask = shift;
	# Manitoo expects exactly 32 bit -> 8 characters
	my $stringLength = length($triggerMask);
	if($stringLength < 8){
		foreach my $missingCharacter ($stringLength + 1..8){
			$triggerMask .= '0';
		}
	}
    $self->{PT_TriggerMask} = $triggerMask;
    return 1;
}

=head2 SetTriggerValue

      $preTrigger -> SetTriggerValue($triggerMaskValue);

B<Description:> sets the trigger value for the command.

B<Arguments:>

=over

=item $triggerMaskValue

Mask value of the command in hex.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $preTrigger -> SetTriggerValue($triggerMaskValue);
    
    $triggerMaskValue = '09C00000';

=cut

sub SetTriggerValue {

    #------------------------------------------------------------------
    my $self         = shift;
    my $triggerValue = shift;
	# Manitoo expects exactly 32 bit -> 8 characters
	my $stringLength = length($triggerValue);
	if($stringLength < 8){
		foreach my $missingCharacter ($stringLength + 1..8){
			$triggerValue .= '0';
		}
	}
    $self->{PT_TriggerValue} = $triggerValue;
    return 1;
}

=head2 SetNodeChipSelect

      $preTrigger -> SetNodeChipSelect($cs);

B<Description:> This function sets the chip select for the node.
                ( Pre - condition ) Pretrigger module object has to be initialised.
B<Arguments:>

=over

=item $cs

Chip select number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $preTrigger -> SetNodeChipSelect($cs);
    
    $cs = 2;

=cut

sub SetNodeChipSelect {
    my $self       = shift;
    my $chipSelect = shift;

    # chip select selection starts with CS0 in SPI_Maid tool, manitoo command format starts with '0' for CS selection
    $self->{PT_NodeChipSelect} = $chipSelect;
    return 1;
}

=head2 SetNodeSPINbr

      $preTrigger -> SetNodeSPINbr($spiNbr);

B<Description:> This function sets the spi channel number.
                ( Pre - condition ) Pretrigger module object ( $preTrigger ) has to be initialised.

B<Arguments:>

=over

=item $spiNbr

SPI channel number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $preTrigger -> SetNodeSPINbr($spiNbr);
    
    $spiNbr = 1;

=cut

sub SetNodeSPINbr {
    my $self   = shift;
    my $spiNbr = shift;
    $self->{PT_NodeSPINbr} = $spiNbr;
    return 1;
}

=head2 SetActiveTime

      $preTrigger -> SetActiveTime($spiNbr);

B<Description:> This function sets the spi channel number.
                ( Pre - condition ) Pretrigger module object ( $preTrigger ) has to be initialised.

B<Arguments:>

=over

=item $spiNbr

SPI channel number.

B<Return Value:>

    Return 1 on success.
    Return nothing if missing mandatory parameter.

B<Example:>

    $preTrigger -> SetNodeSPINbr($spiNbr);
    
    $spiNbr = 1;

=cut

sub SetActiveTime {
    my $self          = shift;
    my $pt_activeTime = shift;
    $self->{PT_ActiveTime_us} = $pt_activeTime;
    return 1;
}

=head2 DownloadPreTriggerToManitoo

      $preTrigger -> DownloadPreTriggerToManitoo($ptNumber);

B<Description:> This function downloads the instruction set to the ManiToo.
                ( Pre - condition ) Pretrigger module object ( $preTrigger ) has to be initialised.

B<Arguments:>

=over

=item $ptNumber

Pretrigger module number (0..3).

B<Return Value:>

    Returns the status of writing the Pretrigger configuration

    $statusPreTrigger = 1 on success, 0 on failure.

B<Example:>

    $preTrigger - >DownloadSignalManipulationToManitoo($ptNumber);
    
    $ptNumber = 1;

=cut

sub DownloadPreTriggerToManitoo {
    my $self             = shift;
    my $statusPreTrigger = LIFT_manitoo::MANITOO_pre_trigger_config(
        {
            'nbr'                    => $self->{PT_Number},           # for all
            'spi_selection'          => $self->{PT_NodeSPINbr},
            'chip_select'            => $self->{PT_NodeChipSelect},
            'frame_mask'             => $self->{PT_TriggerMask},
            'frame_pattern'          => $self->{PT_TriggerValue},
            'trigger_active_time_us' => $self->{PT_ActiveTime_us},
        }
    );
    return $statusPreTrigger;
}

=head2 DESTROY

    $ptNumber -> DESTROY();

B<Description:> This function destroys pretrigger module object initialised.

B<Arguments:> None

B<Return Value:> Returns 1 on success.

B<Example:>

     $ptNumber -> DESTROY();

=cut

sub DESTROY {
    #
    # Destructor - just to have one
    #
    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");
    return 1;
}
1;
__END__


 
