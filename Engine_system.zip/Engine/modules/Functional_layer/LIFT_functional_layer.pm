# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_functional_layer;

use strict;
use warnings;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  FL_Init
  FL_Exit
  FL_CallDeviceFunction
  FL_CreateArchitectureStructure
  FL_GetConfiguredDevice
);

our ( $VERSION, $HEADER );

my ( $configuredDevices_href, $initFunctions_href );

=head1 NAME

LIFT_functional_layer 

=head1 SYNOPSIS

    use LIFT_functional_layer;

    FL_Init( 'labcar', $functionMapping_href, \@availableTestbenchFunctionGroups );
    
    FL_Exit( 'labcar', $functionMapping_href );
    
    FL_CallDeviceFunction('labcar', $functionMapping_href, @args);
    
    FL_CreateArchitectureStructure('labcar', $functionMapping_href);

=head1 DESCRIPTION

This is a helper library for the TurboLIFT functional layer. It provides common functions that are used for several modules in the fuinctional layer. 

=cut

=head2 FL_Init

    FL_Init( $functionLib, $functionMapping_href, $availableTestbenchFunctionGroups_aref );
    
Initialize the devices for all function groups of the function library $functionLib.
This function has to be called before calling any other function in $functionLib.
Calls internally the init functions of all devices that are configured in LIFT_Testbenches.pm for $functionLib.
By convention the init functions must have the name "Init_<device>", e.g. Init_TSG4, Init_MLC, ...

Must be called by <prefix>_Init of functional layer modules.

=cut

sub FL_Init {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FL_Init( $functionLib, $functionMapping_href, $availableTestbenchFunctionGroups_aref )', @args );

    my $functionLib                           = shift @args;
    my $functionMapping_href                  = shift @args;
    my $availableTestbenchFunctionGroups_aref = shift @args;

    delete $configuredDevices_href->{$functionLib};
    $initFunctions_href = {};

    my @availableTestbenchFunctionGroups = @{$availableTestbenchFunctionGroups_aref};

    # get the whole 'Functions' section of LIFT_testbenches with all funcLibs
    my $funcLibs_href = S_get_contents_of_hash( ['Functions'], $LIFT_config::LIFT_Testbench );

    # loop over all funcLibs
    foreach my $tbFuncLib ( keys %{$funcLibs_href} ) {

        # check if funcLib is $functionLib
        next if ( $tbFuncLib !~ /^$functionLib$/i );

        # loop over all function groups that are configured in LIFT_testbenches for $functionLib
        foreach my $functionGroup ( keys %{ $funcLibs_href->{$tbFuncLib} } ) {
            unless ( grep { /^$functionGroup$/ } @availableTestbenchFunctionGroups ) {
                S_set_error( "Function '$functionGroup' is configured in LIFT_Testbenches for '$functionLib', but it is not supported for '$functionLib'. Supported functions are: @availableTestbenchFunctionGroups", 20 );
                next;
            }

            # get the configured device name for the current function
            my $device = $funcLibs_href->{$tbFuncLib}{$functionGroup};
            if ( defined $device ) {

                # Check if the configured device is valid and store it in a hashref, used later by CallDeviceFunction ($configuredDevices_href).
                # For this the function groups defined in testbench config must be translated to function groups in architecture ($functionMapping_href).
                CheckAndStoreConfiguredDevice( $functionLib, $functionMapping_href, $device, $functionGroup );
            }
        }
    }

    # loop over all possible functions for $functionLib
    foreach my $functionGroup ( sort keys %{$functionMapping_href} ) {

        # call the initialization function for the function group and the configured device
        CallInitFunction( $functionLib, $functionGroup );
    }

    return $configuredDevices_href->{$functionLib};
}

=head2 FL_Exit

    FL_Exit( $functionLib, $functionMapping_href );
    
Disconnect from the devices for all functions of $functionLib.

Must be called by <prefix>_Exit of functional layer modules.

=cut

sub FL_Exit {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'FL_Exit( $functionLib, $functionMapping_href )', @args );

    my $functionLib          = shift @args;
    my $functionMapping_href = shift @args;

    # fill @usedDevices with all configured devices, no duplicates!
    my @usedDevices;
    foreach my $functionGroup ( keys %{ $configuredDevices_href->{$functionLib} } ) {
        my $device = $configuredDevices_href->{$functionLib}{$functionGroup};
        push( @usedDevices, $device ) if not grep { /^$device$/ } @usedDevices;
    }

    # loop over all used devices
    foreach my $device (@usedDevices) {

        # get exit function from $functionMapping_href
        my $exitFunction;
        foreach my $function ( keys %{ $functionMapping_href->{'base'}{$device} } ) {
            if ( $function =~ /exit$/i ) {
                $exitFunction = $function;
                last;
            }
        }
        $exitFunction = $functionMapping_href->{'base'}{$device}{$exitFunction} if defined $exitFunction;

        # check if exit function exists
        if ( exists &$exitFunction ) {

            # call the exit function for the device
            no strict 'refs';
            &$exitFunction();
        }
        else {
            S_set_error( "Exit function '$exitFunction' for device '$device' does not exist. Please contact the TurboLIFT development team.", 20 );
        }

    }

    # all exit functions have been called, so delete $configuredDevices_href
    delete $configuredDevices_href->{$functionLib};

    return 1;

}

=head2 FL_CallDeviceFunction

    FL_CallDeviceFunction( $functionLib, $functionMapping_href, @args );
    
Calls a function for the library $functionLib that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.

Returns the return values of the called functions. On error returns 0.

Must be called by <prefix>_CallDeviceFunction of functional layer modules.

=cut

sub FL_CallDeviceFunction {
    my @args = @_;

    my $functionLib          = shift @args;
    my $functionMapping_href = shift @args;

    # get name of the calling function from calling stack
    my $callingFunction = ( caller(2) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    # get function group from calling function name
    my $functionGroup = GetFunctionGroupFromFunction( $callingFunction, $functionMapping_href );

    # special treatment for power function groups: replace in function group name Ubat or UF from $functionMapping_href (which is random) with Ubat or UF from arguments
    if ( $functionGroup =~ /^power_(static|dynamic)/ ) {

        my $powerSource = $LIFT_labcar::currentPowerSource;
        $functionGroup = "power_$1_$powerSource";
    }

    # get configured device from function group
    my $device = $configuredDevices_href->{$functionLib}{$functionGroup};
    if ( not defined $device ) {
        $functionGroup = GetTestbenchFuncGroupFromArchFuncGroup($functionGroup);
        S_set_error( "Please configure '$functionLib -> $functionGroup' in 'Functions' section of LIFT_Testbenches and call the proper init function before calling any '$functionGroup' function in the function library for $functionLib.", 20 );
        return 0;
    }

    # get device layer function name from $functionMapping_href
    my $deviceFunction = $functionMapping_href->{$functionGroup}{$device}{$callingFunction};
    if ( not defined $deviceFunction ) {
        S_set_error("Function '$callingFunction' not defined for device '$device'\n");
        return 0;
    }

    # check if device layer function exists
    unless ( exists &$deviceFunction ) {
        S_set_error( "Function '$callingFunction' is mapped to '$deviceFunction' for device '$device', but '$deviceFunction' does not exist\n", 20 );
        return 0;
    }

    # call device layer function with passed arguments
    S_w2log( 5, "FL_CallDeviceFunction: For function library '$functionLib' for functional layer function '$callingFunction' the device layer function '$deviceFunction' will be called for device '$device'...\n" );
    no strict 'refs';
    return &$deviceFunction(@args);
}

=head2 FL_CreateArchitectureStructure

    $architecture_href = FL_CreateArchitectureStructure( $functionLib, $functionMapping_href );
    
Creates for a given library ($functionLib) a data structure ($architecture_href) out of which the plots for mapping of functional layer functions to device layer functions are created.
The plots are used in TurboLIFT documentation. Input is the function mapping $functionMapping_href.

Must be called by <prefix>_CreateArchitectureStructure of functional layer modules.

=cut

sub FL_CreateArchitectureStructure {
    my @args = @_;

    my $functionLib          = shift @args;
    my $functionMapping_href = shift @args;

    my $architecture_href;

    # get function prefix for each device from $functionMapping_href
    my $functionPrefix_href = GetFunctionPrefixes( $functionLib, $functionMapping_href );

    # read actually used device functions by parsing the device specific packages in this perl module
    my $deviceFunctions_href = ReadDeviceFunctionsFromModule( $functionLib, $functionPrefix_href );

    # create $architecture_href by looping over $functionMapping_href and replacing values like LIFT_labcar_xyz::LC_abc with the proper entries in $deviceFunctions_href
    foreach my $functionGroup ( keys %{$functionMapping_href} ) {
        foreach my $device ( keys %{ $functionMapping_href->{$functionGroup} } ) {
            foreach my $function ( keys %{ $functionMapping_href->{$functionGroup}{$device} } ) {
                my $deviceFunction = $functionMapping_href->{$functionGroup}{$device}{$function};
                if ( $deviceFunction =~ /\w+::(\w+)/ ) {
                    $deviceFunction = 'None';
                    $deviceFunction = $deviceFunctions_href->{$device}{$function} if defined $deviceFunctions_href->{$device}{$function};
                }
                $architecture_href->{$functionGroup}{$device}{$function} = $deviceFunction;
            }
        }
    }

    return $architecture_href;
}

=head2 FL_GetConfiguredDevice

    $device = FL_GetConfiguredDevice( $functionLib, $functionGroup );

Returns the device that is configured for the given $functionGroup in $functionLib.
Returns undef if no device is configured for $functionGroup in $functionLib.

=cut

sub FL_GetConfiguredDevice{
    my @args = @_;
    return unless S_checkFunctionArguments( 'FL_GetConfiguredDevice( $functionLib, $functionGroup )', @args );

    my $functionLib          = shift @args;
    my $functionGroup        = shift @args;
    
    return if not defined $configuredDevices_href->{$functionLib};
    
    return $configuredDevices_href->{$functionLib}{$functionGroup};
    
}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=head2 CheckAndStoreConfiguredDevice

    CheckAndStoreConfiguredDevice( $functionLib, $functionMapping_href, $device, $functionGroup );

Check if in the function mapping ($functionMapping_href) the configured device ($device) is valid for the given testbench function group ($functionGroup) 
for the function library $functionLib and store the information about configured devices in a hashref, 
used later by FL_CallDeviceFunction ($configuredDevices_href).

Called by FL_Init.

=cut

sub CheckAndStoreConfiguredDevice {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CheckAndStoreConfiguredDevice( $functionLib, $functionMapping_href, $device, $functionGroup )', @args );

    my $functionLib          = shift @args;
    my $functionMapping_href = shift @args;
    my $device               = shift @args;
    my $functionGroup        = shift @args;

    # testbench function group 'extended' (only for library LIFT_labcar) contains architecture function groups 'lineRT' and 'digital2CAN'
    if ( $functionGroup eq 'extended' ) {
        return 0 if not IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroup, 'lineRT' );
        $configuredDevices_href->{$functionLib}{'lineRT'}      = $device;
        $configuredDevices_href->{$functionLib}{'digital2CAN'} = $device;
    }

    # testbench function group 'power_Ubat'(only for library LIFT_labcar) contains architecture function groups 'power_static_Ubat' and 'power_dynamic_Ubat' (if the device supports it)
    # additional keys 'power_static_Ubat', 'power_dynamic_Ubat' will be added to $functionMapping_href to handle power functions properly
    elsif ( $functionGroup eq 'power_Ubat' ) {
        return 0 if not IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroup, 'power_static' );
        $configuredDevices_href->{$functionLib}{'power_static_Ubat'} = $device;
        $functionMapping_href->{'power_static_Ubat'} = $functionMapping_href->{'power_static'};

        if ( grep { /^$device$/ } keys %{ $functionMapping_href->{'power_dynamic'} } ) {
            $configuredDevices_href->{$functionLib}{'power_dynamic_Ubat'} = $device;
            $functionMapping_href->{'power_dynamic_Ubat'} = $functionMapping_href->{'power_dynamic'};
        }
    }

    # testbench function group 'power_UF' (only for library LIFT_labcar) contains architecture function groups 'power_static_UF' and 'power_dynamic_UF' (if the device supports it)
    # additional keys 'power_static_UF', 'power_dynamic_UF' will be added to $functionMapping_href to handle power functions properly
    elsif ( $functionGroup eq 'power_UF' ) {
        return 0 if not IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroup, 'power_static' );
        $configuredDevices_href->{$functionLib}{'power_static_UF'} = $device;
        $functionMapping_href->{'power_static_UF'} = $functionMapping_href->{'power_static'};

        if ( grep { /^$device$/ } keys %{ $functionMapping_href->{'power_dynamic'} } ) {
            $configuredDevices_href->{$functionLib}{'power_dynamic_UF'} = $device;
            $functionMapping_href->{'power_dynamic_UF'} = $functionMapping_href->{'power_dynamic'};
        }
    }

    # all other function groups are the same in testbench and architecture
    else {
        return 0 if not IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroup, $functionGroup );
        $configuredDevices_href->{$functionLib}{$functionGroup} = $device;
    }

    return 1;
}

=head2 IsDeviceValid

    IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroupTB, $functionGroupArch );

Check if the given device ($device) is available for the given architecture function group ($functionGroupArch) in $functionMapping_href 
for the library $functionLib.

Called by CheckAndStoreConfiguredDevice.

=cut

sub IsDeviceValid {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'IsDeviceValid( $functionLib, $functionMapping_href, $device, $functionGroupTB, $functionGroupArch )', @args );

    my $functionLib          = shift @args;
    my $functionMapping_href = shift @args;
    my $device               = shift @args;
    my $functionGroupTB      = shift @args;
    my $functionGroupArch    = shift @args;

    my @availableDevices = keys %{ $functionMapping_href->{$functionGroupArch} };
    if ( grep { /^$device$/ } @availableDevices ) {
        return 1;
    }
    else {
        S_set_error( "Device '$device' is configured in LIFT_Testbenches for '$functionLib -> $functionGroupTB', but it is not supported for '$functionLib -> $functionGroupTB'. Supported devices are: @availableDevices", 20 );
        return 0;
    }
}

=head2 CallInitFunction

    CallInitFunction( $functionLib, $functionGroup );

Check if an init function exists for the device that is configured for the given function group ($functionGroup) for the library $functionLib.
By convention the init function must have the name "Init_<device>". 

Call this init function if it has not been called before.

Called by FL_Init.

=cut

sub CallInitFunction {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'CallInitFunction( $functionLib, $functionGroup )', @args );

    my $functionLib   = shift @args;
    my $functionGroup = shift @args;

    # get the device that is configured in LIFT_testbenches for the function group
    my $device = $configuredDevices_href->{$functionLib}{$functionGroup};

    # do nothing if no device is configured for this function group
    return 1 if not defined $device;

    my $deviceModule = Prefix2Module($device);
    eval "use $deviceModule" if defined $deviceModule;

    # get name of the calling module from calling stack
    my $callingModule = ( caller(2) )[3];
    if ( $callingModule =~ /^(\w+)::(\w+)$/ ) {
        $callingModule = $1;
    } elsif( $callingModule =~ /^(\w+::\w+)::(\w+)$/ ){
    	$callingModule = $1;
    }

    # get the init-function for that device
    my $initFunction = $callingModule . "::Init_$device";

    # check if the init-function for the device exists
    if ( not exists &$initFunction ) {
        S_set_error( "Init function '$initFunction' for device '$device' does not exist. Please contact the TurboLIFT development team.", 20 );
        delete $configuredDevices_href->{$functionLib}{$functionGroup};
        return 0;
    }

    # check if the init-function for the device has been called before
    if ( not defined $initFunctions_href->{$device} ) {

        # call the init function for the device
        no strict 'refs';
        
        S_w2log( 2 , " CallInitFunction : '$initFunction' for device '$device' \n" );        
        &$initFunction();

        # set a flag that the init-function for the device has been called
        $initFunctions_href->{$device} = 1;
    }

    S_w2log( 2 , " CallInitFunction : '$functionLib' -> '$functionGroup' is initialized \n" );        

    return 1;
}

=head2 GetFunctionGroupFromFunction

    $functionGroup = GetFunctionGroupFromFunction( $callingFunction, $functionMapping_href );

Search in sub-keys of $functionMapping_href for the given function ($callingFunction) and return the corresponding function group.

Note: for power function groups (for LIFT_labcar) either "<function group>_UBat" or "<function group>_UF" or "<function group>" will be returned (cannot be predicted which).

Called by FL_CallDeviceFunction.

=cut

sub GetFunctionGroupFromFunction {
    my $callingFunction      = shift;
    my $functionMapping_href = shift;

    foreach my $functionGroup ( keys %{$functionMapping_href} ) {
        foreach my $device ( keys %{ $functionMapping_href->{$functionGroup} } ) {
            if ( grep { /^$callingFunction$/ } keys %{ $functionMapping_href->{$functionGroup}{$device} } ) {
                return $functionGroup;
            }
        }
    }
    return;
}

=head2 GetTestbenchFuncGroupFromArchFuncGroup

    $functionGroup = GetTestbenchFuncGroupFromArchFuncGroup( $functionGroup );

Translate from architecture function groups to testbench function group.

Called by FL_CallDeviceFunction.

=cut

sub GetTestbenchFuncGroupFromArchFuncGroup {
    my $functionGroup = shift;

    if ( $functionGroup =~ /^power_(static|dynamic)_(Ubat|UF)$/ ) {
        $functionGroup = "power_$2";
    }
    elsif ( $functionGroup =~ /^(lineRT|digital2CAN)$/ ) {
        $functionGroup = "extended";
    }

    return $functionGroup;
}

=head2 NotSupportedYet

    NotSupportedYet();

This function is used as placeholder until the function is implemented for a specific device.
Always throws an error.

Used in $functionMapping_href.

=cut

sub NotSupportedYet {

    # get name of the calling function from calling stack
    my $callingFunction = ( caller(3) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    S_set_error( "Sorry, the function '$callingFunction' is not supported yet for the configured device.", 20 );
    return 0;
}

=head2 NotSupported

    NotSupported();

This function indicates that a functional layer function is not supported for a certain device.
Always throws an error.

Used in $functionMapping_href.

=cut

sub NotSupported {

    # get name of the calling function from calling stack
    my $callingFunction = ( caller(3) )[3];
    if ( $callingFunction =~ /^(\w+)::(\w+)$/ ) {
        $callingFunction = $2;
    }

    S_set_error( "Sorry, the function '$callingFunction' is not supported for the configured device.", 20 );
    return 0;
}

=head2 None

    None();

This function is used if a functional layer function has no functionality for a specific device.

Used in $functionMapping_href.

=cut

sub None {

    # do nothing
    return 1;
}

=head2 GetFunctionPrefixes

    $functionPrefix_href = GetFunctionPrefixes( $functionLib, $functionMapping_href );

Extracts the prefixes of all device functions of $functionMapping_href in library $functionLib.

Called by FL_CreateArchitectureStructure.

=cut

sub GetFunctionPrefixes {
    my $functionLib          = shift;
    my $functionMapping_href = shift;

    my $functionPrefix_href;

    my @devices       = keys %{ $functionMapping_href->{'base'} };
    my @baseFunctions = keys %{ $functionMapping_href->{'base'}{ $devices[0] } };
    my $baseFunction  = $baseFunctions[0];

    if ( $baseFunction =~ /^([a-zA-Z0-9]+)_/ ) {
        $functionPrefix_href->{$functionLib} = $1;
    }
    else {
        $functionPrefix_href->{$functionLib} = 'prefix_not_found';
    }

    foreach my $device ( keys %{ $functionMapping_href->{'base'} } ) {
        my $initFunction = $functionMapping_href->{'base'}{$device}{$baseFunction};
        if ( $initFunction =~ /^([a-zA-Z0-9]+)_/ ) {
            $functionPrefix_href->{$device} = $1;
        }
        else {
            $functionPrefix_href->{$device} = 'prefix_not_found';
        }
    }
    return $functionPrefix_href;
}

=head2 ReadDeviceFunctionsFromModule

    $deviceFunctions_href = ReadDeviceFunctionsFromModule( $functionLib, $functionPrefix_href );

Reads the library module (.pm-file) for $functionLib, searches for device specific packages 
and extracts the mapping of functional layer functions to actually called device functions ($deviceFunctions_href).

Called by FL_CreateArchitectureStructure.

=cut

sub ReadDeviceFunctionsFromModule {
    my $functionLib         = shift;
    my $functionPrefix_href = shift;

    my $libPrefix  = $functionPrefix_href->{$functionLib};
    my $libModule  = Prefix2Module($libPrefix);
    my $modulePath = $INC{ $libModule . ".pm" };
    if( not defined $modulePath ) {
        S_set_error( "Module path for module file $libModule (function prefix $libPrefix) not found.\n", 109 );
        return;
    }

    open my $LCFH, '<', $modulePath or S_set_error( "Cannot open module file $modulePath: $!.\n", 109 );
    my @moduleLines = <$LCFH>;
    close($LCFH);

    # collect function calls in device specific packages
    my ( $deviceFunctions_href, $devicePackage, $functionDefinition );
    my $regex = 'package\s+'.$libModule.'_(\w+)\s*;';
    foreach my $line (@moduleLines) {

        # detect device package
        if ( $line =~ /$regex/ ) {
            my $device = $1;
            if ( grep { /^$device$/ } keys %{$functionPrefix_href} ) {
                $devicePackage      = $device;
                $functionDefinition = undef;
            }
        }

        next if not defined $devicePackage;

        # detect sub definition
        if ( $line =~ /sub\s+(\w+)/ ) {
            $functionDefinition = $1;
        }

        next if not defined $functionDefinition;

        # detect device api call
        my $apiRegex = $functionPrefix_href->{$devicePackage} . '_\w+';
        if ( $line =~ /($apiRegex)\(.*\)/ ) {
            my $deviceFunction = $1;
            if ( not defined $deviceFunctions_href->{$devicePackage}{$functionDefinition} ) {
                $deviceFunctions_href->{$devicePackage}{$functionDefinition} = $deviceFunction;
            }
            else {
                $deviceFunctions_href->{$devicePackage}{$functionDefinition} .= ", $deviceFunction";
            }
        }
    }

    return $deviceFunctions_href;

}

=head2 Prefix2Module

    $module = Prefix2Module( $prefix );

Returns the module name that corresponds to the given function prefix.

Called by ReadDeviceFunctionsFromModule.

=cut

sub Prefix2Module {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'Prefix2Module( $prefix )', @args );

    my $prefix = shift @args;
    
    my $prefixMapping_href = {
                               'IDX'  => 'IDEFIX',
                               'IXS'  => 'IDXSPI',
                               'TOE'  => 'TOELLNER',
                               'PRT'  => 'PRITT',
                               'LC'   => 'labcar',
                               'MOT'  => 'motion',
                               'S'    => 'general',
                               'TEMP' => 'TEMPERATURE',
                               'CSI'  => 'crash_simulation',
                               'CA'  => 'can_access',
                               'CANoe'  => 'CANoe_device',
                               'CANoeCtrl'  => 'CANoeCtrl',
                               'AB10' => 'PD',
                               'AB12' => 'ProdDiag_AB12',
                               'QNX' => 'SIL',
                               'LINUX' => 'SIL',
                               'WINDOWS' => 'SIL',
							   'SPILC'     => 'FuncLib_SPILC_Framework',
							   'Manitoo' => 'manitoo',
							   'SPI_SensorSimulation' => 'FuncLib_SPI_SensorSimulation',
                               
    };

    my $module = $prefixMapping_href->{$prefix};
    if ( not defined $module ) {
        $module = $prefix;
    }

    if( $module =~ /^none$/i ) {
        return;
    }

	if ( $prefix ne 'DTM5080' and $prefix ne 'SPILC') {
        $module = 'LIFT_' . $module;        
    }

    return $module;
}

1;
__END__

 
