# *****************************************************************************************************
#
#  Copyright (c)  Robert Bosch GmBH
#                 Germany
#                 All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_LIN_Access;

use strict;
use warnings;
use LIFT_general;
use LIFT_equipment;
use LIFT_vector_cantool;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_CANoeCtrl ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [qw()] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  LIN_init
  LIN_read_configure
  LIN_read_LIN_signal
  LIN_write_configure
  LIN_write_LIN_signal
  LIN_disable_frame
  LIN_enable_frame
  LIN_trace_configure
  LIN_trace_start
  LIN_trace_stop
  LIN_trace_check_running
  LIN_trace_store
  LIN_trace_get_dataref
  LIN_set_DLC
  LIN_reset_DLC
  
  LIN_set_invalidCRC
  LIN_set_validCRC
  LIN_set_invalidBZ
  LIN_set_validBZ
  LIN_get_lin_message_info
  LIN_get_LIN_signal_info  
);

our ( $VERSION, $HEADER );

my $LIN_control;

# my $LIN_mapping;

my $dummy_href = { '0' => '0' };

=head1 NAME

LIFT_LIN_Access 

=head1 SYNOPSIS

   LIN_read_configure( );
   Value = LIN_read_LIN_signal ( LIN_signal, 'phys');
  ( Value, Unit ) = LIN_read_LIN_signal ( LIN_signal, 'hex');
   LIN_write_configure( );
   LIN_write_LIN_signal(LIN_signal, Signal_value, 'phys');
   LIN_disable_frame (LIN_frame);
   LIN_enable_frame( LIN_frame);
   LIN_trace_configure ( );
   LIN_trace_start ( );
   LIN_trace_stop ( );
   return_value = LIN_trace_check_running ( );
   file_name_stored = LIN_trace_store ( );
   data_ref = Lin_trace_get_dataref ( $data_file_name , @label_list );
   LIN_set_DLC( LIN_frame);
   LIN_reset_DLC ( LIN_frame);

=head1 DESCRIPTION

This module controls the CANoe application and provides below functionalities  :
 
=over 3

=item * start & stop RBS with trace logging

=item * read LIN signals

=item * write LIN signals

=item * LIN message manipulation

=back

=head2 Prerequisites

You need to have basic knowledge of CANoe. For example compiling of .cfg file, editing some CAPL program etc.

=cut

=head2 Testbench configuration

=head3 Devices section:

=for html
<a href='LIFT_can_access.html#Testbench-configuration'>See LIFT_can_access -> Testbench configuration</a>

=head3 Functions section:

    'Functions' => {
        ...
        'LIN_Access' => {
           'basic'     =>  'CANoe',     # function groups: read, write, trace
        },
        ...  
    },

For backwards compatibility the old way of function configuration is also supported:

    'LIN_Access' => {
       'read' =>  [ 'CANoe' ],
       'write' => [ 'CANoe' ],
       'trace' => [ 'CANoe' ],
    },

=head2 LIN mapping

Many functions of this module need a LIN mapping file that provides information about IDs of messages and bit and byte positions of signals.
The LIN mapping file can be generated from the .ldf file that defines the rest bus simulation. 
To do this there is a LIN mapping file generator tool (with GUI) available: 

    <path to your TurboLIFT sandboxes>\Tools\Mappingfile_Generators\LINMapping\LIFT_prepare_LIN_mapping.pl

The generated FlexRay mapping file should be copied to the "config" folder of your TurboLIFT project and 
in the main config file (..._CFG.pm) the LIN mapping file must be loaded, e.g. like this:

    require "$LIFT_PRJCFG_path/Mapping_LIN.pm" if ( -f "$LIFT_PRJCFG_path/Mapping_LIN.pm" );

=head2 LIN mapping file format

    $Defaults->{"Mapping_LIN"} = {

        #############################################
        ## --- LIN MESSAGES  ---edited for MLBevo_SC_LIN1
        #############################################

        'LIN_MESSAGES'  => {
            'AB_Sg_Init_Info'  => {
                'ID'            => '58', #in decimal (3A in hex)
                'DLC'           => '1',
                'SENDER'        => 'LIN_Master',
                'CAN_BUS_NBR'   => '1',
                'CYCLE'         => undef,
                'CANOE_DISABLE' => 'EvStartAB_Sg_Init_Info',
                'CANOE_DLC'     => 'EvDLCAB_Sg_Init_Info',
            },
        },

       #############################################
       ## --- LIN SIGNALS  ---
       #############################################
       # env variable format -- s_mess_signalname
       'AB_Sg_Init_Info_CompID'  => {
            'SIGNAL_NAME'   => 'AB_Sg_Init_Info_CompID',
            'CANOE_ENV_VAR' => 'S_AB_Sg_Init_Info_AB_Sg_Init_Info_CompID', #proper format
            'SENDER'        => 'LIN_Master',
            'MESSAGE'       => 'AB_Sg_Init_Info',
            'MULTIPLEX'     => undef,
            'STARTBIT'      => '0',
            'LENGTH'        => '8',
            'OFFSET'        => '0',
            'FACTOR'        => '0',
            'FORMAT'        => 'INTEL',
            'TYPE'          => 'UNSIGNED',
            'UNIT'          => 'NO_UNIT',
            'INIT'          => '1',     ## verify INIT value with specifications
        },
    };

=cut

=head1 FUNCTIONS


=head2 LIN_read_configure

 Function Name   :: LIN_read_configure

 Description     :: Configures the given LIN tool (defined in Testbench) with given LIN configuration.
                    It fetches the name of already loaded configuration from CANoe through win32 OLE
                    and checks whether required and already loaded configurations are same.
                    If same nothing done. If not, loads the required configuration and starts measurement.

 Syntax          :: LIN_read_configure( );

 Input Arguments :: None

 Return Value(s) :: 1 -> offline mode and success
                    0 -> failure

 Example         ::  LIN_read_configure( );

=cut

######################################################

sub LIN_read_configure
{
    S_w2log( 4, "LIN_read_configure: Configures the LIN tool wiht LIN configuration \n" );

    my ( @devices, $ole_handle );

    $LIN_control->{'read'}{'Devices'} = [];
    @devices = EQUIP_get_devices( 'LIN_Access', 'read' );

    unless ( scalar @devices )
    {
        S_set_error( " LIN_read_configure : LIFT_Testbench->{Functions}{LIN_Access}{read} does not exist\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices )
    {
        S_set_error( " LIN_read_configure : configure 'CANoe' in LIFT_Testbench->{Functions}{LIN_Access}{read}\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    foreach my $device (@devices)
    {
        if ( $device =~ /CANoe/ix )
        {
            if ( $ole_handle = VEC_read_lin_configure($device) )
            {
                S_w2log( 3, "LIN_read_configure : device $device read configured \n" );
                push( @{ $LIN_control->{'read'}{'Devices'} }, $device );
                $LIN_control->{'read'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;
            }
            else
            {
                S_set_error( "LIN_read_configure : Couldnt configure $device for reading LIN signals\n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_read_LIN_signal
    
    ( Value , UNIT) = LIN_read_LIN_signal ( LIN_signal_name [, 'phys|hex' ] );
                    
                    
      Reads the Lin signal from Lin tool(s) which is/are configured in LIN_read_configure() Unit will be returned just when physical signal value is requested.

B<Arguments:>

=over

=item $lin_signal_name 

Name of the LIN signal to be read from LIN Tool.

=item $mode 
(optional) Physical signal value or hexadecimal signal value (phys or hex (case insensitive))

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(1, 'dummy')     : Offline

(undef, undef) : Failure

=back

B<Examples:> 
                    Value = LIN_read_LIN_signal ( LIN_signal, 'phys');
                    ( Value, Unit ) = LIN_read_LIN_signal ( LIN_signal, 'hex');

=cut

######################################################
sub LIN_read_LIN_signal {
    
## DESIGN #######
    
    #COMMENT-START
        # get arguments 
        # - $lin_signal,
        # - $mode (optional)
    #COMMENT-END

    # STEP set default $mode = phys if not given    
    # IF $mode = either phys or Hex ?
    # IF-NO-START
        # STEP set read value = undef & set Error - mode neither phys or hex (raw).
    # IF-NO-END
    # IF-YES-START
         # IF execution mode?
             # IF-OFFLINE-START
                # STEP success case of phys mode - (return read value = 1 and unit = dummy)
             # IF-OFFLINE-END
             # IF-ONLINE-START
                # STEP check if device was configured or not ?
                # IF Device type ? 
                    #IF-CANoe-START
                        #COMMENT-START
                           # argument : -oleHandle, -$lin_signal, -$mode
                           # return :
                           #   1. $readvalue (raw or phys)
                           #   2. ($unit for phys, undef for raw)
                        #COMMENT-END
                        # CALL VEC_read_lin_signal
                    #IF-CANoe-END
                    #IF-NOT_CANoe-START
                      # STEP set read value = undef & set Error - Device type not CANoe.
                    #IF-NOT_CANoe-END                
             # IF-ONLINE-END             
    # IF-YES-END
    
    # STEP return read value

    my @args = @_;
    return (undef, undef) unless S_checkFunctionArguments( 'LIN_read_LIN_signal ($lin_signal_name [, $mode] )', @args );

    S_w2log( 4, " LIN_read_LIN_signal: Reads the LIN signal \n" );

    my $lin_signal_name = shift @args;
    my $mode            = shift @args;

    my ( $value, $unit);

    unless ( defined $mode ) {
        S_w2log( 4, " LIN_read_LIN_signal : no mode (phys/hex) given , set to 'phys' per default )\n" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( "LIN_read_LIN_signal : Mode shall be either phys or hex (case insensitive) \n", 114 );
        return ( undef, undef );
    }

    S_w2log( 3, "LIN_read_LIN_signal: Reads the LIN signal $lin_signal_name with mode $mode\n" );

    return ( 1, 'dummy') if $main::opt_offline;

    unless ( defined( @{ $LIN_control->{'read'}{'Devices'} } ) ) {
        S_set_error( "no LIN access read configured , LIN_read_LIN_signal is calling Lin_read_configure \n", 0 );
        unless ( LIN_read_configure() ) {
            S_set_error( "Couldnt configure devices for LIN_access read \n", 131 );
            return ( undef, undef );
        }
    }

    foreach my $device ( @{ $LIN_control->{'read'}{'Devices'} } ) {
        if ( $device =~ /CANoe/ix ) {
            ( $value, $unit ) = VEC_read_lin_signal( $LIN_control->{'read'}{$device}{'OLE_handle'}, $lin_signal_name, $mode );
            S_w2log( 3, " LIN_read_LIN_signal : $lin_signal_name = $value , unit = $unit for mode = $mode \n" );
            return ( $value, $unit );
        }
        else {
            S_set_error( " LIN_read_LIN_signal : Device type is not CANoe\n", 131 );
            return ( undef, undef );
        }
    }
}
######################################################

=head2 LIN_write_configure

 Function Name   :: LIN_write_configure

 Description     :: Configures the given LIN tool (defined in Testbench) with given LIN configuration that LIN signals can be writen immediately.
                    It fetches the name of already loaded configuration from CANoe through win32 OLE
                    and checks whether required and already loaded configurations are same.
                    If same nothing done. If not, stops the running measurement and loads the required configuration and starts measurement.

 Syntax          :: LIN_write_configure( );

 Input Arguments :: None

 Return Value(s) :: 1 -> offline mode and success
                    0 -> failure

 Example         ::  LIN_write_configure( );

=cut

######################################################
sub LIN_write_configure
{
    my ( @devices, $devices_text, $ole_handle, @valid_devices );

    S_w2log( 4, "LIN_write_configure: Configures the LIN tool to write LIN signals \n" );

    @devices = EQUIP_get_devices( 'LIN_Access', 'write' );

    unless ( scalar @devices )
    {
        S_set_error( " LIN_write_configure : LIFT_Testbench->{Functions}{LIN_Access}{write} does not exist\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices )
    {
        S_set_error( " LIN_write_configure : configure 'CANoe' in LIFT_Testbench->{Functions}{LIN_Access}{write}\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    $LIN_control->{'write'}{'Devices'} = [];

    foreach my $device (@devices)
    {
        if ( $device =~ /CANoe/ix )
        {
            if ( $ole_handle = VEC_write_lin_configure($device) )
            {
                S_w2log( 3, " LIN_write_configure : device $device write configured \n" );
                push( @{ $LIN_control->{'write'}{'Devices'} }, $device );
                $LIN_control->{'write'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;
            }
            else
            {
                S_set_error( " LIN_write_configure : Couldnt configure $device for writing LIN signals\n", 131 );
                return 0;
            }
        }
    }

}

######################################################


=head2 LIN_write_LIN_signal
    
    returnvalue = LIN_write_LIN_signal ( given_lin_signal_name , Signal_Value [, mode] );
                    
             Write Lin signal from Lin tool(s) which was/were configured in LIN_write_configure()
             
B<Arguments:>

=over

=item $given_lin_signal_name 

Name of the LIN signal

=item $Signal_Value 

LIN signal value

=item $mode 

(optional) physical signal value or hexadecimal signal value (phys or hex (case insensitive))

=back

B<Return Value:>

=item $returnValue 

1 : Successful and in offline

undef : Failure

=back

B<Examples:> 

LIN_write_LIN_signal(LIN_signal_name, Signal_value, 'phys');

=cut

######################################################
sub LIN_write_LIN_signal {

    ## DESIGN 
    
    # COMMENT-START
       # Get arguments 
       #  - $lin_signal_name, 
       #  - $lin_signal_value, 
       #  - $mode (optional)
    # COMMENT-END
    
    # STEP set default $mode = 'phys' if not defined
    # IF $mode = either phys or Hex ?
        # IF-NO-START
            # STEP writing status = undef and set Error - mode neither phys or hex (raw).
        # IF-NO-END
        
        # IF-YES-START
            # IF execution mode?
                # IF-OFFLINE-START
                    # STEP success case of phys mode - (return write = 1)
                # IF-OFFLINE-END
                
                # IF-ONLINE-START
                    # STEP check if device was configured or not ?                        
                        # IF Device type ? 
                           #IF-NOT_CANoe-START
                               # STEP write status = undef & set Error - Device type not CANoe.
                           #IF-NOT_CANoe-END
                           #IF-CANoe-START
                               # STEP write '$lin_signal_name' the  '$lin_signal_value' with mode '$mode'
                               # CALL VEC_write_lin_signal                               
                           #IF-CANoe-END
                # IF-ONLINE-END         
        # IF-YES-END        
                
    # STEP return the write status

    my @args = @_;
    return unless S_checkFunctionArguments( 'LIN_write_LIN_signal ($given_lin_signal_name, $signal_value [,$mode] )', @args );

    my $given_lin_signal_name = shift @args;
    my $signal_value          = shift @args;
    my $mode                  = shift @args;

    my ( $return_value, );

    unless ( defined $mode ) {
        S_w2log( 4, " LIN_write_LIN_signal : no mode (phys/hex) given , set to phys\n" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( " LIN_write_LIN_signal : Mode shall be either 'phys' or 'hex' (case insensitive)\n", 114 );
        return;
    }

    S_w2log( 3, "LIN_write_LIN_signal: Writes signal $given_lin_signal_name with value $signal_value \n" );

    return 1 if $main::opt_offline;

    unless ( defined( @{ $LIN_control->{'write'}{'Devices'} } ) ) {
        S_set_error( " no LIN access write configured , LIN_write_LIN_signal is calling LIN_write_configure \n", 0 );
        unless ( LIN_write_configure() ) {
            S_set_error( " Couldnt configure devices for LIN access write \n", 131 );
            return;
        }
    }

    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } ) {
        if ( $device eq "CANoe" ) {
            ### info from LIN mapping just needed for CANoe at the moment

            if ( $return_value = VEC_write_lin_signal( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_signal_name, $signal_value, $mode ) ) {
                S_w2log( 3, " LIN_write_LIN_signal : $given_lin_signal_name = $signal_value ( $mode ) \n" );
                return $return_value;
            }
            else {
                S_set_error( " LIN_write_LIN_signal : Couldnt write '$given_lin_signal_name' from $device\n", 131 );
                return;
            }
        }
        else {
            S_set_error( " LIN_write_LIN_signal : Device type is not CANoe\n", 131 );
            return;
        }
    }
}

######################################################

=head2 LIN_disable_frame (arbitrary example given)

 Function Name   :: LIN_disable_frame

 Description     :: checks whether LIN Tool is configured. If not , it will call LIN_write_configure();
                    function controls CAPL env variable 'CANOE_DISABLE' as defined in LIN mapping by setting it to 1. 
					( Incase of old implementation, we continue to set to 1 )

 Syntax          :: LIN_disable_frame (LIN_frame [ , time_out_info  ] );

 Input Arguments :: LIN_frame - name of LIN frame as used in LIN mapping
                    time_out_info - additional info value (optional parameter)

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_disable_frame (LIN_frame);
 
=cut

######################################################
sub LIN_disable_frame
{
    ## LIN_write_configure have to called before
    ## use out function VEC_disable_lin_frame() of STEPS_vector_lintool

    my ( $given_lin_frame, $time_out_info ) = @_;

    unless ( defined $given_lin_frame )
    {
        S_set_error( " Too Less params ! SYNTAX: LIN_disable_frame( LIN_frame [, Timeout ] )\n", 110 );
        return 0;
    }

    S_w2log( 3, "LIN_disable_frame: Disables the frame $given_lin_frame \n" );

    return 1 if $main::opt_offline;

    my ( $return_value, $devices_text );

    unless ( defined( @{ $LIN_control->{'write'}{'Devices'} } ) )
    {
        S_set_error( " no LIN access write configured , LIN_disable_frame is calling LIN_write_configure \n", 0 );
        unless ( LIN_write_configure() )
        {
            S_set_error( " Couldnt configure devices to disable the LIN frame \n", 131 );
            return 0;
        }
    }

    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_disable_lin_frame( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_frame, $time_out_info ) )
            {
                S_w2log( 3, " LIN_disable_frame : $given_lin_frame disabled \n" );
                return $return_value;
            }
            else
            {
                S_set_error( " LIN_disable_frame : Couldnt disable '$given_lin_frame' from $device\n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_enable_frame (arbitrary example given)

 Function Name   :: LIN_enable_frame

 Description     :: checks whether LIN Tool is configured. If not , it will call LIN_write_configure();
                    function controls CAPL env variable 'CANOE_DISABLE' as defined in LIN mapping by setting it to 0.
					( Incase of old implementation, we continue to set to 0 )

 Syntax          :: LIN_enable_frame ( LIN_frame );

 Input Arguments :: LIN_frame - name of LIN frame as used in LIN mapping

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_enable_frame( LIN_frame);
 
=cut

######################################################
sub LIN_enable_frame
{
    ## LIN_write_configure have to called before
    ## use out function VEC_enable_lin_frame() of STEPS_vector_cantool

    my $given_lin_frame = shift;

    unless ( defined $given_lin_frame )
    {
        S_set_error( " Too Less Params ! SYNTAX: LIN_enable_frame( LIN_frame )", 110 );
        return;
    }

    S_w2log( 3, "LIN_enable_frame: Enables the fran $given_lin_frame \n" );
    return 1 if $main::opt_offline;

    my ( $return_value, $devices_text, @devices, );

    unless ( defined( @{ $LIN_control->{'write'}{'Devices'} } ) )
    {
        S_set_error( " no LIN access write configured , LIN_enable_frame is calling LIN_write_configure \n ", 0 );
        unless ( LIN_write_configure() )
        {
            S_set_error( " Couldnt configure devices to enable the LIN frame \n", 131 );
            return 0;
        }
    }

    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_enable_lin_frame( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_frame ) )
            {
                S_w2log( 3, " LIN_enable_frame : $given_lin_frame enabled\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " LIN_enable_frame : Couldnt enable '$given_lin_frame' from $device\n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_set_DLC

 Function Name   :: LIN_set_DLC

 Description     :: checks whether LIN Tool is configured. If not , it will call LIN_write_configure();
                    function controls CAPL env variable 'CANOE_DLC' as defined in LIN mapping.

 Syntax          :: LIN_set_DLC ( LIN_frame [, DLC ] );

 Input Arguments :: LIN_frame - name of LIN frame as used in LIN mapping
                    DLC - new value for the DLC of LIN frame (optional). If not given , reads it from LIN mapping file.

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_set_DLC( 'InsErk_Komponummer_Endtestgeraet');

=cut

######################################################
sub LIN_set_DLC
{
    ## LIN_write_configure have to called before
    ## use out function VEC_LIN_set_DLC() of LIFT_vector_lintool

    my ( $given_lin_frame, $given_DLC ) = @_;

    unless ( defined $given_lin_frame )
    {
        S_set_error( " Too Less Params ! SYNTAX: LIN_set_DLC( LIN_frame [, DLC] ) \n", 110 );
        return 0;
    }

    my $LIN_mapping = $main::ProjectDefaults->{"Mapping_LIN"};

    unless (%$LIN_mapping)
    {
        S_set_error( " LIN_set_DLC : Mapping_LIN is not defined in LIFT ProjectDefaults \$Defaults->{Mapping_LIN}\n", 20 );
        return 0;
    }

    unless ( defined $given_DLC )
    {
        S_w2log( 3, " LIN_set_DLC : DLC for the frame read from LIN Mapping file \n" );
        $given_DLC = $LIN_mapping->{'LIN_MESSAGES'}{$given_lin_frame}{'DLC'};
        unless ( defined $given_DLC )
        {
            S_set_error( " LIN_set_DLC : LIN Frame $given_lin_frame doesnot contain 'DLC' in Mapping_LIN \n", 20 );
            return 0;
        }
    }
    S_w2log( 3, "LIN_set_DLC: set DLC $given_DLC for frame $given_lin_frame \n" );

    return 1 if $main::opt_offline;

    my ( $return_value, $devices_text, @devices, );

    # unless ( $device = $LIN_control->{'write'}{'Devices'}[0] )
    unless ( defined( @{ $LIN_control->{'write'}{'Devices'} } ) )
    {
        S_set_error( " no LIN access write configured , LIN_write_LIN_signal is calling LIN_write_configure \n ", 0 );
        unless ( LIN_write_configure() )
        {
            S_set_error( " Couldnt configure devices to set the DLC of the given frame ", 131 );
        }
    }

    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_LIN_set_DLC( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_frame, $given_DLC ) )
            {
                S_w2log( 3, " LIN_set_DLC : $given_lin_frame DLC set\n" );
                return 1;
            }
            else
            {
                S_set_error( " LIN_set_DLC : Couldnt set the DLC of frame '$given_lin_frame' from $device\n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_reset_DLC

 Function Name   :: LIN_reset_DLC

 Description     :: checks whether LIN Tool is configured. If not , it will call LIN_write_configure();
                    function controls CAPL env variable 'CANOE_DLC' , 'DLC' as defined in LIN mapping

 Syntax          :: LIN_reset_DLC ( LIN_frame [ , DLC ]);

 Input Arguments :: LIN_frame - name of LIN frame as used in LIN mapping
                    DLC - DLC to be reset
                    Its optional parameter. If not given , its read from LIN mapping file.

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_reset_DLC ( 'InsErk_Komponummer_Endtestgeraet');

=cut

######################################################
sub LIN_reset_DLC
{
    ## LIN_write_configure have to called before
    ## use out function VEC_LIN_reset_DLC() of LIFT_vector_cantool

    my ( $given_lin_frame, $given_DLC, ) = @_;

    unless ( defined $given_lin_frame )
    {
        S_set_error( " Too Less Params! SYNTAX: LIN_reset_DLC( LIN_frame )", 110 );
        return;
    }

    my $LIN_mapping = $main::ProjectDefaults->{"Mapping_LIN"};

    unless (%$LIN_mapping)
    {
        S_set_error( " LIN_reset_DLC : Mapping_LIN is not defined in LIFT ProjectDefaults \$Defaults->{Mapping_LIN} \n", 20 );
        return 0;
    }

    unless ( defined $given_DLC )
    {
        S_w2log( 3, " LIN_reset_DLC : DLC for the frame read from LIN Mapping file\n" );
        $given_DLC = $LIN_mapping->{'LIN_MESSAGES'}{$given_lin_frame}{'DLC'};

        unless ( defined $given_DLC )
        {
            S_set_error( " LIN_reset_DLC : LIN Frame $given_lin_frame doesnot contain 'DLC' in Mapping_LIN \n", 20 );
            return 0;
        }
    }

    S_w2log( 3, "LIN_reset_DLC:  reset DLC $given_DLC for frame $given_lin_frame \n" );

    return 1 if $main::opt_offline;

    my ( $return_value, $devices_text, @devices, );

    unless ( defined( @{ $LIN_control->{'write'}{'Devices'} } ) )
    {
        S_set_error( " no LIN access write configured , LIN_write_LIN_signal is calling LIN_write_configure \n", 0 );
        unless ( LIN_write_configure() )
        {
            S_set_error( " Couldnt configure devices to reset the DLC of the given frame ", 131 );
            return 0;
        }
    }

    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_LIN_reset_DLC( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_frame, $given_DLC ) )
            {
                S_w2log( 3, " LIN_reset_DLC : $given_lin_frame DLC reset\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " LIN_reset_DLC : Couldnt reset DLC of frame '$given_lin_frame' from $device\n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_trace_configure

 Function Name   :: LIN_trace_configure

 Description     :: fetches the devices configured for trace from Testbench.
                    prepares LIN tool( i.e., CANOE ) that the trace can be started immediately

 Syntax          :: LIN_trace_configure ( );

 Input Arguments :: None

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_trace_configure ( );

=cut

######################################################
sub LIN_trace_configure
{
    my ( @devices, $devices_text, $ole_handle, @valid_devices );

    $LIN_control->{'trace'}{'Devices'} = [];

    @devices = EQUIP_get_devices( 'LIN_Access', 'trace' );

    unless ( scalar @devices )
    {
        S_set_error( " LIN_trace_configure : LIFT_Testbench->{Functions}{LIN_Access}{trace} does not exist\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices )
    {
        S_set_error( " LIN_trace_configure : configure 'CANoe' in LIFT_Testbench->{Functions}{LIN_Access}{trace}\n", 21 );
        return;
    }

    S_w2log( 4, "LIN_trace_configure: Fetches the devices configured for trace \n" );

    return 1 if $main::opt_offline;

    foreach my $device (@devices)
    {
        if ( $device eq "CANoe" )
        {
            if ( $ole_handle = VEC_trace_configure($device) )
            {
                S_w2log( 3, " LIN_trace_configure : device $device trace configured \n" );
                push( @{ $LIN_control->{'trace'}{'Devices'} }, $device );
                $LIN_control->{'trace'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;
            }
            else
            {
                S_set_error( " LIN_trace_configure : could not configure LIN trace on device(s) $device  \n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_trace_start

 Function Name   :: LIN_trace_start

 Description     :: start measurement of LIN tool( CANOE ) , which must be configured before with LIN_trace_configure().
                    if the measurement is already running (because of use of LIN_read_configure() before)
                    the measurment will be stopped and started again immediately to start an new log file.

 Syntax          :: LIN_trace_start ( );

 Input Arguments :: None

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_trace_start ( );

=cut

######################################################
sub LIN_trace_start
{

    S_w2log( 4, " LIN_trace_start: starts measurement of LIN tool \n" );

    if ($main::opt_offline)
    {
        return 1;
    }

    unless ( defined( @{ $LIN_control->{'trace'}{'Devices'} } ) )
    {
        S_set_error( " no LIN access trace configured , LIN_trace_start is calling LIN_trace_configure \n", 0 );
        unless ( LIN_trace_configure() )
        {
            S_set_error( " LIN_trace_start : Couldnt configure devices for LIN access trace\n ", 131 );
            return 0;
        }
    }

    foreach my $device ( @{ $LIN_control->{'trace'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( VEC_check_running( $LIN_control->{'trace'}{$device}{'OLE_handle'} ) )
            {
                unless ( VEC_stop_measurement( $LIN_control->{'trace'}{$device}{'OLE_handle'} ) )
                {
                    S_set_error( "LIN_trace_start : Couldnt stop $device measurement\n", 131 );
                    return 0;
                }
            }
           
            unless ( VEC_start_measurement( $LIN_control->{'trace'}{$device}{'OLE_handle'} ) )
            {
                S_set_error( " LIN_trace_start : Couldnt start $device measurement", 131 );
                return 0;
            }
            
            S_w2log( 3, "LIN_trace_start : LIN Trace started successful on $device\n" );
        }
    }

    return 1;
}

######################################################

=head2 LIN_trace_stop

 Function Name   :: LIN_trace_stop

 Description     :: stops measurement of LIN tool which must be
                    configured before with LIN_trace_configure() and
                    started measurement with LIN_trace_start().

 Syntax          :: LIN_trace_stop ( );

 Input Arguments :: None

 Return Value(s) :: 1 -> offline mode , Success
                    0 -> failure

 Example         :: LIN_trace_stop ( );

=cut

######################################################
sub LIN_trace_stop
{
    S_w2log( 4, " LIN_trace_stop: stops measurement of LIN tool\n" );

    return 1 if $main::opt_offline;

    foreach my $device ( @{ $LIN_control->{'trace'}{'Devices'} } )
    {
        if ( $device eq "CANoe" )
        {
            my $return_value = VEC_check_running( $LIN_control->{'trace'}{$device}{'OLE_handle'} );
            if ( not defined $return_value )
            {
                S_set_error( " LIN_trace_stop : error while checking running LIN trace \n", 131 );
                return 0;
            }
            elsif ( $return_value == 1 )
            {
                S_w2log( 5, " LIN_trace_stop : LIN trace still running\n" );
                unless ( VEC_stop_measurement( $LIN_control->{'trace'}{$device}{'OLE_handle'} ) )
                {
                    S_set_error( " Couldnt stop measurement on $device \n", 131 );
                    return 0;
                }
                S_w2log( 3, " LIN_trace_stop : LIN Trace stopped successfully \n" );
                return 1;
            }
            elsif ( $return_value == 0 )
            {
                S_w2log( 3, " LIN_trace_stop : LIN trace not running. Hence no need to stop\n" );
                return 1;
            }
        }
    }
}

######################################################

=head2 LIN_trace_check_running

 Function Name   :: LIN_trace_check_running

 Description     :: checks if the trace is still running on LIN tool (CANOE ).

 Syntax          :: return_value = LIN_trace_check_running ( );

 Input Arguments :: None

 Return Value(s) :: return_value = 1 -> LIN trace still running, Offline run
                    return_value = 0 -> LIN trace not running, Error

 Example         :: return_value = LIN_trace_check_running ( );

=cut

######################################################
sub LIN_trace_check_running
{

    S_w2log( 4, " LIN_trace_check_running: checks the trace is still running\n" );

    return 1 if $main::opt_offline;

    foreach my $device ( @{ $LIN_control->{'trace'}{'Devices'} } )
    {
        if ( $device eq "CANoe" )
        {
            my $return_value = VEC_check_running( $LIN_control->{'trace'}{$device}{'OLE_handle'} );
            if ( $return_value == 1 )
            {
                S_w2log( 3, " LIN_trace_check_running : LIN trace still running\n" );
                return 1;
            }
            elsif ( $return_value == 0 )
            {
                S_w2log( 3, " LIN_trace_check_running : LIN trace not running\n" );
                return 1;
            }
            else
            {
                S_set_error( " error while checking running LIN trace \n", 131 );
                return 0;
            }
        }
    }
}

######################################################

=head2 LIN_trace_store

 Function Name   :: LIN_trace_store

 Description     :: stores trace of LIN tool measurement configured before with LIN_trace_configure() and
                    started with LIN_trace_start(). It copies the trace to a file whose complete path name
                    $store_file_name or "LIFT_LIN_trace_date_extension.asc".

 Syntax          :: file_name_stored = LIN_trace_store ( [ $store_file_name ] );

 Input Arguments :: $store_file_name - optional parameter

 Return Value(s) :: $store_file_name - returns the trace file name
                    1 - offline
                    0 - Failure

 Example         :: file_name_stored = LIN_trace_store ( );
                    file_name_stored = LIN_trace_store ('D:\MKS\TurboLIFT\MLB\reports\CANoe_Log\canoe_lin_testing.asc');

=cut

######################################################
sub LIN_trace_store
{
    my $store_file_name = shift;

    my $returned_store_file_name;

    S_w2log( 4, "LIN_trace_store: stores trace of LIN tool measurement \n" );

    return 1 if $main::opt_offline;

    foreach my $device ( @{ $LIN_control->{'trace'}{'Devices'} } )
    {
        if ( $device eq "CANoe" )
        {
                unless ( $returned_store_file_name = VEC_trace_store( $LIN_control->{'trace'}{$device}{'OLE_handle'}, $store_file_name ) )
                {
                    S_set_error( " LIN_trace_store: could not store the LIN trace \n", 131 );
                    return 0;
                }
        }
    }

    S_w2log( 3, " LIN_trace_store: LIN trace stored successfully at $returned_store_file_name\n" );

    my $trace_asc_link =
<<EOHTML;
    <TR>
        <TD ALIGN="CENTER">$returned_store_file_name Trace File : <A HREF="$returned_store_file_name">$returned_store_file_name</A> </TD>
    </TR>
EOHTML

    S_w2rep($trace_asc_link);

    return $returned_store_file_name;
}

######################################################

=head2 LIN_trace_get_dataref

 Function Name   :: LIN_trace_get_dataref

 Description     :: Reads a trace file $data_file_name and writes the data
                    of all signals of @label_list into a hash-tree and returns the reference
                    to that hash-tree. The hash-tree is defined as shown below.

 Syntax          :: data_ref = Lin_trace_get_dataref ( $data_file_name , \@label_list );

 Input Arguments :: $data_file_name - trace file
                    \@label_list - aref

 Return Value(s) :: data_ref - hash tree

 Example         :: data_ref = Lin_trace_get_dataref ( $data_file_name , @label_list );

    Structure of returned trace_data_ref is:
        $data_ref = {
                        'timestamp_1' => {
                                       'message_A' => {
                                                        'DATA_A' => 'phys_value_at_time_1' ,
                                                        'DLC_A' => 'DLC_A',
                                                       }
                                       'signal_1' => 'phys_value_at_time_1',
                                       'signal_2' => 'phys_value_at_time_1',
                                       'message_B' => {
                                                        'DATA_B' => 'phys_value_at_time_1' ,
                                                        'DLC_B' => 'DLC_B',
                                                      }
                                       'signal_3' => 'phys_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                      'message_A' => {
                                                        'DATA_A' => 'phys_value_at_time_2' ,
                                                        'DLC_A' => 'DLC_A',
                                                       }
                                        'signal_1' => 'phys_value_at_time_2',
                                       'signal_2' => 'phys_value_at_time_2',
                                       'message_B' => {
                                                        'DATA_B' => 'phys_value_at_time_2' ,
                                                        'DLC_B' => 'DLC_B',
                                                      }
                                       'signal_3' => 'phys_value_at_time_2',
                                          },
                     };
    <Note : This function is same as CA_trace_get_dataref >

=cut

######################################################
sub LIN_trace_get_dataref
{
    my $data_file_name = shift;
    my @label_list     = @_;

    my $data_href = {};

    unless (@label_list)
    {
        S_set_error( " LIN_trace_get_dataref : Too Less Params ! SYNTAX: LIN_trace_get_dataref ( data_file_name , label_list )", 110 );
        return {};
    }

    unless ( $data_href = VEC_trace_lin_get_dataref( $data_file_name, @label_list ) )
    {
        S_set_error( " LIN_trace_get_dataref : Couldnt get data structure for $data_file_name", 131 );
        return {};
    }
    S_w2log( 3, "LIN_trace_get_dataref: Read a trace file $data_file_name \n" );
    return $data_href;
}

######################################################

=head2 LIN_get_LIN_signal_info

 Function Name   :: LIN_get_LIN_signal_info

 Description     :: returns hash reference containing the signal info of the given signal from LIFT LIN Mapping module.

 Syntax          :: lin_signal_info = LIN_get_LIN_signal_info ( LIN_signal_name );

 Input Arguments :: LIN_signal_name - LIN signal name as in LIN mapping file

 Return Value(s) :: $lin_signal_info - hash tree

 Example         :: lin_signal_info = LIN_get_LIN_signal_info ( 'InsErk_Endtestgeraet_Byte2' );

     signal info:
         'InsErk_Endtestgeraet_Byte2'  =>
                      {
                        'SIGNAL_NAME'   => 'InsErk_Endtestgeraet_Byte2',
                        'CANOE_ENV_VAR' => 'EnvMasterResp01_Sig01_',
                        'SENDER'        => 'LIN_Master',
                        'MESSAGE'       => 'InsErk_Komponummer_Endtestgeraet',
                        'MULTIPLEX'     => undef,
                        'STARTBIT'      => '0',
                        'LENGTH'        => '8',
                        'OFFSET'        => '0',
                        'FACTOR'        => '0',
                        'FORMAT'        => 'INTEL',
                        'TYPE'          => 'UNSIGNED',
                        'UNIT'          => 'NO_UNIT',
                        'INIT'          => '1',     ## verify INIT value with specifications
                      },


    Message info :
       'InsErk_Komponummer_Endtestgeraet'  =>
                      {
                        'ID'            => '57', #in decimal
                        'DLC'           => '1',
                        'SENDER'        => 'LIN_Master',
                        'CAN_BUS_NBR'   => '1',
                        'CYCLE'         => undef,
                        'CANOE_DISABLE' => undef,
                        'CANOE_DLC'     => undef,
                      },


=cut

######################################################
sub LIN_get_LIN_signal_info
{
    my ($lin_signal_name) = shift;

    my ( $lin_signal_info, $message );

    unless ( defined $lin_signal_name )
    {
        S_set_error( " Too Less Params !SYNTAX: LIN_get_LIN_signal_info( lin_signal_name ) \n", 110 );
        return {};
    }

    my $LIN_mapping = $main::ProjectDefaults->{"Mapping_LIN"};

    unless (%$LIN_mapping)
    {
        S_set_error( " LIN_get_LIN_signal_info : Mapping_LIN is not defined in LIFT ProjectDefaults \$Defaults->{Mapping_LIN}\n", 20 );
        return {};
    }
    unless ( $lin_signal_info = $LIN_mapping->{$lin_signal_name} )
    {
        S_set_error( " LIN_mapping doesnot contain info for signal : '$lin_signal_name' \n", 20 );
        return {};
    }

    unless ( $message = $lin_signal_info->{'MESSAGE'} )
    {
        S_set_error( " LIN_mapping doesnot contain 'MESSAGE' for signal : '$lin_signal_name' \n", 20 );
        return {};
    }

    unless ( $lin_signal_info->{'MESSAGE_INFO'} = $LIN_mapping->{'LIN_MESSAGES'}{$message} )
    {
        S_set_error( " LIN_mapping doesnot contain 'LIN_MESSAGES' info for message 'MESSAGE' for signal : '$message' \n", 20 );
        return {};
    }

    S_w2log( 3, "LIN_get_LIN_signal_info: Read the signal info for signal $lin_signal_name :: $lin_signal_info \n" );
    return $lin_signal_info;
}

######################################################

=head2 LIN_get_LIN_message_info

 Function Name   :: LIN_get_LIN_message_info

 Description     :: returns hash reference containing the message info for the given message from LIFT LIN Mapping module.

 Syntax          :: lin_message_info = LIN_get_LIN_message_info ( lin_message_name );

 Input Arguments :: lin_message_name - LIN Message name as in LIN mapping file

 Return Value(s) :: lin_message_info - hash tree
                    0 - Failure

 Example         :: lin_message_info = LIN_get_LIN_message_info ( 'InsErk_Komponummer_Endtestgeraet' );

  Message info from mapping file:

       'InsErk_Komponummer_Endtestgeraet'  =>
                      {
                        'ID'            => '57', #in decimal
                        'DLC'           => '1',
                        'SENDER'        => 'LIN_Master',
                        'CAN_BUS_NBR'   => '1',
                        'CYCLE'         => undef,
                        'CANOE_DISABLE' => undef,
                        'CANOE_DLC'     => undef,
                      },


=cut

######################################################
sub LIN_get_LIN_message_info
{
    my $lin_message_name = shift;

    my $lin_msg_info;
    my @signals;

    unless ( defined $lin_message_name )
    {
        S_set_error( "Too Less Params ! SYNTAX: LIN_get_LIN_message_info( $lin_message_name ) \n", 110 );
        return {};
    }

    my $LIN_mapping = $main::ProjectDefaults->{"Mapping_LIN"};

    unless (%$LIN_mapping)
    {
        S_set_error( " LIN_get_LIN_message_info : Mapping_LIN is not defined in LIFT ProjectDefaults \$Defaults->{Mapping_LIN}\n", 20 );
        return {};
    }

    unless ( $lin_msg_info = $LIN_mapping->{'LIN_MESSAGES'}{$lin_message_name} )
    {
        S_set_error( " LIN_mapping doesnt contain info for message : '$lin_message_name' \n", 20 );
        return {};
    }

    foreach my $signal ( keys %$LIN_mapping )
    {
        next unless "HASH" eq ref $LIN_mapping->{$signal};
        push( @signals, $signal ) if $lin_message_name eq $LIN_mapping->{$signal}{'MESSAGE'};
    }

    $lin_msg_info->{'LIN_SIGNALS'} = \@signals;

    S_w2log( 3, "LIN_get_LIN_message_info: Read the message info for signal $lin_message_name \n" );
    return $lin_msg_info;
}

######################################################

=head2 LIN_calc_hex_to_phys

 Function Name   :: LIN_calc_hex_to_phys

 Description     :: Converts the Hex Value of signal into its physical Value.

 Syntax          :: phys_value = LIN_calc_hex_to_phys ( LIN_Signal_info , Hex_Value );

 Input Arguments :: LIN_Signal_info - hash reference containing the signal info from LIFT LIN Mapping module plus the message info
                    Hex_Value - Hex value of the signal

 Return Value(s) :: phys_value - physical value of the signal whose hex value is given
                    0 - failure

 Example         :: phys_value = LIN_calc_hex_to_phys ( 'AB_Sg_Init_Info_CompID' , 1 );

  SIGNAL info from mapping file:

        'AB_Sg_Init_Info_CompID'  =>
                      {
                        'SIGNAL_NAME'   => 'AB_Sg_Init_Info_CompID',
                        'CANOE_ENV_VAR' => 'S_AB_Sg_Init_Info_AB_Sg_Init_Info_CompID', #proper format
                        'SENDER'        => 'LIN_Master',
                        'MESSAGE'       => 'AB_Sg_Init_Info',
                        'MULTIPLEX'     => undef,
                        'STARTBIT'      => '0',
                        'LENGTH'        => '8',
                        'OFFSET'        => '0',
                        'FACTOR'        => '0',
                        'FORMAT'        => 'INTEL',
                        'TYPE'          => 'UNSIGNED',
                        'UNIT'          => 'NO_UNIT',
                        'INIT'          => '1',     ## verify INIT value with specifications
                      },
=cut

######################################################
sub LIN_calc_hex_to_phys
{
    my ( $lin_signal_info, $hex_value ) = @_;

    unless ( defined $hex_value )
    {
        S_set_error( " Too Less Params ! SYNTAX: LIN_get_LIN_signal_info( lin_signal_info , hex_value )", 110 );
        return 0;
    }

    my ( $phys_value, $sig_offset, $sig_type, $sig_factor, $signal_name, );

    unless ( $signal_name = $lin_signal_info->{'SIGNAL_NAME'} )
    {
        S_set_error( " no 'SIGNAL_NAME' defined for given LIN signal\n", 109 );
        return 0;
    }

    $sig_offset = $lin_signal_info->{'OFFSET'};
    unless ( defined $sig_offset )
    {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return 0;
    }
    $sig_type = $lin_signal_info->{'TYPE'};
    unless ( defined $sig_type )
    {
        S_set_error( " no 'TYPE' defined for signal '$signal_name' \n", 109 );
        return 0;
    }

    $sig_factor = $lin_signal_info->{'FACTOR'};
    unless ( defined $sig_factor )
    {
        S_set_error( " no 'FACTOR' defined for LIN signal '$signal_name' \n", 109 );
        return 0;
    }

    $phys_value = ( hex ( $hex_value ) * $sig_factor ) + $sig_offset;    
    
    S_w2log( 3, "LIN_calc_hex_to_phys Transformation '$signal_name' : $phys_value (phys) = ( $hex_value (hex) * $sig_factor (factor) + $sig_offset (offset)) \n" );

    return $phys_value;
}




=head2 LIN_init

    LIN_init();

=cut

sub LIN_init{
    
    my $functionAreas_href = VEC_init ( 'LIN_Access' );
    EQUIP_set_devices ( 'LIN_Access' , $functionAreas_href );

    my $funcLib_href = S_get_contents_of_hash( ['Functions', 'LIN_Access'], $LIFT_config::LIFT_Testbench );
    
    foreach my $functionGroup ( keys %{ $funcLib_href } ) {
        my $devices_mix = $funcLib_href->{$functionGroup};
        my $number_of_devices = 0;
        if( ref( $devices_mix ) eq 'ARRAY' ) {
            $number_of_devices = @{ $devices_mix };
        }
        elsif( ref( $devices_mix ) eq '' ){
            $number_of_devices = 1 if defined $devices_mix;
        }
        else{
            # do nothing
        }
        next if $number_of_devices == 0;
        
        if( $functionGroup eq 'read' ){
            LIN_read_configure ( );
        }
        elsif( $functionGroup eq 'write' ){
            LIN_write_configure ( );
        }
        elsif( $functionGroup eq 'trace' ){
            LIN_trace_configure ( );
        }
        elsif( $functionGroup eq 'basic' ){
            LIN_read_configure ( );
            LIN_write_configure ( );
            LIN_trace_configure ( );
            #LIN_simulation_configure ( );
        }
        elsif( $functionGroup eq 'stimulate' ){
            #LIN_stimulate_configure ( );
        }
        else{
            S_set_error( "Invalid function group '$functionGroup' for 'LIN_Access' in LIFT_Testbenches.pm. Valid function groups are: basic, stimulate ( or read, write, trace ).", 20 );
            return;
        }
    }
    
    return $functionAreas_href;
    
}
######################################################################

=head2 LIN_set_invalidCRC

    return_value = LIN_set_invalidCRC ( LIN_message [ , method, number_of_cycles ]);

Set CRC error to lin_message.

B<Arguments:>

=over
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

Method value

=item  number_of_cycles

Number of cycles for which it should be made invalid 

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = LIN_set_invalidCRC ( 'seating', 'constant',24 );

=cut 

######################################################################

sub LIN_set_invalidCRC {
    ## DESIGN #######
    # STEP configure LIN Access write if not configured  
    # STEP check device type  
    #IF-CANoe-START
    # STEP device = CANoe  
              #CALL VEC_set_lin_crc_error
    #IF-CANoe-END
          #IF-NOT_CANoe-START
               # STEP set Error - Device type not CANoe.
          #IF-NOT_CANoe-END   
    # STEP return status   
    ## LIN_write_configure have to called before
    ## use out function VEC_set_CRC() of LIFT_vector_flxrtool
    my @args = @_;
    return unless S_checkFunctionArguments( 'LIN_set_invalidCRC( $given_lin_message [ , $method, $nbOfCycles ] )', @args );

    my $given_lin_message = shift @args;
    my $method            = shift @args;
    my $nbOfCycles        = shift @args;

    my ( $dev, $return_value );

    unless ( $dev = $LIN_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no LIN Access write configured , LIN_set_invalidCRC is calling LIN_write_configure ... ", 0 );
        unless ( LIN_write_configure() ) {
            S_set_error( " Could not configure devices for LIN Access write ", 131 );
            return;
        }
    }
   foreach my $device( @{$LIN_control->{'write'}{'Devices'}} )
   {
    #### Calling CANoe Device
    if ( $device eq "CANoe" ) {
        if ( $return_value = VEC_set_lin_crc_error( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_message, $method, $nbOfCycles ) ) {
            S_w2log( 3, " LIN_set_invalidCRC : $given_lin_message is set to CRC error\n" );
        }
        else {
            S_set_error( " LIN_set_invalidCRC : Could not create a CRC error for '$given_lin_message'\n", 131 );
            return;
        }
    }
   }
    return $return_value;
}

######################################################################

=head2 LIN_set_validCRC

    return_value = LIN_set_validCRC ( LIN_message [, method] );

Remove CRC error from lin_message.

B<Arguments:>

=over
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

Method value

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = LIN_set_validCRC ( 'seating' );
    return_value = LIN_set_validCRC ( 'seating', 'constant' );

=cut 

######################################################################

sub LIN_set_validCRC {
    ## LIN_write_configure have to called before
    ## use out function VEC_reset_CRC() of LIFT_vector_flxrtool

    my @args = @_;
    return unless S_checkFunctionArguments( 'LIN_set_validCRC( $given_lin_message [ , $method ] )', @args );

    my $given_lin_message = shift @args;
    my $method            = shift @args;

    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $LIN_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no LIN Access write configured , LIN_set_validCRC is calling LIN_write_configure ... ", 0 );
        unless ( LIN_write_configure() ) {
            S_set_error( " Could not configure devices for LIN Access write ", 131 );
            return;
        }
    }
   foreach my $device( @{$LIN_control->{'write'}{'Devices'}} )
   {
    #### Calling CANoe Device
    if ( $device eq "CANoe" ) {
        if ( $return_value = VEC_reset_lin_crc_error( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_message, $method ) ) {
            S_w2log( 3, " LIN_set_validCRC : CRC error removed for $given_lin_message\n" );
        }
        else {
            S_set_error( " LIN_set_validCRC : Could not remove CRC error for '$given_lin_message'\n", 131 );
            return;
        }
    }
   }
    return $return_value;
}


######################################################################

=head2 LIN_set_invalidBZ

    return_value = LIN_set_invalidBZ ( LIN_message [ , method , number_of_cycles ]);

Set BZ error to lin_message.

B<Arguments:>

=over
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

Method value

=item  Number of Cycles

Number of cycles for which it should remain invalid. 

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = LIN_set_invalidBZ ( 'seating' ,'constant', 25 );
    return_value = LIN_set_invalidBZ ( 'seating' );

=cut

######################################################################

sub LIN_set_invalidBZ {
    ## DESIGN #######

    # STEP configure LIN Access write if not configured  
    # STEP check device type  
    #IF-CANoe-START
    # STEP device = CANoe  
              #CALL VEC_set_lin_bz_error
    #IF-CANoe-END
          #IF-NOT_CANoe-START
               # STEP set Error - Device type not CANoe.
          #IF-NOT_CANoe-END   
    # STEP return status    
    ## LIN_write_configure have to called before
    ## use out function VEC_set_BZ() of LIFT_vector_flxrtool
    my @args = @_;
    return unless S_checkFunctionArguments( 'LIN_set_invalidBZ( $given_lin_message [ , $method ,$nbOfCycles ] )', @args );

    my $given_lin_message = shift @args;
    my $method            = shift @args;
    my $nbOfCycles        = shift @args;

    my ( $dev, $return_value );

    unless ( $dev = $LIN_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no LIN Access write configured , LIN_set_invalidBZ is calling LIN_write_configure ... ", 0 );
        unless ( LIN_write_configure() ) {
            S_set_error( " Could not configure devices for LIN Access write ", 131 );
            return;
        }
    }
    foreach my $device ( @{ $LIN_control->{'write'}{'Devices'} } ) {
        #### Calling CANoe Device
        if ( $device eq "CANoe" ) {
            if ( $return_value = VEC_set_lin_bz_error( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_message, $method, $nbOfCycles ) ) {
                S_w2log( 3, "LIN_set_invalidBZ : $given_lin_message is set to BZ error\n" );
            }
            else {
                S_set_error( " LIN_set_invalidBZ : Could not create a BZ error for '$given_lin_message'\n", 131 );
                return;
            }
        }
    }
        return $return_value;
    }

######################################################################

=head2 LIN_set_validBZ

    return_value = LIN_set_validBZ ( LIN_message [ , method] );

Remove BZ error from lin_message.

B<Arguments:>

=over
     
=item  LIN_message

LIN Message name as in LIN mapping file

=item  method

value for method

=back

B<Return Value:>

=over

=item Pass
    : 1
     
=item Error
    : undef
    
=item Offline mode
    : 1
     
=back

B<Examples:>

    return_value = LIN_set_validBZ ( 'seating' );
    return_value = LIN_set_validBZ ( 'seating', 'constant' );
    
=cut

######################################################################
sub LIN_set_validBZ {
    ## LIN_write_configure have to called before
    ## use out function VEC_reset_BZ() of LIFT_vector_flxrtool

    my @args = @_;
    return unless S_checkFunctionArguments( 'LIN_set_validBZ( $given_lin_message [ , $method ] )', @args );

    my $given_lin_message = shift @args;
    my $method            = shift @args;

    unless ( defined $given_lin_message ) {
        S_set_error( " Too Less Params ! SYNTAX: LIN_set_validBZ(LIN_message [ , method ])", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $LIN_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no LIN Access write configured , LIN_set_validBZ is calling LIN_write_configure ... ", 0 );
        unless ( LIN_write_configure() ) {
            S_set_error( " Could not configure devices for LIN Access write ", 131 );
            return;
        }
    }
   foreach my $device( @{$LIN_control->{'write'}{'Devices'}} )
   {
    #### Calling CANoe Device
    if ( $device eq "CANoe" ) {
        if ( $return_value = VEC_reset_lin_bz_error( $LIN_control->{'write'}{$device}{'OLE_handle'}, $given_lin_message, $method ) ) {
            S_w2log( 3, " LIN_set_validBZ : $given_lin_message is removed from BZ error\n" );
        }
        else {
            S_set_error( " LIN_set_validBZ : Could not remove a BZ error for '$given_lin_message'\n", 131 );
            return;
        }
    }
   }

    return $return_value;
}

######################################################################
######################################################################

=head2 LIN_get_lin_message_info

    Function Name     :: LIN_get_lin_message_info
    Description       :: hash reference containing the message info from LIFT LIN Mapping module
    Syntax            :: $lin_message_info = LIN_get_lin_message_info ( $lin_message_name );
    Input Arguments   :: $lin_message_name - array reference of the LIN message
    Return Value(s)   :: $lin_message_info - hash reference containing the message

=cut

######################################################################

sub LIN_get_lin_message_info
{
   my ($lin_message_name) = shift @_ ;

   my $returned_msg_info; my @signals;

   unless( defined $lin_message_name )
   {
      S_set_error( " Too Less Params ! SYNTAX: LIN_get_lin_message_info( $lin_message_name )", 110 );
      return {};
   }

   my $LIN_mapping = S_get_contents_of_hash(['Mapping_LIN']);

    unless( $LIN_mapping )
    {
        S_set_error( "LIFT LIN_mapping doesnot exist" , 20 );
        return {};
    }
   unless( $returned_msg_info = $LIN_mapping->{ 'LIN_MESSAGES' }{ $lin_message_name } )
   {
      S_set_error( " LIFT_LIN_Mapping does not contain info for message : '$lin_message_name'", 114 );
      return {};
   }
   foreach my $signal ( keys %$LIN_mapping )
   {
      next unless "HASH" eq ref $LIN_mapping->{$signal};
      push( @signals , $signal ) if $lin_message_name eq $LIN_mapping->{$signal}{'MESSAGE'};
   }
   $returned_msg_info->{'LIN_SIGNALS'} = \@signals;

   return $returned_msg_info;
}

1;

