# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_spi_database;

use strict;
use warnings;
use LIFT_general;
use Data::Dumper;
use XML::LibXML;
use Readonly;
use LIFT_numerics;

our ( $VERSION, $HEADER );

# SPI Maid decoding style table
Readonly::Hash my %SPI_MAID_DECODING_TABLE => {
    0 => 'None',
    1 => 'IF THEN',
    2 => 'Signed',
    3 => 'Unsigned',
    4 => 'Hex',
    5 => 'Parity',
    6 => 'CRC',
    7 => 'Range',
    8 => 'Equal'
};

=head1 NAME

LIFT_spi_database 

Record class of the EDR Test Framework

=head1 SYNOPSIS

    use LIFT_spi_database;

    LIFT_spi_database -> new();


=head1 DESCRIPTION

SPI database

###############################################################################

=head2 new

    $device_object = LIFT_spi_database -> new( $spiMaidProjectPath );

I<B<Description:>>     instances a new object of EDR record class -> record object

    mandatory:
                                    For other projects where there is only one response, this is it.

    optional: 
 
I<B<Return:>> Return the blessed (instanced) mosi command object.
              Return nothing if missing mandatory parameter

I<B<Verdict:>> none

I<B<Error:>> for missing mandatory parameters (see Description)

=cut

#------------------------ Constructor ------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $class = shift;    # Perl �bergibt als erstes eine Referenz auf die Klasse, dessen Methode gerufen wurde

    my $self = {
        SPI_NetworkNodes   => {},
        SPI_NetworkDevices => {},
    };

    S_w2log( 5, " Instancing new SPI database by running LIFT_spi_database -> new() \n" );

    bless $self, $class;

    my $dataBaseInitialized = $self->SPIDB_init();
    return unless ($dataBaseInitialized);

    # object $self is attached to the class $class
    return $self;
}

###############################################################################

=head2 GetNodeName

    $self -> GetNodeName($CS[, $SPI]);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetNodeName {

    #-------------------------------------------------------------------------------
    my $self = shift;
    my $cs   = shift;
    my $spi  = shift;

    unless ( defined $spi ) {
        S_w2log( 5, " SPI_database -> GetNodeName(): Setting SPI bus nbr to default value '1'\n" );
        $spi = 1;
    }

    my $nodeName;
    foreach my $thisNodeName ( keys %{ $self->{SPI_NetworkNodes} } ) {
        my ( $thisCS, $thisSPInbr ) = $self->{SPI_NetworkNodes}->{$thisNodeName}->GetNetworkInfo();
        if ( $thisCS eq $cs and $spi eq $thisSPInbr ) {
            $nodeName = $thisNodeName;
            last;
        }
    }

    unless ( defined $nodeName ) {
        S_set_error(" SPI_database -> GetNodeName() : Could not find SPI nodename CS= '$cs',  SPI= '$spi', This is because the trace file is empty \n");
        return;
    }

    return $nodeName;
}

###############################################################################

=head2 GetAllSpiNetworkNodeNames

    $all_spi_network_node_names_aref = $self -> GetAllSpiNetworkNodeNames( ); 
 
I<B<Description:>> 

I<B<Return:>> 

    $all_spi_network_node_names_aref : [ <list_with_all_spi_network_node_names> ]

I<B<Verdict:>> none

I<B<Error:>> when SPI datasbase not initialized

=cut

#-------------------------------------------------------------------------------
sub GetAllSpiNetworkNodeNames {

    #-------------------------------------------------------------------------------
    my $self = shift;

    S_w2log( 4, " SPI_database -> GetAllSpiNetworkNodeNames() : Mapping_SPI contain following SPI network nodes :\n" );

    my $all_spi_network_node_names_aref = [];

    foreach my $nodeName ( keys %{ $self->{SPI_NetworkNodes} } ) {
        push( @$all_spi_network_node_names_aref, $nodeName );
        my ( $thisCS, $thisSPInbr ) = $self->{SPI_NetworkNodes}->{$nodeName}->GetNetworkInfo();
        S_w2log( 4, " SPI node '$nodeName'  [ $thisSPInbr:$thisCS (SPI:CS) ]\n" );
    }

    return $all_spi_network_node_names_aref;
}

###############################################################################

=head2 GetNodeBusDetails

    my ($cs, $spi) = $self -> GetNodeBusDetails($nodeName);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetNodeBusDetails {

    #-------------------------------------------------------------------------------
    my $self     = shift;
    my $nodeName = shift;

    unless ( defined $nodeName ) {
        S_set_error("Mandatory parameter node name not given");
        return;
    }

    my $cs;
    my $spi;

    if ( exists $self->{SPI_NetworkNodes}->{$nodeName} ) {
        ( $cs, $spi ) = $self->{SPI_NetworkNodes}->{$nodeName}->GetNetworkInfo();
    }
    else {
        S_set_error("Given node '$nodeName' does not exist in SPI database.");
        return;
    }

    return ( $cs, $spi );
}

###############################################################################

=head2 GetCommandMaskAndValue

    $self -> GetCommandMaskAndValue( $node , $commandName [, $format ]);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandMaskAndValue {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $node        = shift;
    my $commandName = shift;
    my $format      = shift;

    unless ( defined $commandName ) {
        S_set_error("Missing Argument commandName");
        return;
    }

    $format = 'COMPLETE' unless defined $format;

    my $nodeObject = $self->{'SPI_NetworkNodes'}->{$node};

    unless ( defined $nodeObject ) {
        S_set_error("Given node '$node' is not part of database");
        return;
    }

    my $listOfCommandsInNode_href    = $nodeObject->GetCommandList();
    my @listOfCommandsAndSubCommands = split( /__/, $commandName );
    my $command                      = shift @listOfCommandsAndSubCommands;

    unless ( exists $listOfCommandsInNode_href->{$command} ) {
        S_set_error("Given command '$command' is not part of database for node $node");
        return;
    }

    my $commandObject   = $listOfCommandsInNode_href->{$command};
    my $binMaskCommand  = $commandObject->GetCommandMask('BIN');
    my $binValueCommand = $commandObject->GetCommandValue('BIN');

    my $availableSubCommandList = $commandObject->GetSubCommandList(1);

    # go through all sub commands which are defined from the input parameter
    foreach my $subcommand (@listOfCommandsAndSubCommands) {

        # check whether sub command from input parameter exists
        unless ( exists $availableSubCommandList->{$subcommand} ) {
            S_set_error("Sub command '$subcommand' not defined for command '$command', node '$node'");
            return;
        }
        my $thisSubCommandObject = $availableSubCommandList->{$subcommand};
        $binMaskCommand  = $thisSubCommandObject->GetCommandMask('BIN') | $binMaskCommand;
        $binValueCommand = $thisSubCommandObject->GetCommandValue('BIN') | $binValueCommand;
    }

    if ( $format eq 'BIN' ) {
        return $binMaskCommand, $binValueCommand;
    }

    my ( $hexMaskComplete, $hexValueComplete );
    my $maskLengthByte = length($binMaskCommand) / 4;
    $hexMaskComplete = sprintf( "%0" . $maskLengthByte . "X", oct("0b$binMaskCommand") );
    my $valueLengthByte = length($binValueCommand) / 4;
    $hexValueComplete = sprintf( "%0" . $valueLengthByte . "X", oct("0b$binValueCommand") );

    return $hexMaskComplete, $hexValueComplete;
}

###############################################################################

=head2 GetCommandInstructionLength

    $self -> GetCommandInstructionLength( $node , $commandName [, $format ]);

 
I<B<Description:>> Supported Formats: Bit, Byte

I<B<Return:>> 

    nothing: 
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandInstructionLength {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $node        = shift;
    my $commandName = shift;
    my $format      = shift;

    unless ( defined $commandName ) {
        S_set_error("Missing Argument commandName");
        return;
    }

    my $nodeObject = $self->{'SPI_NetworkNodes'}->{$node};

    unless ( defined $nodeObject ) {
        S_set_error("Given node '$node' is not part of database");
        return;
    }

    unless ( defined $format ) {
        $format = 'bit';
    }

    if ( lc($format) ne 'bit' and lc($format) ne 'byte' ) {
        S_set_error("GetCommandInstructionLength supports formats 'bit' and 'byte'");
    }

    my $listOfCommandsInNode_href    = $nodeObject->GetCommandList();
    my @listOfCommandsAndSubCommands = split( /__/, $commandName );
    my $command                      = shift @listOfCommandsAndSubCommands;

    unless ( exists $listOfCommandsInNode_href->{$command} ) {
        S_set_error("Given command '$command' is not part of database for node $node");
        return;
    }

    my $commandObject = $listOfCommandsInNode_href->{$command};

    my $instructionLength = $commandObject->GetCommandInstructionLength_Bit();
    if ( lc($format) eq 'byte' ) {
        $instructionLength = $instructionLength / 8;
    }

    return $instructionLength;
}
###############################################################################

=head2 GetSignalMask

    $self -> GetSignalMask($signal, $commandName, $nodeName, $format);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalMask {

    #-------------------------------------------------------------------------------
    my $self        = shift;
    my $signalName  = shift;
    my $commandName = shift;
    my $nodeName    = shift;
    my $format      = shift;

    my $options_href = {
        'SignalMask'          => $format,
#        'SignalDecodingStyle' => 1,
    };
    my $signal_details_href = Get_signal_details( $self,$nodeName, $commandName, $signalName, $options_href );

    return unless ($signal_details_href);

    return $signal_details_href->{'SignalMask'};
}


sub Get_signal_details {
    
    my $self        = shift;
    my $nodeName    = shift;
    my $commandName = shift;
    my $signalName  = shift;
    my $options_href = shift;

    my $signal_details_href;
    
    my $nodeObject = $self->{'SPI_NetworkNodes'}->{$nodeName};

    unless ( defined $nodeObject ) {
        S_set_error("Given node '$nodeName' is not part of database");
        return;
    }

    my $signalObject;
    my $deviceSignals_href = $nodeObject->GetSignalList();
    my $signalLog          = $signalName;
    $signalLog =~ s/_MISO//i;
    if ( exists $deviceSignals_href->{$signalName} ) {
        S_w2log( 2, "Given signal '$signalLog' is a device signal of node $nodeName.\n" );
        $signalObject = $deviceSignals_href->{$signalName};

    }
    else {
        S_w2log( 5, "LIFT_spi_database::GetSignalMask : Processing signal '$nodeName :: $commandName :: $signalLog' \n" );
        my $listOfCommandsInNode_href = $nodeObject->GetCommandList();

        my @listOfCommandsAndSubCommands = split( /__/, $commandName );
        my $command = shift @listOfCommandsAndSubCommands;

        unless ( exists $listOfCommandsInNode_href->{$command} ) {
            S_set_error("Given command '$command' is not part of database for node $nodeName");
            return;
        }

        my $commandObject = $listOfCommandsInNode_href->{$command};
        my $validCommand;
        if (@listOfCommandsAndSubCommands) {
            my $subCommands_href = $commandObject->GetSubCommandList();
            my $subCommandObject;

            foreach my $subCommand (@listOfCommandsAndSubCommands) {

                $subCommandObject = $subCommands_href->{$subCommand};
                $subCommands_href = $commandObject->GetSubCommandList();
                last unless ($subCommands_href);
            }
            $validCommand = $subCommandObject;
        }
        else {
            $validCommand = $commandObject;
        }

        my $commandSignalList = $validCommand->GetCommandSignalList();

        unless ( exists $commandSignalList->{$signalName} ) {
            S_set_error("Given signal '$signalLog' is not part of database for node $nodeName and command $command");
            return;
        }
        $signalObject = $commandSignalList->{$signalName};
    }

        my $format = $options_href->{'SignalMask'}//'HEX';
        $signal_details_href->{'SignalMask'} = $signalObject->GetSignalMask($format);
    
    if ($options_href->{'SignalDecodingStyle'}){
        $signal_details_href->{'SignalDecodingStyle'} = $signalObject->GetDecodingStyle();
    }
    
    if ($options_href->{'SignalMaskStartPosAndLength'}){
        ($signal_details_href->{'SignalMaskStartPos'}, $signal_details_href->{'SignalMaskLength'} ) = $signalObject->GetMaskStartPosAndLength();
    }
    
    unless ($signal_details_href){
        S_set_error("Get_signal_details: No valid options passed ",109);
        return;
    }
    return $signal_details_href;
}

###############################################################################

=head2 Interpret_SPI_Frame

    $self -> Interpret_SPI_Frame($nodeName, $mosi, $miso);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub Interpret_SPI_Frame {

    #-------------------------------------------------------------------------------
    my $self            = shift;
    my $nodeName        = shift;
    my $mosi            = shift;
    my $miso            = shift;
    my $frameLengthBits = shift;

    # convert MISO and MOSI value to binary
    my ( $thisNodeName, $nodeCS, $frameLength_Bits_FromNode ) = $self->{SPI_NetworkNodes}->{$nodeName}->GetNodeInfo();
    if ( $frameLength_Bits_FromNode > 32 ) {
        S_set_error("Only frame length up to 32bit is currently supported for decoding!");
        return;
    }

    # Use frame length from measurement
    $frameLengthBits = $frameLength_Bits_FromNode unless ( defined $frameLengthBits );

    my ( $thisFrameDecoded, $commandLabelWithSubCommands );
    if ( $frameLengthBits > $frameLength_Bits_FromNode ) {    # Message transmit type must be data flow!
        ( $thisFrameDecoded, $commandLabelWithSubCommands ) = _interpretDataFlowSpiFrame( $self, $nodeName, $mosi, $miso, $frameLengthBits );
    }
    else {
        ( $thisFrameDecoded, $commandLabelWithSubCommands ) = _interpretStandardSpiFrame( $self, $nodeName, $mosi, $miso, $frameLengthBits );
    }

    #    my $timeStampDecodedString;
    #    $timeStampDecodedString = $deviceType.": "."\t|\t"
    #                                        .$commandLabelWithSubCommands."\t";
    #
    #    $timeStampDecodedString .= $commandDefinitionString."\t" if(defined $commandDefinitionString);
    #    $timeStampDecodedString .= $mosiSignalString if(defined $mosiSignalString);
    #    $timeStampDecodedString .= "\t|\t";
    #    $timeStampDecodedString .= $responseDefinitionString."\t" if(defined $responseDefinitionString);
    #    $timeStampDecodedString .= $misoSignalString if(defined $misoSignalString);

    return ( $thisFrameDecoded, $commandLabelWithSubCommands );
}

sub _interpretStandardSpiFrame() {
    my $self            = shift;
    my $nodeName        = shift;
    my $mosi            = shift;
    my $miso            = shift;
    my $frameLengthBits = shift;

    # hex function limited to 32 bit!
    my $value_MOSI_bin = sprintf( "%0" . $frameLengthBits . "b", hex($mosi) );
    my $value_MISO_bin = sprintf( "%0" . $frameLengthBits . "b", hex($miso) );

    # get MOSI commands
    my $deviceType           = $self->{SPI_NetworkNodes}->{$nodeName}->GetDeviceType();
    my $deviceObject         = $self->{SPI_NetworkDevices}->{$deviceType};
    my $mosiCommandList_href = $deviceObject->GetCommandList();

    # map MOSI commands
    my $mosi_commands_href;
    foreach my $commandLabel ( keys %{$mosiCommandList_href} ) {
        my $command = $mosiCommandList_href->{$commandLabel};

        my $mask_bin    = $command->GetCommandMask('BIN');
        my $result_data = $mask_bin & $value_MOSI_bin;

        my $result_command = $command->GetCommandValue('BIN');

        if ( $result_command eq $result_data ) {
            $mosi_commands_href->{$commandLabel} = $command;
        }
    }

    my $numberOfMatchedCommands = scalar keys %{$mosi_commands_href};
    if ( $numberOfMatchedCommands == 0 ) {
        return;
    }

    my ( $finalCommandLabel, $command_object ) = _getFinalCommandlabel( $mosi_commands_href, $mosi );
    return unless ( defined $finalCommandLabel );

    # map sub commands
    my $thisCommandSubCommands_href = $command_object->GetSubCommandList();
    my $commandLabelWithSubCommands = $finalCommandLabel;

    my ( %matchedSignals_hash, $matchedSubCommandSignals_href );

    if ($thisCommandSubCommands_href) {
        my $thisCommandLabelSubCommand;
        ( $thisCommandLabelSubCommand, $matchedSubCommandSignals_href ) = _getMatchingCommandLabelAndSignals( $thisCommandSubCommands_href, $value_MOSI_bin );
        $commandLabelWithSubCommands .= "__" . $thisCommandLabelSubCommand if ( defined $thisCommandLabelSubCommand );
    }

    my $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands } = 1;

    # map command signals
    if ($matchedSubCommandSignals_href) {
        %matchedSignals_hash = ( %{$matchedSubCommandSignals_href}, %{ $command_object->GetCommandSignalList() } );
    }
    else {
        %matchedSignals_hash = %{ $command_object->GetCommandSignalList() };
    }

    my ( $commandDefinitionString, $mosiSignalString, $responseDefinitionString, $misoSignalString );

    foreach my $signal ( keys %matchedSignals_hash ) {
        my $signalObject  = $matchedSignals_hash{$signal};
        my $signalType    = $signalObject->GetSignalType();
        my $signalLabel   = $signalObject->GetSignalLabel();
        my $decodingStyle = $signalObject->GetDecodingStyle();
        my $value_bin;
        if ( $signalType eq 'MOSI' ) {
            $value_bin = $value_MOSI_bin;
        }
        elsif ( $signalType eq 'MISO' ) {
            $value_bin = $value_MISO_bin;
        }
        else {
            S_set_error("Signal type $signalType not known, must be 'MISO' or 'MOSI'");
        }

        if ( $decodingStyle eq 'IF THEN' ) {
            my $signalValue_bin = $signalObject->GetSignalValue('BIN');
            my $signalMask      = $signalObject->GetSignalMask('BIN');
            if ( $signalType eq 'MOSI' and $signalValue_bin eq ( $signalMask & $value_bin ) ) {
                $commandDefinitionString .= $signalLabel . " ";
                $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = 1;    #Valid
            }
            elsif ( $signalType eq 'MISO' and $signalValue_bin eq ( $signalMask & $value_bin ) ) {
                $responseDefinitionString .= $signalLabel . " ";
                $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = 1;    #Valid
            }
        }
        else {
            my $signalValue_bin_cut = _calculateSignalValue_NOHTML( $signalObject, $value_bin );
            $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = $signalValue_bin_cut;
            $mosiSignalString .= "    $signalLabel = $signalValue_bin_cut" if ( $signalType eq 'MOSI' );
            $misoSignalString .= "    $signalLabel = $signalValue_bin_cut" if ( $signalType eq 'MISO' );
        }
    }

    # map device signals
    my $deviceSignalList_href = $deviceObject->GetSignalList();

    foreach my $signalLabel ( keys %{$deviceSignalList_href} ) {
        my $deviceSignal = $deviceSignalList_href->{$signalLabel};

        my $signalType    = $deviceSignal->GetSignalType();
        my $decodingStyle = $deviceSignal->GetDecodingStyle();
        my $value_bin;
        if ( $signalType eq 'MOSI' ) {
            $value_bin = $value_MOSI_bin;
        }
        elsif ( $signalType eq 'MISO' ) {
            $value_bin = $value_MISO_bin;
        }
        else {
            S_set_error("Signal type $signalType not known, must be 'MISO' or 'MOSI'");
        }

        if ( $decodingStyle eq 'IF THEN' ) {
            my $signalValue_bin = $deviceSignal->GetSignalValue('BIN');
            my $signalMask      = $deviceSignal->GetSignalMask('BIN');
            if ( $signalType eq 'MOSI' and $signalValue_bin eq ( $signalMask & $value_bin ) ) {
                $commandDefinitionString .= "    ||    $signalLabel   ";
                $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = 1;    #Valid
            }
            elsif ( $signalType eq 'MISO' and $signalValue_bin eq ( $signalMask & $value_bin ) ) {
                $responseDefinitionString .= "    ||    $signalLabel   ";
                $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = 1;    #Valid
            }
        }
        else {

            my $signalValue_bin_cut = _calculateSignalValue_NOHTML( $deviceSignal, $value_bin );
            $thisFrameDecoded->{ $nodeName . "::" . $commandLabelWithSubCommands . "::" . $signalType . "::" . $signalLabel } = $signalValue_bin_cut;
            $mosiSignalString .= "    ||    $signalLabel = $signalValue_bin_cut" if ( $signalType eq 'MOSI' );
            $misoSignalString .= "    ||    $signalLabel = $signalValue_bin_cut" if ( $signalType eq 'MISO' );
        }
    }

    return ( $thisFrameDecoded, $commandLabelWithSubCommands );
}

sub _interpretDataFlowSpiFrame () {
    my $self            = shift;
    my $nodeName        = shift;
    my $mosi            = shift;
    my $miso            = shift;
    my $frameLengthBits = shift;

    # get MOSI commands
    my $deviceType           = $self->{SPI_NetworkNodes}->{$nodeName}->GetDeviceType();
    my $deviceObject         = $self->{SPI_NetworkDevices}->{$deviceType};
    my $mosiCommandList_href = $deviceObject->GetCommandList();

    # map MOSI commands
    my $mosi_commands_href;
    foreach my $commandLabel ( keys %{$mosiCommandList_href} ) {
        my $command = $mosiCommandList_href->{$commandLabel};

        my $mask_bin = $command->GetCommandMask('BIN');

        my $commandLength_bit = $command->GetCommandInstructionLength_Bit();

        # MOSI value from measurement is in Bytes (Nibbles)
        my $mosiString_CutToLength = substr( $mosi, 0, $commandLength_bit / 4 );
        my $value_MOSI_bin = sprintf( "%0" . $commandLength_bit . "b", hex($mosiString_CutToLength) );

        my $result_data    = $mask_bin & $value_MOSI_bin;
        my $result_command = $command->GetCommandValue('BIN');

        if ( $result_command eq $result_data ) {
            $mosi_commands_href->{$commandLabel} = $command;
        }
    }

    if ( not defined $mosi_commands_href ) {
        my $mosiString_CutToLength = substr( $mosi, 0, 8 );
        S_set_warning("Could not find a matching command for mosi value starting with: '$mosiString_CutToLength'");
        return;
    }

    my ( $finalCommand, $command_object ) = _getFinalCommandlabel( $mosi_commands_href, $mosi );
    my $thisFrameDecoded->{ $nodeName . "::" . $finalCommand } = 1;

    my %matchedSignals_hash = %{ $command_object->GetCommandSignalList() };
    my $headerLength_Bit    = $command_object->GetCommandInstructionLength_Bit();

    foreach my $signal ( keys %matchedSignals_hash ) {
        my $signalObject       = $matchedSignals_hash{$signal};
        my $signalType         = $signalObject->GetSignalType();
        my $signalLabel        = $signalObject->GetSignalLabel();
        my $decodingStyle      = $signalObject->GetDecodingStyle();
        my $signalTransmitType = $signalObject->GetTransmitType();
        if ( not defined $signalTransmitType or $signalTransmitType eq '' ) {
            S_set_error( "(Signal '$signalLabel') " . "For signals under data flow commands, <asicSignalTransmitType> must be 'HeaderDataFlow' or 'DataFlow' in decoding file!" );
            next;
        }
        my $instructionLength_bit = $signalObject->GetInstructionLength_Bit();

        my $signalValue;
        if ( $signalType eq 'MOSI' and $signalTransmitType eq 'HeaderDataFlow' ) {
            my $mosiString_CutToLength = substr( $mosi, 0, $instructionLength_bit / 4 );
            my $value_MOSI_bin = sprintf( "%0" . $instructionLength_bit . "b", hex($mosiString_CutToLength) );
            my $value_bin = $value_MOSI_bin;
            $signalValue = _calculateSignalValue_NOHTML( $signalObject, $value_bin );
        }
        elsif ( $signalType eq 'MISO' and $signalTransmitType eq 'HeaderDataFlow' ) {
            my $misoString_CutToLength = substr( $miso, 0, $instructionLength_bit / 4 );
            my $value_MISO_bin = sprintf( "%0" . $instructionLength_bit . "b", hex($misoString_CutToLength) );
            my $value_bin = $value_MISO_bin;
            $signalValue = _calculateSignalValue_NOHTML( $signalObject, $value_bin );
        }
        elsif ( $signalType eq 'MOSI' and $signalTransmitType eq 'DataFlow' ) {
            my $mosiStringLength_Nibble = split( //, $mosi );
            if ( $mosiStringLength_Nibble % 2 ) {
                $mosi = "0" . $mosi;    # Add leading zero to $mosi for an equal number of nibbles
                $mosiStringLength_Nibble++;
            }

            my $signalInstructionLength_Bits = $signalObject->GetInstructionLength_Bit();
            my $numberOfDataSamples          = ( $frameLengthBits - $headerLength_Bit ) / $signalInstructionLength_Bits;
            my $posInString                  = $headerLength_Bit / 4;
            foreach my $dataSample ( 1 .. $numberOfDataSamples ) {
                if ( $posInString + $signalInstructionLength_Bits / 4 > $mosiStringLength_Nibble ) {
                    S_set_error("Not enough data left in MOSI data for data sample $dataSample of signal $signalLabel");
                    last;
                }
                my $thisSampleHexValue = substr( $mosi, $posInString, $signalInstructionLength_Bits / 4 );
                my $value_MOSI_bin = sprintf( "%0" . $signalInstructionLength_Bits . "b", hex($thisSampleHexValue) );
                push( @{$signalValue}, _calculateSignalValue_NOHTML( $signalObject, $value_MOSI_bin ) );
                $posInString += $signalInstructionLength_Bits / 4;
            }
        }
        elsif ( $signalType eq 'MISO' and $signalTransmitType eq 'DataFlow' ) {
            my $misoStringLength_Nibble = split( //, $miso );
            if ( $misoStringLength_Nibble % 2 ) {
                $miso = "0" . $miso;    # Add leading zero to $miso for an equal number of nibbles
                $misoStringLength_Nibble++;
            }

            my $signalInstructionLength_Bits = $signalObject->GetInstructionLength_Bit();
            my $numberOfDataSamples          = ( $frameLengthBits - $headerLength_Bit ) / $signalInstructionLength_Bits;
            my $posInString                  = $headerLength_Bit / 4;
            foreach my $dataSample ( 1 .. $numberOfDataSamples ) {
                if ( $posInString + $signalInstructionLength_Bits / 4 > $misoStringLength_Nibble ) {
                    S_set_error("Not enough data left in MISO data for data sample $dataSample of signal $signalLabel");
                    last;
                }
                my $thisSampleHexValue = substr( $miso, $posInString, $signalInstructionLength_Bits / 4 );
                my $value_MISO_bin = sprintf( "%0" . $signalInstructionLength_Bits . "b", hex($thisSampleHexValue) );
                push( @{$signalValue}, _calculateSignalValue_NOHTML( $signalObject, $value_MISO_bin ) );
                $posInString += $signalInstructionLength_Bits / 4;
            }
        }
        else {
            S_set_error( "(Signal $signalLabel):\n" . "Signal type $signalType not known, must be 'MISO' or 'MOSI'\n" . "<asicSignalTransmitType> either 'HeaderDataFlow' or 'DataFlow'!" );
        }
        $thisFrameDecoded->{ $nodeName . "::" . $finalCommand . "::" . $signalType . "::" . $signalLabel } = $signalValue;
    }

    return ( $thisFrameDecoded, $finalCommand );
}

sub _getFinalCommandlabel {
    my $mosi_commands_href = shift;
    my $mosi               = shift;
    my $finalCommandLabel;

    my $maxNbrOf1s = 0;
    foreach my $mappedCommand ( keys %{$mosi_commands_href} ) {
        my $object   = $mosi_commands_href->{$mappedCommand};
        my $mask_bin = $object->GetCommandMask('BIN');
        my $nbrOf1s  = $mask_bin =~ tr/1//;
        if ( $nbrOf1s > $maxNbrOf1s ) {
            $finalCommandLabel = $mappedCommand;
            $maxNbrOf1s        = $nbrOf1s;
        }
        elsif ( $nbrOf1s == $maxNbrOf1s ) {
            S_set_error("Command '$mappedCommand' can't be mapped unequivocally to given MOSI value '$mosi'.");
            return;
        }
    }

    my $command_object = $mosi_commands_href->{$finalCommandLabel};

    return $finalCommandLabel, $command_object;
}

sub _getMatchingCommandLabelAndSignals {

    my $thisCommandSubCommands_href = shift;
    my $value_MOSI_bin              = shift;

    my $commandLabelMatched;
    my $matchedSignals_href;

    foreach my $subCommand ( sort keys %{$thisCommandSubCommands_href} ) {
        my $subCommandObject = $thisCommandSubCommands_href->{$subCommand};
        my $commandMask_bin  = $subCommandObject->GetCommandMask('BIN');
        my $commandValue_bin = $subCommandObject->GetCommandValue('BIN');
        if ( $commandValue_bin eq ( $commandMask_bin & $value_MOSI_bin ) ) {
            $commandLabelMatched .= "__" if ( defined $commandLabelMatched );
            $commandLabelMatched .= $subCommand;

            my $thisSubCommandMatchedSignals_href = $subCommandObject->GetCommandSignalList();
            if ( keys %{$matchedSignals_href} ) {
                %{$matchedSignals_href} = ( %{$matchedSignals_href}, %{$thisSubCommandMatchedSignals_href} );
            }
            else {
                $matchedSignals_href = $thisSubCommandMatchedSignals_href;
            }
            my $subCommandsSubCommandsList = $subCommandObject->GetSubCommandList();
            if ( keys %{$subCommandsSubCommandsList} ) {

                # Sub command has sub commands
                my ( $thisSubCommandLabel, $thisSubCommandSignals ) = _getMatchingCommandLabelAndSignals( $subCommandsSubCommandsList, $value_MOSI_bin );
                $commandLabelMatched .= "__" . $thisSubCommandLabel if ( defined $thisSubCommandLabel );
                if ( keys %{$matchedSignals_href} and keys %{$thisSubCommandSignals} ) {
                    %{$matchedSignals_href} = ( %{$matchedSignals_href}, %{$thisSubCommandSignals} );
                }
                elsif ( keys %{$thisSubCommandSignals} and not keys %{$matchedSignals_href} ) {
                    $matchedSignals_href = $thisSubCommandSignals;
                }
            }
        }
    }
    return ( $commandLabelMatched, $matchedSignals_href );
}

=head1 Function Group 'base'

=head2 SPIDB_init

    SPIDB_init($pathToSPImaidProject);
    
    Extracts all decoding files from an SPI Maid project
    
=cut

#-------------------------------------------------------------------------------
sub SPIDB_init {

    #-------------------------------------------------------------------------------
    my $self = shift;

    S_w2log( 3, "Starting SPIDB_init...\n" );

    my $mappingNetworkSPI = S_get_contents_of_hash( ['Mapping_SPI'] );
    unless ( defined $mappingNetworkSPI ) {
        S_set_error( "SPI network mapping is mandatorily required for any SPI functionality!\n" . "Check Mapping_SPI_network_TEMPLATE.pm in the TurboLIFT template project and fill otu based on project configuration.", 110 );
        return;
    }

    foreach my $spiNode ( keys %{$mappingNetworkSPI} ) {

        #add node object
        my $deviceType = $mappingNetworkSPI->{$spiNode}->{'DeviceType'};
        unless ( $self->{SPI_NetworkDevices}->{$deviceType} ) {
            my $decodingFile = $mappingNetworkSPI->{$spiNode}->{'DecodingFile'};
            $self->_create_SPI_Node_mapping_from_XML( $decodingFile, $deviceType );
        }
        my $deviceObject = $self->{SPI_NetworkDevices}->{$deviceType};
        unless ( defined $deviceObject ) {
            S_set_error( "SPIDB_init : No device object available for '$deviceType' (node '$spiNode').\n" . "Check whether there is a .spi decoding file available for this device.\n" . " (in SPI Mapping: 'NodeName' -> 'DecodingFile' -> '<<Path name>>')\n" );
            next;
        }
        $self->{SPI_NetworkNodes}->{$spiNode} = $deviceObject->CreateNode( $spiNode, $mappingNetworkSPI->{$spiNode}->{'CS_Pin'}, $mappingNetworkSPI->{$spiNode}->{'SPI'}, $mappingNetworkSPI->{$spiNode}->{'Frame_Length_Bit'}, );
    }

    S_w2log( 3, "Ending SPIDB_init...\n" );

    return 1;
}

=head2 SPIDB_exit

    SPIDB_exit();

=cut

#-------------------------------------------------------------------------------
sub SPIDB_exit {

    #-------------------------------------------------------------------------------
    return 1;
}

=head1 Function Group 'internal'

=head2 _create_SPI_Node_mapping_from_XML

    _create_SPI_Node_mapping_from_XML($filename, $deviceType, $log_path);
    
=cut

#-------------------------------------------------------------------------------
sub _create_SPI_Node_mapping_from_XML {

    #-------------------------------------------------------------------------------
    my $self       = shift;
    my $filename   = shift;
    my $deviceType = shift;
    my $log_path   = shift;

    unless ($filename) {
        S_set_error( "_create_SPI_Node_mapping_from_XML : No filename given!! Please check decoding file path in SPI Mapping!", 110 );
        return;
    }

    unless ( -e $filename ) {
        S_set_error( "_create_SPI_Node_mapping_from_XML : Given file '$filename' does not exist. Please check decoding file path in SPI Mapping!", 110 );
        return;
    }

    S_w2log( 3, "Start create_SPI_mapping_from_XML with file $filename\n" );
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # load the existing XML file
    my $framesSPI = $parser->load_xml( location => $filename );

    # get the reference to root element
    my $rootElement = $framesSPI->documentElement;
    my $xpc         = XML::LibXML::XPathContext->new($rootElement);

    # get the spi node name
    my @schema_nodes = $xpc->findnodes("//*[name()='xs:element']");
    my $spiNodeNameInXML;
    foreach my $schemaNode (@schema_nodes) {
        my $name = $schemaNode->getAttribute('name');
        if ( $name =~ m/(.*).spi/ ) {
            $spiNodeNameInXML = $name;
            last;
        }
    }

    S_w2log( 4, "SPI node name: $spiNodeNameInXML\n" );

    # get all SPI frames / signals defined for the SPI node
    my @nodes = $xpc->findnodes("//$spiNodeNameInXML");

    my $spi_instructions_href;
    my $spiMapping_href = {};

    my @dumpName_array = split( /.spi/, $spiNodeNameInXML );
    $deviceType = $dumpName_array[0] unless ($deviceType);
    S_w2log( 4, "Create device object of type $deviceType\n" );
    my $device_object = SPI_device->new($deviceType);
    unless ($device_object) {
        S_set_error("Could not create device object of type $deviceType");
        return;
    }
    $self->{SPI_NetworkDevices}->{$deviceType} = $device_object;

    foreach my $node (@nodes) {

        # get next MOSI instruction
        my $asicReferenceID = $node->findvalue("./asicReference");
        if ( defined $spi_instructions_href->{$asicReferenceID}->{'Instruction_Status'} ) {
            next if ( $spi_instructions_href->{$asicReferenceID}->{'Instruction_Status'} eq 'added' );
        }

        # get all signals defined in MOSI instruction
        my @signalNodes = $xpc->findnodes("//$spiNodeNameInXML/asicReference[text()=$asicReferenceID]");

        # get main level instructions (asicReferenceNode = 0)
        foreach my $signalNode (@signalNodes) {

            my $asicReferenceNode = $signalNode->findvalue("./../asicReferenceNode");
            next if ( $asicReferenceNode > 0 );

            my $instructionLength = $signalNode->findvalue("./../asicInstLength");
            my $mosiText          = $signalNode->findvalue("./../asicTextMOSI");
            my $mosiDecoding      = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMOSI") };
            my $misoText          = $signalNode->findvalue("./../asicTextMISO");
            my $transmitType      = $signalNode->findvalue("./../asicTransmitMode");
            if ( $mosiDecoding ne 'IF THEN' and $misoText ne '' ) {
                S_w2log( 5, "MISO Device signal '$misoText' found\n" );
                if ( exists $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText} ) {
                    S_set_error("Same device signal ($misoText, ID $asicReferenceID) already exists. Instruction name must be unique - update decoding file ('$filename')");
                    print "Same device signal ($misoText, ID $asicReferenceID) already exists. Instruction name must be unique - update decoding file ('$filename')";
                    return;
                }
                $misoText                                                        = _format_signal_string($misoText);
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Type"} = "DEVICE_SIGNAL";
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Text"} = $misoText;
                my $maskMISO  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMISO/Value/unsignedInt[1]") );
                my $valueMISO = sprintf( "%X", $signalNode->findvalue("./../asicValueMISO/Value/unsignedInt[1]") );
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'InstructionLength'} = $instructionLength;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'Mask'}              = $maskMISO;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'Value'}             = $valueMISO;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'Decoding'}          = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") };
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'Type'}              = 'MISO';

                my $decodingStyle = $spiMapping_href->{'DEVICE_SIGNALS'}->{$misoText}->{'Decoding'};
                $device_object->AddSignal( $misoText, 'MISO', $maskMISO, $valueMISO, $decodingStyle, $instructionLength );

            }
            elsif ( $mosiText ne '' and $mosiDecoding ne 'IF THEN' ) {
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Type"} = "DEVICE_SIGNAL";
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Text"} = $mosiText;
                S_w2log( 5, "MOSI Device signal '$mosiText' found\n" );
                my $maskMOSI  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMOSI/Value/unsignedInt[1]") );
                my $valueMOSI = sprintf( "%X", $signalNode->findvalue("./../asicValueMOSI/Value/unsignedInt[1]") );
                $mosiText                                                                = _format_signal_string($mosiText);
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'InstructionLength'} = $instructionLength;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'Mask'}              = $maskMOSI;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'Value'}             = $valueMOSI;
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'Decoding'}          = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") };
                $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'Type'}              = 'MOSI';

                my $decodingStyle = $spiMapping_href->{'DEVICE_SIGNALS'}->{$mosiText}->{'Decoding'};
                $device_object->AddSignal( $mosiText, 'MOSI', $maskMOSI, $valueMOSI, $decodingStyle, $instructionLength );
            }
            else {

                my %hash = %{$spiMapping_href};
                if ( exists $hash{$mosiText} ) {
                    S_set_error("Same MOSI Instruction ($mosiText, ID $asicReferenceID) already exists. Instruction name must be unique - update decoding file ('$filename')");
                    print "Same MOSI Instruction ($mosiText, ID $asicReferenceID) already exists. Instruction name must be unique - update decoding file ('$filename')";
                    return;
                }
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Type"} = "MOSI_COMMAND";
                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Text"} = $mosiText;

                my $mask  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMOSI/Value/unsignedInt[1]") );
                my $value = sprintf( "%X", $signalNode->findvalue("./../asicValueMOSI/Value/unsignedInt[1]") );

                $spi_instructions_href->{$asicReferenceID}->{"Instruction_Object"} =
                  SPI_command->new( $mosiText, $mask, $value, $deviceType, $instructionLength, $transmitType );

                $spiMapping_href->{$mosiText}->{'MOSI_Mask'}  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMOSI/Value/unsignedInt[1]") );
                $spiMapping_href->{$mosiText}->{'MOSI_Value'} = sprintf( "%X", $signalNode->findvalue("./../asicValueMOSI/Value/unsignedInt[1]") );
                $spiMapping_href->{$mosiText}->{'MOSI_Decoding'} = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMOSI") };

                my $textMISO  = $signalNode->findvalue("./../asicTextMISO");
                my $maskMISO  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMISO/Value/unsignedInt[1]") );
                my $valueMISO = sprintf( "%X", $signalNode->findvalue("./../asicValueMISO/Value/unsignedInt[1]") );
                if ($textMISO) {
                    $textMISO                                                                           = _format_signal_string($textMISO);
                    $spiMapping_href->{$mosiText}->{'MISO_Signals'}->{$textMISO}->{'InstructionLength'} = $instructionLength;
                    $spiMapping_href->{$mosiText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Mask'}         = $maskMISO;
                    $spiMapping_href->{$mosiText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Value'}        = $valueMISO;
                    $spiMapping_href->{$mosiText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Decoding'}     = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") };

                    $spi_instructions_href->{$asicReferenceID}->{"Instruction_Object"}->AddSignal( $textMISO, 'MISO', $maskMISO, $valueMISO, $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") }, $instructionLength, );
                }
            }

            last;

        }

        next unless ( defined $spi_instructions_href->{$asicReferenceID} );

        my $instructionType   = $spi_instructions_href->{$asicReferenceID}->{"Instruction_Type"};
        my $instructionText   = $spi_instructions_href->{$asicReferenceID}->{"Instruction_Text"};
        my $instructionObject = $spi_instructions_href->{$asicReferenceID}->{"Instruction_Object"};

        # get signals in main MOSI instruction (asicReferenceNode >= 1)
        my $currentInstructionObject             = $instructionObject;
        my $referenceInstructionObject_href->{0} = $instructionObject;
        my $currentInstructionNode               = 0;
        foreach my $signalNode (@signalNodes) {
            my $asicReferenceNode = $signalNode->findvalue("./../asicReferenceNode");
            next if ( $asicReferenceNode == 0 );

            my $instructionLength = $signalNode->findvalue("./../asicInstLength");

            if ( $instructionType eq 'MOSI_COMMAND' ) {
                my $signalTransmitType = $signalNode->findvalue("./../asicSignalTransmitType");

                # MOSI signal
                my $textMOSI = $signalNode->findvalue("./../asicTextMOSI");
                if ( $asicReferenceNode < $currentInstructionNode ) {
                    S_w2log( 5, "Back to instruction one level up\n" );
                    $currentInstructionNode   = $asicReferenceNode - 1;
                    $currentInstructionObject = $referenceInstructionObject_href->{$currentInstructionNode};
                }

                if ($textMOSI) {
                    $textMOSI = _format_signal_string($textMOSI);

                    my $mask = sprintf( "%X", $signalNode->findvalue("./../asicMaskMOSI/Value/unsignedInt[1]") );
                    $spiMapping_href->{$instructionText}->{'MOSI_Signals'}->{$textMOSI}->{'MOSI_Mask'} = $mask;
                    my $value = sprintf( "%X", $signalNode->findvalue("./../asicValueMOSI/Value/unsignedInt[1]") );
                    $spiMapping_href->{$instructionText}->{'MOSI_Signals'}->{$textMOSI}->{'MOSI_Value'} = $value;
                    my $decoding = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMOSI") };
                    $spiMapping_href->{$instructionText}->{'MOSI_Signals'}->{$textMOSI}->{'MOSI_Decoding'} = $decoding;

                    if ( $asicReferenceNode == $currentInstructionNode ) {
                        S_w2log( 5, "Back to instruction one level up\n" );
                        $currentInstructionNode   = $asicReferenceNode - 1;
                        $currentInstructionObject = $referenceInstructionObject_href->{$currentInstructionNode};
                    }

                    # Add as signal in any case, and additionally as sub command in case of decoding 'IF THEN'
                    # Sub command will be needed when manipulating, signal will be needed for decoding
                    $currentInstructionObject->AddSignal( $textMOSI, 'MOSI', $mask, $value, $decoding, $instructionLength, $signalTransmitType, ) if ( $decoding ne 'IF THEN' );
                    if ( $decoding eq 'IF THEN' ) {
                        S_w2log( 5, "Add sub command\n" );
                        my $newSubCommandObject = $currentInstructionObject->AddSubCommand( $textMOSI, $mask, $value, $instructionLength );
                        $currentInstructionObject                              = $newSubCommandObject;
                        $currentInstructionNode                                = $asicReferenceNode;
                        $referenceInstructionObject_href->{$asicReferenceNode} = $newSubCommandObject;
                    }
                }

                # MISO signal
                my $textMISO = $signalNode->findvalue("./../asicTextMISO");

                if ($textMISO) {
                    $textMISO = _format_signal_string($textMISO);
                    $spiMapping_href->{$instructionText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Mask'}  = sprintf( "%X", $signalNode->findvalue("./../asicMaskMISO/Value/unsignedInt[1]") );
                    $spiMapping_href->{$instructionText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Value'} = sprintf( "%X", $signalNode->findvalue("./../asicValueMISO/Value/unsignedInt[1]") );
                    $spiMapping_href->{$instructionText}->{'MISO_Signals'}->{$textMISO}->{'MISO_Decoding'} = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") };

                    # for debug only
                    if ( $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") } eq 'IF THEN' ) {
                        S_w2log( 5, "MISO 'Command' found\n" );
                    }

                    $currentInstructionObject->AddSignal(
                        $textMISO, 'MISO',
                        sprintf( "%X", $signalNode->findvalue("./../asicMaskMISO/Value/unsignedInt[1]") ),
                        sprintf( "%X", $signalNode->findvalue("./../asicValueMISO/Value/unsignedInt[1]") ),
                        $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecodingMISO") },
                        $instructionLength, $signalTransmitType,
                    );
                }

            }
            elsif ( $instructionType eq 'DEVICE_SIGNAL' ) {
                my $type     = $spiMapping_href->{'DEVICE_SIGNALS'}->{$instructionText}->{'Type'};
                my $text     = $signalNode->findvalue("./../asicText$type");
                my $decoding = $SPI_MAID_DECODING_TABLE{ $signalNode->findvalue("./../asicDecoding$type") };

                if ( $decoding ne 'IF THEN' ) {
                    S_set_warning( "Device signals should only contain sub nodes with decoding type 'IF THEN' for a data value table." . "'$text' (sub node of '$instructionText') will be ignored" );
                }
                else {
                    my $mask = sprintf( "%X", $signalNode->findvalue("./../asicMask$type/Value/unsignedInt[1]") );
                    $spiMapping_href->{'DEVICE_SIGNALS'}->{$instructionText}->{"DataValueTable"}->{$text}->{'Mask'} = $mask;
                    my $value = sprintf( "%X", $signalNode->findvalue("./../asicValue$type/Value/unsignedInt[1]") );
                    $spiMapping_href->{'DEVICE_SIGNALS'}->{$instructionText}->{"DataValueTable"}->{$text}->{'Value'} = $value;
                }
            }
        }
        $spi_instructions_href->{$asicReferenceID}->{'Instruction_Status'} = 'added';
    }

    foreach my $mosiCommandID ( keys %{$spi_instructions_href} ) {
        my $instructionType = $spi_instructions_href->{$mosiCommandID}->{'Instruction_Type'};
        next unless ( $instructionType eq 'MOSI_COMMAND' );

        my $command_object = $spi_instructions_href->{$mosiCommandID}->{'Instruction_Object'};
        my $command_label  = $spi_instructions_href->{$mosiCommandID}->{'Instruction_Text'};
        $device_object->AddCommandObject( $command_label, $command_object );
    }

    S_dump2pmFile( "VariableToDump" => $spiMapping_href, "StoragePath" => $log_path, "PackageName" => $deviceType ) if ($log_path);

    S_w2log( 3, " LIFT_spi_database::_create_SPI_Node_mapping_from_XML: Result file $filename \n" );

    return ( $deviceType, $spi_instructions_href );
}

#-------------------------------------------------------------------------------
sub _format_signal_string {

    #-------------------------------------------------------------------------------
    my $string = shift;

    # S_w2log(5, "Start formatting string: '$string'\n");

    my $string_orig = $string;

    $string =~ tr/=//d;
    $string =~ s/^\s+|\s+$//g;
    $string =~ s/^-//g;    #  removing - from '-Data_CH1'  -> Data_CH1 to be used
    $string =~ s/:$//g;
    $string =~ s/\s+$//g;

    S_w2log( 5, " LIFT_spi_database::_format_signal_string: '$string_orig'  => '$string'\n" );

    return $string;
}

#-------------------------------------------------------------------------------
sub _calculateSignalValue {

    #-------------------------------------------------------------------------------
    my $signalObject = shift;
    my $spiFrame_bin = shift;

    my $signalMask = $signalObject->GetSignalMask('BIN');

    my $signalValue_bin = $signalMask & $spiFrame_bin;
    my @signalValue_binarray = split( //, $signalValue_bin );
    my $signalValue_bin_cut;
    my ( $startPos, $length ) = $signalObject->GetMaskStartPosAndLength();
    my $signalLabel = $signalObject->GetSignalLabel();
    unless ( defined $startPos ) {
        S_w2log( 4, "Signal $signalLabel can't be decoded due to problem with mask.\n" );
        return;
    }

    #    S_w2log(5, "$signalLabel -> Mask start: $startPos, Mask length = $length");
    foreach my $characterIndex ( $startPos .. $startPos + $length - 1 ) {
        $signalValue_bin_cut .= $signalValue_binarray[$characterIndex];
    }
    $signalValue_bin_cut = S_bin2dec_NOHTML($signalValue_bin_cut);

    #check for Decoding style and depend upon the Decoding style return the value(signed or unsigned).
    my $decodingStyle = $signalObject->GetDecodingStyle();
    if ( $decodingStyle eq 'Signed' ) {

        # convert unsigned int to signed int
        my $signedInt = NUM_UnsignedInt2SignedInt( $signalValue_bin_cut, $length );
        return $signedInt;
    }
    else {
        return $signalValue_bin_cut;
    }
}

#-------------------------------------------------------------------------------
sub DESTROY {

    #-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");

    return 1;
}

package SPI_device;

####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####

use strict;
use warnings;
use LIFT_general;
use Storable qw(dclone);

=head1 NAME

SPI_device 

Record class of the EDR Test Framework

=head1 SYNOPSIS

    use SPI_device;

    SPI_device -> new();


=head1 DESCRIPTION

this class is only instanced and accessed by functions of the EDR_Record_Handler

###############################################################################

=head2 new

    $device_object = SPI_device -> new( $deviceType );

I<B<Description:>>     instances a new object of EDR record class -> record object

    mandatory:
                                    For other projects where there is only one response, this is it.

    optional: 
 
I<B<Return:>> Return the blessed (instanced) mosi command object.
              Return nothing if missing mandatory parameter

I<B<Verdict:>> none

I<B<Error:>> for missing mandatory parameters (see Description)

=cut

#------------------------ Constructor ------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $class = shift;    # Perl �bergibt als erstes eine Referenz auf die Klasse, dessen Methode gerufen wurde

    my $self = {
        DeviceType       => shift,
        MOSI_CommandList => {},
        DeviceSignalList => {},
        NodeName         => undef,
        ChipSelect       => undef,
        FrameLength_Bit  => undef,
        SPInbr           => undef,
    };

    my $deviceType = $self->{DeviceType};

    # Check that all mandatory parameters were given
    unless ( defined $self->{DeviceType} ) { S_set_error("Device cannot be instanced: No 'DeviceType' given!"); return; }

    S_w2log( 5, " Instancing new device by running SPI_device -> new() \n" );
    S_w2log( 5, " --> Device type: '$deviceType'\n" );

    # object $self is attached to the class $class
    return bless $self, $class;
}

###############################################################################

=head2 AddSignal

    $self -> AddSignal(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub AddSignal {

    #-------------------------------------------------------------------------------
    my $self              = shift;
    my $signalLabel       = shift;
    my $type              = shift;
    my $mask              = shift;
    my $value             = shift;
    my $decodingStyle     = shift;
    my $instructionLength = shift;

    if ( exists $self->{DeviceSignalList}->{ $signalLabel . "_" . $type } ) {
        my $deviceType = $self->{DeviceType};
        S_set_warning("SIGNAL with same label '$signalLabel' already exists for device '$deviceType'");
        return 0;
    }
    else {
        my $deviceType = $self->{DeviceType};
        S_w2log( 5, "Add signal $signalLabel ($type) to device $deviceType\n" );
        my $signal_object = SPI_signal->new( $signalLabel, $mask, $value, $type, $decodingStyle, $instructionLength );
        if ( not defined $signal_object ) {
            S_set_error("Signal $signalLabel could not be added for device $deviceType. Check mapping in SPI maid for this signal.");
            return;
        }
        $self->{DeviceSignalList}->{ $signalLabel . "_" . $type } = $signal_object;
    }

    return 1;
}

###############################################################################

=head2 AddCommandObject

    $self -> AddCommandObject(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub AddCommandObject {

    #-------------------------------------------------------------------------------
    my $self          = shift;
    my $commandLabel  = shift;
    my $commandObject = shift;

    if ( exists $self->{MOSI_CommandList}->{$commandLabel} ) {
        my $deviceType = $self->{DeviceType};
        S_set_warning("Command object with same label '$commandLabel' already exists for device '$deviceType'");
        return 0;
    }
    else {
        $self->{MOSI_CommandList}->{$commandLabel} = $commandObject;
    }
    return 1;
}

###############################################################################

=head2 GetDeviceType

    $self -> GetDeviceType(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetDeviceType {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{DeviceType};
}

###############################################################################

=head2 GetSignalList

    $self -> GetSignalList(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalList {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{DeviceSignalList};
}

###############################################################################

=head2 GetCommandList

    $self -> GetCommandList(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandList {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{MOSI_CommandList};
}

###############################################################################

=head2 GetNetworkInfo

    $self -> GetNetworkInfo(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetNetworkInfo {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return ( $self->{ChipSelect}, $self->{SPInbr} );
}

###############################################################################

=head2 GetNodeInfo

    $self -> GetNodeInfo(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetNodeInfo {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return ( $self->{NodeName}, $self->{ChipSelect}, $self->{FrameLength_Bit}, $self->{SPInbr}, );
}

###############################################################################

=head2 CreateNode

    $self -> CreateNode(...);

 
I<B<Description:>> Returns a deep copy of the object

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub CreateNode {

    #-------------------------------------------------------------------------------
    my $self            = shift;
    my $spiNodeName     = shift;
    my $chipSelect      = shift;
    my $spiNbr          = shift;
    my $frameLength_bit = shift;

    # Check that all mandatory parameters were given
    unless ( defined $spiNodeName )     { S_set_error("Node cannot be created: No 'NodeName' given!");        return; }
    unless ( defined $chipSelect )      { S_set_error("Node cannot be created: No 'ChipSelect' given!");      return; }
    unless ( defined $frameLength_bit ) { S_set_error("Node cannot be created: No 'FrameLength_Bit' given!"); return; }
    if ( not defined $spiNbr or $spiNbr eq '' ) {
        S_set_warning("No SPI bus nbr given, default value '1' will be set (Node $spiNodeName)");
        $spiNbr = 1;
    }

    my $cloned_self = dclone($self);

    $cloned_self->{NodeName}        = $spiNodeName;
    $cloned_self->{ChipSelect}      = $chipSelect;
    $cloned_self->{SPInbr}          = $spiNbr;
    $cloned_self->{FrameLength_Bit} = $frameLength_bit;

    return $cloned_self;
}

#-------------------------------------------------------------------------------
sub DESTROY {

    #-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");

    return 1;
}

package SPI_command;

####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####

use strict;
use warnings;
use LIFT_general;

=head1 NAME

SPI_command 

Record class of the EDR Test Framework

=head1 SYNOPSIS

    use SPI_command;

    SPI_command -> new();


=head1 DESCRIPTION

this class is only instanced and accessed by functions of the EDR_Record_Handler

###############################################################################

=head2 new

    $mosi_command_object = SPI_command -> new(    $commandLabel, 
                                                        $mask, 
                                                        $value, 
                                                        $device,
                                                        $instructionLength,
                                                        $transmitType );

I<B<Description:>>     instances a new object of EDR record class -> record object

    mandatory:
                                    For other projects where there is only one response, this is it.

    optional: 
 
I<B<Return:>> Return the blessed (instanced) mosi command object.
              Return nothing if missing mandatory parameter

I<B<Verdict:>> none

I<B<Error:>> for missing mandatory parameters (see Description)

=cut

#------------------------ Constructor ------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $class = shift;    # Perl �bergibt als erstes eine Referenz auf die Klasse, dessen Methode gerufen wurde

    my $self = {
        CommandLabel          => shift,
        Mask                  => shift,
        Value                 => shift,
        Device                => shift,
        InstructionLength_Bit => shift,
        TransmitType          => shift,
        Mask_Bin              => undef,
        Value_Bin             => undef,
        ListOfSubCommands     => {},
        ListOfSignals         => {},
    };

    my $commandLabel = $self->{CommandLabel};
    my $device       = $self->{Device};

    # Check that all mandatory parameters were given
    unless ( defined $self->{CommandLabel} )          { S_set_error("Mosi command cannot be instanced: No 'CommandLabel' given!");          return; }
    unless ( defined $self->{Mask} )                  { S_set_error("Mosi command cannot be instanced: No 'Mask' given!");                  return; }
    unless ( defined $self->{Value} )                 { S_set_error("Mosi command cannot be instanced: No 'Value' given!");                 return; }
    unless ( defined $self->{Device} )                { S_set_error("Mosi command cannot be instanced: No 'Device' given!");                return; }
    unless ( defined $self->{InstructionLength_Bit} ) { S_set_error("Mosi command cannot be instanced: No 'InstructionLength_Bit' given!"); return; }

    S_w2log( 5, " Instancing new mosi command by running Command -> new() \n" );
    S_w2log( 5, " --> Command label: '$commandLabel', Device: '$device' \n" );

    # object $self is attached to the class $class
    return bless $self, $class;
}

###############################################################################

=head2 AddSignal

    $self -> AddSignal(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub AddSignal {

    #-------------------------------------------------------------------------------
    my $self               = shift;
    my $signalLabel        = shift;
    my $type               = shift;
    my $mask               = shift;
    my $value              = shift;
    my $decodingStyle      = shift;
    my $instructionLength  = shift;
    my $signalTransmitType = shift;

    if ( exists $self->{ListOfSignals}->{ $signalLabel . "_" . $type } ) {
        my $commandLabel = $self->{CommandLabel};
        S_set_warning("SIGNAL with same label '$signalLabel' already exists for command '$commandLabel'");
        return 0;
    }
    else {
        my $command    = $self->{CommandLabel};
        my $deviceType = $self->{Device};
        S_w2log( 5, "Add signal $signalLabel ($type) to command $command\n" );
        my $signal_object = SPI_signal->new( $signalLabel, $mask, $value, $type, $decodingStyle, $instructionLength, $signalTransmitType );
        if ( not defined $signal_object ) {
            S_set_error("Signal $signalLabel could not be added for command $command (device $deviceType). Check mapping in SPI maid for this signal.");
            return;
        }
        $self->{ListOfSignals}->{ $signalLabel . "_" . $type } = $signal_object;
    }

    return 1;
}

###############################################################################

=head2 AddSubCommand

    $self -> AddSubCommand(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub AddSubCommand {

    #-------------------------------------------------------------------------------
    my $self              = shift;
    my $commandLabel      = shift;
    my $mask              = shift;
    my $value             = shift;
    my $instructionLength = shift;

    if ( exists $self->{ListOfSubCommands}->{$commandLabel} ) {
        my $mainCommandLabel = $self->{CommandLabel};
        S_set_warning("Sub command with same label '$commandLabel' already exists for command '$mainCommandLabel'");
        return 0;
    }
    else {
        my $sub_command_object = SPI_command->new( $commandLabel, $mask, $value, $self->{Device}, $instructionLength );
        $self->{ListOfSubCommands}->{$commandLabel} = $sub_command_object;
    }
    return $self->{ListOfSubCommands}->{$commandLabel};
}

###############################################################################

=head2 GetDeviceType

    $self -> GetDeviceType(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetDeviceType {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{Device};
}

###############################################################################

=head2 GetCommandLabel

    $self -> GetCommandLabel(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandLabel {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{CommandLabel};
}

###############################################################################

=head2 GetCommandMask

    $self -> GetCommandMask(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandMask {

    #-------------------------------------------------------------------------------
    my $self   = shift;
    my $format = shift;

    unless ( defined $format ) {
        $format = 'HEX';
    }

    my $mask_Hex = $self->{Mask};

    my $returnMask;
    if ( $format eq 'HEX' ) {
        $returnMask = $mask_Hex;
        my $nbrOfBytes = $self->{InstructionLength_Bit} / 4;
        $returnMask = sprintf( "%0" . $nbrOfBytes . "X", hex($mask_Hex) );
    }
    elsif ( lc($format) eq 'bin' ) {
        if ( not defined $self->{Mask_Bin} ) {
            my $length_bit = $self->{InstructionLength_Bit};
            $self->{Mask_Bin} = sprintf( "%0" . $length_bit . "b", hex($mask_Hex) );
        }
        $returnMask = $self->{Mask_Bin};
    }
    else {
        S_set_error("GetSignalMask: Return format '$format' not known. Supported formats: 'BIN', 'HEX'.");
        return;
    }

    return $returnMask;
}

###############################################################################

=head2 GetCommandValue

    $self -> GetCommandValue(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandValue {

    #-------------------------------------------------------------------------------
    my $self   = shift;
    my $format = shift;

    unless ( defined $format ) {
        $format = 'HEX';
    }

    my $value_Hex = $self->{Value};

    my $returnValue;
    if ( $format eq 'HEX' ) {
        $returnValue = $value_Hex;
        my $nbrOfBytes = $self->{InstructionLength_Bit} / 8;
        $returnValue = sprintf( "%0" . $nbrOfBytes . "X", hex($value_Hex) );
    }
    elsif ( lc($format) eq 'bin' ) {
        if ( not defined $self->{Value_Bin} ) {
            my $length_bit = $self->{InstructionLength_Bit};
            $self->{Value_Bin} = sprintf( "%0" . $length_bit . "b", hex($value_Hex) );
        }
        $returnValue = $self->{Value_Bin};
    }
    else {
        S_set_error("GetSignalValue: Return format '$format' not known. Supported formats: 'BIN', 'HEX'.");
        return;
    }

    return $returnValue;
}

###############################################################################

=head2 GetCommandTransmitType

    $self -> GetCommandTransmitType(...);

 
I<B<Description:>> 
	Return value of property 'TransmitType'
	
I<B<Return:>> 

    value of property 'TransmitType'

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandTransmitType {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{TransmitType};
}

###############################################################################

=head2 GetCommandInstructionLength_Bits

    $self -> GetCommandInstructionLength_Bit(...);

 
I<B<Description:>> 
	Return value of property 'InstructionLength_Bit'
	
I<B<Return:>> 

    value of property 'InstructionLength_Bit'

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandInstructionLength_Bit {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{InstructionLength_Bit};
}

###############################################################################

=head2 GetCommandSignalList

    $self -> GetCommandSignalList(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetCommandSignalList {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{ListOfSignals};
}

###############################################################################

=head2 GetSubCommandList

    $self -> GetSubCommandList(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSubCommandList {

    #-------------------------------------------------------------------------------
    my $self                        = shift;
    my $getSubCommandsOfSubCommands = shift;

    my $subCommandList = $self->{ListOfSubCommands};

    if ($getSubCommandsOfSubCommands) {
        foreach my $subCommand ( keys %{$subCommandList} ) {
            my $thisCommandSubCommands = $subCommandList->{$subCommand}->GetSubCommandList(1);
            if ($thisCommandSubCommands) {
                %{$subCommandList} = ( %{$subCommandList}, %{$thisCommandSubCommands} );
            }
        }
    }

    return $self->{ListOfSubCommands};
}

#-------------------------------------------------------------------------------
sub DESTROY {

    #-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");

    return 1;
}

package SPI_signal;

####    ##
#    #    #
#          #
#          #     ####    #####   #####
#          #         #  #     # #     #
#          #     #####   ###     ###
#          #    #    #      ##      ##
#    #    #    #    #  #     # #     #
####   #####   #### #  #####   #####

use strict;
use warnings;
use LIFT_general;

=head1 NAME

SPI_signal 

Signal class of LIFT_spi_database

=head1 SYNOPSIS

    use SPI_signal;

    SPI_signal -> new();


=head1 DESCRIPTION

this class is only instanced and accessed by functions of the LIFT_spi_database

###############################################################################

=head2 new

    $spi_signal_object = SPI_signal -> new(    $signalLabel, 
                                                $mask, 
                                                $value,
                                                $type,
                                                $decoding,
                                                $instructionLength,
                                                $transmitType);

I<B<Description:>>     instances a new object of SPI signal class -> signal object object
 
I<B<Return:>> Return the blessed (instanced) SPI signal object.
              Return nothing if missing mandatory parameter

I<B<Verdict:>> none

I<B<Error:>> for missing mandatory parameters (see Description)

=cut

#------------------------ Constructor ------------------------------------------
sub new {

    #-------------------------------------------------------------------------------
    my $class = shift;    # Perl �bergibt als erstes eine Referenz auf die Klasse, dessen Methode gerufen wurde

    my $self = {
        SignalLabel           => shift,
        Mask                  => shift,
        Value                 => shift,
        Type                  => shift,
        DecodingStyle         => shift,
        InstructionLength_Bit => shift,
        TransmitType          => shift,
        MaskStartPosition     => undef,
        MaskLength_Bit        => undef,
        Mask_Bin              => undef,
        Value_Bin             => undef,
        DataValueTable        => {},
    };

    # Check that all mandatory parameters were given
    unless ( defined $self->{SignalLabel} ) { S_set_error("Signal cannot be instanced: No 'SignalLabel' given!"); return; }
    my $signalLabel = $self->{SignalLabel};
    unless ( defined $self->{Mask} )                  { S_set_error("Signal '$signalLabel' cannot be instanced: No 'Mask' given!");                  return; }
    unless ( defined $self->{Value} )                 { S_set_error("Signal '$signalLabel' cannot be instanced: No 'Value' given!");                 return; }
    unless ( defined $self->{Type} )                  { S_set_error("Signal '$signalLabel' cannot be instanced: No 'Type' given!");                  return; }
    unless ( defined $self->{DecodingStyle} )         { S_set_error("Signal '$signalLabel' cannot be instanced: No 'DecodingStyle' given!");         return; }
    unless ( defined $self->{InstructionLength_Bit} ) { S_set_error("Signal '$signalLabel' cannot be instanced: No 'InstructionLength_Bit' given!"); return; }

    my $type                  = $self->{Type};
    my $mask                  = $self->{Mask};
    my $instructionLength_bit = $self->{InstructionLength_Bit};

    my ( $maskStartPosition, $maskLength ) = _check_mask( $signalLabel, $mask, $instructionLength_bit );

    unless ( defined $maskStartPosition ) {
        S_set_error( "Mask check failed for signal $signalLabel.\n" . "Mask: $mask, Criteria: Masked bits must be coherent, only one set of coherent bits allowed." . "Signal will not be added." );
        return;
    }

    $self->{MaskStartPosition} = $maskStartPosition;
    $self->{MaskLength_Bit}    = $maskLength;

    #    S_w2log (5, " Instancing new signal by running SIGNAL -> new() \n");
    S_w2log( 5, " --> New Signal label: '$signalLabel', Type: '$type' \n" );

    # object $self is attached to the class $class
    return bless $self, $class;
}

###############################################################################

=head2 GetSignalLabel

    $self -> GetSignalLabel(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalLabel {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{SignalLabel};
}

###############################################################################

=head2 GetSignalMask

    $self -> GetSignalMask(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalMask {

    #-------------------------------------------------------------------------------
    my $self   = shift;
    my $format = shift;

    unless ( defined $format ) {
        $format = 'HEX';
    }

    my $mask_Hex = $self->{Mask};

    my $returnMask;
    if ( lc($format) eq 'hex' ) {
        $returnMask = $mask_Hex;
        my $nbrOfBytes = $self->{InstructionLength_Bit} / 4;
        $returnMask = sprintf( "%0" . $nbrOfBytes . "X", hex($mask_Hex) );
    }
    elsif ( lc($format) eq 'bin' ) {
        if ( not defined $self->{Mask_Bin} ) {
            my $length_bit = $self->{InstructionLength_Bit};
            $self->{Mask_Bin} = sprintf( "%0" . $length_bit . "b", hex($mask_Hex) );
        }
        $returnMask = $self->{Mask_Bin};
    }
    else {
        S_set_error("GetSignalMask: Return format '$format' not known. Supported formats: 'BIN', 'HEX'.");
        return;
    }

    return $returnMask;
}

###############################################################################

=head2 GetSignalValue

    $self -> GetSignalValue(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalValue {

    #-------------------------------------------------------------------------------
    my $self   = shift;
    my $format = shift;

    unless ( defined $format ) {
        $format = 'HEX';
    }

    my $value_Hex = $self->{Value};

    my $returnValue;
    if ( $format eq 'HEX' ) {
        $returnValue = $value_Hex;
    }
    elsif ( lc($format) eq 'bin' ) {
        if ( not defined $self->{Value_Bin} ) {
            my $length_bit = $self->{InstructionLength_Bit};
            $self->{Value_Bin} = sprintf( "%0" . $length_bit . "b", hex($value_Hex) );
        }
        $returnValue = $self->{Value_Bin};
    }
    else {
        S_set_error("GetSignalValue: Return format '$format' not known. Supported formats: 'BIN', 'HEX'.");
        return;
    }

    return $returnValue;
}

###############################################################################

=head2 GetSignalType

    $self -> GetSignalType(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetSignalType {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{Type};
}

###############################################################################

=head2 GetDecodingStyle

    $self -> GetDecodingStyle(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetDecodingStyle {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{DecodingStyle};
}

###############################################################################

=head2 GetInstructionLength_Bit

    $self -> GetInstructionLength_Bit(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetInstructionLength_Bit {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{InstructionLength_Bit};
}

###############################################################################

=head2 GetTransmitType

    $self -> GetTransmitType(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetTransmitType {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return $self->{TransmitType};
}

###############################################################################

=head2 GetMaskStartPosAndLength

    $self -> GetMaskStartPosAndLength(...);

 
I<B<Description:>> 

I<B<Return:>> 

    nothing:
    1:

I<B<Verdict:>> none

I<B<Error:>> 

=cut

#-------------------------------------------------------------------------------
sub GetMaskStartPosAndLength {

    #-------------------------------------------------------------------------------
    my $self = shift;

    return ( $self->{MaskStartPosition}, $self->{MaskLength_Bit} );
}

=head1 Internal Functions

=head2 _check_mask

   my ($startPosition, $maskLength) = _check_mask ($signalLabel, $mask, $length_bit);

    Checks whether given mask for signal is valid.
    Only if this check passes, the signal object will be instanced.
    
    Criteria:
    - bit mask must not be interrupted
    
    Returns start position and length.
    
=cut

#-------------------------------------------------------------------------------
sub _check_mask {

    #-------------------------------------------------------------------------------
    my $signalLabel = shift;
    my $mask        = shift;
    my $length_bit  = shift;

    my $mask_bit = sprintf( "%0" . $length_bit . "b", hex($mask) );
    S_w2log( 5, "_check_mask ($signalLabel): $mask_bit \n" );
    my @mask_bitarray = split( //, $mask_bit );

    my $startPos;
    my $maskLength      = 0;
    my $arrayIndexCount = 0;
    my $maskStarted     = 0;

    foreach my $bitInMask (@mask_bitarray) {
        if ( $bitInMask == 1 and not defined $startPos ) {
            $startPos    = $arrayIndexCount;
            $maskStarted = 1;
            $maskLength  = 1;
        }
        elsif ( $bitInMask == 1 and $maskStarted ) {
            $maskLength++;
        }
        elsif ( $bitInMask == 1 and defined $startPos and not $maskStarted ) {
            S_set_error( "Bit mask was interrupted which is not supported. Bit mask start position and length already known.\n" . "Signal: $signalLabel" );
            return;
        }
        else {
            $maskStarted = 0;
        }

        $arrayIndexCount++;
    }

    return ( $startPos, $maskLength );
}

#-------------------------------------------------------------------------------
sub DESTROY {

    #-------------------------------------------------------------------------------
    #
    # Destructor - just to have one
    #

    my $self = shift;

    # check for an overridden destructor...
    $self->SUPER::DESTROY if $self->can("SUPER::DESTROY");

    return 1;
}

1;
__END__

 
