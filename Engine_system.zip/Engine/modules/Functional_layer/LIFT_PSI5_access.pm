#*****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_PSI5_access;

=head1 NAME

LIFT_PSI5_access

=head1 SYNOPSIS

    use LIFT_PSI5_access;

    # initilise PSI5 sensors
    PSI5_init();
    - initialises the devices configured for PSI5 
    - initilaises the PSI5 sensor and line configuration from Mapping_PSI5_settings.pm
    
    # sets the line properties
    PSI5_set_lines ( 1 => {
                           'QUIESCENT_CURR_MA' => 20,
                           'TRANSMIT_CURR_MA' => 35,
                           'AUTO_RESTART_TIME_US' => 36,
                           'BAUDRATE_KBPS' => 125,
                           'AUTO_RESTART_INT' =>  1,
                           'REBOOT_COUNTER_INT' => 1,
                           'PARITY_BIT_TS1_INT' => 1,
                           'PARITY_BIT_TS2_INT' => 1,
                           'PARITY_BIT_TS3_INT' => 1,
                           'PARITY_BIT_TS4_INT' => 1,
                           'TIMESLOT_TS1_US' => 45,
                           'TIMESLOT_TS2_US' =>  100,
                           'TIMESLOT_TS3_US' =>  120,
                           'TIMESLOT_TS4_US' =>  145
                         }
                   );

    # sets the init times for the sensor 60.5ms (time 1) , 128ms (time 2) , 8ms (time 3)               
    PSI5_set_Init_Times ( 'UFSD', { 1 => 60.5 ,  2 => 128, 3 => 8 } );

    # sets Init1 Data of the sensor

    # Label format
    PSI5_set_Init_Data ( 'UFSD', 1, { 
                                      'INIT1_MESSAGE' => 'NO_MESSAGES',
                                    },
                       );

    # Byte format
    PSI5_set_Init_Data ( 'UFSD', 1 , { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' } } );
    PSI5_set_Init_Data ( 'UFSD', 1 , { 
                                     '1' => { 'DATA_VALUE_HEX' => '0x001' } ,
                                     '2' => { 'DATA_VALUE_HEX' => '0x002' } ,
                                     '3' => { 'DATA_VALUE_HEX' => '0x003' } ,
                                     '4' => { 'DATA_VALUE_HEX' => '0x004' } ,
                                     } );

    # sets Init2 Data of the sensor

    # Label format
    # set SATELLITE_SENSING_AXIS to SENSING_AXIS_Y

    PSI5_set_Init_Data ( 'UFSD', 2, { 
                                       'SATELLITE_SENSING_AXIS' => 'SENSING_AXIS_Y',
                                    } 
                       );
    # Byte format
    # sets the specific control bits of Init2 (examples in different data elements )

    PSI5_set_Init_Data ( 'UFSD', 1 , { '8' => { 'ENABLE_SENSOR_STR' => '0' } } );
    PSI5_set_Init_Data ( 'UFSD', 1 , { '6' => { 'MANCHESTER_FAULT_INT' => '1' } } );
    PSI5_set_Init_Data ( 'UFSD', 1 , { '6' => { 'MANCHESTER_FAULT_INT' => '0' } } );  # reset
    PSI5_set_Init_Data ( 'UFSD', 1 , { '7' => { 'PARITY_FAULT_INT' => '1' } } );
    PSI5_set_Init_Data ( 'UFSD', 1 , { '7' => { 'PARITY_FAULT_INT' => '0' } } ); # reset
    PSI5_set_Init_Data ( 'UFSD', 1 , { '5' => { 'RESET_LOOP_INT' => '1' } } );


    # same for Init2 Data in Data element nr 13                                                                          
    PSI5_set_Init_Data ( 'UFSD', 2 , { '13' => { 'MANCHESTER_FAULT_INT' => '1' } } );
    PSI5_set_Init_Data ( 'UFSD', 2 , { '13' => { 'MANCHESTER_FAULT_INT' => '0' } } ); # reset

    # sets Init3 Data of the sensor

    # Label format
    # set INIT3_MESSAGE to SENSOR_OK

    PSI5_set_Init_Data ( 'UFSD', 3, { 
                                      'INIT3_MESSAGE' => 'SENSOR_OK',
                                    },
                       );

    # Byte format
    # set manchester fault for Init3 Data in Data elements nbr 23 and 46

    PSI5_set_Init_Data ( 'UFSD', 3 , { 
                                        '23' => { 'MANCHESTER_FAULT_INT' => '1' }, 
                                        '46' => { 'MANCHESTER_FAULT_INT' => '1' }, 
                                     } 
                        );
    # reset operation
    PSI5_set_Init_Data ( 'UFSD', 3 , { 
                                        '23' => { 'MANCHESTER_FAULT_INT' => '0' }, 
                                        '46' => { 'MANCHESTER_FAULT_INT' => '0' }, 
                                     } 
                        );

    # sets Cyclic messages of the sensor

    # Label format

    PSI5_set_CyclicMsgs( 'UFSD', { 
                                    'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' },
                                    'NUMBER_OF_USED_BYTES' => '68',
                                 }
                       );

    # Byte format
    # sets Cyclic Msgs Data of the sensor
    PSI5_set_CyclicMsgs ( 'UFSD', { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' } } );

    # sets the specific control bits of Init2 (examples in different data elements ) 
    PSI5_set_CyclicMsgs ( 'UFSD', { '8' => { 'ENABLE_SENSOR_STR' => '0' } } );
    PSI5_set_CyclicMsgs ( 'UFSD', { '6' => { 'MANCHESTER_FAULT_INT' => '1' } } );
    PSI5_set_CyclicMsgs ( 'UFSD', { '7' => { 'PARITY_FAULT_INT' => '1' } } );
    PSI5_set_CyclicMsgs ( 'UFSD', { '5' => { 'RESET_LOOP_INT' => '1' } } );

    # sets Cyclic Msgs Data of the sensor
    PSI5_set_UserMsgs ( 'UFSD', { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' } } );

    # sets the specific control bits of Init2 (examples in different data elements ) 
    PSI5_set_UserMsgs ( 'UFSD', { '8' => { 'ENABLE_SENSOR_STR' => '0' } } );
    PSI5_set_UserMsgs ( 'UFSD', { '6' => { 'MANCHESTER_FAULT_INT' => '1' } } );
    PSI5_set_UserMsgs ( 'UFSD', { '7' => { 'PARITY_FAULT_INT' => '1' } } );
    PSI5_set_UserMsgs ( 'UFSD', { '5' => { 'RESET_LOOP_INT' => '1' } } );


    # switch on PSI5line
    PSI5_switch_on_sensor ( 'UFSD' );
    
    # re-initialize sensor with original config data the end of a testscript 
    PSI5_sensor_reinit ( 'UFSD' );

=head1 DESCRIPTION


=head2 Testbench Configuration  (LIFT_testbenches.pm)


    'localhost' => {      # LIFT PC host name
      
        'Devices' => {
          
            'Manitoo' => {
                          'Description' => "Manitoo",    # only for logging purpose
                          'Connection_Type' => 'COM1' ,
                            # Supported types COM, USB
                            # COM : COM port detected when connected to TestPC
                            # USB : USB-A to USB-A connector.
                            # Drivers needs to be installed for this : refer link
                            # https://inside-docupedia.bosch.com/confluence/display/MOBIT/Setup+USB+connection+for+mobiTOOL
                            
                          'FET_HW_Type' => 'FET_6_Ports',# FET_3_Ports , FET_6_Ports, FET_15_Ports 
                          'FET_PortsSelection' => 1      # If only one port on/off  -> 1 or 2 or 3...
                                                         # If multiple ports on/off -> [1,2] or [2,3]
            },
        },
        
       'Functions' => {
           
            'PSI5_Access' => {
                                'simulate' => 'Manitoo' ,
                                # ManitooPAS hardware should be connected to Manitoo ( QuaTe coming soon)
            },
        },
    },


=head2 PSI5 Configuration  ( Mapping_PSI5_settings.pm)


    #
    # PSI5_LINES_DEFAULTS - Default setting of all lines listed under 'PSI5_LINES'
    #
    $Defaults->{'PSI5_LINES_DEFAULTS'} = {
            'AUTO_RESTART_TIME_US' => 507,
            'AUTO_RESTART_INT'     => 0,
            'PARITY_BIT_TS1_INT'   => 1,
            'PARITY_BIT_TS2_INT'   => 1,
            'PARITY_BIT_TS3_INT'   => 1,
            'PARITY_BIT_TS4_INT'   => 1,
            'REBOOT_COUNTER_INT'   => 1,
            'TIMESLOT_TS1_US'      => 48,      #  <-- refered from PSI5_SENSORS_PROJECT
            'TIMESLOT_TS2_US'      => 192,     #   dito
            'TIMESLOT_TS3_US'      => 348,     #   dito
            'TIMESLOT_TS4_US'      => 383,     #   dito
            'BAUDRATE_KBPS'        => 125,
    };


    #
    # PSI5_LINES : all used lines must be configured with at least the PSI5_LINES_DEFAULTS entry
    #
    #  # INDEX / KEY => PSI5 LINE NUMBER  
    #
    $Defaults->{'PSI5_LINES'} = {
        1 => {
            'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS' ,
            # from here onwards settings of 'PSI5_LINES_DEFAULTS' can be overwritten
        },
        2 => {
            'USE_DEFAULTS' => 'PSI5_LINES_DEFAULTS' ,
            # from here onwards settings of 'PSI5_LINES_DEFAULTS' can be overwritten, e.g.
            'TIMESLOT_TS1_US'      => 48,    #  <-- refered from PSI5_SENSORS_PROJECT
            'TIMESLOT_TS2_US'      => 192,
            'TIMESLOT_TS3_US'      => 348,
            'TIMESLOT_TS4_US'      => 383,           
            'BAUDRATE_KBPS'        => 125,
        },
        ....
    };

    #
    #  PSI5_SENSORS_PROJECT  : project specific configuration of each used PSI5 sensor
    #
    #    (just 2 examples given)
    #
    $Defaults->{'PSI5_SENSORS_PROJECT'} = {
        #
        #  Project Sensor device name  - UFS D ( Driver )
        #
        'UFSD' => {
            'LINE' => 1,    # Reference to Line -> $Defaults->{'PSI5_LINES'}
            'TYPE'       => 'UFS3', # Reference to sensor type -> $Defaults->{'PSI5_SENSOR_TYPES'}
            'INIT1_DATA' => {
                'INIT1_MESSAGE' => 'NO_MESSAGES'
            },

            # Complete set configures Init2 data
            'INIT2_DATA' => '0X42010614A50000002100375033513152', (SCALAR)
            
            (or)
            
            'INIT2_DATA' => {                                     (HREF)
                PROTOCOL_REVISION     => 4,
                NUMBER_OF_DATA_BLOCKS => 32,
                MANUFACTURER          => 'BOSCH',
    
                SENSOR_BUS_MODE => 'BUS3_TIMESLOT2',
                SENSOR_TYPE     => 'ACCELERATION_SENSOR',
    
                SATELLITE_SENSING_AXIS => 'SENSING_AXIS_Y',
    
                ACCELERATION_RANGE     => '480g_RANGE',
                SENSOR_CODE            => 'PAS5x_UFS3x_SMA_AXIS_Y_FILTER_426Hz',
                HOUSING_CODE           => '0X10',
                SENSOR_CODE_CUSTOMER   => '0X00',
                SGB_MANUFACTURING_DATE => '1-1-2000',
                LOT_NUMBER             => '0X0',
                LINE_NUMBER            => '0X0',
                SERIES_NUMBER          => '0x375033513152',
            },

            'INIT3_DATA' => {
                'INIT3_MESSAGE' => 'SENSOR_OK',
            },

            'CYCLIC_MESSAGES' => {
                'ALL' => '0x000', # even all individual bytes can be given ( '1' => '0x000'  , ... )
                'NUMBER_OF_USED_BYTES' => 68, # optional, by default 256 bytes is considered
            },

            'USER_MESSAGES' => {
                'ALL' => '0x000',# even all individual bytes can be given ( '1' => '0x000'  , ... )
                'NUMBER_OF_USED_BYTES' => 10, # optional, by default 16 bytes is considered
            },

            'TIMESLOT' => 'TIMESLOT_TS2_US', # Reference to timeslot configured in PSI5_LINES
        },

        'PTSD' => {
            'LINE' => 5, # Reference to Line -> $Defaults->{'PSI5_LINES'}
            'TYPE'       => 'PTS1', #Reference to sensor type -> $Defaults->{'PSI5_SENSOR_TYPES'}
            'INIT1_DATA' => {
                'INIT1_MESSAGE' => 'NO_MESSAGES'
            },
    
            'INIT2_DATA' => {
                PROTOCOL_REVISION     => 4,
                NUMBER_OF_DATA_BLOCKS => 32,
                MANUFACTURER          => 'BOSCH_ASCII',
                SENSOR_TYPE => 'PRESSURE_SENSOR',
                TRANSMISSION_MODE => 'PPS3_ABS_PRESSURE_ON',
                SENSOR_TYPE_PSI_CONFIGURATION => '0x7',
                ELECTRONIC_HOUSE_CODING       => '0xAB',
                MANUFACTURER_SERIES_CODE      => '0x1',
                SGB_MANUFACTURING_DATE        => '1-1-2004',
                LOT_NUMBER                    => '0XF',
                LINE_NUMBER                   => '0X5',
                SERIES_NUMBER                 => '0x303338363437',
            },
            'INIT3_DATA' => {
                'INIT3_MESSAGE'           => 'SENSOR_OK',
                'ABSOLUTE_PRESSURE_VALUE' => 1000
            },
    
            'CYCLIC_MESSAGES' => {
                'NUMBER_OF_USED_BYTES'    => 68, # optional, by default 256 bytes is considered
                'ABSOLUTE_PRESSURE_VALUE' => 1000
            },
    
            'USER_MESSAGES' => {
                'ALL' => '0x000', # even all individual bytes can be given ( '1' => '0x000'  , ... )
            },

            'TIMESLOT' => 'TIMESLOT_TS3_US', # Reference to timeslot in $Defaults->{'PSI5_LINES'}
            },
        ....
    };


    #
    #  PSI5_SENSORS_TYPES  : - project specific configuration of different used sensor types
    #                       - refered from  'TYPE'  setting in  {'PSI5_SENSORS_PROJECT'} 
    #                         
    #
    #    (just 2 examples given)
    #

    $Defaults->{'PSI5_SENSORS_TYPES'} = {
        'UFS3R' => {                      #  <-- refered from 'TYPE' in PSI5_SENSORS_PROJECT
            'QUIESCENT_CURR_MA' => 4,
            'TRANSMIT_CURR_MA'  => 26,
            'INIT1_TIME_MS'     => 60.5,
            'INIT2_TIME_MS'     => 128,
            'INIT3_TIME_MS'     => 8,
        },
        'PAS5R' => {                      #  <-- refered from 'TYPE' in PSI5_SENSORS_PROJECT
            'QUIESCENT_CURR_MA' => 4,
            'TRANSMIT_CURR_MA'  => 26,
            'INIT1_TIME_MS'     => 60.5,
            'INIT2_TIME_MS'     => 128,
            'INIT3_TIME_MS'     => 8,
        },
        ....
    };

For INIT2 Data to be used in PSI5_set_Init_Data see 

=for html
<a href="LIFT_PSI5_access_INIT2_Data.html">LIFT_PSI5_access_INIT2_Data</a>

=cut

use strict;
use warnings;
use LIFT_general;
use LIFT_manitoo;
use LIFT_functional_layer;
use Data::Dumper;
require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  PSI5_init
  PSI5_sensor_reinit
  PSI5_set_lines
  PSI5_set_Init_Times
  PSI5_set_Init_Data
  PSI5_set_CyclicMsgs
  PSI5_set_UserMsgs
  PSI5_set_Sensor_Defect
  PSI5_get_line_status
  PSI5_get_reboot_counter
  PSI5_reset_reboot_counter
  PSI5_switch_off_sensor
  PSI5_switch_on_sensor
  PSI5_exit
  PSI5_set_sensor_Baudrate_kbps
  PSI5_print_docu
);

our ( $VERSION, $HEADER );

my $ALL_SENSORS_INIT_href = {};    # GLOBAL VAR  (required for PSI5_sensor_reinit)
my $INIT2_LABEL_href      = {};    # GLOBAL VAR (required for PSI5_set_Init_Data)
my $CYCLIC_DATA_href      = {};
my $USER_DATA_href        = {};
my $SENSOR_INIT_DATA      = {};
Readonly::Scalar my $INIT_1_ARRAY_SIZE      => 32;
Readonly::Scalar my $INIT_2_ARRAY_SIZE      => 16;
Readonly::Scalar my $INIT_3_ARRAY_SIZE      => 16;
Readonly::Scalar my $CYCLIC_MSGS_ARRAY_SIZE => 256;
Readonly::Scalar my $USER_MSGS_ARRAY_SIZE   => 16;
Readonly::Scalar my $MAX_DATA_BLOCKS        => 128;
Readonly::Scalar my $MAX_PROTOCOL_VALUE     => 15;
Readonly::Scalar my $INIT_3_MESSAGES_SIZE   => 12;
Readonly::Scalar my $MAX_ABS_PRESSURE_VAL   => 4095;
Readonly::Scalar my $INIT_TYPE_3            => 3;

Readonly::Hash my %SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R => {
    PROTOCOL_REVISION      => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS  => 1,     # NIBBLE 2 and 3
    MANUFACTURER           => 3,     # NIBBLE 4 and 5
    SENSOR_BUS_MODE        => 5,     # NIBBLE 6
    SENSOR_TYPE            => 6,     # NIBBLE 7
    SATELLITE_SENSING_AXIS => 7,     # NIBBLE 8
    ACCELERATION_RANGE     => 8,     # NIBBLE 9
    SENSOR_CODE            => 9,     # STARTING 2 BITS( '00'00 ) OF NIBBLE 10
    HOUSING_CODE           => 10,    # TRAILING 2 BITS( 00'00' ) OF NIBBLE 10 AND COMPLETE NIBBLE 11
    SENSOR_CODE_CUSTOMER   => 11,    # NIBBLES 12, 13 AND 14
    SGB_MANUFACTURING_DATE => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER             => 18,    # NIBBLE 19
    LINE_NUMBER            => 19,    # NIBBLE 20
    SERIES_NUMBER          => 20,    # NIBBLE 21 TO 31
};

Readonly::Hash my %SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e => {
    PROTOCOL_REVISION      => 0,
    NUMBER_OF_DATA_BLOCKS  => 1,
    MANUFACTURER           => 3,
    PAS6e_GENERATION_BIT   => 5,
    SENSOR_TYPE            => 6,
    ACCELERATION_AXIS      => 7,
    ACCELERATION_RANGE     => 8,
    SENSOR_CODE            => 9,
    HOUSING_CODE           => 10,
    SENSOR_CODE_CUSTOMER   => 11,
    SGB_MANUFACTURING_DATE => 14,
    LOT_NUMBER             => 18,
    LINE_NUMBER            => 19,
    SERIES_NUMBER          => 20,
};

Readonly::Hash my %SENSOR_TYPES_PPS3 => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    SENSOR_TYPE                   => 5,     # NIBBLE 6 AND 7  -> VALUE '0X08' FOR PRESSURE SENSOR
    TRANSMISSION_MODE             => 7,     # NIBBLE 8
    SENSOR_TYPE_PSI_CONFIGURATION => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    ELECTRONIC_HOUSE_CODING       => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    MANUFACTURER_SERIES_CODE      => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     #NIBBLE 21 to 31
};

Readonly::Hash my %SENSOR_TYPES_PPS3e_PTS1e => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    FILTER_TYPE_AND_SAMPLING_MODE => 5,     # NIBBLE 6 filter type and sampling mode
    PRESSURE_SENSOR_TYPE          => 6,     # NIBBLE 7
    SENSOR_MODE                   => 7,     # NIBBLE 8
    PSI5_MODE                     => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    BOSCH_SENSOR_CODE             => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    SENSOR_CODE_CUSTOMER          => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     #NIBBLE 21 to 31
};

Readonly::Hash my %SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f => {
    PROTOCOL_REVISION            => 0,
    NUMBER_OF_DATA_BLOCKS        => 1,
    MANUFACTURER                 => 3,
    PAS6sf_GENERATION_BIT        => 5,
    SENSOR_TYPE                  => 6,
    ACCELERATION_AXIS_AND_FILTER => 7,
    ACCELERATION_RANGE           => 8,
    SAMPLE_TIME_AND_FILTER       => 9,
    HOUSING_CODE                 => 10,
    SENSOR_CODE_CUSTOMER         => 11,
    SGB_MANUFACTURING_DATE       => 14,
    LOT_NUMBER                   => 18,
    LINE_NUMBER                  => 19,
    SERIES_NUMBER                => 20,
};

Readonly::Hash my %SENSOR_TYPES_PPS2 => {
    PROTOCOL_REVISION             => 0,     # NIBBLE 1
    NUMBER_OF_DATA_BLOCKS         => 1,     # NIBBLE 2 AND 3
    MANUFACTURER                  => 3,     # NIBBLES 4 AND 5
    SENSOR_TYPE                   => 5,     # NIBBLE 6 AND 7  -> VALUE '0X08' FOR PRESSURE SENSOR
    TRANSMISSION_MODE             => 7,     # NIBBLE 8
    SENSOR_TYPE_PSI_CONFIGURATION => 8,     # NIBBLE 9 -> RANGE '0X0' -'0XF'
    BOSCH_SENSOR_CODE             => 9,     # NIBBLE 10 AND 11 -> RANGE '0X0' - '0XFF'
    SENSOR_CODE_CUSTOMER          => 11,    # NIBBLE 12, 13 AND 14 -> RANGE '0X0' - '0XFFF'
    SGB_MANUFACTURING_DATE        => 14,    # NIBBLES 15, 16, 17 AND 18
    LOT_NUMBER                    => 18,    # NIBBLE 19 -> RANGE '0X0' - '0XF'
    LINE_NUMBER                   => 19,    # NIBBLE 20 -> RANGE '0X0' - '0XF'
    SERIES_NUMBER                 => 20     # NIBBLE 21 to 31
};

Readonly::Hash my %MANUFACTURER => {
    BOSCH                     => '0x10',
    BOSCH_ASCII               => '0x42',
    AUTOLIV                   => '0x40',
    AUTOLIV_ASCII             => '0x41',
    CONTINENTAL               => '0x80',
    CONTINENTAL_ASCII         => '0x43',
    ANALOG_DEVICES_ASCII      => '0x44',
    ELMOS_ASCII               => '0x45',
    FREESCALE_ASCII           => '0x45',
    TRW_ASCII                 => '0x54',
    NO_SPECIFIED_MANUFACTURER => '0x00'
};

Readonly::Hash my %SENSOR_TYPE => {
    ACCELERATION_SENSOR => '0x1',    # length is 1 nible ( nbr 7 )
    PRESSURE_SENSOR     => '0x8',    # length is 1 byte  ( nible nbr 6 + 7 )
};

Readonly::Hash my %PRESSURE_SENSOR_TYPE => {
    PN_SENSOR        => '0x8',       # length 1 nibble
    P0_T_SENSOR      => '0x9',       # length 1 nibble
    PN_COARSE_SENSOR => '0xC',       # length 1 nibble
    P_LOW_SENSOR     => '0x5',       # length 1 nibble
    P_HIGH_SENSOR    => '0x6',       # length 1 nibble
    T_SENSOR         => '0x7',       # length 1 nibble
};

Readonly::Hash my %SENSOR_BUS_MODE => {    # POSSIBLE CONFIGURATIONS
    BUS3_TIMESLOT1   => '0x5',
    BUS3_TIMESLOT2   => '0x6',
    BUS3_TIMESLOT3   => '0x7',
    BUS4_TIMESLOT1   => '0xC',
    BUS4_TIMESLOT2   => '0xD',
    BUS4_TIMESLOT3   => '0xE',
    BUS4_TIMESLOT4   => '0xF',
    PAS6F_GENERATION => '0x2',
};

Readonly::Hash my %PAS6e_GENERATION_BIT => {
    PAS6  => '0X0',
    PAS6e => '0X1',
};

Readonly::Hash my %PAS6sf_GENERATION_BIT => {
    PAS6s => '0X2',
    PAS6f => '0X2',
};

Readonly::Hash my %SATELLITE_SENSING_AXIS => {
    SENSING_AXIS_X => '0x0',
    SENSING_AXIS_Y => '0x4',
};

# SENSOR TYPES SUPPORTED PAS5, PAS5R, UFS3, UFS3R, PAS5XY, UFS6, UFS6e, PAS6, PAS6e
Readonly::Hash my %ACCELERATION_RANGE => {
    '120g_RANGE' => '0x8',
    '240g_RANGE' => '0x9',
    '480g_RANGE' => '0xA',
};

Readonly::Hash my %SENSOR_MODE => {
    'PRESSURE_-5%_to_+15%'    => '0x4',
    'PRESSURE_RESERVED'       => '0x5',
    'PRESSURE_-15%_to_+23.4%' => '0x6',
    'PRESSURE_-15%_to_+100%'  => '0x7',
    'NONE_-5%_to_+15%'        => '0x0',
    'NONE_RESERVED'           => '0x1',
    'NONE_-15%_to_+23.4%'     => '0x2',
    'NONE_-15%_to_+100%'      => '0x3',

};

Readonly::Hash my %SENSOR_CODE => {

    # PAS5, PAS5R, UFS3, UFS3R
    PAS5x_UFS3x_SMA_AXIS_X_FILTER_213Hz => '2',
    PAS5x_UFS3x_SMA_AXIS_X_FILTER_426Hz => '0',
    PAS5x_UFS3x_SMA_AXIS_Y_FILTER_213Hz => '3',
    PAS5x_UFS3x_SMA_AXIS_Y_FILTER_426Hz => '1',

    # PAS6, UFS6
    PAS6_UFS6_SMA_AXIS_X_FILTER_200Hz => '2',
    PAS6_UFS6_SMA_AXIS_X_FILTER_400Hz => '0',
    PAS6_UFS6_SMA_AXIS_Y_FILTER_200Hz => '3',
    PAS6_UFS6_SMA_AXIS_Y_FILTER_400Hz => '1',

    # PAS6e, UFS6e
    PAS6e_426Hz_6us_SAMPLE_TIME  => '0',
    PAS6e_426Hz_FAST_SAMPLE_TIME => '1',
    PAS6e_213Hz_6us_SAMPLE_TIME  => '2',
    PAS6e_213Hz_FAST_SAMPLE_TIME => '3',
};

Readonly::Hash my %ACCELERATION_AXIS => {
    ACCELERATION_AXIS_ALPHA => '0x4',
    ACCELERATION_AXIS_BETA  => '0x0',
    ACCELERATION_AXIS_GAMMA => '0x8',
};

Readonly::Hash my %ACCELERATION_AXIS_AND_FILTER => {
    AXIS_ALPHA_FILTER_426Hz => '0x4',    # 0b0100
    AXIS_ALPHA_FILTER_213Hz => '0x4',    # 0b0100
    AXIS_ALPHA_FILTER_852Hz => '0x5',    # 0b0101
    AXIS_ALPHA_FILTER_53Hz  => '0x5',    # 0b0101

    AXIS_BETA_FILTER_426Hz => '0x0',     # 0b0000
    AXIS_BETA_FILTER_213Hz => '0x0',     # 0b0000
    AXIS_BETA_FILTER_852Hz => '0x1',     # 0b0001
    AXIS_BETA_FILTER_53Hz  => '0x1',     # 0b0001

    AXIS_GAMMA_FILTER_426Hz => '0x8',    # 0b1000
    AXIS_GAMMA_FILTER_213Hz => '0x8',    # 0b1000
    AXIS_GAMMA_FILTER_852Hz => '0x9',    # 0b1001
    AXIS_GAMMA_FILTER_53Hz  => '0x9',    # 0b1001
};

Readonly::Hash my %SAMPLE_TIME_AND_FILTER => {
    PAS6s_FAST_SAMPLETIME_FILTER_426Hz => '1',    # 0b0100
    PAS6s_FAST_SAMPLETIME_FILTER_213Hz => '3',    # 0b1100
    PAS6s_FAST_SAMPLETIME_FILTER_852Hz => '1',    # 0b0100
    PAS6s_FAST_SAMPLETIME_FILTER_53Hz  => '3',    # 0b1100

    PAS6s_49US_SAMPLETIME_FILTER_426Hz => '0',    # 0b0000
    PAS6s_49US_SAMPLETIME_FILTER_213Hz => '2',    # 0b1000
    PAS6s_49US_SAMPLETIME_FILTER_852Hz => '0',    # 0b0000
    PAS6s_49US_SAMPLETIME_FILTER_53Hz  => '2',    # 0b1000
};

Readonly::Hash my %FILTER_TYPE_AND_SAMPLING_MODE => {
    IIR_FAST         => '0x0',
    IIR_6_US_COMMON  => '0x2',
    IIR_49_US_COMMON => '0x4',
    FIR_FAST         => '0x8',
    FIR_6_US_COMMON  => '0x5',
    FIR_49_US_COMMON => '0x6',
};

Readonly::Hash my %TRANSMISSION_MODE => {
    PTS1_ABS_PRESSURE_ON                  => '0x0',
    PTS1_ABS_PRESSURE_OFF                 => '0x8',
    PPS3_ABS_PRESSURE_ON                  => '0x0',
    PPS3_ABS_PRESSURE_OFF                 => '0x8',
    PPS2_ABS_PRESSURE_ON_AND_PARITY_MODE  => '0x0',
    PPS2_ABS_PRESSURE_ON_AND_CRC_MODE     => '0x4',
    PPS2_ABS_PRESSURE_OFF_AND_PARITY_MODE => '0x8',
    PPS2_ABS_PRESSURE_OFF_AND_CRC_MODE    => '0xC',

};

Readonly::Hash my %PSI5_MODE => {
    A10P_250_1L_PARITY                                              => '0x0',
    P10P_500_3L_PN_SLOT1_PARITY                                     => '0x5',
    P10P_500_3L_PN_SLOT2_PARITY                                     => '0x6',
    P10P_500_3L_PN_SLOT3_PARITY                                     => '0x7',
    P10P_500_3L_PN_COARSE_SLOT1__PN_SLOT3_PARITY                    => '0x2',
    P10P_500_3L_PO_T_SLOT2__PN_SLOT3_PARITY                         => '0x3',
    P10P_500_3L_PN_COARSE_SLOT1__PO_T_SLOT2__PN_SLOT3_PARITY        => '0x4',
    P10P_500_4H_PN_SLOT1_PARITY                                     => '0x8',
    P10P_500_4H_PN_SLOT2_PARITY                                     => '0x9',
    P10P_500_4H_PN_SLOT3_PARITY                                     => '0xA',
    P10P_500_4H_PN_SLOT4_PARITY                                     => '0xB',
    P10P_500_4H_PN_COARSE_SLOT1__PN_SLOT4_PARITY                    => '0xC',
    P10P_500_4H_PO_T_SLOT3__PN_SLOT4_PARITY                         => '0xD',
    P10P_500_4H_PN_COARSE_SLOT1__PO_T_SLOT3__PN_SLOT4_PARITY        => '0xE',
    P10P_500_4H_PO_T_SLOT1__PN_SLOT2_PARITY                         => '0xF',
    P16CRC_500_2L_PO_T_SLOT1__PN_SLOT1_CRC                          => '0x15',
    P16CRC_500_2L_PO_T_SLOT2__PN_SLOT2_CRC                          => '0x16',
    P16CRC_500_3H_PO_T_SLOT1__PN_SLOT1_CRC                          => '0x18',
    P16CRC_500_3H_PO_T_SLOT2__PN_SLOT2_CRC                          => '0x19',
    P16CRC_500_3H_PO_T_SLOT3__PN_SLOT3_CRC                          => '0x1A',
    P10P_500_3L_PADC_LOW_SLOT1__PADC_HIGH_SLOT2___TADC_SLOT3_PARITY => '0x14',
};

my $INIT2_DATA_SENSOR_CONFIG_MAPPING = {
    PAS5  => \%SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R,
    PAS5R => \%SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R,
    UFS3  => \%SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R,
    UFS3R => \%SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R,

    PAS6  => \%SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e,
    PAS6e => \%SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e,
    UFS6  => \%SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e,
    UFS6e => \%SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e,

    PPS3  => \%SENSOR_TYPES_PPS3,
    PPS3e => \%SENSOR_TYPES_PPS3e_PTS1e,
    PTS1e => \%SENSOR_TYPES_PPS3e_PTS1e,
    PTS1  => \%SENSOR_TYPES_PPS3,

    PPS2 => \%SENSOR_TYPES_PPS2,

    PAS6s => \%SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f,
    PAS6f => \%SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f,
    UFS6s => \%SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f,
    UFS6f => \%SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f,
};

Readonly::Hash my %VALID_INIT2_LABELS => ( %SENSOR_TYPES_PAS5_UFS3_UFS3R_PAS5R, %SENSOR_TYPES_PAS6_PAS6e_UFS6_UFS6e, %SENSOR_TYPES_PPS3, %SENSOR_TYPES_PPS2, %SENSOR_TYPES_PPS3e_PTS1e, %SENSOR_TYPES_PAS6s_UFS6s_PAS6f_UFS6f );

# $INIT2_DATA_ATTRIBUTE_MAPPING href is used only for documentation purpose.

my $INIT2_DATA_ATTRIBUTE_MAPPING = {

    PROTOCOL_REVISION             => { 'CONFIGURE VALUE' => '<1.. 32>' },
    NUMBER_OF_DATA_BLOCKS         => { 'CONFIGURE VALUE' => '<1.. 128>' },
    MANUFACTURER                  => \%MANUFACTURER,
    SENSOR_BUS_MODE               => \%SENSOR_BUS_MODE,
    SENSOR_TYPE                   => \%SENSOR_TYPE,
    SATELLITE_SENSING_AXIS        => \%SATELLITE_SENSING_AXIS,
    ACCELERATION_AXIS             => \%ACCELERATION_AXIS,
    ACCELERATION_RANGE            => \%ACCELERATION_RANGE,
    PRESSURE_SENSOR_TYPE          => \%PRESSURE_SENSOR_TYPE,
    SENSOR_MODE                   => \%SENSOR_MODE,
    PSI5_MODE                     => \%PSI5_MODE,
    FILTER_TYPE_AND_SAMPLING_MODE => \%FILTER_TYPE_AND_SAMPLING_MODE,
    TRANSMISSION_MODE             => \%TRANSMISSION_MODE,
    ACCELERATION_AXIS_AND_FILTER  => \%ACCELERATION_AXIS_AND_FILTER,
    SAMPLE_TIME_AND_FILTER        => \%SAMPLE_TIME_AND_FILTER,
    MANUFACTURER_SERIES_CODE      => { 'CONFIGURE VALUE' => '<0x0.. 0xFFF>' },
    SENSOR_TYPE_PSI_CONFIGURATION => { 'CONFIGURE VALUE' => '<0x0 .. 0xF>' },
    SENSOR_CODE                   => \%SENSOR_CODE,
    PAS6e_GENERATION_BIT          => \%PAS6e_GENERATION_BIT,
    HOUSING_CODE                  => { 'CONFIGURE VALUE' => '<0x0.. 0x3F>' },
    SENSOR_CODE_CUSTOMER          => { 'CONFIGURE VALUE' => '<0x0.. 0xFFF>' },
    SGB_MANUFACTURING_DATE        => { 'CONFIGURE VALUE' => '<1-1-2000 .. 31-1-2031>' },
    LOT_NUMBER                    => { 'CONFIGURE VALUE' => '<0x0 .. 0xF>' },
    LINE_NUMBER                   => { 'CONFIGURE VALUE' => '<0x0 .. 0xF>' },
    BOSCH_SENSOR_CODE             => { 'CONFIGURE VALUE' => '<0x0 .. 0xFF>' },
    ELECTRONIC_HOUSE_CODING       => { 'CONFIGURE VALUE' => '<0x0 .. 0xFF>' },
    PAS6sf_GENERATION_BIT         => \%PAS6sf_GENERATION_BIT,

};

sub PSI5_print_docu {

    my $table_SensorTypes = S_TableCreate( ['Supported Sensor Types'] );
    foreach my $sensor_type ( sort keys %$INIT2_DATA_SENSOR_CONFIG_MAPPING ) {
        S_TableAddRow( $table_SensorTypes, [$sensor_type] );
    }

    my $table_SensorAttrib         = {};
    my $used_sensor_attributes     = {};
    my $attribute_sensor_collector = {};
    foreach my $sensor_type ( sort keys %$INIT2_DATA_SENSOR_CONFIG_MAPPING ) {
        $table_SensorAttrib->{$sensor_type} =
          S_TableCreate( ["Init2 Attributes of : $sensor_type"] );

        $used_sensor_attributes = $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type};
        foreach my $sensor_attribute ( sort keys %$used_sensor_attributes ) {
            S_TableAddRow( $table_SensorAttrib->{$sensor_type}, [$sensor_attribute] );
            $attribute_sensor_collector->{$sensor_attribute}{$sensor_type} = 1;
        }
    }

    my $table_SensorAttrib_value_labels = {};

    #    my $sensor_attributes_value_labels = {};
    my $sens_attribute_mapping = {};
    my $used_value;
    foreach my $sensor_attribute ( sort keys %$attribute_sensor_collector ) {
        $table_SensorAttrib_value_labels->{$sensor_attribute} =
          S_TableCreate( [ "Init2 Value Labels of : $sensor_attribute", 'Value' ] );

        $sens_attribute_mapping = $INIT2_DATA_ATTRIBUTE_MAPPING->{$sensor_attribute};
        unless ( defined $sens_attribute_mapping ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ "NO SPECIFIC VALUE LABELS PRE-DEFINED", "- - -" ] );
            next;
        }

        if ( $sensor_attribute eq 'SENSOR_CODE' ) {
            PrintSensorCode( $sensor_attribute, $sens_attribute_mapping, $table_SensorAttrib_value_labels );
        }
        elsif ( $sensor_attribute eq 'TRANSMISSION_MODE' ) {
            PrintTransmissionMode( $sensor_attribute, $sens_attribute_mapping, $table_SensorAttrib_value_labels );
        }
        else {
            foreach my $sensor_value_label ( sort keys %$sens_attribute_mapping ) {
                $used_value = $sens_attribute_mapping->{$sensor_value_label};
                $used_value = "NO VALUE SET" unless defined $used_value;
                S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            }
        }
    }

    my $html_title         = "LIFT_PSI5_access : special Docu of INIT2 Data ( sub PSI5_set_Init_Data )";
    my $html_template_code = <<EOT;
<html>
    <head>
        <title>$html_title</title>
    </head>
    <body>
        <H1 align='center'> $html_title </H1>
        <H2 align='center'> All supported sensor types for PSI5_set_Init_Data </H2>
        <TMPL_VAR NAME=TABLE_SUPPORTED_SENSOR_TYPES> 
        
        <H2 align='center'> All supported Init2 Data attributes for each sensor </H2>
        <TMPL_LOOP NAME=SENSOR_LOOP>
          <H3 align='center'> <TMPL_VAR NAME=SENSOR_HEADLINE> </H3>
          <TMPL_VAR NAME=SENSOR_TABLE>
        </TMPL_LOOP>
           
        <H2 align='center'> All supported Init2 Data attributes for each sensor </H2>
        <TMPL_LOOP NAME=ATTRIBUTE_LOOP>
          <H3 align='center'> <TMPL_VAR NAME=ATTRIBUTE_HEADLINE> </H3>
          <TMPL_VAR NAME=ATTRIBUTE_TABLE>
        </TMPL_LOOP>
           
    </body>
</html>    
EOT

    use HTML::Template;
    my $template = HTML::Template->new_scalar_ref( \$html_template_code, option => 'value' );

    #
    # Printing Table of supported sensor types
    #
    $template->param( TABLE_SUPPORTED_SENSOR_TYPES => S_Table2html( $table_SensorTypes, [], { 'align' => 'center', 'border' => 1 }, ) );
    S_TablePrint( CONSOLE | HTML, $table_SensorTypes, 'table_SensorTypes' );

    #
    # Printing Table of supported Init2 data of each sensor type
    #
    S_w2rep("Overview of Init2 Attributes ( per different Sensor Type )\n");
    my $content_for_SENSOR_LOOP_aref = [];
    foreach my $sensor_type ( sort keys %$INIT2_DATA_SENSOR_CONFIG_MAPPING ) {
        S_TablePrint( CONSOLE | HTML, $table_SensorAttrib->{$sensor_type}, 'table_SensorAttrib_' . $sensor_type, );
        push(
            @$content_for_SENSOR_LOOP_aref,
            {
                SENSOR_HEADLINE => "Sensor type $sensor_type -> supported Init2 data attributes",
                SENSOR_TABLE    => S_Table2html( $table_SensorAttrib->{$sensor_type}, [], { 'align' => 'center', 'border' => 1 } ),
            }
        );
    }
    $template->param( SENSOR_LOOP => $content_for_SENSOR_LOOP_aref );

    #
    # Printing Table of supported Value labels of each specific Init2 data attribute
    #
    S_w2rep("Overview of Init2 Values  ( of all different INIT2 data attributes ) \n");
    my $content_for_ATTRIBUTE_LOOP_aref = [];
    foreach my $sensor_attribute ( sort keys %$attribute_sensor_collector ) {
        S_TablePrint( CONSOLE | HTML, $table_SensorAttrib_value_labels->{$sensor_attribute}, 'table_SensorAttrib_ValueLabels_' . $sensor_attribute, );
        push(
            @$content_for_ATTRIBUTE_LOOP_aref,
            {
                ATTRIBUTE_HEADLINE => "Init2 Data Attribute $sensor_attribute -> supported Value labels",
                ATTRIBUTE_TABLE    => S_Table2html( $table_SensorAttrib_value_labels->{$sensor_attribute}, [], { 'align' => 'center', 'border' => 1 } ),
            }
        );
    }
    $template->param( ATTRIBUTE_LOOP => $content_for_ATTRIBUTE_LOOP_aref );

    my $fname = '..\html\modules\Functional_layer\LIFT_PSI5_access_INIT2_Data.html';
    open( DOCU_FILE, ">$fname" ) || die "Opening $fname";
    print DOCU_FILE $template->output;
    close(DOCU_FILE);

    return 1;
}

my $functionMapping_href = {
    'simulate' => {
        'Manitoo' => 'None'
    }
};

my @availableTestbenchFunctionGroups = qw{ simulate };

=head2 PSI5_init

    PSI5_init();
    
Initialises the devices configured for PSI5_Access in LIFT_Testbenches.pm
Initilaises the PSI5 sensor and line configuration from Mapping_PSI5_settings.pm
    - hashes 'PSI5_SENSORS_TYPES', 'PSI5_SENSORS_PROJECT', 'PSI5_LINES' should be
      configured in Mapping_PSI5_settings.pm.

B<Return Value:>

1 on Success and 'undef' on failure.

=cut

sub PSI5_init {

    #CALL FL_init()
    #IF initialisation successfull?
    my $return_href = FL_Init( 'PSI5_Access', $functionMapping_href, \@availableTestbenchFunctionGroups );

    unless ( keys %{$return_href} ) {
        S_set_error( "PSI5_init: simulation device configured not valid check test bench configuration for PSI5 devices", 109 );
        return;
    }

    #IF-YES-START
    #STEP Read mapping file content for the PSI5 sensors and lines

    my $psi5_sensor_type_href    = S_get_contents_of_hash( ['PSI5_SENSORS_TYPES'] );
    my $psi5_sensor_project_href = S_get_contents_of_hash( ['PSI5_SENSORS_PROJECT'] );
    my $psi5_lines_href          = S_get_contents_of_hash( ['PSI5_LINES'] );

    my $all_lines_init_href = Read_PSI5_line_settings( $psi5_sensor_type_href, $psi5_sensor_project_href, $psi5_lines_href );

    unless ($all_lines_init_href) {
        S_set_error( "PSI5_init: PSI5 config for PAS lines failed", 109 );
        return;
    }

    #
    # SET GLOBAL VAR  (required for PSI5_sensor_reinit)
    #
    undef $ALL_SENSORS_INIT_href;
    undef $INIT2_LABEL_href;
    undef $CYCLIC_DATA_href;
    undef $USER_DATA_href;
    $ALL_SENSORS_INIT_href = Read_PSI5_sensor_settings( $psi5_sensor_type_href, $psi5_sensor_project_href, $all_lines_init_href );

    unless ($ALL_SENSORS_INIT_href) {
        S_set_error( "PSI5_init: Configuration for PSI5 sensors failed!", 109 );
        return;
    }

    #CALL PSI5_sensor_init and PSI5_line_init
    #IF is sensor and lines initialisation successfull?
    #IF-NO-START
    #STEP initialisation error
    #STEP return undef
    #IF-NO-END

    S_w2log( 1, "\n Initialize PSI5 lines\n" );
    foreach my $line ( sort { $a <=> $b } keys %$all_lines_init_href ) {
        S_w2log( 2, "\n   Initialize line '$line'\n" );
        my $line_init_href = $all_lines_init_href->{$line};

        unless ( PSI5_line_init($line_init_href) ) {
            S_set_error( "PSI5_init: Loading line init configuration to manitoo failed", 109 );
            return;
        }
    }

    S_w2log( 1, "\n Initialize PSI5 sensors\n" );
    foreach my $sensor ( keys %$ALL_SENSORS_INIT_href ) {
        S_w2log( 2, "\n   Initialize sensor '$sensor'\n" );
        my $sensor_init_href = $ALL_SENSORS_INIT_href->{$sensor};

        unless ( PSI5_sensor_init($sensor_init_href) ) {
            S_set_error( "PSI5_init: Loading sensor init configuration to manitoo failed", 109 );
            return;
        }
        unless ( PSI5_switch_on_sensor($sensor) ) {
            S_set_error( "PSI5_init: switching on sensor '$sensor' line failed", 109 );
            return;
        }
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #IF-NO-START
    #STEP manitoo initialisation error
    #IF-NO-END

    S_w2log( 2, "\n Initialization done!\n" );

    #STEP END
    return 1;
}

=head2 PSI5_sensor_reinit

    PSI5_sensor_reinit ( $sensor_device_name )

Re-initialize PSI5 sensor with data from project defaults sensor configuration ( used PSI5_init ).
Function intended to be used at the end of testcases in order to reset original state of the sensor.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    PSI5_sensor_reinit ( 'UFSP' );

=cut

sub PSI5_sensor_reinit {

    my $sensor_device_name = shift;

    return unless S_checkFunctionArguments( 'PSI5_sensor_reinit ( $sensor_device_name )', ($sensor_device_name) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_sensor_reinit: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    S_w2log( 3, "\n   PSI5_sensor_reinit : Re-Initialize sensor '$sensor_device_name'\n" );

    my $sensor_init_href = $ALL_SENSORS_INIT_href->{$sensor_device_name};

    unless ( PSI5_sensor_init($sensor_init_href) ) {
        S_set_error(" Loading sensor init configuration to manitoo failed");
        return;
    }

    $SENSOR_INIT_DATA->{$sensor_device_name}{init1_data_href} = $ALL_SENSORS_INIT_href->{$sensor_device_name}{init1_data_href};
    $SENSOR_INIT_DATA->{$sensor_device_name}{init2_data_href} = $ALL_SENSORS_INIT_href->{$sensor_device_name}{init2_data_href};

    
    #Special handling for INIT2 data only to fill $INIT2_LABEL_href
    my $psi5_sensor_project_href = S_get_contents_of_hash( ['PSI5_SENSORS_PROJECT'] );
    my $sensor_type_str       = $psi5_sensor_project_href->{$sensor_device_name}{'TYPE'};
    my $init2_data_mix        = $psi5_sensor_project_href->{$sensor_device_name}{INIT2_DATA};
    my $init2_parameters_href = Fill_init2_data( $sensor_device_name, $init2_data_mix );
    return unless ($init2_parameters_href);
    my $init_2_data_href = Format_init2_label_data( $init2_parameters_href, $sensor_type_str );
    return unless ($init_2_data_href);

    $SENSOR_INIT_DATA->{$sensor_device_name}{init3_data_href} = $ALL_SENSORS_INIT_href->{$sensor_device_name}{init3_data_href};
    $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'cyclic_data_href'};
    $USER_DATA_href->{$sensor_device_name}{'user_data_href'} = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'user_data_href'} if ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name}{'user_data_href'} );

    return 1;
}

=head2 PSI5_set_sensor_Baudrate_kbps

    PSI5_set_sensor_Baudrate_kbps ( $sensor_device_name, $baudrate_kbps )

This function sets the baudrate for the PSI5 line the sensor is connected.

If a line is connected with 4 sensors, then the baudrate set is applicable for all the sensors.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $baudrate_kbps

Baudrate value in kbps. 

    Range: 1. 83, 125 and 189 (kbps).
           2. 'reset' -> The baudrate will be reset to value configured in the Mapping_PSI5_settings.pm

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    #set baudrate to 83kbps
    PSI5_set_sensor_Baudrate_kbps ( 'UFSP', 83 );

    #reset baudrate to default value configured in Mapping_PSI5_settings.pm
    PSI5_set_sensor_Baudrate_kbps ( 'UFSP', 'reset' );

=cut

sub PSI5_set_sensor_Baudrate_kbps {

    my @args = @_;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_sensor_Baudrate_kbps ( $sensor_device_name, $baudrate_kbps )', @args );

    my $sensor_device_name = shift @args;

    my $baudrate_kbps = shift @args;
    $baudrate_kbps =~ s/\s*//g;

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_sensor_Baudrate_kbps: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    if ( $baudrate_kbps !~ /^(83|125|189|reset)$/i ) {
        S_set_error( "PSI5_set_sensor_Baudrate_kbps: Baudrate '$baudrate_kbps' not supported! Valid Range: ( 83 | 125 | 189 | 'reset' )", 109 );
        return;
    }

    #IF-YES-START
    #STEP retrieve the line number mapped for the sensor
    #IF Is $baudrate_kbps eq 'reset'?
    #IF-NO-START
    #IF-NO-END
    #IF-YES-START
    #STEP retrieve the value configured from mapping file
    #IF-YES-END

    my $pas_line_num_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'pas_line_num_int'};

    if ( $baudrate_kbps =~ /^reset$/i ) {
        $baudrate_kbps = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'baudrate_kbps'};
    }

    #STEP prepare input for function PSI5_set_lines

    my $set_baudrate_href = { $pas_line_num_int => { 'baudrate_kbps' => $baudrate_kbps, } };

    #CALL PSI5_set_lines
    #IF Is return 1?
    #IF-NO-START
    #STEP Error setting baudrate failed, return undef
    #IF-NO-END

    unless ( PSI5_set_lines($set_baudrate_href) ) {
        S_set_error( "PSI5_set_sensor_Baudrate_kbps: Setting baudrate for sensor '$sensor_device_name' not successfull!, check configuration", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END

    S_w2log( 2, "PSI5_set_sensor_Baudrate_kbps: Baudrate '$baudrate_kbps' set for sensor '$sensor_device_name'\n" );
    return 1;
}

=head2 PSI5_set_Sensor_Defect

    PSI5_set_Sensor_Defect ( $sensor_device_name , $error_code_hex_str )

    Set PSI5 sensor to defect state which is represented by error data in Init3 Data and in Cyclic.

    A) In Init3 Data Sensor sends status 
    14 times 0x1F4 followed by  
    0x1F4 , <error_code> , 0x1F4 , <error_code> , 0x1F4 , <error_code> , ... till power down
 
    B) In Cyclic Data 0x1F4 , <error_code> ,0x1F4 , <error_code> , 0x1F4 , <error_code> , ... till power down 



B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $error_code_hex_str  ( optional ; default value : 0x217 / -489 dec )

    Error Code of sensor
    10bit signed value between 0x200 .. 0x21F  ( -512dec ... -481dec )
    to be given as HEX String !!

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    PSI5_set_Sensor_Defect ( 'UFSP' );          # Default Error Code 0x217 -> Lock-Bit Error ( for UFS6e )

    PSI5_set_Sensor_Defect ( 'PASFD' );         # Default Error Code 0x217 -> Lock-Bit Error ( for PAS6e )

    PSI5_set_Sensor_Defect ( 'PPSFD' );         # Default Error Code 0x217 -> External Capacitance Loss Error ( for PPS3 )


    PSI5_set_Sensor_Defect ( 'UFSP' , '0x213' );   # Error Code 0x213 ->  Undervoltage Error ( for UFS6e )

    PSI5_set_Sensor_Defect ( 'PASFD' , '0x213' );  # Error Code 0x213 ->  Undervoltage Error ( for PAS6e )

    PSI5_set_Sensor_Defect ( 'PPSFD' , '0x213' );  # Error Code 0x213 ->  OTP Error ( for PPS3 )

=cut

sub PSI5_set_Sensor_Defect {

    my $sensor_device_name = shift;
    my $error_code_hex_str = shift;

    return unless S_checkFunctionArguments( 'PSI5_set_Sensor_Defect ( $sensor_device_name [ , $error_code_hex_str ] )', ( $sensor_device_name, $error_code_hex_str ) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_Sensor_Defect: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    unless ($error_code_hex_str) {
        $error_code_hex_str = '0x217';
    }
    S_w2log( 2, " PSI5_set_Sensor_Defect : '$sensor_device_name'\n" );

    my $init3_data_href = {
        '1'  => { 'Data_value_hex' => '0x1F4' },
        '2'  => { 'Data_value_hex' => '0x1F4' },
        '3'  => { 'Data_value_hex' => '0x1F4' },
        '4'  => { 'Data_value_hex' => '0x1F4' },
        '5'  => { 'Data_value_hex' => '0x1F4' },
        '6'  => { 'Data_value_hex' => '0x1F4' },
        '7'  => { 'Data_value_hex' => '0x1F4' },
        '8'  => { 'Data_value_hex' => '0x1F4' },
        '9'  => { 'Data_value_hex' => '0x1F4' },
        '10' => { 'Data_value_hex' => '0x1F4' },
        '11' => { 'Data_value_hex' => '0x1F4' },
        '12' => { 'Data_value_hex' => '0x1F4' },
        '13' => { 'Data_value_hex' => '0x1F4' },
        '14' => { 'Data_value_hex' => '0x1F4' },

        '15' => { 'Data_value_hex' => '0x1F4' },
        '16' => { 'Data_value_hex' => $error_code_hex_str },
    };

    S_w2log( 3, " PSI5_set_Sensor_Defect : configure Ini3 Data of $sensor_device_name\n" );
    PSI5_set_Init_Data( $sensor_device_name, $INIT_TYPE_3, $init3_data_href ) || return;

    my $cyclicMsgs_href = {
        '1' => { 'Data_value_hex' => '0x1F4' },
        '2' => { 'Data_value_hex' => $error_code_hex_str, 'Reset_Loop_int' => 1 },
        'NUMBER_OF_USED_BYTES' => 2
    };

    S_w2log( 3, " PSI5_set_Sensor_Defect : configure Cyclic Messagses of $sensor_device_name \n" );
    PSI5_set_CyclicMsgs( $sensor_device_name, $cyclicMsgs_href ) || return;
    S_w2log( 2, " PSI5_set_Sensor_Defect : Sensor '$sensor_device_name' configured as DEFECT ( with Code $error_code_hex_str )\n" );

    return 1;
}

=head2 PSI5_set_lines

    PSI5_set_lines ( $set_line_href )

This function sets line specific parameters.

    $set_line_href = {
                        # key -> PAS line number ( Range: 1 - 12 )
                        1 => {
                               'QUIESCENT_CURR_MA' => 20,
                               'TRANSMIT_CURR_MA' => 35,
                               'AUTO_RESTART_TIME_US' => 36,
                               'BAUDRATE_KBPS' => 125,
                               'AUTO_RESTART_INT' =>  1,
                               'REBOOT_COUNTER_INT' => 1,
                               'PARITY_BIT_TS1_INT' => 1,
                               'PARITY_BIT_TS2_INT' => 1,
                               'PARITY_BIT_TS3_INT' => 1,
                               'PARITY_BIT_TS4_INT' => 1,
                               'TIMESLOT_TS1_US' => 45,
                               'TIMESLOT_TS2_US' =>  100,
                               'TIMESLOT_TS3_US' =>  120,
                               'TIMESLOT_TS4_US' =>  145
                             }
                     }

B<Arguments:>

=over

=item AUTO_RESTART_TIME_US

Auto restart time in micro seconds.

    Range: 20 - 999 ( us ).

=item BAUDRATE_KBPS

Three baudrate values are supported 83, 125 and 189kbps.

=item QUIESCENT_CURR_MA

quiescent current in mA.

    Range: 2 - 30 ( mA )

=item TRANSMIT_CURR_MA

Transmit current in mA.

    Range: 0 - 69 ( mA )

=item AUTO_RESTART_INT

    Range: 0 - 1
    
active = 1      not active = 0
For systems with asynchronous sensors it is necessary to activate the auto restart function.

=item REBOOT_COUNTER_INT

    Range: 0 - 1

Locked = 0  released = 1

To reset or hold the reboot counter set bit to 0. 
To record the reboot behavior set bit to 1.  

=item PARITY_BIT_TS1_INT

    Range: 0 - 1

active = 1  not active = 0

=item PARITY_BIT_TS2_INT

    Range: 0 - 1

active = 1  not active = 0

=item PARITY_BIT_TS3_INT

    Range: 0 - 1

active = 1  not active = 0

=item PARITY_BIT_TS4_INT

    Range: 0 - 1

active = 1  not active = 0

=item TIMESLOT_TS1_US

    Range: 20 - 999 ( us )

=item TIMESLOT_TS2_US

    Range: 20 - 999 ( us )

=item TIMESLOT_TS3_US

    Range: 20 - 999 ( us )

=item TIMESLOT_TS4_US

    Range: 20 - 999 ( us )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

# mininum range valid values ( 4 time slots )

    PSI5_set_lines ( {
        
                      1 => {
                               'QUIESCENT_CURR_MA' => 20,
                               'TRANSMIT_CURR_MA' => 0,
                               'AUTO_RESTART_TIME_US' => 20,
                               'BAUDRATE_KBPS' => 83,
                               'AUTO_RESTART_INT' =>  0,
                               'REBOOT_COUNTER_INT' => 0,
                               'PARITY_BIT_TS1_INT' => 0,
                               'PARITY_BIT_TS2_INT' => 0,
                               'PARITY_BIT_TS3_INT' => 0,
                               'PARITY_BIT_TS4_INT' => 0,
                               'TIMESLOT_TS1_US' => 20,
                               'TIMESLOT_TS2_US' => 20,
                               'TIMESLOT_TS3_US' => 20,
                               'TIMESLOT_TS4_US' => 20
                           }
                    }         
                   );

# maximum range valid values ( 4 time slots )

    PSI5_set_lines ( { 
                       12 => { 
                               'QUIESCENT_CURR_MA' => 30,
                               'TRANSMIT_CURR_MA' => 69,
                               'AUTO_RESTART_TIME_US' => 999,
                               'BAUDRATE_KBPS' => 189,
                               'AUTO_RESTART_INT' =>  1,
                               'REBOOT_COUNTER_INT' => 1,
                               'PARITY_BIT_TS1_INT' => 1,
                               'PARITY_BIT_TS2_INT' => 1,
                               'PARITY_BIT_TS3_INT' => 1,
                               'PARITY_BIT_TS4_INT' => 1,
                               'TIMESLOT_TS1_US' => 999,
                               'TIMESLOT_TS2_US' => 999,
                               'TIMESLOT_TS3_US' => 999,
                               'TIMESLOT_TS4_US' => 999
                            }
                     }
                  );

# Valid Ranges ( 2 time slots )

    PSI5_set_lines ( {
                        4 => {
                              'QUIESCENT_CURR_MA' => 30,
                              'TRANSMIT_CURR_MA' => 69,
                              'AUTO_RESTART_TIME_US' => 999,
                              'BAUDRATE_KBPS' => 189,
                              'AUTO_RESTART_INT' =>  1,
                              'REBOOT_COUNTER_INT' => 1,
                              'PARITY_BIT_TS1_INT' => 1,
                              'PARITY_BIT_TS2_INT' => 1,
                              'TIMESLOT_TS1_US' => 48,
                              'TIMESLOT_TS2_US' =>  192
                            }
                    }
                  );

=cut

sub PSI5_set_lines {

    my $set_line_href = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_lines ( $set_line_href )', ($set_line_href) );

    #IF-YES-START
    #LOOP-START Loop over all the lines settings configured
    #CALL MANITOO_PAS_init_Line for each line
    #LOOP-END if all lines are set

    foreach my $line ( sort { $a <=> $b } keys %$set_line_href ) {
        $set_line_href->{$line}{'pas_line_num_int'} = $line;
        map {
            my $value_hex = $set_line_href->{$line}{$_};
            my $key_name  = $_;
            delete $set_line_href->{$line}{$_};
            $key_name = lc $key_name;
            $set_line_href->{$line}{$key_name} = $value_hex;
        } keys %{ $set_line_href->{$line} };

        my $line_prop_href = $set_line_href->{$line};

        unless ( MANITOO_PAS_init_Line($line_prop_href) ) {
            S_set_error( "PSI5_set_lines: setting line configuration for line $line failed!", 109 );
            return;
        }
    }

    #IF-YES-END
    #STEP END

    S_w2log( 2, "PSI5_set_lines: PSI5 lines set successfully\n" );

    return 1;
}

=head2 PSI5_set_Init_Times

    PSI5_set_Init_Times ( $sensor_device_name, $init_time_href )

This function sets the init times for the sensors.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $init_time_href

Sets the init times for init 1, init 2, and init 3 in milli seconds.

    Time Range: 0.5 - 2147483647.5 ms (init 1)
    
                0.5 - 2147483647.5 ms (init 2)
                
                0.5 - 2147483647.5 ms (init 3)
    
    $init_time_href = {
                        1 => 60.5    # key = init 1, value = 60.5 milli seconds
                        2 => 128     # key = init 2, value = 128 milli seconds
                        3 => 8       # key = init 3, value = 8 milli seconds
                      }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. All init times configured.

    PSI5_set_Init_Times ( 'UFSD', {   1 => 60.5,
                                    2 => 128,
                                    3 => 8
                                }
                        );

2. Configure only for init 2

    PSI5_set_Init_Times ( 'UFSD', {
                                    2 => 128,
                                }
                        );

=cut

sub PSI5_set_Init_Times {

    my $sensor_device_name = shift;
    my $init_time_href     = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_Init_Times ( $sensor_device_name, $init_time_href )', ( $sensor_device_name, $init_time_href ) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_Init_Times: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    my $init1_time_ms = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'init1_time_ms'};
    my $init2_time_ms = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'init2_time_ms'};
    my $init3_time_ms = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'init3_time_ms'};

    my $pas_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    #IF-YES-START
    #STEP Load default init times
    #STEP Calculate offset based on the init times configured
    #LOOP-START Loop over all the time settings configured
    #STEP configure init times
    #LOOP-END if all time settings are read

    foreach my $init_times ( keys %$init_time_href ) {

        if ( $init_times !~ /[1-3]/ ) {
            S_set_error( "PSI5_set_Init_Times: The value '$init_times' configured for init type is out of range, valid range 1 .. 3! ", 109 );
            return;
        }
        if ( $init_times == 1 ) {
            $init1_time_ms = $init_time_href->{$init_times} if ( defined $init_time_href->{$init_times} );
        }
        if ( $init_times == 2 ) {
            $init2_time_ms = $init_time_href->{$init_times} if ( defined $init_time_href->{$init_times} );
        }
        if ( $init_times == $INIT_TYPE_3 ) {
            $init3_time_ms = $init_time_href->{$init_times} if ( defined $init_time_href->{$init_times} );
        }
    }

    #CALL MANITOO_PAS_sensor_set_InitTimes
    #IF is return 1?
    #IF-NO-START
    #STEP error setting init times
    #IF-NO-END
    unless ( MANITOO_PAS_sensor_set_InitTimes( $pas_module_int, $init1_time_ms, $init2_time_ms, $init3_time_ms ) ) {
        S_set_error( "PSI5_set_Init_Times: Setting init times failed!", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END
    S_w2log( 2, "PSI5_set_Init_Times: Init times set successfully \n" );
    return 1;
}

=head2 PSI5_set_Init_Data

    PSI5_set_Init_Data ( $sensor_device_name, $init_type_int, $init_data_href )

This function sets the init data for the init 1, init 2 and init 3 of the sensors.

B<For INIT2 Data to be used in PSI5_set_Init_Data see:>

=for html
<b><a href="LIFT_PSI5_access_INIT2_Data.html">LIFT_PSI5_access_INIT2_Data</a></b>

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $init_type_int

Type of init data to be set. ( init 1, init 2 or init 3 )

    Range: 1 - 3 ( int )

=item $init_data_href

Sets the data elements of the init data.

 Supports two formats: LABEL and BYTE

B<LABEL FORMAT:>

B<For INIT2 Data to be used in PSI5_set_Init_Data see:>

=for html
<b><a href="LIFT_PSI5_access_INIT2_Data.html">LIFT_PSI5_access_INIT2_Data</a></b>

B<For INIT3 Data labels:>

    1. 'INIT3_MESSAGE'

        Range:

             'SENSOR_OK'
             'SENSOR_DEFECT'
             'SENSOR_OK_LOCK_BIT_3_NOT_SET'
             'SENSOR_OK_LOCK_BIT_2_3_NOT_SET'

    2. 'ABSOLUTE_PRESSURE_VALUE'

        Range: 0 .. 4095 Po.lsb  

B<For INIT1 Data labels:>

    1. 'INIT1_MESSAGE'

        Range: 

             'NO_MESSAGES'
             'MANCHESTER_ERRORS'
             'PARITY_ERRORS'

B<BYTE FORMAT>

Size of the data array for each init type is listed below:

Init 1 ----> 32

Init 2 ----> 16

Init 3 ----> 16

    1. $init_data_href = {
                            # key 1 represents the data array element 1
                            1 => {
                                    'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
                                    'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
                                    'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
                                    'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
                                    'DATA_VALUE_HEX' => '0x000' - '0xFFF' #(only for INIT 1 and Init 3) 
                                                                         # For Init 2 Range is '0x00' - '0xFF'
                                 },
                         }

    2. $init_data_href = {
                            # if 'ALL' is configured, respective value will be set for all elements
                            'ALL' => {
                                        'DATA_VALUE_HEX' => '0x42',
                                     },
                         }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Possible types for configuring Init 2 data.


    # Label format 
    PSI5_set_Init_Data ( 'UFSD', 2, { 
                                       'SATELLITE_SENSING_AXIS' => 'SENSING_AXIS_Y' ,
                                    } 
                        );

    # Byte format
    PSI5_set_Init_Data ( 'UFSD', 2, { 
                                        2 => { 
                                                'MANCHESTER_FAULT_INT' => '1' 
                                             },   
                                    }  
                        );
    



2. Possible types for configuring Init 3 data.

    #Label format
    PSI5_set_Init_Data ( 'PPSFP', 3, { 
                                   'INIT3_MESSAGE' => 'SENSOR_OK',
                                   'ABSOLUTE_PRESSURE_VALUE' => '1000'
                                 },
                       );
    
    #Byte format
    PSI5_set_Init_Data ( 'UFSD', 3, { 
                                      1 => {
                                            'DATA_VALUE_HEX' => '0x1e7'
                                           },
    
                                      2 => {
                                             'MANCHESTER_FAULT_INT' => '1',
                                             'DATA_VALUE_HEX' => '0x1e7'
                                           },
                                    }
                      );

3. Possible types for configuring Init 1 data.

    #Label format
    PSI5_set_Init_Data ( 'PPSFP', 1, { 
                                        'INIT1_MESSAGE' => 'NO_MESSAGES',
                                     },
                       );
    
    #Byte format
    PSI5_set_Init_Data ( 'UFSD', 1, { 
                                      1 => {
                                            'DATA_VALUE_HEX' => '0x001'
                                           },
    
                                      2 => {
                                             'MANCHESTER_FAULT_INT' => '1',
                                             'DATA_VALUE_HEX' => '0x001'
                                           },
                                    }
                      );

3. Same data for all elements of init 3 data.

    #Byte format
    PSI5_set_Init_Data ( 'UFSD', 3, { 'ALL' => {
                                                'DATA_VALUE_HEX' => '0x1e7'
                                               }
                                    }
                       );

=cut

sub PSI5_set_Init_Data {

    my $sensor_device_name = shift;
    my $init_type_int      = shift;
    my $init_data_href     = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_Init_Data ( $sensor_device_name, $init_type_int, $init_data_href )', ( $sensor_device_name, $init_type_int, $init_data_href ) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_Init_Data: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    #IF-YES-START
    #STEP Load default init data
    #STEP Overwrite only selected data elements by calling Set_init_data function if the format is byte.
    #STEP Overwrwrite selected values by calling label format functions in case of label format.
    #CALL MANITOO_PAS_sensor_set_Init_<1|2|3>_Data
    #IF is return 1?
    #IF-NO-START
    #STEP Error setting init data, return undef
    #IF-NO-END

    my $sensor_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    if ( $init_type_int == 1 ) {

        my @hex_format   = grep { $_ =~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;
        my @label_format = grep { $_ !~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;

        if ( @hex_format and @label_format ) {
            S_set_error( "Use any one format for init 1 data, either bytes or label!", 109 );
            return;
        }

        if (@hex_format) {
            return unless ( $init_data_href = Set_init_data( $init_type_int, $init_data_href, $sensor_device_name, $INIT_1_ARRAY_SIZE ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;
        }
        if (@label_format) {
            return unless ( $init_data_href = Fill_init1_data( $sensor_device_name, $init_data_href ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;
        }

        MANITOO_PAS_sensor_set_Init_1_Data( $sensor_module_int, $init_data_href )
          || return;
    }
    elsif ( $init_type_int == 2 ) {
        my @hex_format   = grep { $_ =~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;
        my @label_format = grep { $_ !~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;

        if ( @hex_format and @label_format ) {
            S_set_error( "Use any one format for init 2 data, either bytes or label!", 109 );
            return;
        }

        if (@hex_format) {

            return unless ( $init_data_href = Set_init_data( $init_type_int, $init_data_href, $sensor_device_name, $INIT_2_ARRAY_SIZE ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;
        }

        if (@label_format) {

            return unless ( $init_data_href = Label_init2_data( $init_data_href, $sensor_device_name ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;

        }

        MANITOO_PAS_sensor_set_Init_2_Data( $sensor_module_int, $init_data_href )
          || return;
    }
    elsif ( $init_type_int == $INIT_TYPE_3 ) {
        my @hex_format   = grep { $_ =~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;
        my @label_format = grep { $_ !~ /(^[0-9]+$)|^ALL$/ } keys %$init_data_href;
        if ( @hex_format and @label_format ) {
            S_set_error( "Use any one format for init 3 data, either bytes or label!", 109 );
            return;
        }

        if (@hex_format) {
            return unless ( $init_data_href = Set_init_data( $init_type_int, $init_data_href, $sensor_device_name, $INIT_3_ARRAY_SIZE ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;
        }

        if (@label_format) {
            return unless ( $init_data_href = Fill_init3_data( $sensor_device_name, $init_data_href ) );
            $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_type_int . "_data_href" } = $init_data_href;
        }

        MANITOO_PAS_sensor_set_Init_3_Data( $sensor_module_int, $init_data_href )
          || return;
    }
    else {
        S_set_error("Init '$init_type_int' data not given correctly (can be : 1,2 or 3)!");
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP-END
    S_w2log( 2, "PSI5_set_Init_Data: Init Data $init_type_int set successfully \n" );
    return 1;
}

=head2 PSI5_set_CyclicMsgs

    PSI5_set_CyclicMsgs( $sensor_device_name, $cyclic_data_href )

This function sets the cyclic messages.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm

    Example: 'UFSD', 'UFSP' ...

=item $cyclic_data_href

B<Possible keys: (1 .. 256), 'ALL' and 'NUMBER_OF_USED_BYTES', 'ABSOLUTE_PRESSURE_VALUE' >

1. Byte numbers ranging from 1 .. 256.

    1 => {
            'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
            'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
            'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
            'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
            'DATA_VALUE_HEX' => '0x000' - '0xFFF'
         },

        :
        :
    
    256 => {
            'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
            'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
            'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
            'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
            'DATA_VALUE_HEX' => '0x000' - '0xFFF'
           },

2. Writing all bytes with same data.

    'ALL' => {
              'DATA_VALUE_HEX' => '0x001',
             },

B<NOTE: Either option (1) or (2) should be chosen, if both selected configured values>
 
B<for 'ALL' will be considered.>

3. Number of bytes to write can be chosen by configuring 'NUMBER_OF_USED_BYTES'

    'ALL' => {
              'DATA_VALUE_HEX' => '0x001',
             },

    'NUMBER_OF_USED_BYTES' => 68, # Range: 1 .. 256 ( int )

    Value '0x001' will be written for the 68 bytes instead of 256 bytes.

4. Absolute pressure value for the "presssure" sensors in Bosch mode.

    'ALL' => {
              'DATA_VALUE_HEX' => '0x001',
             },

    'ABSOLUTE_PRESSURE_VALUE' => 1000, # Range: 0 .. 4095 ( Po.lsb )
    
B<NOTE: When the number of used bytes is selected the absolute pressure will be written for the last four bytes
        e.g: when 'NUMBER_OF_USED_BYTES' = 68 and ABSOLUTE_PRESSURE_VALUE = 1000 will be converted to hex in byte 65, 66, 67 and 68>

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Writing to specific bytes.

    PSI5_set_CyclicMsgs( 'UFSP', {
                                   1 => {
                                            'DATA_VALUE_HEX' => '0x1e7'
                                        },
    
                                   2 => {
                                            'DATA_VALUE_HEX' => '0x1e7'
                                        },
                                 }
                       );

2. Same data for all bytes

    PSI5_set_CyclicMsgs( 'UFSD', { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' } } );

3. Same data for all the bytes with number of bytes to be used chosen as 68.

    PSI5_set_CyclicMsgs( 'UFSD', { 
                                   'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' },
                                   'NUMBER_OF_USED_BYTES' => 68,
                                 }
                       );

4. Absolute pressure value and number of used bytes chosen.

    PSI5_set_CyclicMsgs( 'PPSFP', { 
                                    'NUMBER_OF_USED_BYTES' => '68',
                                    'ABSOLUTE_PRESSURE_VALUE' => '1000'
                                  }
                       );

5. Same data for all elements with number of bytes fixed

   # no explicit configuration of 'DATA_VALUE_HEX'
   PSI5_set_CyclicMsgs( 'UFSD', { 'ALL' => '0x1e7', 'NUMBER_OF_USED_BYTES' => 256 } );

5. Writing only 'ABSOLUTE_PRESSURE_VALUE' => '1000' and 'NUMBER_OF_USED_BYTES' => '68'

   # Default DATA_VALUE_HEX will be 0 
   PSI5_set_CyclicMsgs( 'UFSD', { 'NUMBER_OF_USED_BYTES' => '68', 'ABSOLUTE_PRESSURE_VALUE' => '1000' } );

=cut

sub PSI5_set_CyclicMsgs {

    my $sensor_device_name = shift;
    my $cyclic_data_href   = shift;
    my $num_used_bytes;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_CyclicMsgs ( $sensor_device_name, $cyclic_data_href, [,$num_used_bytes] )', ( $sensor_device_name, $cyclic_data_href, $num_used_bytes ) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_CyclicMsgs: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    #IF-YES-START
    #CALL Fill_cyclic_messages to convert to byte format
    #CALL MANITOO_PAS_sensor_set_CyclicMsgs
    #IF is return 1?
    #IF-NO-START
    #STEP Error setting cyclic messages, return undef
    #IF-NO-END

    my $sensor_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    return unless ( $cyclic_data_href = Fill_cyclic_messages( $cyclic_data_href, $sensor_device_name ) );

    unless ( MANITOO_PAS_sensor_set_CyclicMsgs( $sensor_module_int, $cyclic_data_href ) ) {
        S_set_error( "PSI5_set_CyclicMsgs: Cyclic messages not set successfully!, check configuration", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END

    S_w2log( 2, "PSI5_set_CyclicMsgs: Cyclic messages set successfully \n" );
    return 1;
}

=head2 PSI5_set_UserMsgs

    PSI5_set_UserMsgs( $sensor_device_name, $user_data_href )

This function sets the user messages.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $user_data_href

1. Sets the data elements for the user data array (size 16).

    $user_data_href = {
                        1 => {
                                'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
                                'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
                                'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
                                'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
                                'DATA_VALUE_HEX' => '0x000' - '0xFFF'
                             },
                        :
                        :

                        16 => {
                                'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
                                'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
                                'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
                                'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
                                'DATA_VALUE_HEX' => '0x000' - '0xFFF'
                             },
                      }

2. Same data for all elements

    $user_data_href = { 'ALL' => { 'DATA_VALUE_HEX' => '0x001' } };

B<NOTE: Either option (1) or (2) should be chosen, if both selected, configured values>
 
B<for 'ALL' will be considered.>

3. Number of used bytes configured

    $user_data_href = {
                        'ALL' => {
                                    'DATA_VALUE_HEX' => '0x001' 
                                 },

                        'NUMBER_OF_USED_BYTES' => 16 #Range 1 .. 16 ( int )
                      }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Different data values.

    PSI5_set_UserMsgs(  'UFSD', 
                        {
                           1 => { 'DATA_VALUE_HEX' => '0x1e7' },
                           2 => { 'DATA_VALUE_HEX' => '0x1e8' },
                        }
                     );

2. Same data for all elements (each 10 bit data value )

    PSI5_set_UserMsgs( 'UFSD', { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7' } } );


3. Manchester fault in 5th Data of UserMsgs

    PSI5_set_UserMsgs(  'UFSD', { 5 => { 'MANCHESTER_FAULT_INT' => '1' } } );  #   set the fault
    PSI5_set_UserMsgs(  'UFSD', { 5 => { 'MANCHESTER_FAULT_INT' => '0' } } );  # reset the fault

4. Parity fault in 7th and 8th Data of UserMsgs

    PSI5_set_UserMsgs(  'UFSD', {                       #   set the fault
                                    7 => { 'PARITY_FAULT_INT' => '1' } , 
                                    9 => { 'PARITY_FAULT_INT' => '1' } ,
                                } 
                    ); 

    PSI5_set_UserMsgs(  'UFSD', {                       #   reset the fault
                                    7 => { 'PARITY_FAULT_INT' => '0' } , 
                                    9 => { 'PARITY_FAULT_INT' => '0' } ,
                                } 
                    );

5. Same data for elements with number of bytes to write fixed.

   PSI5_set_UserMsgs( 'UFSD', { 'ALL' => { 'DATA_VALUE_HEX' => '0x1e7'}, 'NUMBER_OF_USED_BYTES' => 6 });

6. Same data for all elements with no explicit configuration of 'DATA_VALUE_HEX'

   PSI5_set_UserMsgs( 'UFSD', { 'ALL' => '0x1e7', 'NUMBER_OF_USED_BYTES' => 6 } );

=cut

sub PSI5_set_UserMsgs {

    my $sensor_device_name = shift;
    my $user_data_href     = shift;
    my $userevent_int      = shift;    # used internally only during sensor re-init

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_set_UserMsgs ( $sensor_device_name, $user_data_href, [, $userevent_int] )', ( $sensor_device_name, $user_data_href, $userevent_int ) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_set_UserMsgs: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    return unless ( $user_data_href = Fill_user_messages( $user_data_href, $sensor_device_name ) );

    my $sensor_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    unless ( MANITOO_PAS_sensor_set_UserMsgs( $sensor_module_int, $user_data_href ) ) {
        S_set_error( "PSI5_set_UserMsgs: User messages not set successfully!, check configuration", 109 );
        return;
    }

    #IF-YES-START

    #CALL MANITOO_PAS_sensor_set_UserEvent
    #IF is return 1?
    #IF-NO-START
    #STEP Error setting user messages, return undef
    #IF-NO-END
    $userevent_int = 1 if ( not defined $userevent_int );    # user event will be set when the user messages is transmitted

    unless ( MANITOO_PAS_sensor_set_UserEvent( $sensor_module_int, $userevent_int ) ) {
        S_set_error( "PSI5_set_UserMsgs: User event not set successfully!, check configuration", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END

    S_w2log( 2, "PSI5_set_UserMsgs: User messages set successfully \n" );
    return 1;
}

=head2 PSI5_get_line_status

    my $line_status = PSI5_get_line_status ( $psi_line_num_int );

This function returns the PSI line status. Returns whether the Line is 'ON' or 'OFF'.

B<Arguments:>

=over

=item $psi_line_num_int

-PSI Line number in varying from 1-12
 
=back

B<Return Values:>

=over

=item $line_status

-Status of the PSI line(ON/OFF)

=back

B<Examples:>

    my $on_or_off_val = PSI5_get_line_status(1); #returns ON if the line '1' is on else returns 'OFF'

=cut

sub PSI5_get_line_status {
    my @args             = @_;
    my $psi_line_num_int = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_get_line_status ( $psi_line_num_int )', @args );

    if ( $psi_line_num_int < 1 or $psi_line_num_int > 12 ) {
        S_set_error( "PSI5_get_line_status: Invalid PSI line number '$psi_line_num_int'. Please select from 1-12!\n", 114 );
        return;
    }

    #IF-YES-START
    #Call the device leve fuction
    #CALL LIFT_manitoo::MANITOO_PAS_line_get_status_info
    my $line_status_data_aref = MANITOO_PAS_line_get_status_info($psi_line_num_int);

    #IF Is return dataref?
    #IF-NO-START
    unless ($line_status_data_aref) {

        #STEP Error function call not successful
        S_set_error( "PSI5_get_line_status: Failed to get the PSI line '$psi_line_num_int' status infomation\n", 23 );

        #STEP return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP Read the PSI line status data
    S_w2log( 2, "PSI5_get_line_status: Successfully read the PSI line '$psi_line_num_int' status information\n" );

    #STEP Process the data and return ON/OFF
    my $line_on_off = ( $line_status_data_aref->[5] eq '00' ) ? 'OFF' : 'ON';

    return $line_on_off;

    #IF-YES-END
    #IF-YES-END
    #STEP END

}

=head2 PSI5_get_reboot_counter

    my $reboot_counter = PSI5_get_reboot_counter ( $psi_line_num_int );

This function reads reboot counter value of PSI line

B<Arguments:>

=over

=item $psi_line_num_int

-PSI Line number in varying from 1-12
 
=back

B<Return Values:>

=over

=item $reboot_counter

-Reboot counter value of PSI line

=back

B<Examples:>

    my $reboot_counter = PSI5_get_reboot_counter(1);

=cut

sub PSI5_get_reboot_counter {
    my @args             = @_;
    my $psi_line_num_int = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_get_reboot_counter ( $psi_line_num_int )', @args );

    if ( $psi_line_num_int < 1 or $psi_line_num_int > 12 ) {
        S_set_error( "PSI5_get_reboot_counter: Invalid PSI line number '$psi_line_num_int'. Please select from 1-12!\n", 114 );
        return;
    }

    #IF-YES-START
    #Call the device leve fuction
    #CALL LIFT_manitoo::MANITOO_PAS_line_get_reboot_counter
    my $reboot_counter_dec = MANITOO_PAS_line_get_reboot_counter($psi_line_num_int);

    #IF Is return Reboot counter value?
    #IF-NO-START
    unless ( defined $reboot_counter_dec ) {

        #STEP Error function call not successful
        S_set_error( "PSI5_get_reboot_counter: Failed to get the PSI reboot counter value for line '$psi_line_num_int'\n", 23 );

        #STEP return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP Return Reboot counter value
    S_w2log( 2, "PSI5_get_reboot_counter: successfully got the PSI reboot counter value '$reboot_counter_dec' from line '$psi_line_num_int'\n" );
    return $reboot_counter_dec;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 PSI5_reset_reboot_counter

    my $reboot_counter = PSI5_reset_reboot_counter ( $psi_line_num );

This function resets the reboot counter value of PSI line

B<Arguments:>

=over

=item $psi_line_num

-PSI Line number in varying from 1-12

-If user passes 'ALL' as an input value, Reboot counter for all lines will be reset.
 
=back

B<Return Values:>

=over

=item $status

-Returns 1 on success, Undef on failure

=back

B<Examples:>

    my $status = PSI5_reset_reboot_counter(1);
    my $status = PSI5_reset_reboot_counter('ALL');

=cut

sub PSI5_reset_reboot_counter {
    my @args         = @_;
    my $psi_line_num = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_reset_reboot_counter ( $psi_line_num )', @args );

    if ( $psi_line_num != /^ALL$/i && ( $psi_line_num < 1 or $psi_line_num > 12 ) ) {
        S_set_error( "PSI5_reset_reboot_counter: Invalid PSI line number '$psi_line_num'. Please select from 1-12!\n", 114 );
        return;
    }

    #IF-YES-START
    #Call the device leve fuction for each line specified
    #CALL LIFT_manitoo::MANITOO_PAS_line_reset_reboot_counter
    my $configured_lines_hash = S_get_contents_of_hash( ['PSI5_LINES'] );
    my $psi_line_num_aref = ( $psi_line_num =~ /^ALL$/i ) ? [ ( sort keys %$configured_lines_hash ) ] : [$psi_line_num];
    my $final_status = 1;
    foreach my $psi_line_num_int (@$psi_line_num_aref) {
        my $status = MANITOO_PAS_line_reset_reboot_counter($psi_line_num_int);

        #IF Is return 1?
        #IF-NO-START
        unless ( $status == 1 ) {

            #STEP Error function call not successful
            S_set_error( "PSI5_reset_reboot_counter: Failed to reset the reboot counter value for PSI line '$psi_line_num_int'\n", 23 );

            #STEP return undef
            $final_status = undef;

            #IF-NO-END
        }
        else {
            #IF-YES-START
            #STEP Reset the PSI reboot counter value
            S_w2log( 2, "PSI5_reset_reboot_counter: Successfully reset the reboot counter value for the PSI line '$psi_line_num_int'\n" );

        }
    }

    #STEP Return status
    return $final_status;

    #IF-YES-END
    #IF-YES-END
    #STEP END

}

=head2 PSI5_switch_off_sensor

    PSI5_switch_off_sensor ( $sensor_device_name )

This function switches off PSI5 sensor.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    PSI5_switch_off_sensor ( 'UFSP' );

=cut

sub PSI5_switch_off_sensor {

    my $sensor_device_name = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_switch_off_sensor ( $sensor_device_name )', ($sensor_device_name) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_switch_off_sensor: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    #IF-YES-START
    #CALL MANITOO_PAS_sensor_switch_off
    #IF is return 1?
    #IF-NO-START
    #STEP Error switching off line, return undef
    #IF-NO-END

    my $pas_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    unless ( MANITOO_PAS_sensor_switch_off($pas_module_int) ) {
        S_set_error( "PSI5_switch_off_sensor: switching off sensor '$sensor_device_name' connected to PAS module '$pas_module_int' not successfull!, check configuration", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END

    S_w2log( 2, "PSI5_switch_off_sensor: switching off sensor '$sensor_device_name' connected to PAS module '$pas_module_int' successfull!   \n" );
    return 1;
}

=head2 PSI5_switch_on_sensor

    PSI5_switch_on_sensor ( $sensor_device_name )

This function switches on PSI5 sensor.

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    PSI5_switch_on_sensor ( 'UFSP' )

=cut

sub PSI5_switch_on_sensor {

    my $sensor_device_name = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_switch_on_sensor ( $sensor_device_name )', ($sensor_device_name) );

    unless ( exists $ALL_SENSORS_INIT_href->{$sensor_device_name} ) {
        S_set_error( "PSI5_switch_on_sensor: Sensor device '$sensor_device_name' not configured in mapping file", 109 );
        return;
    }

    #IF-YES-START
    #CALL MANITOO_PAS_sensor_switch_on
    #IF is return 1?
    #IF-NO-START
    #STEP Error switching on line, return undef
    #IF-NO-END

    my $pas_module_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'sensor_module'};

    unless ( MANITOO_PAS_sensor_switch_on($pas_module_int) ) {
        S_set_error( "PSI5_switch_on_sensor: switching on sensor '$sensor_device_name' connected to sensor module '$pas_module_int' not successfull!, check configuration", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END
    S_w2log( 2, "PSI5_switch_on_sensor: switching on sensor '$sensor_device_name' connected to sensor module '$pas_module_int' successfull   \n" );
    return 1;
}

=head2 PSI5_Exit

    PSI5_Exit()

    to be implemented

=cut

sub PSI5_exit {

    return 1;
}

=head1 Non Exported functions

=head2 PSI5_line_init

    PSI5_line_init ($line_init_href)

B<NON EXPORTED FUNCTION: CALLED BY PSI5_init>

This function initialises the PAS line.

    $line_init_href = {
                           'pas_line_num_int' => 2,
                           'quiescent_curr_mA' => 20,
                           'transmit_curr_mA' => 35,
                           'auto_restart_time_us' => 36,     #   optional
                           'baudrate_kbps' => 125,
                           'auto_restart_int' =>  1,         #   optional
                           'reboot_counter_int' => 1,        #   optional
                           'parity_bit_ts1_int' => 1,        #   optional
                           'parity_bit_ts2_int' => 1,        #   optional
                           'parity_bit_ts3_int' => 1,        #   optional
                           'parity_bit_ts4_int' => 1,        #   optional
                           'timeslot_ts1_us' => 48,
                           'timeslot_ts2_us' => 192,
                           'timeslot_ts3_us' => 343,
                           'timeslot_ts4_us' => 383
                      }

B<Arguments:>

=over

=item pas_line_num_int

Line number of the PAS.

    Range: 1 - 12 ( int ).

=item auto_restart_time_us

Auto restart time in micro seconds.

    Range: 20 - 999 ( us ).

=item baudrate_kbps

Three baudrate values are supported 83, 125 and 189kbps.

=item quiescent_curr_mA

quiescent current in mA.

    Range: 2 - 30 ( mA )

=item transmit_curr_mA

Transmit current in mA.

    Range: 0 - 69 ( mA )

=item auto_restart_int

    Range: 0 - 1
    
active = 1      not active = 0
For systems with asynchronous sensors it is necessary to activate the auto restart function.

=item reboot_counter_int

    Range: 0 - 1

Locked = 0  released = 1

To reset or hold the reboot counter set bit to 0. 
To record the reboot behavior set bit to 1.  

=item parity_bit_ts1_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts2_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts3_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts4_int

    Range: 0 - 1

active = 1  not active = 0

=item timeslot_ts1_us

    Range: 20 - 999 ( us )

=item timeslot_ts2_us

    Range: 20 - 999 ( us )

=item timeslot_ts3_us

    Range: 20 - 999 ( us )

=item timeslot_ts4_us

    Range: 20 - 999 ( us )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

mininum range valid values ( 4 time slots )

    PSI5_line_init ( { 
                       'pas_line_num_int' => 1,
                       'quiescent_curr_mA' => 20,
                       'transmit_curr_mA' => 0,
                       'auto_restart_time_us' => 20,
                       'baudrate_kbps' => 83,
                       'auto_restart_int' =>  0,
                       'reboot_counter_int' => 0,
                       'parity_bit_ts1_int' => 0,
                       'parity_bit_ts2_int' => 0,
                       'parity_bit_ts3_int' => 0,
                       'parity_bit_ts4_int' => 0,
                       'timeslot_ts1_us' => 48,
                       'timeslot_ts2_us' => 192,
                       'timeslot_ts3_us' => 343,
                       'timeslot_ts4_us' => 383
                     }
                   );

maximum range valid values ( 4 time slots )

    PSI5_line_init ( { 
                       'pas_line_num_int' => 12,
                       'quiescent_curr_mA' => 30,
                       'transmit_curr_mA' => 69,
                       'auto_restart_time_us' => 999,
                       'baudrate_kbps' => 189,
                       'auto_restart_int' =>  1,
                       'reboot_counter_int' => 1,
                       'parity_bit_ts1_int' => 1,
                       'parity_bit_ts2_int' => 1,
                       'parity_bit_ts3_int' => 1,
                       'parity_bit_ts4_int' => 1,
                       'timeslot_ts1_us' => 48,
                       'timeslot_ts2_us' => 192,
                       'timeslot_ts3_us' => 343,
                       'timeslot_ts4_us' => 383
                    }
                 );

Valid Ranges ( 2 time slots )

    PSI5_line_init ( {
                      'pas_line_num_int' => 12,
                      'quiescent_curr_mA' => 30,
                      'transmit_curr_mA' => 69,
                      'auto_restart_time_us' => 999,
                      'baudrate_kbps' => 189,
                      'auto_restart_int' =>  1,
                      'reboot_counter_int' => 1,
                      'parity_bit_ts1_int' => 1,
                      'parity_bit_ts2_int' => 1,
                      'timeslot_ts1_us' => 48,
                      'timeslot_ts2_us' =>  192
                    }
                  );

=cut

sub PSI5_line_init {

    my $line_init_href = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_line_init ( $line_init_href )', ($line_init_href) );

    #IF-YES-START
    #CALL MANITOO_PAS_init_Line
    #IF is return 1?
    #IF-NO-START
    #STEP Error initialising lines, return undef
    #IF-NO-END

    unless ( MANITOO_PAS_init_Line($line_init_href) ) {
        S_set_error( "PSI5_line_init: Loading line init configuration to manitoo failed", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END
    return 1;
}

=head2 PSI5_sensor_init

    PSI5_sensor_init($sensor_init_href)

B<NON EXPORTED FUNCTION: called by PSI5_init and PSI5_sensor_reinit>

This function initialises the PAS sensors.

    $sensor_init_href =  { 
                            'pas_line_num_int' => 1, 
                            'time_slot_int' => 1,
                            'init1_time_ms' => 60.5,
                            'init2_time_ms' => 128,
                            'init3_time_ms' => 8,
                            'init1_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'init2_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'init3_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                }, 
                            'cyclic_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'user_data_href' =>  {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                } 
                        }
    
B<Arguments:>

=over

=item pas_line_num_int ( $pas_line_num_int )

Line number of the PAS.

    Range: 1 - 12 ( int ).

=item timeslot_int ( $timeslot_int )

4 time slots supported.
 
    Range: 1 - 4 ( int )

=item init1_time_ms ( $init1_time_ms )

Init 1 time in ms.

    Range: 0.5 - 2147483647.5

=item init2_time_ms ( $init2_time_ms )

Init 2 time in ms.

    Range: 0.5 - 2147483647.5

=item init3_time_ms ( $init3_time_ms )

Init 3 time in ms.

    Range: 0.5 - 2147483647.5
    
=item init1_data_href ( $init1_data_href )

Init 1 data array has eight elements.

The keys 1 .. 32 represents the elements.

    Range: $init1_data_href = {
                                1 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                                :
                                :
                                :
                                
                                32 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on' (optional)
                                        'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                        'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                              }

=item init2_data_href ( $init2_data_href )

Init 2 data array has 384 elements.

    Range: $init2_data_href = {
                                1 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0x3FF' 
                                    }
                                :
                                :
                                :
                                384 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0x3FF'
                                      }
                            }

=item init3_data_href ( $init3_data_href )

Init 3 data array has 96 elements.

    Range: $init3_data_href = {
                                1 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0x3FF'
                                     }
                                :
                                96 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0x3FF'
                                     }
                             }

=item cyclic_data_href ($cyclic_data_href)

Cyclic messages array has 512 values.

    Range: $cyclic_data_href = {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0xFFF'
                                        }
                                        
                                    :
                                    512 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0xFFF'
                                         }
                              }

=item user_data_href ($user_data_href) 

user messages array has 1024 values.

    Range: $user_data_href =>  {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'
                                         }
                                    :
                                    1024 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'
                                          }
                             }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    PSI5_sensor_init ( { 
                                'pas_line_num_int' => 1, 
                                'time_slot_int' => 1,
                                'init1_time_ms' => 60.5,
                                'init2_time_ms' => 128,
                                'init3_time_ms' => 8,
                                'init1_data_href' => {
                                                        1 => {
                                                                    'Data_value_hex' => '0x000'
                                                             }
                                                        
                                                    },
                                'init2_data_href' => {
                                                        1 => {
                                                                    'Data_value_hex' => '0x000'
                                                             }
                                                        
                                                    },
                                'init3_data_href' => {
                                                        1 => {
                                                                    'Data_value_hex' => '0x000'
                                                             }
                                                        
                                                    },
                                'cyclic_data_href' => {
                                                        1 => {
                                                                    'Data_value_hex' => '0x000'
                                                             }
                                                        
                                                    },
                                'user_data_href' =>  {
                                                        1 => {
                                                                    'Data_value_hex' => '0x000'
                                                             }
                                                        
                                                    }
                   }
               );

=cut

sub PSI5_sensor_init {

    my $sensor_init_href = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return unless S_checkFunctionArguments( 'PSI5_sensor_init ( $sensor_init_href )', ($sensor_init_href) );

    #IF-YES-START
    #CALL MANITOO_PAS_init_Sensor
    #IF is return 1?
    #IF-NO-START
    #STEP Error initialising sensor, return undef
    #IF-NO-END
    unless ( MANITOO_PAS_init_Sensor($sensor_init_href) ) {
        S_set_error( "PSI5_sensor_init: Loading sensor init configuration to manitoo failed", 109 );
        return;
    }

    #IF-YES-START
    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END
    return 1;
}

=head2 Read_PSI5_sensor_settings

B<NON EXPORTED FUNCTION>

This function reads the contents of PSI5 settings for sensor configuration in Mapping_PSI5_settings.pm

=cut

sub Read_PSI5_sensor_settings {

    my $psi5_sensor_type_href    = shift;
    my $psi5_sensor_project_href = shift;
    my $all_lines_init_href      = shift;

    my $sensor_init_href = {};

    return unless S_checkFunctionArguments( 'Read_PSI5_sensor_settings ( $psi5_sensor_type_href, $psi5_sensor_project_href, $all_lines_init_href )', ( $psi5_sensor_type_href, $psi5_sensor_project_href, $all_lines_init_href ) );

    unless ( Validate_sensor_config($psi5_sensor_project_href) ) {
        return;
    }

    S_w2log( 3, " Read_PSI5_sensor_settings: Sensor mapping details:\n" );

    my $sensor_module = 1;    # initialise first sensor module to 1

    #collect sensor specific data
    foreach my $sensor_device_name ( keys %$psi5_sensor_project_href ) {

        my $pas_line_int = $psi5_sensor_project_href->{$sensor_device_name}{'LINE'};    # Pas line number

        my $time_slot_str = lc $psi5_sensor_project_href->{$sensor_device_name}{'TIMESLOT'};

        my $time_slot_int;

        my $sensor_type_str = $psi5_sensor_project_href->{$sensor_device_name}{'TYPE'};    #Sensor type

        # max number of sensors supported 16
        if ( $sensor_module > 16 ) {
            S_set_error( "Read_PSI5_sensor_settings: Configuration of sensors exceeds maximum limit of 16!", 109 );
            return;
        }

        if ( defined $all_lines_init_href->{$pas_line_int}{$time_slot_str} ) {
            if ( $time_slot_str =~ /^TIMESLOT_TS(\d)_US$/i ) {
                $time_slot_int = $1;
            }
            else {
                S_set_error( "Time slot '$time_slot_str' configured for sensor type '$sensor_type_str' invalid!", 109 );
                return;
            }
        }
        else {
            S_set_error( "Time slot '$time_slot_str' configured for sensor type '$sensor_type_str' not defined in line $pas_line_int!", 109 );
            return;
        }

        S_w2log( 3, " Read_PSI5_sensor_settings: '$sensor_device_name' ->  Line: $pas_line_int, Timeslot:  $time_slot_int\n" );

        my $init1_time_ms = $psi5_sensor_type_href->{$sensor_type_str}{'INIT1_TIME_MS'};
        my $init2_time_ms = $psi5_sensor_type_href->{$sensor_type_str}{'INIT2_TIME_MS'};
        my $init3_time_ms = $psi5_sensor_type_href->{$sensor_type_str}{'INIT3_TIME_MS'};

        unless ($init1_time_ms) {
            S_set_error("Missing 'INIT1_TIME_MS'of sensor type '$sensor_type_str' used from sensor '$sensor_device_name' ");
            return;
        }
        unless ($init2_time_ms) {
            S_set_error("Missing 'INIT2_TIME_MS'of sensor type '$sensor_type_str' used from sensor '$sensor_device_name' ");
            return;
        }
        unless ($init3_time_ms) {
            S_set_error("Missing 'INIT3_TIME_MS'of sensor type '$sensor_type_str' used from sensor '$sensor_device_name' ");
            return;
        }

        my $init_1_data_href;
        if ( exists $psi5_sensor_project_href->{$sensor_device_name}{'INIT1_DATA'} ) {
            my $configured_init_data_href = $psi5_sensor_project_href->{$sensor_device_name}{'INIT1_DATA'};
            return unless ( $init_1_data_href = Convert_init_1_and_3_data( $configured_init_data_href, $sensor_device_name, 1 ) );
        }

        my $init2_config_href = $psi5_sensor_project_href->{$sensor_device_name};

        my $init2_parameters_href = Fill_init2_data( $sensor_device_name, $init2_config_href->{INIT2_DATA} );
        return unless ($init2_parameters_href);
        my $init_2_data_href = Format_init2_label_data( $init2_parameters_href, $sensor_type_str );
        return unless ($init_2_data_href);

        my $init_3_data_href;

        if ( exists $psi5_sensor_project_href->{$sensor_device_name}{'INIT3_DATA'} ) {
            my $configured_init_data_href = $psi5_sensor_project_href->{$sensor_device_name}{'INIT3_DATA'};
            return unless ( $init_3_data_href = Convert_init_1_and_3_data( $configured_init_data_href, $sensor_device_name, $INIT_TYPE_3 ) );
        }

        my ( $cyclic_data_href, $user_data_href );
        if ( exists $psi5_sensor_project_href->{$sensor_device_name}{'CYCLIC_MESSAGES'} ) {
            return unless ( $cyclic_data_href = Fill_cyclic_messages( $psi5_sensor_project_href->{$sensor_device_name}{'CYCLIC_MESSAGES'}, $sensor_device_name ) );
        }

        if ( exists $psi5_sensor_project_href->{$sensor_device_name}{'USER_MESSAGES'} ) {
            return unless ( $user_data_href = Fill_user_messages( $psi5_sensor_project_href->{$sensor_device_name}{'USER_MESSAGES'}, $sensor_device_name ) );
        }

        # increment sensor module
        $sensor_init_href->{$sensor_device_name}{'sensor_module'}    = $sensor_module++;
        $sensor_init_href->{$sensor_device_name}{'pas_line_num_int'} = $pas_line_int;
        $sensor_init_href->{$sensor_device_name}{'time_slot_int'}    = $time_slot_int;
        $sensor_init_href->{$sensor_device_name}{'init1_time_ms'}    = $init1_time_ms;
        $sensor_init_href->{$sensor_device_name}{'init2_time_ms'}    = $init2_time_ms;
        $sensor_init_href->{$sensor_device_name}{'init3_time_ms'}    = $init3_time_ms;
        $sensor_init_href->{$sensor_device_name}{'init1_data_href'}  = $init_1_data_href if ( defined $init_1_data_href );
        $sensor_init_href->{$sensor_device_name}{'init2_data_href'}  = $init_2_data_href;
        $sensor_init_href->{$sensor_device_name}{'init3_data_href'}  = $init_3_data_href;
        $sensor_init_href->{$sensor_device_name}{'cyclic_data_href'} = $cyclic_data_href if ( defined $cyclic_data_href );
        $sensor_init_href->{$sensor_device_name}{'user_data_href'}   = $user_data_href if ( defined $user_data_href );
        $sensor_init_href->{$sensor_device_name}{'baudrate_kbps'}    = $all_lines_init_href->{$pas_line_int}{'baudrate_kbps'};
    }

    return $sensor_init_href;
}

=head2 Convert_init_1_and_3_data

    Convert_init_1_and_3_data ( $configured_init_data, $sensor_device_name, $init_data_type )

B<NON EXPORTED FUNCTION>

This function prepares the init1 and int 3 data in the bytes format as required.

B<Arguments:>

=over

=item $configured_init_data

Configured init 1 or init 3 data

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=item $init_data_type

Type of Init data ( 1 or 3 )

=back

B<Return Value:>

returns success: $init_data_href.

return failure: undef.

=cut

sub Convert_init_1_and_3_data {

    my $configured_init_data_href = shift;
    my $sensor_device_name        = shift;
    my $init_data_type            = shift;
    my $init_data_href            = {};

    return unless S_checkFunctionArguments( 'Convert_init_1_and_3_data ( $configured_init_data_href, $sensor_device_name, $init_data_type )', ( $configured_init_data_href, $sensor_device_name, $init_data_type ) );

    my @hex_format   = grep { $_ =~ /(^[0-9]+$)|^ALL$/ } keys %$configured_init_data_href;
    my @label_format = grep { $_ !~ /(^[0-9]+$)|^ALL$/ } keys %$configured_init_data_href;
    if ( @hex_format and @label_format ) {
        my $init_type_name = 'INIT' . $init_data_type . '_DATA';
        S_set_error( "Use any one format of input for '$init_type_name' for sensor '$sensor_device_name', either bytes or label!", 109 );
        return;
    }
    my $init_array_size;
    if ( $init_data_type == 1 ) {
        $init_array_size = $INIT_1_ARRAY_SIZE;
    }
    elsif ( $init_data_type == $INIT_TYPE_3 ) {
        $init_array_size = $INIT_3_ARRAY_SIZE;
    }

    if (@hex_format) {
        return unless ( $init_data_href = Set_init_data( $init_data_type, $configured_init_data_href, $sensor_device_name, $init_array_size ) );
    }
    if (@label_format) {
        if ( $init_data_type == 1 ) {
            return unless ( $init_data_href = Fill_init1_data( $sensor_device_name, $configured_init_data_href ) );
        }
        elsif ( $init_data_type == $INIT_TYPE_3 ) {
            return unless ( $init_data_href = Fill_init3_data( $sensor_device_name, $configured_init_data_href ) );
        }
    }
    return $init_data_href;
}

=head2 Read_PSI5_line_settings

B<NON EXPORTED FUNCTION>

This function reads the contents of PSI5 settings for line configuration in Mapping_PSI5_settings.pm

=cut

sub Read_PSI5_line_settings {

    my $psi5_sensor_type_href    = shift;
    my $psi5_sensor_project_href = shift;
    my $psi5_lines_href          = shift;

    return unless S_checkFunctionArguments( 'Read_PSI5_line_settings ( $psi5_sensor_type_href, $psi5_sensor_project_href, $psi5_lines_href )', ( $psi5_sensor_type_href, $psi5_sensor_project_href, $psi5_lines_href ) );

    my $line_init_href = {};

    S_w2log( 4, " Read_PSI5_line_settings: reading 'PSI5_LINES_DEFAULTS' \n" );
    my $psi5_lines_default_href = S_get_contents_of_hash( ['PSI5_LINES_DEFAULTS'] );

    my @lines = sort { $a <=> $b } keys %$psi5_lines_href;

    my @line_attributes;

    # fill default attributes for all lines
    if ( defined $psi5_lines_default_href ) {
        @line_attributes = keys %{$psi5_lines_default_href};

        foreach my $line_num (@lines) {
            if ( $psi5_lines_href->{$line_num}{'USE_DEFAULTS'} eq 'PSI5_LINES_DEFAULTS' ) {
                map {
                    my $attribute = lc $_;

                    $line_init_href->{$line_num}{$attribute} = $psi5_lines_default_href->{$_};
                } @line_attributes;
            }
        }

    }

    S_w2log( 4, " Read_PSI5_line_settings: collect line specific data from 'PSI5_LINES' \n" );

    #collect line specific data
    foreach my $line_num ( sort { $a <=> $b } keys %$psi5_lines_href ) {

        S_w2log( 4, " Read_PSI5_line_settings: line '$line_num' \n" );

        map {
            unless ( $_ eq 'USE_DEFAULTS' ) {
                my $value_hex = $psi5_lines_href->{$line_num}{$_};
                my $key_name  = $_;
                delete $psi5_lines_href->{$line_num}{$_};
                $key_name = lc $key_name;
                $psi5_lines_href->{$line_num}{$key_name} = $value_hex;
            }

        } keys %{ $psi5_lines_href->{$line_num} };

        $line_init_href->{$line_num}{'pas_line_num_int'}     = $line_num;
        $line_init_href->{$line_num}{'auto_restart_time_us'} = $psi5_lines_href->{$line_num}{'auto_restart_time_us'} if ( exists $psi5_lines_href->{$line_num}{'auto_restart_time_us'} );
        $line_init_href->{$line_num}{'baudrate_kbps'}        = $psi5_lines_href->{$line_num}{'baudrate_kbps'} if ( exists $psi5_lines_href->{$line_num}{'baudrate_kbps'} );
        $line_init_href->{$line_num}{'auto_restart_int'}     = $psi5_lines_href->{$line_num}{'auto_restart_int'} if ( exists $psi5_lines_href->{$line_num}{'auto_restart_int'} );
        $line_init_href->{$line_num}{'reboot_counter_int'}   = $psi5_lines_href->{$line_num}{'reboot_counter_int'} if ( exists $psi5_lines_href->{$line_num}{'reboot_counter_int'} );
        $line_init_href->{$line_num}{'parity_bit_ts1_int'}   = $psi5_lines_href->{$line_num}{'parity_bit_ts1_int'} if ( exists $psi5_lines_href->{$line_num}{'parity_bit_ts1_int'} );
        $line_init_href->{$line_num}{'parity_bit_ts2_int'}   = $psi5_lines_href->{$line_num}{'parity_bit_ts2_int'} if ( exists $psi5_lines_href->{$line_num}{'parity_bit_ts2_int'} );
        $line_init_href->{$line_num}{'parity_bit_ts3_int'}   = $psi5_lines_href->{$line_num}{'parity_bit_ts3_int'} if ( exists $psi5_lines_href->{$line_num}{'parity_bit_ts3_int'} );
        $line_init_href->{$line_num}{'parity_bit_ts4_int'}   = $psi5_lines_href->{$line_num}{'parity_bit_ts4_int'} if ( exists $psi5_lines_href->{$line_num}{'parity_bit_ts4_int'} );
        $line_init_href->{$line_num}{'timeslot_ts1_us'}      = $psi5_lines_href->{$line_num}{'timeslot_ts1_us'} if ( exists $psi5_lines_href->{$line_num}{'timeslot_ts1_us'} );
        $line_init_href->{$line_num}{'timeslot_ts2_us'}      = $psi5_lines_href->{$line_num}{'timeslot_ts2_us'} if ( exists $psi5_lines_href->{$line_num}{'timeslot_ts2_us'} );
        $line_init_href->{$line_num}{'timeslot_ts3_us'}      = $psi5_lines_href->{$line_num}{'timeslot_ts3_us'} if ( exists $psi5_lines_href->{$line_num}{'timeslot_ts3_us'} );
        $line_init_href->{$line_num}{'timeslot_ts4_us'}      = $psi5_lines_href->{$line_num}{'timeslot_ts4_us'} if ( exists $psi5_lines_href->{$line_num}{'timeslot_ts4_us'} );

        unless ( defined $line_init_href->{$line_num}{'baudrate_kbps'} ) {
            S_set_error( "Missing 'Baudrate_kbps' for line $line_num ", 109 );
            return;
        }

        # add quiescent current for each sensor if more than one sensor is connected to the same line
        S_w2log( 4, " Read_PSI5_line_settings: add quiescent current for each sensor if more than one sensor is connected to the same line \n" );
        $line_init_href->{$line_num}{'quiescent_curr_ma'} = 0;
        foreach my $sensor ( keys %$psi5_sensor_project_href ) {

            S_w2log( 4, " Read_PSI5_line_settings: sensor '$sensor' on line '$line_num' \n" );
            my $sensor_type = $psi5_sensor_project_href->{$sensor}{'TYPE'};
            unless ( defined $psi5_sensor_type_href->{$sensor_type}{'QUIESCENT_CURR_MA'} ) {
                S_set_error("Missing 'QUIESCENT_CURR_MA' for sensor type '$sensor_type' (used from sensor '$sensor') ");
                return;
            }
            unless ( defined $psi5_sensor_type_href->{$sensor_type}{'TRANSMIT_CURR_MA'} ) {
                S_set_error("Missing 'TRANSMIT_CURR_MA' for sensor type '$sensor_type' (used from sensor '$sensor') ");
                return;
            }
            if ( $line_num == $psi5_sensor_project_href->{$sensor}{'LINE'} ) {
                $line_init_href->{$line_num}{'quiescent_curr_ma'} += $psi5_sensor_type_href->{$sensor_type}{'QUIESCENT_CURR_MA'};
                $line_init_href->{$line_num}{'transmit_curr_ma'} = $psi5_sensor_type_href->{$sensor_type}{'TRANSMIT_CURR_MA'};
            }
        }
    }
    return $line_init_href;
}

=head2 Fill_data_array

This function prepares the data value for the init_1, init_2, init_3, cyclic_msgs and user_msgs.

=cut

sub Fill_data_array {

    my $inpu_data_href = shift;

    return unless S_checkFunctionArguments( 'Fill_data_array ( $inpu_data_href )', ($inpu_data_href) );

    my $output_data_href = {};
    while ( my ( $data_element_index, $data_value ) = each %$inpu_data_href ) {
        if ( ref $inpu_data_href->{$data_element_index} ne 'HASH' ) {
            $output_data_href->{$data_element_index}{'Data_value_hex'} = $inpu_data_href->{$data_element_index};
        }
        else {
            $output_data_href->{$data_element_index} = $inpu_data_href->{$data_element_index};
        }

    }

    return $output_data_href;
}

=head2 Validate_sensor_config

This function validates the contents of sensor specific data.

=cut

sub Validate_sensor_config {

    my $psi5_sensor_project_href = shift;

    return unless S_checkFunctionArguments( 'Validate_sensor_config ( $psi5_sensor_project_href )', ($psi5_sensor_project_href) );

    my $err_flag = 0;

    my $sensor_config_aref = [ 'TYPE', 'LINE', 'TIMESLOT', 'INIT2_DATA', 'INIT3_DATA', 'CYCLIC_MESSAGES' ];

    foreach my $sensor ( keys %$psi5_sensor_project_href ) {
        my @mand_attr_missing = grep { !exists $psi5_sensor_project_href->{$sensor}{$_} } @$sensor_config_aref;

        if (@mand_attr_missing) {
            local $" = ',';
            S_set_error( "PSI5_init: Mandatory sensor attributes ( @mand_attr_missing ) not configured for the sensor '$sensor'", 109 );
            $err_flag .= '1';
        }
    }

    if ( $err_flag =~ /1/ ) {
        return;
    }
    return 1;
}

sub Init_Manitoo {
    eval "use LIFT_manitoo";
    MANITOO_init();
    return 1;
}

=head2 Set_init_data

    Set_init_data ( $sensor_device_name, $init_type_int, $init_data_href )

This function sets the init data for the init 1, init 2 and init 3 of the sensors.

This function has to be called from PSI5_set_Init_Data function only.(NON EXPORTED)

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $init_type_int

Type of init data to be set. ( init 1, init 2 or init 3 )

    Range: 1 - 3 ( int )

=item $init_data_href

Sets the data elements for the init data arrays .

1. $init_data_href = {
                        1 => {                                       # key 1 represents the data array element 1
                                'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
                                'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
                                'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                'DATA_VALUE_HEX' => '0x000' - '0xFFF'
                             },
                     }

2. $init_data_href = {
                        'ALL' => {                                  # if 'ALL' is configured then the respective value will be set for all elements
                                    'DATA_VALUE_HEX' => '0x42',
                                 },
                     }

=back

B<Return Value:>

returns $init_data_href

=cut

sub Set_init_data {

    my $init_data_type     = shift;
    my $init_data_href     = shift;
    my $sensor_device_name = shift;
    my $init_array_size    = shift;

    my %init_local_hash = %$init_data_href;

    my $init_local_href = \%init_local_hash;

    if ( exists( $init_local_href->{'ALL'} ) ) {

        if ( ref $init_local_href->{'ALL'} eq 'HASH' ) {

            $init_local_href = Convert_byte_keys($init_local_href);

            map { $init_local_href->{$_} = $init_local_href->{'ALL'} } ( 1 .. $init_array_size );
        }
        else {
            map { $init_local_href->{$_}{'Data_value_hex'} = $init_local_href->{'ALL'} } ( 1 .. $init_array_size );
        }
        delete $init_local_href->{'ALL'};
    }
    else {
        my $byte_index_aref = [];
        my $init_byte_size;
        if ( $init_data_type == 1 ) {
            $init_byte_size = $INIT_1_ARRAY_SIZE;
            $byte_index_aref = [ grep { $_ < 1 or $_ > $init_byte_size } keys %$init_local_href ];
        }
        elsif ( $init_data_type == 2 ) {
            $init_byte_size = $INIT_2_ARRAY_SIZE;
            $byte_index_aref = [ grep { $_ < 1 or $_ > $init_byte_size } keys %$init_local_href ];
        }
        elsif ( $init_data_type == $INIT_TYPE_3 ) {
            $init_byte_size = $INIT_3_ARRAY_SIZE;
            $byte_index_aref = [ grep { $_ < 1 or $_ > $init_byte_size } keys %$init_local_href ];
        }

        if (@$byte_index_aref) {
            S_set_error( "Set_init_data: The byte index for init $init_data_type data (@$byte_index_aref) not in range for sensor '$sensor_device_name', Valid range 1 .. $init_byte_size", 109 );
            return;
        }
        $init_local_href = Convert_byte_keys($init_local_href);
    }

    if ( exists( $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_data_type . "_data_href" } ) ) {
        my $defualt_init_data = $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $init_data_type . "_data_href" };
        if ( $init_data_type == 2 ) {

            # convert labels to hex values only when the $SENSOR_INIT_DATA has label values
            # This is required when setting of init 2 data in byte format is used
            if ( !exists $defualt_init_data->{1} ) {    # 1 indicates data is in hex format, conversion to hex is required when the data is in string.
                my $psi5_sensor_project_href = S_get_contents_of_hash( ['PSI5_SENSORS_PROJECT'] );
                my $sensor_type = $psi5_sensor_project_href->{$sensor_device_name}{TYPE};
                $defualt_init_data = Format_init2_label_data( $defualt_init_data, $sensor_type );
            }

        }
        foreach my $default_init_data_indx ( sort { $a <=> $b } keys %$defualt_init_data ) {
            if ( !exists $init_local_href->{$default_init_data_indx} ) {
                $init_local_href->{$default_init_data_indx} = $defualt_init_data->{$default_init_data_indx};
            }
            elsif ( exists $init_local_href->{$default_init_data_indx} ) {
                foreach my $keys ( keys %{ $defualt_init_data->{$default_init_data_indx} } ) {
                    if ( !exists $init_local_href->{$default_init_data_indx}{$keys} ) {
                        $init_local_href->{$default_init_data_indx}{$keys} = $defualt_init_data->{$default_init_data_indx}{$keys};
                    }
                }
            }
        }
    }

    return $init_local_href;

}

=head2 Convert_byte_keys

    Convert_byte_keys ( $data_href )

B<NON EXPORTED FUNCTION>

This function converts the keys of data array elements to camel case.

B<Arguments:>

=over

=item $data_href

    $data_href = {
                    1 => {                                       # key 1 represents the data array element 1
                            'ENABLE_SENSOR_STR' => 'on/off',     # default 'on'
                            'RESET_LOOP_INT' => '1/0',           # default '0'  (optional)
                            'MANCHESTER_FAULT_INT' => '1/0',     # default '0'  (optional)
                            'PARITY_FAULT_INT' => '1/0',         # default '0'  (optional)
                            'DATA_VALUE_HEX' => '0x000' - '0xFFF'
                         },
                 }

=back

B<Return Value:>

returns $data_href with the keys of data array elements converted to camel case

    e.g:
     
    $data_href = {
                    1 => {                                       # key 1 represents the data array element 1
                            'Enable_sensor_str' => 'on/off',     # default 'on'
                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                            'Data_value_hex' => '0x000' - '0xFFF'
                         },
                 }

=cut

sub Convert_byte_keys {

    my $data_href = shift;

    if ( exists( $data_href->{'ALL'} ) ) {

        if ( ref $data_href->{'ALL'} eq 'HASH' ) {

            foreach my $key ( keys %{ $data_href->{'ALL'} } ) {
                my $value = $data_href->{'ALL'}{$key};
                delete $data_href->{'ALL'}{$key};
                $key = ucfirst lc $key;
                $data_href->{'ALL'}{$key} = $value;
            }
        }

    }
    else {
        foreach my $byte ( keys %$data_href ) {

            # byte with only scalar value e.g 1 => '0x001'
            if ( ref $data_href->{$byte} ne 'HASH' ) {
                my $value = $data_href->{$byte};
                delete $data_href->{$byte};
                $data_href->{$byte}{'Data_value_hex'} = $value;
            }

            # byte with href value e.g 1 => {'Manchester_fault_int' => 1}
            else {
                foreach my $key ( keys %{ $data_href->{$byte} } ) {
                    my $value = $data_href->{$byte}{$key};
                    delete $data_href->{$byte}{$key};
                    $key = ucfirst lc $key;
                    $data_href->{$byte}{$key} = $value;
                }
            }
        }

    }

    return $data_href;
}

=head2 Fill_init2_data

    Fill_init2_data ( $sensor_device_name, $init2_config_href, $init2_data_href )

This function fills the init2 data corresponding to the type of data configured.

Supports two types : href and scalar

B<Arguments:>

=over

=item $sensor_device_name

Sensor device name configured as key in $Defaults->{'PSI5_SENSORS_PROJECT'} of Mapping_PSI5_settings.pm
    Example: 'UFSD', 'UFSP' ...

=item $init2_config_mix

Init 2 href configuration labels and values. e.g : { PROTOCOL_REVISION => 4, ... }

Init 2 scalar value e.g : '0X42010614A50000002100375033513152' (16bytes)

=back

B<Return Value:>

returns $init2_data_href

=cut

sub Fill_init2_data {

    my $sensor_device_name = shift;
    my $init2_config_mix   = shift;
    my $init2_data_href    = {};

    #IF is valid arguments?
    #IF-NO-START
    #STEP error not valid arguments
    #STEP return undef
    #IF-NO-END

    return unless S_checkFunctionArguments( 'Fill_init2_data ( $sensor_device_name, $init2_config_mix )', ( $sensor_device_name, $init2_config_mix ) );

    my $psi5_sensor_project_href = S_get_contents_of_hash( ['PSI5_SENSORS_PROJECT'] );

    my $sensor_type_str = $psi5_sensor_project_href->{$sensor_device_name}{TYPE};

    unless ( exists( $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type_str} ) ) {
        my @sup_sensor_types = keys(%$INIT2_DATA_SENSOR_CONFIG_MAPPING);
        S_set_error( "Fill_init2_data: sensor type '$sensor_type_str' not supported, supported values are: (@sup_sensor_types)", 109 );
        return;
    }

    #IF-YES-START
    #IF is argument type href?
    #IF-YES-START
    #STEP call each specific parameter function if the init2 label is href
    #IF-YES-END
    if ( ref $init2_config_mix eq 'HASH' ) {

        #special case handling for pas6s, ufs6s, pas6f and ufs6f
        return unless ( Validate_filter_and_dependent_params_for_pas6sf_and_ufs6sf( $init2_config_mix, $sensor_type_str, $sensor_device_name ) );

        my $init2_param_range_href = $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type_str};
        my @invalid_params = grep { !exists $init2_param_range_href->{$_} } keys %$init2_config_mix;
        if (@invalid_params) {
            my @valid_init2_range = keys %$init2_param_range_href;
            local $" = ",\n";
            S_set_error( "Fill_init2_data: Init 2 data parameter name(s) \n\n ( @invalid_params ) not in range for sensor '$sensor_device_name' of type '$sensor_type_str', valid range: \n\n( @valid_init2_range )\n", 109 );
            return;
        }

        foreach my $init2_attribute ( keys %{$init2_config_mix} ) {

            if ( exists $VALID_INIT2_LABELS{$init2_attribute} ) {
                my $functionname = ucfirst lc $init2_attribute;
                my $func_ref     = \&$functionname;               # $& contains the function name
                                                                  # create a reference to the function name, direct function call leads to error when strict refs is in use.
                $init2_data_href->{$init2_attribute} = &$func_ref( $init2_config_mix, $init2_attribute, $sensor_device_name );
                $INIT2_LABEL_href->{$sensor_device_name}{$init2_attribute} = $init2_data_href->{$init2_attribute};

                return unless ( defined $init2_data_href->{$init2_attribute} );    #return if there is error in the function call
            }
        }
    }

    #IF-NO-START
    #STEP call Init2_hex_to_labels if init2 is scalar
    #IF-NO-END
    else {
        $init2_config_mix =~ s/^0x//i;    #remove '0x' if present in the starting of the string
        if ( length($init2_config_mix) != 32 ) {
            S_set_error( "Fill_init2_data: Init 2 data for sensor '$sensor_device_name' should be of 16 bytes, Check the length in Mapping file", 109 );
            return;
        }
        $init2_data_href = Init2_hex_to_labels( $sensor_type_str, $sensor_device_name, $init2_config_mix );

    }

    #IF-YES-END
    #STEP END
    $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . '2' . "_data_href" } = $init2_data_href;
    return $init2_data_href;
}

=head2 Fill_init3_data

    Fill_init3_data ( $sensor_device_name, $init3_config_href )

B<NON EXPORTED FUNCTION>

This function prepares the $init3_data_href in the bytes format as required.

B<Arguments:>

=over

=item $init3_config_href

Init3 data configuration.

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=back

B<Return Value:>

returns success: $init3_data_href.

return failure: undef.

=cut

sub Fill_init3_data {

    my $sensor_device_name = shift;
    my $init3_config_href  = shift;
    my $init3_data_href    = {};

    #IF is valid sensor name init 3 config?
    #IF-YES-START
    #STEP convert the label to byte format and return the byte format ($init3_data_href)
    #IF-YES-END
    #IF-NO-START
    #STEP Error not valid arguments return undef
    #IF-NO-END
    #STEP END

    return unless S_checkFunctionArguments( 'Fill_init3_data ( $sensor_device_name, $init3_config_href )', ( $sensor_device_name, $init3_config_href ) );

    my $init3_msg_range = {
        SENSOR_OK                      => '0x1E7',
        SENSOR_DEFECT                  => '0x1F4',
        SENSOR_OK_LOCK_BIT_3_NOT_SET   => '0x1E6',
        SENSOR_OK_LOCK_BIT_2_3_NOT_SET => '0x1E5',
    };

    my $valid_keys_aref      = [ 'INIT3_MESSAGE', 'ABSOLUTE_PRESSURE_VALUE' ];
    my $configured_keys_aref = [ keys %$init3_config_href ];
    my $invalid_keys_aref    = [ grep { !( $_ ~~ @$valid_keys_aref ) } @$configured_keys_aref ];

    if (@$invalid_keys_aref) {
        local $" = ', ';
        S_set_error( "Fill_init3_data: INIT3_DATA value(s) (@$invalid_keys_aref) for sensor '$sensor_device_name' not in range, valid range ( @$valid_keys_aref )", 109 );
        return;
    }

    if ( !exists $init3_msg_range->{ $init3_config_href->{'INIT3_MESSAGE'} } ) {
        my $init3_msg = $init3_config_href->{'INIT3_MESSAGE'};
        local $" = ', ';
        my $valid_message_aref = [ keys %$init3_msg_range ];
        S_set_error( "Fill_init3_data: The value '$init3_msg' of INIT3_MESSAGE for sensor '$sensor_device_name' not in range, valid range ( @$valid_message_aref )", 109 );
        return;
    }

    if ( !exists $init3_config_href->{'ABSOLUTE_PRESSURE_VALUE'} ) {
        map { $init3_data_href->{$_}{'Data_value_hex'} = $init3_msg_range->{ $init3_config_href->{'INIT3_MESSAGE'} } } ( 1 .. $INIT_3_ARRAY_SIZE );
    }
    elsif ( exists $init3_config_href->{'ABSOLUTE_PRESSURE_VALUE'} ) {
        my $abs_presure_Polsb      = $init3_config_href->{'ABSOLUTE_PRESSURE_VALUE'};
        my $pressure_val_start_idx = '13';

        $init3_data_href = Convert_absolute_pressure_value( $abs_presure_Polsb, $pressure_val_start_idx );

        map { $init3_data_href->{$_}{'Data_value_hex'} = $init3_msg_range->{ $init3_config_href->{'INIT3_MESSAGE'} } } ( 1 .. $INIT_3_MESSAGES_SIZE );

    }
    $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . $INIT_TYPE_3 . "_data_href" } = $init3_data_href;
    return $init3_data_href;
}

=head2 Fill_init1_data

    Fill_init1_data ( $sensor_device_name, $init1_config_href )

B<NON EXPORTED FUNCTION>

This function prepares the $init1_data_href in the bytes format as required.

B<Arguments:>

=over

=item $init1_config_href

Init1 data configuration.

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=back

B<Return Value:>

returns success: $init1_data_href.

return failure: undef.

=cut

sub Fill_init1_data {

    my $sensor_device_name = shift;
    my $init1_config_href  = shift;
    my $init1_data_href    = {};
    my $init1_byte_href    = {};

    return unless S_checkFunctionArguments( 'Fill_init1_data ( $sensor_device_name, $init1_config_href )', ( $sensor_device_name, $init1_config_href ) );

    my $valid_keys_aref      = ['INIT1_MESSAGE'];
    my $valid_labels_aref    = [ 'NO_MESSAGES', 'MANCHESTER_ERRORS', 'PARITY_ERRORS' ];
    my $configured_keys_aref = [ keys %$init1_config_href ];
    my $invalid_keys_aref    = [ grep { !( $_ ~~ @$valid_keys_aref ) } @$configured_keys_aref ];

    if (@$invalid_keys_aref) {
        local $" = ', ';
        S_set_error( "Fill_init1_data: INIT1_DATA Keys(s) (@$invalid_keys_aref) for sensor '$sensor_device_name' not in range, valid range ( @$valid_keys_aref )", 109 );
        return;
    }

    if ( $init1_config_href->{'INIT1_MESSAGE'} eq 'NO_MESSAGES' ) {
        $init1_byte_href->{'ALL'}{'Data_value_hex'} = '0x000';
    }
    elsif ( $init1_config_href->{'INIT1_MESSAGE'} eq 'MANCHESTER_ERRORS' ) {
        $init1_byte_href->{'ALL'}{'Manchester_fault_int'} = '1';
    }
    elsif ( $init1_config_href->{'INIT1_MESSAGE'} eq 'PARITY_ERRORS' ) {
        $init1_byte_href->{'ALL'}{'Parity_fault_int'} = '1';
    }
    else {
        local $" = ', ';
        S_set_error( "Fill_init1_data: The label '$init1_config_href->{'INIT1_MESSAGE'}' is invalid for sensor '$sensor_device_name', Valid labels (@$valid_labels_aref)", 109 );
        return;
    }

    $init1_data_href = Set_init_data( 1, $init1_byte_href, $sensor_device_name, $INIT_1_ARRAY_SIZE );

    $SENSOR_INIT_DATA->{$sensor_device_name}{ "init" . '1' . "_data_href" } = $init1_data_href;

    return $init1_data_href;
}

=head2 Convert_absolute_pressure_value

    Convert_absolute_pressure_value ( $abs_presure_Polsb, $pressure_val_start_idx )

B<NON EXPORTED FUNCTION>

This function converts the Absolute Pressure Value in Po.lsb to bytes format as required.

B<Arguments:>

=over

=item $abs_presure_Polsb

Absolute Pressure Value in Po.lsb

=item $pressure_val_start_idx

Byte index to start writting the pressure value

=back

B<Return Value:>

returns success: $pressure_data_href.

return failure: undef.

=cut

sub Convert_absolute_pressure_value {

    my $abs_presure_Polsb      = shift;
    my $pressure_val_start_idx = shift;
    my $pressure_data_idx_aref = [ '00', '01', '10', '11' ];
    my $pressure_data_href     = {};

    # https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-380-0003c52b
    # convert absolute pressure value to 5 bit nibbles with 3 bit pressure data and 2 bit address
    my $abs_pressure_bin_aref = [ grep { $_ } ( split( /(...)/, sprintf( "%.12B", $abs_presure_Polsb ) ) ) ];

    # offset address for pressure data
    my $offset_address = '512';

    # append data portion index ( address ) for the absolute pressure value
    foreach my $data_portion ( 0 .. ( scalar @$abs_pressure_bin_aref - 1 ) ) {
        $abs_pressure_bin_aref->[$data_portion] = $pressure_data_idx_aref->[$data_portion] . $abs_pressure_bin_aref->[$data_portion];
        $abs_pressure_bin_aref->[$data_portion] = sprintf( "%.3X", oct "0b$abs_pressure_bin_aref->[$data_portion]" );
        my $data_portion_dec = 0;
        $data_portion_dec = $offset_address + hex $abs_pressure_bin_aref->[$data_portion] if ($abs_presure_Polsb);
        $pressure_data_href->{ $pressure_val_start_idx++ }{'Data_value_hex'} = '0x' . sprintf( "%.3X", $data_portion_dec );
    }
    return $pressure_data_href;
}

=head2 Protocol_revision

    Protocol_revision ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the protocol revision to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, MANUFACTURER => 'BOSCH' }

=item $init2_attribute

Init 2 attribute configured 'PROTOCOL_REVISION'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of protocol revision.

return failure: undef 

=cut

sub Protocol_revision {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $protocol_value = $init2_config_href->{$init2_attribute};

    if ( $protocol_value < 1 or $protocol_value > $MAX_PROTOCOL_VALUE ) {
        S_set_error( "Protocol_revision: Protocol revision '$protocol_value' for sensor '$sensor_device_name' not in valid range, Range (1 .. 15) integer", 109 );
        return;
    }
    return sprintf( "%X", $protocol_value );
}

=head2 Number_of_data_blocks

    Number_of_data_blocks ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the number of data blocks to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, NUMBER_OF_DATA_BLOCKS => '32' }

=item $init2_attribute

Init 2 attribute configured 'NUMBER_OF_DATA_BLOCKS'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of number of data blocks.

return failure: undef 

=cut

sub Number_of_data_blocks {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $nbrDataBlocks = $init2_config_href->{$init2_attribute};

    if ( $nbrDataBlocks < 1 or $nbrDataBlocks > $MAX_DATA_BLOCKS ) {
        S_set_error( "Number_of_data_blocks: Number of data blocks '$nbrDataBlocks' for sensor '$sensor_device_name' not in valid range, Range (1 .. 128) integer", 109 );
        return;
    }
    return sprintf( "%.2X", $nbrDataBlocks );
}

=head2 Manufacturer

    Manufacturer ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for MANUFACTURER to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, MANUFACTURER => 'BOSCH' }

=item $init2_attribute

Init 2 attribute configured 'MANUFACTURER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for MANUFACTURER.

return failure: undef 

=cut

sub Manufacturer {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $manufacturer = $init2_config_href->{$init2_attribute};

    unless ( exists( $MANUFACTURER{$manufacturer} ) ) {
        S_set_error( "Manufacturer: Manufacturer '$manufacturer' for sensor '$sensor_device_name' not supported", 109 );
        return;
    }
    my $manfact_value = $MANUFACTURER{$manufacturer};
    $manfact_value =~ s/^0x//i;
    return ($manfact_value);
}

=head2 Transmission_mode

    Transmission_mode ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for TRANSMISSION_MODE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, TRANSMISSION_MODE => 'ABS_PRESSURE_ON' }

=item $init2_attribute

Init 2 attribute configured 'TRANSMISSION_MODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for TRANSMISSION_MODE.

return failure: undef 

=cut

sub Transmission_mode {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $transmission_mode_str = $init2_config_href->{$init2_attribute};

    unless ( exists( $TRANSMISSION_MODE{$transmission_mode_str} ) ) {
        S_set_error( "Transmission_mode: Transmission mode '$transmission_mode_str' for sensor '$sensor_device_name' not supported", 109 );
        return;
    }
    my $transmission_mode_hex = $TRANSMISSION_MODE{$transmission_mode_str};
    $transmission_mode_hex =~ s/^0x//i;
    return ($transmission_mode_hex);
}

=head2 Sensor_type_psi_configuration

    Sensor_type_psi_configuration ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for SENSOR_TYPE_PSI_CONFIGURATION.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_TYPE_PSI_CONFIGURATION => '0x12' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_TYPE_PSI_CONFIGURATION'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value configured for SENSOR_TYPE_PSI_CONFIGURATION.

return failure: undef 

=cut

sub Sensor_type_psi_configuration {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $psi_config_hex = $init2_config_href->{$init2_attribute};

    unless ( $psi_config_hex =~ /^0x[0-9A-Fa-f]$/i ) {
        S_set_error( "Sensor_type_psi_configuration: PSI configuration '$psi_config_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xF'", 109 );
        return;
    }

    $psi_config_hex =~ s/^0x//;
    return ($psi_config_hex);
}

=head2 Electronic_house_coding

    Electronic_house_coding ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for ELECTRONIC_HOUSE_CODING.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, ELECTRONIC_HOUSE_CODING => '0x12' }

=item $init2_attribute

Init 2 attribute configured 'ELECTRONIC_HOUSE_CODING'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value configured for ELECTRONIC_HOUSE_CODING.

return failure: undef 

=cut

sub Electronic_house_coding {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $elec_house_code_hex = $init2_config_href->{$init2_attribute};

    unless ( $elec_house_code_hex =~ /^0x[0-9A-Fa-f]{1,2}$/i ) {
        S_set_error( "Electronic_house_coding: Electronic house code '$elec_house_code_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xFF'", 109 );
        return;
    }

    $elec_house_code_hex =~ s/^0x//i;

    $elec_house_code_hex = sprintf( "%.2X", hex $elec_house_code_hex );

    return ($elec_house_code_hex);
}

=head2 Bosch_sensor_code

    Bosch_sensor_code ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for BOSCH_SENSOR_CODE.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, BOSCH_SENSOR_CODE => '0x12' }

=item $init2_attribute

Init 2 attribute configured 'BOSCH_SENSOR_CODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value configured for BOSCH_SENSOR_CODE.

return failure: undef 

=cut

sub Bosch_sensor_code {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $bosch_sensor_code_hex = $init2_config_href->{$init2_attribute};

    unless ( $bosch_sensor_code_hex =~ /^0x[0-9A-Fa-f]{1,2}$/i ) {
        S_set_error( "Bosch_sensor_code: Bosch sensor code '$bosch_sensor_code_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xFF'", 109 );
        return;
    }

    $bosch_sensor_code_hex =~ s/^0x//i;

    $bosch_sensor_code_hex = sprintf( "%.2X", hex $bosch_sensor_code_hex );

    return ($bosch_sensor_code_hex);
}

=head2 Manufacturer_series_code

    Manufacturer_series_code ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for MANUFACTURER_SERIES_CODE.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, MANUFACTURER_SERIES_CODE => '0x123' }

=item $init2_attribute

Init 2 attribute configured 'MANUFACTURER_SERIES_CODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value configured for MANUFACTURER_SERIES_CODE.

return failure: undef 

=cut

sub Manufacturer_series_code {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $manufact_series_code_hex = $init2_config_href->{$init2_attribute};

    unless ( $manufact_series_code_hex =~ /^0x[0-9A-Fa-f]{1,3}$/i ) {
        S_set_error( "Manufacturer_series_code: Manufacturer series code '$manufact_series_code_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xFFF'", 109 );
        return;
    }

    $manufact_series_code_hex =~ s/^0x//i;
    $manufact_series_code_hex = sprintf( "%.3X", hex $manufact_series_code_hex );

    return ($manufact_series_code_hex);
}

=head2 Pas6e_generation_bit

    Pas6e_generation_bit ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for PAS6e_GENERATION_BIT to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, PAS6e_GENERATION_BIT => 'PAS6' }

=item $init2_attribute

Init 2 attribute configured 'PAS6e_GENERATION_BIT'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for PAS6e_GENERATION_BIT.

return failure: undef 

=cut

sub Pas6e_generation_bit {
    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $generation_bit = $init2_config_href->{$init2_attribute};

    unless ( exists( $PAS6e_GENERATION_BIT{$generation_bit} ) ) {
        my $valid_generation_aref = [];
        @$valid_generation_aref = keys %PAS6e_GENERATION_BIT;
        local $" = ',';
        S_set_error( "Pas6e_generation_bit: Generation bit '$generation_bit' for sensor '$sensor_device_name' not supported, valid range (@$valid_generation_aref)", 109 );
        return;
    }
    my $genvalue = $PAS6e_GENERATION_BIT{$generation_bit};
    $genvalue =~ s/^0x//i;
    return ($genvalue);
}

=head2 Sensor_type

    Sensor_type ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_TYPE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_TYPE => 'ACCELERATION_SENSOR' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_TYPE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SENSOR_TYPE.

return failure: undef 

=cut

sub Sensor_type {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sensor_type = $init2_config_href->{$init2_attribute};

    unless ( exists( $SENSOR_TYPE{$sensor_type} ) ) {
        my $valid_sensor_aref = [];
        @$valid_sensor_aref = keys %SENSOR_TYPE;
        local $" = ',';
        S_set_error( "Sensor_type: Sensor type  '$sensor_type' for sensor '$sensor_device_name' not supported, valid range (@$valid_sensor_aref)", 109 );
        return;
    }
    my $typevalue = $SENSOR_TYPE{$sensor_type};
    $typevalue =~ s/^0x//i;
    $typevalue = sprintf( "%.2X", $typevalue ) unless $sensor_type eq 'ACCELERATION_SENSOR';
    return ($typevalue);
}

=head2 Acceleration_axis

    Acceleration_axis ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_TYPE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, ACCELERATION_AXIS => 'ACCELERATION_AXIS_ALPHA' }

=item $init2_attribute

Init 2 attribute configured 'ACCELERATION_AXIS'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for ACCELERATION_AXIS.

return failure: undef 

=cut

sub Acceleration_axis {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $accel_axis = $init2_config_href->{$init2_attribute};

    unless ( exists( $ACCELERATION_AXIS{$accel_axis} ) ) {
        my $valid_axis_aref = [];
        @$valid_axis_aref = keys %ACCELERATION_AXIS;
        local $" = ',';
        S_set_error( "Acceleration_axis: Acceleration axis  '$accel_axis' for sensor '$sensor_device_name' not supported, valid range (@$valid_axis_aref)", 109 );
        return;
    }
    my $accel_axis_value = $ACCELERATION_AXIS{$accel_axis};
    $accel_axis_value =~ s/^0x//i;
    return ($accel_axis_value);
}

=head2 Acceleration_range

    Acceleration_range ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for ACCELERATION_RANGE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, ACCELERATION_RANGE => '240g_RANGE' }

=item $init2_attribute

Init 2 attribute configured 'ACCELERATION_RANGE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for ACCELERATION_RANGE.

return failure: undef 

=cut

sub Acceleration_range {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $accel_range = $init2_config_href->{$init2_attribute};

    unless ( exists( $ACCELERATION_RANGE{$accel_range} ) ) {
        my $valid_accl_aref = [];
        @$valid_accl_aref = keys %ACCELERATION_RANGE;
        local $" = ',';
        S_set_error( "Acceleration_range: Acceleration range '$accel_range' for sensor '$sensor_device_name' not supported, valid range (@$valid_accl_aref)", 109 );
        return;
    }
    my $accel_range_value = $ACCELERATION_RANGE{$accel_range};
    $accel_range_value =~ s/^0x//i;
    return ($accel_range_value);
}

=head2 Sensor_code

    Sensor_code ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_CODE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_CODE => 'SMA_AXIS_X_FILTER_213Hz' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_CODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SENSOR_CODE.

return failure: undef 

=cut

sub Sensor_code {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sensor_code = $init2_config_href->{$init2_attribute};

    unless ( exists( $SENSOR_CODE{$sensor_code} ) ) {
        my $valid_sensor_aref = [];
        @$valid_sensor_aref = keys %SENSOR_CODE;
        local $" = ',';
        S_set_error( "Sensor_code: Sensor code '$sensor_code' for sensor '$sensor_device_name' not supported, valid range (@$valid_sensor_aref)", 109 );
        return;
    }
    my $sensor_code_value = $SENSOR_CODE{$sensor_code};
    $sensor_code_value =~ s/^0x//i;
    my $sensor_code_value_bin = sprintf( "%.2b", hex $sensor_code_value );
    return ($sensor_code_value_bin);
}

=head2 Housing_code

    Housing_code ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for HOUSING_CODE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { HOUSING_CODE => '0x10' }

=item $init2_attribute

Init 2 attribute configured 'HOUSING_CODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of HOUSING_CODE.

return failure: undef 

=cut

sub Housing_code {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $housing_code_hex = $init2_config_href->{$init2_attribute};

    if ( $housing_code_hex !~ /^0x(([0-9A-Fa-f])|([0-3]?[0-9A-Fa-f]))$/i ) {
        S_set_error( "Housing_code: Housing code '$housing_code_hex' for sensor '$sensor_device_name' not supported valid range '0x0' .. '0x3F'", 109 );
        return;
    }

    $housing_code_hex =~ s/^0x//i;

    my $housing_code_bin = sprintf( "%.6b", hex $housing_code_hex );

    return ($housing_code_bin);
}

=head2 Sensor_code_customer

    Sensor_code_customer ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_CODE_CUSTOMER to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_CODE_CUSTOMER => '0x101' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_CODE_CUSTOMER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SENSOR_CODE_CUSTOMER.

return failure: undef 

=cut

sub Sensor_code_customer {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sensor_code_hex = $init2_config_href->{$init2_attribute};

    unless ( $sensor_code_hex =~ /^0x([0-9A-Fa-f]|[0-9A-Fa-f]{2}|[0-9A-Fa-f]{3})$/i ) {
        S_set_error( "Sensor_code_customer: Sensor code customer '$sensor_code_hex' for sensor '$sensor_device_name' not supported valid range '0x0' .. '0x3F'", 109 );
        return;
    }

    $sensor_code_hex =~ s/^0x//i;

    $sensor_code_hex = sprintf( "%.3X", hex $sensor_code_hex );
    return ($sensor_code_hex);
}

=head2 Sgb_manufacturing_date

    Sgb_manufacturing_date ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SGB_MANUFACTURING_DATE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SGB_MANUFACTURING_DATE => '1-12-2010' }

=item $init2_attribute

Init 2 attribute configured 'SGB_MANUFACTURING_DATE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SGB_MANUFACTURING_DATE.

return failure: undef 

=cut

sub Sgb_manufacturing_date {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $manufact_date = $init2_config_href->{$init2_attribute};
    my $day           = '([0]?[1-9]|[12][0-9]|3[01])';
    my $month         = '([0]?[1-9]|1[0-2])';
    my $year          = '(20[0-2][0-9]|203[0-1])';

    my ( $day_dec, $month_dec, $year_dec ) = ( 0, 0, 0 );

    if ( $manufact_date =~ /^$day\-$month\-$year$/ ) {
        ( $day_dec, $month_dec, $year_dec ) = split( /-/, $manufact_date );
    }
    elsif ( $manufact_date =~ /^$month\-$year$/ ) {
        ( $month_dec, $year_dec ) = split( /-/, $manufact_date );
    }
    elsif ( $manufact_date =~ /^$year$/ ) {
        $year_dec = $manufact_date;
    }
    else {
        my $errortext = "Check valid range and format. \n
                            1.Valid range '01-01-2000' .. '31-12-2031'. \n
                            2.Valid Formats: (dd-mm-yyyy or mm-yyyy or yyyy).\n";
        S_set_error( "Sgb_manufacturing_date: Manufacturing date '$manufact_date' for sensor '$sensor_device_name' not supported. $errortext", 109 );
        return;
    }

    my $day_bin   = sprintf( "%.5b", $day_dec );
    my $month_bin = sprintf( "%.4b", $month_dec );
    my $year_bin  = sprintf( "%.7b", substr( $year_dec, 2 ) );

    my $manufact_date_hex = unpack( "H6", pack( "B16", $year_bin . $month_bin . $day_bin ) );

    return $manufact_date_hex;

}

=head2 Lot_number

    Lot_number ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for LOT_NUMBER.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, LOT_NUMBER => '0xB' }

=item $init2_attribute

Init 2 attribute configured 'LOT_NUMBER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of LOT_NUMBER.

return failure: undef 

=cut

sub Lot_number {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $lot_number_hex = $init2_config_href->{$init2_attribute};

    unless ( $lot_number_hex =~ /^0x[0-9A-Fa-f]$/i ) {
        S_set_error( "Lot_number: Lot number '$lot_number_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xF'", 109 );
        return;
    }

    $lot_number_hex =~ s/^0x//i;

    return ($lot_number_hex);
}

=head2 Line_number

    Line_number ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates value configured for LINE_NUMBER.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, LINE_NUMBER => '0xB' }

=item $init2_attribute

Init 2 attribute configured 'LINE_NUMBER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of LINE_NUMBER.

return failure: undef 

=cut

sub Line_number {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $line_number_hex = $init2_config_href->{$init2_attribute};

    unless ( $line_number_hex =~ /^0x[0-9A-Fa-f]$/i ) {
        S_set_error( "Line_number: Line number '$line_number_hex' for sensor '$sensor_device_name' not supported, valid range '0x0' .. '0xF'", 109 );
        return;
    }

    $line_number_hex =~ s/^0x//i;

    return ($line_number_hex);
}

=head2 Sensor_bus_mode

    Sensor_bus_mode ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_BUS_MODE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_BUS_MODE => 'BUS3_TIMESLOT1' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_BUS_MODE'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SENSOR_BUS_MODE.

return failure: undef 

=cut

sub Sensor_bus_mode {
    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sensor_bus_mode_str = $init2_config_href->{$init2_attribute};

    unless ( exists $SENSOR_BUS_MODE{$sensor_bus_mode_str} ) {
        my $valid_sensor_bus_modes = [];
        @$valid_sensor_bus_modes = keys %SENSOR_BUS_MODE;
        local $" = ',';
        S_set_error( "Sensor_bus_mode: Sensor bus mode '$sensor_bus_mode_str' is not valid, valid range (@$valid_sensor_bus_modes) ", 109 );
        return;
    }
    my $bus_mode_value_hex = $SENSOR_BUS_MODE{$sensor_bus_mode_str};
    $bus_mode_value_hex =~ s/^0x//i;

    return $bus_mode_value_hex;
}

=head2 Series_number

    Series_number ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates configured for SERIES_NUMBER.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SERIES_NUMBER => '0x142356AB3443' }

=item $init2_attribute

Init 2 attribute configured 'SERIES_NUMBER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of SERIES_NUMBER.

return failure: undef 

=cut

sub Series_number {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $series_number_hex = $init2_config_href->{$init2_attribute};

    unless ( $series_number_hex =~ /^0x[0-9A-Fa-f]{12}$/i ) {
        S_set_error( "Series_number: Series number '$series_number_hex' for sensor '$sensor_device_name' not supported, valid range 12 nibble hex value", 109 );
        return;
    }

    $series_number_hex =~ s/^0x//i;

    return ($series_number_hex);
}

=head2 Satellite_sensing_axis

    Satellite_sensing_axis ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SATELLITE_SENSING_AXIS to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SATELLITE_SENSING_AXIS => '0x142356AB3443' }

=item $init2_attribute

Init 2 attribute configured 'SATELLITE_SENSING_AXIS'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SATELLITE_SENSING_AXIS.

return failure: undef 

=cut

sub Satellite_sensing_axis {
    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sensing_axis_str = $init2_config_href->{$init2_attribute};

    my $valid_sensing_axis_values = [];
    @$valid_sensing_axis_values = keys %SATELLITE_SENSING_AXIS;
    unless ( exists $SATELLITE_SENSING_AXIS{$sensing_axis_str} ) {
        S_set_error( "Sensor_bus_mode: Satellite sensing axis '$sensing_axis_str' is not valid, valid range (@$valid_sensing_axis_values) ", 109 );
        return;
    }
    my $sensing_axis_hex = $SATELLITE_SENSING_AXIS{$sensing_axis_str};
    $sensing_axis_hex =~ s/^0x//i;

    return $sensing_axis_hex;
}

=head2 Filter_type

    Filter_type ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for FILTER_TYPE_AND_SAMPLING_MODE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, FILTER_TYPE_AND_SAMPLING_MODE => 'FIR' }

=item $init2_attribute

Init 2 attribute configured 'FILTER_TYPE_AND_SAMPLING_MODE'

=item $sensor_device_name

Sensor device name configured. e.g 'PPSFD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for FILTER_TYPE_AND_SAMPLING_MODE.

return failure: undef 

=cut

sub Filter_type_and_sampling_mode {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $filter_type_and_sampling_mode = $init2_config_href->{$init2_attribute};

    unless ( exists( $FILTER_TYPE_AND_SAMPLING_MODE{$filter_type_and_sampling_mode} ) ) {
        my $valid_sensor_aref = [];
        @$valid_sensor_aref = keys %FILTER_TYPE_AND_SAMPLING_MODE;
        local $" = ', ';
        S_set_error( "Filter_type_and_sampling_mode: Filter type and sampling mode '$filter_type_and_sampling_mode' for sensor '$sensor_device_name' not supported, valid range (@$valid_sensor_aref)", 109 );
        return;
    }
    my $filter_type_and_sampling_mode_value = $FILTER_TYPE_AND_SAMPLING_MODE{$filter_type_and_sampling_mode};
    $filter_type_and_sampling_mode_value =~ s/^0x//i;
    return ($filter_type_and_sampling_mode_value);
}

=head2 Pressure_sensor_type

    Pressure_sensor_type ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for PRESSURE_SENSOR_TYPE to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, PRESSURE_SENSOR_TYPE => 'ACCELERATION_SENSOR' }

=item $init2_attribute

Init 2 attribute configured 'PRESSURE_SENSOR_TYPE'

=item $sensor_device_name

Sensor device name configured. e.g 'PPSFD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for PRESSURE_SENSOR_TYPE.

return failure: undef 

=cut

sub Pressure_sensor_type {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $pressure_sensor_type = $init2_config_href->{$init2_attribute};

    unless ( exists( $PRESSURE_SENSOR_TYPE{$pressure_sensor_type} ) ) {
        my $valid_sensor_aref = [];
        @$valid_sensor_aref = keys %PRESSURE_SENSOR_TYPE;
        local $" = ', ';
        S_set_error( "Sensor_type: Sensor type '$pressure_sensor_type' for sensor '$sensor_device_name' not supported, valid range (@$valid_sensor_aref)", 109 );
        return;
    }
    my $typevalue = $PRESSURE_SENSOR_TYPE{$pressure_sensor_type};
    $typevalue =~ s/^0x//i;
    $typevalue = sprintf( "%.1X", $typevalue );
    return ($typevalue);
}

=head2 Sensor_mode

    Sensor_mode ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SENSOR_MODE to bin value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SENSOR_MODE => 'ACCELERATION_SENSOR' }

=item $init2_attribute

Init 2 attribute configured 'SENSOR_MODE'

=item $sensor_device_name

Sensor device name configured. e.g 'PPSFD', 'PTSD'

=back

B<Return Value:>

return success: bin value of label configured for SENSOR_MODE.

return failure: undef 

=cut

sub Sensor_mode {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $mode = $init2_config_href->{$init2_attribute};

    unless ( exists( $SENSOR_MODE{$mode} ) ) {
        my $valid_range_aref = [];
        @$valid_range_aref = keys %SENSOR_MODE;
        local $" = ', ';
        S_set_error( "Sensor_mode: Sensor mode  '$mode' for sensor '$sensor_device_name' not supported, valid range (@$valid_range_aref)", 109 );
        return;
    }
    my $modeValue = $SENSOR_MODE{$mode};
    $modeValue =~ s/^0x//i;
    $modeValue = sprintf( "%.3b", hex $modeValue );
    return ($modeValue);
}

=head2 Psi5_mode

    Psi5_mode ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for PSI5_MODE to bin value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, PSI5_MODE => 'P10P_500_4H_PN_COARSE_SLOT1__PN_SLOT4_PARITY' }

=item $init2_attribute

Init 2 attribute configured 'PSI5_MODE'

=item $sensor_device_name

Sensor device name configured. e.g 'PPSFD', 'PTSD'

=back

B<Return Value:>

return success: bin value of label configured for PSI5_MODE.

return failure: undef 

=cut

sub Psi5_mode {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $psi5_mode = $init2_config_href->{$init2_attribute};

    unless ( exists( $PSI5_MODE{$psi5_mode} ) ) {
        my $valid_transmission_mode_aref = [];
        @$valid_transmission_mode_aref = keys %PSI5_MODE;
        local $" = ",\n";
        S_set_error( "Psi5_mode: Psi5_mode '$psi5_mode' for sensor '$sensor_device_name' not supported, valid range \n (\n @$valid_transmission_mode_aref \n)\n", 109 );
        return;
    }
    my $transmissionValue = $PSI5_MODE{$psi5_mode};
    $transmissionValue =~ s/^0x//i;
    $transmissionValue = sprintf( "%.5b", hex $transmissionValue );
    return ($transmissionValue);
}

=head2 Format_init2_label_data

    Format_init2_label_data ( $sensor_init_href, $sensor_type_str )

B<NON EXPORTED FUNCTION>

This function formats the init 2 data in the order of labels as defined in the ManiPAS GUI.

B<Arguments:>

=over

=item $sensor_init_href

Init 2 configuration data converted to hex values

    Example: { PROTOCOL_REVISION => 4, ..}

=item $sensor_type_str

Sensor type e.g 'UFS3', 'PPS2', ...

=back

B<Return Value:>

return $init_2_data_href.

=cut

sub Format_init2_label_data {

    my $sensor_init_href   = shift;
    my $sensor_type_str    = shift;
    my $sensor_type_param  = {};
    my $local_sensor_param = {};
    $sensor_type_param   = $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type_str};
    %$local_sensor_param = reverse %$sensor_type_param;

    my $init_2_data_hex;

    # build hex string from labels except for the labels which returns binary values
    foreach my $nibble_start_pos ( sort { $a <=> $b } keys %$local_sensor_param ) {
        my $label_name                     = $local_sensor_param->{$nibble_start_pos};
        my $donot_assign_values_for_params = 'SENSOR_CODE|HOUSING_CODE|SENSOR_MODE|PSI5_MODE|SAMPLE_TIME_AND_FILTER';
        unless ( $label_name =~ /^($donot_assign_values_for_params)$/ ) {
            $init_2_data_hex .= $sensor_init_href->{$label_name};
        }
    }
    my ( $sensor_and_housing_code, $pressureRange_and_tranmissionMode );

    # perform merging of binary data returned from labels in order to get hex string
    # for sensor types PAS6_PAS6e_UFS6_UFS6e_PAS5_UFS3_UFS3R_PAS5R
    if ( exists $sensor_init_href->{SENSOR_CODE} and exists $sensor_init_href->{HOUSING_CODE} ) {

        $sensor_and_housing_code = $sensor_init_href->{SENSOR_CODE} . $sensor_init_href->{HOUSING_CODE};
        $sensor_and_housing_code = unpack( "H2", pack( "B8", $sensor_and_housing_code ) );    # 1 byte data
        my $sensor_code_position = '9';    # nibble postion
        substr( $init_2_data_hex, $sensor_code_position, 0, $sensor_and_housing_code );
    }

    #for sensor types PPS3e, PTS1
    if ( exists $sensor_init_href->{SENSOR_MODE} and exists $sensor_init_href->{PSI5_MODE} ) {
        $pressureRange_and_tranmissionMode = $sensor_init_href->{SENSOR_MODE} . $sensor_init_href->{PSI5_MODE};
        $pressureRange_and_tranmissionMode = unpack( "H2", pack( "B8", $pressureRange_and_tranmissionMode ) );    # 1 byte data
        my $sensor_code_position = '7';    # nibble postion
        substr( $init_2_data_hex, $sensor_code_position, 0, $pressureRange_and_tranmissionMode );
    }

    #for PAS6s,UFS6s,PAS6f,UFS6f
    if ( exists $sensor_init_href->{HOUSING_CODE} and exists $sensor_init_href->{SAMPLE_TIME_AND_FILTER} ) {

        my $sample_time_and_housing = $sensor_init_href->{SAMPLE_TIME_AND_FILTER} . $sensor_init_href->{HOUSING_CODE};
        $sample_time_and_housing = unpack( "H2", pack( "B8", $sample_time_and_housing ) );    # 1 byte data
        my $sample_time_and_housing_position = '9';                                           # nibble postion
        substr( $init_2_data_hex, $sample_time_and_housing_position, 0, $sample_time_and_housing );
    }

    my $init_2_data_href;
    my @init_2_data   = $init_2_data_hex =~ /(..)/g;                                          # group byte wise and collect into the array
    my $size_of_init2 = scalar @init_2_data;
    foreach ( 1 .. $size_of_init2 ) {
        $init_2_data_href->{$_}{'Data_value_hex'} = '0x' . shift @init_2_data;
    }

    return $init_2_data_href;
}

=head2 Label_init2_data

    Label_init2_data ( $init_data_href, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function converts the label to hex format and returns the init 2 data in the order of labels as defined in the ManiPAS GUI.

B<Arguments:>

=over

=item $init_data_href

Init 2 configuration data

    Example: { PROTOCOL_REVISION => 4, ..}

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=back

B<Return Value:>

returns success: formatted init 2 data href.

=cut

sub Label_init2_data {
    my $init_data_href     = shift;
    my $sensor_device_name = shift;

    my $init2_data_href = Fill_init2_data( $sensor_device_name, $init_data_href );
    return unless $init2_data_href;

    foreach my $init2_label ( keys %$init2_data_href ) {
        $INIT2_LABEL_href->{$sensor_device_name}{$init2_label} = $init2_data_href->{$init2_label};
    }

    my $psi5_sensor_project_href = S_get_contents_of_hash( ['PSI5_SENSORS_PROJECT'] );

    my $sensor_type            = $psi5_sensor_project_href->{$sensor_device_name}{TYPE};
    my $sensor_type_param_href = $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type};

    return Format_init2_label_data( $INIT2_LABEL_href->{$sensor_device_name}, $sensor_type );

}

=head2 Fill_cyclic_messages

    Fill_cyclic_messages ( $cyclic_msgs_href, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function prepares the $cyclic_data_href in the bytes format as required.

B<Arguments:>

=over

=item $cyclic_msgs_href

Cyclic messages configuration.

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=back

B<Return Value:>

returns success: $cyclic_data_href.

return failure: undef.

=cut

sub Fill_cyclic_messages {

    my $cyclic_msgs_href   = shift;
    my $sensor_device_name = shift;

    my $no_of_used_bytes;
    my $cyclic_data_href = {};

    #    if ( exists $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} ) {
    #        my %localCyclicMsgs = %{ $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} };
    #        $cyclic_data_href = \%localCyclicMsgs;
    #    }

    #IF is valid sensor name and cyclic messages configured?
    #IF-YES-START
    #STEP convert the label to byte format and return the byte format ($cyclic_data_href)
    #IF-YES-END
    #IF-NO-START
    #STEP Error not valid arguments return undef
    #IF-NO-END
    #STEP END

    return unless S_checkFunctionArguments( 'Fill_cyclic_messages ( $cyclic_msgs_href, $sensor_device_name )', ( $cyclic_msgs_href, $sensor_device_name ) );

    my %local_cyclic_msgs = %$cyclic_msgs_href;
    my $msgs_href         = \%local_cyclic_msgs;
    my $valid_keys_aref   = [ 'ALL', 'NUMBER_OF_USED_BYTES', 'ABSOLUTE_PRESSURE_VALUE', 1 .. $CYCLIC_MSGS_ARRAY_SIZE ];

    # check invalid keys
    my $configured_keys_aref = [ keys %$msgs_href ];
    my $invalid_keys_aref = [ grep { !( $_ ~~ @$valid_keys_aref ) } @$configured_keys_aref ];

    if (@$invalid_keys_aref) {
        local $" = ', ';
        $valid_keys_aref = [ @$valid_keys_aref[ 0 .. 2 ] ];
        push( @$valid_keys_aref, ' <1 .. 256>' );    # only for log purpose
        S_set_error( "Fill_cyclic_messages: Keys (@$invalid_keys_aref) configured for CYCLIC_MESSAGES for sensor '$sensor_device_name' not in range, valid keys ( @$valid_keys_aref )", 109 );
        return;
    }

    if ( exists $msgs_href->{'NUMBER_OF_USED_BYTES'} ) {
        $no_of_used_bytes = $msgs_href->{'NUMBER_OF_USED_BYTES'};
        if ( $no_of_used_bytes < 1 or $no_of_used_bytes > $CYCLIC_MSGS_ARRAY_SIZE ) {
            S_set_error("Fill_cyclic_messages: The value '$no_of_used_bytes' configured for NUMBER_OF_USED_BYTES for sensor '$sensor_device_name' is not in range. Valid Range (1 .. $CYCLIC_MSGS_ARRAY_SIZE)");
            return;
        }

        delete $msgs_href->{'NUMBER_OF_USED_BYTES'};
        if ( keys %$msgs_href == 0 ) {
            $msgs_href->{'ALL'} = '0x000';
        }

    }

    #    # if not configured, but already sensor initialised, choose number of bytes as configured in init.
    elsif ( exists $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} ) {
        $no_of_used_bytes = keys %{ $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} };
    }

    else {
        $no_of_used_bytes = $CYCLIC_MSGS_ARRAY_SIZE;
    }

    my $abs_pressure_val;
    if ( exists $msgs_href->{'ABSOLUTE_PRESSURE_VALUE'} ) {
        $abs_pressure_val = $msgs_href->{'ABSOLUTE_PRESSURE_VALUE'};
        if ( $abs_pressure_val < 0 or $abs_pressure_val > $MAX_ABS_PRESSURE_VAL ) {
            S_set_error( "Fill_cyclic_messages: Absolute pressure value '$abs_pressure_val', configured for sensor '$sensor_device_name' not in range, Valid range 0 .. 4095 Po.lsb", 109 );
            return;
        }
        delete $msgs_href->{'ABSOLUTE_PRESSURE_VALUE'};

    }

    if ( exists $msgs_href->{'ALL'} ) {
        if ( ref $msgs_href->{'ALL'} eq 'HASH' ) {

            # convert byte keys to camel case
            $msgs_href = Convert_byte_keys($msgs_href);
            my %msg_hash = %{ $msgs_href->{'ALL'} };

            foreach my $byte_idx ( 1 .. $no_of_used_bytes ) {
                foreach my $cycattr ( keys %msg_hash ) {
                    $cyclic_data_href->{$byte_idx}{$cycattr} = $msg_hash{$cycattr};
                }
            }
        }
        else {
            map { $cyclic_data_href->{$_}{'Data_value_hex'} = $msgs_href->{'ALL'} } ( 1 .. $no_of_used_bytes );
        }

        $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} = $cyclic_data_href;
    }

    # byte keys configured explicitly
    if ( !exists $msgs_href->{'ALL'} ) {

        if ( keys %$msgs_href != 0 ) {

            # convert byte keys to camel case
            $msgs_href = Convert_byte_keys($msgs_href);

            if ( exists $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} ) {
                my $default_cyclic_data = $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'};

                foreach my $element ( 1 .. $no_of_used_bytes ) {
                    if ( exists $msgs_href->{$element} ) {
                        $cyclic_data_href->{$element} = $msgs_href->{$element};
                    }
                    else {
                        $cyclic_data_href->{$element} = $default_cyclic_data->{$element};
                    }
                }

                $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} = $cyclic_data_href;
            }
            else {
                $cyclic_data_href = Fill_data_array($msgs_href);
                $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} = $cyclic_data_href;
            }
        }

    }

    delete $msgs_href->{'ALL'} if ( exists $msgs_href->{'ALL'} );

    if ( defined $abs_pressure_val ) {
        my $offset_pos_pressure_val = '3';
        my $pressure_data_href = Convert_absolute_pressure_value( $abs_pressure_val, ( $no_of_used_bytes - $offset_pos_pressure_val ) );

        foreach my $pressData ( sort { $a <=> $b } keys %$pressure_data_href ) {
            $cyclic_data_href->{$pressData}{'Data_value_hex'} = $pressure_data_href->{$pressData}{'Data_value_hex'};
        }
        $CYCLIC_DATA_href->{$sensor_device_name}{'cyclic_data_href'} = $cyclic_data_href;
    }

    return $cyclic_data_href;

}

=head2 Fill_user_messages

    Fill_user_messages ( $user_msgs_href, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function prepares the $user_data_href in the bytes format as required.

B<Arguments:>

=over

=item $user_msgs_href

User messages configuration.

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=back

B<Return Value:>

returns success: $user_data_href.

return failure: undef.

=cut

sub Fill_user_messages {

    my $user_data_href     = shift;
    my $sensor_device_name = shift;

    my $num_used_bytes;
    my $user_msgs_href = {};

    #IF is valid sensor name and user messages configured?
    #IF-YES-START
    #STEP convert the label to byte format and return the byte format ($user_data_href)
    #IF-YES-END
    #IF-NO-START
    #STEP Error not valid arguments return undef
    #IF-NO-END
    #STEP END

    return unless S_checkFunctionArguments( 'Fill_user_messages ( $user_data_href, $sensor_device_name )', ( $user_data_href, $sensor_device_name ) );

    my %local_user_msgs = %$user_data_href;
    my $msgs_href       = \%local_user_msgs;

    my $valid_keys_aref = [ 'ALL', 'NUMBER_OF_USED_BYTES', 1 .. $USER_MSGS_ARRAY_SIZE ];

    # check invalid keys
    my $configured_keys_aref = [ keys %$msgs_href ];
    my $invalid_keys_aref = [ grep { !( $_ ~~ @$valid_keys_aref ) } @$configured_keys_aref ];

    if (@$invalid_keys_aref) {
        local $" = ', ';
        $valid_keys_aref = [ @$valid_keys_aref[ 0 .. 1 ] ];
        push( @$valid_keys_aref, ' <1 .. 16>' );    # only for log purpose
        S_set_error( "Fill_user_messages: Keys (@$invalid_keys_aref) configured for USER_MESSAGES for sensor '$sensor_device_name' not in range, valid keys ( @$valid_keys_aref )", 109 );
        return;
    }

    if ( exists $msgs_href->{'NUMBER_OF_USED_BYTES'} ) {
        $num_used_bytes = $msgs_href->{'NUMBER_OF_USED_BYTES'};
        if ( $num_used_bytes < 1 or $num_used_bytes > $USER_MSGS_ARRAY_SIZE ) {
            S_set_error("Fill_user_messages: The value '$num_used_bytes' configured for NUMBER_OF_USED_BYTES for sensor '$sensor_device_name' is not in range. Valid Range (1 .. $USER_MSGS_ARRAY_SIZE)");
            return;
        }
        delete $msgs_href->{'NUMBER_OF_USED_BYTES'};
        if ( keys %$msgs_href == 0 ) {
            $msgs_href->{'ALL'} = '0x000';
        }
    }

    # if not configured, but already sensor initialised, choose number of bytes as configured in init.
    elsif ( exists $USER_DATA_href->{$sensor_device_name}{'user_data_href'} ) {
        $num_used_bytes = keys %{ $USER_DATA_href->{$sensor_device_name}{'user_data_href'} };
    }

    else {
        $num_used_bytes = $USER_MSGS_ARRAY_SIZE;
    }

    my $pas_line_num_int = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'pas_line_num_int'};
    my $time_slot_int    = $ALL_SENSORS_INIT_href->{$sensor_device_name}{'time_slot_int'};

    if ( exists $msgs_href->{'ALL'} ) {

        if ( ref $msgs_href->{'ALL'} eq 'HASH' ) {
            $msgs_href = Convert_byte_keys($msgs_href);

            my %msg_hash = %{ $msgs_href->{'ALL'} };

            foreach my $byte_idx ( 1 .. $num_used_bytes ) {
                foreach my $userattr ( keys %msg_hash ) {
                    $user_msgs_href->{$byte_idx}{$userattr} = $msg_hash{$userattr};
                }
            }
        }
        else {
            map { $user_msgs_href->{$_}{'Data_value_hex'} = $msgs_href->{'ALL'} } ( 1 .. $num_used_bytes );
        }
        delete $msgs_href->{'ALL'};
        $USER_DATA_href->{$sensor_device_name}{'user_data_href'} = $user_msgs_href;
    }
    else {

        if ( keys %$msgs_href != 0 ) {

            $msgs_href = Convert_byte_keys($msgs_href);

            if ( exists $USER_DATA_href->{$sensor_device_name}{'user_data_href'} ) {
                my $default_user_data = $USER_DATA_href->{$sensor_device_name}{'user_data_href'};
                foreach my $element ( 1 .. $num_used_bytes ) {
                    if ( exists $msgs_href->{$element} ) {
                        $user_msgs_href->{$element} = $msgs_href->{$element};
                    }
                    else {
                        $user_msgs_href->{$element} = $default_user_data->{$element};
                    }
                }
                $USER_DATA_href->{$sensor_device_name}{'user_data_href'} = $user_msgs_href;
            }
            else {
                $user_msgs_href = Fill_data_array($msgs_href);
                $USER_DATA_href->{$sensor_device_name}{'user_data_href'} = $user_msgs_href;
            }
        }
    }
    return $user_msgs_href;
}

=head2 Init2_hex_to_labels

    Init2_hex_to_labels ( $sensor_type_str, $sensor_device_name, $init2_config_str )

B<NON EXPORTED FUNCTION>

This function converts the hex values to string labels.

B<Arguments:>

=over

=item $sensor_type_str

Type of the sensor.

=item $sensor_device_name

Sensor type e.g 'UFSD', 'PTSD', ...

=item $init2_config_str

Init2 data in hex string format.

=back

B<Return Value:>

returns success: $init2_data_href.

return failure: undef.

=cut

sub Init2_hex_to_labels {

    my $sensor_type_str        = shift;
    my $sensor_device_name     = shift;
    my $init2_config_str       = shift;
    my $init2_data_href        = {};
    my $sensor_attr_label_href = $INIT2_DATA_SENSOR_CONFIG_MAPPING->{$sensor_type_str};
    my @nibble_pos             = sort { $a <=> $b } values %$sensor_attr_label_href;
    my @attribute_lengths      = ();

    # collect attribute lengths from INIT2_DATA_SENSOR_CONFIG_MAPPING hash ref
    foreach my $nibble ( 0 .. ( @nibble_pos - 1 ) ) {
        if ( exists $nibble_pos[ $nibble + 1 ] ) {
            push( @attribute_lengths, $nibble_pos[ $nibble + 1 ] - $nibble_pos[$nibble] );
        }
        else {
            push( @attribute_lengths, 12 );    # byte position 11(index starting from 0) for series number
        }
    }

    foreach my $attribute ( sort { $sensor_attr_label_href->{$a} <=> $sensor_attr_label_href->{$b} } keys %$sensor_attr_label_href ) {
        my $start_nibble_pos = $sensor_attr_label_href->{$attribute};
        $init2_data_href->{$attribute} = substr( $init2_config_str, $start_nibble_pos, shift @attribute_lengths );
        $INIT2_LABEL_href->{$sensor_device_name}{$attribute} = $init2_data_href->{$attribute};
    }
    my ( $sensor_code_value_bin, $housing_code_bin, $pressure_range_val_bin, $pressure_tranmsission_mode_bin ) = ( 0, 0, 0, 0 );

    # perform merging of binary data returned from labels in order to get hex string
    # for sensor types PAS6_PAS6e_UFS6_UFS6e_PAS5_UFS3_UFS3R_PAS5R

    # URL for status data content table for PAS6e, UFS6e
    # https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-252-0003c520?doors.view=00000004

    if ( defined $init2_data_href->{'SENSOR_CODE'} and defined $init2_data_href->{'HOUSING_CODE'} ) {
        my $sensor_code_hex = $init2_data_href->{'SENSOR_CODE'};
        $sensor_code_value_bin = sprintf( "%.4b", hex $sensor_code_hex );

        my $housing_code_hex = $init2_data_href->{'HOUSING_CODE'};
        $housing_code_bin = sprintf( "%.4b", hex $housing_code_hex );
        $housing_code_bin = substr( $sensor_code_value_bin, 2, 2 ) . $housing_code_bin;

        $sensor_code_value_bin = substr( $sensor_code_value_bin, 0, 2 );
        $init2_data_href->{'HOUSING_CODE'}                       = $housing_code_bin;
        $init2_data_href->{'SENSOR_CODE'}                        = $sensor_code_value_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'HOUSING_CODE'} = $housing_code_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'SENSOR_CODE'}  = $sensor_code_value_bin;
    }

    # URL for status data content table for PPS3e and PTS1e
    # https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-956-0003c52b

    # URL for Sensor mode and psi5 mode data content description
    # https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-1182-0003c52b

    if ( defined $init2_data_href->{'SENSOR_MODE'} and defined $init2_data_href->{'PSI5_MODE'} ) {
        my $pressure_range_hex = $init2_data_href->{'SENSOR_MODE'};
        $pressure_range_val_bin = substr( sprintf( "%.4b", hex $pressure_range_hex ), 0, 3 );         # bit 0 to 2 from MSB contains the SENSOR MODE
        $pressure_tranmsission_mode_bin = substr( sprintf( "%.4b", hex $pressure_range_hex ), 3 );    # bit 3 in SENSOR MODE nibble and PSI5 MODE complete nibble provides PSI5 mode data
        my $pressure_tranmsission_mode_hex = $init2_data_href->{'PSI5_MODE'};
        $pressure_tranmsission_mode_bin = $pressure_tranmsission_mode_bin . sprintf( "%.4b", hex $pressure_tranmsission_mode_hex );
        $init2_data_href->{'SENSOR_MODE'}                       = $pressure_range_val_bin;
        $init2_data_href->{'PSI5_MODE'}                         = $pressure_tranmsission_mode_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'SENSOR_MODE'} = $pressure_range_val_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'PSI5_MODE'}   = $pressure_tranmsission_mode_bin;
    }

    # for sensor types PAS6s, UFS6f, PAS6f, UFS6f
    if ( defined $init2_data_href->{'SAMPLE_TIME_AND_FILTER'} and defined $init2_data_href->{'HOUSING_CODE'} ) {
        my $sampleTimeFilter_hex = $init2_data_href->{'SAMPLE_TIME_AND_FILTER'};
        my $sampleTimeFilter_bin = sprintf( "%.4b", hex $sampleTimeFilter_hex );

        my $housing_code_hex = $init2_data_href->{'HOUSING_CODE'};
        $housing_code_bin = sprintf( "%.4b", hex $housing_code_hex );
        $housing_code_bin = substr( $sampleTimeFilter_bin, 2, 2 ) . $housing_code_bin;

        $sampleTimeFilter_bin = substr( $sampleTimeFilter_bin, 0, 2 );
        $init2_data_href->{'HOUSING_CODE'}                                 = $housing_code_bin;
        $init2_data_href->{'SAMPLE_TIME_AND_FILTER'}                       = $sampleTimeFilter_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'HOUSING_CODE'}           = $housing_code_bin;
        $INIT2_LABEL_href->{$sensor_device_name}{'SAMPLE_TIME_AND_FILTER'} = $sampleTimeFilter_bin;
    }

    my $label_data_dump = Dumper($init2_data_href);
    S_w2log( 5, " Data dump for debugging : $label_data_dump" );

    return $init2_data_href;
}

=head2 PrintSensorCode

    PrintSensorCode ( $sensor_attribute, $sens_attribute_mapping, $table_SensorAttrib_value_labels )

B<NON EXPORTED FUNCTION>

This function fills the html text for the sensor code attribute of int2 data

B<Arguments:>

=over

=item $sensor_attribute

sensor attribute is sensor code.

=item $sens_attribute_mapping

Sensor attribute mapping which contains the sensor labels

=item $table_SensorAttrib_value_labels

object of the html table to be printed

=back

B<Return Value:>

returns success: $table_SensorAttrib_value_labels with details added for sensor code.

return failure: undef.

=cut

sub PrintSensorCode {

    my $sensor_attribute                = shift;
    my $sens_attribute_mapping          = shift;
    my $table_SensorAttrib_value_labels = shift;

    my $used_value;
    my ( $pas5_3_flag, $pas6_flag, $pas6e_flag ) = ( 0, 0, 0 );
    foreach my $sensor_value_label ( sort keys %$sens_attribute_mapping ) {
        $used_value = $sens_attribute_mapping->{$sensor_value_label};

        if ( $sensor_value_label =~ /PAS5|PAS5R|UFS3|UFS3R/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'SENSOR_CODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PAS5 or PAS5R or UFS3 or UFS3R)' ] ) unless ( $pas5_3_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pas5_3_flag = 1;
        }
        if ( $sensor_value_label =~ /^PAS6_/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'SENSOR_CODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PAS6 or UFS6)' ] ) unless ( $pas6_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pas6_flag = 1;
        }
        if ( $sensor_value_label =~ /^PAS6e_/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'SENSOR_CODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PAS6e or UFS6e)' ] ) unless ( $pas6e_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pas6e_flag = 1;
        }
        $used_value = "NO VALUE SET" unless defined $used_value;
    }
    return 1;
}

=head2 PrintTransmissionMode

    PrintTransmissionMode ( $sensor_attribute, $sens_attribute_mapping, $table_SensorAttrib_value_labels )

B<NON EXPORTED FUNCTION>

This function fills the html text for the sensor code attribute of int2 data

B<Arguments:>

=over

=item $sensor_attribute

sensor attribute is transmission mode.

=item $sens_attribute_mapping

Sensor attribute mapping which contains the transmission labels

=item $table_SensorAttrib_value_labels

object of the html table to be printed

=back

B<Return Value:>

returns success: $table_SensorAttrib_value_labels with details added for sensor code.

return failure: undef.

=cut

sub PrintTransmissionMode {

    my $sensor_attribute                = shift;
    my $sens_attribute_mapping          = shift;
    my $table_SensorAttrib_value_labels = shift;

    my $used_value;
    my ( $pps3_flag, $pps2_flag, $pts1_flag ) = ( 0, 0, 0 );
    foreach my $sensor_value_label ( sort keys %$sens_attribute_mapping ) {
        $used_value = $sens_attribute_mapping->{$sensor_value_label};

        if ( $sensor_value_label =~ /PPS3_/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'TRANSMISSION_MODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PPS3)' ] ) unless ( $pps3_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pps3_flag = 1;
        }
        if ( $sensor_value_label =~ /^PPS2/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'TRANSMISSION_MODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PPS2)' ] ) unless ( $pps2_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pps2_flag = 1;
        }
        if ( $sensor_value_label =~ /^PTS1/i ) {
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ 'TRANSMISSION_MODE ATTRIBUTES FOR SENSOR TYPES -> ', '(PTS1)' ] ) unless ( $pts1_flag == 1 );
            S_TableAddRow( $table_SensorAttrib_value_labels->{$sensor_attribute}, [ $sensor_value_label, $used_value ], );
            $pts1_flag = 1;
        }
        $used_value = "NO VALUE SET" unless defined $used_value;
    }
    return 1;
}

=head2 Pas6sf_generation_bit

    Pas6sf_generation_bit ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for PAS6sf_GENERATION_BIT to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, PAS6sf_GENERATION_BIT => 'PAS6' }

=item $init2_attribute

Init 2 attribute configured 'PAS6sf_GENERATION_BIT'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for PAS6sf_GENERATION_BIT.

return failure: undef 

=cut

sub Pas6sf_generation_bit {
    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $generation_bit = $init2_config_href->{$init2_attribute};

    unless ( exists( $PAS6sf_GENERATION_BIT{$generation_bit} ) ) {
        my $valid_generation_aref = [];
        @$valid_generation_aref = keys %PAS6sf_GENERATION_BIT;
        local $" = ',';
        S_set_error( "Pas6sf_generation_bit: Generation bit '$generation_bit' for sensor '$sensor_device_name' not supported, valid range (@$valid_generation_aref)", 109 );
        return;
    }
    my $genvalue = $PAS6sf_GENERATION_BIT{$generation_bit};
    $genvalue =~ s/^0x//i;
    return ($genvalue);
}

=head2 Sample_time_and_filter

    Sample_time_and_filter ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for SAMPLE_TIME_AND_FILTER to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, SAMPLE_TIME_AND_FILTER => 'BOSCH' }

=item $init2_attribute

Init 2 attribute configured 'SAMPLE_TIME_AND_FILTER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for SAMPLE_TIME_AND_FILTER.

return failure: undef 

=cut

sub Sample_time_and_filter {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $sample_time_and_filter = $init2_config_href->{$init2_attribute};

    unless ( exists( $SAMPLE_TIME_AND_FILTER{$sample_time_and_filter} ) ) {
        my @valid_keys = keys %SAMPLE_TIME_AND_FILTER;
        S_set_error(
            "Sample_time_and_filter: Sample time and filter '$sample_time_and_filter' for sensor '$sensor_device_name' not supported
        Valid range @valid_keys", 109
        );
        return;
    }
    my $value = $SAMPLE_TIME_AND_FILTER{$sample_time_and_filter};
    my $value_bin = sprintf( "%.2b", $value );
    return ($value_bin);
}

=head2 Validate_filter_and_dependent_params_for_pas6sf_and_ufs6sf

    Validate_filter_and_dependent_params_for_pas6sf_and_ufs6sf ( $init2_config_mix, $sensor_type_str, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates parameter SAMPLE_TIME_AND_FILTER and ACCELERATION_AXIS_AND_FILTER.

both should have same filter configuration.

B<Arguments:>

=over

=item $init2_config_mix

Init 2 configuration data 

    Example: { ACCELERATION_AXIS_AND_FILTER => 4, SAMPLE_TIME_AND_FILTER => 'BOSCH' }

=item $sensor_type_str

Only for sensor device types PAS6s, UFS6s, PAS6f, UFS6f

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: 1.

return failure: undef 

=cut

sub Validate_filter_and_dependent_params_for_pas6sf_and_ufs6sf {
    my $init2_config_mix   = shift;
    my $sensor_type_str    = shift;
    my $sensor_device_name = shift;

    if ( $sensor_type_str =~ /PAS6s|UFS6s|PAS6f|UFS6f/i ) {
        if ( exists $init2_config_mix->{ACCELERATION_AXIS_AND_FILTER} or exists $init2_config_mix->{SAMPLE_TIME_AND_FILTER} ) {
            if ( not defined $init2_config_mix->{ACCELERATION_AXIS_AND_FILTER} or not defined $init2_config_mix->{SAMPLE_TIME_AND_FILTER} ) {
                S_set_error( "Fill_init2_data: For sensor '$sensor_device_name' both parameters 'ACCELERATION_AXIS_AND_FILTER' and 'SAMPLE_TIME_AND_FILTER' needs to be set as they are interdependent", 109 );
                return;
            }
            if ( defined $init2_config_mix->{ACCELERATION_AXIS_AND_FILTER} and $init2_config_mix->{SAMPLE_TIME_AND_FILTER} ) {

                #check both have same filters are not
                my $acc_axis_fltr    = $init2_config_mix->{ACCELERATION_AXIS_AND_FILTER};
                my $sample_time_fltr = $init2_config_mix->{SAMPLE_TIME_AND_FILTER};
                $acc_axis_fltr =~ s/(.*)(FILTER.*)/$2/;
                $sample_time_fltr =~ s/(.*)(FILTER.*)/$2/;
                if ( $acc_axis_fltr ne $sample_time_fltr ) {
                    S_set_error(
                        "Fill_init2_data: Filter values of both parameters 'ACCELERATION_AXIS_AND_FILTER' and 
                            'SAMPLE_TIME_AND_FILTER' needs to be same as they are interdependent configured values '$init2_config_mix->{ACCELERATION_AXIS_AND_FILTER} and '$init2_config_mix->{SAMPLE_TIME_AND_FILTER}'", 109
                    );
                    return;
                }

            }
        }
    }
    return 1;
}

=head2 Acceleration_axis_and_filter

    Acceleration_axis_and_filter ( $init2_config_href, $init2_attribute, $sensor_device_name )

B<NON EXPORTED FUNCTION>

This function validates and converts the label configured for ACCELERATION_AXIS_AND_FILTER to hex value.

B<Arguments:>

=over

=item $init2_config_href

Init 2 configuration data 

    Example: { PROTOCOL_REVISION => 4, ACCELERATION_AXIS_AND_FILTER => 'BOSCH' }

=item $init2_attribute

Init 2 attribute configured 'ACCELERATION_AXIS_AND_FILTER'

=item $sensor_device_name

Sensor device name configured. e.g 'UFSD', 'PTSD'

=back

B<Return Value:>

return success: hex value of label configured for ACCELERATION_AXIS_AND_FILTER.

return failure: undef 

=cut

sub Acceleration_axis_and_filter {

    my $init2_config_href  = shift;
    my $init2_attribute    = shift;
    my $sensor_device_name = shift;

    my $acceleration_axis_and_filter = $init2_config_href->{$init2_attribute};

    unless ( exists( $ACCELERATION_AXIS_AND_FILTER{$acceleration_axis_and_filter} ) ) {
        S_set_error( "Acceleration_axis_and_filter: Acceleration axis and filter '$acceleration_axis_and_filter' for sensor '$sensor_device_name' not supported", 109 );
        return;
    }
    my $value = $ACCELERATION_AXIS_AND_FILTER{$acceleration_axis_and_filter};
    $value =~ s/^0x//i;
    return ($value);
}

1;

