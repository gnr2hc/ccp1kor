# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_can_access;

use strict;
use LIFT_general;
use LIFT_equipment;
use LIFT_vector_cantool;
use LIFT_vector_canstress;
use LIFT_CANoe;
use LIFT_CANoeCtrl;
use Readonly;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY

@ISA    = qw(Exporter);
@EXPORT = qw(
  CA_init
  
  CA_stimulate_configure
  CA_stimulate_reset_signal_curves
  CA_stimulate_load_signal_curves
  CA_stimulate_load_timed_signals
  CA_stimulate_start_now
  CA_stimulate_start_with_external_trigger
  
  CA_read_configure
  CA_read_can_signal
  CA_write_configure
  CA_write_can_signal
  CA_disable_message
  CA_enable_message
  CA_set_DLC
  CA_reset_DLC

  CA_trace_configure
  CA_trace_start
  CA_trace_stop
  CA_simulation_start
  CA_simulation_stop

  CA_trace_check_running
  CA_trace_store
  CA_trace_get_dataref
    
  CA_set_EnvVar_value
  CA_get_EnvVar_value
  CA_set_SysVar_value
  CA_get_SysVar_value
  
  CA_CAPL_config
  CA_CAPL_invoke

  CA_get_can_signal_info
  CA_get_can_message_info
  CA_calc_hex_to_phys
  CA_calc_phys_to_hex
  CA_set_invalidCRC
  CA_set_validCRC
  CA_set_invalidBZ
  CA_set_validBZ
  CA_trace_get_PD_responses
  );    # export subs

my $CA_control;

####################################################

=head1 NAME

LIFT_can_access  

=head1 SYNOPSIS

    use LIFT_can_access;
    
    CA_init

    CA_read_configure
    CA_read_can_signal

    CA_write_configure
    CA_write_can_signal

    CA_disable_message
    CA_enable_message

    CA_set_DLC
    CA_reset_DLC

    CA_trace_configure
    CA_trace_start
    CA_trace_stop
    CA_trace_reset    ( not implemented yet ; might be included in CA_trace_store )
    CA_trace_check_running
    CA_trace_store
    CA_trace_get_dataref
    
    CA_simulation_start
    CA_simulation_stop

    CA_CAPL_config
    CA_CAPL_invoke
  
    CA_get_can_signal_info
    CA_get_can_message_info

    CA_calc_hex_to_phys
    CA_calc_phys_to_hex

    CA_set_invalidCRC
    CA_set_validCRC

    CA_set_invalidBZ
    CA_set_validBZ

    CA_trace_get_PD_responses
    
    CA_logging_start
    CA_logging_stop

=cut

=head1 DESCRIPTION

This module controls the CANoe application and provides below functionalities  :
 
=over 3

=item * start & stop RBS with or without trace logging 

=item * read CAN signals

=item * write CAN signals

=item * stimulation of CAN signals

=item * set & get Environment variables.

=item * set & get system variables.

=item * to Enable & Disbale CAN message.

=item * to reset & set DLC.

=item * to set valid & invalid CRC.

=item * to set valid & invalid BZ.

=item * get the copy of CANoe Trace if logged by CANoe.

=item * get the content of CANoe trace into a data structure for Evaluation.

=item * call user written CAPL functions .
 
=back



=head2 Prerequisites

In order to work with this module following are recommended :  

=over 3

=item * to have basic knowledge of CAN protocol refer :

=for html
<a href='https://elearning.vector.com/vl_can_introduction_en.html'>vector CAN e-training</a>

=item * basic knowledge of CANoe (for eg. compiling of .cfg file, editing some CAPL program, creating Environment variables in dbc file etc.)

=item * L</"CAN mapping">.

=back

=cut



=head2 Testbench configuration

=head3 Devices section:

    'Devices' => {
        ... 
        'CANoe' => {
            'Hostname'                       => 'BMH1045912',
            'Online_Config'                  => 'C:\TurboLIFT\Engine\test\CANoe\LIFT_CAN_access\COMDemo.cfg',
            'Log_File'                       => 'C:\temp\CANOE_log.asc',
            'ILUsed'                         => 'Yes',  # Option : 'Yes' if Interaction layer used , otherwise 'No'
            'OldSignalFactorOffsetHandling'  => 'No',   # Option : 'Yes' if old handling of factor offset calculation for signal has to be considered , otherwise 'No'
            'OldEnableDisableHandling'       => 'No',   # Option : 'Yes' if old handling of enabling and disabling has to be considered , otherwise 'No'
            'Keep_Application_After_Test'    => 1, 
            'Create_Local_Config_Copy'       => 1, 
            'Max_Stimulate_Signals'          => 200,    # Optional, supported values are 200 and 400, 200 if not defined
        },
        ...
      },

B<'Hostname':> It is recommended to have Canoe running on the same host as TurboLIFT. 
If really needed then Canoe can also run on a different host, but then the handling of log files is more difficult.

B<'Online_Config':> Path B<on 'Hostname'> to the .cfg file to be loaded.

B<'Log_File':> Path B<on TurboLIFT host> to the log file that is configured in the defined .cfg file (see 'Online_Config').

B<'ILUsed':> (optional) Option if B<Interaction layer> was supported by the B<CANoe config> 'Online_Config' . If B<not given> then considered as B<NO>. 

B<'OldSignalFactorOffsetHandling':> (optional) Option B<YES> if B<Old handling of factor Offset calculation for signal> is to be considered . If B<not given> then considered as B<NO>.  

B<'OldEnableDisableHandling':> (optional) Option B<YES> if B<Old handling of enabling and disabling is to be considered . If B<not given> then considered as B<NO>.  

B<'Keep_Application_After_Test':> (optional) If set to 1 then Canoe will stay open after test. 
By default Canoe will be closed after the test.

B<'Create_Local_Config_Copy':> (optional) If set to 1 then the path defined in 'Online_Config' is taken B<on TurboLIFT host> 
and the .cfg file there is copied to 'Hostname' C:\temp. From there it is then loaded by Canoe. 
Makes only sense if 'Hostname' is not the TurboLIFT host.

B<'Max_Stimulate_Signals':> (optional) If set to 400 then the value of max stimulate signals will be increased to 400. If not set then 200 shall be the value of
max stimulate signals. Supported are only two values now (200 and 400).


=head3 Functions section:

    'Functions' => {
        ...
        'CAN_Access' => {
           'basic'     =>  'CANoe',     # function groups: read, write, trace, simulation
           'stimulate' => 'CANoe',  # function group stimulate
        },
        ...  
    },

For backwards compatibility the old way of function configuration is also supported, 
but only for the function groups read, write and trace:

    'CAN_Access' => {
       'read' =>  [ 'CANoe' ],
       'write' => [ 'CANoe' ],
       'trace' => [ 'CANoe' ],
    },

=head2 CAN mapping

Many functions of this module need a CAN mapping file that provides information about IDs of messages and bit and byte positions of signals.
The CAN mapping file can be generated from the .dbc file that defines the rest bus simulation. 
To do this there is a CAN mapping file generator tool (with GUI) available: 

    <path to your TurboLIFT sandboxes>\Tools\Mappingfile_Generators\CANMapping\LIFT_prepare_CAN_mapping.pl

The generated CAN mapping file should be copied to the "config" folder of your TurboLIFT project and 
in the main config file (..._CFG.pm) the CAN mapping file must be loaded, e.g. like this:

    require "$LIFT_PRJCFG_path/Mapping_CAN.pm"     if ( -f "$LIFT_PRJCFG_path/Mapping_CAN.pm" );

=head2 Tutorials

Please refer below tutorials for better understanding of this module.

=over 3

=item *
  
=for html
<a href='https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Dynamic%20stimulation%20of%20CAN%20signals'>Dynamic stimulation of CAN signals</a> 

=> for the L</"Function Group 'stimulate'">. 


=item *
  
=for html
<a href='https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/Control%20CANoe%20Trace%20logging'>Control CANoe Trace logging</a> 

=> for Start/Stop Logging functionality which uses L</"Function Group 'simulation'"> and L</"Function Group 'trace'">
 
=item *
  
=for html
<a href='https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/CANoe%20IL%20%28CANoe%20Interaction%20Layer%29'>CANoe IL (CANoe Interaction Layer)</a> 

=> for writing can signals which uses L</"Function Group 'write'">


=back

=cut

=head1 Function Group 'read'


=cut


=head2 CA_read_configure

    $returnValue = CA_read_configure( );

It configures the CAN tool 'CANoe' so that CAN signals can be read (after start of measurement ). Refer testbench config  L</"Functions section:"> function group basic.

=over

=item Arugments : None

=item $returnValue

1 :: Successful and offline, undef :: Failure

=back

B<Examples:>

    $returnValue = CA_read_configure();    

B<Notes:> 

This function was called internally by B<EQUIP_init_testbench>. So no need to call this funciton if already EQUIP_init_testbench in called in IC.

=cut

sub CA_read_configure {
    my ( @devices, $ole_handle, @device_error );

    S_w2log( 4, "CA_read_configure: Reads the can access configuration \n" );

    return 1 if ($main::opt_offline);    # return 1 in offline

    @devices = EQUIP_get_devices( 'CAN_Access', 'read' );

    $CA_control->{'read'}{'Devices'} = [];

    unless ( scalar @devices ) {
        S_set_error( " CA_read_configure : LIFT_Testbenches does not contain Devices for reading CAN signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_read_configure : LIFT_Testbenches doesnt contain valid devices for reading CAN signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {
            if ( $ole_handle = VEC_read_can_configure($device) ) {
                S_w2log( 3, " CA_read_configure : device $device read configured \n" );
                push( @{ $CA_control->{'read'}{'Devices'} }, $device );
                $CA_control->{'read'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;    #ask christian - after configuring one device, we shall return ???
            }
            else {
                S_set_error( " CA_read_configure : Could not configure $device for reading CAN signals\n", 131 );
                return 0;
            }
        }
    }

    return 1;
}

######################################################################

=head2 CA_read_can_signal

    $returnValue = CA_read_can_signal( $can_signal_name, [, $mode] );   

Reads CAN signal value (phys or hex) from CAN tool 'CANoe' while measurement was running.

B<Arguments:>

=over

=item $can_signal_name 

signal name of the CAN , same as defined in CAN mapping file.

=item phys/hex  

(optional) Mode of the CAN signal. Default is 'phys' if not given.

=back

B<Return Value:>

=item $returnValue 

Value - either Physical value or Hex value depending on mode.
Unit  - unit of the signal defined in Mapping file(returns only in case of phys mode).

(Value, Unit)  : Successful

(1, undef)     : Offline

(undef, undef) : Failure

=back

B<Examples:>
    
    my $can_signal = 'SigStimulus1_CAN';
    ( $sigvalue_phy, $unit ) = CA_read_can_signal( $can_signal);
    ( $sigvalue_phy, $unit ) = CA_read_can_signal( $can_signal,  'phys' );

    # no unit in Hex mode, $unit will be undef
    ( $sigvalue_hex, $unit ) = CA_read_can_signal( $can_signal, 'hex' );  

B<Notes1:>

CA_read_configure() shall be called before this to do the configuration as specified in section L</"Devices section:">, and L</"Functions section:">.  

CANoe meaurement must be running (CA_trace_start() or CA_simulation_start()) then only CAN signal can be read.  

B<Note2:>

Based on whether the old handling of factor and offset calculation has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldSignalFactorOffsetHandling'>  :
  
= B<'Yes'> Uses the old implementation of factor offset calculation for signals.

= B<'No'> Uses the correct(new) implementation of factor and offset calculation for signals. 

=cut

sub CA_read_can_signal {

    ## DESIGN #######
    
    #COMMENT-START
        # get arguments 
        # - $can_signal,
        # - $mode (optional)
    #COMMENT-END

    # STEP set default $mode = phys if not given    
    # IF $mode = either phys or Hex ?
    # IF-NO-START
        # STEP set read value = undef & set Error - '$mode' neither phys or hex (raw).
    # IF-NO-END
    # IF-YES-START
         # IF execution mode?
             # IF-OFFLINE-START
                # STEP success case of phys mode - (return read value = 1 and unit = dummy)
             # IF-OFFLINE-END
             # IF-ONLINE-START
                # STEP check if device was configured or not ?
                # IF Device type ? 
                    #IF-CANoe-START
                        #COMMENT-START
                           # argument : -oleHandle, -$can_signal, -$mode
                           # return :
                           #   1. $readvalue (raw or phys)
                           #   2. ($unit for phys, undef for raw)
                        #COMMENT-END
                        # CALL VEC_read_can_signal
                    #IF-CANoe-END
                    #IF-NOT_CANoe-START
                      # STEP set read value = undef & set Error - Device type not CANoe.
                    #IF-NOT_CANoe-END                
             # IF-ONLINE-END             
    # IF-YES-END
    
    # STEP return read value

    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_read_can_signal ($can_signal_name [, $mode] )', @args );

    my $can_signal_name = shift @args;
    my $mode            = shift @args;

    S_w2log( 4, " CA_read_can_signal: Reads the can signal $can_signal_name for mode $mode\n" );
    my ( $dev, $value, $unit, $device );

    unless ( defined $mode ) {
        S_w2log( 4, " CA_read_can_signal : no mode (phys/hex) given , set to 'phys' per default )\n" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( "CA_read_can_signal : Invalid params ! mode shall be either 'phys' or 'hex'\n )", 114 );
        return ( undef, undef );
    }

    return ( 1, undef ) if $main::opt_offline;    # just return if running in offline mode

    unless ( $device = $CA_control->{'read'}{'Devices'}[0] ) {
        S_set_error( " no CAN access read configured , CA_read_can_signal is calling CA_read_configure ... ", 0 );
        unless ( CA_read_configure() ) {
            S_set_error( " Could not configure devices for CAN access read ", 131 );
            return ( undef, undef );
        }
    }

    foreach my $dev ( @{ $CA_control->{'read'}{'Devices'} } ) {
        if ( $dev eq "CANoe" ) {

            ( $value, $unit ) = VEC_read_can_signal( $CA_control->{'read'}{$dev}{'OLE_handle'}, $can_signal_name, $mode );
            
            S_w2log( 3, " CA_read_can_signal : $can_signal_name = $value , unit = $unit for mode = $mode \n" );
            return ( $value, $unit );
        }
            else {
                S_set_error( " CA_read_can_signal : Could not read '$can_signal_name' from $dev\n", 131 );
                return ( undef, undef );
            }
        }
    }

######################################################################

=head1 Function Group 'write'


=cut


######################################################################

=head2 CA_write_configure

    $returnValue = CA_write_configure( );

It configures the CAN tool 'CANoe' so that CAN signals can be written (after start of measurement). Refer testbench config  L</"Functions section:"> function group basic.

=over

=item Arugments : None

=item $returnValue 

1 :: Successful and offline, undef :: Failure

=back

B<Examples:>

    $returnValue = CA_write_configure();    

B<Notes:> 

This function was called internally by B<EQUIP_init_testbench>. So no need to call this funciton if already EQUIP_init_testbench in called in IC.

=cut

sub CA_write_configure {
    my ( @devices, $ole_handle, @device_error );

    S_w2log( 4, "CA_write_configure: prepare CAN tool to write signals immediately \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    @devices = EQUIP_get_devices( 'CAN_Access', 'write' );

    $CA_control->{'write'}{'Devices'} = [];

    unless ( scalar @devices ) {
        S_set_error( " CA_write_configure : LIFT_Testbenches does not contain Devices for writing CAN signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_write_configure : LIFT_Testbenches doesnt contain valid devices for writing CAN signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {
            if ( $ole_handle = VEC_write_can_configure($device) ) {
                S_w2log( 3, " CA_write_configure : device $device write configured \n" );
                push( @{ $CA_control->{'write'}{'Devices'} }, $device );
                $CA_control->{'write'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;    #ask christian - after configuring one device, we shall return ???
            }
            else {
                S_set_error( " CA_write_configure : Could not configure $device for writing CAN signals\n", 131 );
                return 0;
            }
        }
    }

    return 1;
}



######################################################################


=head2 CA_write_can_signal
    
    $returnValue = CA_write_can_signal ( $given_can_signal_name , $signal_value [,$mode ] );

Writes the given value of a CAN signal to the CANoe.

CA_write_configure() shall be called before this to do the configuration as specified in section L</"Devices section:">, and L</"Functions section:">.

B<Arguments:>

=over

=item $given_can_signal_name 

CAN signal name for which value to be set. Must be same as in CAN mapping. Refer section L</"CAN mapping">. 

=item $signal_value 

signal value to be written in CANoe. 

=item $mode 

(optional) phys | hex : Mode of writing CAN signal to CAN tool. Case insensitive(default mode : phys)

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful and in offline

undef : Failure

=back

B<Examples:> 
  
    $status = CA_write_can_signal ("SigStimulus1_CAN" , '80');
    $status = CA_write_can_signal ("SigStimulus1_CAN" , '80', 'phys');
    $status = CA_write_can_signal ("SigStimulus1_CAN" , '0x50', 'Hex');
    
B<Note1:>

Based on the Interaction layer L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'ILUsed'>  :
  
= B<'Yes'> set the $signal_value directly to the signal object in CANoe. No intermediate Environment variable or system variable required.

= B<'No'> set the $signal_value to the Environment or System variable. And in CAPL tester has to map System / Envrironment value to the Signal. 

B<Note2:>

Based on whether the old handling of factor and offset calculation has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldSignalFactorOffsetHandling'>  :
  
= B<'Yes'> Uses the old implementation of factor offset calculation for signals.

= B<'No'> Uses the correct(new) implementation of factor and offset calculation for signals. 

=cut

sub CA_write_can_signal {

    ## DESIGN 
    
    # COMMENT-START
       # Get arguments 
       #  - $given_can_signal, 
       #  - $can_signal_value, 
       #  - $mode (optional)
    # COMMENT-END
    
    # STEP set default $mode = 'phys' if not defined
    # IF $mode = either phys or Hex ?
        # IF-NO-START
            # STEP writing status = undef and set Error - mode neither phys or hex (raw).
        # IF-NO-END
        
        # IF-YES-START
            # IF execution mode?
                # IF-OFFLINE-START
                    # STEP success case of phys mode - (return write = 1)
                # IF-OFFLINE-END
                
                # IF-ONLINE-START
                    # STEP check if device was configured or not ?                        
                        # IF Device type ? 
                           #IF-NOT_CANoe-START
                               # STEP write status = undef & set Error - Device type not CANoe.
                           #IF-NOT_CANoe-END
                           #IF-CANoe-START
                               # STEP write '$given_can_signal' the  $can_signal_value with mode '$mode'
                               # CALL VEC_write_can_signal                               
                           #IF-CANoe-END
                # IF-ONLINE-END         
        # IF-YES-END        
                
    # STEP return the write status

    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_write_can_signal ($given_can_signal_name , $can_signal_value [, $mode] )', @args );

    my $given_can_signal_name = shift @args;
    my $can_signal_value      = shift @args;
    my $mode                  = shift @args;

    my ( $dev, $return_value, );

    unless ( defined $mode ) {
        S_w2log( 4, " CA_write_can_signal : no mode (phys/hex) given , set to 'phys' as default\n" );
        $mode = 'phys';
    }

    unless ( $mode =~ /phys/i or $mode =~ /hex/i ) {
        S_set_error( " CA_write_can_signal : mode '$mode' shall be either 'phys' or 'hex' \n)", 114 );
        return;
    }

    S_w2log( 3, "CA_write_can_signal: Writes signal value $can_signal_value for signal $given_can_signal_name in mode $mode \n" );

    return 1 if ($main::opt_offline);

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] ) {
        S_set_error( " no CAN access write configured , CA_write_can_signal is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() ) {
            S_set_error( " Could not configure devices for CAN access write ", 131 );
            return;
        }
    }

    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } ) {

        if ( $device eq "CANoe" ) {

            if ( $return_value = VEC_write_can_signal( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_signal_name, $can_signal_value, $mode ) ) {
                S_w2log( 3, " CA_write_can_signal : $given_can_signal_name = $can_signal_value ( $mode ) \n" );
                return $return_value;
            }
            else {
                S_set_error( " CA_write_can_signal : Could not write '$given_can_signal_name'\n", 131 );
                return;
            }
        }
    }
}

######################################################################

=head2 CA_disable_message

    Function Name   :: CA_disable_message
    Description     :: Function controls CAPL env variable 'CANOE_DISABLE'. 
                       'CANOE_DISABLE' set to 0 in case of old implementation.
                       'CANOE_DISABLE' set to 1 in case of new implementation.
    Syntax          :: return_value = CA_disable_message ( CAN_message [ , time_out_info  ]);
    Input Arguments ::
                       Mandatory::
                           CAN_message: name of CAN message as used in LIFT CAN mapping
                       Optional::
                           time_out_info: additional info value which will be set in CAPL environment variable
                             e.g.
                                - number of timeout cycles
                                - time value

    Return Value(s) :: 1 or 0
    Description     ::  1: Successful or in offline
                        0: Failure
						
	Example         :: CA_disable_message('MsgStimulus2_CAN');

B<Note:>

Based on whether the old handling of enabling and disabling the CAN Messages has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling CAN Messages.

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling CAN Messages.

=cut

######################################################################

sub CA_disable_message
{
    ## CA_write_configure have to called before
    ## use out function VEC_disable_can_message() of LIFT_vector_cantool

    my ( $given_can_message, $time_out_info ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_disable_message( CAN_message )", 110 );
        return 0;
    }
    S_w2log( 4, "CA_disable_message \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline
    my ( $dev, $return_value, $devices_text, @devices );
    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN access write configured , CA_disable_message is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_disable_can_message( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message, $time_out_info ) )
            {
                S_w2log( 3, " CA_disable_message : $given_can_message disabled\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_disable_message : Could not disable '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_enable_message

    Function Name   :: CA_enable_message
    Description     :: Function controls CAPL env variable 'CANOE_DISABLE'.
                       'CANOE_DISABLE' set to 1 in case of old implementation.
                       'CANOE_DISABLE' set to 0 in case of new implementation.
    Syntax          :: return_value = CA_enable_message ( CAN_message );
    Input Arguments :: CAN_message
    Description     :: name of CAN message as used in LIFT CAN mapping
    Return Value(s) :: 1 or 0
    Description     :: 1: Successful or in offline
                       0: Failure
    Example         :: CA_enable_message('MsgStimulus2_CAN');
	
B<Note:>

Based on whether the old handling of enabling and disabling the CAN Messages has to be considered L</"Testbench configuration"> 'Devices' => 'CANoe' => B<'OldEnableDisableHandling'>  :
  
= B<'Yes'> Uses the old implementation of Enabling and Disabling CAN Messages.

= B<'No'> Uses the correct(new) implementation of Enabling and Disabling CAN Messages.

=cut

######################################################################

sub CA_enable_message
{
    ## CA_write_configure have to called before
    ## use out function VEC_enable_can_message() of LIFT_vector_cantool

    my ($given_can_message) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_enable_message( CAN_message )", 110 );
        return 0;
    }

    S_w2log( 4, "CA_enable_message \n" );

    return 1 if ($main::opt_offline);    # return 1 in offline

    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN access write configured , CA_enable_message is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_enable_can_message( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message ) )
            {
                S_w2log( 3, " CA_enable_message : $given_can_message enabled\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_enable_message : Could not enable '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_set_DLC

    Function Name   :: CA_set_DLC
    Description     :: Function controls CAPL env variable 'CANOE_DISABLE'
    Syntax          :: return_value = CA_set_DLC ( CAN_message , DLC [ , time_out_info  ]);
    Input Arguments :: Arguments to be passed(if any) / None
    Description     :: Input Arguments description
    Return Value(s) :: Return values of func (if any)  / None
    Description     :: Return values Description
    Example         :: Example with dummy values
    offline return    :: 1

=cut

######################################################################

sub CA_set_DLC
{
    ## CA_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_cantool

    my ( $given_can_message, $given_DLC, $time_out_info ) = @_;

    unless ( defined $given_DLC )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_set_DLC( CAN_message , DLC [ , time_out_info  ] )", 110 );
        return 0;
    }

    S_w2log( 3, "CA_set_DLC: CAN message $given_can_message and DLC $given_DLC \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN access write configured , CA_write_can_signal is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_set_DLC( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message, $given_DLC, $time_out_info ) )
            {
                S_w2log( 3, " CA_set_DLC : DLC of the message $given_can_message set to $given_DLC \n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_set_DLC : Could not disable DLC of message '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_reset_DLC

    Function Name   :: CA_reset_DLC
    Description     :: function controls either LC signal 'LC_DLC' (set to 0) or CAPL env variable 'CANOE_DISABLE' as defined in LIFT CAN mapping
    Syntax          :: $return_value = CA_set_DLC ( $given_can_message [, $given_DLC ]);
    Input Arguments :: $given_can_message - name of CAN message as used in LIFT CAN mapping
                       $given_DLC - DLC which have to be reset in case of not regarding to LIFT CAN mapping for original DLC
    Return Value(s) :: 1 - offline
    Example         ::

=cut

######################################################################

sub CA_reset_DLC
{
    ## CA_write_configure have to called before
    ## use out function VEC_reset_DLC() of LIFT_vector_cantool
    my ( $given_can_message, $given_DLC ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_reset_DLC( CAN_message )", 110 );
        return 0;
    }

    S_w2log( 3, "CA_reset_DLC: CAN message $given_can_message \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline
    my ( $dev, $return_value, $devices_text, @devices );
    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN access write configured , CA_write_can_signal is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN access write ", 131 );
            return 0;
        }
    }

    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_reset_DLC( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message, $given_DLC ) )
            {
                S_w2log( 3, " CA_reset_DLC : DLC of the message $given_can_message has been reset\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_reset_DLC : Could not reset the DLC of the message $given_can_message\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_set_invalidBZ

    Syntax          :: return_value = CA_set_invalidBZ ( $given_can_message [ , $method ,$NbOfCycles ] );

=cut

######################################################################

sub CA_set_invalidBZ
{
    ## CA_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool

   my ( $given_can_message, $method, $NbOfCycles ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params! SYNTAX:  CA_set_invalidBZ(CAN_message [ , method , NbOfCycles])", 110 );
        return;
    }
    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN Access write configured , CA_set_invalidBZ is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN Access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
           if ( $return_value = VEC_set_can_bz_error( $CA_control->{'write'}{$device}{'OLE_handle'} , $given_can_message ,$method , $NbOfCycles) )
            {
                S_w2log( 3, "CA_set_invalidBZ : $given_can_message is set to BZ error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_set_invalidBZ : Could not create a BZ error for '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_set_validBZ

    Syntax          :: return_value = CA_set_validBZ (CAN_message);

=cut

######################################################################

sub CA_set_validBZ
{
    ## CA_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool

    my ( $given_can_message, $method ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_set_validBZ(CAN_message [ , method ])", 110 );
        return 0;
    }
    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN Access write configured , CA_set_validBZ is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN Access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_reset_can_bz_error( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message, $method ) )
            {
                S_w2log( 3, " CA_set_validBZ : $given_can_message is removed from BZ error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_set_validBZ : Could not remove a BZ error for '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}


######################################################################

=head2 CA_set_invalidCRC

    Syntax          :: return_value = CA_set_invalidCRC (CAN_message [,$method, $NbOfCycles]);

=cut

######################################################################

sub CA_set_invalidCRC
{
    ## CA_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool

    my ( $given_can_message, $method, $NbOfCycles ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_set_validCRC(CAN_message [ , method, NbOfCycles ])", 110 );
        return 0;
    }
    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN Access write configured , CA_set_invalidCRC is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN Access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
             if ( $return_value = VEC_set_can_crc_error( $CA_control->{'write'}{$device}{'OLE_handle'} , $given_can_message ,$method ,$NbOfCycles) )
            {
                S_w2log( 3, " CA_set_invalidCRC : $given_can_message is set to CRC error\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_set_invalidCRC : Could not create a CRC error for '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}

######################################################################

=head2 CA_set_validCRC

    Syntax          :: return_value = CA_set_validCRC (CAN_message);

=cut

######################################################################

sub CA_set_validCRC
{
    ## CA_write_configure have to called before
    ## use out function VEC_set_DLC() of LIFT_vector_flxrtool

    my ( $given_can_message, $method ) = @_;

    unless ( defined $given_can_message )
    {
        S_set_error( "Too Less Params ! SYNTAX: CA_set_validCRC( CAN_message [,method])", 110 );
        return 0;
    }
    my ( $dev, $return_value, $devices_text, @devices );

    unless ( $dev = $CA_control->{'write'}{'Devices'}[0] )
    {
        S_set_error( " no CAN Access write configured , CA_set_validCRC is calling CA_write_configure ... ", 0 );
        unless ( CA_write_configure() )
        {
            S_set_error( " Could not configure devices for CAN Access write ", 131 );
            return 0;
        }
    }
    foreach my $device ( @{ $CA_control->{'write'}{'Devices'} } )
    {
        #### Calling CANoe Device
        if ( $device eq "CANoe" )
        {
            if ( $return_value = VEC_reset_can_crc_error( $CA_control->{'write'}{$device}{'OLE_handle'}, $given_can_message, $method ) )
            {
                S_w2log( 3, " CA_set_validCRC : CRC error removed for $given_can_message\n" );
                return $return_value;
            }
            else
            {
                S_set_error( " CA_set_validCRC : Could not remove CRC error for '$given_can_message'\n", 131 );
                return 0;
            }
        }
    }
}


=head1 Function Group 'trace'


=cut


######################################################################

=head2 CA_trace_configure

    Function Name   :: CA_trace_configure
    Description     :: prepare CAN tool to start the trace
    Syntax          :: CA_trace_configure ( );
    Input Arguments :: None
    Return Value(s) :: 1 - offline
    Example         :: CA_trace_configure ( );

=cut

######################################################################

sub CA_trace_configure {
    my ( @devices, $ole_handle, @device_error );

    @devices = EQUIP_get_devices( 'CAN_Access', 'trace' );

    $CA_control->{'trace'}{'Devices'} = [];

    unless ( scalar @devices ) {
        S_set_error( " CA_trace_configure : LIFT_Testbenches does not contain Devices for tracing CAN signals\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_trace_configure : LIFT_Testbenches doesnt contain valid devices for get the trace of CAN signals. Please configure 'CANoe'\n", 21 );
        return;
    }

    S_w2log( 4, "CA_trace_configure:Prepares to starts the trace in CAN tool \n" );
    return 1 if $main::opt_offline;

    foreach my $device (@devices) {
        if ( $device eq "CANalyzer" or $device eq "CANoe" ) {
            if ( $ole_handle = VEC_trace_configure($device) ) {
                S_w2log( 3, " CA_trace_configure : device $device trace configured \n" );
                push( @{ $CA_control->{'trace'}{'Devices'} }, $device );
                $CA_control->{'trace'}{$device}{'OLE_handle'} = $ole_handle;
                return 1;
            }
            else {
                S_set_error( " CA_trace_configure : Could not configure $device for tracing CAN signals", 131 );
                return 0;
            }
        }
    }

    return 1;
}

######################################################################

=head2 CA_trace_start

    Function Name   :: CA_trace_start
    Description     :: start measurement of CAN tool , which must be configured before with CA_trace_configure()
                       if the measurement is already running (because of use of CA_read_configure() before)
                       the measurment will be stopped and started again immediately to start an new log file
    Syntax          :: CA_trace_start ( );
    Input Arguments :: None
    Return Value(s) :: 1 - offline
    Example         :: CA_trace_start ( );

=cut

######################################################################

sub CA_trace_start {

    # return without doing if no CAN_Access trace configured
    return 1 unless CA_isFunctionGroup_CANAccess_configured('trace');

    S_w2log( 3, "CA_trace_start: Starts CAN trace \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my $device;

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configure() before", 131 );
        return;
    }

    if ( $device eq "CANoe" ) {
        #
        # stop measurement first if it is still running ,
        #  then start the measurement again to create a new trace file
        #
        if ( VEC_check_running( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {

            # start logging of the RBS
            if ( CA_get_RBS_control_mode($device) == 1 ) {
                S_w2log( 4, "CA_trace_start: RBS mode (trace logging start/stop) configured. So we do not stop the measurement.\n" );
            }
            else {
                unless ( VEC_stop_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
                    S_set_error( " Could not stop $device measurement", 131 );
                    return;
                }
            }
        }

        unless ( VEC_start_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
            S_set_error( " Could not start $device measurement", 131 );
            return;
        }

        # start logging of CAN trace
        if ( CA_get_RBS_control_mode($device) == 1 ) {
            CA_logging_start();
            S_w2log( 4, "CA_trace_start: RBS mode (trace logging start/stop) configured. Start logging of trace.\n" );
        }

    }
    return 1;
}

######################################################################

=head2 CA_trace_stop

    Function Name   :: CA_trace_stop
    Description     :: stop measurement of CAN tool which must be configured before with CA_trace_configure() and started with CA_trace_start()
    Syntax          :: CA_trace_stop ( );
    Input Arguments :: None
    Return Value(s) :: 1 - offline
    Example         :: CA_trace_stop ( );

=cut

######################################################################

sub CA_trace_stop {

    # return without doing if no CAN_Access trace configured
    return 1 unless CA_isFunctionGroup_CANAccess_configured('trace');

    S_w2log( 4, "CA_trace_stop Stops CAN trace \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my $device;

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configure() before", 131 );
        return;
    }

    unless ( CA_trace_check_running() ) {
        S_w2log( 3, " CA_trace_stop : trace has been stopped already \n" );
        return 1;
    }
    if ( $device eq "CANoe" ) {

        if ( CA_get_RBS_control_mode($device) == 1 ) {
            CA_logging_stop();
            S_w2log( 4, "CA_trace_stop RBS mode (trace logging start/stop) configured. So we do not stop the measurement. Only stop logging of trace. \n" );
        }
        else {
            # stop the measurement if not in RBS control mode
            unless ( VEC_stop_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
                S_set_error( " Could not stop $device measurement", 131 );
                return;
            }
        }
    }
    return 1;
}

######################################################################

=head2 CA_trace_check_running

    Function Name   :: CA_trace_check_running
    Description     :: check if the trace is still running on CAN tool
    Syntax          :: $return_value = CA_trace_check_running ( );
    Input Arguments :: None
    Return Value(s) :: return_value = 1 -> CAN trace still running
                       return_value = 0 -> CAN trace not running
    Example         :: CA_trace_check_running ( );
    offline return    :: 1

=cut

######################################################################

sub CA_trace_check_running {

    # return without doing if no CAN_Access trace configured
    return 1 unless EQUIP_get_devices( 'CAN_Access', 'trace' );

    my ( $device, $return_value );

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configureqqq() before", 0 );
        unless ( CA_trace_configure() ) {
            S_set_error( " CA_trace_configure : couldnot configure trace\n", 131 );
            return;
        }
    }

    S_w2log( 4, "CA_trace_check_running: checks for CAN trace status \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    if ( $device eq "CANoe" ) {
        $return_value = VEC_check_running( $CA_control->{'trace'}{$device}{'OLE_handle'} );
        if ( $return_value == 1 ) {
            S_w2log( 3, " CA_trace_check_running : CAN trace still running\n" );
        }
        elsif ( $return_value == 0 ) {
            S_w2log( 3, " CA_trace_check_running : CAN trace not running\n" );
        }
        else {
            S_set_error( "CA_trace_check_running : not successful ", 131 );
            return 0;
        }
        return $return_value;
    }
}


######################################################################

=head2 CA_trace_store

    $returned_store_file_name = CA_trace_store ( [ $store_file_name ] ) ;

Gets the copy of 'CANoe' trace log file. 

Trace log file as mentioned in testbech  L</"Devices section:"> ['CANoe'->'Log_File'] shall be copied to the path '$store_file_name' if given otherwise to the report folder.


B<Arguments:>

=over

=item $store_file_name 

(optional) name of the Trace file.If not given then it will be stored under report folder.

=back

B<Return Value:>

=over

=item returned_store_file_name 

file of the trace file where the trace is stored

=item Offline return

Returns name of the dummy file created in the folder as mentioned in $store_file_name. If not mentioned as parameter, a dummy file name in reports folder.

=back

B<Examples:>

	$returned_store_file_name = CA_trace_store ( );
	$returned_store_file_name = CA_trace_store ( $store_file_name);

B<Notes:> 

It logs the CANoe trace based on the setting's done in the CANoe for "Logging File Configuration".

 Check : what user has configured for the logging file ?  
  Measurement setup -> Logging Block > Logging File Configuration
  --> if option "After each trigger block"  is :
      --> checked : RBS will not be stopped to take the log file.
      --> unchecked : stop the RBS & take the log file.     

=cut

sub CA_trace_store {

    # return without doing if no CAN_Access trace configured
    my ($store_file_name) = @_;

    return 1 unless CA_isFunctionGroup_CANAccess_configured('trace');

    S_w2log( 3, "CA_trace_store:Stores CAN trace to $store_file_name \n" );

	if($main::opt_offline) {
		# create a dummy trace file for the file name passed or in reports folder if not passed the file name
		unless($store_file_name) {
			$store_file_name = $main::REPORT_PATH ."/dummy_trace".".asc";
		}
		S_create_dummy_file($store_file_name);
		return $store_file_name;
	}

    my ($returned_store_file_name);
    my $device;
    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configure() before", 0 );
        unless ( CA_trace_configure() ) {
            S_set_error( " CA_trace_store : could not configure trace", 131 );
            return;
        }
    }

    if ( $device eq "CANoe" ) {
        return unless ( $returned_store_file_name = VEC_trace_store( $CA_control->{'trace'}{$device}{'OLE_handle'}, $store_file_name ) );

    }
    return $returned_store_file_name;
}

######################################################################

=head2  CA_trace_get_dataref

	$data_href = CA_trace_get_dataref ( $trace_file_path , $can_signals_or_msgs_aref, [ $sysVars_aref ] );
    
Reads a trace file $data_file_name and writes the data of all signals, mesages (\@label_list) and optionaly system variables (\@sysVars_list) 
into a hash-tree and returns the reference to that hash-tree.
    
B<Arguments:>

=over

=item $trace_file_path 

Path to the trace file.

=item $can_signals_or_msgs_aref 

Array reference of messages and signals for which data shall be retrieved. It may contain sub-arefs like [Message_ID_dec,busnr] to bypass CAN mapping file

=item $sysVars_aref 

(optional) array reference of system variales. NOTE: of data type integer & float only.

=back

B<Return Value:>

=over

=item $data_href 

Hash reference of the data. See below for details.

=back

B<Examples:>

   	$data_href = CA_trace_get_dataref($can_log_file, ['PreCrash_01_CRC', 'PreCrash_01']);
   	$data_href = CA_trace_get_dataref(
                           $can_log_file, 
                           ['PreCrash_01_CRC', 'PreCrash_01'], 
                           ['LIFT_CAN_access::SysVar_Type_Int', 'LIFT_CAN_access::SysVar_Type_Float']
                         );
    $data_href = CA_trace_get_dataref($can_log_file, ['PreCrash_01', [16, 2] ]);

B<Structure of returned $data_href:>

	$data_href = {
		'timestamp_1' => {
   	                     'message_A' => {
   	                        	        'DATA_A' => 'phys_value_at_time_1' ,
   	                        	        'DLC_A' => 'DLC_A',
   	                        	        }
   	                     'signal_1' => 'phys_value_at_time_1',
   	                     'signal_2' => 'phys_value_at_time_1',
   	                     'message_B' => {
   	                        	        'DATA_B' => 'phys_value_at_time_1' ,
   	                        	        'DLC_B' => 'DLC_B',
   	                        	        }
   	                     'signal_3' => 'phys_value_at_time_1',
						  },
		'timestamp_2' => {
   	                     'message_A' => {
   	                        	        'DATA_A' => 'phys_value_at_time_2' ,
   	                        	        'DLC_A' => 'DLC_A',
   	                        	        }
   	                     'signal_1' => 'phys_value_at_time_2',
   	                     'signal_2' => 'phys_value_at_time_2',
   	                     'message_B' => {
   	                        	        'DATA_B' => 'phys_value_at_time_2' ,
   	                        	        'DLC_B' => 'DLC_B',
   	                        	        }
   	                     'signal_3' => 'phys_value_at_time_2',
						 },
		'timestamp_3' => {
   	                     'Full_qualified_system_variable' => 'value_at_timestamp_3',
   	                     },                                         
	  };

B<Hint for evaluation:> 

  The data hash can be sorted via :-
 
  foreach my $ascending_sorted_timestamp ( keys sort { $a <=> $b } %$data_href  ) {
     what you want to evaluate
  }

  (Note: for numerical descending just use { $b <=> $a } )
  or you can use the functions provided in LIFT_evaluation package,
  e.g.
  use LIFT_evaluation;
  EVAL_get_time_when
  EVAL_get_values_at_time
  EVAL_get_values_over_time
  EVAL_evaluate_values_at_time
  EVAL_evaluate_values_in_trace
  ...

=cut

######################################################################
sub CA_trace_get_dataref
{
    #STEP get arguments: -log file  -list of signals or messages  -list of system variables
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_trace_get_dataref ( $trace_file_path , $can_signals_or_msgs_aref, [ $sysVars_aref ] )', @args );

    my $trace_file_path          = shift @args;
    my $can_signals_or_msgs_aref = shift @args;
    my $sysVars_aref             = shift @args;

    my $returnDataRef = ();    # < - - declared as hash ref initially
    my ( $just_message_infos, $msg_name, $can_bus_nbr, $can_signal, $data_format, $timestamps, $found_messages );

    #STEP validate arguments
    unless ( -f $trace_file_path )
    {
        S_set_error( " $trace_file_path File not found", 109 );
        return;
    }

    my @can_signals_or_msgs = @$can_signals_or_msgs_aref;

    my $can_mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless (%$can_mapping)
    {
        S_set_error( " LIFT CAN_mapping doesnot exist", 20 );
        return;
    }

    ( $data_format, $timestamps ) = VEC_trace_can_analyze_format($trace_file_path);

    unless ($data_format)
    {
        S_set_error( " couldnt determine format of CAN trace '$trace_file_path'", 131 );
        return;
    }

    #LOOP-START loop over list of signals or messages
    foreach my $can_signal_or_msg (@can_signals_or_msgs)
    {
        #IF signal or message is an array reference?
        if( ref( $can_signal_or_msg ) eq 'ARRAY' ) {
            #IF-YES-START

            #STEP get message ID and bus number from given array reference
            $msg_name = $$can_signal_or_msg[0];
            my $id_dec = $msg_name;
            $can_bus_nbr = $$can_signal_or_msg[1];
            my $id = GetIDfromDecID($id_dec, $data_format);
            $just_message_infos = 1;

            #STEP get data for message ID from trace file
            $found_messages = VEC_trace_can_get_message_data( $trace_file_path, $id, $can_bus_nbr );

            #IF-YES-END
        }
        else{
            #IF-NO-START
            #STEP get message name and bus number from signal
            if ( exists $can_mapping->{'CAN_MESSAGES'}{$can_signal_or_msg} )
            {
                $msg_name           = $can_signal_or_msg;
                $just_message_infos = 1;
            }
            else
            {
                $can_signal = $can_signal_or_msg;
                unless ( $msg_name = $can_mapping->{$can_signal}{'MESSAGE'} )
                {
                    S_set_error( " CA_trace_get_dataref: no 'MESSAGE' defined for CAN signal '$can_signal' in CAN MAPPING", 109 );
                    return;
                }
                $just_message_infos = 0;
            }
            unless ( $can_bus_nbr = $can_mapping->{'CAN_MESSAGES'}{$msg_name}{'CAN_BUS_NBR'} )
            {
                S_set_error( " CA_trace_get_dataref: no 'CAN_BUS_NBR' defined for CAN message '$msg_name' in CAN MAPPING\n", 109 );
                return;
            }

            #STEP get data for message name from trace file
            $found_messages = VEC_trace_can_get_message_data( $trace_file_path, $msg_name, $can_bus_nbr );

            #IF data found?
            #IF-YES-START
            #IF-YES-END
            my $id_dec;
            my $id;
            unless ( defined $found_messages )
            {
                #IF-NO-START
                #STEP get message ID from message name
                 $id_dec = $can_mapping->{'CAN_MESSAGES'}{$msg_name}{'ID'};
                 $id = GetIDfromDecID($id_dec, $data_format);

                #STEP get data for message ID from trace file
                $found_messages = VEC_trace_can_get_message_data( $trace_file_path, $id, $can_bus_nbr );
                #IF-NO-END
            }
            
            # STEP look for the CANFD from Trace if CAN data not found
            unless ( defined $found_messages ) {
                 # CALL LIFT_vector_cantool::VEC_trace_canfd_get_message_data
                 $found_messages = VEC_trace_canfd_get_message_data($trace_file_path, {CANFD_MSG_NAME=> $msg_name, CANFD_ID=>$id, CANFD_CHNL_NBR=>$can_bus_nbr});   
            }
                      
            #IF-NO-END  
             
        }

        #STEP sort data into dataref
        foreach my $time_stamp ( sort { $a <=> $b } keys %$found_messages )
        {
            my $dlc  = $found_messages->{$time_stamp}{'DLC'};
            my $data = $found_messages->{$time_stamp}{'DATA'};
            $returnDataRef->{$time_stamp}{$msg_name}{'DLC'}  = $dlc;
            $returnDataRef->{$time_stamp}{$msg_name}{'DATA'} = $data;
        }

        if ($just_message_infos)
        {
            # If only Message is given, skip current iteration
            next;
        }

        my $signal_data_ref = VEC_trace_can_get_signal_data( $found_messages, $can_signal, $data_format );

        unless( defined $signal_data_ref )
        {
            S_set_error( " CA_trace_get_dataref: $can_signal not found in the Trace" , 109);
            next;
        }

        foreach my $time_stamp ( sort { $a <=> $b } keys %$signal_data_ref )
        {
            my $can_signal_Data_local = $$signal_data_ref{$time_stamp};
            $returnDataRef->{$time_stamp}->{$can_signal} = $can_signal_Data_local;
        }
        #LOOP-END last signal or message?
    }

    # if system variable was defiend --> optional
    #IF list of system variables given?
    my @sysVars_to_search;
    if (defined $sysVars_aref)   {
        #IF-YES-START

		if ( ref($sysVars_aref) eq 'ARRAY' ) {
	       	@sysVars_to_search = @$sysVars_aref;
	    }
    	else  {
        	S_set_error( " Invalid Parameters ! given_sysVars is not an Array Reference", 114 );
        	return;
    	}

        #LOOP-START loop over list of system variables
    	## get the timestamp of system variable from trace file 
        foreach my $sysVar ( @sysVars_to_search )  {

            #STEP get system variable data from trace
			my $sysvar_data_ref =  VEC_trace_sysVar_get_data ($trace_file_path, $sysVar) ;

			#STEP sort data into dataref
			foreach my $time_stamp ( sort { $a <=> $b } keys %$sysvar_data_ref ){
				my $sysvar_Data_local =  $$sysvar_data_ref{$time_stamp}{'DATA'};
				$returnDataRef->{$time_stamp}->{$sysVar} = $sysvar_Data_local;
			}
			#LOOP-END last system variable?
        }
        #IF-YES-END
	}
    #IF-NO-START
    #aSTEP -
    #IF-NO-END

    #STEP return dataref
    return $returnDataRef;
}

sub GetIDfromDecID{
    my $id_dec = shift;
    my $data_format = shift;

    if ( $id_dec > 0x1FFFFFFF )
    {
        S_w2log( 5, " CA_trace_get_dataref: given ID $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) is greater the 29 bit ; sometime 100 is added to 29bit IDs (EXT identifier)\n" );
        $id_dec = $id_dec & 0x1FFFFFFF;    # mask with 29bit
        S_w2log( 5, " CA_trace_get_dataref: changed to $id_dec (dec) / 0x" . uc sprintf( "%x", $id_dec ) . " (hex) \n" );
    }

    my $id_hex = uc sprintf( "%x", $id_dec );
    my $id;
    $id = $id_dec if $data_format =~ /dec/i;
    $id = $id_hex if $data_format =~ /hex/i;

    return $id;
}

=head2 CA_trace_get_PD_responses

    $responses_href = CA_trace_get_PD_responses( $traceFilename, $response [, $busNr ] );

Reads the CAN/CANFD trace file $traceFilename and extracts all PD responses with response code $response.

Input:

    $filename: name of CAN trace file with PD responses
    $response: response code that shall be extracted from trace (in hex)
    $busNr   : (optional) bus number in trace, default = 1 (CAN)
               if it is a decimal number then it defines the CAN bus number
               if it is CANFD or CANFD2 then it defines CANFD bus number 1 or 2 respectively

Output:

    $responses_href : reference to hash with all responses of $response. Primary key is the time of the response

    $responses_href = {
        TIME_0 => [responseByte0, responseByte1, responseByte2, ...] ,
        TIME_1 => [responseByte0, responseByte1, responseByte2, ...] ,
        ...
    }

Note1: responseByteX is always in dec !!!
Note2: response CAN-ID is taken from project const: $Defaults->{'CUSTOMER_DIAGNOSIS'}{'ResponseID_PD'}

Examples:

    Extract all responses (4D) of the PD request 0D (SMI7xy verification):
    $responses_href = CA_trace_get_PD_responses( 'myTraceFile.asc', '4D' );

=cut

sub CA_trace_get_PD_responses
{

    my @args = @_;
    return {} unless S_checkFunctionArguments( 'CA_trace_get_PD_responses( $traceFilename, $response [, $busNr ] )', @args );

    my $filename = shift @args;
    my $response = shift @args;
    my $busNr    = shift @args;

    Readonly my $BYTE_LENGTH => 256;

    $busNr = 1 if not defined $busNr;

    S_w2log( 4, "CA_trace_get_PD_responses : Getting PD responses from file '$filename' for response '$response' on bus '$busNr'\n" );

    # get response CAN-ID from project const
    my $responseID = S_get_contents_of_hash( [ 'CUSTOMER_DIAGNOSIS', 'ResponseID_PD' ] );
    if ( not defined $responseID )
    {
        S_set_error("'ResponseID_PD' not defined in project const in section 'CUSTOMER_DIAGNOSIS'.");
        return {};
    }
    $responseID =~ s/^0x(\w+)/$1/g;    # remove leading 0x

    # get all data frames of response ID from trace, depending on $busNr
	my $message_ref;
	if( $busNr =~ /^CANFD(\d*)/i ){
		my $channelNr = $1;
		$channelNr = 1 if $channelNr eq '';
    	$message_ref = VEC_trace_canfd_get_message_data($filename, {CANFD_ID=>$responseID, CANFD_CHNL_NBR=>$channelNr}); 
	}
	else{
    	$message_ref = VEC_trace_can_get_message_data( $filename, $responseID, $busNr );		
	}

    if ( not defined $message_ref )
    {
        S_set_error("Could not get data from CAN trace on bus $busNr and message ID $responseID.");
        return {};
    }

    my ( %responses, $length, $timestamp );
    my $responseString = '';
    my $responseFound = 0;

    # loop over all response frames
    foreach my $frame ( sort { $a <=> $b } keys %$message_ref )
    {
        # get data string of response (string of hex bytes)
        my $data = $message_ref->{$frame}{'DATA'};

        # check if second byte is the expected resonse code
        if ( not $responseFound and $data =~ /^\s*(\w\w)\s+($response.+)$/i )
        {
            # set marker $responseFound because responses can be spread over several frames
            $responseFound = 1;

            # determine the expected data length in number of bytes
            $length = hex($1);
            my $responseFirstByte = substr($response, 0, 2);
            if ( uc($responseFirstByte) eq '4D' or uc($responseFirstByte) eq '4E')
            {
                # only for response 4D the length is in fact longer than 256
                $length += $BYTE_LENGTH;
            }

            # get first data bytes and frame time
            $responseString = $2;
            $timestamp      = $frame;
        }
        else
        {
            # second byte is not the expected resonse code
            if ($responseFound)
            {
                # add data bytes to $responseString if the response was found earlier
                $responseString .= ' ' . $data;
            }
            else
            {
                # do nothing
            }
        }

        # get current response bytes in a list
        my @hexBytes = split( /\s+/, $responseString );

        # check if length of the list is => the expected response length
        if ( $responseFound and @hexBytes >= $length )
        {
            # the response is complete and can be put to the output data structure
            my @decBytes = map( { hex($_) } @hexBytes );

            # cut response bytes to be exactly $length bytes long
            splice( @decBytes, $length );
            $responses{$timestamp} = \@decBytes;
            $responseFound = 0;
        }
    }

    return \%responses;
}


=head1 Function Group 'simulation'


=cut

######################################################################

=head2 CA_simulation_start

    Function Name   :: CA_simulation_start
    Description     :: start CANoe  measurement if not running before and then stop logging of CANoe trace fast..
                       Configuration shall be done by calling CA_init().
                       If the measurement is already running then only trace logging will be stopped.
                       Otherwise first measurement will be started and then trace logging will be stopped.                       
    Syntax          :: CA_simulation_start ( );
    Input Arguments :: None
    Return Value(s) :: 1 - offline, success
                       0 - failure  
    Example         :: CA_simulation_start ( );

=cut

######################################################################

sub CA_simulation_start {
    return 1 unless CA_isFunctionGroup_CANAccess_configured('trace');

    S_w2log( 3, "CA_simulation_start : Starts CAN trace \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my ( $device, $measurement_running_status );

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " CA_simulation_start : no trace configured , use CA_init() before", 131 );
        return;
    }

    # check measurement running status
    $measurement_running_status = VEC_check_running( $CA_control->{'trace'}{$device}{'OLE_handle'} );

    if ( $device eq "CANoe" ) {
        #
        #  start the measurement if not already running
        #
        if ($measurement_running_status) {
            S_w2log( 3, "CA_simulation_start : Measurement was already running, do nothing. \n" );
        }
        else {
            S_w2log( 3, "CA_simulation_start : measurement was not running, will be started now..\n" );
            unless ( VEC_start_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
                S_set_error( " CA_simulation_start : Could not start $device measurement", 131 );
                return;
            }
        }

        #
        # Stop the logging of trace here
        #
        CA_set_RBS_control_mode( $device, 1 );
        CA_logging_stop();
    }
    else {
        S_set_error(" CA_simulation_start : Configured $device not supported yet !! ");
    }

    return 1;
}


######################################################################

=head2 CA_simulation_stop

    Function Name   :: CA_simulation_stop
    Description     :: stop measurement of CAN tool which must be configured before with CA_init()
                       and started with CA_simulation_start()
    Syntax          :: CA_simulation_stop ( );
    Input Arguments :: None
    Return Value(s) :: 1 - offline, success
                       0 - failure  
    Example         :: CA_simulation_stop ( );

=cut

######################################################################
sub CA_simulation_stop {
    return 1 unless CA_isFunctionGroup_CANAccess_configured('trace');

    S_w2log( 4, "CA_simulation_stop Stops CAN trace \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my $device;

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " CA_simulation_stop : no trace configured , use CA_init() before", 131 );
        return;
    }

    unless ( CA_trace_check_running() ) {
        S_w2log( 3, " CA_simulation_stop : trace has been stopped already \n" );
        return 1;
    }

    if ( $device eq "CANoe" ) {
        unless ( VEC_stop_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
            S_set_error( " Could not stop $device measurement", 131 );
            return;
        }

        # set RBS mode to zero
        CA_set_RBS_control_mode( $device, 0 );
    }
    return 1;
}


#not used functions
######################################################################

# =head2 CA_read_can_lamps

# Function Name   :: CA_read_can_lamps
# Description     :: Read CAN lamps from CAN tool(s) which was/were configured in
# $LIFT_config->LIFT_ProjectDefaults->{'CAN_PROJECT_LAMPS'}
# Syntax          :: $can_lamps_href = CA_read_can_lamps ( );
# Input Arguments :: None
# Description     :: None
# Return Value(s) :: can_lamps_hash
# Description     :: Hash refernce of the CAN lamps
# Example         :: \%can_lamps_hash = CA_read_can_lamps ( );
# offline Return    :: 1

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

######################################################################

# sub CA_read_can_lamps
# {
    # my $can_lamps_href = {};
    # my $can_lamp_value;

    # unless( $LIFT_config::LIFT_ProjectDefaults->{'CAN_PROJECT_LAMPS'} ) 
    # {
        # S_set_error( "LIFT_config::LIFT_ProjectDefaults->{'CAN_PROJECT_LAMPS'} not defined" , 0 );
        # return;
    # }

    # return 1 if ($main::opt_offline); # return 1 in offline

    # foreach my $can_lamp ( @{$LIFT_config::LIFT_ProjectDefaults->{'CAN_PROJECT_LAMPS'}} ) 
    # {
        # ( $can_lamp_value ) = CA_read_can_signal( $can_lamp , 'phys' );
        # $can_lamps_href->{$can_lamp} = $can_lamp_value;
        # S_w2log( 4, " CA_read_can_lamps: $can_lamp -> $can_lamp_value \n");
    # }
    # return $can_lamps_href;
# }

######################################################################

# =head2 CA_disturbance_configure

    # Function Name     :: CA_disturbance_configure
    # Description       :: CANStress disturbance configuration loading
    # Syntax            :: CA_disturbance_configure ( $config_or_file [ , $replace_config ] );
    # Input Arguments   :: $config_or_file - configuration file
                         # $replace_config - hash reference as shoen below
    # Return Value(s)   :: None
    # Example           :: CA_disturbance_configure ( config_or_file );
    # offline return      :: 1

    # config_or_file 
        # - is for CANstress : CANstress configuration file (template) (*.cst)
        # - is for LabCar/ES4441 : hash ref with

        # $disturbance_config = {
                                # 'disturbance_type'          => 'short_realtime' or 'interrupt_realtime' ,
                                # 'disturbance_lines'         => \@( 'Line1' , 'Line2' ) ,
                                # 'disturbance_duration_ms'   => <<duration_ms>> ,
                                # 'disturbance_trigger_type'  => 'None' or 'External' , 
                                # };

    # CANstress needs further action (kexword replacement in config file)

    # $replace_config = {
                        # 'replace_keywords' => {
                                                # '__DISTURBANCE_DURATION_MS__' => 100 ,
                                                # } ,
                        # 'config_file_final' => 'CANStress_ir_CANHigh_100.cst'  ,
                        # } ; 

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

#####################################################################

# sub CA_disturbance_configure
# {
    # my $config_or_file = shift;
    # my $replace_config = shift;

    # my (
        # @devices ,
        # $devices_text ,
        # $OLE_handle ,
    # );

    # @devices = EQUIP_get_devices( 'CAN_Access' , 'disturbance' );

    # $CA_control->{'disturbance'}{'Devices'} = [];

    # unless( @devices ) {
        # S_w2log( 1 , " CA_disturbance_configure : LIFT_Testbenches does not contain Devices for disturbance of CAN signals\n" );
        # return;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
    # foreach my $device ( @devices ) {
        # if( $device eq "CANStress" ) {
            # if( $OLE_handle = VCS_disturbance_configure( $device , $config_or_file , $replace_config ) ) {
                # S_w2log( 5 , " CA_disturbance_configure : device $device disturbance configured \n" );
                # S_w2rep(" CA_disturbance_configure : device '$device' disturbance configured \n" , 'red' );
                # push( @{$CA_control->{'disturbance'}{'Devices'}} , $device);
                # S_w2rep(" CA_disturbance_configure : ".$CA_control->{'disturbance'}{'Devices'}[0] , 'red' );
                # $CA_control->{'disturbance'}{$device}{'OLE_handle'} = $OLE_handle;
            # }
            # else {
                # S_w2log( 1 , " CA_disturbance_configure : Could not configure $device for disturbance of CAN signals" );
            # }
        # }
    # }
    # unless( @{$CA_control->{'disturbance'}{'Devices'}} ) {
        # bad case
        # $devices_text = join( " " , @devices );
        # S_w2log( 1 , " CA_disturbance_configure : Could not configure any devices ($devices_text) for disturbance of CAN signals\n" );
       # S_set_error( " no other tool supported ", 131 );
        # return;
    # }
    # return 1;
# }

#####################################################################

# =head2 CA_disturbance_start

    # Function Name     :: CA_disturbance_start
    # Description       :: start measurement of CAN tool , which must be configured before with CA_trace_configure()
                         # if the measurement is already running (because of use of CA_read_configure() before) 
                         # the measurment will be stopped and started again immediately to start an new log file
    # Syntax            :: CA_disturbance_start ( );
    # Input Arguments   :: None
    # Return Value(s)   :: 1 - offline
    # Example           :: CA_disturbance_start ( );

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

#####################################################################

# sub CA_disturbance_start
# {
    # return without doing if no CAN_Access trace configured
    # return 1 unless  EQUIP_get_devices( 'CAN_Access' , 'disturbance' );

    # my $device;
    # unless ( $device = $CA_control->{'disturbance'}{'Devices'}[0] )
    # {
        # S_set_error( " no trace configured , use CA_disturbance_configure() before", 131 );
        # return;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
    # if( $device eq "CANStress" )
    # {

        # stop measurement first if it is still running , 
         # then start the disturbance again to create a new trace file

        # if ( VCS_check_running( $CA_control->{'disturbance'}{$device}{'OLE_handle'} ) > 0 )
        # {
            # S_w2log (3, "Disturbance is running/active on $device. Stop running disturbance before starting again\n");
            # unless ( VCS_stop_disturbance( $CA_control->{'disturbance'}{$device}{'OLE_handle'} ) )
            # {
                # S_set_error( " Could not stop $device disturbance before starting", 131 );
                # return;
            # }
        # }
        # unless ( VCS_start_disturbance( $CA_control->{'disturbance'}{$device}{'OLE_handle'} ) )
        # {
            # S_set_error( " Could not start $device disturbance", 131 );
            # return;
        # }
        # unless ( VCS_start_trigger( $CA_control->{'disturbance'}{$device}{'OLE_handle'} ) )
        # {
            # S_set_error( " Could not trigger $device disturbance", 131 );
            # return;
        # }
        # S_wait_ms(400);
    # }
    # else {
        # S_set_error( " no other tool supported ", 131 );
        # return ;
    # }
    # return 1;
# }

#####################################################################

# =head2 CA_disturbance_stop

    # Function Name     :: CA_disturbance_stop
    # Description       :: stop measurement of CAN tool which must be configured before with CD_trace_configure() and
                         # started with CA_disturbance_start()
    # Syntax            :: CA_disturbance_stop ( );
    # Input Arguments   :: None
    # Return Value(s)   :: 1 - offline
    # Example           :: CA_disturbance_stop ( );

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

#####################################################################

# sub CA_disturbance_stop
# {
    # return without doing if no CAN_Access trace configured
    # return 1 unless  EQUIP_get_devices( 'CAN_Access' , 'disturbance' );

    # my $device;

    # unless ( $device = $CA_control->{'disturbance'}{'Devices'}[0] )
    # {
        # S_set_error( " no disturbance configured , use CA_disturbance_configure() before", 131 );
        # return;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
    # if( CA_disturbance_check_running() < 2) {
        # S_w2log( 3 , " CA_disturbance_stop : disturbance has been stopped already \n" );
        # return 1;
    # }
    # if( $device eq "CANStress" )
    # {
        # unless ( VCS_stop_disturbance( $CA_control->{'disturbance'}{$device}{'OLE_handle'} ) ) {
            # S_set_error( " Could not stop $device disturbance", 131 );  return;
        # }
    # }
    # else {
        # S_set_error( " no other tool supported ", 131 );
        # return;
    # }
    # S_w2log( 5 , " CA_disturbance_start : device $device disturbance stopped \n" ); 
    # return 1;
# }

#####################################################################

# =head2 CA_disturbance_check_running

    # Function Name     :: CA_disturbance_check_running
    # Description       :: Checks if the Disturbance is running or not
    # Syntax            :: $return_value = CA_disturbance_check_running ( );
    # Input Arguments   :: None
    # Return Value(s)   :: $return_value = current value of CANStress
    # Example           :: $return_value = CA_disturbance_check_running ( );
    # offline return      :: 1

    # Checks the current status of the CANStress

        # 0 - Idle State
        # 1 - Finished
        # 2 - Pending State
        # 9 - State Info not supported yet     

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

######################################################################

# sub CA_disturbance_check_running
# {
    # return without doing if no CAN_Access trace configured
    # return 1 unless  EQUIP_get_devices( 'CAN_Access' , 'disturbance' );

    # my $device; my $return_value;

    # unless ( $device = $CA_control->{'disturbance'}{'Devices'}[0] )
    # {
        # S_w2rep(" CA_disturbance_configure : ".$CA_control->{'disturbance'}{'Devices'}[0] , 'red' );
        # S_set_error( " no disturbance configured , use CA_disturbance_configure() before", 131 );
        # return;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
    # if( $device eq "CANStress" ) {
        # $return_value = VCS_check_running ( $CA_control->{'disturbance'}{$device}{'OLE_handle'} );
        # if( not defined $return_value )
        # {
            # S_set_error( " error while checking running CAN disturbance", 131 );
        # }
        # elsif ( $return_value == 2 )
        # {
            # S_w2log( 3, " CA_disturbance_check_running : CAN disturbance still running\n" );
        # }
        # elsif ( $return_value == 1 )
        # {
            # S_w2log( 3, " CA_disturbance_check_running : CAN disturbance finished\n" );
        # }
        # elsif ( $return_value == 0 )
        # {
            # S_w2log( 3, " CA_disturbance_check_running : CAN disturbance idle\n" );
        # }
        # else
        # { 
            # S_set_error( " undefined return value '$return_value' from VEC_check_running ", 131 );
        # }
        # return $return_value;
    # }
    # else {
        # S_set_error( " no other tool supported ", 131 );
        # return;
    # }
# }

#####################################################################

# =head2 CA_disturbance_load_configuration

    # Function Name     :: CA_disturbance_load_configuration
    # Description       :: loads the configuration file onto the corresponding device
    # Syntax            :: CA_disturbance_load_configuration ($config_file );
    # Input Arguments   :: None
    # Return Value(s)   :: 1 - offline
    # Example           :: CA_disturbance_load_configuration ( $config_file  );

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

######################################################################

# sub CA_disturbance_load_configuration
# {
    # my $config_file = shift;

    # my $dev;

    # return without doing if no CAN_Access trace configured
    # my @devices = EQUIP_get_devices( 'CAN_Access' , 'disturbance' );

    # unless ( $dev = $CA_control->{'disturbance'}{'Devices'}[0] )   {
        # S_set_error( " no disturbance configured , use CA_disturbance_configure() before", 131 );
        # return;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
    # $CA_control->{'disturbance'}{'Devices'} = [];
    # unless( @devices ) {
        # S_w2log( 1 , " CA_disturbance_configure : LIFT_Testbenches does not contain Devices for disturbance of CAN signals\n" );
        # return;
    # }
    # foreach my $device ( @devices ) {
        # if( $device eq "CANStress" ) {
            # VCS_disturbance_configure( $device , $config_file , 1 );
            # VCS_open_configuration( $device , $config_file , 1 );
        # }
    # }
    # return 1;
# }

#####################################################################

# =head2 CA_evaluate_can_lamps

    # Function Name     :: CA_evaluate_can_lamps
    # Description       :: evaluates the lamp values against the expected and returns the verdict 
    # Syntax            :: $VERDICT = CA_evaluate_can_lamps ( \%state_lamps , \%lamps_expected );
    # Input Arguments   :: \%state_lamps  - hash reference of the stat of the CAN lamps
                         # \%lamps_expected - hash refernce of the expected values of CAN lamps                         
    # Return Value(s)   :: $VERDICT - verdict 
    # Example           :: $VERDICT = CA_evaluate_can_lamps ( \%state_lamps , \%lamps_expected );

# Note : This API is not used in any testcase. Hence it is not exported. yet to be tested

 # =cut

#####################################################################

# sub CA_evaluate_can_lamps 
# {
    # my $state_lamps = shift;
    # my $lamps_expected = shift;

    # unless ( defined $lamps_expected ) { # if less than 2 parameters: set error
        # S_set_error( " too less parameters ! CA_evaluate_can_lamps (\%detected_lamps ,\%expected_lamps) ", 110 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }
    # if( $main::opt_offline ) { S_set_verdict(VERDICT_PASS); return 1; }
    # no strict 'subs';                        # needed to check the reference type
    # unless ( ref( $state_lamps) eq HASH ) {
        # S_set_error( " parameter error ! given parameter of detected lamps IS NOT a HASH REFERENCE", 114 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }
    # unless ( ref( $lamps_expected) eq HASH ) {
        # S_set_error( " parameter error ! given parameter of expected lamps IS NOT a HASH REFERENCE", 114 );
        # S_set_verdict( VERDICT_INCONC );
        # return VERDICT_INCONC;
    # }
     ## CALL check lamps function
     # my ( $result ,
          # $expected_lamp_eval_text ,
          # $detected_lamp_eval_text
        # ) = CA_check_can_lamps( $state_lamps, $lamps_expected , 'get_text' );

   ### ---- for of EVAL TABLE write the SIGNAL, THE EXPECT & DETECT value in seperated lines per cell ----
    # my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
    # my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};

    # S_add2eval_collection( 'CAN_LAMPS' , $expect_marker.$expected_lamp_eval_text );
    # S_add2eval_collection( 'CAN_LAMPS' , $detect_marker.$detected_lamp_eval_text );
   ### ----------------------------------------------------------------------------------------

    # if ( $result ) {
       # my $pass_text=<<EOPASS;
# CA_evaluate_can_lamps ==> expected result
  # $expect_marker: $expected_lamp_eval_text
  # $detect_marker: $detected_lamp_eval_text
# EOPASS
       # S_w2rep( $pass_text );
       # S_set_verdict( VERDICT_PASS );
       # return VERDICT_PASS;
    # }
    # else {
       # my $fail_text=<<EOFAIL;
# CA_evaluate_can_lamps ==> FAIL, not expected result
  # $expect_marker: $expected_lamp_eval_text
  # $detect_marker: $detected_lamp_eval_text
# EOFAIL
       # S_w2rep( $fail_text );
       # S_set_verdict(VERDICT_FAIL);
       # S_add2eval_collection( 'MISMATCH' , 'CAN_LAMPS' );
       # return VERDICT_FAIL;
    # }
# }

#####################################################################

# =head2 CA_check_can_lamps

    # Function Name     :: CA_check_can_lamps
    # Description       :: evaluates the lamp values against the expected and returns the verdict 
    # Syntax            :: ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line )  = CA_check_can_lamps ( $result_ref, $expected_ref, $get_text_option );
    # Input Arguments   :: $result_ref, $expected_ref, $get_text_option                 
    # Return Value(s)   :: $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line
    # Example           :: ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line ) = CA_check_can_lamps ($result_ref, $expected_ref , 'get_text' );
    # offline return      :: 1

# Note : This API is not used in any testcase. Hence its not exported. yet to be tested

 # =cut

#####################################################################

# sub CA_check_can_lamps 
# {
    # could perhaps be replaced by "if (%result eq %expected) {...}
    # my $result_ref = shift;
    # my $expected_ref = shift;
    # my $get_text_option = shift;
    # my $fault_flag;
    # my ($lamp_res_expect, $lamp_res_detect , $real_lamp );
    # my $strategy_key = "CAN_LAMP_STRATEGY"; # key for mapping of expected lamps

    # unless (defined( $expected_ref )) {
           # HERE YOU COULD CHOOSE A DEFAULT ARRAY !
        # S_set_error( '! too less parameters ! SYNTAX: CA_check_can_lamps(\%result,\%expected)', 110 );
        # return 0;
    # }
    # return 1 if ($main::opt_offline); # return 1 in offline
   # check if a mapping of lamps is recommendet
   # if (defined $expected_ref->{$strategy_key}) {
  # S_w2log( 5, "found STRATEGY: ".$expected_ref->{$strategy_key}.", trying to map it\n" );

       # check if strategy is defined in Project defaults
        # if( exists $main::ProjectDefaults->{'CAN_LAMP_STRATEGY'}{ $expected_ref->{$strategy_key} } ) {
            # map strategy to expected lamp behavoiur
            # S_w2log( 3, "  => expected lamps found in ProjectDefaults->{'CAN_LAMP_STRATEGY'}{".$expected_ref->{$strategy_key}."}\n" );
            # %$expected_ref = %{$main::ProjectDefaults->{'CAN_LAMP_STRATEGY'}{ $expected_ref->{$strategy_key} } };
        # }
        # else { S_set_error( "CAN lamp mapping failed for strategy ".$expected_ref->{$strategy_key}, 20); }
   # }

   # my $expected_lamp_eval_line;
   # my $detected_lamp_eval_line;

   # $fault_flag = 1;
   ## ----------------------------------------------------------------------------------------
   # step through whole hash %expected
   # foreach my $lamp ( sort keys %$expected_ref) {

       # $lamp_res_expect = $expected_ref->{$lamp};

       # if( $real_lamp = $main::ProjectDefaults->{'LABEL_MAPPING'}{$lamp} ) {
           # S_w2log( 5, " CA_check_can_lamps : $lamp (mapped) is $real_lamp (real) (out of LABEL_MAPPING) \n" );
           # $lamp = $real_lamp;
       # }
       # unless( exists $result_ref->{$lamp} ) {
           # S_set_error( " CA_check_can_lamps : Expected lamp '$lamp' not in given lamps results \n", 0 );
           # $fault_flag = 0;
           # next;
       # }
       # $expected_lamp_eval_line .= " $lamp -> $lamp_res_expect";
       # $lamp_res_detect = $result_ref->{$lamp};
       # $detected_lamp_eval_line .= " $lamp -> $lamp_res_detect";
       # if lamp state in result differs from lamp state in expected, delete fault flag
       # if ( $lamp_res_expect eq $lamp_res_detect ) {
          # S_w2log( 4, " CA_check_can_lamps: $lamp is $lamp_res_detect => expected state\n" );
       # }
       # else {
          # S_w2log( 4, " CA_check_can_lamps: $lamp is $lamp_res_detect => FAIL, not expected state ($lamp_res_expect)\n" );
          # $fault_flag = 0;
       # }
    # }
    ## ----------------------------------------------------------------------------------------
     # if ( $get_text_option =~ /get_text/i ) {
         # return ( $fault_flag , $expected_lamp_eval_line , $detected_lamp_eval_line);
    # } else {
         # return $fault_flag;
    # }
# }



=head1 Function Group 'base'


=cut



=head2 CA_init

    $functionAreas_href = CA_init();

Initialize the device(s) for CAN_Access.
The devices are defined in LIFT_testbenches:

    'CAN_Access' => {
       'basic' =>  'CANoe',     # function groups: read, write, trace, simulation
       'stimulate' => 'CANoe',  # function group stimulate
    },

The reason for the differentiation between 'basic' and 'stimulate' is that different libraries are used.

For backwards compatibility the old way of function configuration is also supported, 
but only for the function groups read, write and trace:

    'CAN_Access' => {
	   'read' =>  [ 'CANoe' ],
	   'write' => [ 'CANoe' ],
	   'trace' => [ 'CANoe' ],
    },

The device that is usually used for all function groups is currently 'CANoe'.

=cut

sub CA_init {

    my $functionAreas_href = VEC_init('CAN_Access');
    EQUIP_set_devices( 'CAN_Access', $functionAreas_href );

    my $funcLib_href = S_get_contents_of_hash( [ 'Functions', 'CAN_Access' ], $LIFT_config::LIFT_Testbench );

    foreach my $functionGroup ( keys %{$funcLib_href} ) {
        my $devices_mix       = $funcLib_href->{$functionGroup};
        my $number_of_devices = 0;
        if ( ref($devices_mix) eq 'ARRAY' ) {
            $number_of_devices = @{$devices_mix};
        }
        elsif ( ref($devices_mix) eq '' ) {
            $number_of_devices = 1 if defined $devices_mix;
        }
        else {
            # do nothing
        }
        next if $number_of_devices == 0;

        if ( $functionGroup eq 'read' ) {
            CA_read_configure();
        }
        elsif ( $functionGroup eq 'write' ) {
            CA_write_configure();
        }
        elsif ( $functionGroup eq 'trace' ) {
            CA_trace_configure();
        }
        elsif ( $functionGroup eq 'basic' ) {
            CA_read_configure();
            CA_write_configure();
            CA_trace_configure();

            #CA_simulation_configure ( );
        }
        elsif ( $functionGroup eq 'stimulate' ) {
            CA_stimulate_configure();
        }
        else {
            S_set_error( "Invalid function group '$functionGroup' for 'CAN_Access' in LIFT_Testbenches.pm. Valid function groups are: basic, stimulate ( or read, write, trace ).", 20 );
            return;
        }
    }

    return $functionAreas_href;
}


######################################################

=head2 CA_set_EnvVar_value

 CA_set_EnvVar_value ( EnvVarName, EnvVarValue );

Sets environment value to CANoe.

 expects EnvVarValue as scalar value for EnvVar type Integer, Float, String
 expects EnvVarValue as array_ref if EnvVar type is Data
 Integer and Data may be hex or dec or bin.

 examples :
     CA_set_EnvVar_value('Env_Var_Typ_int', 10);                         # Interger  
     CA_set_EnvVar_value('Env_Var_Typ_Float', 102.25);                   # Float
     CA_set_EnvVar_value('Env_Var_Typ_String', "LRT ENV testing");       # String
     CA_set_EnvVar_value('Env_Var_Typ_Data', [0xA, 0xB, 0xC, 0xD, 0xE]); # Data

=cut

######################################################
sub CA_set_EnvVar_value {
    my @args    = @_;
    my $env_var = shift @args;
    my $value   = shift @args;

    # $value can be of type int, float, string or data
    unless ( defined $value ) {
        S_set_error( " SYNTAX: CAN_set_EnvVar_value ( EnvVarName, EnvVarValue )", 110 );
        return;
    }

    S_w2log( 4, " CA_set_EnvVar_value :: prepare EnvVar '$env_var' to set '$value' value. \n" );

    my @devices = EQUIP_get_devices( 'CAN_Access', 'basic' );
    unless ( scalar @devices ) {
        S_set_error( " CA_set_EnvVar_value : LIFT_Testbenches does not contain Devices for setting Environment variables\n", 21 );
        return;
    }
    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_set_EnvVar_value : LIFT_Testbenches doesnt contain valid devices for setting Environment variables. Please configure 'CANoe'\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {

            # get environment variable object & set the value
            my $handle = VEC_get_env_variable( $CA_control->{'trace'}{$device}{'OLE_handle'}, $env_var );
            VEC_set_EnvVar_value_by_type( $handle, $env_var, $value );
        }
        else {
            S_set_warning(" CA_set_EnvVar_value : not yet supported for this device $device. \n");
        }
    }

    return 1;
}


######################################################

=head2 CA_get_EnvVar_value

 EnvVarValue = CA_get_EnvVar_value ( EnvVarName );

 returns scalar value for EnvVar type Integer, Float, String
 returns array_ref of dec values if EnvVar type is Data
 
  examples :
  $intVal   = CA_get_EnvVar_value('Env_Var_Typ_int');       # Interger  
  $FloatVal = CA_get_EnvVar_value('Env_Var_Typ_Float');     # Float
  $StringVal= CA_get_EnvVar_value('Env_Var_Typ_String');    # String
  $arrRef   = CA_get_EnvVar_value('Env_Var_Typ_Data');      # Data
 

=cut

######################################################
sub CA_get_EnvVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_get_EnvVar_value($env_var)', @args );

    my $env_var = shift @args;
    my $return_env_var_value;
    my @devices = EQUIP_get_devices( 'CAN_Access', 'basic' );
    unless ( scalar @devices ) {
        S_set_error( " CA_get_EnvVar_value : LIFT_Testbenches does not contain Devices for getting Environment variables\n", 21 );
        return;
    }
    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_get_EnvVar_value : LIFT_Testbenches doesnt contain valid devices for getting Environment variables. Please configure 'CANoe'\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {

            # get environment variable value
            my $handle = VEC_get_env_variable( $CA_control->{'trace'}{$device}{'OLE_handle'}, $env_var );
            $return_env_var_value = VEC_get_EnvVar_value_by_type( $handle, $env_var );
        }
        else {
            S_set_warning(" CA_get_EnvVar_value : not yet supported for this device $device. \n");
        }
    }

    return $return_env_var_value;
}


=head2 CA_CAPL_config

    CA_CAPL_config( [@CAPL_functions] );

Configure CAPL function(s) before invoking them.

 This function shall be called before measurement start. 
 (before function 'CA_trace_start' or 'CA_simulation_start') otherwise CAPL functions cannot be registered.
 => CAPL function configuation has below priority:
    1) CAPL function as function arguments.
    2) if 1) is not given then take it from project constant.
 => Function must be present in the CANoe CAPL file.        

 Examples : 
    CA_CAPL_config();
    CA_CAPL_config('MyCAPLFunction1');
    CA_CAPL_config('MyCAPLFunction1', 'MyCAPLFunction2', 'MyCAPLFunction3' ...);

=cut
sub CA_CAPL_config {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_CAPL_config([$capl_functions_aref])', @args );
    my $capl_functions_aref = shift @args;

    S_w2log( 4, " CA_CAPL_config : prepares to configure CAPL Function(s). \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my $device = '';
    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " CA_CAPL_config : no trace configured , use CA_init.", 131 );
        return;
    }
    #
    #  Configure the CAPL function
    #
    my $status ;
    if ( CANoeCtrl_isItInitialized() ) {
        $status = CANoeCtrl_CAPL_config($capl_functions_aref);    # via CANoeCtrl
    }
    else {
        S_set_error( " Function group 'stimulate' for 'CAN_Access' in not configured in LIFT_Testbenches.pm, 'CAN_Access' => { 'stimulate' => 'CANoe' }", 20 );
        return;
    }
    return $status;
}


=head2 CA_CAPL_invoke

    CA_CAPL_invoke( $CAPL_function_to_invoke [,$CAPL_function_args_optional ] );

Invoking of a CAPL function from CANoe.

 Arguments :
    $CAPL_function_to_invoke        :   CAPL function to invoke 
    $CAPL_function_args_optional    :   arguments pass to CAPL function [Optional]
  
 Note : 
 => Before invoking first configure the CAPL functions using 'CA_CAPL_config'.
 => CAPL function must be defined in the CANoe CAPL file.

 Examples : 
    CA_CAPL_invoke( 'MyCAPLFunction' );           # => no arguments passed to CANoe CAPL
    CA_CAPL_invoke( 'MyCAPLFunction1', 10 );      # => argument (10) passed to CANoe CAPL 
    CA_CAPL_invoke( 'MyCAPLFunction2', 10, 20 );  # => argument (10, 20) passed to CANoe CAPL
    CA_CAPL_invoke( 'MyCAPLFunction3' );          # => no arguments passed to CANoe CAPL
    
=cut
sub CA_CAPL_invoke {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_CAPL_invoke($CAPL_function_to_invoke, [, $capl_functions_aref])', @args );

    my $CAPL_function_to_invoke = shift @args;
    my $capl_functions_aref     = shift @args;

    S_w2log( 4, " CA_CAPL_invoke : prepares to invoke CAPL Function(s). \n" );
    return 1 if ($main::opt_offline);    # return 1 in offline

    my $device = '';
    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " CA_CAPL_invoke : no trace configured , use CA_simulation_configure() before", 131 );
        return;
    }

    #
    #  invoke CAPL function
    #
    my ( $status, $returnValCAPL );
    if ( CANoeCtrl_isItInitialized() ) {
        ( $status, $returnValCAPL ) = CANoeCtrl_CallCapl( $CAPL_function_to_invoke, $capl_functions_aref );    # via CANoeCtrl
    }
    else {
        S_set_error( " Function group 'stimulate' for 'CAN_Access' in not configured in LIFT_Testbenches.pm, 'CAN_Access' => { 'stimulate' => 'CANoe' }", 20 );
        $status = 0;
    }

    return $status;
}


######################################################

=head2 CA_set_SysVar_value

    CA_set_SysVar_value( $sys_var, $value );

Sets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array>  to CANoe. 

For configuration refer L</"Functions section:"> of Testbench configuration.

B<Arguments:>

=over

=item $sys_var 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are "Integer, Float, String, Integer Array , Float Array".

MULTIPLE level of namespace are also supported.

=item $value 

value to be set for the system variable. Value can be Integer, Float, String, Integer Array , Float Array.
It depends on what kind of System variable has been defined in the system variable file. Pass it accordingly.

=back

B<Return Value:>

=over

=item Offine & Success = 1

=back

B<Examples:>

    # -----------------------------------
    # exmaples for SINGLE LEVEL NAMESPACE
    # -----------------------------------
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_Type_Int', 0xFF) ;        # set integer value
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_Type_Int', 255) ;         # set integer value
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_Type_Float',  525.25) ;    # set float value
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_Type_String',  "LRT SYSVAR testing") ;   # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    CA_set_SysVar_value('LIFT_CAN_access::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;  

    # -------------------------------------
    # exmaples for MULTIPLE LEVEL NAMESPACE
    # --------------------------------------
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 0xFF) ;      # set integer value
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 255) ;       # set integer value
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float',  525.25) ; # set float value
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String', "LRT SYSVAR testing") ; # set string value
    
    # set float array of 10 data points, all points must be specified
    # Integer dataPoints will be converted to float before set to CANoe
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray',  [1.0, 2, 3, 4, 5.5, 6.4, 2.5, 8.0, 9.0 , 9.5]) ;
       
    # set Integer array 10 data points, all points must be specified
    # Float dataPoints if any will be converted to Integer (removed decimal part) before set to CANoe
    CA_set_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray',  [0, 1, 1, 2.0, 3, 5, 8.1, 11, 19, 30 ]) ;  
    
    # -------------------------------------
    # Example for usage of wait time to read back the system variable value immediately
    # --------------------------------------
    CA_set_sysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int', 0xFF) ; 
    S_wait_ms(200); # Wait time to get the system variable value immediately  

B<Notes:>
 
1) For Integer array & Float Array, B<specify all the values or dataPoints> as defiend in the system variable file. See the variable defination.

2) Multiple level of namespace for System varible are supported.

3) To read back the system variable value immediately, the tester can give a wait time of 30ms to 200ms in TC_LRT_CAN_Access__SystemVariables after CA_set_sysVar_value( $sysVarName, $sysVar_setVal ).  

=cut

######################################################

sub CA_set_SysVar_value {
    my @args    = @_;
    my $sys_var = shift @args;
    my $value   = shift @args;

    unless ( defined $value ) {
        S_set_error( " SYNTAX: CA_set_SysVar_value ( SysVarName, SysVarValue )", 110 );
        return;
    }

    my @devices = EQUIP_get_devices( 'CAN_Access', 'basic' );
    unless ( scalar @devices ) {
        S_set_error( " CA_set_SysVar_value : LIFT_Testbenches does not contain Devices for setting System variables\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_set_SysVar_value : LIFT_Testbenches doesnt contain valid devices for setting System variables. Please configure 'CANoe'\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {
            #
            # get system  variable object
            #
            my $handle = VEC_get_sys_variable( $CA_control->{'trace'}{$device}{'OLE_handle'}, $sys_var );
            VEC_set_SysVar_value_by_type( $handle, $value );
        }
        else {
            S_set_warning(" CA_set_SysVar_value: : not yet supported for this device $device. \n");
        }
    }

    return 1;
}


######################################################

=head2 CA_get_SysVar_value

    $return_sys_var_value = CA_get_SysVar_value( $sys_var );

Gets the value of B<System variable> of type B<Integer, Float, String, Integer Array, Float Array>  from CANoe. 

For configuration refer L</"Functions section:"> of Testbench configuration.

B<Arguments:>

=over

=item $sys_var 

System varible name B<<NAMESPACE::VAR_NAME>> must be defined in the Systme variable file & added to respective CANoe Configuration.
Supported variable types are of type : "Integer, Float, String, Integer Array , Float Array".

=back

B<Return Value:>

=over

=item $return_sys_var_value 

on Success it will return = "Integer, Float, String, Integer Array , Float Array" depends on the type of System variable defined in CANoe (System variable file) .

=item $offline 

Offline return is 1. 

=back

B<Examples:>
  
  # -----------------------------------
  # exmaples for SINGLE LEVEL NAMESPACE
  # -----------------------------------
  $intVal       = CA_get_SysVar_value('LIFT_CAN_access::SysVar_Type_Int') ;       # get integer value  
  $floatVal     = CA_get_SysVar_value('LIFT_CAN_access::SysVar_Type_Float') ;     # get float value
  $stringVal    = CA_get_SysVar_value('LIFT_CAN_access::SysVar_Type_String') ;    # get string value
  $float_aref   = CA_get_SysVar_value('LIFT_CAN_access::SysVar_FloatArray');      # get float array value as array reference
  $integer_aref = CA_get_SysVar_value('LIFT_CAN_access::SysVar_IntegerArray');    # get Integer array value as array reference

  # -------------------------------------
  # exmaples for MULTIPLE LEVEL NAMESPACE
  # --------------------------------------
  $intVal = CA_get_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Int') ;     # get integer value  
  $floatVal = CA_get_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_Float') ;   # get float value
  $stringVal = CA_get_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_Type_String') ;  # get string value
  $float_aref = CA_get_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_FloatArray');    # get float array value as array reference
  $integer_aref = CA_get_SysVar_value('LIFT_CAN_access::MultipleLevel::SysVar_IntegerArray');  # get Integer array value as array reference  

B<Notes:>
 
Multiple level of namespace for System varible are supported.  

=cut

######################################################

sub CA_get_SysVar_value {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_get_SysVar_value ( $sys_var )', @args );

    my $sys_var = shift @args;
    my $return_sys_var_value;

    my @devices = EQUIP_get_devices( 'CAN_Access', 'basic' );
    unless ( scalar @devices ) {
        S_set_error( " CA_get_EnvVar_value : LIFT_Testbenches does not contain Devices for getting System variables\n", 21 );
        return;
    }

    unless ( grep { $_ eq "CANoe" } @devices ) {
        S_set_error( " CA_get_SysVar_value : LIFT_Testbenches doesnt contain valid devices for getting System variables. Please configure 'CANoe'\n", 21 );
        return;
    }

    return 1 if $main::opt_offline;

    foreach my $device (@devices) {
        if ( $device eq "CANoe" ) {

            # get environment variable value
            my $h_sys_var_obj = VEC_get_sys_variable( $CA_control->{'trace'}{$device}{'OLE_handle'}, $sys_var );            
            $return_sys_var_value = VEC_get_SysVar_value_by_type( $h_sys_var_obj, $sys_var );
            S_w2log( 4, " CA_get_SysVar_value SysVar: $sys_var value: $return_sys_var_value\n" );
        }
        else {
            S_set_warning(" CA_get_SysVar_value : not yet supported for this device $device. \n");
        }
    }

    return $return_sys_var_value;
}


######################################################################

=head2 CA_get_can_message_info

    Function Name     :: CA_get_can_message_info
    Description       :: hash reference containing the message info from LIFT CAN Mapping module
    Syntax            :: $can_message_info = CA_get_can_message_info ( $can_message_name );
    Input Arguments   :: $can_message_name - array reference of the CAN message
    Return Value(s)   :: $can_message_info - hash reference containing the message
    Example           :: CA_get_can_message_info ( [ 'Airbag_01','SCU_01' ] );

=cut

######################################################################

sub CA_get_can_message_info
{
    my ($can_message_name) = shift @_;

    my $returned_msg_info;
    my @signals;

    unless ( defined $can_message_name )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_get_can_message_info( $can_message_name )", 110 );
        return {};
    }

    my $CAN_mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_mapping)
    {
        S_set_error( "LIFT CAN_mapping doesnot exist", 20 );
        return {};
    }
    unless ( $returned_msg_info = $CAN_mapping->{'CAN_MESSAGES'}{$can_message_name} )
    {
        S_set_error( " LIFT_CanMapping does not contain info for message : '$can_message_name'", 114 );
        return {};
    }
    foreach my $signal ( keys %$CAN_mapping )
    {
        next unless "HASH" eq ref $CAN_mapping->{$signal};
        push( @signals, $signal ) if $can_message_name eq $CAN_mapping->{$signal}{'MESSAGE'};
    }
    $returned_msg_info->{'CAN_SIGNALS'} = \@signals;

    return $returned_msg_info;
}

######################################################################

=head2 CA_calc_hex_to_phys

    Function Name     :: CA_calc_hex_to_phys
    Description       :: Converts the Hex_Value into its physical Value dependendly on the fromat of the CAN signal given in CAN_Signal_info.
    Syntax            :: $phys_value = CA_calc_hex_to_phys ( $CAN_Signal_info , $Hex_Value );
    Input Arguments   :: $CAN_Signal_info - hash reference containing the signal info from LIFT CAN Mapping module plus the message info
                         $Hex_Value - hex value of the signal
    Return Value(s)   :: $phys_value - it is the physical value of the signal
    Example           :: $phys_value = CA_calc_hex_to_phys ( CAN_Signal_info , Hex_Value );

=cut

######################################################################

sub CA_calc_hex_to_phys
{
    my ( $can_signal_info, $hex_value ) = @_;

    unless ( defined $hex_value )
    {

        S_set_error( " Too Less Params !SYNTAX: CA_calc_hex_to_phys ( $can_signal_info , $hex_value )", 110 );
        return;
    }

    my ( $sig_offset, $sig_type, $sig_factor, $signal_name );

    unless ( $signal_name = $can_signal_info->{'SIGNAL_NAME'} )
    {
        S_set_error( " no 'SIGNAL_NAME' defined for given CAN signal\n", 109 );
        return;
    }
    $sig_offset = $can_signal_info->{'OFFSET'};
    unless ( defined $sig_offset )
    {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_type = $can_signal_info->{'TYPE'};
    unless ( defined $sig_type )
    {
        S_set_error( " no 'TYPE' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_factor = $can_signal_info->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 )
    {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }
    my $phys_value = ( $hex_value * $sig_factor ) + $sig_offset;
    S_w2log( 3, "   Transformation '$signal_name' : $phys_value (phys) = ( $hex_value (hex) * $sig_factor (factor) + $sig_offset (offset) \n" );

    return $phys_value;
}

######################################################################

=head2 CA_calc_phys_to_hex

    Function Name     :: CA_calc_phys_to_hex
    Description       :: Converts the Phys_Value into its Raw Value dependendly from the fromat of the CAN signal given in CAN_Signal_info.
    Syntax            :: $hex_value = CA_calc_phys_to_hex ( $CAN_Signal_info , $phys_Value );
    Input Arguments   :: $CAN_Signal_info - hash reference containing the signal info from LIFT CAN Mapping module plus the message info
                         $Phys_Value - physical value of the signal
    Return Value(s)   :: $hex_value - it is the hex value of the signal
    Example           :: $hex_value = CA_calc_phys_to_hex ( CAN_Signal_info , phys_Value );

=cut

######################################################################

sub CA_calc_phys_to_hex
{
    my ( $can_signal_info, $phys_value ) = @_;

    unless ( defined $phys_value )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_calc_phys_to_hex( $can_signal_info , $phys_value )", 110 );
        return;
    }

    my ( $hex_value, $sig_offset, $sig_type, $sig_factor, $signal_name );

    unless ( $signal_name = $can_signal_info->{'SIGNAL_NAME'} )
    {
        S_set_error( " no 'SIGNAL_NAME' defined for given  CAN signal\n", 109 );
        return;
    }
    $sig_offset = $can_signal_info->{'OFFSET'};
    unless ( defined $sig_offset )
    {
        S_set_error( " no 'OFFSET' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_type = $can_signal_info->{'TYPE'};
    unless ( defined $sig_type )
    {
        S_set_error( " no 'TYPE' defined for signal '$signal_name' \n", 109 );
        return;
    }
    $sig_factor = $can_signal_info->{'FACTOR'};
    unless ( defined $sig_factor and $sig_factor != 0 )
    {
        S_set_error( " no 'FACTOR' defined or '0.0' for signal '$signal_name' \n", 109 );
        return;
    }
    $hex_value = ( $phys_value - $sig_offset ) / $sig_factor;
    S_w2log( 5, "   Transformation '$signal_name' : $hex_value (hex) = ( $phys_value (phys) - $sig_offset (offset) / $sig_factor (factor) \n" );
    return $hex_value;
}



######################################################################

=head2 CA_get_can_signal_info

    Function Name     :: CA_get_can_signal_info
    Description       :: reads the signal info from CAN mapping file.
    Syntax            :: $returned_sig_info = CA_get_can_signal_info ( $CAN_signal_name );
    Input Arguments   :: $CAN_signal_name - CAN signal name as defined in CAN mapping file
    Return Value(s)   :: $returned_sig_info - hash reference
    Example           :: $returned_sig_info = CA_get_can_signal_info ( $CAN_signal_name );

=cut

######################################################################

sub CA_get_can_signal_info
{
    my $can_signal_name = shift;

    my $returned_sig_info;
    my $message;

    unless ( defined $can_signal_name )
    {
        S_set_error( " Too Less Params ! SYNTAX: CA_get_can_signal_info( $can_signal_name )", 110 );
        return {};
    }

    my $CAN_mapping = S_get_contents_of_hash( ['Mapping_CAN'] );

    unless ($CAN_mapping)
    {
        S_set_error( " LIFT CAN_mapping doesnot exist", 20 );
        return {};
    }

    unless ( $returned_sig_info = $CAN_mapping->{$can_signal_name} )
    {
        S_set_error( " LIFT_CanMapping does not contain info for signal : '$can_signal_name'", 114 );
        return {};
    }
    unless ( $message = $returned_sig_info->{'MESSAGE'} )
    {
        S_set_error( " LIFT_CanMapping does not contain 'MESSAGE' for signal : '$can_signal_name'", 114 );
        return {};
    }

    unless ( $returned_sig_info->{'MESSAGE_INFO'} = $CAN_mapping->{'CAN_MESSAGES'}{$message} )
    {
        S_set_error( " LIFT_CanMapping does not contain 'CAN_MESSAGES' info for message 'MESSAGE' for signal : '$message'", 114 );
        return {};
    }
    return $returned_sig_info;
}


=head1 Function Group 'stimulate'


=cut

=head2 CA_stimulate_configure

    CA_stimulate_configure();

Initialize the device(s) for Stimulate signals , CALL CAPL.

    'CAN_Access' => {
       'basic' =>  'CANoe',     # function groups: read, write, trace, simulation
       'stimulate' => 'CANoe',  # function group:  stimulate signals, CALL CAPL 
    },
    
The device that is usually used for all function groups is currently 'CANoe'.

=cut

sub CA_stimulate_configure {
    CANoeCtrl_Init();
    return 1;
}


=head2 CA_stimulate_load_signal_curves

    CA_stimulate_load_signal_curves($busSignal_curves_href, $triggertype);

Loads the bus signal curves to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes, 
software (CA_stimulate_start_now) or hardware (CA_stimulate_start_with_external_trigger). 

  Inputs :
    $busSignal_curves_href = hash reference  containing the signal name, sample time and signal values.
    $triggertype = 'Triggersoft' or 'Triggerhard'
    
  Prerequiste : 
    => prepare CANoeCtrl mapping.
    => prepare the CAPL files (assign it to system variable and the signal name from CAN / FlexRay database).
       template is availble here : 
       g:/MKS/Projects/TurboLIFT/System/develop/develop.pj 
       /develop/CANoeCtrl/CANoeCtrl_Control/template/nodes/CREIS/CREIS.can
    
    
  Remark :
    => This function shall be called before CANoe measurement starts (start of RBS)  
       (in case measurement is running then it will stopped and signal shall be configured)
    => The signal is identified by an index, the mapping to the corresponding signal must be done in the CAPL program of the network node.
       Signal indices must be continuous, starting at 0. 
       

  Example:
    $busSignal_curves_href = {
        'SigStimulus1_CAN' => {
            'SAMPLETIME_US'=> 10000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
        'SigStimulus2_CAN' => {
            'SAMPLETIME_US'=> 20000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
         ...
    };

    CA_stimulate_load_signal_curves($busSignal_curves_href, 'Triggersoft');
    CA_stimulate_load_signal_curves($busSignal_curves_href, 'Triggerhard');
    
=cut

sub CA_stimulate_load_signal_curves {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_stimulate_load_signal_curves ($busSignal_curves_href, $triggertype)', @args );

    my $busSignal_curves_href = shift @args;
    my $triggertype           = shift @args;    # Triggersoft or Triggerhard

    S_w2log( 4, "CA_stimulate_load_signal_curves ->  \n" );

    my ( $device, $status );

    # STEP check configured device 'CANoe' before stimulating the signals 
    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configure() before", 0 );
        unless ( CA_trace_configure() ) {
            S_set_error( " CA_stimulate_load_signal_curves : couldnot configure trace\n", 131 );
            return;
        }
    }

    return 1 if ($main::opt_offline);    # return 1 in offline

    # STEP stop the measurement if running before
    if ( VEC_check_running( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
        unless ( VEC_stop_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
            S_set_error( " CA_stimulate_load_signal_curves : Could not stop $device measurement", 131 );
            return;
        }
    }

    my $sysVar_SVNumSignals_value = CA_get_SysVar_value("Stimulus::SVNumSignals");

    # STEP Configure all signals
    foreach my $signal_curve_name ( keys %{$busSignal_curves_href} ) {

        my $sampleTime_US = $busSignal_curves_href->{$signal_curve_name}{'SAMPLETIME_US'};
        my $dataPtsCount  = scalar( @{ $busSignal_curves_href->{$signal_curve_name}{'SIGNALS'} } );

        S_w2log( 4, " $signal_curve_name => SAMPLING RATE = $sampleTime_US us, DataPoints count = $dataPtsCount \n" );

        my $signal_indx                 = CANoeCtrl_rdPrjConst_signalIndex($signal_curve_name);
        my $sysVar_outputSignal         = "Stimulus::SVSignalValues" . "$signal_indx";
        my $max_dataPts_SysVarFile_aref = CA_get_SysVar_value($sysVar_outputSignal);

        # CALL LIFT_CANoeCtrl::CANoeCtrl_loadSignalCurve
        CANoeCtrl_loadSignalCurve(
            {
                'signal_name'         => $signal_curve_name,
                'signal_data'         => $busSignal_curves_href->{$signal_curve_name}{'SIGNALS'},
                'sysVar_name'         => $sysVar_outputSignal,
                'sysVar_max_dataPts'  => scalar @$max_dataPts_SysVarFile_aref,
                'sysVar_SVNumSignals' => scalar @$sysVar_SVNumSignals_value,
                'sampleTime_ms'       => $busSignal_curves_href->{$signal_curve_name}{'SAMPLETIME_US'} / 1000,
                'trigger_type'        => $triggertype,
            }
        );

    }
    
    unless ( CANoeCtrl_SetSystemVariablesValues() ) {
        S_set_error( " CA_stimulate_load_signal_curves : failed to set System variables.\n", 131 );
        return;
    }

    S_w2log( 4, "CA_stimulate_load_signal_curves -> done \n" );

    return 1;
}


=head2 CA_stimulate_reset_signal_curves

    CA_stimulate_reset_signal_curves();

Resets the signal curve. Shall be called before 'CA_stimulate_load_signal_curves'.  

=cut

sub CA_stimulate_reset_signal_curves {
    unless ( CANoeCtrl_ResetOutputSignal() ) {
        S_set_error( " CA_stimulate_reset_signal_curves : failed to reset output signals.\n", 131 );
        return;
    }

    return 1;
}


=head2 CA_stimulate_load_timed_signals

    CA_stimulate_load_timed_signals($signal_name, $signal_setValue_1, $triggertype , [$timeshift_ms, $signal_setValue_2]);

The signal value will be set to value1 when the trigger occurs, and optional (if timeshift > 0) to value2 after further <timeshift> milliseconds.
Loads the timed signal curves to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes, 
software (CA_stimulate_start_now) or hardware (CA_stimulate_start_with_external_trigger).

  Inputs :
    $busSignal_curves_href = hash reference  containing the signal name, sample time and signal values.
    $Triggertype = 'Triggersoft' or 'Triggerhard'
    
  Prerequiste : 
    => prepare CANoeCtrl mapping.
    => prepare the CAPL files (assign it to system variable and the signal name from CAN / FlexRay database).
       template is availble here : 
       g:/MKS/Projects/TurboLIFT/System/develop/develop.pj 
       /develop/CANoeCtrl/CANoeCtrl_Control/template/nodes/CREIS/CREIS.can
    
    
  Remark :
    => This function shall be called before CANoe measurement starts (start of RBS)  
       (in case measurement is running then it will stopped and signal shall be configured)
    => The signal is identified by an index, the mapping to the corresponding signal must be done in the CAPL program of the network node.
       Signal indices must be continuous, starting at 0.

  Example:
    CA_stimulate_load_timed_signals( 'SigTimed1_CAN', '45.25', 'Triggersoft',  '500', '100.55')  ;
    CA_stimulate_load_timed_signals( 'SigTimed1_CAN', '45.25', 'Triggerhard',  '500', '100.55')  ;
    CA_stimulate_load_timed_signals( 'SigTimed1_CAN', '45', 'Triggersoft',  0, 0)  ;
    CA_stimulate_load_timed_signals( 'SigTimed1_CAN', '45', 'Triggerhard',  0, 0)  ;
    
=cut

sub CA_stimulate_load_timed_signals {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_stimulate_load_timed_signals ($signal_name, $signal_setValue_1, $triggertype , [$timeshift_ms, $signal_setValue_2])', @args );

    my $signal_name       = shift @args;
    my $signal_setValue_1 = shift @args;
    my $triggertype       = shift @args;
    my $timeshift_ms      = shift @args;
    my $signal_setValue_2 = shift @args;

    S_w2log( 4, "CA_stimulate_load_timed_signals :  $signal_name \n" );

    my ($device);

    unless ( $device = $CA_control->{'trace'}{'Devices'}[0] ) {
        S_set_error( " no trace configured , use CA_trace_configure() before", 0 );
        unless ( CA_trace_configure() ) {
            S_set_error( " CA_stimulate_load_timed_signals : couldnot configure trace\n", 131 );
            return;
        }
    }

    return 1 if ($main::opt_offline);    # return 1 in offline

    ## stop the measurement if running before
    if ( VEC_check_running( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
        unless ( VEC_stop_measurement( $CA_control->{'trace'}{$device}{'OLE_handle'} ) ) {
            S_set_error( " CA_stimulate_load_signal_curves : Could not stop $device measurement", 131 );
            return;
        }
    }

    unless ( CANoeCtrl_SetTimedSignal( $signal_name, $signal_setValue_1, $triggertype, $timeshift_ms, $signal_setValue_2 ) ) {
        S_set_error( " CA_stimulate_load_timed_signals : failed to configure timed signals for the signal '$signal_name'. \n", 131 );
        return;
    }

    unless ( CANoeCtrl_SetSystemVariablesValues() ) {
        S_set_error( " CA_stimulate_prepare_inject_signals_start_RBS : failed to set System variables.\n", 131 );
        return;
    }

    return 1;
}


=head2 CA_stimulate_start_now

    CA_stimulate_start_now();

Starts the output of the configured signals curvers or timed signals on software trigger.
This function can only be called when measurement (RBS) is running, otherwise it has no effect and 0 is returned.

  Example:
    CA_stimulate_start_now()  ;

=cut

sub CA_stimulate_start_now {
    S_w2log( 4, "CA_stimulate_start_now \n" );

    unless ( CANoeCtrl_EnableOutputTriggers() ) {
        S_set_error( " CA_stimulate_start_now : failed to enable trigger.\n", 131 );
        return;
    }

    unless ( CANoeCtrl_SetSoftwareTrigger() ) {
        S_set_error( " CA_stimulate_start_now : failed to set software trigger.\n", 131 );
        return;
    }

    return 1;
}

=head2 CA_stimulate_start_with_external_trigger

    CA_stimulate_start_with_external_trigger();

Starts the output of the configured signals curvers or timed signals on hardware trigger.
This function can only be called when measurement (RBS) is running, otherwise it has no effect and 0 is returned.

  Example:
    CA_stimulate_start_with_external_trigger()  ;

=cut

sub CA_stimulate_start_with_external_trigger {
    S_w2log( 4, "CA_stimulate_start_with_external_trigger \n" );

    unless ( CANoeCtrl_EnableOutputTriggers() ) {
        S_set_error( " CA_stimulate_start_with_external_trigger : failed to enable trigger.\n", 131 );
        return;
    }

    ##
    # External trigger will be received be CAN hardware (from Quate)
    # Settings for the external trigger has to be made in the CANoe configuration
    ##

    return 1;
}


=head1 not exported functions


=cut

=head2 CA_isFunctionGroup_CANAccess_configured

    $funcGrpStatus = CA_isFunctionGroup_CANAccess_configured ( $fnGrp_CAN_access );

Does the check if function group '$fnGrp_CAN_access' of CAN_Access is configured in test bench. 

 $fnGrp_CAN_access : read, write, trace, stimulate

 If the return status of $fnGrp_CAN_access == 0 then below might be two reasons :
 1) below Testbench configuration is missing 
   'CAN_Access' => {
      'basic' =>  'CANoe',     # function groups: read, write, trace, simulation
      'stimulate' => 'CANoe',  # function group 
 },

 2) call of EQUIP_init_testbench() was not done

=cut
sub CA_isFunctionGroup_CANAccess_configured {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_isFunctionGroup_CANAccess_configured ( $fnGrp_CAN_access  )', @args );

    my $fnGrp_CAN_access = shift @args;    # function group for CAN_access : 'read, write, trace, stimulate',

    my $funcGrpStatus = 1;                 ## assumption -> its present
    unless ( EQUIP_get_devices( 'CAN_Access', $fnGrp_CAN_access ) ) {
        S_set_error( "Function group '$fnGrp_CAN_access' for 'CAN_Access' not found. 1) Check testbench for 'CAN_Access' or 2) you forgot to call 'EQUIP_init_testbench'.", 131 );
        $funcGrpStatus = 0;                ## assumption was wrong
    }

    return $funcGrpStatus;
}

=head2 CA_set_RBS_control_mode

    CA_set_RBS_control_mode();

set the RBS mode. Used to decide CANoe trace logging On/Off.

=cut
sub CA_set_RBS_control_mode {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_set_RBS_control_mode ( $device, $flag_RBS_control_mode  )', @args );

    my $device                = shift @args;
    my $flag_RBS_control_mode = shift @args;

    $CA_control->{'trace'}{$device}{'RBS'}{'RBS-control-mode'} = $flag_RBS_control_mode;
    return 1;
}

=head2 CA_set_RBS_control_mode

    CA_get_RBS_control_mode();

gets the RBS mode. Used to decide CANoe trace logging On/Off.

=cut

sub CA_get_RBS_control_mode {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CA_get_RBS_control_mode ( $device )', @args );

    my $device = shift @args;
    return $CA_control->{'trace'}{$device}{'RBS'}{'RBS-control-mode'};
}

######################################################

=head2 CA_logging_start

    CA_logging_start ( );

This API enables the logging of the Trace into a log file via system variable.
 
 used System variable is "SysVar_logging_control" under namespace "LIFT_CAN_access".
 
the user have to configure a .asc/.blf/.mdf file as log file in the measurement setup in CANoe configuration.

=cut

######################################################
sub CA_logging_start {
    CA_set_SysVar_value( 'LIFT_CAN_access::SysVar_logging_control', 1 );
    return 1;
}


######################################################

=head2 CA_logging_stop

    CA_logging_stop ( );

This API disables the logging of the Trace into a log file via system variable.

 used System variable is "SysVar_logging_control" under namespace "LIFT_CAN_access".
 
the user have to configure a .asc/.blf/.mdf file as log file in the measurement setup in CANoe configuration.

=cut

######################################################
sub CA_logging_stop {
    CA_set_SysVar_value( 'LIFT_CAN_access::SysVar_logging_control', 0 );
    return 1;
}


1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut
