# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_ProdDiag_AB12;

use strict;
use warnings;
use LIFT_general;
use LIFT_stringProcessing;
use LIFT_functional_layer;
use LIFT_numerics;
use File::Basename;
use File::Path 'make_path';
use File::Slurp;
use Storable 'dclone';
use HTML::Table;
use Data::Dumper;
use Digest::MD5;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  PRD12_init
  PRD12_exit
  PRD12_Send_Request_Wait_Response
  PRD12_Get_ECU_Details
  PRD12_ECU_Login
  PRD12_ECU_Status
  PRD12_Get_ECU_Properties
  PRD12_Get_Fast_Diagnosis_Data
  PRD12_SW_Reset
  PRD12_Read_Fault_Memory
  PRD12_Clear_Fault_Memory
  PRD12_Manipulate_Fault_Memory
  PRD12_Freeze_Fault_Memory
  PRD12_Start_Fast_Diagnosis
  PRD12_Stop_Fast_Diagnosis
  PRD12_Get_Fast_Diagnosis_Data
  PRD12_Read_EDR
  PRD12_Clear_EDR
  PRD12_Dump_Memory_To_File
  PRD12_Electronic_Firing_Enable
  PRD12_Electronic_Firing_Fire
  PRD12_Sensor_Verification
  PRD12_Read_Cell
  PRD12_Write_Cell
  PRD12_Set_Device_Configuration
  PRD12_Get_Device_Configuration
  PRD12_Read_NVM_cells
  PRD12_Write_NVM_cells
  PRD12_Get_Symbol_Mapping
  PRD12_Check_ECU_Properties
  PRD12_Get_Device_Property
  PRD12_Read_ECU_NVM
  PRD12_Get_Last_Response
  PRD12_AIO_Test_Pattern
  PRD12_Set_Secure_PIN
  PRD12_Read_ASIC_Serial_Numbers
  PRD12_Read_ECU_LifeCycle_Data
  PRD12_Switch_ECU_LifeCycle
  PRD12_SHEKeyCalculatorProtocol
  PRD12_Get_Signature_from_KMS
  PRD12_Do_Initial_Login
  PRD12_Enable_KMS_Simulator
  PRD12_SetAutoLogin
);

our ( $VERSION, $HEADER );

Readonly::Hash my %LAMPSTATE => {
	#system warning lamp state indicators for CA and JLR
	'rb_wimi_SysWIStatusOff_e'        => 'Off',
	'rb_wimi_SysWIStatusOn_e'         => 'On',
	'rb_wimi_SysWIInvalidData_e'      => 'Invalid data. Device is unable to generate valid data (faulty device).',
	'rb_wimi_SysWIDataNotAvailable_e' => 'Data Not Available. Device is not configured.',
	'rb_wimi_SysWIStatusMax_e'        => 'Length of the SysWI status enum',
	
	#passenger airbag state indicators for CA and JLR
	'rb_wimi_PAOxStatusOff_e'         => 'Off',
    'rb_wimi_PAOxStatusOn_e'          => 'On',
    'rb_wimi_PAOxInvalidData_e'       => 'Invalid data. Device is unable to generate valid data (faulty device).',
    'rb_wimi_PAOxDataNotAvailable_e'  => 'Data Not Available. Device is not configured.',
    'rb_wimi_PAOxStatusMax_e'         => 'Length of the PAOx status enum',
    
    #Daimler - system warning lamp state indicators
    'rb_wima_WLStatusOff_e'           => 'Off',
    'rb_wima_WLStatusOn_e'            => 'On',
    'rb_wima_WLStatusBlink_e'         => 'Warning lamp is blinking.',
    'rb_wima_WLDataNotAvailable_e'    => 'Warning lamp status is not available.',
    'rb_wima_WLStatusMax_e'           => 'Status max. value',
    
    # Daimler - passenger airbag state indicators
    'rb_wimi_PAOxStatusOff_e'         => 'Off',
    'rb_wimi_PAOxStatusOn_e'          => 'On',
    'rb_wimi_PAOxInvalidData_e'       => 'Invalid data. Device is unable to generate valid data (faulty device).',
    'rb_wimi_PAOxDataNotAvailable_e'  => 'Data Not Available. Device is not configured.',
    'rb_wimi_PAOxStatusMax_e'         => 'Length of the PAOx status enum'
};

=head1 NAME

LIFT_ProdDiag_AB12 

=head1 SYNOPSIS

    use LIFT_ProdDiag_AB12

    $ecuDetails_href = PRD12_init();
    $success = PRD12_exit();
    $response_href = PRD12_Send_Request_Wait_Response( $request_aref [, $options_href ] );
    $success = PRD12_Send_Request_No_Wait( $request_aref [, $options_href ] );
    $ecuDetails_href = PRD12_Get_ECU_Details($romcode);
    $response_href = PRD12_ECU_Login();
    $ecuStatus_href = PRD12_ECU_Status();
    $ecu_properties_href = PRD12_Get_ECU_Properties($options_href);
    $success = PRD12_SW_Reset( $resetType );
    $faultMemory_href = PRD12_Read_Fault_Memory( $faultType );
    $success = PRD12_Manipulate_Fault_Memory( $manipulationConfig_href );
    $success = PRD12_Clear_Fault_Memory( $mode, $wait_timeout );
    $success = PRD12_Set_Device_Configuration( $devices_modes_href  [, $options_href ] );
    $device_config_href = PRD12_Get_Device_Configuration( [,$options_href] );
    $success = PRD12_Freeze_Fault_Memory();
    $csv_data_file_path = PRD12_Start_Fast_Diagnosis( $fastDiagConfig_href );
    $success = PRD12_Stop_Fast_Diagnosis();
    $fdData_href = PRD12_Get_Fast_Diagnosis_Data([, $options_href ]);
    $response_href = PRD12_Read_EDR( $did [, $options_href ]);
    $response_href = PRD12_Clear_EDR( $options_href );
    $fileName = PRD12_Dump_Memory_To_File( $memoryType [, $options_href ] );
    $success = PRD12_Electronic_Firing_Enable([$options_href]);
    $firingStatus_href = PRD12_Electronic_Firing_Fire();
    $smiData_href = PRD12_Sensor_Verification( $smiConfig_href );
    $cellContents_aref = PRD12_Read_Cell( $label[, $options_href] );
    $success = PRD12_Write_Cell( $label, $cellContents_aref );
    $nvmContents_aref = PRD12_Read_NVM_cells( $blockConfig_href );
    $success = PRD12_Write_NVM_cells( $blockConfig_href, $nvmContents_aref );
    $nvmMemoryContents_aref = PRD12_Read_ECU_NVM( $nvmConfig_href );    
    $response_href = PRD12_Get_Last_Response();
    $success = PRD12_AIO_Test_Pattern();
    $success = PRD12_Set_Secure_PIN();
    $serialNumbers_href = PRD12_Read_ASIC_Serial_Numbers( [$options_href] );
    $response_href = PRD12_Read_ECU_LifeCycle_Data();
    $response_href = PRD12_Switch_ECU_LifeCycle( $options_href );
    $response_href = PRD12_SHEKeyCalculatorProtocol( $options_href );
    $signature_aref = PRD12_Get_Signature_from_KMS( $challenge_aref );
    $success = PRD12_Enable_KMS_Simulator([$kms_simulator_mode]);
    $success = PRD12_SetAutoLogin(1)
    
    Note: Currently, the Lamp_status enums with comments are defined only for Core Asset, JLR and Daimler. Please contact TurboLIFT Team to add your project specific Lamp_State enums.

=cut

my $functionMapping_href = {
    'base' => {
        'PDLayer' => {
            'PRD12_init' => 'PDL_init',
            'PRD12_exit' => 'PDL_exit',
        },
    },
    'basic' => {
        'PDLayer' => {
            'PRD12_ECU_Login'                                      => 'PDL_EcuLogin',
            'PRD12_Get_ECU_Details'                                => 'PDL_GetECUDetails',
            'PRD12_Send_Request_Wait_Response'                     => 'PDL_send_request_wait_response',
            'PRD12_Read_Fault_Memory'                              => 'PDL_ReadFaultMemory',
            'PRD12_Read_Cell'                                      => 'PDL_Read_Memory',
            'PRD12_Write_Cell'                                     => 'PDL_Write_Memory',
            'PRD12_Clear_Fault_Memory'                             => 'PDL_ClearFaultMemory',
            'PRD12_Manipulate_Fault_Memory'                        => 'PDL_ManipulateFaultMemory',
            'PRD12_SW_Reset'                                       => 'PDL_EcuReset',
            'PRD12_Read_EDR'                                       => 'PDL_ReadEdr',
            'PRD12_Clear_EDR'                                      => 'PDL_ClearEdr',
            'PRD12_Start_Fast_Diagnosis'                           => 'PDL_FastDiagnosis',
            'PRD12_Stop_Fast_Diagnosis'                            => 'PDL_StopReadFastdiagData',
            'PRD12_ECU_Status'                                     => 'PDL_EcuStatus',
            'PRD12_SMI7_Sensor_Verification'                       => 'PDL_Smi7Verification',
            'PRD12_Electronic_Firing_Enable'                       => 'PDL_EnableSafetyPath',
            'PRD12_Electronic_Firing_Fire'                         => 'PDL_FireAllDevices',
            'PRD12_Freeze_Fault_Memory'                            => 'PDL_FreezeFaultMemory',
            'PRD12_Read_NVM_cells'                                 => 'PDL_ReadNvmDatabyID',
            'PRD12_Write_NVM_cells'                                => 'PDL_WriteNvmDatabyID',
            'PRD12_Get_Last_Response'                              => 'PDL_get_last_response',
            'PRD12_AIO_Test_Pattern'                               => 'PDL_ActivateAIO',
            'PRD12_Set_Secure_PIN'                                 => 'PDL_SetSecurePIN',
            'PRD12_Read_ASIC_Serial_Numbers'                       => 'PDL_ReadASICSerialNumbers',
            'PRD12_SMI8_Sensor_Verification_StartRoutine'          => 'PDL_SMI8SMA7VerificationStartRoutine',
            'PRD12_SMI8_Sensor_Verification_RequestRoutineResults' => 'PDL_SMI8SMA7VerificationRequestRoutineResults',
            'PRD12_Read_ECU_LifeCycle_Data'                        => 'PDL_ReadECULifeCycle',
            'PRD12_Switch_ECU_LifeCycle'                           => 'PDL_SwitchECULifeCycle',
            'PRD12_SHEKeyCalculatorProtocol'                       => 'PDL_SHEKeyCalculatorProtocol',
            'PRD12_Get_Signature_from_KMS'                         => 'PDL_ReceiveResponseFromKMS',
            'PRD12_Enable_KMS_Simulator'                           => 'PDL_Enable_KMS_Simulator',
            'PRD12_SetAutoLogin'                                   => 'PDL_SetAutoLogin',
        },
    },
};

my @availableTestbenchFunctionGroups = qw{ base basic };
my $prd12Handle_href;
my $symbolMapping_href;
my $prd12StoreVar_href = {};
my $allDevDetails_href = {};
my $ecu_details_href   = {};
my $fastDiagActive;
my $busParams_href;

Readonly::Scalar my $FAULT_NAME_MAPPING => {
    PLANT       => 0,
    PRIMARY     => 1,
    BOSCH       => 3,
    DISTURBANCE => 4
};

# DO NOT USE THIS FOR ANY OTHER COMPUTATIONS EXCEPT TO PRINT TO HTML
Readonly::Scalar my $FAULT_ATTR_LIST_HOA => {
    'BOSCH' => [
        'FaultID', 'DTC', 'FaultName', 'EventDebug_Data_HB', 'EventDebug_Data_LB', 'ASIC_Temperature', 'AlwaysCleared',
        'Squib_fired_in_the_current_POC',
        'DIS_ALP_Low_side_power_lines_disabled',
        'Algo_active', 'VUp_OutOfRange_present', 'VBat_OutOfRange_present', 'InitMode_active', 'IdleMode_active', 'QualificationTime', 'DequalificationTime', 'Qualification_PowerOn_Cycle', 'Dequalification_PowerOn_Cycle',
        'OccurrenceCounter', 'Test_Failed', 'Test_not_Failed', 'GeneralStatus', 'Status'
    ],
    'PRIMARY' =>
      [ 'FaultID', 'DTC', 'FaultName', 'Warning_lamp_indicator', 'Test_not_completed_this_operation_cycle', 'Test_failed_since_last_clear', 'Test_not_completed_since_last_clear', 'Confirmed_DTC_Stored', 'Pending', 'Test_failed_this_operation_cycle_Latched', 'Test_failed_Filtered', 'Status' ],
    'PLANT' =>
      [ 'FaultID', 'DTC', 'FaultName', 'Warning_lamp_indicator', 'Test_not_completed_this_operation_cycle', 'Test_failed_since_last_clear', 'Test_not_completed_since_last_clear', 'Confirmed_DTC_Stored', 'Pending', 'Test_failed_this_operation_cycle_Latched', 'Test_failed_Filtered', 'Status' ],
    'DISTURBANCE' => [
        'FaultID', 'DTC', 'FaultName', 'TestDisturbed', 'TestCurrent', 'EventDebug_Data_HB', 'EventDebug_Data_LB', 'DisturbaneceCounter', 'AlwaysCleared',
        'Squib_fired_in_the_current_POC',
        'DIS_ALP_Low_side_power_lines_disabled',
        'Algo_active', 'VUp_OutOfRange_present', 'VBat_OutOfRange_present', 'InitMode_active', 'IdleMode_active', 'GeneralStatus', 'Status'
    ],
};

Readonly::Scalar my $GENERALSTATUS_AREF => [ 'Squib_fired_in_the_current_POC', 'DIS_ALP_Low_side_power_lines_disabled', 'Algo_active', 'VUp_OutOfRange_present', 'VBat_OutOfRange_present', 'InitMode_active', 'IdleMode_active' ];

Readonly::Scalar my $ISO_AREF => [ 'Warning_lamp_indicator', 'Test_not_completed_this_operation_cycle', 'Test_failed_since_last_clear', 'Test_not_completed_since_last_clear', 'Confirmed_DTC_Stored', 'Pending', 'Test_failed_this_operation_cycle_Latched', 'Test_failed_Filtered' ];

Readonly::Scalar my $MAX_ASIC_ID => 1;    # starts with 0

Readonly::Scalar my $MAX_ASIC_CHANNEL_SWITCH => 11;    # starts with 0

# refer SRS https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-O-1980-0003ea7f
Readonly::Scalar my $ECULIFECYCLE_STATES_HREF => {
    'IN_FIELD_1'                   => 1,
    'IN_FIELD_2'                   => 2,
    'TEMPORARY'                    => 3,
    'PRIVELEDGED_MODE_SERIAL'      => 4,
    'PRIVELEDGED_MODE_DEVELOPMENT' => 5,
    'DEBUG'                        => 14,
    'PRODUCTION'                   => 15,
    'RETURN'                       => 127,
};

my $deviceConfig_href = {
    'DEVICE_CONFIG_VARIABLES' => {
        'AB12' => {
            'lamps' => {
                'enum'       => 'rb_syco_AOuts_ten',
                'monitored'  => 'rb_syco_SysConfAOutEeData_dfst.AoutMonitored_ab8',
                'real'       => 'rb_syco_AOutPresence_ab8',
                'configured' => 'rb_syco_SysConfAOutEeData_dfst.AoutConfigured_ab8',
            },
            'squibs' => {
                'enum'               => 'rb_sycf_SquibDevice_ten',
                'monitored'          => 'rb_sycf_SysConfSquib_dfst.SquibMonitored_ab8',
                'real'               => 'rb_sycf_SquibPresence_ab8',
                'configured'         => 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8',
                'asic_configuration' => 'rb_sqm_SQMLoopConfigSettings_st.SQMLoopConfig_au16',    #  UWORD = rb_sqm_SQMLoopConfigSettings_st.SQMLoopConfig_au16($device_index)
            },

            'SpBehaviour' => {
                'enum'       => 'rb_sycg_StaticBitPositions_ten',
                'configured' => 'rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8',
            },
            'parSections' => {
                'enum'       => 'rb_sycg_DynamicBitPositions_ten',
                'configured' => 'rb_sycg_DynamicBehaviorBits_dfst.rb_sycg_DynamicBits_ab8',
            },
            'pases' => {
                'enum'               => 'rb_sycp_SensorChannels_ten',
                'monitored'          => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelMonitored_ab8',
                'real'               => 'rb_sycp_PsPresence_ab8',
                'configured'         => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelConfigured_ab8',
                'asic_configuration' => 'rb_psem_PsemNvmCfgData_st.SensorToAsicMap_aen',
                'asic_chnl_config'   => 'rb_psem_PsemNvmCfgData_st.SensorToLineMap_aen'
            },
            'switches' => {
                'enum'               => 'rb_sycs_SwitchDevices_ten',
                'monitored'          => 'rb_sycs_SysConfSwmEeData_dfst.SwitchMonitored_ab8',
                'real'               => 'rb_sycs_SwitchPresence_ab8',
                'configured'         => 'rb_sycs_SysConfSwmEeData_dfst.SwitchConfigured_ab8',
                'asic_configuration' => 'rb_swm_ChannelToSwitchRelation_aaen',
            },
            'asics' => {
                'enum'       => 'rb_syca_AllAsics_ten',
                'real'       => 'rb_syca_AsicPresence_ab8',
                'configured' => 'rb_syca_SysConfAsicEeData_dfst.AsicConfigured_ab8',
            },
        },
    },
};

=head1 DESCRIPTION

This is a device independant and generation dependant module for AB12 for production diagnosis

=head1 CONFIGURATION

B<See documentation of higher level module>

=for html
<a href='LIFT_ProdDiag.html#CONFIGURATION'>LIFT_ProdDiag documentation</a>
<br><br>


=head1 FUNCTIONS

=head2 PRD12_init

    $ecuDetails_href = PRD12_init( $initConfig_href );

Get bus type and communication parameters from project data (L</"CONFIGURATION">).

Read all required files (SAD, CNS, FLT and NVM) and create necessary symbol mapping.

Initialize the diagnosis tool.

Do initial login with ECU.

Return ECU details like SW version, etc.

B<Arguments:>

=over

=item $initConfig_href

 {setSecurePIN => 0|1}
 
If setSecurePIN = 1 then PRD12_Set_Secure_PIN is called before login in order to get the PIN for the smartcard for secure login.

 {setInitialLogin => 0|1}
 
If setInitialLogin = 0 then PRD_Disable_Initial_Login is called before PRD_init so that ECU login is not done with this function.  

by default setInitialLogin is 1. So ECU login is done.

 {enableKMSsimulator =>1|0}

If enableKMSsimulator = 1 then PRD12_Enable_KMS_Simulator is called before login so that instead of real KMS, simulator KMS is used.

By defualt value of enableKMSsimulator is 0.

If setAutoLogin = 0 then PRD12_SetAutoLogin is called after communication is initialised so that auto login is disabled.

=back

B<Return Values:>

=over

=item $ecuDetails_href on success

    $ecuDetails_href = {
        'EcuGeneration'    => 12,
        'PdVersionNr'      => 8,
        'DMC_PlantID'      => plant_id,
        'DMC_LineID'       => line_id,
        'DMC_CounterID'    => counter_id,
        'DMC_Date'         => date,
        'DMC_PartNumber'   => part_num,
        'EcuSwVersion'     => SW_version,
        'ECU_FingerPrint'  => finger_print,
        'Algo_Param_ID'    => algo_id,
        'Variant_Version'  => variant_ver,
        'Variant_ID'       => variant_id,
    };  
        
=item undef on failure

=back

B<Examples:>

    $ecuDetails_href = PRD12_init();

=cut

sub PRD12_init {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_init( $initConfig_href )', @args ) or return;

    my $initConfig_href = shift @args;

    S_w2log( 2, "PRD12_init: Starting initialization of ProdDiag for AB12...\n" );
    if ( defined $prd12Handle_href ) {
        S_w2log( 3, "PRD12_init : already initialized! Nothing to do...\n" );
        return;
    }

    #STEP Copy testbench functions config data from 'ProdDiag' to virtual function 'ProdDiag_AB12'
    my $prodDiagFunctions_href = S_get_contents_of_hash( [ 'Functions', 'ProdDiag' ], $LIFT_config::LIFT_Testbench ) || return;
    $LIFT_config::LIFT_Testbench->{'Functions'}{'ProdDiag_AB12'} = dclone $prodDiagFunctions_href;
    delete $LIFT_config::LIFT_Testbench->{'Functions'}{'ProdDiag_AB12'}{'generation'};
    $LIFT_config::LIFT_Testbench->{'Functions'}{'ProdDiag_AB12'}{'base'} = $prodDiagFunctions_href->{'basic'};

    #CALL GetCommunicationParameters to read the neccessary parameters
    $busParams_href = GetCommunicationParameters() || return;

    my $communicationParameters_href = $busParams_href->{'COMMPARAMS'};
    my $sad_filePath                 = $busParams_href->{'SADFILEPATH'};
    my $busType                      = $busParams_href->{'BUSTYPE'};

    #CALL Create_Symbol_Mapping to parse SAD, NVM, FLT and CNS file and create a hash ref
    Create_Symbol_Mapping($sad_filePath) || return;
    my $test_href = $symbolMapping_href;

    #CALL CreateDevicesDetails to create device details in a hash ref
    CreateDevicesDetails($test_href) || return;

    #CALL FL_Init for ProdDiag_AB12 to initialize the device layer module
    my $configuredDevices_href = FL_Init( 'ProdDiag_AB12', $functionMapping_href, \@availableTestbenchFunctionGroups );

    #CALL LIFT_PDLayer::PDL_init with communication parameters and bus type
    my $diagHandle_href = CallDeviceFunction( 'PD', $busType, $communicationParameters_href );
    return if not defined $diagHandle_href;

    #STEP Store diag handle as global variable
    $prd12Handle_href = $diagHandle_href;

    # CALL PRD12_Set_Secure_PIN if flag 'setSecurePIN' is set
    if ( $initConfig_href->{setSecurePIN} ) {
        PRD12_Set_Secure_PIN();
    }

    # CALL PRD12_SetAutoLogin
    PRD12_SetAutoLogin( $initConfig_href->{setAutoLogin} );

    # CALL PRD12_Enable_KMS_Simulator if flag 'enableKMSsimulator' is set
    if ( $initConfig_href->{enableKMSsimulator} ) {
        PRD12_Enable_KMS_Simulator(1);
    }

    # CALL PRD12_Do_Initial_Login if flag 'setInitialLogin' is set
    my $ecuDetails_href = {};
    if ( $initConfig_href->{setInitialLogin} ) {
        $ecuDetails_href = PRD12_Do_Initial_Login();
    }

    S_w2log( 2, "PRD12_init: ProdDiag for AB12 initialized.\n" );

    #STEP Return ECU details
    return $ecuDetails_href;
}

=head2 PRD12_exit

    $success = PRD12_exit();
    
B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_exit'>PRD_exit documentation</a>
<br><br>

=cut

sub PRD12_exit {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_exit()', @args ) or return;

    #CALL LIFT_PDLayer::PDL_exit to close the diag handle
    @args = ($prd12Handle_href);
    CallDeviceFunction(@args);
    $prd12Handle_href = undef;
    $ecu_details_href = {};

    S_w2log( 2, "PRD12_exit: Finished ProdDiag for AB12.\n" );
    return 1;
}

=head2 PRD12_Do_Initial_Login

    $ecuDetails_href = PRD12_Do_Initial_Login();
    
B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Do_Initial_Login'>PRD_Do_Initial_Login documentation</a>
<br><br>

=cut

sub PRD12_Do_Initial_Login {

    #CALL PRD12_ECU_Login for initial login with ECU
    S_w2log( 3, "Calling ECU login...\n" );
    my $response_href = PRD12_ECU_Login() or return;

    #CALL PRD12_Get_ECU_Details from initial login
    S_w2log( 3, "Calling GetECUDetails...\n" );
    my $romcode = S_get_contents_of_hash( [ 'sad', 'header', 'ROMCODE' ], $symbolMapping_href ) || return;
    my $ecuDetails_href = PRD12_Get_ECU_Details($romcode);

    my $sad_filePath = $busParams_href->{'SADFILEPATH'};
    my $ecu_sw_ver   = $ecuDetails_href->{'EcuSwVersion'};

    unless ( $main::opt_offline == 1 ) {
        $sad_filePath =~ /([a-zA-Z0-9\_]+)(\.sad)$/;
        my $sad_file = $1;
        unless ( $ecu_sw_ver eq $sad_file ) {
            S_set_warning(
"PRD12_Do_Initial_Login: Mismatch of ECU SW Version and SAD file configured. Check the SAD file configured in Main_CFG or PSDiag SAD file path(only if you defined 'TakeFromPSDiag' as the project name in project constant module)\n\nSAD file path configured: $sad_filePath\nECU SW Version: $ecu_sw_ver\n"
            );
        }
    }

    #store it in global hash ref
    $ecu_details_href = dclone $ecuDetails_href;
    return $ecuDetails_href;
}

=head2 PRD12_Send_Request_Wait_Response

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Send_Request_Wait_Response'>PRD_Send_Request_Wait_Response documentation</a>
<br><br>

=cut

sub PRD12_Send_Request_Wait_Response {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Send_Request_Wait_Response( $request_mix [, $options_href ] )', @args ) or return;

    my $request_mix  = shift @args;
    my $options_href = shift @args;

    my $add_length_checksum_flag;
    $add_length_checksum_flag = $options_href->{add_length_checksum} if ( exists $options_href->{add_length_checksum} );

    # STEP Check whether the $request_mix is a string or an array ref, if it is string then convert the $request_mix to array reference otherwise consider as it is
    my $request_aref;
    if ( ref $request_mix eq 'ARRAY' ) {
        $request_aref = $request_mix;
    }
    else {
        @$request_aref = map {
            if ( $_ !~ /^[0-9A-F]+$/i or ( hex($_) > 255 or hex($_) < 0 ) ) {    # check if 0 =< byte <= 255
                S_set_error( "PRD12_Send_Request_Wait_Response : byte value $_ is out of range ( 0<=x<=FF )", 110 );
                return;
            }
            $_ = hex $_;

        } split /\s/, $request_mix;    #convert request string(separated by space) to an array reference

    }
    my $request4print = STR_Aref2HexString($request_aref);
    S_w2log( 3, "PRD12_Send_Request_Wait_Response: Start sending request '$request4print'...\n" );

    # STEP Check whether $add_length_checksum_flag is 1, if it is then calculate the length (first byte) and checksum (last byte) and append to the request
    if ( defined $add_length_checksum_flag and $add_length_checksum_flag == 1 ) {

        unshift( @$request_aref, scalar(@$request_aref) + 1 );    # length of the request passed as an input plus checksum
        my $checksum;
        map { $checksum += $_; } @$request_aref;

        $checksum = hex( substr( sprintf( "%X", $checksum ), -2 ) ) if ( $checksum > 255 );    # Incase the checksum exceed 8 bit , the lowest 8-bit is the Checksum

        push( @$request_aref, $checksum );
    }

    # CALL LIFT_PDLayer::PDL_send_request_wait_response to send the request
    my $response_href = CallDeviceFunction( $prd12Handle_href, $request_aref );

    S_w2log( 3, "PRD12_Send_Request_Wait_Response: Finished sending request '$request4print'.\n" );

    # STEP Return $response_href
    return $response_href;
}

=head2 PRD12_Send_Request_No_Wait

    $success = PRD12_Send_Request_No_Wait( $request_aref [, $options_href ] );

Not yet implemented!!!

B<Arguments:>

=over

=item $request_aref

=item $options_href

=back


B<Return Values:>

=over

=item $success

=back


B<Examples:>

B<Notes:> 

=cut

#sub PRD12_Send_Request_No_Wait {
#    my @args = @_;
#    S_checkFunctionArguments( 'PRD12_Send_Request_No_Wait( $request_aref [, $options_href ] )', @args ) or return;
#    my $request_aref = shift @args;
#    my $options_href = shift @args;
#
#    my $success;
#
#    return $success;
#}

=head2 PRD12_Get_ECU_Details

    $ecuDetails_href = PRD12_Get_ECU_Details($romcode);

Returns the ECU details. This function can be called only after initial login.

B<Arguments:>

=over

=item $romcode

Romcode using which software version is fetched

=back

B<Return Values:>

=over

=item $ecuDetails_href

    $ecuDetails_href = {
        'EcuGeneration'    => 12,
        'PdVersionNr'      => 8,
        'DMC_PlantID'      => plant_id,
        'DMC_LineID'       => line_id,
        'DMC_CounterID'    => counter_id,
        'DMC_Date'         => date,
        'DMC_PartNumber'   => part_num,
        'EcuSwVersion'     => SW_version,
        'ECU_FingerPrint'  => finger_print,
        'Algo_Param_ID'    => algo_id,
        'Variant_Version'  => variant_ver,
        'Variant_ID'       => variant_id,
    };  

=back

B<Examples:>

    $ecuDetails_href = PRD12_Get_ECU_Details("AB1200_BD_074_BB00000_Cat2");
    
    $ecuDetails_href = {
        'DMC_LineID' => '',
        'EcuSwVersion' => 'AB1200_BD_0107_BB000000_Cat2',
        'DMC_PartNumber' => '',
        'DMC_Date' => '',
        'PdVersionNr' => 8,
        'EcuGeneration' => 12,
        'DMC_CounterID' => '',
        'DMC_PlantID' => '',
        'ECU_FingerPrint' => 'F377EFE6#596E1654A51F',
        'Algo_Param_ID' => '0x0378',
        'Variant_Version' => '0x10',
        'Variant_ID' => '0x01',
    }
    
=cut

sub PRD12_Get_ECU_Details {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_ECU_Details($romcode)', @args ) or return;
    my $details_href = CallDeviceFunction(@args);

    return unless ($details_href);

    my $fingerprint   = Get_ECU_fingerprint_NOERROR();
    my $algo_param_ID = Get_ECU_AlgoParameter_ID_NOERROR();
    my ( $variant_version, $variant_number ) = Get_Variant_Version_NOERROR();

    $details_href->{'ECU_FingerPrint'} = $fingerprint;
    $details_href->{'Algo_Param_ID'}   = $algo_param_ID;
    $details_href->{'Variant_Version'} = $variant_version;
    $details_href->{'Variant_ID'}      = $variant_number;

    $main::ENV{'ECU_SW_VERSION'} = $details_href->{'EcuSwVersion'};
    S_set_project_info( { 'ECU_SW_VERSION' => $details_href->{'EcuSwVersion'} } );

    $main::ENV{'VARIANT_ID'} = $details_href->{'Variant_ID'};
    S_set_project_info( { 'VARIANT_ID' => $details_href->{'Variant_ID'} } );

    $main::ENV{'VARIANT_VERSION'} = $details_href->{'Variant_Version'};
    S_set_project_info( { 'VARIANT_VERSION' => $details_href->{'Variant_Version'} } );

    return $details_href;
}

=head2 PRD12_ECU_Login

    $response_href = PRD12_ECU_Login();

Does the inital login into ECU.

B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $response_href

Second Login response after successfull handshake

    $response_href = {
              'ErrorDescription' => 'OK',
              'Id' => 'id',
              'PdLength' => 1,
              'CompletePdMsg' => ['msg'],
              'Status' => 0,
              'PdPayload' => ['payload'],
              'Checksum' => 'checksum'
            }

=back

B<Examples:>

    $response_href = PRD12_ECU_Login();
    
    Sresponse_href = {
        'ErrorDescription' => 'OK',
        'PdLength' => 54,
        'Id' => 64,
        'CompletePdMsg' => [54, 64, 162, 12, 8, 11, 65, 66, 0, 66, 68, 1, 7, 0, 0, ....],
        'Status' => 0,
        'PdPayload' => [64, 162, 12, 8, 11, 65,....],
        'Checksum' => 122,
    }

=cut

sub PRD12_ECU_Login {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_ECU_Login()', @args ) or return;
    S_w2log( 3, "PRD12_ECU_Login: Logging in to ECU...\n" );
    return CallDeviceFunction( 'PD', @args );
}

=head2 PRD12_Get_ECU_Properties

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Get_ECU_Properties'>PRD_Get_ECU_Properties documentation</a>
<br><br>

=cut

sub PRD12_Get_ECU_Properties {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_ECU_Properties([,$options_href])', @args ) or return;
    my $options_href = shift @args;
    my $ecu_properties_href;

    S_w2log( 3, "PRD12_Get_ECU_Properties: Start getting ECU properties...\n" );

    CheckPreconditions() or return;

    #STEP read properties given as argument.
    my $properties_aref = $options_href->{'Property_names'};

    #STEP if not given, consider all the properties(ECU details, ECU status, Lamp_status)
    unless ( defined $properties_aref ) {
        $properties_aref = [ 'ECU_status', 'ECU_details', 'Lamp_status' ];
    }

    #CALL PRD12_ECU_Status to read ECU status if its asked
    #IF ECU details is asked
    #   IF-YES-START
    #   STEP read ECU details which is stored already
    #   CALL Get_ECU_fingerprint
    #   CALL Get_ECU_AlgoParameter_ID
    #   CALL Get_Variant_Version
    #   STEP add fingerprint, algo parameter ID, variantID and version to the hash
    #   IF-YES-END
    #   IF-NO-START
    #   IF-NO-END
    #CALL ReadLampStates to read Lamp states if its asked

    foreach my $property (@$properties_aref) {
        if ( $property =~ /ECU_status/i ) {
            my $ecu_status_href = PRD12_ECU_Status();
            $ecu_properties_href->{'ECU_status'} = $ecu_status_href;
        }
        if ( $property =~ /ECU_details/i ) {
            $ecu_properties_href->{'ECU_details'} = $ecu_details_href;
        }
        if ( $property =~ /Lamp_status/i ) {
            $ecu_properties_href->{'Lamp_status'} = ReadLampStates();
        }
    }

    S_w2log( 3, "PRD12_Get_ECU_Properties: Finished getting ECU properties.\n" );

    #STEP return the properties hash
    return $ecu_properties_href;
}

=head2 PRD12_ECU_Status

    $ecuStatus_href = PRD12_ECU_Status();

Reads the ECU status, creates a hash and returns. Also reads ECU mode

B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $ecuStatus_href

    $ecuStatus_href => {
        Fault_memory_status => 0|1
        EDR_status => 0|1
        Data_flash_status => 0|1
        Electronic_firing_status => 0|1
        ECU_mode => ecu_mode
    }

=item undef on error

=back

B<Examples:>

    $ecuStatus_href = PRD12_ECU_Status();

=cut

sub PRD12_ECU_Status {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_ECU_Status()', @args ) or return;

    # offline return
    if ($main::opt_offline) {
        return {
            'Fault_memory_status'      => 0,
            'EDR_status'               => 0,
            'Data_flash_status'        => 0,
            'Electronic_firing_status' => 0,
            'ECU_mode'                 => 'Normal',
        };
    }

    #CALL LIFT_PDLayer::PDL_EcuStatus to send the service ECUStatus and record the response
    my $response_href  = CallDeviceFunction(@args);
    my $ecuStatus_href = {};

    #CALL Get_ECU_Mode
    my $ecu_mode = Get_ECU_Mode();

    #STEP read the response bytes and create a hash
    my $response_aref = $response_href->{'PdPayload'};
    $ecuStatus_href = {
        'Fault_memory_status'      => @$response_aref[1],
        'EDR_status'               => @$response_aref[2],
        'Data_flash_status'        => @$response_aref[3],
        'Electronic_firing_status' => @$response_aref[4],
    };

    #STEP Add ecu_mode to the hash
    $ecuStatus_href->{'ECU_mode'} = $ecu_mode;

    #STEP return ECU status
    return $ecuStatus_href;

}

=head2 PRD12_SW_Reset

    $success = PRD12_SW_Reset( [$options_href] );

Resets the ECU (Hard reset or soft reset) and waits for the time mentioned by the user after resetting.

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_ECU_Reset'>PRD_ECU_Reset documentation</a>
<br><br>   
    
=cut

sub PRD12_SW_Reset {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_SW_Reset( [$options_href] )', @args ) or return;

    #STEP read arguments
    my $options_href = shift @args;

    #CALL Read_options_4_reset to read and validate the reset type and wait time
    my ( $reset_type, $wait_time_ms ) = Read_options_4_reset($options_href) or return;

    #STEP append 'RESET' to reset_type and make it upper case
    $reset_type = uc( $reset_type . 'RESET' );

    S_w2log( 3, "PRD12_SW_Reset: Peforming $reset_type...\n" );

    my $numOfReset = 1;    # default set to 1

    $numOfReset = $options_href->{'numberOfResets'} if ( defined $options_href->{'numberOfResets'} );

    S_w2log( 3, "PRD12_SW_Reset: ECU will be $reset_type '$numOfReset' time(s) " );
    while ( $numOfReset > 0 ) {

        #CALL LIFT_PDLayer::PDL_EcuReset() 'numberOfResets' times to reset the ECU with reset type
        my $response_href = CallDeviceFunction($reset_type);

        #STEP wait for read number of ms
        #STEP decrement reset count till 0
        return unless ($response_href);
        S_wait_ms($wait_time_ms) if ($wait_time_ms);    #do not call wait if time is 0
        $numOfReset--;
    }
    return 1;
}

=head2 PRD12_Manipulate_Fault_Memory

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Manipulate_Fault_Memory'>PRD_Manipulate_Fault_Memory documentation</a>
<br><br>

=cut

sub PRD12_Manipulate_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Manipulate_Fault_Memory( $manipulationConfig_href )', @args ) or return;

    #STEP read manipulation config href for faultname, fault type and action
    my $manipulationConfig_href = shift @args;
    my $fault_name              = $manipulationConfig_href->{'fault_name'};
    my $fault_type              = $manipulationConfig_href->{'fault_type'};
    my $action                  = $manipulationConfig_href->{'action'};
    my $response_href;

    CheckPreconditions() or return;

    S_w2log( 3, "PRD12_Manipulate_Fault_Memory: Start manipulating fault memory...\n" );

    if ( ECUProtectionActivated() ) {
        S_set_error( "ECU is locked or was locked once. PRD12_Manipulate_Fault_Memory cannot be executed in this state.", 109 );
        return;
    }

    #IF both fault name and fault type is defined
    #IF-YES-START
    #STEP set error if both fault name and fault type are defined and return
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    if ( defined $fault_name and defined $fault_type ) {
        S_set_error( "PRD12_Manipulate_Fault_Memory : Either of fault type or fault name should be specified in argument '$manipulationConfig_href' . Not both!", 109 );
        return;
    }

    #IF fault name is defined
    #IF-YES-START
    #   STEP set error and return if action is neither qualify nor dequalify
    #   CALL PRD12_Get_Symbol_Mapping to read fault id for the fault name mentioned
    #   CALL LIFT_PDLayer::PDL_ManipulateFaultMemory for fault ID and action
    #   STEP log the status
    #IF-YES-END
    #IF-NO-START
    #   STEP set error and return if fault type is not "PLANT|PRIMARY|BOSCH|DISTURBANCE"
    #   CALL Get_Fault_IDs_4_manipulation with fault type
    #   CALL LIFT_PDLayer::PDL_ManipulateFaultMemory for each fault in loop
    #   STEP log the status for each call
    #IF-NO-END
    #STEP return

    if ( defined $fault_name ) {
        if ( !( $action =~ /^qualify$|^dequalify$/i ) ) {
            S_set_error( "PRD12_Manipulate_Fault_Memory : Action $action specified is not valid. Valid actions are \"qualify\" or \"dequalify\"!.", 109 );
            return;
        }
        S_w2log( 3, "PRD12_Manipulate_Fault_Memory called for the fault $fault_name to $action \n" );
        my $action_bool = 0;
        $action_bool = 1 if $action =~ /^qualify$/i;
        my $mappingPart_href = { 'fault_name' => $fault_name, };
        my $fault_id = PRD12_Get_Symbol_Mapping($mappingPart_href);
        $response_href = CallDeviceFunction( $fault_id, $action_bool );
        return unless $response_href;
        S_w2log( 4, "PRD12_Manipulate_Fault_Memory : action $action applied on fault $fault_name and returned status $response_href->{'Status'}\n" );
    }
    else {
        if ( !( $fault_type =~ /^PLANT$|^PRIMARY$|^BOSCH$|^DISTURBANCE$/i ) ) {
            S_set_error( "PRD12_Manipulate_Fault_Memory : Fault type $fault_type specified is not valid. Valid fault types are \"PLANT|PRIMARY|BOSCH|DISTURBANCE\"!.", 109 );
            return;
        }
        S_w2log( 3, "PRD12_Manipulate_Fault_Memory called to dequalify all the faults from fault type " . uc($fault_type) . "\n" );
        my @fault_ids = Get_Fault_IDs_4_manipulation($fault_type);
        foreach my $fault (@fault_ids) {
            $response_href = CallDeviceFunction( $fault, 0 );
            return unless $response_href;
            S_w2log( 4, "PRD12_Manipulate_Fault_Memory :dequalifying fault with fault id $fault returned status $response_href->{'Status'}\n" );
        }
    }
    S_w2log( 3, "PRD12_Manipulate_Fault_Memory: Finished manipulating fault memory.\n" );
    return 1;
}

=head2 PRD12_Read_Fault_Memory

    $faultMemory_href = PRD12_Read_Fault_Memory( $faultType );

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_Fault_Memory'>PRD_Read_Fault_Memory documentation</a>
<br><br>

=cut

sub PRD12_Read_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Read_Fault_Memory( $faultType )', @args ) or return;
    my $faultType = shift @args;

    S_w2log( 3, "PRD12_Read_Fault_Memory: Start reading '$faultType' fault memory...\n" );

    my $validFaultTypes_aref = [ 'BOSCH', 'PRIMARY', 'PLANT', 'DISTURBANCE' ];
    $faultType =~ s/\s+//g;    # remove spaces if any

    #   IF Valid fault type is configured?
    #   IF-NO-START
    #       STEP ERROR: invalid Fault type.
    #       STEP Return undef
    #   IF-NO-END
    #   IF-YES-START
    #        CALL LIFT_PDLayer::PDL_ReadFaultMemory
    #        STEP return $faultMemory_href if success, else undef
    #   IF-YES-END
    #   STEP END

    unless ( $faultType =~ /^(BOSCH|PRIMARY|PLANT|DISTURBANCE)$/i ) {
        my $allFaultTypes = join( ', ', @$validFaultTypes_aref );
        S_set_error( "PRD12_Read_Fault_Memory: Read fault memory type '$faultType' is invalid! Valid Types: $allFaultTypes", 109 );
        return;
    }

    $faultType = uc $faultType;    # convert to uppercase if configured in camel or smaller case

    return unless CheckPreconditions();    # check for diag handle and fast diag

    # Prepare the attribute list to print to the HTML table

    #  STEP Convert $faultType to integer
    my $faultType_int = $FAULT_NAME_MAPPING->{$faultType};

    #  STEP Fetch fault file path
    my $fltFilePath = $prd12StoreVar_href->{'SADFILEPATH'};    # fault file must be present in same location as sad file
    $fltFilePath =~ s/.sad$/.flt/i;

    #  STEP return empty fault hash in offline mode.
    return {} if ($main::opt_offline);                         # empty hash for fault memory.

    unless ( -e $fltFilePath ) {
        S_set_error( "PRD12_Read_Fault_Memory: Faultfile path '$fltFilePath' not found, fault file must be present in the same path as SAD file!", 1 );
        return;
    }

    #  CALL CallDeviceFunction
    my $faultMemory_href = CallDeviceFunction( $faultType_int, $fltFilePath );

    return unless ($faultMemory_href);                         # error message handled in device layer

    #  STEP print the fault details to HTML
    PrintFaultTableToHTML( $faultMemory_href, $faultType );

    #  STEP return $faultMemory_href
    #  STEP END

    S_w2log( 3, "PRD12_Read_Fault_Memory: Finished reading '$faultType' fault memory.\n" );

    return $faultMemory_href;
}

=head2 PRD12_Clear_Fault_Memory

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Clear_Fault_Memory'>PRD_Clear_Fault_Memory documentation</a>
<br><br>

=cut

sub PRD12_Clear_Fault_Memory {

    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Clear_Fault_Memory( [,$options_href] )', @args ) or return;

    S_w2log( 3, "PRD12_Clear_Fault_Memory: Start clearing fault memory...\n" );

    my $options_href = shift @args;

    # IF Is faultType and waitUntilClear are in valid range?
    #   IF-NO-START
    #       STEP ERROR: argument not in range, return undef
    #   IF-NO-END
    #   IF-YES-START
    #      IF faultType is 'plant'
    #      IF-YES-START
    #           CALL LIFT_PDLayer::PDL_ClearPlantFaultMemory
    #           STEP return 1 on successful function call, else return undef
    #      IF-YES-END
    #      IF-NO-START
    #           IF execution option PD_ClearFaultMemory_using_ManipulateFaultMemory is set
    #           IF-YES-START
    #               CALL PRD12_Manipulate_Fault_Memory to dequalify all faults from primary fault memory
    #           IF-YES-END
    #           IF-NO-START
    #           IF-NO-END
    #           CALL LIFT_PDLayer::PDL_ClearFaultMemory
    #           STEP return 1 on successful function call, else return undef
    #      IF-NO-END
    #   IF-YES-END
    #STEP END

    return unless CheckPreconditions();

    $options_href = CheckAndFillClearFaultArg($options_href) || return;
    my $exec_Options_href     = S_get_exec_option();
    my $is_ExecOption_enabled = $exec_Options_href->{'PD_ClearFaultMemory_using_ManipulateFaultMemory'};
    if ( $is_ExecOption_enabled and lc( $options_href->{'faultType'} ) ne 'plant' ) {
        S_w2log( 3, "Execution option PD_ClearFaultMemory_using_ManipulateFaultMemory is set. So the fault memory is manipulated for dequalifying the faults present and then cleared.\n" );

        # manipulating only primary fault memory which actually causes the system go into idle mode
        PRD12_Manipulate_Fault_Memory( { 'fault_type' => 'primary', 'action' => 'dequalify' } );
    }
    return unless ( CallDeviceFunction($options_href) );

    S_w2log( 3, "PRD12_Clear_Fault_Memory: Finished clearing fault memory...\n" );

    return 1;
}

=head2 PRD12_Freeze_Fault_Memory

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Freeze_Fault_Memory'>PRD_Freeze_Fault_Memory Documentation</a>
<br><br>

=cut

sub PRD12_Freeze_Fault_Memory {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Freeze_Fault_Memory()', @args ) or return;

    # STEP CheckPreconditions
    # CALL PDLayer::PDL_FreezeFaultMemory
    # IF defined  $response_href?
    # IF-YES-START
    #   STEP Freeze Fault memory was successful
    #   STEP Return 1
    # IF-YES-END
    # IF-NO-START
    #   STEP Failed to Freeze Fault memory.
    #   STEP Return undef
    # IF-NO-END
    # STEP END
    S_w2log( 3, "PRD12_Freeze_Fault_Memory: Start freezing fault memory...\n" );

    return unless CheckPreconditions();
    my $response_href = CallDeviceFunction();

    unless ( defined $response_href ) {
        S_w2log( 3, "PRD12_Freeze_Fault_Memory : Failed to freeze the fault memory!" );
        return;
    }

    S_w2log( 3, "PRD12_Freeze_Fault_Memory: Finished freezing fault memory.\n" );
    return 1;
}

=head2 PRD12_Start_Fast_Diagnosis

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Start_Fast_Diagnosis'>PRD_Start_Fast_Diagnosis documentation</a>
<br><br>

=cut

sub PRD12_Start_Fast_Diagnosis {
    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Start_Fast_Diagnosis( $fastDiagConfig_href )', @args ) or return;
    my $fastDiagConfig_href = shift @args;

    S_w2log( 3, "PRD12_Start_Fast_Diagnosis: Starting the initial Settings for Fast Diagnosis...\n" );

    # STEP Fetch the input arguments ($fastDiagConfig_href)

    # CALL Validate_And_Fetch_FastDiag_Parameters
    my ( $selectedVarInfo_aref, $nbr_of_BUS_Ids, $isNextPOC, $csv_data_file_path ) = Validate_And_Fetch_FastDiag_Parameters($fastDiagConfig_href) or return;

    # CALL LIFT_PDLayer::PDL_FastDiagnosis
    my $response_href = CallDeviceFunction( $selectedVarInfo_aref, $nbr_of_BUS_Ids, $isNextPOC, $csv_data_file_path );

    unless ( defined $response_href ) {
        S_set_error( " PRD12_Start_Fast_Diagnosis : Failed to start fast diagnosis\n", 109 );
        return;
    }

    $prd12StoreVar_href->{csv_data_file_path} = $csv_data_file_path;

    # STEP set FastDiag flag as 1(active)
    $fastDiagActive = 1;

    S_w2log( 3, "PRD12_Start_Fast_Diagnosis: Fast Diagnosis started.\n" );

    # STEP return $csv_data_file_path incase of success or undef incase of error
    return $csv_data_file_path;
}

=head2 PRD12_Stop_Fast_Diagnosis

    $success = PRD12_Stop_Fast_Diagnosis();
    
Stops a previously started fast diagnosis session.

B<Return Values:>

=over

=item $success

Success/Offline : 1

Error : undef

=back

B<Examples:>

    1 = PRD12_Stop_Fast_Diagnosis();

B<Notes:> 

=cut

sub PRD12_Stop_Fast_Diagnosis {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Stop_Fast_Diagnosis()', @args ) or return;

    S_w2log( 3, "PRD12_Stop_Fast_Diagnosis: stopping Fast Diagnosis...\n" );

    if ( not defined $prd12Handle_href ) {
        S_set_error( "Production diagnosis AB12 handle not defined. Please initialize Production diagnosis for AB12 before using the function 'PRD_Stop_Fast_Diagnosis'.", 109 );
        return;
    }

    # STEP Set a warning if FastDiagnostics is not active
    unless ($fastDiagActive) {
        S_set_warning("PRD12_Stop_Fast_Diagnosis : Fast Diagnostics is not Active");
        return 1;
    }

    # CALL LIFT_PDLayer::PDL_StopReadFastdiagData
    my $success = CallDeviceFunction() or return;

    # STEP set FastDiag flag as 0(inactive)
    $fastDiagActive = 0;

    S_wait_ms(1000);    # Do not remove this line until Defect is closed: https://rb-alm-04-p.de.bosch.com/ccm/resource/itemName/com.ibm.team.workitem.WorkItem/165357

    S_w2log( 3, "PRD12_Stop_Fast_Diagnosis: Fast Diagnosis stopped.\n" );

    # STEP return status(success(1)/failure(undef))
    return 1;
}

=head2 PRD12_Get_Fast_Diagnosis_Data

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Get_Fast_Diagnosis_Data'>PRD_Get_Fast_Diagnosis_Data documentation</a>
<br><br>

=cut

sub PRD12_Get_Fast_Diagnosis_Data {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_Fast_Diagnosis_Data( [, $options_href] )', @args ) or return;

    my $options_href = shift @args;

    my $data_path;

    # STEP Fetch the input arguments ($data_path(optional))
    $data_path = $options_href->{data_path} if ( exists $options_href->{data_path} );

    # STEP if the $data_path is not given then by default path last used in PRD_Start_Fast_Diagnosis is considered
    $data_path = $prd12StoreVar_href->{csv_data_file_path} unless ( defined $data_path );

    S_w2log( 3, "PRD12_Get_Fast_Diagnosis_Data: Start getting Fast Diagnosis data from path '$data_path'...\n" );

    my $data_HoH_dummy->{0}->{'dummy'} = 0;

    return $data_HoH_dummy if ($main::opt_offline);

    my $fdData_href;

    # CALL  Get_FDtrace_from_CSV_File if the input is directory
    if ( -d $data_path ) {
        $fdData_href = Get_FDtrace_from_CSV_File($data_path);
    }

    unless ($fdData_href) {
        S_set_error( "PRD12_Get_Fast_Diagnosis_Data : Could not fetch the fast Diagnosis data\n", 110 );
        return;
    }

    S_w2log( 3, "PRD12_Get_Fast_Diagnosis_Data: Finished getting Fast Diagnosis data.\n" );

    # STEP return fastDiag data hash reference on success otherwise return undef
    return $fdData_href;
}

=head2 PRD12_Read_EDR

    $response_href = PRD12_Read_EDR( $did [, $options_href] );

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_EDR'>PRD_Read_EDR documentation</a>
<br><br>

=cut

sub PRD12_Read_EDR {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Read_EDR( $did, [, $options_href] )', @args ) or return;
    my $did          = shift @args;
    my $options_href = shift @args;

    #STEP check options_href
    my $mandatoryArgs_href = {};
    my $validArgs_href = { dump_filename => 1, date_time_in_file_name => 1, dump_file_format_version => 1 };

    if ($options_href) {
        S_checkFunctionArgumentHashKeys( 'PRD12_Read_EDR', $options_href, $validArgs_href, $mandatoryArgs_href ) or return;
    }

    $options_href->{date_time_in_file_name} = 1 if not defined $options_href->{date_time_in_file_name};

    #CALL CheckPreconditions
    return unless CheckPreconditions();    # check for diag handle and fast diag

    #STEP if $did is given as hex string convert to number
    if ( $did =~ /^0x/i ) {
        $did =~ s/^0X/0x/;                 #substitute only if uppercase X to lowercase
        $did = hex $did;
    }

    my $did_log = sprintf( "%02X", $did );
    S_w2log( 3, "PRD12_Read_EDR: Starting reading EDR for DID 0x$did_log...\n" );

    #STEP call device function for Read_EDR
    my $response_href = CallDeviceFunction($did);

    #STEP return on error, except if execution option 'Defect_219169_workaround' is true and error is ERR_INCOMPLETE_RESPONSE
    if ( not defined $response_href ) {
        my $exec_Options_href = S_get_exec_option();
        if ( $exec_Options_href->{'Defect_219169_workaround'} ) {
            $response_href = PRD12_Get_Last_Response();
            return unless ( $response_href->{Status} == -976 );    # status -976 is ERR_INCOMPLETE_RESPONSE
            S_set_warning("INCOMPLETE_RESPONSE is ignored because execution option 'Defect_219169_workaround' is set. Response will be returned.");
        }
        else {
            return;
        }
    }

    S_w2log( 3, "PRD12_Read_EDR: Finished reading EDR for DID 0x$did_log.\n" );

    #IF option dump_filename is defined?
    #IF-YES-START
    if ( exists $options_href->{'dump_filename'} and defined $options_href->{'dump_filename'} ) {

        #STEP Check the dump file format version- if it is not defined or has an invalid value then assign the default file format '2'(.txt)
        $options_href->{dump_file_format_version} = 2 if ( not defined $options_href->{dump_file_format_version} );

        #STEP The valid dump file formats are 2 for (.txt) and 3 for (.xml)
        my @vaild_edr_file_formats = ( 2, 3 );
        if ( not $options_href->{dump_file_format_version} ~~ @vaild_edr_file_formats ) {
            S_set_warning( "PRD12_Read_EDR: EDR dump file format is defined as '$options_href->{'dump_file_format_version'}' which is not supported. Supported formats are [@vaild_edr_file_formats]  2 for .txt and 3 for .xml respectively. Considering file format '2' by default", 109 );
            $options_href->{dump_file_format_version} = 2;
        }

        #STEP format DID and EDR bytes for dump
        my $serviceID        = "0xFD$did_log";
        my $edr_DumpFileName = $options_href->{'dump_filename'};
        my $edrByteData;

        foreach my $edr_byte ( @{ $response_href->{'CompletePdMsg'} } ) {
            $edrByteData .= sprintf '%.2X', $edr_byte;
            $edrByteData .= "\n";
        }

        #STEP Return with error if dump_filename does not end with .txt or .xml
        if ( $options_href->{'dump_filename'} !~ /\.txt|\.xml$/ ) {
            S_set_error( "PRD12_Read_EDR: EDR dump file type '$options_href->{'dump_filename'}' is invalid, Supported types are '*.txt', '*.xml' ", 109 );
            return;
        }

        #STEP Return with error if the filename with '.txt' extension has dump_file_format_version other than 2
        if ( $options_href->{'dump_filename'} =~ /\.txt$/ and $options_href->{'dump_file_format_version'} != 2 ) {
            S_set_error( "PRD12_Read_EDR: Given format of file '$options_href->{'dump_filename'}' is '$options_href->{'dump_file_format_version'}. Supported is '2' ", 109 );
            return;
        }

        #STEP Return with error if the filename with '.xml' extension has dump_file_format_version other than 3
        if ( $options_href->{'dump_filename'} =~ /\.xml$/ and $options_href->{'dump_file_format_version'} != 3 ) {
            S_set_error( "PRD12_Read_EDR: Given format of file '$options_href->{'dump_filename'}' is '$options_href->{'dump_file_format_version'}. Supported is '3' ", 109 );
            return;
        }

        #CALL CreateFileNameAndLink
        my $linkName;

        ( $edr_DumpFileName, $linkName ) = CreateFileNameAndLink( 'EDR', $edr_DumpFileName, $options_href->{date_time_in_file_name} ) or return;

        #IF option dump_file_format_version is
        #IF-2-START
        if ( $options_href->{dump_file_format_version} == 2 ) {

            #STEP Prepare and dump EDR crash dump data to a txt file
            return unless ( PrepareDumpFormat2Content( $edr_DumpFileName, $serviceID, $edrByteData, $linkName ) );
        }

        #IF-2-END
        #IF-3-START
        elsif ( $options_href->{dump_file_format_version} == 3 ) {

            #STEP open dump file with file format 3 and write header and EDR bytes
            return unless ( EdrDump_to_XML( $edr_DumpFileName, $serviceID, $edrByteData ) );

            #STEP Calculate File Checksum and write it back to the '.xml' file
            return unless ( WrChecksumTo_XML_File( $edr_DumpFileName, $linkName ) );

        }

        #IF-3-END
    }

    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    #END return $response_href
    return $response_href;
}

=head2 PRD12_Clear_EDR

    $response_href = PRD12_Clear_EDR( [ $options_href ] );

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Clear_EDR'>PRD_Clear_EDR documentation</a>
<br><br>

=cut

sub PRD12_Clear_EDR {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Clear_EDR( [,$options_href] )', @args ) or return;
    my $options_href = shift @args;

    #IF is valid parameters?
    # IF-NO-START
    #   STEP Error invalid parameters, return undef
    # IF-NO-END
    # IF-YES-START
    #   CALL LIFT_PDLayer::PDL_ClearEdr
    #   STEP Store the response_href
    #   IF is wait time configured?
    #   IF-YES-START
    #       LOOP-START for every one sec (decrement wait time) check ecu status is set
    #       STEP return response_href, print log message in report for the timeout after which the EDR data is cleared
    #       LOOP-END If timeout is less than 0
    #   IF-YES-END
    #   IF-NO-START
    #       STEP return response_href as received from dll
    #   IF-NO-END
    # IF-YES-END
    #STEP END

    S_w2log( 3, "PRD12_Clear_EDR: Start clearing EDR...\n" );

    return unless CheckPreconditions();    # check for diag handle and fast diag

    if ( ECUProtectionActivated() ) {
        S_set_error( "ECU is locked or was locked once. PRD12_Clear_EDR cannot be executed in this state.", 109 );
        return;
    }

    my $response_href      = CallDeviceFunction() or return;
    my $ecuStatus_href     = {};
    my $timeOut_ms         = 0;
    my $timeOut_Log        = 0;
    my $mandatoryArgs_href = { timeout_ms => 1 };
    my $validArgs_href     = $mandatoryArgs_href;

    if ($options_href) {
        S_checkFunctionArgumentHashKeys( 'PRD12_Clear_EDR', $options_href, $validArgs_href, $mandatoryArgs_href ) or return;
    }

    if ( defined $options_href->{timeout_ms} ) {

        $timeOut_ms = $options_href->{timeout_ms};
        if ( $timeOut_ms !~ /^\d+$/ ) {
            $timeOut_ms = S_get_contents_of_hash_NOERROR( [ 'TIMER', $timeOut_ms ] );

            if ( $timeOut_ms !~ /^\d+$/ ) {
                S_set_error( "PRD12_Clear_EDR: Timer value '$timeOut_ms' configured for '$options_href->{timeout_ms}' not valid", 109 );
                return;
            }
            else {
                S_w2log( 4, "PRD12_Clear_EDR: Timeout given in project defaults timer section : $timeOut_ms \n" );
            }
        }
        while ( $timeOut_ms > 0 ) {
            $ecuStatus_href = PRD12_ECU_Status();
            if ( $ecuStatus_href->{EDR_status} == 0 ) {
                $response_href->{Status} = $ecuStatus_href->{EDR_status};
                S_w2log( 3, "PRD12_Clear_EDR: EDR cleared after '$timeOut_Log' milli seconds\n" );
                return $response_href;
            }
            else {
                $timeOut_ms -= 1000;
                S_wait_ms(1000);
                $timeOut_Log += 1000;
            }
        }
        if ( $ecuStatus_href->{EDR_status} != 0 ) {
            S_set_error( "PRD12_Clear_EDR: Clearing EDR is still active after '$timeOut_Log' milli seconds ", 109 );
            return;
        }
    }
    S_w2log( 3, "PRD12_Clear_EDR: Finished sending clear EDR command.\n" );
    return $response_href;
}

=head2 PRD12_Dump_Memory_To_File

    $fileName = PRD12_Dump_Memory_To_File( $memoryType [, $options_href ] );

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Dump_Memory_To_File'>PRD_Dump_Memory_To_File</a>
<br><br>

=cut

sub PRD12_Dump_Memory_To_File {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Dump_Memory_To_File( $memoryType [, $options_href ]  )', @args ) or return;
    my $memoryType   = lc shift @args;
    my $options_href = shift @args;

    S_w2log( 3, "PRD12_Dump_Memory_To_File: Start dumping '$memoryType' memory...\n" );

    my $mandatoryArgs_href = {};
    my $validArgs_href = { file_name => 1, date_time_in_file_name => 1 };

    if ($options_href) {
        S_checkFunctionArgumentHashKeys( 'PRD12_Dump_Memory_To_File', $options_href, $validArgs_href, $mandatoryArgs_href ) or return;
    }

    $options_href->{date_time_in_file_name} = 1 if not defined $options_href->{date_time_in_file_name};

    #IF is valid parameters?
    # IF-NO-START
    #   STEP error invalid arguments, return undef
    # IF-NO-END
    # IF-YES-START
    #   IF is memory type NVM?
    #   IF-YES-START
    #       LOOP-START for each NVM block
    #           CALL PRD12_Read_NVM_cells($noOfBytes, $blockId, $subBlockId, $offset)
    #       LOOP-END If all nvm blocks are read
    #   IF-YES-END
    #   IF-NO-START
    #       STEP error memory type not supported
    #   IF-NO-END
    # IF-YES-END
    #STEP END

    my ( $fileName, $linkName ) = CreateFileNameAndLink( $memoryType, $options_href->{file_name}, $options_href->{date_time_in_file_name} ) or return;

    if ( $memoryType !~ /^nvm$/i ) {
        S_set_error( "PRD12_Dump_Memory_To_File: Invalid memory type, supported types (nvm)", 109 );
        return;
    }
    if ( $memoryType eq 'nvm' ) {
        return unless ( DumpAllNvmData( $fileName, $linkName ) );
    }

    S_w2log( 3, "PRD12_Dump_Memory_To_File: Finished dumping '$memoryType' memory to file $fileName.\n" );

    return $fileName;
}

=head2 PRD12_Electronic_Firing_Enable

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Electronic_Firing_Enable'>PRD_Electronic_Firing_Enable documentation</a>
<br><br>

=cut

sub PRD12_Electronic_Firing_Enable {

    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Electronic_Firing_Enable( [$options_href] )', @args ) or return;
    my $options_href = shift @args;

    my $is_plant_mode = $options_href->{'set_plant_mode'};

    S_w2log( 3, "PRD12_Electronic_Firing_Enable: Start enabling electronic firing...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # STEP If set_plant_mode is not defined by default consider it as 1
    if ( not defined $is_plant_mode or ( $is_plant_mode != 0 and $is_plant_mode != 1 ) ) {
        $is_plant_mode = '' unless ( defined $is_plant_mode );
        S_w2log( 3, "PRD12_Electronic_Firing_Enable : set_plant_mode '$is_plant_mode' is either not defined or is not 0|1, so by default '1' is considered" );
        $is_plant_mode = 1;
    }

    # STEP if 'set_plant_mode' is 1 then Write "rb_sycg_ActivePlantModes_au8(0)" label value as 40 for enabling the fire Mode
    PRD12_Write_Cell( 'rb_sycg_ActivePlantModes_au8(0)', [64] ) if ( $is_plant_mode == 1 );

    # CALL LIFT_PDLayer::PDL_EnableSafetyPath for enabling Safety path
    my $response_href = CallDeviceFunction();

    return unless ( defined $response_href );

    S_w2log( 3, "PRD12_Electronic_Firing_Enable: Finished enabling electronic firing.\n" );

    # STEP return 1 incase of success, otherwise an undef
    return 1;
}

=head2 PRD12_Electronic_Firing_Fire

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Electronic_Firing_Fire'>PRD_Electronic_Firing_Fire documentation</a>
<br><br>

=cut

sub PRD12_Electronic_Firing_Fire {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Electronic_Firing_Fire()', @args ) or return;

    S_w2log( 3, "PRD12_Electronic_Firing_Fire: Start firing squibs...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # CALL LIFT_PDLayer::PDL_FireAllDevices
    my $response_href = CallDeviceFunction();

    return unless ( defined $response_href );

    S_w2log( 4, "PRD12_Electronic_Firing_Fire : success - Fired devices\n" );

    # firing status (byte 3 - 1(offset))
    my $firing_status = $response_href->{CompletePdMsg}[2];
    if ( $firing_status == 0 ) {
        S_w2log( 3, "PRD12_Electronic_Firing_Fire : Firing status byte = 0: Not all devices fired\n" );
    }
    elsif ( $firing_status == 1 ) {
        S_w2log( 3, "PRD12_Electronic_Firing_Fire : Firing status byte = 1: All devices fired\n" );
    }
    else {
        S_w2log( 3, "PRD12_Electronic_Firing_Fire : Firing status byte = '$firing_status' (Unknown Status)\n" );
    }

    # STEP return $firingStatus_href incase of success, otherwise an undef
    my $firingStatus_href->{response_href} = $response_href;

    return $firingStatus_href;
}

=head2 PRD12_Sensor_Verification

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Sensor_Verification'>PRD_Sensor_Verification documentation</a>
<br><br>

=cut

sub PRD12_Sensor_Verification {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Sensor_Verification( $sensorConfig_href )', @args ) or return;
    my $sensorConfig_href = shift @args;

    my $sensorConfigLocal_href = dclone $sensorConfig_href;    # using a copy of the original hashref because we will modify the hashref later

    S_w2log( 3, "PRD12_Sensor_Verification: Start sending sensor verification request...\n" );

    # STEP CheckPreconditions
    CheckPreconditions() or return;

    # STEP check amount_samples
    my $nbrOfSamples = $sensorConfigLocal_href->{'amount_samples'};
    if ( $nbrOfSamples < 2 || $nbrOfSamples > 2048 ) {
        S_set_error( "PRD12_Sensor_Verification: 'amount_samples' = '$nbrOfSamples' is not valid! Please select a value between 2 and 2048.", 109 );
        return;
    }

    # STEP check sensor_type
    my $sensor_type = $sensorConfigLocal_href->{'sensor_type'};
    if ( lc($sensor_type) ne lc('SMI7') and lc($sensor_type) ne lc('SMI8') ) {
        S_set_error( "PRD12_Sensor_Verification: 'sensor_type' = '$sensor_type' is not valid! Only 'SMI7' and 'SMI8' are supported.", 109 );
        return;
    }

    #IF sensor_type is 'SMI7'?
    my $sensorData_href;
    if ( lc($sensor_type) eq lc('SMI7') ) {

        #IF-YES-START
        #CALL PRD12_SMI7_Sensor_Verification
        $sensorData_href = PRD12_SMI7_Sensor_Verification($sensorConfigLocal_href);

        #IF-YES-END
    }
    else {
        #IF-NO-START
        #CALL PRD12_SMI8_Sensor_Verification
        $sensorData_href = PRD12_SMI8_Sensor_Verification($sensorConfigLocal_href);

        #IF-NO-END
    }

    return unless defined $sensorData_href;

    S_w2log( 3, "PRD12_Sensor_Verification: Finished request and received the data for the sensor type : '$sensor_type' \n" );

    #STEP return sensor type and ECU response
    my $finalResponse_href = {
        'sensor_type'   => $sensor_type,
        'response_href' => $sensorData_href,
    };

    return $finalResponse_href;
}

=head2 PRD12_SMI7_Sensor_Verification (not exported)

    $sensorData_href = PRD12_SMI7_Sensor_Verification( $sensorConfig_href );

=cut

sub PRD12_SMI7_Sensor_Verification {
    my $sensorConfig_href = shift;

    #STEP setup sensor request byte table
    my $sensor_request_bytes_href = {
        'Sensor1_Rate' => { 'byte' => 0, 'bit' => 0 },
        'Sensor1_ACC1' => { 'byte' => 0, 'bit' => 2 },
        'Sensor1_ACC2' => { 'byte' => 0, 'bit' => 4 },
        'Sensor2_Rate' => { 'byte' => 1, 'bit' => 0 },
        'Sensor2_ACC1' => { 'byte' => 1, 'bit' => 2 },
        'Sensor2_ACC2' => { 'byte' => 1, 'bit' => 4 },
        'Sensor3_Rate' => { 'byte' => 2, 'bit' => 0 },
        'Sensor3_ACC1' => { 'byte' => 2, 'bit' => 2 },
        'Sensor3_ACC2' => { 'byte' => 2, 'bit' => 4 },
        'Sensor4_Rate' => { 'byte' => 3, 'bit' => 0 },
        'Sensor4_ACC1' => { 'byte' => 3, 'bit' => 2 },
        'Sensor4_ACC2' => { 'byte' => 3, 'bit' => 4 },
    };

    #IF $sensorConfig_href->{ALL} is defined ?
    if ( defined $sensorConfig_href->{ALL} ) {

        #IF-YES-START
        #STEP replace all values in $sensorConfig_href with the value set for ALL
        my $processing = $sensorConfig_href->{ALL};
        delete $sensorConfig_href->{ALL};
        foreach my $sensor ( keys %{$sensor_request_bytes_href} ) {
            $sensorConfig_href->{$sensor} = $processing;
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP throw error and return if $sensorConfig_href has not all mandatory keys
    my @mandatoryInputKeys = ( 'sensor_type', keys %$sensor_request_bytes_href, 'amount_samples' );

    if ( my @inputKeysNotFound = grep { !defined $sensorConfig_href->{$_} } @mandatoryInputKeys ) {
        S_set_error( "PRD12_SMI7_Sensor_Verification: Mandatory Input keys not defined in \$sensorConfig_href: " . join( ',', @inputKeysNotFound ), 110 );
        return;
    }

    #STEP setup 4 request bytes with values 0
    my @requestBytes = ( 0, 0, 0, 0 );

    #LOOP-START loop over all sensors in sensor request byte table
    foreach my $sensor ( sort keys %{$sensor_request_bytes_href} ) {

        #STEP get frequency and mode from sensor config value
        my ( $freq, $mode );
        if ( $sensorConfig_href->{$sensor} =~ /^(LF|HF)_(raw|processed)$/i ) {
            $freq = $1;
            $mode = $2;
        }
        else {
            S_set_error( "PRD12_SMI7_Sensor_Verification: Value '$sensorConfig_href->{$sensor}' for key '$sensor' in \$sensorConfig_href is unknown (should be one of 'LF_raw', 'HF_raw', 'LF_processed' or 'HF_processed' ", 109 );
            return;
        }

        #STEP determine request byte and bit to be set for sensor
        my $byte = $sensor_request_bytes_href->{$sensor}{'byte'};
        my $bit  = $sensor_request_bytes_href->{$sensor}{'bit'};

        #Check if bits have to be set
        #STEP if frequency is 'HF' then bit is set in the determined byte
        if ( uc($freq) eq 'HF' ) {
            $requestBytes[$byte] |= 1 << $bit;
        }

        #STEP if mode is 'processed' then next bit is set in the determined byte
        if ( lc($mode) eq 'processed' ) {
            $requestBytes[$byte] |= 1 << ( $bit + 1 );
        }
    }

    #LOOP-END last sensor?

    #STEP call device function with request bytes and number of samples
    my $nbrOfSamples = $sensorConfig_href->{'amount_samples'};
    my $sensorData_href = CallDeviceFunction( \@requestBytes, $nbrOfSamples );

    #END return $sensorData_href
    return $sensorData_href;
}

=head2 PRD12_SMI8_Sensor_Verification (not exported)

    $sensorData_href = PRD12_SMI8_Sensor_Verification( $sensorConfig_href );

=cut

sub PRD12_SMI8_Sensor_Verification {
    my $sensorConfig_href = shift;

    #STEP setup sensor request byte table
    my $sensor_request_bytes_href = {
        AccX_low_g            => { 'byte' => 0, 'bit' => 0 },
        AccY_low_g            => { 'byte' => 0, 'bit' => 1 },
        AccZ_low_g            => { 'byte' => 0, 'bit' => 2 },
        AccY_redundant_low_g  => { 'byte' => 0, 'bit' => 5 },
        AccZ_redundant_low_g  => { 'byte' => 0, 'bit' => 6 },
        AccX_mid_g            => { 'byte' => 1, 'bit' => 0 },
        AccY_mid_g            => { 'byte' => 1, 'bit' => 1 },
        AccZ_mid_g            => { 'byte' => 1, 'bit' => 2 },
        AccX_high_g           => { 'byte' => 2, 'bit' => 0 },
        AccY_high_g           => { 'byte' => 2, 'bit' => 1 },
        AccX_redundant_high_g => { 'byte' => 2, 'bit' => 4 },
        AccY_redundant_high_g => { 'byte' => 2, 'bit' => 5 },
        Rate_wX               => { 'byte' => 3, 'bit' => 0 },
        Rate_wY               => { 'byte' => 3, 'bit' => 1 },
        Rate_wZ               => { 'byte' => 3, 'bit' => 2 },
        Rate_wZ_redundant     => { 'byte' => 3, 'bit' => 6 },
    };

    #IF $sensorConfig_href->{ALL} is defined ?
    if ( defined $sensorConfig_href->{ALL} ) {

        #IF-YES-START
        #STEP set values in $sensorConfig_href for all sensors with the value set for ALL
        my $processing = $sensorConfig_href->{ALL};
        delete $sensorConfig_href->{ALL};
        foreach my $sensor ( keys %{$sensor_request_bytes_href} ) {
            $sensorConfig_href->{$sensor} = $processing;
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    my $nbrOfSamples = $sensorConfig_href->{'amount_samples'};
    delete $sensorConfig_href->{'amount_samples'};
    my $sensor_type = $sensorConfig_href->{'sensor_type'};
    delete $sensorConfig_href->{'sensor_type'};

    #STEP throw error and return if $sensorConfig_href has invalid keys
    if ( my @inputKeysInvalid = grep { !defined $sensor_request_bytes_href->{$_} } keys %{$sensorConfig_href} ) {
        S_set_error( "PRD12_SMI8_Sensor_Verification: The following keys in \$sensorConfig_href are invalid: " . join( ',', @inputKeysInvalid ), 110 );
        return;
    }

    #STEP setup 4 request bytes with values 0
    my @requestBytes = ( 0, 0, 0, 0 );

    #LOOP-START loop over all sensors in sensor request byte table
    foreach my $sensor ( sort keys %{$sensorConfig_href} ) {

        #STEP get mode from sensor config value
        my $mode = $sensorConfig_href->{$sensor};
        if ( lc($mode) ne 'raw' and lc($mode) ne 'processed' ) {
            S_set_error( "PRD12_SMI8_Sensor_Verification: Value '$mode' for key '$sensor' in \$sensorConfig_href is unknown (should be either 'raw' or 'processed')", 109 );
            return;
        }

        #STEP determine request byte and bit to be set for sensor
        my $byte = $sensor_request_bytes_href->{$sensor}{'byte'};
        my $bit  = $sensor_request_bytes_href->{$sensor}{'bit'};

        #STEP if mode is 'processed' then the bit is set in the determined byte
        if ( lc($mode) eq 'processed' ) {
            $requestBytes[$byte] |= 1 << $bit;
        }
    }

    #LOOP-END last sensor?

    #CALL PRD12_SMI8_Sensor_Verification_StartRoutine with request bytes and number of samples
    my $response_href = PRD12_SMI8_Sensor_Verification_StartRoutine( \@requestBytes, $nbrOfSamples );

    return unless defined $response_href;

    my $timeOut_ms   = 3000;
    my $timeOut_Log  = 0;
    my $step_time_ms = 500;

    #LOOP-START repeat
    while ( $timeOut_ms > 0 ) {

        #CALL PRD12_SMI8_Sensor_Verification_RequestRoutineResults
        $response_href = PRD12_SMI8_Sensor_Verification_RequestRoutineResults();

        #IF response status defined?
        if ( not defined $response_href->{Status} ) {

            #IF-NO-START
            #END throw error and return
            S_set_error( "PRD12_SMI8_Sensor_Verification: Negative response received after '$timeOut_Log' milli seconds.", 109 );
            return;

            #IF-NO-END
        }

        #IF-YES-START
        #IF response status == 0?
        elsif ( $response_href->{Status} == 0 ) {

            #IF-YES-START
            #END return response
            S_w2log( 3, "PRD12_SMI8_Sensor_Verification: Received results after '$timeOut_Log' milli seconds\n" );
            return $response_href;

            #IF-YES-END
        }
        else {
            #IF-NO-START
            #STEP wait and increase timeout counter
            $timeOut_ms -= $step_time_ms;
            S_wait_ms($step_time_ms);
            $timeOut_Log += $step_time_ms;

            #IF-NO-END
        }

        #IF-YES-END
    }

    #LOOP-END timeout reached?

    #END throw timeout error and return
    S_set_error( "PRD12_SMI8_Sensor_Verification: No results received after '$timeOut_Log' milli seconds ", 109 );
    return;

}

sub PRD12_SMI8_Sensor_Verification_StartRoutine {
    my $smi8sma7dataBlock_aref = shift;
    my $noOfSamples            = shift;

    #STEP call device function with $smi8sma7dataBlock_aref and $noOfSamples
    my $response_href = CallDeviceFunction( $smi8sma7dataBlock_aref, $noOfSamples );

    #END return response
    return $response_href;
}

sub PRD12_SMI8_Sensor_Verification_RequestRoutineResults {

    #STEP call device function
    my $response_href = CallDeviceFunction();

    #END return response
    return $response_href;
}

=head2 PRD12_Read_Cell

    $memoryContents = PRD12_Read_Cell( $label [, $options_href ] );
    
    $options_href can contain one of these options:
    
        noOfBytes => <integer> # if given then this number of bytes is read
        
        memoryContentsAsInteger => 0|1 # default is 0 
        
        Note: When both 'memoryContentsAsInteger' and 'noOfBytes' are passed only 'memoryContentsAsInteger' is considered. It is recommended to pass only one option.

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_Memory'>PRD_Read_Memory documentation</a>
<br><br>

=cut

sub PRD12_Read_Cell {
    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Read_Cell( $label[, $options_href] )', @args ) or return;

    my $label        = shift @args;
    my $options_href = shift @args;

    my $nbrOfBytes              = $options_href->{'NbrOfBytes'};
    my $memoryContentsAsInteger = $options_href->{'memoryContentsAsInteger'};

    S_w2log( 4, "PRD12_Read_Cell: Start reading memory at '$label'...\n" );
    
    if ( defined $nbrOfBytes && defined $memoryContentsAsInteger ) {
    	S_set_warning("PRD12_Read_Cell: Both 'NbrOfBytes' and 'memoryContentsAsInteger' are given, only 'memoryContentsAsInteger' will be considered\n");
    }

    #If the $nbrOfBytes is defined, Check if its valid
    if ( defined $nbrOfBytes && $nbrOfBytes !~ /^\d+$/ ) {
        S_w2log( 4, " PRD12_Read_Cell : Invalid \$nbrOfBytes = '$nbrOfBytes'(Not a number). Taking the \$nbrOfBytes from Symbol\n" );
        $nbrOfBytes = undef;
    }

    #If the $memoryContentsAsInteger is defined, Check if its valid
    if ( defined $memoryContentsAsInteger && !( $memoryContentsAsInteger ~~ ( 0, 1 ) ) ) {
        S_w2log( 4, " PRD12_Read_Cell : Invalid \$memoryContentsAsInteger = '$memoryContentsAsInteger'(Neither 1 nor 0). Considering 0 by default\n" );
        $memoryContentsAsInteger = 0;
    }

    CheckPreconditions() or return;

    # CALL ValidateAddressOrSymbol(labelOrAddress)
    my $address = ValidateAddressOrSymbol($label);
    return unless ( defined($address) );

    # CALL GetSymbolDataTypeFromAddOrLabel(labelOrAddress)
    my $symbolDataType;
    $symbolDataType = GetSymbolDataTypeFromAddOrLabel($label) // 'U8';

    my $nbrOfByteFrmSymbol;
    $nbrOfByteFrmSymbol = $1 / 8 if ( defined $symbolDataType && $symbolDataType =~ /[usb](\d+)$/i );

    $nbrOfBytes = $nbrOfByteFrmSymbol if ( not defined $nbrOfBytes and defined $nbrOfByteFrmSymbol );
    $nbrOfBytes = $nbrOfByteFrmSymbol if ( defined $memoryContentsAsInteger && $memoryContentsAsInteger == 1 );

    # IF Is $nbrOfBytes not defined or greater than 2047?
    #   IF-YES-START
    #     STEP Print in the log that default value of $nbrOfBytes is considered as 1
    #     STEP Assign $nbrOfBytes = 1
    if ( not defined $nbrOfBytes or $nbrOfBytes > 2047 ) {
        S_w2log( 4, "PRD12_Read_Cell : Either Nbr of Bytes \$nbrOfBytes is not defined or is greater than 2047, so by default '1' is considered\n" );
        $nbrOfBytes = 1;
    }

    #   IF-YES-END
    #   IF-NO-START
    #   IF-NO-END
    #     CALL LIFT_PDLayer::PDL_Read_Memory
    my $address4print = '0x' . sprintf( '%X', $address );
    S_w2log( 4, "PRD12_Read_Cell : Going to read '$nbrOfBytes' bytes from address '$address4print' \n" );
    my $cellContents_href = CallDeviceFunction( $address, $nbrOfBytes );

    unless ( defined $cellContents_href ) {
        S_set_error( " PRD12_Read_Cell : $label is an invalid address/variable name or failed to read the data\n", 109 );
        return;
    }

    #   IF Is argument memoryContentsAsInteger is set to 1?
    #   IF-YES-START
    #       COMMENT-START
    #           Convert read memory bytes aref to Integer
    #           Using NUM_ListOfBytes2Integer(MemoryContents_aref, DataType)
    #       COMMENT-END
    #       CALL NUM_ListOfBytes2Integer(MemoryContents_aref, DataType)
    my $memoryContents = $cellContents_href->{'DataBytes'};
    if ( defined $memoryContentsAsInteger && $memoryContentsAsInteger == 1 ) {
        $memoryContents = NUM_ListOfBytes2Integer( $memoryContents, $symbolDataType );
    }

    #   IF-YES-END
    #   IF-NO-START
    #   IF-NO-END
    #   STEP Return MemoryContents

    S_w2log( 4, "PRD12_Read_Cell: Finished reading memory.\n" );
    return $memoryContents;

    # STEP END
}

=head2 PRD12_Set_Device_Configuration

    $success = PRD12_Set_Device_Configuration( $devices_modes_href  [, $options_href ] );
    
B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Set_Device_Configuration'>PRD_Set_Device_Configuration documentation</a>
<br><br>

=cut

sub PRD12_Set_Device_Configuration {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Set_Device_Configuration( $device_modes_href [, $options_href ] )', @args ) or return;

    my $device_modes_href = shift @args;
    my $options_href      = shift @args;

    # STEP Fetch the input arguments ($device_modes_href, resetType(optional) and wait_time_after_reset_ms(optional))

    my @devices = keys %{$device_modes_href};
    S_w2log( 3, "PRD12_Set_Device_Configuration: Start configuring devices '@devices'...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # CALL SetOrClear_Device_Bit for each device and mode

    foreach my $device ( keys %{$device_modes_href} ) {
        if ( ref $device_modes_href->{$device} eq 'ARRAY' ) {
            foreach my $mode ( @{ $device_modes_href->{$device} } ) {
                SetOrClear_Device_Bit( $device, $mode ) or return;
            }
        }
        else {
            SetOrClear_Device_Bit( $device, $device_modes_href->{$device} ) or return;
        }
    }

    # IF $options_href is defined
    #   IF-YES-START
    # CALL PRD12_SW_Reset

    if ( defined $options_href ) {
        PRD12_SW_Reset($options_href) or return;
    }

    #  IF-YES-END
    #  IF-NO-START
    #  IF-NO-END
    # STEP return 1 incase of success or undef incase of error

    S_w2log( 3, "PRD12_Set_Device_Configuration: Finished configuring devices.\n" );
    return 1;
}

=head2 PRD12_Get_Device_Configuration

    $device_config_href = PRD12_Get_Device_Configuration( [,$options_href] );

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Get_Device_Configuration'>PRD_Get_Device_Configuration documentation</a>
<br><br>

=cut

sub PRD12_Get_Device_Configuration {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_Device_Configuration( [,$options_href] )', @args ) or return;

    my $options_href = shift @args;

    # IF Is valid parameters and preconditions satisfied?
    #   IF-NO-START
    #       STEP Error, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       CALL GetDevicesInfo([,$options_href])
    #   IF-YES-END
    # STEP END

    S_w2log( 3, "PRD12_Get_Device_Configuration: Start getting device configuration...\n" );
    CheckPreconditions() or return;

    my $device_config_href = {};

    if ( keys(%$options_href) ) {
        return unless ValidateGetDevice($options_href);
        $device_config_href = GetDevicesInfo($options_href);
    }
    else {
        $device_config_href = GetDevicesInfo($options_href);
    }

    S_w2log( 3, "PRD12_Get_Device_Configuration: Finished getting device configuration.\n" );
    return $device_config_href;
}

=head2 PRD12_Write_Cell

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Write_Memory'>PRD_Write_Memory documentation</a>
<br><br>

=cut

sub PRD12_Write_Cell {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Write_Cell( $addressOrSymbol, $memoryContents_mix  )', @args ) or return;

    my $addressOrSymbol = shift @args;
    my $memoryContents  = shift @args;

    S_w2log( 4, "PRD12_Write_Cell: Start writing memory at '$addressOrSymbol'...\n" );

    CheckPreconditions() or return;

    # CALL ValidateAddressOrSymbol
    my $address = ValidateAddressOrSymbol($addressOrSymbol) or return;

    # STEP offline return
    return 1 if ($main::opt_offline);

    # IF Is $address defined?
    #   IF-YES-START
    my ( $memoryContents_aref, $formatEndianness );

    # IF Is $memoryContent is an aref?
    if ( ref $memoryContents eq 'ARRAY' ) {

        # IF-YES-START
        #   STEP Convert the $memoryContent_aref to integer format if it is in hexstring format
        # IF-Yes-END
        $memoryContents_aref = $memoryContents;
        foreach my $byte (@$memoryContents_aref) {
            $byte = hex( lc($byte) ) if $byte =~ /^0x/i;
            if ( $byte =~ /\./ ) {
                S_set_error( "PRD12_Write_Cell : '$byte' is a float\n", 114 );
                return;
            }
        }
    }
    else {

        # IF-NO-START
        #   CALL GetSymbolDataTypeFromAddOrLabel
        my $symbolDataType = GetSymbolDataTypeFromAddOrLabel($address);

        $symbolDataType = 'U8' unless ( defined $symbolDataType );

        #   COMMENT-START
        #       Covert Integer input to Array of integer bytes
        #       i.e. NUM_Integer2ListOfBytes( IntegerToConvert, SymbolDataType)
        #   COMMENT-END
        #   CALL NUM_Integer2ListOfBytes
        $memoryContents_aref = NUM_Integer2ListOfBytes( $memoryContents, $symbolDataType ) or return;
        $formatEndianness = 1;

        # IF-NO-END

    }

    #   IF $memoryContent_aref are within the range [0-255] and are not floating point value
    #       IF-YES-START
    #           STEP Write the data given in $memoryContent_aref into ECU
    #           CALL LIFT_PDLayer::PDL_Write_Memory
    #       IF-YES-END
    #       IF-NO-START
    #       IF-NO-END
    #   IF-YES-END
    #   IF-NO-START

    S_w2log( 4, " PRD12_Write_Cell : Writes data '@$memoryContents_aref' into ECU at '$addressOrSymbol' \n" );

    foreach my $byte (@$memoryContents_aref) {
        if ( $byte > 255 or $byte < 0 ) {    # check if 0 =< byte <= 255
            S_set_error( "PRD12_Write_Cell : byte value '$byte' is out of range ( 0<=x<=255 )", 114 );
            return;
        }
    }
    my $response_href = CallDeviceFunction( $address, $memoryContents_aref, $formatEndianness );

    unless ( defined $response_href ) {
        S_set_error( " PRD12_Write_Cell : $addressOrSymbol is an invalid address/variable name or failed to write the data\n", 109 );
        return;
    }

    #   IF-NO-END
    # STEP return 1 incase of success or undef incase of error

    S_w2log( 4, "PRD12_Write_Cell: Finished writing memory.\n" );
    return 1;
}

=head2 PRD12_Read_NVM_cells

    $nvmContents_aref = PRD12_Read_NVM_cells( $blockConfig_href );


B<Arguments:>

=over

=item $blockConfig_href

    $blockConfig_href = {
        noOfBytes => <int>,
        blockID => <int>,
        subBlockID => <int>, # default 0
        offset => <int>, # default 0
        format_data_by_endianness => 0|1, # default 1
    }

=back


B<Return Values:>

=over

=item $nvmContents_aref

    Array reference containing nvm data.

=back


B<Examples:>

B<Notes:> 

=cut

sub PRD12_Read_NVM_cells {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Read_NVM_cells( $blockConfig_href )', @args ) or return;
    my $blockConfig_href = shift @args;

    my $nvmContents_aref;
    my $noOfBytes                 = $blockConfig_href->{noOfBytes};
    my $blockID                   = $blockConfig_href->{blockID};
    my $subBlockID                = $blockConfig_href->{subBlockID} // 0;
    my $offset                    = $blockConfig_href->{offset} // 0;
    my $format_data_by_endianness = $blockConfig_href->{format_data_by_endianness} // 1;

    my $errFlag = 0;
    unless ( defined $noOfBytes ) {
        S_set_error( "PRD12_Read_NVM_cells: Mandatory key 'noOfBytes' is not configured!", 109 );
        $errFlag = 1;
    }
    unless ( defined $blockID ) {
        S_set_error( "PRD12_Read_NVM_cells: Mandatory key 'blockID' is not configured!", 109 );
        $errFlag = 1;
    }
    return if ($errFlag);

    #IF is valid arguments?
    #   IF-NO-START
    #      STEP Error invalid arguments, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       CALL LIFT_PDLayer::PDL_ReadNvmDatabyID(noOfBytes, blockID, subBlockID, offset)
    #   IF-YES-END
    #STEP END
    my $response_href = CallDeviceFunction( $noOfBytes, $blockID, $subBlockID, $offset, $format_data_by_endianness ) or return;

    return $response_href->{DataBytes};
}

=head2 PRD12_Write_NVM_cells

B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Write_ECU_NVM'PRD_Write_ECU_NVM Documentation</a>
<br><br>

=cut

sub PRD12_Write_NVM_cells {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Write_NVM_cells( $nvmConfig_href, $nvmMemoryContents_aref )', @args ) or return;
    my $nvmConfig_href         = shift @args;
    my $nvmMemoryContents_aref = shift @args;

    #STEP validate arguments
    my $validArgs_href = { block_name => 1, block_ID => 1, no_of_bytes => 1 };
    S_checkFunctionArgumentHashKeys( 'PRD12_Write_NVM_cells', $nvmConfig_href, $validArgs_href, {} ) or return;

    my $block_name  = $nvmConfig_href->{block_name};
    my $block_ID    = $nvmConfig_href->{block_ID};
    my $no_of_bytes = $nvmConfig_href->{no_of_bytes};

    S_w2log( 4, "PRD12_Write_NVM_cells: Start writing NVM memory at block_name = '$block_name', block_ID = '$block_ID', no_of_bytes = '$no_of_bytes'...\n" );

    if ( defined $block_name and defined $block_ID ) {
        S_set_error( "Both 'block_name' and 'block_ID' are defined in \$nvmConfig_href. Only one of them may be defined.", 109 );
        return;
    }
    elsif ( not defined $block_name and not defined $block_ID ) {
        S_set_error( "Neither 'block_name' nor 'block_ID' are defined in \$nvmConfig_href. One of them must be defined.", 109 );
        return;
    }

    #STEP CheckPreconditions
    CheckPreconditions() or return;

    #STEP Get block_ID from block_name
    my $block_length;
    if ( defined $block_name ) {
        $block_ID     = $symbolMapping_href->{nvm}{block}{$block_name}{block_ID};
        $block_length = $symbolMapping_href->{nvm}{block}{$block_name}{block_length};
        if ( not defined $block_ID ) {
            S_set_error( "For given 'block_name' = '$block_name' no block_ID could be found in .nvm file.", 109 );
            return;
        }
        S_w2log( 4, "PRD12_Write_NVM_cells: For block_name = '$block_name' the block_ID = '$block_ID' and block_length = '$block_length' is used.\n" );
    }

    #STEP Get block_length
    if ( defined $no_of_bytes ) {
        $block_length = $no_of_bytes;
        S_w2log( 4, "PRD12_Write_NVM_cells: block_length = '$block_length' is explicitly set.\n" );
    }
    if ( not defined $block_length ) {
        $block_length = @$nvmMemoryContents_aref;
        S_w2log( 4, "PRD12_Write_NVM_cells: block_length = '$block_length' is taken from size of data to write.\n" );
    }

    if ( $block_length > @$nvmMemoryContents_aref ) {
        $block_length = @$nvmMemoryContents_aref;
        S_w2log( 4, "PRD12_Write_NVM_cells: given block length is > size of data to write, so block_length is truncated to the size of data to write (= '$block_length').\n" );
    }
    elsif ( $block_length < @$nvmMemoryContents_aref ) {
        splice( @$nvmMemoryContents_aref, $block_length );
        S_set_warning("PRD12_Write_NVM_cells: given block length is < size of data to write. Only $block_length bytes of given data will be written.");
    }

    foreach my $byte (@$nvmMemoryContents_aref) {
        if ( $byte > 255 or $byte < 0 ) {    # check if 0 =< byte <= 255
            S_set_error( "PRD12_Write_NVM_cells: byte value '$byte' is out of range ( 0<=x<=255 )", 114 );
            return;
        }
    }

    S_w2log( 4, "PRD12_Write_NVM_cells: Writing data '@$nvmMemoryContents_aref' into NVM at ID '$block_ID' with block length '$block_length' \n" );

    #STEP Call device level function
    my $response_href = CallDeviceFunction( $nvmMemoryContents_aref, $block_length, $block_ID, 0, 0 ) or return;

    S_w2log( 4, "PRD12_Write_NVM_cells: Finished writing to NVM memory.\n" );
    return 1;
}

=head2 PRD12_Get_Symbol_Mapping

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Get_Symbol_Mapping'>PRD_Get_Symbol_Mapping documentation</a>
<br><br>

=cut

sub PRD12_Get_Symbol_Mapping {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_Symbol_Mapping( $mappingPart_href )', @args ) or return;
    my $mappingPart_href = shift @args;

    #STEP CheckPreconditions
    CheckPreconditions() or return;

    #STEP return with error if User specified more than one key in the Input_href
    if ( scalar( keys %$mappingPart_href ) > 1 ) {
        S_set_error( " PRD12_Get_Symbol_Mapping : Using more than one input key is not allowed! Please specify either 'symbol_name'/'fault_name'\n", 109 );
        return;
    }

    #IF input key = symbol_name?
    if ( defined $mappingPart_href->{'symbol_name'} ) {

        # STEP offline return
        return { 'enum_or_mask' => '\n', 'address' => 4273934933, 'description' => 'Parameter ID' } if ($main::opt_offline);

        #IF-YES-START
        #STEP get symbol mapping part
        my $symName         = $mappingPart_href->{'symbol_name'};
        my $symMapping_href = $symbolMapping_href->{'sad'}{'symbol'}{$symName};

        #STEP return undef if symbol mapping part does not exist
        if ( not defined $symMapping_href ) {
            S_w2log( 3, "PRD12_Get_Symbol_Mapping : No entries found for the symbol : '$symName' in Symbol mapping\n" );
            return;
        }

        #STEP return symbol mapping part
        S_w2log( 3, "PRD12_Get_Symbol_Mapping : Successfully read the symbol mapping for symbol : '$symName'\n" );
        return $symMapping_href;

        #IF-YES-END
    }

    #IF-NO-START
    #IF input key = fault_name?
    elsif ( defined $mappingPart_href->{'fault_name'} ) {

        # STEP offline return
        return 100 if ($main::opt_offline);

        #IF-YES-START
        #STEP get fault ID
        my $fltName = $mappingPart_href->{'fault_name'};
        my $fltID   = $symbolMapping_href->{'flt'}{'fltNametoID'}{$fltName};

        #STEP return undef if fault ID does not exist
        if ( not defined $fltID ) {
            S_w2log( 3, "PRD12_Get_Symbol_Mapping : No entries found for the Faultname : '$fltName' in Symbol mapping\n" );
            return;
        }

        #STEP return fault ID
        S_w2log( 3, "PRD12_Get_Symbol_Mapping : Successfully read the Fault ID '$fltID' for Fault name : '$fltName'\n" );
        return $fltID;

        #IF-YES-END
    }

    #IF-NO-START
    #IF input key = enum_type_name?
    elsif ( defined $mappingPart_href->{'enum_type'} ) {

        # STEP offline return
        return { 'rb_wimi_SysWIOffBeforeInitPhase_e' => { 'value' => 0, 'comment' => 'Indicator is off before the initialization phase' } } if ($main::opt_offline);

        #IF-YES-START
        #STEP get enum mapping part
        my $enumType         = $mappingPart_href->{'enum_type'};
        my $enumMapping_href = $symbolMapping_href->{cns}{enum}{$enumType};

        #STEP return undef if enum mapping part does not exist
        if ( not defined $enumMapping_href ) {
            S_w2log( 3, "PRD12_Get_Symbol_Mapping : No entries found for enum type : '$enumType' in Symbol mapping\n" );
            return;
        }

        #STEP return enum mapping part
        S_w2log( 3, "PRD12_Get_Symbol_Mapping : Successfully read the enum mapping for enum type : '$enumType'\n" );
        return $enumMapping_href;

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END

    #STEP throw error for unknown key
    S_set_error( "PRD12_Get_Symbol_Mapping : Please specify one of 'symbol_name'/'fault_name'/'enum_type' as part of \$mappingPart_href", 109 );
    return;
}

=head2 PRD12_Check_ECU_Properties

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Check_ECU_Properties'>PRD_Check_ECU_Properties Documentation</a>
<br><br>

=cut

sub PRD12_Check_ECU_Properties {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Check_ECU_Properties( $expectedProperties_href )', @args ) or return;
    my $expectedProperties_href = shift @args;

    # STEP CheckPreconditions
    #   IF Input validation Successful?
    #   IF-YES-START
    #       For each given properties fetch the actual properties
    #       Compare the expected and actual property
    #       IF All expected property matches with all actual property?
    #       IF-YES-START
    #           STEP Return 1
    #       IF-YES-END
    #       IF-NO-START
    #           STEP Do nothing/Display warning/Error/Fail based on the user input
    #           STEP Return undef
    #       IF-NO-END
    #   IF-YES-END
    #   IF-NO-START
    #       STEP Return undef
    #   IF-NO-END
    # STEP END

    CheckPreconditions() or return;

    my $actionOnMismatch = $expectedProperties_href->{'action_on_mismatch'};
    $actionOnMismatch = 'none' unless ( defined $actionOnMismatch );
    delete $expectedProperties_href->{'action_on_mismatch'};

    unless ( $actionOnMismatch =~ /^(none|warning|error|fail)$/i ) {
        S_set_error( " PRD12_Check_ECU_Properties : Invalid 'action_on_mismatch' = '$actionOnMismatch'! Please specify none/warning/error/fail", 109 );
        return;
    }

    #Get the ECU properties for 'ECU_details'
    my $ecuProperties_href = PRD12_Get_ECU_Properties( { 'Property_names' => ['ECU_details'] } );

    #Store the properties which are not present in actual ECU properties in an array and display it to user
    if ( my @invalidECUProperties = grep { !defined $ecuProperties_href->{'ECU_details'}{$_} } keys %$expectedProperties_href ) {
        S_set_error( "PRD12_Check_ECU_Properties : Actual ECU properties doesnt have the keys specified by \$expectedProperties_href : " . join( ',', @invalidECUProperties ), 110 );
        return;
    }

    my $errorWarningText  = '';
    my $everythingMatched = 1;
    foreach my $ecuProperty ( keys %$expectedProperties_href ) {
        my $expected_value = $expectedProperties_href->{$ecuProperty};
        my $actual_value   = $ecuProperties_href->{'ECU_details'}{$ecuProperty};
        if ( $ecuProperty eq 'EcuSwVersion' && uc($expected_value) eq 'ROMCODE' ) {
            S_w2log( 3, "PRD12_Check_ECU_Properties : EcuSwVersion is 'ROMCODE'. Hence Fetching the ROMCODE value from the \$symbolMapping_href" );
            $expected_value = $symbolMapping_href->{'sad'}{'header'}{'ROMCODE'};
        }

        #As we recieve the properties as string(quoted ''). Do the string comparision
        unless ( lc($expected_value) eq lc($actual_value) ) {
            my $mismatchText = "Mismatch in actual value ($actual_value) and expected value ($expected_value) for property '$ecuProperty'\n";
            $errorWarningText .= $mismatchText;
            S_w2log( 3, "PRD12_Check_ECU_Properties : $mismatchText" );
            $everythingMatched = 0;
            last;
        }
    }

    if ( not $everythingMatched ) {
        $errorWarningText = "PRD12_Check_ECU_Properties: $errorWarningText";
        if ( lc($actionOnMismatch) eq 'none' ) {

            #Do nothing
            return;
        }
        elsif ( lc($actionOnMismatch) eq 'warning' ) {
            S_set_warning($errorWarningText);
            return;
        }
        elsif ( lc($actionOnMismatch) eq 'error' ) {
            if ($main::opt_offline) {
                S_set_warning($errorWarningText);    # in offline mode only a warning
            }
            else {
                S_set_error( $errorWarningText, 109 );    # set error only in online mode
            }
            return;

        }
        else {
            S_w2log( 3, "PRD12_Check_ECU_Properties : Mismatch in actual and expected value of properties. Setting the Verdict to 'FAIL'" );
            S_set_verdict('VERDICT_FAIL');
            return;
        }
    }
    S_w2log( 3, "PRD12_Check_ECU_Properties : All the expected value of ECU property matches with all the actual ECU property values" );
    return 1;

}

=head2 PRD12_Get_Device_Property

    $propertyValue = PRD12_Get_Device_Property( $device [, $options_href ] );

B<For documentation please check:>

=for html

<a href='LIFT_ProdDiag.html#PRD_Get_Device_Property'>PRD_Get_Device_Property Documentation</a>
<br><br>

=cut

sub PRD12_Get_Device_Property {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_Device_Property( $device [, $options_href ]  )', @args ) or return;
    my $device       = shift @args;
    my $options_href = shift @args;

    # STEP CheckPreconditions
    CheckPreconditions() or return;

    # If the property_name is not defined, then property_name='index'
    my $propertyName = $options_href->{'property_name'} // 'index';

    # STEP Validate $propertyName, return undef on error
    unless ( $propertyName =~ /^(index|bitmask|bytecount)$/i ) {
        S_set_error( "PRD12_Get_Device_Property : Invalid property name '$propertyName', Please specify anyone among: index, bitmask or bytecount", 114 );
        return;
    }

    #STEP Apply DEVICE_CONFIG mapping if it exists
    my $mappedDevice = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device};
    if ( defined $mappedDevice ) {
        S_w2log( 4, "PRD12_Get_Device_Property : Given device name '$device' is mapped to '$mappedDevice' according to ProjectDefaults->{'DEVICE_CONFIG'}\n" );
        $device = $mappedDevice;
    }

    # STEP Parse $allDevDetails_href for device
    my $deviceFoundFlag = 0;
    foreach my $deviceType ( keys %{$allDevDetails_href} ) {
        my $deviceTypeDetails_href = $allDevDetails_href->{$deviceType};
        foreach my $deviceName ( keys %$deviceTypeDetails_href ) {

            # IF Is device found?
            if ( $device eq $deviceName ) {

                # IF-YES-START
                # IF Is Property value defined?
                $deviceFoundFlag = 1;
                my $propertyValue = $deviceTypeDetails_href->{$deviceName}{ lc($propertyName) };
                if ( defined $propertyValue ) {

                    # IF-YES-START
                    # STEP Return Property Value
                    S_w2log( 3, "PRD12_Get_Device_Property : Found '$device' -> '$propertyName' = '$propertyValue'\n" );
                    return $propertyValue;

                    # IF-YES-END
                }

                # IF-NO-START
                # IF-NO-END

                # IF-YES-END
            }
        }
    }

    unless ($deviceFoundFlag) {

        # IF-NO-START
        # STEP return Undef
        S_set_warning("PRD12_Get_Device_Property : No entries found for the device '$device' \n");
        return;

        # IF-NO-END
    }

    # STEP END
}

=head2 PRD12_Read_ECU_NVM

    $nvmMemoryContents_aref = PRD12_Read_ECU_NVM( $nvmConfig_href );

    $nvmConfig_href = {
        block_name => ...,   # string, block name as defined in the nvm file
        block_ID => ...,     # integer, block ID number
        no_of_bytes => ...,  # integer, number of bytes to be read
        format_data_by_endianness => 0|1, # default = 0
    }


B<For documentation please check:>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_ECU_NVM'PRD_Read_ECU_NVM Documentation</a>
<br><br>

=cut

sub PRD12_Read_ECU_NVM {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Read_ECU_NVM( $nvmConfig_href )', @args ) or return;
    my $nvmConfig_href = shift @args;

    #STEP validate arguments
    my $validArgs_href = { block_name => 1, block_ID => 1, no_of_bytes => 1, format_data_by_endianness => 1 };
    S_checkFunctionArgumentHashKeys( 'PRD12_Read_ECU_NVM', $nvmConfig_href, $validArgs_href, {} ) or return;

    my $block_name                = $nvmConfig_href->{block_name};
    my $block_ID                  = $nvmConfig_href->{block_ID};
    my $no_of_bytes               = $nvmConfig_href->{no_of_bytes};
    my $format_data_by_endianness = $nvmConfig_href->{format_data_by_endianness} // 0;

    S_w2log( 4, "PRD12_Read_ECU_NVM: Start reading NVM memory at block_name = '$block_name', block_ID = '$block_ID', no_of_bytes = '$no_of_bytes', format_data_by_endianness = '$format_data_by_endianness'...\n" );

    if ( defined $block_name and defined $block_ID ) {
        S_set_error( "Both 'block_name' and 'block_ID' are defined in \$nvmConfig_href. Only one of them may be defined.", 109 );
        return;
    }
    elsif ( not defined $block_name and not defined $block_ID ) {
        S_set_error( "Neither 'block_name' nor 'block_ID' are defined in \$nvmConfig_href. One of them must be defined.", 109 );
        return;
    }

    #STEP CheckPreconditions
    CheckPreconditions() or return;

    #STEP handle offline return
    if ($main::opt_offline) {
        $symbolMapping_href->{nvm}{block}{$block_name}{block_ID}     = 1;
        $symbolMapping_href->{nvm}{block}{$block_name}{block_length} = 2;
    }

    #STEP Get block_ID from block_name
    my $block_length;
    if ( defined $block_name ) {
        $block_ID     = $symbolMapping_href->{nvm}{block}{$block_name}{block_ID};
        $block_length = $symbolMapping_href->{nvm}{block}{$block_name}{block_length};
        if ( not defined $block_ID ) {
            S_set_error( "For given 'block_name' = '$block_name' no block_ID could be found in .nvm file.", 109 );
            return;
        }
        S_w2log( 4, "PRD12_Read_ECU_NVM: For block_name = '$block_name' the block_ID = '$block_ID' and block_length = '$block_length' is used.\n" );
    }

    #STEP Get block_length
    if ( defined $no_of_bytes ) {
        $block_length = $no_of_bytes;
        S_w2log( 4, "PRD12_Read_ECU_NVM: block_length = '$block_length' is explicitly set.\n" );
    }
    if ( not defined $block_length ) {
        S_set_error( "'no_of_bytes' is not given together with 'block_ID' = '$block_ID'.", 109 );
        return;
    }

    #CALL PRD12_Read_NVM_cells with block_ID and block_length
    my $blockConfig_href = {
        blockID                   => $block_ID,
        noOfBytes                 => $block_length,
        subBlockID                => 0,
        offset                    => 0,
        format_data_by_endianness => $format_data_by_endianness,
    };
    my $nvmContents_aref = PRD12_Read_NVM_cells($blockConfig_href);

    S_w2log( 4, "PRD12_Read_ECU_NVM: Finished reading NVM memory.\n" );
    return $nvmContents_aref;
}

=head2 PRD12_Get_Last_Response

    $response_href = PRD12_Get_Last_Response();

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Return_Last_Response'>PRD_Return_Last_Response documentation</a>
<br><br>

=cut

sub PRD12_Get_Last_Response {
    my $response_href      = CallDeviceFunction();
    my $completePdMsg_aref = $response_href->{CompletePdMsg} // [];
    my $message4print      = STR_Aref2HexString($completePdMsg_aref);
    S_w2log( 4, "PRD12_Get_Last_Response: Getting last response with complete PD message '$message4print' \n" );

    return $response_href;
}

=head2 PRD12_AIO_Test_Pattern

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_AIO_Test_Pattern'>PRD_AIO_Test_Pattern documentation</a>
<br><br>

=cut

sub PRD12_AIO_Test_Pattern {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_AIO_Test_Pattern()', @args ) or return;

    S_w2log( 3, "PRD12_AIO_Test_Pattern: Start activation of test pattern...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # CALL LIFT_PDLayer::PDL_FireAllDevices
    my $response_href = CallDeviceFunction();

    return unless ( defined $response_href );

    S_w2log( 4, "PRD12_AIO_Test_Pattern : success - test pattern activated\n" );

    return 1;
}

=head2 PRD12_Set_Secure_PIN

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_AIO_Test_Pattern'>PRD_Set_Secure_PIN documentation</a>
<br><br>

=cut

sub PRD12_Set_Secure_PIN {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Set_Secure_PIN()', @args ) or return;

    S_w2log( 3, "PRD12_Set_Secure_PIN: Start setting Secure PIN...\n" );

    #CALL CheckPreconditions
    CheckPreconditions() or return;

    #STEP get encrypted PIN as hex string from PIN GUI
    my $modulePath = dirname(__FILE__);
    my $command    = $modulePath . '\..\Device_layer\ProdDiag\Win32\SecurePIN.exe';
    my ( $returnValue, @screenOutputLines ) = S_call_command($command);
    my $hexString = shift @screenOutputLines;
    chomp $hexString;

    #STEP check format of hex string
    if ( not defined $hexString or $hexString =~ /error/i ) {
        S_set_error( "Encryption of the entered PIN was not successful: @screenOutputLines", 109 );
        return;
    }
    if ( $hexString =~ /^(.+):(.+)/i or $hexString =~ /(offline)(.+)/i ) {
        my $guiVersion = $1;
        $hexString = $2;
        S_w2log( 3, "PRD12_Set_Secure_PIN: Received encrypted PIN from Secure PIN GUI version $guiVersion.\n" );
    }
    else {
        S_set_error( "Secure PIN GUI returned a wrongly formatted encrypted PIN. Please use the latest version of the GUI.", 109 );
        return;
    }

    #STEP convert hex string to character (byte) string
    my $cipherText = pack "H*", $hexString;    # converts hex bytes to character string

    #STEP execute device function
    my $success = CallDeviceFunction($cipherText);

    return unless $success;

    S_w2log( 4, "PRD12_Set_Secure_PIN: finished setting Secure PIN in diagnosis dll\n" );

    return 1;
}

=head2 PRD12_Read_ASIC_Serial_Numbers

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_Serial_Numbers'>PRD_Read_Serial_Numbers documentation</a>
<br><br>

=cut

sub PRD12_Read_ASIC_Serial_Numbers {

    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Read_ASIC_Serial_Numbers( [$options_href] )', @args ) or return;
    my $options_href = shift @args;

    my $is_plant_mode = $options_href->{'set_plant_mode'};

    S_w2log( 3, "PRD12_Read_ASIC_Serial_Numbers: Start reading System ASIC serial numbers...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # STEP If set_plant_mode is not defined by default consider it as 1
    if ( not defined $is_plant_mode or ( $is_plant_mode != 0 and $is_plant_mode != 1 ) ) {
        $is_plant_mode = '' unless ( defined $is_plant_mode );
        S_w2log( 3, "PRD12_Read_ASIC_Serial_Numbers: set_plant_mode '$is_plant_mode' is either not defined or is not 0|1, so by default '1' is considered\n" );
        $is_plant_mode = 1;
    }

    # STEP if 'set_plant_mode' is 1 then Write "rb_sycg_ActivePlantModes_au8(0)" label value as 40 for enabling the fire Mode
    PRD12_Write_Cell( 'rb_sycg_ActivePlantModes_au8(0)', [64] ) if ( $is_plant_mode == 1 );

    # CALL device layer function
    my $response_href = CallDeviceFunction();

    return unless ( defined $response_href );

    my $payload_aref = $response_href->{PdPayload};
    my $id           = shift @$payload_aref;          # split off (positive) response byte

    if ( $id != 0x57 or @$payload_aref != 18 ) {
        S_set_error( "No positive response or != 18 data bytes received", 109 );
        return;
    }

    my $serialNumbers_href;
    foreach my $asic (qw(ASIC1 ASIC2 ASIC3)) {
        my @dataBytes = splice( @$payload_aref, 0, 6 );
        my @hexList = map { sprintf( "%02X", $_ ) } @dataBytes;
        my $hexString = join( '', @hexList );
        $serialNumbers_href->{$asic} = $hexString;
    }

    S_w2log( 3, "PRD12_Read_ASIC_Serial_Numbers: Finished reading System ASIC serial numbers.\n" );

    # STEP return 1 incase of success, otherwise an undef
    return $serialNumbers_href;
}

=head2 PRD12_Read_ECU_LifeCycle_Data

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Read_ECU_LifeCycle_Data'>PRD_Read_ECU_LifeCycle_Data documentation</a>
<br><br>

=cut

sub PRD12_Read_ECU_LifeCycle_Data {

    S_w2log( 3, "PRD12_Read_ECU_LifeCycle_Data: Start reading ECU life cycle data\n" );

    return unless CheckPreconditions();

    if ( $ecu_details_href->{PdVersionNr} < 15 and $main::opt_offline != 1 ) {
        S_set_error( "Read_ECU_LifeCycle service is not supported for PdVersion less than 15, configured PdVersion is : $ecu_details_href->{PdVersionNr}", 109 );
        return;
    }

    #CALL device layer function
    my $response_href = CallDeviceFunction();
    return unless ($response_href);
    S_w2log( 3, "PRD12_Read_ECU_LifeCycle_Data: Finished reading ECU life cycle data\n" );
    return $response_href;

    #STEP END
}

=head2 PRD12_Switch_ECU_LifeCycle

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Switch_ECU_LifeCycle'>PRD_Switch_ECU_LifeCycle documentation</a>
<br><br>

=cut

sub PRD12_Switch_ECU_LifeCycle {

    my @args = @_;

    S_checkFunctionArguments( 'PRD12_Switch_ECU_LifeCycle( $options_href )', @args ) or return;
    my $options_href     = shift @args;
    my $delayInPOC       = $options_href->{'delayInPOC'} // 0;    # default considered as no delay in  POC
    my $ecuMainLifeCycle = $options_href->{'ecuMainLifeCycle'};

    #STEP validate configured ecu life cycle state
    unless ( exists $ECULIFECYCLE_STATES_HREF->{ uc $ecuMainLifeCycle } ) {
        my @life_cylestates = keys %$ECULIFECYCLE_STATES_HREF;
        S_set_error( "PRD12_Switch_ECU_LifeCycle: Invalid ECU life cycle state '$ecuMainLifeCycle' configured, Supported are : @life_cylestates", 109 );
        return;
    }
    $ecuMainLifeCycle = $ECULIFECYCLE_STATES_HREF->{ uc $ecuMainLifeCycle };
    S_w2log( 3, "PRD_Switch_ECU_LifeCycle: Start switching ECU life cycle to '$ecuMainLifeCycle'\n" );

    return unless CheckPreconditions();

    if ( $ecu_details_href->{PdVersionNr} < 15 and $main::opt_offline != 1 ) {
        S_set_error( "Switch_ECU_LifeCycle service is not supported for PdVersion less than 15, configured PdVersion is : $ecu_details_href->{PdVersionNr}", 109 );
        return;
    }

    # CALL device layer function
    my $response_href = CallDeviceFunction( $delayInPOC, $ecuMainLifeCycle );

    return unless ($response_href);

    S_w2log( 3, "PRD_Switch_ECU_LifeCycle: ECU life cycle will be Switched to '$options_href->{'ecuMainLifeCycle'}' in '$delayInPOC' POC's\n" );
    return $response_href;

    #STEP END
}

=head2 PRD12_SHEKeyCalculatorProtocol

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_SHEKeyCalculatorProtocol'>PRD_SHEKeyCalculatorProtocol documentation</a>
<br><br>

=cut

sub PRD12_SHEKeyCalculatorProtocol {

    my @args         = @_;
    my $options_href = shift @args;

    #STEP validate input parameters
    my $valid_keys_href = { 'M1_Hex_str' => 1, 'M2_Hex_str' => 1, 'M3_Hex_str' => 1, 'SheKeyExtensionId' => 1, 'BankIndex_Hex_str' => 1 };
    my $mand_keys_href = { 'M1_Hex_str' => 1, 'M2_Hex_str' => 1, 'M3_Hex_str' => 1, };
    return unless S_checkFunctionArgumentHashKeys( 'PRD12_SHEKeyCalculatorProtocol', $options_href, $valid_keys_href, $mand_keys_href );

    my ( $m1_bytes_aref, $m2_bytes_aref, $m3_bytes_aref, $bankIndex_bytes_aref );

    $options_href->{'M1_Hex_str'} =~ s/\s+//g;
    $options_href->{'M2_Hex_str'} =~ s/\s+//g;
    $options_href->{'M3_Hex_str'} =~ s/\s+//g;
    $options_href->{'BankIndex_Hex_str'} =~ s/\s+//g if ( defined $options_href->{'BankIndex_Hex_str'} );

    @$m1_bytes_aref        = $options_href->{'M1_Hex_str'} =~ /(..)/g;
    @$m2_bytes_aref        = $options_href->{'M2_Hex_str'} =~ /(..)/g;
    @$m3_bytes_aref        = $options_href->{'M3_Hex_str'} =~ /(..)/g;
    @$bankIndex_bytes_aref = $options_href->{'BankIndex_Hex_str'} =~ /(..)/g if ( defined $options_href->{'BankIndex_Hex_str'} );

    #STEP Assign default values for SheKeyExtensionId and BankIndex if not defined
    my $sheKeyExtensionId = $options_href->{'SheKeyExtensionId'} // 'FF';
    $bankIndex_bytes_aref = [ 'FF', 'FF', 'FF', 'FF' ] if ( not defined @$bankIndex_bytes_aref );

    S_w2log( 3, "PRD12_SHEKeyCalculatorProtocol: Writing Keys M1, M2, M3, SheKeyExtensionId and BankIndex to ECU using SHE protocol started!\n" );
    S_w2log( 3, "M1: $options_href->{'M1_Hex_str'},\n M2: $options_href->{'M2_Hex_str'},\n M3: $options_href->{'M3_Hex_str'}, SheKeyExtensionId: $sheKeyExtensionId, BankIndex: @$bankIndex_bytes_aref\n" );

    #CALL PDL_SHEKeyCalculatorProtocol
    my $response_href = CallDeviceFunction( $m1_bytes_aref, $m2_bytes_aref, $m3_bytes_aref, $sheKeyExtensionId, $bankIndex_bytes_aref );

    return unless ($response_href);

    #STEP return $response_href
    S_w2log( 3, "PRD12_SHEKeyCalculatorProtocol: Successfully Written Keys M1, M2, M3, SheKeyExtensionId and BankIndex using SHE protocol! \n" );
    return $response_href;

    #STEP END
}

=head2 PRD12_Get_Signature_from_KMS

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Get_Signature_from_KMS'>PRD_Get_Signature_from_KMS documentation</a>
<br><br>

=cut

sub PRD12_Get_Signature_from_KMS {

    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Get_Signature_from_KMS( $challenge_aref )', @args ) or return;
    my $challenge_aref = shift @args;

    #CALL PDL_ReceiveResponseFromKMS
    my $signature_href = CallDeviceFunction($challenge_aref);

    return unless ($signature_href);

    my $signature_aref = $signature_href->{'CompletePdMsg'};

    return $signature_aref;

    #STEP END
}

=head2 PRD12_Enable_KMS_Simulator

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_Enable_KMS_Simulator'>PRD_Enable_KMS_Simulator documentation</a>
<br><br>

=cut

sub PRD12_Enable_KMS_Simulator {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_Enable_KMS_Simulator( [$kms_simulator_mode] )', @args ) or return;
    my $kms_simulator_mode = shift @args // 1;    # if not defined then set the value to 1

    #CALL CheckPreconditions
    CheckPreconditions() or return;

    # STEP Check for the valid modes
    my @validModes = ( 0, 1 );
    unless ( grep { /^$kms_simulator_mode$/i } @validModes ) {
        S_set_error( "PRD12_Enable_KMS_Simulator: passed mode = '$kms_simulator_mode' is not supported. Supported modes are : '@validModes'", 109 );
        return;
    }

    # CALL device layer function PDL_Enable_KMS_Simulator
    my $status = CallDeviceFunction($kms_simulator_mode);
    return $status;

}

=head2 PRD12_SetAutoLogin

B<Please check :>

=for html
<a href='LIFT_ProdDiag.html#PRD_SetAutoLogin'>PRD_SetAutoLogin documentation</a>
<br><br>

=cut

sub PRD12_SetAutoLogin {
    my @args = @_;
    S_checkFunctionArguments( 'PRD12_SetAutoLogin( $enbale_or_disable_bool )', @args ) or return;
    my $enable_or_disable_bool = shift @args;

    #CALL CheckPreconditions
    CheckPreconditions() or return;

    # STEP Check for the valid options
    my @validoptions = ( 0, 1 );
    unless ( grep { /^$enable_or_disable_bool$/ } @validoptions ) {
        S_set_error( "PRD_SetAutoLogin: passed login option = '$enable_or_disable_bool' is not supported. Supported options are : '@validoptions'", 109 );
        return;
    }

    # CALL device layer function PDL_SetAutoLogin
    my $status = CallDeviceFunction($enable_or_disable_bool);
    return $status;

}

############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=head2 CallDeviceFunction

    CallDeviceFunction( @args );
    
Calls a function that is defined in $functionMapping_href with arguments @args.
The key for $functionMapping_href is defined by the caller of this function.
Values of $functionMapping_href are either directly functions of the device layer if a 1:1 mapping is possible.
Otherwise a function of the package LIFT_ProdDiag_AB12_xyz is called.

Returns the return values of the called functions. On error returns 0.

=cut

sub CallDeviceFunction {
    my @args = @_;
    return FL_CallDeviceFunction( 'ProdDiag_AB12', $functionMapping_href, @args );
}

sub Init_PDLayer {
    eval "use LIFT_PDLayer";
    return 1;
}

=head2 CheckPreconditions

    CheckPreconditions();

This functions checks the handles for Production Diagnosis are initialised correct.

B<Return Values:>

    Success: 1
    Failure: undef 

=cut

sub CheckPreconditions {
    my $funcNameIdx     = '3';
    my $callingFunction = ( caller(1) )[$funcNameIdx];
    $callingFunction = 'main' if not defined $callingFunction;
    $callingFunction =~ s/^\w+\:\://g;

    if ( not defined $prd12Handle_href ) {
        S_set_error( "Production diagnosis AB12 handle not defined. Please initialize Production diagnosis for AB12 before using the function '$callingFunction'.", 109 );
        return;
    }

    if ($fastDiagActive) {
        S_set_error( "Fast Diagnostics is Active", 109 );
        return;
    }

    return 1;
}

=head2 Create_Symbol_Mapping

    Create_Symbol_Mapping($sad_file_path);
    
Gets path of .sad file path as parameter and reads .sad, .cns, .nvm and .flt file, which must be in the same folder as .sad file.
Extracts data from the files and creates the symbol mapping in package global variable $symbolMapping_href.

    $symbolMapping_href = {
        cns => {
            header => {
                <cns_header_item> => <value>,
                ...
            }
            const => {
                <const_name> => {value => <value>},
                ...
            }
            enum => {
                <enum_type> => {
                    <array_idx_enum_name> => {value => <value>, comment => <comment>},
                    ...                    
                }
                ...
            }
            mask => {
                <mask_name> => {value => <value>, comment => <comment>},
                ...
            }
        }
        flt => {
            header => {
                <flt_header_item> => <value>,
                ...
            },
            fault => {
                <fault_number> => {enum_variable => <enum_variable>, description => <description>},
                ...
            },
            fltNametoID {
                <fault_name> => <fault_ID>
                ...
            }
        }
        nvm => {
            header => {
                <nvm_header_item> => <value>,
                ...
            }
            block => {
                <block_name> => {block_ID => <block_ID>, block_length => <block_length>},
                ...
            }
        }
        sad => {
            header => {
                <sad_header_item> => <value>,
                ...
            }
            symbol => {
                <symbol_name> => {address => <address>, description => <description>, enum_or_mask => <enum_or_mask>},
                ...
            },
            AddresstoSymbol => {
                <address> => <symbol>,
                ...
            }
        }
    }

=cut

sub Create_Symbol_Mapping {

    my @args         = @_;
    my $sad_filePath = shift @args;
    S_w2log( 3, "PRD12_init: Creating symbol mapping ...\n" );

    #STEP Get symbol file types: 'sad', 'cns', 'nvm', 'flt'
    my @symbolFileTypes = ( 'sad', 'cns', 'nvm', 'flt' );

    if ($main::opt_offline) {
        $symbolMapping_href->{'flt'}{'fltNametoID'}{offline_flt_name} = 0xA20800;
        $symbolMapping_href->{'sad'}{'AddresstoSymbol'}{0xFFFF0000}   = 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32';
        $symbolMapping_href->{'sad'}{'header'}{'ROMCODE'}             = 'ROMCODE';

        return 1;
    }

    unless ( -e $sad_filePath ) {
        S_set_error("SAD file does not exist at $sad_filePath. Please mention the correct path in main config file or PSdiag config file(only if 'TakeFromPSDiag' option is chosen)");
        return;
    }

    #STEP Get directory and file name without extension
    my $nameWoExtension;
    my $basename = basename($sad_filePath);
    if ( $basename =~ /^(.+)\.sad$/i ) {
        $nameWoExtension = $1;
    }
    else {
        S_set_error( "Given \$SAD_file ($sad_filePath) in main config has the wrong extension. Extension must be '.sad'", 109 );
        return;
    }
    my $dirname = dirname($sad_filePath);

    #LOOP-START Loop over symbol file types
    foreach my $symbolFileType (@symbolFileTypes) {

        #CALL ReadSymbolFile to get symbol mapping for one symbol type
        my $typeMapping_href = ReadSymbolFile( $dirname . '/' . $nameWoExtension, $symbolFileType );

        #STEP Add mapping for symbol type to overall symbol mapping
        $symbolMapping_href->{$symbolFileType} = $typeMapping_href;
    }

    #LOOP-END Last symbol file type?

    #STEP Store the Fault Name->ID mapping in the Fault mapping
    if ( defined $symbolMapping_href->{'flt'}{'fault'} ) {
        my $fltInfo_href = $symbolMapping_href->{'flt'}{'fault'};
        foreach my $fltId ( keys %$fltInfo_href ) {
            my $fltName = $fltInfo_href->{$fltId}{'enum_variable'};
            $symbolMapping_href->{'flt'}{'fltNametoID'}{$fltName} = $fltId;
        }
    }

    #STEP Store the Address-> Symbol mapping in the SAD mapping
    if ( defined $symbolMapping_href->{'sad'}{'symbol'} ) {
        my $sadInfo_href = $symbolMapping_href->{'sad'}{'symbol'};
        foreach my $symbol ( sort { length($a) <=> length($b) } keys %$sadInfo_href ) {
            my $address = $sadInfo_href->{$symbol}{'address'};
            $symbolMapping_href->{'sad'}{'AddresstoSymbol'}{$address} = $symbol;
        }
    }

    return 1;
}

=head2 ReadSymbolFile

    $typeMapping_href = ReadSymbolFile( $filePath, $fileType );
    
Reads one symbol file from path $filePath with extension $fileType.
Extracts header data and body data and returns it in $typeMapping_href.
The structure of $typeMapping_href is described in function Create_Symbol_Mapping.

=cut

sub ReadSymbolFile {
    my $filePath = shift;
    my $fileType = shift;

    my $typeMapping_href;

    #STEP Get complete file name from $filePath and $fileType
    my $fileName = $filePath . '.' . $fileType;
    S_w2log( 4, "PRD12_init: Reading symbol file $fileName ...\n" );

    #STEP Open the file, read all lines and close the file again
    my $in_fh;
    unless ( open( $in_fh, '<', $fileName ) ) {
        S_set_error( "Cannot open input file $fileName : $!", 109 );
        return;
    }
    my @lines = <$in_fh>;
    close $in_fh;

    my $header = 1;    # flag to mark if we are in the header section or not

    #LOOP-START Loop over all lines in the file
    foreach my $line (@lines) {

        #IF In header?
        if ($header) {

            #IF-YES-START

            #STEP Check for END OF HEADER
            if ( $line =~ /^END OF HEADER$/i ) {
                $header = 0;
                next;
            }

            #STEP extract header data and store it in $typeMapping_href->{header} or detect end of header
            if ( $line =~ /^(.+?)\s*:\s*(.+)\s*$/ ) {
                $typeMapping_href->{header}{$1} = $2;
                S_w2log( 5, " ReadSymbolFile: Found Header attribute '$1' : '$2'\n" );
            }

            #IF-YES-END
        }
        else {
            #IF-NO-START
            #CALL GetDataFromBodyLine with line, $fileType and $typeMapping_href
            GetDataFromBodyLine( $line, $fileType, $typeMapping_href );

            #IF-NO-END
        }
    }

    #LOOP-END Last line?

    #STEP Return $typeMapping_href
    return $typeMapping_href;
}

=head2 GetDataFromBodyLine

    GetDataFromBodyLine( $line, $fileType, $typeMapping_href );
    
Extracts data from given line $line of symbol file of type $fileType.
The line format depends on $fileType.
Adds the extracted data to $typeMapping_href.
The structure of $typeMapping_href is described in function Create_Symbol_Mapping.

=cut

sub GetDataFromBodyLine {
    my $line             = shift;
    my $fileType         = shift;
    my $typeMapping_href = shift;

    my $syntax_version_sad_file = 1;

    my ( $symbol, $address, $description, $enum_or_mask, $array_idx_enum_name, );

    if ( $fileType eq 'sad' ) {
        if ( defined $typeMapping_href->{header}{'Syntax version'} ) {
            $syntax_version_sad_file = $typeMapping_href->{header}{'Syntax version'};
        }

        if ( $syntax_version_sad_file > 2 ) {
            S_set_error("Unsupported Syntax version $syntax_version_sad_file");
            return;
        }
    }

    #IF $fileType is 'sad' and syntax_version == 1 line has sad-format?
    if ( $fileType eq 'sad' and $syntax_version_sad_file == 1 and $line =~ /^([^,]+),(\w+),([^,]*),([^,]*)/ ) {

        #IF-YES-START
        # syntax_version == 1
        # name,address in hex,symbol description, enum or mask type
        # rb_tim_EcuOnTimeDataEe_st.POnCounter_u32,FEDF8004,Total ECU PowerOn cycles (since production),
        #STEP Extract sad data (version 1) and store in $typeMapping_href
        $symbol       = $1;
        $address      = $2;
        $description  = $3;
        $enum_or_mask = $4;
        chomp $enum_or_mask;
        $typeMapping_href->{symbol}{$symbol}{address}      = hex($address);
        $typeMapping_href->{symbol}{$symbol}{description}  = $description;
        $typeMapping_href->{symbol}{$symbol}{enum_or_mask} = $enum_or_mask;

        #IF-YES-END
    }

    #IF-NO-START
    #IF $fileType is 'sad' and syntax_version == 2 line has sad-format?
    elsif ( $fileType eq 'sad' and $syntax_version_sad_file == 2 and $line =~ /^([^,]+),(\w+),([^,]*),([^,]*),([^,]*)/ ) {

        #IF-YES-START

        # syntax_version == 2
        # name,address in hex,symbol description, enum or mask type, array index enum name
        # rb_tim_EcuOnTimeDataEe_st.POnCounter_u32,FEDF8004,Total ECU PowerOn cycles (since production),wgnorwehge,fwqgfrew
        #STEP Extract sad data (version 2) and store in $typeMapping_href
        $symbol              = $1;
        $address             = $2;
        $description         = $3;
        $enum_or_mask        = $4;
        $array_idx_enum_name = $5;

        chomp $enum_or_mask;
        $typeMapping_href->{symbol}{$symbol}{address}             = hex($address);
        $typeMapping_href->{symbol}{$symbol}{description}         = $description;
        $typeMapping_href->{symbol}{$symbol}{enum_or_mask}        = $enum_or_mask;
        $typeMapping_href->{symbol}{$symbol}{array_idx_enum_name} = $array_idx_enum_name;

        #IF-YES-END
    }

    #IF-NO-START
    #IF $fileType is 'cns'?
    elsif ( $fileType eq 'cns' ) {

        #IF-YES-START
        #STEP Extract cns enum data if enum line and store in $typeMapping_href
        if ( $line =~ /^enum;(\w+);(\w+);(\w+);(.*)/ ) {

            # type;enum type;symbol name;symbol value;comment
            # enum;rb_sycc_Smi7Sensors_ten;rb_sycc_Smi7SensorMax_e;4;Max Value (number of all SMI7 sensors)
            my $enum_type    = $1;
            my $symbol_name  = $2;
            my $symbol_value = $3;
            my $comment      = $4;
            $typeMapping_href->{enum}{$enum_type}{$symbol_name}{value}   = $symbol_value;
            $typeMapping_href->{enum}{$enum_type}{$symbol_name}{comment} = $comment;
        }

        #STEP Extract cns mask data if mask line and store in $typeMapping_href
        elsif ( $line =~ /^mask;(\w+);(\w+);(.*)/ ) {

            # type;symbol name;symbol value;comment
            # mask;AlgoDisableMaskDef;00;FrontRear disable
            my $symbol_name  = $1;
            my $symbol_value = $2;
            my $comment      = $3;
            $typeMapping_href->{mask}{$symbol_name}{value}   = $symbol_value;
            $typeMapping_href->{mask}{$symbol_name}{comment} = $comment;
        }

        #STEP Extract cns const data if const line and store in $typeMapping_href
        elsif ( $line =~ /^const;(\w+);(\w+)/ ) {

            # type;symbol name;symbol value;comment
            # const;RB_PRDP_AutosarCUBASDriver_cs;1
            my $symbol_name  = $1;
            my $symbol_value = $2;
            $typeMapping_href->{const}{$symbol_name}{value} = $symbol_value;
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF $fileType is 'nvm' and line has nvm-format?
    elsif ( $fileType eq 'nvm' and $line =~ /^(\w+),(\w+),(\w+)/ ) {

        #IF-YES-START
        # block name,block ID,block length
        # NvM_MultiBlock,0,1
        #STEP Extract nvm data and store in $typeMapping_href
        my $block_name   = $1;
        my $block_ID     = $2;
        my $block_length = $3;
        $typeMapping_href->{block}{$block_name}{block_ID}     = $block_ID;
        $typeMapping_href->{block}{$block_name}{block_length} = $block_length;

        #IF-YES-END
    }

    #IF-NO-START
    #IF $fileType is 'flt' and line has flt-format?
    elsif ( $fileType eq 'flt' and $line =~ /^(\w+),(\w+),(.+)/ ) {

        #IF-YES-START
        # fault number,enum variable,description
        # 2,rb_acc_AlgoDeploySconLocked_flt,0xF00049 rb_acc_AlgoDeploySconLocked_flt
        #STEP Extract flt data and store in $typeMapping_href
        my $fault_number  = $1;
        my $enum_variable = $2;
        $description                                             = $3;
        $typeMapping_href->{fault}{$fault_number}{enum_variable} = $enum_variable;
        $typeMapping_href->{fault}{$fault_number}{description}   = $description;

        #IF-YES-END
    }
    elsif ( $line !~ /^EOF/ ) {

        #IF-NO-START
        #STEP throw warning about line not according to spec
        chomp $line;
        S_set_warning("The following $fileType file line is not according to spec: $line");

        #IF-NO-END
    }

    #IF-NO-END
    #IF-NO-END
    #IF-NO-END
    #IF-NO-END

    #END Return 1
    return 1;
}

=head2 Read_CAN_parameter

    $communication_params_href = Read_CAN_parameter($project_const_val, $CAN_type, $customer_name);

Reads the CAN parameter file from location ../DLLs/ProdDiag/Win32/PSDiag_CAN_Parameter.txt or form PSDiag folder to fetch the communication parameters like baud rate, request and respose IDs, etc

B<Arguments:>

=over

=item $project_const_val

To check if CAN parameter file to be taken from PSDiag folder if project is 'TakeFromPSDiag'

=item $CAN_type

CAN type is either the value read from project defaults or could be a CAN indicator read from psdiagconf.conf file

=item $customer_name

If CAN type passed is the CAN indicator, then customer name is used to find the correct communication parameters

=back

B<Return Values:>

=over

=item $communication_params_href

     $communication_params_href = {
        'BAUDRATE'   => 7A120,
        'TSEG1'      => C,
        'TSEG2'      => 3,
        'SJW'        => 3,
        'SAM'        => 1,
        'REQUEST'    => 650,
        'RESPONSE1'  => 651,
        'RESPONSE2'  => 652,
        'RESPONSE3'  => 653,
        'RESPONSE4'  => 654,
    };

=back

B<Examples:>

    $communication_params_href = Read_CAN_parameter( 'FORD_CAN_05', 'FORD_CAN_05', undef);       ### CAN type
    
    or
    
    $communication_params_href = Read_CAN_parameter('TakeFromPSDiag', 'AB12_BASE','VOLVO');      ### CAN indicator and customer name

B<Notes:>

when project is 'TakeFromPSDiag', then the details are read from psdiag config file. This file has only can indicator and not can type. So customer name is needed to identify the correct parameters.
        
=cut

sub Read_CAN_parameter {
    my @args = @_;

    my $project_const_val = shift @args;
    my $can_type          = shift @args;          # $can_type = FORD_CAN_05  -- if Project defaults
                                                  # $can_type = ALL(CAN indicator)  -- if TakeFromPSDiag
    my $customer_name     = shift @args // '';    # set to '' if not defined to avoid warnings in the regex

    #CALL Read_Content_Of_Comm_Par_File
    my ($lines_aref) = Read_Content_Of_Comm_Par_File( $project_const_val, 'PSDiag_CAN_Parameter.txt' );

    return unless ($lines_aref);

    #STEP check every line of PSDiag CAN parameter file to find the CAN type and customer name matching
    #STEP read the communication paramters like baud rate, request ID, response ID, etc
    my @can_ids;
    foreach my $line (@$lines_aref) {

        my $canCustNbr = 'CANTyp_' . $customer_name . '_CAN';

        # check if line matches the CAN type -- in case of project defaults
        if ( $line =~ /CANTyp_$can_type\s*=\s*(.+)/i ) {
            @can_ids = split( /\,/, $1 );
            last;
        }

        # check if line matches both customer name and can indicator -- in case of TakeFromPSDiag
        elsif ( $line =~ /$canCustNbr/ && $line =~ /$can_type,\s*.+/i ) {
            $line =~ /=\s*(.+)/i;
            @can_ids = split( /\,/, $1 );
            last;
        }
    }

    my $communication_params_href = {
        'BAUDRATE'  => $can_ids[0],
        'TSEG1'     => $can_ids[1],
        'TSEG2'     => $can_ids[2],
        'SJW'       => $can_ids[3],
        'SAM'       => $can_ids[4],
        'REQUEST'   => $can_ids[5],
        'RESPONSE1' => $can_ids[6],
        'RESPONSE2' => $can_ids[7],
        'RESPONSE3' => $can_ids[8],
        'RESPONSE4' => $can_ids[9],
    };

    #STEP return the hash of communication parameters
    return $communication_params_href;
}

=head2 Read_Content_Of_Comm_Par_File

    $lines_aref = Read_Content_Of_Comm_Par_File($project, $parfilename);

Returns content of CAN/CANFD parameters.

B<Arguments:>

=over

=item $project

Project name for which CAN/CANFD parameters has to be read. 

=item $parfilename

Psdiag CAN/CANFD parameter file

=back

B<Return Values:>

=over

=item $lines_aref

Content of CAN/CANFD parameter file

=back

B<Examples:>

    $lines_aref = Read_comm_par_file('BOSCH_CAN_03', 'PSDiag_CAN_Parameter.txt');
    $lines_aref = Read_comm_par_file('TOYOTA', 'PSDiag_CANFD_Parameter.txt');
    $lines_aref = Read_comm_par_file('TakeFromPSDiag', 'PSDiag_CANFD_Parameter.txt');

=cut

sub Read_Content_Of_Comm_Par_File {
    my @args = @_;

    my $project     = shift @args;
    my $parfilename = shift @args;
    my $addpath     = File::Spec->rel2abs( dirname(__FILE__) ) . "/../Device_layer/ProdDiag";
    $addpath =~ s/\//\\/g;    # replace all slashes with backslahes

    #IF is TakeFromPSDiag defined?
    #IF-NO-START
    #STEP Take communication parameter file from ../Device_layer/ProdDiag/Win32/
    #IF-NO-END

    my $can_para_file_path = "$addpath\\Win32\\$parfilename";

    #IF-YES-START
    #STEP Take communication parameter file from C:/AB12_TOOLS/PSDiag/
    #IF-YES-END
    my $psdiag_CAN_parameter_file = "C:\\AB12_TOOLS\\PSDiag\\$parfilename";
    if ( $project =~ /^TakeFromPSDiag$/i ) {
        if ( -e $psdiag_CAN_parameter_file ) {
            $can_para_file_path = $psdiag_CAN_parameter_file;
        }
        else {
            S_set_warning("The $parfilename file was not found at expected location - $psdiag_CAN_parameter_file when TakeFromPSDiag option was choosen. Hence reading the parameters from $can_para_file_path");
        }
    }
    S_w2log( 4, "Read_Content_Of_Comm_Par_File: Parameter file used from folder : $can_para_file_path\n" );
    my $fh;
    my @lines = read_file( $can_para_file_path, { err_mode => "quiet" } );
    unless (@lines) {
        S_set_error("ERROR ! Couldn't open $can_para_file_path for reading");
        return;
    }
    my $lines_aref = \@lines;

    #STEP return file contents
    return ($lines_aref);

    #STEP END
}

=head2 Read_FLEXRAY_parameter

    $communication_params_href = Read_FLEXRAY_parameter($customer_name);

Reads the FLEXRAY parameters for Customer "Daimler" and "jaguar".

B<Arguments:>

=over

=item $customer_name

Cutomer name : Currently supported "DAIMLER" and "JAGUAR".

B<Return Values:>

=over

=item $communication_params_href

     $communication_params_href = {

        REQUEST                           => 109,
        RESPONSE1                         => 110,
        RESPONSE2                         => 111,
        RESPONSE3                         => 112,
        BASE                              => 1,
        REPETITION                        => 2,
        baudrate                          => 10000,
        busGuardianEnable                 => 1,
        busGuardianTick                   => 1,
        externalClockCorrectionMode       => 0,
        gChannels                         => 1,
        gColdStartAttempts                => 8,
        gdActionPointOffset               => 2,
        gdCASRxLowMax                     => 97,
        gdDynamicSlotIdlePhase            => 0,
        gdMacrotick                       => 0,
        gdMinislot                        => 6,
        gdMiniSlotActionPointOffset       => 2,
        gdNIT                             => 5,
        gdStaticSlot                      => 55,
        gdSymbolWindow                    => 0,
        gdTSSTransmitter                  => 13,
        gdWakeupSymbolRxIdle              => 40,
        gdWakeupSymbolRxLow               => 40,
        gdWakeupSymbolRxWindow            => 301,
        gdWakeupSymbolTxIdle              => 180,
        gdWakeupSymbolTxLow               => 60,
        gListenNoise                      => 2,
        gMacroPerCycle                    => 3361,
        gMaxWithoutClockCorrectionFatal   => 2,
        gMaxWithoutClockCorrectionPassive => 2,
        gNetworkManagementVectorLength    => 1,
        gNumberOfMinislots                => 211,
        gNumberOfStaticSlots              => 38,
        gOffsetCorrectionStart            => 3357,
        gPayloadLengthStatic              => 32,
        gSyncNodeMax                      => 15,
        pAllowHaltDueToClock              => 1,
        pAllowPassiveToActive             => 0,
        pChannels                         => 3,
        pChannelsMTS                      => 3,
        pClusterDriftDamping              => 2,
        pdAcceptedStartupRange            => 269,
        pDecodingCorrection               => 60,
        pDelayCompensationA               => 5,
        pDelayCompensationB               => 5,
        pdListenTimeout                   => 400402,
        pdMaxDrift                        => 201,
        pdMicrotick                       => 0,
        pExternOffsetCorrection           => 0,
        pExternRateCorrection             => 0,
        pKeySlotUsedForStartup            => 7,
        pKeySlotUsedForSync               => 7,
        pLatestTx                         => 201,
        pMacroInitialOffsetA              => 4,
        pMacroInitialOffsetB              => 4,
        pMaxPayloadLengthDynamic          => 66,
        pMicroInitialOffsetA              => 55,
        pMicroInitialOffsetB              => 55,
        pMicroPerCycle                    => 200000,
        pMicroPerMacroNom                 => 0,
        pOffsetCorrectionOut              => 146,
        pRateCorrectionOut                => 201,
        pSamplesPerMicrotick              => 2,
        pSingleSlotEnabled                => 0,
        pWakeupChannel                    => 'XL_FR_CHANNEL_A',
        pWakeupPattern                    => 33,
        vExternOffsetControl              => 0,
        vExternRateControl                => 0,
    };

=back

B<Examples:>

    $communication_params_href = Read_FLEXRAY_parameter('JAGUAR');
    $communication_params_href = Read_FLEXRAY_parameter('DAIMLER');

=cut

sub Read_FLEXRAY_parameter {
    my @args          = @_;
    my $customer_name = shift @args;

    S_w2log( 4, "Read_FLEXRAY_parameter Fetch communication parameters for '$customer_name' ...\n" );

    # STEP prepare communication parameters for FLEXRAY
    my $communication_params_href = {};
    $communication_params_href = {
        daimler => {
            REQUEST                           => 109,
            COLDSTART                         => -1,
            RESPONSE1                         => 110,
            RESPONSE2                         => 111,
            RESPONSE3                         => 112,
            BASE                              => 1,
            REPETITION                        => 2,
            RQFRAMELENGTH                     => 64,
            baudrate                          => 10000,
            busGuardianEnable                 => 1,
            busGuardianTick                   => 1,
            externalClockCorrectionMode       => 0,
            gChannels                         => 1,
            gColdStartAttempts                => 8,
            gdActionPointOffset               => 2,
            gdCASRxLowMax                     => 97,
            gdDynamicSlotIdlePhase            => 0,
            gdMacrotick                       => 0,
            gdMinislot                        => 6,
            gdMiniSlotActionPointOffset       => 2,
            gdNIT                             => 5,
            gdStaticSlot                      => 55,
            gdSymbolWindow                    => 0,
            gdTSSTransmitter                  => 13,
            gdWakeupSymbolRxIdle              => 40,
            gdWakeupSymbolRxLow               => 40,
            gdWakeupSymbolRxWindow            => 301,
            gdWakeupSymbolTxIdle              => 180,
            gdWakeupSymbolTxLow               => 60,
            gListenNoise                      => 2,
            gMacroPerCycle                    => 3361,
            gMaxWithoutClockCorrectionFatal   => 2,
            gMaxWithoutClockCorrectionPassive => 2,
            gNetworkManagementVectorLength    => 1,
            gNumberOfMinislots                => 211,
            gNumberOfStaticSlots              => 38,
            gOffsetCorrectionStart            => 3357,
            gPayloadLengthStatic              => 32,
            gSyncNodeMax                      => 15,
            pAllowHaltDueToClock              => 1,
            pAllowPassiveToActive             => 0,
            pChannels                         => 3,
            pChannelsMTS                      => 3,
            pClusterDriftDamping              => 2,
            pdAcceptedStartupRange            => 269,
            pDecodingCorrection               => 60,
            pDelayCompensationA               => 5,
            pDelayCompensationB               => 5,
            pdListenTimeout                   => 400402,
            pdMaxDrift                        => 201,
            pdMicrotick                       => 0,
            pExternOffsetCorrection           => 0,
            pExternRateCorrection             => 0,
            pKeySlotUsedForStartup            => 7,
            pKeySlotUsedForSync               => 7,
            pLatestTx                         => 201,
            pMacroInitialOffsetA              => 4,
            pMacroInitialOffsetB              => 4,
            pMaxPayloadLengthDynamic          => 66,
            pMicroInitialOffsetA              => 55,
            pMicroInitialOffsetB              => 55,
            pMicroPerCycle                    => 200000,
            pMicroPerMacroNom                 => 0,
            pOffsetCorrectionOut              => 146,
            pRateCorrectionOut                => 201,
            pSamplesPerMicrotick              => 2,
            pSingleSlotEnabled                => 0,
            pWakeupChannel                    => 'XL_FR_CHANNEL_A',
            pWakeupPattern                    => 33,
            vExternOffsetControl              => 0,
            vExternRateControl                => 0,

        },

        jaguar => {
            COLDSTART                         => -1,
            REQUEST                           => 208,
            RESPONSE1                         => 207,
            RESPONSE2                         => 211,
            RESPONSE3                         => 212,
            BASE                              => 1,
            REPETITION                        => 2,
            KEYSLOTCC2                        => 30,
            RQFRAMELENGTH                     => 64,
            baudrate                          => 10000,
            busGuardianEnable                 => 1,
            busGuardianTick                   => 1,
            externalClockCorrectionMode       => 0,
            gChannels                         => 0,
            gColdStartAttempts                => 8,
            gdActionPointOffset               => 4,
            gdCASRxLowMax                     => 91,
            gdDynamicSlotIdlePhase            => 1,
            gListenNoise                      => 2,
            gMacroPerCycle                    => 5000,
            gMaxWithoutClockCorrectionFatal   => 15,
            gMaxWithoutClockCorrectionPassive => 7,
            gNetworkManagementVectorLength    => 0,
            gNumberOfMinislots                => 261,
            gNumberOfStaticSlots              => 63,
            gOffsetCorrectionStart            => 4990,
            gPayloadLengthStatic              => 13,
            gSyncNodeMax                      => 4,
            gdMacrotick                       => 1,
            gdMinislot                        => 8,
            gdMiniSlotActionPointOffset       => 4,
            gdNIT                             => 14,
            gdStaticSlot                      => 46,
            gdSymbolWindow                    => 0,
            gdTSSTransmitter                  => 11,
            gdWakeupSymbolRxIdle              => 59,
            gdWakeupSymbolRxLow               => 50,
            gdWakeupSymbolRxWindow            => 301,
            gdWakeupSymbolTxIdle              => 180,
            gdWakeupSymbolTxLow               => 60,
            pAllowHaltDueToClock              => 1,
            pAllowPassiveToActive             => 15,
            pChannels                         => 3,
            pClusterDriftDamping              => 2,
            pDecodingCorrection               => 56,
            pDelayCompensationA               => 28,
            pDelayCompensationB               => 28,
            pExternOffsetCorrection           => 0,
            pExternRateCorrection             => 0,
            pKeySlotUsedForStartup            => 10,
            pKeySlotUsedForSync               => 10,
            pLatestTx                         => 226,
            pMacroInitialOffsetA              => 7,
            pMacroInitialOffsetB              => 7,
            pMaxPayloadLengthDynamic          => 127,
            pMicroInitialOffsetA              => 36,
            pMicroInitialOffsetB              => 36,
            pMicroPerCycle                    => 200000,
            pMicroPerMacroNom                 => 40,
            pOffsetCorrectionOut              => 189,
            pRateCorrectionOut                => 601,
            pSamplesPerMicrotick              => 2,
            pSingleSlotEnabled                => 0,
            pWakeupChannel                    => 'XL_FR_CHANNEL_A',
            pWakeupPattern                    => 55,
            pdAcceptedStartupRange            => 160,
            pdListenTimeout                   => 401202,
            pdMaxDrift                        => 601,
            pdMicrotick                       => 0,
            vExternOffsetControl              => 0,
            vExternRateControl                => 0,
            pChannelsMTS                      => 3
          }

    };

    # STEP error if communication parameters are not supported for a customer type.
    if ( not exists $communication_params_href->{ lc $customer_name } ) {
        my @supportedFlexRayCustomers = map { uc $_ } keys %{$communication_params_href};
        S_set_error("ERROR ! Couldn't find the FlexRay parameters for given Customer type = '$customer_name'. Please pass either one from supported Customer types ='@supportedFlexRayCustomers'.. \n");
        return;
    }

    #STEP return the href of communication parameters
    return $communication_params_href->{ lc $customer_name };
}

=head2 Read_CANFD_parameter

    $communication_params_href = Read_CANFD_parameter($project_const_val, $customer_name, $commParameter, $fastDiagBusType,);

Reads the CANFD parameters.

B<Arguments:>

=over

=item $project_const_val

Configured project name in Project constant. 

=item $customer_name

Customer name for which CANFD parameters has to be read. Supported customer are Bosch, Toyota, Volvo, HRYT and Maserati.

=item $commParameter

For some customers there is more than one communication parameter set. 
Then the name of the communication parameter set (as shown in PSDiag) must be given.

=item $fastDiagBusType

Fast diag type is either CAN or CANFD. Default is CANFD.



=back

B<Return Values:>

=over

=item $communication_params_href

Example value (Bosch):

     $communication_params_href = {
        REQUEST            => 650,
        RESPONSE1          => 651,
        RESPONSE2          => 652,
        RESPONSE3          => 653,
        RESPONSE4          => 655,
        RESPONSE5          => 656,
        ARBITRATIONBITRATE => '7A120',
        DATABITRATE        => '4C4B40',
        SJWABR             => 1,
        SJWDBR             => 2,
        TSEG1ABR           => 3,
        TSEG1DBR           => 5,
        TSEG2ABR           => 1,
        TSEG2DBR           => 2,
        EDL                => 'False',
        BRS                => 'False',
        FRAMELENGTH        => 8,
    };

=back

B<Examples:>

    $communication_params_href = Read_CANFD_parameter('TOYOTA', 'TOYOTA', '19PF',  'CAN');
    $communication_params_href = Read_CANFD_parameter('TakeFromPSDiag', 'TOYOTA', '19PF', 'CAN');

=cut

sub Read_CANFD_parameter {
    my @args              = @_;
    my $project_const_val = shift @args;
    my $customer_name     = shift @args;
    my $commParameter     = shift @args;
    my $fastDiagBusType   = shift @args // 'CANFD';

    S_checkSingleValue( '$fastDiagBusType', $fastDiagBusType, { list_i => [ 'can', 'canfd' ] }, 'error' ) or return;
    S_w2log( 4, "Read_CANFD_parameter : Fetch communication parameters for '$customer_name' with communication parameters '$commParameter' and fast diagnosis bus '$fastDiagBusType'...\n" );

    #CALL Read_Content_Of_Comm_Par_File
    my ($lines_aref) = Read_Content_Of_Comm_Par_File( $project_const_val, 'PSDiag_CANFD_Parameter.txt' );
    return unless ($lines_aref);

    #STEP check every line of PSDiag CANFD parameter file to find the communication parameter and customer name matching
    #STEP read the communication paramters like baud rate, request ID, response ID, etc

    my $collect_comm_params_href = {};
    foreach my $line (@$lines_aref) {
        my $canfdCustNbr = 'CANFDTyp_' . $customer_name . '_CANFD';
        if ( $line =~ /$canfdCustNbr/ ) {
            $line =~ /=\s*(.+)/i;
            my @canfd_ids = split( /\,/, $1 );
            my $params_href = {
                ARBITRATIONBITRATE => $canfd_ids[0],
                DATABITRATE        => $canfd_ids[1],
                SJWABR             => $canfd_ids[2],
                SJWDBR             => $canfd_ids[3],
                TSEG1ABR           => $canfd_ids[4],
                TSEG1DBR           => $canfd_ids[5],
                TSEG2ABR           => $canfd_ids[6],
                TSEG2DBR           => $canfd_ids[7],
                REQUEST            => $canfd_ids[8],
                RESPONSE1          => $canfd_ids[9],
                RESPONSE2          => $canfd_ids[10],
                RESPONSE3          => $canfd_ids[11],
                RESPONSE4          => $canfd_ids[12],
                RESPONSE5          => $canfd_ids[13],
                EDL                => $canfd_ids[15],
                BRS                => $canfd_ids[16],
                FRAMELENGTH        => $canfd_ids[17],
            };
            my $communication_parameter = $canfd_ids[14];    # Indicate
            $collect_comm_params_href->{$customer_name}{$communication_parameter} = $params_href;
        }
    }

    if ( keys %{$collect_comm_params_href} == 0 ) {
        S_set_error("Read_CANFD_parameter: Could not find canfd parameter for '$customer_name' , Check customer name case sensitivity and also if it is supported or not");
        return;
    }
    if ( keys %{ $collect_comm_params_href->{$customer_name} } > 1 and not defined $commParameter ) {
        my @supportedCommParameters = keys %{ $collect_comm_params_href->{$customer_name} };
        S_set_error("Read_CANFD_parameter : ERROR ! Couldn't find the CANFD parameters for given Communication Parameter = '$commParameter' (Customer = '$customer_name'). Please pass either one from supported Communication Parameters ='@supportedCommParameters'..\n");
        return;
    }

    my $communication_params_href = {};
    foreach my $communication_parameter ( keys %{ $collect_comm_params_href->{$customer_name} } ) {
        if ( defined($commParameter) ) {
            if ( not exists $collect_comm_params_href->{$customer_name}{$commParameter} ) {
                S_set_error("Read_CANFD_parameter : ERROR ! Couldn't find the CANFD parameter '$commParameter' for given Customer '$customer_name'\n");
                return;
            }
            $communication_params_href = $collect_comm_params_href->{$customer_name}{$commParameter};
            last;
        }
        else {
            $communication_params_href = $collect_comm_params_href->{$customer_name}{$communication_parameter};
            last;
        }
    }

    # STEP add fastDiagBusType to communication parameters
    $communication_params_href->{PSDiagCommunication} = uc($fastDiagBusType);

    # STEP Return the href of communication parameters
    return $communication_params_href;
}

=head2 Read_PSDiag_Conf_File

    $communication_params_href = Read_PSDiag_Conf_File();

Reads the configuration details for PD from psdiag config file located at C:/Users/<username>/AppData/Roaming/psdiag/psdiagconfig.conf

B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $params_href

    $params_href = {
        'SAD_File_path'       => sad_file_path,
        'Channel_Nbr_0-based' => channel_Nbr,
        'CAN_indicator'       => can_indicator,
        'Customer_name'       => customer_name,
        'Bus_name'            => bus_name,
        'Hw_serial_nbr'       => HwSerialNbr,
    };
   
=back

B<Examples:>

  $params_href = read_PSDiag_Conf_File(); 
  $params_href = {
      'SAD_File_path'       => 'C:/temp/AB1200_BD_074_BB00000_Cat2.sad',
      'Channel_Nbr_0-based' => 2,
      'CAN_indicator'       => 'ALL',
      'Customer_name'       => 'FORD',
      'Bus_name'            => 'Flexray',
      'Hw_serial_nbr'       => 434,
  }
    
=cut

sub Read_PSDiag_Conf_File {

    my $username = getlogin;

    my $psDiag_ini_file = "C:\\Users\\$username\\AppData\\Roaming\\psdiag\\PSDiag.ini";

    S_w2log( 4, "Fetching PSDiag config file from $psDiag_ini_file.. \n", 'grey' );

    # STEP offline return
    my $params_href;
    if ($main::opt_offline) {
        $params_href = {
            'SAD_File_path'       => 'C:/temp/AB1200_BD_074_BB00000_Cat2.sad',
            'Channel_Nbr_0-based' => 1,
            'CAN_indicator'       => 'ALL',
            'Customer_name'       => 'FORD',
            'Bus_name'            => 'CAN',
            'Hw_serial_nbr'       => 434,
        };
        return $params_href;
    }

    my $fileContent = read_file( $psDiag_ini_file, { err_mode => "quiet" } );
    if ( not defined $fileContent ) {
        S_set_error("ERROR ! Couldn't open $psDiag_ini_file for reading\n");
        return;
    }

    # STEP check if PSDiag ini file has filePath of psdiagconfig.conf
    my $psDiag_Config_file;
    if ( $fileContent =~ /CONFIGURATION_FILE_PATH-(.+)/ ) {
        $psDiag_Config_file = $1;
        S_w2log( 4, "Config file path fetched from '$psDiag_ini_file' is '$psDiag_Config_file'... \n", 'grey' );
    }
    else {
        $psDiag_Config_file = "C:\\Users\\$username\\AppData\\Roaming\\psdiag\\psdiagconfig.conf";
        S_w2log( 4, "Default PSDiag config file '$psDiag_Config_file' is taken as not able to fetch from $psDiag_ini_file.. \n", 'grey' );
    }

    my $configFileContent = read_file( $psDiag_Config_file, { err_mode => "quiet" } );
    if ( not defined $configFileContent ) {
        S_set_error("ERROR ! Couldn't open $psDiag_Config_file for reading\n");
        return;
    }

    #STEP read customer name
    my $customerName;
    $customerName = $1 if ( $configFileContent =~ /Customer-([\w-]+)/ );    # example VOLVO-TRUCK
    $params_href->{'Customer_name'} = $customerName;

    #STEP read SAD file path
    my $sadfilePath;
    $sadfilePath = $1 if ( $configFileContent =~ /SymPathPrimary-(.+)/ );
    $params_href->{'SAD_File_path'} = $sadfilePath;

    #STEP read channel number for communication
    if ( $configFileContent =~ /.*Channel\s+\d.*:\s+(\d+)\s*-\s*(\d+)/ ) {
        $params_href->{'Hw_serial_nbr'}       = $1;
        $params_href->{'Channel_Nbr_0-based'} = $2;
    }

    #STEP read CAN indicator
    my $canIndicator;
    $canIndicator = $1 if ( $configFileContent =~ /CANIndicator-(.+)/ );    # SRS_2.0
    $params_href->{'CAN_indicator'} = $canIndicator;

    #STEP read bus type
    $params_href->{'Bus_Type'} = $1 if ( $configFileContent =~ /CommunicationProtocol-(\w+)/ );
    unless ( defined( $params_href->{'Channel_Nbr_0-based'} ) || defined( $params_href->{'Hw_serial_nbr'} ) ) {
        S_set_error("Channel number or Hardware serial number is not defined in PSDiag Config file. Please check $psDiag_Config_file");
        return;
    }

    #STEP read Fast_Diag_Bus_Type, named PSDiagCommunication in PSDiag config file
    my $fastDiagBusType;
    $fastDiagBusType = $1 if ( $configFileContent =~ /PSDiagCommunication-(.+)/ );
    $params_href->{'Fast_Diag_Bus_Type'} = $fastDiagBusType;

    S_w2log( 3, "Following values are read from PSDiag config file : '$psDiag_Config_file' .. \n" . Dumper($params_href), 'grey' );

    #STEP return sad file path, Channel Nbr,  CAN indicator,  customer name and bus type
    return $params_href;
}

=head2 GetCommunicationParameters

    $busParams_href = GetCommunicationParameters();

Depending on the project, the configuration details are read form PSDiag config file or testbench. The required communication parameters are read and returned.

B<Arguments:>

=over

=item None

=back

B<Return Values:>

=over

=item $busParams_href

    my $busParams_href = {
            'SADFILEPATH' => <sad_filePath>,
            'BUSTYPE'     => <bustype>, 
            'COMMPARAMS'  => <communicationParameters_href>,
        };

=back

B<Examples:>

  $busParams_href = GetCommunicationParameters(); 
  
=cut

sub GetCommunicationParameters {
    my @args = @_;

    #STEP Get project name from project defaults
    my $project = S_get_contents_of_hash( [ 'ProdDiag', 'ProjectName' ], $main::ProjectDefaults, { action_on_mismatch => 'w2log' } );

    # STEP If section 'ProdDiag' in project const is not defined then set "TakeFromPSDiag" in order to save configuration effort.
    if ( not defined $project ) {
        $project = 'TakeFromPSDiag';
        S_w2log( 3, " GetCommunicationParameters : Project Const 'ProdDiag -> ProjectName' = 'TakeFromPSDiag' is taken as default vlaue as it is not defined.. \n" );
    }

    my ( $customer_name, $sad_filePath, $channel_Nbr, $can_type, $hw_Serial_Nbr, $busType, $can_indicator, $fastDiagBusType );

    #IF Project name is 'TakeFromPSDiag'
    if ( lc($project) eq lc('TakeFromPSDiag') ) {

        # IF-YES-START
        # CALL Read_PSDiag_Conf_File to read Bus type (CAN, FlexRay, CANFD), Ch-Nbr, HW_serial_nbr, SAD file path, bus name from PSDiag config file.
        my $params_href = Read_PSDiag_Conf_File() || return;
        $sad_filePath    = $params_href->{'SAD_File_path'};          # named "SAD File Path" in PSDiag
        $channel_Nbr     = $params_href->{'Channel_Nbr_0-based'};    # part of "Communication Channel" in PSDiag
        $can_indicator   = $params_href->{'CAN_indicator'};          # named "Communication Parameter" in PSDiag
        $customer_name   = $params_href->{'Customer_name'};          # named "Customer" in PSDiag
        $busType         = $params_href->{'Bus_Type'};               # named "Communication On Bus" in PSDiag
        $hw_Serial_Nbr   = $params_href->{'Hw_serial_nbr'};          # part of "Communication Channel" in PSDiag
        $fastDiagBusType = $params_href->{'Fast_Diag_Bus_Type'};     # named "PSDiag Communication" in PSDiag

        $can_type = $can_indicator;                                  # CANTyp_FORD_CAN_05=7A120,C,3,3,1,671,670,66D,66E,66F,ALL,High Speed 251
                                                                     # $can_indicator = ALL,
                                                                     # IF-YES-END
    }
    else {
        # IF-NO-START
        # STEP Read SAD file path from cfg file and channel number, $hw_Serial_Nbr and bus name from Testbench and CAN type from project defaults
        $sad_filePath = $LIFT_config::SAD_file;
        unless ($sad_filePath) {
            S_set_error(" GetCommunicationParameters : SAD file not defined in main config file. Please define the SAD file path.");
            return;
        }
        $busType       = S_get_contents_of_hash( [ 'Devices', 'PDLayer', 'BusType' ],             $LIFT_config::LIFT_Testbench ) // return;
        $hw_Serial_Nbr = S_get_contents_of_hash( [ 'Devices', 'PDLayer', 'Hw_Serial_Nbr' ],       $LIFT_config::LIFT_Testbench ) // return;
        $channel_Nbr   = S_get_contents_of_hash( [ 'Devices', 'PDLayer', 'Channel_Nbr_0-based' ], $LIFT_config::LIFT_Testbench ) // return;
        $fastDiagBusType = S_get_contents_of_hash( [ 'Devices',  'PDLayer', 'FastDiagBusType' ], $LIFT_config::LIFT_Testbench, { action_on_mismatch => 'w2log' } );
        $can_indicator   = S_get_contents_of_hash( [ 'ProdDiag', 'CommunicationParameter' ],     $main::ProjectDefaults,       { action_on_mismatch => 'w2log' } );
        $can_type        = $project;

        # $customer_name = not required as $can_type will have this info
        # IF-NO-END
    }
    unless ( defined $busType ) {
        $busType = 'CAN';
        S_w2log( 4, " GetCommunicationParameters : Bus Type is not available. So assuming it to be 'CAN' \n" );
    }

    my $customer4Print = $customer_name // '<not required>';
    S_w2log( 3, "Trying to establish communication with following parameters - Customer : '$customer4Print', Project : '$project', BusType : '$busType', Channel number : '$channel_Nbr', HwSerial nbr : '$hw_Serial_Nbr', SAD file : '$sad_filePath' \n", 'blue' );

    my $communicationParameters_href;

    # IF Bus name eq CAN?
    if ( lc($busType) eq 'can' ) {

        # IF-YES-START
        # CALL read_CAN_parameter to get the communication parameters
        $communicationParameters_href = Read_CAN_parameter( $project, $can_type, $customer_name ) || return;

        # IF-YES-END
    }

    # IF-NO-START
    # IF Bus name eq FLEXRAY?
    elsif ( lc($busType) eq 'flexray' ) {

        # IF-YES-START
        # CALL Read_FLEXRAY_parameter to get the communication parameters
        $customer_name = $project if not defined $customer_name;    # in case if Project name is specified in Project constant, and if not 'TakeFromPSDiag'
                                                                    # then take customer name as project name itself Ex customer_name = project_name = <DAIMLER | JAGUAR>
                                                                    # Reason : no file like PSDiag_CAN_parameter is presnt for FlexRay.
        $communicationParameters_href = Read_FLEXRAY_parameter($customer_name) || return;    # Flexray parameters
                                                                                             # IF-YES-END
    }

    # IF-NO-START
    # IF Bus name eq CANFD?
    elsif ( lc($busType) eq 'canfd' ) {

        # IF-YES-START
        # CALL Read_CANFD_parameter to get the communication parameters
        $customer_name = $project if not defined $customer_name;    # in case if Project name is specified in Project constant, and if not 'TakeFromPSDiag'
        $communicationParameters_href = Read_CANFD_parameter( $project, $customer_name, $can_indicator, $fastDiagBusType ) || return;    # CANFD parameters
                                                                                                                                         # IF-YES-END
    }
    else {
        # IF-NO-START
        # STEP set error
        S_set_error("GetCommunicationParameters : The bus type can only be CAN, CANFD or FLEXRAY. $busType is not valid");
        return;

        # IF-NO-END
    }

    # IF-NO-END
    # IF-NO-END

    # STEP add CHANNELID and SERIALNUMBER to CommunicationParameters
    $communicationParameters_href->{CHANNELID}    = $channel_Nbr;     # 0-based channel number
    $communicationParameters_href->{SERIALNUMBER} = $hw_Serial_Nbr;

    $prd12StoreVar_href->{'SADFILEPATH'} = $sad_filePath;

    #STEP build bus parameters href
    my $busParamslocal_href = {
        'SADFILEPATH' => $sad_filePath,
        'BUSTYPE'     => $busType,
        'COMMPARAMS'  => $communicationParameters_href,
    };

    S_w2log( 3, "Using below Communication parameters for establishing '$busType' communication .. \n" );
    S_w2log( 4, "Communication parameters :- \n" . Dumper($busParamslocal_href), 'grey' );

    #STEP return bus parameters href
    return $busParamslocal_href;
}

=head2 FillFaultAttrDetails

    $faultTypeValues_aref = FillFaultAttrDetails( $faultMemory_href, $faultType, $fault_indx );

B<Arguments:>

=over

=item $faultMemory_href

Fault memory content of the structure:

    0 => { # fault index
            'attribute1' => 'value1',
            'attribute2' => 'value2',
         }

=item $faultType

Fault type BOSCH, PRIMARY, PLANT, DISTURBANCE.

=item $fault_indx

Fault index 0,1,2 ...

=back

B<Return Values:>

=over

=item $faultTypeValues_aref

=back

B<Examples:>

BOSCH FAULT MEMORY:

 $faultTypeValues_aref = 
 
 #FaultID,   DTC,      FaultName,                       EventDebug_Data_HB, EventDebug_Data_LB,
 [ 50,       0xC14287, rb_cap_TimeoutBcklSwRxStat_flt,  0x00,               0x00,                              

 #ASIC_Temperature, AlwaysCleared, Squib_fired_in_the_current_POC, DIS_ALP_Low_side_power_lines_disabled,
 67,                0,             0,                              1,                                   
 
 #Algo_active, VUp_OutOfRange_present,  VBat_OutOfRange_present, InitMode_active, IdleMode_active, 
 0,            0,                       0,                       0,               0,  
 
 #QualificationTime,  DequalificationTime, Qualification_PowerOn_Cycle,                  
 17407895,            0,                   84281100,
 
 #Dequalification_PowerOn_Cycle, OccurrenceCounter, Test_Failed, Test_not_Failed, GeneralStatus, Status
 0,                              1,                 1,           0,               0x20,          0x01 ]
 
PRIMARY FAULT MEMORY:

 $faultTypeValues_aref = 
 
 #FaultID,   DTC,       FaultName,                  Warning_lamp_indicator,
 [704,       0x805055,  rb_swm_UnexpectedBLFD_flt,  1,

 #Test_not_completed_this_operation_cycle, Test_failed_since_last_clear,
 0,                                        1,
 
 #Test_not_completed_since_last_clear, Confirmed_DTC_Stored, Pending,
 0,                                    1,                    1,
 
 #Test_failed_this_operation_cycle_Latched, Test_failed_Filtered, Status
 1,                                         1,                    0xAF ]

PLANT FAULT MEMORY:

 $faultTypeValues_aref = 
 
 #FaultID,   DTC,       FaultName,                  Warning_lamp_indicator,
 [704,       0x805055,  rb_swm_UnexpectedBLFD_flt,  1,
 
 #Test_not_completed_this_operation_cycle, Test_failed_since_last_clear,
 0,                                        1,
 
 #Test_not_completed_since_last_clear, Confirmed_DTC_Stored,    Pending,
 0,                                    1,                       1,
 
 #Test_failed_this_operation_cycle_Latched,  Test_failed_Filtered,  Status
 1,                                          1,                     0xAF ]
 
DISTURBANCE FAULT MEMORY:

 $faultTypeValues_aref = 
 
 #FaultID,   DTC,       FaultName,   TestDisturbed,   TestCurrent, EventDebug_Data_HB,
 [143,       0x9D0155,  rb_edr_NotConfigured_flt,     0,           1,

 #EventDebug_Data_LB,  DisturbaneceCounter, AlwaysCleared,   Squib_fired_in_the_current_POC,
 0x00,                 0x00,                0,               0,
 
 #DIS_ALP_Low_side_power_lines_disabled,    Algo_active,  VUp_OutOfRange_present,
 0,                                        0,            0,
 
 #VBat_OutOfRange_present, InitMode_active, IdleMode_active, GeneralStatus, Status
 0,                        1,               0,               0x02,           0x01 ]

B<Notes:> 

=cut

sub FillFaultAttrDetails {

    my @args = @_;

    S_checkFunctionArguments( 'FillFaultAttrDetails( $faultMemory_href, $faultType, $fault_indx )', @args ) or return;

    my $faultMemory_href = shift @args;
    my $faultType        = shift @args;
    my $fault_indx       = shift @args;

    my $faultTypeValues_aref = [];

    #loop through each fault attribute
    foreach my $fault_attr ( @{ $FAULT_ATTR_LIST_HOA->{$faultType} } ) {

        # Fill values for each attribute, (convert Description attribute to -> DTC and FaultName)
        if ( $fault_attr eq 'DTC' ) {
            ( $faultMemory_href->{$fault_indx}{'DTC'}, $faultMemory_href->{$fault_indx}{'FaultName'} ) =
              split( /\s+/, $faultMemory_href->{$fault_indx}{'Description'} );
            push( @$faultTypeValues_aref, ( $faultMemory_href->{$fault_indx}{'DTC'}, $faultMemory_href->{$fault_indx}{'FaultName'} ) );
            delete $faultMemory_href->{$fault_indx}{'Description'};
        }
        elsif ( $fault_attr ne 'FaultName' ) {
            if ( exists $faultMemory_href->{$fault_indx}{$fault_attr} ) {
                $faultMemory_href->{$fault_indx}{$fault_attr} =~ s/^$/0/;
                $faultMemory_href->{$fault_indx}{$fault_attr} =~ s/^X|x$/1/;
            }

            push( @$faultTypeValues_aref, $faultMemory_href->{$fault_indx}{$fault_attr} );
        }

    }

    # Fill status attribute for PLANT and PRIMARY
    if ( $faultType eq 'PRIMARY' or $faultType eq 'PLANT' ) {
        my $isoBin = '0b';
        foreach my $attr (@$ISO_AREF) {
            $isoBin .= $faultMemory_href->{$fault_indx}{$attr};
        }

        my $isoHex = STR_Bin2HexString( $isoBin, 2 );
        $faultMemory_href->{$fault_indx}{'Status'} = $isoHex;
        $faultTypeValues_aref->[-1] = $faultMemory_href->{$fault_indx}{'Status'};
    }

    # fill status attribute for BOSCH
    if ( $faultType eq 'BOSCH' ) {
        $faultMemory_href->{$fault_indx}{'Status'} = '0x00';                                                               # default value                                                            # by default set to 0x00
        $faultMemory_href->{$fault_indx}{'Status'} = '0x01' if ( $faultMemory_href->{$fault_indx}{'Test_Failed'} == 1 );
        $faultTypeValues_aref->[-1]                = $faultMemory_href->{$fault_indx}{'Status'};
    }

    #fill status attribute for DISTURBANCE
    if ( $faultType eq 'DISTURBANCE' ) {

        my $disturbStatus = '0b000000' . $faultMemory_href->{$fault_indx}{'TestDisturbed'} . $faultMemory_href->{$fault_indx}{'TestCurrent'};
        $faultMemory_href->{$fault_indx}{'Status'} = STR_Bin2HexString( $disturbStatus, 2 );
        $faultTypeValues_aref->[-1] = $faultMemory_href->{$fault_indx}{'Status'};
    }

    # Fill GeneralStatus attributes for BOSCH and DISTURBANCE
    if ( $faultType eq 'BOSCH' or $faultType eq 'DISTURBANCE' ) {
        my $genStatusBin = '0b';
        foreach my $attr (@$GENERALSTATUS_AREF) {
            $genStatusBin .= $faultMemory_href->{$fault_indx}{$attr};
        }
        my $genStatusHex = STR_Bin2HexString( $genStatusBin, 2 );
        $faultMemory_href->{$fault_indx}{'GeneralStatus'} = $genStatusHex;
        my $genStatusPos = '-2';
        $faultTypeValues_aref->[$genStatusPos] = $faultMemory_href->{$fault_indx}{'GeneralStatus'};
    }

    return $faultTypeValues_aref;
}

=head2 PrintFaultTableToHTML

    PrintFaultTableToHTML( $faultMemory_href, $faultType );

This function prints the table in the HTML report.

B<Arguments:>

=over

=item $faultMemory_href

Fault memory content of the structure:

    0 => { # fault index
            'attribute1' => 'value1',
            'attribute2' => 'value2',
         }

=item $faultType

Fault type BOSCH, PRIMARY, PLANT, DISTURBANCE.

=back

B<Return Values:>

=over

=item None

=back

B<Examples:>

B<Notes: Not Exported function> 

=cut

sub PrintFaultTableToHTML {

    my @args = @_;

    S_checkFunctionArguments( 'PrintFaultTableToHTML( $faultMemory_href, $faultType )', @args ) or return;

    my $faultMemory_href = shift @args;
    my $faultType        = shift @args;

    my $readFaultMemory = HTML::Table->new(
        -width  => '50%',
        -head   => ["$faultType FAULT MEMORY"],
        -border => 1,
    );

    # unique color for each fault type
    $readFaultMemory->setRowBGColor( 1, "#be63ec" ) if ( $faultType eq 'PRIMARY' );
    $readFaultMemory->setRowBGColor( 1, "#ec7063" ) if ( $faultType eq 'PLANT' );
    $readFaultMemory->setRowBGColor( 1, "#63d7ec" ) if ( $faultType eq 'BOSCH' );
    $readFaultMemory->setRowBGColor( 1, "#58d68d" ) if ( $faultType eq 'DISTURBANCE' );

    # if no faults in fault memory
    unless ( keys %$faultMemory_href ) {

        $readFaultMemory->addRow("NO FAULTS IN FAULT MEMORY");
        $readFaultMemory->setRowBGColor( 2, "#E2E8EE" );
        $readFaultMemory->setRowAlign( 2, 'center' );
        $readFaultMemory->setCellColSpan( 1, 1, 1 );
        AddTable2Html($readFaultMemory);
        return {};
    }

    $readFaultMemory->addRow( @{ $FAULT_ATTR_LIST_HOA->{$faultType} } );
    $readFaultMemory->setRowBGColor( 2, "#E2E8EE" );
    $readFaultMemory->setRowAlign( 2, 'center' );
    $readFaultMemory->setRowClass( 2, 'rotate' );

    $readFaultMemory->setCellColSpan( 1, 1, scalar @{ $FAULT_ATTR_LIST_HOA->{$faultType} } );

    # loop through each fault index
    foreach my $fault_indx ( sort { $a <=> $b } keys %$faultMemory_href ) {
        my $faultTypeValues_aref = [];

        $faultTypeValues_aref = FillFaultAttrDetails( $faultMemory_href, $faultType, $fault_indx );

        $readFaultMemory->addRow(@$faultTypeValues_aref);
    }

    AddTable2Html($readFaultMemory);

    return 1;
}

sub AddTable2Html {
    my $table_obj = shift;

    my $tableHtml = '<div class="TCtable">' . $table_obj . '</div>';
    push( @TC_HTML_TEXT, $tableHtml );
    return 1;
}

=head2 CheckAndFillClearFaultArg

    CheckAndFillClearFaultArg ( [,$options_href] );

This function validates the configured arguments and fills the default values if not configured.

B<Arguments:>

=over

=item $options_href (optional)

    $options_href => {
                        'faultType' => 'plant' or 'all' (default)
                        'waitUntilClear' => 0 or 1 (default)
                     }

=back

B<Return Values:>

=over

=item $options_href

    $options_href => {
                        'faultType' => 'plant' or 'all' (default)
                        'waitUntilClear' => 0 or 1 (default)
                     }

=back

B<Notes: Not Exported function> 

=cut

sub CheckAndFillClearFaultArg {

    my @args = @_;

    S_checkFunctionArguments( 'CheckAndFillClearFaultArg( [,$options_href] )', @args ) or return;

    my $options_href = shift @args;

    my ( $faultType, $waitUntilClear ) = ( 'all', 1 );    # default

    #faultType configured
    if ( defined $options_href->{'faultType'} ) {
        $faultType = $options_href->{'faultType'};
        if ( lc($faultType) ne 'plant' && lc($faultType) ne 'all' ) {
            S_set_error( "PRD12_Clear_Fault_Memory: Fault Type '$faultType' is invalid! Valid range 'PLANT' or 'ALL'", 109 );
            return;
        }
    }

    #faultType not configured
    else {
        $options_href->{'faultType'} = $faultType;
    }

    #waitUntilClear configured
    if ( defined $options_href->{'waitUntilClear'} ) {
        $waitUntilClear = $options_href->{'waitUntilClear'};
        if ( $waitUntilClear != 0 && $waitUntilClear != 1 ) {
            S_set_error( "PRD12_Clear_Fault_Memory: Wait until clear value '$waitUntilClear' is invalid! Valid range '0' or '1'", 109 );
            return;
        }
    }

    #waitUntilClear not configured and faultType is not equal to 'plant'
    elsif ( lc( $options_href->{'faultType'} ) ne 'plant' ) {
        $options_href->{'waitUntilClear'} = $waitUntilClear;
    }

    #waitUntilClear not configured
    else {
        $options_href->{'waitUntilClear'} = 0;
    }

    if ( lc( $options_href->{'faultType'} ) eq 'plant' and $options_href->{'waitUntilClear'} == 1 ) {
        S_set_warning("PRD12_Clear_Fault_Memory: Wait until clear value '$waitUntilClear' is not supported for fault type '$faultType', valid value '0'");
    }

    return $options_href;
}

=head2 Read_options_4_reset

    ($reset_type, $wait_time_ms) = Read_options_4_reset($options_href);

This function, reads and validates the options passed for ECU reset

=cut

sub Read_options_4_reset {
    my @args         = @_;
    my $options_href = shift @args;

    #STEP set reset type to 'SOFT' if not defined
    #STEP set wait time to '0' if not defined
    #IF wait time is string
    #   IF-YES-START
    #       STEP read ms defined by the value in project const
    #   IF-YES-END
    #   IF-NO-START
    #   IF-NO-END
    #STEP return reset type and wait time

    my $reset_type   = $options_href->{'resetType'};
    my $wait_time_ms = $options_href->{'wait_time_after_reset_ms'};

    unless ( defined $reset_type ) {
        $reset_type = 'SOFT';
        S_w2log( 4, "PRD12_SW_Reset : Reset type is not defined. Hence, reset type is considered to be SOFTRESET" );
    }

    unless ( $reset_type =~ /^(SOFT|HARD)$/i ) {
        S_set_error(" PRD12_SW_Reset : Invalid reset type : '$reset_type', Please specify either 'SOFT' or 'HARD'");
        return;
    }

    unless ( defined $wait_time_ms ) {
        $wait_time_ms = 0;
        S_w2log( 4, "PRD12_SW_Reset : wait time is not defined. Hence, wait time is considered to be 0" );
    }

    #if the value is string, use it as key and get the value from project defaults
    unless ( $wait_time_ms =~ /^\d+$/ ) {
        $wait_time_ms = S_get_contents_of_hash( [ 'TIMER', $wait_time_ms ], $main::ProjectDefaults );

        #if the read value is not number throw error
        if ( $wait_time_ms =~ /^\d+$/ ) {
            S_w2log( 4, "wait time is read from project defaults. Read value is '$wait_time_ms' ms" );
        }
        else {
            S_set_error("The value read '$wait_time_ms' from Project Defaults under 'TIMER' is not a number");
            return;
        }
    }
    return ( $reset_type, $wait_time_ms );
}

=head2 Get_Fault_IDs_4_manipulation

    @fault_ids = Get_Fault_IDs_4_manipulation($fault_type);

This function, reads the faults for fault type mentioned and returns the list of fault ids

=cut

sub Get_Fault_IDs_4_manipulation {
    my @args       = @_;
    my $fault_type = shift @args;
    my @fault_ids;

    #STEP read fault memory for fault type mentioned
    #STEP extract all the fault_ids from the obtained href
    #STEP return array of fault ids

    my $fault_memory_href = PRD12_Read_Fault_Memory($fault_type);
    foreach my $index ( keys %$fault_memory_href ) {
        push @fault_ids, $fault_memory_href->{$index}{'FaultID'};
    }
    return @fault_ids;
}

=head2 Get_ECU_AlgoParameter_ID

    $ecu_algo_parameter_id = Get_ECU_AlgoParameter_ID( );

Returns a unique AlgoParameter ID assembled from 

    rb_acc_AidaParametersAlgoIds1_cst.ProjIdHB_u8
    rb_acc_AidaParametersAlgoIds1_cst.ProjIdLB_u8
    rb_acc_AidaParametersAlgoIds1_cst.ParaId_u8
    
resulting in 3-byte value

Example :

        "0x<HighB><LowB><ParaID>" = Get_ECU_AlgoParameter_ID( );

Success return :: AlgoParameter ID

B<Note:>
 
Supported AB Generations : '12'

%ENV{'ECU_AlgoParameter_ID'} will be set
    
S_set_project_info will be called with 'ECU_AlgoParameter_ID'

=cut

sub Get_ECU_AlgoParameter_ID {

    #STEP Read labels "rb_acc_AlgoIds_st.ProjIdHB_u8" and "rb_acc_AlgoIds_st.ProjIdLB_u8", "rb_acc_AlgoIds_st.ParaId_u8" to get algo parameter ID
    my $projectID_HB_aref = PRD12_Read_Cell('rb_acc_AlgoIds_st.ProjIdHB_u8');
    my $projectID_LB_aref = PRD12_Read_Cell('rb_acc_AlgoIds_st.ProjIdLB_u8');
    my $paraID_aref       = PRD12_Read_Cell('rb_acc_AlgoIds_st.ParaId_u8');

    unless ( $projectID_HB_aref && $projectID_LB_aref && $paraID_aref ) {
        S_set_warning("Get_ECU_AlgoParameter_ID : Could not read all required symbols for ECU AlgoParameter ID - returning");
        return;
    }
    my $projectID_HB_string = sprintf( "%02X", $projectID_HB_aref->[0] );
    my $projectID_LB_string = sprintf( "%02X", $projectID_LB_aref->[0] );
    my $paraID_string       = sprintf( "%02X", $paraID_aref->[0] );

    #STEP append to a single stirng
    my $ecu_algo_parameter_id = "0x" . $projectID_HB_string . $projectID_LB_string . $paraID_string;

    S_w2log( 2, " PRD12_Get_ECU_AlgoParameter_ID : $ecu_algo_parameter_id\n" );
    $main::ENV{'ECU_AlgoParameter_ID'} = $ecu_algo_parameter_id;

    S_set_project_info( { 'ECU_AlgoParameter_ID' => $ecu_algo_parameter_id } );

    #STEP return algo parameter ID
    return $ecu_algo_parameter_id;
}

=head2 Get_ECU_fingerprint

     $fingerprint = Get_ECU_fingerprint( );

returns a unique ID to identify the ECU built from internal IDs (  UniqueMcId # SMA660 ID )

Success return :: fingerprint

B<Note:> 

Supported AB Generations:: B<12> 

%ENV{'ECU_fingerprint'} will be set
    
S_set_project_info will be called with 'ECU_fingerprint'

=cut

sub Get_ECU_fingerprint {
    my $fingerprint;
    my $value_aref;

    #STEP read unique mc ID using label 'rb_mcs_UniqueMcId_u32'
    $value_aref = PRD12_Read_Cell('rb_mcs_UniqueMcId_u32');
    my $mcID = S_aref2hex($value_aref);
    $mcID =~ s/0x//g;

    S_w2log( 5, "UniqueMcId is $mcID\n" );

    #STEP read SMA660 ID
    $value_aref = PRD12_Read_Cell('rb_cs6m_AsicIdData_ast(0).SerialNumber1_u16');
    my $cs6ID = S_aref2hex($value_aref);
    $value_aref = PRD12_Read_Cell('rb_cs6m_AsicIdData_ast(0).SerialNumber2_u16');
    $cs6ID .= S_aref2hex($value_aref);
    $value_aref = PRD12_Read_Cell('rb_cs6m_AsicIdData_ast(0).SerialNumber3_u16');
    $cs6ID .= S_aref2hex($value_aref);
    $cs6ID =~ s/0x//g;

    S_w2log( 5, "SMA660 ID is $cs6ID\n" );

    #STEP build ECU fingerprint by concatenating mc ID and SMA660 ID
    $fingerprint = $mcID . '#' . $cs6ID;

    S_w2log( 4, "ECU fingerprint is $fingerprint" );
    $main::ENV{'ECU_fingerprint'} = $fingerprint;

    S_set_project_info( { 'ECU_fingerprint' => $fingerprint } );

    #STEP return ECU fingerprint
    return $fingerprint;
}

=head2 Get_Variant_Version

    my ($variant_version, $variant_num) = Get_Variant_Version();

get ECU variant ID and version

Success return :: variant version and ID

Error Retun :: undef

B<Note:> Supported AB Generations:: B<12>

=cut

sub Get_Variant_Version {

    my ( $variant_version, $variant_ID );

    if ($main::opt_offline) {
        return ( '0x01', '0x01' );
    }

    #STEP read variant ID 'rb_swv_SwVersionNvmCfg_st.VariantID_u16'
    my $value_aref = PRD12_Read_Cell('rb_swv_SwVersionNvmCfg_st.VariantID_u16');
    $variant_ID = S_aref2hex($value_aref);

    #STEP read variant version 'rb_swv_SwVersionNvmCfg_st.VariantVersion_u16'
    $value_aref      = PRD12_Read_Cell('rb_swv_SwVersionNvmCfg_st.VariantVersion_u16');
    $variant_version = S_aref2hex($value_aref);

    #STEP return variant ID and version
    return ( $variant_version, $variant_ID );
}

=head2 SetOrClear_Device_Bit

    $success = SetOrClear_Device_Bit($device_name, $mode)

This function sets or clears the bit value of a device label.
    
This function reads, modifies the values and writes back the value to a particular device label.

If the read value is equal to the modified value then nothing is done.

B<Arguments:>

=over

=item $device_name

It is the name of a device as defined by project specific enums in the *.CNS file, e.g. rb_sycf_SquibDevice_ten for squibs.

=item $mode

It is one of: 'set_Configure', 'clear_Configure' to configure/unconfigure or 'set_Monitor', 'clear_Monitor' to enable/disable monitoring.

=back

B<Return Values:>

=over

=item $success 

Success/Offline mode : 1

Error        : undef

=back

B<Examples:>
     
     $success = SetOrClear_Device_Bit('AB1FD', 'set_Configure')
     
B<Notes: Not Exported function>

=cut

sub SetOrClear_Device_Bit {
    my @args = @_;
    S_checkFunctionArguments( 'SetOrClear_Device_Bit($device_name,$mode)', @args ) or return;

    # STEP Fetch the input arguments ($device_name, $mode)
    my $device_name = shift @args;
    my $mode        = shift @args;

    my ( $deviceType, $label_mode );

    S_w2log( 4, "SetOrClear_Device_Bit : Device name => $device_name for Mode => $mode\n" );

    #STEP Apply DEVICE_CONFIG mapping if it exists
    my $mappedDevice = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device_name};
    if ( defined $mappedDevice ) {
        S_w2log( 4, "SetOrClear_Device_Bit : Given device name '$device_name' is mapped to '$mappedDevice' according to ProjectDefaults->{'DEVICE_CONFIG'}\n" );
        $device_name = $mappedDevice;
    }

    # STEP offline return
    return 1 if ($main::opt_offline);

    # STEP Fetch the $deviceType for the $device_name given from $devDetails
    foreach my $dev_type ( keys %$allDevDetails_href ) {
        if ( exists $allDevDetails_href->{$dev_type}{$device_name} ) {
            $deviceType = $dev_type;
        }
    }

    unless ( exists( $allDevDetails_href->{$deviceType}{$device_name} ) ) {
        S_set_error( "SetOrClear_Device_Bit : Device name '$device_name' is not valid!\n 1. Device names are case sensitive\n 2. Device name must exist as enums in CNS file", 109 );
        return;
    }

    if ( $mode !~ /^(set|clear)(_configure|_monitor)?$/i ) {
        S_set_error( " SetOrClear_Device_Bit : mode '$mode' is not 'set_Configure', 'clear_Configure','set_Monitor' or 'clear_Monitor'", 114 );
        return;
    }

    # check the mode and get either 'monitored' or 'configured'
    # if $mode contains "_Mon", it set as monitored else set as configured
    $label_mode = 'monitored' if ( $mode =~ /_monitor$/i );

    $label_mode = 'configured' if ( $mode =~ /_configure$/i );

    if ( $deviceType =~ /^(asics|SpBehaviour|parSections)$/ and $label_mode =~ /^monitored$/i ) {
        S_set_error( "SetOrClear_Device_Bit : '$label_mode' is not allowed for device type '$deviceType'", 109 );
        return;
    }

    # STEP Read the byte value and bitmask value of given device
    my $byte_value = $allDevDetails_href->{$deviceType}{$device_name}{'bytecount'};
    my $bit_mask   = $allDevDetails_href->{$deviceType}{$device_name}{'bitmask'};

    # STEP Get the label based on the device type
    my $label_name = $deviceConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$deviceType}{$label_mode};

    # STEP Read the current value stored in the variable
    my $data_aref = PRD12_Read_Cell("$label_name($byte_value)") // return;

    my $currentValue = hex( STR_Aref2HexString($data_aref) );

    S_w2log( 5, "SetOrClear_Device_Bit : Read $label_name($byte_value) : $currentValue\n" );

    # STEP Modify values according to devices
    my $newValue;

    if ( $mode =~ /^set/i ) {
        $newValue = $currentValue | $bit_mask;
    }
    else {
        $newValue = $currentValue & ~$bit_mask;
    }

    # STEP if value has not changed nothing needs to be done
    if ( $newValue == $currentValue ) {
        S_w2log( 5, "SetOrClear_Device_Bit : Applying the bitmask does not change the value --> nothing done\n" );
        return 1;
    }

    # STEP Write modified values
    PRD12_Write_Cell( "$label_name($byte_value)", [$newValue] ) or return;

    S_w2log( 5, "SetOrClear_Device_Bit : write $label_name($byte_value) : $newValue\n" );
    S_w2log( 3, "Setting '$label_mode' mode successfull for device '$device_name' \n" );

    # STEP return 1 incase of success or undef incase of error
    return 1;
}

=head2 CreateDevicesDetails

    $response_href = CreateDevicesDetails( $symDetails_href );

B<Arguments:>

=over

=item $symDetails_href

Symbol details from sad, cns, nvm and flt files

=back

B<Return Values:>

=over

=item $allDevDetails_href

Attributes like bitmask, bytecount of all the devices in AB12 will be filled

    Example: $allDevDetails_href = {
                pases' => {
                    'PASFR1' => {
                        bitmask => '1',
                        bytecount => '0'
                    }
                    'PASML' => {
                        bitmask => '2',
                        bytecount => '0'
                    }
                }
                ...
            }

=back

B<Notes: Not exported function> 

=cut

sub CreateDevicesDetails {

    my @args = @_;
    S_checkFunctionArguments( 'CreateDevicesDetails($symDetails_href)', @args ) or return;

    my $symDetails_href = shift @args;

    my $devData_href = { 'symDetails_href' => $symDetails_href };

    my $devTypes_href = $deviceConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'AB12'};

    #CALL OverWriteDevConfVar if DEVICE_CONFIG_VARIABLES defined in project constants
    if ( exists $LIFT_PROJECT::Defaults->{'DEVICE_CONFIG_VARIABLES'}{'AB12'} ) {
        OverWriteDevConfVar($devTypes_href);
    }

    #CALL CreateDeviceAttributes to fill the device details

    # loop through all the device types
    foreach my $devType ( keys %$devTypes_href ) {
        my $enumName = $deviceConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$devType}{'enum'};
        $devData_href->{'devType'}      = lc $devType;
        $devData_href->{'enumName'}     = $enumName;
        $allDevDetails_href->{$devType} = CreateDeviceAttributes($devData_href);
    }

    #STEP return href with all device details filled
    #STEP END

    return $allDevDetails_href;
}

=head2 GetDevicesDetails

    $allDevDetails_href = GetDevicesDetails();

Returns the (package global) data structure that is being created by CreateDevicesDetails().

B<Notes: Not exported function> 

Used in LIFT_PD2ProdDiag.pm

=cut

sub GetDevicesDetails {
    return $allDevDetails_href;
}

=head2 CreateDeviceAttributes

    $response_href = CreateDeviceAttributes( $devData_href );

B<Arguments:>

=over

=item $devData_href

    'symDetails_href' -> Symbol details from sad, cns, nvm and flt files

    'devType' -> device type

    'enumName' -> enum of the device

=back

B<Return Values:>

=over

=item $devAttr_href

    Example: $devAttr_href = {
                                'PASFR1' => {
                                    bitmask => '1',
                                    bytecount => '0'
                                }
                                'PASML' => {
                                    bitmask => '2',
                                    bytecount => '0'
                                }
                                ....
                             }

=back

B<Notes: Not exported function> 

=cut

sub CreateDeviceAttributes {

    my @args = @_;
    S_checkFunctionArguments( 'CreateDeviceAttributes($devData_href)', @args ) or return;

    my $devData_href = shift @args;

    my $symDetails_href = $devData_href->{'symDetails_href'};
    my $devType         = $devData_href->{'devType'};
    my $enumName        = $devData_href->{'enumName'};
    my $devAttr_href    = {};

    #STEP fill device details bitmask and bytecount into href
    if ( exists $symDetails_href->{'cns'}{'enum'}{$enumName} ) {
        my $devList_aref = [ keys %{ $symDetails_href->{'cns'}{'enum'}{$enumName} } ];

        foreach my $dev (@$devList_aref) {

            # extract the 'value' from cns details to calculate bytecount and bitmask
            my $devValue = $symDetails_href->{'cns'}{'enum'}{$enumName}{$dev}{'value'};

            if ( $dev =~ /rb_\w+_(\w+)_\w+/ ) {
                my $devName = $1;
                $devName =~ s/^AllAsics// if ( $devType =~ /asics/i );
                $devName =~ s/^Switch//   if ( $devType =~ /switches/i );

                my $byteSize    = '8';
                my $devBitCount = $devValue % $byteSize;

                # Fill device attributes except max count of device variable
                unless ( $devName =~ /max/i ) {
                    $devAttr_href->{$devName}{'bitmask'}   = 2**$devBitCount;
                    $devAttr_href->{$devName}{'bytecount'} = int( $devValue / $byteSize );
                    $devAttr_href->{$devName}{'index'}     = $devValue;
                }
            }
        }
    }

    #STEP return href with bitmask and bytecount
    #STEP END
    return $devAttr_href;

}

=head2 OverWriteDevConfVar

    $response_href = OverWriteDevConfVar( $devTypes_href );

Over writes the default values defined in package variable $allDevDetails_href, If the values are defined in Project constant. 

B<Arguments:>

=over

=item $devTypes_href

Href containing devtypes and types of variables

    Example: $devTypes_href =  {
               'DEVICE_CONFIG_VARIABLES' => {
                    'AB12' => {
                        'lamps' => {
                            'enum'       => 'rb_syco_AOuts_ten',
                            'monitored'  => 'rb_syco_SysConfAOutEeData_dfst.AoutMonitored_ab8',
                            'real'       => 'rb_syco_AOutPresence_ab8',
                            'configured' => 'rb_syco_SysConfAOutEeData_dfst.AoutConfigured_ab8',
                         },
                      }
                   }
                 };

=back

B<Return Values:>

=over

=back

B<Notes: Not exported function> 

=cut

sub OverWriteDevConfVar {
    my ($devConfig_href) = @_;

    # loop through each devtype
    foreach my $devType ( keys %{$devConfig_href} ) {

        #STEP over write the values if defined in 'DEVICE_CONFIG_VARIABLES' href of project constants
        #STEP Warning: If the variable value is not defined

        foreach my $devAttr ( keys %{ $devConfig_href->{$devType} } ) {
            if ( exists $LIFT_PROJECT::Defaults->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$devType}{$devAttr} ) {
                $devConfig_href->{$devType}{$devAttr} = $LIFT_PROJECT::Defaults->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$devType}{$devAttr};
            }
        }
    }

    #STEP END
    return 1;
}

=head2 GetDevicesInfo

    $device_config_href = GetDevicesInfo( [,$options_href] );

Gets the Device details with states of 'Configure', 'Monitor' and 'Presence'.

B<Arguments:>

=over

=item $options_href

$options_href = {

    'devices' => ['AB1FD', 'BLFD'],

    ( OR )

    'device_types' => [ 'lamps', 'squibs', 'staticbehaviour', 'dynamicbehaviour', 'pases', 'switches', 'asics' ],

}

=back

B<Return Values:>

=over

=item $device_config_href

returns 'presence', 'configure' and 'monitor' status values for the devices selected. 

'monitor' is not returned for devices belonging to types: asics and special behaviour types StaticBehaviour and DynamicBehaviour

Success : 

         # For devices which belongs to one of types: pases, squibs, lamps or switches
         $device_config_href = {
                    'squibs' => {
                                 'AB1FD' => {
                                   'Presence' => 1,
                                   'Configure' => 1,
                                   'Monitor' => 1,
                                   'Index' => 0,
                                   'Type' => 'squibs'                               
                                 },
                                 'AB1FP' => {
                                   'Presence' => 0,  # if device not present
                                   'Configure' => 0, # if device not configured
                                   'Monitor' => 0    # if device not monitored
                                   'Index' => 1,
                                   'Type' => 'squibs'  
                                 },
                               },
                    },

        # For devices which belongs to one of types: asics and StaticBehaviour and DynamicBehaviour
        $device_config_href = {
                    'asics' => {
                                'CentralSensorMain' => {
                                   'Presence' => 1,
                                   'Configure' => 1,
                                   'Index' => 0,
                                   'Type' => 'asics'                          
                                 },
                              },
                    },

Error : undef

=back

=cut

sub GetDevicesInfo {
    my @args         = @_;
    my $options_href = shift @args;
    my $device_config_href;
    my $dataByLabel_href = {};

    # IF Is devices defined?
    #   IF-YES-START
    #       STEP loop through each device
    #       STEP Apply DEVICE_CONFIG mapping if it exists
    #       CALL GetDevAttributes($devType, $device_name, $htmlDevinfo_mix)
    #   IF-YES-END
    #   IF-NO-START
    #       IF Is device_types defined?
    #           IF-YES-START
    #               CALL GetDevAttrOfDevType($DevTyes_aref, $htmlDevinfo_mix) with only configured device types
    #           IF-YES-END
    #           IF-NO-START
    #               CALL GetDevAttrOfDevType($DevTyes_aref, $htmlDevinfo_mix) all device types
    #           IF-NO-END
    #   IF-NO-END
    # STEP END

    my $htmlDevinfo_mix;
    unless ( defined $options_href->{NOHTML} ) {
        $htmlDevinfo_mix = HTML::Table->new(
            -style  => 'margin-left: 110px',
            -head   => ["Devices And Behaviour"],
            -border => 1,
            -align  => 'center',
        );
        $htmlDevinfo_mix->setCellColSpan( 1, 1, 5 );
        $htmlDevinfo_mix->setRowBGColor( 1, "#63d7ec" );
    }

    # STEP offline return
    return {
        squibs   => { AB1FD => { Asic_Channel => 1, Asic_Id => 1 } },
        pases    => { UfsD  => { Asic_Channel => 1, Asic_Id => 1 } },
        switches => { BLFD  => { Asic_Channel => 1, Asic_Id => 1 } },
    } if ($main::opt_offline);

    if ( exists $options_href->{'devices'} ) {

        foreach my $device_name ( @{ $options_href->{'devices'} } ) {
            foreach my $devType ( keys %$allDevDetails_href ) {
                $devType = lc $devType;

                my $configured_device_name = $device_name;
                my $mappedDevice           = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device_name};
                if ( defined $mappedDevice ) {
                    S_w2log( 4, "GetDevicesInfo : Given device name '$device_name' is mapped to '$mappedDevice' according to ProjectDefaults->{'DEVICE_CONFIG'}\n" );
                    $device_name = $mappedDevice;

                }
                if ( exists $allDevDetails_href->{$devType}{$device_name} ) {
                    FormatDeviceTable( $htmlDevinfo_mix, $devType );
                    my $device_attributes_href = {};
                    $device_attributes_href = GetDevAttributes( $devType, $device_name, $dataByLabel_href, $htmlDevinfo_mix );
                    $device_config_href->{$device_name} = $device_attributes_href unless ($mappedDevice);
                    $device_config_href->{$configured_device_name} = $device_attributes_href if ( defined $mappedDevice );
                }
            }
        }
        unless ($device_config_href) {
            my @invalid_device_names = @{ $options_href->{'devices'} };
            S_set_error( "GetDevicesInfo: One or more device names '@invalid_device_names' are incorrect please check!\n", 109 );
            return;
        }
    }
    elsif ( exists $options_href->{'device_types'} ) {
        $device_config_href = GetDevAttrOfDevType( $options_href->{'device_types'}, $dataByLabel_href, $htmlDevinfo_mix );
    }
    else {
        $device_config_href = GetDevAttrOfDevType( [ keys %$allDevDetails_href ], $dataByLabel_href, $htmlDevinfo_mix );
    }

    AddTable2Html($htmlDevinfo_mix) unless ( defined $options_href->{NOHTML} );
    return $device_config_href;
}

=head2 FormatDeviceTable

    FormatDeviceTable( $htmlDevinfo_mix, $devType );

Formats the device details table

B<Arguments:>

=over

=item $htmlDevinfo_mix

Html object to print device details to html page

=item $devType

Device type to print as a sub heading

=back

B<Return Values: None>

B<Notes: Not exported function>

=cut

sub FormatDeviceTable {

    my @args = @_;

    my $htmlDevinfo_mix = shift @args;
    my $devType         = shift @args;

    #STEP device type as a heading
    #STEP "Device Name", "Presence", "Configured", "Monitored", "Index", as sub heading
    #STEP END

    $devType = 'STATICBEHAVIOUR'  if ( $devType =~ /spbehaviour/i );
    $devType = 'DYNAMICBEHAVIOUR' if ( $devType =~ /parsections/i );

    $htmlDevinfo_mix->addRow( uc "$devType" );
    $htmlDevinfo_mix->setCellColSpan( $htmlDevinfo_mix->getTableRows(), 1, 5 );
    $htmlDevinfo_mix->setRowBGColor( $htmlDevinfo_mix->getTableRows(), "#63d7ec" );
    $htmlDevinfo_mix->setRowAlign( $htmlDevinfo_mix->getTableRows(), 'center' );
    $htmlDevinfo_mix->addRow( "Device Name", "Presence", "Configured", "Monitored", "Index" );
    my $rownum = $htmlDevinfo_mix->getTableRows();
    $htmlDevinfo_mix->setRowBGColor( $rownum, "#eaec63" );
    return 1;
}

=head2 GetDevAttrOfDevType

    $device_config_href = GetDevAttrOfDevType( $devTypes_aref, $htmlDevinfo_mix );

Formats the device details table

B<Arguments:>

=over

=item $devTypes_aref

List of device types

=item $htmlDevinfo_mix

Html object to print device details to html page

=back

B<Return Values:>

=item $device_config_href

returns 'presence', 'configure' and 'monitor' status values for the devices selected. 

'monitor' is not returned for devices belonging to types: asics and special behaviour types StaticBehaviour and DynamicBehaviour

Success : 

         # For devices which belongs to one of types: pases, squibs, lamps or switches
         $device_config_href = {
                    'squibs' => {
                                 'AB1FD' => {
                                   'Presence' => 1,
                                   'Configure' => 1,
                                   'Monitor' => 1,
                                   'Index' => 0                                
                                 },
                                 'AB1FP' => {
                                   'Presence' => 0,  # if device not present
                                   'Configure' => 0, # if device not configured
                                   'Monitor' => 0    # if device not monitored
                                   'Index' => 1,  
                                 },
                               },
                    },

        # For devices which belongs to one of types: asics and StaticBehaviour and DynamicBehaviour
        $device_config_href = {
                    'asics' => {
                                'CentralSensorMain' => {
                                   'Presence' => 1,
                                   'Configure' => 1,
                                   'Index' => 0                          
                                 },
                              },
                    },

=back

B<Notes: Not exported function>

=cut

sub GetDevAttrOfDevType {

    my @args = @_;

    my $devTypes_aref      = shift @args;
    my $dataByLabel_href   = shift @args;
    my $htmlDevinfo_mix    = shift @args;
    my $device_config_href = {};

    #CALL FormatDeviceTable( $htmlDevinfo_mix, $devType )
    #STEP for each of device in the device types fill the properties by callling GetDevAttributes

    foreach my $devType (@$devTypes_aref) {
        FormatDeviceTable( $htmlDevinfo_mix, $devType ) if ( defined $htmlDevinfo_mix );
        my %devices = %{ $allDevDetails_href->{$devType} };

        foreach my $device_name ( sort { $devices{$a}{'index'} <=> $devices{$b}{'index'} } keys %devices ) {

            # reverse used in order to match the name in cns/sad files.
            my $dev_conf_values_key_pairs_href = { reverse %{ $main::ProjectDefaults->{'DEVICE_CONFIG'} } };
            my $mappedDevice                   = $dev_conf_values_key_pairs_href->{$device_name};
            if ( defined $mappedDevice ) {
                S_w2log( 4, "GetDevAttrOfDevType : device name '$device_name' is mapped to '$mappedDevice' according to ProjectDefaults->{'DEVICE_CONFIG'}\n" );
            }
            my $device_attributes_href = {};
            $device_attributes_href = GetDevAttributes( $devType, $device_name, $dataByLabel_href, $htmlDevinfo_mix );
            $device_config_href->{$devType}{$device_name} = $device_attributes_href unless ($mappedDevice);
            $device_config_href->{$devType}{$mappedDevice} = $device_attributes_href if ( defined $mappedDevice );

        }
    }
    return $device_config_href;
}

=head2 GetDevAttributes

    $devProp_href = GetDevAttributes( $devType, $devName, $htmlDevinfo_mix  );

Formats the device details table

B<Arguments:>

=over

=item $devTypes_aref

List of device types

=item $devName

Device name for which the properties 'presence', 'configure' and 'monitor' has to be filled

=item $htmlDevinfo_mix

Html object to print device details to html page

=back

B<Return Values:>

=item $devProp_href

returns 'presence', 'configure' and 'monitor' status values for the devices selected. 

'monitor' is not returned for devices belonging to types: asics and special behaviour types StaticBehaviour and DynamicBehaviour

Success : 

         $devProperties = {
                            'AB1FD' => {
                                       'Presence' => 1,
                                       'Configure' => 1,
                                       'Monitor' => 1                                
                                     }
                           
                           }

=back

B<Notes: Not exported function>

=cut

sub GetDevAttributes {

    my @args = @_;

    my ( $devType, $devName, $dataByLabel_href, $htmlDevinfo_mix ) = @args;

    my $bitmask      = $allDevDetails_href->{$devType}{$devName}{'bitmask'};
    my $bytecnt      = $allDevDetails_href->{$devType}{$devName}{'bytecount'};
    my $devindx      = $allDevDetails_href->{$devType}{$devName}{'index'};
    my $devProp_href = {};
    my $devProp_aref = [ 'real', 'configured', 'monitored', 'asic_configuration', 'asic_chnl_config' ];

    $devType = 'spbehaviour' if ( $devType eq 'staticbehaviour' );
    $devType = 'parsections' if ( $devType eq 'dynamicbehaviour' );

    #Assign the property values to an empty string, To avoid runtime warnings when those are undefined
    foreach my $prop ( 'Presence', 'Configured', 'Monitored', 'Index' ) {
        $devProp_href->{$prop} = '';
    }

    #STEP Fetch the variables for the device property
    #STEP Do not fill monitor fields if the device type is one of 'asics', 'dynamicbehaviour', 'staticbehaviour'
    #CALL PRD12_Read_Cell("$label($bytecnt)")
    #STEP Write device properties to HTML
    #STEP END

    foreach my $devProp (@$devProp_aref) {

        $devProp_href->{'Type'} = $devType;
        if ( exists( $deviceConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$devType}{$devProp} ) ) {
            my $label = $deviceConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'AB12'}{$devType}{$devProp};
            $devProp_href->{'Index'} = $devindx;

            next if ( $devType =~ /(asics)|(dynamicbehaviour)|(staticbehaviour)/ and $devProp eq 'monitored' );
            $devProp = 'presence' if ( $devProp eq 'real' );
            unless ( $devProp =~ /(asic_configuration)|(asic_chnl_config)/ ) {
                my $data_aref = GetLabelData( "$label($bytecnt)", $dataByLabel_href );

                if ( ( $data_aref->[0] & $bitmask ) != 0 ) {
                    $devProp_href->{ ucfirst $devProp } = 1;
                }
                else {
                    $devProp_href->{ ucfirst $devProp } = 0;
                }
            }

            Fill_asicId_chnl( $devProp_href, $devType, $devProp, $label, $devindx, $dataByLabel_href );

        }
    }
    if ( defined $htmlDevinfo_mix ) {

        # reverse used in order to match the name in cns/sad files.
        my $dev_conf_values_key_pairs_href = { reverse %{ $main::ProjectDefaults->{'DEVICE_CONFIG'} } };
        my $mappedDevice                   = $dev_conf_values_key_pairs_href->{$devName};
        if ( defined $mappedDevice ) {
            S_w2log( 4, "GetDevAttributes : Given device name '$devName' is mapped to '$mappedDevice' according to ProjectDefaults->{'DEVICE_CONFIG'}\n" );
            $devName = $mappedDevice;

        }
        $htmlDevinfo_mix->addRow( "$devName", "$devProp_href->{Presence}", "$devProp_href->{Configured}", "$devProp_href->{Monitored}", "$devProp_href->{Index}" );
    }

    return $devProp_href;
}

sub GetLabelData {
    my $fullLabel        = shift;
    my $dataByLabel_href = shift;
    my $noerror          = shift // '';

    my $data_aref;

    # $dataByLabel_href is used to avoid reading a label again that has been read already
    # for AB12CA this reduces the number of calls of PRD12_Read_Cell from 2316 to 484 !
    if ( defined $dataByLabel_href->{$fullLabel} ) {
        $data_aref = $dataByLabel_href->{$fullLabel};
    }
    else {
        if ( $noerror eq 'NOERROR' ) {
            $data_aref = PRD12_Read_Cell_NOERROR_NOHTML($fullLabel);
        }
        else {
            $data_aref = PRD12_Read_Cell_NOHTML($fullLabel);
        }
        $dataByLabel_href->{$fullLabel} = $data_aref;
    }

    return $data_aref;
}

=head2 Validate_ReqRespIds

    $valid_NbrOfBUSIds = Validate_ReqRespIds([$numberOfBUSIds]);       

This function is used to validate the Number Of BUSIds passed as a parameter to FastDiagnosis API(PRD12_Start_Fast_Diagnosis) against the allowed Nbr of BUS IDS

B<Arguments:>

=over

=item $numberOfBUSIds

(optional)Number of BUS IDs to be used for fast diagnosis

If Nbr Of BUS IDs is not defined, then by default Max Nbr of BUS IDs allowed are considered

=back

B<Return Value:>

=over

=item $valid_NbrOfBUSIds 

Success : Number of valid BUS IDs

Error return : undef

=back

B<Examples:>

    $valid_NbrOfBUSIds = Validate_ReqRespIds();
    
    $valid_NbrOfBUSIds = Validate_ReqRespIds($numberOfBUSIds);
    
B<Notes: Not exported function>     

=cut

sub Validate_ReqRespIds {

    my @args = @_;

    return unless S_checkFunctionArguments( 'Validate_ReqRespIds( [$numberOfBUSIds] )', @args );

    my $numberOfBUSIds = shift @args;

    # STEP Fetch the input arguments (number_of_BUS_Ids(optional))
    S_w2log( 4, "Validate_ReqRespIds : Validating the Nbr of Request and Response IDs...\n" );

    my @bus_ids;
    my $communication_params_href;
    my $max_nbr_Of_BUSIds;
    my $busType;

    # STEP Fetch the $communication_params_href from $busParams_href
    $communication_params_href = $busParams_href->{'COMMPARAMS'} if ( exists $busParams_href->{'COMMPARAMS'} );
    $busType                   = $busParams_href->{'BUSTYPE'}    if ( exists $busParams_href->{'BUSTYPE'} );

    if ( lc($busType) eq 'canfd' ) {
        $max_nbr_Of_BUSIds = 2;    # Maximum Nbr of Bus Ids allowed for FastDiagnosis(CoreAsset) using CANFD is 2
    }
    elsif ( lc($busType) eq 'can' or lc($busType) eq 'flexray' ) {    #For FlexRay and CAN

        # STEP Fetch the BUS IDs from $communication_params_href
        push( @bus_ids, $communication_params_href->{'RESPONSE1'} ) if ( exists $communication_params_href->{'RESPONSE1'} );
        push( @bus_ids, $communication_params_href->{'RESPONSE2'} ) if ( exists $communication_params_href->{'RESPONSE2'} );
        push( @bus_ids, $communication_params_href->{'RESPONSE3'} ) if ( exists $communication_params_href->{'RESPONSE3'} );
        push( @bus_ids, $communication_params_href->{'RESPONSE4'} ) if ( exists $communication_params_href->{'RESPONSE4'} );

        @bus_ids = grep { hex($_) > 0 } @bus_ids;

        $max_nbr_Of_BUSIds = scalar(@bus_ids);                        # It contains BUS IDs for Response as well as Request, So total Nbr of BUS ids passed for Fast Diagnosis will be 1 less than the total
    }
    else {
        S_set_error( "Validate_ReqRespIds : '$busType' is unknown BusType\n ", 114 );
        return;
    }

    unless ($max_nbr_Of_BUSIds) {                                     #return if the Max Nbr of BUS IDs for Fast Diagnosis is 0 for the respective project
        S_set_error( "Validate_ReqRespIds : The maximum Nbr Of BUS IDs is '$max_nbr_Of_BUSIds', It should be more than '0'\n ", 114 );
        return;
    }

    # STEP If numberOfBUSIds is not defined then by default Max Nbr Of BUS IDs allowed is considered
    unless ( defined $numberOfBUSIds ) {
        $numberOfBUSIds = $max_nbr_Of_BUSIds;
        S_w2log( 4, "Validate_ReqRespIds : The Nbr Of BUSIDs passed as a parameter is undefined, so by default '$max_nbr_Of_BUSIds' is considered\n " );
    }

    if ( ( $numberOfBUSIds > $max_nbr_Of_BUSIds ) || $numberOfBUSIds < 1 ) {
        S_set_error( "Validate_ReqRespIds : The Nbr Of BUS IDs passed as a parameter to the API is '$numberOfBUSIds', Nbr of BUSIDs allowed is '1' to '$max_nbr_Of_BUSIds'\n ", 114 );
        return;
    }

    # STEP return Nbr of valid BUS IDs incase of success or undef incase of failure
    return $numberOfBUSIds;
}

=head2 Validate_And_Fetch_FastDiag_Parameters

    ( $selectedVarInfo_aref, $nbr_of_BUS_Ids, $isNextPOC, $csv_data_file_path ) = Validate_And_Fetch_FastDiag_Parameters( $fastDiagConfig_href );
    
This function validates the fast Diagnosis parameters and returns the valid parameters

B<Arguments:>

=over

=item $fastDiagConfig_href

$fastDiagConfig_href = {
    
    labels => [<label_1>, <label_2>, ...], 
    
    number_of_BUS_Ids => ...,   # optional
    
    time_resolution_ms => ...,  # optional
    
    is_next_POC => 0|1,         # optional
    
    csv_data_file_path => ...,  # optional
    
}

Below are the parameters in the hash reference

B<labels> : Array reference to the label names for which fast diagnosis data will be read.

B<(optional) number_of_BUS_Ids> : It tells about the resolution at which particular Nbr of bytes can be read.

The Nbr of BUS Ids allowed is project specific. 

B<(optional)time_resolution_ms> : Not yet supported. Desired time resolution of the data, possible values:  0.5, 1, 2, 4, 6, 8

B<(optional)is_next_POC> : This provides the possibility to start the fast diagnosis not immediately(=0, default), but on next ECU power on(=1)

B<(optional)csv_data_file_path> : Path of the directory where the csv files for the individual labels are stored, default is <report-folder>\FastDiagData_<date>_<time>

=back

B<Return Values:>

=over

=item $selectedVarInfo_aref

Success : array reference to the variable info in the format 'address,label_name,type'

Error   : undef

=item $nbr_of_BUS_Ids

Success : Valid Nbr Of BUS IDs

Error   : undef

=item $isNextPOC

Success : Next Power on cycle flag(0 - current power on cycle, 1 - Next power on cycle)

Error   : undef

=item $csv_data_file_path

Success : File path where csv files are stored

Error   : undef

=back

B<Examples:>

my $fastDiagConfig_href = {
        
    labels => ['Adc_GroupInfo(0).resultBuffer_puo_U8'], 
    
    number_of_BUS_Ids => 2,   # optional
    
    is_next_POC => 0,         # optional
    
    csv_data_file_path => 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/',      # optional
}

( ['FEDF8004,Adc_GroupInfo(0).resultBuffer_puo_U8, U8'], 2, 0, 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/' ) = Validate_And_Fetch_FastDiag_Parameters( $fastDiagConfig_href ); # Validates label info, Nbr of BUS iDs, Next Power on cycle flag and csv result filepath

B<Notes: Not exported function>  

=cut

sub Validate_And_Fetch_FastDiag_Parameters {

    my @args = @_;

    S_checkFunctionArguments( 'Validate_And_Fetch_FastDiag_Parameters( $fastDiagConfig_href )', @args ) or return;
    my $fastDiagConfig_href = shift @args;

    my $labels_aref        = $fastDiagConfig_href->{'labels'};
    my $nbr_of_BUS_Ids     = $fastDiagConfig_href->{'number_of_BUS_Ids'};
    my $isNextPOC          = $fastDiagConfig_href->{'is_next_POC'};
    my $csv_data_file_path = $fastDiagConfig_href->{'csv_data_file_path'};

    # STEP Fetch the input arguments (labels, number_of_BUS_Ids(optional), is_next_POC(optional) and csv_data_file_path(optional))

    S_w2log( 4, "Validate_And_Fetch_FastDiag_Parameters: Fetching the parameters required for Fast Diagnosis...\n" );

    # CALL CheckPreconditions
    CheckPreconditions() or return;

    # STEP If $csv_data_file_path is not defined then by default <report-folder>\FastDiagData_<date>_<time> is considered
    if ( not defined $csv_data_file_path ) {
        $csv_data_file_path = $main::REPORT_PATH . '/' . "FastDiagData_" . S_get_date_extension( time() ) . "/";
        S_w2log( 4, "Validate_And_Fetch_FastDiag_Parameters : Data file path is not defined, so by default '$csv_data_file_path' is considered\n" );
    }

    #To create directory for full given path
    if ( not -e $csv_data_file_path and not make_path $csv_data_file_path) {
        S_set_error( "Validate_And_Fetch_FastDiag_Parameters : Failed to create path: $csv_data_file_path\n", 109 );
        return;
    }

    # CALL Validate_ReqRespIds to validate the Nbr of BUS IDs against the Maximum Nbrof BUS IDs allowed
    $nbr_of_BUS_Ids = Validate_ReqRespIds($nbr_of_BUS_Ids) or return;    #return if the Nbr of BUS IDs for Fast Diagnosis is 0 for the respective project

    # STEP if NextPOC value is not defined or is not valid then Default Value considered is 0
    if ( not defined $isNextPOC or $isNextPOC !~ /(0|1)/ ) {
        $isNextPOC = '' unless ( defined $isNextPOC );
        S_w2log( 4, "Validate_And_Fetch_FastDiag_Parameters : NextPOC Value '$isNextPOC' is not valid. Value can be either '0' or '1', so by default '0' is considered\n " );
        $isNextPOC = 0;
    }

    if ( scalar(@$labels_aref) < 1 or S_check_array( $labels_aref, "\$labels_aref" ) == 0 ) {
        S_set_error( "Validate_And_Fetch_FastDiag_Parameters : The Variable array reference passed as a parameter is empty or \$labels_aref contains undefined value\n", 109 );
        return;
    }

    # CALL Fetch_FastDiag_Label_Info
    my $selectedVarInfo_aref = Fetch_FastDiag_Label_Info( $labels_aref, $csv_data_file_path ) or return;

    # STEP Return ($selectedVarInfo_aref, $nbr_of_BUS_Ids, $isNextPOC, $csv_data_file_path)
    return ( $selectedVarInfo_aref, $nbr_of_BUS_Ids, $isNextPOC, $csv_data_file_path );
}

=head2 Fetch_FastDiag_Label_Info

    ( $selectedVarInfo_aref ) = Fetch_FastDiag_Label_Info( $labels_aref, $csv_data_file_path );
    
Convert the Label info into format 'address,label_name,type'

B<Arguments:>

=over

item $labels_aref

Array reference to the label names for which fast diagnosis data will be read.

item $csv_data_file_path

Path of the directory where the csv files for the individual labels are stored, default is <report-folder>\FastDiagData_<date>_<time>

=back

B<Return Values:>

=over

=item $selectedVarInfo_aref

Success : array reference to the variable info in the format 'address,label_name,type'

Error   : undef

B<Examples:>

( ['FEDF8004,Adc_GroupInfo(0).resultBuffer_puo_U8, U8'], 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/') = Fetch_FastDiag_Label_Info( ['Adc_GroupInfo(0).resultBuffer_puo_U8'] ); # Convert the label info 'Adc_GroupInfo(0).resultBuffer_puo_U8' to 'FEDF8004,Adc_GroupInfo(0).resultBuffer_puo_U8, U8'

B<Notes: Not exported function>  

=cut

sub Fetch_FastDiag_Label_Info {

    my @args = @_;

    S_checkFunctionArguments( 'Fetch_FastDiag_Label_Info( $labels_aref, $csv_data_file_path )', @args ) or return;
    my $labels_aref        = shift @args;
    my $csv_data_file_path = shift @args;

    my @label_type;
    my $selectedVarInfo_aref;
    my ( $name, $address, $type, $noOfCells );

    $noOfCells = 0;

    # STEP Fetch label_name/address and type from $labels_aref for each label and $csv_data_file_path(Ex : ['Adc_GroupInfo(0).resultBuffer_puo_U8', 'rb_sycc_SysConfCsemDataEe_st.sensorID;U8'])
    foreach my $label (@$labels_aref) {

        @label_type = split /;/, $label;

        # CALL PRD12_Read_Cell to Check whether the label name/address is valid
        PRD12_Read_Cell( $label_type[0] ) // return;

        $type = $label_type[1];

        # IF $Label is address
        if ( $label_type[0] =~ /^\d+$/ or $label_type[0] =~ /^0x[0-9A-F]+$/i ) {

            #   IF-YES-START
            #     CALL Get_Name_From_Address to fetch label name
            #     STEP use the address as it is
            #  IF-YES-END

            $name = Get_Name_From_Address( $label_type[0] ) or return;

            $address = $label_type[0];
            $address = hex( lc($address) ) if $address =~ /^0x/i;
        }
        else {

            #  IF-NO-START
            #    CALL Get_Address_From_Name to fetch address incase of label name
            #    STEP use the label name as it is
            #  IF-NO-END
            $name = $label_type[0];
            $address = Get_Address_From_Name( $label_type[0] ) or return;
        }

        # CALL GetSymbolDataType to fetch type
        $type = GetSymbolDataTypeFromAddOrLabel($name) unless ( defined $type );

        # STEP check the length of the absolute filename
        Validate_FastDiag_Result_File_Length( $name, $csv_data_file_path ) or return;

        # STEP If type is not passed as a parameter or not given in label name then by default 'U8' is considered

        unless ( defined $type ) {
            $type = 'U8';
            S_set_warning("Fetch_FastDiag_Label_Info : By default 'type' is considered as 'U8' for label '$label_type[0]' since its not defined\n");
        }

        unless ( $type =~ /^U8|S8|S10|U16|S16|U32|S32|U64|S64$/i ) {
            S_set_error( " Fetch_FastDiag_Label_Info : wrong type : $type != U8,S8,S10,U16,S16,U32,S32,U64,S64", 114 );
            return;
        }

        $type =~ /^(U|S)(\d+)$/i;
        my $bits = $2;
        $bits = 16 if ( $bits == 10 );    # treat S10 as 2 byte value
        $noOfCells += $bits / 8;

        $address = sprintf( "%8X", $address );
        push( @$selectedVarInfo_aref, $address . "," . $name . "," . uc($type) );
        $address = $name = $type = undef;
    }

    # STEP If Nbr of cells or Nbr of variables are greater than 28 then throw an error
    my $names_aref_length = scalar(@$selectedVarInfo_aref);
    if ( $noOfCells > 28 ) { S_set_error( "Fetch_FastDiag_Label_Info : The Nbr of cells $noOfCells or the Nbr of variables $names_aref_length passed to the Function exceeds the maximum allowed limit 28(Maximum of 28 cells are allowed for Fast Diagnosis) ", 109 ); return; }

    # STEP return $selectedVarInfo_aref
    return $selectedVarInfo_aref;
}

=head2 Get_FDtrace_from_CSV_File

    $data_HoH = Get_FDtrace_from_CSV_File( $data_path );       

This function is used to fetch the fast diagnosis data from the .csv file generated from the PRD12_Start_Fast_Diagnosis function

B<Arguments:>

=over

=item $data_path 

It is the path to the folder containing .csv files having the fast diagnosis data.

=back

B<Return Value:>

=over

=item $fdData_href 

Success : returns the structure created from fast diagnosis .csv file

Error return : undef

=back

B<Examples:>

    $fdData_href = Get_FDtrace_from_CSV_File( $data_path );
    
B<Notes: Not exported function>      

=cut

sub Get_FDtrace_from_CSV_File {
    my @args = @_;
    S_checkFunctionArguments( 'Get_FDtrace_from_CSV_File( $data_path )', @args ) or return;

    my $data_path = shift @args;

    my ( $name, $line );
    my $fdData_href = {};

    $data_path =~ s/\.(\S+)$//;    #Removing file extension

    unless ( -d $data_path ) {
        S_set_error( "Get_FDtrace_from_CSV_File : Tracefilefolder $data_path is not found ", 1 );
        return;
    }

    # STEP Fetch all the files in the $data_path
    my @files = glob("$data_path/*.csv");

    unless ( scalar(@files) ) {
        S_set_error( "Get_FDtrace_from_CSV_File : No fastDiag Data Files(*.csv) are generated in the location $data_path", 121 );
        return;
    }

    foreach my $file (@files) {

        my $labelname = basename($file);    #To get the filename(basename)

        # STEP Get the label name from file name Eg: 20180314_161738_1_fd_rb_dsa_PrevRearSevInfo_u16_U16.csv
        if ( $labelname =~ /^\d+_\d+_\d+_fd_(.+?)\.csv$/ ) {
            $name = $1;

            # Remove the variable type
            $name = $1 if ( $name =~ /^(.*)_(U8|S8|S10|U16|S16|U32|S32|U64|S64)$/i );
        }

        # STEP Fetch the data from csv file (the fast diagnosis data and time is extracted) and converts into standard format($fdData_href->{$time}->{$name})
        my $in_fh;
        unless ( open( $in_fh, '<', $file ) ) {
            S_set_error( "Get_FDtrace_from_CSV_File : Cannot open input file $file : $!", 1 );
            return;
        }
        my @lines = <$in_fh>;
        close $in_fh;

        foreach my $line (@lines) {

            # portion is added in below manner and needs to be skipped
            # time_ms ; measurment_hex ; measurment_dec
            next if ( $line =~ /^time_ms.*$/i );

            chomp($line);
            my @values = split /;/, $line;
            my $time = $values[0];
            $time =~ s/,/\./;
            my $fdData = $values[2];    #Converting to hex value
            $fdData_href->{$time}->{$name} = $fdData;
        }
    }

    # STEP return fast Diagnosis $fdData_href incase of success otherwise undef
    return $fdData_href;
}

=head2 GetSymbolDataTypeFromAddOrLabel

    $type = GetSymbolDataTypeFromAddOrLabel( $labelOrAddress );
    
Fetches the type from label name/Address(from the SAD file).

If the address(decimal/hex) is passed as input, Corresponding label is fetched and type is determined.

B<Arguments:>

=over

=item $labelOrAddress

It is the label name/Address from which type has to be fetched

=back

B<Return Values:>

=over

=item $type

Success : Returns the type of the variable(fetches from the variable name)

Error  : Undef

=back

B<Examples:>

 'U32'  = GetSymbolDataTypeFromAddOrLabel('rb_tim_EcuOnTimeDataEe_st.POnCounter_u32');
 'U8'   = GetSymbolDataTypeFromAddOrLabel('rb_prhs_SendCounter_u8');
 'S16'  = GetSymbolDataTypeFromAddOrLabel( 'A_AccEcuChannel_S16R(2)' );
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'A_EEMgrJobTable_XSR(0).A_EEData_U8X' );
 'S8'   = GetSymbolDataTypeFromAddOrLabel( 'A_RgBBuf_XSR(0).A_RgBAcc_XSX(0).V_CSX_S8X' );
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'A_EEMgrJobTable_XSR(0).A_EEData_U8X' );
 'U32'  = GetSymbolDataTypeFromAddOrLabel( 'rb_fcl_FireSeq1_st.MarkerDevice_au32(0)' );
 'U32'  = GetSymbolDataTypeFromAddOrLabel( 'rb_fcl_FireSeq_st.Mask_au32(0)(0)' );
 'S32'  = GetSymbolDataTypeFromAddOrLabel( 'T_OMFLpFilterNoResetSto_t_S32X(0)' );
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'rb_aid_AidaParameters_nvmst.A_RoseStpTableAR_t_U8X(0)(0)' );
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'rb_sqmf_Firecounter_au16(0)(13).1' );
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32.1' ); 
 'U8'   = GetSymbolDataTypeFromAddOrLabel( 'rb_sfcs_TestModuleProcessParamsTable_cast(4).SubtestId_u32.2' ); 
 'U64'  = GetSymbolDataTypeFromAddOrLabel( 'rb_cs7m_RUVData_ast(0).QuadI_st.QuadSum_u64' );
 'U64'  = GetSymbolDataTypeFromAddOrLabel( '0xFEBF2778' ); # as 0xFEBF2778 => rb_cs7m_RUVData_ast(0).QuadI_st.QuadSum_u64 in sad file
 'U32'  = GetSymbolDataTypeFromAddOrLabel( '0xFEDFB9BC' ); # as 0xFEDFB9BC => rb_mcs_UniqueMcId_u32 in sad file
 undef  = GetSymbolDataTypeFromAddOrLabel( 'A_ImpactInfoINTW_XSR(0).E_ImpactEnd_XXX' ); 
 
B<Notes: Not exported function>  

=cut

sub GetSymbolDataTypeFromAddOrLabel {

    my @args = @_;
    S_checkFunctionArguments( 'GetSymbolDataTypeFromAddOrLabel( $labelOrAddress )', @args ) or return;

    my $labelOrAddress = shift @args;

    # STEP Fetch the input arguments ($labelOrAddress)

    # IF Address is given as input?
    if ( $labelOrAddress =~ /^\d+$/ or $labelOrAddress =~ /^0x[0-9A-F]+$/i ) {

        # IF-YES-START
        # STEP Get the decimal address from given address
        # STEP Fetch the label associated with the address
        # IF-YES-END
        my $address = $labelOrAddress;
        $address = hex( lc($labelOrAddress) ) if $labelOrAddress =~ /^0x/i;
        $labelOrAddress = $symbolMapping_href->{'sad'}{'AddresstoSymbol'}{$address} or return;
    }

    # IF-NO-START
    # IF-NO-END
    # STEP Fetch the type from label name
    my @matches = $labelOrAddress =~ m/([usb]\d+)/ig;    # collect all matches of u or s or b followed by digits
    my $type    = pop(@matches);                         # use the last match (that which is rightmost in the string)

    # STEP If the variable format is 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32.1' ie followed by .nbr then by default U8 is considered
    $type = 'U8' if ( $labelOrAddress =~ /.*\.\d+$/i );

    # STEP return type incase of success, otherwise undef
    # STEP End

    return $type;
}

=head2 Get_Name_From_Address

    $label_name = Get_Name_From_Address( $address );
    
Fetches the label name from address(from the SAD file).

B<Arguments:>

=over

=item $address

It is the address whose corresponding label name in SAD file should be fetched

=back

B<Return Values:>

=over

=item $label_name

Success/Offline : Returns the label name of the corresponding address in the SAD file

Error           : Undef

=back

B<Examples:>

'rb_sfra_FastRAMTstFailed_bo' = Get_Name_From_Address( '0xFEDF8000' );

'rb_sfra_FastRAMTstFailed_bo' = Get_Name_From_Address( 4276060164 );

B<Notes: Not exported function>

=cut

sub Get_Name_From_Address {
    my @args = @_;

    S_checkFunctionArguments( 'Get_Name_From_Address( $address )', @args ) or return;

    # STEP Fetch the input arguments (address)
    my $address = shift @args;

    S_w2log( 5, " Get_Name_From_Address : Fetches the Label_name of the corresponding address $address from SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ) . "\n" );

    # STEP handle offline
    return 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' if ($main::opt_offline);

    # IF address exists in the SAD file
    #   IF-YES-START
    #     STEP Fetch the label name using the address from $symbolMapping_href
    #   IF-YES-END

    unless ( defined $symbolMapping_href ) {
        S_set_error( "Get_Name_From_Address : No contents are fetched from the SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ) . " !Please First call PRD12_init function", 23 );
        return;
    }

    #  IF-NO-START
    #     STEP Set an error

    $address = hex( lc($address) ) if $address =~ /^0x/i;

    my $label_name;
    foreach my $label ( keys %{ $symbolMapping_href->{'sad'}{'symbol'} } ) {
        if ( $symbolMapping_href->{'sad'}{'symbol'}{$label}{'address'} == $address ) {
            $label_name = $label;
            last;
        }
    }

    unless ( defined $label_name ) {
        S_set_error( "Get_Name_From_Address : address $address is not found in SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ), 23 );
        return;
    }

    # IF-NO-END
    # STEP return the label name, undef incase of error
    return $label_name;
}

=head2 Get_Address_From_Name

    $address = Get_Address_From_Name( $name );
    
Fetches the address(integer) of the corresponding label($name) from the SAD file.

B<Arguments:>

=over

=item $name

$name is the label name whose corresponding address in SAD file should be fetched

=back

B<Return Values:>

=over

=item $address

Success/Offline : Returns the address(integer) of the corresponding label in the SAD file

Error           : Undef

=back

B<Examples:>

4276060164 = Get_Address_From_Name( 'rb_tim_EcuOnTimeDataEe_st.POnCounter_u32' );

B<Notes:> 

=cut

sub Get_Address_From_Name {
    my @args = @_;

    S_checkFunctionArguments( 'Get_Address_From_Name( $name )', @args ) or return;

    # STEP Fetch the input arguments (label name)
    my $name = shift @args;

    # offline return
    return 0xFFFF0000 if ($main::opt_offline);

    S_w2log( 5, " Get_Address_From_Name: Fetches the address of the corresponding label $name from SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ) . "\n" );

    # IF Label exists in the SAD file
    #   IF-YES-START
    #     STEP Fetch the address using the label name from $symbolMapping_href
    #   IF-YES-END

    unless ( defined $symbolMapping_href ) {
        S_set_error( "Get_Address_From_Name: No contents are fetched from the SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ) . " !Please First call PRD12_init function", 23 );
        return;
    }

    #  IF-NO-START
    #     STEP Set an error

    my $address;

    # Fetch the variable name if its given in a format of variable_name.index(Ex : rb_tim_EcuOnTimeDataEe_st.PoOnTime_u32.0)
    $name = $1 if ( $name =~ /(.*)\.(\d)$/ and $2 == 0 );

    if ( exists $symbolMapping_href->{'sad'}{'symbol'}{$name} ) {
        $address = $symbolMapping_href->{'sad'}{'symbol'}{$name}{'address'};
    }
    else {
        S_set_error( "Get_Address_From_Name: Label $name is not found in SAD File " . File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} ), 23 );
        return;
    }

    # IF-NO-END
    # STEP return the address, undef incase of error
    return $address;
}

=head2 Get_ECU_Mode

    my $ECUMode = Get_ECU_Mode();

Get ECU Mode.

Success return :: Type of ECU mode: 'Init1', 'Init2', 'Init3', 'Idle', 'NormalDriving', 'Disposal', 'Crash', 'ReProg'

Offline Return :: 1
Error Retun :: undef

B<Note:> Supported AB Generations:: B<12>

=cut

sub Get_ECU_Mode {

    my $ecuModes_href = {

        # key => value pair indicates the ECU mode in numeric and string format respectively.
        1 => 'Init1',
        2 => 'Init2',
        3 => 'Init3',
        4 => 'Idle',
        5 => 'NormalDriving',
        6 => 'Disposal',
        7 => 'Crash',
        8 => 'ReProg'
    };

    #STEP read label "rb_bswm_ActualSystemMode_au16"
    my $label      = 'rb_bswm_ActualSystemMode_au16(0)';
    my $value_aref = PRD12_Read_Cell($label);              #This Variable name contains the mode in which the ECU is currently operated

    #STEP set error if value read has 0 bytes
    if ( scalar(@$value_aref) < 1 ) {
        S_set_error("Get_ECU_Mode : $label received no values");
        return;
    }
    my $ecuMode_inNbr = $value_aref->[1];                  # index 1 indicates the ECU MODE

    my $ecuMode = $ecuModes_href->{$ecuMode_inNbr};

    #STEP Set error if ecu mode is not valid
    if ( $ecuMode_inNbr < 1 || $ecuMode_inNbr > 8 ) {
        S_set_error("Get_ECU_Mode: $label received invalid values");
        return;
    }

    #STEP return ECU mode
    S_w2log( 4, "ECU is in $ecuMode mode \n" );
    return $ecuMode;

}

=head2 ReadLampStates

    $states_href = ReadLampStates();

Reads the Lamp states of Analog outputs as well as system warning lamps.

B<Arguments:>

=over

=back

B<Return Values:>

=item $states_href

Reference to hash containing lamp states (Both Analog and System W/L)

Success : 

          $states_href = {
             "AOutPassAirbagOnIndicator"            => "Off",
             "SystemWarningLamp"                  => "On",
             "AOutPassAirbagOffIndicator"           => "Off",
          };

=back

B<Notes: Not exported function>

=cut

sub ReadLampStates {
    my @args = @_;
    S_checkFunctionArguments( 'ReadLampStates()', @args ) or return;

    S_w2log( 4, "ReadLampStates\n" );

    my $states_href = {};

    if ($main::opt_offline) {
        return {
            'AOutPassAirbagOffIndicator' => 'Off',
            'AOutPassAirbagOnIndicator'  => 'Off',
            'SystemWarningLamp'          => 'On'
        };
    }

    # CALL GetWarningLampStates to get warning lamp states
    GetWarningLampStates($states_href);

    # CALL GetAnalogLampStates to get analog lamp states
    GetAnalogLampStates($states_href);

    # STEP return lamp states of analog outputs as well as system warning lamps
    return $states_href;
}

=head2 Get_lamp_enums

    Get_lamp_enums($enum_type);

enum value and comment related to the lamp will be returned.

example : 0(value) => 'off'(comment), 1 (value) => 'on'(comment) 

B<Arguments:>

=over

=item $enum_type

ECU SW software variable for enum range.

=back

B<Return Values:>

=item $lampStatesEnum_href

Reference to hash containing lamp enum range.

Success : 

          $lampStatesEnum_href = {
             0 => "Off",
             1 => "On",
             2 => "Invalid data. Device is unable to generate valid data",
             3 => "Data Not Available. Device is not configured",
             4 => "Length of the SysWI status enum"
          };

=back

B<Notes: Not exported function>

=cut

sub Get_lamp_enums {
    my @args = @_;
    S_checkFunctionArguments( 'Get_lamp_enums($enum_type)', @args ) or return;
    my $enum_type           = shift @args;
    my $lampStatesEnum_href = {};
    my $wl_status  = \%LAMPSTATE;

    # STEP Get the lampstates values (ON, Off,Invalid Data . . etc) from CNS file

    if ( exists $symbolMapping_href->{'cns'}{'enum'}{$enum_type} ) {
        foreach my $symbol_name ( keys %{ $symbolMapping_href->{'cns'}{'enum'}{$enum_type} } ) {
        	my $comment = $wl_status->{$symbol_name};
            my $symbol_value = $symbolMapping_href->{'cns'}{'enum'}{$enum_type}{$symbol_name}{value};
            $lampStatesEnum_href->{$symbol_value} = $comment;
        }
    }
    else {
        my $cns_file_path = File::Spec->rel2abs( $prd12StoreVar_href->{'SADFILEPATH'} );
        $cns_file_path =~ s/\.sad$/\.cns/;
        S_set_error( "ReadLampStates : Enum type '$enum_type' is not found in CNS File '$cns_file_path'", 23 );
        return;
    }

    return $lampStatesEnum_href;
}

=head2 GetWarningLampStates

    GetWarningLampStates($states_href, $lampStates_aref);

Reads the Lamp states of system warning lamps.

B<Arguments:>

=over

=item $lampStates_aref

Array reference to the lamp states

=back

B<Return Values:>

=item $states_href

Reference to hash containing lamp states (System W/L)

Success : 

          $states_href = {
             "System Warning Lamp" => "On",
          };

=back

B<Notes: Not exported function>

=cut

sub GetWarningLampStates {

    my @args = @_;
    S_checkFunctionArguments( 'GetWarningLampStates($states_href)', @args ) or return;

    my $states_href = shift @args;

    S_w2log( 4, "GetWarningLampStates\n" );
    my $enum_type = 'rb_wimi_SysWIStatus_ten';

    #CALL Get_lamp_enums
    my $lampStatesEnum_href = Get_lamp_enums($enum_type);

    return unless ($lampStatesEnum_href);

    #Variables to get the status of system Warning Lamps in case of AB12
    #rb_wimi_SysWIStatus_en - Variable for warning lamps in BEG and JLR projects
    my $warning_lamp_variables_aref = [ "rb_wimi_SysWIStatus_aen(0)", "rb_wim_CustSysWIStatus_aen(0)", "rb_wima_SysWIStatus_en", "rb_wimi_SysWIStatus_en" ];
    my $lamp_name = 'SystemWarningLamp';

    #CALL Get_lamp_state to get warning lamp state
    return unless ( Get_lamp_state( $states_href, $warning_lamp_variables_aref, $lampStatesEnum_href, $lamp_name ) );

    #STEP return lamp states of system warning lamps
    return 1;
}

=head2 Get_lamp_state

    Get_lamp_state($states_href, $lamp_variables_aref, $lampStatesEnum_href, $lamp_name);

Reads the Lamp states of system warning lamps.

B<Arguments:>

=over

=item $states_href

href to fill and return the lamp state.

=item $lamp_variables_aref

SW variables to read a lamp of particular type ($lamp_name).

=item $lampStatesEnum_href

enum which contains the possible values of lamp state.

=item $lamp_name

name of the lamp for which the state has to be obtained.

=back

B<Return Values:>

=item $states_href

Reference to hash containing lamp states

=back

B<Notes: Not exported function>

=cut

sub Get_lamp_state {

    my @args = @_;
    S_checkFunctionArguments( 'Get_lamp_state($states_href, $lamp_variables_aref, $lampStatesEnum_href, $lamp_name)', @args ) or return;

    my $states_href         = shift @args;
    my $lamp_variables_aref = shift @args;
    my $lampStatesEnum_href = shift @args;
    my $lamp_name           = shift @args;

    my $lamp_variable_flag = 0;

    # STEP Read the value of Warning Lamp variable
    foreach my $lamp_var (@$lamp_variables_aref) {
        my $data_aref = PRD12_Read_Cell_NOERROR($lamp_var);
        if ( defined $data_aref ) {
            $lamp_variable_flag = 1;
            $states_href->{"$lamp_name"} = $lampStatesEnum_href->{ $$data_aref[0] };
            last;
        }
    }

    if ( $lamp_variable_flag == 0 )    # Incase the warning lamp status is not updated from all variables
    {
        S_set_warning("Get_lamp_state : '$lamp_name' status not updated from predefined variables '@$lamp_variables_aref'");
    }
    return 1;
}

=head2 GetAnalogLampStates

    GetAnalogLampStates($states_href, $lampStates_aref);

Reads the Lamp states of Analog output lamps.

B<Arguments:>

=over

=item $lampStates_aref

Array reference to the lamp states

=back

B<Return Values:>

=item $states_href

Reference to hash containing lamp states (Analog W/L)

Success : 

          $states_href = {
             "AOutPassAirbagOnIndicator"            => "Off",
             "AOutPassAirbagOffIndicator"           => "Off",
          };
=back

B<Notes: Not exported function>

=cut

sub GetAnalogLampStates {

    my @args = @_;
    S_checkFunctionArguments( 'GetAnalogLampStates($states_href)', @args ) or return;

    my $states_href = shift @args;

    my $enum_type = 'rb_wimi_PAOxStatus_ten';

    #STEP Collect passenger airbag enum range
    my $lampStatesEnum_href = Get_lamp_enums($enum_type);

    return unless ($lampStatesEnum_href);

    if ( exists $allDevDetails_href->{lamps} ) {
        foreach my $aout_label ( keys %{ $allDevDetails_href->{lamps} } ) {

            #STEP get PAOx on/off lamp state.
            if ( $aout_label =~ /(AOutPassAirbagOffIndicator)/i ) {
                my $warning_lamp_variables_aref = [ "rb_wimi_PAOxStatus_aen(0)", "rb_wimp_PAOxStatus_aen(0)", "rb_wimi_PAOxStatus_en" ];
                Get_lamp_state( $states_href, $warning_lamp_variables_aref, $lampStatesEnum_href, $aout_label );
            }
            if ( $aout_label =~ /(AOutPassAirbagOnIndicator)/i ) {
                my $warning_lamp_variables_aref = [ "rb_wimi_PAOxStatus_aen(1)", "rb_wimp_PAOxStatus_aen(1)", "rb_wimi_PAOxStatus_en" ];
                Get_lamp_state( $states_href, $warning_lamp_variables_aref, $lampStatesEnum_href, $aout_label );
            }

        }
    }

    #STEP END
    return 1;
}

=head2 Validate_FastDiag_Result_File_Length

    $success = Validate_FastDiag_Result_File_Length([$label_name, $data_file_path]);       

This function is used to validate the complete file pathname of the fastDiag result file

B<Arguments:>

=over

=item $label_name

It is the label name present in SAD file

=item $data_file_path

Data file path whose length along with variable name has to be verified

=back

B<Return Value:>

=over

=item $success 

Success/Offline : 1

Error return : undef

=back

B<Examples:>

    1 = Validate_FastDiag_Result_File_Length(['Adc_GroupInfo(0).resultBuffer_puo_U8', 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/']);

B<Notes: Not exported function>     

=cut

sub Validate_FastDiag_Result_File_Length {

    my @args = @_;
    return unless S_checkFunctionArguments( 'Validate_FastDiag_Result_File_Length( [$label_name, $data_file_path] )', @args );

    my $label_name     = shift @args;
    my $data_file_path = shift @args;

    my $max_pathlength = 255;

    # STEP check the length of the absolute filename

    my $templateFileName = '/yyyymmdd_hhmmss_d_fd_' . $label_name . '_Udd.csv';
    my $folderpath       = length($data_file_path);
    my $filenamelength   = length($templateFileName);
    my $totalFileLength  = $folderpath + $filenamelength;
    if ( $totalFileLength > $max_pathlength ) {
        S_set_error( "Validate_FastDiag_Result_File_Length : The FD trace file path '$data_file_path' ( length '$folderpath') + filename '$templateFileName' ( length $filenamelength) exceeds maximum length '$max_pathlength', choose shorter path!", 114 );
        return;
    }

    #STEP If the length is within allowed range return 1 else return undef
    return 1;
}

=head2 GetEcuPropertyForFile

    ($swVersion, $variantVer, $variantID, $algoProjectID, $algoParaID) = GetEcuPropertyForFile();

Gets ECU properties to dump into files for reading EDR, NVM memory types(could be used for other types also)

Returns :: ($swVersion, $variantVer, $variantID, $algoProjectID, $algoParaID)

B<Note: Not exported function>

=cut

sub GetEcuPropertyForFile {

    my ( $swVersion, $variantVer, $variantID, $algoProjectID, $algoParaID ) = ('Not available') x 5;

    my $ecuProp_href = PRD12_Get_ECU_Properties( { 'Property_names' => ['ECU_details'] } );

    $swVersion  = $ecuProp_href->{'ECU_details'}{'EcuSwVersion'};
    $variantID  = $ecuProp_href->{'ECU_details'}{'Variant_ID'};
    $variantVer = $ecuProp_href->{'ECU_details'}{'Variant_Version'};

    my $algodetails = $ecuProp_href->{'ECU_details'}{'Algo_Param_ID'};

    # initialise variables to 'Not Available'
    if ( $algodetails =~ /^0X([0-9a-fA-F]{4})([0-9a-fA-F]{2})/i ) {
        $algoProjectID = '0x' . $1;
        $algoParaID    = '0x' . $2;
    }
    return ( $swVersion, $variantVer, $variantID, $algoProjectID, $algoParaID );

}

=head2 CreateFileNameAndLink

    ( $fileName, $htmlLink ) = CreateFileNameAndLink( $memoryType [,$fileName, $addDateTime ] );

creates file name and html link to dump data functionalities (EDR, NVM).

Returns :: ( $fileName, $htmlLink )

B<Note: Not exported function>

=cut

sub CreateFileNameAndLink {
    my @args = @_;
    S_checkFunctionArguments( 'CreateFileNameAndLink( $memoryType [,$fileName, $addDateTime ] )', @args ) or return;
    my $memoryType  = shift @args;
    my $fileName    = shift @args;
    my $addDateTime = shift @args // 1;

    #default names and extensions if filename is not defined
    my $memTypeFilename_href = {
        nvm => {
            name      => 'ALL_NVM_Sections',
            extension => 'txt',
        }
    };

    #prepare time stamp
    my $time = S_get_date_extension();
    my $linkName;

    if ( defined $fileName ) {

        # add date and time if configured
        if ( $fileName =~ /(.*)\.(.*)/ ) {
            $fileName = $1 . '_' . $time . '.' . $2 if $addDateTime;
        }

        # if only file name is given fetch the relative path
        if ( $fileName !~ /:|\/|\// ) {
            $fileName = $main::REPORT_PATH . '/' . $fileName;
            $linkName = File::Spec->abs2rel( $fileName, $main::REPORT_PATH );
        }

        # if complete path is given
        else {
            $linkName = $fileName;
            $linkName =~ s/^([A-Za-z]:)/file:\/\/\/$1/;
        }

        #create path if not exists
        my $create_dir = $fileName;
        $create_dir =~ s/(.*)(\/|\\).*/$1$2/;
        unless ( -e $create_dir or make_path($create_dir) ) {
            S_set_error( "CreateFileNameAndLink : Path '$fileName' could not be created", 109 );
            return;
        }
    }
    else {
        my $name      = $memTypeFilename_href->{$memoryType}{name};
        my $extension = $memTypeFilename_href->{$memoryType}{extension};
        $fileName = $name . '_' . $time . '.' . $extension;
        $fileName = $main::REPORT_PATH . '/' . $fileName;
        $linkName = File::Spec->abs2rel( $fileName, $main::REPORT_PATH );
    }
    my $htmlLink = '<A HREF=' . "$linkName" . ' TYPE="text/law">' . $linkName . '</A>';
    return ( $fileName, $htmlLink );
}

=head2 DumpAllNvmData

    1 = DumpAllNvmData($fileName, $htmlLink);

Dumps all nvm sections data to filename given.

Returns :: 1 on success, undef on failure

B<Note: Not exported function>

=cut

sub DumpAllNvmData {
    my @args = @_;
    S_checkFunctionArguments( 'DumpAllNvmData( $fileName, $linkName  )', @args ) or return;

    my ( $fileName, $linkName ) = ( shift @args, shift @args );

    if ( $fileName !~ /.*\.txt$/ ) {
        $fileName =~ /(.*(\/|\\))(.*)/;
        S_set_error( "DumpAllNvmData: NVM dump file type '$3' is invalid, Supported type '*.txt' ", 109 );
        return;
    }
    my $allNvmBlocks_href = S_get_contents_of_hash( [ 'nvm', 'block' ], $symbolMapping_href ) or return;
    my $nvmdata;
    foreach my $nvmblock ( sort { $allNvmBlocks_href->{$a}{block_ID} <=> $allNvmBlocks_href->{$b}{block_ID} } keys %$allNvmBlocks_href ) {
        my $noOfBytes        = $allNvmBlocks_href->{$nvmblock}{block_length};
        my $blockID          = $allNvmBlocks_href->{$nvmblock}{block_ID};
        my $blockConfig_href = {
            noOfBytes                 => $noOfBytes,
            blockID                   => $blockID,
            subBlockID                => 0,
            offset                    => 0,
            format_data_by_endianness => 0,
        };
        my $response_aref = PRD12_Read_NVM_cells_NOERROR($blockConfig_href);

        if ($response_aref) {
            map { $_ = sprintf( "%.2X", int $_ ) } @{$response_aref};
            $nvmdata .= "! NVM Section Name: $nvmblock , Block ID(d): $blockID , Block Length: $noOfBytes\n";
            $nvmdata .= "\n: " . join( ',', splice( @$response_aref, 0, 8 ) ) . ",\n" while (@$response_aref);
            chop $nvmdata;
            chop $nvmdata;
            $nvmdata .= "\n\n\n\n\n\n";
        }
    }

    unless ( open( my $dmpFileHandle, ">$fileName" ) ) {
        S_set_error( "DumpAllNvmData: could not dump NVM data to '$fileName' : $!", 1 );
        return;
    }
    else {
        my ( $swVersion, $variantVer, $variantID, $algoProjectID, $algoParaID ) = GetEcuPropertyForFile();
        print $dmpFileHandle "!! Time Date: " . S_get_date_extension() . "\n";
        print $dmpFileHandle "!! SW version : " . $swVersion . "\n";
        print $dmpFileHandle "!! Variant ID (hex) : " . $variantID . "\n";
        print $dmpFileHandle "!! Variant Version (hex) : " . $variantVer . "\n";
        print $dmpFileHandle "!! Algo project ID (hex) : " . $algoProjectID . "\n";
        print $dmpFileHandle "!! Algo parameter ID (hex) : " . $algoParaID . "\n";
        print $dmpFileHandle "$nvmdata";
        close $dmpFileHandle;
    }

    S_w2log( 3, "NVM data dumped to file : $linkName" );
    return 1;
}

=head2 ValidateAddressOrSymbol

    $address = ValidateAddressOrSymbol( $addressOrSymbol );

Validates the given Address/Symbol and converts it to decimal address

Returns decimal address on success, undef on failure
B<Note: Not exported function>

=cut

sub ValidateAddressOrSymbol {
    my @args = @_;
    S_checkFunctionArguments( 'ValidateAddressOrSymbol( $addressOrSymbol  )', @args ) or return;
    my $addressOrSymbol = shift;

    # IF Is $addressOrSymbol is an address?
    # IF-YES-START
    #   STEP Convert the given address to decimal if it is a Hexadecimal address
    # IF-YES-END
    # IF-NO-START
    #   CALL Get_Address_From_Name
    # IF-NO-END
    # STEP Return the Address
    # STEP END

    my $address;

    if ( $addressOrSymbol =~ /^\d+$/ or $addressOrSymbol =~ /^0x[0-9A-F]+$/i ) {
        $address = $addressOrSymbol;
        $address = hex( lc($address) ) if $address =~ /^0x/i;
    }
    else {
        $address = Get_Address_From_Name($addressOrSymbol) or return;
    }
    return $address;
}

=head2 ECUProtectionActivated

    $protectionActivated = ECUProtectionActivated();

Checks if ECU protection is activated (= ECU is locked or was locked once). This is done by checking the value of a particular memory variable.
If this variable does not exist in the SAD file or has the value 0x55AA55AA then no protection is active and 0 is returned.
Otherwise protection is active and 1 is returned.

B<Note: Not exported function>

=cut

sub ECUProtectionActivated {
    my $protectionActivatedLabel = 'rb_prd_OTPProtectionSettings_st.OTPProtectionActivated_u32';
    my $unprotectedValue         = 0x55AA55AA;
    my $unprotectedValueString   = "0x" . sprintf( "%X", $unprotectedValue );

    if ( not exists $symbolMapping_href->{'sad'}{'symbol'}{$protectionActivatedLabel} ) {
        S_w2log( 3, "ECUProtectionActivated: Label '$protectionActivatedLabel' does not exist in SAD file. Assuming ECU is not protected.\n" );
        return 0;
    }

    my $protectionValue = PRD12_Read_Cell( $protectionActivatedLabel, { memoryContentsAsInteger => 1 } );

    $protectionValue = $unprotectedValue if $main::opt_offline;

    if ( $protectionValue == $unprotectedValue ) {
        S_w2log( 3, "ECUProtectionActivated: Label '$protectionActivatedLabel' has the value '$unprotectedValueString'. ECU is not protected.\n" );
        return 0;
    }

    my $protectionValueString = "0x" . sprintf( "%X", $protectionValue );
    S_w2log( 3, "ECUProtectionActivated: Label '$protectionActivatedLabel' has the value '$protectionValueString' != '$unprotectedValueString'. ECU is locked or was locked once.\n" );
    return 1;
}

=head2 Fill_asicId_chnl

    $protectionActivated = Fill_asicId_chnl( $devProp_href, $devType, $devProp, $label, $devindx );

Fills $devProp_href hash with attributes 

B<Note: Not exported function>

=cut

sub Fill_asicId_chnl {

    my $devProp_href     = shift;
    my $devType          = shift;
    my $devProp          = shift;
    my $label            = shift;
    my $devindx          = shift;
    my $dataByLabel_href = shift;

    if ( ( $devType eq 'squibs' ) and ( $devProp eq 'asic_configuration' ) ) {
        my $loopConfigSetting_aref = GetLabelData( "$label($devindx)", $dataByLabel_href );
        $devProp_href->{'Asic_Id'}      = sprintf( "%d", $$loopConfigSetting_aref[0] >> 4 );
        $devProp_href->{'Asic_Channel'} = sprintf( "%d", $$loopConfigSetting_aref[0] & 0xF );
    }

    if ( ( $devType eq 'pases' ) and ( $devProp eq 'asic_configuration' ) ) {
        my $senstoasic_aref = GetLabelData( "$label($devindx)", $dataByLabel_href );
        $devProp_href->{'Asic_Id'} = sprintf( "%d", $$senstoasic_aref[0] );
    }

    if ( ( $devType eq 'pases' ) and ( $devProp eq 'asic_chnl_config' ) ) {
        my $senstochanl_aref = GetLabelData( "$label($devindx)", $dataByLabel_href );
        $devProp_href->{'Asic_Channel'} = sprintf( "%d", $$senstochanl_aref[0] );
    }

    if ( ( $devType eq 'switches' ) and ( $devProp eq 'asic_configuration' ) ) {
        if ($main::opt_offline) {
            $devProp_href->{'Asic_Id'}      = 0;
            $devProp_href->{'Asic_Channel'} = 0;
            return 1;
        }
        foreach my $asicid ( 0 .. $MAX_ASIC_ID ) {
            foreach my $cnhl ( 0 .. $MAX_ASIC_CHANNEL_SWITCH ) {
                my $devIdx_aref = GetLabelData( "$label($asicid)($cnhl)", $dataByLabel_href, 'NOERROR' );
                my $devIdx = $$devIdx_aref[0] // 0;
                $devIdx = sprintf( "%d", $devIdx );
                if ( $devIdx == $devindx ) {
                    $devProp_href->{'Asic_Id'}      = $asicid;
                    $devProp_href->{'Asic_Channel'} = $cnhl;
                    last;
                }
            }
        }
    }
    return 1;
}

=head2 ValidateGetDevice

    1 = ValidateGetDevice( $options_href );

Validates $options_href for Get device configuartion 

B<Note: Not exported function>

=cut

sub ValidateGetDevice {

    my @args         = @_;
    my $options_href = shift @args;

    if ( defined $options_href ) {
        my @invalid_options = grep { $_ !~ /NOHTML|devices|device_types/ } keys %$options_href;
        if (@invalid_options) {
            S_set_error( "ValidateGetDevice: options '@invalid_options' not supported, Check 'PRD_Get_Device_Configuration' Documentation for valid options", 109 );
            return;
        }
    }

    if ( exists $options_href->{'devices'} && exists $options_href->{'device_types'} ) {
        S_set_error( "ValidateGetDevice: Only one of options 'devices' or 'device_types' supported! configure any one!", 109 );
        return;
    }

    return 1;
}

=head2 WriteXmlContentToDumpFile

    WriteXmlContentToDumpFile( $edr_DumpFileName, $xml_content );

Writes the xml content to file '$edr_DumpFileName'.

B<Note: Not exported function>

=cut

sub WriteXmlContentToDumpFile {
    my @args            = @_;
    my $xml_fileName    = shift @args;
    my $xml_content     = shift @args;
    my $file_access_err = 0;
    open( my $fh, '>>', $xml_fileName ) or $file_access_err = $!;
    if ($file_access_err) {
        S_set_error( "WriteXmlContentToDumpFile : writing data to file '$xml_fileName' not successful!, check if file path exists $file_access_err", 109 );
        return;
    }
    print $fh $xml_content;
    close $fh;
    return 1;
}

=head2 EdrDump_to_XML

    EdrDump_to_XML( $edr_DumpFileName, $serviceID,$edrByteData );

Retrieves $edrByteData, $serviceID and ECU properties for the file and dumps it into an XML File $edr_DumpFileName 

B<Note: Not exported function>

=cut

sub EdrDump_to_XML {
    my @args         = @_;
    my $xml_fileName = shift @args;
    my $serviceID    = shift @args;
    my $edrByteData  = shift @args;
    my ( $swVersion, $variantVer, $variantNum, $algoProjectID, $algoParaID ) = GetEcuPropertyForFile();
    my $date      = S_get_date_extension();
    my $xmlheader = <<XMLHEADER;
<?xml version="1.0" encoding="utf-8"?>
<EDR_Dump xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://www.bosch.com/passiveSafety/EDR">
XMLHEADER
    WriteXmlContentToDumpFile( $xml_fileName, $xmlheader );

    my $userName               = Win32::LoginName();
    my $xmlAnalysis_body_fixed = <<XML_ANALYSIS_BODY_FIXED;
  <attributes>
    <dump_info user= "$userName" version= "1.0.0.0">
      <file_format_version>3</file_format_version>
      <time_stamp>$date</time_stamp>
      <software_version>$swVersion</software_version>
      <variant_number>$variantNum</variant_number>
      <variant_version>$variantVer</variant_version>
      <algo_project_id>$algoProjectID</algo_project_id>
      <algo_parameter_id>$algoParaID</algo_parameter_id>
      <file_checksum />
      <crash_code />
      <mapping_comment>comment</mapping_comment>
    </dump_info>
  </attributes>
  <crash_entry id="$serviceID">
    <payload_value>$edrByteData</payload_value>
  </crash_entry>   
</EDR_Dump>

XML_ANALYSIS_BODY_FIXED
    return unless ( WriteXmlContentToDumpFile( $xml_fileName, $xmlAnalysis_body_fixed ) );
    return 1;
}

=head

    Find_XML_File_Checksum( $edr_DumpFileName );

Finds the MD5 File checksum for $edr_DumpFileName with $dump_file_format_version => 3 and returns it

B<Note: Not exported function>

=cut

sub Find_XML_File_Checksum {
    my @args         = @_;
    my $xml_fileName = shift @args;
    open( my $fh, '<', $xml_fileName ) or S_set_error( "Can't open '$xml_fileName': $!", 109 );
    binmode($fh);
    my $md5Checksum = uc( Digest::MD5->new->addfile($fh)->hexdigest );
    close $fh;
    S_w2log( 3, "The Checksum is $md5Checksum.\n" );
    return $md5Checksum;
}

=head

    WrChecksumTo_XML_File( $edr_DumpFileName, $linkName );

$md5Checksum - Checksum of the XML file
Retrieves the MD5 File Checksum and replaces the <file_checksum /> tag with <file_checksum>$md5Checksum</file_checksum> in the same XML file whose Checksum is calculated
 

B<Note: Not exported function>

=cut

sub WrChecksumTo_XML_File {
    my @args = @_;
    S_checkFunctionArguments( 'WrChecksumTo_XML_File( $edr_DumpFileName, $linkName )', @args ) or return;
    my $xml_fileName = shift @args;
    my $linkName     = shift @args;
    my $md5Checksum  = Find_XML_File_Checksum($xml_fileName);
    return unless ($md5Checksum);
    my $file_access_err;

    # Read the xml content from $fileName
    open( my $fh_read, '<', $xml_fileName ) or $file_access_err = $!;
    if ($file_access_err) {
        S_set_error( "WrChecksumTo_XML_File : Reading data from file '$xml_fileName' not successful, check if file path exists $file_access_err", 109 );
        return;
    }
    local $/ = '';    # To replace the default input record separator newline(\n) with a single scalar value, to read all the lines in the file.
    my $file_content = <$fh_read>;

    # Search and fill in the empty checksum tag
    $file_content =~ s/<file_checksum\s+\/>/<file_checksum>$md5Checksum<\/file_checksum>/;
    close $fh_read;

    # Write the modified xml content to $fileName
    open( my $fh_write, '>', $xml_fileName ) or $file_access_err = $!;
    if ($file_access_err) {
        S_set_error( "WrChecksumTo_XML_File : writing data to file '$xml_fileName' not successful!, check if file path exists $file_access_err", 109 );
        return;
    }
    print $fh_write $file_content;
    S_w2log( 3, "PRD12_Read_EDR: EDR data dumped to file : $linkName \n" );
    close $fh_write;
    return 1;
}

=head

    PrepareDumpFormat2Content( $edr_DumpFileName, $serviceID, $edrByteData, $linkName );

Writes header and EDR Bytes to the Dump file for file format version 2 (.txt)  

B<Note: Not exported function>

=cut

sub PrepareDumpFormat2Content {
    my @args = @_;
    S_checkFunctionArguments( 'PrepareDumpFormat2Content( $edr_DumpFileName, $serviceID, $edrByteData, $linkName )', @args ) or return;
    my $txt_fileName = shift @args;
    my $serviceID    = shift @args;
    my $edrByteData  = shift @args;
    my $linkName     = shift @args;

    #STEP open dump file with file format 2 and write header and EDR bytes
    S_w2log( 5, "open file '$txt_fileName' \n" );
    if ( open( my $fh, '>', $txt_fileName ) ) {
        my ( $swVersion, $variantVer, $variantNum, $algoProjectID, $algoParaID ) = GetEcuPropertyForFile();
        print $fh ":2 # File Format Version.\n";
        print $fh ":" . S_get_date_extension() . "# Timestamp\n";
        print $fh ":$swVersion # Software version.\n";
        print $fh ":$variantNum # Variant number.\n";
        print $fh ":$variantVer # Variant version.\n";
        print $fh ":$algoProjectID # Algo Project ID.\n";
        print $fh ":$algoParaID # Algo Parameter ID.\n";
        print $fh ":$serviceID # Crash Entry.\n";
        print $fh $edrByteData;
        close $fh;
    }

    #STEP throw error and return if dump file cannot be written
    else {
        S_set_error( "PRD12_Read_EDR : Dumping edr data to file '$txt_fileName' not successful!, check if file path exists!", 109 );
        return;
    }
    S_w2log( 3, "PRD12_Read_EDR: EDR data dumped to file : $linkName \n" );
    return 1;

}

1;

