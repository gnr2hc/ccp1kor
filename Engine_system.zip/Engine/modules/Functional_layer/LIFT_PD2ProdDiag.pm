# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_PD2ProdDiag;

use strict;
use warnings;
use LIFT_general;
use LIFT_ProdDiag;
use Data::Dumper;

our ( $VERSION, $HEADER );

my @redefinedFunctions = qw(
  LIFT_PD::PD_BBCheck
  LIFT_PD::PD_CalculateChecksum
  LIFT_PD::PD_ClearCrashRecorder
  LIFT_PD::PD_ClearFaultMemory
  LIFT_PD::PD_ClearMemoryBits
  LIFT_PD::PD_CloseDiagnosis
  LIFT_PD::PD_Device_configuration
  LIFT_PD::PD_DumpDeviceConfiguration
  LIFT_PD::PD_DumpEEPROM
  LIFT_PD::PD_DumpRAM
  LIFT_PD::PD_DumpNVMData
  LIFT_PD::PD_WriteAllNVMSections
  LIFT_PD::PD_ECUlogin
  LIFT_PD::PD_ECUreset
  LIFT_PD::PD_EraseEEPROM
  LIFT_PD::PD_FreezeFaultMemory
  LIFT_PD::PD_Prepare_electronic_firing
  LIFT_PD::PD_Trigger_electronic_firing
  LIFT_PD::PD_GetABGeneration
  LIFT_PD::PD_GetAddressByName
  LIFT_PD::PD_GetECUStatus
  LIFT_PD::PD_GetECUMode
  LIFT_PD::PD_GetExtendedFaultInformation
  LIFT_PD::PD_GetFaultID
  LIFT_PD::PD_GetNameByAddress
  LIFT_PD::PD_InitCommunication
  LIFT_PD::PD_InitDiagnosis
  LIFT_PD::PD_InitEEPROM
  LIFT_PD::PD_ReadFaultMemory
  LIFT_PD::PD_ReadLampStates
  LIFT_PD::PD_ReadMemoryByAddress
  LIFT_PD::PD_ReadMemoryByName
  LIFT_PD::PD_SetMemoryBits
  LIFT_PD::PD_ReadMemoryBit
  LIFT_PD::PD_StartFastDiagAddress
  LIFT_PD::PD_StartFastDiagName
  LIFT_PD::PD_StopFastDiag
  LIFT_PD::PD_WriteMemoryByAddress
  LIFT_PD::PD_WriteMemoryByName
  LIFT_PD::PD_block_idle_mode
  LIFT_PD::PD_fast_fault_quali
  LIFT_PD::PD_getISOdata
  LIFT_PD::PD_getISOfaultbits
  LIFT_PD::PD_get_ECU_fingerprint
  LIFT_PD::PD_get_ECU_AlgoParameter_ID
  LIFT_PD::PD_get_FDtrace
  LIFT_PD::PD_get_device_config
  LIFT_PD::PD_get_device_index
  LIFT_PD::PD_get_last_index
  LIFT_PD::PD_get_LIFT_PD::PD_init_status
  LIFT_PD::PD_reset_PowerOnCounter
  LIFT_PD::PD_reset_PowerOnTime
  LIFT_PD::PD_wait_INI_end
  LIFT_PD::PD_ReadPasINIT2Data
  LIFT_PD::PD_send_request_wait_response
  LIFT_PD::PD_SMI7xy_verification
  LIFT_PD::PD_writeDump2ECU
  LIFT_PD::PD_DumpFLASH
  LIFT_PD::PD_Read_PowerOnTime
  LIFT_PD::PD_ReadCrashRecorder
  LIFT_PD::PD_DumpCrashRecorder
  LIFT_PD::PD_ReadNVMSection
  LIFT_PD::PD_WriteNVMSection
  LIFT_PD::PD_ManipulateFaultMemory
  PD::pd_GetSADItemDesc
  PD::pd_ReadName
);

=head1 NAME

LIFT_PD2ProdDiag 

=head1 SYNOPSIS

    use LIFT_PD;
    require LIFT_PD2ProdDiag; import LIFT_PD2ProdDiag;

This sequence of use, require and import must be given in the B<init campaign>. 

=head1 DESCRIPTION

Wrapper module that redirects all PD_* functions which access Vector hardware to LIFT_ProdDiag.
Loading of this module must be done in the B<init campaign> like shown in the SYNOPSIS.
By doing this all PD_* functions that access Vector hardware will be redirected to LIFT_ProdDiag.
This redirection is then effective in the init campaign itself and all subsequent test cases.

Use case for the usage of this module is a project that needs to use LIFT_ProdDiag because production diagnosis 
is only via flexray, but does not want to change all existing function libraries and test cases.

=head1 FUNCTIONS

B<For PD_* functions see:>

=for html
<a href='LIFT_PD.html'>LIFT_PD documentation</a>
<br><br>

The following functions are defined in this module:

    PD_InitDiagnosis
    PD_InitCommunication
    PD_ECUlogin
    PD_CloseDiagnosis
    PD_ReadFaultMemory
    PD_ClearFaultMemory
    PD_GetExtendedFaultInformation
    PD_FreezeFaultMemory
    PD_ManipulateFaultMemory
    PD_GetFaultID
    PD_ReadMemoryByName
    PD_ReadMemoryByAddress
    PD_WriteMemoryByName
    PD_WriteMemoryByAddress
    PD_GetAddressByName
    PD_ECUreset
    PD_Device_configuration
    PD_get_device_config
    PD_DumpDeviceConfiguration
    PD_get_device_index
    PD_ReadCrashRecorder
    PD_ClearCrashRecorder
    PD_StartFastDiagName
    PD_StartFastDiagAddress
    PD_StopFastDiag
    PD_get_FDtrace
    PD_GetECUStatus
    PD_GetABGeneration
    PD_GetECUMode
    PD_BBCheck
    PD_ReadLampStates
    PD_Prepare_electronic_firing
    PD_Trigger_electronic_firing
    PD_SMI7xy_verification
    PD_DumpNVMData
    PD_ReadNVMSection
    PD_WriteNVMSection
    pd_GetSADItemDesc
    pd_ReadName


B<Note:>

Calling functions which are redirected by the import function of this module, 
but which are not defined in this module will lead to the following error:

    Function LIFT_PD2ProdDiag::PD_... is not known in TurboLIFT 

This will happen if unsupported PD_* functions are called, e.g. AB10 specific functions.

=cut

#######################################
# The following import function is taken from http://www.perlmonks.org/?node_id=650045
# It redefines the caller's functions imported from elsewhere to the functions defined in this module below
#######################################
sub import {
    my $class  = shift;
    my $caller = caller;

    no strict 'refs';
    no warnings qw/redefine/;

    for my $sym (@redefinedFunctions) {

        #"unqualify" subs
        ( my $sub = $sym ) =~ s/.*:://;
        if (   ${ $caller . '::' }{$sub}
            && *{ $caller . '::' . $sub }{CODE} eq *$sym{CODE} )
        {

            *{ $caller . '::' . $sub } = \&$sub;
        }
        *{$sym} = \&$sub;
    }
    return 1;
}

#######################################
# Init and Exit
#######################################

sub PD_InitDiagnosis {

    package LIFT_PD;
    return 1;
}

sub PD_InitCommunication {

    package LIFT_PD;
    LIFT_PD::SetVariablesForUnitTest( 1, 12, 0 );
    my $testbenchDevices_href = LIFT_ProdDiag::PRD_init();
    my $ecuDetails_href       = LIFT_ProdDiag::PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_details'] } );
    my $ecu_SW_version        = $ecuDetails_href->{ECU_details}{EcuSwVersion};
    return $ecu_SW_version;
}

sub PD_ECUlogin {

    package LIFT_PD;
    my $success = LIFT_ProdDiag::PRD_ECU_Login();
    return $success;
}

sub PD_CloseDiagnosis {

    package LIFT_PD;
    my $success = LIFT_ProdDiag::PRD_exit();
    return $success;
}

#######################################
# Fault Recorder
#######################################

sub PD_ReadFaultMemory {

    package LIFT_PD;

    my $nType = shift // 1;
    my $engineTesting = shift;

    my $typeTable_href = {
        0 => 'Plant',
        1 => 'Primary',
        3 => 'Bosch',
        4 => 'Disturbance',
    };
    my $faultType        = $typeTable_href->{$nType};
    my $faultMemory_href = LIFT_ProdDiag::PRD_Read_Fault_Memory($faultType);

    $faultMemory_href = LIFT_PD2ProdDiag::SetOfflineFaults() if $main::opt_offline and $engineTesting eq 'engineTesting';

    my $faultMemory_HoA = LIFT_PD2ProdDiag::FaultMemoryHref2HoA( $faultMemory_href, $faultType );
    return $faultMemory_HoA;
}

sub PD_ClearFaultMemory {

    package LIFT_PD;

    my $localid               = shift;
    my $isWaitUntillCLTFltMem = shift;

    my $options_href;
    if ($localid) {
        $options_href->{faultType} = 'plant';
    }
    if ( defined $isWaitUntillCLTFltMem and not $isWaitUntillCLTFltMem ) {
        $options_href->{waitUntilClear} = 0;
    }

    my $success = LIFT_ProdDiag::PRD_Clear_Fault_Memory($options_href);
    return $success;
}

sub PD_GetExtendedFaultInformation {

    package LIFT_PD;

    my $nType = shift;
    my $engineTesting = shift;

    my $faultMemory_HoA = LIFT_PD2ProdDiag::PD_ReadFaultMemory($nType, $engineTesting);
    return $faultMemory_HoA;
}

sub PD_FreezeFaultMemory {

    package LIFT_PD;

    my $success = LIFT_ProdDiag::PRD_Freeze_Fault_Memory();
    return $success;
}

sub PD_ManipulateFaultMemory {

    package LIFT_PD;

    my $faultName = shift;
    my $action    = shift;

    my $manipulationConfig_href = {};

    if ( $faultName =~ /^[0|1|3|4]$/ ) {
        my $typeTable_href = {
            0 => 'Plant',
            1 => 'Primary',
            3 => 'Bosch',
            4 => 'Disturbance',
        };
        my $faultType = $typeTable_href->{$faultName};
        $manipulationConfig_href->{fault_type} = $faultType;
    }
    else {
        $manipulationConfig_href->{fault_name} = $faultName;
    }

    $manipulationConfig_href->{action} = $action;

    my $success = LIFT_ProdDiag::PRD_Manipulate_Fault_Memory($manipulationConfig_href);

    return $success;
}

sub FaultMemoryHref2HoA {
    my $faultMemory_href = shift;
    my $faultType        = shift;

    my $attributeMapping_href = {
        DTC                           => 'DTC',
        FaultID                       => 'fltnum',
        FaultName                     => 'fault_text',
        Status                        => 'state',
        EventDebug_Data_HB            => 'EventDebug_HB',
        EventDebug_Data_LB            => 'EventDebug_LB',
        Qualification_PowerOn_Cycle   => 'Qualification_poweron_cycle',
        OccurrenceCounter             => 'OccuranceCounter',
        DisturbaneceCounter           => 'DisturbanceCounter',
        QualificationTime             => 'QualificationTime',
        GeneralStatus                 => 'GeneralState',
        Dequalification_PowerOn_Cycle => 'Dequalification_poweron_cycle',
        DisturbanceStatus             => 'DisturbanceState',
        DequalificationTime           => 'DequalificationTime',
        ASIC_Temperature              => 'ASIC_Temperature',
        info                          => 'info',
        info_txt                      => 'info_txt',
        ApTime                        => 'ApTime',
        DisTime                       => 'DisTime',
        PonCnt                        => 'PonCnt',
        SpoCnt                        => 'SpoCnt',
    };

    my $stateMapping_href = {
        state_txt             => [qw(Warning_lamp_indicator Test_not_completed_this_operation_cycle Test_failed_since_last_clear Test_not_completed_since_last_clear Confirmed_DTC_Stored Pending Test_failed_this_operation_cycle_Latched Test_failed_Filtered)],
        GeneralState_text     => [qw(AlwaysCleared Squib_fired_in_the_current_POC DIS_ALP_Low_side_power_lines_disabled Algo_active VUp_OutOfRange_present VBat_OutOfRange_present InitMode_active IdleMode_active)],
        DisturbanceState_text => [qw(TestDisturbed TestCurrent)],
    };

    my $faultMemory_HoA = {};
    foreach my $hoa_attributeName ( values %{$attributeMapping_href} ) {
        $faultMemory_HoA->{$hoa_attributeName} = [];
    }
    $faultMemory_HoA->{state_txt}                  = [];
    $faultMemory_HoA->{state_txt_aref}             = [];
    $faultMemory_HoA->{GeneralState_text}          = [];
    $faultMemory_HoA->{GeneralState_text_aref}     = [];
    $faultMemory_HoA->{DisturbanceState_text}      = [];
    $faultMemory_HoA->{DisturbanceState_text_aref} = [];

    foreach my $faultIndex ( sort { $a <=> $b } keys %{$faultMemory_href} ) {
        my $faultEntry_href = $faultMemory_href->{$faultIndex};
        foreach my $attributeName ( keys %{$faultEntry_href} ) {
            my $attributeValue    = $faultEntry_href->{$attributeName};
            my $hoa_attributeName = $attributeMapping_href->{$attributeName};
            if ( defined $hoa_attributeName ) {

                # the attribute is found in attribute mapping
                $faultMemory_HoA->{$hoa_attributeName}[$faultIndex] = $attributeValue;
            }
            else {
                # the attribute is in the state mapping
                MapStateAttribute( $faultMemory_HoA, $attributeName, $attributeValue, $stateMapping_href );
            }
        }
        my $state_txt = join( '+', @{ $faultMemory_HoA->{'state_txt_aref'} } );
        $faultMemory_HoA->{state_txt}[$faultIndex] = $state_txt;
        my $generalState_text = join( '+', @{ $faultMemory_HoA->{'GeneralState_text_aref'} } );
        $faultMemory_HoA->{GeneralState_text}[$faultIndex] = $generalState_text;
        my $disturbanceState_text = join( '+', @{ $faultMemory_HoA->{'DisturbanceState_text_aref'} } );
        $faultMemory_HoA->{DisturbanceState_text}[$faultIndex] = $disturbanceState_text;

        # create and add 'EventDebug' which is not passed from dll
        if( defined $faultEntry_href->{EventDebug_Data_HB} and defined $faultEntry_href->{EventDebug_Data_LB} ) {
            my $eventDebug_join = $faultEntry_href->{EventDebug_Data_HB} . substr( $faultEntry_href->{EventDebug_Data_LB} , 2 ); # strip of leading '0x' from EventDebug_Data_LB
            $faultMemory_HoA->{EventDebug}[$faultIndex] = $eventDebug_join;
        }

        $faultMemory_HoA->{state_txt_aref}             = [];
        $faultMemory_HoA->{GeneralState_text_aref}     = [];
        $faultMemory_HoA->{DisturbanceState_text_aref} = [];

    }

    delete $faultMemory_HoA->{state_txt_aref};
    delete $faultMemory_HoA->{GeneralState_text_aref};
    delete $faultMemory_HoA->{DisturbanceState_text_aref};

    return $faultMemory_HoA;
}

sub MapStateAttribute {
    my $faultMemory_HoA   = shift;
    my $attributeName     = shift;
    my $attributeValue    = shift;
    my $stateMapping_href = shift;

    foreach my $stateType ( keys %{$stateMapping_href} ) {
        my $states_aref = $stateMapping_href->{$stateType};
        if ( grep { $attributeName eq $_ } @$states_aref ) {
            push( @{ $faultMemory_HoA->{ $stateType . '_aref' } }, $attributeName ) if $attributeValue;
        }
    }
    return 1;
}

sub SetOfflineFaults {

    my $faultMemory_href = {
        0 => {    # fault entry #0
            'Test_not_completed_this_operation_cycle'  => '0',
            'Test_failed_since_last_clear'             => '1',
            'Confirmed_DTC_Stored'                     => '1',
            'Status'                                   => '0xAF',
            'Pending'                                  => '1',
            'Warning_lamp_indicator'                   => '1',
            'FaultName'                                => 'rb_sqm_UnexpectedBT1FD_flt',
            'DTC'                                      => '0x807E55',
            'Test_failed_this_operation_cycle_Latched' => '1',
            'FaultID'                                  => '633',
            'Test_failed_Filtered'                     => '1',
            'Test_not_completed_since_last_clear'      => '0',
            'EventDebug_Data_HB'                       => '0x01',
            'EventDebug_Data_LB'                       => '0x02',
        },
        1 => {    # fault entry #1
            'Test_not_completed_this_operation_cycle'  => '1',
            'Test_failed_since_last_clear'             => '0',
            'Confirmed_DTC_Stored'                     => '1',
            'Status'                                   => '0xAE',
            'Pending'                                  => '1',
            'Warning_lamp_indicator'                   => '1',
            'FaultName'                                => 'rb_sqm_xyz_flt',
            'DTC'                                      => '0x807E56',
            'Test_failed_this_operation_cycle_Latched' => '1',
            'FaultID'                                  => '634',
            'Test_failed_Filtered'                     => '1',
            'Test_not_completed_since_last_clear'      => '0',
            'EventDebug_Data_HB'                       => '0x0A',
            'EventDebug_Data_LB'                       => '0x0B',
        },
    };

    return $faultMemory_href;
}

sub PD_GetFaultID {

    package LIFT_PD;

    my $faultName = shift;

    my $faultID = LIFT_ProdDiag::PRD_Get_Symbol_Mapping( { 'fault_name' => $faultName } );

    return $faultID;
}

#######################################
# Read / Write Memory
#######################################

sub PD_ReadMemoryByName {

    package LIFT_PD;

    my $label = shift;

    my $data_aref = LIFT_ProdDiag::PRD_Read_Memory($label);

    return $data_aref;
}

sub PD_ReadMemoryByAddress {

    package LIFT_PD;

    my $address     = shift;
    my $no_of_bytes = shift;

    my $data_aref = LIFT_ProdDiag::PRD_Read_Memory( $address, { NbrOfBytes => $no_of_bytes } );

    return $data_aref;
}

sub PD_WriteMemoryByName {

    package LIFT_PD;

    my $label      = shift;
    my $bytes_aref = shift;

    my $success = LIFT_ProdDiag::PRD_Write_Memory( $label, $bytes_aref );

    return $success;
}

sub PD_WriteMemoryByAddress {

    package LIFT_PD;

    my $address    = shift;
    my $bytes_aref = shift;

    my $success = LIFT_ProdDiag::PRD_Write_Memory( $address, $bytes_aref );

    return $success;
}

sub PD_GetAddressByName {

    package LIFT_PD;

    my $name = shift;

    my $symbolInfo_href = LIFT_ProdDiag::PRD_Get_Symbol_Mapping( { 'symbol_name' => $name } );

    my $address = $symbolInfo_href->{address};

    if ( defined $address ) {
        $address = sprintf( "0x%X", $address );
    }
    else {
        $address = '0x1';
    }

    return $address;
}

#######################################
# ECU reset
#######################################
sub PD_ECUreset {

    package LIFT_PD;

    my $reset_type = shift;

    if ( $reset_type =~ /(\w+)_reset/i ) {
        $reset_type = $1;
    }
    my $success = LIFT_ProdDiag::PRD_ECU_Reset( { resetType => $reset_type } );

    return $success;
}

#######################################
# Device Configuration
#######################################
sub PD_Device_configuration {

    package LIFT_PD;

    my $mode          = shift;
    my $devices_aref  = shift;
    my $checksum_flag = shift;
    my $resetecu_flag = shift;

    my $modeMapping_href = {
        set       => 'set_Configure',
        set_Mon   => 'set_Monitor',
        clear     => 'clear_Configure',
        clear_Mon => 'clear_Monitor',
    };

    my $mappedMode = $modeMapping_href->{$mode};

    my $devices_modes_href;
    foreach my $device (@$devices_aref) {
        $devices_modes_href->{$device} = $mappedMode;
    }

    my $options_href;
    if ( not defined $resetecu_flag or $resetecu_flag =~ /yes/i ) {
        $options_href->{resetType} = 'HARD';
    }

    my $success = LIFT_ProdDiag::PRD_Set_Device_Configuration( $devices_modes_href, $options_href );

    return $success;
}

sub PD_get_device_config {

    package LIFT_PD;

    my $label = shift;

    my $deviceConfig_href = LIFT_ProdDiag::PRD_Get_Device_Configuration();

    foreach my $deviceType ( keys %{$deviceConfig_href} ) {
        my $deviceTypeConfig_href = $deviceConfig_href->{$deviceType};
        foreach my $device ( keys %{$deviceTypeConfig_href} ) {
            my $singleDeviceConfig_href = $deviceTypeConfig_href->{$device};
            if ( $device eq $label ) {
                my $real       = $singleDeviceConfig_href->{Presence};
                my $monitored  = $singleDeviceConfig_href->{Monitored};
                my $configured = $singleDeviceConfig_href->{Configured};

                return ( $real, $monitored, $configured );
            }
        }
    }

    S_set_error( "Given device '$label' is unknown in ECU", 114 );
    return ( 0, 0, 0 );
}

sub PD_DumpDeviceConfiguration {

    package LIFT_PD;

    my $typeMapping_href = {
        SpBehaviour => 'spb',
        asics       => 'asic',
        lamps       => 'lamps',
        parSections => 'pars',
        pases       => 'pases',
        squibs      => 'squib',
        switches    => 'switches',
    };

    my $deviceConfig_href = LIFT_ProdDiag::PRD_Get_Device_Configuration();

    my $device_config_PD_href;
    foreach my $deviceType ( keys %{$deviceConfig_href} ) {
        my $deviceTypePD          = $typeMapping_href->{$deviceType};
        my $deviceTypeConfig_href = $deviceConfig_href->{$deviceType};
        foreach my $device ( keys %{$deviceTypeConfig_href} ) {
            my $singleDeviceConfig_href = $deviceTypeConfig_href->{$device};
            $device_config_PD_href->{$deviceTypePD}{Prog}{$device} = "$singleDeviceConfig_href->{Configured}";
            $device_config_PD_href->{$deviceTypePD}{Mon}{$device}  = "$singleDeviceConfig_href->{Monitored}" if defined $singleDeviceConfig_href->{Monitored};
            $device_config_PD_href->{$deviceTypePD}{Real}{$device} = "$singleDeviceConfig_href->{Presence}" if defined $singleDeviceConfig_href->{Presence};
        }
    }

    return $device_config_PD_href;
}

sub PD_get_device_index {

    package LIFT_PD;

    my $label = shift;

    my $index = LIFT_ProdDiag_AB12::PRD12_Get_Device_Property( $label );

    if( not defined $index ) {
        S_set_error( " unknown device $label", 114 );
        return 0;
    }

    return $index;
}

#######################################
# Crash Recorder
#######################################
sub PD_ReadCrashRecorder {

    package LIFT_PD;

    my $dataId   = shift;
    my $filename = shift;

    my $options_href->{date_time_in_file_name} = 0;
    $options_href->{dump_filename} = $filename if defined $filename;

    my $response_href = LIFT_ProdDiag::PRD_Read_EDR( $dataId, $options_href );
    
    if( not defined $response_href ) {
        $response_href = LIFT_ProdDiag::PRD_Get_Last_Response();
    }

    my $response_aref = $response_href->{CompletePdMsg};

    return $response_aref;
}

sub PD_ClearCrashRecorder {

    package LIFT_PD;

    my $clearEDR_Timeout_ms = shift;

    if ( not defined $clearEDR_Timeout_ms ) {

        # try to get timeout time from Project Defaults
        $clearEDR_Timeout_ms = S_get_contents_of_hash_NOERROR( [ 'TIMER', 'TIMER_CLEAR_CRASH_RECORDER' ] );
        if ( defined $clearEDR_Timeout_ms ) {
            S_w2log( 1, "PD_ClearCrashRecorder: Timeout time given in project defaults timer section : $clearEDR_Timeout_ms \n" );
        }
        else {
            $clearEDR_Timeout_ms = 10000;    # By default wait time is 10s story 29656 .
            S_w2log( 1, "PD_ClearCrashRecorder: Timeout time not given by the user : By default - 10sec \n" );
        }
    }

    my $options_href;
    $options_href->{timeout_ms} = $clearEDR_Timeout_ms;

    my $response_href = LIFT_ProdDiag::PRD_Clear_EDR($options_href);

    my $response_aref = $response_href->{CompletePdMsg};

    return ( 1, $response_aref );
}

#######################################
# Fast Diagnosis
#######################################
sub PD_StartFastDiagName {

    package LIFT_PD;

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PD_StartFastDiagName( $filename, $names_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] )', @args );

    my $filename       = shift @args;
    my $names_aref     = shift @args;
    my $types_aref     = shift @args;
    my $shifts_aref    = shift @args;
    my $numberOfCANIds = shift @args // 1;
    my $isNextPOC      = shift @args // 0;

    my $fastDiagConfig_href;

    $filename =~ s/\.(\S+)$/\//;    #removing file extension
    $fastDiagConfig_href->{csv_data_file_path} = $filename;

    if ( defined $types_aref ) {
        if ( scalar(@$types_aref) != scalar(@$names_aref) ) {
            S_set_error( "\$names_aref and \$types_aref have different size", 109 );
            return 0;
        }
        foreach my $index ( 0 .. @$names_aref - 1 ) {
            $$names_aref[$index] .= ';' . $$types_aref[$index];
        }
    }
    $fastDiagConfig_href->{labels} = $names_aref;

    $fastDiagConfig_href->{number_of_BUS_Ids} = $numberOfCANIds;
    $fastDiagConfig_href->{is_next_POC}       = $isNextPOC;

    my $csv_data_file_path = LIFT_ProdDiag::PRD_Start_Fast_Diagnosis($fastDiagConfig_href);

    my $success = 0;
    $success = 1 if defined $csv_data_file_path;

    return $success;
}

sub PD_StartFastDiagAddress {

    package LIFT_PD;

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PD_StartFastDiagAddress( $filename, $adresses_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] )', @args );

    my $filename       = shift @args;
    my $adresses_aref  = shift @args;
    my $types_aref     = shift @args;
    my $shifts_aref    = shift @args;
    my $numberOfCANIds = shift @args // 1;
    my $isNextPOC      = shift @args // 0;

    my $fastDiagConfig_href;

    $filename =~ s/\.(\S+)$/\//;    #removing file extension
    $fastDiagConfig_href->{csv_data_file_path} = $filename;

    if ( defined $types_aref ) {
        if ( scalar(@$types_aref) != scalar(@$adresses_aref) ) {
            S_set_error( "\$adresses_aref and \$types_aref have different size", 109 );
            return 0;
        }
        foreach my $index ( 0 .. @$adresses_aref - 1 ) {
            $$adresses_aref[$index] .= ';' . $$types_aref[$index];
        }
    }
    $fastDiagConfig_href->{labels} = $adresses_aref;

    $fastDiagConfig_href->{number_of_BUS_Ids} = $numberOfCANIds;
    $fastDiagConfig_href->{is_next_POC}       = $isNextPOC;

    my $csv_data_file_path = LIFT_ProdDiag::PRD_Start_Fast_Diagnosis($fastDiagConfig_href);

    my $success = 0;
    $success = 1 if defined $csv_data_file_path;

    return $success;
}

sub PD_StopFastDiag {

    package LIFT_PD;

    my $success = LIFT_ProdDiag::PRD_Stop_Fast_Diagnosis();

    return $success;

}

sub PD_get_FDtrace {

    package LIFT_PD;

    my @args = @_;

    return unless S_checkFunctionArguments( 'PD_get_FDtrace( $file_name[, $FastDiagVar_aref, $FastDiagType_aref, $time_unit] )', @args );
    my $filename          = shift @args;
    my $fastDiagVar_aref  = shift @args;
    my $fastDiagType_aref = shift @args;
    my $time_unit         = shift @args;

    my $options_href;

    $filename =~ s/\.(\S+)$/\//;    #removing file extension
    $options_href->{data_path} = $filename;

    my $fdData_href = LIFT_ProdDiag::PRD_Get_Fast_Diagnosis_Data($options_href);

    return $fdData_href;
}

#######################################
# ECU properties
#######################################
sub PD_GetECUStatus {

    package LIFT_PD;

    my $ecuProperties_href = LIFT_ProdDiag::PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_status'] } );

    my $fault_memory_status      = $ecuProperties_href->{ECU_status}{Fault_memory_status};
    my $edr_status               = $ecuProperties_href->{ECU_status}{EDR_status};
    my $data_flash_status        = $ecuProperties_href->{ECU_status}{Data_flash_status};
    my $electronic_firing_status = $ecuProperties_href->{ECU_status}{Electronic_firing_status};

    return [ $fault_memory_status, $edr_status, $data_flash_status, $electronic_firing_status, 0 ];
}

sub PD_GetABGeneration {

    package LIFT_PD;

    my $ecuProperties_href = LIFT_ProdDiag::PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_details'] } );

    my $abGeneration = $ecuProperties_href->{ECU_details}{EcuGeneration};

    return $abGeneration;
}

sub PD_GetECUMode {

    package LIFT_PD;

    my $ecuProperties_href = LIFT_ProdDiag::PRD_Get_ECU_Properties( { 'Property_names' => ['ECU_status'] } );

    my $ecuMode = $ecuProperties_href->{ECU_status}{ECU_mode};

    return $ecuMode;

}

sub PD_BBCheck {

    package LIFT_PD;

    my $success = LIFT_ProdDiag::PRD_Check_ECU_Properties( { EcuSwVersion => 'ROMCODE', action_on_mismatch => 'error' } );

    return $success;
}

sub PD_ReadLampStates {

    package LIFT_PD;

    my $ecuProperties_href = LIFT_ProdDiag::PRD_Get_ECU_Properties( { 'Property_names' => ['Lamp_status'] } );

    my $lampStatus_href   = $ecuProperties_href->{Lamp_status};
    my $systemWarningLamp = $lampStatus_href->{SystemWarningLamp};
    delete $lampStatus_href->{SystemWarningLamp};
    $lampStatus_href->{"System Warning Lamp"} = $systemWarningLamp;

    return $lampStatus_href;
}

#######################################
# Electronic Firing
#######################################
sub PD_Prepare_electronic_firing {

    package LIFT_PD;

    my $success = LIFT_ProdDiag::PRD_Electronic_Firing_Enable();

    return $success;
}

sub PD_Trigger_electronic_firing {

    package LIFT_PD;

    my $firingStatus_href = LIFT_ProdDiag::PRD_Electronic_Firing_Fire();

    my $status = $firingStatus_href->{response_href}{Status};

    my $success = 1;
    $success = 0 if $status < 0;

    return $success;
}

#######################################
# Sensor
#######################################
sub PD_SMI7xy_verification {

    package LIFT_PD;

    my $sMI7xy_config_href = shift;

    $sMI7xy_config_href->{sensor_type} = 'SMI7';

    my $sensorData_href = LIFT_ProdDiag::PRD_Sensor_Verification($sMI7xy_config_href);

    my $responsePayload_aref = $sensorData_href->{response_href}{PdPayload};

    return $responsePayload_aref;
}

#######################################
# Dump memory to file
#######################################
sub PD_DumpNVMData {

    package LIFT_PD;

    my $dumpfile = shift;

    my $options_href;
    $options_href->{file_name} = $dumpfile if defined $dumpfile;

    my $filename = LIFT_ProdDiag::PRD_Dump_Memory_To_File( 'NVM', $options_href );

    my $success = 0;
    $success = 1 if defined $filename;

    return $success;
}

#######################################
# NVM
#######################################
sub PD_ReadNVMSection {

    package LIFT_PD;

    my $sectionName = shift;

    my $nvmConfig_href = { block_name => $sectionName };

    my $nvmContents_aref = LIFT_ProdDiag::PRD_Read_ECU_NVM($nvmConfig_href);

    if ( not defined $nvmContents_aref ) {
        return [];
    }

    # convert all bytes to hex because the original PD function does it like that
    my @nvmContentsHex = map { sprintf( "%02X", $_ ) } @$nvmContents_aref;

    return \@nvmContentsHex;
}

sub PD_WriteNVMSection {

    package LIFT_PD;

    my $sectionName = shift;
	my $hexStrings_aref = shift;

    my $nvmConfig_href = { block_name => $sectionName };

    # convert all hex strings to bytes because the original PD function does it like that
    my @integers = map { hex($_) } @$hexStrings_aref;

    my $success = LIFT_ProdDiag::PRD_Write_ECU_NVM($nvmConfig_href, \@integers);

    if( not $success ) {
        return 0;
    }

    return 1;
}

#######################################
# low level functions
#######################################
sub pd_GetSADItemDesc {

    package PD;

    my $name = shift;

    my $symbolInfo_href = LIFT_ProdDiag::PRD_Get_Symbol_Mapping( { 'symbol_name' => $name } );

    my $description  = $symbolInfo_href->{description};
    my $enum_or_mask = $symbolInfo_href->{enum_or_mask};

    my $status;
    if ( defined $description ) {
        if ( length $description > 0 ) {
            if ( length $enum_or_mask > 0 ) {
                $status = 2;
            }
            else {
                $status = 1;
            }
        }
        else {
            $status = 0;
        }
    }
    else {
        $status      = -20;
        $description = '';
    }

    return ( $status, $description, 8 );
}

sub pd_ReadName {

    package PD;

    my $label = shift;

    my $data_aref = LIFT_ProdDiag::PRD_Read_Memory($label);

    my $status;
    if ( defined $data_aref ) {
        $status = 0;
    }
    else {
        $status    = -1;
        $data_aref = [];
    }

    return ( $status, $data_aref );
}

1;
