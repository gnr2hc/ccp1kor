# *****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_PD;

use strict;
use warnings;
use LIFT_general;
use Win32::Process;    # for killing WinDiag
use File::Basename;
use File::Path 'make_path';
use GD::Graph::linespoints;
use LIFT_CD_CAN;
use Readonly;
use Data::Dumper;
use POSIX;
use Math::BigInt;
use Math::BigFloat;
use HTML::Table;
use List::Util 'sum';
my $addpath;

BEGIN
{
    use File::Spec;
    use LIFT_general;
    S_add_paths2INC(['../Device_layer/PD', '../Device_layer/PD/Win32'], ['../Device_layer/PD/Win32']);

    # $addpath will be used later in the code, so we have to keep it
    $addpath = File::Spec->rel2abs( dirname(__FILE__) ) . "/../Device_layer/PD";
    $addpath =~ s/\//\\/g;    # replace all slashes with backslahes
}

use PD;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_PD ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  PD_BBCheck
  PD_CalculateChecksum
  PD_ClearCrashRecorder
  PD_ClearFaultMemory
  PD_ClearMemoryBits
  PD_CloseDiagnosis
  PD_Device_configuration
  PD_DumpDeviceConfiguration
  PD_DumpFaultMemoryTable
  PD_DumpEEPROM
  PD_DumpRAM
  PD_DumpNVMData
  PD_WriteAllNVMSections
  PD_ECUlogin
  PD_ECUreset
  PD_EraseEEPROM
  PD_FreezeFaultMemory
  PD_Prepare_electronic_firing
  PD_Trigger_electronic_firing
  PD_GetABGeneration
  PD_GetAddressByName
  PD_GetECUStatus
  PD_GetECUMode
  PD_GetExtendedFaultInformation
  PD_GetFaultAttribute
  PD_GetFaultID
  PD_GetNameByAddress
  PD_InitCommunication
  PD_InitDiagnosis
  PD_InitEEPROM
  PD_ReadFaultMemory
  PD_ReadLampStates
  PD_ReadMemoryByAddress
  PD_ReadMemoryByName
  PD_SetMemoryBits
  PD_ReadMemoryBit
  PD_StartFastDiagAddress
  PD_StartFastDiagName
  PD_StopFastDiag
  PD_WriteMemoryByAddress
  PD_WriteMemoryByName
  PD_block_idle_mode
  PD_check_fault_exists
  PD_check_fault_status
  PD_count_fault
  PD_evaluate_faults
  PD_fast_fault_quali
  PD_getISOdata
  PD_getISOfaultbits
  PD_get_ECU_fingerprint
  PD_get_ECU_AlgoParameter_ID
  PD_get_FDtrace
  PD_get_fault_index
  PD_get_fault_info
  PD_get_fault_status
  PD_get_faults
  PD_get_device_config
  PD_get_device_index
  PD_get_last_index
  PD_get_PD_init_status
  PD_get_type_from_name
  PD_plot_FDtrace
  PD_reset_PowerOnCounter
  PD_reset_PowerOnTime
  PD_wait_INI_end
  PD_ReadPasINIT2Data
  PD_send_request_wait_response
  PD_SMI7xy_verification
  PD_writeDump2ECU
  PD_DumpFLASH
  PD_Read_PowerOnTime
  PD_ReadCrashRecorder
  PD_DumpCrashRecorder
  PD_ReadNVMSection
  PD_WriteNVMSection
  PD_ManipulateFaultMemory
    
  PLANT_FLT_MEM
  PRIMARY_FLT_MEM
  BOSCH_FLT_MEM
  DISTURBANCE_FLT_MEM
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_PD 

Perl extension for Production Diagnosis

=head1 SYNOPSIS

    use LIFT_PD;

    PD_InitDiagnosis();
    $SWversion = PD_InitCommunication();
    
    $check_status = PD_BBCheck();
    $ABgeneration = PD_GetABGeneration();
    PD_ECUreset();
    PD_ECUlogin();
    $response_aref = PD_GetECUStatus();
    $response_aref = PD_send_request_wait_response([0x04,0x18,0xAB,0x12,0xD9]);
    $PD_init_status = PD_get_PD_init_status();


    $fault_HoA = PD_ReadFaultMemory();
    PD_ClearFaultMemory();
    PD_FreezeFaultMemory();
    $fault_HoA = PD_GetExtendedFaultInformation();
    PD_DumpFaultMemoryTable($fault_HoA);
    PD_check_fault_exists( $fault_HoA, 'FltVbatLow' );
    $status = PD_get_fault_status( $fault_HoA, 'FltVbatLow' );
    PD_check_fault_status( $fault_HoA, 'FltVbatLow', '0bxxxxx111' );
    $count = PD_count_fault( $fault_HoA, 'FltVbatLow' );
    $FaultID = PD_GetFaultID( 'FltAB1FDResistanceOpen' );
    PD_fast_fault_quali( "ENABLE" );
    (188, 23, 4,"0bxxx0xxxx", "0bxxx1xxxx" ) = PD_getISOdata("FltAB1FDResistanceOpen");
    0b00101100 = PD_getISOfaultbits("FltAB1FDResistanceOpen");
    $VERDICT = PD_evaluate_faults( $fault_HoA, ['FltVbatLow']);
    $index = PD_get_fault_index( $fault_HoA, 'FltVbatLow' );
    $info = PD_get_fault_info( $fault_HoA, 'FltVbatLow');
    $string = PD_get_faults( $fault_HoA );


    PD_StartFastDiagAddress( $main::REPORT_PATH."/FD1.txt" , ['FEDFD915'] , ['S16']);
    PD_StartFastDiagName( $main::REPORT_PATH."/FD1.txt" , ['A_AccEcuChannel_S16R(0)'] , ['S16']);
    PD_StopFastDiag();
    my $data_HoH = PD_get_FDtrace( "$log_path/FastDiagTrace.txt" );
    PD_plot_FDtrace( $data_HoH, "$log_path/FastDiagTracePic");

    PD_Device_configuration( 'clear', ['UFSL','AB1FD','FLIC'] );
    $device_data_href = PD_DumpDeviceConfiguration();
    ($Real,$Monitored_ID,$Prog) = PD_get_device_config('AB1FD');
    $index = PD_get_device_index( 'AB1FD' );
    PD_CalculateChecksum( 'PROG_VAR_TBL', 'ASIC_CONF_TBL' );


    PD_ClearCrashRecorder();
    $response_aref = PD_ReadCrashRecorder(0x00);


    PD_Prepare_electronic_firing( ['AB1FD','AB2FD'] );
    PD_Trigger_electronic_firing();


    $response_aref = PD_SMI7xy_verification( $sMI7xy_config_href );


    ( $stat, $address ) = pd_GetAddressByName('V_BlockIdleMode_U16E');
    $name = PD_GetNameByAddress( 0x8005FD8 );
    $value_aref = PD_ReadMemoryByAddress( '0x20400001', 1 );
    $value_aref = PD_ReadMemoryByName('rb_res_IllegalEventData_dfst');
    PD_SetMemoryBits('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X',['Fault Quali Time','Suppress CAN Faults']);
    $membitval = PD_ReadMemoryBit('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X','Fault Quali Time');
    $membitval = PD_ReadMemoryBit('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X','2');
    PD_ClearMemoryBits('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X',['Fault Quali Time','Suppress CAN Faults']);
    PD_WriteMemoryByAddress( '0x20400001',[5,8] );
    PD_WriteMemoryByName( 'V_IdleFaultNbr_U16R', [12,34] );
    PD_InitEEPROM( "$log_path/bb63962_eeprom.hex", 'Reset' );
    PD_DumpEEPROM( "$log_path/EE.hex" );
    PD_EraseEEPROM();
    PD_DumpFLASH( "$log_path/Flash.hex"  );
    PD_DumpRAM( "$log_path/RAM.hex" );
    $status = PD_writeDump2ECU( "$log_path/EE.hex" );
    $value_aref = PD_ReadLampStates();
    PD_block_idle_mode();
    PD_reset_PowerOnCounter();
    PD_reset_PowerOnTime();
    $dec_value = PD_Read_PowerOnTime();
    PD_wait_INI_end();
    $aref=PD_ReadPasINIT2Data('UFSD');
    $value = PD_get_last_index( 'A_EEMgrJobTable_XSR(0).A_EEData_U8X' );
    $value = PD_get_type_from_name( 'A_AccEcuChannel_S16R(2)' );

    PD_CloseDiagnosis();

=head1 PREREQUISITES

=over 3

=item * .sad, .flt, .cns, .nvm files corresponding to the specific checkpoint of ECU SW must be in the folder defined by $SAD_file in the main configuration file (..._CFG.pm)

=item * The correct CAN Type must be defined either in project constants (recommended) or in the used .sad-file (usually wrong by default):

B<Define in Project constants (recommended): e.g.>

    'SADCONFIG' => {
        'CAN_Type' => 'BOSCH_CAN_03',  # <-- IMPORTANT
        #'CPU_Type' => 'NECV850',       # is usually correct in the .sad file
        #'SG_Type'  => 'AB12.0'         # is usually correct in the .sad file
    }

When the above config items are defined then the corresponding values from the .sad file are ignored.
So continuous editing of SAD file for every SW checkpoint can be avoided. 

B<edit in .sad file (not recommended): e.g.>

    CAN Type            : BOSCH_CAN_03
    
B<Check if the CAN Type exists in the CAN parameter definition file:>

    For AB12: Engine\modules\DLLs\PD\Win32\PSDiag_CAN_Parameter.txt
    e.g. 
    CANTyp_BOSCH_CAN_03=7A120,C,3,3,1,650,651,652,653,654,AB12_BASE,High Speed 251

    For AB10: Engine\modules\DLLs\PD\CAN_parameter.txt file.
    e.g.
    CANTyp_BOSCH_CAN_02=7A120,C,3,3,1,64C,509,AB10_BASE,High Speed 251

=back

=head1 CONFIGURATION

=head2 Main configuration file (..._CFG.pm)

Define the path to .sad, .flt, .cns, .nvm files in $SAD_file:

    ### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ### replace path with SAD file for current ECU SW under test
    our $SAD_file = "$LIFT_PRJCFG_path/SW/dummy_sad_file.sad";
    ###
    ### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

=head2 Project Configuration (..._ProjectConst.pm)

Define the correct CAN Type for your project (see L</PREREQUISITES> above) in 'SADCONFIG', e.g.:

    'SADCONFIG' => {
        'CAN_Type' => 'BOSCH_CAN_03',  # <-- IMPORTANT
        #'CPU_Type' => 'NECV850',       # is usually correct in the .sad file
        #'SG_Type'  => 'AB12.0'         # is usually correct in the .sad file
    }
    
Define a device mapping for all project devices in 'DEVICE_CONFIG'. For AB12 usually left side = right side.

Note: On each call of PD_InitCommunication a file ..._devicemapping.txt will be generated in the config folder of the project 
that contains the complete 'DEVICE_CONFIG' section of your project. 
The contents of this file should be copied once to your ..._ProjectConst.pm file.

    'DEVICE_CONFIG' => {
    	#Squibs
    	'AB1FD'   	=> 'AB1FD',
    	'AV1FD'   	=> 'AV1FD',
    	...
    	#Switches
    	'BLFD'  => 'BLFD',
    	'BLFP'  => 'BLFP',
    	...
        ...
    },

Squibs, pases, switches and asics are read from predefined enums in the .cns file 
and can be configured in the ECU using predefined variables in the .sad file (function PD_Device_configuration).
If required the predefined variables can be overwritten by defining the following section in ..._ProjectConst.pm.
If this section does not exist then the default values as shown below will be used.

Note: Donot use RAM variables for configuring this section as the values will not be reflected in Data flash or NVM.

e.g: for 'squibs'=>{'configured' => 'rb_sycf_SysConfSquib_B<st>.SquibConfigured_ab8',} ) ( _st ) indicates the RAM variable, and should not be used to configure/unconfigue or to enable/disable monitoring devices


    'DEVICE_CONFIG_VARIABLES' => {
        '10' => {},    # end of '10'
        '12' => {
            'lamps' => {
                'enum'       => 'rb_syco_AOuts_ten',
                'monitored'  => 'rb_syco_SysConfAOutEeData_dfst.AoutMonitored_ab8',
                'real'       => 'rb_syco_AOutPresence_ab8',
                'configured' => 'rb_syco_SysConfAOutEeData_dfst.AoutConfigured_ab8',
            },
            'squibs' => {
                'enum'       => 'rb_sycf_SquibDevice_ten',
                'monitored'  => 'rb_sycf_SysConfSquib_dfst.SquibMonitored_ab8',
                'real'       => 'rb_sycf_SquibPresence_ab8',
                'configured' => 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8',
            },
            'SpBehaviour' => {
                'enum'       => 'rb_sycg_StaticBitPositions_ten',
                'configured' => 'rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8',
            },
            'parSections' => {
                'enum'       => 'rb_sycg_DynamicBitPositions_ten',
                'configured' => 'rb_sycg_DynamicBehaviorBits_dfst.rb_sycg_DynamicBits_ab8',
            },
            'pases' => {
                'enum'       => 'rb_sycp_SensorChannels_ten',
                'monitored'  => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelMonitored_ab8',
                'real'       => 'rb_sycp_PsPresence_ab8',
                'configured' => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelConfigured_ab8',
            },
            'switches' => {
                'enum'       => 'rb_sycs_SwitchDevices_ten',
                'monitored'  => 'rb_sycs_SysConfSwmEeData_dfst.SwitchMonitored_ab8',
                'real'       => 'rb_sycs_SwitchPresence_ab8',
                'configured' => 'rb_sycs_SysConfSwmEeData_dfst.SwitchConfigured_ab8',
            },
            'asics' => {
                'enum'       => 'rb_syca_AllAsics_ten',
                'real'       => 'rb_syca_AsicPresence_ab8',
                'configured' => 'rb_syca_SysConfAsicEeData_dfst.AsicConfigured_ab8',
                'id'         => 'rb_syca_AsicDeviceId_au16',
            },
        },    # end of '12'
    },    # end of 'DEVICE_CONFIG_VARIABLES'

By default on PD_InitCommunication the ECU fingerprint and the ECU Algo parameter ID are read. 
If those numbers are not defined in a project then reading can be suppressed by defining the following section:

    'PD' => {
        'PD_InitCommunication' => {
            'PD_get_ECU_fingerprint'      => 0,
            'PD_get_ECU_AlgoParameter_ID' => 0,
        },
    },
    
Only used for the function PD_wait_INI_end:

    'PRODUCTION_DIAGNOSIS' => {
        'INIEND_TIMEOUT' => 10,
        'INIEND_LABEL' => 'V_ITMTestExecutedStatus_U32R',
    },
    
Only used for AB10 for CRC calculation:

    'CRC_AREA' => {
        'PROG_VAR_TBL' => 1,
        'ASIC_CONF_TBL' => 4,
        'PAR_SEC_TBL'   => 0,
    },

=head2 Testbench Configuration (LIFT_Testbenches.pm)

    'Devices' => {
        ...
        'PD' =>
        {
            'CANchannel' => 1,
            'CANHWSerialNo'  => 30679,
        },
        ...
    },
    'Functions' => {
        ...
        'PD' => 'PD',          # only device PD is currently possible
        ...
    },

The entry under 'Functions' looks trivial, but it is required if EQUIP_init_testbench is to initialize PD.

B<Important Note about CANchannel:> 

For B<AB12> Please follow below link for configuring CANChannel.

=for html
<a href='https://connect.bosch.com/blogs/95fa69ff-a587-4120-acbe-3b2f0cdd4ef7/entry/PSDiag_V_3_15_2_and_TurboLIFT?lang=en_us'>Configure CANChannel</a> 


For B<AB10> only CAN channels with transceiver are counted, e.g. if on a VN89xx channel 1 = FlexRay, channel 2 = CAN, 
then VN89xx channel 2 is CANchannel 1.

Always check if the numbering has changed if you connect additional CAN hardware.

=head2 Execution Options (LIFT_ExecOptions.pm)

The following are the existing execution options that can be used.

B<PD_ClearFaultMemory_using_ManipulateFaultMemory:> Please refer L</"PD_ClearFaultMemory"> for the use.

=head1 DESCRIPTION

This module contains all kinds of functions for performing production diagnosis tasks.
The functions are sorted into the following function groups:

    'base'      : init, status, login, reset, etc.
    'fault'     : fault memory reading and handling
    'fast_diag' : fast diagnosis recording and getting data
    'device'    : device configuration setting and checking
    'edr'       : crash recorder reading, clearing and dumping
    'firing'    : electronic firing preparing and triggering
    'smi7xy'    : smi7xy verification service
    'memory'    : ECU memory reading, writing and dumping

In the TurboLIFT layer architecture LIFT_PD is a functional module.

See the documentation of the individual functions for more detail.

=cut

=head2 Fault Status Byte - Bit Description

=head3 AB12 Fault Bits Description

B<ISO Fault Bits>

    Bit 0: Test Failed (Filtered)
    Bit 1: Test Failed This Operation Cycle (Latched)
    Bit 2: Pending
    Bit 3: Confirmed DTC (Stored)
    Bit 4: Test Not Completed Since Last Clear
    Bit 5: Test Failed Since Last Clear
    Bit 6: Test Not Completed This Operation Cycle
    Bit 7: Warning Lamp Indicator


B<General Status Fault Bits ( reported in Bosch fault memory and Disturbance fault memory )>

    Bit0: Set if IdleMode active
    Bit1: Set if InitMode active
    Bit2: Set if VBat OutOfRange present
    Bit3: Set if VUp OutOfRange present
    Bit4: Set if Algo active
    Bit5: Set if DIS_ALP (Low side power lines) disabled
    Bit6: Set if Squib fired in the current POC
    Bit7: n/a (always cleared)


B<Disturbance Status Fault Bits>

    Bit0: TestCurrent
    Bit1: TestDisturbed
    Bit2 to 7: not used

=head3 AB10 Fault Bits Description

    Bit 0: Filtered
    Bit 1: Latched
    Bit 2: Stored
    Bit 3: Current
    Bit 4: Active
    Bit 5: Disturb
    Bit 6: not used
    Bit 7: not used

=cut

=head4 Fast Diagnosis information
	
	'FAST_DIAG_INFO' => {
		
		'CAN ID' => { 'Nbr_Of_bytes' => { 'Multiplex' => 'Value', 'Resolution' => 'Value', 'Nbr_frames' => 'Value' },
	},
};

=cut    

######################################################################################################################
# Datastructures and variables used  across different functions in LIFT_PD
#######################################################################################################################

my ( $stat, %last_index, $device_conf_tbl, %SW_index, %PAS_index, %SQ_index, %ASIC_index, %WL_index, %CUST_index, %SPB_index, %parSEC_index, $ELFenabled, @squibs, @pases, @switches, @lamps, @cust, @asics, @lampstates, @SpBehaviour, @parSections, );

my %flt_mem_keys = (    #keyvalue  #mandatory(1)/optional(0)
                     "fltnum"     => 1,
                     "fault_text" => 1,
                     "DTC"        => 1,
                     "state"      => 1,
                     "state_txt"  => 1,
                     "info"       => 1,
                     "info_txt"   => 1,
                     "ApTime"     => 0,
                     "DisTime"    => 0,
                     "PonCnt"     => 0,
                     "SpoCnt"     => 0,
);

my $pdConfig_href = {
    'DEVICE_CONFIG_VARIABLES' => {

        '10' => {
                  'asics' => {
                               'enum'       => 'E_MaxAsics_SXC',
                               'configured' => 'S_PDMASICDevice_XXE.A_AsicDev_U8X',
                               'real'       => 'S_PDMASICDevice_XXR.A_AsicDev_U8X',
                               'id'         => 'S_PDMASICDevice_XXE.A_ASICDeviceList_U8X',
                  },
                  'squibs' => {
                                'enum'       => 'E_MaxSquibs_SXC',
                                'monitored'  => 'S_PDMProgVarTbl1_XXE.A_ExtDevMon_U8X',
                                'configured' => 'S_PDMProgVarTbl1_XXE.A_ExtDevConf_U8X',
                                'real'       => 'S_PDMExtDevPresenceTbl_XXR.A_ExtDev_U8X',
                  },
                  'SpBehaviour' => {
                                     'enum'       => 'E_MaxSpecialBehaviours_SXC',
                                     'configured' => 'S_PDMProgVarTbl1_XXE.A_SpecialBTable_U8X',
                  },
                  'parSections' => {
                                     'enum'       => 'E_MaxParSections_SXC',
                                     'configured' => 'S_PDMSectionActivator_XXE.A_LoadSection_U8X',
                  },
                  'pases' => {
                               'enum' => 'E_MaxPASensors_SXC',
                  },
                  'switches' => {
                                  'enum' => 'E_MaxSwitchDevices_SXC',
                  },
                  'lamps' => {
                               'enum' => 'E_MaxWLDevice_SXC',
                  },
                  'cust' => {
                              'enum' => 'E_MaxCustDevice_SXC',
                  },
        },    # end of '10'
        '12' => {
                  'lamps' => {
                               'enum'       => 'rb_syco_AOuts_ten',
                               'monitored'  => 'rb_syco_SysConfAOutEeData_dfst.AoutMonitored_ab8',
                               'real'       => 'rb_syco_AOutPresence_ab8',
                               'configured' => 'rb_syco_SysConfAOutEeData_dfst.AoutConfigured_ab8',
                  },
                  'squibs' => {
                                'enum'       => 'rb_sycf_SquibDevice_ten',
                                'monitored'  => 'rb_sycf_SysConfSquib_dfst.SquibMonitored_ab8',
                                'real'       => 'rb_sycf_SquibPresence_ab8',
                                'configured' => 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8',
                  },
                  'SpBehaviour' => {
                                     'enum'       => 'rb_sycg_StaticBitPositions_ten',
                                     'configured' => 'rb_sycg_StaticBehaviorBits_dfst.rb_sycg_StaticBits_ab8',
                  },
                  'parSections' => {
                                     'enum'       => 'rb_sycg_DynamicBitPositions_ten',
                                     'configured' => 'rb_sycg_DynamicBehaviorBits_dfst.rb_sycg_DynamicBits_ab8',
                  },
                   'pases' => {
                               'enum'       => 'rb_sycp_SensorChannels_ten',
                               'monitored'  => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelMonitored_ab8',
                               'real'       => 'rb_sycp_PsPresence_ab8',
                               'configured' => 'rb_sycp_SysConfPsNvmCfgData_dfst.ChannelConfigured_ab8',
                  },
                  'switches' => {
                                  'enum'       => 'rb_sycs_SwitchDevices_ten',
                                  'monitored'  => 'rb_sycs_SysConfSwmEeData_dfst.SwitchMonitored_ab8',
                                  'real'       => 'rb_sycs_SwitchPresence_ab8',
                                  'configured' => 'rb_sycs_SysConfSwmEeData_dfst.SwitchConfigured_ab8',
                  },
                  'asics' => {
                               'enum'       => 'rb_syca_AllAsics_ten',
                               'real'       => 'rb_syca_AsicPresence_ab8',
                               'configured' => 'rb_syca_SysConfAsicEeData_dfst.AsicConfigured_ab8',
                               'id'         => 'rb_syca_AsicDeviceId_au16',
                  },
        },    # end of '12'
    },    # end of 'DEVICE_CONFIG_VARIABLES'
};

# 'CAN ID' => { 'Nbr_Of_bytes' => { 'Multiplex' => <Value>, 'Resolution' => <Value>, 'Nbr_frames' => <Value> },
#  For detailed information about Fast Diagnnosis trace refer "doors://si-airbag-doors.de.bosch.com:36681/?version=2&prodID=0&view=00000006&urn=urn:telelogic::1-0000000000000000-M-0003ea7f"
#  and https://si-airbag-doors-dwa.de.bosch.com:8443/dwa/rm/urn:rational::1-0000000000000000-M-00045f20?doors.view=00000001
my $fast_diag_info_href = {
	'FAST_DIAG_INFO' => {

		1 => {
			   1  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 1 },
			   2  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 1 },
			   3  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 1 },
			   4  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 1 },
			   5  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 1 },
			   6  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 1 },
			   7  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 1 },
			   8  => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   9  => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   10 => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   11 => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   12 => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   13 => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   14 => { 'Multiplex' => 'Y', 'Resolution' => 4,   'Nbr_frames' => 2 },
			   15 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   16 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   17 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   18 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   19 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   20 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   21 => { 'Multiplex' => 'Y', 'Resolution' => 6,   'Nbr_frames' => 3 },
			   22 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   23 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   24 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   25 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   26 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   27 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
			   28 => { 'Multiplex' => 'Y', 'Resolution' => 8,   'Nbr_frames' => 4 },
		},
		2 => {
			   2  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 2 },
			   3  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 2 },
			   4  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 2 },
			   5  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 2 },
			   6  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 2 },
			   7  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 2 },
			   8  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   9  => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   10 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   11 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   12 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   13 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
			   14 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 2 },
		},
		3 => {
			   4  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 3 },
			   5  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 3 },
			   6  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 3 },
			   7  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 3 },
			   8  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 3 },
			   9  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 3 },
			   10 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 3 },
			   11 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   12 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   13 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   14 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   15 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   16 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   17 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   18 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   19 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   20 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
			   21 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 3 },
		},
		4 => {
			   6  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 4 },
			   7  => { 'Multiplex' => 'N', 'Resolution' => 0.5, 'Nbr_frames' => 4 },
			   8  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   9  => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   10 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   11 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   12 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   13 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   14 => { 'Multiplex' => 'N', 'Resolution' => 1,   'Nbr_frames' => 4 },
			   15 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   16 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   17 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   18 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   19 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   20 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   21 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   22 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   23 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   24 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   25 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   26 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   27 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
			   28 => { 'Multiplex' => 'N', 'Resolution' => 2,   'Nbr_frames' => 4 },
		},
	},
};


my %ECU_SWInfo = ();    #Holds the details which read from ECU
my $RomCode;            #ROMCode for BB checking
my $module_name    = __PACKAGE__;
my $max_pathlength = 255;

my $PD_initialized = 0;    # set by PD_InitDiagnosis / PD_CloseDiagnosis; can be checked with PD_get_PD_init_status
my $FastDiagActive = 0;

our ( $ABgeneration, $CNSfile );
our $Motorola_format;

my $nvmData_href = {};
my $nvmFile_readflag = 0;
#Constant variables used in whole module
use constant PLANT_FLT_MEM       => 0;
use constant PRIMARY_FLT_MEM     => 1;
use constant BOSCH_FLT_MEM       => 3;
use constant DISTURBANCE_FLT_MEM => 4;

#Global variables used for fault memory
#Bit7 Bit6 ... Bit 0 of ISO state in Plant and Primary fault memory location
my %iso_statenames = (
                       'Bit7' => 'Warning_lamp_indicator',
                       'Bit6' => 'Test_not_completed_this_operation_cycle',
                       'Bit5' => 'Test_failed_since_last_clear',
                       'Bit4' => 'Test_not_completed_since_last_clear',
                       'Bit3' => 'Confirmed_DTC_Stored',
                       'Bit2' => 'Pending',
                       'Bit1' => 'Test_failed_this_operation_cycle_Latched',
                       'Bit0' => 'Test_failed_Filtered'
);

#Bit7 Bit6 ... Bit 0 of General state in Bosch fault memory location
my %bfm_gen_statenames = (
                           'Bit6' => 'Squib_fired_in_the_current_POC',
                           'Bit5' => 'DIS_ALP_Low_side_power_lines_disabled',
                           'Bit4' => 'Algo_active',
                           'Bit3' => 'VUp_OutOfRange_present',
                           'Bit2' => 'VBat_OutOfRange_present',
                           'Bit1' => 'InitMode_active',
                           'Bit0' => 'IdleMode_active'
);

#Bit7 Bit6 ... Bit 1 are always 0 and Bit 0 any of given below of ISO state in Bosch fault memory location
my %bfm_iso_statenames = (
                           'Bit0_1' => 'Test_Failed',
                           'Bit0_2' => 'Test_not_Failed'
);

#Bit7 Bit6 ... Bit 0 of General state in Disturbance fault memory location
my %dfm_gen_statenames = (
                           'Bit6' => 'Squib_fired_in_the_current_POC',
                           'Bit5' => 'DIS_ALP_Low_side_power_lines_disabled',
                           'Bit4' => 'Algo_active',
                           'Bit3' => 'VUp_OutOfRange_present',
                           'Bit2' => 'VBat_OutOfRange_present',
                           'Bit1' => 'InitMode_active',
                           'Bit0' => 'IdleMode_active'
);

#Bit7 Bit6 ... Bit 2 are always 0. Bit1 and Bito are given below of Disturbance state in Disturbance fault memory location
my %dfm_dist_statenames = (
                            'Bit1' => 'TestDisturbed',
                            'Bit0' => 'TestCurrent'
);

#BFM Extra params
my @BFM_extra_data = ( 'EventDebug_Data_HB', 'EventDebug_Data_LB', 'OccurrenceCounter', 'QualificationTime', 'DequalificationTime', 'Qualification_PowerOn_Cycle', 'Dequalification_PowerOn_Cycle','ASIC_Temperature' );

#DFM Extra params
my @DFM_extra_data = ( 'EventDebug_Data_HB', 'EventDebug_Data_LB', 'DisturbaneceCounter' );

######################################################################################################################
# Definition of functions in LIFT_PD
#######################################################################################################################

=head1 Function Group 'base'

=head2 PD_BBCheck

    PD_BBCheck();

This function performs the BB number checking from SAD file to ECU version.

Sets an error message if the number is not same in both SAD file and ECU version and returns 0.

offline/success return :: 1

error return :: 0

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_BBCheck
{
    my ( @ECU_Version_data, $ECU_version );
    my ( $BB_number,        @romcode_data );

    S_w2log( 5, "PD_BBCheck: checks the BB number is same in ECU and loaded SAD file \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $BB_number   = $RomCode;
    $ECU_version = $ECU_SWInfo{'SW Version'};

    unless ( $BB_number eq $ECU_version )
    {
        S_set_error( "BB number from ECU ($ECU_version) and SAD file($BB_number) is not same \n", 114 );
        return 0;
    }

    S_w2log( 4, "PD_BBCheck: BB number from ECU and SAD file is same :: $BB_number \n" );

    return 1;
}

=head2 PD_CloseDiagnosis

    PD_CloseDiagnosis();

has to be called at the end, will unload PD.dll. should be called in ENDcampaign. Re-initialisation possible by PD_InitDiagnosis.

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_CloseDiagnosis
{

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $PD_initialized = 0;
        S_w2log( 5, "PD_CloseDiagnosis: Terminated the communication \n" );
        return 1;
    }

    $stat = pd_TestEnd();
    check_status($stat);
    S_w2log( 5, "pd_TestEnd status : $stat\n" );

    $PD_initialized = 0;
    S_w2log( 5, "PD_CloseDiagnosis: Terminated the communication \n" );

    return 1;
}

=head2 PD_ECUlogin

     PD_ECUlogin();

login to ECU

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ECUlogin
{

    S_w2log( 4, "PD_ECUlogin\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = pd_ECUlogin();
    check_status($stat);
    S_w2log( 3, "PD_ECUlogin status: $stat\n" );

    return 1;
}

=head2 PD_ECUreset

     PD_ECUreset($reset_type);

$reset_type :: 'Soft_reset' (default) or 'Hard_reset'

Resets the ECU. 

B<Note:> After a reset the ECU requires some waiting time before it is capable of accepting PD requests again.

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ECUreset
{

    my $reset_type = shift;

    unless ( defined $reset_type )
    {
        S_w2log( 4, "Default reset type is Soft_reset\n" );
        $reset_type = 'Soft_reset';
    }

    if ( defined($reset_type) && ( ( $reset_type !~ /Hard_reset/i ) && ( $reset_type !~ /Soft_reset/i ) ) )
    {
        S_set_error( "Reset type should be Hard_reset or Soft_reset \n", 114 );
        return 0;
    }

    S_w2log( 4, "PD_ECUreset ($reset_type)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ( $reset_type =~ /Hard_reset/i )
    {
        $reset_type = 0;
    }
    else
    {
        $reset_type = 1;
    }

    return 1 if $main::opt_offline;

    $stat = pd_ECUreset($reset_type);
    check_status($stat);
    S_w2log( 3, "PD_ECUreset status : $stat\n" );

    return 1;
}

=head2 PD_get_ECU_fingerprint

     $fingerprint = PD_get_ECU_fingerprint( );

returns a unique ID to identify the ECU built from internal IDs (  UniqueMcId # SMA660 ID )

Error return : unsupported_ABgeneration

Success return :: fingerprint

B<Note:> Supported AB Generations:: B<12> all other will return 'unsupported_ABgeneration'

=cut

sub PD_get_ECU_fingerprint
{
    my $fingerprint;
    my ($value_aref);

    return("unsupported_ABgeneration") if ( $ABgeneration != 12 );

    $value_aref = PD_ReadMemoryByName_NOHTML( 'rb_mcs_UniqueMcId_u32' );
    my $mcID=S_aref2hex($value_aref);
    $mcID =~ s/0x//g;

    S_w2log( 5, "UniqueMcId is $mcID\n");

    $value_aref = PD_ReadMemoryByName_NOHTML( 'rb_cs6m_AsicIdData_ast(0).SerialNumber1_u16' );
    my $cs6ID=S_aref2hex($value_aref);
    $value_aref = PD_ReadMemoryByName_NOHTML( 'rb_cs6m_AsicIdData_ast(0).SerialNumber2_u16' );
    $cs6ID.=S_aref2hex($value_aref);
    $value_aref = PD_ReadMemoryByName_NOHTML( 'rb_cs6m_AsicIdData_ast(0).SerialNumber3_u16' );
    $cs6ID.=S_aref2hex($value_aref);
    $cs6ID =~ s/0x//g;

    S_w2log( 5, "SMA660 ID is $cs6ID\n");

    $fingerprint = $mcID.'#'.$cs6ID;

    S_w2rep("ECU fingerprint is $fingerprint\n");
    $main::ENV{'ECU_fingerprint'} = $fingerprint;

    S_set_project_info( { 'ECU_fingerprint' => $fingerprint } );

    return $fingerprint;
}



=head2 PD_get_ECU_AlgoParameter_ID

    $ecu_algo_parameter_id = PD_get_ECU_AlgoParameter_ID( );

Returns a unique AlgoParameter ID assembled from 

    rb_acc_AidaParametersAlgoIds1_cst.ProjIdHB_u8
    rb_acc_AidaParametersAlgoIds1_cst.ProjIdLB_u8
    rb_acc_AidaParametersAlgoIds1_cst.ParaId_u8
    
resulting in 3-byte value

Example :

        "0x<HighB><LowB><ParaID>" = PD_get_ECU_AlgoParameter_ID( );

return "unsupported_ABgeneration" for unsupported_ABgeneration

return undef and set warning for any problems while reading the symbols

Success return :: AlgoParameter ID

Notes:
 
Supported AB Generations : '12'  ( all other will return 'unsupported_ABgeneration' )

%ENV{'ECU_AlgoParameter_ID'} will be set
    
S_set_project_info will be called with 'ECU_AlgoParameter_ID'

=cut

sub PD_get_ECU_AlgoParameter_ID
{

    return("unsupported_ABgeneration") if ( $ABgeneration != 12 );

    my $projectID_HB_aref = PD_ReadMemoryByName( 'rb_acc_AlgoIds_st.ProjIdHB_u8' );
    my $projectID_LB_aref = PD_ReadMemoryByName( 'rb_acc_AlgoIds_st.ProjIdLB_u8' );
    my $paraID_aref = PD_ReadMemoryByName( 'rb_acc_AlgoIds_st.ParaId_u8' );

    unless( $projectID_HB_aref && $projectID_LB_aref && $paraID_aref ) {
        S_set_warning( "Could not read all required symbols for ECU AlgoParameter ID - return" );
        return;
    }

    my $projectID_HB_string = sprintf("%02X", $projectID_HB_aref -> [0]);
    my $projectID_LB_string = sprintf("%02X", $projectID_LB_aref -> [0]);
    my $paraID_string = sprintf("%02X", $paraID_aref -> [0]);

    my $ecu_algo_parameter_id = "0x" . $projectID_HB_string . $projectID_LB_string . $paraID_string;

    S_w2log( 2 , " PD_get_ECU_AlgoParameter_ID : $ecu_algo_parameter_id\n" );
    $main::ENV{'ECU_AlgoParameter_ID'} = $ecu_algo_parameter_id;

    S_set_project_info( { 'ECU_AlgoParameter_ID' => $ecu_algo_parameter_id } );

    return $ecu_algo_parameter_id;
}




=head2 PD_get_PD_init_status

     $PD_init_status = PD_get_PD_init_status( );

Returns 1 if PD is already initialized, 0 if not.

Returns undef on error.

=cut

sub PD_get_PD_init_status
{
    if ( $PD_initialized == 0 )
    {
        S_w2log( 3, " PD_get_PD_init_status: PD is not initialized (PD_initialized = $PD_initialized)\n" );
        return $PD_initialized;
    }

    if ( $PD_initialized == 1 )
    {
        S_w2log( 3, " PD_get_PD_init_status: PD is initialized (PD_initialized = $PD_initialized)\n" );
        return $PD_initialized;
    }

    S_set_error("PD_initialized is in unexpected state ( PD_initialized = $PD_initialized ) ");
    return;
}

=head2 PD_GetABGeneration

    $ABgeneration = PD_GetABGeneration();

Returns Airbag Generation version of ECU.

Error return : 0 In case PD not initialized
offline return : 12	Since most used is AB12, ABgeneration returns 12 by default instead of 'offline'

Success return ::
Airbag Generation of ECU

For AB10 :: 10

For AB12 :: 12

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetABGeneration
{
    S_w2log( 5, " PD_GetABGeneration: Gives the Aribag ECU generation \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "PD_GetABGeneration: Airbag Generation of ECU  is $ABgeneration \n" );

    return $ABgeneration;
}

=head2 PD_GetECUStatus

    my $response_aref = PD_GetECUStatus();

get ECU status

Success return :: array of bytes

Total ECU Status Byte : 5

Status Byte 1: Fault Memory Status Byte

Status Byte 2: EDR Status Byte

Status Byte 3: Data Flash Status Byte Reserved

Status Byte 4: Electronic Firing Status Byte

Status Byte 5: Reserved Byte

Error return : []

offline return :: [0,0,0,0,0]

Reference link for Status Byte informations
doors://si-airbag-doors.de.bosch.com:36681/?version=2&prodID=0&urn=urn:telelogic::1-0000000000000000-O-320-0003ea7f

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetECUStatus
{

    my $response_aref;

    S_w2log( 4, "PD_GetECUStatus \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return [];
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return [];
    }

    return [ 0, 0, 0, 0, 0 ] if $main::opt_offline;

    ( $stat, $response_aref ) = pd_GetECUStatus();
    check_status($stat);
    S_w2log( 5, "PD_GetECUStatus() returned status $stat\n" );

    #For positive response 5 data Bytes will be received from ECU, Else 1 data byte will be receive.
    if ( scalar(@$response_aref) == 1 )
    {
        S_w2log( 4, "PD_GetECUStatus : No response received\n" );
        return [];
    }
    S_w2log( 4, "PD_GetECUStatus : ECU status bytes : @$response_aref bytes\n" );

    return $response_aref;
}


=head2 PD_GetECUMode

    my $ECUMode = PD_GetECUMode();

get ECU Mode

Success return :: Type of ECU mode

Offline Return :: 1
Error Retun :: 0

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_GetECUMode
{
	my $value_aref;
	my $ECUMode;
	my $label;
    my $ecuModes_aref = [0,'Init1','Init2','Init3','Idle','NormalDriving','Disposal','Crash','ReProg'];
    S_w2log( 4, "PD_GetECUMode \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }
    
    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }
    
    #Set error if AB generation is 10 or 9
    if ( $ABgeneration < 12 )
    {
        S_set_error( "The function 'PD_GetECUMode' is not currently support for AB10 project \n", 20 );
        return 0;
    }
    
    return "offline" if $main::opt_offline;
    
    $label = 'rb_bswm_ActualSystemMode_au16(0)';
    ( $stat, $value_aref ) = pd_ReadName($label); #This Variable name contains the mode in which the ECU is currently operated
    check_status($stat);
    
    S_w2log( 5, "pd_ReadName() returned status $stat\n" );

    if ( scalar(@$value_aref) < 1 )
    {
        S_set_error("PD_GetECUMode $label received no values");
        return 0;
    }
    my $ecuMode_inNbr = $value_aref->[1] ;
    
    $ECUMode = $ecuModes_aref->[$ecuMode_inNbr];
      
    if(@$value_aref[1] < 1 || @$value_aref[1] > 8)
    {
       $ECUMode = undef;
       S_w2log( 4, "ECU mode is not valid \n");
       S_set_error("PD_GetECUMode $label received invalid values");
   	   return 0;
    }

   	   S_w2log( 4, "ECU is in $ECUMode mode \n");
   	   return $ECUMode;

}

=head2 PD_InitCommunication

     $SWversion = PD_InitCommunication();

Initialize communication. 
Has to be called after PD_InitDiagnosis before any other function. 
Intializes communication based on ini file. 
Should be called in INITcampaign.  
ECU has to be switched on !

Calls :

    process_SAD
    PD_get_ECU_fingerprint
    PD_get_ECU_AlgoParameter_ID

Calling of PD_get_ECU_fingerprint and/or PD_get_ECU_AlgoParameter_ID can be suppressed in project const, 
see L<Project Configuration (..._ProjectConst.pm)>

Returns SW version of ECU.

offline + Error return : 'offline'

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_InitCommunication
{
    my ( $version, $ECU_label_aref, $ECU_value_aref );

    S_w2log( 4, " PD_InitCommunication: Initialize the communication \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return "offline";
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return "offline";
    }

    return "offline" if ($main::opt_offline);

    $stat = pd_InitCommunication();
    if ( $stat == -14 )
    {
        S_w2log( 3, "WARNING: SW version mismatch \n", "red" );
    }
    elsif ( $stat < 0 )
    {
        if($stat == -101)
        {
    	    my $CANchannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANchannel'};
            my $SerialNo   = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'};
    	    S_w2log( 3, "WARNING: HW CAN Channel (Channel : $CANchannel) or HW serial number (Serial No : $SerialNo) configured is incorrect \n", "red" );
        }
		check_status($stat);
        return "offline";
    }
    S_w2log( 5, "pd_InitCommunication: $stat\n" );

    #Reading ECu software version into array format
    ( $stat, $ECU_label_aref, $ECU_value_aref ) = pd_GetSWversion();

    if ( scalar(@$ECU_label_aref) == scalar(@$ECU_value_aref) )
    {
        for ( my $i = 0 ; $i < $stat ; $i++ )
        {
            $ECU_SWInfo{ $$ECU_label_aref[$i] } = $$ECU_value_aref[$i];
        }
    }

    check_status($stat);
    S_w2log( 5, "pd_GetSWversion status -> $stat \n" );
    for ( my $i = 0 ; $i < $stat ; $i++ )
    {
        S_w2log( 5, " $$ECU_label_aref[$i] :: $$ECU_value_aref[$i] \n" );
    }

    $ABgeneration = $ECU_SWInfo{'Airbag Generation'};

    if ( defined $ABgeneration )
    {
        # !!! ASSUMPTION THAT UNSUPPORTED $ABgeneration IS AB10 !!!
        # warn if $ABgeneration is not in the list of supported generations & consider ABGeneration as 10
        unless ( grep { $ABgeneration == $_ } ( 9, 10, 12 ) )
        {
            # for older AB10 SW, airbag generation will be 0 . So by default consider airbag generation as 10
            S_set_warning("AB generation is $ABgeneration. but AB generation can only be '9', '10', '12'. By default considering AB generation as '10'");    # just a warning
            $ABgeneration = 10;
        }
    }
    else
    {                                                                                                                                                        # error if $ABgeneration is not defined
        S_set_error( "AB generation is not defined. Something went wrong! AB generation shall be 9, 10, 12 !", 120 );
        return "offline";
    }

    # read SAD file (AB10 and AB12) and CNS file (only AB12) to get information about devices
    process_SAD();

    my $do_PD_get_ECU_fingerprint = 1; 
    if ( defined $main::ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_fingerprint'} ) {
        unless( $main::ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_fingerprint'} ) {
            S_set_warning( "ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_fingerprint'} is disabling PD_get_ECU_fingerprint" );
            $do_PD_get_ECU_fingerprint = 0;
        }   
    }
    PD_get_ECU_fingerprint() if $do_PD_get_ECU_fingerprint;


    my $do_PD_get_ECU_AlgoParameter_ID = 1;
    if ( defined $main::ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_AlgoParameter_ID'} ) {
        unless( $main::ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_AlgoParameter_ID'} ) {
            S_set_warning( "ProjectDefaults->{'PD'}{'PD_InitCommunication'}{'PD_get_ECU_AlgoParameter_ID'} is disabling PD_get_ECU_AlgoParameter_ID" );
            $do_PD_get_ECU_fingerprint = 0;
        }   
    }
    PD_get_ECU_AlgoParameter_ID() if $do_PD_get_ECU_AlgoParameter_ID;

    
    S_w2log( 4, "PD_InitCommunication: Communication with ECU is Initialized \n" );
    my $ECU_SW_version = $ECU_SWInfo{'SW Version'};
    unless( defined $ECU_SW_version ) {
        S_set_error( "ECU SW Version not received -> return 'offline'" );
        return "offline";
    }
    
    #
    # set for LIFT_exec_engine (used in campaign and testcase header)
    #
    $main::ENV{'ECU_SW_VERSION'} =  $ECU_SW_version;
    
    #
    # adding to collection of all project meta info
    #
    S_set_project_info( { 'ECU_SW_VERSION' => $ECU_SW_version } );
    
    return ( $ECU_SW_version );
}

=head2 PD_InitDiagnosis

     PD_InitDiagnosis();

Has to be called before any other PD command, loads SAD file (mentioned in config file) and intializes diagnosis settings. should be called in INITcampaign. does not access the ECU.

NOTICE: kills running WinDiag process and PSDiag Process.

AB10 => CANParameterFile.txt
        File Location : \Engine\modules\DLLs\PD

AB12 => PSDiag_CAN_Parameter.txt (This file get shared from PSDIAG)
        File Loaction :\Engine\modules\DLLs\PD\Win32

B<CAN Hardware Serial number & Channel number> should be mentioned in testbench configuration

    'Devices' => {

          'PD' => {
                'Hostname' => 'SI54207',
                'CANchannel' => 1,
                'CANHWSerialNo'  => 30679,
          },

     }

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_InitDiagnosis
{

    if ($PD_initialized)
    {
        S_set_warning("PD is already initialized");
        return;
    }

    my $SADfile    = $LIFT_config::SAD_file;
    my $CANchannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANchannel'};
    my $SerialNo   = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'};

    my $CPUType = $main::ProjectDefaults->{'SADCONFIG'}{'CPU_Type'};
    $CPUType = '' if not defined $CPUType;
    my $CANtype = $main::ProjectDefaults->{'SADCONFIG'}{'CAN_Type'};
    $CANtype = '' if not defined $CANtype;
    my $SGType = $main::ProjectDefaults->{'SADCONFIG'}{'SG_Type'};
    $SGType = '' if not defined $SGType;

    S_w2log( 4, "PD_InitDiagnosis : Initialize the diagnosis settings \n" );

    unless ( defined $SADfile )    { S_set_error( "SADfile not defined in tesbenchconfig",    105 ); return; }
    unless ( defined $CANchannel ) { S_set_error( "CANchannel not defined in tesbenchconfig", 105 ); return; }
    unless ( defined $SerialNo ) { S_set_error( "CANHWSerialNo not defined in testbenchconfig", 0 ); }    # only a warning

    $CANchannel--; # In accordance with PS Diag DLLs - indexing of channel number changed to zero-based

    my %procs = S_get_Win32_processes();

    #Killing Windiag
    if ( exists $procs{'windiag'} )
    {
        S_w2log( 5, "-> killing WinDiag !!!\n" );
        Win32::Process::KillProcess( $_, 0 ) foreach ( @{ $procs{'windiag'} } );
    }

    #Killing PSDiag
    if ( exists $procs{'PSDiag'} )
    {
        S_w2log( 5, "-> killing PSDiag !!!\n" );
        Win32::Process::KillProcess( $_, 0 ) foreach ( @{ $procs{'PSDiag'} } );
    }

    $SADfile =~ /([^\/\\]+)$/;
    my $SADname = $1;

    # copy ECU software related files (sad, cns, nvm, flt) to dll folder
    Copy_ECU_SW_Files( $SADfile ) or return 0;

    $addpath =~ s/^;//;    # drop leading semicolon
    my $diag_ini = "$addpath\\PD_Diag.ini";

    S_w2log( 3, "PD_InitDiagnosis using diag_ini $diag_ini (this may take some time)\n" );

    if ($main::opt_offline)
    {

        unless ( defined $SerialNo ) { $SerialNo = 0 }

        # delete old and create new PD_Diag.ini
        if ( -f $diag_ini )
        {
            S_w2log( 3, "File $diag_ini is exisiting -> deleting it first\n" );
            unless ( unlink($diag_ini) )
            {
                S_set_error("Error while deleting $diag_ini : $!");
                return;
            }
        }

        unless ( open( OUT, ">$diag_ini" ) )
        {
            S_set_error( "could not write $diag_ini", 1 );
            $PD_initialized = 0;
            return 0;
        }

        print OUT"[GENERAL]\n";
        print OUT"DIRECTORY      = $addpath\n";
        print OUT"SADFILE         = $SADname\n";
        print OUT"TIMEOUT         = 1000\n";
        print OUT"CAN              = $CANchannel\n";
        print OUT"CANHWSERIALNUMBER = $SerialNo\n";
        print OUT"RINGBUFFER     = 1000\n";
        print OUT"RETRYCOUNT     = 60\n";
        print OUT"AB10_CANPARAFILEPATH     = $addpath\\CAN_Parameter\.txt\n";
        print OUT"AB12_CANPARAFILEPATH     = $addpath\\Win32\\PSDIAG_CAN_Parameter\.txt\n";
        print OUT"CPU Type            = $CPUType\n";
        print OUT"SG Type             = $SGType\n";
        print OUT"CAN Type            = $CANtype\n";
        close(OUT);

       	S_w2log( 4, "PD_init: Initialized successfully \n" );
        $PD_initialized = 1;
        $ABgeneration = 12; #Initializing ABGeneration as 12 incase of offline mode
        return 1;
    }

    $stat = pd_TestStart();
    check_status($stat);

    #get the available (connected) CAN Hardwares
    my ( $IDs_aref, $channels_aref );
    ( $stat, $IDs_aref, $channels_aref ) = pd_GetCANHWList();
    check_status($stat);

    # set SerialNo if only one HW detected and no entry in testbenchconfig
    if ( scalar(@$IDs_aref) == 1 and not defined $SerialNo )
    {
        S_w2log( 3, " PD_InitDiagnosis: set SerialNo if only one HW detected and no entry in testbenchconfig\n" );
        $SerialNo = $$IDs_aref[0];
    }

    # set error if no entry in testbenchconfig (and more than one HW detected)
    unless ( defined $SerialNo )
    {
        S_set_error( "CANHWSerialNo not defined in testbenchconfig PD, detected HWs: @$IDs_aref ", 114 );
        return;
    }

    # check if expected HW connected and channel number in range
    my $foundSerialno = 0;
    for ( my $count = 0 ; $count < scalar(@$IDs_aref) ; $count++ )
    {
        if ( $$IDs_aref[$count] == $SerialNo )
        {
            S_w2log( 3, " PD_InitDiagnosis: set SerialNo $SerialNo \n" );
            $foundSerialno = $SerialNo;
        }
    }

    #if the "testbenchconfig HW number" is not found, report error
    unless ($foundSerialno)
    {
        S_set_error( "! given CANHWSerialNo $SerialNo not connected, detected HWs: @$IDs_aref  )", 114 );
        return;
    }

    # delete old and create new PD_Diag.ini
    unless ( open( OUT, ">$diag_ini" ) )
    {
        S_set_error( "could not write $diag_ini", 1 );
        $PD_initialized = 0;
        return;
    }

    print OUT"[GENERAL]\n";
    print OUT"DIRECTORY      = $addpath\n";
    print OUT"SADFILE         = $SADname\n";
    print OUT"TIMEOUT         = 1000\n";
    print OUT"CAN              = $CANchannel\n";
    print OUT"CANHWSERIALNUMBER = $SerialNo\n";
    print OUT"RINGBUFFER     = 1000\n";
    print OUT"RETRYCOUNT     = 60\n";
    print OUT"AB10_CANPARAFILEPATH     = $addpath\\CAN_Parameter\.txt\n";
    print OUT"AB12_CANPARAFILEPATH     = $addpath\\Win32\\PSDIAG_CAN_Parameter\.txt\n";
    print OUT"CPU Type            = $CPUType\n";
    print OUT"SG Type             = $SGType\n";
    print OUT"CAN Type            = $CANtype\n";
    close(OUT);

    $stat = pd_InitConfiguration($diag_ini);
    S_w2log( 5, " PD_InitDiagnosis: pd_InitConfiguration ($stat)\n" );
    check_status($stat);

    $Motorola_format = 0;
    my ( $SAD_created, $CAN_Type );

    ( $stat, $Motorola_format ) = pd_GetSADInfo("Motorola Format");
    check_status($stat);
    ( $stat, $SAD_created ) = pd_GetSADInfo("File created on");
    check_status($stat);
    ( $stat, $CAN_Type ) = pd_GetSADInfo("CAN Type");
    check_status($stat);

    S_w2log( 5, " PD_InitDiagnosis: SAD: Motorola_format is $Motorola_format\n" );
    S_w2log( 5, " PD_InitDiagnosis: SAD: CAN Type is $CAN_Type\n" );
    S_w2log( 5, " PD_InitDiagnosis: SAD: file created on $SAD_created\n" );

    my $version;
    ( $stat, $version ) = pd_GetVersion();
    check_status($stat);

    S_w2log( 5, " PD_InitDiagnosis: ($stat) PD DLL version: $version\n" );
    $PD_initialized = 1;

    if ( $stat < 0 )
    {
        S_set_error( "could not initialize PD with $diag_ini", 5 );
        $PD_initialized = 0;
    }

    S_w2log( 4, "PD_init: Initialized successfully \n" );
    return 1;
}

=head2 PD_send_request_wait_response

I<B<Syntax : >>

     $response_aref = PD_send_request_wait_response( $request_aref [, $RequestID [, $ResponseID [, $Timeout_ms ]]] )

I<B<Arguments     : >>

     $request_aref         = array reference to the request array
     $RequestID             = (optional) send ID, if not given will be taken from CD_set_addressing_mode
     $ResponseID            = (optional) response ID, if not given will be taken from CD_set_addressing_mode
     $Timeout_ms            = (optional) timeout in milliseconds. if not given, will be taken from CD_set_addressing_mode

I<B<Description :>>

Sends arbitrary service to PD. $response_aref must contain Block Length, the service itself and the Checksum.

The function calls "CD_set_addressing_mode('PD')", which looks for ProjectDefaults->{'CUSTOMER_DIAGNOSIS'}{'RequestID_PD'} etc. in ProjectConst.

If this is not defined an error is thrown.

Optionally $RequestID, $ResponseID and $Timeout_ms can be specified if other values than those defined in ProjectConst are wanted.

Error return : []

offline return : []

I<B<Example : >>

     my $response_aref = PD_send_request_wait_response([0x04,0x18,0xAB,0x12,0xD9]);


B<Note:> Supported AB Generations:: B<10 and 12>
B<Note:> Parallel using of this function with CD_send_request_wait_response might cause an error

=cut

sub PD_send_request_wait_response
{

    my $request_aref   = shift;
    my $sendRequestID  = shift;
    my $sendResponseID = shift;
    my $sendTimeout_ms = shift;

    S_w2log( 5, "PD_send_request_wait_response: starting...\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return [];
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return [];
    }

    unless ( defined($request_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: respone_aref = PD_send_request_wait_response( request_aref [, RequestID [, ResponseID [, Timeout_ms ]]] )", 110 );
        return [];
    }

    if ( ref($request_aref) ne "ARRAY" )
    {
        S_set_error( " request_aref is not an array reference", 114 );
        return [];
    }

    CD_CAN_init();

    CD_CAN_start_simulation();

    CD_CAN_set_addressing_mode('PD');

    # Send request with inter frame delay = 4ms. See PD SRS requirment SRS_PRD_938.
    my $response_aref = CAN_send_request_wait_response( $request_aref, $sendRequestID, $sendResponseID, $sendTimeout_ms, 4 );

    S_w2log( 5, "PD_send_request_wait_response: @$response_aref\n" );

    return $response_aref;
}

=head1 Function Group 'fault'

=head2 PD_check_fault_exists

    PD_check_fault_exists( $flt_mem_struct, $faultname );

Test if fault $faultname is included in fault memory dump $flt_mem_struct.

Sets verdict to PASS if fault exists, otherwise to FAIL

Calls PD_count_fault, (does not require PD_InitDiagnosis)

Error return : 0

Success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_check_fault_exists
{
    my $flt_struct = shift;
    my $faultname  = shift;
    my ( $occurence, $extended_struct );

    unless ( defined($faultname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_check_fault_exists( flt_mem_struct, faultname )", 110 );
        return 0;
    }

    if ( ref($flt_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    S_w2log( 4, "PD_check_fault_exists for fault name $faultname \n" );

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return 0;
            }
        }
    }

    $occurence = PD_count_fault( $flt_struct, $faultname );
    if ( $occurence > 0 )
    {
        S_w2log( 3, " PD_check_fault_exists: $faultname found $occurence times\n" );
        S_set_verdict('VERDICT_PASS');
        return 1;
    }
    else
    {
        S_w2log( 3, " PD_check_fault_exists: $faultname not found\n" );
        S_set_verdict('VERDICT_FAIL');
        return 0;
    }

    #return 1;
}

=head2 PD_check_fault_status

    PD_check_fault_status($flt_mem_struct,$fault_name,$expected_state, [$key_name]);

I<Mandatory Input Arguments>

flt_mem_struct - Fault memory structure

fault_name - Fault name to which state has to check

expected_state - The expected value of the state

I<Optional Input Arguments>

key_name - state/GeneralState/DisturbanceState/fltmun/QualificationTime/Dequalification_poweron_cycle
             DequalificationTime/OccuranceCounter/DisturbanceCounter/EventDebug/EventDebug_HB/EventDebug_LB/Qualification_poweron_cycle/ASIC_Temperature

calls internally

$found_status = PD_GetFaultAttribute($flt_mem_struct, $fault_name, $key_name) and

EVAL_evaluate_value ( $fault_name , $expected_states , $found_status  );

sets PASS if the $fault_name matches $expected_states, else FAIL.

sets ERROR if $fault_name not found

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_check_fault_status
{
    my $flt_mem_struct = shift;
    my $fault_name     = shift;
    my $expected_state = shift;
    my $key_name       = shift;
    my $extended_struct;

    my $check_verdict = '';

    my @keys = ( 'state', 'GeneralState', 'DisturbanceState', 'fltnum', 'EventDebug','EventDebug_HB','EventDebug_LB','DisturbanceCounter', 'OccuranceCounter', 'Qualification_poweron_cycle', 'QualificationTime', 'Dequalification_poweron_cycle', 'DequalificationTime','ASIC_Temperature' );

    #Performing Checking conditions
    if ( !defined $expected_state )
    {
        S_set_error( "too less parameters ,SYNTAX: PD_check_fault_status( \$flt_mem_struct, \$fault_name, \$expected_states ) ", 110 );
        return 0;
    }

    if ( ref($flt_mem_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    S_w2log( 5, "PD_check_fault_status for fault name $fault_name \n" );

    if ( !defined $key_name )
    {
        S_w2log( 4, "Considered default state :: 'key' \n" );
        $key_name = 'state';
    }
    else
    {
        if ( !grep { $key_name eq $_ } @keys )
        {
            S_set_error( "Given state name $key_name is not match with any of states \"@keys\"", 114 );
            return 0;
        }
    }

    return 1 if $main::opt_offline;

    #Reads the data for given state_name
    my $found_status = PD_GetFaultAttribute( $flt_mem_struct, $fault_name, $key_name );

    #Evaluates read data with expected and reads the verdict
    $check_verdict = LIFT_evaluation::EVAL_evaluate_value( "STATUS_" . $fault_name, $found_status, "==", $expected_state );

    S_w2log( 3, "PD_check_fault_status: $key_name  - $fault_name - $expected_state - $check_verdict \n" );

    return 1;
}

=head2 PD_ClearFaultMemory

    PD_ClearFaultMemory( [$localid , $isWaitUntillCLTFltMem] );

Calls the service to clear fault memory.

Only if the execution option "PD_ClearFaultMemory_using_ManipulateFaultMemory" is set, then the service for manipulating the fault memory to dequalify the primary faults is called first. Faults are cleared after this.

$localid for AB12

    0 : (default) clear all fault memories (primary, history, disturbance and Bosch)
    1 : only plant fault memory

$localid for AB10

    0 :  (default) clear all fault memories (Bosch)
    1 :  clear not filtered faults (Bosch)
    2 :  clear disturbance memory
    3 :  clear shadow memory
    4 :  clear all faults (customer -> shadow memory will be written if any)
    5 :  clear not filtered faults (customer -> shadow memory will be written if any)

$isWaitUntillCLTFltMem

    0 : Return immediately after sending the request
    1 : (default) Wait until clear fault Memory is finished

Note: If $isWaitUntillCLTFltMem is set to 0 then immediately afterwards the ECU may still be busy with clearing the fault memory 
and not be ready for further PD requests.

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ClearFaultMemory
{
    #COMMENT-START
    #Two arguments - $localid and $isWaitUntillCLTFltMem - both optional
    #(default for $localid = 0, isWaitUntillCLTFltMem = 1)
    #COMMENT-END
    my $localid               = shift;
    my $isWaitUntillCLTFltMem = shift;

    unless ( defined $localid )
    {
        S_w2log( 5, "Considering default localid value :: 0 \n" );
        $localid = 0;

    }
    unless ( defined $isWaitUntillCLTFltMem )
    {
        S_w2log( 5, "Considering default isWaitUntillCLTFltMem value :: 1 \n" );
        $isWaitUntillCLTFltMem = 1;
    }

    S_w2log( 4, "PD_ClearFaultMemory ($localid)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }
    #IF Fast diagnostics active
    #IF-YES-START
    #STEP set error and return
    #IF-YES-END
    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    #IF-NO-START
    #IF execution option PD_ClearFaultMemory_using_ManipulateFaultMemory is set and local id not equal to 1
    #IF-YES-START
    #CALL PD_ManipulateFaultMemory to dequalify all faults from primary fault memory
    #IF-YES-END
    #IF-NO-START
    #IF-NO-END
    my $exec_Options_href = S_get_exec_option();
    my $is_ExecOption_enabled = $exec_Options_href->{'PD_ClearFaultMemory_using_ManipulateFaultMemory'};
    if ( $is_ExecOption_enabled and ($localid != 1)) {

        S_w2log( 3, "Execution option PD_ClearFaultMemory_using_ManipulateFaultMemory is set. So the fault memory is manipulated for dequalifying the faults present and then cleared." );

        # manipulating only primary fault memory which actually causes the system go into idle mode
        PD_ManipulateFaultMemory( 1, "dequalify" );
    }

    #CALL pd_ClearFaultMemory
    $stat = pd_ClearFaultMemory( $localid, $isWaitUntillCLTFltMem );
    check_status($stat);
    S_w2log( 4, "pd_ClearFaultMemory status : $stat\n" );

    #STEP return
    #IF-NO-END
    return 1;

}

=head2 PD_count_fault

    $count = PD_count_fault( $flt_mem_struct, $faultname );

Counts and returns how many times the given fault $faultname is included in fault memory dump $flt_mem_struct.

sets no verdict, (does not require PD_InitDiagnosis)

B<Arguments:>

=over

=item $flt_mem_struct

It is the fault memory dump.

=item $faultname

It is faultname whose no of occurence has to be found.

=back

B<Return Value:>

=over

=item $type 

Success      : Number of occurences of fault

Error        : undef

=back

B<Examples AB12:>
    
B<Notes>:

Supported AB Generations:: B<10 and 12>

=cut


sub PD_count_fault
{
    my $flt_struct = shift;
    my $faultname  = shift;
    my $occurence  = 0;
    my ($extended_struct);

    unless ( defined($faultname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_count_fault( flt_mem_struct, faultname )", 110 );
        return undef;
    }

    if ( ref($flt_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return undef;
    }

    S_w2log( 4, "PD_count_fault for fault name $faultname\n" );

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return undef;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return undef;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return undef;
            }
        }
    }

    foreach my $fault ( @{ $flt_struct->{'fault_text'} } )
    {
        $occurence++ if ( $faultname eq $fault );
    }
    if   ( $occurence > 0 ) { S_w2log( 3, " PD_count_fault: $faultname found $occurence times\n" ); }
    else                    { S_w2log( 3, " PD_count_fault: $faultname not found\n" ); }

    return ($occurence);
}

=head2 PD_DumpFaultMemoryTable

      Reads the fault memory structure of PD and generates the HTML table.

      PD_DumpFaultMemoryTable($flt_mem_struct);

        $flt_mem_struct = {
            "fltnum"                           => [@faults],
            "fault_text"                       => [@fault_text],
            "DTC"                              => [@DTC],
            "state"                            => [@states],
            "DisturbanceState"                 => [@distrubanceState],
            "GeneralState"                     => [@generalState],
            "state_txt"                        => [@state_text],
            "DisturbanceState_text"            => [@distrubanceStateText],
            "GeneralState_text"                => [@generalStateText],
            "info"                             => [@addInfo],
            "info_txt"                         => [@addInfo_text],
            #Extra Information from both disturbance & Bosch fault memory
            "EventDebug"                       => [@event],   # Holds event values in DFM and BFM respectively
            "EventDebug_HB"                    => [@event_hb],# Holds event high byte values in DFM and BFM respectively
            "EventDebug_LB"                    => [@event_lb],# Holds event low byte values in DFM and BFM respectively
            "OccuranceCounter"                 => [@counter], # Holds Occurance counter in BFM
            "DisturbanceCounter"               => [@counter], # Holds disturbance counter value in DFM
            #Extra Information from only Bosch fault memory
            "QualificationTime"                => [@quali_time],
            "DequalificationTime"              => [@dequali_time],
            "Qualification_poweron_cycle"      => [@quali_poweron],
             "Dequalification_poweron_cycle"    => [@dequali_poweron],
			 "ASIC_Temperature"                => [@asic_Temperature]
        };

Error return : 0

Success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_DumpFaultMemoryTable
{
    my $flt_mem_struct = shift;
    my ( @faults,     @fault_text, @DTC,         @states,  @addInfo,    @addInfo_text, @state_text );
    my ( $item,       $value,      @table,       $text,    @ApTime,     @DisTime,      @PonCnt, @SpoCnt );
    my ( @dist_state, @gen_state,  @event_debug, @event_debug_hb, @event_debug_lb,  @counter, @quali_time, @dequali_time, @quali_Pon_Cycle, @dequali_Pon_Cycle, @asic_Temperature );
    my ($extended_struct);

    unless ( defined $flt_mem_struct )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_DumpFaultMemoryTable(flt_mem_struct)", 110 );
        return 0;
    }

    unless ( ref $flt_mem_struct eq "HASH" )
    {
        S_set_error( "flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    #Fault memory Table creates for ABGeneration < 12
    if ( $ABgeneration < 12 )
    {
        #Checking flt_mem_struct format
        foreach my $keyvalue ( keys %flt_mem_keys )
        {
            #set $extended_struct = 1, if Extendedfaultinfo found
            if ( ( exists $flt_mem_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
            {
                $extended_struct = 1;
            }
        }

        foreach my $keyvalue ( keys %flt_mem_keys )
        {
            #check, if all mandatory keys are present
            if ( not exists $flt_mem_struct->{$keyvalue} )
            {
                if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
                {
                    S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                    return 0;
                }
            }

            #check, if all mandatory keys are defined
            elsif ( not defined $flt_mem_struct->{$keyvalue} )
            {
                if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
                {
                    S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                    return 0;
                }
            }
            else
            {
                #check if all key's array reference contains defined array elements
                if ( S_check_array( $flt_mem_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
                {
                    S_set_error( "S_check_array reported an error", 114 );
                    return 0;
                }
            }
        }

        #Reads the data from Fault memory structure
        @states     = @{ $flt_mem_struct->{'state'} };
        @faults     = @{ $flt_mem_struct->{'fltnum'} };
        @fault_text = @{ $flt_mem_struct->{'fault_text'} };
        @DTC        = @{ $flt_mem_struct->{'DTC'} };
        @state_text = @{ $flt_mem_struct->{'state_txt'} };
        @addInfo    = @{ $flt_mem_struct->{'info'} };

        #Reads the data from fault memory structure for extended data
        if ($extended_struct)
        {
            @ApTime  = @{ $flt_mem_struct->{'ApTime'} };
            @DisTime = @{ $flt_mem_struct->{'DisTime'} };
            @PonCnt  = @{ $flt_mem_struct->{'PonCnt'} };
            @SpoCnt  = @{ $flt_mem_struct->{'SpoCnt'} };
        }

        if (@states)
        {
            @table = ();
            $text  = "ID; DTC; faultname; status; Add Faultinfo\n";

            for ( $item = 0 ; $item < @states ; $item++ )
            {
                my $bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                my $bittext = join( '</TD><TD>', split( //, $bits ) );
                $bittext =~ s/0/-/g;
                $bittext =~ s/1/X/g;

                my $infotext;
                $infotext = $addInfo[$item] . "<br>" . $addInfo_text[$item];

                #HTML output
                if ($extended_struct)
                {
                    push( @table,
                              '<TR><TD>'
                            . hex( $faults[$item] )
                            . '</TD><TD>'
                            . $DTC[$item]
                            . '</TD><TD>'
                            . $fault_text[$item]
                            . '</TD><TD>'
                            . $states[$item]
                            . '</TD><TD>'
                            . $bittext
                            . '</TD><TD>'
                            . $infotext
                            . '</TD><TD>'
                            . $ApTime[$item]
                            . '</TD><TD>'
                            . $DisTime[$item]
                            . '</TD><TD>'
                            . $PonCnt[$item]
                            . '</TD><TD>'
                            . $SpoCnt[$item]
                            . '</TD></TR>' );
                    $text .= hex( $faults[$item] ) . "; $DTC[$item]; $fault_text[$item]; $states[$item]; $addInfo[$item]; $ApTime[$item]; $DisTime[$item]; $PonCnt[$item]; $SpoCnt[$item]\n";
                }
                else
                {
                    push( @table, '<TR><TD>' . hex( $faults[$item] ) . '</TD><TD>' . $DTC[$item] . '</TD><TD>' . $fault_text[$item] . '</TD><TD>' . $states[$item] . '</TD><TD>' . $bittext . '</TD><TD>' . $infotext . '</TD></TR>' );
                    $text .= hex( $faults[$item] ) . "; $DTC[$item]; $fault_text[$item]; $states[$item]; $addInfo[$item]\n";
                }
            }

            #Table Creation for Extendend fault memory structure
            if ($extended_struct)
            {
                S_w2log( 4, "PD_DumpFaultMemoryTable of AB Generation $ABgeneration: Extended fault memory table\n" );
                #
                #  TODO : table function must be used normally
                #
                push(
                      @TC_HTML_TEXT,
                      join( '',
                            '<div class="w2rep ',
                            $module_name,
                            '"><TABLE class="tablesorter">',
                            '<TR><TH>ID</TH><TH>DTC</TH><TH>faultname</TH><TH>status</TH>',
                            '<TH>7</TH><TH>6</TH><TH>D</TH><TH>A</TH><TH>C</TH><TH>S</TH><TH>L</TH><TH>F</TH>',
                            '<TH>Add Faultinfo</TH><TH>ApTime</TH><TH>DisTime</TH><TH>Pon</TH><TH>Spo</TH></TR>',
                            @table, '</TABLE></div>', "\n" )
                );
            }

            #Table Creation for fault memory structure
            else
            {
                S_w2log( 4, "PD_DumpFaultMemoryTable of AB Generation $ABgeneration: fault memory table\n" );
                #
                #  TODO : table function must be used normally
                #
                push(
                      @TC_HTML_TEXT,
                      join( '',
                            '<div class="w2rep ',
                            $module_name,
                            '"><TABLE class="tablesorter">',
                            '<TR><TH>ID</TH><TH>DTC</TH><TH>faultname</TH><TH>status</TH>',
                            '<TH>7</TH><TH>6</TH><TH>D</TH><TH>A</TH><TH>C</TH><TH>S</TH><TH>L</TH><TH>F</TH>',
                            '<TH>Add Faultinfo</TH></TR>',
                            @table, '</TABLE></div>', "\n" )
                );
            }

            print $text unless $main::opt_silent;
            print LIFT_general::LOG $text;
        }
    }

    #Fault memory Table creates for ABGeneration == 12
    else
    {
        #Checking flt_mem_struct format
        foreach my $key ( keys %$flt_mem_struct )
        {
            if ( ref( $flt_mem_struct->{$key} ) ne "ARRAY" )
            {
                S_set_error( " $key data is not an array reference \n", 114 );
                return 0;
            }
        }

        #Reading data from fault memory structure
        @faults     = @{ $flt_mem_struct->{'fltnum'} };
        @fault_text = @{ $flt_mem_struct->{'fault_text'} };
        @DTC        = @{ $flt_mem_struct->{'DTC'} };

        #Table creation for disturbance fault memory
        if ( scalar( @{ $flt_mem_struct->{'DisturbanceState'} } ) > 0 )
        {
            @dist_state  = @{ $flt_mem_struct->{'DisturbanceState'} };
            @gen_state   = @{ $flt_mem_struct->{'GeneralState'} };
            @event_debug = @{ $flt_mem_struct->{'EventDebug'} };
            @event_debug_hb = @{ $flt_mem_struct->{'EventDebug_HB'} };
            @event_debug_lb = @{ $flt_mem_struct->{'EventDebug_LB'} };
            @counter     = @{ $flt_mem_struct->{'DisturbanceCounter'} };

            for ( $item = 0 ; $item < @dist_state ; $item++ )
            {
                my $dist_bits = sprintf( "%08b", S_0x2dec( $dist_state[$item] ) );
                my $gen_bits  = sprintf( "%08b", S_0x2dec( $gen_state[$item] ) );

                my @dist_bit_arr = split( //, $dist_bits );
                my $gen_bittext = join( '</TD><TD>', split( //, $gen_bits ) );

                push(
                    @table, '<TR>
                            <TD>' . hex( $faults[$item] ) . '</TD>
                            <TD>' . $DTC[$item] . '</TD>
                            <TD>' . $fault_text[$item] . '</TD>
                            <TD>' . $dist_state[$item] . '</TD>
                            <TD>0</TD>
                            <TD>' . $dist_bit_arr[6] . '</TD>
							<TD>' . $dist_bit_arr[7] . '</TD>
                            <TD>' . $event_debug[$item] . '</TD>
                            <TD>' . $event_debug_hb[$item] . '</TD>
                            <TD>' . $event_debug_lb[$item] . '</TD>
                            <TD>' . $counter[$item] . '</TD>
                            <TD>' . $gen_state[$item] . '</TD>
                            <TD>' . $gen_bittext . '</TD>
                            </TR>'
                );
            }

            S_w2log( 4, "PD_DumpFaultMemoryTable of AB Generation $ABgeneration: Disturbance fault memory\n" );
            #
            #  TODO : table function must be used normally
            #
            push(
                @TC_HTML_TEXT,
                join(
                    '', '<div class="w2rep ', $module_name, '"><TABLE class="tablesorter">',
                    '<TR>
            <TH>ID</TH>
            <TH>DTC</TH>
            <TH>faultname</TH>
            <TH>Disturbance status</TH>
            <TH>Bits 7 - 2</TH>
            <TH>' . $dfm_dist_statenames{'Bit1'} . '</TH>
            <TH>' . $dfm_dist_statenames{'Bit0'} . '</TH>
            <TH>Event Debug</TH>
            <TH>Event Debug HB</TH>
            <TH>Event Debug LB</TH>
            <TH>Disturbance Counter</TH>
            <TH>General status</TH>
            <TH>Bit 7</TH>
            <TH>' . $dfm_gen_statenames{'Bit6'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit5'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit4'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit3'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit2'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit1'} . '</TH>
            <TH>' . $dfm_gen_statenames{'Bit0'} . '</TH></TR>',
                    @table, '</TABLE></div>', "\n"
                )
            );
        }

        #Table creation for bosch fault memory
        elsif ( scalar( @{ $flt_mem_struct->{'GeneralState'} } ) > 0 )
        {
            @states            = @{ $flt_mem_struct->{'state'} };
            @gen_state         = @{ $flt_mem_struct->{'GeneralState'} };
            @event_debug       = @{ $flt_mem_struct->{'EventDebug'} };
            @event_debug_hb    = @{ $flt_mem_struct->{'EventDebug_HB'} };
            @event_debug_lb    = @{ $flt_mem_struct->{'EventDebug_LB'} };
            @counter           = @{ $flt_mem_struct->{'OccuranceCounter'} };
            @quali_time        = @{ $flt_mem_struct->{'QualificationTime'} };
            @dequali_time      = @{ $flt_mem_struct->{'DequalificationTime'} };
            @quali_Pon_Cycle   = @{ $flt_mem_struct->{'Qualification_poweron_cycle'} };
            @dequali_Pon_Cycle = @{ $flt_mem_struct->{'Dequalification_poweron_cycle'} };
            @asic_Temperature  = @{ $flt_mem_struct->{'ASIC_Temperature'} };
            my @iso_bit_arr;

            for ( $item = 0 ; $item < @gen_state ; $item++ )
            {
                my $iso_bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                my $gen_bits = sprintf( "%08b", S_0x2dec( $gen_state[$item] ) );

                @iso_bit_arr = split( //, $iso_bits );
                my $gen_bittext = join( '</TD><TD>', split( //, $gen_bits ) );

                push(
                    @table, '<TR>
                            <TD>' . hex( $faults[$item] ) . '</TD>
                            <TD>' . $DTC[$item] . '</TD>
                            <TD>' . $fault_text[$item] . '</TD>
                            <TD>' . $quali_time[$item] . '</TD>
                            <TD>' . $dequali_time[$item] . '</TD>
                            <TD>' . $counter[$item] . '</TD>
                            <TD>' . $quali_Pon_Cycle[$item] . '</TD>
                            <TD>' . $dequali_Pon_Cycle[$item] . '</TD>
                            <TD>' . $event_debug[$item] . '</TD>
                            <TD>' . $event_debug_hb[$item] . '</TD>
                            <TD>' . $event_debug_lb[$item] . '</TD>
                            <TD>' . $gen_state[$item] . '</TD>
                            <TD>' . $gen_bittext . '</TD>
                            <TD>' . $asic_Temperature[$item] . '</TD>
                            <TD>' . $states[$item] . '</TD>
                            <TD>0</TD>
                            <TD>' . $iso_bit_arr[0] . '</TD>
                            </TR>'
                );
            }

            my $bit_name = '';

            if ( $iso_bit_arr[0] == 0 )
            {
                $bit_name = $bfm_iso_statenames{'Bit0_1'};

            }
            else
            {
                $bit_name = $bfm_iso_statenames{'Bit0_2'};
            }

            S_w2log( 4, "PD_DumpFaultMemoryTable of AB Generation $ABgeneration: Bosch fault memory\n" );
            #
            #  TODO : table function must be used normally
            #
            push(
                @TC_HTML_TEXT,
                join(
                    '', '<div class="w2rep ', $module_name, '"><TABLE class="tablesorter">',
                    '<TR>
            <TH>ID</TH>
            <TH>DTC</TH>
            <TH>faultname</TH>
            <TH>QualificationTime(sec)</TH>
            <TH>DequalificationTime(sec)</TH>
            <TH>Occurance Counter</TH>
            <TH>Qualification_PowerOn_Cycle</TH>
            <TH>Dequalification_PowerOn_Cycle</TH>
            <TH>Event Debug (Hex) </TH>
            <TH>Event Debug_HB (Hex) </TH>
            <TH>Event Debug_LB (Hex)</TH>
            <TH>General status</TH>
            <TH>Bit 7</TH>
            <TH>' . $bfm_gen_statenames{'Bit6'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit5'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit4'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit3'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit2'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit1'} . '</TH>
            <TH>' . $bfm_gen_statenames{'Bit0'} . '</TH>
            <TH>ASIC_Temperature (�C)</TH>
            <TH>Status</TH>
            <TH>Bits 7 - 1</TH>
            <TH>' . $bit_name . '</TH></TR>',
                    @table, '</TABLE></div>', "\n"
                )
            );
        }

        #Table creation for primary and plant fault memory
        else
        {
            @states = @{ $flt_mem_struct->{'state'} };

            for ( $item = 0 ; $item < @states ; $item++ )
            {
                my $iso_bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                my $iso_bittext = join( '</TD><TD>', split( //, $iso_bits ) );

                push(
                    @table, '<TR>
                            <TD>' . hex( $faults[$item] ) . '</TD>
                            <TD>' . $DTC[$item] . '</TD>
                            <TD>' . $fault_text[$item] . '</TD>
                            <TD>' . $states[$item] . '</TD>
                             <TD>' . $iso_bittext . '</TD>
                            </TR>'
                );
            }

            S_w2log( 4, "PD_DumpFaultMemoryTable of AB Generation $ABgeneration:  primary/plant fault memory \n" );
            #
            #  TODO : table function must be used normally
            #
            push(
                @TC_HTML_TEXT,
                join(
                    '', '<div class="w2rep ', $module_name, '"><TABLE class="tablesorter">',
                    '<TR>
            <TH>ID</TH>
            <TH>DTC</TH>
            <TH>faultname</TH>
            <TH>Status</TH>
            <TH>' . $iso_statenames{'Bit7'} . '</TH>
            <TH>' . $iso_statenames{'Bit6'} . '</TH>
            <TH>' . $iso_statenames{'Bit5'} . '</TH>
            <TH>' . $iso_statenames{'Bit4'} . '</TH>
            <TH>' . $iso_statenames{'Bit3'} . '</TH>
            <TH>' . $iso_statenames{'Bit2'} . '</TH>
            <TH>' . $iso_statenames{'Bit1'} . '</TH>
            <TH>' . $iso_statenames{'Bit0'} . '</TH></TR>',
                    @table, '</TABLE></div>', "\n"
                )
            );
        }
    }

    S_w2log( 5, "Dump fault memory to HTML report successfully \n" );

    return 1;
}

=head2 PD_evaluate_faults

     VERDICT = PD_evaluate_faults( $flt_mem_struct, $mandatory_faults_aref, [ $optional_faults_aref, $disjunction_faults_aref ] );
     VERDICT = PD_evaluate_faults( $flt_mem_struct, [] ); # will check for empty fault memory

mandatory: all faults have to be in fault memory (all)

optional: all faults may be in fault memory (0-all)

disjunction: at least one of the faults has to be in fault memory (1-all)

=over 3

=item * a violation of the conditions above or any other fault will set verdict fail

=item * If the given fault structure contain Faults, that are not given in parameters, verdict will be set as FAIL

=item * the faults listed by user and its corresponding presence is populated in a table for reference.

=back

returns verdict, (does not require PD_InitDiagnosis)

Error return : 0

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_evaluate_faults
{

    my $flt_struct               = shift;
    my $given_mandatory_faults   = shift;
    my $given_optional_faults    = shift;
    my $given_disjunction_faults = shift;

    my ( @expected_mandatory_list,      @expected_optional_list, @expected_disjunction_list, @remaining_faults );
    my ( @found_mandatory_list,         @found_optional_list,    @found_disjunction_list,    %found_additional_list, @ignore_disturb_list, $count );
    my ( $flag_not_all_mandatory_found, $FCMoth,                 $flag_not_one_disjunction_found, $eval_keyword, $extended_struct );
    my $OPTcomment = "";
    $eval_keyword = 'RB_FAULTS';

    #TBD: check reference type of parameters !

    # if less than $flt_mem_struct $given_mandatory_faults  -> set error
    unless ( defined $given_mandatory_faults )
    {
        S_set_error( " too less parameters ! SYNTAX: PD_evaluate_faults( flt_mem_struct , mandatory_faults_aref, [ optional_faults_aref, disjunction_faults_aref ])", 110 );
        return 0;
    }

    if ( ref($flt_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return 0;
            }
        }
    }

    #check $mandatory_faults_aref for undef elements
    if ( S_check_array( $given_mandatory_faults, "\$mandatory_faults_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    @expected_mandatory_list = @$given_mandatory_faults;

    if ( defined $given_optional_faults )
    {
        #check $optional_faults_aref for undef elements
        if ( S_check_array( $given_optional_faults, "\$optional_faults_aref" ) == 0 )
        {
            S_set_error( "S_check_array reported an error", 114 );
            return 0;
        }
        @expected_optional_list = @$given_optional_faults;
    }

    if ( exists $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} )
    {
        S_w2log( 5, " Add project defined optional faults '" . @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } . "'\n" );
        push( @expected_optional_list, @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} } );
        $OPTcomment = " with TEMP_OPTIONAL_FAULTS" if @{ $main::ProjectDefaults->{'TEMP_OPTIONAL_FAULTS'} };
    }

    if ( exists $main::ProjectDefaults->{'TEMP_DISTURB_FAULTS'} )
    {
        S_w2log( 5, " Add project defined optional disturb faults '" . @{ $main::ProjectDefaults->{'TEMP_DISTURB_FAULTS'} } . "'\n" );
        push( @ignore_disturb_list, @{ $main::ProjectDefaults->{'TEMP_DISTURB_FAULTS'} } );
        $OPTcomment .= " with TEMP_DISTURB_FAULTS" if @{ $main::ProjectDefaults->{'TEMP_DISTURB_FAULTS'} };
    }

    if ( defined $given_disjunction_faults )
    {
        #check $disjunction_faults_aref for undef elements
        if ( S_check_array( $given_disjunction_faults, "\$disjunction_faults_aref" ) == 0 )
        {
            S_set_error( "S_check_array reported an error", 114 );
            return 0;
        }
        @expected_disjunction_list = @$given_disjunction_faults;
        if ( scalar(@expected_disjunction_list) < 2 )
        {
            S_set_error( " wrong parameter !  \n PD_evaluate_faults( optional_faults has to have at least 2 elements, use mandatory instead", 109 );
            return 0;
        }
    }

    foreach my $fault ( @{ $flt_struct->{'fault_text'} } )
    {
        #add fault to additional fault list, using hash to avoid double occurence and make deleting easy !
        $found_additional_list{$fault} = 1;
    }

    foreach my $faultname (@expected_mandatory_list)
    {
        foreach my $fault ( @{ $flt_struct->{'fault_text'} } )
        {
            if ( $faultname eq $fault )
            {
                push( @found_mandatory_list, $fault );

                #delete fault from additional fault list
                delete $found_additional_list{$fault};
            }
        }
    }

    foreach my $faultname (@expected_optional_list)
    {
        foreach my $fault ( @{ $flt_struct->{'fault_text'} } )
        {
            if ( $faultname eq $fault )
            {
                push( @found_optional_list, $fault );

                #delete fault from additional fault list
                delete $found_additional_list{$fault};
            }
        }
    }

    foreach my $faultname (@expected_disjunction_list)
    {
        foreach my $fault ( @{ $flt_struct->{'fault_text'} } )
        {
            if ( $faultname eq $fault )
            {
                push( @found_disjunction_list, $fault );

                #delete fault from additional fault list
                delete $found_additional_list{$fault};
            }
        }
    }

    # now delete all allowed disturb faults from found_additional_list
    # if ALL, delete every distrub fault
    foreach my $faultname (@ignore_disturb_list)
    {
        for ( $count = 0 ; $count < scalar( @{ $flt_struct->{'fault_text'} } ) ; $count++ )
        {
            # move to optional list if only disturb bit is set
            if ( ( uc( $ignore_disturb_list[0] ) eq "ALL" or $flt_struct->{'fault_text'}[$count] eq $faultname ) and ( hex( $flt_struct->{'state'}[$count] ) == 32 ) )
            {
                push( @found_optional_list, $flt_struct->{'fault_text'}[$count] );

                #delete fault from additional fault list
                delete $found_additional_list{ $flt_struct->{'fault_text'}[$count] };
            }
        }
    }

    $flag_not_all_mandatory_found = $FCMoth = $flag_not_one_disjunction_found = 0;

    $flag_not_all_mandatory_found = 1 if ( scalar(@expected_mandatory_list) != scalar(@found_mandatory_list) );
    my @missing_mandatory_faults  = grep{ not $_ ~~ @found_mandatory_list } @expected_mandatory_list;

    $FCMoth = 1 if ( scalar( keys(%found_additional_list) ) != 0 );
    @remaining_faults = keys(%found_additional_list);

    $flag_not_one_disjunction_found = 1 if ( scalar(@found_disjunction_list) == 0 );
    
    
    ####################### Printing Evall table in HTML ########################
    my $fault_eval_table = new HTML::Table();
    $fault_eval_table->setCaption("Fault Evaluation Table");
    $fault_eval_table->addRow('FaultName','Expected Type','in fault memory');
    $fault_eval_table->setRowBGColor(1, "#E2E8EE");
    $fault_eval_table->setBorder([1]);
        
    my $row_no =1;
    my @row;
    foreach(@expected_mandatory_list)
    {
        $row_no++;
        my $index = 0;
        if($_ ~~ @found_mandatory_list)
        {
            @row = ($_,"Expected Mandatory"," Present");
            $fault_eval_table->addRow(@row);
            $fault_eval_table->setCellBGColor($row_no,3,'green');
        }
        else
        {
            @row = ($_,"Expected Mandatory","Not Present");
            $fault_eval_table->addRow(@row);
            $fault_eval_table->setCellBGColor($row_no,3,'red');
        }
    }
    
    foreach(@expected_optional_list)
    {
        $row_no++;
        my $index = 0;
        if($_ ~~ @found_optional_list)
        {
            @row = ($_,"Expected Optional","Present");
            $fault_eval_table->addRow(@row);
            $fault_eval_table->setCellBGColor($row_no,3,'green');
        }
        else
        {
            @row = ($_,"Expected Optional","not Present");
            $fault_eval_table->addRow(@row);
            #$fault_eval_table->setCellBGColor($row_no,3,'red'); No need to set Red if optional faults are not present
        }
    }
    
    foreach(@expected_disjunction_list)
    {
        $row_no++;
        my $index = 0;
        if($_ ~~ @found_disjunction_list)
        {
            @row = ($_,"Expected Disjuntion","Present");
            $fault_eval_table->addRow(@row);
            $fault_eval_table->setCellBGColor($row_no,3,'green');
        }
        else 
        {
            @row = ($_,"Expected Disjuntion","not Present");
            $fault_eval_table->addRow(@row);
            if($flag_not_one_disjunction_found)
            {
              $fault_eval_table->setCellBGColor($row_no,3,'red'); #No need to set Red if one or more Disjuntion faults are present
            }         			
        }
    }
    
    foreach(@remaining_faults)
    {
        $row_no++;
        @row = ($_,"Additional","Present");
        $fault_eval_table->addRow(@row);
        $fault_eval_table->setCellBGColor($row_no,3,'red');
    }
    
    push( @TC_HTML_TEXT,$fault_eval_table) ;
#     print LIFT_general::LOG $fault_eval_table;
#    S_w2log(3,"Eval table - $fault_eval_table");

    #$text = "\nPD_evaluate_faults$OPTcomment\n MAND: @expected_mandatory_list\n OPT: @expected_optional_list\n dist: @ignore_disturb_list\n DISJ: @expected_disjunction_list\n";

    #offline    $text .= "flags $flag_not_all_mandatory_found $FCMoth $flag_not_one_disjunction_found\n";

    ###########    SECTION FOR EVALUATION TABLE  #############

    if ( $main::ProjectDefaults->{'EVALUATION_FILE'}{'USED'} ) {
        my $expect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'EXPECT_MARKER'};
        my $detect_marker = $main::ProjectDefaults->{'EVALUATION_FILE'}{'DETECT_MARKER'};
        S_add2eval_collection( $eval_keyword, "$expect_marker @expected_mandatory_list (mand)" );
        S_add2eval_collection( $eval_keyword, "$expect_marker @expected_optional_list (opt)" ) if (@expected_optional_list);
        S_add2eval_collection( $eval_keyword, "$expect_marker @expected_disjunction_list (disj)" ) if (@expected_disjunction_list);
        S_add2eval_collection( $eval_keyword, "$detect_marker @{$flt_struct->{'fault_text'}}" );
    }
    
    my $text = '';
    ### all variants without @expected_disjunction_list
    ### OK case
    if (     not $flag_not_all_mandatory_found
         and not $FCMoth
         and not @expected_disjunction_list )
    {
        $text = "        => OK -> all expected faults found AND there is no other fault entry\n";
        S_w2log( 3, "$text \n" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
    ### FAIL cases
    elsif (     not $flag_not_all_mandatory_found
            and $FCMoth
            and not @expected_disjunction_list )
    {
        $text = "Because of additional other entries: @remaining_faults\n";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH',$text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and not $FCMoth
            and not @expected_disjunction_list )
    {
        $text = "Because of missing mandatory faults:@missing_mandatory_faults\n";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and $FCMoth
            and not @expected_disjunction_list )
    {
        $text = "Because of missing mandatory faults:@missing_mandatory_faults AND additional other entries: @remaining_faults\n";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH',$text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }

    ### all variants with @expected_disjunction_list
    ### OK case
    elsif (     not $flag_not_all_mandatory_found
            and not $FCMoth
            and $#expected_disjunction_list
            and not $flag_not_one_disjunction_found )
    {
        $text = "        => OK -> all expected faults found AND at least one of disjunction fault found AND there is no other fault entry\n";
        S_w2log( 3, "PD_evaluate_faults $text \n" );
        S_set_verdict(VERDICT_PASS);
        return VERDICT_PASS;
    }
    elsif (     not $flag_not_all_mandatory_found
            and $FCMoth
            and $#expected_disjunction_list
            and not $flag_not_one_disjunction_found )
    {
        $text = "Because of additional other entries: @remaining_faults\n";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text);
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and not $FCMoth
            and $#expected_disjunction_list
            and not $flag_not_one_disjunction_found )
    {
        $text = "Because of missing mandatory faults: @missing_mandatory_faults\n";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     not $flag_not_all_mandatory_found
            and not $FCMoth
            and $#expected_disjunction_list
            and $flag_not_one_disjunction_found )
    {
        $text = "Because of missing disjunction faults";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and not $FCMoth
            and $#expected_disjunction_list
            and $flag_not_one_disjunction_found )
    {
        $text = "Because of missing mandatory faults:@missing_mandatory_faults AND missing disjunction faults";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     not $flag_not_all_mandatory_found
            and $FCMoth
            and $#expected_disjunction_list
            and $flag_not_one_disjunction_found )
    {
        $text = "Because of missing disjunction faults AND additional other entries: @remaining_faults";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and $FCMoth
            and $#expected_disjunction_list
            and $flag_not_one_disjunction_found )
    {
        $text = "Because of missing mandatory faults:@missing_mandatory_faults AND missing disjunction faults AND additional other entries: @remaining_faults";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    elsif (     $flag_not_all_mandatory_found
            and $FCMoth
            and $#expected_disjunction_list
            and not $flag_not_one_disjunction_found )
    {
        $text = "Because of missing mandatory faults:@missing_mandatory_faults AND additional other entries: @remaining_faults";
        S_w2log( 3, "PD_evaluate_faults => FAIL -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text );
        S_set_verdict(VERDICT_FAIL);
        return VERDICT_FAIL;
    }
    else
    {
        $text = "Because of unexpected calculation....";
        S_w2log( 3, "PD_evaluate_faults  => INCONC -> $text \n" );
        S_add2eval_collection( 'MISMATCH', $text);
        S_set_verdict(VERDICT_INCONC);
        return VERDICT_INCONC;
    }

}

=head2 PD_fast_fault_quali

     PD_fast_fault_quali( $flag );

     $flag = ENABLE  or "ENABLE"  or 1 for enabling
     $flag = DISABLE or "DISABLE" or 0 for disabling

enable or disable fast fault qualification by setting S_PDMProgVarTbl1_XXE.V_ProdMode_U16X
(and if required S_PDMProgVarTbl2_XXE.V_ProdMode_U16X). Performs ECU reset that changes take place.

calls internally  PD_ClearMemoryBits('S_PDMProgVarTbl1_XXE.V_ProdMode_U16X',['Fault Quali Time']);
or                PD_SetMemoryBits('S_PDMProgVarTbl1_XXE.V_ProdMode_U16X',['Fault Quali Time']);

requires ProjectDefaults->{'CRC_AREA'}{'PROG_VAR_TBL'}

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_fast_fault_quali
{
    my $flag = shift;
    my ( $address, $value_aref, $ProgVarTbl );

    unless ( defined($flag) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_fast_fault_quali( flag )", 110 );
        return 0;
    }

    S_w2log( 4, "PD_fast_fault_quali :: $flag\n" );

    unless ( defined( $main::ProjectDefaults->{'CRC_AREA'}{'PROG_VAR_TBL'} ) )
    {
        S_set_error( "PROG_VAR_TBL not defined in Project Defaults CRC_AREA", 110 );
        return 0;
    }

    $ProgVarTbl = $main::ProjectDefaults->{'CRC_AREA'}{'PROG_VAR_TBL'};

    if ( $flag eq "1" or $flag eq "ENABLE" )
    {
        $flag = ENABLE;
    }
    elsif ( $flag eq "0" or $flag eq "DISABLE" )
    {
        $flag = DISABLE;
    }
    else
    {
        S_set_error( "! unknown flag $flag", 110 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_fast_fault_quali' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    # if defined S_PDMProgVarTbl1_XXE.V_ProdMode_U16X
    ( $stat, $address ) = pd_GetAddressByName('S_PDMProgVarTbl1_XXE.V_ProdMode_U16X');
    if ( $stat >= 0 )
    {
        if ( $flag == ENABLE )
        {
            PD_SetMemoryBits( 'S_PDMProgVarTbl1_XXE.V_ProdMode_U16X', ['Fault Quali Time'] );
        }
        elsif ( $flag == DISABLE )
        {
            PD_ClearMemoryBits( 'S_PDMProgVarTbl1_XXE.V_ProdMode_U16X', ['Fault Quali Time'] );
        }
        else { S_set_error( "unknown flag $flag", 110 ); return 0; }
    }
    else
    {
        S_set_error( "S_PDMProgVarTbl1_XXE.V_ProdMode_U16X not found", 109 );

        # return on error to avoid checksum problem
        return 0;
    }

    # if defined S_PDMProgVarTbl2_XXE.V_ProdMode_U16X change accordingly !
    ( $stat, $address ) = pd_GetAddressByName('S_PDMProgVarTbl2_XXE.V_ProdMode_U16X');
    if ( $stat >= 0 )
    {
        if ( $flag == ENABLE )
        {
            PD_SetMemoryBits( 'S_PDMProgVarTbl2_XXE.V_ProdMode_U16X', ['Fault Quali Time'] );
        }
        elsif ( $flag == DISABLE )
        {
            PD_ClearMemoryBits( 'S_PDMProgVarTbl2_XXE.V_ProdMode_U16X', ['Fault Quali Time'] );
        }
        else { S_set_error( "unknown flag $flag", 110 ); return 0; }
    }

    $stat = pd_CalculateChecksum($ProgVarTbl);
    check_status($stat);
    S_w2log( 5, "PD_fast_fault_quali: pd_CalculateChecksum of $ProgVarTbl - $stat \n" );
    $stat = pd_ECUreset(0);
    S_w2log( 5, "PD_fast_fault_quali: pd_ECUreset - $stat \n" );
    check_status($stat);

    return 1;
}

=head2 PD_FreezeFaultMemory

   PD_FreezeFaultMemory();

   To freeze the fault memory.

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_FreezeFaultMemory
{

    S_w2log( 4, "PD_FreezeFaultMemory \n" );

    my $response_aref;
    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    if ( $ABgeneration < 12 )
    {
        S_set_error( "The function 'PD_FreezeFaultMemory' is not currently support for AB10 project \n", 20 );
        return 0;
    }

    ( $stat, $response_aref ) = pd_FreezeFaultMemory();
    S_w2log( 5, "pd_FreezeFaultMemory status : $stat\n" );
    check_status($stat);
    S_w2log( 5, "End PD_FreezeFaultMemory \n" );
    return 1;
}

=head2 PD_get_fault_index

     $index = PD_get_fault_index( $flt_mem_struct, $fault_name );

returns the index (starting from 0) for corresponding fault , -1 if not exists, (does not require PD_InitDiagnosis)

Error return : -1

Success return :: Index of fault

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_fault_index
{
    my $flt_mem_struct = shift;
    my $fault_name     = shift;

    my $extended_struct;

    unless ( defined($fault_name) )
    {
        S_set_error( "! too less parameters ! SYNTAX: status = PD_get_fault_index( flt_mem_struct, fault_name )", 110 );
        return -1;
    }

    S_w2log( 4, "PD_get_fault_index :: $fault_name\n" );

    if ( ref($flt_mem_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return -1;
    }

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_mem_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return -1;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return -1;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_mem_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return -1;
            }
        }
    }

    foreach my $index ( 0 .. @{ $flt_mem_struct->{'fault_text'} } - 1 )
    {
        # compare each fault in lowercase (case insensitive)
        if ( lc( $flt_mem_struct->{'fault_text'}[$index] ) eq lc($fault_name) )
        {
            S_w2log( 3, " PD_get_fault_index: $fault_name has index $index\n" );
            return ($index);
        }
    }

    S_w2log( 3, " PD_get_fault_index: $fault_name not found\n" );
    return -1;

}

=head2 PD_get_fault_info

     $info = PD_get_fault_info( $flt_mem_struct, $fault_name );

returns the additional fault info for corresponding fault in bin e.g. 0b0100, 0 if not exists, (does not require PD_InitDiagnosis)

Error return : 0

Success return :: Info of fault

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_fault_info
{
    my $flt_mem_struct = shift;
    my $fault_name     = shift;

    my $extended_struct;

    unless ( defined($fault_name) )
    {
        S_set_error( "! too less parameters ! SYNTAX: info = PD_get_fault_info( flt_mem_struct, fault_name )", 110 );
        return 0;
    }

    if ( ref($flt_mem_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    S_w2log( 4, "PD_get_fault_info :: $fault_name\n" );

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_mem_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_mem_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return 0;
            }
        }
    }

    foreach my $index ( 0 .. @{ $flt_mem_struct->{'fault_text'} } - 1 )
    {
        # compare each fault in lowercase (case insensitive)
        if ( lc( $flt_mem_struct->{'fault_text'}[$index] ) eq lc($fault_name) )
        {
            my $info = $flt_mem_struct->{'info'}[$index];
            S_w2log( 3, " PD_get_fault_info: $fault_name has info $info\n" );
            return ($info);
        }
    }
    S_w2log( 3, " PD_get_fault_info: $fault_name not found\n" );

    return 0;
}

=head2 PD_get_fault_status

     $status = PD_get_fault_status( $flt_mem_struct, $fault_name );

returns the status byte for corresponding fault in hex e.g. 0x1f, 0 if not exists, (does not require PD_InitDiagnosis)

Error return : 0

Success return :: Status of fault

Refer L</"SYNOPSIS"> for Fault memory bit description details

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_fault_status
{
    my $flt_mem_struct = shift;
    my $fault_name     = shift;
    my $extended_struct;

    unless ( defined($fault_name) )
    {
        S_set_error( "! too less parameters ! SYNTAX: status = PD_get_fault_status( flt_mem_struct, fault_name )", 110 );
        return 0;
    }

    S_w2log( 4, "PD_get_fault_status :: $fault_name \n" );

    if ( ref($flt_mem_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_mem_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_mem_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_mem_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return 0;
            }
        }
    }

    foreach my $index ( 0 .. @{ $flt_mem_struct->{'fault_text'} } - 1 )
    {
        # compare each fault in lowercase (case insensitive)
        if ( lc( $flt_mem_struct->{'fault_text'}[$index] ) eq lc($fault_name) )
        {
            my $status = $flt_mem_struct->{'state'}[$index];
            S_w2log( 3, " PD_get_fault_status: $fault_name has status $status\n" );
            return ($status);
        }
    }

    S_w2log( 3, " PD_get_fault_status: $fault_name not found\n" );
    return 0;

}

=head2 PD_get_faults

     $string = PD_get_faults( $flt_mem_struct );

returns string with fault table, (does not require PD_InitDiagnosis)

Error return : 0

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_faults
{
    my $flt_struct = shift;
    my ( $item, $output );

    my $extended_struct;

    unless ( defined($flt_struct) )
    {
        S_set_error( "! too less parameters ! SYNTAX: string = PD_get_faults( flt_mem_struct )", 110 );
        return 0;
    }

    if ( ref($flt_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    #check whether the $flt_mem_struct is in correct format
    $extended_struct = 0;    #flag to indicate whether the structure contains extended fault info
    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #set $extended_struct = 1, if Extendedfaultinfo found
        if ( ( exists $flt_struct->{$keyvalue} ) && ( $flt_mem_keys{$keyvalue} == 0 ) )
        {
            $extended_struct = 1;
        }
    }

    foreach my $keyvalue ( keys %flt_mem_keys )
    {
        #check, if all mandatory keys are present
        if ( not exists $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} does not exists", 114 );
                return 0;
            }
        }

        #check, if all mandatory keys are defined
        elsif ( not defined $flt_struct->{$keyvalue} )
        {
            if ( ( $flt_mem_keys{$keyvalue} == 1 ) || ( $extended_struct == 1 ) )
            {
                S_set_error( " \$flt_mem_struct->{'$keyvalue'} is not defined", 114 );
                return 0;
            }
        }
        else
        {    #check if all key's array reference contains defined array elements
            if ( S_check_array( $flt_struct->{$keyvalue}, "\$flt_mem_struct->{'$keyvalue'}" ) == 0 )
            {
                S_set_error( "S_check_array reported an error", 114 );
                return 0;
            }
        }
    }

    $output = "";
    foreach my $key ( sort keys %$flt_struct )
    {
        $output .= "$key ; ";
    }
    chop($output);
    chop($output);
    $output .= "\n";

    for ( $item = 0 ; $item < @{ $flt_struct->{'fltnum'} } ; $item++ )
    {
        foreach my $key ( sort keys %$flt_struct )
        {
            $output .= "$flt_struct->{$key}[$item] ; ";
        }
        chop($output);
        chop($output);
        $output .= "\n";
    }

    S_w2log( 4, "PD_get_faults: available faults are $output \n" );
    return ($output);
}

=head2 PD_GetExtendedFaultInformation

    $fault_HoA = PD_GetExtendedFaultInformation([nType]);

Optional parameter : nType - 0, 1, 3, 4, PLANT_FLT_MEM, PRIMARY_FLT_MEM, BOSCH_FLT_MEM, DISTURBANCE_FLT_MEM

    $fault_HoA = PD_GetExtendedFaultInformation();  #Primary and Bosch (Default Value) (Return data of PRIMARY only)
    $fault_HoA = PD_GetExtendedFaultInformation(0); #Plant
    $fault_HoA = PD_GetExtendedFaultInformation(1); #Primary
    $fault_HoA = PD_GetExtendedFaultInformation(3); #Bosch
    $fault_HoA = PD_GetExtendedFaultInformation(4); #Disturbance
    $fault_HoA = PD_GetExtendedFaultInformation(PLANT_FLT_MEM);
    $fault_HoA = PD_GetExtendedFaultInformation(PRIMARY_FLT_MEM);
    $fault_HoA = PD_GetExtendedFaultInformation(BOSCH_FLT_MEM);
    $fault_HoA = PD_GetExtendedFaultInformation(DISTURBANCE_FLT_MEM);

This function reads and returns the fault memory structure.

AB12 :: nType Optional, if not given -> Read Primary and Bosch (write both to the report), but return only data of Primary.

0 - Plant
1 - Primary
3 - Bosch
4 - Disturbance

AB10 :: No need of nType

B<Example :>

B<AB12>

See L</PD_ReadFaultMemory>

B<AB10>

    $fault_HoA = {
           'info_txt' => [
                          '',
                          ''
                        ],
          'info' => [
                      '0b000000',
                      '0b000001'
                    ],
          'fault_text' => [
                            'FltEOLNotProgrammed',
                            'FltCRCRamFault'
                          ],
          'DTC' => [
                     'A01300',
                     '00004A'
                   ],
          'state_txt' => [
                           'disturb+latched',
                           'active+current+stored+latched+filtered'
                         ],
          'fltnum' => [
                        'bc',
                        '11'
                      ],
          'state' => [
                       '0x22',
                       '0x1f'
                     ]
          'EventDebug' => [],                    #not Support for AB10
          'EventDebug_HB' => [],                 #not Support for AB10
          'EventDebug_LB' => [],                 #not Support for AB10
          'Qualification_poweron_cycle' => [],   #not Support for AB10
          'OccuranceCounter' => [],              #not Support for AB10
          'DisturbanceCounter' => [],            #not Support for AB10
          'QualificationTime' => [],             #not Support for AB10
          'GeneralState' => [],                  #not Support for AB10
          'DisturbanceState_text' => [],         #not Support for AB10
          'Dequalification_poweron_cycle' => [], #not Support for AB10
          'DisturbanceState' => [],              #not Support for AB10
          'DequalificationTime' => []            #not Support for AB10
        };

B<General Fault Structure Description>

See L</PD_ReadFaultMemory>

B<offline + Error return>

See L</PD_ReadFaultMemory>

B<Note:> Supported AB Generations:: B<10 and 12>

=cut
sub PD_GetExtendedFaultInformation {
    my $nType = shift;
    my ( @faults, @fault_text, @DTC, @states, @addInfo, @addInfo_text, @state_text, @ApTime, @DisTime, @PonCnt,@SpoCnt );
    my ( $item, $value, $fault_HoA, @table, $text );

    my $dummy_return = {
        "fltnum"                => [],
        "fault_text"            => [],
        "DTC"                   => [],
        "state"                 => [],
        "DisturbanceState"      => [],
        "GeneralState"          => [],
        "ApTime"                => [],
        "DisTime"               => [],
        "PonCnt"                => [],
        "SpoCnt"                => [],
        "state_txt"             => [],
        "DisturbanceState_text" => [],
        "GeneralState_text"     => [],
        "info"                  => [],
        "info_txt"              => [],

        #Extra Information from both disturbance & Bosch fault memory
        "EventDebug"                    => [],    # Holds event values in DFM and BFM respectively
        "EventDebug_HB"                 => [],    # Holds event high byte values in DFM and BFM respectively
        "EventDebug_LB"                 => [],    # Holds event low byte values in DFM and BFM respectively
        "OccuranceCounter"              => [],    # Holds Occurance counter in BFM
        "DisturbanceCounter"            => [],    # Holds disturbance counter value in DFM
                                                  # Extra Information from only Bosch fault memory
        "QualificationTime"             => [],
        "DequalificationTime"           => [],
        "Qualification_poweron_cycle"   => [],
        "Dequalification_poweron_cycle" => [],
        "ASIC_Temperature"              => [],
    };

    unless ($PD_initialized) {
        S_set_error( "PD not initialized", 120 );
        return $dummy_return;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive) {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $dummy_return;
    }

    return $dummy_return if $main::opt_offline;
    if ( $ABgeneration < 12 ) {

        unless ( defined $nType ) {

            # Default: Primary Fault Memory type
            $nType = 1;
            S_w2log( 3," PD_GetExtendedFaultInformation: Read Primary Fault Memory (Default setting nType: $nType) \n" );
        }

        my ( $IDs, $DTCs, $names, $states, $info, $fiApTime, $laDisTime, $PonCnt, $SpoCnt );
        ( $stat, $IDs, $DTCs, $names, $states, $info, $fiApTime, $laDisTime, $PonCnt, $SpoCnt ) = pd_ReadExtendedFaultMemory($nType);

        @faults     = @$IDs;
        @DTC        = @$DTCs;
        @fault_text = @$names;
        @states     = @$states;
        @PonCnt     = @$PonCnt;
        @SpoCnt     = @$SpoCnt;
        @ApTime     = @$fiApTime;
        @DisTime    = @$laDisTime;
        @addInfo    = @$info;

        #HTML output
        check_status($stat) || return;
        S_w2log( 5, "pd_ReadExtendedFaultMemory status is ($stat):\n" );

        if (@states) {
            @table = ();
            $text  = "ID; DTC; faultname; status; Add Faultinfo; ApTime; DisTime; Pon; Spo\n";

            for ( $item = 0 ; $item < @states ; $item++ ) {
                if ( hex( $states[$item] ) & 128 ) { $state_text[$item] .= "bit_7+" }
                if ( hex( $states[$item] ) & 64 )  { $state_text[$item] .= "bit_6+" }
                if ( hex( $states[$item] ) & 32 )  { $state_text[$item] .= "disturb+" }
                if ( hex( $states[$item] ) & 16 )  { $state_text[$item] .= "active+" }
                if ( hex( $states[$item] ) & 8 )   { $state_text[$item] .= "current+" }
                if ( hex( $states[$item] ) & 4 )   { $state_text[$item] .= "stored+" }
                if ( hex( $states[$item] ) & 2 )   { $state_text[$item] .= "latched+" }
                if ( hex( $states[$item] ) & 1 )   { $state_text[$item] .= "filtered+" }
                chop( $state_text[$item] );    # cut off trailing +

                $states[$item] = '0x' . $states[$item];

                my $bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                my $bittext = join( '</TD><TD>', split( //, $bits ) );
                $bittext =~ s/0/-/g;
                $bittext =~ s/1/X/g;

                my @infos = split( /,/, $addInfo[$item] );
                my ( $infobits, $infotext );
                $infobits = $infotext = '';
                foreach my $temp (@infos) {
                    $temp =~ /^(\d+)\s+(.+)$/;
                    my $bit = $1;
                    my $txt = $2;

                    # append infobits
                    $infobits = $bit . $infobits;

                    #append info text if bit is set and text not only blanks or empty
                    $infotext = $txt . "," . $infotext if ( $bit > 0 and $txt !~ /^\s*$/ );
                }
                chop($infotext);    # cut off trailing ,
                $addInfo_text[$item] = $infotext;
                $addInfo[$item]      = "0b" . $infobits;

                $infotext = $addInfo[$item] . "<br>" . $addInfo_text[$item];

                if ( $ApTime[$item] eq 'ffffffff' ) {
                    $ApTime[$item] = '-';
                }
                else {
                    $ApTime[$item] = S_formated_ECUtime( '0x' . $ApTime[$item] );
                }

                if ( $DisTime[$item] eq 'ffffffff' ) {
                    $DisTime[$item] = '-';
                }
                else {
                    $DisTime[$item] = S_formated_ECUtime( '0x' . $DisTime[$item] );
                }

                $PonCnt[$item] = '-' if ( $PonCnt[$item] eq 'ffffffff' );
                $SpoCnt[$item] = '-' if ( $SpoCnt[$item] eq 'ffffffff' );

                #HTML output
                push( @table,
                        '<TR><TD>'
                      . hex( $faults[$item] )
                      . '</TD><TD>'
                      . $DTC[$item]
                      . '</TD><TD>'
                      . $fault_text[$item]
                      . '</TD><TD>'
                      . $states[$item]
                      . '</TD><TD>'
                      . $bittext
                      . '</TD><TD>'
                      . $infotext
                      . '</TD><TD>'
                      . $ApTime[$item]
                      . '</TD><TD>'
                      . $DisTime[$item]
                      . '</TD><TD>'
                      . $PonCnt[$item]
                      . '</TD><TD>'
                      . $SpoCnt[$item]
                      . '</TD></TR>' );
                $text .= hex( $faults[$item] )
                  . "; $DTC[$item]; $fault_text[$item]; $states[$item]; $addInfo[$item]; $ApTime[$item]; $DisTime[$item]; $PonCnt[$item]; $SpoCnt[$item]\n";

            }

            #HTML output
            #
            #  TODO : table function must be used normally
            #
            S_w2log( 4, "PD_GetExtendedFaultInformation of AB Generation $ABgeneration\n" );

            push(
                @TC_HTML_TEXT,
                join( '',
                    '<div class="w2rep ',
                    $module_name,
                    '"><TABLE class="tablesorter">',
                    '<TR><TH>ID</TH><TH>DTC</TH><TH>faultname</TH><TH>status</TH>',
                    '<TH>7</TH><TH>6</TH><TH>D</TH><TH>A</TH><TH>C</TH><TH>S</TH><TH>L</TH><TH>F</TH>',
                    '<TH>Add Faultinfo</TH><TH>ApTime</TH><TH>DisTime</TH><TH>Pon</TH><TH>Spo</TH></TR>',
                    @table,
                    '</TABLE></div>',"\n" )
            );
            print $text unless $main::opt_silent;
            print LIFT_general::LOG $text;

        }
        else {
            S_w2log( 3, "The fault memory is empty.\n" );
        }

        $fault_HoA = {
            "fltnum"                => [@faults],
            "fault_text"            => [@fault_text],
            "DTC"                   => [@DTC],
            "state"                 => [@states],
            "DisturbanceState"      => [],
            "GeneralState"          => [],
            "ApTime"                => [@ApTime],
            "DisTime"               => [@DisTime],
            "PonCnt"                => [@PonCnt],
            "SpoCnt"                => [@SpoCnt],
            "state_txt"             => [@state_text],
            "DisturbanceState_text" => [],
            "GeneralState_text"     => [],
            "info"                  => [@addInfo],
            "info_txt"              => [@addInfo_text],

            #Extra Information from both disturbance & Bosch fault memory
            "EventDebug"                    => [],    # Holds event values in DFM and BFM respectively
            "EventDebug_HB"                 => [],    # Holds event high byte values in DFM and BFM respectively
            "EventDebug_LB"                 => [],    # Holds event low byte values in DFM and BFM respectively
            "OccuranceCounter"              => [],    # Holds Occurance counter in BFM
            "DisturbanceCounter"            => [],    # Holds disturbance counter value in DFM
                                                      #Extra Information from only Bosch fault memory
            "QualificationTime"             => [],
            "DequalificationTime"           => [],
            "Qualification_poweron_cycle"   => [],
            "Dequalification_poweron_cycle" => [],
        };
    }

    if ( $ABgeneration == 12 ) {

        my $fault_type_text = "";

        if (
            not defined $nType
          )    # first check for "not defined" then later check for "== 0", because "undef == 0" with == operator!
        {
            # Default: Primary Fault Memory type
            S_w2log( 3," PD_GetExtendedFaultInformation: No specfic Fault Type defined -> DEFAULT Handling of Reading Fault Memory\n");
            S_w2log( 3," PD_GetExtendedFaultInformation: -> Step1: BOSCH Fault Memory Type will be READ + PRINTED ( option 3 ) \n");
            S_w2log( 3," PD_GetExtendedFaultInformation: -> Step2: PRIMARY Fault Memory Type will be READ + PRINTED + RETURNED ( option 1 )\n");

            S_w2log( 3, "\n" );
            S_w2log( 3," PD_GetExtendedFaultInformation: BOSCH Fault Memory Type - (Read+Print only) Processing ... \n" );
            ReadFaultMemory_AB12(3);

            $nType           = 1;
            $fault_type_text = "PRIMARY";

            # processing now like option 1
        }
        elsif ( $nType == 0 ) { $fault_type_text = "PLANT"; }
        elsif ( $nType == 1 ) { $fault_type_text = "PRIMARY"; }
        elsif ( $nType == 3 ) { $fault_type_text = "BOSCH"; }
        elsif ( $nType == 4 ) { $fault_type_text = "DISTURBANCE"; }
        else {
            S_set_error(" Wrong argument given : $nType (only 0 , 1 , 3 , 4 or nothing (default) is implemented)\n");
            return {};
        }

        S_w2log( 3," PD_GetExtendedFaultInformation: $fault_type_text Fault Memory Type (option $nType) - Processing ... \n" );
        $fault_HoA = ReadFaultMemory_AB12($nType);
        unless ($fault_HoA) {
            S_w2log( 3, " Call of ReadFaultMemory_AB12($nType) not successful\n" );    # error set in called function
            return;
        }

        S_w2log( 3," PD_GetExtendedFaultInformation: Returning Data of $fault_type_text Fault Memory Type (option $nType)\n" );

        #Below empty keys are added as to maintain consistency with AB10 return hash for extended fault memory
        $$fault_HoA{"ApTime"}  = [];
        $$fault_HoA{"DisTime"} = [];
        $$fault_HoA{"PonCnt"}  = [];
        $$fault_HoA{"SpoCnt"}  = [];
    }

    return ($fault_HoA);
}


=head2 PD_GetFaultAttribute

    $data = PD_GetFaultAttribute( $flt_mem_struct, $fault_name, $key);

All parameters are mandatory

$flt_mem_struct :: Fault memory structure read from PD_ReadFaultMemory()

$fault_name :: Name of fault to which key value to be read

$key :: Can be any of below given attributes

fltnum/fault_text/DTC/state/state_txt/info/info_txt

DisturbanceState/GeneralState/DisturbanceState_text/GeneralState_text

EventDebug/EventDebug_HB/EventDebug_LB/OccuranceCounter/DisturbanceCounter/ QualificationTime

DequalificationTime/ Qualification_poweron_cycle/ Dequalification_poweron_cycle/ ASIC_Temperature 

Returns data for given key. (does not require PD_InitDiagnosis)

Error/Offline return : 0

Success return :: data of key for given fault

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetFaultAttribute
{
    my $flt_mem_struct = shift;
    my $fault_name     = shift;
    my $key            = shift;

    if ( not defined($key) )
    {
        S_set_error( "! too less parameters ! SYNTAX: data = PD_GetFaultAttribute( flt_mem_struct, fault_name, key)", 110 );
        return 0;
    }

    S_w2log( 4, "PD_GetFaultAttribute for fault name $fault_name and key $key\n" );

    if ( ref($flt_mem_struct) ne "HASH" )
    {
        S_set_error( " flt_mem_struct is not a hash reference", 114 );
        return 0;
    }

    if ( scalar( keys %$flt_mem_struct ) <= 0 )
    {
        S_set_error( " flt_mem_struct is empty hash \n", 114 );
        return 0;
    }

    if ( !exists $flt_mem_struct->{$key} )
    {
        S_set_error( "  $key doestnot exists in given fault memory structure \n", 114 );
        return 0;
    }

    if ( ref( $flt_mem_struct->{$key} ) ne "ARRAY" )
    {
        S_set_error( " $key data is not an array reference \n", 114 );
        return 0;
    }

    return 0 if $main::opt_offline;

    foreach my $index ( 0 .. @{ $flt_mem_struct->{'fault_text'} } - 1 )
    {
        # compare each fault in lowercase (case insensitive)
        if ( lc( $flt_mem_struct->{'fault_text'}[$index] ) eq lc($fault_name) )
        {
            my $data = $flt_mem_struct->{$key}[$index];
            S_w2log( 4, " PD_GetFaultAttribute: $fault_name has status $data\n" );
            return ($data);
        }
    }

    S_w2log( 4, " PD_GetFaultAttribute: $fault_name not found\n" );
    return 0;
}

=head2 PD_GetFaultID

    $FaultID = PD_GetFaultID( $FLTname );

get fault ID from fault name

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetFaultID
{
    my $FLTname = shift;
    my $FLTid;
    unless ( defined($FLTname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: FaultID = PD_GetFaultID( FLTname )", 110 );
        return 0;
    }

    S_w2log( 4, "PD_GetFaultID ($FLTname)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    return 1 if $main::opt_offline;
    ( $stat, $FLTid ) = pd_GetFLTIDByFLTName($FLTname);
    check_status($stat);
    S_w2log( 5, "pd_GetFLTIDByFLTName status:  $stat\n" );

    S_w2log( 4, "PD_GetFaultID:Fault name ($FLTname) - Fault Id $FLTid \n" );
    return ($FLTid);
}

=head2 PD_getISOdata

    ( $ISOnr, $ISObyte, $ISObit, $ISOmask0, $ISOmask1 ) = PD_getISOdata( $FLTname );

     e.g. ( 188, 23, 4,"0bxxx0xxxx", "0bxxx1xxxx" ) = PD_getISOdata("FltAB1FDResistanceOpen");

get ISO fault data from fault name. calculates byte and bit position in ISO array.

offline + Error return = (1,1,1,"0b0","0b1")

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_getISOdata
{
    my $FLTname = shift;
    my ( $FLTid, $ISO_state_byte, $ISObitnr, $ISO_state_mask0, $ISO_state_mask1 );

    my @dummy_return = ( 1, 1, 1, "0b0", "0b1" );

    unless ( defined($FLTname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: ( ISOnr, ISObyte, ISObit, ISOmask0, ISOmask1 ) = PD_getISOdata( FLTname )", 110 );
        return @dummy_return;
    }

    S_w2log( 4, "PD_getISOdata ($FLTname) \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return @dummy_return;
    }

    return @dummy_return if $main::opt_offline;
    ( $stat, $FLTid ) = pd_GetFLTIDByFLTName($FLTname);
    check_status($stat);
    if ( $stat >= 0 )
    {
        $ISO_state_byte  = int( $FLTid / 8 );
        $ISObitnr        = $FLTid % 8;
        $ISO_state_mask1 = '0b' . ( 'x' x ( 7 - $ISObitnr ) ) . '1' . ( 'x' x $ISObitnr );
        $ISO_state_mask0 = '0b' . ( 'x' x ( 7 - $ISObitnr ) ) . '0' . ( 'x' x $ISObitnr );
        S_w2log( 4, "PD_getISOdata $FLTname: $FLTid, $ISO_state_byte, $ISObitnr, $ISO_state_mask0, $ISO_state_mask1\n" );
        return ( $FLTid, $ISO_state_byte, $ISObitnr, $ISO_state_mask0, $ISO_state_mask1 );
    }
    else { return @dummy_return; }
}

=head2 PD_getISOfaultbits

    $faultbits = PD_getISOfaultbits( $FLTname );

     e.g. 0b00101100 = PD_getISOfaultbits("FltAB1FDResistanceOpen");

get ISO fault bits from RAM variables for fault name. WIR is always 0 since this can not be displayed.

returns in following order:  WIR TNCTOC TFSLC TNCSLC CDTC PDTC TFTOC TF

calls internally PD_getISOdata

offline + Error return = 0b00000000

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_getISOfaultbits
{
    my $FLTname = shift;
    my ( $FLTid, $ISO_state_byte, $ISObitnr, $ISO_state_mask0, $ISO_state_mask1 );
    my ( $WIR, $TNCTOC, $TFSLC, $TNCSLC, $CDTC, $PDTC, $TFTOC, $TF ) = ( 0, 0, 0, 0, 0, 0, 0, 0 );
    my ( $value_aref, $fltnum );

    my $dummy_return = '0b00000000';

    unless ( defined($FLTname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: faultbits = PD_getISOfaultbits( FLTname )", 110 );
        return $dummy_return;
    }

    S_w2log( 4, "PD_getISOfaultbits($FLTname)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return $dummy_return;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_getISOfaultbits' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $dummy_return;
    }

    return $dummy_return if $main::opt_offline;

    ( $FLTid, $ISO_state_byte, $ISObitnr, $ISO_state_mask0, $ISO_state_mask1 ) = PD_getISOdata($FLTname);

    my $check = 1 << $ISObitnr;

    ( $stat, $value_aref ) = pd_ReadName("A_FLIFltLatched_U8R($ISO_state_byte)");
    check_status($stat);
    $TFTOC = ( S_0x2dec( $$value_aref[0] ) & $check ) / $check;

    ( $stat, $value_aref ) = pd_ReadName("A_FLIFltPending_U8R($ISO_state_byte)");
    check_status($stat);
    $PDTC = ( S_0x2dec( $$value_aref[0] ) & $check ) / $check;

    ( $stat, $value_aref ) = pd_ReadName("A_FLITestCompletedSLC_U8R($ISO_state_byte)");
    check_status($stat);
    $TNCSLC = ( ( S_0x2dec( $$value_aref[0] ) & $check ) / $check );    # negated
    if   ( $TNCSLC == 1 ) { $TNCSLC = 0; }
    else                  { $TNCSLC = 1; }

    ( $stat, $value_aref ) = pd_ReadName("A_FLITestFailedSLC_U8R($ISO_state_byte)");
    check_status($stat);
    $TFSLC = ( S_0x2dec( $$value_aref[0] ) & $check ) / $check;

    ( $stat, $value_aref ) = pd_ReadName("A_FLITestPassedTOC_U8R($ISO_state_byte)");
    check_status($stat);
    my $tptoc = ( S_0x2dec( $$value_aref[0] ) & $check ) / $check;
    $TNCTOC = ( $TFSLC | $tptoc );                                      # negated
    if   ( $TNCTOC == 1 ) { $TNCTOC = 0; }
    else                  { $TNCTOC = 1; }

    ( $stat, $value_aref ) = pd_ReadName("A_FLMFltFiltered_U8R($ISO_state_byte)");
    check_status($stat);
    $TF = ( S_0x2dec( $$value_aref[0] ) & $check ) / $check;

    my $maxfaults;
    ( $stat, $value_aref ) = pd_ReadName("V_FltMemRamSize_U8C");
    check_status($stat);
    $maxfaults = S_0x2dec( $$value_aref[0] );

    # search for fault in fault memory and check if stored
    my $count = 0;
    $fltnum = 99999;
    while ( $fltnum != $FLTid and $fltnum != 0 and $count < $maxfaults )
    {
        ( $stat, $value_aref ) = pd_ReadName("A_FLMFltMemNbr_U16R($count)");
        check_status($stat);
        $fltnum = S_aref2dec( $value_aref, U16 );

        # remove additional fault info to check if monitored cells match extected fault
        $fltnum &= ~0b1111110000000000;
        $count++ unless ( $fltnum == $FLTid );    #increment $count, only if $FLTid is not found in A_FLMFltMemNbr_U16R($count)
    }
    if ( $fltnum == $FLTid )
    {
        ( $stat, $value_aref ) = pd_ReadName("A_FLMFltMemState_U8R($count)");
        check_status($stat);
        $CDTC = ( S_0x2dec( $$value_aref[0] ) & 0b100 ) / 0b100;
    }
    else { $CDTC = 0; }

    S_w2log( 4, "PD_getISOfaultbits($FLTname) ,$WIR, $TNCTOC, $TFSLC, $TNCSLC, $CDTC, $PDTC, $TFTOC, $TF\n" );

    return ( join( '', '0b', $WIR, $TNCTOC, $TFSLC, $TNCSLC, $CDTC, $PDTC, $TFTOC, $TF ) )

}

=head2 PD_ReadFaultMemory

    $fault_HoA = PD_ReadFaultMemory([nType]);

Optional parameter : nType - 0, 1, 3, 4, PLANT_FLT_MEM, PRIMARY_FLT_MEM, BOSCH_FLT_MEM, DISTURBANCE_FLT_MEM

    $fault_HoA = PD_ReadFaultMemory();  #Primary and Bosch (Default Value) (Return data of PRIMARY only)
    $fault_HoA = PD_ReadFaultMemory(0); #Plant
    $fault_HoA = PD_ReadFaultMemory(1); #Primary
    $fault_HoA = PD_ReadFaultMemory(3); #Bosch
    $fault_HoA = PD_ReadFaultMemory(4); #Disturbance
    $fault_HoA = PD_ReadFaultMemory(PLANT_FLT_MEM);
    $fault_HoA = PD_ReadFaultMemory(PRIMARY_FLT_MEM);
    $fault_HoA = PD_ReadFaultMemory(BOSCH_FLT_MEM);

This function reads and returns the fault memory structure.

AB12 ::
nType Optional, default value '1'

0 - Plant
1 - Primary
3 - Bosch
4 - Disturbance

AB10 ::
No need of nType

=head3 Fault memory structure:

B<Example :>

B<AB12 Plant>

    $fault_HoA = {
          'fault_text' => [
                            'rb_spi_SpiRcvMsgCrcWrong_flt',
                            'rb_sdm_SectionInvalid_flt'
                          ],
          'state' => [
                       '0x2e',
                       '0x2f'
                     ],
          'DTC' => [
                     'F00049',
                     'F00049'
                   ],
          'fltnum' => [
                        '313',
                        '244'
                      ],
          'state_txt' => [
                           'Test_failed_since_last_clear+Confirmed_DTC_Stored+Pending+Test_failed_this_operation_cycle_Latched',
                           'Test_failed_since_last_clear+Confirmed_DTC_Stored+Pending+Test_failed_this_operation_cycle_Latched+Test_failed_Filtered'
                         ],
          'info' => [],                          #not Support for plant memory
          'EventDebug' => [],                    #not Support for plant memory
          'EventDebug_HB' => [],                 #not Support for plant memory
          'EventDebug_LB' => [],                 #not Support for plant memory
          'GeneralState_text' => [],             #not Support for plant memory
          'DequalificationTime' => []            #not Support for plant memory
          'Qualification_poweron_cycle' => [],   #not Support for plant memory
          'OccuranceCounter' => [],              #not Support for plant memory
          'QualificationTime' => [],             #not Support for plant memory
          'info_txt' => [],                      #not Support for plant memory
          'GeneralState' => [],                  #not Support for plant memory
          'DisturbanceState' => [],              #not Support for plant memory
          'DisturbanceState_text' => [],         #not Support for plant memory
          'Dequalification_poweron_cycle' => [], #not Support for plant memory
          'DisturbanceCounter' => [],            #not Support for plant memory
        };


B<AB12 Primary>

    $fault_HoA = {
          'fault_text' => [
                            'rb_spi_SpiRcvMsgCrcWrong_flt',
                            'rb_sdm_SectionInvalid_flt'
                          ],
          'state' => [
                       '0x2f',
                       '0x2f'
                     ],
          'DTC' => [
                     'F00049',
                     'F00049'
                   ],
          'fltnum' => [
                        '313',
                        '244'
                      ],
          'state_txt' => [
                           'Test_failed_since_last_clear+Confirmed_DTC_Stored+Pending+Test_failed_this_operation_cycle_Latched+Test_failed_Filtered',
                           'Test_failed_since_last_clear+Confirmed_DTC_Stored+Pending+Test_failed_this_operation_cycle_Latched+Test_failed_Filtered'
                         ],
          'info' => [],                          #not Support for primary memory
          'EventDebug' => [],                    #not Support for primary memory
          'EventDebug_HB' => [],                 #not Support for primary memory
          'EventDebug_LB' => [],                 #not Support for primary memory
          'GeneralState_text' => [],             #not Support for primary memory
          'Qualification_poweron_cycle' => [],   #not Support for primary memory
          'OccuranceCounter' => [],              #not Support for primary memory
          'DisturbanceCounter' => [],            #not Support for primary memory
          'QualificationTime' => [],             #not Support for primary memory
          'info_txt' => [],                      #not Support for primary memory
          'GeneralState' => [],                  #not Support for primary memory
          'DisturbanceState_text' => [],         #not Support for primary memory
          'Dequalification_poweron_cycle' => [], #not Support for primary memory
          'DisturbanceState' => [],              #not Support for primary memory
          'DequalificationTime' => []            #not Support for primary memory
        };

B<AB12 Bosch>

    $fault_HoA = {
          'EventDebug' => [
                            '0x00',
                            '0x0B'
                          ],
          'EventDebug_HB' => [
                            '0x00',
                            '0x00'
                          ],
          'EventDebug_LB' => [
                            '0x00',
                            '0x0B'
                          ],
          'fault_text' => [
                            'rb_spi_SpiRcvMsgCrcWrong_flt',
                            'rb_sdm_SectionInvalid_flt'
                          ],
          'GeneralState_text' => [
                                   '',
                                   ''
                                 ],
          'Qualification_poweron_cycle' => [
                                             '0',
                                             '4294967295'
                                           ],
          'OccuranceCounter' => [
                                  '255',
                                  '1'
                                ],
          'state' => [
                       '0x00',
                       '0x00'
                     ],
          'QualificationTime' => [
                                   '0',
                                   '4294967295'
                                 ],
          'GeneralState' => [
                              '0x0',
                              '0x0'
                            ],
          'Dequalification_poweron_cycle' => [
                                               '7',
                                               '0'
                                             ],
          'DTC' => [
                     'F00049',
                     'F00049'
                   ],
          'fltnum' => [
                        '313',
                        '244'
                      ],
          'state_txt' => [
                           'Test_not_Failed',
                           'Test_not_Failed'
                         ],
          'DequalificationTime' => [
                                     '166016',
                                     '0'
                                   ],
          'ASIC_Temperature'  => [
                                   '50',
                                   '51'
          ]
          'info' => [],                  #not Support for Bosch memory
          'info_txt' => [],              #not Support for Bosch memory
          'DisturbanceCounter' => [],    #not Support for Bosch memory
          'DisturbanceState' => [],      #not Support for Bosch memory
          'DisturbanceState_text' => [], #not Support for Bosch memory
        };

B<AB12 Disturbance>

    $fault_HoA = {

          'EventDebug' => [
                            '0x0B',
                            '0xFF'
                          ],
          'EventDebug_HB' => [
                            '0x00',
                            '0x00'
                          ],
          'EventDebug_LB' => [
                            '0x0B',
                            '0xFF'
                          ],
          'fault_text' => [
                            'rb_sdm_SectionInvalid_flt',
                            'rb_syc_AsicIdMismatch_flt'
          'GeneralState_text' => [
                                   '',
                                   ''
                                 ],
          'DisturbanceCounter' => [
                                    '0',
                                    '0'
                                  ],
          'GeneralState' => [
                              '0x0',
                              '0x0'
                            ],
          'DisturbanceState_text' => [
                                       'TestCurrent',
                                       'TestCurrent'
                                     ],
          'DTC' => [
                     'F00049',
                     'F00049'
                   ],
          'DisturbanceState' => [
                                  '0x1',
                                  '0x1'
                                ],
          'fltnum' => [
                        '244',
                        '713'
                      ],
          'state_txt' => [],                     #not Support for Disturbance memory
          'info' => [],                          #not Support for Disturbance memory
          'state' => [],                         #not Support for Disturbance memory
          'QualificationTime' => [],             #not Support for Disturbance memory
          'info_txt' => [],                      #not Support for Disturbance memory
          'Dequalification_poweron_cycle' => [], #not Support for Disturbance memory
          'Qualification_poweron_cycle' => [],   #not Support for Disturbance memory
          'OccuranceCounter' => [],              #not Support for Disturbance memory
          'DequalificationTime' => []            #not Support for Disturbance memory
        };

B<AB10>

    $fault_HoA = {
           'info_txt' => [
                          '',
                          ''
                        ],
          'info' => [
                      '0b000000',
                      '0b000001'
                    ],
          'fault_text' => [
                            'FltEOLNotProgrammed',
                            'FltCRCRamFault'
                          ],
          'DTC' => [
                     'A01300',
                     '00004A'
                   ],
          'state_txt' => [
                           'disturb+latched',
                           'active+current+stored+latched+filtered'
                         ],
          'fltnum' => [
                        'bc',
                        '11'
                      ],
          'state' => [
                       '0x22',
                       '0x1f'
                     ]
          'EventDebug' => [],    #not Support for AB10
          'EventDebug_HB' => [], #not Support for AB10
          'EventDebug_LB' => [], #not Support for AB10
          'Qualification_poweron_cycle' => [],   #not Support for AB10
          'OccuranceCounter' => [],              #not Support for AB10
          'DisturbanceCounter' => [],            #not Support for AB10
          'QualificationTime' => [],             #not Support for AB10
          'GeneralState' => [],                  #not Support for AB10
          'DisturbanceState_text' => [],         #not Support for AB10
          'Dequalification_poweron_cycle' => [], #not Support for AB10
          'DisturbanceState' => [],              #not Support for AB10
          'DequalificationTime' => []            #not Support for AB10
        };

B<General Fault Structure Description>

    $fault_HoA = {
         "fltnum"                           => [@faults], #is Fault Number (eg:40)
         "fault_text"                       => [@fault_text], #is Name Enum (eg:rb_coa_MissingMsgFromBCM_flt)
         "DTC"                              => [@DTC], #is Fault Code (eg:10)
         "state"                            => [@states], #is status byte (eg:0x6c)
         "DisturbanceState"                 => [@distrubanceState], #States read only for DFM #is disturbance status byte (eg:0x01)
         "GeneralState"                     => [@generalState], #States read only for BFM and DFM #is general status byte (eg:0x01)
         "state_txt"                        => [@state_text], #State bit text
                            (eg:'Test_not_completed_this_operation_cycle+Test_failed_since_last_clear+Confirmed_DTC_Stored+Pending')
         "DisturbanceState_text"            => [@distrubanceStateText],#Disturbance State bit text(eg:'Testdisturbed')
         "GeneralState_text"                => [@generalStateText], #General State bit text(eg:'InitModeactive')
         "info"                             => [@addInfo], #only for AB10
         "info_txt"                         => [@addInfo_text], #only for AB10
         #Extra Information from both disturbance & Bosch fault memory
         "EventDebug"                       => [@event],   # Holds event values in DFM and BFM respectively (eg:0x0001)
         "EventDebug_HB"                    => [@event_hb],   # Holds event high byte values in DFM and BFM respectively (eg:0x00)
         "EventDebug_LB"                    => [@event_lb],   # Holds event low byte values in DFM and BFM respectively (eg:0x01)
         "OccuranceCounter"                 => [@counter], # Holds Occurance counter in BFM (eg:15)
         "DisturbanceCounter"               => [@counter], # Holds disturbance counter value in DFM (eg:25)
         #Extra Information from only Bosch fault memory
         "QualificationTime"                => [@quali_time], #is qualification time(eg:96137)
         "DequalificationTime"              => [@dequali_time], #is dequalification time(eg:96)
         "Qualification_poweron_cycle"      => [@quali_poweron], #is qualification cycle (eg:1)
         "Dequalification_poweron_cycle"    => [@dequali_poweron], #is dequalification cycle (eg:0)
		 "ASIC_Temperature"                 => [@asic_temperature], #ASIC temperature(eg:50)
    };

B<offline + Error return>

          $dummy_return = {
                             "fltnum"                           => [],
                             "fault_text"                       => [],
                             "DTC"                              => [],
                             "state"                            => [],
                             "DisturbanceState"                 => [],
                             "GeneralState"                     => [],
                             "state_txt"                        => [],
                             "DisturbanceState_text"            => [],
                             "GeneralState_text"                => [],
                             "info"                             => [],
                             "info_txt"                         => [],
                             "EventDebug"                       => [],
                             "EventDebug_HB"                    => [],
                             "EventDebug_LB"                    => [],
                             "OccuranceCounter"                 => [],
                             "DisturbanceCounter"               => [],
                             "QualificationTime"                => [],
                             "DequalificationTime"              => [],
                             "Qualification_poweron_cycle"      => [],
                             "Dequalification_poweron_cycle"    => [],
                             "ASIC_Temperature"                 => [],
                        };

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ReadFaultMemory
{
    my $nType = shift;

    my ( @faults, @fault_text, @DTC, @states, @addInfo, @addInfo_text, @state_text, $item, $fault_HoA, @table, $text );

    my $dummy_return = {
        "fltnum"                => [],
        "fault_text"            => [],
        "DTC"                   => [],
        "state"                 => [],
        "DisturbanceState"      => [],
        "GeneralState"          => [],
        "state_txt"             => [],
        "DisturbanceState_text" => [],
        "GeneralState_text"     => [],
        "info"                  => [],
        "info_txt"              => [],

        #Extra Information from both disturbance & Bosch fault memory
        "EventDebug"         => [],    # Holds event values in DFM and BFM respectively
        "EventDebug_HB"      => [],    # Holds event high byte values in DFM and BFM respectively
        "EventDebug_HB"      => [],    # Holds event low byte values in DFM and BFM respectively
        "OccuranceCounter"   => [],
        "DisturbanceCounter" => [],

        #Extra Information from only Bosch fault memory
        "QualificationTime"             => [],
        "DequalificationTime"           => [],
        "Qualification_poweron_cycle"   => [],
        "Dequalification_poweron_cycle" => [],
		"ASIC_Temperature"              => [],
    };

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return $dummy_return;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $dummy_return;
    }

    return $dummy_return if $main::opt_offline;

    if ( $ABgeneration < 12 )
    {

        unless ( defined $nType )
        {
            # Default: Primary Fault Memory type
            $nType = 1;
            S_w2log( 3, " PD_ReadFaultMemory: Read Primary Fault Memory (Default setting nType: $nType) \n" );
        }

        my ( $IDs, $DTCs, $names, $states, $info );
        ( $stat, $IDs, $DTCs, $names, $states, $info ) = pd_ReadFaultMemory($nType);

        @faults     = @$IDs;
        @DTC        = @$DTCs;
        @fault_text = @$names;
        @states     = @$states;
        @addInfo    = @$info;

        S_w2log( 5, "\nPD_ReadFaultMemory ($stat):\n" );
        check_status($stat) || return;

        if (@states)
        {
            @table = ();
            $text  = "ID; DTC; faultname; status; Add Faultinfo\n";

            for ( $item = 0 ; $item < @states ; $item++ )
            {
                if ( hex( $states[$item] ) & 128 ) { $state_text[$item] .= "bit_7+" }
                if ( hex( $states[$item] ) & 64 )  { $state_text[$item] .= "bit_6+" }
                if ( hex( $states[$item] ) & 32 )  { $state_text[$item] .= "disturb+" }
                if ( hex( $states[$item] ) & 16 )  { $state_text[$item] .= "active+" }
                if ( hex( $states[$item] ) & 8 )   { $state_text[$item] .= "current+" }
                if ( hex( $states[$item] ) & 4 )   { $state_text[$item] .= "stored+" }
                if ( hex( $states[$item] ) & 2 )   { $state_text[$item] .= "latched+" }
                if ( hex( $states[$item] ) & 1 )   { $state_text[$item] .= "filtered+" }
                chop( $state_text[$item] );    # cut off trailing +

                $states[$item] = '0x' . $states[$item];

                my $bits = sprintf( "%08b", S_0x2dec( $states[$item] ) );
                my $bittext = join( '</TD><TD>', split( //, $bits ) );
                $bittext =~ s/0/-/g;
                $bittext =~ s/1/X/g;

                my @infos = split( /,/, $addInfo[$item] );
                my ( $infobits, $infotext );
                $infobits = $infotext = '';
                foreach my $temp (@infos)
                {
                    $temp =~ /^(\d+)\s+(.+)$/;
                    my $bit = $1;
                    my $txt = $2;

                    # append infobits
                    $infobits = $bit . $infobits;

                    #append info text if bit is set and text not only blanks or empty
                    $infotext = $txt . "," . $infotext if ( $bit > 0 and $txt !~ /^\s*$/ );
                }
                chop($infotext);    # cut off trailing,
                $addInfo_text[$item] = $infotext;
                $addInfo[$item]      = "0b" . $infobits;

                $infotext = $addInfo[$item] . "<br>" . $addInfo_text[$item];

                #HTML output
                push( @table, '<TR><TD>' . hex( $faults[$item] ) . '</TD><TD>' . $DTC[$item] . '</TD><TD>' . $fault_text[$item] . '</TD><TD>' . $states[$item] . '</TD><TD>' . $bittext . '</TD><TD>' . $infotext . '</TD></TR>' );
                $text .= hex( $faults[$item] ) . "; $DTC[$item]; $fault_text[$item]; $states[$item]; $addInfo[$item]\n";
            }

            #
            #  TODO : table function must be used normally
            #
            S_w2log( 4, "printing fault table of AB Generation $ABgeneration:  Plant/Primary  Fault Memory\n" );

            push(
                  @TC_HTML_TEXT,
                  join( '',
                        '<div class="w2rep ',
                        $module_name,
                        '"><TABLE class="tablesorter">',
                        '<TR><TH>ID</TH><TH>DTC</TH><TH>faultname</TH><TH>status</TH>',
                        '<TH>7</TH><TH>6</TH><TH>D</TH><TH>A</TH><TH>C</TH><TH>S</TH><TH>L</TH><TH>F</TH>',
                        '<TH>Add Faultinfo</TH></TR>',
                        @table, '</TABLE></div>', "\n" )
            );
            print $text unless $main::opt_silent;
            print LIFT_general::LOG $text;

        }
        else
        {
            S_w2log( 5, "The fault memory is empty.\n" );
        }

        $fault_HoA = {
            "fltnum"                => [@faults],
            "fault_text"            => [@fault_text],
            "DTC"                   => [@DTC],
            "state"                 => [@states],
            "DisturbanceState"      => [],
            "GeneralState"          => [],
            "state_txt"             => [@state_text],
            "DisturbanceState_text" => [],
            "GeneralState_text"     => [],
            "info"                  => [@addInfo],
            "info_txt"              => [@addInfo_text],

            #Extra Information from both disturbance & Bosch fault memory
            "EventDebug"                    => [],    # Holds event values in DFM and BFM respectively
            "EventDebug_HB"                 => [],    # Holds event high byte values in DFM and BFM respectively
            "EventDebug_LB"                 => [],    # Holds event low byte values in DFM and BFM respectively
            "OccuranceCounter"              => [],    # Holds Occurance counter in BFM
            "DisturbanceCounter"            => [],    # Holds disturbance counter value in DFM
                                                      #Extra Information from only Bosch fault memory
            "QualificationTime"             => [],
            "DequalificationTime"           => [],
            "Qualification_poweron_cycle"   => [],
            "Dequalification_poweron_cycle" => [],
        };
    }

    if ( $ABgeneration == 12 )
    {
        
        my $fault_type_text = "";
        
        if( not defined $nType ) # first check for "not defined" then later check for "== 0", because "undef == 0" with == operator!
        {
            # Default: Primary Fault Memory type
            S_w2log( 3, " PD_ReadFaultMemory: No specfic Fault Type defined -> DEFAULT Handling of Reading Fault Memory\n" );
            S_w2log( 3, " PD_ReadFaultMemory: -> Step1: BOSCH Fault Memory Type will be READ + PRINTED ( option 3 ) \n" );
            S_w2log( 3, " PD_ReadFaultMemory: -> Step2: PRIMARY Fault Memory Type will be READ + PRINTED + RETURNED ( option 1 )\n" );

            S_w2log( 3, "\n" );
            S_w2log( 3, " PD_ReadFaultMemory: BOSCH Fault Memory Type - (Read+Print only) Processing ... \n" );
            ReadFaultMemory_AB12( 3 );
            
            $nType = 1;
            $fault_type_text = "PRIMARY";
            # processing now like option 1            
        }
        elsif( $nType == 0 )    { $fault_type_text = "PLANT"; }
        elsif( $nType == 1 )    { $fault_type_text = "PRIMARY"; }
        elsif( $nType == 3 )    { $fault_type_text = "BOSCH"; }
        elsif( $nType == 4 )    { $fault_type_text = "DISTURBANCE"; }
        else {
            S_set_error( " Wrong argument given : $nType (only 0 , 1 , 3 , 4 or nothing (default) is implemented)\n" );
            return {};
        }

        S_w2log( 3, " PD_ReadFaultMemory: $fault_type_text Fault Memory Type (option $nType) - Processing ... \n" );
        $fault_HoA = ReadFaultMemory_AB12($nType);
        unless( $fault_HoA ) {
            S_w2log( 3, " Call of ReadFaultMemory_AB12($nType) not successful\n" ); # error set in called function
            return;
        }

        S_w2log( 3, " PD_ReadFaultMemory: Returning Data of $fault_type_text Fault Memory Type (option $nType)\n" );

        #Below empty keys are added as to maintain consistency with AB10 return hash for extended fault memory
        $$fault_HoA{"ApTime"}  = [];
        $$fault_HoA{"DisTime"} = [];
        $$fault_HoA{"PonCnt"}  = [];
        $$fault_HoA{"SpoCnt"}  = [];
    }

    return ($fault_HoA);
}

=head2 PD_ManipulateFaultMemory

    $returnValue = PD_ManipulateFaultMemory($faultname, $action);

Manipulates the fault memory according to the action and the fault specified.

B<Arguments:>

=over

=item $faultname

1. A String - Fault name which has to be qualified or dequalified.

2. A Number - Fault type to be dequalified.

(0 - Plant,
1 - Primary,
3 - Bosch,
4 - Disturbance)

=item $action

action can be either "qualify" or "dequalify".

=back

B<Return Value:>

=over

=item $status 

1 - success

undef - error

1 - offline mode

=back

B<Examples:>

    $status = PD_ManipulateFaultMemory("rb_acc_ParameterLayoutIDInvalid_flt", "qualify");

B<Notes:> 

Reset the ECU after fault memory manipulation to switch on the fault qualification.

=cut

sub PD_ManipulateFaultMemory {

	#COMMENT-START
	#	Two arguments - Faultname and action(qualify or dequalify) - both mandatory
	#COMMENT-END

	#IF offline mode
	#	IF-YES-START
	#		STEP return success
	#	IF-YES-END
	#	IF-NO-START
	#		IF faultname is a number
	#			IF-YES-START
	#				IF action is qualify
	#					IF-YES-START
	#						STEP set error and exit
	#					IF-YES-END
	#					IF-NO-START
	#						STEP read PD faults with the fault type user had mentioned
	#						LOOP-START loop over all the faults present
	#						CALL pd_ManipulateFaultMemory for every fault with dequalify as the action
	#						STEP print the status for every fault manipulation
	#						LOOP-END faults over?
	#						STEP return the overall status
	#					IF-NO-END
	#			IF-YES-END
	#			IF-NO-START
	#				CALL pd_ManipulateFaultMemory with the action specified for the fault mentioned
	#				STEP return the status of manipulation
	#			IF-NO-END
	#	IF-NO-END

	my @args = @_;
	S_checkFunctionArguments( 'PD_ManipulateFaultMemory($faultName, $action)', @args )
	  or return;

	my $faultName = shift @args;
	my $action    = shift @args;

	unless ( $action =~ /qualify/i || $action =~ /dequalify/i ) {
		S_set_error( "Action $action you specified is not valid. Valid actions are \"qualify\" or \"dequalify\".", 114 );
		return;
	}

	S_w2log( 4, " PD_ManipulateFaultMemory : called with ($faultName, $action)\n" );
	my $status;
	if ($main::opt_offline) {
		return 1;
	}

	if ( $faultName =~ /^\d$/ ) {

		S_w2log( 3, " PD_ManipulateFaultMemory: Faultname is a number and hence considerd as a fault type to be dequalified. So all faults are considered for fault manipulation.\n" );

		unless ( $action =~ m/dequalify/i ) {
			S_set_error( " Action can only be dequalify when a fault type is chosen. Please choose a single fault or change the action.", 114 );
			return;
		}
		
		unless ($faultName =~ /[0|1|3|4]/) {
			S_set_error( " Fault type can only be 0/1/3/4. Please check the function documentation.", 114 );
			return;
		}

		my @fault_ids;

		#Reading information from low level function
		my ( $ids, $dtcs, $names, $info, $states, $fault_info_aref );    # Except $fault_info_aref, all values return empty always
		( $status, $ids, $dtcs, $names, $states, $info, $fault_info_aref ) = pd_ReadFaultMemory($faultName);

		foreach my $fault_data (@$fault_info_aref)                       # Parses each index of an array
		{
			my @flt_data_arr = split( /\,/, $fault_data );               #Splitting the contents of fault_data separated by comma
			my %fault_data_hash;                                         # This is temp hash, holds details which is available in @flt_data_arr
			foreach my $data (@flt_data_arr) {
				my @data_temp = split( /:/, $data );
				$fault_data_hash{ $data_temp[0] } = $data_temp[1];
			}

			# Reading Fault IDs into an array
			push( @fault_ids, $fault_data_hash{'FaultID'} );             #fault id information

		}
		my ( $faultname, $faultcode );

		foreach my $fault (@fault_ids) {
			( $status, $faultname, $faultcode ) = pd_GetFLTNameByFLTID($fault);
			
			S_w2log(3," PD_ManipulateFaultMemory: pd_ManipulateFaultMemory called for the fault : $faultname to dequalify\n");
			$status = pd_ManipulateFaultMemory( $faultname, "dequalify" );
			if ( $status == 0 ) {
				S_w2log( 3, " PD_ManipulateFaultMemory: Fault $faultname is dequalified successfully.\n" );
			}
			else {
				S_w2log( 3, " PD_ManipulateFaultMemory: Fault $faultname dequalification was not successful.\n" );
			}
		}
		return check_status($status);
	}
	else {
		S_w2log( 3, " pd_ManipulateFaultMemory called for the fault : $faultName to $action\n" );
		$status = pd_ManipulateFaultMemory( $faultName, $action );
		return check_status($status);
	}

	return;
}

=head1 Function Group 'fast_diag'

=head2 PD_get_FDtrace

    $fast_diag_data_HoH = PD_get_FDtrace($filename[, $fastDiagVarAdd_aref, $fastDiagType_aref, $time_unit]);       

Returns the structure created from file containing fast Diagnosis data to evaluate with EVAL functions.

Pass CAN trace(.asc) file as input if real time data from the CAN trace has to be fetched , otherwise pass the folder containing the .csv result files.

Timebase of structure is in Milliseconds if CSV file is the input, (does not require PD_InitDiagnosis)

Otherwise, Timebase of structure is in Milliseconds/Seconds if CAN trace file(.asc) is the input, (does not require PD_InitDiagnosis)

B<Arguments:>

=over

=item $filename 

It is the path of the trace file(.csv) or the can trace file name(.asc) containing the fast diagnosis data

=item (optional)$fastDiagVarAdd_aref 

Array reference with the label names for which fast diagnosis data will be read.

=item (optional)$fastDiagType_aref 

Array reference with the data types (U8,U16,U32,U64,S8,S10,S16,S32,S64) of the names given in $names_aref. Must have the same length as $FastDiagVarAdd_aref

=item (optional)$time_unit 

time_unit is required incase CAN trace file(.asc) file is passed as a parameter and If the Timebase has to be converted from 'Seconds' to 'MilliSeconds'.

'MILLISEC' should be passed as time_unit for the conversion, otherwise the FastDiag data returned will be in Seconds Timebase.

Mostly the time conversion from 'Seconds' to 'MilliSeconds' is required incase the FastDiag data obtained is used to plot graph using the function 'PD_plot_FDtrace'(The timebase for this function is in milliseconds).

B<If the graph has to be plotted with 'Seconds' timebase, EVAL_createGraphFromMeasurement can be used.>

=back

B<Return Value:>

=over

=item $returnValue_href 

B<Success :> Returns the structure created from fast diagnosis data file

Ex : { time => { 'variable_name' => value } }

The timebase(MilliSeconds/Seconds) incase CAN trace(.asc) file is passed as input is the real time taken from CAN trace file.

The timebase(MilliSeconds) incase .csv file is passed as input is the relative time taken from .csv file.

B<Error return :> { 0 => { 'dummy' => 0 } }

=back

B<Note 1:> The $FastDiagVarAdd_aref and  $FastDiagType_aref should be same as the variable and type array reference passed to the PD_StartFastDiagName or PD_StartFastDiagAddress

B<Note 2: This will not work on currently running FD traces. Call PD_StopFastDiag(), before calling PD_get_FDtrace() >

B<Note 3: Incase CAN trace file is passed as input ,trace should be recorded using CA_trace_start and CA_trace_stop functions as suggested in the Example below and the trace file should have Login and fast Diagnosis data>

B<Note 4:> Supported AB Generations:: B<10 and 12>

B<Examples:>

    For .asc file    
    CA_trace_start();
    $return_value = PD_StartFastDiagName( $FastDig_Dir_name, $FastDiagVar_aref, $FastDiagType_aref, '', 1 );
    $return_value = PD_StopFastDiag();
    CA_trace_stop();
    my $filename = GEN_generateUniqueTraceName();
    CA_trace_store($filename);
    
    $fast_diag_data_HoH = PD_get_FDtrace($filename, $FastDiagVarAdd_aref, $FastDiagType_aref, 'MILLISEC'); To get FastDiag data in MilliSeconds Timebase
    PD_plot_FDtrace( $fast_diag_data_HoH, $PlotFileName );    
    OR 
    $fast_diag_data_HoH = PD_get_FDtrace($filename, $FastDiagVarAdd_aref, $FastDiagType_aref); To get FastDiag data in Seconds Timebase
    my $signalNames_href = {
        'y' => $FastDiagVarAdd_aref
    };
    EVAL_createGraphFromMeasurement($fast_diag_data_HoH, 'FastDiagnosis', $signalNames_href);
    
                                       OR
    For .csv file    
    $return_value = PD_StartFastDiagName( $FastDig_Dir_name, $FastDiagVar_aref, $FastDiagType_aref, '', 1 );
    $return_value = PD_StopFastDiag();
    $fast_diag_data_HoH = PD_get_FDtrace($ResultFolderName);
    PD_plot_FDtrace( $fast_diag_data_HoH, $PlotFileName );                                   

=cut

sub PD_get_FDtrace {

	# STEP Get the Filename(can be a trace file(.asc) or an csv result file)
	# IF type of the file is .csv
	# IF-YES-START
	#      CALL Get_FDtrace_from_CSV_File
	# IF-YES-END
	# IF-NO-START
	#      STEP Get the fast diag variable names
	#      STEP Get the fast diag variable types
	#      CALL Get_Fast_Diag_data_from_CANTrace
	# IF-NO-END
	# STEP return the hash reference containing the fast daignosis data

	my @args = @_;

	my $data_HoH_dummy;
	$data_HoH_dummy->{0}->{'dummy'} = 0;

	return $data_HoH_dummy unless S_checkFunctionArguments( 'PD_get_FDtrace( $file_name[, $FastDiagVar_aref, $FastDiagType_aref, $time_unit] )', @args );
	my $filename          = shift @args;
	my $fastDiagVar_aref  = shift @args;
	my $fastDiagType_aref = shift @args;
	my $time_unit         = shift @args;

	my $fast_diag_data_HoH = {};

	if ( $filename =~ /^.+\.asc$/ ) {
		unless ( defined $fastDiagVar_aref || defined $fastDiagType_aref ) {
			S_set_error( "The array reference of variable and variable types are mandatory if .asc file(can trace file) is passed as a input\n", 110 );
			return $data_HoH_dummy;
		}
		if ( $time_unit !~ /MILLISEC/i ) {
			S_set_warning("The time_unit '$time_unit' passed as an input parameter is not valid, so by default the time_unit considered is 'Seconds'.\n Please refer the docu of 'PD_get_FDtrace' for more information\n");
		}
		$fast_diag_data_HoH = Get_Fast_Diag_data_from_CANTrace( $filename, $fastDiagVar_aref, $fastDiagType_aref, $time_unit );
	}
	else {
		if ( defined $fastDiagVar_aref || defined $fastDiagType_aref || defined $time_unit ) {
			S_set_warning("The array reference of variable, variable types and the time_unit are not required incase the File containing FastDiag Data passed as a input is in the form of CSV\n ");
		}
		$fast_diag_data_HoH = Get_FDtrace_from_CSV_File($filename);
	}

	unless ($fast_diag_data_HoH) {
		S_set_error( "Could not fetch the fast Diagnosis data\n", 110 );
		return $data_HoH_dummy;
	}
	return ($fast_diag_data_HoH);
}

=head2 PD_plot_FDtrace

    $status = PD_plot_FDtrace( $data_HoH, $plotfilename [,$triggertime] );    

This function is used to create plot from fast diagnosis trace and save as pic (*.png) and UNIVIEW file (*.txt.unv).

B<Arguments:>

=over

=item $data_HoH 

The structure containing the Fast Diagnosis Data

The timebase expected by this function is in MilliSeconds 

=item $plotfilename 

It is the Plot Filename 

=item $triggertime 

(Optional)If triggertime is given, an artificial trigger signal will be added, (does not require PD_InitDiagnosis)

=back

B<Return Value:>

=over

=item $status

Success/Offline : 1

Error return : 0

=back

B<Examples:>

    $status = PD_plot_FDtrace( $data_HoH, $plotfilename [,$triggertime] );
	
B<Note:> Supported AB Generations:: B<10 and 12>

B<Note:> The time in the graph will be in MilliSeconds	

=cut

sub PD_plot_FDtrace {

	# DESIGN
	# COMMENT-START
	# args :
	# - $data_HoH
	# - $plotfilename
	# - optional - $triggertime
	# COMMENT-END

	# STEP Create the PlotFilename and the UNV Filename from the Filename passed as a parameter

	# IF Offline ?
	# IF-YES-START
	# STEP Create a dummy PlotFile and UNV File
	# IF-YES-END

	# IF-NO-START
	# STEP  Extract the timestamps from the FastDiag Hash
	# STEP  Get the Variable names from the FastDiag Hash
	# STEP  Store the First timestamp of the FastDiag hash in the initial values of the $last_time and $step_time
	# STEP  Store the time and values in an array GDdata
	# STEP  Plot graph using the data stored in array GDdata(time and values are stored in array GDdata)
	# IF-NO-END
	# STEP  Return 1

	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'PD_plot_FDtrace ( $fddata_href, $plotfilename[,$triggertime] )', @args );

	my $fddata_href = shift @args;
	my $filename    = shift @args;
	my $triggertime = shift @args;

	my $dt = 1;    # ms

	#    bytes    $dt
	#    1,2      0.5
	#    3,4      1
	#    5..8     2
	#    9..14    4
	#    15..21  6
	# unfortunately at this point we don't know number of bytes, so $dt = 1 is a compromise

	S_w2log( 4, "PD_plot_FDtrace( $filename )\n" );

	$filename =~ s/\.(\S+)$//;    # cut off file extension
	my $picname = $filename . ".png";
	my $unvname = $filename . ".txt.unv";

	my ( $time, @legend, $unvline1, $unvline2, $value, @gddata, $count, $graph, $last_time, $step_time, @timestamps );
	@legend = @gddata = @timestamps = ();

	if ($main::opt_offline) {
		S_create_dummy_pic($picname);
		S_create_dummy_file($unvname);
		return 1;
	}

	#print "PD_plot_FDtrace extract names\n";
	# extract names from some timestamp (which one does not matter);
	@timestamps = sort { $a <=> $b } keys %{$fddata_href};

	if ( scalar(@timestamps) < 1 ) {
		S_create_dummy_pic($picname);
		S_create_dummy_file($unvname);
		S_set_error( "no data in data_HoH", 114 );
		return;

	}
	else {
		unless ( open( UNV, ">$unvname" ) ) {
			S_set_error( " Couldnt open UNIVIEW file '$unvname' ", 1 );
			return;
		}

		#print "- ".scalar(@timestamps)." -\nPD_plot_FDtrace extract legend\n";
		@legend = sort keys %{ $fddata_href->{ $timestamps[0] } };    # extract names in sorted order to match with values later

		if ( defined $triggertime ) {
			push( @legend, "trigger" );
		}
		my $triggerflag = 0;

		#print "- @legend -\nPD_plot_FDtrace write UNIVIEW header\n";
		#write UNIVIEW header
		#TIME;E_ERMBGStateMachine_SXR;E_ERMBGStateMachine_SXR;
		#s;-;-;
		$unvline1 = "TIME;";
		$unvline2 = "s;";
		foreach (@legend) {
			$unvline1 .= "$_;";
			$unvline2 .= "-;";
		}
		print UNV "$unvline1\n";
		print UNV "$unvline2\n";

		#print "PD_plot_FDtrace fill gddata\n";
		$last_time = $timestamps[0];    # Store the First timestamp in FastDiag Data hash as the initial value of $last_time
		$step_time = $timestamps[0];    # Store the First timestamp in FastDiag Data hash as the initial value of $step_time

		# fill @gddata with times and values

		for ( my $i = 0 ; $i < scalar(@timestamps) ; $i++ ) {
			$time = $timestamps[$i];

			# fill inbetween time stamps if there is a gap
			while ( $time - $dt > ($step_time) ) {
				$step_time += $dt;
				$count = 1;
				push( @{ $gddata[0] }, $step_time );
				foreach my $signal ( sort keys %{ $fddata_href->{$last_time} } ) {
					$value = $fddata_href->{$time}->{$signal};
					push( @{ $gddata[$count] }, $value );
					$count++;

					#if ($signal eq "ECU_reset" and $value != 1){
					#     S_w2log( 5, "filling up ($time) $step_time\n" );
					#}
				}
			}

			push( @{ $gddata[0] }, $time );
			$unvline1  = ( $time / 1000 ) . ";";
			$count     = 1;
			$last_time = $time;
			$step_time = $time;

			foreach my $signal ( sort keys %{ $fddata_href->{$time} } ) {
				my $nextvalue;
				$value = $fddata_href->{$time}->{$signal};
				push( @{ $gddata[$count] }, sprintf("%.0f",$value) );
				$count++;

				# overwrite reset flag for value before reset in UNV
				if ( $signal eq "ECU_reset" and $i + 1 < scalar(@timestamps) ) {
					$nextvalue = $fddata_href->{ $timestamps[ $i + 1 ] }->{$signal};
					if ( $nextvalue == 1 ) {
						$value = $nextvalue;
					}
				}
				$unvline1 .= "$value;";
			}

			if ( defined $triggertime ) {
				if ( $time < $triggertime or $triggerflag == 1 ) {
					push( @{ $gddata[$count] }, 0 );
					$unvline1 .= "0;";
				}
				else {
					push( @{ $gddata[$count] }, 10 );
					$triggerflag = 1;
					$unvline1 .= "10;";
				}
			}

			#write UNIVIEW data line
			#0;13;13;
			print UNV "$unvline1\n";

			#print "PD_plot_FDtrace $UNVline1\n";
		}

		#print "PD_plot_FDtrace new graph\n";
		$graph = GD::Graph::lines->new( 800, 600 );

		#print "PD_plot_FDtrace settings\n";

		$graph->set(
					 x_label       => "time in ms (0 to $last_time)",
					 y_label       => "fast diagnosis data values",
					 title         => 'fast diagnosis trace',
					 x_tick_number => 'auto',
					 r_margin      => 10,
					 l_margin      => 10,
					 b_margin      => 10,
					 transparent   => 0,
					 bgclr         => "black",
					 fgclr         => "white",
					 textclr       => "white",
					 labelclr      => "white",
					 axislabelclr  => "white",
					 legendclr     => "white",
					 valuesclr     => "white",
		);

		#print "PD_plot_FDtrace legend font\n";
		$graph->set_legend_font( GD::Font->Large );

		#print "PD_plot_FDtrace legend names - @legend -\n";
		$graph->set_legend(@legend);

		unless ( open( PIC, ">$picname" ) ) {
			S_set_error( " Couldnt open PNG file '$picname' ", 1 );
			return;
		}

		binmode PIC;

		#print "PD_plot_FDtrace plot gddata\n";
		print PIC $graph->plot( \@gddata )->png;
		close(PIC);
		close(UNV);
	}

	return 1;
}


=head2 PD_StartFastDiagAddress

    $success = PD_StartFastDiagAddress( $filename, $addresses_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] );

Starts reading the values of the ECU labels given by address in $addresses_aref by fast diagnosis.
The data values of the addresses will be written to a file (AB10) or folder (AB12) defined in $filename.
The address types can be given explicitly in $types_aref. By default the address types are set to 'U8'.
Works in the same way as PD_StartFastDiagName, except for the second argument.

By default only one CAN ID is used for fast diagnosis. In AB12 up to 4 CAN-IDs can be used for fast diagnosis to increase the data cycle time for a given number of data bytes
or to increase the number of data bytes for a given data cycle time: 

    1 CAN ID : up to 1 data byte with 0.5ms data cycle ... up to 28 data bytes with 8ms data cycle
    2 CAN IDs: up to 3 data byte with 0.5ms data cycle ... up to 28 data bytes with 4ms data cycle
    3 CAN IDs: up to 5 data byte with 0.5ms data cycle ... up to 28 data bytes with 4ms data cycle
    4 CAN IDs: up to 7 data byte with 0.5ms data cycle ... up to 28 data bytes with 2ms data cycle

For AB12 there is a possibility to start the fast diagnosis not immediately, but on next ECU power on ($isNextPOC=1).

B<Arguments:>

=over

=item $filename

Name of file or folder where the fast diagnosis data will be written. In AB12 any file extensions will be removed.

=item $addresses_aref

Array reference with the address for which fast diagnosis data will be read.

=item $types_aref

(optional) Array reference with the data types (U8,U16,U32,S8,S16,S32,U64,S64) of the names given in $addresses_aref. Must have the same length as $addresses_aref

=item $shifts_aref

(optional) Array reference, will be ignored for AB12 and should be set to undef. In AB10 it defines an address offset for each label (?) 
and it must have the same length as $addresses_aref.

=item $numberOfCANIds

(optional) Number of CAN IDs to be used for fast diagnosis (default = 1)

=item $isNextPOC

(optional) Defines if fast diagnosis is to start immediately (=0, default) or after next ECU power on (=1)

=back

B<Return Value:>

=over

=item $success 

Success flag: =1 on success or in offline mode, 0 on error.

=back

B<Examples>

    PD_StartFastDiagAddress( $main::REPORT_PATH."/AB12FD1" , ['0xFEDFAD38'] );
    PD_StartFastDiagAddress( $main::REPORT_PATH."/AB12FD2" , [0xFEDFAD38, 0xFEDFA561], ['U8', 'U16'], undef, 2 );
    
B<Notes>: If the Nbr of CAN IDs passed as a parameter to the API exceeds the Max Nbr of allowed CAN IDS, an ERROR will be thrown 
          (The Maximum Nbr of allowed CAN IDs is taken from PSDiagCANParameter.txt file)

B<Notes>:

A B<reset=1> at the beginning and a start time of 2.5 sec in the fast diagnosis trace indicates that no diagnosis session
was active when calling PD_StartFastDiagAddress. To avoid this or if you are not sure that PD session is active, you can send a
B<PD_ECUlogin> directly before calling PD_StartFastDiagAddress.

You should call B<PD_StopFastDiag()>, before accessing the Trace data.

Supported AB Generations:: B<10 and 12>

=cut

sub PD_StartFastDiagAddress {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PD_StartFastDiagAddress( $filename, $adresses_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] )', @args );

    my $filename       = shift @args;
    my $adresses_aref  = shift @args;
    my $types_aref     = shift @args;
    my $shifts_aref    = shift @args;
    my $numberOfCANIds = shift @args;
    my $isNextPOC      = shift @args;

    my $count;
    my $noOfCells;

    S_w2log( 4, "PD_StartFastDiagAddress \n" );

    unless ($filename) {
        S_set_error( "The Filename passed as a parameter is empty\n", 109 );
        return 0;
    }

    unless ( scalar(@$adresses_aref) ) {
        S_set_error( "The Variable array reference passed as a parameter is empty\n", 109 );
        return 0;
    }

    my $err_flg = 0;
    # check the length of the absolute filename
    foreach my $fdVarAddress (@$adresses_aref) {
        my $fdLabel;

        # get the fast diag label in order to check the complete length
        unless ( $fdLabel = PD_GetNameByAddress($fdVarAddress) ) {
            S_set_error( "PD_StartFastDiagAddress: Invalid variable address '$fdVarAddress', check the address configured!", 109 );
            return 0;
        }

        # template filename which is created by the psdiag dlls
        my $templateFileName = '/yyyymmdd_hhmmss_d_fd_' . $fdLabel . '_Udd.csv';
        my $folderpath = length($filename);
        my $filenamelength = length($templateFileName);
        my $totalFileLength  = $folderpath + $filenamelength;
        if ( $totalFileLength > $max_pathlength ) {
            S_set_error( "PD_StartFastDiagAddress: The FD trace file path '$filename' ( length '$folderpath') + filename '$templateFileName' ( length $filenamelength) exceeds maximum length '$max_pathlength', choose shorter path!", 114 );
            $err_flg = 1;
        }
    }

    return 0 if ($err_flg);
    
    #check $addresses_aref for undef elements
    if ( S_check_array( $adresses_aref, "\$addresses_aref" ) == 0 ) {
        S_set_error( "adresses_aref contains undefined value", 114 );
        return 0;
    }

    $numberOfCANIds = Validate_Nbr_CAN_IDS($numberOfCANIds);
    return 0 unless ($numberOfCANIds);    #return if the Nbr of CAN IDs for Fast Diagnosis is 0(in PSDiagCANParameter.txt file) for the respective project

    foreach my $ecu_memory_address_UBYTE ( @{$adresses_aref} ) {
        my $read_mem_value_aref = PD_ReadMemoryByAddress( $ecu_memory_address_UBYTE, 1 );
        if ( scalar(@$read_mem_value_aref) < 1 ) {

            # Error is already set in PD_ReadMemoryByName
            return 0;
        }
    }

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@$adresses_aref) ; $count++ ) {
        @$adresses_aref[$count] = S_0x2dec( @$adresses_aref[$count] );
        S_w2log( 5, "Passed Address :  @$adresses_aref[$count] \n" );
    }

    if ( defined $types_aref ) {

        unless ( scalar(@$types_aref) ) {
            S_set_error( "The types array reference passed as a parameter is empty\n", 109 );
            return 0;
        }

        #check $types_aref for undef elements
        if ( S_check_array( $types_aref, "\$types_aref" ) == 0 ) {
            S_set_error( "types_aref contains undefined value", 114 );
            return 0;
        }
        if ( scalar(@$adresses_aref) != scalar(@$types_aref) ) { S_set_error( "parameter array size is different", 109 ); return 0; }

        $noOfCells = 0;

        # check data
        for ( $count = 0 ; $count < scalar(@$types_aref) ; $count++ ) {
            unless ( $$types_aref[$count] =~ /^U8|S8|S10|U16|S16|U32|S32|U64|S64$/i ) {
                S_set_error( " wrong type at types_aref[$count]: $$types_aref[$count] != U8,S8,S10,U16,S16,U32,S32,U64,S64", 114 );
                return 0;
            }
            $$types_aref[$count] =~ /^(U|S)(\d+)$/;
            my $bits = $2;
            $bits = 16 if ( $bits == 10 );    # treat S10 as 2 byte value
            $noOfCells += $bits / 8;
        }
    }
    else {
        # $types_aref will be filled with default U8 if not given
        $noOfCells = scalar(@$adresses_aref);
        $types_aref = [ ('U8') x $noOfCells ];
    }

    my $address_aref_length = scalar(@$adresses_aref);
    if ( $noOfCells > 28 ) { S_set_error( "The Nbr of cells $noOfCells or the Nbr of addresses $address_aref_length passed to the Function exceeds the maximum allowed limit 28(Maximum of 28 cells are allowed for Fast Diagnosis) ", 109 ); return 0; }

    # Default Value is 0 for isNextPOC - starts on current cycle
    $isNextPOC = 0 unless ( defined $isNextPOC );

    unless ($PD_initialized) {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive) {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline) {
        S_create_dummy_file($filename);
        $FastDiagActive = 1;
        return 1;
    }

    if ( $ABgeneration < 12 ) {
        if ( defined $shifts_aref ) {

            #check $shifts_aref for undef elements
            if ( S_check_array( $shifts_aref, "\$shifts_aref" ) == 0 ) {
                S_set_error( "shifts_aref contains undefined value", 114 );
                return 0;
            }
            if ( $noOfCells != scalar(@$shifts_aref) ) {
                S_set_error( "number of shifts and types do not correspond", 109 );
                return 0;
            }

            # convert data to dec if required
            for ( $count = 0 ; $count < scalar(@$shifts_aref) ; $count++ ) {
                $$shifts_aref[$count] = S_0x2dec( $$shifts_aref[$count] );
            }
        }
        elsif ( $noOfCells < 9 ) {

            # $shifts_aref will be filled with default 0 if not given
            $shifts_aref = [ (0) x $noOfCells ];
        }
        else {
            $shifts_aref = [];    # not used
        }
        S_w2log( 3, " PD_StartFastDiagAddress ($noOfCells) - @$adresses_aref - @$types_aref - @$shifts_aref" . "- $filename - $numberOfCANIds - $isNextPOC\n" );

        if ( $noOfCells < 9 ) {    #Default CAN id and POC values for AB10
            $stat = pd_StartFastAddress( $adresses_aref, $shifts_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );
            S_w2log( 5, "standard PD_StartFastDiagAddress ($stat)\n" );
        }
        else {
            $stat = pd_StartExtAddress( $adresses_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );
            S_w2log( 5, "extended PD_StartFastDiagAddress ($stat)\n" );
        }
    }
    else {
        $shifts_aref = [];            # not used in AB12
        $filename =~ s/\.(\S+)$//;    #removing file extension
        make_path($filename);         #Creating Directory
        S_w2log( 3, " PD_StartFastDiagAddress($noOfCells) - @$adresses_aref - @$types_aref - @$shifts_aref " . "- $filename - $numberOfCANIds - $isNextPOC\n" );
        $stat = pd_StartFastAddress( $adresses_aref, $shifts_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );
        S_w2log( 5, "standard PD_StartFastDiagAddress($stat) \n" );
    }
    check_status($stat);
    $FastDiagActive = 1;
    if ( $stat < 0 ) {
        S_set_error( "could not start FastDiagnostics", 121 );
        $FastDiagActive = 0;
    }

    return 1;
}

=head2 PD_StartFastDiagName

    $success = PD_StartFastDiagName( $filename, $names_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] );

Starts reading the values of the ECU labels given by name in $names_aref by fast diagnosis.
The data values of the labels will be written to a file (AB10) or folder (AB12) defined in $filename.
The label types can be given explicitly in $types_aref. By default the label types are set to 'U8'.

By default only one CAN ID is used for fast diagnosis. In AB12 up to 4 CAN-IDs can be used for fast diagnosis to increase the data cycle time for a given number of data bytes
or to increase the number of data bytes for a given data cycle time: 

    1 CAN ID : up to 1 data byte with 0.5ms data cycle ... up to 28 data bytes with 8ms data cycle
    2 CAN IDs: up to 3 data byte with 0.5ms data cycle ... up to 28 data bytes with 4ms data cycle
    3 CAN IDs: up to 5 data byte with 0.5ms data cycle ... up to 28 data bytes with 4ms data cycle
    4 CAN IDs: up to 7 data byte with 0.5ms data cycle ... up to 28 data bytes with 2ms data cycle

For AB12 there is a possibility to start the fast diagnosis not immediately, but on next ECU power on ($isNextPOC=1).

B<Arguments:>

=over

=item $filename

Name of file or folder where the fast diagnosis data will be written. In AB12 any file extensions will be removed.

=item $names_aref

Array reference with the label names for which fast diagnosis data will be read.

=item $types_aref

(optional) Array reference with the data types (U8,U16,U32,S8,S16,S32,U64,S64) of the names given in $names_aref. Must have the same length as $names_aref

=item $shifts_aref

(optional) Array reference, will be ignored for AB12 and should be set to undef. In AB10 it defines an adress offset for each label (?) 
and it must have the same length as $names_aref.

=item $numberOfCANIds

(optional) Number of CAN IDs to be used for fast diagnosis (default = 1)

=item $isNextPOC

(optional) Defines if fast diagnosis is to start immediately (=0, default) or after next ECU power on (=1)

=back

B<Return Value:>

=over

=item $success 

Success flag: =1 on success or in offline mode, 0 on error.

=back

B<Examples AB12:>

    PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD1" , ['rb_psgp_PsiLineRebootTimer_au32(3)'] , ['U32'] );
    PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD2" , ['rb_psgp_PsiLineRebootTimer_au32(3)'] , ['U32'] , undef, 2 );
    PD_StartFastDiagName( $main::REPORT_PATH."/AB12FD3" , ['rb_psgp_PsiLineRebootTimer_au32(3)','fd_rb_psgp_PsiLineRebootTimer_au32(4)'] , ['U32', 'U32'] , undef, 4, 1);

B<Examples AB10:>

    PD_StartFastDiagName( $main::REPORT_PATH."/FD1.txt" , ['A_AccEcuChannel_S16R(0)'] , ['S16']);
    PD_StartFastDiagName( $main::REPORT_PATH."/FD2.txt" ,["A_FLMFltMemCounter_U8R(0)","A_FLMFltMemState_U8R(0)"]);
    PD_StartFastDiagName( $main::REPORT_PATH."/FD3.txt" , ['A_AccEcuChannel_S16R(0)'] , ['S16'] , [ 1, 1 ]);
    
B<Notes>: If the Nbr of CAN IDs passed as a parameter to the API exceeds the Max Nbr of allowed CAN IDS, an ERROR will be thrown
          (The Maximum Nbr of allowed CAN IDs is taken from PSDiagCANParameter.txt file)

B<Notes>:

A B<reset=1> at the beginning and a start time of 2.5 sec in the fast diagnosis trace indicates that no diagnosis session
was active when calling PD_StartFastDiagName. To avoid this or if you are not sure that PD session is active, you can send a
B<PD_ECUlogin> directly before calling PD_StartFastDiagName.

You should call B<PD_StopFastDiag()>, before accessing the Trace data.

Supported AB Generations:: B<10 and 12>

=cut

sub PD_StartFastDiagName {

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PD_StartFastDiagName( $filename, $names_aref [, $types_aref, $shifts_aref, $numberOfCANIds, $isNextPOC ] )', @args );

    my $filename       = shift @args;
    my $names_aref     = shift @args;
    my $types_aref     = shift @args;
    my $shifts_aref    = shift @args;
    my $numberOfCANIds = shift @args;
    my $isNextPOC      = shift @args;

    my $count;
    my $noOfCells;

    S_w2log( 4, "PD_StartFastDiagName \n" );

    unless ($filename) {
        S_set_error( "The Filename passed as a parameter is empty\n", 109 );
        return 0;
    }

    unless ( scalar(@$names_aref) ) {
        S_set_error( "The Variable array reference passed as a parameter is empty\n", 109 );
        return 0;
    }

    #check $names_aref for undef elements
    if ( S_check_array( $names_aref, "\$names_aref" ) == 0 ) {
        S_set_error( "names_aref contains undefined value", 114 );
        return 0;
    }

    my $err_flg = 0;
    # check the length of the absolute filename
    foreach my $fdVarName (@$names_aref) {
        my $templateFileName = '/yyyymmdd_hhmmss_d_fd_' . $fdVarName . '_Udd.csv';
        my $folderpath = length($filename);
        my $filenamelength = length($templateFileName);
        my $totalFileLength  = $folderpath + $filenamelength;
        if ( $totalFileLength > $max_pathlength ) {
            S_set_error( "PD_StartFastDiagName: The FD trace file path '$filename' ( length '$folderpath') + filename '$templateFileName' ( length $filenamelength) exceeds maximum length '$max_pathlength', choose shorter path!", 114 );
            $err_flg = 1;
        }
    }

    return 0 if ($err_flg);
    
    $numberOfCANIds = Validate_Nbr_CAN_IDS($numberOfCANIds);
    return 0 unless ($numberOfCANIds);    #return if the Nbr of CAN IDs for Fast Diagnosis is 0(in PSDiagCANParameter.txt file) for the respective project

    foreach my $ecu_memory_label_UBYTE ( @{$names_aref} ) {
        my $read_mem_value_aref = PD_ReadMemoryByName($ecu_memory_label_UBYTE);
        if ( scalar(@$read_mem_value_aref) < 1 ) {

            # Error is already set in PD_ReadMemoryByName
            return 0;
        }
    }

    # Default Value is 0 for isNextPOC - starts on current cycle
    $isNextPOC = 0 unless ( defined $isNextPOC );

    if ( defined $types_aref ) {

        unless ( scalar(@$types_aref) ) {
            S_set_error( "The types array reference passed as a parameter is empty\n", 109 );
            return 0;
        }

        #check $types_aref for undef elements
        if ( S_check_array( $types_aref, "\$types_aref" ) == 0 ) {
            S_set_error( "types_aref contains undefined value", 114 );
            return 0;
        }
        if ( scalar(@$names_aref) != scalar(@$types_aref) ) { S_set_error( "parameter array size is different", 109 ); return 0; }

        $noOfCells = 0;

        # check data
        for ( $count = 0 ; $count < scalar(@$types_aref) ; $count++ ) {
            unless ( $$types_aref[$count] =~ /^U8|S8|S10|U16|S16|U32|S32|U64|S64$/i ) {
                S_set_error( " wrong type at types_aref[$count]: @$types_aref[$count] != U8,S8,S10,U16,S16,U32,S32,U64,S64", 114 );
                return 0;
            }
            $$types_aref[$count] =~ /^(U|S)(\d+)$/i;
            my $bits = $2;
            $bits = 16 if ( $bits == 10 );    # treat S10 as 2 byte value
            $noOfCells += $bits / 8;
        }
    }
    else {
        # $types_aref will be filled with default U8 if not given
        $noOfCells = scalar(@$names_aref);
        $types_aref = [ ('U8') x $noOfCells ];
    }

    my $names_aref_length = scalar(@$names_aref);
    if ( $noOfCells > 28 ) { S_set_error( "The Nbr of cells $noOfCells or the Nbr of variables $names_aref_length passed to the Function exceeds the maximum allowed limit 28(Maximum of 28 cells are allowed for Fast Diagnosis) ", 109 ); return 0; }

    unless ($PD_initialized) {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive) {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline) {
        S_create_dummy_file($filename);
        $FastDiagActive = 1;
        return 1;
    }

    if ( $ABgeneration < 12 ) {
        if ( defined $shifts_aref ) {

            #check $shifts_aref for undef elements
            if ( S_check_array( $shifts_aref, "\$shifts_aref" ) == 0 ) {
                S_set_error( "shifts_aref contains undefined value", 114 );
                return 0;
            }
            if ( $noOfCells != scalar(@$shifts_aref) ) { S_set_error( "number of shifts and bytes to read do not correspond", 109 ); return 0; }

            # convert data to dec if required
            for ( $count = 0 ; $count < scalar(@$shifts_aref) ; $count++ ) {
                $$shifts_aref[$count] = S_0x2dec( $$shifts_aref[$count] );
            }
        }
        elsif ( $noOfCells < 9 ) {

            # $shifts_aref will be filled with default 0 if not given
            $shifts_aref = [ (0) x $noOfCells ];
        }
        else {
            $shifts_aref = [];    # not used
        }
        S_w2log( 3, " PD_StartFastDiagName:($noOfCells) - @$names_aref - @$types_aref - @$shifts_aref - $filename\n" );

        if ( $noOfCells < 9 ) {
            $stat = pd_StartFastName( $names_aref, $shifts_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );

            S_w2log( 5, "standard PD_StartFastDiagName ($stat)\n" );
        }
        else {
            $stat = pd_StartExtName( $names_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );

            S_w2log( 5, "extended PD_StartFastDiagName ($stat)\n" );
        }
    }
    else {
        $filename =~ s/\.(\S+)$//;    #To remove file extension
        make_path($filename);         #To create directory for full given path
        $shifts_aref = [];                                                                                            # not used
        $stat = pd_StartFastName( $names_aref, $shifts_aref, $types_aref, $filename, $numberOfCANIds, $isNextPOC );
        S_w2log( 5, "standard PD_StartFastDiagName ($stat) \n" );
    }

    check_status($stat);
    $FastDiagActive = 1;

    if ( $stat < 0 ) {
        S_set_error( "could not start FastDiagnostics", 121 );
        $FastDiagActive = 0;
    }

    return 1;
}

=head2 PD_StopFastDiag

     PD_StopFastDiag();

stop fast diagnosis

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_StopFastDiag
{

    S_w2log( 4, " PD_StopFastDiag\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is not already active
    unless ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is not Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $FastDiagActive = 0;
        return 1;
    }

    $stat = pd_StopFastDiag();
    check_status($stat);
    S_w2log( 5, "pd_StopFastDiag -> status : $stat\n" );

    if ( $stat >= 0 )
    {
        $FastDiagActive = 0;
    }

    S_w2log( 4, " PD_StopFastDiag done!! \n" );
    return 1;
}

=head1 Function Group 'device'

=head2 PD_CalculateChecksum

    PD_CalculateChecksum( $area [, $area1, , $area3, ...] );

    $area = same number as in WinDiag or label from 'CRC_AREA' in ProjectComst

calculate checksum for area, list of areas is also possible

    e.g.  PD_CalculateChecksum( 3 );
          PD_CalculateChecksum( 'PROG_VAR_TBL', 'ASIC_CONF_TBL' );

    'CRC_AREA' => {
        'PROG_VAR_TBL' => '1',
        'ASIC_CONF_TBL' => '4',
    },

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_CalculateChecksum
{
    my @areas = @_;
    my ($mapped_area);
    S_w2log( 5, "PD_CalculateChecksum: Checksum calculation for areas @areas \n" );

    if ( scalar(@areas) < 1 )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_CalculateChecksum( area(s) )", 110 );
        return 0;
    }

    #check @areas for undef elements
    unless ( S_check_array( \@areas, "\$areas" ) )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_CalculateChecksum' is not support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    foreach my $area (@areas)
    {

        #map area if necessary
        unless ( defined( $mapped_area = $main::ProjectDefaults->{'CRC_AREA'}{$area} ) )
        {
            if ( $area =~ /^\d+$/ )
            {
                $mapped_area = $area;
            }
            else
            {
                S_set_error( "could not resolve area $area", 114 );
                return 1;
            }
        }

        S_w2log( 4, "PD_CalculateChecksum for area  :: $mapped_area\n" );
        $stat = pd_CalculateChecksum($mapped_area);
        check_status($stat);
        S_w2log( 5, "Status of calculated checksum for area $mapped_area: $stat\n" );
    }

    return 1;
}

=head2 PD_Device_configuration

    PD_Device_configuration( $mode, $devices_aref [, $checksum_flag [, $resetecu_flag]] );

$mode may be "set", "clear" to configure/unconfigue or "set_Mon", "clear_Mon" to enable/disable monitoring.
$devices_aref is a reference to an array of labels of 'DEVICE_CONFIG' mapping from ProjectConst

$checksum_flag, $resetecu_flag are optional. may be passed as 'yes' or 'no'.
default value is 'yes', if not given.

configure devices, calculate checksum and perform reset

works for SQUIBs, PASes, SWITCHES, LAMPs, CUST_DEVICES, SpecialBehaviourbits, Section Activators and ASICs.

Monitoring will not work on ASICs, SpecialBehaviourbits, Section Activators.

NOTE:=> monitoring and configuring is independant (different to in WinDiag) !
     e.g. PD_Device_configuration( 'clear', ['UFSL','AB1FD','FLIC'] );
     section 0 (sections to load) cannot activated/deactivated

     => CRC checksum is calculated automatically (triggered) by Production diagnosis when writing CRC protected data.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_Device_configuration
{

    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'PD_Device_configuration( $mode, $devices_aref [, $checksum_flag [, $resetecu_flag]] )', @args );
    my $mode          = shift @args;
    my $devices_aref  = shift @args;
    my $checksum_flag = shift @args;
    my $resetecu_flag = shift @args;

    my ( %device_value, $setflag, $value_aref );

    S_w2log( 4, "PD_Device_configuration of mode $mode \n" );

    # assign default values , if not defined
    $checksum_flag = 'yes' unless defined($checksum_flag);
    $resetecu_flag = 'yes' unless defined($resetecu_flag);

    #validate $checksum_flag
    if ( $checksum_flag !~ /yes/i && $checksum_flag !~ /no/i )
    {
        S_set_error( "! invalid checksum flag $checksum_flag. shall be 'yes' or 'no'", 114 );
        return 0;
    }

    #validate $resetecu_flag
    if ( $resetecu_flag !~ /yes/i && $resetecu_flag !~ /no/i )
    {
        S_set_error( "! invalid reset ECU flag $resetecu_flag. shall be 'yes' or 'no'", 114 );
        return 0;
    }

    # change to lower case for string comparision
    # regular expression check (=~, !~) will take more time than string comparision
    $checksum_flag = lc $checksum_flag;
    $resetecu_flag = lc $resetecu_flag;

    #validate crc_area is exist or not in project defaults
    #only AB10 supports and contains crc area
    if ( $ABgeneration <= 10 )
    {
        if ( $checksum_flag eq 'yes' && !defined( $main::ProjectDefaults->{'CRC_AREA'}{'PROG_VAR_TBL'} ) )
        {
            S_set_error( "! CRC_AREA for PROG_VAR_TBL not found in ProjectConst )", 114 );
            return 0;
        }
        if ( $checksum_flag eq 'yes' && !defined( $main::ProjectDefaults->{'CRC_AREA'}{'ASIC_CONF_TBL'} ) )
        {
            S_set_error( "! CRC_AREA for ASIC_CONF_TBL not found in ProjectConst )", 114 );
            return 0;
        }
        if ( $checksum_flag eq 'yes' && !defined( $main::ProjectDefaults->{'CRC_AREA'}{'PAR_SEC_TBL'} ) )
        {
            S_set_error( "! CRC_AREA for PAR_SEC_TBL not found in ProjectConst )", 114 );
            return 0;
        }
    }

    my @devices = @$devices_aref;

    S_w2log( 5, "PD_Device_configuration $mode: " . join( ',', @devices ) . " \n" );

    #   map devices
    foreach my $device (@devices)
    {
        if ( defined $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device} )
        {
            $device = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device};

            #Loading\unloading of 'Sections to load' cannot be done dynamically
            if ( defined( $parSEC_index{$device} ) && $parSEC_index{$device} == 0 && $ABgeneration <= 10)
            {
                S_set_error( "Section '$device' cannot be activated/deactivated", 114 );
                return 0;
            }
        }
        else
        {
            S_set_error( " Device '$device' not found in ProjectConst", 114 );
            return 0;
        }
    }

    #set error if PD is not initialized
    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    DeviceConfigurationCheck( \@devices, $mode );

    #if checksum flag is set, perform crc checksum calculation(supports only AB10)
    #AB12 crc checksum calculated automatically
    if ( $checksum_flag eq 'yes' && $ABgeneration <= 10 )
    {
        my $area_ext    = $main::ProjectDefaults->{'CRC_AREA'}{'PROG_VAR_TBL'};
        my $area_asic   = $main::ProjectDefaults->{'CRC_AREA'}{'ASIC_CONF_TBL'};
        my $area_parsec = $main::ProjectDefaults->{'CRC_AREA'}{'PAR_SEC_TBL'};

        # calculate CRC checksum
        S_w2log( 5, "-> calculate checksum for area :: $area_ext + $area_asic + $area_parsec\n" );
        $stat = pd_CalculateChecksum($area_ext);
        check_status($stat);
        $stat = pd_CalculateChecksum($area_asic);
        check_status($stat);
        $stat = pd_CalculateChecksum($area_parsec);
        check_status($stat);
    }

    # reset ECU
    if ( $resetecu_flag eq 'yes' )
    {
        $stat = pd_ECUreset(0);
        S_w2log( 5, "PD reset status :: $stat\n" );
        check_status($stat);
    }

    S_w2log( 4, "PD_Device_configuration (checksum calculation: $checksum_flag, reset ECU: $resetecu_flag) done \n" );

    return 1;
}

=head2 PD_DumpDeviceConfiguration

    $device_data_href = PD_DumpDeviceConfiguration( );

Dump device configuration info to report, similar to Windiag
             SQUIBs, PASes, SWITCHES, LAMPs, CUST_DEVICES, SpecialBehaviourbits, Section Activators and ASICs

This function also return the device configuration structure.

Will access ECU to read out configuration data for AB10.

The variable names that are read are defined in the data structure $pdConfig_href with the keys 'monitored', 'configured' and 'real':

    my $pdConfig_href = {
        'DEVICE_CONFIG_VARIABLES' => {
            '10' => {
                ...
                'squibs'       => {
                    ...
                    'monitored'  => 'S_PDMProgVarTbl1_XXE.A_ExtDevMon_U8X',
                    'configured' => 'S_PDMProgVarTbl1_XXE.A_ExtDevConf_U8X',
                    'real'       => 'S_PDMExtDevPresenceTbl_XXR.A_ExtDev_U8X',
                },
                ...
            },
            '12' => {
                ...
                'squibs'       => {
                    ...
                    'monitored'  => 'rb_sycf_SysConfSquib_dfst.SquibMonitored_ab8',
                    'real'       => 'rb_sycf_SquibPresence_ab8',
                    'configured' => 'rb_sycf_SysConfSquib_dfst.SquibConfigured_ab8',
                },
                ...
            },
        },
    };


If a project needs other variable names then the default can be overwritten by defining an appropriate data structure in the project const file:

    $Defaults->{"DEVICE_CONFIG_VARIABLES"} = {
        '10' => {
            ...
        },
        '12' => {
            ...
        },
    };
    
In order to get individual value of monitored bit of 'AB1FD' ,

	$ReturnVariable{'DeviceType'}{'Real \ Mon \ Prog'}{'DeviceName'}

	$$pdDumpDeviceConfiguration{'squib'}{'Mon'}{'AB1FD'}

Error return : 0

offline return :: {}

Succes return :: Hash Structure

Example:

    my $device_data_href = {
          'squib' => {
                       'Real' => {
                                'variable' => 'rb_sycf_SquibPresence_ab8',
                                'name' => 'Real',
                                'bits' => [
                                            '0',
                                            '0',
                                            '0'
                                          ]
                                �AB1FD� => 0,
                                �AB1FP� => 1,
                                'AB2FD' => 1,
                                ...
                              },
                     },
          'pases' => {
                       'Real' => {
                                'variable' => 'rb_sycp_PsPresence_ab8',
                                'name' => 'Real',
                                'bits' => [
                                            '0',
                                            '0',
                                            '0',
                                            '0',
                                            '0'
                                          ]
                                 'UfsD'   => '0',
                                 'UfsP'   => '0',
                                 'PasFD'  => '0',
                                 ...
                              },
                     },
          'switches' => {
                          'Real' => {
                                   'variable' => 'rb_sycs_SwitchPresence_ab8',
                                   'name' => 'Real',
                                   'bits' => [
                                               '0',
                                               '0',
                                               '0',
                                               '0',
                                               '0'
                                             ]
                                    'PADS1' => '0',
                                    'PADS2' => '0',
                                    'BLFD'  => '0',
                                    ...
                                 },
                        },
          'asic' => {
                      'Real' => {
                               'variable' => 'rb_syca_AsicPresence_ab8',
                               'name' => 'Real',
                               'bits' => []
                               },
                             },
                       'SystemAsic1'	=> '0',
                       'SystemAsic2'	=> '0',
                       'CentralSensorMain' => '0',
                       'CentralSensorPlausi' => '0',
                       ...
        };

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_DumpDeviceConfiguration
{

    S_w2log( 5, "PD_DumpDeviceConfiguration\n" );

    my (%dev_config_data);

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return {} if $main::opt_offline;

    my @devices;

    @devices = @asics;
    $dev_config_data{'asic'} = DumpSingleDeviceConfiguration( 'asics', 'Asic', \@devices );

    if ( $ABgeneration <= 10 )
    {

        # in AB10 many devices are grouped together and the config information is read from a single variable structure
        @devices = @squibs;
        push( @devices, @pases, @switches, @lamps, @cust );    # put devices in right order
        $dev_config_data{'squib'} = DumpSingleDeviceConfiguration( 'squibs', 'Device', \@devices );

        # SpBehaviour and parSections are only supported for AB10
        @devices = @SpBehaviour;
        $dev_config_data{'spb'} = DumpSingleDeviceConfiguration( 'SpBehaviour', 'SpecialBehaviourBit', \@devices );

        @devices = @parSections;
        $dev_config_data{'pars'} = DumpSingleDeviceConfiguration( 'parSections', 'SectionActivators', \@devices );
    }
    else
    {
        # in AB12 each section has its own config variable structure
        @devices = @squibs;
        $dev_config_data{'squib'} = DumpSingleDeviceConfiguration( 'squibs', 'Squibs', \@devices );

        @devices = @pases;
        $dev_config_data{'pases'} = DumpSingleDeviceConfiguration( 'pases', 'Pases', \@devices );

        @devices = @switches;
        $dev_config_data{'switches'} = DumpSingleDeviceConfiguration( 'switches', 'Switches', \@devices );

        @devices = @SpBehaviour;
        $dev_config_data{'spb'} = DumpSingleDeviceConfiguration( 'SpBehaviour', 'SpecialBehaviourBit', \@devices );

        @devices = @parSections;
        $dev_config_data{'pars'} = DumpSingleDeviceConfiguration( 'parSections', 'SectionActivators', \@devices );
        
        @devices = @lamps;
        $dev_config_data{'lamps'} = DumpSingleDeviceConfiguration( 'lamps', 'lamps', \@devices );

    }

    return ( \%dev_config_data );
}

=head2 PD_get_device_config

     ($Real,$Monitored_ID,$Prog) = PD_get_device_config( $device );

returns the configuration of Device connected to ECU.

$device should contain a label from 'DEVICE_CONFIG' mapping of ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

Return values are,

B<$Real - > 0 or 1  ,

B<$Monitored_ID - > B<0 or 1> for SQUIBs, PASes, SWITCHES, LAMPs, CUST_DEVICES |  B<Integer ASIC_ID> for ASICs,

B<$Prog - > 0 or 1

B<Note:  For Special behaviour bits and section activators Real and Monitored_ID always remain I<0> >

offline + Error return : (0,0,0)

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_device_config
{
    my $label = shift;
    my @dummy_return = ( 0, 0, 0 );
    my ( $value_aref, $configured, $monitored, $real, $label_configured, $label_monitored, $label_real, $byte, $bitmask );

    unless ( defined $label )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_get_device_config( label )", 110 );
        return @dummy_return;
    }

    S_w2log( 4, "PD_get_device_config : :$label\n" );

    # map devices
    if ( defined $main::ProjectDefaults->{'DEVICE_CONFIG'}{$label} )
    {
        $label = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$label};
    }
    else
    {
        S_set_error( " Device '$label' not found in ProjectConst", 114 );
        return @dummy_return;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return @dummy_return;
    }

    return (@dummy_return) if $main::opt_offline;

    $configured = $monitored = $real = 0;

    $byte    = $device_conf_tbl->{$label}{'byte'};
    $bitmask = $device_conf_tbl->{$label}{'bitmask'};

    if ( exists $ASIC_index{$label} )    #asic
    {
        $label_monitored  = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"asics"}{"id"};
        $label_real       = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"asics"}{"real"};
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"asics"}{"configured"};
    }
    elsif ( exists( $PAS_index{$label} ) && $ABgeneration == 12 )    #Pases
    {
        $label_real       = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"pases"}{"real"};
        $label_monitored  = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"pases"}{"monitored"};
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"pases"}{"configured"};
    }
    elsif ( exists( $SW_index{$label} ) && $ABgeneration == 12 )     #Switch
    {
        $label_real       = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"switches"}{"real"};
        $label_monitored  = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"switches"}{"monitored"};
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"switches"}{"configured"};
    }
    elsif ( exists( $WL_index{$label} ) && $ABgeneration == 12 )     #Lamps
    {
        $label_real       = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"lamps"}{"real"};
        $label_monitored  = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"lamps"}{"monitored"};
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"lamps"}{"configured"};
    }
    
    elsif ( exists( $SPB_index{$label} ) && $ABgeneration == 12 )     #Special behaviour bit
    {
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"SpBehaviour"}{"configured"};
    }
    
    elsif ( exists( $parSEC_index{$label} ) && $ABgeneration == 12 )     #section activator
    {
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"parSections"}{"configured"};
    }

    #if SQUIBs & CUST_index(AB10 and AB12), LAMPs(AB10), SWITCHES(AB10), Pases (AB10)
    elsif ( exists( $SQ_index{$label} ) or exists( $SW_index{$label} ) or exists( $PAS_index{$label} ) or exists( $WL_index{$label} ) or exists( $CUST_index{$label} ) )
    {
        $label_real       = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"squibs"}{"real"};
        $label_monitored  = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"squibs"}{"monitored"};
        $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"squibs"}{"configured"};
    }

    #if given device is Special behaviour bit
    elsif ( exists( $SPB_index{$label} ) && $ABgeneration <= 10 )
    {
        $label_configured = $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"SpBehaviour"}{"configured"};
    }

    #if given device is section activator
    elsif ( exists( $parSEC_index{$label} ) && $ABgeneration <= 10 )
    {
        $label_configured = $label_configured = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{"parSections"}{"configured"};
    }
    else
    {    #if no mapping found in SAD file , report error (Probably mismatch between CFG, SAD files)
        S_set_error( " Unknown device $label", 114 );
        return @dummy_return;
    }
    
    if((exists $SPB_index{$label} || exists $parSEC_index{$label}) && $ABgeneration == 12) {
        ( $stat, $value_aref ) = pd_ReadName("$label_configured($byte)");                     # configured
        check_status($stat);
        if ( ( S_0x2dec( $$value_aref[0] ) & $bitmask ) != 0 )
        {
            $configured = 1;
        }
        S_w2log( 5, "$label => Real : $real , Monitored : $monitored , Prog : $configured\n" );
        return ( $real, $monitored, $configured );
    }

    if ( exists $ASIC_index{$label} )    #if given device is asic
    {
        ( $stat, $value_aref ) = pd_ReadName("$label_monitored($ASIC_index{$label})");    # ID
        check_status($stat);
        $monitored = sprintf( "0x%X", S_0x2dec( $$value_aref[0] ) );
    }
    else
    {
        #find monitored, configured, real status for all devices except asic
        ( $stat, $value_aref ) = pd_ReadName("$label_monitored($byte)");                  # monitored
        check_status($stat);
        if ( ( S_0x2dec( $$value_aref[0] ) & $bitmask ) != 0 )
        {
            $monitored = 1;
        }
    }

    ( $stat, $value_aref ) = pd_ReadName("$label_real($byte)");                           # real
    check_status($stat);
    if ( ( S_0x2dec( $$value_aref[0] ) & $bitmask ) != 0 )
    {
        $real = 1;
    }

    ( $stat, $value_aref ) = pd_ReadName("$label_configured($byte)");                     # configured
    check_status($stat);
    if ( ( S_0x2dec( $$value_aref[0] ) & $bitmask ) != 0 )
    {
        $configured = 1;
    }

    S_w2log( 5, "$label => Real : $real , Monitored : $monitored , Prog : $configured\n" );
    return ( $real, $monitored, $configured );
}

=head2 PD_get_device_index

     $index = PD_get_device_index( $device );

Returns index of device from 'DEVICE_CONFIG' which is read from SAD file.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

Error return : 0

offline return : 1

Success return :: Index of the device

     e.g.
      0 = PD_get_device_index( 'AB1FD' );
      1 = PD_get_device_index( 'AB2FD' );
      3 = PD_get_device_index( 'FLIC' );

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_device_index
{
    my $label = shift;
    my $index = 0;

    unless ( defined $label )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_get_device_index( device )", 110 );
        return 0;
    }

    S_w2log( 4, "PD_get_device_index :: $label \n" );

    # map devices
    if ( defined $main::ProjectDefaults->{'DEVICE_CONFIG'}{$label} )
    {
        $label = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$label};
    }
    else
    {
        S_set_error( " Device '$label' not found in ProjectConst", 114 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    return 1 if $main::opt_offline;

    if ( exists $SQ_index{$label} )
    {
        $index = $SQ_index{$label};
        S_w2log( 5, "-> '$label' is SQ ($index)\n" );
    }
    elsif ( exists $SW_index{$label} )
    {
        $index = $SW_index{$label};
        S_w2log( 5, "-> '$label' is SW ($index)\n" );
    }
    elsif ( exists $PAS_index{$label} )
    {
        $index = $PAS_index{$label};
        S_w2log( 5, "-> '$label' is PAS ($index)\n" );
    }
    elsif ( exists $WL_index{$label} )
    {
        $index = $WL_index{$label};
        S_w2log( 5, "-> '$label' is WL ($index)\n" );
    }
    elsif ( exists $CUST_index{$label} )
    {
        $index = $CUST_index{$label};
        S_w2log( 5, "-> '$label' is CUST ($index)\n" );
    }
    elsif ( exists $ASIC_index{$label} )
    {
        $index = $ASIC_index{$label};
        S_w2log( 5, "-> '$label' is ASIC ($index)\n" );
    }
    elsif ( exists $SPB_index{$label} )
    {
        $index = $SPB_index{$label};
        S_w2log( 5, "-> '$label' is Special Behaviour Bit ($index)\n" );
    }
    elsif ( exists $parSEC_index{$label} )
    {
        $index = $parSEC_index{$label};
        S_w2log( 5, "-> '$label' is Section Activator ($index)\n" );
    }
    else
    {
        S_set_error( " unknown device $label", 114 );
        return 0;
    }

    return $index;

}

=head1 Function Group 'edr'

=head2 PD_ClearCrashRecorder

    ($status,$response_aref) = PD_ClearCrashRecorder( [, $clearEDR_Timeout_ms ] );

Sends the service for Clear crash recorder and returns the ECU response after the crash recorder has been cleared 
or a timeout ($clearEDR_Timeout_ms) has occured (whatever comes earlier).

The success - 1 / failure - 0 of the function call can be obtained from first return value $status

B<Arguments:>

=over

=item $clearEDR_Timeout_ms 

(optional) Timeout in milliseconds. 
If not given then the timeout value is taken from project const:  'TIMER' => { 'TIMER_CLEAR_CRASH_RECORDER' => 30000,} (value of 30000 is an example only).
If also this is not given, then it is 10000ms.

=back

B<Return Value:>

=over

=item $status 

On success value is set to 1, on failure and error conditions value is set to 0.

=item $response_aref 

Response to the clear crash recorder request from the ECU.

=back

B<Examples:>

    ($status,$response_aref) = PD_ClearCrashRecorder();
    ($status,$response_aref) = PD_ClearCrashRecorder( 9000 );
    ($status,$response_aref) = PD_ClearCrashRecorder( 14000 );

B<Notes:> 

Supported AB Generations:: B<10 and 12>

=cut

sub PD_ClearCrashRecorder
{
	my @args = @_;
    my $dummy_return = [];
    return (0,$dummy_return) unless S_checkFunctionArguments( 'PD_ClearCrashRecorder( [, $clearEDR_Timeout_ms ] )', @args );

	my $clearEDR_Timeout_ms = shift @args;# optional Input : Timeout Value in milli seconds.

	my $clearEDR_flag = 0; # flag indicating clearEDR success or failure

    #set error if PD is not initialized
    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return (0,$dummy_return);
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return (0,$dummy_return);
    }

    S_w2log( 4, "PD_ClearCrashRecorder: Clears the crash record data \n" );

    if (defined($clearEDR_Timeout_ms) )
    {
       S_w2log( 1, "PD_ClearCrashRecorder: Timeout time given by the user : $clearEDR_Timeout_ms \n" );
    }
    else
    {
        # try to get timeout time from Project Defaults
        $clearEDR_Timeout_ms = S_get_contents_of_hash_NOERROR(['TIMER', 'TIMER_CLEAR_CRASH_RECORDER']);
        if(defined $clearEDR_Timeout_ms){
            S_w2log( 1, "PD_ClearCrashRecorder: Timeout time given in project defaults timer section : $clearEDR_Timeout_ms \n" );
        }
        else{
            $clearEDR_Timeout_ms = 10000 ;# By default wait time is 10s story 29656 .
            S_w2log( 1, "PD_ClearCrashRecorder: Timeout time not given by the user : By default - 10sec \n" );
        }
    }

    return (1,$dummy_return) if $main::opt_offline;

    my $response_aref;
    ( $stat, $response_aref ) = pd_ClearCrashRecorder();
    check_status($stat);
    S_w2log( 4, "pd_ClearCrashRecorder(from DLL) status : $stat\n" );

    S_w2log( 3, "PD_ClearCrashRecorder : Response received : @$response_aref bytes\n" );

    if($stat == 0)
    {
        #Positive response for Clear EDR service 48H for AB12 and 78H for AB10 - refer in PD SRS
        S_w2log( 3, "PD_ClearCrashRecorder : Positive response \n" );

        my $ecu_status;
        my $timer_ms= 5000;# By default,this mandatory delay is from ProductionDiagnosis.dll. So the timer count starts from 5000ms
        do
        {
            $ecu_status = PD_GetECUStatus();
            if($$ecu_status[1]==0)
            {
                S_w2log( 4, "PD_ClearCrashRecorder: Clearing is completed after $timer_ms milli seconds\n" );
                $clearEDR_flag  = 1 ;
                return ( $clearEDR_flag , $response_aref );
            }
            else
            {
                if($clearEDR_Timeout_ms>5000)#Timer should get incrimented only when user given timeout value is specified and more than 5sec
                {
                $timer_ms = $timer_ms+ 1000;
                S_wait_ms(1000);
                }
            }
        }while($timer_ms < $clearEDR_Timeout_ms);
        if($clearEDR_flag == 0)
        {
            S_set_error("PD_ClearCrashRecorder: Clearing Process is still active after $timer_ms milli seconds ", 114);
        }
    }
    return ( $clearEDR_flag , $response_aref );
}

=head2 PD_ReadCrashRecorder

    $response_aref = PD_ReadCrashRecorder($dataId [ , $filename]);

It will read crash records based on $dataId.

B<Inputs:>

$dataID is a hex byte. Depending on its value normal crash records or Pedestrian protection crash records are read.

    [0x00 to 0x0F] => Normal crash record

        0x00 => Report the most recent crash record.(Normal crash record)
        0x01 => Report the previous record of most recent one. (Normal crash record) and so on.

    [0x10 to 0x1F] => Pedpro crash record

        0x10 => Report the most recent crash record.(Pedpro crash record)
        0x11 => Report the previous record of most recent one. (Pedpro crash record) and so on.

$filename: (optional) if given a crash recorder dump is stored in the file $filename

B<Inputs:>

    $response_aref : ECU response on read crash recorder service.

B<Example:>
     
    my $response_aref = PD_ReadCrashRecorder(0x00);

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_ReadCrashRecorder
{
    my @args = @_;
    return 0
        unless S_checkFunctionArguments( 'PD_ReadCrashRecorder( $dataId [ , $filename] )', @args );

    my $dataId = shift @args;
    my $filename = shift @args;

    S_w2log( 5, "PD_ReadCrashRecorder \n" );

    my $response_aref;
    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    if ( $ABgeneration < 12 )
    {
        S_set_error( "The function 'PD_ReadCrashRecorder' is not currently support for AB10 project \n", 20 );
        return 0;
    }

    ( $stat, $response_aref ) = pd_ReadCrashRecorder($dataId);
    S_w2log( 5, "-> status : $stat\n" );
    check_status($stat);

    if ( scalar(@$response_aref) < 1 )
    {
        S_w2log( 3, "PD_ReadCrashRecorder : No response received\n" );
        return 0;
    }
    S_w2log( 3, "PD_ReadCrashRecorder : response received : @$response_aref bytes\n" );

    if (defined $filename){
        S_w2log( 3, "PD_ReadCrashRecorder : dumping the crash recorder to given file\n" );
 		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time());
		my $time = sprintf("%04d%02d%02d_%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec);
		my $dataId_Hex = sprintf("%02X", $dataId);
		my $serviceID = "0xFD$dataId_Hex";
        PD_DumpCrashRecorder($response_aref, $filename, $serviceID, $time);
    }

    return $response_aref;
}

=head2 PD_DumpCrashRecorder

    PD_DumpCrashRecorder($response_aref, $filename, [$serviceID, $timeStamp]);

It will dump a crash record which was read with PD_ReadCrashRecorder in the same format as "PSdiag" (format version: 2).
The function is not exported and will be called by PD_ReadCrashRecorder if the optional input parameter
$filename is given (see API docu of PD_ReadCrashRecorder)

File Format Description:
:2 #file format version, immer
:20160725_095921
:AB1200_B4_0030_BB000000_Cat2
:0x1232 #variant
:0x3432 #version
:0x3020 #algo project id
:0x34   #algo parameter id
:0xFD00 # crash entry
D5 # PD Response Length
47 # PD ID
FD # Data Identifier
00 # Data Identifier
00 # EDR Byte Data
01
00
..
..
..
FF # checksum


B<Inputs:>

    $response_aref : content which was returned by PD_ReadCrashRecorder
    $filename : Complete file name (with path) of .txt file where Dump shall be stored
    $serviceID : (optional) service ID which was called to obtain $response_aref (0xFD00, 0xFD01,...)
    $timeStamp : (optional) Time stamp in format YearMonthDay_HourMinSec when the read crash recorder service was called
    
If optional parameters are not given, then the corresponding data in the dump file will be 'not available'.

Error return : 0

offline return : 1

=cut

sub PD_DumpCrashRecorder
{
    my $response_aref = shift;
    my $filename = shift;
    my $serviceID = shift;
    my $timeStamp = shift;
    my $text4file;

    S_w2log( 5, "PD_DumpCrashRecorder \n" );
	my @arguments = ($response_aref, $filename ,$serviceID, $timeStamp);
	return unless S_checkFunctionArguments ( 'PD_DumpCrashRecorder ( $response_aref, $filename [,$serviceID, $timeStamp])', @arguments );
    $serviceID = 'not available' if (not defined $serviceID);
    $timeStamp = 'not available' if (not defined $timeStamp);

    S_w2log( 5, "Loop through PD response converting decimal to hex and transforming to string for dump\n" );
    foreach my $edr_byte(@$response_aref){
        $text4file .= sprintf '%.2X', $edr_byte;
        $text4file .= "\n";
    }

    S_w2log( 5, "Get SW version" );
    my $swVersion = $ECU_SWInfo{'SW Version'};
    $swVersion = 'not available' if (not defined $swVersion);

    S_w2log( 5, "Get variant information (number and version) \n" );
	my $variantNumber = PD_ReadMemoryByName_NOERROR( 'rb_swv_SwVersionNvmCfg_st.VariantID_u16' );
	if(@{$variantNumber}){
		$variantNumber = S_aref2hex($variantNumber);		
	}
	else {
		$variantNumber = 'not available';
	}
	my $variantVersion = PD_ReadMemoryByName_NOERROR( 'rb_swv_SwVersionNvmCfg_st.VariantVersion_u16' );
	if(@{$variantVersion}){
		$variantVersion = S_aref2hex($variantVersion);		
	}
	else {
		$variantVersion = 'not available';
	}

    S_w2log( 5, "Get algo info (project ID, parameter id)\n" );
	my $projID_HB = PD_ReadMemoryByName_NOERROR( 'rb_acc_AlgoIds_st.ProjIdHB_u8' );
	my $projID_LB = PD_ReadMemoryByName_NOERROR( 'rb_acc_AlgoIds_st.ProjIdLB_u8' );
	my $algoProjectID;
	if(@{$projID_HB} and @{$projID_LB}){
		my @projectID_array = (@{$projID_HB}, @{$projID_LB});
		$algoProjectID = S_aref2hex(\@projectID_array);		
	}
	else {
		$algoProjectID = 'not available';
	}
 	my $algoParaID = PD_ReadMemoryByName_NOERROR( 'rb_acc_AlgoIds_st.ParaId_u8' );
 	if(@{$algoParaID}){
	 	$algoParaID = S_aref2hex($algoParaID); 		
 	}
 	else{
	 	$algoParaID = 'not available'; 		
 	}
   
	S_w2log( 5, "open file '$filename' \n" );
    if (open(my $fh, '>', "$filename"))
    {
        print $fh ":2 # File Format Version.\n";
        print $fh ":$timeStamp # Timestamp\n";
        print $fh ":$swVersion # Software version.\n";
        print $fh ":$variantNumber # Variant number.\n";
        print $fh ":$variantVersion # Variant version.\n";
        print $fh ":$algoProjectID # Algo Project ID.\n";
        print $fh ":$algoParaID # Algo Parameter ID.\n";		
        print $fh ":$serviceID # Crash Entry.\n"; # crash entry
        print $fh $text4file;
        close $fh;
    }
    else { 
    	S_set_error( " PD_DumpCrashRecorder : could not create $filename", 1 );
        return 0;
    }

    return 1;
}

=head1 Function Group 'firing'

=head2 PD_Prepare_electronic_firing

    $returnValue = PD_Prepare_electronic_firing( ['AB1FD','AB2FD'] ); # AB10
    $returnValue = PD_Prepare_electronic_firing( ); # AB12
    
This function is to prepare ECU for electronic firing. Safety path is enabled to facilitate electronic firing.
Plant mode is activated within this function for AB12, In case of AB10 ProdMode needs to be set explicitly.


B<Arguments:>

=over

=item For AB10: $squibs_aref 

for devices mentioned in $squibs_aref electronic firing safety path is enabled.
Devices mentioned in $squibs_aref must be a part of DEVICE_CONFIG section mentioned in project constant.

=item For AB12: No paramters 

By default, safety path is enabled for all the devices.

=back

B<Return Value:>

=over

=item $returnValue 

$returnValue = 1 in Online and offline mode
$returnValue = 0 in if there is an error

=back

B<Examples:>

    $returnValue = PD_Prepare_electronic_firing( ['AB1FD','AB2FD'] ); # AB10
    $returnValue = PD_Prepare_electronic_firing( ); # AB12
    
B<Notes:> 

This function needs to be called before calling PD_Trigger_electronic_firing.

=cut

sub PD_Prepare_electronic_firing
{
    my $squibs_aref = shift;
    my $value_aref;
    my @SQ2fire = ( 0, 0, 0, 0 );

    S_w2log( 4, "PD_Prepare_electronic_firing\n" );

    if ( $ABgeneration < 12 )
    {
        unless ( defined($squibs_aref) )
        {
            S_set_error( "! too less parameters ! SYNTAX: PD_Prepare_electronic_firing( \$squibs_aref )", 110 );
            return 0;
        }

        #check $squibs_aref for undef elements
        if ( S_check_array( $squibs_aref, "\$squibs_aref" ) == 0 )
        {
            S_set_error( "S_check_array reported an error", 114 );
            return 0;
        }
    }
    else
    {
        if ( defined($squibs_aref) )
        {
            S_set_error( "electronic firing for selected devices not supported in AB12, always ALL devices will be fired", 0 );#warning is given
        }

    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $ELFenabled = 1;
        return 1;
    }

    if ( $ABgeneration < 12 )
    {
        my @devices = @$squibs_aref;

        # map devices
        foreach my $device (@devices)
        {
            if ( defined $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device} )
            {
                $device = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$device};
                unless ( exists $SQ_index{$device} )
                {
                    S_set_error( " device $device is not a squib", 114 );
                    return 0;
                }
            }
            else
            {
                S_set_error( " Device '$device' not found in ProjectConst", 114 );
                return 0;
            }
        }

        my $SQbyte;

        #e.g.
        # 0,0,0,0x01 = AB1FD # A_CFCFiringCounter_U8R(0)
        # 0,0,0,0x02 = AB2FD # A_CFCFiringCounter_U8R(1)
        # 0,0,0,0x04 = AB1FP # A_CFCFiringCounter_U8R(2)

        # set bit in byte according to device (reverse byte order)
        foreach my $device (@devices)
        {
            $SQbyte = 3 - $device_conf_tbl->{$device}{'byte'};
            $SQ2fire[$SQbyte] = S_bitmask_set( $SQ2fire[$SQbyte], $device_conf_tbl->{$device}{'bitmask'}, 1 );
        }

        my @DecryptionKey = ( 0x39, 0xAF );
        my @Pattern = ( 0x55, 0xAA, 0x55, 0xAA );

        S_w2log( 4, "PD_Prepare_electronic_firing\n" );
        S_w2log( 4, "DecryptionKey " . S_aref2hex( \@DecryptionKey ) . "\n" );
        S_w2log( 4, "Pattern " . S_aref2hex( \@Pattern ) . "\n" );
        S_w2log( 4, "SQ2fire " . S_aref2hex( \@SQ2fire ) . "\n" );

        # 'S_PDMProgVarTbl1_XXE.V_ProdMode_U16X' check if ELF bit is set in 2. byte: 0bxxx1xxxx, else error
        S_w2log( 5, "check if ProdMode is set for electronic firing\n" );
        ( $stat, $value_aref ) = pd_ReadName('S_PDMProgVarTbl1_XXE.V_ProdMode_U16X');
        check_status($stat);
        my $ProdMode = S_aref2dec( $value_aref, 'U16' );
        if ( ( $ProdMode & 16 ) == 16 )
        {
            S_w2log( 5, "OK: ProdMode is set for electronic firing\n" );
        }
        else
        {
            S_set_error( "ProdMode is not set for electronic firing : " . S_aref2hex($value_aref) . "\n", 5 );
            return 0;
        }

        # convert to dec
        foreach (@SQ2fire)
        {
            $_ = S_0x2dec($_);
        }

        S_w2log( 5, "*** Select Devices for firing in RAM for electrical firing\n" );
        $stat = pd_WriteName( 'V_SQFHighSidePSVector_U32R', \@SQ2fire );
        check_status($stat);
        $stat = pd_WriteName( 'V_SQFLowSidePSVector_U32R', \@SQ2fire );
        check_status($stat);

        S_w2log( 5, "*** Enable HW-Path for electrical firing\n" );
        $stat = pd_WriteName( 'V_DPLSafetyKey_U32R', [ 0x5A, 0x5A, 0x5A, 0x5A ] );
        check_status($stat);

        S_w2log( 5, "*** Write deployment Key for electrical firing\n" );
        $stat = pd_WriteName( 'V_DPLDecryptionKey_U16R', \@DecryptionKey );
        check_status($stat);

        S_w2log( 5, "*** Prepare parameter in RAM for electrical firing PART 1\n" );
        $stat = pd_WriteName( 'V_SQFDeviceToFire_U32R', \@Pattern );
        check_status($stat);

        S_w2log( 5, "*** Prepare parameter in RAM for electrical firing PART 2\n" );
        $stat = pd_WriteName( 'V_SQFFirePlausibility_U32R', \@Pattern );
        check_status($stat);

        S_w2log( 5, "*** Prepare parameter in RAM for electrical firing PART 3\n" );
        $stat = pd_WriteName( 'V_ADDActivateFiring_U32R', \@Pattern );
        check_status($stat);

        $ELFenabled = 1;
    }
    else
    {    # AB12 or higher
        my $readLabel_arref;
        my $response_aref;

        S_w2log( 5, "PD_Prepare_electronic_firing: For AB12 sending request '04 18 AB 12 D9' to PD\n" );
        S_w2log( 5, "*** Prepare for electrical firing\n" );

        #Write "rb_sycg_ActivePlantModes_au8(0)" label value as 40 for enabling the fire Mode - Electronic firing
        $stat = pd_WriteName( 'rb_sycg_ActivePlantModes_au8(0)', [64] );
        check_status($stat);

        #Reading and checking "rb_sycg_ActivePlantModes_au8(0)" label value.
        ( $stat, $readLabel_arref ) = pd_ReadName('rb_sycg_ActivePlantModes_au8(0)');
        check_status($stat);

        if ( $$readLabel_arref[0] == 64 )
        {
            #Enabling Safety path
            ( $stat, $response_aref ) = pd_EleFrgEnableSafetyPath();
            check_status($stat);

            if ( $$response_aref[1] == 88 )
            {
                S_w2log( 4, "PD_Prepare_electronic_firing: success - Safety path is Enabled\n" );
                $ELFenabled = 1;
            }
            else
            {
                my $response_string = S_aref2hex($response_aref);
                $response_string =~ s/([0-9A-F]{2})/$1 /g;
                $response_string = substr( $response_string, 2 );
                S_set_error( "Prepare_electronic_firing not successful - Safety path is not Enabled. Response from ECU is $response_string", 5 );
                $ELFenabled = 0;
            }
        }
        else
        {
            S_set_error( "Fire Mode is not enabled for electronic firing : " . S_aref2hex($readLabel_arref) . "\n", 5 );
            return 0;
        }
    }

    return 1;

}

=head2 PD_Trigger_electronic_firing

     PD_Trigger_electronic_firing( );

Trigger electronic firing, has to be enabled by calling PD_Prepare_electronic_firing before.

NOTE: will not work if reset was done after calling PD_Prepare_electronic_firing, because values are only in RAM

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_Trigger_electronic_firing
{

    S_w2log( 4, "PD_Trigger_electronic_firing\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $ELFenabled = 0;
        return 1;
    }

    unless ($ELFenabled)
    {
        S_set_error( "electronic firing not enabled by PD_Prepare_electronic_firing \n", 5 );
        return 0;
    }

    if ( $ABgeneration < 12 )
    {
        S_w2log( 5, "*** Activate electrical firing\n" );
        $stat = pd_WriteName( 'V_ActivationPattern_U32R', [ 0x5A, 0x5A, 0x5A, 0x5A ] );
        check_status($stat);

        S_w2log( 5, "*** Reset firing\n" );
        $stat = pd_WriteName( 'V_SQFPSLockStatus_U32R', [ 0, 0, 0, 0 ] );
        check_status($stat);
    }
    else
    {
        S_w2log( 5, "PD_Trigger_electronic_firing: For AB12 sending request '02 19 1B' to PD\n" );

        my $response_aref;
        ( $stat, $response_aref ) = pd_EleFrgFireAllDevices();

        my $response_string = S_aref2hex($response_aref);

        # cut off leading '0x'
        $response_string = substr( $response_string, 2 );

        # add a whitespace every 2 hex-digits
        $response_string =~ s/([0-9A-F]{2})/$1 /g;

        # check for positive response (59 ...)
        unless ( $$response_aref[1] == 89 )
        {
            S_set_error( "PD_Trigger_electronic_firing: not successful. Response from ECU is $response_string", 5 );
            return 0;
        }

        S_w2log( 3, "PD_Trigger_electronic_firing: response from ECU is $response_string\n" );
        S_w2log( 4, "PD_Trigger_electronic_firing: success - Fired All devices\n" );

        # extract information from response: response starts with block title (byte 2 in SRS for PD)
        my $info_href;
        my $byteOffset = 1;
        S_w2log( 3, "PD_Trigger_electronic_firing: start data output ...\n" );

        # overall status (byte 3)
        $info_href->{'overallStatus'} = $response_aref->[ 3 - $byteOffset ];
        if ( $info_href->{'overallStatus'} == 0 )
        {
            S_w2log( 3, "Overall status byte = 0: Not all devices fired\n" );
        }
        elsif ( $info_href->{'overallStatus'} == 1 )
        {
            S_w2log( 3, "Overall status byte = 1: All devices fired\n" );
        }
        else
        {
            S_w2log( 3, "Overall status byte = " . $info_href->{'overallStatus'} . ": Unknown Status\n" );
        }

        S_w2log( 4, "PD_Trigger_electronic_firing: ... end data output\n" );

    }

    $ELFenabled = 0;

    return 1;

}

=head1 Function Group 'smi7xy'

=head2 PD_SMI7xy_verification

I<B<Syntax : >>

     $response_aref = PD_SMI7xy_verification( $sMI7xy_config_href )

I<B<Arguments     : >>

     $sMI7xy_config_href = hash reference to the SMI7xy_config data. Example:

     my $sMI7xy_config_href = {
          'Sensor1_Rate' => 'HF_raw',
          'Sensor1_ACC1' => 'HF_raw',
          'Sensor1_ACC2' => 'HF_raw',
          'Sensor2_Rate' => 'HF_raw',
          'Sensor2_ACC1' => 'HF_raw',
          'Sensor2_ACC2' => 'HF_raw',
          'Sensor3_Rate' => 'HF_raw',
          'Sensor3_ACC1' => 'HF_raw',
          'Sensor3_ACC2' => 'HF_raw',
          'Sensor4_Rate' => 'HF_raw',
          'Sensor4_ACC1' => 'HF_raw',
          'Sensor4_ACC2' => 'HF_raw',
          'amount_samples' => 1000,
     };

     Hash keys must be the same as in the example. Values can be 'LF_raw', 'HF_raw', 'LF_processed' or 'HF_processed',
     except for key 'amount_samples' which must be a number.

I<B<Description :>>

Sends the AB12 service SMI7xy verification ($0DH) to the ECU. Returns a reference to the ECU response.

See SRS_PROD_ProductionDiagnosis ID SRS_PRD_297 for details.

Error return : []

offline return : []

B<Note:> Supported AB Generations:: B<only 12>

=cut

sub PD_SMI7xy_verification
{

    my @args = @_;
    return [] unless S_checkFunctionArguments( 'PD_SMI7xy_verification( $sMI7xy_config_href )', @args );

    my $sMI7xy_config_href = shift @args;

    S_w2log( 4, "PD_SMI7xy_verification start\n" );

    if ( $ABgeneration < 12 )
    {
        S_set_error( "Function is only applicable for AB12 or higher", 120 );
        return [];
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return [];
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return [];
    }

    unless ( defined $sMI7xy_config_href->{'amount_samples'} )
    {
        S_set_error( " key 'amount_samples' is not defined in SMI7xy_config_href ", 114 );
        return [];
    }

    my @requestBytes = ( 0, 0, 0, 0 );

    #my @blocks = ('SMI700/1', 'SMI700/2', 'SMI710/1', 'SMI710/2');
    my $sMI7xy_request_bytes_href = {
                                      'Sensor1_Rate' => { 'byte' => 0, 'bit' => 0 },
                                      'Sensor1_ACC1' => { 'byte' => 0, 'bit' => 2 },
                                      'Sensor1_ACC2' => { 'byte' => 0, 'bit' => 4 },
                                      'Sensor2_Rate' => { 'byte' => 1, 'bit' => 0 },
                                      'Sensor2_ACC1' => { 'byte' => 1, 'bit' => 2 },
                                      'Sensor2_ACC2' => { 'byte' => 1, 'bit' => 4 },
                                      'Sensor3_Rate' => { 'byte' => 2, 'bit' => 0 },
                                      'Sensor3_ACC1' => { 'byte' => 2, 'bit' => 2 },
                                      'Sensor3_ACC2' => { 'byte' => 2, 'bit' => 4 },
                                      'Sensor4_Rate' => { 'byte' => 3, 'bit' => 0 },
                                      'Sensor4_ACC1' => { 'byte' => 3, 'bit' => 2 },
                                      'Sensor4_ACC2' => { 'byte' => 3, 'bit' => 4 },
    };

    foreach my $sensor ( sort keys %{$sMI7xy_request_bytes_href} )
    {

        # check if correct keys are defined in $sMI7xy_config_href
        unless ( defined $sMI7xy_config_href->{$sensor} )
        {
            S_set_error( " key $sensor is not defined in SMI7xy_config_href ", 114 );
            return [];
        }

        my $freq;
        my $mode;

        # check if correct values are defined in $sMI7xy_config_href
        if ( $sMI7xy_config_href->{$sensor} =~ /(LF|HF)_(raw|processed)/i )
        {
            $freq = $1;
            $mode = $2;

            #S_w2log( 5, "PD_SMI7xy_verification: $sensor is configured as $sMI7xy_config_href->{$sensor}\n");
        }
        else
        {
            S_set_error( " value '" . $sMI7xy_config_href->{$sensor} . "' for key $sensor in SMI7xy_config_href is unknown (should be one of 'LF_raw', 'HF_raw', 'LF_processed' or 'HF_processed' ", 114 );
            return [];
        }

        # determine byte and bit to be set
        my $byte = $sMI7xy_request_bytes_href->{$sensor}{'byte'};
        my $bit  = $sMI7xy_request_bytes_href->{$sensor}{'bit'};

        # check if bits have to be set
        # $freq == HF: bit is set
        if ( $freq =~ /HF/i )
        {
            $requestBytes[$byte] |= 1 << $bit;
        }

        # $mode == processed: next bit is set
        if ( $mode =~ /processed/i )
        {
            $requestBytes[$byte] |= 1 << ( $bit + 1 );
        }

    }

    # get amount of sample and check if it is in the correct range
    my $no_of_samples = $sMI7xy_config_href->{'amount_samples'};
    if ( $no_of_samples < 1 or $no_of_samples >= 1 << 16 )
    {
        S_set_error( " value $no_of_samples for key 'amount_samples' is out of range in SMI7xy_config_href (must be >0 and <2^16)", 114 );
        return [];
    }

#    # create bytes from amount of samples and add them to the request bytes
#    my $amountBytes_aref = S_dec2aref( $no_of_samples, U16 );
#    push( @requestBytes, ${$amountBytes_aref}[0], ${$amountBytes_aref}[1] );
#
#    # add checksum to the request bytes
#    my $checksum = 0;
#    foreach my $byte (@requestBytes)
#    {
#        $checksum += $byte;
#    }
#    $checksum &= 255;
#    push( @requestBytes, $checksum );
#
#    # print request to report and send request to PD
#    my $requestString = S_aref2hex( \@requestBytes );
#    $requestString = substr( $requestString, 2 );    # cut off leading '0x'
#    $requestString =~ s/([0-9A-F]{2})/$1 /g;         # add a whitespace every 2 hex-digits
#    S_w2log( 5, "PD_SMI7xy_verification: sending the following request to PD: $requestString\n" );

    if ($main::opt_offline)
    {
        return [];
    }
    
    my ( $status , $response_aref,$response_length);
    ($status, $response_aref,$response_length) =  pd_SMI7verification(\@requestBytes,$no_of_samples);
    S_w2log( 3, "PD_SMI7xy_verification : response received : @$response_aref bytes\n" );
    
    check_status($status) || return []; # Return empty array in case of error
    
     # $response_length - should be 416 for 9E case
     #                  - should be 440 for B6 case
     # Verified with ARB3KOR
    if ( scalar@$response_aref < 416 ) # expected minimum length of positive response in PD SW 
    {
        S_set_error( "Too short response from ECU on SMI7xy verification request. Response length must be at least 416. Check actual response in the test log in the lines above.", 102 );
        return [];
    }
    
    ######## Modifications with respect to VDS_ExtractSMI7xyDataFromPD
    # $response_aref[0] - Gives length of no of bytes from Service 
    # value is B6(Dec 182) Modulo -> 182 + 256 = 438 Bytes or
    # value is 9E(Dec 158) Modulo -> 158 + 256 = 414 Bytes
    # cut off first and last byte for VDS_ExtractSMI7xyDataFromPD
    
    pop @$response_aref;
    shift @$response_aref;
    
    return $response_aref;

}

=head1 Function Group 'memory'

=head2 PD_block_idle_mode

    PD_block_idle_mode( );

block idle mode for next occurence

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_block_idle_mode
{
    my $address;

    S_w2log( 4, "PD_block_idle_mode\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_block_idle_mode' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    # if defined V_BlockIdleModeActive_U16R
    ( $stat, $address ) = pd_GetAddressByName('V_BlockIdleMode_U16E');
    if ( $stat >= 0 )
    {
        $stat = pd_WriteName( "V_BlockIdleMode_U16E", [ hex("0xB1"), hex("0x0C") ] );
        check_status($stat);
    }
    else
    {
        S_set_error( "V_BlockIdleMode_U16E not found", 109 );
    }

    # if defined V_PermIdleMode_U16E
    ( $stat, $address ) = pd_GetAddressByName('V_PermIdleMode_U16E');
    if ( $stat >= 0 )
    {
        $stat = pd_WriteName( "V_PermIdleMode_U16E", [ hex("0x1D"), hex("0x1E") ] );
        check_status($stat);
    }
    else
    {
        S_set_error( "V_PermIdleMode_U16E not found", 109 );
    }

    S_w2log( 4, "PD_block_idle_mode: Blocks Idle mode for next occurance\n" );

    return 1;
}

=head2 PD_ClearMemoryBits

    PD_ClearMemoryBits( $memory_name , $bit_descriptions_aref );

Clear Memory bits by using the variable name and Bit descriptions available in SAD file.

$memory_name = Name of the variable

Only Memory name B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16X')> is needed. Not the specific byte names B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16XI<.1>')>

$bit_descriptions_aref = Array reference of (comma seperated) Bit descriptions that needs to be "Cleared" .

Bit descriptions should be copied from SAD (.sad) file

Error return : 0

offline/success return :: 1

Ex:

    PD_ClearMemoryBits('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X',['Fault Quali Time','Suppress CAN Faults']);

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ClearMemoryBits
{

    my $memory_name           = shift;
    my $bit_descriptions_aref = shift;
	my $MaxBitWiseCount = 0;
    my ( @tempArray, $byteCount, $Description, $descFound );
    my $bitRepresentation = {};    #						 For DiagSym3
    							   #                         ByteNumbers    BitNumbers        BitDescriptions
                                   #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {16}     ->  "Description of Bit 16"
                                   #
                                   #                              {1}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {16}     ->  "Description of Bit 16"
                                   #							For other than DiagSym3
                                   #                         ByteNumbers    BitNumbers        BitDescriptions
                                   #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {7}     ->  "Description of Bit 7"
                                   #
                                   #                              {1}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {7}     ->  "Description of Bit 7"
                                   

    $byteCount = 0;

    unless ( defined($bit_descriptions_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_ClearMemoryBits( \$memory_name , \$bit_descriptions_aref )", 110 );
        return 0;
    }

    #check $bit_descriptions_aref for undef elements
    if ( S_check_array( $bit_descriptions_aref, "\$bit_descriptions_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    #check $bit_descriptions_aref contains atleast one element
    if ( scalar(@$bit_descriptions_aref) == 0 )
    {
        S_set_error( "\$bit_descriptions_aref does not contain any Bit descriptions", 114 );
        return 0;
    }

    if ( defined($memory_name) && $memory_name =~ /.*?\.\d$/ )
    {
        S_set_error( "Enter only Memory name . Specific byte number is not allowed (Eg. ONLY A_SampleCtrINTW_U8R(0), NOT A_SampleCtrINTW_U8R(0).1", 114 );
        return 0;
    }

    S_w2log( 4, "PD_ClearMemoryBits for memory name :: $memory_name \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    #check if memory name exists in SAD file & Get the Description
    ( $stat, $Description, $MaxBitWiseCount) = pd_GetSADItemDesc($memory_name);
    check_status($stat);
    if ( $stat < 0 )
    {
        return 0;
    }

    #split Bit descriptions and save it in the structure $bitRepresentation
    @tempArray = split( /,/, $Description );  
    foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
    {
        if ( defined( $tempArray[$bitIndex] ) && $stat == 1 )
        {
            $bitRepresentation->{$byteCount}->{$bitIndex} = $tempArray[$bitIndex];
        }
        else
        {
            $bitRepresentation->{$byteCount}->{$bitIndex} = "";
        }
    }
    $bitRepresentation->{$byteCount}->{'value'} = 255;

    $byteCount++;

    #check the memory name in SAD file, whether it consists of next, next bytes  ("$memory_name.1" , "$memory_name.2" etc...)
    while ( $stat >= 0 )
    {
        #check for next bytes of $memory_name, till it does not found in SAD file
        #and calculate 'number of bytes' of variable
        ( $stat, $Description, $MaxBitWiseCount) = pd_GetSADItemDesc( $memory_name . "\.$byteCount" );
        if ( $stat >= 0 )
        {
            @tempArray = split( /,/, $Description );
            foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
            {
                if ( defined( $tempArray[$bitIndex] ) && $stat == 1 )
                {
                    $bitRepresentation->{$byteCount}->{$bitIndex} = $tempArray[$bitIndex];
                }
                else
                {
                    $bitRepresentation->{$byteCount}->{$bitIndex} = "";
                }
            }
            $bitRepresentation->{$byteCount}->{'value'} = 255;
            $byteCount++;
        }
    }

    #check for the given Bit descriptions from User and calculate the appropriate byte value
    #report error, if any bit description is not found in Variable bit descriptions
    foreach my $bitdesc (@$bit_descriptions_aref)
    {
        $descFound = 0;
        for ( my $byteindex = 0 ; $byteindex < $byteCount ; $byteindex++ )
        {
            foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
            {
                if ( $bitRepresentation->{$byteindex}->{$bitIndex} eq $bitdesc )
                {
                    $bitRepresentation->{$byteindex}->{'value'} &= ~( 1 << $bitIndex );    #shift 1 till the correct position, then negate, then AND
                    $descFound++;
                }
            }
        }

        unless ($descFound)
        {
            S_set_error( "Bit description '$bitdesc' is not found in variable '$memory_name'", 109 );
            return 0;
        }
    }

    my @writeArray = ();
    my $readArray;

    #Read the corresponding memory and get values that are already existing
    ( $stat, $readArray ) = pd_ReadName($memory_name);
    check_status($stat);

    #cumulate the "values to be written" in one single array
    push( @writeArray, $bitRepresentation->{$_}->{'value'} & $$readArray[$_] ) foreach ( 0 .. ( $byteCount - 1 ) );
    $stat = pd_WriteName( "$memory_name", \@writeArray );
    check_status($stat);

    if ( $stat >= 0 )
    {
        S_w2log( 4, "PD_ClearMemoryBits ($stat) : value of '$memory_name' is cleared for Bits '" . join( ", ", @$bit_descriptions_aref ) . "' \n" );
    }

    return 1;
}

=head2 PD_DumpEEPROM

     PD_DumpEEPROM( $hexfile );

dump EEPROM to hex file (*.hex).

     PD_DumpEEPROM header (readable by Windiag )
     !!SW Stand: EL0110_BB01008_D01_CAT2_20100811 BOSCH AB10.0
     !! ecu: 0285010000
     !! timedate: 16:38:42  2010/09/06 !! PD_control : 1.0.2.4
     !! user: SI-Z8643 bm7zsi

Error return : 0

offline/success return :: 1

Note : Currently, Sad file is not updated with proper address as per info on 22.01.2015.

       Need to edit manually the sad file with proper address and run PD_DumpEEPROM

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_DumpEEPROM
{
    my $file = shift;

    unless ( defined($file) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_DumpEEPROM( hexfile )", 110 );
        return 0;
    }
    if ( length($file) > $max_pathlength )
    {
        S_set_error( " filename <$file> size > $max_pathlength", 114 );
        return 0;
    }
    unless ( $file =~ /\.hex$/ )
    {
        S_set_error( " $file is not a hexfile (*.hex)", 114 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($file);
        S_w2log( 4, "PD_DumpEEPROM: Offline dummy file $file is created \n" );
        return 1;
    }
    $stat = pd_GetEEPROMDump($file);
    check_status($stat);
    S_w2log( 5, "Status of pd_GetEEPROMDump :: $stat \n" );

    S_w2log( 4, "PD_DumpEEPROM: Dumped to $file\n" );
    return 1;
}

=head2 PD_DumpFLASH

     PD_DumpFLASH( $hexfile );

Dumps the Flash memory content to HEX file.

dump Flash to hex file (*.hex)

     PD_DumpFLASH header
     !!SW Stand: EL0110_BB01008_D01_CAT2_20100811 BOSCH AB12.0
     !! ecu: 0285010000
     !! timedate: 16:38:42  2010/09/06 !! PD_control : 1.0.2.4
     !! user: SI-Z8643 bm7zsi

Error return : 0

offline/success return :: 1

Note : Currently, Sad file is not updated with proper address as per info on 22.01.2015.

       Need to edit manually the sad file with proper address and run PD_DumpFLASH

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_DumpFLASH
{
    my $file = shift;

    unless ( defined($file) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_DumpFLASH( hexfile )", 110 );
        return 0;
    }
    if ( length($file) > $max_pathlength )
    {
        S_set_error( " filename <$file> size > $max_pathlength", 114 );
        return 0;
    }
    unless ( $file =~ /\.hex$/ )
    {
        S_set_error( " $file is not a hexfile (*.hex)", 114 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($file);
        S_w2log( 4, "PD_DumpFLASH: Offline dummy file $file is created \n" );
        return 1;
    }
    $stat = pd_GetFLASHDump($file);
    check_status($stat);
    S_w2log( 5, "Status of pd_GetFLASHDump :: $stat \n" );

    S_w2log( 4, "PD_DumpFLASH: Dumped to $file\n" );

    return 1;
}

=head2 PD_DumpRAM

     PD_DumpRAM( $hexfile );

dump RAM to hex file (*.hex)

     PD_DumpRAM header
     !!SW Stand: EL0110_BB01008_D01_CAT2_20100811 BOSCH AB10.0
     !! ecu: 0285010000
     !! timedate: 16:38:42  2010/09/06 !! PD_control : 1.0.2.4
     !! user: SI-Z8643 bm7zsi

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_DumpRAM
{
    my $file = shift;

    unless ( defined($file) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_DumpRAM( hexfile )", 110 );
        return 0;
    }
    if ( length($file) > $max_pathlength )
    {
        S_set_error( " filename <$file> size > $max_pathlength", 114 );
        return 0;
    }
    unless ( $file =~ /\.hex$/ )
    {
        S_set_error( " $file is not a hexfile (*.hex)", 114 );
        return 0;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_create_dummy_file($file);
        S_w2log( 4, "PD_DumpRAM: Offline dummy file $file is created \n" );
        return 1;
    }
    $stat = pd_GetRAMDump($file);
    check_status($stat);
    S_w2log( 5, "Status of pd_GetRAMDump :: $stat \n" );

    S_w2log( 4, "PD_DumpRAM: Dumped to $file\n" );

    return 1;
}

=head2 process_NVM

	 process_NVM() is not exported
	 Opens NVM file and store the information in a hash data structure in variables $nvmData_href and $nvmFile_readflag.
		Structure => $nvmData_href=> {
			'0'		=>{
				section name =>	
				section ID	 =>
				section BlockLength =>
			}
			'1'		=>{
				section name =>	
				section ID	 =>
				section BlockLength =>			
			}
			.
			.
			.	
		}
		
Error return : '0' when .nvm file does not exist

success return :: =>	'1' when data is sucessfuly filled in function call
						
=cut

sub process_NVM
{
	if ( $nvmFile_readflag == 1 ) {
		S_w2log( 5,"process_NVM : Data is already filled into global hash => nvmData_href... \n");
		return 1;
	}
	my $NVMfile = $LIFT_config::SAD_file;
	my $response_aref;
	$NVMfile =~ s/\.sad$/.nvm/i;
	my $NVM_FileHandle;

	unless ( open( $NVM_FileHandle, "<$NVMfile" ) ) {
		S_set_error( " could not open $NVMfile for reading: $@", 1 );
		return 0;
	}
	my @NVM_SectionDetails;
	my $NVMdataCounter = 0;
	S_w2log( 5," process_NVM : Processing NVM file. .. \n");
	while ( my $line = <$NVM_FileHandle> ) {					# Loop to process nvm-file line by line
		chomp $line;
		next if ( $line =~ /^NULL_PTR/ );

		@NVM_SectionDetails = split( /,/, $line );

		if ( defined $NVM_SectionDetails[2]	&& $NVM_SectionDetails[2] =~ /^\d+$/ )               # Checking if NVM block length is a valid numeric value
		{
			$$nvmData_href{ $NVMdataCounter }{ "section name" } = $NVM_SectionDetails[0];        # NVM section name
			$$nvmData_href{ $NVMdataCounter }{ "section ID" } = $NVM_SectionDetails[1];          # NVM section ID
			$$nvmData_href{ $NVMdataCounter }{ "section BlockLength" } = $NVM_SectionDetails[2]; # NVM section BlockLength
			$NVMdataCounter++;
		}
	}
	close($NVM_FileHandle);
	$nvmFile_readflag = 1;

	return 1;
}

=head2 PD_DumpNVMData

     PD_DumpNVMData([$filename]); 
	 $filename => Optional parameter 
	 			  Complete file path and file name with extension(.txt) should be mentioned
    This funciton is used to dump of all NVM sections.
    
    Example:
	$status = PD_DumpNVMData(cwd().'/Dump_data.txt');
	$status = PD_DumpNVMData($main::REPORT_PATH .'/'.$i."_ReadAllNVMSections_Dump.txt");
	Dumped NVMData can be found at the path mentioned by the user.
	
	$status = PD_DumpNVMData();
	If no parameter is given, by default, file("ReadAllNVMSections_Dump.txt") will get stored inside reports folder
		
	File will contain data of all NVM sections and the changes should not be directly made to Dump file.

Error return : '0' 

offline/success return :: 1

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_DumpNVMData {
	unless ($PD_initialized) {
		S_set_error( "PD not initialized", 120 );
		return 0;
	}

	#set error if FastDiagnostics is already active
	if ($FastDiagActive) {
		S_set_error( "Fast Diagnostics is Active", 121 );
		return 0;
	}
	process_NVM(); # Read NVM file, Obtained the details of all the NVM Section in a hash ref ($$nvmData_href)

	my $dumpfile = shift; 
	unless (defined($dumpfile))
	{
		$dumpfile = $main::REPORT_PATH .'/'.S_get_date_extension()."_ReadAllNVMSections_Dump.txt";		
	}
	unless ( $dumpfile =~ /\.txt$/i ) {
		S_set_error( " $dumpfile is not a textfile (*.txt)", 114 );
		return 0;
	}
	
	if ( -e $dumpfile ) {
        S_set_error( "Warning : Dump File : $dumpfile already exists, may replace the already existing file", 1 );
        return 0;
    }
	if ($main::opt_offline) {
		S_w2log( 4, "PD_DumpNVMData : Cannot read NVM Data in Offline mode \n" );
		return 1;
	}
	
	my $sections_read = 0;
	my $response_aref;
	my $block_length;
	my $section_id;
	
	
	my $Dump_FileHandle;
	unless ( open( $Dump_FileHandle, ">$dumpfile" ) ) {
		S_set_error( "could not write ReadAllNVMSections_Dump.txt", 1 );
		return 0;
	}
	else {
		#Filling the header part of Dumpfile
		print $Dump_FileHandle "!! NVM Dump data - Generated from TurboLIFT \n";
		print $Dump_FileHandle "!! SW Version :: ". $ECU_SWInfo{'SW Version'}. ",Date and Time :: ". S_get_date_extension() . "\n\n";

	}
	S_w2rep("Dump file :  $dumpfile\n");
	S_w2log( 5, "PD_DumpNVMData : Reading the NVM sections... \n" );
	foreach my $NVMcount ( sort { $a <=> $b } keys %{$nvmData_href} ) {
		$block_length = $$nvmData_href{$NVMcount}{"section BlockLength"};
		$section_id = $$nvmData_href{$NVMcount}{"section ID"};
		( $stat, $response_aref ) = pd_ReadNVMSection($block_length,$section_id);
		if ($stat != -922){
			 check_status($stat);
		}
		if ( $stat == 0 ) {
			$sections_read++;
			print $Dump_FileHandle "!NVM_Section_Name:". $$nvmData_href{$NVMcount}{"section name"};
			print $Dump_FileHandle ",NVM_Block_ID:". $$nvmData_href{$NVMcount}{"section ID"};
			print $Dump_FileHandle ",Block_Length:". $$nvmData_href{$NVMcount}{"section BlockLength"}."\n:";

			foreach my $index (0..(scalar(@$response_aref)-1)) {
				if ( $index % 8 == 0 and $index > 7 ) {
					print $Dump_FileHandle "\n:";
				}
				printf $Dump_FileHandle ( uc "%02x,",$response_aref->[$index] );
			}
			print $Dump_FileHandle "\n\n";
		}
		else {
			print $Dump_FileHandle "!!NVM_Section_Name:". $$nvmData_href{$NVMcount}{"section name"};
			print $Dump_FileHandle ",NVM_Block_ID:". $$nvmData_href{$NVMcount}{"section ID"};
			print $Dump_FileHandle ",Block_Length:". $$nvmData_href{$NVMcount}{"section BlockLength"}."\n:";
			print $Dump_FileHandle "Unable to read section, status : $stat \n\n";
			S_w2log( 5,"PD_DumpNVMData : Unable to read section : ". $$nvmData_href{$NVMcount}{"section name"}. ", status : $stat \n" );
		}
	}

	close($Dump_FileHandle);
	S_w2log( 5,"PD_DumpNVMData : No of read sections $sections_read , Find dump data in Reports folder \n");
	return 1;
}

=head2 PD_ReadNVMSection

	This function is used to read particular NVM section individually 
    PD_ReadNVMSection($SectionName); => Mandatory Parameter
	$SectionName => Label of NVM section to be read.
	 
	Examples:
	 
    $resp_aref => PD_ReadNVMSection("rb_tim_EcuOnTimeDataEe_st");	# will give [74,00,00,00,6F,40,4A,00] as response.
    $resp_aref => Array response of NVM section data

offline/Error return : [] 

success return :: NVMsection data

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_ReadNVMSection {
	
	my $response_aref;
	my $section_foundflag = 0;
	my $NVMcount;
	my $SectionName = shift;
	unless ( defined($SectionName) ) {
		S_set_error("! too less parameters ! SYNTAX: PD_ReadNVMSection( SectionName )",110);
		return 0;
	}

	unless ($PD_initialized) {
		S_set_error( "PD not initialized", 120 );
		return 0;
	}

	#set error if FastDiagnostics is already active
	if ($FastDiagActive) {
		S_set_error( "Fast Diagnostics is Active", 121 );
		return 0;
	}
	process_NVM(); # Read NVM file, Obtained the details of all the NVM Section in a hash ref ($nvmData_href)

	if ($main::opt_offline) {
		S_w2log( 4,	"PD_ReadNVMSection : Cannot read NVM Data in Offline mode \n" );
		$response_aref = [];    # Returning Dummy Array in offline mode
		return $response_aref;
	}
  #Searching through global hash reference for the section name requested
	foreach my $NVMcount ( keys %$nvmData_href ) {
		if ( $$nvmData_href{$NVMcount}{"section name"} eq $SectionName ) {
		
			( $stat, $response_aref ) = pd_ReadNVMSection($$nvmData_href{$NVMcount}{"section BlockLength"},$$nvmData_href{$NVMcount}{"section ID"});
			
			$section_foundflag = 1; # If NVM section is found in global hash, setting the flag
			
			check_status($stat);

			if ( $stat == 0 ) {
				S_w2log( 4,	"PD_ReadNVMSection : Section found, obtained data \n" );
				foreach my $index ( 0..(scalar(@$response_aref)-1) ) {
					$response_aref->[$index] = uc sprintf( "%02x", $response_aref->[$index] );
				}
				return $response_aref;
			}
			else {
				S_w2log(4,"PD_ReadNVMSection : Section found, Unable to read section : $SectionName \n ");
				return [];
			}
		}
	}
	if ( $section_foundflag == 0 ) {
		S_set_error("PD_ReadNVMSection : requested section not found in NVM file! : $SectionName, Verify the input");
		return [];
	}
}

=head2 PD_WriteAllNVMSections

	Writes All the NVM sections with data as in NVM dump.
    PD_WriteAllNVMSections($NVMDump_filepath);
	$NVMDump_filepath => Path of NVM Dump file
	
	Examples:
	$status = PD_WriteAllNVMSections($main::REPORT_PATH . "/ReadAllNVMSections_Dump.txt");

Error return : '0' when dump file address is invalid or doesnt exist

offline/success return :: '1' when writing all NVM sections is sucessful

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_WriteAllNVMSections {
	my $DumpFile_address = shift;

	unless ($PD_initialized) {
		S_set_error( "PD not initialized", 120 );
		return 0;
	}

	#set error if FastDiagnostics is already active
	if ($FastDiagActive) {
		S_set_error( "Fast Diagnostics is Active", 121 );
		return 0;
	}

	if ($main::opt_offline) {
		S_w2log( 4,"PD_WriteAllNVMSections : Cannot Write NVM Data in Offline mode \n");
		return 1;
	}

	unless ( defined($DumpFile_address) ) {
		S_set_error("! too less parameters ! SYNTAX: PD_WriteAllNVMSections( dumpFile )",110);
		return 0;
	}
	unless ( $DumpFile_address =~ /\.txt$/i ) {
		S_set_error( " $DumpFile_address is not a textfile (*.txt)", 114 );
		return 0;
	}
	unless ( open( FILE, "<$DumpFile_address" ) ) {
		S_set_error( " could not open $DumpFile_address for reading: $@", 1 );
		return 0;
	}
	my $section_count=0;
	my @bytes_arr;
	my $NVM_BlockLength;
	my $NVM_BlockID;
	my $NVM_Section_name;
	S_w2log( 5,"PD_WriteAllNVMSections started this may take few minutes... \n" );
	while ( my $line = <FILE> ) {# Reading the NVM dump file in order to write the NVM section one by one
		next if ( ( $line =~ /^\s*$/ ) || ( $line =~ /^!{2,}/ ) );    # skip empty lines and the header part
		 #!NVM_Section_Name : $arr[0],NVM_Block_ID : $arr[1],Block_Length : $arr[2]
		if ( $line =~ /^!\w+:(\w+),\w+:(\d+),\w+:(\d+)*$/ ) {

			$NVM_Section_name = $1;
			$NVM_BlockID     = $2;
			$NVM_BlockLength = $3;
		}
		if ( $line =~ /^:(.*),\s*$/ ) {# Reads the valid data values from the indvidual sections
			my $data = $1;
			push( @bytes_arr, split( /,/, $data ) );
		}

		if ( $NVM_BlockLength == @bytes_arr ) {
			foreach my $count ( 0..(@bytes_arr-1) ) {
				$bytes_arr[$count] = S_0x2dec( "0x" . $bytes_arr[$count] );
			}
			$stat = pd_WriteNVMSection( $NVM_BlockLength, $NVM_BlockID, \@bytes_arr );
			
			if($stat==0)
			{
				$section_count++;
			}
			else
			{
				S_w2log( 5,"PD_WriteAllNVMSections : Unable to write section : $NVM_Section_name , Status : $stat \n" );
			}
			@bytes_arr = ();    #Clearing array values
		}

	}

	# to get the count of sections that has been written sucessfuly
	if ( $stat == 0 ) {
		S_w2log( 5,"PD_WriteAllNVMSections completed for $section_count sections \n" );
	}

	return 1;
}

=head2 PD_WriteNVMSection

	Writes particular NVM section with corresponding data array passed.
	
    PD_WriteNVMSection($SectionName,$response_aref); =>Mandatory Parameter
    
    $SectionName   => NVM section label
    $response_aref => array reference of the modified data.
     
    Example:
	$resp_aref = PD_ReadNVMSection(rb_tim_EcuOnTimeDataEe_st); will give [74,00,00,00,6F,40,4A,00]
	$resp_aref[0] = 00; # Modify values
	$resp_aref[1] = 0A;
	$status = PD_WriteNVMSection(rb_tim_EcuOnTimeDataEe_st,$resp_aref);
	
Error return : '0' when length of input array passed is does not match with input NVM section's block length 

offline/success return :: '1' when writing particular NVM section completed

B<Note:> Supported AB Generations:: B<12>

=cut

sub PD_WriteNVMSection {
	
	my @args = @_;
	return {} unless S_checkFunctionArguments( 'PD_WriteNVMSection( $SectionName, $response_aref)', @args );

	my $SectionName   = shift;
	my $response_aref = shift;
	my $found_flag    = 0;
	
	unless ($PD_initialized) {
		S_set_error( "PD not initialized", 120 );
		return 0;
	}

	#set error if FastDiagnostics is already active
	if ($FastDiagActive) {
		S_set_error( "Fast Diagnostics is Active", 121 );
		return 0;
	}

	if ($main::opt_offline) {
		S_w2log( 4,"PD_WriteAllNVMSections : Cannot Write NVM Data in Offline mode \n");
		return 1;
	}

	
	process_NVM();
	my $count;

	
	my $NVMcount;
	my $NVMkeyNo;
	foreach $NVMcount ( keys %$nvmData_href ) {# searches for given input nvm section name whether it exists in global hash ref
		if (   $$nvmData_href{$NVMcount}{"section name"} eq $SectionName && $$nvmData_href{$NVMcount}{"section BlockLength"} == @$response_aref )
		{
			$found_flag = 1;
			$NVMkeyNo   = $NVMcount;
			last;
		}
	}
	if ( $found_flag == 1 ) {
		foreach $count ( 0..scalar(@$response_aref)-1) {
		@$response_aref[$count] = S_0x2dec( "0x". @$response_aref[$count] );
	}
		($stat) = pd_WriteNVMSection($$nvmData_href{$NVMkeyNo}{"section BlockLength"},$$nvmData_href{$NVMkeyNo}{"section ID"},$response_aref);
		check_status($stat);
	}
	else {
		S_set_error("Section name or the length Data block does not match ");
		return 0
	}
	return 1;
}


=head2 PD_EraseEEPROM

     PD_EraseEEPROM();

erase EEPROM (overwrite with FF)

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_EraseEEPROM
{

    S_w2log( 4, "PD_EraseEEPROM\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_EraseEEPROM' is not support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = pd_EraseEEPROM();
    check_status($stat);
    S_w2log( 3, "PD_EraseEEPROM status : $stat\n" );

    return 1;
}

=head2 PD_get_last_index

     $index = PD_get_last_index( $label );

     e.g.
     11 = PD_get_last_index( 'S_SWMSet_XXC.A_Cfg_XSX' );
      9 = PD_get_last_index( 'A_EEMgrJobTable_XSR' );
      3 = PD_get_last_index( 'A_EEMgrJobTable_XSR(0).A_EEData_U8X' );

returns last index of label from SAD file, label is without last bracket.

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_get_last_index
{
    my $label = shift;

    unless ( defined $label )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_get_last_index( label )", 110 );
        return 0;
    }

    S_w2log( 4, "PD_get_last_index ($label) \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_get_last_index' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    return 1 if $main::opt_offline;

    unless ( defined $last_index{$label} )
    {
        S_set_error( " unknown label $label", 114 );
        return 0;
    }

    S_w2log( 4, "PD_get_last_index:Last index of label '$label' is '$last_index{$label}' \n" );

    return $last_index{$label};
}

=head2 PD_get_type_from_name

    $type = PD_get_type_from_name( $label );

Returns data type of label extracted from label. (type = U or S or u or s followed by 1 or 2 digits).
Function return error, in case of if the label does not follows as [U or S or u or s followed by 1 or 2 digits].

B<Arguments:>

=over

=item $label

It is the label of which data type has to be extracted.

=back

B<Return Value:>

=over

=item $type 

Success      : Type of label

Error        : 0

=back

B<Examples AB12:>

     S16 = PD_get_type_from_name( 'A_AccEcuChannel_S16R(2)' );
     U8  = PD_get_type_from_name( 'A_EEMgrJobTable_XSR(0).A_EEData_U8X' );
     S8  = PD_get_type_from_name( 'A_RgBBuf_XSR(0).A_RgBAcc_XSX(0).V_CSX_S8X' );
     0   = PD_get_type_from_name( 'A_Edr_XSE(0).S_Fc_XXX.A_FclEventType_XEX(0)' ); # error
     0   = PD_get_type_from_name( 'A_ImpactInfoINTW_XSR(0).E_ImpactEnd_XXX' ); # error
    
B<Notes>:

Supported AB Generations:: B<10 and 12>

=cut

sub PD_get_type_from_name
{
    my $label = shift;
    my $type;

    unless ( defined $label )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_get_type_from_name( \$label )", 110 );
        return 0;
    }

    my @matches = $label =~ m/([us]\d\d?)/ig; # collect all matches of u or s followed by 1 or 2 digits 
    $type = pop @matches; # use the last match (that which is rightmost in the string)

    unless ($type)
    {
        S_set_error( " unknown type in $label", 114 );
        return 0;
    }

    S_w2log( 4, "PD_get_type_from_name: Name '$label' type is '$type' \n" );

    return $type;
}

=head2 PD_GetAddressByName

     $Address = PD_GetAddressByName( $name );

     e.g. 0x8005FD8 = PD_GetAddressByName( 'V_IdleFaultNbr_U16R' );

get Address from SAD symbol name

offline + Error return = 0x1

Success return :: Address of variable

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetAddressByName
{
    my $name = shift;
    my ($address);

    unless ( defined($name) )
    {
        S_set_error( "! too less parameters ! SYNTAX: Address = PD_GetAddressByName( name )", 110 );
        return '0x1';
    }

    S_w2log( 4, "PD_GetAddressByName($name)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return '0x1';
    }

    return '0x1' if $main::opt_offline;

    ( $stat, $address ) = pd_GetAddressByName($name);
    $address = sprintf( "0x%X", $address );
    check_status($stat);
    if ( $stat >= 0 )
    {
        S_w2log( 4, "PD_GetAddressByName: ($name) returned $address\n" );
        return $address;
    }
    else
    {
        S_w2log( 4, "PD_GetAddressByName: unable to retrieve address of name ($name). Returned  0x1 \n" );
        return '0x1';
    }
}

=head2 PD_GetNameByAddress

     $name = PD_GetNameByAddress( $address );

     e.g. 'V_IdleFaultNbr_U16R' = PD_GetNameByAddress( 0x8005FD8 );

get SAD symbol name from Address, will return 'unknown' on error

offline + Error return = ''

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_GetNameByAddress
{
    my $address = shift;
    my ($name);

    unless ( defined($address) )
    {
        S_set_error( "! too less parameters ! SYNTAX: name = PD_GetNameByAddress( address )", 110 );
        return '';
    }
    S_w2log( 4, "PD_GetNameByAddress($address)\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return '';
    }

    return 'dummy' if $main::opt_offline;

    ( $stat, $name ) = pd_GetNameByAddress($address);
    if ( $stat >= 0 )
    {
        S_w2log( 4, "PD_GetNameByAddress($address) returned $name\n" );
        return $name;
    }
    else
    {
        S_w2log( 4, "PD_GetNameByAddress($address) : NO name for given address\n" );
        return 'unknown';
    }
}

=head2 PD_InitEEPROM

     PD_InitEEPROM( $hexfile [, 'reset']);

Initialize EEPROM with given hex file. If reset keyword given, SW reset will be triggered afterwards.

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_InitEEPROM
{
    my $file  = shift;
    my $reset = shift;

    unless ( defined($file) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_InitEEPROM( hexfile [, 'reset'] )", 110 );
        return 0;
    }
    if ( length($file) > $max_pathlength )
    {
        S_set_error( " filename <$file> size > $max_pathlength", 114 );
        return 0;
    }
    unless ( -f $file )
    {
        S_set_error( "hexfile not found", 1 );
        return 0;
    }
    $reset = '' unless ( defined $reset );

    S_w2log( 4, "PD_InitEEPROM with $file $reset: Initialize the EEPROM\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_InitEEPROM' is not support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;
    $stat = pd_InitEEPROM($file);
    check_status($stat);

    PD_ECUreset() if ( lc($reset) =~ /^reset$/ );

    S_w2log( 4, "PD_InitEEPROM: Initialized the EEPROM with hex file $file\n" );
    return 1;
}

=head2 PD_Read_PowerOnTime

    dec_value = PD_Read_PowerOnTime( );

Read power on time, ECU operating time (since production) in seconds
4byte time data in seconds is returned

Error return : 0

Offline return : 1

Sucess return : Operation time in seconds (decimal value)

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_Read_PowerOnTime
{
    my ( $address, $value_aref );

    S_w2log( 4, "PD_Read_PowerOnTime\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_Read_PowerOnTime' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    return 1 if $main::opt_offline;

    # if defined V_PoOnTime_U32R
    ( $stat, $address ) = pd_GetAddressByName('V_PoOnTime_U32R');

    if ( $stat >= 0 )
    {
        S_w2log( 5, "PD_Read_PowerOnTime: read V_PoOnTime_U32R\n" );
        ( $stat, $value_aref ) = pd_ReadName("V_PoOnTime_U32R");
        check_status($stat);
        S_w2log( 5, "-> pd_ReadName for label V_PoOnTime_U32R status : $stat\n" );
    }
    else
    {
        S_set_error( "V_PoOnTime_U32R not found", 109 );
        return 0;
    }

    my $dec_value = S_aref2dec( $value_aref, 'U32' );
    S_w2log( 4, "PD_Read_PowerOnTime - $dec_value \n" );

    # return the entire contents as single value

    return ($dec_value);
}

=head2 PD_ReadLampStates

    $value_aref = PD_ReadLampStates();

To Read Lamp states of Analog outputs as well as system warning lamps.

AB10 => reads lamp states from A_LampLogicalStatus_SER, returns reference to hash containing lamp states (Both Analog and System W/L).

AB12 =>	Warning Lamps from any of 3 variables : rb_wimi_SysWIStatus_aen,rb_wim_CustSysWIStatus_aen or rb_wima_SysWIStatus_en

Analog Output						  : rb_syco_AOutPresence_ab8 		

B<Arguments:> No Arguments

B<Return Value:> Reference to hash containing lamp states (Both Analog and System W/L)

B<AB10:>

          $value_aref = {
             "BAOnA"                        => "Lamp Off",
             "BAOffA"                       => "Lamp On",
             "BADisplay"                    => "Lamp Off",
             "SysWL"                        => "Lamp On",
          };

B<AB12:>

          $value_aref = {
             "AOutPassAirbagOnIndicator"            => "Off",
             "System Warning Lamp"                  => "On",
             "AOutCrashOutput1"                     => "Off",
             "AOutPassAirbagOffIndicator"           => "Off",
             "AOutSysWarningIndicator"              => "Off"
          };

offline + Error return : {}

B<Notes:> Supported AB Generations:: B<10 and 12> 

=cut

sub PD_ReadLampStates {
    my %states;
    my $dummy_return = {};
    my $value_aref;
    my $wl_AB12_flag = 0;

    #Variables to get the status of system Warning Lamps in case of AB12
    my @warning_lamp_var = ( "rb_wimi_SysWIStatus_aen(0)", "rb_wim_CustSysWIStatus_aen(0)", "rb_wima_SysWIStatus_en", "rb_wimi_SysWIStatus_en" );
    # Added rb_wimi_SysWIStatus_en - Variable for warning lamps in BEG and JLR projects
    S_w2log( 4, "PD_ReadLampStates\n" );

    unless ($PD_initialized) {
        S_set_error( "PD not initialized", 120 );
        return $dummy_return;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive) {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $dummy_return;
    }

    return $dummy_return if $main::opt_offline;

    my $lampnr = 0;

    #   $lampstates contains the values ON, Off,Invalid Data . . etc these values are filled from CNS file incase of AB12 and incase of AB10 from SAD file
    if ( $ABgeneration < 12 ) {
        foreach (@lamps) {
            ( $stat, $value_aref ) = pd_ReadName("A_LampLogicalStatus_SER($lampnr)");
            check_status($stat);
            my $state     = S_0x2dec( $$value_aref[0] );     # to get the lamp state as state Text
            my $statetext = $lampstates[$lampnr][$state];    # filling hash with lamp name and lamp states
            $states{ $lamps[$lampnr] } = $statetext;
            S_w2log( 5, "PD_ReadLampStates: $lamps[$lampnr] - $statetext \n" );

            $lampnr++;
        }
    }
    else {
        # For Warning Lamps
        foreach (@warning_lamp_var) {
            ( $stat, $value_aref ) = pd_ReadName($_);
            if ( $stat > 0 ) {
                $wl_AB12_flag = 1;
                $states{"System Warning Lamp"} = $lampstates[ $$value_aref[0] ][0];    # System warning lamps are added seperately to the return state Hash
                S_w2log( 5, "PD_ReadLampStates: System Warning Lamp - $lampstates[$$value_aref[0]][0]  \n" );
                last;
            }

        }
        if ( $wl_AB12_flag == 0 )    # Incase the warning lamp status is not updated from all 3 variables
        {
            S_set_warning("PD_ReadLampStates: System Warning Lamp status not updated from predefined variables" );
        }

        # For Analog Outputs
        ( $stat, $value_aref ) = pd_ReadName('rb_syco_AOutPresence_ab8(0)');    # Variable to know the presence of analog lamps
        check_status($stat);
        my $state = S_0x2dec( $$value_aref[0] );                                # first index contains status of Presence of Analog outputs no of lamps that exists.
        $state = S_dec2bin($state);

        $state = substr $state, -scalar(@lamps);                                # extracting only the Lamp status bits from the whole byte

        my @analog_lamp_bits = split( undef, $state );                          # splitting to access the individual status bits

        for my $index ( 0 .. $#lamps ) {                                        #   $#lamps similar to scalar(@array), but gives highest index of array
            $lampnr = $analog_lamp_bits[ $#lamps - $index ];
            my $statetext = $lampstates[$lampnr][0];                            # Obtaining state text
            $states{ $lamps[$index] } = $statetext;                             #   Assigning lamp status to corresponding lamp
        }
    }

    # get additional infos from V_LampReq_U32R ?
    return ( \%states );

}


=head2 PD_ReadMemoryBit

    $membitval = PD_ReadMemoryBit( $memory_name, $bit_description);

Reads the Memory bit status by using the Variable name(available in SAD file) and Bit description.

B<Arguments:>

=over

=item $memory_name 

Name of the variable

If the Bit description is a Bit comment(present in SAD/CNS file) only Memory name B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16X')> is needed and Not the specific byte names B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16XI<.1>')>.

Otherwise If the Bit description is a Bit index then the respective memory name(which could be a specific byte name also) should be passed as an argument.

=item $bit_description 

Bit description can be the Bitcomment present in the SAD/CNS file or a Bit index at which the Bit value has to be read.

=back

B<Return Value:>

=over

=item $membitval 

Error return : undef

offline return : 1

Success return : Returns the bit status of a variable(0/1).

=back

B<Examples:>

     If the Bit description is a Bit comment
        PD_ReadMemoryBit('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X','Fault Quali Time');
     If the Bit description is a Bit index
        PD_ReadMemoryBit('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X','2'); 
        PD_ReadMemoryBit('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X.1','2');          
     
B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_ReadMemoryBit {

	my @args = @_;
	return unless S_checkFunctionArguments( 'PD_ReadMemoryBit($memory_name, $bit_description)', @args );

	my $memory_name     = shift @args;
	my $bit_description = shift @args;    #Bit description can be a Bit comment or a Bit index
	my $maxBitWiseCount = 0;              #maximum no of bit comment allowed
	my ( @bitComments_arr, $byteCount, $bitvalue, $description, $bitCommentFound, %bitDescriptionHash );
    my $bitRepresentation = {};           #	            	     For DiagSym3
	                                      #                         ByteNumbers    BitNumbers        BitDescriptions
	                                      #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
	                                      #                                      ->   {1}     ->  "Description of Bit 1"
	                                      #                                      ->    .                    .
	                                      #                                      ->    .                    .
	                                      #                                      ->   {15}     ->  "Description of Bit 15"
	                                      #
	                                      #                              {1}     ->   {0}     ->  "Description of Bit 0"
	                                      #                                      ->   {1}     ->  "Description of Bit 1"
	                                      #                                      ->    .                    .
	                                      #                                      ->    .                    .
	                                      #                                      ->   {15}     ->  "Description of Bit 15"
	                                      #							For other than DiagSym3
	                                      #                         ByteNumbers    BitNumbers        BitDescriptions
	                                      #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
	                                      #                                      ->   {1}     ->  "Description of Bit 1"
	                                      #                                      ->    .                    .
	                                      #                                      ->    .                    .
	                                      #                                      ->   {7}     ->  "Description of Bit 7"
	                                      #
	                                      #                              {1}     ->   {0}     ->  "Description of Bit 0"
	                                      #                                      ->   {1}     ->  "Description of Bit 1"
	                                      #                                      ->    .                    .
	                                      #                                      ->    .                    .
	                                      #                                      ->   {7}     ->  "Description of Bit 7"
	$byteCount = 0;
	$bitCommentFound = 0;

	if ( $bit_description eq "" || $memory_name eq "" ) {
		S_set_error( "! Memory name/Bit description is null", 110 );
		return;
	}

	if ( ($memory_name =~ /.*?\.\d$/) && ( $bit_description !~ /^\d+$/ )) {
		S_set_error( "Enter only Memory name . Specific byte number is not allowed (Eg. ONLY A_SampleCtrINTW_U8R(0), NOT A_SampleCtrINTW_U8R(0).1", 114 );
		return;
	}

	S_w2log( 4, "PD_ReadMemoryBit for $memory_name \n" );

	unless ($PD_initialized) {
		S_set_error( "PD not initialized", 120 );
		return;
	}

	#set error if FastDiagnostics is already active
	if ($FastDiagActive) {
		S_set_error( "Fast Diagnostics is Active", 121 );
		return;
	}

	return 1 if $main::opt_offline;

	#Check whether the bit description is a bit index and if it is then call the GetBitValue function directly
	if ( $bit_description =~ /^\d+$/ ) {

		$bitvalue = GetBitValue( $memory_name, $bit_description);

		return $bitvalue;
	}

	#If the Bit Desc is a bit comment then the bit index is found by mapping the Bit comment passed to the API with the Bit comment present in the SAD/CNS file
	#check if memory name exists in SAD file & Get the Description
	( $stat, $description, $maxBitWiseCount ) = pd_GetSADItemDesc($memory_name);    #If the stat is 1 then the description contains bitcomments
	check_status($stat);
	if ( $stat < 0 ) {
		return;
	}

	#split Bit descriptions and save it in the structure $bitRepresentation
	@bitComments_arr = split( /,/, $description );
	foreach my $bitIndex ( 0 .. $maxBitWiseCount - 1 ) {
		if ( defined( $bitComments_arr[$bitIndex] ) && $stat == 1 ) {

			$bitRepresentation->{$byteCount}->{$bitIndex} = $bitComments_arr[$bitIndex];
		}
	}

	$byteCount++;

	#check the memory name in SAD file, whether it consists of next, next bytes  ("$memory_name.1" , "$memory_name.2" etc...)
	while ( $stat >= 0 ) {

		#check for next bytes of $memory_name, till it is not found in SAD file
		#and calculate 'number of bytes' of variable
		( $stat, $description, $maxBitWiseCount ) = pd_GetSADItemDesc( $memory_name . "\.$byteCount" );
		if ( $stat >= 0 ) {
			@bitComments_arr = split( /,/, $description );
			foreach my $bitIndex ( 0 .. $maxBitWiseCount - 1 ) {
				if ( defined( $bitComments_arr[$bitIndex] ) && $stat == 1 ) {
					$bitRepresentation->{$byteCount}->{$bitIndex} = $bitComments_arr[$bitIndex];
				}
			}
			$byteCount++;
		}
	}

	for ( my $byteindex = 0 ; $byteindex < $byteCount ; $byteindex++ ) {
		foreach my $bitIndex ( 0 .. $maxBitWiseCount - 1 ) {
			if ( $bitRepresentation->{$byteindex}->{$bitIndex} eq $bit_description ) {

				$bitCommentFound = 1;
				if ( $byteindex > 0 ) {
					$memory_name = $memory_name . "\.$byteindex";
				}
				$bitvalue = GetBitValue( $memory_name, $bitIndex );
			}
		}
	}

    unless($bitCommentFound == 1){
    	S_set_error( "Bit Comment $bit_description not present in the SAD/CNS file", 110 );
        return;
	}

	return $bitvalue;
}

=head2 PD_ReadMemoryByAddress

    $value_aref = PD_ReadMemoryByAddress( $address, $no_of_bytes );

read number of bytes starting from address, returns reference to array containing decimal byte values.

B<Arguments:>

=over

=item $address

It is the address at which data has to be read.
Address may be decimal or hex e.g '0x40006F4'

=item $no_of_bytes

It is the number of bytes to be read starting from address.

=back

B<Return Value:>

=over

=item value_aref 

Success      : the data read for the respective memory address.

Offline mode : [1]

Error        : []

=back

B<Examples AB12:>

    $value_aref = PD_ReadMemoryByAddress( '0x20400001', 1 );
    
B<Notes>:

This same API can be used for reading NVM. To read NVM appropriate address should be passsed.
NVM Memory address always starts from '2'.
NVM $address may be decimal or hex e.g  '0x20400001' (Read NVM Memory)

Supported AB Generations:: B<10 and 12>

=cut

sub PD_ReadMemoryByAddress
{
    my $address     = shift;
    my $no_of_bytes = shift;
    my $value_aref;
    my $dummy_return = [];

    unless ( defined($no_of_bytes) )
    {
        S_set_error( "! too less parameters ! SYNTAX: values = PD_ReadMemoryByAddress( address, no_of_bytes )", 110 );
        return $dummy_return;
    }

    #convert address if required
    $address = S_0x2dec($address);

    S_w2log( 5, " PD_ReadMemoryByAddress: Read the $no_of_bytes of memory data from address $address \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return $dummy_return;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $dummy_return;
    }

    return [1]if $main::opt_offline;

    ( $stat, $value_aref ) = pd_ReadAddress( $address, $no_of_bytes );
    check_status($stat);
    
    if ( $stat < 0 )
    {
    	my $hexaddress  = S_dec2hex($address);
    	S_set_error(" PD_ReadMemoryByAddress: $hexaddress is an invalid address\n", 0);
    	
    	# Error is already set in check_status
        return $dummy_return;
    }

    if ( scalar(@$value_aref) < 1 )
    {
        S_w2log( 4, "PD_ReadMemoryByAddress $address $no_of_bytes received no value\n" );
        S_set_verdict(VERDICT_INCONC);
        return $dummy_return;
    }
    else
    {
        my $hexVal_aref = S_decaref2hexaref($value_aref);
        my $hexaddress  = S_dec2hex($address);
        S_w2log( 4, "PD_ReadMemoryByAddress $address $no_of_bytes received - @$value_aref -\n" );
        return ($value_aref);
    }
}

=head2 PD_ReadMemoryByName

    $value_aref = PD_ReadMemoryByName( $name );

Read memory by label, length will be taken from SAD file, returns reference to array containing decimal byte values.

B<Arguments:>

=over

=item $name

if $name is a multi-byte value all bytes are read e.g.: value_U32X will read 4 bytes.

=back

B<Return Value:>

=over

=item value_aref 

Success flag: the data read for the respective memory label.

Offline mode: [1]

Error:        []

=back

B<Examples AB12:>

    $value_aref = PD_ReadMemoryByName('rb_res_IllegalEventData_dfst');
    
B<Notes>:

This same API can be used for reading NVM.
To read NVM appropriate NVM label name should be passsed and address always starts with '2'.

Supported AB Generations:: B<10 and 12>

=cut

sub PD_ReadMemoryByName
{
    my $label = shift;
    my $value_aref;

    unless ( defined($label) )
    {
        S_set_error( "! too less parameters ! SYNTAX: values = PD_ReadMemoryByName( name )", 110 );
        return [];
    }

    S_w2log( 5, " PD_ReadMemoryByName: Read the memory data from address $label \n" );

    return [1] if $main::opt_offline;

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return [];
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return [];
    }

    ( $stat, $value_aref ) = pd_ReadName($label);
    check_status($stat);
    
    if ( $stat < 0 )
    {
    	# Error is already set in check_status
        return [];
    }

    if ( scalar(@$value_aref) < 1 )
    {
        S_set_error("PD_ReadMemoryByName $label received no value");
        return [];
    }

    my $hexVal_aref = S_decaref2hexaref($value_aref);
    S_w2log( 4, " PD_ReadMemoryByName: PD_ReadMemoryByName $label received - @$value_aref -\n" );
    return ($value_aref);
}

=head2 PD_ReadPasINIT2Data

     [ 16 bytes] = PD_ReadPasINIT2Data( $pasname );

read INIT2 data from PAS.

calls internally
     address = ReadName(S_PesIntData_XXR.A_SensorSpecificData_XPX(pas_index))
     values  = ReadAddress(address,16)

offline + Error return : [0]

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_ReadPasINIT2Data
{
    my $pasname = shift;
    my ( $value_aref, $address_aref );
    my $offline_ret = [0];

    unless ( defined($pasname) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_ReadPasINIT2Data( pasname )", 110 );
        return $offline_ret;
    }

    S_w2log( 4, "PD_ReadPasINIT2Data $pasname\n" );

    if ( defined $main::ProjectDefaults->{'DEVICE_CONFIG'}{$pasname} )
    {
        $pasname = $main::ProjectDefaults->{'DEVICE_CONFIG'}{$pasname};
    }
    else
    {
        S_set_error( " Device '$pasname' not found in ProjectConst", 114 );
        return $offline_ret;
    }

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return $offline_ret;
    }

    if ( $ABgeneration > 10 )
    {
	    #set error if FastDiagnostics is already active
	    if ($FastDiagActive)
	    {
	        S_set_error( "Fast Diagnostics is Active", 121 );
	        return $offline_ret;
	    }
	
	    return $offline_ret if $main::opt_offline;
	    
		# todo: check order of bytes
	    ( $stat, $address_aref ) = pd_ReadName("rb_pssm_InternalData_st.ChannelMiscData_apv($PAS_index{$pasname})");
	    check_status($stat);
	    ( $stat, $value_aref ) = pd_ReadAddress( hex( S_aref2hex($address_aref) ), 16 );
	    check_status($stat);
	
	    S_w2log( 4, "PD_ReadPasINIT2Data PASindex $PAS_index{$pasname} ($pasname) returned - @$value_aref -\n" );
	
	    return ($value_aref);
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return $offline_ret;
    }

    return $offline_ret if $main::opt_offline;

    ( $stat, $address_aref ) = pd_ReadName("S_PesIntData_XXR.A_SensorSpecificData_XPX($PAS_index{$pasname})");
    check_status($stat);
    ( $stat, $value_aref ) = pd_ReadAddress( hex( S_aref2hex($address_aref) ), 16 );
    check_status($stat);

    S_w2log( 4, "PD_ReadPasINIT2Data PASindex $PAS_index{$pasname} ($pasname) returned - @$value_aref -\n" );

    return ($value_aref);
}

=head2 PD_reset_PowerOnCounter

     PD_reset_PowerOnCounter( );

reset power on counter by setting V_POnCounter_U16E or V_POnCounter_U32E to 0.

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_reset_PowerOnCounter
{
    my $address;
    my $label_count = 0;

    S_w2log( 4, "PD_reset_PowerOnCounter\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_reset_PowerOnCounter' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    # if defined V_POnCounter_U16E
    ( $stat, $address ) = pd_GetAddressByName('V_POnCounter_U16E');
    if ( $stat >= 0 )
    {
        S_w2log( 5, "PD_reset_PowerOnCounter: set V_POnCounter_U16E to 0\n" );
        $stat = pd_WriteName( "V_POnCounter_U16E", [ 0, 0 ] );
        check_status($stat);

        #only for consistency
        $stat = pd_WriteName( "V_POnCounter_U16R", [ 0, 0 ] );
        check_status($stat);
        $label_count++;
    }

    # if defined V_POnCounter_U32E
    ( $stat, $address ) = pd_GetAddressByName('V_POnCounter_U32E');
    if ( $stat >= 0 )
    {
        S_w2log( 5, "PD_reset_PowerOnCounter: set V_POnCounter_U32E to 0\n" );
        $stat = pd_WriteName( "V_POnCounter_U32E", [ 0, 0, 0, 0 ] );
        check_status($stat);

        #only for consistency
        $stat = pd_WriteName( "V_POnCounter_U32R", [ 0, 0, 0, 0 ] );
        check_status($stat);
        $label_count++;
    }

    if ( $label_count < 1 )
    {
        S_set_error( "V_POnCounter_U16E or V_POnCounter_U32E not found", 109 );
    }

    S_w2log( 4, "PD_reset_PowerOnCounter done!!\n" );

    return 1;
}

=head2 PD_reset_PowerOnTime

     PD_reset_PowerOnTime( );

reset power on time by setting V_PoOnTime_U32R to 0.
Performs ECU reset that changes take place.

Error return : 0

offline return : 1

B<Note:> Supported AB Generations:: B<10>

=cut

sub PD_reset_PowerOnTime
{
    my $address;

    S_w2log( 4, "PD_reset_PowerOnTime\n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    if ( $ABgeneration > 10 )
    {
        S_set_error( "The function 'PD_reset_PowerOnTime' is not currently support for AB12 project \n", 20 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    # if defined V_PoOnTime_U32R
    ( $stat, $address ) = pd_GetAddressByName('V_PoOnTime_U32R');
    if ( $stat >= 0 )
    {
        S_w2log( 5, "PD_reset_PowerOnTime: set V_PoOnTime_U32R to 0\n" );
        $stat = pd_WriteName( "V_PoOnTime_U32R", [ 0, 0, 0, 0 ] );
        check_status($stat);
        S_w2log( 5, "pd_WriteName (V_PoOnTime_U32R) status :: $stat\n" );

        #only for consistency
        S_w2log( 5, "PD_reset_PowerOnTime: set V_PoOnTime_U32E to 0\n" );
        $stat = pd_WriteName( "V_PoOnTime_U32E", [ 0, 0, 0, 0 ] );
        check_status($stat);
        S_w2log( 5, "pd_WriteName (V_PoOnTime_U32E) status :: $stat\n" );

        $stat = pd_ECUreset(0);
        check_status($stat);
        S_w2log( 5, "pd_ECUreset status :: $stat\n" );
    }
    else
    {
        S_set_error( "V_PoOnTime_U32R not found", 109 );
        return 0;
    }

    S_w2log( 4, "PD_reset_PowerOnTime is done\n" );
    return 1;
}

=head2 PD_SetMemoryBits

     PD_SetMemoryBits( $memory_name , $bit_descriptions_aref );

Set Memory bits by using the variable name and Bit descriptions available in SAD file.

$memory_name = Name of the variable

Only Memory name B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16X')> is needed. Not the specific byte names B<(eg.'S_PDMProgVarTbl1_XXR.V_ProdMode_U16XI<.1>')>

$bit_descriptions_aref = Array reference of (comma seperated) Bit descriptions that needs to be "Set" .

Bit descriptions should be copied from SAD (.sad) file

Error return : 0

offline return : 1

Ex:

     PD_SetMemoryBits('S_PDMProgVarTbl1_XXR.V_ProdMode_U16X',['Fault Quali Time','Suppress CAN Faults']);

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_SetMemoryBits
{

    my $memory_name           = shift;
    my $bit_descriptions_aref = shift;
	my $MaxBitWiseCount = 0;
    my ( @tempArray, $byteCount, $Description, $descFound, %bitDescriptionHash );
    my $bitRepresentation = {};    #						 For DiagSym3
    							   #                         ByteNumbers    BitNumbers        BitDescriptions
                                   #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {16}     ->  "Description of Bit 16"
                                   #
                                   #                              {1}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {16}     ->  "Description of Bit 16"
                                   #							For other than DiagSym3
                                   #                         ByteNumbers    BitNumbers        BitDescriptions
                                   #   $bitRepresentation->       {0}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {7}     ->  "Description of Bit 7"
                                   #
                                   #                              {1}     ->   {0}     ->  "Description of Bit 0"
                                   #                                      ->   {1}     ->  "Description of Bit 1"
                                   #                                      ->    .                    .
                                   #                                      ->    .                    .
                                   #                                      ->   {7}     ->  "Description of Bit 7"

    $byteCount = 0;
    unless ( defined($bit_descriptions_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_SetMemoryBits( \$memory_name , \$bit_descriptions_aref )", 110 );
        return 0;
    }

    #check $bit_descriptions_aref for undef elements
    if ( S_check_array( $bit_descriptions_aref, "\$bit_descriptions_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    #check $bit_descriptions_aref contains atleast one element
    if ( scalar(@$bit_descriptions_aref) == 0 )
    {
        S_set_error( "\$bit_descriptions_aref does not contain any Bit descriptions", 114 );
        return 0;
    }

    if ( defined($memory_name) && $memory_name =~ /.*?\.\d$/ )
    {
        S_set_error( "Enter only Memory name . Specific byte number is not allowed (Eg. ONLY A_SampleCtrINTW_U8R(0), NOT A_SampleCtrINTW_U8R(0).1", 114 );
        return 0;
    }

    S_w2log( 4, "PD_SetMemoryBits  for memory name $memory_name \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    #check if memory name exists in SAD file & Get the Description
    ( $stat, $Description, $MaxBitWiseCount) = pd_GetSADItemDesc($memory_name);
    check_status($stat);
    if ( $stat < 0 )
    {
        return 0;
    }

    #split Bit descriptions and save it in the structure $bitRepresentation
    @tempArray = split( /,/, $Description );
    foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
    {
        if ( defined( $tempArray[$bitIndex] ) && $stat == 1 )
        {
            $bitRepresentation->{$byteCount}->{$bitIndex} = $tempArray[$bitIndex];
        }
        else
        {
            $bitRepresentation->{$byteCount}->{$bitIndex} = "";
        }

        unless ( exists( $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} } ) )
        {
            $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} } = 1;
        }
        else
        {
            $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} }++;
        }
    }

    $bitRepresentation->{$byteCount}->{'value'} = 0;

    $byteCount++;

    #check the memory name in SAD file, whether it consists of next, next bytes  ("$memory_name.1" , "$memory_name.2" etc...)
    while ( $stat >= 0 )
    {

        #check for next bytes of $memory_name, till it does not found in SAD file
        #and calculate 'number of bytes' of variable
        ( $stat, $Description, $MaxBitWiseCount) = pd_GetSADItemDesc( $memory_name . "\.$byteCount" );
        if ( $stat >= 0 )
        {
            @tempArray = split( /,/, $Description );
            foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
            {
                if ( defined( $tempArray[$bitIndex] ) && $stat == 1 )
                {
                    $bitRepresentation->{$byteCount}->{$bitIndex} = $tempArray[$bitIndex];
                }
                else
                {
                    $bitRepresentation->{$byteCount}->{$bitIndex} = "";
                }

                unless ( exists( $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} } ) )
                {
                    $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} } = 1;
                }
                else
                {
                    $bitDescriptionHash{ $bitRepresentation->{$byteCount}->{$bitIndex} }++;
                }
            }
            $bitRepresentation->{$byteCount}->{'value'} = 0;
            $byteCount++;
        }
    }

    #check for the given Bit descriptions from User and calculate the appropriate byte value
    #report error, if any bit description is not found in Variable bit descriptions
    foreach my $bitdesc (@$bit_descriptions_aref)
    {
        $descFound = 0;
        for ( my $byteindex = 0 ; $byteindex < $byteCount ; $byteindex++ )
        {
            foreach my $bitIndex ( 0 .. $MaxBitWiseCount-1 )
            {
                if ( $bitRepresentation->{$byteindex}->{$bitIndex} eq $bitdesc )
                {
                    #check for the ambiguous bit-descriptions available
                    if ( $bitDescriptionHash{$bitdesc} == 1 )
                    {
                        $bitRepresentation->{$byteindex}->{'value'} |= ( 1 << $bitIndex );
                    }
                    else
                    {
                        S_set_error( "Possible Ambiguity : Bit description '$bitdesc' is found " . $bitDescriptionHash{$bitdesc} . " times in variable '$memory_name' . ", 109 );
                        return 0;
                    }
                    $descFound++;
                }
            }
        }

        #if Bit-description not found, report error
        unless ($descFound)
        {
            S_set_error( "Bit description '$bitdesc' is not found in variable '$memory_name'", 109 );
            return 0;
        }
    }

    my @writeArray = ();
    my $readArray;

    #Read the corresponding memory and get values that are already existing
    ( $stat, $readArray ) = pd_ReadName($memory_name);
    check_status($stat);

    #cumulate the "values to be written" in one single array
    push( @writeArray, $bitRepresentation->{$_}->{'value'} | $$readArray[$_] ) foreach ( 0 .. ( $byteCount - 1 ) );    #logical OR the Mask , Existing value
    $stat = pd_WriteName( "$memory_name", \@writeArray );
    check_status($stat);

    if ( $stat >= 0 )
    {
        S_w2log( 4, "PD_SetMemoryBits ($stat) : value of '$memory_name' is set for Bits '" . join( ", ", @$bit_descriptions_aref ) . "' \n" );
    }

    return 1;
}

=head2 PD_wait_INI_end

      PD_wait_INI_end();

wait until last bit in INIEND label is set or INIEND timeout reached,

Assign INIEND timeout value in project constant 'ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_TIMEOUT'};'

Assign INIEND label value in project constant 'ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_LABEL'};'

B<DEFAULT VALUES>

    INIEND_TIMEOUT is 60 sec
    INIEND_LABEL is either V_ITMTestExecutedStatus_U32R or F_ITMTestExecutedStatus_U32R or A_ITMTestExecutedStatus_U8R(0)

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_wait_INI_end
{
    my $timeout      = $main::ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_TIMEOUT'};
    my $INIend_label = $main::ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_LABEL'};
    my $address;

    S_w2log( 4, " PD_wait_INI_end: \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    unless ( defined $timeout )
    {
        $timeout = 60;
        S_w2log( 5, "PD_wait_INI_end: ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_TIMEOUT'} not defined, considered the default timeout -- $timeout seconds \n" );
    }
    my ( $ini_end, $value_aref, $start );
    $start   = S_get_TC_time();
    $ini_end = 0;

    # to make sure that SW reset command that has been called before has really been started
    S_wait_ms(100);

    if ( defined $INIend_label )
    {
        ( $stat, $address ) = pd_GetAddressByName($INIend_label);
        $INIend_label = $INIend_label if ( $stat >= 0 );
    }
    else
    {
        # if defined V_ITMTestExecutedStatus_U32R or F_ITMTestExecutedStatus_U32R
        ( $stat, $address ) = pd_GetAddressByName('V_ITMTestExecutedStatus_U32R');
        $INIend_label = 'V_ITMTestExecutedStatus_U32R' if ( $stat >= 0 );
        ( $stat, $address ) = pd_GetAddressByName('F_ITMTestExecutedStatus_U32R');
        $INIend_label = 'F_ITMTestExecutedStatus_U32R' if ( $stat >= 0 );
        ( $stat, $address ) = pd_GetAddressByName('A_ITMTestExecutedStatus_U8R(0)');
        $INIend_label = 'A_ITMTestExecutedStatus_U8R(0)' if ( $stat >= 0 );
        S_w2log( 5, "PD_wait_INI_end: ProjectDefaults->{'PRODUCTION_DIAGNOSIS'}{'INIEND_LABEL'} not defined, considered the default label -- $INIend_label\n" );
    }

    if ($INIend_label)
    {
        while ( $ini_end < 1 and S_get_TC_time() - $start < $timeout )
        {
            ( $stat, $value_aref ) = pd_ReadName($INIend_label);
            check_status($stat);
            $ini_end = hex( S_aref2hex($value_aref) ) & 1;
            S_w2log( 5, "ini_end $ini_end ($INIend_label=" . S_aref2hex($value_aref) . ") \n" );
        }
        my $duration = S_get_TC_time() - $start;
        $duration = sprintf( "%.2f", $duration );
        S_w2log( 3, " PD_wait_INI_end = $ini_end (" . S_aref2hex($value_aref) . ") after " . ($duration) . " sec\n" );
        if ( $ini_end < 1 ) { S_set_error( "INIT_end flag not set after timeout ($timeout sec)", 5 ); }
    }
    else
    {
        S_set_error( "INIEND LABEL not found", 109 );
    }

    return 1;
}

=head2 PD_writeDump2ECU

I<B<Syntax : >>

     $status = PD_writeDump2ECU( $dumpFile );

I<B<Arguments     : >>

     $dumpFile = name of dump file: *.hex (EEPROM dump or RAM dump)

I<B<Description :>>

Writes contents of dump file (EEPROM dump or RAM dump) to ECU using PD_WriteMemoryByAddress. Returns 1 on success.

B<CAUTION>: If the dump file does not match to your ECU HW and SW then it can seriously corrupt your ECU SW!

Error return : 0

Success return :: 1

=cut

sub PD_writeDump2ECU
{

    my $dumpFile = shift;

    unless ( defined($dumpFile) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_writeDump2ECU( dumpFile )", 110 );
        return 0;
    }
    unless ( $dumpFile =~ /\.hex$/i )
    {
        S_set_error( " $dumpFile is not a hexfile (*.hex)", 114 );
        return 0;
    }
    unless ( open( FILE, "<$dumpFile" ) )
    {
        S_set_error( " could not open $dumpFile for reading: $@", 1 );
        return 0;
    }

    my $baseAddress;
    while ( my $line = <FILE> )
    {

        next if $line =~ /^!/;    # skip comment lines starting with !
        if ( $line =~ /^:(\w+)/ )
        {
            my $data          = $1;
            my $numberOfBytes = hex( substr( $data, 0, 2, '' ) );
            my $address       = substr( $data, 0, 4, '' );
            my $type          = hex( substr( $data, 0, 2, '' ) );
            my $checksum      = substr( $data, -2, 2, '' );
            my @bytes         = map hex, $data =~ /../g;            # splits the hex bytes into an array of dec numbers

            if ( $type == 4 )
            {
                $baseAddress = '0x' . $data;
            }
            elsif ( $type == 0 )
            {
                if ( not defined $baseAddress )
                {
                    S_set_error( "no base address found in dump file", 114 );
                    close(FILE);
                    return 0;
                }
                $address = $baseAddress . $address;
                S_w2log( 3, "PD_writeDump2ECU: executing PD_WriteMemoryByAddress( $address, [ @bytes ] ) \n" );

                # PD_WriteMemoryByAddress will write the bytes in reverse order if 'CPU Type' in SAD file is not 'TMS470', so we have to take care for this
                my $cpuType;
                ( $stat, $cpuType ) = pd_GetSADInfo("CPU Type");
                unless ( $cpuType =~ /TMS470/i )
                {
                    @bytes = reverse @bytes;
                }
                PD_WriteMemoryByAddress( $address, \@bytes );
            }
            elsif ( $type == 1 )
            {
                S_w2log( 5, "PD_writeDump2ECU: end of data reached in dump file\n" );
            }
        }
    }
    close(FILE);

    return 1;
}

=head2 PD_WriteMemoryByAddress

     PD_WriteMemoryByAddress( $address, $bytes_aref );
     e.g. PD_WriteMemoryByAddress( '0x8005FD8',[5,8] );
          PD_WriteMemoryByAddress( '0x20400001',[5,8] );

$address me be decimal or hex e.g  '0x20400001' (Read NVM Memory)

write given bytes starting from $address, $bytes_aref has to be a reference to an array, hex, dec or bin allowed

B<Note:> This same API can be used for writing NVM. B<>

To write NVM appropriate address should be passsed. NVM Memory address always starts from '2'.

NVM $address may be decimal or hex e.g  '0x20400001' (Read NVM Memory)

 PD_WriteMemoryByAddress( '0x20400001', [1,2]);

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_WriteMemoryByAddress
{
    my $address    = shift;
    my $bytes_aref = shift;
    my $count;

    unless ( defined($bytes_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_WriteMemoryByAddress( address, bytes_aref )", 110 );
        return 0;
    }

    #check $bytes_aref for undef elements
    if ( S_check_array( $bytes_aref, "\$bytes_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@$bytes_aref) ; $count++ )
    {
        @$bytes_aref[$count] = S_0x2dec( @$bytes_aref[$count] );

        # check if 0 =< byte <= 255
        if ( @$bytes_aref[$count] =~ /\./ )
        {
            S_set_error( "PD_WriteMemoryByAddress: " . @$bytes_aref[$count] . " is a float\n", 114 );
            return 0;
        }
        elsif ( @$bytes_aref[$count] > 255 )
        {
            S_set_error( "! byte value @$bytes_aref[$count] on array[$count] out of range ( 0<=x<=255 )", 110 );
            return 0;
        }
        elsif ( @$bytes_aref[$count] < 0 )
        {
            S_set_error( "! byte value @$bytes_aref[$count] not a valid value (S_0x2dec error) or < 0", 110 );
            return 0;
        }
    }

    $address = S_0x2dec($address);

    S_w2log( 5, " PD_WriteMemoryByAddress: Writes @{$bytes_aref} to address $address \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = pd_WriteAddress( $address, $bytes_aref );
    check_status($stat);

    S_w2log( 5, " PD_WriteMemoryByAddress: pd_WriteAddress status is $stat \n" );

    S_w2log( 4, " PD_WriteMemoryByAddress ($stat): $address -@{$bytes_aref}-\n" );
    return 1;
}

=head2 PD_WriteMemoryByName

     PD_WriteMemoryByName( $name, $bytes_aref );
     e.g. PD_WriteMemoryByName( 'V_IdleFaultNbr_U16R', [12,34] );

write $no_of_bytes bytes starting from $name (resolved from SAD file), $bytes_aref has to be a reference to an array, hex, dec or bin allowed

B<Note:> The same API can be used for writing NVM. B<>

To write NVM appropriate label should be passsed. NVM Memory address always starts from '2'.

 PD_WriteMemoryByName( 'rb_res_IllegalEventData_dfst', [1,2]);

Error return : 0

offline/success return :: 1

B<Note:> Supported AB Generations:: B<10 and 12>

=cut

sub PD_WriteMemoryByName
{
    my $label      = shift;
    my $bytes_aref = shift;
    my $count;

    unless ( defined($bytes_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX: PD_WriteMemoryByName( name, bytes_aref )", 110 );
        return 0;
    }

    #check $bytes_aref for undef elements
    if ( S_check_array( $bytes_aref, "\$bytes_aref" ) == 0 )
    {
        S_set_error( "S_check_array reported an error", 114 );
        return 0;
    }

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@$bytes_aref) ; $count++ )
    {
        @$bytes_aref[$count] = S_0x2dec( @$bytes_aref[$count] );

        # check if  0 =< byte <= 255
        if ( @$bytes_aref[$count] =~ /\./ )
        {
            S_set_error( "PD_WriteMemoryByName: " . @$bytes_aref[$count] . " is a float\n", 114 );
            return 0;
        }
        elsif ( @$bytes_aref[$count] > 255 )
        {
            S_set_error( "! byte value @$bytes_aref[$count] on array[$count] out of range ( 0<=x<=255 )", 110 );
            return 0;
        }
        elsif ( @$bytes_aref[$count] < 0 )
        {
            S_set_error( "! byte value @$bytes_aref[$count] not a valid value (S_0x2dec error) or < 0", 110 );
            return 0;
        }
    }

    S_w2log( 5, " PD_WriteMemoryByName: Writes @{$bytes_aref} to label $label \n" );

    unless ($PD_initialized)
    {
        S_set_error( "PD not initialized", 120 );
        return 0;
    }

    #set error if FastDiagnostics is already active
    if ($FastDiagActive)
    {
        S_set_error( "Fast Diagnostics is Active", 121 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = pd_WriteName( $label, $bytes_aref );
    check_status($stat);
    S_w2log( 5, " PD_WriteMemoryByName: pd_WriteName status is $stat \n" );

    S_w2log( 4, " PD_WriteMemoryByName ($stat): $label - @{$bytes_aref}-\n" );

    return 1;
}
############################################################################################################
#
# not exported functions
#
############################################################################################################

=head1 not exported functions

=head2 BuildDeviceConfigTable

 BuildDeviceConfigTable() not exported

Called from process_SAD().

Build the device config data structure $device_conf_tbl and $SQ_index, $PAS_index, etc. based on the data read from SAD and CNS file.

=cut

sub BuildDeviceConfigTable
{

    %SQ_index = %SW_index = %PAS_index = %WL_index = %CUST_index = %ASIC_index = %SPB_index = %parSEC_index = ();

    # build device config table with byte number and bitmask for every device
    my $bitcount   = 0;
    my $bytecount  = 0;
    my $indexcount = 0;

    foreach my $device (@squibs)
    {
        $SQ_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }
    $indexcount = 0;
    if ( $ABgeneration == 12 )
    {
        $bytecount = 0;
        $bitcount  = 0;
    }

    foreach my $device (@pases)
    {
        $PAS_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }
    $indexcount = 0;
    if ( $ABgeneration == 12 )
    {
        $bytecount = 0;
        $bitcount  = 0;
    }

    foreach my $device (@switches)
    {
        $SW_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }
    $indexcount = 0;
    if ( $ABgeneration == 12 )
    {
        $bytecount = 0;
        $bitcount  = 0;
    }

    foreach my $device (@lamps)
    {
        $WL_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }
    $indexcount = 0;

    foreach my $device (@cust)
    {
        $CUST_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }

    # ASIC will be in different table, so start again with bit0 byte 0
    $bitcount   = 0;
    $bytecount  = 0;
    $indexcount = 0;
    foreach my $device (@asics)
    {
        $ASIC_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }

    # SPECIAL BEHAVIOUR will be in different table, so start again with bit 0 byte 0
    $bitcount   = 0;
    $bytecount  = 0;
    $indexcount = 0;
    foreach my $device (@SpBehaviour)
    {
        $SPB_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }

    # SECTION ACTIVATORS will be in different table, so start again with bit 0 byte 0
    $bitcount   = 0;
    $bytecount  = 0;
    $indexcount = 0;
    foreach my $device (@parSections)
    {
        $parSEC_index{$device} = $indexcount;
        $indexcount++;
        $device_conf_tbl->{$device}{'bitmask'} = 2**$bitcount;
        $device_conf_tbl->{$device}{'byte'}    = $bytecount;
        if ( $bitcount > 6 )
        {
            $bitcount = 0;
            $bytecount++;
        }
        else
        {
            $bitcount++;
        }
    }

    return 1;

}

=head2 check_status

 check_status($result) not exported

  if result < 0, 
    log error string and 
    set INCONC via S_set_error and 
    return undefined

  all other cases
    return 1

=cut

sub check_status
{
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status < 0 )
    {
        my $errortext = pd_GetErrorString($status);
        if($status == -941)
        {
        	$errortext = $errortext."\n This may be due to any of the below reasons:
        	 1. ECU is OFF at this instant \n 
        	 2. Wrong CAN hardware no or channel no. \n
        	 3. Wrong CAN Type is configured \n 
        	 For futher details : https://connect.bosch.com/wikis/home?lang=en-us#!/wiki/Wad0c302c3442_4748_8eef_7d10157fb564/page/PD%20Troubleshooting";
#            S_w2log(5, "Waiting 6sec in case of error -941 to make sure that no wrong answer from the ECU is received. This is a workaround for Defect 74850.\n");
#            S_wait_ms( 6000 );
#            This delay is added to Production Diagnosis DLL Version Updated Ver 4.6.0.            
        }
        S_set_error( "PD ($status): $errortext", 5 );
        return;
    }

    return 1;
}

=head2 DeviceConfigurationBitmask

DeviceConfigurationBitmask($deviceType,$device,$label_mode,$setflag) not exported function

Called from DeviceConfigurationCheck().

This function is able to read, modify the values and write back the value to particular device label.
If the read value is equal to the modified value then nothing is done.

=cut

sub DeviceConfigurationBitmask
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'DeviceConfigurationBitmask($deviceType,$device,$label_mode,$setflag)', @args );

    my $deviceType = shift @args;
    my $device     = shift @args;
    my $label_mode = shift @args;
    my $setflag    = shift @args;

    my ( $value_aref );

    my $errorflag = 0;

    # read the byte value of given device
    my $byte_value = $device_conf_tbl->{$device}{'byte'};

    # read the bitmask value of given device
    my $bit_mask = $device_conf_tbl->{$device}{'bitmask'};

    # get the label based on the device type
    my $label_value = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{$label_mode};

    # read current values
    ( $stat, $value_aref ) = pd_ReadName("$label_value($byte_value)");
    my $currentValue = S_aref2hex($value_aref);
    check_status($stat);
    $errorflag++ if ( $stat < 0 );
    S_w2log( 5, "-> read $label_value($byte_value) : $currentValue\n" );

    # modify values according to devices
    my $newValue = S_bitmask_set( $currentValue, $bit_mask, $setflag );

    # if value has not changed nothing needs to be done
    if( hex( $newValue ) == hex( $currentValue ) ){
        S_w2log( 5, "-> applying the bitmask does not change the value --> nothing done\n" );
        return 1;
    }

    # write modified values
    $stat = pd_WriteName( "$label_value($byte_value)", [ hex( $newValue ) ] );
    check_status($stat);
    $errorflag++ if ( $stat < 0 );
    S_w2log( 5, "-> write $label_value($byte_value) : $newValue\n" );

    if ( $errorflag != 0 )
    {
        S_set_error( " aborting PD_Device_configuration due to $errorflag errors", 5 );
        return 0;
    }
    return 1;
}

=head2 DeviceConfigurationCheck

 DeviceConfigurationCheck($device_aref, $mode, $setflag) not exported function

Called from PD_DeviceConfiguration().

This function is able to check which device configuration and allow to read and write the device configuration.

=cut

sub DeviceConfigurationCheck
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'DeviceConfigurationCheck($device_aref, $mode)', @args );

    my $device_aref = shift @args;
    my $mode        = shift @args;

    my ( %device_value, $value_aref, $label_mode, $setflag );

    my $errorflag = 0;

    # check the mode is to set or clear
    # set 1 if need to set the device
    if ( $mode eq "set" or $mode eq "set_Mon" )
    {
        $setflag = 1;
    }

    # set 0 if need to clear the device
    elsif ( $mode eq "clear" or $mode eq "clear_Mon" )
    {
        $setflag = 0;
    }
    else
    {
        S_set_error( " mode is not 'set', 'clear','set_Mon' or 'clear_Mon'", 114 );
        return 0;
    }

    # check the mode and get either 'monitored' or 'configured'
    # if $mode contains "_Mon", it set as monitored else set as configured
    if ( $mode =~ /_Mon$/ )
    {
        $label_mode = 'monitored';
    }
    else
    {
        $label_mode = 'configured';
    }

    # check which values to be modified
    foreach my $device (@$device_aref)
    {
        # monitoring will not work on ASICs.
        if ( exists $ASIC_index{$device} && $label_mode eq 'configured' )
        {
            DeviceConfigurationBitmask( 'asics', $device, $label_mode, $setflag );
        }

        # monitoring will not work on SpecialBehaviourbits.
        elsif ( exists $SPB_index{$device} && $label_mode eq 'configured' )
        {
            DeviceConfigurationBitmask( 'SpBehaviour', $device, $label_mode, $setflag );
        }

        # monitoring will not work on Section Activators.
        elsif ( exists $parSEC_index{$device} && $label_mode eq 'configured' )
        {
            DeviceConfigurationBitmask( 'parSections', $device, $label_mode, $setflag );
        }

        # PAses has contains seperate device label for AB12
        elsif ( exists $PAS_index{$device} && $ABgeneration == 12 )
        {
            DeviceConfigurationBitmask( 'pases', $device, $label_mode, $setflag );
        }

        # SWITCHES has contains seperate device label for AB12
        elsif ( exists $SW_index{$device} && $ABgeneration == 12 )
        {
            DeviceConfigurationBitmask( 'switches', $device, $label_mode, $setflag );
        }
		# Aout has contains seperate device label for AB12
        elsif ( exists $WL_index{$device} && $ABgeneration == 12 )
        {
            DeviceConfigurationBitmask( 'lamps', $device, $label_mode, $setflag );
        }
        # else common squib device label for all in case of AB10
        elsif ( exists( $SQ_index{$device} ) or exists( $SW_index{$device} ) or exists( $PAS_index{$device} ) or exists( $WL_index{$device} ) or exists( $CUST_index{$device} ) )
        {
            DeviceConfigurationBitmask( 'squibs', $device, $label_mode, $setflag );
        }

        # set error device not found in sad file
        else
        {
            S_set_error( "$device Not found in SAD/CNS file", 114 );
        }
    }

    return 1;
}

=head2 DumpSingleDeviceConfiguration

 DumpSingleDeviceConfiguration( $deviceType, $deviceText, $devices_aref ) not exported

Called from PD_DumpDeviceConfiguration().

Dumps the device configuration for a single device type ($deviceType) to html and text log.

=cut

sub DumpSingleDeviceConfiguration
{

    my $deviceType   = shift;
    my $deviceText   = shift;
    my $devices_aref = shift;

    my ( $htmlString, $deviceConfigData_href, @table );

    S_w2log( 5, "DumpSingleDeviceConfiguration for device type $deviceType\n" );

    # build $deviceConfigData_href from $pdConfig_href: depends on $deviceType and which state (real, monitored or configured) is defined
    if ( defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'real'} )
    {
        $deviceConfigData_href->{'Real'}{'variable'} = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'real'};
    }
    if ( defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'monitored'} )
    {
        $deviceConfigData_href->{'Mon'}{'variable'} = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'monitored'};
    }
    if ( defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'configured'} )
    {
        $deviceConfigData_href->{'Prog'}{'variable'} = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$deviceType}{'configured'};
    }

    # get devices list from function argument
    my @devices = @{$devices_aref};

    # calculate number of bytes necessary for the devices
    my $bytes = ceil( scalar(@devices) / 8 );

    # generate first line of text log, e.g. "Asic; Real; Prog\n"
    my $text = "$deviceText";
    foreach my $state ( sort keys %{$deviceConfigData_href} )
    {
        $text .= "; $state";
    }
    $text .= "\n";

    # loop over the bytes
    for ( my $count = 0 ; $count < $bytes ; $count++ )
    {
        my ( $status, $value_aref );

        # loop over the states, e.g. 1 and 3 (for Real and Prog)
        foreach my $state ( sort keys %{$deviceConfigData_href} )
        {
            # read the variable that corresponds to $deviceType and $state
            ( $status, $value_aref ) = pd_ReadName("$deviceConfigData_href->{$state}{'variable'}($count)");
            check_status($status);

            # convert value to bitmask, split to array, reverse order
            my @bitValues = reverse( split( //, sprintf( "%08b", S_0x2dec( $$value_aref[0] ) ) ) );    # @bitValues needs to be declared newly for every loop count so that copying the reference works properly in the next line !!!
                                                                                                       #  store the reference to @bitValues
            $deviceConfigData_href->{$state}{'bits'} = \@bitValues;

            S_w2log( 5, "$deviceConfigData_href->{$state}{'variable'}($count) -> @bitValues\n" );
        }

        # get the bits for state configured to count them down one by one
        my $conf_bits_aref = $deviceConfigData_href->{'Prog'}{'bits'};
        my @conf_bits      = ();
        if ( ref($conf_bits_aref) eq 'ARRAY' )
        {
            @conf_bits = @{$conf_bits_aref};
        }

        # loop as long as @devices and @conf_bits have contents
        while ( @devices and @conf_bits )
        {
            # remove the first element from @devices and @conf_bits
            my $device = shift(@devices);
            shift(@conf_bits);

            # start building the html table and text block
            $htmlString = '<TR><TD>' . $device . '</TD>';
            $text .= "$device";

            # loop over the states, e.g. 1 and 3 (for Real and Prog)
            foreach my $state ( sort keys %{$deviceConfigData_href} )
            {
                # get the bits that we have read earlier with pd_ReadName and extract the first bit; store the rest of the bits again for later
                my @bits     = @{ $deviceConfigData_href->{$state}{'bits'} };    # again, @bits needs to be declared newly for every loop count so that copying the reference works properly later !!!
                my $bitValue = shift(@bits);
                $deviceConfigData_href->{$state}{'bits'} = \@bits;
				$deviceConfigData_href->{$state}{$device}= $bitValue; # Adding the status of indvidual devices on to the return value i.e.$deviceConfigData_href 
                # log 1 as 'X' and 0 as '-' in the table
                if   ( $bitValue eq '1' ) { $bitValue = 'X'; }
                else                      { $bitValue = '-'; }

                # bulid the table elements in html and text
                $htmlString .= '<TD>' . $bitValue . '</TD>';
                $text .= "; $bitValue";
            }

            # finish the line in html and text
            $htmlString .= '</TR>';
            push( @table, $htmlString );
            $text .= "\n";
        }    # end of while
    }    # end of for

    # create the complete html table and append it to the html log
    $htmlString = '<div class="w2rep ' . $module_name . '"><TABLE  class="tablesorter"><TR><TH>' . $deviceText . '</TH>';
    foreach my $state ( sort keys %{$deviceConfigData_href} )
    {
        $htmlString .= "<TH>$state</TH>";
    }
    $htmlString .= join( '', @table, "</TABLE></div>\n" );
    push( @TC_HTML_TEXT, $htmlString );

    # write the text table to the text log
    print $text unless $main::opt_silent;
    print LIFT_general::LOG $text;

    return $deviceConfigData_href;
}

=head2 GenerateDeviceMappingFile

 GenerateDeviceMappingFile() not exported

Called from process_SAD().

Generate device mapping file *_devicemapping.txt based on the data read from SAD and CNS file.

=cut

sub GenerateDeviceMappingFile
{

    #This code generates the text file containing the device config mapping details, to be placed in project defaults
    my $sad = $LIFT_config::SAD_file;
    $sad =~ s/\.([^.]+)$//;    # cut off file extension
    my $mapname = basename($sad) . '_devicemapping.txt';

    unless ( defined $LIFT_config::LIFT_PRJCFG_path )
    {
        S_set_error( "Project config folder path name is not given in Config file to generate the device mapping file \n", 5 );
        return 0;
    }

    if ( open( MAP, ">$LIFT_config::LIFT_PRJCFG_path/$mapname" ) )
    {
        print MAP "'DEVICE_CONFIG' => {\n";
        for my $dev ( "# Squibs", @squibs, "# PASes", @pases, "# Warning lamps", @lamps, "# Switches", @switches, "# Customer dummy device", @cust, "# ASICs", @asics, "# Special Behaviour Bits", @SpBehaviour, "#Section Activators", @parSections )
        {
            if ( $dev =~ /^#/ )
            {
                print MAP "$dev\n";
                next;
            }
            print MAP "\t\t'$dev' => '$dev',\n";
        }
        print MAP "},\n";
        close MAP;
        S_w2rep( '<A HREF="./../../config/' . $mapname . '">PD device mapping template see ' . $mapname . '</A><br>' );
    }
    else
    {
        S_set_error( "Device Mapping $LIFT_config::LIFT_PRJCFG_path/$mapname file not opened", 1 );
    }

    return 1;

}

=head2 GetDeviceEnumsFromCNS

 GetDeviceEnumsFromCNS( \@devtypes ) not exported

Called from process_SAD().

Read device enums from CNS file (AB12).

=cut

sub GetDeviceEnumsFromCNS
{

    my $devtypes_aref = shift;

    # get label for CNS file variable for each supported device type from DEVICE_CONFIG_VARIABLES mapping
    foreach my $devtype (@$devtypes_aref)
    {
        my $label = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$devtype}{'enum'};
        S_w2log( 5, "GetDeviceEnumsFromCNS: for device type $devtype reading label $label\n" );
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'variable'}   = $label;
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = [];
    }

    ### processing CNS file
    unless ( open( CNS, "<$CNSfile" ) )
    {
        S_set_error( "Cannot open CNS file $CNSfile: $!.\nHint: The CNS file must be in the same folder and have the same name (except extension) as the SAD file.", 5 );
        return 0;
    }
    my @lines = <CNS>;
    close(CNS);

    # read enums from CNS file contents
    foreach my $devtype (@$devtypes_aref)
    {

        my @dev_list;
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = \@dev_list;
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'} = 0;
        my $label = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$devtype}{'enum'};
        $label = 'undefined' if not defined $label;    # to avoid perl warnings in the regexp later
        my $labelFound = 0;

        # search for the names of devices for each supported device type in the CNS file line where the corresponding label was found
        foreach my $line (@lines)
        {
            if ( $line =~ /^enum;$label;rb_\w+_(\w+)_\w+;(\d+);(.*)\s*$/ )
            {
                @dev_list = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} };
                my $deviceName = $1;
                $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'} = $2;
                $deviceName =~ s/^AllAsics//;
                $deviceName =~ s/^Switch//;
                push( @dev_list, $deviceName );
                $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = \@dev_list;
                $labelFound = 1;
            }
			# Reading lampstates from CNS file
            if ( $ABgeneration == 12 )
       		 {
				if ( $line =~ /^enum;rb_wimi_SysWIStatus_ten;rb_\w+_(\w+)_\w+;(\d+);(.*)\s*$/)
	            {
	            	@{ $lampstates[$2] } = $3;
	            }
       		 }
        }

        if ( not $labelFound )
        {
            S_set_error( "Label $label for device type $devtype not found in CNS file $CNSfile .", 0 );
        }

        # last entry is no device, but just a placeholder for the max number of devices, so we have to remove it from the list of devices
        @dev_list = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} };
        pop @dev_list;
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = \@dev_list;

        # consistency check: compare the highest index ($pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'}) with the number of devices
        if ( $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'} != @dev_list )
        {
            S_set_error(
                         "CNS file inconsistent: for device type $devtype ($pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'variable'}) the highest index (= "
                           . $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'}
                           . ") is not equal to the number of devices in the enum (= "
                           . @dev_list . ")",
                         5
            );
            return 0;
        }
    }

    return 1;

}

=head2 GetDeviceEnumsFromSAD

 GetDeviceEnumsFromSAD( \@devtypes ) not exported

Called from process_SAD().

Read device enums from SAD file (AB10).

Will access ECU to read out max number of devices for each device type.

=cut

sub GetDeviceEnumsFromSAD
{

    my $devtypes_aref = shift;

    my $value_aref;

    # get label for SAD file variable for each supported device type from DEVICE_CONFIG_VARIABLES mapping
    # get max numbers for each supported device type from ECU by using the labels
    foreach my $devtype (@$devtypes_aref)
    {
        my $label = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$devtype}{'enum'};
        S_w2log( 5, "GetDeviceEnumsFromSAD: for device type $devtype reading label $label\n" );
        ( $stat, $value_aref ) = pd_ReadName($label);
        check_status($stat);
        my $max = S_aref2dec( $value_aref, U8 );
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'variable'}   = $label;
        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'} = $max;
        S_w2log( 3, "max number of $devtype = $max \n" );
    }

    ### processing SAD file
    unless ( open( SAD, "<$LIFT_config::SAD_file" ) )
    {
        S_set_error( "Cannot open SAD file: $!", 5 );
    }
    my @lines = <SAD>;
    close(SAD);

    foreach my $line (@lines)
    {

        # search for the names of devices for each supported device type in the SAD file line where the corresponding label was found
        my @dev_list;
        foreach my $devtype (@$devtypes_aref)
        {
            my $label = $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration}{$devtype}{'enum'};
            if ( $line =~ /^$label,.+,,+(.+)\s*$/ )
            {
                @dev_list = split( /,/, $1 );
                $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = \@dev_list;
            }
        }

        # lamp states
        @{ $lampstates[$1] } = split( /,/, $2 ) if ( $line =~ /^A_LampLogicalStatus_SER\((\d+)\),.+,,(.+)\s*$/ );

    }

    return 1;

}

=head2 GetLastIndexFromSAD

 GetLastIndexFromSAD() not exported

Called from process_SAD().

Open SAD file and store information in data structure for PD_get_last_index.

=cut

sub GetLastIndexFromSAD
{
    ### processing SAD file
    unless ( open( SAD, "<$LIFT_config::SAD_file" ) )
    {
        S_set_error( "Cannot open SAD file: $!", 5 );
    }
    my @lines = <SAD>;
    close(SAD);

    %last_index = ();
    foreach my $line (@lines)
    {

        #process data for PD_get_last_index
        #S_PDMProgVarTbl1_XXE.A_ExtDevConf_U8X(6)
        if ( $line =~ /^([^,]+)\((\d+)\),/ )
        {
            if ( defined $last_index{$1} )
            {
                $last_index{$1} = $2 if ( $2 > $last_index{$1} );
            }
            else
            {
                $last_index{$1} = $2;
            }
        }

        #A_EEMgrJobTable_XSR(9).A_EEData_U8X(3)
        if ( $line =~ /^([^,]+)\((\d+)\)[^,]+,/ )
        {
            if ( defined $last_index{$1} )
            {
                $last_index{$1} = $2 if ( $2 > $last_index{$1} );
            }
            else
            {
                $last_index{$1} = $2;
            }
        }

        #Reading of ROMCODE value from SAD file
        if ( $line =~ /^\s*ROMCODE\s*\:\s*(\w+)/ )
        {
            $RomCode = $1;
        }

#        #Reading lampstates from  SAD File
#        if ( $ABgeneration == 12 )
#        {
#			if ( $line =~ /^rb_wim_CustSysWIStatus_aen\((\d+)\),.+,,(.+)\s*$/ || $line =~ /^rb_wimi_SysWIStatus_aen\((\d+)\),.+,,(.+)\s*$/ || $line =~ /^rb_wima_SysWIStatus_en\((\d+)\),.+,,(.+)\s*$/ )
#            {
#            	@{ $lampstates[$1] } = split( /,/, $2 );
#            }
#        }
    }

    return 1;
}

=head2 Process_nested_hash

    Process_nested_hash($pdConfig_href);

This function is used to access each and every element of nested hash structure.
Compares the copy of $pdConfig_href that is present in LIFT_PD.pm and ProjectConst file.
If the hash is initialized in project constant file this copy will be replaced in global hash $pdConfig_href 

B<Arguments:>

=over

=item $hash 

the hash reference for which individual elements access needs to be made.

=back

B<Return Value:> 1

=back

B<Examples:>

    Process_nested_hash($value);

=cut

sub Process_nested_hash {
    my ($hash,$key_list) = @_;
    
    while (my ($key, $value) = each %$hash) {
        # Keep track of the hierarchy of keys, in case
        # to search the hash.
        push @$key_list, $key;

        if (ref($value) eq 'HASH') {
            # Recurse.
            Process_nested_hash($value, $key_list);
        }
        else {
        if ( defined $$key_list[0] and defined $$key_list[1] and defined $$key_list[2] and defined $$key_list[3] ) {
			if ( defined $LIFT_PROJECT::Defaults->{$$key_list[0]}{$$key_list[1]}{$$key_list[2]}{$$key_list[3]} )
		    {
		    	$pdConfig_href->{$$key_list[0]}{$$key_list[1]}{$$key_list[2]}{$$key_list[3]} = $LIFT_PROJECT::Defaults->{$$key_list[0]}{$$key_list[1]}{$$key_list[2]}{$$key_list[3]};
		    }
         }
        }

        pop @$key_list;
    }
    return 1;
}

=head2 process_SAD

 process_SAD() not exported

Open SAD file (AB10) or SAD file and CNS file (AB12) and store information in data structure for PD_get_last_index and PD_Device_conf.

Will access ECU to read out data for AB10.

Generates a DEVICE_CONFIG mapping of project constant with name "SADFILENAME_devicemapping.txt" in config folder

Note:: SADFILENAME -- Name of the sad file used for the project

The keywords/variable names that are searched for in the SAD/CNS file are defined in the data structure $pdConfig_href with the keys 'enum':

     my $pdConfig_href = {
          'DEVICE_CONFIG_VARIABLES' => {

                '10' => {
                     ...
                     'squibs'         => {
                          'enum'         => 'E_MaxSquibs_SXC',
                          ...
                     },
                     ...
                },
                '12' => {
                     ...
                },
          },
     };


If a project needs other keywords/variable names then the default can be overwritten by defining an appropriate data structure in the project const file:

     $Defaults->{"DEVICE_CONFIG_VARIABLES"} = {
          '10' => {
                ...
          },
          '12' => {
                ...
          },
     };


=cut

sub process_SAD
{
	    # create a list with all supported device types (squibs, PASes, etc.) for the given AB generation
	Process_nested_hash($pdConfig_href,[]);
#    if ( defined $LIFT_PROJECT::Defaults->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration} )
#    {
#        $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration} = $LIFT_PROJECT::Defaults->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration};
#    }

    my @devtypes = sort keys %{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$ABgeneration} };
    S_w2log( 5, "process_SAD: supported device types are: @devtypes\n" );

    # read device enums from SAD/CNS file)
    if ( $ABgeneration <= 10 )
    {
        GetDeviceEnumsFromSAD( \@devtypes );
    }
    else
    {
        GetDeviceEnumsFromCNS( \@devtypes );
    }

    # get values for PD_get_last_index from SAD file
    GetLastIndexFromSAD();

    # summary of all devices found in SAD/CNS file
    S_w2log( 5, "found following devices in SAD/CNS:\n" );
    foreach my $devtype (@devtypes)
    {
        if ( defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} )
        {
            my @dev_list = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} };
            @dev_list = splice( @dev_list, 0, $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'max_number'} );
            $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{$devtype}{'names_aref'} = \@dev_list;
            S_w2log( 5, $devtype . ": " . join( ',', @dev_list ) . " \n" );
        }
    }

    # fill global variables
    @squibs      = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'squibs'}{'names_aref'} }      if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'squibs'}{'names_aref'};
    @pases       = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'pases'}{'names_aref'} }       if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'pases'}{'names_aref'};
    @switches    = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'switches'}{'names_aref'} }    if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'switches'}{'names_aref'};
    @lamps       = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'lamps'}{'names_aref'} }       if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'lamps'}{'names_aref'};
    @cust        = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'cust'}{'names_aref'} }        if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'cust'}{'names_aref'};
    @asics       = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'asics'}{'names_aref'} }       if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'asics'}{'names_aref'};
    @SpBehaviour = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'SpBehaviour'}{'names_aref'} } if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'SpBehaviour'}{'names_aref'};
    @parSections = @{ $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'parSections'}{'names_aref'} } if defined $pdConfig_href->{'DEVICE_CONFIG_VARIABLES'}{'parSections'}{'names_aref'};

    # generate device config file: *_devicemapping.txt
    GenerateDeviceMappingFile();

#    
    # build device config table with byte number and bitmask for every device
    BuildDeviceConfigTable();

    # dump variables for testing purpose. Switch off after testing.
    if (0)
    {
        $Data::Dumper::Indent   = 1;
        $Data::Dumper::Sortkeys = 1;

        # dump data structures into a text file
        unless ( open( VDUMP, ">$LIFT_config::LIFT_PRJCFG_path/process_SAD_variable_dump.txt" ) )
        {
            S_set_error( "Variable dump file $LIFT_config::LIFT_PRJCFG_path/process_SAD_variable_dump.txt not opened", 1 );
            return 0;
        }
        print VDUMP Data::Dumper->Dump( [ \@squibs, \@pases, \@switches, \@lamps, \@cust, \@asics, \@SpBehaviour, \@parSections ], [qw(squibs pases switches lamps cust asics SpBehaviour parSections)] );
        print VDUMP Data::Dumper->Dump( [ \@lampstates ], [qw(lampstates)] );
        print VDUMP Data::Dumper->Dump( [ \%SQ_index, \%PAS_index, \%SW_index, \%WL_index, \%CUST_index, \%ASIC_index, \%SPB_index, \%parSEC_index ], [qw(SQ_index PAS_index SW_index WL_index CUST_index ASIC_index SPB_index parSEC_index)] );
        print VDUMP Data::Dumper->Dump( [$device_conf_tbl], [qw(device_conf_tbl)] );
        print VDUMP Data::Dumper->Dump( [ \%last_index ],   [qw(last_index)] );
        print VDUMP "END DUMP process_SAD\n";
        close VDUMP;

        # useless comment. if you remove it perlcritic will raise an error on the open statement 13 lines earlier :-(
    }

    return 1;
}

=head2 Copy_ECU_SW_Files

 Copy_ECU_SW_Files( $sadFile ) not exported

Read sad file $sadFile, sort all variables alphabeticaly and write the sorted file to the PD dll folder.

Copy flt file and cns file to the PD dll folder.

=cut

# todo:

sub Copy_ECU_SW_Files {

    my $sadFile = shift;

    my $maxHeaderLineNumber = 100;

    my $fltFile = $sadFile;
    $fltFile =~ s/\.sad$/.flt/i;
    $CNSfile = $sadFile;
    $CNSfile =~ s/\.sad$/.cns/i;

    $sadFile =~ s/\//\\/g;    # replace all slashes with backslahes
    $fltFile =~ s/\//\\/g;    # replace all slashes with backslahes
    $CNSfile =~ s/\//\\/g;    # replace all slashes with backslahes

    unless ( -f $sadFile ) { S_set_error( "$sadFile does not exist", 1 ); return; }
    unless ( -f $fltFile ) { S_set_error( "$fltFile does not exist", 1 ); return; }

    # sad file will not be simply copied, but the sad file variables will be sorted to work around a problem with
    # diagsym 3 and mapped symbols (Defect 27749)
    my $result = open( my $sad_in_fh, "<", $sadFile );
    unless ($result) {
        S_set_error( "Could not open file $sadFile for reading: $!", 1 );
        return 0;
    }
    my @sadFileLines = <$sad_in_fh>;
    close($sad_in_fh);

    # extract sad file header
    my @headerLines;
    my $headerFound = 0;
    foreach my $lineNumber ( 1 .. $maxHeaderLineNumber ) {
        my $line = shift @sadFileLines;
        push( @headerLines, $line );
        if ( $line =~ /END OF HEADER/ ) {
            $headerFound = 1;
            last;
        }
    }
    unless ($headerFound) {
        S_set_error( "Could not find 'END OF HEADER' in $sadFile.", 1 );
        return 0;
    }

    # remove last 2 lines (footer)
    my @lastLines;
    unshift( @lastLines, pop @sadFileLines );
    unshift( @lastLines, pop @sadFileLines );

    # sort the remaining lines alphabetically
    my @sortedSadFileLines = sort @sadFileLines;

    # add header and footer
    unshift( @sortedSadFileLines, @headerLines );
    push( @sortedSadFileLines, @lastLines );

    # write all lines to destination file
    my $sadFileName     = basename($sadFile);
    my $destinationFile = $addpath . '/' . $sadFileName;
    $result = open( my $sad_out_fh, ">", $destinationFile );
    unless ($result) {
        S_set_error( "Could not open file $destinationFile for writing: $!", 1 );
        return 0;
    }

    print $sad_out_fh @sortedSadFileLines;
    close($sad_out_fh);

    S_w2log( 5, " PD_InitDiagnosis: sorted file $sadFile and written to $addpath\n" );

    #copy flt file
    $result = system("xcopy \"$fltFile\" $addpath\ /Y/R");    # copy single file with DOS command xcopy
                                                              #$result = copy( $file, $remote_path );
    if ($result) {
        S_set_error( "could not copy file $fltFile to $addpath", 1 );
        return 0;
    }

    S_w2log( 5, " PD_InitDiagnosis: copied file $fltFile to $addpath\n" );

    #copy cns file
    if ( -f $CNSfile ) {
        S_w2log( 4, " PD_InitDiagnosis: $CNSfile is existing -> will be copied to $addpath\n" );

        $result = system("xcopy \"$CNSfile\" $addpath\ /Y/R");    # copy single file with DOS command xcopy
        if ($result) {
            S_set_error( "could not copy file $CNSfile to $addpath", 1 );
            return 0;
        }

        S_w2log( 5, " PD_InitDiagnosis: copied file $CNSfile to $addpath\n" );
    }

    return 1;
}

=head2 ReadFaultMemory_AB12

    $fault_HoA = ReadFaultMemory_AB12(nType);

nType :: 0, 1, 3, 4

This function reads the fault memory structure based on type passed and returns the fault memory structure

0 - Plant
1 - Primary
3 - Bosch
4 - Disturbance

B<General Fault memory structure>

          $fault_HoA = {
             "fltnum"                           => [@faults],
             "fault_text"                       => [@fault_text],
             "DTC"                              => [@DTC],
             "state"                            => [@states],
             "DisturbanceState"                 => [@distrubanceState],
             "GeneralState"                     => [@generalState],
             "state_txt"                        => [@state_text],
             "DisturbanceState_text"            => [@distrubanceStateText],
             "GeneralState_text"                => [@generalStateText],
             "info"                             => [@addInfo],
             "info_txt"                         => [@addInfo_text],
             #Extra Information from both disturbance & Bosch fault memory
             "EventDebug"                       => [@event],   # Holds event values in DFM and BFM respectively
             "EventDebug_HB"                    => [], # Holds event high byte values in DFM and BFM respectively
             "EventDebug_LB"                    => [], # Holds event low byte values in DFM and BFM respectively
             "OccuranceCounter"                 => [@occ_counter], # Holds Occurance counter in BFM
             "DisturbanceCounter"               => [@dist_counter], # Holds disturbance counter value in DFM
             #Extra Information from only Bosch fault memory
             "QualificationTime"                => [@quali_time],
             "DequalificationTime"              => [@dequali_time],
             "Qualification_poweron_cycle"      => [@quali_poweron],
             "Dequalification_poweron_cycle"    => [@dequali_poweron],
             "ASIC_Temperature"                 => [@asic_temperature],
          };

B<Plant (0) and Primary (1) Fault Memory Structure>

              $fault_HoA = {
             "fltnum"                           => [@faults],
             "fault_text"                       => [@fault_text],
             "DTC"                              => [@DTC],
             "state"                            => [@states],
             "DisturbanceState"                 => [],
             "GeneralState"                     => [],
             "state_txt"                        => [@state_text],
             "DisturbanceState_text"            => [],
             "GeneralState_text"                => [],
             "info"                             => [],
             "info_txt"                         => [],
             "EventDebug"                       => [], # Holds event values in DFM and BFM respectively
             "EventDebug_HB"                    => [], # Holds event high byte values in DFM and BFM respectively
             "EventDebug_LB"                    => [], # Holds event low byte values in DFM and BFM respectively
             "OccuranceCounter"                 => [], # Holds Occurance counter in BFM
             "DisturbanceCounter"               => [], # Holds disturbance counter value in DFM
             #Extra Information from only Bosch fault memory
             "QualificationTime"                => [],
             "DequalificationTime"              => [],
             "Qualification_poweron_cycle"      => [],
             "Dequalification_poweron_cycle"    => [],
          };

B<Bosch (3) Fault memory structure>

          $fault_HoA = {
             "fltnum"                           => [@faults],
             "fault_text"                       => [@fault_text],
             "DTC"                              => [@DTC],
             "state"                            => [@states],
             "DisturbanceState"                 => [],
             "GeneralState"                     => [@generalState],
             "state_txt"                        => [@state_text],
             "DisturbanceState_text"            => [],
             "GeneralState_text"                => [@generalStateText],
             "info"                             => [],
             "info_txt"                         => [],
             "EventDebug"                       => [@event],
             "EventDebug_HB"                    => [@event_hb],
             "EventDebug_LB"                    => [@event_lb],
             "OccuranceCounter"                 => [@occ_counter],
             "DisturbanceCounter"               => [],
             "QualificationTime"                => [@quali_time],
             "DequalificationTime"              => [@dequali_time],
             "Qualification_poweron_cycle"      => [@quali_poweron],
             "Dequalification_poweron_cycle"    => [@dequali_poweron],
			 "ASIC_Temperature"                 => [@asic_temperature],
          };

B<Disturbance (4) Fault memory structure>

          $fault_HoA = {
             "fltnum"                           => [@faults],
             "fault_text"                       => [@fault_text],
             "DTC"                              => [@DTC],
             "state"                            => [],
             "DisturbanceState"                 => [@distrubanceState],
             "GeneralState"                     => [@generalState],
             "state_txt"                        => [],
             "DisturbanceState_text"            => [@distrubanceStateText],
             "GeneralState_text"                => [@generalStateText],
             "info"                             => [],
             "info_txt"                         => [],
             "EventDebug"                       => [@event],
             "EventDebug_HB"                    => [@event_hb],
             "EventDebug_LB"                    => [@event_lb],
             "OccuranceCounter"                 => [],
             "DisturbanceCounter"               => [@dist_counter],
             "QualificationTime"                => [],
             "DequalificationTime"              => [],
             "Qualification_poweron_cycle"      => [],
             "Dequalification_poweron_cycle"    => [],
          };

=cut

sub ReadFaultMemory_AB12
{
    my $nType = shift;
    my ( @faults, @fault_text, @DTC, @states, @addInfo, @addInfo_text, @state_text, $item, $fault_HoA, @table, $text );    #ISO, BFM, DFM
    my ( @generalState, @distrubanceState, @distrubanceStateText, @generalStateText,@event_hb, @event_lb, @event, @occ_counter, @dist_counter ) = ();    #BFM, DFM
    my ( @quali_time, @dequali_time, @quali_poweron, @dequali_poweron , @asic_temperature ) = ();                                                       #BFM
    my ( $faultname, $faultcode );

    #Reading information from low level function
    my ( $ids, $dtcs, $names, $info, $states, $fault_info_aref );                                                                   # Except $fault_info_aref, all values return empty always
    ( $stat, $ids, $dtcs, $names, $states, $info, $fault_info_aref ) = pd_ReadFaultMemory($nType);

    my $fault_type_text = "UNDEFINED";
    if( $nType == 0 )    { $fault_type_text = "PLANT"; }
    if( $nType == 1 )    { $fault_type_text = "PRIMARY"; }
    if( $nType == 3 )    { $fault_type_text = "BOSCH"; }
    if( $nType == 4 )    { $fault_type_text = "DISTURBANCE"; }

    S_w2log( 3, " ReadFaultMemory_AB12: call of pd_ReadFaultMemory($nType - $fault_type_text) returned with status : $stat\n" );
    check_status($stat) || return;  # return immediately in case of error
    
    foreach my $fault_data (@$fault_info_aref)                                                                                      # Parses each index of an array
    {
        my @flt_data_arr = split( /\,/, $fault_data );                                                                              #Splitting the contents of fault_data separated by comma
        my %fault_data_hash;                                                                                                        # This is temp hash, holds details which is available in @flt_data_arr

        #Splitting of info of array into hash
        #This helps in reading the states and state texts for each fault
        foreach my $data (@flt_data_arr)
        {
            my @data_temp = split( /:/, $data );
            $fault_data_hash{ $data_temp[0] } = $data_temp[1];
        }

        # Reading Fault IDs into an array
        push( @faults, $fault_data_hash{'FaultID'} );    #fault id information

        my $nfaultID = $fault_data_hash{'FaultID'};

        #To get Fault Name and Fault code by fault ID
        ( $stat, $faultname, $faultcode ) = pd_GetFLTNameByFLTID($nfaultID);
        S_w2log( 5, " ReadFaultMemory_AB12: call of pd_GetFLTNameByFLTID($nfaultID) returned with status : $stat , $faultname , $faultcode \n" ); # Error at this helper function will fill incorrect values in the table.
        check_status($stat) || return;  # return immediately in case of error


        # Reading and writing DTC number & fault text into respective arrays
        push( @DTC,        $faultcode );                 # dtc information
        push( @fault_text, $faultname );                 # fault text information

        # Replacing 'x' with 1 and '' with 0
        foreach my $xo ( keys %fault_data_hash )
        {
            no warnings;
            if ( $fault_data_hash{$xo} =~ s/^X$/1/ ) { }
            if ( $fault_data_hash{$xo} =~ s/^$/0/ )  { }
        }
               
        S_w2log( 4, " ReadFaultMemory_AB12: Adding Fault '$faultname' ($fault_type_text) to table \n" );
        #Reading information of plant or primary fault memory
        if ( ( $nType == 0 ) || ( $nType == 1 ) )
        {
            my ( $state_temp, $iso_temp );

            #Bit7 Bit6 ... Bit 0
            $iso_temp =
                $fault_data_hash{ $iso_statenames{'Bit7'} }
              . $fault_data_hash{ $iso_statenames{'Bit6'} }
              . $fault_data_hash{ $iso_statenames{'Bit5'} }
              . $fault_data_hash{ $iso_statenames{'Bit4'} }
              . $fault_data_hash{ $iso_statenames{'Bit3'} }
              . $fault_data_hash{ $iso_statenames{'Bit2'} }
              . $fault_data_hash{ $iso_statenames{'Bit1'} }
              . $fault_data_hash{ $iso_statenames{'Bit0'} };

            $iso_temp = '0b' . $iso_temp;
            ### Convert binary to hex
            $iso_temp = sprintf( "0x%x", oct($iso_temp) );

            # Reading ISO data into array
            push( @states, $iso_temp );

            #Retrive values from %bfm_gen_statenames in same order
            my @iso = ();
            foreach my $key ( reverse sort( keys %iso_statenames ) )
            {
                push( @iso, $iso_statenames{$key} );
            }

            # Reading state text which are 'x'/'1' for ISO
            my @iso_temp_res = grep { $fault_data_hash{$_} eq '1' } @iso;
            my $iso_states_str = join( '+', @iso_temp_res );
            push( @state_text, $iso_states_str );

            #HTML Table Info filling
            push( @table,
                      '<TR>' . '<TD>'
                    . $fault_data_hash{'FaultID'} . '</TD>' . '<TD>'
                    . $faultcode . '</TD>' . '<TD>'
                    . $faultname . '</TD>' . '<TD>'
                    . $iso_temp . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit7'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit6'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit5'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit4'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit3'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit2'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit1'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $iso_statenames{'Bit0'} } . '</TD>'
                    . '</TR>' );
            $text .= "$fault_data_hash{'FaultID'};$faultcode;$faultname;$iso_temp;$fault_data_hash{$iso_statenames{'Bit7'}};$fault_data_hash{$iso_statenames{'Bit6'}};$fault_data_hash{ $iso_statenames{'Bit5'}};$fault_data_hash{$iso_statenames{'Bit4'}};$fault_data_hash{$iso_statenames{'Bit3'}};$fault_data_hash{$iso_statenames{'Bit2'}};$fault_data_hash{$iso_statenames{'Bit1'}};$fault_data_hash{ $iso_statenames{'Bit1'}}\n";
        }

        # Reading states of bosch fault type
        elsif ( $nType == 3 )
        {
            my ( $state_temp, $iso_temp, $gen_temp, $iso_state );

            #ISO State details

            #Bit7 Bit6 ... Bit 1 always 0 and Bit 0 varies based on test failed or not - ISO
            if ( $fault_data_hash{ $bfm_iso_statenames{'Bit0_1'} } eq '1' )
            {
                $iso_temp  = '0x01';
                $iso_state = $bfm_iso_statenames{'Bit0_1'};
            }
            else
            {
                #Bit7 Bit6 ... Bit 0
                $iso_temp  = '0x00';
                $iso_state = $bfm_iso_statenames{'Bit0_2'};
            }

            # Reading ISO data and ISO states into array
            push( @states,     $iso_temp );
            push( @state_text, $iso_state );

            #General State details

            #Bit7 Bit6 ... Bit 0 :: Bit 7 always clear so set to 0
            $gen_temp = '0b0'
              . $fault_data_hash{ $bfm_gen_statenames{'Bit6'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit5'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit4'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit3'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit2'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit1'} }
              . $fault_data_hash{ $bfm_gen_statenames{'Bit0'} };

            #Convert binary to hex for gen_temp
            $gen_temp = sprintf( "0x%x", oct($gen_temp) );

            # Reading General data into array
            push( @generalState, $gen_temp );

            #Retrive values from %bfm_gen_statenames in same order
            my @bfm_gen = ();
            foreach my $key ( reverse sort( keys %bfm_gen_statenames ) )
            {
                push( @bfm_gen, $bfm_gen_statenames{$key} );
            }

            # Reading state text which are 'x'/'1' for General
            my @gen_temp_res = grep { $fault_data_hash{$_} eq '1' } @bfm_gen;
            my $gen_states_str = join( '+', @gen_temp_res );
            push( @generalStateText, $gen_states_str );

            # Extra parameters available in Bosch fault memory
            my $event_HB = substr( $fault_data_hash{ $BFM_extra_data[0] }, 2 );
            my $event_LB = substr( $fault_data_hash{ $BFM_extra_data[1] }, 2 );

            my $event_join = '0x' . $event_HB . $event_LB;
            push( @event_hb,     $fault_data_hash{ $BFM_extra_data[0] } );
            push( @event_lb,     $fault_data_hash{ $BFM_extra_data[1] } );
            push( @event, $event_join );

            push( @occ_counter,     $fault_data_hash{ $BFM_extra_data[2] } );
            push( @quali_time,      $fault_data_hash{ $BFM_extra_data[3] } );
            push( @dequali_time,    $fault_data_hash{ $BFM_extra_data[4] } );
            push( @quali_poweron,   $fault_data_hash{ $BFM_extra_data[5] } );
            push( @dequali_poweron, $fault_data_hash{ $BFM_extra_data[6] } );
            push( @asic_temperature, $fault_data_hash{ $BFM_extra_data[7] } );

            #HTML Table Info filling
            push( @table,
                      '<TR>' . '<TD>'
                    . $fault_data_hash{'FaultID'} . '</TD>' . '<TD>'
                    . $faultcode . '</TD>' . '<TD>'
                    . $faultname . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[3] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[4] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[2] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[5] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[6] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[0] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $BFM_extra_data[1] } . '</TD>' . '<TD>'
                    . $gen_temp . '</TD>' . '<TD>' . '0' . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit6'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit5'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit4'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit3'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit2'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit1'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_gen_statenames{'Bit0'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{$BFM_extra_data[7]} . '</TD>' . '<TD>'
                    . $iso_temp . '</TD>' . '<TD>' . '0' . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_iso_statenames{'Bit0_1'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $bfm_iso_statenames{'Bit0_2'} } . '</TD>' 
                    . '</TR>' );
            $text .= "$fault_data_hash{'FaultID'};$faultcode;$faultname;$fault_data_hash{ $BFM_extra_data[3] };$fault_data_hash{ $BFM_extra_data[4] };$fault_data_hash{ $BFM_extra_data[2] };$fault_data_hash{ $BFM_extra_data[5] };$fault_data_hash{ $BFM_extra_data[6] };$fault_data_hash{ $BFM_extra_data[0] };$fault_data_hash{ $BFM_extra_data[1] };$gen_temp;0;$fault_data_hash{ $bfm_gen_statenames{'Bit6'} };$fault_data_hash{ $bfm_gen_statenames{'Bit5'} };$fault_data_hash{ $bfm_gen_statenames{'Bit4'} };$fault_data_hash{ $bfm_gen_statenames{'Bit3'} };$fault_data_hash{ $bfm_gen_statenames{'Bit2'} };$fault_data_hash{ $bfm_gen_statenames{'Bit1'} };$fault_data_hash{ $bfm_gen_statenames{'Bit0'} };$fault_data_hash{$BFM_extra_data[7] };$iso_temp;0;$fault_data_hash{ $bfm_iso_statenames{'Bit0_1'}};$fault_data_hash{ $bfm_iso_statenames{'Bit0_2'} } \n";
        }

        #Reading states of disturbance fault type
        elsif ( $nType == 4 )
        {
            my ( $state, $dist_temp, $gen_temp );

            #General State details

            #Bit7 Bit6 ... Bit 0 :: Bit 7 always clear so set to 0
            $gen_temp = '0b0'
              . $fault_data_hash{ $dfm_gen_statenames{'Bit6'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit5'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit4'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit3'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit2'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit1'} }
              . $fault_data_hash{ $dfm_gen_statenames{'Bit0'} };

            #Convert binary to hex for gen_temp
            $gen_temp = sprintf( "0x%x", oct($gen_temp) );

            # Reading General data into array
            push( @generalState, $gen_temp );

            #Disturbance state details

            #Bit7 Bit6 ... Bit0 :: Bit2 to Bit7 are not used so set to 0
            $dist_temp = '0b000000' . $fault_data_hash{ $dfm_dist_statenames{'Bit1'} } . $fault_data_hash{ $dfm_dist_statenames{'Bit0'} };

            #Convert binary to hex for dist_temp
            $dist_temp = sprintf( "0x%x", oct($dist_temp) );

            # Reading Disturbance data into array
            push( @distrubanceState, $dist_temp );

            #Retrive values from %dfm_dist_statenames in same order
            my @dfm_dist = ();
            foreach my $key ( reverse sort( keys %dfm_dist_statenames ) )
            {
                push( @dfm_dist, $dfm_dist_statenames{$key} );
            }

            #Retrive values from %dfm_gen_statenames in same order
            my @dfm_gen = ();
            foreach my $key ( reverse sort( keys %dfm_gen_statenames ) )
            {
                push( @dfm_gen, $dfm_gen_statenames{$key} );
            }

            # Reading state text which are 'x'/'1' for General and Disturbance
            my @dist_temp_res = grep { $fault_data_hash{$_} eq '1' } @dfm_dist;
            my @gen_temp_res  = grep { $fault_data_hash{$_} eq '1' } @dfm_gen;

            my $dist_states_str = join( '+', @dist_temp_res );
            my $gen_states_str  = join( '+', @gen_temp_res );

            push( @distrubanceStateText, $dist_states_str );
            push( @generalStateText,     $gen_states_str );

            # Extra parameters available in fault memory
            my $event_HB = substr( $fault_data_hash{ $DFM_extra_data[0] }, 2 );
            my $event_LB = substr( $fault_data_hash{ $DFM_extra_data[1] }, 2 );

            my $event_join = '0x' . $event_HB . $event_LB;
            push( @event, $event_join );

            push( @event_hb,     $fault_data_hash{ $BFM_extra_data[0] } );
            push( @event_lb,     $fault_data_hash{ $BFM_extra_data[1] } );
            push( @dist_counter, $fault_data_hash{ $DFM_extra_data[2] } );

            #HTML Table Info filling
            push( @table,
                      '<TR>' . '<TD>'
                    . $fault_data_hash{'FaultID'} . '</TD>' . '<TD>'
                    . $faultcode . '</TD>' . '<TD>'
                    . $faultname . '</TD>' . '<TD>'
                    . $dist_temp . '</TD>' . '<TD>' . '0' . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_dist_statenames{'Bit1'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_dist_statenames{'Bit0'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $DFM_extra_data[0] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $DFM_extra_data[1] } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $DFM_extra_data[2] } . '</TD>' . '<TD>'
                    . $gen_temp . '</TD>' . '<TD>' . '0' . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit6'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit5'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit4'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit3'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit2'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit1'} } . '</TD>' . '<TD>'
                    . $fault_data_hash{ $dfm_gen_statenames{'Bit0'} } . '</TD>'
                    . '</TR>' );
            $text .= "$fault_data_hash{'FaultID'};$faultcode;$faultname;$dist_temp;0;$fault_data_hash{ $dfm_dist_statenames{'Bit1'} };$fault_data_hash{ $dfm_dist_statenames{'Bit0'} };$fault_data_hash{ $DFM_extra_data[0] };$fault_data_hash{ $DFM_extra_data[1] };$fault_data_hash{ $DFM_extra_data[2] } ;$gen_temp;0,$fault_data_hash{ $dfm_gen_statenames{'Bit5'} };$fault_data_hash{ $dfm_gen_statenames{'Bit4'} };$fault_data_hash{ $dfm_gen_statenames{'Bit3'} };$fault_data_hash{ $dfm_gen_statenames{'Bit2'} };$fault_data_hash{ $dfm_gen_statenames{'Bit1'} };$fault_data_hash{ $dfm_gen_statenames{'Bit0'} }\n";

        }
    }

    #HTML Table header
    if ( ( $nType == 0 ) || ( $nType == 1 ) )
    {
        #
        #  TODO : table function must be used normally
        #
        S_w2log( 4, "printing fault table of AB Generation $ABgeneration:  Plant/Primary  Fault Memory\n" );
        push(
              @TC_HTML_TEXT,
              join( '',
                    '<div class="w2rep ',
                    $module_name,
                    '"><TABLE class="tablesorter">',
                    '<TR>'
                      . '<TH>ID</TH>'
                      . '<TH>DTC</TH>'
                      . '<TH>faultname</TH>'
                      . '<TH>status</TH>'
                      . '<TH>Warning lamp indicator</TH>'
                      . '<TH>Test not completed this operation cycle</TH>'
                      . '<TH>Test failed since last clear</TH>'
                      . '<TH>Test not completed since last clear</TH>'
                      . '<TH>Confirmed DTC (Stored)</TH>'
                      . '<TH>Pending</TH>'
                      . '<TH>Test failed this operation cycle(Latched)</TH>'
                      . '<TH>Test failed (Filtered)</TH>',
                    @table,
                    '</TABLE></div>',
                    "\n" )
        );

        my $text_header = "ID; DTC; faultname; status;Warning lamp indicator;Test not completed this operation cycle;Test failed since last clear;Test not completed since last clear;Confirmed DTC(Stored) ;Pending;Test failed this operation cycle(Latched);Test failed (Filtered)\n";

        $text = $text_header . $text;

        print $text unless $main::opt_silent;
        print LIFT_general::LOG $text;
    }
    elsif ( $nType == 3 )
    {
        #
        #  TODO : table function must be used normally
        #
        S_w2log( 4, "printing fault table of AB Generation $ABgeneration:  Bosch Fault Memory\n" );
        push(
              @TC_HTML_TEXT,
              join( '',
                    '<div class="w2rep ',
                    $module_name,
                    '"><TABLE class="tablesorter">',
                    '<TR>'
                      . '<TH>ID</TH>'
                      . '<TH>DTC</TH>'
                      . '<TH>faultname</TH>'
                      . '<TH>Qualification Time(sec)</TH>'
                      . '<TH>Dequalification Time(sec)</TH>'
                      .'<TH>Occurance Counter</TH>'
                      .'<TH>Qualification PowerOn Cycle</TH>'
                      .'<TH>Dequalification PowerOn Cycle</TH>'
                      .'<TH>EventDebug Data HB(Hex)</TH>'
                      .'<TH>EventDebug Data LB(Hex)</TH>'
                      . '<TH>General Status Byte</TH>'
                      . '<TH>Bit 7</TH>'
                      . '<TH>Squib fired in the current POC</TH>'
                      . '<TH>DIS_ALP_Low_side_power_lines_disabled</TH>'
                      . '<TH>Algoactive</TH>'
                      . '<TH>VUpOutOfRange_present</TH>'
                      . '<TH>VBatOutOfRange_present</TH>'
                      . '<TH>InitMode active</TH>'
                      . '<TH>IdleMode active</TH>'
                      . '<TH>ASIC Temperature(�C)</TH>'
                      . '<TH>status Byte</TH>'
                      . '<TH>Bits 7 - 1</TH>'
                      . '<TH>Bit0 - Test Failed</TH>'
                      . '<TH>Bit0 - Test not Failed</TH>',
                    @table,
                    '</TABLE></div>',
                    "\n" )
        );

        my $text_header = "ID; DTC; faultname;Qualification Time(sec);Dequalification Time(sec);Occurance Counter;Qualification PowerOn Cycle;Dequalification PowerOn Cycle;EventDebug Data HB(Hex);EventDebug Data LB(Hex); General status(byte);Bit 7;Squib fired in the current POC;DIS_ALP_Low_side_power_lines_disabled;Algoactiv;VUpOutOfRange_present;VBatOutOfRange_present;InitMode active;IdleMode active;ASIC Temperature; Fault Status(byte);Bits 7 - 1;Bit0 - Test Failed;Bit0 - Test not Failed\n";

        $text = $text_header . $text;

        print $text unless $main::opt_silent;
        print LIFT_general::LOG $text;
    }
    elsif ( $nType == 4 )
    {
        #
        #  TODO : table function must be used normally
        #
        S_w2log( 4, "printing fault table of AB Generation $ABgeneration:  Disturbance  Fault Memory\n" );
        push(
              @TC_HTML_TEXT,
              join( '',
                    '<div class="w2rep ',
                    $module_name,
                    '"><TABLE class="tablesorter">',
                    '<TR>'
                      . '<TH>ID</TH>'
                      . '<TH>DTC</TH>'
                      . '<TH>faultname</TH>'
                      . '<TH>Disturbance status</TH>'
                      . '<TH>Bits 7 - 2</TH>'
                      . '<TH>TestDisturbed</TH>'
                      . '<TH>TestCurrent</TH>'
                      . '<TH>EventDebug Data HB(Hex)</TH>'
                      . '<TH>EventDebug Data LB(Hex)</TH>'
                      . '<TH>DisturbanceCounter</TH>'
                      . '<TH>General Status</TH>'
                      . '<TH>Bit 7</TH>'
                      . '<TH>Squib fired in the current POC</TH>'
                      . '<TH>DIS_ALP (Low side power lines) disabled</TH>'
                      . '<TH>Algo active</TH>'
                      . '<TH>VUp OutOfRange present</TH>'
                      . '<TH>VBat OutOfRange present</TH>'
                      . '<TH>InitMode active</TH>'
                      . '<TH>IdleMode active</TH>',
                    @table,
                    '</TABLE></div>',
                    "\n" )
        );

        my $text_header = "ID; DTC; faultname;Disturbance Status; Bits 7 - 2;TestDisturbed; TestCurrent;EventDebug Data HB(Hex);EventDebug Data LB(Hex);DisturbanceCounter;General status;Bit 7;Squib fired in the current POC;DIS_ALP (Low side power lines) disabled;Algo active;VUp OutOfRange present;VBat OutOfRange present;InitMode active;IdleMode active \n";

        $text = $text_header . $text;

        print $text unless $main::opt_silent;
        print LIFT_general::LOG $text;
    }

    $fault_HoA = {
        "fltnum"                => [@faults],
        "fault_text"            => [@fault_text],
        "DTC"                   => [@DTC],
        "state"                 => [@states],
        "DisturbanceState"      => [@distrubanceState],
        "GeneralState"          => [@generalState],
        "state_txt"             => [@state_text],
        "DisturbanceState_text" => [@distrubanceStateText],
        "GeneralState_text"     => [@generalStateText],
        "info"                  => [@addInfo],
        "info_txt"              => [@addInfo_text],

        #Extra Information from both disturbance & Bosch fault memory
        "EventDebug_HB"                 => [@event_hb],          # Holds event high byte values in DFM and BFM respectively
        "EventDebug_LB"                 => [@event_lb],          # Holds event low byte values in DFM and BFM respectively
        "EventDebug"                    => [@event],             # Holds event values in DFM and BFM respectively
        "OccuranceCounter"              => [@occ_counter],       # Holds Occurance counter in BFM
        "DisturbanceCounter"            => [@dist_counter],      # Holds disturbance counter value in DFM
                                                                 #Extra Information from only Bosch fault memory
        "QualificationTime"             => [@quali_time],
        "DequalificationTime"           => [@dequali_time],
        "Qualification_poweron_cycle"   => [@quali_poweron],
        "Dequalification_poweron_cycle" => [@dequali_poweron],
        "ASIC_Temperature"              => [@asic_temperature],
    };

    return ($fault_HoA);
}

=head2 GetBitValue

    $returnValue = GetBitValue( $memory_name, $bitIndex);   
    

This API is used to get the bit status of a variable using the memory name and bit index passed as an argument .

B<Arguments:>

=over

=item $memory_name 

It is the variable name for which the bit status has to be read according to the bitindex passed to the API .

=item $bitIndex 

It is the index position passed as an argument at which the bit status has to be read.

=back

B<Return Value:>

=over

=item $returnValue 

It returns the status of a bit(0/1).

=back

B<Examples:>

    $returnValue = GetBitValue( S_PDMProgVarTbl1_XXR.V_ProdMode_U16X, 1);

=cut

sub GetBitValue

{
	my @args = @_;
	return 0 unless S_checkFunctionArguments( 'GetBitValue($memory_name, $bit_description)', @args );

	my $memory_name     = shift @args;
	my $bitIndex        = shift @args;    #Bit description can be a Bit comment or a Bit index
	my $no_of_bytes;
	my $bytevalue_aref;
	my $bitvalue;

	( $no_of_bytes, $bytevalue_aref ) = pd_ReadName($memory_name);

	unless ($bytevalue_aref) {
		S_set_error( "GetBitValue : Failed to read the byte value for memory $memory_name", 114 );
		return;
	}
	
	if ( $no_of_bytes > 0 ) {
		        if ( ($bitIndex >= ( $no_of_bytes * 8 )) || $bitIndex < 0) {
				S_set_error( "GetBitValue : The maximum no of byte the variable $memory_name can hold is $no_of_bytes, therefore the Bit index should be in the range 0 - (($no_of_bytes*8)-1)", 114 );
				return;
			}

		#If the no of bytes obtained are multiple then combine the bytes and find the bit value in the respective Bit position   
	    $bytevalue_aref = "0x".(sprintf "%02x" x @$bytevalue_aref, @$bytevalue_aref ); # contains continous data string with "0x" removed from each one of them and finally concatenated with "0x"
		$bitvalue = ( Math::BigInt->new($bytevalue_aref)) & ( 1 << $bitIndex );
		
		if ($bitvalue) {
			$bitvalue = 1;
		}
		else{
		    $bitvalue = 0;
		}
	}
	S_w2log( 4, "GetBitValue ($no_of_bytes) : value of '$memory_name' read for Bit $bitIndex is $bitvalue \n" );
	return $bitvalue;
}

sub SetVariablesForUnitTest
{

    my @args = @_;
    return {} unless S_checkFunctionArguments( 'SetVariablesForUnitTest( $initialized, $generation, $fastDiag )', @args );

    my $initialized = shift @args;
    my $generation  = shift @args;
    my $fastDiag    = shift @args;

    $PD_initialized = $initialized;
    $ABgeneration   = $generation;
    $FastDiagActive = $fastDiag;

    return 1;
}


=head2 Get_Fast_Diag_data_from_CANTrace

    $returnValue_href = Get_Fast_Diag_data_from_CANTrace($trace_file_path, $FastDiagVarAdd_aref, $FastDiagType_aref[, $time_unit]);       

This function is used to fetch the fast diagnosis data from the can trace and store it in a hash reference containing the realtime data(time and fast diag data) from trace and the variable information.

B<Arguments:>

=over

=item $trace_file_path

It is the path of the CAN trace file containing the fast diagnosis data

=item $FastDiagVarAdd_aref 

Array reference with the label names for which fast diagnosis data will be read.

=item $FastDiagType_aref 

Array reference with the data types (U8,U16,U32,S8,S10,S16,S32,U64,S64) of the variables/address given in the $FastDiagVarAdd_aref. Must have the same length as $FastDiagVarAdd_aref

=item (optional)$time_unit 

If the Time unit is 'MILLISEC' then the FastDiag data will be obtained with MilliSeconds Timebase, otherwise the FastDiag data returned will be in Seconds Timebase. 

=back

B<Return Value:>

=over

=item $returnValue_href 

Success : returns the structure created from fast diagnosis CAN trace file

Error return : undef

=back

B<Examples:>

    $returnValue_href = Get_Fast_Diag_data_from_CANTrace($trace_file_path, ['rb_sfra_FastRAMTstFailed_bo', 'rb_tim_EcuOnTimeDataEe_st(0)'], ['U8', 'U8'], 'MILLISEC');
                                                                   OR
    $returnValue_href = Get_Fast_Diag_data_from_CANTrace($trace_file_path, ['rb_sfra_FastRAMTstFailed_bo', 'rb_tim_EcuOnTimeDataEe_st(0)'], ['U8', 'U8']);

=cut

sub Get_Fast_Diag_data_from_CANTrace {

	my @args = @_;

	return unless S_checkFunctionArguments( 'Get_Fast_Diag_data_from_CANTrace( $trace_file_path, $FastDiagVar_aref, $FastDiagType_aref[, $time_unit] )', @args );

	# the type of the variable is asc then the fast diagnosis data and timestamps are extracted from the .asc file
	#STEP Get the tracefile(.asc) path which contains the fast diagnosis data
	#STEP Get the fast diag variable names
	#STEP Get the fast diag variable types

	my $trace_file_path   = shift @args;
	my $fastDiagVar_aref  = shift @args;
	my $fastDiagType_aref = shift @args;
	my $time_unit         = shift @args;

	my ( $resolution, $nbr_of_can_ids, $nbr_of_cells_to_read, $nbr_of_frames, $endianess );
	my ( $fast_Diag_data_time_href, $raw_fast_diag_data_href, $fast_diag_data_href );

	# STEP Fetch the fast diagnosis data from the can trace file
	# CALL FetchFastDiagData
	( $raw_fast_diag_data_href, $nbr_of_cells_to_read, $nbr_of_frames, $resolution, $nbr_of_can_ids, $endianess ) = FetchFastDiagData($trace_file_path);

	unless ( defined $nbr_of_cells_to_read && defined $nbr_of_frames && defined $resolution && defined $nbr_of_can_ids && defined $raw_fast_diag_data_href && defined $endianess ) { return; }

	# IF the fast Diagnosis response is fetched successfully
	# IF-YES-START
	# STEP Use the hash reference containing data and the timestamp and create a hash reference containing the timestamps as the key and the fast diag data info and variable info
	# IF-YES-END

	# IF-NO-START
	# STEP The trace doesnt contain fast diagnosis data
	# STEP fast diagnosis data = undef
	# IF-NO-END
	# STEP return fast diagnosis data

	my ( $counter_chk, $nbr_of_cells, $total_nbr_bytes_to_read, $temp_ts );
	my $str_resp             = " ";
	my $index                = 1;
	my $frame_chk            = 0;
	my $t_n_b_r              = 0;
	my $no_of_frames_missing = 0;
	$total_nbr_bytes_to_read = ( 2 * $nbr_of_cells_to_read * $nbr_of_frames ) / ( $resolution * $nbr_of_can_ids );    # Total nbr of bytes should be obtained in one dataset of FD response
	my $temp_fr_val = 0;
	$nbr_of_cells = 0;
	my $frame_missing = 0;

	foreach my $time ( sort { $a <=> $b } keys %$raw_fast_diag_data_href ) {
		my $data_arr = $raw_fast_diag_data_href->{$time};                                                             # Fetch each frame

		# Check whether First frame is presnt in the Dataset ?
		# First Byte of Frame gives : 1) COUNTER VALUE = first 6 bits and 2)FRAME VALUE = last 2 bits
		# from the FRAME VALUE - check if its first frame
		if ( ( ( hex( $$data_arr[0] ) & 0xf0 ) >> 6 ) == 0 ) {
			$counter_chk = ( hex( $$data_arr[0] ) & 0x3f );    # first 6 bits from the right gives the value of the counter
			$t_n_b_r     = 0;                                                                       # track : total nbr of bytes to read.			

		}

		# next if any frame is missed
		unless ( defined $counter_chk ) {
			$no_of_frames_missing++;
			next;
		}

		#
		# counter check - > first six bits (from Right) should be same
		#   -> Error if Counter value is different
		#  04  => 00 000100
		#  44  => 01 000100
		#  84  => 10 000100

		#
		# Frame check - > last two bits ex '00, 01, 10' is the frame Nbr like [0, 1, 2 -> index 0 based] so it means 1st, 2nd and 3rd frame
		#     -> Error if and 1st , 2nd or 3rd frame is missing
		#  04  => 00 000100
		#  44  => 01 000100
		#  84  => 10 000100

		#
		# COUNTER CHECK & FRAME CHECK ?
		#
		if ( $counter_chk != ( hex( $$data_arr[0] ) & 0x3f ) || ($frame_chk != ( hex( $$data_arr[0] ) & 0xf0 ) >> 6 && $temp_fr_val > 0) )
		{    # check whether the frame is from the same dataset of response or a frame is missing and check whether the frame is recieved from the expected can id
		    $temp_fr_val = 0;                                                                      # track : 0 .. last frame in the data set
			$no_of_frames_missing++;
			$frame_missing = 1;
		}

		# Fetch the next frame if the total no of bytes to be read becomes less than equal to zero
		#Ex : 5.764612 2  651             Rx   d 8 04 02 C8 8E 02 DB 3C 04  Length = 228000 BitCount = 118 ID = 1617
		#      5.764845 2  652             Rx   d 8 44 C8 8E 02 DB 3C FF FF  Length = 224000 BitCount = 116 ID = 1618
		#       5.765089 2  653             Rx   d 8 84 FF FF FF FF FF FF FF  Length = 236000 BitCount = 122 ID = 1619
		if ( $temp_fr_val > 0 && $t_n_b_r <= 0 && $frame_missing == 0 ) {

			$temp_fr_val = 0;
			$frame_chk   = 0;
			next;

		}

		if ( $frame_missing == 1 ) {
			if ( ( ( hex( $$data_arr[0] ) & 0xf0 ) >> 6 ) != 0 ) {
				undef $counter_chk;
				next;
			}

		}

		# Re intialize the values when the parsing of next set of response frame starts
		if ( $t_n_b_r == 0 ) {
			$temp_ts       = $time;
			$temp_fr_val   = $nbr_of_frames;
			$frame_chk     = 0;
			$t_n_b_r       = $total_nbr_bytes_to_read;
			$frame_missing = 0;
			$str_resp      = "";
			$nbr_of_cells  = 0;
		}

		$index = 1;

		while ( $t_n_b_r > 0 ) {

			# Concatenating the bytes according to the nbr of bytes requested for a variable
			$str_resp = $str_resp . " " . $$data_arr[$index] . " ";
			$str_resp =~ s/^\s+//;
			$str_resp =~ s/\s+$//;

			$nbr_of_cells++;

			if ( $nbr_of_cells == $nbr_of_cells_to_read ) {

				$fast_Diag_data_time_href->{$temp_ts} = $str_resp;
				$t_n_b_r = $t_n_b_r - $nbr_of_cells_to_read;    # reducing the total nbr of bytes in a response dataset by the actual nbr of bytes to read
				if ( $t_n_b_r > 0 ) {
					$temp_ts = $temp_ts + ( $resolution / 1000 );    # calculate the time for the data which are received in the same frame or is continued from the previous frame
				}
				$nbr_of_cells = 0;
				$str_resp     = " ";
			}
			$index++;
			if ( $index == 8 ) {
				last;                                                # Exit the loop when the 8 bytes of data are read( A CAN frame contains 8 byte of data)
			}
		}
		$temp_fr_val--;

		$frame_chk++;

	}

	if($no_of_frames_missing){
	    S_w2log( 4, " Get_Fast_Diag_data_from_CANTrace: Frames are missing \n" );
	}

	my (@nbr_of_bytes);

	# Fetch the no of bytes to be read for each variable
	foreach my $typ (@$fastDiagType_aref) {

		unless ( $typ =~ /^U8|S8|S10|U16|S16|U32|S32|U64|S64$/i ) {
			S_set_error( " wrong type at $typ: @$fastDiagType_aref != U8,S8,S10,U16,S16,U32,S32,U64,S64", 114 );
			return;
		}
		$typ =~ m/^[us](\d\d?)$/i;
		my $bits = $1;
		$bits = 16 if ( $bits == 10 );    # treat S10 as 2 byte value
		push( @nbr_of_bytes, ( $bits / 8 ) );
	}

	unless ( ( sum(@nbr_of_bytes) == $nbr_of_cells_to_read ) && ( scalar(@$fastDiagVar_aref) == scalar(@$fastDiagType_aref) ) ) {
		S_set_error( "The no of cells to read obtained from the trace does'nt match with the no of cell passed as an input or the nbr of types is not equal to the nbr of labels names", 109 );
		return;
	}

	my $byte;

	# store the timestamp and data in a hash reference along with the variable info
	foreach my $time ( sort { $a <=> $b } keys %$fast_Diag_data_time_href ) {

		my @data_array = split( " ", $fast_Diag_data_time_href->{$time} );

		# 1000 is multipied to convert the time into milli seconds from seconds
		$time = $time * 1000 if ( defined $time_unit && $time_unit =~ /MILLISEC/i );

		$byte = 0;

		foreach my $var (@$fastDiagVar_aref) {
		    my $dataValue = " ";
			$dataValue = $dataValue . shift @data_array for 1 .. $nbr_of_bytes[$byte];

			$dataValue =~ s/^\s+//;    #remove leading spaces
			$dataValue =~ s/\s+$//;

			#If Endianess is 0 then Little Endian format should be used otherwise Big Endian Format should be followed
			$dataValue = join( '', reverse split( /(..)/, $dataValue ) ) if ( $endianess == 0 );
			
			$dataValue = "0x" . $dataValue;
			
			if( $nbr_of_bytes[$byte] <= 4 ) {
    			$$fast_diag_data_href{$time}{$var} = hex( $dataValue );
			}
			else{
    			$$fast_diag_data_href{$time}{$var} = Math::BigFloat->from_hex( $dataValue );
			}

			$byte++;
		}

	}

	return $fast_diag_data_href;
}

=head2 FetchFastDiagData

    ( $raw_fast_diag_data_href, $nbr_of_cells_to_read, $nbr_of_frames, $resolution, $nbr_of_can_ids, $endianess ) = FetchFastDiagData($trace_file_path);   
    

This function is used to fetch the fast diagnosis data from the can trace and store it in a hash reference containing the realtime data(time and fast diag data) from trace

B<Arguments:>

=over

=item $trace_file_path

It is the path of the CAN trace file containing the fast diagnosis data

=back

B<Return Value:>

=over

=item $returnValue_href 

Success : returns the structure created from fast diagnosis CAN trace file

Error return : undef

=item $nbr_of_cells_to_read 

Success : Nbr of bytes to read

Error return : undef

=item $nbr_of_frames 

Success : Nbr of frames

Error return : undef

=item $resolution 

Success : Resolution with which the FastDiag data is obtained

Error return : undef

=item $nbr_of_can_ids 

Success : Nbr of CAN IDs

Error return : undef

=item $endianess 

Success : Endianess(Little/Big Endian format)

Error return : undef

=back

B<Examples:>

    ( $raw_fast_diag_data_href, $nbr_of_cells_to_read, $nbr_of_frames, $resolution, $nbr_of_can_ids, $endianess ) = FetchFastDiagData($trace_file_path);

=cut

sub FetchFastDiagData {

	my @args = @_;

	return ( undef, undef, undef, undef, undef, undef) unless S_checkFunctionArguments( 'FetchFastDiagData( $trace_file_path)', @args );

	my $trace_file_path = shift @args;

	my ( $time_stamp_sec, $can_bus_nbr, $found_can_id, $request_byte, $line, $resolution, $nbr_of_can_ids, $nbr_of_frames, $fast_request_byte, $nbr_of_cells_to_read, $next_poc, $endianess );
	my (@response_byte);
	my ($raw_fast_diag_data_href);
	my $can_id_arr_ref;

	use constant FD_STARTED          => '90';
	use constant FD_STOPPED          => '09';
	use constant POC_RESPONSE_BYTE_1 => 'D0';
	use constant POC_RESPONSE_BYTE_2 => 'D2';

	# CALL Fetch_CAN_IDS
	$can_id_arr_ref = Fetch_CAN_IDS();

	unless ($can_id_arr_ref) { return ( undef, undef, undef, undef, undef, undef); }

	# STEP read the trace file which contains fast diag data
	my $trace_FH = new FileHandle;
	unless ( $trace_FH->open($trace_file_path) ) { S_set_error( " Couldnt open CAN Trace $trace_file_path ", 1 ); return ( undef, undef, undef, undef, undef, undef); }

	# STEP Parse Entire trace file and fetch the FastDiagnosis data(in the form of frames) and the timestamp using the CAN bus no and CAN id
	$fast_request_byte = '';
	while ( $line = <$trace_FH> ) {

		# STEP Fetch the CAN bus no used for PD from the trace
		# IF the frames contain the fast Diagnosis request
		#   IF-YES-START
		#   STEP The frames contain the fast Diagnosis request then fetch the fast diagnosis response and the timestamp till stop fast diagnosis is called
		#   STEP From the extracted frames get the data and timestamps according to the no of cells to be read(fetch from the request frame) and store it in an hash reference

		## try to match:
		##      0.0171 1  Bremse_1   Rx   d 8 00 18 00 00 FE FE 00 18
		if (
			$line =~ /^
          \s*                # leading spaces
          (\d+\.\d+)         # timestamp
          \s+                # spaces
          (\d+)              # bus nbr
          \s+                # spaces
          ($$can_id_arr_ref[0] | $$can_id_arr_ref[1] | $$can_id_arr_ref[2] | $$can_id_arr_ref[3] | $$can_id_arr_ref[4]) # can id
          x?
          \s+                # spaces
          [TxRq]+            # match Rx or Tx or TxRq
          \s+                # spaces
          d
          \s+                # spaces
          \d+                # DLC
          \s+                # spaces
          ([\da-fA-F]+)      # have the information about realtime counter and frames
          \s+
          ([\da-fA-F]+)      # request byte or response1 data 
          \s+
          ([\da-fA-F]+)      # no of can ids used or response2 data
          \s+
          ([\da-fA-F]+)      # no of cells to be read or response3 data 
          \s+
          ([\da-fA-F]+)      # response4 data
          \s+
          ([\da-fA-F]+)      # response5 data
          \s+
          ([\da-fA-F]+)      # response6 data
          \s+
          ([\da-fA-F]+)      # response7 data
          (.+)$              # all Data and aditional info unil end of line  (e.g. 2A 34 42 FF 20 00  Length = 192000 BitCount = 100)
          /ix
		  )
		{
			$time_stamp_sec = $1;
			$can_bus_nbr    = $2;
			$found_can_id   = $3;    # can id used for fast diagnosis

			my ( $login_block_len, $login_block_title, $login_response_key );
			$login_block_len    = $4;
			$login_block_title  = $5;
			$login_response_key = $6;

			# STEP Find the Endianness from login response
			if ( $login_block_len eq '36' && $login_block_title eq '40' && $login_response_key eq 'A2' ) {

				$endianess = ( hex($7) & 0xf0 ) >> 7;
			}

			# STEP Find first CAN ID for start FD
			if ( $found_can_id == $$can_id_arr_ref[0] ) {
				$request_byte = $5;    # indicator for FD start or stop
			}

			#
			# STEP Get required info to fetch fast diagnosis data ex Nbr of Frames & resolution
			#
			my ( $poc_response_byte1, $poc_response_byte2 );

			if ( defined $endianess && $found_can_id == $$can_id_arr_ref[0] && $request_byte eq FD_STARTED ) {
				S_w2log( 5, "Fast Diagnosis has started at $time_stamp_sec\n" );

				$nbr_of_cells_to_read = hex($7);
				S_w2log( 5, "The nbr of cells to read are $nbr_of_cells_to_read\n" );

				$nbr_of_can_ids = ( hex($6) & 0xf0 ) >> 4;    # Bit 4-7 determines the no of can ids for response
				S_w2log( 5, "The nbr of can ids are $nbr_of_can_ids\n" );

				$fast_request_byte = FD_STARTED;
				$next_poc = S_calculate_value_by_mask_NOHTML( hex($6), "0000--00" );    # Bit 2-3 determines the next power on cycle

				S_w2rep("The response will be obtained in next power on cycle\n") if ( $next_poc == 4 );

				if ( $nbr_of_cells_to_read > 0 and $nbr_of_cells_to_read < 29 ) {
					$nbr_of_can_ids = 1 if ( $nbr_of_cells_to_read == 1 );
					$nbr_of_can_ids = 2 if ( ( $nbr_of_cells_to_read == 2 || $nbr_of_cells_to_read == 3 ) && $nbr_of_can_ids > 2 );
					$nbr_of_can_ids = 3 if ( ( $nbr_of_cells_to_read == 4 || $nbr_of_cells_to_read == 5 ) && $nbr_of_can_ids > 3 );

					# Fetch the fastDiag information(no of frames and resolution) from a hash reference
					$nbr_of_frames = $fast_diag_info_href->{'FAST_DIAG_INFO'}{$nbr_of_can_ids}{$nbr_of_cells_to_read}{'Nbr_frames'};
					$resolution    = $fast_diag_info_href->{'FAST_DIAG_INFO'}{$nbr_of_can_ids}{$nbr_of_cells_to_read}{'Resolution'};

					S_w2log( 5, "The Fast Diagnosis Data will have $nbr_of_frames no_of_frames, $resolution resolution, $nbr_of_cells_to_read no_of_cells_to_read and $nbr_of_can_ids no_of_can_ids\n" );

				}
			}

			#
			# STEP If command for stopping FD found then come out of the loop or else continue
			#
			elsif ( defined $endianess && $found_can_id == $$can_id_arr_ref[0] && $request_byte eq FD_STOPPED && $fast_request_byte eq FD_STARTED ) { S_w2log( "Fast Diagnosis has stopped\n", 5 ); last; }

			#
			# COMMENT-START
			#  Store Fast diagnosis Data & time stamp in hash for later evaluation
			# COMMENT-END
			#
			if ( $fast_request_byte eq FD_STARTED && $request_byte ne FD_STOPPED && ( $found_can_id == $$can_id_arr_ref[1] || $found_can_id == $$can_id_arr_ref[2] || $found_can_id == $$can_id_arr_ref[3] || $found_can_id eq $$can_id_arr_ref[4] ) ) {

				$poc_response_byte1 = $5;
				$poc_response_byte2 = $6;

				if ( $next_poc == 4 && $poc_response_byte1 eq POC_RESPONSE_BYTE_1 && $poc_response_byte2 eq POC_RESPONSE_BYTE_2 ) {
					S_w2log( 5, "Positive response is obtained for next power on cycle request at $time_stamp_sec\n" );
					next;
				}

				# response Frame( byte $4 to $11)
				push( @response_byte, $4 );
				push( @response_byte, $5 );
				push( @response_byte, $6 );
				push( @response_byte, $7 );
				push( @response_byte, $8 );
				push( @response_byte, $9 );
				push( @response_byte, $10 );
				push( @response_byte, $11 );

				$raw_fast_diag_data_href->{$time_stamp_sec} = [@response_byte];
				undef @response_byte;
			}

		}

		# IF-YES-END
	}

	$trace_FH->close;

	unless ( defined $endianess ) {

		S_set_error( "Could not find the positive response for Login, so fast Diagnosis also wont start or trace doesn't contain PD Login request/response", 102 );
		return ( undef, undef, undef, undef, undef, undef);
	}

	# IF-NO-START
	#   STEP The trace doesnt contain fast diagnosis data
	#   STEP fast diagnosis data $raw_fast_diag_data_href = undef
	# IF-NO-END
	unless ( defined $nbr_of_cells_to_read && defined $nbr_of_frames && defined $resolution && defined $nbr_of_can_ids && defined $raw_fast_diag_data_href ) {
		S_set_error( "1) Either the trace does'nt contain the fast Diagnosis data or the fast Diagnosis was not successful\n2) Or Power On and off was not done incase nextPoc option was given as input", 102 );
		return ( undef, undef, undef, undef, undef, undef);
	}

	# STEP return fast diagnosis data
	return ( $raw_fast_diag_data_href, $nbr_of_cells_to_read, $nbr_of_frames, $resolution, $nbr_of_can_ids, $endianess );

}

=head2 Fetch_CAN_IDS

    $can_ids_arr_ref = Fetch_CAN_IDS();   
    

This function is used to fetch the CAN ids for Production Diagnosis from the PSDiag_CAN_Parameter.txt file

B<Arguments:>

=over

=back

B<Return Value:>

=over

=item $returnValue_arr_ref 

Success : returns the array reference of the can ids

Error return : undef

=back

B<Examples:>

    $can_ids_arr_ref = Fetch_CAN_IDS();

=cut

sub Fetch_CAN_IDS {

	# STEP Fetch the CAN Type from the Project Const
	my $can_type = $main::ProjectDefaults->{'SADCONFIG'}{'CAN_Type'};
	
	# STEP Return [1,1,1,1,1] incase of offline
	if($main::opt_offline){	    
	    return [1, 1, 1, 1, 1];
	}	
	
	# STEP Fetch the CAN Type from SAD file if not given in Project constant
	$can_type  = pd_GetSADInfo("CAN Type") if ((not defined $can_type) || $can_type =~/^\s*$/);	

	S_w2log( 4, "The CAN type present in the Project Const file or SAD file is '$can_type'\n" );

	unless ($can_type) {
		S_set_error( "CAN_Type is not found in Project constant or SAD file", 134 );
		return;
	}

	# STEP Fetch the CAN IDs from the PSDiagCanParameter File using the can type
	my $line;
	my @can_ids_arr;
	my $can_para_file_path = "$addpath\\Win32\\PSDiag_CAN_Parameter.txt";
	my $file_FH            = new FileHandle;
	unless ( $file_FH->open($can_para_file_path) ) { S_set_error( " Could'nt open PSDiag_CAN_Parameter.txt '$can_para_file_path' ", 1 ); return; }
	while ( $line = <$file_FH> ) {

		if ( $line =~ /CANTyp_$can_type\s*=\s*(.+)/i ) {

			my @temp_can_ids = split( /\,/, $1 );
			@can_ids_arr = grep { hex($_) > 0 } splice( @temp_can_ids, 5, 5 );

		}
	}
	$file_FH->close;

	S_w2log( 4, "The CAN IDS(in hex) for CAN Type '$can_type' in PSDiag_CAN_Parameter.txt is '@can_ids_arr'\n" );

	unless ( scalar(@can_ids_arr) ) {
		S_set_error( "The CAN_Type '$can_type' is not found in PSDiag_CAN_Parameter file or the Nbr of CAN ids is less than '1'", 134 );
		return;
	}
	return \@can_ids_arr;
}

=head2 Validate_Nbr_CAN_IDS

    $valid_NbrOfCANIds = Validate_Nbr_CAN_IDS([$numberOfCANIds]);       

This function is used to validate the Number Of CANIds passed as a parameter to FastDaignosis APIs(PD_StartFastDiagName and PD_StartFastDiagAddress) against the allowed Nbr of CAN IDS present in the
PSDiag_CAN_Parameter.txt file

B<Arguments:>

=over

=item $numberOfCANIds

(optional)Number of CAN IDs to be used for fast diagnosis

=back

B<Return Value:>

=over

=item $valid_NbrOfCANIds 

Success : Number of valid CAN IDs

Error return : undef

=back

B<Examples:>

    $valid_NbrOfCANIds = Validate_Nbr_CAN_IDS();
    $valid_NbrOfCANIds = Validate_Nbr_CAN_IDS($numberOfCANIds);

=cut

sub Validate_Nbr_CAN_IDS {

	my @args = @_;

	return unless S_checkFunctionArguments( 'Validate_Nbr_CAN_IDS( [$numberOfCANIds] )', @args );

	my $numberOfCANIds = shift @args;

	my $max_nbr_Of_CANIds;
	$max_nbr_Of_CANIds = ( scalar( @{ Fetch_CAN_IDS() } ) - 1 );    #The PSDiagCANParameter.txt file contains CAN IDs for Response as well as Request, So total Nbr of CAN ids passed for Fast Diagnosis will be 1 less than the total
	return unless ($max_nbr_Of_CANIds);                             #return if the Nbr of CAN IDs for Fast Diagnosis is 0(in PSDiagCANParameter.txt file) for the respective project

	# Default Value is 1 for numberOfCANIds
	unless ( defined $numberOfCANIds ) { $numberOfCANIds = 1; S_w2log(3, "The Nbr Of CANIDs passed as a parameter is undefined,So by default '1' is considered\n "); }

	if ( ( $numberOfCANIds > $max_nbr_Of_CANIds ) || $numberOfCANIds < 1 ) { S_set_error( "The Nbr Of CAN IDs passed as a parameter to the API is '$numberOfCANIds', Nbr of CANIDs allowed is '1' to '$max_nbr_Of_CANIds'\n ", 114 ); return; }

	return $numberOfCANIds;

}

=head2 Get_FDtrace_from_CSV_File

    $data_HoH = Get_FDtrace_from_CSV_File( $tracefilename);   
    

This function is used to fetch the fast diagnosis data from the .csv file generated from the PD_StartFastDiagName function

B<Arguments:>

=over

=item $trace_file_path 

It is the path of the .csv file path containing the fast diagnosis data

=back

B<Return Value:>

=over

=item $returnValue_href 

Success : returns the structure created from fast diagnosis .csv file

Error return : { 0 => { 'dummy' => 0 } }

=back

B<Examples:>

    $data_HoH = Get_FDtrace_from_CSV_File( $tracefilename);

=cut

sub Get_FDtrace_from_CSV_File {

	# STEP If the type of the variable is csv then the fast diagnosis data and time is extracted from the .csv generated by the STARTFASTDIAGNOSIS function

	my $data_HoH_dummy;
	$data_HoH_dummy->{0}->{'dummy'} = 0;

	my @args = @_;
	return $data_HoH_dummy unless S_checkFunctionArguments( 'Get_FDtrace_from_CSV_File( $filename)', @args );

	my $filename = shift @args;

	my $data_HoH = {};
	my ( $line, @names, @values, $name, $time );

	S_w2log( 4, "Get_FDtrace_from_CSV_File  ( $filename )\n" );

	@names = ('ECU_reset');

	return $data_HoH_dummy if ($main::opt_offline);

	if ( $ABgeneration < 12 ) {
		my ( $cantime, $count, $sigcount );
		$cantime = 0;
		unless ( -f $filename ) {
			S_set_error( "tracefilename not found $filename", 1 );
			return $data_HoH_dummy;
		}

		open( IN, "<$filename" ) or warn "could not read $filename: $@\n";
		while ( $line = <IN> ) {

			no warnings;

			# to avoid strange warning like
			# Use of uninitialized value in numeric gt (>) at ../modules//LIFT_PD.pm line 2582, <IN> line 1.

			if ( $line =~ /^([0-9a-fA-F]+)\s*-->\s*(\S+)$/ ) {

				# modify for mulibyte !!!
				$name = $2;
				push( @names, $name );
			}
			elsif ( $line =~ /^(\S+)\s*-->\s*([0-9a-fA-F]+)$/ ) {
				$name = $1;
				push( @names, $name );
			}
			elsif ( $line =~ /^---------------------------------------------/ ) {
				$sigcount = scalar(@names);
			}
			elsif ( $sigcount > 0 and $line =~ /^(\S+)\s+([-\w\s]+)$/ ) {
				$cantime = $1;

				@values = split( /\s+/, $2 );

				for ( $count = 0 ; $count < $sigcount ; $count++ ) {
					$time = sprintf( "%010.3f", ( $cantime * 1000 ) );
					$data_HoH->{$time}->{ $names[$count] } = $values[$count];
				}
			}
		}
		close(IN);
	}
	else {
		$filename =~ s/\.(\S+)$//;    #Removing file extension

		unless ( -d $filename ) {
			S_set_error( "tracefilefolder not found $filename", 1 );
			return $data_HoH_dummy;
		}

		my @files = glob("$filename/*");

		foreach my $file (@files) {
			if ( $file =~ m/\.csv$/ )    #Check for csv file extension
			{
				my $labelname = basename($file);    #To get the filename(basename)

                # create a flag for usage of BigFloat
                my $isBigFloat = 0;
                if( $labelname =~ /[us]64/i ) {
                    $isBigFloat = 1;
                }
                
				#To get the label name from older file name Eg: 1_fd_rb_psgp_PsiLineRebootTimer_au32(3)_20140826_142947.csv
				if ( $labelname =~ /^\d+_fd_(.+?)_\d+_\d+\.csv$/ ) {
					$name = $1;
				}

				#To get the label name from newer file name Eg: 20140826_142947_1_fd_rb_psgp_PsiLineRebootTimer_au32(3).csv
				elsif ( $labelname =~ /^\d+_\d+_\d+_fd_(.+?)\.csv$/ ) {
					$name = $1;

					# Remove the variable type added from the ProductionDiagnosis.dll: 1.53
					$name = $1 if ( $name =~ /^(.*)_(U8|S8|S10|U16|S16|U32|S32|U64|S64)$/i );
				}
				open( IN, "<$file" ) or warn "could not read $file: $@\n";
				while ( $line = <IN> ) {

					# With ProductionDiagnosis.dll, 1.53, the header
					# portion is added in below manner and needs to be skipped
					# time_ms ; measurment_hex ; measurment_dec
					next if ( $line =~ /^time_ms.*$/i );
					
					no warnings;
					chomp($line);
					@values = split /;/, $line;
					$time = $values[0];
					$time =~ s/,/\./;
					my $point = $values[2];    #Converting to hex value
					if( $isBigFloat ) {
    					$data_HoH->{$time}->{$name} = Math::BigFloat->new($point);
					}
					else{
    					$data_HoH->{$time}->{$name} = $point;
					}
				}
				close(IN);
			}
		}
	}

	return ($data_HoH);
}

1;

__END__
