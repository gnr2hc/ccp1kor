# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_PDLayer;

use strict;
use warnings;
use LIFT_general;
use LIFT_simulation;
use LIFT_stringProcessing;
use Win32::OLE;
use Win32::OLE::Variant;
Win32::OLE->Option( Warn => \&CatchOleException );
use Win32::Process;    # for killing WinDiag
use version;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  PDL_init
  PDL_exit
  PDL_send_request_wait_response
  PDL_send_request_no_wait
  PDL_get_last_response
  PDL_EcuLogin
  PDL_GetECUDetails
  PDL_FrameSwVersionBasedonRomCodeLength
  PDL_EcuStatus
  PDL_EcuReset
  PDL_Read_Memory
  PDL_Write_Memory
  PDL_ReadFaultMemory
  PDL_ClearFaultMemory
  PDL_ClearAllFaultMemory
  PDL_ClearPlantFaultMemory
  PDL_FreezeFaultMemory
  PDL_ReadEdr
  PDL_ClearEdr
  PDL_ReadNvmDatabyID
  PDL_WriteNvmDatabyID
  PDL_EnableSafetyPath
  PDL_FireAllDevices
  PDL_FastDiagnosis
  PDL_StopReadFastdiagData
  PDL_GetFastDiagnosisData
  PDL_Smi7Verification
  PDL_ManipulateFaultMemory
  PDL_ActivateAIO
  PDL_SetSecurePIN
  PDL_ReadASICSerialNumbers
  PDL_SMI8SMA7VerificationStartRoutine
  PDL_SMI8SMA7VerificationRequestRoutineResults
  PDL_ReadECULifeCycle
  PDL_SwitchECULifeCycle
  PDL_SHEKeyCalculatorProtocol
  PDL_ReceiveResponseFromKMS
  PDL_Enable_KMS_Simulator
  PDL_SetAutoLogin
);

my $pdDiagHandle_href;
my $noResponseRegex = "timed out|queue empty|LOGIN_HAS_FAILED|RECEIVE_QUEUE_EMPTY";
my $lastResponse_href;

=head1 NAME

LIFT_PDLayer 

=head1 SYNOPSIS

    use LIFT_PDLayer

    ($diagHandle_href) = PDL_init( $handleName, $busName, $communicationParameters_href );
    $success = PDL_exit( $diagHandle_href );
    $response_href = PDL_send_request_wait_response( $diagHandle_href, $request_aref [, $options_href ] );
    $success = PDL_send_request_no_wait( $diagHandle_href, $request_aref [, $options_href ] );
    $response_href = PDL_get_last_response();
    $response_href = PDL_EcuLogin();
    $response_href = PDL_EcuStatus();
    $ecu_details_href = PDL_GetECUDetails($romcode);
    $response_href = PDL_EcuReset( $resetType );
    $response_href = PDL_ReadCell( $startAddress, $noOfBytes );
    $response_href = PDL_WriteCell( $startAddress, $memoryContent_aref, $noOfBytesToWrite );
    ($response_href, $maxNoofFlts) = PDL_ReadFaultMemory( $faultType );
    $response_href = PDL_ClearFaultMemory( $waitUntilClear );
    $response_href = PDL_ClearPlantFaultMemory();
    $response_href = PDL_FreezeFaultMemory();
    $response_href = PDL_ReadEdr( $didLowerByte );
    $response_href = PDL_ClearEdr();
    $response_href = PDL_ReadNvmDatabyID( $noOfBytes, $blockID, $subBlockID, $offset );
    $response_href = PDL_WriteNvmDatabyID( $requestBlock_aref, $noOfCellsToWrite, $address );
    $response_href = PDL_EnableSafetyPath();
    $response_href = PDL_FireAllDevices();
    $response_href = PDL_FastDiagnosis( $selectedVarInfo_aref, $numberOfBUSIds, $isNextPOC, $fastDiagDataPath );
    $success = PDL_StopReadFastdiagData();
    $fastDiagDataPath = PDL_GetFastDiagnosisData();
    $response_href = PDL_Smi7Verification( $smi7DataBlock, $noOfSamples );
    $response_href = PDL_ManipulateFaultMemory( $eventID, $isQualify );
    $response_href = PDL_ActivateAIO();
    $response_href = PDL_ReadASICSerialNumbers();
    $response_href = PDL_SMI8SMA7VerificationStartRoutine( $smi8sma7dataBlock_aref, $noOfSamples );
    $response_href = PDL_SMI8SMA7VerificationRequestRoutineResults();

=head1 DESCRIPTION

Perl interface to the PDLayer.dll (PDLayer.Pd4Com) via COM.

Most of the functions return the ECU response as hashref:

    $response_href = {
        'PdLength'           => <first byte of response>,        # decimal number
        'Id'                 => <second byte of response>,       # decimal number
        'Checksum'           => <last byte of response>,         # decimal number
        'PdPayload'          => [<remaining bytes of response>], # array reference, decimal numbers
        'CompletePdMsg'      => [<all bytes of response>],       # array reference, decimal numbers
        'Status'             => <status of response>,            # number, >=0 is OK, <0 is error
        'ErrorDescription'   => <error description>,             # string, according to 'Status'
        'IsCheckConsistency' => <???>,                           # boolean, 0|1
    };

=head1 FUNCTIONS



=head2 PDL_init

    $diagHandle_href = PDL_init( $handleName, $busName, $communicationParameters_href );

Creates a COM connection to PDLayer.dll (PDLayer.Pd4Com) and creates a COM handle with the name $handleName for subsequent usage of the connection.
Tries to initialize communication on the bus $busName using $communicationParameters_href.

B<Arguments:>

=over

=item $handleName

name of the handle

=item $busName

bus type for initializing communication (CAN)
    
=item $communicationParameters_href

For CAN, communication parameters looks like this,
    
    $communication_params_href = {
        'BAUDRATE'   => 7A120,
        'TSEG1'      => C,
        'TSEG2'      => 3,
        'SJW'        => 3,
        'SAM'        => 1,
        'REQUEST'    => 650,
        'RESPONSE1'  => 651,
        'RESPONSE2'  => 652,
        'RESPONSE3'  => 653,
        'RESPONSE4'  => 654,
    }

=back

B<Return Values:>

=over

=item $diagHandle_href

    $diagHandle_href = {
        'name' => <name of handle>,          # name as given in $communicationParameters_href
        'OLE_handle' => <Win32::OLE object>, # Win32::OLE object for access to PDLayer.dll
        'status' => <status of the function call>
    }

=back

B<Examples:>

    $result = PDL_init( 'PD', 'CAN', $comm_href ); 

=cut

sub PDL_init {
    my @args = @_;

    S_checkFunctionArguments( 'PDL_init( $handleName, $busName, $communicationParameters_href )', @args ) or return;
    my $handleName                   = shift @args;
    my $busName                      = shift @args;
    my $communicationParameters_href = shift @args;

    # offline handling
    my $diagHandle_href;
    if ($main::opt_offline) {
        $diagHandle_href = {
            'name'       => $handleName,
            'OLE_handle' => 1,
            'status'     => 1,
        };
        if ( $diagHandle_href->{name} eq 'PD' ) {
            $pdDiagHandle_href = $diagHandle_href;
        }
        return $diagHandle_href;
    }

    #STEP Killing PSDiag
    S_w2log( 3, "PDL_init: Searching for PSDiag ...\n" );
    my %procs = S_get_Win32_processes();
    if ( exists $procs{'PSDiag'} ) {
        S_w2log( 3, "PDL_init: Killing PSDiag !!!\n" );
        Win32::Process::KillProcess( $_, 0 ) foreach ( @{ $procs{'PSDiag'} } );
    }

    #CALL CheckRegisteredCOMdll to check if the registered COM dll matches the corresponding Engine dll
    my $dllName = 'Pd4Com.Pd4Com.1.0';
    CheckRegisteredCOMdll($dllName) or return;

    #CALL GetOleObject (PDLayer.Pd4Com.1.0) to get Pd4Com object
    S_w2log( 3, "PDL_init: Creating a connection to COM class '$dllName' for handle '$handleName' ...\n" );
    my $pdLayer_obj = GetOleObject($dllName) or return;

    #STEP Create diag handle with Pd4Com object
    $diagHandle_href = {
        'name'       => $handleName,
        'OLE_handle' => $pdLayer_obj,
    };

    #STEP Store handle if name is PD
    if ( $diagHandle_href->{name} eq 'PD' ) {
        $pdDiagHandle_href = $diagHandle_href;
    }

    S_w2log( 3, "PDL_init: Connection to COM class '$dllName' for handle '$handleName' created. Initializing communication on bus '$busName'...\n" );

    #CALL GetOleObject ('PDLayer.Pd4Com.ComPdParam') to get ComPdParam object
    #my $comPdParam_obj = GetOleObject('PDLayer.Pd4Com.ComPdParam') or return; # offline dll
    my $comPdParam_obj = GetOleObject('Pd4Com.ComPdParam.1.0') or return;    # first prototype

    #STEP Fill the ComPdParam object with communication parameters
    #CALL SetComPdParam (ComPdParam object, $communicationParameters_href)
    SetComPdParam( $comPdParam_obj, $communicationParameters_href );

    #STEP Initialize communication on the bus using the ComPdParam object
    #CALL CallObjMethod (Pd4Com object, 'InitializeEcuCommunication', [ $busName, ComPdParam object ])
    my $initStatus = CallObjMethod( $pdLayer_obj, 'InitializeEcuCommunication', [ $busName, $comPdParam_obj ] ) // -1;
    if ( $initStatus < 0 ) {
        my $errorDescription = CallObjMethod( $pdLayer_obj, 'GetErrorDescription', [$initStatus] );
        my $errorText =
          "Status '$initStatus' after 'InitializeEcuCommunication' on PDLayer handle '$handleName'. Error description: $errorDescription\n" . "This may be due to any of the below reasons:\n" . "In LIFT_testbenches.pm section: 'Devices' => 'PDLayer' a wrong 'BusType' or 'Hw_Serial_Nbr' is given \n";
        S_set_error( $errorText, 109 );
        $diagHandle_href->{status} = $initStatus;
        return $diagHandle_href;
    }
    S_w2log( 3, "PDL_init: Communication on bus '$busName' established.\n" );
    $diagHandle_href->{status} = 1;

    my $getMainVersionOfPdDll  = CallObjMethod( $pdLayer_obj, 'GetMainVersionOfPdDll' )  // 'Error-GetMainVersionOfPdDll';
    my $getMainVersionOfVxlapi = CallObjMethod( $pdLayer_obj, 'GetMainVersionOfVxlapi' ) // 'Error-GetMainVersionOfVxlapi';
    S_w2log( 3, "PDL_init: version information for 'PDLayer = $getMainVersionOfPdDll' and 'vxlapi = $getMainVersionOfVxlapi'.\n" );

    #STEP Return diag handle
    return $diagHandle_href;
}

=head2 PDL_exit

    $success = PDL_exit( $diagHandle_href );


B<Arguments:>

=over

=item $diagHandle_href

=back
B<Return Values:>

=over

=item $success

$success is 1 on success
$success is undef on failure

=back

B<Examples:>

    $success = PDL_exit( $diagHandle_href );
    
=cut

sub PDL_exit {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_exit( $diagHandle_href )', @args ) or return;
    my $diagHandle_href = shift @args;

    S_checkFunctionArgumentHashKeys( "PDL_exit", $diagHandle_href, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 }, { 'name' => 1, 'OLE_handle' => 1 } ) or return;

    S_w2log( 4, "Calling PDL_exit to close the diagnosis handle.." );

    #STEP Delete the stored handle if the handle name is PD
    if ( $diagHandle_href->{name} eq 'PD' ) {
        $pdDiagHandle_href = undef;
    }

    # offline handling
    return 1 if ($main::opt_offline);

    #STEP Uninitialize the OLE object in the diagHandle
    my $pdLayer_obj = $diagHandle_href->{OLE_handle};
    CallObjMethod( $pdLayer_obj, 'UnInitializeEcuCommunication' );
    $pdLayer_obj = undef;

    return 1;
}

=head2 PDL_send_request_wait_response

    $response_href = PDL_send_request_wait_response( $diagHandle_href, $request_aref [, $options_href ] );

Sends the request bytes $request_aref to the device defined by $diagHandle_href, waits for a response, 
and returns the response data as $response_href.

B<Arguments:>

=over

=item $diagHandle_href

=item $request_aref

=item $options_href

=back


B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_send_request_wait_response {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_send_request_wait_response( $diagHandle_href, $request_aref [, $options_href ] )', @args ) or return;
    my $diagHandle_href = shift @args;
    my $request_aref    = shift @args;
    my $options_href    = shift @args;

    S_checkFunctionArgumentHashKeys( "PDL_send_request_wait_response", $diagHandle_href, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 }, { 'name' => 1, 'OLE_handle' => 1, 'status' => 1 } ) or return;

    my $handleName    = $diagHandle_href->{'name'};
    my $requestString = STR_Aref2HexString($request_aref);

    S_w2log( 3, "PDL_send_request_wait_response: Sending request '$requestString' to PDLayer handle '$handleName' ...\n" );
    my $response_href = SendServiceReceiveResponse( $diagHandle_href, 'SendReceiveData', [$request_aref], [ VT_ARRAY | VT_I4 ] );

    if ( defined $response_href and defined $response_href->{Status} and $response_href->{Status} == 0 ) {
        my $payloadString = STR_Aref2HexString( $response_href->{'PdPayload'} );
        S_w2log( 3, "PDL_send_request_wait_response: Received Response. Payload is '$payloadString'.\n" );
    }

    return $response_href;
}

=head2 PDL_send_request_no_wait

    $success = PDL_send_request_no_wait( $diagHandle_href, $request_aref [, $options_href ] );

B<Arguments:>

=over

=item $diagHandle_href

=item $request_aref

=item $options_href

=back


B<Return Values:>

=over

=item $success

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_send_request_no_wait {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_send_request_no_wait( $diagHandle_href, $request_aref [, $options_href ] )', @args ) or return;
    my $diagHandle_href = shift @args;
    my $request_aref    = shift @args;
    my $options_href    = shift @args;

    my $success;
    S_set_error( "Not yet implemented in PDLayer.dll", 109 );
    return $success;
}

=head2 PDL_EcuLogin

    $response_href = PDL_EcuLogin();

Unsecured Login to the ECU using two way handshake with seed and key.

B<Return Values:>

=over

=item $response_href

Second Login response after successfull handshake (L</"DESCRIPTION">)

=back

B<Examples:>

    $response_href = PDL_EcuLogin();
    
    $response_href = {
        'ErrorDescription' => 'OK',
        'PdLength' => 54,
        'Id' => 64,
        'CompletePdMsg' => [54, 64, 162, 12, 8, 11, 65, 66, 0, 66, 68, 1, 7, 0, 0, ....],
        'Status' => 0,
        'PdPayload' => [64, 162, 12, 8, 11, 65,....],
        'Checksum' => 122,
    }

=cut

sub PDL_EcuLogin {

    my $command = 'EcuLogin';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    my $response_href = SendPDServiceReceiveResponse($command);
    return $response_href;
}

=head2 PDL_EcuStatus

    $response_href = PDL_EcuStatus();

ECU status request.

B<Return Values:>

=over

=item $response_href

PD response containing status bytes for Fault Memory, EDR, Dataflash, Electronic Firing 

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_EcuStatus {

    my $command = 'EcuStatus';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_EcuReset

    $response_href = PDL_EcuReset( $resetType );

Soft or Hard Reset the ECU.

B<Arguments:>

=over

=item $resetType

"SOFTRESET" or "HARDRESET".

=back

B<Return Values:>

=over

=item $response_href

(L</"DESCRIPTION">)

=back

B<Examples:>

    $response_href = PDL_EcuReset( 'SOFTRESET' );

=cut

sub PDL_EcuReset {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_EcuReset( $resetType )', @args ) or return;
    my $resetType = shift @args;

    #STEP read reset type
    #IF reset type is not 'SOFTRESET' or 'HARDRESET'
    #   IF-YES-START
    #       STEP set error
    #   IF-YES-END
    #   IF-NO-START
    #       CALL EcuReset service with reset type
    #   IF-NO-END
    #STEP return
    $resetType = uc($resetType);
    if ( $resetType ne 'SOFTRESET' and $resetType ne 'HARDRESET' ) {
        S_set_error( "\$resetType = '$resetType' is unknown. Allowed values for \$resetType are: 'SOFTRESET' or 'HARDRESET'.", 109 );
        return;
    }

    my $command = 'EcuReset';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$resetType = '$resetType' ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [$resetType] );

    return $response_href;
}

=head2 PDL_Read_Memory

    $cellContents_aref = PDL_Read_Memory( $startAddress, $nbrOfBytes );

Reads the data from different memory sections like RAM, ROM, external EEPROM, Dataflash and NVM.

B<Arguments:>

=over

=item $startAddress

Address in memory block from where read service shall begin (integer).

=item $nbrOfBytes

Total number of bytes to be read (integer), shall not be greater than 2047.

=back

B<Return Values:>

=over

=item $response_href 

Success      : ECU response, see L</DESCRIPTION>

Error        : undef

=back

B<Examples:>

    $response_href = PDL_Read_Memory( 0xFED48004, 3 ); Nbr of bytes read = 3, starting from the address 0xFED48004
    
    $response_href = PDL_Read_Memory( 201A0000, 3 ); Nbr of bytes read = 3, starting from the address 201A0000
    
B<Notes:> Function L</"PDL_init">() has to be called before calling this function.

=cut

sub PDL_Read_Memory {
    my @args = @_;

    S_checkFunctionArguments( 'PDL_Read_Memory( $startAddress, $nbrOfBytes )', @args ) or return;

    my $startAddress = shift @args;
    my $nbrOfBytes   = shift @args;

    # STEP Fetch the input arguments ($startAddress, $nbrOfBytes)

    S_w2log( 5, " PDL_Read_Memory Read the memory data at address $startAddress \n" );

    #   IF $address is a NVM address
    #   IF-YES-START
    #    CALL LIFT_PDLayer::PDL_ReadNvmDatabyID
    #   IF-YES-END
    #   IF-NO-START
    #    CALL LIFT_PDLayer::PDL_ReadCell
    #   IF-NO-END

    my $startAddress_hexstr = sprintf( "%8X", $startAddress );

    my $response_href;
    if ( $startAddress_hexstr =~ /^2/ ) {

        my $nvmParams = Extract_Parameters_From_NvM_Address($startAddress_hexstr) or return;

        my ( $nvmAddrRangeIndex, $nvmBlockId, $nvmSubBlockId, $nvmOffset ) = @$nvmParams;

        $response_href = PDL_ReadNvmDatabyID( $nbrOfBytes, hex $nvmBlockId, hex $nvmSubBlockId, hex $nvmOffset );
    }
    else {
        $response_href = PDL_ReadCell( $startAddress, $nbrOfBytes );
    }

    # STEP return the hash reference of the data, undef incase of error
    return $response_href;
}

=head2 PDL_ReadCell

    $response_href = PDL_ReadCell( $startAddress, $nbrOfBytes );

Reads the data from different memory sections like RAM, ROM, external EEPROM and Dataflash.

B<Arguments:>

=over

=item $startAddress

Address in memory block from where read service shall begin (integer).

=item $nbrOfBytes

Total number of bytes to be read (integer), shall not be greater than 2047.

=back


B<Return Values:>

=over

=item $response_href

ECU response, see L</DESCRIPTION>

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_ReadCell {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ReadCell( $startAddress, $noOfBytes )', @args ) or return;
    my $startAddress = shift @args;
    my $noOfBytes    = shift @args;

    S_w2log( 4, "PDL_ReadCell: Sending service 'ReadCell' with start address = " . Dec2HexString( $startAddress, 8 ) . " and number of bytes = $noOfBytes ...\n" );
    my $response_href = SendPDServiceReceiveResponse( 'ReadCell', [ $startAddress, $noOfBytes ] );

    if ( defined $response_href and defined $response_href->{Status} and $response_href->{Status} >= 0 ) {

        my $memoryDataCorr_aref = AddMemoryData2Response($response_href);
        my $memoryDataString    = STR_Aref2HexString($memoryDataCorr_aref);
        S_w2log( 4, "PDL_ReadCell: Received Response. Cell content is '$memoryDataString'.\n" );
    }

    return $response_href;
}

=head2 PDL_Write_Memory

    $response_href = PDL_Write_Memory( $startAddress, $cellContents_aref [,$formatEndianness] );

Writes the data given in $cellContents_aref into ECU at address $startAddress using write cell service

B<Arguments:>

=over

=item $startAddress

Memory address from where the write service shall begin (integer)

=item $cellContents_aref

Data that shall be written into memory block (array of integer)

=item $formatEndianness (optional)

Flag to identify whether the Endianness correction is needed or not.

=back

B<Return Values:>

=over

=item $response_href

Response hash reference contains the details of the write operation, see L</DESCRIPTION>

=back

B<Examples:>

$response_href  = PDL_Write_Memory( 0xFED48004, [ 40, 0, 6] ); Address = 0xFED48004, Data to be written = 40, 0, 6

$response_href  = PDL_Write_Memory( 0xFED48004, [ 6, 37, 8], 1 ); Address = 0xFED48004, Data to be written = 6, 37, 8. Additionally an endianness correction will be done based on ECU endianness.

B<Notes:> 

=cut

sub PDL_Write_Memory {
    my @args = @_;

    S_checkFunctionArguments( 'PDL_Write_Memory( $startAddress, $cellContents_aref [,$formatEndianness] )', @args ) or return;

    my $startAddress      = shift @args;
    my $cellContents_aref = shift @args;
    my $formatEndianness  = shift @args;

    S_w2log( 4, " PDL_Write_Memory : Writes data '@$cellContents_aref' into ECU at '$startAddress' \n" );

    # IF Is $formatEndianness Flag set to 1?
    # IF-YES-START
    #   COMMENT-START
    #       Correct the endianness as per ECU endianness
    #   COMMENT-END
    #   CALL FormatMemoryDatabyEndianness
    # IF-YES-END
    # IF-NO-START
    # IF-NO-END
    #   IF $address is a NVM address
    #   IF-YES-START
    #       CALL LIFT_PDLayer::PDL_WriteNvmDatabyID
    #   IF-YES-END
    #   IF-NO-START
    #   CALL LIFT_PDLayer::PDL_WriteCell
    #   IF-NO-END

    my $startAddress_hexstr = sprintf( "%8X", $startAddress );
    my $response_href;
    $cellContents_aref = FormatMemoryDatabyEndianness($cellContents_aref) if $formatEndianness;
    if ( $startAddress_hexstr =~ /^2/ ) {

        my $nvmParams = Extract_Parameters_From_NvM_Address($startAddress_hexstr) or return;

        my ( $nvmAddrRangeIndex, $nvmBlockId, $nvmSubBlockId, $nvmOffset ) = @$nvmParams;

        $response_href = PDL_WriteNvmDatabyID( $cellContents_aref, scalar(@$cellContents_aref), hex $nvmBlockId, hex $nvmSubBlockId, hex $nvmOffset );
    }
    else {
        $response_href = PDL_WriteCell( $startAddress, $cellContents_aref );
    }

    # STEP return the hash reference of the data, undef incase of error
    # STEP END
    return $response_href;
}

=head2 PDL_WriteCell

    $response_href = PDL_WriteCell( $startAddress, $memoryContent_aref );

Writes the data given in $memoryContent_aref into ECU at address $startAddress using write cell service

B<Arguments:>

=over

=item $startAddress

Memory address from where the write service shall begin (integer)

=item $memoryContent_aref

Data that shall be written into memory block (array of integer)

=back


B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_WriteCell {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_WriteCell( $startAddress, $memoryContent_aref )', @args ) or return;
    my $startAddress       = shift @args;
    my $memoryContent_aref = shift @args;

    my $command = 'WriteCell';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$startAddress = " . Dec2HexString( $startAddress, 8 ) . " and \$memoryContent_aref = " . STR_Aref2HexString($memoryContent_aref) . " ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $startAddress, $memoryContent_aref ], [ 0, VT_ARRAY | VT_I4 ] );

    return $response_href;
}

=head2 PDL_ReadFaultMemory

    $faultMemory_href = PDL_ReadFaultMemory( $faultType, $fltFilepath );

Read one of the fault memories, defined by $faultType. 
Path to the fault file ($fltFilepath) must be given and the file shall be present in the same location where the SAD file is present. 

B<Arguments:>

=over

=item $faultType

Fault Recorder Type (integer):  0 = PLANT, 1 = PRIMARY, 3 = BOSCH, 4 = DISTURBANCE

=item $fltFilepath

*.flt file path to read the fault description

=back

B<Return Values:>

=over

=item $faultMemory_href

Content of fault memory in the following structure:

    0 => {   # fault entry #0
        FaultID     => ...,
        Description => ...,
        ...
    },
    1 => {   # fault entry #1
        ...
    }

The keys depend on $faultType.

If the fault memory is empty then $faultMemory_href = {}.

In offline mode $faultMemory_href = {}.

On error $faultMemory_href = undef.

=back

B<Examples:>

    $faultMemory_href = PDL_ReadFaultMemory(1, 'C:/TurboLIFT/TSG4/Config/SAD/AB12.flt'); # Reads PRIMARY fault memory.
    $faultMemory_href = PDL_ReadFaultMemory(3, 'C:/TurboLIFT/TSG4/Config/SAD/AB12.flt'); # Reads BOSCH fault memory.

B<Notes:> This function should be called by PRD12_Read_Fault_Memory() in LIFT_ProdDiag_AB12.pm.

=cut

sub PDL_ReadFaultMemory {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ReadFaultMemory( $faultType, $fltFilepath )', @args ) or return;
    my $faultType   = shift @args;
    my $fltFilepath = shift @args;

    S_w2log( 4, "PDL_ReadFaultMemory: Sending service 'ReadFaultMemory' with \$faultType = '$faultType' and \$fltFilepath = '$fltFilepath' ...\n" );

    # IF Is PDLayer handle defined?
    #   IF-NO-START
    #       STEP ERROR: PDLayer handle not defined, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       CALL CallObjMethod()
    #       IF Is status < 0
    #           IF-YES-START
    #               STEP ERROR: dll function call not successfull, return undef
    #           IF-YES-END
    #           IF-NO-START
    #               STEP return $faultMemory_href
    #           IF-NO-END
    #   IF-YES-END
    # STEP END

    return unless CheckPreconditions();

    return {} if ($main::opt_offline);

    my $status;
    my $maxNoofFlts               = 0;
    my $fltDescriptionValues_aref = [];

    ( $status, $fltDescriptionValues_aref, $maxNoofFlts ) = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'ReadFaultMemory', [ $faultType, $fltFilepath, $fltDescriptionValues_aref, $maxNoofFlts ], [ 0, 0, VT_BSTR | VT_ARRAY | VT_BYREF, VT_I4 | VT_BYREF ] );

    if ( $status < 0 ) {
        my $errText = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'GetErrorDescription', [$status] );
        S_set_error( "PDLayer dll function 'ReadFaultMemory' returned status = '$status', Error description: '$errText'.", 109 );
        return;
    }

    my $faultMemory_href = {};
    S_w2log( 4, "PDL_ReadFaultMemory: Fault descriptions start:\n" );
    foreach my $faultIndex ( 0 .. @$fltDescriptionValues_aref - 1 ) {
        my $faultDescription = $$fltDescriptionValues_aref[$faultIndex];
        S_w2log( 4, "$faultIndex: $faultDescription\n" );

        my @properties = split( /,/, $faultDescription );
        foreach my $property (@properties) {
            if ( $property =~ /^([^:]+):([^:]*)$/ ) {
                my $propertyKey   = $1;
                my $propertyValue = $2;
                $faultMemory_href->{$faultIndex}{$propertyKey} = $propertyValue;
            }
        }
    }
    S_w2log( 4, "PDL_ReadFaultMemory: Fault descriptions end.\n" );

    return $faultMemory_href;
}

=head2 PDL_ClearFaultMemory

    $response_href = PDL_ClearFaultMemory( $options_href );

Clears fault memory based on the fault type selected.

B<Arguments:>

=over

=item $options_href

    $options_href => {
                        'faultType' => 'plant' or 'all' (default)
                        'waitUntilClear' => 0 or 1 (default)
                     }

=back

B<Return Values:>

    1 on success
    undef on failure

B<Examples:>

    # clear all FM and wait until clear
    PDL_ClearFaultMemory({'faultType' => 'all', 'waitUntilClear' => 1});

    # clear plant FM
    PDL_ClearFaultMemory({'faultType' => 'plant', 'waitUntilClear' => 0});

B<Notes: This function must be called by LIFT_ProdDiag_AB12::PRD12_Clear_Fault_Memory>

=cut

sub PDL_ClearFaultMemory {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ClearFaultMemory( $options_href )', @args ) or return;
    my $options_href = shift @args;

    # IF Is PDLayer handle defined?
    #   IF-NO-START
    #       STEP ERROR: PDLayer handle not defined, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       IF Is faultType eq ALL
    #           IF-YES-START
    #               CALL PDL_ClearAllFaultMemory($options_href-{'waitUntilClear'})
    #           IF-YES-END
    #           IF-NO-START
    #               CALL PDL_ClearPlantFaultMemory()
    #           IF-NO-END
    #   IF-YES-END
    # STEP END

    return unless CheckPreconditions();

    my $response_href = {};
    if ( $options_href->{'faultType'} =~ /^all$/i ) {
        $response_href = PDL_ClearAllFaultMemory( $options_href->{'waitUntilClear'} );
        return unless keys %$response_href;
    }
    else {
        $response_href = PDL_ClearPlantFaultMemory();
        return unless keys %$response_href;
    }

    return $response_href;
}

=head2 PDL_ClearAllFaultMemory

    $response_href = PDL_ClearAllFaultMemory( $waitUntilClear );

Clear All Fault Memories: Plant FM, Bosch FM, Disturbance FM, Primary FM.

B<Arguments:>

=over

=item $waitUntilClear

If $waitUntilClear is true, the function will wait until the Fault Memory is actually cleared and the ECU is ready to be used. 
If $waitUntilClear is false, the function will return right after the Service acknowledged the reception of the request.

=back


B<Return Values:>

=over

=item $response_href

=back

B<Examples:>

    # wait until clear
    PDL_ClearFaultMemory(1);

    # Do not wait until clear
    PDL_ClearFaultMemory(0);

B<Notes: This function must be called by PDL_ClearFaultMemory>

=cut

sub PDL_ClearAllFaultMemory {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ClearAllFaultMemory( $waitUntilClear )', @args ) or return;
    my $waitUntilClear = shift @args;

    # IF Is PDLayer handle defined?
    #   IF-NO-START
    #       STEP ERROR: PDLayer handle not defined, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       CALL SendPDServiceReceiveResponse($command, [$waitUntilClear])
    #       IF Is status < 0
    #           IF-YES-START
    #               STEP ERROR: dll function call not successfull, return undef with error description
    #           IF-YES-END
    #           IF-NO-START
    #               STEP return $response_href
    #           IF-NO-END
    #   IF-YES-END
    # STEP END

    return unless CheckPreconditions();

    $waitUntilClear = $waitUntilClear ? 1 : 0;    # convert perl true/false to 1/0

    my $command = 'ClearFaultMemory';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$waitUntilClear = $waitUntilClear ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [$waitUntilClear] );

    return $response_href;
}

=head2 PDL_ClearPlantFaultMemory

    $response_href = PDL_ClearPlantFaultMemory();

Clears only the Plant fault memory. This is intended to be used when the plant mode 12 is active.

B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

    PDL_ClearPlantFaultMemory();

B<Notes: This function must be called by PDL_ClearFaultMemory> 

=cut

sub PDL_ClearPlantFaultMemory {

    my $command = 'ClearPlantFaultMemory';

    # IF Is PDLayer handle defined?
    #   IF-NO-START
    #       STEP ERROR: PDLayer handle not defined, return undef
    #   IF-NO-END
    #   IF-YES-START
    #       CALL SendPDServiceReceiveResponse($command)
    #       IF Is status < 0
    #           IF-YES-START
    #               STEP ERROR: dll function call not successfull, return undef with error description
    #           IF-YES-END
    #           IF-NO-START
    #               STEP return $response_href
    #           IF-NO-END
    #   IF-YES-END
    # STEP END

    return unless CheckPreconditions();

    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_FreezeFaultMemory

    $response_href = PDL_FreezeFaultMemory();

Request freeze of fault memory. No faults will qualify, disqualfiy after calling this until a reset is requested.

B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_FreezeFaultMemory {

    my $command = 'FreezeFaultMemory';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, undef, undef, 1 );

    return $response_href;
}

=head2 PDL_ReadEdr

    $response_href = PDL_ReadEdr( $didLowerByte );

Read a single EDR record, defined by $didLowerByte.

B<Arguments:>

=over

=item $didLowerByte

ID of the record (integer). First record has ID 0.

=back


B<Return Values:>

=over

=item $response_href

Positive Response containing the EDR data for valid DID.

Negative Response if ID does not exist or record is empty. 

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_ReadEdr {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ReadEdr( $didLowerByte )', @args ) or return;
    my $didLowerByte = shift @args;

    #IF is Valid Arguments
    #IF-YES-START
    #CALL SendPDServiceReceiveResponse
    #IF-YES-END
    #IF-NO-START
    #STEP ERROR invalid arguments
    #IF-NO-END
    #STEP END
    my $command = 'ReadEdr';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$didLowerByte = $didLowerByte ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [$didLowerByte] );

    if ($response_href) {
        if ( $response_href->{ErrorDescription} =~ /NRC55_RDEDR__VALID_DID_EMPTY_CRASH_ENTRY/i ) {
            my $did = sprintf( "0x%.2X", $didLowerByte );
            S_w2log( 3, "PDL_ReadEdr: EDR data for DID $did is empty" );
        }
    }

    #call remove fill bytes to remove the extra fill bytes
    if ($response_href) {

        # offline condition added because the CallObjMethod does not have the check for the offline
        if ($main::opt_offline) {
            $response_href = ResponseObj2href('offline');
            return $response_href;
        }
        ( $response_href->{'CompletePdMsg'} ) = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'RemoveFillBytes', [ $response_href->{'CompletePdMsg'} ], [ VT_ARRAY | VT_I4 ] );
        $response_href->{'Checksum'} = @{ $response_href->{'CompletePdMsg'} }[-1];    # last index value is the checksum
        my $last_idx = $#{ $response_href->{'CompletePdMsg'} };                       # get last index for PdPayload
        $response_href->{'PdPayload'} = [ @{ $response_href->{'CompletePdMsg'} }[ 1 .. ( $last_idx - 1 ) ] ];    # PdPayload contains ID and data bytes except length and checksum
        my $completeMessageString = STR_Aref2HexString( $response_href->{'CompletePdMsg'} );
        S_w2log( 4, "PDL_ReadEdr: Response after removal of fill bytes: $completeMessageString" );
    }
    return $response_href;
}

=head2 PDL_ClearEdr

    $response_href = PDL_ClearEdr();

Clears all EDR (Event Data Recorder).

B<Return Values:>

=over

=item $response_href

Returns positive or negative response for success or failure of the service.

    Positive Response, Length, ID, Reserved Byte, Checksum

or

    Negative Response, Checksum

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_ClearEdr {

    my $command = 'ClearEDR';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    #CALL SendPDServiceReceiveResponse
    #STEP return response_href from SendPDServiceReceiveResponse
    #STEP END

    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_ReadNvmDatabyID

    $response_href = PDL_ReadNvmDatabyID( $noOfBytes, $blockID, $subBlockID, $offset [, $format_data_by_endianness ] );

Reads the NVM data based on the Block ID.

    Example : How to extract the parameters from NvM Address :
    Address : 201A0000
    2   : Its an indication for NVM address range
    01A : Block ID
    0   : SubBlockID
    000 : Offset 

B<Arguments:>

=over

=item $noOfBytes

Total number of bytes to read (integer)

=item $blockID

Block ID extracted from the NvM address (integer)

=item $subBlockID

SubBlock ID extracted from the NvM address (integer)

=item $offset

Offset extracted from the NvM address (integer)

=item $format_data_by_endianness (optional)

Determines the format of the value of key 'DataBytes' in $response_href.
If set to true (default) then DataBytes will be corrected for endianness of ECU. Otherwise no correction for endianness will be done.

=back


B<Return Values:>

=over

=item $response_href

Value of key 'DataBytes' is corrected for endianness of ECU if $format_data_by_endianness is true.

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_ReadNvmDatabyID {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ReadNvmDatabyID( $noOfBytes, $blockID, $subBlockID, $offset [, $format_data_by_endianness ] )', @args ) or return;
    my $noOfBytes                 = shift @args;
    my $blockID                   = shift @args;
    my $subBlockID                = shift @args;
    my $offset                    = shift @args;
    my $format_data_by_endianness = shift @args // 1;

    my $command = 'ReadNvmDatabyID';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$noOfBytes = $noOfBytes, \$blockID = $blockID, \$subBlockID = $subBlockID, \$offset = $offset, \$format_data_by_endianness = $format_data_by_endianness ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $noOfBytes, $blockID, $subBlockID, $offset ] );

    if ( defined $response_href and defined $response_href->{Status} and $response_href->{Status} >= 0 ) {

        my $memoryDataCorr_aref = AddMemoryData2Response( $response_href, $format_data_by_endianness );
        my $memoryDataString = STR_Aref2HexString($memoryDataCorr_aref);
        S_w2log( 4, "PDL_ReadNvmDatabyID: Received Response. NVM content is '$memoryDataString'.\n" );
    }

    return $response_href;
}

=head2 PDL_WriteNvmDatabyID

    $response_href = PDL_WriteNvmDatabyID( $requestBlock_aref, $noOfCellsToWrite, $blockID, $subBlockID, $offset );

Writes $noOfCellsToWrite bytes of the data given by $requestBlock_aref in into NVM Block defined by $blockID, $subBlockID, $offset.

B<Arguments:>

=over

=item $requestBlock_aref

Data that shall be written into the NvM block (array of integers)

=item $noOfCellsToWrite

Total number of bytes to be written into ECU (integer)

=item $blockID, $subBlockID, $offset

NvM block block ID, sub block ID and offset (all int)

=back


B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_WriteNvmDatabyID {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_WriteNvmDatabyID( $requestBlock_aref, $noOfCellsToWrite, $blockID, $subBlockID, $offset )', @args ) or return;
    my $requestBlock_aref = shift @args;
    my $noOfCellsToWrite  = shift @args;
    my $blockID           = shift @args;
    my $subBlockID        = shift @args;
    my $offset            = shift @args;

    my $command = 'WriteNvmDatabyID';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$requestBlock_aref =  " . STR_Aref2HexString($requestBlock_aref) . ", \$noOfCellsToWrite = $noOfCellsToWrite, \$blockID = '$blockID' , \$subBlockID = '$subBlockID' , \$offset = '$offset' ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $requestBlock_aref, $noOfCellsToWrite, $blockID, $subBlockID, $offset ], [ VT_ARRAY | VT_I4, 0, 0, 0, 0 ] );

    return $response_href;
}

=head2 PDL_EnableSafetyPath

    $response_href = PDL_EnableSafetyPath();

Enable Safety Path request.

B<Return Values:>

=over

=item $response_href

=back

B<Examples:>

B<Notes:> 

=cut

sub PDL_EnableSafetyPath {

    my $command = 'EnableSafetyPath';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    #STEP CALL SendPDServiceReceiveResponse for 'EnableSafetyPath' functionality
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_FireAllDevices

    $response_href = PDL_FireAllDevices();

Send Fire all squibs request.

B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_FireAllDevices {

    my $command = 'FireAllDevices';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    #STEP CALL SendPDServiceReceiveResponse for 'FireAllDevices' functionality
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_FastDiagnosis

    $response_href = PDL_FastDiagnosis( $selectedVarInfo_aref, $numberOfBUSIds, $isNextPOC, $fastDiagDataPath );
    
Starts the fast diagnosis recording as defined by $fastDiagConfig_href and returns the path to the folder with the created csv files. It reads the values at the ECU labels given in $fastDiagConfig_href.

B<Arguments:>

=over

=item $selectedVarInfo_aref

Array reference of the label names for which fast diagnosis data will be read.

=item $numberOfBUSIds

It tells about the resolution at which particular Nbr of bytes can be read.

=item $isNextPOC

This provides the possibility to start the fast diagnosis not immediately(=0, default), but on next ECU power on(=1)

=item $fastDiagDataPath

Path of the directory where the csv files for the individual labels are stored, default is <report-folder>\FastDiagData_<date>_<time>

=back

B<Return Values:>

=over

=item $response_href

=back

B<Examples:>
    
    my $selectedVarInfo_aref = ['Adc_GroupInfo(0).resultBuffer_puo_U8', 'rb_sycc_SysConfCsemDataEe_st.sensorID;U8', '0xFEDFF395;U8'] ;
    
    my $numberOfBUSIds = 2 ;
    
    my $isNextPOC = 0 ;
    
    $fastDiagDataPath = 'D:/TurboLIFT/Projects/TSG4/Engine/test/fastDiag/' ;

$response_href = PDL_FastDiagnosis( $selectedVarInfo_aref, $numberOfBUSIds, $isNextPOC, $fastDiagDataPath );

B<Notes:> 

=cut

sub PDL_FastDiagnosis {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_FastDiagnosis( $selectedVarInfo_aref, $numberOfCANIds, $isNextPOC, $fastDiagDataPath )', @args ) or return;

    my $selectedVarInfo_aref = shift @args;
    my $numberOfBUSIds       = shift @args;
    my $isNextPOC            = shift @args;
    my $fastDiagDataPath     = shift @args;

    my $command = 'FastDiagnosis';

    # STEP Append a / to the path name if there is neither / nor \. It seems the dll needs a final / or \.
    if ( $fastDiagDataPath !~ /[\/\\]$/ ) {
        $fastDiagDataPath .= '/';
    }

    S_w2log( 4, "PDL_$command: Sending service '$command' with Label : '@$selectedVarInfo_aref, Nbr Of BUS IDs : '$numberOfBUSIds', NextPOC : '$isNextPOC' and Data Filepath : '$fastDiagDataPath'\n" );

    if ($main::opt_offline) {
        S_create_dummy_file( $fastDiagDataPath . "/FD1.txt" );
    }

    # CALL SendPDServiceReceiveResponse for fastDiagnosis service
    my $response_href = SendPDServiceReceiveResponse( $command, [ $selectedVarInfo_aref, $numberOfBUSIds, $isNextPOC, $fastDiagDataPath ], [ VT_BSTR | VT_ARRAY, 0, 0, 0 ], 1 );

    # STEP return response_href
    return $response_href;
}

=head2 PDL_StopReadFastdiagData

    $success = PDL_StopReadFastdiagData();
    
Stops a previously started fast diagnosis session.

B<Return Values:>

=over

=item $success

Success/Offline : 1

Error : undef

=back

B<Examples:>

    1 = PDL_StopReadFastdiagData();

B<Notes:> 

=cut

sub PDL_StopReadFastdiagData {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_StopReadFastdiagData()', @args ) or return;

    my $command = 'TerminateFastDiagnosisProcess';

    S_w2log( 4, "PDL_$command: Sending service '$command'\n" );

    if ($main::opt_offline) {
        return 1;
    }

    # CALL CallObjMethod for Stop fastDiagnosis service
    CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, $command );

    # STEP return 1
    return 1;
}

=head2 PDL_GetFastDiagnosisData

    $fastDiagDataPath = PDL_GetFastDiagnosisData();



B<Return Values:>

=over

=item $fastDiagDataPath

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_GetFastDiagnosisData {

    my $fastDiagDataPath;

    S_set_error( "Not yet implemented in PDLayer.dll", 109 );
    return $fastDiagDataPath;
}

=head2 PDL_Smi7Verification

    $response_href = PDL_Smi7Verification( $smi7DataBlock_aref, $noOfSamples );

Sends SMI7 sensor verification service request with configuration $smi7DataBlock_aref and number of data samples ($noOfSamples). 

B<Arguments:>

=over

=item $smi7DataBlock_aref

SMI7 sensor verification service configuration data (array of integers)

=item $noOfSamples

Total number of samples to be read from ECU, noOfSamples should be b/w 2 to 2048 (integer)

=back


B<Return Values:>

=over

=item $response_href

=back


B<Examples:>

B<Notes:> 

=cut

sub PDL_Smi7Verification {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_Smi7Verification( $smi7DataBlock_aref, $noOfSamples )', @args ) or return;
    my $smi7DataBlock_aref = shift @args;
    my $noOfSamples        = shift @args;

    my $command = 'Smi7Verification';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$smi7DataBlock_aref =  " . STR_Aref2HexString($smi7DataBlock_aref) . ", \$noOfSamples = $noOfSamples ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $smi7DataBlock_aref, $noOfSamples ], [ VT_ARRAY | VT_I4, 0 ] );

    return $response_href;
}

=head2 PDL_ManipulateFaultMemory

    $response_href = PDL_ManipulateFaultMemory( $eventID, $isQualify );

Qualifies or dequalifies a single fault in the fault management. This applies to all fault memories. 
After calling this service, the fault management is switched off until the ECU is reset. No faults will qualify after this. 

B<Arguments:>

=over

=item $eventID

Bosch Event ID for the fault, as displayed on fault memory page in PSDiag (integer)

=item $isQualify

If set to true, tries to qualify the fault. If set to false, tries to dequalify the fault

=back

B<Return Values:>

=over

=item $response_href

=back

=cut

sub PDL_ManipulateFaultMemory {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_ManipulateFaultMemory( $eventID, $isQualify )', @args ) or return;
    my $eventID   = shift @args;
    my $isQualify = shift @args;

    my $command = 'ManipulateFaultMemory';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$eventID = $eventID and \$isQualify = $isQualify ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $eventID, $isQualify ] );

    return $response_href;
}

=head2 PDL_GetECUDetails

    $ecuDetails_href = PDL_GetECUDetails($romcode);

Returns the ECU details. This function can be called only after initial login.

B<Arguments:>

=over

=item $romcode

Romcode using which software version is fetched

=back

B<Return Values:>

=over

=item $ecuDetails_href

    $ecuDetails_href = {
        'EcuGeneration'  => 12,
        'PdVersionNr'    => 8,
        'DMC_PlantID'    => plant_id,
        'DMC_LineID'     => line_id,
        'DMC_CounterID'  => counter_id,
        'DMC_Date'       => date,
        'DMC_PartNumber' => part_num,
        'EcuSwVersion'   => SW_version,
    };  

=back

B<Examples:>

    $ecuDetails_href = PDL_GetECUDetails("AB1200_BD_074_BB00000_Cat2");
    
    $ecu_details_href = {
        'DMC_LineID' => '',
        'EcuSwVersion' => 'AB1200_BD_0107_BB000000_Cat2',
        'DMC_PartNumber' => '',
        'DMC_Date' => '',
        'PdVersionNr' => 8,
        'EcuGeneration' => 12,
        'DMC_CounterID' => '',
        'DMC_PlantID' => ''
    }
    
=cut

sub PDL_GetECUDetails {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_GetECUDetails( $romcode)', @args ) or return;

    my $romcode = shift @args;

    S_w2log( 4, "PDL_GetECUDetails: Getting ECU details from last login ...\n" );

    if ( not defined $pdDiagHandle_href ) {
        S_set_error( "PDLayer handle 'PD' not defined. Please call PDL_init_communication before with 'name' = 'PD'.", 109 );
        return;
    }

    if ($main::opt_offline) {
        return {
            'EcuGeneration'  => 12,
            'PdVersionNr'    => 1,
            'DMC_PlantID'    => 'offline',
            'DMC_LineID'     => 'offline',
            'DMC_CounterID'  => 'offline',
            'DMC_Date'       => 'offline',
            'DMC_PartNumber' => 'offline',
            'EcuSwVersion'   => 'offline',
        };
    }

    my $ecuDetails_obj = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'GetECUDetails' );

    if ( ref($ecuDetails_obj) ne 'Win32::OLE' and substr( $ecuDetails_obj, 0, 10 ) ne 'simulation' ) {    # $response_obj ne 'simulation' is to have no error in simulation mode, but 'simulation' has to be set actively using SIM_setReturnValues
        S_set_error( "PDLayer dll function 'GetECUDetails' returned no object. Maybe PDL_EcuLogin was not called before.", 109 );
        return;
    }

    my @detailMethods = ( 'EcuGeneration', 'PdVersionNr', 'DMC_PlantID', 'DMC_LineID', 'DMC_CounterID', 'DMC_Date', 'DMC_PartNumber' );

    my $ecuDetails_href = {};
    foreach my $method (@detailMethods) {
        my $propertyValue = CallObjMethod( $ecuDetails_obj, $method );
        $ecuDetails_href->{$method} = $propertyValue;
        S_w2log( 4, "PDL_GetECUDetails: $method = $propertyValue\n" );
    }

    my $ecu_Sw_ver = PDL_FrameSwVersionBasedonRomCodeLength($romcode);
    unless ($ecu_Sw_ver) {
        S_set_error("PDL_GetECUDetails : Fetching ECU SW version failed with romcode $romcode");
        return;
    }
    $ecuDetails_href->{'EcuSwVersion'} = $ecu_Sw_ver;
    return $ecuDetails_href;
}

=head2 PDL_FrameSwVersionBasedonRomCodeLength

    $swVersion = PDL_FrameSwVersionBasedonRomCodeLength( $romCode );

Returns the software version using the romcode passed as parameter

B<Arguments:>

=over

=item $romcode

Romcode read from SAD file using which software version is fetched

=back

B<Return Values:>

=over

=item $swVersion

=back

B<Examples:>

    $swVersion = PDL_FrameSwVersionBasedonRomCodeLength( "AB1200_BD_074_BB00000_Cat2" );
    
    $swVersion = "AB1200_BD_0107_BB000000_Cat2"

=cut

sub PDL_FrameSwVersionBasedonRomCodeLength {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_FrameSwVersionBasedonRomCodeLength( $romCode )', @args ) or return;
    my $romCode = shift @args;

    if ( not defined $pdDiagHandle_href ) {
        S_set_error( "PDLayer handle 'PD' not defined. Please call PDL_init_communication before with 'name' = 'PD'.", 109 );
        return;
    }

    return 'offline' if ($main::opt_offline);

    my $swVersion = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'FrameSwVersionBasedonRomCodeLength', [$romCode] );
    S_w2log( 3, "PDL_FrameSwVersionBasedonRomCodeLength: SW version read from ECU: $swVersion\n" );

    return $swVersion;
}

=head2 PDL_get_last_response

    $response_href = PDL_get_last_response();

Returns the response hash of the last service that was sent to PDLayer.dll.

B<Return Values:>

=over

=item $response_href

=back

=cut

sub PDL_get_last_response {
    return $lastResponse_href;
}

=head2 PDL_ActivateAIO

    $response_href = PDL_ActivateAIO();

Activates AIO test pattern (service $16H).

B<Return Values:>

=over

=item $response_href

ECU response

=back

=cut

sub PDL_ActivateAIO {

    my $command = 'ActivateAIO';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_SetSecurePIN

    $success = PDL_SetSecurePIN( $cipherText );

Passes the encrypted smartcard PIN to PDLayer.dll for security unlock.

B<Arguments:>

=over

=item $cipherText

Encrypted smartcard PIN as string of bytes.

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise

=back

=cut

sub PDL_SetSecurePIN {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_SetSecurePIN( $cipherText )', @args ) or return;
    my $cipherText = shift @args;

    my $command = 'SetSecurePIN';

    S_w2log( 4, "PDL_$command: Sending service '$command'\n" );

    if ($main::opt_offline) {
        return 1;
    }

    # CALL CallObjMethod for SetSecurePIN
    CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, $command, [$cipherText], [VT_UI1] );

    # STEP return 1
    return 1;
}

=head2 PDL_ReadASICSerialNumbers

    $response_href = PDL_ReadASICSerialNumbers();

Read ASIC Serial Numbers (service $17H).

B<Return Values:>

=over

=item $response_href

ECU response

=back

=cut

sub PDL_ReadASICSerialNumbers {

    my $command = 'ReadASICSerialNumbers';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    my $response_href;
    if ($main::opt_offline) {
        $response_href = ResponseObj2href('offline');
        $response_href->{PdPayload} = [ 0x57, 1 .. 18 ];
        return $response_href;
    }

    $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_SMI8SMA7VerificationStartRoutine

    $response_href = PDL_SMI8SMA7VerificationStartRoutine( $smi8sma7dataBlock_aref, $noOfSamples );

Request the ECU to collect data for SMI8/SMA7 verification (service 0E 01).

B<Arguments:>

=over

=item $smi8sma7dataBlock_aref (array of integer bytes)

4 bytes of data to specify if collected data for the different sensors shall be raw or processed.
See Production diagnosis requirement SRS_PRD_1918 for details.

=item $noOfSamples (integer)

Number of data samples to be collected. Must be > 0 and < 2049. 

=back

B<Return Values:>

=over

=item $response_href

ECU response

=back

=cut

sub PDL_SMI8SMA7VerificationStartRoutine {
    my @args = @_;
    S_checkFunctionArguments( 'PDL_SMI8SMA7VerificationStartRoutine( $smi8sma7dataBlock_aref, $noOfSamples )', @args ) or return;
    my $smi8sma7dataBlock_aref = shift @args;
    my $noOfSamples            = shift @args;

    my $command = 'SMI8SMA7VerificationStartRoutine';
    S_w2log( 4, "PDL_$command: Sending service '$command' with \$smi8sma7dataBlock_aref = " . STR_Aref2HexString($smi8sma7dataBlock_aref) . " and \$noOfSamples = $noOfSamples ...\n" );
    my $response_href = SendPDServiceReceiveResponse( $command, [ $smi8sma7dataBlock_aref, $noOfSamples ], [ VT_ARRAY | VT_I4, 0 ] );

    return $response_href;
}

=head2 PDL_SMI8SMA7VerificationRequestRoutineResults

    $response_href = PDL_SMI8SMA7VerificationRequestRoutineResults();

Request the ECU to return collected data for SMI8/SMA7 verification (service 0E 03).
The command PDL_SMI8SMA7VerificationStartRoutine must be called before in order to get data.
If not NRC 0x24 would be sent by the ECU.

B<Return Values:>

=over

=item $response_href

ECU response

=back

=cut

sub PDL_SMI8SMA7VerificationRequestRoutineResults {

    my $command = 'SMI8SMA7VerificationRequestRoutineResults';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_ReadECULifeCycle

    $response_href = PDL_ReadECULifeCycle();

Request ECU to read the current ECU life cycle data.

B<Arguments:> NONE

B<Return Values:>

=over

=item $response_href

ECU response with the life cycle data

=back

=cut

sub PDL_ReadECULifeCycle {
    my $command = 'ReadECULifeCycle';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    # CALL SendPDServiceReceiveResponse
    my $response_href = SendPDServiceReceiveResponse($command);

    return $response_href;
}

=head2 PDL_SwitchECULifeCycle

    $response_href = PDL_SwitchECULifeCycle($delayInPOC, $ecuMainLifeCycle);

Request ECU to switch ECU life cycle data.

B<Arguments:>

=over

=item $delayInPOC

Number of POC's after which ecu life cycle will be switched.

=item $ecuMainLifeCycle

ECU life cycle to which ECU has to switch.

=back

B<Return Values:>

=over

=item $response_href

ECU response for switch ECU life cycle

=back

=cut

sub PDL_SwitchECULifeCycle {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_SwitchECULifeCycle( $delayInPOC, $ecuMainLifeCycle )', @args ) or return;
    my $delayInPOC       = shift @args;
    my $ecuMainLifeCycle = shift @args;

    my $command = 'SwitchECULifeCycle';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    # CALL SendPDServiceReceiveResponse
    my $response_href = SendPDServiceReceiveResponse( $command, [ $delayInPOC, $ecuMainLifeCycle ] );

    return $response_href;
}

=head2 PDL_SHEKeyCalculatorProtocol

    $response_href = PDL_SHEKeyCalculatorProtocol($m1_aref, $m2_aref, $m3_aref, $sheKeyExtensionId, $bankIndex_aref);

writes SHE key to ECU.

B<Arguments:>

=over

=item $m1_aref

16 bytes hex array.

=item $m2_aref

32 bytes hex array.

=item $m3_aref

16 bytes hex array.

=item $sheKeyExtensionId

This is single byte.

=item $bankIndex_aref

This is 4 byte hex array ref.

=back

B<Return Values:>

=over

=item $response_href

ECU response containing M4 and M5

=back

=cut

sub PDL_SHEKeyCalculatorProtocol {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_SHEKeyCalculatorProtocol( $m1_aref, $m2_aref, $m3_aref, $sheKeyExtensionId, $bankIndex_aref )', @args ) or return;
    my $m1_aref           = shift @args;
    my $m2_aref           = shift @args;
    my $m3_aref           = shift @args;
    my $sheKeyExtensionId = shift @args;
    my $bankIndex_aref    = shift @args;

    my $command = 'SHEKeyCalculatorProtocol';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    map { $_ = hex $_ } @$m1_aref;
    map { $_ = hex $_ } @$m2_aref;
    map { $_ = hex $_ } @$m3_aref;
    map { $_ = hex $_ } @$bankIndex_aref;
    $sheKeyExtensionId = hex $sheKeyExtensionId;

    # CALL SendPDServiceReceiveResponse
    my $response_href = SendPDServiceReceiveResponse( $command, [ $m1_aref, $m2_aref, $m3_aref, $sheKeyExtensionId, $bankIndex_aref ], [ VT_ARRAY | VT_I4, VT_ARRAY | VT_I4, VT_ARRAY | VT_I4, 0, VT_ARRAY | VT_I4, ] );

    return $response_href;
}

=head2 PDL_ReceiveResponseFromKMS

    $response_href = PDL_ReceiveResponseFromKMS($challenge_aref);

This service sends challenge from ECU to KMS , and returns received response.

B<Arguments:>

=over

=item $challenge_aref

Challenge received from ECU which is to be sent to KMS.

=back

B<Return Values:>

=over

=item $response_href

KMS response.

=back

=cut

sub PDL_ReceiveResponseFromKMS {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_ReceiveResponseFromKMS( $challenge_aref )', @args ) or return;
    my $challenge_aref = shift @args;

    my $command = 'ReceiveResponseFromKMS';
    S_w2log( 4, "PDL_$command: Sending service '$command' ...\n" );

    # CALL SendPDServiceReceiveResponse
    my $response_href = SendPDServiceReceiveResponse( $command, [$challenge_aref], [ VT_ARRAY | VT_I4 ] );

    return $response_href;
}

=head2 PDL_Enable_KMS_Simulator

    $success = PDL_Enable_KMS_Simulator($kms_simulator_mode);

This service sends the command to enable or dsiable the KMS simulator.

B<Arguments:>

=over

=item $kms_simulator_mode : 1|0

1: Enable the KMS simulator.
0: Disable the KMS simulator.

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise

=back

=cut

sub PDL_Enable_KMS_Simulator {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_Enable_KMS_Simulator( $kms_simulator_mode )', @args ) or return;
    my $kms_simulator_mode = shift @args;

    my $command = 'SetKMSSimulationActivationStatus';

    S_w2log( 4, "PDL_$command: Sending service '$command'\n" );

    if ($main::opt_offline) {
        return 1;
    }

    # CALL CallObjMethod for SetKMSSimulationActivationStatus
    CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, $command, [$kms_simulator_mode] );

    # STEP return 1
    return 1;

}

=head2 PDL_SetAutoLogin

    $success = PDL_SetAutoLogin($enbale_or_disable_bool);

This service Enables or Disables autologin feature.

B<Arguments:>

=over

=item $enbale_or_disable_bool : 1|0

1: Enable Autologin.
0: Disable Autologin.

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise

=back

=cut

sub PDL_SetAutoLogin {

    my @args = @_;
    S_checkFunctionArguments( 'PDL_SetAutoLogin( $enbale_or_disable_bool )', @args ) or return;
    my $enbale_or_disable_bool = shift @args;

    my $command = 'SetAutoLoginStatus';

    S_w2log( 4, "PDL_$command: Sending service '$command'\n" );

    if ($main::opt_offline) {
        return 1;
    }

    # CALL CallObjMethod for SetAutoLoginStatus
    CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, $command, [$enbale_or_disable_bool] );

    # STEP return 1
    return 1;

}

=head1 Not exported functions

=head2 Get_OleObject

    $object = Get_OleObject( $dllName );

Gets the COM/OLE object from the $dllName.  

B<Examples:>

    $pdLayer_obj = Get_OleObject( 'PDLayer.ProductionDiagnosis.1.3' )  

=cut

sub GetOleObject {
    my @args = @_;

    return unless S_checkFunctionArguments( 'GetOleObject ( $dllName )', @args );
    my $dllName = shift @args;

    #STEP Create a new Win32::OLE object for $dllName
    my $object = Win32::OLE->new($dllName);

    #IF Object is defined?
    if ( not defined $object ) {

        #IF-NO-START
        #STEP Throw error and return
        S_set_error( "Could not create COM connection to dll $dllName : " . Win32::OLE->LastError(), 111 );
        return;

        #IF-NO-END
    }

    #IF-YES-START

    #STEP Return object
    return $object;

    #IF-YES-END
    #STEP End
}

=head2 GetObjProperty

    $propertyValue = GetObjProperty ($object_mix, $property);

retrieves directly the value of COM '$property' from the object '$object_mix'.    

B<Examples:>

    my $raw_value = GetObjProperty( $signal_object, 'RawValue' );

=cut

sub GetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'GetObjProperty ($object_mix, $property)', @args );
    my $object   = shift @args;
    my $property = shift @args;

    my $propertyValue;
    $propertyValue = $object->{$property};
    return $propertyValue;
}

=head2 SetObjProperty

    SetObjProperty ($object_mix, $property, $propertyValue);

Set directly the '$propertyValue' to COM '$property' of object '$object_mix'.

B<Examples:>

    SetObjProperty( $signal_object, 'RawValue', $signal_value_raw_to_wr );    
    
=cut

sub SetObjProperty {
    my @args = @_;
    return unless S_checkFunctionArguments( 'SetObjProperty ($object_mix, $property, $propertyValue_mix)', @args );
    my $object        = shift @args;
    my $property      = shift @args;
    my $propertyValue = shift @args;

    $object->{$property} = $propertyValue;
    return 1;
}

=head2 CallObjMethod

    $result = CallObjMethod ($object_mix, $methodName, [, $methodArgs_aref]);
    ($result, $argByRef1, ...) = CallObjMethod ($object_mix, $methodName, [, $methodArgs_aref, $argTypes_aref]);

Invokes on the object $object_mix the method $methodName. Arguments for the method (if required) can be given in $methodArgs_aref.
If arguments are arrays and/or shall be passed by reference then the argument types must be defined in $argTypes_aref.

B<Arguments:>

=over

=item $object_mix

OLE object on which the method shall be called.

=item $methodName

Name of the method that shall be called.

=item $methodArgs_aref

(Optional) List of arguments for the method. Arguments can be scalars or OLE objects or array references.
If arguments are arrays and/or shall be passed by reference then the argument types must be defined in $argTypes_aref.
In that case for each element of $methodArgs_aref the type must be defined in $argTypes_aref. 

=item $argTypes_aref

(Optional) List of argument types. 
The type of an argument can be either 0 if the argument is neither array nor by reference. 
Or the type can be described by the constants defined in 
L<Win32::OLE::Variant|http://search.cpan.org/~jdb/Win32-OLE-0.1712/lib/Win32/OLE/Variant.pm#Constants> (see last example).

=back


B<Return Values:>

=over

=item $result

Return value of the method call. Is either a scalar or an OLE object.

=item arguments passed by reference

If any arguments are passed by reference then they are additionaly returned in the order in which they were given.

=back

B<Examples:>

    my $result = CallObjMethod( $object, 'method1' );        
    my $result = CallObjMethod( $object, 'method2', [$scalarArg] );        
    my ($result, $integerByRef) = CallObjMethod( $object, 'method3', [$scalarArg, \@listOfStrings, $integerByRef], [0 , VT_ARRAY | VT_BSTR , VT_I4 | VT_BYREF] );        
    
=cut

sub CallObjMethod {
    my @args = @_;

    return unless S_checkFunctionArguments( 'CallObjMethod ( $object_mix, $methodName [, $methodArgs_aref, $argTypes_aref])', @args );
    my $object          = shift @args;
    my $methodName      = shift @args;
    my $methodArgs_aref = shift @args;
    my $argTypes_aref   = shift @args;
    my $result;

    #S_w2log( 5, "Calling method '$methodName' on object '$object' ...\n" );
    # Invoke the method
    if ( not defined $methodArgs_aref ) {

        #STEP On object $object_mix call method $methodName without arguments
        $result = $object->$methodName();
        return $result;
    }
    elsif ( not defined $argTypes_aref ) {

        #STEP On object $object_mix call method $methodName with argument array as it is (assuming only scalar arguments)
        $result = $object->$methodName(@$methodArgs_aref);
        return $result;
    }
    else {
        if ( scalar(@$methodArgs_aref) != scalar(@$argTypes_aref) ) {
            S_set_error( "Given number of arguments does not match given number of argument types.", 109 );
            return;
        }
        my @variantArgs;
        foreach my $argumentIndex ( 0 .. @$methodArgs_aref - 1 ) {
            my $argumentValue = $$methodArgs_aref[$argumentIndex];
            my $argumentType  = $$argTypes_aref[$argumentIndex];
            if ( $argumentType == 0 ) {
                push( @variantArgs, $argumentValue );
            }
            else {
                my $values_OLEvariant;
                if ( ref($argumentValue) eq 'ARRAY' ) {
                    $values_OLEvariant = Variant( $argumentType, scalar(@$argumentValue) );
                }
                else {
                    $values_OLEvariant = Variant( $argumentType, $argumentValue );
                }
                $values_OLEvariant->Put($argumentValue);
                push( @variantArgs, $values_OLEvariant );
            }
        }

        #STEP On object $object_mix call method $methodName with argument array
        $result = $object->$methodName(@variantArgs);
        my @returnList = ($result);
        foreach my $argumentIndex ( 0 .. @$methodArgs_aref - 1 ) {
            my $argumentType = $$argTypes_aref[$argumentIndex];
            if ( $argumentType & VT_BYREF ) {
                my $variant = $variantArgs[$argumentIndex];
                my $value   = $variant->Value();
                push( @returnList, $value );
            }
        }
        return @returnList;
    }

}

sub Dec2HexString {
    my $decNumber      = shift;
    my $numberOfDigits = shift;

    my $format;
    if ( defined $numberOfDigits ) {
        $format = '%0' . $numberOfDigits . 'X';
    }
    else {
        $format = '%X';
    }

    my $hexString = '0x' . sprintf( $format, $decNumber );

    return $hexString;
}

sub ResponseObj2href {
    my $response_obj       = shift;
    my $pdLayer_obj        = shift;
    my $onlyStatusExpected = shift;

    my $response_href = {};
    $lastResponse_href = $response_href;    # creates a global pointer to $response_href, so everything that will be done with $response_href
                                            # will be visible also in $lastResponse_href

    if ( $response_obj eq 'offline' ) {
        $response_href->{Checksum}         = 1;
        $response_href->{Id}               = 80;
        $response_href->{PdLength}         = 2;
        $response_href->{CompletePdMsg}    = [ 2, 80, 1 ];
        $response_href->{PdPayload}        = [80];
        $response_href->{ErrorDescription} = 'OK';
        $response_href->{Status}           = 0;
        return $response_href;
    }

    if ( ref($response_obj) ne 'Win32::OLE' and substr( $response_obj, 0, 10 ) ne 'simulation' ) {    # $response_obj ne 'simulation' is to have no error in simulation mode, but 'simulation' has to be set actively using SIM_setReturnValues
        $response_href->{Status}           = -999;
        $response_href->{ErrorDescription} = "No Win32::OLE object returned from PDLayer.dll";
        return $response_href;
    }

    $response_href->{Status} = CallObjMethod( $response_obj, 'GetStatus' );

    if ( defined $response_href->{Status} ) {
        $response_href->{ErrorDescription} = CallObjMethod( $pdLayer_obj, 'GetErrorDescription', [ $response_href->{Status} ] );
    }
    else {
        $response_href->{Status}           = -998;
        $response_href->{ErrorDescription} = "No object status returned from PDLayer.dll";
        $onlyStatusExpected                = 1;
    }

    #In case of queue empty or timeout only status and error description is expected
    if ( $response_href->{ErrorDescription} =~ /$noResponseRegex/ ) {
        $onlyStatusExpected = 1;
    }

    if ($onlyStatusExpected) {
        $response_href->{Checksum}      = undef;
        $response_href->{Id}            = undef;
        $response_href->{PdLength}      = undef;
        $response_href->{CompletePdMsg} = [];
        $response_href->{PdPayload}     = [];

        return $response_href;
    }

    my $method4attribute_href = {

        # <key of data hash> => <object method>
        'Checksum'      => 'Checksum',
        'Id'            => 'Id',
        'PdLength'      => 'PdLength',
        'CompletePdMsg' => 'GetCompletePdMsg',
        'PdPayload'     => 'GetPdPayload',
    };

    foreach my $key ( sort keys %{$method4attribute_href} ) {
        my $method = $method4attribute_href->{$key};
        if ( $method eq 'GetPdPayload' and @{ $response_href->{CompletePdMsg} } <= 2 ) {    # if CompletePdMsg is only 2 bytes or less (e.g. for WriteCell) then calling GetPdPayload would give an exception from the dll
            $response_href->{$key} = [];
            next;
        }
        $response_href->{$key} = CallObjMethod( $response_obj, $method );
    }

    # No error shall be set for the following status values
    # -915 : NRC55_RDEDR__VALID_DID_EMPTY_CRASH_ENTRY
    # -988 : NRC78_SMI8SMA7_REQ_ROUTINE_RESULTS_BEFORE_DATACOLLECTION_FINISHED
    if ( $response_href->{Status} == -915 or $response_href->{Status} == -988 ) {
        $response_href->{Status} = 1;
    }

    return $response_href;
}

sub SetComPdParam {
    my $comPdParam_obj = shift;
    my $busParams_href = shift;

    #LOOP-START Loop over keys of $busParams_href
    foreach my $busParameter ( keys %{$busParams_href} ) {

        #next if $busParameter eq 'name';
        my $value = $busParams_href->{$busParameter};

        #CALL CallObjMethod ($comPdParam_obj, 'SetParam', [ key, value ] )
        CallObjMethod( $comPdParam_obj, 'SetParam', [ $busParameter, $value ] );
    }

    #LOOP-END Last key?

    #STEP End
    return 1;
}

sub SendServiceReceiveResponse {
    my $diagHandle_href    = shift;
    my $serviceName        = shift;
    my $arguments_aref     = shift;
    my $argumentTypes_aref = shift;
    my $onlyStatusExpected = shift;

    my $handleName = $diagHandle_href->{name};

    S_w2log( 4, "SendServiceReceiveResponse: Sending service '$serviceName' to PDLayer handle '$handleName' ...\n" );

    my $response_href;
    if ($main::opt_offline) {
        $response_href = ResponseObj2href('offline');
        return $response_href;
    }

    #CALL CallObjMethod ($pdDiagHandle_href->{'OLE_handle'}, $serviceName, $arguments_aref) to get a response object
    my ($response_obj) = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, $serviceName, $arguments_aref, $argumentTypes_aref );

    #CALL ResponseObj2href (response object) to get a response hash
    $response_href = ResponseObj2href( $response_obj, $pdDiagHandle_href->{'OLE_handle'}, $onlyStatusExpected );

    #STEP write complete response (if defined) to log
    if ( defined $response_href->{'CompletePdMsg'} ) {
        my $completeMessageString = STR_Aref2HexString( $response_href->{'CompletePdMsg'} );
        S_w2log( 4, "SendServiceReceiveResponse: Received '$completeMessageString'\n" );
    }

    #CALL CheckResponseForError
    CheckResponseForError( $response_href, $serviceName, $handleName ) or return;

    #STEP Return response hash
    return $response_href;
}

=head2 CheckResponseForError

    $success = CheckResponseForError($response_href, $serviceName, $handleName);

Checks if an error needs to be thrown for response $response_href and service $serviceName.
If so it creates the error message and throws the error.

Returns 1 if the response is no error, otherwise undef. 

=cut

sub CheckResponseForError {
    my $response_href = shift;
    my $serviceName   = shift;
    my $handleName    = shift;

    my $responseStatus = $response_href->{Status};

    #STEP if service is "SendReceiveData" then do not throw an error, except for -999 (no object from PDLayer)
    if ( $serviceName eq "SendReceiveData" and $responseStatus != -999 ) {
        S_w2log( 4, "SendServiceReceiveResponse: No response received on request 'SendReceiveData'.\n" ) if $responseStatus == -941;
        return 1;
    }

    #IF response status is < 0 or == 160?
    if ( $responseStatus < 0 or $responseStatus == 160 ) {

        #IF-YES-START
        #STEP set general error text
        my $errorDescription = $response_href->{ErrorDescription};
        my $errorText        = "Response status '$responseStatus' after sending service '$serviceName' to PDLayer handle '$handleName'. Error description: $errorDescription";

        #STEP special error text for status -974 (no PIN)
        if ( $responseStatus == -974 ) {
            $errorText = "ECU is locked but no PIN was provided for secure login using smartcard and PIN. Please call the function for secure PIN entry before diagnosis login.\n" . $errorText;
        }

        #STEP special error text for status 160 (wrong PIN)
        elsif ( $responseStatus == 160 ) {
            $errorText =
"ECU is locked and wrong PIN was provided for secure login using smartcard and PIN. Please repeat the test and provide the correct PIN for the given smartcard. Please note that the smartcard is locked after 3 times providing the wrong PIN. In such cases also this error will come. To check if a smartcard is locked can be done using C:\\ubkpki_pkcs11provider\\MiddlewareVerifier.exe. If the smartcard is locked you can unlock it using your PUK according to the procedure shown in the link under point 7: https://inside-docupedia.bosch.com/confluence/display/escryptitoperations/Smartcard+Guide .\n"
              . $errorText;
        }

        #STEP special error text for no response
        elsif ( $errorDescription =~ /$noResponseRegex/ ) {
            $errorText = "No (proper) response from ECU.
            This may be due to any of the below reasons:
            1. ECU is OFF at this instant (most probable if communication was successful before)
            2. In project const section: 'ProdDiag' a wrong 'ProjectName' is configured
            3. In LIFT_testbenches.pm section: 'Devices' => 'PDLayer' a wrong 'Channel_Nbr_0-based' is given\n" . $errorText;
        }

        #STEP Throw error and return
        S_set_error( $errorText, 109 );
        return;

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP return 1
    return 1;
}

sub SendPDServiceReceiveResponse {
    my $serviceName        = shift;
    my $arguments_aref     = shift;
    my $argumentTypes_aref = shift;
    my $onlyStatusExpected = shift;

    if ( not defined $pdDiagHandle_href ) {
        S_set_error( "PDLayer handle 'PD' not defined. Please call PDL_init_communication before with 'name' = 'PD'.", 109 );
        return;
    }

    my $response_href = SendServiceReceiveResponse( $pdDiagHandle_href, $serviceName, $arguments_aref, $argumentTypes_aref, $onlyStatusExpected );

    return $response_href;
}

sub AddMemoryData2Response {
    my $response_href = shift;
    my $format_data_by_endianness = shift // 1;

    # get data bytes from payload
    my $payload_aref = $response_href->{PdPayload};
    my @dataBytes    = @$payload_aref;
    shift @dataBytes;    # remove ID

    if ($main::opt_offline) {
        $response_href->{DataBytes} = [1];
        return [1];
    }

    # correct order of bytes in data, depending on endianness
    my $dataBytesCorr_aref;
    if ($format_data_by_endianness) {

        # correct for endianness
        $dataBytesCorr_aref = FormatMemoryDatabyEndianness( \@dataBytes );
    }
    else {
        # take data bytes as they are
        $dataBytesCorr_aref = \@dataBytes;
    }

    $response_href->{DataBytes} = $dataBytesCorr_aref;

    return $dataBytesCorr_aref;
}

sub CatchOleException {
    my $errorText = Win32::OLE->LastError();

    return 1 if $errorText !~ /PDLayer/;    # only react on OLE exceptions from PDLayer

    if ( $errorText =~ /Invalid pointer|Invalid index/ ) {
        S_w2log( 3, "$errorText" );
    }
    else {
        S_set_error( "$errorText", 23 );
    }
    return;
}

=head2 CheckPreconditions

    CheckPreconditions();

This functions checks the handles for Production Diagnosis are initialised.

B<Return Values:>

    Success: 1
    Failure: undef 

=cut

sub CheckPreconditions {
    my $callingFunction = ( caller(1) )[3];
    $callingFunction = 'main' if not defined $callingFunction;
    $callingFunction =~ s/^\w+\:\://g;

    if ( not defined $pdDiagHandle_href ) {
        S_set_error( "PDLayer handle 'PD' not defined. Please call PDL_init_communication before with 'name' = 'PD' before using the function '$callingFunction'.", 109 );
        return;
    }
    return 1;
}

=head2 Extract_Parameters_From_NvM_Address

    $nvm_Parameters_aref = Extract_Parameters_From_NvM_Address( $address );
    
Splits the NVM address into below mentioned format

Reads the NVM data based on the Block ID.

    Example : How to extract the parameters from NvM Address :
    Address : 201A0000
    2 : Its an indication for NVM address range
    01A : Block ID
    0 : SubBlockID
    000 : Offset

B<Arguments:>

=over

=item $address

NVM address

=back

B<Return Values:>

=over

=item $nvm_Parameters_aref

array reference to the Parameters(nvmAddrRangeIndex, nvmBlockId, nvmSubBlockId, nvmOffset) obtained from NVM address

=back


B<Examples:>

B<Notes: Not Exported function>

=cut

sub Extract_Parameters_From_NvM_Address {
    my @args = @_;
    S_checkFunctionArguments( 'Extract_Parameters_From_NvM_Address($address)', @args ) or return;
    my $address = shift @args;

    #Example : How to extract the parameters from NvM Address :
    #Address : 201A0000
    #2   : Its an indication for NVM address range
    #01A : Block ID
    #0   : SubBlockID
    #000 : Offset
    my @nvmParameters = $address =~ /(.)(...)(.)(...)/g;

    if ( scalar(@nvmParameters) != 4 ) {
        S_set_error( "Extract_Parameters_From_NvM_Address : $address is not an valid NVM address'", 114 );
        return;
    }

    return \@nvmParameters;

}

# Formats the memory bytes as per the ECU endianness
sub FormatMemoryDatabyEndianness {
    my @args = @_;
    S_checkFunctionArguments( 'FormatMemoryDatabyEndianness( $memoryContent_aref )', @args ) or return;
    my $memoryContent_aref = shift @args;

    return [1] if ($main::opt_offline);

    my ($dataBytesCorr_aref) = CallObjMethod( $pdDiagHandle_href->{'OLE_handle'}, 'FormatMemoryDatabyEndianness', [$memoryContent_aref], [ VT_I4 | VT_ARRAY ] );

    return $dataBytesCorr_aref;
}

=head2 CheckRegisteredCOMdll

    $success = CheckRegisteredCOMdll( $dllName );
    
Check if path and version of the registered COM dll ($dllName) matches the corresponding Engine dll.

    If path of registered dll == path of Engine dll then OK.
    Else:
        If version of the registered dll == version of the Engine dll then OK
        If version of the registered dll > version of the Engine dll then OK, but Warning
        If version of the registered dll < version of the Engine dll then Error

B<Arguments:>

=over

=item $dllName

Program ID of the registered PDLayer dll

=back

B<Return Values:>

=over

=item $success

1 on success, undef otherwise

=back

B<Note: Not exported function>

=cut

sub CheckRegisteredCOMdll {
    my $dllName = shift;

    #CALL LIFT_general::S_get_version_and_path_of_registered_COM_dll with $dllName
    my $versionPathRegisteredDll_href = S_get_version_and_path_of_registered_COM_dll($dllName);

    #STEP Error if $dllName is not registered
    if ( not defined $versionPathRegisteredDll_href->{fullPath} ) {
        S_set_error( "PDLayer.dll ($dllName) is not registered as COM dll on this computer. Trying to register now. Please re-run the test after successful registration.", 109 );
        S_register_COM_dlls();
        return;
    }
    S_w2log( 3, "PDL_init: Using registered dll " . $versionPathRegisteredDll_href->{fullPath} . " version " . $versionPathRegisteredDll_href->{version} . "\n" );

    #CALL LIFT_general::S_get_version_and_path_of_dll_on_file_system with absolute path of registered dll
    my $realVersionPathRegisteredDll_href = S_get_version_and_path_of_dll_on_file_system( $versionPathRegisteredDll_href->{fullPath} );
    S_w2log( 3, "PDL_init: Real version of registered dll on disk is " . $realVersionPathRegisteredDll_href->{version} . "\n" );

    #CALL LIFT_general::S_get_version_and_path_of_dll_on_file_system with relative path of registered dll
    $versionPathRegisteredDll_href->{relativePath} =~ s|/DLLs/|/Device_layer/|i;    # in relative path replace 'DLLs' with 'Device_layer' in case the dll was registered with an engine F or older
    my $versionPathEngineDll_href = S_get_version_and_path_of_dll_on_file_system( $versionPathRegisteredDll_href->{relativePath} );

    #IF path of registered dll != path of Engine dll?
    if ( $versionPathRegisteredDll_href->{fullPath} ne $versionPathEngineDll_href->{fullPath} ) {

        #IF-YES-START
        S_w2log( 3, "PDL_init: INFO:     Engine dll " . $versionPathEngineDll_href->{fullPath} . " is not the registered dll.\n" );

        #STEP Throw error if version of the registered dll < version of the Engine dll and return
        if ( version->parse( $realVersionPathRegisteredDll_href->{version} ) < version->parse( $versionPathEngineDll_href->{version} ) ) {
            S_set_error(
                "The version number ("
                  . $realVersionPathRegisteredDll_href->{version}
                  . ") of the registered dll ("
                  . $versionPathRegisteredDll_href->{fullPath}
                  . ")\n is lower than the version number ("
                  . $versionPathEngineDll_href->{version}
                  . ") of the Engine dll ("
                  . $versionPathEngineDll_href->{fullPath}
                  . ").\nTrying to register the Engine dll now. Please re-run the test after successful registration.",
                109
            );
            S_register_COM_dlls();
            return;
        }

        #STEP Throw warning if version of the registered dll > version of the Engine dll
        elsif ( version->parse( $realVersionPathRegisteredDll_href->{version} ) > version->parse( $versionPathEngineDll_href->{version} ) ) {
            S_set_warning( "The version number ("
                  . $realVersionPathRegisteredDll_href->{version}
                  . ") of the registered dll ("
                  . $versionPathRegisteredDll_href->{fullPath}
                  . ")\n  is higher than the version number ("
                  . $versionPathEngineDll_href->{version}
                  . ") of the Engine dll ("
                  . $versionPathEngineDll_href->{fullPath}
                  . ").\nYou may want to run in your sandbox 'Engine\\run_once\\register_com_dlls.bat' as administrator to register the version of PDLayer.dll in your sandbox." );
        }

        #STEP Print info if version of the registered dll == version of the Engine dll
        else {
            S_w2log( 3, "PDL_init: The registered dll and the Engine dll have the same version number (" . $realVersionPathRegisteredDll_href->{version} . "). Looks OK.\n" );
        }

        #IF-YES-END
    }

    #IF-NO-START
    #IF-NO-END

    #STEP Return 1
    return 1;
}

############################################################################################################
#
#
# Simulation mode
#
#
############################################################################################################

if ($main::opt_simulation) {

    my @redefinedFunctions = qw(
      GetOleObject
      GetObjProperty
      SetObjProperty
      CallObjMethod
    );

    # redefine functions for simulation mode with default return values
    foreach my $function (@redefinedFunctions) {
        no strict 'refs';

        # each function specifed is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {};
    SIM_addToValuesTable($returnValuesTable_href);
}

1;
