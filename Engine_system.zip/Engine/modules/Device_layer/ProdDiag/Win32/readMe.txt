1) 	Path to get the Dlls from the PsDiag Team :
	https://rb-airbag-artifactory.de.bosch.com/list/ab12_tools/PSDiag/ProductionDiagnosisDLL/