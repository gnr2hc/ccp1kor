package FLUKE45;

use strict;
use warnings;

use Win32::SerialPort;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use FLUKE45 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our ($VERSION,$HEADER);


my $MAXtimeout = 500;

=head1 NAME

FLUKE45 

Perl extension for FLUKE 45 multi meter

=head1 SYNOPSIS

    use FLUKE45;

    my ($flu, $voltage, $status, $DeviceID);

    $flu = FLUKE45->new(\*LOG);
    ($status,$DeviceID) = $flu->connect('COM:1');
    ($status,$voltage) = $flu->getDCvoltage();
    $status = $flu->disconnect();


=head1 DESCRIPTION

remote control functions for FLUKE 45 multi meter using COM port

=cut


=head1 CONSTRUCTOR

=head2 $flu = FLUKE45->new(\*LOG);

creates an instance of a PPS object and returns its handle

writes into give logfile, if no filehandle is given log_FLUKE45pm.txt is created, 

=cut


my $COM;
my $logfile_handle;
my $stat;


sub new {
    my $class = shift;
    $logfile_handle=shift;
    unless ($logfile_handle) {
        open ( FLULOG,">log_FLUKE45pm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*FLULOG;
    }
    my $self = {};
    bless ($self, $class);
    w2log("creating new FLUKE45 instance\n");
    $self->{connected} = 0; # set connencted flag to false
    $self->{ID} = "";
    return $self;
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 ($status,$DeviceID) = $flu->connect($connection);

Connnect to FLUKE via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used.   

A valid connection is e.g. 'COM:1'. Make sure multi meter is configured accordingly !

=cut

sub connect {
    my $self = shift;

    my ($mode,$DeviceID);
    my $connection = shift;
    w2log("connecting with FLUKE45 via <$connection>\n");

    if($connection =~ /COM:\s*(\d+)/i){
        my $comnr=$1;
    
        $self->{COM} = new Win32::SerialPort("COM$comnr") || Global::Exit("Cannot open COM port $comnr");
        $COM = $self->{COM};
        # setting up all parameters for COM port
        $COM->error_msg(1);
        $COM->user_msg(1);
        $COM->baudrate(9600);
        $COM->parity('none');
        $COM->databits(8);
        $COM->stopbits(1);
        $COM->handshake('none');
        $COM->binary('T');
        $COM->parity_enable('F');
        $COM->buffers(4096, 4096);
        $COM->write_settings() || Global::Exit("Error when configuring COM port $comnr");

        $stat = writeString($self,"*IDN?");
        ($stat,$DeviceID) = readString($self);
        return(-1,"unknown") if ($stat < 0);

        chomp($DeviceID);
        w2log("Device is <$DeviceID>\n");
        $self->{connected} = 1; # set connencted flag to true
        $self->{ID} = "{$DeviceID}";
        return(0,$DeviceID);

    }
    else{
      w2log("ERROR: connection error for GOS64D42P on <$connection>\n");
      $self->{connected} = 0; # set connencted flag to false
      return(-1,"unknown");
    }

}




############################################################################################################

=head2 $status = $flu->disconnect();

Disconnect from FLUKE

=cut

sub disconnect{
    my $self = shift;
    w2log("disconnecting FLUKE45 $self->{ID}\n");
    undef $self->{ID};
    $self->{connected} = 0; # set connencted flag to false
    return(0);

}



############################################################################################################

=head2 ($status,$voltage) = $flu->getACvoltage();

read AC voltage from FLUKE main display

=cut

sub getACvoltage{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"VAC");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}

############################################################################################################

=head2 ($status,$voltage) = $flu->getDCvoltage();

read DC voltage from FLUKE main display

=cut

sub getDCvoltage{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"VDC");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}



############################################################################################################

=head2 ($status,$voltage) = $flu->getACcurrent();

read AC current from FLUKE main display

=cut

sub getACcurrent{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"AAC");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}


############################################################################################################

=head2 ($status,$voltage) = $flu->getDCcurrent();

read DC current from FLUKE main display

=cut

sub getDCcurrent{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"ADC");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}

############################################################################################################

=head2 ($status,$voltage) = $flu->getResistance();

read resistance from FLUKE main display

=cut

sub getResistance{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"OHMS");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}

############################################################################################################

=head2 ($status,$voltage) = $flu->getFrequency();

read frequency from FLUKE main display

=cut

sub getFrequency{
    my $self = shift;
    my $voltage;

    $stat = writeString($self,"FREQ");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    $stat = writeString($self,"VAL1?");
    ($stat,$voltage) = readString($self);
    return(-1,"unknown") if ($stat < 0);

    return(0,$voltage);

}


######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut



############################################################################################################

=head2 $status = $flu->writeString($string);

write string directly to FLUKE

=cut

sub writeString{
  my $self = shift;
  $COM = $self->{COM};
  my $string = shift;
  w2log("writing {$string} to $self->{ID} ");

  my $count_out = $COM->write($string.chr(10));
  if ( $count_out != length($string)+1 ){
      w2log("ERROR: write incomplete ($count_out < ".(length($string)+1).")\n");
      return(-1);
  
  }
  else{ 
      w2log("ok ($count_out)\n");
      return(0);
  }
   
}



############################################################################################################

=head2 ($status,$string) = $flu->readString();

read string directly from FLUKE

=cut

sub readString{
  my $self = shift;
  $COM = $self->{COM};
    my $buf="";
    my $data="";
    my $ret="";
    my $count=0;
    my $timeoutcounter=0;
     
    while(ord($buf) != 10){
     ($count, $buf) = $COM->read(1);
      $data.=$buf;
      if (ord($buf) == 0){
        $timeoutcounter++;
        select(undef, undef, undef, 0.01); #sleep 10 ms
      }
      else{
        $timeoutcounter=0;
      }
      if ($timeoutcounter > $MAXtimeout){
        w2log ("ERROR: timeout!\n");
        return (-1,'');
      }
    }

     chop($data);
     chop($data);
     chomp($data);

    if ($data eq "?>"){
      w2log ("ERROR: $data unknown command\n");
      return (-1,'');
    }
    elsif ($data eq "!>"){
      w2log ("ERROR: $data could not execute command\n");
      return (-1,'');
    }
    elsif ($data eq "=>"){
      #w2log (" ok\n");
      $data = "command executed";
    }
    else{

        $ret=$buf="";
        while(ord($buf) != 10){
         ($count, $buf) = $COM->read(1);
          $ret.=$buf;
          if (ord($buf) == 0){
            $timeoutcounter++;
            select(undef, undef, undef, 0.01); #sleep 10 ms
          }
          else{
            $timeoutcounter=0;
          }
          if ($timeoutcounter > $MAXtimeout){
            w2log ("ERROR: timeout!\n");
            return (-1,"");
          }
        }
        chop($ret);
        chop($ret);
        chomp($ret);

        if ($ret eq "?>"){
          w2log ("ERROR: $ret unknown command\n");
          return (-1,'');
        }
        elsif ($ret eq "!>"){
          w2log ("ERROR: $ret could not execute command\n");
          return (-1,'');
        }
        elsif ($ret eq "=>"){
          #w2log (" -> ok\n");
        }
        else {w2log ("ERROR: unexpected response $ret\n");return (-1,'');}
        
    }
    w2log("reading {$data} from $self->{ID}\n");

   return (0,$data);


}



############################################################################################################

=head2 $value = $flu->isConnected();

check if FLUKE is connected returns 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    return($self->{connected});
}





##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text if (defined $logfile_handle);
     print $text;
}



# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, FLUKE manual.

=cut
