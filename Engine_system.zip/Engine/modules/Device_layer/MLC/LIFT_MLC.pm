# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_MLC;

use strict;
use warnings;
use File::Basename;
use LIFT_TSG4;

my $addpath;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
    
    # $addpath will be used later in the code, so we have to keep it
    $addpath = File::Spec->rel2abs( dirname(__FILE__) );
    $addpath =~ s/\//\\/g;    # replace all slashes with backslahes
}
use MLC;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  MLC_InitHW
  MLC_CloseHW
  MLC_SetVoltage
  MLC_PSconnect
  MLC_PSdisconnect
  MLC_DisconnectLine
  MLC_ReconnectLine
  MLC_SetLogicalState
  MLC_WarningLampVia
  MLC_SWMinus
  MLC_ShortLine
  MLC_UndoShortLine
  MLC_SetResistance
  MLC_SetCurrent
  MLC_get_names
);

our ( $VERSION, $HEADER );

use constant MAX_ALLOWED_VOLTAGE => 30;    # restricting voltage for MLC

my $stat;                                  # Variable to hold the status of operation
my @MLC_PSlines;                           # Array of names of powersupply lines used in the project
my $MLC_initialized;                       # flag for MLC initialization
my $MLC_labels;                            # A hash reference used to keep track of Labels used in the project
my $MLC_count;                             # variable to hold MLC count
my @undoShortQueue;                        # Queue used to track Short - mainly used to undo the short
my $TSG4_rerouting;                        # flag form calling TSG4 functions
my $MaxVoltage;                            # to hold the maximum voltage configured via Defaults->{'MLC'}{'MLC1'}{'General'}

#sections for different Pins present in a MLC
my @MLCSections = ( 'POWER_SUPPLY_LINES', 'SQUIBS', 'SWITCHES', 'CAN', 'PAS', 'WARNING_LAMPS', 'FREELY_USABLE_SWITCHES' );

#initialize with default values
$MLC_initialized = $TSG4_rerouting = 0;
$MLC_count       = 0;
@undoShortQueue  = ();

=head1 NAME

LIFT_MLC 

Perl extension for MiniLabCar

=head1 SYNOPSIS

    use LIFT_MLC;

    MLC_InitHW();

    MLC_SetVoltage('U_BATT_DEFAULT');
    MLC_PSconnect('CLAMP_15');
    MLC_PSdisconnect('CLAMP_15');
    MLC_DisconnectLine( 'BT1FP' );
    MLC_ReconnectLine( 'BT1FP' );
    MLC_SetLogicalState( 'PADS', 'ACTIVATED' );
    MLC_SWMinus( 'PinGnd' );
    MLC_WarningLampVia( 'PADL', 'Gnd' );
    MLC_ShortLine( 'AB1FD+', 'BT1FP-', 100);
    MLC_UndoShortLine( );
    MLC_SetResistance( 'AB1FP',150);
    MLC_UndoShortLine( );
    MLC_SetCurrent( 'PADS',25.50);
    MLC_SetLogicalState( 'PADS', 'ACTIVATED' );
    MLC_CloseHW();

B<For projects using only one MLC>

ProjectConst:

       'VEHICLE' => {
                 'U_BATT_DEFAULT'   => 13.8,
                 },

       'MLC' => {
             'General' =>
                       {
                          # CAN settings will be overwritten form testbench config settings
                          'MaxVoltage' => 20,     # maximum voltage to be allowed in MLC
                       },

             'SQUIBS' =>
                       {
                        'SQ1_Name' => 'AB1FD',
                        'SQ2_Name' => 'BT1FP',
                        'SQ3_Name' => 'AB1FP',
                        },

             'POWER_SUPPLY_LINES' =>
                       {
                        'PSL1_Name' => 'UB1',
                        'PSL2_Name' => 'UB2',
                        },

             'SWITCHES' =>
                       {
                        'SW4_Name' => 'PADS',
                        'SW2_Name' => 'BLRR',
                        'BLRR_OPEN' => 'BUCKLED',
                        'BLRR_CLOSED' => 'UNBUCKLED',
                        'PADS_OPEN' => 'ACTIVATED',
                        'PADS_CLOSED' => 'DEACTIVATED',
                        },

            'WARNING_LAMPS' =>
                       {
                        'WL5_Name'   => 'PADL',
                       },
            },





TestBench Config:

    $Testbench={

     'COB409407' => {      # LIFT PC host name
            ### ----------- Device Configuration Section ------
            'Devices' => {
               'LabCar' => {
                'Hostname' => 'COB409407',
                'Test_Bench_Number' => 10,  # number of test bench (Laborplatz)
                'Description' => "SW Test Team",

                'CANchannel' => 2,         # CAN channel used to communicate with MLC
                'CANHWSerialNo' => 0,      # Serial number of Vector CAN hardware
                'PinSWMinus' => 'PinGnd'   # (optional) pin to which all switch minus lines are connected in MLC_InitHW if given
              },
           },
      },
   },


B<For projects using Parallel MLCs>

ProjectConst:


   'VEHICLE' => {
             'U_BATT_DEFAULT'   => 13.8,
                 },

   'MLC'    => {

        'General' => {
             # CAN settings will be overwritten form testbench config settings
             'MaxVoltage' => 20,     # maximum voltage to be allowed in MLC
             },


        'MLC1' => {
             'SQUIBS' =>
                       {
                        'SQ1_Name' => 'AB1FD',
                        'SQ2_Name' => 'BT1FP',
                        'SQ3_Name' => 'AB1FP',
                        },

             'POWER_SUPPLY_LINES' =>
                       {
                        'PSL1_Name' => 'UB1',
                        'PSL2_Name' => 'UB2',
                        },

             'SWITCHES' =>
                       {
                        'SW4_Name' => 'PADS',
                        'SW2_Name' => 'BLRR',
                        'BLRR_OPEN' => 'BUCKLED',
                        'BLRR_CLOSED' => 'UNBUCKLED',
                        'PADS_OPEN' => 'ACTIVATED',
                        'PADS_CLOSED' => 'DEACTIVATED',
                        },

            'WARNING_LAMPS' =>
                      {
                       'WL5_Name'   => 'PADL',
                      },
             },


        'MLC2' => {
              'SQUIBS' =>
                        {
                         'SQ1_Name' => 'AB2FD',
                         'SQ2_Name' => 'BT2FP',
                         'SQ3_Name' => 'AB2FP',
                         },

              'SWITCHES' =>
                        {
                         'SW4_Name' => 'STPS',
                         'SW2_Name' => 'BSR1D',
                         'BSR1D_OPEN' => 'BUCKLED',
                         'BSR1D_CLOSED' => 'UNBUCKLED',
                         'STPS_OPEN' => 'FORWARD',
                         'STPS_CLOSED' => 'NOTFORWARD',
                         },

             'WARNING_LAMPS' =>
                       {
                        'WL5_Name'   => 'WALA',
                       },
              },
    },


TestBench Config:

    $Testbench={

     'COB409407' => {      # LIFT PC host name
            ### ----------- Device Configuration Section ------
            'Devices' => {
               'LabCar' => {
                'Hostname' => 'COB409407',
                'Test_Bench_Number' => 10,  # number of test bench (Laborplatz)
                'Description' => "SW Test Team",

                'LabCarCount' => 2,         #Number of MLCs used (this configuration uses 2 MLCs)

                'LabCar1_CANchannel' => 1,        #CAN channel used to communicate with MLC1
                'LabCar1_CANHWSerialNo' => 09182,   #Serial number of Vector CAN hardware for MLC1

                'LabCar2_CANchannel' => 2,        #CAN channel used to communicate with MLC2
                'LabCar2_CANHWSerialNo' => 09182,   #Serial number of Vector CAN hardware for MLC2
              },
            },
         },
      },




B<For projects using TSG4 instead of MLC but test cases written for MLC>

ProjectConst:

see TSG4 SYNOPSIS for Project Const and TSG4 TestBench settings

TestBench Config:

    $Testbench={

     'COB409407' => {      # LIFT PC host name
            ### ----------- Device Configuration Section ------
            'Devices' => {
               'LabCar' => {
                'TSG4_rerouting' => 1,        # if 1 MLC functions will call internally TSG4 functions
                                              # all other entries will be ignored
               },
               'TSG4' => {

                      # put TSG4 TestBench settings here !!!

               },
           },
      },
   },


 it even works with power module configured to LabCar and re-routing to TSG4:

  'SI-Z0CKR' => {      # LIFT PC host name
    ### ----------- Device Configuration Section -----------
    'Devices' => {
         'LabCar' => {
            'TSG4_rerouting' => 1,        # if 1 MLC functions will call internally TSG4 functions
                                          # all other entries will be ignored
         },
        'TSG4' => {
            'Hostname' => 'SI-Z0CKR',
            'Test_Bench_Number' => 42,        # only for logging purpose
            'Description' => "Franks PC",   # only for logging purpose
            'CANchannel' => 1,
            'CANHWSerialNo' => 16024,       # written on CAN device e.g. "007129-030679" -> 30679
            'POWER' => {
                ### configure power inputs: (internal, TOE1, or GOS1)
                'Ubat' => 'internal',
                'UF' => 'TOE1',
            },
        },
    }, ## end of ~~~ Device Configuration Section ~~~
    ### ----------- Function Configuration Section -----------
    'Functions' => {
        ### --- Function Area : Power, select device the power functions will be mapped to (TSG4,LabCar,TOE1 or IDX)
        'POWER' => {
            'device' => 'LabCar',
        },
        ### --- Function Area : Peripherie, select device where ECU is connected to (TSG4,PeriBox or LabCar)
        'PERIPHERIE' => {
            'device' => 'LabCar',
        },
    }, ## end of ~~~ Function Configuration Section ~~~
  },



=head1 DESCRIPTION

=head2 MLC_CloseHW

    MLC_CloseHW();

has to be called at the end, will unload MLC_control.dll. should be called in ENDcampaign

=cut

sub MLC_CloseHW
{

    if ($TSG4_rerouting)
    {
        S_w2log( 1, "MLC_CloseHW() ->  TSG4_CloseHW()\n" );
        TSG4_CloseHW();
        return;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        #clear the global flags
        $MLC_initialized = 0;
        @undoShortQueue  = ();
        S_w2log( 4, "MLC_CloseHW: Terminated the communication with hardware \n" );
        return 1;
    }

    $stat = mlc_CloseHW();
    Check_status($stat);
    S_w2log( 5, "MLC_CloseHW status=$stat\n" );

    $stat = mlc_End();
    Check_status($stat);
    S_w2log( 5, "MLC End status=$stat\n" );

    #clear the global flags
    $MLC_initialized = 0;
    @undoShortQueue  = ();

    S_w2log( 3, "MLC_CloseHW: Terminated the communication with hardware \n" );

    return;
}

=head2 MLC_DisconnectLine

    MLC_DisconnectLine( $line );

disconnect line of MLC, $line has to be a label from ProjectConst

 e.g. with ProjectConst containing
   'MLC' => {
         'SQUIBS' =>
                   {
                    'SQ1_Name' => 'AB1FD',
                    'SQ2_Name' => 'BT1FP',
                    'SQ3_Name' => 'AB1FP',
                    },
          },

    MLC_DisconnectLine( 'BT1FP' );

=cut

sub MLC_DisconnectLine
{
    my $label = shift;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_DisconnectLine( $label ) ->  TSG4_DisconnectLine( $label )\n" );
        TSG4_DisconnectLine($label);
        return;
    }

    unless ( defined($label) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_DisconnectLine( \$line )", 110 );
        return 0;
    }

    my ( $mlc_number, $type ) = Get_MLCNumber($label);

    #    unless ( $mlc_number > 0 )
    if ( $mlc_number <= 0 )
    {
        S_set_error( "! unknown label $label", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "MLC_DisconnectLine( $label ): Disconnected the line   \n" );
        return 1;
    }

    if( $type eq 'POWER_SUPPLY_LINES' ) {
        $stat = mlc_PSdisconnect( $label, 1 );    
    }
    else{
        $stat = mlc_InterruptLine( $label, $mlc_number );
    }
    Check_status($stat);
    S_w2log( 5, "mlc_InterruptLine $label status=$stat\n" );
    S_w2log( 3, "MLC_DisconnectLine( $label ): Disconnected the line  \n" );

    return;
}

=head2 MLC_InitHW

    MLC_InitHW();

initialize MLC hardware

has to be called before any other MLC command, loads MLC_control.dll and intializes MLC settings with values from project defaults. should be called in INITcampaign

Calls MLC_SWMinus( $pinSWMinus ) if 'PinSWMinus' is defined in the Testbench configuration.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration options

=cut

sub MLC_InitHW
{

    $TSG4_rerouting = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'TSG4_rerouting'} if ( exists $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'TSG4_rerouting'} );
    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_InitHW() ->  TSG4_InitHW()\n" );
        TSG4_InitHW();
        return;
    }

    if ($MLC_initialized)
    {
        S_set_warning( "MLC already initialized", 120 );
        return;
    }
    $addpath =~ s/^;//;    # drop leading semicolon

	$MLC_count = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'LabCarCount'};

	#if LabCarCount is undefined, Assume LabCarCount = 1
	if ( not defined $MLC_count  or $MLC_count <=1 ) {
		S_set_warning("No valid LabCarCount for MLC in testbench config found. Assuming LabCarCount = 1  ");
		$LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'LabCarCount'} = 1;
		$MLC_count = 1;

		#if 'POWER_SUPPLY_LINES' section is in outside , its time for Backward compatibility
		if ( exists $main::ProjectDefaults->{'MLC'}->{'POWER_SUPPLY_LINES'} ) {

			#Assign the necessary values for backward compatibilty
			$LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{"LabCar1_CANchannel"}    = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{"CANchannel"};
			$LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{"LabCar1_CANHWSerialNo"} = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{"CANHWSerialNo"};

			#Copy all the sections existing sections in {'MLC'} to {'MLC'}->{'MLC1'}
			foreach my $section (@MLCSections) {
				%{ $main::ProjectDefaults->{'MLC'}->{'MLC1'}->{$section} } = %{ $main::ProjectDefaults->{'MLC'}->{$section} } if ( exists $main::ProjectDefaults->{'MLC'}->{$section} );
			}
		}
		else {
			S_set_error( "POWER_SUPPLY_LINES section for MLC in Project Constants is not found.", 110 );
			return;
		}

	}

    my $mlc_ini = "$addpath\\MLC.ini";
    S_w2log( 4, "Number of MLCs used = $MLC_count\n" );

    # MLC.ini
    if ( open( OUT, ">$mlc_ini" ) )
    {
        $MLC_labels = ();

        for ( my $mlc_number = 1 ; $mlc_number <= $MLC_count ; $mlc_number++ )
        {
            $MLC_labels->{"MLC$mlc_number"} = ();

            #update MLC settinns with CAN settings from Testbenchconfig
            my $tbCAN      = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{ "LabCar$mlc_number" . "_CANchannel" };
            my $tbSerialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{ "LabCar$mlc_number" . "_CANHWSerialNo" };

            #if a common "General" section is provided, the individual "General" sections will be overridden
            if ( exists $main::ProjectDefaults->{'MLC'}->{'General'} )
            {
                %{ $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{'General'} } = %{ $main::ProjectDefaults->{'MLC'}->{'General'} };
            }

            $MaxVoltage = $main::ProjectDefaults->{'MLC'}{"MLC1"}{'General'}{'MaxVoltage'};

            # check whether the Maximum voltage is defined in projectconst & retirn error if not defined
            if ( !defined($MaxVoltage) )
            {
                S_set_error( "Maximum voltage (ProjectDefaults->{'MLC'}{'General'}{'MaxVoltage'}) for MLC is not mentioned", 20 );
                return 0;
            }

            # validate whether the Maximum voltage defined in projectconst does not exceed the MAX_ALLOWED_VOLTAGE for MLC
            if ( $MaxVoltage > MAX_ALLOWED_VOLTAGE )
            {
                S_set_error( "ProjectDefaults->{'MLC'}{'General'}{'MaxVoltage'}($main::ProjectDefaults->{'MLC'}{'General'}{'MaxVoltage'}) > MAX_ALLOWED_VOLTAGE(" . MAX_ALLOWED_VOLTAGE . ")", 20 );
                return 0;
            }

            #check if Channel number is defined
            unless ( defined $tbCAN )
            {
                S_set_error( "No CANchannel for MLC$mlc_number in testbench config found", 20 );
                return 0;
            }

            $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{'General'}->{'CAN'} = $tbCAN;

            #check if Serial number is defined
            unless ( defined $tbSerialNo )
            {
                S_set_error( "No CANHWSerialNo for MLC$mlc_number in testbench config found", 20 );
                return 0;
            }

            $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{'General'}->{'CANHWSERIALNUMBER'} = $tbSerialNo;

            #check the uniqueness of CANChannel, CANHardware serial number
            foreach ( 1 .. $mlc_number - 1 )
            {
                if (    ( $main::ProjectDefaults->{'MLC'}->{"MLC$_"}->{'General'}->{'CAN'} == $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{'General'}->{'CAN'} )
                     && ( $main::ProjectDefaults->{'MLC'}->{"MLC$_"}->{'General'}->{'CANHWSERIALNUMBER'} == $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{'General'}->{'CANHWSERIALNUMBER'} ) )
                {

                    S_set_error( "Same CAN settings found for MLC$_ and MLC$mlc_number", 20 );
                    return 0;
                }
            }

            #parameter range check(only Lower range check is done here(i.e., offline mode), the upper range check will be done below in Realtime mode)
            if ( $tbCAN < 1 )
            {
                S_set_error( "CANchannel $tbCAN out of range ( should be greater than 0 )", 114 );
                return 0;
            }

            #only MLC1 powersupply lines are needed
            unless ( defined $main::ProjectDefaults->{'MLC'}{"MLC1"}{'POWER_SUPPLY_LINES'} )
            {
                S_set_error( "No POWER_SUPPLY_LINES settings for MLC1 found in ProjectDefaults ", 20 );
                return 0;
            }

            foreach my $section ( sort keys %{ $main::ProjectDefaults->{'MLC'}{"MLC$mlc_number"} } )
            {
                print OUT "\n[MLC$mlc_number" . "_$section]\n";
                foreach my $key ( sort keys %{ $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{$section} } )
                {
                    my $temp = $main::ProjectDefaults->{'MLC'}->{"MLC$mlc_number"}->{$section}->{$key};

                    #if 'key' is a name, then add it in 'Names' group, else add it in 'States' group
                    if ( $key =~ /_Name$/ )
                    {
                        #check if key is unique
                        foreach ( 1 .. $mlc_number )
                        {
                            if ( exists $MLC_labels->{"MLC$_"}{$section}{"Names"}{$temp} )
                            {
                                S_set_error( "Redundant name <$temp> in $section", 20 );
                                return 0;
                            }
                        }

                        #add under 'Names' group
                        $MLC_labels->{"MLC$mlc_number"}{$section}{"Names"}{$temp} = 1;
                    }
                    else
                    {
                        #add under 'States' group
                        $MLC_labels->{"MLC$mlc_number"}{$section}{"States"}{$temp} = 1;
                    }

                    print OUT "$key = $temp\n";

                    # check if keys are valid
                    if ( $section eq "FREELY_USABLE_SWITCHES" )
                    {
                        if ( $key !~ /_Name$/ and $key !~ /_STATE_CA$/ and $key !~ /_STATE_CB$/ and $key !~ /_STATE_NC$/ )
                        {
                            S_set_error( "wrong key <$key> in $section, must end with _Name, _STATE_CA, _STATE_CB or _STATE_NC", 20 );
                            return 0;
                        }
                    }
                    elsif ( $section eq "SWITCHES" )
                    {
                        if ( $key !~ /_Name$/ and $key !~ /_CLOSED$/ and $key !~ /_OPEN$/ )
                        {
                            S_set_error( "wrong key <$key> in $section, must end with _Name, _CLOSED or _OPEN", 20 );
                            return 0;
                        }
                    }
                    elsif ( $section eq "CAN" or $section eq "PAS" or $section eq "POWER_SUPPLY_LINES" or $section eq "SQUIBS" or $section eq "WARNING_LAMPS" )
                    {
                        if ( $key !~ /_Name$/ )
                        {
                            S_set_error( "wrong key <$key> in $section, must end with _Name", 20 );
                            return 0;
                        }
                    }

                }
            }
        }

        close(OUT);
    }
    else
    {
        S_set_error( "MLC_InitHW, could not write $mlc_ini", 1 );
        return 0;
    }

    #collect names of 'POWER_SUPPLY_LINES' into an array
    @MLC_PSlines = ();
    foreach ( 1 .. 4 )
    {
        push( @MLC_PSlines, $main::ProjectDefaults->{'MLC'}{"MLC1"}{'POWER_SUPPLY_LINES'}{ 'PSL' . $_ . '_Name' } )
          if ( exists $main::ProjectDefaults->{'MLC'}{"MLC1"}{'POWER_SUPPLY_LINES'}{ 'PSL' . $_ . '_Name' }
               and $main::ProjectDefaults->{'MLC'}{"MLC1"}{'POWER_SUPPLY_LINES'}{ 'PSL' . $_ . '_Name' } ne '' );
    }

    S_w2log( 3, "MLC_InitHW using $mlc_ini\n" );

    if ($main::opt_offline)
    {
       S_w2log( 4, "MLC_InitHW: Initialized successfully \n" );
        $MLC_initialized = 1;
        return 1;
    }

    $stat = mlc_Start();
    Check_status($stat);
    S_w2log( 5, "mlc_Start status=$stat\n" );

    #get the available (connected) CAN Hardwares
    my ( $ids_aref, $channels_aref );
    ( $stat, $ids_aref, $channels_aref ) = mlc_GetCANHWList();
    Check_status($stat);
    S_w2log( 5, "mlc_GetCANHWList status=$stat\n" );

    #check if all the hardwares needed are connected and Channels are in range
    foreach ( 1 .. $MLC_count )
    {
        my $tbCAN      = $main::ProjectDefaults->{'MLC'}->{"MLC$_"}->{'General'}->{'CAN'};
        my $tbSerialNo = $main::ProjectDefaults->{'MLC'}->{"MLC$_"}->{'General'}->{'CANHWSERIALNUMBER'};

        # check if expected HW connected and channel number in range
        my $foundSerialno = 0;
        for ( my $count = 0 ; $count < scalar(@$ids_aref) ; $count++ )
        {
            if ( $$ids_aref[$count] == $tbSerialNo )
            {
                $foundSerialno = 1;

               unless ( $tbCAN <= $$channels_aref[$count] )
                {
                    S_set_error( "! given channel $tbCAN > $$channels_aref[$count] (= MAXchannel of HW $tbSerialNo) )", 114 );
                    return;
                }
            }
        }

        if ( $foundSerialno == 0 )
        {
            S_set_error( "! given hardware with serial number $tbSerialNo is not connected  !", 114 );
            return;
        }
    }

    #init MLC's with .ini file and MLC count needed
    $stat = mlc_InitHW( $mlc_ini, $MLC_count );
    Check_status($stat);
    S_w2log( 5, "MLC_InitHW status=$stat\n" );

    #get Number of MLCs, MLC_IDs and MLC Hardware revision details
    my ( $mlcCount, $mlcID_aref, $mlcHWrev_aref );
    ( $mlcCount, $mlcID_aref, $mlcHWrev_aref ) = mlc_GetDeviceID();
    Check_status($mlcCount);
    S_w2log( 5, "mlc_GetDeviceID: Number of MLCs connected $mlcCount \n" );

    if ( $mlcCount >= 0 )
    {
        foreach my $mlc_number ( 1 .. $mlcCount )
        {
            S_w2log( 3, "MLC$mlc_number :  ID = @$mlcID_aref[$mlc_number - 1] , Revision = @$mlcHWrev_aref[$mlc_number - 1]\n" );
        }
    }

    my $version;
    ( $stat, $version ) = mlc_GetVersion();
    Check_status($stat);
    S_w2log( 5, "MLC_control DLL version is $version and status is $stat \n" );
    S_w2log( 5, "MLC PM-" . mlc_getPMrevision() . " XS-" . mlc_getXSrevision() . " CW-" . mlc_getCWrevision() . "\n" );

    $MLC_initialized = 1;
 	S_w2log( 4, "MLC_InitHW: Initialized successfully \n" );
	 
    if ( $stat < 0 )
    {
        S_set_error( "could not initialize MLC with $mlc_ini", 5 );
        $MLC_initialized = 0;
    }

    # Connect switch minus lines to a pin if defined in testbench config.
    # This is added here for usage of MLC in LIFT_labcar.
    my $pinSWMinus = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'PinSWMinus'};
    if( defined $pinSWMinus ) {
        MLC_SWMinus( $pinSWMinus );
    }
    # todo: return values are not consistent
    # todo: error handling for low level functions is not good

    return;
}

=head2 MLC_PSconnect

    MLC_PSconnect( $label );

connect power line of MLC, $label has to be a label from ProjectConst

$label = "ALL" will connect all MLC power supply lines defined in ProjectConst

B<NOTE: While using Parallel MLCs, Only MLC1 Power supply lines will be connected / disconnected >


 e.g. with ProjectConst containing
    'MLC' => {
         'POWER_SUPPLY_LINES' =>
                   {
                    'PSL1_Name' => 'UB1',
                    'PSL2_Name' => 'UB2',
                    },
          },

    MLC_PSconnect( 'UB1' );
    MLC_PSconnect( 'ALL' ) would connect 'UB1' and 'UB2'


=cut

sub MLC_PSconnect
{
    my $label = shift;

    if ($TSG4_rerouting)
    {
        my $tsg4_label = $label;
        $tsg4_label = 'ALL_SUPPLY' if ( $label eq 'ALL' );
        S_w2log( 5, "MLC_PSconnect( $label ) ->  TSG4_ConnectLine( $tsg4_label )\n" );
        TSG4_ConnectLine($tsg4_label);
        return;
    }

    unless ( defined($label) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_PSconnect( \$label )", 110 );
        return 0;
    }

    #power supply will be always accessed (on/off) in MLC1
    unless ( ( $label eq 'ALL' ) or ( grep { $_ eq $label } @MLC_PSlines ) )
    {
        S_set_error( "! unknown label $label for MLC1", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_PSconnect( $label ) \n" );

    return 1 if $main::opt_offline;

    if ( $label eq "ALL" )
    {
        S_w2log( 4, "MLC_PSconnect ALL = @MLC_PSlines \n" );
        foreach (@MLC_PSlines)
        {
            #always connect powersupply on 1st MLC
            $stat = mlc_PSconnect( $_, 1 );
            Check_status($stat);
            S_w2log( 5, "mlc_PSconnect $_ status=$stat \n" );
        }
    }
    else
    {
        #always connect powersupply on 1st MLC
        $stat = mlc_PSconnect( $label, 1 );
        Check_status($stat);
        S_w2log( 4, "MLC_PSconnect $label status=$stat\n" );
    }

    return;

}

=head2 MLC_PSdisconnect

    MLC_PSdisconnect( $label );

disconnect power line of MLC, $label has to be a label from ProjectConst

$label = "ALL" will disconnect all MLC power supply lines defined in ProjectConst

B<NOTE: While using Parallel MLCs, Only MLC1 Power supply lines will be connected / disconnected>

 e.g. with ProjectConst containing
   'MLC' => {
         'POWER_SUPPLY_LINES' =>
                   {
                    'PSL1_Name' => 'UB1',
                    'PSL2_Name' => 'UB2',
                    },
          },

    MLC_PSdisconnect( 'UB1' );
    MLC_PSdisconnect( 'ALL' ) would disconnect 'UB1' and 'UB2'.


=cut

sub MLC_PSdisconnect
{
    my $label = shift;

    if ($TSG4_rerouting)
    {
        my $tsg4_label = $label;
        $tsg4_label = 'ALL_SUPPLY' if ( $label eq 'ALL' );
        S_w2log( 5, "MLC_PSdisconnect( $label ) ->  TSG4_DisconnectLine( $tsg4_label )\n" );
        TSG4_DisconnectLine($tsg4_label);
        return;
    }

    unless ( defined($label) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_PSdisconnect( \$label )", 110 );
        return 0;
    }

    unless ( $label eq 'ALL' or ( grep { $_ eq $label } @MLC_PSlines ) )
    {
        S_set_error( "! unknown label $label", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_PSdisconnect( $label ) \n" );

    return 1 if $main::opt_offline;

    if ( $label eq "ALL" )
    {
        S_w2log( 4, "MLC_PSdisconnect ALL = @MLC_PSlines \n" );
        foreach (@MLC_PSlines)
        {
            #always disconnect powersupply on 1st MLC
            $stat = mlc_PSdisconnect( $_, 1 );
            Check_status($stat);
        }
    }
    else
    {
        #always disconnect powersupply on 1st MLC
        $stat = mlc_PSdisconnect( $label, 1 );
        Check_status($stat);
        S_w2log( 4, "MLC_PSdisconnect $label status=$stat\n" );
    }

    return;
}

=head2 MLC_ReconnectLine

    MLC_ReconnectLine( $line );

reconnect line of MLC, $line has to be a label from ProjectConst

 e.g. with ProjectConst containing
    'MLC' => {
         'SQUIBS' =>
                   {
                    'SQ1_Name' => 'AB1FD',
                    'SQ2_Name' => 'BT1FP',
                    'SQ3_Name' => 'AB1FP',
                    },
          },

    MLC_ReconnectLine( 'BT1FP' );

=cut

sub MLC_ReconnectLine
{
    my $label = shift;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_ReconnectLine( $label ) ->  TSG4_ConnectLine( $label )\n" );
        TSG4_ConnectLine($label);
        return;
    }

    unless ( defined($label) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_ReconnectLine( \$line )", 110 );
        return 0;
    }

    my ( $mlc_number, $type ) = Get_MLCNumber($label);

    unless ( $mlc_number > 0 )
    {
        S_set_error( "! unknown label $label", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_ReconnectLine( $label ) \n" );

    return 1 if $main::opt_offline;

    if( $type eq 'POWER_SUPPLY_LINES' ) {
        $stat = mlc_PSconnect( $label, 1 );    
    }
    else{
        $stat = mlc_UndoInterruptLine( $label, $mlc_number );
    }
    Check_status($stat);
    S_w2log( 4, "MLC_ReconnectLine $label status=$stat\n" );

    return;
}

=head2 MLC_SetLogicalState

    MLC_SetLogicalState( $switch, $state )

set switch and free usable switch, $switch and $state have to be a label from ProjectConst

 e.g. with ProjectConst containing
    'MLC' => {
         'SWITCHES' =>
                   {
                    'SW4_Name' => 'PADS',
                    'SW2_Name' => 'BLRR',
                    'BLRR_OPEN' => 'BUCKLED',
                    'BLRR_CLOSED' => 'UNBUCKLED',
                    'PADS_OPEN' => 'ACTIVATED',
                    'PADS_CLOSED' => 'DEACTIVATED',
                    },
          },

    MLC_SetLogicalState( 'PADS', 'ACTIVATED' );

=cut

sub MLC_SetLogicalState
{
    my $switch = shift;
    my $state  = shift;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_SetLogicalState( $switch, $state ) ->  TSG4_SetLogicalState( $switch, $state )\n" );
        TSG4_SetLogicalState( $switch, $state );
        return;
    }

    unless ( defined($state) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_SetLogicalState( \$switch, \$state )", 110 );
        return 0;
    }

    my ( $switchMLCnumber, $switchtype ) = Get_MLCNumber($switch);

	unless ( $switchMLCnumber > 0 )
    {
        S_set_error( "! unknown label $switch", 109 );
        return 0;
    }

    my ( $stateMLCnumber, $statetype ) = Get_MLCNumber($state);

    unless ( $stateMLCnumber > 0 )
    {
        S_set_error( "! unknown label $state in MLC$switchMLCnumber", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_SetLogicalState( $switch, $state  ) \n" );

    return 1 if $main::opt_offline;

    $stat = mlc_SetLogicalState( $switch, $state, $switchMLCnumber );
    Check_status($stat);
    S_w2log( 4, "MLC_SetLogicalState( $switch, $state  ) status=$stat\n" );

    return;
}

=head2 MLC_SetVoltage

    MLC_SetVoltage( $voltage );

set voltage of MLC, $voltage has to be a float value, may be mapped in ProjectConst

Maximum voltage allowed should be mentioned in ProjectConst (Defaults->{'MLC'}{'General'}{'MaxVoltage'})

B<NOTE: While using parallel MLCs, Voltage will be set only in MLC1>

 e.g. with ProjectConst containing
   'VEHICLE' => {
             'U_BATT_DEFAULT'   => 13.8,
             },

    MLC_SetVoltage( 'U_BATT_DEFAULT' );
    MLC_SetVoltage( 10.5 );


=cut

sub MLC_SetVoltage
{
    my $voltage = shift;
    my $value;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_SetVoltage( $voltage ) ->  TSG4_SetVoltage( $voltage )\n" );
        TSG4_SetVoltage($voltage);
        return;
    }

    unless ( defined($voltage) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_SetVoltage( \$voltage )", 110 );
        return 0;
    }

    #map voltage if necessary
    unless ( defined( $value = $main::ProjectDefaults->{'VEHICLE'}{$voltage} ) )
    {
        if ( $voltage =~ /^\d+\.?\d*$/ )
        {
            $value = $voltage;
        }
        else
        {
            S_set_error( "could not resolve voltage $voltage", 114 );
            return 0;
        }
    }

    # check whether MLC is initialized already
    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    #parameter range check
    if ( ( $value < 0 ) || ( $value > $MaxVoltage ) )
    {
        S_set_error( "voltage $value out of range (should be 0<=VOLTAGE<=$MaxVoltage)", 114 );
        return 0;
    }

    S_w2log( 4, "MLC_SetVoltage to $voltage (V $value)\n" );

    return 1 if $main::opt_offline;

    #always set voltage on 1st MLC
    $stat = mlc_PSvoltage( $value, 1 );
    Check_status($stat);
    S_w2log( 4, "MLC_SetVoltage status=$stat\n" );

    return;
}

=head2 MLC_ShortLine

    MLC_ShortLine( $line1, $line2, [$resistance]  );

create a short between $line1 and $line2 with leakage resistor $resistance.
$lineX may be a label from HW.ini with + or - added or "VBAT" or "GND". $resistance in Ohms, default is 0.

B< Note: only one short at same time is possible !>

$resistance can take value from 0 to 100000 ohms.

For Squibs:
The $resistance can be multiples of 0.1 Ohm from 0 to 51.1 Ohms.
The $resistance should be multiples of 10 Ohms from 51.1 to 100000 Ohms

For Others:
The $resistance should be multiples of 10 Ohms from 0 to 100000 Ohms

B<NOTE: While using Parallel MLCs, "Ref-B" lines and Common Ground of all MLCs should be connected for Crosscoupling>

 e.g. with ProjectConst containing
   'MLC' => {
         'SQUIBS' =>
                   {
                    'SQ1_Name' => 'AB1FD',
                    'SQ2_Name' => 'BT1FP',
                    'SQ3_Name' => 'AB1FP',
                    },
          },

    MLC_ShortLine( 'AB1FD+', 'BT1FP-' );
    MLC_ShortLine( 'AB1FD+', 'BT1FP-', 100);
    MLC_ShortLine( 'AB1FD+', 'VBAT' );
    MLC_ShortLine( 'AB1FD+', 'GND' );
    MLC_ShortLine( 'AB1FD+', 'VBAT', 100 );
    MLC_ShortLine( 'AB1FD+', 'GND', 100 );


=cut

sub MLC_ShortLine
{
    my $line1      = shift;
    my $line2      = shift;
    my $resistance = shift;

    $resistance = 0 unless ( defined $resistance );

    if ($TSG4_rerouting)
    {
        #B+ B-
        my @lines = ( $line1, $line2 );
        foreach my $label (@lines)
        {
            $label =~ s/GND/B-/;
            $label =~ s/VBAT/B+/;
        }

        my $linestext = join( ',', @lines );
        S_w2log( 1, "MLC_ShortLine( $line1, $line2, $resistance ) ->  TSG4_ShortLines( [$linestext], $resistance )\n" );
        TSG4_ShortLines( \@lines, $resistance );
        return;
    }

    unless ( defined($line2) )
    {
        S_set_error( "! too less parameters ! MLC_ShortLine( \$line1, \$line2, [\$resistance]  )", 110 );
        return 0;
    }

    S_w2log( 4, "MLC_ShortLine( $line1, $line2, $resistance ) \n" );

    if ( $line1 !~ /VBAT|GND/ and $line1 !~ /[+-]$/ )
    {
        S_set_error( "\$line1 has to be either  VBAT or GND or label- or label+ )", 109 );
        return 0;
    }
    if ( $line2 !~ /VBAT|GND/ and $line2 !~ /[+-]$/ )
    {
        S_set_error( "\$line2 has to be either  VBAT or GND or label- or label+ )", 109 );
        return 0;
    }
    if ( $line2 =~ /VBAT|GND/ and $line1 =~ /VBAT|GND/ )
    {
        S_set_error( "at least one line has to be label- or label+ )", 109 );
        return 0;
    }

    my $linename = $line1;
    $linename =~ s/[+-]$//;    # cut off trailing sign
    my ( $line1MLCnumber, $line1type ) = Get_MLCNumber($linename);
    unless ( $linename eq 'VBAT' or $linename eq 'GND' or $line1MLCnumber > 0 )
    {
        S_set_error( "! unknown label $line1", 109 );
        return 0;
    }

    $linename = $line2;
    $linename =~ s/[+-]$//;    # cut off trailing sign
    my ( $line2MLCnumber, $line2type ) = Get_MLCNumber($linename);
    unless ( $linename eq 'VBAT' or $linename eq 'GND' or $line2MLCnumber > 0 )
    {
        S_set_error( "! unknown label $line2", 109 );
        return 0;
    }

    if ( $resistance =~ /^\d+\.?\d*$/ )
    {
        #do nothing
    }
    else
    {
        S_set_error( "could not resolve Resistance value $resistance", 114 );
        return 1;
    }

    #possible short at a time is 1
    if ( scalar(@undoShortQueue) >= 1 )
    {
        S_set_error( "Only one short is possible at a time!", 114 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        unshift @undoShortQueue, 1;
        return 1;
    }

    #If two MLCs are different, then REFERENCE line is used
    #else, mlc_ShortLine() is called with two pin names directly
    if ( $line1MLCnumber != $line2MLCnumber )
    {
        $stat = mlc_ShortLine( $line1, 'REFERENCE', $resistance, $line1MLCnumber );
        Check_status($stat);
        S_w2log( 4, "MLC_ShortLine($line1, REFERENCE, $resistance) status in MLC$line1MLCnumber = $stat\n" );
        if ( $stat == 0 )
        {
            $stat = mlc_ShortLine( 'REFERENCE', $line2, 0, $line2MLCnumber );
            Check_status($stat);
            S_w2log( 4, "MLC_ShortLine(REFERENCE, $line2, 0) status in MLC$line2MLCnumber = $stat\n" );

            #Roll back MLC1 , if second short is not successful
            if ( $stat < 0 )
            {
                mlc_UndoShortLine($line1MLCnumber);
            }
            else
            {
                unshift @undoShortQueue, "$line1MLCnumber,$line2MLCnumber";
            }
        }
    }
    else
    {
        $stat = mlc_ShortLine( $line1, $line2, $resistance, $line1MLCnumber );
        Check_status($stat);
        S_w2log( 4, "MLC_ShortLine status=$stat\n" );

        if ( $stat == 0 )
        {
            unshift @undoShortQueue, $line1MLCnumber;
        }
    }

    return;
}

=head2 MLC_SWMinus

    MLC_SWMinus( $pin );

define minus connection for SW4-10, $pin has to be 'PinA' or 'PinB' or 'PinGnd', usually called in INITcampaign

    MLC_SWMinus( 'PinGnd' );

=cut

sub MLC_SWMinus
{
    my $pin = shift;

    if ($TSG4_rerouting)
    {
        S_set_error( "! TSG4_rerouting does not support MLC_SWMinus !", 5 );
        return;
    }

    unless ( defined($pin) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_SWMinus( \$pin )", 110 );
        return 0;
    }

    unless ( $pin =~ /^(PinA|PinB|PinGnd)$/ )
    {
        S_set_error( "! unknown pin label $pin, must be 'PinA' or 'PinB' or 'PinGnd'", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_SWMinus( $pin ) \n" );

    return 1 if $main::opt_offline;

    foreach ( 1 .. $MLC_count )
    {
        $stat = mlc_SWMinus( $pin, $_ );
        Check_status($stat);
        S_w2log( 4, "MLC_SWMinus($pin) for MLC$_  status=$stat\n" );
    }

    return;
}

=head2 MLC_UndoShortLine

    MLC_UndoShortLine();

remove short condition

=cut

sub MLC_UndoShortLine
{
    my $temp;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_UndoShortLine() ->  TSG4_UndoShortLines()\n" );
        TSG4_UndoShortLines();
        return;
    }

    S_w2log( 4, "MLC_UndoShortLine( ) \n" );

    if ( scalar(@undoShortQueue) == 0 )
    {
        S_set_error( "! No short exists !", 0 );    # only warning
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        shift(@undoShortQueue);
        return 1;
    }

    $temp = shift(@undoShortQueue);

    #Call undoshortline function for MLCs ( Comma seperated MLCs in case of Multiple MLC short)
    foreach my $mlc ( split( /,/, $temp ) )
    {
        $stat = mlc_UndoShortLine($mlc);
        Check_status($stat);
        S_w2log( 4, "MLC_UndoShortLine for MLC$mlc status=$stat\n" );
    }

    return;
}

=head2 MLC_WarningLampVia

    MLC_WarningLampVia( $lamp, $via );

connect warning lamp via 'GND' or 'VBAT', $lamp has to be a label from ProjectConst, usually called in INITcampaign

 e.g. with ProjectConst containing
   'MLC' => {
    'WARNING_LAMPS' =>
       {
        'WL5_Name'   => 'PADL',
       },
     },

    MLC_WarningLampVia( 'PADL', 'GND' );


=cut

sub MLC_WarningLampVia
{
    my $lamp = shift;
    my $via  = shift;

    if ($TSG4_rerouting)
    {
        S_set_error( "! TSG4_rerouting does not support MLC_WarningLampVia !", 5 );
        return;
    }

    unless ( defined($via) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_WarningLampVia( \$lamp, \$via )", 110 );
        return 0;
    }

    my ( $mlc_number, $type ) = Get_MLCNumber($lamp);

    unless ( $mlc_number > 0 )
    {
        S_set_error( "! unknown label $lamp", 109 );
        return 0;
    }

    unless ( $via =~ /^(GND|VBAT)$/ )
    {
        S_set_error( "! unknown via label $via, must be 'GND' or 'VBAT'", 109 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "MLC_WarningLampVia( $lamp, $via ) \n" );

    return 1 if $main::opt_offline;

    $stat = mlc_WarningLampVia( $lamp, $via, $mlc_number );
    Check_status($stat);
    S_w2log( 4, "MLC_WarningLampVia( $lamp, $via ) status=$stat\n" );

    return;
}

=head2 MLC_SetResistance

    MLC_SetResistance( $label, $resistance);

short the "+" and "-" pins of a Squib or a Switch ($label) with leakage resistance $resistance (in Ohms).

only applicable for Switches and Squibs !

B< Note: only one short at same time is possible ! use MLC_UndoShortLine() for Squibs, MLC_SetLogicalState() for Switches before using MLC_SetResistance() next time>

$resistance can take value from 0 to 100000 ohms.

For Squibs:
The $resistance can be multiples of 0.1 Ohm from 0 to 51.1 Ohms.
The $resistance should be multiples of 10 Ohms from 51.1 to 100000 Ohms

For Switch:
The $resistance should be multiples of 10 Ohms from 0 to 100000 Ohms

e.g. with ProjectConst containing

   'MLC' => {
        'SQUIBS' =>
                {
                    'SQ1_Name' => 'AB1FD',
                    'SQ2_Name' => 'BT1FP',
                    'SQ3_Name' => 'AB1FP',
                },

        'SWITCHES' =>
            {
            'SW1_Name' => '_ISOFIX',
            'SW2_Name' => 'BLRR',
            'SW3_Name' => '_BLM',
                    'SW4_Name' => 'PADS',
                },
          },

    MLC_SetResistance( 'AB1FD', 100 );
    MLC_SetResistance( 'BT1FP', 26.5);
    MLC_SetResistance( '_ISOFIX', 150 );
    MLC_SetResistance( 'PADS', 200 );


=cut

sub MLC_SetResistance
{

    my $label      = shift;
    my $resistance = shift;
    my $value;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_SetResistance( $label, $resistance ) ->  TSG4_SetResistance( $label, $resistance )\n" );
        TSG4_SetResistance( $label, $resistance );
        return;
    }

    #Check for required number of Parameters
    unless ( defined($resistance) )
    {
        S_set_error( "! too less parameters ! MLC_SetResistance( \$label, \$resistance  )", 110 );
        return 0;
    }

    S_w2log( 4, "MLC_SetResistance( $label, $resistance ) \n" );

    #Get MLCNumber and Type of device for $label
    my ( $mlc_number, $type ) = Get_MLCNumber($label);

    unless ( $mlc_number > 0 )
    {
        S_set_error( "! unknown label $label", 109 );
        return 0;
    }

    #validate given resistance value
    if ( $resistance =~ /^\d+\.?\d*$/ )
    {
        $value = $resistance;
    }
    else
    {
        S_set_error( "could not resolve Resistance value $resistance", 114 );
        return 0;
    }

    #possible short at a time is 1
    if ( $type eq 'SQUIBS' && scalar(@undoShortQueue) >= 1 )
    {
        S_set_error( "Only one short is possible at a time!", 114 );
        return 0;
    }

    #check for initilaized MLC
    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        #Push "1" into Shortlist queue
        unshift @undoShortQueue, 1;
        return 1;
    }

    #call Low level function with MLC number
    $stat = mlc_SetResistance( $label, $value, $mlc_number );
    Check_status($stat);
    S_w2log( 4, "MLC_SetResistance status=$stat\n" );

    #for SQUIBS, mlc_UndoShortline() should be called for undoing the resistance
    if ( $stat == 0 && $type eq 'SQUIBS' )
    {
        unshift @undoShortQueue, $mlc_number;
    }

    return;
}

=head2 MLC_SetCurrent

    MLC_SetCurrent( $label, $currentvalue);

sets current equal to $currentvalue(in mA) across the Switch $label. only applicable for Switches!

$currentvalue can take value from 0 to 99.99 mA

B< Note: Only one switch can use current supply at same time !
use MLC_SetLogicalState() before using MLC_SetCurrent() next time >

e.g. with ProjectConst containing

   'MLC' => {
        'SWITCHES' =>
        {
                'SW1_Name' => '_ISOFIX',
            'SW2_Name' => 'BLRR',
            'SW3_Name' => '_BLM',
                    'SW4_Name' => 'PADS',
                },
          },


    MLC_SetCurrent( 'PADS', 25.5 );
    MLC_SetCurrent( 'BLRR', 15.0 );


=cut

sub MLC_SetCurrent
{

    my $label        = shift;
    my $currentvalue = shift;
    my $value;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_SetCurrent( $label, $currentvalue ) ->  TSG4_SetCurrent( $label, $currentvalue )\n" );
        TSG4_SetCurrent( $label, $currentvalue );
        return;
    }

    unless ( defined($currentvalue) )
    {
        S_set_error( "! too less parameters ! MLC_SetCurrent( \$label, \$currentvalue  )", 110 );
        return 0;
    }

    S_w2log( 4, "MLC_SetCurrent( $label, $currentvalue ) \n" );

    my ( $mlc_number, $type ) = Get_MLCNumber($label);

    unless ( $mlc_number > 0 )
    {
        S_set_error( "! unknown label $label", 109 );
        return 0;
    }

    if ( $currentvalue =~ /^\d+\.?\d*$/ )
    {
        $value = $currentvalue;
    }
    else
    {
        S_set_error( "could not resolve Current value $currentvalue", 114 );
        return 0;
    }

    unless ($MLC_initialized)
    {
        S_set_error( "MLC not initialized", 120 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = mlc_SetCurrent( $label, $value, $mlc_number );
    Check_status($stat);
    S_w2log( 4, "MLC_SetCurrent status=$stat\n" );

    return;
}

=head1 non-DLL functions

these functions do not access the MLC dll

=head2 MLC_get_names

  @names = MLC_get_names( $section );

return names of MLC section defined in ProjectConst in ascending order

 e.g. with ProjectConst containing
   'MLC' => {
         'SWITCHES' =>
                   {
                    'SW4_Name' => 'PADS',
                    'SW2_Name' => 'BLRR',
                    'BLRR_OPEN' => 'BUCKLED',
                    'BLRR_CLOSED' => 'UNBUCKLED',
                    'PADS_OPEN' => 'ACTIVATED',
                    'PADS_CLOSED' => 'DEACTIVATED',
                    },
          },

    MLC_get_names( 'SWITCHES' ) will return ('BLRR','PADS')

=cut

sub MLC_get_names
{
    my $section = shift;

    if ($TSG4_rerouting)
    {
        S_w2log( 5, "MLC_get_names( $section ) ->  TSG4_get_names( $section )\n" );
        my @names = TSG4_get_names($section);
        return @names;
    }

    my ( @names, @keys );
    my $mlc_count     = 1;
    my $sectionExists = 0;
    my %values;

    @names = ();
    unless ( defined($section) )
    {
        S_set_error( "! too less parameters ! SYNTAX: MLC_get_names( \$section )", 110 );
        return @names;
    }

    #if 'LabCarCount' is existing in Testbench configuration, it means
    # New Configuration file(.pm) format is used (for Parallel MLCs)
    if ( exists $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'LabCarCount'} )
    {
        $mlc_count = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'LabCarCount'};
        $mlc_count = 1 if ( $mlc_count <= 0 );    #validation against negative or zero value

        foreach ( 1 .. $mlc_count )
        {
            $sectionExists = 1 if ( exists $main::ProjectDefaults->{'MLC'}{"MLC$_"}{$section} );
        }

        #if section doesn't exists , raise error
        unless ( $sectionExists == 1 )
        {
            S_set_error( "! wrong parameter ! section $section does not exist in ProjectConst", 109 );
            return @names;
        }

        #collect all names corresponding to $section in hash %values
        foreach my $mlcNumber ( 1 .. $mlc_count )
        {
            foreach my $sectionelement ( keys %{ $main::ProjectDefaults->{'MLC'}{"MLC$mlcNumber"}{$section} } )
            {
                #append the MLCnumber with key, for sorting purpose
                $values{ $mlcNumber . "_" . $sectionelement } = $main::ProjectDefaults->{'MLC'}{"MLC$mlcNumber"}{$section}{$sectionelement};
            }
        }

    }
    else
    {
        #old CFG format is used
        unless ( exists $main::ProjectDefaults->{'MLC'}{$section} )
        {
            S_set_error( "! wrong parameter ! section $section does not exist in ProjectConst", 109 );
            return @names;
        }
        %values = %{ $main::ProjectDefaults->{'MLC'}{$section} };

        #append the MLCnumber with key for sorting purpose, in this case MLC number is 1
        foreach my $keyname ( keys %values )
        {
            $values{ "1_" . $keyname } = $values{$keyname};
            delete $values{$keyname};
        }
    }

    #collect keys with the pattern .*_Name (ex: 1_SW1_Name, 2_SW2_Name, 1_SW3_Name etc.)
    @keys = grep { /_Name$/ } keys %values;

    # sorting taken from C:/Perl/html/lib/Pod/perlfunc.html sort LIST
    #sort based on the keys : for example, (1_SW1_Name, 2_SW2_Name, 1_SW3_Name) should be sorted to (1_SW1_Name , 1_SW3_Name , 2_SW2_Name ) and so on.
    #Consider the list containing elements (1_SW1_Name, 2_SW2_Name, 1_SW3_Name )
    #The sorting involves 3 steps
    #step-1: map { [$_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_)] } @keys;
    #       For each element in @keys, prepare a 4-element hash of form [SwitchName, MLCNumber, SwitchNumber, Uppercase of SwitchName]
    #       for example[1_SW1_Name , 1, 1, 1_SW1_NAME], [2_SW2_Name ,2,  2, 2_SW2_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME])
    #
    #step-2: sort { $a->[1] <=> $b->[1]    ||     $a->[2] <=> $b->[2]      ||      $b->[3] cmp $a->[3]}
    #       Sort the array based on first, second and third element ([1_SW1_Name , 1,  1, SW1_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME], [2_SW2_Name , 2, 2, SW2_NAME])
    #
    #step-3: map { $_->[0] }
    #       Assign the first element to the resulting variable(1_SW1_Name,1_SW3_Name,2_SW2_Name)
    #
    #Hence the elements are sorted
    #
    @keys = map { $_->[0] }
      sort { $a->[1] <=> $b->[1] || $a->[2] <=> $b->[2] || $b->[3] cmp $a->[3] } map { [ $_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_) ] } @keys;

    foreach (@keys)
    {
        push( @names, $values{$_} );
    }

    S_w2log( 4, "MLC_get_names( $section ) = @names\n" );
    return (@names);

}

=head1 not exported functions

=head2 Check_status

 Check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_status
{
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status < 0 )
    {
        my $errortext = mlc_GetErrorString($status);
        S_set_error( "MLC ($status): $errortext", 5 );

    }

    return;
}

=head2 Get_MLCNumber

 ($MLCnumber, $Type) = Get_MLCNumber($label)

Return the MLCNumber ( 1 or 2 or ..) and Type (like 'POWER_SUPPLY_LINES' or 'SQUIBS' or 'SWITCHES' etc.,) ,
in which $label is defined.

Return (0, '') , if $label is not found in any of the MLCs.

 e.g. with ProjectConst containing
   'MLC' => {
         'SWITCHES' =>
                   {
                    'SW4_Name' => 'PADS',
                    'SW2_Name' => 'BLRR',
                    'BLRR_OPEN' => 'BUCKLED',
                    'BLRR_CLOSED' => 'UNBUCKLED',
                    'PADS_OPEN' => 'ACTIVATED',
                    'PADS_CLOSED' => 'DEACTIVATED',
                    },
          },

    Get_MLCNumber( 'PADS' ) will return (1, 'SWITCHES')

=cut

sub Get_MLCNumber
{
    my $label = shift;

    #if VBAT, GND are requested
    if ( $label =~ /VBAT|GND/i )
    {
        return ( 1, "POWER_SOURCES" );
    }

    foreach my $tempMLC ( 1 .. $MLC_count )
    {
        foreach my $tempSection (@MLCSections)
        {
            if ( ( exists $MLC_labels->{"MLC$tempMLC"}{$tempSection}{"Names"}{$label} ) || ( exists $MLC_labels->{"MLC$tempMLC"}{$tempSection}{"States"}{$label} ) )
            {
                S_w2log(5,"Get_MLCNumber: MLC Number is $tempMLC for label $label which is of $tempSection type \n");
                return ( $tempMLC, $tempSection );
            }
        }
    }

    S_w2log(5,"Get_MLCNumber: MLC Number is 0 for label $label \n");
    return ( 0, "" );
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

