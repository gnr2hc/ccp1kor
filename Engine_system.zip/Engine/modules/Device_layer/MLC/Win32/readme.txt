About vxlapi.dll:
A 32-bit XL driver library from Vector used to communicate with vector hardwares.

About MLC_Control.dll:
 32-bit MLC control dll used to automate MLC based tests

About MLC.dll:
A 32-bit Wrapper perl dll for MLC_Control.dl . 
It is compiled using Perl 5.12, 32 bit version
