About vxlapi64.dll:
A 64-bit XL driver library from Vector used to communicate with vector hardwares.

About MLC_Control.dll:
 64-bit MLC control dll used to automate MLC based tests

About MLC.dll:
A 64-bit Wrapper perl dll for MLC_Control.dl . 
It is compiled using Perl 5.12, 64 bit version
