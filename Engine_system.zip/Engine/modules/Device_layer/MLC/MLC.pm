package MLC;

use strict;
use warnings;
use LIFT_simulation;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use MLC ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
    mlc_Start
    mlc_End
    mlc_InitHW
    mlc_GetDeviceID
    mlc_CloseHW
    mlc_GetVersion
    mlc_PSconnect
    mlc_PSdisconnect
    mlc_PSvoltage
    mlc_getPMrevision
    mlc_getXSrevision
    mlc_getCWrevision
    mlc_InterruptLine
    mlc_UndoInterruptLine
    mlc_SetLogicalState
    mlc_WarningLampVia
    mlc_SWMinus
    mlc_UndoShortLine
    mlc_ShortLine
    mlc_SetResistance
    mlc_SetCurrent
    mlc_GetCANHWList
    mlc_GetErrorString
);
our $VERSION = '1.0';

bootstrap MLC $VERSION;

# Preloaded methods go here.

sub mlc_getPMrevision{
    return ('SCM');
}

sub mlc_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub mlc_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}


#
# simulation functions start here
#

if ( $main::opt_simulation ){
    no strict 'refs';
    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT){
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'mlc_GetDeviceID' => { 'default' => [ 0, [1], [1] ], },
    }; 
    SIM_addToValuesTable( $returnValuesTable_href );

    *mlc_GetCANHWList = sub{
        my $defaultSerialNo;
        if( defined $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'CANHWSerialNo'} ){
            $defaultSerialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'LabCar'}{'CANHWSerialNo'};
        }
        else{
            $defaultSerialNo = '12345';
        }
        return SIM_returnValues('mlc_GetCANHWList', [ 0, [$defaultSerialNo], [1] ], \@_); 
    };
}


1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

MLC - Perl extension for generic mini lab car dll

=head1 SYNOPSIS

    use MLC;

    my ($version,$i,$stat,$ret,$mlcID, $mlcVersion);
    my ($names,$IDs,$states,$DTCs,$PonCnt,$SpoCnt,$fiApTime,$laDisTime);
    print"call start\n";

    $ret = mlc_getPMrevision();
    print "PM $ret\n";
    $ret = mlc_getXSrevision();
    print "XS $ret\n";
    $ret = mlc_getCWrevision();
    print "CW $ret\n";


    $stat = mlc_Start();
    print"perl: ($stat) started\n";

    $stat = mlc_InitHW('C:\MKS\LIFT\LIFT_develop\MLC\MLC_HWtest.ini', 1);
    print"perl: ($stat) init\n";

    ($stat,$version) = mlc_GetVersion();
    print"perl: ($stat) v $version\n";
    
    ($stat, $mlcID, $mlcVersion) = mlc_GetDeviceID();
    print"perl: ($stat) id- $mlcID, v- $mlcVersion\n";
    
    $stat = mlc_PSvoltage(11.5, 1);
    print"perl: ($stat) voltage\n";

    $stat = mlc_PSconnect('CLAMP_15', 1);
    print"perl: ($stat) connect\n";

    sleep(3);

    $stat = mlc_PSdisconnect('CLAMP_15', 1);
    print"perl: ($stat) disconnect\n";
    
    sleep(1);
        
    $stat = mlc_SetResistance('AB1FD',20.5, 1);
    print"perl: ($stat) resistance\n";
        
    sleep(1);
        
    $stat = mlc_UndoShortLine(1);
    print"perl: ($stat) undoshortline\n";
        
    sleep(1);
        
    $stat = mlc_SetCurrent('PADS',12.2, 1);
    print"perl: ($stat) current\n"; 
        
    sleep(1);
        
    $stat = mlc_SetLogicalState("PADS","ACTIVATED", 1);
    print"perl: ($stat) logical_state\n";
    
    sleep(1); 

    $stat = mlc_CloseHW();
    print"perl: ($stat) close\n";

    $stat = mlc_End();
    print"perl: ($stat) ended\n";


=head1 DESCRIPTION

All these functions are wrapped around MLC_control DLL APIs.


=head2 mlc_Start

 $status = mlc_Start();

load MLC_control.DLL and initalize function pointers


=head2 mlc_End

 $status = mlc_End();

unload MLC_control.DLL


=head2 mlc_InitHW

 $status = mlc_InitHW( $path_to_ini_file, $NumberOfMLCs);

init MLC with given ini file

=head2 mlc_GetDeviceID

  ($status, $mlcID, $mlcVersion) = mlc_GetDeviceID();

returns the Serial number and Version of the MLC Hardwares used

=head2 mlc_CloseHW

 $status = mlc_CloseHW();

close MLC connection


=head2 mlc_GetCANHWList

    ($stat, $IDs_aref, $Channels_aref) = mlc_GetCANHWList();

returns the list of Serial number of connected Hardwares and Number of channels available in each Hardware


=head2 mlc_GetErrorString

    $errortext = mlc_GetErrorString( $status );

resolve error string from $status < 0


=head2 mlc_GetVersion

 ($status, $version) = mlc_GetVersion();

returns MLC_control.DLL version


=head2 mlc_PSvoltage

 $status = mlc_PSvoltage( $voltage, $MLCNumber );

set voltage of MLC, $voltage has to be a float value, 

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_PSconnect

 $status = mlc_PSconnect( $line, $MLCNumber );


connect power line of MLC, $line has to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_PSdisconnect

 $status = mlc_PSdisconnect( $line, $MLCNumber );

disconnect power line of MLC, $line has to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_ShortLine

 $status = mlc_ShortLine( $line1, $line2, $resistance, $MLCNumber );

create a short between $line1 and $line2 with leakage resistor $resistance. 
$lineX may be a label from HW.ini or "VBAT" or "GND". For direct short set $resistance to 0. 
<B Note: only one short at same time is possible !>

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_UndoShortLine

 $status = mlc_UndoShortLine( $MLCNumber );

remove short condition

1 <= $MLCNumber <= Total MLCs used
    

=head2 mlc_InterruptLine

 $status = mlc_InterruptLine( $line, $MLCNumber );

disconnect line of MLC, $line has to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_UndoInterruptLine

 $status = mlc_UndoInterruptLine( $line, $MLCNumber );

reconnect line of MLC, $line has to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_SetLogicalState

 $status = mlc_SetLogicalState( $switch, $state, $MLCNumber );

set switch and free usable switch, $switch and $state have to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_WarningLampVia

 $status = mlc_WarningLampVia( $lamp, $via, $MLCNumber );

connect warning lamp via "Gnd" or "Vbat", $lamp has to be a label from ini file

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_SWMinus

 $status = mlc_SWMinus( $pin, $MLCNumber );

define minus connection for SW4-10, $pin has to be "PinA" or "PinB" or "PinGnd"

1 <= $MLCNumber <= Total MLCs used

=head2 mlc_SetResistance

 $status = mlc_SetResistance( $line, $resistance_value, $MLCNumber );

Used to set a resistance $resistance_value between "+" and "-" pins of a Switch or Squib $line.
<B Note: only applicable for Switches and Squibs !>

1 <= $MLCNumber <= Total MLCs used


=head2 mlc_SetCurrent

 $status = mlc_SetCurrent(  $line, $current_value, $MLCNumber );

Used to set current $current_value across a Switch $line.
<B Note: only applicable for Switches !>

1 <= $MLCNumber <= Total MLCs used


=head1 TRACEABILITY FUNCTIONS

=head2 mlc_getPMrevision

returns MKS revision number of .pm file

=head2 mlc_getXSrevision

returns MKS revision number of .xs file

=cut

=head2 mlc_getCWrevision

returns MKS revision number of Interface.c file

=cut

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, MLC documentation

=cut
