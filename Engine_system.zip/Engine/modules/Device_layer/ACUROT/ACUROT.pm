package ACUROT;

use strict;
use warnings;
use LIFT_simulation;
use LIFT_general;

use Win32::SerialPort;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
   ar_connect
   ar_disconnect
   ar_get_status
   ar_stop
   ar_rotate
   ar_home
   ar_position
   ar_init
   ar_coldstart
   ar_clearFaults
   ar_reset
   ar_get_firmware
   ar_get_HWversion
   ar_set_null
   ar_wobble
   ar_get_error
   ar_transmit
   ar_get_speed_safety_limit
   ar_get_accel_limit
   ar_get_position
);

our ($VERSION,$HEADER);

my $MAXtimeout = 250;
my ($COM_v, $COM_h, $nullPosH, $nullPosV);
my $move_timeout_ms = 60000; # 1 min timeout for new position
my ($stat,$ret,$Vport,$Hport);
my $error_text="";

# speed safety limit
# change only in conformity with "Sicherheitsingenieur G.Loeckle"
my $speed_safety_limit_deg_s = 3000;
my $accel_limit_deg_s2 = 20000;

############################################################################################################

=head1 DESCRIPTION

Control module for AcuRot via serial (COM port) connection 

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 ar_connect

    $stat = ar_connect($Vport, $Hport);

Connnect to AcuRot on $Vport and $Hport.

A valid connection is e.g. '1' for COM1.

=cut

sub ar_connect {
    $Vport = shift;
    $Hport = shift;

    $COM_v = new Win32::SerialPort("COM$Vport");
    unless($COM_v){ set_error("Can't open COM$Vport: $!"); return -1; }
    $COM_h = new Win32::SerialPort("COM$Hport");
    unless($COM_h){ set_error("Can't open COM$Hport: $!"); return -1; }

    #    port configuration according to
    #        S306_Amplifier Manual-E.pdf
    #        3.5.1.4 Operating systems
    #        page 37
    #        ----------------------------
    #        - 38400 bps
    #        - databit 8
    #        - no parity
    #        - stopbit 1
    #        - no flow control

    # setting up all parameters for COM ports
    $COM_v->error_msg(1);
    $COM_v->user_msg(1);
    $COM_v->baudrate(38400);
    $COM_v->parity('none');
    $COM_v->databits(8);
    $COM_v->stopbits(1);
    $COM_v->read_interval(1000);
    $COM_v->read_const_time(30000);
    $COM_v->handshake('none');
    $COM_v->binary('T');
    $COM_v->parity_enable('F');
    $COM_v->buffers(4096, 4096);
    $stat=$COM_v->write_settings();
    unless($stat){ set_error("Error when configuring COM$Vport port"); return -1; }

    $COM_h->error_msg(1);
    $COM_h->user_msg(1);
    $COM_h->baudrate(38400);
    $COM_h->parity('none');
    $COM_h->databits(8);
    $COM_h->stopbits(1);
    $COM_h->read_interval(1000);
    $COM_h->read_const_time(30000);
    $COM_h->handshake('none');
    $COM_h->binary('T');
    $COM_h->parity_enable('F');
    $COM_h->buffers(4096, 4096);
    $stat=$COM_h->write_settings();
    unless($stat){ set_error("Error when configuring COM$Hport port"); return -1; }
    
    return 0;
}

=head2 ar_init

    $stat = ar_init( $table, $nullPosOffset );

initialize AcuRot table and go to 0 position.

=cut

sub ar_init{
    my $table = shift;
    my $nullPos = shift;
    my $data;

    if ($table eq "V"){
        $nullPosV=$nullPos;
    }
    elsif ($table eq "H"){
        $nullPosH=$nullPos;
    }
    else{ set_error("wrong table $table"); return -1; }
    
    # disable amplifier
    ($stat,$ret)=ar_transmit($table,"DIS");
    return $stat if ($stat<0);

    ($stat,$ret) = ar_transmit($table, "CLRFAULT");
    return $stat if ($stat<0);

    ($stat,$ret) = ar_transmit($table, "ERRCODE");
    return $stat if ($stat<0); # 'no errors'
    if( $ret ne 'no errors' ){
        S_set_error("ACUROT tool error: $ret", 120);
    }

    ($stat,$ret) = ar_transmit($table, "STATCODE");
    return $stat if ($stat<0); # 'no warnings'
    if( $ret ne 'no warnings' ){
        S_set_warning("ACUROT tool warning: $ret");
    }

	# Todo: 
	# check status after CLRFAULT, then do COLDSTART and again CLRFAULT if necessary

	# coldstart to reset the amplifier
    #($stat,$ret) = ar_transmit($table, "COLDSTART");
    #return $stat if ($stat<0);

    # set communication timeout to avoid communication errors
    ($stat,$ret) = ar_transmit($table,"BUSP2 6000");
    return $stat if ($stat<0);

    ($stat,$data) = ar_get_firmware($table);
    return $stat if ($stat<0);
    S_w2log(5, "$table firmware is $data\n");
    
    ($stat,$data) = ar_get_HWversion($table);
    return $stat if ($stat<0);
    S_w2log(5, "$table hardware is $data\n");
    
    # Checking the ACUROT units
    # check current units for P (deg/s): should be 0, together with PGEARI (360000) it becomes mdeg (milli-degrees)
    ($stat,$ret) = ar_transmit($table, "PUNIT");
    return $stat if ($stat<0);
    S_w2log(5, "$table PUNIT is $ret\n");

    # check current units for acceleration: should be 4 = 1000*|PUNIT|/sec�
    ($stat,$ret) = ar_transmit($table, "ACCUNIT");
    return $stat if ($stat<0);
    S_w2log(5, "$table ACCUNIT is $ret\n");

    # check current units for acceleration: should be 7 = 1000 * |PUNIT| / Sec
    ($stat,$ret) = ar_transmit($table, "VUNIT");
    return $stat if ($stat<0);
    S_w2log(5, "$table VUNIT is $ret\n");

    # check if reference point is already set
    my $status_href = ar_STATUS($table);
    
    if( not $status_href->{'referencePointSet'} ){
	    # drive table in homing position, to have reference point and defined start
        S_w2log(4, "Reference point is not set. Start Homing for table '$table'.\n");        
	    $stat = ar_home($table);
	    return $stat if ($stat<0);
    }
    else{
        S_w2log(4, "Homing not required for table '$table'. Reference point is already set.\n");        
    }

    # drive 0�-position
    $stat = ar_position($table, 0.000);
    return $stat if ($stat<0);

    return 0;
}

=head2 ar_home

    $stat = ar_home($table);

move table to homing position

=cut

sub ar_home{
    my $table = shift;
    
    # do we need to STOP ?

    # stop rotation
#    ($stat,$ret)=ar_transmit($table,"STOP");
#    return $stat if ($stat<0);

    ($stat,$ret)=ar_transmit($table,"DIS");         # disable table
    return $stat if ($stat<0);

    # set Position Resolution (Numerator)
    ($stat,$ret)=ar_transmit($table,"PGEARI 360000"); # sets |PUNIT| to mdeg (1/1000 degrees)
    return $stat if ($stat<0);

    ($stat,$ret)=ar_transmit($table,"OPMODE 8");    # motion task
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"VLIM 3000");   # set max velocity in deg/s --> lower to 3000 ???
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"MSPEED 16000"); # set max motor speed 16000 rpm
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"VREF 200");   # set speed for homing in deg/s  --> lower to 100
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"PVMAX 3000");  # max speed for motion tasks in deg/s --> lower to 3000 ???
    return $stat if ($stat<0);
    
    ($stat,$ret)=ar_transmit($table,"ACC 20000"); # acceleration limit in deg/s2, max possible value is 126000
    return $stat if ($stat<0);

    ($stat,$ret)=ar_transmit($table,"DEC 20000"); # deceleration limit in deg/s2, max possible value is 126000
    return $stat if ($stat<0);

    ($stat,$ret)=ar_transmit($table,"PTMIN 20000"); # minimum time that is permitted for a velocity change from 0 to |PVMAX| --> should be lowered to 3
                                                    # any acceleration is limited to |PVMAX|/PTMIN
    return $stat if ($stat<0);

    ($stat,$ret)=ar_transmit($table,"NREF 5");      # move to zero mark
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"DREF 34");     # shortest distance
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"EN");          # enable table
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"MH");          # start homing
    return $stat if ($stat<0);
    
    my $duration_ms = 0;
	my $timeStep_ms = 100;
	my $status_href;
    
    do{
        wait_ms($timeStep_ms);
        $duration_ms += $timeStep_ms;
	    if ($duration_ms > $move_timeout_ms){ 
	    	set_error("positioning timeout, time > $move_timeout_ms ms"); 
	    	return -1; 
	    }
        $status_href = ar_STATUS($table);
    
    } until( $status_href->{'referencePointSet'} );

    return 0;    
}

=head2 ar_get_firmware

    ($stat,$firmware) = ar_get_firmware($table);

read firmware version

=cut

sub ar_get_firmware{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"FW");  # version number of firmware
    return ($stat,$ret);
}

=head2 ar_get_position

    ($stat,$pos) = ar_get_position($table);

read real table position (no null correction)

=cut

sub ar_get_position{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"PFB"); # actual position from feedback drive
    return ($stat,$ret);
}


=head2 ar_get_HWversion

    ($stat,$hardware) = ar_get_HWversion($table);

read hardware version

=cut

sub ar_get_HWversion{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"HVER"); # hardware version
    return ($stat,$ret);
}

=head2 ar_get_error

    $errortext = ar_get_error();

return last error and clear error

=cut

sub ar_get_error{

    $ret=$error_text;
    $error_text="";
    return ($ret);
}

=head2 ar_set_null

    ($stat,$null_pos) = ar_set_null($table);

set current table position as new null position

=cut

sub ar_set_null{
    my $table = shift;

    my ($stat,$pos)=ar_get_position($table);
    return ($stat,0) if ($stat<0);
    
    # convert data
    $pos = $pos / 1000;

    if ($table eq "V"){
        $nullPosV=$pos;
    }
    elsif ($table eq "H"){
        $nullPosH=$pos;
    }
    else{set_error("wrong table $table"); return (-1,0);}
#print"new $table null position = $pos\n";

    return (0,$pos);
}


=head2 ar_position

    $stat = ar_position($table, $position_deg [, $speed_deg_s, $acceleration_deg_s2]);

Move table $table to given position $position_deg.
Speed of positioning can be given in $speed_deg_s in deg/s (default = 360 deg/s, limit = 3000 deg/s).
Acceleration until max positioning speed can be given in $acceleration_deg_s2 in deg/s2 (default = 1000 deg/s2, limit = 10000 deg/s2).

=cut

sub ar_position{
    my $table = shift;
    my $position_deg = shift;
    my $speed_deg_s = shift;
    my $acceleration_deg_s2 = shift;
    my $cmd;
    
    $speed_deg_s = 360 if not defined $speed_deg_s;
    $acceleration_deg_s2 = 1000 if not defined $acceleration_deg_s2;

    # speed safety limit
    if ( $speed_deg_s > $speed_safety_limit_deg_s or $speed_deg_s <= 0 ){
        set_error("speed safety limit violation: $speed_deg_s > $speed_safety_limit_deg_s");
        return -3;
    }

    # accel limit
    if ( $acceleration_deg_s2 > $accel_limit_deg_s2 or $acceleration_deg_s2 <= 0 ){
        set_error("acceleration limit violation: $acceleration_deg_s2 > $accel_limit_deg_s2");
        return -3;
    }

    my $nullCorrection;
    if ($table eq "V"){
        $nullCorrection=$nullPosV;
    }
    elsif ($table eq "H"){
        $nullCorrection=$nullPosH;
    }
    else{set_error("wrong table $table"); return -1;}

    # stop rotation
    ($stat,$ret)=ar_transmit($table,"STOP");
    return $stat if ($stat<0);

    # set position mode
    ($stat,$ret)=ar_transmit($table,"OPMODE 8");
    return $stat if ($stat<0);

    # disable amplifier
    ($stat,$ret)=ar_transmit($table,"DIS");
    return $stat if ($stat<0);

    # calculate position concerning null position
    $position_deg = $nullCorrection - $position_deg;

    # convert position (0)-(+360)
    if      ($position_deg >= +360.0) {$position_deg -= 360.0;}
    elsif ($position_deg <    -0.0) {$position_deg += 360.0;}

    # convert data
    my $position_mdeg = $position_deg * 1000;
    
#print"go to position $position\n";

    # set motion task paramters
    # ORDER  nr  o_p  o_v  o_c  o_acc  o_dec  o_tab  reserved  o_fn  o_ft
    #	  nr    : number of motion task
    #	  o_p   : position in deg
    #	  o_v   : Speed [increments] = |O_P| * |PGEARO| / |PGEARI| / 4000     (default for PGEARO = 1048576)
    #	  o_c   : control word = 0x2000 = speed in SI units (depends on PGEARI)
    #	  o_acc : acceleration in ms to target speed
    #	  o_dec : deceleration in ms to target speed
    #	  o_tab : ???
    #	  o_fn can be used to define the number of the following motion block   # is -1 correct???
    #	  o_ft can be used to delay the start of the next motion task    
    $cmd = sprintf( "ORDER 1 %d %d 8192 %d %d 0 -1 0 0", int($position_mdeg), int($speed_deg_s), int($acceleration_deg_s2), int($acceleration_deg_s2));
    ($stat,$ret)=ar_transmit($table,$cmd);
    return $stat if ($stat<0);

    # enable amplifier
    ($stat,$ret)=ar_transmit($table,"EN");
    return $stat if ($stat<0);

	wait_ms(100);
	
    # start motion task
    ($stat,$ret)=ar_transmit($table,"MOVE 1");
    return $stat if ($stat<0);

    
    my $duration_ms = 0;
	my $timeStep_ms = 100;
	my $status_href;
    
    do{
        wait_ms($timeStep_ms);
        $duration_ms += $timeStep_ms;
	    if ($duration_ms > $move_timeout_ms){ 
	    	set_error("positioning timeout, time > $move_timeout_ms ms"); 
	    	return -1; 
	    }
        $status_href = ar_STATUS($table);
    
    } until( $status_href->{'inPosition'} );

    # DO NOT disable amplifier now, if this is done the position will not be accurate anymore

    return 0;
}

=head2 ar_wobble

    $stat = ar_wobble($table, $position1, $position2, $acceleration);

move table between given positions (clockwise) with given acceleration, covered angle will be $position2-$position1

=cut

sub ar_wobble{
    my $table = shift;
    my $pos1 = shift;
    my $pos2 = shift;
    my $acc = shift;
    my $cmd;
    
    my $nullCorrection;
    if ($table eq "V"){
        $nullCorrection=$nullPosV;
    }
    elsif ($table eq "H"){
        $nullCorrection=$nullPosH;
    }
    else{ set_error("wrong table $table"); return -1; }

    # stop rotation
    ($stat,$ret)=ar_transmit($table,"STOP");
    return $stat if ($stat<0);

    # set Position Resolution (Numerator)
    ($stat,$ret)=ar_transmit($table,"PGEARI 360000");
    return $stat if ($stat<0);

    # set position mode
    ($stat,$ret)=ar_transmit($table,"OPMODE 8");
    return $stat if ($stat<0);

    # disable amplifier
    ($stat,$ret)=ar_transmit($table,"DIS");
    return $stat if ($stat<0);

    my $angle = $pos2-$pos1;

    # convert position (0)-(+360)
    if      ($angle >= +360.0) {$angle = $angle - 360.0;}
    elsif ($angle <    -0.0) {$angle = $angle + 360.0;}

#print"wobble between $pos1 and $pos2 ($angle degree) with $acc\n";

    # calculate position concerning null position
    $pos1 = $nullCorrection - $pos1;

    # convert position (0)-(+360)
    if      ($pos1 >= +360.0) {$pos1 = $pos1 - 360.0;}
    elsif ($pos1 <    -0.0) {$pos1 = $pos1 + 360.0;}

    # convert data
    $pos1 = $pos1 * 1000;

    # convert data
    $angle = $angle * 1000;

    # set motion task parameters
    $cmd = sprintf( "ORDER 1 %d 30000 8200 1000 1000 0 -1 2 0", int($pos1));
    ($stat,$ret)=ar_transmit($table,$cmd);
    return $stat if ($stat<0);

    $cmd = sprintf( "ORDER 2 %d 30000 8201 %d %d 0 -1 3 0", int($angle)*-1,$acc,$acc);
    ($stat,$ret)=ar_transmit($table,$cmd);
    return $stat if ($stat<0);
#print"$cmd\n";

    $cmd = sprintf( "ORDER 3 %d 30000 8201 %d %d 0 -1 2 0", int($angle),$acc,$acc);
    ($stat,$ret)=ar_transmit($table,$cmd);
    return $stat if ($stat<0);
#print"$cmd\n";

    # enable amplifier
    ($stat,$ret)=ar_transmit($table,"EN");
    return $stat if ($stat<0);

    # start motion task
    ($stat,$ret)=ar_transmit($table,"MOVE 1");
    return $stat if ($stat<0);

    return 0;

}

=head2 ar_clearFaults

    $stat = ar_clearFaults($table);

clear faults and warnings for table

=cut

sub ar_clearFaults{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"CLRWARN 1");
    return $stat if ($stat<0);
    ($stat,$ret)=ar_transmit($table,"CLRFAULT");
    return $stat if ($stat<0);
    
    return 0;
}


=head2 ar_coldstart

    $stat = ar_coldstart($table);

coldstart (SW reset) for table

=cut

sub ar_coldstart{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"COLDSTART");
    
    return $stat;
}


=head2 ar_reset(); TBD

SW reset for whole system

=cut

sub ar_reset{

    # erase errors
    ar_clearFaults('H');
    ar_clearFaults('V');
    wait_ms(2000);


    # coldstart system
    ar_coldstart('H');
    ar_coldstart('V');
    wait_ms(11000);

    # get status
    ar_get_status('H');
    ar_get_status('V');

    # drive both tables in homing position, to have reference point and defined start
    ar_home('H');
    ar_home('V');
    
    # drive 0�-position
    ar_position('H', 0.000);
    ar_position('V', 0.000);

}

############################################################################################################

=head2 ar_disconnect

    $stat = ar_disconnect();

Stop both tables and disconnnect from AcuRot.

=cut

sub ar_disconnect{
    $stat = ar_stop('V');
    return $stat if ($stat<0);
    $stat = ar_stop('H');
    return $stat if ($stat<0);

    $stat = $COM_h->close;
    unless($stat){ set_error("Can't close COM$Hport: $!"); return -1; }
    $stat = $COM_v->close;
    unless($stat){ set_error("Can't close COM$Vport: $!"); return -1; }
    
    undef $COM_h;
    undef $COM_v;
    
    return 0;
}


=head2 ar_get_status($table); TBD

get status for table.

=cut

sub ar_get_status{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"STATCODE");
 print"stat: $ret\n";

    ($stat,$ret)=ar_transmit($table,"ERRCODE");
print"err: $ret\n";

    ($stat,$ret)=ar_transmit($table,"READY");
print"ready: $ret\n";

    ($stat,$ret)=ar_transmit($table,"REMOTE");
print"remote: $ret\n";

    return($ret);

}


=head2 ar_stop

    $stat = ar_stop($table);

stop table.

=cut

sub ar_stop{
    my $table = shift;

    ($stat,$ret)=ar_transmit($table,"STOP");
    return $stat if ($stat<0);

    # disable amplifier
    ($stat,$ret)=ar_transmit($table,"DIS");
    return $stat if ($stat<0);

    return 0;
}

=head2 ar_rotate

    $stat = ar_rotate($table, $speed_deg_s);

rotate table with speed (in deg/s).

=cut

sub ar_rotate{
    my $table = shift;
    my $speed_deg_s = shift;
    my $data="";
    my $cmd;

#print"ar_rotate($table,$speed)\n";

    ($stat,$ret)=ar_transmit($table,"EN");
    return $stat if ($stat<0);
    wait_ms(25);

    # speed safety limit
    if ( $speed_deg_s > $speed_safety_limit_deg_s or $speed_deg_s < -1 * $speed_safety_limit_deg_s ){
        set_error("speed safety limit violation: $speed_deg_s > $speed_safety_limit_deg_s");
        return -3;
    }

    ($stat,$ret)=ar_transmit($table,"OPMODE 0");    # digital velocity control mode
    return $stat if ($stat<0);
    
    $cmd = sprintf("J %.3lf", $speed_deg_s);    # constant velocity in deg/s

    ($stat,$ret)=ar_transmit($table,"$cmd");
    return $stat if ($stat<0);

    return 0;
}



################ advanced functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################

=head2 ar_transmit($table,$data);

    ($stat,$ret) = ar_transmit($table,$data);

Transmits the string $data on the COM port. IMPORTANT: this function attaches \r\n to $data, therefore $data must not contain linebreak.

returns status and return values as single string, where newlines are replaced by semicolon 

=cut

sub ar_transmit {
    my $COM;
    my $table = shift;
    my $data = shift;
    my $received;
    if ($table eq "V"){
        $COM=$COM_v;
    }
    elsif ($table eq "H"){
        $COM=$COM_h;
    }
    else{ set_error("wrong table $table"); return -1; }

    my $count = $COM->write($data."\r\n");
    unless ($count) {
        set_error("write COM failed");
        return (-1,'');
    }
    if ( $count != length($data)+2 ){
        set_error("write COM incomplete");
        return (-1,'');
    }

  #S_w2log(1, "Tx: $data ($count)\n"); # uncomment only for debugging and uncomment also use LIFT_general

     ($count,  $received) = $COM->read(200);

  #S_w2log(1, "Rx: $received ($count)\n"); # uncomment only for debugging and uncomment also use LIFT_general

	if($received =~ /^COL/){ # coldstart
		wait_ms(15000);
		return (0,$received);
	}

	if($received =~ /^ok/){ # response after coldstart
		wait_ms(5000);
		return (0,$received);
	}

    if ($received eq ''){
        set_error("no answer received!");
        return (-1,'');
    }

    unless ($received =~ s/\n-->$//){
        S_w2log(5, "Warning: end of received answer ('$received') is not as expected ('\n-->')!\n");
        #return (-1,'');
    }

    $received =~ s/\r//g; # drop all <Lf>
    my @lines=split(/\n/,$received); # split at <Cr>
    my $sent= shift(@lines); # first line is command echo

    if ($sent ne $data){
        S_w2log(5, "Warning: <$sent> ne <$data>\n");
        #return (-1,'');
    }

    $received = join (';',@lines); # re-combine string by replacing \n with ;

  #S_w2log(5, "ret: >$received<\n"); # uncomment only for debugging and uncomment also use LIFT_general

    return (0,$received);

}

sub ar_STATUS{
    my $table = shift;
    my $status_href = {
        'referencePointSet' => 0,
        'inPosition' => 0,
        'homingInProgress' => 0,
    };

    # read STATUS
    ($stat,$ret)=ar_transmit($table,"STATUS");
    return $status_href if ($stat<0);
    
    # check response
    if( $ret =~ /^H(\w{4})\sH(\w{8})\sH(\w{4})\sH(\w{4})\sH(\w{4})$/ ){
        # decode status words
        my $statusWord5 = hex($5);
        #print"statusWord5: $statusWord5\n";
        $status_href->{'referencePointSet'} = 1 if $statusWord5 & 0x02;
        $status_href->{'inPosition'} = 1 if $statusWord5 & 0x08;
        $status_href->{'homingInProgress'} = 1 if $statusWord5 & 0x20;
    }
    else{
        S_w2log(4, "Warning: unexpected response from STATUS: '$ret'! It should be 'Hxxxx Hxxxxxxxx Hxxxx Hxxxx Hxxxx'.\n");
    }
    return $status_href;
}

sub ar_get_speed_safety_limit{
    return $speed_safety_limit_deg_s;
}

sub ar_get_accel_limit{
    return $accel_limit_deg_s2;
}

sub set_error{
    $error_text = shift;    
    S_w2log(1, "!!!: $error_text\n");
}


sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}

##############################################################################################################################
##############################################################################################################################
#
# simulation functions start here
#

if ( $main::opt_simulation ){

    # redefine all functions that have  for simulation mode with default return values
    my @hw_access_functions = qw(ar_connect ar_disconnect ar_transmit);
    foreach my $function ( @hw_access_functions ){
        no strict 'refs';
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'ar_connect' => { 'default' => [ 0 ], },
        'ar_disconnect' => { 'default' => [ 0 ], },
        'ar_transmit' => { 'default' => [ 0, 1 ], },
    };
    SIM_addToValuesTable( $returnValuesTable_href );

    *ar_transmit = sub{
        my $table = shift;
        my $data = shift;
        
        if( $data eq "STATUS" ) {
            return SIM_returnValues('ar_transmit', [0, 'H0000 H00000000 H0000 H0000 H000F'], [$table, $data]); 
        }
        elsif( $data eq "ERRCODE" ){
            return SIM_returnValues('ar_transmit', [0, 'no errors'], [$table, $data]);
        }

        # by default return the string that is transmit as second return value
        return SIM_returnValues('ar_transmit', [0, $data], [$table, $data]); 
    };

}

1;



=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, AcuRot manual.

=cut



