package LIFT_ACUROT;

use strict;
use warnings;
use LIFT_general;
use ACUROT;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  AR_init
  AR_wobble
  AR_stop
  AR_rotate
  AR_position
  AR_get_position
  AR_exit
);

our ( $VERSION, $HEADER );

my ( $AR_initialized, $COMv, $COMh, $nullPosH, $nullPosV, $nullPosition_deg );
my ( $stat, $data );

# take speed safety limit from low level module
my $speed_safety_limit_deg_s = ar_get_speed_safety_limit();
my $accel_limit_deg_s2 = ar_get_accel_limit();

=head1 NAME

LIFT_ACUROT 


=head1 SYNOPSIS

    use LIFT_ACUROT;

    AR_init();

    AR_wobble("H",2.5,100.5,100);
    AR_stop("H");
    AR_rotate("V",200);
    AR_position("H", 90);

    AR_exit();


=head1 DESCRIPTION

Provide the possibility to control the ACUROT. 
There are 2 tables in the ACUROT oin which the ECU can be mounted: 
an upper table with a horizontal axis ('H') and a lower table with a vertical axis ('V').
Defined positions and rotations can be set on the ACUROT tables. 

=head2 Testbench configuration

=head3 Devices section:

    'Devices' => {
        ...
        'ACUROT' => {
            'COM_hor'  => 3,            # COM port for horizontal axis
            'zero_hor' => 4.647000,     # offset for horizontal axis zero position
            'COM_ver'  => 4,            # COM port for vertical axis
            'zero_ver' => 292.192000,   # offset for vertical axis zero position
        },
        ...
    },

=cut

=head1 Functions

=head2 AR_init

    AR_init();

initialize ACUROT hardware and move both tables to zero position.

has to be called before any other AR command. has to be called in INITcampaign.

=cut

sub AR_init
{
    my $AR_info;
    $AR_info = "";

    if ($AR_initialized)
    {
    	S_set_warning( "ACUROT already initialized");
        return 1;
    }

    S_w2log( 1, "AR_init: Initialize the Acurot, please wait... \n" );

    # check testbench config
    {
        no warnings;
        $COMh     = $LIFT_config::LIFT_Testbench->{'Devices'}{'ACUROT'}{'COM_hor'};
        $COMv     = $LIFT_config::LIFT_Testbench->{'Devices'}{'ACUROT'}{'COM_ver'};
        $nullPosH = $LIFT_config::LIFT_Testbench->{'Devices'}{'ACUROT'}{'zero_hor'};
        $nullPosV = $LIFT_config::LIFT_Testbench->{'Devices'}{'ACUROT'}{'zero_ver'};
    }
    if( not defined $COMh )
    {
        S_set_error( "No COM_hor settings for ACUROT in testbench config found", 20 );
        return "";
    }
    if( not defined $COMv)
    {
        S_set_error( "No COM_ver settings for ACUROT in testbench config found", 20 );
        return "";
    }
    if ( not defined $nullPosH)
    {
        S_set_error( "No zero_hor settings for ACUROT in testbench config found", 20 );
        return "";
    }
    if ( not defined $nullPosV)
    {
        S_set_error( "No zero_ver settings for ACUROT in testbench config found", 20 );
        return "";
    }

    if ($main::opt_offline)
    {
    	S_w2log( 4, "AR_init: Initialized successfully \n" );
        $AR_initialized = 1;
        return 1;
    }

    $stat = ar_connect( $COMv, $COMh );
    check_status($stat);
    S_w2log( 5, "ar_connect status: $stat \n" );

    $AR_initialized = 1;

    if ( $stat != 0 )
    {
        S_set_error( "could not initialize ACUROT", 5 );
        $AR_initialized = 0;
    }

    ( $stat, $data ) = ar_get_firmware("V");
    check_status($stat);
    $AR_info .= "FW_V: $data";

    ( $stat, $data ) = ar_get_firmware("H");
    check_status($stat);
    $AR_info .= ", FW_H: $data";

    ( $stat, $data ) = ar_get_HWversion("V");
    check_status($stat);
    $AR_info .= ", HW_H: $data";

    ( $stat, $data ) = ar_get_HWversion("H");
    check_status($stat);
    $AR_info .= ", HW_V: $data";

    S_w2log( 5, "AR_init:: Acurot firmware and hardware information :: \n $AR_info\n" );

    S_w2log( 4, "moving upper table to home and zero position, please wait...\n" );
    $stat = ar_init( "H", $nullPosH );
    check_status($stat);
    S_w2log( 4, "moving lower table to home and zero position, please wait...\n" );
    $stat = ar_init( "V", $nullPosV );
    check_status($stat);

    S_w2log( 4, "AR_init: Initialized successfully \n" );
	return 1;
}

=head2 AR_wobble

    AR_wobble($table, $position1, $position2, $acceleration);

move table between given positions (clockwise) with given acceleration, covered angle will be $position2-$position1

=cut

sub AR_wobble
{
    my ( $table, $position1, $position2, $acceleration ) = @_;

    unless ( defined($acceleration) )
    {
        S_set_error( "SYNTAX: AR_wobble(\$table, \$position1, \$position2, \$acceleration)", 110 );
        return 0;
    }

    unless ($AR_initialized)
    {
        S_set_error( "ACUROT not initialized", 120 );
        return 0;
    }

    $table = Check_table($table) or return 0;

    S_w2log( 4, "AR_wobble ($table, $position1, $position2, $acceleration)\n" );

    if ( $position1 !~ /^[+-]?\d+\.?\d*$/ )
    {
        S_set_error( "position1 $position1 is not a valid number", 114 );
        return 0;
    }
    if ( $position2 !~ /^[+-]?\d+\.?\d*$/ )
    {
        S_set_error( "position2 $position2 is not a valid number", 114 );
        return 0;
    }
    if ( $acceleration !~ /^[+-]?\d+\.?\d*$/ )
    {
        S_set_error( "acceleration $acceleration is not a valid number", 114 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = ar_wobble( $table, $position1, $position2, $acceleration );
    check_status($stat);
    S_w2log( 5, "ar_wobble status: $stat \n" );
	return 1;

}

=head2 AR_stop

    AR_stop($table);

stop table

=cut

sub AR_stop
{
    my $table = shift;

    unless ( defined($table) )
    {
        S_set_error( "SYNTAX: AR_stop(\$table)", 110 );
        return 0;
    }

    unless ($AR_initialized)
    {
        S_set_error( "ACUROT not initialized", 120 );
        return 0;
    }

    $table = Check_table($table) or return 0;

    S_w2log( 4, "AR_stop ($table)\n" );

    return 1 if $main::opt_offline;

    $stat = ar_stop($table);
    check_status($stat);
    S_w2log( 5, "ar_stop status : $stat \n" );

    S_w2log( 5, "AR_wobble: Stopped the Acurot \n" );
	return 1;
}

=head2 AR_rotate

    AR_rotate($table, $speed);

rotate table with speed (in �/s).

=cut

sub AR_rotate
{
    my ( $table, $speed ) = @_;

    unless ( defined($speed) )
    {
        S_set_error( "SYNTAX: AR_rotate(\$table, \$speed)", 110 );
        return 0;
    }

    unless ($AR_initialized)
    {
        S_set_error( "ACUROT not initialized", 120 );
        return 0;
    }

    $table = Check_table($table) or return 0;

    S_w2log( 4, "AR_rotate ($table, $speed)\n" );

    if ( $speed !~ /^[+-]?\d+\.?\d*$/ )
    {
        S_set_error( "speed $speed is not a valid number", 114 );
        return 0;
    }

    # speed limit
    if ( $speed > $speed_safety_limit_deg_s or $speed <= -1 * $speed_safety_limit_deg_s)
    {
        S_set_error( "speed limit violation: |$speed| > $speed_safety_limit_deg_s deg/s", 114 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = ar_rotate( $table, $speed );
    check_status($stat);
    S_w2log( 5, "ar_rotate status: $stat \n" );


	return 1;
}

=head2 AR_position

    AR_position($table, $position_deg [, $speed_deg_s, $acceleration_deg_s2]);

Move table $table to given position $position_deg (in �, range is -360 .. 360).
Speed of positioning can be given in $speed_deg_s in deg/s (default = 360 deg/s, limit = 3000 deg/s).
Acceleration until max positioning speed can be given in $acceleration_deg_s2 in deg/s2 (default = 1000 deg/s2, limit = 20000 deg/s2).

=cut

sub AR_position
{
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'AR_position($table, $position_deg [, $speed_deg_s, $acceleration_time_ms])', @args );

    my $table = shift @args;
    my $position = shift @args;
    my $speed_deg_s = shift @args;
    my $acceleration_deg_s2 = shift @args;

    $speed_deg_s = 360 if not defined $speed_deg_s;
    $acceleration_deg_s2 = 1000 if not defined $acceleration_deg_s2;    

    unless ($AR_initialized)
    {
        S_set_error( "ACUROT not initialized", 120 );
        return 0;
    }

    $table = Check_table($table) or return 0;

    S_w2log( 4, "AR_position ($table, $position, $speed_deg_s, $acceleration_deg_s2)\n" );
    if ( $position !~ /^[+-]?\d+\.?\d*$/ )
    {
        S_set_error( "position $position is not a valid number", 114 );
        return 0;
    }

    # position limit
    if ( $position > 360 or $position < -360 )
    {
        S_set_error( "given position $position is out of range (-360� .. 360�)", 114 );
        $position = 0.0;
        return 0;
    }

    # speed limit
    if ( $speed_deg_s > $speed_safety_limit_deg_s or $speed_deg_s <= 0)
    {
        S_set_error( "speed limit violation: $speed_deg_s > $speed_safety_limit_deg_s deg/s or <= 0 deg/s", 114 );
        return 0;
    }

    # acceleration limit
    if ( $acceleration_deg_s2 > $accel_limit_deg_s2 or $acceleration_deg_s2 <= 0)
    {
        S_set_error( "acceleration limit violation: $acceleration_deg_s2 > $accel_limit_deg_s2 deg/s2 or <= 0 deg/s2", 114 );
        return 0;
    }

    return 1 if $main::opt_offline;

    $stat = ar_position( $table, $position, $speed_deg_s, $acceleration_deg_s2 );
    check_status($stat);
    S_w2log( 5, "ar_position status : $stat \n" );
	return 1;

}

=head2 AR_exit

    AR_exit();

Stop both tables and disconnect from ACUROT hardware. Has to be called in ENDcampaign.

=cut

sub AR_exit
{

    unless ($AR_initialized)
    {
        S_set_warning( "ACUROT not initialized");
        return 1;
    }

    if ($main::opt_offline)
    {
        $AR_initialized = 0;
        return 1;
    }

    S_w2log( 4, "AR_exit:: Terminating the communication \n " );
    $stat = ar_disconnect();
    check_status($stat);
    S_w2log( 5, "ar_disconnect status : $stat \n" );

    $AR_initialized = 0;

    S_w2log( 5, "AR_exit: Terminated the communication with acurot \n" );
	return 1;
}

=head2 AR_get_position

    $position_deg = AR_get_position( $table );

Returns the current position of the table $table in deg.

Returns 0 in offline mode and undef on error.

=cut

sub AR_get_position{
    my @args = @_;
    S_checkFunctionArguments( 'AR_get_position( $table )', @args ) or return;

    my $table = shift @args;

    unless ($AR_initialized){
        S_set_error( "ACUROT not initialized", 120 );
        return;
    }

    Check_table( $table ) or return;
    S_w2log( 4, "AR_get_position( $table )\n" );

    return 0 if $main::opt_offline;

    my ($stat,$positionNoNullCorr_mdeg) = ar_get_position($table);
    if( $stat < 0 ) {
        S_set_error( "Current position of table $table could not be determined", 120 );
        return;
    }

    my $position_deg = $nullPosition_deg - $positionNoNullCorr_mdeg/1000;
    
    return $position_deg;
}

=head1 not exported functions

=head2 check_status

 check_status($result) not exported

if result != 0, log error and set INCONC.

=cut

sub check_status
{
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status != 0 )
    {
        S_set_error( "ACUROT Tool error", 5 );
    }

}

sub Check_table{
    my $table = shift;

    # check for correct table
    if( $table =~ /^(h|x|y)$/i ) {
        $table = 'H';
        $nullPosition_deg = $nullPosH;
    }
    elsif( $table =~ /^(v|z)$/i ) {
        $table = 'V';
        $nullPosition_deg = $nullPosV;
    }
    else{
        S_set_error( "Given table ($table) is unknown. It must be one of V, H, X, Y, Z.", 114 );
        return;        
    }
    return $table;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

