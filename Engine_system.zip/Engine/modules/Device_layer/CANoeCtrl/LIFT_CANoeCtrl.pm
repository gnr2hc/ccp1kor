# *****************************************************************************************************
#
#  Copyright (c)  Robert Bosch GmBH
#                 Germany
#                 All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CANoeCtrl;

use strict;
use warnings;
use File::Basename;

my $addpath;

BEGIN {
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use CANoeCtrl;
use LIFT_general;
use LIFT_numerics;
use LIFT_CANoe_device;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_CANoeCtrl ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [qw()] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  CANoeCtrl_Init
  CANoeCtrl_SetSystemVariablesValues
  CANoeCtrl_CAPL_config
  CANoeCtrl_CAPL_register
  CANoeCtrl_ResetOutputSignal

  CANoeCtrl_load_signal_curves
  CANoeCtrl_loadSignalCurve
  CANoeCtrl_SetOutputSignal
  CANoeCtrl_SetTimedSignal

  CANoeCtrl_StartMeasurement
  CANoeCtrl_EnableOutputTriggers
  CANoeCtrl_SetSoftwareTrigger
  CANoeCtrl_CallCapl
  CANoeCtrl_StopMeasurement
  CANoeCtrl_Exit
  CANOECTRL_FAILED
  CANOECTRL_OFFLINE
  CANoeCtrl_isItInitialized
  CANoeCtrl_getSignalLimits
  CANoeCtrl_validSignalDataPoints
  CANoeCtrl_rdPrjConst_signalIndex
  CANoeCtrl_incMaxOutputSignals
);

# functions not used by TurbolIFT
# -> done by CANoe trace & LIFT Evaluation module
# CANoeCtrl_SetAnalysisSignal
# CANoeCtrl_GetSignalTimes
# CANoeCtrl_SetMonitoringTime

# -> alternative is to use -> CA_write_can_signal / LIN_write_LIN_signall / FR_write_flxr_signal
# CANoeCtrl_SetSignalNow

our ( $VERSION, $HEADER );

use constant CANOECTRL_FAILED  => 0;    #Return value when function failed - must be always FALSE
use constant CANOECTRL_OFFLINE => 1;    #Return value when function is called in offline mod

# my $status;  #Status value of the functions
my $CANoe_Init = 0;                     # Initialization  flag
my $measure    = 0;                     # Measurement Flag

my $CN_control;

=head1 NAME

LIFT_CANoeCtrl 

Perl extension for CANoe Control application

=head1 SYNOPSIS

    use LIFT_CANoeCtrl;
    
    # initialize CANoeCtrl (load dlls (CANoeCtrl_Control.dll, CANoeCtrl.dll), establish DCOM, 
    # open CANoe Application, load .cfg configuration & register CAPL functions)   
    CANoeCtrl_Init();
    
    # configure CAPL function
    CANoeCtrl_CAPL_config('TestFunction_1', 'TestFunction_2');
    CANoeCtrl_CAPL_register();
    
    # configure the signals (output, timed & analysis), before measurement starts
    my @OutputSignal = (1..50);
    $status = CANoeCtrl_SetOutputSignal('SigStimulus1_CAN', \@OutputSignal, '10', 'triggersoft');
    $status = CANoeCtrl_SetTimedSignal('SigTimed1_CAN', '80.25', 'triggersoft', '0', '0');
    $status = CANoeCtrl_SetTimedSignal('SigTimed2_CAN', '150.25', 'triggersoft', '1000', '0');       
    #$status = CANoeCtrl_SetAnalysisSignal('Allrad_SNI', 'Lessthan', 100.0, 'TriggerSoft');
    #$status = CANoeCtrl_SetMonitoringTime(100);
    
    # start measurement (Rest bus simulation) & set trigger (either SW or HW)     
    $status = CANoeCtrl_StartMeasurement('-1');  
    #$status = CANoeCtrl_SetSignalNow("CAN1::Signal1", 100.0);
    $status = CANoeCtrl_enableOutputTriggers();
    $status = CANoeCtrl_setSoftwareTrigger();
     
    ($status, $result) = CANoeCtrl_CallCapl('TestFunction_1');
    ($status, $result) = CANoeCtrl_CallCapl('TestFunction_2, '10');
    
    # stop measurement (RBS)
    $status = CANoeCtrl_StopMeasurement(-1);
    #$status = CANoeCtrl_GetSignalTimes(10);
    $status = CANoeCtrl_ResetOutputSignal();       
    
    # Uninitialize CANoeCtrl (unload dlls & release DCOM)
    CANoeCtrl_Exit('-1', '0');

=head2 Testbench configuration

   'SI-Z0IUA' => {      # LIFT PC host name
    ### ----------- Device Configuration Section -----------
    'Devices' => {
        'CANoe' =>{
            'Hostname' => 'SI-Z0IUA',
            'Online_Config' => 'C:\TestSw\dllprojects\CANoeCtrl\demo\COMDemo.cfg',
            'Log_File' => 'C:\TestSw\dllprojects\CANoeCtrl\demo\CANOE.ASC',
        },
    }, ## end of ~~~ Device Configuration Section ~~~



=head2 Project configuration

    $Defaults = 
    {	
        'CANoe' => {
           'CAPL_Functions' =>  [ 'CAPL_function1', 'CAPL_function2'],           
        },
            
        ### 1 CANoeCtrl
        'CANoeCtrl' => {
            ## 1.1 CANoeCtrl => OutputSignals
            'OutputSignals' => {		
                # 1.1.1 1st OutputSignal
                'SigStimulus1_CAN' => {
                    'Index' => 0,           # index number if a signal
                    'CycleTime' => 20,      # cycle time normal (slow)
                    'DefaultValue' => 1,             # optional  ?? -> currently not used for downsampling because no guarantee equal to inactive value
                    'CycleTimeFast' => 10,           # optional    
                    'InactiveValue' => 0,            # optional -> specified by user   
                    'NumRepetitionsOnChange' => 10   # optional 
                },
				
                # 1.1.2 2nd OutputSignal
                'SigStimulus2_CAN' => {
                    'Index' => 1,
                    'CycleTime' => 20,
                    'DefaultValue' => 10,	
                },			
                
                # .. so on
            },
			
            ## 1.2 CANoeCtrl => TimedSignals
            'TimedSignals' => 
            {		
                # 1.2.1 1st TimedSignal
                'SigTimed1_CAN' => {    
                    'Index' => 0,
                },
				
                # 1.2.1 2nd TimedSignal
                'SigTimed2_CAN' => {   
                    'Index' => 1,
                },
                
                # .. so on	
            },
			 
            ## 1.3 CANoeCtrl => AnalysisSignals
            'AnalysisSignals' => {
                'LRRS_Location_01_RCS_Ang_02' => {
                    'Index' => 0,
                    'Triggertype' => 'Triggersoft'
                    'Operator' => 'Equals'
                    'Threshold' => '1.1',
                },
                'Allrad_SNI' => {
                    'Index' => 1,
                    'Triggertype' => 'Triggersoft'
                    'Operator' => 'Lessthan'
                    'Threshold' => '1.1'
                },
                # .. so on                
            },
			
      },
       
         
    };


=cut

=head1 Exported Subroutines

=head2 CANoeCtrl_CAPL_config

    CANoeCtrl_CAPL_config( [$function_to_configure_aref] );

Configures the CAPL functions (stores into hash for later registering them). 

B<Note> : This should be called before start of the measurement. 
call  L</"CANoeCtrl_CallCapl"> to invoke it later after start of measurement.

B<Arguments:>

=over

=item $function_to_configure_aref 

(optional) list of one or more function(s) to be configured before calling it. 
If not given then if will search if functions are given in the project constant [ 'CANoe', 'CAPL_Functions' ] to configure..

=back

B<Return Value:>

= B<1> : Successful & Offline - B<undef> : Failure

B<Examples:>

    CANoeCtrl_CAPL_config( ['MyCAPLFunc', 'MyCAPLFunc1', 'MyCAPLFunc2'] );
    CANoeCtrl_CAPL_config( ); # get the CAPL fucntion list from project constant.

=cut

sub CANoeCtrl_CAPL_config {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_CAPL_config ( [$function_to_configure_aref] )', @args );
    my $function_to_configure_aref = shift @args;

    S_w2log( 5, " CANoeCtrl_CAPL_config : start.\n" );

    if ( not defined $function_to_configure_aref ) {
        my $capl_functions_prjConst = S_get_contents_of_hash( [ 'CANoe', 'CAPL_Functions' ] );
        unless ($capl_functions_prjConst) {
            S_set_error( " CANoeCtrl_CAPL_config : CAPL functions are not defined in Project Defaults : 'CANoe' => {CAPL_Functions => []}.", 131 );
            return;
        }
        $function_to_configure_aref = $capl_functions_prjConst;
        S_w2log( 4, " CANoeCtrl_CAPL_config : CAPL functions from Project Defaults are : '@{$function_to_configure_aref}' \n" );
    }

    # use only unique value
    foreach my $function (@$function_to_configure_aref) {
        $function =~ s/^\s+//;    ## delete leading white spaces
        $function =~ s/\s+$//;    ## delete trailing white spaces

        if ( !grep { $function eq $_ } @{ $CN_control->{'CAPL'}->{'Functions'} } ) {
            push @{ $CN_control->{'CAPL'}->{'Functions'} }, $function;
        }
    }

    # register CAPL functions
    CANoeCtrl_CAPL_register();

    S_w2log( 5, " CANoeCtrl_CAPL_config : End.\n" );
    return 1;
}

=head2 CANoeCtrl_CAPL_register

    CANoeCtrl_CAPL_register(  );

Register the CAPL functions which was configred by 'CANoeCtrl_CAPL_config' 
 
 To call/invoke registered CAPL function call the functionality 'CANoeCtrl_CallCapl'. 
 
 Example : 
    CANoeCtrl_CAPL_register();
    
=cut

sub CANoeCtrl_CAPL_register {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_CAPL_register ()', @args );

    my $capl_handle;

    # get the CAPL handle(s) for
    foreach my $capl_function_Name ( @{ $CN_control->{'CAPL'}{'Functions'} } ) {
        undef $CN_control->{'CAPL'}{$capl_function_Name};

        # store the CAPL handle
        $capl_handle = CANoeCtrl_RegisterCaplFunction($capl_function_Name);

        unless ( defined $capl_handle ) {
            S_set_error( " CANoeCtrl_CAPL_register : CAPL function '$capl_function_Name' not registered.\n", 140 );
        }

        # register CAPL function(s)
        if ( defined $capl_handle ) {
            S_w2log( 4, " CANoeCtrl_CAPL_register : CAPL function '$capl_function_Name' registered successfuly.\n" );
            $CN_control->{'CAPL'}{$capl_function_Name}{'handle'} = $capl_handle;
        }
    }
    return 1;
}


=head2 CANoeCtrl_CallCapl

    ($status, $result) = CANoeCtrl_CallCapl ($func_name, [ $func_param_aref ]);

Calls the registered CAPL function with input arguments of the function.

B<Notes:> 

This can only be done during measurement (RBS is running). 
The passed number of arguments must be the same as the CAPL function in CANoe expects,
CAPL functions with return values are only supported in the evaluation branch of the CANoe configuration, 
i.e. CAPL functions in programs assigned to network nodes in the simulation setup cannot return result values.

B<Arguments:>

=over

=item $func_name 

Function name from that must be configured first by  L</"CANoeCtrl_CAPL_config">

=item $func_param_aref 

(optionals) val1, val2, .. val8 - Input parameters for the given function name if any, max 8

=back

B<Return Value:>

=over

=item Offine & Success = 1

=back

B<Examples:>

    CANoeCtrl_CallCapl('MyCAPLFunc');
    CANoeCtrl_CallCapl( 'MyCAPLFunc1', [100] );
    CANoeCtrl_CallCapl( 'MyCAPLFunc2', [200, 201] );    

=cut

sub CANoeCtrl_CallCapl {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_CallCapl ($func_name, [ $func_param_aref ])', @args );
    my $func_name       = shift @args;    # Mandatory parameter
    my $func_param_aref = shift @args;    # Optional parameter(s)

    S_w2log( 4, "CANoeCtrl_CallCapl (  $func_name ). \n" );

    my $func_val = $CN_control->{'CAPL'}{$func_name}{'handle'};
    unless ( defined $func_val ) {
        S_set_error( "CANoeCtrl_CallCapl : CAPL Function $func_name is not registered, cannot call the CAPL function \n", 114 );
        return;
    }

    if ( defined $func_param_aref ) {
        my $nbrArgs = scalar(@$func_param_aref);
        if ( $nbrArgs == 0 ) {
            @$func_param_aref = ();
            S_w2log( 4, "CANoeCtrl_CallCapl: No input params are given \n" );
        }

        if ( $nbrArgs > 8 ) {
            S_set_error( "CANoeCtrl_CallCapl: Maximum 8 input param are allowed ( 0 <= Input_params <= 8) \n", 114 );
            return;
        }
    }
    else {
        @$func_param_aref = ();
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_CallCapl : CANoeCtrl not initialized \n", 120 );
        return;
    }

    return ( CANOECTRL_OFFLINE, CANOECTRL_OFFLINE ) if ($main::opt_offline);

    my ( $result, $status );

    # invoke CAPL function
    ( $status, $result ) = canoectrl_callCAPL( $func_val, $func_param_aref );
    Check_status( $status, "Failed in calling capl function ( $func_name ), handle ( $func_val )" );

    S_w2log( 4, "CANoeCtrl_CallCapl : Status of function ( $func_name ), args =  ( @$func_param_aref ) :: $status. \n" );

    return ( $status, $result );
}

=head2 CANoeCtrl_EnableOutputTriggers

 Function Name   :: CANoeCtrl_EnableOutputTriggers

 Description     :: Enables signal output triggers. 
                    Before the call of this function, any hardware or software trigger has no effect.
                    This function does not start the output itself, but just enables the output triggers. 
                    This function can only be called when measurement (RBS) is running, 
                    otherwise it has no effect and 0 is returned.

 Syntax          :: $status = CANoeCtrl_EnableOutputTriggers();

 Input Arguments :: None

 Return Value(s) :: 1 = if the triggers could be enabled, otherwise 0.
                    0 = if the triggers could not be enabled or CANoeCtrl is not initialized.
                    
 Example         :: $status = CANoeCtrl_EnableOutputTriggers();

=cut

sub CANoeCtrl_EnableOutputTriggers {

    my $status = 0;
    S_w2log( 4, "CANoeCtrl_EnableOutputTriggers \n" );

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_EnableOutputTriggers : CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    $status = canoectrl_enableOutputTriggers();

    Check_status( $status, "CANoeCtrl_EnableOutputTriggers : Failed to enable output trigger \n" );
    S_w2log( 4, "CANoeCtrl_EnableOutputTriggers status :: $status \n" );

    return $status;
}

=head2 CANoeCtrl_Exit

 Function Name   :: CANoeCtrl_Exit

 Description     :: Disconnect the CANoe application and closes CANoe if the parameter "exit_appl" is not 0.
                    Uninitialize CANoe dlls.
 
 Syntax          :: CANoeCtrl_Exit(Timeout_ms, exit_appl);

 Input Arguments :: timeout_ms : The maximum time in milliseconds that the client should wait until CANoe is quit.
                              = -1 is an infinite timeout, i.e. the thread is blocked until it receives
                                 the OnQuit event from CANoe via COM.
                    exit_appl =  0 : CANoe application is closed.
                             !=  0 : Only the COM is disconnected from the application.  
 						
 Return Value(s) :: = 1 : if the DCOM connection and CANoe (if quit is not 0) could be closed within the given time.
                    = 0 : failue initialization CANoeCtrl
                        : Failure closing DCOM connection & CANoe.   

 Example         :: CANoeCtrl_Exit( -1 , 0 );  # 0 - keeps application alive 

=cut

sub CANoeCtrl_Exit {
    S_w2log( 4, "CANoeCtrl_Exit \n" );

    my $timeout_ms = shift;
    my $exit_appl  = shift;

    my $status = 0;

    unless ( defined $timeout_ms ) {
        S_w2log( 4, "CANoeCtrl_Exit : Parameter timeout_ms is not given. Considering -1 (infinite) \n" );
        $timeout_ms = -1;
    }

    unless ( defined $exit_appl ) {
        S_w2log( 4, "CANoeCtrl_Exit : Parameter exit_appl is not given. Considering (0) CANoe tion will stay again \n" );
        $exit_appl = 0;
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_Exit: CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    if ($main::opt_offline) {
        $CANoe_Init = 0;
        return CANOECTRL_OFFLINE;
    }

    $status = canoectrl_cnDisconnectFromCanoe( $exit_appl, $timeout_ms );
    Check_status( $status, "CANoeCtrl_Exit: Disconnecting from CANoe failed " );
    S_w2log( 4, "CANoeCtrl_Exit: Status of canoectrl_cnDisconnectFromCanoe :: $status \n" );

    # Uninitialize COM & free DLL
    my $un_init_status = canoectrl_cnUninitialize();
    Check_status( $status, "CANoeCtrl_Exit: Unintialization of DCOM  & free DLL failed " );
    S_w2log( 4, "CANoeCtrl_Exit: Status of canoectrl_cnUninitialize :: $status \n" );
    $CANoe_Init = 0 if ( ( $status > 0 ) && ( $un_init_status > 0 ) );

    return $status;

}

=head2 CANoeCtrl_Init

 Function Name   :: CANoeCtrl_Init

 Description     :: Initialization of CANoeCtrl Module. It does following steps : 
                    load dlls (CANoeCtrl_Control.dll, CANoeCtrl.dll)
                    Establish DCOM Connection & Launch CANoe Application
                    Load CANoe configuration (.cfg file) 
                    Register CAPL function (optional)
                    Performing CANoe setting as defined in project defaults.

 Syntax          :: CANoeCtrl_Init();

 Input Arguments :: None

 Return Value(s) :: None

 Example         :: CANoeCtrl_Init();

=cut

sub CANoeCtrl_Init {
    my $status = 0;
    S_w2log( 5, "CANoeCtrl_Init: Starting \n" );

    ###  Step 1 ) READ & validate TEST BENCH CONFIGURATION
    ###  CANoe configuration from  Test-bench   ###
    my $canoeCnfg_settings = S_get_contents_of_hash( [ 'Devices', 'CANoe' ], $LIFT_config::LIFT_Testbench );

    # Testbench ---------> hostname
    my $hostname = $canoeCnfg_settings->{'Hostname'};

    unless ($hostname) {
        S_set_error( " CANoeCtrl_Init failed : => {'Devices'}{'CANoe'}{'Hostname'} is not defined in Testbench. \n", 5 );
        return CANOECTRL_FAILED;
    }

    # Testbench ---------> CANoe Config file (.cfg file)
    my $configfile = $canoeCnfg_settings->{'Online_Config'};
    unless ($configfile) {
        S_set_error( " CANoeCtrl_Init failed : => {'Devices'}{'CANoe'}{'Online_Config'} is not defined in Testbench. \n", 5 );
        return CANOECTRL_FAILED;
    }
    unless ( $configfile =~ /\.cfg$/i ) {
        S_set_error( " CANoeCtrl_Init: Given file is not a config file for 'CANoe' in Testbench ($configfile)\n", 5 );
        return CANOECTRL_FAILED;
    }

    ###  Step 2 ) CHECK : CANoeCtrl module is already initialized
    if ($CANoe_Init) {
        S_set_warning("CANoeCtrl_Init : already initialized");
        return 1;
    }

    ###  Step 3 )  READ & validate PROJECT CONSTANT CONFIGURATION
    # Checking for redundancy in the Signal names\Index values of signals
    my ( $dup_tym, $dup_out ) = Signal_Ndx_Dup( $main::ProjectDefaults->{'CANoeCtrl'} );

    # timed signals
    if ( scalar(@$dup_tym) > 0 ) {
        S_set_error( "Index value of mentioned timed signal @$dup_tym is\are duplicated \n", 114 );
        return CANOECTRL_FAILED;
    }

    # Output signals
    if ( scalar(@$dup_out) > 0 ) {
        S_set_error( "Index value of mentioned output signal @$dup_out is\are duplicated \n", 114 );
        return CANOECTRL_FAILED;
    }

    ###  Step 4 )  OFFLINE MODE
    if ($main::opt_offline) {
        $CANoe_Init = 1;
        S_w2log( 4, "CANoeCtrl_Init: Initialization successful\n" );
        return CANOECTRL_OFFLINE;
    }

    my $version;
    $version = canoectrl_getPMrevision();
    S_w2log( 4, "PM $version\n" );
    $version = canoectrl_getXSrevision();
    S_w2log( 4, "XS $version\n" );
    $version = canoectrl_getCWrevision();
    S_w2log( 4, "CW $version\n" );

    ###  Step 5 )  DCOM initialization
    my $init_status = canoectrl_cnInitialize();
    Check_status( $init_status, "canoectrl_cnInitialize :: Initialization Failed" );
    S_w2log( 4, " CANoeCtrl_Init: Status of canoectrl_cnInitialize :: $init_status \n" );

    ###  Step 6 )  Connect to CANoe application
    $status = canoectrl_cnConnectToCanoe($hostname);
    Check_status( $status, "CANoeCtrl_Init: Connection to CANoe Failed " );
    S_w2log( 4, " CANoeCtrl_Init: Status of canoectrl_cnConnectToCanoe :: $status \n" );

    ###  Step 7 ) SET INIT Flag for CANoeCtrl
    $CANoe_Init = 1 if ( ( $init_status > 0 ) && ( $status > 0 ) );
    $CN_control->{'flag'}{'CANoeCtrlUsed'} = 1;

    ###  Step 8 ) Load CANoe configuration flie (.cfg file)
    $status = CANoeCtrl_Loadconfig($configfile);
    Check_status( $status, "CANoeCtrl_Init: loading Configuration failed " );

    #Analysis signals setting
    #if ( defined $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'} ) {
    #    my @Ana_signal_name = keys( %{ $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'} } );
    #    foreach my $signal_name (@Ana_signal_name) {
    #        $status = &CANoeCtrl_SetAnalysisSignal($signal_name);
    #    }
    # }

    # Get the limits of the signal.
    
    CANoeCtrl_incMaxOutputSignals();
    
    my $signalLimits_href = CANoeCtrl_getSignalLimits();
    if ( defined $signalLimits_href ) {
        my $msg =
            "MAX_DATA_POINTS_SIGNAL = $signalLimits_href->{'MAX_DATA_POINTS_SIGNAL'}, "
          . "MAX_NBR_OUTPUT_SIGNAL = $signalLimits_href->{'MAX_NBR_OUTPUT_SIGNAL'}, "
          . "MAX_NBR_TIMED_SIGNAL = $signalLimits_href->{'MAX_NBR_TIMED_SIGNAL'}, "
          . "MAX_NBR_ANALYSIS_SIGNAL = $signalLimits_href->{'MAX_NBR_ANALYSIS_SIGNAL'}.";
        S_w2log( 4, "CANoeCtrl_Init : Signal Limits - $msg \n", 'grey' );
    }
    else {
        S_set_error( "CANoeCtrl_Init : Could not retrive signal limits. Most likely is the problem with CANoeCtrl dll or its XS interface.\n", 120 );
    }

    S_w2log( 3, "CANoeCtrl_Init: Initialization successful\n" );

    return 1;
}

=head2 CANoeCtrl_isItInitialized

    CANoeCtrl_isItInitialized( );

Checks if the CANoeCtrl module has been already initialized or not.
If already initialzed then returns 1 otherwise 0.
    
=cut

sub CANoeCtrl_isItInitialized {
    my $flagIsCN_initialized = 0;

    if ( $CN_control->{'flag'}{'CANoeCtrlUsed'} ) {
        $flagIsCN_initialized = 1;
    }

    return $flagIsCN_initialized;
}

=head2 CANoeCtrl_Loadconfig

 Function Name   :: CANoeCtrl_Loadconfig

 Description     :: Loads a configuration. 
                    If measurement is already running, it is stopped before loading the configuration. 
                    The current configuration is not saved before loading the new configuration.

 Syntax          :: $status = CANoeCtrl_Loadconfig(ConfigFile, Timeout_ms);

 Input Arguments :: Optional: $loadconfig_timeout (default value is -1 (infinite))

 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)

 Example         :: status = CANoeCtrl_Loadconfig(100);

=cut

sub CANoeCtrl_Loadconfig {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_Loadconfig ($configfile [, $loadconfig_timeout] )', @args );

    my $configfile         = shift @args;
    my $loadconfig_timeout = shift @args;

    S_w2log( 4, "CANoeCtrl_Loadconfig \n" );

    my $status = 0;

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_Loadconfig : CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    unless ( defined $loadconfig_timeout ) {
        S_w2log( 4, "CANoeCtrl_Loadconfig : Timeout to load cfg is not given, considering Default timeout (-1 :: infinite timeout)  \n" );
        $loadconfig_timeout = -1;
    }

    if ( ( defined $loadconfig_timeout ) && ( $loadconfig_timeout !~ /^-?\d+$/ ) ) {
        S_set_error( "CANoeCtrl_Loadconfig :  Timeout is not a numeric value \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    $status = canoectrl_cnLoadConfiguration( $configfile, $loadconfig_timeout );
    Check_status( $status, "Loading configuration file failed " );
    S_w2log( 4, "CANoeCtrl_Loadconfig status :: $status \n" );

    return $status;
}

=head2 CANoeCtrl_ResetOutputSignal

 Function Name   :: CANoeCtrl_ResetOutputSignal

 Description     :: Resets the output signal of CANoe

 Syntax          :: status = CANoeCtrl_ResetOutputSignal();

 Input Arguments :: None

 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)

 Example         :: status = CANoeCtrl_ResetOutputSignal();

=cut

sub CANoeCtrl_ResetOutputSignal {
    my $status = 0;
    S_w2log( 4, "CANoeCtrl_ResetOutputSignal \n" );

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_ResetOutputSignal: CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    $status = canoectrl_ResetOutputSignal();
    Check_status( $status, "Reset of output signal failed \n" );
    S_w2log( 4, "Status of canoectrl_ResetOutputSignal :: $status \n" );

    return $status;
}

=head2 CANoeCtrl_loadSignalCurve

    $success = CANoeCtrl_loadSignalCurve( $inArgs_href );

Loads a single bus signal curve to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes

B<Arguments:>

=over

=item input $inArgs_href

    $inArgs_href = {
         signal_name => <signal name >,
         signal_data => <bus signal data>,
         sysVar_name => <system variable name which holds the data>,
         sysVar_max_dataPts => <maximum datapoints for the system variable>,
         sysVar_SVNumSignals => <maximum number of output signals that has to be injected>,
         sampleTime_ms => <sample time in ms>,
         trigger_type => <trigger type : 'Triggersoft' or 'Triggerhard'>,
    }
    
all are mandatory parameters
   
=back

B<Return Values:>

=over

=item $success

$success is B<1> on success and B<undef> on failure

=back

B<Examples:>
    
    $inArgs_href = {
        'signal_name'        => 'SigStimulus2_CAN',
        'signal_data'        => [1..10],
        'sysVar_name'        => 'Stimulus::SVSignalValues1',
        'sysVar_max_dataPts' => $max_dataPts_SysVarFile, # ex 20000
        'sampleTime_ms'      => 10,
        'trigger_type'       => 'TriggerSoft',    
     },
     $success = CANoeCtrl_loadSignalCurve ($inArgs_href);

=back
  
B<Note:> This should be called internally by other functions example CANoeCtrl_load_signal_curves, but not directly.    
    
=cut

sub CANoeCtrl_loadSignalCurve {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_loadSignalCurve ($inArgs_href)', @args );
    my $inArgs_href = shift @args;

    my $signal_curve_name     = $inArgs_href->{'signal_name'};
    my $signal_dataPts_aref   = $inArgs_href->{'signal_data'};           # other attributes can be dervied from this.
    my $sysVarName            = $inArgs_href->{'sysVar_name'};
    my $max_dataPts_SysVar    = $inArgs_href->{'sysVar_max_dataPts'};
    my $max_nbr_outputSignals = $inArgs_href->{'sysVar_SVNumSignals'};
    my $sampleTimeMds_ms      = $inArgs_href->{'sampleTime_ms'};
    my $trigger_type          = $inArgs_href->{'trigger_type'};

    S_w2log( 4, "CANoeCtrl_loadSignalCurve -> '$signal_curve_name' ..   \n" );

    # STEP Get the cycle time in ms from Project Constant
    my $cycleTime_prjCons_ms = CANoeCtrl_rdPrjConst_normalCycleTime($signal_curve_name) || return;

    # STEP Get the sample time in ms from MDS
    unless ( $sampleTimeMds_ms =~ /^\d+\.?\d*$/ ) {
        S_set_error( "CANoeCtrl_loadSignalCurve Cycle time (from MDS) value should be numeric. \n", 114 );
        return;
    }

    my $busSignals_aref;

    # IF Sample_time_mds (in ms) is > 0
    # IF-YES-START
    if ( $sampleTimeMds_ms > 0 ) {

        # STEP Error if there is a sample time but no signal datapoints defined
        unless ( scalar(@$signal_dataPts_aref) > 0 ) {
            S_set_error( "CANoeCtrl_loadSignalCurve Curve '$signal_curve_name' has no data but nonZE sample time  = $sampleTimeMds_ms.\n", 114 );
            return;
        }

        # CALL CANoeCtrl_handleOutputSignalForResampling
        $busSignals_aref = CANoeCtrl_handleOutputSignalForResampling( $signal_curve_name, $signal_dataPts_aref, $sampleTimeMds_ms, $cycleTime_prjCons_ms );
        my $dataPtsCount = scalar @$busSignals_aref;

        # CALL CANoeCtrl_validSignalDataPoints
        return if not CANoeCtrl_validSignalDataPoints(
            {
                'busSignalName'       => $signal_curve_name,
                'dataPts_busSignal'   => $dataPtsCount,
                'sysVarName'          => $sysVarName,
                'dataPts_SysVar'      => $max_dataPts_SysVar,
                'sysVar_SVNumSignals' => $max_nbr_outputSignals,
            }
        );

        # CALL CANoeCtrl_SetOutputSignal - load signal data points into system variable.
        CANoeCtrl_SetOutputSignal( $signal_curve_name, $busSignals_aref, $trigger_type );
    }

    # IF-YES-END

    # IF-NO-START
    else {
        # CALL CANoeCtrl_handleOutputSignalForZeroEmulation
        my ( $default_val, $busSignals_aref ) = CANoeCtrl_handleOutputSignalForZeroEmulation( $signal_dataPts_aref, $signal_curve_name );

        # STEP if defaut value is not defined in the project contant then keep the default value as like CANoe
        if ( $default_val == -12345.0 ) {
            ## do not set any value, keep the default value of RBS
            S_w2log( 4, " ZERO EMULATION -> for signal '$signal_curve_name' Default value of the RBS has been kept. No value has been set explicitly. \n" );
        }
        else {
            # CALL CANoeCtrl_SetOutputSignal if default value of CANoe has to set from PrjConst.
            CANoeCtrl_SetOutputSignal( $signal_curve_name, $busSignals_aref, $trigger_type );
        }

    }

    # IF-NO-END

    # STEP end ..
    S_w2log( 4, "CANoeCtrl_loadSignalCurve end..  \n" );

    return 1;
}

=head2 CANoeCtrl_load_signal_curves

    CANoeCtrl_load_signal_curves($busSignal_curves_href, $Triggertype);

Loads the bus signal curves to be injected to CANoe RBS and holds in buffer (system variables) until trigger comes, 
software or hardware trigger. 

B<Prerequiste> :

- prepare CANoeCtrl mapping.

- prepare the CAPL files (assign it to system variable and the signal name from CAN / FlexRay database).

- template is availble here :
g:/MKS/Projects/TurboLIFT/System/develop/develop.pj  

/develop/CANoeCtrl/CANoeCtrl_Control/template/nodes/CREIS/CREIS.can

B<Remark> :

- This function shall be called before CANoe measurement starts (start of RBS)
  (in case measurement is running then it will stopped and signal shall be configured)
  
- The signal is identified by an index, the mapping to the corresponding signal must be done in the CAPL program of the network node.
  Signal indices must be continuous, starting at 0. 
       
B<Arguments:>

=over

=item $busSignal_curves_href
 
hash reference containing the signal name, sample time and signal values.

=item $Triggertype

'Triggersoft' or 'Triggerhard'

=back

B<Return Value:>

B<1>  : Successful & Offline - B<undef> : Failure

B<Examples:>
  
    $busSignal_curves_href = {
        'SigStimulus1_CAN' => {
            'SAMPLETIME_US'=> 10000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
        'SigStimulus2_CAN' => {
            'SAMPLETIME_US'=> 20000.000, 
            'SIGNALS'=>[0.1, 0.2, 0.5, 0.9, 1.47, 2.55, 0.5, 0.1, 0.45, 1.25, 10.25, 0.5, 0.4, 0.3, 0.2, 0.1]},
         ...
    };

    CANoeCtrl_load_signal_curves( $busSignal_curves_href, 'Triggersoft');
    CANoeCtrl_load_signal_curves( $busSignal_curves_href, 'Triggerhard');

=cut

sub CANoeCtrl_load_signal_curves {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_load_signal_curves ($busSignal_curves_href, $triggertype)', @args );

    my $busSignal_curves_href = shift @args;
    my $triggertype           = shift @args;    # Triggersoft or Triggerhard

    S_w2log( 4, "CANoeCtrl_load_signal_curves ->  \n" );

    ## Configure all signals
    foreach my $signal_curve_name ( keys %{$busSignal_curves_href} ) {

        my $sampleTime_US = $busSignal_curves_href->{$signal_curve_name}{'SAMPLETIME_US'};
        my $dataPtsCount  = scalar( @{ $busSignal_curves_href->{$signal_curve_name}{'SIGNALS'} } );

        S_w2log( 4, " $signal_curve_name => SAMPLING RATE = $sampleTime_US us, DataPoints count = $dataPtsCount \n" );

        if ( defined $signal_curve_name ) {

            my $signal_indx         = CANoeCtrl_rdPrjConst_signalIndex($signal_curve_name);
            my $sysVar_outputSignal = "Stimulus::SVSignalValues" . "$signal_indx";

            next if $main::opt_offline;

            my $max_dataPts_SysVarFile_aref = CANoe_get_sysVar_value($sysVar_outputSignal);
            my $max_dataPts_SysVarFile;
            
            if ($main::opt_simulation) {
                $max_dataPts_SysVarFile = 20000;
            }
            else {
                $max_dataPts_SysVarFile = scalar(@$max_dataPts_SysVarFile_aref);
            }

            my $max_nbr_outputSignals_aref = CANoe_get_sysVar_value("Stimulus::SVNumSignals");
            my $max_nbr_outputSignals;
            if ($main::opt_simulation) {
                $max_nbr_outputSignals = 200;
            }
            else {
                $max_nbr_outputSignals = scalar(@$max_nbr_outputSignals_aref);
            }

            # CALL LIFT_CANoeCtrl::CANoeCtrl_loadSignalCurve
            CANoeCtrl_loadSignalCurve(
                {
                    'signal_name'        => $signal_curve_name,
                    'signal_data'        => $busSignal_curves_href->{$signal_curve_name}{'SIGNALS'},
                    'sysVar_name'        => $sysVar_outputSignal,
                    'sysVar_max_dataPts' => $max_dataPts_SysVarFile,
                    'sysVar_SVNumSignals' => $max_nbr_outputSignals,
                    'sampleTime_ms'      => $busSignal_curves_href->{$signal_curve_name}{'SAMPLETIME_US'} / 1000,
                    'trigger_type'       => $triggertype,
                }
            );
        }
    }

    unless ( CANoeCtrl_SetSystemVariablesValues() ) {
        S_set_error( " CANoeCtrl_load_signal_curves : failed to set System variables.\n", 131 );
        return;
    }

    S_w2log( 4, "CANoeCtrl_load_signal_curves -> done \n" );

    return 1;
}

=head2 CANoeCtrl_SetOutputSignal

    $status = CANoeCtrl_SetOutputSignal($signalname, $busSignals_aref, $triggertype);

Defines new values of a signal that shall be sent when the system is triggered. 

B<Notes:> 

- This definition of the new values must be done before measurement start, otherwise it has no effect and 0 is returned.
 
- The signal is identified by an index, the corresponding signal name must be mapped
to the system variable Stimulus::SVSignal<signalIndex> in the CAPL program of the network node.
 
- Signal indices must be continuous, starting at 0.

- Note that this function does not trigger the sending of the signal 
(it must be sent cyclically by a Nodelayer DLL), but just modifies the signal data.

B<Arguments:>

=over

=item $signalname 

signal name, should be same as defined in the CANoeCtrl mapping. Refer L</"Project configuration">

=item $busSignals_aref 

data points of the signal to be set or configured.

=item $triggertype 

Triggersoft or Triggerhard

=back

B<Return Value:>

=over

=item $status 

> 0 = success, offline = 0,  else undef.

=back

B<Examples:>

    $status = CANoeCtrl_SetOutputSignal( 'SigStimulus2_CAN', [1, 2, 3, 4, 5], 'Triggersoft' );

=cut

sub CANoeCtrl_SetOutputSignal {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_SetOutputSignal ($signalname, $busSignals_aref, $triggertype)', @args );

    my $signalname      = shift @args;
    my $busSignals_aref = shift @args;
    my $triggertype     = shift @args;

    my $status = 0;
    my $error_msg;
    my $suggestion_msg;

    S_w2log( 4, "CANoeCtrl_SetOutputSignal [signalname = $signalname, NbrPoints = " . scalar(@$busSignals_aref) . ", triggerType = $triggertype] \n", 'purple' );

    #
    # check the arguments
    #
    # STEP check the trigger type
    unless ( ( $triggertype =~ /^Triggersoft$/i ) || ( $triggertype =~ /^Triggerhard$/i ) ) {
        S_set_error( "CANoeCtrl_SetOutputSignal : Trigger type should be either Triggersoft or Triggerhard  \n", 114 );
        return;
    }

    if ( $triggertype =~ /Triggersoft/i ) {
        $triggertype = 0;
    }
    else {
        $triggertype = 1;
    }

    # STEP get the signal index from project constant
    my $signal_indx = CANoeCtrl_rdPrjConst_signalIndex($signalname);
    return unless ( defined $signal_indx );

    # STEP check if CANoeCtrl is initialzed , if not then error
    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_SetOutputSignal: CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    # STEP load or buffer the datapoints into the system variable until trigger comes
    $status = canoectrl_setOutputSignal( $signal_indx, $busSignals_aref, $triggertype );
    Check_status( $status, "CANoeCtrl_SetOutputSignal: setOutputSignal Failed." );

    S_w2log( 4, "CANoeCtrl_SetOutputSignal end status = $status \n\n" );

    return $status;
}

=head2 CANoeCtrl_handleOutputSignalForResampling

    $resampled_busSignals_aref = CANoeCtrl_handleOutputSignalForResampling( $signalname, $busSignals_aref, $cycle_time_MDS_ms, $cycleTime_prjCons_ms );

Performs resampling of a signal based on input cycle time (given by the MDS) and the cycle time from CANoe. 
Refer L</"Project configuration">

B<Arguments:>

=over

=item $signalname 

Signal name for which resampling has to done.

=item $busSignal_MDS_aref 

Signal curve (normally comes from MDS) that has to be checked or done resampling.

=item $busCycleTime_MDS_ms 

cycle time from MDS of the signal.

=item $busCycleTimeNormal 

Cycle time from CANoe , normal cycle time specified in the project constant.

=back

B<Return Value:>

=over

=item $busSignal_MDS_aref 

resampled curve.

=back

B<Examples:>

    $busSignal_curves_href = {
        'SigStimulus1_CAN' => {'SAMPLETIME_US'=> 10000.000, 'SIGNALS'=>[1, 2, 3, 4, 5, 6]},
    };    

    $resampled_busSignals_aref = CANoeCtrl_handleOutputSignalForResampling( $signalname, $busSignal_curves_href->{'SigStimulus1_CAN'}{'SIGNALS'}, 10, 20 );;
    $resampled_busSignals_aref is [1, 3, 5].    

    $resampled_busSignals_aref = CANoeCtrl_handleOutputSignalForResampling( $signalname, $busSignal_curves_href->{'SigStimulus1_CAN'}{'SIGNALS'}, 10, 5 );;
    $resampled_busSignals_aref is [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6].    

B<Notes:> 

Downsample functionality was implemented but not used in project yet. Has to be tested.

=cut

sub CANoeCtrl_handleOutputSignalForResampling {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_handleOutputSignalForResampling ($signalname, $busSignal_MDS_aref, $busCycleTime_MDS_ms, $busCycleTimeNormal)', @args );

    my $signalname            = shift @args;
    my $busSignal_MDS_aref    = shift @args;
    my $busCycleTime_MDS_ms   = shift @args;
    my $busCycleTimeNormal_ms = shift @args;    # Project constant [CANoeCtrl-> OutputSignals-> <signalName> -> CycleTime]

    my ( $busCycleTimeFast_ms, $inactiveValue, $numRepetitionsOnChange );
    my $status;

    S_w2log( 4, " CANoeCtrl_handleOutputSignalForResampling :  \n" );

    # STEP read project constants [ $busCycleTimeFast_ms, $inactiveValue , $numRepetitionsOnChange]
    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signalname ] );

    $busCycleTimeFast_ms    = CANoeCtrl_rdPrjConst_CycleTimeFast($signalname);
    $inactiveValue          = CANoeCtrl_rdPrjConst_inactiveValue($signalname);
    $numRepetitionsOnChange = CANoeCtrl_rdPrjConst_NumRepetitionsOnChange($signalname);

    # IF If parameter fast bus cycle time is configured
    # IF-YES-START
    if ( defined $busCycleTimeFast_ms ) {

        if ( abs( $busCycleTime_MDS_ms - $busCycleTimeFast_ms ) > 0.0001 ) {

            S_w2log( 4, " 1) resample to fast cycle time \$busCycleTimeFast_ms = $busCycleTimeFast_ms ms  \n" );
            S_w2log( 4, " before resample to fast cycle time \$busCycleTimeFast_ms = $busCycleTimeFast_ms ms nbr of points are = " . scalar @$busSignal_MDS_aref . "\n" );

            # STEP resample to fast cycle time $busCycleTimeFast_ms with respect to $busCycleTime_MDS_ms
            my $retVals_href = NUM_ResampleData(
                {
                    'dataIn_aref'      => $busSignal_MDS_aref,
                    'dtIn_sec'         => $busCycleTime_MDS_ms / 1000,
                    'dtOut_sec'        => $busCycleTimeFast_ms / 1000,
                    'dtResolution_sec' => 1E-6,
                }
            );

            $busSignal_MDS_aref  = $retVals_href->{'dataOutValues_aref'};
            $busCycleTime_MDS_ms = $busCycleTimeFast_ms;
            S_w2log( 4, " after resample to fast cycle time \$busCycleTimeFast_ms = $busCycleTimeFast_ms ms nbr of points are = " . scalar @$busSignal_MDS_aref . "\n" );
        }

        # STEP if Option: Resample signal regions containing const. or inactive values to normal cycle time
        if ( defined $busCycleTimeNormal_ms ) {

            S_w2log( 4, " 2) Resample signal regions containing const. or inactive values to normal cycle time = $busCycleTimeNormal_ms ms  \n" );

            # STEP Resample signal regions containing const. or inactive values to normal cycle time
            my $retVals_href = NUM_downsampleInactiveRegions(
                {
                    'dtSlow_s'               => $busCycleTimeNormal_ms / 1000,
                    'dtSlowResolution_s'     => 1E-6,
                    'dtFast_s'               => $busCycleTime_MDS_ms / 1000,
                    'inactiveValue'          => $inactiveValue,
                    'numRepetitionsOnChange' => $numRepetitionsOnChange,
                    'dataInValues_aref'      => $busSignal_MDS_aref
                }
            );

            if ( $retVals_href != 0 ) {
                $busSignal_MDS_aref = $retVals_href->{'dataOutValues_aref'};

                # $bussignals_href->{'SAMPLETIME_US'} cannot be assigned here anymore as a single value,
                # because output curve is now non-equidistant (signal contains two time bases, automatically rebuilt by RBS through time-scheduler)
            }
        }
    }

    # IF-YES-END

    # IF-NO-START
    elsif ( defined $busCycleTimeNormal_ms ) {

        # STEP Resample to normal cycle time '$busCycleTimeNormal_ms ms' with respect to '$busCycleTime_MDS_ms'
        if ( abs( $busCycleTime_MDS_ms - $busCycleTimeNormal_ms ) > 0.0001 ) {

            S_w2log( 4, " resample to normal cycle time '\$busCycleTimeNormal_ms = $busCycleTimeNormal_ms ms', cycle time MDS = $busCycleTime_MDS_ms ms. \n" );
            S_w2log( 4, " => before resample to normal cycle time \$busCycleTimeNormal_ms = $busCycleTimeNormal_ms ms nbr of points are = " . scalar @$busSignal_MDS_aref . "\n" );

            # Required, if resampling leads to only one point
            my $pointToHold  = $$busSignal_MDS_aref[-1];    # option 1  => set to last value   TODO> How to make this configurable
                                                            # my $pointToHold = $$busSignal_MDS_aref[0];   # option 2  => set to first value  TODO> How to make this configurable
            my $retVals_href = NUM_ResampleData(
                {
                    'dataIn_aref'      => $busSignal_MDS_aref,
                    'dtIn_sec'         => $busCycleTime_MDS_ms / 1000,
                    'dtOut_sec'        => $busCycleTimeNormal_ms / 1000,
                    'dtResolution_sec' => 1E-6,
                }
            );

            $busSignal_MDS_aref  = $retVals_href->{'dataOutValues_aref'};
            $busCycleTime_MDS_ms = $busCycleTimeNormal_ms;
            S_w2log( 4, " => after resample to normal cycle time \$busCycleTimeNormal_ms = $busCycleTimeNormal_ms ms nbr of points are = " . scalar @$busSignal_MDS_aref . "\n" );
            #
            # Catch boundary situation if resample would lead to less than 2 points
            #
            if ( scalar @$busSignal_MDS_aref == 1 ) {
                S_w2log( 4, " => only one point after resmapling, value = @$busSignal_MDS_aref \n" );
                splice @$busSignal_MDS_aref, 1;    # reduce array to only one point
                $$busSignal_MDS_aref[0] = $pointToHold;
            }

            if ( scalar @$busSignal_MDS_aref == 0 ) {
                S_set_error( "Resampling not possible.", 114 );
            }

        }
        else {
            S_w2log( 4, " Resampling not done as 'cycle time MDS = $busCycleTime_MDS_ms ms' equal to 'normal cycle time = $busCycleTimeNormal_ms ms'. \n" );
        }
    }

    # IF-NO-END
    # STEP return the resampled signal $busSignal_MDS_aref

    return $busSignal_MDS_aref;
}

=head2 CANoeCtrl_handleOutputSignalForZeroEmulation

    ($default_val, $busSignals_aref ) = CANoeCtrl_handleOutputSignalForZeroEmulation( $busSignals_aref, $signalname );

This function is to handle the zero emulation. 

 i.e. for ZE - values to CANoe : 
    -> default value of the RBS if no project contant value has been defined ( [CANoeCtrl-> OutputSignals-> <signalName> -> DefaultValue] )  
    -> value as defined in the project constant ( [CANoeCtrl-> OutputSignals-> <signalName> -> DefaultValue] )

B<Arguments:>

=over

=item $busSignals_aref 

signal curve for which ZE has to be taken care. Comes from MDS

=item $signalname 

signal name as defined in the mappings CANoeCtrl & sensor mapping.

=back

B<Return Value:>

=over

=item $default_value_ZE 

default ZE value  (single ZE value) used later to decide for $data_aref that has to be send to CANoe .

=item $data_aref 

signal curve for ZE to set in RBS. 
if no project contant value has been defined( [CANoeCtrl-> OutputSignals-> <signalName> -> DefaultValue] ), then no $data_aref has been set to CANoe.
Hence kept the default value of the RBS itself. 

=back

B<Examples:>

    $busSignal_curves_href = {
        'SigStimulus1_CAN' => {'SAMPLETIME_US'=> 0.0, 'SIGNALS'=>[1, 2, 3, 4, 5, 6]},
    };    
     
    (-12345.0, undef) = CANoeCtrl_handleOutputSignalForResampling( $busSignal_curves_href->{'SigStimulus1_CAN'}{'SIGNALS'}, 'SigStimulus1_CAN');
    when NO project contant value has been defined( [CANoeCtrl-> OutputSignals-> <signalName> -> DefaultValue] ) is undef

    (2, [2, 2, 2, 2, 2,2]] = CANoeCtrl_handleOutputSignalForResampling( $busSignal_curves_href->{'SigStimulus1_CAN'}{'SIGNALS'}, 'SigStimulus1_CAN');
    when project contant value has been defined( [CANoeCtrl-> OutputSignals-> <signalName> -> DefaultValue] = 2 )

=cut

sub CANoeCtrl_handleOutputSignalForZeroEmulation {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_handleOutputSignalForZeroEmulation ($data_aref, $signal_curve_name )', @args );

    my $data_aref         = shift @args;
    my $signal_curve_name = shift @args;

    my $default_value_ZE;

    S_w2log( 4, " CANoeCtrl_handleOutputSignalForZeroEmulation :  \n" );

    # STEP read default value from prjConst 'CANoeCtrl'->'OutputSignals'-> $signal_curve_name ->'DefaultValue'
    # IF DefaultValue defined ?
    $default_value_ZE = CANoeCtrl_rdPrjConst_defaultValue($signal_curve_name);
    if ( not defined $default_value_ZE ) {

        # IF-NO-START
        # STEP do not overwrite the signals , keep the default value of CANoe
        S_w2log( 4, " no zero emulation value ('CANoeCtrl'->'OutputSignals'-> $signal_curve_name ->'DefaultValue') was defined in project constant. Will be considered default value of RBS itself \n" );
        $default_value_ZE = -12345.0;
        return ( $default_value_ZE, undef );

        # IF-NO-END
    }
    else {
        # IF-YES-START
        # STEP replace default zero value with the correct default value
        S_w2log( 4, " ZE : value = '$default_value_ZE' will be set from project constant ('CANoeCtrl' ->'OutputSignals'-> $signal_curve_name -> 'DefaultValue').  \n" );
        my $nbrDataPoints = scalar @{$data_aref};
        if ( $nbrDataPoints > 0 ) {
            my $max_dataPts_CANoeCtrlDll = CANoeCtrl_getSignalLimits()->{'MAX_DATA_POINTS_SIGNAL'};
            if ( $nbrDataPoints > $max_dataPts_CANoeCtrlDll ) {
                S_w2log( 4, " ZE : datapoints of signal '$signal_curve_name' = $nbrDataPoints, so it is reduced to = $max_dataPts_CANoeCtrlDll '-> max supported data points'. \n" );
                splice( @{$data_aref}, $max_dataPts_CANoeCtrlDll );
            }
            map { $_ = $default_value_ZE } @{$data_aref};
            S_w2log( 4, " ZE : each datapoints of signal curve '$signal_curve_name' are replaced by value = $default_value_ZE. \n" );
        }
        else {

            #put the single defualt value
            push( @{$data_aref}, $default_value_ZE );
            S_w2log( 4, " ZE : bus signal curve '$signal_curve_name' contains single value = $default_value_ZE. \n" );
        }

        # IF-YES-END
        return ( $default_value_ZE, $data_aref );
    }

    # STEP return the $default_value_ZE, $data_aref.

    return 1;
}

=head2 CANoeCtrl_SetSoftwareTrigger

 Function Name   :: CANoeCtrl_SetSoftwareTrigger

 Description     :: Starts the output of the configured output signals (software trigger for signal output). 
                    This function can only be called when measurement is running, 
                    otherwise it has no effect and 0 is returned.

 Syntax          :: status = CANoeCtrl_SetSoftwareTrigger();

 Input Arguments :: None

 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)

 Example         :: status = CANoeCtrl_SetSoftwareTrigger();

=cut

sub CANoeCtrl_SetSoftwareTrigger {
    S_w2log( 4, "CANoeCtrl_SetSoftwareTrigger \n" );
    my $status = 0;

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_SetSoftwareTrigger :  CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    #1 if the software trigger could be triggered, otherwise 0.
    $status = canoectrl_setSoftwareTrigger();
    Check_status( $status, "Failed to set software trigger" );
    S_w2log( 4, "Status of canoectrl_setSoftwareTrigger :: $status \n" );

    return $status;
}

=head2 CANoeCtrl_SetTimedSignal

 Function Name   :: CANoeCtrl_SetTimedSignal
 
 Description     :: Defines new values of a signal that shall be sent when the system is triggered. 
                    The signal value will be set to value1 when the trigger occurs, 
                    and optional (if timeshift > 0) to value2 after further <timeshift> milliseconds. 
                    The parameter triggerType defines the type of the trigger that starts the output of value1.
                    This function call must be done before measurement start.                    
                    Note : The signal is identified by an index, the mapping to the 
                    corresponding signal must be done in the CAPL program of the network node.
                    Signal indices must be continuous, starting at 0.
 
 Syntax          :: status = CANoeCtrl_SetTimedSignal(Signalname, Value1, TriggerType, Timeshift_ms, Value2)

 Input Arguments :: Mandatory: Signalname, Value1, TriggerType
                    Optional: Value2, Timeshift_ms
 
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: $status = CANoeCtrl_SetTimedSignal('Diag_RGS_re_Resp_Data', 100.0, 'Triggersoft', 200, 50.0);
                    $status = CANoeCtrl_SetTimedSignal('Diag_RGS_re_Resp_Data', 100.0, 'Triggersoft', 0, 0.0);

=cut

sub CANoeCtrl_SetTimedSignal {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_SetTimedSignal ($signalname, $value1, $triggertype , [$timeshift_ms, $value2])', @args );

    my $signalname   = shift @args;
    my $value1       = shift @args;
    my $triggertype  = shift @args;
    my $timeshift_ms = shift @args;
    my $value2       = shift @args;

    my $signalIndex;
    my $status = 0;

    S_w2log( 4, "CANoeCtrl_SetTimedSignal $signalname) \n" );

    $signalIndex = $main::ProjectDefaults->{'CANoeCtrl'}{'TimedSignals'}{$signalname}{'Index'};
    unless ( defined $signalIndex ) {
        S_set_error( " CANoeCtrl_SetTimedSignal : 'Index' Nbr not found for signal '$signalname' in project const => 'CANoeCtrl - TimedSignals - $signalname - Index' \n", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( $signalIndex =~ /^\d+$/ ) {
        S_set_error( "CANoeCtrl_SetTimedSignal : 'Index' is not numberic for signal '$signalname' in project const => 'CANoeCtrl - TimedSignals - $signalname - Index'.", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( $value1 =~ /^\d+\.?\d*$/ ) {
        S_set_error( "CANoeCtrl_SetTimedSignal : 'value1 = $value1' is not numeric for signal $signalname. ", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( ( $triggertype =~ /^Triggersoft$/i ) || ( $triggertype =~ /^Triggerhard$/i ) ) {
        S_set_error( "CANoeCtrl_SetTimedSignal : Trigger type should be either Triggersoft or Triggerhard  \n", 114 );
        return CANOECTRL_FAILED;
    }

    if ( defined($timeshift_ms) && ( $timeshift_ms !~ /^\d+$/ ) ) {
        S_set_error( "CANoeCtrl_SetTimedSignal : 'timeshift_ms = $timeshift_ms' is not numeric or have negative value for signal $signalname.", 114 );
        return CANOECTRL_FAILED;
    }

    if ( ( defined $value2 ) && ( $value2 !~ /^\d+\.?\d*$/ ) ) {
        S_set_error( "CANoeCtrl_SetTimedSignal : 'value2 = $value2' is not numeric for signal $signalname. ", 114 );
        return CANOECTRL_FAILED;
    }

    if ($measure) {
        S_set_error( "CANoeCtrl_SetTimedSignal : Measurement is running, cannot set the timed signals \n", 120 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_SetTimedSignal :  CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    #In Dll level  triggersoft represented as 0 and trigger hard represented as 1
    if ( $triggertype =~ /Triggersoft/i ) {
        $triggertype = 0;
    }
    else {
        $triggertype = 1;
    }

    # 1 if the signal could be configured successfully, otherwise 0.
    $status = canoectrl_setTimedSignal( $signalIndex, $value1, $triggertype, $value2, $timeshift_ms );
    Check_status( $status, "setTimedSignal Failed ($signalname)" );
    S_w2log( 4, "Status of canoectrl_setTimedSignal of signal '$signalname' :: $status \n" );

    return $status;
}

=head2 CANoeCtrl_StartMeasurement

 Function Name   :: CANoeCtrl_StartMeasurement
 
 Description     :: Starts reading measurement. If measurement is already running, it is stopped and restarted.
 
 Syntax          :: status = CANoeCtrl_StartMeasurement(Timeout_ms);

 Input Arguments :: Optional: Timeout_ms (default value is -1 (infinite))
                    The maximum time in milliseconds that the client should wait until the measurement is started. 
                    A timeout of -1 is an infinite timeout, i.e., the thread is blocked until 
                    it receives the OnStart event from CANoe via COM. 
                    If measurement is already running and has to be stopped first, 
                    the same timeout is used for stopping the measurement.
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: $status = CANoeCtrl_StartMeasurement(-1);
                    $status = CANoeCtrl_StartMeasurement(); 
                    $status = CANoeCtrl_StartMeasurement(100);

=cut

sub CANoeCtrl_StartMeasurement {
    my $start_meas_timeout_ms = shift;
    my $status                = 0;
    S_w2log( 4, "CANoeCtrl_StartMeasurement \n" );

    unless ( defined $start_meas_timeout_ms ) {
        S_w2log( 4, "Start measure timeout is not given, considering Default timeout (-1)  \n" );
        $start_meas_timeout_ms = -1;
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_StartMeasurement: CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    if ($main::opt_offline) {
        $measure = 1;
        return CANOECTRL_OFFLINE;
    }

    # if the measurement could be started within the given time, otherwise 0.
    $status = canoectrl_cnStartMeasurement($start_meas_timeout_ms);
    Check_status( $status, "CANoeCtrl_StartMeasurement: Failed to start measurement" );
    S_w2log( 4, "Status of canoectrl_cnStartMeasurement :: $status \n" );

    $measure = 1 if ( $status > 0 );
    S_w2log( 4, "Status of canoectrl_cnStartMeasurement flag:: $measure \n" );

    #Setting the signals to bus if Signals has been set before start of measurement
    #if ( ( $measure == 1 ) && ( scalar( keys(%SetSignalNow) ) > 0 ) ) {
    #    foreach my $key ( keys(%SetSignalNow) ) {
    #        CANoeCtrl_SetSignalNow( $key, $SetSignalNow{$key} );
    #    }
    #}

    return $status;

}

=head2 CANoeCtrl_StopMeasurement

 Function Name   :: CANoeCtrl_StopMeasurement
 
 Description     :: Stops reading measurement. If measurement is not running, 
                    the function has no effect, and 1 is returned.
 
 Syntax          :: status = CANoeCtrl_StopMeasurement(Timeout);

 Input Arguments :: Optional: Timeout_ms (default value is -1 (infinite))
                    The maximum time in milliseconds that the client should wait until the measurement is stopped.
                    A timeout of -1 is an infinite timeout, i.e., the thread is blocked until 
                    it receives the OnStop event from CANoe via COM.    
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: $status = CANoeCtrl_StopMeasurement(-1);
                    $status = CANoeCtrl_StopMeasurement();
                    $status = CANoeCtrl_StopMeasurement(100);

=cut

sub CANoeCtrl_StopMeasurement {
    my $stop_meas_timeout_ms = shift;
    my $status               = 0;

    S_w2log( 4, "CANoeCtrl_StopMeasurement \n" );

    unless ( defined $stop_meas_timeout_ms ) {
        S_w2log( 4, "CANoeCtrl_StopMeasurement : Stop measure timeout is not given, considering Default timeout (-1)  \n" );
        $stop_meas_timeout_ms = -1;
    }

    unless ($measure) {
        S_set_error( "CANoeCtrl_StopMeasurement : Measurement not running \n", 114 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_StopMeasurement: CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    if ($main::opt_offline) {
        $measure = 0;
        return CANOECTRL_OFFLINE;
    }

    # 1 if the measurement could be stopped within the given time, otherwise 0.
    $status = canoectrl_cnStopMeasurement($stop_meas_timeout_ms);
    Check_status( $status, "Failed to stop measurement" );

    S_w2log( 4, "Status of canoectrl_cnStopMeasurement :: $status \n" );

    $measure = 0;

    return $status;
}

=head2 CANoeCtrl_SetSystemVariablesValues

 Function Name   :: CANoeCtrl_SetSystemVariablesValues
 
 Description     :: Set the system variable values (output, timed & analysis signals) to CANoe. 
                    This function is required in case Measurement  (RBS) is started via other
                    TurboLIFT module like  LIFT_CAN_access then to send the system variable values.
                    This function has to be called before the start of measurement (RBS). 
 
 Syntax          :: $status = CANoeCtrl_SetSystemVariablesValues();

 Input Arguments :: none
 Return Value(s) :: status (>0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: $status = CANoeCtrl_SetSystemVariablesValues();                   

=cut

sub CANoeCtrl_SetSystemVariablesValues {
    my $status = 0;

    S_w2log( 4, "CANoeCtrl_SetSystemVariablesValues \n" );

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_SetSystemVariablesValues CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    if ($main::opt_offline) {
        $measure = 0;
        return CANOECTRL_OFFLINE;
    }

    $status = canoectrl_setSysVariablesValues();
    Check_status( $status, "Failed to set system variables values" );

    S_w2log( 4, "Status of CANoeCtrl_SetSystemVariablesValues :: $status \n" );

    return $status;
}

=head1 Non-Exported Subroutines

=head2 Check_status

 Function Name   :: Check_status
 
 Description     :: Checks the status of given value and throws an error message
 
 Syntax          :: Check_status(status, error_msg);

 Input Arguments :: status, error_msg
 
 Return Value(s) :: None
 
 Example         :: Check_status(0, "Sample error message");

=cut

sub Check_status {
    my ( $status, $error_msg ) = @_;

    if ( $status <= 0 ) {
        S_set_error( "CANoeCtrl ( $status ) : $error_msg ", 5 );
    }
    return 1;
}

=head2 CANoeCtrl_RegisterCaplFunction

 Function Name   :: CANoeCtrl_RegisterCaplFunction
 
 Description     :: Register a CAPL Function
 Syntax          :: Func_val = CANoeCtrl_RegisterCaplFunction(CAPLFuncName);
 
 Input Arguments :: CAPLFuncName
 
 Return Value(s) :: Func_val - Function pointer value of the Registered capl function
 
 Example         :: Func_val = CANoeCtrl_RegisterCaplFunction("testFunction");

=cut

sub CANoeCtrl_RegisterCaplFunction {
    my $func_name = shift;

    S_w2log( 4, "CANoeCtrl_RegisterCaplFunction ( '$func_name' ) \n" );

    if ($measure) {
        S_set_error( "Measurement is running, cannot register the function $func_name \n", 120 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( " CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    my $func_val = canoectrl_registerCAPL($func_name);

    return $func_val;
}

=head2 Signal_Ndx_Dup

 Function Name   :: Signal_Ndx_Dup
 
 Description     ::Checks for the  uniqueness of signal names in output signals, analysis signals and timed signals individually
                   Checks for the uniqueness of signal index values of output signals, analysis signals and timed signals individually
 
 Syntax          :: (\@dup_nm_tym,\@dup_nm_ana,\@dup_nm_out) = Signal_Ndx_Dup(canoectrl_href);
 
 Input Arguments :: canoectrl_href - Signals hash reference from the project constants
 
 Return Value(s) :: \@dup_nm_tym - Array reference of index number/signal names duplicated timed signal names
                    \@dup_nm_ana - Array reference of index number/signal names duplicated analysis signal names
                    \@dup_nm_out - Array reference of index number/signal names duplicated output signal names
 
 Example         :: (\@dup_nm_tym,\@dup_nm_ana,\@dup_nm_out) = Signal_Ndx_Dup(canoectrl_href);

Refer L</"SYNOPSIS"> ProjectConst for canoectrl_href

=cut

sub Signal_Ndx_Dup {
    my $canoectrl_href = shift;

    my @dup_nm_tym = ();
    my @dup_nm_out = ();
    my @dup        = ();

    my %out_sig_ndx = ();
    my %ana_sig_ndx = ();
    my %tym_sig_ndx = ();
    my %seen        = ();    # Dummy hash which is used for testing of duplication of signal names and index values

    my @out_signal = keys( %{ $canoectrl_href->{'OutputSignals'} } );
    my @any_signal = keys( %{ $canoectrl_href->{'AnalysisSignals'} } );
    my @tym_signal = keys( %{ $canoectrl_href->{'TimedSignals'} } );

    # Checking for the duplication of signal names in project constant hash
    # my @sig_arr = (@inj_signal,@any_signal,@tym_signal);

    # Checking for the duplication of output signal names in project constant hash
    @dup = grep { $seen{$_}++ } @out_signal;
    push( @dup_nm_out, @dup ) if ( scalar(@dup) > 0 );
    @dup  = ();
    %seen = ();

    # Checking for the duplication of timed signal names in project constant hash
    @dup = grep { $seen{$_}++ } @tym_signal;
    push( @dup_nm_tym, @dup ) if ( scalar(@dup) > 0 );
    @dup  = ();
    %seen = ();

    #If no duplication of timed signal names then checks for index value duplication
    unless ( scalar(@dup_nm_tym) > 0 ) {
        @dup  = ();
        %seen = ();

        #Reads the Index value of each timed signal in project constant hash
        foreach my $tym (@tym_signal) {
            unless ( defined $canoectrl_href->{'TimedSignals'}{$tym}{'Index'} ) {
                S_set_error( "Index value of TimedSignals signal $tym is not defined  \n", 120 );
                return CANOECTRL_FAILED;
            }

            #Reading Timed signal name and index value into internal hash 'tym_sig_ndx'
            $tym_sig_ndx{$tym} = $canoectrl_href->{'TimedSignals'}{$tym}{'Index'};
        }

        #Reads all duplicated signal index values of read timed signal values
        @dup = grep { $seen{$_}++ } values(%tym_sig_ndx);

        #Checking of duplication of index value
        if ( scalar(@dup) > 0 ) {
            foreach my $dupvar (@dup) {
                foreach my $nm ( keys(%tym_sig_ndx) ) {

                    #checking of duplicated index number
                    if ( $dupvar == $tym_sig_ndx{$nm} ) {

                        #Reading the duplicated index value signal names
                        push( @dup_nm_tym, $nm );
                    }
                }
            }
        }
    }

    #If no duplication of output signal names then checks for index value duplication
    unless ( scalar(@dup_nm_out) > 0 ) {
        @dup  = ();
        %seen = ();

        #Reads the Index value of each output signal in project constant hash
        foreach my $out (@out_signal) {
            $out_sig_ndx{$out} = CANoeCtrl_rdPrjConst_signalIndex($out);
        }

        #Reads all duplicated signal index values of read timed signal values
        @dup = grep { $seen{$_}++ } values(%out_sig_ndx);

        #Checking of duplication of index value
        if ( scalar(@dup) > 0 ) {
            foreach my $dupvar (@dup) {
                foreach my $nm ( keys(%out_sig_ndx) ) {

                    #checking of duplicated index number
                    if ( $dupvar == $out_sig_ndx{$nm} ) {

                        #Reading the duplicated index value signal name
                        push( @dup_nm_out, $nm );
                    }
                }
            }
        }
    }

    return ( \@dup_nm_tym, \@dup_nm_out );
}

=head2 CANoeCtrl_getSignalLimits

    $signalLimits_href = CANoeCtrl_getSignalLimits( );

Returns the signal limits as per defined in the CANoeCtrl_Control dll. 
Signal limits here means - (1) Maximum data points supported for the signal. (2) Maximum number of signals that can be used by Tester - Output or timed.

B<Return Value:>

=over

=item $signalLimits_href 

Hash reference returning the signal limts , see example.

=back

B<Examples:>
    
 $signalLimits_href = CANoeCtrl_getSignalLimits ();
    
 $signalLimits_href->{'MAX_DATA_POINTS_SIGNAL'} = Maximum dataPoints a signal can have.(defined in the dll)
 $signalLimits_href->{'MAX_NBR_OUTPUT_SIGNAL'}  = Maximum number of supported Output signal (signal stimulation)
 $signalLimits_href->{'MAX_NBR_TIMED_SIGNAL'}   = Maximum number of supported Timed signal (ex velocity) 
                                                 -> but not used in TurbolIFT
 $signalLimits_href->{'MAX_NBR_ANALYSIS_SIGNAL'} = Maximum number of analysis signal (not used by TurbolIFT)

=cut

sub CANoeCtrl_getSignalLimits {

    my $signalLimits_href;
    my @signalLimits;
    
    if ($main::opt_offline) {
        push @signalLimits, ( 1, 5000, 100, 10, 10 );    #dummy values
    }
    else {
        @signalLimits = canoectrl_getSignalLimts();
    }
    $signalLimits_href->{'MAX_DATA_POINTS_SIGNAL'}  = $signalLimits[1];
    $signalLimits_href->{'MAX_NBR_OUTPUT_SIGNAL'}   = $signalLimits[2];
    $signalLimits_href->{'MAX_NBR_TIMED_SIGNAL'}    = $signalLimits[3];
    $signalLimits_href->{'MAX_NBR_ANALYSIS_SIGNAL'} = $signalLimits[4];

    return $signalLimits_href;
}

=head2 CANoeCtrl_incMaxOutputSignals

    CANoeCtrl_incMaxOutputSignals( );

Increment the count of maximum number of output signals defined in the CANoeCtrl dll. 
this is configurable in the test bench file ['Devices', 'CANoe', 'Max_Stimulate_Signals']. Supported Values are 200 and 400

B<Return Value:>

=over

=item none

=back

B<Examples:>
    
    CANoeCtrl_incMaxOutputSignals ();
 
=cut
sub  CANoeCtrl_incMaxOutputSignals {
    
    my $max_stimulate_signals = S_get_contents_of_hash( [ 'Devices', 'CANoe', 'Max_Stimulate_Signals' ], $LIFT_config::LIFT_Testbench, {action_on_mismatch =>'w2log'});
    my @valid_values = (200, 400);
    
    $max_stimulate_signals = 200 if not defined $max_stimulate_signals;
    
    if (not $max_stimulate_signals ~~ @valid_values) {
        S_set_error( "CANoeCtrl_incMaxOutputSignals : input value is wrong = '$max_stimulate_signals' in test bench [ 'Devices', 'CANoe', 'Max_Stimulate_Signals' ]. It should be either one of these values '@valid_values'.\n", 114 );    
    }
    
    return 1 if ($main::opt_offline);
    
    canoectrl_incMaxOutputSignals($max_stimulate_signals);
    return 1;
}


=head2 CANoeCtrl_rdPrjConst_signalIndex

    $cycleTime_prjCons_ms = CANoeCtrl_rdPrjConst_signalIndex ( $signal_curve_name  );

Read the L</"Project configuration"> for 'Index' for output signal '$signal_curve_name'.

Returns $signal_indx if defined otherwise undef with error.

=cut

sub CANoeCtrl_rdPrjConst_signalIndex {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_signalIndex ($signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );

    unless ( defined $outSignalprjCons_href->{'Index'} ) {
        S_set_error( "CANoeCtrl_rdPrjConst_signalIndex : signal index for signal '$signal_curve_name' is not available in project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'Index']. \n", 114 );
        return;
    }

    my $signal_indx = $outSignalprjCons_href->{'Index'};
    unless ( $signal_indx =~ /\d+/ ) {
        S_set_error( "CANoeCtrl_rdPrjConst_signalIndex: Signal index for '$signal_curve_name' value should be numeric \n", 114 );
        return;
    }
    S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'Index']  =  $signal_indx \n" );

    return $signal_indx;
}

=head2 CANoeCtrl_rdPrjConst_defaultValue

    $cycleTime_prjCons_ms = CANoeCtrl_rdPrjConst_defaultValue ( $signal_curve_name  );

Read the L</"Project configuration"> for 'DefaultValue' for output signal '$signal_curve_name'.

Returns $default_value_ZE if defined otherwise undef.

=cut

sub CANoeCtrl_rdPrjConst_defaultValue {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_defaultValue ($signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );

    my $default_value_ZE = undef;
    ## fast cycle time
    if ( defined $outSignalprjCons_href->{'DefaultValue'} ) {
        $default_value_ZE = $outSignalprjCons_href->{'DefaultValue'};
        S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'DefaultValue']  =  $default_value_ZE \n" );
    }
    return $default_value_ZE;
}

=head2 CANoeCtrl_rdPrjConst_normalCycleTime

    $cycleTime_prjCons_ms = CANoeCtrl_rdPrjConst_normalCycleTime ( $signal_curve_name  );

Read the L</"Project configuration"> for 'CycleTime' for output signal '$signal_curve_name'.

Returns $cycleTime_prjCons_ms if defined otherwise undef.

=cut

sub CANoeCtrl_rdPrjConst_normalCycleTime {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_normalCycleTime ( $signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );

    ## cycle time normal
    unless ( defined $outSignalprjCons_href->{'CycleTime'} ) {
        S_set_error( "CANoeCtrl_rdPrjConst_normalCycleTime: Cycle time of signal $signal_curve_name is not given in Project contstant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'CycleTime']. \n", 114 );
        return;
    }

    my $cycleTime_prjCons_ms = $outSignalprjCons_href->{'CycleTime'};
    S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'CycleTime']  =  $cycleTime_prjCons_ms ms \n" );

    unless ( $cycleTime_prjCons_ms =~ /^\d+\.?\d*$/ ) {
        S_set_error( "CANoeCtrl_rdPrjConst_normalCycleTime: Cycle time value ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'CycleTime'] = '$cycleTime_prjCons_ms' should be numeric.", 114 );
        return;
    }

    return $cycleTime_prjCons_ms;
}

=head2 CANoeCtrl_rdPrjConst_CycleTimeFast

    $busCycleTimeFast_ms = CANoeCtrl_rdPrjConst_CycleTimeFast ( $signal_curve_name  );

Read the L</"Project configuration"> for 'CycleTimeFast' for output signal '$signal_curve_name'.

Returns $busCycleTimeFast_ms if defined otherwise undef.

=cut

sub CANoeCtrl_rdPrjConst_CycleTimeFast {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_CycleTimeFast ($signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );

    my $busCycleTimeFast_ms = undef;

    ## fast cycle time
    if ( defined $outSignalprjCons_href->{'CycleTimeFast'} ) {
        $busCycleTimeFast_ms = $outSignalprjCons_href->{'CycleTimeFast'};
        S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'CycleTimeFast']  =  $busCycleTimeFast_ms ms \n" );
    }

    return $busCycleTimeFast_ms;
}

=head2 CANoeCtrl_rdPrjConst_inactiveValue

    $inactiveValue = CANoeCtrl_rdPrjConst_inactiveValue ( $signal_curve_name  );

Read the L</"Project configuration"> for 'InactiveValue' for output signal '$signal_curve_name'.

Returns $inactiveValue if defined otherwise undef.

=cut

sub CANoeCtrl_rdPrjConst_inactiveValue {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_inactiveValue ($signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );
    my $inactiveValue;

    ## inactive value
    if ( defined $outSignalprjCons_href->{'InactiveValue'} ) {
        $inactiveValue = $outSignalprjCons_href->{'InactiveValue'};
        S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'InactiveValue']  =  $inactiveValue \n" );
    }
    else {
        $inactiveValue = undef;    ## value not used (optional parameter)
        S_w2log( 5, " project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'InactiveValue']  not defined, considered value =  undef \n" );
    }

    return $inactiveValue;
}

=head2 CANoeCtrl_rdPrjConst_NumRepetitionsOnChange

    $numRepetitionsOnChange = CANoeCtrl_rdPrjConst_NumRepetitionsOnChange ( $signal_curve_name  );

Read the L</"Project configuration"> for 'NumRepetitionsOnChange' for output signal '$signal_curve_name'.

Returns $numRepetitionsOnChange if defined otherwise 0.

=cut

sub CANoeCtrl_rdPrjConst_NumRepetitionsOnChange {
    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_rdPrjConst_NumRepetitionsOnChange ($signal_curve_name )', @args );
    my $signal_curve_name = shift @args;

    my $outSignalprjCons_href = S_get_contents_of_hash( [ 'CANoeCtrl', 'OutputSignals', $signal_curve_name ] );

    my $numRepetitionsOnChange;

    if ( defined $outSignalprjCons_href->{'NumRepetitionsOnChange'} ) {
        $numRepetitionsOnChange = $outSignalprjCons_href->{'NumRepetitionsOnChange'};
        S_w2log( 4, " read project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'NumRepetitionsOnChange']  =  $numRepetitionsOnChange \n" );
    }
    else {
        $numRepetitionsOnChange = 0;
        S_w2log( 5, " project constant ['CANoeCtrl', 'OutputSignals', $signal_curve_name , 'NumRepetitionsOnChange']  not defined, considered value =  $numRepetitionsOnChange \n" );
    }

    return $numRepetitionsOnChange;
}

=head2 CANoeCtrl_validSignalDataPoints

    $returnValue = CANoeCtrl_validSignalDataPoints( $inArgs_href );

Before stimulating the signal to the CANoe, signal was checked and error was given:

1) if the given signal has dataPoints more then defined  the defined Max dataPoints in the CANoeCtrl dll.

2) if the Max dataPoints of a signal defined in the CANoeCtrl dll donot match with the Max dataPoints defined in the System variable file.  

B<Arguments:>

=over

=item $inArgs_href->{'busSignalName'} 

Given Signal name.

=item $inArgs_href->{'dataPts_busSignal'} 

DataPoints of the given signal.

=item $inArgs_href->{'sysVarName'}  

System variable name for the given signal where Max datapoint can be defined.

=item $inArgs_href->{'dataPts_SysVar'}

DataPoints as defined in the system varible.

=back

B<Return Value:>

=over

=item $returnValue 

Returns 1 on success (and in offline or simulation mode), undef otherwise.

=back

B<Examples:>

    CANoeCtrl_validSignalDataPoints( {
                                        'busSignalName'     => $signal_curve_name,
                                        'dataPts_busSignal' => $dataPtsCount,
                                        'sysVarName'        => $sysVar_outputSignal,
                                        'dataPts_SysVar'    => scalar(@$max_dataPts_SysVarFile_aref),
                                        'sysVar_SVNumSignals' => <maximum number of output signals defined in the system variable file>
                                    }
                                   ) ; 

=cut

sub CANoeCtrl_validSignalDataPoints {

    my @args = @_;
    return unless S_checkFunctionArguments( 'CANoeCtrl_validSignalDataPoints ($inArgs_href )', @args );

    my $inArgs_href = shift;

    my $signalName            = $inArgs_href->{'busSignalName'};
    my $dataPtsBusSignal      = $inArgs_href->{'dataPts_busSignal'};
    my $sysVarName            = $inArgs_href->{'sysVarName'};
    my $max_dataPts_SysVar    = $inArgs_href->{'dataPts_SysVar'};
    my $max_nbr_outputSignals = $inArgs_href->{'sysVar_SVNumSignals'};

   
    my ( $error_msg, $suggestion_msg );

     # STEP Error if the MAX_NBR_OUTPUT_SIGNAL defined in the dll and defined in the sysvar file are not same.
    my $maxNbr_OutputSignals_dll = CANoeCtrl_getSignalLimits()->{'MAX_NBR_OUTPUT_SIGNAL'};
    if ( $maxNbr_OutputSignals_dll != $max_nbr_outputSignals ) {
        $error_msg      = "Found unequal nbr of max. output signals defined in CANoeCtrl dll and in sysvar file  ['CANoeCtrl dll = $maxNbr_OutputSignals_dll ,  sysvar Stimulus::SVNumSignals = $max_nbr_outputSignals'] .\n";
        $suggestion_msg = "Suggestion - Choose the Sysvar file which has same number of output signals as defined in the CANoeCtrl dll.\n";
        S_set_error( " CANoeCtrl_validateSignalDataPoints : $error_msg  $suggestion_msg ", 131 );
        return;
    }

    # STEP Error if the $max_dataPts_CANoeCtrlDll is not equal to $max_dataPts_SysVar
    my $max_dataPts_CANoeCtrlDll = CANoeCtrl_getSignalLimits()->{'MAX_DATA_POINTS_SIGNAL'};
    if ( $max_dataPts_CANoeCtrlDll != $max_dataPts_SysVar ) {
        $error_msg      = "Unequal DataPts found for signal '$signalName' defined in System Variable '$sysVarName' = $max_dataPts_SysVar and in CANoeCtrl DLL = $max_dataPts_CANoeCtrlDll.\n";
        $suggestion_msg = "Suggestion - Correct the Data points in 'CANoe > SystemVariable > $sysVarName' same as $max_dataPts_CANoeCtrlDll.\n";
        S_set_error( " CANoeCtrl_validateSignalDataPoints : $error_msg  $suggestion_msg ", 131 );
        return;
    }

    # STEP check if signal has more data points than the defined maximum (in CANoeCtrl_Control.dll) then throw an error
    if ( $dataPtsBusSignal > $max_dataPts_CANoeCtrlDll ) {
        $error_msg      = "'$signalName' has datapoints = $dataPtsBusSignal but maxminum supported datapoints are = $max_dataPts_CANoeCtrlDll.\n";
        $suggestion_msg = "Suggestion : Either reduce the datapoints or contact TurboLIFT support regarding the datapoints limits if it can be increased.\n";
        S_set_error( "CANoeCtrl_validateSignalDataPoints : $error_msg  $suggestion_msg ", 114 );
        return;
    }

    return 1;
}

#=============================================
# Below functions are not used by TurboLIFT,  so commented out
# - CANoeCtrl_SetAnalysisSignal
# - CANoeCtrl_SetMonitoringTime
# - CANoeCtrl_getSignalLimits
#       -> alternative is to get use CANoe trace & LIFT evaluation module.
# - CANoeCtrl_SetSignalNow
#       -> alternative is to use -> CA_write_can_signal / LIN_write_LIN_signall / FR_write_flxr_signal
#=============================================

=head2 CANoeCtrl_SetAnalysisSignal

 Function Name   :: CANoeCtrl_SetAnalysisSignal
 
 Description     :: Sets a signal that shall be monitored after the trigger
 
 Syntax          :: status =  CANoeCtrl_SetAnalysisSignal(Signalname, [Operator, Threshold, Triggertype])

 Input Arguments :: Mandatory: Signalname
                    Optional: Operator, Threshold, Triggertype
 
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: status = CANoeCtrl_SetAnalysisSignal('Allrad_SNI', 'Lessthan', 100.0, 'TriggerSoft')

sub CANoeCtrl_SetAnalysisSignal {
    my ( $signalname, $operator, $threshold, $triggertype ) = @_;
    my $signalIndex;
    my $status;

    S_w2log( 4, "CANoeCtrl_SetAnalysisSignal \n" );

    unless ( defined $signalname ) {
        S_set_error( "too less params!, Syntax:: CANoeCtrl_SetAnalysisSignal(Signalname,[Operator, Threshold, Triggertype]) \n", 110 );
        return CANOECTRL_FAILED;
    }

    $signalIndex = $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'}{$signalname}{'Index'};
    unless ( defined $signalIndex ) {
        S_set_error( " Signal index is not available for signal $signalname in project constants \n", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( defined $operator ) {
        S_w2log( 4, "Operator is not passed as argument, considering operator of signal $signalname from project constants\n" );
        $operator = $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'}{$signalname}{'Operator'};

        unless ( defined $operator ) {
            S_w2log( 4, "Operator is not available for signal $signalname in project constants\n" );
            S_set_error( " Operator is not defined for signal $signalname \n", 114 );
            return CANOECTRL_FAILED;
        }
    }

    unless ( defined $threshold ) {
        S_w2log( 4, "Threshold is not passed as argument, considering threshold of signal $signalname from project constants\n" );
        $threshold = $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'}{$signalname}{'Threshold'};

        unless ( defined $threshold ) {
            S_w2log( 4, "Threshold is not available for signal $signalname in project constants\n" );
            S_set_error( " Threshold is not defined for signal $signalname \n", 114 );
            return CANOECTRL_FAILED;
        }
    }

    unless ( defined $triggertype ) {
        S_w2log( 4, "Trigger type is not passed as argument, considering trigger type of signal $signalname from project constants\n" );
        $triggertype = $main::ProjectDefaults->{'CANoeCtrl'}{'AnalysisSignals'}{$signalname}{'Triggertype'};

        unless ( defined $triggertype ) {
            S_w2log( 4, "Trigger type is not available for signal $signalname in project constants\n" );
            S_set_error( " Trigger type is not defined for signal $signalname \n", 114 );
            return CANOECTRL_FAILED;
        }
    }

    unless ( $signalIndex =~ /^\d+$/ ) {
        S_set_error( " SignalIndex is not numeric \n", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( ( $operator =~ /Equals/i ) || ( $operator =~ /Lessthan/i ) || ( $operator =~ /Greaterthan/i ) ) {
        S_set_error( " Operator type should be either Equals or Lessthan or Greaterthan \n", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( $threshold =~ /^\d+\.?\d*$/ ) {
        S_set_error( " Threshold is not number ", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( ( $triggertype =~ /Triggersoft/i ) || ( $triggertype =~ /Triggerhard/i ) ) {
        S_set_error( "Trigger type should be either Triggersoft or Triggerhard  \n", 114 );
        return CANOECTRL_FAILED;
    }

    if ($measure) {
        S_set_error( "Measurement is running, cannot set the signal for analysis", 120 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( " CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    #In DLL level 	Triggersoft - 0 , Triggerhard - 1
    if ( $triggertype =~ /Triggersoft/i ) {
        $triggertype = 0;
    }
    else {
        $triggertype = 1;
    }

    #In DLL level Equals - 0, Lessthan - 1, Greaterthan - 2
    if ( $operator =~ /Equals/i ) {
        $operator = 0;
    }
    elsif ( $operator =~ /Lessthan/i ) {
        $operator = 1;
    }
    else {
        $operator = 2;
    }

    $status = canoectrl_setAnalysisSignal( $signalIndex, $operator, $threshold, $triggertype );

    Check_status( $status, "setAnalysisSignal Failed ($signalname)" );
    S_w2log( 4, "Status of canoectrl_setAnalysisSignal ($signalname) :: $status \n" );

    return $status;
}
=cut

=head2 CANoeCtrl_SetMonitoringTime

 Function Name   :: CANoeCtrl_SetMonitoringTime
 
 Description     :: Sets a maximum monitoring time in milliseconds.
 
 Syntax          :: status = CANoeCtrl_SetMonitoringTime(Time_ms)

 Input Arguments :: Time in milliseconds
 
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: status  = CANoeCtrl_SetMonitoringTime(100);

sub CANoeCtrl_SetMonitoringTime {
    my $time_ms = shift;
    my $status  = 0;

    S_w2log( 4, "CANoeCtrl_SetMonitoringTime \n" );

    unless ( defined $time_ms ) {
        S_set_error( " ! too less parameters ! SYNTAX: CANoeCtrl_SetMonitoringTime(Time_ms) ", 110 );
        return CANOECTRL_FAILED;
    }

    unless ( $time_ms =~ /^\d+$/ ) {
        S_set_error( " Time is not numeric ", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( $time_ms > 0 ) {
        S_set_error( " Monitoring time should be greater than '0' ", 114 );
        return CANOECTRL_FAILED;
    }

    if ($measure) {
        S_set_error( "Measurement is running, cannot set the signal for analysis", 120 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( " CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    $status = canoectrl_setMonitoringTime($time_ms);

    Check_status( $status, "setMonitoringTime Failed" );
    S_w2log( 4, "Status of canoectrl_setMonitoringTime :: $status \n" );

    return $status;
}
=cut

=head2 CANoeCtrl_GetSignalTimes

 Function Name   :: CANoeCtrl_GetSignalTimes
 
 Description     :: Gets the response times in milliseconds of configured signals
 
 Syntax          :: (status, time) = CANoeCtrl_GetSignalTimes(NumSignals)

 Input Arguments :: NumSignals
 
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
                    time
 
 Example         :: (status, time) = CANoeCtrl_GetSignalTimes(10)

sub CANoeCtrl_GetSignalTimes {
    my $time;
    my $numSignals = shift;
    my $status     = 0;

    S_w2log( 4, "CANoeCtrl_GetSignalTimes \n" );

    unless ( defined $numSignals ) {
        S_set_error( " ! too less parameters ! SYNTAX: CANoeCtrl_GetSignalTimes(NumSignals) ", 110 );
        return CANOECTRL_FAILED;
    }

    unless ( $numSignals =~ /^\d+$/ ) {
        S_set_error( " CANoeCtrl_GetSignalTimes : numSignals is not number ", 114 );
        return CANOECTRL_FAILED;
    }

    unless ( $numSignals > 0 ) {
        S_set_error( " CANoeCtrl_GetSignalTimes : numSignals should be greater than '0' ", 114 );
        return CANOECTRL_FAILED;
    }

    if ($measure) {
        S_set_error( "CANoeCtrl_GetSignalTimes : Measurement is running, cannot get the response times of configured signals\n", 120 );
        return CANOECTRL_FAILED;
    }

    unless ($CANoe_Init) {
        S_set_error( "CANoeCtrl_GetSignalTimes :  CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return ( CANOECTRL_OFFLINE, [ CANOECTRL_OFFLINE, CANOECTRL_OFFLINE ] ) if ($main::opt_offline);

    ( $status, $time ) = canoectrl_getSignalTimes($numSignals);

    Check_status( $status, "getSignalTimes Failed" );
    S_w2log( 4, "Status of canoectrl_getSignalTimes :: $status \n" );

    return ( $status, $time );
}
=cut

=head2 CANoeCtrl_SetSignalNow

 Function Name   :: CANoeCtrl_SetSignalNow
 
 Description     :: Immediatelty set a signal to a given value. 
                    This can only be called during measurement, otherwise 0 is returned. 
                    The signal is identified by its name, if the name is ambiguous then signal can be further
                    identified by the channel, database, node, and message where it belongs to. 
                    Thus, the exact qualification syntax is
                    [Channel::][Database name (alias)::][Node::][Message::]Signal
                    The function returns 1 if the COM call succeeds, otherwise 0. 
                    Note that it is not checked whether the signal exists, 
                    i.e., if the COM call to CANoe succeeds but there is no such signal, 1 is returned.
 
 Syntax          :: status = CANoeCtrl_SetSignalNow(SignalName, SignalValue)

 Input Arguments :: SignalName : The name of the signal to set
                    SignalValue : The new value of the signal.
 
 Return Value(s) :: status ( >0 success, CANOECTRL_OFFLINE failure, CANOECTRL_OFFLINE offline)
 
 Example         :: $status = CANoeCtrl_SetSignalNow("CAN1::Msg1::MySignal", 23.0)
                    Sets the signal MySignal on message Msg1 which is sent on the bus CAN1 to 23.0.

sub CANoeCtrl_SetSignalNow {
    my ( $signalName, $signalValue ) = @_;
    my $status = 0;

    unless ( defined $signalValue ) {
        S_set_error( " ! too less parameters ! SYNTAX: CANoeCtrl_SetSignalNow(SignalName, SignalValue) ", 110 );
        return CANOECTRL_FAILED;
    }

    #supported signal value examples: -2, -2.0, 2.0, 2
    unless ( $signalValue =~ /[-]?(\d+)(\.)?(\d+)?/ ) {
        S_set_error( "CANoeCtrl_SetSignalNow :Signal value should be numeric, examples: -2, -2.0, 2.0, 2 \n", 114 );
        return CANOECTRL_FAILED;
    }

    S_w2log( 4, "CANoeCtrl_SetSignalNow, signalName : $signalName \n" );
    unless ($CANoe_Init) {
        S_set_error( " CANoeCtrl_SetSignalNow : CANoeCtrl not initialized \n", 120 );
        return CANOECTRL_FAILED;
    }

    return CANOECTRL_OFFLINE if ($main::opt_offline);

    unless ($measure) {
        S_w2log( 4, "CANoeCtrl_SetSignalNow : Signal $signalName will be set to Value $signalValue after measurement is started \n" );
        $SetSignalNow{$signalName} = $signalValue;
    }

    if ($measure) {
        $status = canoectrl_setSetSignalNow( $signalName, $signalValue );
        Check_status( $status, "SetSignalNow Failed" );
        S_w2log( 4, "Status of canoectrl_setSetSignalNow for signal $signalName :: $status \n" );
        return $status;
    }
}

=cut

1;

__END__

=head1 AUTHORS

G V Sriram, E<lt> VeerabhadraSriram.Grandhi@in.bosch.com E<gt>

=head1 NOTES

B<ReturnValue>

offline mode :: B<3>

Failure of function execution :: B<0>

=head1 SEE ALSO

Perl documentation

=cut 


