package ADIS;

use 5.012001;
use strict;
use warnings;


BEGIN
{
    # add directories to search path for perl modules    
    use Config;
    use File::Spec;
    use File::Basename;
    my $addpath = File::Spec->rel2abs(dirname(__FILE__));
    $addpath =~ s/\//\\/g; # replace all slashes with backslahes
    
    my $win32 = $addpath . "\\Win32";       #perl 5.12, 32-bit DLL directory
    unshift @INC, ($win32);    #Load ADIS.dll from "Win32"
    $ENV{PATH} = $win32 . ";$ENV{PATH}"; #Load wrapper dll from "Win32"
}


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use ADIS ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	adis_getPMrevision
	adis_getXSrevision
	adis_getCWrevision
	adis_FirmwareInfo
	adis_Start
	adis_Connect
	adis_Disconnect
	adis_ReadData
	adis_WriteRegWord
	adis_ReadArray
);

our $VERSION = '0.01';

require XSLoader;
XSLoader::load('ADIS', $VERSION);

# Preloaded methods go here.

sub adis_getPMrevision{
    return ('SCM');
}

sub adis_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub adis_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

1;
__END__

=head1 NAME

ADIS - Perl extension for RAT reference sensor

=head1 SYNOPSIS

  use ADIS;

=head1 DESCRIPTION

All these functions are wrapped around EvalAdisApi_32.dll APIs.


=head2 adis_Start

 $status = adis_Start();

load EvalAdisApi_32.dll and initalize function pointers


=head2 adis_FirmwareInfo

 $firmware = adis_FirmwareInfo();


=head2 adis_Connect

 $status = adis_Connect();


=head2 adis_Disconnect

 $status = adis_Disconnect(); 


=head2 adis_WriteRegWord

 $status = adis_WriteRegWord($addr, $data); 


=head2 adis_ReadData

 $data = adis_ReadData($addr); 


=head2 adis_ReadArray

 $data_aref = adis_ReadArray($addr_aref, $samples); 

	$addr_aref = [addr_a,addr_b,addr_c]
	$data_aref = [value_a,value_b,value_c,value_a,value_b,value_c, ...];




=head1 TRACEABILITY FUNCTIONS

=head2 adis_getPMrevision

returns MKS revision number of .pm file

=head2 adis_getXSrevision

returns MKS revision number of .xs file

=cut

=head2 adis_getCWrevision

returns MKS revision number of Interface.c file

=cut

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl,


=cut
