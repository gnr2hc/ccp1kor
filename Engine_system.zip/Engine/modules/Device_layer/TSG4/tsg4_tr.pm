package tsg4_tr;

use strict;
use warnings;
use tsg4;
use TSG4CAN;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    tr_send_commad
    tr_send_commad_wait_response
    tr_get_firmware
    tr_get_HW_id
    tr_bootloader_mode
    tr_write_SN
    tr_enable_PWM
    tr_enable_EVTR
    tr_connect_channel
    tr_disconnect_channel
    tr_connect_DUT
    tr_disconnect_DUT
    tr_display_text
    tr_connect_switch
    tr_disconnect_switch
    tr_reset_all
    tr_enable_FirePulse

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value,$TRstatus);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

Test Rack module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

=head2 tr_get_firmware

    ($status, $firmware) = tr_get_firmware();

    e.g. (0,'Ver 1.0') = tr_get_firmware();

reads firmware version from rack controller

returns status.

=cut

sub tr_get_firmware {
    my $value;

    ($status,$value) = tr_send_commad_wait_response('?00');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 tr_get_HW_id

    ($status, $HW_ID) = tr_get_HW_id();

    e.g. (0,'999/0042') = tr_get_HW_id();

reads hardware ID from rack controller card

returns status.

=cut

sub tr_get_HW_id {
    my $value;

    ($status,$value) = tr_send_commad_wait_response('?02');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 tr_bootloader_mode

    $status = tr_bootloader_mode();

    e.g. $status = tr_bootloader_mode();

sets rack controller to bootloader mode for firmware update

returns status.

=cut

sub tr_bootloader_mode {
    my ($value);

    ($status,$value) = tr_send_commad_wait_response('@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}

=head2 tr_write_SN

    $status = tr_write_SN($serial_number);

    e.g. $status = tr_write_SN('999/42');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub tr_write_SN {
    my $SN = shift;
    my ($receive_ID);

    ($status,$receive_ID) = tr_send_commad('#37');

#    printf( "-> 0x%02x $SN\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $receive_ID-1, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TR" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

=head2 tr_enable_PWM

    $status = tr_enable_PWM($slot);

    e.g. $status = tr_enable_PWM(1);

send PWM signals for 5 sec.

returns status after PWM finished.

=cut

sub tr_enable_PWM {
    my $slot=shift;
    my $command;
    $command = sprintf("P%02d",$slot);

    ($TRstatus,$value) = tr_send_commad_wait_response($command,5000+$MAXtimeout);
#    print("tr_enable_PWM response: $value\n");

    $status = tr_check_response($TRstatus,$value);

#    print("PWM sent\n");
    
    return ($status);
    
}


=head2 tr_enable_EVTR

    $status = tr_enable_EVTR();

    e.g. $status = tr_enable_EVTR();

send event trigger signal.

returns status.

=cut

sub tr_enable_EVTR {

    ($TRstatus,$value) = tr_send_commad_wait_response('E');
#    print("tr_enable_EVTR response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("Event trigger sent\n");
    
    return ($status);
    
}

=head2 tr_enable_FirePulse

    $status = tr_enable_FirePulse( $duration );

    e.g. $status = tr_enable_FirePulse( 5 );

send fire pulse for $duration milliseconds (1..99)

returns status.

=cut

sub tr_enable_FirePulse {
    my $duration=shift;
    my $command = sprintf("F%02d",$duration);
    ($TRstatus,$value) = tr_send_commad_wait_response($command);
#    print("tr_enable_FirePulse $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("Fire pulse sent\n");
    
    return ($status);
    
}

=head2 tr_connect_channel

    $status = tr_connect_channel($channel_nr);

    e.g. $status = tr_connect_channel(3);

connect scanner channel (1..24) to TRC/DMM. 23 = 10 Ohm ZK measure shunt, 24 100 Ohm BL measure shunt.

returns status.

=cut

sub tr_connect_channel {
    my $channel=shift;
    my $command;
    $command = sprintf("XRe%02d",$channel);


    ($TRstatus,$value) = tr_send_commad_wait_response($command);
#    print("tr_connect_channel response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("channel $channel connected\n");
    
    return ($status);
    
}

=head2 tr_disconnect_channel

    $status = tr_disconnect_channel($channel_nr);

    e.g. $status = tr_disconnect_channel(3);

disconnect scanner channel (1..24) from TRC/DMM.

returns status.

=cut

sub tr_disconnect_channel {
    my $channel=shift;
    my $command;
    $command = sprintf("XRa%02d",$channel);


    ($TRstatus,$value) = tr_send_commad_wait_response($command);
#    print("tr_disconnect_channel response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("channel $channel disconnected\n");
    
    return ($status);
    
}

=head2 tr_connect_switch

    $status = tr_connect_switch($switch_nr);

    e.g. $status = tr_connect_switch(1);

connect switch (1..2) . 1 = PULSE, 2 = LS1

returns status.

=cut

sub tr_connect_switch {
    my $switch=shift;
    my $command;
    $command = sprintf("XEe%02d",$switch);


    ($TRstatus,$value) = tr_send_commad_wait_response($command);
#    print("tr_connect_channel response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("switch $switch connected\n");
    
    return ($status);
    
}

=head2 tr_disconnect_switch

    $status = tr_disconnect_switch($switch_nr);

    e.g. $status = tr_disconnect_switch(1);

disconnect switch (1..2) .

returns status.

=cut

sub tr_disconnect_switch {
    my $switch=shift;
    my $command;
    $command = sprintf("XEa%02d",$switch);


    ($TRstatus,$value) = tr_send_commad_wait_response($command);
#    print("tr_disconnect_channel response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("switch $switch disconnected\n");
    
    return ($status);
    
}

=head2 tr_reset_all

    $status = tr_reset_all();

    e.g. $status = tr_reset_all();

reset all scanner and switches.

returns status.

=cut

sub tr_reset_all {
    ($TRstatus,$value) = tr_send_commad_wait_response('RA');
#    print("tr_reset_all response: $value\n");
 
    $status = tr_check_response($TRstatus,$value);
#    print("all scanner and switches reset\n");
    
    return ($status);
    
}

=head2 tr_connect_DUT

    $status = tr_connect_DUT();

    e.g. $status = tr_connect_DUT();

connect Device Under Test supply voltage.

returns status.

=cut

sub tr_connect_DUT {

    ($TRstatus,$value) = tr_send_commad_wait_response('Ue');
#    print("tr_connect_DUT response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("DUT connected\n");

    return ($status);

}


=head2 tr_disconnect_DUT

    $status = tr_disconnect_DUT();

    e.g. $status = tr_disconnect_DUT();

disconnect Device Under Test supply voltage.

returns status.

=cut

sub tr_disconnect_DUT {

    ($TRstatus,$value) = tr_send_commad_wait_response('Ua');
#    print("tr_disconnect_DUT response: $value\n");
    $status = tr_check_response($TRstatus,$value);
#    print("DUT disconnected\n");

    return ($status);

}

=head2 tr_display_text

    $status = tr_display_text($text,$position);

    e.g. $status = tr_display_text('hello',1);

    $text length <= 8 
    $position = 1,2,3,4 (line 1 left, line 1 right, line 2 left, line 2 right)

writes text to card to be displayed.

=cut

sub tr_display_text {
    my $text = shift;
    my $position = shift;
    my ($receive_ID);
    
    while (length($text)<8){
        $text.=' ';
    }

    ($status,$receive_ID) = tr_send_commad("V$position");

#    printf( "-> 0x%02x $text\n",$receive_ID-1);
    
    my @bytes = split(//, $text);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $receive_ID-1, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, 'TR' );
    tsg4_wait_ms(5);
    
    return ($status);
    
}



################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 tr_send_commad_wait_response

    ($stat,$ret) = tr_send_commad_wait_response($ASCII_command [, $timeout] );

Transmits the string $ASCII_command on the CAN to test rack controller

if no $timeout given takes default $Maxtimeout

returns status and answer string as ASCII.

=cut

sub tr_send_commad_wait_response {
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless (defined $timeout);
    my ($byte,$data_aref);

    my $send_ID = TestRack_base_address;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("E00%s",$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "TR" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 tr_send_commad

    ($stat,$receive_ID) = tr_send_commad($ASCII_command);

    e.g. ($status,$receive_ID) = tr_send_commad('P01');


Transmits the string $data on the CAN to test rack controller

returns status and answer ID.

=cut

sub tr_send_commad {
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = TestRack_base_address;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("E00%s",$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TR" );
    return ($status,$receive_ID);
    
}



=head2 tr_check_response

 $status = tr_check_response($TRstatus,$TRresult);

if $TRstatus < 0, set error string and return -1.
if $result not 'done' set error string and return -2.

=cut

sub tr_check_response{
    my $TRstatus = shift;
    my $TRresult = shift;

    if ($TRstatus<0){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -1
      
    }
    if ($TRresult !~ m/^done/){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -2
      
    }
    
    return 0;

}

1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



