package tsg4_spdt;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    spdt_send_commad
    spdt_send_commad_wait_response
    spdt_reset
    spdt_bootloader_mode
    spdt_get_firmware
    spdt_get_HW_id
    spdt_write_SN
    spdt_write_TST
    spdt_write_CAL
	spdt_get_INFO
	spdt_set_state

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

generic switch card (single pole, double throw) control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 spdt_reset

    $status = spdt_reset($SPDTnumber);

    e.g. $status = spdt_reset(1);

resets all switches (default off = C-NC)

returns status.

=cut

sub spdt_reset {
    my $SPDTnumber = shift;

    my $command = "R01";

    ($status,$receive_ID) = spdt_send_commad_wait_response($SPDTnumber,$command);
    
    return ($status);
    
}


=head2 spdt_set_state

    $status = spdt_set_state($SPDTnumber, $Switch_number, $state);
    
    $Switch_number 1..40

	$state = 'on' or 'off', default is 'off'   
	
	      -- NO (on)
	C ---
	      -- NC (off)

    e.g. $status = spdt_set_state(1,7,'on');

connects SPDT switch $Switch_number to given position

returns status.

=cut

sub spdt_set_state {
    my $SPDTnumber = shift;
    my $Switch_number = shift;
    my $state = shift;
	if ($state eq 'on'){
		$state='e';
	}
	else{
		$state='a';
	}

    my $command = sprintf("S%02d%s",$Switch_number,$state);

    ($status,$receive_ID) = spdt_send_commad_wait_response($SPDTnumber,$command);
    
    return ($status);
    
}


=head2 spdt_write_SN

    $status = spdt_write_SN($SPDTnumber,$serial_number);

    e.g. $status = spdt_write_SN(1,'999W0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub spdt_write_SN {
    my $SPDTnumber = shift;
    my $SN = shift;

    $status = spdt_write_EE($SPDTnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 spdt_write_TST

    $status = spdt_write_TST($SPDTnumber,$TST_date);

    e.g. $status = spdt_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub spdt_write_TST {
    my $SPDTnumber = shift;
    my $TST_date = shift;

    $status = spdt_write_EE($SPDTnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 spdt_write_CAL

    $status = spdt_write_CAL($SPDTnumber,$CAL_date);

    e.g. $status = spdt_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub spdt_write_CAL {
    my $SPDTnumber = shift;
    my $CAL_date = shift;

    $status = spdt_write_EE($SPDTnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 spdt_bootloader_mode

    $status = spdt_bootloader_mode($SPDTnumber);

    e.g. $status = spdt_bootloader_mode(1);

sets SPDT switch card to bootloader mode for firmware update

returns status.

=cut

sub spdt_bootloader_mode {
    my $SPDTnumber = shift;
    my $value;

    ($status,$value) = spdt_send_commad_wait_response($SPDTnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 spdt_get_firmware

    ($status, $firmware) = spdt_get_firmware($SPDTnumber);

    e.g. (0,'FW_W0001') = spdt_get_firmware(1);

reads firmware version from SPDT switch card

returns status.

=cut

sub spdt_get_firmware {
    my $SPDTnumber = shift;
    my $value;

    ($status,$value) = spdt_send_commad_wait_response($SPDTnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 spdt_get_HW_id

    ($status, $HW_ID) = spdt_get_HW_id($SPDTnumber);

    e.g. (0,'999W0042') = spdt_get_HW_id(1);

reads hardware ID from SPDT switch card

returns status.

=cut

sub spdt_get_HW_id {
    my $SPDTnumber = shift;
    my $value;

    ($status,$value) = spdt_get_INFO($SPDTnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 spdt_get_INFO

    ($status, $INFO) = spdt_get_INFO($SPDTnumber,$keyword);

    e.g. (0,'999R0042') = spdt_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from SPDT switch card

returns status.

=cut

sub spdt_get_INFO {
    my $SPDTnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = spdt_send_commad_wait_response($SPDTnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 spdt_write_EE not exported

    $status = spdt_write_EE($SPDTnumber,$EEslot,$text);

    e.g. $status = spdt_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub spdt_write_EE {
    my $SPDTnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = spdt_send_commad($SPDTnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "SPDT_$SPDTnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 spdt_send_commad_wait_response

    ($stat,$ret) = spdt_send_commad_wait_response($SPDTnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to SPDT scanner

returns status and answer string as ASCII.

=cut

sub spdt_send_commad_wait_response {
    my $SPDTnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;

    my $send_ID = GenericSwitch_base_address +(($SPDTnumber - 1) * 2);   
    
    $ASCII_command = sprintf("W%01d%s",$SPDTnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "SPDT_$SPDTnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 spdt_send_commad

    ($stat,$receive_ID) = spdt_send_commad($SPDTnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = spdt_send_commad(3,'?00');

Transmits the string $data on the CAN to SPDT scanner

returns status and answer ID.

=cut

sub spdt_send_commad {
    my $SPDTnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = GenericSwitch_base_address +(($SPDTnumber - 1) * 2);   
    
    $ASCII_command = sprintf("W%01d%s",$SPDTnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "SPDT_$SPDTnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



