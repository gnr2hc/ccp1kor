package tsg4_canfr;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    cf_send_commad
    cf_send_commad_wait_response
    cf_connect
    cf_disconnect
    cf_connect_via
    cf_disconnect_via
	cf_microcut
	cf_LV124    
	cf_set_termination_highspeed
	cf_clear_termination_highspeed
	cf_set_termination_lowspeed
	cf_clear_termination_lowspeed
    cf_bootloader_mode
    cf_set_event_delay
    cf_set_event_trigger
    cf_get_firmware
    cf_get_HW_id
    cf_write_SN
    cf_write_TST
    cf_write_CAL
	cf_get_INFO

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

CAN/FlexRay card control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut



=head2 cf_set_termination_lowspeed

    $status = cf_set_termination_lowspeed($CHnumber,$resistor);

    e.g. $status = cf_set_termination_lowspeed(3,2);

    $resistor between 1 .. 3, values depend on hardware
    
        ch_odd     ch_even (on card)
    1 - R15/R16 or R24/R25
    2 - R17/R18 or R26/R27
    3 - R19/R20 or R28/R29
    C - allow combination of resistors
    
sets termination resistors on CAN/FlexRay channel $CHnumber, usually used for lowspeed CAN

returns status.

=cut

sub cf_set_termination_lowspeed {
    my $CHnumber = shift;
    my $resistor = shift;
    my $command;

    $command = sprintf("P%s"."e",$resistor);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}

=head2 cf_clear_termination_lowspeed

    $status = cf_clear_termination_lowspeed($CHnumber,$resistor);

    e.g. $status = cf_clear_termination_lowspeed(3,2);

    $resistor between 1 .. 3, values depend on hardware
    
        ch_odd     ch_even (on card)
    1 - R15/R16 or R24/R25
    2 - R17/R18 or R26/R27
    3 - R19/R20 or R28/R29
    C - lock combination of resistors (default)

clears termination resistors on CAN/FlexRay channel $CHnumber, usually used for lowspeed CAN

returns status.

=cut

sub cf_clear_termination_lowspeed {
    my $CHnumber = shift;
    my $resistor = shift;
    my $command;

    $command = sprintf("P%s"."a",$resistor);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 cf_set_termination_highspeed

    $status = cf_set_termination_highspeed($CHnumber,$resistor);

    e.g. $status = cf_set_termination_highspeed(3,2);

    $resistor between 1 .. 3, values depend on hardware
    
        ch_odd   ch_even (on card)
    1 - R12  or  R21
    2 - R13  or  R22
    3 - R14  or  R23
    C - allow combination of resistors
    
sets termination resistor on CAN/FlexRay channel $CHnumber, usually used for highspeed CAN or FR

returns status.

=cut

sub cf_set_termination_highspeed {
    my $CHnumber = shift;
    my $resistor = shift;
    my $command;

    $command = sprintf("A%s"."e",$resistor);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}

=head2 cf_clear_termination_highspeed

    $status = cf_clear_termination_highspeed($CHnumber,$resistor);

    e.g. $status = cf_clear_termination_highspeed(3,2);

    $resistor between 1 .. 3, values depend on hardware
    
        ch_odd   ch_even (on card)
    1 - R12  or  R21
    2 - R13  or  R22
    3 - R14  or  R23
    C - lock combination of resistors (default)

clears termination resistor on CAN/FlexRay channel $CHnumber, usually used for highspeed CAN or FR

returns status.

=cut

sub cf_clear_termination_highspeed {
    my $CHnumber = shift;
    my $resistor = shift;
    my $command;

    $command = sprintf("A%s"."a",$resistor);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 cf_connect_via

    $status = cf_connect_via($CHnumber,$pin,$via);
    
    e.g. $status = cf_connect_via(3,'H',1); # connect CAN3 HIGH to ref1

    $pin = H L G (high, low, ground)

connect pin $pin of channel $CHnumber to reference line $via

returns status.

=cut

sub cf_connect_via {
    my $CHnumber = shift;
    my $pin = shift;
    my $via = shift;
    my $command;

    $command = sprintf("B%s"."e%d",$pin,$via);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
#    print("cf_connect_via ($CHnumber $pin $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 cf_disconnect_via

    $status = cf_disconnect_via($CHnumber,$pin,$via);
    
    e.g. $status = cf_disconnect_via(3,'H',1); # disconnect CAN3 HIGH from ref1

    $pin = H L G (high, low, ground)

disconnect pin $pin of channel $CHnumber from reference line $via

returns status.

=cut

sub cf_disconnect_via {
    my $CHnumber = shift;
    my $pin = shift;
    my $via = shift;
    my $command;

    $command = sprintf("B%s"."a%d",$pin,$via);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
#    print("cf_disconnect_via ($CHnumber $pin $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 cf_set_event_delay

    $status = cf_set_event_delay($CHnumber,$delay);

    e.g. $status = cf_set_event_delay(3,1.7);

    $delay between 0 .. 9.9 millisec step 0.1 millisec 

sets delay on CAN/FlexRay card for cf_set_event_trigger

returns status.

=cut

sub cf_set_event_delay {
    my $CHnumber = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%03d",$delay*10);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 cf_set_event_trigger

    $status = cf_set_event_trigger($CHnumber, $pin,$fault_type);

    e.g. $status = cf_set_event_trigger(3,'H',1);

    $pin = H L G (high, low, ground)
    
    $fault_type between 0 .. 8 

     0 - no fault
     1 - interruption
     2 - pin to ref1
     3 - pin to ref2
     4 - LV124 10sec interruption
     5 - LV124 1ms   interruption
     6 - LV124 100us interruption
     7 - LV124 1us   interruption 1ms pause with 4 sec cycle
     8 - LV124 100us interruption 1ms pause with 4 sec cycle

sets event trigger mode on pin $pin of channel $CHnumber.

returns status.

=cut

sub cf_set_event_trigger {
    my $CHnumber = shift;
    my $pin = shift;
    my $fault_type = shift;
    my $command;
    
    $command = sprintf("E%s%d",$pin,$fault_type);
    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
}



=head2 cf_LV124

    $status = cf_LV124($CHnumber, $pin, $fault_type);

    e.g. $status = cf_LV124(3,'H',4);

    $pin = H L G (high, low, ground)
    
    $fault_type between 0 .. 5 

    0 - no fault
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on pin $pin of channel $CHnumber.

=cut

sub cf_LV124 {
    my $CHnumber = shift;
    my $pin = shift;
    my $fault_type = shift;

    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);
    
    my $command = sprintf("L%s%d",$pin,$fault_type);

    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command,$timeout);
    
    return ($status);
    
}

=head2 cf_microcut

    $status = cf_microcut($CHnumber, $pin, $offtime_us);

    e.g. $status = cf_microcut(3,'H',100);
    
    $pin = H L G (high, low, ground)
    $offtime_us in microseconds

starts microcut (LV124) fault simulation on pin $pin of channel $CHnumber.

=cut

sub cf_microcut {
    my $CHnumber = shift;
    my $pin = shift;
    my $offtime_us = shift;

    my $timeout=int($offtime_us/1000)+1000;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s%s",$pin,join('',@bytes));

    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command,$timeout);
    
    return ($status);
    
}


=head2 cf_connect

    $status = cf_connect($CHnumber, $pin);
    
    $pin = H L G (high, low, ground)

    e.g. $status = cf_connect(3,'H');

connects bus pin $pin on channel $CHnumber

returns status.

=cut

sub cf_connect {
    my $CHnumber = shift;
    my $pin = shift;

    my $command = "U".$pin."a";

    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}



=head2 cf_disconnect

    $status = cf_disconnect($CHnumber, $pin);
    
    $pin = H L G (high, low, ground)

    e.g. $status = cf_disconnect(3,'H');

disconnects bus pin $pin on channel $CHnumber

returns status.

=cut

sub cf_disconnect {
    my $CHnumber = shift;
    my $pin = shift;

    my $command = "U".$pin."e";

    ($status,$receive_ID) = cf_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 cf_write_SN

    $status = cf_write_SN($CHnumber,$serial_number);

    e.g. $status = cf_write_SN(3,'999D0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub cf_write_SN {
    my $CHnumber = shift;
    my $SN = shift;

    $status = cf_write_EE($CHnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 cf_write_TST

    $status = cf_write_TST($CHnumber,$TST_date);

    e.g. $status = cf_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub cf_write_TST {
    my $CHnumber = shift;
    my $TST_date = shift;

    $status = cf_write_EE($CHnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 cf_write_CAL

    $status = cf_write_CAL($CHnumber,$CAL_date);

    e.g. $status = cf_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub cf_write_CAL {
    my $CHnumber = shift;
    my $CAL_date = shift;

    $status = cf_write_EE($CHnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 cf_bootloader_mode

    $status = cf_bootloader_mode($CHnumber);

    e.g. $status = cf_bootloader_mode(1);

sets CAN/FR card to bootloader mode for firmware update

returns status.

=cut

sub cf_bootloader_mode {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = cf_send_commad_wait_response($CHnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 cf_get_firmware

    ($status, $firmware) = cf_get_firmware($CHnumber);

    e.g. (0,'Ver 1.0') = cf_get_firmware(3);

reads firmware version from CAN/FR card

returns status.

=cut

sub cf_get_firmware {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = cf_send_commad_wait_response($CHnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 cf_get_HW_id

    ($status, $HW_ID) = cf_get_HW_id($CHnumber);

    e.g. (0,'999D0042') = cf_get_HW_id(3);

reads hardware ID from CAN/FR card

returns status.

=cut

sub cf_get_HW_id {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = cf_get_INFO($CHnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 cf_get_INFO

    ($status, $INFO) = cf_get_INFO($CHnumber,$keyword);

    e.g. (0,'999D0042') = cf_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from CAN/FR card

returns status.

=cut

sub cf_get_INFO {
    my $CHnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = cf_send_commad_wait_response($CHnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 cf_write_EE not exported

    $status = cf_write_EE($CHnumber,$EEslot,$text);

    e.g. $status = cf_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in CAN/FR card.

=cut

sub cf_write_EE {
    my $CHnumber = shift;
    my $slot = shift;
    my $text = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = cf_send_commad($CHnumber,$command);

#    printf( "-> 0x%02x $text (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $text);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "CF_$CHnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 cf_send_commad_wait_response

    ($stat,$ret) = cf_send_commad_wait_response($CHnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to CAN/FR card channel

returns status and answer string as ASCII.

=cut

sub cf_send_commad_wait_response {
    my $CHnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref,$offset);
    $timeout = $MAXtimeout unless defined $timeout;

    if(($CHnumber & 0x01) ==1) {$offset=($CHnumber+1)-2;}
    else {$offset=$CHnumber-2;}

    my $send_ID = CAN_base_address + $offset;   
    
    $ASCII_command = sprintf("C%d%s",$CHnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "CF_$CHnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
 #printf( "<- %s\n",join('',@response));
    
    return (0,join('',@response));
    
}


=head2 cf_send_commad

    ($stat,$receive_ID) = cf_send_commad($CHnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = cf_send_commad(3,'?00');

Transmits the string $data on the CAN to CAN/FR card channel

returns status and answer ID.

=cut

sub cf_send_commad {
    my $CHnumber = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

    if(($CHnumber & 0x01) ==1) {$offset=($CHnumber+1)-2;}
    else {$offset=$CHnumber-2;}

    my $send_ID = CAN_base_address + $offset;   
    
    $ASCII_command = sprintf("C%d%s",$CHnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "CF_$CHnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



