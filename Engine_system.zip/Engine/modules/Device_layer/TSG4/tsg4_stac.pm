package tsg4_stac;

use strict;
use warnings;
use tsg4;
use TSG4CAN;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(

    stac_send_commad
    stac_send_commad_wait_response
    stac_relay
    stac_relay_on
    stac_relay_off
    stac_get_bank
    stac_reset

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);



############################################################################################################

=head1 DESCRIPTION

STAC module for TSG4 family HW via CAN 

CAN has to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

# in Testprog only high level apis are used (single relay function)

# how to set faults e.g. for squib, PAS ?

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

=head2 stac_relay_on

    ($status) = stac_relay_on($number);

    e.g. (0) = stac_relay_on(1);

	$number 1..2
	

switch single relay on, better call connect?

returns status.

=cut

sub stac_relay_on {

	my $number = shift;
	my $command_on = sprintf("SA%03de",$number);

    ($status,$value) = stac_send_commad($command_on);

    return ($status);

}

=head2 stac_relay_off

    ($status) = stac_relay_off($number);

    e.g. (0) = stac_relay_off(1);

	$number 1..2
	

switch single relay off

returns status.

=cut

sub stac_relay_off {

	my $number = shift;
	my $command_off = sprintf("SA%03da",$number);

    ($status,$value) = stac_send_commad($command_off);

    return ($status);

}

=head2 stac_reset

    ($status) = stac_reset();

    e.g. (0) = stac_reset();

	$number 1..2
	

reset stac, all relays open (disconnected)

returns status.

=cut

sub stac_reset {

    ($status,$value) = stac_send_commad('SARST');

    return ($status);

}


################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 stac_send_commad_wait_response

    ($stat,$ret) = stac_send_commad_wait_response($ASCII_command [, $timeout] );

Transmits the string $ASCII_command on the CAN to test rack controller

if no $timeout given takes default $Maxtimeout

returns status and answer string as ASCII.

=cut

sub stac_send_commad_wait_response {
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless (defined $timeout);
    my ($byte,$data_aref);

    my $send_ID = 0x10;
    my $receive_ID = 0x110;

    $ASCII_command = sprintf("%s",$ASCII_command);
    #printf( "-> 0x%02x $ASCII_command\n",$send_ID);

    my @bytes = split(//, $ASCII_command);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $receive_ID, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "TR" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    #print "<- ".join(',',@response)."\n";
    foreach my $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }

    #print "<- ".join('',@response)."\n";

    return (0,join('',@response));

}


=head2 stac_send_commad

    ($stat,$receive_ID) = stac_send_commad($ASCII_command);

    e.g. ($status,$receive_ID) = stac_send_commad('SA001de');


Transmits the string $data on the CAN to STAC controller

returns status and answer ID.

=cut

sub stac_send_commad {
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = 0x10;   
    my $receive_ID = 0x110;   

    $ASCII_command = sprintf("%s",$ASCII_command);
    #printf( "-> 0x%02x $ASCII_command\n",$send_ID);

    my @bytes = split(//, $ASCII_command);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TR" );
    return ($status,$receive_ID);

}



=head2 stac_check_response

 $status = stac_check_response($PPTstatus,$PPTresult);

if $PPTstatus < 0, set error string and return -1.
if $result not 'done' set error string and return -2.

=cut

sub stac_check_response{
    my $PPTstatus = shift;
    my $PPTresult = shift;

    if ($PPTstatus<0){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -1;

    }
    if ($PPTresult !~ m/^done/){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -2;

    }

    return 0;

}

1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



