package tsg4_trg;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    trg_send_commad
    trg_send_commad_wait_response
    trg_bootloader_mode
    trg_get_firmware
    trg_get_HW_id
    trg_write_SN
    trg_write_TST
    trg_write_CAL
	trg_get_INFO
	trg_set_amp
	trg_set_DAC
	trg_set_coupling
	trg_set_trigger
	trg_read_DAC_offset
	trg_write_DAC_offset
	trg_lock_display
	trg_unlock_display

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

TRIGGER control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 trg_write_DAC_offset

    $status = trg_write_DAC_offset($TRGnumber,$input,$level,$offset);

    e.g. $status = trg_write_DAC_offset(1,2,'H',-3);
	
	$input = 1 to 4
	$level = H or L (for higher or lower limit)
	$offset = -100 to 100 in LSB (1 LSB ~ 10mV)

sets DAC offset correction for input.

=cut

sub trg_write_DAC_offset {
    my $TRGnumber = shift;
    my $input = shift;
    my $level = shift;
    my $offset = shift;
    my ($value,$output,$response);
    
    if ($level eq 'H'){
    	$output = 'a';
    }
    else{
    	$output = 'b';
    }
	my $dac = 5-$input;	
	$value = pack("c",$offset);
    my $command = sprintf("Zw%d%s%s",$dac,$output,$value);	
	
   ($status,$response) = trg_send_commad_wait_response($TRGnumber,$command);
    
    return $status;
    
}

=head2 trg_read_DAC_offset

    ($status,$offset) = trg_read_DAC_offset($TRGnumber,$input,$level);

    e.g. ($status,-11) = trg_read_DAC_offset(1,2,'H');
	
	$input = 1 to 4
	$level = H or L (for higher or lower limit)

returns DAC offset correction value in LSB (1 LSB ~ 10mV).

=cut

sub trg_read_DAC_offset {
    my $TRGnumber = shift;
    my $input = shift;
    my $level = shift;
    my ($offset,$output,$response);
    
    if ($level eq 'H'){
    	$output = 'a';
    }
    else{
    	$output = 'b';
    }
	my $dac = 5-$input;	
    my $command = sprintf("Zr%d%s",$dac,$output);
	
    ($status,$response) = trg_send_commad_wait_response($TRGnumber,$command);
    $offset = unpack("c", $response); 
    
    return ($status,$offset);
    
}



=head2 trg_set_amp

    $status = trg_set_amp($TRGnumber,$input,$factor);

    e.g. $status = trg_set_amp(1,2,10);
	
	$input = 1 to 4
	$factor = 0.1 or 1 or 10

sets amplifier for input.

=cut

sub trg_set_amp {
    my $TRGnumber = shift;
    my $input = shift;
    my $factor = shift;
    my $value;
	
	if ($factor<1){
		$factor = 0; # 0.1
	}
	elsif ($factor>1){
		$factor = 2; # 10
	}
	else{
		$factor = 1; # 1
	}
		
    my $command = sprintf("A%d%d",$input,$factor);
	
    ($status,$value) = trg_send_commad_wait_response($TRGnumber,$command);
    
    return ($status);
    
}

=head2 trg_set_DAC

    $status = trg_set_DAC($TRGnumber,$input,$level,$limit);

    e.g. $status = trg_set_DAC(1,2,'H',9.5);
	
	$input = 1 to 4
	$level = H or L (for higher or lower limit)
	$limit = -10 to 10 V in 10mV step

sets DAC limits for input.

=cut

sub trg_set_DAC {
    my $TRGnumber = shift;
    my $input = shift;
    my $level = shift;
    my $limit = shift;
    my $value;

    #convert value to ascii string which represents the hex value for $limit (signed 16 bit)
    my $hexstring = unpack("H*",pack("s*",$limit*100));
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }


    my $command = sprintf("D%d%s%s",$input,$level,join('',reverse(@bytes)));

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,$command);

    return ($status);
    
}


=head2 trg_set_coupling

    $status = trg_set_coupling($TRGnumber,$output,$input_aref);

    e.g. $status = trg_set_coupling(1,2,[1,3]); # couple output 2 with input 1 and input 3
	
	$output = 1 to 8
	$input_aref = reference to list of inputs (1 to 4)

sets amplifier for input.

=cut

sub trg_set_coupling {
    my $TRGnumber = shift;
    my $output = shift;
    my $input_aref = shift;
    my ($value,$coupling);
	$coupling = 0;
	
	# set bit for input
    foreach my $input (@$input_aref)
	{
		$coupling += 2**($input-1);
    }	
		
    my $command = sprintf("K%d%s",$output,chr($coupling));

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,$command);
    
    return ($status);
    
}


=head2 trg_set_trigger

    $status = trg_set_trigger($TRGnumber,$output,$state,$slope,$hold,$coupling);

    e.g. $status = trg_set_trigger(1,2,1,1,0,1); # output 2 on, positive slope, no hold, OR coupling with inputs
	
	$output = 1 to 8
	$state    = 0 or 1 (off / on)
	$slope    = 0 or 1 (negative / positive)
	$hold     = 0 or 1 (no hold / hold)
	$coupling = 0 or 1 (AND / OR)

sets amplifier for input.

=cut

sub trg_set_trigger {
    my $TRGnumber = shift;
    my $output = shift;
    my $state = shift;
    my $slope = shift;
    my $hold = shift;
    my $coupling = shift;
    my ($value,$triggering);
	
	# set bit for value
	$triggering = $state*8 + $slope*4 + $hold*2 + $coupling*1;

    my $command = sprintf("O%d%s",$output,chr($triggering));

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,$command);
    
    return ($status);
    
}


=head2 trg_lock_display

    ($status) = trg_lock_display($TRGnumber);

    e.g. (0) = trg_lock_display(1);

lock display on TRIGGER card to avoid wait times due to display update.

returns status.

=cut

sub trg_lock_display {
    my $TRGnumber = shift;
    my $value;

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,'C99');
    
    return ($status);
    
}

=head2 trg_unlock_display

    ($status) = trg_unlock_display($TRGnumber);

    e.g. (0) = trg_unlock_display(1);

unlock display on TRIGGER card.

returns status.

=cut

sub trg_unlock_display {
    my $TRGnumber = shift;
    my $value;

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,'C00');
    
    return ($status);
    
}


=head2 trg_write_SN

    $status = trg_write_SN($TRGnumber,$serial_number);

    e.g. $status = trg_write_SN(1,'999D0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub trg_write_SN {
    my $TRGnumber = shift;
    my $SN = shift;

    $status = trg_write_EE($TRGnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 trg_write_TST

    $status = trg_write_TST($TRGnumber,$TST_date);

    e.g. $status = trg_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub trg_write_TST {
    my $TRGnumber = shift;
    my $TST_date = shift;

    $status = trg_write_EE($TRGnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 trg_write_CAL

    $status = trg_write_CAL($TRGnumber,$CAL_date);

    e.g. $status = trg_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub trg_write_CAL {
    my $TRGnumber = shift;
    my $CAL_date = shift;

    $status = trg_write_EE($TRGnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 trg_bootloader_mode

    $status = trg_bootloader_mode($TRGnumber);

    e.g. $status = trg_bootloader_mode(1);

sets TRG scanner card to bootloader mode for firmware update

returns status.

=cut

sub trg_bootloader_mode {
    my $TRGnumber = shift;
    my $value;

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 trg_get_firmware

    ($status, $firmware) = trg_get_firmware($TRGnumber);

    e.g. (0,'Ver 1.0') = trg_get_firmware(1);

reads firmware version from TRIGGER card

returns status.

=cut

sub trg_get_firmware {
    my $TRGnumber = shift;
    my $value;

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 trg_get_HW_id

    ($status, $HW_ID) = trg_get_HW_id($TRGnumber);

    e.g. (0,'999D0042') = trg_get_HW_id(1);

reads hardware ID from TRIGGER card

returns status.

=cut

sub trg_get_HW_id {
    my $TRGnumber = shift;
    my $value;

    ($status,$value) = trg_get_INFO($TRGnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 trg_get_INFO

    ($status, $INFO) = trg_get_INFO($TRGnumber,$keyword);

    e.g. (0,'999D0042') = trg_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from TRIGGER card

returns status.

=cut

sub trg_get_INFO {
    my $TRGnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = trg_send_commad_wait_response($TRGnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 trg_write_EE not exported

    $status = trg_write_EE($TRGnumber,$EEslot,$text);

    e.g. $status = trg_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub trg_write_EE {
    my $TRGnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = trg_send_commad($TRGnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "TRG_$TRGnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 trg_send_commad_wait_response

    ($stat,$ret) = trg_send_commad_wait_response($TRGnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to TRIGGER card

returns status and answer string as ASCII.

=cut

sub trg_send_commad_wait_response {
    my $TRGnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;

    my $send_ID = TRIGGER_base_address +(($TRGnumber - 1) * 2);   
    
    $ASCII_command = sprintf("Y%d%s",$TRGnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "TRG_$TRGnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 trg_send_commad

    ($stat,$receive_ID) = trg_send_commad($TRGnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = trg_send_commad(3,'?00');

Transmits the string $data on the CAN to TRIGGER card

returns status and answer ID.

=cut

sub trg_send_commad {
    my $TRGnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = TRIGGER_base_address +(($TRGnumber - 1) * 2);   
    
    $ASCII_command = sprintf("Y%d%s",$TRGnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TRG_$TRGnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



