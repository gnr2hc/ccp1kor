package tsg4_sq;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    sq_bootloader_mode
    sq_connect
    sq_connect_via
    sq_disconnect
    sq_disconnect_via
    sq_get_counters
    sq_get_firmware
    sq_get_HW_id
    sq_get_INFO
    sq_lock_display
    sq_LV124
    sq_microcut
    sq_reset_counter
    sq_send_commad
    sq_send_commad_wait_response
    sq_set_delay
    sq_set_fault_mode
    sq_set_firing_mode
    sq_set_resistance
    sq_set_threshold
    sq_unlock_display
    sq_write_CAL
    sq_write_name
    sq_write_SN
    sq_write_TST

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

Control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 sq_reset_counter

    $status = sq_reset_counter($SQnumber,$counter);

    e.g. $status = sq_reset_counter(3,1);

   $counter 0..4
   0 - ALL
   1 - $Tim0 - gate closed counter 
   2 - $Int0 - fire counter integrator (integrator threshold exceeded)
   3 - $Int1 - fire counter (threshold exceeded)
   4 - $Int2 - event trigger

resets counter on squib card

returns status.

=cut

sub sq_reset_counter {
    my $SQnumber = shift;
    my $counter = shift;
    my $command;

    $command = sprintf("R%03d",$counter + 2);
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);

    return ($status);

}



=head2 sq_set_resistance

    $status = sq_set_resistance($SQnumber,$resistance);

    e.g. $status = sq_set_resistance(3,4.7);

    $resistance between 0 .. 99.9 Ohm step 0.1 Ohm

    requires 'Z001' called once before

sets resistance on squib decade

returns status.

=cut

sub sq_set_resistance {
    my $SQnumber = shift;
    my $resistance = shift;

    my $command = sprintf("V%03d",$resistance*10);

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}


=head2 sq_set_threshold

    $status = sq_set_threshold($SQnumber,$mode,$threshold);

    e.g. $status = sq_set_threshold(3,'current',1.7);

    $mode 'current' or 'integrator'
    $threshold between 0 .. 4 Ampers step 0.01 Ampers 

sets threshold on squib decade for sq_set_fault_mode (integrator) and sq_set_firing_mode (current)

returns status.

=cut

sub sq_set_threshold {
    my $SQnumber = shift;
    my $mode = shift;
    my $threshold = shift;
    my $command;

    if($mode eq 'integrator'){
        $command = sprintf("D%03d",$threshold*100); 
    }
    elsif($mode eq 'current'){
        $command = sprintf("E%03d",$threshold*100);
    }
    else{
    	return(-1);
    }
    
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}

=head2 sq_set_delay

    $status = sq_set_delay($SQnumber,$delay);

    e.g. $status = sq_set_delay(3,1.7);

    $delay between 0 .. 25 millisec step 0.1 millisec 

sets delay on squib decade for sq_set_fault_mode

returns status.

=cut

sub sq_set_delay {
    my $SQnumber = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("G%03d",$delay*10);
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}


=head2 sq_set_fault_mode

    $status = sq_set_fault_mode($SQnumber,$mode,$fault_type);

    e.g. $status = sq_set_fault_mode(3,'time',1);

    $mode 'event', 'time' or 'integrator'
 
    $fault_type between 0 .. 6 

    0 - no fault
    1 - interruption
    2 - short
    3 - SQ- to ref1
    4 - SQ+ to ref1
    5 - SQ- to ref2
    5 - SQ+ to ref2

sets fault simualtion mode on squib decade (activated by firing pulse from ECU on squib line)

returns status.

=cut

sub sq_set_fault_mode {
    my $SQnumber = shift;
    my $mode = shift;
    my $fault_type = shift;
    my $command;
    
    if ($fault_type != 0){
	    if($mode eq 'integrator'){
	        $fault_type = $fault_type;
	    }
	    elsif($mode eq 'time'){
	        $fault_type = $fault_type+100;
	    }
	    elsif($mode eq 'event'){
	        $fault_type = $fault_type+200;
	    }
	    else{
	        return(-1);
	    }
    }

    $command = sprintf("F%03d",$fault_type);
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}


=head2 sq_set_firing_mode

    $status = sq_set_firing_mode($SQnumber,$firing_mode);

    e.g. $status = sq_set_firing_mode(3,4);

    $firing_mode between 0 .. 18 

         0 = no simulation
         1 = lead free squib then previous value
         2 = lead free squib then interruption
         3 = lead free squib then short
         4 = lead free squib then SQ- to ref1
         5 = lead free squib then SQ+ to ref1 
         6 = lead free squib then SQ- to ref2 
         7 = lead free squib then SQ+ to ref2 
         8 = 10sec interruption
         9 = 1ms   interruption
        10 = 100us interruption
        11 = 1us   interruption 1ms pause with 4 sec cycle
        12 = 100us interruption 1ms pause with 4 sec cycle
        13 = testmode - fixed signal
        14 = run download buffer
        15 = run temp buffer
        16 = copy current values to temp buffer
        17 = switch off randomize
        18 = switch on randomize
        
sets firing mode (squib simulation) on squib decade (activated by firing pulse from ECU on squib line)

=cut

sub sq_set_firing_mode {
    my $SQnumber = shift;
    my $firing_mode = shift;
    
    my %firemodes=(
        0 => "000",     # no simulation
        1 => "001",     # lead free squib then previous value
        2 => "002",     # lead free squib then interruption
        3 => "003",     # lead free squib then short
        4 => "004",     # lead free squib then SQ- to ref1
        5 => "005",     # lead free squib then SQ+ to ref1 
        6 => "006",     # lead free squib then SQ- to ref2 
        7 => "007",     # lead free squib then SQ+ to ref2 
        8 => "100",     # 10sec interruption
        9 => "101",     # 1ms   interruption
        10 => "102",    # 100us interruption
        11 => "103",    # 1us   interruption 1ms pause with 4 sec cycle
        12 => "104",    # 100us interruption 1ms pause with 4 sec cycle
        13 => "900",    # testmode - fixed signal
        14 => "995",    # run download buffer
        15 => "996",    # run temp buffer
        16 => "997",    # copy current values to temp buffer
        17 => "998",    # switch off randomize
        18 => "999",    # switch on randomize
    );
    
    my $command = sprintf("S%03d",$firemodes{$firing_mode});
    
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}


=head2 sq_LV124

    $status = sq_LV124($SQnumber,$fault_type);

    e.g. $status = sq_LV124(3,4);

    $fault_type between 0 .. 5 

    0 - no fault
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on squib decade.

=cut

sub sq_LV124 {
    my $SQnumber = shift;
    my $fault_type = shift;
    
    my $command = sprintf("L%03d",$fault_type);
    
    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);
    
    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command,$timeout);
    
    return ($status);
    
}

=head2 sq_microcut

    $status = sq_microcut($SQnumber,$offtime_us);

    e.g. $status = sq_microcut(3,100);

    $offtime_us in microseconds

starts microcut (LV124) fault simulation on squib.

=cut

sub sq_microcut {
    my $SQnumber = shift;
    my $offtime_us = shift;

    my $timeout=int($offtime_us/1000)+1000;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s",join('',@bytes));

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command,$timeout);
    
    return ($status);
    
}

=head2 sq_connect

    $status = sq_connect($SQnumber);

    e.g. $status = sq_connect(3);

connects squib

returns status.

=cut

sub sq_connect {
    my $SQnumber = shift;

    my $command = "Z001";

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}

=head2 sq_disconnect

    $status = sq_disconnect($SQnumber);

    e.g. $status = sq_disconnect(3);

disconnects squib (open line)

returns status.

=cut

sub sq_disconnect {
    my $SQnumber = shift;

    my $command = "Z000";

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);
    
    return ($status);
    
}


=head2 sq_lock_display

    ($status) = sq_lock_display($SQnumber);

    e.g. (0) = sq_lock_display(3);

lock display on SQUIBT card to avoid wait times due to display update.

returns status.

=cut

sub sq_lock_display {
    my $SQnumber = shift;
    my $value;

    ($status,$value) = sq_send_commad_wait_response($SQnumber,'C99');
    
    return ($status);
    
}

=head2 sq_unlock_display

    ($status) = sq_unlock_display($SQnumber);

    e.g. (0) = sq_unlock_display(3);

unlock display on SQUIBT card.

returns status.

=cut

sub sq_unlock_display {
    my $SQnumber = shift;
    my $value;

    ($status,$value) = sq_send_commad_wait_response($SQnumber,'C00');
    
    return ($status);
    
}

=head2 sq_write_name

    $status = sq_write_name($SQnumber,$name);

    e.g. $status = sq_write_name(3,'AB1FD');

    $name length <= 8 

writes name to card to be displayed.

=cut

sub sq_write_name {
    my $SQnumber = shift;
    my $name = shift;
    my ($receive_ID);

    ($status,undef,$receive_ID) = sq_send_commad_wait_response($SQnumber,'N');

#    printf( "-> 0x%02x $name\n",$receive_ID-1);
    
    my @bytes = split(//, $name);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(5);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout );
    $status = tsg4_check_CAN_status( $CANstatus, "SQ_$SQnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

=head2 sq_write_SN

    $status = sq_write_SN($SQnumber,$serial_number);

    e.g. $status = sq_write_SN(3,'999Z0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub sq_write_SN {
    my $SQnumber = shift;
    my $SN = shift;

    $status = sq_write_EE($SQnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 sq_write_TST

    $status = sq_write_TST($SQnumber,$TST_date);

    e.g. $status = sq_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy

writes test date to card to be displayed.

=cut

sub sq_write_TST {
    my $SQnumber = shift;
    my $TST_date = shift;

    $status = sq_write_EE($SQnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 sq_write_CAL

    $status = sq_write_CAL($SQnumber,$CAL_date);

    e.g. $status = sq_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy

writes calibration date to card to be displayed.

=cut

sub sq_write_CAL {
    my $SQnumber = shift;
    my $CAL_date = shift;

    $status = sq_write_EE($SQnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}

=head2 sq_get_firmware

    ($status, $firmware) = sq_get_firmware($SQnumber);

    e.g. (0,'Ver 1.0') = sq_get_firmware(3);

reads firmware version from squib card

returns status.

=cut

sub sq_get_firmware {
    my $SQnumber = shift;
    my $value;

    ($status,$value) = sq_send_commad_wait_response($SQnumber,'?010');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 sq_get_HW_id

    ($status, $HW_ID) = sq_get_HW_id($SQnumber);

    e.g. (0,'999Z0042') = sq_get_HW_id(3);

reads hardware ID from squib card

returns status.

=cut

sub sq_get_HW_id {
    my $SQnumber = shift;
    my $value;

    ($status,$value) = sq_get_INFO($SQnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 sq_get_counters

    ($status, $Tim0, $Int0, $Int1, $Int2) = sq_get_counters($SQnumber);

    e.g. (0,) = sq_get_counters(3);
    
    $Tim0 - gate closed counter 
    $Int0 - fire counter integrator (integrator threshold exceeded)
    $Int1 - fire counter (threshold exceeded)
    $Int2 - event trigger

reads all counters from SQUIB card

returns status.

=cut

sub sq_get_counters {
    my $SQnumber = shift;
    my $value;
    my ($Tim0, $Int0, $Int1, $Int2);

    ($status,$Tim0) = sq_send_commad_wait_response($SQnumber,"?019");
    $Tim0 =~ s/\s//g;
    ($status,$Int0) = sq_send_commad_wait_response($SQnumber,"?020");
    $Int0 =~ s/\s//g;
    ($status,$value) = sq_send_commad_wait_response($SQnumber,"?021");
    $value =~ m/^(\d+)\s+(\d+)/;
    $Int1 = $1;
    $Int2 = $2;

#    print("counters $Tim0, $Int0, $Int1, $Int2\n");
    return ($status,$Tim0, $Int0, $Int1, $Int2);
    
}

=head2 sq_get_INFO

    ($status, $INFO) = sq_get_INFO($SQnumber,$keyword);

    e.g. (0,'999Z0042') = sq_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from SQUIBT card

returns status.

=cut

sub sq_get_INFO {
    my $SQnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%03d",$keyword);

    ($status,$value) = sq_send_commad_wait_response($SQnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 sq_bootloader_mode

    $status = sq_bootloader_mode($SQnumber);

    e.g. $status = sq_bootloader_mode(1);

sets squib card to bootloader mode for firmware update

returns status.

=cut

sub sq_bootloader_mode {
    my $SQnumber = shift;
    my $value;

    ($status,$value) = sq_send_commad_wait_response($SQnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}

=head2 sq_connect_via

    $status = sq_connect_via($SQnumber,$terminal,$via);

    e.g. $status = sq_connect_via(3,'+',1); # connect SQ+ to ref1

connect squib terminal to reference line

returns status.

=cut

sub sq_connect_via {
    my $SQnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2*$via;
    }
    elsif ($terminal eq "-"){
        if ($via>1){
            $command=3;
        }
        else{
            $command=1;
        }
    }
    else{return (-1);}

# 001 ZK- Bezug 1
# 002 ZK+ Bezug 1
# 003 ZK- Bezug 2
# 004 ZK+ Bezug 2

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,'B00'.$command);
#    print("sq_connect_via ($terminal $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 sq_disconnect_via

    $status = sq_disconnect_via($SQnumber,$terminal,$via);

    e.g. $status = sq_disconnect_via(3,'+',1); # disconnect SQ+ from ref1

disconnect squib terminal from reference line

returns status.

=cut

sub sq_disconnect_via {
    my $SQnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2*$via;
    }
    elsif ($terminal eq "-"){
        if ($via>1){
            $command=3;
        }
        else{
            $command=1;
        }
    }
    else{return (-1);}

# 001 ZK- Bezug 1
# 002 ZK+ Bezug 1
# 003 ZK- Bezug 2
# 004 ZK+ Bezug 2

    ($status,$receive_ID) = sq_send_commad_wait_response($SQnumber,'B000');
#    print("sq_disconnect_via ($terminal $via -> $command) $status\n");
    
    return ($status);
    
}


=head2 sq_write_EE not exported

    $status = sq_write_EE($SQnumber,$EEslot,$text);

    e.g. $status = sq_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub sq_write_EE {
    my $SQnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,undef,$receive_ID) = sq_send_commad_wait_response($SQnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "SQ_$SQnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}
################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 sq_send_commad_wait_response

    ($stat,$ret,$receive_ID) = sq_send_commad_wait_response($SQnumber,$ASCII_command,[$timeout]);

    $timeout is optional, default is $MAXtimeout

Transmits the string $data on the CAN to squib decade

returns status and answer string as ASCII.

=cut

sub sq_send_commad_wait_response {
    my $SQnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($byte,$data_aref);

    my $send_ID = SQ_base_address +(($SQnumber - 1) * 2);   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("Z%02d%s",$SQnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "SQ_$SQnumber" );
        return ($status,'error',$receive_ID);
    }


    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response),$receive_ID);
    
}


=head2 sq_send_commad

    ($stat,$receive_ID) = sq_send_commad($SQnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = sq_send_commad(3,'V470');

Transmits the string $data on the CAN to squib decade

returns status and answer ID.

=cut

sub sq_send_commad {
    my $SQnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = SQ_base_address +(($SQnumber - 1) * 2);   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("Z%02d%s",$SQnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "SQ_$SQnumber" );
    return ($status,$receive_ID);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



