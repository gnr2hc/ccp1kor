package tsg4_lct64;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    lct_send_commad
    lct_send_commad_wait_response
    lct_get_firmware
    lct_get_HW_id
    lct_write_SN
    lct_write_TST
    lct_write_CAL
    lct_get_INFO
    lct_get_FPGA_firmware
    lct_get_FPGA_data
    lct_enable_trigger
    lct_disable_trigger
    lct_enable_channel
    lct_read_values
    lct_invoke_trigger
    lct_configure_trigger
    lct_reset_FPGAandFIFO
    lct_reset_FPGA_only
    lct_get_error

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;
my %enabled_channels;
my @error_text=();

use constant LCT_base_address => 0x640;

############################################################################################################

=head1 DESCRIPTION

LCT64 control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 lct_write_SN

    $status = lct_write_SN($LCTnumber,$serial_number);

    e.g. $status = lct_write_SN(1,'999A0042');

    $serial_number length <= 8 

writes serial number to LCT64.

=cut

sub lct_write_SN {
    my $LCTnumber = shift;
    my $SN = shift;

    $status = lct_write_EE($LCTnumber,$tsg4::EEmapping{'SN'},$SN);

    return ($status);

}

=head2 lct_write_TST

    $status = lct_write_TST($LCTnumber,$TST_date);

    e.g. $status = lct_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to LCT64.

=cut

sub lct_write_TST {
    my $LCTnumber = shift;
    my $TST_date = shift;

    $status = lct_write_EE($LCTnumber,$tsg4::EEmapping{'TST'},$TST_date);

    return ($status);

}

=head2 lct_write_CAL

    $status = lct_write_CAL($LCTnumber,$CAL_date);

    e.g. $status = lct_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to LCT64.

=cut

sub lct_write_CAL {
    my $LCTnumber = shift;
    my $CAL_date = shift;

    $status = lct_write_EE($LCTnumber,$tsg4::EEmapping{'CAL'},$CAL_date);

    return ($status);

}



=head2 lct_get_firmware

    ($status, $firmware) = lct_get_firmware($LCTnumber);

    e.g. (0,'Ver 1.0') = lct_get_firmware(1);

reads firmware version from LCT64

returns status.

=cut

sub lct_get_firmware {
    my $LCTnumber = shift;
    my $value;

    ($status,$value) = lct_send_commad_wait_response($LCTnumber,'?14');
#    print("firmware $value\n");

    return ($status,$value);

}

=head2 lct_get_FPGA_firmware

    ($status, $firmware) = lct_get_FPGA_firmware($LCTnumber);

    e.g. (0,'Ver 1.0') = lct_get_FPGA_firmware(1);

reads FPGA firmware version from LCT64

returns status.

=cut

sub lct_get_FPGA_firmware {
    my $LCTnumber = shift;
    my $value;

    ($status,$value) = lct_send_commad_wait_response($LCTnumber,'?13');
#    print("FPGA firmware $value\n");

    return ($status,$value);

}

=head2 lct_get_FPGA_data

    ($status, $firmware) = lct_get_FPGA_data($LCTnumber);

    e.g. (0,'01000000') = lct_get_FPGA_data(1);

reads FPGA data from LCT64

returns status.

=cut

sub lct_get_FPGA_data {
    my $LCTnumber = shift;
    my $value;

    ($status,$value) = lct_send_commad_wait_response($LCTnumber,'?12');
#    print("FPGA data $value\n");

    return ($status,$value);

}


=head2 lct_reset_FPGAandFIFO

    $status = lct_reset_FPGAandFIFO($LCTnumber);

    e.g. 0 = lct_reset_FPGAandFIFO(1);

resets FPGA and FIFO in LCT64

returns status.

=cut

sub lct_reset_FPGAandFIFO {
    my $LCTnumber = shift;
    my $response;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'SR0815');

    return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;

}

=head2 lct_reset_FPGA_only

    $status = lct_reset_FPGA_only($LCTnumber);

    e.g. 0 = lct_reset_FPGA_only(1);

resets FPGA but not FIFO in LCT64 (data can be read out later)

returns status.

=cut

sub lct_reset_FPGA_only {
    my $LCTnumber = shift;
    my $response;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'SR4711');
 
   return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;

}

=head2 lct_configure_trigger

    $status = lct_configure_trigger( $LCTnumber, $trigger_edge_in [, $trigger_out] );

    $trigger_edge_in : 'p' = positive, 'n' = negative
    
    $trigger_out : DEFAULT = 1
    0 - Trigger Out Disabled
    1 - Trigger Out = Trigger In 
    2 - Trigger Out = not Trigger In
    3 - Trigger Out = OR (all enabled channels)
    4 - Trigger Out = not (OR (all enabled channels))

    e.g. 0 = lct_configure_trigger(1, 'n', 0);

configures trigger on LCT64

returns status.

=cut

sub lct_configure_trigger {
    my $LCTnumber = shift;
    my $edge = shift;
    my $trigger_out = shift;
    my $response;

    $trigger_out = 1 unless defined $trigger_out;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'SE'.$edge);
    tsg4_wait_ms(10);
    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'O'.$trigger_out);
    tsg4_wait_ms(10);

    return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;
}

=head2 lct_enable_trigger

    $status = lct_enable_trigger($LCTnumber);

    e.g. 0 = lct_enable_trigger(1);

enables trigger on LCT64

returns status.

=cut

sub lct_enable_trigger {
    my $LCTnumber = shift;
    my $response;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'STe');
    
    return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;
}

=head2 lct_invoke_trigger

    $status = lct_invoke_trigger($LCTnumber);

    e.g. 0 = lct_invoke_trigger(1);

invokes SW trigger on LCT64

returns status.

=cut

sub lct_invoke_trigger {
    my $LCTnumber = shift;
    my $response;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'Go');

    return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;

}

=head2 lct_disable_trigger

    $status = lct_disable_trigger($LCTnumber);

    e.g. 0 = lct_disable_trigger(1);

disables trigger on LCT64

returns status.

=cut

sub lct_disable_trigger {
    my $LCTnumber = shift;
    my $response;

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,'STa');

    return $status if ($status < 0);
    $status = lct_check_response($response);

    return $status;

}


=head2 lct_enable_channel

    $status = lct_enable_channel($LCTnumber,$channel_aref);
    
    $channel_aref may contain numbers from 1 to 90

    e.g. 0 = lct_enable_channel(1,[1,5,18,37]);

enables given channels on LCT64, disables all others

returns status.

=cut

sub lct_enable_channel {
    my $LCTnumber = shift;
    my $channel_aref = shift;
    my $value;
    my ($ENM0,$ENM1,$ENM2,$ENM3,$ENM4,$ENM5);

	$ENM0=$ENM1=$ENM2=$ENM3=$ENM4=$ENM5=0;

	%enabled_channels =();
	foreach my $ch (@$channel_aref){
		$enabled_channels{$ch}=undef;
	}
#   printf("enabled channels: %s\n",join(' ',sort (keys %enabled_channels)));


	foreach my $ch_nr (sort (keys %enabled_channels)){
		$ch_nr--; # offset correction for bitposition
		if ($ch_nr < 16){
			$ENM0 += 1<<$ch_nr;
#			printf ("0 %016b $ch_nr\n",$ENM0);
		}
		elsif ($ch_nr < 32){
			$ENM1 += 1<<($ch_nr-16);
#			printf ("1 %016b $ch_nr\n",$ENM1);
		}
		elsif ($ch_nr < 48){
			$ENM2 += 1<<($ch_nr-32);
#			printf ("1 %016b $ch_nr\n",$ENM2);
		}
		elsif ($ch_nr < 64){
			$ENM3 += 1<<($ch_nr-48);
#			printf ("1 %016b $ch_nr\n",$ENM3);
		}
		elsif ($ch_nr < 80){
			$ENM4 += 1<<($ch_nr-64);
#			printf ("1 %016b $ch_nr\n",$ENM4);
		}
		elsif ($ch_nr < 90){
			$ENM5 += 1<<($ch_nr-80);
#			printf ("1 %016b $ch_nr\n",$ENM5);
		}
		else{return -1;}
	}

	$status = ch_mask_enable($LCTnumber,0,$ENM0);
    return $status if ($status < 0);
	$status = ch_mask_enable($LCTnumber,1,$ENM1);
    return $status if ($status < 0);
	$status = ch_mask_enable($LCTnumber,2,$ENM2);
    return $status if ($status < 0);
	$status = ch_mask_enable($LCTnumber,3,$ENM3);
    return $status if ($status < 0);
	$status = ch_mask_enable($LCTnumber,4,$ENM4);
    return $status if ($status < 0);
	$status = ch_mask_enable($LCTnumber,5,$ENM5);

    return ($status);

}



=head2 ch_mask_enable not exported

    $status = ch_mask_enable($LCTnumber,$bank,$mask);

    $mask 16 bit mask for channels
    $bank 0..5

    e.g. 0 = ch_mask_enable(1,3,0b111);

enables single channel mask on LCT64

returns status.

=cut

sub ch_mask_enable{

	my $LCTnumber = shift;
	my $bank = shift;
	my $mask = shift;
	my $response;

	#convert value to ascii string which represents the hex value for enable mask
    my $hexstring = sprintf("%04X",$mask);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    my $en_hex = sprintf("%s",join('',@bytes));

    ($status,$response) = lct_send_commad_wait_response($LCTnumber,"E".$bank."$en_hex");

    return $status if ($status < 0);
    $status = lct_check_response($response);

   	return $status;

}




=head2 lct_read_values

    ($status, $data_ref) = lct_read_values($LCTnumber [, $channel_mapping_ref]);

	$data_ref = { time_in_us => {channel_a => value_a, channel_b => value_b} }
	$channel_mapping_ref = {channel_ number => channel_name}
	
    e.g. (0,{16 => {1 => 1},23 => {1 => 0} ) = lct_read_values(1);

    e.g. (0,{16 => {'AB1FD' => 1},23 => {'AB1FD' => 0} ) = lct_read_values(1,{1 => 'AB1FD'});

reads all stored values from LCT64

returns status.

=cut

sub lct_read_values {
    my $LCTnumber = shift;
    my $channel_mapping_ref = shift;
    my $value;
    my %data;
    %data=();
    $status = 0;

# store in first run bitarrays %bitlist = time => [page0,1,2]
# then replace undef values with values from previous time
# then process data with channel filters

my %bitlist = ();
 my @old = ('000000000000000000000000000000','000000000000000000000000000000','000000000000000000000000000000');

	while ($status > -1){
	    ($status,$value) = lct_send_commad_wait_response($LCTnumber,'R1','RAW');
	    my $time = sprintf ("%d", $$value[0]*0x1000000+$$value[1]*0x10000+$$value[2]*0x100+$$value[3] );

	    my $bitmask = sprintf ("%032b", $$value[4]*0x1000000+$$value[5]*0x10000+$$value[6]*0x100+$$value[7] );

		if ( $time == 0){
#			print "end of data\n";
		    last; # end loop if timestamp 0 is found (end of data)
		}
		else{
		    my @bits = split(//,$bitmask);
		    my $page = shift(@bits);
		    $page .= shift(@bits);
		    $page = oct('0b'.$page);
			# page 0 ch 1..30, page 1 ch 31..60, page 2 ch 61..90
			@bits = reverse(@bits);

			$bitlist{$time/1000}[$page]= join('',@bits);
		}
	}

    my @timestamps=sort { $a <=> $b } keys %bitlist;

    foreach my $time (@timestamps){
	    #replace undef values with previous values
    	foreach my $index (0..2){
	    	if ( defined ($bitlist{$time}[$index]) ){
	    		$old[$index]=$bitlist{$time}[$index]
	    	}
	    	else{
	    		$bitlist{$time}[$index]=$old[$index]
	    	}
    	}

    	my $allbits = join('',@{$bitlist{$time}});
    	my @SQbits = split(//,$allbits);
    	#process data with channel filters
	    #loop over all measured bits amd extract enabled bits only
	    for (my $count = 1; $count<scalar(@SQbits)+1;$count++){
	    	#if this bit was enabled, store value
	    	if ( exists $enabled_channels{$count} ){
	    		my $channel_name;
	    		if ( exists $$channel_mapping_ref{$count} ) { $channel_name = $$channel_mapping_ref{$count};}
	    		else {$channel_name = $count;}

    			# $SQbits[0] = chanel1
	    		$data{$time}{$channel_name} = $SQbits[$count-1];
	    	}
	    }
    }

    return ($status,\%data);

}


=head2 lct_get_HW_id

    ($status, $HW_ID) = lct_get_HW_id($LCTnumber);

    e.g. (0,'999D0042') = lct_get_HW_id(1);

reads hardware ID from LCT64

returns status.

=cut

sub lct_get_HW_id {
    my $LCTnumber = shift;
    my $value;

    ($status,$value) = lct_get_INFO($LCTnumber,'SN');
#    print("HW ID $value\n");

    return ($status,$value);

}

=head2 lct_get_INFO

    ($status, $INFO) = lct_get_INFO($LCTnumber,$keyword);

    e.g. (0,'999D0042') = lct_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from LCT64

returns status.

=cut

sub lct_get_INFO {
    my $LCTnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = lct_send_commad_wait_response($LCTnumber,$command);
#    print("INFO ($keyword) $value\n");

    return ($status,$value);

}

=head2 lct_write_EE not exported

    $status = lct_write_EE($LCTnumber,$EEslot,$text);

    e.g. $status = lct_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in LCT64.

=cut

sub lct_write_EE {
    my $LCTnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID,$response);

    my $command = sprintf("#37%02d",$slot);

    ($status,$receive_ID) = lct_send_commad($LCTnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);

    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);
    tsg4_wait_ms(10);

    ($status,$response) = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);

    return $status if ($status < 0);

	foreach my $byte (@$response){
  		if ($byte == 0){
    		$byte = ""; #skip zero bytes
  		}
  		else{
    		$byte = chr($byte);
 		}
	}

    $status = lct_check_response(join('',@$response));

    tsg4_wait_ms(5);

    return ($status);

}

=head2 lct_get_error

    $errortext = lct_get_error();

return last errors and clear error

=cut

sub lct_get_error{

    my $ret=join(';',@error_text);
    @error_text=();
    return ($ret);
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 lct_send_commad_wait_response

    ($stat,$ret,$receive_ID) = lct_send_commad_wait_response($LCTnumber,$ASCII_command [,$mode, $timeout]);

    $timeout is optional, default is $MAXtimeout
    $mode = 'ASCII' or 'RAW' for returning data

Transmits the string $data on the CAN to LCT64

returns status and answer string as ASCII.

=cut

sub lct_send_commad_wait_response {
    my $LCTnumber = shift;
    my $ASCII_command = shift;
    my $mode = shift;
    my $timeout = shift;
    my ($byte,$data_aref,$CANstatus);
    $timeout = $MAXtimeout unless defined $timeout;
    $mode='ASCII' unless(defined $mode);

    my $send_ID = LCT_base_address +(($LCTnumber - 1) * 2);   

    $ASCII_command = sprintf("A%d%s",$LCTnumber-1,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);

    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    tsg4_wait_ms(2);

    $status = lct_check_CAN_status( $CANstatus );
    if ($status < 0){
        return ($status,'CAN_error',$receive_ID);
    }

    if ($mode ne 'RAW'){
	    my @response = @$data_aref;
	    foreach $byte (@response){
	        if ($byte == 0){
	            $byte = ""; #skip zero bytes
	        }
	        else{
	            $byte = chr($byte);
	        }
	    }

	    return (0,join('',@response),$receive_ID);
    }
    else{
        return (0,$data_aref,$receive_ID);

    }


}


=head2 lct_send_commad

    ($stat,$receive_ID) = lct_send_commad($LCTnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = lct_send_commad(1,'?00');

Transmits the string $data on the CAN to LCT64

returns status and answer ID.

=cut

sub lct_send_commad {
    my $LCTnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = LCT_base_address +(($LCTnumber - 1) * 2);   

    $ASCII_command = sprintf("A%d%s",$LCTnumber-1,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);

    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = lct_check_CAN_status( $CANstatus );
    return ($status,$send_ID+1);

}



sub lct_set_error{
    my $error_txt = shift;
    push (@error_text,$error_txt);
#    print"!!!: $error_txt\n";
}


sub lct_check_response{
    my $response = shift;    
    # CAN_error will be set by lct_send_commad_wait_response, so we already have an error text
    # LCT will acknowlegde all successful commands with 'done A'
    unless ($response =~ /done/ or $response eq 'CAN_error'){
    	lct_set_error ("negative response from LCT : $response");
    	return -1;
    }
    return 0;
}

=head2 lct_check_CAN_status

 $status = lct_check_CAN_status($result)

if result < 0, set error string and return -1.

=cut

sub lct_check_CAN_status{
    my $CANstatus = shift;

    if ($CANstatus<0){
      my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      lct_set_error( "CAN ($CANstatus): $CANerrortext");
      return -1

    }
    return 0;

}


1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



