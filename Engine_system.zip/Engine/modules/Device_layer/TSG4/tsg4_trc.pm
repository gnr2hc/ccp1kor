package tsg4_trc;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    trc_send_commad
    trc_send_commad_wait_response
    trc_reset
    trc_connect
    trc_connect_DVM
    trc_disconnect
    trc_disconnect_DVM
    trc_bootloader_mode
    trc_get_firmware
    trc_get_devices
    trc_get_HW_id
    trc_write_SN
    trc_write_TST
    trc_write_CAL
    trc_get_INFO

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

TRC scanner control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 trc_reset

    $status = trc_reset($TRCnumber);

    e.g. $status = trc_reset(3);

resets TRC scanner (TRCchannel 1 ..7 and DVMout)

returns status.

=cut

sub trc_reset {
    my $TRCnumber = shift;

    my $command = "R01";

    ($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
    
    return ($status);
    
}

=head2 trc_connect to be tested

    $status = trc_connect($TRCnumber, $TRCchannel, $MUXchannel);

    $TRCchannel 1..8
    $MUXchannel 1..7

    e.g. $status = trc_connect(3,7,5);
    this will connect 'T7.5+' to 'Out T+7' and 'T7.5-' to 'Out T-7'

Connects TRC scanner input $TRCchannel.$MUXchannel to output $TRCchannel. 
Only one MUXchannel can be connected to TRCchannel at same time.

	special case $TRCnumber=32 (trigger scanner):
	pins will be re-mapped since connector layout is different (two channels are coupled)
	trigger scanner range is TRCchannel 1..4 and MUXchannel 1..8

	      IN1              IN2               IN3               IN4   
	       |                |                 |                 |
	  |----+----|      |----+----|       |----+----|       |----+----|   
	  |         |      |         |       |         |       |         |
	T1.1-4    T2.1-4  T3.1-4    T4.1-4  T5.1-4    T6.1-4  T7.1-4    T8.1-4

returns status.

=cut

sub trc_connect {
    my $TRCnumber = shift;
    my $TRCchannel = shift;
    my $MUXchannel = shift;
	my $command;
	
	if ($TRCnumber==32){
		# re-mapping for TriggerScanner
		$TRCchannel = $TRCchannel*2;
		if ($MUXchannel > 4){
			$MUXchannel = $MUXchannel -4;
			$command = sprintf("S0.%d",$TRCchannel-1); # order inverted in firmware !
			($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
		}
		else{
			$TRCchannel--;
			$command = sprintf("S0.%d",$TRCchannel+1); # order inverted in firmware !
			($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
		}
	}

    $command = sprintf("S%d.%d",$MUXchannel,$TRCchannel); # order inverted in firmware !
    
    ($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
    
    return ($status);
    
}

=head2 trc_disconnect to be tested

    $status = trc_disconnect($TRCnumber, $TRCchannel);

    $TRCchannel 1..8

    e.g. $status = trc_disconnect(3,7);
    this will disconnect 'T7' from output

Disconnects TRC scanner input $TRCchannel from output $TRCchannel. 

	special case $TRCnumber=32 (trigger scanner):
	pins will be re-mapped since connector layout is different (two channels are coupled)
	trigger scanner range is TRCchannel 1..4 and MUXchannel 1..8

returns status.

=cut

sub trc_disconnect {
    my $TRCnumber = shift;
    my $TRCchannel = shift;
	my $command;

	if ($TRCnumber==32){
		# re-mapping for TriggerScanner and disconnect both channels
		$TRCchannel = $TRCchannel*2;
		$command = sprintf("S0.%d",$TRCchannel); # order inverted in firmware !
		($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
		$TRCchannel--;
		$command = sprintf("S0.%d",$TRCchannel); # order inverted in firmware !
		($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);

	}
	else{
		$command = sprintf("S0.%d",$TRCchannel); # order inverted in firmware !
		($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
	}
    
    return ($status);
    
}

=head2 trc_connect_DVM

    $status = trc_connect_DVM($TRCnumber, $TRCchannel);
    
    $TRCchannel 1..8

    e.g. $status = trc_connect_DVM(3,7);
    this will connect 'Out T+7' to 'DVM-Hi' and 'Out T-7' to 'DVM-Lo' 

Connects TRC scanner output $bank to output DVM. 
Used for routing of TRC channel to DVM, only one channel can be connected to DVM at same time.

returns status.

=cut

sub trc_connect_DVM {
    my $TRCnumber = shift;
    my $bank = shift;

    my $command = sprintf("D%d",$bank);

    ($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
    
    return ($status);
    
}

=head2 trc_disconnect_DVM

    $status = trc_disconnect_DVM($TRCnumber);

    e.g. $status = trc_disconnect_DVM(3);
    this will disconnect DVM output

Disconnects TRC scanner output from output DVM. 

returns status.

=cut

sub trc_disconnect_DVM {
    my $TRCnumber = shift;

    my $command = sprintf("D0");

    ($status,$receive_ID) = trc_send_commad_wait_response($TRCnumber,$command);
    
    return ($status);
    
}


=head2 trc_write_SN

    $status = trc_write_SN($TRCnumber,$serial_number);

    e.g. $status = trc_write_SN(3,'999D0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub trc_write_SN {
    my $TRCnumber = shift;
    my $SN = shift;

    $status = trc_write_EE($TRCnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 trc_write_TST

    $status = trc_write_TST($TRCnumber,$TST_date);

    e.g. $status = trc_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub trc_write_TST {
    my $TRCnumber = shift;
    my $TST_date = shift;

    $status = trc_write_EE($TRCnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 trc_write_CAL

    $status = trc_write_CAL($TRCnumber,$CAL_date);

    e.g. $status = trc_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub trc_write_CAL {
    my $TRCnumber = shift;
    my $CAL_date = shift;

    $status = trc_write_EE($TRCnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 trc_bootloader_mode

    $status = trc_bootloader_mode($TRCnumber);

    e.g. $status = trc_bootloader_mode(1);

sets TRC scanner card to bootloader mode for firmware update

returns status.

=cut

sub trc_bootloader_mode {
    my $TRCnumber = shift;
    my $value;

    ($status,$value) = trc_send_commad_wait_response($TRCnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 trc_get_firmware

    ($status, $firmware) = trc_get_firmware($TRCnumber);

    e.g. (0,'Ver 1.0') = trc_get_firmware(3);

reads firmware version from TRC scanner card

returns status.

=cut

sub trc_get_firmware {
    my $TRCnumber = shift;
    my $value;

    ($status,$value) = trc_send_commad_wait_response($TRCnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}


=head2 trc_get_devices

    ($status, $IDs_aref) = trc_get_devices();

    e.g. (0,[1,2,3,4]) = trc_get_devices();

returns reference to list of $TRCnumber from available TRC scanner cards, uses internally trc_get_firmware.

returns status.

=cut

sub trc_get_devices {
    my (@IDs,$FW,$device_status);
    @IDs=();
    $device_status=-1;

    foreach my $temp (1..8){
         ($status, $FW) = trc_get_firmware($temp);
         if ($FW ne ''){
            push(@IDs,$temp);
            $device_status = 0;
         }
    }
    
    return ($device_status,\@IDs);
    
}

=head2 trc_get_HW_id

    ($status, $HW_ID) = trc_get_HW_id($TRCnumber);

    e.g. (0,'999D0042') = trc_get_HW_id(3);

reads hardware ID from TRC scanner card

returns status.

=cut

sub trc_get_HW_id {
    my $TRCnumber = shift;
    my $value;

    ($status,$value) = trc_get_INFO($TRCnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 trc_get_INFO

    ($status, $INFO) = trc_get_INFO($TRCnumber,$keyword);

    e.g. (0,'999D0042') = trc_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from TRC scanner card

returns status.

=cut

sub trc_get_INFO {
    my $TRCnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = trc_send_commad_wait_response($TRCnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 trc_write_EE not exported

    $status = trc_write_EE($TRCnumber,$EEslot,$text);

    e.g. $status = trc_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub trc_write_EE {
    my $TRCnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = trc_send_commad($TRCnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "TRC_$TRCnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 trc_send_commad_wait_response

    ($stat,$ret) = trc_send_commad_wait_response($TRCnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to TRC scanner

returns status and answer string as ASCII.

=cut

sub trc_send_commad_wait_response {
    my $TRCnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;

    my $send_ID = TRC_base_address +(($TRCnumber - 1) * 2);   
    
    $ASCII_command = sprintf("T%02d%s",$TRCnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "TRC_$TRCnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 trc_send_commad

    ($stat,$receive_ID) = trc_send_commad($TRCnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = trc_send_commad(3,'?00');

Transmits the string $data on the CAN to TRC scanner

returns status and answer ID.

=cut

sub trc_send_commad {
    my $TRCnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = TRC_base_address +(($TRCnumber - 1) * 2);   
    
    $ASCII_command = sprintf("T%02d%s",$TRCnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TRC_$TRCnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



