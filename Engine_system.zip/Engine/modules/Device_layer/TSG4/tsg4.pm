# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2014  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package tsg4;

use strict;
use warnings;
use File::Basename;
use TSG4_FirmwareVersions;

my $addpath;

# todo: update docu of tsg4_detect_ ... with real return value example

#suppress 'Subroutine redefined' warning locally
local $SIG{__WARN__} = sub
{
    my $warning = shift;
    warn $warning unless $warning =~ /Subroutine .* redefined at/;
};

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use LIFT_simulation;
use TSG4CAN;

use constant UBAT_base_address => 0x010;
use constant VIA_base_address => 0x020;
use constant Kline_base_address => 0x040;
use constant CAN_base_address => 0x050;
use constant WL_base_address => 0x060;
use constant DIO_base_address => 0x070;
use constant Rdecade_base_address => 0x080;
use constant GenericSwitch_base_address => 0x090;
use constant SQ_base_address => 0x100;
use constant PAS_base_address => 0x180;
use constant BL_base_address => 0x1c0;
use constant DVM_base_address => 0x200;
use constant TRC_base_address => 0x240;
use constant RC_base_address => 0x700;
use constant TestRack_base_address => 0x710;
use constant PowerPrittTester_base_address => 0x720;
use constant TRIGGER_base_address => 0x280;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter);

our @EXPORT = qw(
	tsg4_start
    tsg4_init
    tsg4_exit
    tsg4_get_error
    tsg4_boot_init
    tsg4_boot_exit
    tsg4_bootloader_inactive_check
    tsg4_firmware_update
    tsg4_autodetect_cards
    tsg4_get_device_CANid
	tsg4_set_mode
	tsg4_latest_firmware
	tsg4_check_update_required
	tsg4_send_broadcast
	tsg4_reset_all

	tsg4_detect_BL
	tsg4_detect_CANFR
	tsg4_detect_DVM
	tsg4_detect_KLIN
	tsg4_detect_PAS
	tsg4_detect_RC
	tsg4_detect_RDEC
	tsg4_detect_REF
	tsg4_detect_SPDT
	tsg4_detect_SQ
	tsg4_detect_TRC
	tsg4_detect_TRG
	tsg4_detect_UBAT
	tsg4_detect_WL
	tsg4_detect_all_cards
	
	tsg4_get_CAN_HW_list
    tsg4_check_CAN_status
    tsg4_set_error
    tsg4_wait_ms
    
    tsg4_set_SIM_return_text

	UBAT_base_address
	VIA_base_address
	Kline_base_address
	CAN_base_address
	WL_base_address
	DIO_base_address
	Rdecade_base_address
	GenericSwitch_base_address
	SQ_base_address
	PAS_base_address
	BL_base_address
	DVM_base_address
	TRC_base_address
	RC_base_address
    TestRack_base_address
	PowerPrittTester_base_address
    TRIGGER_base_address
    
    %EEmapping
    $TSG4_CAN_initalized
);

our ($VERSION,$HEADER);

my $MAXtimeout = 200; # ms
my $ERASEtimeout = 5000; # ms
my $MSGdelay = 10; # ms
my $FRMdelay = 3; # ms inbetween frames for read or write
my @tsg4errors=();
my ($status,$canStatus,$value);
my $slots2scan;
my ($TSG4log,$console_print);
my $device_count = 0;

# mapping for EEslot usage
our %EEmapping = (
        'SN' => 2,
        'TST' => 0,
        'CAL' => 1,
        'FLB' => 12,
        'BSB' => 40,
    );

our $TSG4_CAN_initalized;

############################################################################################################

=head1 DESCRIPTION

Main control module for TSG4 family HW via CAN 

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 tsg4_start

    $stat = tsg4_start( [$logfile, $console_print] );

   e.g.  $stat = tsg4_start( );

   $logfile is optional, if not given or writeable, a logfile will be created at C:\temp\TSG4log.txt
   $console_print is optional, if 1 tsg4_log will print also to console, else only to log

initialize low level dlls. has to be called before any other function.

=cut

sub tsg4_start {
	$TSG4log = shift;
	$console_print = shift;
	$console_print = 0 unless (defined $console_print);
	unless (defined $TSG4log and -w $TSG4log){
		my $logfile = 'C:\temp\TSG4log.txt';
		open ($TSG4log,">",$logfile);
		$TSG4log->autoflush(1);
	}
    my $version;
    $version = tsg4can_getPMrevision();
#    print("PM $version\n");
    $version = tsg4can_getXSrevision();
#    print("XS $version\n");
    $version = tsg4can_getCWrevision();
#    print("CW $version\n");

    $canStatus = tsg4can_Start();
    $status = tsg4_check_CAN_status( $canStatus, "CANstart" );
    return $status;

}

=head2 tsg4_init

    $stat = tsg4_init( $canChannel, $serialNo );

   e.g.  $stat = tsg4_init( 1, 30679 );

Connnect to TSG4 HW family.

=cut

sub tsg4_init {

my ($canChannel, $sam, $sjw, $tseg1, $tseg2, $baudrate, $extmode, $extAddressing, $ecuID, $targetAddr, $dlcMode, $serialNo);
$sam = 1;
$sjw = 1;
$tseg1 = 10;
$tseg2 = 5;
$baudrate = 500000;
$extmode = 0;
$extAddressing = 0;
$ecuID = 0;
$targetAddr = 0;
$dlcMode = 0;


#$canChannel = 1;
#$serialNo = 30679;

$canChannel = shift;
$serialNo = shift;
#print"wrong Serialno $serialNo !\n" if ($serialNo < 3);


#    tsg4_wait_ms(10);
    $canStatus = tsg4can_InitHW( $canChannel, 0x100, $sam, $sjw, $tseg1, $tseg2, $baudrate, $extmode, $extAddressing, $ecuID, $targetAddr, $dlcMode, $serialNo );
    $status = tsg4_check_CAN_status( $canStatus, "CANinit" );
    return $status if ($status < 0);

#    tsg4_wait_ms(10);

    $status = tsg4can_ConfigurePorts( 0x0, 0x720 );
    $status = tsg4_check_CAN_status( $canStatus, "CANconfigure" );
    return $status if ($status < 0);

    tsg4_wait_ms(100);
    $TSG4_CAN_initalized = 1;

    return 0;
}


=head2 tsg4_exit

    $stat = tsg4_exit();

Disconnect from TSG4 family HW.

=cut

sub tsg4_exit {

    $canStatus = tsg4can_End();
    $status = tsg4_check_CAN_status( $canStatus, "CANexit" );
    $TSG4_CAN_initalized = 0;
    return $status;
}

=head2 tsg4_get_error

    $errortext = tsg4_get_error();

return last errors and clear error

=cut

sub tsg4_get_error{

    my $ret=join(";\n",@tsg4errors);
    @tsg4errors=();
    return ($ret);
}


=head2 tsg4_latest_firmware

    ($status, $FW_href) = tsg4_latest_firmware();

returns hash structure with latest firmware

  e.g.: $status = 0
  $FW_href = {
    'BL'    => 'FW_G0004',
    'CANFR' => 'FW_C0002',
    'DVM'   => 'FW_D0004',
    'KLIN'  => 'FW_K0003',
    'PAS'   => 'FW_P0004',
    'RC'    => 'FW_X0013',
    'REF'   => 'FW_B0002',
    'SQ'    => 'FW_Z0004',
    'TRC'   => 'FW_T0004',
    'TRG_A' => 'FW_Y0003', # ATMEL board
    'TRG_F' => 'FW_Y0021', # FPGA board
    'UBAT'  => 'FW_U0006',
    'WL'    => 'FW_L0007'
  };
  
The previously used method to read the actual firmware file names on N-drive has been replaced by using a dedicated TurboLIFT module (TSG4_FirmwareVersions.pm)
to avoid waiting times because of slow network.
However TSG4_FirmwareVersions.pm must be kept up-to-date manually now.

=cut

sub tsg4_latest_firmware {

    my $firmware_href = $TSG4_FirmwareVersions::latestFirmware_href;

    return (0, $firmware_href);
}



=head2 tsg4_check_update_required

 $true_false = tsg4_check_update_required($card_firmware,$latest_firmware)

returns 1 if newer firmware available, otherwise 0, -1 on error.

=cut


sub tsg4_check_update_required{
    my $card_firmware = shift;
    my $latest_firmware = shift;
    return 0 unless (defined $latest_firmware);

	$card_firmware =~ /^(FW_[A-Z])(\d+)$/;
	my $card_type = $1;
	my $card_nr = $2;

	$latest_firmware =~ /^(FW_[A-Z])(\d+)$/;
	my $latest_type = $1;
	my $latest_nr = $2;

    if ($card_type ne $latest_type){
      tsg4_set_error("card type mismatch ($card_type ne $latest_type)");
      return -1;
    }

    return 1 if ($latest_nr > $card_nr);
	return 0;
}

=head2 tsg4_autodetect_cards

    ($status, $card_href) = tsg4_autodetect_cards([$mode, $scan_href]);

    $mode 1..7 (4 is default)

    $scan_href = {
    	BL => 1,
    	PAS => 1,
    	SQ => 1,
    	TRC => 1,
    } is default, to skip detection according card type set value to 0 (e.g. for bootloader update).


    e.g. $card_href = { 
	       'BL' => {                # device type
			    '1' => {			# device number
			      'CAL' => '12.02.15',  # for mode > 6
			      'BSB' => 'BL:BSB00',  # for mode > 4
			      'FLB' => 'CDD1F5FF',  # for mode > 5
			      'HW' => '005G0046',   # for mode > 2
			      'SW' => 'FW_G0004',
			      'TST' => '15.01.15'   # for mode > 3 (this is default)
			    },
	        },
         }

    device type might be 
        BL,    # belt lock card
        CANFR, # CAN/FlexRay card
        KLIN,  # Kline/LIN card
        DVM,   # dvm scanner card
        PAS,   # PAS card
        RC,    # rack controller
        REF,   # Reference card
        SQ,    # Squib card
        TR,    # test rack
        TRC,   # transient recorder scanner +  trigger scanner
        TRG,   # trigger card
     	SPDT,  # generic switch card (single pole, double throw)
    	RDEC,  # generic resistor decade card
        UBAT,  # Ubat card
    	WL     # warning lamp card, WL4 is DIO




return detected card numbers and firmware/HW IDs/test date/boot staus byte/fuse and lock bits

=cut

sub tsg4_autodetect_cards{
	my $mode = shift;
    my $scan_href = shift;

    $mode = 4 unless defined $mode;
    $scan_href = {
        BL => 1,
        PAS => 1,
        SQ => 1,
        TRC => 1,
    } unless defined $scan_href;

#    print"autodetecting all cards in all racks mode = $mode\n";
    my ($hwID,$firmware,$tstDate);
    # autodetect all cards

	$slots2scan={};

	my $detected={};

	Detect_TR($detected,$mode);

    #check if we are on Test Rack
    if ( exists($detected->{TR}) ){
            push(@{$slots2scan->{scanSQ}}, 1..2);
            push(@{$slots2scan->{scanBL}}, 1..2);
            push(@{$slots2scan->{scanPAS}}, 1..2);
            push(@{$slots2scan->{scanWL}}, 1..4);
            push(@{$slots2scan->{scanUBAT}}, 1..4);
            push(@{$slots2scan->{scanREF}}, 1..8);
            push(@{$slots2scan->{scanCANFR}}, 1..16);
            push(@{$slots2scan->{scanKLIN}}, 1..16);
            push(@{$slots2scan->{scanSPDT}}, 1);
            push(@{$slots2scan->{scanRDEC}}, 1);
            push(@{$slots2scan->{scanTRG}}, 1);
            push(@{$slots2scan->{scanDVM}}, 1..2);
            push(@{$slots2scan->{scanTRC}}, 1..8);
            push(@{$slots2scan->{scanTRC}}, 32);
    }
    else{
		foreach my $rcNum (1..7){
			tsg4_detect_RC($rcNum,$detected,$mode);
		}
		#add possible slots depending on detected rack controllers
		$slots2scan = Calculate_slots($detected,$scan_href);
    }

    # scan all slots
    tsg4_detect_all_cards($slots2scan,$detected,$mode);

    # empty error buffer of not present cards
    tsg4_get_error();

#    print"autodetecting all cards done (mode = $mode) \n";
    if ( $mode > 0 and $mode < 8 ){
        return (0,$detected);
    }
    else{
    	return(-1,{});
    }

}





=head2 tsg4_detect_all_cards

    tsg4_detect_all_cards($slots2scan,$detected,$mode);

    $mode 1..7 (4 is default)

	push(@{$slots2scan->{scanSQ}}, 1..2); # will only scan for SQ1 and SQ2 (1st card)
	

    e.g. $detected = { 
	       'BL' => {                # device type
			    '1' => {			# device number
			      'CAL' => '12.02.15',  # for mode > 6
			      'BSB' => 'BL:BSB00',  # for mode > 4
			      'FLB' => 'CDD1F5FF',  # for mode > 5
			      'HW' => '005G0046',   # for mode > 2
			      'SW' => 'FW_G0004',
			      'TST' => '15.01.15'   # for mode > 3 (this is default)
			    },
	        },
         }

    device type might be 
        BL,    # belt lock card
        CANFR, # CAN/FlexRay card
        KLIN,  # Kline/LIN card
        DVM,   # dvm scanner card
        PAS,   # PAS card
        REF,   # Reference card
        SQ,    # Squib card
        TR,    # test rack
        TRC,   # transient recorder scanner +  trigger scanner
        TRG,   # trigger card
     	SPDT,  # generic switch card (single pole, double throw)
    	RDEC,  # generic resistor decade card
        UBAT,  # Ubat card
    	WL     # warning lamp card, WL4 is DIO


return detected card numbers and firmware/HW IDs/test date/boot staus byte/fuse and lock bits

=cut    

sub tsg4_detect_all_cards{
	my $scan=shift;
	my $detected = shift;
	my $mode = shift;

    foreach my $num (@{$scan->{scanSQ}}){
       	tsg4_detect_SQ($num,$detected,$mode);
    }
	foreach my $num (@{$scan->{scanBL}}){
		tsg4_detect_BL($num,$detected,$mode);
	}
	foreach my $num (@{$scan->{scanPAS}}){
		tsg4_detect_PAS($num,$detected,$mode);
	}
	foreach my $num (@{$scan->{scanTRC}}){
		tsg4_detect_TRC($num,$detected,$mode);
	}
	foreach my $num (@{$scan->{scanWL}}){
		tsg4_detect_WL($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanUBAT}}){
		tsg4_detect_UBAT($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanREF}}){
		tsg4_detect_REF($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanCANFR}}){
		tsg4_detect_CANFR($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanKLIN}}){
		tsg4_detect_KLIN($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanDVM}}){
		tsg4_detect_DVM($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanTRG}}){
		tsg4_detect_TRG($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanRDEC}}){
		tsg4_detect_RDEC($num,$detected,$mode);
	}
    foreach my $num (@{$scan->{scanSPDT}}){
		tsg4_detect_SPDT($num,$detected,$mode);
	}

	return 1;
}



=head2 Detect_TR

not exported

=cut

sub Detect_TR{
	my $detected = shift;
	my $mode = shift;
    tsg4_wait_ms($MSGdelay);
    my ($firmware,$hwID,$tstDate);

    ($status,$firmware) = tsg4_tr::tr_get_firmware();

# useless comments to avoid iSTAr display and Outline problem
#    ($status,$firmware) = tsg4_tr::tr_get_firmware();
#            ($status,$hwID) = tsg4_tr::tr_get_HW_id();

    if ($status >= 0){
        $detected->{TR}{1}{SW} = $firmware;
        if ($mode > 2){
            ($status,$hwID) = tsg4_tr::tr_get_HW_id();
            $detected->{TR}{1}{HW} = $hwID if ($status >= 0);
        }
        if ($mode > 3){
#            ($status,$tstDate) = tsg4_tr::tr_get_INFO('TST');
#            push (@{$detected->{allTSTs}{TR}},$tstDate)if ($status >= 0);
        }
    }
    return 1;
}


=head2 tsg4_detect_RC

    $status = tsg4_detect_RC($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut


sub tsg4_detect_RC{
	my $rcNum = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_rc::rc_get_firmware($rcNum);
	if ($status >= 0){
		$detected->{RC}{$rcNum}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_rc::rc_get_HW_id($rcNum);
			$detected->{RC}{$rcNum}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_rc::rc_get_INFO($rcNum,'TST');
			$detected->{RC}{$rcNum}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_rc::rc_get_INFO($rcNum,'BSB');
			$detected->{RC}{$rcNum}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_rc::rc_get_INFO($rcNum,'FLB');
			$detected->{RC}{$rcNum}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_rc::rc_get_INFO($rcNum,'CAL');
			$detected->{RC}{$rcNum}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

sub Calculate_slots{
	my $detected = shift;
	my $scan_href = shift;
	my $scan;

	# select slots depending on rack type
	foreach my $rack(keys %{$detected->{RC}}){
		if ($rack == 1){
			push(@{$scan->{scanSQ}}, 1..28) if ($scan_href->{SQ});
			push(@{$scan->{scanBL}}, 1..18) if ($scan_href->{BL});
			push(@{$scan->{scanPAS}}, 1..18) if ($scan_href->{PAS});
			push(@{$scan->{scanWL}}, 1,4); # 4 is used for former DIO
			push(@{$scan->{scanUBAT}}, 1);
			push(@{$scan->{scanREF}}, 1);
			push(@{$scan->{scanCANFR}}, 1..4);
			push(@{$scan->{scanKLIN}}, 1..4);
			push(@{$scan->{scanSPDT}}, 1);
			push(@{$scan->{scanRDEC}}, 1);

		}elsif ($rack == 2){
			push(@{$scan->{scanSQ}}, 29..56) if ($scan_href->{SQ});
			push(@{$scan->{scanBL}}, 19..36) if ($scan_href->{BL});
			push(@{$scan->{scanPAS}}, 19..36) if ($scan_href->{PAS});
			push(@{$scan->{scanWL}}, 2);
			push(@{$scan->{scanUBAT}}, 2);
			push(@{$scan->{scanREF}}, 2);
			push(@{$scan->{scanCANFR}}, 5..8);
			push(@{$scan->{scanKLIN}}, 5..8);

		}elsif ($rack == 3){
			push(@{$scan->{scanSQ}}, 29..40) if ($scan_href->{SQ});
			push(@{$scan->{scanBL}}, 19..30) if ($scan_href->{BL});
			push(@{$scan->{scanPAS}}, 19..30) if ($scan_href->{PAS});
			push(@{$scan->{scanWL}}, 2);
			push(@{$scan->{scanCANFR}}, 5..6);
			push(@{$scan->{scanKLIN}}, 5..6);

		}elsif ($rack == 4){
			push(@{$scan->{scanSQ}}, 41..52) if ($scan_href->{SQ});
			push(@{$scan->{scanBL}}, 31..42) if ($scan_href->{BL});
			push(@{$scan->{scanPAS}}, 31..42) if ($scan_href->{PAS});
			push(@{$scan->{scanWL}}, 3);
			push(@{$scan->{scanCANFR}}, 7..8);
			push(@{$scan->{scanKLIN}}, 7..8);

		}elsif ($rack == 5){
			push(@{$scan->{scanSQ}}, 53..64) if ($scan_href->{SQ});
			push(@{$scan->{scanBL}}, 43..54) if ($scan_href->{BL});
			push(@{$scan->{scanPAS}}, 43..54) if ($scan_href->{PAS});
			# WL4 is used for former DIO in Base Rack 1
			push(@{$scan->{scanCANFR}}, 9..10);
			push(@{$scan->{scanKLIN}}, 9..10);

		}elsif ($rack == 7){ # scanner rack
			push(@{$scan->{scanTRG}}, 1);
			push(@{$scan->{scanDVM}}, 1..2);
			push(@{$scan->{scanTRC}}, 1..8) if ($scan_href->{TRC});
			push(@{$scan->{scanTRC}}, 32)  if ($scan_href->{TRC});
		}
	}
	return $scan;
}


=head2 tsg4_detect_SQ

    $status = tsg4_detect_SQ($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_SQ{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_sq::sq_get_firmware($num);
	if ($status >= 0){
		$detected->{SQ}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_sq::sq_get_HW_id($num);
			$detected->{SQ}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_sq::sq_get_INFO($num,'TST');
			$detected->{SQ}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_sq::sq_get_INFO($num,'BSB');
			$detected->{SQ}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_sq::sq_get_INFO($num,'FLB');
			$detected->{SQ}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_sq::sq_get_INFO($num,'CAL');
			$detected->{SQ}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_BL

    $status = tsg4_detect_BL($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

	 e.g.
	 $detected_href = {
		  'BL' => {
		    '1' => {
		      'BSB' => 'BL:BSB00',
		      'FLB' => 'CDD1F5FF',
		      'HW' => '005G0046',
		      'SW' => 'FW_G0004',
		      'TST' => '15.01.15'
	    	},
		  },
	 }

=cut

sub tsg4_detect_BL{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_bl::bl_get_firmware($num);
	if ($status >= 0){
		$detected->{BL}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_bl::bl_get_HW_id($num);
			$detected->{BL}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_bl::bl_get_INFO($num,'TST');
			$detected->{BL}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_bl::bl_get_INFO($num,'BSB');
			$detected->{BL}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_bl::bl_get_INFO($num,'FLB');
			$detected->{BL}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_bl::bl_get_INFO($num,'CAL');
			$detected->{BL}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_PAS

    $status = tsg4_detect_PAS($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_PAS{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_pas::pas_get_firmware($num);
	if ($status >= 0){
		$detected->{PAS}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_pas::pas_get_HW_id($num);
			$detected->{PAS}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_pas::pas_get_INFO($num,'TST');
			$detected->{PAS}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_pas::pas_get_INFO($num,'BSB');
			$detected->{PAS}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_pas::pas_get_INFO($num,'FLB');
			$detected->{PAS}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_pas::pas_get_INFO($num,'CAL');
			$detected->{PAS}{$num}{CAL} = $cal if ($status >= 0);
		}	
	}
	return 1;
}

=head2 tsg4_detect_TRC

    $status = tsg4_detect_TRC($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_TRC{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_trc::trc_get_firmware($num);
	if ($status >= 0){
		$detected->{TRC}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_trc::trc_get_HW_id($num);
			$detected->{TRC}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_trc::trc_get_INFO($num,'TST');
			$detected->{TRC}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_trc::trc_get_INFO($num,'BSB');
			$detected->{TRC}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_trc::trc_get_INFO($num,'FLB');
			$detected->{TRC}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_trc::trc_get_INFO($num,'CAL');
			$detected->{TRC}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_WL

    $status = tsg4_detect_WL($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_WL{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_wl::wl_get_firmware($num);
	if ($status >= 0){
		$detected->{WL}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_wl::wl_get_HW_id($num);
			$detected->{WL}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_wl::wl_get_INFO($num,'TST');
			$detected->{WL}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_wl::wl_get_INFO($num,'BSB');
			$detected->{WL}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_wl::wl_get_INFO($num,'FLB');
			$detected->{WL}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_wl::wl_get_INFO($num,'CAL');
			$detected->{WL}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
 	return 1;
}

=head2 tsg4_detect_UBAT

    $status = tsg4_detect_UBAT($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_UBAT{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_ubat::ubat_get_firmware($num);
	if ($status >= 0){
		$detected->{UBAT}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_ubat::ubat_get_HW_id($num);
			$detected->{UBAT}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_ubat::ubat_get_INFO($num,'TST');
			$detected->{UBAT}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_ubat::ubat_get_INFO($num,'BSB');
			$detected->{UBAT}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_ubat::ubat_get_INFO($num,'FLB');
			$detected->{UBAT}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_ubat::ubat_get_INFO($num,'CAL');
			$detected->{UBAT}{$num}{CAL} = $cal if ($status >= 0);
		}
   }
	return 1;
}

=head2 tsg4_detect_REF

    $status = tsg4_detect_REF($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut


sub tsg4_detect_REF{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_via::via_get_firmware($num);
	if ($status >= 0){
		$detected->{REF}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_via::via_get_HW_id($num);
			$detected->{REF}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_via::via_get_INFO($num,'TST');
			$detected->{REF}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_via::via_get_INFO($num,'BSB');
			$detected->{REF}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_via::via_get_INFO($num,'FLB');
			$detected->{REF}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_via::via_get_INFO($num,'CAL');
			$detected->{REF}{$num}{CAL} = $cal if ($status >= 0);
		}
   }
	return 1;
}

=head2 tsg4_detect_CANFR

    $status = tsg4_detect_CANFR($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

	 e.g.
	 $detected_href = {
		  'CANFR' => {
		    '1' => {
		      'BSB' => 'BL:BSB00',
		      'FLB' => 'CDD1F5FF',
		      'HW' => '004C0016',
		      'SW' => 'FW_C0002',
		      'TST' => '16.10.14'
		    },
		  },
	 }

=cut

sub tsg4_detect_CANFR{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_canfr::cf_get_firmware($num);
	if ($status >= 0){
		$detected->{CANFR}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_canfr::cf_get_HW_id($num);
			$detected->{CANFR}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_canfr::cf_get_INFO($num,'TST');
			$detected->{CANFR}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_canfr::cf_get_INFO($num,'BSB');
			$detected->{CANFR}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_canfr::cf_get_INFO($num,'FLB');
			$detected->{CANFR}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_canfr::cf_get_INFO($num,'CAL');
			$detected->{CANFR}{$num}{CAL} = $cal if ($status >= 0);
		}
   }
	return 1;
}

=head2 tsg4_detect_KLIN

    $status = tsg4_detect_KLIN($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_KLIN{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_klin::kl_get_firmware($num);
	if ($status >= 0){
		$detected->{KLIN}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_klin::kl_get_HW_id($num);
			$detected->{KLIN}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_klin::kl_get_INFO($num,'TST');
			$detected->{KLIN}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_klin::kl_get_INFO($num,'BSB');
			$detected->{KLIN}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_klin::kl_get_INFO($num,'FLB');
			$detected->{KLIN}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_klin::kl_get_INFO($num,'CAL');
			$detected->{KLIN}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_DVM

    $status = tsg4_detect_DVM($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected


=cut

sub tsg4_detect_DVM{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_dvm::dvm_get_firmware($num);
	if ($status >= 0){
		$detected->{DVM}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_dvm::dvm_get_HW_id($num);
			$detected->{DVM}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_dvm::dvm_get_INFO($num,'TST');
			$detected->{DVM}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_dvm::dvm_get_INFO($num,'BSB');
			$detected->{DVM}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_dvm::dvm_get_INFO($num,'FLB');
			$detected->{DVM}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_dvm::dvm_get_INFO($num,'CAL');
			$detected->{DVM}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_TRG

    $status = tsg4_detect_TRG($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_TRG{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_trg::trg_get_firmware($num);
	if ($status >= 0){
		$detected->{TRG}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_trg::trg_get_HW_id($num);
			$detected->{TRG}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_trg::trg_get_INFO($num,'TST');
			$detected->{TRG}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_trg::trg_get_INFO($num,'BSB');
			$detected->{TRG}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_trg::trg_get_INFO($num,'FLB');
			$detected->{TRG}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_trg::trg_get_INFO($num,'CAL');
			$detected->{TRG}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_RDEC

    $status = tsg4_detect_RDEC($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_RDEC{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_rdec::rdec_get_firmware($num);
	if ($status >= 0){
		$detected->{RDEC}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_rdec::rdec_get_HW_id($num);
			$detected->{RDEC}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_rdec::rdec_get_INFO($num,'TST');
			$detected->{RDEC}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_rdec::rdec_get_INFO($num,'BSB');
			$detected->{RDEC}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_rdec::rdec_get_INFO($num,'FLB');
			$detected->{RDEC}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_rdec::rdec_get_INFO($num,'CAL');
			$detected->{RDEC}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}

=head2 tsg4_detect_SPDT

    $status = tsg4_detect_SPDT($device_num,$detected_href,$mode);

update $detected_href structure with details of $device_num if detected

=cut

sub tsg4_detect_SPDT{
	my $num = shift;
	my $detected = shift;
	my $mode = shift;
	my ($firmware,$hwID,$tstDate,$bsb,$flb,$cal);
	($status,$firmware) = tsg4_spdt::spdt_get_firmware($num);
	if ($status >= 0){
		$detected->{SPDT}{$num}{SW} = $firmware;
		if ($mode > 2){
			($status,$hwID) = tsg4_spdt::spdt_get_HW_id($num);
			$detected->{SPDT}{$num}{HW} = $hwID if ($status >= 0);
		}
		if ($mode > 3){
			($status,$tstDate) = tsg4_spdt::spdt_get_INFO($num,'TST');
			$detected->{SPDT}{$num}{TST} = $tstDate if ($status >= 0);
		}
		if ($mode > 4){
			($status,$bsb) = tsg4_spdt::spdt_get_INFO($num,'BSB');
			$detected->{SPDT}{$num}{BSB} = $bsb if ($status >= 0);
		}
		if ($mode > 5){
			($status,$flb) = tsg4_spdt::spdt_get_INFO($num,'FLB');
			$detected->{SPDT}{$num}{FLB} = $flb if ($status >= 0);
		}
		if ($mode > 6){
			($status,$cal) = tsg4_spdt::spdt_get_INFO($num,'CAL');
			$detected->{SPDT}{$num}{CAL} = $cal if ($status >= 0);
		}
	}
	return 1;
}


=head2 tsg4_set_mode

    $status = tsg4_set_mode($mode [,$time]);

	$mode 'standby' or 'normal'
	$time in seconds 1..9999, default is 300 sec for standby

set TSG4 to standby (after time) or normal mode.

=cut

sub tsg4_set_mode{

	my $mode = shift;
	my $time = shift;
	if ($mode eq 'standby'){
		foreach my $num (2,3,4,7){
			tsg4_rc::rc_set_12V_standby($num,1); # better to handle in firmware via broadcast ???
		}
		tsg4_wait_ms(1000);
		$status = tsg4_rc::rc_set_12V_standby(1,$time);
	}
	elsif($mode eq 'normal'){
		$status = tsg4_rc::rc_set_12V_normal(1);
		foreach my $num (2,3,4,7){
			tsg4_rc::rc_set_12V_normal($num);
		}
	}
	else{
		tsg4_set_error("tsg4_set_mode: unknown mode $mode");
		return -1;
	}

	# return status of RC1 communication
    return($status);
}



=head2 tsg4_boot_init

    $status = tsg4_boot_init();

initialize bootloader and start communication.

=cut

sub tsg4_boot_init{
    my $data_aref;

    tsg4_log("\n\n=>tsg4_boot_init");
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # open communication
    tsg4_log("->open communication: $status");
    tsg4_wait_ms(100);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # close communication
    tsg4_log("->close communication: $status");
    tsg4_wait_ms(100);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # open communication
    tsg4_log("got ($status) @$data_aref on 3. open communication\n");

    if ($status < 0){
    	tsg4_set_error("receive timeout!");
    	return ($status);
    }

    if($$data_aref[1] == 1){
        tsg4_log("->bootloader opened");
    }
    elsif($$data_aref[1] == 0){
        tsg4_log("->bootloader closed, reopening");
        tsg4_wait_ms(100);

        ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout);
	    tsg4_log("->open communication: $status");

        if ($status < 0){
            tsg4_set_error("receive timeout!");
            return ($status);
        }

        if($$data_aref[1] == 1){
            tsg4_log("->bootloader opened");
        }
        else{
            tsg4_set_error("error opening bootloader!");
            return (-1);
        }
    }

    return($status);
}

=head2 tsg4_bootloader_inactive_check

    $status = tsg4_bootloader_inactive_check();

check if any bootloader is active.

returns -1 if an answer was received on bootloader communication

=cut

sub tsg4_bootloader_inactive_check{
    my $data_aref;

    tsg4_log("=>tsg4_bootloader_inactive_check");
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # open communication
    tsg4_log("->open communication: $status");
    if ($status > -1){
        tsg4_set_error("received unexpected answer!");
        return (-1);
    }
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # close communication
    tsg4_log("->close communication: $status");
    if ($status > -1){
        tsg4_set_error("received unexpected answer!");
        return (-1);
    }
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [1,0xff], 0, 0, $MAXtimeout); # open communication
    tsg4_log("->open communication: $status");
    if ($status > -1){
        tsg4_set_error("received unexpected answer!");
        return (-1);
    }

#    print"and all is quiet.\n";
    return(0);
}


=head2 tsg4_boot_exit

    $status = tsg4_boot_exit();

exit bootloader mode and re-start firmware.

=cut

sub tsg4_boot_exit{

    tsg4_log("=>tsg4_boot_exit");
    ######
    #   6.902860 1  4               Rx   d 4 03 01 00 00         # start application with reset

    tsg4_log("-> starting application\n");
    tsg4_wait_ms($MSGdelay);
    $canStatus = tsg4can_SendMessage( [4,3,1,0,0], 4, 0 );      # start application with reset
    $status = tsg4_check_CAN_status( $canStatus, "boot_exit" );
    tsg4_log("->reset: $status");
    tsg4_wait_ms(500);
    $canStatus = tsg4can_SendMessage( [4,3,1,0,0], 4, 0 );      # start application with reset
    $status = tsg4_check_CAN_status( $canStatus, "boot_exit" );
    tsg4_log("->reset: $status");

    return($status);
}


=head2 tsg4_firmware_update

    $status = tsg4_firmware_update($firmwarefile);

flash new firmware via CAN, ensure only one card is in bootloader mode, bootloader communication is established and the flashfile is matching to card type.

=cut

sub tsg4_firmware_update{

	$device_count++;
# verify error: erase and reflash again, no reset !!!
	tsg4_log("=>tsg4_firmware_update device $device_count");
    my $firmwarefile=shift;

    # reading and parsing intel hex file needs some update
    # currently it is assumed that the file is starting at 0000 and represents a single block
    # the length and the checksum are not checked. 

    #read file
    my (@lines,@bytes);
    @lines=();
    open(IN,"<$firmwarefile") or warn "could not open file";
    @lines = <IN>;
    close (IN);

    #file: see http://de.wikipedia.org/wiki/Intel_HEX
    # :101DAC0025632563003000645261636B2025326427
    # :101DBC0020200049443A30782558000100000000EA

    #  len  addr type  data                            checksum
    # :10  1DAC  00    25632563003000645261636B20253264 27   # type 00=Data record
    # :10  1DBC  00    20200049443A30782558000100000000 EA # 16

    # :10 FFF0 00 FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF 11
    #             segment
    # :02 0000 02 1000 EC    # type 02=Extended Segment Address Record : add 16*segment to adress (0x1000 * 16 = 0x10000)
    # :10 0000 00 FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF 00 -> address is 0x10000

    # :0C 1D40 00 841F951FA01D0895F894FFCF 8C  #12 byte

    # :00 0000 01 FF   # type 01=end of file

    @bytes=();
    foreach my $line (@lines){
        if ($line =~ /^\s*:(\w{2})(\w{4})(\w{2})(\w+)(\w{2})$/){
            my $length = $1;
            my $address = $2;
            my $type = $3;
            my $bytestring = $4;
            # skip everything which is not a data record
            if ($type == 0){
#	            tsg4_log("$address $bytestring\n");
	            my @values = unpack "a2" x (length( $bytestring ) /2 ), $bytestring;
	            foreach my $value (@values){
	                $value = hex($value);
	            }
	            push(@bytes, @values);
            }
            else{tsg4_log("skipped $line");}
        }
    }

	if(scalar(@bytes) < 100){
        tsg4_set_error("firmware file error!");
        return 0;
	}

#    tsg4_log("writing:\n@bytes \n\n\n");

	my $retry=1;
	my $flash_ok=0;
	until($flash_ok or $retry>5 ){
		tsg4_log("retry cycle $retry");
		firmware_erase();
		$flash_ok=firmware_write_verify(@bytes);
		$retry++;
	}


    return $flash_ok;
}


sub firmware_erase{
    # l�schen, blank check, program, verify

    #   39.319210 1  6               Rx   d 3 01 00 00          # select memory space
    #    0.000172 1  6               Rx   d 1 00  
    #    0.002306 1  1               Rx   d 3 80 FF FF          # erasing
    #    2.128663 1  1               Rx   d 1 00                < command ok

    #   0.000712 1  3               Rx   d 5 80 00 00 FF FF     # blank check 0000 to ffff 
    #   0.737328 1  3               Rx   d 0                    < blank check ok  
    my ($data_aref);
    tsg4_wait_ms($MSGdelay);
    tsg4_log("-> erasing flash\n");
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,1,0,0], 6, 6, $MAXtimeout);
    tsg4_log("got ($status) @$data_aref on select memory space 0 - flash memory\n");
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,0x80,0xff,0xff], 1, 1, $ERASEtimeout);
    tsg4_log("got ($status) @$data_aref on erase\n");
    tsg4_wait_ms($MSGdelay);
    tsg4_log("-> blank check\n");
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,1,0,0], 6, 6, $MAXtimeout);
    tsg4_log("got ($status) @$data_aref on select memory space 0 - flash memory\n");
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,2,0,0], 6, 6, $MAXtimeout);
    tsg4_log("got ($status) @$data_aref on select memory page 0\n");
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [5,80,0,0,0xff,0xff], 3, 3, $ERASEtimeout);
    tsg4_log("got ($status) @$data_aref on blank check\n");
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,2,0,1], 6, 6, $MAXtimeout);
    tsg4_log("got ($status) @$data_aref on select memory page 1\n");
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [5,80,0,0,0xdf,0xff], 3, 3, $ERASEtimeout);
    tsg4_log("got ($status) @$data_aref on blank check\n");

	return 1;
}



# flash_verify_page ($page, $bytes2flash_aref);
sub flash_verify_page{
	my $page = shift;
	my $bytes2flash_aref = shift;
	
	my ($data_aref,@start,$dec_value,@end,$frame_retry,@frame);
	my @bytes2flash = @$bytes2flash_aref;
	$dec_value=0;

	#select memory page 0
    tsg4_wait_ms($MSGdelay);
    ($status,$data_aref) = tsg4can_SendAndWaitForResponse( [3,2,0,$page], 6, 6, $MAXtimeout);
    tsg4_log("got ($status) @$data_aref on select memory page $page\n");

    while (@bytes2flash > 0){

        @frame = splice(@bytes2flash,0,8);
        my @written_bytes=@frame;
        my $frame_length = scalar(@frame);
        unshift (@frame, $frame_length);
        $frame_retry=1;
#        tsg4_log(" @frame \n");
		do{
	        @start = dec2intarray($dec_value);
	        @end = dec2intarray($dec_value+$frame_length-1);

			#prepare write frame
	        tsg4_wait_ms($MSGdelay);
	    	($status,$data_aref) = tsg4can_SendAndWaitForResponse( [5,0,@start,@end], 1, 1, $MAXtimeout);
		    tsg4_log("got ($status) @$data_aref on prepare write  5,0,".join(',',@start,@end)." \n");

			#write frame
	        tsg4_wait_ms($FRMdelay);
	        ($status,$data_aref) = tsg4can_SendAndWaitForResponse( \@frame, 2, 2, $MAXtimeout);
		    tsg4_log("got ($status) @$data_aref on write frame @frame \n");

	        #read frame
        	tsg4_wait_ms($FRMdelay);
        	($status,$data_aref) = tsg4can_SendAndWaitForResponse( [5,0,@start,@end], 3, 3, $MAXtimeout);
		    tsg4_log("got ($status) @$data_aref on read frame 5,0,".join(',',@start,@end)." \n");
	        my @read_bytes=@$data_aref;

	        #verify frame
		    $status = compare_numarrays(\@written_bytes,\@read_bytes);
		    if ($status){
		        tsg4_log("-> frame verify ok address $dec_value\n");
		        $frame_retry=0;
		    }
		    else{
		        tsg4_log("-> frame verify error $frame_retry address $dec_value\nw @written_bytes \nr @read_bytes");
		        $frame_retry++;
				sleep 5;
		    }
		} until ($frame_retry == 0 or $frame_retry > 5);

		# up to 5 retries on error
		if ($frame_retry != 0){
			tsg4_set_error("flash frame error!");
			return 0;
		}
		
        $dec_value += 8; # new start value

    }

	return 1;
}


sub firmware_write_verify{
    my @bytes = @_;
    my $byte_num = scalar(@bytes);
    my ($success, $page_retry);

    tsg4_log("-> programming flash with verify\n");

    # up to 3 retries on error

    # check if 2 pages are needed
    if ($byte_num > 0x10000){
        tsg4_log("$byte_num > 0x10000 \n\n\n");
        # flash and verify entire first page and then 2nd page
	    my @bytes2flash = splice(@bytes,0,0x10000); # cut off first page data

    	$page_retry = 1;
    	$success = 0;
    	do{
			$success = flash_verify_page (0, \@bytes2flash);
			$page_retry++;
    	} until ($success or $page_retry > 3);
		unless ($success){
			tsg4_set_error("flash page error, giving up!");
			return 0;
		}

    	$page_retry = 1;
    	$success = 0;
    	do{
			$success = flash_verify_page (1, \@bytes);
			$page_retry++;
    	} until ($success or $page_retry > 3);
		unless ($success){
			tsg4_set_error("flash page error, giving up!");
			return 0;
		}


    }
    else{
    	tsg4_log("$byte_num <= 0x10000 \n\n\n");
    	$page_retry = 1;
    	$success = 0;
    	do{
			$success = flash_verify_page (0, \@bytes);
			$page_retry++;
    	} until ($success or $page_retry > 3);
		unless ($success){
			tsg4_set_error("flash page error, giving up!");
			return 0;
		}
    }

	return 1;
}



=head2 tsg4_get_device_CANid

    ($stat,$canID) = tsg4_get_device_CANid($device_type, $number);

    (0, 0x104) = tsg4_get_device_CANid('SQ',3);

returns CAN id for device for sending request to device.

=cut

sub tsg4_get_device_CANid {

my $device_type = shift;
my $number= shift;
my ($canID,$offset);

    if($device_type eq 'SQ'){
        $canID = SQ_base_address + (($number - 1) * 2);
    }
    elsif($device_type eq 'BL'){
	    if(($number & 0x01) ==1) {$offset= ($number + 1 )-2;}
	    else {$offset=$number-2;}
	    $canID = BL_base_address + $offset;
    }
    elsif($device_type eq 'CANFR'){
        if(($number & 0x01) ==1) {$offset= ($number + 1 )-2;}
        else {$offset=$number-2;}
        $canID = CAN_base_address + $offset;
    }
    elsif($device_type eq 'KLIN'){
        if(($number & 0x01) ==1) {$offset= ($number + 1 )-2;}
        else {$offset=$number-2;}
        $canID = Kline_base_address + $offset;
    }
    elsif($device_type eq 'DVM'){
        $canID = DVM_base_address + (($number - 1) * 2);
    }
    elsif($device_type eq 'PAS'){
        if(($number & 0x01) ==1) {$offset= ($number + 1)-2;}
        else {$offset=$number-2;}
        $canID = PAS_base_address + $offset
    }
    elsif($device_type eq 'RC'){
        $canID = RC_base_address + (($number - 1) * 2);
    }
    elsif($device_type eq 'REF'){
        $canID = VIA_base_address;
    }
    elsif($device_type eq 'TR'){
        $canID = TestRack_base_address;
    }
    elsif($device_type eq 'TRC'){
        $canID = TRC_base_address + (($number - 1) * 2);
    }
    elsif($device_type eq 'PSL'){
        $canID = UBAT_base_address;
    }
    elsif($device_type eq 'RDEC'){
        $canID = Rdecade_base_address;
    }
    elsif($device_type eq 'SPDT'){
        $canID = GenericSwitch_base_address;
    }
    elsif($device_type eq 'WL'){
	    my $wlTemp=$number;
	    $offset = 0;
	    while ($wlTemp>6){$wlTemp-=6;$offset+=2;}
	    $canID = WL_base_address + $offset;
    }
    else{
        tsg4_set_error("unknown device type <$device_type>!");
        return (-1,0);
    }


    return (1,$canID);
}


################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 tsg4_get_CAN_HW_list

    ($status, $CAN_HW_IDs_aref, $channels_aref) = tsg4_get_CAN_HW_list();

get IDs of connected CAN HW and supported CAN channels

=cut

sub tsg4_get_CAN_HW_list{
   my ($canStat, $ids_aref, $channels_aref) = tsg4can_GetHWlist();

    $status = tsg4_check_CAN_status( $canStat, "getCANhw" );

    return ($status, $ids_aref, $channels_aref);

}

=head2 tsg4_check_CAN_status

 $status = tsg4_check_CAN_status($result,$slot)

if result < 0, set error string and return -1.

=cut

sub tsg4_check_CAN_status{
    my $canStat = shift;
    my $slot = shift;

    if ($canStat<0){
      my $canErrortext = tsg4can_GetErrorString($canStat);
      tsg4_set_error( "slot $slot CAN_error ($canStat): $canErrortext");
      return -1

    }
    return 0;

}


=head2 tsg4_reset_all

    ($status,$answer) = tsg4_reset_all();

    e.g. (0,"TSGready") = tsg4_reset_all();

send reset broadcast to all cards and reset RC7 .. RC1, returns after TSG4 is ready again. 
only cards with firmware which supports reset will be resetted.

returns status and answer of RC1.

=cut

sub tsg4_reset_all {
    my $value;

	$status = tsg4_send_broadcast('TSGreset');
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(7,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(6,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(5,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(4,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(3,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(2,"R"); 
    ($status,$value) = tsg4_rc::rc_send_commad_wait_response(1,"R",'ASCII', 60000); # timeout 60 s
    return ($status,$value);

}

=head2 tsg4_send_broadcast

    $status = tsg4_send_broadcast($ascii_command);

    e.g. $status = tsg4_send_broadcast('TSG4reset');


Transmits the string $data on the CAN to all cards

returns status.

=cut

sub tsg4_send_broadcast {
    my $ascii_command = shift;
	my $CANstatus;
    my $send_ID = 0x7f0;

#    printf( "-> 0x%02x $ascii_command\n",$send_ID);

    my @bytes = split(//, $ascii_command);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "broadcast" );
    return ($status);

}


=head2 tsg4_set_error

 tsg4_set_error($errortext)

 collect errors (including callstack) in variable

=cut

sub tsg4_set_error{
    my $error_text = shift;

    my @callStack;
    my $count = 2;
    while( defined( (caller($count))[3] ) and $count < 99 ){
    	last if ( (caller($count))[3] eq '(eval)' ); # stop at engine level
        push( @callStack,(caller($count))[3] );
        $count++;
    }

    push(@tsg4errors,"low level error: ".$error_text."\nlow level call stack: { ".join(' -> ',@callStack)." }");
    tsg4_log("!!!: $error_text");
    return 1;
}

=head2 tsg4_wait_ms

 tsg4_wait_ms($time_ms)

wait for given milliseconds.

=cut

sub tsg4_wait_ms{
    my $time = shift;
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
    return 1;
}

=head2 tsg4_set_SIM_return_text

 tsg4_set_SIM_return_text( $text )

 set return value for next tsg4can_SendAndWaitForResponse call

=cut

sub tsg4_set_SIM_return_text{
    my $text = shift;
    my $functionArgs_aref = shift;
    my @bytes = split(//,$text);
    foreach my $byte (@bytes){
    	$byte = ord($byte);
    }
    SIM_setReturnValues('tsg4can_SendAndWaitForResponse', [ 0, \@bytes ]);
    return 1;
}

=head1 NOT EXPORTED FUNCTIONS

=cut


sub compare_numarrays {
    my ($first, $second) = @_;
    no warnings;  # silence spurious -w undef complaints
    return 0 unless @$first == @$second;
    for (my $i = 0; $i < @$first; $i++) {
        return 0 if $first->[$i] != $second->[$i];
    }
    return 1;
}

# @integers = dec2intarray($dec_value);
sub dec2intarray{
        my $dec_value = shift;
        my $hex_value=unpack("H*",pack("S*",$dec_value)); # U16 -> hex
        my @integers = reverse (unpack ("a2" x (length( $hex_value ) /2 ) ,$hex_value) );
        #convert all elements to decimal
        foreach my $item (@integers){
            $item = hex($item);
        }
        return @integers;

}

sub tsg4_log{
    my $text=shift;
    chomp($text);
    print $TSG4log $text."\n";
    print $text."\n" if ($console_print);
    return 1;
}



##############################################################################################################################
##############################################################################################################################
#
# simulation functions start here
#

if ( $main::opt_simulation ){

    # define only those functions that should be redefined (most of the exported functions work even in simulation mode)
    my @redefine = qw( tsg4_detect_all_cards tsg4_detect_RC tsg4_get_CAN_HW_list );

	# redefine all functions for simulation mode with default return values
	foreach my $function (@redefine){
		{
		no strict 'refs';
		# each function in @EXPORT is redefined using SIM_returnValues
		*{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
		}
	}

	my $SIM_detected_cards={
			        BL => {
			    		'1' => {
                             'SW' => 'FW_G0005',
                             'HW' => '002G0072'
                        },
			    		'2' => {
                             'SW' => 'FW_G0005',
                             'HW' => '002G0072'
                        },
			    		'3' => {
                             'SW' => 'FW_G0005',
                             'HW' => '002G0073'
                        },
			    		'4' => {
                             'SW' => 'FW_G0005',
                             'HW' => '002G0073'
                        },
			    	},
			        CANFR => {
			    		'1' => {
                             'SW' => 'FW_C0003',
                             'HW' => '004C0013'
                        },
			    		'2' => {
                             'SW' => 'FW_C0003',
                             'HW' => '004C0013'
                        },
			    	},
			        RC => {
			    		'1' => {
                             'SW' => 'FW_X0016',
                             'HW' => '004X0022'
                        },
			    	},
			        REF => {
			    		'1' => {
                             'SW' => 'FW_B0004',
                             'HW' => '004B0012'
                        },
			    	},
			        SQ => {
			    		'1' => {
                             'SW' => 'FW_Z0005',
                             'HW' => '005Z0092'
                        },
			    		'2' => {
                             'SW' => 'FW_Z0005',
                             'HW' => '005Z0092'
                        },
			    		'3' => {
                             'SW' => 'FW_Z0005',
                             'HW' => '005Z0093'
                        },
			    		'4' => {
                             'SW' => 'FW_Z0005',
                             'HW' => '005Z0093'
                        },
			    	},
			        UBAT => {
			    		'1' => {
                             'SW' => 'FW_U0007',
                             'HW' => '004U0012'
                        },
			    	},
			    	WL => {
			    		'1' => {
                             'SW' => 'FW_L0008',
                             'HW' => '004L0001'
                        },
			    	},

			        KLIN => {
			    		'3' => {
                             'SW' => 'FW_K0004',
                             'HW' => '004K0012'
                        },
			    		'4' => {
                             'SW' => 'FW_K0004',
                             'HW' => '004K0012'
                        },
			    	},

			        DVM => {
			    		'1' => {
                             'SW' => 'FW_D0005',
                             'HW' => '004D0012'
                        },
			    	},
			        TRC => {
			    		'1' => {
                             'SW' => 'FW_T0005',
                             'HW' => '004T0012'
                        },
			    		'2' => {
                             'SW' => 'FW_T0005',
                             'HW' => '004T0013'
                        },
			    		'3' => {
                             'SW' => 'FW_T0005',
                             'HW' => '004T0014'
                        },
			    		'4' => {
                             'SW' => 'FW_T0005',
                             'HW' => '004T0015'
                        },
			    	},
			        PAS => {
			    		'7' => {
                             'SW' => 'FW_P0006',
                             'HW' => '004P0012'
                        },
			    		'8' => {
                             'SW' => 'FW_P0006',
                             'HW' => '004P0012'
                        },
			    	},
	};


	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
        'tsg4_get_CAN_HW_list' => { 'default' => [ 0, ['30667'], [1] ], 
                                    'wrong_single' => [ 0, ['33333'], [1] ],
                                    'wrong_multi' => [ 0, ['33333','44444'], [1,2] ],},
	};
	SIM_addToValuesTable( $returnValuesTable_href );

	# redefine again those functions which need special treatment
	*tsg4_detect_all_cards = sub{
		my $slots2scan = shift;
		my $detectedDevices = shift;
		foreach my $device (keys %$SIM_detected_cards){
			$detectedDevices->{$device} = $SIM_detected_cards->{$device};
		}
		return 1;
	};

    *tsg4_detect_RC = sub{
        my $rcNum = shift;
        my $detectedDevices = shift;
        $detectedDevices->{RC}{$rcNum}{SW} = 'FW_X0016';
        return 1;
    };

}

1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



