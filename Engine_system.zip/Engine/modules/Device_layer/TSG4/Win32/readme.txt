About vxlapi.dll:
A 32-bit XL driver library from Vector used to communicate with vector hardwares.

About TSG4CAN.dll:
A 32-bit Wrapper perl dll for CANWIN32TSG4.dl . 
It is compiled using Perl 5.12, 32 bit version
This is created as redundant copy of DLLs/CAN/ low level module to accomodate the TSG4 communication.

About CANWIN32TSG4.dll:
Redundant copy of DLLs/CAN/Win32/CANWIN32.dll.
32-bit wrapper C++ DLL for CAN_Control.dll (which is a C# Assembly dll)

About CAN_Control.dll:
A 32-bit C# dll to control CAN Communication and form TPX control layer

About CAN_Communication.dll:
A 32-bit C++ Low level DLL which perfom simple Send and receive of CAN messages
