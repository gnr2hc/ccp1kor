package tsg4_rdec;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    rdec_send_commad
    rdec_send_commad_wait_response
    rdec_reset
    rdec_bootloader_mode
    rdec_get_firmware
    rdec_get_HW_id
    rdec_write_SN
    rdec_write_TST
    rdec_write_CAL
	rdec_get_INFO
	rdec_set_value

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

generic resistor decade control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 rdec_reset

    $status = rdec_reset($RDECnumber);

    e.g. $status = rdec_reset(1);

resets all resistor decades 

returns status.

=cut

sub rdec_reset {
    my $RDECnumber = shift;

    my $command = "R01";

    ($status,$receive_ID) = rdec_send_commad_wait_response($RDECnumber,$command);
    
    return ($status);
    
}

=head2 rdec_set_value

    $status = rdec_set_value($RDECnumber, $decade, $value);
    
    $decade 'A' .. 'E'
	
	$value 0 .. 99990 Ohm step 10 Ohm, 100000 Ohm = interruption

    e.g. $status = rdec_set_value(1,'A',700);

connects resistor decade card input $decade to output RDEC-Lo

returns status.

=cut

sub rdec_set_value {
    my $RDECnumber = shift;
    my $decade = shift;
    my $value = shift;
	$value = int($value/10);

    my $command = sprintf("%s%05d",$decade,$value);

    ($status,$receive_ID) = rdec_send_commad_wait_response($RDECnumber,$command);
    
    return ($status);
    
}


=head2 rdec_write_SN

    $status = rdec_write_SN($RDECnumber,$serial_number);

    e.g. $status = rdec_write_SN(1,'999R0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub rdec_write_SN {
    my $RDECnumber = shift;
    my $SN = shift;

    $status = rdec_write_EE($RDECnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 rdec_write_TST

    $status = rdec_write_TST($RDECnumber,$TST_date);

    e.g. $status = rdec_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub rdec_write_TST {
    my $RDECnumber = shift;
    my $TST_date = shift;

    $status = rdec_write_EE($RDECnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 rdec_write_CAL

    $status = rdec_write_CAL($RDECnumber,$CAL_date);

    e.g. $status = rdec_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub rdec_write_CAL {
    my $RDECnumber = shift;
    my $CAL_date = shift;

    $status = rdec_write_EE($RDECnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 rdec_bootloader_mode

    $status = rdec_bootloader_mode($RDECnumber);

    e.g. $status = rdec_bootloader_mode(1);

sets resistor decade card to bootloader mode for firmware update

returns status.

=cut

sub rdec_bootloader_mode {
    my $RDECnumber = shift;
    my $value;

    ($status,$value) = rdec_send_commad_wait_response($RDECnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 rdec_get_firmware

    ($status, $firmware) = rdec_get_firmware($RDECnumber);

    e.g. (0,'FW_R0001') = rdec_get_firmware(1);

reads firmware version from resistor decade card

returns status.

=cut

sub rdec_get_firmware {
    my $RDECnumber = shift;
    my $value;

    ($status,$value) = rdec_send_commad_wait_response($RDECnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 rdec_get_HW_id

    ($status, $HW_ID) = rdec_get_HW_id($RDECnumber);

    e.g. (0,'999R0042') = rdec_get_HW_id(1);

reads hardware ID from resistor decade card

returns status.

=cut

sub rdec_get_HW_id {
    my $RDECnumber = shift;
    my $value;

    ($status,$value) = rdec_get_INFO($RDECnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 rdec_get_INFO

    ($status, $INFO) = rdec_get_INFO($RDECnumber,$keyword);

    e.g. (0,'999R0042') = rdec_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from resistor decade card

returns status.

=cut

sub rdec_get_INFO {
    my $RDECnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = rdec_send_commad_wait_response($RDECnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 rdec_write_EE not exported

    $status = rdec_write_EE($RDECnumber,$EEslot,$text);

    e.g. $status = rdec_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub rdec_write_EE {
    my $RDECnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = rdec_send_commad($RDECnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "RDEC_$RDECnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 rdec_send_commad_wait_response

    ($stat,$ret) = rdec_send_commad_wait_response($RDECnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to resistor decade card

returns status and answer string as ASCII.

=cut

sub rdec_send_commad_wait_response {
    my $RDECnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;

    my $send_ID = Rdecade_base_address +(($RDECnumber - 1) * 2);   
    
    $ASCII_command = sprintf("R%01d%s",$RDECnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "RDEC_$RDECnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 rdec_send_commad

    ($stat,$receive_ID) = rdec_send_commad($RDECnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = rdec_send_commad(3,'?00');

Transmits the string $data on the CAN to resistor decade card

returns status and answer ID.

=cut

sub rdec_send_commad {
    my $RDECnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = Rdecade_base_address +(($RDECnumber - 1) * 2);   
    
    $ASCII_command = sprintf("R%01d%s",$RDECnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "RDEC_$RDECnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



