# *****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package TSG4_FirmwareVersions;

use strict;
use warnings;

our ( $VERSION, $HEADER );

our $latestFirmware_href = {
    BL    => 'FW_G0007',
    CANFR => 'FW_C0003',
    DVM   => 'FW_D0005',
    KLIN  => 'FW_K0004',
    PAS   => 'FW_P0006',
    RC    => 'FW_X0017',
    REF   => 'FW_B0004',
    SQ    => 'FW_Z0006',
    TRC   => 'FW_T0005',
    TRG_A => 'FW_Y0003',
    TRG_F => 'FW_Y0021',
    UBAT  => 'FW_U0007',
    WL    => 'FW_L0008',
};
1;
