package tsg4_ubat;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    ubat_bootloader_mode
    ubat_connect
    ubat_disconnect
    ubat_get_firmware
    ubat_get_HW_id
    ubat_get_INFO
    ubat_lock_display
    ubat_LV124
    ubat_LV124_E10
    ubat_LV124_startup_time
	ubat_microcut
    ubat_send_commad
    ubat_send_commad_wait_response
    ubat_set_event_delay
    ubat_set_event_trigger
    ubat_UF
    ubat_unlock_display
    ubat_write_CAL
    ubat_write_SN
    ubat_write_TST

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

UBAT Control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 ubat_UF -> to test

    $status = ubat_UF($UBATcard,$state);

    e.g. $status = ubat_UF(1,"normal");

    $state = "normal", "reverse" or "off"

connects UF with normal prolarity, reverse polarity or disconnects UF 

returns status.

=cut

sub ubat_UF {
    my $UBATcard = shift;
    my $state = shift;
    my ($mode,$cmd);
    if ($state eq "normal"){
    	$mode=1;
    	$cmd='e';    	
    }
    elsif ($state eq "reverse"){
    	$mode=2;    	
    	$cmd='e';    	
    }
    elsif ($state eq "off"){
    	$mode=1;    	
    	$cmd='a';    	
    }
    else{return -1;}
    
#UF ein normal	UxU01e/UxU01a
#UF ein verpolt	UxU02e/UxU02a

    my $command = sprintf("U0%d%s",$mode,$cmd);
 
    ($status) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
    
}

=head2 ubat_connect -> to test

    $status = ubat_connect($UBATcard,$UBATline,$input,$terminal);

    e.g. $status = ubat_connect(1,2,"UBat","+");

    $input = "UBat" or "UF" 
    $terminal = "+" or "-" 

connects Ubat line 1..4 to external power source "UBat" or "UF" 

returns status.

=cut

sub ubat_connect {
    my $UBATcard = shift;
    my $UBATline = shift;
    my $input = shift;
    my $terminal = shift;
    my $mode;
    $mode=0;
    if ($input eq "UF"){
    	$mode+=1;    	
    }
    if ($terminal eq "-"){
    	$mode+=2;    	
    }
    
#Ubat 3 UF+ ein	UxU31e/UxU31a
#Ubat 3 B+ ein	UxU30e/UxU30a
#Ubat 3 UF- ein	UxU33e/UxU33a
#Ubat 3 B- ein	UxU32e/UxU32a
	# '-' = +2
	# UF = +1

    my $command = sprintf("U%d%d%s",$UBATline,$mode,'e');
 
    ($status) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
    
}

=head2 ubat_disconnect -> to test

    $status = ubat_disconnect($UBATcard,$UBATline,$input,$terminal);

    e.g. $status = ubat_disconnect(1,2,"UBat","+");

disconnects Ubat line 1..4 from external power source "UBat" or "UF" 

returns status.

=cut

sub ubat_disconnect {
    my $UBATcard = shift;
    my $UBATline = shift;
    my $input = shift;
    my $terminal = shift;
    my $mode;
    $mode=0;
    if ($input eq "UF"){
    	$mode+=1;    	
    }
    if ($terminal eq "-"){
    	$mode+=2;    	
    }

    my $command = sprintf("U%d%d%s",$UBATline,$mode,'a');

    ($status) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
    
}


=head2 ubat_get_firmware

    ($status, $firmware) = ubat_get_firmware($UBATcard);

    e.g. (0,'FW_U0042') = ubat_get_firmware(1);

reads firmware version from UBAT card

returns status.

=cut

sub ubat_get_firmware {
    my $UBATcard = shift;
    my $value;

    ($status,$value) = ubat_send_commad_wait_response($UBATcard,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}



=head2 ubat_get_HW_id

    ($status, $HW_ID) = ubat_get_HW_id($UBATcard);

    e.g. (0,'999U0042') = ubat_get_HW_id(3);

reads hardware ID from UBAT card

returns status.

=cut

sub ubat_get_HW_id {
    my $UBATcard = shift;
    my $value;

    ($status,$value) = ubat_get_INFO($UBATcard,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 ubat_get_INFO

    ($status, $INFO) = ubat_get_INFO($UBATcard,$keyword);

    e.g. (0,'999U0042') = ubat_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from UBAT card

returns status.

=cut

sub ubat_get_INFO {
    my $UBATcard = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = ubat_send_commad_wait_response($UBATcard,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}


=head2 ubat_LV124 OBSOLETE

    $status = ubat_LV124($UBATcard,$fault_type);

    $fault_type may be
     1: S1 closed, S2 open, R=100K  Step 10us
     2: S1 closed, S2 open, R=100K  Step 100us
     3: S1 closed, S2 open, R=100K  Step 1ms
     4: S1 closed, S2 open, R=100K  Step 10ms
     5: S1 closed, S2 open, R=100K  Step 100ms
     6: S1 closed, S2 inverted to S1, R=10K  Step 10us
     7: S1 closed, S2 inverted to S1, R=10K  Step 100us
     8: S1 closed, S2 inverted to S1, R=10K  Step 1ms
     9: S1 closed, S2 inverted to S1, R=10K  Step 10ms
    10: S1 closed, S2 inverted to S1, R=10K  Step 100ms
    11: S1 closed, S2 open, R=0.1R  Step 10us
    12: S1 closed, S2 open, R=0.1R  Step 100us
    13: S1 closed, S2 open, R=0.1R  Step 1ms
    14: S1 closed, S2 open, R=0.1R  Step 10ms
	15: S1 closed, S2 open, R=0.1R  Step 100ms

starts LV124 fault simulation on UBAT (S1,S2,T1). Returns after sequence is over.
todo: change timeout value in driver !!!

=cut

sub ubat_LV124 {
	my $UBATcard = shift;
    my $fault_type = shift;
    
    my $command = sprintf("L%02d",$fault_type);

    ($status) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
	
}


=head2 ubat_LV124_startup_time OBSOLETE

    $status = bl_LV124($UBATcard,$startup_time);

    $startup_time in millisec (100 ms step)

set LV124 fault simulation time to wait after fault until system is started again (T2)

=cut

sub ubat_LV124_startup_time {
	my $UBATcard = shift;
    my $startup_time = shift;
    
    $startup_time=$startup_time/100; # convert to 100ms scale
    
    my $command = sprintf("S%03d",$startup_time);

    ($status) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
	
}


=head2 ubat_LV124_E10

    $status = ubat_LV124_E10($UBATcard,$fault_type,$offtime_us);

    $fault_type may be
	 1: S1 closed, S2 open, R=100K
	 2: S1 closed, S2 inverted to S1, R=10K
	 3: S1 closed, S2 open, R=0.1R

    $offtime_us in microseconds
 
Starts LV124 E-10 fault simulation on UF input (S1,S2,R). Returns after microcut is over.

requires ubat_UF called before once to have an effect

=cut

sub ubat_LV124_E10 {
	my $UBATcard = shift;
    my $fault_type = shift;
    my $offtime_us = shift;
    
    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%02X%08X",$fault_type,$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s",join('',@bytes));

    ($status) = ubat_send_commad_wait_response( $UBATcard,$command,int($offtime_us/1000+$MAXtimeout) ) ;
    
    return ($status);
	
}

=head2 ubat_microcut

    $status = ubat_microcut($UBATcard,$fault_type,$offtime_us);

    $fault_type may be
		 0	Ubat 1 B+ off
		 1	Ubat 1 UF+ off
		 2	Ubat 1 B- off
		 3	Ubat 1 UF- off
		 4	Ubat 2 B+ off
		 5	Ubat 2 UF+ off
		 6	Ubat 2 B- off
		 7	Ubat 2 UF- off
		 8	Ubat 3 B+ off
		 9	Ubat 3 UF+ off
		10	Ubat 3 B- off
		11	Ubat 3 UF- off
		12	Ubat 4 B+ off
		13	Ubat 4 UF+ off
		14	Ubat 4 B- off
		15	Ubat 4 UF- off


    $offtime_us in microseconds
	NOTE: 10 us is the minimum time technically possible
 
Starts micro interruption fault simulation on input. Returns after microcut is over.

requires ubat_connect called for that line before to have an effect

=cut

sub ubat_microcut {
	my $UBATcard = shift;
    my $fault_type = shift;
    my $offtime_us = shift;
    
    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%02X%08X",$fault_type,$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("F%s",join('',@bytes));

    ($status) = ubat_send_commad_wait_response( $UBATcard,$command,int($offtime_us/1000+$MAXtimeout) );
    
    return ($status);
	
}


=head2 ubat_set_event_delay

    $status = ubat_set_event_delay($UBATcard,$delay);

    e.g. $status = ubat_set_event_delay(1,1.7);

    $delay between 0 .. 99 millisec step 0.1 millisec 

sets delay on Ubat card for ubat_set_event_trigger

returns status.

=cut

sub ubat_set_event_delay {
    my $UBATcard = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%03d",$delay*10);
    ($status,$receive_ID) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
    
}


=head2 ubat_set_event_trigger

    $status = ubat_set_event_trigger($UBATcard,$event,$on_off);

    e.g. $status = ubat_set_event_trigger(1,10,'a');

    $event between 0 .. 43

     0 - no fault
	01 - UF normal on/off
	02 - UF reverse on/off
	10 - Ubat 1 B+ on/off
	11 - Ubat 1 UF+ on/off
	12 - Ubat 1 B- on/off
	13 - Ubat 1 UF- on/off
	20 - Ubat 2 B+ on/off
	21 - Ubat 2 UF+ on/off
	22 - Ubat 2 B- on/off
	23 - Ubat 2 UF- on/off
	30 - Ubat 3 B+ on/off
	31 - Ubat 3 UF+ on/off
	32 - Ubat 3 B- on/off
	33 - Ubat 3 UF- on/off
	40 - Ubat 4 B+ on/off
	41 - Ubat 4 UF+ on/off
	42 - Ubat 4 B- on/off
	43 - Ubat 4 UF- on/off
	
	$on_off: a = off, e = on

sets event trigger mode on Ubat card.

returns status.

=cut

sub ubat_set_event_trigger {
    my $UBATcard = shift;
    my $event = shift;
    my $on_off = shift;
    my $command;
    
    $command = sprintf("E%02d%s",$event,$on_off);
    ($status,$receive_ID) = ubat_send_commad_wait_response($UBATcard,$command);
    
    return ($status);
}

=head2 ubat_bootloader_mode

    $status = ubat_bootloader_mode($UBATcard);

    e.g. $status = ubat_bootloader_mode(1);

sets UBAT card to bootloader mode for firmware update

returns status.

=cut

sub ubat_bootloader_mode {
    my $UBATcard = shift;
    my ($value);

    ($status,$value) = ubat_send_commad_wait_response($UBATcard,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}


=head2 ubat_lock_display

    ($status) = ubat_lock_display($UBATcard);

    e.g. (0) = ubat_lock_display(3);

lock display on UBAT card to avoid wait times due to display update.

returns status.

=cut

sub ubat_lock_display {
    my $UBATcard = shift;
    my $value;

    ($status,$value) = ubat_send_commad_wait_response($UBATcard,'C99');
    
    return ($status);
    
}

=head2 ubat_unlock_display

    ($status) = ubat_unlock_display($UBATcard);

    e.g. (0) = ubat_unlock_display(3);

unlock display on UBAT card.

returns status.

=cut

sub ubat_unlock_display {
    my $UBATcard = shift;
    my $value;

    ($status,$value) = ubat_send_commad_wait_response($UBATcard,'C00');
    
    return ($status);
    
}


=head2 ubat_write_SN

    $status = ubat_write_SN($UBATcard,$serial_number);

    e.g. $status = ubat_write_SN(3,'999U0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub ubat_write_SN {
    my $UBATcard = shift;
    my $SN = shift;

    $status = ubat_write_EE($UBATcard,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 ubat_write_TST

    $status = ubat_write_TST($UBATcard,$TST_date);

    e.g. $status = ubat_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub ubat_write_TST {
    my $UBATcard = shift;
    my $TST_date = shift;

    $status = ubat_write_EE($UBATcard,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 ubat_write_CAL

    $status = ubat_write_CAL($UBATcard,$CAL_date);

    e.g. $status = ubat_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub ubat_write_CAL {
    my $UBATcard = shift;
    my $CAL_date = shift;

    $status = ubat_write_EE($UBATcard,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}

=head2 ubat_write_EE not exported

    $status = ubat_write_EE($UBATcard,$EEslot,$text);

    e.g. $status = ubat_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub ubat_write_EE {
    my $UBATcard = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,undef,$receive_ID) = ubat_send_commad_wait_response($UBATcard,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "UBAT_$UBATcard" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 ubat_send_commad_wait_response

    ($stat,$ret,$receive_ID) = ubat_send_commad_wait_response($UBATcard,$ASCII_command,[$timeout]);

    $timeout is optional, default is $MAXtimeout
    
Transmits the string $data on the CAN to ubat card

returns status and answer string as ASCII.

=cut

sub ubat_send_commad_wait_response {
    my $UBATcard = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($byte,$offset,$data_aref);

	$offset=(($UBATcard-1) * 2); 
	
    my $send_ID = UBAT_base_address+$offset;   

    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("U%d%s",$UBATcard,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
    	$status = tsg4_check_CAN_status( $CANstatus, "UBAT_$UBATcard" );
        return ($status,'',$receive_ID);
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response),$receive_ID);
    
}


=head2 ubat_send_commad

    ($stat,$receive_ID) = ubat_send_commad($UBATcard,$ASCII_command);

    e.g. ($status,$receive_ID) = ubat_send_commad(1,'?00');

Transmits the string $data on the CAN to ubat card

returns status and answer ID.

=cut

sub ubat_send_commad {
    my $UBATcard = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

	$offset=(($UBATcard-1) * 2);

    my $send_ID = UBAT_base_address+$offset;   

    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("U%d%s",$UBATcard,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "UBAT_$UBATcard" );
    return ($status,$receive_ID);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



