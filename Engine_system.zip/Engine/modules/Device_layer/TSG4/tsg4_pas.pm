package tsg4_pas;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    pas_send_commad
    pas_send_commad_wait_response
    pas_get_firmware
    pas_get_HW_id
    pas_get_INFO
    pas_bootloader_mode
    pas_write_name
    pas_write_SN
    pas_write_TST
    pas_write_CAL
    pas_connect
    pas_disconnect
    pas_connect_via
    pas_disconnect_via
    pas_LV124
    pas_microcut
    pas_set_event_delay
    pas_set_event_trigger
    pas_swap
    pas_lock_display
    pas_unlock_display

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

PAS Control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 pas_connect

    $status = pas_connect($PASbank,$PASnumber);

    e.g. $status = pas_connect(3,2);
    
    $PASnumber 1..4

connects PAS

returns status.

=cut

sub pas_connect {
    my $PASbank = shift;
    my $PASnumber = shift;

    my $command = sprintf("U%02d%s",$PASnumber,'a');
 
    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
    
    return ($status);
    
}

=head2 pas_disconnect

    $status = pas_disconnect($PASbank,$PASnumber);

    e.g. $status = pas_disconnect(3,2);

disconnects PAS (open line)

returns status.

=cut

sub pas_disconnect {
    my $PASbank = shift;
    my $PASnumber = shift;

    my $command = sprintf("U%02d%s",$PASnumber,'e');

    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
    
    return ($status);
    
}

=head2 pas_microcut

    $status = pas_microcut($PASbank,$PASnumber,$offtime_us);

    e.g. $status = pas_microcut(3,1,100);

    $offtime_us in microseconds

starts microcut (LV124) fault simulation on PAS 1 of given bank.

=cut

sub pas_microcut {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $offtime_us = shift;
    
    if($PASnumber == 1) { 
	    #convert value to ascii string which represents the hex value for $offtime_us
	    my $hexstring = sprintf("%08X",$offtime_us);
	    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
	    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
	    
	    my $command = sprintf("M%s",join('',@bytes));
    	my $timeout=int($offtime_us/1000)+1000;
    	
	    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command,$timeout);
	    
	    return ($status);
    }
    else{
    	return -100;
    }
    
}

=head2 pas_write_name

    $status = pas_write_name($PASbank,$name);

    e.g. $status = pas_write_name(3,'PPSD');

    $name length <= 8 

writes name to card to be displayed.

=cut

sub pas_write_name {
    my $PASbank = shift;
    my $name = shift;
    my ($receive_ID);

    ($status,undef,$receive_ID) = pas_send_commad_wait_response($PASbank,'N');

#    printf( "-> 0x%02x $name\n",$receive_ID-1);
    
    my @bytes = split(//, $name);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "PAS_$PASbank" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}



=head2 pas_get_firmware

    ($status, $firmware) = pas_get_firmware($PASbank);

    e.g. (0,'Ver 1.0') = pas_get_firmware(3);

reads firmware version from PAS card

returns status.

=cut

sub pas_get_firmware {
    my $PASbank = shift;
    my $value;

    ($status,$value) = pas_send_commad_wait_response($PASbank,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 pas_get_HW_id

    ($status, $HW_ID) = pas_get_HW_id($PASbank);

    e.g. (0,'999D0042') = pas_get_HW_id(3);

reads hardware ID PAS scanner card

returns status.

=cut

sub pas_get_HW_id {
    my $PASbank = shift;
    my $value;

    ($status,$value) = pas_get_INFO($PASbank,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 pas_get_INFO

    ($status, $INFO) = pas_get_INFO($PASbank,$keyword);

    e.g. (0,'999T0042') = pas_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from PAS card

returns status.

=cut

sub pas_get_INFO {
    my $PASbank = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = pas_send_commad_wait_response($PASbank,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}


=head2 pas_lock_display

    ($status) = pas_lock_display($PASbank);

    e.g. (0) = pas_lock_display(3);

lock display on PAS card to avoid wait times due to display update.

returns status.

=cut

sub pas_lock_display {
    my $PASbank = shift;
    my $value;

    ($status,$value) = pas_send_commad_wait_response($PASbank,'C99');
    
    return ($status);
    
}

=head2 pas_unlock_display

    ($status) = pas_unlock_display($PASbank);

    e.g. (0) = pas_unlock_display(3);

unlock display on PAS card.

returns status.

=cut

sub pas_unlock_display {
    my $PASbank = shift;
    my $value;

    ($status,$value) = pas_send_commad_wait_response($PASbank,'C00');
    
    return ($status);
    
}

=head2 pas_LV124

    $status = pas_LV124($PASbank,$PASnumber,$fault_type);

    e.g. $status = pas_LV124(1,1,4);

    $PASnumber between 1 .. 4

    $fault_type between 0 .. 5 
    0 - no fault
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on PAS. This will work only on PAS1

=cut

sub pas_LV124 {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $fault_type = shift;

    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);

    if(($PASbank & 0x01) ==0) {$fault_type+=5;}

    if($PASnumber == 1) { } # take normal fault type
    else{$fault_type = 0;} # skip fault

    my $command = sprintf("L%02d",$fault_type);
    


    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command,$timeout);
    
    return ($status);
    
}

=head2 pas_bootloader_mode

    $status = pas_bootloader_mode($PASbank);

    e.g. $status = pas_bootloader_mode(1);

sets PAS card to bootloader mode for firmware update

returns status.

=cut

sub pas_bootloader_mode {
    my $PASbank = shift;
    my ($value);

    ($status,$value) = pas_send_commad_wait_response($PASbank,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 pas_connect_via

    $status = pas_connect_via($PASbank,$PASnumber,$terminal,$via);

    e.g. $status = pas_connect_via(3,1,'+',1); # connect PAS_3_1+ to ref1

connect PAS terminal to reference line

returns status.

=cut

sub pas_connect_via {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2+$via+($PASnumber-1)*4;
    }
    elsif ($terminal eq "-"){
        $command=0+$via+($PASnumber-1)*4;
    }
    else{return (-1);}

#01  PAS1- Bezug1
#02  PAS1- Bezug2
#03  PAS1+ Bezug1
#04  PAS1+ Bezug2
#05  PAS2- Bezug1
#...

	$command = sprintf("B%02d%s",$command,'e');
    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
#    print("pas_connect_via ($PASbank $PASnumber $terminal ref $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 pas_disconnect_via

    $status = pas_disconnect_via($PASbank,$PASnumber,$terminal,$via);

    e.g. $status = pas_disconnect_via(3,1,'+',1); # disconnect PAS_3_1+ from ref1

disconnect PAS terminal from reference line

returns status.

=cut

sub pas_disconnect_via {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2+$via+($PASnumber-1)*4;
    }
    elsif ($terminal eq "-"){
        $command=0+$via+($PASnumber-1)*4;
    }
    else{return (-1);}

#01  PAS1- Bezug1
#02  PAS1- Bezug2
#03  PAS1+ Bezug1
#04  PAS1+ Bezug2
#05  PAS2- Bezug1
#...

	$command = sprintf("B%02d%s",$command,'a');
	($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
#    print("pas_disconnect_via ($PASbank $PASnumber $terminal ref $via -> $command) $status\n");
    
    return ($status);
    
}


=head2 pas_set_event_delay

    $status = pas_set_event_delay($PASbank,$PASnumber,$delay);

    e.g. $status = pas_set_event_delay(3,1,1.7);

    $delay between 0 .. 9.9 millisec step 0.1 millisec 

sets delay on PAS card for pas_set_event_trigger

returns status.

=cut

sub pas_set_event_delay {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%02d",$delay*10);
    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
    
    return ($status);
    
}


=head2 pas_set_event_trigger

    $status = pas_set_event_trigger($PASbank,$PASnumber,$fault_type);

    e.g. $status = pas_set_event_trigger(3,1,1);

    $fault_type between 0 .. 15 

     0 - no fault
     1 - interruption
     2 - PAS- to ref1
     3 - PAS- to ref2
     4 - PAS+ to ref1
     5 - PAS+ to ref2
    11 - LV124 10sec interruption
    12 - LV124 1ms   interruption
    13 - LV124 100us interruption
    14 - LV124 1us   interruption 1ms pause with 4 sec cycle
    15 - LV124 100us interruption 1ms pause with 4 sec cycle

sets event trigger mode on PAS card

returns status.

=cut

sub pas_set_event_trigger {
    my $PASbank = shift;
    my $PASnumber = shift;
    my $fault_type = shift;
    my $command;
    my $value = 0;
    
    if ($fault_type == 1){
        $value = $PASnumber;
        if(($PASbank & 0x01) ==0) {$value+=4;}
    }
    elsif ($fault_type > 10 and $fault_type < 16){
        $value = $fault_type+30;
        if(($PASbank & 0x01) ==0) {$value+=5;}
        $value = 0 if ($PASnumber != 1);
    }
    elsif ($fault_type > 1 and $fault_type < 6){
        $value = $PASnumber+8;
        $value += ($fault_type-2)*4;
        if(($PASbank & 0x01) ==0) {$value+=16;}
    }
    else{
        $value = 0;
    }
    
    $command = sprintf("E%02d",$value);
    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
    
    return ($status);
    
}

=head2 pas_swap

    $status = pas_swap($PASbank,$on_off);

    e.g. $status = pas_swap(3,1);
    
    $on_off: 1 = on, anything else = off

swap PAS 1_1 and 2_1 on pas card (e.g. $PASbank 3 or 4 will have same effect)

returns status.

=cut

sub pas_swap {
    my $PASbank = shift;
    my $on_off = shift;
    my $command;
    if ($on_off == 1){
        $command = "V01e";
    }
    else{
        $command = "V01a";
    }

    ($status,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);
    
    return ($status);
    
}


=head2 pas_write_SN

    $status = pas_write_SN($PASbank,$serial_number);

    e.g. $status = pas_write_SN(3,'999P0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub pas_write_SN {
    my $PASbank = shift;
    my $SN = shift;

    $status = pas_write_EE($PASbank,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 pas_write_TST

    $status = pas_write_TST($PASbank,$TST_date);

    e.g. $status = pas_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub pas_write_TST {
    my $PASbank = shift;
    my $TST_date = shift;

    $status = pas_write_EE($PASbank,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 pas_write_CAL

    $status = pas_write_CAL($PASbank,$CAL_date);

    e.g. $status = pas_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub pas_write_CAL {
    my $PASbank = shift;
    my $CAL_date = shift;

    $status = pas_write_EE($PASbank,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}

=head2 pas_write_EE not exported

    $status = pas_write_EE($PASbank,$EEslot,$text);

    e.g. $status = pas_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub pas_write_EE {
    my $PASbank = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,undef,$receive_ID) = pas_send_commad_wait_response($PASbank,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "PAS_$PASbank" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 pas_send_commad_wait_response

    ($stat,$ret,$receive_ID) = pas_send_commad_wait_response($PASbank,$ASCII_command [,$timeout] );

	$timeout is optional, default is $MAXtimeout

Transmits the string $data on the CAN to rack controller

returns status and answer string as ASCII.

=cut

sub pas_send_commad_wait_response {
    my $PASbank = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$offset,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;
    
    if(($PASbank & 0x01) ==1) {$offset=($PASbank+1)-2;}
    else {$offset=$PASbank-2;}

    my $send_ID = PAS_base_address+$offset;   

    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("P%02d%s",$PASbank,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
    	$status = tsg4_check_CAN_status( $CANstatus, "PAS_$PASbank" );
        return ($status,'error',$receive_ID);
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response),$receive_ID);
    
}


=head2 pas_send_commad

    ($stat,$receive_ID) = pas_send_commad($PASbank,$ASCII_command);

    e.g. ($status,$receive_ID) = pas_send_commad(3,'?00');

Transmits the string $data on the CAN to rack controller

returns status and answer ID.

=cut

sub pas_send_commad {
    my $PASbank = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

    if(($PASbank & 0x01) ==1) {$offset=($PASbank+1)-2;}
    else {$offset=$PASbank-2;}

    my $send_ID = PAS_base_address+$offset;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("P%02d%s",$PASbank,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "PAS_$PASbank" );
    return ($status,$receive_ID);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



