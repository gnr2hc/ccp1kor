package tsg4_via;

use strict;
use warnings;
use tsg4;
use TSG4CAN;
use LIFT_simulation;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    via_bootloader_mode
    via_get_firmware
    via_get_HW_id
    via_get_INFO
    via_lock_display
    via_LV124
    via_send_commad
    via_send_commad_wait_response
    via_set_event_delay
    via_set_event_trigger
    via_unlock_display
	via_read_OP_offset
    via_write_OP_offset
    via_write_CAL
    via_write_SN
    via_write_TST
	via_connect_OP
	via_disconnect_OP
	via_set_OP_voltage
	via_set_Rdecade
	via_connect_Rdecade
	via_disconnect_Rdecade
	via_connect_REF
	via_disconnect_REF
	via_set_SIM_return_text
);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;

# get HW id stored data and get firmware stores data
# $via_info = {cardNR => {HW => yyyBxxxx, FW => FW_Bzzzz}
our $via_info;

our @ASCII_commands; # ascii commands sent to card for simulation testing

############################################################################################################

=head1 DESCRIPTION

RFE Control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 via_get_firmware

    ($status, $firmware) = via_get_firmware($REFcard);

    e.g. (0,'Ver 1.0') = via_get_firmware(1);

reads firmware version from PAS card

returns status.

=cut

sub via_get_firmware {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'?10');
#    print("firmware $value\n");
    
    $via_info->{$REFcard}{'FW'}=$value;
    return ($status,$value);
    
}



=head2 via_get_HW_id

    ($status, $HW_ID) = via_get_HW_id($REFcard);

    e.g. (0,'999B0042') = via_get_HW_id(1);

reads hardware ID from UBAT card

returns status.

=cut

sub via_get_HW_id {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_get_INFO($REFcard,'SN');
#    print("HW ID $value\n");

    $via_info->{$REFcard}{'HW'}=$value;
    return ($status,$value);
    
}

=head2 via_get_INFO

    ($status, $INFO) = via_get_INFO($REFcard,$keyword);

    e.g. (0,'999B0042') = via_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from REF card

returns status.

=cut

sub via_get_INFO {
    my $REFcard = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}




=head2 via_LV124

    $status = via_LV124($REFcard,$fault_type);

    $fault_type may be
     0 - no fault
     1 - R-decade 10sec interruption
     2 - R-decade 1ms   interruption
     3 - R-decade 100us interruption
     4 - R-decade 1us   interruption 1ms pause with 4 sec cycle
     5 - R-decade 100us interruption 1ms pause with 4 sec cycle
     6 - op-amp 10sec interruption
     7 - op-amp 1ms   interruption
     8 - op-amp 100us interruption
     9 - op-amp 1us   interruption 1ms pause with 4 sec cycle
    10 - op-amp 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on REF card

=cut

sub via_LV124 {
    my $REFcard = shift;
    my $fault_type = shift;

    my $timeout=5000;
    $timeout = 11000 if ($fault_type == 1 or $fault_type == 6);
    
    my $command = sprintf("L%02d",$fault_type);

    ($status) = via_send_commad_wait_response($REFcard,$command,$timeout);
    
    return ($status);
    
}


=head2 via_set_event_delay

    $status = via_set_event_delay($REFcard,$delay);

    e.g. $status = via_set_event_delay(1,1.7);

    $delay between 0 .. 99 millisec step 0.1 millisec 

sets delay on REF card for via_set_event_trigger

returns status.

=cut

sub via_set_event_delay {
    my $REFcard = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("P%03d",$delay*10);
    ($status,$receive_ID) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
    
}


=head2 via_set_event_trigger

    $status = via_set_event_trigger($REFcard,$event);

    e.g. $status = via_set_event_trigger(1,10);

    $event between 0 .. 20

     0 - no fault

	01 - Dekade ein
	02 - Dekade aus
	03 - Spannungsversatz ein
	04 - Spannungsversatz aus
	05 - Bezug 1/2 aus
	06 - Bezug 2 auf B+
	07 - Bezug 2 auf B-
	08 - Bezug 1 auf UF+
	09 - Bezug 1 auf UF-
	10 - 
	11 - R-Dekade Unterbrechung f�r 10 sec.
	12 - R-Dekade Unterbrechung f�r 1ms ohne Relais
	13 - R-Dekade Unterbrechung f�r 100us mit Relais
	14 - R-Dekade Unterbrechung 1us  Pause 1ms  Zyklus 4sec. 
	15 - R-Dekade Unterbrechung 100us Pause 1ms  Zyklus 4sec. 
	16 - OP-Spannung Unterbrechung f�r 10 sec.
	17 - OP-Spannung Unterbrechung f�r 1ms ohne Relais
	18 - OP-Spannung Unterbrechung f�r 100us mit Relais
	19 - OP-Spannung Unterbrechung 1us  Pause 1ms  Zyklus 4sec. 
	20 - OP-Spannung Unterbrechung 100us Pause 1ms  Zyklus 4sec. 


sets event trigger mode on REF card.

returns status.

=cut

sub via_set_event_trigger {
    my $REFcard = shift;
    my $event = shift;
    my $command;
    
    $command = sprintf("E%02d",$event);
    ($status,$receive_ID) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
}



=head2 via_bootloader_mode

    $status = via_bootloader_mode($REFcard);

    e.g. $status = via_bootloader_mode(1);

sets REF card to bootloader mode for firmware update

returns status.

=cut

sub via_bootloader_mode {
    my $REFcard = shift;
    my ($value);

    ($status,$value) = via_send_commad_wait_response($REFcard,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}


=head2 via_lock_display

    ($status) = via_lock_display($REFcard);

    e.g. (0) = via_lock_display(1);

lock display on REF card to avoid wait times due to display update.

returns status.

=cut

sub via_lock_display {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'C99');
    
    return ($status);
    
}

=head2 via_unlock_display

    ($status) = via_unlock_display($REFcard);

    e.g. (0) = via_unlock_display(1);

unlock display on REF card.

returns status.

=cut

sub via_unlock_display {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'C00');
    
    return ($status);
    
}

=head2 via_write_OP_offset

    ($status) = via_write_OP_offset($REFcard,$offset_correction);

    e.g. (0) = via_write_OP_offset(1,2747);

	$offset_correction +1 ==> OP_voltage -10 mV

write OP offset correction value to card.

returns status.

=cut

sub via_write_OP_offset {
    my $REFcard = shift;
    my $offset_correction = shift;
    my $value;
    my $command = sprintf("O%04d",$offset_correction);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
    
}

=head2 via_read_OP_offset

    ($status,$offset_correction) = via_read_OP_offset($REFcard);

    e.g. (0,2747) = via_read_OP_offset(1);

read OP offset correction value from card.

returns status.

=cut

sub via_read_OP_offset {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'?18');
    #print("OP_offset $value\n");
    
    return ($status,$value);
    
}


=head2 via_connect_OP

    ($status) = via_connect_OP($REFcard);

    e.g. (0) = via_connect_OP(1);

connect OP for voltage offset.

returns status.

=cut

sub via_connect_OP {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'U01e');
    
    return ($status);
}

   
=head2 via_disconnect_OP

    ($status) = via_disconnect_OP($REFcard);

    e.g. (0) = via_disconnect_OP(1);

disconnect OP for voltage offset.

returns status.

=cut

sub via_disconnect_OP {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'U01a');
    
    return ($status);
}


=head2 via_set_OP_voltage

    ($status) = via_set_OP_voltage($REFcard,$voltage);

    e.g. (0) = via_set_OP_voltage(1,-5);

	$voltage +10 .. -10 V step 0.01 V

set voltage offset on OP.

returns status.

=cut

sub via_set_OP_voltage {
	#BxVuuuu+,BxVuuuu-

    my $REFcard = shift;
    my $voltage = shift;
    my $value;
	my $sign = '+';
	$sign = '-' if ($voltage < 0);

    my $command=sprintf("V%04d%s",abs($voltage)*100,$sign);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
}

=head2 via_connect_Rdecade

    ($status) = via_connect_Rdecade($REFcard);

    e.g. (0) = via_connect_Rdecade(1);

connect resistor decade for leakage resistor.

returns status.

=cut

sub via_connect_Rdecade {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'D01e');
    
    return ($status);
}


=head2 via_disconnect_Rdecade

    ($status) = via_disconnect_Rdecade($REFcard);

    e.g. (0) = via_disconnect_Rdecade(1);

disconnect resistor decade for leakage resistor.

returns status.

=cut

sub via_disconnect_Rdecade {
    my $REFcard = shift;
    my $value;

    ($status,$value) = via_send_commad_wait_response($REFcard,'D01a');
    
    return ($status);
}


=head2 via_set_Rdecade

    ($status) = via_set_Rdecade($REFcard,$resistance);

    e.g. (0) = via_set_Rdecade(1,200);

	$resistance 0 .. 99999 Ohm step 1 Ohm for lot > 3 e.g. 004B0001
	$resistance 0 ..  9999 Ohm step 1 Ohm for lot < 4 e.g. 002B0007

set resistor decade for leakage resistor.

returns status.

=cut

sub via_set_Rdecade {

    my $REFcard = shift;
    my $resistance = shift;
    my $value;
    my $MAXresistor = 9999; # default for old HW then maxvalue is 9999

	# read HW and FW if not in data 
	unless (defined $via_info->{$REFcard}{'FW'}){
		($status) = via_get_firmware($REFcard);		
	}
	unless (defined $via_info->{$REFcard}{'HW'}){
		($status) = via_get_HW_id($REFcard);
	}

	# check if new HW then maxvalue is 99999
    if ($via_info->{$REFcard}{'HW'} =~ /^(\d{3})\w\d{4}$/){
    	my $lot = $1;
        if ($lot > 3){
			$MAXresistor = 99999;
        }
    }	
    else{
	      tsg4_set_error("could not determine HW version from <$via_info->{$REFcard}{'HW'}>");
	      return -1;
    }

	#error if $resistance > maxresistor
	if ($resistance > $MAXresistor){
	      tsg4_set_error("resistance out of range ($resistance > $MAXresistor) for $via_info->{$REFcard}{'HW'}");
	      return -1;
	}

	# check if old FW, then value *10 (only 1st 4 digits will be read by firmware)
    if ($via_info->{$REFcard}{'FW'} =~ /^FW_\w(\d{4})$/){
    	my $firmware = $1;
        if ($firmware < 3){
			$resistance = $resistance * 10;
        }
    }
    else{
	      tsg4_set_error("could not determine firmware version form <$via_info->{$REFcard}{'FW'}> for $via_info->{$REFcard}{'HW'}");
	      return -1;
    }

    my $command=sprintf("W%05d",$resistance);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
}


=head2 via_connect_REF

    ($status) = via_connect_REF($REFcard,$connection_type);

    e.g. (0) = via_connect_REF(1,2);

	$connection_type between 0 .. 4

	0 - no connection
	1 - REF 2 on UF+
	2 - REF 2 on UF-
	3 - REF 1 on B+
	4 - REF 1 on B-

connect reference line to power source.

returns status.

=cut

sub via_connect_REF {

    my $REFcard = shift;
    my $connection_type = shift;
    my $value;

    my $command=sprintf("B%02de",$connection_type);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
}


=head2 via_disconnect_REF

    ($status) = via_disconnect_REF($REFcard,$connection_type);

    e.g. (0) = via_disconnect_REF(1,2);

	$connection_type between 0 .. 4

	0 - no connection
	1 - REF 2 on B+
	2 - REF 2 on B-
	3 - REF 1 on UF+
	4 - REF 1 on UF-

disconnect reference line from power source.

returns status.

=cut

sub via_disconnect_REF {

    my $REFcard = shift;
    my $connection_type = shift;
    my $value;

    my $command=sprintf("B%02da",$connection_type);

    ($status,$value) = via_send_commad_wait_response($REFcard,$command);
    
    return ($status);
}


=head2 via_write_SN

    $status = via_write_SN($REFcard,$serial_number);

    e.g. $status = via_write_SN(1,'999U0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub via_write_SN {
    my $REFcard = shift;
    my $SN = shift;

    $status = via_write_EE($REFcard,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 via_write_TST

    $status = via_write_TST($REFcard,$TST_date);

    e.g. $status = via_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub via_write_TST {
    my $REFcard = shift;
    my $TST_date = shift;

    $status = via_write_EE($REFcard,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 via_write_CAL

    $status = via_write_CAL($REFcard,$CAL_date);

    e.g. $status = via_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub via_write_CAL {
    my $REFcard = shift;
    my $CAL_date = shift;

    $status = via_write_EE($REFcard,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}

=head2 via_write_EE not exported

    $status = via_write_EE($REFcard,$EEslot,$text);

    e.g. $status = via_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub via_write_EE {
    my $REFcard = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,undef,$receive_ID) = via_send_commad_wait_response($REFcard,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "REF_$REFcard"  );
    tsg4_wait_ms(5);
    
    return ($status);
    
}


################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 via_send_commad_wait_response

    ($stat,$ret,$receive_ID) = via_send_commad_wait_response($REFcard,$ASCII_command,[$timeout]);

    $timeout is optional, default is $MAXtimeout

Transmits the string $data on the CAN to REF card

returns status and answer string as ASCII.

=cut

sub via_send_commad_wait_response {
    my $REFcard = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($byte,$offset,$data_aref);

	$offset=(($REFcard-1) * 2);

    my $send_ID = VIA_base_address+$offset;   

    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("B%d%s",$REFcard,$ASCII_command);
    push (@ASCII_commands,$ASCII_command) if ( $main::opt_simulation );
# printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "REF_$REFcard"  );
        return ($status,'error',$receive_ID);
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }

#print "<- ".join('',@response)."\n";
    return (0,join('',@response),$receive_ID);
    
}


=head2 via_send_commad

    ($stat,$receive_ID) = via_send_commad($REFcard,$ASCII_command);

    e.g. ($status,$receive_ID) = via_send_commad(1,'?00');

Transmits the string $data on the CAN to REF card

returns status and answer ID.

=cut

sub via_send_commad {
    my $REFcard = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

	$offset=(($REFcard-1) * 2);

    my $send_ID = VIA_base_address+$offset;   

    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("B%d%s",$REFcard,$ASCII_command);
    push (@ASCII_commands,$ASCII_command) if ( $main::opt_simulation );
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "REF_$REFcard"  );
    return ($status,$receive_ID);
    
}



=head2 via_set_SIM_return_text

 via_set_SIM_return_text( $REFcard, $ASCII_command, $text )
 e.g. 	via_set_SIM_return_text(1, '?02', "004B0009");

 set return value for next tsg4can_SendAndWaitForResponse call, this is used for simulation testing

=cut

sub via_set_SIM_return_text{
    my $REFcard = shift;
    my $ASCII_command = shift;   
    my $text = shift; 

    my ($byte,$offset);
	$offset=(($REFcard-1) * 2);
    my $send_ID = VIA_base_address+$offset;   
    my $receive_ID = $send_ID+1;   
	
    $ASCII_command = sprintf("B%d%s",$REFcard,$ASCII_command);
    	
    my @bytes = split(//,$text);
    foreach my $byte (@bytes){
    	$byte = ord($byte);
    }
    my @request = split(//,$ASCII_command);
    foreach my $byte (@request){
    	$byte = ord($byte);
    }
    while (scalar(@request)<8){
        push (@request,0);
    }
    unshift (@request,8);

    SIM_setReturnValues('tsg4can_SendAndWaitForResponse', [ 0, \@bytes ], [\@request, $send_ID, $send_ID+1, $MAXtimeout]);
}

1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



