package tsg4_dvm;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    dvm_send_commad
    dvm_send_commad_wait_response
    dvm_reset
    dvm_connect_hi
    dvm_connect_lo
    dvm_bootloader_mode
    dvm_get_firmware
    dvm_get_HW_id
    dvm_write_SN
    dvm_write_TST
    dvm_write_CAL
	dvm_get_INFO

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

DVM scanner control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 dvm_reset

    $status = dvm_reset($DVMnumber);

    e.g. $status = dvm_reset(3);

resets DVM scanner (disconnect hi and lo inputs)

returns status.

=cut

sub dvm_reset {
    my $DVMnumber = shift;

    my $command = "R01";

    ($status,$receive_ID) = dvm_send_commad_wait_response($DVMnumber,$command);
    
    return ($status);
    
}

=head2 dvm_connect_hi

    $status = dvm_connect_hi($DVMnumber, $Hi_input);

    $Lo_input 1..64
    
    e.g. $status = dvm_connect_hi(3,3);

connects DVM scanner input $Hi_input to output DVM-Hi

returns status.

=cut

sub dvm_connect_hi {
    my $DVMnumber = shift;
    my $Hi_input = shift;

    my $command = sprintf("H%02d",$Hi_input);
    
    ($status,$receive_ID) = dvm_send_commad_wait_response($DVMnumber,$command);
    
    return ($status);
    
}

=head2 dvm_connect_lo

    $status = dvm_connect_lo($DVMnumber, $Lo_input);
    
    $Lo_input 1..44

    e.g. $status = dvm_connect_lo(3,7);

connects DVM scanner input $Lo_input to output DVM-Lo

returns status.

=cut

sub dvm_connect_lo {
    my $DVMnumber = shift;
    my $Lo_input = shift;

    my $command = sprintf("L%02d",$Lo_input);

    ($status,$receive_ID) = dvm_send_commad_wait_response($DVMnumber,$command);
    
    return ($status);
    
}


=head2 dvm_write_SN

    $status = dvm_write_SN($DVMnumber,$serial_number);

    e.g. $status = dvm_write_SN(3,'999D0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub dvm_write_SN {
    my $DVMnumber = shift;
    my $SN = shift;

    $status = dvm_write_EE($DVMnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 dvm_write_TST

    $status = dvm_write_TST($DVMnumber,$TST_date);

    e.g. $status = dvm_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub dvm_write_TST {
    my $DVMnumber = shift;
    my $TST_date = shift;

    $status = dvm_write_EE($DVMnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 dvm_write_CAL

    $status = dvm_write_CAL($DVMnumber,$CAL_date);

    e.g. $status = dvm_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub dvm_write_CAL {
    my $DVMnumber = shift;
    my $CAL_date = shift;

    $status = dvm_write_EE($DVMnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 dvm_bootloader_mode

    $status = dvm_bootloader_mode($DVMnumber);

    e.g. $status = dvm_bootloader_mode(1);

sets DVM scanner card to bootloader mode for firmware update

returns status.

=cut

sub dvm_bootloader_mode {
    my $DVMnumber = shift;
    my $value;

    ($status,$value) = dvm_send_commad_wait_response($DVMnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 dvm_get_firmware

    ($status, $firmware) = dvm_get_firmware($DVMnumber);

    e.g. (0,'Ver 1.0') = dvm_get_firmware(3);

reads firmware version from DVM scanner card

returns status.

=cut

sub dvm_get_firmware {
    my $DVMnumber = shift;
    my $value;

    ($status,$value) = dvm_send_commad_wait_response($DVMnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 dvm_get_HW_id

    ($status, $HW_ID) = dvm_get_HW_id($DVMnumber);

    e.g. (0,'999D0042') = dvm_get_HW_id(3);

reads hardware ID from DVM scanner card

returns status.

=cut

sub dvm_get_HW_id {
    my $DVMnumber = shift;
    my $value;

    ($status,$value) = dvm_get_INFO($DVMnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 dvm_get_INFO

    ($status, $INFO) = dvm_get_INFO($DVMnumber,$keyword);

    e.g. (0,'999D0042') = dvm_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from DVM scanner card

returns status.

=cut

sub dvm_get_INFO {
    my $DVMnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = dvm_send_commad_wait_response($DVMnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 dvm_write_EE not exported

    $status = dvm_write_EE($DVMnumber,$EEslot,$text);

    e.g. $status = dvm_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub dvm_write_EE {
    my $DVMnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = dvm_send_commad($DVMnumber,$command);

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "DVM_$DVMnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 dvm_send_commad_wait_response

    ($stat,$ret) = dvm_send_commad_wait_response($DVMnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to DVM scanner

returns status and answer string as ASCII.

=cut

sub dvm_send_commad_wait_response {
    my $DVMnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref);
    $timeout = $MAXtimeout unless defined $timeout;

    my $send_ID = DVM_base_address +(($DVMnumber - 1) * 2);   
    
    $ASCII_command = sprintf("D%02d%s",$DVMnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "DVM_$DVMnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 dvm_send_commad

    ($stat,$receive_ID) = dvm_send_commad($DVMnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = dvm_send_commad(3,'?00');

Transmits the string $data on the CAN to DVM scanner

returns status and answer ID.

=cut

sub dvm_send_commad {
    my $DVMnumber = shift;
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = DVM_base_address +(($DVMnumber - 1) * 2);   
    
    $ASCII_command = sprintf("D%02d%s",$DVMnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "DVM_$DVMnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



