# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_STAC;

use strict;
use warnings;
use LIFT_general;

use tsg4;
use tsg4_stac;
use Data::Dumper;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
	STAC_InitHW
	STAC_CloseHW
	STAC_ConnectLine
	STAC_DisconnectLine
	STAC_SetLogicalState
	STAC_GetNames
);


#connect will set default, disconnect will open all relays
#  SHORT could be implemented by set state for all devices



our ( $VERSION, $HEADER );

my $status;            # Variable to hold the status of operation
my $STAC_initialized;  # flag for STAC initialization

#initialize with default values
$STAC_initialized = 0;

our $STAC_labels;

my @STAC_PSlines;
my %Used_relays;

=head1 NAME

LIFT_STAC 

Perl extension for managing STAC switch card with LIFT

=head1 SYNOPSIS

  use LIFT_STAC;

  STAC_InitHW(); 


  STAC_CloseHW(); 

B<ProjectConst:>

similar structure like for TSG4, list all devices which can be maipulated by STAC

given relays will be connected, all other relays used for device will be disconnected.

       'STAC' => {
             # all Squibs which can be measured on STAC ( connected to TRC or LCT, depends on PeriBox layout)
            'MEASURED_SQUIBS' =>
                       {
                        'SQ1_Name' => 'AB1FD',
                        'SQ2_Name' => 'AB1FP',
                        'SQ3_Name' => 'BT1FD',
                        'SQ4_Name' => 'BT1FP',
                       },

             # Squibs which can be manipulated by STAC
            'SQUIBS' =>
                       {
                        'SQ1_Name' => 'AB1FD',
                        'SQ1_Default' => 'S10',

                        'SQ2_Name' => 'BT1FP',
                        'SQ2_Default' => '',
                        'SQ2_state_short2GND' => 'S11',
                       },

            'POWER_SUPPLY_LINES' =>
                       {
                        'PSL1_Name' => 'UB1',
                        'PSL1_Default' => 'S17',

                        'PSL2_Name' => 'UB2',
                        'PSL2_Default' => 'S18',
                       },

            'PAS_LINES' =>
                       {
                        'PAS_1_1_Name' => 'PPSL',
                        'PAS_1_1_Default' => 'S12',

                        'PAS_1_2_Name' => 'PPSR',
                        'PAS_1_2_Default' => 'S13',

                        'PAS_2_1_Name' => 'UFS1',
                        'PAS_2_1_Default' => 'S14',
                       },

            'BELT_LOCKS' =>
                       {
                        'BL4_Name' => 'PADS',
                        'BL4_Default' => 'S1',
                        'BL4_state_PAB_enabled' => 'S1',		# only S1 is on
                        'BL4_state_PAB_disabled' => 'S2', 		# only S2 is on
                        'BL4_state_PAB_undefined' => 'S1+S2', 	# S1 and S2 are on
                        'BL4_state_PAB_short' => 'S3', 			# only S3 is on
                        'BL4_state_PAB_open' => '', 			# S1+S2+S3 are off

                        'BL3_Name' => 'BLR2P_VW',
                        'BL3_Default' => 'S5',
                        'BL3_state_buckled' => 'S5',
                        'BL3_state_unbuckled' => 'S6',
                       },
       },


B<TestBench Config:>

     'COB409407' => {      # LIFT PC host name
            ### ----------- Device Configuration Section ------ 
            'Devices' => {
               'STAC' => {
                    'Test_Bench_Number' => 10,          # only for logging purpose
                    'Description' => "SW Test Team",    # only for logging purpose
                    'CANchannel' => 2,                  # CAN channel used to communicate with STAC (only CAN channels are counted)
                    									# CAN channel on VN box is not CH number on box! CH1 = FlexRay so CH2 = CANchannel 1
                    'CANHWSerialNo' => 30679,           # written on CAN device e.g. "007129-030679" -> 30679,
                                                        # CANHWSerialNo is optional if only one HW connected
                },
            },
     },


=head1 DESCRIPTION

The module LIFT_STAC has all the necessary functions to configure and operate STAC switch card.
The configuration should be done in LIFT ProjectConst file as given in L</SYNOPSIS>.



=head2 STAC_CloseHW

    STAC_CloseHW();

has to be called at the end, will disconnect from STAC. should be called in ENDcampaign

=cut

sub STAC_CloseHW{

    unless ( $STAC_initialized ) {
        S_set_warning( "STAC not initialized");
        return 1;
    }

    S_w2log(1,"STAC_CloseHW\n");

    if ($main::opt_offline){
        #clear the global flags
        $STAC_initialized = 0;
        return 1;
    }

    $status = tsg4_exit();
    Check_status($status);
    S_w2log(4,"STAC_CloseHW status=$status\n");

    #clear the global flags
    $STAC_initialized = 0;

	return 1;
}


=head2 STAC_InitHW

    STAC_InitHW();

if only one CAN Hardware is connected, the serial number from testbench will be overwritten

validates & configures all channels mentioned in the ProjectConst.

initialize STAC hardware, connects all lines to default state 

has to be called before any other STAC command, should be called in INITcampaign

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    e.g.

        STAC_InitHW();

=cut

sub STAC_InitHW {

    my ( $canChannel, $serialNo );

    #check if STAC already initialized
    if ($STAC_initialized) {
        S_set_warning("STAC already initialized");
        return 1;
    }

	S_w2log(1,"STAC_InitHW \n");

    $status = tsg4_start( );
    Check_status($status);
	
    #get values from testbenchconfig
    $canChannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'STAC'}{"CANchannel"} ;
    $serialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'STAC'}{"CANHWSerialNo"} ;

    unless (defined $canChannel) {S_set_error( "CANchannel not defined in testbenchconfig STAC" , 20);return;}
    unless (defined $serialNo) {S_set_warning( "SerialNo not defined in testbenchconfig STAC");} # only warning

    #collect names of 'POWER_SUPPLY_LINES' into an array
    @STAC_PSlines=();
    foreach(1..4){
        push(@STAC_PSlines,$main::ProjectDefaults->{'STAC'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'})
          if ( exists $main::ProjectDefaults->{'STAC'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'}
            and $main::ProjectDefaults->{'STAC'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'} ne '')
    }

	STAC_ReadLabels();

	if ($main::opt_offline){
        $STAC_initialized = 1;
        return 1;
    }

	return unless ( CAN_HWcheck($canChannel, \$serialNo) );

    $status = tsg4_init( $canChannel,  $serialNo );
    Check_status($status);
    S_w2log(4,"STAC init ( $canChannel, $serialNo ) status=$status\n");

    $STAC_initialized = 1;

    if ($status < 0){
        S_set_error( "could not initialize STAC" , 5);
        $STAC_initialized = 0;
		return 0;
    }

    # reset STAC and init all devices (set default)
    stac_reset();
    foreach my $line (keys %$STAC_labels){
    	STAC_ConnectLine($line);
    }

#    STAC_DisconnectLine('ALL_SUPPLY'); # should not be connected by default (safe mode)


    return 1;
}



=head2 STAC_ConnectLine

    STAC_ConnectLine( $line );

will connect default relays. terminal (+/-) will be ignored

=cut

sub STAC_ConnectLine{

    my @args = @_;
    return unless S_checkFunctionArguments( 'STAC_ConnectLine ( $label )', @args );

	my $label = shift @args;



    # ignore +/- terminal
    $label =~ s/[+-]$//;

    unless ( exists $STAC_labels->{$label} or $label eq "ALL_SUPPLY") {
        S_set_error( "STAC_ConnectLine '$label' unknown (please check STAC mapping in Project Const)" , 109);
        return;
    }

    unless ( $STAC_initialized ) {
    	S_set_error( "STAC not initialized" , 120);
        return;
    }

    S_w2log(4,"STAC_ConnectLine $label\n");

    if ($label eq "ALL_SUPPLY"){
        S_w2log(4,"STAC_ConnectLine ALL_SUPPLY = @STAC_PSlines \n");
        foreach my $name (@STAC_PSlines){
	    	my @relays = Get_default_relays($name);
	    	Connect_relays(@relays);
		}
    }
    else{
    	#get group for disconnect
    	my @relays = Get_group_relays($label);
		# always disconnect all relays to cover default empty '', eg for faulty state only
    	Disconnect_relays(@relays);
    	#get default for connect
    	@relays = Get_default_relays($label);
		#connect only if at least 1 relay is involved
    	Connect_relays(@relays) if (scalar(@relays) > 0);
    }


	return 1;
}


=head2 STAC_DisconnectLine

    STAC_DisconnectLine( $label );

will disconnect all associated relays. terminal (+/-) will be ignored

=cut

sub STAC_DisconnectLine{

    my @args = @_;
    return unless S_checkFunctionArguments( 'STAC_DisconnectLine ( $label )', @args );

	my $label = shift @args;

    # ignore +/- terminal
    $label =~ s/[+-]$//;

    unless ( exists $STAC_labels->{$label} or $label eq "ALL_SUPPLY") {
        S_set_error( "STAC_DisconnectLine '$label' unknown (please check STAC mapping in Project Const)" , 109);
        return;
    }

    unless ( $STAC_initialized ) {
    	S_set_error( "STAC not initialized" , 120);
        return;
    }

    S_w2log(4,"STAC_DisconnectLine $label\n");

    if ($label eq "ALL_SUPPLY"){
        S_w2log(4,"STAC_DisconnectLine ALL_SUPPLY = @STAC_PSlines \n");
        foreach my $name (@STAC_PSlines){
	    	my @relays = Get_group_relays($name);
	    	Disconnect_relays(@relays);
		}
    }
    else{
    	#get group for connect
    	my @relays = Get_group_relays($label);
    	Disconnect_relays(@relays);
    }

	return 1;
}


=head2 STAC_SetLogicalState

    STAC_SetLogicalState( $line, $state );

will disconnect all associated relays and connect state relays

=cut

sub STAC_SetLogicalState{

    my @args = @_;
    return unless S_checkFunctionArguments( 'STAC_SetLogicalState ( $label, $state )', @args );

	my $label = shift @args;
	my $state = shift @args;

    unless ( $STAC_initialized ) {
    	S_set_error( "STAC not initialized" , 120);
        return;
    }

    S_w2log(4,"STAC_SetLogicalState $label to $state\n");

	#get group for disconnect
	my @relays = Get_group_relays($label);
	# always disconnect all relays to cover state empty ''
	Disconnect_relays(@relays);

	if ($state eq "DEFAULT"){
    	#get default for connect
    	@relays = Get_default_relays($label);
		#connect only if more than 1 relay is involved
    	Connect_relays(@relays) if (scalar(@relays) > 1);
	}
	else{
		#get state for connect
		@relays = Get_state_relays($label,$state);
		#connect only if more than 1 relay is involved
    	Connect_relays(@relays) if (scalar(@relays) > 1);
	}

	return 1;
}

=head1 not exported functions



=head2 Get_default_relays

 @relays = Get_default_relays($label)


=cut

sub Get_default_relays {
    my $label = shift;
	my @ret;
    	if (exists $STAC_labels->{$label}{"default"}){
			my $value = $STAC_labels->{$label}{"default"};
			@ret = @$value;
    	}
    	else{
    		S_set_error( "unknown default for '$label', please check STAC mapping in Project Const" , 109);return ();
    	}

    return @ret;
}

=head2 Get_group_relays

 @relays = Get_group_relays($label)


=cut

sub Get_group_relays {
    my $label = shift;
	my @ret;
    	if (defined $STAC_labels->{$label}{"group"}){
			my $value = $STAC_labels->{$label}{"group"};
			@ret = @$value;
    	}
    	else{
    		S_set_error( "unknown group for '$label', please check STAC mapping in Project Const that at least one relay is used" , 109);return ();
    	}

    return @ret;
}

=head2 Get_state_relays

 @relays = Get_state_relays($label, $state)


=cut

sub Get_state_relays {
    my $label = shift;
    my $state = shift;
	my @ret;
    	if (defined $STAC_labels->{$label}{"states"}{$state}){
			my $value = $STAC_labels->{$label}{"states"}{$state};
			@ret = @$value;
    	}
    	else{
    		S_set_error( "unknown state '$state' for '$label', please check STAC mapping in Project Const" , 109);return ();
    	}

    return @ret;
}

=head2 Disconnect_relays

 Disconnect_relays(@relays)


=cut

sub Disconnect_relays {
    my @relays = @_;

    S_w2log(5,"Disconnect STAC relays @relays \n");
    foreach my $number (@relays){
		$status = stac_relay_off($number);
   	}

    return 1;
}

=head2 Connect_relays

 Connect_relays(@relays)


=cut

sub Connect_relays {
    my @relays = @_;

    S_w2log(5,"Connect STAC relays @relays \n");
    foreach my $number (@relays){
		$status = stac_relay_on($number);
   	}

    return 1;
}

=head2 Check_status

 Check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_status {
    my $result = shift;

    return 1 if $main::opt_offline;
    if ( $result < 0 ) {
        my $errortext = tsg4_get_error();
        S_set_error( "STAC ($result): $errortext", 5 );

    }

    return 1;
}


=head2 CAN_HWcheck

 $status = CAN_HWcheck($canChannel,$serialNo_ref);

if only one CAN HW is connected, $serialNo will be overwritten with connected HW (therefore call by ref).

returns false if no CAN HW is connected, given serialNo is not connected or given CAN channel out of range

=cut

sub CAN_HWcheck{
	my $canChannel = shift;
	my $serialNo_ref = shift;
	my $error_ret = 0;

	if( ref($serialNo_ref ) ne "SCALAR" ) {
        S_set_error( "Second parameter (\$serialNo_ref ) is not a scalar reference", 114 );
        return $error_ret;
    }

    #get the available (connected) CAN Hardwares
     my ($canHwIDs_aref, $channels_aref);
    ($status, $canHwIDs_aref, $channels_aref) = tsg4_get_CAN_HW_list();
    Check_status($status,'search CAN HW');

    # set SerialNo if only one HW detected
    if (scalar(@$canHwIDs_aref)==1){
        $$serialNo_ref = $$canHwIDs_aref[0];
	    S_w2log(4,"only one CAN hardware connected: new CANHWSerialNo = $$serialNo_ref\n");
    }
    elsif (scalar(@$canHwIDs_aref)==0){
        S_set_error( "! no CAN hardware detected", 120 );return $error_ret;
    }

    # set error if no entry in testbenchconfig (and more than one HW detected)
    unless (defined $$serialNo_ref) {S_set_error( "CANHWSerialNo not defined in testbenchconfig, detected HWs: @$canHwIDs_aref " , 114 );return $error_ret;}

    # check if expected HW connected and channel number in range
    my $foundSerialno = 0;
    for (my $count=0;$count<scalar(@$canHwIDs_aref);$count++){
        if ($$canHwIDs_aref[$count] == $$serialNo_ref){
            $foundSerialno = $$serialNo_ref;
            if ($canChannel > $$channels_aref[$count] ) {S_set_error( "! given channel $canChannel > $$channels_aref[$count] (= MAXchannel of HW $$serialNo_ref) )", 114 );return $error_ret;}
        }
    }

    #if the "testbenchconfig HW number" is not found, report error 
    if ($foundSerialno <= 0) {S_set_error( "! given CANHWSerialNo $$serialNo_ref not connected, detected HWs: @$canHwIDs_aref  )", 114 );return $error_ret;}
    return 1;
}



#sub Check_relay_assigment{
#
#	my $value = shift;
#	my @resources = split (/\+/, $value);
#
#
#	foreach my $type (@resources){
#    	# chek if resource already used
#	    if (exists $Used_relays{$type}){
#	        S_set_error( "! relay $type already in use!", 114 );
#	        return;
#	    }
#	    else{
#	    	$Used_relays{$type} = 1;
#	    }
#	}
#	return 1;
#}

sub Check_relay_naming{

	my $value = shift;
	my @resources = split (/\+/, $value);

	#todo: check range from 1 to 40 !
	foreach my $type (@resources){
    	# chek if rlay is named correcty S some numbers
	    unless ($type =~ m/^S\d+$/){
	        S_set_error( "! relay name '$type' has wrong format in '$value' !  (not e.g. S10+S11)", 114 );
	        return;
	    }
	}
	return 1;
}

=head2 STAC_GetNames

  @names = STAC_GetNames( $section );

return names of STAC section defined in ProjectConst in ascending order

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    STAC_GetNames( 'BELT_LOCKS' ) will return ('BLRR','PADS')       

=cut

sub STAC_GetNames{
    my $section = shift;
    my (@names,@keys);
    my %values;

    @names=();
    unless (defined( $section )) {
        S_set_error( "! too less parameters ! SYNTAX: STAC_GetNames( \$section )", 110 );
        return @names;
    }


        #old CFG format is used
       unless ( exists $main::ProjectDefaults->{'STAC'}{$section} ) {
            S_set_error( "! wrong parameter ! section $section does not exist in ProjectConst", 109 );
            return @names;
        }
        %values = %{$main::ProjectDefaults->{'STAC'}{$section}};

        #append the STACnumber with key for sorting purpose, in this case STAC number is 1
        foreach my $keyname(keys %values){
            $values{"1_" . $keyname} = $values{$keyname};
            delete $values{$keyname};
        }


    #collect keys with the pattern .*_Name (ex: 1_SW1_Name, 2_SW2_Name, 1_SW3_Name etc.)
    @keys= grep(/_Name$/ ,keys %values);

    # sorting taken from C:/Perl/html/lib/Pod/perlfunc.html sort LIST
    #sort based on the keys : for example, (1_SW1_Name, 2_SW2_Name, 1_SW3_Name) should be sorted to (1_SW1_Name , 1_SW3_Name , 2_SW2_Name ) and so on.
    #Consider the list containing elements (1_SW1_Name, 2_SW2_Name, 1_SW3_Name )
    #The sorting involves 3 steps
    #step-1: map { [$_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_)] } @keys;
    #       For each element in @keys, prepare a 4-element hash of form [SwitchName, STACNumber, SwitchNumber, Uppercase of SwitchName] 
    #       for example[1_SW1_Name , 1, 1, 1_SW1_NAME], [2_SW2_Name ,2,  2, 2_SW2_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME])
    #
    #step-2: sort { $a->[1] <=> $b->[1]    ||     $a->[2] <=> $b->[2]      ||      $b->[3] cmp $a->[3]}
    #       Sort the array based on first, second and third element ([1_SW1_Name , 1,  1, SW1_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME], [2_SW2_Name , 2, 2, SW2_NAME])
    #
    #step-3: map { $_->[0] }
    #       Assign the first element to the resulting variable(1_SW1_Name,1_SW3_Name,2_SW2_Name)
    #
    #Hence the elements are sorted
    #
    @keys = map { $_->[0] }
           sort { $a->[1] <=> $b->[1]
                           ||
                  $a->[2] <=> $b->[2]
                           ||
                  $b->[3] cmp $a->[3]
       } map { [$_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_)] } @keys;

    foreach (@keys){
            push( @names,$values{$_});
    }

    S_w2log(4,"STAC_GetNames( $section ) = @names\n");
    return(@names);

}


=head2 STAC_ReadLabels not exported

    STAC_ReadLabels( );

(re-)read STAC labels from ProjectConst to data structure


=cut

sub STAC_ReadLabels{

    $STAC_labels=undef;
    %Used_relays=();

# name -> section = ...  
# name -> default = ... [1,2] from 'S1+S2'
# name -> unit = ... 
# name -> number = ... 
# name -> states -> state = ... 

    foreach my $section (sort keys %{$main::ProjectDefaults->{'STAC'}}){
    	#skip reading of 'MEASURED_SQUIBS' since the are not used for operation
    	next if ($section eq 'MEASURED_SQUIBS');

        my %temp_no; # hash to store number->label assignment for second run

        foreach my $key (sort keys %{$main::ProjectDefaults->{'STAC'}->{$section}}){
            my $section_value = $main::ProjectDefaults->{'STAC'}->{$section}->{$key};

            if ($key =~ /([_\d]+)_Name$/){
                my $number = $1;
                #check if key is unique
                if(exists $STAC_labels->{$section_value}){
                    S_set_error("Redundant name '$section_value' in $section", 20 );
                    return 0;
                }
                #add under 'Names' group
                $STAC_labels->{$section_value}{"section"} = $section;
                $STAC_labels->{$section_value}{"number"} = $number;
                # store name for second pass
                $temp_no{$number}=$section_value;
            }

        }

        # second run to assign default and states
        foreach my $key (sort keys %{$main::ProjectDefaults->{'STAC'}->{$section}}){
            my $section_value = $main::ProjectDefaults->{'STAC'}->{$section}->{$key};
            my $relay_names = $section_value;

			$section_value =~ s/S//g; # remove all Ss
			$section_value =~ s/\s+//g; # remove all whitespaces
			my @switches = split (/\+/, $section_value);
			
            if ($key =~ /([_\d]+)_Default$/){
                my $number = $1;
				Check_relay_naming($relay_names) or next;

                #get name from first pass
                $STAC_labels->{$temp_no{$number}}{"default"} = \@switches;

            }
            elsif ($key =~ /([_\d]+)_state_(.+)$/){
                my $number = $1;
                my $state = $2;
				Check_relay_naming($relay_names) or next;

                #get name from first pass
                $STAC_labels->{$temp_no{$number}}{"states"}{$state} = \@switches;

            }
        }
    }


	# extra run to get group from states and default
	foreach my $label (sort keys %{$STAC_labels}){
		my %state_relays;
		%state_relays = ();
		my @list = Get_default_relays($label);
		
		if (exists $STAC_labels->{$label}{"states"}){
			foreach my $state (sort keys %{$STAC_labels->{$label}{"states"}}){
				my $state_value = $STAC_labels->{$label}{"states"}{$state};
				push( @list , Get_state_relays($label, $state) );
			}
		}

		foreach my $switch (@list){
			$state_relays{$switch} = 1;
		}

		my @group_relays = sort keys %state_relays;
		foreach my $type  (@group_relays){
	    	# chek if resource already used
		    if (exists $Used_relays{$type}){
		        S_set_error( "! relay S$type already in use for $label!", 114 );
		        return;
		    }
		    else{
		    	$Used_relays{$type} = 1;
		    }
		}

		$STAC_labels->{$label}{"group"} = \@group_relays;

	}


#    $Data::Dumper::Indent = 1;
#    $Data::Dumper::Sortkeys = 1;
#    $Data::Dumper::Varname = "STAC_config_gr";
#    my $dump = Dumper($STAC_labels);
#    print $dump;

    return 1;
}


#return 1 (default for all perl modules)
1;

__END__

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>


=head1 SEE ALSO

Low level STAC module

=cut
