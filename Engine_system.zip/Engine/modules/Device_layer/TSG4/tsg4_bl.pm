package tsg4_bl;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    bl_send_commad
    bl_send_commad_wait_response
    bl_set_resistance
    bl_set_current
    bl_LV124
    bl_reset
    bl_connect
    bl_disconnect
    bl_bootloader_mode
    bl_get_firmware
    bl_get_HW_id
    bl_write_name
    bl_write_SN
    bl_connect_via
    bl_disconnect_via
    bl_microcut
    bl_set_event_delay
    bl_set_event_trigger
    bl_get_INFO
    bl_lock_display
    bl_unlock_display
    bl_write_CAL
    bl_write_SN
    bl_write_TST    
);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);




############################################################################################################

=head1 DESCRIPTION

Belt Lock control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut




=head2 bl_reset

    $status = bl_reset($BLnumber);

    e.g. $status = bl_reset(3);

resets belt lock

returns status.

=cut

sub bl_reset {
    my $BLnumber = shift;

    my $command = "R02";

    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_connect

    $status = bl_connect($BLnumber);

    e.g. $status = bl_connect(3);

connects belt lock

returns status.

=cut

sub bl_connect {
    my $BLnumber = shift;

    my $command = "U01a";

    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_disconnect

    $status = bl_disconnect($BLnumber);

    e.g. $status = bl_disconnect(3);

disconnects belt lock (open line)

returns status.

=cut

sub bl_disconnect {
    my $BLnumber = shift;

    my $command = "U01e";

    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
    
}


=head2 bl_set_resistance

    $status = bl_set_resistance($BLnumber,$resistance);

    e.g. $status = bl_set_resistance(3,470);

    $resistance between 20 .. 9990 Ohm step 10 Ohm (for firmware until FW_G0006)

    $resistance between 20 .. 15990 Ohm step 10 Ohm (for firmware FW_G0007 or higher)

    requires 'U01a' called once before

sets resistance on belt lock

returns status.

=cut

sub bl_set_resistance {
    my $BLnumber = shift;
    my $resistance = shift;

    my $command;
    if( $resistance <= 9999 ) {
        $command = sprintf("V%04d",$resistance);
    }
    else{
        $resistance /= 10;
        $command = sprintf("T%04d",$resistance); # command T is only available with firmware FW_G0007 or later
    }

    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
     
}

=head2 bl_set_current

    $status = bl_set_current($BLnumber,$current);

    e.g. $status = bl_set_current(3,47);

    $current in mA between 0.1 .. 100.0 mA step 0.1 mA

    requires 'U01a' called once before

sets current on belt lock

returns status.

=cut

sub bl_set_current {
    my $BLnumber = shift;
    my $current = shift;
    $current *= 10; # convert to mA

    my $command = sprintf("I%04d",$current);

    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_LV124

    $status = bl_LV124($BLnumber,$fault_type);

    e.g. $status = bl_LV124(3,4);

    $fault_type between 0 .. 5 

    0 - no fault
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on belt lock.

=cut

sub bl_LV124 {
    my $BLnumber = shift;
    my $fault_type = shift;
    
    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);

    if(($BLnumber & 0x01) ==0) {$fault_type+=5;}

    my $command = sprintf("L%02d",$fault_type);
    ($status) = bl_send_commad_wait_response($BLnumber,$command,$timeout);
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_microcut

    $status = bl_microcut($BLnumber,$offtime_us);

    e.g. $status = bl_microcut(3,100);

    $offtime_us in microseconds

starts microcut (LV124) fault simulation on belt lock.

=cut

sub bl_microcut {
    my $BLnumber = shift;
    my $offtime_us = shift;

    my $timeout=int($offtime_us/1000)+1000;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s",join('',@bytes));

    ($status) = bl_send_commad_wait_response($BLnumber,$command,$timeout);
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_write_name

    $status = bl_write_name($BLnumber,$name);

    e.g. $status = bl_write_name(3,'BLRR');

    $name length <= 8 

writes name to card to be displayed.

=cut

sub bl_write_name {
    my $BLnumber = shift;
    my $name = shift;
    my ($receive_ID);

    ($status,undef,$receive_ID) = bl_send_commad_wait_response($BLnumber,'N');
    #todo check response for 'done'
#    printf( "-> 0x%02x $name\n",$receive_ID-1);

    #todo : why not using bl_send_commad_wait_response again ???    
    my @bytes = split(//, $name);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(5);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout );
    $status = tsg4_check_CAN_status( $CANstatus, "BL_$BLnumber" );
    tsg4_wait_ms(5);
    #todo check response for 'done'    
    return ($status);
    
}


=head2 bl_bootloader_mode

    $status = bl_bootloader_mode($BLnumber);

    e.g. $status = bl_bootloader_mode(1);

sets belt lock card to bootloader mode for firmware update

returns status.

=cut

sub bl_bootloader_mode {
    my $BLnumber = shift;
    my $value;

    #($status,$receive_ID) = bl_send_commad($BLnumber,'@');
    ($status,$value) = bl_send_commad_wait_response($BLnumber,'@');
#    print("bootloader response: $value\n");
    #todo check response for '_update_'    
    return ($status);
    
}



=head2 bl_get_firmware

    ($status, $firmware) = bl_get_firmware($BLnumber);

    e.g. (0,'FW_G0042') = bl_get_firmware(3);

reads firmware version from belt lock card

returns status.

=cut

sub bl_get_firmware {
    my $BLnumber = shift;
    my $value;

    ($status,$value) = bl_send_commad_wait_response($BLnumber,'?10');
#    print("firmware $value\n");
    # no check of return value
    return ($status,$value);
    
}

=head2 bl_get_HW_id

    ($status, $HW_ID) = bl_get_HW_id($BLnumber);

    e.g. (0,'999G0042') = bl_get_HW_id(3);

reads hardware ID from belt lock card

returns status.

=cut

sub bl_get_HW_id {
    my $BLnumber = shift;
    my $value;

    ($status,$value) = bl_get_INFO($BLnumber,'SN');
#    print("HW ID $value\n");
    # no check of return value 
    return ($status,$value);
    
}


=head2 bl_get_INFO

    ($status, $INFO) = bl_get_INFO($BLnumber,$keyword);

    e.g. (0,'999B0042') = bl_get_INFO(1,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from belt lock card

returns status.

=cut

sub bl_get_INFO {
    my $BLnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = bl_send_commad_wait_response($BLnumber,$command);
#    print("INFO ($keyword) $value\n");
    # no check of return value
    
    return ($status,$value);
    
}




=head2 bl_connect_via

    $status = bl_connect_via($BLnumber,$terminal,$via);

    e.g. $status = bl_connect_via(3,'+',1); # connect BL+ to ref1

connect belt lock terminal to reference line

returns status.

=cut

sub bl_connect_via {
    my $BLnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2+$via;
    }
    elsif ($terminal eq "-"){
        $command=0+$via;
    }
    else{return (-1);}

#01  GS- Bezug1
#02  GS- Bezug2
#03  GS+ Bezug1
#04  GS+ Bezug2

    ($status) = bl_send_commad_wait_response($BLnumber,'B0'.$command.'e');
#    print("bl_connect_via ($terminal $via -> $command) $status\n");
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_disconnect_via

    $status = bl_disconnect_via($BLnumber,$terminal,$via);

    e.g. $status = bl_disconnect_via(3,'+',1); # disconnect BL+ from ref1

disconnect belt lock terminal from reference line

returns status.

=cut

sub bl_disconnect_via {
    my $BLnumber = shift;
    my $terminal = shift;
    my $via = shift;
    my $command;
  
    if ($terminal eq "+"){
        $command=2+$via;
    }
    elsif ($terminal eq "-"){
        $command=0+$via;
    }
    else{return (-1);}

#01  GS- Bezug1
#02  GS- Bezug2
#03  GS+ Bezug1
#04  GS+ Bezug2

    ($status) = bl_send_commad_wait_response($BLnumber,'B0'.$command.'a');
#    print("bl_disconnect_via ($terminal $via -> $command) $status\n");
    #todo check response for 'done'    
    return ($status);
    
}




=head2 bl_set_event_delay

    $status = bl_set_event_delay($BLnumber,$delay);

    e.g. $status = bl_set_event_delay(3,1.7);

    $delay between 0 .. 9.9 millisec step 0.1 millisec 

sets delay on belt lock card for bl_set_event_trigger

returns status.

=cut

sub bl_set_event_delay {
    my $BLnumber = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%02d",$delay*10);
    ($status) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'    
    return ($status);
    
}


=head2 bl_set_event_trigger

    $status = bl_set_event_trigger($BLnumber,$fault_type);

    e.g. $status = bl_set_event_trigger(3,1);

    $fault_type between 0 .. 15 

     0 - no fault
     1 - interruption
     2 - BL- to ref1
     3 - BL- to ref2
     4 - BL+ to ref1
     5 - BL+ to ref2
    11 - LV124 10sec interruption
    12 - LV124 1ms   interruption
    13 - LV124 100us interruption
    14 - LV124 1us   interruption 1ms pause with 4 sec cycle
    15 - LV124 100us interruption 1ms pause with 4 sec cycle

sets event trigger mode on belt lock card

returns status.

=cut

sub bl_set_event_trigger {
    my $BLnumber = shift;
    my $fault_type = shift;
    my $command;
    my $value = 0;
    
    if ($fault_type == 1){
        $value = $BLnumber;
    }
    elsif ($fault_type > 10 and $fault_type < 16){
        $value = $fault_type+(($BLnumber-1)*5);
    }
    elsif ($fault_type > 1 and $fault_type < 6){
        $value = $fault_type+1;
        $value += ($BLnumber-1)*4;
    }
    else{
        $value = 0;
    }
    
    $command = sprintf("E%02d",$value);
    ($status) = bl_send_commad_wait_response($BLnumber,$command);
     #todo check response for 'done'   
    return ($status);
    
}



=head2 bl_lock_display

    ($status) = bl_lock_display($BLnumber);

    e.g. (0) = bl_lock_display(1);

lock display on belt lock card to avoid wait times due to display update.

returns status.

=cut

sub bl_lock_display {
    my $BLnumber = shift;
    my $value;

    ($status,$value) = bl_send_commad_wait_response($BLnumber,'C99');
    #todo check response for 'done'    
    return ($status);
    
}

=head2 bl_unlock_display

    ($status) = bl_unlock_display($BLnumber);

    e.g. (0) = bl_unlock_display(1);

unlock display on belt lock card.

returns status.

=cut

sub bl_unlock_display {
    my $BLnumber = shift;
    my $value;

    ($status,$value) = bl_send_commad_wait_response($BLnumber,'C00');
    #todo check response for 'done'    
    return ($status);
    
}


=head2 bl_write_SN

    $status = bl_write_SN($BLnumber,$serial_number);

    e.g. $status = bl_write_SN(1,'999G0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub bl_write_SN {
    my $BLnumber = shift;
    my $SN = shift;

    $status = bl_write_EE($BLnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 bl_write_TST

    $status = bl_write_TST($BLnumber,$TST_date);

    e.g. $status = bl_write_TST(1,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub bl_write_TST {
    my $BLnumber = shift;
    my $TST_date = shift;

    $status = bl_write_EE($BLnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 bl_write_CAL

    $status = bl_write_CAL($BLnumber,$CAL_date);

    e.g. $status = bl_write_CAL(1,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub bl_write_CAL {
    my $BLnumber = shift;
    my $CAL_date = shift;

    $status = bl_write_EE($BLnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}

=head2 bl_write_EE not exported

    $status = bl_write_EE($BLnumber,$EEslot,$text);

    e.g. $status = bl_write_EE(1,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub bl_write_EE {
    my $BLnumber = shift;
    my $slot = shift;
    my $SN = shift;
    my ($receive_ID,$response);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$response,$receive_ID) = bl_send_commad_wait_response($BLnumber,$command);
    #todo check response for 'done'

#    printf( "-> 0x%02x $SN (slot $slot)\n",$receive_ID-1);
    
    #todo : why not using bl_send_commad_wait_response again ???
    my @bytes = split(//, $SN);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "BL_$BLnumber" );
    tsg4_wait_ms(5);

    #todo check response for 'done'
        
    return ($status);
    
}


################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 bl_send_commad_wait_response

    ($stat,$ret,$receive_ID) = bl_send_commad_wait_response($BLnumber,$ASCII_command,[$timeout]);

    $timeout is optional, default is $MAXtimeout

Transmits the string $data on the CAN to belt lock

returns status and answer string as ASCII.

=cut

sub bl_send_commad_wait_response {
    my $BLnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($byte,$offset,$data_aref);

    if(($BLnumber & 0x01) ==1) {$offset=($BLnumber+1)-2;}
    else {$offset=$BLnumber-2;}

    my $send_ID = BL_base_address+$offset;   
    my $receive_ID = $send_ID+1;  
    
    $ASCII_command = sprintf("G%02d%s",$BLnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
    	$status = tsg4_check_CAN_status( $CANstatus, "BL_$BLnumber" );
        return ($status,'error',$receive_ID);
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response),$receive_ID);
    
}


=head2 bl_send_commad

    ($stat,$receive_ID) = bl_send_commad($BLnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = bl_send_commad(3,'?00');

Transmits the string $data on the CAN to belt lock

returns status and answer ID.

=cut

sub bl_send_commad {
    my $BLnumber = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

    if(($BLnumber & 0x01) ==1) {$offset=($BLnumber+1)-2;}
    else {$offset=$BLnumber-2;}

    my $send_ID = BL_base_address + $offset;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("G%02d%s",$BLnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

    #print( "->$send_ID @bytes\n");
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "BL_$BLnumber" );
    return ($status,$receive_ID);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



