# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_LCT;

use strict;
use warnings;
use LIFT_general;
use LIFT_evaluation;
use File::Basename;

use tsg4;
use tsg4_lct64;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  LCT_InitHW
  LCT_StartMeasurement
  LCT_SendSWTrigger
  LCT_get_values
  LCT_get_channel
  LCT_plot_values
  LCT_StopMeasurement
  LCT_EvaluateMeasurement
  LCT_get_device_status

);

our ( $VERSION, $HEADER );

my $status;                  # Variable to hold the status of operation
my $LCT_initialized;         # flag for LCT initialization
my @LCT_ChannelsSection;     # list of squib device names to be monitored
my @LCT_channels;            # list of squib device numbers to be monitored
my %LCT_channels_mapping;    # squib device name mapped to number
my $LCT_plot_data_href;           # contains data from get values for plottin as UNV

#initialize with default values
$LCT_initialized = 0;

use constant RISING  => 1;
use constant FALLING => 2;

=head1 NAME

LIFT_LCT 

Perl extension for managing LCT64 with LIFT

=head1 SYNOPSIS

  use LIFT_TSG4;
  use LIFT_LCT;

  TSG4_InitHW(); # intialisation of the CAN communication has to be done via TSG4 function
  # or STAC_InitHW();
  
  LCT_InitHW();
  LCT_StartMeasurement();
  LCT_SendSWTrigger();
  $lct_status = LCT_get_device_status();
  $data_href = LCT_get_values();
  $channel_href = LCT_get_channel('AB1FD');
  LCT_plot_values("SQUIBS.txt.unv");
  LCT_EvaluateMeasurement('AB1FD', 'rising', 200 , 500); # from 200 to 500
  LCT_StopMeasurement();

  TSG4_CloseHW(); # closing of the CAN communication has to be done via TSG4 function
  # or STAC_CloseHW();

B<ProjectConst:>

  $Defaults -> {'LCT64'} = {
    'MonitoredSquibs' => [ 'AB1FD', 'AB2FD' ] , # list of labels from TSG4 config or 'ALL' to take all squibs from ProjectConst
    'TriggerSlopeType'   => 'positive',  # 'positive' or 'negative'
  },

 the project const settings for TSG4 will be used additionally, especially SQUIBS section
 the testbench settings for TSG4 will be used for CAN initialisation

B<Note:>

=over 3

=item * The LCT64 CAN hat to be connected to TSG4 CAN and TSG4 CAN communication has to be initialized before.

=item * The squib thresholds have to be configured in TSG4 via TSG4_SetSquibCurrentThreshold.

=back


=head1 DESCRIPTION

The module LIFT_LCT has all the necessary functions to configure and measure using LCT64.
The configuration should be done in LIFT ProjectConst file as given in L</SYNOPSIS>.




=head2 LCT_EvaluateMeasurement

    ($succeededPulses_aref, $pulses_href) = LCT_EvaluateMeasurement($channelName, $slopeType, $time_min , $time_max)

To evaluate the given channel's data to check whether the recorded signal contains a pulse within the mentioned time.

    $channelName        :   channel name configured in ProjectDefaults->{'LCT64'}{'MonitoredSquibs'}
    $slopeType          :   Direction of the pulse ('rising' or 'falling')
    $time_min           :   Starting time in time interval to be checked (relative to trigger, in milliseconds) or 'START'
    $time_max           :   Finish time in time interval to be checked (relative to trigger, in milliseconds) or 'END'

    e.g.:

    ($succeededPulses_aref, $pulses_href) = LCT_EvaluateMeasurement('CHANNEL1' , 'rising', 200 , 500 ); #retrieve data immediately and evaluate

returns ($succeededPulses_aref, $pulses_href) , on Success

    $succeededPulses_aref : Index of pulses which satisfies the given condition (0,1,2, etc). In success conditions, number of elements in $succeededPulses_aref array > 0
                            Access the successful pulses as $pulses_href->{"pulse$index"}

    $pulses_href          : Hashes that contain all available pulse details in the recorded signal for the total duration
                            Format:
                            $pulses_href = {
                                'pulse0' =>{
                                    'start' = 100.05,
                                    'end' = 220.10,
                                },
                                'pulse1' =>{
                                    'start' = 275.20,
                                    'end' = 325.10,
                                }
                            }


error return : (undef, undef)

offline return :

                ([0], {
                         'pulse0' => {
                            'start' => 0,
                            'end' => 1,
                          }
                      }
                 )

calls internally LCT_get_channel.


=cut

sub LCT_EvaluateMeasurement {
    my $channelName     = shift;
    my $slopeType       = shift;
    my $time_min        = shift;
    my $time_max        = shift;
    my @succeededPulses = ();
    my ( $numOfActualPulses, $pulses_href );
    my $data_HoA;

    # check for too less parameters
    unless ( defined($time_max) ) {
        S_set_error( "! too less parameters ! SYNTAX: LCT_EvaluateMeasurement(\$channelName, \$voltageLevel, \$slopeType, \$time_min , \$time_max [, \$minWaitTime_ms [, \$voltageTolerance [, \$MinSamplesPerPulse]]])", 110 );
        return ( undef, undef );
    }

    #validate slope type
    unless ( $slopeType =~ /rising/i || $slopeType =~ /falling/i ) {
        S_set_error( "Invalid SlopeType '$slopeType' specified for LCT Channel $channelName. 'SlopeType' shall be 'rising' or 'falling'", 109 );
        return ( undef, undef );
    }

    #Time_min should be a number or 'START'
    unless ( $time_min =~ /\d+?\.?\d+?/ || $time_min =~ /START/i ) {
        S_set_error( "\$time_min shall be a number or 'START'", 109 );
        return ( undef, undef );
    }

    #Time_min should be a number or 'START'
    unless ( $time_max =~ /\d+?\.?\d+?/ || $time_max =~ /END/i ) {
        S_set_error( "\$time_max shall be a number or 'END'", 109 );
        return ( undef, undef );
    }

    #check whether LCT is already initialized
    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return ( undef, undef );
    }

    S_w2log( 1, "LCT_EvaluateMeasurement (channel = $channelName, slope = $slopeType, min time = $time_min ms, max time = $time_max ms)\n" );

    #set the number of pulses found as 0
    $numOfActualPulses = 0;

    #LCT_get_values() called even in offline mode, to validate $channelName
    $data_HoA = LCT_get_channel($channelName);

    if ($main::opt_offline) {
        return (
            [0],
            {
                'pulse0' => {
                    'start' => 0,
                    'end'   => 1,
                }
            }
        );
    }

    #if any error occured during retrieving data from  LCT, then report that Evaluation failed
    unless ( defined $data_HoA ) {
        S_set_error( "LCT_EvaluateMeasurement for channel '$channelName' failed", 21 );
        return ( undef, undef );
    }

    #get the time array and signal array corresponding to the channel
    my $timearray = $data_HoA->{'time'};

    # if timearray is not defined, then there is no data for particular channel,
    # so return undef
    if ( !defined($timearray) || scalar(@$timearray) <= 0 ) {
        S_set_error( "LCT_EvaluateMeasurement: No data (transition) recorded/available for channel '$channelName'", 0 );
        return ( undef, undef );
    }

    $time_min = $$timearray[0]  if ( $time_min =~ /START/i );
    $time_max = $$timearray[-1] if ( $time_max =~ /END/i );

    #$slopeType shall be made to a constant defined integer to eliminate comparision time
    $slopeType = RISING  if ( $slopeType =~ /rising/i );
    $slopeType = FALLING if ( $slopeType =~ /falling/i );

    #Time_min should be lesser than Time_max
    if ( $time_min > $time_max ) {
        S_set_error( "\$time_max should be greater than \$time_min", 109 );
        return ( undef, undef );
    }

    my $channeldata = $data_HoA->{$channelName};

    ( $pulses_href, $numOfActualPulses ) = LCT_Extract_pulses( $timearray, $channeldata, $slopeType );

    S_w2log( 5, " -> found $numOfActualPulses pulses in the signal $channelName (Slope = '$slopeType')\n" );

    #log the pulse start and end timings in the report for all pulses in the total duration
    foreach my $pulseNumber ( 0 .. ( $numOfActualPulses - 1 ) ) {
        S_w2log( 5, " Pulse($pulseNumber) => start : " . $pulses_href->{"pulse$pulseNumber"}{'start'} . " , end : " . $pulses_href->{"pulse$pulseNumber"}{'end'} . "\n" );
    }

    # check whether any pulses available within Time_min and Time_max, if available, add the index to Succeeded pulse list
    foreach my $pulseNumber ( 0 .. ( $numOfActualPulses - 1 ) ) {
        if ( $time_min <= $pulses_href->{"pulse$pulseNumber"}{"start"} && $time_max >= $pulses_href->{"pulse$pulseNumber"}{"end"} ) {
            push( @succeededPulses, $pulseNumber );
        }
    }

    #check if any pulses are found and log into report, if no pulses found
    if ( scalar(@succeededPulses) > 0 ) {
        S_w2log( 5, scalar(@succeededPulses) . " pulse(s) found between $time_min ms and $time_max ms \n" );
        foreach my $succeededPulseIndex ( 0 .. ( scalar(@succeededPulses) - 1 ) ) {
            S_w2log( 5, " Pulse ( " . ($succeededPulseIndex) . " ) : start -> " . $pulses_href->{"pulse$succeededPulses[$succeededPulseIndex]"}{"start"} . ", end -> " . $pulses_href->{"pulse$succeededPulses[$succeededPulseIndex]"}{"end"} . "\n" );
        }
    }
    else {
        S_w2log( 4, "No pulses found between $time_min ms and $time_max ms" );
    }

    return ( \@succeededPulses, $pulses_href );
}

=head2 LCT_get_channel

    $channel_href = LCT_get_channel($channelName)

Returns the data recorded for particular channel. LCT_get_values has to be called first to read all channels.

    $channelName    : channel name configured in ProjectDefaults->{'LCT64'}{'MonitoredSquibs'}

    e.g.:

    $channel_href = LCT_get_channel("AB1FD");

$channel_href Format:

    $channel_href = {    # Trigger will always be at time 0
                'time'     => [0, 1, 2, 3, ...],
                'AB1FD' => [3.25, 6.20, 5.15, 5.82, ...],
              }

Error return : undef

offline return :
         {
           'time'     => [0],
           "dummy" => [0],
         }



=cut

sub LCT_get_channel {
    my $channelName = shift;
    my $channel_href = ();

    my $channel_href_dummy = { 'time' => [], "dummy" => [] };
    if ($main::opt_offline) {
        return $channel_href_dummy;
    }

    #extract requested signals
    my ( $channel_aref, $time_aref ) = EVAL_get_values_and_times_over_time( $LCT_plot_data_href, $channelName );

    # check if there is any value measured
    if ( defined($channel_aref) and defined($time_aref) and scalar(@$channel_aref) > 1 and scalar(@$time_aref) > 1 ) {
        $channel_href = {
            'time'       => $time_aref,
            $channelName => $channel_aref,
        };

        return ($channel_href);
    }
    else {
        S_set_error( "no signal found", 0 );
        return ($channel_href_dummy);

    }

}

=head2 LCT_get_values

    $data_href = LCT_get_values()

returns structure created from all configured channels via MonitoredSquibs to evaluate with EVAL functions.
timebase of structure is in milliseconds.

This will clear the buffer inside LCT64 !

    e.g.:

    $data_href = LCT_get_values();           #retrieve data immediately

$data_href Format:

    $data_href = {
                  0 => { 'AB1FD' = 0  , 'BT1FP' = 1 } ,
                  1.2 => { 'AB1FD' = 1  , 'BT1FP' = 0 } ,
                  2.7 => { 'AB1FD' = 0  , 'BT1FP' = 1 } ,
                  3.5 => { 'AB1FD' = 1  , 'BT1FP' = 0 } ,
                };


Error return : undef

offline return :
         { 0 => { 'dummy' => 0 } }


=cut

sub LCT_get_values {

    my %channel;
    %channel = ();

    #dummy return value for offline mode
    my $data_href_dummy;

    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return;
    }

    S_w2log( 1, "LCT_get_values\n" );

    if ($main::opt_offline) {

        #prepare dummy hash to return for offline condition
        $data_href_dummy->{0}->{'dummy'} = 0;

        return $data_href_dummy;
    }

    unless ( defined $LCT_plot_data_href ) {

        # read all values and store ist structure for later plotting
        foreach my $ch ( keys %LCT_channels_mapping ) {
            if ( exists $LCT_channels_mapping{$ch} ) {
                $channel{ $LCT_channels_mapping{$ch} } = $ch;
            }
        }

        ( $status, $LCT_plot_data_href ) = lct_read_values( 1, \%channel );

    }

    return $LCT_plot_data_href;

}

=head2 LCT_InitHW

    LCT_InitHW();

This function should be called after TSG4_init but before calling any other function in this module.
validates & configures all channels mentioned in the ProjectConst.
Configures the Trigger based on the mentioned configuration.
Default is 'MonitoredSquibs'='ALL' and 'TriggerSlopeType'='negative'.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration options

    e.g.:

        LCT_InitHW();

=cut

sub LCT_InitHW {

    my $externalTrigger;

    #check if LCT already initialized
    if ($LCT_initialized) {
        S_set_warning("LCT already initialized");
        return 1;
    }

    #chek if TSG4 was initialized before !!! $TSG4_CAN_initalized exported from tsg4.pm
    unless ($TSG4_CAN_initalized) {
        S_set_error( "TSG4 CAN not initialized", 120 );
        return 0;
    }

    #collect info about channels to be configured
    if ( exists $main::ProjectDefaults->{'LCT64'}{'MonitoredSquibs'} ) {
        @LCT_ChannelsSection = @{ $main::ProjectDefaults->{'LCT64'}{'MonitoredSquibs'} };
    }
    else {
        S_set_warning("ProjectDefaults->{'LCT64'}{'MonitoredSquibs'} not defined, considered the default 'ALL'");
        @LCT_ChannelsSection = ('ALL');
    }

    #empty the already existing channel configuration
    @LCT_channels = ();

    if ( scalar(@LCT_ChannelsSection) == 1 and $LCT_ChannelsSection[0] eq 'ALL' ) {
        @LCT_ChannelsSection = LIFT_TSG4::TSG4_get_names('SQUIBS');
    }

    #parse through all channel definitions and do basic validation
    foreach my $channelIndex (@LCT_ChannelsSection) {

        if ( exists $LIFT_TSG4::TSG4_labels->{$channelIndex}{"number"} ) {
            my $number = $LIFT_TSG4::TSG4_labels->{$channelIndex}{"number"};
            $LCT_channels_mapping{$channelIndex} = $number;
            push( @LCT_channels, $number );
        }
        else {
            #invalid channel definition
            S_set_error( "Could not find TSG4 label for MonitoredSquibs definition : $channelIndex", 20 );
        }
    }

    #check and validate external trigger settings
    if ( defined $main::ProjectDefaults->{'LCT64'}{'TriggerSlopeType'} ) {
        my $slopeType = $main::ProjectDefaults->{'LCT64'}{'TriggerSlopeType'};

        #validate slope type
        unless ( $slopeType =~ /positive/i || $slopeType =~ /negative/i ) {
            S_set_error( "Invalid 'SlopeType' specified for ProjectDefaults->{'LCT64'}{'TriggerSlopeType'}. 'SlopeType' shall be 'positive' or 'negative'", 20 );
            return 0;
        }

        #change signal mode to DLL understandable number (positive = 1, negative = 2)
        $slopeType = 'p' if ( $slopeType =~ /positive/i );
        $slopeType = 'n' if ( $slopeType =~ /negative/i );

        $externalTrigger = $slopeType;
    }
    else {
        S_set_warning("ProjectDefaults->{'LCT64'}{'TriggerSlopeType'} not defined, considered the default 'negative'");
        $externalTrigger = 'n';
    }

    S_w2log( 1, "LCT_InitHW\n" );

    if ($main::opt_offline) {

        #set the flag for initialization
        S_w2log( 4, "LCT_InitHW: Initialized in offline mode \n" );
        $LCT_initialized = 1;
        return 1;
    }

    #get the LCT internal details and report in the log
    my ( $deviceID, $swVersion, $fpgaVersion, $tst, $cal, $settings );

    # Helps if previous measurement failed by missing trigger and LCT is still waiting for it (increase of recovery robustness)
    $status = lct_reset_FPGAandFIFO(1);
    Check_status($status);

    ( $status, $deviceID ) = lct_get_HW_id(1);
    Check_status($status);
    ( $status, $swVersion ) = lct_get_firmware(1);
    Check_status($status);
    ( $status, $fpgaVersion ) = lct_get_FPGA_firmware(1);
    Check_status($status);

    ( $status, $tst ) = lct_get_INFO( 1, 'TST' );
    Check_status($status);
    ( $status, $cal ) = lct_get_INFO( 1, 'CAL' );
    Check_status($status);

    #configure gerneral settings of the LCT
    S_w2log( 4, "Configuring LCT General settings \n" );
    $status = lct_enable_channel( 1, \@LCT_channels );
    Check_status($status);
    S_w2log( 4, "LCT EnableChannel status = $status\n" );

    S_w2log( 4, "Configuring External Trigger for LCT with '$externalTrigger' slope\n" );
    $status = lct_configure_trigger( 1, $externalTrigger );
    Check_status($status);
    S_w2log( 4, "LCT ConfigureTrigger status = $status\n" );

    ( $status, $settings ) = lct_get_FPGA_data(1);
    Check_status($status);

    #log the internal details of LCT
    S_w2log( 4, "LCT Details : DeviceId = $deviceID\n" . "Software Version = $swVersion\n" . "FPGA firmware = $fpgaVersion\n" . "test date = $tst\n" . "calibration date = $cal\n" . "FPGA settings = $settings\n" );

    $LCT_initialized = 1;

    #if status is -ve, print error log
    if ( $status < 0 ) {
        S_set_error( "could not initialize LCT", 5 );
        $LCT_initialized = 0;
    }

    return 1;
}

=head2 LCT_plot_values

    LCT_plot_values($plotfilename);

Plots the recorded signals for All the configured channels into UNIVIEW formatted file. (data with semi-colon seperated format)

    $plotfilename : the file name for the UNIVIEW plot and the picture

=cut

sub LCT_plot_values {
    my $plotfilename = shift;

    unless ( defined($plotfilename) ) {
        S_set_error( "! too less parameters ! SYNTAX: LCT_plot_values( \$plotfilename )", 110 );
        return 0;
    }

    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return 0;
    }

    S_w2log( 1, "LCT_plot_values\n" );

    $plotfilename =~ s/\.(\S+)$//;    # cut off file extension
    my $picname = $plotfilename . ".png";
    my $unvName = $plotfilename . ".txt.unv";

    if ($main::opt_offline) {

        #create dummy pictures and return
        S_create_dummy_pic($picname);
        S_create_dummy_file($unvName);
        return 1;
    }

    unless ( defined $LCT_plot_data_href ) {
        LCT_get_values();
    }

    EVAL_dump2UNV( $LCT_plot_data_href, $unvName );

    my ( $time, @legend, $value, @gdData, $count, $graph, $last_time, $step_time, @timestamps );
    @legend = @gdData = @timestamps = ();

    @timestamps = sort { $a <=> $b } keys %{$LCT_plot_data_href};

    if ( scalar(@timestamps) < 1 ) {
        S_create_dummy_pic($picname);
        S_create_dummy_file($unvName);
        S_set_error( "no data in data_HoH", 0 );
        return;

    }
    else {
        my $dt = $timestamps[-1] / ( scalar(@timestamps) * 10 );    # set plot stepwidth to 1/100 of the average time distance between 2 points
        @legend = sort keys %{ $LCT_plot_data_href->{ $timestamps[0] } };    # extract names in sorted order to match with values later
        my $channels = scalar(@legend);
        $last_time = 0;
        $step_time = $timestamps[0];

        # fill @gdData with times and values

        for ( my $i = 0 ; $i < scalar(@timestamps) ; $i++ ) {
            $time = $timestamps[$i];

            # fill inbetween time stamps if there is a gap
            while ( $time - $dt > ($step_time) ) {
                $step_time += $dt;
                $count = 1;
                push( @{ $gdData[0] }, $step_time );
                foreach my $signal ( sort keys %{ $LCT_plot_data_href->{$last_time} } ) {
                    $value = $LCT_plot_data_href->{$last_time}->{$signal};

                    # value can be 1 or 0, to get a better view reduce signal to 0.5 and stack signals
                    # value/2 + squibnr
                    push( @{ $gdData[$count] }, ( $value / 2 ) + $channels + 1 - $count );
                    $count++;
                }
            }

            push( @{ $gdData[0] }, $time );
            $count     = 1;
            $last_time = $time;
            $step_time = $time;

            foreach my $signal ( sort keys %{ $LCT_plot_data_href->{$time} } ) {
                $value = $LCT_plot_data_href->{$time}->{$signal};

                # value can be 1 or 0, to get a better view reduce signal to 0.5 and stack signals
                # value/2 + squibnr
                push( @{ $gdData[$count] }, ( $value / 2 ) + $channels + 1 - $count );
                $count++;
            }

        }

        # dynamic size of picture depending on number of channels
        $graph = GD::Graph::lines->new( 800, $channels * 24 + 80 );

        $graph->set(
            x_label          => "time in ms (0 to $last_time)",
            title            => 'LCT64 trace',
            x_tick_number    => 'auto',
            r_margin         => 10,
            l_margin         => 10,
            b_margin         => 10,
            transparent      => 0,
            bgclr            => "black",
            fgclr            => "white",
            textclr          => "white",
            labelclr         => "white",
            axislabelclr     => "white",
            legendclr        => "white",
            valuesclr        => "white",
            y_max_value      => ( $channels + 1 ),
            y_min_value      => 0,
            legend_placement => 'RC',
        );

        $graph->set_legend_font( GD::Font->Large );
        $graph->set_legend(@legend);

        if ( open( my $pic, ">", "$picname" ) ) {
            binmode $pic;
            print $pic $graph->plot( \@gdData )->png;
            close($pic);
        }
        else { S_set_error( " Couldnt open PNG file '$picname' ", 1 ); return; }

    }
    S_w2log( 4, "LCT PlotUNV For AllChannels status=$status\n" );

    return 1;
}

=head2 LCT_SendSWTrigger

    LCT_SendSWTrigger();

Triggers the LCT64 by software. The LCT64 starts recording as soon as it gets the software trigger.
Measurement should be already started (by L</"LCT_StartMeasurement">()) before calling this function.

    e.g.:

        LCT_SendSWTrigger();

=cut

sub LCT_SendSWTrigger {
    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return 0;
    }

    S_w2log( 1, "LCT_SendSWTrigger\n" );

    if ($main::opt_offline) {
        return 1;
    }

    #send trigger via Software
    ($status) = lct_invoke_trigger(1);
    Check_status($status);
    S_w2log( 4, "LCT SendSWTrigger status=$status\n" );

    return 1;
}

=head2 LCT_get_device_status

    01000110 = LCT_get_device_status();

reads out device status.

	Byte 1: Record Timer full ---1=full 
	Byte 2: Data Direction --- 1=Input (recorder Mode)
	Byte 3: Reset Status --- 1= FPGA in Reset state
	Byte 4: Measurement Active -- 1=Active
	Byte 5: Trigger Enable Status --- 1=Enabled
	Byte 6: Trigger In Edge --- 1 = negative Edge
	Byte 7: Trigger Out Enable Status --- 1=Enabled
	Byte 8: Trigger Out Polarity --- 1= Inverted"

	error return 00000000
	offline return 11111111

    e.g.:

        $status = LCT_get_status();

=cut

sub LCT_get_device_status {
	my $lct_status;
    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return '00000000';
    }

    S_w2log( 1, "LCT_get_device_status\n" );

    if ($main::opt_offline) {
        return '11111111';
    }

    #read device stauts
    ($status, $lct_status) = lct_get_INFO(1, 12);
    #replace value with error return if not ok
    Check_status($status) or $lct_status = '00000000';
    S_w2log( 4, "LCT device_status=$lct_status status=$status\n" );

    return $lct_status;
}

=head2 LCT_StartMeasurement

    LCT_StartMeasurement();

starts a new measurement and waits for trigger.
Until the configured trigger or Software trigger(refer L</"LCT_SendSWTrigger">()) is obtained , the LCT64 will not start recording.

    e.g.:

         LCT_StartMeasurement();

=cut

sub LCT_StartMeasurement {

    #check whether LCT is initialized
    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return 0;
    }

    S_w2log( 1, "LCT_StartMeasurement\n" );

    #return 1 in offline mode
    if ($main::opt_offline) {
        return 1;
    }

    undef $LCT_plot_data_href;

    #start measurement
    ($status) = lct_enable_trigger(1);
    Check_status($status);
    S_w2log( 4, "LCT StartMeasurement status=$status\n" );

    return 1;
}

=head2 LCT_StopMeasurement

    LCT_StopMeasurement();

stops the already running measurement, if any.
If measurement is not running, no error will be returned.

    e.g.:

         LCT_StopMeasurement();

=cut

sub LCT_StopMeasurement {

    #check whether LCT is initialized
    unless ($LCT_initialized) {
        S_set_error( "LCT not initialized", 120 );
        return 0;
    }

    S_w2log( 1, "LCT_StopMeasurement\n" );

    #return 1 in offline mode
    if ($main::opt_offline) {
        return 1;
    }

    #stop measurement
    $status = lct_reset_FPGA_only(1);
    Check_status($status);
    tsg4_wait_ms(100);
    ($status) = lct_disable_trigger(1);
    Check_status($status);
    S_w2log( 4, "LCT StopMeasurement status=$status\n" );

    return 1;
}

=head1 not exported functions

=head2 LCT_Extract_pulses

	($pulses_href,$numOfActualPulses) = LCT_Extract_pulses($timearray,$channeldata,$slopeType);

extract pulses and return data structure

=cut

sub LCT_Extract_pulses {
    my $timearray   = shift;
    my $channeldata = shift;
    my $slopeType   = shift;

    my ( $startTime, $traceFinishTime, $wasConditionPassed, %pulses, $numOfActualPulses );
    $numOfActualPulses  = 0;
    $wasConditionPassed = 0;

    for ( my $count = 0 ; $count < scalar(@$timearray) ; $count++ ) {
        my $isConditionPassed = 0;
        my $previousTime;
        my $time = $$timearray[$count];
        my $data = $$channeldata[$count];

        #store the previous time
        $previousTime = $traceFinishTime;

        #store current time as trace finish time, so that it shall be used to store 'end' time, outside of loop
        $traceFinishTime = $time;

        #determine whether the signal satisfies the pulse condition & slope
        $isConditionPassed = 1 if ( $slopeType == RISING  && ( $data > 0 ) );
        $isConditionPassed = 1 if ( $slopeType == FALLING && ( $data == 0 ) );

        if ( $isConditionPassed == 1 ) {

            #if this is the first element that satisfies the slope
            $startTime = $time if ( $wasConditionPassed == 0 );
            $wasConditionPassed = 1;
        }
        else {
            #if slope was satified
            if ($wasConditionPassed) {
                $pulses{ 'pulse' . $numOfActualPulses }{'start'} = $startTime;
                $pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $time;
                $numOfActualPulses++;
                $wasConditionPassed = 0;
            }

        }
        print "$time $isConditionPassed $data\n";

    }

    #check if the pulse was still ongoing at the time of exit of forloop
    if ($wasConditionPassed) {
        $pulses{ 'pulse' . $numOfActualPulses }{'start'} = $startTime;
        $pulses{ 'pulse' . $numOfActualPulses }{'end'}   = $traceFinishTime;

        $numOfActualPulses++;
    }

    return ( \%pulses, $numOfActualPulses );
}

=head2 Check_status

 Check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_status {
    my $result = shift;

    return 1 if $main::opt_offline;
    if ( $result < 0 ) {
        my $errortext = lct_get_error($result);
        S_set_error( "LCT ($result): $errortext", 5 );
		return 0;
    }

    return 1;
}

#return 1 (default for all perl modules)
1;

__END__

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

Low level LCT64 module

=cut
