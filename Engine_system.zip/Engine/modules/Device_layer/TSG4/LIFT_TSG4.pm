# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2014  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_TSG4;

use strict;
use warnings;
use LIFT_general;
use LIFT_TRC;
use LIFT_TOE1;

use Data::Dumper;

use tsg4;
use tsg4_bl;
use tsg4_canfr;
use tsg4_dvm;
use tsg4_klin;
use tsg4_pas;
use tsg4_rc;
use tsg4_sq;
use tsg4_tr;
use tsg4_trc;
use tsg4_trg;
use tsg4_ubat;
use tsg4_via;
use tsg4_wl;
use tsg4_rdec;
use tsg4_spdt;
use tsg4_lct64;
use tsg4_ppt;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
                    TSG4_add_pins_to_short
                    TSG4_remove_pins_from_short
                    TSG4_CloseHW
                    TSG4_ConfigureTRCchannels
                    TSG4_ConnectLine
                    TSG4_ConnectVIA
                    TSG4_createRandomFile
                    TSG4_DecodeLampStates
                    TSG4_DisconnectLine
                    TSG4_DisconnectVIA
                    TSG4_event_trigger_LTT_CREIS
                    TSG4_get_CANid
                    TSG4_get_names
                    TSG4_InitHW
                    TSG4_LogAllDevices
                    TSG4_lowlevel_command
                    TSG4_lowlevel_init
                    TSG4_LV124_E10
                    TSG4_LV124_E13
                    TSG4_LV124_microcut
                    TSG4_PWM_configure
                    TSG4_PWM_Disposal
                    TSG4_PWM_stop
                    TSG4_PWM_Trace
                    TSG4_ResetDVMscanner
                    TSG4_ResetInertSquibMode
                    TSG4_ResetTRCscanner
                    TSG4_runCurve
                    TSG4_runCurveOnTrigger
                    TSG4_SetCurrent
                    TSG4_setCurveFile
                    TSG4_SetDVMscanner
                    TSG4_SetLogicalState
                    TSG4_SetResistance
                    TSG4_SetInertSquibMode
                    TSG4_SetSquibCurrentThreshold
                    TSG4_SetTRCscanner
                    TSG4_SetVoltage
                    TSG4_ShortLines
                    TSG4_Standby
                    TSG4_stopCurve
                    TSG4_UndoShortLines
                    TSG4_SetSquibFireMode
                    TSG4_ConnectSquibToOpAmp
                    TSG4_DisconnectSquibFromOpAmp
);

our ($VERSION,$HEADER);

my $status;             # Variable to hold the status of operation
my @TSG4_PSlines;       # Array of names of powersupply lines used in the project
our $TSG4_initialized;   # flag for TSG4 initialization
our $TSG4_labels;        # A hash reference used to keep track of Labels used in the project
our $detectedDevices;     # A hash reference used to keep track of firmwares in TSG4

#sections for different Pins present in a TSG4
my @TSG4Sections = ('POWER_SUPPLY_LINES', 'SQUIBS', 'BELT_LOCKS', 'CAN_FR', 'K_LIN', 'PAS_LINES', 'WARNING_LAMPS');
my $trc_merger_used = 0; # flag for TRC merger connector (connect X-scan1 and X-scan2 for TRC)
my $trc_config; # hash structure for configuring TRC
my %Ref_use; # which ref is used by which terminal $Ref_use{terminal}=via
my $UF_supply; # which power suppply is connected to UF
my $Ubat_supply; # which power suppply is connected to Ubat
my %DVM_present; # DVM scanner present in TSG4 (all numbers)
my %TRC_present; # TRC scanner present in TSG4 (all numbers)
my %Scan_use=( # which scanner is in use $Scan_use{scanner} e.g. $Scan_use{D1}=1 DVM scanner 1 in use, 
              # $Scan_use{T5}=0 TRC scanner 5 not in use
    'D1' => '0',
);
foreach my $trc (1..64){
	$Scan_use{'T'.$trc}='0';
}

my %section_mapping=(
    'SQUIBS' => 'SQ',
    'BELT_LOCKS' => 'BL',
    'CAN_FR' => 'CANFR',
    'K_LIN' => 'KLIN',
    'PAS_LINES' => 'PAS',
    'WARNING_LAMPS' => 'WL',
    'POWER_SUPPLY_LINES' => 'PSL', # was UBAT before
);

my %type_mapping=(
    'LIN' => 'L',
    'Lline' => 'N',
    'Kline' => 'K',
);

my $scan_map;
my $via_target;
my $short_active;
my @short_active_lines;

#initialize with default values
$TSG4_initialized = 0;

=head1 NAME

LIFT_TSG4 

Perl extension for TSG4

=for html
<IMG SRC='..\..\pics\TSG4_front_view.png' alt="TSG4_front_view" border="0"></a> <IMG SRC='..\..\pics\TSG4_rear_view.png' alt="TSG4_rear_view" border="0"></a>

=head1 SYNOPSIS

    use LIFT_TSG4;

    TSG4_InitHW();

    TSG4_SetVoltage('U_BATT_DEFAULT');
    TSG4_DisconnectLine( 'BT1FP' );
    TSG4_ConnectLine( 'BT1FP' );
    TSG4_SetLogicalState( 'PADS', 'PAB_disabled' );
    TSG4_ShortLine( ['AB1FD+', 'BT1FP-'], 100);
    TSG4_UndoShortLine( );
    TSG4_SetResistance( 'AB1FP',150);

    TSG4_SetCurrent( 'PADS',25.50);
    TSG4_SetLogicalState( 'PADS', 'PAB_enabled' );
    TSG4_CloseHW();

    TSG4_lowlevel_command( 'tr_connect_DUT()' );

=head1 CONFIGURATION

in case you need to define a device which should NOT be connected by default, you can use 'not_connected' as default value for 
BELT_LOCKS, SQUIBS, PAS_LINES, WARNING_LAMPS, CAN_FR and K_LIN devices. This is useful if you have several variants of your project.

The complete ProjectConst section for TSG4 can be generated by the L<TSG4 wizard|http://si-airbag-web.de.bosch.com/support/testportal/common/tsg4/TSG4_Wizard/tsg4_wizard.htm>.

B<ProjectConst:> 

       'VEHICLE' => {
                        'U_BATT_DEFAULT'   => 13.8,
                    },

       'TSG4' => {
            'General' =>
                       {
                          # CAN settings will be overwritten form testbench config settings
                          'MaxVoltage' => 20,
                       },

            'SQUIBS' =>
                       {
                        'SQ1_Name' => 'AB1FD',
                        'SQ1_Default' => '2.2',
                        'SQ2_Name' => 'BT1FP',
                        'SQ2_Default' => '2.2',
                        'SQ3_Name' => 'AB1FP',
                        'SQ3_Default' => '2.2',
                        'SQ4_Name' => 'AB2FD',             # this will not be connected by TSG4_InitHW
                        'SQ4_Default' => 'not_connected',  # this will not be connected by TSG4_InitHW
                       },

            'POWER_SUPPLY_LINES' =>
                       {
                        'PSL1_Name' => 'UB1',
                        'PSL1_Default' => 'UF',    # UF or Ubat
                        'PSL2_Name' => 'UB2',
                        'PSL2_Default' => 'Ubat',
                       },

            'PAS_LINES' =>
                       {
                        'PAS_1_1_Name' => 'PPSL',
                        'PAS_1_2_Name' => 'PPSR',
                        'PAS_2_1_Name' => 'UFS1',
                        'PAS_5_1_Name' => 'UFS2',              # this will not be connected by TSG4_InitHW
                        'PAS_5_1_Default' => 'not_connected',  # this will not be connected by TSG4_InitHW
                       },

            'BELT_LOCKS' =>
                       {
                        'BL4_Name' => 'PADS',
                        'BL4_Unit' => 'I',            # I or R
                        'BL4_Default' => '10',
                        'BL4_state_PAB_enabled' => '3.3',
                        'BL4_state_PAB_disabled' => '10',

                        'BL3_Name' => 'BLR2P_VW',
                        'BL3_Unit' => 'R',
                        'BL3_Default' => '20',
                        'BL3_state_buckled' => '100',
                        'BL3_state_unbuckled' => '400',
                        'BL3_state_short' => '20',
                        'BL3_state_open' => '9990',

                        'BL2_Name' => 'BLRR',
                        'BL2_Unit' => 'R',
                        'BL2_Default' => '400',
                        'BL2_state_buckled' => '100',
                        'BL2_state_unbuckled' => '400',
                       },

            'CAN_FR' =>
                       {
                        'CF1_Name'   => 'CANdiag',
                        'CF5_Name'   => 'FlexRay',
                       },

            'K_LIN' =>
                       {
                        'KL3_Name'   => 'Lin1',
                        'KL3_Type'   => 'LIN',           # LIN Lline or Kline
                        'KL4_Name'   => 'K-line',
                        'KL4_Type'   => 'Kline',
                        'KL4_output' => 'inverted',      # (optional) 'inverted' or 'normal' output for Lline or Kline; default is 'normal'
                       },

            'WARNING_LAMPS' =>
                       {
                        'WL_1_5_Name'   => 'PADL',
                        'WL_1_3_Name'   => 'DISP',
                       },

            'DVM_SCANNER' =>
                       {
                        'DVM1_Name'   => 'DVM1',
                       },

            'TRC_SCANNER' =>
                       {
                        'TRC1_Name'   => 'TRC1',
                        'TRC2_Name'   => 'TRC2',
                        'TRC3_Name'   => 'TRC3',
                        'TRC4_Name'   => 'TRC4',
                        'TRC32_Name'  => 'TRGscanner', #trigger scanner
                       },
            'TRG' =>
                       {
                        'TRG1_Name'   => 'TRG1', # trigger card
                       },

            'TRC_MERGER' =>
                       {
                        'MERGER'   => 'used',  # blue connector on scanner rack (connect X-scan1 and X-scan2 for TRC)
                       }, 
       },


	# optional addon for project specific changes
	# used by TSG4_SetDVMscanner and TSG4_SetTRCscanner
	'TSG4_SCANNER' => {
		'DVM' => {
			'UBSense'   => 'D1.1', # add new name
		},
		'TRC' => {
			'WL1_4' => 'T25.5', # re-map to front
		},
	}
	


	for TSG4_ConfigureTRCchannels

       'TRANSI' => {
           'General'   => {
               'SamplingFrequency' => 200 * 1000  , # in Hz , 2 KHz
               'MemorySize'        =>  128 * 1024 , # in bytes, 128 KB
               'TriggerDelay'      =>  0 ,          # from -99% to 200%
           },
           'EXTERNAL_TRIGGER' => {
               'SlopeType'   => 'positive',  # 'positive' or 'negative'
           },
       },



B<TestBench Config:>



     'COB409407' => {      # LIFT PC host name
            ### ----------- Device Configuration Section ------ 
            'Devices' => {
               'TSG4' => {
                    'Test_Bench_Number' => 10,          # only for logging purpose
                    'Description' => "SW Test Team",    # only for logging purpose

                    'CANchannel' => 2,                  # CAN channel used to communicate with TSG4 (only CAN channels are counted)
                    									# CAN channel on VN box is not CH number on box! CH1 = FlexRay so CH2 = CANchannel 1
                    'CANHWSerialNo' => 30679,           # written on CAN device e.g. "007129-030679" -> 30679,
                                                        # CANHWSerialNo is optional if only one HW connected
                    'POWER' => {
                        ### configure power inputs: (internal or TOE1)
                        ### if LIFT_labcar is used then the TSG4 power settings will be ignored
                        'Ubat' => 'internal',
                        'UF' => 'TOE1',
                    },
                },

                'TOE1' => {
                    'connect' => 'GPIB:8',
                },

            },
     },




=head1 DESCRIPTION

=head2 TSG4_CloseHW

    TSG4_CloseHW();

has to be called at the end, will disconnect from TSG4. should be called in ENDcampaign

=cut

sub TSG4_CloseHW{

    unless ( $TSG4_initialized ) {
        S_set_warning( "TSG4 not initialized");
        return 1;
    }

    S_w2log(1,"TSG4_CloseHW\n");

    if ($main::opt_offline){
        #clear the global flags
        $TSG4_initialized = 0;
        %Ref_use=();
        return 1;
    }

    $status = tsg4_exit();
    Check_status($status);
    S_w2log(4,"TSG4_CloseHW status=$status\n");

    #clear the global flags
    $TSG4_initialized = 0;
    %Ref_use=();

	return 1;
}

=head2 TSG4_DecodeLampStates

    $wl_trace_data_ref = TSG4_DecodeLampStates( $can_trace_data_ref, $wl1bitmask );

    $wl1bitmask bit order is 123456 e.g. 010000 for WL_1_2

    extract wl signals from CAN trace structure.
    currently extracts only data for Wl card 1

   NOTE: [0x65,1] the CAN ID and the bus number depend on your setup (dec or hex IDs in CANoe, bus connection for TSG4)

   usage:
   my $trace_data_ref = CA_trace_can_get_dataref ( 'C:\test\PWM.asc', ([0x65,1],[65,1]) );
   my $WLtrace_ref = TSG4_DecodeLampStates($trace_data_ref,'100000');

    will lead to this data structure
    3831.419 WL_1_1=0
    3831.619 WL_1_1=0
    3831.819 WL_1_1=0
    3832.019 WL_1_1=1
    3832.219 WL_1_1=1
    3832.419 WL_1_1=1


returns 

=cut

sub TSG4_DecodeLampStates{
	my $can_trace_data_ref = shift;
	my $wl1bitmask = shift;
	my $wl_trace_data_ref;
	my $dummy_return;
	$dummy_return->{0}{"WL_0_="}=0;


    S_w2log(1,"TSG4_DecodeLampStates\n");

    if( ref($can_trace_data_ref ) ne "HASH" ) {
        S_set_error( "First parameter (\$can_trace_data_ref ) is not a hash reference", 114 );
        return $dummy_return;
    }

    if ($main::opt_offline){
        return $dummy_return;
    }

#    my @signals = (0x65,0x67,0x69,0x6B);
    my @signals = (0x65,65);
    my %cycle_us = ();
    my $bitmasks={};

    $bitmasks->{0x65} = [split(//,$wl1bitmask)];
    $bitmasks->{65} = [split(//,$wl1bitmask)];

# todo: give filter for all lamps to be extracted
# todo: derive signals from filter (which ID for which lamp)
# todo: derive frequency signal and on/off signal ???

	foreach my $signal (@signals){
		my @times=();
	    # calculate $cycle per signal from trace
	    foreach my $time_current ( sort { $a <=> $b } keys %$can_trace_data_ref )
	    {
		        if( defined $can_trace_data_ref->{$time_current}{$signal}){
					push (@times,$time_current);
		        }
		        if(scalar(@times) > 9){
#		        	print" TTT @times\n";
		        	my $sum = 0;
		        	for (my $count=0;$count<scalar(@times)-1;$count++){
		        		$sum += $times[$count+1]-$times[$count];
#		        		print"+ $sum delta ".($times[$count+1]-$times[$count])."\n";
		        	}
		        	my $cycle = $sum / (scalar(@times)-1) / 8;
		        	$cycle_us{$signal} = sprintf("%.3f",$cycle);

	        		print"$signal $cycle_us{$signal} \n";

		        	last; # stop loop when enough samples
		        }
	    } # end foreach
	}

    foreach my $time_current ( sort { $a <=> $b } keys %$can_trace_data_ref )
    {
		foreach my $signal (@signals){
	        if( defined $can_trace_data_ref->{$time_current}{$signal}){
				my $hex_value = $can_trace_data_ref->{$time_current}{$signal};
			    ## example taken form perlmonks.org: 
			    ## How can I split a string into chunks of size n bytes?
			    my @array = unpack ("a2" x (length( $hex_value ) /2 ) ,$hex_value);
			    #convert elements to lamps
			    my $calcualted_time=$time_current;
			    foreach my $item (@array){
			    	$calcualted_time = sprintf("%06.3f",$calcualted_time);
			        $item = sprintf("%08b",hex($item));
			        my @bits= split (//,$item);
					for (my $count=0;$count<6;$count++){
						next if $bitmasks->{$signal}[$count] == 0;
						$wl_trace_data_ref->{$calcualted_time}{"WL_1_".($count+1)}=$bits[$count];
					}
					$calcualted_time+=$cycle_us{$signal};
			    }
	        }
		}

    } # end foreach

    S_w2log( 4, " TSG4_DecodeLampStates : done\n" );
	return ($wl_trace_data_ref);

}

=head2 TSG4_SetDVMscanner

    TSG4_SetDVMscanner( $label );

$label has to be a label from ProjectConst (TSG4 device name or from TSG4_SCANNER) 

 $label may have ::current attached e.g. 'UB2::current'
 $label may have ::H or ::L or ::G attached for CAN pins 
 $label may have ::K or ::N or ::L attached K-line/LIN pins 

will switch scanner to corresponding position

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetDVMscanner( 'BT1FP::current' );
    TSG4_SetDVMscanner( 'PPSL' );

=cut

sub TSG4_SetDVMscanner{
    my $dvmLabel = shift;

    unless (defined( $dvmLabel )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_SetDVMscanner( \$label )", 110 );
        return 0;
    }

# WL +  PAs handling is checked 

	my $append = '';
	my $label=$dvmLabel;

	# remove opt trailing string from label for mapping
	if ($label =~ s/::current$//){
		$append = '_I';
	}
	if ($label =~ s/::(H|L|G|K|N)$//){
		$append = "$1";
	}

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

	my $device = '';

	# use section mapping, if no section found, try label directly
    if (defined $type){
   		$device = $section_mapping{$type}.$number.$append;
    }
    else{
   	    $device = $label.$append;
    }

	my $scanner = '';

    $scanner = $scan_map->{'DVM'}{$device};
    $scanner = $scan_map->{'TRC'}{$device} unless defined ($scanner);

    unless ( defined $scanner ) {
        S_set_error( "$label mapped to $device does not have a scanner channel assigned" , 20);
        return 0;
    }


    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_SetDVMscanner( $label ) -> scanner $scanner\n");

    return 1 if $main::opt_offline;

    unless ( exists $DVM_present{1} ) {
        S_set_error( "DVM scanner 1 not present" , 120);
        return 0;
    }

	#decode and set scanner
	if ($scanner =~ /^D(\d+)\.(\d+)$/){
		my $hi = $1;
		my $lo = $2;

		if($Scan_use{'D1'} ne '0'){
	        S_set_error( "DVM scanner 1 already in use by $Scan_use{'D1'}" , 120);
	        return 0;
		}

		$status = dvm_connect_hi(1,$hi);
    	Check_status($status);
		$status = dvm_connect_lo(1,$lo);
    	Check_status($status);
		$Scan_use{'D1'} = 'DVM:'.$dvmLabel;

	}
	elsif ($scanner =~ /^T(\d+)\.(\d+)$/){
		my $muxChannel = $2;
		my $trcscanner = $1;

		if($Scan_use{'D1'} ne '0'){
	        S_set_error( "DVM scanner 1 already in use by $Scan_use{'D1'}" , 120);
	        return 0;
		}
		if($Scan_use{'T'.$trcscanner} ne '0'){
	        S_set_error( "TRC scanner $trcscanner already in use by $Scan_use{'T'.$trcscanner}" , 120);
	        return 0;
		}
		my ($trcNumber, $trcChannel) = TSG4_TRC_map($trcscanner);

		$status = trc_connect_DVM($trcNumber, $trcChannel);
    	Check_status($status);
		$status = trc_connect($trcNumber, $trcChannel, $muxChannel);
    	Check_status($status);
		$Scan_use{'T'.$trcscanner} = 'DVM:'.$dvmLabel;
		$Scan_use{'D1'} = 'DVM:'.$dvmLabel;
	}
	else{
        S_set_error( "scanner $scanner has wrong format" , 20);
        return 0;
	}
    return 1;
}

=head2 TSG4_ResetDVMscanner

    TSG4_ResetDVMscanner( );

will reset corresponding scannerposition(s)

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_ResetDVMscanner();

=cut

sub TSG4_ResetDVMscanner{

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_ResetDVMscanner\n");

    return 1 if $main::opt_offline;

	#decode and set scanner
	if ($Scan_use{'D1'} =~ /^DVM:/){

		$status = dvm_reset(1);
    	Check_status($status);
		$Scan_use{'D1'}='0';

	}
	foreach my $trcscanner (1..64){
		if ($Scan_use{'T'.$trcscanner} =~ /^DVM:/){
			my ($trcNumber, $trcChannel) = TSG4_TRC_map($trcscanner);
			$status = trc_disconnect_DVM($trcNumber);
	    	Check_status($status);
			$status = trc_disconnect($trcNumber, $trcChannel);
	    	Check_status($status);
			$Scan_use{'T'.$trcscanner}='0';
		}
	}
    return 1;
}


=head2 TSG4_ConfigureTRCchannels

    TSG4_ConfigureTRCchannels([$TRC_general_config_href],[$TRC_ExtTrg_config_href]);

(re)configures transient recorder channel settings with data generated by TSG4_SetTRCscanner, has to be called after last TSG4_SetTRCscanner and before next usage of transient recorder.

calls internally TRC_ConfigureChannels

$TRC_general_config_href and $TRC_ExtTrg_config_href can be used to overwrite "General" and "EXTERNAL_TRIGGER" from Project_Defaults. 

           $TRC_general_config_href   = {
               'SamplingFrequency' => 200 * 1000  , # in Hz , 2 KHz
               'MemorySize'        =>  128 * 1024 , # in bytes, 128 KB
               'TriggerDelay'      =>  -25 ,        # from -99% to 200%
           };
           
           $TRC_ExtTrg_config_href = {
               'SlopeType'   => 'positive',  # 'positive' or 'negative'
           };
           
TRC has to be initialized once before by calling TRC_InitHW();

 e.g.
    TSG4_ConfigureTRCchannels();
 	TSG4_ConfigureTRCchannels({ 'SamplingFrequency'=>20*1000, 'MemorySize'=>256*1024, 'TriggerDelay'=>0 } );
 	TSG4_ConfigureTRCchannels( undef , { 'SlopeType'=>'positiv' } );
=cut

sub TSG4_ConfigureTRCchannels{
	my $TRC_general_config_href = shift;
	my $TRC_ExtTrg_config_href = shift;
	
    #	check whether necessary parameters are defined
	if (defined $TRC_general_config_href)
	{
		unless(exists $TRC_general_config_href->{SamplingFrequency} && exists $TRC_general_config_href->{MemorySize} &&  exists $TRC_general_config_href->{TriggerDelay})
	    {
	        S_set_error( "'SamplingFrequency' is not defined in 'TRC_general_config_href'" , 20) unless (exists $TRC_general_config_href->{SamplingFrequency});
	        S_set_error( "'MemorySize' is not defined in 'TRC_general_config_href'" , 20) unless (exists $TRC_general_config_href->{MemorySize});
	        S_set_error( "'TriggerDelay' is not defined in 'TRC_general_config_href'" , 20) unless (exists $TRC_general_config_href->{TriggerDelay});
	        return 0;   
	    }
	}

    # check and validate external trigger settings
    if(defined $TRC_ExtTrg_config_href)
    {            
        # validate slope type
        unless($TRC_ExtTrg_config_href->{'SlopeType'} =~ /positive/i || $TRC_ExtTrg_config_href->{'SlopeType'} =~ /negative/i ){
            S_set_error( "Invalid 'SlopeType' specified for 'TRC_ExtTrg_config_href'. 'SlopeType' shall be 'positive' or 'negative'" , 20);
            return 0;
        }
    }

	# update predefined TRC_config with input date if given
	$trc_config->{'General'} = $TRC_general_config_href if (defined $TRC_general_config_href);
	$trc_config->{'EXTERNAL_TRIGGER'} = $TRC_ExtTrg_config_href if (defined $TRC_ExtTrg_config_href);
    
	my $timestamp=time();
	my $outFile = $main::REPORT_PATH.'\TRC_config'.$timestamp.'.html';
    open(OUT,">$outFile") or warn("Could not open file.");
	print OUT '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">'.
		'<HTML><HEAD><TITLE>'.$outFile.'</TITLE></HEAD><BODY DIR=LTR BGCOLOR="#FFFFFF">';

    print OUT "START DUMP TRC CONFIG<br>\n";
    $Data::Dumper::Indent = 1;
    $Data::Dumper::Sortkeys = 1;
    $Data::Dumper::Varname = "TRC_config";
    my $dump = Dumper($trc_config);
    $dump =~ s/ /\./g;
    $dump =~ s/\n/<br>/g;
    print OUT $dump;
    print OUT "END DUMP TRC CONFIG<br>\n";
    close(OUT);
    S_w2rep('<A HREF="./TRC_config'.$timestamp.'.html">TRC config used see TRC_config.html</A><br>');

    # offline handling done in TRC_ConfigureChannels
    LIFT_TRC::TRC_ConfigureChannels($trc_config);
    return 1;
}

=head2 TSG4_SetTRCscanner

    TSG4_SetTRCscanner( $label_aref, $CH_config_href [, $trgConfig_href] );

$label_aref has to be an array reference of labels from ProjectConst (TSG4 device name or from TSG4_SCANNER) 

$CH_config_href has to be a hash reference of channel settings for TRC

optional: $trgConfig_href has to be a hash reference of channel trigger settings for TRC

 label may have ::current attached e.g. 'UB2::current'
 label may be ALL_SQUIBS::current to select all configured squibs for TSG4
 label may have ::H or ::L or ::G attached for CAN pins
 label may have ::K or ::N or ::L attached K-line/LIN pins

 $CH_config_href example
                #'CouplingMode'   => 'DC',           # uncomment only if needed , 'AC' or 'DC', by default 'CouplingMode = DC'
                 'SignalMode'     => 'differential', # 'single' or 'differential'
                 'VoltageRange'   => 5,              # one of 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100
                #'Offset'         => 0,              # uncomment only if needed, 0% to 100%, by default 'Offset = 0'

 $trgConfig_href example
                 'TriggerVoltage'    =>  3.5,       # should be less than or equal to value in 'VoltageRange' of the particular Channel
                #'Hysteresis'        =>  3.0,       # uncomment only if needed,  by default 'Hysteresis = TriggerVoltage'
                 'SlopeType'         => 'positive', # 'positive' or 'negative'


will switch scanner(s) to corresponding position(s) and create data structure for transient recorder settings.

can be called several times for accumulatinng different settings in one TRC configuration

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetTRCscanner( ['ALL_SQUIBS::current'], {'SignalMode' => 'differential','VoltageRange' => 5} );
    TSG4_SetTRCscanner( ['BT1FP::current','AB1FD::current'], {'SignalMode' => 'differential','VoltageRange' => 5} );
    TSG4_SetTRCscanner( ['PPSL'], {'SignalMode' => 'differential','VoltageRange' => 10}, {'TriggerVoltage' => 3.5, 'SlopeType' => 'positive'} );

=cut

sub TSG4_SetTRCscanner{
    my $trclabel_aref = shift;
    my $chConf_href = shift;
    my $trgConfig_href = shift;
    my @labellist=();

    unless (defined( $trclabel_aref ) and defined( $chConf_href )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_SetTRCscanner( \$label_aref, \$CH_config_href )", 110 );
        return 0;
    }

    unless (exists $$chConf_href{'SignalMode'} and exists $$chConf_href{'VoltageRange'}) {
        S_set_error( "! wrong parameters in CH_config_href! at least SignalMode and VoltageRange have to be set", 110 );
        return 0;
    }

	if (defined $trgConfig_href){
	    unless (exists $$trgConfig_href{'TriggerVoltage'} and exists $$trgConfig_href{'SlopeType'}) {
	        S_set_error( "! wrong parameters in TRG_config_href! at least TriggerVoltage and SlopeType have to be set", 110 );
	        return 0;
	    }
	}

	# delete channel name if given, will be defined by scanner harness mapping
    delete $$chConf_href{'ChannelName'};

    # expand ALL_SQUIBS_current if found
    foreach my $trclabel (@$trclabel_aref){
    	if ($trclabel eq 'ALL_SQUIBS::current'){
    		my @labels = TSG4_get_names( 'SQUIBS' );
    		foreach my $label (@labels){
    			$label .= '::current';
    		}
    		push(@labellist,@labels);
    	}
    	else{
    		push(@labellist,$trclabel);
    	}
    }

	my $errorcount = 0;
	my $trc_settings=();
	my $dvmSettings=();
	my %trcUsed=();
	my @dvmUsed=();

	# map scanners and build data structure
	# loop over all labels
    foreach my $trclabel (@labellist){

		my $append = '';
		my $label=$trclabel;

		# remove opt trailing string from label for mapping
		if ($label =~ s/::current$//){
			$append = '_I';
		}
		if ($label =~ s/::(H|L|G|K|N)$//){
			$append = "$1";
		}

	    #Get Type of device for $label
	    my $type = $TSG4_labels->{$label}{"section"};
	    my $number = $TSG4_labels->{$label}{"number"};

		my $device = '';

		# use section mapping, if no section found, try label directly
	    if (defined $type){
	   		$device = $section_mapping{$type}.$number.$append;
	    }
	    else{
	   	    $device = $label.$append;
	    }

		my $scanner = '';

		# derive scanner from mapping
	    $scanner = $scan_map->{'TRC'}{$device};
	    $scanner = $scan_map->{'DVM'}{$device} unless defined ($scanner);

	    unless ( defined $scanner ) {
	        S_set_error( "$label mapped to $device does not have a scanner channel assigned" , 20);
	        $errorcount++;
	    }

		# if TRC scanner
		if ($scanner =~ /^T(\d+)\.(\d+)$/){
			my $muxChannel = $2;
			my $trcscanner = $1;
	    S_w2log(4,"TSG4_SetTRCscanner( $trclabel ) -> scanner $scanner\n");
			push( @{$trcUsed{$trcscanner}} , $trclabel);

			# lock coupled scanner if TRC merger connector is used
			if ($trc_merger_used){
				my $shadow_scanner;
				if ($trcscanner<=32){
					$shadow_scanner = $trcscanner+32;
				}
				else{
					$shadow_scanner = $trcscanner-32;
				}
				push( @{$trcUsed{$shadow_scanner}} , $trclabel);
			}

	    	$trc_settings->{$trcscanner}{'MUX'} = $muxChannel;
	    	$trc_settings->{$trcscanner}{'NAME'} = $trclabel;
    	    unless ( exists $TRC_present{$muxChannel} ) {
		        S_set_error( "TRC scanner $muxChannel not present. Check if the scanner rack is physically connected and if the scanner channels are configured in the TSG4 mapping." , 5);
		        $errorcount++;
		    }
		}

	    # if DVM scanner
	    if ($scanner =~ /^D(\d+)\.(\d+)$/){
			my $hi = $1;
			my $lo = $2;
	    S_w2log(4,"TSG4_SetTRCscanner( $trclabel ) -> scanner $scanner + DVM2TRC\n");
			push( @dvmUsed , $trclabel);
	    	$dvmSettings->{'HI'} = $hi;
	    	$dvmSettings->{'LO'} = $lo;
	    	$dvmSettings->{'NAME'} = $trclabel;
	    }

    }

    # check labels for double use of scanners
	if (scalar (@dvmUsed) > 1){
        S_set_error( "labels ( @dvmUsed ) map to same DVM scanner" , 109);
        $errorcount++;
	}

	my $lastnum = 1;
	my $free_channel=0;
	foreach my $trcscannner (sort {$a <=> $b} keys %trcUsed){
		if (scalar (@{$trcUsed{$trcscannner}}) > 1){
	        S_set_error( "labels ( @{$trcUsed{$trcscannner}} ) map to same TRC scanner" , 109);
	        $errorcount++;
		}
		# take first free scanner for dvm rerouting
		if ($free_channel == 0 and $trcscannner > $lastnum){
			$free_channel = $lastnum;
		}
		$lastnum++;
	}

	# if no free channel, take last one
	if ($free_channel == 0){
		$free_channel = $lastnum;
	}

    S_w2log(4,"free channel for DVM2TRC is $free_channel\n");

	if ($errorcount > 0){
        S_set_error( "found too many errors, exiting TSG4_SetTRCscanner" , 109);
		return 0;
	}

	# store free channel for DVM rerouting
    $dvmSettings->{'CH'} = $free_channel;


# WL +  PAs handling is checked 

# try to configure TRC channels (struct) with CREIS


    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }

#    return 1 if $main::opt_offline;


	if (scalar (@dvmUsed) > 0){
		my $hi = $dvmSettings->{'HI'};
		my $lo = $dvmSettings->{'LO'};

		my ($trcNumber, $trcChannel) = TSG4_TRC_map( $dvmSettings->{'CH'} );
		my $trclabel = $dvmSettings->{'NAME'};

		if($Scan_use{'D1'} ne '0'){
	        S_set_error( "DVM scanner 1 already in use by $Scan_use{'D1'}" , 20);
	        return 0;
		}
		if($Scan_use{'T'.$trcNumber} ne '0'){
	        S_set_error( "TRC scanner $trcNumber already in use by $Scan_use{'T'.$trcNumber}" , 20);
	        return 0;
		}

		unless($main::opt_offline){
			# skip this block in offline mode since it will access real hardware
			$status = trc_connect_DVM($trcNumber, $trcChannel);
	    	Check_status($status);
			$status = dvm_connect_hi(1,$hi);
	    	Check_status($status);
			$status = dvm_connect_lo(1,$lo);
	    	Check_status($status);
		}
		$Scan_use{'T'.$dvmSettings->{'CH'}} = 'TRC:'.$trclabel;
		$Scan_use{'D1'} = 'TRC:'.$trclabel;

		$trc_config->{'CHANNELS'}{'CHANNEL'.$dvmSettings->{'CH'}}{'ChannelName'}=$trclabel;
		foreach my $key (keys %$chConf_href){
			$trc_config->{'CHANNELS'}{'CHANNEL'.$dvmSettings->{'CH'}}{$key}=$$chConf_href{$key}
		}
		if (defined $trgConfig_href){
			foreach my $key (keys %$trgConfig_href){
				$trc_config->{'CHANNELS'}{'CHANNEL'.$dvmSettings->{'CH'}}{'TRIGGER'}{$key}=$$trgConfig_href{$key}
			}
		}


	}



	foreach my $trcscanner (sort {$a <=> $b} keys %$trc_settings){

			my $muxChannel = $trc_settings->{$trcscanner}{'MUX'};
			my $trclabel = $trc_settings->{$trcscanner}{'NAME'};

			if($Scan_use{'T'.$trcscanner} ne '0'){
		        S_set_error( "TRC scanner $trcscanner already in use by $Scan_use{'T'.$trcscanner}" , 20);
		        return 0;
			}
			my ($trcNumber, $trcChannel) = TSG4_TRC_map($trcscanner);

			unless($main::opt_offline){
				# skip this block in offline mode since it will access real hardware
				$status = trc_connect($trcNumber, $trcChannel, $muxChannel);
				Check_status($status);
			}
			$Scan_use{'T'.$trcscanner} = 'TRC:'.$trclabel;

			my $trc_channel = $trcscanner;
			if ($trc_channel > 32){
				if( $trc_merger_used ){
				$trc_channel = $trc_channel - 32;
				}
				else{
					S_set_error("channel $trc_channel is out of range (>32), please use TRC merger", 109);
				}
			}

			$trc_config->{'CHANNELS'}{'CHANNEL'.$trc_channel}{'ChannelName'}=$trclabel;
			foreach my $key (keys %$chConf_href){
				$trc_config->{'CHANNELS'}{'CHANNEL'.$trc_channel}{$key}=$$chConf_href{$key}
			}
			if (defined $trgConfig_href){
				foreach my $key (keys %$trgConfig_href){
					$trc_config->{'CHANNELS'}{'CHANNEL'.$trc_channel}{'TRIGGER'}{$key}=$$trgConfig_href{$key}
				}
			}

	}
    return 1;
}


=head2 TSG4_event_trigger_LTT_CREIS

    TSG4_event_trigger_LTT_CREIS();

invert quate trigger signal via trigger card for LTT digital input

 LTT 'TRANSI' settings
 'TriggerDelay'  =>  0 
 'SlopeType'     => 'positive'

Quate trigger out configured to 'NEG_SLOPE'

use digital trigger connector for LTT

connect LTT trigger-in to Trigger-Out 2 in scanner rack

B<check if TRG card jumper is set to 5 V otherwise LTT may be damaged>


Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

	trigger card settings:
	set trigger scanner to EVTR
	couple output 2 with input 2
	gain 1, hi limit 2.5, lo limit -10
	output 2 on, negative slope, no hold, AND coupling with inputs

=cut

sub TSG4_event_trigger_LTT_CREIS{

	#check if trigger card and trigger scanner available
	unless (exists $detectedDevices->{'TRG'}{1}){
		S_set_error( "TSG4 setup error, TRG card missing or communication problem" , 120);
		return 0;
	}
	unless (exists $detectedDevices->{'TRC'}{32}){
		S_set_error( "TSG4 setup error, trigger scanner card missing or communication problem" , 120);
		return 0;
	}

    return 1 if $main::opt_offline;

	#set trigger scanner to EVTR
	$status = trc_connect(32,2,3);
	Check_status($status);
	#couple output 2 with input 2
	$status = trg_set_coupling(1,2,[2]);
	Check_status($status);

	#gain 1
	$status = trg_set_amp(1,2,1);
	Check_status($status);

	# hi limit 2.5
	$status = trg_set_DAC(1,2,'H',2.5);
	Check_status($status);
	# lo limit -10
	$status = trg_set_DAC(1,2,'L',-10);
	Check_status($status);

	# output 2 on, negative slope, no hold, AND coupling with inputs
	$status = trg_set_trigger(1,2,1,0,0,0);
	Check_status($status);

	return 1;
}


=head2 TSG4_ResetInertSquibMode

    TSG4_ResetInertSquibMode( $label_aref);

will connect device automatically

you may also use 'ALL' to reset all squibs in ProjectConst.

only applicable for Squibs !

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_ResetInertSquibMode( ['AB1FD','BT1FP'] );
    TSG4_ResetInertSquibMode( ['ALL']);		      # reset all squibs ( AB1FD BT1FP AB1FP )

=cut

sub TSG4_ResetInertSquibMode{

    my $label_aref = shift;
    my $value;
    my $label_text = "[ ";

    my @labels=@$label_aref;


    #Check for required number of Parameters
    unless (defined( $label_aref )) {
        S_set_error( "! too less parameters ! TSG4_ResetInertSquibMode( \$label_aref )", 110 );
        return 0;
    }

    if ( scalar(@labels) == 1 and $labels[0] eq 'ALL' ){
    	@labels = TSG4_get_names( 'SQUIBS' );
    	$label_text .= "'ALL' = ". join(', ',@labels);
    }
	else{
		foreach my $label (@$label_aref){
			$label_text .= "$label ";
		}
	}
  	$label_text .= "]";

    S_w2log(1,"TSG4_ResetInertSquibMode( $label_text ) \n");

    #check for initilaized TSG4
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized", 120);
        return 0;
    }

    return 1 if $main::opt_offline;

	foreach my $label (@labels){
	    #Get Type of device for $label
	    my $type = $TSG4_labels->{$label}{"section"};
	    my $number = $TSG4_labels->{$label}{"number"};

	    unless ( defined $type ) {
	        S_set_error( "TSG4_ResetInertSquibMode '$label' unknown (please check TSG4 mapping in Project Const)", 109);
	        return 0;
	    }

	    #call Low level function for TSG4 device
	    if($type eq 'SQUIBS'){
        	$status = sq_connect($number);
	        Check_status($status,$label);
			$status = sq_set_fault_mode($number,'time',0);
	        Check_status($status,$label);
	    }
	    else{
	        S_set_error( "TSG4_ResetInertSquibMode only implemented for 'SQUIBS'", 109);
	        return 0;
	    }
	}
    S_w2log(4,"TSG4_ResetInertSquibMode status=$status\n");
    return 1;
}

=head2 TSG4_ResetTRCscanner

    TSG4_ResetTRCscanner( );

will reset corresponding scannerposition(s)

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_ResetTRCscanner();

=cut

sub TSG4_ResetTRCscanner{

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_ResetTRCscanner\n");

	# delete previous generated settings and preload TRC settings
	$trc_config={};
	$trc_config->{'General'} = $main::ProjectDefaults->{'TRANSI'}{'General'} if ( exists $main::ProjectDefaults->{'TRANSI'}{'General'});
	$trc_config->{'EXTERNAL_TRIGGER'} = $main::ProjectDefaults->{'TRANSI'}{'EXTERNAL_TRIGGER'} if ( exists $main::ProjectDefaults->{'TRANSI'}{'EXTERNAL_TRIGGER'});

    if ($main::opt_offline){
    	$Scan_use{'D1'}='0';
		foreach my $trcscanner (1..64){
			$Scan_use{'T'.$trcscanner}='0';
		}
    	return 1;
    }

	#decode and set scanner
	if ($Scan_use{'D1'} =~ /^TRC:/){

		$status = dvm_reset(1);
    	Check_status($status);
		$Scan_use{'D1'}='0';

	}
	foreach my $trcscanner (1..64){
		if ($Scan_use{'T'.$trcscanner} =~ /^TRC:/){
			my ($trcNumber, $trcChannel) = TSG4_TRC_map($trcscanner);
			$status = trc_disconnect_DVM($trcNumber);
	    	Check_status($status);
			$status = trc_disconnect($trcNumber, $trcChannel);
	    	Check_status($status);
			$Scan_use{'T'.$trcscanner}='0';
		}
	}


    # re-initialize TRC so that it is ready for a new measurement
    TRC_InitHW();

    return 1;
}



=head2 TSG4_Standby

    TSG4_Standby( [$time] );

     $time in seconds 1..9999, default is 1 sec for standby

will set TSG4 to standby mode after $time (disable internal 12V supply). should be called in ENDcampaign. 
TSG4 will be set to normal mode by TSG4_InitHW.

=cut

sub TSG4_Standby{
	my $time = shift;

	$time = 1 unless (defined $time);

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }

    S_w2log(1,"TSG4_Standby\n");

    if ($main::opt_offline){
        return 1;
    }

    $status = tsg4_set_mode('standby',$time);
    Check_status($status,'standby');
    return 1;
}

=head2 TSG4_DisconnectLine

    TSG4_DisconnectLine( $line );

disconnect line of TSG4, $line has to be a label from ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    NOTE: for power suppy lines and can lines you may give a terminal (+/-)
          for other devices terminal will be ignored

 e.g.
    TSG4_DisconnectLine( 'BT1FP' );
    TSG4_DisconnectLine( 'PPSL' );
    TSG4_DisconnectLine( 'BLRR' );
    TSG4_DisconnectLine( 'UB1' );  # disconnect + and - pin
    TSG4_DisconnectLine( 'UB1-' ); # disconnect - pin only

    TSG4_DisconnectLine( 'CANdiag' );  # connect high and low pin
    TSG4_DisconnectLine( 'CANdiag+' ); # connect high pin only

    TSG4_DisconnectLine( 'ALL_SUPPLY' );
    TSG4_DisconnectLine( 'ALL_SUPPLY+' ); # disconnect + pins only

$line = "ALL_SUPPLY" will disconnect all TSG4 power supply lines defined in ProjectConst

B<CAUTION: When disconnecting power supply lines with terminal + and - manually then always disconnect + first and then -. 
This ensures that undefined voltage states are avoided inside the ECU.>

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_DisconnectLine{
    my $label = shift;
	my $terminal;
	$terminal='';

    unless (defined( $label )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_DisconnectLine( \$line )", 110 );
        return 0;
    }

	#get terminal, if given
	if ($label =~ /[+-]$/){
		$terminal = chop($label);
	}
    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type or $label eq "ALL_SUPPLY") {
        S_set_error( "TSG4_DisconnectLine '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(4,"TSG4_DisconnectLine( $label$terminal ) \n");

    return 1 if $main::opt_offline;

    if ($label eq "ALL_SUPPLY"){
        S_w2log(4,"TSG4_DisconnectLine ALL_SUPPLY = @TSG4_PSlines \n");
        foreach my $name (@TSG4_PSlines){
            my $psNumber = $TSG4_labels->{$name}{"number"};
	        my $input = $TSG4_labels->{$name}{"default"};
	        if ($input eq 'UF' or $input eq 'Ubat'){
	        	if ($terminal){
		            $status = ubat_disconnect(1,$psNumber,$input,$terminal);
		            Check_status($status,$name) || return 0;
	        	}
	        	else{
		            $status = ubat_disconnect(1,$psNumber,$input,"+");
		            Check_status($status,$name) || return 0;
		            $status = ubat_disconnect(1,$psNumber,$input,"-"); # disconnect supply- last to avoid undefined voltage states inside the ECU
		            Check_status($status,$name) || return 0;
	        	}
	        }
	        else{
	             S_set_error( "TSG4_DisconnectLine '$label' unknown input $input (must be UF or Ubat)" , 109);
	        }
        }
    }
    elsif($type eq 'BELT_LOCKS'){
        $status = bl_disconnect($number);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_disconnect($number);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'WARNING_LAMPS'){
        my($wlCard,$wlNum) = split(/_/,$number);
		$status = wl_disconnect($wlCard,$wlNum);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_disconnect($pasBank,$pasNum);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'CAN_FR'){
       	if ($terminal){
	        my $pin;
	        if ($terminal eq '+'){
	        	$pin = 'H';
	        }
	        else{
	        	$pin = 'L';
	        }
	        $status = cf_disconnect($number,$pin);
	        Check_status($status,$label."_$pin") || return 0;
       	}
       	else{
	        $status = cf_disconnect($number,'H');
	        Check_status($status,$label) || return 0;
	        $status = cf_disconnect($number,'L');
	        Check_status($status,$label) || return 0;
	        $status = cf_disconnect($number,'G');
	        Check_status($status,$label) || return 0;
       	}
    }
    elsif($type eq 'K_LIN'){
    	my $line_type = $TSG4_labels->{$label}{"type"};
    	unless (defined $line_type){
			S_set_error( "type not defined for K_LIN $label (please check TSG4 mapping in Project Const)", 114 );
			return 0;
		}
        $status = kl_disconnect($number,$line_type);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'POWER_SUPPLY_LINES'){
        my $input = $TSG4_labels->{$label}{"default"};
        if ($input eq 'UF' or $input eq 'Ubat'){
        	if ($terminal){
	            $status = ubat_disconnect(1,$number,$input,$terminal);
	            Check_status($status,$label) || return 0;
        	}
        	else{
	            $status = ubat_disconnect(1,$number,$input,"+");
	            Check_status($status,$label) || return 0;
	            $status = ubat_disconnect(1,$number,$input,"-");
	            Check_status($status,$label) || return 0;
        	}
        }
        else{
             S_set_error( "TSG4_DisconnectLine '$label' unknown input $input (must be UF or Ubat)" , 109);
             return 0;
        }
    }
    else{
        S_set_error( "TSG4_DisconnectLine only implemented for 'WARNING_LAMPS', 'POWER_SUPPLY_LINES', 'BELT_LOCKS', 'SQUIBS', 'CAN_FR', 'K_LIN' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(5,"TSG4_DisconnectLine $label$terminal status=$status\n");
    return 1;
}


=head2 TSG4_PWM_Trace

    TSG4_PWM_Trace( $state );

trace PWM signal or WL states of TSG4 on CAN, $state may be 'on' or 'off'

trace ID = device CAN id + 5 e.g. WL_card_1 = 0x65 logging ID

currently traces only data for Wl card 1

requires at least FW_L0007

 e.g.
    TSG4_PWM_Trace( 'on' );

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_PWM_Trace{
    my $state = shift;

    unless (defined( $state )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_PWM_Trace( \$state )", 110 );
        return 0;
    }

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_PWM_Trace( $state ) \n");

    return 1 if $main::opt_offline;

	my $fw=$$detectedDevices->{WL}{1}{SW};
	$fw =~ s/FW_L//;
    if ( $fw < 7 ) {
        S_set_error( "firmware $fw too old, please update at least to FW_L0007" , 21);
        return 0;
    }

    if($state eq 'on'){
		$status = wl_PWMin_start(1);
        Check_status($status,'WL1card');
    }
    elsif($state eq 'off'){
		$status = wl_PWMin_stop(1);
        Check_status($status,'WL1card');
    }
    else{
        S_set_error( "TSG4_PWM_Trace unknown state $state (should be on or off)" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_PWM_Trace $state status=$status\n");
    return 1;
}


=head2 TSG4_PWM_Disposal

    TSG4_PWM_Disposal( $line );

send disposal PWM signal on line of TSG4, $line has to be a WARNING_LAMPS label from ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_PWM_Disposal( 'DISP' );

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_PWM_Disposal{
    my $label = shift;

    unless (defined( $label )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_PWM_Disposal( \$line )", 110 );
        return 0;
    }

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_PWM_Disposal( $label ) \n");

    return 1 if $main::opt_offline;

    if($type eq 'WARNING_LAMPS'){
        my($wlCard,$wlNum) = split(/_/,$number);
		$status = wl_PWMout_disposal($wlCard,$wlNum);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_PWM_Disposal only implemented for 'WARNING_LAMPS'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_PWM_Disposal $label status=$status\n");
    return 1;
}

=head2 TSG4_PWM_stop

    TSG4_PWM_stop( $line );

stop sending PWM signal on line of TSG4, $line has to be a WARNING_LAMPS label from ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_PWM_stop( 'DISP' );

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_PWM_stop{
    my $label = shift;

    unless (defined( $label )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_PWM_stop( \$line )", 110 );
        return 0;
    }

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_PWM_stop( $label ) \n");

    return 1 if $main::opt_offline;

    if($type eq 'WARNING_LAMPS'){
        my($wlCard,$wlNum) = split(/_/,$number);
		$status = wl_PWMout_stop($wlCard,$wlNum);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_PWM_stop only implemented for 'WARNING_LAMPS'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_PWM_stop $label status=$status\n");
    return 1;
}



=head2 TSG4_PWM_configure

    TSG4_PWM_configure( $line, $timebase_ms );

    $timebase_ms may be 0.1, 0.2, 0.5 or 1 millisec

    0.5 is a good tradeoff between busload and sample time

sets common PWM signal timebase for input and output for entire card. 
For output CAN cycletime = 8 x timebase.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_PWM_configure( 'DISP', 1 );
    # this will send a CAN message every 8 ms containign 8 samples

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_PWM_configure{
    my $label = shift;
    my $time = shift;

    unless (defined( $time )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_PWM_stop( \$line, \$timebase_ms )", 110 );
        return 0;
    }

	unless ($time == 0.1 or $time == 0.2 or $time == 0.5 or $time == 1){
        S_set_error( "! wrong parameter ! timebase_ms may be 0.1, 0.2, 0.5 or 1 millisec", 110 );
        return 0;
	}

	$time*=1000; # convert to us

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(4,"TSG4_PWM_configure( $label, $time ) \n");

    return 1 if $main::opt_offline;

    if($type eq 'WARNING_LAMPS'){
        my($wlCard,$wlNum) = split(/_/,$number);
		$status = wl_PWM_timebase($wlCard,$time);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_PWM_configure only implemented for 'WARNING_LAMPS'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_PWM_configure status=$status\n");
    return 1;
}






=head2 TSG4_InitHW

    TSG4_InitHW(); to be finalized

    no lines shall be named 'B' or 'UF' 

    if only one CAN Hardware is connected, the serial number from testbench will be overwritten

initialize TSG4 hardware, connects all lines (except Ubat 1-4), sets default values and writes labels to cards. If Toellner is given as a power input it will be connected and switched on.

does a full TSG4 reset if firmware supports it, configures event trigger to "RISING"

has to be called before any other TSG4 command, intializes TSG4 settings with values from project defaults. should be called in INITcampaign

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_InitHW{
    my ( $canChannel, $serialNo );
	my $recommend_update = 0;
 	$detectedDevices={};
 	my $errorcount = 0;

    if ( $TSG4_initialized ) {
        S_set_warning( "TSG4 already initialized");
        return 1;
    }

    S_w2log(1,"TSG4_InitHW \n");

    $status = tsg4_start( );
    Check_status($status);

    %DVM_present=%TRC_present=();

	$scan_map = {};
	use TSG4_ScannerHarness;
	$scan_map = $TSG4_ScannerHarness::scan_map;

	# use hash slices to merge harness and project mappping, project will overwrite harness value for same keys
	# see file:///C:/TurboLIFT/Perl512/html/lib/pods/perldata.html#slices or http://www.perlmonks.org/index.pl?node_id=140075
	@{$scan_map->{'DVM'}} {keys %{$main::ProjectDefaults->{'TSG4_SCANNER'}{'DVM'}} } = values %{$main::ProjectDefaults->{'TSG4_SCANNER'}{'DVM'}} if ( exists $main::ProjectDefaults->{'TSG4_SCANNER'}{'DVM'} );
	@{$scan_map->{'TRC'}} {keys %{$main::ProjectDefaults->{'TSG4_SCANNER'}{'TRC'}} } = values %{$main::ProjectDefaults->{'TSG4_SCANNER'}{'TRC'}} if ( exists $main::ProjectDefaults->{'TSG4_SCANNER'}{'TRC'} );
	# check if DVM keys are different form TRC keys
	foreach my $dvm_key( keys %{$scan_map->{'DVM'}}){
		if (exists $scan_map->{'TRC'}{$dvm_key} ){
	    	S_set_error( "ProjectDefaults->{'TSG4_SCANNER'} ambiguous key '$dvm_key' : exist for both DVM and TRC, please use unique keys only !", 20 );
			$errorcount++;
		}
	}
	return 0 if ($errorcount>0);

    # preload TRC settings
	$trc_config->{'General'} = $main::ProjectDefaults->{'TRANSI'}{'General'} if ( exists $main::ProjectDefaults->{'TRANSI'}{'General'});
	$trc_config->{'EXTERNAL_TRIGGER'} = $main::ProjectDefaults->{'TRANSI'}{'EXTERNAL_TRIGGER'} if ( exists $main::ProjectDefaults->{'TRANSI'}{'EXTERNAL_TRIGGER'});

    #get values from testbenchconfig
    $canChannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"CANchannel"} ;
    $serialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"CANHWSerialNo"} ;
    $UF_supply = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"POWER"}{'UF'} ;
    $Ubat_supply = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"POWER"}{'Ubat'} ;

    unless (defined $canChannel) {S_set_error( "CANchannel not defined in testbenchconfig TSG4" , 20);return;}
    unless (defined $serialNo) {S_set_warning( "SerialNo not defined in testbenchconfig TSG4");} # only warning
    unless (defined $Ubat_supply) {S_set_error( "POWER-Ubat not defined in testbenchconfig TSG4" , 20);return;}
    unless (defined $UF_supply) {S_set_warning( "POWER-UF not defined in testbenchconfig TSG4");} # only warning

    if ( exists $main::ProjectDefaults->{'TSG4'}{'TRC_MERGER'}{'MERGER'} ){
    	$trc_merger_used=1;
    }
    else{
    	$trc_merger_used=0;
    }

    #collect names of 'POWER_SUPPLY_LINES' into an array
    @TSG4_PSlines=();
    foreach(1..4){
        push(@TSG4_PSlines,$main::ProjectDefaults->{'TSG4'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'})
          if ( exists $main::ProjectDefaults->{'TSG4'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'}
            and $main::ProjectDefaults->{'TSG4'}{'POWER_SUPPLY_LINES'}{'PSL'.$_.'_Name'} ne '')
    }

	if (scalar(@TSG4_PSlines) < 1){
		S_set_error( " no POWER_SUPPLY_LINES in ProjectDefaults configured, at least one is required\n",20 );
		return 0;
	}
    if ($UF_supply eq 'TOE1' or $Ubat_supply eq 'TOE1'){
        my $toe1connection;

        unless( $toe1connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'TOE1'}{'connect'} ) {
            S_set_error( " found no TOE1 connection in testbenchconfig\n",20 );
            return 0;
        }

        my $ppsDeviceID=TOE1_connect($toe1connection);
        TOE1_PPSon();
        S_w2rep( "TSG4_InitHW initialized TOE1 $ppsDeviceID\n" );
    }

	TSG4_ReadLabels();

	my $outFile = $main::REPORT_PATH.'\TSG4_config.html';
    open(CFG_OUT,">$outFile") or warn("Could not open file.");
	print CFG_OUT '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">'."\n".
		'<HTML><HEAD><TITLE>'.$outFile.'</TITLE></HEAD><BODY DIR=LTR BGCOLOR="#FFFFFF">';

    print CFG_OUT "START DUMP TSG4 CONFIG<br>\n";
    $Data::Dumper::Indent = 1;
    $Data::Dumper::Sortkeys = 1;
    $Data::Dumper::Varname = "TSG4_config";
    my $dump = Dumper($TSG4_labels);
    $dump =~ s/ /\./g;
    $dump =~ s/\n/<br>/g;
    print CFG_OUT $dump;
    print CFG_OUT "END DUMP TSG4 CONFIG<br>\n";
    $Data::Dumper::Varname = "TSG4_scanner_mapping";
    $dump = Dumper($scan_map);
    $dump =~ s/ /\./g;
    $dump =~ s/\n/<br>/g;
    print CFG_OUT $dump;

    close(CFG_OUT);
    S_w2rep('<A HREF="./TSG4_config.html">TSG4 config used see TSG4_config.html</A><br>');

	if ($main::opt_offline){
        $TSG4_initialized = 1;
        $TSG4_CAN_initalized = 1;
		for(my $scan=1;$scan<64;$scan++){
			$TRC_present{$scan}=1;
		}
        return 1;
    }

	return unless ( CAN_HWcheck($canChannel, \$serialNo) );

    $status = tsg4_init( $canChannel,  $serialNo );
    Check_status($status);
    S_w2log(4,"TSG4 init ( $canChannel, $serialNo ) status=$status\n");

    $TSG4_initialized = 1;
    %Ref_use=();

    if ($status < 0){
        S_set_error( "could not initialize TSG4" , 5);
        $TSG4_initialized = 0;
		return 0;
    }

    S_w2log(4,"set TSG4 to normal mode (wakeup call)\n");
	tsg4_set_mode('normal');
	S_wait_ms(1000);

	#build $slots2scan
	my $slots2scan = Calculate_TSG4_slots();
	#detect devices
    my $mode=7;

    # scan all slots
    tsg4_detect_all_cards($slots2scan,$detectedDevices,$mode);

	foreach my $rcNum (1..7){
		tsg4_detect_RC($rcNum,$detectedDevices,$mode);
	}
    # empty error buffer of not present rack controllers
    tsg4_get_error();

	# check presence of required devices like UBAT, REF, RC1
    unless (exists $detectedDevices->{RC}{1}){
        S_set_error( "TSG4 setup error, base rack missing or communication problem" , 120);
        $TSG4_initialized = 0;
    }

    unless (exists $detectedDevices->{UBAT}{1}){
        S_set_error( "TSG4 setup error, UBAT card missing or communication problem" , 120);
        $TSG4_initialized = 0;
    }

    unless (exists $detectedDevices->{REF}{1}){
        S_set_error( "TSG4 setup error, REF card missing or communication problem" , 120);
        $TSG4_initialized = 0;
    }

	# reset TSG4 if every firmware supports this
	my $do_reset = Check_TSG4_reset_possible($detectedDevices);
	if ($do_reset){
	    S_w2log(4,"resetting TSG4 (all cards)\n");
		($status,undef) = tsg4_reset_all();
		Check_status($status,"TSG4_reset");
	}
	else{
    	S_set_warning( "TSG4 firmware too old for reset, please update cards listed above");
	}


    #general init things
    $status = ubat_UF(1,"normal"); # only for UF required
	Check_status($status,"UBAT_1");
	my ($fuses,$cFaults,$uFaults);
	($status, $fuses,$cFaults,$uFaults) = rc_get_status(1);
    if ($fuses != 0 or $cFaults != 0 or $uFaults != 0){
        S_set_error( "TSG4 internal error, please check base rack display" , 120);
        $TSG4_initialized = 0;
    }

    if ($TSG4_initialized == 0){
        S_set_error( "please solve previous listed problems and try again" , 120);
		return 0;
    }

	my @tsg4_html;
	push(@tsg4_html,'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">'."\n".
		'<HTML><HEAD><TITLE>'.$outFile.'</TITLE></HEAD><BODY DIR=LTR BGCOLOR="#FFFFFF">');

	my @harness_html = Detect_harness();
	push(@tsg4_html,@harness_html);

	# this will also initialize the devices
	my @device_html = Build_DeviceINIT_table();
	push(@tsg4_html,@device_html);

	# add LCT64 to overview
	my @lct_html = Detect_LCT();
	push(@tsg4_html,@lct_html);

	$outFile = $main::REPORT_PATH.'\TSG4_init.html';
    open(OUT,">$outFile") or warn("Could not open file.");
	print OUT join("\n",@tsg4_html);
    close(OUT);

    S_w2rep('<A HREF="./TSG4_init.html">TSG4 initialized devices see TSG4_init.html</A><br>');

    S_w2log(4,"TSG4 PM-".$tsg4::VERSION."\n");
    S_set_warning( "TSG4 firmware update available") if ($recommend_update);

    TSG4_DisconnectLine('ALL_SUPPLY'); # should not be connected by default (safe mode)
    return 1;
}




=head2 CAN_HWcheck

 $status = CAN_HWcheck($canChannel,$serialNo_ref);

if only one CAN HW is connected, $serialNo will be overwritten with connected HW (therefore call by ref).

returns false if no CAN HW is connected, given serialNo is not connected or given CAN channel out of range

=cut

sub CAN_HWcheck{
	my $canChannel = shift;
	my $serialNo_ref = shift;
	my $error_ret = 0;
	
	if( ref($serialNo_ref ) ne "SCALAR" ) {
        S_set_error( "Second parameter (\$serialNo_ref ) is not a scalar reference", 114 );
        return $error_ret;
    }
	
    #get the available (connected) CAN Hardwares
     my ($canHwIDs_aref, $channels_aref);
    ($status, $canHwIDs_aref, $channels_aref) = tsg4_get_CAN_HW_list();
    Check_status($status,'search CAN HW');

    # set SerialNo if only one HW detected
    if (scalar(@$canHwIDs_aref)==1){
        $$serialNo_ref = $$canHwIDs_aref[0];
	    S_w2log(4,"only one CAN hardware connected: new CANHWSerialNo = $$serialNo_ref\n");
    }
    elsif (scalar(@$canHwIDs_aref)==0){
        S_set_error( "! no CAN hardware detected", 120 );return $error_ret;
    }

    # set error if no entry in testbenchconfig (and more than one HW detected)
    unless (defined $$serialNo_ref) {S_set_error( "CANHWSerialNo not defined in testbenchconfig, detected HWs: @$canHwIDs_aref " , 114 );return $error_ret;}

    # check if expected HW connected and channel number in range
    my $foundSerialno = 0;
    for (my $count=0;$count<scalar(@$canHwIDs_aref);$count++){
        if ($$canHwIDs_aref[$count] == $$serialNo_ref){
            $foundSerialno = $$serialNo_ref;
            if ($canChannel > $$channels_aref[$count] ) {S_set_error( "! given channel $canChannel > $$channels_aref[$count] (= MAXchannel of HW $$serialNo_ref) )", 114 );return $error_ret;}
        }
    }

    #if the "testbenchconfig HW number" is not found, report error 
    if ($foundSerialno <= 0) {S_set_error( "! given CANHWSerialNo $$serialNo_ref not connected, detected HWs: @$canHwIDs_aref  )", 114 );return $error_ret;}
    return 1;
}



sub Build_DeviceINIT_table{
	my @device_html;
	my $recommend_update = 0;
	my $latest_firmware_href;

    ($status,$latest_firmware_href) = tsg4_latest_firmware();
    S_set_warning( "could not read latest firmware from $latest_firmware_href->{'DIR'}") if ($status < 0);

	push(@device_html,"<br><br>INITALIZED TSG4 DEVICES<br>\n");
	push(@device_html,'<TABLE BORDER CELLSPACING=1 CELLPADDING=4 ><TR><TH>device</TH><TH>label</TH>'.
		'<TH>firmware version</TH><TH>serial number</TH><TH>test date</TH><TH>calibration date</TH><TH>bootloader</TH><TH>fuse bits</TH></TR>');

	foreach my $number (sort keys %{$detectedDevices->{'RC'}}){

        my $htmltext = GetCardDataForInitTable('RC', $number, 'RackController', $latest_firmware_href, \$recommend_update);

		$status=rc_configure_event_trigger($number,'FALLING');
		Check_status($status,"configure RC$number event trigger");

        push(@device_html, $htmltext);

	}

	{ # just to have a separate namespace
        my $htmltext = GetCardDataForInitTable('REF', 1, 'ReferenceLines', $latest_firmware_href, \$recommend_update);

        push(@device_html, $htmltext);

	}

    #device specific init things
    foreach my $section (sort keys %{$main::ProjectDefaults->{'TSG4'}}){

        foreach my $key (sort keys %{$main::ProjectDefaults->{'TSG4'}->{$section}}){
            my $label = $main::ProjectDefaults->{'TSG4'}->{$section}->{$key};

            if ($key =~ /([_\d]+)_Name$/){
                my $number = $1;
                if ($section eq 'BELT_LOCKS'){
					my $text = BL_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'SQUIBS'){
					my $text = SQ_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'PAS_LINES'){
					my $text = PAS_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'POWER_SUPPLY_LINES'){
					my $text = UBAT_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'WARNING_LAMPS'){
					my $text = WL_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'CAN_FR'){
					my $text = CANFR_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'K_LIN'){
					my $text = KLIN_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'DVM_SCANNER'){
					my $text = DVM_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'TRC_SCANNER'){
					my $text = TRC_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }
                elsif ($section eq 'TRG'){
					my $text = TRG_init($number,$label,$latest_firmware_href,\$recommend_update);
					push(@device_html,$text);
                }

            }
        }
    }

	push(@device_html,"</TABLE>\n");
	push(@device_html,"END INITALIZED TSG4 DEVICES<br>\n");


	return @device_html;
}





sub BL_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('BL', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'BL'}{$number}){
		# $name length <= 8 
		$status = bl_write_name($number,$label);
		Check_status($status,$label);

		if (defined $TSG4_labels->{$label}{"default"}){
			if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
				S_w2log(5,"TSG4 device $label not connected (given default)\n");
				TSG4_DisconnectLine_NOHTML($label);
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
				TSG4_SetLogicalState_NOHTML($label,'DEFAULT');
			}
		}
		else{
			S_set_error( "no default value defined for $label" , 20);
		}
    }

	return $htmltext;
}




sub SQ_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('SQ', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'SQ'}{$number}){
		# $name length <= 8 
		$status = sq_write_name($number,$label);
		Check_status($status,$label);

		if (defined $TSG4_labels->{$label}{"default"}){
			if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
				S_w2log(5,"TSG4 device $label not connected (given default)\n");
				TSG4_DisconnectLine_NOHTML($label);
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
				TSG4_SetResistance_NOHTML($label,'DEFAULT');
			}
		}
		else{
			S_set_error( "no default value defined for $label" , 20);
		}
    }

	return $htmltext;
}



sub PAS_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    $number=~s/^_//; # cut off leading underline
    my($bank,$pasNum) = split(/_/,$number);

    my $htmltext = GetCardDataForInitTable('PAS', $number, $label, $latest_firmware_href, $recommend_update_ref, $bank);

    if (exists $detectedDevices->{'PAS'}{$bank}){
		# $name length <= 8 
		if($pasNum == 1){ # do it only once per PAS
			# $name length <= 8 
			$status = pas_write_name($bank,$label);
			Check_status($status,$label);
		}

		if (defined $TSG4_labels->{$label}{"default"}){
			if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
				S_w2log(5,"TSG4 device $label not connected (given default)\n");
				TSG4_DisconnectLine_NOHTML($label);
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
			}
		}
		else{
			TSG4_ConnectLine_NOHTML($label);
		}
    }

	return $htmltext;
}



sub UBAT_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('UBAT', $number, $label, $latest_firmware_href, $recommend_update_ref, 1);

	return $htmltext;
}




sub WL_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext;
    $number=~s/^_//; # cut off leading underline

	unless ($number=~/(\d+)_(\d+)/) {
		S_set_error( "wrong WL format '$number' for TSG4 use WL_{card}_{no}_Name e.g. WL_1_5_Name" , 20);
        $htmltext= sprintf ("<TR><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD></TR>\n",
        'WL_'.$number.'_?',$label,'error','error','error','error','error','error');
	}
	else{
	    my $card = $1;
        my $wlNum = $2;

        $htmltext = GetCardDataForInitTable('WL', $number, $label, $latest_firmware_href, $recommend_update_ref, $card);

	    if (exists $detectedDevices->{'WL'}{$card}){

			if (defined $TSG4_labels->{$label}{"default"}){
				if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
					S_w2log(5,"TSG4 device $label not connected (given default)\n");
					TSG4_DisconnectLine_NOHTML($label);
				}
				else{
					TSG4_ConnectLine_NOHTML($label);
				}
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
			}

	    }
	}

	return $htmltext;
}




sub CANFR_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('CANFR', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'CANFR'}{$number}){

		if (defined $TSG4_labels->{$label}{"default"}){
			if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
				S_w2log(5,"TSG4 device $label not connected (given default)\n");
				TSG4_DisconnectLine_NOHTML($label);
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
			}
		}
		else{
			TSG4_ConnectLine_NOHTML($label);
		}

    }

	return $htmltext;
}





sub KLIN_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;
	
    my $htmltext = GetCardDataForInitTable('KLIN', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'KLIN'}{$number}){

		if (defined $TSG4_labels->{$label}{"output"}){
			my $command = $TSG4_labels->{$label}{"output"};
			if ($command eq 'inverted'){
				S_w2log(4, "KLIN $number inverted, call kl_signal_output($number,'K', 'i'");
				kl_signal_output($number,'K','i'); 
			}
			elsif ($command eq 'normal'){
				S_w2log(4, "KLIN $number normal, call kl_signal_output($number,'K', 'n'");
				kl_signal_output($number,'K','n'); 
			}
			else{
                S_set_error( "In TSG4 mapping in section 'K_LIN' the key 'KL".$number."_output' has an invalid value '$command'. Valid values are: 'normal', 'inverted'." , 20);			    
			}
		}

		if (defined $TSG4_labels->{$label}{"default"}){
			if ($TSG4_labels->{$label}{"default"} eq 'not_connected'){
				S_w2log(5,"TSG4 device $label not connected (given default)\n");
				TSG4_DisconnectLine_NOHTML($label);
			}
			else{
				TSG4_ConnectLine_NOHTML($label);
			}
		}
		else{
			TSG4_ConnectLine_NOHTML($label);
		}

    }

	return $htmltext;
}



sub DVM_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('DVM', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'DVM'}{$number}){
        $DVM_present{$number}=1;
    }

	return $htmltext;
}



sub TRC_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

    my $htmltext = GetCardDataForInitTable('TRC', $number, $label, $latest_firmware_href, $recommend_update_ref);

    if (exists $detectedDevices->{'TRC'}{$number}){
        for(my $scan=$number*8;$scan>($number*8)-8;$scan--){
	       $TRC_present{$scan}=1;
		}
    }

	return $htmltext;
}


sub TRG_init{

	my $number = shift;
	my $label = shift;
	my $latest_firmware_href = shift;
	my $recommend_update_ref = shift;

	my ($firmware,$hwID,$testDate,$bsb,$flb,$cal);
    my $sytle_FW='';
    if (exists $detectedDevices->{'TRG'}{$number}){
		$firmware = $detectedDevices->{'TRG'}{$number}{SW};
		$hwID = $detectedDevices->{'TRG'}{$number}{HW};
		$testDate = $detectedDevices->{'TRG'}{$number}{TST};
		$bsb = $detectedDevices->{'TRG'}{$number}{BSB};
		$flb = $detectedDevices->{'TRG'}{$number}{FLB};
		$cal = $detectedDevices->{'TRG'}{$number}{CAL};

		my $trg_type;

	    if ($hwID =~ /^(\d{3})\w\d{4}$/){
	    	my $lot = $1;
			$trg_type = 'TRG_A' if ($lot < 3); #e.g. FW_Y0003 ATMEL
			$trg_type = 'TRG_F' if ($lot > 2); #e.g. FW_Y0021 FPGA

	        if ( Check_firmware($firmware,$latest_firmware_href->{$trg_type}) ){
	        	$sytle_FW= ' style="font-weight:bold;background-color:yellow" ';
	            S_w2log(5,"new firmware available for TRG_$number\n");
	            $$recommend_update_ref = 1;
	        }
	    }

    }
	$firmware='error' unless (defined $firmware);
	$hwID='error' unless (defined $hwID);
	$testDate='error' unless (defined $testDate);
	$cal='error' unless (defined $cal);
	$flb='error' unless (defined $flb);
	$bsb='error' unless (defined $bsb);

	my $htmltext= sprintf ("<TR><TD>%s_%02d</TD><TD>%s</TD><TD$sytle_FW>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD></TR>\n",
	'TRG',$number,$label,$firmware,$hwID,$testDate,$cal,$bsb,$flb);

	return $htmltext;
}


sub GetCardDataForInitTable{
    my $cardType = shift;
    my $number = shift;
    my $label = shift;
    my $latest_firmware_href = shift;
    my $recommend_update_ref = shift;
    my $detectedDevicesNumber = shift // $number;
    
    S_w2log(5, "Init of '$cardType' started for number '$number', label '$label' ...\n");

    # format integer numbers nicely 
    if( $number =~ /^\d+$/ ) {
        $number = sprintf("%02d", $number);
    }

    # define data items that shall be retrieved from $detectedDevices
    my @dataItems = qw(SW HW TST CAL BSB FLB);

    my $storedData_href = {};
    my $sytle_FW = '';
    
    # get data if card was detected
    if (exists $detectedDevices->{$cardType}{$detectedDevicesNumber}){
        S_w2log(5, "$cardType '$detectedDevicesNumber', label '$label' found in detected devices\n");
        # get all data items and store them in $storedData_href
        foreach my $dataItem ( @dataItems ) {
            $storedData_href->{$dataItem} = $detectedDevices->{$cardType}{$detectedDevicesNumber}{$dataItem};
        }

        # check if firmware updat flag should be set
        if ( Check_firmware($storedData_href->{'SW'},$latest_firmware_href->{$cardType}) ){
            $sytle_FW= ' style="font-weight:bold;background-color:yellow" ';
            S_w2log(5,"new firmware available for ".$cardType."_$number\n");
            $$recommend_update_ref = 1;
        }
    }

    # set data values to 'error if they are not defined
    foreach my $dataItem ( @dataItems ) {
        $storedData_href->{$dataItem} = 'error' unless (defined $storedData_href->{$dataItem});
    }

    # if calibration date is 8x'FF' then the card is not calibrated
    $storedData_href->{'CAL'} = 'not calibrated' if $storedData_href->{'CAL'} eq chr(255)x8;

    # create one line for the init table
    my $htmltext= sprintf ("<TR><TD>%s_%s</TD><TD>%s</TD><TD$sytle_FW>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD></TR>\n",
    $cardType,$number,$label,$storedData_href->{'SW'},$storedData_href->{'HW'},$storedData_href->{'TST'},$storedData_href->{'CAL'},$storedData_href->{'BSB'},$storedData_href->{'FLB'});
    
    return $htmltext;
}

sub Detect_harness{
	my @harness_html;

	#communicate with RC1 and get harness information
	my ($text,$cust,$gen,$class,$sn,$ver,$sample,$man,$uid,$text1,$text2,$conn, $sw, $type);
	my $device_connected;

	($status, $uid, $sn, $sw, $type) = rc_read_RFID_info(1);
    push (@harness_html,"<br>RFID reader: UID $uid, SN $sn, SW $sw, type $type<br>\n");
	S_w2log(4,"RFID reader: UID $uid, SN $sn, SW $sw, type $type\n");
	# check reader is ok
	if ( $type =~ /Error/){
	    S_w2rep("RFID reader error '$type', trying to configure reader...");
	    S_wait_ms(500);
		($status,$text) = rc_write_RFID_transponder_type(1);
		S_w2log(4,"configuration result: $text\n");
	    S_wait_ms(500);
		($status, $uid, $sn, $sw, $type) = rc_read_RFID_info(1);
		if ( $type =~ /Error/){
	        S_set_warning( "RFID reader problem '$type' detected inside TSG4");
	        push (@harness_html,"<p><b>RFID reader problem '$type' detected inside TSG4</b></p>");
			return @harness_html;
		}
	}
	#check tag detected (harness connected)
	if($uid =~ /Error/){
        S_set_warning( "NO TSG4 harness detected");
        push (@harness_html,"<p><b>NO TSG4 harness detected</b></p>");
	}
	else{

		($status,$text,$cust,$gen,$class,$sn,$ver,$sample,$man,$uid) = rc_read_RFID_text(1);
		Check_status($status,'Harness text'); # this will set INCONC if no harness connected

		my $htmlText="<TABLE BORDER CELLSPACING=1 CELLPADDING=4 >";
		$htmlText.="<TR><TD>display text</TD><TD>$text</TD></TR>";
		$htmlText.="<TR><TD>customer group</TD><TD>$cust</TD></TR>";
		$htmlText.="<TR><TD>AB generation</TD><TD>$gen</TD></TR>";
		$htmlText.="<TR><TD>vehicle class</TD><TD>$class</TD></TR>";
		$htmlText.="<TR><TD>serial number</TD><TD>$sn</TD></TR>";
		$htmlText.="<TR><TD>HW version</TD><TD>$ver</TD></TR>";
		$htmlText.="<TR><TD>sample phase</TD><TD>$sample</TD></TR>";
		$htmlText.="<TR><TD>manufactured</TD><TD>$man</TD></TR>";
		$htmlText.="</TABLE>";

		if ($text eq ''){
	        S_set_warning( "RFID tag not programmed");
	        push (@harness_html,"<p><b>RFID tag not programmed</b></p>");

		}
		else{
		    S_w2rep("Harness is $text");

		    push (@harness_html,"<br><br>WIRING HARNESS<br>\n");
			push (@harness_html,"$htmlText\n");

			if ( $text eq 'X1X2-CON'){
				S_w2rep('ATTENTION: generic harness detected, pins may not be connected to ECU because additional project specific harness is used','red');
			}

			($status, $device_connected) = rc_read_RFID_pinout(1);
			Check_status($status,'Harness pinout'); # this will set INCONC if no harness connected

			push (@harness_html,"<br><br>CONNECTED TSG4 DEVICES<br>\n");
			foreach my $device (sort keys %$device_connected){
				push (@harness_html," $device = [".join('',@{$device_connected->{$device}})."]<br>\n");
			}
			push (@harness_html,"END CONNECTED TSG4 DEVICES<br>\n");
		}
	}

	return @harness_html;
}

sub Detect_LCT{
	my @lct_html;

	my ($deviceID,$swVersion,$fpgaVersion,$tst,$cal);
	$status = lct_reset_FPGAandFIFO(1);

    ($status, $deviceID) = lct_get_HW_id(1);
    if($status != 0){
        S_set_warning( "NO LCT64 detected");
        push (@lct_html,"<p><b>NO LCT64 detected</b></p>");
	}
	else{
	    Check_status($status);
	    ($status, $swVersion) = lct_get_firmware(1);
	    Check_status($status);
	    ($status, $fpgaVersion) = lct_get_FPGA_firmware(1);
	    Check_status($status);

	    ($status, $tst) =lct_get_INFO(1,'TST');
	    Check_status($status);
	    ($status, $cal) =lct_get_INFO(1,'CAL');
	    Check_status($status);

		my $htmlText="<TABLE BORDER CELLSPACING=1 CELLPADDING=4 >";
		$htmlText.="<TR><TD>LCT DeviceId</TD><TD>$deviceID</TD></TR>";
		$htmlText.="<TR><TD>Software Version</TD><TD>$swVersion</TD></TR>";
		$htmlText.="<TR><TD>FPGA firmware</TD><TD>$fpgaVersion</TD></TR>";
		$htmlText.="<TR><TD>test date</TD><TD>$tst</TD></TR>";
		$htmlText.="<TR><TD>calibration date</TD><TD>$cal</TD></TR>";
		$htmlText.="</TABLE>";

	    push (@lct_html,"<br><br>LCT 64<br>\n");
		push (@lct_html,"$htmlText\n");

		push (@lct_html,"END LCT 64<br>\n");
	}

	return @lct_html;
}

sub Calculate_TSG4_slots{
	my $detected = shift;
	my $scan;

	my $scan_multi;

	# always scan for UBAT and REF card
    my $card=1;
    $scan_multi->{scanUBAT}{$card}=1;
    $scan_multi->{scanREF}{$card}=1;


    foreach my $section (sort keys %{$main::ProjectDefaults->{'TSG4'}}){

        foreach my $key (sort keys %{$main::ProjectDefaults->{'TSG4'}->{$section}}){
            my $label = $main::ProjectDefaults->{'TSG4'}->{$section}->{$key};

            if ($key =~ /([_\d]+)_Name$/){
                my $number = $1;

                if ($section eq 'BELT_LOCKS'){
				        $scan_multi->{scanBL}{$number}=1;
                }
                elsif ($section eq 'SQUIBS'){
				        $scan_multi->{scanSQ}{$number}=1;
                }
                elsif ($section eq 'PAS_LINES'){
                        $number=~s/^_//; # cut off leading underline
                        my($bank,$pasNum) = split(/_/,$number);
				        $scan_multi->{scanPAS}{$bank}=1;
				}
                elsif ($section eq 'WARNING_LAMPS'){
						unless ($number=~/(\d+)_(\d+)/) {
							S_set_error( "wrong WL format '$key' for TSG4 use WL_{card}_{no}_Name e.g. WL_1_5_Name" , 20);
						}
						else{
                            my $wl_card = $1;
					        $scan_multi->{scanWL}{$wl_card}=1;
						}
                }
                elsif ($section eq 'CAN_FR'){
				        $scan_multi->{scanCANFR}{$number}=1;
                }
                elsif ($section eq 'K_LIN'){
				        $scan_multi->{scanKLIN}{$number}=1;
                }
                elsif ($section eq 'DVM_SCANNER'){
				        $scan_multi->{scanDVM}{$number}=1;
                }
                elsif ($section eq 'TRC_SCANNER'){
				        $scan_multi->{scanTRC}{$number}=1;
                }
                elsif ($section eq 'TRG'){
				        $scan_multi->{scanTRG}{$number}=1;
                }
            }
        }
    }


	# reduce multiple occurences of slot to single occurence fro scanning
	foreach my $key qw( scanSQ scanBL scanPAS scanWL scanUBAT scanREF scanCANFR scanKLIN scanSPDT scanRDEC scanTRG scanDVM scanTRC){
		push(@{$scan->{$key}}, sort keys %{$scan_multi->{$key}});
	}


	return $scan;
}





=head2 TSG4_LogAllDevices

    TSG4_LogAllDevices( );

autodetect all present devices in TSG4 and log to extra html file. will put link to html in report.

... this will take a while ...

=cut

sub TSG4_LogAllDevices{

    my $device_connected;

	my $outFile = $main::REPORT_PATH.'\TSG4_info.html';
	my @htmlout=();

	if ($main::opt_offline){
    	#create dummy file and return
      	S_create_dummy_file($outFile);
        return 1;
    }

	push(@htmlout, '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">'."\n".
		'<HTML><HEAD><TITLE>'.$outFile.'</TITLE></HEAD><BODY DIR=LTR BGCOLOR="#FFFFFF">');

	#communicate with RC1 and get harness information
	my ($text,$cust,$gen,$class,$sn,$ver,$sample,$man,$uid,$text1,$text2,$conn);
	($status,$text,$cust,$gen,$class,$sn,$ver,$sample,$man,$uid) = rc_read_RFID_text(1);
	my $htmlText="<TABLE BORDER CELLSPACING=1 CELLPADDING=4 >";
	$htmlText.="<TR><TD>display text</TD><TD>$text</TD></TR>";
	$htmlText.="<TR><TD>customer group</TD><TD>$cust</TD></TR>";
	$htmlText.="<TR><TD>AB generation</TD><TD>$gen</TD></TR>";
	$htmlText.="<TR><TD>vehicle class</TD><TD>$class</TD></TR>";
	$htmlText.="<TR><TD>serial number</TD><TD>$sn</TD></TR>";
	$htmlText.="<TR><TD>HW version</TD><TD>$ver</TD></TR>";
	$htmlText.="<TR><TD>sample phase</TD><TD>$sample</TD></TR>";
	$htmlText.="<TR><TD>manufactured</TD><TD>$man</TD></TR>";
	$htmlText.="</TABLE>";

	push(@htmlout, "<br><br>WIRING HARNESS<br>\n");
	push(@htmlout, "$htmlText\n");
#    S_w2log(1,"WIRING HARNESS");
#    S_w2log(1,"$htmlText");

	if ( $text eq 'X1X2-CON'){
		S_w2rep('ATTENTION: generic harness detected, pins may not be connected to ECU because additional project specific harness is used','red');
	}

	($status, $device_connected) = rc_read_RFID_pinout(1);

	push(@htmlout, "<br><br>CONNECTED TSG4 DEVICES<br>\n");
	foreach my $device (sort keys %$device_connected){
		push(@htmlout, " $device = [".join('',@{$device_connected->{$device}})."]<br>\n");
	}
	push(@htmlout, "END CONNECTED TSG4 DEVICES<br>\n");


	# additional info to be collected and checked:
	# calibration date/state, fusebits/bodlevel, bootloader/BSB,  
	my ($card_href);
	($status, $card_href) = TSG4_lowlevel_command_NOHTML('tsg4_autodetect_cards(6)');

	push(@htmlout, "<br><br>DETECTED TSG4 DEVICES<br>\n");
	push(@htmlout, '<TABLE BORDER CELLSPACING=1 CELLPADDING=4 ><TR><TH>device</TH><TH>firmware version</TH><TH>serial number</TH>'.
			'<TH>test date</TH><TH>bootloader</TH><TH>fuse bits</TH></TR>');

	foreach my $device (sort keys %$card_href){
		foreach my $number (sort keys %{$card_href->{$device}}){
			push(@htmlout, sprintf("<TR><TD>%s_%02d</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD></TR>\n",$device,$number,
			$card_href->{$device}{$number}{SW},$card_href->{$device}{$number}{HW},$card_href->{$device}{$number}{TST},$card_href->{$device}{$number}{BSB},$card_href->{$device}{$number}{FLB}));
		}
	}

	push(@htmlout, "</TABLE>\n");
	push(@htmlout, "END DETECTED TSG4 DEVICES<br>\n");

	foreach my $wl ( keys %{$card_href->{WL}} ){

		($status,$sn)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,83)");
		($status,$cust)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,80)");
		($status,$gen)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,81)");
		($status,$class)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,82)");
		($status,$ver)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,84)");
		($status,$sample)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,85)");
		($status,$man)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,86)");
		($status,$conn)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,87)");
		($status,$text1)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,88)");
		($status,$text2)=TSG4_lowlevel_command_NOHTML("wl_get_INFO($wl,89)");

		$htmlText="<TABLE BORDER CELLSPACING=1 CELLPADDING=4 >";
		$htmlText.="<TR><TD>customer group</TD><TD>$cust</TD></TR>";
		$htmlText.="<TR><TD>AB generation</TD><TD>$gen</TD></TR>";
		$htmlText.="<TR><TD>vehicle class</TD><TD>$class</TD></TR>";
		$htmlText.="<TR><TD>serial number</TD><TD>$sn</TD></TR>";
		$htmlText.="<TR><TD>HW version</TD><TD>$ver</TD></TR>";
		$htmlText.="<TR><TD>sample phase</TD><TD>$sample</TD></TR>";
		$htmlText.="<TR><TD>manufactured</TD><TD>$man</TD></TR>";
		$htmlText.="<TR><TD>connected</TD><TD>$conn</TD></TR>";
		$htmlText.="<TR><TD>text1</TD><TD>$text1</TD></TR>";
		$htmlText.="<TR><TD>text2</TD><TD>$text2</TD></TR>";
		$htmlText.="</TABLE>";

		push(@htmlout, "<br>WL $wl project specific PCB<br>\n");
		push(@htmlout, "$htmlText\n");
#	    S_w2log(1,"WIRING HARNESS");
#	    S_w2log(1,"$htmlText");

	}

    open(my $out,">","$outFile") or warn("Could not open file.");
    print $out join("",@htmlout);
    close($out);
    S_w2rep('<A HREF="./TSG4_info.html">TSG4 details see TSG4_info.html</A><br>');

    # empty error buffer of not present devices
    tsg4_get_error();

	return 1;
}





=head2 TSG4_ConnectLine

    TSG4_ConnectLine( $line );

(re-)connect line of TSG4, $line has to be a label from ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    NOTE: for power suppy lines and can lines you may give a terminal (+/-)
          for other devices terminal will be ignored

 e.g.
    TSG4_ConnectLine( 'BT1FP' );
    TSG4_ConnectLine( 'PPSL' );
    TSG4_ConnectLine( 'BLRR' );
    TSG4_ConnectLine( 'UB1' );  # connect + and - pin
    TSG4_ConnectLine( 'UB1-' ); # connect - pin only

    TSG4_ConnectLine( 'CANdiag' );  # connect high and low pin
    TSG4_ConnectLine( 'CANdiag+' ); # connect high pin only

    TSG4_ConnectLine( 'ALL_SUPPLY' );
    TSG4_ConnectLine( 'ALL_SUPPLY+' ); # connect + pins only

$line = "ALL_SUPPLY" will connect all TSG4 power supply lines defined in ProjectConst

B<CAUTION: When connecting power supply lines with terminal + and - manually then always connect - first and then +. 
This ensures that undefined voltage states are avoided inside the ECU.> 

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

=cut

sub TSG4_ConnectLine{
    my $label = shift;
	my $terminal;
	$terminal='';

    unless (defined( $label )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_ConnectLine( \$line )", 110 );
        return 0;
    }

	#get terminal, if given
	if ($label =~ /[+-]$/){
		$terminal = chop($label);
	}
    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type or $label eq "ALL_SUPPLY") {
        S_set_error( "TSG4_ConnectLine '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(4,"TSG4_ConnectLine( $label$terminal ) \n");

    return 1 if $main::opt_offline;

    if ($label eq "ALL_SUPPLY"){
        S_w2log(4,"TSG4_ConnectLine ALL_SUPPLY = @TSG4_PSlines \n");
        foreach my $name (@TSG4_PSlines){
            my $psl_number = $TSG4_labels->{$name}{"number"};
            my $input = $TSG4_labels->{$name}{"default"};
            if ($input eq 'UF' or $input eq 'Ubat'){
	        	if ($terminal){
		            $status = ubat_connect(1,$psl_number,$input,$terminal);
		            Check_status($status,$name) || return 0;
	        	}
	        	else{
		            $status = ubat_connect(1,$psl_number,$input,"-"); # connect supply- first to avoid undefined voltage states inside the ECU
		            Check_status($status,$name) || return 0;
                    $status = ubat_connect(1,$psl_number,$input,"+");
                    Check_status($status,$name) || return 0;
	        	}
            }
            else{
                 S_set_error( "TSG4_ConnectLine '$label' unknown input $input (must be UF or Ubat)" , 109);
            }
        }
    }
    elsif($type eq 'BELT_LOCKS'){
        $status = bl_connect($number);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_connect($number);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_connect($wlCard,$wlNum);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_connect($pasBank,$pasNum);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'CAN_FR'){
       	if ($terminal){
	        my $pin;
	        if ($terminal eq '+'){
	        	$pin = 'H';
	        }
	        else{
	        	$pin = 'L';
	        }
	        $status = cf_connect($number,$pin);
	        Check_status($status,$label."_$pin") || return 0;
       	}
       	else{
	        $status = cf_connect($number,'H');
	        Check_status($status,$label.'_H') || return 0;
	        $status = cf_connect($number,'L');
	        Check_status($status,$label.'_L') || return 0;
	        $status = cf_connect($number,'G');
	        Check_status($status,$label.'_G') || return 0;
       	}
    }
    elsif($type eq 'K_LIN'){
    	my $line_type = $TSG4_labels->{$label}{"type"};
    	unless (defined $line_type){
			S_set_error( "type not defined for K_LIN $label (please check TSG4 mapping in Project Const)", 114 );
			return 0;
		}
        $status = kl_connect($number,$line_type);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'POWER_SUPPLY_LINES'){
        my $input = $TSG4_labels->{$label}{"default"};
        if ($input eq 'UF' or $input eq 'Ubat'){
        	if ($terminal){
	            $status = ubat_connect(1,$number,$input,$terminal);
	            Check_status($status,$label) || return 0;
        	}
        	else{
	            $status = ubat_connect(1,$number,$input,"+");
	            Check_status($status,$label) || return 0;
	            $status = ubat_connect(1,$number,$input,"-");
	            Check_status($status,$label) || return 0;
        	}
        }
        else{
             S_set_error( "TSG4_ConnectLine '$label' unknown input $input (must be UF or Ubat)" , 109);
             return 0;
        }
    }
    else{
        S_set_error( "TSG4_ConnectLine only implemented for 'WARNING_LAMPS', 'POWER_SUPPLY_LINES', BELT_LOCKS', 'SQUIBS', 'CAN_FR', 'K_LIN' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(5,"TSG4_ConnectLine $label$terminal status=$status\n");
    return 1;
}


=head2 TSG4_LV124_E13

    $success = TSG4_LV124_E13( $line, $sequence );

perform LV124 E-13 sequence on line, refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

B<Arguments:>

=over

=item $line 

line where the manipulation shall happen, has to be a label from ProjectConst

=item $sequence 

stimulation sequence (cycle timing see notes), valid vaules are:

'10s_single'

'1ms_single'

'100us_single'

'1us_cycle_4s', t=1us, t1=1ms, t2=4s

'100us_cycle_4s', t=0.1ms, t1=1ms, t2=4s

=back

B<Return Value:>

=over

=item $success 

Success flag: =1 on success or in offline mode, 0 on error.

=back

B<Examples:>

    TSG4_LV124_E13( 'BT1FP', '1ms_single' );
    TSG4_LV124_E13( 'PPSL', '1ms_single' );
    TSG4_LV124_E13( 'BLRR', '1ms_single' );
    TSG4_LV124_E13( 'PADL', '1ms_single' );
    TSG4_LV124_E13( 'Lin1', '1ms_single' );
    TSG4_LV124_E13( 'CANdiag::L', '1ms_single' ); # H L G - high low ground

B<Notes>:

=for html
<IMG SRC='..\..\pics\LV124_E13.png'  alt="LV124_E13 pin switching" border="0">
<br><br>
Oscilloscope screenshots of Squib E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_SQ.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_SQ_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_SQ_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_SQ_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_SQ_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_SQ_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_SQ_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_SQ_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_SQ_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_SQ_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_SQ_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_SQ_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_SQ_can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of PAS E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_PAS.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_PAS_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_PAS_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_PAS_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_PAS_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_PAS_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_PAS_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_PAS_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_PAS_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_PAS_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_PAS_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_PAS_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_PAS_can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of Warning Lamp 4 E13 sequences (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_WL.png' target="blank">measurement circuit</a><br>
single <a href='..\..\pics\TSG4\E13_1_WL_t.png' target="blank">10s_single</a>
<a href='..\..\pics\TSG4\E13_2_WL_t.png' target="blank">1ms_single</a>
<a href='..\..\pics\TSG4\E13_3_WL_t.png' target="blank">100us_single</a>
<a href='..\..\pics\TSG4\E13_3_WL_can.png' target="blank">100us_single message to interruption</a>
<br>
1us_cycle_4s 
<a href='..\..\pics\TSG4\E13_4_WL_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_4_WL_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_4_WL_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_4_WL_can.png' target="blank">message to interruption</a>
<br>
100us_cycle_4s 
<a href='..\..\pics\TSG4\E13_5_WL_t.png' target="blank">time_t</a>
<a href='..\..\pics\TSG4\E13_5_WL_t1.png' target="blank">time_t1</a>
<a href='..\..\pics\TSG4\E13_5_WL_t2.png' target="blank">time_t2</a>
<a href='..\..\pics\TSG4\E13_5_WL_can.png' target="blank">message to interruption</a>


=cut

sub TSG4_LV124_E13{
    my $label = shift;
    my $sequence = shift;

    my @labels = split(/::/,$label);;
    $label = $labels[0];
    my $canLine = $labels[1];

    my %sequence_table =(
        '10s_single' => 1,
        '1ms_single' => 2,
        '100us_single' => 3,
        '1us_cycle_4s' => 4,
        '100us_cycle_4s' => 5,
    );
    unless (defined( $sequence )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_LV124_E13( \$line, \$sequence )", 110 );
        return 0;
    }
    unless (exists $sequence_table{$sequence}){
        S_set_error( "! $sequence is not a valid sequence !", 114 );
        return 0;
    }

    my $seq_nr=$sequence_table{$sequence};
    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    unless ( defined $type ) {
        S_set_error( "TSG4_LV124_E13 '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    S_w2log(1,"TSG4_LV124_E13( $label, $sequence ) \n");

    return 1 if $main::opt_offline;

    if($type eq 'BELT_LOCKS'){
        $status = bl_LV124($number,$seq_nr);
        Check_status($status,$label);
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_LV124($number,$seq_nr);
        Check_status($status,$label);
    }
    elsif($type eq 'CAN_FR'){
	    unless (defined $canLine or $canLine eq 'H' or $canLine eq 'L' or $canLine eq 'G'){
	        S_set_error( "! no pin defined or invalid for $label (e.g. CANdiag::L)!", 114 );
	        return 0;
	    }
        $status = cf_LV124($number,$canLine,$seq_nr);
        Check_status($status,$label);
    }
    elsif($type eq 'K_LIN'){
    	my $linetype = $TSG4_labels->{$label}{"type"};
	    unless (defined $linetype){
	        S_set_error( "! type not defined or invalid for $label!", 114 );
	        return 0;
	    }
        $status = kl_LV124($number,$linetype,$seq_nr);
        Check_status($status,$label);
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_LV124($wlCard,$wlNum,$seq_nr);
        Check_status($status,$label);
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        if($pasNum eq '1'){
            $status = pas_LV124($pasBank,$pasNum,$seq_nr);
            Check_status($status,$label);
        }
        else{
            S_set_error( "! LV124 E-13 functionality only possible on first PAS of each bank !", 114 );
            return 0;
        }
    }
    else{
        S_set_error( "TSG4_LV124_E13 only implemented for 'WARNING_LAMPS', 'CAN_FR', 'K_LIN', 'BELT_LOCKS', 'SQUIBS' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_LV124_E13 $label, $sequence  status=$status\n");
    return 1;
}

=head2 TSG4_LV124_E10

    $success = TSG4_LV124_E10( $mode, $time_us );

Perform LV124 E10 interruption on UF input, Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings.

UF has to be B<configured> and B<connected> to the Power line you want to test.

If no power line is configured to UF there will an error.

B<Arguments:>

=over

=item $mode 

stimulation mode, valid vaules are '100K', '10K' or '0.1R'.

'100K': S1 closed, S2 open,  R=100K

'10K' : S1 closed, S2 inverted to S1, R=10K

'0.1R': S1 closed, S2 open,  R=0.1R

=item $time_us 

Time in microseconds how long the stimulation shall be done. Valid range 5 to 1000000000 microseconds.

=back

B<Return Value:>

=over

=item $success 

Success flag: =1 on success or in offline mode, 0 on error.

=back

B<Examples:>

    TSG4_LV124_E10( '100K', 200 ); #interrupt UF input for 200 microsec

B<Notes>:

Since the LV124_E10 functionality is not done on a specific PLS line but generic in UF path, not all preconditions can be tested. 
If not all used power lines are configured to UF there will be a warning. The connection state is not checked.

to meet all preconditions a typical flow is configuring B<'PSLx_Default' to 'UF'> in TSG4 mapping and calling B<TSG4_ConnectLine('ALL_SUPPLY')> before calling B<TSG4_LV124_E10>

=for html
<IMG SRC='..\..\pics\LV124_Ubat.png'  alt="LV124_E10 Ubat circuit" border="0" width=400px>
<IMG SRC='..\..\pics\LV124_Ubat2.png'  alt="LV124_10 Ubat switching" border="0">
<br><br>Oscilloscope screenshots of LV124 E-10 microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_Ubat.png' target="blank">measurement circuit</a><br>
mode '100K':
<a href='..\..\pics\TSG4\Ubat_1_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_1_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_1_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_1_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_1_100.png' target="blank">100 us</a>
<br>mode '10K':
<a href='..\..\pics\TSG4\Ubat_2_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_2_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_2_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_2_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_2_100.png' target="blank">100 us</a>
<br>mode '0.1R':
<a href='..\..\pics\TSG4\Ubat_3_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\Ubat_3_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat_3_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat_3_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat_3_100.png' target="blank">100 us</a>
<br>
timing <a href='..\..\pics\TSG4\Ubat_2_100can.png' target="blank">message to interruption</a>
, timing <a href='..\..\pics\TSG4\Ubat_2_100decoding.png' target="blank">message decoding</a>


=cut

#     ubat card required as parameter???

sub TSG4_LV124_E10{
    my $mode = shift;
    my $time = shift;

	my $countUF=0;
    my %mode_table =(
        '100K' => 1,
        '10K' => 2,
        '0.1R' => 3,
    );
    unless (defined( $time )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_LV124_E10( \$mode, \$time )", 110 );
        return 0;
    }
    unless (exists $mode_table{$mode}){
        S_set_error( "! $mode is not a valid mode !", 114 );
        return 0;
    }
    if ($time < 5 or $time > 1000000000){
        S_set_error( "! $time is out of range (must be 5us to 1000s) !", 114 );
        return 0;
    }

    my $mode_nr=$mode_table{$mode};

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }

	foreach my $name (@TSG4_PSlines){
		$countUF++ if ($TSG4_labels->{$name}{"default"} eq 'UF');
	}
	my $count_PSL=scalar(@TSG4_PSlines);
	
	if ($countUF<1){
        S_set_error( "no power line configrerd to UF, but LV124_E10 works only on UF input, please check 'PSLx_Default' in TSG4 mapping\n" , 114);
        return 0;
	}
	if ($countUF<$count_PSL){
        S_set_warning( "LV124_E10 only on $countUF UF lines of $count_PSL power supply lines\n");
	}

    S_w2log(1,"TSG4_LV124_E10( $mode, $time ) on $countUF UF lines of $count_PSL power supply lines\n");

    return 1 if $main::opt_offline;

    $status = ubat_LV124_E10(1,$mode_nr,$time); # only works on UF !

    Check_status($status);
    S_w2log(4,"TSG4_LV124_E10 $mode, $time  status=$status\n");
    return 1;
}


=head2 TSG4_LV124_microcut

    $success = TSG4_LV124_microcut( $line, $time_us );

perform single microcut on line, refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

B<Arguments:>

=over

=item $line 

line where the manipulation shall happen, has to be a label from ProjectConst

for power suppy lines you have to give a terminal (+/-)

for other devices terminal will be ignored

=item $time_us 

Time in microseconds how long the stimulation shall be done. Valid range 1 to 1000000000 microseconds.

for power suppy lines time has to be >= 10

=back

B<Return Value:>

=over

=item $success 

Success flag: =1 on success or in offline mode, 0 on error.

=back

B<Examples:>

    TSG4_LV124_microcut( 'BT1FP', 24 );
    TSG4_LV124_microcut( 'PPSL', 24 );
    TSG4_LV124_microcut( 'BLRR', 24 );
    TSG4_LV124_microcut( 'PADL', 24 );
    TSG4_LV124_microcut( 'UB2-', 24 );

B<Notes>:

=for html
Oscilloscope screenshots of Belt Lock microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_BL.png' target="blank">measurement circuit</a><br>
Belt Lock 1:
<a href='..\..\pics\TSG4\BL_microcut_1.png' target="blank">1 us</a>
<a href='..\..\pics\TSG4\BL_microcut_2.png' target="blank">2 us</a>
<a href='..\..\pics\TSG4\BL_microcut_3.png' target="blank">3 us</a>
<a href='..\..\pics\TSG4\BL_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\BL_microcut_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\BL_microcut_6.png' target="blank">6 us</a>
<a href='..\..\pics\TSG4\BL_microcut_7.png' target="blank">7 us</a>
<a href='..\..\pics\TSG4\BL_microcut_8.png' target="blank">8 us</a>
<a href='..\..\pics\TSG4\BL_microcut_9.png' target="blank">9 us</a>
<a href='..\..\pics\TSG4\BL_microcut_10.png' target="blank">10 us</a>
<br>Belt Lock 2: <a href='..\..\pics\TSG4\BL2_microcut_7.png' target="blank">7 us</a><br>
timing <a href='..\..\pics\TSG4\BL_microcut_10can.png' target="blank">message to interruption</a>
, timing <a href='..\..\pics\TSG4\BL_microcut_10decoding.png' target="blank">message decoding</a>
<br><br>
Oscilloscope screenshots of Squib microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_SQ.png' target="blank">measurement circuit</a><br>
Squib:
<a href='..\..\pics\TSG4\SQ_microcut_1.png' target="blank">1 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_2.png' target="blank">2 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_3.png' target="blank">3 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_6.png' target="blank">6 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_7.png' target="blank">7 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_8.png' target="blank">8 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_9.png' target="blank">9 us</a>
<a href='..\..\pics\TSG4\SQ_microcut_10.png' target="blank">10 us</a>
<br>timing <a href='..\..\pics\TSG4\SQ_microcut_10can.png' target="blank">message to interruption</a>
, timing <a href='..\..\pics\TSG4\SQ_microcut_10decoding.png' target="blank">message decoding</a>
<br><br>
Oscilloscope screenshots of PAS microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_PAS.png' target="blank">measurement circuit</a><br>
PAS 1:
<a href='..\..\pics\TSG4\PAS_microcut_1.png' target="blank">1 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_2.png' target="blank">2 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_3.png' target="blank">3 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_6.png' target="blank">6 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_7.png' target="blank">7 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_8.png' target="blank">8 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_9.png' target="blank">9 us</a>
<a href='..\..\pics\TSG4\PAS_microcut_10.png' target="blank">10 us</a>
<br>PAS 2: 
<a href='..\..\pics\TSG4\PAS2_microcut_2.png' target="blank">2 us</a>
<a href='..\..\pics\TSG4\PAS2_microcut_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\PAS2_microcut_7.png' target="blank">7 us</a>
<br>
timing <a href='..\..\pics\TSG4\BL_microcut_10can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of Warning Lamp microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_WL.png' target="blank">measurement circuit</a>
<br>WL 1: 
<a href='..\..\pics\TSG4\WL1_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL1_microcut_7.png' target="blank">7 us</a>
<br>WL 2: 
<a href='..\..\pics\TSG4\WL2_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL2_microcut_7.png' target="blank">7 us</a>
<br>WL 3: 
<a href='..\..\pics\TSG4\WL3_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL3_microcut_7.png' target="blank">7 us</a>
<br>WL 4:
<a href='..\..\pics\TSG4\WL_microcut_1.png' target="blank">1 us</a>
<a href='..\..\pics\TSG4\WL_microcut_2.png' target="blank">2 us</a>
<a href='..\..\pics\TSG4\WL_microcut_3.png' target="blank">3 us</a>
<a href='..\..\pics\TSG4\WL_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL_microcut_5.png' target="blank">5 us</a>
<a href='..\..\pics\TSG4\WL_microcut_6.png' target="blank">6 us</a>
<a href='..\..\pics\TSG4\WL_microcut_7.png' target="blank">7 us</a>
<a href='..\..\pics\TSG4\WL_microcut_8.png' target="blank">8 us</a>
<a href='..\..\pics\TSG4\WL_microcut_9.png' target="blank">9 us</a>
<a href='..\..\pics\TSG4\WL_microcut_10.png' target="blank">10 us</a>
<br>WL 5: 
<a href='..\..\pics\TSG4\WL5_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL5_microcut_7.png' target="blank">7 us</a>
<br>WL 6: 
<a href='..\..\pics\TSG4\WL6_microcut_4.png' target="blank">4 us</a>
<a href='..\..\pics\TSG4\WL6_microcut_7.png' target="blank">7 us</a>
<br>
timing <a href='..\..\pics\TSG4\BL_microcut_10can.png' target="blank">message to interruption</a>
<br><br>
Oscilloscope screenshots of Ubatp microcuts (CH2 = CAN):<br>
<a href='..\..\pics\TSG4\measure_Ubat_microcut.png' target="blank">measurement circuit</a>
<br>Ubat 1+ : 
<a href='..\..\pics\TSG4\Ubat1p_microcut_20.png' target="blank">20 us</a>
<a href='..\..\pics\TSG4\Ubat1p_microcut_50.png' target="blank">50 us</a>
<a href='..\..\pics\TSG4\Ubat1p_microcut_100.png' target="blank">100 us</a>
<br>Ubat 2- : 
<a href='..\..\pics\TSG4\Ubat2m_microcut_9.png' target="blank">9 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_10.png' target="blank">10 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_11.png' target="blank">11 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_12.png' target="blank">12 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_13.png' target="blank">13 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_14.png' target="blank">14 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_15.png' target="blank">15 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_16.png' target="blank">16 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_17.png' target="blank">17 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_18.png' target="blank">18 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_19.png' target="blank">19 us</a>
<a href='..\..\pics\TSG4\Ubat2m_microcut_20.png' target="blank">20 us</a>
<br>
timing <a href='..\..\pics\TSG4\Ubat_microcut_can.png' target="blank">message to interruption</a>

=cut

sub TSG4_LV124_microcut{
    my $label = shift;
    my $time = shift;
	my $terminal;
	$terminal='';

   unless (defined( $time )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_LV124_microcut( \$line, \$time_us )", 110 );
        return 0;
    }
    if ($time < 1 or $time > 1000000000){
        S_set_error( "! $time is out of range (must be 1us to 1000s) !", 114 );
        return 0;
    }

	#get terminal, if given
	if ($label =~ /[+-]$/){
		$terminal = chop($label);
	}

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type ) {
        S_set_error( "TSG4_LV124_microcut '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(4,"TSG4_LV124_microcut( $label$terminal, $time ) \n");

    return 1 if $main::opt_offline;

    if($type eq 'BELT_LOCKS'){
        $status = bl_microcut($number,$time);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_microcut($number,$time);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_microcut($wlCard,$wlNum);
        Check_status($status,$label) || return 0;
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        if($pasNum == 1){
            $status = pas_microcut($pasBank,$pasNum,$time);
            Check_status($status,$label) || return 0;
        }
        else{
            S_set_error( "! LV124 microcut functionality only possible on first PAS of each bank ! bank $pasBank PAS $pasNum was selected", 114 );
            return 0;
        }
    }
    elsif($type eq 'POWER_SUPPLY_LINES'){
		my %faultmap=(
			'1Ubat+' => 0,
			'1UF+'   => 1,
			'1Ubat-' => 2,
			'1UF-'   => 3,
			'2Ubat+' => 4,
			'2UF+'   => 5,
			'2Ubat-' => 6,
			'2UF-'   => 7,
			'3Ubat+' => 8,
			'3UF+'   => 9,
			'3Ubat-' => 10,
			'3UF-'   => 11,
			'4Ubat+' => 12,
			'4UF+'   => 13,
			'4Ubat-' => 14,
			'4UF-'   => 15,
		);

        my $input = $TSG4_labels->{$label}{"default"};
        unless ($input eq 'UF' or $input eq 'Ubat'){
            S_set_error( "TSG4_DisconnectLine '$label' unknown input $input (must be UF or Ubat)" , 109);
			return 0;
        }
        unless ($terminal eq '+' or $terminal eq '-'){
            S_set_error( "TSG4_DisconnectLine '$terminal' unknown terminal (must be + or -)" , 109);
			return 0;
        }
		my $fault_type = $faultmap{$number.$input.$terminal};
        unless (defined $fault_type){
            S_set_error( "TSG4_DisconnectLine could not map '$number$input$terminal' to a fault type" , 109);
			return 0;
        }

 		$status = ubat_microcut(1,$fault_type,$time);
        Check_status($status,$label) || return 0;

	}
    else{
        S_set_error( "TSG4_LV124_microcut only implemented for 'WARNING_LAMPS', BELT_LOCKS', 'POWER_SUPPLY_LINES', 'SQUIBS' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(5,"TSG4_LV124_microcut $label$terminal, $time  status=$status\n");
    return 1;
}


=head2 TSG4_SetLogicalState

    TSG4_SetLogicalState( $switch, $state )

set switch to state, $switch and $state have to be a label from ProjectConst

 if state is 'DEFAULT' then the default value is taken.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetLogicalState( 'PADS', 'PAB_disabled' );  # will set PADS to 200 mA
    TSG4_SetLogicalState( 'BLRR', 'unbuckled' );     # will set BLRR to 400 Ohm
    TSG4_SetLogicalState( 'PADS', 'DEFAULT' );       # will set PADS to 100 mA
    TSG4_SetLogicalState( 'BLR2P_VW', 'unbuckled' ); # will set PADS to 9990 Ohm (open)
    TSG4_SetLogicalState( 'BLR2P_VW', 'DEFAULT' );   # will set BLR2P_VW to 20 Ohm (short/closed)

 TODO: open + short as values

=cut

sub TSG4_SetLogicalState {
    my $label       = shift;
    my $state       = shift;
    my @errorReturn = ( undef, undef, 0 );

    unless ( defined($state) ) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_SetLogicalState( \$switch, \$state )", 110 );
        return @errorReturn;
    }

    #Get Type of device for $label
    my $type   = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};
    my $value;
    my $unit = '?';

    unless ( defined $type ) {
        S_set_error( "TSG4_SetLogicalState '$label' unknown (please check TSG4 mapping in Project Const)", 109 );
        return @errorReturn;
    }

    unless ( $type eq 'BELT_LOCKS' ) {
        S_set_error( "TSG4_SetLogicalState only implemented for 'BELT_LOCKS'", 109 );
        return @errorReturn;
    }

    unless ($TSG4_initialized) {
        S_set_error( "TSG4 not initialized", 120 );
        return @errorReturn;
    }

    S_w2log( 1, "TSG4_SetLogicalState( $label, $state  ) \n" );

    if ( $state eq 'DEFAULT' ) {
        $value = $TSG4_labels->{$label}{"default"};
    }
    else {
        $value = $TSG4_labels->{$label}{"states"}{$state};
    }

    unless ( defined $value ) {

        # value may be ([list of states] or DEFAULT)
        my $found_states = join( ',', sort keys( %{ $TSG4_labels->{$label}{"states"} } ), 'DEFAULT' );
        S_set_error( "TSG4_SetLogicalState '$state' unknown (please check TSG4 mapping in Project Const) state for $label may be: $found_states", 109 );
        return @errorReturn;
    }

    $unit = $TSG4_labels->{$label}{"unit"};

    #value = short / open -> R

    if ( $unit eq 'I' ) {

        #parameter range check
        if ( ( $value < 0.1 ) || ( $value > 100 ) ) {
            S_set_error( "current $value out of range (0.1 <= x <= 100)", 114 );
            return @errorReturn;
        }
    }
    elsif ( $unit eq 'R' ) {

        #parameter range check
        if ( ( $value < 20 ) || ( $value > 15990 ) ) {
            S_set_error( "resistance $value out of range (20 <= x <= 15990)", 114 );
            return @errorReturn;
        }
    }
    else {
        S_set_error( "TSG4_SetLogicalState unknown unit '$unit' (must be R or I)", 109 );
        return @errorReturn;
    }

    return ( $value, $unit, 1 ) if $main::opt_offline;

    $status = bl_set_resistance( $number, $value ) if ( $unit eq 'R' );
    $status = bl_set_current( $number, $value ) if ( $unit eq 'I' );
    return @errorReturn unless Check_status( $status, $label );

    S_w2log( 4, "TSG4_SetLogicalState( $label, $state ($unit = $value)  ) status=$status\n" );
    return ( $value, $unit, 1 );
}

=head2 TSG4_SetVoltage

currently only internal power supply and TOE1 supported.

    TSG4_SetVoltage( $voltage [, $power_source] );

    $power_source = UF or Ubat, default is Ubat

set voltage of TSG4, $voltage has to be a float value, may be mapped in ProjectConst

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    TSG4_SetVoltage( 'U_BATT_DEFAULT' );
    TSG4_SetVoltage( 10.5 , 'UF');

 voltage range for internal power supply 4.2 to 20 V step 0.01 V

 voltage range for TOELLNER already checked in TOE1 module

=cut

sub TSG4_SetVoltage{
    my $voltage = shift;
    my $power_source = shift;
    my ($value,$maxVoltage);

    $power_source = 'Ubat' unless defined $power_source;

    unless (defined( $voltage )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_SetVoltage( \$voltage )", 110 );
        return 0;
    }

    unless ($power_source eq 'UF' or $power_source eq 'Ubat') {
        S_set_error( "! unknown power_source '$power_source' (UF or Ubat)", 114 );
        return 0;
    }

    #map voltage if necessary
    unless( defined ($value = $main::ProjectDefaults->{'VEHICLE'}{$voltage}) )
    {
        if ($voltage =~ /^\d+\.?\d*$/){
            $value = $voltage;
        }else{
            S_set_error("could not resolve voltage $voltage", 114 );
            return 0;
        }
    }

    unless( defined ($maxVoltage = $main::ProjectDefaults->{'TSG4'}{'General'}{'MaxVoltage'}) )
    {
    	$maxVoltage = 32;
    }

    #parameter range check
    if( ($value < 0)||($value > $maxVoltage) )
    {
        S_set_error("voltage $value out of range (0 <= x <= $maxVoltage), upper limit = MaxVoltage", 114 );
        return 0;
    }

    S_w2log(4,"TSG4_SetVoltage to $voltage (V $value)\n");


    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    return 1 if $main::opt_offline;

#   better use hash with corresponding tool e.g. $supply{'Ubat'} = 'internal'
# then we can check if  $supply{$power_source} eq 'internal'
    $status=0;
    if ($power_source eq 'Ubat' and $Ubat_supply eq 'internal'){
	    #parameter range check
	    if( ($value < 4.2)||($value > 20) )
	    {
	        S_set_error("internal voltage $value out of range (4.2 <= x <= 20)", 114 );
	        return 0;
	    }
  	    $status = rc_set_voltage(1,int($value*1000));
	    Check_status($status);
	    $status = rc_display_text(1,"$value V",1);
    }
    elsif ($power_source eq 'UF' and $UF_supply eq 'internal'){
	    #parameter range check
	    if( ($value < 4.2)||($value > 20) )
	    {
	        S_set_error("internal voltage $value out of range (4.2 <= x <= 20)", 114 );
	        return 0;
	    }
	    $status = rc_set_voltage(1,int($value*1000));
	    Check_status($status);
	    $status = rc_display_text(1,"$value V",1);
    }
    elsif ($power_source eq 'Ubat' and $Ubat_supply eq 'TOE1'){
        TOE1_PPSvoltage( $voltage );
    }
    elsif ($power_source eq 'UF' and $UF_supply eq 'TOE1'){
        TOE1_PPSvoltage( $voltage );
    }
    else{
        S_set_error("error in power settings power_source=$power_source Ubat_supply=$Ubat_supply UF_supply=$UF_supply", 114 );
        $status=-1;
    }
    S_w2log(4,"TSG4_SetVoltage status=$status\n");
    return 1;
}


=head2 TSG4_add_pins_to_short

    TSG4_add_pins_to_short( $lines_aref );

Add lines to an existing short. 
Any element of $lines_aref must be a label from ProjectConst with + or - added.
For WARNING_LAMPS sign will be ignored.
For Power lines only "B+" and "B-" are supported.

B< Note: TSG4_ShortLines had to be called before !>

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_add_pins_to_short( ['AB1FD+', 'BT1FP-'] );
    TSG4_add_pins_to_short( ['PADS+'] );
    TSG4_add_pins_to_short( ['B+'] );


=cut

sub TSG4_add_pins_to_short{
    my $lines_aref = shift;

    #STEP check function arguments
    unless (defined( $lines_aref )) {
        S_set_error( "! too less parameters ! TSG4_add_pins_to_short( \$lines_aref  )", 110 );
        return 0;
    }
    if (scalar( @$lines_aref ) < 1) {
        S_set_error( "! too less parameters ! \$lines_aref must contain at least 1 label  )", 110 );
        return 0;
    }

    #STEP return with error if no short is active
    unless ($short_active) {
        S_set_error( "No short active.", 110 );
        return 0;
    }

    #STEP return with error for wrong short type
    if ($via_target == 0) {
        S_set_error( "TSG4_add_pins_to_short not possible since short type does not allow.", 110 );
        return 0;
    }

    #CALL Validate_tsg4shortlines_conditions
    my @all_lines = (@short_active_lines, @$lines_aref);
    my $tsg4addShort_href = Validate_tsg4shortlines_conditions(\@all_lines, 1);

    #STEP return if lines do not fulfill the conditions 
    return 0 if ( $tsg4addShort_href->{'status'} == 0 );

    S_w2log(4,"TSG4_add_pins_to_short( @$lines_aref ) \n");
    return 1 if $main::opt_offline;
    
    #STEP count terminal lines
    my $linecount_href = $tsg4addShort_href->{'linecount'};
    my $gndCount       = $linecount_href->{'B-'};
    my $vBatCount      = $linecount_href->{'B+'};
    my $gndCountUF     = $linecount_href->{'UF-'};
    my $vBatCountUF    = $linecount_href->{'UF+'};

    #STEP return with error if UF line is added
    if( $gndCountUF + $vBatCountUF == 1 ) {
        S_set_error( "Adding short of lines 'UF+' or 'UF-' is not supported.", 110 );
        return 0;
    }

    #STEP connect B+ or B- line to REF1
    if ( $gndCount + $vBatCount + $gndCountUF + $vBatCountUF == 1 ) {
        my $connection_type = $tsg4addShort_href->{'connection_type'};
        $status = via_connect_REF( 1, $connection_type );
        Check_status($status) || return 0;
    }

    #LOOP-START loop over all given lines
    foreach my $line (@$lines_aref){

	    #STEP skip non-terminals
	    next if ($line eq 'B+' or $line eq 'B-' or $line eq 'UF+' or $line eq 'UF-');
            
        #CALL Short_line for the current line
	    $status = Short_line($line,$via_target);
	    Check_status($status) || return 0;

    }
    #LOOP-END last line?

    #STEP store currently active short lines for next call
    @short_active_lines = @all_lines;

    S_w2log(5,"TSG4_add_pins_to_short done\n");
    return 1;
}


=head2 TSG4_remove_pins_from_short

    TSG4_remove_pins_from_short( $lines_aref );

Remove lines from an existing short. 
Each element of $lines_aref must be a label from ProjectConst with + or - added.
For WARNING_LAMPS sign will be ignored.
Power lines like "B+","B-", "UF+" or "UF-" are not allowed

B< Note: TSG4_ShortLines had to be called before !>

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_remove_pins_from_short( ['AB1FD+', 'BT1FP-'] );
    TSG4_remove_pins_from_short( ['PADS+'] );


=cut

sub TSG4_remove_pins_from_short{
    my $lines_aref = shift;

    #STEP check function arguments
    unless (defined( $lines_aref )) {
        S_set_error( "! too less parameters ! TSG4_remove_pins_from_short( \$lines_aref  )", 110 );
        return 0;
    }
    if (scalar( @$lines_aref ) < 1) {
        S_set_error( "! too less parameters ! \$lines_aref must contain at least 1 label  )", 110 );
        return 0;
    }

    #STEP return with error if no short is active
    unless ($short_active) {
        S_set_error( "No short active.", 110 );
        return 0;
    }

    #STEP return with error for wrong short type
    if ($via_target == 0) {
        S_set_error( "TSG4_remove_pins_from_short not possible since short type does not allow.", 110 );
        return 0;
    }

    S_w2log(4,"TSG4_remove_pins_from_short( @$lines_aref ) \n");
    return 1 if $main::opt_offline;
   
    my @all_lines = @short_active_lines;

    #LOOP-START loop over all given lines
    foreach my $line (@$lines_aref){

	    #STEP skip non-terminals
	    if ($line eq 'B+' or $line eq 'B-' or $line eq 'UF+' or $line eq 'UF-'){
	    	S_set_warning( "$line skipped because not allowed for TSG4_remove_pins_from_short" );
	    	next;
	    }

        #STEP skip lines which are not part of the short
        if( not grep { $_ eq $line } @all_lines ) {
	    	S_set_warning( "$line skipped because it is not part of an existing short" );
	    	next;
        }

        #CALL Undo_short_line for the current line
	    $status = Undo_short_line($line,$via_target);
	    Check_status($status) || return 0;

        @all_lines = grep { $_ ne $line } @all_lines;
    }
    #LOOP-END last line?

    #STEP store currently active short lines for next call
    @short_active_lines = @all_lines;

    S_w2log(5,"TSG4_remove_pins_from_short done\n");
    return 1;
}

=head2 TSG4_ShortLines

    $returnValue = TSG4_ShortLines( $lines_aref, [$resistance]  );

create a short between $lines (with leakage resistor $resistance). 

TSG4 must be intialised before this function is called.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

B<Arguments:>

=over

=item $lines_aref 

$lineX may be a label from ProjectConst with + or - added, or "B+","B-", "UF+" or "UF-".
for WARNING_LAMPS sign will be ignored
for CAN pins sign will be mapped: + to high pin, - to low pin

=item $resistance 

(optional) Resistance between the short . $resistance can take value from 0 to 100000 Ohms, default is 0.

=back

B<Return Value:>

=over

=item $returnValue 

Returns 1 if the function works normally, 
        0 if there is an error and in offline mode.

=back

B<Examples:>

    TSG4_ShortLines( ['AB1FD+', 'BT1FP-'] );
    TSG4_ShortLines( ['AB1FD+', 'PADS+'] );
    TSG4_ShortLines( ['AB1FD+', 'UFS1+'] );
    TSG4_ShortLines( ['AB1FD+', 'B+'] );
    TSG4_ShortLines( ['AB1FD+', 'B-'] );
    TSG4_ShortLines( ['CANdiag+', 'B-'] ); # connect CAN high pin to GND
    TSG4_ShortLines( ['AB1FD+', 'BT1FP-', 'UF+'], 100 ); # AB1FD+ connected to BT1FP- will be shorthed via 100 Ohms to UF+
    TSG4_ShortLines( ['AB1FD+', 'UF-'], 100 );
    #for the above short types pins can be added or removed by TSG4_add_pins_to_short and TSG4_remove_pins_from_short

    #for this short type TSG4_add_pins_to_short and TSG4_remove_pins_from_short is not possible:
    TSG4_ShortLines( ['AB1FD+', 'BT1FP-'], 100); # AB1FD+ will be shorted via 100 Ohms to BT1FP-

B<Notes:> 

Only one short is possible at a particular instance.

PAS- should not be shorted to Ubat.

B<you need to call L</TSG4_UndoShortLines> to remove short.>

=cut

sub TSG4_ShortLines {

    my @args = @_;
    my $tsg4Data_href;

    # STEP check the input mandatory and optional parameters
    S_checkFunctionArguments( 'TSG4_ShortLines( $lines_aref, [$resistance]  )', @args )
      or return 0;

    my $connection_type;
    my $linecount_href;
    my $lines_aref = shift @args;
    my $resistance = shift @args;

    # STEP check input and validate TSG4_shortLines conditions
    # CALL Validate_tsg4shortlines_conditions

    $tsg4Data_href = Validate_tsg4shortlines_conditions($lines_aref);
    return 0 if ( $tsg4Data_href->{'status'} == 0 );

    # STEP Check the validity of resistance values before proceeding
    $resistance = 0 unless ( defined $resistance );
    unless ( $resistance =~ /^\d+\.?\d*$/ ) {
        S_set_error( " TSG4_ShortLines : could not resolve Resistance value $resistance, Value can be only numeric (0 - 100000 ohms).", 114 );
        return 0;
    }

    S_w2log( 4, "TSG4_ShortLines(  @$lines_aref , $resistance ) \n" );

    my ( $gndCount, $vBatCount, $gndCountUF, $vBatCountUF );
    $gndCount = $vBatCount = $gndCountUF = $vBatCountUF = 0;

    # STEP Check if TSG4 is initialised
    unless ($TSG4_initialized) {
        S_set_error( "TSG4 not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline) {
        $Ref_use{'offline'} = 5;
        $short_active       = 1;
        $via_target         = 1;
        return 1;
    }
    $linecount_href = $tsg4Data_href->{'linecount'};
    $gndCount       = $linecount_href->{'B-'};
    $vBatCount      = $linecount_href->{'B+'};
    $gndCountUF     = $linecount_href->{'UF-'};
    $vBatCountUF    = $linecount_href->{'UF+'};
    

    #IF 2 labels and resistor value only, connect via resistor
    #   IF-YES-START
    #       STEP short lines
    #       STEP set resistance via Rdecade
    #   IF-YES-END
    #   IF-NO-START
    #       STEP connect Power device lines
    #       STEP Set resistance via Rdecade
    #       STEP short rest of device lines
    #   IF-NO-END
    
    if ( $gndCount + $vBatCount + $gndCountUF + $vBatCountUF == 0 and $resistance > 0 and scalar(@$lines_aref) == 2 ) {

        $status = Short_line( $$lines_aref[0], 1 );    # connect first line to via1
        Check_status($status) || return 0;
        $status = Short_line( $$lines_aref[1], 2 );    # connect second line to via2
        Check_status($status) || return 0;

        # enable and set resistor decade
        $status = via_set_Rdecade( 1, $resistance );
        Check_status($status) || return 0;
        $status = via_connect_Rdecade(1);
        Check_status($status) || return 0;

        # lock adding/removing of shorts
        $via_target = 0;
    }
    else {

        $via_target = 1;

        #  some labels and GND/VBAT and resistor, connect labels ref1 and via decade ref2 and ref2 to GND/VBAT
        #  some labels and GND/VBAT and no resistor, connect labels ref1 and via shorted decade ref2 and ref2 to GND/VBAT
        if ( $gndCount + $vBatCount + $gndCountUF + $vBatCountUF == 1 ) {
            $connection_type = $tsg4Data_href->{'connection_type'};
            $via_target = 2 if ( $connection_type > 2 );
            $status = via_connect_REF( 1, $connection_type );
            Check_status($status) || return 0;
        }

        # if short to GND/UBAT or via leakage resistor: enable and set resistor decade
        if ( $gndCount + $vBatCount + $gndCountUF + $vBatCountUF == 1 or $resistance > 0 ) {
            $status = via_set_Rdecade( 1, $resistance );
            Check_status($status) || return 0;
            $status = via_connect_Rdecade(1);
            Check_status($status) || return 0;
        }

        #short lines to ref line
        foreach my $line (@$lines_aref) {

            # skip non-terminals
            next if ( $line eq 'B+' or $line eq 'B-' or $line eq 'UF+' or $line eq 'UF-' );
            $status = Short_line( $line, $via_target );
            Check_status($status) || return 0;

        }

    }
    #STEP Set short active and return
    $short_active = 1;
    @short_active_lines = @$lines_aref;
    S_w2log( 5, "TSG4_ShortLines done\n" );
    return 1;
}

=head2 Validate_tsg4shortlines_conditions not exported

    $tsg4Data_href = Validate_tsg4shortlines_conditions($lines_aref [, $add_short]);

Validates the inputs and condiotions for TSG4_shortlines.

=cut

sub Validate_tsg4shortlines_conditions
{
    my @args       = @_;
    my $lines_aref = shift @args;
    my $add_short = shift @args // 0;   # extra optional argument to be able to use this function in TSG4_add_pins_to_short
    my %linecount;
    my $power_dev_flag  = 0;
    my $connection_type;
    my $sign;
    my $type;
    my $lineName;
    my $tsg4Data_href;
    $tsg4Data_href->{'status'} = 0;
    my %connectiontype_powdev = (
        'B-'  => 4,
        'B+'  => 3,
        'UF-' => 2,
        'UF+' => 1,
    );

    # STEP check if no of devices are less than 2
    if ( scalar(@$lines_aref) < 2 ) {
        S_set_error( "! too less parameters ! \$lines_aref must contain at least 2 labels  )", 110 );
        return $tsg4Data_href;
    }

    # STEP Check if the short is active already. Only one fault can be active at a time
    if ($short_active and not $add_short) {
        S_set_error( "Only one short at same time is possible. Line " . join( " ", sort( keys %Ref_use ) ) . " is already short.", 110 );

        return $tsg4Data_href;
    }

    # STEP Validate each of labels for sign
    # STEP set error if any device is repeated
    # STEP identify the connection type and line count hash ref
    #create hash from list, check list and hash keys list has same length (no double items)
    foreach my $line (@$lines_aref) {

        if ( $line !~ /[+-]$/ ) {
            S_set_error( "sign missing in line : label has to be $line- or $line+", 109 );
            return $tsg4Data_href;
        }

        $linecount{$line}++;

        if ( $linecount{$line} > 1 ) {
            S_set_error( "same labels $line found $linecount{$line} times", 109 );
            return $tsg4Data_href;
        }

        if ( defined $connectiontype_powdev{$line} ) {
            $connection_type = $connectiontype_powdev{$line};
        }
    }
    $linecount{'B-'}  = 0 unless defined( $linecount{'B-'} );
    $linecount{'B+'}  = 0 unless defined( $linecount{'B+'} );
    $linecount{'UF-'} = 0 unless defined( $linecount{'UF-'} );
    $linecount{'UF+'} = 0 unless defined( $linecount{'UF+'} );
    
    # STEP Check if more than one power device is set
    if ( ( $linecount{'B-'} + $linecount{'B+'} + $linecount{'UF-'} + $linecount{'UF+'} ) > 1 ) {
        S_set_error( "B+, B-, UF+ or UF- can be used only once ", 109 );
        return $tsg4Data_href;
    }
    $connection_type = 0 unless defined $connection_type;
    $power_dev_flag = 1 if( $linecount{'B+'} == 1 || $linecount{'UF+'} == 1) ;

    # STEP check if PAS- lines are connected to power device positive  
    foreach my $line (@$lines_aref) {
        next if ( $line eq 'B+' or $line eq 'B-' or $line eq 'UF+' or $line eq 'UF-' );
        $lineName = $line;
        $sign = chop($lineName);
        $type = undef;
        $type = $TSG4_labels->{$lineName}{"section"};
        unless ( defined $type ) {
            S_set_error( "Short_line '$line' unknown (please check TSG4 mapping in Project Const)" , 109);
            return $tsg4Data_href;
        }
        if ( $power_dev_flag == 1 && $type eq 'PAS_LINES' && $sign eq '-' ) {
            S_set_error("Negative PAS lines should not be shorted to vbat or uvbat" , 109);
            return $tsg4Data_href;
        }
    }
    $tsg4Data_href = { 'status' => 1, 'connection_type' => $connection_type, 'linecount' => \%linecount };

    return ($tsg4Data_href);
}


=head2 TSG4_UndoShortLines

    TSG4_UndoShortLines();

remove short condition

=cut

sub TSG4_UndoShortLines{


    S_w2log(1,"TSG4_UndoShortLines( ) \n");

    unless($short_active){
        S_set_warning( "! No short exists !"); # only warning
        return 1;
    }

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }

    if ($main::opt_offline){
        %Ref_use=();
        $short_active=0;
        $via_target = 0;
        return 1 ;
    }

    foreach my $line (sort keys %Ref_use){
        # skip non-terminals
        next if ($line eq 'B+' or $line eq 'B-' or $line eq 'UF+' or $line eq 'UF-');
        $status = Undo_short_line($line,$via_target);
        Check_status($status) || return 0;
    }

        # disable short
        $status = via_disconnect_REF(1,0);
        Check_status($status);
        # disable resistor decade
        $status = via_disconnect_Rdecade(1);
        Check_status($status);
        $status = via_set_Rdecade(1,0);
        Check_status($status);


    %Ref_use=();
    $via_target=0;
    $short_active=0;

    S_w2log(4,"TSG4_UndoShortLines done\n");
    return 1;
}


=head2 TSG4_SetInertSquibMode

    TSG4_SetInertSquibMode( $label_aref [, $current_threshold] );

will disconnect squib if configured current threshold is exceeded (implemented on squib card internally)

you may also use 'ALL' to set all squibs in ProjectConst.

optional $current_threshold between 0 .. 4 Ampers step 0.01 Ampers

only applicable for Squibs !

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetInertSquibMode( ['AB1FD','BT1FP'], 1.5 ); # set only 2 squibs AND configure threshold newly
    TSG4_SetInertSquibMode( ['ALL'] );		          # set all squibs ( AB1FD BT1FP AB1FP )

TSG4_SetInertSquibMode will connect selected squibs automatically.

calls internally TSG4_SetSquibCurrentThreshold if $current_threshold was given

=cut

sub TSG4_SetInertSquibMode{

    my $label_aref = shift;
    my $current_threshold = shift;
    my $value;
    my $label_text = "[ ";

    my @labels=@$label_aref;


    #Check for required number of Parameters
    unless (defined( $label_aref )) {
        S_set_error( "! too less parameters ! TSG4_SetInertSquibMode( \$label_aref [, \$current_threshold ] )", 110 );
        return 0;
    }

    if ( scalar(@labels) == 1 and $labels[0] eq 'ALL' ){
    	@labels = TSG4_get_names( 'SQUIBS' );
    	$label_text .= "'ALL' = ". join(', ',@labels);
    }
	else{
		foreach my $label (@$label_aref){
			$label_text .= "$label ";
		}
	}
  	$label_text .= "]";


    #check for initilaized TSG4
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized", 120);
        return 0;
    }

    TSG4_SetSquibCurrentThreshold( \@labels, $current_threshold ) if (defined $current_threshold);

	$current_threshold = '' unless (defined $current_threshold);
    S_w2log(5,"TSG4_SetInertSquibMode( $label_text, $current_threshold ) \n");

    return 1 if $main::opt_offline;

	foreach my $label (@labels){
	    #Get Type of device for $label
	    my $type = $TSG4_labels->{$label}{"section"};
	    my $number = $TSG4_labels->{$label}{"number"};

	    unless ( defined $type ) {
	        S_set_error( "TSG4_SetInertSquibMode '$label' unknown (please check TSG4 mapping in Project Const)", 109);
	        return 0;
	    }

	    #call Low level function for TSG4 device
	    if($type eq 'SQUIBS'){
        	$status = sq_connect($number);
	        Check_status($status,$label);
			$status = sq_set_fault_mode($number,'time',1);
	        Check_status($status,$label);

	    }
	    else{
	        S_set_error( "TSG4_SetInertSquibMode only implemented for 'SQUIBS'", 109);
	        return 0;
	    }
	}
    S_w2log(4,"TSG4_SetInertSquibMode status=$status\n");
    return 1;
}

=head2 TSG4_SetSquibFireMode

    $status = TSG4_SetSquibFireMode($label_aref, $firing_mode);

Sets firing mode (squib simulation) on squib decade (activated by firing pulse from ECU on squib line)

B<Arguments:>

=over

=item $label_aref

array reference of the squib names. You may also use 'ALL' to set all squibs in ProjectConst. 

=item $firing_mode

Value from 0 to 18

    0 = no simulation
    1 = lead free squib then previous value
    2 = lead free squib then interruption
    3 = lead free squib then short
    4 = lead free squib then SQ- to ref1
    5 = lead free squib then SQ+ to ref1 
    6 = lead free squib then SQ- to ref2 
    7 = lead free squib then SQ+ to ref2 
    8 = 10sec interruption
    9 = 1ms   interruption
    10 = 100us interruption
    11 = 1us   interruption 1ms pause with 4 sec cycle
    12 = 100us interruption 1ms pause with 4 sec cycle
    13 = testmode - fixed signal
    14 = run download buffer
    15 = run temp buffer
    16 = copy current values to temp buffer
    17 = switch off randomize
    18 = switch on randomize

=back

B<Return Value:>

=over

=item $status 

Success and offline   - 1

error                 - undef

=back

B<Examples:>

    $status = TSG4_SetSquibFireMode(['AB1FD','BT1FP'], 2);   # set only 2 squibs
    $status = TSG4_SetSquibFireMode(['ALL'], 12);            # set all squibs mentioned in the project const

B<Notes:> 

As per HW design, the firing loop deployment into the Z�ndi-HW of TSG4 must not be repeated more than 10 times for the same ECU, if you fire several times without any delay in between.
If you wait more than 1sec between multiple firing, the ECU firing loop ASIC will have been cooled down to initial state. 
With more than one sec delay, there is no limit in number of multiple firings for one single ECU.

(reason: Airbag firing loop ASICs are electrically stressed more by this Z�ndi-circuit during firing pulse, 
than by constant firing loop resistor, which is exactly the purpose of the test)

=cut

sub TSG4_SetSquibFireMode {

    #COMMENT-START
    #   Two arguments - label_aref and FireMode - both mandatory
    #COMMENT-END

    #IF First paramater is 'ALL' as an array reference
    #   IF-YES-START
    #       CALL TSG4_get_names to read all the squibs configured
    #   IF-YES-END
    #   IF-NO-START
    #       STEP use the array reference as the squib list
    #   IF-NO-END
    #   IF FireMode is not within the range 0-18
    #   IF-YES-START
    #       STEP set error and return
    #   IF-YES-END
    #   IF-NO-START
    #       IF offline mode
    #       IF-YES-START
    #           STEP return success
    #       IF-YES-END
    #       IF-NO-START
    #           LOOP-START loop over squibs
    #               STEP read the corresponding squib number
    #               CALL sq_set_firing_mode with squib number and firing mode
    #               STEP check status after every call
    #           LOOP-END squibs over?
    #           STEP return status
    #       IF-NO-END
    #   IF-NO-END

    my @args = @_;
    S_checkFunctionArguments( 'TSG4_SetSquibFireMode($label_aref, $firing_mode)', @args )
      or return;
    
    my $label_aref  = shift @args;
    my $firing_mode = shift @args;

    my @labels = @$label_aref;
    
    S_w2log(1,"TSG4_SetSquibFireMode\n");

    if ( scalar(@labels) == 1 and $labels[0] eq 'ALL' ) {
        @labels = TSG4_get_names('SQUIBS');
    }
    
    unless ( $firing_mode ~~ [ 0 .. 18 ] ) {
        S_set_error( "TSG4_SetSquibFireMode: Fire mode '$firing_mode' is not in the range of 0-18. Please check function documentation", 109 );
        return;
    }
    return 1 if $main::opt_offline;

    foreach my $label (@labels) {

        #Get Type of device for $label
        my $type   = $TSG4_labels->{$label}{"section"};
        my $number = $TSG4_labels->{$label}{"number"};

        unless ( defined $type ) {
            S_set_error( "TSG4_SetSquibFireMode '$label' unknown (please check TSG4 mapping in Project Const)", 109 );
            return;
        }

        #call Low level function for TSG4 device
        if ( $type eq 'SQUIBS' ) {
            $status = sq_set_firing_mode( $number, $firing_mode );
            Check_status( $status, $label );
        }
        else {
            S_set_error( "TSG4_SetSquibFireMode only implemented for 'SQUIBS'", 109 );
            return;
        }
    }
    S_w2log( 4, "TSG4_SetSquibFireMode status is $status\n" );
    return 1;
}

=head2 TSG4_SetSquibCurrentThreshold

    TSG4_SetSquibCurrentThreshold( $label_aref, $current_threshold);

will not connect device automatically if it was disconnected before!

you may also use 'ALL' to set all squibs in ProjectConst.

$current_threshold between 0 .. 4 Ampers step 0.01 Ampers

only applicable for Squibs !

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetSquibCurrentThreshold( ['AB1FD','BT1FP'], 1.2 );
    TSG4_SetSquibCurrentThreshold( ['ALL'], 1.5);		      # set all squib thresholds ( AB1FD BT1FP AB1FP )


=cut

sub TSG4_SetSquibCurrentThreshold{

    my $label_aref = shift;
    my $current_threshold = shift;
    my $value;
    my $label_text = "[ ";

    my @labels=@$label_aref;


    #Check for required number of Parameters
    unless (defined( $current_threshold )) {
        S_set_error( "! too less parameters ! TSG4_SetSquibCurrentThreshold( \$label_aref, \$current_threshold  )", 110 );
        return 0;
    }

    if ( scalar(@labels) == 1 and $labels[0] eq 'ALL' ){
    	@labels = TSG4_get_names( 'SQUIBS' );
    	$label_text .= "'ALL' = ". join(', ',@labels);
    }
	else{
		foreach my $label (@$label_aref){
			$label_text .= "$label ";
		}
	}
  	$label_text .= "]";

    S_w2log(1,"TSG4_SetSquibCurrentThreshold( $label_text, $current_threshold ) \n");

    #validate given resistance value
    if ($current_threshold =~ /^\d+\.?\d*$/){
        $value = $current_threshold;
    }
    else{
            S_set_error("could not resolve current value $current_threshold", 114 );
            return 0;
    }

    #parameter range check
    if( ($value < 0)||($value > 4) )
    {
        S_set_error("current $value out of range (0 <= x <= 4)", 114 );
        return 0;
    }

    #check for initilaized TSG4
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized", 120);
        return 0;
    }

    return 1 if $main::opt_offline;

	foreach my $label (@labels){
	    #Get Type of device for $label
	    my $type = $TSG4_labels->{$label}{"section"};
	    my $number = $TSG4_labels->{$label}{"number"};

	    unless ( defined $type ) {
	        S_set_error( "TSG4_SetSquibCurrentThreshold '$label' unknown (please check TSG4 mapping in Project Const)", 109);
	        return 0;
	    }

	    #call Low level function for TSG4 device
	    if($type eq 'SQUIBS'){
	        $status = sq_set_threshold($number,'current',$current_threshold);
	        Check_status($status,$label);
	    }
	    else{
	        S_set_error( "TSG4_SetSquibCurrentThreshold only implemented for 'SQUIBS'", 109);
	        return 0;
	    }
	}
    S_w2log(4,"TSG4_SetSquibCurrentThreshold status=$status\n");
    return 1;
}


=head2 TSG4_SetResistance

    TSG4_SetResistance( $label, $resistance);

 will not connect device automatically if it was disconnected before!

 you may also use 'DEFAULT' to set squibs/switches to default value.

For Squibs:
$resistance between 0 .. 99.9 Ohm step 0.1 Ohm

For Switch:

$resistance between 20 .. 9990 Ohm step 10 Ohm (for firmware until FW_G0006)

$resistance between 20 .. 15990 Ohm step 10 Ohm (for firmware FW_G0007 or higher)

only applicable for Switches and Squibs !

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

 e.g.
    TSG4_SetResistance( 'AB1FD', 10 );
    TSG4_SetResistance( 'AB1FD', 0 ); # shorts terminals of squib (AB1FD+ with AB1FD-)
    TSG4_SetResistance( 'BLRR', 26.5);
    TSG4_SetResistance( 'AB1FD', 'DEFAULT' );
    TSG4_SetResistance( 'BLRR', 'DEFAULT' );


=cut

sub TSG4_SetResistance{

    my $label = shift;
    my $resistance = shift;
    my $value;

    #Check for required number of Parameters
    unless (defined( $resistance )) {
        S_set_error( "! too less parameters ! TSG4_SetResistance( \$label, \$resistance  )", 110 );
        return 0;
    }

    S_w2log(1,"TSG4_SetResistance( $label, $resistance ) \n");

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type ) {
        S_set_error( "TSG4_SetResistance '$label' unknown (please check TSG4 mapping in Project Const)", 109);
        return 0;
    }
    if ($resistance eq 'DEFAULT'){
        $resistance = $TSG4_labels->{$label}{"default"};
    }

    #validate given resistance value
    if ($resistance =~ /^\d+\.?\d*$/){
        $value = $resistance;
    }
    else{
            S_set_error("could not resolve Resistance value $resistance", 114 );
            return 0;
    }

    #check for initilaized TSG4
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized", 120);
        return 0;
    }

    return 1 if $main::opt_offline;
    #call Low level function for TSG4 device

    if($type eq 'BELT_LOCKS'){
	    #parameter range check
	    if( ($value < 20)||($value > 15990) )
	    {
	        S_set_error("resistance $value out of range (20 <= x <= 15990)", 114 );
	        return 0;
	    }
        $status = bl_set_resistance($number,$resistance);
        Check_status($status,$label);
    }
    elsif($type eq 'SQUIBS'){
	    #parameter range check
	    if( ($value < 0)||($value > 99.9) )
	    {
	        S_set_error("resistance $value out of range (0 <= x <= 99.9)", 114 );
	        return 0;
	    }
        $status = sq_set_resistance($number,$resistance);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_SetResistance only implemented for 'BELT_LOCKS' and 'SQUIBS'", 109);
        return 0;
    }

    S_w2log(4,"TSG4_SetResistance status=$status\n");
    return 1;
}


=head2 TSG4_SetCurrent

    TSG4_SetCurrent( $label, $currentvalue);

sets current equal to $currentvalue(in mA) across the Switch $label. only applicable for Switches!

will not connect device automatically if it was disconnected before!

you may also use 'DEFAULT' to set switch to default value (only useful for I switches).
 
$currentvalue in mA between 0.1 .. 100.0 mA step 0.1 mA

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    TSG4_SetCurrent( 'PADS', 25.5 );
    TSG4_SetCurrent( 'BLRR', 15.0 ); # will set current where a resistor switch is configured

    TSG4_SetCurrent( 'PADS', 'DEFAULT' );
    TSG4_SetCurrent( 'BLRR', 'DEFAULT' ); # will lead to out of range error because default is intended for resistor switch

=cut

sub TSG4_SetCurrent{

    my $label = shift;
    my $currentvalue = shift;
    my $value;

    unless (defined( $currentvalue )) {
        S_set_error( "! too less parameters ! TSG4_SetCurrent( \$label, \$currentvalue  )", 110 );
        return 0;
    }

    S_w2log(1,"TSG4_SetCurrent( $label, $currentvalue ) \n");

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type ) {
        S_set_error( "TSG4_SetCurrent '$label' unknown (please check TSG4 mapping in Project Const)", 109);
        return 0;
    }
    if ($currentvalue eq 'DEFAULT'){
        $currentvalue = $TSG4_labels->{$label}{"default"};
    }

    #validate given curent value
    if ($currentvalue =~ /^\d+\.?\d*$/){
        $value = $currentvalue;
    }
    else{
        S_set_error("could not resolve Current value $currentvalue", 114 );
        return 0;
    }

    #parameter range check
    if( ($value < 0.1)||($value > 100) )
    {
        S_set_error("current $value out of range (0.1 <= x <= 100)", 114 );
        return 0;
    }

    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized", 120);
        return 0;
    }

    return 1 if $main::opt_offline;

    if($type eq 'BELT_LOCKS'){
        $status = bl_set_current($number,$currentvalue);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_SetCurrent only implemented for 'BELT_LOCKS'", 109);
        return 0;
    }

	S_w2log(4,"TSG4_SetCurrent status=$status\n");
    return 1;
}






=head2 TSG4_ConnectVIA

    TSG4_ConnectVIA( $line_terminal, $via );

connect line_terminal of TSG4 to REF, $line_terminal has to be a label from ProjectConst ending with + or -, $via has to be REF_1 or REF_2.

it is highly recommended to use TSG4_ShortLine instead, if you are not sure.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    TSG4_ConnectVIA( 'BT1FP+', "REF_1" );
    TSG4_ConnectVIA( 'BT1FP-', "REF_2" );

=cut

sub TSG4_ConnectVIA{
    my $terminal = shift;
    my $via = shift;

    unless (defined( $via )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_ConnectVIA( \$line_terminal, \$via )", 110 );
        return 0;
    }

    unless ($terminal =~ /(\+|-)$/) {
        S_set_error( "! line_terminal ($terminal) has to end with + or -", 114 );
        return 0;
    }
    my $label=$terminal;
    my $sign = chop($label); # remove sign from $label and store in $sign

    unless ($via eq "REF_1" or $via eq "REF_2") {
        S_set_error( "! via ($via) has to be REF_1 or REF_2", 114 );
        return 0;
    }
    else{
        $via =~ s/REF_//; # remove prefix
    }

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type ) {
        S_set_error( "TSG4_ConnectVIA '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_ConnectVIA( $terminal, $via ) \n");

    if (exists $Ref_use{$terminal}){
        S_set_warning( "$terminal already connected to VIA $Ref_use{$terminal}");
    }
    else{
        $Ref_use{$terminal}=$via;
    }

    return 1 if $main::opt_offline;

    if($type eq 'BELT_LOCKS'){
        $status = bl_connect_via($number,$sign,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_connect_via($number,$sign,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'WARNING_LAMPS'){
	    my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_connect_via($wlCard,$wlNum,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_connect_via($pasBank,$pasNum,$sign,$via);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_ConnectVIA only implemented for 'WARNING_LAMPS', 'BELT_LOCKS', 'SQUIBS' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_ConnectVIA status=$status\n");
    return 1;

}

=head2 TSG4_DisconnectVIA

    TSG4_DisconnectVIA( $line_terminal, $via );

disconnect line_terminal of TSG4 from REF, $line_terminal has to be a label from ProjectConst ending with + or -, $via has to be REF_1 or REF_2.

it is highly recommended to use TSG4_UndoShortLine instead, if you are not sure.

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    TSG4_DisconnectVIA( 'BT1FP+', "REF_1" );
    TSG4_DisconnectVIA( 'BT1FP-', "REF_2" );

=cut

sub TSG4_DisconnectVIA{
    my $terminal = shift;
    my $via = shift;

    unless (defined( $via )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_DisconnectVIA( \$line_terminal, \$via )", 110 );
        return 0;
    }

    unless ($terminal =~ /(\+|-)$/) {
        S_set_error( "! line_terminal ($terminal) has to end with + or -", 114 );
        return 0;
    }
    my $label=$terminal;
    my $sign = chop($label); # remove sign from $label and store in $sign

    unless ($via eq "REF_1" or $via eq "REF_2") {
        S_set_error( "! via ($via) has to be REF_1 or REF_2", 114 );
        return 0;
    }
    else{
        $via =~ s/REF_//; # remove prefix
    }

    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    unless ( defined $type ) {
        S_set_error( "TSG4_DisconnectVIA '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless ( $TSG4_initialized ) {
        S_set_error( "TSG4 not initialized" , 120);
        return 0;
    }
    S_w2log(1,"TSG4_DisconnectVIA( $terminal, $via ) \n");

    if (exists $Ref_use{$terminal}){
        if ($Ref_use{$terminal} == $via){
            delete($Ref_use{$terminal});
        }
        else{
            S_set_warning( "$terminal VIA is $Ref_use{$terminal}");
        }
    }
    else{
        S_set_warning( "$terminal not connected to VIA");
    }

    return 1 if $main::opt_offline;

    if($type eq 'BELT_LOCKS'){
        $status = bl_disconnect_via($number,$sign,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_disconnect_via($number,$sign,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_disconnect_via($wlCard,$wlNum,$via);
        Check_status($status,$label);
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_disconnect_via($pasBank,$pasNum,$sign,$via);
        Check_status($status,$label);
    }
    else{
        S_set_error( "TSG4_DisconnectVIA only implemented for 'WARNING_LAMPS', 'BELT_LOCKS', 'SQUIBS' and 'PAS_LINES'" , 109);
        return 0;
    }

    S_w2log(4,"TSG4_DisconnectVIA status=$status\n");
    return 1;
}

=head2 TSG4_ConnectSquibToOpAmp
    
    $returnValue = TSG4_ConnectSquibToOpAmp(  $squib_line_terminal , $opAmpVoltage_V  );

This function can be used to create power stage fault(highside/lowside) by setting a appropriate voltage to the squib line terminal.

and this is achieved by resetting the ecu and connecting the Squib_line_terminal of TSG4 to Opamp and setting a appropriate voltage.

B<Arguments:>

=over

=item $squib_line_terminal 

$squib_line_terminal has to be a Squib label from ProjectConst ending with + or -.

=item $opAmpVoltage_V 

$opAmpVoltage_V is the voltage to be set to Opamp (+10 .. -10 V step 0.01 V).

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , 0 : Failure

=back

B<Examples:> 

    TSG4_ConnectSquibToOpAmp( 'BT1FP+', 3 ); Highside Powerstage fault
    
    TSG4_ConnectSquibToOpAmp( 'BT1FP-', 2 ); Lowside Powerstage fault
    
Note : Voltage to be set to the squib terminal is project specific
    
Refer L</"CONFIGURATION"> for ProjectConst and Testbench configuration settings  

=cut

sub TSG4_ConnectSquibToOpAmp {

    # STEP Fetch the mandatory arguments($squib_line_terminal and $opAmpVoltage_V)

    my @args = @_;
    return unless S_checkFunctionArguments( 'TSG4_ConnectSquibToOpAmp(  $squib_line_terminal , $opAmpVoltage_V  )', @args );

    my $squib_line_terminal = shift @args;
    my $opAmpVoltage_V        = shift @args;

    # IF Squib_line_terminal end with + or - ?
    # IF-NO-START
    # STEP return status = 0 , Error msg - ! Squib_line_terminal ($squib_line_terminal) has to end with + or -.
    # IF-NO-END
    unless ( $squib_line_terminal =~ /(\+|-)$/ ) {
        S_set_error( "TSG4_ConnectSquibToOpAmp : Squib_line_terminal ($squib_line_terminal) has to end with + or -", 114 );
        return 0;
    }

    # IF-YES-START
    # STEP Fetch the Squib label and Sign from the $squib_line_terminal.
    # STEP Fetch the Type and Number of device for Squib label.

    my $label = $squib_line_terminal;
    my $sign  = chop($label);           # remove sign from $label and store in $sign

    #Get Type of device for $label
    my $type   = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    if (not defined $type or $type ne 'SQUIBS') {
        S_set_error( "TSG4_ConnectSquibToOpAmp : '$label' unknown (please check TSG4 mapping in Project Const) or the type of label is not squib", 109 );
        return 0;
    }

    # IF OpAmpVoltage is a valid decimal number ?
    # IF-NO-START
    # STEP return status = 0 , Error msg - OpAmp voltage $opAmpVoltage_V is not an integer.
    # IF-NO-END

    # IF-YES-START

    unless ( $opAmpVoltage_V =~ /^\d+\.?\d*$/ ) {
        S_set_error( "TSG4_ConnectSquibToOpAmp : OpAmp voltage $opAmpVoltage_V is not an integer", 114 );
        return 0;
    }

    # IF OpAmpVoltage is not within the range +10 to -10 ?
    # IF-NO-START
    # STEP return status = 0 , Error msg - The OpAmp voltage $opAmpVoltage_V is not within the range +10 to -10.
    # IF-NO-END

    # IF-YES-START

    if ( $opAmpVoltage_V < -10 or $opAmpVoltage_V > 10 ) {
        S_set_error( "TSG4_ConnectSquibToOpAmp : The OpAmp voltage $opAmpVoltage_V is not within the range +10 to -10", 114 );
        return 0;
    }

    # IF TSG4 initialized ?
    # IF-NO-START
    # STEP return status = 0 , Error msg - TSG4 not initialized.
    # IF-NO-END

    # IF-YES-START

    unless ($TSG4_initialized) {
        S_set_error( "TSG4_ConnectSquibToOpAmp : TSG4 not initialized", 120 );
        return 0;
    }
    S_w2log( 1, "TSG4_ConnectSquibToOpAmp( $squib_line_terminal, $opAmpVoltage_V ) \n" );

    return 1 if $main::opt_offline;

    my $refcard         = 1;
    my $connection_type = 4;

    # STEP Disconnect all TSG4 power supply lines
    TSG4_DisconnectLine('ALL_SUPPLY');
    S_wait_ms('TIMER_ECU_OFF');

    # STEP Disconnect the squib .
    TSG4_DisconnectLine($label);

    # STEP Connect to Opamp.
    $status = via_connect_OP($refcard);
    Check_status($status);

    # STEP Set Opamp Voltage.
    $status = via_set_OP_voltage( $refcard, $opAmpVoltage_V );
    Check_status($status);

    # STEP Connect reference line to Power source
    $status = via_connect_REF( $refcard, $connection_type );
    Check_status($status);

    $refcard = 2;

    if ( exists $Ref_use{$squib_line_terminal} ) {
        S_set_warning("$squib_line_terminal already connected to VIA $Ref_use{$squib_line_terminal}");
    }
    else {
        $Ref_use{$squib_line_terminal} = $refcard;
    }

    #STEP Connect squib terminal to reference line
    $status = sq_connect_via( $number, $sign, $refcard );
    Check_status( $status, $label );

    # STEP Connect all TSG4 power supply lines
    TSG4_ConnectLine('ALL_SUPPLY');
    S_wait_ms('TIMER_ECU_READY');

    S_w2log( 4, "TSG4_ConnectSquibToOpAmp status=$status\n" );

    # IF-YES-END
    # IF-YES-END
    # IF-YES-END
    # IF-YES-END
    #STEP return

    return 1;

}

=head2 TSG4_DisconnectSquibFromOpAmp
    
    $returnValue = TSG4_DisconnectSquibFromOpAmp(  $squib_label );

This function is used to dequalify the powerstage faults created using the function TSG4_ConnectSquibToOpAmp.

This is acheived by resetting the ecu and disconnecting the Squib of TSG4 from Opamp

B<Arguments:>

=over

=item $squib_label

$squib_label has to be a Squib label from ProjectConst .

=back

B<Return Value:>

=over

=item $returnValue 

1 : Successful , 0 : Failure

=back

B<Examples:> 

    TSG4_DisconnectSquibFromOpAmp( 'BT1FP');
    
Refer L</"CONFIGURATION"> for ProjectConst and Testbench configuration settings  

=cut

sub TSG4_DisconnectSquibFromOpAmp {

    # STEP Fetch the mandatory arguments($squib_label)

    my @args = @_;
    return unless S_checkFunctionArguments( 'TSG4_DisconnectSquibFromOpAmp( $squib_label )', @args );

    my $squib_label = shift @args;

    my $label = $squib_label;

    #Get Type of device for $label
    my $type   = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

    if (not defined $type or $type ne 'SQUIBS') {
        S_set_error( "TSG4_DisconnectSquibFromOpAmp : '$label' unknown (please check TSG4 mapping in Project Const) or the type of label is not squib", 109 );
        return 0;
    }

    # IF TSG4 initialized ?
    # IF-NO-START
    # STEP return status = 0 , Error msg - TSG4 not initialized.
    # IF-NO-END

    # IF-YES-START

    unless ($TSG4_initialized) {
        S_set_error( "TSG4_DisconnectSquibFromOpAmp : TSG4 not initialized", 120 );
        return 0;
    }
    S_w2log( 1, "TSG4_DisconnectSquibFromOpAmp( $squib_label) \n" );

    return 1 if $main::opt_offline;

    # STEP Disconnect all TSG4 power supply lines
    TSG4_DisconnectLine('ALL_SUPPLY');
    S_wait_ms('TIMER_ECU_OFF');

    my $refcard = 2;

    #STEP Disonnect squib terminal from reference line
    my $refcardUsed;
    my $sign = '+';
    $refcardUsed = $Ref_use{$label.$sign} if ( defined $Ref_use{$label.$sign} );
    if( $refcardUsed == $refcard ) {
        S_w2log( 5, "TSG4_DisconnectSquibFromOpAmp: disconnecting squib $number $sign from refcard $refcard...\n" );
        $status = sq_disconnect_via( $number, $sign, $refcard );
        Check_status( $status, $label );
        delete $Ref_use{$label.$sign};
    }
    $sign = '-';
    $refcardUsed = $Ref_use{$label.$sign} if ( defined $Ref_use{$label.$sign} );
    if( $refcardUsed == $refcard ) {
        S_w2log( 5, "TSG4_DisconnectSquibFromOpAmp: disconnecting squib $number $sign from refcard $refcard...\n" );
        $status = sq_disconnect_via( $number, $sign, $refcard );
        Check_status( $status, $label );
        delete $Ref_use{$label.$sign};
    }

    $refcard = 1;
    my $connection_type = 2;

    # STEP Disconnect reference line from Power source
    $status = via_disconnect_REF( $refcard, $connection_type );
    Check_status($status);

    # STEP Set Opamp Voltage to 0V.
    $status = via_set_OP_voltage( $refcard, 0 );
    Check_status($status);

    # STEP Disconnect from Opamp.
    $status = via_disconnect_OP($refcard);
    Check_status($status);

    # STEP Connect the squib .
    TSG4_ConnectLine($label);

    # STEP Connect all TSG4 power supply lines
    TSG4_ConnectLine('ALL_SUPPLY');
    S_wait_ms('TIMER_ECU_READY');

    S_w2log( 4, "TSG4_DisconnectSquibFromOpAmp status=$status\n" );

    # IF-YES-END
    #STEP return
    return 1;
}

=head2 TSG4_setCurveFile

	($u_min_V, $u_max_V, $duration_ms) = TSG4_setCurveFile( $file );
	
Load curve (in .sat format) from file and transmit to TSG4 internal power supply.

B<Arguments:>

=over

=item $file

Path to the curve input file which has the following format:

Extended .sat file e.g.
        
    time_step:           10
    volt_step:           100
    Filename:            C:\temp\test1.txt
    Points:              27
    Current Limitations: 4.00
    Repetitions:         1

    U[V]   t[s]
    5.400  1.830
    0.000  0.110
   11.600  1.060
    0.000  0.540

or standard .sat file as used for SVTT e.g.

    Dateiname:     test.sat
    Punkte:     113
    Strombegrenzung: 2.00
    Wiederholungen: 1
     
    U[V]    t[s]
     5.400  1.830
     0.000  0.110
    11.600  1.060
     0.000  0.540

From the .sat file header only the following data are used:

    - time_step (or Zeitschritt): Time resolution in ms. Possible values: 10, 20, 50, 80
    - volt_step (or Spannungsschritt): Voltage resolution in mV. Possible values: 50, 100
    - Repetitions (or Wiederholungen): How many times the curve shall be repeated: Possible values: 1 .. 255

If those data are not given in the header then reasonable default values = the lowest possible value
according to the curve data will be set. Default for Repetitions is 1.

CAUTION: Setting Repetitions to 0 is also possible, but then the curve will be repeated infinitely!

All other header items will be ignored.

=back

B<Return Value:>

=over

=item $u_min_V

Minimum voltage of the curve in V. undef on error.

=item $u_max_V

Maximum voltage of the curve in V. undef on error.

=item $duration_ms

Duration of the curve in s, taking into account the given Repetitions. undef on error.

=back

B<Examples:>

    ($u_min_V, $u_max_V, $duration_ms) = TSG4_setCurveFile("test.sat");
    
B<Notes:> 

todo: enable ubat coupling.
# scan voltage values, set all below 4.2 V to 0 and configure trigger out on rc, configure event trigger on ubat

=cut

sub TSG4_setCurveFile {
    my $file = shift;
    my $duration_ms;
    my ( $u_max_V, $u_min_V );

    unless ( defined($file) ) {
        S_set_error( " SYNTAX: (status,duration) = TSG4_setCurveFile(file);", 110 );
        return ( undef, undef, undef );
    }

    unless ( -f $file ) {
        S_set_error( "Could not access $file", 1 );
        return ( undef, undef, undef );
    }

    S_w2log( 4, "TSG4_setCurveFile: Reading curve data from file '$file' and downloading to RC1...\n " );

    ( $status, $duration_ms, $u_min_V, $u_max_V ) = rc_set_voltage_file( 1, $file );
    if( $status < 0 ) {
        S_set_error( "Could not transmit curve from file '$file' to Rack Controller.", 1 );
        Check_status($status);
        return ( undef, undef, undef );
    }

    S_w2log( 4, "TSG4_setCurveFile: done \n" );
    return ( $u_min_V, $u_max_V, $duration_ms );
}

=head2 TSG4_stopCurve

    TSG4_stopCurve( );

stops running curve on internal power supply from rack CPU memory.

=cut

sub TSG4_stopCurve{

  	S_w2log(4,"TSG4_stopCurve() \n");

  	return 1 if $main::opt_offline;

  	$status = rc_stop_curve( 1 );
  	Check_status();
  	S_w2log(4,"TSG4_stopCurve done \n");
    return 1;
}

=head2 TSG4_runCurve

    TSG4_runCurve( );

run curve on internal power supply from rack CPU memory.

voltage will stay on last curve value after curve is over, to stop a running curve just call TSG4_SetVoltage.

=cut

sub TSG4_runCurve{

  	S_w2log(4,"TSG4_runCurve() \n");

  	return 1 if $main::opt_offline;

  	$status = rc_start_curve( 1 ,'now');
  	Check_status();
  	S_w2log(4,"TSG4_runCurve done \n");
    return 1;
}


=head2 TSG4_runCurveOnTrigger

    TSG4_runCurveOnTrigger( );

run curve on internal power supply from rack CPU memory, waiting for external trigger (event trigger)

voltage will stay on last curve value after curve is over, to stop a running curve just call TSG4_SetVoltage.

=cut

sub TSG4_runCurveOnTrigger{

  	S_w2log(4,"TSG4_runCurveOnTrigger() \n");

  	return 1 if $main::opt_offline;

  	$status = rc_start_curve( 1 ,'event');
  	Check_status();
  	S_w2log(4,"TSG4_runCurveOnTrigger done \n");
  	return 1;
}



=head2 TSG4_createRandomFile TBD

    TSG4_createRandomFile( $filename, $t_HImax, $t_HImin, $t_LOmax, $t_LOmin, $v_HImax, $v_HImin, $v_LOmax, $v_LOmin, $volt_step, $time_step, $maxDuration );

create random voltage file (switching between random voltage level for random time in given windows).

    time $t_HImax, $t_HImin, $t_LOmax, $t_LOmin in msec
    voltage $v_HImin, $v_LOmax, $v_LOmin in mV
    $maxDuration in seconds
    $volt_step = 50,100 mV
    $time_step = 10,20,50,80 ms


    e.g. TSG4_createRandomFile("test.sat", 2000, 100, 2000, 100, 15000, 5000, 0, 0, 100, 10, 60);

	time_step:           10
	volt_step:           100
	Filename:            C:\temp\test1.txt
	Points:              24
	Current Limitations: 4.00
	Repetitions:         1
	
	U[V]   t[s]
	 11.800  1.780
	  0.000  0.810
	 11.200  1.970
	  0.000  0.650
	  5.300  1.500


    e.g. TSG4_createRandomFile("test.sat", 2000, 100, 2000, 100, 15000, 10000, 7000, 5000, 100, 10, 60);

	time_step:           10
	volt_step:           100
	Filename:            C:\temp\test1.txt
	Points:              24
	Current Limitations: 4.00
	Repetitions:         1
	
	U[V]   t[s]
	 13.600  0.570
	  5.500  1.970
	 13.400  1.670
	  5.500  0.470
	 11.500  0.200
	  5.400  0.580
	 13.500  1.280

=cut

sub TSG4_createRandomFile{

  my $filename = shift;
  my $t_HImax = shift;
  my $t_HImin = shift;
  my $t_LOmax = shift;
  my $t_LOmin = shift;
  my $v_HImax = shift;
  my $v_HImin = shift;
  my $v_LOmax = shift;
  my $v_LOmin = shift;
  my $volt_step = shift;
  my $time_step = shift;
  my $maxDuration = shift;

  unless (defined($maxDuration) )
  {
    S_set_error( "SYNTAX: TSG4_createRandomFile(filename,T_HImax,T_HImin,T_LOmax,T_LOmin,V_HImax,V_HImin,V_LOmax,V_LOmin,volt_step,time_step,MAXduration)" , 109);
    return 1;
  }

  S_w2log(4,"TSG4_createRandomFile $filename\n  T_HI($t_HImin - $t_HImax) T_LO($t_LOmin - $t_LOmax) V_HI($v_HImin - $v_HImax) V_LO($v_LOmin - $v_LOmax) MAXduration $maxDuration\n");

  if ($main::opt_offline)
  {
    S_create_dummy_file($filename);
    return 1 ;
  }
  $status  = rc_createRandomFile($filename,$t_HImax, $t_HImin, $t_LOmax, $t_LOmin, $v_HImax, $v_HImin, $v_LOmax, $v_LOmin, $volt_step, $time_step,$maxDuration);
  Check_status();
  S_w2log(4,"TSG4_createRandomFile done \n");
    return 1;
}






=head1 non-DLL functions

these functions do not access the TSG4 dll

=head2 TSG4_get_names

  @names = TSG4_get_names( $section );

return names of TSG4 section defined in ProjectConst in ascending order

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings

    TSG4_get_names( 'BELT_LOCKS' ) will return ('BLRR','PADS')       

=cut

sub TSG4_get_names{
    my $section = shift;
    my (@names,@keys);
    my $mlc_count = 1;
    my $sectionExists = 0;
    my %values;

    @names=();
    unless (defined( $section )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_get_names( \$section )", 110 );
        return @names;
    }


        #old CFG format is used
       unless ( exists $main::ProjectDefaults->{'TSG4'}{$section} ) {
            S_set_error( "! wrong parameter ! section $section does not exist in ProjectConst", 109 );
            return @names;
        }
        %values = %{$main::ProjectDefaults->{'TSG4'}{$section}};

        #append the TSG4number with key for sorting purpose, in this case TSG4 number is 1
        foreach my $keyname(keys %values){
            $values{"1_" . $keyname} = $values{$keyname};
            delete $values{$keyname};
        }


    #collect keys with the pattern .*_Name (ex: 1_SW1_Name, 2_SW2_Name, 1_SW3_Name etc.)
    @keys= grep(/_Name$/ ,keys %values);

    # sorting taken from C:/Perl/html/lib/Pod/perlfunc.html sort LIST
    #sort based on the keys : for example, (1_SW1_Name, 2_SW2_Name, 1_SW3_Name) should be sorted to (1_SW1_Name , 1_SW3_Name , 2_SW2_Name ) and so on.
    #Consider the list containing elements (1_SW1_Name, 2_SW2_Name, 1_SW3_Name )
    #The sorting involves 3 steps
    #step-1: map { [$_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_)] } @keys;
    #       For each element in @keys, prepare a 4-element hash of form [SwitchName, TSG4Number, SwitchNumber, Uppercase of SwitchName] 
    #       for example[1_SW1_Name , 1, 1, 1_SW1_NAME], [2_SW2_Name ,2,  2, 2_SW2_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME])
    #
    #step-2: sort { $a->[1] <=> $b->[1]    ||     $a->[2] <=> $b->[2]      ||      $b->[3] cmp $a->[3]}
    #       Sort the array based on first, second and third element ([1_SW1_Name , 1,  1, SW1_NAME], [1_SW3_Name , 1, 3, 1_SW3_NAME], [2_SW2_Name , 2, 2, SW2_NAME])
    #
    #step-3: map { $_->[0] }
    #       Assign the first element to the resulting variable(1_SW1_Name,1_SW3_Name,2_SW2_Name)
    #
    #Hence the elements are sorted
    #
    @keys = map { $_->[0] }
           sort { $a->[1] <=> $b->[1]
                           ||
                  $a->[2] <=> $b->[2]
                           ||
                  $b->[3] cmp $a->[3]
       } map { [$_, /^(\d+)_.*$/, /(\d+)_Name$/, uc($_)] } @keys;

    foreach (@keys){
            push( @names,$values{$_});
    }

    S_w2log(4,"TSG4_get_names( $section ) = @names\n");
    return(@names);

}



=head2 TSG4_get_CANid

  $CANid = TSG4_get_CANid( $label );

  e.g. 0x104 = TSG4_get_CANid( 'AB1FP' );
  
  will ignore trailing sign (+-) 

return $CANid (to send request to device)

Refer L</"SYNOPSIS"> for ProjectConst and Testbench configuration settings


=cut

sub TSG4_get_CANid{
    my $label = shift;
    my $canId;
    unless (defined( $label )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_get_CANid( \$label )", 110 );
        return 0;
    }

    $label =~ s/[+-]$//; # drop sign

    S_w2log(4, "TSG4_get_CANid: Get CAN ID for device '$label'\n");


    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    S_w2log(4, "TSG4_get_CANid: Type ('$label') $type\n");
    my $number = $TSG4_labels->{$label}{"number"};
    my @number_sections = split('_', $number); #e.g. for PAS, number will be '1_1'
    $number = $number_sections[0]; # extract first part of number, which corresponds to PAS card
    S_w2log(4, "TSG4_get_CANid: Number ('$label') $number\n");

    unless (defined $type and defined $number){
    	S_set_error( "! wrong parameter ! TSG4_get_CANid could not resolve label $label", 109 ); return 0;
    }

    my $deviceType = $section_mapping{$type};
    unless(defined $deviceType){
        S_set_error("Can't fine device type for '$label' in section mapping. (Section: '$type')");
        return 0;
    }
    ($status,$canId) = tsg4_get_device_CANid($section_mapping{$type},$number);
    S_w2log(4, "TSG4_get_CANid: Status $status, CAN ID $canId\n");
    Check_status($status, $label);
    return $canId;
}


=head1 special usage functions

=head2 TSG4_lowlevel_command

    @return_values = TSG4_lowlevel_command( $lowlevel_command_string [, $warn_on_error]);
    e.g. $status = TSG4_lowlevel_command( 'tr_connect_DUT()' );

this function is used to give a generic wrapper for all tsg4 low level commands (waits internally for 5 ms). It will return all return vaules like low level command. 
if status is < 0 S_set_error will be called.
if $warn_on_error is defined, S_set_error will only give a warning.

=cut

sub TSG4_lowlevel_command{
    my $command = shift;
    my $errorwarn = shift;
    my $errorcode = 0; # warning
    unless (defined( $command )) {
        S_set_error( "! too less parameters ! SYNTAX: TSG4_lowlevel_command( \$lowlevel_command_string )", 110 );
        return 0;
    }
    unless (defined( $errorwarn )) {
        $errorcode = 5; # external error
    }

	return 1 if $main::opt_offline;

    my $response;
    my @result = eval($command);

    $Data::Dumper::Indent = 0; # all in one line
    $Data::Dumper::Sortkeys = 1;

    if (defined ($result[0])) {
        if ($result[0] < 0){
        	my $errortext = tsg4_get_error($status);
            S_set_error( "! status ($result[0]) < 0 for TSG4_lowlevel_command('$command') \n$errortext", $errorcode );
        }
        foreach my $val (@result){
            my $out = Dumper($val);
            $out =~ s/^\$VAR1 = //;
            $out =~ s/;$//;
            $response.="$out,";
        }
        $response =~ s/,$//; # cut off trailing comma
        S_w2log(4,"TSG4_lowlevel_command( '$command' ) returned '$response'\n");

    }
    else {S_set_error( "! wrong parameter ! unknown command '$command'", 109 );return 0;}

    select(undef, undef, undef, 0.005);   #sleep for 5 ms

    return @result;
}


=head2 TSG4_lowlevel_init

    TSG4_lowlevel_init();

initialize TSG4 hardware. Can be used instead TSG4_InitHW for development purpose.

Refer L</"SYNOPSIS"> for Testbench configuration settings

=cut

sub TSG4_lowlevel_init{
    my ( $canChannel, $serialNo );

    if ( $TSG4_initialized ) {
        S_set_warning( "TSG4 already initialized");
        return 1;
    }

    S_w2log(1,"TSG4_lowlevel_init \n");

    $status = tsg4_start( );
    Check_status($status);
    $TSG4_initialized = 1;
    %Ref_use=();
    #get values from testbenchconfig
    $canChannel = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"CANchannel"} ;
    $serialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"CANHWSerialNo"} ;
    $UF_supply = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"POWER"}{'UF'} ;
    $Ubat_supply = $LIFT_config::LIFT_Testbench->{'Devices'}{'TSG4'}{"POWER"}{'Ubat'} ;

    unless (defined $canChannel) {S_set_error( "CANchannel not defined in testbenchconfig TSG4" , 20);return;}
    unless (defined $serialNo) {S_set_warning( "SerialNo not defined in testbenchconfig TSG4");} # only warning
    unless (defined $Ubat_supply) {S_set_error( "POWER-Ubat not defined in testbenchconfig TSG4" , 20);return;}
    unless (defined $UF_supply) {S_set_warning( "POWER-UF not defined in testbenchconfig TSG4");} # only warning

    TSG4_ReadLabels();

    if ($main::opt_offline){
        $TSG4_initialized = 1;
        return 1;
    }

	return unless ( CAN_HWcheck($canChannel, \$serialNo) );

    $status = tsg4_init( $canChannel,  $serialNo );
    Check_status($status);
    S_w2log(4,"TSG4 init status=$status ch=$canChannel SN=$serialNo\n");

     if ($status < 0){
        S_set_error( "could not initialize TSG4" , 5);
        $TSG4_initialized = 0;
    }

    return 1;
}



=head1 not exported functions


=head2 TSG4_ReadLabels not exported

    TSG4_ReadLabels( );

(re-)read TSG4 labels from ProjectConst to data structure


=cut

sub TSG4_ReadLabels{

    $TSG4_labels=undef;

# name -> section = ...  
# name -> default = ... 
# name -> unit = ... 
# name -> number = ... 
# name -> states -> state = ... 

    foreach my $section (sort keys %{$main::ProjectDefaults->{'TSG4'}}){

        my %device_prj_name_no; # hash to store number->label assignment for second run

        foreach my $key (sort keys %{$main::ProjectDefaults->{'TSG4'}->{$section}}){
            next unless ($key =~ /([_\d]+)_Name$/);
            my $number = $1;
            $number=~s/^_//; # cut off leading underline

            my $name_label = $key;        
            my $device_prj_name = $main::ProjectDefaults->{'TSG4'}->{$section}->{$name_label};
            S_w2log(4, "TSG4_ReadLabels: Section $section, name label $name_label, label number $number, device prj name $device_prj_name \n");

            #check if key is unique
            if(exists $TSG4_labels->{$device_prj_name}){
                S_set_error("Redundant name '$device_prj_name' in $section", 20 );
                return 0;
            }
            #add under 'Names' group
            $TSG4_labels->{$device_prj_name}{"section"} = $section;
            $TSG4_labels->{$device_prj_name}{"number"} = $number;
            # store name for second pass
            $device_prj_name_no{$number}=$device_prj_name;
            
            next unless($section_mapping{$section});
            
			# Add CAN ID of all TSG4 devices to CAN mapping
                ### $device_prj_name is the device label
                # add device to CAN mapping
#                        'ID'            => 7,
#                        'DLC'           => 8,
#                        'SENDER'        => 'TSG4',
#                        'CAN_BUS_NBR'   => 2,
            my $canID = TSG4_get_CANid_noerror($device_prj_name); #  calling with _noerror to avoid errors for only building up the CAN mapping
            unless($canID){
                S_set_warning("TSG4_ReadLabels: could not add CAN message for device '$device_prj_name' to CAN mapping");
                next;
            }
            $main::ProjectDefaults->{'Mapping_CAN'}->{'CAN_MESSAGES'}->{'LC__'.$device_prj_name} = {
                'ID' => $canID,
                'DLC' => 8,
                'SENDER' => 'CONTROL_PC',
                'CAN_BUS_NBR' => 2, # replace with constant or value from LIFT_Testbeches?
            };
            $main::ProjectDefaults->{'Mapping_CAN'}->{'CAN_MESSAGES'}->{'LC__'.$device_prj_name.'_response'} = {
                'ID' => $canID + 1,
                'DLC' => 8,
                'SENDER' => 'TSG4',
                'CAN_BUS_NBR' => 2, # replace with constant or value from LIFT_Testbeches?
            };

        }


        # second run to assign default, unit, type and states
        foreach my $key (sort keys %{$main::ProjectDefaults->{'TSG4'}->{$section}}){
            my $temp = $main::ProjectDefaults->{'TSG4'}->{$section}->{$key};

            if ($key =~ /([_\d]+)_Default$/){
                my $number = $1;
                $number=~s/^_//; # cut off leading underline

                #get name from first pass
                $TSG4_labels->{$device_prj_name_no{$number}}{"default"} = $temp;

            }
            elsif ($key =~ /(\d+)_Unit$/){
                my $number = $1;

	# chek for valid unit

                #get name from first pass
                $TSG4_labels->{$device_prj_name_no{$number}}{"unit"} = $temp;

            }
            elsif ($key =~ /(\d+)_Type$/){
                my $number = $1;

		    	my $type = $type_mapping{ $temp };
			    unless (defined $type){
			        my @validValues = sort keys %type_mapping;
			        S_set_error( "In TSG4 mapping in section '$section': For key '$key' the given value '$temp' is not valid. Valid values are: @validValues", 114 );
                    return 0;
			    }

                #get name from first pass
                $TSG4_labels->{$device_prj_name_no{$number}}{"type"} = $type;

            }
            elsif ($key =~ /(\d+)_state_(.+)$/){
                my $number = $1;
                my $state = $2;

                #get name from first pass
                $TSG4_labels->{$device_prj_name_no{$number}}{"states"}{$state} = $temp;

            }
            elsif ($key =~ /(\d+)_output$/){
                my $number = $1;

                #get output from first pass
                $TSG4_labels->{$device_prj_name_no{$number}}{"output"}= $temp;

            }

        }

    }

    return 1;
}

=head2 Undo_short_line not exported

    $status = Undo_short_line($line,$via_target);

remove short for a single line

=cut

sub Undo_short_line {
    my $line = shift;
    my $via_target = shift;

    my $label=$line;
    my $sign = chop($label); # remove sign from $label and store in $sign
    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

     unless ( defined $type ) {
        S_set_error( "Undo_short_line '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    unless (exists $Ref_use{$line}){
        S_set_error("$line not connected to VIA $Ref_use{$line}",5);
        return 0;
    }
    else{
        delete $Ref_use{$line};
    }

    if($type eq 'BELT_LOCKS'){
        $status = bl_disconnect_via($number,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_disconnect_via($number,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_disconnect_via($wlCard,$wlNum,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_disconnect_via($pasBank,$pasNum,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'CAN_FR'){
        my $pin;
        if ($sign eq '+'){
        	$pin = 'H';
        }
        else{
        	$pin = 'L';
        }
        $status = cf_disconnect_via($number,$pin,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'K_LIN'){
    	my $type = $TSG4_labels->{$label}{"type"};
    	$status = kl_disconnect_via($number,$type,$via_target);
        Check_status($status,$line);
    }
    else{
        S_set_error( "Undo_short_line only implemented for 'WARNING_LAMPS', 'BELT_LOCKS', 'SQUIBS', 'CAN_FR', 'K_LIN' and 'PAS_LINES'");
        return 0;
    }
    return 1;
}


=head2 Short_line not exported

    $status = Short_line($line,$via_target);

short a single line

=cut

sub Short_line {
    my $line = shift;
    my $via_target = shift;

    my $label=$line;
    my $sign = chop($label); # remove sign from $label and store in $sign
    #Get Type of device for $label
    my $type = $TSG4_labels->{$label}{"section"};
    my $number = $TSG4_labels->{$label}{"number"};

     unless ( defined $type ) {
        S_set_error( "Short_line '$label' unknown (please check TSG4 mapping in Project Const)" , 109);
        return 0;
    }
    if (exists $Ref_use{$line}){
        S_set_error("$line already connected to VIA $Ref_use{$line}", 5);
        return 0;
    }
    else{
        $Ref_use{$line}=$via_target;
    }

    if($type eq 'BELT_LOCKS'){
        $status = bl_connect_via($number,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'SQUIBS'){
        $status = sq_connect_via($number,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'WARNING_LAMPS'){
		my($wlCard,$wlNum) = split(/_/,$number);
        $status = wl_connect_via($wlCard,$wlNum,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'PAS_LINES'){
        my($pasBank,$pasNum) = split(/_/,$number);
        $status = pas_connect_via($pasBank,$pasNum,$sign,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'CAN_FR'){
        my $pin;
        if ($sign eq '+'){
        	$pin = 'H';
        }
        else{
        	$pin = 'L';
        }
        $status = cf_connect_via($number,$pin,$via_target);
        Check_status($status,$line);
    }
    elsif($type eq 'K_LIN'){
    	my $type = $TSG4_labels->{$label}{"type"};
    	$status = kl_connect_via($number,$type,$via_target);
        Check_status($status,$line);
    }
    else{
        S_set_error( "Short_line only implemented for 'WARNING_LAMPS', 'BELT_LOCKS', 'SQUIBS', 'CAN_FR', 'K_LIN' and 'PAS_LINES'");
        return 0;
    }
    return 1;
}

=head2 TSG4_TRC_map

 ($trcNumber, $trcChannel) = TSG4_TRC_map($trc)


=cut

sub TSG4_TRC_map{
	my $trc= shift;
	my $trcNumber;
	my $trcChannel;

	if ($trc%8 == 0){
		$trcNumber = $trc/8;
		$trcChannel =8;
	}
	else{
		$trcNumber = int($trc/8)+1;
		$trcChannel = $trc%8;
	}

	return ($trcNumber, $trcChannel);
}


=head2 Check_status

 Check_status($result,$addon_text)

if result < 0, log error string and set INCONC.

=cut


sub Check_status{
    my $stat = shift;
    my $text = shift;

	my $sub = (caller(1))[3];
	$sub = 'unknown_API' unless (defined $sub);

    return 1 if $main::opt_offline;
    if ($stat<0){
        my $errortext = tsg4_get_error($stat);
        my $hint = '';
        if( $errortext =~ /Timeout\sError/ ) {
            $hint = <<'END_HINT';
CAN Timeout Error !!!
Please make sure the following points are fulfilled to avoid this error:
1) The CAN connection between Vector hardware and TSG4 is terminated with 120 Ohm on both ends.
2) The CANoe rest bus simulation is not using the same physical channel as TSG4.
3) The TSG4 mapping matches to the cards that are actually present in the TSG4 in the correct slot. 
4) Sometimes it helps just to reset the Vector box (unplug both power and USB cable of the vector box for a while).
END_HINT
        }
        S_set_error( "TSG4 error occurred for $sub [$text]: $hint\n$errortext" , 5);
        return 0;
    }
	return 1;
}


=head2 Check_firmware

 $true_false = Check_firmware($card_firmware,$latest_firmware)

returns 1 if newer firmware available, otherwise 0.

=cut


sub Check_firmware{
    my $card_firmware = shift;
    my $latest_firmware = shift;
    return 0 unless (defined $latest_firmware);

	$card_firmware =~ /^(FW_[A-Z])(\d+)$/;
	my $card_type = $1;
	my $card_nr = $2;

	$latest_firmware =~ /^(FW_[A-Z])(\d+)$/;
	my $latest_type = $1;
	my $latest_nr = $2;

    if ($card_type ne $latest_type){
      my $errortext = tsg4_get_error($status);
      S_set_error( "TSG4 error occured for Check_firmware:\ncard type mismatch ($card_type ne $latest_type)" , 5);
      return 0;
    }

    return 1 if ($latest_nr > $card_nr);
	return 0;
}


=head2 Check_TSG4_supports_reset

 $true_false = Check_TSG4_supports_reset($devices2check_href);

returns 1 if all firmwares supoort reset, otherwise 0.

=cut


sub Check_TSG4_reset_possible{
    my $devices2check = shift;
    return 0 unless (defined $devices2check);
    my ($card_firmware,$do_reset);

	my %reset_supported=(
		'REF'   => '0004', # B
		'CANFR' => '0003', # C
		'DVM'   => '0005', # D
		'BL'    => '0006', # G
		'KLIN'  => '0004', # K
		'WL'    => '0008', # L
		'PAS'   => '0006', # P
		'TRC'   => '0005', # T
		'UBAT'  => '0007', # U
		'RC'    => '0017', # X
		'SQ'    => '0006', # Z
	);

	$do_reset = 1;

	#loop over all devices
	foreach my $device (sort keys %reset_supported){
		#loop over all slots of all devices
		foreach my $number (sort keys %{$devices2check->{$device}}){
			$card_firmware = $devices2check->{$device}{$number}{SW};
			$card_firmware =~ s/FW_[A-Z]//;
			# check if each device firmware supports TSG4 reset
			if ($card_firmware < $reset_supported{$device}){
				$do_reset = 0;
				S_w2log(5,"firmware $device $number does not support TSG4 reset\n");
			}
		}
	}

	return $do_reset;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut
 
