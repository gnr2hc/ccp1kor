# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2014  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package tsg4_rc;

use strict;
use warnings;
use tsg4;
use TSG4CAN;
use File::Basename;
use GD::Graph::lines;
use LIFT_simulation;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    rc_bootloader_mode
    rc_configure_event_trigger
    rc_configure_event_trigger_delay
    rc_display_text
    rc_enable_event_trigger
    rc_enable_PWM
    rc_get_firmware
    rc_get_HW_id
    rc_get_INFO
    rc_get_status
    rc_get_temperature
    rc_lock_display
    rc_read_RFID_info
    rc_read_RFID_page
    rc_send_commad
    rc_send_commad_wait_response
	rc_send_bytes_wait_response
    rc_set_12V_normal
    rc_set_12V_standby
    rc_set_voltage
	rc_set_voltage_curve
	rc_set_voltage_file
	rc_ubat_coupling
	rc_stop_curve
	rc_start_curve
    rc_unlock_display
    rc_write_CAL
    rc_write_EE
    rc_write_RFID_page
    rc_write_RFID_text
    rc_write_SN
    rc_write_TST
    rc_read_RFID_text
    rc_read_RFID_pinout
	rc_createRandomFile
	rc_create_graph
	rc_write_RFID_transponder_type
	rc_set_SIM_return_text

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus);


my $curve_running = 0;

############################################################################################################

=head1 DESCRIPTION

Rack Controller module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

=cut

=head1 RC INDEPENDANT METHODS (exported)

=head2 rc_createRandomFile

 $status = rc_createRandomFile($filename,$T_HImax,$T_HImin,$T_LOmax,$T_LOmin,$V_HImax,$V_HImin,$V_LOmax,$V_LOmin,$volt_step,$time_step,$MAXduration);

create random voltage file (switching between random voltage level for random time in given windows). 

	time: $T_HImax,$T_HImin,$T_LOmax,$T_LOmin in msec
	voltage: $V_HImax,$V_HImin,$V_LOmax,$V_LOmin in mV
	$MAXduration in seconds.
	$volt_step = 50,100 mV
	$time_step = 10,20,50,80 ms

	
    e.g. rc_createRandomFile("test.sat", 2000, 100, 2000, 100, 15000, 5000, 0, 0, 100, 10, 60);

	time_step:           10
	volt_step:           100
	Filename:            C:\temp\test1.txt
	Points:              24
	Current Limitations: 4.00
	Repetitions:         1
	
	U[V]   t[s]
	 11.800  1.780
	  0.000  0.810
	 11.200  1.970
	  0.000  0.650
	  5.300  1.500
  
Returns:    

            status:  Success: 0,         Error: Error Code < 0.     

=cut

sub rc_createRandomFile{

  my $filename = shift;
  my $T_HImax = shift; 
  my $T_HImin = shift; 
  my $T_LOmax = shift;
  my $T_LOmin = shift;  
  my $V_HImax = shift;
  my $V_HImin = shift;
  my $V_LOmax = shift;
  my $V_LOmin = shift;
  my $volt_step = shift; 
  my $time_step = shift; 
  my $MAXduration = shift; 
  my $errorCode;

  #parameter check, only last parameter
  unless( defined($MAXduration) )
  {
      $errorCode = -19;
      return $errorCode;
  }

  my $save_dir = dirname($filename);

  unless (-d $save_dir ){

    unless( mkdir( $save_dir ) ) {
        $errorCode = -10;
        return $errorCode;
    }
  }

  #avoid division of a not defined value
  if ($T_HImax%$time_step + $T_HImin%$time_step + $T_LOmax%$time_step + $T_LOmin%$time_step + $V_HImax%$volt_step + $V_HImin%$volt_step + $V_LOmax%$volt_step + $V_LOmin%$volt_step > 0){
#	print"!!! min/max value(s) do not match time_step or volt_step\n";
	return -100;
  }

  $T_HImax = $T_HImax/$time_step;
  $T_HImin = $T_HImin/$time_step;
  $T_LOmax =$T_LOmax/$time_step;
  $T_LOmin =$T_LOmin/$time_step;
  $V_HImax = $V_HImax/$volt_step;
  $V_HImin = $V_HImin/$volt_step;
  $V_LOmax = $V_LOmax/$volt_step;
  $V_LOmin = $V_LOmin/$volt_step;

  my ($points, $duration,$hiTime,$loTime,$hiVolts,$loVolts);
  my @filecontent=("\n","U[V]   t[s]\n");

#  print "rc_createRandomFile($filename,$T_HImax, $T_HImin, $T_LOmax, $T_LOmin, $V_HImax, $V_HImin, $V_LOmax, $V_LOmin,$volt_step,$time_step,$MAXduration)";
  $duration = 0;
  $points = 0;

  while ($duration<$MAXduration and $points <= 1000){

    $hiTime = (int(rand($T_HImax-$T_HImin))+$T_HImin)*$time_step/1000;
    $loTime = (int(rand($T_LOmax-$T_LOmin))+$T_LOmin)*$time_step/1000;
    $hiVolts = (int(rand($V_HImax-$V_HImin))+$V_HImin)*$volt_step/1000;
    $loVolts = (int(rand($V_LOmax-$V_LOmin))+$V_LOmin)*$volt_step/1000;

    $hiTime = sprintf("%6.3f", $hiTime);
    $loTime = sprintf("%6.3f", $loTime);
    $hiVolts = sprintf("%6.3f", $hiVolts);
    $loVolts = sprintf("%6.3f", $loVolts);

    push(@filecontent," $hiVolts $hiTime\n");
    push(@filecontent," $loVolts $loTime\n");
    $points+=2;
    $duration+=$hiTime+$loTime;
  }

  # put on top of file
  unshift(@filecontent,"Repetitions:         1\n");
  unshift(@filecontent,"Current Limitations: 4.00\n");
  unshift(@filecontent,"Points:              $points\n");
  unshift(@filecontent,"Filename:            $filename\n");
  unshift(@filecontent,"volt_step:           $volt_step\n");
  unshift(@filecontent,"time_step:           $time_step\n");

  #avoid error by open File
  if(open (FILE,">$filename") )
  {
    print FILE @filecontent;
    close (FILE);
  }
  else {
    $errorCode = -1;
    return $errorCode;
  }

  # create file but return with error if 1000 points are exceeded
  if($points>1000){
      $errorCode = -2;
      return $errorCode;
  }

  return 0;

}

=head2 rc_create_graph

	($status,$picfile) = rc_create_graph($filename, [$undervoltage, $overvoltage]);

create a graph from curve file with the same filename. if > 0 under and overvoltage thresholds will be added to graph. 
Will save picture as *.png and UNIVIEW file as *.txt.unv

Returns:    

            1. status:      Success: 0,                                 Error: Error Code< 0.             
            2. picfile:     Success: File name of the created file,     Error: empty.

    e.g.
    ($status,$picfile) = createGraph("test.txt");      # no thresholds 
    ($status,$picfile) = createGraph("test.txt",5);    # only undervoltage
    ($status,$picfile) = createGraph("test.txt",0,10); # only overvoltage

=cut

sub rc_create_graph{

  my $file=shift;
  my $undervoltage = shift;
  my $overvoltage = shift;
  my (@volts,@time,$uvID,$ovID);
  my @legend_keys = ("battery voltage");
  my $errorCode;
  my $locFileHelper = $file;

  #parameter check, only last parameter
  unless( defined($file) )
  {
    $errorCode = -20;
    return ($errorCode,"");
  }

  unless (-f $file)
  {
    $errorCode = -1;
    return ($errorCode, "");
  }

  @volts=@time=();

  if( open(my $in,"<","$file") )
  {
  	my @lines = <$in>;
  	close($in);
      foreach my $line (@lines){
        if ($line =~ /^\s*([\d.]+)\s+([\d.]+)/){
          push(@volts,$1);
          push(@time,$2);
        }
      }
  }
  else {
     $errorCode = -1;
     return ($errorCode, "");
  }


  #create graph
  $file =~ s/\.\w+$//; # cut off file extension
  $file =~ s/\//\\/g; # replace all slashes with backslashes

  #delete file if existing
  unlink("$file.txt.unv");

  my ($i, $graph,  @data, $current_time);
  my ($val, $dt, $last_time);
  my $step = 0.001;
  @data=();

  $last_time = $current_time=0;

  #set undervoltage and overvoltage if not defined
  $undervoltage = 0 unless (defined $undervoltage);
  $overvoltage = 0 unless (defined $overvoltage);

  if ($undervoltage > 0){$uvID=2;} else {$uvID=1;}
  if ($overvoltage > 0){$ovID=$uvID+1;} else {$ovID=1;}

  #avoid Error by empty file
  if(@time != 0)
  {
      # loop over all points
      for ($i=0; $i<@time; $i++){
        $val = $volts[$i];
        $dt = $time[$i];
        while ($current_time < ($last_time+$dt)){
            push (@{$data[0]},$current_time);
            push (@{$data[1]},$val);
            if ($undervoltage > 0){push (@{$data[$uvID]},$undervoltage);}
            if ($overvoltage > 0){push (@{$data[$ovID]},$overvoltage);}
            $current_time+=$step;
        }
        push (@{$data[0]},$current_time);
        push (@{$data[1]},$val);
        if ($undervoltage > 0){push (@{$data[$uvID]},$undervoltage);}
        if ($overvoltage > 0){push (@{$data[$ovID]},$overvoltage);}
        $last_time = $current_time;
        $current_time+=$step;

      } #END for
  }
  else {
    $errorCode = -11;
    return ($errorCode,"");
  }
  $graph = GD::Graph::lines->new(800, 600);

  $graph->set(
          x_label           => "time in s",
          y_label           => "voltage in V",
          title             => 'waveform',
          x_tick_number     => 'auto',
          r_margin          => 10,
          l_margin          => 10,
          b_margin          => 10,
  );


  $graph->set_legend_font(GD::Font->Large);
  if ($undervoltage > 0){push(@legend_keys,"undervoltage");}
  if ($overvoltage > 0){push(@legend_keys,"overvoltage");}

  $graph->set_legend(@legend_keys);

  if(open ( OUT,">$file".".txt.unv" ))
  {
    print OUT "TIME;VOLTAGE;\n";
    print OUT "s;volt;\n";
    $current_time=0;
    for ($i=0; $i<@time; $i++){
      $current_time+=$time[$i];
      print OUT "$current_time;$volts[$i];\n";
    }
    close (OUT);
  }
  else {
    $errorCode = -1;
    return ($errorCode,"");
  }

  if(open ( my $pic,">","$file.png" ))
  {
    binmode $pic;
    print $pic $graph->plot(\@data)->png;
    close ($pic);
    return(0,"$file.png");
  }
  else {
    $errorCode = -1;
    return ($errorCode,"");
  }


}

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

=head2 rc_get_firmware

    ($status, $firmware) = rc_get_firmware($rcNumber);

    e.g. (0,'Ver 1.0') = rc_get_firmware(1);

reads firmware version from rack controller

returns status.

=cut

sub rc_get_firmware {
    my $rcNumber = shift;
    my $fw;

    ($status,$fw) = rc_send_commad_wait_response($rcNumber,'?10');
#    print("firmware $fw\n");

    return ($status,$fw);

}


=head2  rc_get_HW_id

    ($status, $HW_ID) =  rc_get_HW_id($rcNumber);

    e.g. (0,'999X0042') =  rc_get_HW_id(3);

reads hardware ID from rack controller

returns status.

=cut

sub  rc_get_HW_id {
    my $rcNumber = shift;
    my $hwID;

    ($status,$hwID) =  rc_get_INFO($rcNumber,'SN');
#    print("HW ID $hwID\n");

    return ($status,$hwID);

}

=head2  rc_get_INFO

    ($status, $INFO) =  rc_get_INFO($rcNumber,$keyword);

    e.g. (0,'999X0042') =  rc_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from rack controller

returns status.

=cut

sub  rc_get_INFO {
    my $rcNumber = shift;
    my $keyword = shift;
    my $info;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$info) =  rc_send_commad_wait_response($rcNumber,$command);
#    print("INFO ($keyword) $info\n");

    return ($status,$info);

}


=head2 rc_get_temperature

    ($status, $temperature) = rc_get_temperature($rcNumber);

    e.g. (0,'24.5') = rc_get_temperature(1);

reads temperature sensor value from rack controller card

returns status.

=cut

sub rc_get_temperature {
    my $rcNumber = shift;
    my $value;

    ($status,$value) = rc_send_commad_wait_response($rcNumber,'?14','RAW');
    #print("temperature @$value\n");
    # Byte 0, Byte 1 Temperature in 0.5� resolution signed Integer 
    my $temperature=unpack("s*",pack("i*",$$value[0].$$value[1])) /2;
#    print("temperature $temperature degree celsius\n");

    return ($status,$temperature);

}

=head2 rc_get_status

    ($status, $fuses,$cFaults,$uFaults) = rc_get_status($rcNumber);

    e.g. (0,'0000','00000000','00000000') = rc_get_status(1);

reads fault states and fuse states from rack controller card

returns status.

=cut

sub rc_get_status {
    my $rcNumber = shift;
    my $value;
    my ($fuses,$cFaults,$uFaults);

    ($status,$value) = rc_send_commad_wait_response($rcNumber,'?15','RAW');
    if ($status == 0){
#    print("states: @$value\n");
    $fuses = sprintf("%04b",$$value[5]);
    $cFaults = sprintf("%08b",$$value[1]);
    $uFaults = sprintf("%08b",$$value[3]);
#    print("fuses: $fuses ($$value[5])\n");
    }
    else{$fuses=$cFaults=$uFaults=0};

    return ($status,$fuses,$cFaults,$uFaults);

}


=head2 rc_read_RFID_info

    ($status, $tagUID, $readerSN, $readerSW, $readerType) = rc_read_RFID_info($rcNumber);

    e.g. (0,'09DAAF28','044E','TRMIVH22','Sys  OK5') = rc_read_RFID_info(1);

reads tag UID and reader serial number, software + type from rack controller card

returns status.

=cut

sub rc_read_RFID_info {
    my $rcNumber = shift;
    my ($value,$tagUID,$readerSN,$readerType,$readerSW);

    tsg4_wait_ms(10);
    ($status,$readerSN) = rc_send_commad_wait_response($rcNumber,'T?S');
#    print("Reader serial: $readerSN\n");
    tsg4_wait_ms(10);
    ($status,$readerType) = rc_send_commad_wait_response($rcNumber,'T?T');
#    print("Reader type: $Type\n");
    tsg4_wait_ms(10);
    ($status,$readerSW) = rc_send_commad_wait_response($rcNumber,'T?V');
#    print("Reader SW: $SW\n");
    tsg4_wait_ms(10);
    ($status,$tagUID) = rc_send_commad_wait_response($rcNumber,'T?U');
#    print("tag UID: $tagUID\n");

    return ($status,$tagUID,$readerSN,$readerSW,$readerType);

}


=head2 rc_read_RFID_text

    ($status,$text,$cust,$gen,$class,$harnessSN,$ver,$sample,$man,$tagUID) = rc_read_RFID_text($rcNumber);

    e.g. (0,'AUDI MLB','Audi','AB10','MLBevo','001Q0001','1.0','C1','01/2013','09DAA324') = rc_read_RFID_text(1);

reads harness information from RFID tag of harness

returns status and answer strings for $text,$cust,$gen,$class,$harnessSN,$ver,$sample,$time,$tagUID

$text      - ASCII Text viewed on LCD Display 
$cust      - Harness Customer
$gen       - Harness Airbaggeneration
$class     - Harness Vehicle/class
$harnessSN - Harness Serial Number
$ver       - Harness Version
$sample    - Sample Phase
$man       - Manufacturing Date
$tagUID    - RFID tag ID

=cut

sub rc_read_RFID_text {
    my $rcNumber = shift;
    my ($data);
    my ($text,$cust,$gen,$class,$harnessSN,$ver,$sample,$man,$tagUID);

   ($status,$tagUID) = rc_send_commad_wait_response($rcNumber,'T?U');
   ($status, $data) = rc_read_RFID_page($rcNumber, 3);
   $text = aref2text($data);
   $text =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 4);
   $cust = aref2text($data);
   $cust =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 5);
   $gen = aref2text($data);
   $gen =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 6);
   $class = aref2text($data);
   $class =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 7);
   $harnessSN = aref2text($data);
   $harnessSN =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 8);
   $ver = aref2text($data);
   $ver =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 9);
   $sample = aref2text($data);
   $sample =~ s/\s+$//; # cut off trailing blanks
   ($status, $data) = rc_read_RFID_page($rcNumber, 10);
   $man = aref2text($data);
   $man =~ s/\s+$//; # cut off trailing blanks

   return ($status,$text,$cust,$gen,$class,$harnessSN,$ver,$sample,$man,$tagUID);

}



=head2 rc_read_RFID_pinout

    ($status, $pinout_href) = rc_read_RFID_pinout($rcNumber);

    e.g. (0, $pinout_href) = rc_read_RFID_pinout(1);
    e.g. $pinout_href = { 
        RC => [1,0,1,0,0],
        BL => [0,0,0,0,1,1,1,1,],
        CANFR => [1,1,0,0],
        KLIN => [0,0,1,0],
        PAS => [1,1],
        SQ => [1,1,1,1,1,1,1,1],
        UBAT => [1,0,1,0],
        WL => [1,0,0,1],
    }

reads pinout information from RFID tag of harness

returns status and bit list of connected pins e.g. WL [4] == 1 -> Warning Lamp 3 is connected in harness



=cut

sub rc_read_RFID_pinout {
    my $rcNumber = shift;
    my ($data,$pinout_href,@bits);

   ($status, $data) = rc_read_RFID_page($rcNumber, 11);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'RC'}=[splice(@bits,8,5)]; # do last part first because of resizing
   $pinout_href->{'UBAT'}=[splice(@bits,0,4)];
   ($status, $data) = rc_read_RFID_page($rcNumber, 12);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'KLIN'}=[splice(@bits,16,10)]; # do last part first because of resizing
   $pinout_href->{'CANFR'}=[splice(@bits,0,10)];
   ($status, $data) = rc_read_RFID_page($rcNumber, 13);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'WL'}=[splice(@bits,0,24)];
   ($status, $data) = rc_read_RFID_page($rcNumber, 14);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'BL'}=[splice(@bits,0,54)];
   ($status, $data) = rc_read_RFID_page($rcNumber, 15);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'PAS'}=[splice(@bits,0,54)];
   ($status, $data) = rc_read_RFID_page($rcNumber, 16);
   @bits = split(//,aref2bin($data));
   $pinout_href->{'SQ'}=[splice(@bits,0,64)];

   return ($status,$pinout_href);
}


=head2 rc_read_RFID_page

    ($status, $data_ref) = rc_read_RFID_page($rcNumber, $page);

    e.g. (0,'00000000') = rc_read_RFID_page(1, 3);

reads page from RFID tag of harness

returns status and answer string as RAW

=cut

sub rc_read_RFID_page {
    my $rcNumber = shift;
    my $page = shift;
    my $value;

    my $command = sprintf("TDR%02X",$page);
    ($status,$value) = rc_send_commad_wait_response($rcNumber,$command,'RAW');
    return ($status,$value);

}


=head2 rc_write_RFID_page

    ($status) = rc_write_RFID_page($rcNumber, $page, $data);

    e.g. (0) = rc_write_RFID_page(1, 3, "12345678");

writes page to RFID tag of harness

$data as ASCII

returns status.

=cut

sub rc_write_RFID_page {
    my $rcNumber = shift;
    my $page = shift;
    my $data = shift;
    my $value;
    my ($response,$receive_ID);

    my $command = sprintf("TDW%02X",$page);
    ($status,$response,$receive_ID) = rc_send_commad_wait_response($rcNumber,$command);

#    printf( "-> 0x%02x $data\n",$receive_ID-1);

    my @bytes = split(//, $data);
	($status,$response) = rc_send_bytes_wait_response($rcNumber,\@bytes);

    return ($status);

}

=head2 rc_write_RFID_text

    ($status,$tagUID) = rc_write_RFID_text($rcNumber,$text,$cust,$gen,$class,$harnessSN,$ver,$sample,$man);

    e.g. (0,'09DAA324') = rc_write_RFID_text(1,'AUDI MLB','Audi','AB10','MLBevo','001Q0001','1.0','C1','01/2013');

writes harness information to RFID tag of harness (empty section will be skipped, to delete section use one blank)

returns status and $tagUID

$text   - ASCII Text viewed on LCD Display 
$cust   - Harness Customer
$gen    - Harness Airbaggeneration
$class  - Harness Vehicle/class
$harnessSN     - Harness Serial Number
$ver    - Harness Version
$sample - Sample Phase
$man    - Manufacturing Date

$tagUID    - RFID tag ID

=cut

sub rc_write_RFID_text {
    my ($rcNumber,$text,$cust,$gen,$class,$harnessSN,$ver,$sample,$man) = @_;
    my ($tagUID);

    ($status,$tagUID) = rc_send_commad_wait_response($rcNumber,'T?U');
    if ($text){
        $text = sprintf "%-8s", $text;
        ($status) = rc_write_RFID_page($rcNumber, 3, $text);
    }
    if ($cust){
        $cust = sprintf "%-8s", $cust;
        ($status) = rc_write_RFID_page($rcNumber, 4, $cust);
    }
    if ($gen){
        $gen = sprintf "%-8s", $gen;
        ($status) = rc_write_RFID_page($rcNumber, 5, $gen);
    }
    if ($class){
        $class = sprintf "%-8s", $class;
        ($status) = rc_write_RFID_page($rcNumber, 6, $class);
    }
    if ($harnessSN){
        $harnessSN = sprintf "%-8s", $harnessSN;
         ($status) = rc_write_RFID_page($rcNumber, 7, $harnessSN);
    }
    if ($ver){
        $ver = sprintf "%-8s", $ver;
        ($status) = rc_write_RFID_page($rcNumber, 8, $ver);
    }
    if ($sample){
        $sample = sprintf "%-8s", $sample;
        ($status) = rc_write_RFID_page($rcNumber, 9, $sample);
    }
    if ($man){
        $man = sprintf "%-8s", $man;
        ($status) = rc_write_RFID_page($rcNumber, 10, $man);
    }

   return ($status,$tagUID);

}

=head2 rc_write_RFID_transponder_type

    ($status,$response) = rc_write_RFID_transponder_type($rcNumber);

    e.g. (0,'WR_done') = rc_write_RFID_transponder_type(1);

sets transponder type to reader (type 5), this has to be done only once per TSG4

returns status.

=cut

sub rc_write_RFID_transponder_type {
    my $rcNumber = shift;
    my $value;
    my ($response1,$response,$receive_ID);

   ($status,$response1,$receive_ID) = rc_send_commad_wait_response($rcNumber,"TWT");
    tsg4_wait_ms(200);
   ($status,$response,$receive_ID) = rc_send_commad_wait_response($rcNumber,"TR0");

    return ($status,$response1);

}


=head2 rc_bootloader_mode

    $status = rc_bootloader_mode($rcNumber);

    e.g. $status = rc_bootloader_mode(1);

sets rack controller to bootloader mode for firmware update

returns status.

=cut

sub rc_bootloader_mode {
    my $rcNumber = shift;
    my ($value);

    ($status,$value) = rc_send_commad_wait_response($rcNumber,'@');
#    print("bootloader response: $value\n");

    return ($status);

}

=head2 rc_set_voltage

    $status = rc_set_voltage($rcNumber,$voltage_mV);

    e.g. $status = rc_set_voltage(1,12000);

sets voltage on internal ECU power supply (range 4200 .. 20000). This will stop a running curve.

=cut

sub rc_set_voltage {
    my $rcNumber = shift;
    my $voltage = shift;
    $voltage = int($voltage/10);

	rc_stop_curve();
    my $command = sprintf("S%04d",$voltage);

    ($status) = rc_send_commad_wait_response($rcNumber,$command);
#    print("voltage set to ".($voltage*10)." mV\n");

    return ($status);

}

=head2 rc_stop_curve

    $status = rc_stop_curve($rcNumber);

stops running curve

=cut


sub rc_stop_curve{
    my $rcNumber = shift;
    if( $curve_running ){
	    ($status) = rc_send_commad_wait_response($rcNumber,'GS');
		$curve_running = 0;
    }
    return $status;
}

=head2 rc_start_curve

    $status = rc_start_curve( $rcNumber [,$mode] );
	$mode = 'event' or 'now' (default)

starts curve directly or on eventtrigger

=cut


sub rc_start_curve{
    my $rcNumber = shift;
    my $mode = shift;
	$mode = 'now' unless defined $mode;
    if( $mode eq 'event' ){
	    ($status) = rc_send_commad_wait_response($rcNumber,'GW');
		$curve_running = 1;
    }
    elsif( $mode eq 'now' ){
	    ($status) = rc_send_commad_wait_response($rcNumber,'GG');
		$curve_running = 1;
    }
	else{
		$status = -1;
	}
    return $status;
}

=head2 rc_ubat_coupling

    $status = rc_ubat_coupling($rcNumber,$mode);
	$mode = 0 (no coupling) , 1 (coupling)

couples curve with ubat card, if voltage value is 0 eventtrigger will be sent to control ubat card

=cut


sub rc_ubat_coupling{
    my $rcNumber = shift;
    my $mode = shift;

    ($status) = rc_send_commad_wait_response($rcNumber,'GB0'.$mode+1);

    return $status;
}

=head2 rc_set_voltage_curve

    $status = rc_set_voltage_curve($rcNumber, $voltage_aref, $time_aref, $volt_step, $time_step, $repetition);

    e.g. $status = rc_set_voltage_curve(1,[120,50,120,50],[100,100,100,100],100,10,1);

	$voltage_aref, $time_aref as byte array max 1000 values
	$volt_step = 50,100 mV
	$time_step = 10,20,50,80 ms
	$repetition = 0-99 where 0 means infinite
	
download voltage curve on internal ECU power supply 
(range of values 4.2 .. 20 V).  NOTE: values below 4.2 V will be set to 4.2 V (internal clipping due to OP-amp)

# for LIFT function: scan voltage values, set all below 4.2 V to 0 and configure trigger out on rc, configure event trigger on ubat
# new format xat like sat but with volt_step time_step in header (should run on toellner also!)


=cut

sub rc_set_voltage_curve {
    my $rcNumber = shift;
    my $voltage_aref = shift;
    my $time_aref = shift;
    my $volt_step = shift;
    my $time_step = shift;
    my $repetition = shift;
	my ($command,$count,@values,$ret);
	@values=();
	$volt_step = $volt_step/50;

    ($status,$ret) = rc_send_commad_wait_response($rcNumber,'GD');
	if ($ret =~ /^error/){
#		print"init error !\n";
		return (-1);
	}

	if (scalar(@$voltage_aref) != scalar(@$time_aref)){
#		print"array size mismatch !\n";
		return (-1);
	}

	for ($count=0;$count<scalar(@$voltage_aref);$count++){
		push (@values,$$voltage_aref[$count]);
		push (@values,$$time_aref[$count]);
	}

	# send blocks of 8 value pairs
	while ( scalar(@values) >= 8 ){
		my @send = splice(@values,0,8);
		# send command		
		foreach my $byte (@send){
			$byte = chr($byte);
		}
		($status,$ret) = rc_send_bytes_wait_response($rcNumber,\@send);
	}

	# final block: append 0 until 8 values and send command (if no values left it will be 8x0)
	while ( scalar(@values) < 8 ){
		push(@values,0);
	}
	foreach my $byte (@values){
		$byte = chr($byte);
	}
	($status,$ret) = rc_send_bytes_wait_response($rcNumber,\@values);

    ($status,$ret) = rc_send_commad_wait_response($rcNumber,'GT'.$time_step);
    ($status,$ret) = rc_send_commad_wait_response($rcNumber,'GV0'.$volt_step);

    $command = sprintf("GR%02d",$repetition);
    ($status,$ret) = rc_send_commad_wait_response($rcNumber,$command);

    return ($status);

}

=head2 rc_set_voltage_file

	($status, $duration_ms, $u_min_v, $u_max_V) = rc_set_voltage_file( $rcNumber, $file );
	
Load curve from file $file and transmit to RC $rcNumber. This will stop a running curve! 
File format is extended sat file (with time_step and volt_step), see example below.
However time_step and volt_step can also be omitted. In that case the function sets the lowest possible value
according to the curve data.

B<Arguments:>

=over

=item $rcNumber

=item $file

	file e.g.
	
	time_step:           10
	volt_step:           100
	Filename:            C:\temp\test1.txt
	Points:              27
	Current Limitations: 4.00
	Repetitions:         1

	U[V]   t[s]
	  5.400  1.830
	  0.000  0.110
	 11.600  1.060
	  0.000  0.540

=back

B<Return Value:>

=over

=item $status

0 on success and in offline mode. Negative on error.

=item $duration_ms

Duration of the curve in s, taking into account the given Repetitions. undef on error.

=item $u_min_V

Minimum voltage of the curve in V. undef on error.

=item $u_max_V

Maximum voltage of the curve in V. undef on error.

=back

B<Notes:> 

values below 4.2 V will be set to 4.2 V (internal clipping due to OP-amp)

=cut

sub rc_set_voltage_file {
    my $rcNumber = shift;
    my $file     = shift;
    my $errorCode;

    #COMMENT-START
    # ($status,$duration,$u_min,$u_max) = rc_set_voltage_file($rcNumber,$file);
    #COMMENT-END
    unless ( defined($file) ) {
        $errorCode = -17;
        return ( $errorCode, undef, undef, undef );
    }

    unless ( -f $file ) {
        $errorCode = -1;
        return ( $errorCode, undef, undef, undef );
    }

    my ( @volts_phys_mV, @time_phys_ms, $repeat, $count, $duration_s, $timebuffer_ms, $volt_step_mV, $time_step_ms );
    $repeat        = 1;
    $duration_s    = 0;

    #STEP Read $file
    if ( open( my $in, "<", "$file" ) ) {
        my @lines = <$in>;
        close($in);
        foreach my $line (@lines) {
            $line =~ s/,/./g;    # replace all commas with dots (convert to float)
            #STEP Extract values for time_step, volt_step, Repetitions from file header
            if    ( $line =~ /^(time_step|Zeitschritt)\s*:\s*(\S+)/i )   { $time_step_ms = $2 }
            elsif ( $line =~ /^(volt_step|Spannungsschritt)\s*:\s*(\S+)/i )   { $volt_step_mV = $2 }
            elsif ( $line =~ /^(Repetitions|Wiederholungen)\s*:\s*(\S+)/i ) { $repeat    = $2 }
            elsif ( $line =~ /^\s*([\d.]+)\s+([\d.]+)/ ) {
                #STEP Extract voltage and time values from file
                my $volt_val_mV = $1 * 1000;
                my $time_val_ms = $2 * 1000;
                $duration_s += $time_val_ms / 1000;
                push( @volts_phys_mV, $volt_val_mV );
                push( @time_phys_ms,  $time_val_ms );
            }
        }
    }
    else {
        $errorCode = -1;
        return ( $errorCode, undef, undef, undef );
    }



    #STEP If time_step is not given in the file then it is set to the minimum possible value that does not exceed 1000 data points
    my @timeSteps_ms = (10, 20, 50, 80);
    my $maxNumberOfPoints = 1000;
    if( not defined $time_step_ms ) {
        my $stepFound = 0;
        foreach my $step_ms ( @timeSteps_ms ) {
            my $numberOfPoints = $duration_s * 1000 / $step_ms /255;
            if( $numberOfPoints < $maxNumberOfPoints ) {
                $time_step_ms = $step_ms;
                $stepFound = 1;
                last;
            }
        }
        if( not $stepFound ) {
            tsg4_set_error("Given curve duration is too long ($duration_s s) for TSG4. Maximum duration is 20400 s.");
            return ( -3, undef, undef, undef );
        }
    }

    #STEP Validate the value of time_step
    if( not grep {$time_step_ms == $_} @timeSteps_ms ) {
        tsg4_set_error("Given value of 'time_step' or 'Zeitschritt' (=$time_step_ms) is invalid. Valid values are: @timeSteps_ms .");
        return ( -3, undef, undef, undef );
    }

    #STEP Determine min and max value for voltages from the file
    my ( $u_max_mV, $u_min_mV ) = ( -1e99, 1e99 );    # Initialize to values outside anything in your list
    map { $u_max_mV = $_ if ( $_ > $u_max_mV ); $u_min_mV = $_ if ( $_ < $u_min_mV ); } @volts_phys_mV;
    my $u_max_V = $u_max_mV / 1000;
    my $u_min_V = $u_min_mV / 1000;
    

    #STEP If volt_step is not given in the file then it is set to the minimum possible value that can handle the maximum voltage value from the file 
    if( not defined $volt_step_mV ) {
        if( $u_max_V < 16.8 ){
            $volt_step_mV = 50;
        }
        elsif( $u_max_V < 25.5 ){
            $volt_step_mV = 100;
        }
        else{
            tsg4_set_error("Given maximum curve voltage is too high ($u_max_V V) for TSG4. Maximum voltage is 25.5 V.");
            return ( -4, undef, undef, undef );
        }
    }

    #STEP Validate the value of volt_step
    my $voltOffset_mV;
    if( $volt_step_mV == 50 ){
        $voltOffset_mV = 4000;
    }
    elsif( $volt_step_mV == 100 ){
        $voltOffset_mV = 0;
    }
    else{
        tsg4_set_error("Given value of 'volt_step' or 'Spannungsschritt' (=$volt_step_mV) is invalid. Valid values are: 50 100 .");
        return ( -3, undef, undef, undef );
    }

    #STEP Create time array with the given times and time_step. If given times are > 255*time_step then intermediate steps are created. 
    #STEP Create volt array with the given voltages and volt_step. 
    my (@volts, @time);
    foreach my $index ( 0 .. @volts_phys_mV - 1 ) {
        my $volt_val_mV = $volts_phys_mV[$index];
        # lower bound of voltage values is $voltOffset_mV
        if( $volt_val_mV < $voltOffset_mV ) {
            $volt_val_mV = $voltOffset_mV;
        }
        my $time_val_ms = $time_phys_ms[$index];
        while ( $time_val_ms > $time_step_ms * 255 ) {
            push( @volts, ( $volt_val_mV - $voltOffset_mV ) / $volt_step_mV );
            push( @time,  255 );
            $time_val_ms -= $time_step_ms * 255;
        }
        push( @volts, ( $volt_val_mV - $voltOffset_mV ) / $volt_step_mV );
        push( @time,  $time_val_ms / $time_step_ms );
    }



    #STEP Check plausibility of time and volt array
    if ( scalar(@volts) < 1 ) {
        tsg4_set_error("No data points given.");
        $errorCode = -11;
        return ( $errorCode, undef, undef, undef );
    }

    my $numberOfPoints = @volts;
    if ( $numberOfPoints > $maxNumberOfPoints ) {
        tsg4_set_error("Too many data points (= $numberOfPoints) required for the given curve with the given time_step ($time_step_ms ms). Consider shortening the curve or setting a higher time_step if possible.");
        $errorCode = -2;
        return ( $errorCode, undef, undef, undef );
    }

    #chek values from file, add error message later
    if ( $repeat < 0 or $repeat > 255 ){
        tsg4_set_error("Given Repetitions (= $repeat) out of range. Repetitions must be >= 0 and <= 255.");
        return ( -5, undef, undef, undef );
    }

    #STEP Calculate curve duration using Repetitions
    my $duration_ms = 1000 * $duration_s;
    $duration_ms *= $repeat;

    return ( 0, $duration_ms, $u_min_V, $u_max_V ) if $main::opt_offline;
    #STEP Stop current curve output, if any
    rc_stop_curve();
    #CALL rc_set_voltage_curve with rcNumber, volt array, time array, volt_step, time_step, Repetitions
    $status = rc_set_voltage_curve( $rcNumber, \@volts, \@time, $volt_step_mV, $time_step_ms, $repeat );

    #STEP Return status, curve duration, min voltage , max voltage
    return ( $status, $duration_ms, $u_min_V, $u_max_V );

}

=head2 rc_configure_event_trigger

    $status = rc_configure_event_trigger($rcNumber,$edge);

    e.g. $status = rc_configure_event_trigger(1,'FALLING');
    
    $edge = 'FALLING' or 'RISING', default is 'RISING'.

configre event trigger to falling/rising edge.

=cut

sub rc_configure_event_trigger {
    my $rcNumber = shift;
    my $edge = shift;
    my $edge_num = 2;
    if ($edge eq 'FALLING'){
    	$edge_num = 1;
    }
    elsif ($edge eq 'RISING'){
        $edge_num = 2;
    }
    else {return -1;}

    my $command = sprintf("E%02d",$edge_num);

    ($status,undef) = rc_send_commad_wait_response($rcNumber,$command);
#    print("event trigger on $edge\n");

    return ($status);

}

=head2 rc_configure_event_trigger_delay

    $status = rc_configure_event_trigger_delay($rcNumber,$delay_us);

    e.g. $status = rc_configure_event_trigger_delay(1,120);
    
    $delay_us in microseconds (10 .. 2147483647).

configre event trigger delay time.

=cut

sub rc_configure_event_trigger_delay {
    my $rcNumber = shift;
    my $delay_us = shift;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$delay_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }

    my $command = sprintf("D%s",join('',@bytes));

    ($status,undef) = rc_send_commad_wait_response($rcNumber,$command);

    return ($status);

}

=head2 rc_display_text

    $status = rc_display_text($rcNumber,$text,$position);

    e.g. $status = rc_display_text(1,'hello',1);

    $text length <= 8 
    $position = 1,2,3,4 (left top, left bottom, right top, right bottom)

writes text to card to be displayed.

=cut

sub rc_display_text {
    my $rcNumber = shift;
    my $text = shift;
    my $position = shift;
    my ($receive_ID,$response);

    while (length($text)<8){
    	$text.=' ';
    }

    ($status,$response,$receive_ID) = rc_send_commad_wait_response($rcNumber,"V$position");

#    printf( "-> 0x%02x $text\n",$receive_ID-1);
#    printf( "-> RESP1 $response\n");

    my @bytes = split(//, $text);
    ($status,$response) = rc_send_bytes_wait_response($rcNumber,\@bytes);
#    printf( "-> RESP2 @$response , $CANstatus\n");

    return ($status);

}

=head2 rc_enable_event_trigger

    $status = rc_enable_event_trigger($rcNumber);

    e.g. $status = rc_enable_event_trigger(1);

send event trigger for 1 ms (without delay).

returns status.

=cut

sub rc_enable_event_trigger {
    my $rcNumber = shift;
    my ($value);

    ($status,undef) = rc_send_commad_wait_response($rcNumber,'E00');
#    print("event trigger out\n");

    return ($status);

}


=head2 rc_enable_PWM

    $status = rc_enable_PWM($rcNumber);

    e.g. $status = rc_enable_PWM(1);

send PWM signals for 5 sec.

returns status.

=cut

sub rc_enable_PWM {
    my $rcNumber = shift;
    my ($value);

    ($status,undef) = rc_send_commad_wait_response($rcNumber,'P01','ASCII',6000);
#    print("PWM requested\n");

    return ($status);

}


=head2 rc_set_12V_standby

    $status = rc_set_12V_standby($rcNumber [, $time]);
    
    $time in seconds 1..9999, default is 300

    e.g. $status = rc_set_12V_standby(1);

set standby of 12V card supply after $time. Any rc_ command sent within $time will disable standby. 
Rack controller will send 'standby' on CAN when $time exceeded and standby is activated.

     time        Chn     ID    Name   Dir    DLC   Data                      Data ASCII   
     0.047432    CAN 1   700          Rx     8     58 30 31 4F 30 30 31 30   X01O0010     
     0.000340    CAN 1   701          Rx     8     64 6F 6E 65 20 20 20 4F   done   O     
     10.200078   CAN 1   701          Rx     8     73 74 61 6E 64 62 79 00   standby.     # standby is acitvated

     time       Chn     ID    Name   Dir    DLC   Data                      Data ASCII   
     0.103402   CAN 1   700          Rx     8     58 30 31 4F 30 30 31 30   X01O0010     
     0.272142   CAN 1   701          Rx     8     64 6F 6E 65 20 20 20 4F   done   O     
     1.573044   CAN 1   700          Rx     8     58 30 31 53 31 32 30 30   X01S1200     # standby is disabled by this command
     0.000386   CAN 1   701          Rx     8     64 6F 6E 65 20 20 20 53   done   S     

returns status.

=cut

sub rc_set_12V_standby {
    my $rcNumber = shift;
    my $time = shift;
    $time = 300 unless defined $time;
    my $command = sprintf("O%04d",$time);;

    ($status,undef) = rc_send_commad_wait_response($rcNumber,$command);
#    print("set standby of 12V card supply\n");

    return ($status);

}


=head2 rc_set_12V_normal

    $status = rc_set_12V_normal($rcNumber);

    e.g. $status = rc_set_12V_normal(1);

set normal mode of 12V card supply.

returns status.

=cut

sub rc_set_12V_normal {
    my $rcNumber = shift;
    my ($value);

    ($status,undef) = rc_send_commad_wait_response($rcNumber,'O0000');
#    print("set normal mode of 12V card supply\n");

    return ($status);

}



=head2  rc_lock_display

    ($status) =  rc_lock_display($rcNumber);

    e.g. (0) =  rc_lock_display(3);

lock display on rack controller card to avoid wait times due to display update.

returns status.

=cut

sub  rc_lock_display {
    my $rcNumber = shift;
    my $value;

    ($status,$value) =  rc_send_commad_wait_response($rcNumber,'C99');

    return ($status);

}

=head2  rc_unlock_display

    ($status) =  rc_unlock_display($rcNumber);

    e.g. (0) =  rc_unlock_display(3);

unlock display on rack controller card.

returns status.

=cut

sub  rc_unlock_display {
    my $rcNumber = shift;
    my $value;

    ($status,$value) =  rc_send_commad_wait_response($rcNumber,'C00');

    return ($status);

}


=head2  rc_write_SN

    $status =  rc_write_SN($rcNumber,$serial_number);

    e.g. $status =  rc_write_SN(3,'999X0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub  rc_write_SN {
    my $rcNumber = shift;
    my $cardSN = shift;

    $status =  rc_write_EE($rcNumber,$tsg4::EEmapping{'SN'},$cardSN);

    return ($status);

}

=head2  rc_write_TST

    $status =  rc_write_TST($rcNumber,$TST_date);

    e.g. $status =  rc_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub  rc_write_TST {
    my $rcNumber = shift;
    my $test_date = shift;

    $status =  rc_write_EE($rcNumber,$tsg4::EEmapping{'TST'},$test_date);

    return ($status);

}

=head2  rc_write_CAL

    $status =  rc_write_CAL($rcNumber,$CAL_date);

    e.g. $status =  rc_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub  rc_write_CAL {
    my $rcNumber = shift;
    my $cal_date = shift;

    $status =  rc_write_EE($rcNumber,$tsg4::EEmapping{'CAL'},$cal_date);

    return ($status);

}

=head2  rc_write_EE not exported

    $status =  rc_write_EE($rcNumber,$EEslot,$text);

    e.g. $status =  rc_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in card.

=cut

sub  rc_write_EE {
    my $rcNumber = shift;
    my $slot = shift;
    my $text = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);

    ($status,undef,$receive_ID) =  rc_send_commad_wait_response($rcNumber,$command);

#    printf( "-> 0x%02x $text (slot $slot)\n",$receive_ID-1);

    my @bytes = split(//, $text);

    tsg4_wait_ms(10);

    ($status) = rc_send_bytes_wait_response($rcNumber,\@bytes);
    tsg4_wait_ms(5);

    return ($status);

}


################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 rc_send_commad_wait_response

    ($stat,$ret,$receive_ID) = rc_send_commad_wait_response($rcNumber,$ascii_command [,$mode, $timeout]);

    $timeout is optional, default is $MAXtimeout
    $mode = 'ASCII' or 'RAW' for returning data
    
Transmits the string $data on the CAN to rack controller

returns status and answer string as ASCII ($mode = 'ASCII' is default).

if $mode 'RAW' given, returns status and array reference

=cut

sub rc_send_commad_wait_response {
    my $rcNumber = shift;
    my $ascii_command = shift;
    my $mode = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($data_aref);

    $mode='ASCII' unless(defined $mode);

    my $send_ID = RC_base_address +(($rcNumber - 1) * 2);
    my $receive_ID = $send_ID+1;

    $ascii_command = sprintf("X%02d%s",$rcNumber,$ascii_command);
#    printf( "-> 0x%02x $ascii_command\n",$send_ID);

    my @bytes = split(//, $ascii_command);

   ($status,$data_aref) = rc_send_bytes_wait_response($rcNumber, \@bytes, $timeout);
    if ($status < 0){
        return ($status,'error',$receive_ID);
    }

    if ($mode ne 'RAW'){
	    my @response = @$data_aref;
	    foreach my $byte (@response){
	        if ($byte == 0){
	            $byte = ""; #skip zero bytes
	        }
	        else{
	            $byte = chr($byte);
	        }
	    }

	    return (0,join('',@response),$receive_ID);
    }
    else{
        return (0,$data_aref,$receive_ID);

    }

}



=head2 rc_send_bytes_wait_response

    ($stat,$ret_aref,$receive_ID) = rc_send_bytes_wait_response($rcNumber,$bytes_aref [, $timeout]);

    $timeout is optional, default is $MAXtimeout
    
Transmits the bytes $bytes_aref on the CAN to rack controller

returns status and answer as array reference.

=cut

sub rc_send_bytes_wait_response {
    my $rcNumber = shift;
    my $bytes_aref = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($data_aref);

    my $send_ID = RC_base_address +(($rcNumber - 1) * 2);
    my $receive_ID = $send_ID+1;

    my @bytes = @$bytes_aref;
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $receive_ID, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "RC_$rcNumber" );
        return ($status,[],$receive_ID);
    }

	return (0,$data_aref,$receive_ID);

}


=head2 rc_send_commad

    ($stat,$receive_ID) = rc_send_commad($rcNumber,$ascii_command);

    e.g. ($status,$receive_ID) = rc_send_commad(1,'P01');


Transmits the string $data on the CAN to rack controller

returns status and answer ID.

=cut

sub rc_send_commad {
    my $rcNumber = shift;
    my $ascii_command = shift;

    my $send_ID = RC_base_address +(($rcNumber - 1) * 2);
    my $receive_ID = $send_ID+1;

    $ascii_command = sprintf("X%02d%s",$rcNumber,$ascii_command);
#    printf( "-> 0x%02x $ascii_command\n",$send_ID);

    my @bytes = split(//, $ascii_command);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }

    unshift (@bytes,8);

    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "RC_$rcNumber" );
    return ($status,$receive_ID);

}


=head2 rc_set_SIM_return_text

    ($stat,$ret,$receive_ID) = rc_set_SIM_return_text($rcNumber,$ascii_command, $text_or_aref [,$mode]);

    $mode = 'ASCII' or 'RAW' for returning data, default is 'ASCII'

 	e.g. 	rc_set_SIM_return_text(1, '?02', "004X0009");
 	    	rc_set_SIM_return_text(1, '?15', [0,0,0,0,0,0,0,0], 'RAW');

set return value for next tsg4can_SendAndWaitForResponse call, this is used for simulation testing

if $mode 'RAW' given, tsg4can_SendAndWaitForResponse returns status and $text_or_aref as array directly

=cut

sub rc_set_SIM_return_text {
    my $rcNumber = shift;
    my $ascii_command = shift;
    my $text = shift;
    my $mode = shift;
    my (@bytes);

    $mode='ASCII' unless(defined $mode);

    my $send_ID = RC_base_address +(($rcNumber - 1) * 2);
    my $receive_ID = $send_ID+1;

    $ascii_command = sprintf("X%02d%s",$rcNumber,$ascii_command);

    my @request = split(//,$ascii_command);
    foreach my $byte (@request){
    	$byte = ord($byte);
    }
    while (scalar(@request)<8){
        push (@request,0);
    }
    unshift (@request,8);

    if ($mode ne 'RAW'){
	    @bytes = split(//,$text);
    	foreach my $byte (@bytes){
    		$byte = ord($byte);
    	}
    }
    else{
        @bytes = @$text;
    }

    SIM_setReturnValues('tsg4can_SendAndWaitForResponse', [ 0, \@bytes ], [\@request, $send_ID, $send_ID+1, $MAXtimeout]);

}

=head2 aref2text not exported

    $text = aref2text($value_aref);

    e.g. 'Audi' = aref2text( [0x41, 0x75, 0x64, 0x69, 0x00, 0x00, 0x00, 0x00] );

converts array reference to ASCII text, used for RFID reading

returns 'error' if no array reference given.

=cut


sub aref2text{
    my $aref=shift;
    if( ref($aref) eq "ARRAY" ){
        my @response = @$aref;
        foreach my $byte (@response){
            if ($byte == 0){
                $byte = ""; #skip zero bytes
            }
            else{
                $byte = chr($byte);
            }
        }
        return (join('',@response));
    }
    return 'error';
}


=head2 aref2bin not exported

    $bin = aref2bin($value_aref);

    e.g. '1111111100000000' = aref2bin( [0xff, 0x00] );

converts array reference to binary, used for RFID reading

returns '' if no array reference given.

=cut


sub aref2bin{
    my $aref=shift;
    if( ref($aref) eq "ARRAY" ){
        my @response = @$aref;
        foreach my $byte (@response){
            $byte = sprintf("%08b", $byte);
        }
        return (join('',@response));
    }
    return '';
}


1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



