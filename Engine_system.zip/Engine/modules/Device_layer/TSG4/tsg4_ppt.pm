package tsg4_ppt;

use strict;
use warnings;
use tsg4;
use TSG4CAN;

require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    ppt_send_commad
    ppt_send_commad_wait_response
    ppt_function

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value,$PPTstatus);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

Power Pritt Tester module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

=head2 ppt_function

    ($status) = ppt_function($number);

    e.g. (0) = ppt_function(0);

	$number 0..2
	
	0 stop loop
	1 start loop
	2 single mode
	
runs test function

returns status.

=cut

sub ppt_function {
    my $value;
	my $func = shift;
	my $command = sprintf("TP%d",$func);

    ($status,$value) = ppt_send_commad_wait_response($command);
    
    return ($status);
    
}



################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 ppt_send_commad_wait_response

    ($stat,$ret) = ppt_send_commad_wait_response($ASCII_command [, $timeout] );

Transmits the string $ASCII_command on the CAN to test rack controller

if no $timeout given takes default $Maxtimeout

returns status and answer string as ASCII.

=cut

sub ppt_send_commad_wait_response {
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless (defined $timeout);
    my ($byte,$data_aref);

    my $send_ID = PowerPrittTester_base_address;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("%s",$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "TR" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response));
    
}


=head2 ppt_send_commad

    ($stat,$receive_ID) = ppt_send_commad($ASCII_command);

    e.g. ($status,$receive_ID) = ppt_send_commad('TP0');


Transmits the string $data on the CAN to test rack controller

returns status and answer ID.

=cut

sub ppt_send_commad {
    my $ASCII_command = shift;
    my ($byte);

    my $send_ID = PowerPrittTester_base_address;   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("%s",$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "TR" );
    return ($status,$receive_ID);
    
}



=head2 ppt_check_response

 $status = ppt_check_response($PPTstatus,$PPTresult);

if $PPTstatus < 0, set error string and return -1.
if $result not 'done' set error string and return -2.

=cut

sub ppt_check_response{
    my $PPTstatus = shift;
    my $PPTresult = shift;

    if ($PPTstatus<0){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -1
      
    }
    if ($PPTresult !~ m/^done/){
      #my $CANerrortext = tsg4can_GetErrorString($CANstatus);
      #tsg4_set_error( "CAN ($CANstatus): $CANerrortext");
      return -2
      
    }
    
    return 0;

}

1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



