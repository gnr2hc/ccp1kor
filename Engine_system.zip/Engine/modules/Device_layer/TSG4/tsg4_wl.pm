package tsg4_wl;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    wl_send_commad
    wl_send_commad_wait_response
    wl_get_firmware
    wl_get_HW_id
    wl_get_INFO
    wl_bootloader_mode
    wl_write_SN
    wl_write_CAL
    wl_write_TST
    wl_connect
    wl_disconnect
    wl_connect_via
    wl_disconnect_via
	wl_LV124
	wl_microcut
	wl_disconnect_user_relay
    wl_connect_user_relay
    wl_set_event_delay
    wl_set_event_trigger
    wl_PWMout_disposal
    wl_PWMout_config
    wl_PWMout_start
    wl_PWMout_stop
    wl_PWMin_start
    wl_PWMin_stop
    wl_PWM_timebase
    wl_lock_display
    wl_unlock_display

);

our ($VERSION,$HEADER);

my $MAXtimeout = 100; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

WL (and DIO) Control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a value is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


=head2 wl_connect

    $status = wl_connect($WLcard,$WLnumber);

    e.g. $status = wl_connect(1,2);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

connects WL

returns status.

=cut

sub wl_connect {
    my $WLcard = shift;
    my $WLnumber = shift;

    my $command = "U01a";
 
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}

=head2 wl_disconnect

    $status = wl_disconnect($WLcard,$WLnumber);

    e.g. $status = wl_disconnect(1,2);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

disconnects WL (open line)

returns status.

=cut

sub wl_disconnect {
    my $WLcard = shift;
    my $WLnumber = shift;

    my $command = "U01e";

    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}


=head2 wl_get_firmware

    ($status, $firmware) = wl_get_firmware($WLcard);

    e.g. (0,'Ver 1.0') = wl_get_firmware(1);

    $WLcard 1..4 (4=DIO)

reads firmware version from WL card

returns status.

=cut

sub wl_get_firmware {
    my $WLcard = shift;
    my $value;

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 wl_get_HW_id

    ($status, $HW_ID) = wl_get_HW_id($WLcard);

    e.g. (0,'999/0042') = wl_get_HW_id(1);

    $WLcard 1..4 (4=DIO)	

reads hardware ID from WL card

returns status.

=cut

sub wl_get_HW_id {
    my $WLcard = shift;
    my $value;

    ($status,$value) = wl_get_INFO($WLcard,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 wl_bootloader_mode

    $status = wl_bootloader_mode($WLcard);

    e.g. $status = wl_bootloader_mode(1);

    $WLcard 1..4 (4=DIO)	

sets WL card to bootloader mode for firmware update

returns status.

=cut

sub wl_bootloader_mode {
    my $WLcard = shift;
    my ($value);

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 wl_connect_via

    $status = wl_connect_via($WLcard,$WLnumber,$via);

    e.g. $status = wl_connect_via(1,2,1); # connect WL_2 to ref1

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

connect WL pin to reference line

returns status.

=cut

sub wl_connect_via {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $via = shift;
    my $command;
 
	$command = sprintf("B%02d%s",$via,'e');
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
#    print("wl_connect_via ($WLnumber ref $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 wl_disconnect_via

    $status = wl_disconnect_via($WLcard,$WLnumber,$via);

    e.g. $status = wl_disconnect_via(2,1); # disconnect WL_1_2 from ref1

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

disconnect WL pin from reference line

returns status.

=cut

sub wl_disconnect_via {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $via = shift;
    my $command;
  
	$command = sprintf("B%02d%s",$via,'a');
	($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
#    print("wl_disconnect_via ($WLnumber ref $via -> $command) $status\n");
    
    return ($status);
    
}



=head2 wl_set_event_delay

    $status = wl_set_event_delay($WLcard,$delay);

    e.g. $status = wl_set_event_delay(1,1.7);

    $WLcard 1..4 (4=DIO)
    $delay between 0 .. 9.9 millisec step 0.1 millisec 

sets delay on WL card for wl_set_event_trigger

returns status.

=cut

sub wl_set_event_delay {
    my $WLcard = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%03d",$delay*10);
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}


=head2 wl_set_event_trigger

    $status = wl_set_event_trigger($WLcard,$WLnumber,$fault_type);

    e.g. $status = wl_set_event_trigger(1,3,1);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6
    $fault_type between 0 .. 68 

     0 - no fault
     1 - interruption
     2 - WL to ref1
     3 - WL to ref2
     4 - LV124 10sec interruption
     5 - LV124 1ms   interruption
     6 - LV124 100us interruption
     7 - LV124 1us   interruption 1ms pause with 4 sec cycle
     8 - LV124 100us interruption 1ms pause with 4 sec cycle
    51 - user relay 1 on 
    52 - user relay 2 on 
    53 - user relay 3 on 
    54 - user relay 4 on 
    55 - user relay 5 on 
    56 - user relay 6 on 
    57 - user relay 7 on 
    58 - user relay 8 on 
    61 - user relay 1 off 
    62 - user relay 2 off 
    63 - user relay 3 off 
    64 - user relay 4 off 
    65 - user relay 6 off 
    66 - user relay 6 off 
    67 - user relay 7 off 
    68 - user relay 8 off 

sets event trigger mode on pin $pin of channel $CHnumber.

returns status.

=cut

sub wl_set_event_trigger {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $fault_type = shift;
    my $command;
    
    $command = sprintf("E%02d",$fault_type);
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
}


=head2 wl_connect_user_relay

    $status = wl_connect_user_relay($WLcard,$relay);

    e.g. $status = wl_connect_user_relay(1,3);

    $WLcard 1..4 (4=DIO)
    $relay between 1 .. 8 

connects relay on WL card 

returns status.

=cut

sub wl_connect_user_relay {
    my $WLcard = shift;
    my $relay = shift;
    my $command;

    $command = sprintf("K%02d".'e',$relay);
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}

=head2 wl_disconnect_user_relay

    $status = wl_disconnect_user_relay($WLcard,$relay);

    e.g. $status = wl_disconnect_user_relay(1,3);

    $WLcard 1..4 (4=DIO)
    $relay between 1 .. 8 

disconnects relay on WL card 

returns status.

=cut

sub wl_disconnect_user_relay {
    my $WLcard = shift;
    my $relay = shift;
    my $command;

    $command = sprintf("K%02d".'a',$relay);
    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}



=head2 wl_LV124

    $status = wl_LV124($WLcard,$WLnumber,$fault_type);

    e.g. $status = wl_LV124(1,2,1); 
    
    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6
    
    $fault_type between 1 .. 5 
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on Warning Lamp

returns status.

=cut

sub wl_LV124 {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $fault_type = shift;
    my $command;

    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);

	$command = sprintf("L%02d",$fault_type);
	($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command,$timeout);
    
    return ($status);
    
}

=head2 wl_microcut

    $status = wl_microcut($WLcard,$WLnumber,$offtime_us);

    e.g. $status = wl_microcut(1,3,100);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6
    $offtime_us in microseconds

starts microcut (LV124) fault simulation on Warning Lamp.

=cut

sub wl_microcut {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $offtime_us = shift;

    my $timeout=int($offtime_us/1000)+1000;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s",join('',@bytes));

    ($status,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$command,$timeout);
    
    return ($status);
    
}


=head2 wl_write_SN

    $status = wl_write_SN($WLcard,$serial_number);

    e.g. $status = wl_write_SN(1,'999D0042');

    $WLcard 1..4 (4=DIO)
    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub wl_write_SN {
    my $WLcard = shift;
    my $SN = shift;

    $status = wl_write_EE($WLcard,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 wl_write_TST

    $status = wl_write_TST($WLcard,$TST_date);

    e.g. $status = wl_write_TST(1,'24.12.12');

    $WLcard 1..4 (4=DIO)
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub wl_write_TST {
    my $WLcard = shift;
    my $TST_date = shift;

    $status = wl_write_EE($WLcard,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 wl_write_CAL

    $status = wl_write_CAL($WLcard,$CAL_date);

    e.g. $status = wl_write_CAL(3,'24.12.12');

    $WLcard 1..4 (4=DIO)
    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub wl_write_CAL {
    my $WLcard = shift;
    my $CAL_date = shift;

    $status = wl_write_EE($WLcard,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 wl_get_INFO

    ($status, $INFO) = wl_get_INFO($WLcard,$keyword);

    e.g. (0,'999D0042') = wl_get_INFO(1,'SN');

    $WLcard 1..4 (4=DIO)

    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from WL card

returns status.

=cut

sub wl_get_INFO {
    my $WLcard = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 wl_write_EE not exported

    $status = wl_write_EE($WLcard,$EEslot,$text);

    e.g. $status = wl_write_EE(3,5,'hello');

    $WLcard 1..4 (4=DIO)
    $serial_number length <= 8 

writes text to EEprom slot in WL card.

=cut

sub wl_write_EE {
    my $WLcard = shift;
    my $slot = shift;
    my $text = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,undef,$receive_ID) = wl_send_commad_wait_response($WLcard,1,$command);

#    printf( "-> 0x%02x $text (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $text);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "WL_$WLcard" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}



=head2 wl_PWMout_disposal

    $status = wl_PWMout_disposal($WLcard,$WLnumber);

    e.g. 0 = wl_PWMout_disposal(1,1);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

start PWM signal for disposal (140ms high, 60ms low)

returns status.

=cut

sub wl_PWMout_disposal {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $value;

    my $command = sprintf("P02");

    ($status,$value) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}



=head2 wl_PWMout_config

    $status = wl_PWMout_config($WLcard,$WLnumber,$low_time,$high_time);

    e.g. 0 = wl_PWMout_config(1,1,500,1000);
 
    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6
    $low_time,$high_time in timebase/lsb

    time depends on timebase
    e.g. timebase = 100 us
         low_time = 500   -> 50 ms
         high_time = 1000 -> 100 ms

    e.g. timebase = 500 us
         low_time = 500   -> 250 ms
         high_time = 1000 -> 500 ms

configure PWM signal for output

returns status.

=cut

sub wl_PWMout_config {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $low_time = shift;
    my $high_time = shift;
    my ($value,$low_time_hex,$high_time_hex);

    #convert value to ascii string which represents the hex value for $low_time
    my $hexstring = sprintf("%04X",$low_time);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    $low_time_hex = sprintf("%s",join('',@bytes));

    #convert value to ascii string which represents the hex value for $high_time
    $hexstring = sprintf("%04X",$high_time);
    @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    $high_time_hex = sprintf("%s",join('',@bytes));

    my $command = sprintf("V%s%s",$low_time_hex,$high_time_hex);

    ($status,$value) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}

=head2 wl_PWMout_start

    $status = wl_PWMout_start($WLcard,$WLnumber);

    e.g. 0 = wl_PWMout_start(1,1);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

starts configured PWM signal output

returns status.

=cut

sub wl_PWMout_start {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $value;

    my $command = sprintf("P01");

    ($status,$value) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}

=head2 wl_PWMout_stop

    $status = wl_PWMout_stop($WLcard,$WLnumber);

    e.g. 0 = wl_PWMout_stop(1,1);

    $WLcard 1..4 (4=DIO)
    $WLnumber 1..6

stops PWM signal output

returns status.

=cut

sub wl_PWMout_stop {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $value;

    my $command = sprintf("P00");

    ($status,$value) = wl_send_commad_wait_response($WLcard,$WLnumber,$command);
    
    return ($status);
    
}


=head2 wl_PWM_timebase

    $status = wl_PWM_timebase($WLcard,$timebase_us);

    e.g. 0 = wl_PWM_timebase(1,100);

    $WLcard 1..4 (4=DIO)
    $timebase_us may be 100,200,500 or 1000 microsec

sets common PWM signal timebase for input and output. For output CAN cycletime = 8 x timebase.

returns status.

=cut

sub wl_PWM_timebase {
    my $WLcard = shift;
    my $timebase_us = shift;
    my $value;
    my %time_table=(
    	100 => 10,
    	200 => 11,
    	500 => 12,
    	1000 => 13,
    );

    return -1 unless exists $time_table{$timebase_us};
    
    my $command = sprintf("P%d",$time_table{$timebase_us});

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}

=head2 wl_PWMin_start

    $status = wl_PWMin_start($WLcard);

    e.g. 0 = wl_PWMin_start(1);

    $WLcard 1..4 (4=DIO)

starts PWM signal logging on CAN (ID = device CAN id + 5) e.g. WL_card_1 = 0x65 logging ID

returns status.

=cut

sub wl_PWMin_start {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $value;

    my $command = sprintf("Fe");

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}

=head2 wl_PWMin_stop

    $status = wl_PWMin_stop($WLcard);

    e.g. 0 = wl_PWMin_stop(1);

    $WLcard 1..4 (4=DIO)

stops PWM signal logging on CAN

returns status.

=cut

sub wl_PWMin_stop {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $value;

    my $command = sprintf("Fa");

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,$command);
    
    return ($status);
    
}


=head2 wl_lock_display

    ($status) = wl_lock_display($WLcard);

    e.g. (0) = wl_lock_display(1);

lock display on WL card to avoid wait times due to display update.

returns status.

=cut

sub wl_lock_display {
    my $WLcard = shift;
    my $value;

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,'C99');
    
    return ($status);
    
}

=head2 wl_unlock_display

    ($status) = wl_unlock_display($WLcard);

    e.g. (0) = wl_unlock_display(1);

unlock display on WL card.

returns status.

=cut

sub wl_unlock_display {
    my $WLcard = shift;
    my $value;

    ($status,$value) = wl_send_commad_wait_response($WLcard,1,'C00');
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################



=head2 wl_send_commad_wait_response

    ($stat,$ret,$receive_ID) = wl_send_commad_wait_response($WLcard,$WLnumber,$ASCII_command,[$timeout]);

    $timeout is optional, default is $MAXtimeout

Transmits the string $data on the CAN to warning lamp card

returns status and answer string as ASCII.

=cut

sub wl_send_commad_wait_response {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    $timeout = $MAXtimeout unless defined $timeout;
    my ($byte,$data_aref);

    my $send_ID = WL_base_address+(($WLcard - 1) * 2);   
    
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("L%02d%s",(($WLcard-1)*6+$WLnumber) ,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);

   ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "WL_$WLcard" );
        return ($status,'error',$receive_ID);
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
    
    return (0,join('',@response),$receive_ID);
    
}


=head2 wl_send_commad

    ($stat,$receive_ID) = wl_send_commad($WLcard,$WLnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = wl_send_commad(1,1,'?00');

Transmits the string $data on the CAN to warning lamp card

returns status and answer ID.

=cut

sub wl_send_commad {
    my $WLcard = shift;
    my $WLnumber = shift;
    my $ASCII_command = shift;
    my ($byte);
    
    my $send_ID = WL_base_address+(($WLcard - 1) * 2);   
    my $receive_ID = $send_ID+1;   
    
    $ASCII_command = sprintf("L%02d%s",(($WLcard-1)*6+$WLnumber),$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "WL_$WLcard" );
    return ($status,$receive_ID);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



