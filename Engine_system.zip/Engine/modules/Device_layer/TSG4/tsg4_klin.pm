package tsg4_klin;

use strict;
use warnings;
use tsg4;
use TSG4CAN;


require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
    
    kl_send_commad
    kl_send_commad_wait_response
    kl_connect
    kl_disconnect
    kl_connect_via
    kl_disconnect_via
	kl_microcut
	kl_LV124    
	kl_set_LIN_master
	kl_signal_output
	kl_set_LIN_slave
    kl_bootloader_mode
    kl_set_event_delay
    kl_set_event_trigger
    kl_get_firmware
    kl_get_HW_id
    kl_write_SN
    kl_write_TST
    kl_write_CAL
	kl_get_INFO
	kl_signal_mode

);

our ($VERSION,$HEADER);

my $MAXtimeout = 500; # ms
my ($status,$CANstatus,$value);
my $receive_ID;



############################################################################################################

=head1 DESCRIPTION

K-line/LIN card control module for TSG4 family HW via CAN 

CAN hast to be already initilaize by tsg4_init

please note that due to relay switching it may take up to 5 ms until a channel is set

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut



=head2 kl_set_LIN_master

    $status = kl_set_LIN_master($CHnumber); # this is default

    e.g. $status = kl_set_LIN_master(3);

sets termination resistor R31 / R33 on LIN channel $CHnumber

returns status.

=cut

sub kl_set_LIN_master {
    my $CHnumber = shift;
    my $command;

    $command = sprintf("ALe");
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}

=head2 kl_set_LIN_slave

    $status = kl_set_LIN_slave($CHnumber);

    e.g. $status = kl_set_LIN_slave(3);

sets termination resistor R30 / R32 on LIN channel $CHnumber

returns status.

=cut

sub kl_set_LIN_slave {
    my $CHnumber = shift;
    my $command;

    $command = sprintf("ALa");
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 kl_connect_via

    $status = kl_connect_via($CHnumber,$pin,$via);
    
    e.g. $status = kl_connect_via(3,'L',1); # connect LIN to ref1

    $pin = K N L (K-line, L-line(N), LIN)

connect pin $pin of channel $CHnumber to reference line $via

returns status.

=cut

sub kl_connect_via {
    my $CHnumber = shift;
    my $pin = shift;
    my $via = shift;
    my $command;

    $command = sprintf("B%s"."%de",$pin,$via);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
#    print("kl_connect_via ($CHnumber $pin $via -> $command) $status\n");
    
    return ($status);
    
}

=head2 kl_disconnect_via

    $status = kl_disconnect_via($CHnumber,$pin,$via);
    
    e.g. $status = kl_disconnect_via(3,'L',1); # disconnect LIN from ref1

    $pin = K N L (K-line, L-line(N), LIN)

disconnect pin $pin of channel $CHnumber from reference line $via

returns status.

=cut

sub kl_disconnect_via {
    my $CHnumber = shift;
    my $pin = shift;
    my $via = shift;
    my $command;

    $command = sprintf("B%s"."%da",$pin,$via);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
#    print("kl_disconnect_via ($CHnumber $pin $via -> $command) $status\n");
    
    return ($status);
    
}




=head2 kl_signal_output

    $status = kl_signal_output($CHnumber,$pin,$mode);

    e.g. $status = kl_signal_output(3,'K','n');

	$pin = K N ( K-line OR L-line(N) )

    $mode 'i' for inverted or 'n' for normal (default 'n')

sets output mode on K-line/LIN card for channel $CHnumber (only K-line OR L-line) 

returns status.

=cut

sub kl_signal_output {
    my $CHnumber = shift;
    my $pin = shift;
    my $mode = shift;
    my $command;

    $command = sprintf("F%s%s",$pin,$mode);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}



=head2 kl_signal_mode

    $status = kl_signal_mode($CHnumber,$mode);

    e.g. $status = kl_signal_mode(3,2);
	    
    $mode between 1 .. 3 

     1 - standard K-line RS232 level shifter
     2 - SAE Volvo diagnosis
     3 - reserve function
     
sets special mode on K-line/LIN card for channel $CHnumber (this will affect K-line AND L-line)

returns status.

=cut

sub kl_signal_mode {
    my $CHnumber = shift;
    my $mode = shift;
    my $command;

    $command = sprintf("FK%d",$mode);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 kl_set_event_delay

    $status = kl_set_event_delay($CHnumber,$delay);

    e.g. $status = kl_set_event_delay(3,1.7);

    $delay between 0 .. 99 millisec step 0.1 millisec 

sets delay on K-line/LIN card for kl_set_event_trigger

returns status.

=cut

sub kl_set_event_delay {
    my $CHnumber = shift;
    my $delay = shift;
    my $command;

    $command = sprintf("D%03d",$delay*10);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 kl_set_event_trigger

    $status = kl_set_event_trigger($CHnumber, $pin,$fault_type);

    e.g. $status = kl_set_event_trigger(3,'L',1);

    $pin = K N L (K-line, L-line(N), LIN)
    
    $fault_type between 0 .. 8 

     0 - no fault
     1 - interruption
     2 - pin to ref1
     3 - pin to ref2
     4 - LV124 10sec interruption
     5 - LV124 1ms   interruption
     6 - LV124 100us interruption
     7 - LV124 1us   interruption 1ms pause with 4 sec cycle
     8 - LV124 100us interruption 1ms pause with 4 sec cycle

sets event trigger mode on pin $pin of channel $CHnumber.

returns status.

=cut

sub kl_set_event_trigger {
    my $CHnumber = shift;
    my $pin = shift;
    my $fault_type = shift;
    my $command;
    
    $command = sprintf("E%s%d",$pin,$fault_type);
    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
}



=head2 kl_LV124

    $status = kl_LV124($CHnumber, $pin, $fault_type);

    e.g. $status = kl_LV124(3,'L',4);

    $pin = K N L (K-line, L-line(N), LIN)
    
    $fault_type between 0 .. 5 

    0 - no fault
    1 - 10sec interruption
    2 - 1ms   interruption
    3 - 100us interruption
    4 - 1us   interruption 1ms pause with 4 sec cycle
    5 - 100us interruption 1ms pause with 4 sec cycle

starts LV124 fault simulation on pin $pin of channel $CHnumber.

=cut

sub kl_LV124 {
    my $CHnumber = shift;
    my $pin = shift;
    my $fault_type = shift;

    my $timeout=$MAXtimeout;
    $timeout = 5000 if ($fault_type > 3);
    $timeout = 11000 if ($fault_type == 1);

    my $command = sprintf("L%s%d",$pin,$fault_type);

    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command,$timeout);
    
    return ($status);
    
}

=head2 kl_microcut

    $status = kl_microcut($CHnumber, $pin, $offtime_us);

    e.g. $status = kl_microcut(3,'L',100);
    
    $pin = K N L (K-line, L-line(N), LIN)
    $offtime_us in microseconds

starts microcut (LV124) fault simulation on pin $pin of channel $CHnumber.

=cut

sub kl_microcut {
    my $CHnumber = shift;
    my $pin = shift;
    my $offtime_us = shift;

    my $timeout=int($offtime_us/1000)+1000;

    #convert value to ascii string which represents the hex value for $offtime_us
    my $hexstring = sprintf("%08X",$offtime_us);
    my @bytes = unpack "a2" x (length( $hexstring ) /2), $hexstring;
    foreach my $byte (@bytes){ $byte=chr(hex($byte)); }
    
    my $command = sprintf("M%s%s",$pin,join('',@bytes));

    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command,$timeout);
    
    return ($status);
    
}


=head2 kl_connect

    $status = kl_connect($CHnumber, $pin);
    
    $pin = K N L (K-line, L-line(N), LIN)

    e.g. $status = kl_connect(3,'L');

connects bus pin $pin on channel $CHnumber

returns status.

=cut

sub kl_connect {
    my $CHnumber = shift;
    my $pin = shift;

    my $command = "U".$pin."a";

    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}



=head2 kl_disconnect

    $status = kl_disconnect($CHnumber, $pin);
    
    $pin = K N L (K-line, L-line(N), LIN)

    e.g. $status = kl_disconnect(3,'L');

disconnects bus pin $pin on channel $CHnumber

returns status.

=cut

sub kl_disconnect {
    my $CHnumber = shift;
    my $pin = shift;

    my $command = "U".$pin."e";

    ($status,$receive_ID) = kl_send_commad_wait_response($CHnumber,$command);
    
    return ($status);
    
}


=head2 kl_write_SN

    $status = kl_write_SN($CHnumber,$serial_number);

    e.g. $status = kl_write_SN(3,'999D0042');

    $serial_number length <= 8 

writes serial number to card to be displayed.

=cut

sub kl_write_SN {
    my $CHnumber = shift;
    my $SN = shift;

    $status = kl_write_EE($CHnumber,$tsg4::EEmapping{'SN'},$SN);
    
    return ($status);
    
}

=head2 kl_write_TST

    $status = kl_write_TST($CHnumber,$TST_date);

    e.g. $status = kl_write_TST(3,'24.12.12');
    
    $TST_date dd.mm.yy
    $serial_number length <= 8 

writes test date to card to be displayed.

=cut

sub kl_write_TST {
    my $CHnumber = shift;
    my $TST_date = shift;

    $status = kl_write_EE($CHnumber,$tsg4::EEmapping{'TST'},$TST_date);
    
    return ($status);
    
}

=head2 kl_write_CAL

    $status = kl_write_CAL($CHnumber,$CAL_date);

    e.g. $status = kl_write_CAL(3,'24.12.12');

    $CAL_date dd.mm.yy
    $serial_number length <= 8 

writes calibration date to card to be displayed.

=cut

sub kl_write_CAL {
    my $CHnumber = shift;
    my $CAL_date = shift;

    $status = kl_write_EE($CHnumber,$tsg4::EEmapping{'CAL'},$CAL_date);
    
    return ($status);
    
}


=head2 kl_bootloader_mode

    $status = kl_bootloader_mode($CHnumber);

    e.g. $status = kl_bootloader_mode(1);

sets K-line/LIN card to bootloader mode for firmware update

returns status.

=cut

sub kl_bootloader_mode {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = kl_send_commad_wait_response($CHnumber,'@');
#    print("bootloader response: $value\n");
    
    return ($status);
    
}



=head2 kl_get_firmware

    ($status, $firmware) = kl_get_firmware($CHnumber);

    e.g. (0,'Ver 1.0') = kl_get_firmware(3);

reads firmware version from K-line/LIN card

returns status.

=cut

sub kl_get_firmware {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = kl_send_commad_wait_response($CHnumber,'?10');
#    print("firmware $value\n");
    
    return ($status,$value);
    
}

=head2 kl_get_HW_id

    ($status, $HW_ID) = kl_get_HW_id($CHnumber);

    e.g. (0,'999D0042') = kl_get_HW_id(3);

reads hardware ID from K-line/LIN card

returns status.

=cut

sub kl_get_HW_id {
    my $CHnumber = shift;
    my $value;

    ($status,$value) = kl_get_INFO($CHnumber,'SN');
#    print("HW ID $value\n");
    
    return ($status,$value);
    
}

=head2 kl_get_INFO

    ($status, $INFO) = kl_get_INFO($CHnumber,$keyword);

    e.g. (0,'999D0042') = kl_get_INFO(3,'SN');
    
    TST - Test date
    CAL - calibration date
    SN  - hardware serial number
    3..9 - EE slot 

reads info from K-line/LIN card

returns status.

=cut

sub kl_get_INFO {
    my $CHnumber = shift;
    my $keyword = shift;
    my $value;

    $keyword = $tsg4::EEmapping{$keyword} if (exists $tsg4::EEmapping{$keyword});
    my $command = sprintf("?%02d",$keyword);

    ($status,$value) = kl_send_commad_wait_response($CHnumber,$command);
#    print("INFO ($keyword) $value\n");
    
    return ($status,$value);
    
}

=head2 kl_write_EE not exported

    $status = kl_write_EE($CHnumber,$EEslot,$text);

    e.g. $status = kl_write_EE(3,5,'hello');

    $serial_number length <= 8 

writes text to EEprom slot in K-line/LIN card.

=cut

sub kl_write_EE {
    my $CHnumber = shift;
    my $slot = shift;
    my $text = shift;
    my ($receive_ID);

    my $command = sprintf("#37%02d",$slot);
    
    ($status,$receive_ID) = kl_send_commad($CHnumber,$command);

#    printf( "-> 0x%02x $text (slot $slot)\n",$receive_ID-1);
    
    my @bytes = split(//, $text);
    foreach my $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    tsg4_wait_ms(10);
    
    $CANstatus = tsg4can_SendAndWaitForResponse( \@bytes, $receive_ID-1, $receive_ID, $MAXtimeout);
    $status = tsg4_check_CAN_status( $CANstatus, "KL_$CHnumber" );
    tsg4_wait_ms(5);
    
    return ($status);
    
}

################ low level functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################


=head2 kl_send_commad_wait_response

    ($stat,$ret) = kl_send_commad_wait_response($CHnumber,$ASCII_command,$timeout);

Transmits the string $data on the CAN to K-line/LIN card channel

returns status and answer string as ASCII.

=cut

sub kl_send_commad_wait_response {
    my $CHnumber = shift;
    my $ASCII_command = shift;
    my $timeout = shift;
    my ($byte,$data_aref,$offset);
    $timeout = $MAXtimeout unless defined $timeout;

    if(($CHnumber & 0x01) ==1) {$offset=($CHnumber+1)-2;}
    else {$offset=$CHnumber-2;}

    my $send_ID = Kline_base_address + $offset;   
    
    $ASCII_command = sprintf("K%d%s",$CHnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    ($CANstatus,$data_aref) = tsg4can_SendAndWaitForResponse( \@bytes, $send_ID, $send_ID+1, $timeout);
    if ($CANstatus < 0){
        $status = tsg4_check_CAN_status( $CANstatus, "KL_$CHnumber" );
        return ($status,'error');
    }

    my @response = @$data_aref;
    foreach $byte (@response){
        if ($byte == 0){
            $byte = ""; #skip zero bytes
        }
        else{
            $byte = chr($byte);
        }
    }
# printf( "<- %s\n",join('',@response));
    
    return (0,join('',@response));
    
}


=head2 kl_send_commad

    ($stat,$receive_ID) = kl_send_commad($CHnumber,$ASCII_command);

    e.g. ($status,$receive_ID) = kl_send_commad(3,'?00');

Transmits the string $data on the CAN to K-line/LIN card channel

returns status and answer ID.

=cut

sub kl_send_commad {
    my $CHnumber = shift;
    my $ASCII_command = shift;
    my ($byte,$offset);

    if(($CHnumber & 0x01) ==1) {$offset=($CHnumber+1)-2;}
    else {$offset=$CHnumber-2;}

    my $send_ID = Kline_base_address + $offset;   
    
    $ASCII_command = sprintf("K%d%s",$CHnumber,$ASCII_command);
#    printf( "-> 0x%02x $ASCII_command\n",$send_ID);
    
    my @bytes = split(//, $ASCII_command);
    foreach $byte (@bytes){
        $byte = ord($byte);
    }
    while (scalar(@bytes)<8){
        push (@bytes,0);
    }
    
    unshift (@bytes,8);
    
    $CANstatus = tsg4can_SendMessage( \@bytes, $send_ID, 0 );
    $status = tsg4_check_CAN_status( $CANstatus, "KL_$CHnumber" );
    return ($status,$send_ID+1);
    
}





1;


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut



