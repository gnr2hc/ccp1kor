# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2012  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package LIFT_vector_canstress;

use strict;
use LIFT_general;
use LIFT_equipment;
use File::Basename;
use Cwd;
use File::Copy;
use Win32::OLE;
use Win32::Process;

use Data::Dumper;

use vars qw($VERSION $HEADER @ISA @EXPORT);
use Exporter;

# next 2 lines edited by CVS, DO NOT MODIFY
@ISA = qw(Exporter);
@EXPORT = qw(
                VCS_canstress_init
                VCS_start_application
                VCS_close_application
                VCS_open_configuration
                VCS_start_disturbance
                VCS_stop_disturbance
                VCS_check_running
                VCS_disturbance_configure
                VCS_connection_hardware
                VCS_disconnection_hardware
                VCS_return_ole
                VCS_start_trigger
            );
            
my $CANstress_tool_control;
my $OLE_handle;
my $LIFT_temp_path  = $LIFT_general::LIFT_TEMP_PATH;
my $LIFT_store_path = $main::LIFT_ATD_TEMP;

#####################################################################

=head1 NAME

LIFT_vector_canstress 

Provide LIFT useful functions for CANStress.

=head1 SYNOPSIS

   use LIFT_vector_canstress;

      VCS_canstress_init                 
      VCS_start_application              
      VCS_get_application_version       
      VCS_close_application             
      VCS_open_configuration            
      VCS_read_configuration            
      VCS_start_disturbance              
      VCS_stop_disturbance              
      VCS_get_device_for_OLE_handle     
      VCS_get_hostname_for_OLE_handle   
      VCS_check_running                 
      VCS_disturbance_configure          
      VCS_connection_hardware           
      VCS_check_connection              
      VCS_disconnection_hardware         
      VCS_start_trigger                 
      VCS_stop_trigger
                     
=cut

######################################################

=head2 VCS_canstress_init

    VCS_canstress_init ( $device , $function , $type);
    
    Initializes $device for CANStress disturbances.
    
    Supported devices: VECTOR CANStress
    
    The CANStress is loaded on the corresponding host and is configured with the default configuration.
    The Port number and Baud rates are also configured and the hardware connected. 

=cut

######################################################

sub VCS_canstress_init
{
   my $device = shift;     ## expect 'CANStress'
   my $function = shift;   ## expect just 'disturbance'
   my $type = shift;       ## expect just 'CAN'

   my (
        $hostname ,
        $config_file ,
        $OLE_handle ,
        $currently_loaded_device ,
        $keep_application_after_test ,
        $port_num,
        $baud_rate,
        $Connection_Type ,
      );


    unless( $device =~ /CANStress/i ) {
        S_set_error( " wrong device '$device' (just 'CANStress' allowed)\n" , 135);
        return;
    }

    my $testbench = S_get_contents_of_hash( [], $LIFT_config::LIFT_Testbench );

    unless( $hostname = $testbench->{'Devices'}{$device}{'Hostname'} ) {
        S_set_error( " VCS_canstress_init: No 'Hostname' defined for Device '$device'\n" , 135);
        return;
    }

    if( $currently_loaded_device = $CANstress_tool_control->{'Hostname'}{$hostname} ) {
        S_w2log( 3, " VCS_canstress_init: $device application on host '$hostname' already started\n" );
        $OLE_handle = $CANstress_tool_control->{'Devices'}{$device}{'OLE_handle'};
    }

    $OLE_handle = VCS_start_application( $device , $hostname  ) || return;

    VCS_get_application_version ( $OLE_handle ) || return;

    unless( $config_file = $testbench->{'Devices'}{$device}{'Default_Config_File'} ) {
         S_set_error( " VCS_canstress_init: No 'Default_Config_File' defined for Device '$device'\n" , 135 );
        return;
    }

    S_w2log( 3, " VCS_canstress_init: 'Default_Config_File' set to '$config_file'\n" );

    VCS_open_configuration( $OLE_handle , $config_file , 1 ) || return;

    $CANstress_tool_control->{'Devices'}{$device}{'DefaultConfig'} = $config_file;
    
    unless( $Connection_Type = $testbench->{'Devices'}{$device}{'Connection_Type'} ) {
        S_set_error( " VCS_canstress_init: No 'Connection_Type' ('USB' or 'Serial') defined for Device '$device'\n" , 135 ); return;
    }
    
    unless( $Connection_Type =~ /USB|Serial/ ) {
        S_set_error( " VCS_canstress_init: 'Connection_Type' must be 'USB' or 'Serial' (set is '$Connection_Type') for Device '$device'\n" , 135 ); return;
    }

    if( $Connection_Type =~ /Serial/ ) {
        unless($port_num = $testbench->{'Devices'}{$device}{'Connection_Type'}) {
            S_set_error( " VCS_canstress_init: No 'Port number' defined for Device '$device'\n" , 135 ); return;
        }

        unless($port_num = $testbench->{'Devices'}{$device}{'Port_Number'}) {
            S_set_error( " VCS_canstress_init: No 'Port number' defined for Device '$device'\n" , 135 ); return;
        }

        unless($baud_rate = $testbench->{'Devices'}{$device}{'Baud_Rate'}) {
            S_set_error( " VCS_canstress_init: No 'Port number' defined for Device '$device'\n" , 135 ); return;
        }

        VCS_connection_hardware( $OLE_handle , 'Serial' , $port_num , $baud_rate) || return;
    }
    
    if( $Connection_Type =~ /USB/ ) {
        VCS_connection_hardware( $OLE_handle , 'USB' ) || return;
    }

    if( $keep_application_after_test = $testbench->{'Devices'}{$device}{'Keep_Application_After_Test'} )  {
        $CANstress_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} = 1;
    }
    else {
        $CANstress_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} = 0;
    }
    
    return 1;
}

######################################################

=head2 VCS_start_application

VCS_start_application ( $device , $hostname );

The CANStress application is started, its OLE Handle obtained, and testbench updated

=cut

######################################################

sub VCS_start_application
{
    my $device = shift;     ## expect just 'CANalyzer' + 'CANoe'
    my $hostname = shift;
    
    my (
        $vector_cantool_OLE_call ,
        $device_already_running ,
        $OLE_handle ,
       );
        
    unless( $device =~ /CANStress/i ) {
        S_set_error( " VCS_start_application: wrong device '$device' (just 'CANStress' allowed)\n" , 135 );
        return;
    }
    
    S_ping ($hostname) || S_set_error( " Could not reach host '$hostname'  \n may be just a network problem with 'ping'-function \n anyway - try to load config again..\n" , 0 );     
    
    if( $device_already_running = $CANstress_tool_control->{'Hostname'}{$hostname} ) {
        S_set_error( " VCS_start_application: Couldnt load a second CAN tool application on host '$hostname' ($device_already_running is active) \n" , 136 );
        return;
    }
    
    unless( $OLE_handle = S_create_OLE( 'CANstress.Application', $hostname , \&VCS_close_application ) ) {
        S_w2log( 1, " VCS_start_application: Could not reach host '$hostname' \n" );      
        return;
    }
    
    $CANstress_tool_control->{'Devices'}{$device}{'OLE_handle'} = $OLE_handle;
    $CANstress_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'} = $device;
    $CANstress_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'} = $hostname;
    $CANstress_tool_control->{'Hostname'}{$hostname} = $device;
    
    return $OLE_handle;
}


###-----------------------------------------------------------------------------
sub VCS_get_application_version {
###-----------------------------------------------------------------------------
    my ( $OLE_handle ) = shift @_ ;
    
    my ($SW_version);

    return 1 if $main::opt_offline;
    
    S_w2log( 5 , " VCS_get_application_version: OLE_handle -> Application -> SoftwareVersion() ..\n" );
    $SW_version = $OLE_handle -> Application -> SoftwareVersion();
    S_get_LastError_OLE();
    
    unless( $SW_version ) { S_set_error( "Coudl not read SoftwareVersion" , 136 ); return; }
    
    S_w2log( 3 , " VCS_get_application_version: CANstress version --> $SW_version <--\n" );
        
    return $SW_version;
    
}

######################################################

=head2 VCS_close_application

    VCS_close_application ( $OLE_handle);
    
    The CANStress application is closed, hardware disconnected and testbench cleared

=cut

######################################################
sub VCS_close_application {
    my ( $OLE_handle ) = shift @_ ;

    return 1 if $main::opt_offline;
    
    my $device   = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
    my $hostname = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
    
    S_w2log( 5, "VCS_close_application: OLE_handle -> Disturbance -> Finished() .. \n" );
    if( $OLE_handle -> Disturbance -> Finished() ) {
        S_get_LastError_OLE();
        S_w2log( 4, "VCS_close_application: $device Stop Disturbance on $hostname \n" );
        S_w2log( 5, "VCS_close_application: OLE_handle -> Disturbance -> Stop() .. \n" );
        $OLE_handle -> Disturbance -> Stop();
        S_get_LastError_OLE();
        
        VCS_disconnection_hardware( $OLE_handle );
    }

    unless( $CANstress_tool_control->{'Devices'}{$device}{'Keep_Application_After_Test'} )  {
        S_w2log( 2, "VCS_close_application: $device on $hostname Quit Application \n" );
        S_w2log( 5, "VCS_close_application: OLE_handle -> Application -> Quit() .. \n" );
        my $result = $OLE_handle -> Application -> Quit();
        S_get_LastError_OLE();
    }

    delete $CANstress_tool_control->{'OLE_handles'}{$OLE_handle};
    delete $CANstress_tool_control->{'Hostname'}{$hostname};
    delete $CANstress_tool_control->{'Devices'}{$device}{'OLE_handle'};

    return 1;
}

######################################################

=head2 VCS_open_configuration

    VCS_open_configuration ( $device , $config_file , $visible_mode );
    
    The configuration file passed to the function is loaded onto the device. In case 
    not run in the LIFT PC, it is copied to a remote folder in the LIFT PC

=cut

######################################################
sub VCS_open_configuration {

    my (  
         $OLE_handle ,
         $config_file ,
         $visible_mode ,
        ) = @_ ;

    my (   
         $device ,
         $hostname,
         $read_config_fullname ,
         $already_running_config ,
         $currently_loaded_device,
         $config_path1,
         $config_path,
         $temp_dir,
         $remote_file,
      );
      
    return 1 if $main::opt_offline;

    unless( defined $config_file ) {
        S_set_error( " SYNTAX: VCS_open_configuration( cantool_OLE_handle, config_file , [visible_mode])", 110 ); return;
    } 
        
    unless ($hostname = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'}) {
        S_set_error(" VCS_open_configuration: CANstress_tool_control->{'OLE_handles'}{ OLE_handle }{'Hostname'} not set -> VCS_start_application() correct \n", 135); return;
    }
    
    unless ($device = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'}) {
        S_set_error(" VCS_open_configuration: CANstress_tool_control->{'OLE_handles'}{OLE_handle}{'DeviceType'} not set -> VCS_start_application() correct \n", 135); return;
    }
    
    unless( $currently_loaded_device = $CANstress_tool_control->{'Hostname'}{$hostname} ) {
       S_set_error( " VCS_open_configuration: No currently loaded device\n" , 136 ); return;
    }

    unless( -f $config_file ) {
        unless( $config_path1 = $LIFT_config::LIFT_CANSTRESS_CONFIG_path ) {
            S_set_error(" LIFT_config::LIFT_CANSTRESS_CONFIG_path not set, used for loading CANstress config" , 135); return;
        }
        unless( -d $config_path1 ) {
            S_set_error(" $LIFT_config::LIFT_CANSTRESS_CONFIG_path doesn not exists" , 135); return;        
        }
        
        if( $config_path1 =~ /^\./ ) {
            $config_path1 =~ s/\.//;
            $config_file = cwd().$config_path1.$config_file;
        } #if path is a relative path (begins wih ./)
        else {
            $config_file = $config_path1.$config_file;
        }        
      	
   	    if( $LIFT_config::LIFT_host ne $hostname ){
            $temp_dir = "\\\\$hostname\\$LIFT_temp_path";   
            $temp_dir =~ s/:/\$/g;
            unless (-d $temp_dir){
                 unless( mkdir $temp_dir , 0777 ) { S_set_error( "VCS_open_configuration: mkdir $temp_dir failed" , 1 ); return }
            }
            $remote_file = $temp_dir.basename( $config_file );
    #         $remote_file = "\\\\$hostname\\$LIFT_temp_path".basename( $config_file );
    #         $remote_file =~ s/:/\$/g;
            
            S_w2log( 5, "VCS_open_configuration: copy file from '$config_file' to '$remote_file'\n");
            
            unless( copy( "$config_file" , "$remote_file" ) ) {
                S_set_error( "VCS_open_configuration: could not copy from '$config_file' to '$remote_file'", 1 ); return;
            }
            $config_file = $remote_file;
        }
      	
        unless( -f $config_file)  { 
            S_set_error( " No such config file exist! $config_file", 135 ); return;
        }
        S_w2log( 4, " VCS_open_configuration: use config file '$config_file' \n"); 
    }    
           
    if( $already_running_config = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} ) {
        if( basename( $already_running_config ) eq basename( $config_file ) ) {
            S_w2log( 4, " VCS_open_configuration: $device config '$config_file' already loaded -> return \n" );
            return 1;
        }
    }

    S_w2log( 4, " VCS_open_configuration: $device on $hostname Opening config '$config_file' \n" );
    S_w2log( 5, " VCS_open_configuration: OLE_handle -> Application -> Open( $config_file ) .. \n" );
    $OLE_handle -> Application -> Open( $config_file );   
    if( S_get_LastError_OLE( "CANStress OLE error check :\n" ) ) {
        S_set_error( "CANStress OLE error" , 136 ); 
        return;
    }
    
    $read_config_fullname = VCS_read_configuration( $OLE_handle ) || return;
    
    ## return when loaded config doesnt correspond with required config
    ##  (CANtool is loading mostly a default config)
    unless( lc basename( $config_file ) eq lc basename( $read_config_fullname ) ) {
        S_wait_ms( 1000 );  # try to read current config 2nd time
        $read_config_fullname = VCS_read_configuration( $OLE_handle ) || return;
        unless( lc basename( $config_file ) eq lc basename( $read_config_fullname ) ) {
            S_set_error( " $device Loading config '$config_file' failed (currently loaded config: '$read_config_fullname') ", 136 );  return;
        }
    }
    
    $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'} = $config_file ;
    
    return 1;
}

######################################################

=head2 VCS_read_configuration

    VCS_read_configuration ( $OLE_handle );

    The function reads the name of the configuration file currently loaded

=cut

######################################################
sub VCS_read_configuration {

    my ( $OLE_handle ) = shift @_ ;
    
    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_read_configuration( cantool_OLE_handle )", 110 ); return;
    }
    
    my $device = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
    my $hostname = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
    
    return 1 if $main::opt_offline;
    
    S_w2log( 5, " VCS_read_configuration: FullName = OLE_handle -> Application -> Configuration -> { 'FullName' } .. \n" );
    my $FullName = $OLE_handle -> Application -> Configuration -> { 'FullName' };
    S_get_LastError_OLE();
    
    unless( defined $FullName ) {
        S_set_error( " '$device' on $hostname Couldnt read currently loaded configuration: $! ", 136 );  return;
    }
    
    S_w2log( 4, " VCS_read_configuration: $device '$FullName' (host: $hostname)\n" );
    
    return $FullName;
}

######################################################

=head2 VCS_start_disturbance

    VCS_start_disturbance ( $OLE_handle );
    
    The disturbance is started in the application, if not yet started. 

=cut

######################################################
sub VCS_start_disturbance
{
    my ( $OLE_handle ) = shift @_ ;
    
    my ( $device , $hostname );

    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_start_disturbance( cantool_OLE_handle )", 110 ); return;
    }

    $device = VCS_get_device_for_OLE_handle( $OLE_handle );
    $hostname = VCS_get_hostname_for_OLE_handle( $OLE_handle );
    
    if( VCS_check_running( $OLE_handle ) == 2 ) {
        S_w2log( 4, " VCS_start_disturbance : disturbance has been started already ( $device on $hostname )\n" );
        return 1;   
    }
    
    S_w2log( 3, " VCS_start_disturbance : start $device disturbance on $hostname\n" );
    
    return 1 if $main::opt_offline;

    S_w2log( 5, " VCS_start_disturbance : OLE_handle -> Disturbance -> Start() .. \n" );
    $OLE_handle -> Disturbance -> Start();
    S_wait_ms( 100 );
    if( my $err = S_get_LastError_OLE() )
    {  
        S_wait_ms( 1000 );
        S_w2log( 5, " VCS_start_disturbance : trying 2nd time : OLE_handle -> Disturbance -> Start() .. \n" );
        $OLE_handle -> Disturbance -> Start();
        if( $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt start '$device' CAN disturbance on $hostname" , 136 ); return; 
        } 
    }
    
    unless( VCS_check_running($OLE_handle) > 0) {
        S_set_error( " Couldnt start '$device' CAN disturbance on '$hostname'" , 136 ); return;    
    } 
    
    return 1;
}

######################################################

=head2 VCS_stop_disturbance

    VCS_stop_disturbance ( $OLE_handle );
    
    The currently running disturbance is stopped.  

=cut

######################################################
sub VCS_stop_disturbance {

    my ( $OLE_handle ) = shift @_ ;

    my @devices;

    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_stop_disturbance( cantool_OLE_handle )", 110 );
        return;
    }
    
    if ( VCS_check_running( $OLE_handle ) < 2 ) {
        S_w2log( 3, " VCS_stop_disturbance : disturbance has been stopped already \n" );
        return 1;
    }

    my $device = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'DeviceType'};
    my $hostname = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
    
    S_w2log( 3, " VCS_stop_disturbance : Stop $device disturbance on $hostname .. \n" );
    
    return 1 if $main::opt_offline;

   S_w2log( 5, " VCS_stop_disturbance : OLE_handle -> Disturbance -> Stop() .. \n" );
   $OLE_handle -> Disturbance -> Stop();
   if( my $err = S_get_LastError_OLE() ) {  
        S_wait_ms( 1000 );
        S_w2log( 5, " VCS_stop_disturbance : trying 2nd time : OLE_handle -> Measurement -> Stop() .. \n" );
        $OLE_handle -> Disturbance -> Stop();
        if( my $err = S_get_LastError_OLE() ) {
            S_set_error( " Couldnt stop '$device' CAN disturbance on '$hostname'" , 136 );
            return 0; 
        } 
   }

   return 1 if VCS_check_running( $OLE_handle ) < 2;
       
   foreach ( ( 100 , 200 , 500 , 1500 , 5000 ) ) {
       S_wait_ms( $_ );
       return 1 if VCS_check_running( $OLE_handle ) < 2;
       S_w2log( 4, " VCS_stop_disturbance : disturbance is still running ?!?! \n" );
   }
   S_set_error( "could not stop disturbance" , 136);
   return;
}

######################################################

=head2 VCS_get_device_for_OLE_handle

VCS_get_device_for_OLE_handle ( $OLE_handle );

Gets the device corresponding to a particular OLE Handle  

=cut

######################################################
sub VCS_get_device_for_OLE_handle {

    my ( $OLE_handle ) = shift @_ ;
    
    my $device;
    
    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_get_device_for_OLE_handle( CAN_tool_application ) ['CANStress]", 110 );  return;
    }
    
    unless( $device = $CANstress_tool_control->{'OLE_handles'}{$OLE_handle}{'DeviceType'} )  {
        S_set_error( " Could not get device for OLE_Handle\n" , 135 ); return;
    }
    
    return $device;
}

######################################################

=head2 VCS_get_hostname_for_OLE_handle

    VCS_get_hostname_for_OLE_handle ( $OLE_handle );
    
    Gets the hostname corresponding to a particular OLE Handle  

=cut

######################################################
sub VCS_get_hostname_for_OLE_handle {

    my ( $OLE_handle ) = shift @_ ;
    
    my $hostname;
    
    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_get_hostname_for_OLE_handle( CAN_tool_application ) ['CANStress]", 110 );  return;
    }
    
    unless( $hostname = $CANstress_tool_control->{'OLE_handles'}{$OLE_handle}{'Hostname'} )  {
        S_set_error( " Could not get Hostname for OLE_Handle\n" , 135 ); return;
    }
    
    return $hostname;
}

###################################################################

=head2 VCS_check_running

VCS_check_running ($OLE_handle);

Checks the current status of the CANStress
    
    0 - Idle State
    1 - Finished
    2 - Pending State    

=cut

###################################################################

sub VCS_check_running {

    my ( $OLE_handle ) = shift @_ ;
    
    my ( 
          $status_finished,
          $status_pending,
          $status_idle,
        );

    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_check_running( cantool_OLE_handle )", 110 ); return;
    }
    
    unless( $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle } ) {
        S_set_error( " invalid OLE handle ", 109 ); return;
    }
    
    return 1 if $main::opt_offline;
   
    my $device = VCS_get_device_for_OLE_handle( $OLE_handle ) || return;
    my $hostname = VCS_get_hostname_for_OLE_handle( $OLE_handle ) || return;

    S_w2log( 5 , "VCS_check_running : OLE_handle -> Disturbance -> Finished / Pending / Idle .. \n" );
    $status_finished = $OLE_handle -> Disturbance -> Finished;
    $status_pending  = $OLE_handle -> Disturbance -> Pending;
    $status_idle     = $OLE_handle -> Disturbance -> Idle;
    if( my $err = S_get_LastError_OLE() )
    {  
        S_wait_ms( 1000 );
        S_w2log( 5 , "VCS_check_running : OLE_handle -> Disturbance -> Finished / Pending / Idle .. \n" );
        $status_finished = $OLE_handle -> Disturbance -> Finished;
        $status_pending  = $OLE_handle -> Disturbance -> Pending;
        $status_idle     = $OLE_handle -> Disturbance -> Idle;
        if( my $err = S_get_LastError_OLE() ) {  
            S_set_error( " OLE exception : '$err' (after OLE_handle -> Disturbance -> Finished|Pending|Idle())" , 136 ); return; 
        }
    }

    S_w2log( 4, " VCS_check_running: Idle Status = $status_idle\n" );
    S_w2log( 4, " VCS_check_running: Finished Status = $status_finished\n" );
    S_w2log( 4, " VCS_check_running: Pending Status = $status_pending\n" );
   
    SWITCH : {
        $status_idle     == 1  
            && S_w2log( 3, " Disturbance on '$device' (Host:'$hostname') is IDLE \n\n" , 'grey' ) 
            && return 0; 
        $status_pending  == 1 
            &&  S_w2log( 3, " Disturbance on '$device' (Host:'$hostname') is PENDING \n\n" , 'orange' ) 
            && return 2; 
        $status_finished == 1 
            && S_w2log( 3, " Disturbance on '$device' (Host:'$hostname') is FINISHED \n\n" , 'blue' ) 
            && return 1; 
    }

    return -1; 
}

######################################################

=head2 VCS_disturbance_configure

    VCS_disturbance_configure ( $device  [ , $config_file , $replace_config ] );
    
    Configures the initial default disturbance.  
    
    $replace_config = {
                        'replace_keywords' => {
                                                '__DISTURBANCE_DURATION_MS__' => 100 ,
                                                } ,
                        'config_file_final' => 'CANStress_ir_CANHigh_100.cst'  ,
                        } ; 

=cut

######################################################
sub VCS_disturbance_configure
{
    my $device  = shift;
    my $given_config = shift;
    my $replace_config = shift;
    
    unless( defined $device ) {
        S_set_error( " SYNTAX: VCS_trace_configure( CAN_tool )", 110 ); return;
    }

    my ( 
        $OLE_handle , 
        $active_configuration , 
        $default_configuration , 
        $config_to_be_loaded , 
        $config_path1 ,
        $final_config_file ,
        $final_config_file_work ,
        $final_config_folder ,
        $keyword ,
        $value ,
        $stored_file_name ,
        );
    
    unless( $OLE_handle = $CANstress_tool_control->{'Devices'}{$device}{'OLE_handle'} ) {
        S_set_error( " no OLE_handle available for '$device'", 135 ); return;
    }

    $active_configuration = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'ActiveConfiguration'};
    $default_configuration = $CANstress_tool_control->{'Devices'}{$device}{'DefaultConfig'};
    
    my $hostname = $CANstress_tool_control->{'OLE_handles'}{ $OLE_handle }{'Hostname'};
      
    if( $given_config ) {
        if( $active_configuration ) {
            if( basename( $active_configuration ) eq basename( $given_config ) ) {
                S_w2log( 3, " VCS_disturbance_configure : config file '$given_config' already loaded \n" );
                return $OLE_handle;
            }
        }
        $config_to_be_loaded = $given_config;           # <<-----------------------------
    }
    else {
        if( $active_configuration and $default_configuration ) {
            if( basename( $active_configuration ) eq basename( $default_configuration ) ) {
                S_w2log( 3, " VCS_disturbance_configure : 'DefaultConfig' ($default_configuration) already loaded \n" );
                return $OLE_handle;
            }
        }
        $config_to_be_loaded = $default_configuration;  # <<-----------------------------
    }

    return $OLE_handle if $main::opt_offline;
    
    unless( -f $config_to_be_loaded ) {
        unless( $config_path1 = $LIFT_config::LIFT_CANSTRESS_CONFIG_path ) {
            S_set_error(" LIFT_config::LIFT_CANSTRESS_CONFIG_path not set, used for loading CANstress config" , 135); return;
        }
        unless( -d $config_path1 ) {
            S_set_error(" $LIFT_config::LIFT_CANSTRESS_CONFIG_path doesn not exists" , 135); return;        
        }
        if( $config_path1 =~ /^\./ ) {
            $config_path1 =~ s/\.//;
            $config_to_be_loaded = cwd().$config_path1.$config_to_be_loaded;
        } #if path is a relative path (begins wih ./)
        else {
            $config_to_be_loaded = $config_path1.$config_to_be_loaded;
        }        
      	unless( -f $config_to_be_loaded)  { 
            S_set_error( " No such config file exist! $config_to_be_loaded", 135 ); return;
        }
        S_w2log( 4, " VCS_disturbance_configure: use config file '$config_to_be_loaded' \n"); 
    }    
    
    if( $replace_config ) {
        unless( $final_config_file = $replace_config -> { 'config_file_final' } ) {
            S_set_error( " 'config_file_final' doesnt exist in given replace_config", 135 ); return;
        }
        if( $final_config_file eq basename($final_config_file) ) {
            $final_config_file = "\\\\$hostname\\$LIFT_temp_path\\".basename($final_config_file);
            $final_config_file =~ s/:/\$/g;
            $final_config_folder =  dirname($final_config_file);
            unless( -d $final_config_folder ) {
                S_w2log( 5, " VCS_disturbance_configure: Creating directory $final_config_folder\n" );                
                unless( mkdir( $final_config_folder ) , 777 ) { S_set_error( "mkdir $final_config_folder", 136 ); return; } 
            }
            S_w2log( 5, " VCS_disturbance_configure: Preparing final config file for $device on $hostname : $final_config_file\n" );                
        } else { S_w2log( 5, " VCS_disturbance_configure: complete file name was given : $final_config_file\n" ) }
        
        $final_config_file_work = $final_config_file."_work";
        
        S_w2log( 5, " Copying $config_to_be_loaded --> $final_config_file_work ... \n" );
        unless( copy( $config_to_be_loaded , $final_config_file_work ) ) { S_set_error( "copy( $config_to_be_loaded , $final_config_file_work )", 136 ); return; }
        
        foreach $keyword ( keys %{$replace_config ->{'replace_keywords'}} ) {

            $value = $replace_config ->{'replace_keywords'}{$keyword};            
            unless( defined $value ) {
                S_set_error( "no value defined for replace_config ->{'replace_keywords'}{$keyword}", 136 ); return;                
            }
            
            S_w2log( 5, " VCS_disturbance_configure: Opening $final_config_file_work for reading... \n" );
            unless( open( CST_TEMP , "<$final_config_file_work" ) ) { S_set_error( "open( CST_TEMP , $final_config_file_work", 136 ); return; }        
    
            S_w2log( 5, " VCS_disturbance_configure: Opening $final_config_file for writing... \n" );
            unless( open( CST_FINAL , ">$final_config_file" ) ) { S_set_error( "open( CST_FINAL , $final_config_file) : $! ", 136 ); return; }        
    
            while( <CST_TEMP> ) {
                s/$keyword/$value/g && S_w2log( 5, " REPLACED $keyword --> $value\n" );
                print CST_FINAL;
            }
            
            unless( close CST_TEMP ) { S_set_error( "close CST_TEMP", 136 ); return; };
            unless( close CST_FINAL ) { S_set_error( "close CST_FINAL", 136 ); return; };
                        
            S_w2log( 5, " VCS_disturbance_configure: Copying $config_to_be_loaded --> $final_config_file_work ... \n" );
            unless( copy( $final_config_file , $final_config_file_work ) ) { S_set_error( "copy( $final_config_file , $final_config_file_work ) : $!", 136 ); return; }
        }
        S_w2log( 5, " VCS_disturbance_configure: Deleting $final_config_file_work ... \n" );
        unless( unlink( $final_config_file_work ) ) { S_set_error( "unlink( $final_config_file_work ) : $! ", 136 ); return; }        
        $config_to_be_loaded = $final_config_file;
    }
    
    #
    # OPEN CONFIG
    #
    VCS_open_configuration( $OLE_handle , $config_to_be_loaded , 1 ) || return;
    
    unless( -d $LIFT_store_path ) {
        S_w2log( 5, " VCS_disturbance_configure: Creating directory '$LIFT_store_path' ... \n" );
        unless( mkdir( $LIFT_store_path , 777 )) { S_set_error( "mkdir( $LIFT_store_path , 777 )", 136 ); return; }
    }
    $stored_file_name = $LIFT_store_path."/".basename($final_config_file); 
    S_w2log( 3, " VCS_disturbance_configure: Copying $final_config_file -> $stored_file_name ... \n" );
    unless( copy( $config_to_be_loaded , $stored_file_name  ) ) { S_set_error( "copy( $final_config_file , $stored_file_name  ): $!", 136 ); return; }           
      
    return $OLE_handle;
}

######################################################

=head2 VCS_connection_hardware

    VCS_connection_hardware ( $OLE_handle , USB|Serial  [, $port_num , $baud_rate ] );
    
    The CANStress Hardware is connected via USB or Serial (Port number and Baudrate required)

=cut

######################################################
sub VCS_connection_hardware {

    my (  
        $OLE_handle ,
        $Connection_Type ,
        $port_num ,
        $baud_rate,
        ) = @_ ;
    
    unless( defined $Connection_Type ) {
        S_set_error( " SYNTAX: VCS_connection_hardware( OLE_handle , USB|Serial [ , portnum , baudrate ] )", 110 );  return;
    }
        
    if( VCS_check_connection($OLE_handle) ) {
        S_w2log( 3, " VCS_connection_hardware : CANStress Hardware is already connected\n" );
        return 1;
    }
      
    if( $Connection_Type =~ /Serial/ ) {
        S_w2log( 4, " VCS_connection_hardware: set OLE_handle -> Connection ->{'Port'} = $port_num \n" );
        $OLE_handle -> Connection ->{'Port'} = $port_num;
        S_w2log( 4, " VCS_connection_hardware: set OLE_handle -> Connection ->{'Baudrate'} = $baud_rate \n" );
        $OLE_handle -> Connection ->{'Baudrate'} = $baud_rate;
    }
    
    S_w2log( 4, " VCS_connection_hardware: calling OLE_handle -> Connection -> Connect()... \n" );
    $OLE_handle -> Connection -> Connect();
    S_get_LastError_OLE();

    unless ( VCS_check_connection($OLE_handle) ) {
        S_set_error( " VCS_connection_hardware: Unable to establish Hardware connection! \n " , 136 ); return;
    }

    S_w2log( 3, " VCS_connection_hardware: CANStress Hardware successfully connected \n" );
    
    return 1
}

###-----------------------------------------------------------------------------
sub VCS_check_connection {
###-----------------------------------------------------------------------------
    my (  
        $OLE_handle ,
        ) = @_;

    return 1 if $main::opt_offline; # just return if running in offline mode
             
    S_w2log( 5, " VCS_check_connection: checking connection state \n" );
    my $state = $OLE_handle -> Connection -> Connected;
    S_get_LastError_OLE();
    
    if   ( $state == 0 ) { S_w2log( 4, " VCS_check_connection: Hardware is NOT connected\n" ) }
    elsif( $state == 1 ) { S_w2log( 4, " VCS_check_connection: Hardware is connected\n" ) }
    else { S_set_error( "unexpected connection state '$state'" , 136 ); return }
    
    return $state;    
}

######################################################

=head2 VCS_disconnection_hardware

    VCS_disconnection_hardware ( $OLE_handle );
    
    The CANStress Hardware is disconnected

=cut

######################################################
sub VCS_disconnection_hardware
{
    my ( $OLE_handle ) = shift @_ ;

    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_disconnection_hardware ( cantool_OLE_handle )", 110 );    return;
    }
    
    unless( VCS_check_connection($OLE_handle) ) {
        S_w2log( 3, " VCS_connection_hardware : CANStress Hardware is already disconnected\n" );
        return 1;
    }

    S_w2log( 5, " VCS_check_connection: calling Disconnect()... \n" );
    $OLE_handle -> Connection -> Disconnect();
    S_get_LastError_OLE();
    
    if ( VCS_check_connection($OLE_handle) ) {
        S_set_error( " VCS_connection_hardware: Unable to disconnect Hardware! \n " , 136 ); return;
    }
        
    return 1;

}

######################################################

=head2 VCS_start_trigger

    VCS_start_trigger ( $OLE_handle );
    
    The Software trigger is initiated while running the loaded disturbance

=cut

######################################################
sub VCS_start_trigger {

    my ( $OLE_handle ) = shift;

    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_start_disturbance( cantool_OLE_handle )", 110 ); return;
    }
    
    S_w2log( 3, " VCS_start_trigger: Activate Trigger (1 time for Edge Trigger / Set for level Trigger) \n" );

    if( VCS_check_running( $OLE_handle ) == 2 ) {
        S_w2log( 5, " VCS_start_trigger: OLE_handle -> Disturbance -> Trigger() .. \n" );
        $OLE_handle -> Disturbance -> Trigger();
        if( my $err = S_get_LastError_OLE() ){
            S_set_error( "VCS_start_trigger:Couldn't 'Trigger' CANStress\n" , 131 ); return 0; 
        } 
        return 1;           
    }
    else{
        S_w2log( 3, " VCS_start_trigger: CANStress is not in 'Pending' State. No Trigger possible!!! \n" ); 
    }  

    return 1;
}

######################################################

=head2 VCS_stop_trigger

    VCS_stop_trigger ( $OLE_handle );
    
    The Software trigger can be stopped using this function if the disturbance is configured as Software Level Triggered.

=cut

######################################################

sub VCS_stop_trigger{
    my ( $OLE_handle ) = shift;
    
    unless( defined $OLE_handle ) {
        S_set_error( " SYNTAX: VCS_start_disturbance( cantool_OLE_handle )", 110 ); return;
    }
    

    if( VCS_check_running( $OLE_handle ) == 2 ) {
        S_w2log( 5, " VCS_start_trigger: OLE_handle -> Disturbance -> StopTrigger() .. \n" );
        $OLE_handle -> Disturbance -> StopTrigger();
        return 1;           
    }
  
    return 0;
}
1;

# Preloaded methods go here.

1;
__END__


=head1 AUTHORS

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

=head1 NOTES

The "BEGIN" section contains the Statements which to be executed before the start of program execution

=head1 SEE ALSO

perl documentation

=cut 
