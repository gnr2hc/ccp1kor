package IDEFIX;

use strict;
use warnings;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use IDEFIX ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
        idx_Start
        idx_End
        idx_IniUSB
        idx_GetDescription
        idx_PrepInject
        idx_TriggerInject
        idx_GetInjectProgress
        idx_GetErrortext
        idx_LoadConfig
        idx_GetInjectError
        idx_GetVersion
        idx_GetFirmware
        idx_SetUserEvent
        idx_SetOutput
        idx_getPMrevision
        idx_getXSrevision
        idx_getCWrevision
        idx_WriteEEProm
        idx_ReadEEPromByte
        idx_GetEEPromState
        idx_WriteByAddress
        idx_ReadByAddress
        idx_WriteRAMBlock
        idx_ReadRAMBlock
        idx_PASEnabling
        idx_SetPASMode
        idx_ResetFPGA
        idx_ResetDevice
        idx_ReadPasState
);
our $VERSION = '1.2';

bootstrap IDEFIX $VERSION;

# Preloaded methods go here.

sub idx_getPMrevision{
    return ('SCM');
}

sub idx_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub idx_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

1;
__END__

=head1 NAME

IDEFIX - Perl extension for IDEfix sensor simulator

=head1 SYNOPSIS

  use IDEFIX;

=head1 DESCRIPTION

All these functions are wrapped around IdefixInterface.dll APIs.



=head2 idx_End

    $status = idx_End();

unload IdefixInterface.DLL



=head2 idx_GetDescription

    ($status, $SerialNumber) = idx_GetDescription($Device);

Gets the serial number (as string) of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_GetEEPromState

    $status = idx_GetEEPromState($Device);

Gets the serial number (as string) of the requested USB device. $Device = Idefix index 0..1

Return: =  0 Idle, 1 Busy,  -1 Error



=head2 idx_GetErrortext

    $Errortext = idx_GetErrortext($errornumber);

Returns the Description of any error code (<0)



=head2 idx_GetFirmware

    $Firmware = idx_GetFirmware($Device));

Gets the firmware revision (as string) of the requested USB device. $Device = Idefix index 0..1



=head2 idx_GetInjectError

    $ErrorCode = idx_GetInjectError());

Returns the Crash Injection Error Code



=head2 idx_GetInjectProgress

    $status = idx_GetInjectProgress();

Returns the Crash Injection Progress: 0 .. 100 [%], at 100% Thread is finished
  
     0 =    Thread is started
     1 =    Crash Memory is build
     2=     Crash time = 0
     3..99  Linear Procentage of the Crash Time
     100    Thread is finished



=head2 idx_GetVersion

    ($status, $version) = idx_GetVersion();

returns IdefixInterface.DLL version



=head2 idx_IniUSB

    $Devices = idx_IniUSB();

Initialize the USB Interface and searches for the Idefix Devices, call only once at the beginning before any other function   

Return: >= 0 Number of Idefix Devices,  -1 Error



=head2 idx_LoadConfig

    $status = idx_LoadConfig($configfile);

load IDEfix configuration and resynchronize IDEfix (ECU should be off to avoid sensor faults due to IDEfix reset)



=head2 idx_PASEnabling

    $status = idx_PASEnabling($Device, $Enable_aref);

    $Enable_aref reference to array of 8 values
        0 = PAS is switched off
        1 = PAS is witched on

    e.g. $status = idx_PASEnabling(0, [0,0,1,0,0,0,0,0]);
    enable only 3rd PAS in 1st Idefix

enable/diable PASes on Idefix



=head2 idx_PrepInject

    $status = idx_PrepInject($configfile, $crashfile, $trigger);
    e.g.:  $status = idx_PrepInject('C:\MKS\MLC\FO1000_Frank_71\idefix\fo1000_PAS5_CG102.ifc','',1); # trigger immediately

prepare injection, IDEfix will not be resynchronized, only signal mapping will be taken from config.

 if $crashfile is empty string ('') the crashfile from the Idefix configuration is loaded
 $trigger : 0 -> prepares only the crashbuffer. An additional call of TriggerInject() is necessary.
 $trigger : 1 -> starts the crashinjection immediately after the crashbuffer is prepared.



=head2 idx_ReadByAddress (obsolete)

 obsolete, use idx_ReadRAMBlock instead

    ($status, $value) = idx_ReadByAddress($Device,  $address);
    e.g.: ($stat, $value) = idx_ReadByAddress(0, hex("0x00509A80"));

reads RAM cell (32 bit) (as string) of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_ReadEEPromByte

    ($status, $value) = idx_ReadEEPromByte($Device, �address);
    e.g.: ($status, $value) = idx_ReadEEPromByte(0, hex("0x0"));    

read one EEPROM cell (as string) of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_ReadPasState

    ($status, $States_aref) = idx_ReadPasState($Device)

    $States_aref reference to array of 8 values
      Bit 0   : a_ValidPasSection
      Bit 1   : a_PASEnabled
      Bit 2   : Runtime Counter > 0

read PAS states of Idefix


=head2 idx_ReadRAMBlock

    ($status, $values_aref) = idx_ReadRAMBlock($Device, $numberOfBytes, $address);
    e.g.: ($stat, $values_aref) = idx_ReadRAMBlock(0, 3, hex("0x00509A80"));

reads RAM cell of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_ResetDevice

    $status = idx_ResetDevice($Device);

reset Idefix



=head2 idx_ResetFPGA

    $status = idx_ResetFPGA($Device);

reste FPGA of Idefix



=head2 idx_SetOutput

    $status = idx_SetOutput($Device, $Out1, $Out2);
    e.g.: $status = idx_SetOutput(0, 1, 1);

Set the Ouput of the connectors Out1 and Out2

 Arguments: $Device : Idefix index 0..1
            $Out1   : 1= HighLevel, else LowLevel
            $Out2   : 1= HighLevel, else LowLevel

Return: 0 valid or -1 on any Error



=head2 idx_SetPASMode

    $status = idx_SetPASMode($Device,$busmode,$TS0,$TS1,$TS2,$TS3,$TS4,$TS5,$TS6);

            $busmode: Bus Mode:  0x00AA-> AsynchMode 125 KHz
                                 0x0055-> BusMode    125 KHz
                                 0x0155-> BusMode    189 KHz
            $TS0  Cycle Time: normally 228 in Asynch Mode and 507 in synch Mode
            $TS1  TimeSlot1:  time in usec of Timeslot 1, only relevant in BusMode
            $TS2  TimeSlot2:  time in usec of Timeslot 2, only relevant in BusMode
            $TS3  TimeSlot3:  time in usec of Timeslot 3, only relevant in BusMode
            $TS4  TimeSlot4:  time in usec of Timeslot 4, only relevant in BusMode
            $TS5  TimeSlot4:  time in usec of Timeslot 5, only relevant in BusMode
            $TS6  TimeSlot4:  time in usec of Timeslot 6, only relevant in BusMode

set PAS mode



=head2 idx_SetUserEvent

    $status = idx_SetUserEvent($Device, $Event);

Set User event

Return: 0 valid or -1 on any Error



=head2 idx_Start

    $status = idx_Start();

load IdefixInterface.DLL and initalize function pointers



=head2 idx_TriggerInject

    $status = idx_TriggerInject();

trigger injection



=head2 idx_WriteByAddress (obsolete)

 obsolete, use idx_WriteRAMBlock instead

    $status = idx_WriteByAddress($Device, $address, $value);
    e.g. $status = idx_WriteByAddress(0, hex("0x00509A80"),1);    

Adress to Write (32 Bit), Write Value (32 Bit)

writes RAM cell (32 bit) of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_WriteEEProm

    $status = idx_WriteEEProm($Device,$address,\@values);
    e.g.: $status = idx_WriteEEProm(0, hex(0x0),[0]);
 
Gets the serial number (as string) of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error



=head2 idx_WriteRAMBlock

    $status = idx_WriteRAMBlock($Device, $address, $bytes_aref);
    e.g. $status = idx_WriteRAMBlock(0, hex("0x00509A80"),[1]);    

Adress to Write (32 Bit), 

writes RAM cells of the requested USB device. $Device = Idefix index 0..1

Return: = 0 valid,  -1 Error




=head1 TRACEABILITY FUNCTIONS

=head2 idx_getPMrevision

returns MKS revision number of .pm file

=head2 idx_getXSrevision

returns MKS revision number of .xs file


=head2 idx_getCWrevision

returns MKS revision number of .c wrapper file


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, IDEfix documentation

=cut
