# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_IDEFIX;

use strict;
use warnings;
use LIFT_general;
use Win32::Process;    # for killing IDEfix GUI
use File::Basename;
my $addpath;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use IDEFIX;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_IDEFIX ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  IDX_InitHW
  IDX_CloseHW
  IDX_GetInjectionProgress
  IDX_LoadConfig
  IDX_PrepareInjection
  IDX_TriggerInjection
  IDX_SetOutput
  IDX_ReadByAddress
  IDX_WriteByAddress
  IDX_setPASfault
  IDX_WriteRAMBlock
  IDX_ReadRAMBlock
  IDX_WritePASmemory
  IDX_ReadPASmemory
  IDX_ReadINIT2Data
);

our ( $VERSION, $HEADER );

my $IDX_initialized = 0;
my $MAXretry        = 3;
my $LASTconfig      = 'ERROR';
my ( $stat, $PASsetting, $retryloop );
my $IDXdevices;


=head1 NAME

LIFT_IDEFIX 

Perl extension for IDEfix

=head1 SYNOPSIS

    use LIFT_IDEFIX;

    IDX_InitHW();

    IDX_LoadConfig('my_config.ifc');
    IDX_PrepareInjection('my_config.ifc', 'CSI64264.asc', 0);
    IDX_TriggerInjection();
    $value = IDX_GetInjectionProgress();
    IDX_SetOutput(0, 1, 0);
    $value = IDX_ReadByAddress(0,  '0x00509A80');
    IDX_WriteByAddress(0, '0x00509A80', 1);
    IDX_setPASfault('DUMMY', 'ManchesterError');
    IDX_WriteRAMBlock(0, '0x00509A80', [1]);
    $value = IDX_ReadRAMBlock(0, '0x00509A80', 1);
    IDX_WritePASmemory('DUMMY', 'SensorDefectInfo_U16X', [2,0x3]);

    IDX_CloseHW();


   'IDEFIX' => {
                'FAULTTYPES' =>{
                                'ManchesterError'               =>  {
                                    '1' => {'address'=>'StateSensorFlt_U32X', 'values' => [0,0,0,2]},
                                 },
                },
                'OFFSET' => {
                                'StateSensorFlt_U32X'     => 40,
                },


    <pasName>DUMMY</pasName>
    <pasScript>pas5.c</pasScript>
    <pasEnabled>frue</pasEnabled>

=head1 DESCRIPTION



=head2 IDX_CloseHW

    IDX_CloseHW();

has to be called at the end, will unload IdefixInterface.dll. should be called in ENDcampaign. should have at least 1 second delay to previous IDX function call.

=cut

sub IDX_CloseHW
{

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $IDX_initialized = 0;
        S_w2log( 3, "IDX_CloseHW: Terminated the communication with IDEFIX \n" );
        return 1;
    }

    $stat = idx_End();
    Check_Status($stat);
    S_w2log( 5, "IDX End staus=$stat\n" );
    $IDX_initialized = 0;
    S_w2log( 3, "IDX_CloseHW: Terminated the communication with IDEFIX \n" );

    return 1;
}

=head2 IDX_GetInjectionProgress

    $progress = IDX_GetInjectionProgress();

Returns the Crash Injection Progress: 0 .. 100 [%], at 100% Thread is finished

     0 =    Thread is started
     1 =    Crash Memory is build
     2=     Crash time = 0
     3..99  Linear Procentage of the Crash Time
     100    Thread is finished

offline_return : 100

=cut

sub IDX_GetInjectionProgress
{

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 100;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "IDX_GetInjectionProgress \n" );
        return 100;
    }
    $stat = idx_GetInjectProgress();
    Check_Status($stat);
    S_w2log( 3, "IDX_GetInjectionProgress staus=$stat\n" );
    return ($stat);
}

=head2 IDX_InitHW

    $IDXdevices = IDX_InitHW();

initialize IDEfix hardware, returns number of connected Idefix devices

has to be called before any other IDX command, will load IdefixInterface.dll should be called in INITcampaign

offline_return : 1

=cut

sub IDX_InitHW
{
    my $serialNumber;

    if ($IDX_initialized)
    {
        S_set_warning( "IDEfix already initialized", 120 );
        return ;
    }

    if ($main::opt_offline)
    {
        $IDX_initialized = 1;
        S_w2log( 3, "IDX_InitHWL: Initialized the communication with IDEFIX \n" );
        return 1;
    }

    #kill running idefix application
    my %procs = S_get_Win32_processes();
    if ( exists $procs{'Idefix'} )
    {
        S_w2rep("-> killing IDEfix GUI !!!\n");
        Win32::Process::KillProcess( $_, 0 ) foreach ( @{ $procs{'Idefix'} } );
        S_wait_ms(500);
    }

    #delete remainig gui.lock file if exists
    unlink('C:\Program Files\Idefix_V3\gui.lock');
    unlink('C:\Program Files\Idefix\gui.lock');

    $stat = idx_Start();
    Check_Status($stat);
    S_w2log( 5, "IDX Start staus=$stat\n" );

    for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
    {
        $IDXdevices = idx_IniUSB();
        if ( $IDXdevices > 0 )
        {
            last;    # exit loop if successful
        }
        else
        {
            S_w2log( 5, "idx_IniUSB retry after error\n" );
            S_wait_ms(50);
        }
    }
    if ( $IDXdevices < 1 ) { S_set_error( "could not find IDEFIX", 5 ); return; }

    my $version;
    ( $stat, $version ) = idx_GetVersion();
    Check_Status($stat);
    S_w2log( 5, "($stat) IdefixInterface DLL version:\n $version\n\n" );
    $IDX_initialized = 1;

    if ( $stat < 0 )
    {
        S_set_error( "could not initialize IDEfix", 5 );
        $IDX_initialized = 0;
    }

    for ( my $device = 0 ; $device < $IDXdevices ; $device++ )
    {
        ( $stat, $serialNumber ) = idx_GetDescription($device);
        Check_Status($stat);
        S_w2log( 5, "device $device = $serialNumber\n" );
        ( $stat, $version ) = idx_GetFirmware($device);
        Check_Status($stat);
        S_w2log( 5, "($stat) Idefix $device Firmware version:\n $version\n\n" );
        if ( $stat < 0 )
        {
            S_set_error( "could not initialize IDEfix", 5 );
            $IDX_initialized = 0;
        }
    }

    S_w2log( 3, "IDX_InitHWL: Initialized the communication with IDEFIX \n" );

    return ($IDXdevices);

}

=head2 IDX_LoadConfig

    IDX_LoadConfig($configfile);

load IDEfix configuration and resynchronize IDEfix (ECU should be off to avoid sensor faults due to IDEfix reset)

=cut

sub IDX_LoadConfig
{
    my $configfile  = shift;
    my $idx_counter = 0;
    my $idx_struct  = {};

    unless ( defined($configfile) )
    {
        S_set_error( "! too less parameters ! SYNTAX: values = IDX_LoadConfig( \$configfile )", 110 );
        return 0;
    }
    unless ( -f $configfile )
    {
        S_set_error( "configfile <$configfile> not found", 1 );
        return 0;
    }

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "IDX_LoadConfig ($configfile)\n" );

    S_w2log( 5, "parsing IDEFIX configuration to create symbolic access table\n" );

    #parse configuration for symbolic access
    my ( $help, $line, $device, $scriptnr );
    if ( open( IN, "<$configfile" ) )
    {
        $PASsetting = ();
        while (<IN>)
        {
            #search for <pasName> e.g. <pasName>PAS1_UFSL</pasName>
            # empty = <pasName />
            if ( $_ =~ /<pasName>(.*)<\/pasName>/ or $_ =~ /<pasName(.*)\/>/ )
            {
                $help = $1;

                #check for pasEnable

                #    <pasName>PAS3</pasName>
                #    <pasScript>pas5.c</pasScript>
                #    <pasEnabled>false</pasEnabled>

                $line = <IN>;    #<pasScript>
                $line = <IN>;    #<pasEnabled>
                if ( $line =~ /<pasEnabled>(.*)<\/pasEnabled>/ )
                {
                    if ( lc($1) eq "false" )
                    {
                        S_w2log( 5, "skipping PAS $help (disabled)\n" );
                    }
                    else
                    {
                        # if PAS is enabled and Name is unique, add to hash
                        unless ( defined $PASsetting->{$help} )
                        {
                            S_w2log( 5, "adding PAS $help\n" );
                            $PASsetting->{$help} = {};
                        }
                        else { S_set_error( "PAS name $help is not unique in IDEFIX configuration", 1 ) }
                    }
                }
                else { S_set_error( "could not find <pasEnabled> staus for $help, configuration file error", 1 ); }
            }

            if ( $_ =~ /<SensorID>PAS\((\d+),(\d+),00\)<\/SensorID>/ )
            {
                $device   = $1;
                $scriptnr = $2;

                #     <SensorID>PAS(0,0,00)</SensorID>
                #     <FileColumn>0</FileColumn>
                #     <AssignedChannel>-1</AssignedChannel>
                #     <SensorName>PPS2_left_TS3</SensorName>
                #-->PAS(0=device,0=scriptnr ...

                $line = <IN>;    #<FileColumn>
                $line = <IN>;    #<AssignedChannel>
                $line = <IN>;    #<SensorName>
                if ( $line =~ /<SensorName>(.*)<\/SensorName>/ )
                {
                    $help = $1;

                    # skip PASes which are not found in previous if statement, because they are disabled
                    if ( exists $PASsetting->{$help} )
                    {
                        $PASsetting->{$help}{'device'}       = $device;
                        $PASsetting->{$help}{'scriptnumber'} = $scriptnr;
                    }
                }
                else { S_set_error( "could not find SensorName for <SensorID>PAS($device,$scriptnr,00), configuration file error", 1 ); }

            }

            #search for <PasModeTable> and assing values to according idefix
            if ( $_ =~ /<PasModeTable>/ )
            {
                $line = <IN>;    #<pasMode>
                if ( $line =~ /<pasMode>(.*)<\/pasMode/ )
                {
                    $help = $1;
                    if ( $help eq 'S125k' )
                    {
                        $idx_struct->{$idx_counter}{'busmode'} = 0x0055;
                    }
                    elsif ( $help eq 'S189k' )
                    {
                        $idx_struct->{$idx_counter}{'busmode'} = 0x0155;
                    }
                    elsif ( $help eq 'Asynch' )
                    {
                        $idx_struct->{$idx_counter}{'busmode'} = 0x00AA;
                    }
                    else { S_set_error( "error in <PasModeTable> pasTime $help unknown, configuration file error", 1 ); }
                }
                else { S_set_error( "error in <PasModeTable> pasMode, configuration file error", 1 ); }
                foreach ( 0 .. 6 )
                {
                    $line = <IN>;    #<pasTimeT>
                    if ( $line =~ /<pasTimeT$_>(.*)<\/pasTimeT/ )
                    {
                        $help = $1;
                        push( @{ $idx_struct->{$idx_counter}{'PAStimes'} }, $help );
                    }
                    else { S_set_error( "error in <PasModeTable> pasTime, configuration file error", 1 ); }
                }

                S_w2log( 3, "IDX $idx_counter PAS settings: $idx_struct->{$idx_counter}{'busmode'} @{$idx_struct->{$idx_counter}{'PAStimes'}} )\n" );

                $idx_counter++

            }

        }
        close(IN);
    }
    else
    {
        S_set_error( "File: $configfile could not be opened", 1 );
    }

    $LASTconfig = $configfile;
    return 1 if $main::opt_offline;

    $stat = idx_LoadConfig($configfile);
    Check_Status($stat);
    S_w2log( 5, "IDX_LoadConfig staus=$stat\n" );
    S_wait_ms(500);

    # loop over all connected idefix and set values according to config file
    for ( my $device_itr = 0 ; $device_itr < $IDXdevices ; $device_itr++ )
    {
        S_w2log( 5, "SetPASMode ($device_itr,$idx_struct->{$device_itr}{'busmode'}, @{$idx_struct->{$device_itr}{'PAStimes'}} )\n" );
        $stat = idx_SetPASMode( $device_itr, $idx_struct->{$device_itr}{'busmode'}, @{ $idx_struct->{$device_itr}{'PAStimes'} } );
        Check_Status($stat);
        S_w2log( 5, "SetPASMode($device_itr) staus=$stat\n" );

        $stat = idx_ResetDevice($device_itr);
        Check_Status($stat);
        S_w2log( 5, "ResetDevice($device_itr) staus=$stat\n" );
    }

    return 1;
}

=head2 IDX_PrepareInjection

    IDX_PrepareInjection($configfile,$crashfile,$trigger);

prepare injection, IDEfix will not be resynchronized, only signal mapping will be taken from config.

 if $crashfile is empty string ('') the crashfile from the Idefix configuration is loaded
 if $configfile is empty string ('') the Idefix configuration used in IDX_LoadConfig is loaded
 $trigger : 0 -> prepares only the crashbuffer. An additional call of IDX_TriggerInjection() is necessary.
 $trigger : 1 -> starts the crashinjection immediately after the crashbuffer is prepared.

=cut

sub IDX_PrepareInjection
{
    my $configfile = shift;
    my $crashfile  = shift;
    my $trigger    = shift;

    unless ( defined($trigger) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IDX_PrepareInjection( \$configfile, \$crashfile, \$trigger )", 110 );
        return 0;
    }

    # if not empty and not existsing set error
    if ( $crashfile ne '' and (!( -f $crashfile )) )
    {
        S_set_error( "crashfile not found", 1 );
        return 0;
    }

    if ( $configfile eq '' )
    {
        $configfile = $LASTconfig;
    }
    unless ( -f $configfile )
    {
        S_set_error( "configfile not found", 1 );
        return 0;
    }
    unless ( $trigger =~ /^\d+$/ )
    {
        S_set_error( "trigger $trigger is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $trigger > 1 or $trigger < 0 )
    {
        S_set_error( "trigger $trigger out of range  (0<=x<=1)", 114 );
        return 1;
    }

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "IDX_PrepareInjection ($configfile, $crashfile, $trigger)\n" );

    return 1 if $main::opt_offline;

    $stat = idx_PrepInject( $configfile, $crashfile, $trigger );
    Check_Status($stat);
    S_w2log( 4, "IDX_PrepareInjection staus=$stat\n" );

    return 1;
}

=head2 IDX_SetOutput

    IDX_SetOutput($Device, $Out1, $Out2);

Set the Ouput of the connectors Out1 and Out2

 Arguments: $Device : Idefix index 0..1
            $Out1   : 1= HighLevel, else LowLevel
            $Out2   : 1= HighLevel, else LowLevel

=cut

sub IDX_SetOutput
{
    my $device = shift;
    my $out1   = shift;
    my $out2   = shift;

    unless ( defined($out2) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IDX_SetOutput( \$device, \$Out1, \$Out2 )", 110 );
        return 0;
    }
    S_w2log( 4, "IDX_SetOutput ($device, $out1, $out2)\n" );

    unless ( $device =~ /^\d+$/ )
    {
        S_set_error( "Device $device is not a number", 114 );
        return 1;

    }
    unless ( $out1 =~ /^\d+$/ )
    {
        S_set_error( "Out1 $out1 is not a number", 114 );
        return 1;

    }
    unless ( $out2 =~ /^\d+$/ )
    {
        S_set_error( "Out1 $out1 is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $device > 1 or $device < 0 )
    {
        S_set_error( "Device $device out of range  (0<=x<=1)", 114 );
        return 1;
    }
    if ( $out1 > 1 or $out1 < 0 )
    {
        S_set_error( "Out1 $out1 out of range  (0<=x<=1)", 114 );
        return 1;
    }
    if ( $out2 > 1 or $out2 < 0 )
    {
        S_set_error( "Out2 $out1 out of range  (0<=x<=1)", 114 );
        return 1;
    }
    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    return 1 if $main::opt_offline;

    $stat = idx_SetOutput( $device, $out1, $out2 );
    Check_Status($stat);
    S_w2log( 4, "IDX_SetOutput staus=$stat\n" );

    return 1;
}

=head2 IDX_TriggerInjection

    IDX_TriggerInjection();

trigger signal injection, only working once per buffer. For triggering again, crashbuffer has to be prepared again.

=cut

sub IDX_TriggerInjection
{

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "IDX_TriggerInjection\n" );

    return 1 if $main::opt_offline;

    $stat = idx_TriggerInject();
    Check_Status($stat);
    S_w2log( 4, "IDX_TriggerInjection staus=$stat\n" );

    return 1;
}

=head2 IDX_WritePASmemory

    IDX_WritePASmemory($pasname, $variable, $values_aref);
    e.g.: IDX_WritePASmemory('PPS2_left_TS3', 'SensorDefectInfo_U16X', [2,0x3]);

    $value may be decimal or hex
    $variable has to be from ProjectConst
    $pasname has to be from idefix config

writes variable of PAS scratch memory

   'IDEFIX' => {
                'OFFSET' => {
                                'SensorDefectInfo_U16X'   => 78,
                },

=cut

sub IDX_WritePASmemory
{
    my $pasname     = shift;
    my $variable    = shift;
    my $values_aref = shift;

    my $sc_base = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHBASEADRESS'};
    my $sc_len  = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHLENGHT'};
    my $sc_address;    # scratch memory address to write
    my $idx_script;    # script number taken from config
    my $idx_device;    # idefix number taken from config

    unless ( defined $sc_base and defined $sc_len )
    {
        S_set_error( "No IDEFIX settings (SCRATCHBASEADRESS,SCRATCHLENGHT) found in Project Constants", 20 );
        return;
    }

    unless ( defined($values_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX:  IDX_WritePASmemory( \$pasname, \$variable, \$values_aref )", 110 );
        return 0;
    }
    if ( ref($values_aref) ne "ARRAY" )
    {
        S_set_error( " values_aref is not an array reference", 114 );
        return 0;
    }
    unless (@$values_aref)
    {
        S_set_error( " values_aref is empty", 114 );
        return 0;
    }

    $idx_device = $PASsetting->{$pasname}{'device'};
    $idx_script = $PASsetting->{$pasname}{'scriptnumber'};

    unless ( defined $idx_device and defined $idx_script )
    {
        S_set_error( "No IDEFIX settings (device,scriptnumber) found in idefix configuration for $pasname", 20 );
        return;
    }

    my $count;

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@$values_aref) ; $count++ )
    {
        @$values_aref[$count] = S_0x2dec( @$values_aref[$count] );
    }

    $sc_address = $sc_base + $idx_script * $sc_len;    # only one statemachine supported

    my $offset = $main::ProjectDefaults->{'IDEFIX'}{'OFFSET'}{$variable};
    unless ( defined $offset )
    {
        S_set_error( "No IDEFIX OFFSET ($variable) found in Project Constants", 20 );
        return 0;
    }

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    S_w2log( 5, "IDX_WritePASmemory: write  [@$values_aref] to $variable ($sc_address+$offset)\n" );

    return 1 if $main::opt_offline;

    for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
    {
        $stat = idx_WriteRAMBlock( $idx_device, $sc_address + $offset, $values_aref );
        if ( $stat == 0 )
        {
            last;    # exit loop if successful
        }
        else
        {
            S_w2log( 3, "idx_WriteRAMBlock retry after error\n" );
            S_wait_ms(50);
        }
    }

    Check_Status($stat);

    S_w2log( 3, "IDX_WritePASmemory($pasname, $variable, [@$values_aref]) staus=$stat\n" );

    return 1;
}

=head2 IDX_ReadINIT2Data

    $values_aref = IDX_ReadINIT2Data( $pasname );
    e.g.: [ 16 bytes ] = IDX_ReadINIT2Data('PPS2_left_TS3');

    $pasname has to be from idefix config

 offline + error return: [(0) x 16]

reads data of PAS scratch memory and returns 16 bytes.
calls IDX_ReadPASmemory($pasname, 'A_Init2StatusDataArray_U8X', 32) internally and converts result to 16 bytes.

   'IDEFIX' => {
                'OFFSET' => {
                                'A_Init2StatusDataArray_U8X'   => 4,
                },

=cut

sub IDX_ReadINIT2Data
{
    my $pasname = shift;
    my ( @values, $count );
    @values = ();
    my $offline_return = [ (0) x 16 ];

    unless ( defined($pasname) )
    {
        S_set_error( "! too less parameters ! SYNTAX:  IDX_ReadINIT2Data( \$pasname )", 110 );
        return $offline_return;
    }
    S_w2log( 4, "IDX_ReadINIT2Data\n" );

    return $offline_return if $main::opt_offline;

    my $values_aref = IDX_ReadPASmemory( $pasname, 'A_Init2StatusDataArray_U8X', 32 );

    #combine two 4-bit values to one 8-bit value
    for ( $count = 0 ; $count < 32 ; $count += 2 )
    {
        push( @values, ( $$values_aref[$count] << 4 ) + $$values_aref[ $count + 1 ] );
    }
    S_w2log( 4, "IDX_ReadINIT2Data($pasname) returned [@values]\n" );

    return ( \@values );
}

=head2 IDX_ReadPASmemory

    $values_aref = IDX_ReadPASmemory($pasname, $variable, $bytes);
    e.g.: [2,3] = IDX_ReadPASmemory('PPS2_left_TS3', 'SensorDefectInfo_U16X', 2);

    $bytes may be decimal or hex
    $variable has to be from ProjectConst
    $pasname has to be from idefix config

 offline + error return: [1]

reads variable of PAS scratch memory

   'IDEFIX' => {
                'OFFSET' => {
                                'SensorDefectInfo_U16X'   => 78,
                },

=cut

sub IDX_ReadPASmemory
{
    my $pasname  = shift;
    my $variable = shift;
    my $bytes    = shift;

    my $sc_base = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHBASEADRESS'};
    my $sc_len  = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHLENGHT'};
    my $sc_address;    # scratch memory address to write
    my $idx_script;    # script number taken from config
    my $idx_device;    # idefix number taken from config
    my $values_aref;
    my $offline_return = [1];

    unless ( defined $sc_base and defined $sc_len )
    {
        S_set_error( "No IDEFIX settings (SCRATCHBASEADRESS,SCRATCHLENGHT) found in Project Constants", 20 );
        return;
    }

    unless ( defined($bytes) )
    {
        S_set_error( "! too less parameters ! SYNTAX:  IDX_ReadPASmemory( \$pasname, \$variable, \$bytes )", 110 );
        return $offline_return;
    }

    #parameter range check
    if ( $bytes < 1 )
    {
        S_set_error( "number ob bytes $bytes out of range  (1<=x)", 114 );
        return $offline_return;
    }

    $idx_device = $PASsetting->{$pasname}{'device'};
    $idx_script = $PASsetting->{$pasname}{'scriptnumber'};

    unless ( defined $idx_device and defined $idx_script )
    {
        S_set_error( "No IDEFIX settings (device,scriptnumber) found in idefix configuration for $pasname", 20 );
        return;
    }

    # convert data to dec if required
    $bytes = S_0x2dec($bytes);

    $sc_address = $sc_base + $idx_script * $sc_len;    # only one statemachine supported

    my $offset = $main::ProjectDefaults->{'IDEFIX'}{'OFFSET'}{$variable};
    unless ( defined $offset )
    {
        S_set_error( "No IDEFIX OFFSET ($variable) found in Project Constants", 20 );
        return $offline_return;
    }

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return $offline_return;
    }
    S_w2log( 3, "IDX_ReadPASmemory: read $bytes bytes from $variable ($sc_address+$offset)\n" );

    return $offline_return if $main::opt_offline;

    ( $stat, $values_aref ) = idx_ReadRAMBlock( $idx_device, $bytes, $sc_address + $offset );

    Check_Status($stat);

    S_w2log( 3, "IDX_ReadPASmemory($pasname, $variable, $bytes) returned [@$values_aref] staus=$stat\n" );

    return $values_aref;
}

=head2 IDX_setPASfault

    IDX_setPASfault($pasname, $faulttype, [$duration, $starttime]);

Set fault in PAS script

    $faulttype has to be from ProjectConst
    $pasname has to be from idefix config

   'IDEFIX' => {
                'FAULTTYPES' =>{
                                'ManchesterError'               =>  {
                                    '1' => {'address'=>'StateSensorFlt_U32X', 'values' => [0,0,0,2]},
                                 },
                },
                'OFFSET' => {
                                'StateSensorFlt_U32X'     => 40,
                },

=cut

sub IDX_setPASfault
{
    my $pasname   = shift;
    my $faulttype = shift;
    my $duration  = shift;
    my $starttime = shift;

    my $sc_base = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHBASEADRESS'};
    my $sc_len  = $main::ProjectDefaults->{'IDEFIX'}{'SCRATCHLENGHT'};
    my $sc_address;    # scratch memory address to write
    my $idx_script;    # script number taken from config
    my $idx_device;    # idefix number taken from config
    my $duration_offset  = $main::ProjectDefaults->{'IDEFIX'}{'OFFSET'}{'NumSensorFltMsg_U16X'};
    my $starttime_offset = $main::ProjectDefaults->{'IDEFIX'}{'OFFSET'}{'TimeSensorFltMsg_U16X'};

    unless ( defined $sc_base and defined $sc_len )
    {
        S_set_error( "No IDEFIX settings (SCRATCHBASEADRESS,SCRATCHLENGHT) found in Project Constants", 20 );
        return;
    }

    unless ( defined $duration_offset and defined $starttime_offset )
    {
        S_set_error( "No IDEFIX OFFSET (NumSensorFltMsg_U16X,TimeSensorFltMsg_U16X) found in Project Constants", 20 );
        return;
    }

    unless ( defined($faulttype) )
    {
        S_set_error( "! too less parameters ! SYNTAX: IDX_setPASfault( \$pasname, \$faulttype, [\$duration, \$starttime] )", 110 );
        return 0;
    }
    my %fault_values;

    #map device if necessary
    unless ( exists $main::ProjectDefaults->{'IDEFIX'}{'FAULTTYPES'}{$faulttype} )
    {
        S_set_error( "IDEFIX FAULTTYPE $faulttype unknown, check Project Constants", 20 );
        return 0;
    }
    else
    {
        %fault_values = %{ $main::ProjectDefaults->{'IDEFIX'}{'FAULTTYPES'}{$faulttype} };
    }

    #$PASsetting = {'PASname' => { "device" => 0,"scriptnumber" => 0 } }
    $idx_device = $PASsetting->{$pasname}{'device'};
    $idx_script = $PASsetting->{$pasname}{'scriptnumber'};

    unless ( defined $idx_device and defined $idx_script )
    {
        S_set_error( "No IDEFIX settings (device,scriptnumber) found in idefix configuration for $pasname", 20 );
        return;
    }

    #set default values for skipped optional parameters
    $duration  = 0xffff unless ( defined($duration) );
    $starttime = 0      unless ( defined($starttime) );
    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    S_w2log( 4, "IDX_setPASfault($pasname, $faulttype, $duration, $starttime)\n" );

    return 1 if $main::opt_offline;

    # convert dec values to byte arrays
    my @duration_bytes  = unpack( "C2" x 2, pack( "n", $duration ) );
    my @starttime_bytes = unpack( "C2" x 2, pack( "n", $starttime ) );

    $sc_address = $sc_base + $idx_script * $sc_len;    # only one statemachine supported

    S_w2log( 5, "write duration $duration (@duration_bytes) to $sc_address+$duration_offset\n" );
    for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
    {
        $stat = idx_WriteRAMBlock( $idx_device, $sc_address + $duration_offset, \@duration_bytes );
        if ( $stat == 0 )
        {
            last;                                      # exit loop if successful
        }
        else
        {
            S_w2log( 3, "idx_WriteRAMBlock retry after error\n" );
            S_wait_ms(50);
        }
    }
    Check_Status($stat);

    S_w2log( 5, "write starttime $starttime (@starttime_bytes) to $sc_address+$starttime_offset\n" );
    for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
    {
        $stat = idx_WriteRAMBlock( $idx_device, $sc_address + $starttime_offset, \@starttime_bytes );
        if ( $stat == 0 )
        {
            last;    # exit loop if successful
        }
        else
        {
            S_w2log( 3, "idx_WriteRAMBlock retry after error\n" );
            S_wait_ms(50);
        }
    }
    Check_Status($stat);

    # loop over fault type elemants and execute write commands
    my ( $addr, $vals, $offset );
    foreach my $count ( sort keys %fault_values )
    {
        $addr = $fault_values{$count}{'address'};
        $vals = $fault_values{$count}{'values'};
        if ( defined $addr and defined $vals )
        {
            $offset = $main::ProjectDefaults->{'IDEFIX'}{'OFFSET'}{$addr};
            if ( defined $offset )
            {
                S_w2log( 5, "write  [@$vals] to $addr ($sc_address+$offset)\n" );
                for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
                {
                    $stat = idx_WriteRAMBlock( $idx_device, $sc_address + $offset, $vals );
                    if ( $stat == 0 )
                    {
                        last;    # exit loop if successful
                    }
                    else
                    {
                        S_w2log( 3, "idx_WriteRAMBlock retry after error\n" );
                        S_wait_ms(50);
                    }
                }
                Check_Status($stat);
            }
            else
            {
                S_set_error( "No IDEFIX OFFSET ($addr) found in Project Constants", 20 );
            }
        }
        else
        {
            S_set_error( "No IDEFIX settings (address,values) found for $faulttype [$count] ", 20 );
        }
    }

    return 1;
}

=head1 LOW LEVEL ACCESS

B<Use this functions carefully, you might end up re-programming idefix>


=head2 IDX_ReadByAddress

B<deprecated, use IDX_ReadRAMBlock instead>

    $value = IDX_ReadByAddress($Device,  $address);
    e.g.: $value = IDX_ReadByAddress(0, "0x00509A80");

    $address may be decimal or hex
    $value will be hex e.g. "0x00000000"

reads RAM cell (32 bit) (as string) of the requested USB device. $Device = Idefix index 0..1

offline_return : 0x00000000

=cut

sub IDX_ReadByAddress
{
    my $device  = shift;
    my $address = shift;
    my $value;

    unless ( defined($address) )
    {
        S_set_error( "! too less parameters ! SYNTAX: value = IDX_ReadByAddress( \$device, \$address )", 110 );
        return 0;
    }
    unless ( $device =~ /^\d+$/ )
    {
        S_set_error( "Device $device is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $device > 1 or $device < 0 )
    {
        S_set_error( "Device $device out of range  (0<=x<=1)", 114 );
        return 1;
    }

    #convert address if required
    $address = S_0x2dec($address);

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    if($main::opt_offline)
    {
        S_w2log( 3, "IDX_ReadByAddress($device,  $address): offline value=0x00000000 \n" );
        return "0x00000000";
    }

    ( $stat, $value ) = idx_ReadByAddress( $device, $address );
    Check_Status($stat);
    S_w2log( 3, "IDX_ReadByAddress($device,  $address) value=<$value> staus=$stat\n" );

    return ( "0x" . $value );
}

=head2 IDX_WriteByAddress

B<deprecated, use IDX_WriteRAMBlock instead>

    IDX_WriteByAddress($Device, $address, $value);
    e.g.: IDX_WriteByAddress(0, "0x00509A80",1);

    $address, $value may be decimal or hex

writes RAM cell (32 bit) of the requested USB device. $Device = Idefix index 0..1

=cut

sub IDX_WriteByAddress
{
    my $device  = shift;
    my $address = shift;
    my $value   = shift;

    unless ( defined($value) )
    {
        S_set_error( "! too less parameters ! SYNTAX:  IDX_WriteByAddress( \$device, \$address, \$value )", 110 );
        return 0;
    }
    unless ( $device =~ /^\d+$/ )
    {
        S_set_error( "Device $device is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $device > 1 or $device < 0 )
    {
        S_set_error( "Device $device out of range  (0<=x<=1)", 114 );
        return 1;
    }

    #convert address if required
    $address = S_0x2dec($address);

    #convert value if required
    $value = S_0x2dec($value);

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    if($main::opt_offline)
    {
        S_w2log( 3, "IDX_WriteByAddress($device, $address, $value) offline \n" );
        return 1;
    }

    $stat = idx_WriteByAddress( $device, $address, $value );
    Check_Status($stat);
    S_w2log( 3, "IDX_WriteByAddress($device, $address, $value) staus=$stat\n" );

    return 1;
}

=head2 IDX_ReadRAMBlock

    $values_aref = IDX_ReadRAMBlock($Device,  $address, $numberOfBytes);
    e.g.: $values_aref = IDX_ReadRAMBlock(0, "0x00509A80", 3);

    $address may be decimal or hex
    $values will be dec

reads RAM cells of the requested USB device. $Device = Idefix index 0..1

offline_return : [0]

=cut

sub IDX_ReadRAMBlock
{
    my $device        = shift;
    my $address       = shift;
    my $numberOfBytes = shift;
    my $values_aref;

    unless ( defined($numberOfBytes) )
    {
        S_set_error( "! too less parameters ! SYNTAX: values = IDX_ReadRAMBlock( \$device, \$address, \$numberOfBytes )", 110 );
        return [0];
    }
    unless ( $device =~ /^\d+$/ )
    {
        S_set_error( "Device $device is not a number", 114 );
        return [0];

    }

    #parameter range check
    if ( $device > 1 or $device < 0 )
    {
        S_set_error( "Device $device out of range  (0<=x<=1)", 114 );
        return [0];
    }
    if ( $numberOfBytes < 1 )
    {
        S_set_error( "numberOfBytes $numberOfBytes out of range  (1<=x)", 114 );
        return [0];
    }

    #convert address if required
    $address = S_0x2dec($address);

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }
    if($main::opt_offline)
    {
        S_w2log( 3, "IDX_ReadRAMBlock($device,  $address, $numberOfBytes) offline values=[0] \n" );
        return [0];
    }

    ( $stat, $values_aref ) = idx_ReadRAMBlock( $device, $numberOfBytes, $address );
    Check_Status($stat);
    S_w2log( 3, "IDX_ReadRAMBlock($device,  $address, $numberOfBytes) values=<@$values_aref> staus=$stat\n" );

    return ($values_aref);
}

=head2 IDX_WriteRAMBlock

    IDX_WriteRAMBlock($Device, $address, $values_aref);
    e.g.: IDX_WriteRAMBlock(0, "0x00509A80",[1]);

    $address, $value may be decimal or hex

writes RAM cells of the requested USB device. $Device = Idefix index 0..1

=cut

sub IDX_WriteRAMBlock
{
    my $device      = shift;
    my $address     = shift;
    my $values_aref = shift;

    unless ( defined($values_aref) )
    {
        S_set_error( "! too less parameters ! SYNTAX:  IDX_WriteRAMBlock( \$device, \$address, \$values_aref )", 110 );
        return 0;
    }
    if ( ref($values_aref) ne "ARRAY" )
    {
        S_set_error( " values_aref is not an array reference", 114 );
        return 0;
    }
    unless (@$values_aref)
    {
        S_set_error( " values_aref is empty", 114 );
        return 0;
    }

    unless ( $device =~ /^\d+$/ )
    {
        S_set_error( "Device $device is not a number", 114 );
        return 1;

    }

    #parameter range check
    if ( $device > 1 or $device < 0 )
    {
        S_set_error( "Device $device out of range  (0<=x<=1)", 114 );
        return 1;
    }
    my $count;

    # convert data to dec if required
    for ( $count = 0 ; $count < scalar(@$values_aref) ; $count++ )
    {
        @$values_aref[$count] = S_0x2dec( @$values_aref[$count] );
    }

    #convert address if required
    $address = S_0x2dec($address);

    unless ($IDX_initialized)
    {
        S_set_error( "IDEfix not initialized", 120 );
        return 0;
    }

    if($main::opt_offline)
    {
        S_w2log( 3, "IDX_WriteRAMBlock($device, $address, [@$values_aref]) offline execution successful \n" );
        return 1;
    }

    for ( $retryloop = 0 ; $retryloop < $MAXretry ; $retryloop++ )
    {
        $stat = idx_WriteRAMBlock( $device, $address, $values_aref );
        if ( $stat == 0 )
        {
            last;    # exit loop if successful
        }
        else
        {
            S_w2log( 3, "idx_WriteRAMBlock retry after error\n" );
            S_wait_ms(50);
        }
    }
    Check_Status($stat);
    S_w2log( 3, "IDX_WriteRAMBlock($device, $address, [@$values_aref]) staus=$stat\n" );

    return 1;
}

=head1 not exported functions

=head2 Check_Status

 Check_Status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_Status
{
    my $status = shift;

    return 1 if $main::opt_offline;

    if ( $status < 0 )
    {
        my $errortext = idx_GetErrortext($status);
        S_set_error( "IDX ($status): $errortext", 5 );

    }

    return 1;
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

