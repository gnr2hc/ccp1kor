package PD;

use strict;
use warnings;
use Carp;
use LIFT_general;
use LIFT_simulation;
no strict 'refs';

require Exporter;
require DynaLoader;
#use AutoLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use PD ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(

) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
                    pd_ClearFaultMemory
                    pd_FreezeFaultMemory
                    pd_GetVersion
                    pd_ReadAddress
                    pd_ReadExtendedFaultMemory
                    pd_ReadFaultMemory
                    pd_ReadName
                    pd_TestEnd
                    pd_TestStart
                    pd_WriteAddress
                    pd_WriteName
                    pd_ECUreset
                    pd_ECUlogin
                    pd_ClearCrashRecorder
                    pd_StopFastDiag    
                    pd_StartFastAddress
                    pd_StartFastName
                    pd_StartExtName
                    pd_StartExtAddress
                    pd_getPMrevision
                    pd_getXSrevision
                    pd_getCWrevision
                    pd_InitConfiguration
                    pd_InitCommunication
                    pd_GetSWversion
                    pd_StartFastAddressBuf
                    pd_StartFastNameBuf
                    pd_StartExtAddressBuf
                    pd_StartExtNameBuf
                    pd_GetRingBuffer
                    pd_ClearBuffer
                    pd_CalculateChecksum
                    pd_GetAddressByName
                    pd_GetNameByAddress
                    pd_GetFLTNameByFLTID
                    pd_GetFLTIDByFLTName
                    pd_GetECUStatus
                    pd_GetCANHWList
                    pd_GetErrorString
                    pd_InitEEPROM
                    pd_EraseEEPROM
                    pd_GetEEPROMDump
                    pd_GetRAMDump
                    pd_SensorCalibration
                    pd_GetSADInfo
                    pd_GetSADItemDesc
                    pd_GetFLASHDump
                    pd_EleFrgEnableSafetyPath
                    pd_EleFrgFireAllDevices
                    pd_ReadCrashRecorder
					pd_ReadNVMSection
					pd_WriteNVMSection
					pd_SMI7verification
					pd_ManipulateFaultMemory

);
our $VERSION = '1.5';
bootstrap PD $VERSION;

# Preloaded methods go here.

sub pd_getPMrevision{
    return ('SCM');
}

sub pd_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

sub pd_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

#
# simulation functions start here
#

if ( $main::opt_simulation ){
    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT){
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'pd_GetSWversion' => { 'default' => [4, ['Airbag Generation', 1, 1, 1], [12, 1, 1, 1]], 'AB10' => [4, ['Airbag Generation', 1, 1, 1], [10, 1, 1, 1]], 'AB12' => [4, ['Airbag Generation', 1, 1, 1], [12, 1, 1, 1]], },
        'pd_ReadAddress' => { 'default' => [ 0, [1] ], },
        'pd_ReadName' => { 'default' => [ 0, [1] ], },
        'pd_WriteName' => { 'default' => [ 0 ] },
        'pd_ReadFaultMemory' => { 'default' => [ 0, [], [], [], [], [],[] ], },
        'pd_GetAddressByName' => { 'default' =>  [1, '0x08005FD0'] },
        'pd_ReadExtendedFaultMemory' => { 'default' =>  [2, ['bc','11'],  ['A01300','00004A'], ['FltEOLNotProgrammed','FltCRCRamFault'], ['22','1f'], ['0b000000','0b000001'], ['12','38'], ['08','24'], ['69','ff'], ['69','ff']]},
        'pd_ClearCrashRecorder' => { 'default' =>  [0, ['3','72','00','255','255','255','255','255']]},
        'pd_ECUlogin' => { 'default' =>  [0] },
        'pd_ECUreset' => {'default' => [0] },
        'pd_GetECUStatus' => {'default' => [0,[10,20,30,40]]},
        'pd_FreezeFaultMemory ' => {'default' => [0,[10,20,30,40,50,60,70]]},
        'pd_GetFLTIDByFLTName' => {'default' => [0,11],['rb_spi_SpiRcvMsgCrcWrong_flt']},
        'pd_StartFastAddress' => {'default' => [0]},
        'pd_StartExtAddress' => {'default' => [0]},
        'pd_StartExtName' => {'default' => [0]},
        'pd_GetSADItemDesc' => {'default' => [1,'Side disable,,,Rose disable,,Pedestrian Protection disable,,,',8]},
        'pd_GetFLTNameByFLTID' => {'default' => [1, 'rb_dummy_flt', '4711']},
		'pd_SMI7verification' => {'default' => [1,[1],1]},
		'pd_ReadNVMSection' => {'default' => [0,[0,0,1,3]]},
		'pd_WriteNVMSection' => {'default' => [0]},
		'pd_ReadCrashRecorder' => { 'default' =>  [0, ['0','1','2','3','4','5','6','7']]},
		'pd_EleFrgEnableSafetyPath'=> { 'default' =>  [0, ['0','0','0','0']]},
		'pd_EleFrgFireAllDevices'=> { 'default' =>  [0, ['0','0','0','0']]},
		'pd_GetEEPROMDump' => {'default' => [0]},
		'pd_GetRAMDump' => {'default' => [0]},
		'pd_GetFLASHDump' => {'default' => [0]},
		'pd_GetRAMDump' => {'default' => [0]},
		'pd_GetNameByAddress' => {'default' => [1,'rb_Var_name']},
		'pd_ManipulateFaultMemory' => {'default' => [ 0 ]},
		
    }; 
    SIM_addToValuesTable( $returnValuesTable_href );

    # redefine again those functions which need special treatment
    *pd_GetErrorString = sub{
        my $status = shift; 
        return SIM_returnValues('pd_GetErrorString', "Error $status", \@_); 
    };

    *pd_GetCANHWList = sub{
        my $defaultSerialNo;
        if( defined $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'} ){
            $defaultSerialNo = $LIFT_config::LIFT_Testbench->{'Devices'}{'PD'}{'CANHWSerialNo'};
        }
        else{
            $defaultSerialNo = '12345';
        }
        return SIM_returnValues('pd_GetCANHWList', [ 0, [$defaultSerialNo], [1] ], \@_); 
    };
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__

=head1 NAME

PD - Perl extension for generic production diagnosis dll

=head1 SYNOPSIS

    use PD;

    my ($version,$stat,$value,$value_aref);
    my ($names,$IDs,$states,$DTCs,$PonCnt,$SpoCnt,$fiApTime,$laDisTime,$ABgeneration,$protocolversion);

    $stat = pd_TestStart();
    ($stat, $IDs_aref, $Channels_aref) = pd_GetCANHWList();
    $stat = pd_InitConfiguration('.\my.ini');
    $stat = pd_InitCommunication();
    ($stat,$version) = pd_GetVersion();
    ($stat,$ECULabels_aref,$ECUValues_aref) = pd_GetSWversion();

    ($stat,$IDs,$DTCs,$names,$states, $info, $fault_info_aref) = pd_ReadFaultMemory(1); 
    ($stat,$IDs,$DTCs,$names,$states,$fiApTime,$laDisTime,$PonCnt,$SpoCnt) = pd_ReadExtendedFaultMemory(1);
    $stat = pd_ClearFaultMemory( $id, $IsWaitUntillCLTFltMem );
    ($stat, $response_aref) = pd_FreezeFaultMemory();

    ($stat, $response_aref) = pd_ClearCrashRecorder();
    
    ($stat,$value_aref) = pd_ReadName('A_BoschFltMem_XSE(0).V_FltNbr_U16X');
    ($stat,$value_aref) = pd_ReadAddress(hex('8005FD8'),2);

    $stat = pd_StartFastAddress([hex('80022DC'),hex('80022DD')],[0,0],"FDtest2.txt", 1, 0);
    sleep(1);
    $stat = pd_StopFastDiag();
    
    $stat = pd_ECUreset();
    $stat = pd_ECUlogin();

    $stat = pd_StartFastName(['A_FLMFltMemState_U8R(0)','A_FLMFltMemState_U8R(1)'],[0,0],"FDtest1.txt", 1, 0);
    sleep(1);
    $stat = pd_StopFastDiag();

    $stat = pd_StartExtAddress([hex('80022DC'),hex('80022DD')],"FDtest2.txt", 1, 0);
    sleep(1);
    $stat = pd_StopFastDiag();
    
    $stat = pd_StartExtName(['A_FLMFltMemState_U8R(0)','A_FLMFltMemState_U8R(1)'],"FDtest1.txt", 1, 0);
    sleep(1);
    $stat = pd_StopFastDiag();

    $stat = pd_GetEEPROMDump("EEdump.hex");
    $stat = pd_GetRAMDump("RAMdump.hex");
    $stat = pd_Init_EEPROM("bb62057_eeprom.hex");
    $stat = pd_GetFLASHDump("Flashdump.hex");
    
    $stat = pd_WriteName('A_BoschFltMem_XSE(0).V_FltNbr_U16X',[14,27]);
    $stat = pd_WriteAddress(hex('8005FD8'),[5,8]);
    
    $stat = pd_ReadCrashRecorder(0x10);
	($stat,$value_aref) = pd_ReadNVMSection(8,02);
	$stat = pd_WriteNVMSection(8,02,[14,27]);
    $stat = pd_TestEnd();
    $stat = pd_ManipulateFaultMemory("rb_sqm_SquibResistanceShortIC1FD_flt", "qualify");
 
=head1 DESCRIPTION

All these functions are wrapped around PD DLL APIs.



=head2 pd_CalculateChecksum

    $stat = pd_CalculateChecksum($area);

calculate checksum for area, same number as in WinDiag


=head2 pd_ClearBuffer

    $stat = pd_ClearBuffer();

clear buffer for fast diagnosis


=head2 pd_ClearCrashRecorder

    ($stat, $response_aref) = pd_ClearCrashRecorder();

clear crash recorder &  returns response in all cases. 


=head2 pd_ClearFaultMemory

    $stat = pd_ClearFaultMemory( $id, $IsWaitUntillCLTFltMem );

clear fault memory

  $id   0 :    clear all fault memories (Bosch)
        1 :    clear not filtered faults (Bosch)
        2 :    clear disturbance memory
        3 :    clear shadow memory
        4 :    clear all faults (customer -> shadow memory will be written if any) 
        5 :    clear not filtered faults (customer -> shadow memory will be written if any)
        
  $IsWaitUntillCLTFltMem
        0 :    Not wait untill clear fault Memory
        1 :    Wait untill clear fault Memory

=head2 pd_FreezeFaultMemory

    ($stat, $response_aref) = pd_FreezeFaultMemory();

To freeze fault Memory to avoid new faults	


=head2 pd_ECUlogin

    $stat = pd_ECUlogin();

login to ECU


=head2 pd_ECUreset

    $stat = pd_ECUreset();

reset ECU


=head2 pd_EraseEEPROM

    $stat = pd_EraseEEPROM();

erase EEPROM (overwrite with FF)


=head2 pd_GetAddressByName

    ($stat,$address) = pd_GetAddressByName($name);

get address for symbol name form SAD file


=head2 pd_GetCANHWList

    ($stat, $IDs_aref, $Channels_aref) = pd_GetCANHWList();

returns the list of connected Hardwares and Number of channels available in each Harware


=head2 pd_GetECUStatus

    ($stat, $status_aref) = pd_GetECUStatus();

get ECU status

=head2 pd_GetEEPROMDump

    $stat = pd_GetEEPROMDump($hexfile);

    e.g.: $stat = pd_GetEEPROMDump("EEdump.hex");

dump EEPROM to Hexfile

=head2 pd_GetFLASHDump

    $stat = pd_GetFLASHDump($hexfile);

    e.g.: $stat = pd_GetFLASHDump("Flashdump.hex");

dump Flash to Hexfile

=head2 pd_GetErrorString

    $errortext = pd_GetErrorString($stat);

resolve error string from $status < 0


=head2 pd_GetFLTIDByFLTName

    ($stat,$FLTid) = pd_GetFLTIDByFLTName($FLTname);

get fault id of fault name from FLT file


=head2 pd_GetFLTNameByFLTID

    ($stat,$FLTname,$DTC) = pd_GetFLTNameByFLTID($FLTid);

get fault name and DTC of fault id from FLT file


=head2 pd_GetNameByAddress

    ($stat,$name) = pd_GetNameByAddress($address);

get name of address from SAD file


=head2 pd_GetRAMDump

    $stat = pd_GetRAMDump($hexfile);

    e.g.: $stat = pd_GetRAMDump("RAMdump.hex");

dump RAM to Hexfile


=head2 pd_GetRingBuffer

    ($stat, $timestamp, \@Ringbuffer) = pd_GetRingBuffer();

returns ringbuffer of fast diagnosis with timestamp for first value


=head2 pd_GetSADInfo

    ($stat,$SADvalue) = pd_GetSADInfo($SADkey);

returns SAD header information


=head2 pd_GetSADItemDesc

    ($stat,$Description,$MaxBitWiseCount) = pd_GetSADItemDesc($label);

returns Description (Enum/bitmask) as string and Maximum no. of bit comments for a given label 

$stat =  0 - If Empty string is found 

1 - If the type of description is Bitcomments 

2 - If the type of description is Enum 

-20 - If the label is not found 		 


=head2 pd_GetSWversion

    ($stat,$ECULabels_aref,$ECUValues_aref) = pd_GetSWversion();

returns ECU details in an array format of labels and respective values flashed into ECU


=head2 pd_GetVersion

    ($stat,$version) = pd_GetVersion();

returns PD dll version

=head2 pd_InitConfiguration

    $stat = pd_InitConfiguration($path_to_ini_file);

Loads SAD file, FLT file and intializes diagnosis settings based �n ini file.


=head2 pd_InitCommunication

    $stat = pd_InitCommunication();

Initialize communication. Has to be called before any other function. Intializes communication based �n ini file. ECU has to be switched on !


=head2 pd_InitEEPROM

    $stat = pd_InitEEPROM($hexfile);

    e.g.: $stat = pd_InitEEPROM("bb62057_eeprom.hex");

init EEPROM from Hexfile


=head2 pd_ReadAddress

    ($stat,$value_aref) = pd_ReadAddress($address,$no_of_bytes); 

read $no_of_bytes bytes starting from $address


=head2 pd_ReadExtendedFaultMemory

    ($stat,$IDs_aref,$DTCs_aref,$names_aref,$states_aref,$info_aref,$fiApTime_aref,$laDisTime_aref,$PonCnt_aref,$SpoCnt_aref) = pd_ReadExtendedFaultMemory($nType);

read fault memory and return array refernces, $info_aref is additionally seperated by comma internally

$nType : [0,1,3,4] 0: Plant Memory , 1 : Primary Memory, 3 : Bosch Fault Memory, 4 : Disturbance Memory

AB10 Supported Types : [1] 
Ab12 Supported Types : [0,1,3,4]

=head2 pd_ReadFaultMemory

    ($stat,$IDs_aref,$DTCs_aref,$names_aref,$states_aref,$info_aref, $fault_info_aref) = pd_ReadFaultMemory($nType);

read fault memory and return array refernces, $info_aref is additionally seperated by comma internally

$nType : [0,1,3,4] 0: Plant Memory , 1 : Primary Memory, 3 : Bosch Fault Memory, 4 : Disturbance Memory

AB10 Supported Types : [1] 
AB12 Supported Types : [0,1,3,4]

=head2 pd_ReadName

    ($stat,$value_aref) = pd_ReadName($label); 

read memory by label, lenght will be taken from SAD file


=head2 pd_SensorCalibration

    ($stat,$response_aref) = pd_SensorCalibration($data_aref);
    
    e.g.: ($stat,$response_aref) = pd_SensorCalibration([0,1,1,244]); # temperature, 500 samples

send Sensor Calibration request, very generic: just define the content bytes, for details refer to PD_specification


=head2 pd_StartExtAddress

    $stat = pd_StartExtAddress(\@adresses, \@types, $filename, $numberOfCANIds, $isNextPOC);

use for >8 cells, unused bytes will be filled with 0xFF: 
select cells to read by address, dump fast diagnosis values to file
AB12 : use for 28 cells [select cells to read by address, dump fast diagnosis values to file]
Number of CAN IDS supported 1 - 4
isNextPOC = (0 or 1) 0 = false 1 = true

=head2 pd_StartExtAddressBuf

    $stat = pd_StartExtAddressBuf(\@adresses, \@types, $filename);

use for >8 cells, unused bytes will be filled with 0xFF: 
select cells to read by address, dump fast diagnosis setting to file and fill ringbuffer with values


=head2 pd_StartExtName

    $stat = pd_StartExtName(\@names, \@types, $filename, $numberOfCANIds, $isNextPOC);

use for >8 cells, unused bytes will be filled with 0xFF: 
select cells to read by label, dump fast diagnosis values to file
AB12 : use for 28 cells [select cells to read by address, dump fast diagnosis values to file]
Number of CAN IDS supported 1 - 4
isNextPOC = (0 or 1) 0 = false 1 = true

=head2 pd_StartExtNameBuf

    $stat = pd_StartExtNameBuf(\@names, \@types, $filename);

use for >8 cells, unused bytes will be filled with 0xFF: 
select cells to read by label, dump fast diagnosis setting to file and fill ringbuffer with values


=head2 pd_StartFastAddress

    $stat = pd_StartFastAddress(\@adresses, \@shifts, \@types, $filename, $numberOfCANIds, $isNextPOC);

use for 2,4,8 cells (values may be shifted inside ECU): 
select cells to read by address, dump fast diagnosis values to file
AB12 : use for 28 cells [select cells to read by address, dump fast diagnosis values to file]
Number of CAN IDS supported 1 - 4
isNextPOC = (0 or 1) 0 = false 1 = true


=head2 pd_StartFastAddressBuf

    $stat = pd_StartFastAddressBuf(\@adresses, \@shifts, \@types, $filename);

use for 2,4,8 cells (values may be shifted inside ECU): 
select cells to read by address, dump fast diagnosis setting to file and fill ringbuffer with values


=head2 pd_StartFastName

    $stat = pd_StartFastName(\@names, \@shifts, \@types, $filename, $numberOfCANIds, $isNextPOC);

use for 2,4,8 cells (values may be shifted inside ECU): 
select cells to read by label, dump fast diagnosis values to file
AB12 : use for 28 cells [select cells to read by address, dump fast diagnosis values to file]
Number of CAN IDS supported 1 - 4
isNextPOC = (0 or 1) 0 = false 1 = true

=head2 pd_StartFastNameBuf

    $stat = pd_StartFastNameBuf(\@names, \@shifts, \@types, $filename);

use for 2,4,8 cells (values may be shifted inside ECU): 
select cells to read by label, dump fast diagnosis setting to file and fill ringbuffer with values


=head2 pd_StopFastDiag

    $stat = pd_StopFastDiag();

stop fast diagnosis


=head2 pd_TestEnd

    $stat = pd_TestEnd();

Should to be called at the end, will unload PD.dll


=head2 pd_TestStart

    $stat = pd_TestStart();

Initialize PD DLL. Has to be called before InitConfiguration, InitCommunication. Loads the DLL. 

=head2 pd_WriteAddress

      $stat = pd_WriteAddress($address,\@bytes); 
 e.g. $stat = pd_WriteAddress(hex('8005FD8'),[5,8]);

writes bytes starting from $address, \@bytes has to be a reference to an array of intergers, $address an interger!


=head2 pd_WriteName

     $stat = pd_WriteName($label,\@bytes); 
 e.g.$stat = pd_WriteName('V_IdleFaultNbr_U16R',[12,34]);

writes bytes starting from $name (resolved from SAD file), \@bytes has to be a reference to an array of intergers!


=head2 pd_EleFrgEnableSafetyPath

    ($stat,$value_aref) = pd_EleFrgEnableSafetyPath();

returns response for  Electronic Firing - safety path enabled mode.

=head2 pd_EleFrgFireAllDevices

    ($stat,$value_aref) = pd_EleFrgFireAllDevices();

returns response for  Electronic Firing - Firing all devices.

=head2 pd_ReadCrashRecorder

    $stat,$value_aref) = pd_ReadCrashRecorder($DIDLowerByte);

    ($stat,$value_aref) = pd_ReadCrashRecorder(0x11);
 
 To read crash data from record(EDR).  
 
 returns response in all cases. Success cases on reading data, no crash data and invalid ID
   
=head2 pd_ReadNVMSection

	$stat,$value_aref) = pd_ReadNVMSection(NoofBytes,BlockID);
	
	To read NVM section 
	
=head2 pd_writeNVMSection

	$stat = pd_WriteNVMSection(NoofBytes,BlockID,\@DataBlock);
	
	To write into particular NVM section

=head2 pd_SMI7verification

	($status, $response_aref,$response_length) =  pd_SMI7verification($requestBytes,$no_of_samples);
	
To read SMI7verification data
	
returns response, status and response length

=head2 pd_ManipulateFaultMemory
	
	$status	= pd_ManipulateFaultMemory($faultName, $action);

To qualify or dequalify the fault mentioned. Returns the status of fault manipulation.	 
		
=head1 TRACEABILITY FUNCTIONS

=head2 pd_getCWrevision

returns MKS revision number of Interface.c file

=head2 pd_getPMrevision

returns MKS revision number of .pm file

=head2 pd_getXSrevision

returns MKS revision number of .xs file




=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>


=head1 SEE ALSO

perl, Production diagnosis documentation

=cut
