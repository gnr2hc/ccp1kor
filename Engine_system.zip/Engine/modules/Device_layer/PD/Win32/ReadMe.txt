
About PD_Control.dll:
	It is 32-bit Production Diagnosis DLL used to communicate with ECU.
	It uses Production diagnostic services supported by ECU to get/modify information in the ECU.
	
About vxlapi.dll:
	A 32-bit Vector XL Library which is used to Communicate via CAN, Flexray(Not implemented in PD_Control.dll) protocol. 
	It gives APIs for the low level communication.

About PD.dll:
	A 32-bit perl wrapper dll for C-functions in PD_Control.dll.
	It is compiled using Perl 5.12, 32-bit