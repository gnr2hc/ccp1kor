package LIFT_POWER;

use strict;
use warnings;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_POWER ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  POW_init
  POW_exit
  POW_on
  POW_off
  POW_voltage
);

our ( $VERSION, $HEADER );

my $POWtool;
my $peripherie_device;
my $IDXdevices;
my $voltage      = 0.0;
my $last_voltage = 0.0;
my $last_state   = '';

=head1 NAME

LIFT_POWER 

wrapper class for devices used as power supply.

calls internally LIFT_TOE1, LIFT_GOS1, LIFT_TSG4, LIFT_MLC, LIFT_IDXSPI, LIFT_IDEFIX, LIFT_NIDAQ or S_user_action functions depending on testbench config.

    NOTES for IDX and IXS:
    IXS requires IDEfix with SPI monitor firmware
    IDX requires IDEfix with sensor simulator firmware V3
    for POW_voltage a popup window will appear to set voltage manually !
    if the voltage does not change, the popup is skipped
    POW_on and POW_off will affect all connected IDX devices !

    NOTE for NONE:
    for all commands a popup window will appear to do the action manually !
    if the state/voltage does not change, the popup is skipped


=head1 SYNOPSIS

    use LIFT_POWER;

    POW_init();

    POW_voltage(13.5);
    POW_on();
    sleep(1);
    POW_off();

    POW_exit();


  testbench config example
    'Devices' => {
        'LabCar' => {
            'Hostname' => 'SI54207',
            'Test_Bench_Number' => 10,          # only for logging purpose
            'Description' => "SW Test Team",    # only for logging purpose
            'CANchannel' => 2,
            'CANHWSerialNo' => 28766,       # written on CAN device e.g. "007129-030679" -> 30679
        },
        'TSG4' => {
            'Hostname' => 'SI-Z0CKR',
            'Test_Bench_Number' => 42,      # only for logging purpose
            'Description' => "Franks PC",   # only for logging purpose
            'CANchannel' => 2,
            'CANHWSerialNo' => 28766,       # written on CAN device e.g. "007129-030679" -> 30679
            'POWER' => {
                ### configure power inputs: (internal, TOE1, or GOS1)
                'Ubat' => 'internal',
                'UF' => 'TOE1',             # this will initialize Toellner as well
            },
        },
        'TOE1' => {
            'connect' => 'GPIB:8',
        },
        'GOS1' => {
            'connect' => 'GPIB:3',
        },
        'NIDAQ' =>
        {
          'Device_ID' => 'M6251',  #Devices can be :: M6251
          'Channel_Name' => ['AO0','AO1'], #channel number(s) used for communication, Channel names: AO0  and AO1
        },

    }, ## end of ~~~ Device Configuration Section ~~~
    ### ----------- Function Configuration Section -----------
    'Functions' => {
        ### --- Function Area : Power, select device the power functions will be mapped to (TSG4, LabCar, TOE1, IDX, IXS, GOS1, NIDAQ or NONE)
        'POWER' => {
            'device' => 'TOE1',
        },
           ### --- Function Area : Peripherie, select device where ECU is connected to (TSG4, PeriBox or LabCar)
           'PERIPHERIE' => {
               'device' => 'PeriBox',
        },
    }, ## end of ~~~ Function Configuration Section ~~~

=head1 DESCRIPTION


=head2 POW_init

    POW_init();

initialize POWER hardware according to testbench settings. This will init MLC also if ECU is connected to MLC, but not powered by MLC.
If ECU is connected to TSG4, POWER-device settings will be ignored and TSG4 setting will be taken.

has to be called before any other POW command.

=cut

sub POW_init
{

    unless ( $POWtool = $LIFT_config::LIFT_Testbench->{'Functions'}{'POWER'}{'device'} )
    {
        S_set_error( "No POWER device in testbench config\n", 20 );
        return 1;
    }

    unless ( $peripherie_device = $LIFT_config::LIFT_Testbench->{'Functions'}{'PERIPHERIE'}{'device'} )
    {
        S_set_error( "No PERIPHERIE device in testbench config\n", 20 );
        return 1;
    }

    S_w2log( 4, "POW_init: Initializes power device $POWtool and peripheri device $peripherie_device \n" );

    #if power device is not MLC but peripherie device is MLC, initialize MLC:
    if ( $POWtool ne 'LabCar' and $peripherie_device eq 'LabCar' )
    {
        eval "use LIFT_MLC";
        MLC_InitHW();
        MLC_PSconnect("ALL");
        S_w2rep("ECU is connected to MLC, but not powered by MLC power supply\n");
    }

    if ( $peripherie_device eq 'TSG4' )
    {
        eval "use LIFT_TSG4";

        TSG4_InitHW();
    }
    elsif ( $POWtool eq 'TOE1' )
    {
        eval "use LIFT_TOE1";
        my $TOE1connection;

        unless ( $TOE1connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'TOE1'}{'connect'} )
        {
            S_set_error( " found no TOE1 connection in testbenchconfig\n", 20 );
            return 1;
        }
        my $ppsDeviceID = TOE1_connect($TOE1connection);
        S_w2rep("POW = TOE1 $ppsDeviceID\n");
    }
    elsif ( $POWtool eq 'LabCar' )
    {
        eval "use LIFT_MLC";

        MLC_InitHW();
    }
    elsif ( $POWtool eq 'IDX' )
    {
        eval "use LIFT_IDEFIX";

        $IDXdevices = IDX_InitHW();
    }
    elsif ( $POWtool eq 'IXS' )
    {
        eval "use LIFT_IDXSPI";

        IXS_InitHW();
    }
    elsif ( $POWtool eq 'GOS1' )
    {
        eval "use LIFT_GOS1";

        my $GOS1connection;

        unless ( $GOS1connection = $LIFT_config::LIFT_Testbench->{'Devices'}{'GOS1'}{'connect'} )
        {
            S_set_error( " found no GOS1 connection in testbenchconfig\n", 20 );
            return 1;
        }
        my $ppsDeviceID = GOS1_connect($GOS1connection);
        S_w2rep("POW = GOS1 $ppsDeviceID\n");
    }
    elsif ( $POWtool eq 'NIDAQ' )
    {
        eval "use LIFT_NIDAQ";

        NIDAQ_init();
    }
    elsif ( $POWtool eq 'NONE' )
    {
        S_w2rep("power supply has to be operated manually\n");
    }
    else
    {
        S_set_error( "unknown Power device $POWtool in testbench config\n", 20 );
        return 1;
    }

    S_w2log( 4, "POW_init: Initialization is done \n" );
    return;
}

=head2 POW_voltage

    POW_voltage( $voltage );

set output voltage on POWER hardware.
For NIDAQ, given voltage will be set on both channels 'AO0' and 'AO1'.

=cut

sub POW_voltage
{

    my $volts = shift;

    unless ( defined($volts) )
    {
        S_set_error( "SYNTAX: POW_voltage( voltage )", 110 );
        return 1;
    }

    #map voltage if necessary
    unless ( defined( $voltage = $main::ProjectDefaults->{'VEHICLE'}{$volts} ) )
    {
        if ( $volts =~ /^\d+\.?\d*$/ )
        {
            $voltage = $volts;
        }
        else
        {
            S_set_error( "could not resolve voltage $volts", 114 );
            return 1;
        }
    }

    S_w2log( 4, "POW_voltage: Sets $voltage V of voltage \n" );

    if ( $last_voltage == $voltage )
    {
        S_w2log( 4, "POW_voltage skipped as no change to set the voltage ($last_voltage => $voltage)\n" );
    }
    else
    {
        if ( $peripherie_device eq 'TSG4' )
        {
            TSG4_SetVoltage($voltage);
        }
        elsif ( $POWtool eq 'TOE1' )
        {
            TOE1_PPSvoltage($voltage);
        }
        elsif ( $POWtool eq 'LabCar' )
        {
            MLC_SetVoltage($voltage);
        }
        elsif ( $POWtool eq 'IDX' or $POWtool eq 'IXS' )
        {
            if ($main::opt_offline)
            {
                S_w2log( 4, "POW_voltage skipped for IDX/IXS in offline mode\n" );
            }
            else
            {
                S_user_action("please set voltage to $voltage V");
            }
        }
        elsif ( $POWtool eq 'GOS1' )
        {
            GOS1_voltage($voltage);
        }
        elsif ( $POWtool eq 'NIDAQ' )
        {
            if ( $last_state eq 'ON' )
            {
                NIDAQ_SetVoltage($voltage);    # sets voltage on both channels 'AO0' and 'AO1'  # call NIDAQ_SetVoltage if power is on
            }
            else
            {
                S_w2log( 5, "voltage set to $voltage volts\n" );    # just change voltage variable if power is off
            }
        }
        elsif ( $POWtool eq 'NONE' )
        {
            if ($main::opt_offline)
            {
                S_w2log( 4, "POW_voltage skipped for NONE in offline mode\n" );
            }
            else
            {
                S_user_action("please set voltage to $voltage V");
            }
        }
        else
        {
            S_set_error( "unknown Power device $POWtool in testbench config\n", 20 );
            return 1;
        }
        $last_voltage = $voltage;
    }
    return;
}

=head2 POW_on

    POW_on();

enable output on POWER hardware
For NIDAQ POWER hardware , given voltage value will be set on both channels 'AO0' and 'AO1'.

=cut

sub POW_on
{

    S_w2log( 4, "POW_on->" );

    if ( $last_state eq 'ON' )
    {
        S_w2log( 4, "POW_on skipped as no change ($last_state => ON)\n" );
    }
    else
    {
        # Enabling output power to the power device
        if ( $peripherie_device eq 'TSG4' )
        {
            TSG4_ConnectLine('ALL_SUPPLY');
        }
        elsif ( $POWtool eq 'TOE1' )
        {
            TOE1_PPSon();
        }

        # If labcar is used as a periphery device, line manipulations for connect and disconnect are done by power device only
        # If labcar is used as power device, line manipulations are handled by labcar itself
        elsif ( $POWtool eq 'LabCar' )
        {
            MLC_PSconnect("ALL");
        }
        elsif ( $POWtool eq 'IDX' )
        {
            foreach ( 0 .. $IDXdevices - 1 )
            {
                IDX_SetOutput( $_, 1, 1 );
            }
        }
        elsif ( $POWtool eq 'IXS' )
        {
            IXS_SetOutput( 1, 1 );
        }
        elsif ( $POWtool eq 'GOS1' )
        {
            GOS1_on();
        }
        elsif ( $POWtool eq 'NIDAQ' )
        {
            NIDAQ_SetVoltage($voltage);    # sets voltage on both channels 'AO0' & 'AO1'
        }
        elsif ( $POWtool eq 'NONE' )
        {
            if ($main::opt_offline)
            {
                S_w2log( 4, "POW_on skipped for NONE in offline mode\n" );
            }
            else
            {
                S_user_action("please switch power ON");
            }
        }
        else
        {
            S_set_error( "unknown Power device $POWtool in testbench config\n", 20 );
            return 1;
        }

        $last_state = 'ON';
    }

    return;
}

=head2 POW_off

    POW_off();

disable output on POWER hardware
For NIDAQ POWER hardware , 0 volts will be set on both channels 'AO0' and 'AO1'.

=cut

sub POW_off
{
    if ( $last_state eq 'OFF' )
    {
        S_w2log( 4, "POW_off skipped as no change ($last_state => OFF)\n" );
    }
    else
    {
        # Disabling output power to the power device
        if ( $peripherie_device eq 'TSG4' )
        {
            TSG4_DisconnectLine('ALL_SUPPLY');
        }
        elsif ( $POWtool eq 'TOE1' )
        {
            TOE1_PPSoff();
        }

        # If labcar is used as a periphery device, line manipulations for connect and disconnect are done by power device only
        # If labcar is used as power device, line manipulations are handled by labcar itself
        elsif ( $POWtool eq 'LabCar' )
        {
            MLC_PSdisconnect("ALL");
        }
        elsif ( $POWtool eq 'IDX' )
        {
            foreach ( 0 .. $IDXdevices - 1 )
            {
                IDX_SetOutput( $_, 0, 0 );
            }
        }
        elsif ( $POWtool eq 'IXS' )
        {
            IXS_SetOutput( 0, 0 );
        }
        elsif ( $POWtool eq 'GOS1' )
        {
            GOS1_off();
        }
        elsif ( $POWtool eq 'NIDAQ' )
        {
            NIDAQ_SetVoltage(0);    # sets 0V on both channels 'AO0' and 'AO1'
        }
        elsif ( $POWtool eq 'NONE' )
        {
            if ($main::opt_offline)
            {
                S_w2log( 4, "POW_off skipped for NONE in offline mode\n" );
            }
            else
            {
                S_user_action("please switch power off");
            }
        }
        else
        {
            S_set_error( "unknown Power device $POWtool in testbench config\n", 20 );
            return 1;
        }

        $last_state = 'OFF';
    }

    S_w2log( 4, "POW_off: turn off the power device $POWtool \n" );

    return;
}

=head2 POW_exit

    POW_exit();

has to be called at the end. should be called in ENDcampaign. should have at least 1 second delay to previous POW function call.

=cut

sub POW_exit
{

    # Terminating the communication with power device given in testbench config

    #If MLC is periphery device, decision for lines disconnection given to testcase designer/user

    if ( $POWtool eq 'LabCar' || $peripherie_device eq 'LabCar' )
    {
        MLC_CloseHW();
    }
    elsif ( $peripherie_device eq 'TSG4' )
    {
        TSG4_CloseHW();
    }
    elsif ( $POWtool eq 'TOE1' )
    {
        TOE1_disconnect();
    }
    elsif ( $POWtool eq 'IDX' )
    {
        IDX_CloseHW();
    }
    elsif ( $POWtool eq 'IXS' )
    {
        IXS_CloseHW();
    }
    elsif ( $POWtool eq 'GOS1' )
    {
        GOS1_disconnect();
    }
    elsif ( $POWtool eq 'NIDAQ' )
    {
        NIDAQ_exit();
    }
    elsif ( $POWtool eq 'NONE' )
    {
    }
    else
    {
        S_set_error( "unknown Power device $POWtool in testbench config\n", 20 );
        return 1;
    }

    $last_state = '';
    S_w2log( 4, "POW_exit: Closed the communication with power device $POWtool \n" );

    return;
}

# Preloaded methods go here.

1;
__END__

=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>
G V Sriram, E<lt> VeerabhadraSriram.Grandhi@in.bosch.com E<gt>

=head1 SEE ALSO

perl

=cut
