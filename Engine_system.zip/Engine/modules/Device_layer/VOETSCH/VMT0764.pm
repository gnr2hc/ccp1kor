# *****************************************************************************************************
#                                                                                                       
#  Copyright (c) 2013  Robert Bosch GmBH                                                                
#                      Germany                                                                          
#                      All rights reserved                                                              
#                                                                                                       
#******************************************************************************************************
#******************************************************************************************************

package VMT0764;

use strict;
use warnings;

# need to add in calling module
#BEGIN
#{
#    # add directories to search path for perl modules
#    unshift @INC, dirname( $0 )."/modules/GPIB";
#    unshift @INC, dirname( $0 )."/modules/GPIB/GPIB";
#}

use GPIB;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
   vmt_connect
   vmt_disconnect
   vmt_get_error
   vmt_getCurrentTemperature
   vmt_getTargetTemperature
   vmt_waitForTemperature
   vmt_setRelays
   vmt_setTargetTemperature
   vmt_waitForTemperature

);

our ($VERSION,$HEADER);

my $VMT_handle;
my $targetTemperature='undefined';
my (@vmtErrors,$gpibStatus, $gpibStatusText);


=head1 NAME

VMT0764 

Perl extension for Heraeus Voetsch VMT 07/64 (no OO)

=head1 SYNOPSIS

    use VMT0764;




=head1 DESCRIPTION

remote control functions for Heraeus Voetsch VMT 07/64 using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 ($status) = vmt_connect($connection,$gpibDevice);

Connnect to VMT via given connection. This method has to be called first before any other method can be used.   

A valid connection is e.g. 'GPIB:10'. Make sure wiring is configured accordingly !
$GPIBdevice is usually 0 for first device

it will read the current temperature to check communication and take it as initial target temperature.

=cut

sub vmt_connect {

    my $connection = shift;
    my $gpibDevice = shift;

    if($connection =~ /GPIB:\s*(\d+)/i){
        $VMT_handle = GPIB->new("GPIB::ni", $gpibDevice, $1, 0, GPIB->T3s, 1, 0);
        wait_ms(10);
        unless ($VMT_handle->devicePresent) {
			vmt_set_error('GPIB device not present');
        	return 0;
        }
		$VMT_handle->ibclr;

		# read current temp and take as initial target temp
		my ($status,$temperature) = vmt_getCurrentTemperature();
		$targetTemperature = $temperature;
#		print"target Temp is $targetTemperature\n";

        return $status;
    }
    else{
		vmt_set_error("connection has to be 'GPIB: {address}'");
        return 0;
    }

}



############################################################################################################

=head2 $status = vmt_disconnect( );

Disconnect from VMT

=cut

sub vmt_disconnect{

    return 1;
}



############################################################################################################

=head2 $status = vmt_setRelays( $state );

	$state = 1 (on) or 0 (off)

set Relays at VMT

=cut

sub vmt_setRelays{
	my $state = shift;

	my $string=sprintf("R 0000 000%d\r\n", $state );

	$VMT_handle -> ibwrt($string);
	($gpibStatus, $gpibStatusText)=CheckGPIBerror($VMT_handle);
	vmt_set_error($gpibStatusText) unless($gpibStatus);

    return $gpibStatus;
}


############################################################################################################

=head2 ($status,$temperature) = vmt_getCurrentTemperature();

Returns the current temperature of the VMT temperature chamber in degree Celsius or -1000 in case of error.

=cut

sub vmt_getCurrentTemperature{
	my $string;
	$string = $VMT_handle -> ibrd(37);
	($gpibStatus, $gpibStatusText)=CheckGPIBerror($VMT_handle);
	if($gpibStatus){
		$string =~ m/U1 = (\d+)/;
		chop($string);
		chop($string);
		my $temp = $1;
		$temp /= 10;
		$temp -= 100;
#		print"$temp degC     ($string)\n";

		return (1,$temp);
	}
	else{
		vmt_set_error($gpibStatusText);
		return (0,-1000);
	}
}


############################################################################################################

=head2 $status = vmt_setTargetTemperature( $temperature );

Sets the target temperature of the VMT temperature chamber in degree Celsius.

=cut

sub vmt_setTargetTemperature{

	my $temp = shift;
	$targetTemperature = $temp;

	my $string=sprintf("U1=%04d\r\n", int( abs(-100 - $temp) * 10) ); # 25 C

    $VMT_handle -> ibwrt($string);
	($gpibStatus, $gpibStatusText)=CheckGPIBerror($VMT_handle);
	vmt_set_error($gpibStatusText) unless($gpibStatus);
	return $gpibStatus;
}


############################################################################################################

=head2 ($status,$temperature) = vmt_getTargetTemperature $temperature ();

Gets the last set target temperature in degree Celsius.

=cut

sub vmt_getTargetTemperature{

	return (1,$targetTemperature);
}

############################################################################################################


=head2 vmt_waitForTemperature

    $status = vt_waitForTemperature([$retries,$tolerance]);

Waits until the VMT has reached the temperature set by vmt_setTargetTemperature($temperature); - checks every 60 seconds for +/-$tolerance degC. Gives up after $retries tries. 
Parameter $retries is optional, if not given, 30 is used (results in maximum 30 minutes). 
Parameter $tolerance is optional, if not given, 0.5 is used. 

=cut

sub vmt_waitForTemperature {
    my $retries = shift;
    my $tolerance = shift;

    # use default value if vt_waitForTemperature was called without parameter
    $retries = 30 unless (defined $retries);
    $tolerance = 0.5 unless (defined $tolerance);

    return if ($targetTemperature eq 'undefined');

    my $givenRetries=$retries;
    # wait to reach target temperature +/- 0.5�C
    my ($status, $currentTemp)=vmt_getCurrentTemperature();
    ($status, $targetTemperature)=vmt_getTargetTemperature();
    while ((abs($currentTemp-$targetTemperature) > $tolerance) && ($retries>0)) {
        print "VMT Target: $targetTemperature degC; VT current: $currentTemp degC; tolerance $tolerance; waiting 60s...(try$retries/$givenRetries)\n";
        wait_ms(60000);
        ($status, $currentTemp)=vt_getCurrentTemperature();
        $retries--;
    }
    if ((abs($currentTemp-$targetTemperature) > $tolerance) && ($retries<=0)) {
        print "WARNING Maximum retries reached but target temperature not reached yet!\n"
    }
    else{
    	print "VT Target: $targetTemperature degC; VT current: $currentTemp degC; +/-$tolerance degC reached.\n";
    }
    return 1;
}

=head2 vmt_set_error

 vmt_set_error($errortext)

 collect errors (including callstack) in variable

=cut

sub vmt_set_error{
    my $error_text = shift;

    my @callStack;
    my $count = 2;
    while( defined( (caller($count))[3] ) and $count < 99 ){
    	last if ( (caller($count))[3] eq '(eval)' ); # stop at engine level
        push( @callStack,(caller($count))[3] );
        $count++;
    }

    push(@vmtErrors,"low level error: ".$error_text."\nlow level call stack: { ".join(' -> ',@callStack)." }");
    #print"!!!: $error_text\n";
    return 1;
}

=head2 vmt_get_error

    $errortext = vmt_get_error();

return last errors and clear error

=cut

sub vmt_get_error{

    my $ret=join(";\n",@vmtErrors);
    @vmtErrors=();
    return ($ret);
}

##################################
# internal function
##################################
sub wait_ms{
    my $time = shift;
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms

    return 1;
}

=head2 CheckGPIBerror

    ($gpibStatus, $gpibStatusText) = CheckGPIBerror($gpibHandle);

return last status/errors and clear error

# todo: move to gpib module

=cut

sub CheckGPIBerror{

my $gpib_handle=shift;

my %gpibStat=(
    ERR  => "ERR ",
    TIMO => "TIMO ",
    ENDe  => "END ",
    SRQI => "SRQI ",
    RQS  => "RQS ",
    CMPL => "CMPL ",
    LOK  => "LOK ",
    REM  => "REM ",
    CIC  => "CIC ",
    ATN  => "ATN ",
    TACS => "TACS ",
    LACS => "LACS ",
    DTAS => "DTAS ",
    DCAS => "DCAS ",
);


my ($gStatus,$gError);
$gStatus=$gError='';

    unless ($gpib_handle->devicePresent) {
        return (0,'GPIB device not present');
    }

    my $ibsta = $gpib_handle->ibsta;
    my $iberr = $gpib_handle->iberr;
#		print"error: $iberr\n";

    $gStatus=sprintf("ibsta 0x%04x : ", $ibsta);
#    GPIB->ERR  & $ibsta and print "ERR ";
#    GPIB->TIMO & $ibsta and print "TIMO ";
#    GPIB->ENDe  & $ibsta and print "END ";
#    GPIB->SRQI & $ibsta and print "SRQI ";
#    GPIB->RQS  & $ibsta and print "RQS ";
#    GPIB->CMPL & $ibsta and print "CMPL ";
#    GPIB->LOK  & $ibsta and print "LOK ";
#    GPIB->REM  & $ibsta and print "REM ";
#    GPIB->CIC  & $ibsta and print "CIC ";
#    GPIB->ATN  & $ibsta and print "ATN ";
#    GPIB->TACS & $ibsta and print "TACS ";
#    GPIB->LACS & $ibsta and print "LACS ";
#    GPIB->DTAS & $ibsta and print "DTAS ";
#    GPIB->DCAS & $ibsta and print "DCAS ";
    foreach my $stat (sort keys %gpibStat){
    	GPIB->$stat & $ibsta and $gStatus.= $gpibStat{$stat};
    }

    if ($ibsta & GPIB->ERR) {
    	$gError="GBIB ERR =";
        $gError.=" EDVR System error," if ($iberr == GPIB->EDVR);
        $gError.=" ECIC Board not CIC," if ($iberr == GPIB->ECIC);
        $gError.=" ENOL No listeners," if ($iberr == GPIB->ENOL);
        $gError.=" EADR GPIB board not addressed," if ($iberr == GPIB->EADR);
        $gError.=" EARG Invalid arguments," if ($iberr == GPIB->EARG);
        $gError.=" ESAC GPIB board not system controller," if ($iberr == GPIB->ESAC);
        $gError.=" EABO I/O operation aborted," if ($iberr == GPIB->EABO);
        $gError.=" ENEB Nonexistent GPIB board," if ($iberr == GPIB->ENEB);
        $gError.=" EDMA DMA error," if ($iberr == GPIB->EDMA);
        $gError.=" EOIP Async I/O in progress," if ($iberr == GPIB->EOIP);
        $gError.=" ECAP No capability for operation," if ($iberr == GPIB->ECAP);
        $gError.=" EFSO File system error," if ($iberr == GPIB->EFSO);
        $gError.=" EBUS GPIB bus error," if ($iberr == GPIB->EBUS);
        $gError.=" ESTB Serial poll status queue overflow," if($iberr == GPIB->ESTB);
        $gError.=" ESRQ SRQ stuck in ON position," if ($iberr == GPIB->ESRQ);
        $gError.=" ETAB Table problem," if ($iberr == GPIB->ETAB);
        $gError.=" ELCK Board is locked," if ($iberr == GPIB->ELCK);

        $gpib_handle->ibclr;

		return (0,"$gStatus\n$gError")
    }

    return (1,"$gStatus");
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, Heraeus Voetsch VMT 07/64 manual.

=cut
