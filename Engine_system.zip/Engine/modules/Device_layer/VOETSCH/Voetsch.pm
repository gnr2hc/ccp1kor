# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package Voetsch;

use strict;
use warnings;

use Win32::SerialPort;
use LIFT_simulation;
use LIFT_general;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  vt_connect
  vt_disconnect
  vt_getCurrentTemperature
  vt_getTargetTemperature
  vt_setTargetTemperature
  vt_waitForTemperature
  vt_setProgram
  vt_get_error
  vt_setControlBits
  vt_getControlBits
  vt_setTemperatureGradient
);

our ( $VERSION, $HEADER );

my ( $COM, $unchanged_data, $status );
my $gradientInUse      = 0;
my $recommendationText = "Please check if the Voetsch chamber is switched on and set to external control.";

############################################################################################################

=head1 DESCRIPTION

Control module for Voetsch temperature chamber via serial (COM port) connection 

should work with all Voetsch models supporting ASCII2 serial protocol.

tested models: VT4002 VT4010 VTM7004 VT7010 VT7011 VTS7021-5  

=cut

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 vt_connect

	$status = vt_connect($portNumber);
	
Connnect to Voetsch temperature chamber on $portNumber.

A valid connection is e.g. '1' for COM1.

=cut

sub vt_connect {
    my $portNumber = shift;
    my $data;

    $COM = Win32::SerialPort->new("COM$portNumber");
    unless ($COM) { vt_set_error("Can't open COM$portNumber: $!"); return (0); }

    # fix for USB2serial which does not to return correct information when it is queried for legal baudrates
    # thanx again to the monks http://www.perlmonks.org/bare/?node_id=494713
    $COM->{'_L_BAUD'}{9600} = 9600;

    # setting up all parameters for COM port
    $COM->error_msg(1);
    $COM->user_msg(1);
    $COM->baudrate(9600);
    $COM->parity('none');
    $COM->databits(8);
    $COM->stopbits(1);
    $COM->handshake('none');
    $COM->read_const_time(5000);    # total = (avg * bytes) + const => total timeout 5 sec
    $COM->read_interval(200);       # timeout between chars 0.2 sec
    $COM->binary('T');
    $COM->parity_enable('F');
    $COM->buffers( 1024, 1024 );
    $status = $COM->write_settings();
    unless ($status) { vt_set_error("Error when configuring COM$portNumber port"); return (0); }

    $status = vt_transmit( chr(36) . "00I" );
    return $status unless ($status);
    ( $status, $data ) = vt_receive();
    return $status unless ($status);

    # e.g. 0006.0 0022.0 0050.0 0000.0 0100.0 0100.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 00000000000000000000000000000000

    #VT4010:    -006.0 -005.7 0030.0 0205.1 0000.0 -147.0 0000.0 -147.0 0000.0 -147.0 0061.1 0000.0 0101000000000000
    #VT7010:    0085.0 0021.8 0020.0 -000.7 0000.0 -190.4 0050.0 -190.4 0000.0 -190.4 0050.0 0000.0 0001000000000000
    #VT4002:    -015.0 0022.2 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 01000000000000000000000000000000
    #VTM7004:   0022.0 0023.9 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 01010000000000000000000000000000
    #VT7011:    0085.0 0021.5 0000.0 0000.0 0080.0 0080.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 00000000000000000000000000000000
    #VTS7021-5: 0006.0 0022.0 0050.0 0000.0 0100.0 0100.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 00000000000000000000000000000000

    # split answer string at blanks
    my @values = split( / /, $data );

    # last element is bitfield
    my $bitfield = pop(@values);

    if ( $bitfield !~ /^(0|1)+$/ ) {
        vt_set_error("last element of response is not a bitfield: <$bitfield>");
        return (0);
    }

    # now values contain target,current,target,current, ...
    shift(@values);    # drop target temperature, this will be added in set target temp function later
    shift(@values);    # drop current temperature

    # use only every second target value for send string
    # but if number of target values is <= 2 (new chambers) then use every value
    my $increment = 2;
    if( @values <= 2 ) {
        $increment = 1;
    }
    $unchanged_data = '';
    # add every (or every second) target value to send string
    for ( my $count = 0 ; $count < scalar(@values) ; $count += $increment ) {
        $unchanged_data .= $values[$count] . " ";
    }

    $unchanged_data .= $bitfield;
    S_w2log( 4, "vt_connect: Unchanged Data = $unchanged_data\n" );
    return 1;

}

############################################################################################################

=head2 vt_disconnect

	$status = vt_disconnect();

Disconnnect from Voetsch temperature chamber.

=cut

sub vt_disconnect {
    $COM->close;
    return 1;
}

############################################################################################################

=head2 vt_getControlBits

    ($status, $bitstring) = vt_getControlBits();

reads ControlBits of the Voetsch temperature chamber.

=cut

sub vt_getControlBits {
    my $data = "";

    $status = vt_transmit( chr(36) . "00I" );
    return $status unless ($status);
    ( $status, $data ) = vt_receive();
    return $status unless ($status);

    # target temperature is 1st token in list of tokens separated by spaces
    if ( $data =~ /^(.+)\s+(\S+)/ ) {
        my $unchanged_values = $1;
        my $bits             = $2;
        S_w2log( 5, "vt_getControlBits: got bits:     <$bits>\n" );
        return ( 1, $bits );
    }
    else {
        vt_set_error("could not get control bits");
        return ( 0, '000' );
    }
}
############################################################################################################

=head2 vt_getCurrentTemperature

    ($status, $temperature) = vt_getCurrentTemperature();

Returns the current temperature of the Voetsch temperature chamber.

=cut

sub vt_getCurrentTemperature {
    my $data        = "";
    my $temperature = "";

    $status = vt_transmit( chr(36) . "00I" );
    return ( 0, -9999 ) unless ($status);
    ( $status, $data ) = vt_receive();
    return ( 0, -9999 ) unless ($status);

    # temperature is 2nd token in list of tokens separated by spaces
    if ( $data =~ /^\S+\s+(\S+)/ ) {
        $temperature = $1;
        $temperature =~ s/^0+//;    #drop leading zeroes
        return ( 1, $temperature );
    }
    else {
        vt_set_error("could not read current temperature");
        return ( 0, -9999 );
    }

}

############################################################################################################

=head2 vt_getTargetTemperature

    ($status, $temperature) = vt_getTargetTemperature();

Returns the current temperature of the Voetsch temperature chamber.

=cut

sub vt_getTargetTemperature {
    my $data        = "";
    my $temperature = "";

    $status = vt_transmit( chr(36) . "00I" );
    return ( 0, -9999 ) unless ($status);
    ( $status, $data ) = vt_receive();
    return ( 0, -9999 ) unless ($status);

    # target temperature is 1st token in list of tokens separated by spaces
    if ( $data =~ /^(\S+)\s+/ ) {
        $temperature = $1;
        $temperature =~ s/^0+//;    #drop leading zeroes
        return ( 1, $temperature );
    }
    else {
        vt_set_error("could not read target temperature");
        return ( 0, -9999 );
    }
}

############################################################################################################

=head2 vt_setControlBits

    $status = vt_setControlBits($bitpos,$bitfield);

 $bitpos = bitposition counting from left, starting from 1
 $bitfield = 0 to stop, 1 to start compressor. if you use more bits all will be replaced staring form $bitpos

Sets ControlBits of the Voetsch temperature chamber. Usually 1 bit used to start/stop compressor.

=cut

sub vt_setControlBits {
    my $bitpos   = shift;
    my $bitfield = shift;

    if ( $bitfield !~ /^(0|1)+$/ ) {
        vt_set_error("last parameter is not a bit value: <$bitfield>");
        return (0);
    }

    # split answer string at blanks
    my @values = split( / /, $unchanged_data );

    # last element is bitfield
    my $bits = pop(@values);

    substr( $bits, $bitpos - 1, length($bitfield), $bitfield );
    S_w2log( 5, "vt_setControlBits: sending bits: <$bits>\n" );

    $unchanged_data = join(' ', @values);
    $unchanged_data .= ' '.$bits;

    my $temperature;
    ( $status, $temperature ) = vt_getTargetTemperature();
    return $status unless ($status);
    $status = vt_setTargetTemperature($temperature);
    return $status unless ($status);

    my $readBits;
    ( $status, $readBits ) = vt_getControlBits();

    if ( $readBits ne $bits ) {
        vt_set_error("could not set control bits. $recommendationText");
        return (0);
    }
    else {
        return (1);
    }
}

############################################################################################################

=head2 vt_setTargetTemperature

    $status = vt_setTargetTemperature($temperature);

Sets the target temperature of the Voetsch temperature chamber to $temperature degree celsius.

=cut

sub vt_setTargetTemperature {
    my $temperature = shift;
    my $sendString  = "";
    my $targetTemp;
    my $data;

    # temperature format:       4digits dot 1digit for positive numbers, e.g. 0104.4
    #                     minus 3digits dot 1digit for negative numbers, e.g. -035.1
    $temperature = sprintf( "%06.1f", $temperature );

    $sendString = chr(36) . "00E $temperature $unchanged_data";

    $status = vt_transmit($sendString);

    # wait, flush buffer, read back target temp to check if submit successful
    S_wait_ms(1000);
    empty_buffers();
    return $status unless ($status);    # do error handling after empty buffers in case there was a response

    ( $status, $targetTemp ) = vt_getTargetTemperature();

    if ( not $gradientInUse and $targetTemp != $temperature ) {
        vt_set_error("could not set target temperature. $recommendationText");
        return (0);
    }

    return 1;

}

############################################################################################################

=head2 vt_setProgram

	$status = vt_setProgram($programNumber);

Starts the program $programNumber of the Voetsch temperature chamber. What this program does exactly has to be checked at the Voetsch temperature chamber.

=cut

sub vt_setProgram {
    my $programNumber = shift;
    $programNumber = sprintf( "%04d", $programNumber );
    $status = vt_transmit( chr(36) . "00P" . $programNumber );
    return $status;
}

############################################################################################################

=head2 vt_waitForTemperature

    $status = vt_waitForTemperature([$retries,$tolerance]);

Waits until the VT has reached the temperature set by vt_setTargetTemperature($temperature); - checks every 60 seconds for +/-$tolerance degC. Gives up after $retries tries. 
Parameter $retries is optional, if not given, 30 is used (results in maximum 30 minutes). 
Parameter $tolerance is optional, if not given, 0.5 is used. 

=cut

sub vt_waitForTemperature {
    my $retries   = shift;
    my $tolerance = shift;
    my $currentTemp;
    my $targetTemp;

    # use default value if vt_waitForTemperature was called without parameter
    $retries   = 30  unless ( defined $retries );
    $tolerance = 0.5 unless ( defined $tolerance );

    my $givenRetries = $retries;

    # wait to reach target temperature +/- 0.5�C
    ( $status, $currentTemp ) = vt_getCurrentTemperature();
    ( $status, $targetTemp )  = vt_getTargetTemperature();
    while ( ( abs( $currentTemp - $targetTemp ) > $tolerance ) && ( $retries > 0 ) ) {
        S_w2log( 4, "vt_waitForTemperature: $targetTemp degC; VT current: $currentTemp degC; tolerance $tolerance; waiting 60s...(try$retries/$givenRetries)\n" );
        S_wait_ms(60000);
        ( $status, $currentTemp ) = vt_getCurrentTemperature();
        $retries--;
    }
    if ( ( abs( $currentTemp - $targetTemp ) > $tolerance ) && ( $retries <= 0 ) ) {
        S_set_warning("vt_waitForTemperature: Maximum retries reached but target temperature not reached yet!\n");
    }
    else {
        S_w2log( 4, "vt_waitForTemperature: $targetTemp degC; VT current: $currentTemp degC; +/-$tolerance degC reached.\n" );
    }
    return 1;
}

############################################################################################################

=head2 vt_setTemperatureGradient

    $status = vt_setTemperatureGradient($gradient_Kpm);

Sets the temperature gradient for heating (gradient > 0) or for cooling (gradient < 0).
$gradient_Kpm is in K/min.
If $gradient_Kpm = 0 then the gradient is reset.

=cut

sub vt_setTemperatureGradient {
    my $gradient_Kpm = shift;

    $gradientInUse = 1;
    $gradientInUse = 0 if $gradient_Kpm == 0;

    my $heating = 1;
    if ( $gradient_Kpm < 0 ) {
        $gradient_Kpm *= -1;
        $heating = 0;
    }

    # gradient format: 4digits dot 1digit for positive numbers, e.g. 0010.0
    my $gradientString = sprintf( "%06.1f", $gradient_Kpm );

    my $sendString;
    if ($heating) {
        $sendString = chr(36) . "00U $gradientString 0000.0 0000.0 0000.0";
    }
    else {
        $sendString = chr(36) . "00U 0000.0 $gradientString 0000.0 0000.0";
    }

    $status = vt_transmit($sendString);
    S_wait_ms(1000);
    empty_buffers();

    return $status;
}

=head2 vt_get_error

    $errortext = vt_get_error();

return last error and clear error

=cut

sub vt_get_error {

    return ("Low level error. See previous error message(s).");
}

################ advanced functions ##########

=head1 LOW LEVEL METHODS

=cut

#####################################################################################################

=head2 vt_transmit

	$status = vt_transmit($data);

Transmits the string $data on the COM port. IMPORTANT: this function attaches chr(13) to $data, therefore $data must not contain chr(13).

=cut

sub vt_transmit {
    my $data = shift;
    empty_buffers();

    my $count_out = $COM->write( $data . chr(13) );
    unless ( defined $count_out ) { vt_set_error("write failed"); return (0); }
    if ( $count_out != length($data) + 1 ) { vt_set_error("write incomplete"); return (0); }

    S_w2log( 5, "vt_transmit: Tx: $data ($count_out)\n" );

    return 1;
}

#####################################################################################################

=head2 vt_receive

	($status, $data) = vt_receive();

Reads data from the COM port, terminated by CR = chr(13). Any non-word characters at the end will be dropped.


=cut

sub vt_receive {
    my $data = "";

    my $count = 0;

    ( $count, $data ) = $COM->read(250);

    unless ( $data =~ /\r/ ) {
        vt_set_error(
"Receive timeout! No communication with the chamber. If this is the first communication trial with the Voetsch chamber in this test then please check:\n1) The chamber is switched on\n2) The correct 'connect' port is configured in LIFT_testbenches\n3) For new chambers: The bus address of the chamber is set to 0\n"
        );
        return ( 0, 'error' );
    }

    $data =~ s/\r//g;     # drop all <Lf>
    $data =~ s/\x0//g;    # remove all nullstrings
    $data =~ s/\W+$//;    # drop all non-word characters at end
    chomp($data);
    S_w2log( 5, "vt_receive: Rx: <$data>\n" );

    return ( 1, $data );
}

##################################
# internal function
##################################

=head2 vt_set_error

 vt_set_error($errortext)

 collect errors (including callstack) in variable

=cut

sub vt_set_error {
    my $error_text = shift;
    S_set_error( $error_text, 109 );
    return;
}

sub empty_buffers {
    $COM->purge_all;    # empty buffers
    return 1;
}

##############################################################################################################################
##############################################################################################################################
#
# simulation functions start here
#

if ($main::opt_simulation) {

    # define only those functions that should be redefined (most of the exported functions work even in simulation mode)
    my @redefine = qw( vt_connect vt_disconnect vt_receive vt_transmit empty_buffers );

    # redefine functions for simulation mode with default return values
    foreach my $function (@redefine) {

        no strict 'refs';

        # each function specifed is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = { vt_receive => { 'default' => [ 1, '0006.0 0022.0 0050.0 0000.0 0100.0 0100.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 0000.0 01000000000000000000000000000000' ] }, };
    SIM_addToValuesTable($returnValuesTable_href);
}

1;

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, Voetsch manual.

=cut

