# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_VOETSCH;

use strict;
use warnings;
use File::Basename;

BEGIN {
    use LIFT_general;
    S_add_paths2INC( [ '../GPIB', '../GPIB/GPIB', '../GPIB/Win32' ], [] );
}

use Voetsch;
use VMT0764;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_VT ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  VT_connect
  VT_disconnect
  VT_getCurrentTemperature
  VT_getTargetTemperature
  VT_setTargetTemperature
  VT_setProgram
  VT_setCompressor
  VT_getControlBits
);

our ( $VERSION, $HEADER );

my ( $status, $lastTargetTemperature_degC );
our $VT_connected;    # flag for VT initialization
my $gpibVMT_flag = 0; # flag for VMT via gpib

=head1 NAME

LIFT_VOETSCH 

Perl extension for Voetsch temperature chamber (and Weiss WT11600 and VMT07/64)

=head1 SYNOPSIS

    use LIFT_VOETSCH;

    VT_connect();

    $temperature = VT_getCurrentTemperature();
    $temperature = VT_getTargetTemperature();
    VT_setTargetTemperature(120);
    VT_setProgram(1);

    VT_disconnect();

=head1 DESCRIPTION

remote control functions for Voetsch temperature chamber using serial port or GPIB

should work with all Voetsch models supporting ASCII2 serial protocol and VMT07/64.

B<NOTE: the bus address of temperature chamber has to be set to 0 on control panel !>

tested models: VT4002 VT4010 VTM7004 VT7010 VT7011 VTS7021-5 WT11600 VMT07/64

=head2 Testbench Configuration

=head3 Devices section:

    'Devices' => {
        ...
        'VOETSCH' => {
            'connect'        => 'COM6', # port number
            'compressor_bit' => 2,      # for VT_setCompressor: bitposition counting from left, starting from 1
                                        # if not given it is set to 2
            'GPIB_device'    => 1,      # optional, default is 0 if GPIB connection is used
        },
        ...
    },

B<if you are not sure about the compressor bit position you can do the following:>

    # switch on compressor manually
    # run the test with
    VT_getControlBits();
    S_user_action ( 'please switch off compressor on temperature chamber and press ok' );
    VT_getControlBits();
    # the bit which has changed from 1 to 0 is the compressor bit.

=cut

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 VT_connect

    VT_connect( [$portNumber,$gpibDevice] );

    e.g. VT_connect();
         VT_connect('COM6');
         VT_connect('GPIB:10',1);

Connnect to temperature chamber via given COM/GPIB port. If no connection given, data is taken from Testbenchconfig.

    Testbenchconfig:
    'Devices' => {
        'VOETSCH' => {
            'connect' => 'COM6', # or e.g. 'GPIB:10'
            'GPIB_device' => 1,  # optional, default is 0 if GPIB connection is used
         },


=cut

sub VT_connect {
    my $portNumber = shift;
    my $gpibDevice = shift;
    my $port       = 0;
    unless ( defined($portNumber) ) {
        $portNumber = $LIFT_config::LIFT_Testbench->{'Devices'}{'VOETSCH'}{'connect'};

        unless ($portNumber) {
            S_set_error( "No connection settings for VOETSCH in testbench config found", 20 );
            return 0;
        }
    }
    unless ( defined($gpibDevice) ) {
        $gpibDevice = $LIFT_config::LIFT_Testbench->{'Devices'}{'VOETSCH'}{'GPIB_device'};
        unless ($gpibDevice) {
            $gpibDevice = 0;
        }
    }
    if ($VT_connected) {
        S_w2log( 4, "VT_connect: VOETSCH already initialized\n" );
        return 0;
    }

    if ( $portNumber =~ /GPIB:\s*(\d+)/i ) {
        $gpibVMT_flag = 1;
    }
    elsif ( $portNumber =~ /COM\s*(\d+)/i ) {
        $port = $1;
    }
    else {
        S_set_error( "port number $portNumber is not a valid COM/GPIB port", 109 );
        return 0;
    }

    if ($main::opt_offline) {
        $VT_connected = 1;
        return 1;
    }

    S_w2log( 3, "VT_connect: Connecting to $portNumber\n" );
    if ($gpibVMT_flag) {
        $status = vmt_connect( $portNumber, $gpibDevice );
    }
    else {
        $status = vt_connect($port);
    }

    Check_status($status);
    if ( $status <= 0 ) {
        S_set_error( "could not initialize VOETSCH", 5 );
        $VT_connected = 0;
        return 0;
    }
    $VT_connected = 1;
    S_w2log( 3, "VT_connect: Connection to port $portNumber is established \n" );

    S_w2log( 3, "VT_connect: Switching on VT compressor to make sure temperatures can be set...\n" );
    VT_setCompressor('on');

    return 1;
}

############################################################################################################

=head2 VT_disconnect

    VT_disconnect();

Disconnnect from temperature chamber.

=cut

sub VT_disconnect {

    unless ($VT_connected) {
        S_w2log( 4, "VT_disconnect: VOETSCH not initialized" );
        return 0;
    }
    if ($main::opt_offline) {

        #clear the global flags
        $VT_connected = 0;
        return 1;
    }

    # switch off compressor of the chamber before disconnecting to increase life span of the chamber and to save energy
    VT_setCompressor( 'off' );

    if ($gpibVMT_flag) {
        $status = vmt_disconnect();
    }
    else {
        $status = vt_disconnect();
    }
    Check_status($status);
    $VT_connected = 0;
    S_w2log( 3, "VT_disconnect: Terminated the connection from temperature chamber \n" );
    return 1;
}

############################################################################################################

=head2 VT_getControlBits

    $bitstring = VT_getControlBits();

  e.g.:
                  0101000000000000 = VT_getControlBits(); #VT4010
                  0001000000000000 = VT_getControlBits(); #VT7010
  01000000000000000000000000000000 = VT_getControlBits(); #VT4002
  01010000000000000000000000000000 = VT_getControlBits(); #VTM7004
  00000000000000000000000000000000 = VT_getControlBits(); #VT7011
  00000000000000000000000000000000 = VT_getControlBits(); #VTS7021-5

Returns the control bits of the temperature chamber. Usually used to determine compressor bit.


offline return: 1

=cut

sub VT_getControlBits {
    my $bitstring;
    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }
    if ($main::opt_offline) {
        return 1;
    }

    if ($gpibVMT_flag) {
        $bitstring = 1;
        S_w2log( 3, "VT_getControlBits: ControlBits not required for VMT\n" );
    }
    else {
        ( $status, $bitstring ) = vt_getControlBits();
        Check_status($status);
        S_w2log( 3, "VT_getControlBits: ControlBits: $bitstring\n" );
    }

    return ($bitstring);
}

############################################################################################################

=head2 VT_getCurrentTemperature

    $temperature = VT_getCurrentTemperature();

Returns the current temperature of the temperature chamber in  degree celsius.

offline return: 1

=cut

sub VT_getCurrentTemperature {
    my $temp;
    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }
    if ($main::opt_offline) {
        S_w2log( 3, "VT_getCurrentTemperature: Current Temperature: not read in offline mode\n" );
        return 1;
    }

    if ($gpibVMT_flag) {
        ( $status, $temp ) = vmt_getCurrentTemperature();
    }
    else {
        ( $status, $temp ) = vt_getCurrentTemperature();
    }
    Check_status($status);

    if ( $status >= 0 and defined $LIFT_TSG4::TSG4_initialized and $LIFT_TSG4::TSG4_initialized == 1 ) {
        my $text = $temp . ' ' . chr(0xdf) . 'C';    # chr(0xdf) is � on Rack CPU
        tsg4_rc::rc_display_text( 1, $text, 2 );
    }

    S_w2log( 3, "VT_getCurrentTemperature: Current temperature of chamber is $temp (oC) \n" );
    return ($temp);
}

############################################################################################################

=head2 VT_getTargetTemperature

    $temperature = VT_getTargetTemperature();

Returns the target temperature that was last set by VT_setTargetTemperature in degree celsius.
If VT_setTargetTemperature was never called before then a warning will be thrown and the function
will attempt to read the target temperature from the temperature chamber.

offline return: 1

=cut

sub VT_getTargetTemperature {
    my $temp;
    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }
    if ($main::opt_offline) {
        S_w2log( 4, "VT_getTargetTemperature: Target Temperature: not read in offline mode\n" );
        return 1;
    }

    if ( defined $lastTargetTemperature_degC ) {
        S_w2log( 3, "VT_getTargetTemperature: Target Temperature of chamber (last set) is $lastTargetTemperature_degC (oC) \n" );
        return ($lastTargetTemperature_degC);
    }

    S_set_warning("No target temperature has been set so far in this test run. Trying to read the target temperature set in the chamber...");

    if ($gpibVMT_flag) {
        ( $status, $temp ) = vmt_getTargetTemperature();
    }
    else {
        ( $status, $temp ) = vt_getTargetTemperature();
    }
    Check_status($status);
    S_w2log( 3, "VT_getTargetTemperature: Target Temperature of chamber (read out) is $temp (oC) \n" );
    return ($temp);
}

############################################################################################################

=head2 VT_setCompressor

    VT_setCompressor( $state );

    $state = 'on' or 'off'

    e.g. VT_setCompressor( 'on' );

Sets the compressor of the temperature chamber to $state. compressor_bit position is taken from Testbenchconfig.

=cut

sub VT_setCompressor {
    my $state = shift;
    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }
    unless ( defined($state) ) {
        S_set_error( "SYNTAX: VT_setCompressor( state )", 110 );
        return 0;
    }
    my $bitpos = $LIFT_config::LIFT_Testbench->{'Devices'}{'VOETSCH'}{'compressor_bit'} // 2;

    S_w2log( 3, "VT_setCompressor: Setting Compressor to $state on bit $bitpos (counting from left, starting from 1)\n" );
    return 1 if $main::opt_offline;
    if ( $state eq '1' or uc($state) eq 'ON' ) {
        $state = 1;
    }
    elsif ( $state eq '0' or uc($state) eq 'OFF' ) {
        $state = 0;
    }
    else {
        S_set_error( "unknown state $state ", 110 );
        return 0;
    }

    if ($gpibVMT_flag) {
        $status = vmt_setRelays($state);
    }
    else {
        unless ($bitpos) {
            S_set_error( "No compressor_bit settings for VOETSCH in testbench config found", 20 );
            return 0;
        }
        $status = vt_setControlBits( $bitpos, $state );
    }

    Check_status($status);
    S_w2log( 3, "VT_setCompressor: Compressor of temperature chamber set to state $state\n" );
    return 1;
}

############################################################################################################

=head2 VT_setTargetTemperature

    $success = VT_setTargetTemperature( $temperature_degC [, $gradient_Kpm] );

Sets the target temperature of the temperature chamber to $temperature_degC degree celsius.
Optionally a temperature gradient can be set ($gradient_Kpm in K/min). 
If no gradient is set or if the gradient is higher than the chamber's capabilities 
then the temperature change is done as fast as possible.
Stores the value of $temperature_degC for use in VT_getTargetTemperature.

B<Arguments:>

=over

=item $temperature_degC 

Target temperature in degree celsius.

=item $gradient_Kpm 

(optional) Temperature gradient in K/min.

=back

B<Return Value:>

=over

=item $success 

1 on success and in offline mode, 0 otherwise.

=back

B<Examples:>

    # set target temperature of 25 degC (as fast as possible)
    VT_setTargetTemperature(25);

    # set target temperature of 25 degC with a gradient of 5 K/min
    VT_setTargetTemperature(25, 5);

B<Notes:> 

This function will not change any settings on the temperature chamber, except the target temperature 
and optionally the temperature gradient.

=cut

sub VT_setTargetTemperature {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'VT_setTargetTemperature( $temperature_degC [, $gradient_Kpm] )', @args );

    my $temperature_degC = shift @args;
    my $gradient_Kpm     = shift @args;

    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }

    my $gradientString = '';
    $gradientString = "with a gradient of $gradient_Kpm K/min" if defined $gradient_Kpm;
    S_w2log( 3, "VT_setTargetTemperature: Setting Target Temperature: $temperature_degC degC $gradientString\n" );
    return 1 if $main::opt_offline;

    if ($gpibVMT_flag) {
        if ( defined $gradient_Kpm ) {
            S_set_warning("VT_setTargetTemperature: Temperature gradient is not supported for VMT ovens");
        }
        $status = vmt_setTargetTemperature($temperature_degC);
        Check_status($status) or return 0;
    }
    else {
        if ( defined $gradient_Kpm ) {
            my $currentTemperature_degC;
            ( $status, $currentTemperature_degC ) = vt_getCurrentTemperature();
            Check_status($status) or return 0;
            if ( $currentTemperature_degC > $temperature_degC ) {
                $gradient_Kpm *= -1;
            }
            $status = vt_setTemperatureGradient($gradient_Kpm);
            Check_status($status) or return 0;
        }
        else {
            # reset temperature gradient
            $status = vt_setTemperatureGradient(0);
            Check_status($status) or return 0;
        }

        $status = vt_setTargetTemperature($temperature_degC);
    }

    Check_status($status) or return 0;
    $lastTargetTemperature_degC = $temperature_degC;
    S_w2log( 3, "VT_setTargetTemperature: Setting of target temperature $temperature_degC (oC) is successful \n" );
    return 1;
}

############################################################################################################

=head2 VT_setProgram

    VT_setProgram( $programNumber );

    e.g. VT_setProgram(1);

Starts the program $programNumber of the temperature chamber. What this program does exactly has to be checked at the temperature chamber.

NOT SUPPORTED by VMT device.

=cut

sub VT_setProgram {
    my $prog = shift;
    unless ($VT_connected) {
        S_set_error( "VOETSCH not initialized", 120 );
        return 0;
    }
    unless ( defined($prog) ) {
        S_set_error( "SYNTAX: VT_setProgram( programNumber )", 110 );
        return 0;
    }
    S_w2log( 3, "VT_setProgram: Setting Automatic program to: $prog\n" );
    return 1 if $main::opt_offline;

    if ($gpibVMT_flag) {
        S_set_error( "VMT does not support VT_setProgram", 114 );
        return 0;
    }
    else {
        $status = vt_setProgram($prog);
    }

    Check_status($status);
    return 1;
}

=head1 not exported functions

=head2 Check_status

 Check_status($result)

if result < 0, log error string and set INCONC.

=cut

sub Check_status {
    my $stat = shift;
    my $errortext;

    return 1 if $main::opt_offline;
    unless ($stat) {
        if ($gpibVMT_flag) {
            $errortext = vmt_get_error();
            S_set_error( "Voetsch ($stat): $errortext", 5 );
        }
        return;
    }

    return 1;
}

END {
    # This is called when perl quits, so after the whole test the compressor of the chamber will be switched off 
    # to increase life span of the chamber and to save energy
    VT_setCompressor('off') if $VT_connected;
}

1;

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, Voetsch manual.

=cut
