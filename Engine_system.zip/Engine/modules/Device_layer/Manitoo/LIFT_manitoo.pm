#*****************************************************************************************************
#
#  Copyright (c) 2015  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_manitoo;

=head1 NAME

LIFT_manitoo 

=head1 DESCRIPTION
This module provides the Basic API's for ManiToo and ManiPAS.

Please refer the document for list of services:

g:/MKS/Projects/TurboLIFT/System/Manitoo_PAS_Firmware/Docu/ManiToo_Manual.docx

=head1 SYNOPSIS

    use LIFT_manitoo;

    Initialize the Manitoo Tool ( settings in Testbench config / Project Defaults )

    MANITOO_init();
    calling
   - MANITOO_create_connection()
   - MANITOO_cmd_get_version()
   - MANITOO_cmd_Reset()

    Several pre-trigger conditions can be defined  (see detailed function docu)

    MANITOO_pre_trigger_config( { ... } );
    MANITOO_pre_trigger_config( { ... } );

    Example:
    MANITOO_pre_trigger_config
    (  {
            'nbr' => 0,                             # pre-trigger module number  => for 61 .. 64
            'spi_selection' => 1,                   # SPI selection              => for 61
            'chip_select' => 15,                    # Chip select selection      => for 61
            'frame_mask' => 'FF FF FF FF',          # frame mask selection       => for 62
            'frame_pattern' => '48 D6 18 38',       # frame pattern selection    => for 63
            'trigger_active_time_us' => 5000000     # time active in micro secs  => for 64
        });

    several trigger conditions can be defined   (see detailed function docu)

    MANITOO_trigger_config( { ... } );
    MANITOO_trigger_config( { ... } );

    Example:
        MANITOO_trigger_config
        ( {
            'spi_manipulation_module' => 0,   # SPI manipulation module    => for 31 .. 33, 65 and 72
            'spi_selection' => 1,             # SPI selection              => for 31 and 71
            'chip_select' => 15,              # Chip select selection      => for 31 and 71
            'frame_mask' => 'FF FF FF FF',    # frame mask selection       => for 32
            'frame_pattern' => '48 D6 18 38', # frame pattern selection    => for 33
            'smi7_module' => 3,               # SMI7 module selection      => for 72 ( optional )
            'smi7_page' => 4,                 # SMI7 page for the module   => for 72 ( optional )
            'pre_trigger' => [2, 3]           # pre trigger status mask    => for 65 ( optional )
                                               ( pre-trig module 2 and 3)
        } );

    several write operations can be defined    (see detailed function docu)

    MANITOO_write_config( { ... } );
    MANITOO_write_config( { ... } );

    Example:
        MANITOO_write_config
        ({
            'spi_manipulation_module' => 0,         # SPI manipulation module => for 41 .. 43
            'time_us' => 500 ,                      # manipulation mode       => for 41
            'data_control_1' => '00 00 00 07',      # control data            => 42
            'data_control_2' => '00 00 00 07',      # data                    => 43
        });

    please refer function documentation for different format support.

    MANITOO_trace_start

    START MANITOO

    calling MANITOO_cmd_LOAD_FPGA   +   MANITOO_cmd_START_or_STOP ('START')

    MANITOO_start( );

    use the Manitoo FET ( e.g. for Power On the ECU )

    FET Device 0 ; Port No. 1 will be switched on   ( default settings )
        calling  MANITOO_cmd_FET_control(  0 , { '1' => 'ON' } );

    MANITOO_FET_power_on( );

    ECU is start booting now

    S_wait_ms ( 3000  );  # wait some time until end of test procedure

    MANITOO_trace_stop

    now Manitoo pre-configured operations are ongoing

    STOP MANITOO

        calling  MANITOO_cmd_START_or_STOP ('STOP') +   MANITOO_cmd_PartialReset

    MANITOO_stop() ;


    MANITOO_trace_check_running
    
    MANITOO_trace_store

    use the Manitoo FET ( e.g. for Power Off the ECU )

    FET Device 0 ; Port No. 1 will be switched off  ( default settings )
      calling  MANITOO_cmd_FET_control(  0 , { '1' => 'OFF' } );

    MANITOO_FET_power_off( );

    after all the tests , Manitoo can be disconnected

    MANITOO_exit();


    BASE COMMAND SET ( according Command Catalog )

    MANITOO_cmd_get_version
    MANITOO_cmd_LOAD_FPGA
    MANITOO_cmd_PartialReset
    MANITOO_cmd_START_or_STOP
    MANITOO_cmd_Reset
    MANITOO_cmd_trigger_SPI_CS
    MANITOO_cmd_trigger_FrameMask
    MANITOO_cmd_trigger_FramePattern
    MANITOO_cmd_write_DataCtrl_ModeTime
    MANITOO_cmd_write_DataCtrl_1
    MANITOO_cmd_write_DataCtrl_2
    MANITOO_cmd_Start_SPI_Recording
    MANITOO_cmd_Stop_SPI_Recording
	MANITOO_cmd_Configure_SPI_Data_Size
    MANITOO_cmd_Read_Recorded_SPI_Frames
    
    MANITOO_cmd_WD_CS                   <<<-- NOT IMPLEMENTED YET
    MANITOO_cmd_WD_FrameMask            <<<-- NOT IMPLEMENTED YET
    MANITOO_cmd_WD_FramePattern         <<<-- NOT IMPLEMENTED YET

    MANITOO_cmd_PT_SPI_CS
    MANITOO_cmd_PT_FrameMask
    MANITOO_cmd_PT_FramePattern
    MANITOO_cmd_PT_Time
    MANITOO_cmd_PT_StatusMask
    MANITOO_cmd_SMI7_SPI_CS
    MANITOO_cmd_SMI7_Page
    MANITOO_cmd_FET_control
    MANITOO_cmd_ReadManipulationCounter
    MANITOO_cmd_ExternalTrigger_X8
    MANITOO_cmd_IO_ExtensionPort
    MANITOO_cmd_Request_Response
    
    
    MANITOO_cmd_DYN_SPI_DATA_LOAD
    MANITOO_cmd_DYN_SPI_DATA_START
    MANITOO_cmd_DYN_SPI_DATA_STATUS
    MANITOO_cmd_DYN_SPI_DATA_STOP
    
    MANITOO_exit

=head2 Testbench configuration

    'Devices' => {
                    'Manitoo' => {
                                  'Description' => "only for Manitoo testing ",   # only for logging purpose
                                  'Connection_Type' => 'COM5',
                                    # Supported types 'COM<PORT_NUMBER>', 'USB'
                                    # COM<PORT_NUMBER> : COM port detected when connected to TestPC
                                    # USB : USB-A to USB-A connector.
                                    # Drivers needs to be installed for this : refer link
                                    # https://inside-docupedia.bosch.com/confluence/display/MOBIT/Setup+USB+connection+for+mobiTOOL


                                   # Selection of FET type and ports
                                  'FET_HW_Type' => 'FET_6_Ports', # FET_3_Ports , FET_6_Ports, FET_15_Ports 
                                  'FET_PortsSelection' => 1       # If only one port on/off  -> 1 or 2 or 3...
                                                                  # If multiple ports on/off -> [1,2] or [2,3] ....
                                 },
                 };

=cut

use strict;
use warnings;
use LIFT_general;
use LIFT_evaluation;
use Win32::SerialPort qw( :STAT 0.19 );
use LIFT_simulation;
use Readonly;
use Scalar::Util qw( looks_like_number );
use File::Basename;
require Exporter;
use File::Path;
use IO::Socket::INET;

BEGIN {

    $SIG{__WARN__} = sub {
        my $warning = shift;
        warn $warning unless $warning =~ /Subroutine .* redefined at/;
    };

}

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  MANITOO_init
  MANITOO_exit
  MANITOO_start
  MANITOO_stop
  MANITOO_pre_trigger_config
  MANITOO_trigger_config
  MANITOO_write_config
  MANITOO_FET_power_on
  MANITOO_FET_power_off
  MANITOO_cmd_get_version
  MANITOO_cmd_LOAD_FPGA
  MANITOO_cmd_PartialReset
  MANITOO_cmd_START_or_STOP
  MANITOO_cmd_Reset
  MANITOO_cmd_trigger_SPI_CS
  MANITOO_cmd_trigger_FrameMask
  MANITOO_cmd_trigger_FramePattern
  MANITOO_cmd_write_DataCtrl_ModeTime
  MANITOO_cmd_write_DataCtrl_1
  MANITOO_cmd_write_DataCtrl_2
  MANITOO_cmd_WD_CS
  MANITOO_cmd_WD_FrameMask
  MANITOO_cmd_WD_FramePattern
  MANITOO_cmd_PT_SPI_CS
  MANITOO_cmd_PT_FrameMask
  MANITOO_cmd_PT_FramePattern
  MANITOO_cmd_PT_Time
  MANITOO_cmd_PT_StatusMask
  MANITOO_cmd_SMI7_SPI_CS
  MANITOO_cmd_SMI7_Page
  MANITOO_cmd_Start_SPI_Recording
  MANITOO_cmd_Stop_SPI_Recording
  MANITOO_cmd_Configure_SPI_Data_Size
  MANITOO_cmd_Read_Recorded_SPI_Frames
  MANITOO_cmd_FET_control
  MANITOO_cmd_ReadManipulationCounter
  MANITOO_cmd_ExternalTrigger_X8
  MANITOO_cmd_IO_ExtensionPort
  MANITOO_trace_start
  MANITOO_trace_stop
  MANITOO_trace_store
  MANITOO_trace_load_file
  MANITOO_trace_check_running
  MANITOO_RUN_TEST_SEQUENCE
  MANITOO_RUN_SERVICE
  MANITOO_PAS_cmd_configure_register
  MANITOO_PAS_line_set_quiescent_transmit_current
  MANITOO_PAS_line_set_AutoRestartTiming
  MANITOO_PAS_line_set_Baudrate
  MANITOO_PAS_line_set_Status
  MANITOO_PAS_line_set_Timeslots
  MANITOO_PAS_sensor_set_LineNum_TimeSlot
  MANITOO_PAS_init_Line
  MANITOO_PAS_init_Sensor
  MANITOO_PAS_sensor_set_InitTimes
  MANITOO_PAS_sensor_set_Init_1_Data
  MANITOO_PAS_sensor_set_Init_2_Data
  MANITOO_PAS_sensor_set_Init_3_Data
  MANITOO_PAS_sensor_set_CyclicMsgs
  MANITOO_PAS_sensor_set_UserMsgs
  MANITOO_PAS_sensor_set_UserEvent
  MANITOO_PAS_sensor_switch_off
  MANITOO_PAS_sensor_switch_on
  MANITOO_PAS_IO_Expansion
  MANITOO_cmd_Request_Response
  MANITOO_PAS_line_get_status_info
  MANITOO_PAS_line_get_reboot_counter
  MANITOO_PAS_line_reset_reboot_counter
);

our ( $VERSION, $HEADER );

my $PortObj;

my $mn2_initialised     = 0;
my $dynamic_stimulation = 0;
my $donot_care_bit      = 0;
my $pas_cmd_hex         = '';

my $global_Version_nbr_3byte_string = "";    # storing read version nbr e.g. "030001" , will be written in MANITOO_cmd_get_version

my $global_Version_nbr_for_SPI_trace_min = "040005";
my $global_Version_nbr_for_SPI_trace_max = "FFFFFF";
my $global_Version_nbr_for_SPI_manip_min = "030001";
my $global_Version_nbr_for_SPI_manip_max = "FFFFFF";
my $global_Version_nbr_for_PAS_min       = "040005";
my $global_Version_nbr_for_PAS_max       = "FFFFFF";

my $global_SPI_trace_running           = 0;
my $global_SPI_trace_start_addr        = "";
my $global_SPI_trace_end_addr          = "";
my $global_SPI_trace_store_size_bytes  = 0;
my $global_SPI_manip_region_start_addr = "";
my $global_SPI_manip_region_end_addr   = "";
my $global_SPI_manip_region_size_bytes = 0;

Readonly::Scalar my $SPI_TRACE_STORED_BYTES_PER_FRAME        => 32;
Readonly::Scalar my $SPI_MANIP_REGION_DEFAULT_LEADING_FRAMES => 1000;
Readonly::Scalar my $SPI_MANIP_REGION_DEFAULT_FOLLOW_FRAMES  => 2000;    # to be tried out how long follow-up frames are useful

# PAS service hash with key as line number in integer and value as line number in hex.
Readonly::Scalar my $PAS_LINES_HREF => {
    1  => '01',
    2  => '02',
    3  => '03',
    4  => '04',
    5  => '05',
    6  => '06',
    7  => '07',
    8  => '08',
    9  => '09',
    10 => '0A',
    11 => '0B',
    12 => '0C',
};

Readonly::Scalar my $PAS_SERVICE_HREF => {
    line     => 'B0',
    module   => 'B1',
    dataArea => 'B2'
};

Readonly::Scalar my $LOG_FILE_BYTES_PER_FRAME => 32;

# Structure of information in one line of manitoo log file (.log)
Readonly::Scalar my $BYTE_NBR_CHIPSELECT                    => 0;
Readonly::Scalar my $BYTE_NBR_FRAME_MANIP_AND_MSG_INDICATOR => 2;
Readonly::Scalar my $BYTE_NBR_TOOLS_ID                      => 3;
Readonly::Scalar my $BYTE_NBR_MESSAGE_NUM                   => 4;
Readonly::Scalar my $BYTE_NBR_TIME_NS                       => 8;
Readonly::Scalar my $BYTE_NBR_TIME_US                       => 12;
Readonly::Scalar my $BYTE_START_NBR_MOSI_FRAME              => 16;
Readonly::Scalar my $BYTE_END_NBR_MOSI_FRAME                => 23;
Readonly::Scalar my $BYTE_START_NBR_MISO_FRAME              => 24;
Readonly::Scalar my $BYTE_END_NBR_MISO_FRAME                => 31;
Readonly::Scalar my $OFFSET_BYTE_LENGTH                     => 3;

Readonly::Scalar my $SERIAL_PORT_MAX_READ_BYTES => 4096;

my $fet_type_href = {

    FET_3_Ports  => 0,    #FET_3_Ports -> FET Ports type, 0 -> command code for FET device type
    FET_6_Ports  => 1,
    FET_15_Ports => 2,
};

if ($main::opt_simulation) {
    no strict 'refs';     # TODO : Perl::Critics Don't turn off strict for large blocks of code (See page 433 of PBP)

    # define all functions that should be redefined (because they access the serial port)
    my @redefine = qw(
      MANITOO_create_connection
      MANITOO_exit
      MANITOO_cmd_Request_Response
      Version_Check_PAS
    );

    #      MANITOO_cmd_get_version

    $PortObj = 1;

    # redefine all functions for simulation mode with default return values, except the functions in @exclude
    foreach my $function (@redefine) {

        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = {
        'MANITOO_exit'                 => { 'default' => [1] },
        'MANITOO_create_connection'    => { 'default' => [1] },
        'MANITOO_cmd_Request_Response' => { 'default' => [ 1, [] ] },
        'Version_Check_PAS'            => { 'default' => [1] }
    };
    SIM_addToValuesTable($returnValuesTable_href);
}

=head2 MANITOO_init

    Syntax : MANITOO_init ();

This Function reads the COM port number from Test bench and creates a Serial port for ManiToo and
    does the port settings for communication.

    Called subroutines :
      - MANITOO_create_connection()
      - MANITOO_cmd_get_version()
      - MANITOO_cmd_Reset()

    Input arguments  : None

    Return Value     : 1 upon success, 0 upon error

=cut

sub MANITOO_init {
    if ($mn2_initialised) {
        S_set_warning("Manitoo already initialised. Nothing done\n");
        return 1;
    }

    my $manitoo_connection_type = S_get_contents_of_hash( [ 'Devices', 'Manitoo', 'Connection_Type' ], $LIFT_config::LIFT_Testbench );
    unless ( defined $manitoo_connection_type ) {
        S_set_error( "In LIFT_Testbenches.pm 'Connection_Type' for Device 'Manitoo' is not defined ( shall be only 'COM' currently )", 109 );
        return 0;
    }

    #IF Is connection type COM|USB|ETH?
    #IF-NO-START
    #STEP Error invalid connection
    #IF-NO-END

    unless ( $manitoo_connection_type =~ /^(COM\d\d?)|(USB|ETH)$/ ) {
        S_set_error( "In LIFT_Testbenches.pm 'Connection_Type' for Device 'ManiToo' shall be 'COM' | 'USB' ( currently set : '$manitoo_connection_type')", 109 );
        return 0;
    }

    #IF-YES-START
    #CALL MANITOO_create_connection
    #IF-YES-END
    my $conn_status = MANITOO_create_connection($manitoo_connection_type);
    unless ($conn_status) {
        S_set_error("Error when during call MANITOO_create_connection( $manitoo_connection_type ) \n");
        return 0;
    }

    $mn2_initialised = 1;    # global var

    my ( $status, $response_hex_aref, $version_string ) = MANITOO_cmd_get_version();

    if ( $manitoo_connection_type ne 'USB' ) {
        unless ($status) {
            S_set_error("Call of MANITOO_cmd_get_version() failed");
            GetStatus_SerialPort();
            return;
        }
    }

    MANITOO_cmd_Reset() || return;

    #STEP END
    return 1;
}

=head2 MANITOO_create_connection

    Syntax : MANITOO_create_connection ();

This function creates a new serial port for COM /Socket port(for USB or ETH) for Manitoo Communication with Test PC
and updates the global variable $PortObj.

    Input arguments  : None

    Return Value     : 1 upon success, 0 upon error

Serial Port settings :
    Baudrate = 115200
    Databits = 8
    Stopbits = 1
    Parity = none
    Handshake = none

Socket port settings ;

    PeerHost => $host_IP, # $host_IP is fixed as 10.0.0.1 for connection type USB.
                          # for connection type 'ETH', enter the IP(x.x.x.x) and 
                          # name it as manitoo in C:\windows\system32\drivers\etc\hosts
                          # e.g 10.46.2.25 manitoo
        
        
    PeerPort => '7777', # '7777' for connection type USB, '80' for connection type ETH
    Proto    => 'tcp',

    In simulation Mode :: returns 1

    In offline Mode    :: sets $PortObj , returns 1

=cut

sub MANITOO_create_connection {
    my $manitoo_connection_type = shift;

    unless ( $manitoo_connection_type =~ /^(COM\d\d?)|(USB|ETH)$/ ) {
        S_set_error(" Manitoo connection type '$manitoo_connection_type' not supported, Supported types are 'COM' and 'USB'  \n");
        return;
    }

    if ($main::opt_offline) {
        $PortObj = 1;
        return 1;
    }

    #IF Is connection type COM?
    #IF-YES-START
    #CALL Create_SerialPort_connection
    if ( $manitoo_connection_type =~ /^COM(\d+)/ ) {
        S_w2log( 3, " MANITOO_create_connection: Trying to open serial port " . $manitoo_connection_type . "\n" );
        return 0 unless ( Create_SerialPort_connection($manitoo_connection_type) );
    }

    #IF-YES-END

    #IF-NO-START
    #CALL Create_Socket_connection
    if ( $manitoo_connection_type =~ /^(USB|ETH)/ ) {
        S_w2log( 3, " MANITOO_create_connection: Trying to open Socket port " . $manitoo_connection_type . "\n" );
        return 0 unless ( Create_Socket_connection($manitoo_connection_type) );
    }

    #IF-NO-END

    #STEP END
    return 1;
}

=head2 Create_Socket_connection

    Create_Socket_connection ($manitoo_connection_type);
    
B<Arguments:>

=over

=item $manitoo_connection_type

Possible types USB or ETH

    Socket port settings ;

    PeerHost => $host_IP, # $host_IP is fixed as 10.0.0.1 for connection type USB.
                          # for connection type 'ETH', enter the IP(x.x.x.x) and 
                          # name it as manitoo in C:\windows\system32\drivers\etc\hosts
                          # e.g 10.46.2.25 manitoo
        
        
    PeerPort => 7777, # 7777 for connection type USB, 80 for connection type ETH
    Proto    => 'tcp',

=back

B<Return values:>

    1 on success 0 on failure.

=cut

sub Create_Socket_connection {
    my $manitoo_connection_type = shift;

    my $host_IP = '10.0.0.1';    # default IP for type USB
    my $port_ID = 7777;        # default port for type USB

    # auto-flush on socket
    $| = 1;
    if ( $manitoo_connection_type eq 'USB' ) {
        $PortObj = new IO::Socket::INET(
            PeerHost => $host_IP,
            PeerPort => $port_ID,
            Proto    => 'tcp',
        );
        unless ($PortObj) {
        	S_w2log(3, "MANITOO_create_connection: First attempt for USB socket port creation not successful - try again.");
	        $PortObj = new IO::Socket::INET(
	            PeerHost => $host_IP,
	            PeerPort => $port_ID,
	            Proto    => 'tcp',
	        );   		
        }
    }

    # ETH not for users, only for manitoo development team.
    else {
        $PortObj = new IO::Socket::INET(
            PeerHost => 'manitoo',
            PeerPort => 80,        # default fixed port for ethernet
            Proto    => 'tcp',
        );
    }
    unless ($PortObj) {
        S_set_error("Creating $manitoo_connection_type socket port was not successful: $^E . Check Manitoo $manitoo_connection_type connection and power supply.");
        return 0;
    }

    S_w2log( 3, "MANITOO_create_connection: ... Socket port creation done!\n" );
    return 1;
}

=head2 Create_SerialPort_connection

    Create_SerialPort_connection ($manitoo_connection_type);


B<Description:>

    Creates serial port for manitoo connection type COM.

B<Arguments:>

=over

=item $manitoo_connection_type

Possible types USB or ETH

=back

B<Return values:>

    1 on success, 0 on failure.

=cut

sub Create_SerialPort_connection {
    my $manitoo_connection_type = shift;
    $PortObj = new Win32::SerialPort( $manitoo_connection_type, 1 );    # TODO : Subroutine "new" called using indirect syntax (See page 349 of PBP) Perl Critic
    unless ($PortObj) {
        S_set_error("Creating port $manitoo_connection_type was not successful: $^E . Check Manitoo USB connection and power supply.");
        return 0;
    }
    S_w2log( 3, "MANITOO_create_connection: ... Port creation done!\n" );

    $PortObj->lookclear();                                              # empty buffers
    $PortObj->baudrate(115200);
    $PortObj->databits(8);
    $PortObj->stopbits(1);
    $PortObj->parity('none');
    $PortObj->handshake('none');
    S_w2log( 3, " MANITOO_create_connection: Write settings : baudrate(115200) , databits(8) , stopbits(1) , parity('none') ,  handshake('none') , lookclear() \n" );
    my $stat = $PortObj->write_settings();

    unless ($stat) {
        S_set_error("Error when configuring $manitoo_connection_type port");
        return 0;
    }

    my $Configuration_File_Name_1 = "C:\\temp\\CFG_MANITOO_PORT_1.cfg";
    $PortObj->save($Configuration_File_Name_1) || S_set_warning("Can't save $Configuration_File_Name_1: $^E\n");

    GetStatus_SerialPort() || return;
}

sub GetStatus_SerialPort {

    S_w2log( 3, " GetStatus_SerialPort: PortObj->status() \n " );
    my ( $BlockingFlags, $InBytes, $OutBytes, $LatchErrorFlags ) = ( 0, 0, 0, 0 );
    ( $BlockingFlags, $InBytes, $OutBytes, $LatchErrorFlags ) = $PortObj->status() || S_set_warning("could not get port status: $^E \n");

    S_w2log( 3, "GetStatus_SerialPort: BlockingFlags = $BlockingFlags , InBytes = $InBytes , OutBytes = $OutBytes , LatchErrorFlags = $LatchErrorFlags \n" );

    if ( $BlockingFlags & BM_fCtsHold )  { S_set_warning("SerialPort: BM_fCtsHold ( Waiting for CTS )"); }
    if ( $BlockingFlags & BM_fDsrHold )  { S_set_warning("SerialPort: BM_fDsrHold"); }
    if ( $BlockingFlags & BM_fRlsdHold ) { S_set_warning("SerialPort: BM_fRlsdHold"); }
    if ( $BlockingFlags & BM_fXoffHold ) { S_set_warning("SerialPort: BM_fXoffHold"); }
    if ( $BlockingFlags & BM_fXoffSent ) { S_set_warning("SerialPort: BM_fXoffSent"); }
    if ( $BlockingFlags & BM_fEof )      { S_set_warning("SerialPort: BM_fEof"); }
    if ( $BlockingFlags & BM_fTxim )     { S_set_warning("SerialPort: BM_fTxim"); }
    if ( $BlockingFlags & BM_AllBits )   { S_set_warning("SerialPort: BM_AllBits"); }

    if ( $LatchErrorFlags & CE_FRAME )    { S_set_warning("SerialPort: Framing Error"); }
    if ( $LatchErrorFlags & CE_RXOVER )   { S_set_warning("SerialPort: CE_RXOVER"); }
    if ( $LatchErrorFlags & CE_OVERRUN )  { S_set_warning("SerialPort: CE_OVERRUN"); }
    if ( $LatchErrorFlags & CE_RXPARITY ) { S_set_warning("SerialPort: CE_RXPARITY"); }
    if ( $LatchErrorFlags & CE_BREAK )    { S_set_warning("SerialPort: CE_BREAK"); }
    if ( $LatchErrorFlags & CE_TXFULL )   { S_set_warning("SerialPort: CE_TXFULL"); }
    if ( $LatchErrorFlags & CE_MODE )     { S_set_warning("SerialPort: CE_MODE"); }

    return 1;
}

=head2 MANITOO_exit

    Syntax : MANITOO_exit ();

This function closes the serial port that was created in MANITOO_init for Manitoo Communication with Test PC
and updates the global variable $PortObj accordingly.

    Input arguments  : None

    Return Value     : 1 upon success, 0 upon error

Note : to be implemented for Manitoo communication via Ethernet.

    In simulation Mode :: returns 1

    In offline Mode    :: clears $PortObj, returns 1

=cut

sub MANITOO_exit {
    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call function MANITOO_init first\n", 0 );
        return 0;
    }

    if ($main::opt_offline) {
        $PortObj         = 0;
        $mn2_initialised = 0;
        return 1;
    }

    unless ( $PortObj->close() ) {
        S_set_error( " Close of Serial Connection  failed\n", 0 );
        return 0;
    }

    S_w2log( 3, " MANITOO_exit: Serial Connection closed!\n" );
    undef $PortObj;
    $mn2_initialised = 0;
    return 1;
}

=head2 MANITOO_start

    Syntax : $status = MANITOO_start();

This function starts the manipulation.

Calling :
    MANITOO_cmd_LOAD_FPGA
    MANITOO_cmd_START_or_STOP ('START')

    Return in Success  :    $status = 1

    Return in Error    :    $status = undef

    Return Offline     :    $status = 1

=cut

sub MANITOO_start {
    S_w2log( 5, " MANITOO_start: Processing Start of Manipulation ... \n" );
    unless ($mn2_initialised) {
        S_set_error("Manitoo not initialised. Please call function MANITOO_init first\n");
        return 0;
    }

    if ($dynamic_stimulation) {
        MANITOO_cmd_DYN_SPI_DATA_START() || return;
    }
    else {
        MANITOO_cmd_LOAD_FPGA() || return;
        MANITOO_cmd_START_or_STOP('START') || return;
    }

    S_w2log( 3, " MANITOO_start: Processing of Manitoo configuration - STARTED - now. \n" );

    return 1;
}

=head2 MANITOO_stop

    Syntax : $status = MANITOO_stop();

This function stops the manipulation.

    Calling :
        MANITOO_cmd_START_or_STOP ('STOP')
        MANITOO_cmd_PartialReset

    Return in Success  :    $status = 1

    Return in Error    :    $status = undef

    Return Offline     :    $status = 1

=cut

sub MANITOO_stop {
    S_w2log( 5, " MANITOO_stop: Processing Stop of Manipulation ... \n" );
    unless ($mn2_initialised) {
        S_set_error("Manitoo not initialised. Please call function MANITOO_init first\n");
        return 0;
    }

    if ($dynamic_stimulation) {
        MANITOO_cmd_DYN_SPI_DATA_STOP() || return;
    }
    else {
        MANITOO_cmd_START_or_STOP('STOP') || return;
        MANITOO_cmd_PartialReset() || return;
    }

    S_w2log( 3, " MANITOO_stop: Processing of Manitoo configuration - STOPPED - now. \n" );

    return 1;
}

=head2 MANITOO_FET_power_on

    Syntax : $status = MANITOO_FET_power_on( $fet_device_ID , $fet_port_nbr );

This function defines the port numbers to be switched on for the specific FET device.

FET 0 has 1 .. 3 ports

FET 1 has 1 .. 6 ports

FET 2 has 1 .. 15 ports

    Calling :
        MANITOO_cmd_FET_control(  $fet_device_ID , { $fet_port_nbr => 'ON' } ).

Default $fet_device_ID = 0

Default $fet_port_nbr = 1

B<Arguments:>

=over

=item $fet_device_ID

FET device type used.

    Range: 0 - 2 ( int )

           0 -> FET_3_Ports
           1 -> FET_6_Ports
           2 -> FET_15_Ports

=item $fet_port_nbr

Port number to be switched on
 
    Range: 1 - 3  ( FET_3_Ports )
           1 - 6  ( FET_6_Ports )
           1 - 15 ( FET_15_Ports )

=back

B<Return Value:>

    Return in Success  : 1

    Return in Error    : undef

    Return Offline     : 1


Examples :

    # use the Default setting 0 , 1 if FET type and port number not configured in testbench
    MANITOO_FET_power_on();

    # use the FET type and port number defined in 'FET_HW_Type' and 'FET_PortsSelection' from LIFT_Testbenches if defined.
    MANITOO_FET_power_on();
    
    # use the FET type 1 (FET_6_Ports) and port number 4 (LIFT_Testbenches settings will not be considered).
    MANITOO_FET_power_on( 1 , 4 );

=cut

sub MANITOO_FET_power_on {

    my @args = @_;

    return unless S_checkFunctionArguments( 'MANITOO_FET_power_on ( [ $fet_device_ID , $fet_port_nbr ] )', @args );

    my $fet_device_ID = shift;
    my $fet_port_nbr  = shift;

    my ( $fet_type, $ports );
    unless ( $fet_device_ID and $fet_port_nbr ) {
        $fet_type = S_get_contents_of_hash_NOERROR( [ 'Devices', 'Manitoo', 'FET_HW_Type' ],        $LIFT_config::LIFT_Testbench );
        $ports    = S_get_contents_of_hash_NOERROR( [ 'Devices', 'Manitoo', 'FET_PortsSelection' ], $LIFT_config::LIFT_Testbench );
    }

    my $fet_device_ID__default = 0;
    my $fet_port_nbr__default  = 1;

    if ( defined $fet_type ) {

        my ( $fet_device, $ports_href ) = Process_fet_type( $fet_type, $ports, 'ON' );
        unless ( $fet_device or $ports_href ) {
            S_set_error( "MANITOO_FET_power_on: Manitoo port(s) configuration failed, please check configuartion!", 109 );
            return;
        }

        my ( $status, $response_aref ) = MANITOO_cmd_FET_control( $fet_device, $ports_href );
        unless ($status) {
            S_set_error(" MANITOO_FET_power_on not successful");
            return;
        }

        S_w2log( 2, "MANITOO_FET_power_on: POWER ON operation completed \n" );

    }
    else {
        unless ( defined $fet_device_ID ) {
            S_w2log( 4, " MANITOO_FET_power_on: FET_device_ID not given => set to '$fet_device_ID__default' by default\n" );
            $fet_device_ID = $fet_device_ID__default;
        }

        unless ( defined $fet_port_nbr ) {
            S_w2log( 4, " MANITOO_FET_power_on: FET_port_nbr not given => set to '$fet_port_nbr__default' by default\n" );
            $fet_port_nbr = $fet_port_nbr__default;
        }

        my ( $status, $response_aref ) = MANITOO_cmd_FET_control( $fet_device_ID, { $fet_port_nbr => 'ON' } );
        unless ($status) {
            S_set_error(" MANITOO_FET_power_on not successful");
            return;
        }
        S_w2log( 3, " MANITOO_FET_power_on: POWER ON operation completed \n" );

    }

    return 1;
}

=head2 MANITOO_FET_power_off

    Syntax : $status = MANITOO_FET_power_off( [,$fet_device_ID , $fet_port_nbr] );

This function defines the port numbers to be switched on for the specific FET device.

FET 0 has 1 .. 3 ports.

FET 1 has 1 .. 15 ports.

FET 2 has 1 .. 15 ports.

    Calling :
        MANITOO_cmd_FET_control(  $fet_device_ID , { $fet_port_nbr => 'OFF' } ).

Default $fet_device_ID = 0

Default $fet_port_nbr = 1

B<Arguments:>

=over

=item $fet_device_ID

FET device type used.

    Range: 0 - 2 ( int )

           0 -> FET_3_Ports
           1 -> FET_6_Ports
           2 -> FET_15_Ports

=item $fet_port_nbr

Port number to be switched off
 
        Range: 1 - 3  ( FET_3_Ports )
               1 - 6  ( FET_6_Ports )
               1 - 15 ( FET_15_Ports )

=back

B<Return Value:>

    Return in Success  : 1

    Return in Error    : undef

    Return Offline     : 1

Examples :

    # use the Default setting 0 , 1 if FET type and port number not configured in LIFT_Testbenches
    MANITOO_FET_power_off();   

    # use the FET type and port number defined in 'FET_HW_Type' and 'FET_PortsSelection' from LIFT_Testbenches if defined.
    MANITOO_FET_power_off();    
    
    # use the FET type 1 (FET_6_Ports) and port number 4 (LIFT_Testbenches settings will not be considered).
    MANITOO_FET_power_off( 1 , 4 );

=cut

sub MANITOO_FET_power_off {

    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_FET_power_off ( [ $fet_device_ID , $fet_port_nbr ] )', @args );

    my $fet_device_ID = shift;
    my $fet_port_nbr  = shift;

    my ( $fet_type, $ports );

    unless ( $fet_device_ID and $fet_port_nbr ) {
        $fet_type = S_get_contents_of_hash_NOERROR( [ 'Devices', 'Manitoo', 'FET_HW_Type' ],        $LIFT_config::LIFT_Testbench );
        $ports    = S_get_contents_of_hash_NOERROR( [ 'Devices', 'Manitoo', 'FET_PortsSelection' ], $LIFT_config::LIFT_Testbench );
    }

    my $fet_device_ID__default = 0;
    my $fet_port_nbr__default  = 1;

    if ( defined $fet_type ) {

        my ( $fet_device, $ports_href ) = Process_fet_type( $fet_type, $ports, 'OFF' );
        unless ( $fet_device or $ports_href ) {
            S_set_error( "MANITOO_FET_power_off: Manitoo port(s) configuration failed, please check configuartion!", 109 );
            return;
        }

        my ( $status, $response_aref ) = MANITOO_cmd_FET_control( $fet_device, $ports_href );
        unless ($status) {
            S_set_error(" MANITOO_FET_power_off not successful");
            return;
        }
        S_w2log( 2, "MANITOO_FET_power_off: POWER OFF operation completed \n" );

    }
    else {
        unless ( defined $fet_device_ID ) {
            S_w2log( 4, " MANITOO_FET_power_off: FET_device_ID not given => set to '$fet_device_ID__default' by default\n" );
            $fet_device_ID = $fet_device_ID__default;
        }

        unless ( defined $fet_port_nbr ) {
            S_w2log( 4, " MANITOO_FET_power_off: FET_port_nbr not given => set to '$fet_port_nbr__default' by default\n" );
            $fet_port_nbr = $fet_port_nbr__default;
        }

        my ( $status, $response_aref ) = MANITOO_cmd_FET_control( $fet_device_ID, { $fet_port_nbr => 'OFF' } ) || return;
        unless ($status) {
            S_set_error(" MANITOO_FET_power_off not successful");
            return;
        }
        S_w2log( 3, " MANITOO_FET_power_off: POWER OFF operation completed \n" );
    }

    return 1;
}

=head2 MANITOO_pre_trigger_config

    Syntax :: $status = MANITOO_pre_trigger_config( $pre_tri_input_href );

This function configures the SPI, CS, frame mask and pattern, as well as trigger active time for the pre trigger
    functionality in MANITOO.

Input arguments :

    $pre_tri_input_href = {
                           'nbr' => $pre_trigger_module_int,
                           'spi_selection' => $spi_selection_int ,                     # => for 61
                           'chip_select' => $cs_selection_int ,                        # => for 61

                           'frame_mask' => $frame_mask_hex_str ,                       # => for 62
                           'frame_pattern' => $frame_pattern_hex_str ,                 # => for 63

                           'trigger_active_time_us' => $trigger_active_time_us ,       # => for 64
                          }

    $pre_trigger_module_int = integer ( 0..3 ),

    $spi_selection_int      = integer ( 1..4 ),

    $cs_selection_int       = integer ( 1..20 ),

    $frame_mask_hex_str     = String ('dddddddd'), frame mask in 4 hex bytes string
                                                            (8 character: [0-9A-F])
    $frame_pattern_hex_str  = String ('dddddddd'), frame mask in 4 hex bytes string
                                                                     (8 character: [0-9A-F])

    Allowed hex string formats:
        a) 'dddddddd' -> 'F8000000'
        b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
        c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
        d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'

    $trigger_active_time_us = integer ( 0 - 4294967295 ).

    Returns 1 on success (all MANITOO commands returned successfully).

    Return in Success  :    $status = 1,

    Return in Error    :    $status = 0,

    Return Offline     :    1.

Calling functions :

    MANITOO_cmd_PT_SPI_CS            <- 'spi_selection' + 'chip_select',

    MANITOO_cmd_PT_FrameMask         <- 'frame_mask',

    MANITOO_cmd_PT_FramePattern      <- 'frame_pattern',

    MANITOO_cmd_PT_Time              <- 'trigger_active_time_us'.

Example1(Success) :

    MANITOO_pre_trigger_config({
                                    'nbr' => 0,
                                    'spi_selection' => 1,
                                    'chip_select' => 15,
                                    'frame_mask' => 'FF FF FF FF',
                                    'frame_pattern' => '48 D6 18 38',
                                    'trigger_active_time_us' => 5000000
                               });

    Return Value : $status = 1;

Example2(Error) :

    MANITOO_pre_trigger_config({
                                    'NBR' => 4,
                                    'SPI_SELECTION' => 1,
                                    'CHIP_SELECT' => 15,
                                    'FRAME_MASK' => 'FF FF FF FF',
                                    'FRAME_PATTERN' => '48 D6 18 38',
                                    'TRIGGER_ACTIVE_TIME_US' => 5000000
                               });

    Error : MANITOO_pre_trigger_config : Pre Trigger module value '4'
                is out of range, should be in the range 0 .. 3(integer value).

    Return  Value : $status = 0


=cut

sub MANITOO_pre_trigger_config {

    my @args = @_;

    return 0 unless S_checkFunctionArguments( 'MANITOO_pre_trigger_config( $pre_tri_input_href )', @args );

    my $pre_tri_input_href = shift;

    # hash defines the set of valid keys
    my $valid_pre_trig_keys = {
        'nbr'                    => 1,
        'spi_selection'          => 1,
        'chip_select'            => 1,
        'frame_mask'             => 1,
        'frame_pattern'          => 1,
        'trigger_active_time_us' => 1
    };

    # convert all the configured keys to lower case
    %$pre_tri_input_href = map { lc $_ => $pre_tri_input_href->{$_} } keys %$pre_tri_input_href;

    #collect the keys which are invalid
    my @invalid_keys = grep { !exists( $$valid_pre_trig_keys{$_} ) } keys %$pre_tri_input_href;
    my @mand_keys    = grep { !exists( $$pre_tri_input_href{$_} ) } keys %$valid_pre_trig_keys;

    # error if the keys are wrongly configured
    if (@invalid_keys) {
        local $" = ', ';
        my @valid_keys = keys %$valid_pre_trig_keys;
        S_set_error( "MANITOO_pre_trigger_config :: The key(s) < @invalid_keys > configured are invalid. Valid keys are < @valid_keys >\n", 109 );
        return 0;
    }

    # error if the mandatory keys are not configured
    if (@mand_keys) {
        local $" = ', ';
        my @valid_keys = keys %$valid_pre_trig_keys;
        S_set_error( "MANITOO_pre_trigger_config :: The key(s) ' @mand_keys ' is(are) mandatory.\n", 109 );
        return 0;
    }

    my $pre_trigger_module_int = $pre_tri_input_href->{'nbr'};                       # pre-trigger module in integer
    my $spi_selection_int      = $pre_tri_input_href->{'spi_selection'};             # SPI selection in integer
    my $cs_selection_int       = $pre_tri_input_href->{'chip_select'};               # chip select selection in integer
    my $frame_mask_hex_str     = $pre_tri_input_href->{'frame_mask'};                # frame mask in in hexadecimal string
    my $frame_pattern_hex_str  = $pre_tri_input_href->{'frame_pattern'};             # frame pattern in hexadecimal string
    my $trigger_active_time_us = $pre_tri_input_href->{'trigger_active_time_us'};    # trigger active time in micro seconds

    my $response_aref_hex = [];

    if ( $pre_trigger_module_int < 0 or $pre_trigger_module_int > 3 ) {
        S_set_error( "MANITOO_pre_trigger_config : Pre Trigger module value '$pre_trigger_module_int' is out of range, should be in the range 0 .. 3(integer value)\n", 109 );
        return 0;
    }

    if ( $spi_selection_int < 1 or $spi_selection_int > 4 ) {
        S_set_error( "MANITOO_pre_trigger_config : SPI selection value '$spi_selection_int' is out of range, should be in the range 1 .. 4(integer value)\n", 109 );
        return 0;
    }

    if ( $cs_selection_int < 0 or $cs_selection_int > 19 ) {
        S_set_error( "MANITOO_pre_trigger_config : Chip Select value '$cs_selection_int' is out of range, should be in the range 0 .. 19(integer value)\n", 109 );
        return 0;
    }

    S_w2log( 5, "MANITOO_pre_trigger_config : Calling function  'MANITOO_cmd_PT_SPI_CS' ..\n" );
    my $status;
    ( $status, $response_aref_hex ) = MANITOO_cmd_PT_SPI_CS( $pre_trigger_module_int, $spi_selection_int, $cs_selection_int );

    # error handling for input parameters covered in function MANITOO_cmd_PT_SPI_CS

    unless ( $status == 1 ) {
        S_set_error( "MANITOO_pre_trigger_config : Function call 'MANITOO_cmd_PT_SPI_CS' not successful\n", 23 );
        return 0;
    }

    $frame_mask_hex_str =~ s/[-\s*]//g;    #remove '-' and spaces
    $frame_mask_hex_str =~ s/^0x//g;       #remove '0x'

    S_w2log( 5, "MANITOO_pre_trigger_config : Calling function  'MANITOO_cmd_PT_FrameMask' ..\n" );
    ( $status, $response_aref_hex ) = MANITOO_cmd_PT_FrameMask( $pre_trigger_module_int, $frame_mask_hex_str );

    # error handling for input parameters covered in function MANITOO_cmd_PT_FrameMask
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_pre_trigger_config : Function call 'MANITOO_cmd_PT_FrameMask' not successful\n", 23 );
        return 0;
    }

    $frame_pattern_hex_str =~ s/[-\s*]//g;    #remove '-' and spaces
    $frame_pattern_hex_str =~ s/^0x//g;       #remove '0x'

    S_w2log( 5, "MANITOO_pre_trigger_config : Calling function  'MANITOO_cmd_PT_FramePattern' ..\n" );
    ( $status, $response_aref_hex ) = MANITOO_cmd_PT_FramePattern( $pre_trigger_module_int, $frame_pattern_hex_str );

    # error handling for input parameters covered in function MANITOO_cmd_PT_FramePattern
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_pre_trigger_config : Function call 'MANITOO_cmd_PT_FramePattern' not successful\n", 23 );
        return 0;
    }

    S_w2log( 5, "MANITOO_pre_trigger_config : Calling function  'MANITOO_cmd_PT_Time' ..\n" );
    ( $status, $response_aref_hex ) = MANITOO_cmd_PT_Time( $pre_trigger_module_int, $trigger_active_time_us );

    # error handling for input parameters covered in function MANITOO_cmd_PT_Time
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_pre_trigger_config : Function call 'MANITOO_cmd_PT_Time' not successful\n", 23 );
        return 0;
    }

    return 1 if ($main::opt_offline);

    return $status;
}

=head2 MANITOO_trigger_config

    Syntax : $status = MANITOO_trigger_config( $tri_input_href );

This function configures the SPI, CS, frame mask and pattern for the Manitoo trigger.
In case of some SMI7 frames, the sensor page must be configured.
In case the pre trigger functionality is used, the active pre triggers will be configured.

Input arguments :

    $tri_input_href  =  {
                          'spi_manipulation_module' => $spi_manipulation_module_int,  # for all
                          'spi_selection' => $spi_selection_int ,                     # => for 31 and 71
                          'chip_select' => $cs_selection_int ,                        # => for 31 and 71

                          'frame_mask' => $frame_mask_hex_str ,                       # => for 32
                          'frame_pattern' => $frame_pattern_hex_str ,                 # => for 33

                          'smi7_module' =>  $smi7_module_number_int ,                 # => for 72, optional
                          'smi7_page' =>  $smi7_page_number_int ,                     # => for 72, optional

                          'pre_trigger' => $active_pre_trigger_aref ,                 # => for 65, optional
                        }
    $frame_mask_hex_str              = String ('dddddddd'), frame mask in 4 hex bytes string
                                                 (8 character: [0-9A-F])
    $frame_pattern_hex_str           = String ('dddddddd'), frame mask in 4 hex bytes string
                                                 (8 character: [0-9A-F])

    Allowed hex string formats:

        a) 'dddddddd' -> 'F8000000'
        b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
        c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
        d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'.

    'spi_manipulation_module' => $spi_manipulation_module_int :  0 (0 - 11 dec)

    'spi_selection' => $spi_selection_int :  2
    'chip_select' => $cs_selection_int :  1

    'frame_mask' => $frame_mask_hex_str       :  'F8000000'
    'frame_pattern' => $frame_pattern_hex_str :  'F0000000'

    'smi7_module' => $smi7_module : 2, integer (0 - 3 dec) , SMI7 module ( of the internal physical sensor )

    'smi7_page' => $smi7_page : 2, integer (0 - 7 dec) , SMI7 page ( of the internal physical sensor module )

    'pre_trigger' => $active_pre_trigger_aref : [0, 1] , array ref can contain list of dec numbers in range 0 - 3 ( list of active pre trigger modules )

Calling functions   :

    MANITOO_cmd_trigger_SPI_CS        <-  'spi_selection' + 'chip_select'

    MANITOO_cmd_SMI7_SPI_CS           <-  'spi_selection' + 'chip_select'

    MANITOO_cmd_SMI7_Page             <-  'smi7_page'

    MANITOO_cmd_trigger_FrameMask     <-  'frame_mask'

    MANITOO_cmd_trigger_FramePattern  <-  'frame_pattern'

    MANITOO_cmd_PT_StatusMask         <-  'pre_trigger'.

Return values :

    Return in Success  :    $status = 1,

    Return in Error    :    $status = 0,

    Return Offline     :    1

    Returns 1 on success (all MANITOO commands returned successfully).

Example1(Success)  :

    MANITOO_trigger_config({
                            'SPI_MANIPULATION_MODULE' => 1,
                            'SPI_SELECTION' => 3,
                            'CHIP_SELECT' => 15,
                            'FRAME_MASK' => 'FF-FF-FF-FF',
                            'FRAME_PATTERN' => '48 D6 18 38',
                            'SMI7_MODULE' => 3,
                            'SMI7_PAGE' => 4,
                            'PRE_TRIGGER' => [2, 3]
                         });

    Return value        :   $status = 1;

Example2(Error)    :

    MANITOO_trigger_config({
                            'SPI_MANIPULATION_MODULE' => 1,
                            'SPI_SELECTION' => 3,
                            'CHIP_SELECT' => 15,
                            'FRAME_MASK' => 'FF-FF-FF-FFAD',
                            'FRAME_PATTERN' => '48 D6 18 38',
                            'SMI7_MODULE' => 3,
                            'SMI7_PAGE' => 4,
                            'PRE_TRIGGER' => [2, 3]
                          });

    Error : MANITOO_cmd_trigger_FrameMask : The length of frame mask 'FFFFFFFFAD' should be of
                4 byte hexadecimal value.

    Return value : $status = 0;

=cut

sub MANITOO_trigger_config {

    my @args = @_;

    return 0 unless S_checkFunctionArguments( 'MANITOO_trigger_config( $tri_input_href )', @args );

    my $tri_input_href = shift;

    # hash defines the set of valid keys
    my $valid_trig_keys = {
        'spi_manipulation_module' => 1,
        'spi_selection'           => 1,
        'chip_select'             => 1,
        'frame_mask'              => 1,
        'frame_pattern'           => 1,
        'smi7_module'             => 1,
        'smi7_page'               => 1,
        'pre_trigger'             => 1
    };

    my $mandatory_keys = {
        'spi_manipulation_module' => 1,
        'spi_selection'           => 1,
        'chip_select'             => 1,
        'frame_mask'              => 1,
        'frame_pattern'           => 1
    };

    # convert all the configured keys to lower case
    %$tri_input_href = map { lc $_ => $tri_input_href->{$_} } keys %$tri_input_href;

    #collect the keys which are invalid
    my @invalid_keys = grep { !exists( $$valid_trig_keys{$_} ) } keys %$tri_input_href;
    my @mand_keys    = grep { !exists( $$tri_input_href{$_} ) } keys %$mandatory_keys;

    # error if the keys are wrongly configured
    if (@invalid_keys) {
        local $" = ', ';
        my @valid_keys = keys %$valid_trig_keys;
        S_set_error( "MANITOO_trigger_config :: The key(s) < @invalid_keys > configured are invalid. valid keys are < @valid_keys >\n", 109 );
        return 0;
    }

    # error if the mandatory keys not configured
    if (@mand_keys) {
        local $" = ', ';
        S_set_error( "MANITOO_trigger_config :: The key(s) ( @mand_keys ) is/are mandatory\n", 109 );
        return 0;
    }

    my $spi_manipulation_module_int = $tri_input_href->{'spi_manipulation_module'};    # SPI manipulation module in integer
    my $spi_selection_int           = $tri_input_href->{'spi_selection'};              # SPI selection in integer
    my $cs_selection_int            = $tri_input_href->{'chip_select'};                # chip select selection in integer
    my $frame_mask_hex_str          = $tri_input_href->{'frame_mask'};                 # frame mask in in hexadecimal string
    my $frame_pattern_hex_str       = $tri_input_href->{'frame_pattern'};              # frame pattern in hexadecimal string
    my $smi7_module_number_int      = $tri_input_href->{'smi7_module'};                # smi7 module selection in integer
    my $smi7_page_number_int        = $tri_input_href->{'smi7_page'};                  # smi7 page selection in integer
    my $active_pre_trigger_aref     = $tri_input_href->{'pre_trigger'};                # trigger active time in micro seconds

    my $response_aref_hex = [];

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_trigger_config : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 .. 11(integer value)\n", 109 );
        return 0;
    }

    if ( $spi_selection_int < 1 or $spi_selection_int > 4 ) {
        S_set_error( "MANITOO_trigger_config : SPI selection value '$spi_selection_int' is out of range, should be in the range 1 .. 4(integer value)\n", 109 );
        return 0;
    }

    if ( $cs_selection_int < 0 or $cs_selection_int > 19 ) {
        S_set_error( "MANITOO_trigger_config : Chip Select value '$cs_selection_int' is out of range, should be in the range 0 .. 19(integer value)\n", 109 );
        return 0;
    }

    if ( defined $smi7_module_number_int ) {
        if ( $smi7_page_number_int eq '' ) {
            S_set_error( "MANITOO_trigger_config : Key 'smi7_page' should be defined, when the key 'smi7_module' is defined.\n", 109 );
            return 0;
        }
    }

    if ( defined $smi7_page_number_int ) {
        if ( $smi7_module_number_int eq '' ) {
            S_set_error( "MANITOO_trigger_config : Key 'smi7_module' should be defined, when the key 'smi7_page' is defined.\n", 109 );
            return 0;
        }
    }

    if ( defined $smi7_module_number_int and ( $smi7_module_number_int < 0 or $smi7_module_number_int > 3 ) ) {
        S_set_error( "MANITOO_trigger_config : SMI7 module selection value '$smi7_module_number_int' is out of range, should be in the range 0 to 3(integer value)\n", 109 );
        return 0;
    }

    if ( defined $smi7_page_number_int and ( $smi7_page_number_int < 0 or $smi7_page_number_int > 7 ) ) {
        S_set_error( "MANITOO_trigger_config : SMI7 page number selection value '$smi7_page_number_int' is out of range, should be in the range 0 to 7(integer value)\n", 109 );
        return 0;
    }

    unless ($mn2_initialised) {
        S_w2rep("Initialized variable $mn2_initialised");
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return 0;
    }

    S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_trigger_SPI_CS' ..\n" );
    my $status;

    # call service 31
    ( $status, $response_aref_hex ) = MANITOO_cmd_trigger_SPI_CS( $spi_manipulation_module_int, $spi_selection_int, $cs_selection_int );
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_trigger_SPI_CS' not successful\n", 23 );
        return 0;
    }

    $frame_mask_hex_str =~ s/[-\s*]//g;
    $frame_mask_hex_str =~ s/^0x//g;

    # call service 32
    S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_trigger_FrameMask' ..\n" );
    ( $status, $response_aref_hex ) = MANITOO_cmd_trigger_FrameMask( $spi_manipulation_module_int, $frame_mask_hex_str );
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_trigger_FrameMask' not successful\n", 23 );
        return 0;
    }

    $frame_pattern_hex_str =~ s/[-\s*]//g;
    $frame_pattern_hex_str =~ s/^0x//g;

    # call service 33
    S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_trigger_FrameMask' ..\n" );
    ( $status, $response_aref_hex ) = MANITOO_cmd_trigger_FramePattern( $spi_manipulation_module_int, $frame_pattern_hex_str );
    unless ( $status == 1 ) {
        S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_trigger_FramePattern' not successful\n", 23 );
        return 0;
    }

    if ( ( defined $smi7_module_number_int ) and ( defined $smi7_page_number_int ) ) {

        # call service 71
        S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_SMI7_SPI_CS' ..\n" );
        ( $status, $response_aref_hex ) = MANITOO_cmd_SMI7_SPI_CS( $spi_selection_int, $cs_selection_int );
        unless ( $status == 1 ) {
            S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_SMI7_SPI_CS' not successful\n", 23 );
            return 0;
        }

        # call service 72
        S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_SMI7_Page' ..\n", "blue" );
        ( $status, $response_aref_hex ) = MANITOO_cmd_SMI7_Page( $spi_manipulation_module_int, $smi7_module_number_int, $smi7_page_number_int );
        unless ( $status == 1 ) {
            S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_SMI7_Page' not successful\n", 23 );
            return 0;
        }
    }

    if ( defined $active_pre_trigger_aref ) {

        # collect module values configured greater than 3
        my @module_check = grep { $_ > 3 } @$active_pre_trigger_aref;

        # set error if module values not in range 0 .. 3
        if ( scalar @module_check >= 1 ) {
            local $" = ', ';
            S_set_error( "MANITOO_trigger_config : The pre-trigger module(s) value(s) [ @module_check ] configured for the key 'pre_trigger' is invalid. Valid range 0 .. 3\n", 109 );
            return 0;
        }

        my $pre_trigger_status_mask_int = 0;

        foreach my $pre_trig (@$active_pre_trigger_aref) {

            $pre_trigger_status_mask_int = 2**($pre_trig) | $pre_trigger_status_mask_int;
        }

        # call service 65
        S_w2log( 5, "MANITOO_trigger_config : Calling function  'MANITOO_cmd_PT_StatusMask' ..\n" );
        ( $status, $response_aref_hex ) = MANITOO_cmd_PT_StatusMask( $spi_manipulation_module_int, $pre_trigger_status_mask_int );

        unless ( $status == 1 ) {
            S_set_error( "MANITOO_trigger_config : Function call 'MANITOO_cmd_PT_StatusMask' not successful\n", 23 );
            return 0;
        }
    }
    return 1 if ($main::opt_offline);

    return 1;
}

=head2 MANITOO_write_config

    Syntax : $status = MANITOO_write_config( $write_input_href );

This function prepares the data which will be manipulated on the SPI.

Therefore, the mode and time / number of frames is set. The supported modes are SPI mode and TIM (Timer) mode.
    When the parameter 'time_us' is given, TIM mode is set.
    When the parameter 'frames' is given, SPI mode is set.
    Both parameters can't be given at the same time, since only 1 mode can be supported at a time.

Then, the data which is to be manipulated is prepared. The data can be given to this function in various formats.
The function will convert all formats to match the required input parameters for MANITOO_cmd_write_DataCtrl_1 and
MANITOO_cmd_write_DataCtrl_2.
The format depends on which parameters are given. A subset of these parameters defines the format:
'data_control_1', 'data_control_2', 'masked_value_bin', 'mask_hex', 'value_hex', 'position', 'length'
Only 1 format can be chosen with 1 function call.
Only the parameters defining this format are given mandatorily, all other parameters which describe the other formats must not be given.

The supported formats are described in the following.:

    1) Data Control Format (DC-Format)
        'data_control_1' and 'data_control_2'

    2) Masked Value Bin Format ( MVB-Format )
        'masked_value_bin'

    3) Mask + Value Format ( MV-Format )
        'masked_hex' and 'value_hex'

    4) Postion + Length + Value Format ( PLV-Format )
        'position', 'length', 'value_hex'

Manitoo supports 15 manipulation data sets. Some parameters can be given as a scalar (only one data set is used) or as an array (various data sets are used).
If more than one data set is given, the number of data sets (size of the array) must be consistent throughout all parameters.
See 'Input arguments' and 'Example1(Success)' for details.

Input arguments :

    $write_input_href = {
      'spi_manipulation_module' => $spi_manipulation_module_int,    # for all

      'time_us' => $time_us ,           # for TIM mode, service 41
      'frames' => $nbr_of_frames ,      # for SPI mode, service 41

      'data_control_1' => $data_control_1 ,     # for 42
      'data_control_2' => $data_control_2 ,     # for 43

      'masked_value_bin' =>  $masked_value_bin ,    # for 42 and 43

      'mask_hex' => $mask_hex ,       # for 42 and 43

      'position' => $bit_position,    # for 42 and 43
      'length' => $signal_length,     # for 42 and 43

      'value_hex' => $value,          # for 42 and 43
    }
  );

    'spi_manipulation_module' => $spi_manipulation_module_int :  0 (0 - 11 dec)

    'time_us' : 500, integer ( 0 - 268435455 dec ) or 'infinite'
                SCALAR -> same time value for all data sets
                ARRAY -> different time value for each data set

    'frames'  : 50, integer ( 0 - 268435455 dec ) or 'infinite'
                SCALAR -> same nbr of frames for all data sets
                ARRAY -> different nbr of frames for each data set

    'data_control_1'  :   '00 00 00 07', 4 byte hex string of control data
                          SCALAR -> 1 data set
                          ARRAY -> x data sets (x is array size)

    'data_control_2'   :  '00 00 00 07', 4 byte hex string of data
                          SCALAR -> 1 data set
                                      ARRAY -> x data sets (x is array size)

    'masked_value_bin' :  '-------0100ii0100000011--00101--', 32 bit mask and value ('-' or 'x': don't change; 0: clear bit; 1: set bit)
                          SCALAR -> 1 data set
                          ARRAY -> x data sets (x is array size)

    'mask_hex'  : '00 07 FF F8', 4 byte hex string which chooses the bits that will be overwritten by 'value_hex'
                                 The bits to be overwritten by 'value_hex' must be set to 1.
                                 They must be directly next to each other, no 0's in between.

    'position'  : 4, start bit position starting count 0 from right to left in 32 bit frame

    'length'    : 6, number of bits to be manipulated - must match number of relevant bits given in 'value_hex' (leading zeros might be ignored)

    'value_hex' : 'FF 17', hex string of data value to write (nbr of bits in value should be smaller than number of bits set to 1 in 'mask_hex')
                  SCALAR -> 1 data set
                  ARRAY -> x data sets (x is array size)

Calling functions :

    MANITOO_cmd_write_DataCtrl_ModeTime (41)   <-  'time_us' or 'frames' + 'spi_manipulation_module'

    MANITOO_cmd_write_DataCtrl_1 (42)

    MANITOO_cmd_write_DataCtrl_2 (43)

    Validate_write_inputs

    Write_mvb_format

    Write_dc_format

    Write_mv_format

    Write_plv_format

Return Values :

    Returns 1 on success (all MANITOO commands returned successfully).

    Return in Success  :    $status = 1,

    Return in Error    :    $status = 0,

    Return Offline     :    1

Example1(Success)  :    Various examples for different formats, modes, and number of data sets are given in the following:

    1) Data Control Format (DC-Format)

         a) 1 data set, TIM mode

        $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => 500 ,
                                           'data_control_1' => '00 00 00 07',
                                           'data_control_2' => '00 00 00 07',
                                          }
                                        );
        Return : 1;

         b) 3 data sets, SPI mode, nbr of frames the same for all data sets

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'frames' => 2 ,
                                           'data_control_1' => ['00 00 00 07', '00 00 00 07', '00 00 00 07'],
                                           'data_control_2' => ['00 00 00 03', '00 00 00 02', '00 00 00 01'],
                                          }
                                        );
         Return : 1;

         c) 3 data sets, SPI mode, varying nbr of frames

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'frames' => [2, 1, 1]s ,
                                           'data_control_1' => ['00 00 00 07', '00 00 00 07', '00 00 00 07'],
                                           'data_control_2' => ['00 00 00 03', '00 00 00 02', '00 00 00 01'],
                                          }
                                        );
         Return : 1;

    2) Masked Value Bin Format ( MVB-Format )

         a) 1 data set, TIM mode

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => 500 ,
                                           'masked_value_bin' => '-------0100ii0100000011--00101--',
                                          }
                                        );
         Return : 1;

         b) 2 data sets, TIM mode, varying time values

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => [500, 1000] ,
                                           'masked_value_bin' => ['xxxxxxxxxxxx0100ii0100000011xxxx',
                                                                    'xxxxxxxxxxxx0100ii0100000011xxxx'],
                                          }
                                        );
         Return : 1;

    3) Mask + Value Format ( MV-Format )

         a) 1 data set, SPI mode

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'frames' => 2 ,
                                           'mask_hex' => '00 07 FF F8',
                                           'value_hex' => '     FF 17',
                                          }
                                        );
         Return : 1;

        b) 3 data sets, TIM mode, same time for all data sets
                'mask_hex' stays scalar, there is only one possible mask to give but various values!

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => 500 ,
                                           'mask_hex' => '00 07 FF F8',
                                           'value_hex' => [ '80 17' , '1F 11' , 'F1 07' ],
                                          }
                                        );
         Return : 1;

   4) Postion + Length + Value Format ( PLV-Format )

        a) 1 data set, SPI mode

         $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => 500 ,
                                           'position' => 16,
                                           'length' => 8,
                                           'value_hex' => 'FA',
                                          }
                                        );
         Return : 1;

        b) 3 data sets, TIM mode, different time for each data set
                'position' and 'length' stay scalar!

        $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'time_us' => [500 , 250, 1000] ,
                                           'position' => 16,
                                           'length' => 8,
                                           'value_hex' => [ 'FA' , 'FB' , 'FC' ],
                                          }
                                        );
        Return : 1;

Example2(Error) :

    Data Control Format (DC-Format)

         a) 1 data set, TIM mode

        $status = MANITOO_write_config(
                                         {
                                           'spi_manipulation_module' => 0,
                                           'data_control_1' => '00 00 00 07',
                                           'data_control_2' => '00 00 00 07',
                                          }
                                        );
    Error : Validate_write_inputs : Atleast any one of the key(s) 'time_us' or 'frames'
                should be configured for the mode selection in function 'MANITOO_write_config'.

    Return : 0;

=cut

sub MANITOO_write_config {

    my @args = @_;

    return 0 unless S_checkFunctionArguments( 'MANITOO_write_config( $write_input_href )', @args );

    my $write_input_href = shift;

    # hash defines the set of valid keys
    my $valid_write_keys = {
        'spi_manipulation_module' => 1,
        'time_us'                 => 1,
        'frames'                  => 1,
        'data_control_1'          => 1,
        'data_control_2'          => 1,
        'masked_value_bin'        => 1,
        'mask_hex'                => 1,
        'position'                => 1,
        'length'                  => 1,
        'value_hex'               => 1
    };

    # convert all the configured keys to lower case
    %$write_input_href = map { lc $_ => $write_input_href->{$_} } keys %$write_input_href;

    #collect the keys which are invalid
    my @invalid_keys = grep { !exists( $$valid_write_keys{$_} ) } keys %$write_input_href;

    # error if the keys are wrongly configured
    if (@invalid_keys) {
        local $" = ', ';
        my @valid_keys = keys %$valid_write_keys;
        S_set_error( "MANITOO_write_config :: The key(s) < @invalid_keys > configured are invalid. valid keys are < @valid_keys >\n", 109 );
        return 0;
    }

    my $spi_manipulation_module_int = $write_input_href->{'spi_manipulation_module'};    # SPI manipulation module in integer
    my $time_us                     = $write_input_href->{'time_us'};                    # time in micro seconds
    my $nbr_of_frames               = $write_input_href->{'frames'};                     # number of SPI frames in integer
    my $data_control_1              = $write_input_href->{'data_control_1'};             # 4 byte hex string of control data
    my $data_control_2              = $write_input_href->{'data_control_2'};             # 4 byte hex string of data
    my $masked_value_bin            = $write_input_href->{'masked_value_bin'};           # masked value in 32 bit binary string
    my $bit_index                   = $write_input_href->{'position'};                   # bit position of the data to be manipulated in integer
    my $bit_length                  = $write_input_href->{'length'};                     # bit length of the data to be manipulated in integer
    my $value_hex                   = $write_input_href->{'value_hex'};                  # data value in hex
    my $mask_hex                    = $write_input_href->{'mask_hex'};                   # mask value in hex

    my $response_aref_hex = [];
    my $mode_flag         = 0;
    my $type_count        = 0;
    my ( $status, $mode_config );

    # error, if the spi manipulation module not in range
    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_write_config : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 .. 11(integer value) in function 'MANITOO_write_config'\n", 109 );
        return 0;
    }
    S_w2log( 5, "MANITOO_write_config : Calling function  'Validate_write_inputs' ..\n" );

    return 0 unless ( Validate_write_inputs($write_input_href) );

    my $control_1_data_href = {};
    my $control_2_data_href = {};

    if ( defined $data_control_1 and defined $data_control_2 ) {

        if ( $type_count == 0 ) {
            S_w2log( 5, "MANITOO_write_config : Calling function  'Write_dc_format' ..\n" );
            ( $control_1_data_href, $control_2_data_href, $mode_config ) = Write_dc_format( $data_control_1, $data_control_2, $time_us, $nbr_of_frames );

            # error conditions handled in Write_dc_format function
            $type_count = 1;
        }
        else { Type_error(); return 0; }    # error if more than one format configured
    }

    if ( defined $masked_value_bin ) {
        if ( $type_count == 0 ) {
            S_w2log( 5, "MANITOO_write_config : Calling function  'Write_mvb_format' ..\n" );
            ( $control_1_data_href, $control_2_data_href, $mode_config ) = Write_mvb_format( $masked_value_bin, $time_us, $nbr_of_frames );

            # error conditions handled in Write_mvb_format function
            $type_count = 1;
        }
        else { Type_error(); return 0; }    # error if more than one format configured
    }

    if ( defined $mask_hex and defined $value_hex ) {
        if ( $type_count == 0 ) {
            S_w2log( 5, "MANITOO_write_config : Calling function  'Write_mv_format' ..\n" );
            ( $control_1_data_href, $control_2_data_href, $mode_config ) = Write_mv_format( $mask_hex, $value_hex, $time_us, $nbr_of_frames );

            # error conditions handled in Write_mv_format function
            $type_count = 1;
        }
        else { Type_error(); return 0; }    # error if more than one format configured
    }

    if ( defined $bit_index and defined $bit_length and defined $value_hex ) {
        if ( $type_count == 0 ) {
            S_w2log( 5, "MANITOO_write_config : Calling function  'Write_plv_format' ..\n" );
            ( $control_1_data_href, $control_2_data_href, $mode_config ) = Write_plv_format( $bit_index, $bit_length, $value_hex, $time_us, $nbr_of_frames );

            # error conditions handled in Write_plv_format function
            $type_count = 1;
        }
        else { Type_error(); return 0; }    # error if more than one format configured
    }

    if ( $type_count == 0 ) {
        Type_error(1);
        return 0;                           # error if none of the format configured
    }

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return 0;
    }

    S_w2log( 5, "MANITOO_write_config : Calling function  'MANITOO_cmd_write_DataCtrl_ModeTime' ..\n" );

    ( $status, $response_aref_hex ) = MANITOO_cmd_write_DataCtrl_ModeTime( $spi_manipulation_module_int, $mode_config );
    unless ($status) {
        S_set_error( "MANITOO_write_config : Function call 'MANITOO_cmd_write_DataCtrl_ModeTime' not successful\n", 23 );
        return 0;
    }

    S_w2log( 5, "MANITOO_write_config : Calling function  'MANITOO_cmd_write_DataCtrl_1' ..\n" );

    ( $status, $response_aref_hex ) = MANITOO_cmd_write_DataCtrl_1( $spi_manipulation_module_int, $control_1_data_href );
    unless ($status) {
        S_set_error( "MANITOO_write_config : Function call 'MANITOO_cmd_write_DataCtrl_1' not successful\n", 23 );
        return 0;
    }

    S_w2log( 5, "MANITOO_write_config : Calling function  'MANITOO_cmd_write_DataCtrl_2' ..\n" );

    ( $status, $response_aref_hex ) = MANITOO_cmd_write_DataCtrl_2( $spi_manipulation_module_int, $control_2_data_href );
    unless ($status) {
        S_set_error( "MANITOO_write_config : Function call 'MANITOO_cmd_write_DataCtrl_2' not successful\n", 23 );
        return 0;
    }

    return 1;
}

=head1 MANITOO basic cmd functions

=head2 MANITOO_cmd_get_version

    Syntax : my ($status, $response_hex_aref , $version_string ) = MANITOO_cmd_get_version();

This function reads and returns the version number of ManiToo Firmware in decimal.

Returns the version number of ManiToo Firmware.
This includes the VHDL code as well as the C.
The version number has the following content:

mm:     Major release, e.g. interface change or complete new services.
nn:     Minor release, e.g. smaller changes or optimizations in existing services.
pp:    Patch release, bugfix release.

Manitoo Service Number : 0x10

Input arguments  : None

Return Values :

    Return value on success    : on success  - version number as a string of decimal numbers with following format
                                <Command number> <number of bytes sent> <major release> <minor release> <patch release>

    Return Offline\Error       : "0.0.0"

Example1(Success) :

    my ($status, $response_hex_aref , $version_string ) = MANITOO_cmd_get_version();

		$status : 1
		$response_hex_aref : [ '10' , '01' ,  '02' ,  '01' ,  '00' ]
			10 -> command number
				01 -> number of bytes sent
					02 -> major release
					01 -> minor release
					00 -> patch release

		$version_string : "2.1.0"

		
		
Example2 (Error) :

    my ($status, $response_hex_aref , $version_string ) = MANITOO_cmd_get_version();

		$status : 0
		$response_hex_aref : [ '??' , '??' ,  '??' .... ]
		$version_string : "0.0.0"


=cut

sub MANITOO_cmd_get_version {

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return ('0.0.0');
    }

    my $command_hex = "10";
    S_w2log( 4, " MANITOO_cmd_get_version : Calling Manitoo Service 0x10 Get Version\n" );

    return ( 1, [ "10", "01", "00", "00", "00" ], '0.0.0' ) if ($main::opt_offline);

    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_hex, { check_response => 1, nbr_bytes_exp => 5 } );

    return ( 0, $response_hex_aref, '0.0.0' ) unless ($status);    # error case

    my @response = @$response_hex_aref;
    shift(@response);                                              # remove command nbr
    shift(@response);                                              # remove nbr bytes of request command

    $global_Version_nbr_3byte_string = join( "", @response );

    my @manitoo_Firmware_Version_digits = ();
    foreach my $version_nbr_byte (@response) {
        push( @manitoo_Firmware_Version_digits, hex($version_nbr_byte) );
    }
    my $manitoo_Firmware_Version_string = join( ".", @manitoo_Firmware_Version_digits );    #join individual decimal number with '.' to become m.n.p

    S_w2rep(" MANITOO_cmd_get_version: Manitoo Version '$manitoo_Firmware_Version_string' is loaded \n");

    return ( 1, $response_hex_aref, $manitoo_Firmware_Version_string );
}

=head2 MANITOO_cmd_LOAD_FPGA

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_LOAD_FPGA ();

This function writes the configuration data into the FPGA registers.
The configuration data has to be set before by other services.
This service loads the configuration data from the ARM core into the PL.
This is necessary because the configuration is written by the PC user interface
(Lift or a terminal program) into the ARM core, that handles the communication,
and has to be loaded then into the PL where the manipulation is made.

Manitoo Service Number : 0x20

Input arguments        : None.

Return Values :

    Return in Success      : $status = 1, $response_hex_aref = [20 01]
                             20 -> Service number
                             01 -> number of bytes sent

    Return in error        : $status = 0, $response_hex_aref = []

    Return Offline         : 1, []

Example :

    ($status , $response_hex_aref ) = MANITOO_cmd_LOAD_FPGA();

    Input arguments        : None

    Return Values          : $status = 1;
                             $response_hex_aref = [20 01];

=cut

sub MANITOO_cmd_LOAD_FPGA {

    my $command_hex = "20";

    S_w2log( 4, " Load FPGA : Calling Manitoo Service 0x$command_hex LOAD FPGA\n" );
    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_Request_Response

    Syntax : ( $status , $response_bytes_aref ) = MANITOO_cmd_Request_Response( $request_command_string , $options_href );

Input arguments :

    $request_command_string : < string with bytes separated by spaces >   ( e.g."01 02 03 AA BB CC")

    $options_href (all optional) :
        - check_response => 0|1   0 -> dont check respose / 1 -> check_reponse according protocol spec [default:1]
        - nbr_bytes_exp => <nbr>  (optional / no default) -> throw error (-> INCONC) -> status 0
        - wait_time_ms => integer wait time in ms for reading response (optional; default is 50ms)
        - less_print_out => 0|1   1 -> reduce printouts in report [default:0]

Return Values :

    $status : 1 -> successful command handling accord to options
    $status : 0 -> not successful

    $response_bytes_aref : Array reference with all bytes as single strings ( e.g. '01' , '0A' )

Examples :

    ( $status , $response_bytes_aref ) = MANITOO_cmd_Request_Response( '10' , { check_response => 1 , nbr_bytes_exp => 5 , wait_time_ms => 500 } );

    $status : 1

    $response_bytes_aref : [ '10' , '01' , '01' , '02' , '00' ]

    This instruction summary describes the services implemented in the manipulation tool ManiToo.
        It is divided in sections correlated to the service number reagion. For each service you will find the following information:
    �    Service number and short name.
    �    Version when the service was introduced.
    �    �Direct� is mentioned when the service leads immediately to a reaction of the system.
            All other services will store some information in the ?Controller that has to be copied to the PL and
                will show effect not until the start instruction is sent.
    �    �Send� shows the code that has to be sent.
    �    �Receive� shows the answer of the system if it is not the default answer.
    �    Then comes a description of the function of the service.

    Each service leads to a default answer of the system:
    �    Repetition of the sent service number
    �    Number of bytes sent
    �    Eventually additional information, based on the service. In this case this is then mentioned under �Receive�
            in the service descriptions.
    �    If the service number is not recognized the fault message FF is sent back, followed by the wrong service number.

    The service numbers 0xF are reserved for developing features. Their behavior may differ from the one described in this document.

    original function send_command
    send command  cmd => '31 - 00 - 00 10 00 20' , read from mapping file
                            Manitoo_service_number Mani_level SPI_Number(2 bytes) CS (2 bytes)
    converted by  Convert_bytes_for_send()

=cut

sub MANITOO_cmd_Request_Response {
    my @args = @_;
    return 0 unless S_checkFunctionArguments( 'MANITOO_cmd_Request_Response( $request_command_string [ , $options_href ] )', @args );

    my $request_command_string = shift @args;

    my $options_href = shift @args;

    $options_href->{'check_response'} = 1  unless ( defined $options_href->{'check_response'} );
    $options_href->{'wait_time_ms'}   = 50 unless ( defined $options_href->{'wait_time_ms'} );
    $options_href->{'less_print_out'} = 0  unless ( defined $options_href->{'less_print_out'} );

    #IF Is defined arguments

    unless ( defined $request_command_string ) {

        #IF-NO-START
        #STEP Error missing parameter
        S_set_error( "Missing parameter send data", 110 );

        #STEP return 0, []
        #IF-NO-END
        return ( 0, [] );
    }

    #IF-YES-START
    #IF Is mode == offline
    #IF-YES-START
    #STEP return 1, []
    #IF-YES-END
    return ( 1, [] ) if ($main::opt_offline);

    #IF-NO-START
    #IF Is defined port object
    unless ( defined $PortObj ) {

        #IF-NO-START
        #STEP Error port object not defined
        S_set_error( "PortObj is not defined", 110 );

        #STEP return 0, []
        return ( 0, [] );

        #IF-NO-END
    }

    #IF-YES-START
    S_w2log( 4, " MANITOO_cmd_Request_Response: Sending '$request_command_string' (hex)\n", 'grey' )
      unless $options_href->{'less_print_out'};

    #IF Is manitoo not initialised
    unless ($mn2_initialised) {

        #IF-YES-START
        #STEP Error manitoo not initialised
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );

        #STEP return 0, []
        #IF-YES-END
        return ( 0, [] );
    }

    $request_command_string =~ s/ //g;    # remove white spaces
    $request_command_string =~ s/-//g;    # remove '-'

    my $manitoo_connection_type = S_get_contents_of_hash( [ 'Devices', 'Manitoo', 'Connection_Type' ], $LIFT_config::LIFT_Testbench );

    #IF-NO-START
    #IF is communication port is COM?
    #IF-YES-START
    #CALL Write_to_manitoo_using_COM_port

    my $receiveData_formatted;
    if ( $manitoo_connection_type =~ /^COM(\d+)/ ) {
        $receiveData_formatted = Write_to_manitoo_using_COM_port( $request_command_string, $options_href );
    }

    #IF-YES-END
    #IF-NO-START
    #CALL Write_to_manitoo_using_socket
    elsif ( $manitoo_connection_type =~ /^(USB|ETH)/ ) {
        $receiveData_formatted = Write_to_manitoo_using_socket( $request_command_string, $options_href );
    }

    #convert str to array ref
    my @receiveData_ary = split( /\s+/, $receiveData_formatted );

    #  all options handling here
    if ( $options_href->{'check_response'} ) {
        if ( $receiveData_ary[0] eq "FF" ) {
            S_w2log( 3, "MANITOO_cmd_Request_Response: Negative Response received : " . join( " ", @receiveData_ary ) . "\n", 'orange' );
            return ( 0, \@receiveData_ary );
        }

        if ( $options_href->{'nbr_bytes_exp'} ) {
            unless ( scalar(@receiveData_ary) == $options_href->{'nbr_bytes_exp'} ) {
                S_w2log( 3, "MANITOO_cmd_Request_Response: Number of bytes received ( " . scalar(@receiveData_ary) . " ) doesnot match the expected ( " . $options_href->{'nbr_bytes_exp'} . " )\n", 'orange' );
                return ( 0, \@receiveData_ary );
            }
        }
    }
    else {
        S_w2log( 4, "MANITOO_cmd_Request_Response: check of response was not desired\n" );
    }

    #STEP return 0, received_aref
    #IF-NO-END
    #IF-NO-END
    #IF-YES-END
    #IF-YES-END
    #IF-YES-END
    #STEP END

    # return with success and received data
    return ( 1, \@receiveData_ary );

}

sub Write_to_manitoo_using_COM_port {
    my $request_command_string = shift;
    my $options_href           = shift;
    my $success                = $PortObj->write( Convert_bytes_for_send($request_command_string) );
    unless ($success) {
        S_set_error("Could not write to serial port. Check connection.");
        return;
    }

    if ( length $request_command_string > 400 ) {

        # length of command is taken as buffer length( 400 )
        #  for the purpose of response time from ManiToo,
        #   if the length is large the response time increases.
        S_wait_ms_NOHTML( 150 + $options_href->{'wait_time_ms'} );
    }
    else {
        S_wait_ms_NOHTML( $options_href->{'wait_time_ms'} );
    }

    #STEP Read response value from serial port
    my ( $count, $receiveData_bytestring ) = $PortObj->read($SERIAL_PORT_MAX_READ_BYTES);
    S_w2log( 4, " MANITOO_cmd_Request_Response: Received bytes from Serial Port :  $count \n" )
      unless $options_href->{'less_print_out'};

    #IF Is negative response
    unless ($receiveData_bytestring) {

        #IF-YES-START
        #STEP Error negative response received
        #STEP SEND SERVICE 10 until response is received from manitoo
        S_set_error( "Could not receive response from MANITOO for command code '$request_command_string'", 110 );
        my $waitime_for_response = Send_read_firmware_service('COM');

        #call the service again to get the complete response string.
        $waitime_for_response = Send_read_firmware_service('COM',$waitime_for_response);

        #STEP return 0, []
        #IF-YES-END
        return ( 0, [] );
    }

    #IF-NO-START
    #CALL Convert_bytes_for_print
    #IF-NO-END
    my $receiveData_formatted = Convert_bytes_for_print($receiveData_bytestring);

    #
    # printout the response
    #
    my $nbr_bytes_of_max_printout = 50;
    if ( $count < $nbr_bytes_of_max_printout ) {

        # print all data when less than 100 bytes
        if ( $options_href->{'less_print_out'} ) {
            S_w2log( TEXT, " MANITOO_cmd_Request_Response: Receiving '$receiveData_formatted' (hex)\n", 'grey' );
        }
        else {
            S_w2log( 4, " MANITOO_cmd_Request_Response: Receiving '$receiveData_formatted' (hex)\n", 'grey' );
        }
    }
    else {

        # print less data to logs
        my $receiveData_formatted_reduced = substr( $receiveData_formatted, 0, $nbr_bytes_of_max_printout * 3 );    # 'XX ' -> 3 bytes incl space
        $receiveData_formatted_reduced .= " ... (just $nbr_bytes_of_max_printout from $count bytes)";
        if ( $options_href->{'less_print_out'} ) {
            S_w2log( TEXT, " MANITOO_cmd_Request_Response: Receiving '$receiveData_formatted_reduced' (hex)\n", 'grey' );
        }
        else {
            S_w2log( 4, " MANITOO_cmd_Request_Response: Receiving '$receiveData_formatted_reduced' (hex)\n", 'grey' );
        }
    }
    return $receiveData_formatted;

    #STEP END
}

sub Write_to_manitoo_using_socket {

    my $request_command_string = shift;
    my $options_href           = shift;

    my $receiveData;
    $PortObj->send( Convert_bytes_for_send($request_command_string) );    #instead of $PortObj -> write( convert_bytes_for_send($sendData) );

    # wait time required to load recorded SPI trace.
    S_wait_ms_NOHTML(50) if ( $request_command_string =~ /^(A3)/ );

    #STEP Read response value from serial port
    $PortObj->recv( $receiveData, $SERIAL_PORT_MAX_READ_BYTES );

    #IF Is negative response
    unless ($receiveData) {

        #IF-YES-START
        #STEP Error negative response received

        S_set_error("Could not receive response from MANITOO for command code '$request_command_string'");

        #STEP SEND SERVICE 10 until response is received from manitoo
        my $waitime_for_response = Send_read_firmware_service('USB');

        #call the service again to get the complete response string.
        $waitime_for_response = Send_read_firmware_service('USB', $waitime_for_response);

        #STEP return 0, []
        #IF-YES-END
        return ( 0, [] );
    }

    #IF-NO-START
    #CALL Convert_bytes_for_print
    my $receiveData_formatted = Convert_bytes_for_print($receiveData);

    #IF-NO-END
    S_w2log( 4, "MANITOO_cmd_Request_Response: Receiving $receiveData_formatted" );
    return $receiveData_formatted;

    #STEP END
}

=head2 MANITOO_cmd_START_or_STOP

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_START_or_STOP ( $start_or_stop_str );

This function Starts manipulation inside FPGA.
0 --> Stop terminates all manipulation, all internal counters and intermediate registers are reset.
1 --> A following Start starts the manipulation from the beginning. It does not reset the configuration register,
        i.e. the same test case is performed as before.

Manitoo Service Number :: 0x21

Input arguments :
    $start_or_stop_str = String , ('START', 'STOP').

Return Values :

    Return in Success  : $status = 1,
                         $response_hex_aref = ['21' , '05']

    Return in Error    : $status = 0,
                         $response_hex_aref = []

    Return Offline     : 1, []

Example1(Success)  :

    ($result, $response_hex_aref) = MANITOO_cmd_START_or_STOP ('START');

    Returns values : $status = 1;
                     $response_hex_aref = ['21' , '05'];

Example2(Error)    :

    ($result, $response_hex_aref) = MANITOO_cmd_START_or_STOP ('2');  # wrong Start/Stop value given

    Error          : MANITOO_cmd_START_or_STOP : The START/STOP value '2' is wrong, should be either 'START' or
                        'STOP'(string value)

    Returns values : $status = 0;
                     $response_hex_aref = [];

=cut

sub MANITOO_cmd_START_or_STOP {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_START_or_STOP ( $start_or_stop_str)', @args );

    my $service_number = "21";

    my $donot_care_bit_21 = 0;

    my $start_or_stop_str = shift;

    unless ( $start_or_stop_str eq 'START' or $start_or_stop_str eq 'STOP' ) {
        S_set_error( "MANITOO_cmd_START_or_STOP : The START/STOP value '$start_or_stop_str' is wrong, should be either 'START' or 'STOP'(string value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_START_or_STOP : Processing command $service_number .. \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_START_or_STOP : (arg1) The START/STOP value selected = $start_or_stop_str \n", "grey" );

    $donot_care_bit_21 = $donot_care_bit_21 x 7;    # 7 don't care bits ---> 0000000

    my $start_or_stop_bits_int = 0;                 #default value 0 (STOP)

    $start_or_stop_bits_int = 1 if ( $start_or_stop_str eq 'START' );

    my $command_hex = $service_number . $donot_care_bit_21 . $start_or_stop_bits_int;

    S_w2log( 4, " MANITOO_cmd_START_or_STOP : Calling Manitoo Service 0x$service_number  ($start_or_stop_str) \n" );

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_Reset

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_Reset();

This function resets all internal registers.

Manitoo Service Number :: 0x22

Input arguments   : None

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = ['22' , '01']
                        22 -> Service number
                        01 -> number of bytes sent

    Return in Error   : $status = 0
                        $response_hex_aref = []

    Return Offline    : 1, []


Example :

    ($status,$response_hex_aref) = MANITOO_cmd_Reset();

    Return values : $status = 1;
                    $response_hex_aref = ['22' , '01'];

=cut

sub MANITOO_cmd_Reset {
    my $command_hex = "22";

    S_w2log( 4, "MANITOO_cmd_Reset : Processing command 22 .. \n", "grey" );

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_PartialReset

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PartialReset();

This function resets all internal registers except the WatchDog (WD) configuration (WD CS MASK, WD Frame Mask WD Frame Pattern)
    and SMI7 SPI Mask and SMI7 CS Mask Register.

Manitoo Service Number : 0x23

Input arguments   : None

Return Values :

    Return in Success : $status = 1;
                        $response_hex_aref = ['23' , '01'];
                        23 -> Service number
                        01 -> number of bytes sent

    Return in Error   : $status = 0
                        $response_hex_aref = []

    Return Offline    : 1, []

Example :

    ($status, $response_hex_aref) = MANITOO_cmd_PartialReset();

    Return values : $status = 1;
                    $response_hex_aref = ['23' , '01'];

=cut

sub MANITOO_cmd_PartialReset {
    my $command_hex = "23";    #service number

    S_w2log( 4, " MANITOO_cmd_PartialReset: Starting partial reset\n", "grey" );
    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_trigger_SPI_CS

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_trigger_SPI_CS (
                                                                            $spi_manipulation_module_int,
                                                                            $spi_selection_int,
                                                                            $cs_selection_int
                                                                         );

This function selects the SPI manipulation module, SPI bus number and Chip Select for the target sensor under test.

Manitoo Service Number    : 0x31

Input arguments           :

    $spi_manipulation_module_int = integer (0 - 11) SPI manipulation module selection.
                                    0 - SPI manipulation module 00
                                    1 - SPI manipulation module 01
                                    2 - SPI manipulation module 02
                                      '
                                      '
                                    11 - SPI manipulation module 11


    $spi_selection_int           = SPI bus number(integer).
                                    1 - SPI 1
                                    2 - SPI 2
                                    3 - SPI 3
                                    4 - SPI 4

    $cs_selection_int            = Chip select selection(integer).
                                    0  - CS 0
                                    1  - CS 1
                                    2  - CS 2
                                      '
                                      '
                                    19 - CS19

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['31' , '06'];
                                31 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []


Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_SPI_CS(0, 2, 18);

    Input arguments       : $spi_manipulation_module_int  : 0
                            $spi_selection_int            : 2
                            $cs_selection_int             : 18

    Return Values         : $status = 1;
                            $response_hex_aref = ['31' , '06'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_SPI_CS(0, 6, 18); #wrong SPI selection given

    Input arguments       : $spi_manipulation_module_int  : 0
                            $spi_selection_int            : 6
                            $cs_selection_int             : 18

    Error                 : MANITOO_cmd_trigger_SPI_CS : SPI bus number value '6' is out of range,
                                should be in the range 1 .. 4(integer value)

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_trigger_SPI_CS {
    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_trigger_SPI_CS ( $spi_manipulation_module_int, $spi_selection_int, $cs_selection_int )', @args );
    my $spi_manipulation_module_int = shift;    #value of spi_manipulation_module in integer
    my $spi_selection_int           = shift;    #value of SPI bus number in integer
    my $cs_selection_int            = shift;    #value of Chip select in integer

    my $command_string_hex = undef;

    my $service_number = "31";

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_trigger_SPI_CS : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 .. 11(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $spi_selection_int < 1 or $spi_selection_int > 4 ) {
        S_set_error( "MANITOO_cmd_trigger_SPI_CS : SPI bus number value '$spi_selection_int' is out of range, should be in the range 1 .. 4(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $cs_selection_int < 0 or $cs_selection_int > 19 ) {
        S_set_error( "MANITOO_cmd_trigger_SPI_CS : Chip Select value '$cs_selection_int' is out of range, should be in the range 0 .. 19(integer value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, " MANITOO_cmd_trigger_SPI_CS: Processing command $service_number .. \n",                        "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_SPI_CS: (arg1) SPI manipulation module = $spi_manipulation_module_int\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_SPI_CS: (arg2) SPI bus number selected = $spi_selection_int \n",          "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_SPI_CS: (arg3) CS selected : $cs_selection_int \n",                       "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    #converting the value of  SPI selection to hexadecimal value
    my $spi_selection_hex = sprintf( "%x", $spi_selection_int );

    #converting the value of cs_selection_int to twenty bits hexadecimal value
    my $cs_selection_bin = 0 x ( 19 - $cs_selection_int );    # $cs_selection_bin = 5 : 0 x (19 - 5) = 00000000000000 (14 zeros).
    my $cs_bit_buffer    = 0 x ($cs_selection_int);           # $cs_bit_buffer = 5 : 0 x (5)    = 00000 (5 zeros).
    $cs_selection_bin = $cs_selection_bin . '1' . $cs_bit_buffer;    # $cs_selection_bin = 00000000000000010000  the bit position of '1'
                                                                     # indicates CS.

    S_w2log( 3, " MANITOO_cmd_trigger_SPI_CS: Chip Select Binary : $cs_selection_bin \n" );

    #converting the value of  CS to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Bit string
    #
    my $cs_selection_hex = unpack(
        'H5',    # 5 nibbles in hex
        pack(
            'B20',    # twenty bit binary string
            $cs_selection_bin
        )
    );

    $command_string_hex = $service_number . $spi_manipulation_module_hex . '00' . $spi_selection_hex . $cs_selection_hex;

    return ( 1, [] ) if ($main::opt_offline);
    return ( 0, [] ) unless Version_Check_SPI_manipul();
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_trigger_FrameMask

    Syntax : ($result, $response_hex_aref) = MANITOO_cmd_trigger_FrameMask($spi_manipulation_module_int, $frame_mask_hex_str);

This function selects the Frame Mask required to detect the manipulation frame on MOSI for a specific
    SPI manipulation module.

Manitoo Service Number :: 0x32

Input arguments           :

    $spi_manipulation_module_int = integer (0 - 11) SPI manipulation module.
                                   0 - SPI manipulation module 00
                                   1 - SPI manipulation module 01
                                   2 - SPI manipulation module 02
                                     '
                                     '
                                   11 - SPI manipulation module 11

    $frame_mask_hex_str              = String ('dddddddd'), frame mask in 4 hex bytes string
                                                                     (8 character: [0-9A-F])

    Allowed hex string formats:
        a) 'dddddddd' -> 'F8000000'
        b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
        c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
        d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['32' , '06'];
                                32 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_FrameMask(0, 'F8000000');

    Input arguments       : $spi_manipulation_module_int  : 0
                            $frame_mask_hex_str               : 'F8000000'

    Return Values         : $status = 1;
                            $response_hex_aref = ['32' , '06'];

Example2(Error) :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_FrameMask(0, 'F800000002');

    Input arguments       : $spi_manipulation_module_int  : 0
                            $frame_mask_hex_str               : 'F800000002'

    Error                 : MANITOO_cmd_trigger_FrameMask : The length of frame mask 'F800000002' should be of 4 hex byte string.

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_trigger_FrameMask {
    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_trigger_FrameMask ( $spi_manipulation_module_int, $frame_mask_hex_str )', @args );

    my $spi_manipulation_module_int = shift;    #spi manipulation module
    my $frame_mask_hex_str          = shift;    #value of frame mask in 4 hex bytes

    my $service_number = "32";

    my $command_string_hex = undef;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_trigger_FrameMask : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 .. 11(integer value)\n", 109 );
        return ( 0, [] );
    }

    $frame_mask_hex_str =~ s/[-\s*]//g;
    $frame_mask_hex_str =~ s/^0x//g;

    unless ( $frame_mask_hex_str =~ /^[0-9A-F]{8}$/i ) {    #check for 4 bytes of hexadecimal value
        S_set_error( "MANITOO_cmd_trigger_FrameMask : The length of frame mask '$frame_mask_hex_str' should be of 4 byte hexadecimal value\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_trigger_FrameMask : Processing command $service_number .. \n",                                   "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_FrameMask : (arg1) SPI manipulation module selected = $spi_manipulation_module_int \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_FrameMask : (arg2) Frame mask selected = $frame_mask_hex_str \n",                       "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    $command_string_hex = $service_number . $spi_manipulation_module_hex . $frame_mask_hex_str;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_trigger_FramePattern

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_trigger_FramePattern( $spi_manipulation_module_int, $frame_pattern_hex_str);

This function selects the Frame pattern required to detect the manipulation frame on MOSI for a
    specific SPI manipulation module.

Manitoo Service Number    : 0x33

Input arguments           :

    $spi_manipulation_module_int = integer (0 - 11) , SPI manipulation module.
                                   0 - SPI manipulation module 00
                                   1 - SPI manipulation module 01
                                   2 - SPI manipulation module 02
                                     '
                                     '
                                   11 - SPI manipulation module 11

    $frame_pattern_hex_str       = String ('dddddddd') , frame pattern in 4 hex byte string
                                                                       (8 character: 0-9A-F).
    Allowed hex string formats:
        a) 'dddddddd' -> 'F8000000'
        b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
        c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
        d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['33' , '06'];
                                33 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_FramePattern(0, 'F0000000');

    Input arguments       : $spi_manipulation_module_int  : 0
                            $frame_pattern_hex_str            : 'F0000000'

    Return Values         : $status = 1;
                            $response_hex_aref = ['33' , '06'];

Example2(error) :

    ($status , $response_hex_aref ) = MANITOO_cmd_trigger_FramePattern(0, 'F00000');
                                                                    #wrong frame pattern selected

    Input arguments       : $spi_manipulation_module_int  : 0
                            $frame_pattern_hex_str            : 'F00000'

    Error                 : MANITOO_cmd_trigger_FramePattern : The length of frame mask 'F00000' should be of 4 hex byte string.

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_trigger_FramePattern {
    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_trigger_FramePattern ( $spi_manipulation_module_int, $frame_pattern_hex_str )', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module value in integer

    my $frame_pattern_hex_str = shift;          #value of frame pattern in 4 hex bytes

    my $service_number = "33";                  #service number

    my $command_string_hex = undef;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {

        S_set_error( "MANITOO_cmd_trigger_FramePattern : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 .. 11(integer value)\n", 109 );
        return ( 0, [] );
    }

    $frame_pattern_hex_str =~ s/[-\s*]//g;
    $frame_pattern_hex_str =~ s/^0x//g;

    unless ( $frame_pattern_hex_str =~ /^[0-9A-F]{8}$/i ) {

        S_set_error( "MANITOO_cmd_trigger_FramePattern : The length of frame mask '$frame_pattern_hex_str' should be of 4 hex byte string\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_trigger_FramePattern : Processing command $service_number .. \n",                                   "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_FramePattern : (arg1) SPI manipulation module selected = $spi_manipulation_module_int \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_trigger_FramePattern : (arg2) Frame pattern selected = $frame_pattern_hex_str \n",                 "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    $command_string_hex = $service_number . $spi_manipulation_module_hex . $frame_pattern_hex_str;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_write_DataCtrl_ModeTime

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_write_DataCtrl_ModeTime(
                                                                            $spi_manipulation_module_int ,
                                                                            $manipu_mode_settings_href ,
                                                                        );

This function defines for all SPI manipulations the

- the mode ( SPI frame- , Timer- , RealTime - Mode)

- the number of manipulated SPI frames ( SPI - mode ) OR

- the duration ( Timer-Mode ) OR

- the dependency from WD (watch-dog) functionality which selects the next value from FIFO queue

This will be defined for seperate Manipulation Modules ( 0.. 3 ) and
    specifically for each Data Set of FIFO queue to be executed ( 1 .. 15 )

ALL 3 write functions have a direct dependency and

ALL of them must be called in order to fill registers correctly

    1. MANITOO_cmd_write_DataCtrl_ModeTime

    2. MANITOO_cmd_write_DataCtrl_1

    3. MANITOO_cmd_write_DataCtrl_2

The results are pre-defined registers which lead combined to the desired functionality.

Manitoo Service Number :: 0x41

Input arguments :

    $spi_manipulation_module_int    = integer (0 - 11) , SPI manipulation module.
                                      0 - SPI manipulation module 00
                                      1 - SPI manipulation module 01
                                      2 - SPI manipulation module 02
                                        '
                                        '
                                      11 - SPI manipulation module 11

    $manipu_mode_settings_href      = hash reference, containing dataset numbers
                                      with assignment of mode and
                                      with assignment of attributes according to mode

    $manipu_mode_settings_href =
        {
            # KEY is
            # ID of dataset , integer from 1 ... 15
            #     must be increased by 1  ( e.g.  1 2 3 4 )
            #      no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )
            '1' => {
                        'MODE'      => 'SPI|TIM|RTI'  ,
                        'FRAMES'    => <int__nbr_of_frames> ,   # when MODE = SPI  / infinite when 0
                        'TIME_US'   => <int__time_us> ,         # when MODE = TIM  / infinite when 0
                      },
            ...
            ...
            '15' => {
                        'MODE'      => 'SPI|TIM|RTI'  ,
                        'FRAMES'    => <int__nbr_of_frames> ,   # when MODE = SPI  / infinite when 0
                        'TIME_US'   => <int__time_us> ,         # when MODE = TIM  / infinite when 0
                      },
         }

NOTES :

    'ID of dataset' used in $manipu_mode_settings_href
    integer (1 - 15) , identification number of manipulation data sets, which will be used in sequence
          must be increased by 1  ( e.g.  1 2 3 4 )
          no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )

          1 - mode for 1st manipulation data set
          2 - mode for 2nd manipulation data set
          ....
          ....
          15 - mode for 15th manipulation data set


    'MODE' used in $manipu_mode_settings_href
    'SPI' => Manipulation is executed for a defined number of SPI frames
    'SCM' => Same as SPI ( renamed in Manitoo Manual )
    'TIM' => Manipulation is executed for a defined time duration in micro-seconds

    (not implemented yet)
    'RTI' => Manipulation is executed with an enduring sequence of taking data from a
                FIFO queue controlled via a WD (watchdog timer)

    'FRAMES' used in $manipu_mode_settings_href
    integer , number of frames for execution of manipulation for specific dataset ID
    when 'FRAMES' attribute is missing -> infinite manipulation ( with only 1 Dataset possible !!!)

    'TIME_US' used in $manipu_mode_settings_href
    integer , time duration of execution of manipulation for specific dataset ID
    when 'TIME_US' attribute is missing -> infinite manipulation ( with only 1 Dataset possible !!!)

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['41' , '0B'];
                                41-> Service number
                                0B -> number of bytes sent( depends on the number of manipulation datasets sent).
                                    (for two datasets -> 0B)

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_write_DataCtrl_ModeTime( 0 ,
                                                                              {
                                                                                '1' => { 'MODE' => 'SPI' },   # or MODE = SCM
                                                                              }
                                                                          );



                                SPI Manipulation MOdule '00' selected
                                INFINITE Manipulation of 1 Dataset ; no more possible
                                MANITOO_cmd_write_DataCtrl_ModeTime = ( 0 , '1' => { 'MODE' => 'SPI' , 'FRAMES' => 0 } ); # has same effect

Example2(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_write_DataCtrl_ModeTime( 1 ,
                                                                              {
                                                                                '1' => { 'MODE' => 'TIM' },
                                                                              }
                                                                          );

                                SPI Manipulation Module '00' selected
                                INFINITE Manipulation of 1 Dataset ; no more possible
                                MANITOO_cmd_write_DataCtrl_ModeTime =
                                    ( 0 , '1' => { 'MODE' => 'TIM' , 'TIME_US' => 0 } ); # has same effect




Example3(Success) :

    ($status , $response_hex_aref ) =
        MANITOO_cmd_write_DataCtrl_ModeTime( 2,
            {
                '1' => { 'MODE' => 'SPI' , 'FRAMES' => 10 },
                '2' => { 'MODE' => 'SPI' , 'FRAMES' => 50 },
                '3' => { 'MODE' => 'SPI' , 'FRAMES' => 10 },
                '4' => { 'MODE' => 'SPI' , 'FRAMES' => 50 },
             },
        );

    Return Values         : $status = 1;
                            $response_hex_aref = ['41' ,  '13' ];
                            41 --> service number
                            13 --> number bytes sent (4 data sets)


Example4(Success) :

        ($status , $response_hex_aref ) =

            MANITOO_cmd_write_DataCtrl_ModeTime( 2,
                                                    {
                                                        '1' => { 'MODE' => 'TIM' , 'TIME_US' => 100 },
                                                        '2' => { 'MODE' => 'TIM' , 'TIME_US' => 200 },
                                                     },
                                                  );


        Return Values         : $status = 1;
                                $response_hex_aref = ['41' ,  <.....to be counted...>   ];


Example5(error) :

        ($status , $response_hex_aref ) =

            MANITOO_cmd_write_DataCtrl_ModeTime( 3,
                                                    {
                                                        '1' => { 'MODE' => 'SPI' , 'FRAMES' => 10 },
                                                        '2' => { 'MODE' => 'SPI' , 'FRAMES' => 50 },
                                                        # wrong counting of data set IDs
                                                        '6' => { 'MODE' => 'TIM' , 'TIME_US' => 100 },
                                                        '7' => { 'MODE' => 'TIM' , 'TIME_US' => 200 },
                                                     },
                                                  );

        Input arguments       : $spi_manipulation_module_int    : 3

        Error                 : MANITOO_cmd_write_DataCtrl_ModeTime : Wrong counting of IDs of used datasets

        Return Values         : $status = 0;
                                $response_hex_aref = [];


=cut

sub MANITOO_cmd_write_DataCtrl_ModeTime {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_write_DataCtrl_ModeTime ( $spi_manipulation_module_int , $manipu_mode_settings_href)', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module in integer

    my $manipu_mode_settings_href = shift;      #value of number of manipulation datasets in integer

    my $service_number = "41";

    my $command_string_hex = undef;

    my $dont_care = 0;
    $dont_care = 0 x 7;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_ModeTime : SPI manipulation module configured '$spi_manipulation_module_int' is out of range, valid range 0 .. 11 (integer)\n", 109 );
        return ( 0, [] );
    }

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    if ( keys %{$manipu_mode_settings_href} < 1 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_ModeTime : Atleast one manipulation mode setting should be configured.\n", 109 );
        return ( 0, [] );
    }

    #collect the number of manipulation data sets configured in hex
    my $num_of_manipu_datasets_hex = unpack( 'H2', pack( 'i*', scalar keys %{$manipu_mode_settings_href} ) );

    #hash reference for the mode and the respective command code
    my $manipu_mode = {
        'SPI' => 1,
        'SCM' => 1,
        'RTI' => 2,
        'TIM' => 4
    };

    my $count_modes = 1;
    my ( $mode_time_or_frame_str, $manipu );

    S_w2log( 4, "MANITOO_cmd_write_DataCtrl_ModeTime : Processing command 41 ... \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_write_DataCtrl_ModeTime : (arg1) SPI manipulation module selected = $spi_manipulation_module_int \n", "grey" );
    foreach my $manipu ( sort { $a <=> $b } keys %{$manipu_mode_settings_href} ) {

        unless ( $count_modes == $manipu ) {
            S_set_error( "MANITOO_cmd_write_DataCtrl_ModeTime : Wrong counting of IDs of used datasets, should start with 1 and should be in range 1 .. 15\n", 109 );
            return ( 0, [] );
        }
        if (   $manipu_mode_settings_href->{$manipu}{'MODE'} =~ /^SPI$/i
            or $manipu_mode_settings_href->{$manipu}{'MODE'} =~ /^SCM$/i )
        {    #check mode for SPI/SCM

            S_w2log( 4, " MANITOO_cmd_write_DataCtrl_ModeTime : (arg2) Manipulation mode selected = $manipu_mode_settings_href->{$manipu}{'MODE'} \n", "grey" );
            if ( defined $$manipu_mode_settings_href{$manipu}{'TIME_US'} ) {    #error if other than FRAMES is configured
                S_set_error( "MANITOO_cmd_write_DataCtrl_ModeTime : The Key 'FRAMES' should be configured for manipulation data set with sequence ID '$manipu' since the mode is '$manipu_mode_settings_href->{$manipu}{'MODE'}'\n", 109 );
                return ( 0, [] );
            }

            #if FRAMES is not configured or configured with value 0, then append seven 0's which is infinite manipulation
            if ( !exists( $$manipu_mode_settings_href{$manipu}{'FRAMES'} ) ) {
                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $dont_care;
            }
            elsif ( $$manipu_mode_settings_href{$manipu}{'FRAMES'} == 0 ) {
                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $dont_care;
            }

            #FRAMES value other than 0, convert the value to hexadecimal
            else {
                S_w2log( 4, " MANITOO_cmd_write_DataCtrl_ModeTime : (arg2) number of frames selected = $$manipu_mode_settings_href{$manipu}{'FRAMES'} \n", "grey" );

                my $num_of_frames = sprintf( "%7x", $$manipu_mode_settings_href{$manipu}{'FRAMES'} );
                $num_of_frames =~ s/\s/0/g;
                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $num_of_frames;
            }
        }

        if ( $manipu_mode_settings_href->{$manipu}{'MODE'} =~ /^TIM$/i ) {    #check mode for TIM

            S_w2log( 4, " MANITOO_cmd_write_DataCtrl_ModeTime : (arg2) Manipulation mode selected = $manipu_mode_settings_href->{$manipu}{'MODE'} \n", "grey" );

            if ( defined $$manipu_mode_settings_href{$manipu}{'FRAMES'} ) {    #error if other than TIME_US is configured
                S_set_error( "MANITOO_cmd_write_DataCtrl_ModeTime : The Key TIME_US should be configured for manipulation data set with sequence ID '$manipu', since the mode is $manipu_mode_settings_href->{$manipu}{'MODE'}\n", 109 );
                return ( 0, [] );
            }

            #if TIME_US is not configured or configured with value 0, then append seven 0's which is infinite manipulation
            if ( !exists( $$manipu_mode_settings_href{$manipu}{'TIME_US'} ) ) {

                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $dont_care;
            }
            elsif ( $$manipu_mode_settings_href{$manipu}{'TIME_US'} == 0 ) {
                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $dont_care;
            }

            #TIME_US value other than 0, convert the value to hexadecimal
            else {
                S_w2log( 4, " MANITOO_cmd_write_DataCtrl_ModeTime : (arg2) Waiting time selected = $$manipu_mode_settings_href{$manipu}{'TIME_US'} \n", "grey" );

                my $wait_time = sprintf( "%7x", $$manipu_mode_settings_href{$manipu}{'TIME_US'} );
                $wait_time =~ s/\s/0/g;
                $mode_time_or_frame_str .= $manipu_mode->{ $manipu_mode_settings_href->{$manipu}{'MODE'} } . $wait_time;
            }
        }
        $count_modes++;
    }

    $command_string_hex = $service_number . $spi_manipulation_module_hex . $num_of_manipu_datasets_hex . $mode_time_or_frame_str;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_write_DataCtrl_1

    Syntax : ($result, $response_hex_aref) = MANITOO_cmd_write_DataCtrl_1(
                                                                            $spi_manipulation_module_int ,
                                                                            $manipu_bit_masks_href ,
                                                                        );

This function MANITOO_cmd_write_DataCtrl_1 defines
together with MANITOO_cmd_write_DataCtrl_2 for all SPI manipulations the
RESULTING SPI bit values to be (over)written in the SPI frames.

MANITOO_cmd_write_DataCtrl_1 and
MANITOO_cmd_write_DataCtrl_2 are containing a 32-bit-masks
which are leading for each specific resulting bit as follows :

    MANITOO_cmd_write_DataCtrl_1 : 0
    MANITOO_cmd_write_DataCtrl_2 : 0
                         RESULT  : x  -> unchanged bit of original frame

    MANITOO_cmd_write_DataCtrl_1 : 0
    MANITOO_cmd_write_DataCtrl_2 : 1
                          RESULT : i  -> inverted bit of original frame

    MANITOO_cmd_write_DataCtrl_1 : 1
    MANITOO_cmd_write_DataCtrl_2 : 0
                          RESULT : 0  -> overwritten bit value 0

    MANITOO_cmd_write_DataCtrl_1 : 1
    MANITOO_cmd_write_DataCtrl_2 : 1
                          RESULT : 1  -> overwritten bit value 1

    EXAMPLE FOR 1 DataSet :

    Masks of DataSets for MANIPULATION
    00000000000011110011111111110000    Mask given in MANITOO_cmd_write_DataCtrl_1  ( 0x000F3FF0 )
    00000000000001001101000000110000    Mask given in MANITOO_cmd_write_DataCtrl_2  ( 0x0004D030 )
    --------------------------------
    xxxxxxxxxxxx0100ii0100000011xxxx    MANIPULATION OPERATION

    In Reality on the SPI Bus

    10101010101001111101010100100000    MISO ORIGINAL ( 0xAAA7D520 )
    vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

    xxxxxxxxxxxx0100ii0100000011xxxx    MANIPULATION OPERATION
    vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

    10101010101001000001000100110000    MISO MANIPULATED ( 0xAAA41130 )

This will be defined for seperate Manipulation Modules ( 0.. 3 ) and
specifically for each Data Set of FIFO queue to be executed ( 1 .. 15 ) and
specifically for each of Bit of 32-bit-frame

ALL 3 write functions have a direct dependency and
ALL of them must be called in order to fill registers correctly

    1. MANITOO_cmd_write_DataCtrl_ModeTime

    2. MANITOO_cmd_write_DataCtrl_1

    3. MANITOO_cmd_write_DataCtrl_2

The results are pre-defined registers which lead combined to the desired functionality.

Manitoo Service Number :: 0x42

Input arguments :

    $spi_manipulation_module_int    = integer (0 - 11) , SPI manipulation module.
                                      0 - SPI manipulation module 00
                                      1 - SPI manipulation module 01
                                      2 - SPI manipulation module 02
                                        '
                                        '
                                      11 - SPI manipulation module 11

    $manipu_bit_masks_href      = hash reference, containing
                                            dataset numbers (integer 1..15)
                                                with 32-bit-mask part 1 ( strings, 32-bit hex value )

                                $manipu_bit_masks_href =
                                {
                                    # KEY is
                                    # ID of dataset , integer from 1 ... 15
                                    #     must be increased by 1  ( e.g.  1 2 3 4 )
                                    #      no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )
                                    '1' => <dataset_1_manipul_mask_part_1> ,
                                    ...
                                    ...
                                    'm' => <dataset_m_manipul_mask_part_1>
                                }

NOTES :

    'ID of dataset' used in $manipu_bit_masks_href
    integer (1 - 15) , identification number of manipulation data sets, which will be used in sequence
              must be increased by 1  ( e.g.  1 2 3 4 )
              no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )

              1 - mode for 1st manipulation data set
              2 - mode for 2nd manipulation data set
              ....
              ....
              15 - mode for 15th manipulation data set


    <dataset_1_manipul_mask_part_m> used in $manipu_bit_masks_href
        string , hex-value of 32-bit-Mask given as described in manipulation above
        ( part 1 of MANITOO_cmd_write_DataCtrl_1, e.g. '000F3FF0' or '00 0F 3F F0')

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['42' , '0B'];
                                42-> Service number
                                0B -> number of bytes sent( depends on the number of manipulation datasets sent).
                                    (for two datasets -> 0B)

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_1( 0 ,
                                                                      {
                                                                        '1' => '0x000F3FF0' ,
                                                                      }
                                                                  );

    SPI Manipulation MOdule '0' selected

Example2(Success) :

    ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_1( 2,
                                                                    {
                                                                        '1' => '0x000F3FF0',
                                                                        '2' => '000E4FF0',
                                                                        '3' => '00 0A 5F F0',
                                                                        '4' => '00 0B 6F F0',
                                                                     },
                                                                  );


    Return Values : $status = 1;
                    $response_hex_aref = ['42' ,  '13'];
                    42 --> command number.
                    13 --> number of bytes sent in hex(4 data sets).


Example3(error) :

        ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_1( 3,
                                                                    {
                                                                        '1' => '0x000F3FF0',
                                                                        '2' => '0x000E4FF0',
                                                                        # wrong counting of data set IDs
                                                                        '6' => '0x000A5FF0',
                                                                        '7' => '0x000B6FF0',
                                                                     },
                                                                  );

        Input arguments       : $spi_manipulation_module_int    : 3

        Error                 : MANITOO_cmd_write_DataCtrl_1 : Wrong counting of IDs of used datasets,
                                    should start with 1 and should be in range 1 .. 15

        Return Values         : $status = 0;
                                $response_hex_aref = [];

=cut

sub MANITOO_cmd_write_DataCtrl_1 {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_write_DataCtrl_1 ( $spi_manipulation_module_int, $manipu_bit_masks_href, )', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module in integer

    my $manipu_bit_masks_href = shift;          #value of control bits in 4 byte hex string

    my $service_number = '42';

    my $command_string_hex = undef;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_1 : SPI manipulation module configured '$spi_manipulation_module_int' is out of range, valid range 0 .. 11 (integer)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, " MANITOO_cmd_write_DataCtrl_1 : Processing command 42 ... \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_write_DataCtrl_1 : (arg1) SPI manipulation module selected = $spi_manipulation_module_int \n", "grey" );

    # S_w2log( 4 ," MANITOO_cmd_write_DataCtrl_1 : (arg2) number of manipulation datasets = $number_of_manipu_datasets_int \n", "grey");

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    #collect the number of manipulation data sets configured in hex
    my $num_of_manipu_datasets_hex = unpack( 'H2', pack( 'i*', scalar keys %{$manipu_bit_masks_href} ) );

    if ( keys %{$manipu_bit_masks_href} < 1 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_1 : Atleast one manipulation mode setting should be configured.\n", 109 );
        return ( 0, [] );
    }

    my $bit_mask_count = 1;
    my $bitmask_string = '';
    foreach my $manipu_bit_mask ( sort { $a <=> $b } keys %{$manipu_bit_masks_href} ) {

        unless ( $bit_mask_count == $manipu_bit_mask ) {
            S_set_error( "MANITOO_cmd_write_DataCtrl_1 : Wrong counting of IDs of used datasets, should start with 1 and should be in range 1 .. 15\n", 109 );
            return ( 0, [] );
        }
        $bitmask_string .= $$manipu_bit_masks_href{$manipu_bit_mask};    #append all the DataCtrl 1 mask values
        $bitmask_string =~ s/0x//g;
        $bitmask_string =~ s/[-\s*]//g;
        $bit_mask_count++;
    }

    #command string for service 42
    $command_string_hex = $service_number . $spi_manipulation_module_hex . $num_of_manipu_datasets_hex . $bitmask_string;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_write_DataCtrl_2

    Syntax :: ($result, $response_hex_aref) = MANITOO_cmd_write_DataCtrl_2(
                                                                            $spi_manipulation_module_int ,
                                                                            $manipu_bit_masks_href ,
                                                                        );

ALL 3 write functions have a direct dependency and
ALL of them must be called in order to fill registers correctly

1. MANITOO_cmd_write_DataCtrl_ModeTime
2. MANITOO_cmd_write_DataCtrl_1
3. MANITOO_cmd_write_DataCtrl_2

The results are pre-defined registers which lead combined to the desired functionality.

This function MANITOO_cmd_write_DataCtrl_2 defines
together with MANITOO_cmd_write_DataCtrl_1 for all SPI manipulations the
RESULTING SPI bit values to be (over)written in the SPI frames.

MANITOO_cmd_write_DataCtrl_1 and
MANITOO_cmd_write_DataCtrl_2 are containing a 32-bit-masks
which are leading for each specific resulting bit as follows :

    MANITOO_cmd_write_DataCtrl_1 : 0
    MANITOO_cmd_write_DataCtrl_2 : 0
                         RESULT  : x  -> unchanged bit of original frame

    MANITOO_cmd_write_DataCtrl_1 : 0
    MANITOO_cmd_write_DataCtrl_2 : 1
                          RESULT : i  -> inverted bit of original frame

    MANITOO_cmd_write_DataCtrl_1 : 1
    MANITOO_cmd_write_DataCtrl_2 : 0
                          RESULT : 0  -> overwritten bit value 0

    MANITOO_cmd_write_DataCtrl_1 : 1
    MANITOO_cmd_write_DataCtrl_2 : 1
                          RESULT : 1  -> overwritten bit value 1

EXAMPLE FOR 1 DataSet :

        Masks of DataSets for MANIPULATION
        00000000000011110011111111110000    Mask given in MANITOO_cmd_write_DataCtrl_1  ( 0x000F3FF0 )
        00000000000001001101000000110000    Mask given in MANITOO_cmd_write_DataCtrl_2  ( 0x0004D030 )
        --------------------------------
        xxxxxxxxxxxx0100ii0100000011xxxx    MANIPULATION OPERATION

     In Reality on the SPI Bus

        10101010101001111101010100100000    MISO ORIGINAL ( 0xAAA7D520 )
        vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

        xxxxxxxxxxxx0100ii0100000011xxxx    MANIPULATION OPERATION
        vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

        10101010101001000001000100110000    MISO MANIPULATED ( 0xAAA41130 )



This will be defined for seperate Manipulation Modules ( 0.. 3 ) and
    specifically for each Data Set of FIFO queue to be executed ( 1 .. 15 ) and
    specifically for each of Bit of 32-bit-frame

Manitoo Service Number :: 0x43

Input arguments :

    $spi_manipulation_module_int    = integer (0 - 11) , SPI manipulation module.
                                      0 - SPI manipulation module 00
                                      1 - SPI manipulation module 01
                                      2 - SPI manipulation module 02
                                        '
                                        '
                                      11 - SPI manipulation module 11

    $manipu_bit_masks_href      = hash reference, containing
                                            dataset numbers (integer 1..15)
                                                with 32-bit-mask part 1 ( strings, 32-bit hex value )

                                $manipu_bit_masks_href =
                                {
                                    # KEY is
                                    # ID of dataset , integer from 1 ... 15
                                    #     must be increased by 1  ( e.g.  1 2 3 4 )
                                    #      no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )
                                    '1' => <dataset_1_manipul_mask_part_1> ,
                                    ...
                                    ...
                                    'm' => <dataset_m_manipul_mask_part_1>
                                }

NOTES :

    'ID of dataset' used in $manipu_bit_masks_href
    integer (1 - 15) , identification number of manipulation data sets, which will be used in sequence
              must be increased by 1  ( e.g.  1 2 3 4 )
              no leakages in sequence are allowed ( e.g. 1 2 4 5 => error )

              1 - mode for 1st manipulation data set
              2 - mode for 2nd manipulation data set
              ....
              ....
              15 - mode for 15th manipulation data set


    <dataset_1_manipul_mask_part_m> used in $manipu_bit_masks_href
        string , hex-value of 32-bit-Mask given as described in manipulation above
        ( part 1 of MANITOO_cmd_write_DataCtrl_2, e.g. '000F3FF0' or '00 0F 3F F0')

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['43' , '0B'];
                                43-> Service number
                                0B -> number of bytes sent( depends on the number of manipulation datasets sent).
                                    (for two datasets -> 0B)

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_2( 0 ,
                                                                      {
                                                                        '1' => '00 0F 3F F0' ,
                                                                      }
                                                                  );

    SPI Manipulation MOdule '0' selected


Example2(Success) :

    ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_2( 2,
                                                                    {
                                                                        '1' => '0x000F3FF0',
                                                                        '2' => '000E4FF0',
                                                                        '3' => '00 0A 5F F0',
                                                                        '4' => '0x000B6FF0',
                                                                     },
                                                                  );


    Return Values         : $status = 1;
                            $response_hex_aref = ['43' ,  '13'];
                            43 --> command number.
                            13 --> number of bytes sent in hex (4 data sets).

Example3(error) :

    ($status , $response_hex_aref ) =
                                    MANITOO_cmd_write_DataCtrl_2( 3,
                                                                            {
                                                                                '1' => '0x000F3FF0',
                                                                                '2' => '0x000E4FF0',
                                                                                # wrong counting of data set IDs
                                                                                '6' => '0x000A5FF0',
                                                                                '7' => '0x000B6FF0',
                                                                             },
                                                                          );

    Input arguments       : $spi_manipulation_module_int    : 3

    Error                 : MANITOO_cmd_write_DataCtrl_2 : Wrong counting of IDs of used datasets,
                                should start with 1 and should be in range 1 .. 15

    Return Values         : $status = 0;
                            $response_hex_aref = [];


=cut

sub MANITOO_cmd_write_DataCtrl_2 {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_write_DataCtrl_2 ( $spi_manipulation_module_int, $manipu_bit_masks_href, )', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module in integer

    my $manipu_bit_masks_href = shift;          #value of control bits in 4 byte hex string

    my $service_number = '43';

    my $command_string_hex = undef;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_2 : SPI manipulation module configured '$spi_manipulation_module_int' is out of range, valid range 0 .. 11 (integer)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_write_DataCtrl_2 : Processing command 43 ... \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_write_DataCtrl_2 : (arg1) SPI manipulation module selected = $spi_manipulation_module_int \n", "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    #collect the number of manipulation data sets configured in hex
    my $num_of_manipu_datasets_hex = unpack( 'H2', pack( 'i*', scalar keys %{$manipu_bit_masks_href} ) );

    if ( keys %{$manipu_bit_masks_href} < 1 ) {
        S_set_error( "MANITOO_cmd_write_DataCtrl_2 : Atleast one manipulation mode setting should be configured.\n", 109 );
        return ( 0, [] );
    }

    my $bit_mask_count = 1;
    my $bitmask_string = '';
    foreach my $manipu_bit_mask ( sort { $a <=> $b } keys %{$manipu_bit_masks_href} ) {

        unless ( $bit_mask_count == $manipu_bit_mask ) {
            S_set_error( "MANITOO_cmd_write_DataCtrl_2 : Wrong counting of IDs of used datasets, should start with 1 and should be in range 1 .. 15\n", 109 );
            return ( 0, [] );
        }
        $bitmask_string .= $$manipu_bit_masks_href{$manipu_bit_mask};    #append all the DataCtrl 2 mask values
        $bitmask_string =~ s/0x//g;
        $bitmask_string =~ s/[-\s*]//g;
        $bit_mask_count++;
    }

    #command string for service 43
    $command_string_hex = $service_number . $spi_manipulation_module_hex . $num_of_manipu_datasets_hex . $bitmask_string;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_WD_CS

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_WD_CS ($cs_selection_for_wd_int);

This function defines the Chip Select (CS) selection for the sensor under test.

Manitoo Service Number    : 0x51

Input arguments           :

    $cs_selection_for_wd_int = integer (0 .. 19) CS selection for watch dog.
                                                                0  - CS 0
                                                                1  - CS 1
                                                                   '
                                                                   '
                                                                19 - CS 19

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['51' , '05'];
                                51 -> Service number
                                05 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []


Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_CS(13);

    Input arguments       : $cs_selection_for_wd_int : 13
                            (selection : 13 = 0b0000 0001 0000 0000 0000 ---------> chip select 13 selected)

    Return Values         : $status = 1;
                            $response_hex_aref = ['51' , '05'];

Example2(Error) :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_CS(34);

    Input arguments       : $cs_selection_for_wd_int : 34

    Error                 : MANITOO_cmd_WD_CS : Chip select value '34' for watch dog is out of range,
                            should be in the range 0 .. 19(integer value)

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_WD_CS {
    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'MANITOO_cmd_WD_CS ($cs_selection_for_wd_int)', @args );

    my $cs_selection_for_wd_int = shift;    #value of CS for watch dog in integer

    my $service_number = "51";

    my $command_string_hex = undef;

    my $donot_care = 0;

    if ( $cs_selection_for_wd_int < 0 or $cs_selection_for_wd_int > 19 ) {

        S_set_error( "MANITOO_cmd_WD_CS : Chip select selection value '$cs_selection_for_wd_int' for watch dog is out of range, should be in the range 0 .. 19(integer value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_WD_CS : Processing command $service_number .. \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_WD_CS : (arg1) CS selected for watch dog: $cs_selection_for_wd_int \n", "grey" );

    #converting the value of cs_selection_for_wd_int to twenty bits hexadecimal value
    # 2  -> 0b0000 0000 0000 0000 0010 -> 0x00002

    my $cs_selection_bin = 0 x ( 19 - $cs_selection_for_wd_int );    # $cs_selection_bin = 5 : 0 x (19 - 5) = 00000000000000 (14 zeros).
    my $cs_bit_buffer    = 0 x ($cs_selection_for_wd_int);           # $cs_bit_buffer = 5 : 0 x (5)    = 00000 (5 zeros).
    $cs_selection_bin = $cs_selection_bin . '1' . $cs_bit_buffer;    # $cs_selection_bin = 00000000000000010000  the bit position of '1'
                                                                     # indicates CS.

    #converting the value of  CS to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Bit string
    #
    my $cs_selection_hex = unpack(
        'H5',    # 5 nibbles in hex
        pack(
            'B20',    # twenty bit binary string
            $cs_selection_bin
        )
    );

    $command_string_hex = $service_number . $donot_care . $donot_care . $donot_care . $cs_selection_hex;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_WD_FrameMask

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_WD_FrameMask ($frame_mask_hex_str);

This function defines the Watch Dog (WD) frame mask which inturn helps in detecting the WD frame.

Manitoo Service Number    : 0x52

Input arguments           :

    $frame_mask_hex_str = string ('dddddddd') ---->  4 hex byte

        Allowed hex string formats:
            a) 'dddddddd' -> 'F8000000'
            b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
            c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
            d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['52' , '05'];
                                52 -> Service number
                                05 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_FrameMask('FFC00000');

    Input arguments       : $frame_mask_hex_str : 'FFC00000'

    Return Values         : $status = 1;
                            $response_hex_aref = ['52' , '05'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_FrameMask('FFC000');

    Input arguments       : $frame_mask_hex_str : 'FFC000'

    Error                 : MANITOO_cmd_WD_FrameMask : The length of frame mask 'FFC000' should be of 4 hex byte string.

    Return Values         : $status = 0;
                            $response_hex_aref = [];


=cut

sub MANITOO_cmd_WD_FrameMask {
    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_WD_FrameMask ( $frame_mask_hex_str)', @args );

    my $frame_mask_hex_str = shift;    #value of frame mask in hex

    my $service_number = "52";

    my $command_string_hex = undef;

    unless ( $frame_mask_hex_str =~ /^[0-9A-F]{8}$/i ) {    #check 4 bytes hexadecimal value
        S_set_error( "MANITOO_cmd_WD_FrameMask : The length of frame mask '$frame_mask_hex_str' should be of 4 hex byte string\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_WD_FrameMask : Processing command $service_number .. \n",             "grey" );
    S_w2log( 4, " MANITOO_cmd_WD_FrameMask : (arg1) Frame mask selected : $frame_mask_hex_str \n", "grey" );

    $command_string_hex = $service_number . $frame_mask_hex_str;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_WD_FramePattern

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_WD_FramePattern ( $frame_pattern_hex_str );

This function defines the Watch Dog (WD) frame pattern which inturn helps in detecting the WD frame.

Manitoo Service Number    :: 0x53

Input arguments           :

    $frame_pattern_hex_str = 'dddddddd' ----> 4 hex bytes

        Allowed hex string formats:
            a) 'dddddddd' -> 'F8000000'
            b) 'dd dd dd dd' -> 'F8 00 00 00'   # spaces
            c) 'dd-dd-dd-dd' -> 'F8-00-00-00'   # '-' character
            d) 'dd dd-dddd'  -> 'F8 00-0000'    # combination of space and '-'

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['53' , '05'];
                                53 -> Service number
                                05 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_FramePattern('01000000');

    Input arguments       : $frame_pattern_hex_str : '01000000'

    Return Values         : $status = 1;
                            $response_hex_aref = ['53' , '05'];

Example2(error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_WD_FramePattern('0100000000');

    Input arguments       : $frame_pattern_hex_str : '0100000000'

    Error                 : MANITOO_cmd_WD_FramePattern : The length of frame pattern '0100000000' should be of
                                4 hex bytes string.

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_WD_FramePattern {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_WD_FramePattern ( $frame_pattern_hex_str )', @args );

    my $frame_pattern_hex_str = shift;    #value of frame pattern in hex

    my $service_number = "53";

    my $command_string_hex = undef;

    unless ( $frame_pattern_hex_str =~ /^[0-9A-F]{8}$/i ) {
        S_set_error( "MANITOO_cmd_WD_FramePattern : The length of frame pattern '$frame_pattern_hex_str' should be of 4 byte hexadecimal value\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_WD_FramePattern : Processing command $service_number .. \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_WD_FramePattern : (arg1) Frame pattern selected : $frame_pattern_hex_str \n", "grey" );

    $command_string_hex = $service_number . $frame_pattern_hex_str;

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_PT_SPI_CS

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PT_SPI_CS (
                                                                                                $pre_trigger_module_int,
                                                                                                $spi_selection_int,
                                                                                                $CS_selection_int
                                                                                                );

This function selects the Pre - Trigger module, SPI bus number and Chip Select for the target sensor under test.

Manitoo Service Number    : 0x61

Input arguments           :

    $pre_trigger_module_int : integer (0 .. 3) Pre Trigger module
                              0 - PreTrigger module 00
                              1 - PreTrigger module 01
                              2 - PreTrigger module 02
                              3 - PreTrigger module 03

    $spi_selection_int      : integer (1 .. 4) SPI bus number
                              1 - SPI 1
                              2 - SPI 2
                              3 - SPI 3
                              4 - SPI 4

    $CS_selection_int       : integer (0 .. 19) Chip select selection
                              0  - CS 0
                              1  - CS 1
                                 '
                                 '
                              19 - CS 19

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['61' , '06'];
                                61 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_SPI_CS(1, 1, 3);

    Input arguments       : $pre_trigger_module_int : 1
                            $spi_selection_int      : 1
                            $CS_selection_int       : 3


    Return Values         : $status = 1;
                            $response_hex_aref = ['61' , '06'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_SPI_CS(1, 7, 3);

    Input arguments       : $pre_trigger_module_int : 1
                            $spi_selection_int      : 1
                            $CS_selection_int       : 3

    Error                 : MANITOO_cmd_PT_SPI_CS : SPI selection value '7' is out of range,
                            should be in the range 1 .. 4(integer value)

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_PT_SPI_CS {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_PT_SPI_CS ( $pre_trigger_module_int, $spi_selection_int, $CS_selection_int)', @args );

    my $pre_trigger_module_int = shift;    #value of PT module in integer
    my $spi_selection_int      = shift;    #value of SPI selection in integer
    my $cs_selection_int       = shift;    #value of CS in integer

    my $service_number = "61";             #command number

    my $command_string_hex = undef;
    my $dont_care          = 0;

    if ( $pre_trigger_module_int < 0 or $pre_trigger_module_int > 3 ) {
        S_set_error( "MANITOO_cmd_PT_SPI_CS : Pre Trigger module value '$pre_trigger_module_int' is out of range, should be in the range 0 .. 3(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $spi_selection_int < 1 or $spi_selection_int > 4 ) {
        S_set_error( "MANITOO_cmd_PT_SPI_CS : SPI selection value '$spi_selection_int' is out of range, should be in the range 1 .. 4(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $cs_selection_int < 0 or $cs_selection_int > 19 ) {
        S_set_error( "MANITOO_cmd_PT_SPI_CS : Chip Select value '$cs_selection_int' is out of range, should be in the range 0 .. 19(integer value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_PT_SPI_CS : Processing command $service_number ..\n",                 "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_SPI_CS : (arg1) PT module selected : $pre_trigger_module_int \n", "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_SPI_CS : (arg2) SPI selected : $spi_selection_int\n",             "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_SPI_CS : (arg3) CS selected : $cs_selection_int\n",               "grey" );

    #converting the value of PT module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $pre_trigger_module_hex = unpack(
        'H2',    # 1 byte hexadecimal
        pack(
            'i*',    # integer (signed)
            $pre_trigger_module_int
        )
    );

    #converting the value of  SPI selection to hexadecimal value
    my $spi_selection_hex = sprintf( "%x", $spi_selection_int );

    #converting the value of CS_selection_int to twenty bits hexadecimal value     : 2  -> 0b0000 0000 0000 0000 0010 -> 0x00002
    my $cs_selection_bin = 0 x ( 19 - $cs_selection_int );    # $cs_selection_bin = 5 : 0 x (19 - 5) = 00000000000000 (14 zeros).
    my $cs_bit_buffer    = 0 x ($cs_selection_int);           # $cs_bit_buffer = 5 : 0 x (5)    = 00000 (5 zeros).
    $cs_selection_bin = $cs_selection_bin . '1' . $cs_bit_buffer;    # $cs_selection_bin = 00000000000000010000  the bit position of '1'
                                                                     # indicates CS.

    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $cs_selection_hex = unpack(
        'H5',    # 5 nibble hexadecimal
        pack(
            'B20',    #twenty bit binary
            $cs_selection_bin
        )
    );

    $command_string_hex = $service_number . $pre_trigger_module_hex . $dont_care . $dont_care . $spi_selection_hex . $cs_selection_hex;

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return ( 0, [] );
    }

    return ( 1, [] ) if ($main::opt_offline);
    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_PT_FrameMask

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PT_FrameMask ( $pre_trigger_module_int, $frame_mask_hex_str );

This function defines the Pre Trigger frame mask.

Manitoo Service Number    : 0x62

Input arguments           :

    $pre_trigger_module_int : Pre Trigger module 0 � 3.
                                  0 - PreTrigger module 00
                                  1 - PreTrigger module 01
                                  2 - PreTrigger module 02
                                  3 - PreTrigger module 03

    $frame_mask_hex_str         : String ('dddddddd') frame mask in 4 hex bytes.

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['62' , '06'];
                                62 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_FrameMask(1, 'FFFFFFFF');

    Input arguments       : $pre_trigger_module_int = 1.
                            $frame_mask_hex_str = 'FFFFFFFF'.

    Return Values         : $status = 1;
                            $response_hex_aref = ['62' , '06'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_FrameMask(2, 'FFFFFFFFAD');
                                                                    # wrong pre - trigger mask

    Input arguments       : $pre_trigger_module_int = 2.
                            $frame_mask_hex_str = 'FFFFFFFFAD'.

    Error                 : MANITOO_cmd_PT_FrameMask : The length of frame mask 'FFFFFFFFAD' should be of 4 hex byte string

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_PT_FrameMask {

    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'MANITOO_cmd_PT_FrameMask ( $pre_trigger_module_int, $frame_mask_hex_str)', @args );

    my $pre_trigger_module_int = shift;    #value of pre trigger module in integer
    my $frame_mask_hex_str     = shift;    #value of frame mask in 4 hex bytes
    my $service_number         = "62";     #command number

    my $command_string_hex = undef;

    if ( $pre_trigger_module_int < 0 or $pre_trigger_module_int > 3 ) {
        S_set_error( "MANITOO_cmd_PT_FrameMask : Pre Trigger module value '$pre_trigger_module_int' is out of range, valid range 0 .. 3 (integer)\n", 109 );
        return ( 0, [] );
    }

    $frame_mask_hex_str =~ s/[-\s*]//g;
    $frame_mask_hex_str =~ s/^0x//g;

    unless ( $frame_mask_hex_str =~ /^[0-9A-F]{8}$/i ) {    # check for 4 bytes hexadecimal value
        S_set_error( "MANITOO_cmd_PT_FrameMask : The length of frame mask '$frame_mask_hex_str' should be of 4 hex byte string\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_PT_FrameMask : Processing command $service_number ..\n",                "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_FrameMask : (arg1) PT module selected : $pre_trigger_module_int\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_FrameMask : (arg2) Frame mask selected : $frame_mask_hex_str \n",   "grey" );

    #converting the value of PT module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $pre_trigger_module_hex = unpack(
        'H2',    # 1 byte hexadecimal
        pack(
            'i*',    #integer (signed)
            $pre_trigger_module_int
        )
    );

    $command_string_hex = $service_number . $pre_trigger_module_hex . $frame_mask_hex_str;

    my $options_href = { check_response => 1, nbr_bytes_exp => 2 };

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return ( 0, [] );
    }
    return ( 1, [] ) if ($main::opt_offline);

    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, $options_href );

    # Note : error in return values handled in MANITOO_cmd_Request_Response function

    return ( $status, $response_hex_aref );

}

=head2 MANITOO_cmd_PT_FramePattern

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PT_FramePattern ($pre_trigger_module_int, $frame_pattern_hex_str);

This function defines the Pre Trigger frame pattern.

Manitoo Service Number :: 0x63

Input arguments  :

    $pre_trigger_module_int : integer (0 � 3) , Pre Trigger module selection.
                               0 - PreTrigger module 00
                               1 - PreTrigger module 01
                               2 - PreTrigger module 02
                               3 - PreTrigger module 03

    $frame_pattern_hex_str  : String ('dddddddd') , frame pattern in 4 hex bytes.

Return Values :

    Return values in Success  :  $status = 1;
                                 $response_hex_aref = ['63' , '06'];
                                 63 -> Service number
                                 06 -> number of bytes sent.

    Return values in error    :  $status = 0;
                                 $response_hex_aref = [];

    Return Offline            :  1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_FramePattern(3, '48D61838');

    Input arguments       :  $pre_trigger_module_int = 3.
                             $frame_pattern_hex_str      = '48D61838'.

    Return Values         :  $status = 1;
                             $response_hex_aref = ['63' , '06'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_FramePattern(3, '48D6183845');
                                                                      # wrong frame pattern

    Input arguments       :  $pre_trigger_module_int = 3.
                             $frame_pattern_hex_str      = '48D6183845'.

    Error                 :  MANITOO_cmd_PT_FramePattern : The length of frame pattern '48D6183845' should be of
                                4 byte hexadecimal value.

    Return Values         :  $status = 0;
                             $response_hex_aref = [];

=cut

sub MANITOO_cmd_PT_FramePattern {
    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'MANITOO_cmd_PT_FramePattern ( $pre_trigger_module_int, $frame_pattern_hex_str )', @args );

    my $pre_trigger_module_int = shift;    #value of pre trigger module in int
    my $frame_pattern_hex_str  = shift;    #value of frame pattern in 4 hex bytes

    my $service_number = "63";             #command number

    my $command_string_hex = undef;

    if ( $pre_trigger_module_int < 0 or $pre_trigger_module_int > 3 ) {
        S_set_error( "MANITOO_cmd_PT_FramePattern : Pre Trigger module value '$pre_trigger_module_int' is out of range, should be any one of the values (0, 1, 2 or 3)\n", 109 );
        return ( 0, [] );
    }

    $frame_pattern_hex_str =~ s/[-\s*]//g;
    $frame_pattern_hex_str =~ s/^0x//g;

    unless ( $frame_pattern_hex_str =~ /^[0-9A-F]{8}$/i ) {    #check for 4 bytes hexadecimal
        S_set_error( "MANITOO_cmd_PT_FramePattern : The length of frame pattern '$frame_pattern_hex_str' should be of 4 byte hexadecimal value\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_PT_FramePattern : Processing command $service_number ..\n",                    "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_FramePattern : (arg1) PT module selected : $pre_trigger_module_int\n",     "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_FramePattern : (arg2) Frame pattern selected : $frame_pattern_hex_str \n", "grey" );

    #converting the value of PT module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $pre_trigger_module_hex = unpack(
        'H2',    # 1 byte hexadecimal
        pack(
            'i*',    #integer (signed)
            $pre_trigger_module_int
        )
    );

    $command_string_hex = $service_number . $pre_trigger_module_hex . $frame_pattern_hex_str;

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_PT_Time

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PT_Time ($pre_trigger_module_int, $waiting_time_for_PT_timer_us );

This function defines the Waiting time in 1�s resolution for PT Timer (Pre-Trigger).

Manitoo Service Number    :  0x64

Input arguments           :

    $pre_trigger_module_int        : integer , Pre Trigger module (0 � 3).

    $waiting_time_for_PT_timer_us  : integer , Waiting time in 1�s resolution for PT Timer.
                                     After an activation of the PT it stays active for PT Time.

Return Values  :

    Return values in Success  :  $status = 1;
                                 $response_hex_aref = ['64' , '06'];
                                 64 -> Service number
                                 06 -> number of bytes sent.

    Return values in error    :  $status = 0;
                                 $response_hex_aref = [];

    Return Offline            :  1, []


Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_Time( 1, 2000000);

    Input arguments       :  $pre_trigger_module_int = 1.
                             $waiting_time_for_PT_timer_us = 20000000 micro seconds.

    Return Values         :  $status = 1;
                             $response_hex_aref = ['64' , '06'];

Example2(Error)           :

    ( $status , $response_hex_aref ) = MANITOO_cmd_PT_Time( 6 , 2000000); # wrong pre-trigger given.

    Input arguments       :  $pre_trigger_module_int = 6.
                             $waiting_time_for_PT_timer_us = 20�s.

    Error                 :  MANITOO_cmd_PT_Time : Pre Trigger module value '6' is out of range,
                             should be any one of the values (0, 1, 2 or 3)

    Return Values         :  $status = 0;
                             $response_hex_aref = [];

=cut

sub MANITOO_cmd_PT_Time {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_PT_Time ( $pre_trigger_module_int, $waiting_time_for_PT_timer_us )', @args );

    my $pre_trigger_module_int       = shift;    #value of pre trigger module in hex
    my $waiting_time_for_PT_timer_us = shift;    #value of waiting time in micro seconds for PT timer
    my $service_number               = "64";     #command number

    my $command_string_hex = undef;

    if ( $pre_trigger_module_int < 0 or $pre_trigger_module_int > 3 ) {
        S_set_error( "MANITOO_cmd_PT_Time : Pre Trigger module value '$pre_trigger_module_int' is out of range, should be any one of the values (0, 1, 2 or 3)\n", 109 );
        return ( 0, [] );
    }

    if ( $waiting_time_for_PT_timer_us < 0 or $waiting_time_for_PT_timer_us > 4294967295 ) {
        S_set_error( "MANITOO_cmd_PT_Time : Waiting time for PT timer '$waiting_time_for_PT_timer_us' micro seconds is out of range, should be in the range 0 to 4294967295 micro seconds\n", 109 );
        return ( 0, [] );
    }

    #converting the value of PT module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $pre_trigger_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $pre_trigger_module_int
        )
    );

    S_w2log( 4, "MANITOO_cmd_PT_Time : Processing command $service_number ..\n",                          "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_Time : (arg1) PT module selected = $pre_trigger_module_int \n",          "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_Time : (arg2) waiting time selected : $waiting_time_for_PT_timer_us \n", "grey" );

    #converting the value of PT timer to hexadecimal value
    #
    #   See : http://perldoc.perl.org/perlpacktut.html#How-to-Eat-an-Egg-on-a-Net
    #
    my $waiting_time_for_PT_timer_hex = unpack(
        'H8',    # 4 hex Bytes
        pack(
            'N*',    # 32 bit number
            $waiting_time_for_PT_timer_us
        )
    );

    $command_string_hex = $service_number . $pre_trigger_module_hex . $waiting_time_for_PT_timer_hex;

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_PT_StatusMask

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_PT_StatusMask (
                                                                            $spi_manipulation_module_int,
                                                                            $pre_trigger_status_mask_int
                                                                          );

This function defines for one specific SPI manipulation module the Pre Trigger Status Mask to be considered
(as an AND condition of the PreTrigger flags).

The PreTrigger Status Mask represent the active outputs of the (independent) PreTrigger modules
as the True-condition for the SPI manipulation of the specific SPI manipulation module

Manitoo Service Number    :  0x65

Input arguments           :

    $spi_manipulation_module_int : integer (0 - 11 dec) , SPI manipulation module
                                         0 - SPI manipulation module 00
                                         1 - SPI manipulation module 01
                                         2 - SPI manipulation module 02
                                           '
                                           '
                                         11 - SPI manipulation module 11

    $pre_trigger_status_mask_int : integer (1 � 15 dec) , Mask of the Pre Trigger Module output
                                        0bxxx1 : PreTrigger module 00
                                        0bxx1x : PreTrigger module 01
                                        0bx1xx : PreTrigger module 02
                                        0b1xxx : PreTrigger module 03

                                        0b0001 ... 0b1111 used as summary MASK of 4 independent PreTrigger modules

                                        ( value 0b0000 is useless )

Return Values :

    Return values in Success  :  $status = 1;
                                 $response_hex_aref = ['65' , '06'];
                                 65 -> Service number
                                 06 -> number of bytes sent.

    Return values in error    :  $status = 0;
                                 $response_hex_aref = [];

    Return Offline            :  1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_StatusMask( 2, 3 );

    Input arguments       :  $spi_manipulation_module_int = 2
                             $pre_trigger_status_mask_int = 3
                                ( -> Mask is 0x0011 -> PreTrigger 00 + 01 are active )

    Return Values         :  $status = 1;
                             $response_hex_aref = ['65' , '06'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_PT_StatusMask( 4 , 23 );

    Input arguments       :  $spi_manipulation_module_int = 2.
                             $pre_trigger_status_mask_int = 23 ( MASK : 0b10111   --> tooo long )

    Error                 :  MANITOO_cmd_PT_StatusMask : Pre trigger status mask value '23' is out of range,
                             valid range is 1 .. 15

    Return Values         :  $status = ;
                             $response_hex_aref = [];

=cut

sub MANITOO_cmd_PT_StatusMask {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_PT_StatusMask ( $spi_manipulation_module_int, $pre_trigger_status_mask_int)', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module selection in integer
    my $pre_trigger_status_mask_int = shift;    #value of pre trigger module in integer
    my $service_number              = '65';     #command number

    my $command_string_hex = undef;
    my $dont_care          = 0;
    $dont_care = $dont_care x 7;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_PT_StatusMask : SPI selection value '$spi_manipulation_module_int' is out of range, valid range is 0 .. 11\n", 109 );
        return ( 0, [] );
    }

    if ( $pre_trigger_status_mask_int < 1 or $pre_trigger_status_mask_int > 15 ) {
        S_set_error( "MANITOO_cmd_PT_StatusMask : Pre trigger status mask value '$pre_trigger_status_mask_int' is out of range, valid range is 1 .. 15\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, " MANITOO_cmd_PT_StatusMask : Processing command $service_number ..\n",                                  "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_StatusMask : (arg1) SPI manipulation module selected : $spi_manipulation_module_int\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_PT_StatusMask : (arg2) PT module selected : $pre_trigger_status_mask_int\n",               "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    #   See : http://perldoc.perl.org/perlpacktut.html#integer
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    # 1 hex Byte
        pack(
            'i*',    # integer (signed)
            $spi_manipulation_module_int
        )
    );

    #converting the value of Pre - Trigger module to hexadecimal value

    my $pre_trigger_status_mask_hex = sprintf( "%x", $pre_trigger_status_mask_int );

    $command_string_hex = $service_number . $spi_manipulation_module_hex . $dont_care . $pre_trigger_status_mask_hex;

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_SMI7_SPI_CS

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_SMI7_SPI_CS (
                                                                        $spi_selection_int,
                                                                        $cs_selection_int
                                                                    );

This function is for SMI7 SPI bus number selection and SMI7 ChipSelect selection.

Manitoo Service Number    : 0x71

Input arguments           :

    $spi_selection_int  : integer ( 1 .. 4 ) , SPI bus number to be selected for SMI7
                              1 - SPI 1
                              2 - SPI 2
                              3 - SPI 3
                              4 - SPI 4

    $cs_selection_int   : integer ( 0 .. 19 ), Chip Select selection
                              0  - CS 0
                              1  - CS 1
                              2  - CS 2
                                 '
                                 '
                              19 - CS 19

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['71' , '05'];
                                71 -> Service number
                                05 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_SMI7_SPI_CS( 1, 6 );

    Input arguments       : $spi_selection_int      : 1
                            $cs_selection_int       : 6

    Return Values         : $status = 1;
                            $response_hex_aref = ['71' , '05'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_SMI7_SPI_CS( 5, 6 );
                                                                    #wrong SPI bus number selection

    Input arguments       : $spi_selection_int      : 5
                            $cs_selection_int       : 6

    Error                 : MANITOO_cmd_SMI7_SPI_CS : SPI selection value '5' is out of range,
                                should be in the range 1 to 4(integer value)

    Return Values         : $status = 0;
                            $response_hex_aref = [];

    (Note: old name of this function was 'MANITOO_cmd_SMI7_SPI_Mask_and_SMI7_CS_Mask' )

=cut

sub MANITOO_cmd_SMI7_SPI_CS {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_SMI7_SPI_CS ( $spi_selection_int, $cs_selection_int )', @args );

    my $spi_selection_int = shift;    #value of SPI selection in integer
    my $cs_selection_int  = shift;    #value of CS in integer

    my $service_number = "71";        #command number

    my $command_string_hex = undef;
    my $dont_care          = 0;

    if ( $spi_selection_int < 1 or $spi_selection_int > 4 ) {
        S_set_error( "MANITOO_cmd_SMI7_SPI_CS : SPI selection value '$spi_selection_int' is out of range, should be in the range 1 to 4(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $cs_selection_int < 0 or $cs_selection_int > 19 ) {
        S_set_error( "MANITOO_cmd_SMI7_SPI_CS : Chip select value '$cs_selection_int' is out of range, should be in the range 1 - 20(integer value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, " MANITOO_cmd_SMI7_SPI_CS : Processing command $service_number ..\n",    "grey" );
    S_w2log( 4, " MANITOO_cmd_SMI7_SPI_CS : (arg1) SPI selected = $spi_selection_int\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_SMI7_SPI_CS : (arg2) CS selected = $cs_selection_int\n",   "grey" );

    #converting integer to hexadecimal value for CS selection : 5 -> 0b0000 0000 0000 0010 0000 -> 0x00020
    my $cs_selection_bin = 0 x ( 19 - $cs_selection_int );
    my $cs_bit_buffer    = 0 x ($cs_selection_int);
    $cs_selection_bin = $cs_selection_bin . '1' . $cs_bit_buffer;

    S_w2log( 3, " MANITOO_cmd_SMI7_SPI_CS: Chip Select Binary : $cs_selection_bin \n" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    #   See : http://perldoc.perl.org/functions/pack.html # pack
    #
    my $cs_selection_hex = unpack(
        'H5',    # 5 nibble in hex
        pack(
            'B20',    # 20 bit binary
            $cs_selection_bin
        )
    );

    $command_string_hex = $service_number . $dont_care . $dont_care . $spi_selection_int . $cs_selection_hex;

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_SMI7_Page

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_SMI7_Page (
                                                                       $spi_manipulation_module_int,
                                                                       $smi7_module_number_int,
                                                                       $smi7_page_number_int
                                                                   );

This function is for defining the SMI7 page selection.
Each SMI7 sensor is carring 1 .. 4 specific internal physical sensor modules.
Each SMI7 internal physical sensor moduels have 1 .. 8 pages

SMI7 manipulation is only possible if the selected sensor module and the selected page is given in this command.

Manitoo Service Number    : 0x72

Input arguments           :

    $spi_manipulation_module_int : integer (0 - 11 dec) , SPI manipulation module.
                                     0 - SPI manipulation module 00
                                     1 - SPI manipulation module 01
                                     2 - SPI manipulation module 02
                                       '
                                       '
                                     11 - SPI manipulation module 11

    $smi7_module_number_int : integer (0 - 3 dec) , SMI7 internal physical sensor module.
                     0 - SMI7 sensor module 00
                     1 - SMI7 sensor module 01
                     2 - SMI7 sensor module 02
                     3 - SMI7 sensor module 03

    $smi7_page_number_int : integer (0 - 7 dec) , SMI7 page ( of the internal physical sensor module ).
                     0 - SMI7 sensor module 00
                     1 - SMI7 sensor module 01
                     2 - SMI7 sensor module 02
                     ...
                     ...
                     7 - SMI7 sensor module 07

Return Values :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['72' , '06'];
                                72 -> Service number
                                06 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_SMI7_Page(1, 2, 5);

    Input arguments       : $spi_manipulation_module_int = 1
                            $smi7_module_number_int      = 2
                            $smi7_page_number_int        = 5

    Return Values         : $status = 1;
                            $response_hex_aref = ['72' , '06'];

Example2(error) :

    ($status , $response_hex_aref ) = MANITOO_cmd_SMI7_Page(1, 6, 5);
                                                                    #wrong selection of SMI7 module

    Input arguments       : $spi_manipulation_module_int = 1
                            $smi7_module_number_int      = 6
                            $smi7_page_number_int        = 5

    Error                 : MANITOO_cmd_SMI7_Page :
                                SMI7 module selection value '6' is out of range,
                                    should be in the range 0 to 3 (integer value)

    Return Values         : $status = 0;
                            $response_hex_aref = [];

    ( Note : old name of function was 'MANITOO_cmd_SMI7_Page_Mask')

=cut

sub MANITOO_cmd_SMI7_Page {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_SMI7_Page ( $spi_manipulation_module_int, $smi7_module_number_int, $smi7_page_number_int )', @args );

    my $spi_manipulation_module_int = shift;    #value of SPI manipulation module in integer
    my $smi7_module_number_int      = shift;    #value of SMI7 module in integer
    my $smi7_page_number_int        = shift;    #value of SMI7 page number in integer

    my $service_number = "72";                  #command number

    my $command_string_hex = undef;

    if ( $spi_manipulation_module_int < 0 or $spi_manipulation_module_int > 11 ) {
        S_set_error( "MANITOO_cmd_SMI7_Page : SPI manipulation module value '$spi_manipulation_module_int' is out of range, should be in the range 0 to 11(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $smi7_module_number_int < 0 or $smi7_module_number_int > 3 ) {
        S_set_error( "MANITOO_cmd_SMI7_Page : SMI7 module selection value '$smi7_module_number_int' is out of range, should be in the range 0 to 3(integer value)\n", 109 );
        return ( 0, [] );
    }

    if ( $smi7_page_number_int < 0 or $smi7_page_number_int > 7 ) {
        S_set_error( "MANITOO_cmd_SMI7_Page : SMI7 page number selection value '$smi7_page_number_int' is out of range, should be in the range 0 to 7(integer value)\n", 109 );
        return ( 0, [] );
    }

    S_w2log( 4, "MANITOO_cmd_SMI7_Page: Processing command $service_number ..\n",                                  "grey" );
    S_w2log( 4, " MANITOO_cmd_SMI7_Page: (arg1)SPI manipulation module selected = $spi_manipulation_module_int\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_SMI7_Page: (arg2)SMI7 module selected : $smi7_module_number_int\n",                  "grey" );
    S_w2log( 4, " MANITOO_cmd_SMI7_Page: (arg2)SMI7 page number value selected : $smi7_page_number_int\n",         "grey" );

    #converting the value of SPI manipulation module to hexadecimal value
    #
    # See http://perldoc.perl.org/perlpacktut.html#Integers
    #
    my $spi_manipulation_module_hex = unpack(
        'H2',    #1 byte hexadecimal
        pack(
            'i*',    #integer (signed)
            $spi_manipulation_module_int
        )
    );

    # smi7_module_page_number hash containing the details of SMI7 module and page number mapping.
    my $smi7_module_page_number = {
        0 => {       # module 0
            0 => '00000001',    #page 0
            1 => '00000002',    #page 1
            2 => '00000004',    #page 2
            3 => '00000008',    #page 3
            4 => '00000010',    #page 4
            5 => '00000020',    #page 5
            6 => '00000040',    #page 6
            7 => '00000080',    #page 7
        },
        1 => {                  # module 1
            0 => '00000100',    #page 0
            1 => '00000200',    #page 1
            2 => '00000400',    #page 2
            3 => '00000800',    #page 3
            4 => '00001000',    #page 4
            5 => '00002000',    #page 5
            6 => '00004000',    #page 6
            7 => '00008000',    #page 7
        },
        2 => {                  # module 2
            0 => '00010000',    #page 0
            1 => '00020000',    #page 1
            2 => '00040000',    #page 2
            3 => '00080000',    #page 3
            4 => '00100000',    #page 4
            5 => '00200000',    #page 5
            6 => '00400000',    #page 6
            7 => '00800000',    #page 7
        },
        3 => {                  # module 3
            0 => '01000000',    #page 0
            1 => '02000000',    #page 1
            2 => '04000000',    #page 2
            3 => '08000000',    #page 3
            4 => '10000000',    #page 4
            5 => '20000000',    #page 5
            6 => '40000000',    #page 6
            7 => '80000000',    #page 7
        },
    };

    #converting the value of SMI7 module and SMI7 page number to hexadecimal value
    my $smi7_module_page_number_hex = $smi7_module_page_number->{$smi7_module_number_int}{$smi7_page_number_int};

    $command_string_hex = $service_number . $spi_manipulation_module_hex . $smi7_module_page_number_hex;

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_FET_control

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_FET_control (
                                                                        $fet_device_nbr_int,
                                                                        $fet_port_control_href,
                                                                     );

This function defines the activation of ManiToo FET ports.
Hash reference as argument defines the 'ON' or 'OFF' state of the port number
FET 0 has 1 .. 3 ports
FET 1 has 1 .. 15 ports
FET 2 has 1 .. 15 ports

Note :: This service controls the ports of the ManiToo FET with only three switches.

Manitoo Service Number    : 0x80 -> for FET 0  ('mini')
                            0x81 -> for FET 1
                            0x82 -> for FET 2

Input arguments           :

    $fet_device_nbr_int  = integer , Device number ( 0 .. 2 )
                           0 -> FET 0
                           1 -> FET 1
                           2 -> FET 2

    $fet_port_control_href = hash reference of port numbers ( 1 .. 16 )
                                assigned with ON|OFF control
                {
                    '1'  => 'ON'|'OFF' ,    # port number => requested state
                    '2'  => 'ON'|'OFF' ,    # port number => requested state
                    ...
                    '15' => 'ON'|'OFF' ,    # port number => requested state
                }

Return Values :

    Return values in Success  : $status = 1 (for all services);
                                $response_hex_aref = ['80' , '05'] for service 80;
                                                     ['81' , '05'] for service 81;
                                                     ['82' , '05'] for service 82;
                                80|81|82 -> Service number
                                05       -> number of bytes sent.

    Return values in error    : $status = 0 (for all services);
                                $response_hex_aref = [] (for all services);

    Return Offline            : 1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_FET_control (
                                                                  0 ,
                                                                  { '1' => 'ON' , '2' => 'OFF' }
                                                               );

    Input arguments       : $fet_device_nbr_int = 0
                            $fet_port_control_href = { '1' => 'ON' , '2' => 'OFF' }

    Return Values         : $status = 1;
                            $response_hex_aref = ['80' , '05'];

Example2(Error) :

        ($status , $response_hex_aref ) = MANITOO_cmd_FET_control (
                                                                       4 , #wrong device selection
                                                                       { '1' => 'ON' , '2' => 'OFF' }
                                                                   );

        Input arguments       : $fet_device_nbr_int = 4
                                $fet_port_control_href = { '1' => 'ON' , '2' => 'OFF' }

        Error                 : MANITOO_cmd_FET_control : The device number selected '4' is wrong,
                                    valid selection 0 .. 2(integer).

        Return Values         : $status = 0;
                                $response_hex_aref = [];

=cut

sub MANITOO_cmd_FET_control {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_FET_control ( $fet_device_nbr_int, $fet_port_control_href )', @args );

    my $fet_device_nbr_int    = shift;    # Device selection ManiToo FET
    my $fet_port_control_href = shift;    # output bit settings of ManiToo FET

    my $service_number;
    my $command_string_hex = undef;

    my $total_nbr_ports = scalar( keys %{$fet_port_control_href} );

    unless ($total_nbr_ports) {
        S_set_error( "MANITOO_cmd_FET_control : Atleast one port control value should be configured.\n", 109 );
        return ( 0, [] );
    }

    if ( $fet_device_nbr_int == 0 ) {

        $service_number = "80";

        if ( $total_nbr_ports > 3 ) {
            S_set_error( "MANITOO_cmd_FET_control : The maximum number of port control values that can be configured for FET_0 is 3. There are '$total_nbr_ports' values configured\n", 109 );
            return ( 0, [] );
        }

        my @check_port_number_error = grep { ( $_ > 15 ) or ( $_ < 1 ) } keys %{$fet_port_control_href};

        if (@check_port_number_error) {
            local $" = ', ';
            S_set_error( "MANITOO_cmd_FET_control : The port number value(s) '@check_port_number_error' configured is wrong, should be in range 1 .. 3 (integer value) for FET_0\n", 109 );
            return ( 0, [] );
        }

    }
    elsif ( $fet_device_nbr_int == 1 ) {

        $service_number = "81";

        if ( $total_nbr_ports > 6 ) {
            S_set_error( "MANITOO_cmd_FET_control : The maximum number of port control values that can be configured for FET_1 is 6. There are '$total_nbr_ports' values configured\n", 109 );
            return ( 0, [] );
        }

        my @check_port_number_error = grep { ( $_ > 6 ) or ( $_ < 1 ) } keys %{$fet_port_control_href};

        if (@check_port_number_error) {
            local $" = ', ';
            S_set_error( "MANITOO_cmd_FET_control : The port number value(s) '@check_port_number_error' configured is wrong, should be in range 1 ..6 (integer value) for FET_1 and 1 ..15 (integer value) for FET_2\n", 109 );
            return ( 0, [] );
        }

    }
    elsif ( $fet_device_nbr_int == 2 ) {

        $service_number = "82";

        if ( $total_nbr_ports > 15 and $fet_device_nbr_int == 2 ) {
            S_set_error( "MANITOO_cmd_FET_control : The maximum number of port control values that can be configured for FET_2 is 15. There are '$total_nbr_ports' values configured\n", 109 );
            return ( 0, [] );
        }

        my @check_port_number_error = grep { ( $_ > 15 ) or ( $_ < 1 ) } keys %{$fet_port_control_href};

        if (@check_port_number_error) {
            local $" = ', ';
            S_set_error( "MANITOO_cmd_FET_control : The port number value(s) '@check_port_number_error' configured is wrong, should be in range 1 ..6 (integer value) for FET_1 and 1 ..15 (integer value) for FET_2\n", 109 );
            return ( 0, [] );
        }

    }
    else {
        S_set_error( "MANITOO_cmd_FET_control : The device number selected '$fet_device_nbr_int' is wrong, valid selection 0 .. 2(integer)\n", 109 );
        return ( 0, [] );
    }

    my $port_selection_mask_bin = 0 x 16;    # sixteen binary bits for port selection mask
    my $port_control_mask_bin   = 0 x 16;    # sixteen binary bits for port control mask ( switch on or switch off )

    # setting up port selection and port control according to the input given in the FET_port_control_href
    while ( my ( $port_number_int, $port_on_or_off_str ) = each %{$fet_port_control_href} ) {

        S_w2log( 4, " MANITOO_cmd_FET_control: FET ports selected $port_number_int : $port_on_or_off_str\n", "grey" );

        my $pos_int = ( 16 - ($port_number_int) );    # position of the port selection bit.
        pos($port_selection_mask_bin) = $pos_int;     # set the position to the '$pos_int' calculated position.
        $port_selection_mask_bin =~ s/\G0/1/;         # selection of the port.
        pos($port_control_mask_bin) = $pos_int;       # set the output bit mask to the '$pos_int' calculated position.
        $port_control_mask_bin =~ s/\G0/1/ if ( $port_on_or_off_str =~ /^on$/i );    # switch on the selected port based on the input.
    }

    # convert the port selection to hexadecimal
    my $port_selection_mask_hex = unpack(
        'H4',                                                                        # 4 nibble in hex
        pack(
            'B16',                                                                   # 16 bit binary
            $port_selection_mask_bin
        )
    );

    # convert the port control to hexadecimal
    my $port_control_mask_hex = unpack(
        'H4',                                                                        # 4 nibble in hex
        pack(
            'B16',                                                                   # 16 bit binary
            $port_control_mask_bin
        )
    );
    $command_string_hex = $service_number . $port_selection_mask_hex . $port_control_mask_hex;

    S_w2log( 3, " MANITOO_cmd_FET_control: Processing command '$command_string_hex' ..\n", "grey" );

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_ReadManipulationCounter

    Syntax : ($status, $response_hex_aref , $manipulation_counter_aref ) = MANITOO_cmd_ReadManipulationCounter( $index_of_manipulation_module );

Each manipulation module of Manitoo contains a counter that counts the number of SPI frames that have been manipulated between the start of the manipulation and the stop of the manipulation. 
The service 0xE0 reads the counter of the specified manipulation module and sends the value per UART.
( actually the counters are counting during the manipulation but when StopManipulation command is called the counters are away (internally cleared). That means they have to be read at the moment shortly before Stop of manipulation)

Manitoo Service Number :: 0xE0

Input arguments   : $index_of_manipulation_module 
                     0, 1, 2, 3 , ... 11 - possible ( Manip. Module 1...12 )
                     'ALL' - for all implemented manipulation modules 

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = [ 'E0' , '02' , 'AA' , 'BB' , 'CC' , 'DD'  ]
                            E0 -> Service number
                            02 -> number of bytes sent ( from original service) )
                            AABBCCDD -> U32 integer - nbr of manipulated SPI frames
                        
                        $manipulation_counter_aref = [ X ]
                            X - nbr of manipulation of requested manipulation module

                        $manipulation_counter_aref = [ X , Y , Z , Q , .... ]
                            X , Y , Z , Q - nbr of manipulation of all implemented manipulation modules 

    Return in Error   : $status = 0
                        $response_hex_aref = []

    Return Offline    : 1, []


Example :

    ($status, $response_hex_aref, $manipulation_counter_aref) = MANITOO_cmd_ReadManipulationCounter( 0 );

    Return values : $status = 1;
                    $response_hex_aref = ['E0' , '02' , '00' , '00' , '00' , '03' ];
                    $manipulation_counter_aref = [ 3 ];  
                    
                    => manipulation module Nbr 1 (idx=0) has manipulated 3 Frames


    ($status, $response_hex_aref, $manipulation_counter_aref) = MANITOO_cmd_ReadManipulationCounter( 'ALL' );

    Return values : $status = 1;
                    $response_hex_aref = [ 
                                           'E0','02',
                                           '00','00','00','03',         # counter for module 0
                                           '00','00','00','00',         # counter for module 1
                                           '00','00','00','01',         # ....
                                           '00','00','00','00',
                                           ....
                                           ];
                    $manipulation_counter_aref = [ 3 , 0 , 1 , 0 , ... up to max nbr of counter ];

                    => manipulation module Nbr 1 (idx=0) has manipulated 3 Frames
                    => manipulation module Nbr 2 (idx=1) has manipulated 0 Frames
                    => manipulation module Nbr 3 (idx=2) has manipulated 1 Frames
                    => manipulation module Nbr 4 (idx=3) has manipulated 0 Frames
                    => ....

=cut

sub MANITOO_cmd_ReadManipulationCounter {
    my @args = @_;
    return ( 0, [], [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_ReadManipulationCounter( $index_of_manipulation_module )', @args );
    my $index_of_manipulation_module = shift @args;

    my $manipulation_counter_aref;

    my $service_number = "E0";

    my $read_all_flag = 0;

    # check for argument 'ALL'
    if ( $index_of_manipulation_module =~ /all/i ) {
        $read_all_flag                = 1;
        $index_of_manipulation_module = 0xFF;    ## From version 4.0.0 if nn > 3 then all 4 manipulation counters will be returned
    }

    # parameter check for seperately given index of manipulation module
    else {
        if (   not looks_like_number($index_of_manipulation_module)
            or $index_of_manipulation_module < 0
            or $index_of_manipulation_module > 11 )
        {
            S_set_error( "Argument 'index_of_manipulation_module' must between 0 .. 11 or 'ALL' ", 109 );
            return ( 0, [], [] );
        }
    }

    my $manipul_counter_hex = sprintf( "%02X", $index_of_manipulation_module );

    my $command_string_hex = $service_number . " " . $manipul_counter_hex;

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return ( 0, [], [] );
    }

    S_w2log( 3, "MANITOO_cmd_ReadManipulationCounter : Processing command '$command_string_hex' .. \n", "grey" );

    return ( 1, [], [1] ) if ($main::opt_offline);

    # Note : error in return values handled in MANITOO_cmd_Request_Response function
    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1 } );
    return ( 0, [], [] ) unless ($status);

    my @response = @$response_hex_aref;
    shift @response;    # remove service number
    shift @response;    # remove length of request

    # after command and length nbr of bytes shall be dividable by 4
    if ( ( scalar @response ) % 4 ) {
        S_set_error( "Unexpected nbr of bytes in Response " . join( " ", @$response_hex_aref ) . "" );
        return ( 0, $response_hex_aref, [] );
    }

    # cut always 4 bytes from remaining response
    while (@response) {
        my $value_4byte_str = join( "", splice( @response, 0, 4 ) );
        S_w2log( 4, " MANITOO_cmd_ReadManipulationCounter: extracted 4byte string '$value_4byte_str'\n" );
        my $nbr_of_manip = hex($value_4byte_str);
        push( @$manipulation_counter_aref, $nbr_of_manip );
    }

    return ( $status, $response_hex_aref, $manipulation_counter_aref );

}

=head2 MANITOO_cmd_Start_SPI_Recording

    Syntax : ($status, $response_hex_aref , $trace_start_addr_str ) = MANITOO_cmd_Start_SPI_Recording( $chip_selects_aref );

Manitoo Service Number :: 0xA1

Send: 0xA1 xxxxxxaa
Receive: 0xA1 05 bbbbbbbb

xxxxxx = not used
aa = Chip select (8 bits)   e.g. 14 -> "00010100"  ( Chip Select 2 + 4 are selected for trace ( starting from CS=0 at right side) )
bbbbbbbb = actual start address for SPI recording in Zynq RAM

Example:
ManiToo Send => A1 - 00 00 00 14 (hex)   
ManiToo Receive <= A1 05 20 02 39 20 (hex)

                     
Input arguments   : 
    $chip_selects_aref : array reference with Chip Select lines to be measured
                         each chip select must be in the range 0..7
      

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = [ 'A1' , '05' , 'AA' , 'BB' , 'CC' , 'DD'  ]
                            A1 -> Service number
                            05 -> number of bytes sent ( from original service) )
                            AABBCCDD -> U32 integer - start address of trace data in Manitoo
                        
    Return in Error   : $status = 0
                        $response_hex_aref = []

    Return Offline    : 1, []


Example :

    ($status, $response_hex_aref, $trace_start_addr_str) = MANITOO_cmd_Start_SPI_Recording( [ 2 , 4 ] );

    Return values : $status = 1;
                    $response_hex_aref = ['A1' , '05' , '20' , '02' , '39' , '20' ];
                    $trace_start_adress_str = "0x20023920"

=cut

sub MANITOO_cmd_Start_SPI_Recording {
    my @args = @_;
    return ( 0, [], [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_Start_SPI_Recording( $chip_selects_aref )', @args );
    my $chip_selects_aref = shift @args;

    my $trace_start_addr_str;    # return value

    my $service_number = "A1";

    my $checking_hash = {};
    my $cs_sum        = 0;
    foreach my $given_cs (@$chip_selects_aref) {
        S_w2log( 4, "MANITOO_cmd_Start_SPI_Recording : Processing given chip select  '$given_cs' .. \n", "grey" );
        if ( $checking_hash->{$given_cs} ) {
            S_set_error( "Chip select have been given multiple times in given argument" . join( " ", @$chip_selects_aref ) );
            return;
        }
        unless ( $given_cs =~ /^[0-7]$/ ) {
            S_set_error( "Chip select must be in the range 0..7 " . join( " ", @$chip_selects_aref ) );
            return;
        }
        $checking_hash->{$given_cs} = 1;
        $cs_sum += 2**$given_cs;    # add all 2 exp cs together  e.g. (2 exp 2) + (2 exp 4) = 4 + 16 = 20 dec => 14hex
    }
    S_w2log( 4, "MANITOO_cmd_Start_SPI_Recording : Calculated sum of given Chisp selects = $cs_sum \n", "grey" );

    my $command_string_hex = $service_number . "000000" . sprintf( "%02X", $cs_sum );

    unless ($mn2_initialised) {
        S_set_error( "Manitoo not initialised. Please call MANITOO_init\n", 120 );
        return ( 0, [], [] );
    }

    S_w2log( 4, "MANITOO_cmd_Start_SPI_Recording : Processing command '$command_string_hex' .. \n", "grey" );

    return ( 1, [], "0x00000000" ) if ($main::opt_offline);
    return ( 0, [], "0x00000000" ) unless Version_Check_SPI_trace();

    # Note : error in return values handled in MANITOO_cmd_Request_Response function
    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 6 } );
    return ( 0, [], "" ) unless ($status);

    my @response = @$response_hex_aref;
    shift @response;    # remove service number
    shift @response;    # remove length of request

    # cut 4 bytes from remaining response
    $trace_start_addr_str = "0x";
    $trace_start_addr_str .= join( "", splice( @response, 0, 4 ) );
    S_w2log( 4, " MANITOO_cmd_Start_SPI_Recording: extracted 4byte string as start address '$trace_start_addr_str'\n" );

    return ( $status, $response_hex_aref, $trace_start_addr_str );
}

=head2 MANITOO_cmd_Stop_SPI_Recording

    Syntax : ($status, $response_hex_aref , $trace_end_addr_str ) = MANITOO_cmd_Stop_SPI_Recording( );

    Manitoo Service Number :: 0xA2
    
    Send: 0xA2
    Receive: 0xA2 01 eeeeeeee
    
    eeeeeeee = actual end address of SPI recording in Zynq RAM

    Example:
    ManiToo Send => A2
    ManiToo Receive <= A2 01 24 42 3A C2 (hex)

    Remark: One SPI Record contains 32 bytes.
                   Number of recorded SPI messages = (actual end address - actual start address) / 32

                     
Input arguments   :   no 

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = [ 'A2' , '01' , 'AA' , 'BB' , 'CC' , 'DD'  ]
                            A2 -> Service number
                            01 -> number of bytes sent ( from original service) )
                            AABBCCDD -> U32 integer - end address of trace data in Manitoo
                        $trace_end_addr_str = "0xAABBCCDD"
                        
    Return in Error   : $status = 0
                        $response_hex_aref = []
                        $trace_end_addr_str = ""

    Return Offline    : 1, [] , "0x00000000"


Example :

    ($status, $response_hex_aref, $trace_end_addr_str) = MANITOO_cmd_Stop_SPI_Recording( );

    Return values : $status = 1;
                    $response_hex_aref = ['A2' , '01' , '20' , '02' , '39' , '20' ];
                    $trace_end_adress_str = "0x20023920"

=cut

sub MANITOO_cmd_Stop_SPI_Recording {
    my @args = @_;
    return ( 0, [], [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_Stop_SPI_Recording( )', @args );

    my $service_number = "A2";

    my $command_string_hex = $service_number;

    S_w2log( 4, "MANITOO_cmd_Stop_SPI_Recording : Processing command '$command_string_hex' .. \n", "grey" );

    return ( 1, [], "0x00000000" ) if ($main::opt_offline);

    # Note : error in return values handled in MANITOO_cmd_Request_Response function
    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 6, wait_time_ms => 300 } );
    return ( 0, [], "" ) unless ($status);

    my @response = @$response_hex_aref;
    shift @response;    # remove service number
    shift @response;    # remove length of request

    # cut 4 bytes from remaining response
    my $trace_end_addr_str = "0x";
    $trace_end_addr_str .= join( "", splice( @response, 0, 4 ) );
    S_w2log( 4, " MANITOO_cmd_Stop_SPI_Recording: extracted 4byte string as end address '$trace_end_addr_str'\n" );

    return ( $status, $response_hex_aref, $trace_end_addr_str );
}

=head2 MANITOO_cmd_Configure_SPI_Data_Size

    Syntax : ($status, $response_hex_aref , $trace_start_addr_str , $trace_end_addr_str ) 
               = MANITOO_cmd_Configure_SPI_Data_Size( $nbr_leading_samples , $nbr_follow_up_samples );

    Manitoo Service Number :: 0xA4
    
    Send: 0xA4 xxxxyyyy
    Receive: 0xA4 05 aaaaaaaa bbbbbbbb
    
        xxxx = number of frames before first manipulation
        yyyy = number of frames after last manipulation 
        
        aaaaaaaa = actual start address for SPI output data in Zynq RAM				 
        bbbbbbbb = actual end address for SPI output data in Zynq RAM
        
        Remark: if aaaa = 0xFFFF then use original SPI record start address 
                       if bbbb = 0xFFFF then use original SPI record end address

    Example 1:
     This example with leading 0 SPI frames and following 0 SPI frames 
      return the address of first SPI manipulation(00 11 22 33) 
                         and last SPI manipulation(00 99 88 77)  
    ManiToo Send => A4 00 00 00 00   ( from  ) 
    ManiToo Receive <= A4 05 00 11 22 33 99 88 77 66

    The following command A3 will start to return the data exactly from 1st to last manipulation
    
     
    Example 1 :
     This example with leading 0 SPI frames and following 0 SPI frames 
      return the address of first SPI manipulation(20 11 22 33) 
                         and last SPI manipulation(20 99 88 77)  
    ManiToo Send    => A4 00 00 00 00 
    ManiToo Receive <= A4 05 20 11 22 33 20 99 88 77

    ( total size of trace 0x886644 / 8.939.076 bytes => 279.346 SPI frames )
    
    The following command A3 will start to return the data exactly from 1st to last manipulation
    
     
    Example 2 : 
     This example with 
        leading   100 dec / 64 hex SPI frames (=> 3200 bytes) and 
        following 200 dec / C8 hex SPI frames (=> 6400 bytes)
      return the new begin address of SPI trace data (20 11 15 B3)  (100 frames before 1st manipulation)  
           and the new end address of SPI trace data (20 99 A1 77)  (200 frames after last manipulation) 
    ManiToo Send => A4 00 64 00 C8
    ManiToo Receive <= A4 05 00 11 15 B3 00 99 A1 77

    ( total size of trace 0x888BC4 / 8.948.676 bytes => 279.646 SPI frames ( 300 SPI frames larger than Example 1 ) )
    

    Remark: One SPI Record contains 32 bytes.
        Number of recorded SPI messages = (actual end address - actual start address) / 32

                     
Input arguments   :   
    $nbr_leading_samples   : integer - number of SPI samples BEFORE the FIRST manipulation
                                special values : 
                                $nbr_leading_samples =  0  --> the trace begin exactly from 1st manipulation sample  
                                $nbr_leading_samples = -1  --> the begin of trace will not be changed
                                max value 65534  (FFFE)
                                           
    $nbr_follow_up_samples : integer - number of SPI samples AFTER the LAST SPI manipulation
                                special values : 
                                $nbr_leading_samples =  0  --> the trace end exactly with last manipulation sample  
                                $nbr_leading_samples = -1  --> the end of trace will not be changed
                                max value 65534  (FFFE)
    
     

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = [ 'A4' , '05' , 'AA' , 'AA' , 'AA' , 'AA' , 'BB' , 'BB' , 'BB' , 'BB'  ]
                            A4 -> Service number
                            05 -> number of bytes sent ( from original service) )
                            AAAAAAAA -> U32 integer - new start address of trace data in Manitoo
                            BBBBBBBB -> U32 integer - new end address of trace data in Manitoo
                        $trace_start_addr_str = "0x201115B3"
                        $trace_end_addr_str   = "0x2099A177"
                        
    Return in Error   : $status = 0
                        $response_hex_aref = []
                        $trace_start_addr_str = ""
                        $trace_end_addr_str = ""

    Return Offline    : 1, [] , "0x00000000" , "0xFFFFFFFF"


Example :

  Example 1 - no leading and no follow-up samples
    ($status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str) 
        = MANITOO_cmd_Configure_SPI_Data_Size( 0 , 0 );   

    Return values : $status = 1;
                    $response_hex_aref = [ 'A4' , '05' , 
                                                        '20' , '11' , '22' , '33' , 
                                                        '20' , '99' , '88' , '77'  ]
                    $trace_start_addr_str = "0x20112233"
                    $trace_end_addr_str   = "0x20998877"


  Example 2 - 100 leading and 200 follow-up samples around the manipulation
    ($status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str) 
        = MANITOO_cmd_Configure_SPI_Data_Size( 100 , 200 );

    Return values : $status = 1;
                    $response_hex_aref = [ 'A4' , '05' , 
                                                        '20' , '11' , '15' , 'B3' , 
                                                        '20' , '99' , 'A1' , '77'  ]
                    $trace_start_addr_str = "0x201115B3"
                    $trace_end_addr_str   = "0x2099A177"

  Example 3 - only 200 follow-up samples around the manipulation (but no change of original start)
    ($status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str) 
        = MANITOO_cmd_Configure_SPI_Data_Size( -1 , 200 );

    Return values : $status = 1;
                    $response_hex_aref = [ 'A4' , '05' , 
                                                        '20' , '02' , '39' , '20' , 
                                                        '20' , '99' , 'A1' , '77'  ]
                    $trace_start_addr_str = "0x20023920"
                    $trace_end_addr_str   = "0x2099A177"

  Example 4 - re-configure trace internally to initially captured size 
    ($status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str) 
        = MANITOO_cmd_Configure_SPI_Data_Size( -1 , -1 );


=cut

sub MANITOO_cmd_Configure_SPI_Data_Size {
    my @args = @_;
    return ( 0, [], "", "" )
      unless S_checkFunctionArguments( 'MANITOO_cmd_Configure_SPI_Data_Size( $nbr_leading_samples , $nbr_follow_up_samples )', @args );

    my $nbr_leading_samples   = shift @args;
    my $nbr_follow_up_samples = shift @args;

    if ( $nbr_leading_samples > 65534 )   { S_set_error("Argument 'nbr_leading_samples' ($nbr_leading_samples) out of range (-1 ... 65534) ");     return; }
    if ( $nbr_leading_samples < -1 )      { S_set_error("Argument 'nbr_leading_samples' ($nbr_leading_samples) out of range (-1 ... 65534) ");     return; }
    if ( $nbr_follow_up_samples > 65534 ) { S_set_error("Argument 'nbr_follow_up_samples' ($nbr_follow_up_samples) out of range (-1 ... 65534) "); return; }
    if ( $nbr_follow_up_samples < -1 )    { S_set_error("Argument 'nbr_follow_up_samples' ($nbr_follow_up_samples) out of range (-1 ... 65534) "); return; }

    my $service_number     = "A4";
    my $command_string_hex = $service_number;

    if   ( $nbr_leading_samples == -1 ) { $command_string_hex .= "FFFF" }
    else                                { $command_string_hex .= sprintf( "%04X", $nbr_leading_samples ) }

    if   ( $nbr_follow_up_samples == -1 ) { $command_string_hex .= "FFFF" }
    else                                  { $command_string_hex .= sprintf( "%04X", $nbr_follow_up_samples ) }

    S_w2log( 4, "MANITOO_cmd_Configure_SPI_Data_Size : Processing command '$command_string_hex' .. \n", "grey" );

    return ( 1, [], "0x00000000", "0x00000000" ) if ($main::opt_offline);

    # Note : error in return values handled in MANITOO_cmd_Request_Response function
    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, wait_time_ms => 800 } );
    return ( 0, [], "", "" ) unless ($status);

    my @response = @$response_hex_aref;
    shift @response;    # remove service number
    shift @response;    # remove length of request

    my $trace_start_addr_str = "0x";

    # cut 4 bytes from remaining response
    $trace_start_addr_str .= join( "", splice( @response, 0, 4 ) );
    S_w2log( 4, " MANITOO_cmd_Configure_SPI_Data_Size: extracted 4byte string as start address '$trace_start_addr_str'\n" );

    my $trace_end_addr_str = "0x";

    # cut 4 bytes from remaining response
    $trace_end_addr_str .= join( "", splice( @response, 0, 4 ) );
    S_w2log( 4, " MANITOO_cmd_Configure_SPI_Data_Size: extracted 4byte string as end address '$trace_end_addr_str'\n" );

    return ( $status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str );
}

=head2 MANITOO_cmd_DYN_SPI_DATA_LOAD

  ($status, [response_string])  = MANITOO_cmd_DYN_SPI_DATA_LOAD ( $options_href );

This function loads the dynamic SPI data.

    
    
B<Arguments:>

=over

=item $options_href

$options_href = {
                 'spi_manipulation_module' => 0,
                 'spi_data' => '03040908784534'
                }

=back

B<Return Value:>

($status , $response_bytes_aref)

$status = 1 on success
          0 on failure
          
$response_bytes_aref = [0x54 xx aaaaaaaa ]

xx => Number of bytes in the request command

aaaaaaaa => number of stored SPI manipulation data in ManiToo PS RAM

B<Examples:>

(1, ['54', '08', '03'])MANITOO_cmd_DYN_SPI_DATA_LOAD(
                              {
                                'spi_manipulation_module' => 0,
                                'spi_data' => '030409087845'
                              }
                             );

=cut

sub MANITOO_cmd_DYN_SPI_DATA_LOAD {
    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_cmd_DYN_SPI_DATA_LOAD( $options_href )', @args );
    my $options_href = shift @args;
    my $manip_module = $options_href->{'spi_manipulation_module'};
    my $spi_data     = $options_href->{'spi_data'};

    my $service_id = '54';

    $dynamic_stimulation = 1;
    my $load_data            = [];
    my $complete_data_length = ( length $spi_data ) / 4;

    # load spi data in packets of size 255, if the data size length is more than 255
    if ( $complete_data_length > 255 ) {
        while ( $complete_data_length > 255 ) {
            my $loadSpiData = substr( $spi_data, 0, 1020 );
            push( @$load_data, $service_id . sprintf( "%.2X", $manip_module ) . 'FF' . $loadSpiData );
            substr( $spi_data, 0, 1020 ) = '';
            $complete_data_length = ( length $spi_data ) / 4;
        }
    }
    push( @$load_data, $service_id . sprintf( "%.2X", $manip_module ) . sprintf( "%.2X", ( length $spi_data ) / 4 ) . $spi_data );

    S_w2log( 3, "Loading Crash data to manitoo in progress ...  " );
    foreach my $cmdString (@$load_data) {
        return unless ( MANITOO_cmd_Request_Response($cmdString) );
        S_wait_ms(50);
    }

    return 1;
}

=head2 MANITOO_cmd_DYN_SPI_DATA_START

  ($status, [response_string])  = MANITOO_cmd_DYN_SPI_DATA_START ( $options_href );

This function loads SPI trigger data written by services 0x31, 0x32, 0x33 to FPGA and start the manipulation.
    
B<Arguments:>

=over

=item $options_href

$options_href = {
                 'waitime_us' => 499, # (default)
                 'mode' => 4, # 4 => timer mode (default), 2 = Real time mode
                }

=back

B<Return Value:>

($status , $response_bytes_aref)

$status = 1 on success
          0 on failure
          
$response_bytes_aref = [0x56 xx aaaaaaaa ]

xx => Number of bytes in the request command

aaaaaaaa => number of received SPI data (stored in arrays of PS system, 120.000 entries per channel)

B<Examples:>

(1, ['56', '05', '50']) = MANITOO_cmd_DYN_SPI_DATA_START(
                              {
                                'waitime_us' => 499, 
                                'mode' => 4, 
                              }
                             );

=cut

sub MANITOO_cmd_DYN_SPI_DATA_START {
    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_cmd_DYN_SPI_DATA_START( [,$options_href] )', @args );
    my $options_href       = shift @args;
    my $wait_time_us       = $options_href->{'waitime_us'} // 499;
    my $mode               = $options_href->{'mode'} // 4;
    my $service_id         = '56';
    my $request_cmd_string = $service_id . $mode . sprintf( "%.7X", $wait_time_us );

    S_w2log( 3, "SPI Dynamic stimulation Started " );
    return unless ( MANITOO_cmd_Request_Response($request_cmd_string) );
    return 1;
}

=head2 MANITOO_cmd_DYN_SPI_DATA_STATUS

  ($status, [response_string])  = MANITOO_cmd_DYN_SPI_DATA_STATUS ();

This function returns the number of SPI manipulation data in Manitoo PS RAM..
    
B<Arguments:>

None

=back

B<Return Value:>

($status , $response_bytes_aref)

$status = 1 on success
          0 on failure
          
$response_bytes_aref = [0x57 01 aaaaaaaa ]

xx => Number of bytes in the request command

aaaaaaaa => number of stored SPI manipulation data in ManiToo PS RAM.

If aaaaaaaa = number of stored SPI manipulation data in ManiToo PS RAM (return value from service 0x56), 
then the Dynamic SPI Manipulation is over.

B<Examples:>

(1, ['57', '01', '']) = MANITOO_cmd_DYN_SPI_DATA_STATUS();

=cut

sub MANITOO_cmd_DYN_SPI_DATA_STATUS {
    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_cmd_DYN_SPI_DATA_START()', @args );
    my $service_id = '57';
    return unless ( MANITOO_cmd_Request_Response($service_id) );
    return 1;
}

=head2 MANITOO_cmd_DYN_SPI_DATA_STOP

  ($status, [response_string])  = MANITOO_cmd_DYN_SPI_DATA_STOP ();

This service should be called after dynamic data manipulation is over.

If the service is called before the dynamic data manipulation is over, 

then the manipulation time will be shorter the expected.

B<Arguments:>

None

=back

B<Return Value:>

($status , $response_bytes_aref)

$status = 1 on success
          0 on failure
          
$response_bytes_aref = ['58' '01']

B<Examples:>

(1, ['58', '01']) = MANITOO_cmd_DYN_SPI_DATA_STOP();

=cut

sub MANITOO_cmd_DYN_SPI_DATA_STOP {
    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_cmd_DYN_SPI_DATA_STOP()', @args );
    my $service_id = '58';
    return unless ( MANITOO_cmd_Request_Response($service_id) );
    S_w2log( 3, "SPI Dynamic stimulation Stopped " );
    return 1;
}

=head2 MANITOO_cmd_Read_Recorded_SPI_Frames

    Syntax : ($status, $response_hex_aref , $nbr_of_data_bytes_int , $returned_data_bytes_href ) = MANITOO_cmd_Read_Recorded_SPI_Frames( [ , $nbr_messages_int ] );

    Manitoo Service Number :: 0xA3
    
    Send: 0xA3 aaaaaaaa
    Receive: 0xA3 05 bbbbbbbb byte_1 .. byte_x
    
    aaaaaaaa = number of SPI messages (32 bytes per SPI message)                 
    bbbbbbbb = number of bytes
    
    In order to read out all the recorded SPI data Service A3 has to be repeated until number of bytes is returned as zero. 
    (recommendation: read 20 - 30 SPI messages with one service)
    
    Remark:   1) By sending the Service 0xA2 again, the SPI data can be read out again.
              2) If number of SPI messages = 00 00 00 00, then all recorded SPI data are read at once.
                 (for use with HTerm: can be executed many times and will always return all data)

                     
Input arguments   :   $nbr_messages_int -> integer , nbr of SPI messages to be read 
                      use 10 messages if argument is not given 

Return Values :

    Return in Success : $status = 1
                        $response_hex_aref = [ 'A2' , '05' , 'AA' , 'BB' , 'CC' , 'DD' ,   'EE' , 'EE' , 'EE' , EE' ...... 'EE' ]
                            A3 -> Service number
                            05 -> number of bytes sent ( from original service) )
                            AABBCCDD -> U32 integer - total nbr of read bytes coming followed
                            EE .. EE -> nbr all data bytes ( 32bytes per each SPI frame ) 
                        
                        $nbr_of_data_bytes_int : nbr of total received data bytes
                            
                        $returned_data_bytes_href = { 
                                                     '1' => [ '01' , '02' , '03' , '04' , ... , '32' ] ,                            
                                                     '2' => [ '01' , '02' , '03' , '04' , ... , '32' ] ,
                                                     ...
                                                     'nbr_of_messages' => [ ] ,                            
                                                     }
                        
    Return in Error   : $status = 0
                        $response_hex_aref = [ received bytes ]
                        $nbr_of_data_bytes_int = undef
                        $returned_data_bytes_href = {}

    Return Offline    : 1, [] , 0 , {}


Example :

    ($status, $response_hex_aref, $nbr_of_data_bytes_int , $returned_data_bytes_href ) = MANITOO_cmd_Read_Recorded_SPI_Frames( 10 );

    reading 10 SPI Frame samples ( MOSI/MISO + Timestamp )

    Return values : $status = 1;
                    $response_hex_aref = [ 'A2' , '05' , 'AA' , 'BB' , 'CC' , 'DD' , 'EE' , 'EE' , 'EE' , EE' ...... 'EE' ] ;
                    $nbr_of_data_bytes_int = 320   ( 32bytes  * 10 requested SPI Frames )
                    $returned_data_bytes_href = {  see data structure above described in return values  }

=cut

sub MANITOO_cmd_Read_Recorded_SPI_Frames {
    my @args = @_;
    return ( 0, [], [] ) unless S_checkFunctionArguments( 'MANITOO_cmd_Read_Recorded_SPI_Frames( [, $nbr_messages_int ] )', @args );
    my $nbr_messages_int = shift @args;

    unless ( defined $nbr_messages_int ) {
        $nbr_messages_int = 20;
    }

    my $max_possible_SPI_frames = int( $SERIAL_PORT_MAX_READ_BYTES / $SPI_TRACE_STORED_BYTES_PER_FRAME );

    if ( $nbr_messages_int > $max_possible_SPI_frames ) {
        S_set_error("Max nbr of SPI frames to read is $max_possible_SPI_frames  ( limit exceed with $nbr_messages_int");
        return ( 0, [], undef, {} );
    }

    my $service_number = "A3";

    my $returned_data_bytes_href = {};

    my $options_href = {
        check_response => 1,
        wait_time_ms   => int( $nbr_messages_int * 5 ),    # 5ms per 1 SPI frame (32 Byte)
        less_print_out => 1
    };

    my $hex_value_4byte = sprintf( "%08X", $nbr_messages_int );
    my $command_string_hex = $service_number . $hex_value_4byte;

    return ( 1, [], 0, {} ) if ($main::opt_offline);

    # Note : error in return values handled in MANITOO_cmd_Request_Response function
    my ( $status, $response_hex_aref ) = MANITOO_cmd_Request_Response( $command_string_hex, $options_href );
    return ( 0, $response_hex_aref, undef, {} ) unless ($status);

    my @response = @$response_hex_aref;
    shift @response;    # remove service number
    shift @response;    # remove length of request

    # cut 4 bytes from remaining response
    my $nbr_of_data_bytes_int = hex( join( "", splice( @response, 0, 4 ) ) );

    my $remaining_bytes_in_response = scalar @response;

    unless ( $remaining_bytes_in_response == $nbr_of_data_bytes_int ) {
        S_set_error("The nbr of data bytes in command response does not fit to indicated number of bytes in the response ( $remaining_bytes_in_response != $nbr_of_data_bytes_int ) \n");
        return ( 0, $response_hex_aref, undef, {} );
    }

    # after command and length nbr of bytes shall be dividable by 4
    if ( $remaining_bytes_in_response % $SPI_TRACE_STORED_BYTES_PER_FRAME ) {
        S_set_error("Unexpected nbr of bytes in Response $remaining_bytes_in_response / should be possible to divide by 32  ( bytes per each SPI Frame ) ");
        return ( 0, $response_hex_aref, undef, {} );
    }

    my $SPI_frame_sample_counter = 0;

    # cut always 32 bytes from remaining response
    while (@response) {
        my @SPI_frame_sample = splice( @response, 0, $SPI_TRACE_STORED_BYTES_PER_FRAME );
        $SPI_frame_sample_counter++;
        push( @{ $returned_data_bytes_href->{$SPI_frame_sample_counter} }, hex($_) ) foreach @SPI_frame_sample;
    }

    return ( $status, $response_hex_aref, $nbr_of_data_bytes_int, $returned_data_bytes_href );
}

=head2 MANITOO_cmd_IO_ExtensionPort

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_IO_ExtensionPort ($io_Extension_Port_int );

This function defines the usage of the IO Extension Port.

Manitoo Service Number    : 0xFA

Input arguments           :

    $io_Extension_Port_int  = 0 (integer) : output ports can be activated via Service 0xF1.
                              1 (integer) : output ports are used for internal debugging.


Return Values  :

    Return values in Success  : $status = 1;
                                $response_hex_aref = ['FA' , '05'];
                                FA -> Service number
                                05 -> number of bytes sent.

    Return values in error    : $status = 0;
                                $response_hex_aref = [];

    Return Offline            : 1, []

Example1(Success)         :

    ($status , $response_hex_aref ) = MANITOO_cmd_IO_ExtensionPort(1);

    Input arguments       : $io_Extension_Port_int = 1

    Return Values         : $status = 1;
                            $response_hex_aref = ['FA' , '05'];

Example2(Error)           :

    ($status , $response_hex_aref ) = MANITOO_cmd_IO_ExtensionPort(3);

    Input arguments       : $io_Extension_Port_int = 3

    Return Values         : $status = 0;
                            $response_hex_aref = [];

=cut

sub MANITOO_cmd_IO_ExtensionPort {

    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'MANITOO_cmd_IO_ExtensionPort ( $io_Extension_Port_int)', @args );

    my $service_number = "FA";    #command number

    my $command_string_hex    = undef;
    my $io_Extension_Port_int = shift;

    unless ( $io_Extension_Port_int == 0 or $io_Extension_Port_int == 1 ) {
        S_set_error( "MANITOO_cmd_IO_ExtensionPort : IO extension port value '$io_Extension_Port_int' is wrong, should be either 0 or 1(integer value)\n", 109 );
        return ( 0, [] );
    }
    my $dont_care = 0 x 7;        # seven don't care bits

    $command_string_hex = $service_number . $dont_care . $io_Extension_Port_int;

    S_w2log( 4, "MANITOO_cmd_IO_ExtensionPort: Processing command $service_number ..\n", "grey" );
    S_w2log( 4, " MANITOO_cmd_IO_ExtensionPort: (arg1)output port setting selected = $io_Extension_Port_int\n", "grey" );

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head2 MANITOO_cmd_ExternalTrigger_X8

    Syntax : ($status, $response_hex_aref) = MANITOO_cmd_ExternalTrigger_X8($power_on_off_int);

Switch on and off of the external trigger out signal on X8, i.e. 3.3V or 0V

Manitoo Service Number      :  0xF5

Input arguments             :  $power_on_off_int = 1 for power on, 0 for power off (integer)

Return Values :

    Return in Success           :  $status = 1, $response_hex_aref = [F5 05]
                                    F5 -> service number
                                    05 -> number of bytes sent

    Return in Error             :  $status = 0, $response_hex_aref = []

    Return Offline              :  1, []

Example1(Success) :

    ($status , $response_hex_aref ) = MANITOO_cmd_ExternalTrigger_X8('1');

    Input arguments             :  $power_on_off_int  = 1

    Return Values               :  $status = 1;
                                   $response_hex_aref = [F5 05];

Example2(Error) :

    ($status , $response_hex_aref ) = MANITOO_cmd_ExternalTrigger_X8('3');

    Input arguments             :  $power_on_off_int  = 1

    Return Values               :  $status = 0;
                                   $response_hex_aref = [];

=cut

sub MANITOO_cmd_ExternalTrigger_X8 {
    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'MANITOO_cmd_ExternalTrigger_X8 ( $power_on_off_int )', @args );

    my $power_on_off_int = shift;    #value of power on/power off bit
    my $service_number   = "F5";     #command number
    my $donot_care_bit_x8;
    $donot_care_bit_x8 = $donot_care_bit_x8 x 7;

    my $command_string_hex = undef;

    if ( $power_on_off_int < 0 or $power_on_off_int > 1 ) {
        S_set_error( "MANITOO_cmd_ExternalTrigger_X8 : The power on/off value '$power_on_off_int' is out of range, should be either 1 or 0(integer value)\n", 109 );
        return ( 0, [] );
    }

    $command_string_hex = $service_number . $donot_care_bit_x8 . $power_on_off_int;

    S_w2log( 4, "MANITOO_cmd_ExternalTrigger_X8: Processing command $service_number ..\n",             "grey" );
    S_w2log( 4, " MANITOO_cmd_ExternalTrigger_X8: (arg1)Switch status selected = $power_on_off_int\n", "grey" );

    return MANITOO_cmd_Request_Response( $command_string_hex, { check_response => 1, nbr_bytes_exp => 2 } );
}

=head1 MANITOO trace functions

=head2 MANITOO_trace_start

    $result = MANITOO_trace_start( $nodes_spi_cs_aref );

B<Argument> 

    $nodes_spi_cs_aref : array reference with tuples of [ SPI:CS , SPI:CS , .. ] 
     
        SPI -> SPI bus nbr to trace ( currently only SPI bus nbr 1 is supported)
        CS  -> CS of SPI device to trace 

Starts tracing of the SPI MOSI and MISO instructions.

Manitoo command for trace: 'A1'.

B<Return>
    $result              -> 1 - success ( trace started or was already stopped before ) 
                         -> 0 - error

B<Examples:>

    $result = MANITOO_trace_start( [ '1:0' , '1:1' , '1:2' ] );

=cut

sub MANITOO_trace_start {

    my @args = @_;
    unless ( S_checkFunctionArguments( 'MANITOO_trace_start ( $nodes_spi_cs_aref )', @args ) ) { return ( 0, undef ) }
    my $nodes_spi_cs_aref = shift;

    if ( MANITOO_trace_check_running() ) {
        S_w2log( 2, " MANITOO_trace_start : Trace has been started already before , start command will not executed again - return 1" );
        return 1;
    }

    my $chip_selects_aref = [];

    foreach my $spi_cs_element (@$nodes_spi_cs_aref) {
        unless ( $spi_cs_element =~ /^(\d+):(\d+)$/ ) {
            S_set_error("Given argument '$spi_cs_element' does not match with defined Syntax [ SPI:CS , SPI:CS ,  ... ]  ");
            return ( 0, undef );
        }
        my $spi_nbr = $1;
        my $cs      = $2;

        unless ( $spi_nbr == 1 ) {
            S_set_error("Currently only SPI bus nbr 1 is supported  (given argument was '$spi_cs_element' ) [ SPI:CS , SPI:CS ,  ... ]  ");
            return ( 0, undef );
        }

        push( @$chip_selects_aref, $cs );
    }

    unless ( scalar @$chip_selects_aref ) {
        S_set_error("Given parameter '@$nodes_spi_cs_aref' doesnt contain valid SPI + CS info for trace");
        return ( 0, undef );
    }

    my ( $status, $response_hex_aref, $trace_start_addr_str ) = MANITOO_cmd_Start_SPI_Recording($chip_selects_aref);

    unless ($status) { return 0 }

    $global_SPI_trace_running           = 1;
    $global_SPI_trace_start_addr        = $trace_start_addr_str;
    $global_SPI_trace_end_addr          = "";
    $global_SPI_trace_store_size_bytes  = 0;
    $global_SPI_manip_region_start_addr = "";
    $global_SPI_manip_region_end_addr   = "";
    $global_SPI_manip_region_size_bytes = 0;

    S_w2log( 3, " MANITOO_trace_start : SPI Recording is started now \n" );

    return 1;
}

=head2 MANITOO_trace_stop

    $traceStatusSize = MANITOO_trace_stop();

Stops tracing of the SPI instructions.

Manitoo command for trace: 'A2'.

B<Return>

   $traceStatusSize     -> integer of total trace size in bytes ( > 0 : success ) 
                        -> 0 - error ( even when trace was not started before )

B<Examples:>

=cut

sub MANITOO_trace_stop {

    unless ( MANITOO_trace_check_running() ) {
        S_set_error("Trace has not been started before , stop command will not executed\n");
        return;
    }

    my ( $status, $response_hex_aref, $trace_manip_start_addr_str, $trace_manip_end_addr_str, $trace_end_addr_str );

    # error handling in MANITOO_cmd_Stop_SPI_Recording
    ( $status, $response_hex_aref, $trace_end_addr_str ) = MANITOO_cmd_Stop_SPI_Recording();
    unless ($status) { return 0 }

    S_w2log( 2, " MANITOO_trace_stop: Trace stopped \n", 'grey' );
    $global_SPI_trace_running = 0;

    $global_SPI_trace_end_addr         = $trace_end_addr_str;
    $global_SPI_trace_store_size_bytes = hex($global_SPI_trace_end_addr) - hex($global_SPI_trace_start_addr);
    my $total_trace_size_kbyte = int( $global_SPI_trace_store_size_bytes / 1000 );

    S_w2log( 4, " MANITOO_trace_stop: Captured addr range : [ $global_SPI_trace_start_addr .. $global_SPI_trace_end_addr ]\n",             'grey' );
    S_w2log( 2, " MANITOO_trace_stop: Captured trace size : $total_trace_size_kbyte kByte ( $global_SPI_trace_store_size_bytes bytes )\n", 'grey' );

    ( $status, $response_hex_aref, $trace_manip_start_addr_str, $trace_manip_end_addr_str ) = MANITOO_cmd_Configure_SPI_Data_Size( 0, 0 );
    unless ($status) { return 0 }

    my $manip_region_size_bytes = hex($trace_manip_end_addr_str) - hex($trace_manip_start_addr_str);

    if ( $global_SPI_trace_store_size_bytes > $manip_region_size_bytes ) {
        #
        # re-sizing service A4 detected manipulated regions and returned address of 1st and last manipulation
        #
        my $total_manip_trace_size_kbyte = int( $manip_region_size_bytes / 1000 );
        S_w2log( 4, " MANITOO_trace_stop: Manipulation region addr : [ $trace_manip_start_addr_str  ..  $trace_manip_end_addr_str ]\n",          'grey' );
        S_w2log( 2, " MANITOO_trace_stop: Manipulation region size : $total_manip_trace_size_kbyte kByte ( $manip_region_size_bytes bytes ) \n", 'grey' );
        $global_SPI_manip_region_start_addr = $trace_manip_start_addr_str;
        $global_SPI_manip_region_end_addr   = $trace_manip_end_addr_str;
        $global_SPI_manip_region_size_bytes = $manip_region_size_bytes;
    }
    else {
        #
        # when re-sizing service did not find manipulation there will be no manip region data stored in $global_SPI_manip_region...
        #
        S_w2log( 4, " MANITOO_trace_stop: (no manipulated SPI regions in trace - internal trace size cannot be adapted)\n", 'grey' );
    }

    return $global_SPI_trace_store_size_bytes;

}

=head2 MANITOO_trace_check_running

    $result  = MANITOO_trace_check_running(  );

B<Argument> no 


Checking whether trace has been started before with MANITOO_trace_start ( )via internal variable )
No command sent to Manitoo

Function is used mainly from MANITOO_trace_start , MANITOO_trace_stop , MANITOO_trace_store internally

B<Return>
    $status              -> 1 - trace is running 
                         -> 0 - trace is not running

B<Examples:>

    $result = MANITOO_trace_check_running(  );

=cut

sub MANITOO_trace_check_running {

    if ($global_SPI_trace_running) {
        S_w2log( 4, "MANITOO_trace_check_running: -> RUNNING" );
        return 1;
    }
    else {
        S_w2log( 4, "MANITOO_trace_check_running: -> NOT RUNNING" );
        return 0;
    }

}

=head2 MANITOO_trace_store

      $return_traceFileNamePath = MANITOO_trace_store( [ $traceFileName , $nbr_leading_spi_frames , $nbr_follow_spi_frames ] );

    Trace data will be read from Manitoo into $traceFileName  (*.mbt) 
     ( Note: mbt - Mobi Trace file format )
    If default file name shall be generated and the trace size shall be adapted with following options use filename 'USE_DEFAULT'
    
     Max. Tracefile size is limited to 100 MB  
      ( => 3.125 Mio SPI frames with each 32bytes storage size for MOSI,MISO,Timestamp )

$nbr_leading_spi_frames

  (optional) integer nbr of leading (before manipulated region) SPI frames for SPI trace size reduction 
  ( default is 1000 leading frames )

$nbr_follow_spi_frames

  (optional) integer nbr of following (after manipulated region) SPI frames for SPI trace size reduction 
  ( default is 2000 following frames )


B<Return>

    $return_traceFileNamePath : complete <path>/<filename>   of trace file

    error : when Path of given traceFileName doesnt exists
    

B<Examples:>

    Trace file can be stored in two ways:
    
        1. No Filename $traceFileName is given
        
           use default report path and following filename :
           <STANDARD_REPORT_PATH> / Manitoo_SPI_trace_raw__<data_time_extension>.mbt  
        
        2. Only file name passed as argument
           trace file will be stored in the reports folder with given name.
        
            <STANDARD_REPORT_PATH> / <given traceFilename>.mbt
    
           MANITOO_trace_store( 'MANITOO_TRACE' )
    
        3. Complete file path configured as argument
           trace file will be stored in the path given and with the filename given
    
           MANITOO_trace_store( 'D:/Turbolift/TSG4/trace/MANITOO_TRACE.mbt' )

        4. Default trace storage in report folder , 
           trace_resizing with 
           5000 leading SPI frames and 
           7000 following SPI frames
        
           MANITOO_trace_store( 'USE_DEFAULT' , 5000 , 7000 )
        

=cut

sub MANITOO_trace_store {
    my @args = @_;
    return unless S_checkFunctionArguments( 'MANITOO_trace_store( [ $traceFileName , $nbr_leading_spi_frames , $nbr_follow_spi_frames ] )', @args );
    my $traceFileName          = shift @args;
    my $nbr_leading_spi_frames = shift @args;
    my $nbr_follow_spi_frames  = shift @args;

    $nbr_leading_spi_frames //= $SPI_MANIP_REGION_DEFAULT_LEADING_FRAMES;    # us standard leading number if not given as arg
    $nbr_follow_spi_frames  //= $SPI_MANIP_REGION_DEFAULT_FOLLOW_FRAMES;     # us standard follow number if not given as arg

    my $tracePathName;

    if ( not defined $traceFileName or $traceFileName eq 'USE_DEFAULT' ) {
        $traceFileName = "Manitoo_SPI_trace_raw";
        $tracePathName = $main::REPORT_PATH;
        $traceFileName = $tracePathName . "/" . $traceFileName . "__" . S_get_date_extension() . ".mbt";
    }

    if ( basename($traceFileName) eq $traceFileName ) {
        $tracePathName = $main::REPORT_PATH;
        S_w2log( 4, "MANITOO_trace_store : No storage path defined - set to default: $tracePathName ( Report Path )\n", 'grey' );
        $traceFileName =~ s/\.mbt$//;    # remove the extension *.mbt temporarly
        $traceFileName = $tracePathName . "/" . $traceFileName . ".mbt";
    }

    $tracePathName = dirname($traceFileName);
    unless ( -d $tracePathName ) {
        S_set_error("Path of given traceFilename '$traceFileName' doesnt exist !");
        return;
    }

    my $trace_storing_size_bytes = $global_SPI_trace_store_size_bytes;    # initialize with original trace size

    my ( $status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str );
    if ( $global_SPI_manip_region_size_bytes > 0 ) {
        S_w2log( 4, "MANITOO_trace_store : Manipulation region detected -> trace download size will be reduced \n", 'grey' );
        ( $status, $response_hex_aref, $trace_start_addr_str, $trace_end_addr_str ) = MANITOO_cmd_Configure_SPI_Data_Size( $nbr_leading_spi_frames, $nbr_follow_spi_frames );
        return unless $status;
        $trace_storing_size_bytes = hex($trace_end_addr_str) - hex($trace_start_addr_str);
        my $trace_size_reduction_percent = int( ( $trace_storing_size_bytes / $global_SPI_trace_store_size_bytes ) * 100 );
        S_w2log( 3, "MANITOO_trace_store : Trace size reduction on device [bytes] : $global_SPI_trace_store_size_bytes (100 %) ... -> $trace_storing_size_bytes ($trace_size_reduction_percent %) \n", 'grey' );
        S_w2log( 4, "MANITOO_trace_store : Old range [ $global_SPI_trace_start_addr ...-> $global_SPI_trace_end_addr ]\n" );
        S_w2log( 4, "MANITOO_trace_store : New range [ $global_SPI_manip_region_start_addr ...-> $global_SPI_manip_region_end_addr ]\n" );
    }

    my $total_trace_size_kbyte        = int( $trace_storing_size_bytes / 1000 );
    my $total_nbr_SPI_frames_to_store = $trace_storing_size_bytes / $SPI_TRACE_STORED_BYTES_PER_FRAME;
    S_w2log( 2, "MANITOO_trace_store : Start writing $total_trace_size_kbyte kBytes SPI trace to '$traceFileName' ( $total_nbr_SPI_frames_to_store SPI Frames ) \n", 'grey' );

    my $MBT_FILE;
    unless ( open( $MBT_FILE, '>:raw', $traceFileName ) ) {
        S_set_error("Could not open trace file for writing ('$traceFileName')");
        return;
    }

    my $nbr_messages_to_read_int = 125;

    my $max_data_bytes_to_read_total = 1E8;    #  trace limited to 100 MByte;

    my $last_percentage_printed = 0;

    my $sum_nbr_of_read_data             = 0;
    my $total_nbr_read_SPI_frame_samples = 0;
    my ( $nbr_of_data_bytes_int, $returned_data_bytes_href );
    S_set_timer_zero('Trace_Download');
    while ( $max_data_bytes_to_read_total > $sum_nbr_of_read_data ) {

        ( $status, $response_hex_aref, $nbr_of_data_bytes_int, $returned_data_bytes_href ) = MANITOO_cmd_Read_Recorded_SPI_Frames($nbr_messages_to_read_int);
        last unless ($status);                 #  jump out while loop when error

        unless ($nbr_of_data_bytes_int) {
            S_w2log( 4, " MANITOO_trace_store: no more data are following --- complete trace is read --- (total $sum_nbr_of_read_data data bytes) \n", 'grey' );
            last;                              #  jump out while loop when no more data
        }

        $sum_nbr_of_read_data += $nbr_of_data_bytes_int;    # summarize total nbr of read bytes

        foreach my $SPI_frame_sample_nbr ( 1 .. $nbr_messages_to_read_int ) {
            last unless defined $returned_data_bytes_href->{$SPI_frame_sample_nbr};    #  jump out printing when no more SPI Frame samples are returned ( less than $nbr_messages_to_read_int)

            #
            # WORKAROUND BEGIN
            #
            if ( $total_nbr_read_SPI_frame_samples == 0 ) {
                S_w2log( 4, " MANITOO_trace_store: Workaround implemented - skip the (only) the 1st SPI data sample\n", 'orange' );
                $total_nbr_read_SPI_frame_samples++;
                next;
            }

            #
            # WORKAROUND END
            #

            print $MBT_FILE pack( 'C*', @{ $returned_data_bytes_href->{$SPI_frame_sample_nbr} } );
            $total_nbr_read_SPI_frame_samples++;
        }

        my $percentage_done = int( ( $total_nbr_read_SPI_frame_samples / $total_nbr_SPI_frames_to_store ) * 100 );

        if ( ( $percentage_done - $last_percentage_printed ) > 5 ) {
            my $download_time_ms  = S_read_timer_ms('Trace_Download');
            my $download_time_sec = int( $download_time_ms / 1000 );
            S_w2log( 4, " MANITOO_trace_store : Downloading since $download_time_sec sec \n" );

            my $total_time_sec = int( ( $download_time_sec / $total_nbr_read_SPI_frame_samples ) * $total_nbr_SPI_frames_to_store );

            my $remaining_time_sec = $total_time_sec - $download_time_sec;
            my $remaining_time_min = int( ( $remaining_time_sec + 29 ) / 60 );

            my $time_remaining_text = "";
            $time_remaining_text = "time remaining $remaining_time_sec sec  (appr. $remaining_time_min min)" if $remaining_time_min;
            $time_remaining_text = "time remaining $remaining_time_sec sec" unless $remaining_time_min;
            S_w2log( TEXT | CONSOLE, " MANITOO_trace_store: Stored total $total_nbr_read_SPI_frame_samples (from $total_nbr_SPI_frames_to_store) SPI Frames ( $percentage_done % )  ... $time_remaining_text  \n" );
            $last_percentage_printed = $percentage_done;
        }
    }

    my $total_download_time_sec = int( S_read_timer_ms('Trace_Download') / 1000 );
    my $total_download_time_min = int( ( $total_download_time_sec + 29 ) / 60 );

    my $time_total_text = "";
    $time_total_text = "$total_download_time_sec sec  (appr. $total_download_time_min min)" if $total_download_time_min;
    $time_total_text = "$total_download_time_sec sec" unless $total_download_time_min;

    S_w2log( 2, " MANITOO_trace_store: File storing finished with --> $total_nbr_read_SPI_frame_samples <-- SPI Frame samples ($sum_nbr_of_read_data bytes) Filename : $traceFileName \n", 'grey' );
    S_w2log( 2, " MANITOO_trace_store: Duration of Download => $time_total_text  \n", 'grey' );

    unless ( close($MBT_FILE) ) {
        S_set_error("Error while closing SPI trace file '$traceFileName'");
        return;
    }

    return $traceFileName;
}

=head2 MANITOO_trace_load_file

   $measurementXML_mix = MANITOO_trace_load_file( $traceFilePath, 
                                                  $measurementLabel,
                                                  $firstTimeStampIsZero,
                                                  $measurementXML_mix
                                                );

This function loads the trace file stored.
Call 'MANITOO_trace_store' before calling this function.

In mobi format , each MOBI frame contains 64 bit data only,
if the SPI data is more than 64 bits then mobi frame data is concatenated and
converted into one SPI frame, by making use of toggle bit in MOBI frame.

B<Arguments:>

=over

=item $traceFilePath

Trace file can be loaded in two ways:

    1. Only file name passed as argument.
       trace file will be loaded from reports folder with given name.

    2. Complete file path configured as argument
       trace file will be loaded from path given.

=item $measurementLabel

Measurement label for the trace.

=item $firstTimeStampIsZero

Parameter to start Time stamp to start from 0

=item $measurementXML_mix

XML handle to write trace data to to xml file.

=back

B<Return>

=over

=item $measurementXML_mix 

XML handle with measurement data points added.

=back

B<Example:>

$measurementXML_mix = MANITOO_trace_load_file ("C:\Turbolift\AB12\reports\TL_SPI_Measurement_20171011_145923",
                                               'SPI_Measurement_1',
                                                0,
                                                $measurementXML_mix
                                              );

B<Note:>

To be called by functional layer function 'SPI_trace_load_file'.

=cut

sub MANITOO_trace_load_file {
    my @args = @_;

    my $traceFilePath        = shift @args;
    my $measurementLabel     = shift @args;
    my $firstTimeStampIsZero = shift @args;
    my $measurementXML_mix   = shift @args;

    return unless S_checkFunctionArguments( 'MANITOO_trace_load_file( $traceFilePath, $measurementLabel, $firstTimeStampIsZero, $measurementXML_mix )', ( $traceFilePath, $measurementLabel, $firstTimeStampIsZero, $measurementXML_mix ) );

    #IF is valid arguments?
    #IF-NO-START
    #STEP Error in configuring parameters
    #IF-NO-END

    #IF-YES-START
    #STEP convert the binary file to text file containing hex frames

    # if only file name is given
    if ( $traceFilePath !~ /:|\/|\\/ ) {
        $traceFilePath = $main::REPORT_PATH . '/' . $traceFilePath;
    }

    unless ( -e $traceFilePath ) {
        S_set_error("TraceFile '$traceFilePath' doesnt exists");
        return;
    }

    S_w2log( 4, " MANITOO_trace_load_file: read '$traceFilePath' (read of meas Label '$measurementLabel') \n", 'grey' );

    my $LIFT_temp_path = $LIFT_general::LIFT_TEMP_PATH;
    my $spiTempPath    = $LIFT_temp_path . "\\SPI_Temp";
    unless ( -e $spiTempPath ) {
        unless ( mkpath($spiTempPath) ) { S_set_error(" Error while  mkpath($spiTempPath) "); return }
    }

    S_w2log( 3, "MANITOO_trace_load_file: convert from binary to hex.txt\n" );

    unless ( open( BINFILE, "<:raw", $traceFilePath ) ) { S_set_error("Can't open $traceFilePath: $!"); return; }

    my $measurement_text_file = $spiTempPath . "\\" . $measurementLabel . "_Hex.txt";
    unless ( open( OUT, ">", $measurement_text_file ) ) {
        S_set_error("Opening $measurement_text_file : $!");
        return;
    }

    my $valueRead;

    while ( sysread( BINFILE, $valueRead, $LOG_FILE_BYTES_PER_FRAME ) ) {
        print( OUT unpack( "H*", $valueRead ), "\n" );
    }

    unless ( close(BINFILE) ) { S_set_error("Can't close $traceFilePath: $!");        return }
    unless ( close(OUT) )     { S_set_error("Can't close $measurement_text_file $!"); return }

    S_w2log( 3, "MANITOO_trace_load_file: Conversion done ( mbt -> $measurement_text_file )\n" );

    S_w2log( 3, "MANITOO_trace_load_file: split raw data into MessageNumber/Time/MOSI_Hex/MISO_Hex/ChipSelect/FrameLength_Bits/Tools_ID/FrameManipulated\n" );

    my $lineNumber     = 0;
    my $timeZeroOffset = 0;

    my ( $fh, $err_text );
    unless ( open( $fh, '<', $measurement_text_file ) ) {
        $err_text = $!;
    }
    if ($err_text) {
        S_set_error("Opening $measurement_text_file: $!");
        return;
    }

    my @file_content = <$fh>;
    close $fh;

    #CALL Parse_SPI_Trace_Line
    #IF-YES-END
    $measurementXML_mix = Parse_SPI_Trace_Lines( [@file_content], $measurementXML_mix );

    #STEP return xml handle updated with xml measurement data points.
    #STEP END

    return $measurementXML_mix;
}

=head1 MANITOO PAS functions

=head2 MANITOO_PAS_IO_Expansion

    Syntax : MANITOO_PAS_IO_Expansion ( )

This function activates the ports for PAS commands.
    
B<Arguments:>

No arguments

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_IO_Expansion ( )

=cut

sub MANITOO_PAS_IO_Expansion {

    my $io_service_hex = '2A';
    my $io_val_hex     = '02';
    my $cmd_string     = 0 x 6;

    #STEP prepare command string 2A00000002 to activate PAS IO in manitoo
    my $io_cmd_hex = $io_service_hex . $cmd_string . $io_val_hex;

    #CALL MANITOO_cmd_Request_Response
    my ( $status, $return_data_aref ) = MANITOO_cmd_Request_Response( $io_cmd_hex, { check_response => 1 } );

    #IF Is (status == 0) or (status == undef)
    unless ($status) {

        #IF-YES-START
        #STEP Error writing command to manitoo not successful
        #STEP return undef
        S_set_error( "MANITOO_PAS_IO_Expansion: writing command to ManiToo not successful!, check input parameters!\n", 23 );
        return;

        #IF-YES-END
    }

    #IF-NO-START
    #STEP Writing command to manitoo successfull
    #STEP return 1
    #IF-NO-END
    S_w2log( 4, "MANITOO_PAS_IO_Expansion: PAS IO expansion port set successfully \n", "grey" );

    #STEP END
    return 1;
}

=head2 MANITOO_PAS_cmd_configure_register

    Syntax : MANITOO_PAS_cmd_configure_register ( $service_id, $pas_line_or_module, $address_hex [, $data_aref] )

This function configures the PAS sensor registers.

B<Arguments:>

=over

=item $service_id

    Range: 'B0' - For PAS lines.
           'B1' - For PAS modules.
           'B2' - For PAS data area.

=item $pas_line_or_module

In case of lines:

12 PAS lines are supported. ( configured for PAS service B0 )

    Range: '01' - '0C' ( hex ).

In case of modules:
    
16 PAS modules are supported ( configured for PAS service B1 and B2 )

    Range: '01' - '10' ( hex ).

=item $address_hex

16 bit address range. ( All values in hex )

=item $data_aref

Data to be sent to register in hex format.

For Service B0: 

    0xB0nnaabbbbcc 32BitData[32BitData]
    
    nn = PAS Line ('01' � '0C') hex
    aa = Write/Read  Write  = '01', Read = '00' hex
    bbbb = Address relative to 32BitData_1
    cc = Number of 32BitData

    4ByteData_0 = StatusWrite
    4ByteData_1 = Time1    (timing for timeslot 1)
    4ByteData_2 = Time2    (timing for timeslot 2)
    4ByteData_3 = Time3    (timing for timeslot 3)
    4ByteData_4 = Time4    (timing for timeslot 4)
    4ByteData_5 = AutoRestart
    4ByteData_6 = HalfBitTime
    4ByteData_7 = TransmitData1_NumberOfBits
    4ByteData_8 = TransmitData2_NumberOfBits
    4ByteData_9 = TransmitData3_NumberOfBits
    4ByteData_10 = TransmitData4_NumberOfBits
    4ByteData_11 = DACs: I_quiescent and I_transmit
    4ByteData_12 = StatusRead
    4ByteData_13 = RuntimeCounter_500us (only 16 bit -> stops after 32 s)
    4ByteData_14 = RebootCounterValue

Example:

# Serv Line  Wr   Adr    Cnt   StatusWrite   Time1        Time2        Time3
  B0    01   01   00 00  04    00 00 00 3e   00 00 04 b0  00 00 12 c0  00 00 21 fc

For Service B1:

	Send: 0xB1nnaabbbbcc 32BitData[32BitData]

	nn = PAS Module ('01' � '10') hex
	aa = Write/Read  Write  = '01', Read = '00' hex
	bbbb = Address relative to 32BitData_1 address
	cc = Number of 32BitData

	4ByteData_0 = LineNumber
	4ByteData_1 = TimeSlot
	4ByteData_2 = Init1Time
	4ByteData_3 = Init2Time
	4ByteData_4 = Init3Time
	4ByteData_5 = UserEventOccured
	4ByteData_6 = TransmitData_ReceiveBuffer
	4ByteData_7 = ExternalDataActive
	4ByteData_8 = ActiveState

Example:

# Serv  Module  Wr    Adr     Cnt    LineNumber    TimeSlot      Init1Time
  B1    01      01    00 00   03     00 00 00 07   00 00 00 02   00 00 00 79

For service B2:

    Send: 0xB2nnaaffbbbbcc 32BitData[32BitData]

    nn = PAS Module ('01' � '10') hex
    aa = Write/Read  Write = '01', Read = '00'  hex
    ff = Area  Init1 = 1, Init2 = 2, Init3 = 3, CyclicData = 4, UserData = 5
    bbbb = Address relative to 4ByteData_1 address
    cc = Number of 32BitData
    
    Size of 32BitData Areas:  
    
    Size      Area
     32       Init1
     96       Init2
    384       Init3
    512       CyclicData
    1024      UserData
    
    Example:

# Serv  PAS  Wr  Area   Adr    Cnt     Data
  B2    10   01   01    00 00  08      10 00 00 00 10 00 00 00 10 00 00 00 10 00 00 00 10 00 00 00 10 00 00 00 10 00 00 00 10 00 00 00

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_cmd_configure_register('B0', '01', '01', '0020', ['0060005f'] ); # Write data '0060005f' to address '0020' on the PSI line 1.
MANITOO_PAS_cmd_configure_register('B0','01', '0050');                # Read the data from the address '0050' on the PSI line 1.

=cut

sub MANITOO_PAS_cmd_configure_register {

    my @args = @_;

    my $service_id         = shift;
    my $pas_line_or_module = shift;
    my $address_hex        = shift;
    my $data_aref          = shift;
    my $dataArea           = shift // '';

    my $direction_hex = '01';    # default write to line
    my ($data_length_hex);

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_cmd_configure_register( $service_id, $pas_line_or_module, $address_hex [,$data_aref, $dataArea] )', @args );

    #IF Is valid inputs
    #IF-NO-START
    #STEP Error not valid parameters
    #STEP return undef
    #IF-NO-END
    #IF-YES-START
    #IF Is manitoo initialised
    unless ($mn2_initialised) {

        #IF-NO-START
        #STEP Error manitoo not initialised
        S_set_error( "MANITOO_PAS_cmd_configure_register: Manitoo not initialised. Please call MANITOO_init\n", 120 );

        #STEP return undef
        #IF-NO-END
        return;
    }

    #IF-YES-START
    #STEP prepare command string in the format Service_Id ->line_no_or_module -> direction -> dataArea(only for service B2) -> address -> data_length -> data
    if ( defined $data_aref ) {
        $data_length_hex = sprintf( "%.2X", scalar(@$data_aref) );    # data length convert to hex.

        if ( hex($data_length_hex) >= 256 ) {                         # if the array size is 20( init 2 data ) or 100( cyclic array ) in hex load address as '0x00'
            $data_length_hex = '00';
        }

        my $data_hex = join( '', @$data_aref );
        $pas_cmd_hex = $service_id . $pas_line_or_module . $direction_hex . $dataArea . $address_hex . $data_length_hex . $data_hex;    # append to get the UART command format.
    }
    else {

        # STEP if the data is not defined, The operation direction must be 'Read'
        $direction_hex = '00';
        $pas_cmd_hex   = $service_id . $pas_line_or_module . $direction_hex . $dataArea . $address_hex;                                 # append to get the UART command format.
    }

    S_w2log( 5, "Complete PAS command: $pas_cmd_hex" );                                                                                 # do not remove helpful for debugging and verifying unit test cases

    #Example:
    #90                   01            01 02           01            01 02 03 04 (Write)
    #90                   00            01 02                                     (Read)
    #CALL MANITOO_cmd_Request_Response
    my ( $status, $return_data_aref ) = MANITOO_cmd_Request_Response( $pas_cmd_hex, { check_response => 1 } );

    #IF Is status == 0 or status == undef
    unless ($status) {

        #IF-YES-START
        #STEP Writing command to manitoo failed
        #STEP return undef
        #IF-YES-END
        S_set_error( "MANITOO_PAS_cmd_configure_register: writing command to ManiToo not successful!, check input parameters!\n", 23 );
        return;
    }

    #IF-NO-START
    #IF Is direction_hex eq '00'  ( read operation )
    if ( $direction_hex eq '00' ) {

        #IF-YES-START
        #STEP return return_data_aref
        #IF-YES-END
        return $return_data_aref;
    }
    else {
        #IF-NO-START
        # write operation - return just 1
        #STEP return 1  ( write operation )
        #IF-NO-END
        return 1;
    }

    #IF-NO-END
    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_set_quiescent_transmit_current

    Syntax : MANITOO_PAS_line_set_quiescent_transmit_current ( $pas_line_num_hex, $quiescent_curr_mA, $transmit_curr_mA )

This function sets the quiescent and transmit current for the PAS line.
    
B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '90' - '9B' ( hex ).

=item $quiescent_curr_mA

quiescent current in mA.

    Range: 2 - 30 ( mA )

=item $transmit_curr_mA

Transmit current in mA.

    Range: 0 - 69 ( mA )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_set_quiescent_transmit_current( '90', 2, 0 ); # mininum range valid values

MANITOO_PAS_line_set_quiescent_transmit_current( '9B', 30, 69 ); # maximum range valid values

MANITOO_PAS_line_set_quiescent_transmit_current( '9C', 31, 70 ); # error case value range exceeded

MANITOO_PAS_line_set_quiescent_transmit_current( '89', 1, -1 ); # error case value range below normal

=cut

sub MANITOO_PAS_line_set_quiescent_transmit_current {

    my @args = @_;

    my $pas_line_num_hex            = shift;
    my $quiescent_curr_mA           = shift;
    my $transmit_curr_mA            = shift;
    my $quiscent_transmit_data_aref = [];
    my $quiscent_transmit_err_flag  = 0;       # initialise error flag
                                               #IF Is valid inputs

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_set_quiescent_transmit_current( $pas_line_num_hex, $quiescent_curr_mA, $transmit_curr_mA )', @args );

    if ( $quiescent_curr_mA < 2 or $quiescent_curr_mA > 30 ) {
        S_set_error( "MANITOO_PAS_line_set_quiescent_transmit_current: Value '$quiescent_curr_mA' configured for parameter 'quiescent_curr_ma' is invalid. Valid range : 2 - 30 mA", 109 );
        $quiscent_transmit_err_flag = 1;
    }

    if ( $transmit_curr_mA < 0 or $transmit_curr_mA > 69 ) {
        S_set_error( "MANITOO_PAS_line_set_quiescent_transmit_current: Value '$transmit_curr_mA' configured for parameter 'transmit_curr_ma' is invalid. Valid range : 0 - 69 mA", 109 );
        $quiscent_transmit_err_flag = 1;
    }

    return if ($quiscent_transmit_err_flag);

    #IF-NO-START
    #STEP Error in input arguments
    #STEP return undef
    #IF-NO-END
    #IF-YES-START
    #STEP Convert quiescent and transmit current values from mA to hex command format values
    my $quiscent_transmit_addr_hex = sprintf( "%.4X", 11 );    # 11 is the decimal equivalent address for quiescent and transmit current

    my $quiescent_curr_hex = sprintf( "%.4X", ( $quiescent_curr_mA * 256 ) / 32 );    # quiescent current value to be downloaded to manitoo

    my $transmit_curr_hex = sprintf( "%.4X", ( $transmit_curr_mA * 256 ) / 70 );      # transmit current value to be downloaded to manitoo

    push( @$quiscent_transmit_data_aref, $quiescent_curr_hex . $transmit_curr_hex );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is status == 0 or status == undef
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $quiscent_transmit_addr_hex, $quiscent_transmit_data_aref ) ) {

        #IF-YES-START
        #STEP Writing command to manitoo failed
        #STEP return undef
        #IF-YES-END
        S_set_error( "MANITOO_PAS_line_set_quiescent_transmit_current: Function call to configure quiescent and transmit current failed!\n", 23 );
        return;
    }

    #IF-NO-START
    #STEP Writing command to manitoo successful
    S_w2log( 4, "MANITOO_PAS_line_set_quiescent_transmit_current: quiescent and transmit current set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-NO-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_set_AutoRestartTiming

    Syntax : MANITOO_PAS_line_set_AutoRestartTiming ( $pas_line_num_hex, $auto_restart_time_us )

This function sets the auto restart time in micro seconds for the PAS line.
    
B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '90' - '9B' ( hex ).

=item $auto_restart_time_us

Auto restart time in micro seconds.

    Range: 20 - 999 ( us ).

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_set_AutoRestartTiming( '90', 20 ); # mininum range valid values

MANITOO_PAS_line_set_AutoRestartTiming( '9B', 999 ); # maximum range valid values

MANITOO_PAS_line_set_AutoRestartTiming( '9C', 1000 ); # error case value range exceeded

MANITOO_PAS_line_set_AutoRestartTiming( '89', 19 ); # error case value range below normal

=cut

sub MANITOO_PAS_line_set_AutoRestartTiming {

    my @args = @_;

    my $pas_line_num_hex       = shift;
    my $auto_restart_time_us   = shift;
    my $auto_restart_data_aref = [];

    #IF Is Valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_set_AutoRestartTiming ( $pas_line_num_hex, $auto_restart_time_us )', @args );

    my $auto_restart_err_flag = 0;    # initialise error flag
    if ( $auto_restart_time_us < 20 or $auto_restart_time_us > 999 ) {
        S_set_error( "MANITOO_PAS_line_set_AutoRestartTiming: Value '$auto_restart_time_us' configured for parameter 'auto_restart_time_us' is invalid. Valid range : 20 - 999 us", 109 );
        $auto_restart_err_flag = 1;
    }

    #STEP return undef
    return if ($auto_restart_err_flag);

    #IF-NO-END
    #IF-YES-START
    #STEP prepare auto restart command in hex format
    my $auto_restart_addr_hex = sprintf( "%.4X", 5 );    # 5 is the decimal equivalent address for quiescent and transmit current

    push( @$auto_restart_data_aref, sprintf( "%.8X", $auto_restart_time_us * 25 ) );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $auto_restart_addr_hex, $auto_restart_data_aref ) ) {

        #STEP Error function call not successful
        S_set_error( "MANITOO_PAS_line_set_AutoRestartTiming: Function call to configure auto restart timing failed!\n", 23 );

        #STEP return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP auto restart time set successfully
    S_w2log( 4, " MANITOO_PAS_line_set_AutoRestartTiming: Auto restart timing set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_set_Baudrate

    Syntax : MANITOO_PAS_line_set_Baudrate ( $pas_line_num_hex, $baudrate_kbps )

This function sets baudrate in kbps for the PAS line.
    
B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '90' - '9B' ( hex ).

=item $baudrate_kbps

Three baudrate values are supported 83, 125 and 189kbps.

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_set_Baudrate( '90', 83 ); # mininum range valid values

MANITOO_PAS_line_set_Baudrate( '9B', 189 ); # maximum range valid values

MANITOO_PAS_line_set_Baudrate( '9C', 200 ); # error case value range exceeded

MANITOO_PAS_line_set_Baudrate( '89', 80 ); # error case value range below normal

=cut

sub MANITOO_PAS_line_set_Baudrate {

    my @args = @_;

    my $pas_line_num_hex   = shift;
    my $baudrate_kbps      = shift;
    my $baudrate_data_aref = [];

    #IF is valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    #STEP return undef
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_set_Baudrate ( $pas_line_num_hex, $baudrate_kbps )', @args );

    #IF-NO-END
    #IF-YES-START
    my $baudrate_err_flag = 0;    # initialise error flag

    my $baudrate_map_href = {
        83  => '00000094',
        125 => '00000061',
        189 => '0000003F'
    };                            # key -> baudrate, value-> Manitoo download value
                                  #IF Is Baudrate == (83|125|189)
                                  #IF-NO-START
    if ( $baudrate_kbps !~ /\s*(83|125|189)\s*/ ) {

        #STEP Error baudrate not in range
        S_set_error( "MANITOO_PAS_line_set_Baudrate Value '$baudrate_kbps' configured for parameter 'baudrate_kbps' is invalid. Baudrate supported are ( 83, 125 and 189 )", 109 );
        $baudrate_err_flag = 1;
    }

    #STEP return undef
    return if ($baudrate_err_flag);

    #IF-NO-END
    #IF-YES-START
    my $baudrate_addr_hex = sprintf( "%.4X", 6 );    # 6 is the decimal equivalent address for baudrate
                                                     #STEP convert to hex format that has to be loaded to manitoo
    push( @$baudrate_data_aref, $baudrate_map_href->{$baudrate_kbps} );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF is return 1
    #IF-NO-START
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $baudrate_addr_hex, $baudrate_data_aref ) ) {

        #STEP Error function call not successful
        S_set_error( "MANITOO_PAS_line_set_Baudrate: Function call to configure baudrate failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Baudrate set successfully
    S_w2log( 4, "MANITOO_PAS_line_set_Baudrate: Baudrate set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_set_Status

    Syntax : MANITOO_PAS_line_set_Status ( $pas_line_num_hex, 
                                           [$auto_restart_int, $reboot_counter_int, 
                                           $parity_bit_ts1_int, $parity_bit_ts2_int, $parity_bit_ts3_int, $parity_bit_ts4_int ] )

This function sets the status bit values.
    
B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '90' - '9B' ( hex ).

=item $auto_restart_int

    Range: 0 - 1
    
active = 1      not active = 0
For systems with asynchronous sensors it is necessary to activate the auto restart function.

=item $reboot_counter_int

    Range: 0 - 1

Locked = 0  released = 1

To reset or hold the reboot counter set bit to 0. 
To record the reboot behavior set bit to 1.  

=item $parity_bit_ts1_int

    Range: 0 - 1

active = 1  not active = 0

=item $parity_bit_ts2_int

    Range: 0 - 1

active = 1  not active = 0

=item $parity_bit_ts3_int

    Range: 0 - 1

active = 1  not active = 0

=item $parity_bit_ts4_int

    Range: 0 - 1

active = 1  not active = 0

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_set_Status( '90', 0, 0, 0, 0, 0, 0 ); # mininum range valid values

MANITOO_PAS_line_set_Status( '9B', 1, 1, 1, 1, 1, 1 ); # maximum range valid values

MANITOO_PAS_line_set_Status( '9B', 2, 2, 2, 2, 2, 2 ); # error case value range exceeded

MANITOO_PAS_line_set_Status( '90', -1, -1, -1, -1, -1, -1 ); # error case value range below normal

=cut

sub MANITOO_PAS_line_set_Status {
    my @args = @_;

    my $pas_line_num_hex      = shift;
    my $auto_restart_int      = shift;
    my $reboot_counter_int    = shift;
    my $parity_bit_ts1_int    = shift;
    my $parity_bit_ts2_int    = shift;
    my $parity_bit_ts3_int    = shift;
    my $parity_bit_ts4_int    = shift;
    my $line_status_data_aref = [];

    #IF Is valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_set_Status ( $pas_line_num_hex, [, $auto_restart_int, $reboot_counter_int, $parity_bit_ts1_int, $parity_bit_ts2_int, $parity_bit_ts3_int, $parity_bit_ts4_int] )', @args );
    my $line_status_err_flag = 0;

    if ( defined $auto_restart_int and $auto_restart_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$auto_restart_int' configured for parameter 'auto_restart_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    if ( defined $reboot_counter_int and $reboot_counter_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$reboot_counter_int' configured for parameter 'reboot_counter_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    if ( defined $parity_bit_ts1_int and $parity_bit_ts1_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$parity_bit_ts1_int' configured for parameter 'parity_bit_ts1_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    if ( defined $parity_bit_ts2_int and $parity_bit_ts2_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$parity_bit_ts2_int' configured for parameter 'parity_bit_ts2_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    if ( defined $parity_bit_ts3_int and $parity_bit_ts3_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$parity_bit_ts3_int' configured for parameter 'parity_bit_ts3_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    if ( defined $parity_bit_ts4_int and $parity_bit_ts4_int !~ /^[0-1]$/ ) {
        S_set_error( "MANITOO_PAS_line_set_Status: Value '$parity_bit_ts4_int' configured for parameter 'parity_bit_ts4_int' is invalid. Valid range ( 0, 1 )", 109 );
        $line_status_err_flag = 1;
    }

    #STEP return undef
    return if ($line_status_err_flag);

    #IF-NO-END
    #IF-YES-START
    #STEP set the values for the status bits configured, default will be 0
    my $line_status_addr_hex = sprintf( "%.4X", 0 );    # 0 is the decimal equivalent address for status

    $auto_restart_int   = 1  if ( $auto_restart_int == 1 );
    $reboot_counter_int = 32 if ( $reboot_counter_int == 1 );
    $parity_bit_ts1_int = 2  if ( $parity_bit_ts1_int == 1 );
    $parity_bit_ts2_int = 4  if ( $parity_bit_ts2_int == 1 );
    $parity_bit_ts3_int = 8  if ( $parity_bit_ts3_int == 1 );
    $parity_bit_ts4_int = 16 if ( $parity_bit_ts4_int == 1 );

    #STEP Prepare hex format by concatinating all the status bit values
    my $status_data = $auto_restart_int + $reboot_counter_int + $parity_bit_ts1_int + $parity_bit_ts2_int + $parity_bit_ts3_int + $parity_bit_ts4_int;

    $status_data = sprintf( "%.8X", $status_data );

    push( @$line_status_data_aref, $status_data );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1
    #IF-NO-START
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $line_status_addr_hex, $line_status_data_aref ) ) {

        #STEP Error function call not successfull
        S_set_error( "MANITOO_PAS_line_set_Status: Function call to configure line status failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP status bits set successfully
    S_w2log( 4, "MANITOO_PAS_line_set_Status: status bits set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_set_Timeslots

    Syntax : MANITOO_PAS_line_set_Timeslots ( $pas_line_num_hex, [$timeslot_ts1_us, $timeslot_ts2_us, $timeslot_ts3_us, $timeslot_ts4_us] )

This function sets the timeslots for the PAS line.
    
B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '90' - '9B' ( hex ).

=item $timeslot_ts1_us

    Range: 20 - 999 ( us )

=item $timeslot_ts2_us

    Range: 20 - 999 ( us )

=item $timeslot_ts3_us

    Range: 20 - 999 ( us )

=item $timeslot_ts4_us

    Range: 20 - 999 ( us )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_set_Timeslots ( '90', 20, 20, 20, 20 ); # mininum range valid values

MANITOO_PAS_line_set_Timeslots ( '9B', 999, 999, 999, 999 ); # maximum range valid values

MANITOO_PAS_line_set_Timeslots ( '9B', 1000, 1000, 1000, 1000, 1000, 1000 ); # error case value range exceeded

MANITOO_PAS_line_set_Timeslots ( '90', -1, -1, -1, -1, -1, -1 ); # error case value range below normal

=cut

sub MANITOO_PAS_line_set_Timeslots {

    my @args = @_;

    my $pas_line_num_hex = shift;
    my $timeslot_ts1_us  = shift;
    my $timeslot_ts2_us  = shift;
    my $timeslot_ts3_us  = shift;
    my $timeslot_ts4_us  = shift;
    my $ts_data_aref     = [];

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameter
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_set_Timeslots ( $pas_line_num_hex, [, $timeslot_ts1_us, $timeslot_ts2_us, $timeslot_ts3_us, $timeslot_ts4_us ] )', @args );

    my $timeslot_err_flag = 0;

    if ($timeslot_ts1_us) {
        push( @$ts_data_aref, $timeslot_ts1_us );
        if ( $timeslot_ts1_us < 20 or $timeslot_ts1_us > 999 ) {
            S_set_error( "MANITOO_PAS_line_set_Timeslots: Value '$timeslot_ts1_us' configured for parameter 'timeslot_ts1_us' is invalid. Valid range ( 20 .. 999 ) us", 109 );
            $timeslot_err_flag = 1;
        }
    }
    else {
        push( @$ts_data_aref, 0 );
    }

    if ($timeslot_ts2_us) {
        push( @$ts_data_aref, $timeslot_ts2_us );
        if ( $timeslot_ts2_us < 20 or $timeslot_ts2_us > 999 ) {
            S_set_error( "MANITOO_PAS_line_set_Timeslots: Value '$timeslot_ts2_us' configured for parameter 'timeslot_ts2_us' is invalid. Valid range ( 20 .. 999 ) us", 109 );
            $timeslot_err_flag = 1;
        }
    }
    else {
        push( @$ts_data_aref, 0 );
    }
    if ($timeslot_ts3_us) {
        push( @$ts_data_aref, $timeslot_ts3_us );
        if ( $timeslot_ts3_us < 20 or $timeslot_ts3_us > 999 ) {
            S_set_error( "MANITOO_PAS_line_set_Timeslots: Value '$timeslot_ts3_us' configured for parameter 'timeslot_ts3_us' is invalid. Valid range ( 20 .. 999 ) us", 109 );
            $timeslot_err_flag = 1;
        }
    }
    else {
        push( @$ts_data_aref, 0 );
    }
    if ($timeslot_ts4_us) {
        push( @$ts_data_aref, $timeslot_ts4_us );
        if ( $timeslot_ts4_us < 20 or $timeslot_ts4_us > 999 ) {
            S_set_error( "MANITOO_PAS_line_set_Timeslots: Value '$timeslot_ts4_us' configured for parameter 'timeslot_ts4_us' is invalid. Valid range ( 20 .. 999 ) us", 109 );
            $timeslot_err_flag = 1;
        }
    }
    else {
        push( @$ts_data_aref, 0 );
    }

    #STEP return undef
    return if ($timeslot_err_flag);

    #IF-NO-END
    #IF-YES-START
    #LOOP-START Loop over all timeslots defined
    foreach ( 0 .. 3 ) {    # prepare command string for each defined timeslot ( @$ts_data_aref )

        my $ts_addr_hex = sprintf( "%.4X", ( $_ + 1 ) );    # increment by 1, and convert to hex for the timeslot address

        if ( $$ts_data_aref[$_] ) {                         # if time slot is defined
                                                            #STEP convert timeslots to hex format
            my $ts_data_hex = sprintf( "%.8X", $$ts_data_aref[$_] * 25 );    # convert the time in milli second to the value to be loaded to manitoo

            my $temp_ts_data_aref = [];
            push( @$temp_ts_data_aref, $ts_data_hex );

            #CALL MANITOO_PAS_cmd_configure_register
            unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $ts_addr_hex, $temp_ts_data_aref ) ) {
                S_set_error( "MANITOO_PAS_line_set_Timeslots: Function call to configure line status failed!\n", 23 );
                return;
            }
        }

        #LOOP-END If all timeslots converted to hex?
    }

    #STEP Time slots set successfully
    S_w2log( 4, "MANITOO_PAS_line_set_Timeslots: Time slots set successfully \n", "grey" );

    #STEP return 1
    #IF-YES-END
    return 1;

    #STEP END
}

=head2 MANITOO_PAS_line_TransmitData

    Syntax : MANITOO_PAS_line_TransmitData ( $pas_line_num_hex )

This function sets data bits for the PSI5 frame.

B<NON EXPORTED FUNCTION>

B<Arguments:>

=over

=item $pas_line_num_hex

Line number of the PAS.

    Range: '01' - '0C' ( hex ).

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_line_TransmitData ('01');

=cut

sub MANITOO_PAS_line_TransmitData {

    my @args = @_;
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_line_TransmitData ( $pas_line_num_hex )', @args );

    my $pas_line_num_hex  = shift @args;
    my $transmit_addr_hex = sprintf( "%.4X", 7 );    # 7 is the decimal equivalent address for transmit data
    my $tranmit_data_aref = [ ("0000000C") x 4 ];

    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $pas_line_num_hex, $transmit_addr_hex, $tranmit_data_aref ) ) {
        S_set_error( "MANITOO_PAS_line_TransmitData: Falied to write Transmit data to Manitoo!", 23 );
        return;
    }

    return 1;
}

=head2 MANITOO_PAS_line_get_status_info

    my $read_data_aref = MANITOO_PAS_line_get_status_info ( $psi_line_num_int );

This function reads the PSI line status and returns the read data. 

B<Arguments:>

=over

=item $psi_line_num_int

-PSI Line number ( Varies from 1-12 )

=back

B<Return Values:>

=over

=item $read_data_aref

-Read value array reference

=back

B<Examples:>

    my $read_data_aref = PSI5_get_line_status(1); #ex: Returns data like 90 04 00 00 00 00 when line is OFF
                                                  #    Returns data like 90 04 00 00 00 02 when line is ON

=cut

sub MANITOO_PAS_line_get_status_info {

    my @args             = @_;
    my $psi_line_num_int = shift;

    #IF Is Valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return unless S_checkFunctionArguments( 'MANITOO_PAS_line_get_status_info ( $psi_line_num_int )', @args );
    if ( $psi_line_num_int < 1 or $psi_line_num_int > 12 ) {
        S_set_error( "MANITOO_PAS_line_get_status_info: Invalid PSI line number '$psi_line_num_int'.Please select from 1-12!\n", 114 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP prepare read PSI Line status command in hex format
    my $line_status_addr_hex = sprintf( "%.4X", 12 );    # 12 is the decimal equivalent address for ManiPAS line status read
    $line_status_addr_hex .= '01';
    my $psi_line_num_hex = $PAS_LINES_HREF->{$psi_line_num_int};

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    my $read_data_aref = MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $psi_line_num_hex, $line_status_addr_hex );
    unless (@$read_data_aref) {

        #STEP Error function call not successful
        S_set_error( "MANITOO_PAS_line_get_status_info: Function call to Read the PSI line '$psi_line_num_int' status failed!\n", 23 );

        #STEP return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP Read the PSI line status successfully
    S_w2log( 4, " MANITOO_PAS_line_get_status_info: Successfully Read the PSI line '$psi_line_num_int' status information\n", "grey" );

    #STEP return data_aref
    return $read_data_aref;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_get_reboot_counter

    my $reboot_counter = MANITOO_PAS_line_get_reboot_counter ( $psi_line_num_int );

This function reads reboot counter value of PSI line 

B<Arguments:>

=over

=item $psi_line_num_int

-PSI Line number ( Varies from 1-12 )

=back

B<Return Values:>

=over

=item $reboot_counter

-Reboot counter value of PSI line

=back

B<Examples:>

    my $reboot_counter = MANITOO_PAS_line_get_reboot_counter(1); 
    
=cut

sub MANITOO_PAS_line_get_reboot_counter {

    my @args             = @_;
    my $psi_line_num_int = shift;

    #IF Is Valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return unless S_checkFunctionArguments( 'MANITOO_PAS_line_get_reboot_counter ( $psi_line_num_int )', @args );
    if ( $psi_line_num_int < 1 or $psi_line_num_int > 12 ) {
        S_set_error( "MANITOO_PAS_line_get_reboot_counter: Invalid PSI line number '$psi_line_num_int'.Please select from 1-12!\n", 114 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP prepare read PSI Line status command in hex format
    my $line_status_addr_hex = sprintf( "%.4X", 14 );    # 14 is the decimal equivalent address for ManiPAS reboot counter value
    $line_status_addr_hex .= '01';
    my $psi_line_num_hex = $PAS_LINES_HREF->{$psi_line_num_int};

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return dataref?
    #IF-NO-START
    my $read_data_aref = MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $psi_line_num_hex, $line_status_addr_hex );
    unless (@$read_data_aref) {

        #STEP Error function call not successful
        S_set_error( "MANITOO_PAS_line_get_reboot_counter: Function call to Read the PSI Reboot Counter value for line '$psi_line_num_int' failed!\n", 23 );

        #STEP return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP Process the data recieved and fetch the reboot counter value in Hex
    my $reboot_counter_hex = join( "", @$read_data_aref[ 2 .. 5 ] );

    #STEP Convert the Hex value into Decimal reboot counter value
    my $reboot_counter_dec = hex($reboot_counter_hex);

    S_w2log( 4, " MANITOO_PAS_line_get_reboot_counter: Read the PSI reboot counter value '$reboot_counter_dec' from line '$psi_line_num_int' successfully \n", "grey" );

    #STEP Return Reboot counter value
    return $reboot_counter_dec;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_line_reset_reboot_counter

    my $reboot_counter = MANITOO_PAS_line_reset_reboot_counter ( $psi_line_num_int );

This function resets reboot counter value of PSI line 

B<Arguments:>

=over

=item $psi_line_num_int

-PSI Line number ( Varies from 1-12 )

=back

B<Return Values:>

=over

=item $status

-Returns 1 on success, undef on failure

=back

B<Examples:>

    my $reboot_counter = MANITOO_PAS_line_reset_reboot_counter(1);

=cut

sub MANITOO_PAS_line_reset_reboot_counter {

    my @args             = @_;
    my $psi_line_num_int = shift;

    #IF Is Valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return unless S_checkFunctionArguments( 'MANITOO_PAS_line_reset_reboot_counter ( $psi_line_num )', @args );
    if ( $psi_line_num_int < 1 or $psi_line_num_int > 12 ) {
        S_set_error( "MANITOO_PAS_line_reset_reboot_counter: Invalid PSI line number '$psi_line_num_int'.Please select from 1-12!\n", 114 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP prepare PSI Line reset status command in hex format
    my $reset_counter_addr_hex = sprintf( "%.4X", 0 );    # 0 is the decimal equivalent address for ManiPAS reset reboot counter

    my $reset_cmd = sprintf( "%.8X", 30 );                # Command to reset the reboot counter i.e. 00001E(HEX)

    my $release_cmd = sprintf( "%.8X", 62 );              # command to release the reboot counter i.e. 00003E(HEX)

    my $psi_line_num_hex = $PAS_LINES_HREF->{$psi_line_num_int};

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $psi_line_num_hex, $reset_counter_addr_hex, [$reset_cmd] ) && MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{line}, $psi_line_num_hex, $reset_counter_addr_hex, [$release_cmd] ) ) {

        #STEP Error function call not successful
        S_set_error( "MANITOO_PAS_line_reset_reboot_counter: Function call to Reset the Reboot Counter value for line '$psi_line_num_int' failed!\n", 23 );

        #STEP Return undef
        return;

        #IF-NO-END
    }

    #IF-YES-START
    #STEP successfully Reset the PSI reboot counter value
    S_w2log( 4, " MANITOO_PAS_line_reset_reboot_counter: Successfully reset the reboot counter value for the PSI line '$psi_line_num_int' \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_init_Line

    Syntax : MANITOO_PAS_init_Line ( $init_line_href )
    
    $init_line_href = {
                       'pas_line_num_int' => 2,
                       'quiescent_curr_ma' => 20,
                       'transmit_curr_ma' => 35,
                       'auto_restart_time_us' => 36,     #   optional
                       'baudrate_kbps' => 125,
                       'auto_restart_int' =>  1,         #   optional
                       'reboot_counter_int' => 1,        #   optional
                       'parity_bit_ts1_int' => 1,        #   optional
                       'parity_bit_ts2_int' => 1,        #   optional
                       'parity_bit_ts3_int' => 1,        #   optional
                       'parity_bit_ts4_int' => 1,        #   optional
                       'timeslot_ts1_us' => 45,
                       'timeslot_ts2_us' =>  100,
                       'timeslot_ts3_us' =>  120,
                       'timeslot_ts4_us' =>  145
                  }


This function initialises the PAS line.
    
B<Arguments:>

=over

=item pas_line_num_int

Line number of the PAS.

    Range: 1 - 12 ( int ).

=item auto_restart_time_us

Auto restart time in micro seconds.

    Range: 20 - 999 ( us ).

=item baudrate_kbps

Three baudrate values are supported 83, 125 and 189kbps.

=item quiescent_curr_mA

quiescent current in mA.

    Range: 2 - 30 ( mA )

=item transmit_curr_mA

Transmit current in mA.

    Range: 0 - 69 ( mA )

=item auto_restart_int

    Range: 0 - 1
    
active = 1      not active = 0
For systems with asynchronous sensors it is necessary to activate the auto restart function.

=item reboot_counter_int

    Range: 0 - 1

Locked = 0  released = 1

To reset or hold the reboot counter set bit to 0. 
To record the reboot behavior set bit to 1.  

=item parity_bit_ts1_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts2_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts3_int

    Range: 0 - 1

active = 1  not active = 0

=item parity_bit_ts4_int

    Range: 0 - 1

active = 1  not active = 0

=item timeslot_ts1_us

    Range: 20 - 999 ( us )

=item timeslot_ts2_us

    Range: 20 - 999 ( us )

=item timeslot_ts3_us

    Range: 20 - 999 ( us )

=item timeslot_ts4_us

    Range: 20 - 999 ( us )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

# mininum range valid values ( 4 time slots )
MANITOO_PAS_init_Line ( { 'pas_line_num_int' => 1,'quiescent_curr_ma' => 20,'transmit_curr_ma' => 0,'auto_restart_time_us' => 20,
                          'baudrate_kbps' => 83, 'auto_restart_int' =>  0,'reboot_counter_int' => 0,
                          'parity_bit_ts1_int' => 0,'parity_bit_ts2_int' => 0,'parity_bit_ts3_int' => 0,'parity_bit_ts4_int' => 0,
                          'timeslot_ts1_us' => 20,'timeslot_ts2_us' =>  20,'timeslot_ts3_us' =>  20,'timeslot_ts4_us' =>  20 });

# maximum range valid values ( 4 time slots )
MANITOO_PAS_init_Line ( { 'pas_line_num_int' => 12,'quiescent_curr_ma' => 30,'transmit_curr_ma' => 69,'auto_restart_time_us' => 999,
                          'baudrate_kbps' => 189, 'auto_restart_int' =>  1,'reboot_counter_int' => 1,
                          'parity_bit_ts1_int' => 1,'parity_bit_ts2_int' => 1,'parity_bit_ts3_int' => 1,'parity_bit_ts4_int' => 1,
                          'timeslot_ts1_us' => 999,'timeslot_ts2_us' =>  999,'timeslot_ts3_us' =>  999,'timeslot_ts4_us' =>  999 });

# Valid Ranges ( 2 time slots )
MANITOO_PAS_init_Line ( { 'pas_line_num_int' => 12,'quiescent_curr_ma' => 30,'transmit_curr_ma' => 69,'auto_restart_time_us' => 999,
                          'baudrate_kbps' => 189, 'auto_restart_int' =>  1,'reboot_counter_int' => 1,
                          'parity_bit_ts1_int' => 1,'parity_bit_ts2_int' => 1, 'timeslot_ts1_us' => 999,'timeslot_ts2_us' =>  999, });

=cut

sub MANITOO_PAS_init_Line {

    my @args = @_;

    my $init_line_href = shift;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_init_Line ( $init_line_href )', @args );

    unless ( $init_line_href->{'pas_line_num_int'} ) {
        S_set_error( "MANITOO_PAS_init_Line: PAS line number not configured! \n", 109 );
        return;
    }

    #IF-YES-START
    S_w2log( 4, " MANITOO_PAS_init_Line: Initializing PAS line $init_line_href->{'pas_line_num_int'}\n", "grey" );

    my $pas_line_num_int = $init_line_href->{'pas_line_num_int'};

    my $pas_line_num_hex = $PAS_LINES_HREF->{$pas_line_num_int};

    unless ($pas_line_num_hex) {
        S_set_error( "MANITOO_PAS_init_Line: PAS line number '$pas_line_num_int' configured is not in range! valid range 1 .. 12\n", 109 );
        return;
    }

    my $init_line_err_flag = 0;

    #STEP Call MANITOO_PAS_line_set_quiescent_transmit_current if quiescent_curr_mA and transmit_curr_mA defined
    if (    exists( $init_line_href->{'quiescent_curr_ma'} )
        and exists( $init_line_href->{'transmit_curr_ma'} ) )
    {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_line_set_quiescent_transmit_current( $pas_line_num_hex, $init_line_href->{'quiescent_curr_ma'}, $init_line_href->{'transmit_curr_ma'} ) ) {
            $init_line_err_flag = 1;
        }
    }

    #STEP Call MANITOO_PAS_line_set_AutoRestartTiming if auto_restart_time_us is defined
    if ( exists $init_line_href->{'auto_restart_time_us'} ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_line_set_AutoRestartTiming( $pas_line_num_hex, $init_line_href->{'auto_restart_time_us'} ) ) {
            $init_line_err_flag = 1;
        }

    }

    #STEP Call MANITOO_PAS_line_set_Baudrate if baudrate_kbps is defined
    if ( exists $init_line_href->{'baudrate_kbps'} ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_line_set_Baudrate( $pas_line_num_hex, $init_line_href->{'baudrate_kbps'} ) ) {
            $init_line_err_flag = 1;
        }
    }

    #STEP Call MANITOO_PAS_line_set_Status if any of the parameters (auto_restart_int, reboot_counter_int, parity_bit_ts(1..4)_int are defined
    if (   exists $init_line_href->{'auto_restart_int'}
        or exists $init_line_href->{'reboot_counter_int'}
        or exists $init_line_href->{'parity_bit_ts1_int'}
        or exists $init_line_href->{'parity_bit_ts2_int'}
        or exists $init_line_href->{'parity_bit_ts3_int'}
        or exists $init_line_href->{'parity_bit_ts4_int'} )
    {

        my ( $auto_restart_int, $reboot_counter_int, $parity_bit_ts1_int, $parity_bit_ts2_int, $parity_bit_ts3_int, $parity_bit_ts4_int ) = ( 0, 0, 0, 0, 0, 0 );

        $auto_restart_int = $init_line_href->{'auto_restart_int'}
          if ( exists $init_line_href->{'auto_restart_int'} );
        $reboot_counter_int = $init_line_href->{'reboot_counter_int'}
          if ( exists $init_line_href->{'reboot_counter_int'} );
        $parity_bit_ts1_int = $init_line_href->{'parity_bit_ts1_int'}
          if ( exists $init_line_href->{'parity_bit_ts1_int'} );
        $parity_bit_ts2_int = $init_line_href->{'parity_bit_ts2_int'}
          if ( exists $init_line_href->{'parity_bit_ts2_int'} );
        $parity_bit_ts3_int = $init_line_href->{'parity_bit_ts3_int'}
          if ( exists $init_line_href->{'parity_bit_ts3_int'} );
        $parity_bit_ts4_int = $init_line_href->{'parity_bit_ts4_int'}
          if ( exists $init_line_href->{'parity_bit_ts4_int'} );

        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_line_set_Status( $pas_line_num_hex, $auto_restart_int, $reboot_counter_int, $parity_bit_ts1_int, $parity_bit_ts2_int, $parity_bit_ts3_int, $parity_bit_ts4_int ) ) {
            $init_line_err_flag = 1;
        }
    }

    #STEP Call MANITOO_PAS_line_set_Timeslots if any of the parameters ( timeslot_ts(1..4)_us) are defined
    if (   exists $init_line_href->{'timeslot_ts1_us'}
        or exists $init_line_href->{'timeslot_ts2_us'}
        or exists $init_line_href->{'timeslot_ts3_us'}
        or exists $init_line_href->{'timeslot_ts4_us'} )
    {
        my ( $timeslot_ts1_us, $timeslot_ts2_us, $timeslot_ts3_us, $timeslot_ts4_us );

        $timeslot_ts1_us = $init_line_href->{'timeslot_ts1_us'}
          if ( exists $init_line_href->{'timeslot_ts1_us'} );
        $timeslot_ts2_us = $init_line_href->{'timeslot_ts2_us'}
          if ( exists $init_line_href->{'timeslot_ts2_us'} );
        $timeslot_ts3_us = $init_line_href->{'timeslot_ts3_us'}
          if ( exists $init_line_href->{'timeslot_ts3_us'} );
        $timeslot_ts4_us = $init_line_href->{'timeslot_ts4_us'}
          if ( exists $init_line_href->{'timeslot_ts4_us'} );

        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_line_set_Timeslots( $pas_line_num_hex, $timeslot_ts1_us, $timeslot_ts2_us, $timeslot_ts3_us, $timeslot_ts4_us ) ) {
            $init_line_err_flag = 1;
        }
    }

    my $function_name = ( caller(1) )[3];
    if ( $function_name =~ /PSI5_line_init/ ) {
        MANITOO_PAS_line_TransmitData($pas_line_num_hex);
    }

    #IF Is Error flag 1?
    #IF-YES-START
    #STEP return undef
    #IF-YES-END
    return if ( $init_line_err_flag == 1 );

    #IF-NO-START
    #STEP PAS line Initialized successfully
    #IF-NO-END
    S_w2log( 4, " MANITOO_PAS_init_Line: PAS line $init_line_href->{'pas_line_num_int'} Initialized \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_init_Sensor

    Syntax : MANITOO_PAS_init_Sensor ( $init_sensor_href )

This function initialises the PAS sensor.

    $init_sensor_href = { 
                            'pas_line_num_int' => 1, 
                            'time_slot_int' => 1,
                            'init1_time_ms' => 60.5
                            'init2_time_ms' => 128
                            'init3_time_ms' => 128
                            'init1_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => 0x000
                                                         }
                                                    
                                                }
                            'init2_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => 0x000
                                                         }
                                                    
                                                }
                            'init3_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => 0x000
                                                         }
                                                    
                                                } 
                            'cyclic_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => 0x000
                                                         }
                                                    
                                                }
                            'user_data_href' =>  {
                                                    1 => {
                                                                'Data_value_hex' => 0x000
                                                         }
                                                    
                                                } 
                        }
    
B<Arguments:>

=over

=item pas_line_num_int ( $pas_line_num_int )

Line number of the PAS.

    Range: 1 - 12 ( int ).

=item timeslot_int ( $timeslot_int )

4 time slots supported.
 
    Range: 1 - 4 ( int )

=item init1_time_ms ( $init1_time_ms )

Init 1 time in ms.

    Range: 0.5 - 2147483647.5

=item init2_time_ms ( $init2_time_ms )

Init 2 time in ms.

    Range: 0.5 - 2147483647.5

=item init3_time_ms ( $init3_time_ms )

Init 3 time in ms.

    Range: 0.5 - 2147483647.5
    
=item init1_data_href ( $init1_data_href )

Init 1 data array has eight elements.

The keys 1 .. 32 represents the elements.

    Range: $init1_data_href = {
                                1 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                                :
                                :
                                :
                                
                                32 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on' (optional)
                                        'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                        'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                              }

=item init2_data_href ( $init2_data_href )

Init 2 data array has 384 elements.

    Range: $init2_data_href = {
                                1 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF' 
                                    }
                                :
                                :
                                :
                                384 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF'
                                      }
                            }

=item init3_data_href ( $init3_data_href )

Init 3 data array has 96 elements.

    Range: $init3_data_href = {
                                1 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF'
                                     }
                                :
                                96 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'(optional)
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF'
                                     }
                             }

=item cyclic_data_href ($cyclic_data_href)

Cyclic messages array has 512 values.

    Range: $cyclic_data_href = {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Offset' => '0x210'                  # default '0x210' standard as per PSI5 protocol (optional)
                                            'Data_value_hex' => 0x000 - 0xFFF   
                                            # 10 bit data value, by default '0x000'         (optional)
                                        }
                                        
                                    :
                                    512 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Offset' => '0x210'                  # default '0x210' standard as per PSI5 protocol (optional)
                                            'Data_value_hex' => 0x000 - 0xFFF    
                                            # 10 bit data value, by default '0x000' (optional)
                                         }
                              }

=item user_data_href ($user_data_href) 

user messages array has 1024 values.

    Range: $user_data_href =>  {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'    
                                            # 10 bit data value, by default '0x000' (optional)
                                         }
                                    :
                                    1024 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'    
                                            # 10 bit data value, by default '0x000' (optional)
                                          }
                             }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

    MANITOO_PAS_init_Sensor ( { 
                            'pas_line_num_int' => 1, 
                            'time_slot_int' => 1,
                            'init1_time_ms' => 60.5,
                            'init2_time_ms' => 128,
                            'init3_time_ms' => 8,
                            'init1_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'init2_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'init3_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'cyclic_data_href' => {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            'user_data_href' =>  {
                                                    1 => {
                                                                'Data_value_hex' => '0x000'
                                                         }
                                                    
                                                },
                            }
                     );

=cut

sub MANITOO_PAS_init_Sensor {

    my @args = @_;

    #IF Is valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    #IF-NO-END

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_init_Sensor ( $init_sensor_href )', @args );

    my $init_sensor_href = shift @args;

    my $pas_line_int      = $init_sensor_href->{'pas_line_num_int'};
    my $time_slot_int     = $init_sensor_href->{'time_slot_int'};
    my $init1_time_ms     = $init_sensor_href->{'init1_time_ms'};
    my $init2_time_ms     = $init_sensor_href->{'init2_time_ms'};
    my $init3_time_ms     = $init_sensor_href->{'init3_time_ms'};
    my $init2_data_href   = $init_sensor_href->{'init2_data_href'};
    my $init3_data_href   = $init_sensor_href->{'init3_data_href'};
    my $sensor_module_int = $init_sensor_href->{'sensor_module'};

    my ( $init1_data_href, $cyclic_data_href, $user_data_href ) = ( {}, {}, {} );
    $init1_data_href  = $init_sensor_href->{'init1_data_href'}  if ( exists $init_sensor_href->{'init1_data_href'} );
    $cyclic_data_href = $init_sensor_href->{'cyclic_data_href'} if ( exists $init_sensor_href->{'cyclic_data_href'} );
    $user_data_href   = $init_sensor_href->{'user_data_href'}   if ( exists $init_sensor_href->{'user_data_href'} );

    #IF-YES-START
    #STEP set line number and timeslot by calling MANITOO_PAS_sensor_set_LineNum_TimeSlot

    if ( defined $pas_line_int and defined $time_slot_int ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_LineNum_TimeSlot( $sensor_module_int, $pas_line_int, $time_slot_int ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising init times not successfull!", 23 );
            return;
        }
    }

    #STEP if all the init times defined call MANITOO_PAS_sensor_set_InitTimes
    if ( defined $init1_time_ms and defined $init2_time_ms and defined $init3_time_ms ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_InitTimes( $sensor_module_int, $init1_time_ms, $init2_time_ms, $init3_time_ms ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising init times not successfull!", 23 );
            return;
        }
    }

    #STEP if init 1 data defined call MANITOO_PAS_sensor_set_Init_1_Data
    if ( defined $init1_data_href ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_Init_1_Data( $sensor_module_int, $init1_data_href ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising init 1 data not successfull!", 23 );
            return;
        }
    }

    #STEP if init 2 data defined call MANITOO_PAS_sensor_set_Init_2_Data
    if ( defined $init2_data_href ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_Init_2_Data( $sensor_module_int, $init2_data_href ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising init 2 data not successfull!", 23 );
            return;
        }
    }

    #STEP if init 3 data defined call MANITOO_PAS_sensor_set_Init_3_Data
    if ( defined $init3_data_href ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_Init_3_Data( $sensor_module_int, $init3_data_href ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising init 3 data not successfull!", 23 );
            return;
        }
    }

    #STEP if cyclic messages defined call MANITOO_PAS_sensor_set_CyclicMsgs
    if ( defined $cyclic_data_href ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_CyclicMsgs( $sensor_module_int, $cyclic_data_href ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising cyclic messages not successfull!", 23 );
            return;
        }
    }

    #STEP if user messages defined call MANITOO_PAS_sensor_set_UserMsgs
    if ( defined $user_data_href ) {
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_UserMsgs( $sensor_module_int, $user_data_href ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising user messages not successfull!", 23 );
            return;
        }
        unless ($main::opt_offline) { return unless Version_Check_PAS() }
        unless ( MANITOO_PAS_sensor_set_UserEvent( $sensor_module_int, 0 ) ) {
            S_set_error( "MANITOO_PAS_init_Sensor: Initialising user event successfull!", 23 );
            return;
        }
    }

    #IF-YES-END

    #STEP END
    return 1;
}

=head2 MANITOO_PAS_sensor_set_LineNum_TimeSlot

    Syntax : MANITOO_PAS_sensor_set_LineNum_TimeSlot ( $sensor_module_int, $pas_line_num_int, $timeslot_int );

This function sets the line number and timeslot for sensor configured for PAS module.
    
B<Arguments:>

=over

=item $sensor_module_int

PAS module number.

    Range: 1 - 16 ( int )

=item $pas_line_num_int

Line number of the PAS.

    Range: 1 - 12 ( int )

=item $timeslot_int

4 time slots supported.
 
    Range: 1 - 4 ( int )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_sensor_set_LineNum_TimeSlot ( 1, 1, 1 ); # mininum range valid values

=cut

sub MANITOO_PAS_sensor_set_LineNum_TimeSlot {

    my @args = @_;

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_LineNum_TimeSlot ( $sensor_module_int, $pas_line_num_int, $timeslot_int )', @args );

    my $sensor_module_int = shift @args;
    my $pas_line_int      = shift @args;
    my $timeslot_int      = shift @args;

    return unless Validate_sensor_module($sensor_module_int);

    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );

    my $pas_line_hex = sprintf( "%.8X", $pas_line_int );
    my $timeslot_hex = sprintf( "%.8X", $timeslot_int );

    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, '0000', [$pas_line_hex] ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_LineNum_TimeSlot: Function call to set line number failed!\n", 23 );
        return;
    }

    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, '0001', [$timeslot_hex] ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_LineNum_TimeSlot: Function call to set timeslot failed!\n", 23 );
        return;
    }
    return 1;
}

=head2 MANITOO_PAS_sensor_set_InitTimes

    Syntax : MANITOO_PAS_sensor_set_InitTimes ( $sensor_module_int, [,$init1_time_ms, $init2_time_ms, $init3_time_ms] )

This function sets the Init 1, Init 2 and Init 3 time for sensor assigned to a sensor module.
    
B<Arguments:>

=over

=item $sensor_module_int

Line number of the PAS.

    Range: 1 - 16 ( int )

=item $init1_time_ms

Init 1 time in ms.

    Range: 0.5 - 2147483647.5

=item $init2_time_ms

Init 2 time in ms.

    Range: 0.5 - 2147483647.5

=item $init3_time_ms

Init 3 time in ms.

    Range: 0.5 - 2147483647.5

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_sensor_set_InitTimes ( 1, 20, 20, 20 ); # mininum range valid values

MANITOO_PAS_sensor_set_InitTimes ( 12, 999, 999, 999 ); # maximum range valid values

MANITOO_PAS_sensor_set_InitTimes ( 17, 1000, 1000, 1000); # error case value range exceeded

MANITOO_PAS_sensor_set_InitTimes ( -1, 19, 18, 17 ); # error case value range below normal

=cut

sub MANITOO_PAS_sensor_set_InitTimes {

    my @args = @_;

    my $sensor_module_int = shift;
    my $init1_time_ms     = shift;
    my $init2_time_ms     = shift;
    my $init3_time_ms     = shift;

    #IF Is valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_InitTimes ( $sensor_module_int, [,$init1_time_ms, $init2_time_ms, $init3_time_ms])', @args );

    my $err_flag = 0;

    $err_flag = 1 unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP compute address, convert time in ms to hex value that has to be downloaded to manitoo

    my $init1_addr_hex = '0002';    # address for init time 1
    my $init2_addr_hex = '0003';    # address for init time 2
    my $init3_addr_hex = '0004';    # address for init time 3

    my ( $init1_time_hex, $init2_time_hex, $init3_time_hex );
    $init1_time_hex = [ sprintf( "%.8X", ( $init1_time_ms * 1000 ) / 500 ) ]                                       if ( defined $init1_time_ms );    # convert time in milli seconds to value to be downloaded to manitoo
    $init2_time_hex = [ sprintf( "%.8X", ( ( $init1_time_ms + $init2_time_ms ) * 1000 ) / 500 ) ]                  if ( defined $init2_time_ms );    # convert time in milli seconds to value to be downloaded to manitoo
    $init3_time_hex = [ sprintf( "%.8X", ( ( $init1_time_ms + $init2_time_ms + $init3_time_ms ) * 1000 ) / 500 ) ] if ( defined $init3_time_ms );    # convert time in milli seconds to value to be downloaded to manitoo

    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );

    #CALL MANITOO_PAS_cmd_configure_register
    if ( defined $init1_time_hex ) {
        unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $init1_addr_hex, $init1_time_hex ) ) {
            S_set_error( "MANITOO_PAS_sensor_set_InitTimes: Function call to configure init 1 time failed!\n", 23 );
            $err_flag = 1;
        }
    }

    if ( defined $init2_time_hex ) {
        unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $init2_addr_hex, $init2_time_hex ) ) {
            S_set_error( "MANITOO_PAS_sensor_set_InitTimes: Function call to configure init 2 time failed!\n", 23 );
            $err_flag = 1;
        }
    }

    if ( defined $init3_time_hex ) {
        unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $init3_addr_hex, $init3_time_hex ) ) {
            S_set_error( "MANITOO_PAS_sensor_set_InitTimes: Function call to configure init 3 time failed!\n", 23 );
            $err_flag = 1;
        }
    }

    #IF Is return 1
    #IF-NO-START
    return if ($err_flag);

    #STEP return undef
    #IF-NO-END
    #IF-YES-START
    #STEP Init times set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_InitTimes: Init times set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_Init_1_Data

    Syntax : MANITOO_PAS_sensor_set_Init_1_Data  ( $sensor_module_int, $init1_data_href )

This function sets the Init 1 data for sensor connected to the PAS module.
    
B<Arguments:>

=over

=item $sensor_module_int

PAS module.

    Range: 1 - 16 ( int )

=item $init1_data_href

Init 1 data array has eight elements.

The keys 1 .. 32 represents the elements.

    Range: $init1_data_href = {
                                1 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'
                                        'Reset_loop_int' => '1/0',           # default '0' (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'Parity_fault_int' => '1/0',         # default '0' (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                                :
                                :
                                :
                                
                                32 => {
                                        'Enable_sensor_str' => 'on/off',     # default 'on'
                                        'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                        'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                        'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                        'Data_value_hex' => '0x000' - '0xFFF'
                                     }
                              }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Different data values for each of the array element.

    MANITOO_PAS_sensor_set_Init_1_Data(1,                                             {
                                                1 => {
                                                        'Data_value_hex' => '0x1e7'
                                                     },
                                                2 => {
                                                        'Enable_sensor_str' => 'off',
                                                        'Reset_loop_int'    => 1,
                                                        'Data_value_hex'    => '0x1e7'
                                                     },
                                        
                                                3 => {
                                                        'Enable_sensor_str'    => 'on',
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int'     => 0,
                                                        'Data_value_hex'       => '0x1e7'
                                                    },
                                        
                                                4 => {
                                                        'Data_value_hex' => '0x2'
                                                     },
                                        
                                                5 => {
                                                        'Enable_sensor_str'    => 'on',
                                                        'Reset_loop_int'       => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int'     => 0,
                                                        'Data_value_hex'       => '0x1e7'
                                                    },
                                                6 => {
                                                        'Enable_sensor_str'    => 'on',
                                                        'Reset_loop_int'       => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int'     => 0,
                                                        'Data_value_hex'       => '0x1e7'
                                                    },
                                                7 => {
                                                        'Enable_sensor_str'    => 'on',
                                                        'Reset_loop_int'       => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int'     => 0,
                                                        'Data_value_hex'       => '0x1e'
                                                    },
                                        
                                                8 => {
                                                        'Enable_sensor_str'    => 'on',
                                                        'Reset_loop_int'       => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int'     => 0,
                                                        'Data_value_hex'       => '0x1e7'
                                                     }
                                            }
                                    );

=cut

sub MANITOO_PAS_sensor_set_Init_1_Data {
    my @args = @_;

    my $sensor_module_int = shift;
    my $init1_data_href   = shift;

    #IF Is valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_Init_1_Data ( $sensor_module_int, $init1_data_href )', @args );

    if ( keys %$init1_data_href > 32 ) {
        S_set_error( "MANITOO_PAS_sensor_set_Init_1_Data: Init 1 data array exceeds maximum limit of 32.", 109 );
        return;
    }

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP compute address
    my $init1_data_addr_hex = '0000';     # prepare address hex string ( 0x(1..4)100 - 0x(1..4)11F )
    my $data_aref           = [];
    my $init_type           = 'init_1';
    my $max_array_size      = 32;         # array size for Init 1 data is 32
    my $dataArea            = '01';

    #CALL non exported function Init_process_data
    #IF Is return 1
    #IF-NO-START
    #STEP Error function call to configure init 1 data failed

    $data_aref = Init_process_data( $init1_data_href, $max_array_size, $init_type );

    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );

    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{dataArea}, $sensor_module_hex, $init1_data_addr_hex, $data_aref, $dataArea ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_Init_1_Data: Function call to configure init 1 data failed!\n", 23 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Init 1 data set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_Init_1_Data: Init 1 data set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_Init_2_Data

    Syntax : MANITOO_PAS_sensor_set_Init_2_Data ( $sensor_module_int, $init2_data_href )

This function sets the Init 2 data for the Timeslot and PAS line selected.
    
B<Arguments:>

=over

=item $sensor_module_int

Sensor module assigned.

    Range: 1 - 16 ( int )

=item $init2_data_href

Init 2 data array has 384 elements.

    Range: $init2_data_href = {
                                1 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'offset' => '0x210',
                                         # default standard as per PSI5 protocol (optional)
                                        'data_value_hex' => '0x000' - '0x3FF' 
                                        # 10 bit data value, by default '000' (optional)
                                    }
                                :
                                :
                                :
                                384 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'offset' => '0x210',
                                        # default standard as per PSI5 protocol (optional)
                                        'data_value_hex' => '0x000' - '0x3FF' 
                                        # 10 bit data value, by default '000' (optional)
                                      }
                            }


=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Sixteen data elements

    MANITOO_PAS_sensor_set_Init_2_Data( 1,
                                            {
                                                1 => {
                                                    'Data_value_hex' => '0x01',
                                                    'Reset_loop_int' => 1,
                                                    'Parity_fault_int' => 1,
                                                },
                                                2 => {
                                                    'Data_value_hex' => '0x02',
                                                    'Reset_loop_int' => 1,
                                                    'Manchester_fault_int' => 1,
                                                    'Parity_fault_int' => 1,
                                                },
                                                3 => {
                                                    'Data_value_hex' => '0x03'
                                                },
                                                4 => {
                                                    'Data_value_hex' => '0x04'
                                                },
                                                5 => {
                                                    'Data_value_hex' => '0x05'
                                                },
                                                6 => {
                                                    'Data_value_hex' => '0x06'
                                                },
                                                7 => {
                                                    'Data_value_hex' => '0x07'
                                                },
                                                8 => {
                                                    'Data_value_hex' => '0x08'
                                                },
                                                9 => {
                                                    'Data_value_hex' => '0x09',
                                                    'Reset_loop_int' => 1,
                                                    'Parity_fault_int' => 1,
                                                },
                                                10 => {
                                                    'Data_value_hex' => '0x0A'
                                                },
                                                11 => {
                                                    'Data_value_hex' => '0x0B'
                                                },
                                                12 => {
                                                    'Data_value_hex' => '0x0c'
                                                },
                                                13 => {
                                                    'Data_value_hex' => '0x0D'
                                                },
                                                14 => {
                                                    'Data_value_hex' => '0x0e'
                                                },
                                                15 => {
                                                    'Data_value_hex' => '0x0F'
                                                },
                                                16 => {
                                                    'Data_value_hex' => '0x42'
                                                },
                                            }
                                    );

=cut

sub MANITOO_PAS_sensor_set_Init_2_Data {
    my @args = @_;

    my $sensor_module_int = shift;
    my $init2_data_href   = shift;

    #IF Is valid parameters
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_Init_2_Data ( $sensor_module_int, $init2_data_href )', @args );

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP Set all default values for Init 2 data
    my $enable_sensor_str    = 'on';
    my $reset_Loop_int       = 0;
    my $manchester_fault_int = 0;
    my $parity_fault_int     = 0;
    my $data_value_hex       = '0x210';
    my $offset_hex           = '0x210';
    my $single_data          = 0;
    my $init2_data_addr_hex  = '0000';
    my $data_aref            = [];
    my $data_value_dec       = 0;
    my $id                   = 0;
    my $max_array_size       = keys(%$init2_data_href);

    #LOOP-START Loop over all the data elements
    foreach my $id_key ( 1 .. $max_array_size ) {

        #STEP set the data fields as per the configuration

        if ( exists $init2_data_href->{$id_key}->{'Enable_sensor_str'} ) {
            $enable_sensor_str = $init2_data_href->{$id_key}->{'Enable_sensor_str'};
        }
        else {
            $enable_sensor_str = 'on';
        }

        if ( exists $init2_data_href->{$id_key}->{'Reset_loop_int'} ) {
            $reset_Loop_int = $init2_data_href->{$id_key}->{'Reset_loop_int'};
        }
        else {
            $reset_Loop_int = 0;
        }

        if ( exists $init2_data_href->{$id_key}->{'Manchester_fault_int'} ) {
            $manchester_fault_int = $init2_data_href->{$id_key}->{'Manchester_fault_int'};
        }
        else {
            $manchester_fault_int = 0;
        }

        if ( exists $init2_data_href->{$id_key}->{'Parity_fault_int'} ) {
            $parity_fault_int = $init2_data_href->{$id_key}->{'Parity_fault_int'};
        }
        else {
            $parity_fault_int = 0;
        }

        if ( exists $init2_data_href->{$id_key}->{'Offset'} ) {
            $offset_hex = $init2_data_href->{$id_key}->{'Offset'};
        }
        else {
            $offset_hex = '0x210';
        }

        if ( exists $init2_data_href->{$id_key}->{'Data_value_hex'} ) {

            $data_value_hex = $init2_data_href->{$id_key}->{'Data_value_hex'};
            if ( $data_value_hex !~ /^0x([0-9a-fA-F]){2}$/ ) {
                S_set_error( "MANITOO_PAS_sensor_set_Init_2_Data: Data value configured '$data_value_hex' for Init 2 data should be two nibble values in range <0x00 .. 0xFF>. e.g '0x01' | '0x12' | '0x0C'", 109 );
                return;
            }
            $data_value_hex =~ s/([0-9a-fA-F]+)([0-9a-fA-F][0-9a-fA-F])/$2/;
        }
        else {
            $data_value_hex = '000';
        }

        #STEP prepare the ID and data hex command for init 2 data
        $enable_sensor_str =~ s/on/8/;     # replace 'on' with dec value 8  ------> 1000 ...
        $enable_sensor_str =~ s/off/0/;    # replace 'off' with dec value 0 ------- 0000 ...

        $manchester_fault_int =~ s/1/2/;   # replace 1 with decimal value 2 ------> 0010 ...

        my $data_1 = sprintf( "%.1X", ( $enable_sensor_str + $reset_Loop_int ) );    # prepare hex string for enable/disable sensor and reset loop

        my $data_2 = sprintf( "%.1X", ( $manchester_fault_int + $parity_fault_int ) );    # prepare hex string for manchester and parity fault

        # hex string for ID

        my $offset_dec = sprintf( "%d", hex $offset_hex );

        if ( $data_value_hex !~ /^000$/ ) {

            $data_value_hex =~ s/^0x//;
            my @data_in_nibble_arr = split( //, $data_value_hex );
            $data_value_dec = sprintf( "%d", hex $data_in_nibble_arr[0] );
            $data_value_dec += $offset_dec;
            $data_value_hex = sprintf( "%.3X", $data_value_dec );
            my $id_hex = '8000020' . sprintf( "%.1X", $id % 16 );
            my $data_element_hex = ( $id_hex . $data_1 . $data_2 . '000' . $data_value_hex ) x 4;    # complete hex string containing ID and data

            push( @$data_aref, $data_element_hex );

            $id             = $id + 1;
            $id_hex         = '8000020' . sprintf( "%.1X", $id % 16 );
            $data_value_dec = sprintf( "%d", hex $data_in_nibble_arr[1] );
            $data_value_dec += $offset_dec;
            $data_value_hex = sprintf( "%.3X", $data_value_dec );
            $data_element_hex = ( $id_hex . $data_1 . $data_2 . '000' . $data_value_hex ) x 4;    # complete hex string containing ID and data

            push( @$data_aref, $data_element_hex );
        }

        if ( $data_value_hex =~ /^000$/ ) {

            $offset_hex =~ s/^0x//;
            my $id_hex = '8000020' . sprintf( "%.1X", $id % 16 );
            my $data_element_hex = ( $id_hex . $data_1 . $data_2 . '000' . $offset_hex ) x 4;    # complete hex string containing ID and data

            $id               = $id + 1;
            $id_hex           = '8000020' . sprintf( "%.1X", $id % 16 );
            $data_element_hex = ( $id_hex . $data_1 . $data_2 . '000' . $offset_hex ) x 4;    # complete hex string containing ID and data
            push( @$data_aref, $data_element_hex );
        }

        $id = $id + 1;
        if ( $id == 16 ) {
            $id = 0;
        }

    }

    $data_aref->[-1] =~ s/(.*)([a-zA-Z0-9])([a-zA-Z0-9]{7})$/$1 9 $3/;

    $data_aref->[-1] =~ s/\s+//g;

    my @result_arr;
    foreach my $data_elt (@$data_aref) {
        my @temp_arr = unpack( "(A8)*", $data_elt );
        push( @result_arr, @temp_arr );
    }
    @$data_aref = @result_arr;

    #LOOP-END if all data fields are set
    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    #STEP Error Function call to configure init 2 data failed
    my $dataArea = '02';
    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{dataArea}, $sensor_module_hex, $init2_data_addr_hex, $data_aref, $dataArea ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_Init_2_Data: Function call to configure init 2 data failed!\n", 23 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Init 2 data set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_Init_2_Data: Init 2 data set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_Init_3_Data

    Syntax : MANITOO_PAS_sensor_set_Init_3_Data ( $sensor_module_int $init3_data_href )

This function sets the Init 3 data for the sensor assigned to the sensor module.

B<Arguments:>

=over

=item $sensor_module_int

Sensor module assigned.

    Range: 1 - 16 ( int )

=item $init3_data_href

Init 3 data array has 96 elements.

    Range: $init3_data_href = {
                                1 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF' 
                                        # 10 bit data value, by default '0x000' (optional)
                                     }
                                :
                                
                                96 => {
                                        'enable_sensor_str' => 'on/off',     # default 'on'
                                        'reset_loop_int' => '1/0',           # default '0' (optional)
                                        'manchester_fault_int' => '1/0',     # default '0' (optional)
                                        'parity_fault_int' => '1/0',         # default '0' (optional)
                                        'data_value_hex' => '0x000' - '0x3FF' 
                                        # 10 bit data value, by default '0x000'  (optional)
                                     }
                             }


=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. Eight differnt data values.

    MANITOO_PAS_sensor_set_Init_3_Data( 1,      { 1 => {
                                                        'Data_value_hex' => '0x1e7'
                                                     },
    
                                                2 => { 
                                                        'Enable_sensor_str' => 'off',
                                                        'Reset_loop_int' => 1,
                                                        'Data_value_hex' => '0x1e7'
                                                     },
    
                                                3 => {
                                                        'Enable_sensor_str' => 'on',
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int' => 0,
                                                        'Data_value_hex' => '0x1e7'
                                                     },
    
                                                4 => {
                                                        'Data_value_hex' => '0x2'
                                                     },
    
                                                5 => { 
                                                        'Enable_sensor_str' => 'on',
                                                        'Reset_loop_int' => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int' => 0,
                                                        'Data_value_hex' => '0x1e7'
                                                     },
    
                                                6 => { 'Enable_sensor_str' => 'on',
                                                        'Reset_loop_int' => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int' => 0,
                                                        'Data_value_hex' => '0x1e7'
                                                     },
    
                                                7 => { 
                                                        'Enable_sensor_str' => 'on',
                                                        'Reset_loop_int' => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int' => 0,
                                                        'Data_value_hex' => '0x1e'
                                                     },
                                        
                                                8 => { 
                                                        'Enable_sensor_str' => 'on',
                                                        'Reset_loop_int' => 1,
                                                        'Manchester_fault_int' => 0,
                                                        'Parity_fault_int' => 0,
                                                        'Data_value_hex' => '0x1e7'
                                                     }
                                            } 
                                   );

=cut

sub MANITOO_PAS_sensor_set_Init_3_Data {
    my @args = @_;

    my $sensor_module_int = shift;
    my $init3_data_href   = shift;

    #IF Is Valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_Init_3_Data ( $sensor_module_int, $init3_data_href )', @args );

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP set address in hex, prepare init 3 data
    my $init3_data_addr_hex = '0000';
    my $data_aref           = [];
    my $max_array_size      = 16;

    $data_aref = Init_process_data( $init3_data_href, $max_array_size );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    #STEP Error Function call to configure init 3 data failed
    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );
    my $dataArea = '03';
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{dataArea}, $sensor_module_hex, $init3_data_addr_hex, $data_aref, $dataArea ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_Init_3_Data: Function call to configure init 3 data failed!\n", 23 );
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Init 3 data set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_Init_3_Data: Init 3 data set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_CyclicMsgs

    Syntax : MANITOO_PAS_sensor_set_CyclicMsgs ( $sensor_module_int, $cyclic_data_href )

This function sets the cyclic messages for the sensor assigned to the sensor module.
    
B<Arguments:>

=over

=item $sensor_module_int

Sensor module assigned.

    Range: 1 - 16 ( int )

=item $cyclic_data_href

Cyclic messages array has 512 values.

    Range: $cyclic_data_href = {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Offset' => '0x210'                  # default '0x210' standard as per PSI5 protocol (optional)
                                            'Data_value_hex' => 0x000 - 0xFFF   
                                            # 10 bit data value, by default '0x000'         (optional)
                                        }
                                        
                                    :
                                
                                    512 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Offset' => '0x210'                  # default '0x210' standard as per PSI5 protocol (optional)
                                            'Data_value_hex' => 0x000 - 0xFFF    
                                            # 10 bit data value, by default '0x000' (optional)
                                         }
                              }



=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. All the array elements initialised with data '0x01'.

    MANITOO_PAS_sensor_set_CyclicMsgs( 1,  { '1' => {'Data_value_hex' => '0x01'} ... '256' => {'Data_value_hex' => '0x01'}  }  );
    
2. Array elements 1 and 2 initialised with data '0x01'.

    MANITOO_PAS_sensor_set_CyclicMsgs( 1,  { '1' => {'Data_value_hex' => '0x01'}, '2' => {'Data_value_hex' => '0x01'} }  );

=cut

sub MANITOO_PAS_sensor_set_CyclicMsgs {

    my @args = @_;

    my $sensor_module_int = shift;
    my $cyclic_data_href  = shift;

    #IF Is Valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_CyclicMsgs ( $sensor_module_int, $cyclic_data_href )', @args );

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP set address in hex, prepare cyclic data
    my $cyclic_data_addr_hex = '0000';    # prepare address hex string ( 0x(1..4)800 - 0x(1..4)9FF )
    my $data_aref            = [];
    my $max_array_size       = 256;       # array size is 513 for cyclic messages

    my @cyclic_elements = sort { $a <=> $b } keys %$cyclic_data_href;
    $max_array_size = $cyclic_elements[-1];

    $data_aref = Init_process_data( $cyclic_data_href, $max_array_size );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    #STEP Function call to configure cyclic messages failed
    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );
    my $dataArea = '04';
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{dataArea}, $sensor_module_hex, $cyclic_data_addr_hex, $data_aref, $dataArea ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_CyclicMsgs: Function call to configure cyclic messages failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Cyclic messages set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_CyclicMsgs: Cyclic messages set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_UserMsgs

    Syntax : MANITOO_PAS_sensor_set_UserMsgs ( $sensor_module_int, $user_data_href )

This function sets the user messages for the sensor assigned to the sensor module.
    
B<Arguments:>

=over

=item $sensor_module_int

Sensor module assigned.

    Range: 1 - 16 ( int )

=item $user_data_href

user messages array has 1024 values.

    Range: $user_data_href =  {
                                    1 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'    
                                            # 10 bit data value, by default '0x000' (optional)
                                         }
                                    :
                                
                                    1024 => {
                                            'Enable_sensor_str' => 'on/off',     # default 'on'
                                            'Reset_loop_int' => '1/0',           # default '0'  (optional)
                                            'Manchester_fault_int' => '1/0',     # default '0'  (optional)
                                            'Parity_fault_int' => '1/0',         # default '0'  (optional)
                                            'Data_value_hex' => '0x000' - '0x3FF'    
                                            # 10 bit data value, by default '0x000' (optional)
                                          }
                             }

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

1. All the array elements initialised with data '0x01'.

    MANITOO_PAS_sensor_set_UserMsgs( 1, { '1' => {'Data_value_hex' => '0x01'} ... '16' => {'Data_value_hex' => '0x01'} }  );
    
2. Array elements 1 and 2 initialised with data '0x01'.

    MANITOO_PAS_sensor_set_UserMsgs( 1, { '1' => {'Data_value_hex' => '0x01'}, '2' => {'Data_value_hex' => '0x01'} }  );

=cut

sub MANITOO_PAS_sensor_set_UserMsgs {

    my @args = @_;

    my $sensor_module_int = shift;
    my $user_data_href    = shift;

    #IF Is Valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_UserMsgs ( $sensor_module_int, $user_data_href )', @args );

    #IF-NO-END
    #IF-YES-START
    #STEP set address, prepare user data
    my $user_data_addr_hex = '0000';
    my $data_aref          = [];
    my $max_array_size     = 16;       # array size is 16 for user messages

    my @user_elements = sort { $a <=> $b } keys %$user_data_href;
    $max_array_size = $user_elements[-1];

    $data_aref = Init_process_data( $user_data_href, $max_array_size );

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    #STEP Error Function call to configure user messages failed
    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );
    my $dataArea = '05';
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{dataArea}, $sensor_module_hex, $user_data_addr_hex, $data_aref, $dataArea ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_UserMsgs: Function call to configure user messages failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP User messages set successfully
    S_w2log( 4, "MANITOO_PAS_sensor_set_UserMsgs: User messages set successfully \n", "grey" );

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_set_UserEvent

    Syntax : MANITOO_PAS_sensor_set_UserEvent ( $sensor_module_int, $userevent_int )

This function sets user event bit (bit 0) to 0 or 1.

B<Arguments:>

=over

=item $sensor_module_int

Sensor module assigned.

    Range: 0 - 16 ( int )
    
=item $userevent_int

    0 -> if user message is not configured.
 
    1 -> if user message is configured.
 
    Range: 0 - 1 ( int )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_sensor_set_UserEvent ( 1, 0 ); # mininum range valid values

MANITOO_PAS_sensor_set_UserEvent( 16, 1 ); # maximum range valid values

MANITOO_PAS_sensor_set_UserEvent( 17, 2 ); # error case value range exceeded

MANITOO_PAS_sensor_set_UserEvent( 0, -1 ); # error case value range below normal

=cut

sub MANITOO_PAS_sensor_set_UserEvent {

    my @args = @_;

    my $sensor_module_int = shift;

    my $userevent_int = shift;

    #IF Is Valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters

    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_set_UserEvent ( $sensor_module_int, $userevent_int )', @args );

    if ( $userevent_int < 0 or $userevent_int > 1 ) {

        S_set_error( "MANITOO_PAS_sensor_set_UserEvent The value '$userevent_int' configured for parameter 'userevent_int' is out range!\n valid range ( 0 - 1 )", 109 );
        return;
    }

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP set address, prepare user event data
    my $userevent_addr_hex = '0005';    #address of the user event

    my $userevent_data_aref = ['00000000'];    #by default set to 0

    if ( $userevent_int == 1 ) {
        $userevent_data_aref = ['00000001'];
    }
    else {
        $userevent_data_aref = ['00000000'];
    }

    #CALL MANITOO_PAS_cmd_configure_register
    #IF Is return 1?
    #IF-NO-START
    #STEP Error Function call to configure user event failed
    my $sensor_module_hex = sprintf( "%.2X", $sensor_module_int );
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $userevent_addr_hex, $userevent_data_aref ) ) {
        S_set_error( "MANITOO_PAS_sensor_set_UserEvent Function call to configure user event failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP User event set successfully
    if ( $userevent_int == 1 ) {
        S_w2log( 4, "MANITOO_PAS_sensor_set_UserEvent: User event configured successfully \n", "grey" );
    }

    #STEP return 1
    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_switch_off

    Syntax : MANITOO_PAS_sensor_switch_off ( $sensor_module_int )

This function switches off the PAS sensor configured for PAS module.
    
B<Arguments:>

=over
    
=item $sensor_module_int

Sensor module assigned.
 
    Range: 1 - 16 ( int )

=back

B<Return Value:>
1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_sensor_switch_off(1, 1);

=cut

sub MANITOO_PAS_sensor_switch_off {
    my @args = @_;

    my $sensor_module_int = shift;

    #IF Is Valid Parameters
    #IF-NO-START
    #STEP Error Invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_switch_off ( $sensor_module_int )', @args );

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP set address, prepare hex data for external_data_active and transmit_data to switch off the sensor
    # mapping for the time slot(key) and transmit data buffer address(value)

    my $transmit_data_addr_hex        = '0006';
    my $external_data_active_addr_hex = '0007';                                  # prepare address hex string ( 0x(1..4)004 )
    my $transmit_data_aref            = ['00000000'];                            # the transmit data set to 0 inorder to switch off the sensor
    my $external_active_aref          = ['00000001'];                            # the external data set to 1 inorder to switch off the sensor
                                                                                 #CALL MANITOO_PAS_cmd_configure_register
                                                                                 #IF Is return 1?
                                                                                 #IF-NO-START
                                                                                 #STEP Error Function call to configure transmit data inorder to switch off sensor
    my $err_flag                      = 0;
    my $sensor_module_hex             = sprintf( "%.2X", $sensor_module_int );
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $transmit_data_addr_hex, $transmit_data_aref ) ) {
        S_set_error( "MANITOO_PAS_sensor_switch_off: Function call to configure transmit data inorder to switch off sensor failed!\n", 23 );
        $err_flag = 1;
    }
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $external_data_active_addr_hex, $external_active_aref ) ) {
        S_set_error( "MANITOO_PAS_sensor_switch_off: Function call to configure external data active inorder to switch off sensor failed!\n", 23 );
        $err_flag = 1;
    }

    #IF-NO-END
    return if ($err_flag);

    #IF-YES-START
    #STEP Sensor switched off successfully
    S_w2log( 4, "MANITOO_PAS_sensor_switch_off: Sensor connected to PAS module $sensor_module_int is switched off \n", "grey" );

    #STEP return 1

    return 1;

    #IF-YES-END
    #IF-YES-END
    #STEP END
}

=head2 MANITOO_PAS_sensor_switch_on

    Syntax : MANITOO_PAS_sensor_switch_on ($sensor_module_int)

This function switches on the PAS sensor configured for PAS module.
    
B<Arguments:>

=over

=item $sensor_module_int

PAS module.

    Range: 1 - 16 ( int )

=back

B<Return Value:>

1 on Success and 'undef' on failure.

B<Examples:>

MANITOO_PAS_sensor_switch_on ( 1 );

=cut

sub MANITOO_PAS_sensor_switch_on {
    my @args = @_;

    my $sensor_module_int = shift;

    #IF Is Valid parameters?
    #IF-NO-START
    #STEP Error invalid parameters
    return
      unless S_checkFunctionArguments( 'MANITOO_PAS_sensor_switch_on ( $sensor_module_int )', @args );

    return unless Validate_sensor_module($sensor_module_int);

    #IF-NO-END
    #IF-YES-START
    #STEP set address, prepare hex data for external_data_active to switch off sensor
    my $external_data_active_addr_hex = '0007';
    my $data_aref                     = [];
    my $external_active_aref          = ['00000000'];                            # the external data to be set to 0 inorder to switch off the sensor
                                                                                 #CALL MANITOO_PAS_cmd_configure_register
                                                                                 #IF Is return 1?
                                                                                 #IF-NO-START
                                                                                 #STEP Function call to configure external data active inorder to switch on sensor failed
    my $sensor_module_hex             = sprintf( "%.2X", $sensor_module_int );
    unless ( MANITOO_PAS_cmd_configure_register( $PAS_SERVICE_HREF->{module}, $sensor_module_hex, $external_data_active_addr_hex, $external_active_aref ) ) {
        S_set_error( "MANITOO_PAS_sensor_switch_on: Function call to configure external data active inorder to switch on sensor failed!\n", 23 );

        #STEP return undef
        return;
    }

    #IF-NO-END
    #IF-YES-START
    #STEP Sensor switched on successfully
    S_w2log( 4, "MANITOO_PAS_sensor_switch_on: Sensor connected to PAS module $sensor_module_int is switched on \n", "grey" );

    #STEP return 1
    #IF-YES-END
    #IF-YES-END
    #STEP END
    return 1;
}

#**********************************************************
sub MANITOO_RUN_TEST_SEQUENCE {
    my $testcase_name = shift;

    my $spi_module;
    if ( $testcase_name =~ /^([0-9][0-9A-F])_(.*)/ ) {
        $spi_module    = "$1";
        $testcase_name = "$2";
    }
    my $MANITOO_TESTCASES = S_get_contents_of_hash( [ 'MANITOO_TEMP', 'TESTCASES' ] );
    my $testcases;

    unless ( $testcases = $MANITOO_TESTCASES->{$testcase_name} ) {
        S_set_error("Service '$testcase_name' not defined in Defaults -> 'MANITOO_TEMP' -> 'TESTCASES'");
        return;
    }

    # Dumper
    # ------------------------------------------------------------
    #    my $dump_hash = "dump_MANITOO_TESTCASES_".time();
    #    open (FILE, ">", "$main::REPORT_PATH./$dump_hash.txt");
    #    print FILE Dumper($MANITOO_TESTCASES);
    #    close (FILE);
    # ------------------------------------------------------------

    my $commands;
    unless ( $commands = $testcases->{'CMD_sequence'} ) {
        S_set_error("Missing 'CMD_sequence' in Testsequence '$testcase_name' in Defaults -> 'MANITOO_TEMP' -> 'TESTCASES'");
        return;
    }

    S_w2log( 3, "MANITOO_RUN_TEST_SEQUENCE : Execute $testcase_name \n", "green", "Testseq: $testcase_name" );
    foreach my $cmd_nbr ( sort { $a <=> $b } keys %$commands ) {

        my $cmd_descr;
        unless ( $cmd_descr = $commands->{$cmd_nbr}{'descr'} ) {
            S_w2log( 3, "MANITOO_RUN_TEST_SEQUENCE : $testcase_name -> no command description defined for Cmd nbr $cmd_nbr\n", "orange" );
        }
        else {
            S_w2log( 3, "$cmd_descr \n", "green" );
        }

        if ( my $cmd_code = $commands->{$cmd_nbr}{'cmd'} ) {

            #substitute spi module from tcname if defined in the format "dd_TCNAME" where dd indicates SPI module number
            if ( defined $spi_module ) {
                $cmd_code =~ s/(\d\d)(\s*-*\s*)([0-9][0-9A-F])(.*)/$1$2$spi_module$4/;
            }
            MANITOO_cmd_Request_Response($cmd_code);
        }
        else {
            S_w2log( 3, "MANITOO_RUN_TEST_SEQUENCE : Comment $cmd_nbr $cmd_descr \n", "cyan" ) if defined $cmd_descr;
        }
    }

    return 1;
}

#**********************************************************
sub MANITOO_RUN_SERVICE {
    my $service_name = shift;
    my $MANITOO_RUN_SERVICES = S_get_contents_of_hash( [ 'MANITOO_TEMP', 'SERVICES' ] );
    my $service;

    unless ( $service = $MANITOO_RUN_SERVICES->{$service_name} ) {
        S_set_error("Service '$service_name' not defined in Defaults -> 'MANITOO_TEMP' -> 'SERVICES'");
        return;
    }

    # Dumper
    # ------------------------------------------------------------
    #    my $dump_hash = "dump_MANITOO_RUN_SERVICES_".time();
    #    open (FILE, ">", "$main::REPORT_PATH./$dump_hash.txt");
    #    print FILE Dumper($MANITOO_RUN_SERVICES);
    #    close (FILE);
    # ------------------------------------------------------------

    my $commands;
    unless ( $commands = $service->{'CMD_sequence'} ) {
        S_set_error("Missing 'CMD_sequence' in Service '$service_name' in Defaults -> 'MANITOO_TEMP' -> 'SERVICES'");
        return;
    }

    S_w2log( 3, "MANITOO_RUN_SERVICE : Execute $service_name \n", "green" );
    foreach my $cmd_nbr ( sort { $a <=> $b } keys %$commands ) {

        my $cmd_descr;
        unless ( $cmd_descr = $commands->{$cmd_nbr}{'descr'} ) {
            S_w2log( 3, "MANITOO_RUN_SERVICE : $service_name -> no command description defined for Cmd nbr $cmd_nbr\n", "orange" );
        }
        else {
            S_w2log( 3, "$cmd_descr \n", "green" );
        }

        if ( my $cmd_code = $commands->{$cmd_nbr}{'cmd'} ) {
            MANITOO_cmd_Request_Response($cmd_code);
        }
        else {
            S_w2log( 3, "MANITOO_RUN_SERVICE : Comment $cmd_nbr $cmd_descr \n", "cyan" ) if defined $cmd_descr;
        }
    }

    return 1;
}

=head1 Non Exported Functions

=cut

sub Convert_bytes_for_send {
    my $byte_string = shift;

    #split the string into one byte values
    my @bytes = ( $byte_string =~ m/.{2}/g );
    my $return_cmd;
    foreach (@bytes) {
        next unless /\w/;

        # S_w2log( 4, "Convert_bytes_for_send: '$_' \n" );
        $return_cmd .= chr( hex($_) );    # hex: 05 -> 0x05   / chr: 0x05 -> \x05
    }
    return $return_cmd;
}

sub Convert_bytes_for_print {
    my $bytesting = shift;

    my @bytes = split( //, $bytesting );

    my $str1;
    foreach my $byte (@bytes) {
        $byte = sprintf( "%02X", ord($byte) );
        $str1 .= "$byte ";
    }
    return $str1;
}

=head2 Write_dc_format

    Syntax :
        ( $control_1_data_href,
          $control_2_data_href,
          $mode_collection_href ) = Write_dc_format( $data_control_1,
                                                     $data_control_2,
                                                     [, $time_us,
                                                     $nbr_of_frames] );

This function validates and prepares the command strings
for the services 0x41, 0x42 and 0x43 when the format of the input to the
function Manitoo_write_config is in Data Control(DC) format.

 Note: This function is not exported.

Input Arguments :  

    $data_control_1_mix -> 4 byte hex string , scalar( one data set ) or aref ( > 1 data set)
    
    $data_control_2_mix -> 4 byte hex string , scalar( one data set ) or aref ( > 1 data set)
    
    $time_us_mix,       -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set)
    
    $nbr_of_frames_mix  -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set)

Return Values :


    Return Values success : $control_1_data_href , $control_2_data_href and $mode_collection_href.
    
    Example :
        $control_1_data_href  = {
                                   '1' => 'FF00FF00',
                                   '2' => 'FF00FF00'
                                };
        $control_2_data_href  = {
                                   '1' => '00FF00FF',
                                   '2' => '00FF00FF'
                                };
        $mode_collection_href = {
                                   '1' => {
                                            'TIME_US' => '2000000',
                                            'MODE' => 'TIM'
                                          },
                                   '2' => {
                                            'TIME_US' => '2000000',
                                            'MODE' => 'TIM'
                                          }
                                };
    Return Values in error : 0

Example1( Success ) : 

    ( $control_1_data_href,
                          $control_2_data_href,
                          $mode_config_href ) = Write_dc_format( '00 07 FF F8', '00 00 08 00', 2000000 );

    Return Values       :   $control_1_data_href  = {
                                                   '1' => '0007FFF8',
                                                };
                            $control_2_data_href  = {
                                                   '1' => '00000800',
                                                };
                            $mode_collection_href = {
                                                   '1' => {
                                                            'TIME_US' => '2000000',
                                                            'MODE' => 'TIM'
                                                          },
                                                };

Example2( Error ) : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_dc_format( '00 07 FF F8', [ '00 00 08 00', '00 00 08 00' ], 2000000 );

    Error                :   Write_dc_format : The type of value for keys 'data_control_1'
                            and 'data_control_2' in function 'MANITOO_write_config' should be same.
                                Both should be 'SCALAR' or both should be 'ARRAY reference'.
    Return Value         : 0

=cut

sub Write_dc_format {

    my @args = @_;

    return ( 0, [] ) unless S_checkFunctionArguments( 'Write_dc_format ( $data_control_1_mix, $data_control_2_mix, [, $time_us_mix, $nbr_of_frames_mix ] )', @args );

    my $data_control_1_mix   = shift;
    my $data_control_2_mix   = shift;
    my $time_us_mix          = shift;
    my $nbr_of_frames_mix    = shift;
    my $control_1_data_href  = {};
    my $control_2_data_href  = {};
    my $mode_collection_href = {};
    my $mode_counter         = 1;
    my @modes                = ( $time_us_mix, $nbr_of_frames_mix );

    if ( defined $data_control_1_mix and defined $data_control_2_mix ) {

        # 'time_us' and 'frames' should be of same type for the combination of data sets
        #   with SPI and TIM mode in DC type

        if ( ref $data_control_1_mix ne ref $data_control_2_mix ) {
            S_set_error( "Write_dc_format : The type of value for keys 'data_control_1' and 'data_control_2' in function 'MANITOO_write_config' should be same. Both should be 'SCALAR' or both should be 'ARRAY reference'\n", 109 );
            return 0;
        }
        if ( ref $data_control_1_mix ne 'ARRAY' and ref $data_control_2_mix ne 'ARRAY' ) {
            if ( defined $nbr_of_frames_mix and defined $time_us_mix ) {

                # error if both the keys 'time_us' and 'frames' are configured when
                # $data_control_1 and $data_control_2_mix are scalar

                if ( ref $nbr_of_frames_mix ne 'ARRAY' and ref $time_us_mix ne 'ARRAY' ) {
                    S_set_error( "Write_dc_format : Any one of the keys, either 'time_us' or 'frames' should be configured in function 'MANITOO_write_config' when only one data set is configured\n", 109 );
                    return 0;
                }
                if ( ref $nbr_of_frames_mix eq 'ARRAY' or ref $time_us_mix eq 'ARRAY' ) {

                    # error if either of the keys 'time_us' and 'frames' are aref when
                    # $data_control_1 and $data_control_2_mix are scalar

                    S_set_error( "Write_dc_format : The keys 'time_us' , 'frames' should be scalar value in function 'MANITOO_write_config' when the keys 'data_control_1' and 'data_control_2' are scalar\n", 109 );
                    return 0;
                }
            }

            # error if the array reference with size more than 1 is configured for only one data set
            foreach my $mode (@modes) {
                if ( defined $mode and ref $mode eq 'ARRAY' ) {
                    unless ( @$mode == 1 ) {
                        S_set_error( "Write_dc_format : The size of array reference for keys 'time_us' or 'frames' in function 'MANITOO_write_config' should be '1'(if configured as array reference) or should be a scalar value when keys 'data_control_1' and 'data_control_2' are scalar\n", 109 );
                        return 0;
                    }
                }
            }

            #call function Mode_config to fill the inputs for the function MANITOO_cmd_write_DatCtrl_ModeTime
            $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, 0 );

            #fill the inputs for the function MANITOO_cmd_write_DatCtrl_1 and MANITOO_cmd_write_DatCtrl_2
            $$control_1_data_href{1} = $data_control_1_mix;
            $$control_2_data_href{1} = $data_control_2_mix;

            return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
        }

        # remove '-', ' ' and '0x' characters from data_control_1 and data_control_2
        map { $_ =~ s/[-\s*]//g; $_ =~ s/^0x//g } @$data_control_1_mix;
        map { $_ =~ s/[-\s*]//g; $_ =~ s/^0x//g } @$data_control_2_mix;

        #check if the dataset values of $data_control_1 are within range
        my @invalid_val_ctrl1 = grep { $_ !~ /[0-9A-F]{8}/i } (@$data_control_1_mix);
        if (@invalid_val_ctrl1) {
            local $" = ', ';
            S_set_error( "Write_dc_format : The values [ @invalid_val_ctrl1 ] configured for the key 'data_control_1' in function 'MANITOO_write_config' should be in range 00000000 - FFFFFFFF\n", 109 );
            return 0;
        }

        #check if the dataset values of $data_control_2_mix are within range
        my @invalid_val_ctrl2 = grep { $_ !~ /[0-9A-F]{8}/i } (@$data_control_2_mix);
        if (@invalid_val_ctrl2) {
            local $" = ', ';
            S_set_error( "Write_dc_format : The values [ @invalid_val_ctrl2 ] configured for the key 'data_control_2' in function 'MANITOO_write_config' should be in range 00000000 - FFFFFFFF\n", 109 );
            return 0;
        }

        # error if the size of 'data_control_1' and 'data_control_2' are different
        if ( scalar @$data_control_1_mix != scalar @$data_control_2_mix ) {
            S_set_error( "Write_dc_format : Size of 'data_control_1' and 'data_control_2' in function 'MANITOO_write_config' should be same.\n", 109 );
            return 0;
        }

        if ( defined $nbr_of_frames_mix and defined $time_us_mix ) {
            if ( ref $nbr_of_frames_mix ne 'ARRAY' or ref $time_us_mix ne 'ARRAY' ) {

                # error when both the keys 'time_us' or 'frames' are configured as scalar and
                #   more than one data sets are configured

                S_set_error( "Write_dc_format : Values for the keys 'time_us' and 'frames' in function 'MANITOO_write_config' should be of array reference type, when data sets involve both SPI and TIM mode\n", 109 );
                return 0;
            }

            # error if the size of 'time_us' and 'frames' do not match the size of
            # 'data_control_1' and 'data_control_2' when all the value types are of aref

            if ( ( scalar @$nbr_of_frames_mix != scalar @$data_control_1_mix ) or ( scalar @$time_us_mix != scalar @$data_control_1_mix ) ) {
                S_set_error( "Write_dc_format : The size of array reference for keys 'time_us' and 'frames' in function 'MANITOO_write_config' should match the size of keys 'data_control_1' and 'data_control_2'\n", 109 );
                return 0;
            }
        }

        #error, if the array reference size of modes does not match array reference of control data
        foreach my $mode (@modes) {
            if ( defined $mode and ref $mode eq 'ARRAY' ) {
                unless ( @$data_control_1_mix == @$mode ) {
                    S_set_error( "Write_dc_format : The size of array reference for keys 'time_us' or 'frames' in function 'MANITOO_write_config' should match the size of keys 'data_control_1' and 'data_control_2'\n", 109 );
                    return 0;
                }
            }
        }

        #call function Mode_config to fill the inputs for the function MANITOO_cmd_write_DatCtrl_ModeTime
        $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, $#$data_control_1_mix );

        my $ctrl1_count = 1;

        #fill the inputs for the function MANITOO_cmd_write_DatCtrl_1
        map { $$control_1_data_href{ $ctrl1_count++ } = $_ } @$data_control_1_mix;

        my $ctrl2_count = 1;

        #fill the inputs for the function MANITOO_cmd_write_DatCtrl_2
        map { $$control_2_data_href{ $ctrl2_count++ } = $_ } @$data_control_2_mix;

        return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );

    }
}

=head2 Write_mvb_format

    Syntax :
        ( $control_1_data_href,
          $control_2_data_href,
          $mode_collection_href ) = Write_dc_format( $masked_value_bin_mix,
                                                     [, $time_us_mix,
                                                     $nbr_of_frames_mix ] );

This function validates and prepares the command strings
for the services 0x41, 0x42 and 0x43 when the format of the input to the
function Manitoo_write_config is in Mask Value Bit(MVB) format.

Note: This function is not exported.

Input Arguments :

    $masked_value_bin_mix, -> 32 bit binary string , scalar(one data set ) or aref ( > 1 data set)
    
    $time_us_mix,          -> ( 0 - 268435455 dec ) scalar(one data set ) or aref ( > 1 data set)
    
    $nbr_of_frames_mix.    -> ( 0 - 268435455 dec ) scalar(one data set ) or aref ( > 1 data set)

Return values :

    Return Values success : $control_1_data_href, $control_2_data_href , $mode_collection_href
    
        Example :
                    $control_1_data_href  = {
                                                '1' => 'FF00FF00',
                                                '2' => 'FF00FF00'
                                            };
                    $control_2_data_href  = {
                                            '1' => '00FF00FF',
                                            '2' => '00FF00FF'
                                         };
                    $mode_collection_href = {
                                            '1' => {
                                                    'TIME_US' => '2000000',
                                                    'MODE' => 'TIM'
                                                  },
                                            '2' => {
                                                    'TIME_US' => '2000000',
                                                    'MODE' => 'TIM'
                                                  }
                                         };
    Return Values in error : 0

Example1( Success ) : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_mvb_format( 'xxxxxxxxxxxx0100ii0100000011xxxx', 2000000 );

    Return Values        : $control_1_data_href  =  {
                                                        '1' => '000f3ff0',
                                                    };
                           $control_2_data_href  = {
                                                       '1' => '0004d030',
                                                    };
                           $mode_collection_href = {
                                                       '1' => {
                                                                'TIME_US' => '2000000',
                                                                'MODE' => 'TIM'
                                                              },
                                                    };

Example2( Error ) : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_mvb_format( 'xxxxxxxxxxxx0100ii0100000011xxxx',
                                                [ 2000000, 3000000] );

    Error                :   Write_mvb_format : The value for keys
                                'time_us' or 'nbr_of_frames' in function 'MANITOO_write_config'
                                    should be scalar, since the value configured for key 'masked_value_bin'
                                        is a scalar.
    Return Value         : 0

=cut

sub Write_mvb_format {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'Write_mvb_format ( $masked_value_bin_mix, [, $time_us_mix, $nbr_of_frames_mix ] )', @args );
    my $masked_value_bin_mix = shift;
    my $time_us_mix          = shift;
    my $nbr_of_frames_mix    = shift;
    my $mode_collection_href = {};
    my $control_1_data_href  = {};
    my $control_2_data_href  = {};
    my $mode_counter         = 1;
    my ( $data1, $data2 );
    my @modes = ( $time_us_mix, $nbr_of_frames_mix );
    my $bit_convert = {
        '-' => '0#0',
        'x' => '0#0',
        'X' => '0#0',
        'i' => '0#1',
        'I' => '0#1',
        '0' => '1#0',
        '1' => '1#1'
    };

    unless ( ref $masked_value_bin_mix eq 'ARRAY' ) {

        if ( defined $nbr_of_frames_mix and defined $time_us_mix ) {

            # error if both the keys 'time_us' and 'frames' are configured when
            # 'masked_value_bin' is scalar
            if (    ref $nbr_of_frames_mix ne 'ARRAY'
                and ref $time_us_mix ne 'ARRAY' )
            {
                S_set_error( "Write_mvb_format : Any one of the keys, either 'time_us' or 'frames' should be configured in function 'MANITOO_write_config', when only one data set is configured for key 'masked_value_bin'\n", 109 );
                return 0;
            }

            # error if either of the keys 'time_us' and 'frames' are aref when
            # 'masked_value_bin' is scalar
            if (   ref $time_us_mix eq 'ARRAY'
                or ref $nbr_of_frames_mix eq 'ARRAY' )
            {
                S_set_error( "Write_mvb_format : The value for keys 'time_us' or 'nbr_of_frames' in function 'MANITOO_write_config' should be scalar, since the value configured for key 'masked_value_bin' is a scalar.\n", 109 );
                return 0;
            }
        }

        my @bit_count;
        $masked_value_bin_mix =~ s/[.\s*]//g;    # remove '.' and ' ' in the mvb string.

        # split each bit for the purpose of converting to ctrl1 and ctrl2 data.
        my $mvb_bit_count = @bit_count = split( //, $masked_value_bin_mix );

        # error, if the length of mvb not equal to 32.
        unless ( $mvb_bit_count == 32 ) {
            S_set_error( "Write_mvb_format : Character count of '$masked_value_bin_mix' string should be 32 in the value configured for the key 'masked_value_bin' in function 'MANITOO_write_config'.\n", 109 );
            return 0;
        }
        if ( $masked_value_bin_mix =~ /[^xX\-iI01]/ ) {
            S_set_error( "Write_mvb_format : Invalid characters found in data set '$masked_value_bin_mix' configured for the key 'masked_value_bin_mix' in function 'MANITOO_write_config'. Allowed characters are 'x', 'X', '-', 'i', 'I', '0' or '1'.\n", 109 );
            return 0;
        }

        # error, if the array reference with size more than 1 is configured for 'time_us' or 'frames'
        #   for only one data set
        foreach my $mode (@modes) {
            if ( defined $mode and ref $mode eq 'ARRAY' ) {
                unless ( @$mode == 1 ) {
                    S_set_error( "Write_mvb_format : The size of array reference for keys 'time_us' or 'frames' in function 'MANITOO_write_config' should be '1'(if configured as array reference). ( or ) should be a scalar value when key 'masked_value_bin' is configured as scalar.\n", 109 );
                    return 0;
                }
            }
        }

        foreach my $mvb_bit (@bit_count) {
            if ( $mvb_bit =~ /(-|x)|(0)|(i)|(1)/i ) {    # possible characters of the mvb string.

                #obtain the values of control_1_data and control_2_data for the corresponding mvb bits.
                ( $data1, $data2 ) = split( /#/, $$bit_convert{$&} );

                # key 1 indicates, only one data set
                $$control_1_data_href{1} .= $data1;
                $$control_2_data_href{1} .= $data2;
            }
        }

        #convert the 32 bit binary to 4 byte hex
        $$control_1_data_href{1} = unpack(
            "H8",    # 4 byte hex string
            pack(
                "B32", $$control_1_data_href{1}    # 32 bit bin string
            )
        );

        #convert the 32 bit binary to 4 byte hex
        $$control_2_data_href{1} = unpack(
            "H8",                                  # 4 byte hex string
            pack(
                "B32", $$control_2_data_href{1}    # 32 bit bin string
            )
        );

        #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
        $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, 0 );

        return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
    }

    # error, if more than one data sets configured and both the mode selection are scalar
    if ( defined $time_us_mix and defined $nbr_of_frames_mix ) {
        if ( ref $time_us_mix ne 'ARRAY' and ref $nbr_of_frames_mix ne 'ARRAY' ) {
            S_set_error(
                "Write_mvb_format :
                1) Only one of the keys 'time_us' or 'nbr_of_frames'
                   should be defined in function 'MANITOO_write_config',
                   if only one mode has to be selected for all datasets
                   in mvb - format.

                   ( or )
                2) The Keys 'time_us' and 'nbr_of_frames' should be
                   array reference in function 'MANITOO_write_config',
                   if more than one mode has to be selected
                   for the datasets.

                   Please refer function 'MANITOO_write_config' documentation for configuration\n",
                109
            );
            return 0;
        }
    }

    #error, if the array reference size of modes does not match array reference of control data
    foreach my $mode (@modes) {
        if ( defined $mode and ref $mode eq 'ARRAY' ) {
            unless ( @$masked_value_bin_mix == @$mode ) {

                S_set_error( "Write_mvb_format : The size of array reference for keys 'time_us' or 'frames' in function 'MANITOO_write_config', should match the size of array reference for key 'masked_value_bin'\n", 109 );
                return 0;
            }
        }
    }

    #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
    $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, $#$masked_value_bin_mix );

    map { $_ =~ s/[.\s*]//g } @$masked_value_bin_mix;

    my @invalid_mvb = grep { length($_) != 32 } @$masked_value_bin_mix;

    if (@invalid_mvb) {
        local $" = ', ';
        S_set_error( "Write_mvb_format : Character count of values '@invalid_mvb' for key 'masked_value_bin' in function 'MANITOO_write_config' should be 32 each.\n", 109 );
        return 0;
    }

    @invalid_mvb = ();

    @invalid_mvb = grep { $_ =~ /[^xX\-iI01]/ } @$masked_value_bin_mix;
    if (@invalid_mvb) {
        S_set_error( "Write_mvb_format : Invalid characters found for values '@invalid_mvb' configured for key 'masked_value_bin' in function 'MANITOO_write_config', the allowed characters are 'x','X', '-', 'i', 'I', '0' or '1'.\n", 109 );
        return 0;
    }
    my $key_count = 1;

    foreach my $mvb (@$masked_value_bin_mix) {
        my @bit_count = split( //, $mvb );
        foreach my $mvb_bit (@bit_count) {
            if ( $mvb_bit =~ /(-|x)|(0)|(i)|(1)/i ) {
                ( $data1, $data2 ) = split( /#/, $$bit_convert{$&} );
                $$control_1_data_href{$key_count} .= $data1;
                $$control_2_data_href{$key_count} .= $data2;
            }
        }
        $$control_1_data_href{$key_count} = unpack(
            "H8",    # 4 byte hex string
            pack(
                "B32", $$control_1_data_href{$key_count}    # 32 bit bin string
            )
        );
        $$control_2_data_href{$key_count} = unpack(
            "H8",                                           # 4 byte hex string
            pack(
                "B32", $$control_2_data_href{$key_count}    # 32 bit bin string
            )
        );
        $key_count++;
    }

    return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
}

=head2 Write_mv_format

    Syntax :
        ( $control_1_data_href,
          $control_2_data_href,
          $mode_collection_href ) = Write_dc_format( $mask_hex
                                                     $value_hex_mix
                                                     [, $time_us_mix
                                                     $nbr_of_frames_mix] );
                                                     
This function validates and prepares the command strings
for the services 0x41, 0x42 and 0x43 when the format of the input to the
function Manitoo_write_config is in Mask Value (MV) format.

Input Arguments : 

    $mask_hex          -> hex string ( scalar ).
    
    $value_hex_mix     ->  hex string , scalar(one data set ) or aref ( > 1 data set ).
    
    $time_us_mix       -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set ).
    
    $nbr_of_frames_mix -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set ).

Note: This function is not exported.

Return Values :

    Return Values success : $control_1_data_href , $control_2_data_href and $mode_collection_href

        Example :
                    $control_1_data_href  = {
                                                '1' => 'FF00FF00',
                                                '2' => 'FF00FF00'
                                            };
                    $control_2_data_href  = {
                                                '1' => '00FF00FF',
                                                '2' => '00FF00FF'
                                            };
                    $mode_collection_href = {
                                                '1' => {
                                                        'TIME_US' => '2000000',
                                                        'MODE' => 'TIM'
                                                      },
                                                '2' => {
                                                        'TIME_US' => '2000000',
                                                        'MODE' => 'TIM'
                                                      }
                                            };
    Return Values in error : 0

Example1( Success ) : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_mv_format( '00 07 FF F8', '0000FFF7', 2000000 );

    Return Values        : $control_1_data_href  =  {
                                                        '1' => '000f3ff0',
                                                    };
                           $control_2_data_href  = {
                                                       '1' => '0004d030',
                                                    };
                           $mode_collection_href = {
                                                       '1' => {
                                                                'TIME_US' => '2000000',
                                                                'MODE' => 'TIM'
                                                              },
                                                    };

Example2( Error )    : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_mv_format( '00 07 FF F6', '0000FFF7', 2000000 );

    Error                :   Write_mv_format : The mask value '$actual_mask_hex' configured in key 'mask_hex'
                                in function 'MANITOO_write_config' should contain consecutive 1's only
    Return Value         : 0

=cut

sub Write_mv_format {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'Write_mv_format ( $mask_hex, $value_hex_mix, [, $time_us_mix, $nbr_of_frames_mix] )', @args );

    my $mask_hex             = shift;
    my $value_hex_mix        = shift;
    my $time_us_mix          = shift;
    my $nbr_of_frames_mix    = shift;
    my $mode_collection_href = {};
    my $control_1_data_href  = {};
    my $control_2_data_href  = {};
    my $mode_counter         = 1;
    my ( $data1, $data2, $actual_val_hex );
    my $val_indx = 0;
    my @modes = ( $time_us_mix, $nbr_of_frames_mix );

    if ( ref $mask_hex eq 'ARRAY' ) {
        S_set_error( "Write_mv_format : The value for key 'mask_hex' in function 'MANITOO_write_config', should be always a scalar\n", 109 );
        return 0;
    }
    my $actual_mask_hex = $mask_hex;

    $mask_hex =~ s/0x//g;
    $mask_hex =~ s/[-\s*]//g;
    my $mask_bin = unpack(
        "B32",    # 32 bit bin string
        pack(
            "H*", $mask_hex    # 4 byte hex string
        )
    );
    my @mask_bitarray = split( //, $mask_bin );
    my $mask_bit_aref = \@mask_bitarray;

    my $complete_mask_length;
    if ( $mask_bin =~ /(1)(.*)(1)/ ) {
        $complete_mask_length = length( $1 . $2 . $3 );
    }
    elsif ( $mask_bin =~ /(.*)(1)/ ) {
        $complete_mask_length = 1;
    }

    # if value is scalar
    unless ( ref $value_hex_mix eq 'ARRAY' ) {

        if ( defined $nbr_of_frames_mix and defined $time_us_mix ) {

            # error if both the keys 'time_us' and 'frames' are configured when
            # 'value_hex' is scalar
            if (    ref $nbr_of_frames_mix ne 'ARRAY'
                and ref $time_us_mix ne 'ARRAY' )
            {
                S_set_error( "Write_mv_format : Any one of the keys, either 'time_us' or 'frames' should be configured when only one data set is configured for key 'value_hex' in function 'MANITOO_write_config'.\n", 109 );
                return 0;
            }

            # error if either of the keys 'time_us' and 'frames' are aref when
            # 'value_hex' is scalar
            if (   ref $time_us_mix eq 'ARRAY'
                or ref $nbr_of_frames_mix eq 'ARRAY' )
            {
                S_set_error( "Write_mv_format : The value for keys 'time_us' or 'nbr_of_frames' should be scalar, since the value configured for key 'value_hex' is a scalar in function 'MANITOO_write_config'.\n", 109 );
                return 0;
            }
        }

        # error, if the array reference with size more than 1 is configured for 'time_us' or 'frames'
        #   for only one data set
        foreach my $mode (@modes) {
            if ( defined $mode and ref $mode eq 'ARRAY' ) {
                unless ( @$mode == 1 ) {
                    S_set_error(
                        "Write_mv_format : The size of array reference for keys
                        'time_us' or 'frames' in function 'MANITOO_write_config'
                        should be '1'(if configured as array reference).
                        ( or )
                        should be a scalar value when key 'value_hex'
                        is configured as scalar in function 'MANITOO_write_config'. \n",
                        109
                    );
                    return 0;
                }
            }
        }

        $value_hex_mix =~ s/0x//g;
        $value_hex_mix =~ s/[-\s*]//g;

        my ( $mask_hex_ctrl1, $value_hex_ctrl2 ) = Prepare_control_data( $value_hex_mix, $complete_mask_length, $mask_bit_aref );
        unless ( $mask_hex_ctrl1 or $value_hex_ctrl2 ) {
            return 0;    #error message handled in Prepare_control_data function
        }
        $$control_1_data_href{1} = $mask_hex_ctrl1;
        $$control_2_data_href{1} = $value_hex_ctrl2;

        #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
        $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, 0 );

        return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
    }

    my @value_hex_arr = ();
    my @mask_hex_arr  = ();
    my @mask_bin_arr  = ();
    my @val_bin_arr   = ();

    foreach my $val (@$value_hex_mix) {

        my ( $mask_hex_ctrl1, $value_hex_ctrl2 ) = Prepare_control_data( $val, $complete_mask_length, $mask_bit_aref );
        unless ( $mask_hex_ctrl1 or $value_hex_ctrl2 ) {
            return 0;    #error message handled in Prepare_control_data function
        }
        push( @value_hex_arr, $value_hex_ctrl2 );
        push( @mask_hex_arr,  $mask_hex_ctrl1 );

    }

    #error, if the array reference size of modes does not match array reference of control data
    foreach my $mode (@modes) {
        if ( defined $mode and ref $mode eq 'ARRAY' ) {
            unless ( @$value_hex_mix == @$mode ) {
                S_set_error( "Write_mv_format : The size of array reference for keys 'time_us' or 'frames' should match the size of array reference for key 'value_hex' in function 'MANITOO_write_config'\n", 109 );
                return 0;
            }
        }
    }

    #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
    $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, $#$value_hex_mix );

    # fill control_1_data_href and control_2_data_href hash references
    foreach ( 1 .. ( $#$value_hex_mix + 1 ) ) {

        my $value = shift(@value_hex_arr);
        my $mask  = shift(@mask_hex_arr);
        $$control_1_data_href{$_} = $mask;     # control data 1
        $$control_2_data_href{$_} = $value;    # control data 2
    }

    return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
}

=head2 Write_plv_format

    Syntax :
        ( $control_1_data_href,
          $control_2_data_href,
          $mode_collection_href ) = Write_plv_format( $bit_index,
                                                     $bit_length,
                                                     $value_hex_mix,
                                                     [, $time_us_mix,
                                                     $nbr_of_frames_mix] );

This function validates and prepares the command strings
for the services 0x41, 0x42 and 0x43 when the format of the input to the
function Manitoo_write_config is in Position Length Value (PLV) format.

Note: This function is not exported.

Input Arguments : 

    $bit_index,         -> ( 0 .. 31 ) integer.
    
    $bit_length,        -> integer.
    
    $value_hex_mix,     ->  hex string , scalar(one data set ) or aref ( > 1 data set ).
    
    $time_us_mix,       -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set ).
    
    $nbr_of_frames_mix  -> ( 0 - 268435455 dec ) scalar( one data set ) or aref ( > 1 data set ).

Return Values : 

    Return Values success :
        Example :
                    $control_1_data_href  = {
                                                '1' => 'FF00FF00',
                                                '2' => 'FF00FF00'
                                            };
                    $control_2_data_href  = {
                                                '1' => '00FF00FF',
                                                '2' => '00FF00FF'
                                            };
                    $mode_collection_href = {
                                                '1' => {
                                                        'TIME_US' => '2000000',
                                                        'MODE' => 'TIM'
                                                      },
                                                '2' => {
                                                        'TIME_US' => '2000000',
                                                        'MODE' => 'TIM'
                                                      }
                                            };
    Return Values in error : 0

Example1( Success ) : 

    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_plv_format( 16, 8, 'FA', 4000000 );

    Return Values        : $control_1_data_href  =  {
                                                        '1' => '00ff0000',
                                                    };
                           $control_2_data_href  = {
                                                       '1' => '000000fa'
                                                    };
                           $mode_collection_href = {
                                                       '1' => {
                                                                'TIME_US' => '4000000',
                                                                'MODE' => 'TIM'
                                                              },
                                                    };

Example2( Error ) : 
    
    ( $control_1_data_href,
      $control_2_data_href,
      $mode_config_href ) = Write_plv_format( '00 07 FF F6', '0000FFF7', 2000000 );

    Error                :   Write_plv_format : Any one of the keys, either 'time_us' or 'frames'
                                should be configured when only one data set is configured
                                    for key 'value_hex' in function 'MANITOO_write_config'
    Return Value         : 0

=cut

sub Write_plv_format {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'Write_plv_format ( $bit_index, $bit_length, $value_hex_mix, [, $time_us_mix, $nbr_of_frames_mix] )', @args );

    my $bit_index            = shift;    # position
    my $bit_length           = shift;    # length
    my $value_hex_mix        = shift;    # value
    my $time_us_mix          = shift;
    my $nbr_of_frames_mix    = shift;
    my $mode_collection_href = {};
    my $control_1_data_href  = {};
    my $control_2_data_href  = {};
    my $mode_counter         = 1;
    my ( $data1, $data2, $val_indx );
    my @modes = ( $time_us_mix, $nbr_of_frames_mix );

    my $mask_bin = 0 x 32;               #initialize all the mask bits to 0

    my $bit_sel = 1 x $bit_length;       # prepare a string of 1's of specified length

    # prepare the mask string by length and position.
    # 32 - ( $bit_index + $bit_length )  ------------> sets start position
    substr( $mask_bin, ( 32 - ( $bit_index + $bit_length ) ), $bit_length, $bit_sel );

    my @mask_bitarray = split( //, $mask_bin );

    # convert 32 bit binary mask to hex
    my $mask_hex = unpack( 'H8', pack( 'B32', $mask_bin ) );

    # position validation
    if ( $bit_index > 31 ) {
        S_set_error( "Write_plv_format : The value for key 'position' should be in range 0 .. 31 in function 'MANITOO_write_config'.\n", 109 );
        return 0;
    }

    # error, if the position and length to define mask exceeds 32 characters
    if ( ( $bit_index + $bit_length ) > 31 ) {
        S_set_error( "Write_plv_format : The sum of values for key 'position' and 'length' should be in range 0 .. 31 in function 'MANITOO_write_config'.\n", 109 );
        return 0;
    }

    # if the 'value_hex' is not a array ref, single data set
    unless ( ref $value_hex_mix eq 'ARRAY' ) {

        if ( defined $nbr_of_frames_mix and defined $time_us_mix ) {

            # error if both the keys 'time_us' and 'frames' are configured when
            # 'value_hex' is scalar
            if (    ref $nbr_of_frames_mix ne 'ARRAY'
                and ref $time_us_mix ne 'ARRAY' )
            {
                S_set_error( "Write_plv_format : Any one of the keys, either 'time_us' or 'frames' should be configured when only one data set is configured for key 'value_hex' in function 'MANITOO_write_config'.\n", 109 );
                return 0;
            }

            # error if either of the keys 'time_us' and 'frames' are aref when
            # 'value_hex' is scalar
            if (   ref $time_us_mix eq 'ARRAY'
                or ref $nbr_of_frames_mix eq 'ARRAY' )
            {
                S_set_error( "Write_plv_format : The value for keys 'time_us' or 'nbr_of_frames' should be scalar, since the value configured for key 'value_hex' is a scalar in function 'MANITOO_write_config'.\n", 109 );
                return 0;
            }
        }

        # error, if the array reference with size more than 1 is configured for 'time_us' or 'frames'
        #   for only one data set
        foreach my $mode (@modes) {
            if ( defined $mode and ref $mode eq 'ARRAY' ) {
                unless ( @$mode == 1 ) {
                    S_set_error(
                        "Write_plv_format : The size of array reference for keys
                        'time_us' or 'frames' in function 'MANITOO_write_config'
                        should be '1'(if configured as array reference).
                        ( or )
                        should be a scalar value when key 'value_hex'
                        is configured as scalar in function 'MANITOO_write_config'. \n",
                        109
                    );
                    return 0;
                }
            }
        }

        my $actual_val_hex = $value_hex_mix;    # variable to print the value in error message
        $value_hex_mix =~ s/0x//g;              #remove '0x'
        $value_hex_mix =~ s/[-\s*]//g;          # remove '-' and spaces

        my @actual_value_bin;

        my $val_bin = sprintf( "%b", hex($value_hex_mix) );
        my @value_bin_array = reverse split( //, $val_bin );

        my $mask_length;

        foreach my $bit ( reverse 0 .. $#mask_bitarray ) {
            if ( $mask_bitarray[$bit] == 1 and @value_bin_array != 0 ) {
                unshift( @actual_value_bin, shift(@value_bin_array) );
                $mask_length++;
            }
            elsif ( ( $mask_bitarray[$bit] == 0 and $mask_length > 0 )
                and ( @value_bin_array != 0 ) )
            {
                S_set_error("The signal value is greater than the signal mask");
                return 0;
            }
            else {
                unshift( @actual_value_bin, 0 );
            }
        }

        my $actual_val_bin = join( '', @actual_value_bin );
        $actual_val_hex = unpack( "H8", pack( "B32", $actual_val_bin ) );

        my $value_dec = hex $value_hex_mix;

        $value_hex_mix = unpack( 'H8', pack( 'N*', $value_dec ) );

        $$control_1_data_href{1} = $mask_hex;
        $$control_2_data_href{1} = $actual_val_hex;

        #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
        $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, 0 );

        return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );
    }

    # when 'value_hex' is an array ref

    map { $_ =~ s/[-\s*]//g; $_ =~ s/^0x//g } @$value_hex_mix;    #remove '0x', '-' and spaces
    $val_indx = 0;
    map { $_ =~ s/[-\s*]//g; $_ =~ s/^0x//g } @$value_hex_mix;
    my @invalid_val_ctrl1 = grep { hex $_ > 4294967295 } (@$value_hex_mix);    # collect the values not in range

    my @actual_value_bin;
    my $val_bin = sprintf( "%b", hex( $$value_hex_mix[$val_indx] ) );

    my @value_bin_array = reverse split( //, $val_bin );
    my $mask_length;
    foreach my $bit ( reverse 0 .. $#mask_bitarray ) {
        if ( $mask_bitarray[$bit] == 1 and @value_bin_array != 0 ) {
            unshift( @actual_value_bin, shift(@value_bin_array) );
            $mask_length++;
        }
        elsif ( ( $mask_bitarray[$bit] == 0 and $mask_length > 0 )
            and ( @value_bin_array != 0 ) )
        {
            S_set_error("The signal value is greater than the signal mask");
            return;
        }
        else {
            unshift( @actual_value_bin, 0 );
        }
    }

    my $actual_val_bin = join( '', @actual_value_bin );
    my $actual_val_hex = unpack( "H8", pack( "B32", $actual_val_bin ) );

    # error, if the value configured for key 'value_hex' out of range
    if (@invalid_val_ctrl1) {
        local $" = ', ';
        S_set_error( "Write_plv_format : The values [ @invalid_val_ctrl1 ] configured for the key 'value_hex' should be in range 00000000 - FFFFFFFF in function 'MANITOO_write_config'\n", 109 );
        return 0;
    }

    #error, if the array reference size of modes does not match array reference of control data
    foreach my $mode (@modes) {
        if ( defined $mode and ref $mode eq 'ARRAY' ) {
            unless ( @$value_hex_mix == @$mode ) {
                S_set_error( "Write_plv_format : The size of array reference for keys 'time_us' or 'frames' should match the size of array reference for key 'value_hex' in function 'MANITOO_write_config'\n", 109 );
                return 0;
            }
        }
    }

    #call function Mode_config to collect the mode and the corresponding frames or time depending on mode.
    $mode_collection_href = Mode_config( $time_us_mix, $nbr_of_frames_mix, $#$value_hex_mix );

    my $key_count = 1;

    map { $_ = unpack( 'H8', pack( 'N*', hex $_ ) ) } @$value_hex_mix;

    # fill control_1_data_href and control_2_data_href hash references
    foreach ( 1 .. ( $#$value_hex_mix + 1 ) ) {
        $$control_1_data_href{$_} = $mask_hex;          # control data 1
        $$control_2_data_href{$_} = $actual_val_hex;    # control data 2
    }

    return ( $control_1_data_href, $control_2_data_href, $mode_collection_href );

}

=head2 Mode_config

    Syntax : $mode_collection_href = Mode_config ( $time_us_mix, $nbr_of_frames_mix, $size );

This function prepares the arguments for the function
MANITOO_cmd_write_DataCtrl_ModeTime as hash ref 'mode_collection_href'

Input parameters :
    $time_us_mix -> ( 0 - 268435455 dec ) time in micro seconds.
                    SCALAR -> same time value for all data sets
                    ARRAY -> different time value for each data set
    $nbr_of_frames_mix -> ( 0 - 268435455 dec ) number of frames.
                    SCALAR -> same nbr of frames for all data sets
                    ARRAY -> different nbr of frames for each data set
    $size -> integer, ( number of data sets )

Note: 

    This function is called by functions either :
          'Write_mvb_format' or
          'Write_dc_format' or
          'Write_mv_format' or
          'Write_plv_format'.

    This function is not Exported.

Input Arguments : 

    $time_us : integer, time in micro seconds.
    
    $nbr_of_frames : integer, number of frames.
    
    $size : integer, number of data sets.
    
Return Values : $mode_collection_href;

        Example     : $mode_collection_href = {
                                                '1' => {
                                                           'FRAMES' => 3000,
                                                           'MODE' => 'SPI'
                                                       },
                                                '2' => {
                                                           'FRAMES' => 2000,
                                                           'MODE' => 'SPI'
                                                       }
                                              };
Return Values in Error: 0.

Example1 ( Success ) : 

    $mode_collection_href = Mode_config ( 2000000, 0 );

    Return Value         : $mode_collection_href =  {
                                                       '1' => {
                                                                'TIME_US' => 20000000,
                                                                'MODE' => 'TIM'
                                                              }
                                                    };

=cut

sub Mode_config {

    my @args = @_;
    return ( 0, [] ) unless S_checkFunctionArguments( 'Mode_config ( [, $time_us_mix, $nbr_of_frames_mix ], $size, )', @args );

    my $time_us_mix          = shift;
    my $nbr_of_frames_mix    = shift;
    my $size                 = shift;
    my $mode_collection_href = {};
    my $mode_counter         = 1;

    $nbr_of_frames_mix = [] unless defined $nbr_of_frames_mix;
    $time_us_mix       = [] unless defined $time_us_mix;
    $size              = 0  unless defined $size;

    if ( ( defined $time_us_mix and defined $nbr_of_frames_mix ) and ( ref $time_us_mix eq 'ARRAY' and ref $nbr_of_frames_mix eq 'ARRAY' ) ) {
        foreach my $index ( 0 .. $#$time_us_mix ) {

            #error, if both frames and time_us values are not numeric when more than one mode is used
            if (
                ( $$time_us_mix[$index] =~ /^FRAMES$/i and $$nbr_of_frames_mix[$index] =~ /^TIME_US$/i )
                or (    $$time_us_mix[$index] =~ /^\d+$/i
                    and $$nbr_of_frames_mix[$index] =~ /^\d+/i )
              )
            {
                S_set_error( "Mode_config : Both the values at index '$index' for keys 'time_us' and 'nbr_of_frames' are wrong, either of two should be integer in function 'MANITOO_write_config'.\n", 109 );
                return 0;
            }
        }
    }

    #error, if the time_us contains non numeric values when only TIM mode is used
    if (    defined $time_us_mix
        and $nbr_of_frames_mix eq ''
        and $time_us_mix eq 'ARRAY' )
    {

        my @check_string =
          grep { $_ =~ /^\D+$/ } @$time_us_mix;    # match only non-numeric values
        if (@check_string) {
            S_set_error( "Mode_config : All the values should be integer for the key 'time_us' when only one type of mode is configured in function 'MANITOO_write_config'.\n", 109 );
            return 0;
        }
    }

    #error, if the frames contains non numeric values when only SPI mode is used
    if (    defined $nbr_of_frames_mix
        and $time_us_mix eq ''
        and $nbr_of_frames_mix eq 'ARRAY' )
    {

        my @check_string = grep { $_ =~ /^\D+$/ } @$nbr_of_frames_mix;    # match only non-numeric values
        if (@check_string) {
            S_set_error( "Mode_config : All the values should be integer for the key 'nbr_of_frames' when only one type of mode is configured in function 'MANITOO_write_config'.\n", 109 );
            return 0;
        }
    }

    # fill hash with tim mode and time for scalar
    if ( defined $time_us_mix and ref $time_us_mix ne 'ARRAY' ) {
        foreach ( 0 .. $size ) {
            $$mode_collection_href{$mode_counter}{'MODE'} = 'TIM';
            $$mode_collection_href{ $mode_counter++ }{'TIME_US'} = $time_us_mix;
        }
    }

    # fill hash with tim mode and time for array reference
    elsif ( defined $time_us_mix and ref $time_us_mix eq 'ARRAY' ) {
        $mode_counter = 1;
        map {
            if ( $_ =~ /^\d+$/ ) {    # match only numeric values
                $$mode_collection_href{$mode_counter}{'MODE'} = 'TIM';
                $$mode_collection_href{ $mode_counter++ }{'TIME_US'} = $_;
            }
            else { $mode_counter++; }
        } @$time_us_mix;
    }

    # fill hash with spi mode and frames for scalar
    if ( defined $nbr_of_frames_mix and ref $nbr_of_frames_mix ne 'ARRAY' ) {
        foreach ( 0 .. $size ) {
            $$mode_collection_href{$mode_counter}{'MODE'} = 'SPI';
            $$mode_collection_href{ $mode_counter++ }{'FRAMES'} = $nbr_of_frames_mix;
        }
    }

    # fill hash with spi mode and frames for array reference
    elsif ( defined $nbr_of_frames_mix and ref $nbr_of_frames_mix eq 'ARRAY' ) {
        $mode_counter = 1;
        map {
            if ( $_ =~ /^\d+$/ ) {    # match only numeric values
                $$mode_collection_href{$mode_counter}{'MODE'} = 'SPI';
                $$mode_collection_href{ $mode_counter++ }{'FRAMES'} = $_;
            }
            else { $mode_counter++; }
        } @$nbr_of_frames_mix;
    }
    return $mode_collection_href;
}

=head2 Type_error

    Syntax : Type_error ([, $type]);

This function throws the error when,
1. None of the formats for the function MANITOO_write_config are configured.
        ( or )
2. More than one format is configured in the function MANITOO_write_config.

Note: 

    This function is not exported.

Input Arguments : 

    $type -> integer, (passed when more than one format is defined in MANITOO_write_config ).

Return Values : 0 (Always).

=cut

sub Type_error {

    my @args = @_;
    return ( 0, [] )
      unless S_checkFunctionArguments( 'Type_error ([,$type])', @args );

    my $type = shift;

    my $error_string = "
                        1) Data Control Format (DC-Format)
                        'data_control_1' and 'data_control_2'
                                        ( or )
                        2) Masked Value Bin Format ( MVB-Format )
                        'masked_value_bin'
                                        ( or )
                        3) Mask + Value Format ( MV-Format )
                        'mask_hex' and 'value_hex'
                                        ( or )
                        4) Postion + Length + Value Format ( PLV-Format )
                        'position', 'length', 'value_hex'\n";

    if ( defined $type ) {
        S_set_error( "MANITOO_write_config : Any 'one' format of the following type of arguments should be defined in function 'MANITOO_write_config' : $error_string \n", 109 );
        return 0;
    }
    else {
        S_set_error( "MANITOO_write_config : Only 1 format can be chosen with 1 function call. More than 'one' format of the following type of arguments defined in function 'MANITOO_write_config': $error_string \n", 109 );
        return 0;
    }

}

=head2 Validate_write_inputs

    Syntax : Validate_write_inputs ( $write_input_href );

This function validates the input parameters to the
function Manitoo_write_config.

Note: This function is not exported.

Input Arguments: 

    $write_input_href = {
                            'spi_manipulation_module' => $spi_manipulation_module_int,    # for all

                            'time_us' => $time_us ,           # for TIM mode, service 41
                            'frames' => $nbr_of_frames ,      # for SPI mode, service 41

                            'data_control_1' => $data_control_1 ,     # for 42
                            'data_control_2' => $data_control_2 ,     # for 43

                            'masked_value_bin' =>  $masked_value_bin ,    # for 42 and 43

                            'mask_hex' => $mask_hex ,       # for 42 and 43

                            'position' => $bit_position,    # for 42 and 43
                            'length' => $signal_length,     # for 42 and 43

                            'value_hex' => $value,          # for 42 and 43
                        };

Return Value in success : 1.

Return Value in error : 0.

=cut

sub Validate_write_inputs {

    my @args = @_;

    return ( 0, [] )
      unless S_checkFunctionArguments( 'Validate_write_inputs ( $write_input_href )', @args );

    my $write_input_href = shift;

    my $spi_manipulation_module_int = $write_input_href->{'spi_manipulation_module'};    # SPI manipulation module in integer
    my $time_us                     = $write_input_href->{'time_us'};                    # time in micro seconds
    my $nbr_of_frames               = $write_input_href->{'frames'};                     # number of SPI frames in integer
    my $data_control_1              = $write_input_href->{'data_control_1'};             # 4 byte hex string of control data
    my $data_control_2              = $write_input_href->{'data_control_2'};             # 4 byte hex string of data
    my $masked_value_bin            = $write_input_href->{'masked_value_bin'};           # masked value in 32 bit binary string
    my $bit_index                   = $write_input_href->{'position'};                   # bit position of the data to be manipulated in integer
    my $bit_length                  = $write_input_href->{'length'};                     # bit length of the data to be manipulated in integer
    my $value_hex                   = $write_input_href->{'value_hex'};                  # data value in hex
    my $mask_hex                    = $write_input_href->{'mask_hex'};                   # mask value in hex

    my $mode_flag = 0;

    # hash to check the dependent parameters are configured
    my $validate_hash = {
        'data_control_1' => 'data_control_2',
        'data_control_2' => 'data_control_1',
        'mask_hex'       => 'value_hex',
        'position'       => 'length#value_hex',
        'length'         => 'position#value_hex',
    };

    # error, if the dependent parameters for the specific format are not defined
    foreach my $key ( keys %$write_input_href ) {
        if ( defined( $$validate_hash{$key} ) ) {

            my $value = $$validate_hash{$key};

            if ( $value !~ /#/ ) {    # only one parameter dependent
                if ( !exists( $$write_input_href{$value} ) ) {
                    S_set_error( "Validate_write_inputs : Key '$value' should be defined, when the key $key is defined in function 'MANITOO_write_config'.\n", 109 );
                    return 0;
                }
            }
            elsif ( $value =~ /#/ ) {    # more than one parameter dependent
                my @dependent_keys = split( /#/, $value );
                my @keys_to_be_defined =
                  grep { $$write_input_href{$_} eq '' } @dependent_keys;

                #error, when the dependent parameters are not defined
                if (@keys_to_be_defined) {
                    S_set_error( "Validate_write_inputs : Key(s) '@keys_to_be_defined' should be defined, when the key '$key' is defined in function 'MANITOO_write_config'.\n", 109 );
                    return 0;
                }
            }
        }
    }

    # validate time_us
    if ( defined $time_us ) {
        if (    ( $time_us < 0 or $time_us > 268435455 )
            and ( ref $time_us ne 'ARRAY' ) )
        {
            S_set_error( "Validate_write_inputs : The value configured for the key 'time_us' should be in range 0 - 268435455 micro seconds in function 'MANITOO_write_config'\n", 109 );
            return 0;
        }
        if ( ref $time_us eq 'ARRAY' ) {
            my @invalid_values =
              grep { $_ if ( $_ =~ /^\d+$/ and $_ > 268435455 ) } @$time_us;
            if (@invalid_values) {
                local $" = ', ';
                S_set_error( "Validate_write_inputs : The values [ @invalid_values ]configured for the key 'time_us' should be in range 0 - 268435455 micro seconds in function 'MANITOO_write_config'\n", 109 );
                return 0;
            }
        }
        $mode_flag = 1;
    }

    # validate frames
    if ( defined $nbr_of_frames ) {

        if (    ( $nbr_of_frames < 0 or $nbr_of_frames > 268435455 )
            and ( ref $nbr_of_frames ne 'ARRAY' ) )
        {
            S_set_error( "Validate_write_inputs : The value configured for the key 'frames' should be in range 0- 268435455 frames in function 'MANITOO_write_config'\n", 109 );
            return 0;
        }

        if ( ref $nbr_of_frames eq 'ARRAY' ) {
            my @invalid_values =
              grep { $_ if ( $_ =~ /^\d+$/ and $_ > 268435455 ) } @$nbr_of_frames;
            if (@invalid_values) {
                local $" = ', ';
                S_set_error( "Validate_write_inputs : The values [ @invalid_values ]configured for the key 'frames' should be in range 0 - 268435455 frames in function 'MANITOO_write_config'\n", 109 );
                return 0;
            }
        }
        $mode_flag = 1;
    }

    # error if neither 'time_us' or 'frames' is configured
    unless ($mode_flag) {
        S_set_error( "Validate_write_inputs : Atleast any one of the key(s) 'time_us' or 'frames' should be configured for the mode selection in function 'MANITOO_write_config'\n", 109 );
        return 0;
    }

    if ( defined $value_hex ) {
        if ( $mask_hex eq '' and ( $bit_index eq '' and $bit_length eq '' ) ) {
            S_set_error( "Validate_write_inputs : when the key 'value_hex' is configured, then the Key 'mask_hex' should be configured for MV format (or) keys 'position' and 'length' should be configured for PLV format in function 'MANITOO_write_config'\n", 109 );
            return 0;
        }
    }
    return 1;
}

=head2 Init_process_data

    Init_process_data();

Non export function.

This function prepares the data in the PAS command format for the init phase 1, 3 and Cyclic messages.

=cut

sub Init_process_data {

    my $init_data_href       = shift;
    my $max_number_elements  = shift;
    my $init_type            = shift;
    my $enable_sensor_str    = 'on';
    my $reset_Loop_int       = 0;
    my $manchester_fault_int = 0;
    my $parity_fault_int     = 0;
    my $data_value_hex       = '0000';
    my $data_aref            = [];
    my $data_value_dec       = 0;

    foreach my $data_element ( 1 .. $max_number_elements ) {

        if ( exists $init_data_href->{$data_element}->{'Enable_sensor_str'} ) {
            $enable_sensor_str = $init_data_href->{$data_element}->{'Enable_sensor_str'};
        }
        elsif ( defined $init_type and $init_type eq 'init_1' ) {
            $enable_sensor_str = 'off';
        }
        else {
            $enable_sensor_str = 'on';
        }

        if ( exists $init_data_href->{$data_element}->{'Reset_loop_int'} ) {
            $reset_Loop_int = $init_data_href->{$data_element}->{'Reset_loop_int'};
        }
        elsif ( $data_element == $max_number_elements ) {
            $reset_Loop_int = 1;
        }
        else {
            $reset_Loop_int = 0;
        }

        if ( exists $init_data_href->{$data_element}->{'Manchester_fault_int'} ) {
            $manchester_fault_int = $init_data_href->{$data_element}->{'Manchester_fault_int'};
            if ( $manchester_fault_int == 1 and $init_type eq 'init_1' ) {
                $enable_sensor_str = 'on';
            }
        }
        else {
            $manchester_fault_int = 0;
        }

        if ( exists $init_data_href->{$data_element}->{'Parity_fault_int'} ) {
            $parity_fault_int = $init_data_href->{$data_element}->{'Parity_fault_int'};
            if ( $parity_fault_int == 1 and $init_type eq 'init_1' ) {
                $enable_sensor_str = 'on';
            }
        }
        else {
            $parity_fault_int = 0;
        }

        if ( exists $init_data_href->{$data_element}->{'Data_value_hex'} ) {
            $data_value_dec = sprintf( "%d",   hex $init_data_href->{$data_element}->{'Data_value_hex'} );
            $data_value_hex = sprintf( "%.3X", $data_value_dec );
        }
        else {
            $data_value_hex = '000';
        }

        $enable_sensor_str =~ s/on/8/;     # replace 'on' with dec value 8  ------> 1000 ...
        $enable_sensor_str =~ s/off/0/;    # replace 'off' with dec value 0  ------> 0000 ...
                                           # Note : $reset_Loop_int is last bit of 1st nibble
                                           #         1 or 0 will be added

        my $data_1 = sprintf( "%.1X", ( $enable_sensor_str + $reset_Loop_int ) );    # prepare hex string for enable/disable sensor and reset loop

        $manchester_fault_int =~ s/1/2/;                                             # replace '1' with dec value 2  ------> 0010 ...
                                                                                     # Note : $parity_fault_int is last bit of 1st nibble
                                                                                     #         1 or 0 will be added

        my $data_2 = sprintf( "%.1X", ( $manchester_fault_int + $parity_fault_int ) );    # prepare hex string for manchester and parity fault

        my $data_element_hex = ( $data_1 . $data_2 . '000' . $data_value_hex );           # complete hex string containing ID and data

        push( @$data_aref, $data_element_hex );
    }

    return $data_aref;
}

=head2 Prepare_control_data

    NON export function , which prepares the mask and value for the hex and decimal values when configured with MV format.

    Returns : $mask_hex, $value_hex
    
=cut

sub Prepare_control_data {

    my $val                  = shift;
    my $complete_mask_length = shift;
    my $mask_bit_aref        = shift;
    my @mask_bitarray        = @$mask_bit_aref;
    my @value_hex_arr        = ();
    my @mask_hex_arr         = ();
    my @mask_bin_arr         = ();
    my @val_bin_arr          = ();

    my ( @actual_value_bin, $val_bin );

    if ( $val =~ /^0x/ ) {
        $val =~ s/^0x//;
        $val_bin = sprintf( "%b", hex($val) );
    }
    else {
        $val_bin = sprintf( "%b", ($val) );
    }

    my @value_bin_array = reverse split( //, $val_bin );
    my $value_length    = length $val_bin;
    my $mask_length     = 0;

    my $counter_mask = $complete_mask_length;
    foreach my $bit ( reverse 0 .. $#mask_bitarray ) {
        if ( $mask_bitarray[$bit] == 1 and @value_bin_array != 0 ) {

            push( @mask_bin_arr, 1 );
            my $value_bit;
            $value_bit = shift(@value_bin_array);
            push( @val_bin_arr, 0 ) if ( $value_bit == 0 );
            push( @val_bin_arr, 1 ) if ( $value_bit == 1 );

            $mask_length++;
            $counter_mask--;
        }
        elsif ( ( $mask_bitarray[$bit] == 0 and $mask_length < $complete_mask_length and $mask_length > 0 )
            and ( @value_bin_array != 0 ) )
        {
            push( @mask_bin_arr, 0 );
            push( @val_bin_arr,  0 );
            shift(@value_bin_array) if ( $mask_length > 0 );
            $counter_mask--;
        }

        elsif ( ( $mask_bitarray[$bit] == 1 )
            and ( @value_bin_array == 0 ) )
        {
            push( @mask_bin_arr, 1 );
            push( @val_bin_arr,  0 );

            $mask_length++;
            $counter_mask--;
        }

        elsif ( ( $mask_bitarray[$bit] == 0 and $counter_mask == 0 )
            and ( @value_bin_array != 0 ) )
        {
            S_set_error( "The signal value '$val' is greater than the signal mask", 109 );
            return;
        }
        else {
            push( @mask_bin_arr, 0 );
            push( @val_bin_arr,  0 );
        }
    }

    my $act_mask_bin = join( '', reverse @mask_bin_arr );
    my $act_val_bin  = join( '', reverse @val_bin_arr );
    my $mask_hex     = 0;
    my $value_hex    = 0;
    $value_hex = unpack( "H8", pack( "B32", $act_val_bin ) );
    $mask_hex  = unpack( "H8", pack( "B32", $act_mask_bin ) );

    return ( $mask_hex, $value_hex );

}

=head2 Process_fet_type

    ( $fet_device, $ports_href ) = Process_fet_type($fet_TypeName,
                                                     $ports_mix,
                                                     $port_status,
                                                    );

B<NON EXPORTED FUNCTION>

This function processes the arguments for Fet type given and returns the fet device id and ports.

B<Arguments:>

=over

=item $fet_TypeName

Fet type name (FET_3_Ports , FET_6_Ports, FET_15_Ports)

=item $ports_mix

port numbers ( 1, 2, 3 ..).

=item $port_status

port status to be switched ON or OFF.

=back

B<Return>

=over

=item ( $fet_device, $ports_href )

Fet device Id and ports

=back

B<Example:>

( $fet_device, $ports_href ) = Process_fet_type( 'FET_3_Ports', [1,2], 'ON' );

=cut

sub Process_fet_type {

    my $fet_TypeName = shift;
    my $ports_mix    = shift;
    my $port_status  = shift;
    my $fet_device   = $fet_type_href->{$fet_TypeName};
    my $ports_href   = {};
    my @fet_types    = keys %$fet_type_href;

    unless ( $fet_TypeName =~ /FET_(3|6|15)_Ports/i ) {
        S_set_error( "Process_fet_type: FET type '$fet_TypeName' configured is incorrect, supported values ( @fet_types )", 109 );
        return;
    }

    my $fet_NumberOfports = $1;    # number of ports

    if ( ( ref $ports_mix eq 'ARRAY' and @$ports_mix == 0 ) or ( $ports_mix eq undef or $ports_mix eq '' ) ) {
        S_set_warning('no port number defined in Testbench, default port 1 will be considered');
        $ports_href->{1} = $port_status;
        return ( $fet_device, $ports_href );    #by default port 1 will be switched on/off if the port number is not configured in test bench
    }

    if ( ref($ports_mix) eq 'ARRAY' ) {
        foreach my $port (@$ports_mix) {
            if ( $port > $fet_NumberOfports or $port < 1 ) {
                S_set_error( "Process_fet_type:: Manitoo Port number '$port' configured is incorrect, port number should be in the range (1 .. $fet_NumberOfports)!", 109 );
                return;
            }
            $ports_href->{$port} = $port_status;
        }
        return ( $fet_device, $ports_href );
    }
    elsif ( $ports_mix > $fet_NumberOfports or $ports_mix < 1 ) {
        S_set_error( "Process_fet_type:: Manitoo Port number '$ports_mix' configured is incorrect, port number should be in the range (1 .. $fet_NumberOfports)!", 109 );
        return;
    }
    else {
        $ports_href->{$ports_mix} = $port_status;
        return ( $fet_device, $ports_href );
    }
}

=head2 Parse_SPI_Trace_Lines

    $measurementXML_mix = Parse_SPI_Trace_Lines($trace_data_aref, $measurementXML_mix);

B<NON EXPORTED FUNCTION>

This function parses the log file and prepares the data for the following attributes:

    'MessageNumber' -> 'Time' -> 'MOSI_Hex' -> 'MISO_Hex' -> 'ChipSelect' -> 'FrameLength_Bits' -> 'ToolsID' -> 'FrameManipulated'


B<Arguments:>

=over

=item $trace_data_aref

array reference containing the trace data.

=item $measurementXML_mix

XML handle to fill the trace data

=back

B<Return>

=over

=item $measurementXML_mix 

xml handle filled with trace data according to messages.

'MessageNumber' , 'Time' , 'MOSI_Hex' , 'MISO_Hex' , 'ChipSelect' , 'FrameLength_Bits' , 'ToolsID' , 'FrameManipulated'

=back

B<Example:>

$measurementXML_mix = Parse_SPI_Trace_Lines([bf2001010100000000000023c3620000000000000000009f000000001523c2ff, ..], $measurementXML_mix);

B<Note:>

To be called by device layer function 'MANITOO_trace_load_file'.

=cut

sub Parse_SPI_Trace_Lines {

    my @args               = @_;
    my $trace_data_aref    = shift @args;
    my $measurementXML_mix = shift @args;
    return unless S_checkFunctionArguments( 'Parse_SPI_Trace_Lines( $trace_data_aref, $measurementXML_mix )', ( $trace_data_aref, $measurementXML_mix ) );
    my $frame_data_href             = {};
    my $msg_length_grt_than_64_bits = 0;
    my $previous_frame_toggle       = 'first_frame';
    my $previous_frame_manip        = 'false';
    my $msg_num_int                 = 0;
    my $time_ms;

    # parse the summary XML file and get the reference of Document root element
    my $parser = XML::LibXML->new();

    # important for formatting
    $parser->keep_blanks(0);

    # get the reference to root element
    my $rootElement = $measurementXML_mix->documentElement;

    my $size_of_mbt_frames = @$trace_data_aref;

    #LOOP-START loop over all frames in the trace
    my $counter = 0;
    foreach my $line (@$trace_data_aref) {
        $counter++;
        chomp($line);
        my $frame_data_aref = [ grep { $_ ne '' } ( split( /(..)/, $line ) ) ];

        #STEP fetch spi frame details CS,frame manipulated, ToolsID, Time_ms
        # fill frame manipulated info
        my $num_of_bytes_in_msg    = ( hex $frame_data_aref->[1] ) / 8;
        my $frame_manipulated_bool = 'false';                                                                        # default as false
        my $frameManip_aref        = [ split( //, $frame_data_aref->[$BYTE_NBR_FRAME_MANIP_AND_MSG_INDICATOR] ) ];
        $frame_manipulated_bool = 'true' if ( $frameManip_aref->[0] == 1 );

        #STEP add SPI message to xml if toggle frame is changed
        my $toggle_bit = hex $frameManip_aref->[1];
        if ( $previous_frame_toggle ne 'first_frame' and ( $previous_frame_toggle != $toggle_bit or $previous_frame_manip ne $frame_manipulated_bool ) ) {
            $measurementXML_mix = Add_MeasurementPointToXML( $measurementXML_mix, $rootElement, $frame_data_href );
        }

        $frame_data_href->{'FrameManipulated'} = $frame_manipulated_bool;

        # fill Tools ID
        my $tools_id_int = sprintf( "%d", hex $frame_data_aref->[$BYTE_NBR_TOOLS_ID] );
        $frame_data_href->{'ToolsID'} = $tools_id_int;

        # fill chipselect info
        my $chip_select_bin = reverse sprintf( "%.8b", hex $frame_data_aref->[$BYTE_NBR_CHIPSELECT] );
        $chip_select_bin =~ /0/;
        my $chipselect_int = $-[0];
        $frame_data_href->{'ChipSelect'} = $chipselect_int;

        # fill message number
        if ( ( $previous_frame_toggle != $toggle_bit ) or ( $previous_frame_manip ne $frame_manipulated_bool ) ) {
            ++$msg_num_int;
        }

        $frame_data_href->{'MessageNumber'} = $msg_num_int;

        # fill time
        if ( $previous_frame_toggle eq 'first_frame' or ( $previous_frame_toggle != $toggle_bit ) or ( $previous_frame_manip ne $frame_manipulated_bool ) ) {
            my @time_us_bytes = @$frame_data_aref[ $BYTE_NBR_TIME_US .. ( $BYTE_NBR_TIME_US + $OFFSET_BYTE_LENGTH ) ];
            my $time_us = join( '', reverse(@time_us_bytes) );
            $time_us = sprintf( "%u", hex $time_us );

            $time_ms = $time_us * 0.001;
            $frame_data_href->{'Time'} = $time_ms;
        }

        #CALL Trace_prepare_mosi_and_miso_data to fetch mosi and miso data to spi frame
        # fill mosi data and miso data
        my @mosi_bytes = @$frame_data_aref[ $BYTE_START_NBR_MOSI_FRAME .. $BYTE_END_NBR_MOSI_FRAME ];
        Trace_prepare_mosi_and_miso_data( \@mosi_bytes, $num_of_bytes_in_msg, 'MOSI', $previous_frame_toggle, $toggle_bit, $frame_data_href, $frame_manipulated_bool, $previous_frame_manip );

        # fill miso data
        my @miso_bytes = @$frame_data_aref[ $BYTE_START_NBR_MISO_FRAME .. $BYTE_END_NBR_MISO_FRAME ];
        Trace_prepare_mosi_and_miso_data( \@miso_bytes, $num_of_bytes_in_msg, 'MISO', $previous_frame_toggle, $toggle_bit, $frame_data_href, $frame_manipulated_bool, $previous_frame_manip );

        #fill frame length bits
        $frame_data_href->{'FrameLength_Bits'} = ( length $frame_data_href->{'MOSI_Hex'} ) * 4;
        $previous_frame_toggle                 = $toggle_bit;
        $previous_frame_manip                  = $frame_manipulated_bool;
    }
    if ( $counter == $size_of_mbt_frames ) {
        $measurementXML_mix = Add_MeasurementPointToXML( $measurementXML_mix, $rootElement, $frame_data_href );
    }

    #LOOP-END last frame?
    #STEP END
    return $measurementXML_mix;
}

=head2 Trace_prepare_mosi_and_miso_data

    $frame_data_href = Trace_prepare_mosi_and_miso_data( 
                                                         $databyte_aref,
                                                         $num_of_bytes_in_msg,
                                                         $msg_type,
                                                         $previous_frame_toggle,
                                                         $toggle_bit,
                                                         $frame_data_href
                                                       );

B<NON EXPORTED FUNCTION>

This function prepares the data for the following attributes:

    'MOSI_Hex' and 'MISO_Hex'

At once only one type of data is filled. Either mosi or miso.


B<Arguments:>

=over

=item $databyte_aref

data bytes of MOSI or MISO data

=item $num_of_bytes_in_msg

number of data bytes based on the message length

=item $msg_type

type of message MOSI or MISO

=item $previous_frame_toggle

toggle bit value of the previous message

=item $toggle_bit

current toggle bit value of the message

=item $frame_data_href

href filled with mosi or miso data

=back

B<Return>

=over

=item $frame_data_href 

href filled with the data for the attributes:

'MOSI_Hex' or 'MISO_Hex'

=back

B<Note:>

To be called by device layer function 'MANITOO_trace_load_file'.

=cut

sub Trace_prepare_mosi_and_miso_data {
    my @args                  = @_;
    my $databyte_aref         = shift @args;
    my $num_of_bytes_in_msg   = shift @args;
    my $msg_type              = shift @args;
    my $previous_frame_toggle = shift @args;
    my $toggle_bit            = shift @args;
    my $frame_data_href       = shift @args;
    my $current_frame_manip   = shift @args;
    my $previous_frame_manip  = shift @args;
    return
      unless S_checkFunctionArguments( 'Trace_prepare_mosi_and_miso_data( $databyte_aref, $num_of_bytes_in_msg, $msg_type, $previous_frame_toggle, $toggle_bit, $frame_data_href )', ( $databyte_aref, $num_of_bytes_in_msg, $msg_type, $previous_frame_toggle, $toggle_bit, $frame_data_href ) );

    my $data_hex  = join( '', @$databyte_aref );
    my @msb_bytes = @$databyte_aref[ 0 .. 3 ];
    my @lsb_bytes = @$databyte_aref[ 4 .. 7 ];
    my @temp_arr  = ( @lsb_bytes, @msb_bytes );
    $data_hex = join( '', reverse @temp_arr[ 0 .. ( $num_of_bytes_in_msg - 1 ) ] );

    if ( $previous_frame_toggle == $toggle_bit and $previous_frame_manip eq $current_frame_manip ) {
        $frame_data_href->{ "$msg_type" . '_Hex' } .= $data_hex;
    }
    else {
        $frame_data_href->{ "$msg_type" . '_Hex' } = $data_hex;
    }

    return 1;
}

=head2 Add_MeasurementPointToXML

    $measurementXML_mix = Add_MeasurementPointToXML( $measurementXML_mix,
                                                      $rootElement,
                                                      $parsedSPItraceLine_href
                                                    );

B<NON EXPORTED FUNCTION>

This function parses the log file and prepares the data for the following attributes:

    'MessageNumber' -> 'Time' -> 'MOSI_Hex' -> 'MISO_Hex' -> 'ChipSelect' -> 'FrameLength_Bits' -> 'ToolsID' -> 'FrameManipulated'


B<Arguments:>

=over

=item $measurementXML_mix

XML handle for the measurement data

=item $rootElement

reference to the root element in XML

=item $parsedSPItraceLine_href

Parsed data to be added as measurement point to the XML

=back

B<Return>

=over

=item $frame_data_href 

Href filled with the data for the attributes:

'MessageNumber' , 'Time' , 'MOSI_Hex' , 'MISO_Hex' , 'ChipSelect' , 'FrameLength_Bits' , 'ToolsID' , 'FrameManipulated'

=back

B<Example:>

    $frame_data_href = Add_MeasurementPointToXML( $measurementXML_mix,
                                                   $rootElement,
                                                   $parsedSPItraceLine_href
                                                 );

B<Note:>

To be called by device layer function 'MANITOO_trace_load_file'.

=cut

sub Add_MeasurementPointToXML {

    my @args = @_;

    my $measurementXML_mix      = shift @args;
    my $rootElement_mix         = shift @args;
    my $parsedSPItraceLine_href = shift @args;

    return unless S_checkFunctionArguments( 'Add_MeasurementPointToXML( $measurementXML_mix, $rootElement_mix, $parsedSPItraceLine_href )', ( $measurementXML_mix, $rootElement_mix, $parsedSPItraceLine_href ) );

    my $measurementPointNode = $measurementXML_mix->createElement("MeasurementPoint");
    $measurementPointNode->setAttribute( "MessageNumber",    $parsedSPItraceLine_href->{'MessageNumber'} );
    $measurementPointNode->setAttribute( "Time",             $parsedSPItraceLine_href->{'Time'} );
    $measurementPointNode->setAttribute( "MOSI_Hex",         $parsedSPItraceLine_href->{'MOSI_Hex'} );
    $measurementPointNode->setAttribute( "MISO_Hex",         $parsedSPItraceLine_href->{'MISO_Hex'} );
    $measurementPointNode->setAttribute( "ChipSelect",       $parsedSPItraceLine_href->{'ChipSelect'} );
    $measurementPointNode->setAttribute( "FrameLength_Bits", $parsedSPItraceLine_href->{'FrameLength_Bits'} );
    $measurementPointNode->setAttribute( "ToolsID",          $parsedSPItraceLine_href->{'ToolsID'} );
    $measurementPointNode->setAttribute( "FrameManipulated", $parsedSPItraceLine_href->{'FrameManipulated'} );
    $rootElement_mix->appendChild($measurementPointNode);

    return $measurementXML_mix;
}

sub Version_Check_PAS {

    if (    hex $global_Version_nbr_3byte_string >= hex $global_Version_nbr_for_PAS_min
        and hex $global_Version_nbr_3byte_string <= hex $global_Version_nbr_for_PAS_max )
    {
        return 1;
    }

    S_set_error( "wrong Firmware version for Manitoo PAS functions : " . "MIN: $global_Version_nbr_for_PAS_min MAX:$global_Version_nbr_for_PAS_max) " . "vs CURRENT $global_Version_nbr_3byte_string" );
    return;

}

sub Version_Check_SPI_manipul {

    if (    hex $global_Version_nbr_3byte_string >= hex $global_Version_nbr_for_SPI_manip_min
        and hex $global_Version_nbr_3byte_string <= hex $global_Version_nbr_for_SPI_manip_max )
    {
        return 1;
    }

    S_set_error( "wrong Firmware version for Manitoo SPI manipulation functions : " . "MIN: $global_Version_nbr_for_SPI_manip_min MAX:$global_Version_nbr_for_SPI_manip_max) " . "vs CURRENT $global_Version_nbr_3byte_string" );
    return;
}

sub Version_Check_SPI_trace {

    if (    hex $global_Version_nbr_3byte_string >= hex $global_Version_nbr_for_SPI_trace_min
        and hex $global_Version_nbr_3byte_string <= hex $global_Version_nbr_for_SPI_trace_max )
    {
        return 1;
    }

    S_set_error( "wrong Firmware version for Manitoo SPI trace functions : " . "MIN: $global_Version_nbr_for_SPI_trace_min MAX:$global_Version_nbr_for_SPI_trace_max) " . "vs CURRENT $global_Version_nbr_3byte_string" );
    return;
}

sub Validate_sensor_module {

    my $sensor_module_int = shift;

    if ( $sensor_module_int < 1 or $sensor_module_int > 16 ) {
        S_set_error("Validate_sensor_module: Invalid sensor module '$sensor_module_int'. Valid range (1 .. 16)");
        return;
    }
    return 1;
}


sub Send_read_firmware_service {

    my @args               = @_;
    my $communication_mode = shift @args;
    my $wait_time_ms = shift @args;

    my ($success, $temp_receiveData_bytestring, $waitime_for_response);
    do {

        if ( $communication_mode eq 'COM' ) {
            $success = $PortObj->write( Convert_bytes_for_send('10') );
            unless ($success) {
                S_set_error("Could not write to serial port. Check connection.");
            }
            S_wait_ms_NOHTML( $wait_time_ms )if ($wait_time_ms);
            my $temp_count;
            ( $temp_count, $temp_receiveData_bytestring ) = $PortObj->read($SERIAL_PORT_MAX_READ_BYTES);
            
            my $receiveData_formatted = Convert_bytes_for_print($temp_receiveData_bytestring);
            $waitime_for_response = $waitime_for_response+50 unless ($receiveData_formatted);
            S_w2log( 5, " MANITOO_cmd_Request_Response: Completing Manitoo command request:$wait_time_ms: $receiveData_formatted\n", 'grey' );
        }
        elsif ( $communication_mode eq 'USB' ) {
            $success = $PortObj->send( Convert_bytes_for_send('10') );
            S_wait_ms_NOHTML( $wait_time_ms )if ($wait_time_ms);
            $PortObj->recv( $temp_receiveData_bytestring, $SERIAL_PORT_MAX_READ_BYTES );
            my $receiveData_formatted = Convert_bytes_for_print($temp_receiveData_bytestring);
            S_w2log( 5, " MANITOO_cmd_Request_Response: Completing Manitoo command request\n", 'grey' );
            $waitime_for_response = 100; # wait time for response from manitoo
        }

    } while ( $temp_receiveData_bytestring eq '' );

    return $waitime_for_response;

}

1;

