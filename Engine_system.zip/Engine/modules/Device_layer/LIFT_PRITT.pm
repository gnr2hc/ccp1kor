# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_PRITT;

use strict;
use warnings;

BEGIN {
    use LIFT_general;
    S_add_paths2INC( ['./FTD2XX'], ['./FTD2XX'] );    #Include FTD2XX.pm and Load p5ftd2xx.dll
}

use LIFT_general;
use FTD2XX;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  PRT_init
  PRT_exit
  PRT_connect
  PRT_disconnect
  PRT_power_connect
  PRT_power_disconnect
  PRT_get_device_info
);

our ( $VERSION, $HEADER );

my ( $PRT_initialized, $status, $FTDIdevice, $powerPritt, $powerPritt2x, $relayCommand, );
my $devInfo;
my $powerPritt2x_pgm_connected = 0; # required for crosswise locking 

$PRT_initialized = 0;
$relayCommand    = 0;

my $mcu_bit_mapping_connect = {

    # values used for PRT_connect
    MCU_A => 0x02,
    MCU_B => 0x20,
};

my $mcu_bit_mapping_disconnect = {

    # values used for PRT_disconnect
    MCU_A => 0xFD,
    MCU_B => 0xDF,
};

my $power_Switch_bit_mapping_connect = {

    # values used for PRT_power_connect
    Power_Switch_1 => 0x80,
    Power_Switch_2 => 0x40,
};

my $power_Switch_bit_mapping_disconnect = {

    # values used for PRT_power_disconnect
    Power_Switch_1 => 0x7F,
    Power_Switch_2 => 0xBF,
};

=head1 NAME

LIFT_PRITT 

=for html
<IMG SRC='..\..\..\pics\MinicubePritt.png'  alt="PRITT folder" border="0">
<IMG SRC='..\..\..\pics\PRITT_V3.png'  alt="PRITT V2" border="0">
<IMG SRC='..\..\..\pics\PRITT_V2.png'  alt="PRITT V2" border="0">
<IMG SRC='..\..\..\pics\PRITT_V1.png'  alt="PRITT V1" border="0">
<IMG SRC='..\..\..\pics\PowerPritt2x.jpg'  alt="PowerPritt2x" border="0">

PRITT driver can be found at  \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\CoreAssetTest\12_8xFet_Pritt_PowerPritt\8xFet_and_Pritt_and_PowerPritt


=head1 SYNOPSIS

    use LIFT_PRITT;

    PRT_init();
    PRT_get_device_info();
	
    PRT_power_connect(); #only for PowerPritt and PowerPritt2x, default power connection for MCU_A
    PRT_power_connect('MCU_B'); # only if Power_Switch_2 is used for MCU_B in case of PowerPritt2x
    PRT_connect(); # default controller considered is MCU_A.
    PRT_connect('MCU_B'); # only if MCU_B have to be connected. 
    sleep(1);
    PRT_disconnect();
    PRT_power_disconnect(); #only for PowerPritt and PowerPritt2x

    PRT_exit();


=head1 DESCRIPTION

wrapper for PRITT , PowerPritt, PowerPritt2x , only FTDI driver has to be installed (should be done by Windows7 automatically).

=head1 TESTBENCH CONFIGURATION

B<Test bench configuartion required only in case of PowerPritt2x when both Power_Switches are used.>

By default Power_Switch_1 and MCU_A is considered for PRITT and PowerPritt.

By default Power_Switch_1 connected to MCU_A and MCU_B is considered for PowerPritt2x.
 
    'Devices' => {
                    'PRITT' => {
                                  'MCU_A' => 'Power_Switch_1', # Power_Switch_1 or Power_Switch_2
                                  'MCU_B' => 'Power_Switch_2', # Power_Switch_1 or Power_Switch_2
                                 },
                 };

=cut

=head2 PRT_init

    1|0 = PRT_init();

Initialises Pritt or PowerPritt or PowerPritt2x hardware and disconnects pins.

Has to be called before any other PRT functions.

B<NOTE: Test bench configuration required only in case of PowerPritt2x when both Power_Switches used. >

B<Arguments: None>

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_init();

=cut

sub PRT_init {

    if ($PRT_initialized) {
        S_w2rep( "Info: PRITT already initialized\n", 'grey' );
        return 1;
    }

    $powerPritt = 0;

    if ($main::opt_offline) {
        $PRT_initialized = 1;
        $powerPritt      = 1;
        S_w2log( 4, "PRT_init: Initialized the communication with PRITT \n" );
        return 1;
    }

    #Killing any PRITT GUI that is currently running and locking the PRITT device
    S_kill_process('_Pritt');

    $FTDIdevice = FTD2XX->new();
    unless ( $FTDIdevice->PFT_STATUS() == FT_OK ) {
        S_set_error( "PRT_init failed: " . $FTDIdevice->PFT_STATUS_MSG() . "  (" . $FTDIdevice->PFT_ERROR() . ")", 5 );
        return 0;
    }

    my $p5ver  = $FTDIdevice->P5VERSION();
    my $libver = $FTDIdevice->crackLibraryVersion();
    S_w2log( 4, "P5 version: $p5ver, USBlib version: $libver\n" );

    my $numDevices = $FTDIdevice->GetNumDevices();
    S_w2log( 4, "found $numDevices FTDI devices connected\n" );

    my $PRITTcount = 0;
    my $PRITTindex = -1;

    foreach my $num ( 0 .. ( $numDevices - 1 ) ) {
        my $desc = $FTDIdevice->GetDescrByIndex($num);
        if ( $desc eq 'Pritt' or $desc eq 'PowerPritt' or $desc eq 'PowerPritt2x' ) {
            $PRITTcount++;
            $PRITTindex   = $num;
            $powerPritt   = 1 if ( $desc eq 'PowerPritt' );
            $powerPritt2x = 1 if ( $desc eq 'PowerPritt2x' );
        }
    }
    if ( $PRITTcount > 1 ) {
        S_set_error( "only 1 PRITT supported but found $PRITTcount", 5 );
        return 0;
    }
    if ( $PRITTcount < 1 ) {
        S_set_error( "no PRITT found", 5 );
        return 0;
    }

    $status = $FTDIdevice->OpenByIndex($PRITTindex);
    check_status($status);
    $devInfo = PRT_get_device_info();
    return 0 unless ($devInfo);

    $status = $FTDIdevice->SetBaudRate(921600);
    check_status($status);
    if ($powerPritt) {
        $status = $FTDIdevice->SetBitMode( 0x82, 0x1 );
    }
    elsif ($powerPritt2x) {
        my $connection_details_href = $LIFT_config::LIFT_Testbench->{Devices}{PRITT};
        unless ($connection_details_href) {
            S_w2log( 3, "PRT_init: Default configuration Power_Switch_1 and PGM switch MCU_A and MCU_B is considered to initialise PowerPritt2x" );
            $status = $FTDIdevice->SetBitMode( 0xA2, 0x1 );
        }

        my $bitmode_value = 0;
        if ($connection_details_href) {
            foreach my $microcontroller ( keys %$connection_details_href ) {
                my $power_switch = $connection_details_href->{$microcontroller};
                return 0 unless ( Validate_power_switch($power_switch) );

                return 0 unless ( Validate_pgm_switch($microcontroller) );

                $bitmode_value = $bitmode_value | $mcu_bit_mapping_connect->{$microcontroller} | $power_Switch_bit_mapping_connect->{$power_switch};
            }
            $status = $FTDIdevice->SetBitMode( $bitmode_value, 0x1 );
        }

    }
    else {
        $status = $FTDIdevice->SetBitMode( 0x2, 0x1 );
    }
    check_status($status);

    $PRT_initialized = 1;
    S_w2log( 3, "PRT_init: Initialized the communication with $devInfo->{Descr} \n" );

    return 1;
}

=head2 PRT_get_device_info

    $devInfo = PRT_get_device_info();

Provides details of PRITT or PowerPritt or PowerPritt2x

B<Return Value:>

=over

=item $returnValue 

returns following details for PRITT or PowerPritt or PowerPritt2x on success.

    $devInfo->{TypeID}, 
	$devInfo->{TypeNm}, 
	$devInfo->{VID}, 
	$devInfo->{PID}, 
	$devInfo->{Serial}, 
	$devInfo->{Descr}
	
0 on failure.

=back

B<Examples:>

    $devInfo = PRT_get_device_info();

=cut

sub PRT_get_device_info {
    
    $devInfo = $FTDIdevice->GetDeviceInfo();
    if ($devInfo) {
        my $out = sprintf( " Type:\t\t%d (%s)\n ID:\t\tVID(%04X) PID(%04X)\n Serial:\t%s\n Descr:\t%s\n", $devInfo->{TypeID}, $devInfo->{TypeNm}, $devInfo->{VID}, $devInfo->{PID}, $devInfo->{Serial}, $devInfo->{Descr} );
        S_w2log( 4, "$out\n" );
    }
    else {
        S_set_error( "PRITT device info not found", 0 );    # only warning
        return 0;
    }

    S_w2log( 3, "PRT_get_device_info: Device connected '$devInfo->{Descr}'\n" );

    return $devInfo;
}

=head2 PRT_connect

    1|0 = PRT_connect([, $mcu_index]);

Connect flash-tool pins via PRITT or PowerPritt or PowerPritt2x.

B<Arguments:>

=over

=item $mcu_index (optional)

Range : MCU_A | MCU_B. # Default is MCU_A.

B<Note: Required to be configured in case of connection for MCU_B in PowerPritt2x.>

=back

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_connect(); # by default connects MCU_A
    1 = PRT_connect('MCU_B'); # connects MCU_B in case of PowerPritt2x

=cut

sub PRT_connect {

    my @args = @_;
    my $mcu_index = shift @args // 'MCU_A';

    unless ($PRT_initialized) {
        S_set_error( "PRITT not initialized", 120 );
        return 0;
    }

    if ( not $powerPritt2x and $mcu_index !~ 'MCU_A' ) {
        S_set_error( "PRT_connect: Invalid mcu_index '$mcu_index' configured , valid index is 'MCU_A'", 109 );
        return 0;
    }

    return 0 unless ( Validate_pgm_switch($mcu_index) );

    if ($main::opt_offline) {
        S_w2log( 4, "PRT_connect: Connected flash tool via PRITT\n" );
        return 1;
    }
    
    if ($powerPritt2x and $powerPritt2x_pgm_connected == 1){
        S_set_error("PRT_connect: Already a PGM switch is active for another controller, only one controller can be connected at once.", 108);
        return 0;
    }

    $relayCommand = $relayCommand | $mcu_bit_mapping_connect->{$mcu_index};
    my $byteswritten = $FTDIdevice->Write( pack( "C*", $relayCommand ) );    # pritt on
    if ( $byteswritten != 1 ) {
        S_set_error( "PRITT communication error", 5 );
        return 0;
    }
    
    $powerPritt2x_pgm_connected = 1;

    S_w2log( 3, "PRT_connect: Connected flash tool via PRITT\n" );

    return 1;
}

=head2 PRT_disconnect

    1|0 = PRT_disconnect([, $mcu_index]);

Disconnect flash-tool pins via PRITT or PowerPritt or PowerPritt2x.

B<Arguments:>

=over

=item $mcu_index (optional)

Range : MCU_A | MCU_B. # Default is MCU_A.

B<Note: Required to be configured in case of disconnection for MCU_B in PowerPritt2x.>

=back

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_disconnect(); # by default disconnects MCU_A
    1 = PRT_disconnect('MCU_B'); # disconnects MCU_B in case of PowerPritt2x

=cut

sub PRT_disconnect {

    my @args = @_;
    my $mcu_index = shift @args // 'MCU_A';

    unless ($PRT_initialized) {
        S_set_error( "PRITT not initialized", 120 );
        return 0;
    }

    if ( not $powerPritt2x and $mcu_index !~ 'MCU_A' ) {
        S_set_error( "PRT_disconnect: Invalid mcu_index '$mcu_index' configured , valid index is 'MCU_A'", 109 );
        return 0;
    }

    return 0 unless ( Validate_pgm_switch($mcu_index) );

    if ($main::opt_offline) {
        S_w2log( 4, "PRT_disconnect: Disconnected flash tool via PRITT\n" );
        return 1;
    }

    $relayCommand = $relayCommand & $mcu_bit_mapping_disconnect->{$mcu_index};
    my $byteswritten = $FTDIdevice->Write( pack( "C*", $relayCommand ) );    # pritt off
    if ( $byteswritten != 1 ) {
        S_set_error( "PRITT communication error", 5 );
        return 0;
    }

    $powerPritt2x_pgm_connected = 0 if ($powerPritt2x);
    S_w2log( 3, "PRT_disconnect: Disconnected flash tool via PRITT\n" );

    return 1;
}

=head2 PRT_power_connect

    1|0 = PRT_power_connect([, $mcu_index]);

Connects power pins via PRITT or PowerPritt or PowerPritt2x.

B<Arguments:>

=over

=item $mcu_index (optional)

Range : MCU_A | MCU_B. # Default is MCU_A.

B<Note: Required to be configured in case of power connection via Power_Switch_2 if it is used in PowerPritt2x.>

=back

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_power_connect(); # by default connects power pins to MCU_A via Power_Switch_1
    1 = PRT_power_connect('MCU_B'); # connects power pins via Power_Switch_1 (default) or via configured Power_Switch in Test bench to MCU_B in case of PowerPritt2x

=cut

sub PRT_power_connect {

    my @args = @_;
    my $mcu_index = shift @args // 'MCU_A';

    unless ($PRT_initialized) {
        S_set_error( "PRITT not initialized", 120 );
        return 0;
    }
    unless ( $powerPritt or $powerPritt2x ) {
        S_set_error( "old PRITT does not support power feature, use PowerPritt or PowerPritt2x instead", 109 );
        return 0;
    }
    if ( not $powerPritt2x and $mcu_index !~ 'MCU_A' ) {
        S_set_error( "PRT_power_connect: Invalid mcu_index '$mcu_index' configured , valid index is 'MCU_A'", 109 );
        return 0;
    }

    my $power_switch = $LIFT_config::LIFT_Testbench->{Devices}{PRITT}{$mcu_index};

    if ($power_switch) {
        return 0 unless ( Validate_power_switch($power_switch) );
        S_w2log( 3, "PRT_power_connect: Connecting via $power_switch" ) if ($powerPritt2x);
        $power_switch = $power_Switch_bit_mapping_connect->{$power_switch};
    }

    unless ($power_switch) {
        $power_switch = 0x80;
        S_w2log( 3, "PRT_power_connect: Connecting via Power_Switch_1" ) if ($powerPritt2x);
    }

    if ($main::opt_offline) {
        S_w2log( 4, "PRT_power_connect: Connected power pins via PRITT\n" );
        return 1;
    }

    $relayCommand = $relayCommand | $power_switch;
    my $byteswritten = $FTDIdevice->Write( pack( "C*", $relayCommand ) );    # pritt on
    if ( $byteswritten != 1 ) {
        S_set_error( "PRITT communication error", 5 );
        return 0;
    }

    S_w2log( 3, "PRT_power_connect: Connected power pins via PRITT\n" );

    return 1;
}

=head2 PRT_power_disconnect

    1|0 = PRT_power_disconnect([, $mcu_index]);

Disconnects power pins via PRITT or PowerPritt or PowerPritt2x.

B<Arguments:>

=over

=item $mcu_index (optional)

Range : MCU_A | MCU_B. # Default is MCU_A.

B<Note: Required to be configured in case of power disconnection via Power_Switch_2 if it is used in PowerPritt2x.>

=back

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_power_connect(); # by default disconnects power pins to MCU_A via Power_Switch_1
    1 = PRT_power_connect('MCU_B'); # disconnects power pins via Power_Switch_1 (default) or via configured Power_Switch in Test bench to MCU_B in case of PowerPritt2x

=cut

sub PRT_power_disconnect {

    my @args = @_;
    my $mcu_index = shift @args // 'MCU_A';

    unless ($PRT_initialized) {
        S_set_error( "PRITT not initialized", 120 );
        return 0;
    }
    unless ( $powerPritt or $powerPritt2x ) {
        S_set_error( "old PRITT does not support power feature, use PowerPritt or PowerPritt2x instead", 109 );
        return 0;
    }
    if ( not $powerPritt2x and $mcu_index !~ 'MCU_A' ) {
        S_set_error( "PRT_power_disconnect: Invalid mcu_index '$mcu_index' configured , valid index is 'MCU_A'", 109 );
        return 0;
    }

    my $power_switch = $LIFT_config::LIFT_Testbench->{Devices}{PRITT}{$mcu_index};

    if ($power_switch) {
        return 0 unless ( Validate_power_switch($power_switch) );
        S_w2log( 3, "PRT_power_disconnect: disconnecting via $power_switch" ) if ($powerPritt2x);
        $power_switch = $power_Switch_bit_mapping_disconnect->{$power_switch};
    }

    unless ($power_switch) {
        $power_switch = 0x7F;
        S_w2log( 3, "PRT_power_disconnect: disconnecting via Power_Switch_1" ) if ($powerPritt2x);
    }

    if ($main::opt_offline) {
        S_w2log( 4, "PRT_power_disconnect: Disconnected power pins via PRITT\n" );
        return 1;
    }

    $relayCommand = $relayCommand & $power_switch;
    my $byteswritten = $FTDIdevice->Write( pack( "C*", $relayCommand ) );    # pritt off
    if ( $byteswritten != 1 ) {
        S_set_error( "PRITT communication error", 5 );
        return 0;
    }

    S_w2log( 3, "PRT_power_disconnect: Disconnected power pins via PRITT\n" );

    return 1;
}

=head2 PRT_exit

    PRT_exit();

Disconnect pins and shut down PRITT or PowerPritt or PowerPritt2x hardware. Has to be called in ENDcampaign.

B<Return Value:>

=over

=item $returnValue 

1 on success and 0 on failure.

=back

B<Examples:>

    1 = PRT_exit();

=cut

sub PRT_exit {

    unless ($PRT_initialized) {
        S_set_error( "PRITT not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline) {
        $PRT_initialized = 0;
        S_w2log( 4, "PRT_exit: Terminated the communication with PRITT \n" );
        return 1;
    }

    $status = $FTDIdevice->Close();
    check_status($status);

    $PRT_initialized = 0;
    S_w2log( 2, "PRT_exit: Terminated the communication with PRITT \n" );

    return 1;
}

=head1 not exported functions

=head2 check_status

 check_status($result)

if result != 0, log error and set INCONC.

=cut

sub check_status {
    my $chk_status = shift;

    return 1 if $main::opt_offline;

    unless ($chk_status) {
        S_set_error( "PRITT Tool error: " . $FTDIdevice->PFT_STATUS_MSG() . "  (" . $FTDIdevice->PFT_ERROR() . ")", 5 );

    }

    return 1;
}



=head2 Validate_power_switch

 1|undef = Validate_power_switch($power_switch)

Validates if power switch configured are in range 

=cut

sub Validate_power_switch {
    my @args         = @_;
    my $power_switch = shift @args;

    my @valid_power_switches = keys %$power_Switch_bit_mapping_connect;

    unless ($power_switch) {
        S_set_error( "Validate_power_switch: Power switch not configured in testbenches, Valid Range : @valid_power_switches", 109 );
        return;
    }

    if ( !exists $power_Switch_bit_mapping_connect->{$power_switch} ) {
        S_set_error( "Validate_power_switch: Power switch '$power_switch' configured in Testbenches is invalid, Valid Range : @valid_power_switches", 109 );
        return;
    }
    return 1;
}


=head2 Validate_pgm_switch

 1|undef = Validate_pgm_switch($pgm_switch)

Validates if pgm switch configured are in range 

=cut

sub Validate_pgm_switch {

    my @args       = @_;
    my $pgm_switch = shift @args;

    my @valid_microcontrollers = keys %$mcu_bit_mapping_connect;
    if ( !exists $mcu_bit_mapping_connect->{$pgm_switch} ) {

        S_set_error( "Validate_pgm_switch: '$pgm_switch' is a invalid microcontroller configuration, Valid Range: @valid_microcontrollers", 109 );
        return;
    }

    if ( !exists $mcu_bit_mapping_disconnect->{$pgm_switch} ) {

        S_set_error( "Validate_pgm_switch: '$pgm_switch' is a invalid microcontroller configuration, Valid Range: @valid_microcontrollers", 109 );
        return;
    }

    return 1;
}

1;

