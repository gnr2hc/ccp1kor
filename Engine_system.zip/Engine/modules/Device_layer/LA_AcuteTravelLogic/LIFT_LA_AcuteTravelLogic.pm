#*****************************************************************************************************
#
#  Copyright (c)       Robert Bosch GmbH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_LA_AcuteTravelLogic;

use strict;
use warnings;
use Readonly;

use Win32::OLE;
use Win32::OLE::Variant;
use Win32::Process;    # for killing LA.exe (LA Viewer)

use Clone qw(clone);

use LIFT_general;
use LIFT_simulation;
require Exporter;

our @ISA = qw(Exporter);

our @EXPORT = qw(
  LATL_InitHW
  LATL_CloseHW
  LATL_StartMeasurement
  LATL_StopMeasurement
  LATL_get_values
  LATL_plot_values
);

# Keep this PROGID incl. version same as in DLL source: PROGID, assembly and file version
my $LATL_PROGID = "LA_AcuteTravelLogic.LASDK.1.9.0.0";
my $LATL_hOle;
my %LATL_config;
my $LATL_initialized = 0;
my $LATL_numSamples_perCh;
my $LATL_lastUsedHwMode;
my $LATL_template_file = "";

our ( $VERSION, $HEADER );

# ::Scalar requred, because values are assigned to variables, which are used as arguments for OLE-calls!
Readonly::Scalar my $LATL_TTL_THRESHOLD_MILLI_VOLT => 1600;                 # 1.6V (TTL)
Readonly::Scalar my $LATL_PARA_OMITTED             => -1;
Readonly::Scalar my $LATL_HW_MODE_4G_36CH          => "HW_4G_36CH";
Readonly::Scalar my $LATL_HW_MODE_4G_18CH          => "HW_4G_18CH";
Readonly::Scalar my $LATL_HW_MODE_4G_9CH           => "HW_4G_9CH";
Readonly::Scalar my $LATL_HW_MODE_4G_4CH           => "HW_4G_4CH";
Readonly::Scalar my $LATL_HW_MODE_2G_36CH          => "HW_2G_36CH";
Readonly::Scalar my $LATL_HW_MODE_1600M_4CH        => "HW_1600M_4CH";
Readonly::Scalar my $LATL_HW_MODE_800M_9CH         => "HW_800M_9CH";
Readonly::Scalar my $LATL_HW_MODE_400M_18CH        => "HW_400M_18CH";
Readonly::Scalar my $LATL_HW_MODE_200M_36CH        => "HW_200M_36CH";
Readonly::Scalar my $LATL_HW_MODE_200M_18CH        => "HW_200M_18CH";
Readonly::Scalar my $LATL_HW_MODE_200M_12CH        => "HW_200M_12CH";
Readonly::Scalar my $LATL_HW_MODE_200M_9CH         => "HW_200M_9CH";
Readonly::Scalar my $LATL_HW_MODE_200M_6CH         => "HW_200M_6CH";
Readonly::Scalar my $LATL_HW_MODE_200M_4CH         => "HW_200M_4CH";
Readonly::Scalar my $LATL_HW_MODE_200M_2CH         => "HW_200M_2CH";
Readonly::Scalar my $LATL_HW_MODE_200M_1CH         => "HW_200M_1CH";
Readonly::Scalar my $LATL_HW_MODE_200M_TR_32CH     => "HW_200M_32CH_TR";    # Transitional Storage, using 32 ch
Readonly::Scalar my $LATL_HW_MODE_200M_TR_8CH      => "HW_200M_8CH_TR";     # Transitional Storage, using 8 ch
Readonly::Scalar my $LATL_SIGNAL_GROUP_0           => 0;
Readonly::Scalar my $LATL_SIGNAL_GROUP_1           => 1;
Readonly::Scalar my $LATL_SIGNAL_GROUP_2           => 2;
Readonly::Scalar my $LATL_SIGNAL_GROUP_3           => 3;
Readonly::Scalar my $LATL_TRG_EDGE_FALLING         => 0;
Readonly::Scalar my $LATL_TRG_EDGE_RISING          => 1;
Readonly::Scalar my $LATL_TRG_EDGE_LOW             => 2;
Readonly::Scalar my $LATL_TRG_EDGE_HIGH            => 3;
Readonly::Scalar my $LATL_TRG_EDGE_CHANGE          => 4;
Readonly::Scalar my $LATL_TRG_EDGE_DONTCARE        => -1;
Readonly::Scalar my $LATL_ERR_MINUS_ONE            => -1;
Readonly::Scalar my $LATL_ERR_MINUS_TWO            => -2;
Readonly::Scalar my $LATL_ERR_MINUS_THREE          => -3;
Readonly::Scalar my $LATL_FACTOR_SEC_TO_MS         => 1000;

my @SimulatedFunctionalites = qw(
  WrapComCallLATL_Method
  S_create_OLE
);

if ($main::opt_simulation) {
    no strict 'refs';

    # redefine functions for simulation mode with default return values
    foreach my $function (@SimulatedFunctionalites) {

        # each function specifed is redefined using SIM_returnValues
        *{$function} = sub { return SIM_returnValues( $function, 'default', \@_ ); };
    }

    # define return values table (especially for default values) and pass it to simulation module
    my $returnValuesTable_href = { 'WrapComCallLATL_Method' => { 'default' => [1] }, };
    SIM_addToValuesTable($returnValuesTable_href);
}

=head1 NAME

LIFT_LA_AcuteTravelLogic

=head1 SYNOPSIS

    use LIFT_LA_AcuteTravelLogic

    Supported device from Acute: TL2236B
    
    $success   = LATL_InitHW();
    $success   = LATL_CloseHW();
    $success   = LATL_StartMeasurement($args_href);
    $success   = LATL_StopMeasurement();
    $success   = LATL_get_values($pinNames_aref, $timeoutTrigger_sec, $timeoutCapture_sec, $data_href);
    $success   = LATL_plot_values($data_href, $fileName, $title, $fileFormat[, $fileNameTemplate]);


    content of ProjectConst:
	
	package LIFT_PROJECT;
	use File::Basename;  # needed for dirname
	$Defaults->{'LA_AcuteTravelLogic'} = {


        # [OPTIONAL] : Template file for law format with pin labels assigned in the template file
        'fileNameTemplate ' => <COMPLETE FILE PATH>,
            # Example: 
            # dirname($main::opt_conf) . '/Tools/LA_AcuteTravelLogic/AB12_ManiToo_LIFT_Interface_Template.law',

		'pinNames' => {
                        # Maximum number of available channels depends on selected 'hwMode'
                        # For hwModes see function LATL_StartMeasurement)
                        # Only the used channels, including the trigger channel need to be listed
                        # GND Pin not to be listed, but GND connection to one or more of the
                        # 4 GND pins has to exist.
                        # Names can be chosen, assigned numbers have to be zero-based
                        # integer values in the range [0, 35]
                        'Name_Pin_0' => 0,
                        'Name_Pin_1' => 1,
                        'Name_Pin_2' => 2,
                        'Name_Pin_3' => 3,
                        'Name_Pin_4' => 4,
                        'Name_Pin_5' => 5,
                        ...
                        'Name_Pin_35' => 35,
                      },
        'triggerPinName' => <text>,     # [REQUIRED, if triggerEdge unequal 'dontcare' otherwise OPTIONAL]
                                        # Any of the pin names given
        'triggerEdge'    => <text|int>, # [REQUIRED]
                                        # text: 'falling'|'rising'|'low'|'high'|'change'|'dontcare'
                                        #  int:     0    |   1    |  2  |  3   |   4    |  -1
                                        # (dontcare = immediate trigger)
        'hwMode'         => <text>,     # [OPTIONAL]
                                        # (default: 'HW_200M_32CH_TR' = 200 MHz, transitional mode, 32 ch)
                                                        'HW_4G_36CH'
                                                        'HW_4G_18CH'
                                                        'HW_4G_9CH'
                                                        'HW_4G_4CH'
                                                        'HW_2G_36CH'
                                                        'HW_1600M_4CH'
                                                        'HW_800M_9CH'
                                                        'HW_400M_18CH'
                                                        'HW_200M_36CH'
                                                        'HW_200M_18CH'
                                                        'HW_200M_12CH'
                                                        'HW_200M_9CH'
                                                        'HW_200M_6CH'
                                                        'HW_200M_4CH'
                                                        'HW_200M_2CH'
                                                        'HW_200M_1CH'
                                                        'HW_200M_32CH_TR'
                                                        'HW_200M_8CH_TR'
                                                        
               Note: The last two hwModes named '..._TR' are transitional modes with longer recording time

        'numSamples_perCh'   => <int>,      # [OPTIONAL] default: max. available memory
        'postTriggerSize_pct => <int>,      # [OPTIONAL] default: 90%

        # PARAMETERS FOR TRACE STORE
        'fileFormat' => '1',  #[MANDATORY] 1 -> law format (supported),
                                           0 -> uniview format(not supported)    
                              # By default the trace file will be stored in the 
                              # reports folder with the same name as TC REPORT NAME
                              # with (.law) extension

                    
      }

=head1 DESCRIPTION

    Driver for Logic Analyzer Acute TravelLogic (LATL)

    Device's connector pin assignment (view into device):
                               +-----+
                               |     |  <--- mechanical coding on topside
    +--------------------------+     +--------------------------+
    | 1  3  4  6  8 10 12 13 15 17 19 21 22 24 26 28 30 31 33 35|
    | 0  2  G  5  7  9 11  G 14 16 18 20  G 23 25 27 29  G 32 34|
    +-----------------------------------------------------------+
    Single ended inputs: 0...35
    4 x G = GND (Connect the probe's ground to earth ground ONLY, NOT to an elevated voltage)

=head1 FUNCTIONS

=head2 LATL_InitHW
    $success = LATL_InitHW();

start application, will read LATL_config mapping from ProjectConst (section 'LA_AcuteTravelLogic')
LA_AcuteTravelLogic.dll must be registered for OLE access, otherwise "Invalid class string" error, which is
typically done by _run_once.bat (or register_com_dlls.bat)

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub LATL_InitHW {
    my $status;
    my %pins;

    if ( not defined( $main::ProjectDefaults->{'LA_AcuteTravelLogic'} ) ) {
        S_set_error( "No LA_AcuteTravelLogic settings found in Project Constants", 20 );
        return;
    }

    %LATL_config = %{ $main::ProjectDefaults->{'LA_AcuteTravelLogic'} };

    # check if each pin is listed only once
    foreach my $pin ( sort keys %{ $LATL_config{'pinNames'} } ) {
        if ( exists $pins{$pin} ) {
            S_set_error( " Pin $pin listed twice in ProjectConst", 114 );
            return;
        }
        else {
            $pins{$pin} = 1;
        }
    }
    if ($LATL_initialized) {
        S_set_warning("LA_AcuteTravelLogic already initialized");
        return 1;
    }

    # # not used yet / is defined in Mapping_LA_Acute
    #
    # $LATL_template_file = S_get_contents_of_hash( [ 'Devices', 'LA_AcuteTravelLogic', 'LA_viewer_template' ], $LIFT_config::LIFT_Testbench );
    # unless ( defined $LATL_template_file ) {
    # S_set_error( "In LIFT_Testbenches.pm 'LA_viewer_template' for Device 'LA_AcuteTravelLogic' is not defined", 108 );
    # return 0;
    # }

    # unless( -f $LATL_template_file ) {
    # S_set_error( "LA viewer template file '$LATL_template_file' doesnt exists", 108 );
    # return 0;
    # }

    $LATL_template_file = $LATL_config{'fileNameTemplate'};
    if ( defined $LATL_template_file ) {
        S_w2log( 4, " LATL_InitHW: 'fileNameTemplate' is defined defined in ProjectDefaults->{'LA_AcuteTravelLogic'} :  $LATL_template_file \n" );
        unless ( -f $LATL_template_file ) {
            S_set_error( "LA viewer template file '$LATL_template_file' doesnt exists", 108 );
            return 0;
        }
    }
    else {
        S_w2log( 4, " LATL_plot_values: no 'fileNameTemplate' defined in Mapping_LA_AcuteTravelLogic \n" );
        undef $LATL_template_file;
    }

    # offline mode
    if ($main::opt_offline) {
        $LATL_initialized = 1;
        return 1;
    }

    # Killing LA Viewer
    S_w2log( 3, "LATL_InitHW: Searching for LA Viewer ...\n" );
    my %procs = S_get_Win32_processes();
    if ( exists $procs{'LA'} ) {
        S_w2log( 3, "LATL_InitHW:: Killing LA Viewer !!!\n" );
        Win32::Process::KillProcess( $_, 0 ) foreach ( @{ $procs{'LA'} } );
    }

    S_w2log( 3, " LATL_InitHW: Application_create() ..  \n" );
    Application_create() || return;

    my $dllInfos = WrapComCallLATL_Method( $LATL_hOle, 'getDllInfos' );
    return unless defined $dllInfos;
    S_w2log( 3, " LATL_InitHW: LA Acute TravelLogic DLL infos: $dllInfos\n" );

    S_w2log( 3, " LATL_InitHW: InitDevice() ..  \n" );
    InitDevice() || return;

    my $ulaSDKThreshold_arg_aref = [ $LATL_SIGNAL_GROUP_0, $LATL_TTL_THRESHOLD_MILLI_VOLT ];
    S_w2log( 3, " LATL_InitHW : WrapComCallLATL_Method( LATL_hOle, 'ulaSDKThreshold', @$ulaSDKThreshold_arg_aref ) \n" );
    $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKThreshold', $ulaSDKThreshold_arg_aref );
    return unless CheckStatus($status);

    $ulaSDKThreshold_arg_aref = [ $LATL_SIGNAL_GROUP_1, $LATL_TTL_THRESHOLD_MILLI_VOLT ];
    S_w2log( 3, " LATL_InitHW : WrapComCallLATL_Method( LATL_hOle, 'ulaSDKThreshold', @$ulaSDKThreshold_arg_aref ) \n" );
    $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKThreshold', $ulaSDKThreshold_arg_aref );
    return unless CheckStatus($status);

    $ulaSDKThreshold_arg_aref = [ $LATL_SIGNAL_GROUP_2, $LATL_TTL_THRESHOLD_MILLI_VOLT ];
    S_w2log( 3, " LATL_InitHW : WrapComCallLATL_Method( LATL_hOle, 'ulaSDKThreshold', @$ulaSDKThreshold_arg_aref ) \n" );
    $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKThreshold', $ulaSDKThreshold_arg_aref );
    return unless CheckStatus($status);

    $ulaSDKThreshold_arg_aref = [ $LATL_SIGNAL_GROUP_3, $LATL_TTL_THRESHOLD_MILLI_VOLT ];
    S_w2log( 3, " LATL_InitHW : WrapComCallLATL_Method( LATL_hOle, 'ulaSDKThreshold', @$ulaSDKThreshold_arg_aref ) \n" );
    $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKThreshold', $ulaSDKThreshold_arg_aref );
    return unless CheckStatus($status);

    my $hwInfos = WrapComCallLATL_Method( $LATL_hOle, 'getHwInfos' );
    return unless defined $hwInfos;

    S_w2log( 4, " LATL_InitHW: HW infos: $hwInfos\n" );

    $LATL_initialized = 1;

    return 1;
}

=head2 LATL_CloseHW

    $success = LATL_CloseHW();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub LATL_CloseHW {
    my $success = 1;

    unless ($LATL_initialized) {
        S_set_error( "LA AcuteTravelLogic not initialized", 120 );
        return 0;
    }

    # offline mode
    if ($main::opt_offline) {
        $LATL_initialized = 0;
        return $success;
    }

    Application_destroy();

    $LATL_initialized = 0;

    return $success;
}

=head2 LATL_StartMeasurement

    $success = LATL_StartMeasurement($args_href);

B<Description:> Arguments to this functions can be configured in two ways

               1. Direct function call with arguments.
               e.g: LATL_StartMeasurement($args_href)
               
               2. Through mapping file Mapping_LA_AcuteTravelLogic.pm
               e.g: LATL_StartMeasurement(), refer Synopsis for the arguments.

B<Arguments:>

=over

=item $args_href

        'pinNames'       => [<text>, <text>, ...], # [REQUIRED] list of pin names,
                                        # (triggerPinName has to be included in list!)
                                        # (as defined in ProjectConst, section 'LA_AcuteTravelLogic')
        'triggerPinName' => <text>,     # [REQUIRED, if triggerEdge unequal 'dontcare' 
                                        # otherwise OPTIONAL]
                                        # Any of the pin names given
        'triggerEdge'    => <text|int>, # [REQUIRED]
                                        # text: 'falling'|'rising'|'low'|'high'|'change'|'dontcare'
                                        #  int:     0    |   1    |  2  |  3   |   4    |  -1
                                        # (dontcare = immediate trigger)
        'hwMode'         => <text>,     # [OPTIONAL]
                                        # (default: 'HW_200M_32CH_TR' = 200 MHz, 
                                        # transitional mode, 32 ch)
                                                        'HW_4G_36CH'
                                                        'HW_4G_18CH'
                                                        'HW_4G_9CH'
                                                        'HW_4G_4CH'
                                                        'HW_2G_36CH'
                                                        'HW_1600M_4CH'
                                                        'HW_800M_9CH'
                                                        'HW_400M_18CH'
                                                        'HW_200M_36CH'
                                                        'HW_200M_18CH'
                                                        'HW_200M_12CH'
                                                        'HW_200M_9CH'
                                                        'HW_200M_6CH'
                                                        'HW_200M_4CH'
                                                        'HW_200M_2CH'
                                                        'HW_200M_1CH'
                                                        'HW_200M_32CH_TR'
                                                        'HW_200M_8CH_TR'
                                                        
        Note: The last two hwModes named '..._TR' are transitional modes with longer recording time

        'numSamples_perCh'   => <int>,      # [OPTIONAL] default: max. available memory
        'postTriggerSize_pct => <int>,      # [OPTIONAL] default: 90%


=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

    # How to start measurement immediately (or: no need for a function 'SendSWTrigger')
    $success = LATL_StartMeasurement( { 'triggerEdge'      => 'dontcare' } );

    $success = LATL_StartMeasurement( {     'pinNames'            => ['Name_Pin_0', 'Name_Pin_1', 'Name_Pin_2'],
                                            'triggerPinName'      => 'Name_Pin_1',
                                            'triggerEdge'         => 'rising',
                                            'hwMode'              => 'HW_200M_36CH',
                                            'numSamples_perCh'    => 2000,
                                            'postTriggerSize_pct' => 90               } );

    $success = LATL_StartMeasurement( {     'pinNames'            => ['Name_Pin_0', 'Name_Pin_1', 'Name_Pin_2'],
                                            'triggerPinName'      => 'Name_Pin_1',
                                            'triggerEdge'         => 'falling',
                                            'numSamples_perCh'    => 2000,            } );

B<Notes:> 

=cut

sub LATL_StartMeasurement {
    my @args = @_;

    my $inArgs_href = shift;

    unless ( keys %$inArgs_href ) {

        unless ( keys %LATL_config ) {
            S_set_error( "LATL_StartMeasurement: Missing configuration of parameters!", 109 );
            return;
        }

        $inArgs_href->{'pinNames'}            = [ keys %{ $LATL_config{'pinNames'} } ];
        $inArgs_href->{'triggerPinName'}      = $LATL_config{'triggerPinName'};
        $inArgs_href->{'triggerEdge'}         = $LATL_config{'triggerEdge'};
        $inArgs_href->{'hwMode'}              = $LATL_config{'hwMode'};
        $inArgs_href->{'numSamples_perCh'}    = $LATL_config{'numSamples_perCh'};
        $inArgs_href->{'postTriggerSize_pct'} = $LATL_config{'postTriggerSize_pct'};
    }

    # hash defines the set of valid keys
    my $valid_in_arg_keys = {
        'pinNames'            => 1,
        'triggerPinName'      => 1,
        'triggerEdge'         => 1,
        'hwMode'              => 1,
        'numSamples_perCh'    => 1,
        'postTriggerSize_pct' => 1,
    };
    my $mandatory_keys = { 'pinNames' => 1, 'triggerEdge' => 1, };

    S_checkFunctionArgumentHashKeys( "LATL_StartMeasurement", $inArgs_href, $valid_in_arg_keys, $mandatory_keys ) or return;

    my $success        = 1;
    my $pinNames_aref  = $inArgs_href->{'pinNames'};
    my $triggerPinName = $inArgs_href->{'triggerPinName'};
    my $triggerEdge    = $inArgs_href->{'triggerEdge'};
    my $hwMode         = $inArgs_href->{'hwMode'};
    $LATL_numSamples_perCh = $inArgs_href->{'numSamples_perCh'};
    my $postTriggerSize_pct = $inArgs_href->{'postTriggerSize_pct'};

    return unless ( _Validate_NumSamp_PostTrigg( $LATL_numSamples_perCh, $postTriggerSize_pct ) );

    if ( not defined $LATL_numSamples_perCh ) { $LATL_numSamples_perCh = $LATL_PARA_OMITTED; }
    if ( not defined $hwMode )                { $hwMode                = $LATL_HW_MODE_200M_TR_32CH; }
    if ( not defined $postTriggerSize_pct )   { $postTriggerSize_pct   = $LATL_PARA_OMITTED; }

    if ( $triggerEdge eq 'falling' or $triggerEdge eq '0' ) {
        $triggerEdge = $LATL_TRG_EDGE_FALLING;
    }
    elsif ( $triggerEdge eq 'rising' or $triggerEdge eq '1' ) {
        $triggerEdge = $LATL_TRG_EDGE_RISING;
    }
    elsif ( $triggerEdge eq 'low' or $triggerEdge eq '2' ) {
        $triggerEdge = $LATL_TRG_EDGE_LOW;
    }
    elsif ( $triggerEdge eq 'high' or $triggerEdge eq '3' ) {
        $triggerEdge = $LATL_TRG_EDGE_HIGH;
    }
    elsif ( $triggerEdge eq 'change' or $triggerEdge eq '4' ) {
        $triggerEdge = $LATL_TRG_EDGE_CHANGE;
    }
    elsif ( $triggerEdge eq 'dontcare' or $triggerEdge eq '-1' ) {
        $triggerEdge = $LATL_TRG_EDGE_DONTCARE;
    }
    else {
        S_set_error( "trigger_edge $triggerEdge unknown/not supported", 114 );
        return 0;
    }

    my $triggerPin = 0;    # 0: valid channel number, in case trigger edge is 'don't care'
    if ( $triggerEdge != $LATL_TRG_EDGE_DONTCARE ) {
        $triggerPin = MapPin($triggerPinName);
    }

    unless ($LATL_initialized) {
        S_set_error( "LA AcuteTravelLogic not initialized", 120 );
        return 0;
    }

    S_w2log( 4, "LATL_StartMeasurement\n" );
    return 1 if $main::opt_offline;

    my @pinNumbers;
    foreach my $name (@$pinNames_aref) {
        my $pin = MapPin($name);
        push( @pinNumbers, $pin );
    }

    $LATL_lastUsedHwMode = $hwMode;
    my $pinNumbers_OLEvariant = Variant( VT_ARRAY | VT_I4, scalar(@pinNumbers) );
    $pinNumbers_OLEvariant->Put( \@pinNumbers );

    my $capture_arg_aref = [ $pinNumbers_OLEvariant, $triggerPin, $triggerEdge, $hwMode, $LATL_numSamples_perCh, $postTriggerSize_pct ];
    my $status = WrapComCallLATL_Method( $LATL_hOle, 'capture', $capture_arg_aref );
    if ( $status == 0 || $status == 1 ) { CheckStatus($status); }
    elsif ( $status == $LATL_ERR_MINUS_ONE ) { S_set_error( "hwMode = $hwMode is not supported", 114 ); }
    else                                     { S_set_error( "Unknown error",                     114 ); }
    S_w2log( 4, "LATL->Capture status ($status) \n" );

    if ( $status != 1 ) { $success = 0; }

    return $success;
}

=head2 _Validate_NumSamp_PostTrigg

    $success = _Validate_NumSamp_PostTrigg([,$latl_numSamples_perCh, $postTriggerSize_pct]);

Validates the parameters 'numSamples_perCh' and 'postTriggerSize_pct'.

B<Arguments:>

=over

=item $latl_numSamples_perCh

Number of samples for each channel

=item $postTriggerSize_pct

Post trigger size in percentage

=back

B<Return Values:>

Success: 1 ( both parameters in range )

Failure: undef

B<Examples:>

1. Valid range.

    _Validate_NumSamp_PostTrigg ('200', '90');

2. Invalid range.

    _Validate_NumSamp_PostTrigg ('two hundred', '90');

=cut

sub _Validate_NumSamp_PostTrigg {

    my @args = @_;

    return unless S_checkFunctionArguments( '_Validate_NumSamp_PostTrigg([,$latl_numSamples_perCh, $postTriggerSize_pct])', @args );
    my $latl_numSamples_perCh = shift @args;
    my $postTriggerSize_pct   = shift @args;

    if ( defined $latl_numSamples_perCh ) {
        if ( $latl_numSamples_perCh < 1 ) {
            S_set_error( "LATL_StartMeasurement: Number of samples '$latl_numSamples_perCh' is invalid, should be a integer value greater than 0", 109 );
            return;
        }
    }

    if ( defined $postTriggerSize_pct ) {
        if ( $postTriggerSize_pct < 1 ) {
            S_set_error( "LATL_StartMeasurement: Post trigger size '$postTriggerSize_pct' is invalid, should be a integer value greater than 0", 109 );
            return;
        }
    }

    return 1;
}

=head2 Application_create

    $success = Application_create();

Loads and initializes the Acute Travel Logic DLLs

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_create {
    $LATL_hOle = S_create_OLE($LATL_PROGID);

    unless ( defined($LATL_hOle) ) {
        S_set_error( "Unable to start COM-DLL $LATL_PROGID (Try '_run_once.bat' to register it), " . Win32::OLE->LastError(), 5 );
        return 0;
    }

    return 1;
}

=head2 LATL_StopMeasurement

    $success = LATL_StopMeasurement();

Stops data capturing, if running

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub LATL_StopMeasurement {

    # offline mode
    return 1 if ($main::opt_offline);

    my $status = WrapComCallLATL_Method( $LATL_hOle, 'stopCapture' );
    return CheckStatus($status);
}

=head2 LATL_get_values

     $success = LATL_get_values($pinNames_aref, $timeoutTrigger_sec, $timeoutCapture_sec, $data_href);


B<Arguments:>

=over

=item $pinNames_aref

Reference to an array of pin names (as defined in ProjectConst, section 'LA_AcuteTravelLogic')

=item $timeoutTrigger_sec

Maximum wait time for trigger in seconds, which avoids wait for trigger forever, if expected trigger condition never happens

=item $timeoutCapture_sec

Maximum wait time for capture in seconds, which avoids wait for capture forever, if expected capture ready never happens

=item $data_href

Reference to a hash of captured signals (caller passes an empty hash 'by reference', this function fills the caller's hash)

    'time_s    => [0, dt, 2dt, 3dt, ...],
    "CHANNEL1" => [0, 0, 1, 1, 1, 0, 0, ...],
    "CHANNEL2" => [0, 0, 0, 0, 1, 1, 1, ...],
    ...

=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

    my $data_href  = {};    # Caller passes an empty hash

    $success       = LATL_get_values( ['Name_Pin_0', 'Name_Pin_1', 'Name_Pin_2'], 30, 3, $data_href );

    # After the function call, $data_href will contain the data
    my $numPtsRead = scalar( @{ $data_href->{'Name_Pin_0'} } );

B<Notes:> 

=cut

sub LATL_get_values {
    my @args = @_;
    S_checkFunctionArguments( 'LATL_get_values($pinNames_aref, $timeoutTrigger_sec, $timeoutCapture_sec, $data_href)', @args ) or return;
    my $pinNames_aref      = shift @args;
    my $timeoutTrigger_sec = shift @args;
    my $timeoutCapture_sec = shift @args;
    my $data_href          = shift @args;    #  Empty hash reference given from caller, which will be filled with data by this function

    my $pin;
    my $status     = 1;
    my $error_flag = 0;

    # offline mode
    return 1 if ($main::opt_offline);

    foreach my $pin_name (@$pinNames_aref) {

        $pin = MapPin($pin_name);

        my $getChData_aref = [ $pin, $timeoutTrigger_sec, $timeoutCapture_sec ];

        my $chData_obj = WrapComCallLATL_Method( $LATL_hOle, 'getChData', $getChData_aref );

        $status = $chData_obj->{status};

        if ( $status == 1 ) {
            $data_href->{$pin_name} = $chData_obj->{data};     # directly writes to caller's hash (by reference => no return required)
            $data_href->{'time_s'} = $chData_obj->{time_s};    # directly writes to caller's hash (by reference => no return required)
            next;
        }

        if ( $status == 0 ) {
            CheckStatus($status);
            $error_flag = 1;
            next;
        }

        if ( $status == $LATL_ERR_MINUS_ONE ) {
            S_set_error( "$pin_name (pin: $pin): No trigger received within timeout = $timeoutTrigger_sec", 5 );
            $error_flag = 1;
            next;
        }

        if ( $status == $LATL_ERR_MINUS_TWO ) {
            S_set_warning("$pin_name (pin: $pin): Capture not ready within timeout = $timeoutCapture_sec");
            next;
        }

        if ( $status == $LATL_ERR_MINUS_THREE ) {
            S_set_error( "hwMode not supported (set before by 'LATL_StartMeasurement')", 114 );
            $error_flag = 1;
            next;
        }

        S_set_error( "Unknown error", 23 );
    }

    return 0 if $error_flag;
    return $status;
}

=head2 LATL_plot_values

    $stored_file_name = LATL_plot_values([, $fileName, $fileNameTemplate, $fileFormat, $title, $data_href ]);

B<Description:> Arguments to this functions can be configured in two ways

               1. Direct function call with arguments.
               e.g: LATL_plot_values($fileFormat, $fileName, $fileNameTemplate, $title, $data_href)
               
               2. Through mapping file Mapping_LA_AcuteTravelLogic.pm
               e.g: LATL_plot_values (),
               refer Synopsis for configuration of arguments in mapping file 'Mapping_LA_AcuteTravelLogic.pm'.

B<Arguments:>

=over

=item $fileFormat

    0: uniview (takes $data_href, capture and getvalues was done before)

B< Uniview format CURRENTLY DISABLED ( Not allowed ), due to memory trouble with uniview for undecoded raw data.>

    Details: For transitional HW modes, the timebase in column 'TIME' is a dummy column created by
             'S_create_graph', ignore this and use only original column 'time_s'.
             (Due to memory overflow in 'S_create_graph', the column 'time_s' is not converted
              to a column 'time_ms', as it is done only for classic/standard modes)

    1: LA Viewer format (capture done before, $data_href ignored, recorded data in device is saved)

=item $fileName

By default Test case name will be taken as trace plot file name.
    
If only file name (not full path) is given then the file will be plotted in the respective reports folder with the given name.
    
If explicit full file path is given then the trace file will be created in the respective path.

=item $fileNameTemplate

Optional (and only for fileFormat = 1: LA Viewer format) file path name to a template law file,
which was saved before with LAViewer.exe and contains desired channel names, ...

Procedure, if given, will be:

    fileNameTemplate contains:                          (1) Channel display settings
    HW povides:                                         (2) Waveform and (3) Waveform capture settings
    Together this will make the output file containing: (1), (2) and (3) 

=item $title

Required only for Uniview format( Not supported currently )

=item $data_href

    'time' => \@values,
    'signal1' => \@values1,
    'signal2' => \@values2,

=back


B<Return Values:>

=over

=item $stored_file_name

stored dump file of logic analyser on success, 

undef or 0 otherwise.

=back


B<Examples:>

Configuration has to be done in 'Mapping_LA_AcuteTravelLogic.pm', 
please refer ProjectConst in Synopsis section
   ( example : 	'fileNameTemplate' => dirname($main::opt_conf) . '/Tools/LA_AcuteTravelLogic/AB12_ManiToo_LIFT_Interface_Template.law', # [OPTIONAL] )

    1. LATL_plot_values();

Direct function call for law file trace format

    2. LATL_plot_values('Transitional_plot.law', 'C:/SPI_Template_Example.law');

B<Notes:> 

=cut

sub LATL_plot_values {
    my @args = @_;

    S_checkFunctionArguments( 'LATL_plot_values([, $fileName, $fileNameTemplate, $fileFormat, $title, $data_href,])', @args ) or return;

    my $fileName         = shift @args;    # optional by default test case name will be taken
    my $fileNameTemplate = shift @args;    # optional and only for law file format
    my $fileFormat       = shift @args;
    my $title            = shift @args;
    my $data_href        = shift @args;

    my $mappingFile = 'Mapping_LA_AcuteTravelLogic.pm';

    # By default set to .law format, could be changed in the future, if tracing is possible through manitoo
    unless ( defined $fileFormat ) {
        $fileFormat = 1;
    }

    if ($fileNameTemplate) {
        S_w2log( 4, " LATL_plot_values: 'fileNameTemplate' given as argument : $fileNameTemplate\n" );
        unless ( -f $fileNameTemplate ) {
            S_set_error( "Given LA viewer template file '$fileNameTemplate' doesnt exists", 108 );
            return 0;
        }
    }
    else {
        # check for default Template file
        if ( defined $LATL_template_file ) {
            $fileNameTemplate = $LATL_template_file;
        }
        else {
            S_w2log( 4, " LATL_plot_values: no 'fileNameTemplate' defined in Mapping_LA_AcuteTravelLogic \n" );
            $fileNameTemplate = "OMITTED";    # keep word "OMITED" unchanged, since DLL checks for this also
        }
    }

    # offline mode
    return 1 if ($main::opt_offline);

    unless ( $fileFormat == 1 || $fileFormat == 0 ) {
        S_set_error( "The file format = $fileFormat is out of allowed range [0 ... 1]", 114 );    # 114 = "invalid parameters"
        return;
    }

    my $linkname;
    unless ($fileName) {
        my $tc_name        = $main::TC_REPORT_NAME;
        my $date_extension = '_' . S_get_date_extension();
        $tc_name =~ s/\.html/$date_extension.law/i;
        $fileName = $main::REPORT_PATH . '/' . $tc_name;
        $linkname = File::Spec->abs2rel( $main::REPORT_PATH . '/' . $tc_name, $main::REPORT_PATH );
    }
    else {

        #translate if there is backward slash ('\') to forward slash ('/') in the fileName for proper handling in dll function call.
        $fileName =~ tr/\\/\//;

        # if only file name is given
        if ( $fileName !~ /:|\/|\// ) {
            $fileName = $main::REPORT_PATH . '/' . $fileName;
            $linkname = File::Spec->abs2rel( $fileName, $main::REPORT_PATH );
        }

        # complete path with filename
        else {
            $linkname = $fileName;
            $linkname =~ s/^([A-Za-z]:)/file:\/\/\/$1/;
        }
    }
    my $write_to_html = '<A HREF=' . "$linkname" . ' TYPE="text/law">' . $linkname . '</A>';
    S_w2log( HTML, $write_to_html, 'blue' );

    my $saveAsLawFile_arg_aref = [ $fileName, $fileNameTemplate ];
    my $status = WrapComCallLATL_Method( $LATL_hOle, 'saveAsLawFile', $saveAsLawFile_arg_aref );
    CheckStatus($status) || return;

    unless ( -f $fileName ) {
        S_set_error("LA dump has not been stored in file '$fileName' ");
        return;
    }

    # uniview format
    if ( $fileFormat == 0 ) {

        S_set_error( "Plot values in uniview format CURRENTLY DISABLED ( Not allowed ), due to memory trouble with uniview for undecoded raw data.", 109 );
        return;

        #    DISABLED TILL THE UNIVIEW FORMAT IS SUPPORTED ( DO NOT REMOVE )

        #    unless ($title) {
        #
        #        unless ( exists $LATL_config{'title'} ) {
        #            S_set_error( "LATL_plot_values: Missing title for the trace plot, configure in mapping file '$mappingFile'", 109 );
        #            return;
        #        }
        #        $title = $LATL_config{'title'};
        #    }

        # KEPT FOR FUTURE USE CASE IF UNIVIEW FORMAT IS REQUIRED ( not planned )

        #        unless ( keys %$data_href ) {
        #            S_set_error( "LATL_plot_values: Missing data to plot values, call LATL_get_values before calling plot function", 109 );
        #            return;
        #        }
        #
        #        # Clone input data to avoid modifying caller's data
        #        my $myData_href = clone($data_href);
        #
        #        # Time axis of transitional mode normally cannot be handled by S_create_graph (huge time gaps combined with very small resolution)
        #        if ( $LATL_lastUsedHwMode ne $LATL_HW_MODE_200M_TR_32CH && $LATL_lastUsedHwMode ne $LATL_HW_MODE_200M_TR_8CH ) {
        #
        #            # S_create_graph expects a signal 'time' in ms and takes it as x axis
        #            my $numPts  = scalar( @{ $myData_href->{'time_s'} } );
        #            my @time_ms = (0.0);
        #            foreach my $i ( 0 .. $numPts - 1 ) {
        #                $time_ms[$i] = ${ $myData_href->{'time_s'} }[$i] * $LATL_FACTOR_SEC_TO_MS;
        #            }
        #            $myData_href->{'time'} = \@time_ms;
        #            delete $myData_href->{'time_s'};
        #        }
        #
        #        # Transitional mode
        #        else {
        #            S_set_error( "Plot values in uniview format for Transitional mode causes memory overflow!", 109 );
        #            return;
        #        }
        #        S_create_graph( $myData_href, $fileName, $title, 'white', 'interpolate' );
    }

    S_w2log( 4, " LATL_plot_values: return LA viewer dump file name : $fileName\n" );

    return $fileName;
}

=head2 InitDevice

    $success = InitDevice();

B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub InitDevice {
    my $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKInit' );

    # return 1;
    return CheckStatus($status);
}

=head2 Application_destroy

    $success = Application_destroy();



B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub Application_destroy {
    my $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKClose' );
    return CheckStatus($status);
}

=head2 CheckStatus

    $success = CheckStatus($status);


B<Arguments:>

=over

=item $status

return value of a Acute Travel Logic DLL API call

=back


B<Return Values:>

=over

=item $success

1 on success, undef or 0 otherwise.

=back


B<Examples:>

B<Notes:> 

=cut

sub CheckStatus {
    my $status = shift;

    return 1 if $main::opt_offline;
    if ( $status == 0 ) {
        my $errortext = WrapComCallLATL_Method( $LATL_hOle, 'getLastErrorString' );
        S_set_error( "LATL ($status): $errortext", 5 );
        return 0;
    }

    return $status;
}

=head2 MapPin

    $pinNumber = MapPin($pinName);


B<Arguments:>

=over

=item $pinName

$pinName as given in project const

=back


B<Return Values:>

=over

=item $pinNumber

assigned pinNumber for $pinName in project const.

=back

B<Return:>

Success: assigned pin number in project constant.

Failure: undef

B<Examples:>

MapPin('21_MOSI1');

=cut

sub MapPin {
    my $pinName = shift;
    my $pin;

    unless ( exists $LATL_config{'pinNames'}{$pinName} ) {
        S_set_error( "Pin Mapping for \"$pinName\" is not found in Project Constants ", 114 );
        return;
    }
    else {
        $pin = $LATL_config{'pinNames'}{$pinName};
        unless ( $pin =~ /^\d+$/ ) {
            S_set_error( "The Pin \"$pin\" configured for \"$pinName\" in Project Constants is not a valid number", 20 );
            return;
        }
    }

    S_w2log( 4, " MapPin: Mapped Pin $pinName -> $pin\n" );

    return $pin;
}

=head2 WrapComCallLATL_Method

    $status = WrapComCallLATL_Method($LATL_hOle, $methodName [, $methodArgs_aref]);

B<Description:> Wrapper function, which just wraps all OLE (COM) function calls.

               This auxiliary function was introduced for simulation mode only,
               in order to reduce number of functions to be redefined.

B<Arguments:>

=over

=item $LATL_hOle

OLE handle of LA viewer

=item $methodName

Method name to be invoked.

=item $methodArgs_aref (optional)  

Method arguments that should be passed.

=back

B<Examples:>

    # Invoke method 'ulaSDKThreshold' with arguments '$LATL_SIGNAL_GROUP_0' and  '$LATL_TTL_THRESHOLD_MILLI_VOLT'
    # and returns '$status' 0 or 1
    $status = WrapComCallLATL_Method( $LATL_hOle, 'ulaSDKThreshold',
                                      [$LATL_SIGNAL_GROUP_0,
                                      $LATL_TTL_THRESHOLD_MILLI_VOLT] );
    
    #invoke method 'getDllInfos' without any arguments and returns string '$getdllinfo'
    $getdllinfo = WrapComCallLATL_Method( $LATL_hOle, 'getDllInfos' );
    
    
B<Notes:>

=cut

sub WrapComCallLATL_Method {
    my @args = @_;
    return unless S_checkFunctionArguments( 'WrapComCallLATL_Method ( $LATL_hOle_mix, $methodName [, $methodArgs_aref])', @args );
    $LATL_hOle = shift @args;
    my $methodName      = shift @args;
    my $methodArgs_aref = shift @args;
    my $return_value;

    S_w2log( 3, " LA Acute : WrapComCallLATL_Method: Calling $methodName .. \n", 'grey' );

    if ( defined $methodArgs_aref ) {
        $return_value = $LATL_hOle->$methodName( @{$methodArgs_aref} );
    }
    else {
        $return_value = $LATL_hOle->$methodName();
    }

    if ( not defined $return_value ) {
        S_set_warning(" WrapComCallLATL_Method: $methodName did not returned something ");
        return;
    }

    if ( not ref $return_value ) {

        # just print it in case it's no ref
        S_w2log( 3, " LA Acute : WrapComCallLATL_Method: $methodName returned with : $return_value \n", 'grey' );
    }
    return $return_value;
}

1;
