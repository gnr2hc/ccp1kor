------------------------------------------------------------------------
Perl:                    LIFT_LA_AcuteTravelLogic.pm (via Win32::OLE)
------------------------------------------------------------------------
                       /\
                       ||
                       \/
------------------------------------------------------------------------
LA_AcuteTravelLogic.dll: Bosch DLL (C# class library with COM-Interface)
------------------------------------------------------------------------
                       /\
                       ||
                       \/
------------------------------------------------------------------------
LASDK.dll:               Acute Technology Inc. DLL (high level wrapper with more error checks)
------------------------------------------------------------------------
                       /\
                       ||
                       \/
------------------------------------------------------------------------
LaRun.dll:               Acute Technology Inc. DLL (low level driver DLL)
------------------------------------------------------------------------
                       /\
                       ||
                       \/
------------------------------------------------------------------------
HW: TL2236B              Acute Technology Inc. TravelLogic logic analyzer
------------------------------------------------------------------------


DLL-API functions called from LIFT_LA_AcuteTravelLogic.pm
---------------------------------------------------------
\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\CoreAssetTest\13_TravelLogic_Acute\transitionalModePatch\LA_SDK_CS_20170703\LA_SDK_CS\AcuteLASDK_ProgGuideV1.7a(en).pdf

Remark: If DLL returns true and false via COM, Perl will receive 1 for true and 0 for false

public string getDllInfos()
	Returns above listed 3 DLL names (incl. path) and their version numbers as one string

public bool ulaSDKInit()
	Purpose: Search and init all LA devices connected to PC 
	Returns true, if device initialized successfully
	Returns false otherwise; call getLastErrorString for the last error message

public bool ulaSDKThreshold(int iPod, int iMilliVolt)
	Purpose: Set LA voltage threshold. This value is recommended to set to the mid of target signal.
	Input parameter:
		iPod       = 0 (ch0-15), 1 (ch16-31), 2 (ch32-47), 3 (ch48-63)
		iMilliVolt = Voltage threshold in millivolt as integer
	Returns true, if successful 
	Returns false otherwise; call getLastErrorString for the last error message  

public string getHwInfos()
	Returns Device ID, Name and serial number as one string

public int capture(int[] listOfPins, int triggerPin, int triggerEdge, string hwMode, int numSamples_perCh, int postTriggerSize_pct)
	Purpose: Send capture command to the LA.
	Input parameter:
		listOfPins          = zero-based pin numbers, includes triggerPin number too!
		triggerPin          = zero-based pin number
                triggerEdge         = 0 (=falling), 1 (=rising), 2 (=low), 3 (=high), 4 (=change), -1 (=dontcare, immediate trigger)
                hwMode              = See LIFT_LA_AcuteTravelLogic.pm, List of readonly-scalars: $LATL_HW_MODE_xxx or AcuteLASDK_ProgGuideV1.7a(en).pdf, function ulaSDKSetHwInfo
                numSamples_perCh    = -1 (use max. possible) or 0 ... LA total memory / all opening channel numbers
                postTriggerSize_pct = -1 (use 90%) or 0 ... 100%
	Returns  1, if successful 
	Returns  0, if failed (call getLastErrorString for getting the error message)
        Returns -1, if specified hwMode is not supported

public bool stopCapture()
	Purpose: Send stop capture command to the LA. The LA will keep those data in pre-trigger section.
	Returns true, if successful
	Returns false otherwise; call getLastErrorString for the last error message

public ChData getChData(int iChNo, double timeoutTrigger_sec, double timeoutCapture_sec)
	Purpose: Returns object 'ChData', which contains the properties
                 'time_s' (array of double)
                 'data'   (array of int)
                 'status' (int)
                      1: success
                      0: ulaSDKGetChData failed (call getLastErrorString for getting the error message)
                     -1: trigger not seen within timeoutTrigger_sec
                     -2: capture not ready within timeoutCapture_sec
                     -3: hwMode not supported (set before by capture)
	Input parameter:
		iChNo              = zero-bases channel number
                timeoutTrigger_sec = max. time to wait for trigger
                timeoutCapture_sec = max. time to wait for capture ready
        Returns object 'ChData' (see purpose above)

public bool saveAsLawFile(string filePathName, string filePathNameTemplate)
	Purpose: Store current captured waveform as LAViewer compatible .LAW file.
	Input parameter:
		filePathName         = path and file name
                filePathNameTemplate = valid template path and file name containing Channel display settings or pass string "OMITTED", if not given
	Returns true, if successful
	Returns false otherwise; call getLastErrorString for the last error message

public string getLastErrorString()
	Purpose: Returns error text of last occurred internal LA error

public bool ulaSDKClose()
	Purpose: Shutdown LA
	Returns true, if successful
	Returns false otherwise; call getLastErrorString for the last error message
