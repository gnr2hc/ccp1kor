# *****************************************************************************************************
#
#  Copyright (c) 2012  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_FETbox;

use strict;
use warnings;

BEGIN
{	use LIFT_general;
	S_add_paths2INC(['./FTD2XX'], ['./FTD2XX']);  #Include FTD2XX.pm and Load p5ftd2xx.dll
}

use LIFT_general;
use FTD2XX;

use constant FET_OFF => 'off';
use constant FET_ON  => 'ON';

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  FET_init
  FET_exit
  FET_connect
  FET_disconnect
  FET_get_states
  FET_config
);

our ( $VERSION, $HEADER );

my ( $FET_initialized, $status, $FTDIdevice );

$FET_initialized = 0;

# mapping of pin to port bit position
my %pin2portbit = (
                    1 => 0x08,
                    2 => 0x40,
                    3 => 0x20,
                    4 => 0x80,
                    5 => 0x02,
                    6 => 0x04,
                    7 => 0x10,
                    8 => 0x01,
);
my %name2pin = ();
my %PinState = (
                 1 => FET_OFF,
                 2 => FET_OFF,
                 3 => FET_OFF,
                 4 => FET_OFF,
                 5 => FET_OFF,
                 6 => FET_OFF,
                 7 => FET_OFF,
                 8 => FET_OFF,
);

=head1 NAME

LIFT_FETbox 

=for html
<a href="\\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\CoreAssetTest\12_Pritt" target="blank">
<IMG SRC='..\..\pics\FETbox.png'  alt="PRITT folder" border="0"></a>

wrapper for FETbox, NEW: only FTDI driver has to be installed (should be done by Windows7 automatically).

FETbox driver can be found at \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\CoreAssetTest\12_Pritt\Driver


=head1 SYNOPSIS

    use LIFT_FETbox;

    FET_init();

    FET_config( { 'MOSI' => 1, 'Vstab' => 2, 'VSS' => 3} );

    FET_connect( [ 'VSS', 'Vstab' ] );
    sleep(1);
    $PinState_href = FET_get_states();
    FET_disconnect( [ 'ALL' ] );

    FET_exit();


=head1 DESCRIPTION


=head2 FET_init

    FET_init();

initialize FETbox hardware.

has to be called before any other FET command. has to be called in INITcampaign.

=cut

sub FET_init
{

    if ($FET_initialized)
    {
        S_set_warning( "FETbox already initialized", 120 );
        return;
    }

    if ($main::opt_offline)
    {
        $FET_initialized = 1;
        S_w2log( 4,"FET_init: FETbox intialized successfully \n" );
        return 1;
    }

    $FTDIdevice = FTD2XX->new();
    unless ( $FTDIdevice->PFT_STATUS() == FT_OK )
    {
        S_set_error( "FET_init failed: " . $FTDIdevice->PFT_STATUS_MSG() . "  (" . $FTDIdevice->PFT_ERROR() . ")", 5 );
        return 0;
    }

    my $p5ver  = $FTDIdevice->P5VERSION();
    my $libver = $FTDIdevice->crackLibraryVersion();
    S_w2log( 5, "FET_init: P5 version: $p5ver, USBlib version: $libver\n" );

    my $numDevices = $FTDIdevice->GetNumDevices();
    S_w2log( 5, "FET_init: found $numDevices FTDI devices connected\n" );

    %PinState = (
                  1 => FET_OFF,
                  2 => FET_OFF,
                  3 => FET_OFF,
                  4 => FET_OFF,
                  5 => FET_OFF,
                  6 => FET_OFF,
                  7 => FET_OFF,
                  8 => FET_OFF,
    );


    my $FETboxcount = 0;
    my $FETboxindex = -1;

    foreach my $num ( 0 .. ( $numDevices - 1 ) )
    {
        my $desc = $FTDIdevice->GetDescrByIndex($num);
        print "device $num = $desc\n";
        if ( $desc eq '8xFetSwitch' )
        {
            $FETboxcount++;
            $FETboxindex = $num;
        }
    }
    if ( $FETboxcount > 1 )
    {
        S_set_error( "only 1 FETbox supported but found $FETboxcount", 5 );
        return 0;
    }
    if ( $FETboxcount < 1 )
    {
        S_set_error( "no FETbox found", 5 );
        return 0;
    }

    $status = $FTDIdevice->OpenByIndex($FETboxindex);
    check_status($status);
    my $devInfo = $FTDIdevice->GetDeviceInfo();
    if ($devInfo)
    {
        my $out = sprintf( " Type:\t\t%d (%s)\n ID:\t\tVID(%04X) PID(%04X)\n Serial:\t%s\n Descr:\t%s\n", $devInfo->{TypeID}, $devInfo->{TypeNm}, $devInfo->{VID}, $devInfo->{PID}, $devInfo->{Serial}, $devInfo->{Descr} );
        S_w2log( 5, "FET_init: $out\n" );
    }
    else
    {
        S_set_error( "FETbox device info not found", 0 );    # only warning
    }

    $status = $FTDIdevice->SetBaudRate(921600);
    check_status($status);
    S_w2log( 5, "FET_init: status of SetBaudRate is $status \n" );
    $status = $FTDIdevice->SetBitMode( 0xFF, 0x1 );
    check_status($status);
    S_w2log( 5, "FET_init: status of SetBitMode is $status \n" );

    $FET_initialized = 1;

    S_w2log( 3, "FET_init: FETbox intialized successfully \n" );
    return 1;
}

=head2 FET_config

    FET_config( $map_href );

    $map_href = {
        'MOSI' => 1,
        'Vstab' => 2,
        'VSS' => 3,
    }

configure pin names, has to be called after init before any other function

=cut

sub FET_config
{

    my $map_href = shift;

    my %valcheck = ();

    # check that pin number is unique
    foreach my $name ( keys %$map_href )
    {
        if ( exists $valcheck{ $$map_href{$name} } )
        {
            S_set_error( "pin $$map_href{$name} exists several times", 109 );
        }
        else
        {
            $valcheck{ $$map_href{$name} } = 1;
        }
    }

    # check that pin number is 1 .. 8
    my @nums = sort keys(%valcheck);
    if ( $nums[0] < 1 or $nums[-1] > 8 )
    {
        S_set_error( "pins out of range (has to be in 1 .. 8)", 109 );
    }

    %name2pin = ();
    %name2pin = %$map_href;

    unless ($FET_initialized)
    {
        S_set_error( "FETbox not initialized", 120 );
        return 0;
    }

    S_w2log( 3, "FET_config is done \n" );

    return 1;
}

=head2 FET_get_states

    $PinState_href = FET_get_states();

    e.g.
    $PinState_href = {
        'MOSI'  => 'off',
        'Vstab' => 'ON',
        'VSS'   => 'ON',
    }

get current pin sates

=cut

sub FET_get_states
{

    unless ($FET_initialized)
    {
        S_set_error( "FETbox not initialized", 120 );
        return 0;
    }

    my %states = ();
    foreach my $name ( keys %name2pin )
    {
        $states{$name} = $PinState{ $name2pin{$name} };
    }

    S_w2log( 3, "FET_get_states: States are  read \n" );

    return \%states;
}

=head2 FET_connect

    FET_connect( $names_aref );

    $names_aref names defined by FET_config or 'ALL'

    e.g.
    $names_aref = [ 'VSS', 'Vstab' ]
    $names_aref = [ 'ALL' ]

connect pins via FETbox

=cut

sub FET_connect
{

    my $names_aref = shift;

    unless ($FET_initialized)
    {
        S_set_error( "FETbox not initialized", 120 );
        return 0;
    }

    S_w2log( 5, "FET_connect: Connection of @$names_aref pins Via FETbox \n" );

    if ( scalar(@$names_aref) == 1 and $$names_aref[0] eq 'ALL' )
    {
        # take all defined/configured pins
        foreach my $name ( keys %name2pin )
        {
            $PinState{ $name2pin{$name} } = FET_ON;
        }
    }
    else
    {
        # take all given pins
        foreach my $name (@$names_aref)
        {
            unless ( exists $name2pin{$name} )
            {
                S_set_error( "$name not defined by FET_config", 109 );
            }
            else
            {
                $PinState{ $name2pin{$name} } = FET_ON;
            }
        }
    }

    return 1 if ($main::opt_offline);

    Set_ports();

    return 1;
}

=head2 FET_disconnect

    FET_disconnect(  $names_aref );

    $names_aref names defined by FET_config or 'ALL'

    e.g.
    $names_aref = [ 'VSS', 'Vstab' ]
    $names_aref = [ 'ALL' ]

disconnect pins via FETbox

=cut

sub FET_disconnect
{

    my $names_aref = shift;

    unless ($FET_initialized)
    {
        S_set_error( "FETbox not initialized", 120 );
        return 0;
    }

    S_w2log( 3, "FET_disconnect: Disconnection of @$names_aref pins Via FETbox \n" );

    if ( scalar(@$names_aref) == 1 and $$names_aref[0] eq 'ALL' )
    {
        # take all defined/configured pins
        foreach my $name ( keys %name2pin )
        {
            $PinState{ $name2pin{$name} } = FET_OFF;
        }
    }
    else
    {
        # take all given pins
        foreach my $name (@$names_aref)
        {
            unless ( exists $name2pin{$name} )
            {
                S_set_error( "$name not defined by FET_config", 109 );
            }
            else
            {
                $PinState{ $name2pin{$name} } = FET_OFF;
            }
        }
    }

    return 1 if ($main::opt_offline);

    Set_ports();

    return 1;
}

=head2 FET_exit

    FET_exit();

disconnect pins and shut down FETbox hardware. Has to be called in ENDcampaign.

=cut

sub FET_exit
{

    unless ($FET_initialized)
    {
        S_set_error( "FETbox not initialized", 120 );
        return 0;
    }

    if ($main::opt_offline)
    {
        $FET_initialized = 0;
        S_w2log( 3, "FET_exit: FETbox communication terminated successfully \n" );
        return 1;
    }

    $status = $FTDIdevice->Close();
    check_status($status);

    $FET_initialized = 0;
    S_w2log( 3, "FET_exit: FETbox communication terminated successfully \n" );
    return 1;
}

=head1 not exported functions

=head2 check_status

 check_status($result) not exported

if result != 0, log error and set INCONC.

=cut

sub Check_status
{
    my $chk_status = shift;

    return 1 if $main::opt_offline;
    unless ($chk_status)
    {
        S_set_error( "FETbox Tool error: " . $FTDIdevice->PFT_STATUS_MSG() . "  (" . $FTDIdevice->PFT_ERROR() . ")", 5 );

    }

    return 1;
}

=head2 Set_ports

 Set_ports() not exported

will set ports corresponding to %PinState.

=cut

sub Set_ports
{

    my $switchMask;

    $switchMask = 0;
    foreach my $pin ( keys %PinState )
    {
        if ( $PinState{$pin} eq FET_ON )
        {
            $switchMask += $pin2portbit{$pin};
        }
    }

    my $byteswritten = $FTDIdevice->Write( pack( "C*", $switchMask ) );    # set mask
    if ( $byteswritten != 1 )
    {
        S_set_error( "FETbox communication error", 5 );
        return 0;
    }

    return;
}

# Preloaded methods go here.

1;

=head1 AUTHOR

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl

=cut

