package QUATE;

use strict;
use warnings;
use Carp;
use LIFT_simulation;

require Exporter;
require DynaLoader;
#use AutoLoader;

our @ISA = qw(Exporter DynaLoader);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use QUATE ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
                    qt_DumpStatus
                    qt_GetDeviceDescriptionInternal
                    qt_FreeDLL 
                    qt_GetBusyStatus 
                    qt_GetChipSelect 
                    qt_GetControllerDescription 
                    qt_GetControllerVersion 
                    qt_GetDataFormat 
                    qt_GetDeviceDescription 
                    qt_GetDeviceType 
                    qt_GetDeviceVersion
                    qt_SetTestName
                    qt_GetDLLVersion
                    qt_GetDLLVersionInfo 
                    qt_GetErrorStatus 
                    qt_GetErrorString 
                    qt_GetFirmwareVersion 
                    qt_GetHWConfigurationMode 
                    qt_GetNumberOfChannels 
                    qt_GetNumberOfChipSelects 
                    qt_GetNumberOfControllers 
                    qt_GetNumberOfDACPorts 
                    qt_GetNumberOfDevices 
                    qt_GetNumberOfPSIPorts 
                    qt_GetParameter 
                    qt_GetPSIMonitorMode 
                    qt_GetPSIPort
                    qt_GetResampleFIFOSize
                    qt_GetSerialNumber
                    qt_GetSID 
                    qt_GetSPIMonitorMode 
                    qt_GetStaticData 
                    qt_GetStaticFSMode
                    qt_GetStaticFSMode_ABplus
                    qt_GetStaticFSMode_Internal 
                    qt_GetStaticFSMode_Peripheral 
                    qt_InitDLL
                    qt_LoadHWConfiguration
                    qt_LoadHWConfigurationFromFile
                    qt_ReadFIFOLevel 
                    qt_ReadSPIMonitorLevel
                    qt_ReadSPIMonitorPlusData
                    qt_ResampleFIFOData
                    qt_ResetDevice 
                    qt_ResetFIFO
                    qt_ResetUnit
                    qt_SavePSIMonitorData
                    qt_SaveSPIMonitorData 
                    qt_SendControllerTrigger
                    qt_SetABPlusConfiguration 
                    qt_SetChipSelect  
                    qt_SetClockSource  
                    qt_SetControllerTriggerMode
                    qt_SetDeviceTriggerMode
                    qt_SetDynamicData
                    qt_SetDynamicFSMode
                    qt_SetParameter
                    qt_SetPSIMonitorMode
                    qt_SetSensorConfiguration
                    qt_SetSID
                    qt_SetSPIMonitorMode
                    qt_SetStaticData
                    qt_SetStaticFSMode
                    qt_SetStaticFSMode_ABplus
                    qt_SetStaticFSMode_Internal 
                    qt_SetStaticFSMode_Peripheral
                    qt_SetPSIConfiguration
                    qt_SetTimeBase
                    qt_WriteDeviceAddress
                    qt_ReadDeviceAddress
                    qt_getPMrevision
                    qt_getDLLfilename
                    qt_getXSrevision
                    qt_getCWrevision
);

# ATTENTION:
# 1. $VERSION has to be identical to the $VERSION in the QUATE.pm, which is used during rebuild.bat of XS-Wrapper QUATE.dll,
#    otherwise DynaLoader.pm (Function: bootstrap) will throw the error "QUATE object version 1.020304 does not match bootstrap parameter 1.0 at C:/TurboLIFT/Perl512/lib/DynaLoader.pm line 224".
# 2. $VERSION has to contain only numerical values and dots,
#    otherwise DynaLoader.pm (Function: bootstrap) will throw the error "Invalid version format (non-numeric data) at...".
# 3. Even introducing a 2nd $VERSION_XS will not work, if given to bootstrap command below, because $VERSION is (seems to be) implicitly used for XS purpose!
our ( $VERSION, $HEADER );
$VERSION = '1.0';
bootstrap QUATE $VERSION;

# Preloaded methods go here.

sub qt_DumpStatus{

    my ($CTRLdesc, $CTRLver, $CSnum, $PSInum, $DACnum, $HWmode, $DEVICEnum, $FIRMver, $CTRLserno);
    my ($CTRLstatus, $DLLversion, $DLLversionInfo, $status);
    my ($DEVICEdesc,$DEVICEdescIntern,$DEVICEver,$DEVICEtype,$DEVICEch, $FIFOsize);
    my ($channel, $DEVstatus, $controller, $CTRLnum, $device);
    my ($CSenable, $CHstatus);
    my ($RangeMin, $RangeMax, $ZeroValue, $InputWidth, $OutputWidth, $OutputResolution);

    my $StatusDump = "======================================================================\n";
    $StatusDump .= "QuaTeStatus\n";
    $StatusDump .= "===========\n";

    ($status,$DLLversion) = qt_GetDLLVersion();
    $StatusDump .= "DLL version: $DLLversion\n";
    ($status,$DLLversionInfo) = qt_GetDLLVersionInfo();
    $StatusDump .= "DLL version info: $DLLversionInfo\n";
    $StatusDump .= " PM ".qt_getPMrevision()."\n";
    $StatusDump .= " XS ".qt_getXSrevision()."\n";
    $StatusDump .= " CW ".qt_getCWrevision()."\n";
    $StatusDump .= " Filename ".qt_getDLLfilename()."\n";

    $CTRLnum = qt_GetNumberOfControllers();
    $StatusDump .= "found $CTRLnum controller(s)\n";

    foreach $controller (0..$CTRLnum-1){
        $StatusDump .= "controller $controller:\n";

        ($status,$CTRLdesc) = qt_GetControllerDescription($controller);
        ($status,$CTRLserno) = qt_GetSerialNumber($controller);

        $CTRLver = qt_GetControllerVersion($controller);
        $FIRMver = qt_GetFirmwareVersion($controller);

        $CSnum = qt_GetNumberOfChipSelects($controller);
        $PSInum = qt_GetNumberOfPSIPorts($controller);
        $DACnum = qt_GetNumberOfDACPorts($controller);
        $HWmode = qt_GetHWConfigurationMode($controller);

        $DEVICEnum = qt_GetNumberOfDevices($controller);

        $CTRLstatus = "$CTRLdesc $CTRLserno V_$CTRLver CS_$CSnum PSI_$PSInum DAC_$DACnum HWm_$HWmode DEV_$DEVICEnum";
        $StatusDump .= "$CTRLstatus\n";
        $StatusDump .= "FIRMWARE $FIRMver\n";

        foreach $device (0..$DEVICEnum-1){

            ($status,$DEVICEdesc) = qt_GetDeviceDescription($controller,$device);

            $DEVICEdescIntern = qt_GetDeviceDescriptionInternal($controller,$device);

            $DEVICEver = qt_GetDeviceVersion($controller,$device);

            $DEVICEtype = qt_GetDeviceType($controller,$device);

            $DEVICEch = qt_GetNumberOfChannels($controller,$device);


            $DEVstatus = "$DEVICEdesc (intern name: $DEVICEdescIntern) V$DEVICEver T$DEVICEtype C$DEVICEch";

            if($DEVICEtype == 0){
                ($status,$CSnum,$CSenable) = qt_GetChipSelect($controller,$device);
                $DEVstatus .= " CS : num=$CSnum en=$CSenable";
            }
            $StatusDump .= "* DEVICE $device is $DEVstatus\n";

            foreach $channel (0..$DEVICEch-1){
                $FIFOsize = qt_ReadFIFOLevel($controller,$device,$channel);
                $CHstatus= "C".$channel."buf=$FIFOsize";
                $StatusDump .= "~ $CHstatus\n";

                if ($DEVICEtype == 0){
                    ($status, $RangeMin, $RangeMax, $ZeroValue, $InputWidth, $OutputWidth, $OutputResolution) = qt_GetDataFormat($controller,$device,$channel);
                    $StatusDump .= "~ Min $RangeMin, Max $RangeMax, Z $ZeroValue, IW $InputWidth, OW $OutputWidth, OR $OutputResolution\n";
                }
            }
        }
    }

    $StatusDump .= "======================================================================\n";
    return ($StatusDump);
}

sub qt_getDLLfilename{
    my $dllName = _getDLLfilename();
    $dllName =~ s/\$//g;
    return ($dllName);
}

sub qt_getPMrevision{
    return ('SCM');
}

sub qt_getXSrevision{
    my $XSrev = _getXSrevision();
    $XSrev =~ s/\$//g;
    return ($XSrev);
}

# 
sub qt_getCWrevision{
    my $CWrev = _getCWrevision();
    $CWrev =~ s/\$//g;
    return ($CWrev);
}

if ( $main::opt_simulation ){
    # define all functions that should not be redefined (because they work anyway)
    my @exclude = qw(
        qt_InitDLL qt_SetTestName qt_GetDLLVersion qt_GetDLLVersionInfo qt_getPMrevision qt_getXSrevision qt_getCWrevision qt_getDLLfilename qt_ResampleFIFOData qt_GetResampleFIFOSize
    );
    no strict 'refs';
    # redefine all functions for simulation mode with default return values
    foreach my $function (@EXPORT){
        next if grep {/$function/} @exclude;
        # each function in @EXPORT is redefined using SIM_returnValues
        *{$function} = sub{ return SIM_returnValues($function, 'default', \@_); };
    }

	# define return values table (especially for default values) and pass it to simulation module
	my $returnValuesTable_href = {
		'qt_GetNumberOfControllers' => { 'default' => [1]},
		'qt_GetDeviceDescription' => { 'default' => [1,'SMA6xx '] },
        'qt_GetDeviceDescriptionInternal' => { 'default' => [1,'SMA6xx '] },
		'qt_GetDeviceVersion' => { 'default' => [1,1] },
		'qt_GetNumberOfChipSelects' => { 'default' => [4]},
		'qt_ReadSPIMonitorPlusData' => { 'default' => [1,
		                                              ['000000.097', '000001.098', '000002.099', '000003.100', '000001.100', '000002.100'],
		                                              ['11100111000000000000000001001100', '00100000100000001111111100000000', '00000000000000000000000000010000', '10000000000000000000000000011000', '10001000000000000000000000100000', '00100011000000000000000000001100'],
													  ['11111111111111111111111111111111', '11111111111111111111111111111111', '00101000000011100110000000101100', '00101000000000000000011001101000', '00101000000000000000000000001101', '00101010000100000000000000001110'],
													  ['0', '0', '0', '0', '0', '0'],
													  ['8', '8', '8', '8', '8', '8']] },
		'qt_GetDataFormat'  => { 'default' => [1, 0, 0, 0, 0, 0, 0]},
		'qt_GetResampleFIFOSize'  => { 'default' => [1, 1, 0]},
		'qt_ResampleFIFOData'  => { 'default' => [1, [1]]},
	};
	SIM_addToValuesTable( $returnValuesTable_href );
};

sub qt_GetDeviceDescriptionInternal
{
    my $ctrlIndex = shift;
    my $deviceIndex = shift;

    my $status = -1; # QuaTe DLL error codes start at -1000 and lower, 0 means success
    my $deviceDescriptionInternal;

    # check whether the indexes are found correctly
    if ( defined $deviceIndex )
    {
        my ($param_num, $param_aref);
        ($status, $param_num, $param_aref) = qt_GetParameter($ctrlIndex, $deviceIndex, 0, 'INTERNALDEVICEDESCRIPTION'); # $channelIndex = 0
        if ( $status >= 0 )
        {
            # Due to fixed QuaTe DLL interface, device description comes as integer array, which has to be converted to a string first
            $deviceDescriptionInternal = "";
            my $singleChar;
            for (my $i = 0; $i < $param_num; $i++)
            {
                $singleChar = sprintf("%c", $$param_aref[$i]);
                $deviceDescriptionInternal .= $singleChar;
            }
        }
        else
        {
            $deviceDescriptionInternal = "not found";
        }
    }
    else
    {
        $deviceDescriptionInternal = "not found";
    }

    return ($status, $deviceDescriptionInternal);
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

QUATE - Perl extension for QuaTe Sensor Emulator 

=head1 SYNOPSIS

    use QUATE;
    my ($status, $dev, $DLLversion, $errortext, $CTRLnum, $CTRLdesc);
    my ($DEVICEnum, $DEVICEdesc, $DEVICEver, $CSnum, $CSenable, $param_num, $param_aref);

    $status               = qt_InitDLL();
    
    # read some traceability information
    ($status,$DLLversion) = qt_GetDLLVersion();
    $CTRLnum              = qt_GetNumberOfControllers();
    ($status,$CTRLdesc)   = qt_GetControllerDescription(0);
    $DEVICEnum            = qt_GetNumberOfDevices(0);
    
    foreach $dev (0..$DEVICEnum-1){
      ($status,$DEVICEdesc)      = qt_GetDeviceDescription(0,$dev);
      $DEVICEver                 = qt_GetDeviceVersion(0,$dev);
      ($status,$CSnum,$CSenable) = qt_GetChipSelect(0,$dev);
      if ($status<0){
         print"device$dev: $DEVICEdesc V$DEVICEver (external device)\n";
      }
      else {print"device$dev: $DEVICEdesc V$DEVICEver CS : number=$CSnum enable=$CSenable\n";}
    }

    # create internal sensor fault
    ($status,$param_num,$param_aref) = qt_GetParameter(0, 0, 0, "ERROR");
    $status = qt_SetParameter(0, 0, 0, "ERROR",$param_aref);
    $status = qt_SetParameter(0, 0, 0, "ERROR",[0,0]);
    my @params = (256,0);
    $status = qt_SetParameter(0, 0, 0, "ERROR",\@params);

    # record SPI for 1 second
    $status = qt_SetSPIMonitorMode(0,5,1,0,0,1);
    sleep(1);
    $status = qt_SetSPIMonitorMode(0,5,0,0,0,0);
    
    ($status, $Time_aref, $MOSI_aref, $MOSI16_aref, $MOSI32_aref, 
      $MISO_aref, $MISO16_aref, $MISO32_aref, $CS_aref, $Status_aref, 
      $Length_aref) = qt_ReadSPIMonitorPlusData(0,5,10);
      
    $status = qt_SaveSPIMonitorData(0,5,"testSPIrecord.csv");

    # record PSI for 1 second
    $status = qt_SetPSIMonitorMode(1, 12, 1, 1, 1, 0, 0);
    sleep(1);
    $status = qt_SetPSIMonitorMode(1, 12, 0, 1, 1, 0, 0);

    $status = qt_SavePSIMonitorData(1, 12, "testPSIrecord.csv");
    
    # creating temporary TFF fault for 100 ms (disturb)

    qt_LoadHWConfigurationFromFile(0,'.\rev2_step4_v2.bit');
    qt_SetChipSelect(0,2,4,1);

    $status = qt_SetParameter(0, 2, 0, "FSR_FLAGS", [4]);

    $status=qt_SetDeviceTriggerMode(0, 2, 0, 2, 0);
    $status=qt_SetDeviceTriggerMode(0, 2, 1, 2, 0);

    $status=qt_SetControllerTriggerMode(0, 0, 2);

    $status=qt_SetTimeBase(0, 2, 0, 250);
    $status=qt_SetTimeBase(0, 2, 1, 250);

    $status=qt_SetDynamicFSMode(0, 2, 0, "TFF", 0, 100000, 0, 0, 0, 0);

    my @data=(0)x4000;
    $status=qt_SetDynamicData(0, 2, 0, \@data, 0);
    $status=qt_SetDynamicData(0, 2, 1, \@data, 0);

    $status=qt_SendControllerTrigger(0, 2);

    sleep(4);

    $status = qt_SetParameter(0, 2, 0, "FSR_FLAGS", [0]);

    $status=qt_SetControllerTriggerMode(0, 0, 0);




    $status = qt_FreeDLL();



=head1 DESCRIPTION

All these functions are wrapped around Quate DLL APIs. Read QuaTe documentation for details. All values have to be decimal ! 
$status = 0 means successful, $status < 0 means error. 


=head2 qt_DumpStatus

 $status = qt_DumpStatus();

read full status information from Quate and return as string, will list all controllers and devices


=head2 qt_GetDeviceDescriptionInternal


I<B<Syntax : >>

    ($status, $deviceDescriptionInternal) = qt_GetDeviceDescriptionInternal($ctrlIndex, $deviceIndex);

I<B<Arguments    : >>

    $ctrlIndex         =   QuaTe Controller Index (zero-based)
    $deviceIndex       =   Device Index (zero-based)

I<B<Description :>>

Returns internal QuaTe device description of the requested ctrlIndex and deviceIndex.

Some devices have a different internal device description, compared to 'normal' description,
since the latter is changed by ROM-File parameters to a specific type.

These devices are currently: PSI5DEVICE, SMA7xx, SMI8xx.

Purpose is to have a constant generic or family name, which allows certain logical decisions for a whole sensor family.

I<B<Return values :>>

    ($status, $deviceDescriptionInternal)
      $status: return value of qt_GetParameter (QuaTe DLL return code)

I<B<Examples :>>

   ($status, $deviceDescriptionInternal) = qt_GetDeviceDescriptionInternal( 0, 5 );


=head2 qt_FreeDLL

 $status = qt_FreeDLL();

Free QuaTe DLL. Should be called at the end of test run.


=head2 qt_GetBusyStatus

 $BusyStatus = qt_GetBusyStatus( $CTRLnum );

returns busy status.


=head2 qt_GetChipSelect

 ($status, $CS, $Enable ) = qt_GetChipSelect( $CTRLnum, $DEVICEnum );

returns chipselect and enable status for device.


=head2 qt_GetControllerDescription

 ($status, $CTRLdesc) = qt_GetControllerDescription( $CTRLnum );

returns textual description for controller.


=head2 qt_GetControllerVersion

 $CTRLver = qt_GetControllerVersion( $CTRLnum );

returns version number of controller.


=head2 qt_GetDataFormat

 ($status, $RangeMin, $RangeMax, $ZeroValue, $InputWidth, $OutputWidth, $OutputResolution) = qt_GetDataFormat( $CTRLnum, $DEVICEnum, $CHnum );

returns data format values for channel.


=head2 qt_GetDeviceDescription

 ($status, $DEVICEdesc) = qt_GetDeviceDescription( $CTRLnum, $DEVICEnum );

returns textual description for device like sensor name.


=head2 qt_GetDeviceType

 $DEVICEver = qt_GetDeviceType( $CTRLnum, $DEVICEnum );

returns type of device.


=head2 qt_GetDeviceVersion

 $DEVICEver = qt_GetDeviceVersion( $CTRLnum, $DEVICEnum );

returns version number of device.

=head2 qt_SetTestName

 $status = qt_SetTestName($testName);

returns status (0: no error)

=head2 qt_GetDLLVersion

 ($status, $DLLversion) = qt_GetDLLVersion();

returns status and version of DLL e.g. 03D

=head2 qt_GetDLLVersionInfo

 ($status, $DLLversionInfo) = qt_GetDLLVersionInfo();

returns status and longer versionInfo of DLL


=head2 qt_GetErrorStatus

 $ErrorStatus = qt_GetErrorStatus( $CTRLnum );

returns error status.


=head2 qt_GetErrorString

 $errorstring = qt_GetErrorString( $status );

returns the error text of a error value e.g. from status variable. Note: error values are < 0.


=head2 qt_GetFirmwareVersion

 ($status, $FIRMWARE) = qt_GetFirmwareVersion($CTRLnum);

returns hash string for controller firmware.


=head2 qt_GetHWConfigurationMode

 $CTRLhwm = qt_GetHWConfigurationMode( $CTRLnum );

returns HW configuration mode of controller.


=head2 qt_GetNumberOfChannels

 $CHnum = qt_GetNumberOfChannels( $CTRLnum, $DEVICEnum );

returns number of channels.


=head2 qt_GetNumberOfChipSelects

 $CRTLcs = qt_GetNumberOfChipSelects( $CTRLnum );

returns number of chip selects of controller.


=head2 qt_GetNumberOfControllers

 $CTRLnum = qt_GetNumberOfControllers();

returns number of controllers, typically one per QuaTe HW


=head2 qt_GetNumberOfDACPorts

 $CTRLdac = qt_GetNumberOfDACPorts( $CTRLnum );

returns number of DAC ports of controller.


=head2 qt_GetNumberOfDevices

 $DEVICEnum = qt_GetNumberOfDevices( $CTRLnum );

returns number of devices of controller.


=head2 qt_GetNumberOfPSIPorts

 $CTRLpsi = qt_GetNumberOfPSIPorts( $CTRLnum );

returns number PSI ports of controller.


=head2 qt_GetParameter

 ($status, $param_num, $param_aref) = qt_GetParameter( $CTRLnum, $DEVICEnum, $CHnum, $param_name );

returns array reference to parameter values fro channel.


=head2 qt_GetPSIMonitorMode

 ($status, $Enable, $FilterBusy, $FilterPort, $PortMode, $Raw) = qt_GetPSIMonitorMode( $CTRLnum, $DEVICEnum );

returns PSI monitor mode values for device.

=head2 qt_GetPSIPort

 $psiPort = qt_GetPSIPort( $CTRLnum, $DEVICEnum );

returns the assigned output port.

=head2 qt_GetResampleFIFOSize

 ($status,$OutSize,$OutTime) = qt_GetResampleFIFOSize($InSize, $InTime );
 e.g (0, 669, 114) = qt_GetResampleFIFOSize(660, 113.778)

calculates the best time base settings for the FIFO.The QuaTe can only handle integral timer settings 

=head2 qt_GetSerialNumber

 ($status, $CTRLserno) = qt_GetSerialNumber( $CTRLnum );

returns serial number of controller.


=head2 qt_GetSID

 ($status, $SID) = qt_GetSID( $CTRLnum, $DEVICEnum, $CHnum );

returns internal sensor configuration values for channel.


=head2 qt_GetSPIMonitorMode

 ($status, $Enable, $MISOext, $FilterBusy, $OSC) = qt_GetSPIMonitorMode( $CTRLnum, $DEVICEnum );

returns SPI monitor mode values for device.

$DEVICEnum has to be a SPI_MONITOR


=head2 qt_GetStaticData

 ($status, $data) = qt_GetStaticData( $CTRLnum, $DEVICEnum, $CHnum, $DataFormat );

returns static data for channel.

=head2 qt_GetStaticFSMode

    ($status, $FailureMask) = qt_GetStaticFSMode($CTRLnum, $DEVnum, $CHnum, $FailureType);
    e.g. ($status, $FailureMask) = qt_GetStaticFSMode(0,3,0, 'Manchester');

reads the mask value for particular Failure type of a sensor channel

=head2 qt_GetStaticFSMode_ABplus

 ($status, $GSerror) = qt_GetStaticFSMode_ABplus( $CTRLnum, $DEVICEnum, $CHnum );

returns AB+ sensor fault mode values for channel.


=head2 qt_GetStaticFSMode_Internal

 ($status, $SID, $NRO, $TST, $TFF, $ExtReg) = qt_GetStaticFSMode_Internal( $CTRLnum, $DEVICEnum, $CHnum );

returns internal sensor fault mode values for channel.


=head2 qt_GetStaticFSMode_Peripheral

 ($status, $Manchester, $Parity, $BufferEmpty) = qt_GetStaticFSMode_Peripheral( $CTRLnum, $DEVICEnum, $CHnum );

returns peripheral sensor fault mode values for channel.


=head2 qt_InitDLL

 $status = qt_InitDLL();

Initialize QuaTe DLL. Has to be called before any other function.


=head2 qt_LoadHWConfiguration

 $status = qt_LoadHWConfiguration( $CTRLnum, $Configuration );

Select firmware from flash for QuaTe Rev 2.


=head2 qt_LoadHWConfigurationFromFile

 $status = qt_LoadHWConfigurationFromFile( $CTRLnum, $filename );

Load firmware from file for QuaTe Rev 2.


=head2 qt_ReadFIFOLevel

 $FIFOlevel = qt_ReadFIFOLevel( $CTRLnum, $DEVICEnum, $CHnum );

returns FIFO level.


=head2 qt_ReadSPIMonitorLevel

 $samples = qt_ReadSPIMonitorLevel( $CTRLnum, $DEVICEnum );

returns number of samples recorded by SPI recorder.

$DEVICEnum has to be a SPI_MONITOR


=head2 qt_ReadSPIMonitorPlusData

 ($status, $Time_aref, $MOSI_aref, $MISO_aref, $CS_aref, $Status_aref) = qt_ReadSPIMonitorPlusData( $CTRLnum, $DEVICEnum, $samples );

returns references to arrays of SPI trace.

$DEVICEnum has to be a SPI_MONITOR


=head2 qt_ResampleFIFOData

 ($status,$OutData_ref) = qt_ResampleFIFOData($Data_aref, $InTime,$OutSize,$OutTime,$Mode );
 e.g qt_ResampleFIFOData([0.5, 2, 5, 6, 7 , 4.5, 1, 2], 20, 10, 16, 1 );
 
resamples the original data to fit the best time base and FIFO data settings.


=head2 qt_ResetDevice

 $status = qt_ResetDevice( $CTRLnum, $DEVICEnum );
 e.g. $status = qt_ResetDevice(0,3);

reset device, all device settings will be set to default

=head2 qt_ResetFIFO

 $status = qt_ResetFIFO( $CTRLnum, $DEVICEnum, $CHnum );
 e.g. $status = qt_ResetFIFO(0,3,0);

reset the FIFO of particular channel. All the data inside the FIFO will be deleted.

=head2 qt_ResetUnit

 $status = qt_ResetUnit( $CTRLnum );
 e.g. $status = qt_ResetUnit(0);

reset Quate, all settings will be set to default

=head2 qt_SavePSIMonitorData

 $status = qt_SavePSIMonitorData($CTRLnum, $DEVICEnum, $path_to_CSV_file);
 e.g. $status = qt_SavePSIMonitorData(1, 12, "testPSIrecord.csv");
 
save recorded PSI data to file. This may take some time.

=head2 qt_SaveSPIMonitorData

 $status = qt_SaveSPIMonitorData( $CTRLnum, $DEVICEnum, $path_to_CSV_file );

save recorded SPI data to file. This may take some time.

$DEVICEnum has to be a SPI_MONITOR


=head2 qt_SendControllerTrigger

 $status = qt_SendControllerTrigger( $CTRLnum, $trigline );
 e.g $status = qt_SendControllerTrigger(0,2);

send controller trigger


=head2 qt_SetABPlusConfiguration

 $status = qt_SetABPlusConfiguration( $CTRLnum, $DEVICEnum, $CHnum, $path_to_sensor_config );
 e.g. $status = qt_SetABPlusConfiguration(0,4,"C:\\test\\QUATE\\SMB225_1.cfg");

configure sensor by sensor configuration file


=head2 qt_SetChipSelect

 $status = qt_SetChipSelect( $CTRLnum, $DEVICEnum, $CS, $Enable );
 e.g $status = qt_SetChipSelect(0,4,0,1);

set chip select on QuaTe ($Enable = 1 set CS, 0 reset CS). $CS depends on the connector from QuaTe to ECU.

=head2 qt_SetClockSource

 $status = qt_SetChipSelect( $CTRLnum, $ClkSrc);
 e.g., $status = qt_SetChipSelect( $CTRLnum, $ClkSrc);

    $ClkSrc = 0  --> Internal clock source (clock master mode)
    $ClkSrc = 1  --> External clock source (clock slave mode)

select the reference clock source for all I/O operations of specified unit

=head2 qt_SetControllerTriggerMode

 $status = qt_SetControllerTriggerMode( $CTRLnum, $trig1, $trig2 );
 e.g $status = qt_SetControllerTriggerMode(0,0,2);

set controller trigger mode


=head2 qt_SetDeviceTriggerMode

 $status = qt_SetDeviceTriggerMode( $CTRLnum, $DEVICEnum, $CHnum, $input_mode, $output_mode  );
 e.g $status = qt_SetDeviceTriggerMode(0, 2, 0, 2, 0);

set device trigger mode


=head2 qt_SetDynamicData

 $status = qt_SetDynamicData( $CTRLnum, $DEVICEnum, $CHnum, $data_aref, $dataformat );
 e.g    @data=(0)x4000;
    $status = qt_SetDynamicData(0, 2, 0, \@data, 0);

set dynamic sensor data


=head2 qt_SetDynamicFSMode

 $status = qt_SetDynamicFSMode( $CTRLnum, $DEVICEnum, $CHnum, $errortype, $T1, $D1, $T2, $D2, $T3, $D3 );
 e.g $status = qt_SetDynamicFSMode(0, 2, 0, "TFF", 0, 100000, 0, 0, 0, 0);

set dynamic fault simulation mode, $Tx is starttime in microseconds, $Dx is duration in microseconds


=head2 qt_SetParameter

 $status = qt_SetParameter( $CTRLnum, $DEVICEnum, $CHnum, $param_name, $param_aref );
 e.g $status = qt_SetParameter(0, 1, 0, "ERROR", [0,0]);

set parameter for device. Parameters depend on device, please check QuaTe documenattion for details. $Parameter_aref has to be a reference to an array.

=head2 qt_SetPSIMonitorMode

 $status = qt_SetPSIMonitorMode( $CTRLnum, $DEVnum, $iEnable, $iFilterBusy, $iFilterPort, $iPortMode, $iRaw);
 
 E.g. record PSI for 1 second
 $status = qt_SetPSIMonitorMode(1, 12, 1, 1, 1, 0, 0);
 sleep(1);
 $status = qt_SetPSIMonitorMode(1, 12, 0, 1, 1, 0, 0);
 
set PSI monitoring mode.

=head2 qt_SetSensorConfiguration

 $status = qt_SetSensorConfiguration( $CTRLnum, $DEVICEnum, $path_to_sensor_config );
 e.g. $status = qt_SetSensorConfiguration(0,4,"C:\\test\\QUATE\\SMI500_1.cfg");

configure sensor by sensor configuration file

=head2 qt_SetSID

 $status = qt_SetSID( $CTRLnum, $DEVICEnum, $CHnum, $SID );
 e.g. $status = qt_SetSID(0,4,1,2);

sets SID of particular channel of a Device in particular Quate

=head2 qt_SetSPIMonitorMode

 $status = qt_SetSPIMonitorMode( $CTRLnum, $DEVICEnum, $Enable, $MISOext, $FilterBusy, $FilterCS );

set SPI monitoring mode. $FilterCS = 2^CS 

 e.g. CS 2   -> $FilterCS = 4 (set a 1 for the CS bit you want to record)
      CS 4+6 -> $FilterCS = 2^4+2^6 = 16+64 = 80

$DEVICEnum has to be a SPI_MONITOR


=head2 qt_SetStaticData

 $status = qt_SetStaticData( $CTRLnum, $DEVICEnum, $CHnum, $Data, $DataFormat);

set static data

$DataFormat 0-format like output, 1-format like input

=head2 qt_SetStaticFSMode

    $status = qt_GetStaticFSMode($CTRLnum, $DEVnum, $CHnum, $FailureType, $FailureMask);
    e.g. $status = qt_GetStaticFSMode(0,3,0, 'Manchester', 0x01);

sets the mask value for particular Failure type of a sensor channel

=head2 qt_SetStaticFSMode_ABplus

 $status = qt_SetStaticFSMode_ABplus( $CTRLnum, $DEVICEnum, $CHnum, $GSerror );

set AB+ sensor fault mode values for channel.


=head2 qt_SetStaticFSMode_Internal

 $status = qt_SetStaticFSMode_Internal( $CTRLnum, $DEVICEnum, $CHnum, $SID, $NRO, $TST, $TFF, $ExtReg);

set internal sensor fault mode values for channel.


=head2 qt_SetStaticFSMode_Peripheral

 $status = qt_SetStaticFSMode_Peripheral( $CTRLnum, $DEVICEnum, $CHnum, $Manchester, $Parity, $BufferEmpty);

set peripheral sensor fault mode values for channel.

=head2 qt_SetPSIConfiguration

 $status = qt_SetPSIConfiguration($CTRLnum, $DEVICEnum, $filepath);
 
loads the configuration file for specifying the sensor more precise.

=head2 qt_SetTimeBase

 $status = qt_SetTimeBase( $CTRLnum, $DEVICEnum, $CHnum, $time_us );
 e.g $status = qt_SetTimeBase(0, 2, 0, 250);

set timebase, timebase is in microseconds


=head1 FOR DEBUGGING ONLY

=head2 qt_ReadDeviceAddress

 ($status, $Data) = qt_ReadDeviceAddress( $CTRLnum, $DEVICEnum, $CHnum, $ModulAddress, $MirrorAddress, $Size);

provides a direct access to all device specific registers within the QuaTe device module

=head2 qt_WriteDeviceAddress

 $status = qt_WriteDeviceAddress( $CTRLnum, $DEVICEnum, $CHnum, $ModulAddress, $MirrorAddress, $Data, $Size);

provides a direct access to all device specific registers within the QuaTe device module

=head2 qt_getPMrevision

returns MKS revision number of .pm file

=head2 qt_getXSrevision

returns MKS revision number of .xs file

=head2 qt_getDLLfilename

returns the QuaTe DLL filename

=cut

=head2 qt_getCWrevision

returns MKS revision number of C wrapper file

=cut


=head1 AUTHOR

Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>


=head1 SEE ALSO

perl, QuaTe documentation

=cut
