# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_QuaTe;

use strict;
use warnings;
use LIFT_numerics;
use File::Basename;
use Data::Dumper;
use Win32::OLE;
use Win32::OLE::Const 'Microsoft Excel';
use Readonly;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['./Win32'], ['./Win32']);
}

use QUATE;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use LIFT_QuaTe ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
        QuaTe_GetChipSelectByDeviceName
        QuaTe_GetDeviceDescription
		QuaTe_GetDeviceDescriptionInternal
        QuaTe_GetDeviceProperties
        QuaTe_GetIndexFromDevice
        QuaTe_DownloadData
        QuaTe_DumpStatus
        QuaTe_Exit
        QuaTe_GetDLLVersion
        QuaTe_GetParameter
        QuaTe_GetPSIPortByDeviceName
        QuaTe_GetStaticData
        QuaTe_GetStaticFSMode
        QuaTe_Init
        QuaTe_configure
        QuaTe_LoadHWConfiguration
        QuaTe_ReadSPIMonitorLevel
        QuaTe_ReadSPIMonitorPlusData
        QuaTe_ResetController
        QuaTe_SavePSIMonitorData
        QuaTe_SaveSPIMonitorData
        QuaTe_SendControllerTrigger
        QuaTe_SetChipSelect
        QuaTe_SetControllerTriggerMode
        QuaTe_SetDynamicData
        QuaTe_SetOverloadChannel
        QuaTe_SetParameter
        QuaTe_SetPSIMonitorMode
        QuaTe_SetSPIMonitorMode
        QuaTe_SetSensorConfiguration
        QuaTe_SetStaticData
        QuaTe_SetStaticFSMode
        QuaTe_SetTestName
        
        $SENSOR_PROPERTY_DEV_TYPE_INTERN
        $SENSOR_PROPERTY_INPUT_BIT_WIDTH
);

our ($VERSION,$HEADER);
my ($status);
my $QT_initialized = 0;
my $NumOfCtrls;# number of Controllers used
my %Device_hash; # global Device HASH
my $Quate = "QUATE";
my $MaxNumOfCtrls = 8; # max number of QuaTe uints supported is 8.
my $decoder_xls_flag = 0; #flag to create decoder Excel sheet
my %errormsg = (); #holds decoders error messages
my ($excel,$Sheet,$workbook,$excelfile_abs,$excelsheetname,$excelfile);#for SMA660 decoder
my ( %gPsiDevicesSetup4Inject, %gSpiDevicesSetup4Inject );
my $ERR_MSG_QT_MONITOR = 'Possible reasons: [1] ZERO-Emulation crash, [2] Missing call or Error of QuaTe_DownloadData, or [3] QuaTe_Exit called before';
use constant NEGATIVE_STATUS => -1;

Readonly our $SENSOR_PROPERTY_DEV_TYPE_INTERN => "DEV_TYPE_INTERN"; # 0: EDIF, 1|2: PSI5DEVICE_1CH|2CH , 3: OFFLINE (no QuaTe-HW)
Readonly our $SENSOR_PROPERTY_INPUT_BIT_WIDTH => "INPUT_BIT_WIDTH";
Readonly my $MIN_PSI5DEVCE_SAMPLING_TIME_US   => 94.031221;
Readonly my $NOM_PSI5DEVCE_SAMPLING_TIME_US   => 113.777777; # VDA filter output: 0.000113777777778 s
Readonly my $MAX_PSI5DEVCE_SAMPLING_TIME_US   => 144.022503;

my $Channel_Hash;
my %GlobalSettings = ();
my $NumOfQuates = 0;
my $excel_count = 1;

my $module_name = __PACKAGE__;
##########################

use constant DEVICE_TYPE_SPI               => 0;
use constant DEVICE_TYPE_PSI               => 1;
use constant DEVICE_TYPE_DAC               => 2;
use constant DEVICE_TYPE_SPI_MONITOR       => 3;
use constant DEVICE_TYPE_PSI_MONITOR       => 4;
use constant DEVICE_TYPE_ABPLUS_DEVICE     => 5;
use constant DEVICE_TYPE_MM5               => 7;
use constant DEVICE_TYPE_PSI_AND_SPI       => 8;
use constant DEVICE_TYPE_PSIMASTER         => 97;# used only for Development purpose
use constant DEVICE_TYPE_SPIMASTER         => 98;# used only for Development purpose

#A HASH TO HOLD DEVICE TYPES AVAILABLE IN QUATE
my %DeviceTypes = (
    0      => 'INTERNAL_DEVICE_SPI',
    1      => 'PERIPHERAL_DEVICE_PSI',
    2      => 'ANALOG_DEVICE_DAC',
    3      => 'SPI_MONITOR_PLUS_64',
    4      => 'PSI_MONITOR',
    5      => 'ABPLUS_DEVICE_SPI',
    7      => 'MM5_SPI',
    8      => 'AB12_SPI_PSI',
    97     => 'PSI_MASTER',
    98     => 'SPI_MASTER'
);

my %ValidDynamicFSerrortype = (
    'SID'         => 1,
    'NRO'         => 1,
    'TST'         => 1,
    'TFF'         => 1,
    'Manchester'  => 1,
    'BufferEmpty' => 1,
    'Parity'      => 1,
    'GS'          => 1,
);

my %QuaTe_Trigger_Mapping = (
    'OFF'         => 0,
    'POS_SLOPE'   => 1,
    'NEG_SLOPE'   => 2,
    'EXT_TRIGGER' => 3,
);

my %Device_Trigger_Mapping = (
    'OFF'                  => 0,
    'TRIG_LINE1_NEG_SLOPE' => 1,
    'TRIG_LINE2_NEG_SLOPE' => 2,
    'TRIG_LINE2_POS_SLOPE' => 3,
);

my %ValidParameterNames = (
    'ACC1_2K'                    => 1,
    'ACC2_2K'                    => 1,
    'AGC'                        => 1,
    'AGC'                        => 1,
    'ARMING_PIN'                 => 1,
    'ASSD'                       => 1,
    'AUTOCALIB'                  => 1,
    'BITEVALUE'                  => 1,
    'BufferEmpty'                => 1,
    'CHIPADDR'                   => 1,
    'CHIP_ID'                    => 1,
    'CLK_CNT_DIFF'               => 1,
    'CMRA'                       => 1,
    'CMRD'                       => 1,
    'CTM_RAW'                    => 1,
    'CURRENT'                    => 1,
    'DEV_ID'                     => 1,
    'ENABLE'                     => 1,
    'ERROR'                      => 1,
    'ERROR_BANK'                 => 1,
    'ERROR_COUNTER'              => 1,
    'ErrorNumber'                => 1,
    'Failure_mode'               => 1,
    'FastOffsetCanErr'           => 1,
    'FSR_CFG'                    => 1,
    'FSR_CONFIG'                 => 1,
    'FSR_CTL'                    => 1,
    'FSR_EXTREG'                 => 1,
    'FSR_FLAGS'                  => 1,
    'FSR_INVERT'                 => 1,
    'FSR_LIN'                    => 1,
    'FSR_MIRROR'                 => 1,
    'FSR_MONITOR'                => 1,
    'FSR_NOISEOFFS'              => 1,
    'FSR_OC_MODE'                => 1,
    'FSR_OC_STEPS'               => 1,
    'FSR_OC_REG'                 => 1,
    'FSR_OFFSET'                 => 1,
    'FSR_RD_MODE'                => 1,
    'FSR_SID'                    => 1,
    'FSR_TEST_MODE'              => 1,
    'GenASICError'               => 1,
    'INJ_BIT_FIR'                => 1,
    'INITIALVALUE_TEMP1'         => 1,
    'INITIALVALUE_TEMP2'         => 1,
    'INTERNALDEVICEDESCRIPTION'  => 1,
    'LockErrorBit'               => 1,
    'LTR'                        => 1,
    'NoFilter_Active'            => 1,
    'NOISE_ACC1_LF'              => 1,
    'NOISE_ACC2_LF'              => 1,
    'NOISE_ACC3_LF'              => 1,
    'NOISE_RATE_LF'              => 1,
    'NOISE_RATE1_LF'             => 1,
    'NOISE_RATE2_LF'             => 1,
    'NOISE_ACC1_HF'              => 1,
    'NOISE_ACC2_HF'              => 1,
    'NOISE_ACC3_HF'              => 1,
    'NOISE_RATE_HF'              => 1,
    'NOISE_RATE1_HF'             => 1,
    'NOISE_RATE2_HF'             => 1,
    'NTR'                        => 1,
    'NTR_ACCX'                   => 1,
    'NTR_ACCY'                   => 1,
    'NTR_LINACCX'                => 1,
    'NTR_LINACCY'                => 1,
    'NTR_YAWQUAD'                => 1,
    'NTR_YAWRATE'                => 1,
    'NTR_YAWRATE2'               => 1,
    'OFFSETVALUE'                => 1,
    'OFFSETVALUE_ACC1_LF'        => 1,
    'OFFSETVALUE_ACC1_HF'        => 1,
    'OFFSETVALUE_ACC2_LF'        => 1,
    'OFFSETVALUE_ACC2_HF'        => 1,
    'OFFSETVALUE_ACC3_LF'        => 1,
    'OFFSETVALUE_ACC3_HF'        => 1,
    'OFFSET_X'                   => 1,
    'OFFSET_Y'                   => 1,
    'OSC'                        => 1,
    'OTP'                        => 1,
    'OTPError'                   => 1,
    'OTPIntegrity'               => 1,
    'OVERLOAD_CONFIG'            => 1,
    'OVERLOAD_CONFIG1'           => 1,
    'OVERLOAD_CONFIG2'           => 1,
    'OVERLOAD_RATE_LF'           => 1,
    'OVERLOAD_RATE1_LF'          => 1,
    'OVERLOAD_RATE2_LF'          => 1,
    'OVERLOAD_ACC1_LF'           => 1,
    'OVERLOAD_ACC1_HF'           => 1,
    'OVERLOAD_ACC2_LF'           => 1,
    'OVERLOAD_ACC2_HF'           => 1,
    'OVERLOAD_ACC3_LF'           => 1,
    'OVERLOAD_ACC3_HF'           => 1,
    'OVERLOAD_CLEAR'             => 1,
    'PARTID'                     => 1,
    'POL_PHASE'                  => 1,
    'PosSelfTestErr'             => 1,
    'PTR'                        => 1,
    'PTR_ACCX'                   => 1,
    'PTR_ACCY'                   => 1,
    'PTR_LINACCX'                => 1,
    'PTR_LINACCY'                => 1,
    'PTR_YAWQUAD'                => 1,
    'PTR_YAWRATE'                => 1,
    'PTR_YAWRATE2'               => 1,
    'QUAD_2K'                    => 1,
    'QUAD_I'                     => 1,
    'QUAD_IR'                    => 1,
    'RATE_2K'                    => 1,
    'RATE_DC'                    => 1,
    'RATE_HF'                    => 1,
    'RESET_LINE'                 => 1,
    'REV_ID'                     => 1,
    'RT_MODE'                    => 1,
    'SAMPLINGTIME_PS'            => 1,
    'SELFTEST_REF1'              => 1,
    'SELFTEST_REF2'              => 1,
    'SENSORCONFIG'               => 1,
    'SERIAL_CUSTOM'              => 1,
    'SERIAL_NUMBER'              => 1,
    'SKIP_INIT'                  => 1,
    'SlowOffsetCanErr'           => 1,
    'SPI_ERROR'                  => 1,
    'TEMP'                       => 1,
    'TEMP1'                      => 1,
    'TEMP2'                      => 1,
    'TRIM1'                      => 1,
    'TRIM2'                      => 1,
    'TRIM3'                      => 1,
    'TRIM4'                      => 1,
    'TRIM5'                      => 1,
    'WDGI_LINE'                  => 1,
    'WDGI_PIN'                   => 1,
    'sNTR'                       => 1,
    'sPTR'                       => 1,
);

# hash maps SMI8xx channel numbers to OVERLOAD register names
# Found here: ROM File Generator (Version 2.8, last saved: March 6 2019, sheet: SMI8xx):
# ;-------------------------------    
# ; channel assignment    
# ;   
# ; sensor signal | QuaTe channel | SMI800  | SMI810  | SMI860    
# ; ------------------------------|-------------------------- 
# ;   RATE1_LF    |   CH0         |        |        |        
# ;   ACC1_LF     |   CH1         |        |        |      
# ;   ACC2_LF     |   CH2         |        |        |    
# ;   ACC1_HF     |   CH3         |        |        |       
# ;   ACC2_HF     |   CH4         |        |        |       
# ;   RATE2_LF    |   CH5         |        |        |       
# ;   ACC3_LF     |   CH6         |        |        |       
# ;   ACC3_HF     |   CH7         |        |        |   
my %OverloadChSMI8xx = (
    0      => 'OVERLOAD_RATE1_LF',
    1      => 'OVERLOAD_ACCEL1_LF',
    2      => 'OVERLOAD_ACCEL2_LF',
    3      => 'OVERLOAD_ACCEL1_HF',
    4      => 'OVERLOAD_ACCEL2_HF',
    5      => 'OVERLOAD_RATE2_LF',
    6      => 'OVERLOAD_ACCEL3_LF',
    7      => 'OVERLOAD_ACCEL3_HF',
);

=head1 NAME

LIFT_QuaTe 

Perl extension for QuaTe

=head1 QuaTe Usage

Below are the steps which will help you to start with QuaTe usage.

1. To start with, you have to install device drivers for QuaTe. use the drivers from N: drive.
Installation instructions : \\siz1130\aerse$\Support\Tools\QuaTe\10_Hardware\B_Revision2\70_Documentation\AB_Sens_80_10_10_B_70_003_Driver_Installation_Guide.pdf

2. For using QuaTe for your project, you have to identify the firmwares based on Sensor emulation needs by the Project.
You can get the overview of available firmwares from the file \\siz1130\aerse$\Support\Tools\QuaTe\10_Hardware\B_Revision2\10_Firmware\01_Released\AB_Sens_80_10_10_B_10_01_001_Firmware_Overview.xls.

3. The firmwares are present in folder \\siz1130\aerse$\Support\Tools\QuaTe\10_Hardware\B_Revision2\10_Firmware\01_Released.

4. For controlling QuaTe with TurboLIFT, we have a module called "LIFT_QuaTe" AND also a command-line utility called "QUATE_shell" in TurboLIFT Tools.

=head1 SYNOPSIS

    use LIFT_QuaTe;

    QuaTe_Init();
    
    QuaTe_LoadHWConfiguration( );
    QuaTe_GetQuaTeStatus();
    $Parameter_aref = QuaTe_GetParameter('SMA560', "ERROR", ['AccX']);
    QuaTe_SetChipSelect('SMA560',ENABLE);
    QuaTe_SetParameter('SMA560',"ERROR", ['0xff','0b10'],['AccX']);
    QuaTe_SetParameter('SMA560', "ERROR", $Parameter_aref,['AccX']);
    $data = QuaTe_GetStaticData('SMA560', 0 [,'AccY'] );
    $data = QuaTe_GetStaticData('SMA560', 0 );
    $samples = QuaTe_ReadSPIMonitorLevel( 'SPImonitor');
    $data_HoH = QuaTe_ReadSPIMonitorPlusData('SPImonitor', 100);
    QuaTe_SetStaticData( 'SMB460',10, 0 ,'AccX' );
    QuaTe_SetSPIMonitorMode('SPImonitor',ENABLE,0,0,['SMB460']);
    QuaTe_SetStaticFSMode_Internal('SMB460', 0, 0, 0, 0, 0,['AccX']);
    QuaTe_SetControllerTriggerMode( 'Quate0', 1, 0);
    QuaTe_SendControllerTrigger( 'Quate0', 1, 0);   

    QuaTe_Exit();

=head2 ProjectDefaults

 $Defaults->{'QUATE'} = {
       
    # Master QuaTe
    'QUATE0' => {
        'FIRMWARE' => 'rev2_step35_v9.bit',
              
        'DEVICES'   => {
            '0'  => {
                'DEVICE_NAME' => 'SMA660',
                'ROM_FILE' => 'sma660.cfg',                        
                'CHIP_SELECT' => '0',
                'CHANNELS' => {
                    '0' => {
                        'CHANNEL_NAME' => 'SMA660M_CH1', 
                        'SID' => '0x00',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'SMA660M_CH2', 
                        'SID' => '0x01',
                    },
                },
            },
            '1'  => {
                'DEVICE_NAME' => 'SMI700',
                'ROM_FILE' => 'SMI700_YAW_v4.cfg',
                'CHIP_SELECT' => '1',
                'TYPE' => 'SMI7',
                'CHANNELS' => {
                    '0' => {
                        'CHANNEL_NAME' => 'RATE_LF', 
                        'SID' => '0x16',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'ACC1_LF', 
                        'SID' => '0x17',
                    },
                    '2' => {
                        'CHANNEL_NAME' => 'ACC2_LF', 
                        'SID' => '0x23',
                    },                    
                    '3' => {
                        'CHANNEL_NAME' => 'TEMP1', 
                    },                    
                    '4' => {
                        'CHANNEL_NAME' => 'RATE_HF', 
                        'SID' => '0x17',
                    },
                    '5' => {
                        'CHANNEL_NAME' => 'ACC1_HF', 
                        'SID' => '0x15',
                    },
                    '6' => {
                        'CHANNEL_NAME' => 'ACC2_HF', 
                        'SID' => '0x18',
                    },                    
                    '7' => {
                        'CHANNEL_NAME' => 'TEMP2', 
                    },                    
                },
            },    
            '2'  => {
                'DEVICE_NAME' => 'SMI710',
                'ROM_FILE' => 'SMI710_ROSE_v4.cfg',
                'CHIP_SELECT' => '1',
                'TYPE' => 'SMI7',
                'CHANNELS' => {
                    '0' => {
                        'CHANNEL_NAME' => 'RATE_LF', 
                        'SID' => '0x04',
                    },
                    '1' => {
                        'CHANNEL_NAME' => 'ACC1_LF', 
                        'SID' => '0x13',
                    },
                    '2' => {
                        'CHANNEL_NAME' => 'ACC2_LF', 
                        'SID' => '0x14',
                    },                    
                    '3' => {
                        'CHANNEL_NAME' => 'TEMP1', 
                    },                    
                    '4' => {
                        'CHANNEL_NAME' => 'RATE_HF', 
                        'SID' => '0x1F',
                    },
                    '5' => {
                        'CHANNEL_NAME' => 'ACC1_HF', 
                        'SID' => '0x1F',
                    },
                    '6' => {
                        'CHANNEL_NAME' => 'ACC2_HF', 
                        'SID' => '0x1F',
                    },                    
                    '7' => {
                        'CHANNEL_NAME' => 'TEMP2', 
                    },                    
                },
            },    
            '3'  => {
                'DEVICE_NAME' => 'SPImonitor',
            }, 
        },
        
        'TRIGGER' => {
            # Master QuaTe's intern trigger will be activated by SW command
            # Master QuaTe will simultanously generate a negative pulse on Trigger LINE_2
            # (possible values are OFF, POS_SLOPE, NEG_SLOPE,EXT_TRIGGER)
            'LINE_1' => 'OFF',
            'LINE_2' => 'NEG_SLOPE',
        },

    },
    
    # Slave QuaTe
    'QUATE1' => {

        # 'FIRMWARE' and 'DEVICES' follow here
        ...

        'TRIGGER' => {
            # Slave QuaTe(s) expect(s) external trigger on LINE_2
            # (possible values are OFF, POS_SLOPE, NEG_SLOPE,EXT_TRIGGER)
            'LINE_1' => 'OFF',
            'LINE_2' => 'EXT_TRIGGER',
        },  
    },          

    'QUATE_LOGGING' => {
        'ENABLE' => 'yes' | 'no',
    },

},

 'QUATE_CHANNELS' => {
                        'AccX'=> '0',
                        'AccY'=>'1',
                        'Yaw'=>'0',
                        'HighGX' =>'2',
                        'HighGY' => '1',
                        },

 'AB+_SENSOR' => {
                        '100' => 'LIN',
                        '101' => 'LAT',
                       },

 'AB+_COMMAND' => {
                       '00000' => 'DATA_CAPTURE',
                       '00001' => 'TRG_POS_TEST',
                       '00010' => 'TRG_NEG_TEST',
                      }, 

 'SMB460_COMMAND' => {
                       '0000000' => 'RD_DEVICE_ID',
                       '0000011' => 'RD_REVISION_ID',
                       '0010001' => 'RD_MONITOR_I_DATA',
                      },
                      

=head2 Testbench

    'Devices'  => {
           'QuaTe' =>  {
              'Controllers' => 3,  # number of controllers connected
          },
    }

=head1 DESCRIPTION

control functions for multiple QuaTes

controller number and device number must be mapped in project defaults, Channel number is optional

B<NOTE: The sensors that are emulated using QuaTe should not be physically present on the ECU !>

=cut

=head2 QuaTe_GetChipSelectByDeviceName


I<B<Syntax : >>

    ($chipSelect, $isEnabled) = QuaTe_GetChipSelectByDeviceName($deviceName);

I<B<Arguments    : >>

    $deviceName         =   The device name as configured in ProjectDefaults

I<B<Description :>>

Returns the chip select number and enabled state of requested device name (requires QuaTe is initialized)

I<B<Return values :>>

    $chipSelectNumber   = the used chip select line for the device
    $isEnabled          = 0: chip select is disabled
                        = 1: chip select is enabled
                        For non-SPI devices, return value will be (undef, undef)

I<B<Examples :>>

   ($chipSelect, $isEnabled) = QuaTe_GetChipSelectByDeviceName( 'ECU_Acc_HG' );

   (In case of error, QuaTe-DLL-Error message will be logged)


=cut

sub QuaTe_GetChipSelectByDeviceName
{
    my $deviceName = shift;
    my ( $myStatus, $cs, $isEnabled );

    S_w2log( 5, " QuaTe_GetChipSelectByDeviceName : START\n" );

    return (0, 0) if $main::opt_offline;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    my ( $ctrlIndex, $devIndex ) = QuaTe_GetIndexFromDevice( $deviceName );

    my $iDevType = qt_GetDeviceType($ctrlIndex, $devIndex);

    # If deviceName is a SPI device
    if ( $iDevType == DEVICE_TYPE_SPI || $iDevType == DEVICE_TYPE_MM5  || $iDevType == DEVICE_TYPE_ABPLUS_DEVICE || $iDevType == DEVICE_TYPE_SPI_MONITOR || $iDevType == DEVICE_TYPE_PSI_AND_SPI )
    {
        ( $myStatus, $cs, $isEnabled ) = qt_GetChipSelect( $ctrlIndex, $devIndex );
        check_status($myStatus);
    }
    # If deviceName is not a SPI device
    else
    {
        $cs = undef;
        $isEnabled = undef;
    }

    S_w2log( 5, " QuaTe_GetChipSelectByDeviceName : END\n" );

    return ( $cs, $isEnabled );
}

=head2 QuaTe_GetDeviceDescription


I<B<Syntax : >>

    ($deviceDescription, $deviceVersion) = QuaTe_GetDeviceDescription($deviceName, $channelName);

I<B<Arguments    : >>

    $deviceName         =   The device name as configured in ProjectDefaults
    $channelName        =   The channel name as configured in ProjectDefaults

I<B<Description :>>

Returns QuaTe device description and version (of requested device and channel)

I<B<Return values :>>

    $deviceDescription, $deviceVersion

I<B<Examples :>>

   ($deviceDescription, $deviceVersion) = QuaTe_GetDeviceDescription( 'ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC' );


=cut

sub QuaTe_GetDeviceDescription
{
    my $deviceName = shift;
    my $channelName = shift;
    my ($deviceDescription, $deviceVersion);

    S_w2log( 5, " QuaTe_GetDeviceDescription : START\n" );

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return (undef, undef);
    }

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    # check whether the indexes are found correctly
    if ( defined $ctrlIndex )
    {
        ($status, $deviceDescription) = qt_GetDeviceDescription( $ctrlIndex, $deviceIndex );
        #
        # TODO : status check
        #
        $deviceVersion = qt_GetDeviceVersion( $ctrlIndex, $deviceIndex );
    }
    else
    {
        $deviceDescription = undef;
        $deviceVersion = undef;
    }

    S_w2log( 5, " QuaTe_GetDeviceDescription : END\n" );

    return ($deviceDescription, $deviceVersion);
}

=head2 QuaTe_GetDeviceDescriptionInternal


I<B<Syntax : >>

    $deviceDescriptionInternal = QuaTe_GetDeviceDescriptionInternal($deviceName, $channelName);

I<B<Arguments    : >>

    $deviceName         =   The device name as configured in ProjectDefaults
    $channelName        =   The channel name as configured in ProjectDefaults

I<B<Description :>>

Returns internal QuaTe device description (of requested device and channel)

I<B<Return values :>>

    $deviceDescriptionInternal

I<B<Examples :>>

   $deviceDescriptionInternal = QuaTe_GetDeviceDescriptionInternal( 'ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC' );


=cut

sub QuaTe_GetDeviceDescriptionInternal
{
    my $deviceName = shift;
    my $channelName = shift;
    my $deviceDescriptionInternal;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    # check whether the indexes are found correctly
    if ( defined $ctrlIndex )
    {
        # STEP deviceDescriptionInternal = qt_GetDeviceDescriptionInternal (ctrlIndex, deviceIndex)
        ( $status, $deviceDescriptionInternal ) = qt_GetDeviceDescriptionInternal( $ctrlIndex, $deviceIndex );
        check_status($status);
        S_w2log( 4, " QuaTe_GetDeviceDescriptionInternal ( $ctrlIndex , $deviceIndex ) : $status \n" );
        if ( $status < 0 )
        {
            return 0;
        }
    }
    else
    {
        S_set_error( "! Device $deviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 114 );
        return 0;
    }

    # STEP return deviceDescriptionInternal
    return $deviceDescriptionInternal;
}

=head2 QuaTe_GetDeviceProperties

I<B<Syntax : >>

    $DeviceProperties_href = QuaTe_GetDeviceProperties($deviceName, $channelName);

I<B<Arguments    : >>

    $deviceName         =   The device name as configured in ProjectDefaults
    $channelName        =   The channel name as configured in ProjectDefaults

I<B<Description :>>

Returns a hash reference pointing to QuaTe Device properties (of requested device and channel)

    'DEV_TYPE_INTERN' => 0: EDIF, 1: PSI5DEVICE_1CH, 2: PSI5DEVICE_2CH (integer)
    'INPUT_BIT_WIDTH' => bitwidth value (integer)

Return a Hash (hash keys are the parameters)

I<B<Return values :>>

    None

I<B<Examples :>>

   $DeviceProperties_href = QuaTe_GetDeviceProperties( 'ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC' );
   
   $DeviceProperties_href = {
    'DEV_TYPE_INTERN' => 0,
    'INPUT_BIT_WIDTH' => 12;    
   }

=cut

sub QuaTe_GetDeviceProperties
{
    my $deviceName = shift;
    my $channelName = shift;
    my %deviceProperties;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    # check whether the indexes are found correctly
    if ( defined $ctrlIndex )
    {
        if ( $main::opt_offline )
        {
            $deviceProperties{$SENSOR_PROPERTY_DEV_TYPE_INTERN} = 3; # Offline => no QuaTe HW
            $deviceProperties{$SENSOR_PROPERTY_INPUT_BIT_WIDTH} = 999; # Only dummy value, ignored if device is not a PSI5DEVICE
        }
        else
        {
        	$deviceProperties{$SENSOR_PROPERTY_DEV_TYPE_INTERN} = QuaTe_GetInternalDeviceType($deviceName, $channelName);
    	    my ($rangeMin, $rangeMax, $zeroValue, $inputWidth, $outputWidth, $outputResolution);
    	    ($status, $rangeMin, $rangeMax, $zeroValue, $inputWidth, $outputWidth, $outputResolution) = qt_GetDataFormat($ctrlIndex, $deviceIndex, $channelIndex);
    	    $deviceProperties{$SENSOR_PROPERTY_INPUT_BIT_WIDTH} = $inputWidth;
        }
    }
    else
    {
    	S_set_error( "! Device $deviceName with channel(s) $channelName is not found in ProjectDefaults configuration ", 20 );
        $deviceProperties{$SENSOR_PROPERTY_DEV_TYPE_INTERN} = NEGATIVE_STATUS;    # invalidate
        $deviceProperties{$SENSOR_PROPERTY_INPUT_BIT_WIDTH} = NEGATIVE_STATUS;    # invalidate
    }

    return \%deviceProperties;
}


=head2 QuaTe_DownloadData

I<B<Syntax : >>

    QuaTe_DownloadData($deviceName, $channelName, $data_aref, $samplingTime_us[, $opt_para_href]);

I<B<Arguments    : >>

    $deviceName         =   The Device name as configured in ProjectDefaults
    $channelName        =   The channel name as configured in ProjectDefaults
    $data_aref          =   Array of data to be downloaded to Quate channel
    $samplingTime_us    > 0.0: Sampling time in microseconds and signal $data_aref is valid
                        = 0.0: Only empties the FIFO signal data of the chosen device channel (sensor channel)
                               and signal $data_aref is considered invalid (ignored, e.g. "ZERO-Emulation")

    # OPTIONAL: Hash containing further optional parameters for
    $opt_para_href = {
                        # OPTIONAL: file path for signal graphics
                        #           no terminating slash and folder has to exist before
                        'pathForSignalGraphic' => $pathForSignalGraphic,
                        
                        # OPTIONAL: Append this TC number to graphic file name
                        'tcNumber'             => $tcNumber,

                        # OPTIONAL: dynamic failure emulation during signal output,
                        # which is based on "SetDynamicFSMode" of QuaTe-DLL-API.
      # More sensor specific details in
      # path: \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\QuaTe\30_DLL\E_Documentation
      # file: Latest *DLL_Interface_Description*
      # func: SetDynamicFSMode

                        'errorType'        =>  $errorType,  # sensor-specific error type (string)
                                                            # Allowed strings for:
                                                            # internal sensor (up to AB10)
                                                            #     "SID" (for selected ch)
                                                            #     "NRO", "TST", "TFF" (only ch 0)
                                                            # peripheral sensor (PSI, PSI5DEVICE)
                                                            #     "Manchester", "BufferEmpty", "Parity"
                                                            # ABplus_MM3 and _MM5
                                                            #     "GS" (only ch 1)
                                                            # internal sensor AB12 (SMA66xx,SMI720)
                                                            #     "SID" (only ch 0, 1)
                                                            #     "SPI_S", "SPI_SI_CRC" (only ch 0)
                                                            #     "SPI_GS", "SPI_SO_CRC" (only ch 1)

                                                            # Valid ranges for start time and duration:
                                                            #     t1...3_us >= 0
                                                            #     d1...3_us > 0, use d1...3_us = 0 to disable
                        't1_us'            =>  $t1_us,      # 1st start time of error after trigger
                        'd1_us'            =>  $d1_us,      # 1st duration of error
                        't2_us'            =>  $t2_us,      # 2nd start time of error after trigger
                        'd2_us'            =>  $d2_us,      # 2nd duration of error
                        't3_us'            =>  $t3_us,      # 3rd start time of error after trigger
                        'd3_us'            =>  $d3_us,      # 3rd duration of error
    }
 

I<B<Description :>>

Downloads the given array of data into Quate and sets the given sampoling rate.
Internally resets the Quate channel FIFO, resamples the given data based on given sampling rate for Quate, if needed.

I<B<Return values :>>

    <=0  on Error
    > 0  on Success

I<B<Examples :>>

   # Set 1 to 100 with 12.5 us sampling rate
   QuaTe_DownloadData( 'ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC', [1..100], 12.5);
   
   # Emulates manchester failures once 5 ms after crash begin (t0) for a duration of 50 ms
   # (2nd, 3rd error occurrance not used in this case)
   QuaTe_DownloadData( 'PASFL', 'PAS: Acc_HG: Y: PAS6e', [1..100], 12.5, 
                                       {
                                        'errorType'     => "Manchester", 
                                        't1_us'         => 5000,
                                        'd1_us'         => 50000,
                                        't2_us'         => 0,
                                        'd2_us'         => 0,
                                        't3_us'         => 0,
                                        'd3_us'         => 0,
                                        }
                                       );

=cut

sub QuaTe_DownloadData
{
    #COMMENT-START
    #   Mandatory arguments: DeviceName, ChannelName, data_aref (signal array), SamplingTime_us
    #   Optional arguments: opt_dyn_err_href (optional parameter for SetDynamicFSMode)
    #COMMENT-END
    my $deviceName = shift;
    my $channelName = shift;
    my $data_aref = shift;
    my $samplingTime_us = shift;
    my $opt_para_href = shift; # optional paramerers

    S_w2log( 4, "\n QuaTe_DownloadData : START\n" );

    my ($ctrlIndex, $deviceIndex, $channelIndex, $deviceType, $internalDeviceType, $fifoSize);
    my ( $outSize, $outTime_us, $outData_ref );
    S_w2log( 2, " QuaTe_downloadCrashData: Device => $deviceName Channel => $channelName \n");
#    S_w2log( 5, "Injecting crash signal into the QuaTe\n");

    # check if the last parameter $SamplingTime_us is defined for 'too less parameters'
    unless (defined $samplingTime_us)
    {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_downloadCrashData(\$DeviceName, \$ChannelName, \$data_aref, \$SamplingTime_us) ", 110 );
        return 0;
    }

    my $inSize;

    # validate if the given data signal parameter is of type ARRAY
    if( $samplingTime_us > 0 )
    {
        unless ( defined( $data_aref ) )
        {
            S_set_error( " data_aref is undefined", 114 );
            return 0;
        }
        if ( ref($data_aref) ne "ARRAY" )
        {
            S_set_error( " data_aref is not an array reference", 114 );
            return 0;
        }
        $inSize = scalar(@$data_aref);
    }
    else
    {
        $inSize = 0;
    }

    # validate if given data signal array contains at least one signal value
    if ( $samplingTime_us > 0 && $inSize < 1 )
    {
        S_set_error( " data_aref is empty", 114 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    # STEP get ctrlIndex, deviceIndex, channelIndex from the given Device name and channel name
    ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    # check whether the indexes are found correctly
    unless ( defined $ctrlIndex )
    {
        S_set_error( "! Device $deviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 114 );
        return 0;
    }

    return 1 if ($main::opt_offline);

    # STEP ResetFIFO of the sensor channel
    $status = qt_ResetFIFO($ctrlIndex, $deviceIndex, $channelIndex);
    check_status($status);
    S_w2log( 4, " QuaTe_DownloadData : ResetFIFO ($ctrlIndex, $deviceIndex, $channelIndex) => Status $status \n");

    # IF samplingTime_us <= 0
    if ( $samplingTime_us <= 0 )
    {
        # IF-yes-START
        #COMMENT-START
        #   ZERO-Emulation assumed
        #COMMENT-END
        S_w2log( 3, " QuaTe_DownloadData : samplingTime_us = $samplingTime_us undefined (ZERO-Emulation) => only ResetFIFO done for dev=$deviceName, ch=$channelName\n" );
        return 1;
        # IF-yes-END
    }

    # IF-valid-START

    S_w2log( 4, " QuaTe_DownloadData( $deviceName [QUATE:$ctrlIndex  DEVICE:$deviceIndex], $channelName [CHANNEL:$channelIndex], data [length:$inSize], SamplingRate [$samplingTime_us us])\n");

    my ($rangeMin, $rangeMax, $zeroValue, $inputWidth, $outputWidth, $outputResolution);

    # STEP GetDataFormat (rangeMin, rangeMax, zeroValue, inputWidth, outputWidth, outputResolution) of sensor channel
    ($status, $rangeMin, $rangeMax, $zeroValue, $inputWidth, $outputWidth, $outputResolution) = qt_GetDataFormat($ctrlIndex, $deviceIndex, $channelIndex);
    check_status($status);
    S_w2log( 4, " QuaTe_DownloadData: qt_GetDataFormat (rangeMin=$rangeMin, rangeMax=$rangeMax, zeroValue=$zeroValue, inputWidth=$inputWidth, outputWidth=$outputWidth, outputResolution=$outputResolution) => Status : $status \n" );

    # CALL QuaTe_GetInternalDeviceType
    $internalDeviceType = QuaTe_GetInternalDeviceType($deviceName, $channelName);

	# STEP convert crash data from float to short (16 Bit)
    S_w2log( 4, " --> clipping for  SHORT MAX = " . $NUM_INT16_MAX . ", SHORT MIN = " . $NUM_INT16_MIN . " \n" );
	QuaTe_round2Short($data_aref, $inSize);

    # IF NON-PSI5DEVICE?
    if ( $internalDeviceType == 0 )
    {
        # IF-yes-START    
        S_w2log( 4, " Time to resample is $samplingTime_us us  \n");
        # STEP GetResampleFIFOSize: inSize, inCycle_us => outSize, outCycle_us
        ( $status, $outSize, $outTime_us ) = qt_GetResampleFIFOSize( $inSize, $samplingTime_us );
        check_status($status);
        S_w2log( 4, " Resampling the FIFO size to SamplingTime => Determined size: $outSize, Determined sampling time: $outTime_us us\n" );

        # STEP ResampleFIFOData to returned outCycle_us with an integral resolution of 1us
        $outData_ref = QuaTe_resample( $data_aref, $inSize, $samplingTime_us, $outSize, $outTime_us, 1 );    #1 = interpolation mode
        # STEP SetTimeBase of channel to outCycle_us 
        QuaTe_setClockData( $ctrlIndex, $deviceIndex, $channelIndex, $outTime_us );
        # IF-yes-END
    }

    # PSI5DEVICE
    else
    {
        # IF-PSI5DEVICE-START

        # IF samplingTime_us unequal 113.777777
        if ( abs($samplingTime_us - $NOM_PSI5DEVCE_SAMPLING_TIME_US ) > $NUM_EPSILON_1E_MINUS_6 )
        {
            # IF-yes-START    
            $outTime_us = $NOM_PSI5DEVCE_SAMPLING_TIME_US; # Set to nominal value of PSI5DEVICE
            S_w2log( 4, "! SamplingTime $samplingTime_us us for PSI5DEVICE ($deviceName, $channelName) is out of range and will be resampled to $outTime_us us\n" );
            # STEP Resample signal to 113.777777us
            my $retVals_href = NUM_ResampleData(
                                        {
                                        'dataIn_aref'        => $data_aref,
                                        'dtIn_sec'           => $samplingTime_us / 1E6,
                                        'dtOut_sec'          => $outTime_us / 1E6,
                                        'dtResolution_sec'   => 1E-12,
                                        }
            );
            $outData_ref = $retVals_href->{'dataOutValues_aref'};
            $status = $retVals_href->{'status'};

            $outSize = scalar(@$outData_ref);
            S_w2log( 4, "Signal resampled to nominal sampling rate of PSI5DEVICE: InSize=$inSize, InTime_us=$samplingTime_us => outSize: $outSize, outTime_us: $outTime_us us\n" );
            # IF-yes-END
        }
        else
        {
            # IF-no-START
            # STEP Move input to output data
            $outSize = $inSize;
            $outTime_us  = $samplingTime_us;
            $outData_ref = $data_aref;
            # IF-no-END
        }

        # STEP SetParameter (...,'SAMPLINGTIME_PS',...) of channel to 113777777 (pico seconds)
        # pico sec range is 113777777 (= 113,777777e-6 sec) => limits of nominal reciprocal value frequency = 8.789...e-9 (x 1e12 = 8.789 kHz)
        # -21% (x 0.79) = 6.943...e-9 -> reciprocal value as int = 144022503 (max) => i.e. fits into an integer of 32 bit
        # +21% (x 1.21) = 1.063...e-8 -> reciprocal value as int =  94031221 (min)
        my $outTime_ps        = $outTime_us * 1E6;    # pico sec range is 113777777 (limits +/-20% of nominal value => interval [94031221,144022503]), i.e. fits into an integer
        my @outTimeAsArray_ps = ($outTime_ps);
        QuaTe_SetParameter( $deviceName, $channelName, 'SAMPLINGTIME_PS', \@outTimeAsArray_ps );
        # IF-PSI5DEVICE-END
    }

    if ( defined $opt_para_href )
    {
        my $errorType = $opt_para_href->{'errorType'};
        # IF option dynamic error during crash is enabled
        if ( defined $errorType )
        {
            # IF-YES-START
            my $t1_us = $opt_para_href->{'t1_us'} // 0;
            my $d1_us = $opt_para_href->{'d1_us'} // 0;
            my $t2_us = $opt_para_href->{'t2_us'} // 0;
            my $d2_us = $opt_para_href->{'d2_us'} // 0;
            my $t3_us = $opt_para_href->{'t3_us'} // 0;
            my $d3_us = $opt_para_href->{'d3_us'} // 0;
            S_w2log( 5, "qt_SetDynamicFSMode: errorType = $errorType, t1_us = $t1_us, d1_us = $d1_us, t2_us = $t2_us, d2_us = $d2_us, t3_us = $t3_us, d3_us = $d3_us\n" );

            # STEP SetDynamicFSMode with given errorType and timing
            $status = qt_SetDynamicFSMode( $ctrlIndex, $deviceIndex, $channelIndex, $errorType, $t1_us, $d1_us, $t2_us, $d2_us, $t3_us, $d3_us );
            check_status($status);
            # IF-YES-END
        }
        else
        {
            # IF-NO-START
            # IF-NO-END
        }
    }

    # STEP ReadFIFOLevel
    $fifoSize = qt_ReadFIFOLevel($ctrlIndex, $deviceIndex, $channelIndex); #returns number of data samples which can be stored
    check_status($fifoSize);

	# STEP Set last signal array point to zero value, if it is not the case already
    if(int($$outData_ref[-1]) != $zeroValue)
    {
        S_w2log( 5, "Last value $$outData_ref[-1]: Sensor zero value $zeroValue is added as last point in the data\n" );
        $$outData_ref[scalar(@$outData_ref)] = $zeroValue;
    }

    my $dataSize = scalar(@$outData_ref);  #size of array referenced by $data_aref
    # IF signal fits into FIFO?
    if( $dataSize <= $fifoSize )
    {
        # IF-yes-START
        # STEP GetDeviceType
        $deviceType = qt_GetDeviceType($ctrlIndex, $deviceIndex);

        # IF deviceType is DAC?
        #DAC (use data format 0)
        if ( $deviceType == DEVICE_TYPE_DAC )
        {
            # IF-DAC-START
            # CALL QuaTe_clipData [-32768, 32767]
            QuaTe_clipData( $outData_ref, $NUM_INT16_MIN, $NUM_INT16_MAX );
            # STEP SetDynamicData for DAC signal (device output format)
            QuaTe_SetDynamicData($deviceName, $channelName, $outData_ref , 'LIKE_OUTPUT');    # LIKE_OUTPUT = 0
            # IF-DAC-END
        }
        #sensor (use data format 1)
        else
        {
            # IF-PSI_or_SPI-START
            # CALL QuaTe_clipData [rangeMin, rangeMax]
            QuaTe_clipData($outData_ref, $rangeMin, $rangeMax);
            # STEP SetDynamicData for sensor signal (device input format = compatible to FilterDLL)
            QuaTe_SetDynamicData($deviceName, $channelName, $outData_ref , 'LIKE_INPUT');     # LIKE_INPUT = 1

#            if ( not defined $opt_para_href)
#            {
#                $opt_para_href = {
#                    'pathForSignalGraphic' => "$main::REPORT_PATH/_snapshot_" # or "C:\\temp", no terminating slash and folder has to exist before
#                }
#            }

            if ( defined $opt_para_href )
            {
                my $pathForSignalGraphic = $opt_para_href->{'pathForSignalGraphic'};
                # IF $pathForSignalGraphic given
                if ( defined $pathForSignalGraphic )
                {
                    # IF-YES-START
                    my $curveName = $deviceName."_".$channelName;
                    $curveName =~ s/[: -]/_/g; # replace all colons, spaces and hyphens by underlines
                    my $tcNumber = $opt_para_href->{'tcNumber'};
                    if ( defined $tcNumber ) { $curveName .= "_$tcNumber"; }
                    my $title = "QuaTe_SetDynamicData: ".$curveName;
                    # STEP CreateDeviceChannelSignalGraph
                    QuaTe_createGraph("$pathForSignalGraphic/$curveName", $title, $outData_ref, $outTime_us / 1E6);
                    # IF-YES-END
                }
                else
                {
                    # IF-NO-START
                    # IF-NO-END
                }
            }

            # IF-PSI_or_SPI-END
        }
        # IF-yes-END
    }
    else
    {
        # IF-no-START
        # STEP Error Message "FIFO size exceeded"
        S_set_error( "The size of the Data ($dataSize) exceeds the FIFO size of channel ($fifoSize)" , 120);
        return 0;
        # IF-no-END
    }

    if ( $deviceType != DEVICE_TYPE_DAC )
    {
        if ( $deviceType == DEVICE_TYPE_PSI )
        {
            $gPsiDevicesSetup4Inject{$deviceName} = 1;
            $gPsiDevicesSetup4Inject{$ctrlIndex} = 1;
        }
        else
        {
            $gSpiDevicesSetup4Inject{$deviceName} = 1;
            $gSpiDevicesSetup4Inject{$ctrlIndex} = 1;
        }
    }

    S_w2log( 4, "\n QuaTe_DownloadData : END\n" );

    # IF-valid-END
    # STEP return
    return 1;
}


=head2 QuaTe_DumpStatus

I<B<Syntax : >>

    QuaTe_DumpStatus();

I<B<Arguments    : >>

    None

I<B<Description :>>

read full status information from Quate and write to report. It will list all controllers and devices

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_DumpStatus();

=cut

sub QuaTe_DumpStatus
{

    S_w2log( 4, "QuaTe_GetDumpStatus \n");

   unless ( $QT_initialized ) {
       S_set_error( "QuaTe not initialized" , 120);
       return 0;
   }

   return if ($main::opt_offline);

   S_w2log( 4, qt_DumpStatus());

    return;
}


=head2 Quate_Exit

I<B<Syntax : >>

    Quate_Exit();

I<B<Arguments    : >>

    None

I<B<Description :>>

unloads QuaTe low level DLL. It should be called in ENDcampaign.

I<B<Return values :>>

    None

I<B<Examples :>>

   Quate_Exit();

=cut

sub QuaTe_Exit
{
    S_w2log( 3, "QuaTe_Exit\n");
    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe not initialized" , 120);
        return 0;
    }

#    S_w2log( 3, "QuaTe Exit\n");
    if ($main::opt_offline)
    {
        $QT_initialized = 0;
        return 1;
    }
    $status = qt_FreeDLL();
    check_status($status);

    #empty the global hashes
    %Device_hash = ();
    %GlobalSettings = ();
    %gPsiDevicesSetup4Inject = ();
    %gSpiDevicesSetup4Inject = ();

    $QT_initialized = 0;
    S_w2log( 3, " QuaTe_Exit : Status $status \n" );

    return;
}


=head2 QuaTe_GetIndexFromDevice

I<B<Syntax : >>

    ($QuateIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);

I<B<Arguments    : >>

    $DeviceName          =   device name as defined in ProjectDefaults

I<B<Description :>>

returns the Quate index and device index of the device name

I<B<Return values :>>

    $QuateIndex    =   Quate index to which the device belongs to
    $DeviceIndex   =   Device index in that Quate

I<B<Examples :>>

   ($QuateIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice('ECU_Acc_HG');
   ($QuateIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice('PASFP');

=cut


sub QuaTe_GetIndexFromDevice
{

    my $DeviceName = shift;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return (undef, undef);
    }

    unless (exists $Device_hash{$DeviceName}) {
        S_set_error( "Device $DeviceName not found in ProjectDefaults->{'QUATE'}" , 20);
        return (undef, undef);
    }

    return ($Device_hash{$DeviceName}{'CTRL_INDEX'}, $Device_hash{$DeviceName}{'DEV_INDEX'});
}


=head2 QuaTe_GetIndexFromDeviceChannel

I<B<Syntax : >>

    ($QuateIndex, $DeviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

I<B<Arguments    : >>

    $DeviceName          =   device name as defined in ProjectDefaults
    $ChannelName         =   Name of the channel within the device

I<B<Description :>>

returns the Quate index, device index and channel index from the channel of device

I<B<Return values :>>

    $QuateIndex    =   Quate index to which the device belongs to
    $DeviceIndex   =   Device index in that Quate
    $channelIndex  =   Index of the given channel within the device

I<B<Examples :>>

   ($QuateIndex, $DeviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel('ECU_Acc_HG', 'AccX');
   ($QuateIndex, $DeviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel('PASFP', '-X');

=cut


sub QuaTe_GetIndexFromDeviceChannel
{

    my $DeviceName = shift;
    my $ChannelName = shift;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return (undef, undef, undef);
    }

    unless (exists $Device_hash{$DeviceName}) {
        S_set_error( "Device $DeviceName not found in ProjectDefaults->{'QUATE'}" , 20);
        return (undef, undef, undef);
    }

    my $channelIndex;

    #check whether the channel is existing in particular device
    foreach my $Channel (keys %{$Device_hash{$DeviceName}{'CHANNELS'}})
    {
        if($Device_hash{$DeviceName}{'CHANNELS'}{$Channel}{'CHANNEL_NAME'} eq $ChannelName)
        {
            $channelIndex = $Channel;
        }
    }

    unless(defined $channelIndex)
    {
        S_set_error( "Channel name $ChannelName not found for $DeviceName in ProjectDefaults->{'QUATE'} configuration" , 20);
        return (undef, undef, undef);
    }

    return ($Device_hash{$DeviceName}{'CTRL_INDEX'}, $Device_hash{$DeviceName}{'DEV_INDEX'}, $channelIndex);
}

=head2 QuaTe_GetParameter

I<B<Syntax : >>

    QuaTe_GetParameter($DeviceName, $ChannelName, $ParamName);

I<B<Arguments    : >>

    $DeviceName     =   The Device name as configured in ProjectDefaults
    $ChannelName    =   The channel name as configured in ProjectDefaults
    $ParamName      =   Param name to which the value to be retrieved

I<B<Description :>>

Read the Quate parameter for particular channel of a Sensor (i.e., Device)

I<B<Return values :>>

    array of param values , on success
    [], on failure

I<B<Examples :>>

   ([0x05, 0x1A]) = QuaTe_GetParameter('ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC', 'FSR_MONITOR');    # get FSR_MONITOR param values

=cut

sub QuaTe_GetParameter
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $ParamName = shift;

    my ($param_num,$param_aref);
    my ($CtrlIndex, $DeviceIndex, $ChannelIndex);

    
    unless (defined( $ParamName ))
    {
        S_set_error( "! too less parameters ! QuaTe_GetParameter(\$DeviceName, \$ChannelName, \$ParamName);", 110 );
        return [];
    }

    unless (exists $ValidParameterNames{$ParamName})
    {
        S_set_error("Parameter_name $ParamName is invalid", 114 );
        return [];
    }
 
    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return [];
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);
            
    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return [];
    }

    S_w2log( 4, " QuaTe_GetParameter : ($DeviceName [QUATE: $CtrlIndex DEVICE: $DeviceIndex],  $ChannelName [CHANNEL: $ChannelIndex], $ParamName) \n");

    return [0] if $main::opt_offline;

    ($status,$param_num,$param_aref) = qt_GetParameter($CtrlIndex, $DeviceIndex,$ChannelIndex,$ParamName);
    check_status($status);
    S_w2log( 4, " QuaTe_GetParameter : Status $status \n" );
    S_w2log( 4, " got $param_num parameter(s) of device $DeviceIndex ($DeviceName) on controller $CtrlIndex for parameter '$ParamName' : -@{$param_aref}-\n");

    return ($param_aref);
}

=head2 QuaTe_GetPSIPortByDeviceName


I<B<Syntax : >>

    $port = QuaTe_GetPSIPortByDeviceName($deviceName);

I<B<Arguments    : >>

    $deviceName         =   The device name as configured in ProjectDefaults

I<B<Description :>>

Returns the PSI port number of requested device name (requires QuaTe is initialized)

I<B<Return values :>>

    $port = Return value is the used output port (1..16)
            For non-PSI devices, return value will be undef
            Negative value: Execution error (QuaTe-DLL-Error message will be logged)

I<B<Examples :>>

   $port = QuaTe_GetPSIPortByDeviceName( 'PAS6FP' );

=cut

sub QuaTe_GetPSIPortByDeviceName
{
    my $deviceName = shift;
    my $port;

    S_w2log( 4, " QuaTe_GetPSIPortByDeviceName : START\n" );

    return 0 if $main::opt_offline;

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    my ( $ctrlIndex, $devIndex ) = QuaTe_GetIndexFromDevice( $deviceName );

    my $iDevType = qt_GetDeviceType($ctrlIndex, $devIndex);

    # If deviceName is a PSI device
    if ( $iDevType == DEVICE_TYPE_PSI || $iDevType == DEVICE_TYPE_PSI_MONITOR || $iDevType == DEVICE_TYPE_PSI_AND_SPI )
    {
        $port = qt_GetPSIPort( $ctrlIndex, $devIndex );
        if ( $port < 0 )
        {
            check_status($port);
        }
    }
    # deviceName is not a PSI device
    else
    {
        $port = undef;
    }

    S_w2log( 4, " QuaTe_GetPSIPortByDeviceName : END\n" );

    return $port;
}

=head2 QuaTe_GetStaticData

I<B<Syntax : >>

    QuaTe_GetStaticData($DeviceName, $ChannelName, $DataFormat);

I<B<Arguments    : >>

    $DeviceName     =   The Device name as configured in ProjectDefaults
    $ChannelName    =   The channel name as configured in ProjectDefaults
    $DataFormat     =   Data format of the signal ('LIKE_INPUT' (or) 'LIKE_OUTPUT') 

I<B<Description :>>

returns the current value of particular channel of a Sensor (i.e., Device)

I<B<Return values :>>

    data signal value

I<B<Examples :>>

   512 = QuaTe_GetStaticData('ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC', 'LIKE_INPUT');

=cut

sub QuaTe_GetStaticData
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $DataFormat = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex, $DataFormatNumber, $data); 

    unless (defined( $DataFormat ))
    {
        S_set_error( '! too less parameters ! QuaTe_GetStaticData($DeviceName, $ChannelName, $DataFormat); ', 110 );
        return 0;
    }

    unless($DataFormat =~ /^LIKE_INPUT$/i || $DataFormat =~ /^LIKE_OUTPUT$/i) {
        S_set_error( "! Invalid data format : $DataFormat . Should be 'LIKE_INPUT' or 'LIKE_OUTPUT' ", 114 );
        return 0;
    }

    #assign numeric for data format (according to Quate low level Driver, OUTPUT = 0, INPUT = 1)
    $DataFormatNumber = 0 if($DataFormat =~ /^LIKE_OUTPUT$/i);
    $DataFormatNumber = 1 if($DataFormat =~ /^LIKE_INPUT$/i);

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return;
    }   
    
    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return;
    }

    S_w2log( 4, "QuaTe_GetStaticData ($DeviceName [QUATE: $CtrlIndex  DEVICE: $DeviceIndex], $ChannelName [CHANNEL: $ChannelIndex], '$DataFormat') ");

    return 0 if $main::opt_offline;

    ($status, $data) = qt_GetStaticData( $CtrlIndex, $DeviceIndex, $ChannelIndex, $DataFormatNumber );
    check_status($status);
    S_w2log( 4, "Status of QuaTe_GetStaticData : $status, Data = $data \n" );
    return($data);

}


=head2 QuaTe_GetStaticFSMode

I<B<Syntax : >>

    %FailureMaskHash = QuaTe_GetStaticFSMode($DeviceName, $ChannelName [, $FailureTypes_aref]);

I<B<Arguments    : >>

    $DeviceName         =   The Device name as configured in ProjectDefaults
    $ChannelName        =   The channel name as configured in ProjectDefaults
    $FailureTypes_aref  =   (optional) Array reference of Failure type names for which the masks to be retrieved 

I<B<Description :>>

Returns the current status of the failure simulation of an ABplus sensor

I<B<Return values :>>

    %FailureMaskHash     =  A hash containing the 'Failure types' as keys and 'Failure masks' as values

=over 2

=item * empty hash, on error

=item * On success,

if $FailureType_aref is defined, $FailureMaskHash{$FailureTypes_aref elements} = Failure Mask values

if $FailureType is not defined, StaticFSMode is retrieved B<based on Sensor type>.

Internal sensors    =>  keys: B<SID, NRO, TST, TFF, ExtReg> 

ABplus sensors      =>  keys: B<GSerror>

Peripheral sensors  =>  keys: B<Manchester, Parity, BufferEmpty> 

=back

I<B<Examples :>>

   %FailureMaskHash = QuaTe_GetStaticFSMode('SMG074', 'AccX');  # 'SMG074' is ABPlus sensor. So, %FailureMaskHash will contain value for 'GSerror' 

=cut

sub QuaTe_GetStaticFSMode
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $FailureTypes_aref = shift;
    
    my ($CtrlIndex, $DeviceIndex, $ChannelIndex, %FailureMaskHash);

    S_w2log( 4, "QuaTe_GetStaticFSMode\n");

    unless (defined $ChannelName)
    {
        S_set_error( "! too less parameters !  QuaTe_GetStaticFSMode(\$DeviceName, \$ChannelName, %FailureMaskHash);", 110 );
        return {};
    }

    # check whether $FailureTypes_aref is an array reference
    if(defined $FailureTypes_aref && ref($FailureTypes_aref) ne 'ARRAY') {
        S_set_error( "\$FailureTypes_aref should be an array reference", 114 );
        return {};
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return {};
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return {};
    }

    S_w2log( 4, " QuaTe_GetStaticFSMode: ($DeviceName [QUATE: $CtrlIndex DEVICE: $DeviceIndex],  $ChannelName [CHANNEL: $ChannelIndex], '$FailureTypes_aref') \n");

    return 1 if $main::opt_offline;

    if(defined $FailureTypes_aref)
    {
        my $FailureMaskValue;
        foreach my $FailureType(@$FailureTypes_aref)
        {
            ($status, $FailureMaskValue) = qt_GetStaticFSMode($CtrlIndex, $DeviceIndex, $ChannelIndex, $FailureType);
            check_status($status);
            S_w2log( 4, " QuaTe_GetStaticFSMode ($FailureType) : Status $status,  $FailureType = $FailureMaskValue\n" );

            if($status >= 0) { $FailureMaskHash{$FailureType} = $FailureMaskValue; }
        }
    }
    else
    {
        #get the StaticFSMode status based on device types
        my $DeviceType = qt_GetDeviceType( $CtrlIndex, $DeviceIndex );
        check_status($DeviceType);

        if(exists $DeviceTypes{$DeviceType})
        {
            my ($DeviceDescription, $DeviceVersion);

            S_w2log( 3, " QuaTe_GetStaticFSMode: Device type of Quate $CtrlIndex -> Device $DeviceIndex : $DeviceTypes{$DeviceType} ($DeviceType) \n" );

            ($status, $DeviceDescription) = qt_GetDeviceDescription( $CtrlIndex, $DeviceIndex );
            check_status($status);
            $DeviceVersion = qt_GetDeviceVersion( $CtrlIndex, $DeviceIndex );
            $DeviceVersion = 'not defined' unless(defined $DeviceVersion);

            S_w2log( 3, " QuaTe_GetStaticFSMode: Device is : $DeviceDescription , Version : $DeviceVersion\n" );

            # DEVICE_TYPE_SPI, DEVICE_TYPE_PSI_AND_SPI, DEVICE_TYPE_MM5 = qt_GetStaticFSMode_Internal
            # DEVICE_TYPE_ABPLUS_DEVICE                                 = qt_GetStaticFSMode_ABplus
            # DEVICE_TYPE_PSI                                           = qt_GetStaticFSMode_Peripheral

            if($DeviceType == DEVICE_TYPE_SPI || $DeviceType == DEVICE_TYPE_PSI_AND_SPI || $DeviceType == DEVICE_TYPE_MM5)
            {
                my ($SID, $NRO, $TST, $TFF, $ExtReg);
                ($status, $SID, $NRO, $TST, $TFF, $ExtReg) = qt_GetStaticFSMode_Internal( $CtrlIndex, $DeviceIndex, $ChannelIndex);
                check_status($status);
                S_w2log( 3, " QuaTe_GetStaticFSMode: status of qt_GetStaticFSMode_Internal : $status \n" );

                # store the failure masks
                if($status >= 0)
                {
                    S_w2log( 4, "SID = $SID, NRO = $NRO, TST = $TST, TFF = $TFF, ExtReg = $ExtReg \n" );
                    $FailureMaskHash{'SID'} = $SID;
                    $FailureMaskHash{'NRO'} = $NRO;
                    $FailureMaskHash{'TST'} = $TST;
                    $FailureMaskHash{'TFF'} = $TFF;
                    $FailureMaskHash{'ExtReg'} = $ExtReg;
                }
            }
            elsif($DeviceType == DEVICE_TYPE_ABPLUS_DEVICE)
            {
                my $GSerror;
                ($status, $GSerror) = qt_GetStaticFSMode_ABplus( $CtrlIndex, $DeviceIndex, $ChannelIndex);
                check_status($status);
                S_w2log( 4, " QuaTe_GetStaticFSMode: status of qt_GetStaticFSMode_ABplus : $status \n" );

                if($status >= 0)
                {
                    S_w2log( 4, "GSerror = $GSerror\n" );
                    $FailureMaskHash{'GSerror'} = $GSerror;
                }
            }
            elsif($DeviceType == DEVICE_TYPE_PSI)
            {
                my ($Manchester, $Parity, $BufferEmpty);
                ($status, $Manchester, $Parity, $BufferEmpty) = qt_GetStaticFSMode_Peripheral( $CtrlIndex, $DeviceIndex, $ChannelIndex);
                check_status($status);
                S_w2log( 4, "status of qt_GetStaticFSMode_Peripheral : $status \n" );
 
                if($status >= 0)
                {
                    S_w2log( 4, "Manchester = $Manchester, Parity = $Parity, BufferEmpty = $BufferEmpty\n" );
                    $FailureMaskHash{'Manchester'} = $Manchester;
                    $FailureMaskHash{'Parity'} = $Parity;
                    $FailureMaskHash{'BufferEmpty'} = $BufferEmpty;
                }
            }
            else
            {
                S_set_error( "Devices of type $DeviceTypes{$DeviceType} ($DeviceType) does not support updating ROM file " , 114);
                return;
            }

        }
        else
        {
            S_set_error( "Unknown device type $status found on Quate $CtrlIndex => Device $DeviceIndex " , 114);
            return;
        }

    }

    return(%FailureMaskHash);

}


=head2 QuaTe_Init

I<B<Syntax : >>

    QuaTe_Init();

I<B<Arguments    : >>

    None

I<B<Description :>>

Initializes QuaTe low level DLL, checks if at least 1 Quate is connected. It should be called in INITcampaign.  

The QuaTe configuration should be done as shown in L</ProjectDefaults> & L</Testbench>.

Quate_Init() does all the settings given in L</ProjectDefaults> including

=over 3

=item * Firmware update to QuaTes

=item * Device settings (Chip select, ROM file updates)

=item * Channels settings (SID, SPI related)

=back

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_Init();

=cut

sub QuaTe_Init
{
    QuaTe_LoggingSetup();

    S_w2log( 3, "QuaTe_Init\n");

    if ( $QT_initialized ) {
        S_set_warning( "QuaTe already initialized !");
        return 1;
    }

#    S_w2log( 4, "Initialization of QuaTe\n");

    # global hash from Device perspective
    $NumOfCtrls = $LIFT_config::LIFT_Testbench->{'Devices'}{'QuaTe'}{'Controllers'};

    unless (defined $NumOfCtrls )
    {
        S_set_error( "QuaTe configuration not found, Please check testbench configuration" , 5);
        return 0;
    }

    #Max 8 QuaTe units can be connected, if not throw error
    if ($NumOfCtrls > $MaxNumOfCtrls)
    {
        S_set_error( "Only $MaxNumOfCtrls QuaTe units can be connected. Please check testbench configuration" , 5);
        return 0;
    }

    S_w2log( 4, " QuaTe_Init: Number of Controllers in TestBench : $NumOfCtrls\n");

    $status = qt_InitDLL();
    check_status($status);
    S_w2log( 4, " QuaTe_Init: Status of QuaTe DLL Init :: $status \n" );

    my $version;
    ($status,$version) = qt_GetDLLVersion();
    S_w2log(4," QuaTe_Init: DLL version: $version\n");
    ($status,$version) = qt_GetDLLVersionInfo();
    if ( $status < 0 ) {
      my $errortext = qt_GetErrorString($status);
      S_set_error( "LIFT_QuaTe (GetDLLVersionInfo): $errortext" , 5);
    }
    else {
        # Extract relevant infos: Version, FileVersion
        $version =~ /^Version: ([.0-9]+)[\s\S]+FileVersion: ([\w]+)/; # Version: 7.75.4.0 ... FileVersion: 7K4
        my $dllVersion = defined $1?$1:"not found";
        my $fileVersion = defined $2?$2:"not found";
        S_w2log(4,"QuaTe DLL long Version: $dllVersion, FileVersion: $fileVersion\n");
    }

    $version = qt_getPMrevision();
    S_w2log(4,"PM $version\n");
    $version = qt_getXSrevision();
    S_w2log(4,"XS $version\n");
    $version = qt_getCWrevision();
    S_w2log(4,"CW $version\n");

    if ($main::opt_offline)
    {
        QuaTe_configure($main::ProjectDefaults->{'QUATE'}) or return 0;
        S_w2log( 4, "QuaTe_init: Initialized successfully \n" );
        $QT_initialized = 1;
        return 1;
    }


    my $ctrlNum = qt_GetNumberOfControllers();
    if ($ctrlNum<=0)
    {
         my $errortext = qt_GetErrorString($ctrlNum);
         S_set_error( "QuaTe : $errortext", 5 );
         return 0;
    }

    S_w2log( 2, " QuaTe_Init: Total number of QuaTes connected to PC : $ctrlNum \n" );

    # Used Testbench config QuaTes should be <= total quates connected to PC
    if ($NumOfCtrls > $ctrlNum)
    {
         S_set_error( "QuaTes configured in Testbench ($NumOfCtrls) > Real Quates ($ctrlNum) : please connect additional QuaTes / change Testbench configuration ", 5 );
         return 0;
    }

    #store the actual number of Quates used in Global variable
    $NumOfQuates = $NumOfCtrls;

    ####################################START OF QUATE SETTINGS##############################################
    #assume that QuaTe is initalized, which will be changed based on firmware initialization later

    $QT_initialized = 1; # quate has to be intitilaized to get configured
	QuaTe_configure() or return 0;

    QuaTe_DumpStatus();

    S_w2log( 4, "QuaTe_init: Initialized successfully \n" );

return 1;
}



sub QuaTe_configure{

	my $quate_CONFIG = shift;

	$quate_CONFIG = $main::ProjectDefaults->{'QUATE'} unless (defined $quate_CONFIG);

    my ($dev_name, $chipSelect, $type, $romFile);

    #arrays for HTML table creation 
    my @table = ();
    my @table1 = ();

    # empty the device hash already present
    %Device_hash = ();

    #LOOP-START foreach QuaTe's data
    for (my $ctrlNum = 0; $ctrlNum < $NumOfCtrls; $ctrlNum++) # number of Quates/controllers
    {
        my $quate_name = $Quate.$ctrlNum;

        if (exists ( $quate_CONFIG->{$quate_name} ) ) #check whether CtrlNum th Quate exists or not
        {
            #STEP validate firmware defined
            #check if the firmware available, else report error
            my $firmware = $quate_CONFIG->{$quate_name}{'FIRMWARE'};

            # check FIRMWARE file exists
            unless(defined $firmware)
            {
                S_set_error( "! FIRMWARE not defined for $quate_name in ProjectDefaults->{'QUATE'}  ", 20 );
                return 0;
            }

            #save firmware path to GlobalSettings
            $GlobalSettings{$quate_name}{'FIRMWARE'} = $firmware;

            #LOOP-START foreach device's data
            foreach my $device (sort keys %{$quate_CONFIG->{$quate_name}{'DEVICES'}})
            {
                # check whether the device key is a number
                if ($device =~ /\d+/ )
                {
                    $dev_name = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'DEVICE_NAME'};
                    $chipSelect = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'CHIP_SELECT'};
                    $type = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'TYPE'};
                    $romFile = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'ROM_FILE'};

                    #STEP validate device name, chipSelect, type, romFile
                    # DEVICE_NAME is a needed parameter. check and log error , if not found
                    unless (defined $dev_name)
                    {
                        S_set_error( "! $quate_name ->{'DEVICES'}{$device}{'DEVICE_NAME'} not found ", 20 );
                        return 0;
                    }

                    # DEVICE_NAME should be unique.  check and log error , if not unique
                    if(exists $Device_hash{$dev_name})
                    {
                        S_set_error( "! $quate_name ->{'DEVICES'}{$device}{'DEVICE_NAME'} already exists. DEVICE_NAME should be unique  ", 20 );
                        return 0;
                    }

                    #validate CHIP_SELECT , whether it is in correct format
                    if(defined $chipSelect && $chipSelect !~ /\d+/)
                    {
                        S_set_error( "! QUATE: $chipSelect is not a valid chip select. CHIP_SELECT shall only be integer. Ex: $quate_name ->{DEVICES}{$device}{'CHIP_SELECT'} = 0,1,2,.. ", 20 );
                        return 0;
                    }

                    # if CHIP_SELECT does not exists, say it as 'NOT_GIVEN'
                    unless(defined $chipSelect)
                    {
                        $chipSelect = 'NOT_GIVEN';
                    }

                    # if TYPE does not exists, say it as 'NOT_GIVEN'
                    unless(defined $type)
                    {
                        $type = 'NOT_GIVEN';
                    }

                    # if ROM_FILE does not exists, say it as 'NOT_GIVEN'
                    unless(defined $romFile)
                    {
                        $romFile = 'NOT_GIVEN';
                    }

                    #STEP fill device hash with ctrlNum, device, chipSelect, type, romFile
                    #prepare internal device hash
                    $Device_hash{$dev_name}{'CTRL_INDEX'} = $ctrlNum;
                    $Device_hash{$dev_name}{'DEV_INDEX'} = $device;
                    $Device_hash{$dev_name}{'CHIP_SELECT'} = $chipSelect;
                    $Device_hash{$dev_name}{'TYPE'} = $type;
                    $Device_hash{$dev_name}{'ROM_FILE'} = $romFile;

                    #flag for inconsistency in channel settings
                    # assume that there is no inconsistency 
                    my $isInvalidChannelSettings = DISABLE;

                    #total channels for table rowspan
                    my $numOfChannels = 0;

                    #LOOP-START foreach channel's data
                    #validate the CHANNELS configuration of particular device
                    foreach my $channel(sort {$a <=> $b} keys %{$quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'CHANNELS'}})
                    {
                        #STEP validate channel settings
                        #validate channel number
                        unless($channel =~ /\d+/)
                        {
                            S_set_error( "! QUATE: $channel is not a valid channel index. Channel indexes shall only be integer. Ex: $quate_name ->{DEVICES}{$device}{CHANNELS}=>{1}, {2}..  ", 20 );

                            #enable inconsistency indicator
                            $isInvalidChannelSettings = ENABLE;
                        }

                        #STEP fill channelConfig hash with channel, channelName, SID
                        my $channelConfig = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'CHANNELS'}{$channel};

                        #check out channel name, if exists
                        # if CHANNEL_NAME does not exists, say it as 'NOT_GIVEN'
                        unless(defined $channelConfig->{'CHANNEL_NAME'})
                        {
                            $channelConfig->{'CHANNEL_NAME'} = 'NOT_GIVEN';
                        }


                        #validate SID , whether it is in correct format
                        if(defined $channelConfig->{'SID'} && $channelConfig->{'SID'} !~ /\d+/ && $channelConfig->{'SID'} ne 'NOT_GIVEN')
                        {
                            S_set_error( "! QUATE: $channelConfig->{'SID'} is not a valid SID. ".
                                        "SID shall only be integer. Ex: $quate_name ->{DEVICES}{$device}{CHANNELS}{$channel}{'SID'} = 0,1,2,.. ", 20 );

                            #enable inconsistency indicator
                            $isInvalidChannelSettings = ENABLE;
                        }

                        # if CHIP_SELECT does not exists, say it as 'NOT_GIVEN'
                        unless(defined $channelConfig->{'SID'})
                        {
                            $channelConfig->{'SID'} = 'NOT_GIVEN';
                        }

                        # if SPI2 does not exists, say it as 'NOT_GIVEN'
                        unless(defined $channelConfig->{'SPI2'})
                        {
                            $channelConfig->{'SPI2'} = 'NOT_GIVEN';
                        }

                        $numOfChannels++;

                    }
                    #LOOP-END data of all channels prepared

                    #if there was an inconsistency found during Channel configuration validation,
                    #log the error and return
                    if($isInvalidChannelSettings == ENABLE)
                    {
                        S_set_error( "! Invalid configuration found for channels: $quate_name ->{'DEVICES'}{$device}{'CHANNELS'} ", 20 );
                        return 0;
                    }

                    #STEP insert quate_CONFIG into Device_hash
                    $Device_hash{$dev_name}{'CHANNELS'} = $quate_CONFIG->{$quate_name}{'DEVICES'}{$device}{'CHANNELS'};

                    # for first channel, a special care is needed while creating table
                    my $isFirstChannel = 1;

                    foreach my $channel(sort {$a <=> $b} keys %{$Device_hash{$dev_name}{'CHANNELS'}})
                    {
                        my $channelConfig = $Device_hash{$dev_name}{'CHANNELS'}{$channel};

                        push(@table,"<TR>");

                        # for first channel, insert DEVICE_NAME & QUATE INDEX 
                        if($isFirstChannel == 1) {
                            push(@table,"<TD rowspan=\"$numOfChannels\"> $dev_name </TD><TD rowspan=\"$numOfChannels\"> $ctrlNum </TD><TD rowspan=\"$numOfChannels\"> $chipSelect</TD><TD rowspan=\"$numOfChannels\"> $type </TD><TD rowspan=\"$numOfChannels\"> $romFile </TD>");
                            S_w2log( 3, " DEVICE NAME -> $dev_name , QUATE INDEX -> $ctrlNum, CHIP SELECT -> $chipSelect, TYPE -> $type, ROM FILE -> $romFile,  CHANNELS => \n");
                        }

                        push(@table, "<TD> $channel </TD><TD> $channelConfig->{'CHANNEL_NAME'} </TD>".
                                      "<TD> $channelConfig->{'SID'} </TD><TD> $channelConfig->{'SPI2'} </TD>".
                                      "</TR>");

                        S_w2log( 3, "         CHANNEL INDEX-> $channel, CHANNEL NAME-> $channelConfig->{'CHANNEL_NAME'}, SID-> $channelConfig->{'SID'}, SPI2-> $channelConfig->{'SPI2'} \n" );

                        $isFirstChannel = 0;

                    }
                }
                else
                {
                    S_set_error( "DEVICES=>{INDEX} should be a number in ProjectDefaults->{'QUATE'}{'$quate_name'}" , 20);
                    return 0;
                }

            } #end of for loop across all devices of particular QuaTe    
            #LOOP-END data for all devices prepared

            #STEP validate and prepare trigger settings
            #check whether TRIGGER settings exists for this QuaTe
            my $triggerLine1 = $quate_CONFIG->{$quate_name}{'TRIGGER'}{'LINE_1'};
            my $triggerLine2 = $quate_CONFIG->{$quate_name}{'TRIGGER'}{'LINE_2'};

            # if any one of the trigger line is defined
            if(defined $triggerLine1 || defined $triggerLine2)
            {
                #set trigger line to 'OFF' if not defined
                $triggerLine1 = 'OFF' unless(defined $triggerLine1);
                $triggerLine2 = 'OFF' unless(defined $triggerLine1);

                #check whether trigger line settings are valid
                unless(exists $QuaTe_Trigger_Mapping{$triggerLine1} && exists $QuaTe_Trigger_Mapping{$triggerLine2})
                {
                    S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. Trigger line can be OFF, POS_SLOPE, NEG_SLOPE, EXT_TRIGGER ", 20 );
                    return 0;
                }

                # both trigger line settings cannot be OFF
                if($triggerLine1 eq 'OFF' && $triggerLine2 eq 'OFF')
                {
                    S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. Both Trigger lines cannot be OFF", 20 );
                    return 0;
                }

                #any one trigger line should be OFF
                if($triggerLine1 ne 'OFF' && $triggerLine2 ne 'OFF')
                {
                    S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. Both trigger lines cannot be used at a time for any Quate", 20 );
                    return 0;
                }

                # validation differs for Master Quate and Slave quates
                # $CtrlNum = 0, if master quate
                if($ctrlNum == 0)
                {
                    if($triggerLine1 eq 'EXT_TRIGGER' || $triggerLine2 eq 'EXT_TRIGGER')
                    {
                        S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. Master quate should not contain EXT_TRIGGER", 20 );
                        return 0;
                    }

                    #trigger line1 POS_SLOPE not supported and should be restricted because, devices are not supporting Triggerline1 POS_SLOPE trigger type
                    if($triggerLine1 eq 'POS_SLOPE')
                    {
                        S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. POS_SLOPE cannot be used for LINE_1, as Quate Devices will not support TRIGGET LINE_1 POS_SLOPE trigger type", 20 );
                        return 0;
                    }

                    #determine the GLOBAL_TRIGGER for Devices , so that the all device channels shall be configured to start the injection when trigger is received
                    if($triggerLine1 eq 'OFF')
                    {
                        $GlobalSettings{'GLOBAL_TRIGGER'} = 'TRIG_LINE2_' . $triggerLine2;
                    }
                    else
                    {
                        $GlobalSettings{'GLOBAL_TRIGGER'} = 'TRIG_LINE1_' . $triggerLine1;
                    }

                }
                else
                {
                    # for Slave quates, atleast any of the trigger line should be EXT_TRIGGER
                    unless($triggerLine1 eq 'EXT_TRIGGER' || $triggerLine2 eq 'EXT_TRIGGER')
                    {
                        S_set_error( "! Invalid settings in $quate_name ->{'TRIGGER'}. Slave QuaTes should have one EXT_TRIGGER", 20 );
                        return 0;
                    }
                }

            }
            # no trigger lines are defined
            else
            {
                S_set_error( "! Atleast one trigger line should be defined in $quate_name ->{'TRIGGER'} ", 20 );
                return 0;
            }

            # store trigger settings in GlobalSettings hash
            $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_1'} = $triggerLine1;
            $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_2'} = $triggerLine2;

            S_w2log( 3, " QuaTe_configure: Trigger settings : $quate_name : LINE_1 -> $triggerLine1 , LINE_2 -> $triggerLine2 \n" );

            push(@table1,'<TR><TD>'.$quate_name.'</TD><TD>'.$triggerLine1.'</TD><TD>'.$triggerLine2.'</TD></TR>');
        } #end of if loop to check whether all QuateX config is present
        else
        {
            S_set_error( "$quate_name does not exist in ProjectDefaults->{'QUATE'}" , 20);
            return 0;
        }
    }
    #LOOP-END data of all QuaTes prepared

    push( @TC_HTML_TEXT, join('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">','<TR><TH>DEVICE NAME</TH><TH>QUATE INDEX</TH><TH>CHIP SELECT</TH><TH>TYPE</TH><TH>ROM FILE</TH><TH>CHANNEL INDEX</TH><TH>CHANNEL NAME</TH><TH>SID</TH><TH>SPI2</TH></TR>',@table,'</TABLE></div>',"\n")  );
    push( @TC_HTML_TEXT, join('','<div class="w2rep ',$module_name,'"><TABLE class="tablesorter">','<TR><TH>QUATE INDEX</TH><TH>TRIGGER LINE 1</TH><TH>TRIGGER LINE 2</TH></TR>',@table1,'</TABLE></div>',"\n")  );

    # local hash which contains channel mapping
    if (exists ( $main::ProjectDefaults->{'QUATE_CHANNELS'}))
    {
        foreach my $key (keys %{$main::ProjectDefaults->{'QuaTe_Channels'}})
            {
                $$Channel_Hash{$key} = ${$main::ProjectDefaults->{'QuaTe_Channels'}}{$key};
            }
    }


    if ($main::opt_offline)
    {
        S_w2log( 4, "QuaTe_configure: configured successfully (Offline printout) \n" );
        $QT_initialized = 1;
        return 1;
    }

    #CALL QuaTe_ResetController('ALL')
    #Reset all the Quates before doing any settings
    QuaTe_ResetController('ALL');

    #LOOP-START foreach QuaTe HW
    # set all Quate's clock to internal clock
    for (my $ctrlNum = 0; $ctrlNum < $NumOfCtrls; $ctrlNum++) # number of Quates/controllers
    {
        #STEP SetClockSource (0: internal from QuaTe-unit)
        $status = qt_SetClockSource($ctrlNum, 0); # set clock to internal
        check_status($status);
        S_w2log( 3, " QuaTe_configure: Set clock source of Quate $ctrlNum to internal : $status \n" );

    }
    #LOOP-END all QuaTe clocks set

    #LOOP-START foreach QuaTe HW
    #Set the controller Trigger Mode of all the controllers configured in the Project Constants
    for (my $ctrlNum = 0; $ctrlNum < $NumOfCtrls; $ctrlNum++) # number of Quates/controllers
    {
        my $quate_name = $Quate.$ctrlNum;
        #STEP LoadHWConfiguration(firmware)
        #load the respective firmware files to the QuaTe
        my $qt_status = QuaTe_LoadHWConfiguration($ctrlNum, $GlobalSettings{$quate_name}{'FIRMWARE'});

        #if any of the firmware update fails, reset the $QT_initialized flag to indicate that Firmware initialization failed
        if($qt_status < 0)
        {
            $QT_initialized = 0;
        }

        #STEP SetControllerTriggerMode
        # set the controller trigger appropriately
        QuaTe_SetControllerTriggerMode($ctrlNum , $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_1'}, $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_2'});

    }
    #LOOP-END all firmwares and trigger modes configured

    #LOOP-START foreach device HW
    # Configure the devices and its channels according to the configuration done in ProjectDefaults
    foreach my $device (sort keys %Device_hash)
    {
        #STEP ResetDevice
        #reset device before doing any setting
        $status = qt_ResetDevice($Device_hash{$device}{'CTRL_INDEX'}, $Device_hash{$device}{'DEV_INDEX'} );
        check_status($status);
        S_w2log( 3, " QuaTe_configure: Reset device $Device_hash{$device}{'DEV_INDEX'} on Quate $Device_hash{$device}{'CTRL_INDEX'} : $status \n" );

        #set CHIP_SELECT
        unless ($Device_hash{$device}{'CHIP_SELECT'} eq 'NOT_GIVEN')
        {
            QuaTe_SetChipSelect($device, $Device_hash{$device}{'CHIP_SELECT'}, ENABLE);
        }

        #STEP SetSensorConfiguration(romFile)
        #set sensor configuration, this will automatically reset device -> therefore trigger config has to be done afterwards
        $romFile = $Device_hash{$device}{'ROM_FILE'};
        unless ($romFile eq 'NOT_GIVEN')
        {
           QuaTe_SetSensorConfiguration($device, $romFile);
        }

        #STEP SetChannelTriggerMode
        # set trigger mode of all the channels of this device to GLOBAL_TRIGGER
        QuaTe_SetChannelTriggerMode($device, 'ALL', $GlobalSettings{'GLOBAL_TRIGGER'});

        #do channel related settings                        
        if(exists $Device_hash{$device}{'CHANNELS'})
        {
            #STEP deviceType = GetDeviceType
            my $deviceType = qt_GetDeviceType($Device_hash{$device}{'CTRL_INDEX'},  $Device_hash{$device}{'DEV_INDEX'} );
            check_status($deviceType);

            #LOOP-START foreach channel HW
            # for all channels available, do the configured settings
            foreach my $channel(sort {$a <=> $b} keys %{$Device_hash{$device}{'CHANNELS'}})
            {

                  #set SID for channels
                 my $sid = $Device_hash{$device}{'CHANNELS'}{$channel}{'SID'};

                 # INFO: SID is only applicable for device types DEVICE_TYPE_ABPLUS_DEVICE, DEVICE_TYPE_SPI
                unless ($sid eq 'NOT_GIVEN')
                {
                    #IF deviceType is ABPLUS or SPI
                    if ($deviceType == DEVICE_TYPE_ABPLUS_DEVICE || $deviceType == DEVICE_TYPE_SPI)
                    {
                        #IF-YES-START
                        # STEP SetSID
                        QuaTe_SetSID($device, $Device_hash{$device}{'CHANNELS'}{$channel}{'CHANNEL_NAME'}, $sid);
                        #IF-YES-END
                    }
                    else
                    {
                        #IF-NO-START
                        S_w2log( 3, " QuaTe_configure: SID settings is only needed for ABPLUS, Internal sensors \n" );
                        #IF-NO-END
                    }

                }
                #STEP (status, value) = GetStaticData
                # Forces error checking for specified channel, in order to show errors early in init phase, not only later during crash injection
                my $value;
                ($status, $value) = qt_GetStaticData( $Device_hash{$device}{'CTRL_INDEX'}, $Device_hash{$device}{'DEV_INDEX'}, $channel, 1 );
                #IF status < 0
                if ( $status < 0 )
                {
                    #IF-YES-START
                    #STEP Report error "channel not supported for this device"
                    my $errortext = qt_GetErrorString($status);
                    S_set_error( "QuaTe_configure fault: CHANNEL INDEX [$channel], CHANNEL_NAME '$Device_hash{$device}{'CHANNELS'}{$channel}{'CHANNEL_NAME'}' is not supported for sensor '$device' (QuaTe error code: '$errortext') )" , 20);
                    #IF-YES-END
                }
                #IF-NO-START
                #IF-NO-END
            }
            #LOOP-END all channels configured
        }

    }
    #LOOP-END all devices configured

    #LOOP-START foreach QuaTe HW
    #Set the controller Trigger Mode of all the controllers configured in the Project Constants
    for (my $ctrlNum = 0; $ctrlNum < $NumOfCtrls; $ctrlNum++) # number of Quates/controllers
    {
        my $quate_name = $Quate.$ctrlNum;
        #COMMENT-START
        #   WORKAROUND: Configure Trigger again
        #COMMENT-END
        #STEP SetControllerTriggerMode
        # set the controller trigger again appropriately
        #WORKAROUND - for Trigger to stay for subsequent testcases without initializing QuaTe again (introduced in Rev. 1.6)
        QuaTe_SetControllerTriggerMode($ctrlNum , $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_1'}, $GlobalSettings{$quate_name}{'TRIGGER'}{'LINE_2'});

    }
    #LOOP-END all trigger modes configured
    #STEP return 1
	return 1;
}



=head2 QuaTe_LoadHWConfiguration

I<B<Syntax : >>

    QuaTe_LoadHWConfiguration($QuateIndex, $Firmware);

I<B<Arguments    : >>

    $QuateIndex     =   The index of Quate hardware
    $Firmware       =   Firmware number in Quate flash memory (or) Firmware file name/path
                        if Firmware file name is given , the Firmware will be checked in Project\Config\Tools\Quate\

I<B<Description :>>

Loads the specified Firmware (from file or Flash memory) to the specified Quate

I<B<Return values :>>

      -1  on Error
    >= 0  on Success

I<B<Examples :>>

   QuaTe_LoadHWConfiguration(0, 'rev2_step31_v1.bit');  # load from firmware file
   QuaTe_LoadHWConfiguration(0, 5);                     # load 5th firmware from Flash

=cut

sub QuaTe_LoadHWConfiguration
{

    # default path of Quate firmwares
    my $FirmWarePath = "$LIFT_config::LIFT_PRJCFG_path/Tools/Quate/";

    my $QuateIndex = shift;
    my $Firmware = shift;
    my $isLoadFromFlash = 0;

    unless(defined $Firmware)
    {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_LoadHWConfiguration (QuateIndex, FirmwareFile)", 110 );
        return NEGATIVE_STATUS;
    }

    my $FirmWareFilePath;

    #if the user wants to load firmware from Quate Flash (Rev.2) Numbers : 1..8
    if($Firmware =~ /^\d+$/)
    {
        $isLoadFromFlash = 1;
    }
    else
    {
        #check whether firmware file exists
        if((-f $Firmware) || (-f "$FirmWarePath$Firmware"))
        {
            $FirmWareFilePath = $Firmware if(-f $Firmware);
            $FirmWareFilePath = "$FirmWarePath$Firmware" if(-f "$FirmWarePath$Firmware");
        }
        else
        {
            S_set_error( "! Firmware file '$Firmware' is not found", 5 );
            return NEGATIVE_STATUS;
        }
    }

    S_w2log( 3, "QuaTe_LoadHWConfiguration (QUATE: $QuateIndex, $FirmWareFilePath)\n");


    #check whether QuateIndex is a valid number
    unless($QuateIndex =~ /^\d+$/)
    {
        S_set_error( "Quate Index should be a Number. Ex: 0,1,2..." , 114) ;
        return NEGATIVE_STATUS;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "Quate is not initialized" , 120);
        return NEGATIVE_STATUS;
    }

    return 1 if($main::opt_offline);

    if($isLoadFromFlash)
    {
        $status = qt_LoadHWConfiguration( $QuateIndex, $Firmware );
        check_status($status);
        S_w2log( 4, "Status of qt_LoadHWConfiguration : $status \n" );
    }
    else
    {
        $status = qt_LoadHWConfigurationFromFile( $QuateIndex, $FirmWareFilePath );
        check_status($status);
        S_w2log( 4, "Status of qt_LoadHWConfigurationFromFile : $status \n" );
        $status += S_add_file_to_snapshot($FirmWareFilePath);
    }

    return $status;


}

=head2 QuaTe_ReadSPIMonitorLevel

I<B<Syntax : >>

    $samples = QuaTe_ReadSPIMonitorLevel( $DeviceName );

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults

I<B<Description :>>

returns the number of samples recorded by the SPI-Monitor for the particular device

I<B<Return values :>>

    $samples   =   number of samples recorded by SPI-monitor

I<B<Examples :>>

   QuaTe_ReadSPIMonitorLevel( 'SMA560' );    

=cut

sub QuaTe_ReadSPIMonitorLevel
{
    my $DeviceName = shift;
    my $samples;
    my ($CtrlIndex, $DeviceIndex );

    S_w2log( 3, "QuaTe_ReadSPIMonitorLevel\n");

    unless (defined( $DeviceName ))
    {
        S_set_error( "! too less parameters ! QuaTe_ReadSPIMonitorLevel : Device_name is missing", 110 );
        return 1;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    #get Quate index and device index
    ($CtrlIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    S_w2log( 4, "QuaTe_ReadSPIMonitorLevel ($DeviceName [QUATE:$CtrlIndex  DEVICE:$DeviceIndex])");

    return 1 if ($main::opt_offline);

    $samples = qt_ReadSPIMonitorLevel($CtrlIndex, $DeviceIndex );
    check_status($status);
    S_w2log( 4, "ReadSPIMonitorLevel ($DeviceName) : $samples \n");

    return($samples);

}


=head2 QuaTe_ReadSPIMonitorPlusData

I<B<Syntax : >>

    $samples = $data_HoH = QuaTe_ReadSPIMonitorPlusData($DeviceName, $NumOfSamples);

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults

I<B<Description :>>

returns structure of recorded data by SPI recorder. Sensors and commands are mapped from project defaults. 

Structure can be evaluated with EVAL functions.

I<B<Return values :>>

    $data_HoH   =   number of samples recorded by SPI-monitor

timebase of structure in milliseconds

    $data_HoH={
          time1 => {"SENSOR1:COMMAND:MOSI" => VALUE, "SENSOR1:COMMAND:MISO" => VALUE},
          time2 => {"SENSOR2:COMMAND:MOSI" => VALUE, "SENSOR2:COMMAND:MISO" => VALUE},
          };

=begin html

$Device_name has to be mapped via ProjectDefaults->{'QUATE'} <br/>
the chip select in trace is used to fetch the sensor name from ProjectDefaults <br/>
the Type (nothing but Decoder Type) defined in the ProjectDefaults under the given sensor is read <br/>
the Instruction name will be taken from ProjectDefaults->{sensor name'_COMMAND'} Instruction (7 bits, no parity bit) <br/>
also extended instructions are supported (16 bits) but then use only extended format for this instruction. 

=end html

=over 2

=item * If Type = 'AB+'

Address name from ProjectDefaults->{'AB+_SENSOR'}{'address'}

Instruction name from ProjectDefaults->{'AB+_COMMAND'}{'instruction'}

            'AB+_SENSOR' =>  {
                                    '100' => 'LIN_X',
                             },

            'AB+_COMMAND' => {
                                    '00000' => 'DATA_CAPTURE',
                             },

no extended (16-bit) instructions are supported

for AB+ RD_INT_DATA additionally _P{EEPROMaddress} is added to COMMAND to identify sensor EEPROM location

e.g. "PITCH:RD_INT_DATA_P3:MISO"
VALUE will be in binary e.g. 0b11100000

=item * If Type = 'MM5'

Address name from ProjectDefaults->{'MM5_SENSOR'}{'address'}

Instruction name from ProjectDefaults->{'MM5_COMMAND'}{'instruction'}

no extended (16-bit) instructions are supported

=item * If Type = 'SMI7',

Address name from ProjectDefaults->{'SMI7_SENSOR'}{'address'}

Instruction name from ProjectDefaults->{'SMI7_COMMAND'}{'instruction'}

(both Sensor module and sensor data command decoding supported)

            'SMI7_COMMAND' => { 
                                #for Sensor Module commands decoding ( Page bits - 21 .. 19 of MISO, command bits - 26..23 of MOSI)
                                #page 0 commands
                                '0000000' => 'CONF_IREG0',
                                '0000001' => 'CONF_IREG1',
                                 ...
                                 ...
                                 ...
                                #page 1 commands
                                '0010000' => 'PLL_FREQ',
                                '0010001' => 'PLL_ICO_OUT',
                                 ...
                                 ...
                                 ...
                                #page 2 commands
                                '0100000' => 'TEMP1',
                                '0100001' => 'error_flag_16_bank0',
                                 ...
                                 ...
                                 ...
                                #page 3 commands
                                '0110000' => 'scon_adc_ucm_yaw',
                                '0110001' => 'scon_adc_ucm_acc1', 
                                 ...
                                 ...
                                 ...
                                #page 4 commands
                                '1000000' => 'ASIC_SERIAL_NR_0',
                                '1000010' => 'ASIC_SERIAL_NR_1',
                                 ...
                                 ...
                                 ...
                                #page 5 commands
                                '1010000' => 'LAST_BITE_ACC1_POS',
                                '1010001' => 'LAST_BITE_ACC1_NEG',
                                 ...
                                 ...
                                 ...
                                #for Sensor Data commands decoding (channel cmd bits 29 .. 27 and CAP(mode) bits from 26 .. 24 )
                                # mode = 011 = Read current data
                                '010011' => 'RD_CUR_DATA_RATE_LF',
                                '011011' => 'RD_CUR_DATA_RATE_HF',
                                 ...
                                 ...
                                 ...
                                # mode = 010 = Read captured data
                                '010010' => 'RD_CAPTURED_DATA_RATE_LF',
                                '011010' => 'RD_CAPTURED_DATA_RATE_HF',
                                 ...
                                 ...
                                 ...
                                # mode = 101 = Data capture and read
                                '010101' => 'CAPTURED_DATA_RATE_LF',
                                '011101' => 'CAPTURED_DATA_RATE_HF',
                                 ...
                                 ...
                                 ...
                              },

            'SMI7_SENSOR' => { # bit 31-30)
                               '00' =>'SMI700_1',
                               '01' =>'SMI700_2',
                               '10' =>'SMI710_1',
                               '11' =>'SMI710_2',
                             },

=item * If Type = 'SMA660',

Instruction name from ProjectDefaults ->{'SMA660_COMMAND'}{'instruction'}

This decoder supports both bit wise decoding and regular decoding.

In addition to this hash, 'SMA660_FORMAT' hash is defined.

The hash example of the 'SMA660_COMMAND' and 'SMA660_FORMAT' are given below.

These hashes are in sync with the hash format of SPI explorer tool.

(SMA660_SENSOR hash not required as there is the only sensor)

            'SMA660_FORMAT' => { #start bit numbers and length (bit0 start from LSB)
                                  'platform'=>'AB12', #not used by SMA660 decoder
                                  'frame_length' => '32',
                                  'instruction_length' => '10',
                                  ############used by SPI explorer###############
                                  'DataValueTable_MOSI' =>{ #'instruction' and 'data' fields are mandatory
                                                          'Data_name|bits' => ['instruction|31:22','pe|21:21','data|20:5','CRC|4:2'],
                                                          #nothing else to decode
                                                          },

                                  'DataValueTable_MISO' =>{ #'data' field is mandatory
                                                            'Data_name|bits' => ['status|31:26','S|25:25','sid_status2|24:20','data|19:4','gs|3:3','CRC|2:0'],
                                                            'status' => { # x means bit is dont-care
                                                                        'xxxxx1'=>'DIS1: disposal function active',
                                                                        'xxxx1x'=>'DIS2: disposal function active',
                                                                        'xxx1xx'=>'WDF: watchdog fault occured',
                                                                        'xx1xxx'=>'EOP: programming possible',
                                                                        'x1xxxx'=>'TST: ASIC in test mode',
                                                                        '1xxxxx'=>'TFF: failure in previous SPI comm.',
                                                                    },
                                                          },
                                   ############used by SPI explorer###############
                                 },
              'SMA660_COMMAND' => 
                                  {#bits 31 - bit 22 MOSI
                                      '1111111100' => {'command' => 'PROT_SEL',
                                                       'module'=>'SPI', #optional - for SPIexplorer
                                                       'color'=>'light_Green', #optional - for SPIexplorer
                                                       'DataValueTable_MOSI' =>{
                                                                                  'Data_name|bits' => ['PROT|31:0'],
                                                                                  'PROT' => { 
                                                                                              '11111111000000001111111100000000' => 'BOSCH_SPI',
                                                                                              '00000000111111110000000011111111' => 'OPEN_SPI'
                                                                                            },
                                                                                },
                                                      },
                                      '0010000000' => {'command' => 'RD_MODE',
                                                       'module'=>'SPI', #optional - for SPIexplorer
                                                       'color'=>'blue', #optional - for SPIexplorer
                                                       'DataValueTable_MISO' =>{
                                                                                 'Data_name|bits' => ['Voltage_Mode|7:4','PRO|8'],
                                                                                 'Voltage_Mode' => {
                                                                                                      '0111' => '6.7V',
                                                                                                      '0000' => '5V',
                                                                                                       '1000' =>'3.3V'
                                                                                                    },
                                                                                 'PRO' => {
                                                                                             '1' => 'OPEN_SPI',
                                                                                             '0' => 'BOSCH_SPI'
                                                                                          },
                                                                                },
                                                      },
                                      '0000000000' => {'command' =>'RD_SENSOR_DATA_CH1',
                                                       'instruction_length' => '10',
                                                       'DataValueTable_MOSI' =>{
                                                                                  'Data_name|bits'=> ['SID1|24:20','Sensor_data|19:8'],
                                                                               },
                                                      },
                                      '1000100000' => 'RD_CAPTURED_DATA_CH2',
                                      '0010001100' => 'RD_SID',
                                      '0010100100' => 'RD_OFFSET_REG_CH1',
                                      '0010101000' => 'RD_OFFSET_REG_CH2',
                                  },

=item * If Type is not 'AB+' or 'MM5' or 'SMI7' or 'SMA660'

Address name from ProjectDefaults->{'SensorName_SENSOR'}{'address'}

Instruction name from ProjectDefaults->{'SensorName_COMMAND'}{'instruction'}

Extended instructions (16-bit) are supported

E.g.

            'SMB470_COMMAND' => {
                                    '0000000' => 'RD_DEVICE_ID',
                                }, 

            'SMG100_COMMAND' => {
                                    '0000000'          => 'RD_DEVICE_ID',       # normal instruction
                                    '0011100000000001' => 'WR_BITE_TEST_POS',   # extended instruction
                                    '0011100000000010' => 'WR_BITE_TEST_NEG',
                                    '0011100000000000' => 'WR_BITE_TEST_OFF',
                                },


=back

I<B<Examples :>>

   $data_HoH = QuaTe_ReadSPIMonitorPlusData('SPImonitor', 100);

=cut

sub QuaTe_ReadSPIMonitorPlusData
{
    my $DeviceName = shift;
    my $NumOfSamples = shift;
    my ($CtrlIndex , $DeviceIndex, $CS);
    my $data_HoH_dummy = {};
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    my ($data_HoA, $count, $sensorname, $signalname, $Address, $Instruction, $Page, $time,$Device);
    my ($cmd_MOSI,$np_flag_MOSI,$np); #SMI7 decoder variables
    my ($Time_aref, $MOSI_aref, $MISO_aref, $CS_aref, $Status_aref);

    S_w2log( 3, "QuaTe_ReadSPIMonitorPlusData\n");

    unless (defined( $NumOfSamples ))
    {
        S_set_error( "! too less parameters ! SYNTAX: data_HoH = QuaTe_ReadSPIMonitorPlusData( Device_name, NumOfSamples )", 110 );
        return($data_HoH_dummy);
    }

    if ( $NumOfSamples !~ /^\d+$/ || $NumOfSamples < 1 )
    {
        S_set_error("Invalid samples count : $NumOfSamples. Samples count shall be a number and greater than 0", 114 );
        return($data_HoH_dummy);
    }


    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($CtrlIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    S_w2log( 4, "QuaTe_ReadSPIMonitorPlusData ($DeviceName [QUATE:$CtrlIndex  DEVICE:$DeviceIndex], $NumOfSamples samples) \n");

    return($data_HoH_dummy) if( $main::opt_offline);

    ($status, $Time_aref, $MOSI_aref, $MISO_aref, $CS_aref, $Status_aref) = qt_ReadSPIMonitorPlusData($CtrlIndex, $DeviceIndex, $NumOfSamples );
    check_status($status);
    S_w2log( 3, "Status of QuaTe_ReadSPIMonitorPlusData : $status \n" );

    for ($count=0; $count<scalar(@$Time_aref); $count++)
    {
        $CS = "CS".@$CS_aref[$count];
        $Device = QuaTe_GetDeviceNameFromChipSelect($CS);

        unless(defined $Device)
        {
            S_set_error( "! Device $Device is not found in ProjectDefaults->{'QUATE'} configuration ", 114 );
            return 0;
       }

        if( $Device_hash{$Device}{'TYPE'} eq 'AB+')
        {

           @$MOSI_aref[$count] =~ /^(\d{3})(\d{5})(\d{0,4})/;
           $Address = $1;
           $Instruction = $2;
           $Page = $3;

           if (defined $main::ProjectDefaults->{'AB+_SENSOR'}{$Address}) {
              $sensorname = $main::ProjectDefaults->{'AB+_SENSOR'}{$Address};
           }
           else {
              $errormsg{"ProjectDefaults->{'AB+_SENSOR'}{$Address} not defined"}++;
              $sensorname = "undef";
           }

           if (defined $main::ProjectDefaults->{'AB+_COMMAND'}{$Instruction}) {
               $signalname = $sensorname.":".$main::ProjectDefaults->{'AB+_COMMAND'}{$Instruction};
           }
           else {
               $errormsg{"ProjectDefaults->{'AB+_COMMAND'}{$Instruction} not defined"}++;
               $signalname = $sensorname.":undef";
           }

           if ($Instruction eq '01001') {
               $signalname .= "_P".oct('0b'.$Page);
           }
        }
        elsif( $Device_hash{$Device}{'TYPE'} eq 'MM5')
        {
            @$MOSI_aref[$count] =~ /^\d{3}(\d{3})(\d{9})/;
            $Address = $1;
            $Instruction = $2;

            if (defined $main::ProjectDefaults->{'MM5_SENSOR'}{$Address}) {
                $sensorname = $main::ProjectDefaults->{'MM5_SENSOR'}{$Address};
            }
            else {
                $errormsg{"ProjectDefaults->{'MM5_SENSOR'}{$Address} not defined"}++;
                $sensorname = "undef";
            }

            if (defined $main::ProjectDefaults->{'MM5_COMMAND'}{$Instruction}){
                $signalname = $sensorname.":".$main::ProjectDefaults->{'MM5_COMMAND'}{$Instruction};
            }
            else{
                $errormsg{"ProjectDefaults->{'MM5_COMMAND'}{$Instruction} not defined"}++;
                $signalname = $sensorname.":undef";
            }
        }
        elsif ($Device_hash{$Device}{'TYPE'} eq 'SMI7')
        {
            @$MOSI_aref[$count] =~ /^\d{2}(\d{3})/; #32 bit value
            my $temp_cmd = $1;
            if ( $temp_cmd eq "001") # Sensor module commands
            {
                @$MOSI_aref[$count] =~ /^(\d{2})\d{3}(\d{4})\d{1}\d{1}(\d{1})\d{12}(\d{3})\d{5}/;  #for Sensor Module cmd -- MOSI
                $Address = $1; #sensor address
                $cmd_MOSI = $2;
                $np_flag_MOSI = $3; #next page indicator in MOSI, bit = 20
                $np = $4;#next page value
                $np = sprintf('%X', oct("0b$np")); #convert the binary number to Hex

                @$MISO_aref[$count] =~ /^\d{10}(\d{3})\d{19}/;
                $Page = $1; #page read from MISO message
                $Instruction = $Page.$cmd_MOSI; # to form the instruction , the page bits from MISO and command bits from MOSI are required
                if (defined $main::ProjectDefaults->{'SMI7_SENSOR'}{$Address})
                {
                    $sensorname = $main::ProjectDefaults->{'SMI7_SENSOR'}{$Address};  #eg : SMI700_1
                }
                else
                {
                    $errormsg{"ProjectDefaults->{'SMI7_SENSOR'}{$Address} not defined"}++;
                    $sensorname = "undef";
                }

                if (defined $main::ProjectDefaults->{'SMI7_COMMAND'}{$Instruction})
                {
                    $signalname = $sensorname.":".$main::ProjectDefaults->{'SMI7_COMMAND'}{$Instruction}; # eg : CONF_IREG0 
                }
                else
                {
                    $errormsg{"ProjectDefaults->{'SMI7_COMMAND'}{$Instruction} not defined"}++;
                    $signalname = "undef";
                }
            }
            elsif( $temp_cmd ne "000" && $temp_cmd ne "001") # sensor data commands every other value other than 000 is sensor data command
            {

                @$MOSI_aref[$count] =~ /^(\d{2})(\d{3})(\d{3})\d{22}/;
                $Address = $1;
                my $chl_cmd = $2; #channel command bits 
                my $mode = $3; #CAP bits
                $np_flag_MOSI = 0;
                $Instruction = $chl_cmd.$mode; # to form the instruction , the channel command bits and CAP bits from MOSI are required
                if (defined $main::ProjectDefaults->{'SMI7_SENSOR'}{$Address})
                {
                    $sensorname = $main::ProjectDefaults->{'SMI7_SENSOR'}{$Address};  #SMI700_1
                }
                else
                {
                    $errormsg{"ProjectDefaults->{'SMI7_SENSOR'}{$Address} not defined"}++;
                    $sensorname = "undef";
                }

                if (defined $main::ProjectDefaults->{'SMI7_COMMAND'}{$Instruction})
                {
                    $signalname = $sensorname.":".$main::ProjectDefaults->{'SMI7_COMMAND'}{$Instruction}; #SMI700_1:RD_CUR_DATA_RATE_LF
                }
                else
                {
                    $errormsg{"ProjectDefaults->{'SMI7_COMMAND'}{$Instruction} not defined"}++;
                    $signalname = "undef";
                }
            }
            else
            {
                S_set_error( "@$MOSI_aref[$count] message couldnot be decoded ", 0 );
            }
        }
        elsif( $Device_hash{$Device}{'TYPE'} eq 'SMA660')
        {
             $signalname = SMA660_decoder(@$Time_aref[$count], @$MOSI_aref[$count], @$MISO_aref[$count] );
        }
        else
        {
            @$MOSI_aref[$count] =~ /^(\d{7})(\d{9})/;
            $Instruction = $1;
            my $ExtendedInstruction = $1.$2;

            if (defined $main::ProjectDefaults->{'SPI_SENSOR'}{$CS}) {
                $sensorname = $main::ProjectDefaults->{'SPI_SENSOR'}{$CS};
            }
            else {
                $errormsg{"ProjectDefaults->{'SPI_SENSOR'}{$CS} not defined"}++;
                $sensorname = "undef";
            }

            if (defined $main::ProjectDefaults->{$sensorname.'_COMMAND'}{$Instruction}) {
                $signalname = $sensorname.":".$main::ProjectDefaults->{$sensorname.'_COMMAND'}{$Instruction};
            }
            elsif (defined $main::ProjectDefaults->{$sensorname.'_COMMAND'}{$ExtendedInstruction}) {
                $signalname = $sensorname.":".$main::ProjectDefaults->{$sensorname.'_COMMAND'}{$ExtendedInstruction};
            }
            else {
                $errormsg{"ProjectDefaults->{".$sensorname."_COMMAND}{$Instruction} not defined"}++;
                $signalname = $sensorname.":undef";
            }
        }

        $time = sprintf( "%010.3f" , @$Time_aref[$count]/1000.0);

        if($np_flag_MOSI)
        {
            $data_HoA->{$time}->{$signalname.':MOSI'.':NP'.$np} = '0b'.@$MOSI_aref[$count];
            $data_HoA->{$time}->{$signalname.':MISO'} = '0b'.@$MISO_aref[$count];
        }
        else
        {
            $data_HoA->{$time}->{$signalname.':MOSI'} = '0b'.@$MOSI_aref[$count];
            $data_HoA->{$time}->{$signalname.':MISO'} = '0b'.@$MISO_aref[$count];
        }
    }

    foreach (sort keys %errormsg)
    {
        S_w2rep("$_ : $errormsg{$_}\n","red");
    }
    if ($decoder_xls_flag) #close the excel book if opened.
    {
        $decoder_xls_flag = 0;
        $excel->{DisplayAlerts} = "False";
        $workbook->SaveAs($excelfile_abs);
        $excel->Workbooks->Close();
        $excel_count = 1;
     }
    return($data_HoA);

}

=head2 QuaTe_ResetController

I<B<Syntax : >>

    QuaTe_ResetController($QuateIndex);

I<B<Arguments    : >>

    $QuateIndex   =   Index of Quate to be reset
                      can be a number or 'ALL'

I<B<Description :>>

Reset the Quate based on Index. (or) 'ALL' to reset all Quates

I<B<Return values :>>

    <=0  on Error
    > 0  on Success

I<B<Examples :>>

   QuaTe_ResetController(0);        # reset 0th Quate
   QuaTe_ResetController('ALL');    # reset all Quates

=cut

sub QuaTe_ResetController
{
    my $QuateIndex = shift;

    unless(defined $QuateIndex)
    {
        S_set_error( "! too less parameters ! QuaTe_ResetController(\$QuateIndex); " , 110);
        return 0;
    }

    unless($QuateIndex =~ /^\d+$/ || $QuateIndex =~ /ALL/i)
    {
        S_set_error( "Invalid input : $QuateIndex . Quate Index should be a number (or) 'ALL'" , 114);
        return 0;
    }

    S_w2log( 3, "QuaTe_ResetController ($QuateIndex) \n");

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    return 1 if ($main::opt_offline);

    #IF QuateIndex == "ALL"
    if($QuateIndex =~ /ALL/i)
    {
        #IF-YES-START
        #reset all controllers
        #LOOP-START foreach QuateIndex q
        for my $index (0..($NumOfQuates-1))
        {
            #STEP ResetUnit(q)
            $status = qt_ResetUnit($index);
            check_status($status);
            S_w2log( 3, "Status of QuaTe_ResetController ($index) : $status \n" );
        }
        #LOOP-END all QuaTes reset
        #IF-YES-END
    }
    else
    {
        #IF-NO-START
        #reset the particular Quate of that Index
        #STEP ResetUnit(QuateIndex)
        $status = qt_ResetUnit($QuateIndex);
        check_status($status);
        S_w2log( 3, "Status of QuaTe_ResetController ($QuateIndex) : $status \n" );
        #IF-NO-END
    }
    #STEP return 1
    return 1;
}


=head2 QuaTe_SavePSIMonitorData

I<B<Syntax : >>

    QuaTe_SavePSIMonitorData($deviceName, $csv_file[, $monitorQuaTeAfterDownload]);

I<B<Arguments    : >>

    $deviceName   =   Name of the PSI monitor device as mentioned in ProjectDefaults
    $csv_file     =   CSV file path in which the SPI data to be saved
    $monitorQuaTeAfterDownload (optional flag)
      = 0: is ignored
      = 1: Only save QuaTe monitor, if any of its devices were filled by 'QuaTe_DownloadData' before.
           This option is only useful, if called in this sequence:
            1. QuaTe_DownloadData                -> sets flags for used QuaTes/devices
            2. QuaTe_SetPSIMonitorMode (ENABLE)  -> if device flag not set: warns & skips devices
            3. QuaTe_SetControllerTriggerMode
            4. QuaTe_SetPSIMonitorMode (DISABLE) -> if device flag not set: warns & skips devices
            5. QuaTe_SavePSIMonitorData          -> if QuaTe-No flag not set: warns & skips QuaTe
                                                    saves monitor, resets flags for next download

I<B<Description :>>

save PSI monitor data to CSV file

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SavePSIMonitorData('SPImonitor', 'c:\temp\PSITrace.csv');

=cut

sub QuaTe_SavePSIMonitorData
{
    my $deviceName = shift;
    my $csv_file = shift;
    my $monitorQuaTeAfterDownload = shift; # optional

    my ($ctrlIndex, $deviceIndex);

    unless (defined( $csv_file )) {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SavePSIMonitorData(\$deviceName, \$csv_file); ", 110 );
        return 0;
    }

    unless ($csv_file =~ /.csv$/i ) {
        S_set_error( "! Wrong parameters ! Given file name does not contain .csv extension ", 109 );
        return 0;
    }

     unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($ctrlIndex, $deviceIndex) = QuaTe_GetIndexFromDevice($deviceName);

    # check whether the indexes are found correctly
    unless(defined $ctrlIndex)
    {
        S_set_error( "! Device $deviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    unless ( %gPsiDevicesSetup4Inject && defined $gPsiDevicesSetup4Inject{$ctrlIndex} )
    {
        S_w2log( 4, "! QuaTe_SavePSIMonitorData: QuaTe[$ctrlIndex] was not setup for this injection, by 'QuaTe_DownloadData' before ( $ERR_MSG_QT_MONITOR )\n" );
        if ( $monitorQuaTeAfterDownload ) { return 1; }
    }

    S_w2log(3, " QuaTe_SavePSIMonitorData($deviceName [QUATE: $ctrlIndex  DEVICE: $deviceIndex], '$csv_file') \n");

    if ($main::opt_offline)
    {
       S_create_dummy_file($csv_file);
       return 1 ;
    }

    $status = qt_SavePSIMonitorData( $ctrlIndex, $deviceIndex, $csv_file );
    check_status($status);
    S_w2log( 3, "Status of QuaTe_SavePSIMonitorData : $status \n" );

    undef(%gPsiDevicesSetup4Inject); # reset to prepare for next use

    return 1;
}

=head2 QuaTe_SaveSPIMonitorData

I<B<Syntax : >>

    QuaTe_SaveSPIMonitorData($DeviceName, $CSV_file[, $monitorQuaTeAfterDownload]);

I<B<Arguments    : >>

    $DeviceName   =   Name of the SPI monitor device as mentioned in ProjectDefaults
    $CSV_file     =   CSV file path in which the SPI data to be saved
    $monitorQuaTeAfterDownload (optional flag)
      = 0: is ignored
      = 1: Only save QuaTe monitor, if any of its devices were filled by 'QuaTe_DownloadData' before.
           This option is only useful, if called in this sequence:
            1. QuaTe_DownloadData                -> sets flags for used QuaTes/devices
            2. QuaTe_SetSPIMonitorMode (ENABLE)  -> if device flag not set: warns & skips devices
            3. QuaTe_SetControllerTriggerMode
            4. QuaTe_SetSPIMonitorMode (DISABLE) -> if device flag not set: warns & skips devices
            5. QuaTe_SaveSPIMonitorData          -> if QuaTe-No flag not set: warns & skips QuaTe
                                                    saves monitor, resets flags for next download

I<B<Description :>>

save SPI monitor data to CSV file

B<Note: this will empty the QuaTe buffer, so before reading SPI data again a new trace has to be recorded.>

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SaveSPIMonitorData('SPImonitor', 'D:\SPITrace.csv');

=cut

sub QuaTe_SaveSPIMonitorData
{
    my $deviceName = shift;
    my $csvFile = shift;
    my $monitorQuaTeAfterDownload = shift; # optional

    my ( $ctrlIndex, $deviceIndex );

    unless (defined( $csvFile )) {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SaveSPIMonitorData(\$deviceName, \$csvFile); ", 110 );
        return 0;
    }

    unless ($csvFile =~ /.csv$/i ) {
        S_set_error( "! Wrong parameters ! Given file name does not contain .csv extension ", 109 );
        return 0;
    }

     unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($ctrlIndex, $deviceIndex) = QuaTe_GetIndexFromDevice($deviceName);

    # check whether the indexes are found correctly
    unless(defined $ctrlIndex)
    {
        S_set_error( "! Device $deviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    unless ( %gSpiDevicesSetup4Inject && defined $gSpiDevicesSetup4Inject{$ctrlIndex} )
    {
        S_w2log( 4, "! QuaTe_SaveSPIMonitorData: QuaTe[$ctrlIndex] was not setup for this injection, by 'QuaTe_DownloadData' before ( $ERR_MSG_QT_MONITOR )\n" );
        if ( $monitorQuaTeAfterDownload ) { return 1; }
    }

    S_w2log(4, " QuaTe_SaveSPIMonitorData($deviceName [QUATE: $ctrlIndex  DEVICE: $deviceIndex], '$csvFile') \n");

    if ($main::opt_offline)
    {
       S_create_dummy_file($csvFile);
       return 1 ;
    }

    $status = qt_SaveSPIMonitorData( $ctrlIndex, $deviceIndex, $csvFile );
    check_status($status);
    S_w2log( 4, "Status of QuaTe_SaveSPIMonitorData : $status \n" );

    undef(%gSpiDevicesSetup4Inject); # reset to prepare for next use

    return 1;
}


=head2 QuaTe_SendControllerTrigger

I<B<Syntax : >>

    QuaTe_SendControllerTrigger( $QuateIndex [, $triggerLine] );

I<B<Arguments    : >>

    $QuateIndex     =   Index of the QuaTe to be triggered
    $triggerLine    =   (optional) trigger line index which is to be triggered

If the $triggerLine is not given, the QuaTe unit will trigger both trigger lines, by default (For CREIS purpose).

I<B<Description :>>

the controller (QuaTe-unit) generates a signal on trigger line 1 or 2 for I/O operation "start".
This influences all devices, which are configured to the corresponding trigger line (global trigger).

I<B<Return values :>>

    None

I<B<Examples :>>

    QuaTe_SendControllerTrigger(0 );     # trigger Quate 0 - Master Quate in CREIS
    QuaTe_SendControllerTrigger(1 , 1);  # trigger Quate 1 - 1st Trigger line

=cut

sub QuaTe_SendControllerTrigger
{
    my $QuateIndex = shift;
    my $trigline = shift;

    S_w2log( 4, " QuaTe_SendControllerTrigger (QuateIndex => $QuateIndex , TriggerLine => $trigline)\n");

    unless(defined $QuateIndex)
    {
        S_set_error( "! too less parameters ! SYNTAX :  QuaTe_SendControllerTrigger( \$QuateIndex [, \$triggerLine] );", 110 );
        return 0;
    }

    if (defined $trigline && $trigline !~ /^\d+$/)  #Trigger line should be a number
    {
        S_set_error("Trigger line '$trigline' is not a number", 114 );
        return 0;
    }

    #parameter range check
    if(defined $trigline && (($trigline < 1)||($trigline > 2)) )
    {
        S_set_error("trigline $trigline out of range (1<=x<=2)", 114 );
        return 0;
    }

    unless($QuateIndex =~ /^\d+$/)
    {
        S_set_error("Quate Index '$QuateIndex' is not a number", 114 );
        return 0;
    }

    $trigline = S_0x2dec($trigline)  if(defined $trigline);

    unless ( $QT_initialized ) {
        S_set_error( "QuaTe not initialized" , 120);
        return 0;
    }

    S_w2log( 4, " QuaTe_SendControllerTrigger: sending ControllerTrigger for controller $QuateIndex \n");

    return 1 if $main::opt_offline;

    unless(defined $trigline)
    {
        # trigger both lines
        foreach my $triggerLine(1..2) {
            $status = qt_SendControllerTrigger( $QuateIndex, $triggerLine );
            check_status($status);
            S_w2log( 3, "Status of QuaTe_SendControllerTrigger($QuateIndex, $triggerLine) : $status \n" );
        }
    }
    else
    {
        $status = qt_SendControllerTrigger( $QuateIndex, $trigline );
        check_status($status);
        S_w2log( 4, " QuaTe_SendControllerTrigger : ($QuateIndex, $trigline) => Status $status \n" );
    }

    #
    #  TODO: return undef / is it successful ? / error handling of check status
    #

    return;
}



=head2 QuaTe_SetChannelTriggerMode

I<B<Syntax : >>

    QuaTe_SetChannelTriggerMode( $DeviceName, $ChannelName, $TriggerType);

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults
    $ChannelName    =   channel of the device to which trigger should be set. can be 'ALL' to set trigger type to all channels of the device
    $TriggerType    =   Trigger Type to be set. can be 'OFF', 'TRIG_LINE1_NEG_SLOPE', 'TRIG_LINE2_NEG_SLOPE', 'TRIG_LINE2_POS_SLOPE'

I<B<Description :>>

enables the user to set the trigger behaviour of the different channels of a device.
Device cannot have TRIG_LINE1_POS_SLOPE Input trigger setting which is not supported by Quate low level driver.

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetChannelTriggerMode( 'SMA560', 'ALL', 'TRIG_LINE1_NEG_SLOPE');    #set trigger mode of all channels in device 'SMA560' to 'TRIG_LINE1_NEG_SLOPE'
   QuaTe_SetChannelTriggerMode( 'PASFP', 'X', 'TRIG_LINE1_NEG_SLOPE');         #set trigger mode of 0th channel in device 'PASFP' to 'TRIG_LINE1_NEG_SLOPE'

=cut

sub QuaTe_SetChannelTriggerMode
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $TriggerType = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex);

    S_w2log( 4, "QuaTe_SetDeviceTriggerMode\n");

    unless (defined($TriggerType))
    {
        S_set_error( "! too less parameters !  QuaTe_SetDeviceTriggerMode( DeviceName, ChannelNameOrIndex, TriggerType);", 110 );
        return 0;
    }

    #check valid device trigger type
    unless(exists $Device_Trigger_Mapping{$TriggerType})
    {
        S_set_error( "! Invalid TriggerType $TriggerType : valid values are 'OFF', 'TRIG_LINE1_NEG_SLOPE', 'TRIG_LINE2_NEG_SLOPE', 'TRIG_LINE2_POS_SLOPE'", 114 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    #special consideration for the parameter ALL
    if($ChannelName =~ /^ALL$/)
    {
        ($CtrlIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);
    }
    else
    {
        ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);
    }


    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel(s) $ChannelName is not found in ProjectDefaults configuration ", 20 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my @channels = ();

    #special consideration for the parameter ALL
    if($ChannelName =~ /^ALL$/)
    {
        my $ChannelCount = qt_GetNumberOfChannels($CtrlIndex, $DeviceIndex);
        check_status($ChannelCount);

        @channels = (0..($ChannelCount-1));
    }
    else
    {
        @channels = ($ChannelIndex);
    }

    foreach my $channel(@channels)
    {
        $status = qt_SetDeviceTriggerMode( $CtrlIndex, $DeviceIndex, $channel, $Device_Trigger_Mapping{$TriggerType}, 0 ); #output mode is always OFF (0), reference - Test Prog
        check_status($status);
        S_w2log( 4, "Status of QuaTe_SetDeviceTriggerMode ($CtrlIndex, $DeviceIndex, $channel, $TriggerType) : $status \n" );
    }

    return;
}


=head2 QuaTe_SetChipSelect

I<B<Syntax : >>

    QuaTe_SetChipSelect( $DeviceName, $ChipSelect, $Enable );

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults
    $ChipSelect     =   Chip select to be set to the given device
    $Enable         =   ENABLE or DISABLE (without quotes)

I<B<Description :>>

set chip select on QuaTe ($Enable = ENABLE set CS, DISABLE reset CS). 
Reads Controller Index, Device index from ProjectDefaults.

I<B<Return values :>>

    None

I<B<Examples :>>

    QuaTe_SetChipSelect( 'ECU_Acc_HG', 5, ENABLE );  # enable chip select 5 to the device 'ECU_Acc_HG'

            'QUATE_MAPPING' => {
                                    'YawRateSensor'   => '3',
                                    'PitchRateSensor' => '4',
                                    'RollRateSensor'  => '5',
                                    'LowGz'           => '6',
                                    'LowGxy'          => '7',
                                    'SPImonitor'      => '8',
                               },

            'SPI_SENSOR' => {
                                    'CS6' => 'AB+',
                                    'CS4' => 'SMB470',
                            },

=cut


sub QuaTe_SetChipSelect
{
    my $DeviceName = shift;
    my $ChipSelect = shift;
    my $Enable = shift; 

    my ($DeviceIndex,$CtrlIndex, $EnableString);

    unless (defined( $Enable )) {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SetChipSelect(DeviceName, ChipSelect, ENABLE_or_DISABLE)", 110 );
        return 0;
    }

    unless($Enable == ENABLE || $Enable == DISABLE)
    {
        S_set_error( "ENABLE_or_DISABLE shall be ENABLE (1) or DISABLE (0). ENABLE or DISABLE should be without quotes ", 109 );
        return 0;
    }
    else
    {
        $EnableString = 'ENABLE' if($Enable == ENABLE);
        $EnableString = 'DISABLE' if($Enable == DISABLE);
    }

    S_w2log( 3, "QuaTe_SetChipSelect (Device: $DeviceName, Chipselect: $ChipSelect, Enable: $Enable) \n");

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($CtrlIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    S_w2log( 4, "QuaTe_SetChipSelect : setting Chip select $ChipSelect for device $DeviceName ($DeviceIndex) on Quate $CtrlIndex to $EnableString\n");

    return 1 if $main::opt_offline;

    #validate the chipselect number according to the real Quate hardware
    my $CRTLcs = qt_GetNumberOfChipSelects( $CtrlIndex );
    if ( $ChipSelect > ($CRTLcs - 1) ) {
        S_set_error( "! Invalid chipselect number $ChipSelect. Quate$CtrlIndex supports only $CRTLcs chip selects. ", 114 );
        return 0;
    }

    $status = qt_SetChipSelect($CtrlIndex, $DeviceIndex, $ChipSelect, $Enable);
    check_status($status);
    S_w2log( 3, "Status of QuaTe_SetChipSelect(Quate: $CtrlIndex, Device: $DeviceIndex, Chipselect: $ChipSelect, Enable: $Enable) : $status \n" );

    return;
}


=head2 QuaTe_SetControllerTriggerMode

I<B<Syntax : >>

    QuaTe_SetControllerTriggerMode( $QuateIndex, $triggerLine1, $triggerLine2 );

I<B<Arguments    : >>

    $QuateIndex     =   Index of Quate for which the trigger to be set
    $triggerLine1   =   Trigger option for Trigger Line 1 (can be 'OFF', 'POS_SLOPE', 'NEG_SLOPE', 'EXT_TRIGGER')
    $triggerLine2   =   Trigger option for Trigger Line 2 (can be 'OFF', 'POS_SLOPE', 'NEG_SLOPE', 'EXT_TRIGGER')

I<B<Description :>>

sets the trigger behaviour of the selected QuaTe-unit, for both trigger lines

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetControllerTriggerMode( 0, 'POS_SLOPE', 'NEG_SLOPE' );  # 0th Quate , 1st Line = POS_SLOPE, 2nd Line = NEG_SLOPE

=cut

sub QuaTe_SetControllerTriggerMode
{

    my $QuateIndex = shift;
    my $triggerLine1 = shift;
    my $triggerLine2 = shift;

    my ($trig_value1, $trig_value2);

    unless (defined( $triggerLine2 ))
    {
        S_set_error( "! too less parameters ! SYNTAX : QuaTe_SetControllerTriggerMode( \$QuateIndex, \$triggerLine1, \$triggerLine2 )", 110 );
        return 0;
    }

    #check whether QuateIndex is a valid number
    unless($QuateIndex =~ /^\d+$/)
    {
        S_set_error( "Quate Index should be a Number. Ex: 0,1,2..." , 114) ;
        return;
    }

    #reading respective $trig value from %QuaTe_Trigger_Mapping
    $trig_value1 = $QuaTe_Trigger_Mapping{$triggerLine1};
    $trig_value2 = $QuaTe_Trigger_Mapping{$triggerLine2};

    unless(defined $trig_value1 && defined $trig_value2)
    {
        S_set_error( "Invalid Parameter passed for TriggerLine1 ! can be 'OFF', 'POS_SLOPE', 'NEG_SLOPE', 'EXT_TRIGGER'" , 114) unless(defined $trig_value1);
        S_set_error( "Invalid Parameter passed for TriggerLine2 ! can be 'OFF', 'POS_SLOPE', 'NEG_SLOPE', 'EXT_TRIGGER'" , 114) unless(defined $trig_value2);
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe not initialized" , 120);
        return 0;
    }

    S_w2log( 3, "QuaTe_SetControllerTriggerMode ($QuateIndex, $triggerLine1, $triggerLine2) \n");

    return 1 if ($main::opt_offline);

    $status = qt_SetControllerTriggerMode( $QuateIndex, $trig_value1, $trig_value2);
    check_status($status);
    S_w2log( 3, "Status of QuaTe_SetControllerTriggerMode : $status \n" );

    return;
}


=head2 QuaTe_SetDynamicData

I<B<Syntax : >>

    QuaTe_SetDynamicData( $DeviceName, $ChannelName, $data_aref, $DataFormat);

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults
    $ChannelName    =   channel of the device to which data should be set
    $data_aref      =   array of data values of type floating point to be set
    $DataFormat     =   'LIKE_INPUT' or 'LIKE_OUTPUT' (with quotes)

I<B<Description :>>

writes an array of data to the device channel's output buffer

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetDynamicData( 'SMA560', 'AccX', [(10)x42], 'LIKE_INPUT');    #set data for channel 'AccX' of device 'SMA560'
   QuaTe_SetDynamicData( 'PASFP', 'X', [1..1000], 'LIKE_OUTPUT');       #set data for channel 'X' of device 'PASFP'

=cut

sub QuaTe_SetDynamicData
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $data_aref = shift;
    my $DataFormat = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex, $count, $DataFormatNumber);

    S_w2log( 4, "QuaTe_SetDynamicData\n");

    unless (defined( $DataFormat )) {
        S_set_error( "! too less parameters ! QuaTe_SetDynamicData (\$DeviceName, \$ChannelName, \$data_aref, \$DataFormat) ", 110 );
        return 0;
    }

    if( ref($data_aref) ne "ARRAY" ){
        S_set_error( " data_aref is not an array reference", 114 );
        return 0;
    }
    if ( scalar(@$data_aref) < 1 ) {
        S_set_error( " QuaTe_SetDynamicData : data_aref is empty", 114 );
        return 0;
    }

   unless($DataFormat =~ /^LIKE_INPUT$/i || $DataFormat =~ /^LIKE_OUTPUT$/i) {
        S_set_error( "! Invalid data format : $DataFormat . Should be 'LIKE_INPUT' or 'LIKE_OUTPUT' ", 114 );
        return 0;
    }

    #assign numeric for data format (according to Quate low level Driver, OUTPUT = 0, INPUT = 1)
    $DataFormatNumber = 0 if($DataFormat =~ /^LIKE_OUTPUT$/i);
    $DataFormatNumber = 1 if($DataFormat =~ /^LIKE_INPUT$/i);

    unless ( $QT_initialized ) {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 114 );
        return 0;
    }

    S_w2log( 4, "QuaTe_SetDynamicData : setting DynamicData for CH$ChannelIndex of device $DeviceIndex ($DeviceName) on controller $CtrlIndex format $DataFormat ($DataFormatNumber) \n");

    return 1 if $main::opt_offline;

    $status = qt_SetDynamicData( $CtrlIndex, $DeviceIndex, $ChannelIndex, $data_aref, $DataFormatNumber );
    check_status($status);
    S_w2log( 4, "Status of QuaTe_SetDynamicData : $status \n" );

    return;
}

=head2 QuaTe_SetOverloadChannel

I<B<Syntax : >>

    QuaTe_SetOverloadChannel($devicename, $channelname, $option[, $numPtsSensor, $cycleTimeSensor_us,
                          $numPtsOvlSig, $cycleTimeOvlSig_us, $overloadsignal_aref, $startTime_ms, $endTime_ms]);

I<B<Arguments    : >>

    $devicename:             The device name as configured in ProjectDefaults
    $channelname:            The channel name as configured in ProjectDefaults
    $option = "DISABLE_ALL": Disables the overload function of all QuaTes, SMI700/SMI8xx-Devices and Channels
                             (no further option required, devicename and channelname are ignored)
            = "DISABLE":     Disable the overload function of specified SMI700/SMI8xx-Device and Channel
                             (no further option required)
            = "PERMANENT":   Required options are:
                             $numPtsSensor, $cycleTimeSensor_us
            = "START2END":   Required options are:
                             $numPtsSensor, $cycleTimeSensor_us, -1, -1, [], $startTime_ms, $endTime_ms
            = "DBSIGNAL":    Required options are:
                             $numPtsSensor, $cycleTimeSensor_us, $numPtsOvlSig, $cycleTimeOvlSig_us,
                             $overloadsignal_aref 
    $numPtsSensor, 
    $cycleTimeSensor_us:     OPTIONS Number of points and cycle time of *SENSOR* signal to which the *OVERLOAD*
                             signal has to be attached.
                             These two inputs are required, because the *OVERLOAD* signal has to be configured
                             to same number of points and same cycle time as corresponding *SENSOR* signal, which
                             is defined by deviceName and channelName.
    $numPtsOvlSig,
    $cycleTimeOvlSig_us:     OPTIONS Number of points and cycle time of *OVERLOAD* signal.
    $overloadsignal_aref:    OPTION Overload Signal
    $startTime_ms:           OPTION start time, when overload is enabled
    $endTime_ms:             OPTION end time, when overload is disabled again

I<B<Description :>>

Configures and downloads the overload signal to QuaTe.
Supported for SMI700 and SMI8xx families.
This overload signal will be activated for the corresponding dynamic signal via QuaTe_DownloadData (QuaTe_SetDynamicData)
and QuaTe_SendControllerTrigger.

IMPORTANT: Order of functions calls has to be:

    1. QuaTe_SetOverloadChannel
    2. QuaTe_SetDynamicData
    3. QuaTe_SendControllerTrigger


I<B<Return values :>>

    None

I<B<Examples :>>

    QuaTe_SetOverloadChannel("", "", "DISABLE_ALL");
    QuaTe_SetOverloadChannel("SMI700", "ECU: Acc_LG: -Y: SMI7x0_sync_axay_6_5g_73Hz", "DISABLE");
    QuaTe_SetOverloadChannel("SMI700", "ECU: Angular_Rate: -X: SMI710_sync_wxwy_300grads_77Hz", "PERMANENT",
                              1000, 100.0);
    QuaTe_SetOverloadChannel("SMI700", "ECU: Angular_Rate: -X: SMI710_sync_wxwy_300grads_77Hz", "START2END",
                              1000, 100.0, -1, -1, [], 2.0, 4.0);
    QuaTe_SetOverloadChannel("SMI700", "ECU: Angular_Rate: -X: SMI710_sync_wxwy_300grads_77Hz", "DBSIGNAL",
                              1000, 100.0, 1200, 120, \@overloadSignal);
    QuaTe_SetOverloadChannel("SMI8xx", "SMI8xx_CH_0", "PERMANENT", 1000, 100.0);

=cut

sub QuaTe_SetOverloadChannel
{
    my $deviceName = shift;
    my $channelName = shift;
    my $option = shift;
    my $numPtsSensor = shift;        # optional
    my $cycleTimeSensor_us = shift;  # optional
    my $numPtsOvlSig = shift;        # optional
    my $cycleTimeOvlSig_us = shift;  # optional 
    my $overloadsignal_aref = shift; # optional
    my $startTime_ms = shift;        # optional
    my $endTime_ms = shift;          # optional

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    # Check for minimum required input parameters ($devicename, $channelname, $option)
    unless ( defined $option )
    {
        S_set_error( "! too less parameters ! QuaTe_SetOverloadChannel(\$deviceName, \$channelName, \$option);", 110 );
        return 0;
    }

    if ( $option =~ /^DISABLE_ALL$/ )
    {
        QuaTe_OverloadOff();
    }

    elsif ( $option =~ /^DISABLE$/ )
    {
        QuaTe_UpdateOverloadConfigRegister($deviceName, $channelName, 0); # 0: disable overload
        QuaTe_SetParameter($deviceName, $channelName, 'OVERLOAD_CLEAR', [0]);
    }

    elsif  ( $option =~ /^PERMANENT$/ )
    {
        # Check for optional input parameters
        unless ( defined $numPtsSensor && defined $cycleTimeSensor_us )
        {
            S_set_error( "! too less parameters ! QuaTe_SetOverloadChannel(\$deviceName, \$channelName, \$option, \$numPtsSensor, \$cycleTimeSensor_us);", 110 );
            return 0;
        }

        my @overloadSignal;

        # Get number of points after QuaTe re-sampling of sensor signal
        my ($outSize, $outTime_us);
        ($status, $outSize, $outTime_us) = qt_GetResampleFIFOSize($numPtsSensor, $cycleTimeSensor_us);
        S_w2log( 4, " Get resampling data of sensor signal: InSize=$numPtsSensor, InTime_us=$cycleTimeSensor_us => outSize: $outSize, outTime_us: $outTime_us us\n");

        # Allocate overload signal of same size and assign all its values to 1                
        S_w2log( 4, " Make PERMANENT overload signal=1 with same outSize=$outSize of sensor\n");
        @overloadSignal = (1.0) x $outSize;

        # Enable overload for this channel
        QuaTe_UpdateOverloadConfigRegister($deviceName, $channelName, 1); # 

        # Download overloadSignal to QuaTe
        my $overLoadChStr = QuaTe_overLoadChStrByChName($deviceName, $channelName);
        if ( defined $overLoadChStr )
        {
            QuaTe_SetParameter($deviceName, $channelName, $overLoadChStr, \@overloadSignal);
        }
    }

    elsif  ( $option =~ /^START2END$/ )
    {
        # Check for optional input parameters
        unless ( defined $numPtsSensor && defined $cycleTimeSensor_us && defined $startTime_ms && defined $endTime_ms )
        {
            S_set_error( "! too less parameters ! QuaTe_SetOverloadChannel(\$deviceName, \$channelName, \$option, \$numPtsSensor, \$cycleTimeSensor_us, -1, -1, [], \$startTime_ms, \$endTime_ms);", 110 );
            return 0;
        }

        my @overloadSignal;

        # Get number of points after QuaTe re-sampling of sensor signal 
        my ($outSize, $outTime_us);
        ($status, $outSize, $outTime_us) = qt_GetResampleFIFOSize($numPtsSensor, $cycleTimeSensor_us);
        S_w2log( 4, " Get resampling data of sensor signal: InSize=$numPtsSensor, InTime_us=$cycleTimeSensor_us => outSize: $outSize, outTime_us: $outTime_us us\n");

        # Build the overload signal by known parameters ($numPtsSensor->$OutSize, $cycleTimeSensor_us->$OutTime_us, $startTime_ms, $endTime_ms)
        S_w2log( 4, " Make START2END overload signal pulse=1, based on sensor outSize=$outSize, outTime_us: $outTime_us and pulse startTime_ms=$startTime_ms, endTime_ms=$endTime_ms\n");
        my $startIndex = int($startTime_ms / $outTime_us * 1000.0 + 0.5);
        my $endIndex = int($endTime_ms / $outTime_us * 1000.0 + 0.5);

        # Allocate overload signal of same size containing 1-pulse between start and end
        @overloadSignal = (0.0) x $outSize; # First set all its values to 0
        @overloadSignal[$startIndex .. $endIndex] = (1.0) x ($endIndex - $startIndex + 1); # Then set values between start and end to 1

        # Update Overload Config Register
        QuaTe_UpdateOverloadConfigRegister($deviceName, $channelName, 1); # 1: enable overload

        # Download overloadSignal to QuaTe
        my $overLoadChStr = QuaTe_overLoadChStrByChName($deviceName, $channelName);
        if ( defined $overLoadChStr )
        {
            QuaTe_SetParameter($deviceName, $channelName, $overLoadChStr, \@overloadSignal);
        }
    }

    elsif  ( $option =~ /^DBSIGNAL$/ )
    {
        # Check for optional input parameters
        unless ( defined $numPtsSensor && defined $cycleTimeSensor_us && defined $numPtsOvlSig && defined $cycleTimeOvlSig_us && defined $overloadsignal_aref )
        {
            S_set_error( "! too less parameters ! QuaTe_SetOverloadChannel(\$deviceName, \$channelName, \$option, \$numPtsSensor, \$cycleTimeSensor_us, \$numPtsOvlSig, \$cycleTimeOvlSig_us, \$overloadsignal_aref);", 110 );
            return 0;
        }

        my $outData_ref;

        # Get number of points and cycle time after QuaTe re-sampling of *SENSOR* signal 
        my ($outSize, $outTime_us);
        ($status, $outSize, $outTime_us) = qt_GetResampleFIFOSize($numPtsSensor, $cycleTimeSensor_us);
        S_w2log( 4, " Get resampling data of sensor signal: InSize=$numPtsSensor, InTime_us=$cycleTimeSensor_us => outSize: $outSize, outTime_us: $outTime_us us\n");

        # Resample overload signal to same $OutSize and $OutTime_us as to be done for crash signal
        S_w2log( 4, " Make overload signal from given 'DBSIGNAL', by re-sampling it to fit to sensor signal: InSize=$numPtsOvlSig, InTime_us=$cycleTimeOvlSig_us => outSize: $outSize, outTime_us: $outTime_us us\n");
		$outData_ref = QuaTe_resample($overloadsignal_aref, $numPtsOvlSig, $cycleTimeOvlSig_us, $outSize, $outTime_us, 1); #1 = interpolation mode

         # Update Overload Config Register
        QuaTe_UpdateOverloadConfigRegister($deviceName, $channelName, 1); # 1: enable overload

        # Download overloadSignal to QuaTe
        my $overLoadChStr = QuaTe_overLoadChStrByChName($deviceName, $channelName);
        if ( defined $overLoadChStr )
        {
            QuaTe_SetParameter($deviceName, $channelName, $overLoadChStr, $outData_ref);
        }
    }
    else
    {
        my $errTxt = sprintf("%s: Option '%s' is invalid (use only: DISABLE | PERMANENT | START2END | DBSIGNAL)", (caller(0))[3], $option);
        S_set_error( $errTxt, 114 ); # 114 = "invalid parameters"
        return 0;
    }
    return 1;
}

=head2 QuaTe_SetParameter

I<B<Syntax : >>

    QuaTe_SetParameter($DeviceName, $ChannelName, $ParamName, $Param_aref);

I<B<Arguments    : >>

    $DeviceName     =   The Device name as configured in ProjectDefaults
    $ChannelName    =   The channel name as configured in ProjectDefaults
    $ParamName      =   Param name to which the value to be retrieved
    $Param_aref     =   values to be set for the given $ParamName

I<B<Description :>>

Set the Quate parameter for particular channel of a Sensor (i.e., Device)

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetParameter('ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC', 'FSR_MONITOR', [0x01, 0x02]);    # set FSR_MONITOR param values

=cut

sub QuaTe_SetParameter
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $ParamName = shift;
    my $Param_aref = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex);
    my $paraArrayLen;

    S_w2log( 2, "QuaTe_SetParameter: Device => $DeviceName ChannelName => $ChannelName ParamName => $ParamName \n");

    unless (defined( $Param_aref ))
    {
        S_set_error( "! too less parameters ! QuaTe_SetParameter(\$DeviceName, \$ChannelName, \$ParamName, \$Param_aref);", 110 );
        return;
    }

    if( ref($Param_aref) ne "ARRAY" )
    {
        S_set_error( " QuaTe_SetParameter: \$Param_aref is not an array reference", 114 );
        return;
    }

    $paraArrayLen = scalar(@$Param_aref);

    # check whether values array contain some values
    if ( $paraArrayLen < 1 ) {
        S_set_error( " \$Param_aref is empty", 114 );
        return;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return;
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return;
    }

    # convert data to dec if required
    for (my $count=0; $count < $paraArrayLen;$count++)
    {
        @$Param_aref[$count] = S_0x2dec(@$Param_aref[$count]);
    }

    # Check and limit logging text
    my $logLimitLen = 200;
    my @paramArray4Log = @$Param_aref; # Create a copy for logging only, which is maybe cut below and keep original buffer untouched
    my $postString = "";

    if ( $paraArrayLen > $logLimitLen - 1 )
    {
        $postString = "...";
        @paramArray4Log = @$Param_aref[0 .. $logLimitLen - 1]; # Cut paramArray4Log at limit
    }

    my $preString;
    $preString = sprintf("param[0] = 0x%04X = 0b%.16b | param[0...%d | log-max. %d]", $$Param_aref[0], $$Param_aref[0], $paraArrayLen - 1, $logLimitLen);
    S_w2log( 4, " QuaTe_SetParameter: used parameter ($DeviceName [QUATE: $CtrlIndex  DEVICE: $DeviceIndex], $ChannelName [CHANNEL: $ChannelIndex], Parameter Keyword = $ParamName, $preString = \[@paramArray4Log $postString ])\n");

    return 1 if $main::opt_offline;

    $status = qt_SetParameter($CtrlIndex,$DeviceIndex,$ChannelIndex,$ParamName,$Param_aref);
    check_status($status);
    S_w2log( 4, " QuaTe_SetParameter : qt_SetParameter => Status => $status \n" );
    
    #
    #  TODO: return undef / is it successful ? / error handling of check status
    #

    return;
}


=head2 QuaTe_SetSensorConfiguration

I<B<Syntax : >>

    QuaTe_SetSensorConfiguration($DeviceName, $fileName);

I<B<Arguments    : >>

    $DeviceName          =   device name as defined in ProjectDefaults
    $fileName            =   File name (or) path from which the sensor (device) is to be configured (.cfg or .rom file)
                             if ROM file 'name' is given , the file will be checked in Project\Config\Tools\Quate\

I<B<Description :>>

loads the configuration file for specifying the sensor more precisely.

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetSensorConfiguration('ECU_Acc_HG', 'SMB225_LowGxy_no1_v2.rom');                                          # only file name
   QuaTe_SetSensorConfiguration('ECU_Acc_HG', 'D:\MKS\TurboLIFT\AB12\Config\Tools\QuaTe\SMB225_LowGxy_no1_v2.rom'); # file path

=cut


sub QuaTe_SetSensorConfiguration
{
    my $DeviceName = shift;
    my $fileName = shift;

    my $filePath = "$LIFT_config::LIFT_PRJCFG_path/Tools/Quate/";
    $filePath  = "$filePath$fileName";
    S_w2log( 4, "ROM file path is $filePath\n");

    unless (defined $fileName)
    {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SetSensorConfiguration( Devicename , FileName)", 110 );
        return 0;
    }

    my $ActualROMFile ;

    if ( -f $filePath || -f $fileName)
    {
        $ActualROMFile = $filePath if(-f $filePath);
        $ActualROMFile = $fileName if(-f $fileName);
    }
    else
    {
        S_set_error( "ROM file '$fileName' not found on Disk", 1 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    my ($CtrlIndex, $DeviceIndex) = QuaTe_GetIndexFromDevice($DeviceName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    S_w2log( 3, " QuaTe_SetSensorConfiguration($DeviceName, $fileName) \n" );

    return 1 if ($main::opt_offline);

    my $DeviceType = qt_GetDeviceType( $CtrlIndex, $DeviceIndex );
    check_status($DeviceType);

    if(exists $DeviceTypes{$DeviceType})
    {
        my ($DeviceDescription, $DeviceVersion);

        S_w2log( 3, "Device type of Quate $CtrlIndex -> Device $DeviceIndex : $DeviceTypes{$DeviceType} ($DeviceType) \n" );

        ($status, $DeviceDescription) = qt_GetDeviceDescription( $CtrlIndex, $DeviceIndex );
        check_status($status);
        $DeviceVersion = qt_GetDeviceVersion( $CtrlIndex, $DeviceIndex );
        $DeviceVersion = 'not defined' unless(defined $DeviceVersion);

        S_w2log( 3, "Device is : $DeviceDescription , Version : $DeviceVersion\n" );

        # DEVICE_TYPE_SPI, DEVICE_TYPE_PSI_AND_SPI, DEVICE_TYPE_MM5 = qt_SetSensorConfiguration
        # DEVICE_TYPE_ABPLUS_DEVICE                                 = qt_SetABPlusConfiguration
        # DEVICE_TYPE_PSI                                           = qt_SetPSIConfiguration

        if($DeviceType == DEVICE_TYPE_SPI || $DeviceType == DEVICE_TYPE_PSI_AND_SPI || $DeviceType == DEVICE_TYPE_MM5)
        {
            $status = qt_SetSensorConfiguration( $CtrlIndex, $DeviceIndex, $ActualROMFile);
            S_w2log( 3, "status of qt_SetSensorConfiguration : $status \n" );
        }
        elsif($DeviceType == DEVICE_TYPE_ABPLUS_DEVICE)
        {
            $status = qt_SetABPlusConfiguration( $CtrlIndex, $DeviceIndex, $ActualROMFile);
            S_w2log( 3, "status of qt_SetABPlusConfiguration : $status \n" );
        }
        elsif($DeviceType == DEVICE_TYPE_PSI)
        {
            $status = qt_SetPSIConfiguration( $CtrlIndex, $DeviceIndex, $ActualROMFile);
            S_w2log( 3, "status of qt_SetPSIConfiguration : $status \n" );
        }
        else
        {
            S_set_error( "Devices of type $DeviceTypes{$DeviceType} ($DeviceType) does not support updating ROM file " , 120);
            return 0;
        }

        check_status($status);
        $status = S_add_file_to_snapshot($ActualROMFile);
    }
    else
    {
        S_set_error( "Unknown device type $status found on Quate $CtrlIndex => Device $DeviceIndex " , 20);
        return 0;
    }

    return;
}


=head2 QuaTe_SetSID

I<B<Syntax : >>

    QuaTe_SetSID( $DeviceName, $ChannelName, $SID);

I<B<Arguments    : >>

    $DeviceName     =   Device name as mentioned in ProjectDefaults
    $ChannelName    =   Channel name of the device to which SID to be set
    $SID            =   SID to be set

I<B<Description :>>

Sets the given SID to the channel of given device (i.e., Sensor)

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetSID( 'SMA560', 'AccX', 5);

B<Note (from Testprog):>
  
  SID is only required for sensors with HW-wired SIDs:
       SMB250/260: 4,5,6        
       MM2R/2S: 3  

  Others are SW-controlled via �C and not adjustable in sensor/QuaTe.

=cut


sub QuaTe_SetSID
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $SID = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex);

    unless (defined( $SID )) {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SetChipSelect(DeviceName, ChannelName, SID)", 110 );
        return 0;
    }

    unless($SID =~ /^\d+/)
    {
        S_set_error( "Invalid SID $SID provided. SID should be a number (0,1,2..)", 114 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults configuration ", 20 );
        return 0;
    }

    S_w2log( 3, "QuaTe_SetSID ($DeviceName, $ChannelName, $SID) \n");

    return 1 if $main::opt_offline;

    my $DeviceType = qt_GetDeviceType( $CtrlIndex, $DeviceIndex );
    check_status($DeviceType);

    if(exists $DeviceTypes{$DeviceType})
    {
        my ($DeviceDescription, $DeviceVersion);

        S_w2log( 3, "Device type of Quate $CtrlIndex -> Device $DeviceIndex : $DeviceTypes{$DeviceType} ($DeviceType) \n" );

        ($status, $DeviceDescription) = qt_GetDeviceDescription( $CtrlIndex, $DeviceIndex );
        check_status($status);
        $DeviceVersion = qt_GetDeviceVersion( $CtrlIndex, $DeviceIndex );
        $DeviceVersion = 'not defined' unless(defined $DeviceVersion);

        S_w2log( 3, "Device is : $DeviceDescription , Version : $DeviceVersion\n" );

        #only DEVICE_TYPE_ABPLUS_DEVICE, DEVICE_TYPE_SPI needs SID setting
        if($DeviceType == DEVICE_TYPE_ABPLUS_DEVICE || $DeviceType == DEVICE_TYPE_SPI)
        {
            $status = qt_SetSID($CtrlIndex, $DeviceIndex, $ChannelIndex, $SID);
            check_status($status);
            S_w2log( 3, "Status of QuaTe_SetSID (Quate: $CtrlIndex, Device: $DeviceIndex, Channel: $ChannelIndex, SID: $SID) : $status \n" );
        }
        else
        {
            S_set_error("Device type of $DeviceTypes{$DeviceType} ($DeviceType) does not require SID setting ", 0 );
        }

    }
    else
    {
        S_set_error( "Unknown device type $status found on Quate $CtrlIndex => Device $DeviceIndex " , 120);
        return 0;
    }

    return;
}


=head2 QuaTe_SetPSIMonitorMode

I<B<Syntax : >>

    QuaTe_SetPSIMonitorMode($deviceName, $enable, $filterBusy, $filterPort_aref[, $monitorDevicesAfterDownload]);

I<B<Arguments    : >>

    $deviceName       =   The Device name of PSI monitor as configured in ProjectDefaults
    $enable           =   enable flag for the monitor function : ENABLE or DISABLE (without quotes)
    $filterBusy       =   to monitor only during crash output (busy signal active) :
                                                    0 (monitor all) | 1 (monitor if busy active)
    $filterPort_aref  =   filter for the Ports, which are monitored
    $monitorDevicesAfterDownload (optional flag)
      = 0: is ignored
      = 1: Only save QuaTe monitor, if any of its devices were filled by 'QuaTe_DownloadData' before.
           This option is only useful, if called in this sequence:
            1. QuaTe_DownloadData                -> sets flags for used QuaTes/devices
            2. QuaTe_SetPSIMonitorMode (ENABLE)  -> if device flag not set: warns & skips devices
            3. QuaTe_SetControllerTriggerMode
            4. QuaTe_SetPSIMonitorMode (DISABLE) -> if device flag not set: warns & skips devices
            5. QuaTe_SavePSIMonitorData          -> if QuaTe-No flag not set: warns & skips QuaTe
                                                    saves monitor, resets flags for next download

I<B<Description :>>

set PSI monitoring mode for a group of devices which are passed as array reference.

I<B<Return values :>>

    None

I<B<Examples :>>

    # monitor ports of 'PAS6','PAS6_2','PPS3'
    QuaTe_SetPSIMonitorMode('PSIMonitor', ENABLE, 1, ['PAS6','PAS6_2','PPS3']);

    # monitor all devices
    QuaTe_SetPSIMonitorMode('PSIMonitor', ENABLE, 1, ['ALL']); # see warning below

    # Known issue with 'ALL':
    # Unfortunately in some cases QuaTe DLL will report 'No data to save! (-1936)' for the
    # sensors, which are not used, so this should be pre-filtered here, in order to set
    # only the filter flags for the available sensors (planned in ALM story 23729).
    # Therefore, if you get this error, please configure the sensors individually by name,
    # as in 1st example above.

=cut

sub QuaTe_SetPSIMonitorMode
{
    my $deviceName = shift;
    my $enable = shift;
    my $filterBusy = shift;
    my $filterPort_aref = shift;
    my $monitorDevicesAfterDownload = shift; # optional

    my $portMode = 0;
    my $raw = 0;
    my $filterPort;
    my $enableString;

    S_w2log( 4, "QuaTe_SetPSIMonitorMode\n");

    unless (defined( $filterPort_aref ))
    {
        S_set_error( '! too less parameters ! QuaTe_SetPSIMonitorMode($deviceName, $enable, $filterBusy, $filterPort_aref); ', 110 );
        return 0;
    }

    # check whether $filterPort_aref is array reference
    if( ref($filterPort_aref) ne "ARRAY" )
    {
        S_set_error( " Invalid Parameter ! QuaTe_SetPSIMonitorMode : filterPort_aref is not an array reference", 114 );
        return 0;
    }

    # check whether Device list is empty
    if( scalar(@$filterPort_aref) <= 0 )
    {
        S_set_error( " Invalid Parameter ! QuaTe_SetPSIMonitorMode : filterPort_aref is empty", 114 );
        return 0;
    }

    # verify $Enable parameter
    if ( $enable != ENABLE && $enable != DISABLE )
    {
        S_set_error( "Invalid \$enable input: $enable. \$enable shall be ENABLE (1) or DISABLE (0). ENABLE or DISABLE should be without quotes ", 109 );
        return 0;
    }
    else
    {
        $enableString = 'ENABLE' if ( $enable == ENABLE );
        $enableString = 'DISABLE' if ( $enable == DISABLE );
    }

    my ($ctrlIndexPsiMonitor, $deviceIndexPsiMonitor) = QuaTe_GetIndexFromDevice($deviceName);

    foreach my $dev (@$filterPort_aref)
    {
        if( $dev =~ /ALL/i )
        {
            $filterPort = 0xFFFF;
            last;
        }
        unless (exists $Device_hash{$dev})
        {
            S_set_error( "'$Device_hash{$dev}' of Device $dev not found in ProjectDefaults->{'QUATE'}" , 20);
            return 0;
        }
        unless ( exists $gPsiDevicesSetup4Inject{$dev} )
        {
            S_w2log( 4, "! QuaTe_SetPSIMonitorMode: Device '$dev' was not setup for injection before, by 'QuaTe_DownloadData' before ( $ERR_MSG_QT_MONITOR )\n" );
            if ( $monitorDevicesAfterDownload ) { next; } # skip this device and continue with next
        }
        my ($ctrlIndex, $deviceIndex) = QuaTe_GetIndexFromDevice($dev);

        # filter for port number is defined as front panel channel number of PAS connectors, counted from left to right, starting with zero
        my $frontPanelChNo = -1; # set invalid
        my $iPas = 0;
        my $numDevices = qt_GetNumberOfDevices($ctrlIndex);
        for ( my $iDev = 0; $iDev < $numDevices; $iDev++)
        {
            my $iDevType = qt_GetDeviceType($ctrlIndex, $iDev);
            if ( $iDevType == DEVICE_TYPE_PSI )
            {
                $frontPanelChNo = $iPas;
                $iPas++;
            }
            if ( $deviceIndex == $iDev )
            {
                last; # Leave loop, device reached
            }
        }
        if ( $frontPanelChNo < 0 )
        {
            S_set_error( "Device $dev is not a PSI device" , 114);
            return 0;
        }
        $filterPort |= 1 << $frontPanelChNo;
    }

    S_w2log( 4, "QuaTe_SetPSIMonitorMode ($deviceName [QUATE: $ctrlIndexPsiMonitor  DEVICE: $deviceIndexPsiMonitor], $enableString, filterBusy: $filterBusy, filterPort: $filterPort 0b". S_dec2bin($filterPort) . " )\n");

    return 1 if $main::opt_offline;

    $status = qt_SetPSIMonitorMode($ctrlIndexPsiMonitor, $deviceIndexPsiMonitor, $enable, $filterBusy, $filterPort, $portMode, $raw);
    check_status($status);
    S_w2log( 4, "Status of QuaTe_SetPSIMonitorMode : $status \n" );

    return 1;
}

=head2 QuaTe_SetSPIMonitorMode

I<B<Syntax : >>

    QuaTe_SetSPIMonitorMode($deviceName, $enable, $misoExt, $filterBusy , $filterDevice_aref[, $monitorDevicesAfterDownload]);

I<B<Arguments    : >>

    $deviceName     =   The Device name of SPI monitor as configured in ProjectDefaults
    $enable         =   the enable signal for the monitor function : ENABLE or DISABLE (without quotes)
    $misoExt        =   the parameter to switch between internal and external SPI-monitoring
                          0 : Internal MISO data (CREIS Application)
                          1 : external MISO data (Real Sensor Application)
    $filterBusy     =   to monitor only during crash output (busy signal active)
                                                    0 (monitor all) | 1 (monitor if busy active)
    $filterDevice_aref  =   filter for the Devices which are monitored
    $monitorDevicesAfterDownload (optional flag)
      = 0: is ignored
      = 1: Only save QuaTe monitor, if any of its devices
           were filled by 'QuaTe_DownloadData' before.
           This option is only useful, if called in this sequence:
            1. QuaTe_DownloadData                -> sets flags for used QuaTes/devices
            2. QuaTe_SetSPIMonitorMode (ENABLE)  -> if device flag not set: warns & skips devices
            3. QuaTe_SetControllerTriggerMode
            4. QuaTe_SetSPIMonitorMode (DISABLE) -> if device flag not set: warns & skips devices
            5. QuaTe_SaveSPIMonitorData          -> if QuaTe-No flag not set: warns & skips QuaTe
                                                    saves monitor, resets flags for next download

I<B<Description :>>

set SPI monitoring mode for a group of devices which are passed as array reference.

I<B<Return values :>>

    None

I<B<Examples :>>

    # monitor chip selects of 'SMA660','SMI700','SMI710'
    QuaTe_SetSPIMonitorMode('SPImonitor', ENABLE, 0, 1, ['SMA660','SMI700','SMI710']);

    # monitor all devices
    QuaTe_SetSPIMonitorMode('SPImonitor', ENABLE, 0, 1, ['ALL']); # see warning below

    # Known issue with 'ALL':
    # Unfortunately in some cases QuaTe DLL will report 'No data to save! (-1936)' for the
    # sensors, which are not used, so this should be pre-filtered here, in order to set
    # only the filter flags for the available sensors (planned in ALM story 23729).
    # Therefore, if you get this error, please configure the sensors individually by name,
    # as in 1st example above.

=cut

sub QuaTe_SetSPIMonitorMode
{
    my $deviceName = shift;
    my $enable = shift;
    my $misoExt = shift;
    my $filterBusy = shift;
    my $filterDevice_aref = shift;
    my $monitorDevicesAfterDownload = shift; # optional

    my ($ctrlIndex, $deviceIndex, $enableString, $filterCS);
    $filterCS=0;

    S_w2log( 4, "QuaTe_SetSPIMonitorMode\n");

    unless (defined( $filterDevice_aref ))
    {
        S_set_error( '! too less parameters ! QuaTe_SetSPIMonitorMode($deviceName, $enable, $misoExt, $filterBusy , $filterDevice_aref); ', 110 );
        return 0;
    }

    # check whether $FilterDevice_aref is array reference
    if(ref($filterDevice_aref) ne "ARRAY" )
    {
        S_set_error( " Invalid Parameter ! QuaTe_SetSPIMonitorMode : filterDevice_aref is not an array reference", 114 );
        return 0;
    }

    # check whether Device list is empty
    if(scalar(@$filterDevice_aref) <= 0 )
    {
        S_set_error( " Invalid Parameter ! QuaTe_SetSPIMonitorMode : filterDevice_aref is empty", 114 );
        return 0;
    }

    # verify $Enable parameter
    if ( $enable != ENABLE && $enable != DISABLE )
    {
        S_set_error( "Invalid \$enable input: $enable. \$enable shall be ENABLE (1) or DISABLE (0). ENABLE or DISABLE should be without quotes ", 109 );
        return 0;
    }
    else
    {
        $enableString = 'ENABLE' if($enable == ENABLE);
        $enableString = 'DISABLE' if($enable == DISABLE);
    }

    # validate $MISOext parameter
    unless ($misoExt =~ /^\d+$/ && (($misoExt == 0) || ($misoExt == 1)))
    {
        S_set_error("Invalid misoExt $misoExt. misoExt shall be 0 (or) 1", 114 );
        return 0;
    }

    # verify $FilterBusy parameter
    unless ($filterBusy =~ /^\d+$/ && (($filterBusy == 0)||($filterBusy == 1)))
    {
        S_set_error("Invalid filterBusy $filterBusy. filterBusy shall be 0 (or) 1", 114 );
        return 0;

    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    ($ctrlIndex, $deviceIndex) = QuaTe_GetIndexFromDevice($deviceName);

    # check whether the indexes are found correctly
    unless(defined $ctrlIndex)
    {
        S_set_error( "! Device $deviceName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return 0;
    }

    if( @$filterDevice_aref[0] =~ /ALL/i )
    {
        $filterCS = 0xFFFF;
    }
    else
    {
        # fetch the chip select of sensors $FilterDevice_aref from Project Defaults
        my @filterCS_array = ();
        foreach my $dev (@$filterDevice_aref)
        {
            unless ( exists $gSpiDevicesSetup4Inject{$dev} )
            {
                S_w2log( 4, "! QuaTe_SetSPIMonitorMode: Device '$dev' was not setup for injection before, by 'QuaTe_DownloadData' before ( $ERR_MSG_QT_MONITOR )\n" );
                if ( $monitorDevicesAfterDownload ) { next; } # skip this device and continue with next
            }
            unless (exists $Device_hash{$dev}{'CHIP_SELECT'})
            {
                S_set_error( "'CHIP_SELECT' of Device $dev not found in ProjectDefaults->{'QUATE'}" , 20);
                return 0;
            }
            push (@filterCS_array , $Device_hash{$dev}{'CHIP_SELECT'});
        }
    
        # check for repeated elements in the @FilterCS_array 
        my %seen = ();
        @filterCS_array = grep{!$seen{$_}++} @filterCS_array;
    
        # determine FilterCS value from array of chip selects
        foreach my $cs (@filterCS_array)
        {
            $filterCS |= 1 << $cs;
        }
    }

    S_w2log( 4, "QuaTe_SetSPIMonitorMode ($deviceName [QUATE: $ctrlIndex  DEVICE: $deviceIndex], $enableString, misoExt: $misoExt, filterBusy: $filterBusy, filterCS: ". S_dec2bin($filterCS) . " )\n");

    return 1 if $main::opt_offline;

    $status = qt_SetSPIMonitorMode($ctrlIndex, $deviceIndex, $enable, $misoExt, $filterBusy, $filterCS);
    check_status($status);
    S_w2log( 4, "Status of QuaTe_SetSPIMonitorMode : $status \n" );

    return 1;
}

=head2 QuaTe_SetStaticData

I<B<Syntax : >>

    QuaTe_SetStaticData($DeviceName, $ChannelName, $Data, $DataFormat);

I<B<Arguments    : >>

    $DeviceName     =   The Device name as configured in ProjectDefaults
    $ChannelName    =   The channel name as configured in ProjectDefaults
    $Data           =   a data signal value to be set for the sensor channel
    $DataFormat     =   Data format of the signal ('LIKE_INPUT' (or) 'LIKE_OUTPUT') 

I<B<Description :>>

returns the current value of particular channel of a Sensor (i.e., Device)

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetStaticData('ECU_Acc_HG', 'ECU: Acc_HG: -X: SMA560_SYNC', 512, 'LIKE_INPUT');  #set 512 as current value for sensor channel

=cut


sub QuaTe_SetStaticData
{
    my $DeviceName = shift;
    my $ChannelName = shift;
    my $Data = shift;
    my $DataFormat = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex, $DataFormatNumber);

     unless (defined( $DataFormat ))
    {
        S_set_error( '! too less parameters ! QuaTe_GetStaticData($DeviceName, $ChannelName, $Data, $DataFormat); ', 110 );
        return 0;
    }

    unless($DataFormat =~ /^LIKE_INPUT$/i || $DataFormat =~ /^LIKE_OUTPUT$/i) {
        S_set_error( "! Invalid data format : $DataFormat . Should be 'LIKE_INPUT' or 'LIKE_OUTPUT' ", 114 );
        return 0;
    }

    #assign numeric for data format (according to Quate low level Driver, OUTPUT = 0, INPUT = 1)
    $DataFormatNumber = 0 if($DataFormat =~ /^LIKE_OUTPUT$/i);
    $DataFormatNumber = 1 if($DataFormat =~ /^LIKE_INPUT$/i);

    #convert the data to decimal
    $Data  = S_0x2dec($Data);

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return;
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return;
    }

    S_w2log( 4, " QuaTe_SetStaticData: ($DeviceName [QUATE: $CtrlIndex  DEVICE: $DeviceIndex], $ChannelName [CHANNEL: $ChannelIndex], $Data, '$DataFormat') ");

    return 1 if $main::opt_offline;

    $status = qt_SetStaticData($CtrlIndex, $DeviceIndex, $ChannelIndex, $Data, $DataFormatNumber);
    check_status($status);
    S_w2log( 4, " QuaTe_SetStaticData : qt_SetStaticData => Status $status \n" );

    #
    #  TODO: return undef / is it successful ? / error handling of check status
    #

    return;
}


=head2 QuaTe_SetStaticFSMode

I<B<Syntax : >>

    QuaTe_SetStaticFSMode($DeviceName, $fileName, $FailureMask_href);

I<B<Arguments    : >>

    $DeviceName          =   device name as defined in ProjectDefaults
    $ChannelName         =   channel of the device for which Failure simulation to be done
    $FailureMask_href    =   A hash reference containing 'Failure types' as 'keys' & 'Failure mask values' as 'values'
                             (for additional info on 'keys' & 'Failure mask values', please refer QuaTe User Manual (path provided in QuaTe Usage section of documention)

I<B<Description :>>

generic function to set static Failures in any type of sensors (internal, peripheral, ABPlus, AB12 sensors (SMA660, SMA7xx) etc).
used to set failure mask values to enable or disable the failure simulation for sensors.

Note for PSI5DEVICE, SMI7xx, SMI8xx, etc.: Failure simulation can also be done via SetParameter.

More sensor specific details in

    path: \\bosch.com\dfsrb\DfsDE\DIV\CS\DE_CS$\Prj\PS\Support\Tools\QuaTe\30_DLL\E_Documentation
    file: Latest *DLL_Interface_Description*
    func: SetStaticFSMode

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_SetStaticFSMode('ECU_Acc_HG', 'AccX', { 'SID' => 1, 'TST' => 1 });
   QuaTe_SetStaticFSMode('PASFP', 'X',  { 'Manchester' => 1, 'Parity' => 0 } );

=cut

sub QuaTe_SetStaticFSMode
{
    my $DeviceName = shift;
    my $ChannelName = shift; 
    my $FailureMask_href = shift;

    my ($CtrlIndex, $DeviceIndex, $ChannelIndex);

    S_w2log( 4, "QuaTe_SetStaticFSMode\n");

    unless (defined( $FailureMask_href )) {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_SetStaticFSMode( \$DeviceName, \$ChannelName, \$FailureMask_href)", 110 );
        return 0;
    }


    # check whether $FailureMask_href is an hash reference
    if(defined $FailureMask_href && ref($FailureMask_href) ne 'HASH') {
        S_set_error( "\$FailureTypes_aref should be a HASH reference", 114 );
        return;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return;
    }

    ($CtrlIndex, $DeviceIndex, $ChannelIndex) = QuaTe_GetIndexFromDeviceChannel($DeviceName, $ChannelName);

    # check whether the indexes are found correctly
    unless(defined $CtrlIndex)
    {
        S_set_error( "! Device $DeviceName with channel $ChannelName is not found in ProjectDefaults->{'QUATE'} configuration ", 20 );
        return;
    }    

    my @FailureTypes = sort(keys(%$FailureMask_href));

    S_w2log( 4, "QuaTe_SetStaticFSMode ($DeviceName [QUATE: $CtrlIndex DEVICE: $DeviceIndex],  $ChannelName [CHANNEL: $ChannelIndex], FailureTypes[ @FailureTypes ])" );

    return 1 if $main::opt_offline;

    # set all the given Failure type masks
    foreach my $failureType(@FailureTypes)
    {
        $status = qt_SetStaticFSMode($CtrlIndex, $DeviceIndex, $ChannelIndex, $failureType, $FailureMask_href->{$failureType});
        check_status($status);
        S_w2log( 4, "Status of qt_SetStaticFSMode ($failureType = $FailureMask_href->{$failureType}) : $status \n" );
    }

    return;
}

sub QuaTe_SetTestName
{
    my $testName = shift;

    qt_SetTestName($testName);
    
    return 1;   
}

sub QuaTe_GetDLLVersion
{
    my ( $status, $version );
    ($status, $version) = qt_GetDLLVersion();

    return ($status, $version);
}

=head1 not exported functions

=head2 check_status

I<B<Syntax : >>

    check_status($status);

I<B<Arguments    : >>

    $status   =   status code to be checked

I<B<Description :>>

if status < 0, log error string and set INCONC.

I<B<Return values :>>

    None

I<B<Examples :>>

    check_status($status); 

=cut

sub check_status
{
    $status = shift;
    return 1 if $main::opt_offline;
    if ($status<0){
      my $errortext = qt_GetErrorString($status);
      S_set_error( "LIFT_QuaTe: $errortext" , 5);
    }
    return;
}

=head2 QuaTe_setClockData

I<B<Syntax : >>

    QuaTe_setClockData( $CtrlIndex, $DeviceIndex, $ChannelIndex, $SamplingTime_us);

I<B<Arguments    : >>

    $CtrlIndex          =   Quate Index (starts from 0)
    $DeviceIndex        =   device index in the Quate
    $ChannelIndex       =   channel index of the particular device
    $SamplingTime_us    =   sampling time in microseconds

I<B<Description :>>

sets the sampling time of the data put into FIFO.

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe_setClockData( 0, 1, 1, 12.5);    #set sampling rate of 0th Quate, 1st device, 1st channel to 12.5 us

=cut


sub QuaTe_setClockData
{
    my $CtrlIndex = shift;
    my $DeviceIndex = shift;
    my $ChannelIndex = shift;
    my $SamplingTime_us = shift;

    unless (defined $SamplingTime_us)
    {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_setClockData( \$CtrlIndex, \$DeviceIndex, \$ChannelIndex, \$SamplingTime_us )", 110 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    return 1 if ($main::opt_offline);

    $status = qt_SetTimeBase( $CtrlIndex, $DeviceIndex, $ChannelIndex, $SamplingTime_us );
    check_status($status);
    S_w2log( 4, " QuaTe_setClockData: qt_SetTimeBase ($CtrlIndex, $DeviceIndex, $ChannelIndex, $SamplingTime_us us) => Status : $status \n" );

    #
    #  TODO: return undef / is it successful ? / error handling of check status
    #

    return;
}


=head2 QuaTe_clipData

I<B<Syntax : >>

    QuaTe_clipData ( $data_aref, $rangeMin, $rangeMax );

I<B<Arguments    : >>

    $data_aref    =   Array of data to which the clipping to be applied
    $rangeMin     =   Minimum signal limit to apply Clipping 
    $rangeMax     =   Maximum signal limit to apply Clipping

I<B<Description :>>

clips the values of the array to the corresponding max and min limits

I<B<Return values :>>

    1

I<B<Examples :>>

   QuaTe_clipData( [-10.5, 0, 1, 5, -15.8, 12.5, 18, 0.5], -10, 10 );    # clip the data below -10 and above +10

=cut

sub QuaTe_clipData
{
    my $data_aref =shift;
    my $rangeMin = shift;
    my $rangeMax = shift;
    my $i = 0;

    unless (defined $rangeMax)
    {
        S_set_error( "! too less parameters ! SYNTAX: QuaTe_clipData ( \$data_aref, \$rangeMin, \$rangeMax );", 110 );
        return;
    }

    if ( $rangeMax < $rangeMin )
    {
        S_set_error( " rangeMax ($rangeMax) < rangeMin ($rangeMin). rangeMax should be greater than rangeMin", 109 );
        return;
    }

    S_w2log(4, "QuaTe_clipData(" . scalar(@$data_aref) . " points, Min Range: $rangeMin, Max Range: $rangeMax) \n");

    # STEP index i = -1
    #LOOP-START i++
    for ($i = 0; $i < scalar(@$data_aref); $i++)
    {
        # IF signal[i] < rangeMin
        if ($$data_aref[$i] < $rangeMin)
        {
            # IF-YES-START
            # STEP signal[i] = rangeMin
            $$data_aref[$i] = $rangeMin;
            # IF-YES-END
        }
        # IF-NO-START
        # IFsignal[i] > rangeMax
        elsif ($$data_aref[$i] > $rangeMax)
        {
            # IF-YES-START
            # STEP signal[i] = rangeMax
            $$data_aref[$i] = $rangeMax;
            # IF-YES-END
        }
        # IF-NO-START
        # IF-NO-END
        # IF-NO-END
    }
    #LOOP-END i > last index
    #STEP return 1
    return 1;
}

=head2 QuaTe_GetDeviceNameFromChipSelect

I<B<Syntax : >>

    QuaTe_GetDeviceNameFromChipSelect( $chipselect );

I<B<Arguments    : >>

    $chipselect   =   Chip Select

I<B<Description :>>

returns the Device name of the given chip select.

I<B<Return values :>>

    $device_name

I<B<Examples :>>

   $device_name = QuaTe_GetDeviceNameFromChipSelect('CS0');

=cut

sub QuaTe_GetDeviceNameFromChipSelect
{
    my $chipselect = shift;
    my ($Quate_name, $chip_device, $CtrlNum, $device_name);
    unless (defined $chipselect)
    {
        S_set_error("! too less parameters ! SYNTAX: QuaTe_GetDeviceNameFromChipSelect($chipselect) ",110);
        return 0;
    }
    if($chipselect !~ /^CS\d+/)
    {
        S_set_error( "! Invalid Parameter ! $chipselect shall be as CS0,CS1.... ", 114 );
        return 0;
    }

    unless ( $QT_initialized )
    {
        S_set_error( "QuaTe is not initialized" , 120);
        return 0;
    }

    for ( $CtrlNum = 0; $CtrlNum < $NumOfCtrls; $CtrlNum++) # number of Quates/controllers
    {
        $Quate_name = $Quate.$CtrlNum;
        my $quate_CONFIG = $main::ProjectDefaults->{'QUATE'};
        foreach my $device (sort keys %{$quate_CONFIG->{$Quate_name}{'DEVICES'}})
        {
          $chip_device = 'CS'.$quate_CONFIG->{$Quate_name}{'DEVICES'}{$device}{'CHIP_SELECT'};
            if($chipselect eq $chip_device)
            {

            $device_name = $quate_CONFIG->{$Quate_name}{'DEVICES'}{$device}{'DEVICE_NAME'};
            return $device_name;
           }
        }
    }
    return 0;
}


=head2 Decoder_EXCEL_Log

I<B<Syntax : >>

    Decoder_EXCEL_Log( $sensor_name [, $info_xls_aref] );

I<B<Arguments    : >>

    $sensor_name   =   Device Name

    $info_xls_aref =   Info to be printed to excel sheet

I<B<Description :>>

This is a generic function that prints the decoded data into a newly created EXCEL file.
If only sensor name is given , it will create a new workbook and a worksheet.
When the info is passed, the info is written to the excel sheet.
Excel sheet columns : Decoded Time,    ASIC, MOSI Data, MISO Data, Decoded MOSI, Decoded MISO, Regular Decoder.
Reference : These columns are in sync with SPImaidPlus tool.

I<B<Return values :>>

    None

I<B<Examples :>>

   Decoder_EXCEL_Log('SMA660'); #creates an excel sheet
   Decoder_EXCEL_Log(undef, [info_aref]); #writes info into excel sheet

<NOTE : currently used only for SMA660 decoder>

=cut

sub Decoder_EXCEL_Log
{
    my $sensor_name = shift;
    my $info_xls_aref = shift;
    unless($decoder_xls_flag)
    {
        ###############################################
        # create an EXCEL report to log the decoded info 
        ###############################################
        my @timestamp = S_formated_timestamp();
        my $timestamp_file_path = $timestamp[0] ."_".$timestamp[1];
        $timestamp_file_path =~ s/[.:]//ig;
        my $xls_file_name = $sensor_name."_Decoder_".$timestamp_file_path."\.xlsx";
        $excelfile = $main::save_name ."\\".$xls_file_name;
        $excelfile_abs = File::Spec->rel2abs($excelfile);
        $excel = Win32::OLE->GetActiveObject('Excel.Application') || Win32::OLE->new('Excel.Application','Quit');  # new Excel

        $excel->{SheetsInNewWorkBook} = 1;
        $workbook = $excel->Workbooks->Add();
        $Sheet = $workbook->Worksheets(1);
        $Sheet->Activate();
        $excelsheetname = $Sheet->{Name} = $sensor_name."Decoder";

        #column widths
        $Sheet->Columns("a")->{ColumnWidth} = 15;
        $Sheet->Columns("b")->{ColumnWidth} = 10;
        $Sheet->Columns("c")->{ColumnWidth} = 40;
        $Sheet->Columns("d")->{ColumnWidth} = 40;
        $Sheet->Columns("e")->{ColumnWidth} = 50;
        $Sheet->Columns("f")->{ColumnWidth} = 50;
        $Sheet->Columns("g")->{ColumnWidth} = 40;

        #column names
        $Sheet->Cells($excel_count,1)->{Value} = 'Decoded Time';
        $Sheet->Cells($excel_count,2)->{Value} = 'ASIC';
        $Sheet->Cells($excel_count,3)->{Value} = 'MOSI Data';
        $Sheet->Cells($excel_count,4)->{Value} = 'MISO Data';
        $Sheet->Cells($excel_count,5)->{Value} = 'Decoded MOSI';
        $Sheet->Cells($excel_count,6)->{Value} = 'Decoded MISO';
        $Sheet->Cells($excel_count,7)->{Value} = 'Regular Decoder';
        $excel_count++;

        my $decoder_xls_link =
<<EOHTML;
    <TR>
        <TD ALIGN="CENTER">$sensor_name Decoder File : <A HREF="$xls_file_name">$xls_file_name</A> </TD>
    </TR>
EOHTML

        S_w2rep($decoder_xls_link);
        $decoder_xls_flag = 1;
    }
    if (defined $info_xls_aref)
    {
        $Sheet->Activate();

        for (my $z = 0; $z < 7;$z++)
        {
            $Sheet->Cells($excel_count, ($z + 1))->{NumberFormat} = "\@";
            $Sheet->Cells($excel_count,($z + 1))->{Value} = @{$info_xls_aref}[$z];
        }
        $excel_count++;
    }
    return 1;
}

=head2 GetDecoderData

I<B<Syntax : >>

    \@decoded_data = GetDecoderData( $device_name, $dataline, $instruction, $dataValueTable_bits_aref, $frame_length, $data_aref );

I<B<Arguments    : >>

    $device_name = Sensor Name

    $dataline    =   MISO or MOSI (case sensitive)

    $instruction =   instuction to be decoded

    $dataValueTable_bits_aref = array reference of 'Data_name|bits' for the instruction $instruction

    $frame_length = Frame length read from 'sensor_FORMAT'=>{'frame_length'} hash

    $data_aref  = array reference of MOSI data read from qt_ReadSPIMonitorPlusData

I<B<Description :>>

function returns the bit wise decoded info of the sensor data.
This is a generic function.(currently used only for SMA660 )

I<B<Return values :>>

    \@decoded_data = array ref of decoded info

I<B<Examples :>>

   \@decoded_data = GetDecoderData( 'SMA660', 'MISO', $instruction, $dataValueTable_bits_aref, $frame_length, $data_aref );

<NOTE : This is non exported function. For further info refer documentation of QuaTe_ReadSPIMonitorPlusData>

=cut

sub GetDecoderData
{
    my $device_name = shift; #device name - SMA660 
    my $dataline = shift;# MISO or MOSI
    my $instruction = shift; #10 bit instruction
    my $dataValueTable_bits_aref = shift;#'Data_name|bits' array reference read from Project defaults
    my $frame_length = shift; #'frame_length' from Project defaults
    my $data_aref = shift; #MISO or MOSI data
    unless (defined $data_aref)
    {
        S_set_error("! too less parameters ! SYNTAX: GetDecoderData( $dataline, $instruction, $dataValueTable_bits_aref, $frame_length, $data_aref) ",110);
        return 0;
    }
    my (@decoded_data, @cmd_temp, @dataValueTable_cmd_name, @data_output) = ();
    my ($cmd_bit1, $cmd_bit2, $data);

    my $dataValueTable_count = scalar(@$dataValueTable_bits_aref);
    my $dataValueTable_count_temp = 0; #temporary count to track array length
    foreach my $name (@$dataValueTable_bits_aref) #loop through the data values given in 'Data_name|bits'
    {
        if($dataValueTable_count_temp < $dataValueTable_count)
        {
            my @temp = split (/\|/, $name); #split the data_name and bit places 
            $dataValueTable_cmd_name[$dataValueTable_count_temp] = $temp[0]; #store data_name
            my $cmd_bits = $temp[1];#store bit places
            if ($cmd_bits =~ /^\d+:\d+$/) #format of cmd_bits is upper limit:lower limit
            {
                @cmd_temp = split (/:/,$cmd_bits); #$cmd_bits = upper limit:lower limit
                $cmd_bit2 = ($frame_length -1) - $cmd_temp[0]; #subtract from frame length to get the required higher array index
                $cmd_bit1 = ($frame_length -1) - $cmd_temp[1]; #subtract from frame length to get the required lower array index
            }
            else #only one bit place
            {
                $cmd_bit2 = ($frame_length -1) - $cmd_bits;
                $cmd_bit1 = ($frame_length -1) - $cmd_bits;
            }
            $data = substr($data_aref, ($cmd_bit2),($cmd_bit1 - $cmd_bit2+1)); #extract data between higher and lower array indices
            if(exists $main::ProjectDefaults->{$device_name.'_COMMAND'}{$instruction}{'DataValueTable_'.$dataline}{$dataValueTable_cmd_name[$dataValueTable_count_temp]}{$data})
            {
                $data_output[$dataValueTable_count_temp] = $main::ProjectDefaults->{$device_name.'_COMMAND'}{$instruction}{'DataValueTable_'.$dataline}{$dataValueTable_cmd_name[$dataValueTable_count_temp]}{$data};
            }
            else
            {
                $data_output[$dataValueTable_count_temp] = "0x".sprintf('%X', oct("0b$data")); #convert to hex from binary
            }
        }
         $dataValueTable_count_temp += 1;
     }
    for (my $i = 0;$i < $dataValueTable_count;$i++)
    {
        my $dummy = $dataValueTable_cmd_name[$i]." => ".$data_output[$i];
        push (@decoded_data , $dummy); #push the decoded command and data info to an array
        undef $dummy;
    }
    return (\@decoded_data);
}

=head2 SMA660_decoder

I<B<Syntax : >>

    $signalname = SMA660_decoder( $decoder_time, $mosi_data, $miso_data);

I<B<Arguments    : >>

    $decoder_time  = time value returned from qt_ReadSPIMonitorPlusData

    $mosi_data     = MOSI data returned from qt_ReadSPIMonitorPlusData

    $miso_data     = MISO data returned from qt_ReadSPIMonitorPlusData

I<B<Description :>>

function decodes the SMA660 sensor data, prints decoded info to and excel using Decoder_EXCEL_Log.
returns $signalname to fill the returned hash of the function QuaTe_ReadSPIMonitorPlusData.

I<B<Return values :>>

    $signalname = signal name

I<B<Examples :>>

   $signalname = SMA660_decoder( '100.00123', '11111111000000000000000001001100', '11111111000000111010000001001100');
   
<NOTE : This is non exported function. For further info refer documentation of QuaTe_ReadSPIMonitorPlusData>

=cut

sub SMA660_decoder
{
    my $decoder_time = shift;
    my $mosi_data = shift;
    my $miso_data = shift;
    my @decoder_xls = ();
    my ($decoded_MOSI, $decoded_MISO, $instruction, $signalname); #SMA660 decoder variables
    my ($command,$mosi_name_bits,$miso_name_bits,$inst_length,$frame_length);#SMA660 decoder variables
    my $bitwise_decoding_flag = 0;#flag to represent whether bitwise decoding is required or not

    unless (defined $miso_data)
    {
        S_set_error("! too less parameters ! SYNTAX: SMA660_decoder( $decoder_time, $mosi_data, $miso_data) ",110);
        return 0;
    }

    if (exists $main::ProjectDefaults->{'SMA660_FORMAT'})
    {
         $inst_length = $main::ProjectDefaults->{'SMA660_FORMAT'}{'instruction_length'};
         $frame_length = $main::ProjectDefaults->{'SMA660_FORMAT'}{'frame_length'};
    }
    else
    {
         S_set_error( "'SMA660_FORMAT' hash not defined in Project Defaults", 0 );
         S_w2log( 5, "inst_length is taken as 10 bits \n" );
         S_w2log( 5, "frame_length is taken as 32 bits \n" );
         $inst_length = 10;
         $frame_length = 32;
    }

    $mosi_data =~ /^(\d{$inst_length})/; #bits 31 - 22 represent Instruction
    $instruction = $1;
    my $sensorname = 'SMA660'; #hardcoded as only one sensor belongs to this decoder type.
    #bit wise data decoding
    if(defined ($main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}) && ref($main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}) eq 'HASH')
    {
        $command = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}{'command'};
        $signalname = $sensorname.":".$command;
        $bitwise_decoding_flag = 1; #set the flag for bit wise decoding
    }
    #normal way of decoding data
    elsif(defined ($main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}) && ref($main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}) eq "")
    {
        $command = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction};
        $signalname = $sensorname.":".$command;
        $bitwise_decoding_flag = 0;
    }
    #throw error if instruction is not defined in SMA660_COMMAND hash in proj const
    else
    {
        $errormsg{"ProjectDefaults->{'SMA660_COMMAND'}{$instruction}not defined"}++;
        $signalname = $sensorname.":undef";
        $bitwise_decoding_flag = 0;
    }

    $decoder_time = sprintf( "%010.3f" , $decoder_time/1000.0);
    if ($bitwise_decoding_flag) #perform bit wise decoding
    {
        Decoder_EXCEL_Log($sensorname,undef);
        my $mosi_Decoder = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}{'DataValueTable_MOSI'};
        my $miso_Decoder = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}{'DataValueTable_MISO'};
        if(defined $mosi_Decoder)
        {
            $mosi_name_bits = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}{'DataValueTable_MOSI'}{'Data_name|bits'};
            $decoded_MOSI = GetDecoderData($sensorname, 'MOSI', $instruction, $mosi_name_bits, $frame_length,$mosi_data);
        }
        if (defined $miso_Decoder)
        {
            $miso_name_bits = $main::ProjectDefaults->{'SMA660_COMMAND'}{$instruction}{'DataValueTable_MISO'}{'Data_name|bits'};
            $decoded_MISO = GetDecoderData($sensorname, 'MISO', $instruction, $miso_name_bits, $frame_length,$miso_data);
        }
        #to write decoded info to EXCEL file
        my $string1 = ' ';
        my $string2 = ' ';
        $string1 = $command ." :: ". join(' ',@$decoded_MOSI) if(defined $mosi_name_bits);
        $string2 = $command ." :: ". join(' ',@$decoded_MISO) if(defined $miso_name_bits);
        push(@decoder_xls,($decoder_time, 'SMA660', $mosi_data,$miso_data, $string1, $string2, ' ')); #decoder info
    }
    else #normal decoding
    {
      Decoder_EXCEL_Log($sensorname,undef);
     push(@decoder_xls,($decoder_time, 'SMA660', $mosi_data, $miso_data, ' ', ' ', $command));
    }
    Decoder_EXCEL_Log (undef,\@decoder_xls);
    @decoder_xls = ();
    return $signalname;
}

=head2 QuaTe_UpdateOverloadConfigRegister

I<B<Syntax : >>

    QuaTe_UpdateOverloadConfigRegister($deviceName, $channelName, $enableOverLoad);

I<B<Arguments    : >>

    $deviceName        =   The device name as configured in ProjectDefaults
    $channelName       =   The channel name as configured in ProjectDefaults
    $enableOverLoad    =   A flag to enable (1) or disable (0) overload for this device-channel

I<B<Description :>>

This is a wrapper function for
QuaTe_UpdateOverloadConfigRegisterSMI700 and
QuaTe_UpdateOverloadConfigRegisterSMI8xx

I<B<Return values :>>

    0: error
    1: success

I<B<Examples :>>

   QuaTe_UpdateOverloadConfigRegister("SMI700", "ECU: Acc_LG: Y: SMI7x0_sync_axay_6_5g_73Hz", 1);

=cut

sub QuaTe_UpdateOverloadConfigRegister
{
    my $deviceName = shift;
    my $channelName = shift;
    my $enableOverLoad = shift;

    my $deviceDescriptionInternal = QuaTe_GetDeviceDescriptionInternal( $deviceName, $channelName );
    if ( $deviceDescriptionInternal =~ /^SMI700$/ )
    {
        QuaTe_UpdateOverloadConfigRegisterSMI700($deviceName, $channelName, $enableOverLoad);
    }
    elsif ( $deviceDescriptionInternal =~ /^SMI8xx$/ )
    {
        QuaTe_UpdateOverloadConfigRegisterSMI8xx($deviceName, $channelName, $enableOverLoad);
    }
    else
    {
        my $errTxt = sprintf("%s: Device %s, Channel %s does not support overload function): %s", (caller(0))[3], $deviceName, $channelName, $deviceDescriptionInternal);
        S_set_error( $errTxt, 114 ); # 114 = "invalid parameters"
        return 0;
    }
    return 1;
}

=head2 QuaTe_UpdateOverloadConfigRegisterSMI700

I<B<Syntax : >>

    QuaTe_UpdateOverloadConfigRegisterSMI700($deviceName, $channelName, $enableOverLoad);

I<B<Arguments    : >>

    $deviceName        =   The device name as configured in ProjectDefaults
    $channelName       =   The channel name as configured in ProjectDefaults
    $enableOverLoad    =   A flag to enable (1) or disable (0) overload for this device-channel

I<B<Description :>>

Updates the QuaTe overload config register, by binary masking relevant overload bits, by read > mask-modify > write again config register bits. 

I<B<Return values :>>

    0: error
    1: success

I<B<Examples :>>

   QuaTe_UpdateOverloadConfigRegisterSMI700("SMI700", "ECU: Acc_LG: Y: SMI7x0_sync_axay_6_5g_73Hz", 1);

=cut

sub QuaTe_UpdateOverloadConfigRegisterSMI700
{
    my $deviceName = shift;
    my $channelName = shift;
    my $enableOverLoad = shift;

    # Check for input parameters ($DeviceName, $ChannelName, $EnableOverLoad)
    unless ( defined $enableOverLoad )
    {
        S_set_error( "! too less parameters ! QuaTe_UpdateOverloadConfigRegisterSMI700(\$deviceName, \$channelName, \$enableOverLoad);", 110 );
        return 0;
    }

    my $ovlCfgRegVal = 0; # overload config register value
    my $bitmask;

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    my $overloadConfigRegister_aref = QuaTe_GetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG');    # get OVERLOAD_CONFIG param values
    $ovlCfgRegVal = $$overloadConfigRegister_aref[0];

    # Check, if QuaTe_GetParameter failed
    unless ( defined $ovlCfgRegVal )
    {
        S_set_error( "QuaTe_GetParameter did not return any value", 114 ); # 114 = "invalid parameters"
        return 0;
    }

    # Set corresponding 2 bits to
    # 00: Disable overload
    # 01: Enable overload (higher bit of two always 0 for temporary overload!)

    # RATE_LF (bit11..10)
    if ( $channelIndex == 0 )
    {
        $ovlCfgRegVal &= ~( 1 << 11 );
        if ( $enableOverLoad ) { $ovlCfgRegVal |=  ( 1 << 10 ); }
        else                   { $ovlCfgRegVal &= ~( 1 << 10 ); }
    }

    # ACC1_LF (bit3..2) 
    elsif ( $channelIndex == 1 )
    {
        $ovlCfgRegVal &= ~( 1 << 3 );
        if ( $enableOverLoad ) { $ovlCfgRegVal |=  ( 1 << 2 ); }
        else                   { $ovlCfgRegVal &= ~( 1 << 2 ); }
    }

    # ACC2_LF (bit7..6)
    elsif ( $channelIndex == 2 )
    {
        $ovlCfgRegVal &= ~( 1 << 7 );
        if ( $enableOverLoad ) { $ovlCfgRegVal |=  ( 1 << 6 ); }
        else                   { $ovlCfgRegVal &= ~( 1 << 6 ); }
    }

    # ACC1_HF (bit1..0)
    elsif ( $channelIndex == 3 )
    {
        $ovlCfgRegVal &= ~( 1 << 1 );
        if ( $enableOverLoad ) { $ovlCfgRegVal |=  1; }
        else                   { $ovlCfgRegVal &= ~1; }
    }

    # ACC2_HF (bit5..4)
    elsif ( $channelIndex == 4 )
    {
        $ovlCfgRegVal &= ~( 1 << 5 );
        if ( $enableOverLoad ) { $ovlCfgRegVal |=  ( 1 << 4 ); }
        else                   { $ovlCfgRegVal &= ~( 1 << 4 ); }
    }

    # Error
    else
    {
        my ($deviceDescription, $deviceVersion) = QuaTe_GetDeviceDescription( $deviceName, $channelName );
        my $errTxt = sprintf("%s: Channel %d does not support overload function (range: 0...4, see  corresponding ROM-File): %s", (caller(0))[3], $channelIndex, $deviceDescription);
        S_set_error( $errTxt, 114 ); # 114 = "invalid parameters"
        return 0;
    }

    # Update "SPI register error group", depending on selected channels
    # If any bit in err group ACC1 (bit0..3) is set, set bit12
    $bitmask = 1 | 1 << 1 | 1 << 2 | 1 << 3;
    if ( $ovlCfgRegVal & $bitmask ) { $ovlCfgRegVal |=  ( 1 << 12 ); }
    else                            { $ovlCfgRegVal &= ~( 1 << 12 ); }

    # If any bit in err group ACC2 (bit4..7) is set, set bit13
    $bitmask = 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7;
    if ( $ovlCfgRegVal & $bitmask ) { $ovlCfgRegVal |=  ( 1 << 13 ); }
    else                            { $ovlCfgRegVal &= ~( 1 << 13 ); }

    # If any bit in err group RATE (bit8..11) is set, set bit14
    $bitmask = 1 << 8 | 1 << 9 | 1 << 10 | 1 << 11;
    if ( $ovlCfgRegVal & $bitmask ) { $ovlCfgRegVal |=  ( 1 << 14 ); }
    else                            { $ovlCfgRegVal &= ~( 1 << 14 ); }

    # Update "Global overload enable", depending on selected channels
    # If any bit of bit12..14 is set, set bit15
    $bitmask = 1 << 12 | 1 << 13 | 1 << 14;
    if ( $ovlCfgRegVal & $bitmask ) { $ovlCfgRegVal |=  ( 1 << 15 ); }
    else                            { $ovlCfgRegVal &= ~( 1 << 15 ); }

    $ovlCfgRegVal &= 0xFFFF; # delete (any invalid) bits beyond 16 bit

    $$overloadConfigRegister_aref[0] = $ovlCfgRegVal;
    QuaTe_SetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG', $overloadConfigRegister_aref);

    return 1;
}


=head2 QuaTe_UpdateOverloadConfigRegisterSMI8xx

I<B<Syntax : >>

    QuaTe_UpdateOverloadConfigRegisterSMI8xx($deviceName, $channelName, $enableOverLoad);

I<B<Arguments    : >>

    $deviceName        =   The device name as configured in ProjectDefaults
    $channelName       =   The channel name as configured in ProjectDefaults
    $enableOverLoad    =   A flag to enable (1) or disable (0) overload for this device-channel

I<B<Description :>>

Updates the QuaTe overload config register, by binary masking relevant overload bits, by read > mask-modify > write again config register bits. 

I<B<Return values :>>

    0: error
    1: success

I<B<Examples :>>

   QuaTe_UpdateOverloadConfigRegisterSMI8xx("SMI8xx", "SMI8xx_CH_0", 1);

=cut


sub QuaTe_UpdateOverloadConfigRegisterSMI8xx
{
    my $deviceName = shift;
    my $channelName = shift;
    my $enableOverLoad = shift;

    # Check for input parameters ($DeviceName, $ChannelName, $EnableOverLoad)
    unless ( defined $enableOverLoad )
    {
        S_set_error( "! too less parameters ! QuaTe_UpdateOverloadConfigRegisterSMI8xx(\$deviceName, \$channelName, \$enableOverLoad);", 110 );
        return 0;
    }

    my $overloadConfigRegister_aref;
    my $ovlCfgRegVal1 = 0; # overload config register 1 value
    my $ovlCfgRegVal2 = 0; # overload config register 2 value
    my $bitmask;

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName);

    $overloadConfigRegister_aref = QuaTe_GetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG1');    # get OVERLOAD_CONFIG1 param values
    $ovlCfgRegVal1 = $$overloadConfigRegister_aref[0];

    # Check, if QuaTe_GetParameter failed
    unless ( defined $ovlCfgRegVal1 )
    {
        S_set_error( "QuaTe_GetParameter (..., OVERLOAD_CONFIG1) did not return any value", 114 ); # 114 = "invalid parameters"
        return 0;
    }

    $overloadConfigRegister_aref = QuaTe_GetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG2');    # get OVERLOAD_CONFIG2 param values
    $ovlCfgRegVal2 = $$overloadConfigRegister_aref[0];

    # Check, if QuaTe_GetParameter failed
    unless ( defined $ovlCfgRegVal2 )
    {
        S_set_error( "QuaTe_GetParameter (..., OVERLOAD_CONFIG2) did not return any value", 114 ); # 114 = "invalid parameters"
        return 0;
    }

    # Channel numbers, see comment at hash: %OverloadChSMI8xx

    # Set corresponding 2 bits to
    # 00: Disable overload
    # 01: Enable overload (higher bit of two always 0 for temporary overload!)

    # RATE1_LF (bit11..10)
    if ( $channelIndex == 0 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 11 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 10 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 10 ); }
    }

    # ACCEL1_LF (bit3..2) 
    elsif ( $channelIndex == 1 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 3 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 2 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 2 ); }
    }

    # ACCEL2_LF (bit7..6)
    elsif ( $channelIndex == 2 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 7 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 6 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 6 ); }
    }

    # ACCEL1_HF (bit1..0)
    elsif ( $channelIndex == 3 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 1 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  1; }
        else                   { $ovlCfgRegVal1 &= ~1; }
    }

    # ACCEL2_HF (bit5..4)
    elsif ( $channelIndex == 4 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 5 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 4 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 4 ); }
    }

    # RATE2_LF (bit9..8)
    elsif ( $channelIndex == 5 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 9 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 8 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 8 ); }
    }

    # ACCEL3_LF (bit15..14)
    elsif ( $channelIndex == 6 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 15 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 14 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 14 ); }
    }

    # ACCEL3_HF (bit13..12)
    elsif ( $channelIndex == 7 )
    {
        $ovlCfgRegVal1 &= ~( 1 << 13 );
        if ( $enableOverLoad ) { $ovlCfgRegVal1 |=  ( 1 << 12 ); }
        else                   { $ovlCfgRegVal1 &= ~( 1 << 12 ); }
    }

    # Error
    else
    {
        my ($deviceDescription, $deviceVersion) = QuaTe_GetDeviceDescription( $deviceName, $channelName );
        my $errTxt = sprintf("%s: Channel %d does not support overload function (range: 0...4, see  corresponding ROM-File): %s", (caller(0))[3], $channelIndex, $deviceDescription);
        S_set_error( $errTxt, 114 ); # 114 = "invalid parameters"
        return 0;
    }

    # Update "SPI register error group", depending on selected channels
    # If any bit in err group ACC1 (bit0..3) is set, set bit10
    $bitmask = 1 | 1 << 1 | 1 << 2 | 1 << 3;
    if ( $ovlCfgRegVal1 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 10 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 10 ); }

    # If any bit in err group Rate2 (bit8..9) is set, set bit11
    $bitmask = 1 << 8 | 1 << 9;
    if ( $ovlCfgRegVal1 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 11 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 11 ); }

    # If any bit in err group Rate1 (bit10..11) is set, set bit12
    $bitmask = 1 << 10 | 1 << 11;
    if ( $ovlCfgRegVal1 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 12 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 12 ); }

    # If any bit in err group ACC3 (bit12..15) is set, set bit13
    $bitmask = 1 << 12 | 1 << 13 | 1 << 14 | 1 << 15;
    if ( $ovlCfgRegVal1 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 13 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 13 ); }

    # If any bit in err group ACC2 (bit4..7) is set, set bit14
    $bitmask = 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7;
    if ( $ovlCfgRegVal1 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 14 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 14 ); }

    # Update "Global overload enable", depending on selected channels
    # If any bit of bit10..14 is set, set bit15
    $bitmask = 1 << 10 | 1 << 11 | 1 << 12 | 1 << 13 | 1 << 14;
    if ( $ovlCfgRegVal2 & $bitmask ) { $ovlCfgRegVal2 |=  ( 1 << 15 ); }
    else                             { $ovlCfgRegVal2 &= ~( 1 << 15 ); }

    # delete (any invalid) bits beyond 16 bit
    $ovlCfgRegVal1 &= 0xFFFF;
    $ovlCfgRegVal2 &= 0xFFFF;

    $$overloadConfigRegister_aref[0] = $ovlCfgRegVal1;
    QuaTe_SetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG1', $overloadConfigRegister_aref);

    $$overloadConfigRegister_aref[0] = $ovlCfgRegVal2;
    QuaTe_SetParameter($deviceName, $channelName, 'OVERLOAD_CONFIG2', $overloadConfigRegister_aref);

    return 1;
}

=head2 QuaTe_overLoadChStrByChName

I<B<Syntax : >>

    $overLoadChStr = QuaTe_overLoadChStrByChName($deviceName, $channelName);

I<B<Arguments    : >>

    $deviceName        =   The device name as configured in ProjectDefaults
    $channelName       =   The channel name as configured in ProjectDefaults

I<B<Description :>>

Returns the OVERLOAD register name for given channelName. 

I<B<Return values :>>

    $overLoadChStr: success
    undef:          error

I<B<Examples :>>

   $overLoadChStr = QuaTe_overLoadChStrByChName("SMI700", "ECU: Acc_LG: Y: SMI7x0_sync_axay_6_5g_73Hz");
   $overLoadChStr = QuaTe_overLoadChStrByChName("SMI8xx", "SMI8xx_CH_0");

=cut

sub QuaTe_overLoadChStrByChName
{
    my $deviceName = shift;
    my $channelName = shift;

    my $overLoadChStr;

    my ($ctrlIndex, $deviceIndex, $channelIndex) = QuaTe_GetIndexFromDeviceChannel($deviceName, $channelName); # $channelIndex needed

    my $deviceDescriptionInternal = QuaTe_GetDeviceDescriptionInternal( $deviceName, $channelName );
    if ( $deviceDescriptionInternal =~ /^SMI700$/ )
    {
        $overLoadChStr = sprintf("OVERLOAD_CH%d", $channelIndex);
    }
    elsif ( $deviceDescriptionInternal =~ /^SMI8xx$/ )
    {
        $overLoadChStr = $OverloadChSMI8xx{$channelIndex};
    }
    else
    {
        my $errTxt = sprintf("%s: Device %s, Channel %s does not support overload function): %s", (caller(0))[3], $deviceName, $channelName, $deviceDescriptionInternal);
        S_set_error( $errTxt, 114 ); # 114 = "invalid parameters"
        return undef;
    }

    return $overLoadChStr;

}

=head2 QuaTe_OverloadOff

I<B<Syntax : >>

    QuaTe_OverloadOff();

I<B<Arguments    : >>

    None

I<B<Description :>>

Disables the overload function of all QuaTes, SMI700/SMI8xx-Devices and Channels.

I<B<Return values :>>

    None

I<B<Example :>>

    QuaTe_OverloadOff();

=cut

sub QuaTe_OverloadOff
{
    return 1 if ($main::opt_offline);

    my $ctrlNum = qt_GetNumberOfControllers();
    if ( $ctrlNum < 0 )
    {
         my $errortext = qt_GetErrorString($ctrlNum);
         S_set_error( "QuaTe : $errortext", 5 );
         return 0;
    }

    # for all connected QuaTes
    for ( my $ctrl = 0; $ctrl < $ctrlNum; $ctrl++ )
    {
        my $devNum = qt_GetNumberOfDevices($ctrl);
        if ( $devNum < 0 )
        {
            my $errortext = qt_GetErrorString($devNum);
            S_set_error( "QuaTe : $errortext", 5 );
            return 0;
        }

        # for all sensor devices of this QuaTe
        for ( my $dev = 0; $dev < $devNum; $dev++ )
        {
            my $deviceDescriptionInternal;
            ( $status, $deviceDescriptionInternal ) = qt_GetDeviceDescriptionInternal( $ctrl, $dev );
            check_status($status);
            S_w2log( 4, "Status of qt_GetDeviceDescriptionInternal : $status \n" );
            if ( $status < 0 )
            {
                return 0;
            }

            # Only SMI7 and SMI8xx support overload flag feature
            if ( $deviceDescriptionInternal =~ /^SMI700$/ || $deviceDescriptionInternal =~ /^SMI8xx$/ )
            {
                my @overloadConfigRegister = (0); # all bits cleared
                my $overLoadConfigKey = "OVERLOAD_CONFIG"; # SMI700: OVERLOAD_CONFIG, SMI8xx: OVERLOAD_CONFIG1 and OVERLOAD_CONFIG2
                foreach my $regNo ( 0 .. 2 )
                {
                    if ( $regNo > 0 ) { $overLoadConfigKey = sprintf("OVERLOAD_CONFIG%d", $regNo); }
                    if ( $regNo == 0 && $deviceDescriptionInternal =~ /^SMI700$/ || $regNo > 0 && $deviceDescriptionInternal =~ /^SMI8xx$/ )
                    {
                        $status = qt_SetParameter($ctrl, $dev, 0, $overLoadConfigKey, \@overloadConfigRegister); # 0: parameter is channel independent
                        if ( $status < 0 )
                        {
                            my $errortext = qt_GetErrorString($status);
                            S_set_error( "QuaTe : $errortext", 5 );
                        }
                        else
                        {
                            S_w2log( 4, "Erased $overLoadConfigKey register of QuaTe device=$deviceDescriptionInternal (QuaTe=$ctrl,Dev=$dev)\n");
                        }
                    }
                }

                for (my $devCh = 0; $devCh < 5; $devCh++) # $devCh = 0..4
                {
                    my @devCh_a = ($devCh); # devCh as array
                    $status = qt_SetParameter($ctrl, $dev, 0, 'OVERLOAD_CLEAR', \@devCh_a); # 0: parameter is channel independent
                    if ( $status < 0 )
                    {
                        my $errortext = qt_GetErrorString($status);
                        S_set_error( "QuaTe : $errortext", 5 );
                    }
                    else
                    {
                        S_w2log( 4, "Sent 'OVERLOAD_CLEAR' for QuaTe device=$deviceDescriptionInternal (QuaTe=$ctrl,Dev=$dev), channel=$devCh\n");
                    }
                }
            }
        }
    }
    return 1;
}

=head2 QuaTe_GetInternalDeviceType

I<B<Syntax : >>

    $deviceType = QuaTe_GetInternalDeviceType($deviceName, $channelName);

I<B<Arguments    : >>

    $deviceName   =   The Device name as configured in ProjectDefaults
    $channelName  =   The channel name as configured in ProjectDefaults

I<B<Description :>>

Returns a integer value for internal device type.

I<B<Return values :>>

     0: EDIF-Netlist (no PSI5DEVICE)
     1: PSI5DEVICE_1CH
     2: PSI5DEVICE_2CH

I<B<Example :>>

    $deviceType = QuaTe_GetInternalDeviceType(0, 2); # 1st QuaTe, 3rd sensor device

=cut

sub QuaTe_GetInternalDeviceType
{
    my $deviceName = shift;
    my $channelName = shift;
    my $isPsi5Device;

    # CALL QuaTe_GetDeviceDescriptionInternal
    my $deviceDescriptionInternal = QuaTe_GetDeviceDescriptionInternal( $deviceName, $channelName );

    # IF deviceDescriptionInternal == PSI5DEVICE_1CH
    if ( $deviceDescriptionInternal =~ /^PSI5DEVICE_1CH$/ )
    {
        # IF-YES-START
        # STEP isPsi5Device = 1
        $isPsi5Device = 1;
        # IF-YES-END
    }
    # IF-NO-START
    # IF deviceDescriptionInternal == PSI5DEVICE_2CH
    elsif ( $deviceDescriptionInternal =~ /^PSI5DEVICE_2CH$/ )
    {
        # IF-YES-START
        # STEP isPsi5Device = 2
        $isPsi5Device = 2;
        # IF-YES-END
    }

    else
    {
        # IF-NO-START
        # STEP isPsi5Device = 0
        $isPsi5Device = 0;
        # IF-NO-END
    }

    # IF-NO-END
    # STEP return isPsi5Device
    return $isPsi5Device;
}

=head2 QuaTe_round2Short

I<B<Syntax : >>

    QuaTe_round2Short($data_aref, $dataSize);

I<B<Arguments    : >>

    $data_aref = data points as array reference
    $dataSize  = size of data points array

I<B<Description :>>

Modifies array reference in place, pointing to array with rounded to short values.

short-min: -32768(-0x8000) ... short-max: 32767(0x7FFF)


I<B<Return values :>>

     1

I<B<Example :>>

    QuaTe_round2Short(\[-40000, 1.5, 2.5, 3.1, 4.6, 5.7, 40000], 7);
    modifies aref to  \[-32768, 2.0, 3.0, 3.0, 5.0, 6.0, 32767]

=cut

sub QuaTe_round2Short
{
    my $data_aref = shift;
    my $dataSize = shift;

	for(my $i = 0; $i < $dataSize; $i++)
    {
        #round the floating points to integer
        # positive precision numbers : 0.4 & less => 0, 0.5 & above => 1 and so on
        # negative precision numbers : -0.4 & above(-0.3, -0.2..) => 0, -0.5 & less(-0.6,-0.7..) => -1, and so on
        # zero => zero
        my $value = $$data_aref[$i] >= 0 ? int($$data_aref[$i] + 0.5) : -int(-$$data_aref[$i] + 0.5);
        if ( $value > $NUM_INT16_MAX ) { $value = $NUM_INT16_MAX }
        if ( $value < $NUM_INT16_MIN ) { $value = $NUM_INT16_MIN }

        $$data_aref[$i] = $value;
    }
    return 1;
}

=head2 QuaTe_resample

I<B<Syntax : >>

    $outData_ref = QuaTe_resample($inData_aref, $inDataSize, $inSamplingTime_us, $outDataSize, $outSamplingTime_us, $mode);

I<B<Arguments    : >>

    $inData_aref        = data buffer of the original data
    $inDataSize         = number of samples of the original data
    $inSamplingTime_us  = time base in [�s] of the original data (floating point value allowed)
    $outDataSize        = number of samples of the resampled data
    $outSamplingTime_us = time base in [�s] of the resampled data (only integer value allowed with a resolution of 1�s)
    $mode               = operating mode of resample function:
                            0 : S/H mode (hold the last value of input data)
                            1 : interpolation mode

I<B<Description :>>

First call function 'qt_GetResampleFIFOSize', in order to have proper selection of parameters '$outDataSize' and '$outSamplingTime_us'.
This function 'QuaTe_resample' is a wrapper for 'qt_ResampleFIFOData', which additionally fixes the potential issue with the last point.
Resamples the original data to fit the best time base - and FIFO data settings.
Returns an array reference pointing to the data buffer of the resampled data.


I<B<Return values :>>

     $outData_ref

I<B<Example :>>

    # Usage in two steps:
    
    # Step 1: First call 'qt_GetResampleFIFOSize', in order to find 'BEST FITTING' sampling time and data size for 'WISHED' sampling time and data size
    my $outDataSize = 20; # wished number of points
    my $outSamplingTime_us = 113.777; # wished sampling time (as floating point value)
    my ($status, $outDataSizeBestFit, $outSamplingTimeBestFit_us) = qt_GetResampleFIFOSize($outDataSize, $outSamplingTime_us);
    # Will return: $outDataSizeBestFit = 19, $outSamplingTimeBestFit_us = 114 (integer value with 1us resolution)
    
    # Step 2: Only now call this function 'QuaTe_resample'
    my @signal = (-4, -3, -2, -1, 0, 1, 2, 3, 4, 5); # data as 'short' (16 Bit) values
    my $outData_aref = QuaTe_resample(\@signal, scalar(@signal), 249.456, $outDataSizeBestFit, $outSamplingTimeBestFit_us, 1); # Resample the 10 points with 249.456 us sampling rate to 19 points with 114 us sampling rate
    # Will return: $outData_aref as (-4, -3, -3, -2, -2, -1, -1, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5);

=cut

sub QuaTe_resample
{
    my $inData_aref = shift;
    my $inDataSize = shift;
    my $inSamplingTime_us = shift;
    my $outDataSize = shift;
    my $outSamplingTime_us = shift;
    my $mode = shift;

    my $outData_ref;

    # Resample short data using qt_ResampleFIFOData
    S_w2log( 4, " Resampling the FIFO Data using interpolation mode  \n");
    ($status, $outData_ref) = qt_ResampleFIFOData($inData_aref, $inDataSize, $inSamplingTime_us, $outDataSize, $outSamplingTime_us, $mode); #1 = interpolation mode
    check_status($status);

    # After resampling above, the LAST POINT might be different to original curve (interpolation error),
    # so it is set again with original value, what is especially important because the last
    # value is held by QuaTe as output value until new data is coming in
    $$outData_ref[$outDataSize - 1] = $$inData_aref[-1];

	return $outData_ref;
}

=head2 QuaTe_createGraph

I<B<Syntax : >>

    QuaTe_createGraph($curveName, $title, $data_aref, $dt_sec);

I<B<Arguments    : >>

    $fileName:           without extension, which will be added as .png/.txt.unv (done by S_create_graph)
    $title:              written into graphic
    $data_aref, $dt_sec: curve data and cycle time, both of type floating point

I<B<Description :>>

Creates curve picture and uniview-file of given curve. Generated output: $curveName.png, $curveName.txt.unv

I<B<Return values :>>

     1 (success)

I<B<Example :>>

    # See sample at the end of function QuaTe_DownloadData (prepared as comment there):
    my $curveName = $deviceName."_".$channelName;
    my $title = "QuaTe_SetDynamicData: ".$curveName;
    QuaTe_createGraph($curveName, $title, $outData_ref, $outTime_us / 1E6);

=cut

sub QuaTe_createGraph # Don't delete, even if not used, it exists as prepared comment, wherever useful for special investigations
{
    my $myCurveName = shift;
    my $legend = shift;
    my $dataIn_aref = shift;
    my $dtIn_sec = shift;

    my $numPts = scalar( @$dataIn_aref );
    my @time_ms = (0.0);
    for (my $i = 0; $i < $numPts; $i++)
    {
        $time_ms[$i] = $i * $dtIn_sec * 1000;
    }
    my $data =
    {
       'time' => \@time_ms,
       'val'=> [@$dataIn_aref],
    };
    S_create_graph($data, "$myCurveName", $legend, 'white', 'interpolate');

    return 1;
}

sub QuaTe_LoggingSetup
{
    my $loggingStatus;
    my $logEnable = $main::ProjectDefaults->{'QUATE'}->{'QUATE_LOGGING'}{'ENABLE'}; # 'yes' | 'no'

    if ( defined($logEnable) )
    {
        if ( $logEnable =~ /yes/i ) { $loggingStatus = "ACTIVE";   }
        else                        { $loggingStatus = "INACTIVE"; }

        # Create QuaTe ini file for logging
        my $quateDLLname = qt_getDLLfilename();
        my $quateDLLiniFileName = $quateDLLname;
        $quateDLLiniFileName =~ s/.dll/.ini/i;

        my $liftExecPath = $main::LIFT_exec_path;
        if ( not defined $liftExecPath )
        {
            # Assume .t testing
            require( "Unit_test_engine_path.pm" );
            $liftExecPath = $Unit_test_engine_path::enginePath;
        }
        my $snapshot_directory = "$main::REPORT_PATH/_snapshot_";
        $snapshot_directory = File::Spec->rel2abs($snapshot_directory);
        $snapshot_directory .= "\\";
        unless ( -e $snapshot_directory or mkdir $snapshot_directory )
        {
            S_set_error("Unable to create directory $snapshot_directory\n");
            return;
        }
        my $quateDLLiniFilePath = $liftExecPath . "\\modules\\Device_layer\\QUATE\\Win32\\" . $quateDLLiniFileName;
        $quateDLLiniFilePath = File::Spec->rel2abs($quateDLLiniFilePath);
        my $fhIniFile;
        my $fstatus = open( $fhIniFile, ">", $quateDLLiniFilePath );
        if ( defined $fstatus )
        {
            print $fhIniFile "LOGGING_STATUS=$loggingStatus\n";
            print $fhIniFile "Logging_Path=\"$snapshot_directory\"\n";
            print $fhIniFile "Logging_Prefix=\"QuateReplayLogger_\"\n";
            close($fhIniFile);
        }
        else
        {
            S_set_error("Unable to write to file (does not exist or write-protected?): $quateDLLiniFilePath\n");
            return;
        }
    }

    return 1;
}

1;

__END__


=head1 AUTHORS

Archana GopalaKrishna, E<lt>Archana.Gopalakrishna@in.bosch.comE<gt>

Frank BE<ouml>hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

Arulkumar S, E<lt>Arulkumar.S@in.bosch.comE<gt>

Peter WeiE<szlig>flog, E<lt>Peter.Weissflog@de.bosch.comE<gt>

=head1 SEE ALSO

perl, QuaTe Documentation

=cut

