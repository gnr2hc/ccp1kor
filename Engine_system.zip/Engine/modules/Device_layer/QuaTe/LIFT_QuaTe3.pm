# *****************************************************************************************************
#
#  Copyright (c) 2013  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************
package LIFT_QuaTe3;

use strict;
use warnings;
use REST::Client;
use LIFT_general;

require Exporter;

our @ISA = qw(Exporter);

our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  QuaTe3_DownloadData
  QuaTe3_Exit
  QuaTe3_Init
  QuaTe3_configure
  QuaTe3_LoadHWConfiguration
);

our ( $VERSION, $HEADER );
my ( $client, $url );

=head1 NAME

LIFT_QuaTe3 

Perl extension for QuaTe3

=head1 QuaTe3 Usage


=head1 SYNOPSIS

    use LIFT_QuaTe3;

    QuaTe3_Init();

    QuaTe3_Exit();

=head2 ProjectDefaults


                      

=head2 Testbench



=head1 DESCRIPTION



=cut

=head2 QuaTe3_Init

I<B<Syntax : >>

    QuaTe3_Init();

I<B<Arguments    : >>

    None

I<B<Description :>>

=over



=back

I<B<Return values :>>

    None

I<B<Examples :>>

   QuaTe3_Init();

=cut

sub QuaTe3_Init {

    my ( $name, $number ) = @ARGV;

    $client = REST::Client->new();
    $url    = "http://10.14.247.17/api/rpc";
    $client->addHeader( 'accept',       '*/*' );
    $client->addHeader( 'Content-Type', 'text/plain' );

    Upload_Java_Script('C:\sandboxes\QuaTe_Rev3_Dev\RVD7KOR\tools\quate\software\QAPI\Quate3_API.js');
    Upload_Json();
    
    $client->POST( $url, 'data_handler.ID()' );
    my $init_js_response = $client->responseContent();
    print "data :: $init_js_response\n";
    return 1;
}


############################################################################################################
#
# not exported functions
#
############################################################################################################

sub Upload_Java_Script {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Upload_Java_Script( $name )', @args );
    my $name = shift @args;

    # Upload Init JS File
    my $err_flg = 0;
    $err_flg = 1 unless ( open( my $fh, '<', $name ) );

    if ($err_flg) {
        S_set_error("Could not open file '$name' for reading : $!");
        return;
    }

    local $/ = '';
    my $req = <$fh>;
    close $fh;

    $client->POST( $url, $req );
    my $init_js_response = $client->responseContent();
    print "JS response : $init_js_response\n";
    return 1;
}

sub Upload_Json {
    my @args = @_;
    return unless S_checkFunctionArguments( 'Upload_Json(  )', @args );

    my $pre      = 'var AXI_Map = ';
    my $filename = 'C:\sandboxes\QuaTe_Rev3_Dev\RVD7KOR\tools\quate\software\QAPI\AXI_Map.json';
    my $err_flg  = 0;
    $err_flg = 1 unless ( open( my $fh, '<', $filename ) );

    local $/ = '';
    my $json = <$fh>;
    close $fh;
    my $req = "{$pre$json}";

    if ($err_flg) {
        S_set_error("Could not open file '$filename' for reading : $!");
        return;
    }

    $client->POST( $url, $req );
    my $init_json_response = $client->responseContent();
    print "JS response : $init_json_response\n";

    return 1;
}

1;

