The QuaTe_7L.dll or higher can log the communication (API function calls, Crash data input etc.) between Turbolift and QuaTe-DLL and save them in a log file.

For activating the logger functionality,
1. Save the .ini in same folder where DLL is saved
2. The logging functions works only, if "LOGGING_STATUS=ACTIVE" exists in .ini file
3. WARNING: Do only use a local folder on Test-PC for the "Logging_Path", in order to avoid test interrupts caused by network losses
   (just keep default sub-folder below QuaTe-DLL: Logging_Path=".\logger\", which will be transferred to the testlog snapshot)

