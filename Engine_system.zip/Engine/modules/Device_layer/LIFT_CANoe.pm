# *****************************************************************************************************
#
#  Copyright (c) 2014  Robert Bosch GmBH
#                      Germany
#                      All rights reserved
#
#******************************************************************************************************
#******************************************************************************************************

package LIFT_CANoe;

######################################################

=head1 NAME

LIFT_CANoe 

=head1 IMPORTANT NOTE

The module LIFT_CANoe.pm will become obselete soon. Please use functions from LIFT_can_access.pm module.

=head1 DESCRIPTION

Provide LIFT useful functions for access to CANoe

taken from STEPS and modified

=head1 SYNOPSIS

    use LIFT_CANoe;

    CAN_init();
    OLE_handle = CAN_start_application ( hostname );
    CAN_open_configuration (config_file, 1);
    CAN_logging_start();
    CAN_start_measurement();
    EnvVarObject = CAN_get_env_variable(EnvVarName);
    EnvVarValue = CAN_get_EnvVar_value(EnvVarName);
    CAN_set_EnvVar_value( EnvVarName, EnvVarValue );
    SignalObject = CAN_get_signal_variable( Channel, Message, SignalName );
    SignalValue = CAN_get_Signal_value( Channel, Message, SignalName );
    CAN_set_Signal_value( Channel, Message, SignalName, SignalValue );
    CAN_stop_measurement();
    CAN_trace_store();
    CAN_logging_stop();
    CAN_log_store();
    CAN_close_application();
    $trace_data_ref = CAN_trace_can_get_dataref(  CAN_tool_trace , CAN_signal_or_message_list );
    $signal_data_ref = CAN_trace_get_data_can_signal($found_messages , $can_signal , $data_format);

=head2 Project Configuration

    $Defaults = {
                    'Mapping_CAN'     => {
                        //CAN Messages
                        //CAN signals
                },

=head2 Testbench Configuration

    'Devices' => {
        
        'CANoe' => {
            'Hostname'      =>  'SI-Z0DFL',
            'Online_Config' => 'C:\TurboLIFT_TSG4\Engine\test\CANoe\LIFT_CAN_access\COMDemo.cfg',
            'Log_File'      => 'C:\temp\CANOE_log.asc',
        },
        
    },
 
=cut

######################################################

use strict;
use warnings;
use Win32::OLE;
use File::Copy;
use File::Basename;
use FileHandle;
use LIFT_general;
use Cwd 'abs_path';

use vars qw( $VERSION $HEADER @ISA @EXPORT );
use Exporter;


@ISA    = qw(Exporter);
@EXPORT = qw(
  CAN_init
  CAN_start_measurement
  CAN_stop_measurement
  CAN_trace_store
  CAN_close_application
  CAN_trace_can_get_dataref
  CAN_get_env_variable
  CAN_get_EnvVar_value
  CAN_set_EnvVar_value
  CAN_get_signal_variable
  CAN_get_Signal_value
  CAN_set_Signal_value
  CAN_open_configuration
  CAN_start_application
  CAN_trace_get_data_can_signal
  CAN_logging_start
  CAN_logging_stop
  CAN_log_store
  );    # export subs

my $CAN_tool_control;
my $CANoe_OLE_handle;

my $CANMapping;

######################################################

=head2 CAN_init

    CAN_init();

Organize initialization of CAN tool application (start tool or connect to already running),should be called in INITcampaign.  

refer CANoe section under device of ( L</"Testbench Configuration">) .

B<Examples:>

    CAN_init( );

B<Notes:>

 This API shall be called before calling andy other API of this module. 

=cut

sub CAN_init
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
          
    my $testbench = $LIFT_config::LIFT_Testbench;
    $CANMapping = $main::ProjectDefaults->{'Mapping_CAN'};

    my ( $hostname, $online_config, $logfile, $ole_handle, $currently_loaded_device, @logFileNames, $matched_flag, );

    unless ( $hostname = $testbench->{'Devices'}{'CANoe'}{'Hostname'} )
    {
        S_set_error( " CAN_init: No 'Hostname' defined for 'CANoe' in Testbench\n", 131 );
        return;
    }

    if ( not $currently_loaded_device = $CAN_tool_control->{'Hostname'}{$hostname} )
    {
        unless ( $ole_handle = CAN_start_application($hostname) )
        {
            S_set_error( " CAN_init: Could not start 'CANoe' application on host '$hostname' \n", 131 );
            return;
        }
		
		# get the Canoe .cfg file from testbench
		unless ( defined $testbench->{'Devices'}{'CANoe'}{'Online_Config'})
        {
            S_set_error( " CAN_init: No 'Online_Config' defined for 'CANoe' in LIFT_Testbench\n", 131 );
            return;
        }
		
		 $online_config = abs_path( dirname($testbench->{'Devices'}{'CANoe'}{'Online_Config'}) );
         $online_config =~ s/\//\\/g;
         $online_config .= "\\" . basename($testbench->{'Devices'}{'CANoe'}{'Online_Config'});

        unless ( CAN_open_configuration( $online_config, 1 ) )
        {
            S_set_error( " CAN_init: Could not open 'CANoe' configuration '$online_config' \n", 131 );
            return;
        }

        $CAN_tool_control->{'Devices'}{'CANoe'}{'DefaultOnlineConfig'} = $online_config;
    }
    else
    {
        if ( 'CANoe' =~ /$currently_loaded_device/ )
        {
            S_w2log( 3, " CAN_init: 'CANoe' application on host '$hostname' already started\n" );
            $ole_handle = $CAN_tool_control->{'Devices'}{'CANoe'}{'OLE_handle'};
        }
        else
        {
            S_set_error( " cannot start 'CANoe' application on $hostname ($currently_loaded_device already loaded)\n", 131 );
            return;
        }
    }

    unless ( $logfile = $testbench->{'Devices'}{'CANoe'}{'Log_File'} )
    {
        S_set_error( " CAN_init: No 'Log_File' defined for 'CANoe'\n", 131 );
        return;
    }

    @logFileNames = CAN_get_configured_logfile_names();
    @logFileNames = ($logfile) if $main::opt_offline;

    $matched_flag = 0;
    foreach (@logFileNames)
    {
        my $temp = basename($_);
        $temp =~ s/\d+\.asc$/.asc/i;    # remove numbers from CANoe incrementing file
        if ( $temp eq basename($logfile) )
        {
            S_w2log( 3, " CAN_init: 'CANoe' Configuration has Log File $_ configured\n" );
            $CAN_tool_control->{'Devices'}{'CANoe'}{'DefaultLogFile'} = $logfile;
            $matched_flag = 1;
        }
    }

    unless ($matched_flag)
    {
        my $log_files_text = join( " ", @logFileNames );
        S_set_error( " CAN_init: Could not find Testbench Log_File '$logfile' in configured Log_Files ( $log_files_text ) of 'CANoe' configuration '$online_config' \n", 0 );    #only warning
    }

    return 1;
}

######################################################

=head2 CAN_start_application

    OLE_handle = CAN_start_application ( hostname );

start application of CAN tool

return OLE_handle

=cut

######################################################
sub CAN_start_application
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $hostname = shift;

    my ( $vector_cantool_OLE_call, $device_already_running, $ole_handle, );

    $vector_cantool_OLE_call = "CANoe.Application";

    unless ( S_ping($hostname) )
    {
        S_set_error( " Could not reach host '$hostname'  \n may be just a network problem with 'ping'-function \n anyway - try to load config again..\n", 0 );
    }

    if ( $device_already_running = $CAN_tool_control->{'Hostname'}{$hostname} )
    {
        S_w2log( 4, " CAN_start_application: Couldnt load a second CAN tool application on host '$hostname' ($device_already_running is active) \n" );
        return 1;
    }

    #   unless( $ole_handle = S_create_OLE( $vector_cantool_OLE_call, $hostname , \&CAN_close_application ) ) {
    unless ( $ole_handle = S_create_OLE( $vector_cantool_OLE_call, $hostname ) )
    {
        S_w2log( 3, " CAN_start_application: Could not reach host '$hostname' \n" );
        return 1;
    }

    $CANoe_OLE_handle                                             = $ole_handle;
    $CAN_tool_control->{'Devices'}{'CANoe'}{'OLE_handle'}         = $ole_handle;
    $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'DeviceType'} = 'CANoe';
    $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'}   = $hostname;
    $CAN_tool_control->{'Hostname'}{$hostname}                    = 'CANoe';

    S_w2log( 3, "CANoe application started \n" );

    return $ole_handle;

}

######################################################

=head2 CAN_close_application NE

    CAN_close_application ();

stops measurement and closes application on CAN tool, should be called in EDNcampaign

#not exportet! will crash perl! will be called automatically on quit!

=cut

######################################################
sub CAN_close_application
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;

    return 1 if $main::opt_offline;    # just return if running in offline mode

    my $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};

    if ( $ole_handle->Measurement->Running() )
    {
        S_w2log( 3, "CAN_close_application: 'CANoe' Stop Measurement on $hostname \n" );
        $ole_handle->Measurement->Stop();
    }

    unless ( defined $ole_handle )
    {
        S_w2log( 5, "CAN_close_application: (DESIGN NEEDS TO BE UPDATED) No handle existing for device 'CANoe' on hostname $hostname\n" );
        return 1;
    }

#    S_w2log( 4, "CAN_close_application: 'CANoe' on $hostname Quit Application \n" );
    my $result = $ole_handle->Application->Quit();
    S_w2log( 4, "CAN_close_application: 'CANoe' on $hostname Quit Application = $result \n" );

    delete $CAN_tool_control->{'OLE_handles'}{$ole_handle};
    delete $CAN_tool_control->{'Hostname'}{$hostname};
    delete $CAN_tool_control->{'Devices'}{'CANoe'}{'OLE_handle'};

    return 1;

    # previous ???
    #   my $ole_handle = $CANoe_OLE_handle;
    #   return 1 if $main::opt_offline; # just return if running in offline mode
    #   my $hostname = $CAN_tool_control->{'OLE_handles'}{ $ole_handle }{'Hostname'};
    #   CAN_stop_measurement( ) if CAN_check_running(  );
    #   S_w2log( 2, "CAN_close_application: 'CANoe' on $hostname Quit Application \n" );
    #   my $result = $ole_handle -> Application -> Quit();
    #   delete $CAN_tool_control->{'OLE_handles'}{$ole_handle};
    #   delete $CAN_tool_control->{'Hostname'}{$hostname};
    #   delete $CAN_tool_control->{'Devices'}{'CANoe'}{'OLE_handle'};
    #   return 1;

}

######################################################

=head2 CAN_get_configured_logfile_names NE

 @LogFileNames = CAN_get_configured_logfile_names ();

Read the full name of currently loaded configuration on existing CAN-tool OLE object.

=cut

######################################################
sub CAN_get_configured_logfile_names
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my @dummy_ret  = ('dummy');
    my $ole_handle = $CANoe_OLE_handle;

    unless ( defined $ole_handle )
    {
        S_set_error( "CAN_get_configured_logfile_names: CANoe handle is not obtained \n ", 110 );
        return @dummy_ret;
    }

    my @returned_LogFileNames;
    my $logging_object_handle;

    return @dummy_ret if $main::opt_offline;    # just return if running in offline mode

    my $nbr_of_looging_objects = $ole_handle->Configuration->OnlineSetup->LoggingCollection->Count();

    S_w2log( 5, "CAN_get_configured_logfile_names: nbr of logging objects = $nbr_of_looging_objects \n" );

    for ( 1 .. $nbr_of_looging_objects )
    {
        $logging_object_handle = $ole_handle->Configuration->OnlineSetup->LoggingCollection->Item($_);
        $logging_object_handle = $ole_handle->Configuration->OnlineSetup->LoggingCollection($_);
        push( @returned_LogFileNames, $logging_object_handle->{'FullName'} );

        S_w2log( 5, "CAN_get_configured_logfile_names: " . $logging_object_handle->{'FullName'} . " \n" );
    }

    return @returned_LogFileNames;
}

######################################################

=head2 CAN_open_configuration

 CAN_open_configuration (  $config_file [, $visible_mode] );

Loads configuration on existing CAN-tool OLE object.
visible_mode -> 0 : non-visible
visible_mode -> 1 : visible

A check of the currently loaded config will be done too

=cut

######################################################
sub CAN_open_configuration
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;

    #    my ( $config_file, $visible_mode, ) = @_;

    my $config_file  = shift;
    my $visible_mode = shift;

    my ( $read_config_fullname, $already_running_config, );

    unless ( defined $config_file )
    {
        S_set_error( " ! too less parameters ! SYNTAX: CAN_open_configuration( cantool_OLE_handle, config_file [, visible_mode])", 110 );
        return;
    }

    my $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};

    if ( $already_running_config = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'ActiveConfiguration'} )
    {
        S_w2log( 4, "current CANoe configuration: $already_running_config \n" );
        if ( basename($already_running_config) eq basename($config_file) )
        {
            S_w2log( 4, " CAN_open_configuration: 'CANoe' config '$config_file' already loaded -> return \n" );
            return 1;
        }
    }

    return 1 if $main::opt_offline;    # just return if running in offline mode

    if ($visible_mode)
    {
        S_w2log( 4, " CAN_open_configuration: Set 'CANoe' Visible \n" );
        $ole_handle->Application->{'Visible'} = 1;
    }

    # get full path
    $config_file = abs_path( dirname($config_file) ) . '/' . basename($config_file);
    $config_file =~ s/\//\\/g;         # replace all slashes with backslashes
    $config_file =~ s/\\/\\\\/g;       # replace all single backslashes with double backslashes

    S_w2log( 4, " CAN_open_configuration: 'CANoe' on $hostname Opening config (AutoSave=True , PromptUser=False) '$config_file' \n" );
    $ole_handle->Application->Open( $config_file, 1, 0 );

    ## return when no config could be read
    return unless $read_config_fullname = CAN_read_configuration();

    ## return when loaded config doesnt correspond with required config
    ##  (CANtool is loading mostly a default config)
    unless ( lc basename($config_file) eq lc basename($read_config_fullname) )
    {
        S_wait_ms(1000);

        # try to current config 2nd time
        return unless $read_config_fullname = CAN_read_configuration();
        unless ( lc basename($config_file) eq lc basename($read_config_fullname) )
        {
            S_set_error( " 'CANoe' Loading config '$config_file' failed (currently loaded config: $read_config_fullname) ", 131 );
            return;
        }
    }

    $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'ActiveConfiguration'} = $config_file;

    S_w2log( 3, "CANoe Configuration file loaded succesfully \n" );

    return 1;
}

######################################################

=head2 CAN_read_configuration NE

 FullName = CAN_read_configuration ();

Read the full name of currently loaded configuration on existing CAN-tool OLE object.

=cut

######################################################
sub CAN_read_configuration
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $dummy_ret  = "dummy";
    my $ole_handle = $CANoe_OLE_handle;

    unless ( defined $ole_handle )
    {
        S_set_error( " SYNTAX: CAN_read_configuration( cantool_OLE_handle )", 110 );
        return $dummy_ret;
    }

    my $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};

    return $dummy_ret if $main::opt_offline;    # just return if running in offline mode

    my $fullName = $ole_handle->Application->Configuration->{'FullName'};

    unless ( defined $fullName )
    {
        S_set_error( " 'CANoe' on $hostname Couldnt read currently loaded configuration: $! ", 131 );
        return $dummy_ret;
    }

    S_w2log( 3, " CAN_read_configuration: 'CANoe' '$fullName' (host: $hostname)\n" );

    return $fullName;
}

######################################################

=head2 CAN_start_measurement

      CAN_start_measurement ( );

check if measurement is running on CAN tool given bei OLE_handle

=cut

######################################################
sub CAN_start_measurement
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;

    unless ( defined $ole_handle )
    {
        S_set_error( " SYNTAX: CAN_start_measurement( cantool_OLE_handle )", 110 );
        return;
    }

    if ( CAN_check_running() )
    {
        S_w2log( 4, " CAN_start_measurement : measurement has been started already \n" );
        return 1;
    }

    my $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};

    S_w2log( 3, " CAN_start_measurement : start 'CANoe' Measurement on $hostname\n" );

    return 1 if $main::opt_offline;    # just return if running in offline mode

    $ole_handle->Application->CAPL->Compile();

    $ole_handle->Measurement->Start();
    return 1;
}

######################################################

=head2 CAN_check_running NE

      CAN_check_running ( );

check if measurement is running on CAN tool given bei OLE_handle

=cut

######################################################
sub CAN_check_running
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning(); 

    my $ole_handle = $CANoe_OLE_handle;

    unless ( defined $ole_handle )
    {
        S_set_error( "CAN_check_running: CANoe handle is not obtained \n ", 110 );
        return 0;
    }

    unless ( $CAN_tool_control->{'OLE_handles'}{$ole_handle} )
    {
        S_set_error( " invalid OLE handle ", 109 );
        return 0;
    }

    if ($main::opt_offline)
    {
        S_w2log( 3, "CAN_check_running: Measurement running not checked in offline mode \n" );
        return 1;
    }    # just return if running in offline mode
    if ( $ole_handle->Measurement->Running() )
    {
        S_w2log( 3, "CAN_check_running: Measurement is running \n" );
        return 1;
    }

    return 0;
}

######################################################

=head2 CAN_stop_measurement

      CAN_stop_measurement ();

check if measurement is running on CAN tool given bei OLE_handle

=cut

######################################################
sub CAN_stop_measurement
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;

    unless ( defined $ole_handle )
    {
        S_set_error( " SYNTAX: CAN_stop_measurement( cantool_OLE_handle )", 110 );
        return;
    }

    unless ( CAN_check_running() )
    {
        S_w2log( 3, " CAN_stop_measurement : measurement has been stopped already \n" );
        return 1;
    }

    my $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};

#    S_w2log( 4, " CAN_stop_measurement : Stop 'CANoe' Measurement on $hostname .. " );

    if ($main::opt_offline)
    {    # just return if running in offline mode
        S_w2log( 3, "CAN_stop_measurement : Not done in offline mode\n" );
        return 1;
    }

    $ole_handle->Measurement->Stop();
    S_w2log( 3, "CAN_stop_measurement : Stopped 'CANoe' Measurement on $hostname\n" );
    return 1;
}

######################################################

=head2 CAN_trace_store

    $store_file_name = CAN_trace_store ( [$store_file_name] );

Store the current Logfile of CAN Online Configuration under $store_file_name.
If no store_file_name given the CAN trace will be stored in Testdocumentation.
A running measurement will be stopped !

return value is the store_file_name

=cut

######################################################
sub CAN_trace_store
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $dummy_ret         = 'dummy';
    my $ole_handle        = $CANoe_OLE_handle;
    my ($store_file_name) = shift;

    unless ( defined $ole_handle )
    {
        S_set_error( " SYNTAX: CAN_trace_store( [ , store_file_name ] )", 110 );
        return $dummy_ret;
    }

    unless ($store_file_name)
    {
        my $date_extension = main::get_date_extension( time() );
        $store_file_name = $main::REPORT_PATH . '\LIFT_can_trace_' . $date_extension . ".asc";
    }

    CAN_stop_measurement() if CAN_check_running();

    return $dummy_ret if $main::opt_offline;    # just return if running in offline mode

    ## default logfile was validated in CAN_cantool_init already
    my $default_logfile = $CAN_tool_control->{'Devices'}{'CANoe'}{'DefaultLogFile'};

    if ( -f $default_logfile )
    {
        S_w2log( 4, " CAN_trace_store : Found 'CANoe' Logfile : $default_logfile\n" );
    }
    else
    {
        S_set_error( " Couldn't find 'CANoe' logfile : $default_logfile\n", 0 );
        return $dummy_ret;
    }

    S_w2log( 3, " CAN_trace_store : Copy '$default_logfile' -> $store_file_name \n" );
    unless ( copy( $default_logfile, $store_file_name ) )
    {
        S_set_error( " copy ( $default_logfile , $store_file_name ) : $! \n", 0 );
        return $dummy_ret;
    }

    return $store_file_name;

}

######################################################

=head2 CAN_logging_start

    CAN_logging_start ( );

This API enables the logging of the Trace into a log file via environment variable.
the user have to configure a .asc/.blf/.mdf file as log file in the measurement setup in CANoe configuration.

=cut

######################################################
sub CAN_logging_start
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    CAN_set_EnvVar_value( "LIFT_stop_logging_i",  0 );
    CAN_set_EnvVar_value( "LIFT_start_logging_i", 1 );

    return 1;
}

######################################################

=head2 CAN_logging_stop

    CAN_logging_stop ( );

This API disables the logging of the Trace into a log file via environment variable.
the user have to configure a .asc/.blf/.mdf file as log file in the measurement setup in CANoe configuration.

=cut

######################################################
sub CAN_logging_stop
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    CAN_set_EnvVar_value( "LIFT_start_logging_i", 0 );
    CAN_set_EnvVar_value( "LIFT_stop_logging_i",  1 );

    return 1;
}

######################################################

=head2 CAN_log_store

    $store_file_name = CAN_log_store ( [$store_file_name] );

Store the current Logfile of CAN Online Configuration under $store_file_name.
If no store_file_name given the CAN trace will be stored in Testdocumentation.
A running measurement will not be influenced, the logfile with highest number will be taken.

return value is the store_file_name

=cut

######################################################
sub CAN_log_store
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $dummy_ret         = 'dummy';
    my $ole_handle        = $CANoe_OLE_handle;
    my ($store_file_name) = shift;

    unless ( defined $ole_handle or $main::opt_offline )
    {
        S_set_error( " SYNTAX: CAN_log_store( [ , store_file_name ] )", 110 );
        return $dummy_ret;
    }

    unless ($store_file_name)
    {
        my $date_extension = main::get_date_extension( time() );
        $store_file_name = $main::REPORT_PATH . '\LIFT_can_trace_' . $date_extension . ".asc";
    }

    return $dummy_ret if $main::opt_offline;    # just return if running in offline mode

    ## default logfile was validated in CAN_cantool_init already
    my $default_logfile = $CAN_tool_control->{'Devices'}{'CANoe'}{'DefaultLogFile'};

    #take logfile with highest number.

    my ( $file, $dir ) = fileparse( $default_logfile, '\.asc' );

    print "search for $file in $dir\n";

    opendir( ROOT, $dir ) or die "ERROR: Cannot open $dir for directory check\n";

    # aread all .asc files
    my @newfiles = grep { /^$file\d*\.asc$/ } readdir(ROOT);
    closedir ROOT;
    print "@newfiles \n";

    # sorting taken from C:/Perl/html/lib/Pod/perlfunc.html sort LIST
    @newfiles = map { $_->[0] }
      sort { $b->[1] <=> $a->[1] || $a->[2] cmp $b->[2] } map { [ $_, /(\d+)\.asc$/, uc($_) ] } @newfiles;

    print "@newfiles \n";
    my $logfile = shift(@newfiles);
    if ($logfile)
    {
        $logfile = $dir . $logfile;
        print "taking $logfile \n";
        S_w2log( 4, " CAN_log_store : Found 'CANoe' Logfile : $logfile\n" );
    }
    else
    {
        S_set_error( " Couldn't find 'CANoe' logfile : $default_logfile\n", 0 );
        return $dummy_ret;
    }

    S_w2log( 3, " CAN_log_store : Copy '$logfile' -> $store_file_name \n" );
    unless ( copy( $logfile, $store_file_name ) )
    {
        S_set_error( " copy ( $logfile , $store_file_name ) : $! \n", 0 );
        return $dummy_ret;
    }

    return $store_file_name;

}

######################################################

=head2 CAN_trace_can_get_dataref

    $trace_data_ref = CAN_trace_can_get_dataref ( $CAN_tool_trace , @CAN_signal_or_message_list );

    Structure of returned trace_data_ref is:

    $trace_data_ref = {
                        'timestamp_1' => {
                                       'message_A' => 'DLC_A1' ,
                                       'signal_1' => 'raw_hex_value_at_time_1',
                                       'signal_2' => 'raw_hex_value_at_time_1',
                                       'message_B' => 'DLC_B1' ,
                                       'signal_3' => 'raw_hex_value_at_time_1',
                                          },
                        'timestamp_2' => {
                                       'message_A' => 'DLC_A2' ,
                                       'signal_1' => 'raw_hex_value_at_time_2',
                                       'signal_2' => 'raw_hex_value_at_time_2',
                                       'message_B' => 'DLC_B2' ,
                                       'signal_3' => 'raw_hex_value_at_time_2',
                                          },
                     };

offline_return : { 0 => { 'dummy' => 0 } }

    NOTE: @CAN_signal_or_message_list works as a filter, only listed names are processed
          if a signal is defined in several messages, use message_name::signal_name like in CAPL


    @CAN_signal_or_message_list may contain arefs like [Message_ID_dec,busnr] to bypass CAN mapping file

=cut

######################################################
sub CAN_trace_can_get_dataref
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $can_trace_file                = shift;
    my @given_can_signals_or_messages = @_;
    my $data_HoH_dummy;
    $data_HoH_dummy->{0}->{'dummy'} = 0;

    unless (@given_can_signals_or_messages)
    {
        S_set_error( " SYNTAX: CAN_trace_can_get_dataref( $can_trace_file , @given_can_signals_or_messages )", 110 );
        return;
    }

    my ( $returnDataRef, $data_format, $timestamps, $can_signal, $neededMsgs, $msg_name, $data, $id_dec, $id_hex, $id, $found_messages, $signal_data_ref, $value, $can_bus_nbr, $just_message_infos, $just_signal_infos, );

    return $data_HoH_dummy if $main::opt_offline;

    unless ( ( $data_format, $timestamps ) = CAN_trace_can_analyze_format($can_trace_file) )
    {
        S_set_error( " couldn't determine format of CAN trace $can_trace_file", 131 );
        return $data_HoH_dummy;
    }

    unless ( $timestamps =~ /absolut/i )
    {
        S_set_error( " timestamps in trace must be configured as 'absolute'", 131 );
        return $data_HoH_dummy;
    }

    ## collect all needed messages
    foreach my $can_signal_or_message (@given_can_signals_or_messages)
    {
        if ( ref($can_signal_or_message) eq "ARRAY" )
        {
            if ( $$can_signal_or_message[0] =~ /^\d+$/ )
            {
                $msg_name           = $$can_signal_or_message[0];
                $id_dec             = $msg_name;
                $just_message_infos = 1;
                $can_bus_nbr        = $$can_signal_or_message[1];
                S_w2log( 5, " CAN_trace_can_get_dataref : checking $msg_name on bus $can_bus_nbr (unmapped)\n" );
            }
        }
        else
        {
            if ( $CANMapping->{'CAN_MESSAGES'}{$can_signal_or_message} )
            {
                # message infos are requested
                $msg_name = $can_signal_or_message;
                undef $can_signal;

                $just_message_infos = 1;
                $just_signal_infos  = 0;

            }
            else
            {
                # signal infos are requested
                $can_signal = $can_signal_or_message;
                undef $msg_name;
                unless ( $msg_name = $CANMapping->{$can_signal}{'MESSAGE'} )
                {
                    S_set_error( " CAN_trace_can_get_dataref: no 'MESSAGE' defined for CAN signal '$can_signal' in CAN MAPPING\n", 109 );
                    return;
                }
                $just_message_infos = 0;
                $just_signal_infos  = 1;
            }

            unless ( $can_bus_nbr = $CANMapping->{'CAN_MESSAGES'}{$msg_name}{'CAN_BUS_NBR'} )
            {
                S_set_error( " CAN_trace_can_get_dataref: no 'CAN_BUS_NBR' defined for CAN message '$msg_name' in CAN MAPPING\n", 109 );
                return $data_HoH_dummy;
            }
            S_w2log( 5, " CAN_trace_can_get_dataref : checking $can_signal_or_message \n" );

            $id_dec = $CANMapping->{'CAN_MESSAGES'}{$msg_name}{'ID'};
        }
        $id_hex = uc sprintf( "%x", $id_dec );
        $id = $id_dec if $data_format =~ /dec/i;
        $id = $id_hex if $data_format =~ /hex/i;

        unless ( $found_messages = $neededMsgs->{$msg_name}{'FOUND'} )
        {
            $found_messages = CAN_trace_get_data_can_frame( $can_trace_file, $id, $can_bus_nbr );
            ## then search with the symbolic name from CAN mapping
            unless ( defined $found_messages )
            {
                $found_messages = CAN_trace_get_data_can_frame( $can_trace_file, $msg_name, $can_bus_nbr );
            }

            unless ($found_messages)
            {
                S_w2log( 3, " CAN_trace_can_get_dataref : couldnt find CAN message $msg_name \n" ) if $just_message_infos;
                S_w2log( 3, " CAN_trace_can_get_dataref : couldnt find CAN message $msg_name for (signal : $can_signal) \n" ) if $just_signal_infos;
                next;
            }

            $neededMsgs->{$msg_name}{'FOUND'} = $found_messages;

            if ($just_message_infos)
            {
                foreach my $time_stamp ( sort { $a <=> $b } keys %$found_messages )
                {
                    #                 $DLC = $found_messages->{ $time_stamp }{'DLC'};
                    # S_w2log( 5, " VEC_trace_can_get_dataref : add $time_stamp : $msg_name  = $DLC \n" );
                    #                 $ReturnDataRef->{ $time_stamp }{ $msg_name } = $DLC;
                    $data = $found_messages->{$time_stamp}{'DATA'};
                    $data =~ s/\s+//g;    #remove blanks
                    $returnDataRef->{$time_stamp}{$msg_name} = $data;

                    #S_w2log( 5, " CAN_trace_can_get_dataref : add $time_stamp : $msg_name  = $DATA \n" );
                }
                next;
            }

        }

        $signal_data_ref = CAN_trace_get_data_can_signal( $found_messages, $can_signal, $data_format );
        foreach my $time_stamp ( sort { $a <=> $b } keys %$signal_data_ref )
        {
            $value = $signal_data_ref->{$time_stamp};

            #S_w2log( 5, " CAN_trace_can_get_dataref : add $time_stamp : $can_signal  = $value \n" );
            $returnDataRef->{$time_stamp}{$can_signal} = $value;
        }
    }

    return $returnDataRef;
}

######################################################

=head2 CAN_trace_can_analyze_format NE

    ( base-type , timestamp-type ) = CAN_trace_can_analyze_format ( $can_trace_file );


=cut

######################################################
sub CAN_trace_can_analyze_format
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $can_trace_file = shift;
    my @dummy = ( 'dummy', 'dummy' );

    unless ( defined $can_trace_file )
    {
        S_set_error( " SYNTAX: CAN_trace_can_analyze_format( $can_trace_file )", 110 );
        return @dummy;
    }

    return @dummy if $main::opt_offline;

    #    my $trace_FH = new FileHandle;
    my $trace_FH = FileHandle->new;
    unless ( $trace_FH->open($can_trace_file) )
    {
        S_set_error( " Couldnt open CAN Trace '$can_trace_file' ", 131 );
        return @dummy;
    }

    my $data_format;
    my $timestamps;
    while (<$trace_FH>)
    {
        if (/base\s+(\S+)\s+timestamps\s+(\S+)/) { $data_format = $1; $timestamps = $2; last; }
    }
    $trace_FH->close;

    unless ( defined $timestamps )
    {
        S_set_error( " Couldn't determine base and timestamps format in '$can_trace_file' ", 131 );
        return @dummy;
    }

    S_w2log( 3, " CAN_trace_can_analyze_format : base = $data_format timestamps = $timestamps \n" );
    return ( $data_format, $timestamps );

}

#####################################################################

=head2 CAN_trace_get_data_can_frame

    $message_ref = CAN_trace_get_data_can_frame ( $can_log_file , $can_frame , $can_bus_nbr );

Reads a single frame from a Canalyzer logfile. $can_log_file is the full name of the logfile.
$can_frame is symbolic name or decimal or hexadecimal value of the CAN frame in the logfile.
Returns reference to hash structure:

      $message_ref->{$timestamp}{'DLC'} = DLC;
      $message_ref->{$timestamp}{'DATA'} = raw bytes of message;

=cut

######################################################
sub CAN_trace_get_data_can_frame
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $can_log_file = shift;
    my $can_message  = shift;
    my $can_bus_nbr  = shift;

    my $data_ref_dummy;
    $data_ref_dummy->{0}->{'DLC'}  = "0";
    $data_ref_dummy->{0}->{'DATA'} = "0";

    my ( $msg_cnt, $all_msgs );

    unless ( defined($can_message) )
    {
        S_set_error( "SYNTAX: CAN_trace_get_data_can_frame( can_log_file , can_message , can_bus_nbr)", 110 );
        return $data_ref_dummy;
    }

    unless ( defined $can_bus_nbr )
    {
        $can_bus_nbr = 1;
    }

    return 1 if $main::opt_offline;    # just return if running in offline mode

    #    my $Trace_FH = new FileHandle;
    my $trace_FH = FileHandle->new;

    unless ( $trace_FH->open($can_log_file) ) { S_set_error( " Couldnt open CAN Trace '$can_log_file' ", 131 ); return $data_ref_dummy; }

    $msg_cnt = 0;
    S_w2log( 4, " CAN_trace_get_data_can_frame : Reading CAN frame '$can_message' on Bus-Nbr $can_bus_nbr from $can_log_file)\n" );

    while (<$trace_FH>)
    {
        ## try to match:
        ##      0.0171 1  Bremse_1   Rx   d 8 00 18 00 00 FE FE 00 18
        if (
            /^
          \s*        # leading spaces
          (\d+\.\d+)    # timestamp
          \s+        # spaces
          $can_bus_nbr     # bus ID must be right !!!
          \s+        # spaces
          $can_message
          \s+        # spaces
          [TxRq]+      # match Rx or Tx or TxRq
          \s+        # spaces
          d
          \s+        # spaces
          (\d+)      # DLC
          ([\d\sa-f]+)   # all Data unil end of line or non hex value
          /ix
          )
        {
            $msg_cnt++;
            my $time = sprintf( "%010.3f", $1 * 1000 );
            my $dlc  = $2;
            my $data = $3;
            $data =~ s/\s+$//;    # remove trailing spaces
            $all_msgs->{$time}{'DLC'}  = $dlc;
            $all_msgs->{$time}{'DATA'} = $data;
        }
    }
    $trace_FH->close;

    S_w2log( 3, " CAN_trace_get_data_can_frame : Found $can_message -> $msg_cnt times\n" );

    return $all_msgs;
}

######################################################

=head2 CAN_trace_get_data_can_signal

    $signal_data_ref = CAN_trace_get_data_can_signal( $found_messages , $can_signal , $data_format );

Reads a single Signal from a message data ref read by CAN_trace_get_data_can_frame.

 e.g. $found_messages = {
                     timestamp1 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                     timestamp2 => {
                                    'DATA' =>  '00 18 00 00 FE FE 00 18',
                                    },
                   };

$can_signal is the name of CAN signal in LIFT CAN Mapping

$data_format is format of data in CAN trace : 'dec' or 'hex'

Returns hash ref structure:

      $signal_data_ref = {
                           $timestamp1 => $raw_value1,
                           $timestamp2 => $raw_value2,
                        };

The Values are already the needed

=cut

######################################################
sub CAN_trace_get_data_can_signal
{

    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $all_msgs    = shift;
    my $can_signal  = shift;
    my $data_format = shift;    ### DEC or HEX

    my $data_ref_dummy;
    $data_ref_dummy->{0} = "0";

    my (
         $data_raw,
         @data_list,
         $signal_length,
         $signal_format,           ### INTEL or MOTOROLA
         $can_frame_bin,
         $can_frame_bin_display,
         $byte_value,
         $start_bit,
         $byte_bin_lsb,
         $signal_lsb,
         $signal_msb,
         $signal_raw_value,
         $sig_data_ref,
         $dlc,
         $temp_sig_pos_start,
         $temp_can_frame_bin,
    );

    unless ( defined($data_format) )
    {
        S_set_error( "CAN_trace_get_data_can_signal: SYNTAX: CAN_trace_get_data_can_signal ( message_ref, can_signal, base_format )", 110 );
        return $data_ref_dummy;
    }

    unless ( $data_format =~ /dec/i or $data_format =~ /hex/i )
    {
        S_set_error( "CAN_trace_get_data_can_signal: parameter 'base' must be 'dec' or 'hex'", 110 );
        return $data_ref_dummy;
    }

    $signal_length = $CANMapping->{$can_signal}{'LENGTH'};
    unless ( defined $signal_length )
    {
        S_set_error( " CAN_trace_get_data_can_signal: no 'LENGTH' defined for LC signal '$can_signal' in CAN MAPPING\n", 109 );
        return $data_ref_dummy;
    }

    $signal_format = $CANMapping->{$can_signal}{'FORMAT'};
    unless ( defined $signal_format )
    {
        S_set_error( " CAN_trace_get_data_can_signal: no 'FORMAT' defined for LC signal '$can_signal' in CAN MAPPING\n", 109 );
        return $data_ref_dummy;
    }
    unless ( $signal_format =~ /INTEL/i or $signal_format =~ /MOTOROLA/i )
    {
        S_set_error( "CAN_trace_get_data_can_signal: 'FORMAT' of signal '$can_signal' in CAN Mapping must be INTEL or MOTOROLA", 110 );
        return $data_ref_dummy;
    }

    $start_bit = $CANMapping->{$can_signal}{'STARTBIT'};
    unless ( defined $start_bit )
    {
        S_set_error( " CAN_trace_get_data_can_signal: no 'FORMAT' defined for LC signal '$can_signal' in CAN MAPPING\n", 109 );
        return $data_ref_dummy;
    }

    S_w2log( 4, " CAN_trace_get_data_can_signal : extracting signal $can_signal at startbit: $start_bit, length: $signal_length format: $signal_format\n" );

    return $data_ref_dummy if $main::opt_offline;    # just return if running in offline mode

    foreach my $time_stamp ( sort { $a <=> $b } keys %$all_msgs )
    {
        $data_raw = $all_msgs->{$time_stamp}{'DATA'};
        $data_raw =~ s/^\s+//g;                      ## remove possible leading spaces
                                                     #S_w2log( 1, " data_raw  : $data_raw  \n" );
        ## convert string to list of data bytes ( $data_list[0] eq CAN Byte 0)
        @data_list             = split( /\s+/, $data_raw );
        $can_frame_bin         = "";                          ## CAN frame binary format (LSB)
        $can_frame_bin_display = "";                          ## CAN frame binary format (LSB)

        foreach my $data_byte (@data_list)
        {
            ## converts 'F0' into '00001111' (LSB format) (starting with lowest significant bit))
            ##   PERL lesson:
            ##                 - 'hex $data_byte' interprete given value as hexadecimal value
            ##                 - 'sprintf( "%08b",...' format the given value into 8bit format (MSB)
            ##                 - 'reverse' sort the given scalar in opposite order (that means: MSB to LSB)
            if    ( $data_format =~ /hex/i )        { $byte_value   = hex $data_byte; }
            elsif ( $data_format =~ /dec/i )        { $byte_value   = $data_byte; }
            if    ( $signal_format =~ /INTEL/i )    { $byte_bin_lsb = reverse sprintf( "%08b", $byte_value ); }
            elsif ( $signal_format =~ /MOTOROLA/i ) { $byte_bin_lsb = sprintf( "%08b", $byte_value ); }

            #S_w2log( 1, " byte_bin_lsb : $byte_bin_lsb ($data_byte , $byte_value )\n" );
            ## create the full CAN message by concatinating all bytes (binary LSB)
            $can_frame_bin .= $byte_bin_lsb;
            $can_frame_bin_display .= $byte_bin_lsb . ' ';
        }

        #S_w2log( 1, " can_frame_bin : $can_frame_bin_display \n" );

        if ( $signal_format =~ /INTEL/i )
        {
            $signal_lsb = substr( $can_frame_bin, $start_bit, $signal_length );
        }
        elsif ( $signal_format =~ /MOTOROLA/i )
        {
            $temp_can_frame_bin = reverse $can_frame_bin;
            $dlc                = $all_msgs->{$time_stamp}{'DLC'};
            $temp_sig_pos_start = $dlc * 8 - ( ( $start_bit >> 3 ) << 3 ) - ( 7 + ( ( $start_bit >> 3 ) << 3 ) - $start_bit );
            $signal_lsb         = substr( $temp_can_frame_bin, $temp_sig_pos_start - $signal_length, $signal_length );
        }
        $signal_msb                  = reverse $signal_lsb;
        $signal_raw_value            = unpack( "N", pack( "B32", substr( "0" x 32 . $signal_msb, -32 ) ) );
        $sig_data_ref->{$time_stamp} = $signal_raw_value;

        #S_w2log( 1, " CAN_trace_get_data_can_signal: [$time_stamp] Found Signal (LSB->MSB->DEC): $signal_lsb -> $signal_msb -> $signal_raw_value (Sig:$can_signal : frame data: $can_frame_bin_display ) \n");
    }

    S_w2log( 3, "CAN_trace_get_data_can_signal: Read Signal $can_signal data from CAN message Successfully \n " );

    return $sig_data_ref;
}

######################################################

=head2 CAN_get_env_variable

 EnvVarObject = CAN_get_env_variable ( EnvVarName );

=cut

######################################################
sub CAN_get_env_variable
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $env_var    = shift;

    unless ( defined $env_var )
    {
        S_set_error( " SYNTAX: CAN_get_env_variable( EnvVarName )", 110 );
        return 1;
    }

    return 1 if $main::opt_offline;

    my ( $return_env_var_handle, $device, $hostname );

    unless ( $return_env_var_handle = $ole_handle->Application->Environment->GetVariable($env_var) )
    {
        $device   = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'DeviceType'};
        $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};
        S_set_error( " $device application on $hostname : No environment variable '$env_var' available ", 0 );
        return 1;
    }

    S_w2log( 5, " CAN_get_env_variable: return object handle of EnvVar: $env_var \n" );

    return $return_env_var_handle;
}

######################################################

=head2 CAN_get_EnvVar_value

 EnvVarValue = CAN_get_EnvVar_value ( EnvVarName );

 returns scalar value for EnvVar type Integer, Float, String
 returns array_ref of dec values if EnvVar type is Data

=cut

######################################################
sub CAN_get_EnvVar_value
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $env_var    = shift;
    my $return_env_var_value;

    unless ( defined $env_var )
    {
        S_set_error( " SYNTAX: CAN_get_EnvVar_value( EnvVarName )", 110 );
        return 1;
    }

    return 1 if $main::opt_offline;

    my $handle = CAN_get_env_variable($env_var);

    unless ( defined $handle )
    {
        S_set_error( " $env_var not defined in CANoe", 114 );
        return 1;
    }

    my $type = $handle->Type();

    #( 0: Integer, 1: Float, 2: String, 3: Data)

    if ( $type == 3 )
    {
        my @temp = split( //, $handle->{'Value'} );
        foreach (@temp)
        {
            $_ = ord($_);
        }
        $return_env_var_value = \@temp;
        S_w2log( 5, " CAN_get_EnvVar_value: EnvVar: $env_var array: @temp\n" );

    }
    else
    {
        $return_env_var_value = $handle->{'Value'};
        S_w2log( 5, " CAN_get_EnvVar_value: EnvVar: $env_var value: $return_env_var_value\n" );
    }

    return $return_env_var_value;
}

######################################################

=head2 CAN_set_EnvVar_value

 CAN_set_EnvVar_value ( EnvVarName, EnvVarValue );

 expects EnvVarValue as scalar value for EnvVar type Integer, Float, String
 expects EnvVarValue as array_ref if EnvVar type is Data
 Integer and Data may be hex or dec or bin.

=cut

######################################################
sub CAN_set_EnvVar_value
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $env_var    = shift;
    my $value      = shift;

    unless ( defined $value )
    {
        S_set_error( " SYNTAX: CAN_set_EnvVar_value ( EnvVarName, EnvVarValue )", 110 );
        return;
    }

    return 1 if $main::opt_offline;

    my $handle = CAN_get_env_variable($env_var);

    unless ( defined $handle )
    {
        S_set_error( " $env_var not defined in CANoe", 114 );
        return;
    }

    my $type = $handle->Type();

    #( 0: Integer, 1: Float, 2: String, 3: Data)

    if ( $type == 3 )
    {
        if ( ref($value) ne "ARRAY" )
        {
            S_set_error( " EnvVarValue is not an array reference, but EnvVar type is Data", 114 );
            return;
        }
        my @temp = @$value;
        foreach (@temp)
        {
            $_ = S_0x2dec($_);
        }
        $handle->{'Value'} = \@temp;
        S_w2log( 5, " CAN_set_EnvVar_value: EnvVar: $env_var set to array: @temp \n" );

    }
    elsif ( $type == 0 )
    {
        $value = S_0x2dec($value);
        $handle->{'Value'} = $value;
        S_w2log( 5, " CAN_set_EnvVar_value: EnvVar: $env_var set to value: $value \n" );
    }
    else
    {
        $handle->{'Value'} = $value;
        S_w2log( 5, " CAN_set_EnvVar_value: EnvVar: $env_var set to value: $value \n" );
    }

    return 1;
}

######################################################

=head2 CAN_get_signal_variable

 SignalObject = CAN_get_signal_variable ( Channel, Message, SignalName );

=cut

######################################################
sub CAN_get_signal_variable
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $channel    = shift;
    my $message    = shift;
    my $sig_name   = shift;

    unless ( defined $sig_name )
    {
        S_set_error( " SYNTAX: CAN_get_signal_variable( SignalName )", 110 );
        return 1;
    }

    return 1 if $main::opt_offline;

    my ( $return_sig_handle, $device, $hostname );

    unless ( $return_sig_handle = $ole_handle->Application->Bus->GetSignal( $channel, $message, $sig_name ) )
    {
        $device   = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'DeviceType'};
        $hostname = $CAN_tool_control->{'OLE_handles'}{$ole_handle}{'Hostname'};
        S_set_error( " $device application on $hostname : No signal variable '$sig_name' available for message $message on channel $channel", 0 );
        return 1;
    }

    S_w2log( 5, " CAN_get_signal_variable: return object handle of Signal: $sig_name \n" );

    return $return_sig_handle;
}

######################################################

=head2 CAN_get_Signal_value

 SignalValue = CAN_get_Signal_value ( Channel, Message, SignalName );

 returns scalar value for Signal

=cut

######################################################
sub CAN_get_Signal_value
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $channel    = shift;
    my $message    = shift;
    my $sig_name   = shift;
    my $return_sig_value;

    unless ( defined $sig_name )
    {
        S_set_error( " SYNTAX: CAN_get_Signal_value ( Channel, Message, SignalName )", 110 );
        return 0;
    }

    return 1 if $main::opt_offline;

    my $handle = CAN_get_signal_variable( $channel, $message, $sig_name );
    $return_sig_value = $handle->{'Value'};
    S_w2log( 5, " CAN_get_Signal_value: Signal: $sig_name value: $return_sig_value\n" );

    return $return_sig_value;
}

######################################################

=head2 CAN_set_Signal_value

 CAN_set_Signal_value ( Channel, Message, SignalName, SignalValue );

 SignalValue may be hex or dec or bin.

=cut

######################################################
sub CAN_set_Signal_value
{
    #warning message to indicate LIFT_canoe.pm becoming obselete soon and to use LIFT_can_access.pm functions instead. 
    CANoe_phaseout_warning();
    
    my $ole_handle = $CANoe_OLE_handle;
    my $channel    = shift;
    my $message    = shift;
    my $sig_name   = shift;
    my $value      = shift;

    unless ( defined $value )
    {
        S_set_error( " SYNTAX: CAN_set_Signal_value ( Channel, Message, SignalName, SignalValue )", 110 );
        return;
    }

    return 1 if $main::opt_offline;

    my $handle = CAN_get_signal_variable( $channel, $message, $sig_name );

    $value = S_0x2dec($value);
    $handle->{'Value'} = $value;
    S_w2log( 5, " CAN_set_Signal_value: Signal: $sig_name value set to value: $value \n" );

    return;
}

######################################################

=head2 CANoe_phaseout_warning

 CANoe_phase_out_warning();

 This function shall be called internally everytime a functionality from LIFT_Canoe is called to indicate a warning of the module becoming obselete soon and the functionalities from LIFT_can_access.pm to be used in future.  

=cut

######################################################
sub CANoe_phaseout_warning
{
    S_set_warning( " The function will become obselete soon. Please use functions from LIFT_can_access.pm module");
    return 1;
}

1;