package AFG332x0;

use strict;
use warnings;
use File::Basename;

# need to add in calling module
BEGIN
{
	use LIFT_general;
	S_add_paths2INC(['../GPIB', '../GPIB/GPIB'], []);
}


use GPIB;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use AFG332x0 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
    
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our ($VERSION,$HEADER);


=head1 NAME

AFG332x0 

Perl extension for AFG Agilent 332x0A

=head1 SYNOPSIS

    use AFG332x0;

    my ($afg, $value, $string, $duration);

    $afg = AFG332x0->new(\*LOG);
    $afg->connect('GPIB:2');

    $afg->restoreConfig($LIFT_config::LIFT_PARA_path.'/HW_Test1_AFG1-config.txt');
    $afg->newVolatileWF();
    $afg->setWFVoltage(0, 0.1);
    $afg->setWFVoltage(7, 31.9);
    $afg->setWFVoltage(0, 32);
    $afg->sendWaveForm();


    $afg->disconnect();


=head1 DESCRIPTION

remote control functions for AFG Agilent 332x0 via GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut


=head1 CONSTRUCTOR

=head2 $afg = AFG332x0->new(\*LOG);

creates an instance of a AFG332x0 object and returns its handle

writes into give logfile, if no filehandle is given, log_AFGpm.txt is created, 

=cut


my $AFG_handle;
my $logfile_handle;


sub new {
    my $class = shift;
    $logfile_handle=shift;
    unless ($logfile_handle) {
        open ( AFGLOG,">log_AFGpm.txt" ) or die "Couldn't open logfile : $@";
        $logfile_handle = \*AFGLOG;
    }
    my $self = {};
    bless ($self, $class);
    w2log("creating new AFG332x0 instance\n");
    $self->{connected} = 0; # set connencted flag to false
    $self->{ID} = "";
    return $self;
}


######### advanced functions ##########

=head1 ADVANCED METHODS

=cut


############################################################################################################

=head2 $DeviceID = $afg->connect($connection);

Connnect to AFG via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used. Note that this method does not reset the AFG. Use function reset(); for this purpose.

A valid connection is e.g. 'GPIB:8'. Make sure the device is configured accordingly !

=cut

sub connect {
    my $self = shift;

    my $mode;
    my $connection = shift;
    w2log("connecting with AFG332x0 via <$connection>\n");

    if($connection =~ /GPIB:\s*(\d+)/i){

        $self->{GPIB} = GPIB->new("GPIB::ni", 0, $1, 0, GPIB->T300ms, 1, 0);   
        $AFG_handle = $self->{GPIB};


        #        $AFG_handle -> ibwrt("*RST");
        $AFG_handle -> ibwrt("*IDN?");
        my $DeviceID = readString($self);
        #        $AFG_handle -> ibwrt("*CLS");
        chomp($DeviceID);
        w2log("Device is <$DeviceID>\n");
        $self->{connected} = 1; # set connencted flag to true
        $self->{ID} = "{$DeviceID}";
        return($DeviceID);

    }
    else{
        w2log("ERROR: connection error for AFG332x0 on <$connection>\n");
        $self->{connected} = 0; # set connencted flag to false
    }

}




############################################################################################################

=head2 $afg->disconnect();

Disconnect from AFG

=cut

sub disconnect{
    my $self = shift;
    $AFG_handle = $self->{GPIB};
    w2log("disconnecting AFG332x0 $self->{ID}\n");
    undef $self->{ID};
    $self->{connected} = 0; # set connencted flag to false

}


############################################################################################################

=head2 $afg->saveConfig($configfile, [$comment]);

save configuration to file

=cut

sub saveConfig{
    my $self = shift;
    $AFG_handle = $self->{GPIB};
    my $filename = shift;
    my $Comment = shift;
    $Comment = "" unless (defined $Comment);

    $AFG_handle -> ibwrt("*LRN?");
    my $config = readString($self);

    open ( OUT,">$filename" ) or die "Couldn't open $_ : $@";
    print OUT "DeviceModel=".$self->{ID}."\n";
    print OUT "Comment=".$Comment."\n";
    print OUT $config."\n";
    close(OUT);

    w2log("settings saved to $filename\n");
}



############################################################################################################

=head2 $afg->restoreConfig($configfile);

restore configuration from file.

=cut

sub restoreConfig{
    my $self = shift;
    $AFG_handle = $self->{GPIB};
    my $setup = shift;
    my ($Settings,$ConfigModel,$Comment);
    open ( IN,"<$setup" ) or die "Couldn't open $_ : $@";
    $ConfigModel=<IN>;
    $Comment=<IN>;
    $Settings=<IN>;
    close(IN);
    chomp($Settings);
    chomp($ConfigModel);
    chomp($Comment);
    $ConfigModel =~ s/^DeviceModel=//; #cut off tag
    $Comment =~ s/^Comment=//; #cut off tag

    w2log("restore settings from <".$setup.">\n");
    # write Settings as query
    writeString($self,$Settings);
    wait_ms(1000);
    checkError($self);

    if ($self->{ID} ne $ConfigModel){
        w2log("warning: current device is <".($self->{ID})."> config created with <$ConfigModel>\n");
    }
    else{w2log("settings restored\n");}

}



############################################################################################################

=head2 $value = $afg->checkError();  NOT IMPLEMENTED, just returns

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub checkError{
    return;

    my $self    = shift;
    $AFG_handle = $self->{GPIB};
    my ($ESRresp, $ERRresp);

    $AFG_handle->ibwrt('*ESR?');             
    $ESRresp = readString($self);           # Read result
    unless (defined($ESRresp) ){
        w2log("?retry status check\n");
        $AFG_handle->ibwrt('*ESR?');             
        $ESRresp = readString($self);           # Read result
        unless (defined($ESRresp) ){
            w2log("!comminication error: no staus received\n");
            return;
        }
    }
    chomp($ESRresp);
    if ($ESRresp > 0){
        $AFG_handle->ibwrt('ERR?');             
        $ERRresp = readString($self);           # Read result
        chomp($ERRresp);
        if ($ERRresp !~ /^0,/) {
            w2log("!error: ESR is $ESRresp, ERR is $ERRresp\n");
        }
    }  
}


############################################################################################################

=head2 $afg->reset();

Resets and clears the AFG.
The GPIB Commands used are *RST and *CLS.

=cut

sub reset{
    my $self = shift;

    $AFG_handle -> ibwrt("*RST");
    $AFG_handle -> ibwrt("*CLS");
}


############################################################################################################

=head2 $afg->on();

set output to ON.
The GPIB Command used is OUTPut ON.

=cut

sub on{
    my $self = shift;

    writeString($self,"OUTPut ON"); 
    checkError($self);
}



############################################################################################################

=head2 $afg->off();

set output to OFF. (AFG will continue running any curves, etc.)
The GPIB Command used is OUTPut OFF.

=cut

sub off{
    my $self = shift;

    writeString($self,"OUTPut OFF"); 
    checkError($self);
}


############################################################################################################

=head2 $afg->amplitude($voltage);

set output voltage amplitude, note that this does NOT set any offset.
To set voltage and offset with one function call,
use $afg->voltageDC($voltage) instead.
The GPIB Command used is VOLTage.

=cut

sub amplitude{
    my $self = shift;
    my $voltage = shift;

    writeString($self,"VOLTage $voltage"); 
    checkError($self);
}


############################################################################################################

=head2 $afg->voltageDC($DCvoltage);

set output voltage to DC. Attention: If the AFG's output load is 50 Ohm (default
setting), the DC voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

Expects VOLTage:RANGe:AUTO is ON (default setting).

The GPIB Commands used are FUNCtion DC, OUTPut:LOAD?, VOLTage:OFFSet, .

=cut

sub voltageDC{
    my $self = shift;
    my $DCvoltage = shift;
    my $DCvoltageDiv2 = $DCvoltage/2;
      
    writeString($self, "FUNCtion DC");
    writeString($self, "OUTPut:LOAD?");
    if (readString($self) == 50) {
        writeString($self,"VOLTage:OFFSet $DCvoltageDiv2");
    } else {
        writeString($self,"VOLTage:OFFSet $DCvoltage");
    }
    checkError($self);
}


############################################################################################################

=head2 $afg->highLevel($voltage);

set output's high level to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

The GPIB Commands used are VOLTage:HIGH, OUTPut:LOAD?.

=cut

sub highLevel{
    my $self        = shift;
    my $voltage     = shift;
      
    writeString($self, "OUTPut:LOAD?");
    if (readString($self) == 50) {
        writeString($self,"VOLTage:HIGH ". $voltage/2);
    } else {
        writeString($self,"VOLTage:HIGH ". $voltage);
    }
    checkError($self);
}


############################################################################################################

=head2 $afg->lowLevel($voltage);

set output's low level to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

The GPIB Commands used are VOLTage:LOW, OUTPut:LOAD?.

=cut

sub lowLevel{
    my $self        = shift;
    my $voltage     = shift;

    writeString($self, "OUTPut:LOAD?");
    if (readString($self) == 50) {
        writeString($self,"VOLTage:LOW ". $voltage/2);
    } else {
        writeString($self,"VOLTage:LOW ". $voltage);
    }
    checkError($self);
}


############################################################################################################

=head2 $afg->offset($voltage);

set output's offset to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

The GPIB Commands used are OUTPut:LOAD?, VOLTage:OFFSet.

=cut

sub offset{
    my $self        = shift;
    my $voltage     = shift;
    
    writeString($self, "OUTPut:LOAD?");
    if (readString($self) == 50) {
        writeString($self,"VOLTage:OFFSet ". $voltage/2);
    } else {
        writeString($self,"VOLTage:OFFSet ". $voltage);
    }
    checkError($self);
}


############################################################################################################

=head2 $afg->frequency($frequency);

set the AFG's frequency (given in Hertz)

The GPIB Command used is FREQuency

=cut

sub frequency{
    my $self        = shift;
    my $frequency   = shift;
      
    writeString($self,"FREQuency ". $frequency);
    checkError($self);
}


############################################################################################################

=head2 $afg->period($period);

set the AFG's period (given in seconds - calls function frequency(1/$period)).

=cut

sub period{
    my $self   = shift;
    my $period = shift;

    frequency($self, 1/$period);      
}


############################################################################################################

=head2 $afg->polarity($polarity);

set output polarity. Use $afg->polarity("INV") to invert polarity, all other values for normal polarity.
The GPIB Command used is OUTPut:POLarity.

=cut

sub polarity{
    my $self     = shift;
    my $polarity = shift;

    # uc changes to upper case
    if ((uc($polarity) eq "INV") or (uc($polarity) eq "INVerted")){
        writeString($self,"OUTPut:POLarity INVerted");
    } else {
        writeString($self,"OUTPut:POLarity NORMal");
    }  
    checkError($self);
}


############################################################################################################

=head2 $afg->triggerSource($triggerSource);

set Trigger Source to {IMMediate|EXTernal|BUS}. Example: $afg->AFGTriggerSource("BUS");
to use Trigger via GPIB. (Shortforms {IMM|EXT|BUS} may be used.)
The GPIB Command used is TRIGger:SOURce {IMMediate|EXTernal|BUS}.

=cut

sub triggerSource{
      my $self = shift;
      my $triggerSource = shift;
      
  # uc changes to upper case
  if ((uc($triggerSource) eq "IMMediate") or (uc($triggerSource) eq "IMM")) {
    writeString($self,"TRIGger:SOURce IMMediate");
  } elsif ((uc($triggerSource) eq "EXTernal") or (uc($triggerSource) eq "EXT")) {
    writeString($self,"TRIGger:SOURce EXTernal");
  } elsif (uc($triggerSource) eq "BUS") {
    writeString($self,"TRIGger:SOURce BUS");
  } 
  checkError($self);
}


############################################################################################################

=head2 $afg->trigger();

Trigger AFG via GPIB (BUS). Note that the AFG must be in trigger Mode BUS
($afg->AFGTriggerSource("BUS");).
The GPIB Command used is TRIGger.

=cut

sub trigger{
    my $self = shift;

    writeString($self,"TRIGger");
    checkError($self);
}


############################################################################################################

=head2 $afg->burstPhase($phase);

Set the Burst mode's phase to $phase. Only makes sense when Burst Mode is active.
The GPIB Command used is BURSt:PHASe.

=cut

sub burstPhase{
    my $self = shift;
    my $phase = shift;

    writeString($self,"BURSt:PHASe $phase");
    checkError($self);
}


############################################################################################################

=head2 $afg->outputLoad($load);

Set the output load to the given Ohm value or to infinity (if parameter INFinity or INF used),
respectively MINimum or MAXimum. Parameter is directly sent to AFG without additional checks.

The GPIB Command used is OUTPut:LOAD {<ohms>|INFinity|MINimum|MAXimum}.

=cut

sub outputLoad{
    my $self = shift;
    my $load = shift;

    writeString($self,"OUTPut:LOAD $load");
    checkError($self);
}


############################################################################################################
######### User Generated Waveform functions ##########

=head1 User Generated Waveform METHODS

=cut

my @wfDataVoltage   = ();    # dummy array for user created waveform
my @wfDataDuration  = ();    # dummy array for user created waveform
my $wfHighVoltage;           # highest voltage in volts
my $wfLowVoltage;            # lowest voltage in volts
my $wfInterpolate   = 0;     # linear interpolate waveform? 1=yes, 0=no
my $wfTotalDuration = 0;     # the total duration, for period length
my $wfShortestDuration;      # the shortest duration, to check min sample points
my $wfDefautPoints  = 128;   # default number of points
my $wfPointsTotal;           # number of points if different number defined in newVolatileWF(...)
our $wfMaxTimeError = 0;     # maximum timing error. only accurate after waveform sent.

############################################################################################################

=head2 $afg->newVolatileWF([$interpolate[, $pointsTotal]]);

Create a new volatile waveform.

If $interpolate is non-zero, linear
interpolation is used, otherwise ($interpolate is 0 or not defined)
the previous value is continued to the next
datapoint (results in "steps"). This linear interpolation
is done by this program, not by the AFG, smoothness of the curve
depends on the number of datapoints.
By default, no interpolation is used.

The maximum number
of datapoints $pointsTotal (must be in range 2 ... 65536). Note that
the AFG 33220A uses internally either 16384 or 65536 points. Therefore
it is most accurate to use powers of 2.
By default, 128 is used to limit the amount of data transmitted, although
this program increases the number of points automatically if required.

For details it is referred to the AFG's manual.

No GPIB Commands used.

=cut

sub newVolatileWF{
    my $self        = shift;
    my $interpolate = shift;
    my $pointsTotal = shift;
    unless (defined $interpolate) {
        $interpolate = 0;
    }
    unless ($interpolate==0) {
        $interpolate = 1;
    }
    
    # parameter checks
    
    $pointsTotal = $wfDefautPoints unless (defined $pointsTotal);
    unless (($pointsTotal >= 2) and ($pointsTotal <= 65536)) {
        print "ERROR: \$pointsTotal=$pointsTotal must be in range 2 ... 65536!\n";
        return -1;
    }

    # delete any prev stored waveform
    @wfDataVoltage   = ();
    @wfDataDuration  = ();
    undef $wfHighVoltage;
    undef $wfLowVoltage;
    $wfInterpolate   = $interpolate;
    $wfTotalDuration = 0;
    undef $wfShortestDuration;
    $wfPointsTotal   =  $pointsTotal;
}


############################################################################################################

=head2 $afg->setWFVoltage($voltage, $duration);

Set a voltage for a specific duration. Note that when intrapolation is used, the voltage does
not necessarily remain at this level but is intrapolated to the next datapoint.

Therefore if you need the voltage to remain stable for a certain time your either need
to switch interpolation off in the function call newVolatileWF(...) or you need additional
sampling points ("St�tzstellen").

No GPIB Commands used.

=cut

sub setWFVoltage{
    my $self     = shift;
    my $voltage  = shift;
    my $duration = shift;

    # parameter checks
    unless (defined $voltage) {
        print "ERROR: \$voltage not defined!\n";
        return -1;
    }
    unless (defined $duration) {
        print "ERROR: \$duration not defined!\n";
        return -1;
    }
    if (0+$duration <=0) {
        print "ERROR: \$duration must be > 0!\n";
        return -1;
    }
    if (scalar(@wfDataVoltage) > 65536) {
        print "ERROR: Too many datapoints added. Max is 65536!\n";
        return -1;
    }
    # delete this one again
    $wfMaxTimeError = 0;
    
    # check highest respectively lowest voltage and shortest time
    # needed later when sending waveform
    if (defined $wfHighVoltage) {
        # always all of them are defined because they are defined in the else branch
        if (0+$voltage  > $wfHighVoltage)       { $wfHighVoltage       = $voltage; }
        if (0+$voltage  < $wfLowVoltage)        { $wfLowVoltage        = $voltage; }
        if (0+$duration < $wfShortestDuration)  { $wfShortestDuration  = $duration; }
    }
    else {
        $wfHighVoltage      = $voltage;
        $wfLowVoltage       = $voltage;
        $wfShortestDuration = $duration;
    }

    $wfTotalDuration += $duration;
    push(@wfDataVoltage,  $voltage);
    push(@wfDataDuration, $wfTotalDuration);
}



############################################################################################################

=head2 $afg->sendWaveForm();

Send waveform to AFG. After this function has been called, no datapoints can be added anymore and
you are starting again with a new waveform (same after calling newVolatileWF(...)).

Period is set to the sum of durations and voltage levels are adjusted. If the output is set to
50 Ohm, the voltages are divided by 2.

If the AFG's output was on, it is switched off before loading the waveform, then switched on again.

For details it is referred to the AFG's manual.

The GPIB Commands used are OUTPut?, DATA:DAC VOLATILE, FUNCtion:USER VOLATILE, FUNCtion:SHAPe USER

=cut

sub sendWaveForm{
    my $self = shift;
    
    ################################################
    # parameter check
    ################################################
    # scalar(@wfDataVoltage) is length of array
    # actually one point is enough, but since it does not make sense (is DC
    # voltage then)  we check for 2 - also it would be tricky with the interpolation then.
    if (scalar(@wfDataVoltage)<2) {
        print "ERROR: at least two points must be set before waveform\n";
        print "       can be sent to AFG. Not sending.\n";
        return -1;
    }
    
    my $n;
    my $i;
    my @waveFormArray;
    my $currVoltage;
    my $voltDelta;
    my $timePoint;
    my $maxTimeError=0;
    
    ################################################
    # crude check if number of sampling points sufficient, increase if not
    ################################################
    if (($wfTotalDuration/$wfPointsTotal) > $wfShortestDuration) {
        # adjust number of sample points, use powers of 2
        # start with 2^2=4, end with 2^16=65536, which is AFG's max
        $n = 2;
        while ($n <= 16) {
            $i = 2 ** $n; # 2 to the power of $n, in German: 2 hoch $n
            if (($wfTotalDuration/$i) <= $wfShortestDuration) {
                $wfPointsTotal=$i;
                $n=20; # used to exit loop as pass
            }
            $n++;
        }
        if ($n==17) {
            print " ERROR: Waveform not possible with max resolution 65536 datapoints!\n";
            print "        Shortest duration=$wfShortestDuration cannot be\n";
            print "        reached in period length \$wfTotalDuration=$wfTotalDuration.\n";
            return -1;
        }
        
        print "WARNING: Adjusting number of sample points to \$wfPointsTotal=$wfPointsTotal\n";
        print "         Shortest duration=$wfShortestDuration ms could not be\n";
        print "         reached with prior used sample points.\n";
    }


    ################################################
    # create an array with all sampling points. The distance
    # in this array is equivalent to the time values
    ################################################
    $n=0;
    # scalar(@wfDataVoltage) is length of array.
    # To make interpolation between last and first point easier,
    # we add the first point again at the end,
    # therefore we let the while loop run to the
    # penultimate ("vorletzter") point, which is then the last in our case
    push (@wfDataVoltage,  $wfDataVoltage[0]);
    while ($n<scalar(@wfDataVoltage)-1) {
        # add voltage (initial value)
        push (@waveFormArray, $wfDataVoltage[$n]);

        # calculate timepoint and convert to integer position in array
        $timePoint = $wfDataDuration[$n]/($wfTotalDuration/$wfPointsTotal);
        $timePoint = int($timePoint + .5 * ($timePoint <=> 0));
        # calculate maximum error
        if (abs($timePoint-$wfDataDuration[$n]/($wfTotalDuration/$wfPointsTotal)) > $maxTimeError) {
            $maxTimeError=abs($timePoint-$wfDataDuration[$n]/($wfTotalDuration/$wfPointsTotal));
        }

        # interpolate
        if ($wfInterpolate==1) {
            $voltDelta=($wfDataVoltage[$n+1]-$wfDataVoltage[$n])/($timePoint-scalar(@waveFormArray)+1);
        }
        else {
            $voltDelta=0;
        }
        $currVoltage=$wfDataVoltage[$n];
        while (scalar(@waveFormArray) < $timePoint) {
            $currVoltage+=$voltDelta; # $voltDelta==0 when no interpolation
            push(@waveFormArray, $currVoltage);
        }
        $n++;
    }
    $maxTimeError   = $maxTimeError*($wfTotalDuration/$wfPointsTotal);
    $wfMaxTimeError = $maxTimeError;
    print "INFO: maximum timing error: $maxTimeError ms (neglecting the AFG's internal error)\n";
    
    ################################################
    # convert waveform voltages to integer values
    ################################################
    my $maxPoint;
    my $voltage;
    my $mVperLSB;
    
    if ($wfHighVoltage > -$wfLowVoltage) { $maxPoint = $wfHighVoltage; }
    else                                 { $maxPoint = -$wfLowVoltage; }
    $mVperLSB = $maxPoint / 8192;
    $n        = 0;

    while ($n < scalar(@waveFormArray)) {
        $voltage = $waveFormArray[$n];
        # convert all voltages to values between +/-8191
        $voltage = $voltage/$mVperLSB;
        # round voltage to integer values
        $voltage = int($voltage + .5 * ($voltage <=> 0));
        $voltage =  8191 if ($voltage >   8191); # clip, just to be sure
        $voltage = -8191 if ($voltage <  -8191); # clip, just to be sure
        $waveFormArray[$n] = $voltage;        
        $n++;
    }
    
    ################################################
    # finally, waveform array is complete - now we can send it to the AFG
    ################################################
    my $outputState;
    my $waveFormString;

    # switch off output, if on
    writeString($self, "OUTPut?");
    $outputState = $self->readString();
    if ($outputState == 1) { $self->off(); }

    # set voltages and frequency, to be sure
    # the auto range does not do something messy
    $self->highLevel($wfHighVoltage);
    $self->lowLevel( $wfLowVoltage);
    $self->frequency(1000/$wfTotalDuration);
    
    # send waveform
    $waveFormString=join(',', @waveFormArray);
    $self->writeString("DATA:DAC VOLATILE, $waveFormString");
    $self->checkError();
    $self->writeString("FUNCtion:USER VOLATILE");
    $self->checkError();
    $self->writeString("FUNCtion:SHAPe USER");
    $self->checkError();

    # set voltages and frequency - again in case
    # the auto range has done something messy
    $self->highLevel($wfHighVoltage);
    $self->lowLevel( $wfLowVoltage);
    $self->frequency(1000/$wfTotalDuration);
    
    # switch on output, if it had been on
    if ($outputState == 1) { $self->on(); }
    
    # erase the waveform data
    $self->newVolatileWF();
}

############################################################################################################

=head2 $afg->getWfMaxTimeError();

Returns the maximum time error after a waveform has been sent to the AFG, excluding AFG
internal timing errors. Results are only useful if called directly after sendWaveForm function.

No GPIB Commands used.

=cut

sub getWfMaxTimeError{
    return $wfMaxTimeError;
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 $afg->writeString($string);

write string directly to AFG

=cut

sub writeString{
  my $self     = shift;
  my $string   = shift;
  my $noOutput = shift;
  
  $AFG_handle = $self->{GPIB};
  unless (defined $noOutput) { w2log("writing <$string> to $self->{ID}\n") }
  $AFG_handle -> ibwrt($string);   
}



############################################################################################################

=head2 $string = $afg->readString();

read string directly from AFG

=cut

sub readString{
  my $self = shift;

  $AFG_handle = $self->{GPIB};
   my ($string,$STB,$i);
    # poll for MAV bit max 5 sec
    for ($i=0; $i<500; $i++){
        $STB = 256+($AFG_handle -> ibrsp());
        last if (($STB & 16) == 16);
        # sleep 10 msec
        wait_ms(10);        
    }
   
    if ($i>499){
        w2log("!communication timeout while reading from $self->{ID}\n");
        return("");
    }
   
    wait_ms(10);        
    $string = $AFG_handle -> ibrd(10240);
    unless (defined($string)){
        w2log("?retry reading from $self->{ID}\n");
        $string = $AFG_handle -> ibrd(10240);
        unless (defined($string)){
            w2log("!communication error while reading from $self->{ID}\n");
            return("");
        }
    }
    chomp($string);
    w2log("reading <$string> from $self->{ID}\n");
    return($string);
}



############################################################################################################

=head2 $value = $afg->isConnected();

check if AFG is connected returns 1 if true, 0 if false

=cut

sub isConnected{
    my $self = shift;
    return($self->{connected});
}



##################################
# Logfile handling
##################################
sub w2log{
     my $text = shift;
     print $logfile_handle $text if (defined $logfile_handle);
     print $text;
}


sub wait_ms{
    my $time = shift;    
    if ( $time > 0) {$time = $time/1000;}
    select(undef, undef, undef, $time);   #sleep for X ms
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Roger Hartmann, E<lt>Roger.Hartmann@de.BOSCH.comE<gt>
Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, AFG manual.

=cut
