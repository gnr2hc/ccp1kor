package LIFT_AFG1;

use strict;
use warnings;
use File::Basename;
use LIFT_general;

BEGIN
{
    use LIFT_general;
    S_add_paths2INC(['../GPIB', '../GPIB/GPIB', '../GPIB/Win32'], []);
}

use AFG332x0;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration   use TOE8805 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = (
    'all' => [
        qw(

          )
    ]
);

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
  AFG1_connect
  AFG1_disconnect
  AFG1_writeString
  AFG1_readString
  AFG1_outputLoad
  AFG1_burstPhase
  AFG1_trigger
  AFG1_triggerSource
  AFG1_polarity
  AFG1_voltageDC
  AFG1_amplitude
  AFG1_off
  AFG1_on
  AFG1_reset
  AFG1_checkError
  AFG1_restoreConfig
  AFG1_saveConfig
  AFG1_highLevel
  AFG1_lowLevel
  AFG1_offset
  AFG1_frequency
  AFG1_period
  AFG1_newVolatileWF
  AFG1_setWFVoltage
  AFG1_sendWaveForm
);

our ( $VERSION, $HEADER );

=head1 NAME

LIFT_AFG1 

Perl extension for AFG Agilent 332x0A arbitrary frequency generator

=head1 SYNOPSIS

    use LIFT_AFG1;

    my ($value, $string, $duration);

    AFG1_connect('GPIB:8');

    AFG1_restoreConfig("HW_Test1_AFG1-config.txt");
    AFG1_newVolatileWF();
    AFG1_setWFVoltage(0, 0.1);
    AFG1_setWFVoltage(7, 31.9);
    AFG1_setWFVoltage(0, 32);
    AFG1_sendWaveForm();

    AFG1_writeString('*IDN');
    $value = AFG1_readString();
    AFG1_outputLoad(2000);
    AFG1_burstPhase(1);
    AFG1_trigger();
    AFG1_triggerSource('EXT');
    AFG1_polarity('NORM');
    AFG1_voltageDC(12);
    AFG1_amplitude(12);
    AFG1_off();
    AFG1_on();
    AFG1_reset();
    AFG1_checkError();
    AFG1_saveConfig("$log_path/AFG1_save.cfg");
    AFG1_highLevel(12);
    AFG1_lowLevel(12);
    AFG1_offset(5);
    AFG1_frequency(20);
    AFG1_period(3);

    AFG1_disconnect();


=head1 DESCRIPTION

remote control functions for AFG Agilent 332x0A using GPIB.pm

B<NOTE: National Instruments driver for GPIB has to be installed !>

=cut

my $afg1;

######### advanced functions ##########

=head1 ADVANCED METHODS

=cut

############################################################################################################

=head2 AFG1_connect

    $DeviceID = AFG1_connect($connection);

Connnect to AFG via given connection, reads device identification (*IDN). This method has to be called first before any other method can be used.

A valid connection is e.g. 'GPIB:2'. Make sure power supply is configured accordingly !

debug return: 'dummy'

=cut

sub AFG1_connect
{
    my $connection = shift;

    unless ( defined($connection) )
    {
        S_set_error( "SYNTAX: DeviceID = AFG1_connect( connection )", 110 );
        return 1;
    }

    S_w2log( 4, "AFG1_connect: Initialize the connection\n" );

    return 'dummy' if $main::opt_offline;

    $afg1 = AFG332x0->new();

    S_w2log( 4, "AFG1_connect: Initialization of the connection\n" );
    return ( $afg1->connect($connection) );
}

############################################################################################################

=head2 AFG1_disconnect

    AFG1_disconnect();

Disconnect from AFG

=cut

sub AFG1_disconnect
{
    S_w2log( 4, "AFG1_disconnect: Disconnects the communication \n" );

    return 1 if $main::opt_offline;
    $afg1->disconnect();

    S_w2log( 5, "AFG1_disconnect: Disconnected the communication \n" );

}

############################################################################################################

=head2 AFG1_saveConfig

    AFG1_saveConfig($configfile, [$comment]);

save configuration to file

=cut

sub AFG1_saveConfig
{
    my $filename = shift;
    my $Comment  = shift;
    unless ( defined($filename) )
    {
        S_set_error( "SYNTAX: AFG1_saveConfig( configfile, [comment] )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1_saveConfig: File $filename to save the configuration\n" );

    if ($main::opt_offline)
    {
        S_create_dummy_file($filename);
        return 1;
    }
    $afg1->saveConfig( $filename, $Comment );
}

############################################################################################################

=head2 AFG1_restoreConfig

    AFG1_restoreConfig($configfile);

restore configuration from file.

=cut

sub AFG1_restoreConfig
{
    my $setup = shift;
    unless ( defined($setup) )
    {
        S_set_error( "SYNTAX: AFG1_restoreConfig( configfile )", 110 );
        return 1;
    }
    unless ( -f $setup )
    {
        S_set_error( "configfile $setup not found", 1 );
        return 1;
    }
    S_w2log( 4, "AFG1: restore config: Restores the configuration from $setup file\n" );
    return 1 if $main::opt_offline;
    $afg1->restoreConfig($setup);
}

############################################################################################################

=head2 AFG1_checkError

    $value = AFG1_checkError(); TO BE CHECKED, NOT REALLY IMPLEMENTED YET

(does not return anything, just calls $afg1->checkError();)

read error status (*ESR?,ERR?) and report error if there is one

=cut

sub AFG1_checkError
{
    S_w2log( 4, "AFG1: check Error: NOT IMPLEMENTED YET\n" );
    return 1 if $main::opt_offline;
    $afg1->checkError();
}

############################################################################################################

=head2 AFG1_reset

    AFG1_reset();

Resets and clears the AFG.

=cut

sub AFG1_reset
{
    S_w2log( 4, "AFG1_reset: Resets the AFG agilent\n" );
    return 1 if $main::opt_offline;
    $afg1->reset();
}

############################################################################################################

=head2 AFG1_on

    AFG1_on();

set output to ON.

=cut

sub AFG1_on
{
    S_w2log( 4, "AFG1: output ON\n" );
    return 1 if $main::opt_offline;
    $afg1->on();
}

############################################################################################################

=head2 AFG1_off

    AFG1_off();

set output to OFF. (AFG will continue running any curves, etc.)

=cut

sub AFG1_off
{
    S_w2log( 4, "AFG1: output OFF\n" );
    return 1 if $main::opt_offline;
    $afg1->off();
}

############################################################################################################

=head2 AFG1_amplitude

    AFG1_amplitude($voltage); TO_BE_CHANGED!

set output voltage amplitude, note that this does NOT set any offset.
To set voltage and offset with one function call,
use AFG1_voltageDC($voltage) instead.

=cut

sub AFG1_amplitude
{
    my $voltage = shift;
    unless ( defined($voltage) )
    {
        S_set_error( "SYNTAX: AFG1_amplitude( voltage )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: amplitude: $voltage\n" );
    return 1 if $main::opt_offline;
    $afg1->amplitude($voltage);
}

############################################################################################################

=head2 AFG1_voltageDC

    AFG1_voltageDC($DCvoltage);

set output voltage to DC. Attention: If the AFG's output load is 50 Ohm (default
setting), the DC voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

Expects VOLTage:RANGe:AUTO is ON (default setting).

The GPIB Commands used are FUNCtion DC, OUTPut:LOAD?, VOLTage:OFFSet, .

=cut

sub AFG1_voltageDC
{
    my $DCvoltage = shift;
    unless ( defined($DCvoltage) )
    {
        S_set_error( "SYNTAX: AFG1_voltageDC( DCvoltage )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: DC voltage: $DCvoltage\n" );
    return 1 if $main::opt_offline;
    $afg1->voltageDC($DCvoltage);
}

############################################################################################################

=head2 AFG1_highLevel

    AFG1_highLevel($voltage);

set output's high level to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

=cut

sub AFG1_highLevel
{
    my $voltage = shift;
    unless ( defined($voltage) )
    {
        S_set_error( "SYNTAX: AFG1_highLevel( voltage )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: high level voltage: $voltage\n" );
    return 1 if $main::opt_offline;
    $afg1->highLevel($voltage);
}

############################################################################################################

=head2 AFG1_lowLevel

    AFG1_lowLevel($voltage);

set output's low level to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

=cut

sub AFG1_lowLevel
{
    my $voltage = shift;
    unless ( defined($voltage) )
    {
        S_set_error( "SYNTAX: AFG1_lowLevel( voltage )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: low level voltage: $voltage\n" );
    return 1 if $main::opt_offline;
    $afg1->lowLevel($voltage);
}

############################################################################################################

=head2 AFG1_offset

    AFG1_offset($voltage);

set output's offset to $voltage. Attention: If the AFG's output load is 50 Ohm (default
setting), the voltage is divided by 2 here, because
the AFG outputs twice the voltage when it is set to 50 Ohm output. If
the termination is different from 50 Ohm, provided voltage value is used.

=cut

sub AFG1_offset
{
    my $voltage = shift;
    unless ( defined($voltage) )
    {
        S_set_error( "SYNTAX: AFG1_offset( voltage )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: offset voltage: $voltage\n" );
    return 1 if $main::opt_offline;
    $afg1->offset($voltage);
}

############################################################################################################

=head2 AFG1_frequency

    AFG1_frequency($frequency);

set the AFG's frequency (given in Hertz)

=cut

sub AFG1_frequency
{
    my $frequency = shift;
    unless ( defined($frequency) )
    {
        S_set_error( "SYNTAX: AFG1_frequency( frequency )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: frequency: $frequency\n" );
    return 1 if $main::opt_offline;
    $afg1->frequency($frequency);
}

############################################################################################################

=head2 AFG1_period

    AFG1_period($period);

set the AFG's period (given in seconds).

=cut

sub AFG1_period
{
    my $period = shift;
    unless ( defined($period) )
    {
        S_set_error( "SYNTAX: AFG1_period( period )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: period: $period\n" );
    return 1 if $main::opt_offline;
    $afg1->period($period);
}

############################################################################################################

=head2 AFG1_polarity

    AFG1_polarity($polarity);

set output polarity. Use AFG1_polarity("INV") to invert polarity, all other values for normal polarity.

=cut

sub AFG1_polarity
{
    my $polarity = shift;
    unless ( defined($polarity) )
    {
        S_set_error( "SYNTAX: AFG1_polarity( polarity )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: output polarity: $polarity\n" );
    return 1 if $main::opt_offline;
    $afg1->polarity($polarity);
}

############################################################################################################

=head2 AFG1_TriggerSource

    AFG1_TriggerSource($triggerSource);

set Trigger Source to {IMMediate|EXTernal|BUS}. Example: AFG1_triggerSource("BUS");
to use Trigger via GPIB. (Shortforms {IMM|EXT|BUS} may be used.)

=cut

sub AFG1_triggerSource
{
    my $triggerSource = shift;
    unless ( defined($triggerSource) )
    {
        S_set_error( "SYNTAX: AFG1_TriggerSource( triggerSource )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: Trigger source: $triggerSource\n" );
    return 1 if $main::opt_offline;
    $afg1->triggerSource($triggerSource);
}

############################################################################################################

=head2 AFG1_Trigger

    AFG1_Trigger();

Trigger AFG via GPIB (BUS). Note that the AFG must be in trigger Mode BUS
(AFG1_TriggerSource("BUS");).

=cut

sub AFG1_trigger
{
    S_w2log( 4, "AFG1: trigger!\n" );
    return 1 if $main::opt_offline;
    $afg1->trigger();
}

############################################################################################################

=head2 AFG1_burstPhase

    AFG1_burstPhase($phase);

Set the burst mode's phase to $phase. Only makes sense when Burst Mode is active.

=cut

sub AFG1_burstPhase
{
    my $phase = shift;
    unless ( defined($phase) )
    {
        S_set_error( "SYNTAX: AFG1_burstPhase( phase )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: set burst phase to $phase\n" );
    return 1 if $main::opt_offline;
    $afg1->burstPhase($phase);
}

############################################################################################################

=head2 AFG1_outputLoad

    AFG1_outputLoad($load);

Set the output load to the given Ohm value or to infinity (if parameter INFinity or INF used),
respectively MINimum or MAXimum. Parameter is directly sent to AFG without additional checks.

=cut

sub AFG1_outputLoad
{
    my $load = shift;
    unless ( defined($load) )
    {
        S_set_error( "SYNTAX: AFG1_outputLoad( load )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: set output load to $load\n" );
    return 1 if $main::opt_offline;
    $afg1->outputLoad($load);
}

############################################################################################################
######### User Generated Waveform functions ##########

=head1 User Generated Waveform METHODS

=cut

############################################################################################################

=head2 AFG1_newVolatileWF

    AFG1_newVolatileWF([$interpolate[, $pointsTotal]]);

Create a new volatile waveform.

If $interpolate is non-zero, linear
interpolation is used, otherwise ($interpolate is 0 or not defined)
the previous value is continued to the next
datapoint (results in "steps"). This linear interpolation
is done by this program, not by the AFG, smoothness of the curve
depends on the number of datapoints.
By default, no interpolation is used.

The maximum number
of datapoints $pointsTotal (must be in range 2 ... 65536). Note that
the AFG 33220A uses internally either 16384 or 65536 points. Therefore
it is most accurate to use powers of 2.
By default, 128 is used to limit the amount of data transmitted, although
this program increases the number of points automatically if required.

For details it is referred to the AFG's manual.

=cut

sub AFG1_newVolatileWF
{
    my $interpolate = shift;
    my $pointsTotal = shift;

    if ( defined $pointsTotal )
    {
        S_w2log( 4, "AFG1: creating new volatile waveform: \$interpolate=$interpolate, \$pointsTotal=$pointsTotal.\n" );
    }
    elsif ( defined $interpolate )
    {
        S_w2log( 4, "AFG1: creating new volatile waveform: \$interpolate=$interpolate, \$pointsTotal=DEFAULT.\n" );
    }
    else
    {
        S_w2log( 4, "AFG1: creating new volatile waveform: \$interpolate=DEFAULT, \$pointsTotal=DEFAULT.\n" );
    }
    return 1 if $main::opt_offline;
    $afg1->newVolatileWF( $interpolate, $pointsTotal );
}

############################################################################################################

=head2 AFG1_setWFVoltage

    AFG1_setWFVoltage($voltage, $duration);

Set a voltage for a specific duration. Note that when intrapolation is used, the voltage does
not necessarily remain at this level but is intrapolated to the next datapoint.

Therefore if you need the voltage to remain stable for a certain time your either need
to switch interpolation off in the function call newVolatileWF(...) or you need additional
sampling points ("St�tzstellen").

=cut

sub AFG1_setWFVoltage
{
    my $voltage  = shift;
    my $duration = shift;

    unless ( defined($duration) )
    {
        S_set_error( "SYNTAX: AFG1_setWFVoltage( voltage, duration )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1: setting waveform voltage $voltage V for duration $duration ms\n" );
    return 1 if $main::opt_offline;
    $afg1->setWFVoltage( $voltage, $duration );
}

############################################################################################################

=head2 AFG1_sendWaveForm

    AFG1_sendWaveForm();

Send waveform to AFG. After this function has been called, no datapoints can be added anymore and
you are starting again with a new waveform (same after calling newVolatileWF(...)).

Period is set to the sum of durations and voltage levels are adjusted. If the output is set to
50 Ohm, the voltages are divided by 2.

If the AFG's output was on, it is switched off before loading the waveform, then switched on again.

For details it is referred to the AFG's manual.

=cut

sub AFG1_sendWaveForm
{
    S_w2log( 4, "AFG1: sending waveform to AFG\n" );
    return 1 if $main::opt_offline;
    $afg1->sendWaveForm();
    S_w2log( 4, "AFG1: INFO: maximum timing error of sent waveform: " . $afg1->getWfMaxTimeError() . "ms\n" );
}

######### low level functions ##########

=head1 LOW LEVEL METHODS

=cut

############################################################################################################

=head2 AFG1_writeString

    AFG1_writeString( $string );

write string directly to AFG

=cut

sub AFG1_writeString
{
    my $string = shift;
    unless ( defined($string) )
    {
        S_set_error( "SYNTAX: AFG1_writeString( string )", 110 );
        return 1;
    }
    S_w2log( 4, "AFG1_writeString: Writes $string \n" );
    return 1 if $main::opt_offline;
    $afg1->writeString($string);

}

############################################################################################################

=head2 AFG1_readString

    $string = AFG1_readString();

read string directly from AFG

debug return: 'dummy'

=cut

sub AFG1_readString
{
    return 'dummy' if $main::opt_offline;
    my $string = $afg1->readString();
    S_w2log( 5, "AFG1_readString Read $string \n" );
    return ($string);
}

# Preloaded methods go here.

1;
__END__


=head1 AUTHOR

Roger Hartmann, E<lt>Roger.Hartmann@de.BOSCH.comE<gt>
Frank B�hm, E<lt>Frank.Boehm@de.bosch.comE<gt>

=head1 SEE ALSO

perl, GPIB documentation, AFG manual.

=cut
